<?php
defined('ABSPATH') || exit;
if (!current_user_can('manage_options')) { echo '<div class="alert alert-danger">دسترسی مجاز نیست.</div>'; return; }
$s = KGP_Plugin::settings();
$sections = KGP_Plugin::sections();
$section = (string) ($page_context['definition']['kgp_section'] ?? 'general');
if (!isset($sections[$section])) { $section = 'general'; }
$editable = $section === 'general' || $section === 'products' || isset($s['sources'][$section]);
$providers = KGP_Plugin::providers();
$last = (array) get_option('kgp_last_result', []);
if ($section === 'preview') {
    $last = array_merge(['time' => time(), 'preview' => true], $last);
    $last['rows'] = KGP_Dynamic_Pricing::preview(); // Memory-only; never persist derived prices.
}
$notice = get_transient('kgp_notice_' . get_current_user_id());
delete_transient('kgp_notice_' . get_current_user_id());
// Native ERP classes; no extra UI framework or public assets.
$field = static function (string $name, string $label, $value, string $help = '', string $type = 'text', array $options = [], string $column = 'col-md-6') {
    $id = 'kgp-' . sanitize_key(str_replace(['[', ']'], ['-', ''], $name));
    echo '<div class="' . esc_attr($column) . '"><div class="form-group"><label class="form-label" for="' . esc_attr($id) . '">' . esc_html($label) . '</label>';
    $parts = explode('[', $name, 2);
    $name = 'settings[' . $parts[0] . ']' . (isset($parts[1]) ? '[' . $parts[1] : '');
    if ($options) {
        echo '<select class="form-select" id="' . esc_attr($id) . '" name="' . esc_attr($name) . '">';
        foreach ($options as $key => $title) { echo '<option value="' . esc_attr($key) . '" ' . selected($value, $key, false) . '>' . esc_html($title) . '</option>'; }
        echo '</select>';
    } else {
        echo '<input class="form-control" dir="ltr" id="' . esc_attr($id) . '" name="' . esc_attr($name) . '" type="' . esc_attr($type) . '" value="' . esc_attr($type === 'password' ? '' : $value) . '"';
        if ($type === 'number') { echo ' min="0" step="any" required'; }
        if ($type === 'password') { echo ' autocomplete="new-password"'; }
        echo '>';
    }
    if ($help !== '') { echo '<span class="form-note">' . esc_html($help) . '</span>'; }
    echo '</div></div>';
};
$secret = static function (string $source, string $key, string $label) use ($field, $s) {
    $exists = $s['sources'][$source][$key] !== '';
    $field('sources[' . $source . '][' . $key . ']', $label, '', $exists ? 'ذخیره شده؛ برای حفظ مقدار، خالی بگذارید.' : 'هنوز وارد نشده است.', 'password');
    echo '<div class="col-12"><label><input type="checkbox" name="settings[sources][' . esc_attr($source) . '][clear_' . esc_attr($key) . ']" value="1"> حذف ' . esc_html($label) . ' ذخیره‌شده</label></div>';
};
$units = ['IRT' => 'تومان', 'IRR' => 'ریال'];
$timezones = ['Asia/Tehran' => 'تهران — Asia/Tehran', 'UTC' => 'UTC'];
$source_help = [
    'tabangohar' => 'نام کاربری و رمز اشتراک خودتان را وارد کنید. اتصال مطابق راهنمای تابان گوهر است؛ نرخ پایه یک گرم طلای ۱۸ عیار است.',
    'brs' => 'نرخ IR_GOLD_18K از وب‌سرویس طلا و ارز دریافت می‌شود. این اتصال از سرویس اونس دلاری کامودیتی استفاده نمی‌کند. دسترسی Pro به نوع کلید شما بستگی دارد.',
    'custom' => 'برای افزودن منبع جدید با پاسخ JSON؛ نرخ باید قیمت یک گرم طلای ۱۸ عیار باشد. مسیرها را با نقطه جدا کنید، مانند data.gold.price.',
];
?>
<div class="nk-block-head nk-block-head-sm"><div class="nk-block-between"><div class="nk-block-head-content">
<h3 class="nk-block-title page-title"><?php echo esc_html($sections[$section]['title']); ?></h3><div class="nk-block-des text-soft"><p>اتصال نرخ طلا به محصولات ووکامرس</p></div></div>
<span class="badge <?php echo $s['enabled'] ? 'bg-success-dim text-success' : 'bg-warning-dim text-warning'; ?>"><?php echo $s['enabled'] ? 'قیمت پویا فعال' : 'قیمت پویا خاموش'; ?></span></div></div>
<?php if ($notice): ?><div class="alert alert-info" role="status"><?php echo esc_html($notice); ?></div><?php endif; ?>
<div class="nk-block">
<?php KERP_Helpers_Template::render_template('app/components/settings/hero.php', [
    'icon' => 'icon ni ni-coins', 'eyebrow' => 'مدیریت نرخ و قیمت', 'title' => 'از نرخ بازار تا قیمت محصول',
    'description' => 'اتصال و زمان‌بندی را اینجا تنظیم کنید؛ قیمت‌گذاری خودکار را در صفحه هر محصول یا تنوع فعال کنید. وزن و هزینه‌ها از همان محصول خوانده می‌شوند.',
    'stats' => [ ['label' => 'محصولات خودکار', 'value' => count(KGP_Catalog::ids())], ['label' => 'واحد فروشگاه', 'value' => get_woocommerce_currency()], ['label' => 'فاصله اجرا', 'value' => $s['interval'] . ' دقیقه'] ],
]); ?>
</div>
<?php if ($editable): ?>
<form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="nk-block">
<input type="hidden" name="kgp_section" value="<?php echo esc_attr($section); ?>"><input type="hidden" name="action" value="kgp_action"><input type="hidden" name="kgp_command" value="save"><?php wp_nonce_field('kgp_action'); ?>
<?php if ($section === 'general'): ?>
<div class="row g-4" data-kgp-settings>
    <div class="col-lg-6">
        <div class="card card-bordered"><div class="card-inner">
            <h5 class="card-title mb-4">منابع و زمان‌بندی</h5><div class="row g-4">
            <?php
            $names = array_map(static function ($p) { return $p['label']; }, $providers);
            $field('provider', 'منبع اصلی', $s['provider'], 'تنظیمات سرویس انتخابی روبه‌رو نمایش داده می‌شود.', 'text', $names, 'col-12');
            $field('fallback', 'جایگزین هنگام خطای منبع اصلی', $s['fallback'], 'اگر جایگزین انتخاب کنید، تنظیمات آن هم همین‌جا نمایش داده می‌شود.', 'text', ['' => 'بدون جایگزین'] + $names, 'col-12');
            $field('interval', 'فاصله اجرا (دقیقه)', $s['interval'], 'از ۱ تا ۱۴۴۰؛ اجرای WP-Cron به ترافیک سایت وابسته است.', 'number');
            $field('age', 'حداکثر عمر زمان سرویس (دقیقه)', $s['age'], 'نرخ دارای زمان قدیمی یا نامعتبر استفاده نمی‌شود.', 'number');
            $field('jump', 'حداکثر تغییر مجاز نرخ سرویس (%)', $s['jump'], 'افزایش یا کاهش نسبت به آخرین نرخ پذیرفته‌شده؛ از ۰٫۱ تا ۱۰۰۰ درصد.', 'number', [], 'col-12');
            $field('tax_percent', 'مالیات افزوده به اجرت و سود (%)', $s['tax_percent'], 'پیش‌فرض صفر؛ اگر ووکامرس مالیات را محاسبه می‌کند، از محاسبه دوباره جلوگیری کنید.', 'number');
            $field('round_step', 'گام گردکردن قیمت', $s['round_step'], 'در واحد پول فروشگاه؛ پیش‌فرض ۱.', 'number');
            ?>
            </div><label class="d-block mt-4"><input type="checkbox" name="settings[enabled]" value="1" <?php checked($s['enabled']); ?>> قیمت پویا و دریافت دوره‌ای نرخ فعال باشد</label>
            <p class="form-note mt-3">برای هر محصول یا تنوع، گزینه «قیمت پویا با نرخ طلا (بدون ذخیره قیمت)» را در ویرایش محصول فعال کنید. قیمت هنگام نمایش و محاسبه سبد خرید از نرخ معتبر خوانده می‌شود؛ قیمت نهایی در محصول ذخیره نمی‌شود. زمان‌بندی فقط نرخ پایه را تازه می‌کند.</p>
        </div></div>
    </div>
    <div class="col-lg-6" data-kgp-source-panels>
        <?php foreach ($s['sources'] as $key => $config): if (!isset($providers[$key])) { continue; }
            $visible = $key === $s['provider'] || ($s['fallback'] !== '' && $key === $s['fallback']); ?>
            <section data-kgp-source="<?php echo esc_attr($key); ?>" <?php if (!$visible) { echo 'hidden style="display:none"'; } ?>>
                <?php include __DIR__ . '/source-settings.php'; ?>
            </section>
        <?php endforeach; ?>
        <noscript><p class="form-note">پس از انتخاب منبع، تنظیمات را ذخیره کنید تا فرم همان سرویس نمایش داده شود.</p></noscript>
    </div>
</div>
<?php endif; ?>
<div class="mt-4">
<input type="hidden" name="settings_complete" value="1">
<button class="btn btn-primary" type="submit"><em class="icon ni ni-save"></em><span>ذخیره تنظیمات</span></button>
</div></form>
<?php endif; ?>
<?php foreach ($s['sources'] as $key => $config): if ($section !== 'general') { continue; } ?>
<form id="kgp-test-<?php echo esc_attr($key); ?>" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="kgp_section" value="<?php echo esc_attr($section); ?>"><input type="hidden" name="action" value="kgp_action"><input type="hidden" name="kgp_command" value="test_<?php echo esc_attr($key); ?>"><?php wp_nonce_field('kgp_action'); ?></form>
<?php endforeach; ?>
<?php if ($section === 'preview'): ?>
<div class="nk-block"><div class="card card-bordered"><div class="card-inner"><h5 class="card-title">پیش‌نمایش قیمت</h5><p class="text-soft">محاسبه این جدول فقط در حافظه انجام می‌شود. دکمه زیر نرخ پایه را تازه می‌کند؛ هیچ قیمت نهایی در محصول یا تنظیمات ذخیره نمی‌شود.</p><div class="d-flex flex-wrap gap-2">
<?php foreach (['preview' => 'دریافت آخرین نرخ و پیش‌نمایش'] as $command => $label): ?>
<form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="kgp_section" value="<?php echo esc_attr($section); ?>"><input type="hidden" name="action" value="kgp_action"><input type="hidden" name="kgp_command" value="<?php echo esc_attr($command); ?>"><?php wp_nonce_field('kgp_action'); ?><button type="submit" class="btn <?php echo $command === 'apply' ? 'btn-primary' : 'btn-light'; ?>"><?php echo esc_html($label); ?></button></form>
<?php endforeach; ?></div>
<?php if ($last): ?><hr><h6>نتیجه آخرین اجرا: دریافت نرخ</h6><p class="text-soft"><?php echo esc_html(wp_date('Y/m/d H:i:s', $last['time'])); ?></p>
<?php if (!empty($last['skipped'])): ?><ul class="text-danger"><?php foreach ($last['skipped'] as $skip): ?><li><?php echo esc_html($skip['error']); ?></li><?php endforeach; ?></ul><?php endif; ?>
<?php if (!empty($last['error'])): ?><div class="alert alert-danger"><?php echo esc_html($last['error']); ?></div><?php endif; ?>
<?php if (!empty($last['quote'])): $quote = $last['quote']; ?><p>منبع: <strong><?php echo esc_html($providers[$quote['provider']]['label'] ?? $quote['provider']); ?></strong> — نرخ یک گرم در واحد فروشگاه: <strong><?php echo esc_html(number_format_i18n($quote['rate'], wc_get_price_decimals())); ?></strong><br>زمان اعلام‌شده سرویس: <?php echo esc_html(wp_date('Y/m/d H:i:s', $quote['time'])); ?></p>
<?php if (!empty($quote['fallback_used'])): ?><div class="alert alert-warning">از منبع جایگزین استفاده شد: <?php echo esc_html(implode(' | ', $quote['failures'])); ?></div><?php endif; ?>
<?php endif; ?>
<div class="table-responsive"><table class="table"><thead><tr><th>محصول</th><th>وزن (گرم)</th><th>اجرت %</th><th>سود %</th><th>متعلقات در واحد فروشگاه</th><th>قیمت ثبت‌شده در محصول</th><th>قیمت پویا</th></tr></thead><tbody><?php foreach (($last['rows'] ?? []) as $row): ?><tr><td><?php echo esc_html($row['name']); ?></td><td><?php echo esc_html(number_format_i18n($row['inputs']['weight'] ?? 0, 3)); ?></td><td><?php echo esc_html($row['inputs']['making_percent'] ?? '—'); ?></td><td><?php echo esc_html($row['inputs']['profit'] ?? '—'); ?></td><td><?php echo esc_html(number_format_i18n($row['inputs']['accessories'] ?? 0, wc_get_price_decimals())); ?></td><td><?php echo is_numeric($row['old']) ? esc_html(number_format_i18n($row['old'], wc_get_price_decimals())) : '—'; ?></td><td><?php echo $row['new'] === null ? 'در دسترس نیست' : esc_html(number_format_i18n($row['new'], wc_get_price_decimals())); ?></td></tr><?php endforeach; ?></tbody></table></div>
<?php endif; ?></div></div></div>
<?php endif; ?>
<?php if ($section === 'logs'): ?>
<div class="nk-block"><div class="card card-bordered"><div class="card-inner"><h5 class="card-title">گزارش اجراها</h5><div class="table-responsive"><table class="table"><thead><tr><th>زمان</th><th>عملیات</th><th>منبع</th><th>وضعیت</th></tr></thead><tbody><?php foreach ((array) get_option('kgp_logs', []) as $log): ?><tr><td><?php echo esc_html(wp_date('Y/m/d H:i:s', $log['time'])); ?></td><td>دریافت نرخ</td><td><?php echo esc_html($providers[$log['provider'] ?? '']['label'] ?? '—'); ?></td><td><?php echo esc_html($log['error'] ?: (!empty($log['fallback']) ? 'موفق با منبع جایگزین' : 'موفق')); ?></td></tr><?php endforeach; ?></tbody></table></div>
<details class="mt-3"><summary class="text-soft">رفع قفل دریافت نرخ قطع‌شده</summary><p class="form-note mt-2">فقط قفل قدیمی‌تر از ۳۰ دقیقه آزاد می‌شود؛ ابتدا از متوقف‌بودن اجرای قبلی مطمئن شوید.</p><form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="kgp_section" value="<?php echo esc_attr($section); ?>"><input type="hidden" name="action" value="kgp_action"><input type="hidden" name="kgp_command" value="unlock"><?php wp_nonce_field('kgp_action'); ?><button class="btn btn-light" type="submit">آزادسازی قفل قدیمی</button></form></details>
</div></div></div>

<?php endif; ?>
