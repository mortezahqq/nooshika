<?php
defined('ABSPATH') || exit;

/** Only the source quote is persisted; never a derived product price. */
final class KGP_Market {
    public static function get(bool $require_enabled = true): ?array {
        $s = KGP_Plugin::settings();
        $q = get_option('kgp_market_quote', []);
        if (($require_enabled && !$s['enabled']) || !is_array($q) || !isset($q['rate'], $q['time'], $q['currency']) || $q['currency'] !== get_woocommerce_currency()) { return null; }
        if (!is_numeric($q['rate']) || !is_finite((float) $q['rate']) || $q['rate'] <= 0 || !is_numeric($q['time']) || $q['time'] < time() - $s['age'] * 60 || $q['time'] > time() + 120) { return null; }
        return $q;
    }
    public static function refresh(): array {
        if (!add_option('kgp_quote_lock', time(), '', false)) { return ['error' => 'دریافت نرخ دیگری در حال اجراست.']; }
        $result = ['time' => time(), 'preview' => true, 'count' => 0];
        try {
            $s = KGP_Plugin::settings();
            $q = KGP_Plugin::quote($s);
            $previous = get_option('kgp_market_quote', []);
            if (is_array($previous) && isset($previous['rate'], $previous['currency']) && is_numeric($previous['rate']) && $previous['rate'] > 0 && $previous['currency'] === $q['currency'] && abs($q['rate'] - $previous['rate']) / $previous['rate'] * 100 > $s['jump']) {
                KGP_Plugin::fail('تغییر نرخ از سقف مجاز بیشتر است؛ نرخ قبلی تا پایان اعتبارش حفظ شد.');
            }
            $q['fetched_at'] = time();
            update_option('kgp_market_quote', $q, false);
            $result['quote'] = $q;
        } catch (Throwable $e) {
            $result['error'] = $e instanceof KGP_Exception ? $e->getMessage() : 'دریافت نرخ انجام نشد.';
        } finally { delete_option('kgp_quote_lock'); }
        // Operational status contains only the market quote, not per-product calculations.
        update_option('kgp_last_result', $result, false);
        $logs = (array) get_option('kgp_logs', []);
        array_unshift($logs, ['time' => $result['time'], 'preview' => true, 'count' => 0, 'error' => $result['error'] ?? '', 'provider' => $result['quote']['provider'] ?? '', 'fallback' => $result['quote']['fallback_used'] ?? false]);
        update_option('kgp_logs', array_slice($logs, 0, 30), false);
        return $result;
    }
    public static function scheduled_refresh(): void {
        if (KGP_Plugin::settings()['enabled']) { self::refresh(); }
    }
    public static function maybe_schedule(): void {
        $last = (array) get_option('kgp_last_result', []);
        if (($last['time'] ?? 0) > time() - 60) { return; }
        if (KGP_Plugin::settings()['enabled'] && !self::get() && !wp_next_scheduled('kgp_refresh_quote')) { wp_schedule_single_event(time() + 1, 'kgp_refresh_quote'); }
    }
    public static function migrate(): void {
        if (get_option('kgp_dynamic_mode_v1')) { return; }
        wp_unschedule_hook('kgp_update_products');
        // Old preview rows contained derived prices. Do not retain them in the new mode.
        delete_option('kgp_last_result');
        delete_option('kgp_lock');
        update_option('kgp_dynamic_mode_v1', 1, false);
    }
}
