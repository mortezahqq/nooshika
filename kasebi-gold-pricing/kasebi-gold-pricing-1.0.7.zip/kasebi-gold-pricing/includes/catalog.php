<?php
defined('ABSPATH') || exit;

final class KGP_Catalog {
    public static function boot(): void {
        add_action('woocommerce_product_options_pricing', [self::class, 'simple_field']);
        add_action('woocommerce_variation_options_pricing', [self::class, 'variation_field'], 20, 3);
        add_action('woocommerce_admin_process_product_object', [self::class, 'save_simple']);
        add_action('woocommerce_admin_process_variation_object', [self::class, 'save_variation'], 20, 2);
        add_action('init', [self::class, 'migrate'], 25);
    }
    public static function opted($product): bool {
        return $product && in_array($product->get_type(), ['simple', 'variation'], true) && $product->get_meta('_kgp_enabled', true, 'edit') === 'yes';
    }
    public static function ids(): array {
        return array_map('absint', get_posts([
            'post_type' => ['product', 'product_variation'], 'post_status' => ['publish', 'private'],
            'posts_per_page' => -1, 'fields' => 'ids', 'orderby' => 'ID', 'order' => 'ASC',
            'meta_key' => '_kgp_enabled', 'meta_value' => 'yes', 'no_found_rows' => true,
        ]));
    }
    public static function simple_field(): void {
        global $product_object;
        if (!$product_object) { return; }
        echo '<input type="hidden" name="kgp_product_present" value="1">';
        woocommerce_wp_checkbox([
            'id' => '_kgp_enabled', 'label' => 'قیمت پویا با نرخ طلا (بدون ذخیره قیمت)',
            'value' => $product_object->get_meta('_kgp_enabled', true, 'edit'),
            'wrapper_class' => 'show_if_simple',
            'description' => 'وزن، اجرت، سود و متعلقات همین محصول استفاده می‌شود. قیمت در نمایش و سبد خرید محاسبه می‌شود؛ قیمت ثبت‌شده محصول تغییر نمی‌کند. اتصال و دریافت نرخ را یک‌بار در ERP فعال کنید.',
        ]);
    }
    public static function variation_field($loop, $data, $variation): void {
        $product = wc_get_product($variation->ID);
        if (!$product) { return; }
        echo '<input type="hidden" name="kgp_variation_present[' . (int) $loop . ']" value="1">';
        woocommerce_wp_checkbox([
            'id' => 'kgp_enabled_' . (int) $loop, 'name' => 'kgp_enabled[' . (int) $loop . ']',
            'label' => 'قیمت پویا با نرخ طلا (بدون ذخیره قیمت)', 'value' => $product->get_meta('_kgp_enabled', true, 'edit'),
            'wrapper_class' => 'form-row form-row-full',
            'description' => 'قیمت این تنوع هنگام نمایش و خرید از وزن و هزینه‌های خودش محاسبه می‌شود؛ در محصول ذخیره نمی‌شود.',
        ]);
    }
    public static function save_simple($product): void {
        if (empty($_POST['kgp_product_present']) || !current_user_can('edit_post', $product->get_id())) { return; }
        $product->update_meta_data('_kgp_enabled', $product->get_type() === 'simple' && isset($_POST['_kgp_enabled']) && $_POST['_kgp_enabled'] === 'yes' ? 'yes' : 'no');
    }
    public static function save_variation($product, $loop): void {
        if (empty($_POST['kgp_variation_present'][$loop]) || !current_user_can('edit_post', $product->get_id())) { return; }
        $product->update_meta_data('_kgp_enabled', ($_POST['kgp_enabled'][$loop] ?? '') === 'yes' ? 'yes' : 'no');
    }
    public static function migrate(): void {
        if (get_option('kgp_catalog_v1')) { return; }
        // The previous explicit selection remains opted in; never overwrite a saved opt-out.
        foreach (KGP_Plugin::settings()['rules'] as $row) {
            $id = absint($row['id'] ?? 0); $product = $id ? wc_get_product($id) : false;
            if ($product && in_array($product->get_type(), ['simple', 'variation'], true) && !metadata_exists('post', $id, '_kgp_enabled')) {
                update_post_meta($id, '_kgp_enabled', 'yes');
            }
        }
        update_option('kgp_catalog_v1', 1, false);
    }
}
