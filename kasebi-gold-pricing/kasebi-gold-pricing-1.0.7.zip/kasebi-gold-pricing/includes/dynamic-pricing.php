<?php
defined('ABSPATH') || exit;

final class KGP_Dynamic_Pricing {
    public static function boot(): void {
        foreach (['woocommerce_product_get_price', 'woocommerce_product_get_regular_price', 'woocommerce_product_variation_get_price', 'woocommerce_product_variation_get_regular_price'] as $hook) {
            add_filter($hook, [self::class, 'price'], 99, 2);
        }
        foreach (['woocommerce_product_get_sale_price', 'woocommerce_product_variation_get_sale_price'] as $hook) { add_filter($hook, [self::class, 'sale'], 99, 2); }
        add_filter('woocommerce_product_is_on_sale', [self::class, 'on_sale'], 99, 2);
        // This final filter runs AFTER Woo's persistent transient is written, into request memory only.
        add_filter('woocommerce_get_variation_prices_hash', [self::class, 'price_hash'], 99, 3);
        add_filter('woocommerce_variation_prices', [self::class, 'variation_prices'], 99, 3);
        add_filter('woocommerce_get_price_html', [self::class, 'price_html'], 99, 2);
        add_filter('woocommerce_add_to_cart_validation', [self::class, 'validate_add'], 99, 4);
        add_action('woocommerce_check_cart_items', [self::class, 'validate_cart']);
        add_action('woocommerce_store_api_cart_errors', [self::class, 'validate_store_cart'], 99, 2);
    }
    public static function active($product): bool { return KGP_Plugin::settings()['enabled'] && KGP_Catalog::opted($product); }
    public static function value($product, bool $preview = false): ?string {
        $q = KGP_Market::get(!$preview);
        if (!$q) { return null; }
        try {
            $inputs = KGP_Product_Pricing::read($product, KGP_Plugin::settings());
            $price = wc_format_decimal(KGP_Plugin::calculate((float) $q['rate'], $inputs), wc_get_price_decimals());
            return is_numeric($price) && is_finite((float) $price) && (float) $price > 0 ? $price : null;
        } catch (Throwable $e) { return null; }
    }
    public static function price($original, $product) { return self::active($product) ? (self::value($product) ?? '') : $original; }
    public static function sale($original, $product) { return self::active($product) ? '' : $original; }
    public static function on_sale($original, $product) { return self::active($product) ? false : $original; }
    public static function price_hash(array $hash, $product, bool $for_display): array {
        $s = KGP_Plugin::settings(); $q = KGP_Market::get();
        $hash['kgp_runtime'] = [$s['enabled'], $q['rate'] ?? null, $q['time'] ?? null, get_woocommerce_currency(), $s['tax_percent'], $s['round_step']];
        return $hash;
    }
    public static function variation_prices(array $prices, $parent, bool $for_display): array {
        if (!KGP_Plugin::settings()['enabled']) { return $prices; }
        foreach ($parent->get_visible_children() as $id) {
            $child = wc_get_product($id);
            if (!self::active($child)) { continue; }
            $price = self::value($child);
            if ($price === null) {
                foreach (['price','regular_price','sale_price'] as $key) { unset($prices[$key][$id]); }
                continue;
            }
            $value = $for_display ? wc_get_price_to_display($child, ['price' => (float) $price]) : $price;
            foreach (['price','regular_price','sale_price'] as $key) { $prices[$key][$id] = wc_format_decimal($value, wc_get_price_decimals()); }
        }
        foreach (['price','regular_price','sale_price'] as $key) { if (isset($prices[$key])) { asort($prices[$key], SORT_NUMERIC); } }
        return $prices;
    }
    public static function price_html($html, $product): string {
        if (self::active($product) && self::value($product) === null) { return '<span class="kgp-unavailable">قیمت معتبر در دسترس نیست</span>'; }
        if ($html === '' && $product->is_type('variable') && KGP_Plugin::settings()['enabled']) {
            foreach ($product->get_visible_children() as $id) { if (self::active(wc_get_product($id))) { return '<span class="kgp-unavailable">قیمت معتبر در دسترس نیست</span>'; } }
        }
        return $html;
    }
    private static function error(): void { wc_add_notice('نرخ معتبر طلا یا اطلاعات قیمت‌گذاری یکی از محصولات در دسترس نیست؛ لطفاً بعداً دوباره تلاش کنید.', 'error'); }
    public static function validate_add($passed, $id, $quantity, $variation_id = 0): bool {
        $product = wc_get_product($variation_id ?: $id);
        if (self::active($product) && self::value($product) === null) { self::error(); return false; }
        return (bool) $passed;
    }
    public static function validate_cart(): void {
        if (!WC()->cart) { return; }
        foreach (WC()->cart->get_cart() as $item) {
            $product = $item['data'] ?? null;
            if (self::active($product) && self::value($product) === null) { self::error(); return; }
        }
    }
    public static function validate_store_cart($errors, $cart): void {
        foreach ($cart->get_cart() as $item) {
            $product = $item['data'] ?? null;
            if (self::active($product) && self::value($product) === null) { $errors->add('kgp_invalid_quote', 'نرخ معتبر طلا یا اطلاعات قیمت‌گذاری محصول در دسترس نیست.'); return; }
        }
    }
    public static function preview(): array {
        $rows = [];
        foreach (KGP_Catalog::ids() as $id) {
            $p = wc_get_product($id);
            if (!KGP_Catalog::opted($p)) { continue; }
            $price = self::value($p, true);
            $rows[] = ['id' => $id, 'name' => $p->get_name(), 'old' => $p->get_regular_price('edit'), 'new' => $price, 'inputs' => $price !== null ? KGP_Product_Pricing::read($p, KGP_Plugin::settings()) : []];
        }
        return $rows;
    }
}
