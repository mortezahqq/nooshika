<?php
defined('ABSPATH') || exit;
require_once __DIR__ . '/includes/providers.php';
final class KGP_Exception extends RuntimeException {}

final class KGP_Plugin {
    public static function boot(): void {
        add_filter('kerp_app_pages', [self::class, 'pages'], 90);
        add_filter('kerp_template_path', static function ($path, $template) {
            return $template === 'addons/gold-pricing.php' ? __DIR__ . '/templates/settings.php' : $path;
        }, 10, 2);
        add_action('admin_post_kgp_action', [self::class, 'handle']);
        add_filter('cron_schedules', static function ($s) {
            $s['kgp_interval'] = ['interval' => self::settings()['interval'] * 60, 'display' => 'Gold price interval'];
            return $s;
        });
        add_action('kgp_tick', static function () {
            if (self::settings()['enabled']) { self::run(false); }
        });
        add_action('init', static function () {
            if (self::settings()['enabled'] && !wp_next_scheduled('kgp_tick')) {
                wp_schedule_event(time() + 60, 'kgp_interval', 'kgp_tick');
            }
        }, 30);
    }
    public static function providers(): array {
        return apply_filters('kgp_providers', [
            'tabangohar' => ['label' => 'تابان گوهر', 'adapter' => new KGP_Taban_Provider()],
            'brs' => ['label' => 'BRS — طلای ۱۸ عیار ایران', 'adapter' => new KGP_BRS_Provider()],
            'custom' => ['label' => 'وب‌سرویس JSON سفارشی', 'adapter' => new KGP_JSON_Provider()],
        ]);
    }
    public static function defaults(): array {
        return apply_filters('kgp_default_settings', [
            'enabled' => false, 'provider' => 'tabangohar', 'fallback' => '',
            'interval' => 5, 'age' => 15, 'jump' => 20, 'rules' => [],
            'sources' => [
                'tabangohar' => ['username' => '', 'password' => '', 'price_path' => 'YekGram18', 'time_path' => 'TimeRead', 'timezone' => 'Asia/Tehran', 'unit' => 'IRT'],
                'brs' => ['secret' => '', 'endpoint' => 'pro', 'time_path' => 'time_unix', 'time_scope' => 'item', 'timezone' => 'Asia/Tehran', 'unit' => 'IRT'],
                'custom' => ['url' => '', 'secret' => '', 'header' => 'Authorization', 'prefix' => 'Bearer ', 'price_path' => '', 'time_path' => '', 'timezone' => 'Asia/Tehran', 'unit' => 'IRT'],
            ],
        ]);
    }
    public static function settings(): array {
        return array_replace_recursive(self::defaults(), (array) get_option('kgp_settings', []));
    }
    public static function pages(array $pages): array {
        if (!current_user_can('manage_options')) { return $pages; }
        $pages['gold-pricing'] = [
            'title' => 'قیمت‌گذاری طلا', 'route' => 'settings/gold-pricing', 'type' => 'settings',
            'template' => 'addons/gold-pricing.php', 'permission' => '',
            'navigation' => [
                'group' => ['key' => 'settings', 'title' => 'تنظیمات', 'icon' => 'kik fa-settings-02', 'order' => 100, 'sep_before' => true],
                'title' => 'قیمت‌گذاری طلا', 'icon' => 'ni ni-coins', 'order' => 90,
            ],
        ];
        return $pages;
    }
    public static function fail(string $message): void { throw new KGP_Exception($message); }
    public static function calculate(float $rate, array $r): float {
        // Tax applies to making charges + seller profit, not the gold principal.
        $gold = $rate * $r['weight'];
        $making = $gold * $r['making_percent'] / 100 + $r['making_fixed'];
        $profit = ($gold + $making) * $r['profit'] / 100;
        $total = $gold + $making + $profit + ($making + $profit) * $r['tax'] / 100;
        return round($total / $r['round']) * $r['round'];
    }
    public static function normalize(array $q, array $s, string $key): array {
        if (!isset($q['price'], $q['time'], $q['unit']) || !is_numeric($q['price']) || !is_numeric($q['time'])) {
            self::fail('ساختار نرخ دریافتی معتبر نیست.');
        }
        if ($q['time'] < time() - $s['age'] * 60 || $q['time'] > time() + 120) { self::fail('زمان اعلام‌شده سرویس قدیمی یا جلوتر از ساعت سایت است.'); }
        $factors = ['IRR' => 1, 'IRT' => 10, 'IRHR' => 1000, 'IRHT' => 10000];
        $currency = get_woocommerce_currency();
        if (!isset($factors[$currency]) || !in_array($q['unit'], ['IRR', 'IRT'], true)) { self::fail('واحد نرخ یا واحد فروشگاه پشتیبانی نمی‌شود.'); }
        $rate = (float) $q['price'] * $factors[$q['unit']] / $factors[$currency];
        if ($rate <= 0 || !is_finite($rate)) { self::fail('نرخ نهایی معتبر نیست.'); }
        return ['rate' => $rate, 'time' => (int) $q['time'], 'provider' => $key, 'currency' => $currency, 'raw' => (float) $q['price'], 'unit' => $q['unit']];
    }
    public static function quote(array $s, ?string $only = null): array {
        $providers = self::providers();
        $keys = $only !== null ? [$only] : array_values(array_unique(array_filter([$s['provider'], $s['fallback']])));
        $failures = [];
        foreach ($keys as $key) {
            try {
                if (empty($providers[$key]['adapter']) || !isset($s['sources'][$key])) { self::fail('منبع قیمت موجود نیست.'); }
                $q = $providers[$key]['adapter']->fetch($s['sources'][$key]);
                if (is_wp_error($q)) { self::fail($q->get_error_message()); }
                if (!is_array($q)) { self::fail('ساختار نرخ دریافتی معتبر نیست.'); }
                $quote = self::normalize($q, $s, $key);
                $quote['fallback_used'] = count($failures) > 0;
                $quote['failures'] = $failures;
                return $quote;
            } catch (KGP_Exception $e) {
                $failures[] = ($providers[$key]['label'] ?? $key) . ': ' . $e->getMessage();
            }
        }
        self::fail(implode(' | ', $failures));
    }
    public static function test_source(string $key): array {
        $result = ['time' => time(), 'provider' => $key];
        try { $result['quote'] = self::quote(self::settings(), $key); }
        catch (Throwable $e) { $result['error'] = $e instanceof KGP_Exception ? $e->getMessage() : 'خطای داخلی هنگام بررسی اتصال.'; }
        update_option('kgp_connection_' . sanitize_key($key), $result, false);
        return $result;
    }
    public static function run(bool $preview = true): array {
        // Atomic option insert serializes manual and cron updates, including settings writes.
        if (!add_option('kgp_lock', time(), '', false)) { return ['error' => 'عملیات دیگری در حال اجراست. اگر فرایند قطع شده، قفل را از بخش تنظیمات آزاد کنید.']; }
        $result = ['time' => time(), 'preview' => $preview, 'rows' => [], 'count' => 0];
        try {
            $s = self::settings();
            if (!$s['rules']) { self::fail('حداقل یک قانون محصول تعریف کنید.'); }
            $q = self::quote($s);
            $result['quote'] = $q;
            $products = [];
            foreach ($s['rules'] as $r) {
                $p = wc_get_product($r['id']);
                if (!$p || !in_array($p->get_type(), ['simple', 'variation'], true) || $p->get_status() === 'trash') { self::fail('محصول ساده یا متغیر فرزند معتبر نیست: ' . $r['id']); }
                // Preserve sale semantics by requiring sales to be removed before opting in.
                if ($p->get_sale_price('edit') !== '') { self::fail('محصول ' . $r['id'] . ' قیمت حراج دارد؛ ابتدا حراج را حذف کنید.'); }
                $new = (float) wc_format_decimal(self::calculate($q['rate'], $r), wc_get_price_decimals());
                $old = (float) $p->get_regular_price('edit');
                if ($new <= 0 || !is_finite($new)) { self::fail('قیمت محاسبه‌شده نامعتبر است.'); }
                if ($old > 0 && abs($new - $old) / $old * 100 > $s['jump']) { self::fail('تغییر قیمت محصول ' . $r['id'] . ' از سقف مجاز بیشتر است.'); }
                $result['rows'][] = ['id' => $r['id'], 'name' => $p->get_name(), 'old' => $old, 'new' => $new];
                $products[] = $p;
            }
            // All prices are validated before the first write. WC writes are not a DB transaction.
            if (!$preview) {
                foreach ($products as $i => $p) {
                    if ($q['time'] < time() - $s['age'] * 60) { self::fail('نرخ در حین اجرا منقضی شد.'); }
                    $p->set_regular_price(wc_format_decimal($result['rows'][$i]['new'], wc_get_price_decimals()));
                    $p->set_price(wc_format_decimal($result['rows'][$i]['new'], wc_get_price_decimals()));
                    $p->update_meta_data('_kgp_last_update', ['time' => time(), 'rate' => $q['rate'], 'provider' => $q['provider']]);
                    $p->save();
                    $result['count']++;
                    if ($p->is_type('variation')) { WC_Product_Variable::sync($p->get_parent_id()); }
                    wc_delete_product_transients($p->get_id());
                }
            }
        } catch (Throwable $e) {
            // Do not persist exception content: remote endpoints may contain credentials.
            $result['error'] = $e instanceof KGP_Exception ? $e->getMessage() : 'خطای داخلی هنگام اعمال قیمت؛ گزارش تعداد اعمال‌شده را بررسی کنید.';
        }
        try {
            update_option('kgp_last_result', $result, false);
            $logs = (array) get_option('kgp_logs', []);
            array_unshift($logs, ['time' => $result['time'], 'preview' => $preview, 'count' => $result['count'], 'error' => $result['error'] ?? '', 'provider' => $result['quote']['provider'] ?? '', 'fallback' => $result['quote']['fallback_used'] ?? false]);
            update_option('kgp_logs', array_slice($logs, 0, 30), false);
        } finally { delete_option('kgp_lock'); }
        return $result;
    }
    public static function scalar($value): string {
        if (!is_scalar($value)) { self::fail('مقدار ورودی نامعتبر است.'); }
        return (string) $value;
    }
    public static function clean(array $raw): array {
        $s = self::settings();
        $s['provider'] = sanitize_key(self::scalar($raw['provider'] ?? ''));
        $s['fallback'] = sanitize_key(self::scalar($raw['fallback'] ?? ''));
        $providers = self::providers();
        if (!isset($providers[$s['provider']]) || ($s['fallback'] !== '' && !isset($providers[$s['fallback']]))) { self::fail('منبع قیمت نامعتبر است.'); }
        if ($s['fallback'] === $s['provider']) { self::fail('منبع جایگزین باید با منبع اصلی متفاوت باشد.'); }
        foreach ($s['sources'] as $key => $config) {
            $input = $raw['sources'][$key] ?? [];
            if (!is_array($input)) { self::fail('تنظیمات اتصال نامعتبر است.'); }
            foreach ($config as $field => $old) {
                if (in_array($field, ['password', 'secret'], true)) {
                    if (!empty($input['clear_' . $field])) { $config[$field] = ''; }
                    elseif (isset($input[$field]) && self::scalar($input[$field]) !== '') {
                        $config[$field] = self::scalar($input[$field]);
                        if (strlen($config[$field]) > 2048 || preg_match('/[\x00-\x1F\x7F]/', $config[$field])) { self::fail('کلید یا رمز نامعتبر است.'); }
                    }
                    continue;
                }
                $config[$field] = $field === 'prefix'
                    ? preg_replace('/[\r\n]/', '', self::scalar($input[$field] ?? $old))
                    : sanitize_text_field(self::scalar($input[$field] ?? $old));
            }
            if (!in_array($config['unit'], ['IRR', 'IRT'], true)) { self::fail('واحد نرخ نامعتبر است.'); }
            if (!in_array($config['timezone'], DateTimeZone::listIdentifiers(), true)) { self::fail('منطقه زمانی معتبر نیست.'); }
            foreach (['price_path', 'time_path'] as $field) {
                if (isset($config[$field]) && strlen($config[$field]) > 200) { self::fail('مسیر فیلد بیش از حد طولانی است.'); }
            }
            if ($key === 'brs' && (!in_array($config['endpoint'], ['pro', 'standard'], true) || !in_array($config['time_scope'], ['item', 'root'], true))) { self::fail('تنظیمات BRS نامعتبر است.'); }
            if ($key === 'custom') {
                $config['url'] = esc_url_raw($config['url']);
                if ($config['url'] !== '' && strtolower((string) wp_parse_url($config['url'], PHP_URL_SCHEME)) !== 'https') { self::fail('آدرس سفارشی باید HTTPS باشد.'); }
                if (!preg_match('/^[A-Za-z][A-Za-z0-9-]*$/D', $config['header'])) { self::fail('نام هدر معتبر نیست.'); }
            }
            $s['sources'][$key] = $config;
        }
        foreach (['interval' => [1, 1440], 'age' => [1, 1440], 'jump' => [0.1, 1000]] as $key => $limits) {
            $n = KGP_Data::number($raw[$key] ?? '');
            if (!is_finite($n) || $n < $limits[0] || $n > $limits[1]) { self::fail('مقدار نامعتبر: ' . $key); }
            $s[$key] = in_array($key, ['interval', 'age'], true) ? (int) $n : $n;
        }
        $s['rules'] = [];
        $seen = [];
        foreach ((array) ($raw['rules'] ?? []) as $row) {
            if (!is_array($row) || empty($row['id'])) { continue; }
            $id_number = KGP_Data::number($row['id']);
            if (!is_finite($id_number) || floor($id_number) !== $id_number || $id_number < 1 || $id_number > PHP_INT_MAX) { self::fail('شناسه محصول باید عدد صحیح مثبت باشد.'); }
            $id = (int) $id_number;
            if (!$id || isset($seen[$id])) { self::fail('شناسه محصول نامعتبر یا تکراری است.'); }
            $seen[$id] = true;
            $r = ['id' => $id];
            foreach (['weight', 'making_percent', 'making_fixed', 'profit', 'tax', 'round'] as $k) {
                if (!isset($row[$k]) || !is_scalar($row[$k]) || !preg_match('/^[0-9۰-۹٠-٩.,٬٫ ]+$/uD', (string) $row[$k])) { self::fail('مقدار عددی قانون نامعتبر است.'); }
                $r[$k] = KGP_Data::number($row[$k]);
                if (!is_finite($r[$k]) || $r[$k] < 0 || $r[$k] > 1000000000000) { self::fail('مقدار قانون خارج از محدوده است.'); }
            }
            if ($r['weight'] <= 0 || $r['round'] <= 0) { self::fail('وزن و گام گردکردن باید مثبت باشند.'); }
            $s['rules'][] = $r;
        }
        if (count($s['rules']) > 100) { self::fail('حداکثر ۱۰۰ محصول در این نسخه قابل تعریف است.'); }
        $s['enabled'] = !empty($raw['enabled']);
        if ($s['enabled'] && !$s['rules']) { self::fail('قبل از فعال‌کردن، قوانین محصولات را کامل کنید.'); }
        return $s;
    }
    public static function handle(): void {
        if (!current_user_can('manage_options')) { wp_die('دسترسی مجاز نیست.', '', ['response' => 403]); }
        check_admin_referer('kgp_action');
        $action = is_string($_POST['kgp_command'] ?? null) ? sanitize_key(wp_unslash($_POST['kgp_command'])) : '';
        $message = '';
        try {
            if ($action === 'save') {
                if (($_POST['settings_complete'] ?? '') !== '1') { self::fail('فرم ناقص دریافت شد؛ محدودیت max_input_vars سرور را بررسی کنید.'); }
                if (!add_option('kgp_lock', time(), '', false)) { self::fail('عملیات در حال اجراست.'); }
                try {
                    $s = self::clean((array) wp_unslash($_POST['settings'] ?? []));
                    update_option('kgp_settings', $s, false);
                    wp_clear_scheduled_hook('kgp_tick');
                    if ($s['enabled']) { wp_schedule_event(time() + 60, 'kgp_interval', 'kgp_tick'); }
                } finally { delete_option('kgp_lock'); }
                $message = 'تنظیمات ذخیره شد.';
            } elseif (strpos($action, 'test_') === 0) {
                $r = self::test_source(substr($action, 5));
                $message = $r['error'] ?? 'اتصال و نرخ دریافتی معتبر است؛ محصولی تغییر نکرد.';
            } elseif ($action === 'unlock') {
                if ((int) get_option('kgp_lock', time()) > time() - 1800) { self::fail('فقط قفل قدیمی‌تر از ۳۰ دقیقه آزاد می‌شود.'); }
                delete_option('kgp_lock');
                $message = 'قفل قدیمی آزاد شد.';
            } elseif (in_array($action, ['preview', 'apply'], true)) {
                $r = self::run($action === 'preview');
                $message = $r['error'] ?? ($action === 'preview' ? 'پیش‌نمایش آماده شد؛ قیمت‌ها تغییر نکردند.' : 'قیمت‌ها اعمال شد.');
            } else { self::fail('عملیات نامعتبر است.'); }
        } catch (KGP_Exception $e) { $message = $e->getMessage(); }
        set_transient('kgp_notice_' . get_current_user_id(), $message, 120);
        wp_safe_redirect(home_url('/erp/settings/gold-pricing/'));
        exit;
    }
}
