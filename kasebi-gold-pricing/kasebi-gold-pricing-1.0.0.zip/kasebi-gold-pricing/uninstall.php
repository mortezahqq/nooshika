<?php
defined('WP_UNINSTALL_PLUGIN') || exit;
wp_clear_scheduled_hook('kgp_tick');
$settings = (array) get_option('kgp_settings', []);
$sources = array_unique(array_merge(['tabangohar', 'brs', 'custom'], array_keys((array) ($settings['sources'] ?? []))));
foreach ($sources as $source) { delete_option('kgp_connection_' . sanitize_key($source)); }
foreach (['kgp_settings', 'kgp_last_result', 'kgp_logs', 'kgp_lock'] as $key) { delete_option($key); }
// Uninstall never reverts live product prices or touches orders.
