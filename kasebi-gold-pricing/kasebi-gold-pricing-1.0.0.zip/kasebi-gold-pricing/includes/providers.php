<?php
defined('ABSPATH') || exit;

/** Shared parsing and HTTPS transport. Never return remote bodies or credential URLs as errors. */
final class KGP_Data {
    public static function number($value): float {
        if (!is_scalar($value) || is_bool($value)) { return NAN; }
        $digits = preg_split('//u', '۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩', -1, PREG_SPLIT_NO_EMPTY);
        $value = strtr((string) $value, array_combine($digits, str_split('01234567890123456789')));
        $value = str_replace([',', '٬', ' '], '', trim($value));
        $value = str_replace('٫', '.', $value);
        return is_numeric($value) ? (float) $value : NAN;
    }
    public static function path(array $data, string $path) {
        if ($path === '') { return null; }
        foreach (explode('.', $path) as $part) {
            if (!is_array($data) || !array_key_exists($part, $data)) { return null; }
            $data = $data[$part];
        }
        return $data;
    }
    public static function timestamp($raw, string $timezone): int {
        $n = self::number($raw);
        if (is_finite($n)) {
            if ($n > 100000000000) { $n /= 1000; }
            return $n >= 1000000000 && $n <= 9999999999 ? (int) $n : 0;
        }
        if (!is_string($raw)) { return 0; }
        // Full Gregorian dates only; a time of day or relative expression is not a source timestamp.
        if (!preg_match('~^[12][0-9]{3}[-/][0-9]{2}[-/][0-9]{2}[T ][0-9]{2}:[0-9]{2}(?::[0-9]{2}(?:\.[0-9]+)?)?(?:Z|[+-][0-9]{2}:?[0-9]{2})?$~D', $raw)) { return 0; }
        try {
            $date = new DateTimeImmutable($raw, new DateTimeZone($timezone));
            $errors = DateTimeImmutable::getLastErrors();
            if ($errors && ($errors['warning_count'] || $errors['error_count'])) { return 0; }
            return $date->getTimestamp();
        } catch (Throwable $e) { return 0; }
    }
    public static function json(string $url, array $headers = []) {
        if (strtolower((string) wp_parse_url($url, PHP_URL_SCHEME)) !== 'https') {
            return new WP_Error('endpoint', 'آدرس API باید HTTPS عمومی باشد.');
        }
        $response = wp_safe_remote_get($url, [
            'timeout' => 15, 'redirection' => 0, 'limit_response_size' => 1048576,
            'headers' => array_merge(['Accept' => 'application/json'], $headers), 'sslverify' => true,
        ]);
        if (is_wp_error($response)) { return new WP_Error('network', 'ارتباط با سرویس قیمت برقرار نشد.'); }
        $code = wp_remote_retrieve_response_code($response);
        if ($code !== 200) { return new WP_Error('http', 'پاسخ ناموفق سرویس؛ کد ' . (int) $code); }
        $data = json_decode(wp_remote_retrieve_body($response), true);
        if (is_string($data)) { $data = json_decode($data, true); }
        return is_array($data) ? $data : new WP_Error('json', 'پاسخ سرویس JSON معتبر نیست.');
    }
    public static function money_unit($raw): ?string {
        if (!is_string($raw)) { return null; }
        $value = strtolower(trim($raw));
        return ['irr' => 'IRR', 'rial' => 'IRR', 'ریال' => 'IRR', 'irt' => 'IRT', 'toman' => 'IRT', 'تومان' => 'IRT'][$value] ?? null;
    }
    public static function quote($price, $time, array $c, ?string $unit = null) {
        $price = self::number($price);
        $stamp = self::timestamp($time, $c['timezone']);
        if (!is_finite($price) || $price <= 0) { return new WP_Error('price', 'قیمت مثبت و معتبر در پاسخ سرویس پیدا نشد.'); }
        if (!$stamp) { return new WP_Error('time', 'زمان کامل و معتبر نرخ پیدا نشد؛ مسیر زمان و منطقه زمانی را بررسی کنید.'); }
        return ['price' => $price, 'time' => $stamp, 'unit' => $unit ?? $c['unit']];
    }
}

final class KGP_Taban_Provider {
    public function fetch(array $c) {
        if ($c['username'] === '' || $c['password'] === '') { return new WP_Error('credentials', 'نام کاربری و رمز تابان گوهر وارد نشده است.'); }
        $url = 'https://webservice.tgnsrv.ir/Pr/Get/' . rawurlencode($c['username']) . '/' . rawurlencode($c['password']);
        $body = KGP_Data::json($url);
        if (is_wp_error($body)) { return $body; }
        if (!empty($body['Error'])) { return new WP_Error('taban_auth', 'تابان گوهر دسترسی را نپذیرفت؛ اعتبار اشتراک، اطلاعات ورود، IP و سهمیه را بررسی کنید.'); }
        return KGP_Data::quote(KGP_Data::path($body, $c['price_path']), KGP_Data::path($body, $c['time_path']), $c);
    }
}

final class KGP_BRS_Provider {
    public function fetch(array $c) {
        if ($c['secret'] === '') { return new WP_Error('credentials', 'کلید BRS وارد نشده است.'); }
        $endpoint = $c['endpoint'] === 'standard' ? 'Gold_Currency.php' : 'Gold_Currency_Pro.php';
        $url = add_query_arg(['key' => $c['secret'], 'section' => 'gold'], 'https://api.brsapi.ir/Market/' . $endpoint);
        $body = KGP_Data::json($url);
        if (is_wp_error($body)) { return $body; }
        if (isset($body['successful']) && !in_array($body['successful'], [true, 1, '1', 'true'], true)) {
            return new WP_Error('brs_auth', 'BRS درخواست را نپذیرفت؛ کلید، دسترسی سرویس و سهمیه را بررسی کنید.');
        }
        $items = self::items($body['gold'] ?? []);
        $matches = array_values(array_filter($items, static function ($item) { return ($item['symbol'] ?? '') === 'IR_GOLD_18K'; }));
        if (count($matches) !== 1) { return new WP_Error('symbol', 'یک رکورد یکتا برای IR_GOLD_18K در پاسخ BRS پیدا نشد.'); }
        $item = $matches[0];
        $unit = null;
        if (isset($item['unit']) && $item['unit'] !== '') {
            $unit = KGP_Data::money_unit($item['unit']);
            if ($unit === null) { return new WP_Error('unit', 'واحد نرخ BRS ریال یا تومان نیست.'); }
        }
        $source = $c['time_scope'] === 'root' ? $body : $item;
        return KGP_Data::quote($item['price'] ?? null, KGP_Data::path($source, $c['time_path']), $c, $unit);
    }
    private static function items($data, int $depth = 0): array {
        if (!is_array($data) || $depth > 6) { return []; }
        if (isset($data['symbol'])) { return [$data]; }
        $items = [];
        foreach ($data as $value) {
            if (is_array($value)) { $items = array_merge($items, self::items($value, $depth + 1)); }
        }
        return $items;
    }
}

/** Future providers can register another adapter through kgp_providers. */
class KGP_JSON_Provider {
    public function fetch(array $c) {
        $headers = [];
        if ($c['secret'] !== '') { $headers[$c['header']] = $c['prefix'] . $c['secret']; }
        $body = KGP_Data::json($c['url'], $headers);
        if (is_wp_error($body)) { return $body; }
        return KGP_Data::quote(KGP_Data::path($body, $c['price_path']), KGP_Data::path($body, $c['time_path']), $c);
    }
}
