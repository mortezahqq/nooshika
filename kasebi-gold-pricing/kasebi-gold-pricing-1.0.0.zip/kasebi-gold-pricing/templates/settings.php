<?php
defined('ABSPATH') || exit;
if (!current_user_can('manage_options')) { echo '<div class="alert alert-danger">دسترسی مجاز نیست.</div>'; return; }
$s = KGP_Plugin::settings();
$providers = KGP_Plugin::providers();
$last = (array) get_option('kgp_last_result', []);
$notice = get_transient('kgp_notice_' . get_current_user_id());
delete_transient('kgp_notice_' . get_current_user_id());
// Native ERP classes; no extra UI framework or public assets.
$field = static function (string $name, string $label, $value, string $help = '', string $type = 'text', array $options = []) {
    $id = 'kgp-' . sanitize_key(str_replace(['[', ']'], ['-', ''], $name));
    echo '<div class="col-md-6"><div class="form-group"><label class="form-label" for="' . esc_attr($id) . '">' . esc_html($label) . '</label>';
    $parts = explode('[', $name, 2);
    $name = 'settings[' . $parts[0] . ']' . (isset($parts[1]) ? '[' . $parts[1] : '');
    if ($options) {
        echo '<select class="form-select" id="' . esc_attr($id) . '" name="' . esc_attr($name) . '">';
        foreach ($options as $key => $title) { echo '<option value="' . esc_attr($key) . '" ' . selected($value, $key, false) . '>' . esc_html($title) . '</option>'; }
        echo '</select>';
    } else {
        echo '<input class="form-control" dir="ltr" id="' . esc_attr($id) . '" name="' . esc_attr($name) . '" type="' . esc_attr($type) . '" value="' . esc_attr($type === 'password' ? '' : $value) . '"';
        if ($type === 'number') { echo ' min="0" step="any" required'; }
        if ($type === 'password') { echo ' autocomplete="new-password"'; }
        echo '>';
    }
    if ($help !== '') { echo '<span class="form-note">' . esc_html($help) . '</span>'; }
    echo '</div></div>';
};
$secret = static function (string $source, string $key, string $label) use ($field, $s) {
    $exists = $s['sources'][$source][$key] !== '';
    $field('sources[' . $source . '][' . $key . ']', $label, '', $exists ? 'ذخیره شده؛ برای حفظ مقدار، خالی بگذارید.' : 'هنوز وارد نشده است.', 'password');
    echo '<div class="col-12"><label><input type="checkbox" name="settings[sources][' . esc_attr($source) . '][clear_' . esc_attr($key) . ']" value="1"> حذف ' . esc_html($label) . ' ذخیره‌شده</label></div>';
};
$units = ['IRT' => 'تومان', 'IRR' => 'ریال'];
$timezones = ['Asia/Tehran' => 'تهران — Asia/Tehran', 'UTC' => 'UTC'];
$source_help = [
    'tabangohar' => 'نام کاربری و رمز اشتراک خودتان را وارد کنید. اتصال مطابق راهنمای تابان گوهر است؛ نرخ پایه یک گرم طلای ۱۸ عیار است.',
    'brs' => 'نرخ IR_GOLD_18K از وب‌سرویس طلا و ارز دریافت می‌شود. این اتصال از سرویس اونس دلاری کامودیتی استفاده نمی‌کند. دسترسی Pro به نوع کلید شما بستگی دارد.',
    'custom' => 'برای افزودن منبع جدید با پاسخ JSON؛ نرخ باید قیمت یک گرم طلای ۱۸ عیار باشد. مسیرها را با نقطه جدا کنید، مانند data.gold.price.',
];
?>
<div class="nk-block-head nk-block-head-sm"><div class="nk-block-between"><div class="nk-block-head-content">
<h3 class="nk-block-title page-title">قیمت‌گذاری طلا</h3><div class="nk-block-des text-soft"><p>اتصال نرخ طلا به محصولات ووکامرس</p></div></div>
<span class="badge <?php echo $s['enabled'] ? 'bg-success-dim text-success' : 'bg-warning-dim text-warning'; ?>"><?php echo $s['enabled'] ? 'به‌روزرسانی خودکار فعال' : 'به‌روزرسانی خودکار خاموش'; ?></span></div></div>
<?php if ($notice): ?><div class="alert alert-info" role="status"><?php echo esc_html($notice); ?></div><?php endif; ?>
<div class="nk-block">
<?php KERP_Helpers_Template::render_template('app/components/settings/hero.php', [
    'icon' => 'icon ni ni-coins', 'eyebrow' => 'مدیریت نرخ و قیمت', 'title' => 'از نرخ بازار تا قیمت محصول',
    'description' => 'اطلاعات اتصال و قوانین را ذخیره کنید، اتصال را بسنجید و پیش‌نمایش قیمت‌ها را ببینید. فقط محصولات انتخاب‌شده به‌روزرسانی می‌شوند.',
    'stats' => [ ['label' => 'محصولات تعریف‌شده', 'value' => count($s['rules'])], ['label' => 'واحد فروشگاه', 'value' => get_woocommerce_currency()], ['label' => 'فاصله اجرا', 'value' => $s['interval'] . ' دقیقه'] ],
]); ?>
</div>
<form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="nk-block">
<input type="hidden" name="action" value="kgp_action"><input type="hidden" name="kgp_command" value="save"><?php wp_nonce_field('kgp_action'); ?>
<div class="card card-bordered"><div class="card-inner"><h5 class="card-title mb-4">منابع و زمان‌بندی</h5><div class="row g-4">
<?php
$names = array_map(static function ($p) { return $p['label']; }, $providers);
$field('provider', 'منبع اصلی', $s['provider'], '', 'text', $names);
$field('fallback', 'جایگزین هنگام خطای منبع اصلی', $s['fallback'], 'اگر اتصال یا اعتبار زمان نرخ منبع اصلی ناموفق باشد، جایگزین امتحان می‌شود.', 'text', ['' => 'بدون جایگزین'] + $names);
$field('interval', 'فاصله اجرا (دقیقه)', $s['interval'], 'از ۱ تا ۱۴۴۰؛ اجرای WP-Cron به ترافیک سایت وابسته است.', 'number');
$field('age', 'حداکثر عمر زمان اعلام‌شده سرویس (دقیقه)', $s['age'], 'نرخ دارای زمان قدیمی یا نامعتبر استفاده نمی‌شود.', 'number');
$field('jump', 'حداکثر تغییر مجاز قیمت هر محصول (%)', $s['jump'], 'افزایش یا کاهش نسبت به قیمت عادی فعلی؛ از ۰٫۱ تا ۱۰۰۰ درصد.', 'number');
?>
</div></div></div>
<?php foreach ($s['sources'] as $key => $config): if (!isset($providers[$key])) { continue; } ?>
<div class="card card-bordered mt-4"><div class="card-inner"><div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3"><h5 class="card-title mb-0"><?php echo esc_html($providers[$key]['label']); ?></h5><button class="btn btn-sm btn-outline-primary" type="submit" form="kgp-test-<?php echo esc_attr($key); ?>"><em class="icon ni ni-link"></em><span>آزمایش اتصال ذخیره‌شده</span></button></div>
<p class="text-soft"><?php echo esc_html($source_help[$key] ?? 'تنظیمات منبع افزوده‌شده'); ?></p><div class="row g-4">
<?php
$base = 'sources[' . $key . ']';
if ($key === 'tabangohar') {
    $field($base . '[username]', 'نام کاربری تابان گوهر', $config['username']);
    $secret($key, 'password', 'رمز تابان گوهر');
} elseif ($key === 'brs') {
    $secret($key, 'secret', 'کلید API سرویس BRS');
    $field($base . '[endpoint]', 'نسخه وب‌سرویس BRS', $config['endpoint'], 'Pro مطابق کد ارسالی همکاران؛ نسخه استاندارد برای کلیدهای سازگار با آن.', 'text', ['pro' => 'Gold_Currency_Pro', 'standard' => 'Gold_Currency']);
} elseif ($key === 'custom') {
    $field($base . '[url]', 'آدرس HTTPS سرویس JSON', $config['url'], 'کلید را در قسمت کلید API وارد کنید.', 'url');
    $secret($key, 'secret', 'کلید API سفارشی');
    $field($base . '[header]', 'نام هدر احراز هویت', $config['header']);
    $field($base . '[prefix]', 'پیشوند کلید', $config['prefix'], 'مثلاً Bearer همراه یک فاصله؛ برای X-API-Key معمولاً خالی است.');
} else {
    foreach ($config as $config_key => $config_value) {
        if (in_array($config_key, ['price_path', 'time_path', 'timezone', 'unit'], true)) { continue; }
        if (in_array($config_key, ['password', 'secret'], true)) { $secret($key, $config_key, $config_key); }
        else { $field($base . '[' . $config_key . ']', $config_key, $config_value); }
    }
}
$field($base . '[unit]', 'واحد نرخ خام سرویس', $config['unit'], $key === 'brs' ? 'اگر پاسخ BRS فیلد unit معتبر داشته باشد، واحد همان پاسخ اولویت دارد.' : 'پیش‌فرض تومان است؛ با نمونه نرخ اشتراک خود تطبیق دهید.', 'text', $units);
?>
</div><details class="mt-4"><summary class="text-primary">تنظیمات فیلدها و زمان سرویس</summary><div class="row g-4 mt-1">
<?php
if (isset($config['price_path'])) { $field($base . '[price_path]', 'مسیر فیلد نرخ', $config['price_path'], $key === 'tabangohar' ? 'پیش‌فرض YekGram18؛ تنها در صورت تغییر عنوان فیلد اشتراک خود ویرایش کنید.' : 'فیلد نرخ یک گرم طلای ۱۸ عیار'); }
$field($base . '[time_path]', 'مسیر فیلد زمان', $config['time_path'], $key === 'tabangohar' ? 'TimeRead طبق راهنما زمان خواندن از سرور است؛ زمان معامله بازار را تضمین نمی‌کند.' : 'Unix ثانیه/میلی‌ثانیه یا تاریخ کامل میلادی؛ ساعت بدون تاریخ پذیرفته نمی‌شود.');
if ($key === 'brs') { $field($base . '[time_scope]', 'محل فیلد زمان در BRS', $config['time_scope'], 'متناسب با ساختار پاسخ اشتراک خود تنظیم کنید.', 'text', ['item' => 'داخل رکورد IR_GOLD_18K', 'root' => 'ریشه پاسخ JSON']); }
$field($base . '[timezone]', 'منطقه زمانی تاریخ بدون offset', $config['timezone'], 'زمان Unix یا تاریخ دارای offset مستقل از این انتخاب است.', 'text', $timezones);
?>
</div></details>
<?php $connection = (array) get_option('kgp_connection_' . $key, []); if ($connection): ?>
<div class="alert <?php echo empty($connection['error']) ? 'alert-success' : 'alert-warning'; ?> mt-4 mb-0"><strong>آخرین آزمایش اتصال: </strong><?php echo esc_html(wp_date('Y/m/d H:i:s', $connection['time'])); ?><br>
<?php if (!empty($connection['error'])) { echo esc_html($connection['error']); } elseif (!empty($connection['quote'])) { echo 'نرخ یک گرم در واحد فروشگاه: ' . esc_html(number_format_i18n($connection['quote']['rate'], wc_get_price_decimals())); } ?></div>
<?php endif; ?></div></div>
<?php endforeach; ?>
<div class="card card-bordered mt-4"><div class="card-inner"><h5 class="card-title">قوانین محصولات</h5><p class="text-soft">وزن خالص طلای ۱۸ عیار بر حسب گرم؛ اجرت ثابت و گام گردکردن بر حسب واحد فروشگاه. شناسه محصول ساده یا شناسه هر تنوع را وارد کنید. با خالی‌کردن شناسه و ذخیره، آن محصول از برنامه حذف می‌شود.</p>
<p class="form-note">اصل طلا = نرخ × وزن؛ اجرت = درصد اصل طلا + اجرت ثابت؛ سود = درصد (اصل طلا + اجرت)؛ مالیات = درصد (اجرت + سود). درصدها را مطابق نیاز خود تعیین کنید.</p>
<div class="table-responsive"><table class="table"><thead><tr><?php foreach (['شناسه محصول', 'وزن (گرم)', 'اجرت %', 'اجرت ثابت', 'سود %', 'مالیات %', 'گام گردکردن'] as $title): ?><th scope="col"><?php echo esc_html($title); ?></th><?php endforeach; ?></tr></thead><tbody>
<?php
$rows = $s['rules'];
$blank_count = min(5, 100 - count($rows));
for ($i = 0; $i < $blank_count; $i++) { $rows[] = ['id' => '', 'weight' => 1, 'making_percent' => 0, 'making_fixed' => 0, 'profit' => 0, 'tax' => 0, 'round' => 1]; }
$labels = ['id' => 'شناسه محصول', 'weight' => 'وزن', 'making_percent' => 'درصد اجرت', 'making_fixed' => 'اجرت ثابت', 'profit' => 'درصد سود', 'tax' => 'درصد مالیات', 'round' => 'گام گردکردن'];
foreach ($rows as $i => $row): ?><tr>
<?php foreach ($labels as $key => $label): ?><td><input aria-label="<?php echo esc_attr($label . ' ردیف ' . ($i + 1)); ?>" class="form-control" style="min-width:100px" type="number" min="0" step="<?php echo $key === 'id' ? '1' : 'any'; ?>" name="settings[rules][<?php echo (int) $i; ?>][<?php echo esc_attr($key); ?>]" value="<?php echo esc_attr($row[$key]); ?>"></td><?php endforeach; ?></tr><?php endforeach; ?>
</tbody></table></div><p class="form-note">با ذخیره، ۵ ردیف خالی دیگر اضافه می‌شود؛ حداکثر ۱۰۰ محصول. محصولات دارای قیمت حراج برای جلوگیری از تداخل پذیرفته نمی‌شوند.</p>
<label class="d-block my-3"><input type="checkbox" name="settings[enabled]" value="1" <?php checked($s['enabled']); ?>> به‌روزرسانی خودکار قیمت‌ها فعال باشد</label>
<input type="hidden" name="settings_complete" value="1">
<button class="btn btn-primary" type="submit"><em class="icon ni ni-save"></em><span>ذخیره تنظیمات</span></button>
</div></div></form>
<?php foreach ($s['sources'] as $key => $config): ?>
<form id="kgp-test-<?php echo esc_attr($key); ?>" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="action" value="kgp_action"><input type="hidden" name="kgp_command" value="test_<?php echo esc_attr($key); ?>"><?php wp_nonce_field('kgp_action'); ?></form>
<?php endforeach; ?>
<div class="nk-block"><div class="card card-bordered"><div class="card-inner"><h5 class="card-title">پیش‌نمایش و اعمال قیمت</h5><p class="text-soft">هر اجرا از تنظیمات ذخیره‌شده، نرخ تازه دریافت می‌کند. پیش‌نمایش محصولی را تغییر نمی‌دهد. اعمال دستی حتی با زمان‌بندی خاموش در دسترس است.</p><div class="d-flex flex-wrap gap-2">
<?php foreach (['preview' => 'دریافت نرخ و پیش‌نمایش', 'apply' => 'دریافت نرخ و اعمال روی محصولات'] as $command => $label): ?>
<form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="action" value="kgp_action"><input type="hidden" name="kgp_command" value="<?php echo esc_attr($command); ?>"><?php wp_nonce_field('kgp_action'); ?><button type="submit" class="btn <?php echo $command === 'apply' ? 'btn-primary' : 'btn-light'; ?>"><?php echo esc_html($label); ?></button></form>
<?php endforeach; ?></div>
<?php if ($last): ?><hr><h6>نتیجه آخرین اجرا: <?php echo !empty($last['preview']) ? 'پیش‌نمایش' : 'اعمال قیمت'; ?></h6><p class="text-soft"><?php echo esc_html(wp_date('Y/m/d H:i:s', $last['time'])); ?> — تعداد اعمال‌شده: <?php echo (int) ($last['count'] ?? 0); ?></p>
<?php if (!empty($last['error'])): ?><div class="alert alert-danger"><?php echo esc_html($last['error']); ?></div><?php endif; ?>
<?php if (!empty($last['quote'])): $quote = $last['quote']; ?><p>منبع: <strong><?php echo esc_html($providers[$quote['provider']]['label'] ?? $quote['provider']); ?></strong> — نرخ یک گرم در واحد فروشگاه: <strong><?php echo esc_html(number_format_i18n($quote['rate'], wc_get_price_decimals())); ?></strong><br>زمان اعلام‌شده سرویس: <?php echo esc_html(wp_date('Y/m/d H:i:s', $quote['time'])); ?></p>
<?php if (!empty($quote['fallback_used'])): ?><div class="alert alert-warning">از منبع جایگزین استفاده شد: <?php echo esc_html(implode(' | ', $quote['failures'])); ?></div><?php endif; ?>
<?php endif; ?>
<div class="table-responsive"><table class="table"><thead><tr><th>محصول</th><th>قیمت قبلی</th><th>قیمت محاسبه‌شده</th></tr></thead><tbody><?php foreach (($last['rows'] ?? []) as $row): ?><tr><td><?php echo esc_html('#' . $row['id'] . ' — ' . $row['name']); ?></td><td><?php echo esc_html(number_format_i18n($row['old'], wc_get_price_decimals())); ?></td><td><?php echo esc_html(number_format_i18n($row['new'], wc_get_price_decimals())); ?></td></tr><?php endforeach; ?></tbody></table></div>
<?php endif; ?></div></div></div>
<div class="nk-block"><div class="card card-bordered"><div class="card-inner"><h5 class="card-title">گزارش اجراها</h5><div class="table-responsive"><table class="table"><thead><tr><th>زمان</th><th>عملیات</th><th>اعمال‌شده</th><th>منبع</th><th>وضعیت</th></tr></thead><tbody><?php foreach ((array) get_option('kgp_logs', []) as $log): ?><tr><td><?php echo esc_html(wp_date('Y/m/d H:i:s', $log['time'])); ?></td><td><?php echo $log['preview'] ? 'پیش‌نمایش' : 'اعمال'; ?></td><td><?php echo (int) $log['count']; ?></td><td><?php echo esc_html($providers[$log['provider'] ?? '']['label'] ?? '—'); ?></td><td><?php echo esc_html($log['error'] ?: (!empty($log['fallback']) ? 'موفق با منبع جایگزین' : 'موفق')); ?></td></tr><?php endforeach; ?></tbody></table></div>
<details class="mt-3"><summary class="text-soft">رفع قفل اجرای قطع‌شده</summary><p class="form-note mt-2">فقط قفل قدیمی‌تر از ۳۰ دقیقه آزاد می‌شود؛ ابتدا از متوقف‌بودن اجرای قبلی مطمئن شوید.</p><form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="action" value="kgp_action"><input type="hidden" name="kgp_command" value="unlock"><?php wp_nonce_field('kgp_action'); ?><button class="btn btn-light" type="submit">آزادسازی قفل قدیمی</button></form></details>
</div></div></div>
