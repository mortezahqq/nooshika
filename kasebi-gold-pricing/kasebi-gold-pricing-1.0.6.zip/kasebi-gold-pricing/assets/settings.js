(function () {
    'use strict';
    function update(root) {
        var primary = root.querySelector('[name="settings[provider]"]');
        var fallback = root.querySelector('[name="settings[fallback]"]');
        if (!primary || !fallback) return;
        var selected = primary.value;
        var backup = fallback.value;
        root.querySelectorAll('[data-kgp-source]').forEach(function (panel) {
            var key = panel.getAttribute('data-kgp-source');
            var visible = key === selected || (backup !== '' && key === backup);
            panel.hidden = !visible;
            panel.style.display = visible ? '' : 'none';
            var label = panel.querySelector('[data-kgp-source-role]');
            if (label) label.textContent = key === selected ? 'منبع اصلی' : 'منبع جایگزین';
            panel.style.order = key === selected ? '0' : '1';
        });
        var panels = root.querySelector('[data-kgp-source-panels]');
        if (panels) {
            panels.style.display = 'flex';
            panels.style.flexDirection = 'column';
        }
    }
    function init(scope) {
        if (scope.nodeType !== 1 && scope.nodeType !== 9) return;
        if (scope.matches && scope.matches('[data-kgp-settings]')) update(scope);
        scope.querySelectorAll('[data-kgp-settings]').forEach(update);
    }
    function changed(target) {
        if (!target || (target.name !== 'settings[provider]' && target.name !== 'settings[fallback]')) return;
        var root = target.closest('[data-kgp-settings]');
        if (root) update(root);
    }
    document.addEventListener('change', function (event) { changed(event.target); });
    // Select2 and ERP controls can emit jQuery-only events instead of native change.
    if (typeof window !== 'undefined' && window.jQuery) {
        window.jQuery(document).on(
            'change.kgpSources select2:select.kgpSources select2:clear.kgpSources',
            '[data-kgp-settings] [name="settings[provider]"], [data-kgp-settings] [name="settings[fallback]"]',
            function () { changed(this); }
        );
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(document); });
    else init(document);
    // ERP replaces page HTML during AJAX navigation; no per-page inline scripts are needed.
    new MutationObserver(function (records) {
        records.forEach(function (record) { record.addedNodes.forEach(init); });
    }).observe(document.documentElement, {childList: true, subtree: true});
})();

