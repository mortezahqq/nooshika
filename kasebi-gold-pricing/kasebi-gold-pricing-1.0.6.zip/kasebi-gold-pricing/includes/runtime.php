<?php
defined('ABSPATH') || exit;

/** The ERP MU loader chooses plugins before ordinary plugin hooks can run. */
final class KGP_Runtime {
    public static function dependencies(): array {
        return [plugin_basename(dirname(__DIR__) . '/kasebi-gold-pricing.php'), 'woocommerce/woocommerce.php'];
    }
    public static function forced_plugins(array $plugins): array {
        $active = array_merge((array) get_option('active_plugins', []), array_keys((array) get_site_option('active_sitewide_plugins', [])));
        return array_values(array_unique(array_merge($plugins, array_values(array_intersect(self::dependencies(), $active)))));
    }
    public static function ensure_ajax_dependencies(): void {
        // Persist on an ordinary bootstrap so the *next* early MU bootstrap can retain us.
        // Never enable an inactive plugin, rewrite the MU loader, or replace another selection.
        $old = (array) get_option('kerp_ajax_active_plugins', []);
        $new = self::forced_plugins($old);
        if ($old !== $new) { update_option('kerp_ajax_active_plugins', $new, false); }
    }
}
