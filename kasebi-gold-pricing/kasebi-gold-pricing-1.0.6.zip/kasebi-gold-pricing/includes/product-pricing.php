<?php
defined('ABSPATH') || exit;

/** Read live Woo/KCP values; do not copy them into addon settings or update them. */
final class KGP_Product_Pricing {
    public static function read($product, array $settings): array {
        $raw_weight = $product->get_weight('edit');
        if ($raw_weight === '' && $product->is_type('variation')) {
            $parent = wc_get_product($product->get_parent_id());
            if ($parent) { $raw_weight = $parent->get_weight('edit'); }
        }
        $weight = KGP_Data::number($raw_weight);
        $unit = (string) get_option('woocommerce_weight_unit', 'kg');
        if (!in_array($unit, ['g', 'kg', 'lbs', 'oz'], true) || !is_finite($weight) || $weight <= 0) {
            KGP_Plugin::fail('وزن محصول «' . $product->get_name() . '» را در ووکامرس کامل کنید.');
        }
        $weight = (float) wc_get_weight($weight, 'g', $unit);
        $values = [];
        foreach (['accessories' => '_kcp_accessories_cost', 'making_percent' => '_kcp_wage_percent', 'profit' => '_kcp_profit_percent'] as $key => $meta) {
            $raw = $product->get_meta($meta, true, 'edit');
            $value = $raw === '' ? 0.0 : KGP_Data::number($raw);
            if (!is_finite($value) || $value < 0) { KGP_Plugin::fail('مقدار فیلد هزینه در محصول «' . $product->get_name() . '» معتبر نیست.'); }
            $values[$key] = $value;
        }
        // Uploaded KCP fields explicitly store accessories in toman regardless of shop currency.
        $factors = ['IRT' => 1, 'IRR' => 10, 'IRHT' => 0.001, 'IRHR' => 0.01];
        $currency = get_woocommerce_currency();
        if (!isset($factors[$currency])) { KGP_Plugin::fail('واحد فروشگاه پشتیبانی نمی‌شود.'); }
        $values['accessories'] *= $factors[$currency];
        return array_merge($values, ['weight' => $weight, 'making_fixed' => 0, 'tax' => $settings['tax_percent'], 'round' => $settings['round_step']]);
    }
}
