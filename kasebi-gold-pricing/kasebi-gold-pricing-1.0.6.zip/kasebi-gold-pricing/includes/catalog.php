<?php
defined('ABSPATH') || exit;

final class KGP_Catalog {
    public static bool $applying = false;
    public static function boot(): void {
        add_action('woocommerce_product_options_pricing', [self::class, 'simple_field']);
        add_action('woocommerce_variation_options_pricing', [self::class, 'variation_field'], 20, 3);
        add_action('woocommerce_admin_process_product_object', [self::class, 'save_simple']);
        add_action('woocommerce_admin_process_variation_object', [self::class, 'save_variation'], 20, 2);
        add_action('woocommerce_after_product_object_save', [self::class, 'saved']);
        add_action('kgp_update_products', [self::class, 'batch']);
        add_action('init', [self::class, 'migrate'], 25);
    }
    public static function opted($product): bool {
        return $product && in_array($product->get_type(), ['simple', 'variation'], true) && $product->get_meta('_kgp_enabled', true, 'edit') === 'yes';
    }
    public static function ids(): array {
        return array_map('absint', get_posts([
            'post_type' => ['product', 'product_variation'], 'post_status' => ['publish', 'private'],
            'posts_per_page' => -1, 'fields' => 'ids', 'orderby' => 'ID', 'order' => 'ASC',
            'meta_key' => '_kgp_enabled', 'meta_value' => 'yes', 'no_found_rows' => true,
        ]));
    }
    public static function simple_field(): void {
        global $product_object;
        if (!$product_object) { return; }
        echo '<input type="hidden" name="kgp_product_present" value="1">';
        woocommerce_wp_checkbox([
            'id' => '_kgp_enabled', 'label' => 'قیمت‌گذاری خودکار با نرخ طلا',
            'value' => $product_object->get_meta('_kgp_enabled', true, 'edit'),
            'wrapper_class' => 'show_if_simple',
            'description' => 'وزن، اجرت، سود و متعلقات همین محصول استفاده می‌شود. اتصال و زمان‌بندی را یک‌بار در تنظیمات عمومی ERP فعال کنید.',
        ]);
    }
    public static function variation_field($loop, $data, $variation): void {
        $product = wc_get_product($variation->ID);
        if (!$product) { return; }
        echo '<input type="hidden" name="kgp_variation_present[' . (int) $loop . ']" value="1">';
        woocommerce_wp_checkbox([
            'id' => 'kgp_enabled_' . (int) $loop, 'name' => 'kgp_enabled[' . (int) $loop . ']',
            'label' => 'قیمت‌گذاری خودکار با نرخ طلا', 'value' => $product->get_meta('_kgp_enabled', true, 'edit'),
            'wrapper_class' => 'form-row form-row-full',
            'description' => 'قیمت این تنوع با وزن و هزینه‌های خودش به‌روز می‌شود.',
        ]);
    }
    public static function save_simple($product): void {
        if (empty($_POST['kgp_product_present']) || !current_user_can('edit_post', $product->get_id())) { return; }
        $product->update_meta_data('_kgp_enabled', $product->get_type() === 'simple' && isset($_POST['_kgp_enabled']) && $_POST['_kgp_enabled'] === 'yes' ? 'yes' : 'no');
    }
    public static function save_variation($product, $loop): void {
        if (empty($_POST['kgp_variation_present'][$loop]) || !current_user_can('edit_post', $product->get_id())) { return; }
        $product->update_meta_data('_kgp_enabled', ($_POST['kgp_enabled'][$loop] ?? '') === 'yes' ? 'yes' : 'no');
    }
    public static function queue(array $ids): void {
        $ids = array_values(array_unique(array_filter(array_map('absint', $ids))));
        if (!$ids || !KGP_Plugin::settings()['enabled']) { return; }
        $args = [$ids];
        if (!wp_next_scheduled('kgp_update_products', $args)) { wp_schedule_single_event(time() + 1, 'kgp_update_products', $args); }
    }
    public static function tick(): void {
        if (!KGP_Plugin::settings()['enabled']) { return; }
        foreach (array_chunk(self::ids(), 20) as $ids) { self::queue($ids); }
    }
    public static function saved($product): void {
        if (!self::$applying && self::opted($product)) { self::queue([$product->get_id()]); }
    }
    public static function batch(array $ids): void {
        if (!KGP_Plugin::settings()['enabled']) { return; }
        // Recheck at execution time: a queued product may have been disabled meanwhile.
        $ids = array_values(array_filter($ids, static function ($id) { return self::opted(wc_get_product($id)); }));
        if ($ids) { KGP_Plugin::run(false, $ids, true); }
    }
    public static function migrate(): void {
        if (get_option('kgp_catalog_v1')) { return; }
        // The previous explicit selection remains opted in; never overwrite a saved opt-out.
        foreach (KGP_Plugin::settings()['rules'] as $row) {
            $id = absint($row['id'] ?? 0); $product = $id ? wc_get_product($id) : false;
            if ($product && in_array($product->get_type(), ['simple', 'variation'], true) && !metadata_exists('post', $id, '_kgp_enabled')) {
                update_post_meta($id, '_kgp_enabled', 'yes');
            }
        }
        update_option('kgp_catalog_v1', 1, false);
    }
}
