<?php
defined('ABSPATH') || exit;
?>
<div class="card card-bordered mb-3"><div class="card-inner"><div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3"><div><span class="overline-title text-primary" data-kgp-source-role><?php echo $key === $s['provider'] ? 'منبع اصلی' : 'منبع جایگزین'; ?></span><h5 class="card-title mb-0"><?php echo esc_html($providers[$key]['label']); ?></h5></div><button class="btn btn-sm btn-outline-primary" type="submit" form="kgp-test-<?php echo esc_attr($key); ?>"><em class="icon ni ni-link"></em><span>آزمایش اتصال ذخیره‌شده</span></button></div>
<p class="text-soft"><?php echo esc_html($source_help[$key] ?? 'تنظیمات منبع افزوده‌شده'); ?></p><div class="row g-4">
<?php
$base = 'sources[' . $key . ']';
if ($key === 'tabangohar') {
    $field($base . '[username]', 'نام کاربری تابان گوهر', $config['username']);
    $secret($key, 'password', 'رمز تابان گوهر');
} elseif ($key === 'brs') {
    $secret($key, 'secret', 'کلید API سرویس BRS');
    $field($base . '[endpoint]', 'نسخه وب‌سرویس BRS', $config['endpoint'], 'Pro مطابق کد ارسالی همکاران؛ نسخه استاندارد برای کلیدهای سازگار با آن.', 'text', ['pro' => 'Gold_Currency_Pro', 'standard' => 'Gold_Currency']);
} elseif ($key === 'custom') {
    $field($base . '[url]', 'آدرس HTTPS سرویس JSON', $config['url'], 'کلید را در قسمت کلید API وارد کنید.', 'url');
    $secret($key, 'secret', 'کلید API سفارشی');
    $field($base . '[header]', 'نام هدر احراز هویت', $config['header']);
    $field($base . '[prefix]', 'پیشوند کلید', $config['prefix'], 'مثلاً Bearer همراه یک فاصله؛ برای X-API-Key معمولاً خالی است.');
} else {
    foreach ($config as $config_key => $config_value) {
        if (in_array($config_key, ['price_path', 'time_path', 'timezone', 'unit'], true)) { continue; }
        if (in_array($config_key, ['password', 'secret'], true)) { $secret($key, $config_key, $config_key); }
        else { $field($base . '[' . $config_key . ']', $config_key, $config_value); }
    }
}
$field($base . '[unit]', 'واحد نرخ خام سرویس', $config['unit'], $key === 'brs' ? 'اگر پاسخ BRS فیلد unit معتبر داشته باشد، واحد همان پاسخ اولویت دارد.' : 'پیش‌فرض تومان است؛ با نمونه نرخ اشتراک خود تطبیق دهید.', 'text', $units);
?>
</div><details class="mt-4"><summary class="text-primary">تنظیمات فیلدها و زمان سرویس</summary><div class="row g-4 mt-1">
<?php
if (isset($config['price_path'])) { $field($base . '[price_path]', 'مسیر فیلد نرخ', $config['price_path'], $key === 'tabangohar' ? 'پیش‌فرض YekGram18؛ تنها در صورت تغییر عنوان فیلد اشتراک خود ویرایش کنید.' : 'فیلد نرخ یک گرم طلای ۱۸ عیار'); }
$field($base . '[time_path]', 'مسیر فیلد زمان', $config['time_path'], $key === 'tabangohar' ? 'TimeRead طبق راهنما زمان خواندن از سرور است؛ زمان معامله بازار را تضمین نمی‌کند.' : 'Unix ثانیه/میلی‌ثانیه یا تاریخ کامل میلادی؛ ساعت بدون تاریخ پذیرفته نمی‌شود.');
if ($key === 'brs') { $field($base . '[time_scope]', 'محل فیلد زمان در BRS', $config['time_scope'], 'متناسب با ساختار پاسخ اشتراک خود تنظیم کنید.', 'text', ['item' => 'داخل رکورد IR_GOLD_18K', 'root' => 'ریشه پاسخ JSON']); }
$field($base . '[timezone]', 'منطقه زمانی تاریخ بدون offset', $config['timezone'], 'زمان Unix یا تاریخ دارای offset مستقل از این انتخاب است.', 'text', $timezones);
?>
</div></details>
<?php $connection = (array) get_option('kgp_connection_' . $key, []); if ($connection): ?>
<div class="alert <?php echo empty($connection['error']) ? 'alert-success' : 'alert-warning'; ?> mt-4 mb-0"><strong>آخرین آزمایش اتصال: </strong><?php echo esc_html(wp_date('Y/m/d H:i:s', $connection['time'])); ?><br>
<?php if (!empty($connection['error'])) { echo esc_html($connection['error']); } elseif (!empty($connection['quote'])) { echo 'نرخ یک گرم در واحد فروشگاه: ' . esc_html(number_format_i18n($connection['quote']['rate'], wc_get_price_decimals())); } ?></div>
<?php endif; ?></div></div>
