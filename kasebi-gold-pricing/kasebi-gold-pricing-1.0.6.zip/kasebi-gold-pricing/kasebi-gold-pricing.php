<?php
/**
 * Plugin Name: Kasebi ERP — قیمت‌گذاری طلا
 * Description: دریافت نرخ از منابع قابل توسعه و قیمت‌گذاری انتخابی محصولات ووکامرس در محیط ERP.
 * Version: 1.0.6
 * Requires PHP: 8.0
 * Requires at least: 6.2
 * Author: Kasebi Addons
 * Text Domain: kasebi-gold-pricing
 */
defined('ABSPATH') || exit;
require_once __DIR__ . '/includes.php';
require_once __DIR__ . '/includes/runtime.php';
add_filter('kerp_ajax_forced_plugins', [KGP_Runtime::class, 'forced_plugins']);
add_action('plugins_loaded', static function () {
    if (defined('KERP_PATH')) { KGP_Runtime::ensure_ajax_dependencies(); }
    if (defined('KERP_PATH') && class_exists('WooCommerce')) {
        KGP_Plugin::boot();
        add_action('wp_enqueue_scripts', static function () {
            if (function_exists('kerp_is_erp_request') && kerp_is_erp_request()) {
                wp_enqueue_script('kgp-settings', plugins_url('assets/settings.js', __FILE__), ['kerp-app'], '1.0.6', true);
            }
        }, PHP_INT_MAX); // Registered after ERP's cleanup and core enqueue callbacks.
    } else {
        add_action('admin_notices', static function () {
            echo '<div class="notice notice-warning"><p>افزونه قیمت طلا به کسبی ERP و ووکامرس فعال نیاز دارد.</p></div>';
        });
    }
}, 30);
register_deactivation_hook(__FILE__, static function () { wp_clear_scheduled_hook('kgp_tick'); wp_unschedule_hook('kgp_update_products'); });
