(function () {
    'use strict';
    function update(root) {
        var primary = root.querySelector('[name="settings[provider]"]');
        var fallback = root.querySelector('[name="settings[fallback]"]');
        if (!primary || !fallback) return;
        var selected = primary.value;
        var backup = fallback.value;
        root.querySelectorAll('[data-kgp-source]').forEach(function (panel) {
            var key = panel.getAttribute('data-kgp-source');
            var visible = key === selected || (backup !== '' && key === backup);
            panel.hidden = !visible;
            panel.style.display = visible ? '' : 'none';
            var label = panel.querySelector('[data-kgp-source-role]');
            if (label) label.textContent = key === selected ? 'منبع اصلی' : 'منبع جایگزین';
            panel.style.order = key === selected ? '0' : '1';
        });
        var panels = root.querySelector('[data-kgp-source-panels]');
        if (panels) {
            panels.style.display = 'flex';
            panels.style.flexDirection = 'column';
        }
    }
    function init(scope) {
        if (scope.nodeType !== 1 && scope.nodeType !== 9) return;
        if (scope.matches && scope.matches('[data-kgp-settings]')) update(scope);
        scope.querySelectorAll('[data-kgp-settings]').forEach(update);
    }
    function changed(target) {
        if (!target || (target.name !== 'settings[provider]' && target.name !== 'settings[fallback]')) return;
        var root = target.closest('[data-kgp-settings]');
        if (root) update(root);
    }
    document.addEventListener('change', function (event) { changed(event.target); });
    // Select2 and ERP controls can emit jQuery-only events instead of native change.
    if (typeof window !== 'undefined' && window.jQuery) {
        window.jQuery(document).on(
            'change.kgpSources select2:select.kgpSources select2:clear.kgpSources',
            '[data-kgp-settings] [name="settings[provider]"], [data-kgp-settings] [name="settings[fallback]"]',
            function () { changed(this); }
        );
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', function () { init(document); });
    else init(document);
    // ERP replaces page HTML during AJAX navigation; no per-page inline scripts are needed.
    new MutationObserver(function (records) {
        records.forEach(function (record) { record.addedNodes.forEach(init); });
    }).observe(document.documentElement, {childList: true, subtree: true});
})();

(function () {
    'use strict';
    var states = new WeakMap();
    function parts(box) {
        return {input: box.querySelector('[data-kgp-product-query]'), id: box.querySelector('[data-kgp-product-id]'), list: box.querySelector('[data-kgp-product-results]'), status: box.querySelector('[data-kgp-product-status]')};
    }
    function state(box) {
        if (!states.has(box)) states.set(box, {version: 0, timer: null, abort: null, items: [], index: -1});
        return states.get(box);
    }
    function close(box) {
        var p = parts(box);
        p.list.hidden = true; p.list.style.display = 'none';
        p.input.setAttribute('aria-expanded', 'false'); p.input.removeAttribute('aria-activedescendant');
    }
    function cancel(box) {
        var s = state(box); s.version++; clearTimeout(s.timer);
        if (s.abort) s.abort.abort();
    }
    function choose(box, item) {
        cancel(box);
        var p = parts(box); p.id.value = String(item.id); p.input.value = item.text;
        p.input.setCustomValidity(''); p.status.textContent = 'محصول انتخاب شد'; close(box); p.input.focus();
    }
    function render(box, items) {
        var p = parts(box), s = state(box); p.list.replaceChildren(); s.items = items; s.index = -1;
        items.forEach(function (item, index) {
            var button = document.createElement('button');
            button.type = 'button'; button.className = 'btn btn-light w-100 text-start rounded-0';
            button.textContent = item.text; button.id = p.list.id + '-' + index;
            button.setAttribute('role', 'option'); button.setAttribute('aria-selected', 'false');
            button.addEventListener('click', function () { choose(box, item); }); p.list.appendChild(button);
        });
        p.status.textContent = items.length ? 'محصول موردنظر را انتخاب کنید' : 'محصولی یافت نشد';
        p.list.hidden = !items.length; p.list.style.display = items.length ? '' : 'none';
        p.input.setAttribute('aria-expanded', items.length ? 'true' : 'false');
    }
    async function search(box, term, version) {
        var p = parts(box), s = state(box); s.abort = new AbortController();
        p.status.textContent = 'در حال جستجو…';
        try {
            var url = new URL(box.getAttribute('data-url'), location.href);
            url.searchParams.set('action', 'kgp_search_products');
            url.searchParams.set('nonce', box.getAttribute('data-nonce')); url.searchParams.set('term', term);
            var response = await fetch(url.toString(), {credentials: 'same-origin', signal: s.abort.signal});
            var data = await response.json();
            if (s.version !== version || !box.isConnected) return;
            if (!response.ok || !data.success || !data.data || !Array.isArray(data.data.results)) throw new Error('search');
            render(box, data.data.results);
        } catch (error) {
            if (s.version !== version || error.name === 'AbortError' || !box.isConnected) return;
            close(box); p.status.textContent = 'جستجو انجام نشد؛ دوباره تلاش کنید.';
        }
    }
    document.addEventListener('input', function (event) {
        if (!event.target.matches('[data-kgp-product-query]')) return;
        var box = event.target.closest('[data-kgp-product-search]'), p = parts(box), s = state(box);
        cancel(box); p.id.value = ''; p.input.setCustomValidity(''); close(box);
        var term = p.input.value.trim();
        if (Array.from(term).length < 2) { p.status.textContent = term ? 'حداقل دو حرف وارد کنید' : ''; return; }
        var version = s.version;
        s.timer = setTimeout(function () { search(box, term, version); }, 250);
    });
    document.addEventListener('click', function (event) {
        var clear = event.target.closest('[data-kgp-product-clear]');
        if (clear) {
            var box = clear.closest('[data-kgp-product-search]'), p = parts(box);
            cancel(box); p.id.value = ''; p.input.value = ''; p.input.setCustomValidity('');
            p.status.textContent = ''; close(box); p.input.focus(); return;
        }
        document.querySelectorAll('[data-kgp-product-search]').forEach(function (box) { if (!box.contains(event.target)) { cancel(box); close(box); } });
    });
    document.addEventListener('keydown', function (event) {
        if (!event.target.matches('[data-kgp-product-query]')) return;
        var box = event.target.closest('[data-kgp-product-search]'), p = parts(box), s = state(box);
        if (event.key === 'Escape' || event.key === 'Tab') { cancel(box); close(box); return; }
        if (p.list.hidden || !s.items.length) return;
        if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
            event.preventDefault();
            s.index = s.index < 0 ? (event.key === 'ArrowDown' ? 0 : s.items.length - 1) : (s.index + (event.key === 'ArrowDown' ? 1 : -1) + s.items.length) % s.items.length;
            Array.from(p.list.children).forEach(function (button, i) {
                button.classList.toggle('active', i === s.index); button.setAttribute('aria-selected', i === s.index ? 'true' : 'false');
            });
            p.input.setAttribute('aria-activedescendant', p.list.children[s.index].id);
            p.list.children[s.index].scrollIntoView({block: 'nearest'});
        } else if (event.key === 'Enter') {
            event.preventDefault(); if (s.index >= 0) choose(box, s.items[s.index]);
        }
    });
    document.addEventListener('submit', function (event) {
        event.target.querySelectorAll('[data-kgp-product-search]').forEach(function (box) {
            var p = parts(box);
            if (p.input.value.trim() !== '' && p.id.value === '') {
                event.preventDefault(); p.input.setCustomValidity('محصول را از نتایج جستجو انتخاب کنید.'); p.input.reportValidity();
            }
        });
    });
})();
