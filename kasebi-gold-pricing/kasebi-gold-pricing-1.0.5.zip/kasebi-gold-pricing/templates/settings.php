<?php
defined('ABSPATH') || exit;
if (!current_user_can('manage_options')) { echo '<div class="alert alert-danger">دسترسی مجاز نیست.</div>'; return; }
$s = KGP_Plugin::settings();
$sections = KGP_Plugin::sections();
$section = (string) ($page_context['definition']['kgp_section'] ?? 'general');
if (!isset($sections[$section])) { $section = 'general'; }
$editable = $section === 'general' || $section === 'products' || isset($s['sources'][$section]);
$providers = KGP_Plugin::providers();
$last = (array) get_option('kgp_last_result', []);
$notice = get_transient('kgp_notice_' . get_current_user_id());
delete_transient('kgp_notice_' . get_current_user_id());
// Native ERP classes; no extra UI framework or public assets.
$field = static function (string $name, string $label, $value, string $help = '', string $type = 'text', array $options = [], string $column = 'col-md-6') {
    $id = 'kgp-' . sanitize_key(str_replace(['[', ']'], ['-', ''], $name));
    echo '<div class="' . esc_attr($column) . '"><div class="form-group"><label class="form-label" for="' . esc_attr($id) . '">' . esc_html($label) . '</label>';
    $parts = explode('[', $name, 2);
    $name = 'settings[' . $parts[0] . ']' . (isset($parts[1]) ? '[' . $parts[1] : '');
    if ($options) {
        echo '<select class="form-select" id="' . esc_attr($id) . '" name="' . esc_attr($name) . '">';
        foreach ($options as $key => $title) { echo '<option value="' . esc_attr($key) . '" ' . selected($value, $key, false) . '>' . esc_html($title) . '</option>'; }
        echo '</select>';
    } else {
        echo '<input class="form-control" dir="ltr" id="' . esc_attr($id) . '" name="' . esc_attr($name) . '" type="' . esc_attr($type) . '" value="' . esc_attr($type === 'password' ? '' : $value) . '"';
        if ($type === 'number') { echo ' min="0" step="any" required'; }
        if ($type === 'password') { echo ' autocomplete="new-password"'; }
        echo '>';
    }
    if ($help !== '') { echo '<span class="form-note">' . esc_html($help) . '</span>'; }
    echo '</div></div>';
};
$secret = static function (string $source, string $key, string $label) use ($field, $s) {
    $exists = $s['sources'][$source][$key] !== '';
    $field('sources[' . $source . '][' . $key . ']', $label, '', $exists ? 'ذخیره شده؛ برای حفظ مقدار، خالی بگذارید.' : 'هنوز وارد نشده است.', 'password');
    echo '<div class="col-12"><label><input type="checkbox" name="settings[sources][' . esc_attr($source) . '][clear_' . esc_attr($key) . ']" value="1"> حذف ' . esc_html($label) . ' ذخیره‌شده</label></div>';
};
$units = ['IRT' => 'تومان', 'IRR' => 'ریال'];
$timezones = ['Asia/Tehran' => 'تهران — Asia/Tehran', 'UTC' => 'UTC'];
$source_help = [
    'tabangohar' => 'نام کاربری و رمز اشتراک خودتان را وارد کنید. اتصال مطابق راهنمای تابان گوهر است؛ نرخ پایه یک گرم طلای ۱۸ عیار است.',
    'brs' => 'نرخ IR_GOLD_18K از وب‌سرویس طلا و ارز دریافت می‌شود. این اتصال از سرویس اونس دلاری کامودیتی استفاده نمی‌کند. دسترسی Pro به نوع کلید شما بستگی دارد.',
    'custom' => 'برای افزودن منبع جدید با پاسخ JSON؛ نرخ باید قیمت یک گرم طلای ۱۸ عیار باشد. مسیرها را با نقطه جدا کنید، مانند data.gold.price.',
];
?>
<div class="nk-block-head nk-block-head-sm"><div class="nk-block-between"><div class="nk-block-head-content">
<h3 class="nk-block-title page-title"><?php echo esc_html($sections[$section]['title']); ?></h3><div class="nk-block-des text-soft"><p>اتصال نرخ طلا به محصولات ووکامرس</p></div></div>
<span class="badge <?php echo $s['enabled'] ? 'bg-success-dim text-success' : 'bg-warning-dim text-warning'; ?>"><?php echo $s['enabled'] ? 'به‌روزرسانی خودکار فعال' : 'به‌روزرسانی خودکار خاموش'; ?></span></div></div>
<?php if ($notice): ?><div class="alert alert-info" role="status"><?php echo esc_html($notice); ?></div><?php endif; ?>
<div class="nk-block">
<?php KERP_Helpers_Template::render_template('app/components/settings/hero.php', [
    'icon' => 'icon ni ni-coins', 'eyebrow' => 'مدیریت نرخ و قیمت', 'title' => 'از نرخ بازار تا قیمت محصول',
    'description' => 'اطلاعات اتصال و قوانین را ذخیره کنید، اتصال را بسنجید و پیش‌نمایش قیمت‌ها را ببینید. فقط محصولات انتخاب‌شده به‌روزرسانی می‌شوند.',
    'stats' => [ ['label' => 'محصولات مشمول', 'value' => count($s['rules'])], ['label' => 'واحد فروشگاه', 'value' => get_woocommerce_currency()], ['label' => 'فاصله اجرا', 'value' => $s['interval'] . ' دقیقه'] ],
]); ?>
</div>
<?php if ($editable): ?>
<form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="nk-block">
<input type="hidden" name="kgp_section" value="<?php echo esc_attr($section); ?>"><input type="hidden" name="action" value="kgp_action"><input type="hidden" name="kgp_command" value="save"><?php wp_nonce_field('kgp_action'); ?>
<?php if ($section === 'general'): ?>
<div class="row g-4" data-kgp-settings>
    <div class="col-lg-6">
        <div class="card card-bordered"><div class="card-inner">
            <h5 class="card-title mb-4">منابع و زمان‌بندی</h5><div class="row g-4">
            <?php
            $names = array_map(static function ($p) { return $p['label']; }, $providers);
            $field('provider', 'منبع اصلی', $s['provider'], 'تنظیمات سرویس انتخابی روبه‌رو نمایش داده می‌شود.', 'text', $names, 'col-12');
            $field('fallback', 'جایگزین هنگام خطای منبع اصلی', $s['fallback'], 'اگر جایگزین انتخاب کنید، تنظیمات آن هم همین‌جا نمایش داده می‌شود.', 'text', ['' => 'بدون جایگزین'] + $names, 'col-12');
            $field('interval', 'فاصله اجرا (دقیقه)', $s['interval'], 'از ۱ تا ۱۴۴۰؛ اجرای WP-Cron به ترافیک سایت وابسته است.', 'number');
            $field('age', 'حداکثر عمر زمان سرویس (دقیقه)', $s['age'], 'نرخ دارای زمان قدیمی یا نامعتبر استفاده نمی‌شود.', 'number');
            $field('jump', 'حداکثر تغییر مجاز قیمت هر محصول (%)', $s['jump'], 'افزایش یا کاهش نسبت به قیمت عادی فعلی؛ از ۰٫۱ تا ۱۰۰۰ درصد.', 'number', [], 'col-12');
            $field('tax_percent', 'مالیات افزوده به اجرت و سود (%)', $s['tax_percent'], 'پیش‌فرض صفر؛ اگر ووکامرس مالیات را محاسبه می‌کند، از محاسبه دوباره جلوگیری کنید.', 'number');
            $field('round_step', 'گام گردکردن قیمت', $s['round_step'], 'در واحد پول فروشگاه؛ پیش‌فرض ۱.', 'number');
            ?>
            </div><label class="d-block mt-4"><input type="checkbox" name="settings[enabled]" value="1" <?php checked($s['enabled']); ?>> به‌روزرسانی خودکار قیمت‌ها فعال باشد</label>
        </div></div>
    </div>
    <div class="col-lg-6" data-kgp-source-panels>
        <?php foreach ($s['sources'] as $key => $config): if (!isset($providers[$key])) { continue; }
            $visible = $key === $s['provider'] || ($s['fallback'] !== '' && $key === $s['fallback']); ?>
            <section data-kgp-source="<?php echo esc_attr($key); ?>" <?php if (!$visible) { echo 'hidden style="display:none"'; } ?>>
                <?php include __DIR__ . '/source-settings.php'; ?>
            </section>
        <?php endforeach; ?>
        <noscript><p class="form-note">پس از انتخاب منبع، تنظیمات را ذخیره کنید تا فرم همان سرویس نمایش داده شود.</p></noscript>
    </div>
</div>
<?php endif; ?>
<?php if ($section === 'products'): ?>
<div class="card card-bordered"><div class="card-inner"><h5 class="card-title">محصولات مشمول</h5>
<p class="text-soft">فقط محصول یا تنوع موردنظر را انتخاب کنید. وزن، اجرت، سود و متعلقات در هر اجرا مستقیماً از اطلاعات خود محصول خوانده می‌شوند؛ آن‌ها را در ERP دوباره وارد نمی‌کنید.</p>
<p class="form-note">برای تغییر وزن و هزینه‌ها، همان صفحه ویرایش محصول یا تنوع را به‌روز کنید. این فهرست فقط مشخص می‌کند کدام محصولات به‌صورت خودکار قیمت‌گذاری شوند.</p>
<div class="table-responsive"><table class="table"><thead><tr><?php foreach (['محصول'] as $title): ?><th scope="col"><?php echo esc_html($title); ?></th><?php endforeach; ?></tr></thead><tbody>
<?php
$rows = $s['rules'];
$blank_count = min(5, 100 - count($rows));
for ($i = 0; $i < $blank_count; $i++) { $rows[] = ['id' => '']; }
$labels = ['id' => 'محصول'];
foreach ($rows as $i => $row): ?><tr>
<?php foreach ($labels as $key => $label): ?><td>
<?php if ($key === 'id'):
    $chosen = $row['id'] !== '' ? wc_get_product((int) $row['id']) : false;
    $chosen_label = $chosen ? KGP_Plugin::product_label($chosen) : ($row['id'] !== '' ? 'محصول دیگر در دسترس نیست؛ دوباره انتخاب کنید' : '');
    $search_id = 'kgp-product-' . $i; ?>
    <div data-kgp-product-search data-url="<?php echo esc_url(admin_url('admin-ajax.php')); ?>" data-nonce="<?php echo esc_attr(wp_create_nonce('kgp_product_search')); ?>" style="min-width:270px">
        <input type="hidden" data-kgp-product-id name="settings[rules][<?php echo (int) $i; ?>][id]" value="<?php echo esc_attr($row['id']); ?>">
        <div class="d-flex gap-1">
            <input type="search" class="form-control" data-kgp-product-query name="settings[rules][<?php echo (int) $i; ?>][query]" value="<?php echo esc_attr($chosen_label); ?>" placeholder="جستجوی نام یا SKU محصول…" aria-label="<?php echo esc_attr('جستجوی محصول ردیف ' . ($i + 1)); ?>" role="combobox" aria-autocomplete="list" aria-expanded="false" aria-controls="<?php echo esc_attr($search_id); ?>" autocomplete="off" maxlength="80">
            <button type="button" class="btn btn-light btn-sm" data-kgp-product-clear aria-label="پاک کردن انتخاب محصول">×</button>
        </div>
        <div id="<?php echo esc_attr($search_id); ?>" data-kgp-product-results role="listbox" class="border rounded mt-1" style="max-height:220px;overflow:auto;display:none" hidden></div>
        <div class="form-note" data-kgp-product-status role="status" aria-live="polite"></div>
    </div>
<?php endif; ?></td><?php endforeach; ?></tr><?php endforeach; ?>
</tbody></table></div><p class="form-note">پاک‌کردن انتخاب و ذخیره، محصول را از این فهرست خارج می‌کند؛ اطلاعات خود محصول تغییری نمی‌کند. حداکثر ۱۰۰ محصول. محصولات دارای قیمت حراج برای جلوگیری از تداخل پذیرفته نمی‌شوند.</p>
</div></div>
<?php endif; ?>
<div class="mt-4">
<input type="hidden" name="settings_complete" value="1">
<button class="btn btn-primary" type="submit"><em class="icon ni ni-save"></em><span>ذخیره تنظیمات</span></button>
</div></form>
<?php endif; ?>
<?php foreach ($s['sources'] as $key => $config): if ($section !== 'general') { continue; } ?>
<form id="kgp-test-<?php echo esc_attr($key); ?>" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="kgp_section" value="<?php echo esc_attr($section); ?>"><input type="hidden" name="action" value="kgp_action"><input type="hidden" name="kgp_command" value="test_<?php echo esc_attr($key); ?>"><?php wp_nonce_field('kgp_action'); ?></form>
<?php endforeach; ?>
<?php if ($section === 'preview'): ?>
<div class="nk-block"><div class="card card-bordered"><div class="card-inner"><h5 class="card-title">پیش‌نمایش و اعمال قیمت</h5><p class="text-soft">هر اجرا از تنظیمات ذخیره‌شده، نرخ تازه دریافت می‌کند. پیش‌نمایش محصولی را تغییر نمی‌دهد. اعمال دستی حتی با زمان‌بندی خاموش در دسترس است.</p><div class="d-flex flex-wrap gap-2">
<?php foreach (['preview' => 'دریافت نرخ و پیش‌نمایش', 'apply' => 'دریافت نرخ و اعمال روی محصولات'] as $command => $label): ?>
<form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="kgp_section" value="<?php echo esc_attr($section); ?>"><input type="hidden" name="action" value="kgp_action"><input type="hidden" name="kgp_command" value="<?php echo esc_attr($command); ?>"><?php wp_nonce_field('kgp_action'); ?><button type="submit" class="btn <?php echo $command === 'apply' ? 'btn-primary' : 'btn-light'; ?>"><?php echo esc_html($label); ?></button></form>
<?php endforeach; ?></div>
<?php if ($last): ?><hr><h6>نتیجه آخرین اجرا: <?php echo !empty($last['preview']) ? 'پیش‌نمایش' : 'اعمال قیمت'; ?></h6><p class="text-soft"><?php echo esc_html(wp_date('Y/m/d H:i:s', $last['time'])); ?> — تعداد اعمال‌شده: <?php echo (int) ($last['count'] ?? 0); ?></p>
<?php if (!empty($last['error'])): ?><div class="alert alert-danger"><?php echo esc_html($last['error']); ?></div><?php endif; ?>
<?php if (!empty($last['quote'])): $quote = $last['quote']; ?><p>منبع: <strong><?php echo esc_html($providers[$quote['provider']]['label'] ?? $quote['provider']); ?></strong> — نرخ یک گرم در واحد فروشگاه: <strong><?php echo esc_html(number_format_i18n($quote['rate'], wc_get_price_decimals())); ?></strong><br>زمان اعلام‌شده سرویس: <?php echo esc_html(wp_date('Y/m/d H:i:s', $quote['time'])); ?></p>
<?php if (!empty($quote['fallback_used'])): ?><div class="alert alert-warning">از منبع جایگزین استفاده شد: <?php echo esc_html(implode(' | ', $quote['failures'])); ?></div><?php endif; ?>
<?php endif; ?>
<div class="table-responsive"><table class="table"><thead><tr><th>محصول</th><th>وزن (گرم)</th><th>اجرت %</th><th>سود %</th><th>متعلقات در واحد فروشگاه</th><th>قیمت قبلی</th><th>قیمت محاسبه‌شده</th></tr></thead><tbody><?php foreach (($last['rows'] ?? []) as $row): ?><tr><td><?php echo esc_html($row['name']); ?></td><td><?php echo esc_html(number_format_i18n($row['inputs']['weight'] ?? 0, 3)); ?></td><td><?php echo esc_html($row['inputs']['making_percent'] ?? '—'); ?></td><td><?php echo esc_html($row['inputs']['profit'] ?? '—'); ?></td><td><?php echo esc_html(number_format_i18n($row['inputs']['accessories'] ?? 0, wc_get_price_decimals())); ?></td><td><?php echo esc_html(number_format_i18n($row['old'], wc_get_price_decimals())); ?></td><td><?php echo esc_html(number_format_i18n($row['new'], wc_get_price_decimals())); ?></td></tr><?php endforeach; ?></tbody></table></div>
<?php endif; ?></div></div></div>
<?php endif; ?>
<?php if ($section === 'logs'): ?>
<div class="nk-block"><div class="card card-bordered"><div class="card-inner"><h5 class="card-title">گزارش اجراها</h5><div class="table-responsive"><table class="table"><thead><tr><th>زمان</th><th>عملیات</th><th>اعمال‌شده</th><th>منبع</th><th>وضعیت</th></tr></thead><tbody><?php foreach ((array) get_option('kgp_logs', []) as $log): ?><tr><td><?php echo esc_html(wp_date('Y/m/d H:i:s', $log['time'])); ?></td><td><?php echo $log['preview'] ? 'پیش‌نمایش' : 'اعمال'; ?></td><td><?php echo (int) $log['count']; ?></td><td><?php echo esc_html($providers[$log['provider'] ?? '']['label'] ?? '—'); ?></td><td><?php echo esc_html($log['error'] ?: (!empty($log['fallback']) ? 'موفق با منبع جایگزین' : 'موفق')); ?></td></tr><?php endforeach; ?></tbody></table></div>
<details class="mt-3"><summary class="text-soft">رفع قفل اجرای قطع‌شده</summary><p class="form-note mt-2">فقط قفل قدیمی‌تر از ۳۰ دقیقه آزاد می‌شود؛ ابتدا از متوقف‌بودن اجرای قبلی مطمئن شوید.</p><form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>"><input type="hidden" name="kgp_section" value="<?php echo esc_attr($section); ?>"><input type="hidden" name="action" value="kgp_action"><input type="hidden" name="kgp_command" value="unlock"><?php wp_nonce_field('kgp_action'); ?><button class="btn btn-light" type="submit">آزادسازی قفل قدیمی</button></form></details>
</div></div></div>

<?php endif; ?>
