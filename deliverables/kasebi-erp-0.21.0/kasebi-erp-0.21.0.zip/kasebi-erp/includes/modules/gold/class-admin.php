<?php
defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Gold_Admin {
    public static string $return_url = '';
    public static function start_form( string $operation ): void {
        echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
        wp_nonce_field( 'kerp_gold' );
        if ( $operation !== 'request' ) {
            $return = self::$return_url ?: admin_url( 'admin.php?page=kerp-gold' );
            if ( isset( $_GET['tab'] ) && is_string( $_GET['tab'] ) ) { $return = add_query_arg( 'tab', sanitize_key( $_GET['tab'] ), $return ); }
            echo '<input type="hidden" name="return_url" value="' . esc_url( $return ) . '">';
        }
        echo '<input type="hidden" name="action" value="kerp_gold"><input type="hidden" name="operation" value="' . esc_attr( $operation ) . '">';
    }

    public static function field( string $name, string $label, $value = '', string $type = 'text', bool $required = false ): void {
        echo '<p><label>' . esc_html( $label ) . '<br><input class="regular-text" type="' . esc_attr( $type ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '" ' . ( $required ? 'required' : '' ) . '></label></p>';
    }

    public static function submit( string $label, string $type = 'primary', string $name = 'submit', bool $wrap = true ): void {
        if ( $wrap ) { echo '<p class="submit">'; }
        echo '<button type="submit" name="' . esc_attr( $name ) . '" class="button button-' . esc_attr( $type ) . '">' . esc_html( $label ) . '</button>';
        if ( $wrap ) { echo '</p>'; }
    }

    public static function messages(): void {
        foreach ( [ 'error', 'success' ] as $kind ) {
            $key = 'kerp_gold_' . $kind . '_' . get_current_user_id();
            $message = get_transient( $key );
            if ( $message ) { echo '<div role="status" class="notice notice-' . esc_attr( $kind ) . '"><p>' . esc_html( $message ) . '</p></div>'; delete_transient( $key ); }
        }
    }

    public static function save_settings(): void {
        $old = KERP_Modules_Gold_Module::settings();
        $s = $old;
        foreach ( [ 'cash', 'physical', 'jewelry' ] as $kind ) { $s[ 'allow_' . $kind ] = KERP_Modules_Gold_Module::input( 'allow_' . $kind ) === '1' ? 1 : 0; }
        $s['physical_min'] = KERP_Modules_Gold_Math::grams( KERP_Modules_Gold_Math::units( KERP_Modules_Gold_Module::input( 'physical_min' ) ) );
        foreach ( [ 'rate' ] as $key ) {
            $raw = KERP_Modules_Gold_Module::input( $key );
            if ( ! preg_match( '/^\d{1,14}(?:\.\d{1,6})?$/D', $raw ) ) { throw new InvalidArgumentException( 'نرخ پایه باید عدد نامنفی با ممیز نقطه باشد.' ); }
            $s[ $key ] = $raw;
        }
        $premium = KERP_Modules_Gold_Module::input( 'premium' );
        if ( ! preg_match( '/^[+-]?\d{1,6}(?:\.\d{1,6})?$/D', $premium ) || abs( (float) $premium ) > 200000 ) { throw new InvalidArgumentException( 'اختلاف نرخ باید از منفی ۲۰۰۰۰۰ تا مثبت ۲۰۰۰۰۰ باشد.' ); }
        $s['premium'] = $premium;
        $basis = KERP_Modules_Gold_Module::input( 'quote_basis' );
        if ( ! in_array( $basis, [ 'gram', 'mesghal' ], true ) ) { throw new InvalidArgumentException( 'مبنای نرخ نامعتبر است.' ); }
        $factor = KERP_Modules_Gold_Module::input( 'mesghal_factor' );
        KERP_Modules_Gold_Math::units( $factor );
        $s['quote_basis'] = $basis; $s['mesghal_factor'] = $factor;
        foreach ( [ 'max_age' => [30,86400], 'plus_days' => [1,3650], 'plus_product' => [0,PHP_INT_MAX] ] as $key => $bounds ) {
            $raw = KERP_Modules_Gold_Module::input( $key );
            if ( ! ctype_digit( $raw ) || (float) $raw < $bounds[0] || (float) $raw > $bounds[1] ) { throw new InvalidArgumentException( 'محدوده زمان یا شناسه محصول نامعتبر است.' ); }
            $s[ $key ] = (int) $raw;
        }
        if ( $s['plus_product'] ) {
            $product = wc_get_product( $s['plus_product'] );
            if ( ! $product || ! $product->is_type( 'simple' ) || ! $product->is_virtual() ) { throw new InvalidArgumentException( 'محصول اشتراک باید ساده و مجازی باشد.' ); }
        }
        $s['landing'] = KERP_Modules_Gold_Module::input( 'landing' );
        foreach ( KERP_Modules_Gold_Module::links() as $key => $label ) {
            $raw = KERP_Modules_Gold_Module::input( 'link_' . $key );
            $url = esc_url_raw( $raw, [ 'http', 'https' ] );
            if ( $raw !== '' && ( ! $url || ! filter_var( $url, FILTER_VALIDATE_URL ) ) ) { throw new InvalidArgumentException( 'نشانی خدمات باید کامل و معتبر باشد.' ); }
            $s[ 'link_' . $key ] = $url;
        }
        if ( $old['rate'] !== $s['rate'] || KERP_Modules_Gold_Module::input( 'refresh_rate' ) === '1' ) { $s['rate_at'] = time(); }
        update_option( 'kerp_gold_settings', $s, false );
    }

    public static function render(): void {
        if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'دسترسی کافی ندارید.' ); }
        $tab = isset( $_GET['tab'] ) && is_string( $_GET['tab'] ) ? sanitize_key( $_GET['tab'] ) : 'requests';
        echo '<div class="wrap kerp-gold-backoffice" dir="rtl"><h1>بنکداری طلا</h1>';
        self::messages();
        self::summary();
        echo '<p>تمام وزن‌ها معادل عیار ۷۵۰ هستند. خرید جایگزین، دریافت وجه و تحویل در این نسخه با تأیید دستی انجام می‌شوند.</p><nav class="nav-tab-wrapper">';
        foreach ( [ 'inventory' => 'کالا و انبار', 'books' => 'طرف‌حساب و بانک', 'transfers' => 'حواله و تبادل', 'sales' => 'فروش حضوری و سوشال', 'reports' => 'گزارشات', 'packaging' => 'بسته‌بندی', 'requests' => 'درخواست‌ها', 'replacement' => 'خرید جایگزین', 'ledger' => 'دفتر طلایی', 'events' => 'اعلان‌ها', 'settings' => 'تنظیمات و پلاس' ] as $key => $label ) {
            echo '<a class="nav-tab ' . ( $key === $tab ? 'nav-tab-active' : '' ) . '" href="' . esc_url( self::$return_url !== '' ? add_query_arg( 'tab', $key, self::$return_url ) : admin_url( 'admin.php?page=kerp-gold&tab=' . $key ) ) . '">' . esc_html( $label ) . '</a>';
        }
        echo '</nav>';
        if ( in_array( $tab, [ 'inventory', 'books', 'transfers', 'sales', 'reports', 'packaging' ], true ) ) { KERP_Modules_Gold_Backoffice::render( $tab ); }
        elseif ( $tab === 'settings' ) { self::settings(); }
        elseif ( $tab === 'events' ) {
            echo '<h2>اعلان‌ها</h2><p>رویدادها با هشتگ مستقل ثبت می‌شوند. اتصال ربات: ' . ( KERP_Modules_Gold_Notifications::configured() ? 'تنظیم شده' : 'تنظیم نشده؛ راهنمای نصب را ببینید' ) . '</p>';
            self::table( 'events', [ 'id' => 'شماره', 'event' => 'رویداد', 'reference' => 'پیگیری', 'hashtag' => 'هشتگ', 'delivery' => 'ارسال', 'attempts' => 'تعداد تلاش', 'created_at' => 'زمان هماهنگ جهانی' ], function ( $row ) {
                if ( $row->delivery === 'sent' || (int) $row->attempts >= 5 ) { return; }
                self::start_form( 'retry_event' );
                echo '<input type="hidden" name="id" value="' . (int) $row->id . '">';
                self::submit( 'در صف ارسال', 'secondary', 'submit', false ); echo '</form>';
            } );
        }
        elseif ( $tab === 'ledger' ) { self::ledger(); }
        elseif ( $tab === 'replacement' ) { self::replacement(); }
        else { self::requests(); }
        echo '</div>';
    }

    private static function summary(): void {
        global $wpdb;
        $free = (int) $wpdb->get_var( 'SELECT COALESCE(SUM(balance),0) FROM ' . KERP_Modules_Gold_Store::table( 'accounts' ) );
        $reserved = (int) $wpdb->get_var( 'SELECT COALESCE(SUM(units),0) FROM ' . KERP_Modules_Gold_Store::table( 'requests' ) . " WHERE status='pending' AND kind<>'buy'" );
        $replacement = (int) $wpdb->get_var( 'SELECT COALESCE(SUM(units),0) FROM ' . KERP_Modules_Gold_Store::table( 'replacement' ) . " WHERE status='pending'" );
        echo '<p><strong>موجودی آزاد کاربران:</strong> ' . esc_html( KERP_Modules_Gold_Math::grams( $free ) ) . ' گرم · <strong>رزرو برداشت:</strong> ' . esc_html( KERP_Modules_Gold_Math::grams( $reserved ) ) . ' گرم · <strong>خرید جایگزین در انتظار:</strong> ' . esc_html( KERP_Modules_Gold_Math::grams( $replacement ) ) . ' گرم</p>';
    }

    private static function settings(): void {
        $s = KERP_Modules_Gold_Module::settings();
        self::start_form( 'settings' );
        echo '<h2>سیاست کیف طلایی</h2>';
        foreach ( [ 'cash' => 'تسویه نقدی', 'physical' => 'تحویل فیزیکی', 'jewelry' => 'مصرف برای طلای زینتی' ] as $key => $label ) {
            echo '<p><label><input type="checkbox" name="allow_' . esc_attr( $key ) . '" value="1" ' . checked( $s[ 'allow_' . $key ], 1, false ) . '> ' . esc_html( $label ) . '</label></p>';
        }
        self::field( 'physical_min', 'حداقل تحویل فیزیکی به گرم ۷۵۰', $s['physical_min'], 'text', true );
        echo '<h2>نرخ طلا</h2><p>واحد قیمت همان واحد پول فروشگاه است: ' . esc_html( get_woocommerce_currency() ) . '. نرخ دستی صرفاً برای نمایش برآورد است و معامله خودکار ایجاد نمی‌کند.</p>';
        echo '<p><label>مبنای نرخ <select name="quote_basis"><option value="gram" ' . selected( $s['quote_basis'], 'gram', false ) . '>گرم عیار ۷۵۰</option><option value="mesghal" ' . selected( $s['quote_basis'], 'mesghal', false ) . '>مظنه</option></select></label></p>';
        self::field( 'mesghal_factor', 'ضریب تبدیل مظنه به گرم ۷۵۰؛ پیش‌فرض 4.3318 و قابل تنظیم', $s['mesghal_factor'], 'text', true );
        self::field( 'rate', 'نرخ پایه با مبنای انتخاب‌شده', $s['rate'], 'text', true );
        self::field( 'premium', 'اختلاف قیمت هر گرم؛ بین منفی و مثبت ۲۰۰۰۰۰', $s['premium'], 'text', true );
        self::field( 'max_age', 'اعتبار نرخ به ثانیه؛ بین ۳۰ و ۸۶۴۰۰', $s['max_age'], 'number', true );
        echo '<p><label><input type="checkbox" name="refresh_rate" value="1"> نرخ بالا را همین الان مجدداً بررسی و تأیید کردم</label></p>';
        echo '<h2>اشتراک و پنل پلاس</h2><p>خرید محصول ساده و مجازی در تسویه‌حساب کلاسیک، اشتراک را فعال می‌کند. مدت از تاریخ پرداخت محاسبه می‌شود؛ خریدهای تکراری روی هم جمع نمی‌شوند.</p>';
        self::field( 'plus_product', 'شناسه محصول اشتراک؛ صفر یعنی غیرفعال', $s['plus_product'], 'number', true );
        self::field( 'plus_days', 'مدت اعتبار به روز', $s['plus_days'], 'number', true );
        self::field( 'landing', 'توضیحات صفحه معرفی', $s['landing'] );
        foreach ( KERP_Modules_Gold_Module::links() as $key => $label ) { self::field( 'link_' . $key, 'نشانی ' . $label, $s[ 'link_' . $key ], 'url' ); }
        self::submit( 'ذخیره تنظیمات' ); echo '</form>';
        echo '<p>برای ساخت صفحه معرفی و پنل پلاس از کد کوتاه <code>[kerp_plus]</code> و برای کیف طلایی از <code>[kerp_gold_wallet]</code> استفاده کنید. دسته‌ها و زیردسته‌های زیورآلات در بخش دسته‌بندی محصولات ووکامرس قابل تعریف هستند.</p>';
    }

    private static function ledger(): void {
        echo '<h2>ثبت دستی تراکنش</h2><p>ثبت افزایش موجودی فقط پس از دریافت وجه یا بررسی سند؛ تمام اصلاحات با تراکنش جدید ثبت می‌شوند.</p>';
        self::start_form( 'adjust' );
        self::field( 'user_id', 'شناسه کاربر', '', 'number', true );
        echo '<label>نوع تراکنش <select name="direction"><option value="credit">افزایش</option><option value="debit">کاهش</option></select></label>';
        self::field( 'grams', 'وزن به گرم ۷۵۰', '', 'text', true );
        self::field( 'reference', 'شناسه یکتای سند، حداکثر ۹۳ نویسه', '', 'text', true );
        self::field( 'note', 'شرح تراکنش', '', 'text', true );
        self::submit( 'ثبت تراکنش' ); echo '</form>';
        self::table( 'ledger', [ 'id' => 'شماره', 'user_id' => 'کاربر', 'delta' => 'تغییر وزن', 'balance' => 'موجودی پس از ثبت', 'reference' => 'سند', 'note' => 'شرح', 'actor_id' => 'ثبت‌کننده', 'created_at' => 'زمان هماهنگ جهانی' ] );
    }

    private static function requests(): void {
        echo '<h2>بررسی درخواست‌ها</h2><p>تأیید خرید به معنی دریافت و بررسی وجه است. تأیید برداشت به معنی انجام تسویه یا تحویل است؛ رد برداشت، وزن رزروشده را آزاد می‌کند. سیاست جدید روی درخواست‌های قبلی اثر نمی‌گذارد.</p>';
        self::table( 'requests', [ 'id' => 'شماره', 'user_id' => 'کاربر', 'kind' => 'نوع', 'units' => 'وزن', 'status' => 'وضعیت', 'note' => 'توضیح', 'resolution' => 'نتیجه' ], function ( $row ) {
            if ( $row->status !== 'pending' ) { return; }
            self::start_form( 'resolve' );
            echo '<input type="hidden" name="id" value="' . (int) $row->id . '"><select name="status"><option value="completed">انجام شد</option><option value="rejected">رد شد</option></select>';
            self::field( 'reference', 'شماره سند و شرح نتیجه؛ برای خرید، نرخ و مبلغ دریافت‌شده را درج کنید', '', 'text', true );
            self::submit( 'ثبت نتیجه', 'secondary', 'submit', false ); echo '</form>';
        } );
    }

    private static function replacement(): void {
        echo '<h2>صف خرید طلای جایگزین</h2><p>وزن از اقلام سفارش پرداخت‌شده ثبت می‌شود. برای مثال وزن ۱ گرم و اجرت معادل ۰٫۳ گرم، در محصول برابر 1.300000 ثبت می‌شود. خرید واقعی از فروشنده را دستی انجام دهید و سپس شماره معامله را وارد کنید. سفارش بازپرداخت‌شده به بررسی دستی نیاز دارد.</p>';
        self::table( 'replacement', [ 'id' => 'شماره', 'order_id' => 'سفارش', 'units' => 'گرم موردنیاز', 'status' => 'وضعیت', 'reference' => 'معامله فروشنده', 'note' => 'توضیح' ], function ( $row ) {
            if ( $row->status !== 'pending' ) { return; }
            self::start_form( 'replacement' );
            echo '<input type="hidden" name="id" value="' . (int) $row->id . '">';
            self::field( 'reference', 'شماره معامله انجام‌شده', '', 'text', true );
            self::submit( 'ثبت خرید انجام‌شده', 'secondary', 'submit', false ); echo '</form>';
        } );
        echo '<h3>تلاش دوباره پس از خطای ثبت عملیات سفارش</h3>';
        self::start_form( 'retry_order' ); self::field( 'order_id', 'شناسه سفارش پرداخت‌شده', '', 'number', true ); self::submit( 'بررسی دوباره سفارش' ); echo '</form>';
    }

    public static function label( string $value ): string {
        return [ 'buy' => 'خرید', 'cash' => 'تسویه نقدی', 'physical' => 'تحویل فیزیکی', 'jewelry' => 'مصرف زیورآلات', 'pending' => 'در انتظار بررسی', 'completed' => 'انجام شد', 'rejected' => 'رد شد', 'review' => 'نیازمند بررسی', 'review_bought' => 'خرید شده؛ نیازمند بررسی', 'local' => 'داخلی', 'queued' => 'در صف ارسال', 'sending' => 'در حال ارسال', 'sent' => 'ارسال شد', 'failed' => 'ارسال ناموفق', 'wallet_adjusted' => 'تغییر موجودی طلایی', 'request_pending' => 'درخواست جدید', 'request_completed' => 'درخواست انجام شد', 'request_rejected' => 'درخواست رد شد', 'replacement_pending' => 'خرید جایگزین لازم است', 'replacement_completed' => 'خرید جایگزین انجام شد', 'replacement_review' => 'خرید جایگزین نیازمند بررسی', 'plus_activated' => 'اشتراک پلاس فعال شد', 'paid_error' => 'خطای عملیات سفارش', 'business_posted' => 'سند بنکداری ثبت شد', 'offline_sale' => 'فروش حضوری یا سوشال ثبت شد', 'inventory_status' => 'وضعیت کالا تغییر کرد', 'packaging_pending' => 'سفارش در صف بسته‌بندی', 'packaging_packing' => 'شروع بسته‌بندی', 'packaging_packed' => 'بسته‌بندی انجام شد', 'packaging_shipped' => 'مرسوله ارسال شد', 'packaging_error' => 'خطای بسته‌بندی', 'packaging_review' => 'بسته‌بندی نیازمند بررسی' ][$value] ?? $value;
    }

    private static function table( string $name, array $columns, ?callable $action = null ): void {
        $page = max( 1, isset( $_GET['gold_page'] ) ? (int) $_GET['gold_page'] : 1 );
        $rows = KERP_Modules_Gold_Store::rows( $name, 0, $page );
        echo '<div style="overflow:auto"><table class="widefat striped"><thead><tr>';
        foreach ( $columns as $label ) { echo '<th>' . esc_html( $label ) . '</th>'; }
        if ( $action ) { echo '<th>عملیات</th>'; }
        echo '</tr></thead><tbody>';
        foreach ( $rows as $row ) {
            echo '<tr>';
            foreach ( $columns as $key => $label ) {
                $value = $row->$key;
                if ( in_array( $key, [ 'units', 'delta', 'balance' ], true ) ) { $value = KERP_Modules_Gold_Math::grams( (int) $value ); }
                if ( in_array( $key, [ 'kind', 'status', 'delivery', 'event' ], true ) ) { $value = self::label( (string) $value ); }
                echo '<td' . ( in_array( $key, [ 'units', 'delta', 'balance' ], true ) ? ' dir="ltr"' : '' ) . '>' . esc_html( $value ) . '</td>';
            }
            if ( $action ) { echo '<td>'; $action( $row ); echo '</td>'; }
            echo '</tr>';
        }
        if ( ! $rows ) { echo '<tr><td colspan="10">هنوز موردی ثبت نشده است.</td></tr>'; }
        echo '</tbody></table></div><p>';
        if ( $page > 1 ) { echo '<a href="' . esc_url( add_query_arg( 'gold_page', $page - 1 ) ) . '">صفحه قبل</a> '; }
        if ( count( $rows ) === 25 ) { echo '<a href="' . esc_url( add_query_arg( 'gold_page', $page + 1 ) ) . '">صفحه بعد</a>'; }
        echo '</p>';
    }
}
