<?php
defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Gold_Backoffice {
    private static function input( string $key ): string { return KERP_Modules_Gold_Module::input( $key ); }
    private static function select( string $name, string $label, array $choices ): void {
        echo '<p><label>' . esc_html( $label ) . '<br><select name="' . esc_attr( $name ) . '">';
        foreach ( $choices as $key => $title ) { echo '<option value="' . esc_attr( $key ) . '">' . esc_html( $title ) . '</option>'; }
        echo '</select></label></p>';
    }
    private static function books_options(): array {
        $out = []; foreach ( KERP_Modules_Gold_Business::books() as $book ) { $out[ $book->id ] = '#' . $book->id . ' ' . $book->label; } return $out;
    }
    private static function field( string $name, string $label, $value = '', string $type = 'text', bool $required = true ): void { KERP_Modules_Gold_Admin::field( $name, $label, $value, $type, $required ); }
    private static function finish( string $label ): void { KERP_Modules_Gold_Admin::submit( $label ); echo '</form>'; }
    private static function table( array $headers, array $rows ): void {
        echo '<div style="overflow:auto"><table class="widefat striped"><thead><tr>';
        foreach ( $headers as $title ) { echo '<th>' . esc_html( $title ) . '</th>'; }
        echo '</tr></thead><tbody>';
        foreach ( $rows as $row ) { echo '<tr>'; foreach ( $row as $cell ) { $numeric = preg_match( '/^-?\d+(?:\.\d+)? (?:گرم|[A-Z])/', (string) $cell ); echo '<td>' . ( $numeric ? '<bdi dir="ltr">' : '' ) . esc_html( (string) $cell ) . ( $numeric ? '</bdi>' : '' ) . '</td>'; } echo '</tr>'; }
        if ( ! $rows ) { echo '<tr><td colspan="20">موردی ثبت نشده است.</td></tr>'; }
        echo '</tbody></table></div>';
    }
    private static function page(): int { return max( 1, isset( $_GET['gold_page'] ) ? (int) $_GET['gold_page'] : 1 ); }
    private static function pages( int $count ): void {
        $page = self::page(); echo '<p>';
        if ( $page > 1 ) { echo '<a href="' . esc_url( add_query_arg( 'gold_page', $page - 1 ) ) . '">صفحه قبل</a> '; }
        if ( $count === 25 ) { echo '<a href="' . esc_url( add_query_arg( 'gold_page', $page + 1 ) ) . '">صفحه بعد</a>'; } echo '</p>';
    }
    public static function render( string $tab ): void {
        if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'دسترسی کافی ندارید.' ); }
        if ( $tab === 'books' ) { self::books(); }
        elseif ( $tab === 'transfers' ) { self::transfers(); }
        elseif ( $tab === 'sales' ) { self::sales(); }
        elseif ( $tab === 'reports' ) { self::reports(); }
        elseif ( $tab === 'packaging' ) { self::packaging(); }
        elseif ( $tab === 'inventory' ) { self::inventory(); }
    }
    private static function books(): void {
        echo '<h2>طرف‌حساب، بانک، درگاه و صندوق</h2><p>کد یکتا مانع ثبت دوباره حساب می‌شود. حساب‌های طرف‌حساب می‌توانند مانده منفی داشته باشند؛ بانک، صندوق و دارایی طلایی نمی‌توانند بیش از موجودی پرداخت کنند. موجودی افتتاحیه را با یک سند انتقال از حساب افتتاحیه ثبت کنید.</p>';
        KERP_Modules_Gold_Admin::start_form( 'book' );
        self::field( 'code', 'کد یکتا؛ حروف لاتین، رقم یا خط تیره', wp_generate_uuid4() ); self::field( 'label', 'نام حساب یا طرف‌حساب' );
        self::select( 'kind', 'نوع حساب', KERP_Modules_Gold_Business::kinds() ); self::select( 'party_type', 'نوع طرف‌حساب', KERP_Modules_Gold_Business::parties() );
        self::field( 'user_id', 'شناسه کاربر مرتبط؛ اختیاری', '', 'number', false ); self::field( 'details', 'جزئیات بانک، شماره حساب یا مشخصات طرف‌حساب', '', 'text', false );
        self::finish( 'ثبت حساب' );
        $rows = [];
        foreach ( KERP_Modules_Gold_Business::books() as $book ) {
            $rows[] = [ $book->id, $book->label, KERP_Modules_Gold_Business::kinds()[ $book->kind ] ?? $book->kind, KERP_Modules_Gold_Business::parties()[ $book->party_type ] ?? '', $book->user_id ?: '', $book->details, KERP_Modules_Gold_Business::amount_label( 'gold', KERP_Modules_Gold_Business::balance( (int) $book->id, 'gold' ) ), KERP_Modules_Gold_Business::amount_label( KERP_Modules_Gold_Business::money_asset(), KERP_Modules_Gold_Business::balance( (int) $book->id, KERP_Modules_Gold_Business::money_asset() ) ) ];
        }
        self::table( [ 'شناسه', 'نام', 'نوع حساب', 'نوع طرف‌حساب', 'کاربر', 'مشخصات', 'مانده طلا', 'مانده وجه در واحد فعلی' ], $rows );
    }
    public static function transfer(): void {
        $kind = self::input( 'asset' );
        if ( ! in_array( $kind, [ 'gold', 'money', 'exchange' ], true ) ) { throw new InvalidArgumentException( 'نوع انتقال نامعتبر است.' ); }
        $from = (int) self::input( 'from_book' ); $to = (int) self::input( 'to_book' );
        $legs = [];
        if ( $kind === 'gold' || $kind === 'exchange' ) { $legs[] = [ 'from' => $from, 'to' => $to, 'asset' => 'gold', 'amount' => KERP_Modules_Gold_Math::units( self::input( 'grams' ) ) ]; }
        if ( $kind === 'money' || $kind === 'exchange' ) { $legs[] = [ 'from' => $kind === 'exchange' ? $to : $from, 'to' => $kind === 'exchange' ? $from : $to, 'asset' => KERP_Modules_Gold_Business::money_asset(), 'amount' => KERP_Modules_Gold_Math::money( self::input( 'money' ) ) ]; }
        KERP_Modules_Gold_Business::post( self::input( 'reference' ), self::input( 'note' ), $legs );
    }
    private static function transfers(): void {
        global $wpdb;
        echo '<h2>حواله طلایی و ریالی، تبادل و اصلاح سند</h2><p>در تبادل، طلا از مبدأ به مقصد و وجه در جهت عکس منتقل می‌شود. هر دو ردیف یکجا ثبت می‌شوند. در انتقال ساده فقط مقدار مربوط را وارد کنید. هیچ‌کدام موجودی کیف طلایی کاربر را تغییر نمی‌دهند.</p>';
        KERP_Modules_Gold_Admin::start_form( 'transfer' );
        $options = self::books_options(); self::select( 'from_book', 'مبدأ', $options ); self::select( 'to_book', 'مقصد', $options );
        self::select( 'asset', 'نوع سند', [ 'gold' => 'حواله طلایی', 'money' => 'حواله وجه', 'exchange' => 'تبادل طلا با وجه' ] );
        self::field( 'grams', 'گرم معادل ۷۵۰', '', 'text', false ); self::field( 'money', 'مبلغ؛ واحد پول فروشگاه: ' . get_woocommerce_currency(), '', 'text', false );
        self::field( 'reference', 'شناسه یکتای سند', wp_generate_uuid4() ); self::field( 'note', 'شرح و شماره رسید' ); self::finish( 'ثبت سند' );
        $p = KERP_Modules_Gold_Store::table( 'postings' ); $d = KERP_Modules_Gold_Store::table( 'documents' ); $b = KERP_Modules_Gold_Store::table( 'books' );
        $rows = $wpdb->get_results( $wpdb->prepare( "SELECT p.*,d.reference,d.note,d.created_at,d.reverses_id,src.label src,dst.label dst FROM $p p JOIN $d d ON d.id=p.document_id JOIN $b src ON src.id=p.from_book JOIN $b dst ON dst.id=p.to_book ORDER BY p.id DESC LIMIT 25 OFFSET %d", ( self::page() - 1 ) * 25 ) );
        $cells = []; foreach ( $rows as $row ) { $cells[] = [ $row->document_id, $row->src, $row->dst, KERP_Modules_Gold_Business::amount_label( $row->asset, (int) $row->amount ), $row->reference, $row->note, $row->reverses_id ?: '', wp_date( 'Y-m-d H:i', strtotime( $row->created_at . ' UTC' ) ) ]; }
        self::table( [ 'سند', 'مبدأ', 'مقصد', 'مقدار', 'پیگیری', 'شرح', 'معکوس سند', 'زمان محلی سایت' ], $cells ); self::pages( count( $rows ) );
        echo '<h3>معکوس کردن سند اشتباه</h3><p>سند اصلی حذف نمی‌شود. مانده کافی برای انتقال معکوس لازم است و هر سند فقط یک بار معکوس می‌شود.</p>';
        KERP_Modules_Gold_Admin::start_form( 'reverse_document' ); self::field( 'id', 'شماره سند اصلی', '', 'number' ); self::field( 'reference', 'شناسه یکتای سند اصلاحی', wp_generate_uuid4() ); self::field( 'note', 'دلیل اصلاح' ); self::finish( 'ثبت سند معکوس' );
    }
    public static function sale(): void {
        $raw_ids = $_POST['product_ids'] ?? []; $raw_qty = $_POST['quantities'] ?? [];
        if ( ! is_array( $raw_ids ) || ! is_array( $raw_qty ) || count( $raw_ids ) > 30 ) { throw new InvalidArgumentException( 'ردیف‌های محصول نامعتبرند.' ); }
        $items = [];
        foreach ( $raw_ids as $i => $id ) {
            if ( ! is_scalar( $id ) || ! isset( $raw_qty[ $i ] ) || ! is_scalar( $raw_qty[ $i ] ) ) { throw new InvalidArgumentException( 'محصول یا تعداد نامعتبر است.' ); }
            if ( (string) $id === '' && (string) $raw_qty[ $i ] === '' ) { continue; }
            $items[] = [ 'product_id' => absint( $id ), 'quantity' => sanitize_text_field( wp_unslash( (string) $raw_qty[ $i ] ) ) ];
        }
        $order_id = KERP_Modules_Gold_Business::offline_sale( [ 'source' => self::input( 'source' ), 'user_id' => self::input( 'user_id' ), 'reference' => self::input( 'reference' ), 'method' => self::input( 'method' ), 'receipt' => self::input( 'receipt' ) ], $items );
        set_transient( 'kerp_gold_sale_result_' . get_current_user_id(), $order_id, 120 );
    }
    private static function sales(): void {
        global $wpdb;
        echo '<h2>فروش حضوری و شبکه‌های اجتماعی</h2><p>محصول ساده، قیمت و مالیات فروشگاه و اجرت پلاسِ مشتری ملاک است. انتخاب نقد، بانک یا درگاه یعنی رسید دریافت وجه را قبلاً بررسی کرده‌اید؛ این فرم تراکنش بانکی جدید ایجاد نمی‌کند. ثبت سند در دفتر بانک و طرف‌حساب، در بخش حواله‌ها جداگانه انجام می‌شود.</p>';
        $result = get_transient( 'kerp_gold_sale_result_' . get_current_user_id() );
        if ( $result ) { $order = wc_get_order( $result ); if ( $order ) { echo '<p><a href="' . esc_url( $order->get_edit_order_url() ) . '">مشاهده سفارش ثبت‌شده شماره ' . (int) $result . '</a></p>'; } }
        KERP_Modules_Gold_Admin::start_form( 'offline_sale' );
        self::select( 'source', 'منبع فروش', [ 'physical' => 'حضوری', 'social' => 'شبکه‌های اجتماعی' ] );
        self::field( 'user_id', 'شناسه کاربر مشتری', '', 'number' );
        echo '<table><thead><tr><th>شناسه محصول</th><th>تعداد</th></tr></thead><tbody>';
        for ( $i = 0; $i < 8; $i++ ) { echo '<tr><td><input name="product_ids[]" type="number" min="1" aria-label="شناسه محصول"></td><td><input name="quantities[]" type="number" min="1" step="1" aria-label="تعداد"></td></tr>'; } echo '</tbody></table>';
        self::select( 'method', 'روش پرداخت', [ 'unpaid' => 'هنوز پرداخت نشده', 'cash' => 'نقد؛ دریافت وجه بررسی شد', 'bank' => 'بانک؛ رسید بررسی شد', 'gateway' => 'درگاه؛ رسید بررسی شد' ] );
        self::field( 'receipt', 'شماره رسید پرداخت؛ برای فروش پرداخت‌شده الزامی است', '', 'text', false ); self::field( 'reference', 'شناسه یکتای ثبت فروش', wp_generate_uuid4() ); self::finish( 'ثبت سفارش فروش' );
        $rows = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . KERP_Modules_Gold_Store::table( 'sales' ) . ' ORDER BY order_id DESC LIMIT 25 OFFSET %d', ( self::page() - 1 ) * 25 ) );
        $cells = []; foreach ( $rows as $row ) { $cells[] = [ $row->order_id, $row->user_id, KERP_Modules_Gold_Business::source_labels()[ $row->source ] ?? $row->source, $row->was_plus ? 'پلاس' : 'عادی', KERP_Modules_Gold_Math::format_money( (int) $row->total, (int) $row->decimals ) . ' ' . $row->currency, self::order_status( $row->status ) ]; }
        self::table( [ 'سفارش', 'کاربر', 'منبع', 'عضویت هنگام خرید', 'مبلغ', 'وضعیت' ], $cells ); self::pages( count( $rows ) );
    }
    private static function reports(): void {
        global $wpdb;
        $today = wp_date( 'Y-m-d' ); $start = isset( $_GET['gold_start'] ) && is_string( $_GET['gold_start'] ) ? sanitize_text_field( $_GET['gold_start'] ) : $today; $end = isset( $_GET['gold_end'] ) && is_string( $_GET['gold_end'] ) ? sanitize_text_field( $_GET['gold_end'] ) : $today;
        echo '<h2>تراز روزانه و بازه‌ای</h2><form method="get"><input type="hidden" name="page" value="kerp-gold"><input type="hidden" name="tab" value="reports">';
        self::field( 'gold_start', 'از تاریخ میلادی؛ بر اساس منطقه زمانی سایت', $start, 'date' ); self::field( 'gold_end', 'تا تاریخ میلادی', $end, 'date' ); KERP_Modules_Gold_Admin::submit( 'نمایش گزارش' ); echo '</form>';
        try { [ $from, $until ] = KERP_Modules_Gold_Business::range( $start, $end ); } catch ( Throwable $e ) { echo '<p>' . esc_html( $e->getMessage() ) . '</p>'; return; }
        $p = KERP_Modules_Gold_Store::table( 'postings' ); $d = KERP_Modules_Gold_Store::table( 'documents' ); $b = KERP_Modules_Gold_Store::table( 'books' );
        $query = "SELECT b.label,m.asset,SUM(CASE WHEN d.created_at<%s THEN m.delta ELSE 0 END) opening,SUM(CASE WHEN d.created_at>=%s AND m.delta>0 THEN m.delta ELSE 0 END) incoming,SUM(CASE WHEN d.created_at>=%s AND m.delta<0 THEN -m.delta ELSE 0 END) outgoing,SUM(m.delta) closing FROM (SELECT from_book book_id,asset,-amount delta,document_id FROM $p UNION ALL SELECT to_book book_id,asset,amount delta,document_id FROM $p) m JOIN $d d ON d.id=m.document_id JOIN $b b ON b.id=m.book_id WHERE d.created_at<%s GROUP BY b.id,b.label,m.asset ORDER BY b.id,m.asset";
        $rows = $wpdb->get_results( $wpdb->prepare( $query, $from, $from, $from, $until ) );
        $cells = []; foreach ( $rows as $row ) { $cells[] = [ $row->label, KERP_Modules_Gold_Business::amount_label( $row->asset, (int) $row->opening ), KERP_Modules_Gold_Business::amount_label( $row->asset, (int) $row->incoming ), KERP_Modules_Gold_Business::amount_label( $row->asset, (int) $row->outgoing ), KERP_Modules_Gold_Business::amount_label( $row->asset, (int) $row->closing ) ]; }
        echo '<h3>دفتر بنکداری تا پایان بازه</h3><p>این جدول فقط اسناد ثبت‌شده در حواله‌ها را نشان می‌دهد. فروش ووکامرس یا درخواست کیف، سند بانکی خودکار در این دفتر نمی‌سازد.</p>';
        self::table( [ 'حساب', 'ابتدای بازه', 'ورودی', 'خروجی', 'پایان بازه' ], $cells );
        $assets = $wpdb->get_results( "SELECT m.asset,SUM(m.delta) amount FROM (SELECT from_book book_id,asset,-amount delta FROM $p UNION ALL SELECT to_book book_id,asset,amount delta FROM $p) m JOIN $b b ON b.id=m.book_id WHERE b.kind IN ('bank','gateway','cash','inventory') GROUP BY m.asset" );
        echo '<h3>مانده فعلی حساب‌های دارایی ثبت‌شده</h3><p>این بخش فقط حساب‌های بانک، درگاه، صندوق و دارایی طلایی را جمع می‌کند؛ مانده طرف‌حساب و کیف کاربران جداست.</p>';
        $asset_rows = []; foreach ( $assets as $asset ) { $asset_rows[] = [ KERP_Modules_Gold_Business::amount_label( $asset->asset, (int) $asset->amount ) ]; }
        self::table( [ 'دارایی فعلی؛ مستقل از بازه گزارش' ], $asset_rows );
        $s = KERP_Modules_Gold_Store::table( 'sales' );
        $rows = $wpdb->get_results( $wpdb->prepare( "SELECT currency,decimals,source,was_plus,status,COUNT(*) orders,SUM(total) total,SUM(refunded) refunded FROM $s WHERE paid_at>=%s AND paid_at<%s GROUP BY currency,decimals,source,was_plus,status ORDER BY currency,was_plus DESC", $from, $until ) );
        $cells = []; foreach ( $rows as $row ) { $asset = $row->currency . ':' . $row->decimals; $cells[] = [ KERP_Modules_Gold_Business::source_labels()[ $row->source ] ?? $row->source, $row->was_plus ? 'پلاس' : 'عادی', self::order_status( $row->status ), $row->orders, KERP_Modules_Gold_Business::amount_label( $asset, (int) $row->total ), KERP_Modules_Gold_Business::amount_label( $asset, (int) $row->refunded ), KERP_Modules_Gold_Business::amount_label( $asset, (int) $row->total - (int) $row->refunded ) ]; }
        echo '<h3>فروش ثبت‌شده در بنکداری، تفکیک کاربران پلاس</h3><p>مبنای بازه، زمان پرداخت سفارش است. بازپرداخت، مقدار فعلی بازپرداخت همان سفارش‌هاست؛ این جدول گردش بانکیِ روز بازپرداخت نیست. ارزها و وضعیت‌های مختلف جدا نمایش داده می‌شوند. فقط سفارش‌های جدید یا سفارش‌هایی که با ابزار بررسی دوباره ثبت گزارش شده‌اند نمایش داده می‌شوند.</p>';
        self::table( [ 'منبع', 'نوع کاربر هنگام خرید', 'وضعیت', 'تعداد', 'مبلغ سفارش', 'بازپرداخت فعلی', 'خالص ارزش سفارش' ], $cells );
        $owned = (int) $wpdb->get_var( "SELECT COALESCE(SUM(CAST(w.meta_value AS SIGNED)),0) FROM {$wpdb->posts} p JOIN {$wpdb->postmeta} w ON w.post_id=p.ID AND w.meta_key='_kerp_gold_equivalent' JOIN {$wpdb->postmeta} s ON s.post_id=p.ID AND s.meta_key='_kerp_gold_state' WHERE p.post_type='kerp_gold_piece' AND p.post_status='publish' AND s.meta_value='in_stock'" );
        $consigned = (int) $wpdb->get_var( "SELECT COALESCE(SUM(CAST(w.meta_value AS SIGNED)),0) FROM {$wpdb->posts} p JOIN {$wpdb->postmeta} w ON w.post_id=p.ID AND w.meta_key='_kerp_gold_equivalent' JOIN {$wpdb->postmeta} s ON s.post_id=p.ID AND s.meta_key='_kerp_gold_state' WHERE p.post_type='kerp_gold_piece' AND p.post_status='publish' AND s.meta_value='consigned'" );
        echo '<h3>موجودی فعلی قطعات ثبت‌شده؛ مستقل از بازه</h3><p>موجود: ' . esc_html( KERP_Modules_Gold_Math::grams( $owned ) ) . ' گرم · امانی: ' . esc_html( KERP_Modules_Gold_Math::grams( $consigned ) ) . ' گرم. این وزن‌ها با دفتر مالی جمع نمی‌شوند؛ ممکن است نمایش دوگانهٔ یک دارایی باشند.</p>';
    }
    private static function packaging(): void {
        global $wpdb;
        echo '<h2>صف بسته‌بندی و ثبت وضعیت</h2><p>سفارش‌های طلایی پرداخت‌شده خودکار در صف قرار می‌گیرند. رابط اتصال احراز هویت‌شده آماده است؛ نشانی‌ها و روش اتصال در راهنمای افزونه آمده‌اند.</p>';
        $rows = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . KERP_Modules_Gold_Store::table( 'packaging' ) . ' ORDER BY order_id DESC LIMIT 25 OFFSET %d', ( self::page() - 1 ) * 25 ) );
        $cells = []; foreach ( $rows as $row ) { $cells[] = [ $row->order_id, self::pack_label( $row->status ), $row->version, $row->reference, $row->note ]; }
        self::table( [ 'سفارش', 'وضعیت', 'نسخه', 'شناسه پیگیری', 'توضیح' ], $cells ); self::pages( count( $rows ) );
        KERP_Modules_Gold_Admin::start_form( 'packaging_status' ); self::field( 'order_id', 'شماره سفارش', '', 'number' ); self::field( 'version', 'نسخه فعلی رکورد در جدول بالا', '', 'number' );
        self::select( 'status', 'وضعیت بعدی', [ 'packing' => 'در حال بسته‌بندی', 'packed' => 'بسته‌بندی شد', 'shipped' => 'ارسال شد', 'error' => 'خطا' ] );
        self::field( 'reference', 'شناسه یکتای عملیات', wp_generate_uuid4() ); self::field( 'note', 'توضیح یا شناسه مرسوله', '', 'text', false ); self::finish( 'ثبت وضعیت' );
    }
    private static function order_status( string $status ): string {
        return [ 'pending' => 'در انتظار پرداخت', 'processing' => 'در حال انجام', 'completed' => 'تکمیل‌شده', 'on-hold' => 'در انتظار بررسی', 'cancelled' => 'لغوشده', 'refunded' => 'بازپرداخت‌شده', 'failed' => 'ناموفق', 'checkout-draft' => 'پیش‌نویس تسویه' ][ $status ] ?? wc_get_order_status_name( $status );
    }
    private static function pack_label( string $status ): string { return [ 'pending' => 'در انتظار', 'packing' => 'در حال بسته‌بندی', 'packed' => 'بسته‌بندی شد', 'shipped' => 'ارسال شد', 'error' => 'خطا', 'review' => 'نیازمند بررسی مدیر' ][ $status ] ?? $status; }
    private static function inventory(): void {
        global $wpdb;
        echo '<h2>کالا، دسته‌ها و تاریخچه وضعیت</h2><p><a href="' . esc_url( admin_url( 'edit.php?post_type=kerp_gold_piece' ) ) . '">انبار قطعات آب‌شده</a> · <a href="' . esc_url( admin_url( 'edit.php?post_type=product' ) ) . '">محصولات زینتی و پک‌ها</a> · <a href="' . esc_url( admin_url( 'edit-tags.php?taxonomy=product_cat&post_type=product' ) ) . '">دسته‌ها و زیردسته‌ها؛ شامل طلای متفرقه</a></p><p>وضعیت کالا در ویرایش محصول یا قطعه انتخاب می‌شود. کالای رزرو، عودت‌شده، تحویل‌گرفته‌شده برای بررسی، فروخته‌شده، بسته‌بندی‌شده یا ارسال‌شده، از ویترین قابل خرید نیست. کالای موجود و امانی با رعایت موجودی ووکامرس قابل فروش است.</p>';
        $rows = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . KERP_Modules_Gold_Store::table( 'statushistory' ) . ' ORDER BY id DESC LIMIT 25 OFFSET %d', ( self::page() - 1 ) * 25 ) );
        $cells = []; foreach ( $rows as $row ) { $states = KERP_Modules_Gold_Module::states(); $cells[] = [ $row->object_id, $row->object_type === 'piece' ? 'قطعه' : 'محصول', $states[ $row->old_state ] ?? $row->old_state, $states[ $row->new_state ] ?? $row->new_state, $row->actor_id, wp_date( 'Y-m-d H:i', strtotime( $row->created_at . ' UTC' ) ) ]; }
        self::table( [ 'شناسه کالا', 'نوع', 'وضعیت قبلی', 'وضعیت جدید', 'ثبت‌کننده', 'زمان محلی سایت' ], $cells ); self::pages( count( $rows ) );
    }
}
