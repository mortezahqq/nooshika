<?php
defined( 'ABSPATH' ) || exit;

/** Optional gold business module; the existing fiat wallet remains independent. */
final class KERP_Modules_Gold_Module {
    private static ?self $instance = null;
    private static array $quote_cache = [];
    public static function instance(): self { return self::$instance ??= new self(); }
    private function __construct() {
        KERP_Modules_Gold_Store::install();
        if ( ! get_role( 'kerp_gold_packager' ) ) { add_role( 'kerp_gold_packager', 'بسته‌بندی بنکداری', [ 'read' => true, 'kerp_gold_packaging' => true ] ); }
        $this->register_inventory();
        $this->categories();
        add_filter( 'kerp_app_pages', [ $this, 'pages' ], 60 );
        add_filter( 'kerp_employee_permission_groups', [ $this, 'permissions' ], 60 );
        add_action( 'admin_menu', [ $this, 'admin_menu' ] );
        add_action( 'admin_notices', function () { if ( function_exists( 'get_current_screen' ) && get_current_screen() && get_current_screen()->post_type === 'kerp_gold_piece' ) { KERP_Modules_Gold_Admin::messages(); } } );
        add_action( 'admin_post_kerp_gold', [ $this, 'handle' ] );
        add_shortcode( 'kerp_plus', [ KERP_Modules_Gold_Public::class, 'plus' ] );
        add_shortcode( 'kerp_gold_wallet', [ KERP_Modules_Gold_Public::class, 'wallet' ] );
        add_action( 'wp_enqueue_scripts', [ $this, 'assets' ] );
        KERP_Modules_Gold_Commerce::register();
        KERP_Modules_Gold_Notifications::register();
        KERP_Modules_Gold_Packaging::register();
        KERP_Modules_Gold_Pricing::register();
    }

    public static function settings(): array {
        return wp_parse_args( (array) get_option( 'kerp_gold_settings', [] ), [
            'allow_cash' => 0, 'allow_physical' => 0, 'allow_jewelry' => 1, 'physical_min' => '1',
            'rate' => '0', 'rate_at' => 0, 'premium' => '0', 'quote_basis' => 'gram', 'mesghal_factor' => '4.3318', 'max_age' => '300',
            'plus_product' => 0, 'plus_days' => 365, 'landing' => 'با عضویت پلاس به خدمات آموزشی، کیف طلایی و بنکداری دسترسی پیدا کنید.',
            'link_wallet' => '', 'link_shop' => '', 'link_course' => '', 'link_support' => '',
            'link_roadmap' => '', 'link_gifts' => '', 'link_ai' => '', 'link_channel' => '', 'link_extra' => '',
        ] );
    }

    public static function links(): array {
        return [ 'wallet' => 'کیف طلایی', 'shop' => 'بنکداری', 'course' => 'دوره‌ها', 'support' => 'پشتیبانی', 'roadmap' => 'نقشه راه', 'gifts' => 'هدایا', 'ai' => 'هوش مصنوعی', 'channel' => 'کانال ویژه', 'extra' => 'خدمات بیشتر' ];
    }

    public static function is_plus( int $user_id ): bool {
        global $wpdb;
        return $user_id > 0 && (int) $wpdb->get_var( $wpdb->prepare( 'SELECT MAX(expires_at) FROM ' . KERP_Modules_Gold_Store::table( 'memberships' ) . ' WHERE user_id=%d', $user_id ) ) > time();
    }

    /** Price currency is WooCommerce store currency, never an implicit rial/toman conversion. */
    public static function quote( bool $refresh = false ): ?array {
        $s = self::settings();
        // A real supplier adapter may provide rate + timestamp, in store currency per gram of 750.
        $key = md5( serialize( $s ) );
        if ( $refresh || ! array_key_exists( $key, self::$quote_cache ) ) { self::$quote_cache[ $key ] = apply_filters( 'kerp_gold_supplier_quote', [ 'rate' => (float) $s['rate'], 'timestamp' => (int) $s['rate_at'] ] ); }
        $quote = self::$quote_cache[ $key ];
        if ( ! is_array( $quote ) || ! isset( $quote['rate'], $quote['timestamp'] ) || ! is_numeric( $quote['rate'] ) || ! is_numeric( $quote['timestamp'] ) ) { return null; }
        $age = time() - (int) $quote['timestamp'];
        if ( ! is_finite( (float) $quote['rate'] ) || (float) $quote['rate'] <= 0 || $age < 0 || $age > (int) $s['max_age'] ) { return null; }
        $rate = (float) $quote['rate'];
        $basis = $quote['basis'] ?? $s['quote_basis'];
        if ( $basis === 'mesghal' ) { if ( (float) $s['mesghal_factor'] <= 0 ) { return null; } $rate /= (float) $s['mesghal_factor']; }
        elseif ( $basis !== 'gram' ) { return null; }
        $rate += (float) $s['premium'];
        if ( ! is_finite( $rate ) || $rate <= 0 ) { return null; }
        return [ 'rate' => $rate, 'timestamp' => (int) $quote['timestamp'] ];
    }

    public static function event( string $event, string $reference ): void {
        global $wpdb;
        $inserted = $wpdb->insert( KERP_Modules_Gold_Store::table( 'events' ), [ 'event' => sanitize_key( $event ), 'reference' => $reference, 'hashtag' => '#gold_' . sanitize_key( $event ), 'created_at' => current_time( 'mysql', true ) ] );
        try {
            if ( $inserted !== false ) { KERP_Modules_Gold_Notifications::queue( (int) $wpdb->insert_id ); }
            // A committed financial operation must remain successful if an optional integration throws.
            do_action( 'kerp_gold_event', sanitize_key( $event ), $reference, '#gold_' . sanitize_key( $event ) );
        } catch ( Throwable $e ) {
            if ( function_exists( 'wc_get_logger' ) ) { wc_get_logger()->error( 'Gold event integration failed; inspect the local event log.', [ 'source' => 'kerp-gold', 'event' => sanitize_key( $event ), 'reference' => $reference ] ); }
        }
    }

    private function register_inventory(): void {
        register_post_type( 'kerp_gold_piece', [ 'labels' => [ 'name' => 'قطعات طلای آب‌شده', 'singular_name' => 'قطعه طلا', 'add_new_item' => 'افزودن قطعه' ], 'public' => false, 'show_ui' => true, 'show_in_menu' => 'kerp-gold', 'supports' => [ 'title', 'editor' ], 'capability_type' => 'post', 'capabilities' => [ 'edit_posts' => 'manage_options', 'edit_others_posts' => 'manage_options', 'publish_posts' => 'manage_options', 'read_private_posts' => 'manage_options', 'delete_posts' => 'manage_options', 'create_posts' => 'manage_options', 'edit_post' => 'manage_options', 'read_post' => 'manage_options', 'delete_post' => 'manage_options' ], 'map_meta_cap' => false ] );
        add_action( 'add_meta_boxes', function () { add_meta_box( 'kerp-gold-piece', 'اطلاعات قطعه؛ مبنای سیستم عیار ۷۵۰', [ $this, 'piece_box' ], 'kerp_gold_piece' ); } );
        add_action( 'save_post_kerp_gold_piece', [ $this, 'save_piece' ] );
    }

    public function piece_box( $post ): void {
        wp_nonce_field( 'kerp_gold_piece', 'kerp_gold_piece_nonce' );
        foreach ( [ 'weight' => 'وزن واقعی به گرم', 'purity' => 'عیار از ۱ تا ۱۰۰۰', 'supplier' => 'تأمین‌کننده', 'assay' => 'شماره انگ یا آزمایش' ] as $key => $label ) {
            echo '<p><label>' . esc_html( $label ) . '<br><input name="gold_' . esc_attr( $key ) . '" value="' . esc_attr( get_post_meta( $post->ID, '_kerp_gold_' . $key, true ) ) . '"></label></p>';
        }
        echo '<p><label>وضعیت قطعه <select name="gold_state">';
        $state = get_post_meta( $post->ID, '_kerp_gold_state', true ) ?: 'in_stock';
        foreach ( self::states() as $key => $label ) { echo '<option value="' . esc_attr( $key ) . '" ' . selected( $state, $key, false ) . '>' . esc_html( $label ) . '</option>'; }
        echo '</select></label></p>';
        $units = (int) get_post_meta( $post->ID, '_kerp_gold_equivalent', true );
        echo '<p>معادل عیار ۷۵۰: ' . esc_html( KERP_Modules_Gold_Math::grams( $units ) ) . ' گرم</p><p>وضعیت‌های انبار در این نسخه به‌صورت دستی ثبت می‌شوند.</p>';
    }

    public function save_piece( int $id ): void {
        if ( ! current_user_can( 'manage_options' ) || wp_is_post_revision( $id ) || ! isset( $_POST['kerp_gold_piece_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['kerp_gold_piece_nonce'] ) ), 'kerp_gold_piece' ) ) { return; }
        try {
            $weight = KERP_Modules_Gold_Math::units( self::input( 'gold_weight' ) );
            $raw_purity = self::input( 'gold_purity' );
            if ( ! preg_match( '/^\d{1,4}$/D', $raw_purity ) ) { throw new InvalidArgumentException( 'عیار نامعتبر است.' ); }
            $state = self::input( 'gold_state' );
            if ( ! isset( self::states()[ $state ] ) ) { throw new InvalidArgumentException( 'وضعیت قطعه نامعتبر است.' ); }
            $purity = (int) $raw_purity;
            $equivalent = KERP_Modules_Gold_Math::equivalent( $weight, $purity );
            $old = (string) get_post_meta( $id, '_kerp_gold_state', true );
            foreach ( [ 'weight' => KERP_Modules_Gold_Math::grams( $weight ), 'purity' => $purity, 'equivalent' => $equivalent, 'supplier' => self::input( 'gold_supplier' ), 'assay' => self::input( 'gold_assay' ), 'state' => $state ] as $key => $value ) { update_post_meta( $id, '_kerp_gold_' . $key, $value ); }
        KERP_Modules_Gold_Business::status_history( $id, 'piece', $old, $state );
        } catch ( Throwable $e ) {
            set_transient( 'kerp_gold_error_' . get_current_user_id(), $e->getMessage(), 60 );
        }
    }

    public function assets(): void {
        wp_register_style( 'kerp-gold', KERP_ASSETS_URL . 'public/css/gold.css', [], KERP_VERSION );
        if ( current_user_can( 'manage_options' ) && isset( $_SERVER['REQUEST_URI'] ) && str_contains( (string) $_SERVER['REQUEST_URI'], '/erp' ) ) { wp_enqueue_style( 'kerp-gold' ); }
    }

    public function admin_menu(): void {
        add_menu_page( 'بنکداری طلا', 'بنکداری طلا', 'manage_options', 'kerp-gold', [ KERP_Modules_Gold_Admin::class, 'render' ], 'dashicons-money-alt', 58 );
        add_submenu_page( 'kerp-gold', 'عملیات و تنظیمات طلا', 'عملیات و تنظیمات', 'manage_options', 'kerp-gold', [ KERP_Modules_Gold_Admin::class, 'render' ] );
    }

    private function categories(): void {
        if ( get_option( 'kerp_gold_categories' ) || ! taxonomy_exists( 'product_cat' ) ) { return; }
        $ids = [];
        foreach ( [ 'kerp-melted-gold' => 'طلای آب‌شده', 'kerp-gold-jewelry' => 'طلای زینتی', 'kerp-misc-gold' => 'طلای متفرقه' ] as $slug => $label ) {
            $term = get_term_by( 'slug', $slug, 'product_cat' );
            if ( $term ) { $ids[] = (int) $term->term_id; }
            else { $result = wp_insert_term( $label, 'product_cat', [ 'slug' => $slug ] ); if ( is_wp_error( $result ) ) { return; } $ids[] = (int) $result['term_id']; }
        }
        update_option( 'kerp_gold_categories', $ids, false );
    }

    public function pages( array $pages ): array {
        if ( ! current_user_can( 'manage_options' ) ) { return $pages; }
        $pages['gold-wholesale'] = [
            'title' => 'بنکداری طلا', 'route' => 'gold', 'type' => 'page', 'template' => 'modules/gold/admin.php', 'permission' => 'gold.manage',
            'navigation' => [ 'group' => [ 'key' => 'sales', 'title' => 'فروش و مالی', 'icon' => 'uik-r fa-money', 'order' => 25 ], 'icon' => 'ni ni-coins', 'order' => 65 ],
        ];
        return $pages;
    }

    public function permissions( array $groups ): array {
        $groups['gold'] = [ 'key' => 'gold', 'label' => 'بنکداری طلا', 'icon' => 'ni ni-coins', 'order' => 65,
            'blocks' => [ 'gold' => [ 'key' => 'gold', 'label' => 'مدیریت بنکداری', 'icon' => 'ni ni-coins', 'order' => 10,
                'permissions' => [ 'manage' => [ 'key' => 'gold.manage', 'label' => 'مدیریت بنکداری؛ نیازمند اختیار مدیریت تنظیمات سایت', 'type' => 'view', 'order' => 10 ] ] ] ] ];
        return $groups;
    }

    public static function states(): array {
        return [ 'in_stock' => 'موجود', 'consigned' => 'امانی', 'reserved' => 'رزرو', 'returned' => 'عودت‌شده', 'received' => 'تحویل‌گرفته‌شده؛ آماده بررسی', 'sold' => 'فروخته‌شده', 'packed' => 'بسته‌بندی‌شده', 'shipped' => 'ارسال‌شده' ];
    }

    public static function input( string $key ): string {
        return isset( $_POST[ $key ] ) && is_scalar( $_POST[ $key ] ) ? sanitize_text_field( wp_unslash( (string) $_POST[ $key ] ) ) : '';
    }

    public function handle(): void {
        if ( ! is_user_logged_in() ) { wp_die( 'ابتدا وارد حساب شوید.', '', [ 'response' => 403 ] ); }
        check_admin_referer( 'kerp_gold' );
        $op = self::input( 'operation' );
        $fallback = $op === 'request' ? home_url( '/' ) : admin_url( 'admin.php?page=kerp-gold' );
        $return = wp_validate_redirect( self::input( 'return_url' ), $fallback );
        try {
            if ( $op !== 'request' && ! current_user_can( 'manage_options' ) ) { throw new RuntimeException( 'دسترسی کافی ندارید.' ); }
            switch ( $op ) {
                case 'book': KERP_Modules_Gold_Business::create_book( array_combine( [ 'kind', 'party_type', 'user_id', 'label', 'code', 'details' ], array_map( [ self::class, 'input' ], [ 'kind', 'party_type', 'user_id', 'label', 'code', 'details' ] ) ) ); break;
                case 'transfer': KERP_Modules_Gold_Backoffice::transfer(); break;
                case 'reverse_document': KERP_Modules_Gold_Business::reverse( (int) self::input( 'id' ), self::input( 'reference' ), self::input( 'note' ) ); break;
                case 'offline_sale': KERP_Modules_Gold_Backoffice::sale(); break;
                case 'packaging_status': KERP_Modules_Gold_Packaging::update( (int) self::input( 'order_id' ), self::input( 'status' ), (int) self::input( 'version' ), self::input( 'reference' ), self::input( 'note' ) ); break;
                case 'settings': KERP_Modules_Gold_Admin::save_settings(); break;
                case 'adjust':
                    $sign = self::input( 'direction' );
                    if ( ! in_array( $sign, [ 'credit', 'debit' ], true ) ) { throw new InvalidArgumentException( 'نوع تراکنش نامعتبر است.' ); }
                    KERP_Modules_Gold_Store::adjust( (int) self::input( 'user_id' ), KERP_Modules_Gold_Math::units( self::input( 'grams' ) ) * ( $sign === 'credit' ? 1 : -1 ), self::input( 'reference' ), self::input( 'note' ) ); break;
                case 'request':
                    $kind = self::input( 'kind' );
                    if ( self::input( 'note' ) === '' ) { throw new InvalidArgumentException( 'توضیح درخواست لازم است.' ); }
                    KERP_Modules_Gold_Store::request( get_current_user_id(), $kind, KERP_Modules_Gold_Math::units( self::input( 'grams' ) ), self::input( 'reference' ), self::input( 'note' ) ); break;
                case 'resolve': KERP_Modules_Gold_Store::resolve( (int) self::input( 'id' ), self::input( 'status' ), self::input( 'reference' ) ); break;
                case 'retry_event': KERP_Modules_Gold_Notifications::queue( (int) self::input( 'id' ) ); break;
                case 'retry_order': if ( ! KERP_Modules_Gold_Commerce::paid( (int) self::input( 'order_id' ) ) ) { throw new RuntimeException( 'سفارش پرداخت‌شده موجود نیست یا ثبت عملیات ناموفق بود؛ یادداشت سفارش را بررسی کنید.' ); } break;
                case 'replacement': KERP_Modules_Gold_Store::complete_replacement( (int) self::input( 'id' ), self::input( 'reference' ) ); break;
                default: throw new InvalidArgumentException( 'عملیات نامعتبر است.' );
            }
            set_transient( 'kerp_gold_success_' . get_current_user_id(), 'عملیات ثبت شد.', 60 );
        } catch ( Throwable $e ) { set_transient( 'kerp_gold_error_' . get_current_user_id(), $e->getMessage(), 60 ); }
        wp_safe_redirect( $return ); exit;
    }
}
