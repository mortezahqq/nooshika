<?php
defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Gold_Public {
    private static function begin(): void {
        if ( ! defined( 'DONOTCACHEPAGE' ) ) { define( 'DONOTCACHEPAGE', true ); }
        if ( ! headers_sent() ) { nocache_headers(); }
        wp_enqueue_style( 'kerp-gold' );
        echo '<section class="kerp-gold" dir="rtl">';
    }

    public static function plus(): string {
        ob_start(); self::begin();
        $s = KERP_Modules_Gold_Module::settings();
        echo '<header class="kerp-gold-hero"><span class="kerp-gold-eyebrow">باشگاه پلاس</span><h2>همه خدمات، یک‌جا</h2><p>' . esc_html( $s['landing'] ) . '</p></header>';
        if ( KERP_Modules_Gold_Module::is_plus( get_current_user_id() ) ) {
            echo '<p class="kerp-gold-status">اشتراک پلاس شما فعال است.</p><div class="kerp-gold-grid">';
            $i = 0;
            foreach ( KERP_Modules_Gold_Module::links() as $key => $label ) {
                $url = $s[ 'link_' . $key ];
                if ( $url === '' ) { continue; }
                $i++;
                echo '<a class="kerp-gold-tile" href="' . esc_url( $url ) . '"><span aria-hidden="true">' . esc_html( str_pad( (string) $i, 2, '0', STR_PAD_LEFT ) ) . '</span><h3>' . esc_html( $label ) . '</h3><small>ورود به بخش ←</small></a>';
            }
            if ( ! $i ) { echo '<p>خدمات به‌زودی در این بخش نمایش داده می‌شوند.</p>'; }
            echo '</div>';
        } else {
            echo '<div class="kerp-gold-card"><h3>به جمع کاربران پلاس بپیوندید</h3><p>کیف طلایی، بنکداری و دسترسی یک‌جا به مسیر آموزش و خدمات ویژه.</p>';
            if ( ! is_user_logged_in() ) { echo '<a class="kerp-gold-button" href="' . esc_url( wp_login_url( get_permalink() ) ) . '">ورود یا ثبت‌نام</a> '; }
            $product = $s['plus_product'] ? wc_get_product( $s['plus_product'] ) : false;
            if ( $product && $product->is_purchasable() && $product->is_in_stock() ) {
                echo '<p>' . wp_kses_post( $product->get_price_html() ) . ' · ' . esc_html( $s['plus_days'] ) . ' روز</p><a class="kerp-gold-button" href="' . esc_url( get_permalink( $product->get_id() ) ) . '">خرید اشتراک پلاس</a>';
            } else { echo '<p>برای تهیه اشتراک با پشتیبانی تماس بگیرید.</p>'; }
            echo '</div>';
        }
        echo '</section>'; return ob_get_clean();
    }

    public static function wallet(): string {
        ob_start(); self::begin();
        echo '<header class="kerp-gold-hero"><span class="kerp-gold-eyebrow">دارایی طلایی شما</span><h2>کیف طلایی</h2><p>شفاف، بر پایه گرم طلای عیار ۷۵۰</p></header>';
        if ( ! is_user_logged_in() ) {
            echo '<a class="kerp-gold-button" href="' . esc_url( wp_login_url( get_permalink() ) ) . '">ورود به حساب</a></section>'; return ob_get_clean();
        }
        KERP_Modules_Gold_Admin::messages();
        $id = get_current_user_id();
        $balance = KERP_Modules_Gold_Store::balance( $id );
        $quote = KERP_Modules_Gold_Module::quote();
        echo '<div class="kerp-gold-card"><p>موجودی آزاد</p><strong class="kerp-gold-balance">' . esc_html( KERP_Modules_Gold_Math::grams( $balance ) ) . ' <small>گرم</small></strong><p>وزن درخواست‌های برداشتِ در انتظار بررسی، از موجودی آزاد کم شده است.</p>';
        if ( $quote ) {
            echo '<p>برآورد قیمت هر گرم: ' . wp_kses_post( wc_price( $quote['rate'] ) ) . '</p><p>برآورد ارزش موجودی: ' . wp_kses_post( wc_price( $balance / KERP_Modules_Gold_Math::SCALE * $quote['rate'] ) ) . '</p>';
        } else { echo '<p>نرخ معتبر در دسترس نیست. برآورد قیمت تا به‌روزرسانی نرخ نمایش داده نمی‌شود.</p>'; }
        echo '</div>';
        if ( KERP_Modules_Gold_Module::is_plus( $id ) ) {
            $s = KERP_Modules_Gold_Module::settings();
            echo '<div class="kerp-gold-card"><h3>ثبت درخواست</h3><p>درخواست‌ها به‌صورت دستی بررسی می‌شوند. خرید فقط پس از توافق نرخ، دریافت وجه و تأیید مدیر به موجودی اضافه می‌شود. این فرم پرداخت اینترنتی یا معامله قطعی ایجاد نمی‌کند.</p>';
            KERP_Modules_Gold_Admin::start_form( 'request' );
            echo '<input type="hidden" name="reference" value="' . esc_attr( wp_generate_uuid4() ) . '"><input type="hidden" name="return_url" value="' . esc_url( get_permalink() ) . '"><label>نوع درخواست<select name="kind"><option value="buy">خرید طلا</option>';
            foreach ( [ 'cash' => 'تسویه نقدی', 'physical' => 'تحویل فیزیکی', 'jewelry' => 'مصرف برای زیورآلات' ] as $kind => $label ) {
                if ( $s[ 'allow_' . $kind ] ) { echo '<option value="' . esc_attr( $kind ) . '">' . esc_html( $label ) . '</option>'; }
            }
            echo '</select></label>';
            KERP_Modules_Gold_Admin::field( 'grams', 'وزن به گرم معادل عیار ۷۵۰؛ نمونه: 1.250000', '', 'text', true );
            KERP_Modules_Gold_Admin::field( 'note', 'توضیحات؛ برای زیورآلات، شناسه محصول یا سفارش را بنویسید', '', 'text', true );
            if ( $s['allow_physical'] ) { echo '<p>حداقل تحویل فیزیکی: ' . esc_html( $s['physical_min'] ) . ' گرم</p>'; }
            echo '<button class="kerp-gold-button" type="submit">ثبت برای بررسی</button></form></div>';
        } else { echo '<p>برای ثبت درخواست جدید، اشتراک پلاس فعال لازم است. موجودی و سوابق شما محفوظ است.</p>'; }
        self::history( $id );
        echo '</section>'; return ob_get_clean();
    }

    private static function history( int $id ): void {
        $page = max( 1, isset( $_GET['gold_page'] ) ? (int) $_GET['gold_page'] : 1 );
        foreach ( [ 'requests' => 'درخواست‌های من', 'ledger' => 'گردش طلایی من' ] as $name => $title ) {
            $rows = KERP_Modules_Gold_Store::rows( $name, $id, $page );
            echo '<h3>' . esc_html( $title ) . '</h3><div class="kerp-gold-scroll"><table><thead><tr><th>شماره</th><th>وزن</th><th>شرح</th><th>وضعیت یا موجودی پس از ثبت</th></tr></thead><tbody>';
            foreach ( $rows as $row ) {
                echo '<tr><td>' . (int) $row->id . '</td><td dir="ltr">' . esc_html( KERP_Modules_Gold_Math::grams( (int) ( $row->units ?? $row->delta ) ) ) . '</td><td>' . esc_html( $name === 'requests' ? KERP_Modules_Gold_Admin::label( $row->kind ) . ' — ' . $row->note . ' ' . $row->resolution : $row->note ) . '</td><td>' . esc_html( $name === 'requests' ? KERP_Modules_Gold_Admin::label( $row->status ) : KERP_Modules_Gold_Math::grams( (int) $row->balance ) ) . '</td></tr>';
            }
            if ( ! $rows ) { echo '<tr><td colspan="4">هنوز موردی ثبت نشده است.</td></tr>'; }
            echo '</tbody></table></div>';
        }
        echo '<nav class="kerp-gold-pages" aria-label="صفحه‌های سوابق">';
        if ( $page > 1 ) { echo '<a href="' . esc_url( add_query_arg( 'gold_page', $page - 1 ) ) . '">صفحه قبل</a>'; }
        // A next page may be empty for one stream; both remain scoped to the current user.
        echo '<a href="' . esc_url( add_query_arg( 'gold_page', $page + 1 ) ) . '">صفحه بعد</a></nav>';
    }
}
