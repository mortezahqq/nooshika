<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
$user_id      = get_current_user_id();
$current_skin = get_user_meta( $user_id, 'kerp_skin', TRUE ) ?: 'default';

$user_id        = get_current_user_id();
$dark_mode_meta = get_user_meta( $user_id, 'kerp_dark_mode', TRUE );

$is_dark_mode = in_array(
	strtolower( (string) $dark_mode_meta ),
	[ '1', 'true', 'yes', 'on' ],
	TRUE
);

$modules                  = KERP_Modules::instance();
$customers_module_enabled = $modules->is_module_enabled( 'customers' );
$customer_singular_label  = KERP_Modules_Customers_Settings::instance()->get_singular_label();
$can_add_customer         = $customers_module_enabled && KERP_Services_UI_Gate::can( 'customers.create', 'action' );
$can_search_customers     = $customers_module_enabled && KERP_Modules_Customers_Query::search_scope() !== 'none';

$access_record = KERP_Services_Access::get_record( $user_id );
$role_key      = sanitize_key( (string) ( $access_record['role_key'] ?? '' ) );
$role          = KERP_Modules_Employees_Roles::instance()->get( $role_key );
$role_label    = (string) ( $role['label'] ?? $role_key );
?>
<div class="nk-header nk-header-fixed ">
    <div class="container-xl wide-xl">
        <div class="nk-header-wrap">
            <div class="nk-menu-trigger d-xl-none ms-n1 me-3">
                <a href="#" class="nk-nav-toggle nk-quick-nav-icon" data-target="sidebarMenu"><em
                        class="icon ni ni-menu"></em></a>
            </div>
			
			<?php if ( $can_search_customers ) { ?>
                <div class="nk-header-search">
                    <button type="button" class="btn btn-icon search-toggle kerp-header-search-toggle"
                            aria-controls="kerp-header-search" aria-expanded="false"
                            aria-label="<?php esc_attr_e( 'جستجو', 'kasebi-erp' ); ?>">
                        <em class="icon ni ni-search"></em>
                    </button>

                    <div class="card-search search-wrap"
                         id="kerp-header-search" role="search" aria-hidden="true">

                        <div class="card-body">
                            <div class="search-content">
                                <button type="button" class="search-back btn btn-icon kerp-header-search-toggle"
                                        aria-label="<?php esc_attr_e( 'بستن جستجو', 'kasebi-erp' ); ?>">
                                    <em class="icon ni ni-arrow-right"></em>
                                </button>

                                <input type="text"
                                       class="form-control border-transparent form-focus-none"
                                       id="header_user_search" autocomplete="off" enterkeyhint="search"
                                       aria-label="<?php esc_attr_e( 'جستجو بر اساس نام یا شماره تماس', 'kasebi-erp' ); ?>"
                                       placeholder="<?php esc_attr_e(
									       'جستجو بر اساس نام یا شماره تماس',
									       'kasebi-erp'
								       ); ?>">

                                <button type="button"
                                        class="search-submit btn btn-icon"
                                        aria-label="<?php echo esc_attr( sprintf( __( 'جستجوی %s', 'kasebi-erp' ), $customer_singular_label ) ); ?>">
                                    <em class="icon ni ni-search"></em>
                                </button>
                            </div>
                        </div>

                        <div class="search_result_container"></div>
                    </div>
                </div>
			<?php } ?>
            <div class="nk-header-tools">
                <ul class="nk-quick-nav">
					<?php if ( $can_add_customer ) { ?>
                        <li class="dropdown notification-dropdown">
                            <a href="#"
                               class="nk-quick-nav-icon"
                               data-bs-toggle="modal"
                               data-bs-target="#addCustomer"
                               aria-label="<?php echo esc_attr( sprintf( __( 'افزودن %s', 'kasebi-erp' ), $customer_singular_label ) ); ?>">
                                <em class="icon ni ni-plus"></em>
                            </a>
                        </li>
					<?php } ?>
                    <li class="dropdown language-dropdown d-none d-sm-block me-n1">
                        <a href="#" class="dropdown-toggle nk-quick-nav-icon" data-bs-toggle="dropdown">
                            <div class="quick-icon border border-light">
                                <span class="nk-opt-item-bg"><span
                                        class="skin-<?php echo $current_skin; ?>"></span></span>
                            </div>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end">
                            <ul class="language-list">
                                <li>
                                    <a href="#" class="change_preferences"
                                       data-action="change_skin" data-value="default">
                                        <span class="nk-opt-item-bg"><span class="skin-default"></span>	</span>
                                        <span class="language-name">پیش‌فرض</span>
                                    </a>
                                </li>

                                <li>
                                    <a href="#" class="change_preferences"
                                       data-action="change_skin" data-value="green">
                                        <span class="nk-opt-item-bg"><span class="skin-green"></span></span>
                                        <span class="language-name">سبز</span>
                                    </a>
                                </li>

                                <li>
                                    <a href="#" class="change_preferences"
                                       data-action="change_skin" data-value="blue">
                                        <span class="nk-opt-item-bg"><span class="skin-blue"></span></span>
                                        <span class="language-name">آبی روشن</span>
                                    </a>
                                </li>

                                <li>
                                    <a href="#" class="change_preferences"
                                       data-action="change_skin" data-value="egyptian">
                                        <span class="nk-opt-item-bg"><span class="skin-egyptian"></span></span>
                                        <span class="language-name">آبی سیر</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" class="change_preferences"
                                       data-action="change_skin" data-value="purple">
                                        <span class="nk-opt-item-bg"><span class="skin-purple"></span></span>
                                        <span class="language-name">بنفش</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" class="change_preferences" data-action="change_skin"
                                       data-value="red">
                                        <span class="nk-opt-item-bg"><span class="skin-red"></span></span>
                                        <span class="language-name">قرمز</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </li>
                    <li class="dropdown user-dropdown">
                        <a href="#" class="dropdown-toggle" data-bs-toggle="dropdown">
                            <div class="user-toggle">
                                <div class="user-avatar sm">
                                    <em class="icon ni ni-setting-alt"></em>
                                </div>
                            </div>
                        </a>
                        <div class="dropdown-menu dropdown-menu-md dropdown-menu-end">
                            <div class="dropdown-inner user-card-wrap bg-lighter d-none d-md-block">
                                <div class="user-card">
                                    <div class="user-avatar">
                                        <span><?php echo KERP_Helpers_User::get_user_avatar(); ?></span>
                                    </div>
                                    <div class="user-info">
                                        <span class="lead-text"><?php echo get_user_name_by_id(); ?></span>
                                        <span class="sub-text"><?php echo $role_label ?></span>
                                    </div>
                                </div>
                            </div>
							<?php
							$auth = KERP_Api_Auth::instance();
							
							if ( $auth->is_impersonating() ) {
								$admin_id = $auth->get_impersonator_id();
								$admin    = get_userdata( $admin_id );
								
								if ( $admin instanceof WP_User ) {
									?>
                                    <div class="dropdown-inner">
                                        <ul class="link-list">
                                            <li>
                                                <a href="#" class="kerp-restore-admin-session">
                                                    <em class="icon ni ni-chevron-left-c"></em>
                                                    <span><?php printf(
															esc_html__( 'بازگشت به %s', 'kasebi-erp' ),
															esc_html( get_user_name_by_id( $admin->ID ) )
														); ?></span>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
									<?php
								}
							}
							?>
                            <div class="dropdown-inner">
                                <ul class="link-list">
                                    <li>
                                        <a href="<?php echo home_url( '/erp/settings' ); ?>"
                                           class="page_activator nk-menu-link" data-url="/erp/settings/">
                                            <em class="kik fa-settings-02 icon"></em>
                                            <span>تنظیمات حساب</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#"
                                           class="dark-switch change_preferences<?php echo $is_dark_mode ? ' active' : ''; ?>"
                                           data-action="change_dark_mode"
                                           data-value="<?php echo $is_dark_mode ? '0' : '1'; ?>"
                                           aria-pressed="<?php echo $is_dark_mode ? 'true' : 'false'; ?>">
                                            <em class="icon ni <?php echo $is_dark_mode ? 'ni-sun' : 'ni-moon'; ?>"></em>
                                            <span>حالت تاریک</span>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                            <div class="dropdown-inner">
                                <ul class="link-list">
                                    <li>
                                        <a href="<?php echo get_home_url(); ?>/erp?action=logout">
                                            <em class="icon ni ni-signout"></em><span>خروج</span>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
