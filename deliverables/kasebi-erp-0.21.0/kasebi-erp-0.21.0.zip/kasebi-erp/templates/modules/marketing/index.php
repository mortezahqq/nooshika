<?php
defined( 'ABSPATH' ) || exit;
$store = KERP_Modules_Marketing_Store::class;
$view = KERP_Modules_Marketing_View::class;
if ( ! $store::can_view() ) return;
$query = (array) ( $page_context['query'] ?? [] );
$route = '/erp/marketing/' . $marketing_section . '/';
$query['inbox'] = [ 'review' => 'review', 'finance' => 'finance', 'inbox' => 'mine' ][$marketing_section] ?? '';
$per_page = KERP_Helpers_Pagination::resolve_per_page( 'marketing', $query, 20, 100 );
$result = $store::find( $query, $per_page );
$filters = [
	[ 'key' => 'search', 'name' => 'search', 'label' => 'جستجو', 'type' => 'text', 'value' => $store::text( $query['search'] ?? '' ), 'col' => 12 ],
	[ 'key' => 'status', 'name' => 'status', 'label' => 'وضعیت', 'type' => 'select', 'options' => $store::statuses(), 'placeholder' => 'همه وضعیت‌ها', 'value' => $store::text( $query['status'] ?? '' ) ],
];
$can_archive = kerp_can( 'marketing.archive', 'action' );
$has_selectable = $can_archive && count( array_filter( $result['items'], static fn( $item ) => in_array( $item['status'], [ 'completed', 'rejected' ], true ) ) ) > 0;
?>
<div class="kerp-marketing marketing-interior" data-marketing-nonce="<?php echo esc_attr( wp_create_nonce( 'kerp_marketing' ) ); ?>">
<div class="nk-block-head marketing-page-hero"><div class="nk-block-between g-3"><div><span class="overline-title text-primary">مارکتینگ</span><h3 class="nk-block-title"><?php echo esc_html( $marketing_title ); ?></h3><p class="text-soft mb-0">از برنامه‌ریزی هزینه تا تأیید، پرداخت و سنجش نتیجه</p></div>
<div class="d-flex flex-wrap gap-2">
<?php if ( kerp_can( 'marketing.create', 'action' ) ) : ?><button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#marketingRequestModal"><em class="icon ni ni-plus"></em><span>درخواست جدید</span></button><?php endif; ?>
</div></div></div>
<div class="card card-bordered"><div class="card-inner"><div class="card-title-group flex-wrap gap-2"><div class="card-title"><h6 class="title marketing-list-title">درخواست‌ها <span class="badge bg-primary-dim"><?php echo esc_html( $view::display( $result['total'] ) ); ?></span></h6></div><div class="d-flex flex-wrap gap-2">
<?php
if ( $can_archive ) KERP_Helpers_Template::render_template( 'app/components/list/bulk-actions.php', [ 'actions' => [ 'archive' => [ 'label' => 'بایگانی پایان‌یافته‌ها / برگشتی‌ها', 'icon' => 'ni ni-archive' ] ], 'action' => 'marketing_bulk', 'page' => $route, 'item_selector' => '.marketing-select' ] );
KERP_Helpers_Template::render_template( 'app/components/list/filter-dropdown.php', [ 'has_filter' => ! empty( $query['search'] ) || ! empty( $query['status'] ) || ! empty( $query['inbox'] ), 'filter_fields' => $filters, 'action' => 'erp_request_page_content', 'page' => $route ] );
KERP_Helpers_Template::render_template( 'app/components/list/per-page-selector.php', [ 'per_page' => $per_page, 'available_per_pages' => [ 10, 20, 50, 100 ], 'action' => 'erp_request_page_content', 'page' => $route ] );
?></div></div></div>
<div class="nk-tb-list kerp-marketing-list">
<div class="nk-tb-item nk-tb-head">
<div class="nk-tb-col nk-tb-col-check"><?php if ( $can_archive ) : ?><input class="form-check-input select_all_rows" type="checkbox" data-target=".marketing-select" <?php disabled( ! $has_selectable ); ?> aria-label="انتخاب همه موارد قابل بایگانی" title="فقط درخواست‌های پایان‌یافته یا برگشتی قابل بایگانی هستند"><?php endif; ?></div>
<?php foreach ( [ 'کمپین / پلتفرم', 'هزینه و بازده برآوردی', 'تاریخ اجرا', 'وضعیت', 'عملیات' ] as $label ) : ?><div class="nk-tb-col"><?php echo esc_html( $label ); ?></div><?php endforeach; ?></div>
<?php foreach ( $result['items'] as $row ) : $detail = '/erp/marketing/requests/' . (int) $row['id'] . '/'; ?>
<div class="nk-tb-item">
<div class="nk-tb-col nk-tb-col-check"><?php if ( $can_archive ) : $selectable = in_array( $row['status'], [ 'completed', 'rejected' ], true ); ?><input class="form-check-input select_item_row marketing-select" type="checkbox" <?php disabled( ! $selectable ); ?> <?php if ( ! $selectable ) : ?>title="فقط درخواست‌های پایان‌یافته یا برگشتی قابل بایگانی هستند" aria-describedby="marketing-selection-note-<?php echo (int) $row['id']; ?>"<?php endif; ?> value="<?php echo (int) $row['id']; ?>" aria-label="انتخاب <?php echo esc_attr( $row['title'] ); ?>"><?php if ( ! $selectable ) : ?><span class="visually-hidden" id="marketing-selection-note-<?php echo (int) $row['id']; ?>">فقط درخواست‌های پایان‌یافته یا برگشتی قابل بایگانی هستند</span><?php endif; endif; ?></div>
<div class="nk-tb-col" data-label="کمپین"><a class="fw-bold page_activator" data-url="<?php echo esc_attr( $detail ); ?>" href="<?php echo esc_url( home_url( $detail ) ); ?>"><?php echo esc_html( $row['title'] ); ?></a><span class="sub-text"><?php echo esc_html( $row['platform'] . ' · ' . $row['ad_type'] ); ?></span></div>
<div class="nk-tb-col" data-label="بودجه"><strong><?php echo $view::money( $row['cost'], $row['currency'] ); ?></strong><span class="sub-text">ROI: <?php echo esc_html( $view::display( $store::ratio( (float) $row['expected_sales'], (float) $row['cost'] ), 2 ) ); ?> برابر</span></div>
<div class="nk-tb-col" data-label="اجرا"><?php echo esc_html( $view::jalali( $row['execution_date'] ) ); ?></div>
<div class="nk-tb-col" data-label="وضعیت"><span class="badge marketing-status" data-status="<?php echo esc_attr( $row['status'] ); ?>"><?php echo esc_html( $store::statuses()[$row['status']] ?? $row['status'] ); ?></span></div>
<div class="nk-tb-col kerp-marketing-request-actions" data-label="عملیات"><?php
$actions = [
    [ 'title' => 'جزئیات درخواست', 'url' => home_url( $detail ), 'data_url' => $detail, 'class' => 'page_activator', 'icon' => 'ni ni-eye' ],
    [ 'title' => 'داشبورد کمپین', 'url' => home_url( $detail . 'dashboard/' ), 'data_url' => $detail . 'dashboard/', 'class' => 'page_activator', 'icon' => 'ni ni-growth' ],
];
if ( kerp_can( 'marketing.delete', 'action' ) ) $actions[] = [ 'title' => 'حذف درخواست', 'icon' => 'ni ni-trash', 'class' => 'text-danger', 'data' => [ 'bs-toggle' => 'modal', 'bs-target' => '#marketingDeleteRequest' . (int) $row['id'] ] ];
KERP_Helpers_Template::render_template( 'app/components/list/row-actions.php', [ 'display' => 'inline', 'actions' => $actions ] );
?></div>
</div><?php endforeach; ?></div>
<?php if ( ! $result['items'] ) : ?><div class="card-inner text-center py-5"><em class="icon ni ni-growth fs-1 text-soft"></em><h5 class="mt-3">درخواستی پیدا نشد</h5><p class="text-soft mb-0">فیلترها را تغییر دهید یا اولین درخواست تبلیغ را ثبت کنید.</p></div><?php endif; ?>
<?php if ( $result['pages'] > 1 ) : ?><div class="card-inner border-top"><?php KERP_Helpers_Template::render_template( 'app/components/list/pagination.php', [ 'max_page_num' => $result['pages'], 'current_page' => $result['page'], 'class_name' => 'marketing_pagination_link', 'show_count' => 2, 'action' => 'erp_request_page_content', 'page' => $route ] ); ?></div><?php endif; ?>
</div>
<?php foreach ( $result['items'] as $row ) $view::delete_modal( $row ); ?>
<?php if ( kerp_can( 'marketing.create', 'action' ) ) $view::request_modal(); ?>
</div>




