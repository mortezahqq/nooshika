<?php
defined( 'ABSPATH' ) || exit;
if ( ! kerp_can( 'marketing.pay', 'action' ) ) { echo '<div class="alert alert-warning">دسترسی ثبت پرداخت را ندارید.</div>'; return; }
$marketing_section = 'finance'; $marketing_title = 'کارتابل مالی تبلیغات';
require __DIR__ . '/index.php';
