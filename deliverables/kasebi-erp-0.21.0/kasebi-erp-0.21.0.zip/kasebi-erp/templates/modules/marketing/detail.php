<?php
defined( 'ABSPATH' ) || exit;
$is_campaign_dashboard = $is_campaign_dashboard ?? false;
$store = KERP_Modules_Marketing_Store::class; $view = KERP_Modules_Marketing_View::class;
$unit = $view::money_label( $row['currency'] );
$metrics = $store::metrics( $row );
$sources = $store::sources( $row );
$entries = json_decode( $row['metric_entries'] ?? '[]', true ) ?: [];
$can_sources = kerp_can( 'marketing.edit', 'action' ) || kerp_can( 'marketing.metrics', 'action' );
$totals = $store::totals( $metrics );
$history = json_decode( $row['history'] ?? '[]', true ) ?: [];
$review = kerp_can( 'marketing.review', 'action' ) && $row['status'] === 'pending';
$pay = kerp_can( 'marketing.pay', 'action' ) && $row['status'] === 'finance';
$can_metrics = $view::metrics_editable( $row );
?>
<div class="kerp-marketing marketing-interior">
<nav class="marketing-page-nav d-flex flex-wrap gap-2 mb-3" aria-label="صفحات کمپین">
<?php foreach ( [ '' => 'جزئیات درخواست', 'dashboard/' => 'داشبورد کمپین' ] as $suffix => $label ) : $url = '/erp/marketing/requests/' . (int) $row['id'] . '/' . $suffix; ?>
<a class="btn btn-outline-primary page_activator" <?php echo ( $is_campaign_dashboard === ( $suffix !== '' ) ) ? 'aria-current="page"' : ''; ?> data-url="<?php echo esc_attr( $url ); ?>" href="<?php echo esc_url( home_url( $url ) ); ?>"><?php echo esc_html( $label ); ?></a>
<?php endforeach; ?></nav><div class="nk-block-head marketing-page-hero"><div class="nk-block-between g-3"><div><span class="overline-title">درخواست #<?php echo (int) $row['id']; ?></span><h3 class="nk-block-title"><?php echo esc_html( $row['title'] ); ?></h3><p class="text-soft mb-0"><?php echo esc_html( $row['ad_type'] . ' · ' . $row['platform'] ); ?></p></div><span class="badge marketing-status" data-status="<?php echo esc_attr( $row['status'] ); ?>"><?php echo esc_html( $store::statuses()[$row['status']] ); ?></span></div></div>
<div class="card card-bordered mb-4"><div class="card-inner"><div class="d-flex justify-content-between align-items-center flex-wrap gap-2"><h6 class="mb-0">منابع کمپین</h6><?php if ( $can_sources ) : ?><button class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#marketingSourceModal">افزودن منبع</button><?php endif; ?></div><div class="d-flex flex-wrap gap-2 mt-3"><?php foreach ( $sources as $name ) : ?><span class="badge marketing-status"><?php echo esc_html( $name ); ?></span><?php endforeach; ?></div></div></div>
<?php if ( ! $is_campaign_dashboard ) : ?><div class="card card-bordered mb-4"><div class="card-inner">
<div class="kerp-marketing-flow"><span class="marketing-icon-label"><em class="icon ni ni-user" aria-hidden="true"></em><span>ثبت کارشناس</span></span><em class="icon marketing-flow-chevron" aria-hidden="true"></em><span>تأیید مدیر مارکتینگ</span><em class="icon marketing-flow-chevron" aria-hidden="true"></em><span>پرداخت مالی</span><em class="icon marketing-flow-chevron" aria-hidden="true"></em><span>تحلیل کمپین</span></div>
<div class="row g-3 mt-2 marketing-record-meta">
<?php foreach ( [ 'ثبت‌کننده' => get_user_name_by_id( $row['created_by'] ), 'تاریخ اجرا' => $view::jalali( $row['execution_date'] ) ] as $label => $value ) : ?><div class="col-6 col-lg-3"><span class="sub-text"><?php echo esc_html( $label ); ?></span><strong><?php echo wp_kses_post( $value ); ?></strong></div><?php endforeach; ?>
</div><div class="d-flex flex-wrap gap-2 mt-4">
<?php if ( $view::editable( $row ) ) : ?><button class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#marketingRequestModal">اصلاح و ارسال مجدد</button><?php $view::request_modal( $row ); endif; ?>
<?php if ( $review ) : ?><button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#marketingReviewModal">بررسی و ارجاع به مالی</button><?php endif; ?>
<?php if ( $pay ) : ?><button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#marketingPayModal">ثبت پرداخت <?php echo $view::money( $row['cost'], $row['currency'] ); ?></button><?php endif; ?>
<?php if ( kerp_can( 'marketing.complete', 'action' ) && $row['status'] === 'paid' ) : ?><button class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#marketingCompleteModal">اعلام پایان کمپین</button><?php endif; ?>
</div>
<?php if ( $row['payment_reference'] !== '' ) : ?><div class="alert alert-success mt-3 mb-0">مرجع پرداخت: <?php echo esc_html( $row['payment_reference'] ); ?></div><?php endif; ?>
</div></div>
<?php endif; if ( $is_campaign_dashboard ) : ?><h5 class="mb-3">برآورد پیش از اجرا</h5><div class="row g-3 mb-4">
<?php foreach ( [ 'بودجه · ' . $unit => $view::money( $row['cost'], $row['currency'] ), 'مشتری بالقوه پیش‌بینی‌شده' => $view::display( $row['expected_leads'] ), 'فروش پیش‌بینی‌شده · ' . $unit => $view::money( $row['expected_sales'], $row['currency'] ), 'ROI پیش‌بینی‌شده · برابر' => $view::display( $store::ratio( (float) $row['expected_sales'], (float) $row['cost'] ), 2 ) ] as $label => $value ) : ?>
<div class="col-6 col-xl-3"><div class="card card-bordered h-100 marketing-metric-card"><div class="card-inner"><span class="sub-text"><?php echo esc_html( $label ); ?></span><strong class="fs-24px d-block text-primary"><?php echo wp_kses_post( $value ); ?></strong></div></div></div><?php endforeach; ?></div>
<div class="nk-block-head nk-block-head-sm"><div class="nk-block-between g-3"><div><h5>داشبورد عملکرد کمپین</h5><p class="text-soft mb-0">ثبت دستی به تفکیک منبع؛ مبلغ‌ها به <?php echo esc_html( $unit ); ?>. جمع درصدها از مجموع تعدادها محاسبه می‌شود.</p></div><?php if ( $can_metrics ) : ?><button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#marketingMetricModal">ثبت آمار روزانه</button><?php endif; ?></div></div>
<?php if ( $metrics ) : ?>
<div class="row g-3 mb-4"><?php foreach ( [ 'مشتری بالقوه واقعی' => $view::display( $totals['numbers'] ), 'کلیک روی لینک' => $view::display( $totals['online'] ), 'تکمیل فرم کمپین' => $view::display( $totals['pre_reg'] ), 'ROI واقعی · برابر' => $view::display( $store::ratio( $totals['sales'], $totals['cost'] ), 2 ) ] as $label => $value ) : ?><div class="col-6 col-xl-3"><div class="card card-bordered h-100 marketing-metric-card"><div class="card-inner"><span class="sub-text"><?php echo esc_html( $label ); ?></span><strong class="fs-24px d-block"><?php echo wp_kses_post( $value ); ?></strong></div></div></div><?php endforeach; ?></div>
<?php endif; ?>
<?php if ( $entries ) : ?><div class="card card-bordered mb-4"><div class="card-inner"><h6>آمار ثبت‌شده به تفکیک روز</h6><p class="text-soft mb-0">برای اصلاح، منبع و تاریخ همین ردیف را در فرم آمار روزانه انتخاب کنید.</p></div><div class="nk-tb-list kerp-marketing-metrics"><div class="nk-tb-item nk-tb-head"><?php foreach ( [ 'تاریخ', 'منبع' ] as $label ) : ?><div class="nk-tb-col"><?php echo esc_html( $label ); ?></div><?php endforeach; ?><?php foreach ( $store::metric_fields() as $label ) : ?><div class="nk-tb-col"><?php echo esc_html( $label ); ?></div><?php endforeach; ?></div><?php $daily_rows = array_values( $entries ); usort( $daily_rows, static fn( $a, $b ) => strcmp( $b['date'], $a['date'] ) ); foreach ( $daily_rows as $entry ) : ?><div class="nk-tb-item"><div class="nk-tb-col" data-label="تاریخ"><bdi dir="ltr"><?php echo esc_html( $view::jalali( $entry['date'] ) ); ?></bdi></div><div class="nk-tb-col" data-label="منبع"><?php echo esc_html( $entry['source'] ); ?></div><?php foreach ( $store::metric_fields() as $key => $label ) : ?><div class="nk-tb-col" data-label="<?php echo esc_attr( $label ); ?>"><?php echo in_array( $key, [ 'cost', 'sales' ], true ) ? $view::money( $entry[$key], $row['currency'] ) : esc_html( $view::display( $entry[$key] ) ); ?></div><?php endforeach; ?></div><?php endforeach; ?></div></div><?php endif; ?>
<?php if ( ! empty( json_decode( $row['metrics'] ?? '[]', true ) ) ) : ?><div class="alert alert-info">آمار قبلی بدون تاریخ حفظ شده و در جمع عملکرد لحاظ می‌شود. روزهای پوشش‌داده‌شده در آمار قبلی را دوباره ثبت نکنید.</div><?php endif; ?>
<div class="card card-bordered mb-4"><div class="card-inner"><h6>مقایسه منابع جذب</h6><p class="text-soft mb-0">درصد کلیک = کلیک ÷ مشتری بالقوه؛ درصد فرم = تکمیل فرم ÷ مشتری بالقوه؛ هزینه هر مشتری بالقوه = هزینه ÷ مشتری بالقوه؛ CAC فرم = هزینه ÷ تکمیل فرم. مخرج صفر با «—» نمایش داده می‌شود.</p></div>
<div class="nk-tb-list kerp-marketing-metrics"><div class="nk-tb-item nk-tb-head"><?php foreach ( [ 'منبع', 'مشتری بالقوه', 'کلیک / درصد', 'فرم / درصد', 'هزینه', 'هزینه هر مشتری بالقوه', 'CAC فرم', 'فروش' ] as $label ) : ?><div class="nk-tb-col"><?php echo esc_html( $label ); ?></div><?php endforeach; ?></div>
<?php foreach ( $metrics ? array_merge( array_values( $metrics ), [ [ 'source' => 'جمع کل' ] + $totals ] ) : [] as $metric ) :
$cells = [ 'منبع' => $metric['source'], 'مشتری بالقوه' => $view::display( $metric['numbers'] ), 'کلیک / درصد' => $view::display( $metric['online'] ) . ' / ' . $view::display( $store::ratio( (float) $metric['online'], (float) $metric['numbers'], 100 ), 1 ) . '٪', 'فرم / درصد' => $view::display( $metric['pre_reg'] ) . ' / ' . $view::display( $store::ratio( (float) $metric['pre_reg'], (float) $metric['numbers'], 100 ), 1 ) . '٪', 'هزینه' => $view::money( $metric['cost'], $row['currency'] ), 'هزینه هر مشتری بالقوه' => $view::money( $store::ratio( (float) $metric['cost'], (float) $metric['numbers'] ), $row['currency'] ), 'CAC فرم' => $view::money( $store::ratio( (float) $metric['cost'], (float) $metric['pre_reg'] ), $row['currency'] ), 'فروش' => $view::money( $metric['sales'], $row['currency'] ) ]; ?>
<div class="nk-tb-item"><?php foreach ( $cells as $label => $value ) : ?><div class="nk-tb-col" data-label="<?php echo esc_attr( $label ); ?>"><?php echo in_array( $label, [ 'هزینه', 'هزینه هر مشتری بالقوه', 'CAC فرم', 'فروش' ], true ) ? wp_kses_post( $value ) : esc_html( $value ); ?></div><?php endforeach; ?></div>
<?php endforeach; ?></div>
<?php if ( ! $metrics ) : ?><div class="card-inner text-center py-5"><em class="icon ni ni-bar-chart-alt fs-1 text-soft"></em><h5 class="mt-3">هنوز عملکردی ثبت نشده</h5><p class="text-soft mb-0">پس از ثبت پرداخت، آمار هر منبع را وارد کنید تا تحلیل واقعی کمپین نمایش داده شود.</p></div><?php endif; ?>
</div>
<?php if ( $metrics ) : ?><div class="card card-bordered mb-4"><div class="card-inner"><h6 class="mb-3">سهم هر منبع از تکمیل فرم‌ها</h6><?php foreach ( $metrics as $metric ) : $percent = $store::ratio( (float) $metric['pre_reg'], $totals['pre_reg'], 100 ) ?? 0; ?><div class="mb-3"><div class="d-flex justify-content-between gap-2"><span><?php echo esc_html( $metric['source'] ); ?></span><strong><?php echo esc_html( $view::display( $percent, 1 ) ); ?>٪</strong></div><div class="progress progress-md mt-1"><div class="progress-bar bg-primary" role="progressbar" aria-label="<?php echo esc_attr( $metric['source'] ); ?>" aria-valuenow="<?php echo esc_attr( round( $percent, 1 ) ); ?>" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo esc_attr( round( $percent, 2 ) ); ?>%"></div></div></div><?php endforeach; ?></div></div><?php endif; ?>
<?php endif; if ( ! $is_campaign_dashboard ) : ?><div class="card card-bordered"><div class="card-inner"><h6>تاریخچه درخواست</h6><ul class="list-unstyled mb-0 marketing-history"><?php foreach ( array_reverse( $history ) as $event ) : ?><li class="py-3 border-bottom"><strong><?php echo esc_html( $event['event'] ); ?></strong><span class="sub-text"><?php echo esc_html( get_user_name_by_id( $event['actor'] ) . ' · ' . KERP_Helpers_Date::local_datetime_to_jalali( $event['at'] ) ); ?></span><?php if ( $event['note'] !== '' ) : ?><div class="mb-0 mt-1 marketing-payment-note"><?php echo ( $event['note_format'] ?? '' ) === 'html' ? wp_kses_post( $event['note'] ) : esc_html( $event['note'] ); ?></div><?php endif; ?><?php foreach ( (array) ( $event['files'] ?? [] ) as $file ) : ?><a class="btn btn-sm btn-outline-primary mt-2 me-2" href="<?php echo esc_url( $file ); ?>" target="_blank" rel="noopener noreferrer">پیوست پرداخت · <?php echo esc_html( rawurldecode( wp_basename( $file ) ) ); ?></a><?php endforeach; ?></li><?php endforeach; ?></ul></div></div>
<?php
endif;
if ( $review ) $view::modal( 'marketingReviewModal', 'بررسی مدیر مارکتینگ', 'transition', $view::fields( [ 'operation' => [ 'label' => 'تصمیم', 'type' => 'select', 'options' => [ 'approve' => 'تأیید و ارجاع به مالی', 'reject' => 'برگشت به کارشناس برای اصلاح' ] ], 'note' => [ 'label' => 'توضیح (برای برگشت الزامی)', 'type' => 'textarea', 'required' => false ] ], 'marketing-review' ), $row );
if ( $pay ) $view::modal( 'marketingPayModal', 'ثبت پرداخت انجام‌شده', 'transition', array_merge( [ $view::hidden( 'operation', 'pay' ) ], $view::fields( [ 'payment_reference' => 'شماره پیگیری / مرجع پرداخت', 'note' => [ 'label' => 'توضیح پرداخت', 'type' => 'quill', 'required' => false ], 'payment_files' => [ 'label' => 'پیوست پرداخت', 'type' => 'upload', 'action' => 'marketing_upload', 'max_files' => 3, 'required' => false ] ], 'marketing-pay' ) ), $row, '', 'مبلغ مصوب: ' . $view::display( $row['cost'] ) . ' ' . $unit . '. این فرم ثبت پرداخت انجام‌شده است و انتقال بانکی انجام نمی‌دهد.' );
if ( kerp_can( 'marketing.complete', 'action' ) && $row['status'] === 'paid' ) $view::modal( 'marketingCompleteModal', 'پایان کمپین', 'transition', [ $view::hidden( 'operation', 'complete' ) ], $row );
if ( $can_sources ) $view::modal( 'marketingSourceModal', 'افزودن منبع کمپین', 'sources', $view::fields( [ 'source_name' => 'نام منبع جدید' ], 'marketing-source' ), $row );
if ( $can_metrics ) {
	$definitions = [ 'source_id' => [ 'label' => 'منبع کمپین', 'type' => 'select', 'options' => $sources, 'placeholder' => 'انتخاب منبع' ], 'metric_date' => [ 'label' => 'تاریخ عملکرد', 'type' => 'date' ] ];
	foreach ( $store::metric_fields() as $key => $label ) $definitions[$key] = [ 'label' => $label, 'type' => in_array( $key, [ 'cost', 'sales' ], true ) ? 'price' : 'number' ];
	$daily_data = [];
	foreach ( $entries as $key => $entry ) $daily_data[] = $entry + [ 'entry_key' => $key, 'jalali_date' => $view::jalali( $entry['date'] ) ];
	$body = '<div class="col-12" data-marketing-daily="' . esc_attr( wp_json_encode( $daily_data ) ) . '"><p class="text-soft mb-0" data-marketing-daily-hint>منبع و تاریخ را انتخاب کنید و فقط آمار همان روز را وارد کنید.</p></div>';
	$fields = $view::fields( $definitions, 'marketing-metric' );
	$fields[] = $view::hidden( 'entry_key', '' );
	$view::modal( 'marketingMetricModal', 'ثبت / اصلاح آمار روزانه', 'metric', $fields, $row, $body );
}

?>
</div>




