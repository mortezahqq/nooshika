<?php
defined( 'ABSPATH' ) || exit;
$store = KERP_Modules_Marketing_Store::class; $view = KERP_Modules_Marketing_View::class;
if ( ! $store::can_view() ) return;
global $wpdb;
$summary = $wpdb->get_results( 'SELECT status,COUNT(*) AS total FROM ' . $store::table() . ' WHERE ' . $store::scope() . ' GROUP BY status', ARRAY_A );
$counts = array_fill_keys( array_keys( $store::statuses() ), 0 );
foreach ( $summary as $item ) $counts[$item['status']] = (int) $item['total'];
$budgets = $wpdb->get_results( 'SELECT currency,SUM(cost) AS budget,SUM(expected_sales) AS sales FROM ' . $store::table() . ' WHERE ' . $store::scope() . " AND status IN ('finance','paid','completed') GROUP BY currency", ARRAY_A );
$recent = $store::find( [], 5 );
$today = current_datetime()->setTime( 0, 0 );
$start = $today->modify( '-13 days' );
$days = []; $day_labels = [];
for ( $i = 0; $i < 14; $i++ ) {
    $day = $start->modify( '+' . $i . ' days' );
    $days[$day->format( 'Y-m-d' )] = 0;
    $day_labels[] = substr( $view::jalali( $day->format( 'Y-m-d' ) ), 5 );
}
$trend = $wpdb->get_results( $wpdb->prepare( 'SELECT DATE(created_at) AS day,COUNT(*) AS total FROM ' . $store::table() . ' WHERE ' . $store::scope() . ' AND created_at >= %s AND created_at < %s GROUP BY DATE(created_at)', $start->format( 'Y-m-d H:i:s' ), $today->modify( '+1 day' )->format( 'Y-m-d H:i:s' ) ), ARRAY_A );
foreach ( $trend as $point ) if ( isset( $days[$point['day']] ) ) $days[$point['day']] = (int) $point['total'];
$total = array_sum( $counts );
$colors = [ 'pending' => '#f5a524', 'rejected' => '#ef6478', 'finance' => '#8b6cf6', 'paid' => '#3291ff', 'completed' => '#20b99a', 'archived' => '#94a3b8' ];
?>
<div class="kerp-marketing kerp-marketing-dashboard">
<div class="marketing-dashboard-hero">
<div class="nk-block-head"><div class="nk-block-between g-3"><div><span class="overline-title text-primary">مارکتینگ</span><h3 class="nk-block-title">داشبورد تبلیغات</h3><p class="text-soft">نمای کلی درخواست‌های مرتبط با شما، از برنامه‌ریزی تا اجرای کمپین</p></div>
<?php if ( kerp_can( 'marketing.create', 'action' ) ) : ?><button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#marketingRequestModal"><em class="icon ni ni-plus"></em><span>درخواست جدید</span></button><?php endif; ?></div></div>
<div class="marketing-dashboard-context"><span class="marketing-icon-label"><em class="icon ni ni-layers" aria-hidden="true"></em><span><bdi dir="ltr"><?php echo esc_html( $view::display( $total ) ); ?></bdi> درخواست در دسترس</span></span><span class="marketing-icon-label"><em class="icon ni ni-calendar" aria-hidden="true"></em><bdi dir="ltr"><?php echo esc_html( $view::jalali( $today->format( 'Y-m-d' ) ) ); ?></bdi></span></div></div>
<div class="row g-3 mb-4"><?php foreach ( [ 'pending' => [ 'در انتظار تأیید', 'ni ni-clock' ], 'finance' => [ 'در انتظار پرداخت', 'ni ni-wallet' ], 'paid' => [ 'پرداخت‌شده', 'ni ni-check-circle' ], 'completed' => [ 'پایان‌یافته', 'ni ni-growth' ] ] as $key => $stat ) : ?><div class="col-6 col-xl-3"><div class="card card-bordered h-100 marketing-kpi" style="--marketing-accent:<?php echo esc_attr( $colors[$key] ); ?>"><div class="card-inner"><div class="marketing-kpi-top"><span class="sub-text"><?php echo esc_html( $stat[0] ); ?></span><span class="marketing-kpi-icon"><em class="icon <?php echo esc_attr( $stat[1] ); ?>"></em></span></div><strong class="marketing-kpi-value"><?php echo esc_html( $view::display( $counts[$key] ) ); ?></strong><span class="marketing-kpi-foot">از <?php echo esc_html( $view::display( $total ) ); ?> درخواست</span></div></div></div><?php endforeach; ?></div>
<div class="marketing-charts-grid mb-4">
<section class="card card-bordered"><div class="card-inner"><div class="marketing-chart-heading"><div><h5>روند ثبت درخواست‌ها</h5><p class="text-soft mb-0">۱۴ روز اخیر · تعداد درخواست‌های جدید</p></div><span class="marketing-period">۱۴ روز</span></div><div class="marketing-trend-summary"><strong><?php echo esc_html( $view::display( array_sum( $days ) ) ); ?></strong><span class="text-soft">درخواست در این بازه</span></div>
<?php if ( array_sum( $days ) > 0 ) : ?><div class="marketing-chart-canvas"><div class="kasebi-chart" data-chart-type="area" data-legend="0" data-grid="0" data-color="#3291ff" data-tension="0" data-point-radius="3" data-label="درخواست جدید" data-unit="درخواست" data-labels="<?php echo esc_attr( wp_json_encode( $day_labels ) ); ?>" data-data="<?php echo esc_attr( wp_json_encode( array_values( $days ) ) ); ?>" role="img" aria-label="روند روزانه ثبت درخواست در ۱۴ روز اخیر"></div></div><details class="marketing-chart-data"><summary>مشاهده اعداد نمودار</summary><div class="marketing-day-values"><?php foreach ( array_values( $days ) as $index => $count ) : ?><span><?php echo esc_html( $day_labels[$index] . ': ' . $view::display( $count ) ); ?></span><?php endforeach; ?></div></details>
<?php else : ?><div class="marketing-chart-empty"><em class="icon ni ni-bar-chart-alt"></em><strong>در این بازه درخواستی ثبت نشده</strong><span class="text-soft">روند روزانه با ثبت درخواست جدید نمایش داده می‌شود.</span></div><?php endif; ?></div></section>
<section class="card card-bordered"><div class="card-inner"><div class="marketing-chart-heading"><div><h5>وضعیت درخواست‌ها</h5><p class="text-soft mb-0">تعداد و سهم هر وضعیت از کل درخواست‌ها</p></div></div>
<ul class="marketing-status-bars" aria-label="نمودار میله‌ای وضعیت درخواست‌ها"><?php foreach ( $store::statuses() as $key => $label ) : $share = $total > 0 ? round( $counts[$key] / $total * 100, 1 ) : 0; ?><li style="--marketing-accent:<?php echo esc_attr( $colors[$key] ); ?>"><div class="marketing-status-label"><span><?php echo esc_html( $label ); ?></span><span><strong><?php echo esc_html( $view::display( $counts[$key] ) ); ?></strong><small><?php echo esc_html( $view::display( $share ) ); ?>٪</small></span></div><div class="marketing-status-track" aria-hidden="true"><span style="width:<?php echo esc_attr( $share ); ?>%"></span></div></li><?php endforeach; ?></ul>
<?php if ( ! $total ) : ?><p class="marketing-status-note text-soft mb-0">با ثبت اولین درخواست، سهم وضعیت‌ها نمایش داده می‌شود.</p><?php endif; ?></div></section>
</div>
<div class="row g-3 mb-4"><?php foreach ( [ 'requests' => [ 'درخواست‌های تبلیغات', 'مشاهده و پیگیری تمام درخواست‌های مرتبط', 'ni ni-list' ], 'inbox' => [ 'کارتابل من', 'درخواست‌هایی که منتظر اقدام شما هستند', 'ni ni-inbox' ] ] as $key => $item ) : ?><div class="col-md-6"><div class="card card-bordered h-100"><a class="marketing-inbox page_activator" href="<?php echo esc_url( home_url( '/erp/marketing/' . $key . '/' ) ); ?>" data-url="/erp/marketing/<?php echo esc_attr( $key ); ?>/"><div class="card-inner"><em class="icon text-primary <?php echo esc_attr( $item[2] ); ?>"></em><h5 class="mt-2"><?php echo esc_html( $item[0] ); ?></h5><p class="text-soft mb-0"><?php echo esc_html( $item[1] ); ?></p></div></a></div></div><?php endforeach; ?></div>
<?php foreach ( $budgets as $budget ) : ?><div class="card card-bordered mb-4"><div class="card-inner"><h6>برآورد کمپین‌های تأییدشده · <?php echo esc_html( $view::money_label( $budget['currency'] ) ); ?></h6><div class="row g-3"><div class="col-sm-6"><span class="sub-text">بودجه مصوب</span><strong class="fs-24px"><?php echo $view::money( $budget['budget'], $budget['currency'] ); ?></strong></div><div class="col-sm-6"><span class="sub-text">فروش برآوردی</span><strong class="fs-24px"><?php echo $view::money( $budget['sales'], $budget['currency'] ); ?></strong></div></div></div></div><?php endforeach; ?>
<div class="card card-bordered"><div class="card-inner"><h5>آخرین کمپین‌ها</h5><p class="text-soft">داشبورد هر کمپین در برگه مستقل در دسترس است.</p></div>
<?php foreach ( $recent['items'] as $item ) : $url = '/erp/marketing/requests/' . (int) $item['id'] . '/dashboard/'; ?><div class="card-inner border-top d-flex justify-content-between gap-3 flex-wrap kerp-marketing-recent"><div><strong><?php echo esc_html( $item['title'] ); ?></strong><span class="sub-text"><?php echo esc_html( $store::statuses()[$item['status']] ); ?></span></div><a class="btn btn-outline-primary page_activator" data-url="<?php echo esc_attr( $url ); ?>" href="<?php echo esc_url( home_url( $url ) ); ?>">داشبورد کمپین</a></div><?php endforeach; ?>
<?php if ( ! $recent['items'] ) : ?><div class="card-inner text-center py-5"><em class="icon ni ni-growth fs-1"></em><h5 class="mt-3">هنوز کمپینی ثبت نشده</h5><p class="text-soft">با ثبت اولین درخواست، خلاصه وضعیت آن اینجا نمایش داده می‌شود.</p></div><?php endif; ?></div>
<?php if ( kerp_can( 'marketing.create', 'action' ) ) $view::request_modal(); ?>
</div>


