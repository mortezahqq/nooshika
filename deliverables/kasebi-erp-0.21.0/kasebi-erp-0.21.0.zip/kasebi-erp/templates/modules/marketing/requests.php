<?php
defined( 'ABSPATH' ) || exit;
$marketing_section = 'requests'; $marketing_title = 'درخواست‌های تبلیغات';
require __DIR__ . '/index.php';
