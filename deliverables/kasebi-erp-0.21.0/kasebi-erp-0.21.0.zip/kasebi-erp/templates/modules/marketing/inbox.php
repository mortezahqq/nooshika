<?php
defined( 'ABSPATH' ) || exit;
$marketing_section = 'inbox'; $marketing_title = 'کارتابل من';
require __DIR__ . '/index.php';
