<?php
defined( 'ABSPATH' ) || exit;
if ( ! kerp_can( 'marketing.review', 'action' ) ) { echo '<div class="alert alert-warning">دسترسی بررسی درخواست‌ها را ندارید.</div>'; return; }
$marketing_section = 'review'; $marketing_title = 'بررسی مدیر مارکتینگ';
require __DIR__ . '/index.php';
