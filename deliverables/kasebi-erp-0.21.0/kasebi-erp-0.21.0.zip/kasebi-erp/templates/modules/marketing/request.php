<?php
defined( 'ABSPATH' ) || exit;
$row = KERP_Modules_Marketing_Store::get( absint( $page_context['route_params']['request_id'] ?? 0 ) );
if ( ! $row ) { echo '<div class="alert alert-warning">درخواست پیدا نشد یا دسترسی ندارید.</div>'; return; }
$is_campaign_dashboard = $is_campaign_dashboard ?? false;
require __DIR__ . '/detail.php';
