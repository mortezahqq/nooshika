<?php

defined( 'ABSPATH' ) || exit;

if ( ! is_user_logged_in() ) {
	return;
}

$user_id     = get_current_user_id();
$page_number = max( 1, absint( $_GET['attendance_page'] ?? 1 ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
$per_page    = 12;
$result      = KERP_Modules_Online_Attendance_Query::instance()->find( [
	'user_id'     => $user_id,
	'page_number' => $page_number,
	'per_page'    => $per_page,
	'sort_order'  => 'newest',
] );
$rows        = (array) ( $result['items'] ?? [] );
$total       = absint( $result['total'] ?? 0 );
$total_pages = max( 1, absint( $result['total_pages'] ?? 1 ) );

$format_datetime = static function( string $value ): string {
	if ( $value === '' ) {
		return '—';
	}

	$local_datetime = get_date_from_gmt( $value, 'Y-m-d H:i:s' );
	$timestamp      = strtotime( $local_datetime );

	return $timestamp ? date_i18n( 'j F Y، H:i', $timestamp ) : '—';
};
?>
<section class="kerp-attendance-history" aria-labelledby="kerp-attendance-history-title">
    <header class="kerp-attendance-history__hero">
        <div>
            <span class="kerp-attendance-history__eyebrow"><?php esc_html_e( 'کلاس‌های آنلاین', 'kasebi-erp' ); ?></span>
            <h1 id="kerp-attendance-history-title"><?php esc_html_e( 'تاریخچه حضور من', 'kasebi-erp' ); ?></h1>
            <p><?php esc_html_e( 'زمان اولین حضور، آخرین ورود و تعداد دفعات دریافت لینک ورود به هر کلاس را اینجا می‌بینید.', 'kasebi-erp' ); ?></p>
        </div>
        <div class="kerp-attendance-history__summary" aria-label="<?php esc_attr_e( 'تعداد حضورهای ثبت‌شده', 'kasebi-erp' ); ?>">
            <em class="uik fa-presentation" aria-hidden="true"></em>
            <strong><?php echo esc_html( number_format_i18n( $total ) ); ?></strong>
            <span><?php esc_html_e( 'کلاس', 'kasebi-erp' ); ?></span>
        </div>
    </header>

	<?php if ( empty( $rows ) ) : ?>
        <div class="kerp-attendance-history__empty">
            <em class="uik fa-presentation" aria-hidden="true"></em>
            <h2><?php esc_html_e( 'هنوز حضوری ثبت نشده است', 'kasebi-erp' ); ?></h2>
            <p><?php esc_html_e( 'بعد از دریافت لینک ورود کلاس، سابقه حضور شما در این صفحه ثبت می‌شود.', 'kasebi-erp' ); ?></p>
        </div>
	<?php else : ?>
        <div class="kerp-attendance-history__grid">
			<?php foreach ( $rows as $attendance ) :
				$post_id    = absint( $attendance['post_id'] ?? 0 );
				$class_name = (string) ( $attendance['post_title'] ?: '#' . $post_id );
				$course     = (string) ( $attendance['course_title'] ?: '—' );
				$type       = ( $attendance['post_type'] ?? '' ) === 'sfwd-topic' ? __( 'سرفصل', 'kasebi-erp' ) : __( 'درس', 'kasebi-erp' );
				$first      = $format_datetime( (string) ( $attendance['joined_at'] ?? '' ) );
				$last       = $format_datetime( (string) ( $attendance['last_joined_at'] ?? '' ) );
				$count      = max( 1, absint( $attendance['join_count'] ?? 1 ) );
				?>
                <article class="kerp-attendance-card">
                    <div class="kerp-attendance-card__head">
                        <span class="kerp-attendance-card__icon"><em class="uik fa-presentation" aria-hidden="true"></em></span>
                        <div><span class="kerp-attendance-card__type"><?php echo esc_html( $type ); ?></span><h2><?php echo esc_html( $class_name ); ?></h2></div>
                    </div>
                    <div class="kerp-attendance-card__course"><em class="hik-r fa-display-1" aria-hidden="true"></em><span><?php echo esc_html( $course ); ?></span></div>
                    <dl class="kerp-attendance-card__details">
                        <div><dt><?php esc_html_e( 'اولین حضور', 'kasebi-erp' ); ?></dt><dd><?php echo esc_html( $first ); ?></dd></div>
                        <div><dt><?php esc_html_e( 'آخرین ورود', 'kasebi-erp' ); ?></dt><dd><?php echo esc_html( $last ); ?></dd></div>
                        <div><dt><?php esc_html_e( 'تعداد ورود', 'kasebi-erp' ); ?></dt><dd><?php printf( esc_html__( '%s مرتبه', 'kasebi-erp' ), esc_html( number_format_i18n( $count ) ) ); ?></dd></div>
                    </dl>
                </article>
			<?php endforeach; ?>
        </div>

		<?php if ( $total_pages > 1 ) :
			$pagination = paginate_links( [
				'base'      => add_query_arg( 'attendance_page', '%#%', home_url( '/panel/online-attendance/' ) ),
				'format'    => '',
				'current'   => $page_number,
				'total'     => $total_pages,
				'type'      => 'list',
				'prev_text' => '‹',
				'next_text' => '›',
			] );
			?>
            <nav class="kerp-attendance-history__pagination" aria-label="<?php esc_attr_e( 'صفحه‌بندی تاریخچه حضور', 'kasebi-erp' ); ?>"><?php echo wp_kses_post( $pagination ); ?></nav>
		<?php endif; ?>
	<?php endif; ?>
</section>
