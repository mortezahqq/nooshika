<?php
defined( 'ABSPATH' ) || exit;

$page_context = isset( $page_context ) && is_array( $page_context ) ? $page_context : [];
$page_query = isset( $page_context['query'] ) && is_array( $page_context['query'] ) ? $page_context['query'] : [];
unset( $page_query['user_id'] );
$joined = isset( $page_query['joined'] ) && is_array( $page_query['joined'] ) ? $page_query['joined'] : [];
$page_route = '/erp/online-attendance/';
$per_page = KERP_Helpers_Pagination::resolve_per_page( 'online_attendance', $page_query, 20, 200 );
$sort_options = KERP_Modules_Online_Attendance_List_Table::instance()->get_sort_options();
$sort_order = sanitize_key( (string) ( $page_query['sort_order'] ?? 'newest' ) );
$sort_order = isset( $sort_options[ $sort_order ] ) ? $sort_order : 'newest';
$query_args = [
	'post_id' => absint( $page_query['post_id'] ?? 0 ),
	'course_id' => absint( $page_query['course_id'] ?? 0 ), 'room_slug' => sanitize_text_field( (string) ( $page_query['room_slug'] ?? '' ) ),
	'search' => sanitize_text_field( (string) ( $page_query['search'] ?? '' ) ), 'date_from' => sanitize_text_field( (string) ( $joined['from'] ?? '' ) ),
	'date_to' => sanitize_text_field( (string) ( $joined['to'] ?? '' ) ), 'page_number' => max( 1, absint( $page_query['page_number'] ?? 1 ) ),
	'per_page' => $per_page, 'sort_order' => $sort_order,
];
$result = KERP_Modules_Online_Attendance_Query::instance()->find( $query_args );
$rows = (array) ( $result['items'] ?? [] );
$total = absint( $result['total'] ?? 0 );
$page_number = max( 1, absint( $result['page_number'] ?? 1 ) );
$total_pages = max( 1, absint( $result['total_pages'] ?? 1 ) );
$filters = KERP_Modules_Online_Attendance_List_Table::instance()->get_filters( array_merge( $page_query, [ 'joined' => $joined ] ) );
$has_filter = ! empty( array_filter( [ $query_args['post_id'], $query_args['course_id'], $query_args['room_slug'], $query_args['search'], $query_args['date_from'], $query_args['date_to'] ] ) );
$current_query = $page_query;
unset( $current_query['page_number'] );
?>
<div class="nk-block-head nk-block-head-sm"><div class="nk-block-between"><div class="nk-block-head-content">
    <h3 class="nk-block-title page-title"><?php esc_html_e( 'حضور و غیاب کلاس آنلاین', 'kasebi-erp' ); ?></h3>
    <div class="nk-block-des text-soft"><p><?php printf( esc_html__( 'در مجموع %s حضور ثبت شده است.', 'kasebi-erp' ), esc_html( number_format_i18n( $total ) ) ); ?></p></div>
</div></div></div>
<div class="nk-block"><div class="card card-stretch"><div class="card-inner-group">
    <div class="card-inner position-relative card-tools-toggle"><div class="card-title-group">
        <div class="card-tools"><span class="text-soft"><?php esc_html_e( 'فهرست حضورهای ثبت‌شده', 'kasebi-erp' ); ?></span></div>
        <div class="card-tools"><ul class="btn-toolbar gx-1">
            <li><div class="dropdown"><button type="button" class="btn btn-trigger btn-icon dropdown-toggle" data-bs-toggle="dropdown" title="<?php esc_attr_e( 'مرتب‌سازی', 'kasebi-erp' ); ?>"><em class="icon ni ni-swap-v"></em></button><div class="dropdown-menu dropdown-menu-end"><ul class="link-check"><li><span><?php esc_html_e( 'مرتب‌سازی', 'kasebi-erp' ); ?></span></li>
                <?php foreach ( $sort_options as $key => $label ) : $sort_url = add_query_arg( array_merge( $current_query, [ 'sort_order' => $key ] ), $page_route ); ?><li class="<?php echo $key === $sort_order ? 'active' : ''; ?>"><a href="<?php echo esc_attr( $sort_url ); ?>" class="page_activator" data-url="<?php echo esc_attr( $sort_url ); ?>"><?php echo esc_html( $label ); ?></a></li><?php endforeach; ?>
            </ul></div></div></li>
            <li class="btn-toolbar-sep"></li>
            <li><?php KERP_Helpers_Template::render_template( 'app/components/list/filter-dropdown.php', [ 'has_filter' => $has_filter, 'filter_fields' => $filters, 'action' => 'erp_request_page_content', 'page' => $page_route ] ); ?></li>
            <li class="btn-toolbar-sep"></li>
            <li><?php KERP_Helpers_Template::render_template( 'app/components/list/per-page-selector.php', [ 'per_page' => $per_page, 'available_per_pages' => [ 10, 20, 50, 100 ], 'action' => 'erp_request_page_content', 'page' => $page_route ] ); ?></li>
        </ul></div>
    </div></div>
    <div class="card-inner p-0"><div class="nk-tb-list nk-tb-ulist is-compact kerp-online-attendance-table kerp-online-attendance-table--main">
        <div class="nk-tb-item nk-tb-head">
            <div class="nk-tb-col kerp-attendance-user-col"><span class="sub-text"><?php esc_html_e( 'کاربر', 'kasebi-erp' ); ?></span></div>
            <div class="nk-tb-col kerp-attendance-learning-col"><span class="sub-text"><?php esc_html_e( 'کلاس و دوره', 'kasebi-erp' ); ?></span></div>
            <div class="nk-tb-col tb-col-md kerp-attendance-room-col"><span class="sub-text"><?php esc_html_e( 'اتاق کلاس', 'kasebi-erp' ); ?></span></div>
            <div class="nk-tb-col kerp-attendance-summary-col"><span class="sub-text"><?php esc_html_e( 'جزئیات حضور', 'kasebi-erp' ); ?></span></div>
        </div>
        <?php if ( empty( $rows ) ) { echo '</div>'; ?><div class="card-inner text-center py-5"><em class="uik fa-presentation fs-1 text-soft"></em><h5 class="mt-3 mb-1"><?php esc_html_e( 'رکورد حضوری پیدا نشد.', 'kasebi-erp' ); ?></h5><p class="text-soft mb-0"><?php esc_html_e( 'فیلترها را تغییر دهید یا پس از ورود کاربران دوباره بررسی کنید.', 'kasebi-erp' ); ?></p></div><div><?php } else { foreach ( $rows as $attendance ) { KERP_Helpers_Template::render_template( 'modules/online-attendance/partials/list-row.php', [ 'attendance' => $attendance ] ); } } ?>
    </div></div>
    <?php if ( $total_pages > 1 ) : ?><div class="card-inner border-top"><?php KERP_Helpers_Template::render_template( 'app/components/list/pagination.php', [ 'max_page_num' => $total_pages, 'current_page' => $page_number, 'class_name' => 'online_attendance_pagination_link', 'show_count' => 2, 'action' => 'erp_request_page_content', 'page' => $page_route ] ); ?></div><?php endif; ?>
</div></div></div>
