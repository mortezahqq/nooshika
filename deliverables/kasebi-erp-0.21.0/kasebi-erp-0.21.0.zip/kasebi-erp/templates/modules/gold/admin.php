<?php
defined( 'ABSPATH' ) || exit;
KERP_Modules_Gold_Admin::$return_url = home_url( '/erp/gold/' );
KERP_Modules_Gold_Admin::render();
