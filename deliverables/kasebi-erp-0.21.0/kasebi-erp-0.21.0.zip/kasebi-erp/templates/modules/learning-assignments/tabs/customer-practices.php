<?php

defined( 'ABSPATH' ) || exit;

if ( ! isset( $customer ) || ! $customer instanceof WP_User || ! kerp_can( 'learning_assignments.review', 'action' ) ) {
	return;
}

$customer_id  = absint( $customer_id ?? $customer->ID );
$page_query   = isset( $page_context['query'] ) && is_array( $page_context['query'] ) ? $page_context['query'] : [];
$route        = '/erp/customers/' . $customer_id . '/?tab=learning-assignments';
$store        = KERP_Modules_Learning_Assignments_Store::instance();
$migration    = KERP_Modules_Learning_Assignments_Migration::instance()->status();
$enabled      = KERP_Modules_Learning_Assignments_Settings::instance()->post_type_enabled();
$status       = sanitize_key( (string) ( $page_query['status'] ?? 'all' ) );
$labels       = [
	'pending'  => 'در انتظار بررسی',
	'approved' => 'تأییدشده',
	'rejected' => 'ردشده',
	'changed'  => 'جایگزین‌شده',
];

if ( ! isset( $labels[ $status ] ) ) {
	$status = 'all';
}

$practice_id = absint( $page_query['practice_id'] ?? 0 );
$per_page    = KERP_Helpers_Pagination::resolve_per_page( 'customer_practices', $page_query, 20 );
$page_number = max( 1, absint( $page_query['page_number'] ?? 1 ) );
$total       = $store->count_responses( $customer_id, $practice_id, $status === 'all' ? '' : $status, TRUE );
$max_pages   = max( 1, (int) ceil( $total / $per_page ) );
$page_number = min( $page_number, $max_pages );
$review_return_route = add_query_arg( [
	'status'      => $status,
	'practice_id' => $practice_id,
	'per_page'    => $per_page,
	'page_number' => $page_number,
], $route );
$rows        = $store->responses(
	$customer_id,
	$practice_id,
	$status === 'all' ? '' : $status,
	$per_page,
	( $page_number - 1 ) * $per_page,
	TRUE
);

$practice_options = [];
$practice_ids     = $store->review_practice_ids( $customer_id, TRUE );

foreach ( get_posts( [
	'post_type'      => KERP_Modules_Learning_Assignments_Module::POST_TYPE,
	'post_status'    => [ 'publish', 'draft' ],
	'posts_per_page' => -1,
	'post__in'       => $practice_ids ?: [ 0 ],
	'orderby'        => 'title',
	'order'          => 'ASC',
] ) as $practice ) {
	$practice_options[ $practice->ID ] = $practice->post_title;
}

$filters = [
	'status'      => [ 'type' => 'select', 'label' => 'وضعیت', 'value' => $status, 'options' => $labels ],
	'practice_id' => [
		'type'    => 'select',
		'label'   => 'تمرین',
		'value'   => $practice_id,
		'options' => $practice_options,
		'search'  => TRUE,
	],
];

$singular_label = KERP_Modules_Customers_Settings::instance()->get_singular_label();
$column_context = [
	'singular_label' => $singular_label,
	'enabled'        => $enabled,
	'route'          => $route,
	'customer_id'    => $customer_id,
];
$columns        = KERP_Modules_Learning_Assignments_Module::review_columns( $column_context );
unset( $columns['customer'], $columns['ncp_customer_extra'] );
?>
<div class="kerp-customer-tab-controls d-lg-none">
    <div class="kerp-customer-mobile-nav">
        <a href="#" class="toggle btn btn-icon btn-trigger" data-target="customerAside" aria-label="<?php esc_attr_e( 'نمایش منوی کاربر', 'kasebi-erp' ); ?>"><em class="icon ni ni-menu-alt-r"></em></a>
    </div>
</div>
<?php KERP_Helpers_Template::render_template( 'app/components/customer-tab-hero.php', [
	'icon'        => 'ni ni-file-text',
	'eyebrow'     => __( 'ارزیابی آموزشی', 'kasebi-erp' ),
	'title'       => __( 'تمرین‌های ارسالی', 'kasebi-erp' ),
	'description' => sprintf( __( 'در مجموع %s پاسخ برای این کاربر یافت شد.', 'kasebi-erp' ), number_format_i18n( $total ) ),
] ); ?>

<?php if ( ! $enabled ) : ?>
    <div class="nk-block">
        <div class="alert alert-warning alert-icon"><em class="icon ni ni-alert-circle"></em><span>پست‌تایپ تمرین غیرفعال است؛ پاسخ‌های قبلی فقط قابل مشاهده‌اند.</span>
        </div>
    </div>
<?php endif; ?>

<?php if ( $migration['remaining'] > 0 ) : ?>
    <div class="nk-block">
        <div class="alert alert-warning alert-icon"><em class="icon ni ni-alert-circle"></em><span>پاسخ‌های قدیمی منتقل‌نشده در این فهرست نمایش داده نمی‌شوند.</span>
        </div>
    </div>
<?php endif; ?>

<div class="nk-block">
    <div class="card card-stretch">
        <div class="card-inner-group">
            <div class="card-inner position-relative card-tools-toggle">
                <div class="card-title-group">
                    <div class="card-tools">
						<?php if ( $enabled ) {
							echo KERP_Helpers_Template::get_template( 'app/components/list/bulk-actions.php', [
								'actions'     => [
									'approved' => [ 'label' => 'تأیید پاسخ‌ها', 'icon' => 'ni ni-check-circle' ],
									'rejected' => [ 'label' => 'رد پاسخ‌ها', 'icon' => 'ni ni-cross-circle', 'need' => [ 'comment' ] ],
								],
								'need_fields' => [
									'comment' => [ 'type' => 'textarea', 'label' => 'دلیل رد', 'required' => TRUE ],
								],
								'action'      => 'kerp_practice_review_bulk',
								'page'        => $review_return_route,
							] );
						} ?>
                    </div>
                    <div class="card-tools">
                        <ul class="btn-toolbar gx-1">
                            <li><?php echo KERP_Helpers_Template::get_template( 'app/components/list/filter-dropdown.php', [
									'has_filter'    => $status !== 'all' || $practice_id > 0,
									'filter_fields' => $filters,
									'page'          => $route,
								] ); ?></li>
                            <li class="btn-toolbar-sep"></li>
                            <li><?php echo KERP_Helpers_Template::get_template( 'app/components/list/per-page-selector.php', [
									'per_page' => $per_page,
									'page'     => $route,
								] ); ?></li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="card-inner p-0">
                <div class="nk-tb-list nk-tb-ulist is-compact kerp-practice-reviews-table">
                    <div class="nk-tb-item nk-tb-head">
						<?php foreach ( $columns as $column_key => $column ) : ?>
                            <div class="nk-tb-col <?php echo esc_attr( trim( sanitize_text_field( (string) ( $column['class'] ?? '' ) ) . ' kerp-review-col kerp-review-col--' . sanitize_html_class( (string) $column_key ) ) ); ?>">
								<?php if ( ! empty( $column['header_callback'] ) && is_callable( $column['header_callback'] ) ) : ?>
									<?php call_user_func( $column['header_callback'], $column, $column_context ); ?>
								<?php elseif ( $column_key === 'select' ) : ?>
                                    <div class="custom-control custom-control-sm custom-checkbox notext">
                                        <input type="checkbox" class="custom-control-input select_all_rows"
                                               id="kerp-customer-practices-select-all"
                                               data-target=".select_item_row" <?php disabled( ! $enabled ); ?>>
                                        <label class="custom-control-label"
                                               for="kerp-customer-practices-select-all"></label>
                                    </div>
								<?php else : ?>
                                    <span class="sub-text"><?php echo esc_html( (string) ( $column['label'] ?? $column_key ) ); ?></span>
								<?php endif; ?>
                            </div>
						<?php endforeach; ?>
                    </div>

					<?php foreach ( $rows as $row ) {
						KERP_Helpers_Template::render_template( 'modules/learning-assignments/partials/review-row.php', [
							'row'            => $row,
							'labels'         => $labels,
							'enabled'        => $enabled,
							'singular_label' => $singular_label,
							'columns'        => $columns,
							'column_context' => $column_context,
						] );
					} ?>
                </div>
            </div>

			<?php if ( ! $rows ) : ?>
                <div class="card-inner text-center py-5">
                    <em class="icon ni ni-file-text fs-1 text-soft"></em>
                    <h5 class="mt-3 mb-1">پاسخی یافت نشد.</h5>
                    <p class="text-soft mb-0"><?php echo esc_html( $status !== 'all' || $practice_id ? 'فیلترها را تغییر دهید یا بازنشانی کنید.' : 'هنوز پاسخی برای تمرین‌های این کاربر ثبت نشده است.' ); ?></p>
                </div>
			<?php endif; ?>

			<?php if ( $max_pages > 1 ) : ?>
                <div class="card-inner border-top">
					<?php echo KERP_Helpers_Template::get_template( 'app/components/list/pagination.php', [
						'max_page_num' => $max_pages,
						'current_page' => $page_number,
						'page'         => $route,
					] ); ?>
                </div>
			<?php endif; ?>
        </div>
    </div>
</div>

<?php if ( $enabled ) {
	KERP_Helpers_Template::render_template( 'modules/learning-assignments/partials/review-modal.php', [ 'route' => $review_return_route ] );
} ?>
