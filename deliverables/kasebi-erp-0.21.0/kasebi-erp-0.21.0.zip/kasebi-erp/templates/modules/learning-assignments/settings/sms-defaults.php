<?php
defined( 'ABSPATH' ) || exit;

$defaults = KERP_Modules_Learning_Assignments_Settings::instance()->sms_defaults();
?>
<form class="modal_form kerp-appointments-settings" data-action="kerp_practice_save_sms_defaults"
      data-page="/erp/settings/learning-assignments/sms-defaults/">
    <input type="hidden" data-for="sms_defaults_nonce"
           value="<?php echo esc_attr( wp_create_nonce( 'kerp_practice_save_sms_defaults' ) ); ?>">
    <div class="nk-block-head nk-block-head-sm">
        <div class="nk-block-between">
            <div class="nk-block-head-content"><h3 class="nk-block-title page-title">پیامک پیش‌فرض تمرین</h3>
                <div class="nk-block-des text-soft"><p>پترن جایگزین برای تمرین‌هایی که پترن اختصاصی ندارند.</p></div>
            </div>
            <div class="nk-block-head-content">
                <button type="button" class="btn btn-primary submit_modal_form"><em class="icon ni ni-save"></em><span>ذخیره تنظیمات</span>
                </button>
            </div>
        </div>
    </div>
    <div class="nk-block"><?php KERP_Helpers_Template::render_template( 'app/components/settings/hero.php', [
			'icon'        => 'ni ni-chat-fill',
			'eyebrow'     => 'تنظیمات تمرین',
			'title'       => 'پترن‌های جایگزین پیامک',
			'description' => 'پترن اختصاصی هر تمرین اولویت دارد. اگر پترن آن تمرین خالی باشد، پترن و متغیرهای پیش‌فرضِ همان رویداد استفاده می‌شود.',
			'stats'       => [
				[
					'label' => 'پترن رد',
					'value' => $defaults['rejected_pattern'] !== '' ? 'تنظیم‌شده' : 'تنظیم‌نشده',
				],
				[
					'label' => 'پترن باز شدن مرحلهٔ بعد',
					'value' => $defaults['unlock_pattern'] !== '' ? 'تنظیم‌شده' : 'تنظیم‌نشده',
				],
			],
		] ); ?></div>
	<?php if ( ! class_exists( 'kasebiSMS' ) || ! method_exists( 'kasebiSMS', 'send_pattern_sms' ) ) : ?>
        <div class="nk-block">
            <div class="alert alert-warning alert-icon"><em class="icon ni ni-alert-circle"></em><span>سرویس پیامک در دسترس نیست؛ تنظیمات ذخیره می‌شوند، اما تا فعال شدن سرویس ارسالی انجام نمی‌شود.</span>
            </div>
        </div><?php endif; ?>
    <div class="nk-block">
        <div class="row g-gs">
            <div class="col-xl-6">
                <div class="card card-bordered kerp-appointments-settings-card">
                    <div class="card-inner border-bottom">
                        <div class="kerp-appointments-settings-card__head"><span
                                class="kerp-appointments-settings-section-icon"><em
                                    class="icon ni ni-cross-circle"></em></span>
                            <div><h6 class="title mb-1">رد پاسخ</h6>
                                <p class="text-soft mb-0">پس از رد هر پاسخ، اگر پترن ردِ همان تمرین خالی باشد، این پترن
                                    ارسال
                                    می‌شود.</p></div>
                        </div>
                    </div>
                    <div class="card-inner">
                        <div class="row g-4">
							<?php KERP_Helpers_Template::render_template( 'app/components/fields/text.php', [
								'field' => [
									'id'          => 'kerp-practice-default-rejected-pattern',
									'name'        => 'rejected_pattern',
									'label'       => 'پترن پیش‌فرض رد پاسخ',
									'value'       => $defaults['rejected_pattern'],
									'class'       => 'col-12',
									'input_class' => 'fc-direction-ltr',
								],
							] ); ?>
							<?php KERP_Helpers_Template::render_template( 'app/components/fields/textarea.php', [
								'field' => [
									'id'          => 'kerp-practice-default-rejected-variables',
									'name'        => 'rejected_variables',
									'label'       => 'متغیرهای پترن رد',
									'value'       => $defaults['rejected_variables'],
									'class'       => 'col-12',
									'input_class' => 'fc-direction-ltr',
									'rows'        => 2,
									'placeholder' => 'name:{user_name};practice:{practice_title};reason:{review_comment}',
								],
							] ); ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-6">
                <div class="card card-bordered kerp-appointments-settings-card">
                    <div class="card-inner border-bottom">
                        <div class="kerp-appointments-settings-card__head"><span
                                class="kerp-appointments-settings-section-icon"><em
                                    class="icon ni ni-check-circle"></em></span>
                            <div><h6 class="title mb-1">تأیید و باز شدن مرحلهٔ بعد</h6>
                                <p class="text-soft mb-0">فقط وقتی تأیید، مبحث بعدی را برای هنرجو قابل
                                    مشاهده کند
                                    ارسال می‌شود.</p></div>
                        </div>
                    </div>
                    <div class="card-inner">
                        <div class="row g-4">
							<?php KERP_Helpers_Template::render_template( 'app/components/fields/text.php', [
								'field' => [
									'id'          => 'kerp-practice-default-unlock-pattern',
									'name'        => 'unlock_pattern',
									'label'       => 'پترن پیش‌فرض باز شدن مرحلهٔ بعد',
									'value'       => $defaults['unlock_pattern'],
									'class'       => 'col-12',
									'input_class' => 'fc-direction-ltr',
								],
							] ); ?>
							<?php KERP_Helpers_Template::render_template( 'app/components/fields/textarea.php', [
								'field' => [
									'id'          => 'kerp-practice-default-unlock-variables',
									'name'        => 'unlock_variables',
									'label'       => 'متغیرهای پترن باز شدن',
									'value'       => $defaults['unlock_variables'],
									'class'       => 'col-12',
									'input_class' => 'fc-direction-ltr',
									'rows'        => 2,
									'placeholder' => 'name:{user_name};next:{next_item_title}',
								],
							] ); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="nk-block">
        <div class="alert alert-light alert-icon mb-0"><em
                class="icon ni ni-info"></em><span>متغیرهای قابل استفاده: <code>{user_id}</code>، <code>{user_name}</code>، <code>{practice_title}</code>، <code>{item_title}</code>، <code>{next_item_title}</code>، <code>{review_comment}</code> و <code>{site_name}</code>. پاسخ پنل پیامکی روی همان پاسخ تمرین ثبت می‌شود.</span>
        </div>
    </div>
</form>
