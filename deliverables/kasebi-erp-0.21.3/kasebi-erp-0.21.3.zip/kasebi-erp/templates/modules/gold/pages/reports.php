<?php
defined( 'ABSPATH' ) || exit;
$u = KERP_Modules_Gold_Ui::class;
try { $data = KERP_Modules_Gold_Ui_Data::report(); } catch ( Throwable $e ) { $u::note( $e->getMessage(), 'danger' ); $data = [ 'start' => $u::get( 'gold_start' ), 'end' => $u::get( 'gold_end' ), 'balances' => [], 'assets' => [], 'sales' => [] ]; }
$today = new DateTimeImmutable( wp_date( 'Y-m-d' ), wp_timezone() );
$money_cell = static fn( $asset, $amount ) => $u::html( '<bdi>' . esc_html( KERP_Modules_Gold_Business::amount_label( $asset, (int) $amount ) ) . '</bdi>' );
?>
<div class="nk-block"><?php $u::card( 'گزارش فروش' ); ?>
<nav class="kg-periods mb-3" aria-label="بازه گزارش"><?php foreach ( [ 0 => 'امروز', 6 => '۷ روز اخیر', 29 => '۳۰ روز اخیر' ] as $days => $label ) { $u::link( 'reports', $label, 'btn btn-white btn-outline-light', '', [ 'gold_start' => KERP_Helpers_Date::gregorian_to_jalali( $today->modify( '-' . $days . ' days' )->format( 'Y-m-d' ) ), 'gold_end' => KERP_Helpers_Date::gregorian_to_jalali( $today->format( 'Y-m-d' ) ) ] ); } ?></nav>
<details class="kg-help mb-3"><summary>انتخاب تاریخ</summary><form class="mt-3" method="get" action="<?php echo esc_url( $u::url( 'reports' ) ); ?>"><div class="row g-3 align-items-end">
<?php foreach ( [ 'gold_start' => [ 'از تاریخ', $data['start'] ], 'gold_end' => [ 'تا تاریخ', $data['end'] ] ] as $name => [ $label, $value ] ) { KERP_Helpers_Template::render_template( 'app/components/fields/date.php', [ 'field' => [ 'id' => 'kg-' . $name, 'name' => $name, 'label' => $label, 'value' => $value, 'class' => 'col-md-4', 'required' => true ] ] ); } ?>
<div class="col-md-4"><button type="submit" class="btn btn-primary">نمایش</button></div></div></form></details>
<p class="kg-report-dates"><bdi><?php echo esc_html( $data['start'] ); ?></bdi> تا <bdi><?php echo esc_html( $data['end'] ); ?></bdi></p>
<?php $rows = []; foreach ( $data['sales'] as $row ) { $asset = $row->currency . ':' . $row->decimals; $rows[] = [ ( KERP_Modules_Gold_Business::source_labels()[ $row->source ] ?? $row->source ) . ' · ' . ( $row->was_plus ? 'پلاس' : 'عادی' ), number_format_i18n( $row->orders ), $money_cell( $asset, $row->refunded ), $money_cell( $asset, (int) $row->total - (int) $row->refunded ) ]; } $u::table( [ 'فروش', 'تعداد سفارش', 'بازپرداخت', 'خالص فروش' ], $rows, 'فروشی در این تاریخ ثبت نشده است.' ); $u::end_card(); ?></div>
<details class="card card-bordered kg-settings-fold mb-3"><summary>ریز حساب‌ها <?php echo $u::icon( 'chevron-down' ); ?></summary><div class="card-inner">
<?php $rows = []; foreach ( $data['balances'] as $row ) { $rows[] = [ $row->label, $money_cell( $row->asset, $row->opening ), $money_cell( $row->asset, $row->incoming ), $money_cell( $row->asset, $row->outgoing ), $money_cell( $row->asset, $row->closing ) ]; } $u::table( [ 'حساب', 'مانده قبل', 'ورودی', 'خروجی', 'مانده پایان' ], $rows, 'گردشی ثبت نشده است.' ); ?></div></details>
<details class="card card-bordered kg-settings-fold"><summary>موجودی حساب‌های دارایی (همین حالا) <?php echo $u::icon( 'chevron-down' ); ?></summary><div class="card-inner">
<?php $rows = []; foreach ( $data['assets'] as $asset ) { $rows[] = [ $asset->asset === 'gold' ? 'طلا' : 'بانک، درگاه و صندوق', $money_cell( $asset->asset, $asset->amount ) ]; } $u::table( [ 'دارایی', 'موجودی' ], $rows, 'موجودی ثبت نشده است.' ); ?></div></details>
