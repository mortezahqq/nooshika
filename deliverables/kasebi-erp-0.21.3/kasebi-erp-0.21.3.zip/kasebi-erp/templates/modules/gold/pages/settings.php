<?php
defined( 'ABSPATH' ) || exit;
$u = KERP_Modules_Gold_Ui::class; $s = KERP_Modules_Gold_Module::settings();
$u::open_form( 'settings' ); ?>
<div class="row g-gs"><div class="col-xl-8"><div class="kg-settings-stack">
<?php $u::card( 'نرخ و قیمت طلا', 'واحد پول فروشگاه: ' . html_entity_decode( wp_strip_all_tags( get_woocommerce_currency_symbol() ) ) ); ?>
<div class="row g-3"><?php
$u::select( 'quote_basis', 'مبنای نرخ دریافتی', [ 'gram' => 'گرم عیار ۷۵۰', 'mesghal' => 'مظنه' ], $s['quote_basis'] ); $u::field( 'rate', 'نرخ پایه', $s['rate'], 'text', true, '', 'col-md-6', 'inputmode="decimal" dir="ltr"' );
$u::field( 'premium', 'اختلاف قیمت هر گرم', (string) (float) $s['premium'], 'number', true, 'از منفی ۲۰۰٬۰۰۰ تا مثبت ۲۰۰٬۰۰۰', 'col-md-6', 'min="-200000" max="200000" step="0.000001"' ); echo '</div><details class="kg-help mt-3"><summary>تنظیمات پیشرفته نرخ طلا</summary><div class="row g-3">';
$u::field( 'max_age', 'اعتبار نرخ به ثانیه', $s['max_age'], 'number', true, 'پس از انقضا، قیمت‌گذاری طلایی متوقف می‌شود.', 'col-md-6', 'min="30" max="86400"' );
$u::field( 'mesghal_factor', 'ضریب تبدیل مظنه به گرم ۷۵۰', $s['mesghal_factor'], 'text', true, 'ضریب را با قرارداد آب‌شده‌فروش تطبیق دهید.', 'col-12', 'inputmode="decimal" dir="ltr"' );
echo '</div></details><div>';
?></div><div class="custom-control custom-checkbox mt-4"><input class="custom-control-input" type="checkbox" id="kg-refresh-rate" name="refresh_rate" value="1"><label class="custom-control-label" for="kg-refresh-rate">نرخ بالا را تأیید می‌کنم.</label></div><?php $u::end_card(); ?>
<?php $u::card( 'سیاست کیف طلایی', 'روش‌های مجاز برداشت و حداقل تحویل فیزیکی' ); ?>
<div class="kg-policy-list"><?php foreach ( [ 'cash' => [ 'تسویه نقدی', 'کاربر بتواند درخواست تبدیل موجودی به وجه بدهد.', 'wallet-out' ], 'physical' => [ 'تحویل فیزیکی', 'درخواست تحویل قطعه با رعایت حداقل وزن.', 'package' ], 'jewelry' => [ 'مصرف برای زیورآلات', 'ثبت درخواست استفاده از موجودی برای خرید زینتی.', 'bag' ] ] as $key => [ $label, $hint, $icon ] ) : ?>
<label class="kg-policy" for="kg-allow-<?php echo esc_attr( $key ); ?>"><span class="user-avatar sm bg-primary-dim"><?php echo $u::icon( $icon ); ?></span><span><strong><?php echo esc_html( $label ); ?></strong><small class="sub-text"><?php echo esc_html( $hint ); ?></small></span><span class="custom-control custom-switch"><input class="custom-control-input" type="checkbox" id="kg-allow-<?php echo esc_attr( $key ); ?>" name="allow_<?php echo esc_attr( $key ); ?>" value="1" <?php checked( $s[ 'allow_' . $key ], 1 ); ?>><span class="custom-control-label"></span></span></label>
<?php endforeach; ?></div><div class="row g-3 mt-1"><?php $u::field( 'physical_min', 'حداقل تحویل فیزیکی', $s['physical_min'], 'text', true, 'بر حسب گرم معادل عیار ۷۵۰', 'col-12', 'inputmode="decimal" dir="ltr"' ); ?></div><?php $u::end_card(); ?>
<?php $u::card( 'اشتراک پلاس', 'محصول خرید اشتراک و مدت دسترسی' ); ?><div class="row g-3"><?php $u::lookup( 'plus_product', 'محصول ساده و مجازی اشتراک', 'products', (int) $s['plus_product'], false, 'col-12' ); $u::field( 'plus_days', 'مدت اشتراک به روز', $s['plus_days'], 'number', true, '', 'col-12', 'min="1" max="3650"' ); $u::field( 'landing', 'متن معرفی خدمات', $s['landing'], 'textarea', false, '', 'col-12' ); ?></div><?php $u::end_card(); ?>
<?php $u::card( 'مسیر خدمات پلاس', 'کارت‌هایی که در پنل کاربر نمایش داده می‌شوند.' ); ?><div class="row g-3"><?php foreach ( KERP_Modules_Gold_Module::links() as $key => $label ) { $u::field( 'link_' . $key, 'نشانی ' . $label, $s[ 'link_' . $key ], 'url', false, '', 'col-md-6', 'placeholder="https://"' ); } ?></div><?php $u::end_card(); ?>
</div></div><div class="col-xl-4"><div class="kg-settings-side">
<?php $u::card( 'راه‌اندازی صفحات', 'کد را در برگه وردپرس قرار دهید.' ); foreach ( [ 'kerp_plus' => 'صفحه معرفی و پنل پلاس', 'kerp_gold_wallet' => 'صفحه کیف طلایی' ] as $short => $label ) : ?>
<div class="kg-shortcode"><span class="sub-text mb-2"><?php echo esc_html( $label ); ?></span><div><code dir="ltr">[<?php echo esc_html( $short ); ?>]</code><button class="btn btn-sm btn-icon" type="button" data-kg-copy="[<?php echo esc_attr( $short ); ?>]" aria-label="کپی کد"><?php echo $u::icon( 'copy' ); ?></button></div></div>
<?php endforeach; $u::end_card(); ?>
<?php $u::card( 'وضعیت اتصال‌ها' ); ?><ul class="kg-setup-list"><li><span>پیام‌رسان</span><?php echo $u::badge( KERP_Modules_Gold_Notifications::configured() ? 'completed' : 'local', KERP_Modules_Gold_Notifications::configured() ? 'تنظیم شده' : 'ثبت داخلی' ); ?></li><li><span>رابط بسته‌بندی</span><?php echo $u::badge( 'completed', 'در دسترس' ); ?></li><li><span>خرید جایگزین</span><?php echo $u::badge( 'local', 'تأیید دستی' ); ?></li></ul><details class="kg-help mt-3"><summary>جزئیات اتصال و محدودیت‌ها</summary><p>برای دریافت نرخ و خرید خودکار از فروشنده، راهنمای فنی او لازم است. رابط بسته‌بندی افزونه فعال است؛ اتصال سامانه مقصد جداگانه تنظیم می‌شود. درخواست کیف طلایی و خرید جایگزین فعلاً با بررسی دستی مدیر انجام می‌شوند.</p></details><?php $u::end_card(); ?>
</div></div></div>
<?php $u::form_footer( 'ذخیره تنظیمات', false, '' ); ?>
