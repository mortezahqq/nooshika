<?php
defined( 'ABSPATH' ) || exit;
$u = KERP_Modules_Gold_Ui::class; $data = $u::query( 'books' ); $rows = [];
$u::card( 'حساب‌های بنکداری', number_format_i18n( $data['total'] ) . ' حساب · مانده طلا و وجه به‌صورت مستقل' ); $u::table_filter();
foreach ( $data['rows'] as $book ) {
    $kind = KERP_Modules_Gold_Business::kinds()[ $book->kind ] ?? $book->kind;
    $gold = KERP_Modules_Gold_Business::balance( (int) $book->id, 'gold' ); $money = KERP_Modules_Gold_Business::balance( (int) $book->id, KERP_Modules_Gold_Business::money_asset() );
    $rows[] = [ $u::html( '<div class="user-card"><div class="user-avatar sm bg-primary-dim">' . $u::icon( $book->kind === 'party' ? 'user' : 'wallet' ) . '</div><div class="user-info"><strong>' . esc_html( $book->label ) . '</strong><span class="sub-text">حساب #' . (int) $book->id . '</span></div></div>' ), $u::html( '<span class="badge badge-dim bg-light">' . esc_html( $kind ) . '</span><span class="sub-text">' . esc_html( KERP_Modules_Gold_Business::parties()[ $book->party_type ] ?? '' ) . '</span>' ), $u::html( '<strong><bdi>' . esc_html( $u::weight( $gold ) ) . '</bdi></strong><span class="sub-text">گرم ۷۵۰</span>' ), $u::html( wp_kses_post( $u::money( $money ) ) ), $book->user_id ? $u::user( (int) $book->user_id ) : '—', $book->details ?: '—' ];
}
$u::table( [ 'حساب / طرف‌حساب', 'نوع حساب', 'مانده طلا', 'مانده وجه', 'کاربر مرتبط', 'مشخصات' ], $rows, 'اولین حساب بنکداری را بسازید.', 'برای ثبت حواله، ابتدا طرف‌حساب، بانک یا صندوق خود را تعریف کنید.' ); $u::pagination( $data['total'] ); $u::end_card();
?>

<?php $u::modal( 'gold-create', 'افزودن حساب جدید', function () use ( $u ) {
    $u::open_form( 'book' ); $u::hidden( 'code', wp_generate_uuid4() ); echo '<div class="row g-3">'; $u::field( 'label', 'نام حساب یا طرف‌حساب', '', 'text', true, 'مثلاً بانک ملت، صندوق فروشگاه یا نام تأمین‌کننده', 'col-12' ); $u::select( 'kind', 'نوع حساب', KERP_Modules_Gold_Business::kinds(), 'party' ); echo '<div class="col-md-6" data-kg-if="kind:party"><div class="row">'; $u::select( 'party_type', 'نوع طرف‌حساب', KERP_Modules_Gold_Business::parties(), 'customer', 'col-12' ); echo '</div></div><div class="col-12"><details class="kg-help"><summary>اطلاعات بیشتر (اختیاری)</summary><div class="mt-3" data-kg-if="kind:party"><div class="row">'; $u::lookup( 'user_id', 'اتصال به کاربر سایت؛ اختیاری', 'users', 0, false, 'col-12' ); echo '</div></div>'; $u::field( 'details', 'مشخصات تکمیلی', '', 'textarea', false, 'شماره حساب، نام شعبه یا توضیحات طرف‌حساب', 'col-12' ); echo '</details></div></div>'; $u::form_footer( 'افزودن حساب' );
} ); ?>
