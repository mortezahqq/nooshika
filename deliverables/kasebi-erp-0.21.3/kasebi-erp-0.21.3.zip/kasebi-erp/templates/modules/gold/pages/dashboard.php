<?php
defined( 'ABSPATH' ) || exit;
$u = KERP_Modules_Gold_Ui::class; $stats = KERP_Modules_Gold_Ui_Data::summary();
?>
<div class="kg-home-actions">
<?php foreach ( [
    [ 'sales', 'ثبت فروش', 'plus', null, [ 'new' => '1' ] ],
    [ 'requests', 'درخواست مشتریان', 'inbox', $stats['requests'], [ 'status' => 'pending' ] ],
    [ 'packaging', 'ارسال سفارش‌ها', 'package', $stats['packaging'], [] ],
    [ 'replacement', 'خرید طلای جایگزین', 'coins', $stats['replacement_count'], [ 'status' => 'pending' ] ],
] as [ $target, $label, $icon, $count, $query ] ) : $url = $u::url( $target, $query ); ?>
<a class="kg-home-action page_activator" href="<?php echo esc_url( $url ); ?>" data-url="<?php echo esc_attr( wp_make_link_relative( $url ) ); ?>"><span class="kg-home-icon"><?php echo $u::icon( $icon ); ?></span><strong><?php echo esc_html( $label ); ?></strong><?php if ( $count ) : ?><span class="kg-home-count"><?php echo esc_html( number_format_i18n( $count ) ); ?> در انتظار</span><?php endif; ?><?php echo $u::icon( 'chevron-left' ); ?></a>
<?php endforeach; ?>
</div>
<nav class="kg-home-secondary" aria-label="بخش‌های دیگر"><?php $u::link( 'inventory', 'کالاها', 'btn btn-white btn-outline-light', 'layers' ); $u::link( 'books', 'حساب‌ها', 'btn btn-white btn-outline-light', 'users' ); $u::link( 'reports', 'گزارش فروش', 'btn btn-white btn-outline-light', 'bar-chart' ); ?></nav>
