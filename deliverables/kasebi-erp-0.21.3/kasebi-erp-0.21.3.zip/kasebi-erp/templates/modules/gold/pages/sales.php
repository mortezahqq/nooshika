<?php
defined( 'ABSPATH' ) || exit;
$u = KERP_Modules_Gold_Ui::class; $data = $u::query( 'sales' ); $rows = []; $details = [];
$result = get_transient( 'kerp_gold_sale_result_' . get_current_user_id() );
if ( $result ) { echo '<div class="alert alert-success" role="status">فروش شماره ' . (int) $result . ' ثبت شد.</div>'; delete_transient( 'kerp_gold_sale_result_' . get_current_user_id() ); }
$u::card( 'فروش‌ها' ); $u::table_filter( [ 'pending' => 'پرداخت نشده', 'processing' => 'در حال انجام', 'completed' => 'تکمیل‌شده', 'refunded' => 'برگشت خورده', 'cancelled' => 'لغوشده' ] );
foreach ( $data['rows'] as $row ) {
    $order = wc_get_order( $row->order_id ); $action = '—';
    if ( $order ) {
        ob_start(); $u::action( 'kg-sale-' . $row->order_id, 'جزئیات', 'eye', 'btn-white btn-outline-light' ); $action = ob_get_clean();
        $details[] = function () use ( $u, $order, $row ) {
            $u::modal( 'kg-sale-' . $row->order_id, 'فروش شماره ' . $row->order_id, function () use ( $u, $order, $row ) {
                echo '<div class="kg-order-heading"><strong>' . esc_html( $u::user( (int) $row->user_id ) ) . '</strong>' . $u::badge( $order->get_status(), $u::order_status( $order->get_status() ) ) . '</div>';
                $items = []; foreach ( $order->get_items() as $item ) { $items[] = [ $item->get_name(), number_format_i18n( $item->get_quantity() ) ]; }
                $u::table( [ 'کالا', 'تعداد' ], $items );
                echo '<div class="kg-sale-summary"><span>مبلغ نهایی</span><strong>' . wp_kses_post( $order->get_formatted_order_total() ) . '</strong></div><div class="kg-order-info"><span>' . esc_html( KERP_Modules_Gold_Business::source_labels()[ $row->source ] ?? $row->source ) . '</span><span>' . esc_html( $row->paid_at ? 'پرداخت: ' . $u::date( $row->paid_at ) : 'هنوز پرداخت نشده' ) . '</span></div><div class="kg-form-footer"><button class="btn btn-primary" type="button" data-bs-dismiss="modal">بستن</button></div>';
            } );
        };
    }
    $rows[] = [ '#' . (int) $row->order_id, $u::user( (int) $row->user_id ), $u::html( wp_kses_post( $u::money( (int) $row->total, $row->currency, (int) $row->decimals ) ) ), $u::html( $u::badge( $row->status, $u::order_status( $row->status ) ) ), $u::html( $action ) ];
}
$u::table( [ 'فروش', 'مشتری', 'مبلغ', 'وضعیت', '' ], $rows, 'هنوز فروشی ثبت نشده است.' ); $u::pagination( $data['total'] ); $u::end_card(); foreach ( $details as $render ) { $render(); }
$u::modal( 'gold-create', 'ثبت فروش جدید', function () use ( $u ) {
    $u::open_form( 'offline_sale' ); echo '<div class="kg-sale-step" data-kg-step="0"><div class="row g-3">'; $u::lookup( 'user_id', 'مشتری', 'users', 0, true ); $u::select( 'source', 'منبع فروش', [ 'physical' => 'فروش حضوری', 'social' => 'شبکه‌های اجتماعی' ], 'physical' ); echo '</div></div><div class="kg-sale-step" data-kg-step="1"><div class="kg-form-section"><div class="kg-section-label"><h5>کالاها</h5></div><div data-kg-sale-lines>';
    echo '<div class="kg-sale-row"><div>'; $u::lookup( 'product_ids[]', 'محصول', 'products', 0, true, 'col-12' ); echo '</div><div>'; $u::field( 'quantities[]', 'تعداد', '1', 'number', true, '', 'col-12', 'min="1" max="10000" step="1"' ); echo '</div><button type="button" class="btn btn-icon btn-white btn-outline-light kg-remove-line" aria-label="حذف ردیف">' . $u::icon( 'trash' ) . '</button></div></div><button type="button" class="btn btn-sm btn-white btn-outline-light mt-2" data-kg-add-line>' . $u::icon( 'plus' ) . '<span>کالای دیگر</span></button></div>';
    echo '</div><div class="kg-sale-step" data-kg-step="2"><div data-kg-sale-review class="alert alert-light"></div><div class="kg-sale-summary" aria-live="polite"><span>جمع اولیه سفارش</span><strong data-kg-sale-total>محصول را انتخاب کنید</strong><small class="sub-text" data-kg-sale-note>مالیات در مبلغ نهایی سفارش محاسبه می‌شود.</small></div><div class="row g-3">'; $u::select( 'method', 'وضعیت دریافت وجه', [ 'unpaid' => 'هنوز پرداخت نشده', 'cash' => 'دریافت نقدی تأیید شده', 'bank' => 'رسید بانکی بررسی شده', 'gateway' => 'رسید درگاه بررسی شده' ], 'unpaid', 'col-12' ); echo '<div class="col-12" data-kg-if="method:cash,bank,gateway"><div class="row">'; $u::field( 'receipt', 'شماره رسید پرداخت', '', 'text', true, 'انتخاب این روش یعنی دریافت وجه را بررسی کرده‌اید؛ این فرم برداشت بانکی انجام نمی‌دهد.', 'col-12' ); echo '</div></div></div></div>'; $u::form_footer( 'ثبت سفارش' );
} );
