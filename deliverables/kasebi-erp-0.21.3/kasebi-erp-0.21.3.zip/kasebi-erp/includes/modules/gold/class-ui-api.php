<?php
defined( 'ABSPATH' ) || exit;
/** Read-only data for accessible ERP lookups and the draft sale estimate. */
final class KERP_Modules_Gold_Ui_Api {
    public static function register(): void { add_action( 'rest_api_init', [ self::class, 'routes' ] ); }
    public static function allowed(): bool { return current_user_can( 'manage_options' ) && KERP_Modules::instance()->is_module_loaded( 'gold' ); }
    public static function routes(): void {
        register_rest_route( 'kerp/v1', '/gold/ui/lookup', [ 'methods' => 'GET', 'permission_callback' => [ self::class, 'allowed' ], 'callback' => [ self::class, 'lookup' ], 'args' => [ 'kind' => [ 'type' => 'string', 'enum' => [ 'users', 'products' ], 'required' => true ], 'q' => [ 'type' => 'string', 'required' => true, 'maxLength' => 100 ] ] ] );
        register_rest_route( 'kerp/v1', '/gold/ui/sale-preview', [ 'methods' => 'POST', 'permission_callback' => [ self::class, 'allowed' ], 'callback' => [ self::class, 'preview' ], 'args' => [ 'user_id' => [ 'type' => 'integer', 'minimum' => 1, 'required' => true ], 'items' => [ 'type' => 'array', 'required' => true, 'minItems' => 1, 'maxItems' => 30, 'items' => [ 'type' => 'object', 'required' => [ 'product_id', 'quantity' ], 'properties' => [ 'product_id' => [ 'type' => 'integer', 'minimum' => 1 ], 'quantity' => [ 'type' => 'integer', 'minimum' => 1, 'maximum' => 10000 ] ] ] ] ] ] );
    }
    private static function response( array $data ): WP_REST_Response { $response = new WP_REST_Response( $data ); $response->header( 'Cache-Control', 'no-store, private' ); return $response; }
    public static function lookup( WP_REST_Request $request ): WP_REST_Response {
        $q = KERP_Helpers_Format::sanitize_numbers( trim( sanitize_text_field( $request['q'] ) ) ); $items = [];
        if ( $q === '' ) { return self::response( [ 'items' => [] ] ); }
        if ( $request['kind'] === 'users' ) {
            $users = get_users( [ 'number' => 12, 'search' => '*' . $q . '*', 'search_columns' => [ 'display_name', 'user_login', 'user_email' ], 'orderby' => 'display_name', 'order' => 'ASC' ] );
            if ( ctype_digit( $q ) && ( $direct = get_userdata( (int) $q ) ) ) { array_unshift( $users, $direct ); }
            $unique = []; foreach ( $users as $user ) { $unique[ $user->ID ] = $user; }
            if ( count( $unique ) < 12 ) {
                $matches = get_users( [ 'number' => 12 - count( $unique ), 'exclude' => array_keys( $unique ), 'meta_query' => [ 'relation' => 'OR', [ 'key' => 'first_name', 'value' => $q, 'compare' => 'LIKE' ], [ 'key' => 'last_name', 'value' => $q, 'compare' => 'LIKE' ], [ 'key' => 'billing_phone', 'value' => $q, 'compare' => 'LIKE' ] ] ] );
                foreach ( $matches as $user ) { $unique[ $user->ID ] = $user; }
            }
            foreach ( array_slice( $unique, 0, 12 ) as $user ) { $items[] = [ 'id' => (int) $user->ID, 'label' => KERP_Modules_Gold_Ui::user( $user->ID ), 'meta' => sanitize_text_field( get_user_meta( $user->ID, 'billing_phone', true ) ) ?: 'مشتری شماره ' . $user->ID ]; }
        } else {
            $ids = ctype_digit( $q ) ? [ (int) $q ] : get_posts( [ 'post_type' => 'product', 'post_status' => 'publish', 'posts_per_page' => 12, 's' => $q, 'fields' => 'ids' ] );
            $sku_id = wc_get_product_id_by_sku( $q ); if ( $sku_id ) { array_unshift( $ids, $sku_id ); }
            foreach ( array_slice( array_unique( $ids ), 0, 12 ) as $id ) { $p = wc_get_product( $id ); if ( ! $p || ! $p->is_type( 'simple' ) || $p->get_status() !== 'publish' ) { continue; } $items[] = [ 'id' => $p->get_id(), 'label' => $p->get_name(), 'meta' => ( $p->get_sku() ? 'کد کالا: ' . $p->get_sku() : 'کالا شماره ' . $p->get_id() ) . ( $p->is_in_stock() ? '' : ' · ناموجود' ) . ( $p->get_meta( '_kerp_gold_state' ) && $p->get_meta( '_kerp_gold_state' ) !== 'in_stock' ? ' · ' . ( KERP_Modules_Gold_Module::states()[ $p->get_meta( '_kerp_gold_state' ) ] ?? '' ) : '' ) ]; }
        }
        return self::response( [ 'items' => $items ] );
    }
    public static function preview( WP_REST_Request $request ) {
        $uid = (int) $request['user_id']; if ( ! get_userdata( $uid ) ) { return new WP_Error( 'gold_customer', 'مشتری را دوباره انتخاب کنید.', [ 'status' => 400 ] ); }
        $total = 0; $combined = [];
        foreach ( $request['items'] as $line ) { $id = (int) $line['product_id']; $combined[ $id ] = ( $combined[ $id ] ?? 0 ) + (int) $line['quantity']; }
        foreach ( $combined as $id => $quantity ) {
            $p = wc_get_product( $id ); if ( ! $p || ! $p->is_type( 'simple' ) || ! $p->is_purchasable() || ! $p->has_enough_stock( $quantity ) || $quantity > 10000 ) { return new WP_Error( 'gold_product', 'محصول قابل فروش نیست یا موجودی کافی ندارد.', [ 'status' => 400 ] ); }
            $calc = KERP_Modules_Gold_Pricing::calculate( $p, $uid ); $price = $calc ? $calc['price'] : (float) $p->get_price(); $total += $price * $quantity;
        }
        return self::response( [ 'total_html' => wp_kses_post( wc_price( $total ) ), 'is_plus' => KERP_Modules_Gold_Module::is_plus( $uid ), 'note' => 'مالیات در مبلغ نهایی محاسبه می‌شود.' ] );
    }
}
