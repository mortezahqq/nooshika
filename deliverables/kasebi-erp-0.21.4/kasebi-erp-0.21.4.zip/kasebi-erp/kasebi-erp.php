<?php
/**
 * Plugin Name: کاسبی: ERP
 * Plugin URI: https://kasebi.co/
 * Description: هسته ماژولار سامانه ERP کاسبی.
 * Version: 0.21.4
 * Author: احمد گلچین
 * Author URI: https://kasebi.co/
 * Text Domain: kasebi-erp
 * Domain Path: /languages
 * Requires at least: 6.0
 * Requires PHP: 8.0
 */

defined( 'ABSPATH' ) || exit;

const KERP_VERSION     = '0.21.4';
const KERP_DB_VERSION  = '0.5.2';
const KERP_SLUG        = 'erp';
const KERP_TEXT_DOMAIN = 'kasebi-erp';
const KERP_FILE        = __FILE__;

define( 'KERP_PATH', plugin_dir_path( __FILE__ ) );
define( 'KERP_URL', plugin_dir_url( __FILE__ ) );
define( 'KERP_BASENAME', plugin_basename( __FILE__ ) );

const KERP_INC_PATH       = KERP_PATH . 'includes/';
const KERP_TEMPLATES_PATH = KERP_PATH . 'templates/';
const KERP_ASSETS_PATH    = KERP_PATH . 'assets/';
const KERP_ASSETS_URL     = KERP_URL . 'assets/';

require_once KERP_INC_PATH . 'class-bootstrap.php';

KERP_Bootstrap::init();
