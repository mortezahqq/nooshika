<?php
defined( 'ABSPATH' ) || exit;
$u = KERP_Modules_Gold_Ui::class;
$s = KERP_Modules_Gold_Module::settings();
$currency = html_entity_decode( wp_strip_all_tags( get_woocommerce_currency_symbol() ) );
$u::open_form( 'settings' );
?>
<div class="kg-settings-layout">
<?php $u::card( 'نرخ و قیمت طلا' ); ?>
<div class="row g-3">
<?php
$u::select( 'quote_basis', 'قیمت بر اساس', [ 'gram' => 'هر گرم عیار ۷۵۰', 'mesghal' => 'مظنه' ], $s['quote_basis'] );
$u::field( 'rate', 'قیمت پایه (' . $currency . ')', $s['rate'], 'text', true, '', 'col-md-6', 'inputmode="decimal" dir="ltr"' );
$u::field( 'premium', 'اختلاف قیمت هر گرم (' . $currency . ')', (string) (float) $s['premium'], 'number', true, 'از منفی ۲۰۰٬۰۰۰ تا مثبت ۲۰۰٬۰۰۰', 'col-12', 'min="-200000" max="200000" step="0.000001"' );
?>
</div>
<div class="custom-control custom-checkbox kg-rate-confirm"><input class="custom-control-input" type="checkbox" id="kg-refresh-rate" name="refresh_rate" value="1"><label class="custom-control-label" for="kg-refresh-rate">نرخ بالا را تأیید می‌کنم.</label></div>
<details class="kg-rate-advanced"><summary>تنظیمات پیشرفته نرخ</summary><div class="row g-3 mt-1">
<?php
$u::field( 'max_age', 'اعتبار نرخ (ثانیه)', $s['max_age'], 'number', true, '', 'col-md-6', 'min="30" max="86400"' );
$u::field( 'mesghal_factor', 'ضریب تبدیل مظنه', $s['mesghal_factor'], 'text', true, '', 'col-md-6', 'inputmode="decimal" dir="ltr"' );
?>
</div></details>
<?php $u::end_card(); ?>

<?php $u::card( 'برداشت از کیف طلایی' ); ?>
<div class="kg-settings-policies">
<?php foreach ( [ 'cash' => 'درخواست دریافت پول', 'physical' => 'درخواست تحویل طلا', 'jewelry' => 'درخواست خرید زیورآلات' ] as $key => $label ) : ?>
<div class="custom-control custom-switch"><input class="custom-control-input" type="checkbox" id="kg-allow-<?php echo esc_attr( $key ); ?>" name="allow_<?php echo esc_attr( $key ); ?>" value="1" <?php checked( $s[ 'allow_' . $key ], 1 ); ?>><label class="custom-control-label" for="kg-allow-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></label></div>
<?php endforeach; ?>
</div>
<div class="row g-3 mt-1"><?php $u::field( 'physical_min', 'حداقل تحویل طلا (گرم عیار ۷۵۰)', $s['physical_min'], 'text', true, '', 'col-12', 'inputmode="decimal" dir="ltr"' ); ?></div>
<?php $u::end_card(); ?>

<?php $u::card( 'اشتراک پلاس' ); ?>
<div class="row g-3">
<?php
$u::lookup( 'plus_product', 'محصول اشتراک', 'products', (int) $s['plus_product'], false, 'col-12' );
$u::field( 'plus_days', 'مدت اشتراک (روز)', $s['plus_days'], 'number', true, '', 'col-12', 'min="1" max="3650"' );
$u::field( 'landing', 'متن معرفی', $s['landing'], 'textarea', false, '', 'col-12' );
?>
</div>
<?php $u::end_card(); ?>

<?php $u::card( 'لینک خدمات پلاس' ); ?>
<div class="row g-3"><?php foreach ( KERP_Modules_Gold_Module::links() as $key => $label ) { $u::field( 'link_' . $key, $label, $s[ 'link_' . $key ], 'url', false, '', 'col-md-6', 'placeholder="https://" autocomplete="url"' ); } ?></div>
<?php $u::end_card(); ?>

<?php $u::card( 'راه‌اندازی و اتصال‌ها' ); ?>
<div class="kg-settings-shortcodes">
<?php foreach ( [ 'kerp_plus' => 'صفحه پلاس', 'kerp_gold_wallet' => 'صفحه کیف طلایی' ] as $short => $label ) : ?>
<div class="kg-shortcode"><span class="sub-text mb-2"><?php echo esc_html( $label ); ?></span><div><code dir="ltr">[<?php echo esc_html( $short ); ?>]</code><button class="btn btn-sm btn-icon" type="button" data-kg-copy="[<?php echo esc_attr( $short ); ?>]" aria-label="کپی کد <?php echo esc_attr( $label ); ?>"><?php echo $u::icon( 'copy' ); ?></button></div></div>
<?php endforeach; ?>
</div>
<ul class="kg-setup-list mb-0"><li><span>پیام‌رسان</span><?php echo $u::badge( KERP_Modules_Gold_Notifications::configured() ? 'completed' : 'local', KERP_Modules_Gold_Notifications::configured() ? 'تنظیم شده' : 'تنظیم نشده' ); ?></li><li><span>خرید طلای جایگزین</span><?php echo $u::badge( 'local', 'تأیید دستی' ); ?></li><li><span>بسته‌بندی</span><span>اتصال سامانه مقصد جداگانه است</span></li></ul>
<?php $u::end_card(); ?>
</div>
<?php $u::form_footer( 'ذخیره تنظیمات', false ); ?>
