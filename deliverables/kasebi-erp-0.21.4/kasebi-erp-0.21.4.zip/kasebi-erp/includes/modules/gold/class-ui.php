<?php
defined( 'ABSPATH' ) || exit;

/** Native ERP presentation. All writes continue through the existing nonce/capability guarded handler. */
final class KERP_Modules_Gold_Ui {
    private static string $section = 'dashboard';
    private static int $sequence = 0;
    private static ?array $query = null;
    private static array $card_stack = [];
    public static function sections(): array {
        return [
            'dashboard' => [ 'title' => 'خانه', 'description' => 'وضعیت دارایی‌ها، صف کارها و فروش را یک‌جا دنبال کنید.', 'icon' => 'dashboard', 'menu' => '' ],
            'sales' => [ 'title' => 'فروش‌ها', 'description' => 'ثبت سفارش و پیگیری فروش‌های خارج از سایت.', 'icon' => 'cart', 'menu' => '', 'create' => 'ثبت فروش' ],
            'requests' => [ 'title' => 'درخواست مشتریان', 'description' => 'بررسی خرید، تسویه و درخواست‌های تحویل کاربران.', 'icon' => 'inbox', 'menu' => '' ],
            'replacement' => [ 'title' => 'خرید طلای جایگزین', 'description' => 'وزن موردنیاز هر سفارش و نتیجه خرید از تأمین‌کننده.', 'icon' => 'repeat', 'menu' => 'more' ],
            'packaging' => [ 'title' => 'ارسال سفارش‌ها', 'description' => 'پیگیری سفارش از آماده‌سازی تا تحویل به ارسال.', 'icon' => 'package', 'menu' => '' ],
            'transfers' => [ 'title' => 'انتقال طلا و پول', 'description' => 'انتقال طلا، وجه و تبادل بین حساب‌های بنکداری.', 'icon' => 'swap', 'menu' => 'more', 'create' => 'ثبت انتقال جدید' ],
            'ledger' => [ 'title' => 'گردش کیف طلایی', 'description' => 'گردش موجودی گرمی کاربران و ثبت اصلاحات مستند.', 'icon' => 'wallet', 'menu' => 'more', 'create' => 'اصلاح موجودی' ],
            'books' => [ 'title' => 'حساب‌ها', 'description' => 'حساب مشتری، تأمین‌کننده، بانک و صندوق را مدیریت کنید.', 'icon' => 'users', 'menu' => 'more', 'create' => 'افزودن حساب' ],
            'inventory' => [ 'title' => 'کالاها', 'description' => 'قطعات آب‌شده، کالاهای زینتی و آخرین تغییر وضعیت‌ها.', 'icon' => 'layers', 'menu' => 'more' ],
            'reports' => [ 'title' => 'گزارش فروش', 'description' => 'تراز حساب‌ها و فروش را در بازه دلخواه بررسی کنید.', 'icon' => 'bar-chart', 'menu' => 'more' ],
            'events' => [ 'title' => 'پیام‌ها', 'description' => 'رویدادهای سیستم و نتیجه ارسال به پیام‌رسان.', 'icon' => 'bell', 'menu' => 'more' ],
            'settings' => [ 'title' => 'تنظیمات بنکداری', 'description' => 'سیاست کیف طلایی، نرخ طلا و خدمات اشتراک پلاس.', 'icon' => 'setting', 'menu' => 'more' ],
        ];
    }
    public static function url( string $section = 'dashboard', array $query = [] ): string {
        $section = isset( self::sections()[ $section ] ) ? $section : 'dashboard';
        $url = home_url( '/' . KERP_SLUG . '/gold/' . ( $section === 'dashboard' ? '' : $section . '/' ) );
        return $query ? add_query_arg( $query, $url ) : $url;
    }
    private static function return_url(): string {
        $query = []; foreach ( [ 'q', 'status', 'gold_page', 'view', 'gold_start', 'gold_end' ] as $key ) { $value = self::get( $key ); if ( $value !== '' ) { $query[ $key ] = $value; } }
        return self::url( self::$section, $query );
    }
    public static function legacy_redirect(): void {
        if ( ! current_user_can( 'manage_options' ) || ! kerp_is_erp_request() || ! isset( $_GET['tab'] ) || ! is_string( $_GET['tab'] ) ) { return; }
        $route = KERP_Core_Router::instance()->get_route(); $section = sanitize_key( $_GET['tab'] );
        if ( $route !== [ 'gold' ] || ! isset( self::sections()[ $section ] ) ) { return; }
        $query = []; foreach ( [ 'q', 'status', 'gold_page', 'view', 'gold_start', 'gold_end' ] as $key ) { if ( isset( $_GET[ $key ] ) && is_scalar( $_GET[ $key ] ) ) { $query[ $key ] = sanitize_text_field( wp_unslash( (string) $_GET[ $key ] ) ); } }
        wp_safe_redirect( self::url( $section, $query ) ); exit;
    }
    public static function current( array $context = [] ): string {
        $key = (string) ( $context['slug'] ?? '' );
        if ( str_starts_with( $key, 'gold-' ) && $key !== 'gold-wholesale' ) { $section = substr( $key, 5 ); if ( isset( self::sections()[ $section ] ) ) { return $section; } }
        $query = $context['query'] ?? $_GET;
        $legacy = isset( $query['tab'] ) && is_string( $query['tab'] ) ? sanitize_key( $query['tab'] ) : '';
        return isset( self::sections()[ $legacy ] ) ? $legacy : 'dashboard';
    }
    public static function get( string $key, string $default = '' ): string {
        $query = self::$query ?? wp_unslash( $_GET ); return isset( $query[ $key ] ) && is_scalar( $query[ $key ] ) ? sanitize_text_field( (string) $query[ $key ] ) : $default;
    }
    public static function icon( string $icon ): string { return '<em class="icon ni ni-' . esc_attr( $icon ) . '" aria-hidden="true"></em>'; }
    public static function link( string $section, string $label, string $class = 'btn btn-white btn-outline-light', string $icon = '', array $query = [] ): void {
        $url = self::url( $section, $query );
        echo '<a href="' . esc_url( $url ) . '" data-url="' . esc_attr( wp_make_link_relative( $url ) ) . '" class="page_activator ' . esc_attr( $class ) . '">' . ( $icon ? self::icon( $icon ) : '' ) . '<span>' . esc_html( $label ) . '</span></a>';
    }
    public static function weight( int $units ): string { return rtrim( rtrim( KERP_Modules_Gold_Math::grams( $units ), '0' ), '.' ); }
    public static function money( int $amount, string $currency = '', ?int $decimals = null ): string {
        $currency = $currency ?: get_woocommerce_currency(); $decimals = $decimals ?? wc_get_price_decimals();
        return wc_price( $amount / ( 10 ** $decimals ), [ 'currency' => $currency, 'decimals' => $decimals ] );
    }
    public static function date( string $utc, bool $time = true ): string {
        if ( $utc === '' ) { return '—'; }
        $local = wp_date( 'Y-m-d H:i:s', strtotime( $utc . ' UTC' ) );
        $date = KERP_Helpers_Date::local_datetime_to_jalali( $local );
        return $date ? str_replace( '-', '/', substr( $date, 0, $time ? 16 : 10 ) ) : $local;
    }
    public static function user( int $id ): string { $user = get_userdata( $id ); if ( ! $user ) { return 'کاربر حذف‌شده'; } $name = function_exists( 'get_user_name_by_id' ) ? KERP_Helpers_User::get_display_name( $id, false, false ) : ''; return $name ?: ( $user->display_name ?: $user->user_login ); }
    public static function order_status( string $status ): string {
        return [ 'pending' => 'پرداخت نشده', 'processing' => 'در حال انجام', 'completed' => 'تکمیل‌شده', 'on-hold' => 'در انتظار بررسی', 'cancelled' => 'لغوشده', 'refunded' => 'برگشت خورده', 'failed' => 'پرداخت ناموفق', 'checkout-draft' => 'ثبت نشده' ][ $status ] ?? wc_get_order_status_name( $status );
    }
    public static function badge( string $status, string $label = '' ): string {
        $color = [ 'pending' => 'warning', 'completed' => 'success', 'sent' => 'success', 'shipped' => 'success', 'packed' => 'info', 'packing' => 'primary', 'queued' => 'primary', 'processing' => 'primary', 'rejected' => 'danger', 'failed' => 'danger', 'error' => 'danger', 'review' => 'warning', 'review_bought' => 'warning', 'local' => 'light', 'sending' => 'info', 'in_stock' => 'success', 'consigned' => 'info', 'reserved' => 'warning', 'returned' => 'danger', 'received' => 'light', 'sold' => 'light' ][ $status ] ?? 'light';
        $labels = [ 'packing' => 'در حال بسته‌بندی', 'packed' => 'بسته‌بندی شد', 'shipped' => 'ارسال شد', 'processing' => 'در حال انجام', 'error' => 'خطا', 'cancelled' => 'لغوشده', 'refunded' => 'بازپرداخت‌شده' ];
        $text = $label ?: ( KERP_Modules_Gold_Module::states()[ $status ] ?? $labels[ $status ] ?? KERP_Modules_Gold_Admin::label( $status ) );
        return '<span class="badge badge-dot bg-' . esc_attr( $color ) . ' kg-badge">' . esc_html( $text ) . '</span>';
    }
    public static function card( string $title, string $description = '', string $class = '' ): void {
        $folded = self::$section === 'settings' && $title !== 'نرخ و قیمت طلا'; self::$card_stack[] = $folded;
        if ( $folded ) { echo '<details class="card card-bordered kg-settings-fold"><summary>' . esc_html( $title ) . self::icon( 'chevron-down' ) . '</summary><div class="card-inner">'; return; }
        echo '<div class="card card-bordered kg-card ' . esc_attr( $class ) . '"><div class="card-inner kg-card-heading"><div><h2 class="title fs-18px mb-0">' . esc_html( $title ) . '</h2>';
        echo '</div></div><div class="card-inner pt-0">';
    }
    public static function end_card(): void { echo array_pop( self::$card_stack ) ? '</div></details>' : '</div></div>'; }
    public static function empty( string $title, string $description = '', string $icon = 'inbox' ): void {
        KERP_Helpers_Template::render_template( 'app/components/settings/empty-state.php', [ 'title' => $title, 'description' => $description, 'icon' => 'icon ni ni-' . $icon, 'class' => 'kg-empty' ] );
    }
    public static function note( string $text, string $type = 'info' ): void { echo '<div class="alert alert-' . esc_attr( $type ) . ' alert-icon kg-note" role="note">' . self::icon( 'info' ) . esc_html( $text ) . '</div>'; }
    public static function field( string $name, string $label, $value = '', string $type = 'text', bool $required = true, string $hint = '', string $class = 'col-md-6', string $attrs = '' ): void {
        $id = 'kg-field-' . ++self::$sequence; $attrs .= $hint ? ' aria-describedby="' . esc_attr( $id . '-note' ) . '"' : '';
        echo '<div class="' . esc_attr( $class ) . '"><div class="form-group"><label class="form-label" for="' . esc_attr( $id ) . '">' . esc_html( $label ) . ( $required ? '<span class="text-danger ms-1" aria-hidden="true">*</span>' : '' ) . '</label><div class="form-control-wrap">';
        if ( $type === 'textarea' ) { echo '<textarea class="form-control" rows="3" id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" ' . ( $required ? 'required' : '' ) . ' ' . $attrs . '>' . esc_textarea( $value ) . '</textarea>'; }
        else { echo '<input class="form-control" id="' . esc_attr( $id ) . '" type="' . esc_attr( $type ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '" ' . ( $required ? 'required' : '' ) . ' ' . ( in_array( $type, [ 'number', 'url', 'date' ], true ) ? 'dir="ltr"' : '' ) . ' ' . $attrs . '>'; }
        echo '</div>'; if ( $hint ) { echo '<div class="form-note" id="' . esc_attr( $id . '-note' ) . '">' . esc_html( $hint ) . '</div>'; } echo '</div></div>';
    }
    public static function select( string $name, string $label, array $options, string $value = '', string $class = 'col-md-6' ): void {
        $id = 'kg-select-' . ++self::$sequence;
        echo '<div class="' . esc_attr( $class ) . '"><div class="form-group"><label class="form-label" for="' . esc_attr( $id ) . '">' . esc_html( $label ) . '</label><div class="form-control-wrap"><select class="form-select" id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" ' . ( array_key_exists( '', $options ) ? 'required' : '' ) . '>';
        foreach ( $options as $key => $text ) { echo '<option value="' . esc_attr( $key ) . '" ' . selected( (string) $value, (string) $key, false ) . '>' . esc_html( $text ) . '</option>'; } echo '</select></div></div></div>';
    }
    public static function lookup( string $name, string $label, string $kind, int $value = 0, bool $required = true, string $class = 'col-md-6' ): void {
        $id = 'kg-lookup-' . ++self::$sequence; $text = '';
        if ( $value ) { $object = $kind === 'users' ? get_userdata( $value ) : wc_get_product( $value ); $text = $object ? ( $kind === 'users' ? $object->display_name : $object->get_name() ) : '#' . $value; }
        echo '<div class="' . esc_attr( $class ) . '"><div class="form-group kg-lookup" data-kg-lookup="' . esc_attr( $kind ) . '" data-empty="' . ( $required ? '' : '0' ) . '"><label class="form-label" for="' . esc_attr( $id ) . '">' . esc_html( $label ) . '</label><div class="form-control-wrap"><div class="form-icon form-icon-right">' . self::icon( 'search' ) . '</div><input type="search" class="form-control kg-lookup-input" id="' . esc_attr( $id ) . '" value="' . esc_attr( $text ) . '" placeholder="جستجو با نام یا شماره…" autocomplete="off" role="combobox" aria-autocomplete="list" aria-expanded="false" aria-controls="' . esc_attr( $id . '-list' ) . '" ' . ( $required ? 'required' : '' ) . '><input type="hidden" name="' . esc_attr( $name ) . '" value="' . ( $value ?: ( $required ? '' : '0' ) ) . '" data-kg-id><div class="kg-lookup-results" role="listbox" id="' . esc_attr( $id . '-list' ) . '" hidden></div></div><span class="form-note kg-lookup-status" aria-live="polite">' . ( $text ? 'گزینه انتخاب‌شده' : 'نام را بنویسید و از نتایج انتخاب کنید.' ) . '</span></div></div>';
    }
    public static function hidden( string $name, $value ): void { echo '<input type="hidden" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '">'; }
    public static function open_form( string $operation ): void {
        KERP_Modules_Gold_Admin::start_form( $operation );
        if ( in_array( $operation, [ 'book', 'transfer', 'offline_sale', 'adjust', 'reverse_document', 'packaging_status' ], true ) ) { self::hidden( 'reference', wp_generate_uuid4() ); }
    }
    public static function form_footer( string $label, bool $modal = true, string $hint = '' ): void {
        echo '<div class="kg-form-footer' . ( $modal ? '' : ' kg-settings-save' ) . '">'; if ( $hint ) { echo '<span class="text-soft">' . esc_html( $hint ) . '</span>'; } if ( $modal ) { echo '<button type="button" class="btn btn-white btn-outline-light" data-bs-dismiss="modal">انصراف</button>'; }
        echo '<button type="submit" class="btn btn-primary">' . self::icon( 'check' ) . '<span>' . esc_html( $label ) . '</span></button></div></form>';
    }
    public static function modal( string $id, string $title, callable $body, string $subtitle = '' ): void {
        echo '<div class="modal fade kg-modal" id="' . esc_attr( $id ) . '" tabindex="-1" aria-labelledby="' . esc_attr( $id . '-title' ) . '" aria-hidden="true"><div class="modal-dialog modal-dialog-centered modal-lg"><div class="modal-content"><div class="modal-header"><div><h4 class="modal-title" id="' . esc_attr( $id . '-title' ) . '">' . esc_html( $title ) . '</h4>';
        if ( $subtitle ) { echo '<p class="text-soft small mb-0 mt-1">' . esc_html( $subtitle ) . '</p>'; }
        echo '</div><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="بستن"></button></div><div class="modal-body">'; $body(); echo '</div></div></div></div>';
    }
    public static function action( string $modal, string $label, string $icon = 'edit', string $type = 'btn-outline-primary' ): void { echo '<button class="btn btn-sm ' . esc_attr( $type ) . '" type="button" data-bs-toggle="modal" data-bs-target="#' . esc_attr( $modal ) . '">' . self::icon( $icon ) . '<span>' . esc_html( $label ) . '</span></button>'; }
    public static function confirm( string $label ): void { $id = 'kg-confirm-' . ++self::$sequence; echo '<div class="custom-control custom-checkbox mt-3"><input type="checkbox" class="custom-control-input" id="' . esc_attr( $id ) . '" required><label class="custom-control-label" for="' . esc_attr( $id ) . '">' . esc_html( $label ) . '</label></div>'; }
    public static function render( array $context = [] ): void {
        if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'دسترسی کافی ندارید.' ); }
        self::$query = isset( $context['query'] ) && is_array( $context['query'] ) ? $context['query'] : wp_unslash( $_GET );
        self::$section = self::current( $context ); $meta = self::sections()[ self::$section ];
        KERP_Modules_Gold_Admin::$return_url = self::return_url();
        echo '<div class="kg-ui" data-section="' . esc_attr( self::$section ) . '" data-kg-open-create="' . ( self::get( 'new' ) === '1' ? '1' : '0' ) . '" dir="rtl"><div class="nk-block-head nk-block-head-sm"><div class="nk-block-between g-3"><div class="nk-block-head-content">';
        if ( self::$section !== 'dashboard' ) { self::link( 'dashboard', 'خانه', 'kg-breadcrumb-link', 'arrow-right' ); }
        echo '<h1 class="nk-block-title page-title">' . esc_html( $meta['title'] ) . '</h1></div><div class="nk-block-head-content d-flex gap-2 flex-wrap">';
        if ( ! empty( $meta['create'] ) ) { self::action( 'gold-create', $meta['create'], 'plus', 'btn-primary' ); }
        echo '</div></div></div>'; KERP_Modules_Gold_Admin::messages(); self::render_section( self::$section, self::$query ); self::recovery(); echo '</div>';
    }
    public static function recovery(): void {
        $key = 'kerp_gold_draft_' . get_current_user_id(); $draft = get_transient( $key );
        if ( ! is_array( $draft ) || ( $draft['return'] ?? '' ) !== self::return_url() ) { return; }
        delete_transient( $key );
        echo '<script type="application/json" data-kg-recovery>' . wp_json_encode( $draft, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT ) . '</script>';
    }
    public static function render_section( string $section, ?array $query = null ): void {
        if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'دسترسی کافی ندارید.' ); }
        self::$query = $query ?? wp_unslash( $_GET );
        self::$section = isset( self::sections()[ $section ] ) ? $section : 'dashboard';
        if ( in_array( self::$section, [ 'requests', 'replacement' ], true ) && ! array_key_exists( 'status', self::$query ) && ! self::get( 'q' ) ) { self::$query['status'] = 'pending'; }
        KERP_Modules_Gold_Admin::$return_url = self::return_url();
        $template = in_array( $section, [ 'requests', 'replacement', 'packaging', 'ledger', 'events' ], true ) ? 'queues' : $section;
        KERP_Helpers_Template::render_template( 'modules/gold/pages/' . $template . '.php', [ 'section' => self::$section ] );
    }
    public static function pagination( int $total, int $per_page = 15 ): void {
        if ( $total <= $per_page ) { return; } $pages = (int) ceil( $total / $per_page ); $page = min( $pages, max( 1, (int) self::get( 'gold_page', '1' ) ) );
        echo '<div class="kg-pagination"><span class="sub-text">صفحه ' . esc_html( number_format_i18n( $page ) ) . ' از ' . esc_html( number_format_i18n( $pages ) ) . ' · ' . esc_html( number_format_i18n( $total ) ) . ' مورد</span><nav aria-label="صفحه‌های نتایج"><ul class="pagination">';
        foreach ( [ -1 => 'قبلی', 1 => 'بعدی' ] as $delta => $label ) { $disabled = $page + $delta < 1 || $page + $delta > $pages; echo '<li class="page-item ' . ( $disabled ? 'disabled' : '' ) . '">'; if ( $disabled ) { echo '<span class="page-link" aria-disabled="true">' . esc_html( $label ) . '</span>'; } else { $query = array_filter( [ 'gold_page' => $page + $delta, 'q' => self::get( 'q' ), 'status' => self::get( 'status' ), 'view' => self::get( 'view' ) ] ); if ( in_array( self::$section, [ 'requests', 'replacement' ], true ) ) { $query['status'] = self::get( 'status' ); } self::link( self::$section, $label, 'page-link', '', $query ); } echo '</li>'; }
        echo '</ul></nav></div>';
    }
    public static function table( array $columns, array $rows, string $empty = 'هنوز موردی ثبت نشده است.', string $description = '' ): void {
        if ( ! $rows ) { self::empty( $empty, $description ); return; }
        echo '<div class="kg-table-wrap"><table class="table kg-table"><thead><tr>'; foreach ( $columns as $label ) { echo '<th scope="col">' . esc_html( $label ) . '</th>'; } echo '</tr></thead><tbody>';
        foreach ( $rows as $row ) { echo '<tr>'; foreach ( array_values( $columns ) as $i => $label ) { $cell = $row[ $i ] ?? ''; echo '<td data-label="' . esc_attr( $label ) . '">' . ( is_array( $cell ) && isset( $cell['html'] ) ? $cell['html'] : esc_html( (string) $cell ) ) . '</td>'; } echo '</tr>'; } echo '</tbody></table></div>';
    }
    public static function html( string $safe ): array { return [ 'html' => $safe ]; }
    public static function table_filter( array $statuses = [] ): void {
        echo '<form method="get" action="' . esc_url( self::url( self::$section ) ) . '" class="kg-toolbar"><div class="form-control-wrap kg-search"><div class="form-icon form-icon-right">' . self::icon( 'search' ) . '</div><input class="form-control" name="q" value="' . esc_attr( self::get( 'q' ) ) . '" placeholder="نام یا شماره را بنویسید" aria-label="جستجو در فهرست"></div>';
        if ( $statuses ) { echo '<select class="form-select kg-filter-status" name="status" aria-label="فیلتر وضعیت"><option value="">همه وضعیت‌ها</option>'; foreach ( $statuses as $key => $label ) { echo '<option value="' . esc_attr( $key ) . '" ' . selected( self::get( 'status' ), $key, false ) . '>' . esc_html( $label ) . '</option>'; } echo '</select>'; }
        echo '<button class="btn btn-white btn-outline-light" type="submit">جستجو</button>'; if ( self::get( 'q' ) || self::get( 'status' ) ) { self::link( self::$section, 'پاک کردن', 'btn btn-link text-soft' ); } echo '</form>';
    }
    public static function query( string $name ): array {
        global $wpdb; $allowed = [ 'requests', 'replacement', 'packaging', 'ledger', 'events', 'books', 'sales', 'statushistory' ]; if ( ! in_array( $name, $allowed, true ) ) { throw new InvalidArgumentException( 'table' ); }
        $table = KERP_Modules_Gold_Store::table( $name ); $id = in_array( $name, [ 'sales', 'packaging' ], true ) ? 'order_id' : 'id';
        $status_column = $name === 'events' ? 'delivery' : 'status'; $where = '1=1';
        $status = self::get( 'status' ); if ( $status && in_array( $name, [ 'requests', 'replacement', 'packaging', 'sales', 'events' ], true ) ) { $where .= $wpdb->prepare( " AND t.$status_column=%s", $status ); }
        $q = mb_substr( self::get( 'q' ), 0, 100, 'UTF-8' ); $join = '';
        if ( $q !== '' ) {
            $search = '%' . $wpdb->esc_like( $q ) . '%'; $cols = [ 'books' => [ 'label', 'details', 'party_type' ], 'events' => [ 'event', 'reference', 'hashtag' ], 'sales' => [ 'source', 'currency' ], 'statushistory' => [ 'object_type', 'old_state', 'new_state' ] ][ $name ] ?? [ 'note', 'reference' ];
            $parts = [ $wpdb->prepare( "CAST(t.$id AS CHAR) LIKE %s", $search ) ]; foreach ( $cols as $col ) { $parts[] = $wpdb->prepare( "t.$col LIKE %s", $search ); }
            if ( in_array( $name, [ 'requests', 'ledger', 'sales' ], true ) ) { $join = " LEFT JOIN {$wpdb->users} u ON u.ID=t.user_id"; $parts[] = $wpdb->prepare( 'u.display_name LIKE %s', $search ); }
            if ( in_array( $name, [ 'replacement', 'packaging' ], true ) ) { $join = ' LEFT JOIN ' . KERP_Modules_Gold_Store::table( 'sales' ) . " s ON s.order_id=t.order_id LEFT JOIN {$wpdb->users} u ON u.ID=s.user_id"; $parts[] = $wpdb->prepare( 'u.display_name LIKE %s', $search ); $parts[] = $wpdb->prepare( 'CAST(t.order_id AS CHAR) LIKE %s', $search ); }
            $where .= ' AND (' . implode( ' OR ', $parts ) . ')';
        }
        $total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $table t$join WHERE $where" ); $page = min( max( 1, (int) self::get( 'gold_page', '1' ) ), max( 1, (int) ceil( $total / 15 ) ) );
        $rows = $wpdb->get_results( $wpdb->prepare( "SELECT t.* FROM $table t$join WHERE $where ORDER BY t.$id DESC LIMIT 15 OFFSET %d", ( $page - 1 ) * 15 ) ); return [ 'rows' => $rows, 'total' => $total ];
    }
}
