<?php

defined( 'ABSPATH' ) || exit;

/**
 * @var array $page_context
 */

$page_template = (string) (
	$page_context['template']
	?? 'app/pages/not-found.php'
);

?>
<div class="nk-main" data-page="<?php echo esc_attr( $page_context['slug'] ?? '' ); ?>">
	<?php
	KERP_Helpers_Template::render_template(
		'app/sidebar.php',
		[
			'page_context' => $page_context,
		]
	);
	?>
    <div class="nk-wrap">
		<?php
		KERP_Helpers_Template::render_template(
			'app/header.php',
			[
				'page_context' => $page_context,
			]
		);
		?>
        <div class="nk-content nk-content-fluid">
            <div class="container-xl wide-xl">
                <div class="nk-content-body">
					<?php
					KERP_Helpers_Template::render_template(
						$page_template,
						[
							'page_context' => $page_context,
							'params'       => $page_context['params'] ?? [],
						]
					);
					?>
                </div>
            </div>
        </div>
		<?php
		KERP_Helpers_Template::render_template(
			'app/footer.php',
			[
				'page_context' => $page_context,
			]
		);
		?>
    </div>
</div>