<?php

defined( 'ABSPATH' ) || exit;

$id           = sanitize_html_class( (string) ( $field['id'] ?? '' ) );
$name         = (string) ( $field['name'] ?? '' );
$label        = (string) ( $field['label'] ?? '' );
$column_class = (string) ( $field['class'] ?? 'col-12' );
$terms        = isset( $field['terms'] ) && is_array( $field['terms'] ) ? $field['terms'] : [];
$value        = array_values( array_unique( array_filter( array_map( 'absint', (array) ( $field['value'] ?? [] ) ) ) ) );
$required     = ! empty( $field['required'] );
$map          = [];
$children     = [];

foreach ( $terms as $term ) {
	$term_id = absint( $term['id'] ?? 0 );
	if ( $term_id <= 0 ) {
		continue;
	}
	$term['id']        = $term_id;
	$term['parent_id'] = absint( $term['parent_id'] ?? 0 );
	$map[ $term_id ]   = $term;
}
foreach ( $map as $term ) {
	$parent_id = isset( $map[ $term['parent_id'] ] ) && $term['parent_id'] !== $term['id'] ? $term['parent_id'] : 0;
	$children[ $parent_id ][] = $term;
}

$path_for = static function ( int $term_id ) use ( $map ): string {
	$path = [];
	$seen = [];
	while ( isset( $map[ $term_id ] ) && ! isset( $seen[ $term_id ] ) ) {
		$seen[ $term_id ] = TRUE;
		array_unshift( $path, (string) $map[ $term_id ]['name'] );
		$term_id = (int) $map[ $term_id ]['parent_id'];
	}
	return implode( ' / ', $path );
};
$visited = [];
$render_node = static function ( array $term, int $level = 1 ) use ( &$render_node, &$visited, $children, $path_for, $id ): void {
	$term_id = (int) $term['id'];
	if ( isset( $visited[ $term_id ] ) ) {
		return;
	}
	$visited[ $term_id ] = TRUE;
	$child_terms = $children[ $term_id ] ?? [];
	$is_open     = $level === 1;
	$branch_id   = $id . '-branch-' . $term_id;
	$path        = $path_for( $term_id );
	$search      = $path . ' ' . (string) ( $term['description'] ?? '' ) . ' ' . (string) ( $term['slug'] ?? '' );
	?>
    <div class="kerp-taxonomy-picker__node" data-node="<?php echo esc_attr( $term_id ); ?>" data-search="<?php echo esc_attr( $search ); ?>" data-path="<?php echo esc_attr( $path ); ?>">
        <div class="kerp-taxonomy-picker__row" style="--taxonomy-level:<?php echo esc_attr( max( 0, $level - 1 ) ); ?>">
            <button type="button" class="kerp-taxonomy-picker__toggle" aria-controls="<?php echo esc_attr( $branch_id ); ?>" aria-expanded="<?php echo $is_open ? 'true' : 'false'; ?>" <?php disabled( empty( $child_terms ) ); ?>><em class="icon ni <?php echo empty( $child_terms ) ? 'ni-minus' : ( $is_open ? 'ni-chevron-down' : 'ni-chevron-left' ); ?>"></em></button>
            <label title="<?php echo esc_attr( $path ); ?>">
                <input type="checkbox" class="kerp-taxonomy-picker__check" value="<?php echo esc_attr( $term_id ); ?>">
                <em class="icon ni <?php echo empty( $child_terms ) ? 'ni-file-text' : 'ni-folder'; ?>"></em>
                <span><?php echo esc_html( (string) $term['name'] ); ?></span>
            </label>
            <?php if ( $child_terms ) : ?><small><?php echo esc_html( number_format_i18n( count( $child_terms ) ) ); ?></small><?php endif; ?>
        </div>
        <?php if ( $child_terms ) : ?>
            <div id="<?php echo esc_attr( $branch_id ); ?>" class="kerp-taxonomy-picker__branches" <?php echo $is_open ? '' : 'hidden'; ?>>
                <?php foreach ( $child_terms as $child ) { $render_node( $child, $level + 1 ); } ?>
            </div>
        <?php endif; ?>
    </div>
	<?php
};
?>
<div class="<?php echo esc_attr( $column_class ); ?> meta-field-row">
    <div class="form-group kerp-taxonomy-picker" data-picker="<?php echo esc_attr( $id ); ?>">
        <div class="kerp-taxonomy-picker__heading">
            <label class="form-label" for="<?php echo esc_attr( $id . '-search' ); ?>"><?php echo esc_html( $label ); ?><?php if ( $required ) : ?> <span class="text-danger">*</span><?php endif; ?></label>
            <span class="kerp-taxonomy-picker__count">۰ انتخاب</span>
        </div>
        <select id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $name ); ?>" class="kerp-taxonomy-picker__select" data-for="<?php echo esc_attr( $name ); ?>" data-req="<?php echo $required ? '1' : '0'; ?>" multiple aria-hidden="true" tabindex="-1">
            <?php foreach ( $map as $term_id => $term ) : ?>
                <option value="<?php echo esc_attr( $term_id ); ?>" <?php selected( in_array( $term_id, $value, TRUE ) ); ?>><?php echo esc_html( (string) $term['name'] ); ?></option>
            <?php endforeach; ?>
        </select>
        <div class="kerp-taxonomy-picker__toolbar">
            <div class="kerp-taxonomy-picker__search-wrap"><em class="icon ni ni-search"></em><input id="<?php echo esc_attr( $id . '-search' ); ?>" type="search" class="form-control kerp-taxonomy-picker__search" placeholder="جستجو در نام، مسیر یا توضیحات…"></div>
            <button type="button" class="btn btn-sm btn-outline-light kerp-taxonomy-picker__expand" data-open="1">بازکردن همه</button>
            <button type="button" class="btn btn-sm btn-outline-light kerp-taxonomy-picker__clear">پاک‌کردن انتخاب‌ها</button>
        </div>
        <div class="kerp-taxonomy-picker__selected" aria-live="polite"></div>
        <div class="kerp-taxonomy-picker__tree" role="tree" aria-multiselectable="true">
            <?php foreach ( $children[0] ?? [] as $root_term ) { $render_node( $root_term ); } ?>
            <?php foreach ( $map as $term ) { if ( ! isset( $visited[ $term['id'] ] ) ) { $render_node( $term ); } } ?>
            <p class="kerp-taxonomy-picker__empty" hidden>موردی با این عبارت پیدا نشد.</p>
        </div>
        <small class="form-text text-soft">می‌توانید چند مبحث را از شاخه‌های مختلف انتخاب کنید؛ مسیر کامل هر مورد با نگه‌داشتن نشانگر روی آن دیده می‌شود.</small>
    </div>
</div>
