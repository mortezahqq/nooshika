<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * @var array $field
 */

$id    = $field['id'] ?? '';
$name  = $field['name'] ?? '';
$class = $field['class'] ?? 'col-12';
$label = $field['label'] ?? '';
$value = $field['value'] ?? '';
?>

<div class="<?php echo esc_attr( $class ); ?> meta-field-row"
     data-conditional="<?php echo ! empty( $field['conditional'] ) ? '1' : '0'; ?>"
     data-cond-meta="<?php echo esc_attr( $field['cond_meta'] ?? '' ); ?>"
     data-cond-operator="<?php echo esc_attr( $field['cond_operator'] ?? '==' ); ?>"
     data-cond-expected="<?php echo esc_attr( $field['cond_expected'] ?? '' ); ?>">
    <div class="form-group">
		<?php if ( $label ) { ?>
            <label class="form-label">
				<?php echo esc_html( $label ); ?>
            </label>
		<?php } ?>
        <div class="quill-basic"
             id="<?php echo esc_attr( $id ); ?>"
             data-for="<?php echo esc_attr( $name ); ?>"
		     data-req="<?php echo ! empty( $field['required'] ) ? '1' : '0'; ?>"
             data-type="quill">
            <textarea class="d-none quill-value"><?php echo esc_textarea( $value ); ?></textarea>
        </div>

    </div>
</div>
