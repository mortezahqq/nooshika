<?php

defined( 'ABSPATH' ) || exit;

$id           = (string) ( $field['id'] ?? '' );
$name         = (string) ( $field['name'] ?? '' );
$label        = (string) ( $field['label'] ?? '' );
$column_class = (string) ( $field['class'] ?? 'col-md-6' );
$input_class  = (string) ( $field['input_class'] ?? '' );
$value        = (string) ( $field['value'] ?? '' );
$required     = ! empty( $field['required'] );
?>
<div class="<?php echo esc_attr( $column_class ); ?> meta-field-row">
	<div class="form-group">
		<?php if ( $label !== '' ) : ?>
			<label class="form-label" for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $label ); ?></label>
		<?php endif; ?>
		<div class="form-control-wrap">
			<input type="time"
			       id="<?php echo esc_attr( $id ); ?>"
			       name="<?php echo esc_attr( $name ); ?>"
			       data-for="<?php echo esc_attr( $name ); ?>"
			       class="form-control <?php echo esc_attr( $input_class ); ?>"
			       value="<?php echo esc_attr( $value ); ?>"
			       step="60"
				<?php echo $required ? ' data-req="1"' : ''; ?>>
		</div>
	</div>
</div>
