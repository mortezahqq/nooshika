<?php
defined( 'ABSPATH' ) || exit;
$id = (string) $field['id'];
$resource_label = (string) ( $field['resource_label'] ?? 'محصول' );
$field['selected_label'] = $field['selected_label'] ?? ( ! empty( $field['value'] ) ? get_the_title( (int) $field['value'] ) : '' );
?>
<div class="<?php echo esc_attr( $field['class'] ); ?> meta-field-row kerp-lead-product-picker" data-search-action="<?php echo esc_attr( $field['search_action'] ?? 'leads_search_products' ); ?>" data-resource-label="<?php echo esc_attr( $resource_label ); ?>">
    <label class="form-label" for="<?php echo esc_attr( $id . '-search' ); ?>"><?php echo esc_html( $field['label'] ); ?></label>
    <input type="hidden" class="no_clear" data-for="<?php echo esc_attr( $field['name'] ); ?>" data-req="<?php echo ( $field['required'] ?? TRUE ) ? '1' : '0'; ?>" value="<?php echo esc_attr( $field['value'] ); ?>">
    <div class="d-flex gap-2">
        <input id="<?php echo esc_attr( $id . '-search' ); ?>" class="form-control no_clear kerp-lead-product-search" type="search" autocomplete="off" placeholder="<?php echo esc_attr( 'نام ' . $resource_label . ' را بنویسید (حداقل دو حرف)' ); ?>" value="<?php echo esc_attr( $field['selected_label'] ); ?>" aria-controls="<?php echo esc_attr( $id . '-results' ); ?>" aria-describedby="<?php echo esc_attr( $id . '-status' ); ?>">
        <button type="button" class="btn btn-outline-light kerp-lead-product-clear" aria-label="<?php echo esc_attr( 'پاک‌کردن ' . $resource_label . ' انتخاب‌شده' ); ?>">پاک‌کردن</button>
    </div>
    <div id="<?php echo esc_attr( $id . '-status' ); ?>" class="kerp-lead-product-status text-soft small mt-2" role="status" aria-live="polite"><?php echo esc_html( $field['value'] ? $resource_label . ' انتخاب شده است.' : 'پس از جستجو، ' . $resource_label . ' را از نتایج انتخاب کنید.' ); ?></div>
    <div id="<?php echo esc_attr( $id . '-results' ); ?>" class="kerp-lead-product-results list-group mt-2" hidden></div>
</div>
