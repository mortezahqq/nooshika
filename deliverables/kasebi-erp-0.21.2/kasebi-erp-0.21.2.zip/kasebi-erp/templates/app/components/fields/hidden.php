<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * @var array $field
 */

$id    = $field['id'] ?? '';
$name  = $field['name'] ?? '';
$value = $field['value'] ?? '';
$class = trim( implode( ' ', array_filter( [
	(string) ( $field['class'] ?? '' ),
	(string) ( $field['input_class'] ?? '' ),
] ) ) );
?>

<input type="hidden"
       id="<?php echo esc_attr( $id ); ?>"
       class="<?php echo esc_attr( $class ); ?>"
       data-for="<?php echo esc_attr( $name ); ?>"
       value="<?php echo esc_attr( $value ); ?>">
