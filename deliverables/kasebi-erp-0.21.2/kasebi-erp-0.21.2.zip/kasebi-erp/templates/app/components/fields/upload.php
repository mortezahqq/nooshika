<?php

defined( 'ABSPATH' ) || exit;

/**
 * @var array $field
 */

$id             = $field['id'] ?? '';
$name           = $field['name'] ?? '';
$label          = $field['label'] ?? '';
$column_class   = $field['class'] ?? 'col-12';
$value          = $field['value'] ?? '';
$action         = $field['action'] ?? 'handle_file_upload';
$max_files      = absint( $field['max_files'] ?? 1 );
$accepted_files = $field['accepted_files'] ?? '';
$required       = ! empty( $field['required'] );
?>

<div class="<?php echo esc_attr( $column_class ); ?> meta-field-row"
     data-conditional="<?php echo ! empty( $field['conditional'] ) ? '1' : '0'; ?>"
     data-cond-meta="<?php echo esc_attr( $field['cond_meta'] ?? '' ); ?>"
     data-cond-operator="<?php echo esc_attr( $field['cond_operator'] ?? '==' ); ?>"
     data-cond-expected="<?php echo esc_attr( $field['cond_expected'] ?? '' ); ?>">
    <div class="form-group">
		<?php if ( $label !== '' ) : ?>
            <label class="form-label" for="<?php echo esc_attr( $id ); ?>">
				<?php echo esc_html( $label ); ?>
            </label>
		<?php endif; ?>

        <div class="upload-zone"
             data-target="#<?php echo esc_attr( $id ); ?>"
             data-action="<?php echo esc_attr( $action ); ?>"
             data-max-files="<?php echo esc_attr( $max_files ); ?>"
             data-urls="<?php echo esc_attr( $value ); ?>"
			<?php if ( $accepted_files !== '' ) : ?>
                data-accepted-files="<?php echo esc_attr( $accepted_files ); ?>"
			<?php endif; ?>>
            <div class="dz-message" data-dz-message>
                <span class="dz-message-text"><?php esc_html_e( 'بکشید و رها کنید', 'kasebi-erp' ); ?></span>
                <span class="dz-message-or"><?php esc_html_e( 'یا', 'kasebi-erp' ); ?></span>
                <div class="btn btn-primary"><?php esc_html_e( 'انتخاب کنید', 'kasebi-erp' ); ?></div>
            </div>
        </div>

        <input type="hidden"
               id="<?php echo esc_attr( $id ); ?>"
               data-for="<?php echo esc_attr( $name ); ?>"
               value="<?php echo esc_attr( $value ); ?>"
			<?php echo $required ? 'data-req="1"' : ''; ?>>
    </div>
</div>
