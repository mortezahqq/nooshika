<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * @var array $field
 */

$id          = $field['id'] ?? '';
$name        = $field['name'] ?? '';
$label       = $field['label'] ?? '';
$class       = $field['class'] ?? 'col-md-6';
$input_class = $field['input_class'] ?? '';
$options     = $field['options'] ?? [];
$value       = $field['value'] ?? '';
$required    = $field['required'] ?? FALSE;

$value = is_array( $value ) ? reset( $value ) : $value;
$value = (string) $value;
?>
<div class="<?php echo esc_attr( $class ); ?> meta-field-row"
     data-conditional="<?php echo ! empty( $field['conditional'] ) ? '1' : '0'; ?>"
     data-cond-meta="<?php echo esc_attr( $field['cond_meta'] ?? '' ); ?>"
     data-cond-operator="<?php echo esc_attr( $field['cond_operator'] ?? '==' ); ?>"
     data-cond-expected="<?php echo esc_attr( $field['cond_expected'] ?? '' ); ?>">
    <div class="form-group">
		<?php if ( $label ) { ?>
            <label class="form-label">
				<?php echo esc_html( $label ); ?>
            </label>
		<?php } ?>

        <div class="form-control-wrap">
            <div class="d-flex flex-wrap" style="gap: 12px 18px;">
				<?php
				$counter = 0;
				foreach ( $options as $key => $label_item ) {
					$choice_id = sanitize_key( (string) $key ) ?: $counter;
					$option_id = $id . '_' . $choice_id;
					?>
                    <div class="custom-control custom-radio">
                        <input type="radio"
                               class="custom-control-input <?php echo esc_attr( $input_class ); ?>"
                               id="<?php echo esc_attr( $option_id ); ?>"
                               name="<?php echo esc_attr( $name ); ?>"
                               value="<?php echo esc_attr( $key ); ?>"
                               data-for="<?php echo esc_attr( $name ); ?>"
							<?php checked( $value, (string) $key ); ?>
							<?php echo $required ? 'data-req="1"' : ''; ?>>

                        <label class="custom-control-label" for="<?php echo esc_attr( $option_id ); ?>">
							<?php echo esc_html( $label_item ); ?>
                        </label>
                    </div>
					<?php
					$counter ++;
				}
				?>
            </div>
        </div>
    </div>
</div>