<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * @var array $field
 */

$id          = $field['id'] ?? '';
$name        = $field['name'] ?? '';
$label       = $field['label'] ?? '';
$class       = $field['class'] ?? 'col-md-6';
$input_class = $field['input_class'] ?? '';
$options     = $field['options'] ?? [];
$value       = $field['value'] ?? [];
$required    = $field['required'] ?? FALSE;

if ( is_string( $value ) ) {
	$value = trim( $value );
	$value = $value !== '' ? array_map( 'trim', explode( ',', $value ) ) : [];
}

if ( ! is_array( $value ) ) {
	$value = [];
}

$value = array_map( 'strval', $value );
?>
<div class="<?php echo esc_attr( $class ); ?> meta-field-row"
     data-conditional="<?php echo ! empty( $field['conditional'] ) ? '1' : '0'; ?>"
     data-cond-meta="<?php echo esc_attr( $field['cond_meta'] ?? '' ); ?>"
     data-cond-operator="<?php echo esc_attr( $field['cond_operator'] ?? '==' ); ?>"
     data-cond-expected="<?php echo esc_attr( $field['cond_expected'] ?? '' ); ?>">
    <div class="form-group">
		<?php if ( $label ) { ?>
            <label class="form-label">
				<?php echo esc_html( $label ); ?>
            </label>
		<?php } ?>

        <div class="form-control-wrap">
            <div class="d-flex flex-wrap" style="gap: 12px 18px;">
				<?php
				foreach ( $options as $key => $label_item ) {
					$option_id = $id . '_' . sanitize_key( (string) $key );
					?>
                    <div class="custom-control custom-checkbox">
                        <input type="checkbox"
                               class="custom-control-input <?php echo esc_attr( $input_class ); ?>"
                               id="<?php echo esc_attr( $option_id ); ?>"
                               name="<?php echo esc_attr( $name ); ?>[]"
                               value="<?php echo esc_attr( $key ); ?>"
                               data-for="<?php echo esc_attr( $name ); ?>"
							<?php checked( in_array( (string) $key, $value, TRUE ) ); ?>
							<?php echo $required ? 'data-req="1"' : ''; ?>>

                        <label class="custom-control-label" for="<?php echo esc_attr( $option_id ); ?>">
							<?php echo esc_html( $label_item ); ?>
                        </label>
                    </div>
					<?php
				}
				?>
            </div>
        </div>
    </div>
</div>