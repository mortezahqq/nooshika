<?php

defined( 'ABSPATH' ) || exit;

/**
 * @var array $field
 */

$id             = sanitize_html_class( (string) ( $field['id'] ?? '' ) );
$name           = (string) ( $field['name'] ?? '' );
$label          = (string) ( $field['label'] ?? '' );
$value          = (string) ( $field['value'] ?? '' );
$placeholder    = (string) ( $field['placeholder'] ?? '' );
$description    = (string) ( $field['description'] ?? '' );
$column_class   = (string) ( $field['class'] ?? 'col-md-6' );
$input_class    = (string) ( $field['input_class'] ?? '' );
$rows           = max( 2, absint( $field['rows'] ?? 4 ) );
$required       = ! empty( $field['required'] );
$conditional    = ! empty( $field['conditional'] );

?>
<div
	class="<?php echo esc_attr( $column_class ); ?> meta-field-row"
	data-conditional="<?php echo $conditional ? '1' : '0'; ?>"
	data-cond-meta="<?php echo esc_attr( (string) ( $field['cond_meta'] ?? '' ) ); ?>"
	data-cond-operator="<?php echo esc_attr( (string) ( $field['cond_operator'] ?? '==' ) ); ?>"
	data-cond-expected="<?php echo esc_attr( (string) ( $field['cond_expected'] ?? '' ) ); ?>"
>
	<div class="form-group">
		<?php if ( $label !== '' ) : ?>
			<label class="form-label" for="<?php echo esc_attr( $id ); ?>">
				<?php echo esc_html( $label ); ?>
			</label>
		<?php endif; ?>

		<div class="form-control-wrap">
			<textarea
				id="<?php echo esc_attr( $id ); ?>"
				name="<?php echo esc_attr( $name ); ?>"
				data-for="<?php echo esc_attr( $name ); ?>"
				class="form-control <?php echo esc_attr( $input_class ); ?>"
				rows="<?php echo esc_attr( $rows ); ?>"
				placeholder="<?php echo esc_attr( $placeholder ); ?>"
				<?php echo $required ? 'data-req="1" required' : ''; ?>
			><?php echo esc_textarea( $value ); ?></textarea>
		</div>

		<?php if ( $description !== '' ) : ?>
			<div class="form-note">
				<?php echo esc_html( $description ); ?>
			</div>
		<?php endif; ?>
	</div>
</div>
