<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * @var array $field
 */

$id           = $field['id'] ?? '';
$name         = $field['name'] ?? '';
$label        = $field['label'] ?? '';
$column_class = $field['class'] ?? 'col-md-6';
$input_class  = $field['input_class'] ?? '';
$value        = $field['value'] ?? '';
$required     = $field['required'] ?? FALSE;
?>
<div class="<?php echo esc_attr( $column_class ); ?> meta-field-row"
     data-conditional="<?php echo ! empty( $field['conditional'] ) ? '1' : '0'; ?>"
     data-cond-meta="<?php echo esc_attr( $field['cond_meta'] ?? '' ); ?>"
     data-cond-operator="<?php echo esc_attr( $field['cond_operator'] ?? '==' ); ?>"
     data-cond-expected="<?php echo esc_attr( $field['cond_expected'] ?? '' ); ?>">
    <div class="form-group">
		<?php if ( $label ) { ?>
            <label class="form-label" for="<?php echo esc_attr( $id ); ?>">
				<?php echo esc_html( $label ); ?>
            </label>
		<?php } ?>
        <div class="form-control-wrap">
            <div class="input-group">
                <input type="text" class="form-control datepicker <?php echo esc_attr( $input_class ); ?>"
                       id="<?php echo esc_attr( $id ); ?>_from"
                       name="<?php echo esc_attr( $name ); ?>_from"
                       data-for="<?php echo esc_attr( $name ); ?>[from]"
                       value="<?php echo esc_attr( $value['from'] ); ?>"/>
                <div class="input-group-addon">تا</div>
                <input type="text" class="form-control datepicker <?php echo esc_attr( $input_class ); ?>"
                       id="<?php echo esc_attr( $id ); ?>_to"
                       name="<?php echo esc_attr( $name ); ?>_to"
                       data-for="<?php echo esc_attr( $name ); ?>[to]"
                       value="<?php echo esc_attr( $value['to'] ); ?>"/>
            </div>
        </div>
    </div>
</div>