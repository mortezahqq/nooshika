<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * @var array $field
 */

$id          = $field['id'] ?? '';
$name        = $field['name'] ?? '';
$label       = $field['label'] ?? '';
$class       = $field['class'] ?? 'col-12';
$row_class   = $field['row_class'] ?? 'col-12 col-md-6';
$value       = $field['value'] ?? [];
$fields      = $field['fields'] ?? [];
$button_text = $field['button_text'] ?? __( 'ردیف جدید', 'kasebi-erp' );
$row_card_class  = trim( (string) ( $field['card_class'] ?? '' ) );
$row_icon        = trim( (string) ( $field['row_icon'] ?? 'ni ni-list-check' ) );
$row_title       = trim( (string) ( $field['row_title'] ?? '' ) );
$row_description = trim( (string) ( $field['row_description'] ?? '' ) );
$row_badge       = trim( (string) ( $field['row_badge'] ?? '' ) );
$new_row_badge   = trim( (string) ( $field['new_row_badge'] ?? $row_badge ) );
$use_field_card  = $row_card_class !== '';
if ( is_string( $value ) ) {
	$value = maybe_unserialize( $value );
	
	if ( is_string( $value ) ) {
		$decoded = json_decode( $value, TRUE );
		
		if ( json_last_error() === JSON_ERROR_NONE ) {
			$value = $decoded;
		}
	}
}

if ( ! is_array( $value ) ) {
	$value = [];
}

$numeric_indexes = array_filter(
	array_map( 'absint', array_keys( $value ) )
);

$new_row_index = ! empty( $numeric_indexes )
	? max( $numeric_indexes ) + 1
	: 1;

$value[ $new_row_index ] = [];

$repeater_id = $id ?: 'repeater_' . sanitize_key( $name );

$prepare_child_field = static function( array $child_field, $row_index, string $repeater_id, string $name, array $row, bool $is_new_row ): array {
	$child_name  = sanitize_key( $child_field['name'] ?? '' );
	$child_value = $row[ $child_name ] ?? '';
	
	if ( $is_new_row ) {
		$child_value = '';
	}
	
	$child_field['id']          = $repeater_id . '_' . sanitize_key( (string) $row_index ) . '_' . $child_name;
	$child_field['name']        = $name . '[' . $row_index . '][' . $child_name . ']';
	$child_field['value']       = $child_value;
	$child_field['input_class'] = trim( (string) ( $child_field['input_class'] ?? '' ) . ' no_clear' );
	
	// در ریپیتر کارت، کلاس هر فیلد مستقیماً ستون Flex/Grid آن را مشخص می‌کند.
	$child_field['class'] = $child_field['repeater_class']
	                        ?? $child_field['class']
	                           ?? 'col-12 col-md-6 col-xl';
	if (
		! empty( $child_field['conditional'] )
		&& ! empty( $child_field['cond_meta'] )
	) {
		$child_field['cond_meta'] =
			$name
			. '[' . $row_index . ']'
			. '[' . sanitize_key( $child_field['cond_meta'] ) . ']';
	}
	
	return $child_field;
};
?>
<div class="<?php echo esc_attr( $class ); ?> meta-field-row"
     data-conditional="<?php echo ! empty( $field['conditional'] ) ? '1' : '0'; ?>"
     data-cond-meta="<?php echo esc_attr( $field['cond_meta'] ?? '' ); ?>"
     data-cond-operator="<?php echo esc_attr( $field['cond_operator'] ?? '==' ); ?>"
     data-cond-expected="<?php echo esc_attr( $field['cond_expected'] ?? '' ); ?>">

    <div class="form-group">
		<?php if ( $label ) : ?>
            <label class="form-label mb-2">
				<?php echo esc_html( $label ); ?>
            </label>
		<?php endif; ?>

        <div class="form-control-wrap">
            <div class="repeater_wrapper"
                 id="<?php echo esc_attr( $repeater_id ); ?>"
                 data-next-index="<?php echo esc_attr( $new_row_index + 1 ); ?>">

                <div class="repeater_rows row g-3">
					<?php foreach ( $value as $row_index => $row ) : ?>
						<?php
						if ( ! is_array( $row ) ) {
							$row = [];
						}
						
						$is_new_row = (int) $row_index === (int) $new_row_index;
						?>
                        <div
                            class="<?php echo esc_attr( $row_class ); ?> repeater_row <?php echo $is_new_row ? 'repeater_row--new' : ''; ?>">
                            <div class="card card-bordered <?php echo esc_attr( $row_card_class ); ?>">
                                <?php if ( $use_field_card ) : ?><div class="kerp-settings-field-card__accent"></div><?php endif; ?>
                                <div class="card-inner">
                                    <div class="<?php echo $use_field_card ? 'kerp-settings-field-card__head mb-3' : 'd-flex align-items-center justify-content-between mb-3'; ?>">
                                        <?php if ( $use_field_card ) : ?>
                                            <div class="kerp-settings-field-card__identity">
                                                <span class="kerp-settings-field-card__icon"><em class="icon <?php echo esc_attr( $is_new_row ? 'ni ni-plus' : $row_icon ); ?>"></em></span>
                                                <div class="kerp-settings-field-card__title">
                                                    <div class="kerp-settings-field-card__title-row"><h6 class="title mb-0"><?php echo esc_html( $row_title ); ?></h6><?php if ( ( $is_new_row ? $new_row_badge : $row_badge ) !== '' ) : ?><span class="badge badge-dim bg-outline-primary"><?php echo esc_html( $is_new_row ? $new_row_badge : $row_badge ); ?></span><?php endif; ?></div>
                                                </div>
                                            </div>
                                        <?php else : ?><div class="d-flex align-items-center g-2"><div class="user-avatar sq bg-light"><em class="icon ni <?php echo $is_new_row ? 'ni-plus' : 'ni-list-check'; ?>"></em></div></div><?php endif; ?>
                                        <div class="card-tools">
											<?php if ( $is_new_row ) : ?>
                                                <button type="button"
                                                        class="btn btn-sm btn-icon btn-primary add_repeater_row"
                                                        data-bs-toggle="tooltip"
                                                        data-bs-placement="top"
                                                        title="<?php echo esc_attr( $button_text ); ?>">
                                                    <em class="icon ni ni-plus-round"></em>
                                                </button>
											<?php else : ?>
                                                <button type="button"
                                                        class="btn btn-sm btn-icon btn-trigger text-danger remove_repeater_row"
                                                        data-bs-toggle="tooltip"
                                                        data-bs-placement="top"
                                                        title="<?php esc_attr_e( 'حذف ردیف', 'kasebi-erp' ); ?>">
                                                    <em class="icon ni ni-trash"></em>
                                                </button>
											<?php endif; ?>
                                        </div>
                                    </div>
                                    <?php if ( $use_field_card && $row_description !== '' ) : ?><div class="kerp-settings-field-card__description mt-0"><p><?php echo esc_html( $row_description ); ?></p></div><?php endif; ?>
                                    <div class="<?php echo $use_field_card ? 'kerp-settings-field-card__section' : ''; ?>">
                                    <div class="row g-3 align-items-start repeater_row_fields">
										<?php foreach ( $fields as $child_field ) : ?>
											<?php
											$child_type = sanitize_key( $child_field['type'] ?? 'text' );
											$child_name = sanitize_key( $child_field['name'] ?? '' );
											
											if ( ! $child_name ) {
												continue;
											}
											
											$child_field_for_row = $prepare_child_field(
												$child_field,
												$row_index,
												$repeater_id,
												$name,
												$row,
												$is_new_row
											);
											
											KERP_Helpers_Template::render_template(
												'app/components/fields/' . $child_type . '.php',
												[
													'field' => $child_field_for_row,
												]
											);
											?>
                                        <?php endforeach; ?>
                                    </div>
                                    </div>
                                </div>
                            </div>
                        </div>
					<?php endforeach; ?>
                </div>
                <script type="text/template" class="repeater_row_template">
                    <div class="<?php echo esc_attr( $row_class ); ?> repeater_row repeater_row--new">
                        <div class="card card-bordered <?php echo esc_attr( $row_card_class ); ?>">
                            <?php if ( $use_field_card ) : ?><div class="kerp-settings-field-card__accent"></div><?php endif; ?>
                            <div class="card-inner">
                                <div class="<?php echo $use_field_card ? 'kerp-settings-field-card__head mb-3' : 'd-flex align-items-center justify-content-between mb-3'; ?>">
                                    <?php if ( $use_field_card ) : ?>
                                        <div class="kerp-settings-field-card__identity">
                                            <span class="kerp-settings-field-card__icon"><em class="icon ni ni-plus"></em></span>
                                            <div class="kerp-settings-field-card__title"><div class="kerp-settings-field-card__title-row"><h6 class="title mb-0"><?php echo esc_html( $row_title ); ?></h6><?php if ( $new_row_badge !== '' ) : ?><span class="badge badge-dim bg-outline-primary"><?php echo esc_html( $new_row_badge ); ?></span><?php endif; ?></div></div>
                                        </div>
                                    <?php else : ?><div class="d-flex align-items-center g-2"><div class="user-avatar sq bg-light"><em class="icon ni ni-plus"></em></div></div><?php endif; ?>

                                    <div class="card-tools">
                                        <button type="button"
                                                class="btn btn-sm btn-icon btn-primary add_repeater_row"
                                                data-bs-toggle="tooltip"
                                                data-bs-placement="top"
                                                title="<?php echo esc_attr( $button_text ); ?>">
                                            <em class="icon ni ni-plus-round"></em>
                                        </button>
                                    </div>
                                    </div>
                                <?php if ( $use_field_card && $row_description !== '' ) : ?><div class="kerp-settings-field-card__description mt-0"><p><?php echo esc_html( $row_description ); ?></p></div><?php endif; ?>
                                <div class="<?php echo $use_field_card ? 'kerp-settings-field-card__section' : ''; ?>">
                                <div class="row g-3 align-items-start repeater_row_fields">
									<?php foreach ( $fields as $child_field ) : ?>
										<?php
										$child_type = sanitize_key( $child_field['type'] ?? 'text' );
										$child_name = sanitize_key( $child_field['name'] ?? '' );
										
										if ( ! $child_name ) {
											continue;
										}
										
										$child_field_for_row                = $child_field;
										$child_field_for_row['id']          = $repeater_id . '___INDEX___' . $child_name;
										$child_field_for_row['name']        = $name . '[__INDEX__][' . $child_name . ']';
										$child_field_for_row['value']       = '';
										$child_field_for_row['input_class'] = trim( (string) ( $child_field['input_class'] ?? '' ) . ' no_clear' );
										$child_field_for_row['class']       = $child_field['repeater_class']
										                                      ?? $child_field['class']
										                                         ?? 'col-12 col-md-6 col-xl';
										if (
											! empty( $child_field_for_row['conditional'] )
											&& ! empty( $child_field_for_row['cond_meta'] )
										) {
											$child_field_for_row['cond_meta'] =
												$name
												. '[__INDEX__]'
												. '[' . sanitize_key( $child_field_for_row['cond_meta'] ) . ']';
										}
										KERP_Helpers_Template::render_template(
											'app/components/fields/' . $child_type . '.php',
											[
												'field' => $child_field_for_row,
											]
										);
										?>
									<?php endforeach; ?>
                                </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </script>
            </div>
        </div>
    </div>
</div>
