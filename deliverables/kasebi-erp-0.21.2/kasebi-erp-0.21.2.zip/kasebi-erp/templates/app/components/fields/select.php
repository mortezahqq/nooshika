<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * @var array $field
 */

$id           = $field['id'] ?? '';
$name         = $field['name'] ?? '';
$label        = $field['label'] ?? '';
$column_class = $field['class'] ?? 'col-md-6';
$input_class  = $field['input_class'] ?? '';
$options      = $field['options'] ?? [];
$value        = $field['value'] ?? '';
$placeholder  = $field['placeholder'] ?? __( 'انتخاب کنید', 'kasebi-erp' );
$data         = isset( $field['data'] ) && is_array( $field['data'] )
	? $field['data']
	: [];
$multiple     = ! empty( $field['multiple'] );

if ( $multiple ) {
	$value = is_array( $value ) ? array_map( 'strval', $value ) : [];
}
?>
<div class="<?php echo esc_attr( $column_class ); ?> meta-field-row"
     data-conditional="<?php echo ! empty( $field['conditional'] ) ? '1' : '0'; ?>"
     data-cond-meta="<?php echo esc_attr( $field['cond_meta'] ?? '' ); ?>"
     data-cond-operator="<?php echo esc_attr( $field['cond_operator'] ?? '==' ); ?>"
     data-cond-expected="<?php echo esc_attr( $field['cond_expected'] ?? '' ); ?>">
    <div class="form-group">
		<?php if ( $label ) : ?>
            <label class="form-label" for="<?php echo esc_attr( $id ); ?>">
				<?php echo esc_html( $label ); ?>
            </label>
		<?php endif; ?>

        <div class="form-control-wrap">
            <select class="form-control js-select2 <?php echo esc_attr( $input_class ); ?>"
                    id="<?php echo esc_attr( $id ); ?>"
                    name="<?php echo esc_attr( $name ); ?>"
                    data-for="<?php echo esc_attr( $name ); ?>"
				<?php echo ! empty( $field['disabled'] ) ? 'disabled' : ''; ?>
                    data-req="<?php echo ! empty( $field['required'] ) ? '1' : '0'; ?>"
				<?php echo $multiple ? ' multiple' : ''; ?>
				<?php foreach ( $data as $data_key => $data_value ) : ?>
					<?php
					if ( is_array( $data_value ) || is_object( $data_value ) ) {
						continue;
					}
					
					$data_key = sanitize_key(
						str_replace(
							'_',
							'-',
							(string) $data_key
						)
					);
					
					if ( $data_key === '' ) {
						continue;
					}
					?>
                    data-<?php echo esc_attr( $data_key ); ?>="<?php echo esc_attr( (string) $data_value ); ?>"
				<?php endforeach; ?>>
                <option value=""<?php echo ! $multiple ? selected( $value, '', FALSE ) : ''; ?>>
					<?php echo esc_html( $placeholder ); ?>
                </option>
				
				<?php foreach ( $options as $key => $label_item ) : ?>
					<?php $is_selected = $multiple ? in_array( (string) $key, $value, TRUE ) : (string) $value === (string) $key; ?>
                    <option value="<?php echo esc_attr( $key ); ?>"<?php echo $is_selected ? ' selected' : ''; ?>>
						<?php echo esc_html( $label_item ); ?>
                    </option>
				<?php endforeach; ?>
            </select>
        </div>
    </div>
</div>
