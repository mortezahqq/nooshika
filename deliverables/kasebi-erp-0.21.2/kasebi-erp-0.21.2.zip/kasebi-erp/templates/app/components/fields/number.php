<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * @var array $field
 */

$id           = $field['id'] ?? '';
$name         = $field['name'] ?? '';
$label        = $field['label'] ?? '';
$column_class = $field['class'] ?? 'col-md-6';
$input_class  = $field['input_class'] ?? '';
$value        = $field['value'] ?? '';
$required     = $field['required'] ?? FALSE;
$description  = (string) ( $field['description'] ?? '' );
?>
<div class="<?php echo esc_attr( $column_class ); ?> meta-field-row"
     data-conditional="<?php echo ! empty( $field['conditional'] ) ? '1' : '0'; ?>"
     data-cond-meta="<?php echo esc_attr( $field['cond_meta'] ?? '' ); ?>"
     data-cond-operator="<?php echo esc_attr( $field['cond_operator'] ?? '==' ); ?>"
     data-cond-expected="<?php echo esc_attr( $field['cond_expected'] ?? '' ); ?>">
    <div class="form-group">
		<?php if ( $label ) { ?>
            <label class="form-label" for="<?php echo esc_attr( $id ); ?>">
				<?php echo esc_html( $label ); ?>
            </label>
		<?php } ?>
        <div class="form-control-wrap">
            <input type="text"
                   id="<?php echo esc_attr( $id ); ?>"
                   name="<?php echo esc_attr( $name ); ?>"
                   data-for="<?php echo esc_attr( $name ); ?>"
                   class="form-control number_type <?php echo esc_attr( $input_class ); ?>"
                   value="<?php echo esc_attr( $value ); ?>"
                   <?php if ( $description !== '' && $id !== '' ) : ?>aria-describedby="<?php echo esc_attr( $id . '-note' ); ?>"<?php endif; ?>
				<?php echo $required ? 'data-req="1"' : ''; ?>>
        </div>
        <?php if ( $description !== '' ) : ?><div class="form-note"<?php if ( $id !== '' ) : ?> id="<?php echo esc_attr( $id . '-note' ); ?>"<?php endif; ?>><?php echo esc_html( $description ); ?></div><?php endif; ?>
    </div>
</div>
