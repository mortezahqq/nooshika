<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * @var array $field
 */

$id           = $field['id'] ?? '';
$name         = $field['name'] ?? '';
$label        = $field['label'] ?? '';
$column_class = $field['class'] ?? 'col-md-6';
$input_class  = $field['input_class'] ?? '';
$value        = $field['value'] ?? '';
$required     = $field['required'] ?? FALSE;
$checked      = ! empty( $value );
?>
<div class="<?php echo esc_attr( $column_class ); ?> meta-field-row"
     data-conditional="<?php echo ! empty( $field['conditional'] ) ? '1' : '0'; ?>"
     data-cond-meta="<?php echo esc_attr( $field['cond_meta'] ?? '' ); ?>"
     data-cond-operator="<?php echo esc_attr( $field['cond_operator'] ?? '==' ); ?>"
     data-cond-expected="<?php echo esc_attr( $field['cond_expected'] ?? '' ); ?>">
    <div class="form-group">
        <div class="custom-control custom-control-sm custom-switch <?php echo $checked ? 'checked' : ''; ?>">
            <input type="checkbox"
                   id="<?php echo esc_attr( $id ); ?>"
                   name="<?php echo esc_attr( $name ); ?>"
                   data-for="<?php echo esc_attr( $name ); ?>"
                   class="custom-control-input <?php echo esc_attr( $input_class ); ?>"
                   value="1"
				<?php checked( $checked ); ?>
				<?php echo $required ? 'data-req="1"' : ''; ?>>
			<?php if ( $label ) { ?>
                <label class="custom-control-label" for="<?php echo esc_attr( $id ); ?>">
					<?php echo esc_html( $label ); ?>
                </label>
			<?php } ?>
        </div>
    </div>
</div>