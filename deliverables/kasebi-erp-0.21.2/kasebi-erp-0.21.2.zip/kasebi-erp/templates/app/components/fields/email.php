<?php

defined( 'ABSPATH' ) || exit;

/** @var array $field */
$field = isset( $field ) && is_array( $field ) ? $field : [];

$id            = sanitize_html_class( (string) ( $field['id'] ?? '' ) );
$name          = (string) ( $field['name'] ?? '' );
$label         = (string) ( $field['label'] ?? '' );
$description   = (string) ( $field['description'] ?? '' );
$value         = (string) ( $field['value'] ?? '' );
$column_class  = trim( (string) ( $field['class'] ?? 'col-md-6' ) );
$input_class   = trim( (string) ( $field['input_class'] ?? '' ) );
$placeholder   = (string) ( $field['placeholder'] ?? '' );
$required      = ! empty( $field['required'] );
$autocomplete  = (string) ( $field['autocomplete'] ?? 'email' );
$conditional   = ! empty( $field['conditional'] );
$cond_meta     = (string) ( $field['cond_meta'] ?? '' );
$cond_operator = (string) ( $field['cond_operator'] ?? '==' );
$cond_expected = (string) ( $field['cond_expected'] ?? '' );
?>
<div class="<?php echo esc_attr( $column_class ); ?> meta-field-row"
     data-conditional="<?php echo $conditional ? '1' : '0'; ?>"
     data-cond-meta="<?php echo esc_attr( $cond_meta ); ?>"
     data-cond-operator="<?php echo esc_attr( $cond_operator ); ?>"
     data-cond-expected="<?php echo esc_attr( $cond_expected ); ?>">
	<div class="form-group">
		<?php if ( $label !== '' ) : ?><label class="form-label" for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $label ); ?></label><?php endif; ?>
		<div class="form-control-wrap">
			<input type="email"
			       id="<?php echo esc_attr( $id ); ?>"
			       name="<?php echo esc_attr( $name ); ?>"
			       data-for="<?php echo esc_attr( $name ); ?>"
			       class="form-control <?php echo esc_attr( $input_class ); ?>"
			       value="<?php echo esc_attr( $value ); ?>"
			       placeholder="<?php echo esc_attr( $placeholder ); ?>"
			       autocomplete="<?php echo esc_attr( $autocomplete ); ?>"
				<?php echo $required ? ' data-req="1"' : ''; ?>>
		</div>
		<?php if ( $description !== '' ) : ?><div class="form-note"><?php echo esc_html( $description ); ?></div><?php endif; ?>
	</div>
</div>
