<?php
defined( 'ABSPATH' ) || exit;
$sms_name = (string) $field['name'];
$sms_id = str_replace( '__index__', '__INDEX__', (string) $field['id'] );
$sms_rows = is_array( $field['value'] ?? NULL ) ? array_values( $field['value'] ) : [];
$sms_fields = $field['condition_fields'] ?? [];
$sms_options = $field['condition_options'] ?? [];
$render_sms_row = static function( $index, array $values ) use ( $sms_name, $sms_id, $sms_fields, $sms_options ): void {
    $selected_field = (string) ( $values['condition_field'] ?? '' );
    $has_condition = isset( $sms_fields[$selected_field] );
    $choices = [];
    foreach ( $sms_options[$selected_field] ?? [] as $value ) $choices[(string) $value] = (string) $value;
    $previous = (string) ( $values['condition_value'] ?? '' );
    if ( $has_condition && $previous !== '' && ! isset( $choices[$previous] ) ) $choices[$previous] = $previous . ' (مقدار ذخیره‌شده قبلی)';
    ?>
    <div class="kerp-button-sms-row border rounded p-3 mb-3">
        <div class="d-flex justify-content-between align-items-center mb-3"><strong>پیامک</strong><button type="button" class="btn btn-sm btn-icon btn-outline-danger kerp-button-sms-remove" title="حذف این پیامک" aria-label="حذف این پیامک" data-bs-toggle="tooltip"><em class="icon ni ni-trash"></em></button></div>
        <div class="row g-3">
        <?php
        $definitions = [
            [ 'name'=>'pattern','type'=>'text','label'=>'کد پترن','class'=>'col-12' ],
            [ 'name'=>'variables','type'=>'textarea','label'=>'مقادیر پترن؛ ثابت یا متغیر','placeholder'=>'token:تهران;token2:{customer_name}','class'=>'col-12' ],
            [ 'name'=>'delay','type'=>'text','label'=>'زمان انتظار (صفر = بدون انتظار)','class'=>'col-sm-6' ],
            [ 'name'=>'unit','type'=>'select','label'=>'واحد زمان','options'=>[ 'minute'=>'دقیقه','hour'=>'ساعت','day'=>'روز' ],'class'=>'col-sm-6' ],
            [ 'name'=>'condition_field','type'=>'select','label'=>'شرط پاسخ فرم','options'=>[ '0'=>'بدون شرط' ] + $sms_fields,'class'=>'col-sm-6' ],
            [ 'name'=>'condition_value','type'=>'select','label'=>'پاسخ برابر با','options'=>$choices,'placeholder'=>$choices ? 'انتخاب مقدار شرط' : 'مقداری برای این فیلد ثبت نشده است','disabled'=>! $has_condition,'class'=>'col-sm-6 kerp-button-sms-condition-value' . ( $has_condition ? '' : ' d-none' ),'data'=>[ 'search'=>'on','minimum-results-for-search'=>0 ] ],
        ];
        foreach ( $definitions as $definition ) {
            $key = $definition['name'];
            $definition['name'] = $sms_name . '[' . $index . '][' . $key . ']';
            $definition['id'] = $sms_id . '-' . $index . '-' . $key;
            $definition['value'] = $values[$key] ?? '';
            $definition['input_class'] = 'no_clear';
            KERP_Helpers_Template::render_template( 'app/components/fields/' . $definition['type'] . '.php', [ 'field'=>$definition ] );
        }
        ?>
        </div>
    </div>
    <?php
};
?>
<div class="col-12 meta-field-row kerp-button-sms" data-condition-options="<?php echo esc_attr( wp_json_encode( $sms_options ) ); ?>" data-conditional="1" data-cond-meta="<?php echo esc_attr( $field['cond_meta'] ); ?>" data-cond-operator="==" data-cond-expected="1" data-next-index="<?php echo count( $sms_rows ) + 1; ?>">
    <label class="form-label">پیامک‌های این دکمه</label>
    <div class="kerp-button-sms-rows">
        <?php foreach ( $sms_rows as $index=>$values ) $render_sms_row( $index, $values ); ?>
        <?php $render_sms_row( count( $sms_rows ), [] ); ?>
    </div>
    <button type="button" class="btn btn-sm btn-outline-primary kerp-button-sms-add" title="افزودن پیامک با شرط و زمان‌بندی مستقل" aria-label="افزودن پیامک با شرط و زمان‌بندی مستقل" data-bs-toggle="tooltip"><em class="icon ni ni-plus"></em><span>افزودن پیامک</span></button>
    <template class="kerp-button-sms-template"><?php $render_sms_row( '__SMS_INDEX__', [] ); ?></template>
</div>
