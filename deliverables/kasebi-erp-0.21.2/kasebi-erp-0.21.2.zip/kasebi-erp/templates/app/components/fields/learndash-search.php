<?php

defined( 'ABSPATH' ) || exit;

$id          = sanitize_html_class( (string) ( $field['id'] ?? '' ) );
$name        = sanitize_key( (string) ( $field['name'] ?? 'learndash_id' ) );
$label       = (string) ( $field['label'] ?? __( 'درس یا سرفصل LearnDash', 'kasebi-erp' ) );
$placeholder = (string) ( $field['placeholder'] ?? __( 'عنوان درس یا سرفصل را وارد کنید', 'kasebi-erp' ) );
$value       = absint( $field['value'] ?? 0 );
$value_label = $value ? get_the_title( $value ) : '';
?>
<div class="<?php echo esc_attr( $field['class'] ?? 'col-12' ); ?> meta-field-row kerp-learndash-picker"
     data-for="<?php echo esc_attr( $name ); ?>"
     data-search-action="<?php echo esc_attr( sanitize_key( (string) ( $field['search_action'] ?? 'programs_search_learndash_content' ) ) ); ?>"
     data-conditional="<?php echo ! empty( $field['conditional'] ) ? '1' : '0'; ?>"
     data-cond-meta="<?php echo esc_attr( $field['cond_meta'] ?? '' ); ?>"
     data-cond-operator="<?php echo esc_attr( $field['cond_operator'] ?? '==' ); ?>"
     data-cond-expected="<?php echo esc_attr( $field['cond_expected'] ?? '' ); ?>">
    <input type="hidden" id="<?php echo esc_attr( $id ); ?>" data-for="<?php echo esc_attr( $name ); ?>"
           value="<?php echo esc_attr( $value ); ?>"<?php echo ! empty( $field['required'] ) ? ' data-req="1"' : ''; ?>>
    <div class="row g-2">
        <div class="col-md-6">
            <div class="form-group card-title">
                <label class="form-label"><?php echo esc_html( $label ); ?></label>
                <div class="kerp-learndash-picker-preview nk-tb-list">
                    <?php if ( $value ) : ?>
                        <div class="d-flex align-center justify-between"><span class="tb-lead"><?php echo esc_html( $value_label ); ?></span><button type="button" class="btn btn-sm btn-icon btn-trigger kerp-learndash-picker-clear" data-for="<?php echo esc_attr( $name ); ?>"><em class="icon ni ni-cross"></em></button></div>
                    <?php else : ?>
                        <span class="sub-text"><?php esc_html_e( 'برای انتخاب، عنوان را در فیلد روبه‌رو جستجو کنید.', 'kasebi-erp' ); ?></span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="form-group card-title search_wrapper">
                <label class="form-label" for="<?php echo esc_attr( $id ); ?>_search"><?php esc_html_e( 'جستجوی محتوای LearnDash', 'kasebi-erp' ); ?></label>
                <div class="form-control-wrap">
                    <div class="form-icon form-icon-left"><em class="icon ni ni-search"></em></div>
                    <input type="text" class="form-control kerp-learndash-picker-search" id="<?php echo esc_attr( $id ); ?>_search" placeholder="<?php echo esc_attr( $placeholder ); ?>" autocomplete="off">
                </div>
                <div class="kerp-learndash-picker-results"></div>
            </div>
        </div>
    </div>
</div>
