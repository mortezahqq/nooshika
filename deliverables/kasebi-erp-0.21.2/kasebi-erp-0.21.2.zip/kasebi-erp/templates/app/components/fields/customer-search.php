<?php

defined( 'ABSPATH' ) || exit;

/**
 * @var array $field
 */

$id              = sanitize_html_class( (string) ( $field['id'] ?? '' ) );
$name            = sanitize_key( (string) ( $field['name'] ?? 'customer_id' ) );
$customer_id     = absint( $field['value'] ?? 0 );
$required        = ! empty( $field['required'] );
$hide_on_profile = ! empty( $field['hide_on_profile'] );
$input_class     = trim( (string) ( $field['input_class'] ?? '' ) );
$singular_label  = KERP_Modules_Customers_Settings::instance()->get_singular_label();
$preview_label   = (string) ( $field['preview_label'] ?? sprintf(
		__( 'ثبت برای %s:', 'kasebi-erp' ),
		$singular_label
	) );
$search_label    = (string) ( $field['search_label'] ?? sprintf(
		__( 'جستجوی %s', 'kasebi-erp' ),
		$singular_label
	) );
$placeholder     = (string) ( $field['placeholder'] ?? sprintf(
		__( 'نام یا شماره موبایل %s را وارد کنید', 'kasebi-erp' ),
		$singular_label
	) );
$columns         = absint( $field['columns'] ?? 2 );
$columns         = in_array( $columns, [ 1, 2 ], TRUE ) ? $columns : 2;

$column_class = $columns === 1
	? 'col-12'
	: 'col-md-6';
if ( $hide_on_profile ) {
	?>
    <input type="hidden"
           id="<?php echo esc_attr( $id ); ?>"
           class="<?php echo esc_attr( $input_class ); ?>"
           data-for="<?php echo esc_attr( $name ); ?>"
           value="<?php echo esc_attr( $customer_id ); ?>"
		<?php echo $required ? 'data-req="1"' : ''; ?>>
	<?php
} else {
	?>
    <div class="col-12 kerp-customer-picker" data-search-action="<?php echo esc_attr( $field['search_action'] ?? 'customers_search' ); ?>">
        <input type="hidden"
               id="<?php echo esc_attr( $id ); ?>"
               class="<?php echo esc_attr( $input_class ); ?>"
               data-for="<?php echo esc_attr( $name ); ?>"
               value="<?php echo esc_attr( $customer_id ); ?>"
			<?php echo $required ? 'data-req="1"' : ''; ?>>
        <div class="row g-2">
            <div class="<?php echo esc_attr( $column_class ); ?>">
                <div class="form-group card-title">
                    <label class="form-label"><?php echo esc_html( $preview_label ); ?></label>
                    <div class="kerp-customer-picker-preview nk-tb-list">
						<?php if ( $customer_id ) : ?>
                            <div class="d-flex align-center justify-between">
								<?php
								KERP_Helpers_Template::render_template(
									'app/components/user-card.php',
									[
										'user_id'    => $customer_id,
										'show_phone' => TRUE,
									]
								);
								?>
                                <button type="button"
                                        class="btn btn-sm btn-icon btn-trigger kerp-customer-picker-clear">
                                    <em class="icon ni ni-cross"></em>
                                </button>
                            </div>
						<?php else : ?>
                            <span class="sub-text">
							<?php
							printf(
								esc_html__( 'برای انتخاب %s، در فیلد روبه‌رو جستجو کنید.', 'kasebi-erp' ),
								esc_html( $singular_label )
							);
							?>
						</span>
						<?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="<?php echo esc_attr( $column_class ); ?>">
                <div class="form-group card-title search_wrapper">
                    <label class="form-label" for="<?php echo esc_attr( $id ); ?>_search">
						<?php echo esc_html( $search_label ); ?>
                    </label>
                    <div class="form-control-wrap">
                        <div class="form-icon form-icon-left">
                            <em class="icon ni ni-user"></em>
                        </div>
                        <input type="text"
                               class="form-control kerp-customer-picker-search"
                               id="<?php echo esc_attr( $id ); ?>_search"
                               placeholder="<?php echo esc_attr( $placeholder ); ?>"
                               autocomplete="off">
                    </div>
                    <p class="mt-1 mb-0">
						<?php
						printf(
							esc_html__( 'شماره موبایل یا نام %s را جستجو کنید.', 'kasebi-erp' ),
							esc_html( $singular_label )
						);
						?>
                    </p>
                    <div class="kerp-customer-picker-results"></div>
                </div>
            </div>
        </div>
    </div>
	<?php
}
