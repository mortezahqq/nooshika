<?php

defined( 'ABSPATH' ) || exit;

/**
 * @var bool   $has_filter
 * @var array  $filter_fields
 * @var string $page
 * @var string $action
 * @var string $apply_class
 * @var string $reset_class
 * @var string $title
 */

$has_filter    = ! empty( $has_filter );
$filter_fields = isset( $filter_fields ) && is_array( $filter_fields )
	? $filter_fields
	: [];
$page          = sanitize_text_field( (string) ( $page ?? '' ) );
$action        = sanitize_key( (string) ( $action ?? 'erp_request_page_content' ) );
$apply_class   = sanitize_html_class( (string) ( $apply_class ?? 'filter_erp_list' ) );
$reset_class   = sanitize_html_class( (string) ( $reset_class ?? 'reset_page_filter' ) );
$title         = sanitize_text_field( (string) ( $title ?? __( 'فیلتر', 'kasebi-erp' ) ) );

if ( empty( $filter_fields ) ) {
	return;
}

?>
<div class="dropdown">
    <button
        type="button"
        class="btn btn-trigger btn-icon dropdown-toggle"
        data-bs-toggle="dropdown"
        data-kerp-no-tooltip
        data-bs-auto-close="outside"
        aria-expanded="false"
        aria-label="<?php echo esc_attr( $title ); ?>"
    >
        <em class="icon ni ni-filter-alt"></em>
		<?php if ( $has_filter ) : ?>
            <span class="dot dot-primary"></span>
		<?php endif; ?>
    </button>

    <div class="filter-wg dropdown-menu dropdown-menu-xl dropdown-menu-end filter_form_wrapper "
         style="width:min(620px, 92vw);">
        <div class="dropdown-head">
			<span class="sub-title dropdown-title">
				<?php echo esc_html( $title ); ?>
			</span>
        </div>

        <div class="dropdown-body dropdown-body-rg overflow-auto" style="max-height:480px;">
            <div class="row g-2">
				<?php foreach ( $filter_fields as $filter_key => $field ) : ?>
					<?php
					if ( ! is_array( $field ) ) {
						continue;
					}
					
					$name = sanitize_key(
						(string) ( $field['name'] ?? $field['key'] ?? $filter_key )
					);
					
					if ( $name === '' ) {
						continue;
					}
					
					$type = sanitize_key( (string) ( $field['type'] ?? 'text' ) );
					
					if ( in_array( $type, [ 'checkbox', 'multi-select' ], TRUE ) ) {
						$type = 'select';
					}
					
					if ( ! in_array( $type, [
						'hidden',
						'search',
						'text',
						'date',
						'date-range',
						'number',
						'price',
						'select',
						'radio',
						'switch',
					], TRUE ) ) {
						$type = 'text';
					}
					
					$id = sanitize_html_class(
						(string) ( $field['id'] ?? 'kerp-filter-' . $name )
					);
					
					$label       = sanitize_text_field( (string) ( $field['label'] ?? '' ) );
					$placeholder = sanitize_text_field( (string) ( $field['placeholder'] ?? '' ) );
					$options     = isset( $field['options'] ) && is_array( $field['options'] )
						? $field['options']
						: [];
					$value       = $field['value'] ?? '';
					$col         = max( 1, min( 12, absint( $field['col'] ?? 6 ) ) );
					$input_class = sanitize_text_field( (string) ( $field['input_class'] ?? '' ) );
					$search      = ! empty( $field['search'] );
					$data        = isset( $field['data'] ) && is_array( $field['data'] )
						? $field['data']
						: [];
					
					$data_attributes = [];
					
					foreach ( $data as $data_key => $data_value ) {
						if ( ! is_scalar( $data_value ) ) {
							continue;
						}
						
						$data_key = sanitize_key(
							str_replace( '_', '-', (string) $data_key )
						);
						
						if ( $data_key === '' ) {
							continue;
						}
						
						$data_attributes[ 'data-' . $data_key ] = (string) $data_value;
					}
					if ( $type === 'hidden' ) :
						?>
                        <input
                            type="hidden"
                            id="<?php echo esc_attr( $id ); ?>"
                            class="kerp-filter-input <?php echo esc_attr( $input_class ); ?>"
                            data-for="<?php echo esc_attr( $name ); ?>"
                            value="<?php echo esc_attr( is_scalar( $value ) ? (string) $value : '' ); ?>"
                        >
						<?php
						continue;
					endif;
					$depends_on = sanitize_key( (string) ( $field['depends_on'] ?? '' ) );
					$depends_value = (string) ( $field['depends_value'] ?? '' );
					$depends_operator = in_array( $field['depends_operator'] ?? '', [ 'selected', 'in' ], TRUE ) ? $field['depends_operator'] : 'equals';
					$parent_value = (string) ( $filter_fields[ $depends_on ]['value'] ?? '' );
					$dependent_hidden = $depends_on !== '' && ( $depends_operator === 'selected' ? in_array( $parent_value, [ '', '0' ], TRUE ) : ( $depends_operator === 'in' ? ! in_array( $parent_value, explode( '|', $depends_value ), TRUE ) : $parent_value !== $depends_value ) );
					?>

                    <div class="col-md-<?php echo esc_attr( $col ); ?><?php echo $dependent_hidden ? ' d-none' : ''; ?>"
                         <?php if ( $depends_on !== '' ) : ?>data-filter-parent="<?php echo esc_attr( $depends_on ); ?>" data-filter-parent-value="<?php echo esc_attr( $depends_value ); ?>" data-filter-parent-operator="<?php echo esc_attr( $depends_operator ); ?>"<?php endif; ?>>
                        <div class="form-group">
							<?php if ( $label !== '' ) : ?>
                                <label class="overline-title overline-title-alt" for="<?php echo esc_attr( $id ); ?>">
									<?php echo esc_html( $label ); ?>
                                </label>
							<?php endif; ?>

                            <div class="form-control-wrap">
								<?php if ( in_array( $type, [
									'search',
									'text',
									'number',
									'price',
									'date',
								], TRUE ) ) : ?>
									<?php
									$type_class = match ( $type ) {
										'date' => 'datepicker',
										'number' => 'number_type',
										'price' => 'price_input',
										default => '',
									};
									?>
                                    <input
                                        type="text"
                                        id="<?php echo esc_attr( $id ); ?>"
                                        class="form-control kerp-filter-input <?php echo esc_attr( trim( $type_class . ' ' . $input_class ) ); ?>"
                                        data-for="<?php echo esc_attr( $name ); ?>"
                                        value="<?php echo esc_attr( is_scalar( $value ) ? (string) $value : '' ); ?>"
                                        placeholder="<?php echo esc_attr( $placeholder ); ?>"
                                    >
								<?php elseif ( $type === 'date-range' ) : ?>
                                    <div class="input-group">
                                        <input type="text"
                                               class="form-control datepicker kerp-filter-input <?php echo esc_attr( $input_class ); ?>"
                                               id="<?php echo esc_attr( $id ); ?>_from"
                                               name="<?php echo esc_attr( $name ); ?>_from"
                                               data-for="<?php echo esc_attr( $name ); ?>[from]"
                                               value="<?php echo esc_attr( $value['from'] ); ?>"/>
                                        <div class="input-group-addon">تا</div>
                                        <input type="text"
                                               class="form-control datepicker kerp-filter-input <?php echo esc_attr( $input_class ); ?>"
                                               id="<?php echo esc_attr( $id ); ?>_to"
                                               name="<?php echo esc_attr( $name ); ?>_to"
                                               data-for="<?php echo esc_attr( $name ); ?>[to]"
                                               value="<?php echo esc_attr( $value['to'] ); ?>"/>
                                    </div>
								<?php elseif ( $type === 'select' ) : ?>
									<?php
									$select_classes = [
										'form-select',
										'kerp-filter-input',
									];
									
									if ( $search ) {
										$select_classes[] = 'js-select2';
									}
									
									if ( $input_class !== '' ) {
										$select_classes[] = $input_class;
									}
									?>
                                    <select
                                        <?php disabled( $dependent_hidden ); ?>
                                        id="<?php echo esc_attr( $id ); ?>"
                                        class="<?php echo esc_attr( implode( ' ', array_unique( $select_classes ) ) ); ?>"
                                        data-for="<?php echo esc_attr( $name ); ?>"
										<?php if ( $search ) : ?>
                                            data-search="on"
										<?php endif; ?>
										<?php
										foreach ( $data_attributes as $attribute_key => $attribute_value ) {
											printf(
												' %s="%s"',
												esc_attr( $attribute_key ),
												esc_attr( $attribute_value )
											);
										}
										?>
                                    >
                                        <option value="0">
											<?php
											echo esc_html(
												$placeholder !== ''
													? $placeholder
													: __( 'همه موارد', 'kasebi-erp' )
											);
											?>
                                        </option>
										
										<?php foreach ( $options as $option_key => $option_label ) : ?>
                                            <option
                                                value="<?php echo esc_attr( (string) $option_key ); ?>"
												<?php selected( (string) $value, (string) $option_key ); ?>
                                            >
												<?php echo esc_html( (string) $option_label ); ?>
                                            </option>
										<?php endforeach; ?>
                                    </select>
								<?php elseif ( $type === 'radio' && in_array( $field['radio_style'] ?? '', [ 'avatars', 'pills' ], TRUE ) ) : ?>
                                    <?php KERP_Helpers_Template::render_template( 'app/components/list/filter-choice-radio.php', [ 'field' => $field, 'id' => $id, 'name' => $name, 'value' => $value, 'options' => $options, 'dependent_hidden' => $dependent_hidden ] ); ?>
								<?php elseif ( $type === 'radio' ) : ?>
                                    <div class="d-flex flex-wrap g-2">
                                        <div class="custom-control custom-radio">
                                            <input
                                                type="radio"
                                                id="<?php echo esc_attr( $id . '-all' ); ?>"
                                                name="kerp-filter-<?php echo esc_attr( $name ); ?>"
                                                class="custom-control-input kerp-filter-input"
                                                data-for="<?php echo esc_attr( $name ); ?>"
                                                value=""
												<?php checked( (string) $value, '' ); ?>
                                            >
                                            <label class="custom-control-label"
                                                   for="<?php echo esc_attr( $id . '-all' ); ?>">
												<?php esc_html_e( 'همه', 'kasebi-erp' ); ?>
                                            </label>
                                        </div>
										
										<?php foreach ( $options as $option_key => $option_label ) : ?>
											<?php $option_id = $id . '-' . sanitize_html_class( (string) $option_key ); ?>
                                            <div class="custom-control custom-radio">
                                                <input
                                                    type="radio"
                                                    id="<?php echo esc_attr( $option_id ); ?>"
                                                    name="kerp-filter-<?php echo esc_attr( $name ); ?>"
                                                    class="custom-control-input kerp-filter-input"
                                                    data-for="<?php echo esc_attr( $name ); ?>"
                                                    value="<?php echo esc_attr( (string) $option_key ); ?>"
													<?php checked( (string) $value, (string) $option_key ); ?>
                                                >
                                                <label class="custom-control-label"
                                                       for="<?php echo esc_attr( $option_id ); ?>">
													<?php echo esc_html( (string) $option_label ); ?>
                                                </label>
                                            </div>
										<?php endforeach; ?>
                                    </div>
								<?php elseif ( $type === 'switch' ) : ?>
                                    <div class="custom-control custom-switch">
                                        <input
                                            type="checkbox"
                                            id="<?php echo esc_attr( $id ); ?>"
                                            class="custom-control-input kerp-filter-input"
                                            data-for="<?php echo esc_attr( $name ); ?>"
                                            value="1"
											<?php checked( ! empty( $value ) ); ?>
                                        >
                                        <label class="custom-control-label" for="<?php echo esc_attr( $id ); ?>">
											<?php echo esc_html( $placeholder !== '' ? $placeholder : __( 'فقط موارد فعال', 'kasebi-erp' ) ); ?>
                                        </label>
                                    </div>
								<?php endif; ?>
                            </div>
                        </div>
                    </div>
				<?php endforeach; ?>
            </div>
        </div>

        <div class="dropdown-foot between">
            <button
                type="button"
                class="btn btn-primary <?php echo esc_attr( $apply_class ); ?>"
                data-action="<?php echo esc_attr( $action ); ?>"
                data-page="<?php echo esc_attr( $page ); ?>"
            >
				<?php esc_html_e( 'اعمال فیلتر', 'kasebi-erp' ); ?>
            </button>

            <a class="<?php echo esc_attr( $reset_class ); ?>" data-action="<?php echo esc_attr( $action ); ?>"
               data-page="<?php echo esc_attr( $page ); ?>">
				<?php esc_html_e( 'بازنشانی فیلتر', 'kasebi-erp' ); ?>
            </a>
        </div>
    </div>
</div>
