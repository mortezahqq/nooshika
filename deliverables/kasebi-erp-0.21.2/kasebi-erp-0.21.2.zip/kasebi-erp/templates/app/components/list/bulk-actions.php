<?php

defined( 'ABSPATH' ) || exit;

/**
 * @var array  $actions
 * @var array  $need_fields
 * @var string $page
 * @var string $action
 * @var string $item_selector
 * @var string $select_class
 * @var string $dropdown_class
 * @var string $placeholder
 */

$actions       = isset( $actions ) && is_array( $actions ) ? $actions : [];
$need_fields   = isset( $need_fields ) && is_array( $need_fields ) ? $need_fields : [];
$page          = sanitize_text_field( (string) ( $page ?? '' ) );
$action        = sanitize_key( (string) ( $action ?? '' ) );
$item_selector = sanitize_text_field( (string) ( $item_selector ?? '.select_item_row' ) );
$placeholder   = sanitize_text_field(
	(string) ( $placeholder ?? __( 'عملیات گروهی', 'kasebi-erp' ) )
);

/*
 * برای سازگاری با فراخوانی‌های قبلی، select_class نیز پشتیبانی می‌شود.
 */
$dropdown_class = (string) (
	$dropdown_class
	?? $select_class
	   ?? 'row_bulk_actions'
);

$dropdown_class = implode(
	' ',
	array_filter(
		array_map(
			'sanitize_html_class',
			preg_split( '/\s+/', trim( $dropdown_class ) ) ?: []
		)
	)
);

if ( empty( $actions ) || $action === '' ) {
	return;
}

?>
<div class="dropdown bulk-actions-dropdown">
    <button
        type="button"
        class="btn btn-sm btn-outline-light dropdown-toggle"
        data-bs-toggle="dropdown"
        data-kerp-no-tooltip
        aria-expanded="false"
        aria-label="<?php echo esc_attr( $placeholder ); ?>"
    >
        <span><?php echo esc_html( $placeholder ); ?></span>
        <em class="icon ni ni-chevron-down"></em>
    </button>

    <div class="dropdown-menu dropdown-menu-start">
        <ul class="link-list-opt no-bdr">
			<?php foreach ( $actions as $action_key => $definition ) : ?>
				<?php
				if ( ! is_array( $definition ) ) {
					continue;
				}
				
				$action_key = sanitize_key(
					(string) ( $definition['key'] ?? $action_key )
				);
				
				if ( $action_key === '' ) {
					continue;
				}
				
				$operation_action = sanitize_key(
					(string) ( $definition['action'] ?? '' )
				);
				
				$label = sanitize_text_field(
					(string) ( $definition['label'] ?? $action_key )
				);
				
				$needs = [];
				
				foreach ( (array) ( $definition['need'] ?? [] ) as $need_key ) {
					$need_key = sanitize_key( (string) $need_key );
					
					if (
						$need_key === ''
						|| $need_key === 'customer_ids'
					) {
						continue;
					}
					
					if (
						isset( $need_fields[ $need_key ] )
						&& is_array( $need_fields[ $need_key ] )
					) {
						$field        = $need_fields[ $need_key ];
						$field['key'] = $need_key;
						$needs[]      = $field;
					}
				}
				
				$need_keys = array_values(
					array_filter(
						array_map(
							'sanitize_key',
							(array) ( $definition['need'] ?? [] )
						)
					)
				);
				
				$attributes = isset( $definition['attributes'] )
				              && is_array( $definition['attributes'] )
					? $definition['attributes']
					: [];
				
				$icon_classes = preg_split(
					'/\s+/',
					trim( (string) ( $definition['icon'] ?? '' ) )
				);
				
				$icon_classes = is_array( $icon_classes )
					? array_filter(
						array_map( 'sanitize_html_class', $icon_classes )
					)
					: [];
				
				$icon = implode( ' ', $icon_classes );
				
				$item_classes = [
					$dropdown_class,
				];
				
				if ( ! empty( $definition['class'] ) ) {
					$custom_classes = preg_split(
						'/\s+/',
						trim( (string) $definition['class'] )
					);
					
					if ( is_array( $custom_classes ) ) {
						foreach ( $custom_classes as $custom_class ) {
							$custom_class = sanitize_html_class(
								$custom_class
							);
							
							if ( $custom_class !== '' ) {
								$item_classes[] = $custom_class;
							}
						}
					}
				}
				
				$item_classes = implode(
					' ',
					array_unique(
						array_filter( $item_classes )
					)
				);
				?>

                <li>
                    <a
                        href="#"
                        class="<?php echo esc_attr( $item_classes ); ?>"
                        data-action="<?php echo esc_attr( $action ); ?>"
                        data-page="<?php echo esc_attr( $page ); ?>"
                        data-item-selector="<?php echo esc_attr( $item_selector ); ?>"
                        data-operation="<?php echo esc_attr( $action_key ); ?>"
                        data-operation-action="<?php echo esc_attr( $operation_action ); ?>"
                        data-need="<?php echo esc_attr( implode( ',', $need_keys ) ); ?>"
                        data-needs="<?php echo esc_attr( wp_json_encode( $needs ) ); ?>"
						<?php
						foreach ( $attributes as $attribute_name => $attribute_value ) {
							$attribute_name = strtolower(
								trim( (string) $attribute_name )
							);
							
							if (
								! str_starts_with( $attribute_name, 'data-' )
								|| in_array(
									$attribute_name,
									[
										'data-action',
										'data-page',
										'data-item-selector',
										'data-operation',
										'data-operation-action',
										'data-need',
										'data-needs',
									],
									TRUE
								)
							) {
								continue;
							}
							
							printf(
								' %s="%s"',
								esc_attr( $attribute_name ),
								esc_attr(
									is_scalar( $attribute_value )
										? (string) $attribute_value
										: wp_json_encode( $attribute_value )
								)
							);
						}
						?>
                    >
						<?php if ( $icon !== '' ) : ?>
                            <em class="icon <?php echo esc_attr( $icon ); ?>"></em>
						<?php endif; ?>

                        <span><?php echo esc_html( $label ); ?></span>
                    </a>
                </li>
			<?php endforeach; ?>
        </ul>
    </div>
</div>