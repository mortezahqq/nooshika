<?php

defined( 'ABSPATH' ) || exit;

/**
 * @var array $actions
 */

$actions = isset( $actions ) && is_array( $actions ) ? $actions : [];

if ( empty( $actions ) ) {
	return;
}

// Inline actions share the established icon and tooltip renderer; dropdown remains the default.
if ( ( $display ?? 'dropdown' ) === 'inline' ) {
    $items = [];
    foreach ( $actions as $action_key => $action ) {
        if ( ! is_array( $action ) ) continue;
        $data = isset( $action['data'] ) && is_array( $action['data'] ) ? $action['data'] : [];
        if ( ! empty( $action['data_url'] ) ) $data['url'] = (string) $action['data_url'];
        $items[] = array_merge( $action, [
            'url' => (string) ( $action['url'] ?? $action['link'] ?? '#' ),
            'title' => (string) ( $action['title'] ?? $action_key ),
            'icon' => 'icon ' . (string) ( $action['icon'] ?? 'ni ni-eye' ),
            'data' => $data,
        ] );
    }
    KERP_Helpers_Template::render_template( 'app/components/list/row-icons.php', [ 'items' => $items ] );
    return;
}

?>
<ul class="nk-tb-actions gx-1">
	<li>
		<div class="drodown">
			<button
				type="button"
				class="btn btn-sm btn-icon btn-trigger dropdown-toggle"
				data-bs-toggle="dropdown"
				aria-expanded="false"
			>
				<em class="icon ni ni-more-h"></em>
			</button>

			<div class="dropdown-menu dropdown-menu-end">
				<ul class="link-list-opt no-bdr">
					<?php foreach ( $actions as $action_key => $action ) : ?>
						<?php
						if ( ! is_array( $action ) ) {
							continue;
						}

						$url      = (string) ( $action['url'] ?? $action['link'] ?? '#' );
						$data_url = (string) ( $action['data_url'] ?? '' );
						$title    = sanitize_text_field( (string) ( $action['title'] ?? $action_key ) );
						$icon     = sanitize_text_field( (string) ( $action['icon'] ?? 'ni ni-eye' ) );
						$class    = sanitize_text_field( (string) ( $action['class'] ?? '' ) );
						$data     = isset( $action['data'] ) && is_array( $action['data'] )
							? $action['data']
							: [];
						?>
						<li>
							<a
								href="<?php echo esc_url( $url ); ?>"
								class="<?php echo esc_attr( $class ); ?>"
								<?php echo $data_url !== '' ? 'data-url="' . esc_attr( $data_url ) . '"' : ''; ?>
								<?php
								foreach ( $data as $data_key => $data_value ) {
									$data_key = sanitize_key( (string) $data_key );

									if ( $data_key === '' ) {
										continue;
									}

									printf(
										' data-%s="%s"',
										esc_attr( $data_key ),
										esc_attr( is_scalar( $data_value ) ? (string) $data_value : wp_json_encode( $data_value ) )
									);
								}
								?>
							>
								<em class="icon <?php echo esc_attr( $icon ); ?>"></em>
								<span><?php echo esc_html( $title ); ?></span>
							</a>
						</li>
					<?php endforeach; ?>
				</ul>
			</div>
		</div>
	</li>
</ul>
