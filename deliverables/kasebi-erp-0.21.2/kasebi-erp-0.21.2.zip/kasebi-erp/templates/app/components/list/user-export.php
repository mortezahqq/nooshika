<?php

defined( 'ABSPATH' ) || exit;

/** action (required), filter_selector (required), filters, per_page, filename. */
$action = sanitize_key( (string) ( $action ?? '' ) );
$filter_selector = (string) ( $filter_selector ?? '' );
if ( $action === '' || $filter_selector === '' ) { return; }
$filters = isset( $filters ) && is_array( $filters ) ? $filters : [];
$per_page = max( 1, min( 200, (int) ( $per_page ?? 100 ) ) );
$filename = sanitize_file_name( (string) ( $filename ?? 'users.csv' ) );
if ( ! str_ends_with( strtolower( $filename ), '.csv' ) ) { $filename .= '.csv'; }
?>
<div class="kerp-user-export d-inline-flex flex-column mw-100"
     data-export-action="<?php echo esc_attr( $action ); ?>"
     data-export-filters="<?php echo esc_attr( wp_json_encode( $filters ) ); ?>"
     data-export-filter-selector="<?php echo esc_attr( $filter_selector ); ?>"
     data-export-per-page="<?php echo esc_attr( $per_page ); ?>"
     data-export-nonce="<?php echo esc_attr( wp_create_nonce( 'kerp_user_export_' . $action ) ); ?>"
     data-export-filename="<?php echo esc_attr( $filename ); ?>">
    <span class="visually-hidden kerp-user-export-status" role="status" aria-live="polite"></span>
    <button type="button" class="btn btn-sm btn-outline-light kerp-user-export-start"
            data-bs-toggle="tooltip" title="<?php esc_attr_e( 'خروجی CSV از کاربران با فیلترهای فعلی', 'kasebi-erp' ); ?>"
            aria-label="<?php esc_attr_e( 'خروجی CSV از کاربران با فیلترهای فعلی', 'kasebi-erp' ); ?>">
        <em class="icon ni ni-download"></em><span><?php esc_html_e( 'اکسپورت', 'kasebi-erp' ); ?></span>
    </button>
    <div class="kerp-user-export-progress d-none" hidden>
        <div class="d-flex align-items-center gap-2">
            <span class="kerp-user-export-label small" role="status" aria-live="polite">۰٪</span>
            <button type="button" class="btn btn-sm btn-icon btn-outline-light kerp-user-export-cancel"
                    data-bs-toggle="tooltip" title="<?php esc_attr_e( 'لغو خروجی', 'kasebi-erp' ); ?>"
                    aria-label="<?php esc_attr_e( 'لغو خروجی', 'kasebi-erp' ); ?>"><em class="icon ni ni-cross"></em></button>
        </div>
        <div class="progress progress-sm mt-1">
            <div class="progress-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"
                 aria-label="<?php esc_attr_e( 'پیشرفت خروجی کاربران', 'kasebi-erp' ); ?>" style="width:0%"></div>
        </div>
    </div>
    <a class="btn btn-sm btn-primary kerp-user-export-download d-none" hidden
       data-bs-toggle="tooltip" title="<?php esc_attr_e( 'دانلود فایل CSV آماده‌شده', 'kasebi-erp' ); ?>"
       aria-label="<?php esc_attr_e( 'دانلود فایل CSV آماده‌شده', 'kasebi-erp' ); ?>">
        <em class="icon ni ni-download"></em><span><?php esc_html_e( 'دانلود CSV', 'kasebi-erp' ); ?></span>
    </a>
</div>
