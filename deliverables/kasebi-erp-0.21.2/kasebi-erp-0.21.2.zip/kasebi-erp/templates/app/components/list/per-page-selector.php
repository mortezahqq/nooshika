<?php

defined( 'ABSPATH' ) || exit;

/**
 * @var int    $per_page
 * @var array  $available_per_pages
 * @var string $page
 * @var string $action
 */

$per_page = max( 1, absint( $per_page ?? 20 ) );
$page     = sanitize_text_field( (string) ( $page ?? '' ) );
$action   = sanitize_key( (string) ( $action ?? 'erp_request_page_content' ) );

$available_per_pages = isset( $available_per_pages ) && is_array( $available_per_pages )
	? $available_per_pages
	: [ 10, 20, 50, 100 ];

$available_per_pages = array_values(
	array_unique(
		array_filter(
			array_map( 'absint', $available_per_pages )
		)
	)
);

if ( ! in_array( $per_page, $available_per_pages, TRUE ) ) {
	$available_per_pages[] = $per_page;
}

sort( $available_per_pages );

?>
<div class="dropdown">
	<button
		type="button"
		class="btn btn-trigger btn-icon dropdown-toggle"
		data-bs-toggle="dropdown"
        data-kerp-no-tooltip
		aria-expanded="false"
		aria-label="<?php esc_attr_e( 'تعداد نمایش در صفحه', 'kasebi-erp' ); ?>"
	>
		<em class="icon ni ni-setting"></em>
	</button>

	<div class="dropdown-menu dropdown-menu-xs dropdown-menu-end">
		<ul class="link-check">
			<li><span><?php esc_html_e( 'نمایش', 'kasebi-erp' ); ?></span></li>

			<?php foreach ( $available_per_pages as $item ) : ?>
				<li>
					<a
						href="#"
						class="change_per_page<?php echo $item === $per_page ? ' active' : ''; ?>"
						data-action="<?php echo esc_attr( $action ); ?>"
						data-page="<?php echo esc_attr( $page ); ?>"
						data-per-page="<?php echo esc_attr( $item ); ?>"
					>
						<?php echo esc_html( $item ); ?>
					</a>
				</li>
			<?php endforeach; ?>
		</ul>
	</div>
</div>
