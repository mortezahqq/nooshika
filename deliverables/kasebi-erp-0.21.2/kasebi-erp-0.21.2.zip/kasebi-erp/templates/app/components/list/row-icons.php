<?php

defined( 'ABSPATH' ) || exit;

/**
 * @var array $items
 * @var array $context
 */

$items   = isset( $items ) && is_array( $items ) ? $items : [];
$context = isset( $context ) && is_array( $context ) ? $context : [];

if ( empty( $items ) ) {
	return;
}

$sanitize_classes = static function( string $classes ): string {
	$classes = preg_split( '/\s+/', trim( $classes ) );
	$classes = is_array( $classes ) ? $classes : [];
	$classes = array_filter( array_map( 'sanitize_html_class', $classes ) );
	
	return implode( ' ', $classes );
};

?>
<div class="d-flex align-items-center flex-wrap kerp-row-icons fs-17px text-date" style="gap: 12px">
	<?php
	foreach ( $items as $item_key => $item ) {
		if ( ! is_array( $item ) || ! empty( $item['hidden'] ) ) {
			continue;
		}
		
		$icon    = $sanitize_classes( (string) ( $item['icon'] ?? '' ) );
		$tooltip = sanitize_text_field( (string) ( $item['tooltip'] ?? $item['title'] ?? '' ) );
		$url     = (string) ( $item['url'] ?? '' );
		$class   = $sanitize_classes( (string) ( $item['class'] ?? '' ) );
		$data    = isset( $item['data'] ) && is_array( $item['data'] ) ? $item['data'] : [];
		
		if ( $icon === '' ) {
			continue;
		}
		
		$tag = $url !== '' ? 'a' : 'span';
		
        // Modal/collapse triggers need their own Bootstrap toggle; put the tooltip on a wrapper.
        $wrapped_tooltip = $tooltip !== '' && ! empty( $data['bs-toggle'] ) && $data['bs-toggle'] !== 'tooltip';
        if ( $wrapped_tooltip ) printf( '<span class="d-inline-flex" data-bs-toggle="tooltip" data-bs-placement="top" title="%s">', esc_attr( $tooltip ) );
		echo '<' . esc_html( $tag );
		if ( $url !== '' ) {
			printf( ' href="%s"', esc_url( $url ) );
		}
		
		printf(
			' class="d-flex align-items-center justify-content-center kerp-row-icon %s"',
			esc_attr( $class )
		);
		
		if ( $tooltip !== '' && ! $wrapped_tooltip ) {
			printf(
				' data-bs-toggle="tooltip" data-bs-placement="top" title="%s" aria-label="%s"',
				esc_attr( $tooltip ),
				esc_attr( $tooltip )
			);
		}
		
        if ( $wrapped_tooltip ) printf( ' aria-label="%s"', esc_attr( $tooltip ) );
		foreach ( $data as $data_key => $data_value ) {
			$data_key = sanitize_key( (string) $data_key );
			
			if ( $data_key === '' ) {
				continue;
			}
			
			printf(
				' data-%s="%s"',
				esc_attr( $data_key ),
				esc_attr(
					is_scalar( $data_value )
						? (string) $data_value
						: wp_json_encode( $data_value )
				)
			);
		}
		?>>
        <em class="<?php echo esc_attr( $icon ); ?>"></em>
		<?php
		echo '</' . esc_html( $tag ) . '>';
        if ( $wrapped_tooltip ) echo '</span>';
	}
	?>
</div>
