<?php

defined( 'ABSPATH' ) || exit;

/**
 * @var int    $max_page_num
 * @var int    $current_page
 * @var string $class_name
 * @var int    $show_count
 * @var string $page
 * @var string $action
 */

$max_page_num = max( 1, absint( $max_page_num ?? 1 ) );
$current_page = max( 1, absint( $current_page ?? 1 ) );
$show_count   = max( 1, absint( $show_count ?? 2 ) );
$page         = sanitize_text_field( (string) ( $page ?? '' ) );
$action       = sanitize_key( (string) ( $action ?? 'erp_request_page_content' ) );

$class_names = preg_split( '/\s+/', trim( (string) ( $class_name ?? '' ) ) );
$class_names = array_values(
	array_filter(
		array_map(
			'sanitize_html_class',
			is_array( $class_names ) ? $class_names : []
		)
	)
);

if ( $current_page > $max_page_num ) {
	$current_page = $max_page_num;
}

if ( $max_page_num <= 1 ) {
	return;
}

$render_page = static function( int $page_number, bool $active = FALSE ) use ( $class_names, $page, $action ): void {
	$classes = array_merge( [ 'page-item', 'kerp-pagination-link' ], $class_names );
	
	if ( $active ) {
		$classes[] = 'active';
	}
	?>
    <li
        class="<?php echo esc_attr( implode( ' ', $classes ) ); ?>"
        data-action="<?php echo esc_attr( $action ); ?>"
        data-route="<?php echo esc_attr( $page ); ?>"
        data-page="<?php echo esc_attr( $page_number ); ?>"
    >
        <a class="page-link" href="#">
			<?php echo esc_html( $page_number ); ?>
        </a>
    </li>
	<?php
};

?>
<nav aria-label="<?php esc_attr_e( 'صفحه‌بندی', 'kasebi-erp' ); ?>">
    <ul class="pagination justify-content-center mb-0">
        <li
            class="page-item kerp-pagination-link<?php echo $current_page <= 1 ? ' disabled' : ''; ?>"
            data-action="<?php echo esc_attr( $action ); ?>"
            data-route="<?php echo esc_attr( $page ); ?>"
            data-page="<?php echo esc_attr( max( 1, $current_page - 1 ) ); ?>"
        >
            <a class="page-link" href="#" aria-label="<?php esc_attr_e( 'صفحه قبل', 'kasebi-erp' ); ?>">
                <em class="icon ni ni-chevron-left"></em>
            </a>
        </li>
		
		<?php
		$dots_rendered = FALSE;
		
		for ( $page_number = 1; $page_number <= $max_page_num; $page_number ++ ) {
			$should_show = $page_number === 1
			               || $page_number === $max_page_num
			               || (
				               $page_number >= $current_page - $show_count
				               && $page_number <= $current_page + $show_count
			               );
			
			if ( $should_show ) {
				$render_page( $page_number, $page_number === $current_page );
				$dots_rendered = FALSE;
				continue;
			}
			
			if ( ! $dots_rendered ) {
				?>
                <li class="page-item disabled">
					<span class="page-link">
						<em class="icon ni ni-more-h"></em>
					</span>
                </li>
				<?php
				$dots_rendered = TRUE;
			}
		}
		?>

        <li
            class="page-item kerp-pagination-link<?php echo $current_page >= $max_page_num ? ' disabled' : ''; ?>"
            data-action="<?php echo esc_attr( $action ); ?>"
            data-route="<?php echo esc_attr( $page ); ?>"
            data-page="<?php echo esc_attr( min( $max_page_num, $current_page + 1 ) ); ?>"
        >
            <a class="page-link" href="#" aria-label="<?php esc_attr_e( 'صفحه بعد', 'kasebi-erp' ); ?>">
                <em class="icon ni ni-chevron-right"></em>
            </a>
        </li>
    </ul>
</nav>
