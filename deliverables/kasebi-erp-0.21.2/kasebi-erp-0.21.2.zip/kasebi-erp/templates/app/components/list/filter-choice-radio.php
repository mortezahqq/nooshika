<?php
defined( 'ABSPATH' ) || exit;
$avatar_choices = ( $field['radio_style'] ?? '' ) === 'avatars';
$choices = [ '' => 'همه موارد' ] + $options;
?>
<div class="g-1 align-center flex-wrap<?php echo $avatar_choices ? ' w-max-300px' : ''; ?>" role="group" aria-label="<?php echo esc_attr( $field['label'] ?? '' ); ?>">
    <?php foreach ( $choices as $choice => $choice_label ) :
        $choice_id = $id . '-' . ( $choice === '' ? 'all' : sanitize_html_class( (string) $choice ) );
        ?>
        <div class="custom-control custom-radio custom-control-pro<?php echo $avatar_choices ? ' custom-control-pro-icon' : ''; ?> no-control">
            <input type="radio" class="custom-control-input kerp-filter-input" name="<?php echo esc_attr( 'kerp-filter-' . $name ); ?>" id="<?php echo esc_attr( $choice_id ); ?>" data-for="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( (string) $choice ); ?>" <?php checked( (string) $value, (string) $choice ); ?> <?php disabled( $dependent_hidden ); ?>>
            <label class="custom-control-label<?php echo $avatar_choices ? ' rounded-circle overflow-hidden p-0' : ''; ?>" for="<?php echo esc_attr( $choice_id ); ?>" title="<?php echo esc_attr( $choice_label ); ?>"<?php if ( $avatar_choices ) : ?> style="width:36px;height:36px"<?php endif; ?>>
                <?php if ( $avatar_choices && $choice === '' ) : ?>
                    <em class="icon ni ni-user-list" aria-hidden="true"></em><span class="visually-hidden">همه کارمندان</span>
                <?php elseif ( $avatar_choices ) : ?>
                    <img src="<?php echo esc_url( $field['avatars'][ $choice ] ?? '' ); ?>" class="user_avatar rounded-circle w-100 h-100" alt="<?php echo esc_attr( $choice_label ); ?>">
                <?php else : echo esc_html( $choice_label ); endif; ?>
            </label>
        </div>
    <?php endforeach; ?>
</div>
