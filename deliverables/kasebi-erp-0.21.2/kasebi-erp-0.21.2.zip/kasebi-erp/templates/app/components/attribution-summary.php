<?php
// Shared compact attribution display; details use the existing public-content modal.
defined( 'ABSPATH' ) || exit;
$data = isset( $data ) && is_array( $data ) ? $data : [];
foreach ( [ 'products' => 'landing_products', 'cart_items' => 'cart_products' ] as $key => $target ) {
    $names = [];
    foreach ( (array) ( $data[ $key ] ?? [] ) as $item ) {
        if ( ! is_array( $item ) ) { continue; }
        $name = isset( $item['name'] ) && is_scalar( $item['name'] ) ? trim( (string) $item['name'] ) : '';
        if ( $name !== '' ) { $names[] = $name; }
    }
    $data[ $target ] = implode( '، ', array_unique( $names ) );
}
$labels = [
    'touch_type' => 'مسیر عضویت', 'source_type' => 'نوع منبع',
    'utm_source' => 'منبع', 'utm_medium' => 'رسانه', 'utm_campaign' => 'کمپین',
    'utm_term' => 'عبارت جستجو', 'utm_content' => 'محتوای تبلیغ',
    'registered_at' => 'زمان اولین ورود', 'form_title' => 'فرم',
    'form_id' => 'شناسه فرم', 'entry_id' => 'شناسه ورودی فرم', 'order_id' => 'شماره سفارش',
    'landing_products' => 'محصولات لندینگ', 'cart_products' => 'محصولات سبد خرید',
    'landing_url' => 'صفحه فرود', 'referrer_url' => 'ارجاع‌دهنده', 'redirect_url' => 'مقصد عضویت',
];
$english_labels = [
    'touch_type' => 'Registration Method', 'source_type' => 'Source Type',
    'utm_source' => 'UTM Source', 'utm_medium' => 'UTM Medium', 'utm_campaign' => 'UTM Campaign',
    'utm_term' => 'UTM Term', 'utm_content' => 'UTM Content',
    'landing_url' => 'Landing Page', 'referrer_url' => 'Referrer', 'redirect_url' => 'Redirect URL',
];
$translations = [
    'landing_order' => 'سفارش از لندینگ', 'gravity_form' => 'تکمیل فرم گرویتی',
    'site_registration' => 'ثبت‌نام سایت', '(direct)' => 'ورود مستقیم', 'direct' => 'ورود مستقیم',
    'typein' => 'ورود مستقیم', 'referral' => 'ارجاع از سایت دیگر', 'organic' => 'جستجوی طبیعی',
    'campaign' => 'کمپین تبلیغاتی', 'internal' => 'ارجاع داخلی', 'cpc' => 'تبلیغات کلیکی',
    'social' => 'شبکه‌های اجتماعی', 'email' => 'ایمیل', 'paid' => 'تبلیغات پولی',
];
$facts = [];
foreach ( $labels as $key => $label ) {
    $value = $data[ $key ] ?? '';
    $value = is_scalar( $value ) ? trim( (string) $value ) : '';
    if ( in_array( $key, [ 'form_id', 'entry_id', 'order_id' ], TRUE ) && absint( $value ) === 0 ) { continue; }
    if ( in_array( strtolower( $value ), [ '', '(none)', 'none', '(not set)', '(not provided)', 'null', 'http://(none)', 'https://(none)' ], TRUE ) || ( $key === 'utm_content' && $value === '/' ) ) { continue; }
    $is_url = in_array( $key, [ 'landing_url', 'referrer_url', 'redirect_url' ], TRUE );
    $display = in_array( $key, [ 'touch_type', 'source_type', 'utm_source', 'utm_medium' ], TRUE ) ? ( $translations[ strtolower( $value ) ] ?? $value ) : $value;
    if ( $key === 'registered_at' ) { $display = get_date_from_gmt( $value, 'Y/m/d H:i' ); }
    if ( $key === 'utm_source' && $display === ( $facts['source_type']['display'] ?? '' ) ) { continue; }
    $facts[ $key ] = [ 'label' => $label, 'english_label' => $english_labels[ $key ] ?? '', 'display' => $display, 'value' => $value, 'is_url' => $is_url,
        'show_original' => in_array( $key, [ 'touch_type', 'source_type', 'utm_source', 'utm_medium' ], TRUE ) && $display !== $value ];
}
$primary = $facts['touch_type']['display'] ?? $facts['utm_source']['display'] ?? $facts['source_type']['display'] ?? '';
$secondary = $facts['utm_campaign']['display'] ?? ( isset( $facts['touch_type'] ) ? ( $facts['utm_source']['display'] ?? $facts['source_type']['display'] ?? '' ) : '' );
$modal_title = isset( $facts['touch_type'] ) ? 'جزئیات اولین ورود' : 'جزئیات منبع سفارش';
$content_id = wp_unique_id( 'kerp-attribution-' );
$first_touch_style = TRUE;
$appearance = [
    'landing_order' => [ 'green', 'ni-cart' ],
    'gravity_form' => [ 'purple', 'ni-edit-alt' ],
    'site_registration' => [ 'blue', 'ni-user-add' ],
][ $facts['touch_type']['value'] ?? '' ] ?? [ 'neutral', 'ni-compass' ];
$style_class = $first_touch_style ? ' kerp-attribution-first-touch kerp-attribution-tone--' . $appearance[0] : '';
?>
<div class="kerp-attribution-summary<?php echo esc_attr( $style_class . ( ! $facts ? ' is-empty' : '' ) ); ?>">
    <?php if ( ! $facts ) : ?>
        <span class="sub-text"><?php esc_html_e( 'ثبت نشده', 'kasebi-erp' ); ?></span>
    <?php else : ?>
        <span class="kerp-attribution-summary__line fw-medium<?php echo $first_touch_style ? ' kerp-attribution-first-touch__title' : ''; ?>" title="<?php echo esc_attr( $primary ); ?>"><?php if ( $first_touch_style ) : ?><em class="icon ni <?php echo esc_attr( $appearance[1] ); ?>" aria-hidden="true"></em><?php endif; ?><span><?php echo esc_html( $primary ?: 'اطلاعات ورودی' ); ?></span></span>
        <?php if ( $secondary !== '' && $secondary !== $primary ) : ?>
            <span class="kerp-attribution-summary__line sub-text" title="<?php echo esc_attr( $secondary ); ?>"><?php echo esc_html( $secondary ); ?></span>
        <?php endif; ?>
        <button type="button" class="btn btn-sm btn-outline-light show_public_content_modal kerp-attribution-summary__button" aria-label="<?php echo esc_attr( $modal_title ); ?>" title="<?php echo esc_attr( $modal_title ); ?>" data-modal-title="<?php echo esc_attr( $modal_title ); ?>" data-content-target="#<?php echo esc_attr( $content_id ); ?>"><em class="icon ni ni-info" aria-hidden="true"></em></button>
        <div id="<?php echo esc_attr( $content_id ); ?>" class="d-none">
            <dl class="kerp-attribution-details mb-0<?php echo $first_touch_style ? esc_attr( ' kerp-attribution-details--first-touch kerp-attribution-tone--' . $appearance[0] ) : ''; ?>">
                <?php foreach ( $facts as $fact ) : ?>
                    <div class="kerp-attribution-details__row">
                        <dt class="sub-text"><?php echo esc_html( $fact['label'] ); ?><?php if ( $fact['english_label'] !== '' ) : ?> <small class="d-block fw-normal"><bdi dir="ltr" lang="en"><?php echo esc_html( $fact['english_label'] ); ?></bdi></small><?php endif; ?></dt>
                        <dd class="mb-0">
                            <?php if ( $fact['is_url'] ) : ?>
                                <?php $href = preg_match( '#^https?://#i', $fact['value'] ) ? $fact['value'] : home_url( '/' . ltrim( $fact['value'], '/' ) ); ?>
                                <a class="kerp-attribution-details__link" href="<?php echo esc_url( $href ); ?>" title="<?php echo esc_attr( $fact['value'] ); ?>" target="_blank" rel="noopener noreferrer" dir="auto"><?php echo esc_html( $fact['value'] ); ?></a>
                            <?php else : ?>
                                <span dir="auto"><?php echo esc_html( $fact['display'] ); ?></span>
                                <?php if ( $fact['show_original'] ) : ?><small class="text-soft"> (<bdi dir="ltr"><?php echo esc_html( $fact['value'] ); ?></bdi>)</small><?php endif; ?>
                            <?php endif; ?>
                        </dd>
                    </div>
                <?php endforeach; ?>
            </dl>
        </div>
    <?php endif; ?>
</div>
