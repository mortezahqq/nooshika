<?php

defined( 'ABSPATH' ) || exit;

$title       = trim( (string) ( $title ?? '' ) );
$description = trim( (string) ( $description ?? '' ) );
$eyebrow     = trim( (string) ( $eyebrow ?? '' ) );
$icon        = trim( (string) ( $icon ?? 'ni ni-info' ) );

if ( $title === '' ) {
	return;
}
?>
<div class="kerp-customer-content-hero">
    <div class="kerp-customer-content-hero__copy">
        <span class="kerp-customer-content-hero__icon"><em class="icon <?php echo esc_attr( $icon ); ?>"></em></span>
        <div>
			<?php if ( $eyebrow !== '' ) : ?>
                <span class="kerp-customer-content-hero__eyebrow"><?php echo esc_html( $eyebrow ); ?></span>
			<?php endif; ?>
            <h4><?php echo esc_html( $title ); ?></h4>
			<?php if ( $description !== '' ) : ?>
                <p><?php echo wp_kses_post( $description ); ?></p>
			<?php endif; ?>
        </div>
    </div>
    <?php // Optional, trusted markup rendered by the calling template.
    if ( isset( $content ) && is_string( $content ) ) { echo $content; } ?>
</div>
