<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * @var string $id
 * @var string $action
 * @var string $page
 * @var string $title
 * @var string $button
 * @var array  $fields
 */
?>
<?php if ( empty( $body_only ) ) : ?><div class="modal fade zoom" id="<?php echo esc_attr( $id ); ?>">
    <div class="modal-dialog <?php echo esc_attr( $class ?? 'modal-lg' ); ?>" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
					<?php echo esc_html( $title ?? '' ); ?>
                </h5>
                <a href="#" class="close" data-bs-dismiss="modal" aria-label="بستن">
                    <em class="icon ni ni-cross"></em>
                </a>
            </div>
            <div class="modal-body">
<?php endif; ?>
                <form class="modal_form"
                      data-action="<?php echo esc_attr( $action ); ?>"
                      data-page="<?php echo esc_attr( $page ); ?>">
                    <div class="row g-3">
						<?php if ( ! empty( $body ) ) { echo $body; } // Trusted, server-rendered component content. ?>
						<?php
						if ( ! empty( $fields ) && is_array( $fields ) ) {
							foreach ( $fields as $field ) {
								$type = $field['type'] ?? 'text';
								KERP_Helpers_Template::render_template( "app/components/fields/$type.php",
									[ 'field' => $field, ] );
							}
						}
						?>
                        <div class="col-12">
                            <?php if ( ! empty( $footer_note ) ) : ?><div class="modal-footer-note text-soft border-top pt-3 mb-3"><?php echo esc_html( $footer_note ); ?></div><?php endif; ?>
                            <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                <li>
                                    <div class="btn btn-primary submit_modal_form">
										<?php echo esc_html( $button ?? 'ثبت' ); ?>
                                    </div>
                                </li>
                                <li>
                                    <a href="#" class="link link-light" data-bs-dismiss="modal">
                                        لغو
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </form>
<?php if ( empty( $body_only ) ) : ?>            </div>
        </div>
    </div>
</div>
<?php endif; ?>
