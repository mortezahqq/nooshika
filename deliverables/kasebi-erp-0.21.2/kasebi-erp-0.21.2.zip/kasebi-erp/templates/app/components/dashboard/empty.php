<?php

defined( 'ABSPATH' ) || exit;
?>
<div class="col-12">
	<div class="card card-bordered">
		<div class="card-inner text-center py-5">
			<em class="icon ni ni-view-grid fs-1 text-soft" aria-hidden="true"></em>
			<h5 class="mt-3"><?php esc_html_e( 'میزکار شما هنوز بلوکی ندارد', 'kasebi-erp' ); ?></h5>
			<p class="text-soft mb-0"><?php esc_html_e( 'بلوک‌های ماژول‌های فعال، متناسب با سطح دسترسی شما در این بخش نمایش داده می‌شوند.', 'kasebi-erp' ); ?></p>
		</div>
	</div>
</div>
