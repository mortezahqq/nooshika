<?php

defined( 'ABSPATH' ) || exit;

$heading_id = 'kerp-dashboard-' . $block['id'] . '-title';
$dashboard_icons = [ 'customers' => 'users', 'leads' => 'growth', 'orders' => 'cart', 'payments' => 'wallet', 'installment_management' => 'calendar' ];
$dashboard_icon = $dashboard_icons[ $block['module'] ] ?? 'activity';
?>
<div class="col-12 col-lg-<?php echo (int) $block['width']; ?> kerp-dashboard-column" style="min-width:0;">
	<section id="kerp-dashboard-<?php echo esc_attr( $block['id'] ); ?>" data-dashboard-module="<?php echo esc_attr( $block['module'] ); ?>" class="card card-bordered h-100 kerp-dashboard-block" style="min-width:0;overflow-wrap:anywhere;"<?php if ( $block['title'] !== '' ) : ?> aria-labelledby="<?php echo esc_attr( $heading_id ); ?>"<?php endif; ?>>
		<?php if ( $block['title'] !== '' ) : ?>
			<div class="card-inner border-bottom kerp-dashboard-heading">
				<span class="kerp-dashboard-icon" aria-hidden="true"><em class="icon ni ni-<?php echo esc_attr( $dashboard_icon ); ?>"></em></span>
				<h5 class="card-title mb-0" id="<?php echo esc_attr( $heading_id ); ?>"><?php echo esc_html( $block['title'] ); ?></h5>
			</div>
		<?php endif; ?>
		<div class="card-inner kerp-dashboard-block-content" style="min-width:0;"<?php if ( ! empty( $block['async'] ) ) : ?> data-dashboard-pending="1" aria-busy="true"<?php endif; ?>>
			<?php echo $content; // Trusted module template; escape dynamic data in the callback. ?>
		</div>
	</section>
</div>
