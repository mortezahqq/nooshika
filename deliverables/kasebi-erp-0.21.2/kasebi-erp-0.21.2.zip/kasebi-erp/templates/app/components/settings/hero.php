<?php

defined( 'ABSPATH' ) || exit;

$icon        = isset( $icon ) ? trim( (string) $icon ) : 'ni ni-setting icon';
$eyebrow     = isset( $eyebrow ) ? (string) $eyebrow : '';
$title       = isset( $title ) ? (string) $title : '';
$description = isset( $description ) ? (string) $description : '';
$stats       = isset( $stats ) && is_array( $stats ) ? $stats : [];
$actions     = isset( $actions ) && is_array( $actions ) ? $actions : [];
$class       = isset( $class ) ? trim( (string) $class ) : '';
?>
<div class="card card-bordered kerp-settings-hero<?php echo $class !== '' ? ' ' . esc_attr( $class ) : ''; ?>">
	<div class="card-inner">
		<div class="kerp-settings-hero__layout">
			<div class="kerp-settings-hero__intro">
				<span class="kerp-settings-hero__icon"><em class="<?php echo esc_attr( $icon ); ?>"></em></span>
				<div>
					<?php if ( $eyebrow !== '' ) : ?><span class="overline-title text-primary"><?php echo esc_html( $eyebrow ); ?></span><?php endif; ?>
					<?php if ( $title !== '' ) : ?><h4 class="title mb-1"><?php echo esc_html( $title ); ?></h4><?php endif; ?>
					<?php if ( $description !== '' ) : ?><p class="text-soft mb-0"><?php echo esc_html( $description ); ?></p><?php endif; ?>

					<?php if ( $actions ) : ?>
						<div class="d-flex align-center flex-wrap g-2 mt-3">
							<?php foreach ( $actions as $action ) : ?>
								<?php
								$action_label      = isset( $action['label'] ) ? (string) $action['label'] : '';
								$action_icon       = isset( $action['icon'] ) ? trim( (string) $action['icon'] ) : '';
								$action_href       = isset( $action['href'] ) ? (string) $action['href'] : '#';
								$action_class      = isset( $action['class'] ) ? trim( (string) $action['class'] ) : 'btn btn-sm btn-white btn-outline-light';
								$action_attributes = isset( $action['attributes'] ) && is_array( $action['attributes'] ) ? $action['attributes'] : [];
								?>
								<a href="<?php echo esc_url( $action_href ); ?>" class="<?php echo esc_attr( $action_class ); ?>"<?php foreach ( $action_attributes as $attribute => $value ) : ?> <?php echo esc_attr( sanitize_key( (string) $attribute ) ); ?>="<?php echo esc_attr( (string) $value ); ?>"<?php endforeach; ?>>
									<?php if ( $action_icon !== '' && empty( $action['icon_after'] ) ) : ?><em class="<?php echo esc_attr( $action_icon ); ?>"></em><?php endif; ?>
									<?php if ( $action_label !== '' ) : ?><span><?php echo esc_html( $action_label ); ?></span><?php endif; ?>
									<?php if ( $action_icon !== '' && ! empty( $action['icon_after'] ) ) : ?><em class="<?php echo esc_attr( $action_icon ); ?>"></em><?php endif; ?>
								</a>
							<?php endforeach; ?>
						</div>
					<?php endif; ?>
				</div>
			</div>

			<?php if ( $stats ) : ?>
				<div class="kerp-settings-hero__stats">
					<?php foreach ( $stats as $stat ) : ?>
						<?php
						$stat_label = isset( $stat['label'] ) ? (string) $stat['label'] : '';
						$stat_value = isset( $stat['value'] ) ? (string) $stat['value'] : '';
						$stat_tag   = isset( $stat['tag'] ) && $stat['tag'] === 'code' ? 'code' : 'strong';
						$stat_id    = isset( $stat['id'] ) ? sanitize_html_class( (string) $stat['id'] ) : '';
						$stat_class = isset( $stat['class'] ) ? trim( (string) $stat['class'] ) : '';
						?>
						<div class="kerp-settings-stat">
							<span><?php echo esc_html( $stat_label ); ?></span>
							<<?php echo esc_attr( $stat_tag ); ?><?php echo $stat_id !== '' ? ' id="' . esc_attr( $stat_id ) . '"' : ''; ?><?php echo $stat_class !== '' ? ' class="' . esc_attr( $stat_class ) . '"' : ''; ?>><?php echo ! empty( $stat['html'] ) ? wp_kses_post( $stat_value ) : esc_html( $stat_value ); ?></<?php echo esc_attr( $stat_tag ); ?>>
						</div>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</div>
	</div>
</div>
