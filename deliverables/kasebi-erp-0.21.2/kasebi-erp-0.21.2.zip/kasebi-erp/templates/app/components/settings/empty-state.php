<?php

defined( 'ABSPATH' ) || exit;

$icon        = isset( $icon ) ? trim( (string) $icon ) : 'icon ni ni-info';
$title       = isset( $title ) ? (string) $title : '';
$description = isset( $description ) ? (string) $description : '';
$class       = isset( $class ) ? trim( (string) $class ) : '';
$action      = isset( $action ) && is_array( $action ) ? $action : [];
?>
<div class="card card-bordered kerp-settings-empty-state<?php echo $class !== '' ? ' ' . esc_attr( $class ) : ''; ?>">
	<div class="card-inner">
		<span class="kerp-settings-empty-state__icon"><em class="<?php echo esc_attr( $icon ); ?>"></em></span>
		<?php if ( $title !== '' ) : ?><h5 class="title"><?php echo esc_html( $title ); ?></h5><?php endif; ?>
		<?php if ( $description !== '' ) : ?><p><?php echo esc_html( $description ); ?></p><?php endif; ?>
		<?php if ( $action ) : ?>
			<?php
			$action_tag        = isset( $action['tag'] ) && $action['tag'] === 'a' ? 'a' : 'button';
			$action_class      = isset( $action['class'] ) ? trim( (string) $action['class'] ) : 'btn btn-primary';
			$action_label      = isset( $action['label'] ) ? (string) $action['label'] : '';
			$action_icon       = isset( $action['icon'] ) ? trim( (string) $action['icon'] ) : '';
			$action_attributes = isset( $action['attributes'] ) && is_array( $action['attributes'] ) ? $action['attributes'] : [];
			?>
			<<?php echo esc_attr( $action_tag ); ?><?php echo $action_tag === 'button' ? ' type="button"' : ''; ?> class="<?php echo esc_attr( $action_class ); ?>"<?php foreach ( $action_attributes as $attribute => $value ) : ?> <?php echo esc_attr( sanitize_key( (string) $attribute ) ); ?>="<?php echo esc_attr( (string) $value ); ?>"<?php endforeach; ?>>
				<?php if ( $action_icon !== '' ) : ?><em class="<?php echo esc_attr( $action_icon ); ?>"></em><?php endif; ?>
				<?php if ( $action_label !== '' ) : ?><span><?php echo esc_html( $action_label ); ?></span><?php endif; ?>
			</<?php echo esc_attr( $action_tag ); ?>>
		<?php endif; ?>
	</div>
</div>
