<?php

defined( 'ABSPATH' ) || exit;

$column_class            = isset( $column_class ) ? trim( (string) $column_class ) : 'col-md-6 col-xl-4';
$class                   = isset( $class ) ? trim( (string) $class ) : '';
$icon                    = isset( $icon ) ? trim( (string) $icon ) : 'ni ni-file-text icon';
$icon_class              = isset( $icon_class ) ? trim( (string) $icon_class ) : 'bg-primary-dim text-primary';
$label                   = isset( $label ) ? (string) $label : '';
$key                     = isset( $key ) ? (string) $key : '';
$active                  = ! empty( $active );
$status_label            = isset( $status_label ) ? trim( (string) $status_label ) : '';
$status_active           = isset( $status_active ) ? (bool) $status_active : $active;
$show_status             = ! isset( $show_status ) || (bool) $show_status;
$description             = isset( $description ) ? (string) $description : '';
$description_placeholder = isset( $description_placeholder ) ? (string) $description_placeholder : '';
$actions                 = isset( $actions ) && is_array( $actions ) ? $actions : [];
$meta                    = isset( $meta ) && is_array( $meta ) ? $meta : [];
$tags                    = isset( $tags ) && is_array( $tags ) ? $tags : [];
$footer                  = isset( $footer ) && is_array( $footer ) ? $footer : [];

if ( $status_label === '' ) {
	$status_label = $active ? __( 'فعال', 'kasebi-erp' ) : __( 'غیرفعال', 'kasebi-erp' );
}
?>
<div class="<?php echo esc_attr( $column_class ); ?>">
	<div class="kerp-settings-item-card<?php echo $class !== '' ? ' ' . esc_attr( $class ) : ''; ?><?php echo $active ? '' : ' is-inactive'; ?>">
		<div class="kerp-settings-item-card__main">
			<div class="kerp-settings-item-card__head">
				<div class="kerp-settings-item-card__identity">
					<span class="kerp-settings-item-card__icon <?php echo esc_attr( $icon_class ); ?>"><em class="<?php echo esc_attr( $icon ); ?>"></em></span>
					<div class="kerp-settings-item-card__title">
						<div class="kerp-settings-item-card__title-row">
							<h6><?php echo esc_html( $label ); ?></h6>
							<?php if ( $show_status ) : ?>
								<span class="kerp-settings-item-card__status <?php echo $status_active ? 'is-active' : 'is-inactive'; ?>"><?php echo esc_html( $status_label ); ?></span>
							<?php endif; ?>
						</div>
						<?php if ( $key !== '' ) : ?><span class="kerp-settings-item-card__key"><?php echo esc_html( $key ); ?></span><?php endif; ?>
					</div>
				</div>
				<?php if ( $actions ) : ?>
					<div class="dropdown">
						<a href="#" class="btn btn-sm btn-icon btn-trigger dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false"><em class="ni ni-more-h icon"></em></a>
						<div class="dropdown-menu dropdown-menu-end">
							<ul class="link-list-opt no-bdr">
								<?php foreach ( $actions as $action ) : ?>
									<?php
									$action_label      = isset( $action['label'] ) ? (string) $action['label'] : '';
									$action_icon       = isset( $action['icon'] ) ? trim( (string) $action['icon'] ) : '';
									$action_class      = isset( $action['class'] ) ? trim( (string) $action['class'] ) : '';
									$action_href       = isset( $action['href'] ) ? (string) $action['href'] : '#';
									$action_attributes = isset( $action['attributes'] ) && is_array( $action['attributes'] ) ? $action['attributes'] : [];
									?>
									<?php if ( ! empty( $action['divider_before'] ) ) : ?><li class="divider"></li><?php endif; ?>
									<li>
										<a href="<?php echo esc_url( $action_href ); ?>"<?php echo $action_class !== '' ? ' class="' . esc_attr( $action_class ) . '"' : ''; ?><?php foreach ( $action_attributes as $attribute => $value ) : ?> <?php echo esc_attr( sanitize_key( (string) $attribute ) ); ?>="<?php echo esc_attr( (string) $value ); ?>"<?php endforeach; ?>>
											<?php if ( $action_icon !== '' ) : ?><em class="<?php echo esc_attr( $action_icon ); ?>"></em><?php endif; ?>
											<?php if ( $action_label !== '' ) : ?><span><?php echo esc_html( $action_label ); ?></span><?php endif; ?>
										</a>
									</li>
								<?php endforeach; ?>
							</ul>
						</div>
					</div>
				<?php endif; ?>
			</div>

			<?php if ( $description !== '' ) : ?>
				<p class="kerp-settings-item-card__description"><?php echo esc_html( $description ); ?></p>
			<?php elseif ( $description_placeholder !== '' ) : ?>
				<p class="kerp-settings-item-card__description is-placeholder"><?php echo esc_html( $description_placeholder ); ?></p>
			<?php endif; ?>

			<?php if ( $meta ) : ?>
				<div class="kerp-settings-item-card__meta-list">
					<?php foreach ( $meta as $item ) : ?>
						<span>
							<?php if ( ! empty( $item['icon'] ) ) : ?><em class="<?php echo esc_attr( (string) $item['icon'] ); ?>"></em><?php endif; ?>
							<small><?php echo esc_html( (string) ( $item['label'] ?? '' ) ); ?></small>
							<strong><?php echo esc_html( (string) ( $item['value'] ?? '' ) ); ?></strong>
						</span>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>

			<?php if ( $tags ) : ?>
				<div class="kerp-settings-item-card__tags">
					<?php foreach ( $tags as $tag ) : ?><span><?php echo esc_html( (string) $tag ); ?></span><?php endforeach; ?>
				</div>
			<?php endif; ?>
		</div>

		<?php if ( $footer ) : ?>
			<div class="kerp-settings-item-card__footer">
				<?php foreach ( $footer as $item ) : ?>
					<?php
					$item_type       = isset( $item['type'] ) ? (string) $item['type'] : 'text';
					$item_class      = isset( $item['class'] ) ? trim( (string) $item['class'] ) : '';
					$item_attributes = isset( $item['attributes'] ) && is_array( $item['attributes'] ) ? $item['attributes'] : [];
					?>
					<?php if ( $item_type === 'color' && ! empty( $item['value'] ) ) : ?>
						<span class="kerp-settings-item-card__color"><input type="color" value="<?php echo esc_attr( (string) $item['value'] ); ?>" disabled aria-label="<?php esc_attr_e( 'رنگ', 'kasebi-erp' ); ?>"><code><?php echo esc_html( (string) $item['value'] ); ?></code></span>
					<?php elseif ( $item_type === 'resource' ) : ?>
						<div class="kerp-settings-item-card__resource d-flex align-center justify-between w-100 g-2">
							<?php if ( ! empty( $item['href'] ) ) : ?><a href="<?php echo esc_url( (string) $item['href'] ); ?>" target="_blank" rel="noopener noreferrer"><?php else : ?><span><?php endif; ?>
								<?php if ( ! empty( $item['icon'] ) ) : ?><em class="<?php echo esc_attr( (string) $item['icon'] ); ?>"></em><?php endif; ?><?php echo esc_html( (string) ( $item['text'] ?? '' ) ); ?>
							<?php if ( ! empty( $item['href'] ) ) : ?></a><?php else : ?></span><?php endif; ?>
							<?php if ( ! empty( $item['actions'] ) ) : ?>
								<span class="kerp-settings-item-card__resource-actions d-inline-flex align-center g-1 flex-shrink-0">
									<?php foreach ( (array) $item['actions'] as $resource_action ) : ?>
										<?php $resource_attributes = isset( $resource_action['attributes'] ) && is_array( $resource_action['attributes'] ) ? $resource_action['attributes'] : []; ?>
										<a href="<?php echo esc_url( (string) ( $resource_attributes['href'] ?? '#' ) ); ?>" class="<?php echo esc_attr( (string) ( $resource_action['class'] ?? '' ) ); ?>" title="<?php echo esc_attr( (string) ( $resource_action['label'] ?? '' ) ); ?>"<?php foreach ( $resource_attributes as $attribute => $value ) : ?><?php if ( $attribute === 'href' ) { continue; } ?> <?php echo esc_attr( sanitize_key( (string) $attribute ) ); ?>="<?php echo esc_attr( (string) $value ); ?>"<?php endforeach; ?>><?php if ( ! empty( $resource_action['icon'] ) ) : ?><em class="<?php echo esc_attr( (string) $resource_action['icon'] ); ?>"></em><?php endif; ?><span><?php echo esc_html( (string) ( $resource_action['label'] ?? '' ) ); ?></span></a>
									<?php endforeach; ?>
								</span>
							<?php endif; ?>
						</div>
					<?php elseif ( $item_type === 'link' ) : ?>
						<a href="<?php echo esc_url( (string) ( $item['href'] ?? '#' ) ); ?>"<?php echo $item_class !== '' ? ' class="' . esc_attr( $item_class ) . '"' : ''; ?><?php foreach ( $item_attributes as $attribute => $value ) : ?> <?php echo esc_attr( sanitize_key( (string) $attribute ) ); ?>="<?php echo esc_attr( (string) $value ); ?>"<?php endforeach; ?>>
							<?php if ( ! empty( $item['icon'] ) && empty( $item['icon_after'] ) ) : ?><em class="<?php echo esc_attr( (string) $item['icon'] ); ?>"></em><?php endif; ?><?php echo esc_html( (string) ( $item['text'] ?? '' ) ); ?><?php if ( ! empty( $item['icon'] ) && ! empty( $item['icon_after'] ) ) : ?><em class="<?php echo esc_attr( (string) $item['icon'] ); ?>"></em><?php endif; ?>
						</a>
					<?php else : ?>
						<span<?php echo $item_class !== '' ? ' class="' . esc_attr( $item_class ) . '"' : ''; ?>><?php if ( ! empty( $item['icon'] ) ) : ?><em class="<?php echo esc_attr( (string) $item['icon'] ); ?>"></em><?php endif; ?><?php echo esc_html( (string) ( $item['text'] ?? '' ) ); ?></span>
					<?php endif; ?>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>
	</div>
</div>
