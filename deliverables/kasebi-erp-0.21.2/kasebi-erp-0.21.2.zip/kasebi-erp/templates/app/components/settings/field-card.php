<?php

defined( 'ABSPATH' ) || exit;

$column_class = (string) ( $column_class ?? 'col-md-6 col-xl-4' );
$icon         = trim( (string) ( $icon ?? 'icon ni ni-text' ) );
$label        = (string) ( $label ?? '' );
$type_label   = (string) ( $type_label ?? '' );
$key          = (string) ( $key ?? '' );
$active       = ! empty( $active );
$description  = (string) ( $description ?? '' );
$usage        = is_array( $usage ?? NULL ) ? $usage : [];
$options      = is_array( $options ?? NULL ) ? $options : [];
$column_label = (string) ( $column_label ?? '' );
$order        = (int) ( $order ?? 100 );
$placeholder  = (string) ( $placeholder ?? '' );
$actions      = is_array( $actions ?? NULL ) ? $actions : [];
?>
<div class="<?php echo esc_attr( $column_class ); ?>">
	<div class="card card-bordered h-100 kerp-settings-field-card<?php echo $active ? '' : ' is-inactive'; ?>">
		<div class="kerp-settings-field-card__accent"></div>
		<div class="card-inner">
			<div class="kerp-settings-field-card__head">
				<div class="kerp-settings-field-card__identity">
					<span class="kerp-settings-field-card__icon"><em class="<?php echo esc_attr( $icon ); ?>"></em></span>
					<div class="kerp-settings-field-card__title">
						<div class="kerp-settings-field-card__title-row"><h6 class="title mb-0"><?php echo esc_html( $label ); ?></h6><span class="badge badge-dim bg-outline-primary"><?php echo esc_html( $type_label ); ?></span></div>
						<code><?php echo esc_html( $key ); ?></code>
					</div>
				</div>
				<?php if ( $actions ) : ?>
					<div class="dropdown">
						<a href="#" class="btn btn-sm btn-icon btn-trigger dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false"><em class="icon ni ni-more-h"></em></a>
						<div class="dropdown-menu dropdown-menu-end"><ul class="link-list-opt no-bdr">
							<?php foreach ( $actions as $action ) : ?>
								<?php if ( ! empty( $action['divider_before'] ) ) : ?><li class="divider"></li><?php endif; ?>
								<li><a href="<?php echo esc_url( (string) ( $action['href'] ?? '#' ) ); ?>" class="<?php echo esc_attr( (string) ( $action['class'] ?? '' ) ); ?>"<?php foreach ( (array) ( $action['attributes'] ?? [] ) as $attribute => $value ) : ?> <?php echo esc_attr( $attribute ); ?>="<?php echo esc_attr( (string) $value ); ?>"<?php endforeach; ?>><?php if ( ! empty( $action['icon'] ) ) : ?><em class="<?php echo esc_attr( (string) $action['icon'] ); ?>"></em><?php endif; ?><span><?php echo esc_html( (string) ( $action['label'] ?? '' ) ); ?></span></a></li>
							<?php endforeach; ?>
						</ul></div>
					</div>
				<?php endif; ?>
			</div>
			<div class="kerp-settings-field-card__description"><p<?php echo $description === '' ? ' class="is-empty"' : ''; ?>><?php echo esc_html( $description !== '' ? $description : __( 'برای این فیلد توضیحی ثبت نشده است.', 'kasebi-erp' ) ); ?></p></div>
			<div class="kerp-settings-field-card__section">
				<div class="kerp-settings-field-card__section-head"><span><?php esc_html_e( 'محل استفاده', 'kasebi-erp' ); ?></span><span class="badge badge-dim <?php echo $active ? 'bg-success' : 'bg-light'; ?>"><?php echo $active ? esc_html__( 'فعال', 'kasebi-erp' ) : esc_html__( 'غیرفعال', 'kasebi-erp' ); ?></span></div>
				<div class="kerp-settings-field-card__usage">
					<?php if ( $usage ) : foreach ( $usage as $item ) : ?><span<?php echo ! empty( $item['muted'] ) ? ' class="is-muted"' : ''; ?>><?php if ( ! empty( $item['icon'] ) ) : ?><em class="<?php echo esc_attr( (string) $item['icon'] ); ?>"></em><?php endif; ?><?php echo esc_html( (string) ( $item['label'] ?? '' ) ); ?></span><?php endforeach; else : ?><span class="is-muted"><em class="icon ni ni-eye-off"></em><?php esc_html_e( 'بدون محل نمایش', 'kasebi-erp' ); ?></span><?php endif; ?>
				</div>
			</div>
			<?php if ( $options ) : ?>
				<div class="kerp-settings-field-card__section">
					<div class="kerp-settings-field-card__section-head"><span><?php esc_html_e( 'گزینه‌ها', 'kasebi-erp' ); ?></span><strong><?php echo esc_html( number_format_i18n( count( $options ) ) ); ?></strong></div>
					<div class="kerp-settings-field-card__options">
						<?php foreach ( array_slice( $options, 0, 4, TRUE ) as $option_label ) : ?><span class="badge badge-dim bg-light"><?php echo esc_html( (string) $option_label ); ?></span><?php endforeach; ?>
						<?php if ( count( $options ) > 4 ) : ?><span class="badge badge-dim bg-primary">+<?php echo esc_html( number_format_i18n( count( $options ) - 4 ) ); ?></span><?php endif; ?>
					</div>
				</div>
			<?php endif; ?>
			<div class="kerp-settings-field-card__meta">
				<span><em class="icon ni ni-grid-alt"></em><?php echo esc_html( $column_label ); ?></span>
				<span><em class="icon ni ni-sort"></em><?php printf( esc_html__( 'ترتیب %s', 'kasebi-erp' ), esc_html( number_format_i18n( $order ) ) ); ?></span>
				<?php if ( $placeholder !== '' ) : ?><span class="kerp-settings-field-card__placeholder"><em class="icon ni ni-text"></em><?php echo esc_html( $placeholder ); ?></span><?php endif; ?>
			</div>
		</div>
	</div>
</div>
