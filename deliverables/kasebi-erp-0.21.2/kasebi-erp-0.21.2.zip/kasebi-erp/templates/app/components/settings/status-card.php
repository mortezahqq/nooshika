<?php

defined( 'ABSPATH' ) || exit;

$column_class = (string) ( $column_class ?? 'col-md-6 col-xl-4' );
$class        = trim( (string) ( $class ?? '' ) );
$color        = sanitize_key( (string) ( $color ?? 'primary' ) ) ?: 'primary';
$icon         = trim( (string) ( $icon ?? 'icon ni ni-flag' ) );
$label        = (string) ( $label ?? '' );
$key          = (string) ( $key ?? '' );
$active       = ! empty( $active );
$actions      = is_array( $actions ?? NULL ) ? $actions : [];
$meta         = is_array( $meta ?? NULL ) ? $meta : [];
$transitions  = is_array( $transitions ?? NULL ) ? $transitions : [];
$flow_label   = (string) ( $flow_label ?? __( 'مسیرهای مجاز بعدی', 'kasebi-erp' ) );
$empty_label  = (string) ( $empty_label ?? __( 'پایان مسیر', 'kasebi-erp' ) );
$show_state   = ! isset( $show_state ) || (bool) $show_state;
$action_mode  = (string) ( $action_mode ?? 'dropdown' );
?>
<div class="<?php echo esc_attr( $column_class ); ?>">
	<div class="card card-bordered h-100 kerp-settings-status-card<?php echo $active ? '' : ' is-inactive'; ?><?php echo $class !== '' ? ' ' . esc_attr( $class ) : ''; ?>">
		<div class="kerp-settings-status-card__accent bg-<?php echo esc_attr( $color ); ?>"></div>
		<div class="card-inner">
			<div class="kerp-settings-status-card__head">
				<div class="kerp-settings-status-card__identity">
					<span class="kerp-settings-status-card__icon bg-<?php echo esc_attr( $color ); ?>-dim text-<?php echo esc_attr( $color ); ?>"><em class="<?php echo esc_attr( $icon ); ?>"></em></span>
					<div>
						<div class="kerp-settings-status-card__title-row">
							<h6 class="title mb-0"><?php echo esc_html( $label ); ?></h6>
							<?php if ( $show_state ) : ?><span class="kerp-settings-status-card__state <?php echo $active ? 'is-active' : 'is-inactive'; ?>"><?php echo $active ? esc_html__( 'فعال', 'kasebi-erp' ) : esc_html__( 'غیرفعال', 'kasebi-erp' ); ?></span><?php endif; ?>
						</div>
						<code><?php echo esc_html( $key ); ?></code>
					</div>
				</div>
				<?php if ( $actions && $action_mode === 'single' ) : ?>
					<?php $action = reset( $actions ); ?>
					<a href="<?php echo esc_url( (string) ( $action['href'] ?? '#' ) ); ?>" class="<?php echo esc_attr( (string) ( $action['class'] ?? 'btn btn-sm btn-icon btn-trigger' ) ); ?>"<?php foreach ( (array) ( $action['attributes'] ?? [] ) as $attribute => $value ) : ?> <?php echo esc_attr( $attribute ); ?>="<?php echo esc_attr( (string) $value ); ?>"<?php endforeach; ?>><?php if ( ! empty( $action['icon'] ) ) : ?><em class="<?php echo esc_attr( (string) $action['icon'] ); ?>"></em><?php endif; ?></a>
				<?php elseif ( $actions ) : ?>
					<div class="dropdown">
						<a href="#" class="btn btn-sm btn-icon btn-trigger dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false"><em class="icon ni ni-more-h"></em></a>
						<div class="dropdown-menu dropdown-menu-end"><ul class="link-list-opt no-bdr">
							<?php foreach ( $actions as $action ) : ?>
								<?php if ( ! empty( $action['divider_before'] ) ) : ?><li class="divider"></li><?php endif; ?>
								<li><a href="<?php echo esc_url( (string) ( $action['href'] ?? '#' ) ); ?>" class="<?php echo esc_attr( (string) ( $action['class'] ?? '' ) ); ?>"<?php foreach ( (array) ( $action['attributes'] ?? [] ) as $attribute => $value ) : ?> <?php echo esc_attr( $attribute ); ?>="<?php echo esc_attr( (string) $value ); ?>"<?php endforeach; ?>><?php if ( ! empty( $action['icon'] ) ) : ?><em class="<?php echo esc_attr( (string) $action['icon'] ); ?>"></em><?php endif; ?><span><?php echo esc_html( (string) ( $action['label'] ?? '' ) ); ?></span></a></li>
							<?php endforeach; ?>
						</ul></div>
					</div>
				<?php endif; ?>
			</div>
			<?php if ( $meta ) : ?><div class="kerp-settings-status-card__meta"><?php foreach ( $meta as $item ) : ?><span class="<?php echo esc_attr( (string) ( $item['class'] ?? '' ) ); ?>"><?php if ( ! empty( $item['icon'] ) ) : ?><em class="<?php echo esc_attr( (string) $item['icon'] ); ?>"></em><?php endif; ?><?php echo esc_html( (string) ( $item['text'] ?? '' ) ); ?></span><?php endforeach; ?></div><?php endif; ?>
			<div class="kerp-settings-status-flow">
				<div class="kerp-settings-status-flow__head"><span><?php echo esc_html( $flow_label ); ?></span><strong><?php echo esc_html( number_format_i18n( count( $transitions ) ) ); ?></strong></div>
				<div class="kerp-settings-status-flow__items">
					<?php if ( ! $transitions ) : ?><span class="kerp-settings-status-flow__empty"><em class="icon ni ni-check-circle"></em><?php echo esc_html( $empty_label ); ?></span><?php else : foreach ( $transitions as $transition ) : ?><span class="badge bg-light"><?php echo esc_html( (string) $transition ); ?></span><?php endforeach; endif; ?>
				</div>
			</div>
		</div>
	</div>
</div>
