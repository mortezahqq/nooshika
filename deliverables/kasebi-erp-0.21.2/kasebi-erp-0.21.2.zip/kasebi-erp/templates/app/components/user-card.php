<?php
/**
 * @var int  $user_id
 * @var bool $show_avatar
 * @var bool $show_phone
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$show_avatar = $show_avatar ?? TRUE;
$show_phone = $show_phone ?? FALSE;
$avatar = $show_avatar && get_user_meta( $user_id, 'nooshika_user_avatar_url', TRUE ) && function_exists( 'nooshika_get_user_avatar' ) ? nooshika_get_user_avatar( $user_id ) : '';
$first_name = get_user_name_by_id( $user_id );
$gender     = get_user_meta( $user_id, 'user_gender', TRUE );
$class      = $show_phone ? 'sm' : 'xs';
?>
<div class="user-card">
    <?php if ( $show_avatar ) : ?>
    <div class="user-avatar fs-18px <?php echo $class; ?> bg-primary">
		<?php
		if ( $avatar ) { echo '<img class="rounded-circle" src="' . esc_url( $avatar ) . '" alt="">'; } elseif ( $gender == 'female' ) {
			echo '<i class="uik-r fa-woman-head"></i>';
		} else {
			echo '<i class="uik-r fa-smile"></i>';
		}
		?>
    </div>
    <?php endif; ?>
    <div class="user-info">
        <span class="tb-lead"><?php echo $first_name; ?></span>
		<?php
		if ( $show_phone ) {
			$phone = get_user_meta( $user_id, 'nooshika_phone_num', TRUE );
			?>
            <span class="sub-text"><?php echo $phone; ?></span>
			<?php
		}
		?>
    </div>
</div>
