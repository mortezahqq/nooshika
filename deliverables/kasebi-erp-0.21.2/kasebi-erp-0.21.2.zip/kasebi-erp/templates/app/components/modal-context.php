<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * @var string $id
 * @var string $title
 * @var string $class
 * @var string $body
 * @var string $footer
 */

$class = $class ?? 'modal-lg';
?>

<div class="modal fade zoom" id="<?php echo esc_attr( $id ); ?>" tabindex="-1">
    <div class="modal-dialog <?php echo esc_attr( $class ); ?>" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
					<?php echo esc_html( $title ?? '' ); ?>
                </h5>
                <a href="#" class="close" data-bs-dismiss="modal" aria-label="بستن">
                    <em class="icon ni ni-cross-sm"></em>
                </a>
            </div>
            <div class="modal-body bg-white">
				<?php echo $body ?? ''; ?>
            </div>
			<?php if ( ! empty( $footer ) ) : ?>
                <div class="modal-footer">
					<?php echo $footer; ?>
                </div>
			<?php endif; ?>
        </div>
    </div>
</div>