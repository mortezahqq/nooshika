<?php
?>
    <div class="nk-footer">
        <div class="container-xl wide-xl">
            <div class="nk-footer-wrap">
                <div class="nk-footer-copyright">طراحی و توسعه توسط <a href="https://kasebi.co/"
                                                                       target="_blank">کاسبی</a>
                </div>
                <div class="nk-footer-links english_number">
                    Copyright 2017-<?php echo date( "Y" ); ?>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="kerpPublicContentModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"></h5>
                    <a href="#" class="close" data-bs-dismiss="modal"
                       aria-label="<?php esc_attr_e( 'بستن', 'kasebi-erp' ); ?>">
                        <em class="icon ni ni-cross"></em>
                    </a>
                </div>
                <div class="modal-body">
                    <div class="kerp-public-modal-content"></div>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="kerpDynamicModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"></h5>
                    <a href="#"
                       class="close"
                       data-bs-dismiss="modal"
                       aria-label="<?php esc_attr_e( 'بستن', 'kasebi-erp' ); ?>">
                        <em class="icon ni ni-cross"></em>
                    </a>
                </div>
                <div class="modal-body kerp-dynamic-modal-content"></div>
            </div>
        </div>
    </div>
<?php
do_action( 'kerp_footer_template' );
