<?php

defined( 'ABSPATH' ) || exit;

$dashboard_url = home_url( '/erp/' );

?>

<div class="nk-block nk-block-middle wide-xs mx-auto">
    <div class="nk-block-content text-center">

        <div class="mb-4">
            <em
                class="icon ni ni-alert-circle text-primary"
                style="font-size: 72px;"
            ></em>
        </div>

        <h2 class="nk-error-title">
			<?php esc_html_e( 'صفحه مورد نظر پیدا نشد', 'kasebi-erp' ); ?>
        </h2>

        <p class="nk-error-text">
			<?php esc_html_e(
				'صفحه‌ای که به دنبال آن هستید وجود ندارد، حذف شده یا آدرس آن تغییر کرده است.',
				'kasebi-erp'
			); ?>
        </p>

        <div class="mt-4">
            <a
                href="<?php echo esc_url( $dashboard_url ); ?>"
                class="btn btn-lg btn-primary"
            >
                <em class="icon ni ni-home"></em>

                <span>
					<?php esc_html_e( 'بازگشت به داشبورد', 'kasebi-erp' ); ?>
				</span>
            </a>
        </div>

    </div>
</div>