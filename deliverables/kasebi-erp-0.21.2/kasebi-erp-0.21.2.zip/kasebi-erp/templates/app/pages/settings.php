<?php

defined( 'ABSPATH' ) || exit;

$user_id = get_current_user_id();
$user    = get_userdata( $user_id );

if ( ! $user instanceof WP_User ) {
	return;
}

$page_route           = '/erp/settings/';
$phone_meta_key       = KERP_Helpers_Phone::get_meta_key();
$phone                = (string) get_user_meta( $user_id, $phone_meta_key, TRUE );
$phone_display        = $phone !== '' ? KERP_Helpers_Phone::with_zero( $phone ) : '';
$user_name            = KERP_Helpers_User::get_display_name( $user_id, TRUE, TRUE );
$registered_timestamp = strtotime( (string) $user->user_registered );
$registered_date      = $registered_timestamp ? date_i18n( 'j F Y', $registered_timestamp ) : '-';
$avatar_url           = esc_url( (string) get_user_meta( $user_id, 'nooshika_user_avatar_url', TRUE ) );

if ( $avatar_url === '' ) {
	$avatar_url = esc_url( get_avatar_url( $user_id, [ 'size' => 160 ] ) );
}

$profile_fields = [
	[
		'id'          => 'kerp-settings-comment-badge',
		'name'        => 'profile[comment_badge]',
		'label'       => __( 'عنوان نمایشی در گفت‌وگوی برنامه', 'kasebi-erp' ),
		'description' => __( 'مثلاً معاونت مجموعه یا مشاور ارشد؛ این عنوان کنار نام شما در کامنت‌های پنل کاربر نمایش داده می‌شود.', 'kasebi-erp' ),
		'type'        => 'text',
		'class'       => 'col-12',
		'value'       => (string) get_user_meta( $user_id, 'kerp_comment_badge', TRUE ),
	],
	[
		'id'       => 'kerp-settings-first-name',
		'name'     => 'profile[first_name]',
		'label'    => __( 'نام', 'kasebi-erp' ),
		'type'     => 'text',
		'class'    => 'col-md-6',
		'value'    => (string) $user->first_name,
		'required' => TRUE,
	],
	[
		'id'       => 'kerp-settings-last-name',
		'name'     => 'profile[last_name]',
		'label'    => __( 'نام خانوادگی', 'kasebi-erp' ),
		'type'     => 'text',
		'class'    => 'col-md-6',
		'value'    => (string) $user->last_name,
		'required' => TRUE,
	],
	[
		'id'          => 'kerp-settings-email',
		'name'        => 'profile[email]',
		'label'       => __( 'ایمیل', 'kasebi-erp' ),
		'description' => __( 'ایمیل اصلی حساب وردپرس با این مقدار به‌روزرسانی می‌شود.', 'kasebi-erp' ),
		'type'        => 'email',
		'class'       => 'col-md-6',
		'value'       => (string) $user->user_email,
	],
	[
		'id'          => 'kerp-settings-phone',
		'name'        => 'profile[phone]',
		'label'       => __( 'شماره موبایل', 'kasebi-erp' ),
		'description' => __( 'شماره تماس اصلی این حساب کاربری.', 'kasebi-erp' ),
		'type'        => 'text',
		'class'       => 'col-md-6',
		'input_class' => 'ltr',
		'value'       => $phone_display,
	],
];

$password_fields = [
	[
		'id'           => 'kerp-settings-new-password',
		'name'         => 'profile[new_password]',
		'label'        => __( 'رمز عبور جدید', 'kasebi-erp' ),
		'description'  => __( 'اگر قصد تغییر رمز عبور را ندارید، این فیلد را خالی بگذارید.', 'kasebi-erp' ),
		'type'         => 'password',
		'class'        => 'col-md-6',
		'value'        => '',
		'autocomplete' => 'new-password',
	],
	[
		'id'           => 'kerp-settings-confirm-password',
		'name'         => 'profile[confirm_password]',
		'label'        => __( 'تکرار رمز عبور جدید', 'kasebi-erp' ),
		'description'  => __( 'فقط در صورت تغییر رمز عبور، مقدار بالا را دوباره وارد کنید.', 'kasebi-erp' ),
		'type'         => 'password',
		'class'        => 'col-md-6',
		'value'        => '',
		'autocomplete' => 'new-password',
	],
];

$avatar_field = [
	'id'          => 'new_profile_image',
	'name'        => 'image',
	'type'        => 'hidden',
	'input_class' => 'no_clear',
	'value'       => '',
	'required'    => TRUE,
];
?>
<div class="kerp-account-settings">
    <form class="modal_form" data-action="settings_save_profile" data-page="<?php echo esc_attr( $page_route ); ?>">
        <div class="nk-block-head nk-block-head-sm">
            <div class="nk-block-between g-3">
                <div class="nk-block-head-content">
                    <h3 class="nk-block-title page-title"><?php esc_html_e( 'حساب کاربری', 'kasebi-erp' ); ?></h3>
                    <div class="nk-block-des text-soft">
                        <p><?php esc_html_e( 'اطلاعات شخصی، راه‌های ارتباطی و امنیت حساب خود را مدیریت کنید.', 'kasebi-erp' ); ?></p>
                    </div>
                </div>
                <div class="nk-block-head-content">
                    <button type="button" class="btn btn-primary submit_modal_form">
                        <em class="icon ni ni-save"></em>
                        <span><?php esc_html_e( 'ذخیره تغییرات', 'kasebi-erp' ); ?></span>
                    </button>
                </div>
            </div>
        </div>

        <div class="nk-block">
			<?php
			KERP_Helpers_Template::render_template(
				'app/components/settings/hero.php',
				[
					'icon'        => 'icon ni ni-user-circle',
					'eyebrow'     => __( 'حساب من', 'kasebi-erp' ),
					'title'       => $user_name,
					'description' => __( 'اطلاعات پایه این حساب در بخش‌های مختلف ERP برای شناسایی شما استفاده می‌شود.', 'kasebi-erp' ),
					'stats'       => [
						[
							'label' => __( 'نام کاربری', 'kasebi-erp' ),
							'value' => (string) $user->user_login,
							'tag'   => 'code',
						],
						[
							'label' => __( 'شناسه کاربر', 'kasebi-erp' ),
							'value' => number_format_i18n( $user_id ),
						],
						[
							'label' => __( 'تاریخ عضویت', 'kasebi-erp' ),
							'value' => $registered_date,
						],
					],
				]
			);
			?>
        </div>

        <div class="nk-block">
            <div class="row g-gs">
                <div class="col-xl-4">
                    <div class="card card-bordered h-100 kerp-account-avatar-card">
                        <div class="card-inner border-bottom">
                            <div class="card-title-group">
                                <div class="card-title">
                                    <h5 class="title"><em
                                            class="icon ni ni-camera me-1"></em><?php esc_html_e( 'تصویر پروفایل', 'kasebi-erp' ); ?>
                                    </h5>
                                    <p class="text-soft mb-0"><?php esc_html_e( 'تصویر نمایشی حساب کاربری خود را تغییر دهید.', 'kasebi-erp' ); ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="card-inner">
                            <div class="kerp-account-avatar-preview">
                                <img src="<?php echo esc_url( $avatar_url ); ?>"
                                     alt="<?php echo esc_attr( $user_name ); ?>">
                            </div>
                            <div class="text-center mt-3">
                                <strong class="d-block"><?php echo esc_html( $user_name ); ?></strong>
								<?php if ( $user->user_email !== '' ) : ?><span
                                    class="text-soft small"><?php echo esc_html( $user->user_email ); ?></span><?php endif; ?>
                            </div>
                            <div class="text-center mt-4">
                                <button type="button" class="btn btn-outline-primary" data-bs-toggle="modal"
                                        data-bs-target="#crop">
                                    <em class="icon ni ni-camera-fill"></em>
                                    <span><?php esc_html_e( 'تغییر تصویر پروفایل', 'kasebi-erp' ); ?></span>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xl-8">
                    <div class="card card-bordered h-100">
                        <div class="card-inner border-bottom">
                            <div class="card-title-group">
                                <div class="card-title">
                                    <h5 class="title"><em
                                            class="icon ni ni-user me-1"></em><?php esc_html_e( 'اطلاعات شخصی', 'kasebi-erp' ); ?>
                                    </h5>
                                    <p class="text-soft mb-0"><?php esc_html_e( 'نام، اطلاعات تماس و مشخصات پایه حساب خود را ویرایش کنید.', 'kasebi-erp' ); ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="card-inner">
                            <div class="row g-4">
								<?php foreach ( $profile_fields as $field ) : ?>
									<?php KERP_Helpers_Template::render_template( 'app/components/fields/' . sanitize_key( (string) $field['type'] ) . '.php', [ 'field' => $field ] ); ?>
								<?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="nk-block">
            <div class="card card-bordered">
                <div class="card-inner border-bottom">
                    <div class="card-title-group">
                        <div class="card-title">
                            <h5 class="title"><em
                                    class="icon ni ni-lock-alt me-1"></em><?php esc_html_e( 'تغییر رمز عبور', 'kasebi-erp' ); ?>
                            </h5>
                            <p class="text-soft mb-0"><?php esc_html_e( 'این بخش اختیاری است؛ اگر هر دو فیلد خالی باشند رمز عبور فعلی بدون تغییر باقی می‌ماند.', 'kasebi-erp' ); ?></p>
                        </div>
                    </div>
                </div>
                <div class="card-inner">
                    <div class="row g-4">
						<?php foreach ( $password_fields as $field ) : ?>
							<?php KERP_Helpers_Template::render_template( 'app/components/fields/password.php', [ 'field' => $field ] ); ?>
						<?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>

<div class="modal fade zoom" id="crop">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><?php esc_html_e( 'تنظیم تصویر پروفایل', 'kasebi-erp' ); ?></h5>
                <a href="#" class="close" data-bs-dismiss="modal"
                   aria-label="<?php esc_attr_e( 'بستن', 'kasebi-erp' ); ?>"><em class="icon ni ni-cross"></em></a>
            </div>
            <div class="modal-body">
                <form action="#" class="modal_form" data-action="change_user_profile_image"
                      data-page="<?php echo esc_attr( $page_route ); ?>">
                    <input type="hidden" class="no_clear" value="<?php echo $user_id; ?>" data-for="id">
                    <input type="hidden" class="no_clear" value="<?php echo $page_route; ?>" data-for="page">
                    <div class="row g-gs">
                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label"
                                       for="new_profile_image"><?php esc_html_e( 'انتخاب تصویر', 'kasebi-erp' ); ?></label>
                                <div class="upload-zone" data-target="#new_profile_image"
                                     data-action="handle_file_upload_avatar" data-max-files="1">
                                    <div class="dz-message" data-dz-message>
                                        <span
                                            class="dz-message-text"><?php esc_html_e( 'بکشید و رها کنید', 'kasebi-erp' ); ?></span>
                                        <span class="dz-message-or"><?php esc_html_e( 'یا', 'kasebi-erp' ); ?></span>
                                        <div
                                            class="btn btn-primary"><?php esc_html_e( 'انتخاب کنید', 'kasebi-erp' ); ?></div>
                                    </div>
                                </div>
								<?php KERP_Helpers_Template::render_template( 'app/components/fields/hidden.php', [ 'field' => $avatar_field ] ); ?>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="border rounded p-3">
                                <div class="d-flex align-center justify-between flex-wrap g-2">
                                    <div>
                                        <strong><?php esc_html_e( 'استفاده از وبکم', 'kasebi-erp' ); ?></strong>
                                        <div
                                            class="text-soft small"><?php esc_html_e( 'در صورت اتصال دوربین، می‌توانید مستقیم عکس بگیرید.', 'kasebi-erp' ); ?></div>
                                    </div>
                                    <button type="button"
                                            class="btn btn-outline-primary btn-sm start_profile_webcam"><?php esc_html_e( 'فعال کردن وبکم', 'kasebi-erp' ); ?></button>
                                </div>
                                <div class="profile_webcam_box mt-3">
                                    <div class="row g-3">
                                        <div class="col-md-6">
                                            <video class="profile_webcam_video w-100 rounded" width="300" height="300"
                                                   autoplay playsinline muted></video>
                                        </div>
                                        <div class="col-md-6">
                                            <canvas class="profile_webcam_canvas w-100 rounded" width="500"
                                                    height="500"></canvas>
                                        </div>
                                        <div class="col-12 text-center">
                                            <button type="button"
                                                    class="btn btn-info take_profile_webcam_screenshot"><?php esc_html_e( 'پیش‌نمایش تصویر', 'kasebi-erp' ); ?></button>
                                            <button type="button"
                                                    class="btn btn-success upload_profile_webcam_to_dropzone"><?php esc_html_e( 'افزودن به آپلودزون', 'kasebi-erp' ); ?></button>
                                            <button type="button"
                                                    class="btn btn-light stop_profile_webcam"><?php esc_html_e( 'بستن وبکم', 'kasebi-erp' ); ?></button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                <li>
                                    <button type="button"
                                            class="btn btn-primary submit_modal_form"><?php esc_html_e( 'ثبت تصویر پروفایل', 'kasebi-erp' ); ?></button>
                                </li>
                                <li><a href="#" class="link link-light btn-trigger"
                                       data-bs-dismiss="modal"><?php esc_html_e( 'لغو', 'kasebi-erp' ); ?></a></li>
                            </ul>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
