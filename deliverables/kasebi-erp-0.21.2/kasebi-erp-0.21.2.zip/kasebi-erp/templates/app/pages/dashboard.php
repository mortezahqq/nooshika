<?php

defined( 'ABSPATH' ) || exit;

if ( ! KERP_App::instance()->current_user_has_access() || ! kerp_can_page( 'dashboard' ) ) {
	return;
}
?>
<div class="kerp-dashboard" data-dashboard-nonce="<?php echo esc_attr( wp_create_nonce( 'kerp-dashboard' ) ); ?>">
	<div class="nk-block-head nk-block-head-sm">
		<div class="nk-block-head-content">
			<h3 class="nk-block-title page-title"><?php esc_html_e( 'میزکار', 'kasebi-erp' ); ?></h3>
			<div class="nk-block-des text-soft"><p><?php esc_html_e( 'نمای کلی فعالیت‌ها و اطلاعات در دسترس شما', 'kasebi-erp' ); ?></p></div>
			<p class="sub-text small mb-0"><?php esc_html_e( 'خلاصه‌ها ممکن است با چند دقیقه تأخیر به‌روز شوند.', 'kasebi-erp' ); ?></p>
		</div>
	</div>
	<div class="nk-block">
		<div class="row g-gs mx-0 kerp-dashboard-blocks">
			<?php KERP_App_Dashboard::render( [
				'user_id' => get_current_user_id(),
				'page_context' => isset( $page_context ) && is_array( $page_context ) ? $page_context : [],
			] ); ?>
		</div>
	</div>
</div>
