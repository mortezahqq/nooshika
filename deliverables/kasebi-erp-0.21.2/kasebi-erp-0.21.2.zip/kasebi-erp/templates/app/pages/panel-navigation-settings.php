<?php
defined( 'ABSPATH' ) || exit;
if ( ! kerp_can( KERP_Settings_Panel_Navigation::PERMISSION, 'action' ) ) { return; }
$rows = KERP_Settings_Panel_Navigation::instance()->rows();
$module_count = count( array_unique( array_column( $rows, 'module' ) ) );
?>
<div class="kerp-panel-navigation-settings">
    <div class="nk-block-head nk-block-head-sm">
        <div class="nk-block-head-content">
            <h3 class="nk-block-title page-title">نمایش پنل کاربری</h3>
            <div class="nk-block-des text-soft"><p>عنوان و آیکون صفحات پنل را به سلیقه خود تنظیم کنید.</p></div>
        </div>
    </div>
    <div class="nk-block">
        <div class="card card-bordered kerp-settings-hero">
            <div class="card-inner kerp-settings-hero__layout">
                <div class="kerp-settings-hero__intro">
                    <div class="kerp-settings-hero__icon"><em class="icon ni ni-layout" aria-hidden="true"></em></div>
                    <div>
                        <span class="overline-title text-primary">منوی پنل کاربری</span>
                        <h5 class="title mb-1">هر صفحه، یک هویت مشخص</h5>
                        <p class="text-soft mb-0">فقط صفحات پنل ماژول‌های فعال در این بخش قرار دارند. هر صفحه عنوان و آیکون مستقل دارد.</p>
                    </div>
                </div>
                <div class="kerp-panel-navigation-stats">
                    <div><strong><?php echo esc_html( count( $rows ) ); ?></strong><span>صفحه پنل</span></div>
                    <div><strong><?php echo esc_html( $module_count ); ?></strong><span>ماژول</span></div>
                </div>
            </div>
        </div>
    </div>
    <?php if ( ! $rows ) : ?>
        <div class="nk-block"><div class="card card-bordered"><div class="card-inner text-center py-5">
            <em class="icon ni ni-layout fs-2 text-soft" aria-hidden="true"></em>
            <h5 class="title mt-3">هنوز صفحه‌ای ثبت نشده است</h5>
            <p class="text-soft mb-0">با فعال شدن ماژولی که صفحه پنل کاربری دارد، تنظیمات آن در این بخش نمایش داده می‌شود.</p>
        </div></div></div>
    <?php else : ?>
    <form class="kerp-panel-navigation-form" data-nonce="<?php echo esc_attr( wp_create_nonce( 'kerp_panel_navigation' ) ); ?>">
        <div class="nk-block">
            <div class="kerp-panel-navigation-section-head">
                <div><h6 class="title mb-1">صفحات پنل</h6><p class="text-soft mb-0">پیش‌نمایش هر صفحه با تغییر عنوان و آیکون به‌روز می‌شود.</p></div>
                <span class="text-soft small">کلاس کامل آیکون · <bdi>ni ni-wallet</bdi></span>
            </div>
            <div class="row g-3">
                <?php foreach ( $rows as $key => $row ) : ?>
                <div class="col-12 col-xl-6">
                    <div class="card card-bordered h-100 kerp-panel-navigation-row" data-page="<?php echo esc_attr( $key ); ?>" data-default-title="<?php echo esc_attr( $row['default_title'] ); ?>" data-default-icon="<?php echo esc_attr( $row['default_icon'] ); ?>">
                        <div class="card-inner kerp-panel-navigation-card-head">
                            <div class="kerp-panel-navigation-identity">
                                <span class="kerp-panel-navigation-module-icon"><em class="icon ni ni-grid-alt" aria-hidden="true"></em></span>
                                <div><span class="overline-title text-soft"><?php echo esc_html( $row['label'] ); ?></span><h6 class="title mb-0"><?php echo esc_html( $row['default_title'] ); ?></h6></div>
                            </div>
                            <button type="button" class="btn btn-sm btn-outline-light kerp-panel-navigation-reset" aria-label="<?php echo esc_attr( 'بازگشت ' . $row['default_title'] . ' به پیش‌فرض' ); ?>"><em class="icon ni ni-reload" aria-hidden="true"></em><span>پیش‌فرض</span></button>
                        </div>
                        <div class="card-inner pt-0">
                            <div class="kerp-panel-navigation-menu-preview">
                                <span class="kerp-panel-navigation-preview-icon"><em class="icon <?php echo esc_attr( $row['icon'] ); ?> kerp-panel-navigation-preview" aria-hidden="true"></em></span>
                                <span class="kerp-panel-navigation-preview-title"><?php echo esc_html( $row['title'] ); ?></span>
                                <em class="icon ni ni-chevron-left" aria-hidden="true"></em>
                            </div>
                            <div class="row g-3 mt-1">
                                <?php KERP_Helpers_Template::render_template( 'app/components/fields/text.php', [ 'field' => [
                                    'id' => 'kerp-panel-title-' . $key, 'name' => 'pages[' . $key . '][title]', 'label' => 'عنوان در پنل',
                                    'value' => $row['title'], 'class' => 'col-12 col-sm-6', 'input_class' => 'kerp-panel-navigation-title',
                                ] ] ); ?>
                                <?php KERP_Helpers_Template::render_template( 'app/components/fields/text.php', [ 'field' => [
                                    'id' => 'kerp-panel-icon-' . $key, 'name' => 'pages[' . $key . '][icon]', 'label' => 'کلاس کامل آیکون',
                                    'value' => $row['icon'], 'class' => 'col-12 col-sm-6', 'input_class' => 'kerp-panel-navigation-icon',
                                ] ] ); ?>
                            </div>
                            <div class="kerp-panel-navigation-card-note"><em class="icon ni ni-info" aria-hidden="true"></em><span>فیلد خالی از مقدار پیش‌فرض استفاده می‌کند.</span></div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <div class="nk-block kerp-panel-navigation-savebar">
            <div><strong>ذخیره نمایش پنل</strong><span class="text-soft small kerp-panel-navigation-feedback" role="status" aria-live="polite">تغییرات پس از تازه‌سازی پنل کاربری دیده می‌شوند.</span></div>
            <button type="submit" class="btn btn-primary kerp-panel-navigation-save"><em class="icon ni ni-save"></em><span>ذخیره تغییرات</span></button>
        </div>
    </form>
    <?php endif; ?>
</div>
