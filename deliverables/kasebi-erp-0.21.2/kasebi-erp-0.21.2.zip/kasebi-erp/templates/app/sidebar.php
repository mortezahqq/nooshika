<?php

defined( 'ABSPATH' ) || exit;

/**
 * @var array $page_context
 * @var array $sidebar
 */
$sidebar = KERP_App_Sidebar::instance()->get_context( $page_context );
$groups  = isset( $sidebar['groups'] ) && is_array( $sidebar['groups'] )
	? $sidebar['groups']
	: [];

$active = isset( $sidebar['active'] ) && is_array( $sidebar['active'] )
	? $sidebar['active']
	: [];

$active_group = sanitize_key( (string) ( $active['group'] ?? '' ) );
$active_menu  = sanitize_key( (string) ( $active['menu'] ?? '' ) );
$active_page  = sanitize_key( (string) ( $active['page'] ?? '' ) );

if ( empty( $groups ) ) {
	return;
}

?>
<div
    class="nk-sidebar"
    data-content="sidebarMenu"
    data-active-group="<?php echo esc_attr( $active_group ); ?>"
    data-active-menu="<?php echo esc_attr( $active_menu ); ?>"
    data-active-page="<?php echo esc_attr( $active_page ); ?>"
>
    <div class="nk-sidebar-bar">
        <div class="nk-apps-brand">
            <a href="https://kasebi.co/" class="logo-link" target="_blank" rel="noopener">
                <img
                    src="https://kasebi.co/wp-content/uploads/2021/10/kasebi_logo.png"
                    alt="<?php esc_attr_e( 'کاسبی', 'kasebi-erp' ); ?>"
                    class="logo-img"
                >
            </a>
        </div>

        <div class="nk-sidebar-element">
            <div class="nk-sidebar-body">
                <div class="nk-sidebar-content" data-simplebar>
                    <div class="nk-sidebar-menu">
                        <ul class="nk-menu apps-menu">
							<?php foreach ( $groups as $group ) : ?>
								<?php if ( ! empty( $group['sep_before'] ) ) : ?>
                                    <li
                                        class="nk-menu-hr"
                                        role="separator"
                                        aria-hidden="true"
                                    ></li>
								<?php endif; ?>
								<?php
								$group_key    = sanitize_key( (string) $group['key'] );
								$group_active = ! empty( $group['active'] );
								$target       = 'kerp-nav-' . sanitize_html_class( $group_key );
								$icon         = (string) $group['icon'];
								?>
                                <li class="nk-menu-item<?php echo $group_active ? ' active' : ''; ?>">
                                    <a
                                        href="#"
                                        class="nk-menu-link nk-menu-switch"
                                        data-target="<?php echo esc_attr( $target ); ?>"
                                        title="<?php echo esc_attr( $group['title'] ); ?>"
                                        aria-label="<?php echo esc_attr( $group['title'] ); ?>"
                                        aria-current="<?php echo $group_active ? 'true' : 'false'; ?>"
                                    >
										<span class="nk-menu-icon">
											<em class="<?php echo $icon; ?> icon"></em>
										</span>
                                    </a>
                                </li>
								
								<?php if ( ! empty( $group['separator_after'] ) ) : ?>
                                    <li
                                        class="nk-menu-hr"
                                        role="separator"
                                        aria-hidden="true"
                                    ></li>
								<?php endif; ?>
							<?php endforeach; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="nk-sidebar-main">
        <div class="nk-sidebar-inner" data-simplebar>
			<?php foreach ( $groups as $group ) : ?>
				<?php
				$group_key    = sanitize_key( (string) $group['key'] );
				$group_active = ! empty( $group['active'] );
				$target       = 'kerp-nav-' . sanitize_html_class( $group_key );
				?>

                <div class="nk-menu-content<?php echo $group_active ? ' menu-active' : ''; ?>"
                     data-content="<?php echo esc_attr( $target ); ?>">
                    <h5 class="title"><?php echo esc_html( $group['title'] ); ?></h5>

                    <ul class="nk-menu">
						<?php foreach ( $group['rows'] as $row ) : ?>
							<?php if ( $row['type'] === 'page' ) : ?>
								<?php
								$row_active = ! empty( $row['active'] );
								$icon       = (string) $row['icon'];
								?>

                                <li class="nk-menu-item<?php echo $row_active ? ' active current-page' : ''; ?>">
                                    <a
                                        href="<?php echo esc_url( $row['href'] ); ?>"
                                        class="page_activator nk-menu-link"
                                        data-url="<?php echo esc_attr( $row['data_url'] ); ?>"
										<?php echo $row_active ? 'aria-current="page"' : ''; ?>
                                    >
										<span class="nk-menu-icon">
											<em class="<?php echo $icon; ?> icon"></em>
										</span>

                                        <span class="nk-menu-text">
											<?php
											echo esc_html( $row['title'] );
											do_action( 'kerp_sidebar_title_after', $row['key'], $page_context );
											?>
										</span>
                                    </a>
                                </li>
							<?php else : ?>
								<?php
								$menu_active = ! empty( $row['active'] );
								$icon        = (string) $row['icon'];
								?>

                                <li class="nk-menu-item has-sub<?php echo $menu_active ? ' active' : ''; ?>">
                                    <a
                                        href="#"
                                        class="nk-menu-link nk-menu-toggle"
                                        aria-expanded="<?php echo $menu_active ? 'true' : 'false'; ?>"
                                    >
										<span class="nk-menu-icon">
											<em class="<?php echo $icon; ?> icon"></em>
										</span>

                                        <span class="nk-menu-text">
											<?php echo esc_html( $row['title'] ); ?>
										</span>
                                    </a>

                                    <ul class="nk-menu-sub">
										<?php foreach ( $row['children'] as $child ) : ?>
											<?php $child_active = ! empty( $child['active'] ); ?>

                                            <li class="nk-menu-item<?php echo $child_active ? ' active current-page' : ''; ?>">
                                                <a
                                                    href="<?php echo esc_url( $child['href'] ); ?>"
                                                    class="page_activator nk-menu-link"
                                                    data-url="<?php echo esc_attr( $child['data_url'] ); ?>"
													<?php echo $child_active ? 'aria-current="page"' : ''; ?>
                                                >
													<span class="nk-menu-text">
														<?php
														echo esc_html( $child['title'] );
														do_action( 'kerp_sidebar_title_after', $child['key'], $page_context );
														?>
													</span>
                                                </a>
                                            </li>
										<?php endforeach; ?>
                                    </ul>
                                </li>
							<?php endif; ?>
						<?php endforeach; ?>
                    </ul>
                </div>
			<?php endforeach; ?>
        </div>
    </div>
</div>