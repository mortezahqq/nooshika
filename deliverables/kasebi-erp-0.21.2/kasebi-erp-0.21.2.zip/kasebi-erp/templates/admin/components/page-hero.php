<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * @var string $title
 * @var string $description
 * @var string $button_text
 * @var string $button_type
 * @var string $icon
 */

$button_type = $button_type ?? 'button';
$icon        = $icon ?? 'uik-r fa-grid-2';
?>

<div class="kasebi-page-hero">
    <div class="kasebi-page-hero-content">
        <div class="kasebi-page-hero-info">
            <div class="kasebi-page-hero-icon">
                <i class="<?php echo esc_attr( $icon ); ?>"></i>
            </div>

            <div class="kasebi-page-hero-text">
                <h2><?php echo esc_html( $title ); ?></h2>
				
				<?php if ( ! empty( $description ) ) : ?>
                    <p><?php echo esc_html( $description ); ?></p>
				<?php endif; ?>
            </div>
        </div>
		
		<?php if ( ! empty( $button_text ) ) : ?>
            <button type="<?php echo esc_attr( $button_type ); ?>" class="button button-primary kasebi-page-hero-submit">
                <i class="uik-r fa-check"></i>
				<?php echo esc_html( $button_text ); ?>
            </button>
		<?php endif; ?>
    </div>
</div>