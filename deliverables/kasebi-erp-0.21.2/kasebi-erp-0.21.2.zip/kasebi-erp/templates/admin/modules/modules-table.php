<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * @var KERP_Modules $modules_manager
 * @var array        $parent_modules
 */
?>

<div class="kasebi-table-card">
    <div class="kasebi-table-scroll">
        <table class="widefat fixed striped ksp-modules-table">
            <thead>
            <tr>
                <th class="column-module"><?php esc_html_e( 'ماژول', 'kasebi-platform' ); ?></th>
                <th class="column-description"><?php esc_html_e( 'توضیحات', 'kasebi-platform' ); ?></th>
                <th class="column-status"><?php esc_html_e( 'وضعیت', 'kasebi-platform' ); ?></th>
                <th class="column-toggle"><?php esc_html_e( 'فعال‌سازی', 'kasebi-platform' ); ?></th>
            </tr>
            </thead>

            <tbody>
			<?php
			foreach ( $parent_modules as $key => $module ) {
				if ( $key == 'ajax' ) {
					continue;
				}
				KERP_Helpers_Template::render_template( 'admin/modules/module-row.php', [
					'key'             => $key,
					'module'          => $module,
					'modules_manager' => $modules_manager,
					'is_child'        => FALSE,
				] );
				
				foreach ( $modules_manager->get_children( $key ) as $child_key => $child_module ) {
					KERP_Helpers_Template::render_template( 'admin/modules/module-row.php', [
						'key'             => $child_key,
						'module'          => $child_module,
						'modules_manager' => $modules_manager,
						'is_child'        => TRUE,
					] );
				}
			}
			?>
            </tbody>
        </table>
    </div>
</div>