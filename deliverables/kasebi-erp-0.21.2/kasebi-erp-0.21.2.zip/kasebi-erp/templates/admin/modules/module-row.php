<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * @var string       $key
 * @var array        $module
 * @var KERP_Modules $modules_manager
 * @var bool         $is_child
 */

$is_enabled           = $modules_manager->is_module_enabled( $key );
$missing_dependencies = $modules_manager->get_missing_dependencies( $module );
$is_disabled          = ! empty( $missing_dependencies );
$input_id             = 'ksp-module-' . sanitize_html_class( $key );
$row_class            = $is_child ? 'is-child' : 'is-parent';
$row_class            .= $is_enabled ? ' is-enabled' : ' is-disabled';
$row_class            .= $is_disabled ? ' has-missing-dependencies' : '';
?>

<tr class="<?php echo esc_attr( $row_class ); ?>">
    <td class="column-module">
        <div class="kasebi-module-name">
			<?php if ( ! empty( $module['icon'] ) ) : ?>
                <span class="kasebi-module-icon">
                    <i class="<?php echo esc_attr( $module['icon'] ); ?>"></i>
                </span>
			<?php endif; ?>
            <div>
                <strong><?php echo esc_html( $module['label'] ); ?></strong>
            </div>
        </div>
    </td>

    <td class="column-description">
        <span><?php echo esc_html( $module['description'] ?? '' ); ?></span>
		
		<?php if ( $missing_dependencies ) : ?>
            <div class="kasebi-module-warning">
				<?php
				$dependency_labels = wp_list_pluck( $missing_dependencies, 'label' );
				printf(
					esc_html__( 'وابستگی فعال نیست: %s', 'kasebi-platform' ),
					esc_html( implode( '، ', $dependency_labels ) )
				);
				?>
            </div>
		<?php endif; ?>
    </td>

    <td class="column-status">
		<?php if ( $is_enabled ) : ?>
            <span class="kasebi-status-badge is-active"><?php esc_html_e( 'فعال', 'kasebi-platform' ); ?></span>
		<?php else : ?>
            <span class="kasebi-status-badge is-inactive"><?php esc_html_e( 'غیرفعال', 'kasebi-platform' ); ?></span>
		<?php endif; ?>
    </td>

    <td class="column-toggle">
        <label class="kasebi-switch" for="<?php echo esc_attr( $input_id ); ?>">
            <input
                type="checkbox"
                id="<?php echo esc_attr( $input_id ); ?>"
                name="modules[<?php echo esc_attr( $key ); ?>]"
                value="1"
				<?php checked( $is_enabled ); ?>
				<?php disabled( $is_disabled ); ?>
            >
            <span class="kasebi-switch-box"></span>
        </label>
    </td>
</tr>