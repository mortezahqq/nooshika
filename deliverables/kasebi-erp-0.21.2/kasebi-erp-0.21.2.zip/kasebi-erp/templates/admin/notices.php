<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * @var string $notice
 */

$message = '';
$type    = 'success';

switch ( $notice ) {
	case 'modules_saved':
		$message = __( 'تنظیمات ماژول‌ها ذخیره شد.', 'kasebi-platform' );
		break;
	
	default:
		$message = '';
		break;
}

if ( ! $message ) {
	return;
}
?>

<div class="notice notice-<?php echo esc_attr( $type ); ?> is-dismissible ksp-admin-notice">
    <p><?php echo esc_html( $message ); ?></p>
</div>