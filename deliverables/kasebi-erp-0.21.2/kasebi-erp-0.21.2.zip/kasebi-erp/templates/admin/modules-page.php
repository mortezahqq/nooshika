<?php

defined( 'ABSPATH' ) || exit;

/**
 * @var KERP_Modules $modules_manager
 * @var array        $parent_modules
 * @var string       $notice
 */

?>

<div class="wrap kasebi-admin-page kasebi-modules-page">
    <form id="kasebi-modules-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
        <input type="hidden" name="action" value="<?php echo esc_attr( KERP_Admin_Modules_Page::SAVE_ACTION ); ?>">
		<?php wp_nonce_field( KERP_Admin_Modules_Page::NONCE_ACTION, KERP_Admin_Modules_Page::NONCE_NAME ); ?>
		<?php
		KERP_Helpers_Template::render_template( 'admin/components/page-hero.php', [
			'title'       => __( 'مدیریت ماژول‌ها', 'kasebi-erp' ),
			'description' => __( 'در این بخش می‌توانید ماژول‌های افزونه ERP را فعال یا غیرفعال کنید.', 'kasebi-erp' ),
			'button_text' => __( 'ذخیره ماژول‌ها', 'kasebi-erp' ),
			'button_type' => 'submit',
			'icon'        => 'kik-r fa-layout-grid-01',
		] );
		?>
		
		<?php
		if ( $notice ) {
			KERP_Helpers_Template::render_template( 'admin/notices.php', [
				'notice' => $notice,
			] );
		}
		?>
		
		<?php
		KERP_Helpers_Template::render_template( 'admin/modules/modules-table.php', [
			'modules_manager' => $modules_manager,
			'parent_modules'  => $parent_modules,
		] );
		?>
    </form>
</div>
