<?php

defined( 'ABSPATH' ) || exit;

$app = KERP_App::instance();
$has_access = $app->current_user_has_access();
$page_context = $app->get_current_page_context();
$user_id = get_current_user_id();
$dark_mode_meta = get_user_meta( $user_id, 'kerp_dark_mode', TRUE );
$is_dark_mode = in_array(
	strtolower( (string) $dark_mode_meta ),
	[ '1', 'true', 'yes', 'on' ],
	TRUE
);
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	
	<?php wp_head(); ?>
</head>

<body <?php body_class( 'kerp-shell' . ( $is_dark_mode ? ' dark-mode' : '' ) ); ?>>
<?php wp_body_open(); ?>

<?php if ( $has_access ) : ?>
    <div id="kerp-app">
		<?php
		KERP_Helpers_Template::render_template(
			'app/main.php',
			[
				'page_context' => $page_context,
			]
		);
		?>
    </div>
<?php else : ?>

    <main class="kerp-access-denied" role="main">
        <div class="kerp-access-denied__card">
            <h1>
				<?php esc_html_e( 'دسترسی به ERP فعال نیست', 'kasebi-erp' ); ?>
            </h1>

            <p>
				<?php esc_html_e(
					'برای حساب کاربری شما هنوز سطح دسترسی ERP تعریف نشده است.',
					'kasebi-erp'
				); ?>
            </p>
            <a class="btn btn-primary mt-4" href="<?php echo esc_url( home_url( '/panel/' ) ); ?>">
                <?php esc_html_e( 'رفتن به پنل کاربری', 'kasebi-erp' ); ?>
            </a>
        </div>
    </main>

<?php endif; ?>

<noscript>
	<?php esc_html_e(
		'برای استفاده از ERP باید JavaScript مرورگر فعال باشد.',
		'kasebi-erp'
	); ?>
</noscript>

<?php wp_footer(); ?>
</body>
</html>
