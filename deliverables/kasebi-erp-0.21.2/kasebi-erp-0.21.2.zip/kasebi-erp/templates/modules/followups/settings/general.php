<?php

defined( 'ABSPATH' ) || exit;

$settings_service   = KERP_Modules_Followups_Settings::instance();
$customer_singular_label = KERP_Modules_Customers_Settings::instance()->get_singular_label();
$settings           = $settings_service->all();
$types              = $settings_service->get_types( FALSE );
$type_options       = $settings_service->get_type_options( FALSE );
$priority_options   = $settings_service->get_priority_options();
$modal_id           = 'kerp-followup-type-modal';
$modal_selector     = '#' . $modal_id;
$default_per_page   = max( 1, min( 200, absint( $settings['default_per_page'] ?? 20 ) ) );
$default_priority   = sanitize_key( (string) ( $settings['default_priority'] ?? 'normal' ) );
$active_types_count = 0;

foreach ( $types as $type ) {
	if ( is_array( $type ) && ! empty( $type['active'] ) ) {
		$active_types_count ++;
	}
}

if ( $types ) {
	$type_orders = [];
	foreach ( $types as $type_key => $type ) {
		$type_orders[ $type_key ] = absint( is_array( $type ) ? ( $type['order'] ?? 100 ) : 100 );
	}
	array_multisort( $type_orders, SORT_ASC, SORT_NUMERIC, $types );
}

$add_populate = [
	'original_key' => [ 'id' => '#kerp-followup-type-original-key', 'type' => 'text', 'value' => '' ],
	'key'          => [ 'id' => '#kerp-followup-type-key-setting', 'type' => 'text', 'value' => '' ],
	'label'        => [ 'id' => '#kerp-followup-type-label', 'type' => 'text', 'value' => '' ],
	'icon'         => [ 'id' => '#kerp-followup-type-icon', 'type' => 'text', 'value' => 'kik fa-clock' ],
	'color'        => [ 'id' => '#kerp-followup-type-color', 'type' => 'select', 'value' => 'primary' ],
	'order'        => [ 'id' => '#kerp-followup-type-order', 'type' => 'text', 'value' => 100 ],
	'active'       => [ 'id' => '#kerp-followup-type-active', 'type' => 'switch', 'value' => '1' ],
];
?>
    <div class="kerp-settings-smart kerp-followups-settings">
        <div class="nk-block-head nk-block-head-sm">
            <div class="nk-block-between g-3">
                <div class="nk-block-head-content">
                    <h3 class="nk-block-title page-title"><?php esc_html_e( 'تنظیمات پیگیری‌ها', 'kasebi-erp' ); ?></h3>
                    <div class="nk-block-des text-soft">
                        <p><?php printf( esc_html__( 'پیش‌فرض‌های پیگیری و نوع‌های قابل استفاده در فرآیندهای ارتباط با %s و کارکنان را مدیریت کنید.', 'kasebi-erp' ), esc_html( $customer_singular_label ) ); ?></p>
                    </div>
                </div>
                <div class="nk-block-head-content">
                    <button type="button" class="btn btn-primary open_populate_modal"
                            data-modal="<?php echo esc_attr( $modal_selector ); ?>"
                            data-modal-title="<?php esc_attr_e( 'افزودن نوع پیگیری', 'kasebi-erp' ); ?>"
                            data-submit-text="<?php esc_attr_e( 'افزودن نوع', 'kasebi-erp' ); ?>"
                            data-populate="<?php echo esc_attr( wp_json_encode( $add_populate ) ); ?>"><em
                            class="icon ni ni-plus"></em><span><?php esc_html_e( 'افزودن نوع پیگیری', 'kasebi-erp' ); ?></span>
                    </button>
                </div>
            </div>
        </div>

        <div class="nk-block">
			<?php
			KERP_Helpers_Template::render_template(
				'app/components/settings/hero.php',
				[
					'icon'        => 'kik fa-clock',
					'eyebrow'     => __( 'مدیریت پیگیری', 'kasebi-erp' ),
					'title'       => __( 'قواعد پیش‌فرض و نوع‌های پیگیری', 'kasebi-erp' ),
					'description' => __( 'نوع، اولویت و نحوه نمایش پیگیری‌ها را یک‌جا مدیریت کنید.', 'kasebi-erp' ),
					'stats'       => [
						[
							'label' => __( 'کل نوع‌ها', 'kasebi-erp' ),
							'value' => number_format_i18n( count( $types ) ),
						],
						[
							'label' => __( 'نوع فعال', 'kasebi-erp' ),
							'value' => number_format_i18n( $active_types_count ),
						],
						[
							'label' => __( 'اولویت پیش‌فرض', 'kasebi-erp' ),
							'value' => (string) ( $priority_options[ $default_priority ] ?? $default_priority ),
							'class' => 'kerp-settings-stat__text',
						],
						[
							'label' => __( 'نمایش در صفحه', 'kasebi-erp' ),
							'value' => number_format_i18n( $default_per_page ),
						],
					],
				]
			);
			?>
        </div>
        <div class="nk-block">
            <div class="kerp-settings-section-head">
                <div><h5 class="title mb-1"><?php esc_html_e( 'انواع پیگیری', 'kasebi-erp' ); ?></h5>
                    <p class="text-soft mb-0"><?php esc_html_e( 'نوع‌های قابل انتخاب هنگام ایجاد پیگیری را مدیریت کنید.', 'kasebi-erp' ); ?></p>
                </div>
            </div>
			<?php if ( empty( $types ) ) : ?>
				<?php
				KERP_Helpers_Template::render_template(
					'app/components/settings/empty-state.php',
					[
						'icon'        => 'kik fa-clock',
						'title'       => __( 'نوع پیگیری ثبت نشده است.', 'kasebi-erp' ),
						'description' => __( 'برای شروع اولین نوع پیگیری را ایجاد کنید.', 'kasebi-erp' ),
						'action'      => [
							'label'      => __( 'افزودن نوع پیگیری', 'kasebi-erp' ),
							'icon'       => 'icon ni ni-plus',
							'class'      => 'btn btn-primary open_populate_modal',
							'attributes' => [
								'data-modal'       => $modal_selector,
								'data-modal-title' => __( 'افزودن نوع پیگیری', 'kasebi-erp' ),
								'data-submit-text' => __( 'افزودن نوع', 'kasebi-erp' ),
								'data-populate'    => wp_json_encode( $add_populate ),
							],
						],
					]
				);
				?>
			<?php else : ?>
                <div class="row g-gs kerp-settings-item-grid">
					<?php foreach ( $types as $type_key => $type ) : ?>
						<?php
						if ( ! is_array( $type ) ) {
							continue;
						}
						$type_key            = sanitize_key( (string) ( $type['key'] ?? $type_key ) );
						$type_label          = sanitize_text_field( (string) ( $type['label'] ?? $type_key ) );
						$type_icon           = sanitize_text_field( (string) ( $type['icon'] ?? 'kik fa-clock' ) );
						$type_color          = sanitize_key( (string) ( $type['color'] ?? 'primary' ) );
						$type_text_color     = $type_color === 'light' ? 'dark' : $type_color;
						$type_order          = absint( $type['order'] ?? 100 );
						$type_active         = ! empty( $type['active'] );
						$edit_populate       = [
							'original_key' => [
								'id'    => '#kerp-followup-type-original-key',
								'type'  => 'text',
								'value' => $type_key,
							],
							'key'          => [
								'id'    => '#kerp-followup-type-key-setting',
								'type'  => 'text',
								'value' => $type_key,
							],
							'label'        => [
								'id'    => '#kerp-followup-type-label',
								'type'  => 'text',
								'value' => $type_label,
							],
							'icon'         => [
								'id'    => '#kerp-followup-type-icon',
								'type'  => 'text',
								'value' => $type_icon,
							],
							'color'        => [
								'id'    => '#kerp-followup-type-color',
								'type'  => 'select',
								'value' => $type_color,
							],
							'order'        => [
								'id'    => '#kerp-followup-type-order',
								'type'  => 'text',
								'value' => $type_order,
							],
							'active'       => [
								'id'    => '#kerp-followup-type-active',
								'type'  => 'switch',
								'value' => $type_active ? '1' : '0',
							],
						];
						$replacement_options = array_diff_key( $type_options, [ $type_key => TRUE ] );
						?>
						<?php
						$card_actions = [
							[
								'label'      => __( 'ویرایش', 'kasebi-erp' ),
								'icon'       => 'icon ni ni-edit',
								'class'      => 'edit_row_item',
								'attributes' => [
									'data-modal'       => $modal_selector,
									'data-modal-title' => __( 'ویرایش نوع پیگیری', 'kasebi-erp' ),
									'data-submit-text' => __( 'ذخیره تغییرات', 'kasebi-erp' ),
									'data-populate'    => wp_json_encode( $edit_populate ),
								],
							],
						];
						if ( $replacement_options ) {
							$card_actions[] = [
								'label'          => __( 'حذف و جایگزینی', 'kasebi-erp' ),
								'icon'           => 'icon ni ni-trash',
								'class'          => 'edit_row_item',
								'divider_before' => TRUE,
								'attributes'     => [
									'data-modal'       => '#kerp-followup-type-delete-modal',
									'data-modal-title' => __( 'حذف نوع پیگیری', 'kasebi-erp' ),
									'data-submit-text' => __( 'حذف و جایگزینی', 'kasebi-erp' ),
									'data-populate'    => wp_json_encode( [
										'type_key' => [
											'id'    => '#kerp-followup-delete-type-key',
											'type'  => 'text',
											'value' => $type_key,
										],
									] ),
								],
							];
						}
						KERP_Helpers_Template::render_template(
							'app/components/settings/item-card.php',
							[
								'icon'        => $type_icon . ' icon',
								'icon_class'  => 'bg-' . $type_color . '-dim text-' . $type_text_color,
								'label'       => $type_label,
								'key'         => $type_key,
								'active'      => $type_active,
								'description' => __( 'این نوع در فرم ثبت و فیلترهای پیگیری قابل استفاده است.', 'kasebi-erp' ),
								'actions'     => $card_actions,
								'footer'      => [
									[
										'icon' => 'icon ni ni-sort-v',
										'text' => sprintf( __( 'ترتیب %s', 'kasebi-erp' ), number_format_i18n( $type_order ) ),
									],
									[
										'icon' => 'icon ni ni-flag',
										'text' => (string) ( $color_options[ $type_color ] ?? $type_color ),
									],
								],
							]
						);
						?>
					<?php endforeach; ?>
                </div>
			<?php endif; ?>
        </div>
    </div>
<?php
KERP_Helpers_Template::render_modal(
	[
		'id'     => $modal_id,
		'title'  => __( 'افزودن یا ویرایش نوع پیگیری', 'kasebi-erp' ),
		'action' => 'followups_save_type',
		'page'   => '/erp/settings/followups/',
		'button' => __( 'ذخیره نوع', 'kasebi-erp' ),
		'size'   => 'lg',
		'fields' => [
			[
				'id'          => 'kerp-followup-type-original-key',
				'name'        => 'original_key',
				'type'        => 'hidden',
				'input_class' => 'no_clear',
				'value'       => '',
			],
			[
				'id'          => 'kerp-followup-type-key-setting',
				'name'        => 'type[key]',
				'label'       => __( 'کلید نوع', 'kasebi-erp' ),
				'description' => __( 'یک کلید انگلیسی یکتا مانند call-back وارد کنید.', 'kasebi-erp' ),
				'type'        => 'text',
				'class'       => 'col-md-6',
				'input_class' => 'kerp-settings-key-input',
				'value'       => '',
				'required'    => TRUE,
			],
			[
				'id'       => 'kerp-followup-type-label',
				'name'     => 'type[label]',
				'label'    => __( 'عنوان', 'kasebi-erp' ),
				'type'     => 'text',
				'class'    => 'col-md-6',
				'value'    => '',
				'required' => TRUE,
			],
			[
				'id'          => 'kerp-followup-type-icon',
				'name'        => 'type[icon]',
				'label'       => __( 'کلاس آیکون', 'kasebi-erp' ),
				'description' => __( 'برای مثال kik fa-clock یا ni ni-call', 'kasebi-erp' ),
				'type'        => 'text',
				'class'       => 'col-md-6',
				'input_class' => 'kerp-settings-icon-input',
				'value'       => 'kik fa-clock',
			],
			[
				'id'          => 'kerp-followup-type-color',
				'name'        => 'type[color]',
				'label'       => __( 'رنگ', 'kasebi-erp' ),
				'type'        => 'select',
				'class'       => 'col-md-6',
				'input_class' => 'kerp-settings-color-input',
				'options'     => [
					'primary'   => __( 'آبی', 'kasebi-erp' ),
					'success'   => __( 'سبز', 'kasebi-erp' ),
					'info'      => __( 'فیروزه‌ای', 'kasebi-erp' ),
					'warning'   => __( 'زرد', 'kasebi-erp' ),
					'danger'    => __( 'قرمز', 'kasebi-erp' ),
					'secondary' => __( 'خاکستری', 'kasebi-erp' ),
					'purple'    => __( 'بنفش', 'kasebi-erp' ),
					'light'     => __( 'روشن', 'kasebi-erp' ),
				],
				'value'       => 'primary',
			],
			[
				'id'    => 'kerp-followup-type-order',
				'name'  => 'type[order]',
				'label' => __( 'ترتیب', 'kasebi-erp' ),
				'type'  => 'number',
				'class' => 'col-md-6',
				'value' => 100,
				'min'   => 0,
			],
			[
				'id'          => 'kerp-followup-type-active-empty',
				'name'        => 'type[active]',
				'type'        => 'hidden',
				'input_class' => 'no_clear',
				'value'       => '0',
			],
			[
				'id'    => 'kerp-followup-type-active',
				'name'  => 'type[active]',
				'label' => __( 'فعال باشد', 'kasebi-erp' ),
				'type'  => 'switch',
				'class' => 'col-md-6 align-self-end',
				'value' => '1',
			],
		],
	]
);
KERP_Helpers_Template::render_modal(
	[
		'id'     => 'kerp-followup-type-delete-modal',
		'title'  => __( 'حذف نوع پیگیری', 'kasebi-erp' ),
		'action' => 'followups_delete_type',
		'page'   => '/erp/settings/followups/',
		'button' => __( 'حذف و جایگزینی', 'kasebi-erp' ),
		'size'   => 'md',
		'fields' => [
			[
				'id'          => 'kerp-followup-delete-type-key',
				'name'        => 'type_key',
				'type'        => 'hidden',
				'input_class' => 'no_clear',
				'value'       => '',
			],
			[
				'id'          => 'kerp-followup-replacement-key',
				'name'        => 'replacement_key',
				'label'       => __( 'نوع جایگزین', 'kasebi-erp' ),
				'description' => __( 'تمام پیگیری‌های این نوع به نوع انتخاب‌شده منتقل می‌شوند.', 'kasebi-erp' ),
				'type'        => 'select',
				'class'       => 'col-12',
				'options'     => $type_options,
				'value'       => '',
				'required'    => TRUE,
			],
		],
	]
);
