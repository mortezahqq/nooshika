<?php

defined( 'ABSPATH' ) || exit;

if ( ! isset( $followup ) || ! is_array( $followup ) ) {
	return;
}
$return_page         = isset( $return_page ) && is_string( $return_page ) ? $return_page : '/erp/followups/';
$context             = sanitize_html_class( (string) ( $context ?? 'main' ) );
$id                  = absint( $followup['id'] ?? 0 );
$customer_id         = absint( $followup['customer_id'] ?? 0 );
$assignee_id         = absint( $followup['assignee_id'] ?? 0 );
$type                = KERP_Modules_Followups_Settings::instance()
                                                      ->get_type( (string) ( $followup['type_key'] ?? '' ) );
$status_key          = (string) ( $followup['display_status'] ?? $followup['status'] ?? 'pending' );
$status_options      = KERP_Modules_Followups_Settings::instance()->get_status_options();
$priority_key        = sanitize_key( (string) ( $followup['priority'] ?? 'normal' ) );
$priority_options    = KERP_Modules_Followups_Settings::instance()->get_priority_options();
$status_classes      = [
	'pending'   => 'bg-warning',
	'overdue'   => 'bg-danger',
	'completed' => 'bg-success',
	'cancelled' => 'bg-light',
];
$priority_classes    = [ 'low' => 'bg-light', 'normal' => 'bg-info', 'high' => 'bg-warning', 'urgent' => 'bg-danger' ];
$customer_url        = '/erp/customers/' . $customer_id . '/?tab=followups';
$populate            = KERP_Modules_Followups_Module::instance()->get_populate_data( $followup );
$due_at              = (string) ( $followup['due_at'] ?? '' );
$timestamp           = $due_at !== '' ? strtotime( $due_at ) : FALSE;
$action_populate     = [
	'followup_id' => [ 'id' => '#kerp-followup-complete-id-' . $context, 'type' => 'text', 'value' => $id ],
];
$cancel_populate     = [
	'followup_id' => [ 'id' => '#kerp-followup-cancel-id-' . $context, 'type' => 'text', 'value' => $id ],
];
$history             = KERP_Modules_Followups_Query::instance()->get_history( $id );
$history_id          = 'kerp-followup-history-' . $context . '-' . $id;
$history_labels      = [
	'created'     => __( 'پیگیری ایجاد شد', 'kasebi-erp' ),
	'updated'     => __( 'اطلاعات پیگیری ویرایش شد', 'kasebi-erp' ),
	'completed'   => __( 'پیگیری انجام شد', 'kasebi-erp' ),
	'cancelled'   => __( 'پیگیری لغو شد', 'kasebi-erp' ),
	'rescheduled' => __( 'زمان پیگیری تغییر کرد', 'kasebi-erp' ),
];
$reschedule_populate = [
	'followup_id' => [ 'id' => '#kerp-followup-reschedule-id-' . $context, 'type' => 'text', 'value' => $id ],
	'due_date'    => [
		'id'    => '#kerp-followup-reschedule-date-' . $context,
		'type'  => 'text',
		'value' => $timestamp ? date_i18n( 'Y-m-d', $timestamp ) : '',
	],
	'due_time'    => [
		'id'    => '#kerp-followup-reschedule-time-' . $context,
		'type'  => 'text',
		'value' => $timestamp ? wp_date( 'H:i', $timestamp ) : '',
	],
];
$metadata            = json_decode(
	(string) ( $followup['metadata'] ?? '' ),
	TRUE
);

$metadata = is_array( $metadata )
	? $metadata
	: [];

$attachments = $metadata['attachment'] ?? [];

if ( is_string( $attachments ) ) {
	$attachments = preg_split(
		'/\s*,\s*/',
		trim( $attachments ),
		- 1,
		PREG_SPLIT_NO_EMPTY
	);
}

$attachments = is_array( $attachments )
	? array_values(
		array_unique(
			array_filter(
				array_map(
					'esc_url_raw',
					$attachments
				)
			)
		)
	)
	: [];

$attachment_count = count( $attachments );
?>
<div class="col-12 col-xl-6">
    <div
        class="card card-bordered h-100 kerp-followup-card<?php echo ! empty( $followup['is_overdue'] ) ? ' is-overdue' : ''; ?>">
        <div class="card-inner">
            <div class="kerp-followup-card__head">
                <div class="d-flex align-items-start" style="gap: 12px;">
        <span
            class="kerp-followup-card__type bg-<?php echo esc_attr( (string) ( $type['color'] ?? 'primary' ) ); ?>-dim text-<?php echo esc_attr( (string) ( $type['color'] ?? 'primary' ) ); ?>">
            <em class="<?php echo esc_attr( (string) ( $type['icon'] ?? 'kik fa-clock' ) ); ?> icon"></em>
        </span>
                    <div>
                        <h6 class="title mb-1">
							<?php echo esc_html( (string) ( $followup['title'] ?? '' ) ); ?>
                        </h6>
                        <div class="d-flex flex-wrap" style="gap: 5px;">
                <span class="badge badge-dim <?php echo esc_attr( $status_classes[ $status_key ] ?? 'bg-light' ); ?>">
					<?php echo esc_html( (string) ( $status_options[ $status_key ] ?? $status_key ) ); ?>
                </span>
                            <span
                                class="badge badge-dim <?php echo esc_attr( $priority_classes[ $priority_key ] ?? 'bg-info' ); ?>">
					<?php echo esc_html( (string) ( $priority_options[ $priority_key ] ?? $priority_key ) ); ?>
                </span>
                            <span class="badge badge-dim bg-outline-primary">
					<?php echo esc_html( (string) ( $type['label'] ?? '' ) ); ?>
                </span>
                        </div>
                    </div>
                </div>

                <ul class="nk-tb-actions gx-1">
					<?php if ( $attachment_count > 0 ) : ?>
                        <li>
                            <div class="dropdown">
                                <a href="#"
                                   class="btn btn-sm btn-icon btn-trigger dropdown-toggle"
                                   data-bs-toggle="dropdown"
                                   title="<?php esc_attr_e( 'فایل‌های ضمیمه', 'kasebi-erp' ); ?>"
                                   aria-expanded="false">
                                    <span class="badge badge-circle bg-primary">
                                        <?php echo esc_html( number_format_i18n( $attachment_count ) ); ?>
                                    </span>
                                    <em class="kik fa-file-attachment-04 icon p-0 m-0"></em>
                                </a>
                                <div class="dropdown-menu dropdown-menu-end">
                                    <ul class="link-list-opt no-bdr">
										<?php foreach ( $attachments as $attachment_index => $attachment_url ) : ?>
											<?php
											$attachment_url = esc_url_raw( $attachment_url );
											
											if ( $attachment_url === '' ) {
												continue;
											}
											
											$file_data = KERP_Api_File_Upload::instance()
											                                 ->get_uploaded_file_data( $attachment_url );
											
											$attachment_name = is_array( $file_data )
												? sanitize_text_field(
													(string) ( $file_data['original_name'] ?? '' )
												)
												: '';
											
											if ( $attachment_name === '' ) {
												$attachment_name = sprintf(
													__( 'فایل ضمیمه %s', 'kasebi-erp' ),
													number_format_i18n( $attachment_index + 1 )
												);
											}
											?>
                                            <li>
                                                <a href="<?php echo esc_url( $attachment_url ); ?>"
                                                   target="_blank"
                                                   rel="noopener"
                                                   download>
                                                    <em class="icon ni ni-file-download"></em>
                                                    <span><?php echo esc_html( $attachment_name ); ?></span>
                                                </a>
                                            </li>
										<?php endforeach; ?>
                                    </ul>
                                </div>
                            </div>
                        </li>
					<?php endif; ?>

                    <li>
                        <div class="dropdown">
                            <a href="#"
                               class="btn btn-sm btn-icon btn-trigger dropdown-toggle"
                               data-bs-toggle="dropdown"
                               aria-expanded="false">
                                <em class="icon ni ni-more-h"></em>
                            </a>
                            <div class="dropdown-menu dropdown-menu-end">
                                <ul class="link-list-opt no-bdr">
									<?php if ( kerp_can( 'followups.edit', 'action' ) ) : ?>
                                        <li>
                                            <a href="#"
                                               class="edit_row_item"
                                               data-modal="#<?php echo esc_attr( $context === 'customer' ? 'customerFollowupModal' : 'followupModal' ); ?>"
                                               data-modal-title="<?php esc_attr_e( 'ویرایش پیگیری', 'kasebi-erp' ); ?>"
                                               data-submit-text="<?php esc_attr_e( 'ذخیره تغییرات', 'kasebi-erp' ); ?>"
                                               data-populate="<?php echo esc_attr( wp_json_encode( $populate ) ); ?>">
                                                <em class="icon ni ni-edit"></em>
                                                <span><?php esc_html_e( 'ویرایش', 'kasebi-erp' ); ?></span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#"
                                               class="edit_row_item"
                                               data-modal="#followupRescheduleModal-<?php echo esc_attr( $context ); ?>"
                                               data-populate="<?php echo esc_attr( wp_json_encode( $reschedule_populate ) ); ?>">
                                                <em class="icon ni ni-calendar-alt"></em>
                                                <span><?php esc_html_e( 'زمان‌بندی مجدد', 'kasebi-erp' ); ?></span>
                                            </a>
                                        </li>
									<?php endif; ?>
									
									<?php if ( $status_key === 'pending' && kerp_can( 'followups.complete', 'action' ) ) : ?>
                                        <li>
                                            <a href="#"
                                               class="edit_row_item"
                                               data-modal="#followupCompleteModal-<?php echo esc_attr( $context ); ?>"
                                               data-populate="<?php echo esc_attr( wp_json_encode( $action_populate ) ); ?>">
                                                <em class="icon ni ni-check-circle"></em>
                                                <span><?php esc_html_e( 'ثبت نتیجه و تکمیل', 'kasebi-erp' ); ?></span>
                                            </a>
                                        </li>
									<?php endif; ?>
									
									<?php if ( $status_key === 'pending' && kerp_can( 'followups.cancel', 'action' ) ) : ?>
                                        <li>
                                            <a href="#"
                                               class="edit_row_item"
                                               data-modal="#followupCancelModal-<?php echo esc_attr( $context ); ?>"
                                               data-populate="<?php echo esc_attr( wp_json_encode( $cancel_populate ) ); ?>">
                                                <em class="icon ni ni-cross-circle"></em>
                                                <span><?php esc_html_e( 'لغو پیگیری', 'kasebi-erp' ); ?></span>
                                            </a>
                                        </li>
									<?php endif; ?>

                                    <li>
                                        <a href="#<?php echo esc_attr( $history_id ); ?>"
                                           data-bs-toggle="collapse"
                                           aria-expanded="false"
                                           aria-controls="<?php echo esc_attr( $history_id ); ?>">
                                            <em class="icon ni ni-history"></em>
                                            <span><?php esc_html_e( 'تاریخچه', 'kasebi-erp' ); ?></span>
                                        </a>
                                    </li>
									
									<?php if ( kerp_can( 'followups.delete', 'action' ) ) : ?>
                                        <li class="divider"></li>
                                        <li>
                                            <a href="#"
                                               class="delete_db_item"
                                               data-action="followups_delete"
                                               data-page="<?php echo esc_attr( $return_page ); ?>"
                                               data-followup_id="<?php echo esc_attr( $id ); ?>"
                                               data-item_id="<?php echo esc_attr( $id ); ?>"
                                               data-return_page="<?php echo esc_attr( $return_page ); ?>">
                                                <em class="icon ni ni-trash"></em>
                                                <span><?php esc_html_e( 'حذف', 'kasebi-erp' ); ?></span>
                                            </a>
                                        </li>
									<?php endif; ?>
                                </ul>
                            </div>
                        </div>
                    </li>
                </ul>
            </div>
            <div class="kerp-followup-card__meta mt-4">
				<?php
				if ( $context == 'main' ) {
					?>
                    <a href="<?php echo esc_url( home_url( $customer_url ) ); ?>" class="page_activator"
                       data-url="<?php echo esc_attr( $customer_url ); ?>"><em
                            class="icon ni ni-user"></em><span><?php echo esc_html( get_user_name_by_id( $customer_id ) ); ?></span></a>
					<?php
				}
				?>
                <span><em
                        class="icon ni ni-user-check"></em><span><?php echo esc_html( $assignee_id > 0 ? get_user_name_by_id( $assignee_id ) : '-' ); ?></span></span>
                <span class="<?php echo ! empty( $followup['is_overdue'] ) ? 'text-danger' : ''; ?>"><em
                        class="icon ni ni-calendar"></em><span><?php echo esc_html( $timestamp ? date_i18n( 'Y/m/d H:i', $timestamp ) : '-' ); ?></span></span>
            </div>
			<?php if ( trim( wp_strip_all_tags( (string) ( $followup['description'] ?? '' ) ) ) !== '' ) : ?>
                <div
                    class="kerp-followup-card__description mt-3"><?php echo wp_kses_post( wpautop( (string) $followup['description'] ) ); ?></div>
			<?php endif; ?>
			<?php if ( trim( wp_strip_all_tags( (string) ( $followup['outcome'] ?? '' ) ) ) !== '' ) : ?>
                <div class="alert alert-light mt-3 mb-0">
                    <strong><?php esc_html_e( 'نتیجه:', 'kasebi-erp' ); ?></strong> <?php echo wp_kses_post( (string) $followup['outcome'] ); ?>
                </div>
			<?php endif; ?>
            <div class="collapse mt-3" id="<?php echo esc_attr( $history_id ); ?>">
                <div class="border rounded p-3">
                    <span class="overline-title"><?php esc_html_e( 'تاریخچه تغییرات', 'kasebi-erp' ); ?></span>
					<?php if ( empty( $history ) ) : ?>
                        <p class="text-soft mb-0 mt-2"><?php esc_html_e( 'تاریخچه‌ای ثبت نشده است.', 'kasebi-erp' ); ?></p>
					<?php else : ?>
                        <ul class="list-unstyled mb-0 mt-2">
							<?php foreach ( $history as $history_item ) : ?>
								<?php $history_user_id = absint( $history_item['created_by'] ?? 0 ); ?>
                                <li class="d-flex align-items-start py-2 border-bottom" style="gap:10px;">
                                    <em class="icon ni ni-dot text-primary mt-1"></em>
                                    <div>
                                        <strong
                                            class="d-block"><?php echo esc_html( (string) ( $history_labels[ sanitize_key( (string) ( $history_item['event_key'] ?? '' ) ) ] ?? $history_item['event_key'] ?? '' ) ); ?></strong>
										<?php if ( trim( wp_strip_all_tags( (string) ( $history_item['note'] ?? '' ) ) ) !== '' ) : ?>
                                            <span
                                                class="text-soft d-block"><?php echo wp_kses_post( (string) $history_item['note'] ); ?></span><?php endif; ?>
                                        <small
                                            class="text-soft"><?php echo esc_html( $history_user_id > 0 ? get_user_name_by_id( $history_user_id ) : __( 'سیستم', 'kasebi-erp' ) ); ?>
                                            — <?php echo esc_html( date_i18n( 'Y/m/d H:i', strtotime( (string) ( $history_item['created_at'] ?? '' ) ) ) ); ?></small>
                                    </div>
                                </li>
							<?php endforeach; ?>
                        </ul>
					<?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
