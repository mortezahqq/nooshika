<?php

defined( 'ABSPATH' ) || exit;

if ( ! isset( $customer ) || ! $customer instanceof WP_User ) {
	return;
}
$customer_id = absint( $customer_id ?? $customer->ID );
$return_page = '/erp/customers/' . $customer_id . '/?tab=followups';
$followups   = KERP_Modules_Followups_Query::instance()->get_customer_items( $customer_id, 100 );
?>
<div class="kerp-customer-tab-controls">
    <div class="d-lg-none kerp-customer-mobile-nav"><a href="#" class="toggle btn btn-icon btn-trigger" data-target="customerAside" aria-label="<?php esc_attr_e( 'نمایش منوی کاربر', 'kasebi-erp' ); ?>"><em class="icon ni ni-menu-alt-r"></em></a></div>
	<?php if ( kerp_can( 'followups.create', 'action' ) ) : ?>
        <a href="#customerFollowupModal" class="btn btn-dim btn-primary btn-icon" data-bs-toggle="modal" data-bs-target="#customerFollowupModal" title="<?php esc_attr_e( 'افزودن پیگیری', 'kasebi-erp' ); ?>" aria-label="<?php esc_attr_e( 'افزودن پیگیری', 'kasebi-erp' ); ?>"><em class="icon ni ni-plus"></em></a>
	<?php endif; ?>
</div>
<?php KERP_Helpers_Template::render_template( 'app/components/customer-tab-hero.php', [
	'icon'        => 'ni ni-clock',
	'eyebrow'     => __( 'برنامه پیگیری', 'kasebi-erp' ),
	'title'       => __( 'پیگیری‌ها', 'kasebi-erp' ),
	'description' => __( 'سررسیدها، مسئولان و نتایج پیگیری', 'kasebi-erp' ),
] ); ?>
<div class="nk-block">
    <div class="row g-gs">
		<?php if ( empty( $followups ) ) : ?>
            <div class="col-12">
            <div class="card card-bordered">
                <div class="card-inner text-center py-5"><em class="kik fa-clock fs-1 text-soft"></em><h5
                        class="mt-3 mb-1"><?php esc_html_e( 'برای این کاربر پیگیری ثبت نشده است.', 'kasebi-erp' );
						?></h5>
                </div>
            </div></div><?php endif; ?>
		<?php foreach ( $followups as $followup ) {
			KERP_Helpers_Template::render_template( 'modules/followups/partials/followup-card.php', [
				'followup'    => $followup,
				'return_page' => $return_page,
				'context'     => 'customer',
			] );
		} ?>
    </div>
</div>
