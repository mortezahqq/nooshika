<?php

defined( 'ABSPATH' ) || exit;

$customer_id = absint( $customer_id ?? 0 );
$return_page = isset( $return_page ) && is_string( $return_page ) && $return_page !== '' ? $return_page : '/erp/followups/';
$modal_id    = sanitize_html_class( (string) ( $modal_id ?? 'followupModal' ) );
$current     = current_datetime()->modify( '+1 day' );
$minute      = intdiv( (int) $current->format( 'i' ), 30 ) * 30;
$current     = $current->setTime( (int) $current->format( 'H' ), $minute );
$fields      = [
	[
		'id'          => 'kerp-followup-id',
		'name'        => 'followup_id',
		'type'        => 'hidden',
		'input_class' => 'no_clear',
		'value'       => '',
	],
	[
		'id'          => 'kerp-followup-return-page',
		'name'        => 'return_page',
		'type'        => 'hidden',
		'input_class' => 'no_clear',
		'value'       => $return_page,
	],
];
if ( $customer_id > 0 ) {
	$fields[] = [
		'id'              => 'kerp-followup-customer-id',
		'name'            => 'customer_id',
		'type'            => 'customer-search',
		'value'           => $customer_id,
		'required'        => TRUE,
		'hide_on_profile' => TRUE,
		'input_class'     => 'no_clear',
	];
} else {
	$fields[] = [
		'id'            => 'kerp-followup-customer-id',
		'name'          => 'customer_id',
		'type'          => 'customer-search',
		'value'         => 0,
		'required'      => TRUE,
		'preview_label' => __( 'ثبت پیگیری برای:', 'kasebi-erp' ),
	];
}
$fields = array_merge( $fields, [
	[
		'id'       => 'kerp-followup-title',
		'name'     => 'title',
		'label'    => __( 'عنوان پیگیری', 'kasebi-erp' ),
		'type'     => 'text',
		'class'    => 'col-md-6',
		'value'    => '',
		'required' => TRUE,
	],
	[
		'id'          => 'kerp-followup-type-key',
		'name'        => 'type_key',
		'label'       => __( 'نوع پیگیری', 'kasebi-erp' ),
		'type'        => 'select',
		'class'       => 'col-md-6',
		'options'     => KERP_Modules_Followups_Settings::instance()->get_type_options(),
		'placeholder' => __( 'انتخاب نوع', 'kasebi-erp' ),
		'value'       => '',
		'required'    => TRUE,
	],
	[
		'id'          => 'kerp-followup-assignee-id',
		'name'        => 'assignee_id',
		'label'       => __( 'مسئول پیگیری', 'kasebi-erp' ),
		'type'        => 'select',
		'class'       => 'col-md-6',
		'options'     => KERP_Modules_Followups_Form::instance()->get_assignee_options(),
		'placeholder' => __( 'انتخاب کارمند', 'kasebi-erp' ),
		'value'       => get_current_user_id(),
		'required'    => TRUE,
	],
	[
		'id'       => 'kerp-followup-priority',
		'name'     => 'priority',
		'label'    => __( 'اولویت', 'kasebi-erp' ),
		'type'     => 'select',
		'class'    => 'col-md-6',
		'options'  => KERP_Modules_Followups_Settings::instance()->get_priority_options(),
		'value'    => KERP_Modules_Followups_Settings::instance()->get( 'default_priority', 'normal' ),
		'required' => TRUE,
	],
	[
		'id'          => 'kerp-followup-due-date',
		'name'        => 'due_date',
		'label'       => __( 'تاریخ سررسید', 'kasebi-erp' ),
		'type'        => 'date',
		'class'       => 'col-md-6',
		'input_class' => 'persian-date',
		'value'       => date_i18n( 'Y-m-d', $current->getTimestamp() ),
		'required'    => TRUE,
	],
	[
		'id'          => 'kerp-followup-due-time',
		'name'        => 'due_time',
		'label'       => __( 'ساعت سررسید', 'kasebi-erp' ),
		'type'        => 'text',
		'class'       => 'col-md-6',
		'input_class' => 'time-picker',
		'value'       => $current->format( 'H:i' ),
		'required'    => TRUE,
	],
	[
		'id'    => 'kerp-followup-description',
		'name'  => 'description',
		'label' => __( 'شرح پیگیری', 'kasebi-erp' ),
		'type'  => 'quill',
		'class' => 'col-12',
		'value' => '',
	],
	[
		'id'             => 'kerp-followup-attachment',
		'name'           => 'attachment',
		'label'          => __( 'فایل ضمیمه', 'kasebi-erp' ),
		'type'           => 'upload',
		'class'          => 'col-12',
		'value'          => '',
		'action'         => 'handle_file_upload',
		'max_files'      => 5,
		'accepted_files' => '',
	],
] );
KERP_Helpers_Template::render_modal( [
	'id'     => $modal_id,
	'title'  => __( 'افزودن یا ویرایش پیگیری', 'kasebi-erp' ),
	'action' => 'followups_save',
	'page'   => $return_page,
	'button' => __( 'ذخیره پیگیری', 'kasebi-erp' ),
	'size'   => 'lg',
	'fields' => $fields,
] );
