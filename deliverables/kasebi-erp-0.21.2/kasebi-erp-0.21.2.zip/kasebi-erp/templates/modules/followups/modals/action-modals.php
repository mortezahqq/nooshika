<?php

defined( 'ABSPATH' ) || exit;

$return_page = isset( $return_page ) && is_string( $return_page ) && $return_page !== '' ? $return_page : '/erp/followups/';
$context     = sanitize_html_class( (string) ( $context ?? 'main' ) );
if ( kerp_can( 'followups.complete', 'action' ) ) {
	KERP_Helpers_Template::render_modal( [
		'id'     => 'followupCompleteModal-' . $context,
		'title'  => __( 'تکمیل پیگیری', 'kasebi-erp' ),
		'action' => 'followups_complete',
		'page'   => $return_page,
		'button' => __( 'ثبت نتیجه و تکمیل', 'kasebi-erp' ),
		'size'   => 'md',
		'fields' => [
			[
				'id'          => 'kerp-followup-complete-id-' . $context,
				'name'        => 'followup_id',
				'type'        => 'hidden',
				'input_class' => 'no_clear',
				'value'       => '',
			],
			[
				'id'          => 'kerp-followup-complete-return-' . $context,
				'name'        => 'return_page',
				'type'        => 'hidden',
				'input_class' => 'no_clear',
				'value'       => $return_page,
			],
			[
				'id'    => 'kerp-followup-outcome-' . $context,
				'name'  => 'outcome',
				'label' => __( 'نتیجه پیگیری', 'kasebi-erp' ),
				'type'  => 'quill',
				'class' => 'col-12',
				'rows'  => 5,
				'value' => '',
			],
		],
	] );
}
if ( kerp_can( 'followups.cancel', 'action' ) ) {
	KERP_Helpers_Template::render_modal( [
		'id'     => 'followupCancelModal-' . $context,
		'title'  => __( 'لغو پیگیری', 'kasebi-erp' ),
		'action' => 'followups_cancel',
		'page'   => $return_page,
		'button' => __( 'لغو پیگیری', 'kasebi-erp' ),
		'size'   => 'md',
		'fields' => [
			[
				'id'          => 'kerp-followup-cancel-id-' . $context,
				'name'        => 'followup_id',
				'type'        => 'hidden',
				'input_class' => 'no_clear',
				'value'       => '',
			],
			[
				'id'          => 'kerp-followup-cancel-return-' . $context,
				'name'        => 'return_page',
				'type'        => 'hidden',
				'input_class' => 'no_clear',
				'value'       => $return_page,
			],
			[
				'id'    => 'kerp-followup-cancel-note-' . $context,
				'name'  => 'note',
				'label' => __( 'دلیل لغو', 'kasebi-erp' ),
				'type'  => 'quill',
				'class' => 'col-12',
				'rows'  => 4,
				'value' => '',
			],
		],
	] );
}
if ( kerp_can( 'followups.edit', 'action' ) ) {
	KERP_Helpers_Template::render_modal( [
		'id'     => 'followupRescheduleModal-' . $context,
		'title'  => __( 'زمان‌بندی مجدد پیگیری', 'kasebi-erp' ),
		'action' => 'followups_reschedule',
		'page'   => $return_page,
		'button' => __( 'ثبت زمان جدید', 'kasebi-erp' ),
		'size'   => 'md',
		'fields' => [
			[
				'id'          => 'kerp-followup-reschedule-id-' . $context,
				'name'        => 'followup_id',
				'type'        => 'hidden',
				'input_class' => 'no_clear',
				'value'       => '',
			],
			[
				'id'          => 'kerp-followup-reschedule-return-' . $context,
				'name'        => 'return_page',
				'type'        => 'hidden',
				'input_class' => 'no_clear',
				'value'       => $return_page,
			],
			[
				'id'          => 'kerp-followup-reschedule-date-' . $context,
				'name'        => 'due_date',
				'label'       => __( 'تاریخ جدید', 'kasebi-erp' ),
				'type'        => 'date',
				'class'       => 'col-md-6',
				'input_class' => 'persian-date no_clear',
				'value'       => '',
			],
			[
				'id'          => 'kerp-followup-reschedule-time-' . $context,
				'name'        => 'due_time',
				'label'       => __( 'ساعت جدید', 'kasebi-erp' ),
				'type'        => 'text',
				'class'       => 'col-md-6',
				'input_class' => 'time-picker no_clear',
				'value'       => '',
			],
			[
				'id'    => 'kerp-followup-reschedule-note-' . $context,
				'name'  => 'note',
				'label' => __( 'توضیح تغییر زمان', 'kasebi-erp' ),
				'type'  => 'quill',
				'class' => 'col-12',
				'rows'  => 3,
				'value' => '',
			],
		],
	] );
}
