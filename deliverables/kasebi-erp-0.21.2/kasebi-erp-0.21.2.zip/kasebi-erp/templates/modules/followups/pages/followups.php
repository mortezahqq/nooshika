<?php

defined( 'ABSPATH' ) || exit;

$page_context = isset( $page_context ) && is_array( $page_context ) ? $page_context : [];
$page_query   = isset( $page_context['query'] ) && is_array( $page_context['query'] ) ? $page_context['query'] : [];
$page_route   = '/erp/followups/';
$due          = isset( $page_query['due'] ) && is_array( $page_query['due'] ) ? $page_query['due'] : [];
$per_page     = KERP_Helpers_Pagination::resolve_per_page(
	basename( __FILE__, '.php' ),
	$page_query,
	(int) KERP_Modules_Followups_Settings::instance()->get( 'default_per_page', 20 ),
	200
);
$query_args   = [
	'status'      => sanitize_key( (string) ( $page_query['status'] ?? '' ) ),
	'type_key'    => sanitize_key( (string) ( $page_query['type_key'] ?? '' ) ),
	'assignee_id' => absint( $page_query['assignee_id'] ?? 0 ),
	'priority'    => sanitize_key( (string) ( $page_query['priority'] ?? '' ) ),
	'search'      => sanitize_text_field( (string) ( $page_query['search'] ?? '' ) ),
	'due_from'    => sanitize_text_field( (string) ( $due['from'] ?? '' ) ),
	'due_to'      => sanitize_text_field( (string) ( $due['to'] ?? '' ) ),
	'page_number' => max( 1, absint( $page_query['page_number'] ?? 1 ) ),
	'per_page'    => $per_page,
];

$result      = KERP_Modules_Followups_Query::instance()->find( $query_args );
$followups   = (array) ( $result['items'] ?? [] );
$total       = absint( $result['total'] ?? 0 );
$total_pages = max( 1, absint( $result['total_pages'] ?? 1 ) );
$page_number = max( 1, absint( $result['page_number'] ?? 1 ) );
$per_page    = max( 1, absint( $result['per_page'] ?? 20 ) );
$counts      = KERP_Modules_Followups_Query::instance()->get_counts();
$filters     = KERP_Modules_Followups_List_Table::instance()
                                                ->get_filters( array_merge( $page_query, [ 'due' => $due ] ) );
$has_filter  = ! empty( array_filter( [
	$query_args['status'],
	$query_args['type_key'],
	$query_args['assignee_id'],
	$query_args['priority'],
	$query_args['search'],
	$query_args['due_from'],
	$query_args['due_to'],
] ) );
$can_create  = kerp_can( 'followups.create', 'action' );
?>
<div class="nk-block-head nk-block-head-sm">
    <div class="nk-block-between">
        <div class="nk-block-head-content"><h3
                class="nk-block-title page-title"><?php esc_html_e( 'پیگیری‌ها', 'kasebi-erp' ); ?></h3>
            <div class="nk-block-des text-soft">
                <p><?php printf( esc_html__( 'در مجموع %s پیگیری ثبت شده است.', 'kasebi-erp' ), esc_html( number_format_i18n( $total ) ) ); ?></p>
            </div>
        </div>
		<?php if ( $can_create ) : ?>
            <div class="nk-block-head-content"><a href="#followupModal" class="btn btn-primary" data-bs-toggle="modal"
                                                  data-bs-target="#followupModal"><em
                    class="icon ni ni-plus"></em><span><?php esc_html_e( 'افزودن پیگیری', 'kasebi-erp' ); ?></span></a>
            </div><?php endif; ?>
    </div>
</div>
<div class="nk-block">
    <div class="row g-gs">
        <div class="col-sm-6 col-xl-3">
            <div class="card card-bordered">
                <div class="card-inner">
                    <div class="d-flex align-center justify-between">
                        <div><span class="sub-text"><?php esc_html_e( 'در انتظار', 'kasebi-erp' ); ?></span><span
                                class="fs-24px fw-bold d-block"><?php echo esc_html( number_format_i18n( $counts['pending'] ) ); ?></span>
                        </div>
                        <em class="icon ni ni-clock fs-32px text-warning"></em></div>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-xl-3">
            <div class="card card-bordered">
                <div class="card-inner">
                    <div class="d-flex align-center justify-between">
                        <div><span class="sub-text"><?php esc_html_e( 'امروز', 'kasebi-erp' ); ?></span><span
                                class="fs-24px fw-bold d-block"><?php echo esc_html( number_format_i18n( $counts['today'] ) ); ?></span>
                        </div>
                        <em class="icon ni ni-calendar-check fs-32px text-info"></em></div>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-xl-3">
            <div class="card card-bordered">
                <div class="card-inner">
                    <div class="d-flex align-center justify-between">
                        <div><span class="sub-text"><?php esc_html_e( 'عقب‌افتاده', 'kasebi-erp' ); ?></span><span
                                class="fs-24px fw-bold d-block"><?php echo esc_html( number_format_i18n( $counts['overdue'] ) ); ?></span>
                        </div>
                        <em class="icon ni ni-alert-circle fs-32px text-danger"></em></div>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-xl-3">
            <div class="card card-bordered">
                <div class="card-inner">
                    <div class="d-flex align-center justify-between">
                        <div><span class="sub-text"><?php esc_html_e( 'انجام‌شده', 'kasebi-erp' ); ?></span><span
                                class="fs-24px fw-bold d-block"><?php echo esc_html( number_format_i18n( $counts['completed'] ) ); ?></span>
                        </div>
                        <em class="icon ni ni-check-circle fs-32px text-success"></em></div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="nk-block">
    <div class="card card-bordered">
        <div class="card-inner position-relative card-tools-toggle">
            <div class="card-title-group">
                <div class="card-tools"><span
                        class="text-soft"><?php esc_html_e( 'فهرست پیگیری‌ها', 'kasebi-erp' ); ?></span></div>
                <div class="card-tools">
                    <ul class="btn-toolbar gx-1">
                        <li><?php echo KERP_Helpers_Template::get_template( 'app/components/list/filter-dropdown.php', [
								'has_filter'    => $has_filter,
								'filter_fields' => $filters,
								'action'        => 'erp_request_page_content',
								'page'          => $page_route,
							] ); ?></li>
                        <li class="btn-toolbar-sep"></li>
                        <li><?php echo KERP_Helpers_Template::get_template( 'app/components/list/per-page-selector.php', [
								'per_page'            => $per_page,
								'available_per_pages' => [
									10,
									20,
									50,
									100,
								],
								'action'              => 'erp_request_page_content',
								'page'                => $page_route,
							] ); ?></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="nk-block">
    <div class="row g-gs">
		<?php if ( empty( $followups ) ) : ?>
            <div class="col-12">
            <div class="card card-bordered">
                <div class="card-inner text-center py-5"><em class="kik fa-clock fs-1 text-soft"></em><h5
                        class="mt-3 mb-1"><?php esc_html_e( 'پیگیری‌ای پیدا نشد.', 'kasebi-erp' ); ?></h5>
                    <p class="text-soft mb-0"><?php esc_html_e( 'فیلترها را تغییر دهید یا یک پیگیری جدید ثبت کنید.', 'kasebi-erp' ); ?></p>
                </div>
            </div></div><?php endif; ?>
		<?php foreach ( $followups as $followup ) {
			KERP_Helpers_Template::render_template( 'modules/followups/partials/followup-card.php', [
				'followup'    => $followup,
				'return_page' => $page_route,
				'context'     => 'main',
			] );
		} ?>
    </div>
</div>
<?php if ( $total_pages > 1 ) : ?>
    <div class="nk-block">
    <div class="card card-bordered">
        <div class="card-inner"><?php echo KERP_Helpers_Template::get_template( 'app/components/list/pagination.php', [
				'max_page_num' => $total_pages,
				'current_page' => $page_number,
				'class_name'   => 'followups_pagination_link',
				'show_count'   => 2,
				'action'       => 'erp_request_page_content',
				'page'         => $page_route,
			] ); ?></div>
    </div></div><?php endif; ?>
<?php if ( $can_create || kerp_can( 'followups.edit', 'action' ) ) {
	KERP_Modules_Followups_Form::instance()->render_modal( 0, $page_route, 'followupModal' );
} ?>
<?php KERP_Modules_Followups_Form::instance()->render_action_modals( $page_route, 'main' ); ?>
