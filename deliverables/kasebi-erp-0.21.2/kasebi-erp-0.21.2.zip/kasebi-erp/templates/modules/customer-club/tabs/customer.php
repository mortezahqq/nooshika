<?php
defined( 'ABSPATH' ) || exit;
$user_id = absint( $customer_id ?? 0 );
$unit = KERP_Modules_Customer_Club_Settings::label();
$balance = KERP_Modules_Customer_Club_Store::balance( $user_id );
$history = KERP_Modules_Customer_Club_Store::history( $user_id, 50 );
?>
<div class="kerp-customer-tab-controls d-lg-none">
    <div class="kerp-customer-mobile-nav">
        <a href="#" class="toggle btn btn-icon btn-trigger" data-target="customerAside" aria-label="<?php esc_attr_e( 'نمایش منوی کاربر', 'kasebi-erp' ); ?>"><em class="icon ni ni-menu-alt-r"></em></a>
    </div>
</div>
<?php KERP_Helpers_Template::render_template( 'app/components/customer-tab-hero.php', [
	'icon'        => 'ni ni-star',
	'eyebrow'     => __( 'وفاداری مشتری', 'kasebi-erp' ),
	'title'       => __( 'باشگاه مشتریان', 'kasebi-erp' ),
	'description' => sprintf( __( 'موجودی و تاریخچه %s این کاربر', 'kasebi-erp' ), $unit ),
] ); ?>
<div class="card card-bordered"><div class="card-inner"><h5 class="title">موجودی: <?php echo esc_html( number_format_i18n( $balance ) . ' ' . $unit ); ?></h5></div><div class="table-responsive"><table class="table"><thead><tr><th>شرح</th><th>تغییر</th><th>تاریخ</th></tr></thead><tbody><?php foreach ( $history as $row ) : ?><tr><td><?php echo esc_html( $row['description'] ); ?></td><td><?php echo esc_html( number_format_i18n( $row['amount'] ) ); ?></td><td><?php echo esc_html( mysql2date( 'Y/m/d H:i', $row['created_at'] ) ); ?></td></tr><?php endforeach; ?></tbody></table></div></div>
