<?php
defined( 'ABSPATH' ) || exit;
if ( ! kerp_can( 'customer_club.manage', 'action' ) ) {
	return;
}
$s       = KERP_Modules_Customer_Club_Settings::all();
$labels  = [ 'comment_approved' => 'تأیید دیدگاه', 'article_read' => 'مطالعه مقاله', 'birthday' => 'روز تولد' ];
$periods = [ 'day' => 'روزانه', 'week' => 'هفتگی', 'month' => 'ماهانه', 'year' => 'سالانه', 'lifetime' => 'کل دوره' ];
?>
<form class="modal_form" data-action="customer_club_settings" data-page="/erp/settings/customer-club/">
    <input type="hidden" name="nonce" value="<?php echo esc_attr( wp_create_nonce( 'kerp_customer_club' ) ); ?>">
    <div class="nk-block-head nk-block-head-sm">
        <div class="nk-block-between">
            <div class="nk-block-head-content"><h3 class="nk-block-title page-title">تنظیمات باشگاه مشتریان</h3>
                <div class="nk-block-des text-soft"><p>واحد امتیاز، قوانین دریافت، سقف‌ها و انقضای سکه را مدیریت
                        کنید.</p></div>
            </div>
            <div class="nk-block-head-content">
                <button type="button" class="btn btn-primary submit_modal_form"><em class="icon ni ni-save"></em><span>ذخیره تنظیمات</span>
                </button>
            </div>
        </div>
    </div>
    <div class="nk-block">
        <div class="row g-gs">
            <div class="col-xl-6">
                <div class="card card-bordered h-100">
                    <div class="card-inner border-bottom"><h6 class="title mb-1">هویت امتیاز</h6>
                        <p class="text-soft mb-0">عنوان، رنگ، آیکن یا تصویر در تمام بخش‌های باشگاه استفاده می‌شود.</p>
                    </div>
                    <div class="card-inner">
                        <div class="row g-4">
                            <div class="col-12">
                                <div class="custom-control custom-switch"><input type="checkbox"
                                                                                 class="custom-control-input"
                                                                                 id="club-enabled" name="enabled"
                                                                                 value="1" <?php checked( $s['enabled'] ); ?>><label
                                        class="custom-control-label" for="club-enabled">باشگاه فعال باشد</label></div>
                            </div>
                            <div class="col-md-6"><label class="form-label">عنوان واحد</label><input
                                    class="form-control" name="unit_name" maxlength="30" required
                                    value="<?php echo esc_attr( $s['unit_name'] ); ?>"></div>
                            <div class="col-md-6"><label class="form-label">کلاس آیکن</label><input class="form-control"
                                                                                                    name="unit_icon"
                                                                                                    value="<?php echo esc_attr( $s['unit_icon'] ); ?>"
                                                                                                    placeholder="ni ni-coins">
                            </div>
                            <div class="col-md-6"><label class="form-label">رنگ</label><input
                                    class="form-control form-control-color" type="color" name="unit_color"
                                    value="<?php echo esc_attr( $s['unit_color'] ); ?>"></div>
                            <div class="col-md-6 kc-media-field"><label class="form-label">تصویر واحد</label><input
                                    type="hidden" name="unit_image_id"
                                    value="<?php echo esc_attr( $s['unit_image_id'] ); ?>">
                                <div class="kc-media-preview"><?php if ( $s['unit_image_id'] ) {
										echo wp_kses_post( wp_get_attachment_image( $s['unit_image_id'], 'thumbnail' ) );
									} ?></div>
                                <button type="button" class="btn btn-light btn-sm kc-media-select">انتخاب تصویر</button>
                                <button type="button" class="btn btn-light btn-sm kc-media-remove">حذف</button>
                                <small class="text-soft d-block">بدون تصویر، آیکن استفاده می‌شود.</small></div>
                            <div class="col-12"><label class="form-label">انقضای سکه (روز)</label><input
                                    class="form-control" type="number" min="0" name="expiration_days"
                                    value="<?php echo esc_attr( $s['expiration_days'] ); ?>"><small class="text-soft">صفر
                                    یعنی بدون انقضا. هنگام خرج، سکه‌هایی که زودتر منقضی می‌شوند اول مصرف
                                    می‌شوند.</small></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-6">
                <div class="card card-bordered h-100">
                    <div class="card-inner border-bottom"><h6 class="title mb-1">امتیاز خرید</h6>
                        <p class="text-soft mb-0">فقط مبلغ نهایی محصول پس از تخفیف و کسر کیف پول؛ ارسال و مالیات محاسبه
                            نمی‌شوند.</p></div>
                    <div class="card-inner">
                        <div class="row g-4">
                            <div class="col-md-7"><label class="form-label">هر مبلغ خرید</label><input
                                    class="form-control price_input" type="number" min="1" name="purchase_step"
                                    value="<?php echo esc_attr( $s['purchase_step'] ); ?>"></div>
                            <div class="col-md-5"><label
                                    class="form-label">تعداد <?php echo esc_html( $s['unit_name'] ); ?></label><input
                                    class="form-control" type="number" min="1" name="purchase_coins"
                                    value="<?php echo esc_attr( $s['purchase_coins'] ); ?>"></div>
                            <div class="col-12">
                                <div class="alert alert-light mb-0">جزء باقی‌مانده هر سفارش منتقل نمی‌شود. پرداخت‌های
                                    مرحله‌ای همان سفارش تجمیع می‌شوند و در مرجوعی، سکه متناسب پس گرفته می‌شود.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12">
                <div class="card card-bordered">
                    <div class="card-inner border-bottom"><h6 class="title mb-1">قوانین فعالیت</h6>
                        <p class="text-soft mb-0">هر رویداد مقدار و سقف مستقل دارد. سقف صفر یعنی نامحدود.</p></div>
                    <div class="card-inner">
                        <div class="row g-gs">
							<?php foreach ( $labels
							
							as $event => $label ) :
							$rule = $s['rules'][ $event ]; ?>
                            <div class="col-lg-4">
                                <div class="card card-bordered h-100">
                                    <div class="card-inner">
                                        <div class="custom-control custom-switch mb-3"><input type="checkbox"
                                                                                              class="custom-control-input"
                                                                                              id="rule-<?php echo esc_attr( $event ); ?>"
                                                                                              name="rules[<?php echo esc_attr( $event ); ?>][enabled]"
                                                                                              value="1" <?php checked( $rule['enabled'] ); ?>><label
                                                class="custom-control-label"
                                                for="rule-<?php echo esc_attr( $event ); ?>"><?php echo esc_html( $label ); ?></label>
                                        </div>
                                        <div class="form-group"><label class="form-label">سکه هر بار</label><input
                                                class="form-control" type="number" min="1"
                                                name="rules[<?php echo esc_attr( $event ); ?>][coins]"
                                                value="<?php echo esc_attr( $rule['coins'] ); ?>"></div>
                                        <div class="form-group"><label class="form-label">سقف دفعات</label><input
                                                class="form-control" type="number" min="0"
                                                name="rules[<?php echo esc_attr( $event ); ?>][limit]"
                                                value="<?php echo esc_attr( $rule['limit'] ); ?>"></div>
                                        <div class="form-group mb-0"><label class="form-label">دوره سقف</label><select
                                                class="form-select"
                                                name="rules[<?php echo esc_attr( $event ); ?>][period]"><?php foreach ( $periods as $key => $text ) : ?>
                                                    <option
                                                    value="<?php echo esc_attr( $key ); ?>" <?php selected( $rule['period'], $key ); ?>><?php echo esc_html( $text ); ?></option><?php endforeach; ?>
                                            </select></div>
                                    </div>
                                </div>
								<?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</form>
