<?php

defined( 'ABSPATH' ) || exit;

/**
 * @var int    $customer_id
 * @var string $return_page
 */

$customer_id   = absint( $customer_id ?? 0 );
$return_page   = isset( $return_page ) && is_string( $return_page )
	? $return_page
	: '/erp/customers/' . $customer_id . '/?tab=notes';
$notes_service = KERP_Modules_Customers_Notes::instance();
$modal         = [
	'id'          => 'customerNoteModal',
	'title'       => __( 'ثبت یادداشت', 'kasebi-erp' ),
	'action'      => 'customers_notes_save',
	'page'        => $return_page,
	'button'      => __( 'ذخیره یادداشت', 'kasebi-erp' ),
	'button_text' => __( 'ذخیره یادداشت', 'kasebi-erp' ),
	'size'        => 'lg',
	'fields'      => [
		[
			'id'    => 'kerp-customer-note-id',
			'name'  => 'note_id',
			'type'  => 'hidden',
			'value' => 0,
		],
		[
			'id'    => 'kerp-customer-note-customer-id',
			'name'  => 'customer_id',
			'type'  => 'hidden',
			'class' => 'no_clear',
			'value' => $customer_id,
		],
		[
			'id'       => 'kerp-customer-note-type',
			'name'     => 'type',
			'type'     => 'select',
			'label'    => __( 'نوع یادداشت', 'kasebi-erp' ),
			'class'    => 'col-md-6',
			'options'  => $notes_service->get_type_options(),
			'value'    => 'general',
			'required' => TRUE,
		],
		[
			'id'       => 'kerp-customer-note-visibility',
			'name'     => 'visibility',
			'type'     => 'select',
			'label'    => __( 'سطح نمایش', 'kasebi-erp' ),
			'class'    => 'col-md-6',
			'options'  => $notes_service->get_visibilities(),
			'value'    => KERP_Modules_Customers_Notes::VISIBILITY_ALL_STAFF,
			'required' => TRUE,
		],
		[
			'id'          => 'kerp-customer-note-content',
			'name'        => 'content',
			'type'        => 'textarea',
			'label'       => __( 'متن یادداشت', 'kasebi-erp' ),
			'placeholder' => __( 'مثلاً: این کاربر بنگاه‌دار است و با لحن رسمی و محترمانه با او صحبت شود.', 'kasebi-erp' ),
			'class'       => 'col-12',
			'rows'        => 5,
			'required'    => TRUE,
		],
		[
			'id'    => 'kerp-customer-note-is-pinned',
			'name'  => 'is_pinned',
			'type'  => 'switch',
			'label' => __( 'در بالای پروفایل کاربر نمایش داده شود', 'kasebi-erp' ),
			'class' => 'col-12',
			'value' => 0,
		],
	],
];
KERP_Helpers_Template::render_modal( $modal );
