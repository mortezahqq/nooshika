<?php

defined( 'ABSPATH' ) || exit;

/**
 * @var array $page_context
 */

$page_context = isset( $page_context ) && is_array( $page_context )
	? $page_context
	: [];

$page_query = isset( $page_context['query'] ) && is_array( $page_context['query'] )
	? $page_context['query']
	: [];

$settings_service = KERP_Modules_Customers_Settings::instance();
$query_service    = KERP_Modules_Customers_Query::instance();
$list_table       = KERP_Modules_Customers_List_Table::instance();
$taxonomies       = KERP_Modules_Customers_Taxonomies::instance();

$per_page = KERP_Helpers_Pagination::resolve_per_page(
	basename( __FILE__, '.php' ),
	$page_query,
	(int) $settings_service->get( 'default_per_page', 20 )
);

$plural_label   = $settings_service->get_plural_label();
$singular_label = $settings_service->get_singular_label();
$page_route     = '/erp/customers/';
$query_args     = array_merge(
	$page_query,
	[
		'page_number' => max( 1, absint( $page_query['page_number'] ?? 1 ) ),
		'per_page'    => $per_page,
		'orderby'     => sanitize_key( (string) ( $page_query['orderby'] ?? 'registered' ) ),
		'order'       => strtoupper( (string) ( $page_query['order'] ?? 'DESC' ) ) === 'ASC'
			? 'ASC'
			: 'DESC',
	]
);
$result         = $query_service->find( $query_args );

if (
	! empty( $result['total_pages'] )
	&& (int) $result['page_number'] > (int) $result['total_pages']
) {
	$query_args['page_number'] = (int) $result['total_pages'];
	$result                    = $query_service->find( $query_args );
}

$customers    = isset( $result['items'] ) && is_array( $result['items'] )
	? $result['items']
	: [];
$total        = absint( $result['total'] ?? 0 );
$per_page     = max( 1, absint( $result['per_page'] ?? $query_args['per_page'] ) );
$page_number  = max( 1, absint( $result['page_number'] ?? $query_args['page_number'] ) );
$total_pages  = max( 1, absint( $result['total_pages'] ?? 1 ) );
$request_args = isset( $result['request_args'] ) && is_array( $result['request_args'] )
	? $result['request_args']
	: $query_args;

$filters      = $list_table->get_filters( $request_args );
$columns      = $list_table->get_columns();
$bulk_actions = $list_table->get_bulk_actions();
$first_touches = KERP_Services_Attribution_First_Touch::instance()->get_list_data(
	array_map( static fn( $customer ): int => $customer instanceof WP_User ? (int) $customer->ID : 0, $customers )
);
$per_page_query = $page_query;
unset( $per_page_query['page_number'], $per_page_query['per_page'] );

$has_filter = FALSE;

foreach ( array_keys( $filters ) as $filter_key ) {
	$value = $request_args[ $filter_key ] ?? '';
	
	if ( is_array( $value ) ? ! empty( $value ) : $value !== '' && ( str_starts_with( $filter_key, 'first_touch_' ) || ( $value !== 0 && $value !== '0' ) ) ) {
		$has_filter = TRUE;
		break;
	}
}

$available_per_pages = apply_filters(
	'kerp_customers_available_per_pages',
	[ 10, 20, 50, 100 ],
	$per_page
);

$owner_options = [];
$owner_users   = get_users(
	apply_filters(
		'kerp_customers_owner_query_args',
		[
			'number'       => 200,
			'orderby'      => 'display_name',
			'order'        => 'ASC',
			'fields'       => 'all',
			'role__not_in' => (array) $settings_service->get( 'customer_roles', [] ),
		]
	)
);

foreach ( $owner_users as $owner ) {
	if ( $owner instanceof WP_User ) {
		$owner_options[ $owner->ID ] = get_user_name_by_id( $owner->ID );
	}
}

$owner_options = apply_filters( 'kerp_customers_owner_options', $owner_options );

$bulk_need_fields = [
	'label'    => [
		'type'        => 'select',
		'label'       => __( 'برچسب', 'kasebi-erp' ),
		'placeholder' => __( 'یک برچسب انتخاب کنید', 'kasebi-erp' ),
		'options'     => $taxonomies->get_options( KERP_Modules_Customers_Taxonomies::TYPE_LABEL ),
	],
	'tag'      => [
		'type'        => 'select',
		'label'       => __( 'تگ', 'kasebi-erp' ),
		'placeholder' => __( 'یک تگ انتخاب کنید', 'kasebi-erp' ),
		'options'     => $taxonomies->get_options( KERP_Modules_Customers_Taxonomies::TYPE_TAG ),
	],
	'source'   => [
		'type'        => 'select',
		'label'       => __( 'شیوه آشنایی', 'kasebi-erp' ),
		'placeholder' => __( 'شیوه آشنایی را انتخاب کنید', 'kasebi-erp' ),
		'options'     => $taxonomies->get_options( KERP_Modules_Customers_Taxonomies::TYPE_SOURCE ),
	],
	'owner_id' => [
		'type'        => 'select',
		'label'       => sprintf(
			__( 'مسئول %s', 'kasebi-erp' ),
			$singular_label
		),
		'placeholder' => __( 'مسئول را انتخاب کنید', 'kasebi-erp' ),
		'options'     => $owner_options,
	],
];

$bulk_need_fields = apply_filters(
	'kerp_customers_bulk_need_fields',
	$bulk_need_fields,
	$bulk_actions
);

?>
<div class="nk-block-head nk-block-head-sm">
    <div class="nk-block-between">
        <div class="nk-block-head-content">
            <h3 class="nk-block-title page-title">
				<?php echo esc_html( $plural_label ); ?>
            </h3>
            <div class="nk-block-des text-soft">
                <p class="mb-0">
					<?php
					printf(
					/* translators: 1: total count, 2: plural customer label. */
						esc_html__( 'در مجموع %1$s %2$s ثبت شده است.', 'kasebi-erp' ),
						number_format_i18n( $total ),
						esc_html( $plural_label )
					);
					?>
                </p>
            </div>
        </div>
    </div>
</div>

<div class="nk-block">
    <div class="card card-stretch m-0 kerp-customers-list-card">
        <div class="card-inner-group">
            <div class="card-inner position-relative card-tools-toggle">
                <div class="card-title-group">
                    <div class="card-tools">
						<?php
						echo KERP_Helpers_Template::get_template(
							'app/components/list/bulk-actions.php',
							[
								'actions'       => $bulk_actions,
								'need_fields'   => $bulk_need_fields,
								'action'        => 'customers_bulk_action',
								'page'          => $page_route,
								'item_selector' => '.select_item_row',
							]
						);
						?>
                    </div>

                    <div class="card-tools">
                        <ul class="btn-toolbar gx-1">
                            <li>
								<?php
								echo KERP_Helpers_Template::get_template(
									'app/components/list/filter-dropdown.php',
									[
										'has_filter'    => $has_filter,
										'filter_fields' => $filters,
										'action'        => 'erp_request_page_content',
										'page'          => $page_route,
									]
								);
								?>
                            </li>

                            <li class="btn-toolbar-sep"></li>

                            <li>
								<?php
								echo KERP_Helpers_Template::get_template(
									'app/components/list/per-page-selector.php',
									[
										'per_page'            => $per_page,
										'available_per_pages' => $available_per_pages,
										'action'              => 'erp_request_page_content',
										'page'                => add_query_arg( $per_page_query, $page_route ),
									]
								);
								?>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>

            <?php if ( empty( $customers ) ) : ?>
                <div class="card-inner text-center py-5">
                    <em class="icon ni ni-users fs-1 text-soft"></em>
                    <h5 class="mt-3"><?php printf( esc_html__( '%s یافت نشد.', 'kasebi-erp' ), esc_html( $singular_label ) ); ?></h5>
                    <p class="text-soft mb-0"><?php echo $has_filter ? esc_html__( 'فیلترها را تغییر دهید و دوباره بررسی کنید.', 'kasebi-erp' ) : esc_html__( 'پس از ثبت مشتری، اطلاعات او در این بخش نمایش داده می‌شود.', 'kasebi-erp' ); ?></p>
                </div>
            <?php else : ?>
            <div class="card-inner p-0">
                <div class="nk-tb-list nk-tb-ulist is-compact kerp-customers-list">
                    <div class="nk-tb-item nk-tb-head">
                        <div class="nk-tb-col nk-tb-col-check">
                            <div class="custom-control custom-control-sm custom-checkbox notext">
                                <input
                                    type="checkbox"
                                    class="custom-control-input select_all_rows"
                                    id="kerp-customers-select-all"
                                    data-target=".select_item_row"
                                >
                                <label class="custom-control-label" for="kerp-customers-select-all"><span class="kerp-customer-select-label"><?php esc_html_e( 'انتخاب همه', 'kasebi-erp' ); ?></span></label>
                            </div>
                        </div>
						
						<?php foreach ( $columns as $column_key => $column ) : ?>
							<?php
							if ( ! is_array( $column ) ) {
								continue;
							}
							
							$column_class = sanitize_text_field( (string) ( $column['class'] ?? '' ) );
							?>
                            <div class="nk-tb-col <?php echo esc_attr( $column_class ); ?>">
								<span class="sub-text">
									<?php echo esc_html( (string) ( $column['label'] ?? $column_key ) ); ?>
								</span>
                            </div>
						<?php endforeach; ?>
                        <div class="nk-tb-col nk-tb-col-tools"></div>
                    </div>
						<?php foreach ( $customers as $customer ) : ?>
							<?php
							if ( ! $customer instanceof WP_User ) {
								continue;
							}
							
							echo KERP_Helpers_Template::get_template(
								'modules/customers/partials/list-row.php',
								[
									'customer'   => $customer,
									'columns'    => $columns,
									'list_table' => $list_table,
									'context'    => [
										'first_touches' => $first_touches,
										'page_context' => $page_context,
										'query_result' => $result,
									],
								]
							);
							?>
						<?php endforeach; ?>
                </div>
            </div>
			<?php endif; ?>
			
			<?php if ( $total_pages > 1 ) : ?>
                <div class="card-inner">
					<?php
					echo KERP_Helpers_Template::get_template(
						'app/components/list/pagination.php',
						[
							'max_page_num' => $total_pages,
							'current_page' => $page_number,
							'class_name'   => 'customers_pagination_link',
							'show_count'   => 2,
							'action'       => 'erp_request_page_content',
							'page'         => $page_route,
						]
					);
					?>
                </div>
			<?php endif; ?>
        </div>
    </div>
</div>
