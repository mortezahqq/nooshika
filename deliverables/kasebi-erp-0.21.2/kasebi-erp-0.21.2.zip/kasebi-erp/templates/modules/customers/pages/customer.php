<?php

defined( 'ABSPATH' ) || exit;

/**
 * @var array $page_context
 */

$page_context = isset( $page_context ) && is_array( $page_context )
	? $page_context
	: [];

$page_query = (
	isset( $page_context['query'] ) &&
	is_array( $page_context['query'] )
)
	? $page_context['query']
	: [];

$customer_id = absint(
	$page_context['route_params']['customer_id'] ?? 0
);

$requested_tab = sanitize_key(
	(string) ( $page_query['tab'] ?? '' )
);

$settings_service = KERP_Modules_Customers_Settings::instance();
$profile_service  = KERP_Modules_Customers_Profile::instance();

$profile_context = $profile_service->get_context(
	$customer_id,
	$requested_tab
);
$customer        = $profile_context['customer'] ?? NULL;
$singular_label  = $settings_service->get_singular_label();

if ( ! $customer instanceof WP_User ) :
	?>
    <div class="nk-block">
        <div class="card card-bordered">
            <div class="card-inner text-center py-5">
                <em class="icon ni ni-user-cross fs-1 text-soft"></em>

                <h4 class="mt-3">
					<?php
					printf(
					/* translators: %s: singular customer label. */
						esc_html__( '%s پیدا نشد.', 'kasebi-erp' ),
						esc_html( $singular_label )
					);
					?>
                </h4>
            </div>
        </div>
    </div>
	<?php
	return;
endif;

$display_name = get_user_name_by_id( $customer_id );

$phone_key = (string) $settings_service->get(
	'phone_meta_key',
	'nooshika_phone_num'
);

$phone = sanitize_text_field(
	(string) get_user_meta(
		$customer_id,
		$phone_key,
		TRUE
	)
);

if ( $phone === '' ) {
	$phone = sanitize_text_field(
		(string) get_user_meta(
			$customer_id,
			'billing_phone',
			TRUE
		)
	);
}

$email                = sanitize_email( (string) $customer->user_email );
$registered_timestamp = strtotime( (string) $customer->user_registered );
$registered_date      = $registered_timestamp ? date_i18n( 'j F Y', $registered_timestamp ) : '';
$tabs                 = ( isset( $profile_context['tabs'] ) && is_array( $profile_context['tabs'] ) ) ? $profile_context['tabs'] : [];
$active_tab           = sanitize_key( (string) ( $profile_context['active_tab'] ?? '' ) );

$base_route = '/erp/customers/' . $customer_id . '/';
$profile_navigation = $profile_service->get_navigation( $tabs, $active_tab );
$sanitize_icon       = static function( string $icon ): string {
	$classes = preg_split( '/\s+/', trim( $icon ), - 1, PREG_SPLIT_NO_EMPTY );

	return implode(
		' ',
		array_filter(
			array_map( 'sanitize_html_class', is_array( $classes ) ? $classes : [] )
		)
	);
};

$gender = sanitize_key(
	(string) get_user_meta(
		$customer_id,
		'user_gender',
		TRUE
	)
);

$user_avatar = trim(
	(string) get_user_meta(
		$customer_id,
		'nooshika_user_avatar_url',
		TRUE
	)
);

$user_image = '';

if ( $user_avatar !== '' ) {
	if ( wp_http_validate_url( $user_avatar ) ) {
		$user_image = $user_avatar;
	} else {
		$upload_dir = wp_upload_dir();
		$user_image = trailingslashit( $upload_dir['baseurl'] ) . ltrim( $user_avatar, '/' );
	}
}

$can_delete_customer = KERP_Services_UI_Gate::can(
	'customers.delete',
	'action'
);
$owner_meta_key      = (string) $settings_service->get(
	'owner_meta_key',
	'kerp_customer_owner_id'
);

$owner_id = absint(
	get_user_meta(
		$customer_id,
		$owner_meta_key,
		TRUE
	)
);

$owner = $owner_id > 0
	? get_userdata( $owner_id )
	: FALSE;

$owner_name = $owner instanceof WP_User
	? trim( (string) get_user_name_by_id( $owner_id ) )
	: '';

$account_info_items = [
	'customer_id'     => [
		'icon'        => 'ni ni-browser-fill',
		'label'       => __( 'شناسه:', 'kasebi-erp' ),
		'value'       => (string) $customer_id,
		'class'       => '',
		'value_class' => '',
		'visible'     => TRUE,
		'order'       => 10,
	],
	'registered_date' => [
		'icon'        => 'ni ni-calendar-check-fill',
		'label'       => __( 'تاریخ عضویت:', 'kasebi-erp' ),
		'value'       => $registered_date,
		'class'       => '',
		'value_class' => '',
		'visible'     => $registered_date !== '',
		'order'       => 20,
	],
	'owner'           => [
		'icon'        => 'ni ni-user-check',
		'label'       => sprintf(
			__( 'مسئول %s:', 'kasebi-erp' ),
			$settings_service->get_singular_label()
		),
		'value'       => $owner_name !== ''
			? $owner_name
			: __( 'تعیین نشده', 'kasebi-erp' ),
		'class'       => '',
		'value_class' => $owner_name === '' ? 'text-soft' : '',
		'visible'     => TRUE,
		'order'       => 30,
	],
];
$account_info_items = apply_filters(
	'kerp_customers_profile_account_info_items',
	$account_info_items,
	$customer,
	$profile_context
);
uasort(
	$account_info_items,
	static function( mixed $first, mixed $second ): int {
		$first_order = is_array( $first )
			? (int) ( $first['order'] ?? 100 )
			: 100;
		
		$second_order = is_array( $second )
			? (int) ( $second['order'] ?? 100 )
			: 100;
		
		return $first_order <=> $second_order;
	}
);
$profile_dropdown_actions = [
	'change_avatar' => [
		'label'      => __( 'تنظیم تصویر', 'kasebi-erp' ),
		'icon'       => 'ni ni-camera-fill',
		'href'       => '#crop',
		'order'      => 10,
		'attributes' => [
			'data-bs-toggle' => 'modal',
			'data-bs-target' => '#crop',
		],
	],
];

if ( KERP_Api_Auth::instance()->can_login_as_user( $customer ) ) {
	$profile_dropdown_actions['login_as_customer'] = [
		'label'      => __( 'ورود به عنوان کاربر', 'kasebi-erp' ),
		'icon'       => 'ni ni-signin',
		'href'       => '#',
		'class'      => 'login_as_this',
		'order'      => 80,
		'attributes' => [ 'data-id' => $customer_id ],
	];
}

if ( $can_delete_customer ) {
	$profile_dropdown_actions['delete_customer'] = [
		'label'          => sprintf(
			__( 'حذف %s', 'kasebi-erp' ),
			$singular_label
		),
		'icon'           => 'ni ni-na',
		'href'           => '#',
		'class'          => 'delete_db_item',
		'order'          => 100,
		'divider_before' => TRUE,
		'attributes'     => [
			'data-action'      => 'customers_delete_customer',
			'data-page'        => '/erp/customers/',
			'data-customer_id' => $customer_id,
			'data-item_id'     => $customer_id,
		],
	];
}

$profile_dropdown_actions = apply_filters(
	'kerp_customers_profile_dropdown_actions',
	$profile_dropdown_actions,
	$customer,
	$profile_context
);

uasort(
	$profile_dropdown_actions,
	static function( array $first_action, array $second_action ): int {
		return (int) ( $first_action['order'] ?? 10 )
		       <=> (int) ( $second_action['order'] ?? 10 );
	}
);
?>
    <div class="nk-block">
        <div class="card">
            <div class="card-aside-wrap">
                <div class="card-inner kerp-customer-tab-content">
					<?php
					$tab_context = array_merge(
						$profile_context,
						[
							'page_context' => $page_context,
						]
					);
					do_action(
						'kerp_customer_profile_before_tab',
						$customer_id,
						$customer,
						$tab_context
					);
					$profile_service->render_tab(
						$active_tab,
						$customer_id,
						$tab_context
					);
					?>
                </div>
                <div class="card-aside card-aside-left user-aside toggle-slide toggle-slide-left toggle-break-lg"
                     data-toggle-body="true"
                     data-content="customerAside"
                     data-toggle-screen="lg"
                     data-toggle-overlay="true">
                    <div class="card-inner-group" data-simplebar>
                        <div class="card-inner">
                            <div class="user-card">
                                <div class="user-avatar bg-primary fs-20px">
									<?php if ( $user_image === '' ) : ?>
										<?php if ( $gender === 'female' ) : ?>
                                            <em class="uik fa-woman-head"></em>
										<?php else : ?>
                                            <em class="uik fa-smile"></em>
										<?php endif; ?>
									<?php else : ?>
                                        <a class="gallery-image popup-image ratio ratio-1x1"
                                           href="<?php echo esc_url( $user_image ); ?>">
                                            <img class="object-fit-cover"
                                                 src="<?php echo esc_url( $user_image ); ?>"
                                                 alt="<?php echo esc_attr( $display_name ); ?>">
                                        </a>
									
									<?php endif; ?>
                                </div>
                                <div class="user-info">
                                    <span class="lead-text"><?php echo esc_html( $display_name ); ?></span>
                                    <span class="sub-text"><?php echo esc_html( $phone ); ?></span>
                                </div>
                                <div class="user-action">
                                    <div class="dropdown">
                                        <a href="#" class="btn btn-icon btn-trigger me-n2"
                                           data-bs-toggle="dropdown"
                                           aria-expanded="false">
                                            <em class="icon ni ni-more-v"></em>
                                        </a>
                                        <div class="dropdown-menu dropdown-menu-end">
                                            <ul class="link-list-opt no-bdr">
												<?php foreach ( $profile_dropdown_actions as $action_key => $action ) : ?>
													<?php
													if (
														! is_array( $action ) ||
														empty( $action['label'] ) ||
														isset( $action['visible'] ) && ! $action['visible']
													) {
														continue;
													}
													$action_classes = preg_split(
														'/\s+/',
														trim( (string) ( $action['class'] ?? '' ) ),
														- 1,
														PREG_SPLIT_NO_EMPTY
													);
													
													$action_attributes = isset( $action['attributes'] ) && is_array( $action['attributes'] )
														? $action['attributes']
														: [];
													?>
													<?php if ( ! empty( $action['divider_before'] ) ) : ?>
                                                        <li class="divider"></li>
													<?php endif; ?>
                                                    <li class="<?php echo esc_attr( (string) ( $action['item_class'] ?? '' ) ); ?>"
                                                        data-action-key="<?php echo esc_attr( (string) $action_key ); ?>">
                                                        <a href="<?php echo esc_url( (string) ( $action['href'] ?? '#' ) ); ?>"
															<?php if ( $action_classes ) : ?>
                                                           class="<?php echo esc_attr( implode( ' ', $action_classes ) ); ?>"
														<?php endif; ?>
														<?php foreach ( $action_attributes as $attribute_name => $attribute_value ) : ?>
															<?php
															if (
																$attribute_value === NULL ||
																$attribute_value === FALSE ||
																is_array( $attribute_value ) ||
																is_object( $attribute_value )
															) {
																continue;
															}
															
															$attribute_name = sanitize_key( (string) $attribute_name );
															?>
															<?php if ( $attribute_value === TRUE ) : ?>
																<?php echo esc_attr( $attribute_name ); ?>
															<?php else : ?>
																<?php echo esc_attr( $attribute_name ); ?>="<?php echo esc_attr( (string) $attribute_value ); ?>"
															<?php endif; ?>
														<?php endforeach; ?>>
														<?php if ( ! empty( $action['icon'] ) ) : ?>
                                                            <em class="<?php echo esc_attr( (string) $action['icon']
															); ?> icon"></em>
														<?php endif; ?>
                                                        <span><?php echo esc_html( (string) $action['label'] ); ?></span>
                                                        </a>
                                                    </li>
													
													<?php if ( ! empty( $action['divider_after'] ) ) : ?>
                                                        <li class="divider"></li>
													<?php endif; ?>
												<?php endforeach; ?>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-inner">
                            <div class="user-account-info py-0">
                                <div class="g-2 row">
									<?php foreach ( $account_info_items as $item_key => $item ) : ?>
										<?php
										if ( ! is_array( $item ) || empty( $item['visible'] ) ) {
											continue;
										}
										
										$item_icon  = trim( (string) ( $item['icon'] ?? '' ) );
										$item_label = trim( (string) ( $item['label'] ?? '' ) );
										$item_value = trim( (string) ( $item['value'] ?? '' ) );
										
										if ( $item_label === '' || $item_value === '' ) {
											continue;
										}
										
										$item_class  = trim( 'd-flex align-center ' . (string) ( $item['class'] ?? '' ) );
										$value_class = trim( 'fw-bold ' . (string) ( $item['value_class'] ?? '' ) );
										?>
                                        <div class="<?php echo esc_attr( $item_class ); ?>"
                                             data-item="<?php echo esc_attr( sanitize_key( $item_key ) ); ?>"
                                             style="gap: 5px;">
											<?php if ( $item_icon !== '' ) : ?>
                                                <em class="<?php echo esc_attr( $item_icon ); ?> icon text-primary
                                                fs-18px"></em>
											<?php endif; ?>
                                            <span class="sub-text"><?php echo esc_html( $item_label ); ?></span>
                                            <div
                                                class="<?php echo esc_attr( $value_class ); ?>"><?php echo ! empty( $item['value_html'] ) ? wp_kses_post( $item_value ) : esc_html( $item_value ); ?></div>
                                        </div>
									<?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                        <div class="card-inner p-0">
							<ul class="nk-menu kerp-customer-profile-menu">
								<?php foreach ( $profile_navigation as $row ) : ?>
									<?php if ( ( $row['type'] ?? '' ) === 'tab' ) : ?>
										<?php
										$tab       = is_array( $row['tab'] ?? NULL ) ? $row['tab'] : [];
										$tab_key   = sanitize_key( (string) ( $tab['key'] ?? '' ) );
										$tab_title = sanitize_text_field( (string) ( $tab['title'] ?? $tab_key ) );
										$tab_icon  = $sanitize_icon( (string) ( $tab['icon'] ?? '' ) );
										$is_active = ! empty( $tab['active'] );
										$data_url  = add_query_arg( 'tab', $tab_key, $base_route );
										?>
										<li class="nk-menu-item<?php echo $is_active ? ' active current-page' : ''; ?>">
											<a href="<?php echo esc_url( home_url( $data_url ) ); ?>"
											   class="page_activator nk-menu-link"
											   data-url="<?php echo esc_attr( $data_url ); ?>"
												<?php echo $is_active ? 'aria-current="page"' : ''; ?>>
												<?php if ( $tab_icon !== '' ) : ?>
													<span class="nk-menu-icon"><em class="<?php echo esc_attr( $tab_icon ); ?> icon"></em></span>
												<?php endif; ?>
												<span class="nk-menu-text"><?php echo esc_html( $tab_title ); ?></span>
											</a>
										</li>
									<?php elseif ( ( $row['type'] ?? '' ) === 'group' && ! empty( $row['children'] ) ) : ?>
										<?php
										$group_key    = sanitize_key( (string) ( $row['key'] ?? '' ) );
										$group_title  = sanitize_text_field( (string) ( $row['title'] ?? $group_key ) );
										$group_icon   = $sanitize_icon( (string) ( $row['icon'] ?? '' ) );
										$group_active = ! empty( $row['active'] );
										?>
										<li class="nk-menu-item has-sub<?php echo $group_active ? ' active' : ''; ?>"
										    data-profile-group="<?php echo esc_attr( $group_key ); ?>">
											<a href="#" class="nk-menu-link kerp-profile-menu-toggle"
											   aria-expanded="<?php echo $group_active ? 'true' : 'false'; ?>">
												<?php if ( $group_icon !== '' ) : ?>
													<span class="nk-menu-icon"><em class="<?php echo esc_attr( $group_icon ); ?> icon"></em></span>
												<?php endif; ?>
												<span class="nk-menu-text"><?php echo esc_html( $group_title ); ?></span>
											</a>

											<ul class="nk-menu-sub">
												<?php foreach ( $row['children'] as $tab_key => $tab ) : ?>
													<?php
													if ( ! is_array( $tab ) ) {
														continue;
													}

													$tab_key   = sanitize_key( (string) ( $tab['key'] ?? $tab_key ) );
													$tab_title = sanitize_text_field( (string) ( $tab['title'] ?? $tab_key ) );
													$tab_icon  = $sanitize_icon( (string) ( $tab['icon'] ?? '' ) );
													$is_active = ! empty( $tab['active'] );
													$data_url  = add_query_arg( 'tab', $tab_key, $base_route );
													?>
													<li class="nk-menu-item<?php echo $is_active ? ' active current-page' : ''; ?>">
														<a href="<?php echo esc_url( home_url( $data_url ) ); ?>"
														   class="page_activator nk-menu-link"
														   data-url="<?php echo esc_attr( $data_url ); ?>"
															<?php echo $is_active ? 'aria-current="page"' : ''; ?>>
															<?php if ( $tab_icon !== '' ) : ?>
																<span class="nk-menu-icon"><em class="<?php echo esc_attr( $tab_icon ); ?> icon"></em></span>
															<?php endif; ?>
															<span class="nk-menu-text"><?php echo esc_html( $tab_title ); ?></span>
														</a>
													</li>
												<?php endforeach; ?>
											</ul>
										</li>
									<?php endif; ?>
								<?php endforeach; ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade zoom" id="crop">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">تنظیم تصویر پروفایل</h5>
                    <a href="#" class="close" data-bs-dismiss="modal" aria-label="بستن">
                        <em class="icon ni ni-cross"></em>
                    </a>
                </div>
                <div class="modal-body">
                    <form action="#" class="modal_form" data-action="change_user_profile_image">
                        <div class="row g-gs">
                            <div class="col-12">
                                <div class="form-group">
                                    <label class="form-label" for="new_profile_image">انتخاب تصویر</label>
                                    <div class="upload-zone" data-target="#new_profile_image"
                                         data-action="handle_file_upload_avatar" data-max-files="1">
                                        <div class="dz-message" data-dz-message>
                                            <span class="dz-message-text">بکشید و رها کنید</span>
                                            <span class="dz-message-or">یا</span>
                                            <div class="btn btn-primary">انتخاب کنید</div>
                                        </div>
                                    </div>
                                    <input type="hidden" id="new_profile_image" data-for="image" data-req="1">
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="border rounded p-3">
                                    <div class="d-flex align-center justify-between flex-wrap" style="gap: 10px">
                                        <div>
                                            <strong>استفاده از وبکم</strong>
                                            <div class="text-soft small">در صورت اتصال دوربین، می‌توانید مستقیم عکس
                                                بگیرید.
                                            </div>
                                        </div>
                                        <button type="button"
                                                class="btn btn-outline-primary btn-sm start_profile_webcam">
                                            فعال کردن وبکم
                                        </button>
                                    </div>
                                    <div class="profile_webcam_box mt-3" style="display:none;">
                                        <div class="row g-3">
                                            <div class="col-md-6">
                                                <video class="profile_webcam_video w-100 rounded"
                                                       width="300"
                                                       height="300"
                                                       autoplay
                                                       playsinline
                                                       muted></video>
                                            </div>

                                            <div class="col-md-6">
                                                <canvas class="profile_webcam_canvas w-100 rounded"
                                                        width="500"
                                                        height="500"></canvas>
                                            </div>

                                            <div class="col-12 text-center">
                                                <button type="button"
                                                        class="btn btn-info take_profile_webcam_screenshot">
                                                    پیش نمایش تصویر
                                                </button>

                                                <button type="button"
                                                        class="btn btn-success upload_profile_webcam_to_dropzone">
                                                    افزودن به آپلودزون
                                                </button>

                                                <button type="button" class="btn btn-light stop_profile_webcam">
                                                    بستن وبکم
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="col-12">
                                    <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                        <li>
                                            <div class="btn btn-primary submit_modal_form">ثبت تصویر پروفایل</div>
                                        </li>
                                        <li>
                                            <a href="#" class="link link-light btn-trigger"
                                               data-bs-dismiss="modal">لغو</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <input type="hidden" class="no_clear" value="<?php echo $customer_id; ?>" data-for="id">
                            <input type="hidden" class="no_clear" value="<?php echo $active_tab; ?>" data-for="tab">
                            <input type="hidden" class="no_clear" value="<?php echo $base_route; ?>" data-for="page">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php
do_action(
	'kerp_customer_profile_modals',
	$customer_id,
	$customer,
	$profile_context,
	$active_tab
);
