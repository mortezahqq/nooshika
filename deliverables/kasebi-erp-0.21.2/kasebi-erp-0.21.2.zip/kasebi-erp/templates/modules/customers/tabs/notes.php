<?php

defined( 'ABSPATH' ) || exit;

/**
 * @var WP_User $customer
 * @var int     $customer_id
 */

$customer_id   = absint( $customer_id ?? 0 );
$notes_service = KERP_Modules_Customers_Notes::instance();
$notes         = KERP_Modules_Customers_Notes_Query::instance()->get_by_customer( $customer_id );
$can_create    = kerp_can( 'customers.notes.create', 'action' );
$can_edit      = kerp_can( 'customers.notes.edit', 'action' );
?>
<div class="kerp-customer-tab-controls">
    <div class="d-lg-none kerp-customer-mobile-nav">
        <a href="#" class="toggle btn btn-icon btn-trigger" data-target="customerAside"
           aria-label="<?php esc_attr_e( 'نمایش منوی کاربر', 'kasebi-erp' ); ?>">
            <em class="icon ni ni-menu-alt-r"></em>
        </a>
    </div>
	<?php if ( $can_create ) : ?>
        <a href="#customerNoteModal" class="btn btn-dim btn-primary btn-icon" data-bs-toggle="modal"
           data-bs-target="#customerNoteModal" title="<?php esc_attr_e( 'افزودن یادداشت', 'kasebi-erp' ); ?>"
           aria-label="<?php esc_attr_e( 'افزودن یادداشت', 'kasebi-erp' ); ?>">
            <em class="icon ni ni-plus"></em>
        </a>
	<?php endif; ?>
</div>
<?php KERP_Helpers_Template::render_template( 'app/components/customer-tab-hero.php', [
	'icon'        => 'ni ni-notes',
	'eyebrow'     => __( 'اطلاعات تکمیلی', 'kasebi-erp' ),
	'title'       => __( 'یادداشت‌ها', 'kasebi-erp' ),
	'description' => __( 'اطلاعات ثابت، ترجیحات و نکاتی که کارکنان باید درباره این کاربر بدانند.', 'kasebi-erp' ),
] ); ?>
<div class="nk-block">
	<?php if ( empty( $notes ) ) : ?>
        <div class="card card-bordered">
            <div class="card-inner text-center py-5">
                <em class="icon ni ni-note-add fs-1 text-soft"></em>
                <h5 class="mt-3"><?php esc_html_e( 'هنوز یادداشتی ثبت نشده است.', 'kasebi-erp' ); ?></h5>
				<?php if ( $can_create ) : ?>
                    <p class="text-soft mb-0"><?php esc_html_e( 'اولین نکته مهم درباره این کاربر را ثبت کنید.', 'kasebi-erp' ); ?></p>
				<?php endif; ?>
            </div>
        </div>
	<?php else : ?>
        <div class="row g-gs">
			<?php foreach ( $notes as $note ) : ?>
				<?php
				KERP_Helpers_Template::render_template(
					'modules/customers/partials/note-item.php',
					[
						'note'          => $note,
						'customer_id'   => $customer_id,
						'notes_service' => $notes_service,
						'can_edit'      => $can_edit,
						'can_delete'    => kerp_can( 'customers.notes.delete', 'action' ),
					]
				);
				?>
			<?php endforeach; ?>
        </div>
	<?php endif; ?>
</div>
