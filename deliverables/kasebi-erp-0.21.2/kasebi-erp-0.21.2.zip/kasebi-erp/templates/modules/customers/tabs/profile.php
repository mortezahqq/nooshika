<?php

defined( 'ABSPATH' ) || exit;

/**
 * @var WP_User $customer
 * @var int     $customer_id
 * @var array   $tab
 */

if ( ! isset( $customer ) || ! $customer instanceof WP_User ) {
	return;
}

$customer_id       = absint( $customer_id ?? $customer->ID );
$fields_service    = KERP_Modules_Customers_Fields::instance();
$taxonomy_service  = KERP_Modules_Customers_Taxonomies::instance();
$settings_service  = KERP_Modules_Customers_Settings::instance();
$singular_label    = $settings_service->get_singular_label();
$profile_fields    = $fields_service->get_profile_view_fields( $customer_id );
$taxonomy_fields   = $taxonomy_service->get_profile_fields( $customer_id );
$can_edit_customer = KERP_Services_UI_Gate::can( 'customers.edit', 'action' );
$modal_id          = 'kerp-customer-profile-modal';
$page_route        = add_query_arg(
	[ 'tab' => 'profile' ],
	'/erp/customers/' . $customer_id . '/'
);
?>
    <div class="kerp-customer-tab-controls">
        <div class="d-lg-none kerp-customer-mobile-nav">
            <a href="#" class="toggle btn btn-icon btn-trigger" data-target="customerAside" aria-label="<?php esc_attr_e( 'نمایش منوی کاربر', 'kasebi-erp' ); ?>"><em class="icon ni ni-menu-alt-r"></em></a>
        </div>
		<?php if ( $can_edit_customer ) : ?>
            <a class="btn btn-dim btn-primary btn-icon" data-bs-toggle="modal" href="#<?php echo esc_attr( $modal_id ); ?>" aria-label="<?php esc_attr_e( 'ویرایش اطلاعات شخصی', 'kasebi-erp' ); ?>"><em class="icon ni ni-edit"></em></a>
		<?php endif; ?>
    </div>
<?php KERP_Helpers_Template::render_template( 'app/components/customer-tab-hero.php', [
	'icon'        => 'ni ni-user-circle',
	'eyebrow'     => __( 'پروفایل مشتری', 'kasebi-erp' ),
	'title'       => sprintf( __( 'اطلاعات شخصی %s', 'kasebi-erp' ), $singular_label ),
	'description' => sprintf( __( 'اطلاعات اصلی و اختصاصی %s', 'kasebi-erp' ), $singular_label ),
] ); ?>
<?php do_action( 'kerp_customer_profile_before_fields', $customer_id, $customer, $profile_fields ); ?>
    <div class="nk-block">
        <div class="profile-ud-list">
			<?php foreach ( $profile_fields as $field_key => $field ) : ?>
				<?php
				if ( ! is_array( $field ) ) {
					continue;
				}
				
				$label = trim( (string) ( $field['label'] ?? $field_key ) );
				$value = (string) ( $field['display_value'] ?? '-' );
				
				if ( $label === '' ) {
					continue;
				}
				?>
                <div class="profile-ud-item">
                    <div class="profile-ud wider">
                        <span class="profile-ud-label"><?php echo esc_html( $label ); ?></span>
                        <span class="profile-ud-value"><?php echo esc_html( $value ); ?></span>
                    </div>
                </div>
			<?php endforeach; ?>
        </div>
    </div>
<?php do_action( 'kerp_customer_profile_after_fields', $customer_id, $customer, $profile_fields ); ?>
    <div class="nk-divider divider md"></div>
    <div class="nk-block mb-2">
        <div class="nk-block-head nk-block-head-line p-0">
            <h6 class="title text-base"><?php esc_html_e( 'اطلاعات تکمیلی', 'kasebi-erp' ); ?></h6>
        </div>
        <div class="profile-ud-list">
			<?php foreach ( $taxonomy_fields as $taxonomy_type => $taxonomy_field ) : ?>
				<?php
				if ( ! is_array( $taxonomy_field ) ) {
					continue;
				}
				
				$taxonomy_label = trim( (string) ( $taxonomy_field['label'] ?? $taxonomy_type ) );
				$selected       = $taxonomy_field['value'] ?? [];
				$options        = isset( $taxonomy_field['options'] ) && is_array( $taxonomy_field['options'] )
					? $taxonomy_field['options']
					: [];
				
				$selected = is_array( $selected )
					? $selected
					: ( $selected !== '' ? [ $selected ] : [] );
				?>
                <div class="profile-ud-item">
                    <div class="profile-ud wider">
                        <span class="profile-ud-label"><?php echo esc_html( $taxonomy_label ); ?></span>
                        <ul class="g-1 profile-ud-value">
							<?php if ( ! empty( $selected ) ) : ?>
								<?php foreach ( $selected as $term_key ) : ?>
									<?php
									$term_key  = sanitize_key( (string) $term_key );
									$term_name = trim( (string) ( $options[ $term_key ] ?? $term_key ) );
									
									if ( $term_name === '' ) {
										continue;
									}
									?>
                                    <li class="btn-group">
                                        <span class="badge bg-info"><?php echo esc_html( $term_name ); ?></span>
                                    </li>
								<?php endforeach; ?>
							<?php else : ?>
                                <li>-</li>
							<?php endif; ?>
                        </ul>
                    </div>
                </div>
			<?php endforeach; ?>
        </div>
    </div>
<?php do_action( 'kerp_customer_profile_after_taxonomies', $customer_id, $customer, $taxonomy_fields ); ?>
<?php
if ( $can_edit_customer ) {
	$modal_fields = [
		[
			'id'    => 'kerp-customer-profile-id',
			'name'  => 'customer_id',
			'type'  => 'hidden',
			'value' => $customer_id,
		],
	];
	
	$modal_fields = array_merge(
		$modal_fields,
		array_values(
			$fields_service->get_edit_profile_fields( $customer_id )
		),
		array_values(
			$taxonomy_service->get_profile_modal_fields( $customer_id )
		)
	);
	
	$modal_fields = array_map(
		static function( array $field ): array {
			$classes = preg_split(
				'/\s+/',
				trim( (string) ( $field['input_class'] ?? '' ) ),
				- 1,
				PREG_SPLIT_NO_EMPTY
			);
			
			$classes[] = 'no_clear';
			
			$field['input_class'] = implode(
				' ',
				array_unique( $classes )
			);
			
			return $field;
		},
		$modal_fields
	);
	$modal        = [
		'id'     => $modal_id,
		'title'  => sprintf(
		/* translators: %s: singular customer label. */
			__( 'ویرایش اطلاعات %s', 'kasebi-erp' ),
			$singular_label
		),
		'action' => 'customers_save_profile',
		'page'   => $page_route,
		'button' => __( 'ذخیره تغییرات', 'kasebi-erp' ),
		'size'   => 'lg',
		'fields' => $modal_fields,
	];
	
	$modal = apply_filters(
		'kerp_customer_profile_modal_data',
		$modal,
		$customer_id,
		$customer
	);
	
	if ( is_array( $modal ) && ! empty( $modal['id'] ) ) {
		KERP_Helpers_Template::render_modal( $modal );
	}
}
