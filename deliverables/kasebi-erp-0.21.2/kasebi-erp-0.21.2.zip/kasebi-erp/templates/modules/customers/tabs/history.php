<?php

defined( 'ABSPATH' ) || exit;

if ( ! isset( $customer ) || ! $customer instanceof WP_User ) {
	return;
}

$customer_id = absint( $customer_id ?? $customer->ID );
$page_query  = isset( $page_context['query'] ) && is_array( $page_context['query'] ) ? $page_context['query'] : [];
$service     = KERP_Modules_Customers_History::instance();
$event_type = sanitize_key( (string) ( $page_query['history_event_type'] ?? '' ) );
$per_page   = KERP_Helpers_Pagination::resolve_per_page( 'customer-history', $page_query, 20, 100 );
$result     = $service->find( $customer_id, [
	'event_type'  => $event_type,
	'page_number' => 1,
	'per_page'    => $per_page,
] );
$items        = (array) ( $result['items'] ?? [] );
$total        = absint( $result['total'] ?? 0 );
$total_pages  = max( 1, absint( $result['total_pages'] ?? 1 ) );
$event_labels = $service->event_labels();
$page_route   = add_query_arg( 'tab', 'history', '/erp/customers/' . $customer_id . '/' );
$has_filter   = $event_type !== '';
$filters      = [
	'history_event_type' => [
		'key'         => 'history_event_type',
		'name'        => 'history_event_type',
		'label'       => __( 'نوع تغییر', 'kasebi-erp' ),
		'type'        => 'select',
		'options'     => $event_labels,
		'placeholder' => __( 'همه تغییرات', 'kasebi-erp' ),
		'value'       => $event_type,
		'col'         => 12,
	],
];
?>
<div class="kerp-customer-tab-controls d-lg-none">
    <div class="kerp-customer-mobile-nav">
        <a href="#" class="toggle btn btn-icon btn-trigger" data-target="customerAside" aria-label="<?php esc_attr_e( 'نمایش منوی کاربر', 'kasebi-erp' ); ?>"><em class="icon ni ni-menu-alt-r"></em></a>
    </div>
</div>
<?php KERP_Helpers_Template::render_template( 'app/components/customer-tab-hero.php', [
	'icon'        => 'ni ni-history',
	'eyebrow'     => __( 'گزارش تغییرات', 'kasebi-erp' ),
	'title'       => __( 'سوابق تغییرات', 'kasebi-erp' ),
	'description' => sprintf( __( 'در مجموع %s تغییر در فیلدهای ERP این کاربر ثبت شده است.', 'kasebi-erp' ), number_format_i18n( $total ) ),
] ); ?>

<div class="nk-block kerp-customer-history">
    <div class="card card-bordered card-stretch">
        <div class="card-inner-group">
            <div class="card-inner py-3 position-relative card-tools-toggle">
                <div class="card-title-group">
                    <div class="card-title">
                        <h6 class="title mb-0"><?php esc_html_e( 'تاریخچه ویرایش‌ها', 'kasebi-erp' ); ?></h6>
                        <span class="badge badge-dim bg-outline-primary mt-1">
							<?php printf( esc_html__( '%s مورد', 'kasebi-erp' ), esc_html( number_format_i18n( $total ) ) ); ?>
						</span>
                    </div>
                    <div class="card-tools">
                        <ul class="btn-toolbar gx-1">
                            <li>
								<?php echo KERP_Helpers_Template::get_template( 'app/components/list/filter-dropdown.php', [
									'has_filter'    => $has_filter,
									'filter_fields' => $filters,
									'action'        => 'erp_request_page_content',
									'page'          => $page_route,
								] ); ?>
                            </li>
                            <li class="btn-toolbar-sep"></li>
                            <li>
								<?php echo KERP_Helpers_Template::get_template( 'app/components/list/per-page-selector.php', [
									'per_page'            => $per_page,
									'available_per_pages' => [ 10, 20, 50, 100 ],
									'action'              => 'erp_request_page_content',
									'page'                => $page_route,
								] ); ?>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>

			<div class="card-inner p-0">
				<div class="nk-tb-list nk-tb-ulist is-compact kerp-customer-history-list">
					<div class="nk-tb-item nk-tb-head">
						<div class="nk-tb-col"><span class="sub-text"><?php esc_html_e( 'فیلد', 'kasebi-erp' ); ?></span></div>
						<div class="nk-tb-col"><span class="sub-text"><?php esc_html_e( 'تغییر مقدار', 'kasebi-erp' ); ?></span></div>
						<div class="nk-tb-col tb-col-sm"><span class="sub-text"><?php esc_html_e( 'نوع تغییر', 'kasebi-erp' ); ?></span></div>
						<div class="nk-tb-col tb-col-lg"><span class="sub-text"><?php esc_html_e( 'ثبت‌کننده', 'kasebi-erp' ); ?></span></div>
						<div class="nk-tb-col"><span class="sub-text"><?php esc_html_e( 'تاریخ', 'kasebi-erp' ); ?></span></div>
					</div>

					<?php foreach ( $items as $item ) : ?>
						<?php KERP_Helpers_Template::render_template( 'modules/customers/partials/history-item.php', [
							'item'        => $item,
							'customer_id' => $customer_id,
							'service'     => $service,
						] ); ?>
					<?php endforeach; ?>
				</div>

				<?php if ( empty( $items ) ) : ?>
                    <div class="card-inner text-center py-5">
                        <em class="icon ni ni-history fs-1 text-soft"></em>
                        <h5 class="mt-3"><?php esc_html_e( 'هنوز تغییری ثبت نشده است.', 'kasebi-erp' ); ?></h5>
                        <p class="text-soft mb-0"><?php esc_html_e( 'تغییرات بعدی فیلدهای فرم ERP در این بخش نمایش داده می‌شوند.', 'kasebi-erp' ); ?></p>
                    </div>
				<?php endif; ?>
			</div>

			<?php if ( ! empty( $items ) ) : ?>
				<?php if ( $total_pages > 1 ) : ?>
					<div class="card-inner border-top text-center kerp-customer-history-load-more-wrap">
						<button type="button"
								class="btn btn-outline-primary kerp-customer-history-load-more"
								data-customer-id="<?php echo esc_attr( $customer_id ); ?>"
								data-next-page="2"
								data-per-page="<?php echo esc_attr( $per_page ); ?>"
								data-event-type="<?php echo esc_attr( $event_type ); ?>">
							<em class="icon ni ni-reload"></em>
							<span class="spinner-border spinner-border-sm kerp-load-more-spinner d-none" role="status" aria-hidden="true"></span>
							<span class="kerp-load-more-label"><?php esc_html_e( 'نمایش سوابق بیشتر', 'kasebi-erp' ); ?></span>
						</button>
					</div>
				<?php endif; ?>
			<?php endif; ?>
        </div>
    </div>
</div>
