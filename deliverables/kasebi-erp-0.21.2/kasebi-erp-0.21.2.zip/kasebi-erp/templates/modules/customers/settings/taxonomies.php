<?php

defined( 'ABSPATH' ) || exit;

/**
 * @var array $page_context
 */

$page_query         = isset( $page_context['query'] ) && is_array( $page_context['query'] ) ? $page_context['query'] : [];
$active_tab         = sanitize_key( (string) ( $page_query['tab'] ?? '' ) );
$settings_service   = KERP_Modules_Customers_Settings::instance();
$taxonomies_service = KERP_Modules_Customers_Taxonomies::instance();
$singular_label     = $settings_service->get_singular_label();
$plural_label       = $settings_service->get_plural_label();

$taxonomy_types = [
	KERP_Modules_Customers_Taxonomies::TYPE_LABEL  => [
		'title'       => __( 'دسته‌بندی‌ها', 'kasebi-erp' ),
		'singular'    => __( 'دسته‌بندی', 'kasebi-erp' ),
		'description' => sprintf( __( 'برای دسته‌بندی وضعیت کلی هر %s استفاده می‌شود.', 'kasebi-erp' ), $singular_label ),
		'icon'        => 'ni ni-layers',
	],
	KERP_Modules_Customers_Taxonomies::TYPE_TAG    => [
		'title'       => __( 'تگ‌ها', 'kasebi-erp' ),
		'singular'    => __( 'تگ', 'kasebi-erp' ),
		'description' => __( 'برای نشانه‌گذاری آزاد، علایق و ویژگی‌های قابل ترکیب استفاده می‌شود.', 'kasebi-erp' ),
		'icon'        => 'ni ni-tags',
	],
	KERP_Modules_Customers_Taxonomies::TYPE_SOURCE => [
		'title'       => __( 'شیوه آشنایی', 'kasebi-erp' ),
		'singular'    => __( 'شیوه آشنایی', 'kasebi-erp' ),
		'description' => sprintf( __( 'مسیر یا منبع آشنایی %s با مجموعه را مشخص می‌کند.', 'kasebi-erp' ), $singular_label ),
		'icon'        => 'ni ni-link-alt',
	],
];

if ( ! isset( $taxonomy_types[ $active_tab ] ) ) {
	$active_tab = KERP_Modules_Customers_Taxonomies::TYPE_LABEL;
}

$taxonomy_terms = [];
$total_count    = 0;
$active_count   = 0;

foreach ( $taxonomy_types as $type => $type_data ) {
	$taxonomy_terms[ $type ] = $taxonomies_service->get_terms( $type, FALSE );
	$total_count             += count( $taxonomy_terms[ $type ] );
	foreach ( $taxonomy_terms[ $type ] as $term ) {
		$active_count += ! isset( $term['active'] ) || ! empty( $term['active'] ) ? 1 : 0;
	}
}

$inactive_count = max( 0, $total_count - $active_count );
$modal_id       = 'kerp-taxonomy-term-modal';
$modal_selector = '#' . $modal_id;

KERP_Helpers_Template::render_modal(
	[
		'id'     => $modal_id,
		'title'  => __( 'افزودن یا ویرایش مورد', 'kasebi-erp' ),
		'action' => 'customers_save_taxonomy_term',
		'page'   => 'customers-settings-taxonomies',
		'button' => __( 'ذخیره', 'kasebi-erp' ),
		'size'   => 'lg',
		'fields' => [
			[
				'id'          => 'kerp-taxonomy-modal-type',
				'name'        => 'type',
				'type'        => 'hidden',
				'input_class' => 'no_clear',
				'value'       => '',
			],
			[
				'id'          => 'kerp-taxonomy-modal-tab',
				'name'        => 'tab',
				'type'        => 'hidden',
				'input_class' => 'no_clear',
				'value'       => '',
			],
			[
				'id'       => 'kerp-taxonomy-modal-key',
				'name'     => 'term[key]',
				'label'    => __( 'کلید انگلیسی', 'kasebi-erp' ),
				'type'     => 'text',
				'class'    => 'col-md-6',
				'value'    => '',
				'required' => TRUE,
			],
			[
				'id'       => 'kerp-taxonomy-modal-name',
				'name'     => 'term[name]',
				'label'    => __( 'عنوان', 'kasebi-erp' ),
				'type'     => 'text',
				'class'    => 'col-md-6',
				'value'    => '',
				'required' => TRUE,
			],
			[
				'id'    => 'kerp-taxonomy-modal-description',
				'name'  => 'term[description]',
				'label' => __( 'توضیحات', 'kasebi-erp' ),
				'type'  => 'text',
				'class' => 'col-md-8',
				'value' => '',
			],
			[
				'id'    => 'kerp-taxonomy-modal-color',
				'name'  => 'term[color]',
				'label' => __( 'رنگ', 'kasebi-erp' ),
				'type'  => 'text',
				'class' => 'col-md-4',
				'value' => '',
			],
			[
				'id'    => 'kerp-taxonomy-modal-icon',
				'name'  => 'term[icon]',
				'label' => __( 'آیکون', 'kasebi-erp' ),
				'type'  => 'text',
				'class' => 'col-md-6',
				'value' => '',
			],
			[
				'id'    => 'kerp-taxonomy-modal-order',
				'name'  => 'term[order]',
				'label' => __( 'ترتیب', 'kasebi-erp' ),
				'type'  => 'number',
				'class' => 'col-md-6',
				'value' => 100,
			],
			[
				'id'          => 'kerp-taxonomy-modal-active-empty',
				'name'        => 'term[active]',
				'type'        => 'hidden',
				'input_class' => 'no_clear',
				'value'       => '0',
			],
			[
				'id'    => 'kerp-taxonomy-modal-active',
				'name'  => 'term[active]',
				'label' => __( 'فعال باشد', 'kasebi-erp' ),
				'type'  => 'switch',
				'class' => 'col-md-6',
				'value' => '1',
			],
		],
	]
);
?>
<div class="kerp-customers-taxonomies-settings">
    <div class="nk-block-head nk-block-head-sm">
        <div class="nk-block-between">
            <div class="nk-block-head-content">
                <h3 class="nk-block-title page-title"><?php printf( esc_html__( 'دسته‌بندی، تگ و شیوه آشنایی %s', 'kasebi-erp' ), esc_html( $plural_label ) ); ?></h3>
                <div class="nk-block-des text-soft">
                    <p><?php printf( esc_html__( 'ساختارهای طبقه‌بندی %s را برای فرم‌ها، پروفایل و فیلترهای سیستم مدیریت کنید.', 'kasebi-erp' ), esc_html( $plural_label ) ); ?></p>
                </div>
            </div>
        </div>
    </div>
    <div class="nk-block">
                <?php
        KERP_Helpers_Template::render_template(
        	'app/components/settings/hero.php',
        	[
        		'icon'        => 'icon ni ni-tags',
				'eyebrow'     => sprintf( __( 'طبقه‌بندی %s', 'kasebi-erp' ), $plural_label ),
        		'title'       => __( 'ساختار دسته‌بندی و برچسب‌گذاری', 'kasebi-erp' ),
				'description' => sprintf( __( 'دسته‌بندی‌ها ساختار اصلی را مشخص می‌کنند، تگ‌ها برای نشانه‌گذاری آزاد هستند و شیوه آشنایی منبع ورود %s را ثبت می‌کند.', 'kasebi-erp' ), $singular_label ),
        		'stats'       => [
        			[
        				'label' => __( 'کل موارد', 'kasebi-erp' ),
        				'value' => number_format_i18n( $total_count ),
        			],
        			[
        				'label' => __( 'فعال', 'kasebi-erp' ),
        				'value' => number_format_i18n( $active_count ),
        			],
        			[
        				'label' => __( 'غیرفعال', 'kasebi-erp' ),
        				'value' => number_format_i18n( $inactive_count ),
        			],
        			[
        				'label' => __( 'انواع ساختار', 'kasebi-erp' ),
        				'value' => number_format_i18n( count( $taxonomy_types ) ),
        			],
        		],
        	]
        );
        ?>
    </div>
    <div class="nk-block">
        <div class="card card-bordered kerp-customer-taxonomy-nav-card">
            <div class="card-inner p-0">
                <ul class="nav nav-tabs kerp-customer-taxonomy-tabs">
					<?php foreach ( $taxonomy_types as $type => $type_data ) : ?>
						<?php
						$tab_id     = 'kerp-customers-taxonomy-' . sanitize_html_class( $type );
						$is_active  = $active_tab === $type;
						$type_count = count( $taxonomy_terms[ $type ] ?? [] );
						?>
                        <li class="nav-item p-0">
                            <a class="nav-link<?php echo $is_active ? ' active' : ''; ?>"
                               data-bs-toggle="tab"
                               href="#<?php echo esc_attr( $tab_id ); ?>"
                               data-tab="<?php echo esc_attr( $type ); ?>"
                               aria-selected="<?php echo $is_active ? 'true' : 'false'; ?>">
                                <em class="<?php echo esc_attr( $type_data['icon'] ); ?> icon"></em>
                                <span><?php echo esc_html( $type_data['title'] ); ?></span>
                                <strong><?php echo esc_html( number_format_i18n( $type_count ) ); ?></strong>
                            </a>
                        </li>
					<?php endforeach; ?>
                </ul>
            </div>
        </div>
        <div class="tab-content mt-4">
			<?php foreach ( $taxonomy_types as $type => $type_data ) : ?>
				<?php
				$tab_id       = 'kerp-customers-taxonomy-' . sanitize_html_class( $type );
				$terms        = $taxonomy_terms[ $type ] ?? [];
				$is_active    = $active_tab === $type;
				$add_populate = [
					'type'        => [ 'id' => '#kerp-taxonomy-modal-type', 'value' => $type, 'type' => 'hidden' ],
					'tab'         => [ 'id' => '#kerp-taxonomy-modal-tab', 'value' => $type, 'type' => 'hidden' ],
					'key'         => [ 'id' => '#kerp-taxonomy-modal-key', 'value' => '', 'type' => 'text' ],
					'name'        => [ 'id' => '#kerp-taxonomy-modal-name', 'value' => '', 'type' => 'text' ],
					'description' => [ 'id' => '#kerp-taxonomy-modal-description', 'value' => '', 'type' => 'text' ],
					'color'       => [ 'id' => '#kerp-taxonomy-modal-color', 'value' => '', 'type' => 'text' ],
					'icon'        => [ 'id' => '#kerp-taxonomy-modal-icon', 'value' => '', 'type' => 'text' ],
					'order'       => [ 'id' => '#kerp-taxonomy-modal-order', 'value' => 100, 'type' => 'text' ],
					'active'      => [ 'id' => '#kerp-taxonomy-modal-active', 'value' => '1', 'type' => 'switch' ],
				];
				?>
                <div class="tab-pane fade<?php echo $is_active ? ' show active' : ''; ?>"
                     id="<?php echo esc_attr( $tab_id ); ?>">
                    <div class="card card-bordered kerp-customer-taxonomy-section-head">
                        <div class="card-inner">
                            <div class="nk-block-between">
                                <div class="kerp-customer-taxonomy-section-head__identity">
                                    <span class="kerp-customer-taxonomy-section-head__icon"><em
                                            class="<?php echo esc_attr( $type_data['icon'] ); ?> icon"></em></span>
                                    <div>
                                        <h5 class="title mb-1"><?php echo esc_html( $type_data['title'] ); ?></h5>
                                        <p class="text-soft mb-0"><?php echo esc_html( $type_data['description'] ); ?></p>
                                    </div>
                                </div>
                                <button type="button"
                                        class="btn btn-primary open_populate_modal"
                                        data-modal="<?php echo esc_attr( $modal_selector ); ?>"
                                        data-modal-title="<?php echo esc_attr( sprintf( __( 'افزودن %s', 'kasebi-erp' ), $type_data['singular'] ) ); ?>"
                                        data-submit-text="<?php esc_attr_e( 'افزودن', 'kasebi-erp' ); ?>"
                                        data-populate="<?php echo esc_attr( wp_json_encode( $add_populate ) ); ?>">
                                    <em class="icon ni ni-plus"></em>
                                    <span><?php printf( esc_html__( 'افزودن %s', 'kasebi-erp' ), esc_html( $type_data['singular'] ) ); ?></span>
                                </button>
                            </div>
                        </div>
                    </div>
					<?php if ( empty( $terms ) ) : ?>
                                                <?php
                        KERP_Helpers_Template::render_template(
                        	'app/components/settings/empty-state.php',
                        	[
                        		'icon'        => $type_data['icon'] . ' icon',
                        		'title'       => sprintf( __( 'هنوز %s ثبت نشده است', 'kasebi-erp' ), $type_data['singular'] ),
                        		'description' => $type_data['description'],
                        		'class'       => 'mt-4',
                        		'action'      => [ 'label' => sprintf( __( 'افزودن اولین %s', 'kasebi-erp' ), $type_data['singular'] ), 'icon' => 'icon ni ni-plus', 'class' => 'btn btn-primary open_populate_modal', 'attributes' => [ 'data-modal' => $modal_selector, 'data-modal-title' => sprintf( __( 'افزودن %s', 'kasebi-erp' ), $type_data['singular'] ), 'data-submit-text' => __( 'افزودن', 'kasebi-erp' ), 'data-populate' => wp_json_encode( $add_populate ) ] ],
                        	]
                        );
                        ?>
					<?php else : ?>
                        <div class="row g-gs kerp-settings-item-grid kerp-customer-taxonomy-grid mt-1">
							<?php foreach ( $terms as $term_key => $term ) : ?>
								<?php
								$term_key         = sanitize_key( (string) $term_key );
								$term_name        = sanitize_text_field( (string) ( $term['name'] ?? $term_key ) );
								$term_description = sanitize_text_field( (string) ( $term['description'] ?? '' ) );
								$term_color       = sanitize_hex_color( (string) ( $term['color'] ?? '' ) ) ?: '';
								$term_icon        = trim( (string) ( $term['icon'] ?? '' ) );
								$display_icon     = $term_icon !== '' ? $term_icon : $type_data['icon'];
								$term_order       = (int) ( $term['order'] ?? 100 );
								$term_active      = ! isset( $term['active'] ) || ! empty( $term['active'] );
								$edit_populate    = [
									'type'        => [
										'id'    => '#kerp-taxonomy-modal-type',
										'value' => $type,
										'type'  => 'hidden',
									],
									'tab'         => [
										'id'    => '#kerp-taxonomy-modal-tab',
										'value' => $type,
										'type'  => 'hidden',
									],
									'key'         => [
										'id'    => '#kerp-taxonomy-modal-key',
										'value' => $term_key,
										'type'  => 'no_change',
									],
									'name'        => [
										'id'    => '#kerp-taxonomy-modal-name',
										'value' => $term_name,
										'type'  => 'text',
									],
									'description' => [
										'id'    => '#kerp-taxonomy-modal-description',
										'value' => $term_description,
										'type'  => 'text',
									],
									'color'       => [
										'id'    => '#kerp-taxonomy-modal-color',
										'value' => $term_color,
										'type'  => 'text',
									],
									'icon'        => [
										'id'    => '#kerp-taxonomy-modal-icon',
										'value' => $term_icon,
										'type'  => 'text',
									],
									'order'       => [
										'id'    => '#kerp-taxonomy-modal-order',
										'value' => $term_order,
										'type'  => 'text',
									],
									'active'      => [
										'id'    => '#kerp-taxonomy-modal-active',
										'value' => $term_active ? '1' : '0',
										'type'  => 'switch',
									],
								];
								?>
                                                                <?php
                                KERP_Helpers_Template::render_template(
                                	'app/components/settings/item-card.php',
                                	[
                                		'icon'        => $display_icon . ' icon',
                                		'label'       => $term_name,
                                		'key'         => $term_key,
                                		'active'      => $term_active,
                                		'description' => $term_description,
                                		'actions'     => [
                                			[
                                				'label'      => __( 'ویرایش', 'kasebi-erp' ),
                                				'icon'       => 'icon ni ni-edit',
                                				'class'      => 'edit_row_item',
                                				'attributes' => [
                                					'data-modal'       => $modal_selector,
                                					'data-modal-title' => sprintf( __( 'ویرایش %s', 'kasebi-erp' ), $type_data['singular'] ),
                                					'data-submit-text' => __( 'ذخیره تغییرات', 'kasebi-erp' ),
                                					'data-populate'    => wp_json_encode( $edit_populate ),
                                				],
                                			],
                                			[
                                				'label'          => __( 'حذف', 'kasebi-erp' ),
                                				'icon'           => 'icon ni ni-trash',
                                				'class'          => 'delete_db_item',
                                				'divider_before' => TRUE,
                                				'attributes'     => [
                                					'data-action'  => 'customers_delete_taxonomy_term',
                                					'data-page'    => 'customers-settings-taxonomies',
                                					'data-tab'     => $type,
                                					'data-type'    => $type,
                                					'data-key'     => $term_key,
                                					'data-item_id' => $term_key,
                                				],
                                			],
                                		],
                                		'footer'      => array_values( array_filter( [
                                			[ 'icon' => 'icon ni ni-sort', 'text' => sprintf( __( 'ترتیب %s', 'kasebi-erp' ), number_format_i18n( $term_order ) ) ],
                                			$term_color !== '' ? [ 'type' => 'color', 'value' => $term_color ] : NULL,
                                		] ) ),
                                	]
                                );
                                ?>
							<?php endforeach; ?>
                        </div>
					<?php endif; ?>
                </div>
			<?php endforeach; ?>
        </div>
    </div>
</div>
