<?php

defined( 'ABSPATH' ) || exit;

$settings_service = KERP_Modules_Customers_Settings::instance();
$settings         = $settings_service->all();
$singular_label   = $settings_service->get_singular_label();
$plural_label     = $settings_service->get_plural_label();

$role_options = [];
$wp_roles     = wp_roles();

if ( $wp_roles instanceof WP_Roles ) {
	foreach ( $wp_roles->roles as $role_key => $role_data ) {
		$role_options[ $role_key ] = translate_user_role(
			(string) ( $role_data['name'] ?? $role_key )
		);
	}
}

$customer_roles = array_values(
	array_unique(
		array_filter(
			array_map(
				'sanitize_key',
				(array) ( $settings['customer_roles'] ?? [] )
			)
		)
	)
);

foreach ( $customer_roles as $role_key ) {
	if ( $role_key !== '' && ! isset( $role_options[ $role_key ] ) ) {
		$role_options[ $role_key ] = $role_key;
	}
}

asort( $role_options, SORT_NATURAL | SORT_FLAG_CASE );

$username_source_options = [
	'phone'     => __( 'شماره موبایل', 'kasebi-erp' ),
	'email'     => __( 'ایمیل', 'kasebi-erp' ),
	'generated' => __( 'تولید خودکار', 'kasebi-erp' ),
];

$required_fields = [
	'require_first_name' => [
		'label'       => __( 'نام', 'kasebi-erp' ),
		'description' => __( 'ثبت نام برای ایجاد یا ویرایش کاربر الزامی باشد.', 'kasebi-erp' ),
		'icon'        => 'ni ni-user',
	],
	'require_last_name'  => [
		'label'       => __( 'نام خانوادگی', 'kasebi-erp' ),
		'description' => __( 'ثبت نام خانوادگی برای کاربر الزامی باشد.', 'kasebi-erp' ),
		'icon'        => 'ni ni-user-list',
	],
	'require_phone'      => [
		'label'       => __( 'شماره موبایل', 'kasebi-erp' ),
		'description' => __( 'بدون شماره موبایل امکان ثبت کاربر وجود نداشته باشد.', 'kasebi-erp' ),
		'icon'        => 'ni ni-call',
	],
	'require_email'      => [
		'label'       => __( 'ایمیل', 'kasebi-erp' ),
		'description' => __( 'ثبت ایمیل برای ایجاد یا ویرایش کاربر الزامی باشد.', 'kasebi-erp' ),
		'icon'        => 'ni ni-mail',
	],
];

$default_role         = sanitize_key( (string) ( $settings['default_role'] ?? 'customer' ) );
$username_source      = sanitize_key( (string) ( $settings['username_source'] ?? 'phone' ) );
$default_per_page     = max( 1, min( 200, absint( $settings['default_per_page'] ?? 20 ) ) );
$show_registration_at = ! empty( $settings['show_registration_at'] );
$first_touch_migration = KERP_Services_Attribution_First_Touch::instance()->migration_status();
$legacy_taxonomy_migration = KERP_Modules_Customers_Legacy_Taxonomy_Migration::instance()->status();
$required_count       = 0;

foreach ( array_keys( $required_fields ) as $setting_key ) {
	if ( ! empty( $settings[ $setting_key ] ) ) {
		$required_count ++;
	}
}

$default_role_label    = (string) ( $role_options[ $default_role ] ?? $default_role );
$username_source_label = (string) (
	$username_source_options[ $username_source ]
	?? $username_source_options['phone']
);
?>
<form class="modal_form kerp-customers-settings"
      data-action="customers_save_settings"
      data-page="customers-settings-general">
    <div class="nk-block-head nk-block-head-sm">
        <div class="nk-block-between">
            <div class="nk-block-head-content">
                <h3 class="nk-block-title page-title">
					<?php
					printf(
						esc_html__( 'تنظیمات عمومی %s', 'kasebi-erp' ),
						esc_html( $plural_label )
					);
					?>
                </h3>
                <div class="nk-block-des text-soft">
                    <p><?php printf( esc_html__( 'نام‌گذاری، نقش‌ها، اطلاعات الزامی و رفتار پیش‌فرض ثبت %s را مدیریت کنید.', 'kasebi-erp' ), esc_html( $singular_label ) ); ?></p>
                </div>
            </div>
            <div class="nk-block-head-content">
                <button type="button" class="btn btn-primary submit_modal_form">
                    <em class="icon ni ni-save"></em>
                    <span><?php esc_html_e( 'ذخیره تغییرات', 'kasebi-erp' ); ?></span>
                </button>
            </div>
        </div>
    </div>

    <div class="nk-block">
                <?php
        KERP_Helpers_Template::render_template(
        	'app/components/settings/hero.php',
        	[
        		'icon'        => 'icon ni ni-users',
				'eyebrow'     => sprintf( __( 'ماژول %s', 'kasebi-erp' ), $plural_label ),
        		'title'       => $plural_label,
				'description' => sprintf( __( 'این تنظیمات روی فرم ثبت، فهرست %s و نحوه ساخت حساب کاربری اعمال می‌شوند.', 'kasebi-erp' ), $plural_label ),
        		'stats'       => [
        			[
        				'label' => __( 'نقش پیش‌فرض', 'kasebi-erp' ),
        				'value' => $default_role_label,
        			],
        			[
						'label' => sprintf( __( 'نقش‌های %s', 'kasebi-erp' ), $singular_label ),
        				'value' => number_format_i18n( count( $customer_roles ) ),
        			],
        			[
        				'label' => __( 'فیلدهای الزامی', 'kasebi-erp' ),
        				'value' => number_format_i18n( $required_count ),
        			],
        			[
        				'label' => __( 'نام کاربری', 'kasebi-erp' ),
        				'value' => $username_source_label,
        			],
        		],
        	]
        );
        ?>
    </div>

    <div class="nk-block">
        <div class="row g-gs">
            <div class="col-xl-8">
                <div class="card card-bordered mb-4">
                    <div class="card-inner border-bottom">
                        <div class="card-title-group align-start">
                            <div class="card-title">
                                <h6 class="title">
                                    <em class="icon ni ni-text-a me-1"></em>
									<?php esc_html_e( 'نام‌گذاری و ایجاد حساب', 'kasebi-erp' ); ?>
                                </h6>
                                <p class="text-soft"><?php printf( esc_html__( 'عنوان‌های نمایشی و رفتار پیش‌فرض ساخت حساب %s را تعیین کنید.', 'kasebi-erp' ), esc_html( $singular_label ) ); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="card-inner">
                        <div class="row g-4">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label" for="kerp-customers-singular-label">
										<?php esc_html_e( 'عنوان مفرد', 'kasebi-erp' ); ?>
                                    </label>
                                    <div class="form-control-wrap">
                                        <div class="form-icon form-icon-right">
                                            <em class="icon ni ni-user"></em>
                                        </div>
                                        <input type="text"
                                               id="kerp-customers-singular-label"
                                               class="form-control no_clear"
                                               name="settings[singular_label]"
                                               data-for="settings[singular_label]"
                                               data-req="1"
                                               value="<?php echo esc_attr( $settings['singular_label'] ?? '' ); ?>">
                                    </div>
                                    <div
                                        class="form-note"><?php printf( esc_html__( 'مثال: %s، مخاطب یا خریدار', 'kasebi-erp' ), esc_html( $singular_label ) ); ?></div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label" for="kerp-customers-plural-label">
										<?php esc_html_e( 'عنوان جمع', 'kasebi-erp' ); ?>
                                    </label>
                                    <div class="form-control-wrap">
                                        <div class="form-icon form-icon-right">
                                            <em class="icon ni ni-users"></em>
                                        </div>
                                        <input type="text"
                                               id="kerp-customers-plural-label"
                                               class="form-control no_clear"
                                               name="settings[plural_label]"
                                               data-for="settings[plural_label]"
                                               data-req="1"
                                               value="<?php echo esc_attr( $settings['plural_label'] ?? '' ); ?>">
                                    </div>
                                    <div
                                        class="form-note"><?php printf( esc_html__( 'مثال: %s، مخاطبان یا خریداران', 'kasebi-erp' ), esc_html( $plural_label ) ); ?></div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label" for="kerp-customers-default-role">
										<?php esc_html_e( 'نقش پیش‌فرض کاربر', 'kasebi-erp' ); ?>
                                    </label>
                                    <div class="form-control-wrap">
                                        <select id="kerp-customers-default-role"
                                                class="form-control js-select2 no_clear"
                                                name="settings[default_role]"
                                                data-for="settings[default_role]"
                                                data-req="1">
                                            <option
                                                value=""><?php esc_html_e( 'انتخاب کنید', 'kasebi-erp' ); ?></option>
											<?php foreach ( $role_options as $role_key => $role_label ) : ?>
                                                <option value="<?php echo esc_attr( $role_key ); ?>"
													<?php selected( $default_role, $role_key ); ?>>
													<?php echo esc_html( $role_label ); ?>
                                                </option>
											<?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div
                                        class="form-note"><?php printf( esc_html__( 'این نقش هنگام ایجاد حساب جدید برای %s استفاده می‌شود.', 'kasebi-erp' ), esc_html( $singular_label ) ); ?></div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label" for="kerp-customers-username-source">
										<?php esc_html_e( 'مبنای تولید نام کاربری', 'kasebi-erp' ); ?>
                                    </label>
                                    <div class="form-control-wrap">
                                        <select id="kerp-customers-username-source"
                                                class="form-control js-select2 no_clear"
                                                name="settings[username_source]"
                                                data-for="settings[username_source]"
                                                data-req="1">
                                            <option
                                                value=""><?php esc_html_e( 'انتخاب کنید', 'kasebi-erp' ); ?></option>
											<?php foreach ( $username_source_options as $source_key => $source_label ) : ?>
                                                <option value="<?php echo esc_attr( $source_key ); ?>"
													<?php selected( $username_source, $source_key ); ?>>
													<?php echo esc_html( $source_label ); ?>
                                                </option>
											<?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div
                                        class="form-note"><?php esc_html_e( 'در صورت موجود بودن حساب قبلی، حساب جدید ساخته نمی‌شود.', 'kasebi-erp' ); ?></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card card-bordered mb-4">
                    <div class="card-inner border-bottom">
                        <div class="card-title-group align-start">
                            <div class="card-title">
                                <h6 class="title">
                                    <em class="icon ni ni-shield-check me-1"></em>
									<?php
									printf(
										esc_html__( 'نقش‌های مربوط به %s', 'kasebi-erp' ),
										esc_html( $plural_label )
									);
									?>
                                </h6>
                                <p class="text-soft">
									<?php printf( esc_html__( 'کاربرانی که یکی از این نقش‌های وردپرس را دارند در محدوده %s شناخته می‌شوند.', 'kasebi-erp' ), esc_html( $plural_label ) ); ?>
                                </p>
                            </div>
                            <div class="card-tools">
                                <span class="badge badge-dim bg-primary">
									<?php
									printf(
										esc_html__( '%s نقش انتخاب‌شده', 'kasebi-erp' ),
										esc_html( number_format_i18n( count( $customer_roles ) ) )
									);
									?>
                                </span>
                            </div>
                        </div>
                    </div>
                    <div class="card-inner">
                        <input type="hidden"
                               class="no_clear"
                               name="settings[customer_roles]"
                               data-for="settings[customer_roles]"
                               value="">
                        <div class="kerp-customer-role-grid">
							<?php foreach ( $role_options as $role_key => $role_label ) :
								$field_id = 'kerp-customers-role-' . sanitize_html_class( $role_key );
								$selected = in_array( (string) $role_key, $customer_roles, TRUE );
								?>
                                <label class="kerp-settings-option<?php echo $selected ? ' is-selected' : ''; ?>"
                                       for="<?php echo esc_attr( $field_id ); ?>">
                                    <span class="kerp-settings-option__content">
                                        <span class="kerp-settings-option__icon">
                                            <em class="icon ni ni-user-check"></em>
                                        </span>
                                        <span>
                                            <strong><?php echo esc_html( $role_label ); ?></strong>
                                            <code><?php echo esc_html( $role_key ); ?></code>
                                        </span>
                                    </span>
                                    <span class="custom-control custom-switch">
                                        <input type="checkbox"
                                               id="<?php echo esc_attr( $field_id ); ?>"
                                               class="custom-control-input no_clear"
                                               name="settings[customer_roles][]"
                                               data-for="settings[customer_roles]"
                                               data-req="1"
                                               value="<?php echo esc_attr( $role_key ); ?>"
											<?php checked( $selected ); ?>>
                                        <span class="custom-control-label"></span>
                                    </span>
                                </label>
							<?php endforeach; ?>
                        </div>
                        <div class="form-note mt-3">
							<?php esc_html_e( 'حداقل یک نقش باید انتخاب شود. نقش پیش‌فرض بهتر است در همین فهرست فعال باشد.', 'kasebi-erp' ); ?>
                        </div>
                    </div>
                </div>

                <div class="card card-bordered mb-4">
                    <div class="card-inner border-bottom">
                        <div class="card-title-group align-start">
                            <div class="card-title">
                                <h6 class="title">
                                    <em class="icon ni ni-code me-1"></em>
									<?php esc_html_e( 'تنظیمات فنی', 'kasebi-erp' ); ?>
                                </h6>
                                <p class="text-soft"><?php printf( esc_html__( 'کلیدهای متا و تنظیمات داخلی اتصال %s را مشخص کنید.', 'kasebi-erp' ), esc_html( $plural_label ) ); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="card-inner">
                        <div class="row g-4">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label" for="kerp-customers-phone-meta-key">
										<?php esc_html_e( 'کلید متای شماره موبایل', 'kasebi-erp' ); ?>
                                    </label>
                                    <div class="form-control-wrap">
                                        <div class="form-icon form-icon-right">
                                            <em class="icon ni ni-call"></em>
                                        </div>
                                        <input type="text"
                                               id="kerp-customers-phone-meta-key"
                                               class="form-control no_clear"
                                               name="settings[phone_meta_key]"
                                               data-for="settings[phone_meta_key]"
                                               data-req="1"
                                               value="<?php echo esc_attr( $settings['phone_meta_key'] ?? 'nooshika_phone_num' ); ?>">
                                    </div>
                                    <div
                                        class="form-note"><?php esc_html_e( 'تغییر این مقدار ممکن است اتصال اطلاعات قبلی را مختل کند.', 'kasebi-erp' ); ?></div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label" for="kerp-customers-owner-meta-key">
										<?php printf( esc_html__( 'کلید متای مسئول %s', 'kasebi-erp' ), esc_html( $singular_label ) ); ?>
                                    </label>
                                    <div class="form-control-wrap">
                                        <div class="form-icon form-icon-right">
                                            <em class="icon ni ni-user-round"></em>
                                        </div>
                                        <input type="text"
                                               id="kerp-customers-owner-meta-key"
                                               class="form-control no_clear"
                                               name="settings[owner_meta_key]"
                                               data-for="settings[owner_meta_key]"
                                               data-req="1"
                                               value="<?php echo esc_attr( $settings['owner_meta_key'] ?? 'kerp_customer_owner_id' ); ?>">
                                    </div>
                                    <div
                                        class="form-note"><?php printf( esc_html__( 'برای تعیین مالک و اعمال Scope %s استفاده می‌شود.', 'kasebi-erp' ), esc_html( $plural_label ) ); ?></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card card-bordered" id="kerp-first-touch-migration"
                     data-nonce="<?php echo esc_attr( wp_create_nonce( 'kerp_first_touch_migration' ) ); ?>">
                    <div class="card-inner border-bottom">
                        <div class="card-title-group align-start">
                            <div class="card-title">
                                <h6 class="title"><em class="icon ni ni-database me-1"></em><?php esc_html_e( 'ذخیره‌سازی First Touch', 'kasebi-erp' ); ?></h6>
                                <p class="text-soft"><?php esc_html_e( 'اطلاعات جدید در جدول گزارش‌پذیر ERP ذخیره می‌شوند؛ متای قدیمی بدون حذف قابل انتقال است.', 'kasebi-erp' ); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="card-inner">
                        <div class="row g-3 mb-3">
                            <div class="col-6"><span class="sub-text"><?php esc_html_e( 'متای قدیمی', 'kasebi-erp' ); ?></span><strong class="d-block fs-5" data-ft-total><?php echo esc_html( number_format_i18n( $first_touch_migration['total'] ) ); ?></strong></div>
                            <div class="col-6"><span class="sub-text"><?php esc_html_e( 'باقی‌مانده', 'kasebi-erp' ); ?></span><strong class="d-block fs-5" data-ft-remaining><?php echo esc_html( number_format_i18n( $first_touch_migration['remaining'] ) ); ?></strong></div>
                        </div>
                        <button type="button" class="btn btn-outline-primary" data-ft-migrate <?php disabled( $first_touch_migration['remaining'] === 0 ); ?>>
                            <em class="icon ni ni-upload-cloud"></em><span><?php echo $first_touch_migration['remaining'] > 0 ? esc_html__( 'انتقال به جدول', 'kasebi-erp' ) : esc_html__( 'انتقال کامل است', 'kasebi-erp' ); ?></span>
                        </button>
                        <p class="text-soft mt-2 mb-0" data-ft-message role="status" aria-live="polite"><?php esc_html_e( 'این عملیات idempotent است و داده‌های متای قبلی را حذف نمی‌کند.', 'kasebi-erp' ); ?></p>
                    </div>
                </div>

				<div class="card card-bordered mt-4" id="kerp-legacy-taxonomy-migration"
				     data-nonce="<?php echo esc_attr( wp_create_nonce( 'kerp_legacy_taxonomy_migration' ) ); ?>">
					<div class="card-inner border-bottom">
						<div class="card-title-group align-start">
							<div class="card-title">
								<h6 class="title"><em class="icon ni ni-tags me-1"></em><?php esc_html_e( 'انتقال دسته‌بندی‌های پنل قدیمی', 'kasebi-erp' ); ?></h6>
								<p class="text-soft"><?php esc_html_e( 'user-type به دسته‌بندی، user-group به تگ و ncp_user_marketer_id به مسئول مشتری منتقل می‌شود؛ داده‌های قدیمی حذف نخواهند شد.', 'kasebi-erp' ); ?></p>
							</div>
						</div>
					</div>
					<div class="card-inner">
						<?php if ( ! $legacy_taxonomy_migration['available'] ) : ?>
							<div class="alert alert-light mb-0"><?php esc_html_e( 'هیچ گزینه یا اتصال کاربری در taxonomyهای قدیمی پیدا نشد.', 'kasebi-erp' ); ?></div>
						<?php else : ?>
							<div class="row g-3 mb-3">
								<div class="col-6 col-lg-3"><span class="sub-text"><?php esc_html_e( 'گزینه‌های قدیمی', 'kasebi-erp' ); ?></span><strong class="d-block fs-5" data-tax-term-total><?php echo esc_html( number_format_i18n( $legacy_taxonomy_migration['term_total'] ) ); ?></strong></div>
								<div class="col-6 col-lg-3"><span class="sub-text"><?php esc_html_e( 'مسئول‌های قدیمی', 'kasebi-erp' ); ?></span><strong class="d-block fs-5" data-tax-owner-total><?php echo esc_html( number_format_i18n( $legacy_taxonomy_migration['owner_total'] ) ); ?></strong></div>
								<div class="col-6 col-lg-3"><span class="sub-text"><?php esc_html_e( 'کاربران', 'kasebi-erp' ); ?></span><strong class="d-block fs-5" data-tax-total><?php echo esc_html( number_format_i18n( $legacy_taxonomy_migration['total'] ) ); ?></strong></div>
								<div class="col-6 col-lg-3"><span class="sub-text"><?php esc_html_e( 'باقی‌مانده', 'kasebi-erp' ); ?></span><strong class="d-block fs-5" data-tax-remaining><?php echo esc_html( number_format_i18n( $legacy_taxonomy_migration['remaining'] ) ); ?></strong></div>
							</div>
							<button type="button" class="btn btn-outline-primary" data-tax-migrate <?php disabled( $legacy_taxonomy_migration['complete'] ); ?>>
								<em class="icon ni ni-upload-cloud"></em><span><?php echo ! $legacy_taxonomy_migration['complete'] ? esc_html__( 'شروع انتقال', 'kasebi-erp' ) : esc_html__( 'انتقال کامل است', 'kasebi-erp' ); ?></span>
							</button>
							<p class="text-soft mt-2 mb-0" data-tax-message role="status" aria-live="polite"><?php esc_html_e( 'گزینه‌ها و مقادیر فعلی ERP حفظ و با اطلاعات قدیمی ادغام می‌شوند.', 'kasebi-erp' ); ?></p>
						<?php endif; ?>
					</div>
				</div>
            </div>

            <div class="col-xl-4">
                <div class="card card-bordered mb-4">
                    <div class="card-inner border-bottom">
                        <div class="card-title-group align-start">
                            <div class="card-title">
                                <h6 class="title">
                                    <em class="icon ni ni-check-round-cut me-1"></em>
									<?php esc_html_e( 'فیلدهای الزامی', 'kasebi-erp' ); ?>
                                </h6>
                                <p class="text-soft"><?php printf( esc_html__( 'اطلاعاتی که بدون آن‌ها ثبت %s انجام نمی‌شود.', 'kasebi-erp' ), esc_html( $singular_label ) ); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="card-inner">
                        <div class="kerp-customer-required-list">
							<?php foreach ( $required_fields as $setting_key => $field ) :
								$field_id = 'kerp-customers-' . sanitize_html_class( $setting_key );
								$enabled = ! empty( $settings[ $setting_key ] );
								?>
                                <input type="hidden"
                                       class="no_clear"
                                       name="settings[<?php echo esc_attr( $setting_key ); ?>]"
                                       data-for="settings[<?php echo esc_attr( $setting_key ); ?>]"
                                       value="0">
                                <label class="kerp-settings-option<?php echo $enabled ? ' is-enabled' : ''; ?>"
                                       for="<?php echo esc_attr( $field_id ); ?>">
                                    <span class="kerp-settings-option__content">
                                        <span class="kerp-settings-option__icon">
                                            <em class="<?php echo esc_attr( $field['icon'] ); ?> icon"></em>
                                        </span>
                                        <span>
                                            <strong><?php echo esc_html( $field['label'] ); ?></strong>
                                            <small><?php echo esc_html( $field['description'] ); ?></small>
                                        </span>
                                    </span>
                                    <span class="custom-control custom-switch">
                                        <input type="checkbox"
                                               id="<?php echo esc_attr( $field_id ); ?>"
                                               class="custom-control-input no_clear"
                                               name="settings[<?php echo esc_attr( $setting_key ); ?>]"
                                               data-for="settings[<?php echo esc_attr( $setting_key ); ?>]"
                                               value="1"
											<?php checked( $enabled ); ?>>
                                        <span class="custom-control-label"></span>
                                    </span>
                                </label>
							<?php endforeach; ?>
                        </div>
                    </div>
                </div>

                <div class="card card-bordered">
                    <div class="card-inner border-bottom">
                        <div class="card-title-group align-start">
                            <div class="card-title">
                                <h6 class="title">
                                    <em class="icon ni ni-list-thumb me-1"></em>
									<?php esc_html_e( 'نمایش فهرست', 'kasebi-erp' ); ?>
                                </h6>
                                <p class="text-soft"><?php printf( esc_html__( 'تعداد و اطلاعات قابل نمایش در صفحه %s را تنظیم کنید.', 'kasebi-erp' ), esc_html( $plural_label ) ); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="card-inner">
                        <div class="form-group">
                            <label class="form-label" for="kerp-customers-default-per-page">
								<?php esc_html_e( 'تعداد پیش‌فرض در هر صفحه', 'kasebi-erp' ); ?>
                            </label>
                            <div class="form-control-wrap">
                                <div class="form-icon form-icon-right">
                                    <em class="icon ni ni-list"></em>
                                </div>
                                <input type="number"
                                       id="kerp-customers-default-per-page"
                                       class="form-control number_type no_clear"
                                       name="settings[default_per_page]"
                                       data-for="settings[default_per_page]"
                                       data-req="1"
                                       min="1"
                                       max="200"
                                       value="<?php echo esc_attr( $default_per_page ); ?>">
                            </div>
                            <div
                                class="form-note"><?php esc_html_e( 'مقدار مجاز بین ۱ تا ۲۰۰ است.', 'kasebi-erp' ); ?></div>
                        </div>

                        <input type="hidden"
                               class="no_clear"
                               name="settings[show_registration_at]"
                               data-for="settings[show_registration_at]"
                               value="0">

                        <label class="kerp-settings-option mt-4"
                               for="kerp-customers-show-registration-at">
                            <span class="kerp-settings-option__content">
                                <span class="kerp-settings-option__icon">
                                    <em class="kik fa-calendar-check-02 icon"></em>
                                </span>
                                <span>
                                    <strong><?php esc_html_e( 'نمایش تاریخ عضویت', 'kasebi-erp' ); ?></strong>
                                    <small><?php printf( esc_html__( 'تاریخ ثبت حساب در فهرست %s نمایش داده شود.', 'kasebi-erp' ), esc_html( $plural_label ) ); ?></small>
                                </span>
                            </span>
                            <span class="custom-control custom-switch">
                                <input type="checkbox"
                                       id="kerp-customers-show-registration-at"
                                       class="custom-control-input no_clear"
                                       name="settings[show_registration_at]"
                                       data-for="settings[show_registration_at]"
                                       value="1"
									<?php checked( $show_registration_at ); ?>>
                                <span class="custom-control-label"></span>
                            </span>
                        </label>

                        <div class="alert alert-light alert-icon mt-4 mb-0">
                            <em class="icon ni ni-info-fill"></em>
                            <div>
                                <strong><?php esc_html_e( 'تأثیر تنظیمات', 'kasebi-erp' ); ?></strong>
                                <p class="mb-0">
									<?php printf( esc_html__( 'تغییر عنوان‌ها و نمایش فهرست، اطلاعات ذخیره‌شده %s قبلی را تغییر نمی‌دهد.', 'kasebi-erp' ), esc_html( $plural_label ) ); ?>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>

<?php $search_index_status = KERP_Modules_Customers_Search_Index::instance()->status(); ?>
    <div class="card card-bordered mt-4" id="kerp-customers-search-index"
         data-nonce="<?php echo esc_attr( wp_create_nonce( 'kerp_customers_search_index' ) ); ?>"
         data-generation="<?php echo esc_attr( $search_index_status['complete'] ? '' : $search_index_status['generation'] ); ?>">
        <div class="card-inner border-bottom">
            <h6 class="title"><?php esc_html_e( 'ایندکس جستجوی مشتریان', 'kasebi-erp' ); ?></h6>
            <p class="text-soft mb-0"><?php esc_html_e( 'نام، شماره تماس، نقش و مسئول مشتری به‌صورت خودکار همگام می‌شوند. بازسازی، اطلاعات اصلی کاربران را تغییر نمی‌دهد.', 'kasebi-erp' ); ?></p>
        </div>
        <div class="card-inner">
            <div class="row g-3 mb-3">
                <div class="col-4"><span class="sub-text"><?php esc_html_e( 'کل کاربران', 'kasebi-erp' ); ?></span><strong class="d-block" data-index-total><?php echo esc_html( number_format_i18n( $search_index_status['total'] ) ); ?></strong></div>
                <div class="col-4"><span class="sub-text"><?php esc_html_e( 'پردازش‌شده', 'kasebi-erp' ); ?></span><strong class="d-block" data-index-processed><?php echo esc_html( number_format_i18n( $search_index_status['processed'] ) ); ?></strong></div>
                <div class="col-4"><span class="sub-text"><?php esc_html_e( 'باقی‌مانده', 'kasebi-erp' ); ?></span><strong class="d-block" data-index-remaining><?php echo esc_html( number_format_i18n( $search_index_status['remaining'] ) ); ?></strong></div>
            </div>
            <div class="progress mb-3">
                <div class="progress-bar" data-index-progress role="progressbar" aria-label="<?php esc_attr_e( 'پیشرفت بازسازی ایندکس', 'kasebi-erp' ); ?>" aria-valuemin="0" aria-valuemax="100" aria-valuenow="<?php echo esc_attr( $search_index_status['percent'] ); ?>" style="width: <?php echo esc_attr( $search_index_status['percent'] ); ?>%"></div>
            </div>
            <p data-index-message role="status" aria-live="polite"><?php echo esc_html( $search_index_status['complete']
                ? __( 'ایندکس آماده است.', 'kasebi-erp' )
                : __( 'تا پایان بازسازی، جستجو موقتاً در دسترس نیست. با دکمه زیر ادامه دهید.', 'kasebi-erp' ) ); ?></p>
            <button type="button" class="btn btn-outline-primary" data-index-rebuild>
                <em class="icon ni ni-reload"></em><span><?php echo esc_html( $search_index_status['complete'] ? __( 'بازسازی ایندکس جستجو', 'kasebi-erp' ) : __( 'ادامه بازسازی ایندکس', 'kasebi-erp' ) ); ?></span>
            </button>
        </div>
    </div>
