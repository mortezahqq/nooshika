<?php

defined( 'ABSPATH' ) || exit;

/**
 * @var WP_User                           $customer
 * @var array                             $columns
 * @var KERP_Modules_Customers_List_Table $list_table
 * @var array                             $context
 */

if ( ! isset( $customer ) || ! $customer instanceof WP_User ) {
	return;
}

$columns     = isset( $columns ) && is_array( $columns ) ? $columns : [];
$list_table  = isset( $list_table ) && $list_table instanceof KERP_Modules_Customers_List_Table
	? $list_table
	: KERP_Modules_Customers_List_Table::instance();
$context     = isset( $context ) && is_array( $context ) ? $context : [];
$customer_id = absint( $customer->ID );
$data_url    = '/erp/customers/' . $customer_id . '/';

$row_actions = [
	'view' => [
		'title'    => __( 'مشاهده پروفایل', 'kasebi-erp' ),
		'icon'     => 'ni ni-eye',
		'url'      => home_url( $data_url ),
		'data_url' => $data_url,
		'class'    => 'page_activator',
	],
];

if ( KERP_Api_Auth::instance()->can_login_as_user( $customer ) ) {
	$row_actions['login_as_customer'] = [
		'title' => __( 'ورود به عنوان کاربر', 'kasebi-erp' ),
		'icon'  => 'ni ni-signin',
		'url'   => '#',
		'class' => 'login_as_this',
		'data'  => [ 'id' => $customer_id ],
	];
}

$row_actions = apply_filters(
	'kerp_customers_row_actions',
	$row_actions,
	$customer_id,
	$customer,
	$context
);

?>
<div class="nk-tb-item kerp-customer-list-row" data-customer-id="<?php echo esc_attr( $customer_id ); ?>">
    <div class="nk-tb-col nk-tb-col-check">
        <div class="custom-control custom-control-sm custom-checkbox notext">
            <input
                type="checkbox"
                class="custom-control-input select_item_row"
                id="kerp-customer-row-<?php echo esc_attr( $customer_id ); ?>"
                value="<?php echo esc_attr( $customer_id ); ?>"
                aria-label="<?php echo esc_attr( sprintf( __( 'انتخاب %s', 'kasebi-erp' ), $customer->display_name ) ); ?>"
            >
            <label
                class="custom-control-label"
                for="kerp-customer-row-<?php echo esc_attr( $customer_id ); ?>"
            ></label>
        </div>
    </div>
	
	<?php foreach ( $columns as $column_key => $column ) : ?>
		<?php
		if ( ! is_array( $column ) ) {
			continue;
		}
		
		$column_key   = sanitize_key( (string) ( $column['key'] ?? $column_key ) );
		$column_class = sanitize_text_field( (string) ( $column['class'] ?? '' ) );
		
		ob_start();
		$list_table->render_column( $column_key, $customer, $context );
		$content = trim( (string) ob_get_clean() );
		?>
        <div class="nk-tb-col kerp-customer-cell kerp-customer-cell--<?php echo esc_attr( $column_key ); ?> <?php echo esc_attr( $column_class ); ?>">
            <span class="kerp-customer-cell-label sub-text"><?php echo esc_html( (string) ( $column['label'] ?? $column_key ) ); ?></span>
			<?php echo $content !== '' ? $content : '<span class="text-soft">—</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
        </div>
	<?php endforeach; ?>

    <div class="nk-tb-col nk-tb-col-tools">
        <div class="d-flex align-center justify-end">
			<?php
			ob_start();
			$list_table->render_row_icons_column( $customer );
			echo trim( (string) ob_get_clean() );
			echo KERP_Helpers_Template::get_template(
				'app/components/list/row-actions.php',
				[
					'actions' => $row_actions,
				]
			);
			?>
        </div>
    </div>
</div>
