<?php
defined( 'ABSPATH' ) || exit;
KERP_Helpers_Template::render_template( 'app/components/attribution-summary.php', [
    'data' => isset( $data ) && is_array( $data ) ? $data : [],
    'first_touch_style' => TRUE,
] );
