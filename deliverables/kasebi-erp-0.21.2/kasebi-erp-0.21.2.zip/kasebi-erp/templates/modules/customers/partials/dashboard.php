<?php
defined( 'ABSPATH' ) || exit;
$colors = [ '#6576ff', '#1ee0ac', '#09c2de', '#f4bd0e', '#e85347', '#816bff', '#8094ae' ];
if ( $kind === 'products' ) { $colors = array_fill( 0, 7, '#8b5cf6' ); }
?>
<?php if ( $kind === 'memberships' ) : ?>
    <div class="kerp-dashboard-metric d-flex justify-content-between align-items-center mb-3 gap-2">
        <div><div class="h2 mb-1 text-primary" id="kerp-customers-membership-total"><?php echo esc_html( number_format_i18n( array_sum( $series['data'] ) ) ); ?></div><span class="sub-text" id="kerp-customers-membership-period">۷ روز اخیر</span></div>
        <div class="dropdown">
            <button type="button" class="btn btn-sm btn-outline-light dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">بازه زمانی</button>
            <div class="dropdown-menu dropdown-menu-end"><ul class="link-list-opt no-bdr">
                <?php foreach ( [ 7, 15, 30 ] as $days ) : ?>
                    <li><a href="#" class="request_dashboard_block_data<?php echo $days === 7 ? ' active' : ''; ?>" data-action="customers_dashboard_memberships" data-atts="<?php echo esc_attr( 'days:' . $days . ';nonce:' . wp_create_nonce( 'kerp-customers-dashboard' ) ); ?>" data-targets="chart:#kerp-customers-membership-chart:chart;total:#kerp-customers-membership-total:text;period:#kerp-customers-membership-period:text"><em class="icon ni ni-calendar"></em><span><?php echo esc_html( number_format_i18n( $days ) ); ?> روز اخیر</span></a></li>
                <?php endforeach; ?>
            </ul></div>
        </div>
    </div>
    <div class="position-relative w-100" style="height:220px"><div id="kerp-customers-membership-chart" style="height:220px" class="kasebi-chart" data-chart-type="area" data-legend="0" data-label="عضویت جدید" data-unit="نفر" data-color="#6576ff" data-labels="<?php echo esc_attr( wp_json_encode( $series['labels'] ) ); ?>" data-data="<?php echo esc_attr( wp_json_encode( $series['data'] ) ); ?>" ><canvas role="img" aria-label="نمودار روزانه عضویت‌های جدید">تعداد عضویت‌های جدید در هر روز</canvas></div></div>
    <p class="sub-text mt-3 mb-0">عضویت‌های جدید مشتریان قابل‌مشاهده؛ روزهای بدون عضویت با صفر نمایش داده می‌شوند.</p>
<?php elseif ( $kind === 'channels' ) : ?>
    <div class="d-flex flex-wrap justify-content-between gap-2 mb-3"><span class="sub-text">۳۰ روز اخیر · <?php echo esc_html( number_format_i18n( $stats['total'] ) ); ?> عضویت جدید</span><a class="page_activator" href="<?php echo esc_url( home_url( '/erp/customers/' ) ); ?>" data-url="/erp/customers/">مشاهده مشتریان</a></div>
    <?php if ( ! $stats['total'] ) : ?>
        <div class="text-center py-5"><em class="icon ni ni-users fs-2 text-soft"></em><p class="sub-text mt-2 mb-0">در این بازه عضویت جدیدی ثبت نشده است.</p></div>
    <?php else : foreach ( $stats['channels'] as $type => $row ) :
        $percent = round( $row['count'] / $stats['total'] * 100, 1 );
        $tone = [ 'landing_order' => 'success', 'gravity_form' => 'primary', 'site_registration' => 'info' ][ $type ] ?? 'secondary';
        $icon = [ 'landing_order' => 'cart', 'gravity_form' => 'file-text', 'site_registration' => 'user-add' ][ $type ] ?? 'help';
        $dates = array_keys( $stats['daily'] );
        $channel_url = add_query_arg( [
            'first_touch_type' => $type === 'unknown' ? '__unknown__' : $type,
            'registered' => [
                'from' => KERP_Helpers_Date::gregorian_to_jalali( reset( $dates ) ),
                'to' => KERP_Helpers_Date::gregorian_to_jalali( end( $dates ) ),
            ],
        ], home_url( '/erp/customers/' ) );
        ?>
        <a class="page_activator d-block mb-4 text-decoration-none" href="<?php echo esc_url( $channel_url ); ?>" data-url="<?php echo esc_url( $channel_url ); ?>" aria-label="<?php echo esc_attr( 'مشاهده مشتریان: ' . $row['label'] ); ?>">
            <div class="d-flex align-items-center justify-content-between gap-2 mb-2">
                <div class="d-flex align-items-center gap-2"><span class="user-avatar sm bg-<?php echo esc_attr( $tone ); ?>-dim"><em class="icon ni ni-<?php echo esc_attr( $icon ); ?>"></em></span><span class="fw-medium text-base"><?php echo esc_html( $row['label'] ); ?></span></div>
                <span class="text-nowrap sub-text"><?php echo esc_html( number_format_i18n( $row['count'] ) . ' نفر · ' . number_format_i18n( $percent, 1 ) . '٪' ); ?></span>
            </div>
            <div class="progress progress-md"><div class="progress-bar bg-<?php echo esc_attr( $tone ); ?>" role="progressbar" style="width:<?php echo esc_attr( $percent ); ?>%" aria-label="<?php echo esc_attr( $row['label'] ); ?>" aria-valuenow="<?php echo esc_attr( $percent ); ?>" aria-valuemin="0" aria-valuemax="100"></div></div>
        </a>
    <?php endforeach; endif; ?>
<?php else :
    $rows = [];
    foreach ( $stats[ $kind ] ?? [] as $id => $row ) { $rows[] = array_merge( $row, [ 'filter_value' => (string) $id ] ); }
    $total = array_sum( array_column( $rows, 'count' ) );
    // Keep the chart legible even when many distinct products or forms contributed.
    if ( count( $rows ) > 7 ) {
        $others = array_slice( $rows, 6 ); $rows = array_slice( $rows, 0, 6 );
        $rows[] = [ 'label' => 'سایر', 'count' => array_sum( array_column( $others, 'count' ) ), 'filter_value' => 'except:' . implode( ',', array_column( $rows, 'filter_value' ) ) ];
    }
    ?>
    <p class="sub-text mb-3">۳۰ روز اخیر · <?php echo $kind === 'products' ? 'محصولات فرم لندینگ و سبد خرید هنگام عضویت' : 'فرم‌های منجر به ایجاد حساب مشتری'; ?></p>
    <?php if ( ! $total ) : ?>
        <div class="text-center py-5"><em class="icon ni ni-pie fs-2 text-soft"></em><p class="sub-text mt-2 mb-0">داده‌ای برای نمایش در این بازه وجود ندارد.</p></div>
    <?php else : ?>
        <div class="position-relative w-100 mb-3" style="height:200px"><div class="kasebi-chart" style="height:200px" data-chart-type="<?php echo $kind === 'products' ? 'horizontalBar' : 'doughnut'; ?>" data-color="#8b5cf6" data-cutout="76" data-legend="0" data-unit="عضویت" data-labels="<?php echo esc_attr( wp_json_encode( array_column( $rows, 'label' ) ) ); ?>" data-data="<?php echo esc_attr( wp_json_encode( array_column( $rows, 'count' ) ) ); ?>" data-colors="<?php echo esc_attr( wp_json_encode( $colors ) ); ?>" ><canvas role="img" aria-label="<?php echo $kind === 'products' ? 'سهم محصولات در اولین ورود' : 'سهم فرم‌ها در اولین ورود'; ?>">جزئیات نمودار در فهرست زیر آمده است.</canvas></div></div>
        <ul class="list-unstyled mb-0">
            <?php foreach ( $rows as $index => $row ) :
                $dates = array_keys( $stats['daily'] );
                $row_url = add_query_arg( [
                    'first_touch_type' => $kind === 'products' ? '__products__' : 'gravity_form',
                    $kind === 'products' ? 'first_touch_product' : 'first_touch_form_id' => $row['filter_value'],
                    'registered' => [ 'from' => KERP_Helpers_Date::gregorian_to_jalali( reset( $dates ) ), 'to' => KERP_Helpers_Date::gregorian_to_jalali( end( $dates ) ) ],
                ], home_url( '/erp/customers/' ) );
                ?>
                <li><a class="page_activator d-flex align-items-center justify-content-between gap-2 py-1 text-decoration-none" href="<?php echo esc_url( $row_url ); ?>" data-url="<?php echo esc_url( $row_url ); ?>">
                    <span class="d-flex align-items-center gap-1 text-truncate" style="min-width:0" title="<?php echo esc_attr( $row['label'] ); ?>"><em class="icon ni ni-bullet-fill flex-shrink-0" style="color:<?php echo esc_attr( $colors[ $index ] ); ?>"></em><span class="text-truncate"><?php echo esc_html( $row['label'] ); ?></span></span>
                    <span class="sub-text text-nowrap"><?php echo esc_html( number_format_i18n( $row['count'] ) . ' · ' . number_format_i18n( $row['count'] / $total * 100, 1 ) . '٪' ); ?></span>
                </a></li>
            <?php endforeach; ?>
        </ul>
        <?php if ( $kind === 'products' ) : ?><p class="sub-text small mt-3 mb-0">هر محصول برای هر مشتری یک‌بار شمرده می‌شود؛ یک عضویت می‌تواند چند محصول داشته باشد.</p><?php endif; ?>
    <?php endif; ?>
<?php endif; ?>
