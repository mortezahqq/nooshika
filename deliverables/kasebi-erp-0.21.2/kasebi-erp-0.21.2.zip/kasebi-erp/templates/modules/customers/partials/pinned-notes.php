<?php

defined( 'ABSPATH' ) || exit;

/**
 * @var array $notes
 * @var int   $customer_id
 */

if ( empty( $notes ) ) {
	return;
}

$notes_service = KERP_Modules_Customers_Notes::instance();
$notes_url     = '/erp/customers/' . absint( $customer_id ) . '/?tab=notes';
?>
<div class="mb-4">
	<?php foreach ( $notes as $note ) : ?>
		<?php $type = $notes_service->get_type( (string) ( $note['type'] ?? 'important' ) ); ?>
        <div class="alert alert-warning alert-icon mb-2">
            <em class="icon <?php echo esc_attr( (string) ( $type['icon'] ?? 'ni ni-alert-circle' ) ); ?>"></em>
            <div class="d-flex justify-between align-center flex-grow-1 g-2">
                <div>
                    <strong><?php echo esc_html( (string) ( $type['label'] ?? __( 'نکته مهم', 'kasebi-erp' ) ) ); ?>
                        :</strong>
					<?php echo nl2br( esc_html( (string) ( $note['content'] ?? '' ) ) ); ?>
                </div>
                <a href="#" class="page_activator text-nowrap fs-12px" data-url="<?php echo esc_url( $notes_url ); ?>">
					<?php esc_html_e( 'مشاهده یادداشت‌ها', 'kasebi-erp' ); ?>
                </a>
            </div>
        </div>
	<?php endforeach; ?>
</div>
