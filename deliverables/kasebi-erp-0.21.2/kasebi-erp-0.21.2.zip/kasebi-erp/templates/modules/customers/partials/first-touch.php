<?php

defined( 'ABSPATH' ) || exit;

$data = isset( $data ) && is_array( $data ) ? $data : [];
$type = sanitize_key( (string) ( $data['type'] ?? '' ) );
$types = [
	'landing_order' => [
		'label'       => __( 'ثبت سفارش از لندینگ', 'kasebi-erp' ),
		'description' => __( 'این کاربر با تکمیل فرم خرید یک محصول عضو سایت شده است.', 'kasebi-erp' ),
		'icon'        => 'ni ni-cart',
		'tone'        => 'success',
	],
	'gravity_form' => [
		'label'       => __( 'تکمیل Gravity Form', 'kasebi-erp' ),
		'description' => __( 'اولین حساب کاربر هنگام ارسال یکی از فرم‌های Gravity Forms ساخته شده است.', 'kasebi-erp' ),
		'icon'        => 'ni ni-edit-alt',
		'tone'        => 'primary',
	],
	'site_registration' => [
		'label'       => __( 'ورود و ثبت‌نام سایت', 'kasebi-erp' ),
		'description' => __( 'کاربر برای ورود به یک بخش محدودشده، حساب خود را ایجاد کرده است.', 'kasebi-erp' ),
		'icon'        => 'ni ni-signin',
		'tone'        => 'info',
	],
];
$type_data = $types[ $type ] ?? [
	'label'       => $type !== '' ? $type : __( 'مسیر نامشخص', 'kasebi-erp' ),
	'description' => __( 'اطلاعات اولین نقطه عضویت این کاربر ثبت شده است.', 'kasebi-erp' ),
	'icon'        => 'ni ni-flag',
	'tone'        => 'secondary',
];

$registered_at = '';
if ( ! empty( $data['registered_at'] ) ) {
	$local_time = get_date_from_gmt( (string) $data['registered_at'], 'Y-m-d H:i:s' );
	$timestamp  = strtotime( $local_time );
	$registered_at = $timestamp ? date_i18n( 'j F Y، H:i', $timestamp ) : (string) $data['registered_at'];
}

$format_id = static fn( mixed $value ): string => absint( $value ) > 0 ? '#' . number_format_i18n( absint( $value ) ) : '';
$action_facts = [];
if ( ! empty( $data['form_title'] ) || ! empty( $data['form_id'] ) ) {
	$action_facts[] = [ 'icon' => 'ni ni-template', 'label' => __( 'فرم', 'kasebi-erp' ), 'value' => (string) ( $data['form_title'] ?? __( 'Gravity Form', 'kasebi-erp' ) ), 'meta' => $format_id( $data['form_id'] ?? 0 ) ];
}
if ( ! empty( $data['entry_id'] ) ) {
	$action_facts[] = [ 'icon' => 'ni ni-file-docs', 'label' => __( 'ورودی فرم', 'kasebi-erp' ), 'value' => $format_id( $data['entry_id'] ), 'meta' => '' ];
}
if ( ! empty( $data['order_id'] ) ) {
	$action_facts[] = [ 'icon' => 'ni ni-bag', 'label' => __( 'سفارش ایجادشده', 'kasebi-erp' ), 'value' => $format_id( $data['order_id'] ), 'meta' => '' ];
}

$destination_url   = (string) ( $data['redirect_to'] ?? $data['landing_page'] ?? '' );
$destination_title = (string) ( $data['redirect_post_title'] ?? '' );
$destination_href  = $destination_url !== '' && preg_match( '#^https?://#i', $destination_url )
	? $destination_url
	: home_url( '/' . ltrim( $destination_url, '/' ) );
$is_redirect_destination = ! empty( $data['redirect_to'] );
$destination_meta  = [];
if ( ! empty( $data['redirect_post_type'] ) ) { $destination_meta[] = (string) $data['redirect_post_type']; }
if ( ! empty( $data['redirect_post_id'] ) ) { $destination_meta[] = $format_id( $data['redirect_post_id'] ); }

$attribution = [
	[ 'label' => __( 'نوع منبع', 'kasebi-erp' ), 'value' => $data['source_type'] ?? '' ],
	[ 'label' => 'UTM Source', 'value' => $data['utm_source'] ?? '' ],
	[ 'label' => 'UTM Medium', 'value' => $data['utm_medium'] ?? '' ],
	[ 'label' => 'UTM Campaign', 'value' => $data['utm_campaign'] ?? '' ],
	[ 'label' => 'UTM Content', 'value' => $data['utm_content'] ?? '' ],
	[ 'label' => 'UTM Term', 'value' => $data['utm_term'] ?? '' ],
];
$attribution = array_values( array_filter( $attribution, static fn( array $item ): bool => (string) $item['value'] !== '' ) );
$referrer = (string) ( $data['referrer'] ?? '' );
$landing  = (string) ( $data['landing_page'] ?? '' );
$items    = ! empty( $data['products'] ) ? (array) $data['products'] : (array) ( $data['cart_items'] ?? [] );
?>
<div class="nk-divider divider md"></div>
<section class="kerp-first-touch kerp-first-touch--<?php echo esc_attr( $type_data['tone'] ); ?>" aria-labelledby="kerp-first-touch-title">
    <div class="kerp-first-touch__hero">
        <div class="kerp-first-touch__identity">
            <span class="kerp-first-touch__hero-icon"><em class="icon <?php echo esc_attr( $type_data['icon'] ); ?>"></em></span>
            <div>
                <span class="kerp-first-touch__eyebrow"><?php esc_html_e( 'نقطه شروع ارتباط', 'kasebi-erp' ); ?></span>
                <h6 id="kerp-first-touch-title" class="kerp-first-touch__title"><?php echo esc_html( $type_data['label'] ); ?></h6>
                <p class="kerp-first-touch__description"><?php echo esc_html( $type_data['description'] ); ?></p>
            </div>
        </div>
        <div class="kerp-first-touch__hero-meta">
            <span class="kerp-first-touch__immutable"><em class="icon ni ni-lock-alt"></em><?php esc_html_e( 'اولین رکورد؛ غیرقابل بازنویسی', 'kasebi-erp' ); ?></span>
		<?php if ( $registered_at !== '' ) : ?>
            <span class="kerp-first-touch__date"><em class="icon ni ni-calendar"></em><?php echo esc_html( $registered_at ); ?></span>
		<?php endif; ?>
        </div>
    </div>

    <div class="kerp-first-touch__journey" aria-label="<?php esc_attr_e( 'مسیر عضویت کاربر', 'kasebi-erp' ); ?>">
        <div class="kerp-first-touch__journey-step is-complete"><span><em class="icon ni ni-compass"></em></span><small><?php esc_html_e( 'ورود اولیه', 'kasebi-erp' ); ?></small></div>
        <div class="kerp-first-touch__journey-line"></div>
        <div class="kerp-first-touch__journey-step is-complete"><span><em class="icon <?php echo esc_attr( $type_data['icon'] ); ?>"></em></span><small><?php esc_html_e( 'اقدام کاربر', 'kasebi-erp' ); ?></small></div>
        <div class="kerp-first-touch__journey-line"></div>
        <div class="kerp-first-touch__journey-step is-current"><span><em class="icon ni ni-user-add"></em></span><small><?php esc_html_e( 'ساخت حساب', 'kasebi-erp' ); ?></small></div>
    </div>

    <div class="kerp-first-touch__grid">
        <article class="kerp-first-touch__panel">
            <div class="kerp-first-touch__panel-head">
                <span><em class="icon ni ni-activity-round"></em></span>
                <div><h6><?php esc_html_e( 'اقدام منجر به عضویت', 'kasebi-erp' ); ?></h6><p><?php esc_html_e( 'رویدادی که حساب کاربر را ایجاد کرد', 'kasebi-erp' ); ?></p></div>
            </div>
            <div class="kerp-first-touch__facts">
                <div class="kerp-first-touch__fact is-featured">
                    <span class="kerp-first-touch__fact-icon"><em class="icon <?php echo esc_attr( $type_data['icon'] ); ?>"></em></span>
                    <div><small><?php esc_html_e( 'کانال عضویت', 'kasebi-erp' ); ?></small><strong><?php echo esc_html( $type_data['label'] ); ?></strong></div>
                </div>
			<?php foreach ( $action_facts as $fact ) : ?>
                <div class="kerp-first-touch__fact">
                    <span class="kerp-first-touch__fact-icon"><em class="icon <?php echo esc_attr( $fact['icon'] ); ?>"></em></span>
                    <div><small><?php echo esc_html( $fact['label'] ); ?></small><strong><?php echo esc_html( $fact['value'] ); ?></strong><?php if ( $fact['meta'] !== '' ) : ?><span><?php echo esc_html( $fact['meta'] ); ?></span><?php endif; ?></div>
                </div>
			<?php endforeach; ?>
            </div>
        </article>

        <article class="kerp-first-touch__panel">
            <div class="kerp-first-touch__panel-head">
                <span><em class="icon ni ni-map-pin"></em></span>
                <div><h6><?php esc_html_e( 'مقصد و زمینه ورود', 'kasebi-erp' ); ?></h6><p><?php esc_html_e( 'صفحه‌ای که کاربر پیش از عضویت در آن قرار داشت', 'kasebi-erp' ); ?></p></div>
            </div>
		<?php if ( $destination_url !== '' || $destination_title !== '' ) : ?>
            <div class="kerp-first-touch__destination">
                <span class="kerp-first-touch__destination-icon"><em class="icon ni ni-link-alt"></em></span>
                <div>
                    <small><?php echo $is_redirect_destination ? esc_html__( 'مقصد بعد از ورود', 'kasebi-erp' ) : esc_html__( 'لندینگ اولیه', 'kasebi-erp' ); ?></small>
                    <strong><?php echo esc_html( $destination_title !== '' ? $destination_title : $destination_url ); ?></strong>
				<?php if ( ! empty( $destination_meta ) ) : ?><span><?php echo esc_html( implode( ' · ', $destination_meta ) ); ?></span><?php endif; ?>
				<?php if ( $destination_url !== '' ) : ?><a href="<?php echo esc_url( $destination_href ); ?>" target="_blank" rel="noopener noreferrer" dir="ltr"><?php echo esc_html( $destination_url ); ?><em class="icon ni ni-external"></em></a><?php endif; ?>
                </div>
            </div>
		<?php else : ?>
            <p class="kerp-first-touch__muted"><?php esc_html_e( 'مقصد مشخصی برای این عضویت ثبت نشده است.', 'kasebi-erp' ); ?></p>
		<?php endif; ?>
        </article>
    </div>

	<?php if ( ! empty( $items ) ) : ?>
    <article class="kerp-first-touch__products">
        <div class="kerp-first-touch__section-head">
            <div><span><em class="icon ni ni-bag"></em></span><div><h6><?php esc_html_e( 'محصولات همان لحظه', 'kasebi-erp' ); ?></h6><p><?php esc_html_e( 'اقلام لندینگ سفارش یا سبد خرید هنگام ساخت حساب', 'kasebi-erp' ); ?></p></div></div>
            <span class="badge badge-dim bg-primary"><?php echo esc_html( sprintf( _n( '%s محصول', '%s محصول', count( $items ), 'kasebi-erp' ), number_format_i18n( count( $items ) ) ) ); ?></span>
        </div>
        <div class="kerp-first-touch__product-grid">
		<?php foreach ( $items as $item ) :
			$product_id = absint( ( $item['variation_id'] ?? 0 ) ?: ( $item['product_id'] ?? 0 ) );
			$base_id    = absint( $item['product_id'] ?? $product_id );
			$name       = (string) ( ( $item['name'] ?? '' ) ?: __( 'محصول', 'kasebi-erp' ) );
			$quantity   = max( 0.0001, (float) ( $item['quantity'] ?? 1 ) );
			$quantity_decimals = floor( $quantity ) === $quantity ? 0 : 2;
			$image      = $base_id > 0 ? get_the_post_thumbnail_url( $base_id, 'thumbnail' ) : '';
			?>
            <div class="kerp-first-touch__product">
                <span class="kerp-first-touch__product-image"><?php if ( $image ) : ?><img src="<?php echo esc_url( $image ); ?>" alt=""><?php else : ?><em class="icon ni ni-package"></em><?php endif; ?></span>
                <div><strong><?php echo esc_html( $name ); ?></strong><span><?php echo esc_html( sprintf( __( 'شناسه %s', 'kasebi-erp' ), $format_id( $product_id ) ) ); ?></span></div>
                <span class="kerp-first-touch__quantity"><?php echo esc_html( '× ' . number_format_i18n( $quantity, $quantity_decimals ) ); ?></span>
            </div>
		<?php endforeach; ?>
        </div>
    </article>
	<?php endif; ?>

	<?php if ( ! empty( $attribution ) || $referrer !== '' || ( $landing !== '' && $landing !== $destination_url ) ) : ?>
    <article class="kerp-first-touch__attribution">
        <div class="kerp-first-touch__section-head">
            <div><span><em class="icon ni ni-growth"></em></span><div><h6><?php esc_html_e( 'منبع جذب', 'kasebi-erp' ); ?></h6><p><?php esc_html_e( 'اطلاعات بازاریابی اولین ورود ثبت‌شده', 'kasebi-erp' ); ?></p></div></div>
        </div>
		<?php if ( ! empty( $attribution ) ) : ?><div class="kerp-first-touch__chips"><?php foreach ( $attribution as $item ) : ?><span><small><?php echo esc_html( $item['label'] ); ?></small><strong><?php echo esc_html( (string) $item['value'] ); ?></strong></span><?php endforeach; ?></div><?php endif; ?>
        <div class="kerp-first-touch__links">
		<?php foreach ( [ __( 'لندینگ اول', 'kasebi-erp' ) => $landing, __( 'ارجاع‌دهنده', 'kasebi-erp' ) => $referrer ] as $label => $url ) : if ( $url === '' ) { continue; } ?>
            <div><span><?php echo esc_html( $label ); ?></span><a href="<?php echo esc_url( $url ); ?>" target="_blank" rel="noopener noreferrer" dir="ltr"><?php echo esc_html( $url ); ?><em class="icon ni ni-external"></em></a></div>
		<?php endforeach; ?>
        </div>
    </article>
	<?php endif; ?>
</section>
