<?php

defined( 'ABSPATH' ) || exit;

if ( ! isset( $item, $service ) || ! is_array( $item ) || ! $service instanceof KERP_Modules_Customers_History ) {
	return;
}

$customer_id  = absint( $customer_id ?? 0 );
$meta_key     = (string) ( $item['meta_key'] ?? '' );
$event_type   = sanitize_key( (string) ( $item['event_type'] ?? '' ) );
$event_labels = $service->event_labels();
$actor        = get_userdata( absint( $item['actor_id'] ?? 0 ) );
$actor_name   = $actor instanceof WP_User ? (string) get_user_name_by_id( $actor->ID ) : __( 'سیستم', 'kasebi-erp' );
$actor_avatar = $actor instanceof WP_User ? KERP_Helpers_User::get_user_avatar_url( $actor->ID ) : '';
$timestamp    = strtotime( (string) ( $item['created_at'] ?? '' ) );
$old_value    = $service->format_value( $item['old_value'] ?? '', $meta_key, $customer_id );
$new_value    = $service->format_value( $item['new_value'] ?? '', $meta_key, $customer_id );
$badge_class = match ( $event_type ) {
	'added' => 'bg-outline-success',
	'deleted' => 'bg-outline-danger',
	default => 'bg-outline-info',
};
?>
<div class="nk-tb-item" data-history-id="<?php echo esc_attr( absint( $item['id'] ?? 0 ) ); ?>">
    <div class="nk-tb-col">
        <div class="user-card">
            <div class="user-avatar xs bg-light text-primary">
                <em class="icon ni ni-edit-alt-fill"></em>
            </div>
            <div class="user-info">
                <span class="tb-lead"><?php echo esc_html( $service->get_meta_label( $meta_key, $customer_id ) ); ?></span>
            </div>
        </div>
    </div>
    <div class="nk-tb-col">
        <div class="d-flex flex-column g-1">
            <div class="d-flex align-center">
                <span class="sub-text me-2"><?php esc_html_e( 'قبلی:', 'kasebi-erp' ); ?></span>
                <span class="text-break text-soft"><?php echo esc_html( $old_value ); ?></span>
            </div>
            <div class="d-flex align-center">
                <span class="sub-text me-2"><?php esc_html_e( 'جدید:', 'kasebi-erp' ); ?></span>
                <span class="text-break fw-medium text-primary"><?php echo esc_html( $new_value ); ?></span>
            </div>
        </div>
    </div>
    <div class="nk-tb-col tb-col-sm">
        <span class="badge badge-dim <?php echo esc_attr( $badge_class ); ?>">
			<?php echo esc_html( $event_labels[ $event_type ] ?? $event_type ); ?>
        </span>
    </div>
    <div class="nk-tb-col tb-col-lg">
        <div class="user-card">
			<div class="user-avatar sm bg-primary flex-shrink-0 overflow-hidden">
				<?php if ( $actor_avatar !== '' ) : ?>
                    <img
                        src="<?php echo esc_url( $actor_avatar ); ?>"
                        alt="<?php echo esc_attr( $actor_name ); ?>"
                        class="w-100 h-100 object-fit-cover"
                        width="32"
                        height="32"
                        loading="lazy"
                    >
				<?php elseif ( $actor instanceof WP_User ) : ?>
					<?php echo esc_html( KERP_Helpers_User::get_user_avatar( $actor->ID, FALSE, 32 ) ); ?>
				<?php else : ?>
                    <em class="icon ni ni-setting"></em>
				<?php endif; ?>
            </div>
            <div class="user-info overflow-hidden">
                <span class="tb-lead text-nowrap"><?php echo esc_html( $actor_name ); ?></span>
            </div>
        </div>
    </div>
    <div class="nk-tb-col">
        <span class="tb-lead"><?php echo esc_html( $timestamp ? date_i18n( 'Y/m/d', $timestamp ) : '-' ); ?></span>
        <span class="sub-text">
            <em class="icon ni ni-clock me-1"></em>
			<?php echo esc_html( $timestamp ? date_i18n( 'H:i', $timestamp ) : '-' ); ?>
        </span>
    </div>
</div>
