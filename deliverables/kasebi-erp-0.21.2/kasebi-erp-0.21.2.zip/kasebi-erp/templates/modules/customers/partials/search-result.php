<?php

defined( 'ABSPATH' ) || exit;

/**
 * @var WP_User[] $users
 * @var string    $search
 * @var int       $total
 * @var string    $singular_label
 */

$users          = isset( $users ) && is_array( $users ) ? $users : [];
$singular_label = isset( $singular_label )
	? sanitize_text_field( (string) $singular_label )
	: KERP_Modules_Customers_Settings::instance()->get_singular_label();

$query = KERP_Modules_Customers_Query::instance();

?>

<div class="card card-stretch m-0">
    <div class="card-inner-group">
		<?php if ( ! empty( $users ) ) : ?>
            <div class="card-inner p-0">
                <div class="is-compact nk-tb-list nk-tb-ulist">
					<?php foreach ( $users as $user ) : ?>
						<?php
						if ( ! $user instanceof WP_User ) {
							continue;
						}
						
						$user_id  = $user->ID;
						$name     = trim(
							(string) $user->first_name
							. ' '
							. (string) $user->last_name
						);
						$name     = get_user_name_by_id( $user_id );
						$phone    = $query->get_customer_phone( $user_id );
						$data_url = '/erp/customers/' . $user_id . '/';
						$avatar   = function_exists( 'get_user_name_for_avatar' )
							? get_user_name_for_avatar( $user_id )
							: mb_substr( $name, 0, 1 );
						?>
                        <div
                            class="nk-tb-item"
                            data-id="<?php echo esc_attr( $user_id ); ?>"
                        >
                            <div class="nk-tb-col">
                                <div class="user-card">
                                    <div class="user-avatar xs">
										<span>
											<?php echo esc_html( $avatar ); ?>
										</span>
                                    </div>

                                    <div class="user-info">
										<span class="tb-lead">
											<?php echo esc_html( $name ); ?>
										</span>
                                    </div>
                                </div>
                            </div>

                            <div class="nk-tb-col tb-col-md">
								<span>
									<?php echo esc_html( $phone ); ?>
								</span>
                            </div>

                            <div class="nk-tb-col nk-tb-col-tools">
                                <ul class="nk-tb-actions gx-2">
                                    <li class="nk-tb-action">
                                        <a
                                            href="<?php echo esc_url( home_url( $data_url ) ); ?>"
                                            class="btn btn-sm btn-icon btn-trigger page_activator"
                                            data-url="<?php echo esc_attr( $data_url ); ?>"
                                        >
                                            <em class="icon ni ni-eye"></em>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
					<?php endforeach; ?>
                </div>
            </div>
		<?php else : ?>
            <div class="card-inner text-center py-5">
                <em class="icon ni ni-search display-6 text-soft" aria-hidden="true"></em>
                <h6 class="title mt-3"><?php printf( esc_html__( '%s یافت نشد.', 'kasebi-erp' ), esc_html( $singular_label ) ); ?></h6>
                <p class="text-soft"><?php esc_html_e( 'نام یا شماره تماس دیگری را امتحان کنید.', 'kasebi-erp' ); ?></p>
                <?php if ( KERP_Services_UI_Gate::can( 'customers.create', 'action' ) ) : ?>
                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addCustomer">
                        <em class="icon ni ni-plus" aria-hidden="true"></em>
                        <span><?php printf( esc_html__( 'افزودن %s', 'kasebi-erp' ), esc_html( $singular_label ) ); ?></span>
                    </button>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</div>
