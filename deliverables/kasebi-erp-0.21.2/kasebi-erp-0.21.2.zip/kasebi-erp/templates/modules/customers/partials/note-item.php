<?php

defined( 'ABSPATH' ) || exit;

/**
 * @var array                        $note
 * @var int                          $customer_id
 * @var KERP_Modules_Customers_Notes $notes_service
 * @var bool                         $can_edit
 * @var bool                         $can_delete
 */

$type          = $notes_service->get_type( (string) ( $note['type'] ?? 'general' ) );
$type_label    = (string) ( $type['label'] ?? '' );
$type_icon     = (string) ( $type['icon'] ?? 'ni ni-note-add' );
$badge_class   = (string) ( $type['badge_class'] ?? 'bg-outline-primary' );
$visibility    = $notes_service->get_visibility_label( (string) ( $note['visibility'] ?? '' ) );
$created_by    = get_userdata( absint( $note['created_by'] ?? 0 ) );
$created_name  = $created_by instanceof WP_User ? get_user_name_by_id( $created_by->ID ) : __( 'کاربر حذف‌شده', 'kasebi-erp' );
$created_at    = strtotime( (string) ( $note['created_at'] ?? '' ) );
$created_date  = $created_at ? date_i18n( 'j F Y - H:i', $created_at ) : '';
$populate_data = wp_json_encode(
	$notes_service->get_populate_data( $note ),
	JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
);
?>
<div class="col-12">
    <div class="card card-bordered<?php echo ! empty( $note['is_pinned'] ) ? ' border-warning' : ''; ?>">
        <div class="card-inner">
            <div class="d-flex justify-between align-center flex-wrap">
                <div class="d-flex align-center flex-wrap " style="gap: 10px">
					<span class="badge <?php echo esc_attr( $badge_class ); ?>">
						<em class="icon <?php echo esc_attr( $type_icon ); ?> me-1"></em>
						<?php echo esc_html( $type_label ); ?>
					</span>
					<?php if ( ! empty( $note['is_pinned'] ) ) : ?>
                        <span class="badge bg-warning text-dark d-flex align-center">
							<em class="icon ni ni-pin-fill me-1"></em>
							<?php esc_html_e( 'سنجاق‌شده', 'kasebi-erp' ); ?>
						</span>
					<?php endif; ?>
                    <span class="text-soft fs-12px d-flex align-center">
						<em class="icon ni ni-eye me-1"></em>
						<?php echo esc_html( $visibility ); ?>
					</span>
                </div>
				<?php if ( $can_edit || $can_delete ) : ?>
                    <div class="dropdown">
                        <a href="#" class="btn btn-icon btn-trigger btn-sm" data-bs-toggle="dropdown">
                            <em class="icon ni ni-more-h"></em>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end">
                            <ul class="link-list-opt no-bdr">
								<?php if ( $can_edit ) : ?>
                                    <li>
                                        <a href="#" class="edit_row_item" data-modal="#customerNoteModal"
                                           data-populate="<?php echo esc_attr( (string) $populate_data ); ?>">
                                            <em class="icon ni ni-edit"></em>
                                            <span><?php esc_html_e( 'ویرایش', 'kasebi-erp' ); ?></span>
                                        </a>
                                    </li>
								<?php endif; ?>
								<?php if ( $can_delete ) : ?>
                                    <li>
                                        <a href="#" class="delete_db_item" data-action="customers_notes_delete"
                                           data-note_id="<?php echo esc_attr( (string) $note['id'] ); ?>"
                                           data-item_id="<?php echo esc_attr( (string) $note['id'] ); ?>"
                                           data-customer_id="<?php echo esc_attr( $customer_id ); ?>">
                                            <em class="icon ni ni-trash"></em>
                                            <span><?php esc_html_e( 'حذف', 'kasebi-erp' ); ?></span>
                                        </a>
                                    </li>
								<?php endif; ?>
                            </ul>
                        </div>
                    </div>
				<?php endif; ?>
            </div>
            <div class="mt-3 fs-15px lh-lg border-0 border-bottom pb-2">
				<?php echo nl2br( esc_html( (string) ( $note['content'] ?? '' ) ) ); ?>
            </div>
            <div class="d-flex align-center flex-wrap mt-1 text-soft fs-12px" style="gap: 10px">
                <span class="d-flex align-center">
					<em class="icon ni ni-user me-1"></em>
					<?php echo esc_html( $created_name ); ?>
				</span>
				<?php if ( $created_date !== '' ) : ?>
                    <span class="d-flex align-center">
						<em class="icon ni ni-clock me-1"></em>
						<?php echo esc_html( $created_date ); ?>
					</span>
				<?php endif; ?>
            </div>
        </div>
    </div>
</div>
