<?php

defined( 'ABSPATH' ) || exit;

/**
 * @var KERP_Modules_Ajax_Module $module
 * @var array                    $active_plugins
 * @var array                    $selected_plugins
 * @var string                   $mu_loader_path
 * @var bool                     $has_mu_loader
 * @var string                   $notice
 */

$selected_plugins = is_array( $selected_plugins ) ? $selected_plugins : [];
?>

<div class="wrap kasebi-admin-page kasebi-modules-page">
    <form id="kasebi-ajax-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
        <input type="hidden" name="action" value="<?php echo esc_attr( KERP_Modules_Ajax_Module::SAVE_ACTION ); ?>">
		<?php wp_nonce_field( KERP_Modules_Ajax_Module::NONCE_ACTION, KERP_Modules_Ajax_Module::NONCE_NAME ); ?>
		
		<?php
		KERP_Helpers_Template::render_template(
			'admin/components/page-hero.php',
			[
				'title'       => __( 'مدیریت Ajax اختصاصی ERP', 'kasebi-erp' ),
				'description' => __( 'افزونه‌های مجاز برای endpoint اختصاصی ERP را مشخص کنید.', 'kasebi-erp' ),
				'button_text' => __( 'ذخیره تنظیمات Ajax', 'kasebi-erp' ),
				'button_type' => 'submit',
				'icon'        => 'kik-r fa-route',
			]
		);
		?>
		
		<?php if ( in_array( $notice, [ 'ajax_saved', 'mu_loader_installed' ], TRUE ) ) : ?>
            <div class="notice notice-success is-dismissible kasebi-admin-notice">
                <p><?php esc_html_e( 'تنظیمات Ajax و فایل MU Loader با موفقیت ذخیره شدند.', 'kasebi-erp' ); ?></p>
            </div>
		<?php elseif ( in_array( $notice, [ 'ajax_save_failed', 'mu_loader_failed' ], TRUE ) ) : ?>
            <div class="notice notice-error is-dismissible kasebi-admin-notice">
                <p><?php esc_html_e( 'فایل MU Loader ساخته نشد؛ دسترسی نوشتن پوشه mu-plugins را بررسی کنید.', 'kasebi-erp' ); ?></p>
            </div>
		<?php endif; ?>

        <div class="kasebi-page-hero">
            <div class="kasebi-page-hero-content">
                <div>
                    <h2><?php esc_html_e( 'وضعیت MU Loader', 'kasebi-erp' ); ?></h2>
                </div>
				
				<?php if ( $has_mu_loader ) : ?>
                    <span class="kasebi-status-badge is-active"><?php esc_html_e( 'نصب شده', 'kasebi-erp' ); ?></span>
				<?php else : ?>
                    <a
                        class="button button-primary"
                        href="<?php
						echo esc_url(
							wp_nonce_url(
								add_query_arg(
									[ 'action' => KERP_Modules_Ajax_Module::INSTALL_MU_ACTION ],
									admin_url( 'admin-post.php' )
								),
								KERP_Modules_Ajax_Module::INSTALL_MU_NONCE,
								KERP_Modules_Ajax_Module::INSTALL_MU_NONCE
							)
						);
						?>"
                    >
						<?php esc_html_e( 'نصب MU Loader', 'kasebi-erp' ); ?>
                    </a>
				<?php endif; ?>
            </div>
        </div>
        <div class="kasebi-card">
            <div class="kasebi-ajax-card__header">
                <div>
                    <h2><?php esc_html_e( 'افزونه‌های مجاز در Ajax', 'kasebi-erp' ); ?></h2>
                    <p><?php esc_html_e( 'خود Kasebi ERP و افزونه‌های شبکه‌ای همیشه بارگذاری می‌شوند.', 'kasebi-erp' ); ?></p>
                </div>
            </div>

            <div class="kasebi-table-scroll">
                <table class="widefat striped kasebi-ajax-plugins-table">
                    <thead>
                    <tr>
                        <th><?php esc_html_e( 'افزونه', 'kasebi-erp' ); ?></th>
                        <th><?php esc_html_e( 'شناسه', 'kasebi-erp' ); ?></th>
                        <th><?php esc_html_e( 'لود در Ajax', 'kasebi-erp' ); ?></th>
                    </tr>
                    </thead>
                    <tbody>
					<?php foreach ( $active_plugins as $plugin_basename => $plugin ) : ?>
						<?php
						$is_forced   = ! empty( $plugin['forced'] );
						$is_selected = $is_forced || in_array( $plugin_basename, $selected_plugins, TRUE );
						$input_id    = 'kasebi-ajax-plugin-' . md5( $plugin_basename );
						?>
                        <tr>
                            <td>
                                <strong><?php echo esc_html( $plugin['name'] ); ?></strong>
                            </td>
                            <td><code><?php echo esc_html( $plugin_basename ); ?></code></td>
                            <td>
								<?php if ( $is_forced ) : ?>
                                    <input type="hidden" name="ajax_active_plugins[]"
                                           value="<?php echo esc_attr( $plugin_basename ); ?>">
								<?php endif; ?>

                                <label class="kasebi-switch" for="<?php echo esc_attr( $input_id ); ?>">
                                    <input
                                        type="checkbox"
                                        id="<?php echo esc_attr( $input_id ); ?>"
                                        name="ajax_active_plugins[]"
                                        value="<?php echo esc_attr( $plugin_basename ); ?>"
										<?php checked( $is_selected ); ?>
										<?php disabled( $is_forced ); ?>
                                    >
                                    <span class="kasebi-switch-box"></span>
                                </label>
                            </td>
                        </tr>
					<?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </form>
</div>
