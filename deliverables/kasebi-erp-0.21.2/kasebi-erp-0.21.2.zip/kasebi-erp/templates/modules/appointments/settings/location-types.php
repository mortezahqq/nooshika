<?php

defined( 'ABSPATH' ) || exit;

$settings       = KERP_Modules_Appointments_Settings::instance();
$location_types = $settings->get_location_types( FALSE );
$modal_id       = 'appointmentLocationTypeModal';
$modal_selector = '#' . $modal_id;
$active_tab     = 'location_types';
$type_counts    = [];
$total_usage    = 0;
$active_count   = 0;

foreach ( $location_types as $key => $location_type ) {
	$key = sanitize_key( (string) $key );
	
	$type_counts[ $key ] = KERP_Modules_Appointments_Query::instance()->count_by_location_type( $key );
	$total_usage         += $type_counts[ $key ];
	
	if ( ! empty( $location_type['active'] ) ) {
		$active_count ++;
	}
}

$add_populate = [
	'original' => [
		'id'    => '#kerp-appointment-location-type-original-key',
		'type'  => 'text',
		'value' => '',
	],
	'key'      => [
		'id'    => '#kerp-appointment-location-type-key',
		'type'  => 'text',
		'value' => '',
	],
	'label'    => [
		'id'    => '#kerp-appointment-location-type-label',
		'type'  => 'text',
		'value' => '',
	],
	'icon'     => [
		'id'    => '#kerp-appointment-location-type-icon',
		'type'  => 'text',
		'value' => 'uik-r fa-map-marker',
	],
	'color'    => [
		'id'    => '#kerp-appointment-location-type-color',
		'type'  => 'select',
		'value' => 'primary',
	],
	'order'    => [
		'id'    => '#kerp-appointment-location-type-order',
		'type'  => 'text',
		'value' => 10,
	],
	'active'   => [
		'id'    => '#kerp-appointment-location-type-active',
		'type'  => 'checkbox',
		'value' => '1',
	],
];
?>

<div class="kerp-location-types-page">
	<div class="nk-block-head nk-block-head-sm">
		<div class="nk-block-between g-3">
			<div class="nk-block-head-content">
				<h3 class="nk-block-title page-title"><?php echo esc_html( sprintf( __( 'انواع برگزاری %s', 'kasebi-erp' ), $settings->get_appointment_singular_label() ) ); ?></h3>
				<div class="nk-block-des text-soft"><p><?php echo esc_html( sprintf( __( 'روش‌های برگزاری %s مانند حضوری، تلفنی و آنلاین را تعریف و مدیریت کنید.', 'kasebi-erp' ), $settings->get_appointment_singular_label() ) ); ?></p></div>
			</div>
			<div class="nk-block-head-content">
				<a href="#" class="btn btn-primary open_populate_modal" data-modal="<?php echo esc_attr( $modal_selector ); ?>" data-modal-title="<?php esc_attr_e( 'افزودن نوع برگزاری', 'kasebi-erp' ); ?>" data-submit-text="<?php esc_attr_e( 'افزودن نوع برگزاری', 'kasebi-erp' ); ?>" data-populate="<?php echo esc_attr( wp_json_encode( $add_populate ) ); ?>"><em class="ni ni-plus icon"></em><span><?php esc_html_e( 'افزودن نوع برگزاری', 'kasebi-erp' ); ?></span></a>
			</div>
		</div>
	</div>
	<div class="nk-block">
		<?php
		KERP_Helpers_Template::render_template(
			'app/components/settings/hero.php',
			[
				'icon'        => 'uik-r fa-map-marker',
				'eyebrow'     => __( 'روش برگزاری', 'kasebi-erp' ),
				'title'       => sprintf( __( 'انواع برگزاری %s', 'kasebi-erp' ), $settings->get_appointment_singular_label() ),
				'description' => sprintf( __( 'روش‌های قابل انتخاب هنگام ثبت %s را از این بخش مدیریت کنید.', 'kasebi-erp' ), $settings->get_appointment_singular_label() ),
				'stats'       => [
					[ 'label' => __( 'کل انواع', 'kasebi-erp' ), 'value' => number_format_i18n( count( $location_types ) ) ],
					[ 'label' => __( 'فعال', 'kasebi-erp' ), 'value' => number_format_i18n( $active_count ) ],
					[ 'label' => sprintf( __( '%s ثبت‌شده', 'kasebi-erp' ), $settings->get_appointment_singular_label() ), 'value' => number_format_i18n( $total_usage ) ],
				],
			]
		);
		?>
	</div>
	<div class="nk-block">
		<?php if ( empty( $location_types ) ) : ?>
			<?php
			KERP_Helpers_Template::render_template(
				'app/components/settings/empty-state.php',
				[
					'icon'        => 'uik-r fa-map-marker',
					'title'       => __( 'هنوز نوع برگزاری تعریف نشده است', 'kasebi-erp' ),
					'description' => sprintf( __( 'اولین روش برگزاری %1$s را اضافه کنید تا هنگام ثبت %1$s قابل انتخاب باشد.', 'kasebi-erp' ), $settings->get_appointment_singular_label() ),
					'action'      => [
						'tag'        => 'a',
						'label'      => __( 'افزودن اولین نوع', 'kasebi-erp' ),
						'icon'       => 'ni ni-plus icon',
						'class'      => 'btn btn-primary open_populate_modal',
						'attributes' => [ 'href' => '#', 'data-modal' => $modal_selector, 'data-modal-title' => __( 'افزودن نوع برگزاری', 'kasebi-erp' ), 'data-submit-text' => __( 'افزودن نوع برگزاری', 'kasebi-erp' ), 'data-populate' => wp_json_encode( $add_populate ) ],
					],
				]
			);
			?>
		<?php else : ?>
			<div class="row g-gs kerp-settings-item-grid">
				<?php foreach ( $location_types as $key => $location_type ) : ?>
					<?php
					$key    = sanitize_key( (string) $key );
					$label  = (string) ( $location_type['label'] ?? $key );
					$icon   = trim( (string) ( $location_type['icon'] ?? 'uik-r fa-map-marker' ) );
					$color  = sanitize_key( (string) ( $location_type['color'] ?? 'primary' ) ) ?: 'primary';
					$count  = $type_counts[ $key ] ?? 0;
					$active = ! empty( $location_type['active'] );
					$order  = intval( $location_type['order'] ?? 10 );
					$populate = [
						'original' => [ 'id' => '#kerp-appointment-location-type-original-key', 'type' => 'text', 'value' => $key ],
						'key'      => [ 'id' => '#kerp-appointment-location-type-key', 'type' => 'text', 'value' => $key ],
						'label'    => [ 'id' => '#kerp-appointment-location-type-label', 'type' => 'text', 'value' => $label ],
						'icon'     => [ 'id' => '#kerp-appointment-location-type-icon', 'type' => 'text', 'value' => $icon ],
						'color'    => [ 'id' => '#kerp-appointment-location-type-color', 'type' => 'select', 'value' => $color ],
						'order'    => [ 'id' => '#kerp-appointment-location-type-order', 'type' => 'text', 'value' => $order ],
						'active'   => [ 'id' => '#kerp-appointment-location-type-active', 'type' => 'checkbox', 'value' => $active ? '1' : '0' ],
					];
					$actions = [
						[
							'label' => __( 'ویرایش', 'kasebi-erp' ), 'icon' => 'ni ni-edit icon', 'class' => 'edit_row_item',
							'attributes' => [ 'data-modal' => $modal_selector, 'data-modal-title' => __( 'ویرایش نوع برگزاری', 'kasebi-erp' ), 'data-submit-text' => __( 'ذخیره تغییرات', 'kasebi-erp' ), 'data-populate' => wp_json_encode( $populate ) ],
						],
					];
					if ( $count <= 0 ) {
						$actions[] = [
							'label' => __( 'حذف', 'kasebi-erp' ), 'icon' => 'ni ni-trash icon', 'class' => 'delete_db_item', 'divider_before' => TRUE,
							'attributes' => [ 'data-action' => 'appointments_delete_location_type', 'data-page' => '/erp/appointments/settings/location-types/', 'data-active_tab' => $active_tab, 'data-location_type_key' => $key, 'data-item_id' => $key ],
						];
					}
					KERP_Helpers_Template::render_template(
						'app/components/settings/item-card.php',
						[
							'column_class' => 'col-md-6 col-xl-4',
							'icon'         => $icon,
							'icon_class'   => 'bg-' . $color . '-dim text-' . $color,
							'label'        => $label,
							'key'          => $key,
							'active'       => $active,
							'actions'      => $actions,
							'meta'         => [
								[ 'icon' => 'icon ni ni-calendar', 'label' => $settings->get_appointment_plural_label(), 'value' => number_format_i18n( $count ) ],
								[ 'icon' => 'icon ni ni-sort', 'label' => __( 'ترتیب', 'kasebi-erp' ), 'value' => number_format_i18n( $order ) ],
							],
							'footer'       => [
								[ 'icon' => $count > 0 ? 'icon ni ni-lock-alt' : 'icon ni ni-check', 'text' => $count > 0 ? __( 'در حال استفاده', 'kasebi-erp' ) : __( 'بدون استفاده', 'kasebi-erp' ) ],
							],
						]
					);
					?>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>
	</div>
</div>
