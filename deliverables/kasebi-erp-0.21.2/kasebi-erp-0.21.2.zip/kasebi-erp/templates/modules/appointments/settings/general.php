<?php

defined( 'ABSPATH' ) || exit;

$settings            = KERP_Modules_Appointments_Settings::instance();
$values              = $settings->all();
$active_tab          = 'general';
$status_options      = $settings->get_status_options();
$default_status_key  = sanitize_key( (string) ( $values['default_admin_status'] ?? 'confirmed' ) );
$default_status_name = (string) ( $status_options[ $default_status_key ] ?? $default_status_key );

$fields = [
	'booking_start_date' => [
		'id' => 'kerp-appointments-booking-start-date',
		'name' => 'settings[booking_start_date]',
		'label' => __( 'شروع بازه فعال بودن نوبت‌دهی', 'kasebi-erp' ),
		'type' => 'date',
		'class' => 'col-12',
		'value' => KERP_Helpers_Date::gregorian_to_jalali( (string) $values['booking_start_date'] ),
		'description' => __( 'تاریخ شمسی؛ خالی یعنی بدون محدودیت شروع.', 'kasebi-erp' ),
	],
	'booking_end_date' => [
		'id' => 'kerp-appointments-booking-end-date',
		'name' => 'settings[booking_end_date]',
		'label' => __( 'پایان بازه فعال بودن نوبت‌دهی', 'kasebi-erp' ),
		'type' => 'date',
		'class' => 'col-12',
		'value' => KERP_Helpers_Date::gregorian_to_jalali( (string) $values['booking_end_date'] ),
		'description' => __( 'روز پایان هم قابل رزرو است. برنامه‌های هفتگی و زمان‌های استثنا فقط در این بازه فعال‌اند؛ خالی یعنی بدون محدودیت پایان.', 'kasebi-erp' ),
	],
	'active_tab'                  => [
		'id'    => 'kerp-appointments-active-tab-general',
		'name'  => 'active_tab',
		'type'  => 'hidden',
		'class' => 'no_clear',
		'value' => $active_tab,
	],
	'default_duration'            => [
		'id'       => 'kerp-appointments-default-duration',
		'name'     => 'settings[default_duration]',
		'label'    => sprintf( __( 'مدت پیش‌فرض %s (دقیقه)', 'kasebi-erp' ), $settings->get_service_singular_label() ),
		'type'     => 'number',
		'class'    => 'col-12',
		'value'    => absint( $values['default_duration'] ?? 30 ),
		'required' => TRUE,
	],
	'default_slot_interval'       => [
		'id'       => 'kerp-appointments-default-slot-interval',
		'name'     => 'settings[default_slot_interval]',
		'label'    => __( 'فاصله پیش‌فرض اسلات‌ها (دقیقه)', 'kasebi-erp' ),
		'type'     => 'number',
		'class'    => 'col-12',
		'value'    => absint( $values['default_slot_interval'] ?? 30 ),
		'required' => TRUE,
	],
	'hold_minutes'                => [
		'id'       => 'kerp-appointments-hold-minutes',
		'name'     => 'settings[hold_minutes]',
		'label'    => __( 'زمان نگهداری رزرو موقت (دقیقه)', 'kasebi-erp' ),
		'type'     => 'number',
		'class'    => 'col-12',
		'value'    => absint( $values['hold_minutes'] ?? 15 ),
		'required' => TRUE,
	],
	'default_capacity'            => [
		'id'       => 'kerp-appointments-default-capacity',
		'name'     => 'settings[default_capacity]',
		'label'    => __( 'ظرفیت پیش‌فرض', 'kasebi-erp' ),
		'type'     => 'number',
		'class'    => 'col-12',
		'value'    => absint( $values['default_capacity'] ?? 1 ),
		'required' => TRUE,
	],
	'default_per_page'            => [
		'id'       => 'kerp-appointments-default-per-page',
		'name'     => 'settings[default_per_page]',
		'label'    => __( 'تعداد در هر صفحه', 'kasebi-erp' ),
		'type'     => 'number',
		'class'    => 'col-12',
		'value'    => absint( $values['default_per_page'] ?? 20 ),
		'required' => TRUE,
	],
	'default_admin_status'        => [
		'id'          => 'kerp-appointments-default-admin-status',
		'name'        => 'settings[default_admin_status]',
		'label'       => __( 'وضعیت پیش‌فرض ثبت از پنل', 'kasebi-erp' ),
		'type'        => 'select',
		'class'       => 'col-12',
		'input_class' => 'js-select2',
		'options'     => $status_options,
		'placeholder' => __( 'انتخاب وضعیت', 'kasebi-erp' ),
		'value'       => $default_status_key,
		'required'    => TRUE,
	],
	'booking_cancellation_terms'  => [
		'id'    => 'kerp-appointments-booking-cancellation-terms',
		'name'  => 'settings[booking_cancellation_terms]',
		'label' => __( 'متن شرایط رزرو و لغو نوبت', 'kasebi-erp' ),
		'type'  => 'quill',
		'class' => 'col-12',
		'value' => (string) ( $values['booking_cancellation_terms'] ?? '' ),
	],
	'booking_terms_checkbox_text' => [
		'id'          => 'kerp-appointments-booking-terms-checkbox-text',
		'name'        => 'settings[booking_terms_checkbox_text]',
		'label'       => __( 'متن چک‌باکس پذیرش شرایط', 'kasebi-erp' ),
		'type'        => 'text',
		'class'       => 'col-12',
		'value'       => $settings->get_booking_terms_checkbox_text(),
		'placeholder' => __( 'شرایط رزرو و لغو نوبت را خوانده‌ام و می‌پذیرم.', 'kasebi-erp' ),
	],
];
?>
<form class="modal_form kerp-appointments-settings" data-action="appointments_save_settings"
      data-page="/erp/appointments/settings/">
	<?php KERP_Helpers_Template::render_template( 'app/components/fields/hidden.php', [ 'field' => $fields['active_tab'] ] ); ?>
    <div class="nk-block-head nk-block-head-sm">
        <div class="nk-block-between">
            <div class="nk-block-head-content">
                <h3 class="nk-block-title page-title"><?php echo esc_html( sprintf( __( 'تنظیمات عمومی %s', 'kasebi-erp' ), $settings->get_appointment_plural_label() ) ); ?></h3>
                <div class="nk-block-des text-soft">
                    <p><?php echo esc_html( sprintf( __( 'مقادیر پیش‌فرض ثبت %s، ظرفیت، اسلات‌ها و رزرو موقت را مدیریت کنید.', 'kasebi-erp' ), $settings->get_appointment_singular_label() ) ); ?></p>
                </div>
            </div>
            <div class="nk-block-head-content">
                <button type="button" class="btn btn-primary submit_modal_form">
                    <em class="icon ni ni-save"></em>
                    <span><?php esc_html_e( 'ذخیره تنظیمات', 'kasebi-erp' ); ?></span>
                </button>
            </div>
        </div>
    </div>
    <div class="nk-block">
		<?php
		KERP_Helpers_Template::render_template(
			'app/components/settings/hero.php',
			[
				'icon'        => 'icon ni ni-calendar',
				'eyebrow'     => sprintf( __( 'هسته %s', 'kasebi-erp' ), $settings->get_appointment_plural_label() ),
				'title'       => __( 'رفتار پیش‌فرض رزروها', 'kasebi-erp' ),
				'description' => sprintf( __( 'این مقادیر هنگام ساخت %1$s، ایجاد اسلات و ثبت %2$s از پنل به‌عنوان مقدار اولیه استفاده می‌شوند.', 'kasebi-erp' ), $settings->get_service_singular_label(), $settings->get_appointment_singular_label() ),
				'stats'       => [
					[
						'label' => sprintf( __( 'مدت %s', 'kasebi-erp' ), $settings->get_service_singular_label() ),
						'value' => sprintf( __( '%s دقیقه', 'kasebi-erp' ), number_format_i18n( absint( $values['default_duration'] ?? 30 ) ) ),
					],
					[
						'label' => __( 'فاصله اسلات', 'kasebi-erp' ),
						'value' => sprintf( __( '%s دقیقه', 'kasebi-erp' ), number_format_i18n( absint( $values['default_slot_interval'] ?? 30 ) ) ),
					],
					[
						'label' => __( 'ظرفیت', 'kasebi-erp' ),
						'value' => number_format_i18n( absint( $values['default_capacity'] ?? 1 ) ),
					],
					[
						'label' => __( 'وضعیت ثبت پنل', 'kasebi-erp' ),
						'value' => $default_status_name,
					],
				],
			]
		);
		?>
    </div>
    <div class="nk-block">
        <div class="row g-gs">
            <div class="col-xl-6">
                <div class="card card-bordered h-100 kerp-appointments-settings-card">
                    <div class="card-inner border-bottom">
                        <div class="kerp-appointments-settings-card__head">
                            <span class="kerp-appointments-settings-section-icon"><em
                                    class="icon ni ni-clock"></em></span>
                            <div>
                                <h6 class="title mb-1"><?php esc_html_e( 'زمان‌بندی و نگهداری', 'kasebi-erp' ); ?></h6>
                                <p class="text-soft mb-0"><?php esc_html_e( 'قواعد زمانی پیش‌فرض برای ساخت اسلات و رزرو موقت.', 'kasebi-erp' ); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="card-inner">
                        <div class="row g-4">
							<?php foreach (
								[
									'default_duration',
									'booking_start_date',
									'booking_end_date',
									'default_slot_interval',
									'hold_minutes',
								] as $field_key
							) : ?>
								<?php
								$field = $fields[ $field_key ];
								$type  = sanitize_key( (string) $field['type'] );
								KERP_Helpers_Template::render_template( 'app/components/fields/' . $type . '.php', [ 'field' => $field ] );
								?>
							<?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-6">
                <div class="card card-bordered h-100 kerp-appointments-settings-card">
                    <div class="card-inner border-bottom">
                        <div class="kerp-appointments-settings-card__head">
                            <span class="kerp-appointments-settings-section-icon"><em
                                    class="icon ni ni-setting"></em></span>
                            <div>
                                <h6 class="title mb-1"><?php esc_html_e( 'ثبت و نمایش', 'kasebi-erp' ); ?></h6>
                                <p class="text-soft mb-0"><?php esc_html_e( 'ظرفیت اولیه، تعداد آیتم‌های فهرست و وضعیت ثبت از پنل.', 'kasebi-erp' ); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="card-inner">
                        <div class="row g-4">
							<?php foreach (
								[
									'default_capacity',
									'default_per_page',
									'default_admin_status',
								] as $field_key
							) : ?>
								<?php
								$field = $fields[ $field_key ];
								$type  = sanitize_key( (string) $field['type'] );
								KERP_Helpers_Template::render_template( 'app/components/fields/' . $type . '.php', [ 'field' => $field ] );
								?>
							<?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="nk-block">
        <div class="card card-bordered kerp-appointments-settings-card">
            <div class="card-inner border-bottom">
                <div class="kerp-appointments-settings-card__head">
                    <span class="kerp-appointments-settings-section-icon"><em
                            class="icon ni ni-shield-check"></em></span>
                    <div>
                        <h6 class="title mb-1"><?php esc_html_e( 'شرایط رزرو و لغو نوبت', 'kasebi-erp' ); ?></h6>
                        <p class="text-soft mb-0"><?php esc_html_e( 'قوانین رزرو، تغییر زمان و لغو نوبت را برای نمایش به کاربران وارد کنید.', 'kasebi-erp' ); ?></p>
                    </div>
                </div>
            </div>
            <div class="card-inner">
                <div class="row g-4">
					<?php
					$field = $fields['booking_terms_checkbox_text'];
					$type  = sanitize_key( (string) $field['type'] );
					
					KERP_Helpers_Template::render_template(
						'app/components/fields/' . $type . '.php',
						[
							'field' => $field,
						]
					);
					?>
					
					<?php
					$field = $fields['booking_cancellation_terms'];
					
					KERP_Helpers_Template::render_template(
						'app/components/fields/quill.php',
						[
							'field' => $field,
						]
					);
					?>
                </div>
            </div>
        </div>
    </div>
</form>
