<?php

defined( 'ABSPATH' ) || exit;

$fields_service = KERP_Modules_Appointments_Public_Fields::instance();
$definitions    = $fields_service->get_all();

$type_options = [
	'text'         => __( 'متن', 'kasebi-erp' ),
	'email'        => __( 'ایمیل', 'kasebi-erp' ),
	'number'       => __( 'عدد', 'kasebi-erp' ),
	'date'         => __( 'تاریخ', 'kasebi-erp' ),
	'textarea'     => __( 'متن چندخطی', 'kasebi-erp' ),
	'select'       => __( 'لیست انتخابی', 'kasebi-erp' ),
	'radio'        => __( 'انتخاب تکی', 'kasebi-erp' ),
	'checkbox'     => __( 'چک‌باکس', 'kasebi-erp' ),
	'multi-select' => __( 'انتخاب چندتایی', 'kasebi-erp' ),
	'switch'       => __( 'روشن / خاموش', 'kasebi-erp' ),
];

$modal_id = 'appointmentPublicFieldModal';

$add_populate = [
	'key'         => [
		'id'    => '#kerp-appointment-public-field-key',
		'type'  => 'text',
		'value' => '',
	],
	'label'       => [
		'id'    => '#kerp-appointment-public-field-label',
		'type'  => 'text',
		'value' => '',
	],
	'type'        => [
		'id'    => '#kerp-appointment-public-field-type',
		'type'  => 'select',
		'value' => 'text',
	],
	'description' => [
		'id'    => '#kerp-appointment-public-field-description',
		'type'  => 'text',
		'value' => '',
	],
	'placeholder' => [
		'id'    => '#kerp-appointment-public-field-placeholder',
		'type'  => 'text',
		'value' => '',
	],
	'options'     => [
		'id'    => '#kerp-appointment-public-field-options',
		'type'  => 'text',
		'value' => '',
	],
	'required'    => [
		'id'    => '#kerp-appointment-public-field-required',
		'type'  => 'switch',
		'value' => '0',
	],
	'active'      => [
		'id'    => '#kerp-appointment-public-field-active',
		'type'  => 'switch',
		'value' => '1',
	],
	'order'       => [
		'id'    => '#kerp-appointment-public-field-order',
		'type'  => 'text',
		'value' => 100,
	],
];
?>

    <div class="nk-block-head nk-block-head-sm">
        <div class="nk-block-between g-3">
            <div class="nk-block-head-content">
                <h3 class="nk-block-title page-title"><?php esc_html_e( 'فیلدهای فرم رزرو عمومی', 'kasebi-erp' ); ?></h3>
                <div class="nk-block-des text-soft">
                    <p><?php esc_html_e( 'اطلاعات تکمیلی که در مرحله ورود مشخصات رزرو از کاربر دریافت می‌شود.', 'kasebi-erp' ); ?></p>
                </div>
            </div>
            <div class="nk-block-head-content">
                <button type="button"
                        class="btn btn-primary open_populate_modal"
                        data-modal="#<?php echo esc_attr( $modal_id ); ?>"
                        data-modal-title="<?php esc_attr_e( 'افزودن فیلد', 'kasebi-erp' ); ?>"
                        data-submit-text="<?php esc_attr_e( 'افزودن فیلد', 'kasebi-erp' ); ?>"
                        data-populate="<?php echo esc_attr( wp_json_encode( $add_populate ) ); ?>">
                    <em class="icon ni ni-plus"></em>
                    <span><?php esc_html_e( 'افزودن فیلد', 'kasebi-erp' ); ?></span>
                </button>
            </div>
        </div>
    </div>

    <div class="nk-block">
		<?php if ( empty( $definitions ) ) : ?>
            <div class="card card-bordered">
                <div class="card-inner text-center py-5">
                    <em class="icon ni ni-property-add fs-1 text-soft"></em>
                    <h5 class="mt-3 mb-1"><?php esc_html_e( 'فیلد تکمیلی تعریف نشده است.', 'kasebi-erp' ); ?></h5>
                    <p class="text-soft mb-0"><?php esc_html_e( 'نام، نام خانوادگی و شماره‌های تماس به‌صورت ثابت در فرم وجود دارند.', 'kasebi-erp' ); ?></p>
                </div>
            </div>
		<?php else : ?>
            <div class="row g-gs">
				<?php foreach ( $definitions as $field_key => $field ) : ?>
					<?php
					$options      = (array) ( $field['options'] ?? [] );
					$options_text = [];
					
					foreach ( $options as $option_key => $option_label ) {
						$options_text[] = $option_key . '=' . $option_label;
					}
					
					$edit_populate = [
						'key'         => [
							'id'    => '#kerp-appointment-public-field-key',
							'type'  => 'no_change',
							'value' => $field_key,
						],
						'label'       => [
							'id'    => '#kerp-appointment-public-field-label',
							'type'  => 'text',
							'value' => (string) ( $field['label'] ?? '' ),
						],
						'type'        => [
							'id'    => '#kerp-appointment-public-field-type',
							'type'  => 'select',
							'value' => (string) ( $field['type'] ?? 'text' ),
						],
						'description' => [
							'id'    => '#kerp-appointment-public-field-description',
							'type'  => 'text',
							'value' => (string) ( $field['description'] ?? '' ),
						],
						'placeholder' => [
							'id'    => '#kerp-appointment-public-field-placeholder',
							'type'  => 'text',
							'value' => (string) ( $field['placeholder'] ?? '' ),
						],
						'options'     => [
							'id'    => '#kerp-appointment-public-field-options',
							'type'  => 'text',
							'value' => implode( "\n", $options_text ),
						],
						'required'    => [
							'id'    => '#kerp-appointment-public-field-required',
							'type'  => 'switch',
							'value' => ! empty( $field['required'] ) ? '1' : '0',
						],
						'active'      => [
							'id'    => '#kerp-appointment-public-field-active',
							'type'  => 'switch',
							'value' => ! empty( $field['active'] ) ? '1' : '0',
						],
						'order'       => [
							'id'    => '#kerp-appointment-public-field-order',
							'type'  => 'text',
							'value' => (int) ( $field['order'] ?? 100 ),
						],
					];
					?>

                    <div class="col-md-6 col-xl-4">
                        <div class="card card-bordered h-100">
                            <div class="card-inner">
                                <div class="d-flex align-items-start justify-content-between g-2">
                                    <div>
                                        <h6 class="title mb-1"><?php echo esc_html( (string) ( $field['label'] ?? $field_key ) ); ?></h6>
                                        <code><?php echo esc_html( $field_key ); ?></code>
                                    </div>

                                    <div class="dropdown">
                                        <a href="#"
                                           class="btn btn-sm btn-icon btn-trigger dropdown-toggle"
                                           data-bs-toggle="dropdown">
                                            <em class="icon ni ni-more-h"></em>
                                        </a>
                                        <div class="dropdown-menu dropdown-menu-end">
                                            <ul class="link-list-opt no-bdr">
                                                <li>
                                                    <a href="#"
                                                       class="edit_row_item"
                                                       data-modal="#<?php echo esc_attr( $modal_id ); ?>"
                                                       data-populate="<?php echo esc_attr( wp_json_encode( $edit_populate ) ); ?>">
                                                        <em class="icon ni ni-edit"></em>
                                                        <span><?php esc_html_e( 'ویرایش', 'kasebi-erp' ); ?></span>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#"
                                                       class="delete_db_item"
                                                       data-action="appointments_delete_public_field"
                                                       data-page="/erp/appointments/settings/public-fields/"
                                                       data-key="<?php echo esc_attr( $field_key ); ?>"
                                                       data-item_id="<?php echo esc_attr( $field_key ); ?>">
                                                        <em class="icon ni ni-trash"></em>
                                                        <span><?php esc_html_e( 'حذف', 'kasebi-erp' ); ?></span>
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>

                                <div class="d-flex align-items-center flex-wrap g-2 mt-3">
								<span class="badge badge-dim bg-outline-primary">
									<?php echo esc_html( $type_options[ $field['type'] ] ?? $field['type'] ); ?>
								</span>
									
									<?php if ( ! empty( $field['required'] ) ) : ?>
                                        <span
                                            class="badge badge-dim bg-outline-warning"><?php esc_html_e( 'اجباری', 'kasebi-erp' ); ?></span>
									<?php endif; ?>

                                    <span
                                        class="badge badge-dim <?php echo ! empty( $field['active'] ) ? 'bg-success' : 'bg-light'; ?>">
									<?php echo ! empty( $field['active'] ) ? esc_html__( 'فعال', 'kasebi-erp' ) : esc_html__( 'غیرفعال', 'kasebi-erp' ); ?>
								</span>
                                </div>
								
								<?php if ( ! empty( $field['description'] ) ) : ?>
                                    <p class="text-soft mt-3 mb-0"><?php echo esc_html( (string) $field['description'] ); ?></p>
								<?php endif; ?>

                                <div class="border-top mt-3 pt-3 text-soft small">
									<?php
									printf(
										esc_html__( 'ترتیب: %s', 'kasebi-erp' ),
										esc_html( number_format_i18n( (int) ( $field['order'] ?? 100 ) ) )
									);
									?>
                                </div>
                            </div>
                        </div>
                    </div>
				<?php endforeach; ?>
            </div>
		<?php endif; ?>
    </div>

<?php
KERP_Helpers_Template::render_modal(
	[
		'id'     => $modal_id,
		'title'  => __( 'فیلد فرم رزرو', 'kasebi-erp' ),
		'action' => 'appointments_save_public_field',
		'page'   => '/erp/appointments/settings/public-fields/',
		'button' => __( 'ذخیره', 'kasebi-erp' ),
		'size'   => 'lg',
		'fields' => [
			[
				'id'          => 'kerp-appointment-public-field-key',
				'name'        => 'field[key]',
				'label'       => __( 'کلید فیلد', 'kasebi-erp' ),
				'description' => __( 'کلید انگلیسی یکتا؛ همین مقدار به‌عنوان user meta ذخیره می‌شود.', 'kasebi-erp' ),
				'type'        => 'text',
				'class'       => 'col-md-6',
			],
			[
				'id'    => 'kerp-appointment-public-field-label',
				'name'  => 'field[label]',
				'label' => __( 'عنوان فیلد', 'kasebi-erp' ),
				'type'  => 'text',
				'class' => 'col-md-6',
			],
			[
				'id'      => 'kerp-appointment-public-field-type',
				'name'    => 'field[type]',
				'label'   => __( 'نوع فیلد', 'kasebi-erp' ),
				'type'    => 'select',
				'class'   => 'col-md-6',
				'options' => $type_options,
				'value'   => 'text',
			],
			[
				'id'    => 'kerp-appointment-public-field-order',
				'name'  => 'field[order]',
				'label' => __( 'ترتیب', 'kasebi-erp' ),
				'type'  => 'number',
				'class' => 'col-md-6',
				'value' => 100,
			],
			[
				'id'            => 'kerp-appointment-public-field-placeholder',
				'name'          => 'field[placeholder]',
				'label'         => __( 'متن جایگزین', 'kasebi-erp' ),
				'type'          => 'text',
				'class'         => 'col-12',
				'value'         => '',
				'conditional'   => TRUE,
				'cond_meta'     => 'field[type]',
				'cond_operator' => '==',
				'cond_expected' => wp_json_encode(
					[
						'text',
						'email',
						'number',
						'date',
						'textarea',
					]
				),
			],
			[
				'id'    => 'kerp-appointment-public-field-description',
				'name'  => 'field[description]',
				'label' => __( 'توضیحات', 'kasebi-erp' ),
				'type'  => 'textarea',
				'class' => 'col-12',
				'rows'  => 3,
			],
			[
				'id'            => 'kerp-appointment-public-field-options',
				'name'          => 'field[options]',
				'label'         => __( 'گزینه‌ها', 'kasebi-erp' ),
				'description'   => __( 'هر گزینه را در یک خط و به شکل key=عنوان وارد کنید.', 'kasebi-erp' ),
				'type'          => 'textarea',
				'class'         => 'col-12',
				'rows'          => 5,
				'placeholder'   => "male=مرد\nfemale=زن",
				'value'         => '',
				'conditional'   => TRUE,
				'cond_meta'     => 'field[type]',
				'cond_operator' => '==',
				'cond_expected' => wp_json_encode(
					[
						'select',
						'radio',
						'multi-select',
					]
				),
			],
			[
				'id'    => 'kerp-appointment-public-field-required',
				'name'  => 'field[required]',
				'label' => __( 'اجباری باشد', 'kasebi-erp' ),
				'type'  => 'switch',
				'class' => 'col-md-6',
				'value' => '0',
			],
			[
				'id'    => 'kerp-appointment-public-field-active',
				'name'  => 'field[active]',
				'label' => __( 'فعال', 'kasebi-erp' ),
				'type'  => 'switch',
				'class' => 'col-md-6',
				'value' => '1',
			],
		],
	]
);
?>