<?php

defined( 'ABSPATH' ) || exit;

$settings                   = KERP_Modules_Appointments_Settings::instance();
$sms                        = KERP_Modules_Appointments_SMS::instance();
$rules                      = $sms->get_rules();
$action_options             = $sms->get_action_options();
$recipient_options          = $sms->get_recipient_options();
$variables                  = $sms->get_available_variables();
$active_tab                 = 'sms';
$active_rules               = count( array_filter( $rules, fn( array $rule ): bool => ! empty( $rule['enabled'] ) ) );
$appointment_status_options = [];

foreach ( $settings->get_statuses( FALSE ) as $status_key => $status ) {
	$appointment_status_options[ $status_key ] = $status['label'] ?? $status_key;
}

$action_options = [
	'created'        => __( 'ثبت نوبت', 'kasebi-erp' ),
	'status_changed' => __( 'تغییر وضعیت', 'kasebi-erp' ),
];

$fields = [
	'active_tab' => [
		'id'    => 'kerp-appointments-active-tab-sms',
		'name'  => 'active_tab',
		'type'  => 'hidden',
		'class' => 'no_clear',
		'value' => $active_tab,
	],
	
	'rules' => [
		'id'          => 'kerp-appointments-sms-rules',
		'name'        => 'sms_rules',
		'label'       => __( 'قواعد ارسال پیامک', 'kasebi-erp' ),
		'type'        => 'repeater',
		'class'       => 'col-12',
		'value'       => $rules,
		'button_text' => __( 'افزودن قانون', 'kasebi-erp' ),
		
		'fields' => [
			[
				'name'           => 'event',
				'label'          => __( 'اکشن', 'kasebi-erp' ),
				'type'           => 'select',
				'repeater_class' => 'col-12 col-md-4',
				'options'        => $action_options,
				'placeholder'    => __( 'انتخاب اکشن', 'kasebi-erp' ),
			],
			
			[
				'name'           => 'status',
				'label'          => __( 'وضعیت نوبت', 'kasebi-erp' ),
				'type'           => 'select',
				'repeater_class' => 'col-12 col-md-4',
				'options'        => $appointment_status_options,
				'placeholder'    => __( 'انتخاب وضعیت', 'kasebi-erp' ),
			],
			[
				'name'           => 'recipient',
				'label'          => __( 'گیرنده', 'kasebi-erp' ),
				'type'           => 'select',
				'repeater_class' => 'col-12 col-md-6',
				'options'        => $recipient_options,
				'placeholder'    => __( 'انتخاب گیرنده', 'kasebi-erp' ),
			],
			[
				'name'           => 'receptor',
				'label'          => __( 'شماره دلخواه', 'kasebi-erp' ),
				'type'           => 'text',
				'repeater_class' => 'col-12 col-md-6',
				'conditional'    => TRUE,
				'cond_meta'      => 'recipient',
				'cond_operator'  => '==',
				'cond_expected'  => 'custom',
				'input_class'    => 'fc-direction-ltr',
			],
			[
				'name'           => 'pattern',
				'label'          => __( 'نام پترن', 'kasebi-erp' ),
				'type'           => 'text',
				'repeater_class' => 'col-12',
				'input_class'    => 'fc-direction-ltr',
			],
			[
				'name'           => 'variables',
				'label'          => __( 'متغیرهای پترن', 'kasebi-erp' ),
				'type'           => 'textarea',
				'repeater_class' => 'col-12',
				'rows'           => 2,
				'placeholder'    => 'name:{first_name};token:{appointment_date}',
				'input_class'    => 'fc-direction-ltr',
			],
		],
	],
];
?>
<form class="modal_form kerp-appointments-settings"
      data-action="appointments_save_sms_settings"
      data-page="/erp/appointments/settings/sms/">
	<?php
	KERP_Helpers_Template::render_template(
		'app/components/fields/hidden.php',
		[ 'field' => $fields['active_tab'] ]
	);
	?>

    <div class="nk-block-head nk-block-head-sm">
        <div class="nk-block-between">
            <div class="nk-block-head-content">
                <h3 class="nk-block-title page-title">
					<?php echo esc_html( sprintf( __( 'پیامک‌های %s', 'kasebi-erp' ), $settings->get_appointment_plural_label() ) ); ?>
                </h3>
                <div class="nk-block-des text-soft">
                    <p><?php esc_html_e( 'برای رویدادهای مختلف رزرو، پترن پیامک و گیرنده را تعریف کنید.', 'kasebi-erp' ); ?></p>
                </div>
            </div>

            <div class="nk-block-head-content">
                <button type="button" class="btn btn-primary submit_modal_form">
                    <em class="icon ni ni-save"></em>
                    <span><?php esc_html_e( 'ذخیره تنظیمات', 'kasebi-erp' ); ?></span>
                </button>
            </div>
        </div>
    </div>

    <div class="nk-block">
		<?php
		KERP_Helpers_Template::render_template(
			'app/components/settings/hero.php',
			[
				'icon'        => 'icon ni ni-chat-circle',
				'eyebrow'     => __( 'ارسال خودکار', 'kasebi-erp' ),
				'title'       => __( 'پیامک رویدادهای رزرو', 'kasebi-erp' ),
				'description' => __( 'هر قانون مشخص می‌کند در چه رویدادی، کدام پترن و برای چه گیرنده‌ای ارسال شود.', 'kasebi-erp' ),
				'stats'       => [
					[
						'label' => __( 'کل قوانین', 'kasebi-erp' ),
						'value' => number_format_i18n( count( $rules ) ),
					],
					[
						'label' => __( 'قوانین فعال', 'kasebi-erp' ),
						'value' => number_format_i18n( $active_rules ),
					],
					[
						'label' => __( 'اکشن‌های قابل انتخاب', 'kasebi-erp' ),
						'value' => number_format_i18n( count( $action_options ) ),
					],
					[
						'label' => __( 'متغیرهای آماده', 'kasebi-erp' ),
						'value' => number_format_i18n( count( $variables ) ),
					],
				],
			]
		);
		?>
    </div>
	
	<?php if ( ! $sms->service_available() ) : ?>
        <div class="nk-block">
            <div class="alert alert-warning alert-icon">
                <em class="icon ni ni-alert-circle"></em>
                <strong><?php esc_html_e( 'سرویس پیامک در دسترس نیست.', 'kasebi-erp' ); ?></strong>
				<?php esc_html_e( 'کلاس kasebiSMS یا متد send_pattern_sms پیدا نشد؛ تنظیمات ذخیره می‌شوند اما ارسال انجام نخواهد شد.', 'kasebi-erp' ); ?>
            </div>
        </div>
	<?php endif; ?>

    <div class="nk-block">
        <div class="card card-bordered">
            <div class="card-inner border-bottom">
                <div class="d-flex align-items-center justify-content-between flex-wrap g-2">
                    <div>
                        <h6 class="title mb-1"><?php esc_html_e( 'قوانین ارسال', 'kasebi-erp' ); ?></h6>
                        <p class="text-soft mb-0">
							<?php esc_html_e( 'در گیرنده «شماره دلخواه» می‌توانید چند شماره را با , از هم جدا کنید.', 'kasebi-erp' ); ?>
                        </p>
                    </div>
                    <span class="badge badge-dim bg-outline-primary">
						<?php echo esc_html( sprintf( __( '%s قانون', 'kasebi-erp' ), number_format_i18n( count( $rules ) ) ) ); ?>
					</span>
                </div>
            </div>

            <div class="card-inner">
                <div class="row g-4">
					<?php
					KERP_Helpers_Template::render_template(
						'app/components/fields/repeater.php',
						[ 'field' => $fields['rules'] ]
					);
					?>
                </div>
            </div>
        </div>
    </div>

    <div class="nk-block">
        <div class="card card-bordered">
            <div class="card-inner border-bottom">
                <div class="d-flex align-items-center justify-content-between g-2">
                    <div>
                        <h6 class="title mb-1">
							<?php esc_html_e( 'متغیرهای قابل استفاده', 'kasebi-erp' ); ?>
                        </h6>

                        <p class="text-soft mb-0">
							<?php esc_html_e( 'برای کپی کردن هر متغیر روی آن کلیک کنید.', 'kasebi-erp' ); ?>
                        </p>
                    </div>

                    <span class="badge badge-dim bg-light">
					<?php
					echo esc_html(
						sprintf(
							__( '%s متغیر', 'kasebi-erp' ),
							number_format_i18n( count( $variables ) )
						)
					);
					?>
				</span>
                </div>
            </div>

            <div class="card-inner">
                <div class="alert alert-light alert-icon mb-4">
                    <em class="icon ni ni-info"></em>
                    <div>
                        <strong><?php esc_html_e( 'ساختار متغیرهای پترن', 'kasebi-erp' ); ?></strong>

                        <div class="mt-1">
                            <code>name:{first_name};token:{appointment_date}</code>
                        </div>
                    </div>
                </div>

                <div class="row g-3 kerp-sms-variables">
					<?php foreach ( $variables as $variable => $label ) : ?>
                        <div class="col-12 col-sm-6 col-lg-4 col-xl-3">
                            <button
                                type="button"
                                class="kerp-sms-variable clipboard-init"
                                data-clipboard-text="<?php echo esc_attr( $variable ); ?>"
                                data-clip-text="<?php esc_attr_e( 'کپی', 'kasebi-erp' ); ?>"
                                data-clip-success="<?php esc_attr_e( 'کپی شد', 'kasebi-erp' ); ?>"
                                data-clip-error="<?php esc_attr_e( 'ناموفق', 'kasebi-erp' ); ?>"
                            >
							<span class="kerp-sms-variable__content">
								<span class="kerp-sms-variable__label">
									<?php echo esc_html( $label ); ?>
								</span>

								<code class="kerp-sms-variable__code">
									<?php echo esc_html( $variable ); ?>
								</code>
							</span>

                                <span class="kerp-sms-variable__copy">
								<em class="icon ni ni-copy"></em>
								<span class="clipboard-text">
									<?php esc_html_e( 'کپی', 'kasebi-erp' ); ?>
								</span>
							</span>
                            </button>
                        </div>
					<?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</form>
