<?php

defined( 'ABSPATH' ) || exit;

$booking_service = KERP_Modules_Appointments_Booking_Product::instance();
$product_id      = $booking_service->get_product_id();
$product         = $booking_service->get_product();
$active_tab      = 'product';
$product_exists  = $product instanceof WC_Product;
$is_hidden       = $product_exists && $product->get_catalog_visibility() === 'hidden';
$is_virtual      = $product_exists && $product->is_virtual();
$is_healthy      = $product_exists && $is_hidden && $is_virtual;
$product_name    = $product_exists ? $product->get_name() : __( 'محصول سیستمی هنوز ایجاد نشده است', 'kasebi-erp' );
?>
<div class="kerp-appointments-settings">
	<div class="nk-block-head nk-block-head-sm">
		<div class="nk-block-between">
			<div class="nk-block-head-content">
				<h3 class="nk-block-title page-title"><?php esc_html_e( 'محصول سیستمی رزرو', 'kasebi-erp' ); ?></h3>
				<div class="nk-block-des text-soft">
					<p><?php esc_html_e( 'محصول مشترک و مخفی ووکامرس که در مرحله پرداخت رزروها استفاده می‌شود.', 'kasebi-erp' ); ?></p>
				</div>
			</div>
			<div class="nk-block-head-content">
				<button type="button"
				        class="btn btn-light row_inline_action"
				        data-action="appointments_repair_booking_product"
				        data-item-id="<?php echo esc_attr( $product_id ); ?>"
				        data-page="/erp/appointments/settings/product/"
				        data-active_tab="<?php echo esc_attr( $active_tab ); ?>"
				        data-needs="[]"
				        data-swal-title="<?php esc_attr_e( 'محصول سیستمی رزرو بررسی و در صورت نیاز تعمیر شود؟', 'kasebi-erp' ); ?>">
					<em class="icon ni ni-reload"></em>
					<span><?php esc_html_e( 'بررسی و تعمیر محصول', 'kasebi-erp' ); ?></span>
				</button>
			</div>
		</div>
	</div>
	<div class="nk-block">
		<div class="card card-bordered kerp-settings-hero kerp-appointments-product-hero">
			<div class="card-inner">
				<div class="kerp-settings-hero__layout">
					<div class="kerp-settings-hero__intro">
						<div class="kerp-settings-hero__icon">
							<em class="icon ni ni-cart"></em>
						</div>
						<div>
							<div class="d-flex align-items-center flex-wrap gap-2 mb-1">
								<span class="overline-title text-primary mb-0"><?php esc_html_e( 'WooCommerce Bridge', 'kasebi-erp' ); ?></span>
								<span class="badge <?php echo $is_healthy ? 'bg-success-dim text-success' : 'bg-warning-dim text-warning'; ?>">
									<?php echo $is_healthy ? esc_html__( 'سالم و آماده', 'kasebi-erp' ) : esc_html__( 'نیازمند بررسی', 'kasebi-erp' ); ?>
								</span>
							</div>
							<h4 class="title mb-1"><?php echo esc_html( $product_name ); ?></h4>
							<p class="text-soft mb-0"><?php esc_html_e( 'این محصول پشت‌صحنه برای انتقال مبلغ رزرو به جریان استاندارد پرداخت ووکامرس استفاده می‌شود و نباید در کاتالوگ فروشگاه نمایش داده شود.', 'kasebi-erp' ); ?></p>
						</div>
					</div>
					<div class="kerp-settings-stat kerp-appointments-product-id">
						<span><?php esc_html_e( 'شناسه محصول', 'kasebi-erp' ); ?></span>
						<strong><?php echo $product_id > 0 ? esc_html( '#' . number_format_i18n( $product_id ) ) : '—'; ?></strong>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="nk-block">
		<div class="row g-gs kerp-appointments-product-health">
			<div class="col-sm-6 col-xl-3">
				<div class="card card-bordered h-100 kerp-appointments-health-card <?php echo $product_exists ? 'is-ok' : 'is-warning'; ?>">
					<div class="card-inner">
						<span class="kerp-appointments-health-card__icon"><em class="icon ni ni-package"></em></span>
						<div><span><?php esc_html_e( 'وضعیت محصول', 'kasebi-erp' ); ?></span><strong><?php echo $product_exists ? esc_html__( 'ایجاد شده', 'kasebi-erp' ) : esc_html__( 'نیازمند ایجاد', 'kasebi-erp' ); ?></strong></div>
					</div>
				</div>
			</div>
			<div class="col-sm-6 col-xl-3">
				<div class="card card-bordered h-100 kerp-appointments-health-card <?php echo $is_hidden ? 'is-ok' : 'is-warning'; ?>">
					<div class="card-inner">
						<span class="kerp-appointments-health-card__icon"><em class="icon ni ni-eye-off"></em></span>
						<div><span><?php esc_html_e( 'نمایش در فروشگاه', 'kasebi-erp' ); ?></span><strong><?php echo $is_hidden ? esc_html__( 'مخفی', 'kasebi-erp' ) : esc_html__( 'نیازمند اصلاح', 'kasebi-erp' ); ?></strong></div>
					</div>
				</div>
			</div>
			<div class="col-sm-6 col-xl-3">
				<div class="card card-bordered h-100 kerp-appointments-health-card <?php echo $is_virtual ? 'is-ok' : 'is-warning'; ?>">
					<div class="card-inner">
						<span class="kerp-appointments-health-card__icon"><em class="icon ni ni-cloud"></em></span>
						<div><span><?php esc_html_e( 'نوع محصول', 'kasebi-erp' ); ?></span><strong><?php echo $is_virtual ? esc_html__( 'مجازی', 'kasebi-erp' ) : esc_html__( 'نیازمند اصلاح', 'kasebi-erp' ); ?></strong></div>
					</div>
				</div>
			</div>
			<div class="col-sm-6 col-xl-3">
				<div class="card card-bordered h-100 kerp-appointments-health-card <?php echo $is_healthy ? 'is-ok' : 'is-warning'; ?>">
					<div class="card-inner">
						<span class="kerp-appointments-health-card__icon"><em class="icon ni ni-shield-check"></em></span>
						<div><span><?php esc_html_e( 'سلامت اتصال', 'kasebi-erp' ); ?></span><strong><?php echo $is_healthy ? esc_html__( 'آماده پرداخت', 'kasebi-erp' ) : esc_html__( 'بررسی شود', 'kasebi-erp' ); ?></strong></div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="nk-block">
		<div class="card card-bordered kerp-appointments-product-note">
			<div class="card-inner">
				<div class="kerp-appointments-product-note__content">
					<span class="kerp-appointments-settings-section-icon"><em class="icon ni ni-info"></em></span>
					<div>
						<h6 class="title mb-1"><?php esc_html_e( 'این محصول را دستی ویرایش نکنید', 'kasebi-erp' ); ?></h6>
						<p class="text-soft mb-0"><?php esc_html_e( 'در صورت حذف شدن محصول یا تغییر ویژگی‌های ضروری آن، از «بررسی و تعمیر محصول» استفاده کنید تا تنظیمات موردنیاز به شکل خودکار بازسازی شوند.', 'kasebi-erp' ); ?></p>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
