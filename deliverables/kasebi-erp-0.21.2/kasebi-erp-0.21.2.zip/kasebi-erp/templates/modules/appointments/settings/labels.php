<?php

defined( 'ABSPATH' ) || exit;

$settings   = KERP_Modules_Appointments_Settings::instance();
$values     = $settings->all();
$active_tab = 'labels';

$fields = [
	'active_tab'                   => [
		'id'    => 'kerp-appointments-active-tab-labels',
		'name'  => 'active_tab',
		'type'  => 'hidden',
		'class' => 'no_clear',
		'value' => $active_tab,
	],
	'appointment_singular_label'   => [
		'id'       => 'kerp-appointments-appointment-singular-label',
		'name'     => 'settings[appointment_singular_label]',
		'label'    => __( 'عنوان مفرد', 'kasebi-erp' ),
		'type'     => 'text',
		'class'    => 'col-12',
		'value'    => (string) ( $values['appointment_singular_label'] ?? 'نوبت' ),
		'required' => TRUE,
	],
	'appointment_plural_label'     => [
		'id'       => 'kerp-appointments-appointment-plural-label',
		'name'     => 'settings[appointment_plural_label]',
		'label'    => __( 'عنوان جمع', 'kasebi-erp' ),
		'type'     => 'text',
		'class'    => 'col-12',
		'value'    => (string) ( $values['appointment_plural_label'] ?? 'نوبت‌ها' ),
		'required' => TRUE,
	],
	'service_singular_label'       => [
		'id'       => 'kerp-appointments-service-singular-label',
		'name'     => 'settings[service_singular_label]',
		'label'    => __( 'عنوان مفرد', 'kasebi-erp' ),
		'type'     => 'text',
		'class'    => 'col-12',
		'value'    => (string) ( $values['service_singular_label'] ?? 'خدمت' ),
		'required' => TRUE,
	],
	'service_plural_label'         => [
		'id'       => 'kerp-appointments-service-plural-label',
		'name'     => 'settings[service_plural_label]',
		'label'    => __( 'عنوان جمع', 'kasebi-erp' ),
		'type'     => 'text',
		'class'    => 'col-12',
		'value'    => (string) ( $values['service_plural_label'] ?? 'خدمات' ),
		'required' => TRUE,
	],
	'provider_singular_label'      => [
		'id'       => 'kerp-appointments-provider-singular-label',
		'name'     => 'settings[provider_singular_label]',
		'label'    => __( 'عنوان مفرد', 'kasebi-erp' ),
		'type'     => 'text',
		'class'    => 'col-12',
		'value'    => (string) ( $values['provider_singular_label'] ?? 'کارشناس' ),
		'required' => TRUE,
	],
	'provider_plural_label'        => [
		'id'       => 'kerp-appointments-provider-plural-label',
		'name'     => 'settings[provider_plural_label]',
		'label'    => __( 'عنوان جمع', 'kasebi-erp' ),
		'type'     => 'text',
		'class'    => 'col-12',
		'value'    => (string) ( $values['provider_plural_label'] ?? 'کارشناسان' ),
		'required' => TRUE,
	],
];

$label_groups = [
	[
		'icon'        => 'ni ni-calendar',
		'title'       => __( 'نوبت', 'kasebi-erp' ),
		'description' => __( 'عنوانی که در فهرست‌ها، فرم‌ها و جزئیات رزرو نمایش داده می‌شود.', 'kasebi-erp' ),
		'fields'      => [ 'appointment_singular_label', 'appointment_plural_label' ],
	],
	[
		'icon'        => 'ni ni-briefcase',
		'title'       => __( 'خدمت', 'kasebi-erp' ),
		'description' => __( 'نام نمایشی سرویس‌ها یا خدمات قابل رزرو در سیستم.', 'kasebi-erp' ),
		'fields'      => [ 'service_singular_label', 'service_plural_label' ],
	],
	[
		'icon'        => 'ni ni-user-list',
		'title'       => __( 'ارائه‌دهنده', 'kasebi-erp' ),
		'description' => __( 'عنوان کارشناسان، پزشکان، مشاوران یا هر فرد ارائه‌دهنده خدمت.', 'kasebi-erp' ),
		'fields'      => [ 'provider_singular_label', 'provider_plural_label' ],
	],
];
?>
<form class="modal_form kerp-appointments-settings" data-action="appointments_save_settings" data-page="/erp/appointments/settings/labels/">
	<?php KERP_Helpers_Template::render_template( 'app/components/fields/hidden.php', [ 'field' => $fields['active_tab'] ] ); ?>
	<div class="nk-block-head nk-block-head-sm">
		<div class="nk-block-between">
			<div class="nk-block-head-content">
				<h3 class="nk-block-title page-title"><?php esc_html_e( 'لیبل‌های نوبت‌دهی', 'kasebi-erp' ); ?></h3>
				<div class="nk-block-des text-soft">
					<p><?php esc_html_e( 'عنوان‌های نمایشی نوبت، خدمت و ارائه‌دهنده را متناسب با کسب‌وکار تغییر دهید.', 'kasebi-erp' ); ?></p>
				</div>
			</div>
			<div class="nk-block-head-content">
				<button type="button" class="btn btn-primary submit_modal_form">
					<em class="icon ni ni-save"></em>
					<span><?php esc_html_e( 'ذخیره لیبل‌ها', 'kasebi-erp' ); ?></span>
				</button>
			</div>
		</div>
	</div>
	<div class="nk-block">
				<?php
		KERP_Helpers_Template::render_template(
			'app/components/settings/hero.php',
			[
				'icon'        => 'icon ni ni-text-a',
				'eyebrow'     => __( 'واژگان کسب‌وکار', 'kasebi-erp' ),
				'title'       => __( 'نوبت‌دهی با ادبیات خودتان', 'kasebi-erp' ),
				'description' => __( 'بدون تغییر منطق سیستم، نام موجودیت‌های اصلی را با واژگان رایج کسب‌وکارتان هماهنگ کنید.', 'kasebi-erp' ),
				'stats'       => [
					[
						'label' => __( 'نوبت‌ها', 'kasebi-erp' ),
						'value' => (string) ( $values['appointment_plural_label'] ?? 'نوبت‌ها' ),
					],
					[
						'label' => __( 'خدمات', 'kasebi-erp' ),
						'value' => (string) ( $values['service_plural_label'] ?? 'خدمات' ),
					],
					[
						'label' => __( 'ارائه‌دهندگان', 'kasebi-erp' ),
						'value' => (string) ( $values['provider_plural_label'] ?? 'کارشناسان' ),
					],
				],
			]
		);
		?>
	</div>
	<div class="nk-block">
		<div class="row g-gs">
			<?php foreach ( $label_groups as $group ) : ?>
				<div class="col-lg-4">
					<div class="card card-bordered h-100 kerp-appointments-settings-card kerp-appointments-label-card">
						<div class="card-inner border-bottom">
							<div class="kerp-appointments-settings-card__head">
								<span class="kerp-appointments-settings-section-icon"><em class="icon <?php echo esc_attr( $group['icon'] ); ?>"></em></span>
								<div>
									<h6 class="title mb-1"><?php echo esc_html( $group['title'] ); ?></h6>
									<p class="text-soft mb-0"><?php echo esc_html( $group['description'] ); ?></p>
								</div>
							</div>
						</div>
						<div class="card-inner">
							<div class="row g-4">
								<?php foreach ( $group['fields'] as $field_key ) : ?>
									<?php KERP_Helpers_Template::render_template( 'app/components/fields/text.php', [ 'field' => $fields[ $field_key ] ] ); ?>
								<?php endforeach; ?>
							</div>
						</div>
					</div>
				</div>
			<?php endforeach; ?>
		</div>
	</div>
</form>
