<?php

defined( 'ABSPATH' ) || exit;

$settings       = KERP_Modules_Appointments_Settings::instance();
$statuses       = $settings->get_statuses( FALSE );
$status_options = $settings->get_status_options( FALSE );
$query          = KERP_Modules_Appointments_Query::instance();
$modal_id       = 'appointmentStatusModal';
$modal_selector = '#' . $modal_id;
$active_tab     = 'statuses';
$status_counts  = [];
$active_count   = 0;
$system_count   = 0;
$total_count    = 0;

foreach ( $statuses as $status_key => $status_item ) {
	$status_key                   = sanitize_key( (string) $status_key );
	$status_counts[ $status_key ] = $query->count_by_status( $status_key );
	$total_count                 += $status_counts[ $status_key ];
	$active_count                += ! empty( $status_item['active'] ) ? 1 : 0;
	$system_count                += ! empty( $status_item['system'] ) ? 1 : 0;
}

$add_populate = [
	'original' => [
		'id'    => '#kerp-appointment-status-original-key',
		'type'  => 'text',
		'value' => '',
	],
	'key'      => [
		'id'    => '#kerp-appointment-status-key',
		'type'  => 'text',
		'value' => '',
	],
	'label'    => [
		'id'    => '#kerp-appointment-status-label',
		'type'  => 'text',
		'value' => '',
	],
	'icon'     => [
		'id'    => '#kerp-appointment-status-icon',
		'type'  => 'text',
		'value' => 'ni ni-clock',
	],
	'color'    => [
		'id'    => '#kerp-appointment-status-color',
		'type'  => 'select',
		'value' => 'primary',
	],
	'order'    => [
		'id'    => '#kerp-appointment-status-order',
		'type'  => 'text',
		'value' => 10,
	],
	'active'   => [
		'id'    => '#kerp-appointment-status-active',
		'type'  => 'checkbox',
		'value' => '1',
	],
];

foreach ( array_keys( $status_options ) as $next_key ) {
	$add_populate['next_' . $next_key] = [
		'id'    => '#kerp-appointment-status-allowed-next_' . sanitize_key( (string) $next_key ),
		'type'  => 'checkbox',
		'value' => '0',
	];
}
?>
<div class="kerp-appointments-settings">
	<div class="nk-block-head nk-block-head-sm">
		<div class="nk-block-between">
			<div class="nk-block-head-content">
				<h3 class="nk-block-title page-title"><?php echo esc_html( sprintf( __( 'وضعیت‌های %s', 'kasebi-erp' ), $settings->get_appointment_singular_label() ) ); ?></h3>
				<div class="nk-block-des text-soft">
					<p><?php echo esc_html( sprintf( __( 'وضعیت‌ها و گردش مجاز بین مراحل مختلف %s را مدیریت کنید.', 'kasebi-erp' ), $settings->get_appointment_singular_label() ) ); ?></p>
				</div>
			</div>
			<div class="nk-block-head-content">
				<a href="#"
				   class="btn btn-primary open_populate_modal"
				   data-modal="<?php echo esc_attr( $modal_selector ); ?>"
				   data-modal-title="<?php echo esc_attr( sprintf( __( 'افزودن وضعیت %s', 'kasebi-erp' ), $settings->get_appointment_singular_label() ) ); ?>"
				   data-submit-text="<?php esc_attr_e( 'افزودن وضعیت', 'kasebi-erp' ); ?>"
				   data-populate="<?php echo esc_attr( wp_json_encode( $add_populate ) ); ?>">
					<em class="icon ni ni-plus"></em>
					<span><?php esc_html_e( 'افزودن وضعیت', 'kasebi-erp' ); ?></span>
				</a>
			</div>
		</div>
	</div>
	<div class="nk-block">
				<?php
		KERP_Helpers_Template::render_template(
			'app/components/settings/hero.php',
			[
				'icon'        => 'icon ni ni-list-check',
				'eyebrow'     => sprintf( __( 'چرخه عمر %s', 'kasebi-erp' ), $settings->get_appointment_singular_label() ),
				'title'       => __( 'جریان وضعیت‌ها و انتقال‌ها', 'kasebi-erp' ),
				'description' => sprintf( __( 'هر کارت یک مرحله از چرخه %1$s است و مسیرهای مجاز بعدی مشخص می‌کنند %1$s از آن مرحله به کجا می‌تواند منتقل شود.', 'kasebi-erp' ), $settings->get_appointment_singular_label() ),
				'stats'       => [
					[
						'label' => __( 'کل وضعیت‌ها', 'kasebi-erp' ),
						'value' => number_format_i18n( count( $statuses ) ),
					],
					[
						'label' => __( 'فعال', 'kasebi-erp' ),
						'value' => number_format_i18n( $active_count ),
					],
					[
						'label' => __( 'سیستمی', 'kasebi-erp' ),
						'value' => number_format_i18n( $system_count ),
					],
					[
						'label' => sprintf( __( '%s ثبت‌شده', 'kasebi-erp' ), $settings->get_appointment_plural_label() ),
						'value' => number_format_i18n( $total_count ),
					],
				],
			]
		);
		?>
	</div>
	<div class="nk-block">
		<?php if ( empty( $statuses ) ) : ?>
						<?php
			KERP_Helpers_Template::render_template(
				'app/components/settings/empty-state.php',
				[
					'icon'        => 'icon ni ni-list-check',
					'title'       => __( 'هنوز وضعیتی تعریف نشده است', 'kasebi-erp' ),
					'description' => sprintf( __( 'برای ساخت چرخه %s، اولین وضعیت را ایجاد کنید.', 'kasebi-erp' ), $settings->get_appointment_singular_label() ),
					'action'      => [ 'tag' => 'a', 'label' => __( 'افزودن اولین وضعیت', 'kasebi-erp' ), 'icon' => 'icon ni ni-plus', 'class' => 'btn btn-primary open_populate_modal', 'attributes' => [ 'href' => '#', 'data-modal' => $modal_selector, 'data-modal-title' => sprintf( __( 'افزودن وضعیت %s', 'kasebi-erp' ), $settings->get_appointment_singular_label() ), 'data-submit-text' => __( 'افزودن وضعیت', 'kasebi-erp' ), 'data-populate' => wp_json_encode( $add_populate ) ] ],
				]
			);
			?>
		<?php else : ?>
			<div class="row g-gs kerp-settings-status-grid">
				<?php foreach ( $statuses as $key => $status ) : ?>
					<?php
					$key          = sanitize_key( (string) $key );
					$icon         = trim( (string) ( $status['icon'] ?? 'ni ni-clock' ) );
					$color        = sanitize_key( (string) ( $status['color'] ?? 'primary' ) ) ?: 'primary';
					$count        = absint( $status_counts[ $key ] ?? 0 );
					$system       = ! empty( $status['system'] );
					$active       = ! empty( $status['active'] );
					$allowed_next = array_values( array_filter( array_map( 'sanitize_key', (array) ( $status['allowed_next'] ?? [] ) ) ) );
					$populate     = [
						'original' => [
							'id'    => '#kerp-appointment-status-original-key',
							'type'  => 'text',
							'value' => $key,
						],
						'key'      => [
							'id'    => '#kerp-appointment-status-key',
							'type'  => $system ? 'no_change' : 'text',
							'value' => $key,
						],
						'label'    => [
							'id'    => '#kerp-appointment-status-label',
							'type'  => 'text',
							'value' => (string) ( $status['label'] ?? '' ),
						],
						'icon'     => [
							'id'    => '#kerp-appointment-status-icon',
							'type'  => 'text',
							'value' => $icon,
						],
						'color'    => [
							'id'    => '#kerp-appointment-status-color',
							'type'  => 'select',
							'value' => $color,
						],
						'order'    => [
							'id'    => '#kerp-appointment-status-order',
							'type'  => 'text',
							'value' => intval( $status['order'] ?? 10 ),
						],
						'active'   => [
							'id'    => '#kerp-appointment-status-active',
							'type'  => 'checkbox',
							'value' => $active ? '1' : '0',
						],
					];

					foreach ( array_keys( $status_options ) as $next_key ) {
						$populate['next_' . $next_key] = [
							'id'    => '#kerp-appointment-status-allowed-next_' . sanitize_key( (string) $next_key ),
							'type'  => 'checkbox',
							'value' => in_array( $next_key, $allowed_next, TRUE ) ? '1' : '0',
						];
					}
					?>
					<?php
					$transition_labels = [];
					foreach ( $allowed_next as $next_key ) {
						$transition_labels[] = (string) ( $status_options[ $next_key ] ?? $next_key );
					}
					$actions = [
						[
							'label'      => __( 'ویرایش', 'kasebi-erp' ),
							'icon'       => 'icon ni ni-edit',
							'class'      => 'edit_row_item',
							'attributes' => [
								'data-modal'       => $modal_selector,
								'data-modal-title' => sprintf( __( 'ویرایش وضعیت %s', 'kasebi-erp' ), $settings->get_appointment_singular_label() ),
								'data-submit-text' => __( 'ذخیره تغییرات', 'kasebi-erp' ),
								'data-populate'    => wp_json_encode( $populate ),
							],
						],
					];
					if ( ! $system && $count <= 0 ) {
						$actions[] = [
							'label'          => __( 'حذف', 'kasebi-erp' ),
							'icon'           => 'icon ni ni-trash',
							'class'          => 'delete_db_item',
							'divider_before' => TRUE,
							'attributes'     => [
								'data-action'            => 'appointments_delete_status',
								'data-page'              => '/erp/appointments/settings/statuses/',
								'data-active_tab'        => $active_tab,
								'data-status_key'        => $key,
								'data-item_id'           => $key,
							],
						];
					}
					$meta = [
						[ 'icon' => 'icon ni ni-calendar', 'text' => sprintf( __( '%1$s %2$s', 'kasebi-erp' ), number_format_i18n( $count ), $settings->get_appointment_singular_label() ) ],
						[ 'icon' => 'icon ni ni-sort', 'text' => sprintf( __( 'ترتیب %s', 'kasebi-erp' ), number_format_i18n( intval( $status['order'] ?? 10 ) ) ) ],
					];
					if ( $system ) {
						$meta[] = [ 'icon' => 'icon ni ni-shield-check', 'text' => __( 'سیستمی', 'kasebi-erp' ) ];
					}
					if ( ! $active ) {
						$meta[] = [ 'icon' => 'icon ni ni-pause', 'text' => __( 'غیرفعال', 'kasebi-erp' ), 'class' => 'text-warning' ];
					}
					KERP_Helpers_Template::render_template(
						'app/components/settings/status-card.php',
						[
							'color'       => $color,
							'icon'        => $icon . ' icon',
							'label'       => (string) ( $status['label'] ?? $key ),
							'key'         => $key,
							'active'      => $active,
							'show_state'  => FALSE,
							'actions'     => $actions,
							'meta'        => $meta,
							'transitions' => $transition_labels,
						]
					);
					?>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>
	</div>
</div>
