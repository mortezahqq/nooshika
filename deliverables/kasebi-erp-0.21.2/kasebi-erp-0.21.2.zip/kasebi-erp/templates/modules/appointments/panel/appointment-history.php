<?php

defined( 'ABSPATH' ) || exit;

echo do_shortcode( '[kerp_appointment_history]' );