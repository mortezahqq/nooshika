<?php

defined( 'ABSPATH' ) || exit;
/** @var array $services */
/** @var array $taxonomies */
/** @var array $employee_options */
/** @var array $customer_fields */
/** @var array $gateways */
/** @var array $user_data */
/** @var KERP_Modules_Appointments_Settings $settings */
$service_label     = $settings->get_service_singular_label();
$services_label    = $settings->get_service_plural_label();
$provider_label    = $settings->get_provider_singular_label();
$appointment_label = $settings->get_appointment_singular_label();
$current_url       = get_permalink() ?: home_url( '/' );
$booking_start     = (string) $settings->get( 'booking_start_date', '' );
$booking_end       = (string) $settings->get( 'booking_end_date', '' );
$booking_month     = substr( max( current_time( 'Y-m-d' ), $booking_start ), 0, 7 );
?>
<div class="kerp-booking" data-current-month="<?php echo esc_attr( $booking_month ); ?>">
    <?php if ( $booking_start !== '' || $booking_end !== '' ) : ?>
        <p class="text-break">
            <?php esc_html_e( 'بازه فعال بودن نوبت‌دهی:', 'kasebi-erp' ); ?>
            <?php echo esc_html( $booking_start !== '' ? KERP_Helpers_Date::gregorian_to_jalali( $booking_start ) : __( 'بدون محدودیت شروع', 'kasebi-erp' ) ); ?>
            —
            <?php echo esc_html( $booking_end !== '' ? KERP_Helpers_Date::gregorian_to_jalali( $booking_end ) : __( 'بدون محدودیت پایان', 'kasebi-erp' ) ); ?>
        </p>
    <?php endif; ?>
    <div class="kerp-booking__steps">
        <button type="button" class="kerp-booking__step is-active" data-step="1">
            <span>1</span><strong><?php echo esc_html( $service_label ); ?></strong></button>
        <button type="button" class="kerp-booking__step" data-step="2">
            <span>2</span><strong><?php esc_html_e( 'زمان', 'kasebi-erp' ); ?></strong></button>
        <button type="button" class="kerp-booking__step" data-step="3">
            <span>3</span><strong><?php esc_html_e( 'اطلاعات شما', 'kasebi-erp' ); ?></strong></button>
        <button type="button" class="kerp-booking__step" data-step="4">
            <span>4</span><strong><?php esc_html_e( 'تایید و پرداخت', 'kasebi-erp' ); ?></strong></button>
    </div>
    <div class="kerp-booking__notice" hidden></div>
    <input type="hidden" class="kerp-booking-service-id" value="">
    <input type="hidden" class="kerp-booking-employee-id" value="0">
    <input type="hidden" class="kerp-booking-date" value="">
    <input type="hidden" class="kerp-booking-time" value="">
    <input type="hidden" class="kerp-booking-receipt-base-url" value="<?php echo esc_url( $current_url ); ?>">

    <section class="kerp-booking__panel is-active" data-panel="1">
        <div class="kerp-booking__panel-head">
            <div class="kerp-booking__panel-heading">
                <h3><?php echo esc_html( sprintf( __( '%s موردنظر را انتخاب کنید', 'kasebi-erp' ), $service_label ) ); ?></h3>
            </div>
        </div>
        <div class="kerp-booking__filters">
			<?php foreach ( $taxonomies as $taxonomy ) {
				$terms = (array) ( $taxonomy['terms'] ?? [] );
				if ( count( $terms ) <= 1 ) {
					continue;
				}
				?>
                <label class="kerp-booking__field">
                    <span><?php echo esc_html( (string) ( $taxonomy['singular_label'] ?? '' ) ); ?></span>
                    <select class="kerp-booking-tax-filter"
                            data-taxonomy-id="<?php echo esc_attr( absint( $taxonomy['id'] ?? 0 ) ); ?>">
                        <option value="0"><?php esc_html_e( 'همه موارد', 'kasebi-erp' ); ?></option>
						<?php foreach ( $terms as $term ) : ?>
                            <option
                                value="<?php echo esc_attr( absint( $term['id'] ?? 0 ) ); ?>"><?php echo esc_html( (string) ( $term['name'] ?? '' ) ); ?></option>
						<?php endforeach; ?>
                    </select>
                </label>
				<?php
			}
			?>
			<?php if ( count( $employee_options ) > 1 ) : ?>
                <label class="kerp-booking__field">
                    <span><?php echo esc_html( $provider_label ); ?></span>

                    <select class="kerp-booking-employee-filter">
                        <option value="0">
							<?php
							echo esc_html(
								sprintf(
									__( 'همه %s', 'kasebi-erp' ),
									$settings->get_provider_plural_label()
								)
							);
							?>
                        </option>
						
						<?php foreach ( $employee_options as $employee_id => $employee_name ) : ?>
                            <option value="<?php echo esc_attr( absint( $employee_id ) ); ?>">
								<?php echo esc_html( $employee_name ); ?>
                            </option>
						<?php endforeach; ?>
                    </select>
                </label>
			<?php endif; ?>
        </div>
        <div class="kerp-booking__services">
			<?php foreach ( $services as $service ) {
				$service_id   = absint( $service['id'] ?? 0 );
				$term_ids     = array_values( array_filter( array_map( 'absint', (array) ( $service['term_ids'] ?? [] ) ) ) );
				$employee_ids = array_values( array_filter( array_map( 'absint', (array) ( $service['employee_ids'] ?? [] ) ) ) );
				$price        = (float) ( $service['price'] ?? 0 );
				$payable      = KERP_Modules_Appointments_Services::instance()->calculate_payable_amount( $service );
				$service_data = [
					'id'           => $service_id,
					'term_ids'     => array_map( 'absint', $term_ids ),
					'employee_ids' => array_map( 'absint', $employee_ids ),
					'icon'         => (string) ( $service['icon'] ?? 'uik fa-calendar' ),
					'title'        => (string) ( $service['title'] ?? '' ),
					'description'  => (string) ( $service['description'] ?? '' ),
					'price'        => $price,
					'payable'      => $payable,
					'duration'     => absint( $service['duration_min'] ?? 0 ),
					'price_html'   => $price > 0
						? KERP_Helpers_Template::price( $price  )
						: esc_html__( 'رایگان', 'kasebi-erp' ),
				];
				?>
                <button type="button"
                        class="kerp-booking-service"
                        data-service="<?php echo esc_attr( wp_json_encode( $service_data, JSON_UNESCAPED_UNICODE ) ); ?>"
                        data-service-id="<?php echo esc_attr( $service_id ); ?>"
                        data-term-ids="<?php echo esc_attr( implode( ',', $term_ids ) ); ?>"
                        data-employee-ids="<?php echo esc_attr( implode( ',', $employee_ids ) ); ?>"
                        data-icon="<?php echo esc_attr( (string) ( $service['icon'] ?? 'uik fa-calendar' ) ); ?>"
                        data-title="<?php echo esc_attr( (string) ( $service['title'] ?? '' ) ); ?>"
                        data-price="<?php echo esc_attr( (string) $price ); ?>"
                        data-payable="<?php echo esc_attr( (string) $payable ); ?>"
                        data-duration="<?php echo esc_attr( absint( $service['duration_min'] ?? 0 ) ); ?>">
                    <span class="kerp-booking-service__icon"><em
                            class="<?php echo esc_attr( (string) ( $service['icon'] ?? 'uik fa-calendar' ) );
		                    ?>"></em></span>
                    <span
                        class="kerp-booking-service__body"><strong><?php echo esc_html( (string) ( $service['title'] ?? '' ) ); ?></strong><?php if ( trim( (string) ( $service['description'] ?? '' ) ) !== '' ) : ?>
                            <small><?php echo esc_html( wp_trim_words( wp_strip_all_tags( (string) $service['description'] ), 18 ) ); ?></small><?php endif; ?></span>
                    <span
                        class="kerp-booking-service__meta"><small><?php echo esc_html( sprintf( __( '%d دقیقه', 'kasebi-erp' ), absint( $service['duration_min'] ?? 0 ) ) ); ?></small><strong><?php echo $price > 0 ? wp_kses_post( KERP_Helpers_Template::price( $price  ) ) : esc_html__( 'رایگان', 'kasebi-erp' ); ?></strong></span>
                </button>
				<?php
			}
			?>
            <div class="kerp-booking__empty-services"
                 hidden><?php echo esc_html( sprintf( __( '%s مطابق فیلترهای انتخاب‌شده پیدا نشد.', 'kasebi-erp' ), $service_label ) ); ?></div>
        </div>
        <div class="kerp-booking__footer"><span></span>
            <button type="button" class="kerp-booking__next" data-next="2"
                    disabled><?php esc_html_e( 'انتخاب زمان', 'kasebi-erp' ); ?></button>
        </div>
    </section>

    <section class="kerp-booking__panel" data-panel="2">
        <div class="kerp-booking__panel-head">
            <div class="kerp-booking__panel-heading">
                <h3><?php esc_html_e( 'انتخاب روز و ساعت', 'kasebi-erp' ); ?></h3>
                <p><?php esc_html_e( 'از تقویم، روز مناسب و سپس یکی از ساعت‌های آزاد را انتخاب کنید.', 'kasebi-erp' ); ?></p>
            </div>

            <div class="kerp-booking__selection-summary">
                <div class="kerp-booking__selection-summary-icon">
                    <em class="icon ni ni-calendar-booking"></em>
                </div>
                <div class="kerp-booking__selection-summary-content">
                    <strong class="kerp-booking__selected-service"></strong>
                </div>

                <button type="button"
                        class="kerp-booking__change-service"
                        data-back="1">
                    <em class="icon ni ni-edit"></em>
                    <span><?php esc_html_e( 'تغییر', 'kasebi-erp' ); ?></span>
                </button>
            </div>
        </div>
        <div class="kerp-booking-service-description"></div>
        <div class="kerp-booking-calendar">
            <div class="kerp-booking-calendar__main">
                <div class="kerp-booking-calendar__nav">
                    <button type="button" class="kerp-booking-month-prev"
                            aria-label="<?php esc_attr_e( 'ماه قبل', 'kasebi-erp' ); ?>">‹
                    </button>
                    <strong class="kerp-booking-month-title"></strong>
                    <button type="button" class="kerp-booking-month-next"
                            aria-label="<?php esc_attr_e( 'ماه بعد', 'kasebi-erp' ); ?>">›
                    </button>
                </div>
                <div class="kerp-booking-calendar__weekdays">
                    <span><?php esc_html_e( 'شنبه', 'kasebi-erp' ); ?></span><span><?php esc_html_e( 'یکشنبه', 'kasebi-erp' ); ?></span><span><?php esc_html_e( 'دوشنبه', 'kasebi-erp' ); ?></span><span><?php esc_html_e( 'سه‌شنبه', 'kasebi-erp' ); ?></span><span><?php esc_html_e( 'چهارشنبه', 'kasebi-erp' ); ?></span><span><?php esc_html_e( 'پنجشنبه', 'kasebi-erp' ); ?></span><span><?php esc_html_e( 'جمعه', 'kasebi-erp' ); ?></span>
                </div>
                <div class="kerp-booking-calendar__days"></div>
            </div>
            <div class="kerp-booking-calendar__slots" id="slot_wrapper">
                <div class="kerp-booking-calendar__slots-head">
                    <strong><?php esc_html_e( 'ساعت‌های آزاد', 'kasebi-erp' ); ?></strong><span
                        class="kerp-booking-selected-date"></span></div>
                <div class="kerp-booking-calendar__slot-groups">
                    <div
                        class="kerp-booking-calendar__placeholder"><?php esc_html_e( 'یک روز را از تقویم انتخاب کنید.', 'kasebi-erp' ); ?></div>
                </div>
            </div>
        </div>
        <div class="kerp-booking__footer">
            <button type="button" class="kerp-booking__back"
                    data-back="1"><?php esc_html_e( 'بازگشت', 'kasebi-erp' ); ?></button>
            <button type="button" class="kerp-booking__next" data-next="3"
                    disabled><?php esc_html_e( 'ثبت اطلاعات', 'kasebi-erp' ); ?></button>
        </div>
    </section>

    <section class="kerp-booking__panel" data-panel="3">
        <div class="kerp-booking__panel-head">
            <div class="kerp-booking__panel-heading">
                <h3><?php esc_html_e( 'اطلاعات خود را وارد کنید', 'kasebi-erp' ); ?></h3>
            </div>
            <div class="kerp-booking__selection-summary">
                <div class="kerp-booking__selection-summary-icon">
                    <em class="icon ni ni-calendar-booking"></em>
                </div>
                <div class="kerp-booking__selection-summary-content">
                    <strong class="kerp-booking__selected-service"></strong>
                    <span class="kerp-booking__selected-date"></span>
                </div>
                <button type="button"
                        class="kerp-booking__change-service"
                        data-back="2">
                    <em class="icon ni ni-edit"></em>
                    <span><?php esc_html_e( 'تغییر', 'kasebi-erp' ); ?></span>
                </button>
            </div>
        </div>
        <div class="kerp-booking__form-grid">
            <label class="kerp-booking__field">
                <span><?php esc_html_e( 'نام', 'kasebi-erp' ); ?></span>
                <input type="text"
                       class="kerp-booking-input kerp-booking-first-name"
                       data-req="1"
                       data-validate="persian-text"
                       value="<?php echo esc_attr( (string) ( $user_data['first_name'] ?? '' ) ); ?>">
            </label>

            <label class="kerp-booking__field">
                <span><?php esc_html_e( 'نام خانوادگی', 'kasebi-erp' ); ?></span>
                <input type="text"
                       class="kerp-booking-input kerp-booking-last-name"
                       data-req="1"
                       data-validate="persian-text"
                       value="<?php echo esc_attr( (string) ( $user_data['last_name'] ?? '' ) ); ?>">
            </label>

            <label class="kerp-booking__field">
                <span><?php esc_html_e( 'شماره موبایل', 'kasebi-erp' ); ?></span>
                <input type="text"
                       class="kerp-booking-input kerp-booking-phone"
                       data-req="1"
                       data-validate="phone"
                       value="<?php echo esc_attr( (string) ( $user_data['phone'] ?? '' ) ); ?>"
                       inputmode="numeric">
            </label>
			
			<?php foreach ( $customer_fields as $field_key => $field ) : ?>
				<?php
				$type        = sanitize_key( (string) ( $field['type'] ?? 'text' ) );
				$value       = $user_data['custom_fields'][ $field_key ] ?? '';
				$options     = is_array( $field['options'] ?? NULL ) ? $field['options'] : [];
				$is_required = ! empty( $field['required'] );
				
				$input_type = in_array(
					$type,
					[
						'email',
						'number',
						'url',
						'date',
					],
					TRUE
				) ? $type : 'text';
				
				$validate = sanitize_key( (string) ( $field['validate'] ?? '' ) );
				
				if ( $validate === '' ) {
					$validate = match ( $type ) {
						'email' => 'email',
						'number' => 'number',
						'url' => 'url',
						'date' => 'date',
						default => '',
					};
				}
				?>

                <label class="kerp-booking__field<?php echo in_array( $type, [
					'textarea',
					'quill',
				], TRUE ) ? ' is-full' : ''; ?>">
			<span>
				<?php echo esc_html( (string) ( $field['label'] ?? $field_key ) ); ?>
				
				<?php if ( $is_required ) : ?>
                    <sup>*</sup>
				<?php endif; ?>
			</span>
					
					<?php if ( $type === 'select' || $type === 'multi-select' ) : ?>
                        <select class="kerp-booking-input kerp-booking-custom-field"
                                data-field-key="<?php echo esc_attr( $field_key ); ?>"
							<?php if ( $is_required ) : ?>
                                data-req="1"
							<?php endif; ?>
							<?php if ( $validate !== '' ) : ?>
                                data-validate="<?php echo esc_attr( $validate ); ?>"
							<?php endif; ?>
							<?php echo $type === 'multi-select' ? ' multiple' : ''; ?>>
							
							<?php if ( $type === 'select' ) : ?>
                                <option value="">
									<?php esc_html_e( 'انتخاب کنید', 'kasebi-erp' ); ?>
                                </option>
							<?php endif; ?>
							
							<?php foreach ( $options as $option_key => $option_label ) : ?>
                                <option value="<?php echo esc_attr( $option_key ); ?>"
									<?php
									selected(
										is_array( $value )
											? in_array( $option_key, $value, TRUE )
											: (string) $value === (string) $option_key
									);
									?>>
									<?php echo esc_html( $option_label ); ?>
                                </option>
							<?php endforeach; ?>
                        </select>
					
					<?php elseif ( $type === 'textarea' || $type === 'quill' ) : ?>
                        <textarea class="kerp-booking-input kerp-booking-custom-field"
                                  data-field-key="<?php echo esc_attr( $field_key ); ?>"
					<?php if ( $is_required ) : ?>
                        data-req="1"
					<?php endif; ?>
							<?php if ( $validate !== '' ) : ?>
                                data-validate="<?php echo esc_attr( $validate ); ?>"
							<?php endif; ?>
				          placeholder="<?php echo esc_attr( (string) ( $field['placeholder'] ?? '' ) ); ?>"><?php echo esc_textarea( (string) $value ); ?></textarea>
					
					<?php elseif ( $type === 'checkbox' || $type === 'switch' ) : ?>
                        <input type="checkbox"
                               class="kerp-booking-input kerp-booking-custom-field kerp-booking-custom-field--check"
                               data-field-key="<?php echo esc_attr( $field_key ); ?>"
                               value="1"
							<?php if ( $is_required ) : ?>
                                data-req="1"
							<?php endif; ?>
							<?php checked( ! empty( $value ) ); ?>>
					
					<?php elseif ( $type === 'radio' ) :
						?>
                        <div class="kerp-booking__radio-group">
							<?php foreach ( $options as $option_key => $option_label ) : ?>
                                <label>
                                    <input type="radio"
                                           class="kerp-booking-input kerp-booking-custom-field"
                                           data-field-key="<?php echo esc_attr( $field_key ); ?>"
                                           name="kerp_booking_<?php echo esc_attr( $field_key ); ?>"
                                           value="<?php echo esc_attr( $option_key ); ?>"
										<?php if ( $is_required ) : ?>
                                            data-req="1"
										<?php endif; ?>
										<?php if ( $validate !== '' ) : ?>
                                            data-validate="<?php echo esc_attr( $validate ); ?>"
										<?php endif; ?>
										<?php checked( (string) $value, (string) $option_key ); ?>>
                                    <span><?php echo esc_html( $option_label ); ?></span>
                                </label>
							<?php endforeach; ?>
                        </div>
					
					<?php else : ?>
                        <input type="<?php echo esc_attr( $input_type ); ?>"
                               class="kerp-booking-input kerp-booking-custom-field"
                               data-field-key="<?php echo esc_attr( $field_key ); ?>"
                               value="<?php echo esc_attr( is_scalar( $value ) ? (string) $value : '' ); ?>"
                               placeholder="<?php echo esc_attr( (string) ( $field['placeholder'] ?? '' ) ); ?>"
							<?php if ( $is_required ) : ?>
                                data-req="1"
							<?php endif; ?>
							<?php if ( $validate !== '' ) : ?>
                                data-validate="<?php echo esc_attr( $validate ); ?>"
							<?php endif; ?>>
					<?php endif; ?>
					
					<?php if ( ! empty( $field['description'] ) ) : ?>
                        <small>
							<?php echo esc_html( (string) $field['description'] ); ?>
                        </small>
					<?php endif; ?>
                </label>
			<?php endforeach; ?>
			<?php
			$booking_terms_content = (string) $settings->get_booking_cancellation_terms();
			$booking_terms_text    = (string) $settings->get_booking_terms_checkbox_text();
			
			$booking_terms_plain = html_entity_decode(
				wp_strip_all_tags( $booking_terms_content ),
				ENT_QUOTES | ENT_HTML5,
				'UTF-8'
			);
			
			$booking_terms_plain = preg_replace( '/[\s\x{00A0}]+/u', '', $booking_terms_plain );
			$has_booking_terms   = is_string( $booking_terms_plain ) && $booking_terms_plain !== '';
			?>
			
			<?php if ( $has_booking_terms ) : ?>
                <div class="kerp-booking__terms">
                    <label class="kerp-booking__terms-check">
                        <input type="checkbox"
                               class="kerp-booking-input kerp-booking-terms-checkbox"
                               value="1"
                               data-req="1">
                        <span class="kerp-booking__terms-checkmark"><em class="kik fa-check icon"></em></span>
                        <span class="kerp-booking__terms-label"><?php echo esc_html( $booking_terms_text ); ?></span>
                    </label>

                    <details class="kerp-booking__terms-details">
                        <summary class="kerp-booking__terms-toggle">
                            <em class="uik fa-text-check icon"></em>
                            <span><?php esc_html_e( 'مطالعه قوانین', 'kasebi-erp' ); ?></span>
                            <em class="kik fa-chevron-down icon kerp-booking__terms-arrow"></em>
                        </summary>

                        <div class="kerp-booking__terms-content">
							<?php echo wp_kses_post( $booking_terms_content ); ?>
                        </div>
                    </details>
                </div>
			<?php endif; ?>
        </div>
        <div class="kerp-booking__footer">
            <button type="button" class="kerp-booking__back"
                    data-back="2"><?php esc_html_e( 'بازگشت', 'kasebi-erp' ); ?></button>
            <button type="button" class="kerp-booking__next"
                    data-next="4"><?php esc_html_e( 'مشاهده رسید', 'kasebi-erp' ); ?></button>
        </div>
    </section>

    <section class="kerp-booking__panel" data-panel="4">
        <div class="kerp-booking__panel-head">
            <div class="kerp-booking__panel-heading">
                <h3><?php echo esc_html( sprintf( __( 'رسید %s شما', 'kasebi-erp' ), $appointment_label ) ); ?></h3>
                <p><?php esc_html_e( 'اطلاعات را بررسی کنید؛ پس از تایید شماره موبایل به درگاه پرداخت منتقل می‌شوید.', 'kasebi-erp' ); ?></p>
            </div>
        </div>
        <div class="kerp-booking-summary">
            <div><span><?php echo esc_html( $service_label ); ?></span><strong data-summary="service">—</strong></div>
            <div><span><?php echo esc_html( $provider_label ); ?></span><strong data-summary="employee">—</strong></div>
            <div><span><?php esc_html_e( 'تاریخ', 'kasebi-erp' ); ?></span><strong data-summary="date">—</strong></div>
            <div><span><?php esc_html_e( 'ساعت', 'kasebi-erp' ); ?></span><strong data-summary="time">—</strong></div>
            <div><span><?php esc_html_e( 'نام و نام خانوادگی', 'kasebi-erp' ); ?></span><strong data-summary="customer">—</strong>
            </div>
            <div><span><?php esc_html_e( 'شماره موبایل', 'kasebi-erp' ); ?></span><strong
                    data-summary="phone">—</strong></div>
            <div class="kerp-booking-summary__price">
                <span><?php esc_html_e( 'مبلغ خدمت', 'kasebi-erp' ); ?></span><strong data-summary="price">—</strong>
            </div>
            <div class="kerp-booking-summary__payable">
                <span><?php esc_html_e( 'مبلغ قابل پرداخت', 'kasebi-erp' ); ?></span><strong
                    data-summary="payable">—</strong></div>
        </div>
        <div class="kerp-booking-gateways">
            <h4><?php esc_html_e( 'روش پرداخت', 'kasebi-erp' ); ?></h4>
			<?php if ( empty( $gateways ) ) : ?>
                <div
                    class="kerp-booking-gateways__empty"><?php esc_html_e( 'درگاه پرداخت فعالی در دسترس نیست.', 'kasebi-erp' ); ?></div><?php endif; ?>
			<?php foreach ( $gateways as $gateway_id => $gateway ) : ?>
                <label class="kerp-booking-gateway"><input type="radio" name="kerp_booking_gateway"
                                                           value="<?php echo esc_attr( $gateway_id ); ?>"><span><strong><?php echo esc_html( $gateway->get_title() ); ?></strong><?php if ( $gateway->get_description() ) : ?>
                            <small><?php echo wp_kses_post( $gateway->get_description() ); ?></small><?php endif; ?></span></label>
			<?php endforeach; ?>
        </div>
        <div class="kerp-booking__footer">
            <button type="button" class="kerp-booking__back"
                    data-back="3"><?php esc_html_e( 'ویرایش اطلاعات', 'kasebi-erp' ); ?></button>
            <button type="button"
                    class="kerp-booking__submit"><?php esc_html_e( 'تایید شماره و رفتن به پرداخت', 'kasebi-erp' ); ?></button>
        </div>
    </section>
</div>
