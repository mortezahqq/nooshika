<?php

defined( 'ABSPATH' ) || exit;
/** @var array $appointment */
/** @var WC_Order|null $order */
/** @var KERP_Modules_Appointments_Settings $settings */
$status = $settings->get_status( (string) ( $appointment['status'] ?? '' ) );
$date   = substr( (string) ( $appointment['start_at'] ?? '' ), 0, 10 );
$time   = substr( (string) ( $appointment['start_at'] ?? '' ), 11, 5 );
$end    = substr( (string) ( $appointment['end_at'] ?? '' ), 11, 5 );
$is_paid = $order instanceof WC_Order ? $order->is_paid() : (float) ( $appointment['payable_amount'] ?? 0 ) <= 0;
?>
<div class="kerp-booking-receipt">
	<div class="kerp-booking-receipt__mark"><span>✓</span></div>
	<span class="kerp-booking-receipt__eyebrow"><?php echo esc_html( $settings->get_appointment_singular_label() ); ?> #<?php echo esc_html( number_format_i18n( absint( $appointment['id'] ?? 0 ) ) ); ?></span>
	<h2><?php echo $is_paid ? esc_html__( 'رزرو شما با موفقیت ثبت شد', 'kasebi-erp' ) : esc_html__( 'رزرو شما ثبت شد', 'kasebi-erp' ); ?></h2>
	<p><?php echo $is_paid ? esc_html__( 'اطلاعات رزرو و پرداخت شما در ادامه آمده است.', 'kasebi-erp' ) : esc_html__( 'پرداخت هنوز تکمیل نشده است.', 'kasebi-erp' ); ?></p>
	<div class="kerp-booking-receipt__grid">
		<div><span><?php echo esc_html( $settings->get_service_singular_label() ); ?></span><strong><?php echo esc_html( (string) ( $appointment['service_title'] ?? '' ) ); ?></strong></div>
		<div><span><?php echo esc_html( $settings->get_provider_singular_label() ); ?></span><strong><?php echo esc_html( (string) ( $appointment['employee_name'] ?? '' ) ); ?></strong></div>
		<div><span><?php esc_html_e( 'تاریخ', 'kasebi-erp' ); ?></span><strong><?php echo esc_html( KERP_Modules_Appointments_Form::instance()->to_display_date( $date ) ); ?></strong></div>
		<div><span><?php esc_html_e( 'ساعت', 'kasebi-erp' ); ?></span><strong><?php echo esc_html( $time . ( $end !== '' ? ' - ' . $end : '' ) ); ?></strong></div>
		<div><span><?php esc_html_e( 'وضعیت', 'kasebi-erp' ); ?></span><strong><?php echo esc_html( (string) ( $status['label'] ?? $appointment['status'] ?? '' ) ); ?></strong></div>
		<div><span><?php esc_html_e( 'مبلغ', 'kasebi-erp' ); ?></span><strong><?php echo wp_kses_post( KERP_Helpers_Template::price( (float) ( $appointment['payable_amount'] ?? 0 )  ) ); ?></strong></div>
	</div>
	<?php if ( trim( (string) ( $appointment['location'] ?? '' ) ) !== '' ) : ?><div class="kerp-booking-receipt__location"><span><?php esc_html_e( 'محل برگزاری', 'kasebi-erp' ); ?></span><strong><?php echo esc_html( (string) $appointment['location'] ); ?></strong></div><?php endif; ?>
	<?php if ( $order instanceof WC_Order && $order->needs_payment() ) : ?><a class="kerp-booking-receipt__pay" href="<?php echo esc_url( $order->get_checkout_payment_url() ); ?>"><?php esc_html_e( 'ادامه پرداخت', 'kasebi-erp' ); ?></a><?php endif; ?>
</div>
