<?php

defined( 'ABSPATH' ) || exit;

/** @var array $appointments */
/** @var KERP_Modules_Appointments_Settings $settings */
/** @var string $login_url */
/** @var bool $is_logged_in */
?>
<div class="kerp-booking-history">
    <div class="kerp-booking-history__head">
        <div>
            <span><?php esc_html_e( 'سوابق نوبت‌های شما', 'kasebi-erp' ); ?></span>
            <h3><?php echo esc_html( $settings->get_appointment_plural_label() ); ?></h3>
        </div>
    </div>
	
	<?php if ( ! $is_logged_in ) : ?>
        <div class="kerp-booking-history__empty">
            <strong><?php esc_html_e( 'برای مشاهده سوابق وارد حساب کاربری شوید.', 'kasebi-erp' ); ?></strong>
            <a href="<?php echo esc_url( $login_url ); ?>">
				<?php esc_html_e( 'ورود به حساب', 'kasebi-erp' ); ?>
            </a>
        </div>
	<?php elseif ( empty( $appointments ) ) : ?>
        <div class="kerp-booking-history__empty">
            <strong>
				<?php
				echo esc_html(
					sprintf(
						__( 'هنوز %s ثبت نکرده‌اید.', 'kasebi-erp' ),
						$settings->get_appointment_singular_label()
					)
				);
				?>
            </strong>
        </div>
	<?php else : ?>
        <div class="kerp-booking-history__list">
			<?php foreach ( $appointments as $appointment ) : ?>
				<?php
				$appointment_id = absint( $appointment['id'] ?? 0 );
				$status_key     = sanitize_key( (string) ( $appointment['status'] ?? '' ) );
				$status         = $settings->get_status( $status_key );
				$start_at       = (string) ( $appointment['start_at'] ?? '' );
				$date           = $start_at !== '' ? substr( $start_at, 0, 10 ) : '';
				$time           = $start_at !== '' ? substr( $start_at, 11, 5 ) : '';
				$display_date   = $date !== ''
					? KERP_Modules_Appointments_Form::instance()->to_display_date( $date )
					: '—';
				
				$order_id = absint( $appointment['order_id'] ?? 0 );
				$order    = $order_id > 0 ? wc_get_order( $order_id ) : NULL;
				
				$location = trim( (string) ( $appointment['location'] ?? '' ) );
				$duration = absint( $appointment['duration_minutes'] ?? 0 );
				
				$created_at         = (string) ( $appointment['created_at'] ?? '' );
				$created_date       = $created_at !== '' ? substr( $created_at, 0, 10 ) : '';
				$created_time       = $created_at !== '' ? substr( $created_at, 11, 5 ) : '';
				$created_date_label = $created_date !== ''
					? KERP_Modules_Appointments_Form::instance()->to_display_date( $created_date )
					: '';
				
				$payment_status = '';
				$payment_class  = '';
				
				if ( $order instanceof WC_Order ) {
					if ( $order->is_paid() ) {
						$payment_status = __( 'پرداخت شده', 'kasebi-erp' );
						$payment_class  = 'is-paid';
					} elseif ( $order->needs_payment() ) {
						$payment_status = __( 'در انتظار پرداخت', 'kasebi-erp' );
						$payment_class  = 'is-pending';
					} else {
						$payment_status = wc_get_order_status_name( $order->get_status() );
						$payment_class  = 'is-neutral';
					}
				}
				?>

                <article class="kerp-booking-history-card">
                    <div class="kerp-booking-history-card__header">
                        <div class="kerp-booking-history-card__heading">
                            <div class="kerp-booking-history-card__number">
								<?php
								printf(
									esc_html__( 'شماره نوبت #%s', 'kasebi-erp' ),
									esc_html( number_format_i18n( $appointment_id ) )
								);
								?>
                            </div>

                            <h4>
								<?php echo esc_html( (string) ( $appointment['service_title'] ?? '' ) ); ?>
                            </h4>
                        </div>

                        <div class="kerp-booking-history-card__badges">
							<span
                                class="kerp-booking-status kerp-booking-status--<?php echo esc_attr( $status_key ); ?>">
								<?php echo esc_html( (string) ( $status['label'] ?? $status_key ) ); ?>
							</span>
							
							<?php if ( $payment_status !== '' ) : ?>
                                <span class="kerp-booking-payment-status <?php echo esc_attr( $payment_class ); ?>">
									<?php echo esc_html( $payment_status ); ?>
								</span>
							<?php endif; ?>
                        </div>
                    </div>

                    <div class="kerp-booking-history-card__primary">
                        <div class="kerp-booking-history-info">
                            <span><?php esc_html_e( 'تاریخ نوبت', 'kasebi-erp' ); ?></span>
                            <strong><?php echo esc_html( $display_date ); ?></strong>
                        </div>

                        <div class="kerp-booking-history-info">
                            <span><?php esc_html_e( 'ساعت', 'kasebi-erp' ); ?></span>
                            <strong><?php echo esc_html( $time !== '' ? $time : '—' ); ?></strong>
                        </div>

                        <div class="kerp-booking-history-info">
                            <span><?php echo esc_html( $settings->get_provider_singular_label() ); ?></span>
                            <strong>
								<?php echo esc_html( (string) ( $appointment['employee_name'] ?? '—' ) ); ?>
                            </strong>
                        </div>

                        <div class="kerp-booking-history-info kerp-booking-history-info--price">
                            <span><?php esc_html_e( 'مبلغ نوبت', 'kasebi-erp' ); ?></span>
                            <strong>
								<?php echo wp_kses_post( KERP_Helpers_Template::price( (float) ( $appointment['payable_amount'] ?? 0 )  ) ); ?>
                            </strong>
                        </div>
                    </div>
					
					<?php if ( $location !== '' || $duration > 0 || $order instanceof WC_Order || $created_date_label !== '' ) : ?>
                        <div class="kerp-booking-history-card__details">
							<?php if ( $location !== '' ) : ?>
                                <div class="kerp-booking-history-detail">
                                    <span><?php esc_html_e( 'محل برگزاری', 'kasebi-erp' ); ?></span>
                                    <strong><?php echo esc_html( $location ); ?></strong>
                                </div>
							<?php endif; ?>
							
							<?php if ( $duration > 0 ) : ?>
                                <div class="kerp-booking-history-detail">
                                    <span><?php esc_html_e( 'مدت خدمت', 'kasebi-erp' ); ?></span>
                                    <strong>
										<?php
										printf(
											esc_html__( '%s دقیقه', 'kasebi-erp' ),
											esc_html( number_format_i18n( $duration ) )
										);
										?>
                                    </strong>
                                </div>
							<?php endif; ?>
							
							<?php if ( $order instanceof WC_Order ) : ?>
                                <div class="kerp-booking-history-detail">
                                    <span><?php esc_html_e( 'شماره سفارش', 'kasebi-erp' ); ?></span>
                                    <strong>#<?php echo esc_html( $order->get_order_number() ); ?></strong>
                                </div>
							<?php endif; ?>
							
							<?php if ( $created_date_label !== '' ) : ?>
                                <div class="kerp-booking-history-detail">
                                    <span><?php esc_html_e( 'زمان ثبت', 'kasebi-erp' ); ?></span>
                                    <strong>
										<?php echo esc_html( $created_date_label ); ?>
										<?php if ( $created_time !== '' ) : ?>
                                            <small><?php echo esc_html( $created_time ); ?></small>
										<?php endif; ?>
                                    </strong>
                                </div>
							<?php endif; ?>
                        </div>
					<?php endif; ?>
					
					<?php if ( $order instanceof WC_Order && $order->needs_payment() ) : ?>
                        <div class="kerp-booking-history-card__actions">
                            <div>
                                <strong><?php esc_html_e( 'پرداخت این نوبت هنوز تکمیل نشده است.', 'kasebi-erp' ); ?></strong>
                                <span><?php esc_html_e( 'برای نهایی شدن رزرو، پرداخت را تکمیل کنید.', 'kasebi-erp' ); ?></span>
                            </div>

                            <a class="kerp-booking-history-card__pay"
                               href="<?php echo esc_url( $order->get_checkout_payment_url() ); ?>">
								<?php esc_html_e( 'ادامه پرداخت', 'kasebi-erp' ); ?>
                            </a>
                        </div>
					<?php endif; ?>
                </article>
			<?php endforeach; ?>
        </div>
	<?php endif; ?>
</div>