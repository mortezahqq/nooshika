<?php

defined( 'ABSPATH' ) || exit;

$settings = KERP_Modules_Appointments_Settings::instance();

/**
 * @var array $employee_options
 * @var array $service_options
 */

$employee_options = isset( $employee_options ) && is_array( $employee_options )
	? $employee_options
	: [];

$service_options = isset( $service_options ) && is_array( $service_options )
	? $service_options
	: [];

KERP_Helpers_Template::render_modal(
	[
		'id'     => 'appointmentExceptionModal',
		'title'  => __( 'افزودن یا ویرایش استثنای برنامه کاری', 'kasebi-erp' ),
		'action' => 'appointments_save_exception',
		'page'   => '/erp/appointments/schedules/',
		'button' => __( 'ذخیره استثنا', 'kasebi-erp' ),
		'size'   => 'lg',
		'fields' => [
			[
				'id'    => 'kerp-appointment-exception-active-tab',
				'name'  => 'active_tab',
				'type'  => 'hidden',
				'class' => 'no_clear',
				'value' => 'exceptions',
			],
			[
				'id'    => 'kerp-appointment-exception-filter-employee-id',
				'name'  => 'filter_employee_id',
				'type'  => 'hidden',
				'class' => 'no_clear',
				'value' => '',
			],
			[
				'id'    => 'kerp-appointment-exception-filter-service-id',
				'name'  => 'filter_service_id',
				'type'  => 'hidden',
				'class' => 'no_clear',
				'value' => '',
			],
			[
				'id'    => 'kerp-appointment-exception-id',
				'name'  => 'exception[id]',
				'type'  => 'hidden',
				'value' => '',
			],
			[
				'id'          => 'kerp-appointment-exception-employee',
				'name'        => 'exception[employee_id]',
				'label'       => $settings->get_provider_singular_label(),
				'type'        => 'select',
				'class'       => 'col-md-6',
				'options'     => $employee_options,
				'value'       => '',
				'required'    => TRUE,
				'placeholder' => sprintf( __( 'انتخاب %s', 'kasebi-erp' ), $settings->get_provider_singular_label() ),
			],
			[
				'id'      => 'kerp-appointment-exception-service',
				'name'    => 'exception[service_id]',
				'label'   => $settings->get_service_singular_label(),
				'type'    => 'select',
				'class'   => 'col-md-6',
				'options' => [
					             0 => sprintf( __( 'همه %s', 'kasebi-erp' ), $settings->get_service_plural_label() ),
				             ] + $service_options,
				'value'   => 0,
			],
			[
				'id'       => 'kerp-appointment-exception-date',
				'name'     => 'exception[date]',
				'label'    => __( 'تاریخ', 'kasebi-erp' ),
				'type'     => 'date',
				'class'    => 'col-md-6',
				'value'    => '',
				'required' => TRUE,
			],
			[
				'id'          => 'kerp-appointment-exception-type',
				'name'        => 'exception[type]',
				'label'       => __( 'نوع', 'kasebi-erp' ),
				'type'        => 'select',
				'class'       => 'col-md-6',
				'input_class' => 'kerp-appointment-exception-type',
				'options'     => [
					'closed'   => __( 'تعطیل / غیرقابل رزرو', 'kasebi-erp' ),
					'override' => __( 'برنامه جایگزین', 'kasebi-erp' ),
				],
				'value'       => 'closed',
			],
			[
				'id'            => 'kerp-appointment-exception-start',
				'name'          => 'exception[start_time]',
				'label'         => __( 'شروع', 'kasebi-erp' ),
				'type'          => 'text',
				'class'         => 'col-md-4',
				'input_class'   => 'time-picker',
				'value'         => '',
				'conditional'   => TRUE,
				'cond_meta'     => 'exception[type]',
				'cond_operator' => '==',
				'cond_expected' => 'override',
			],
			[
				'id'            => 'kerp-appointment-exception-end',
				'name'          => 'exception[end_time]',
				'label'         => __( 'پایان', 'kasebi-erp' ),
				'type'          => 'text',
				'class'         => 'col-md-4',
				'input_class'   => 'time-picker',
				'value'         => '',
				'conditional'   => TRUE,
				'cond_meta'     => 'exception[type]',
				'cond_operator' => '==',
				'cond_expected' => 'override',
			],
			[
				'id'            => 'kerp-appointment-exception-capacity',
				'name'          => 'exception[capacity]',
				'label'         => __( 'ظرفیت', 'kasebi-erp' ),
				'type'          => 'number',
				'class'         => 'col-md-4',
				'value'         => 0,
				'conditional'   => TRUE,
				'cond_meta'     => 'exception[type]',
				'cond_operator' => '==',
				'cond_expected' => 'override',
			],
			[
				'id'    => 'kerp-appointment-exception-note',
				'name'  => 'exception[note]',
				'label' => __( 'یادداشت', 'kasebi-erp' ),
				'type'  => 'quill',
				'class' => 'col-12',
				'rows'  => 3,
				'value' => '',
			],
			[
				'id'    => 'kerp-appointment-exception-active',
				'name'  => 'exception[active]',
				'label' => __( 'فعال', 'kasebi-erp' ),
				'type'  => 'switch',
				'class' => 'col-md-4',
				'value' => 1,
			],
		],
	]
);
