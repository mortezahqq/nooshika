<?php

defined( 'ABSPATH' ) || exit;

$settings = KERP_Modules_Appointments_Settings::instance();

KERP_Helpers_Template::render_modal(
	[
		'id'     => 'appointmentNoteModal',
		'title'  => sprintf( __( 'یادداشت %s', 'kasebi-erp' ), $settings->get_appointment_singular_label() ),
		'action' => 'appointments_save_note',
		'page'   => '/erp/appointments/',
		'button' => __( 'ذخیره یادداشت', 'kasebi-erp' ),
		'size'   => 'md',
		'fields' => [
			[
				'id'    => 'kerp-appointment-note-id',
				'name'  => 'appointment_id',
				'type'  => 'hidden',
				'value' => 0,
			],
			[
				'id'    => 'kerp-appointment-note-return-page',
				'name'  => 'return_page',
				'type'  => 'hidden',
				'value' => '/erp/appointments/',
			],
			[
				'id'          => 'kerp-appointment-quick-note',
				'name'        => 'note',
				'type'        => 'textarea',
				'label'       => __( 'یادداشت داخلی', 'kasebi-erp' ),
				'placeholder' => sprintf( __( 'یادداشت مربوط به این %s را وارد کنید...', 'kasebi-erp' ), $settings->get_appointment_singular_label() ),
				'class'       => 'col-12',
				'rows'        => 5,
				'value'       => '',
			],
		],
	]
);