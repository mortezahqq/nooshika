<?php

defined( 'ABSPATH' ) || exit;

$taxonomies = isset( $taxonomies ) && is_array( $taxonomies )
	? $taxonomies
	: KERP_Modules_Appointments_Taxonomies::instance()->get_taxonomies( FALSE );

$taxonomy_options = [];

foreach ( $taxonomies as $taxonomy ) {
	$taxonomy_id = absint( $taxonomy['id'] ?? 0 );
	
	if ( $taxonomy_id < 1 ) {
		continue;
	}
	
	$taxonomy_options[ $taxonomy_id ] = (string) ( $taxonomy['singular_label'] ?? $taxonomy['plural_label'] ?? $taxonomy_id );
}

$color_options = [
	'primary' => __( 'آبی', 'kasebi-erp' ),
	'success' => __( 'سبز', 'kasebi-erp' ),
	'info'    => __( 'فیروزه‌ای', 'kasebi-erp' ),
	'warning' => __( 'نارنجی', 'kasebi-erp' ),
	'danger'  => __( 'قرمز', 'kasebi-erp' ),
	'purple'  => __( 'بنفش', 'kasebi-erp' ),
];

KERP_Helpers_Template::render_modal(
	[
		'id'     => 'appointmentTermModal',
		'title'  => __( 'افزودن یا ویرایش گزینه دسته‌بندی', 'kasebi-erp' ),
		'action' => 'appointments_save_term',
		'page'   => '/erp/appointments/taxonomies/',
		'button' => __( 'ذخیره گزینه', 'kasebi-erp' ),
		'size'   => 'lg',
		'fields' => [
			[
				'id'    => 'kerp-appointment-term-id',
				'name'  => 'term[id]',
				'type'  => 'hidden',
				'value' => '',
			],
			[
				'id'          => 'kerp-appointment-term-taxonomy',
				'name'        => 'term[taxonomy_id]',
				'label'       => __( 'دسته‌بندی', 'kasebi-erp' ),
				'type'        => 'select',
				'class'       => 'col-md-6',
				'options'     => $taxonomy_options,
				'placeholder' => __( 'انتخاب دسته‌بندی', 'kasebi-erp' ),
				'value'       => '',
				'required'    => TRUE,
			],
			[
				'id'       => 'kerp-appointment-term-name',
				'name'     => 'term[name]',
				'label'    => __( 'عنوان', 'kasebi-erp' ),
				'type'     => 'text',
				'class'    => 'col-md-6',
				'value'    => '',
				'required' => TRUE,
			],
			[
				'id'    => 'kerp-appointment-term-slug',
				'name'  => 'term[slug]',
				'label' => __( 'نامک', 'kasebi-erp' ),
				'type'  => 'text',
				'class' => 'col-md-6',
				'value' => '',
			],
			[
				'id'    => 'kerp-appointment-term-parent',
				'name'  => 'term[parent_id]',
				'label' => __( 'شناسه گزینه والد', 'kasebi-erp' ),
				'type'  => 'number',
				'class' => 'col-md-6',
				'value' => 0,
			],
			[
				'id'          => 'kerp-appointment-term-description',
				'name'        => 'term[description]',
				'label'       => __( 'توضیحات', 'kasebi-erp' ),
				'type'        => 'textarea',
				'class'       => 'col-12',
				'rows'        => 3,
				'value'       => '',
				'placeholder' => __( 'توضیح کوتاهی درباره این گزینه بنویسید.', 'kasebi-erp' ),
			],
			[
				'id'    => 'kerp-appointment-term-icon',
				'name'  => 'term[icon]',
				'label' => __( 'کلاس آیکون', 'kasebi-erp' ),
				'type'  => 'text',
				'class' => 'col-md-4',
				'value' => 'ni ni-tag',
			],
			[
				'id'      => 'kerp-appointment-term-color',
				'name'    => 'term[color]',
				'label'   => __( 'رنگ', 'kasebi-erp' ),
				'type'    => 'select',
				'class'   => 'col-md-4',
				'options' => $color_options,
				'value'   => 'primary',
			],
			[
				'id'    => 'kerp-appointment-term-order',
				'name'  => 'term[order]',
				'label' => __( 'ترتیب نمایش', 'kasebi-erp' ),
				'type'  => 'number',
				'class' => 'col-md-4',
				'value' => 10,
			],
			[
				'id'    => 'kerp-appointment-term-active',
				'name'  => 'term[active]',
				'label' => __( 'فعال باشد', 'kasebi-erp' ),
				'type'  => 'switch',
				'class' => 'col-md-4',
				'value' => 1,
			],
		],
	]
);