<?php

defined( 'ABSPATH' ) || exit;

$settings = KERP_Modules_Appointments_Settings::instance();

$color_options = [
	'primary' => __( 'آبی', 'kasebi-erp' ),
	'success' => __( 'سبز', 'kasebi-erp' ),
	'info'    => __( 'فیروزه‌ای', 'kasebi-erp' ),
	'warning' => __( 'نارنجی', 'kasebi-erp' ),
	'danger'  => __( 'قرمز', 'kasebi-erp' ),
	'purple'  => __( 'بنفش', 'kasebi-erp' ),
];

KERP_Helpers_Template::render_modal(
	[
		'id'     => 'appointmentTaxonomyModal',
		'title'  => sprintf( __( 'افزودن یا ویرایش دسته‌بندی %s', 'kasebi-erp' ), $settings->get_service_plural_label() ),
		'action' => 'appointments_save_taxonomy',
		'page'   => '/erp/appointments/taxonomies/',
		'button' => __( 'ذخیره دسته‌بندی', 'kasebi-erp' ),
		'size'   => 'lg',
		'fields' => [
			[
				'id'    => 'kerp-appointment-taxonomy-id',
				'name'  => 'taxonomy[id]',
				'type'  => 'hidden',
				'value' => '',
			],
			[
				'id'       => 'kerp-appointment-taxonomy-key',
				'name'     => 'taxonomy[key]',
				'label'    => __( 'کلید', 'kasebi-erp' ),
				'type'     => 'text',
				'class'    => 'col-md-4',
				'value'    => '',
				'required' => TRUE,
			],
			[
				'id'       => 'kerp-appointment-taxonomy-singular',
				'name'     => 'taxonomy[singular_label]',
				'label'    => __( 'عنوان مفرد', 'kasebi-erp' ),
				'type'     => 'text',
				'class'    => 'col-md-4',
				'value'    => '',
				'required' => TRUE,
			],
			[
				'id'       => 'kerp-appointment-taxonomy-plural',
				'name'     => 'taxonomy[plural_label]',
				'label'    => __( 'عنوان جمع', 'kasebi-erp' ),
				'type'     => 'text',
				'class'    => 'col-md-4',
				'value'    => '',
				'required' => TRUE,
			],
			[
				'id'          => 'kerp-appointment-taxonomy-description',
				'name'        => 'taxonomy[description]',
				'label'       => __( 'توضیحات', 'kasebi-erp' ),
				'type'        => 'textarea',
				'class'       => 'col-12',
				'rows'        => 3,
				'value'       => '',
				'placeholder' => __( 'توضیح کوتاهی درباره کاربرد این دسته‌بندی بنویسید.', 'kasebi-erp' ),
			],
			[
				'id'    => 'kerp-appointment-taxonomy-icon',
				'name'  => 'taxonomy[icon]',
				'label' => __( 'کلاس آیکون', 'kasebi-erp' ),
				'type'  => 'text',
				'class' => 'col-md-4',
				'value' => 'ni ni-folder-list',
			],
			[
				'id'      => 'kerp-appointment-taxonomy-color',
				'name'    => 'taxonomy[color]',
				'label'   => __( 'رنگ', 'kasebi-erp' ),
				'type'    => 'select',
				'class'   => 'col-md-4',
				'options' => $color_options,
				'value'   => 'primary',
			],
			[
				'id'    => 'kerp-appointment-taxonomy-order',
				'name'  => 'taxonomy[order]',
				'label' => __( 'ترتیب نمایش', 'kasebi-erp' ),
				'type'  => 'number',
				'class' => 'col-md-4',
				'value' => 10,
			],
			[
				'id'    => 'kerp-appointment-taxonomy-active',
				'name'  => 'taxonomy[active]',
				'label' => __( 'فعال باشد', 'kasebi-erp' ),
				'type'  => 'switch',
				'class' => 'col-md-4',
				'value' => 1,
			],
		],
	]
);