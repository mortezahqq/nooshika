<?php

defined( 'ABSPATH' ) || exit;

$color_options = [
	'primary'   => __( 'اصلی', 'kasebi-erp' ),
	'secondary' => __( 'ثانویه', 'kasebi-erp' ),
	'success'   => __( 'موفق', 'kasebi-erp' ),
	'info'      => __( 'اطلاعاتی', 'kasebi-erp' ),
	'warning'   => __( 'هشدار', 'kasebi-erp' ),
	'danger'    => __( 'خطر', 'kasebi-erp' ),
	'light'     => __( 'روشن', 'kasebi-erp' ),
	'dark'      => __( 'تیره', 'kasebi-erp' ),
];

$fields = [
	[
		'id'          => 'kerp-appointment-location-type-active-tab',
		'name'        => 'active_tab',
		'type'        => 'hidden',
		'input_class' => 'no_clear',
		'value'       => 'location_types',
	],
	[
		'id'    => 'kerp-appointment-location-type-original-key',
		'name'  => 'original_key',
		'type'  => 'hidden',
		'class' => 'no_clear',
		'value' => '',
	],
	[
		'id'       => 'kerp-appointment-location-type-key',
		'name'     => 'location_type[key]',
		'label'    => __( 'کلید', 'kasebi-erp' ),
		'type'     => 'text',
		'class'    => 'col-md-6',
		'value'    => '',
		'required' => TRUE,
	],
	[
		'id'       => 'kerp-appointment-location-type-label',
		'name'     => 'location_type[label]',
		'label'    => __( 'عنوان', 'kasebi-erp' ),
		'type'     => 'text',
		'class'    => 'col-md-6',
		'value'    => '',
		'required' => TRUE,
	],
	[
		'id'    => 'kerp-appointment-location-type-icon',
		'name'  => 'location_type[icon]',
		'label' => __( 'آیکون', 'kasebi-erp' ),
		'type'  => 'text',
		'class' => 'col-md-4',
		'value' => 'uik-r fa-map-marker',
	],
	[
		'id'          => 'kerp-appointment-location-type-color',
		'name'        => 'location_type[color]',
		'label'       => __( 'رنگ', 'kasebi-erp' ),
		'type'        => 'select',
		'class'       => 'col-md-4',
		'options'     => $color_options,
		'placeholder' => __( 'انتخاب رنگ', 'kasebi-erp' ),
		'value'       => 'primary',
	],
	[
		'id'    => 'kerp-appointment-location-type-order',
		'name'  => 'location_type[order]',
		'label' => __( 'ترتیب', 'kasebi-erp' ),
		'type'  => 'number',
		'class' => 'col-md-4',
		'value' => 10,
	],
	[
		'id'    => 'kerp-appointment-location-type-active',
		'name'  => 'location_type[active]',
		'label' => __( 'فعال', 'kasebi-erp' ),
		'type'  => 'switch',
		'class' => 'col-md-4',
		'value' => 1,
	],
];

KERP_Helpers_Template::render_modal( [
	'id'     => 'appointmentLocationTypeModal',
	'title'  => __( 'افزودن یا ویرایش نوع برگزاری', 'kasebi-erp' ),
	'action' => 'appointments_save_location_type',
	'page'   => '/erp/appointments/settings/location-types/',
	'button' => __( 'ذخیره نوع برگزاری', 'kasebi-erp' ),
	'size'   => 'lg',
	'fields' => $fields,
] );