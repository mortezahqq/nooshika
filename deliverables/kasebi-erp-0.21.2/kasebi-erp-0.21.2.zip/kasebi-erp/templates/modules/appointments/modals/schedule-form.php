<?php

defined( 'ABSPATH' ) || exit;

$settings = KERP_Modules_Appointments_Settings::instance();

/**
 * @var array $employee_options
 * @var array $service_options
 * @var array $weekday_options
 */

$employee_options = isset( $employee_options ) && is_array( $employee_options )
	? $employee_options
	: [];

$service_options = isset( $service_options ) && is_array( $service_options )
	? $service_options
	: [];

$weekday_options = isset( $weekday_options ) && is_array( $weekday_options )
	? $weekday_options
	: [];

KERP_Helpers_Template::render_modal(
	[
		'id'     => 'appointmentScheduleModal',
		'title'  => __( 'افزودن یا ویرایش برنامه کاری', 'kasebi-erp' ),
		'action' => 'appointments_save_schedule',
		'page'   => '/erp/appointments/schedules/',
		'button' => __( 'ذخیره برنامه', 'kasebi-erp' ),
		'size'   => 'lg',
		'fields' => [
			[
				'id'    => 'kerp-appointment-schedule-active-tab',
				'name'  => 'active_tab',
				'type'  => 'hidden',
				'class' => 'no_clear',
				'value' => 'schedules',
			],
			[
				'id'    => 'kerp-appointment-schedule-filter-employee-id',
				'name'  => 'filter_employee_id',
				'type'  => 'hidden',
				'class' => 'no_clear',
				'value' => '',
			],
			[
				'id'    => 'kerp-appointment-schedule-filter-service-id',
				'name'  => 'filter_service_id',
				'type'  => 'hidden',
				'class' => 'no_clear',
				'value' => '',
			],
			[
				'id'    => 'kerp-appointment-schedule-id',
				'name'  => 'schedule[id]',
				'type'  => 'hidden',
				'value' => '',
			],
			[
				'id'          => 'kerp-appointment-schedule-employee',
				'name'        => 'schedule[employee_id]',
				'label'       => $settings->get_provider_singular_label(),
				'type'        => 'select',
				'class'       => 'col-md-6',
				'options'     => $employee_options,
				'value'       => '',
				'required'    => TRUE,
				'placeholder' => sprintf( __( 'انتخاب %s', 'kasebi-erp' ), $settings->get_provider_singular_label() ),
			],
			[
				'id'      => 'kerp-appointment-schedule-service',
				'name'    => 'schedule[service_id]',
				'label'   => $settings->get_service_singular_label(),
				'type'    => 'select',
				'class'   => 'col-md-6',
				'options' => [
					             0 => sprintf( __( 'همه %s', 'kasebi-erp' ), $settings->get_service_plural_label() ),
				             ] + $service_options,
				'value'   => 0,
			],
			[
				'id'       => 'kerp-appointment-schedule-weekday',
				'name'     => 'schedule[weekday]',
				'label'    => __( 'روز هفته', 'kasebi-erp' ),
				'type'     => 'select',
				'class'    => 'col-md-4',
				'options'  => $weekday_options,
				'value'    => 0,
				'required' => TRUE,
			],
			[
				'id'          => 'kerp-appointment-schedule-start',
				'name'        => 'schedule[start_time]',
				'label'       => __( 'شروع', 'kasebi-erp' ),
				'type'        => 'text',
				'class'       => 'col-md-4',
				'input_class' => 'time-picker',
				'value'       => '09:00',
				'required'    => TRUE,
			],
			[
				'id'          => 'kerp-appointment-schedule-end',
				'name'        => 'schedule[end_time]',
				'label'       => __( 'پایان', 'kasebi-erp' ),
				'type'        => 'text',
				'class'       => 'col-md-4',
				'input_class' => 'time-picker',
				'value'       => '17:00',
				'required'    => TRUE,
			],
			[
				'id'    => 'kerp-appointment-schedule-interval',
				'name'  => 'schedule[slot_interval]',
				'label' => __( 'فاصله اسلات‌ها (دقیقه)', 'kasebi-erp' ),
				'type'  => 'number',
				'class' => 'col-md-4',
				'value' => 0,
			],
			[
				'id'    => 'kerp-appointment-schedule-capacity',
				'name'  => 'schedule[capacity]',
				'label' => __( 'ظرفیت', 'kasebi-erp' ),
				'type'  => 'number',
				'class' => 'col-md-4',
				'value' => 0,
			],
			[
				'id'    => 'kerp-appointment-schedule-order',
				'name'  => 'schedule[order]',
				'label' => __( 'ترتیب', 'kasebi-erp' ),
				'type'  => 'number',
				'class' => 'col-md-2',
				'value' => 10,
			],
			[
				'id'    => 'kerp-appointment-schedule-active',
				'name'  => 'schedule[active]',
				'label' => __( 'فعال', 'kasebi-erp' ),
				'type'  => 'switch',
				'class' => 'col-md-2 align-self-end',
				'value' => 1,
			],
		],
	]
);
