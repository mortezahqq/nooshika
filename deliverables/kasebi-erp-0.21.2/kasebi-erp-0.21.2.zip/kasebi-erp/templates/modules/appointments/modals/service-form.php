<?php

defined( 'ABSPATH' ) || exit;

/**
 * @var array $employee_options
 * @var array $taxonomy_groups
 */

$settings = KERP_Modules_Appointments_Settings::instance();

$employee_options = isset( $employee_options ) && is_array( $employee_options )
	? $employee_options
	: [];

$taxonomy_groups = isset( $taxonomy_groups ) && is_array( $taxonomy_groups )
	? $taxonomy_groups
	: [];

$fields = [
	[
		'id'    => 'kerp-appointment-service-id',
		'name'  => 'service[id]',
		'type'  => 'hidden',
		'value' => '',
	],
	[
		'id'       => 'kerp-service-title',
		'name'     => 'service[title]',
		'label'    => __( 'عنوان', 'kasebi-erp' ),
		'type'     => 'text',
		'class'    => 'col-md-8',
		'value'    => '',
		'required' => TRUE,
	],
	[
		'id'    => 'kerp-service-slug',
		'name'  => 'service[slug]',
		'label' => __( 'کلید', 'kasebi-erp' ),
		'type'  => 'text',
		'class' => 'col-md-4',
		'value' => '',
	],
	[
		'id'          => 'kerp-service-description',
		'name'        => 'service[description]',
		'label'       => __( 'توضیحات', 'kasebi-erp' ),
		'type'        => 'quill',
		'class'       => 'col-12',
		'value'       => '',
		'placeholder' => sprintf( __( 'توضیح کوتاهی درباره این %s بنویسید.', 'kasebi-erp' ), $settings->get_service_singular_label() ),
	],
	[
		'id'       => 'kerp-service-duration',
		'name'     => 'service[duration_min]',
		'label'    => sprintf( __( 'مدت %s (دقیقه)', 'kasebi-erp' ), $settings->get_service_singular_label() ),
		'type'     => 'number',
		'class'    => 'col-md-3',
		'value'    => absint( $settings->get( 'default_duration', 30 ) ),
		'required' => TRUE,
	],
	[
		'id'    => 'kerp-service-buffer-before',
		'name'  => 'service[buffer_before_min]',
		'label' => __( 'فاصله قبل (دقیقه)', 'kasebi-erp' ),
		'type'  => 'number',
		'class' => 'col-md-3',
		'value' => 0,
	],
	[
		'id'    => 'kerp-service-buffer-after',
		'name'  => 'service[buffer_after_min]',
		'label' => __( 'فاصله بعد (دقیقه)', 'kasebi-erp' ),
		'type'  => 'number',
		'class' => 'col-md-3',
		'value' => 0,
	],
	[
		'id'    => 'kerp-service-capacity',
		'name'  => 'service[capacity]',
		'label' => __( 'ظرفیت هر بازه زمانی', 'kasebi-erp' ),
		'type'  => 'number',
		'class' => 'col-md-3',
		'value' => absint( $settings->get( 'default_capacity', 1 ) ),
	],
	[
		'id'    => 'kerp-service-price',
		'name'  => 'service[price]',
		'label' => __( 'قیمت', 'kasebi-erp' ),
		'type'  => 'price',
		'class' => 'col-md-4',
		'value' => 0,
	],
	[
		'id'      => 'kerp-service-deposit-type',
		'name'    => 'service[deposit_type]',
		'label'   => __( 'نوع بیعانه', 'kasebi-erp' ),
		'type'    => 'select',
		'class'   => 'col-md-4',
		'options' => [
			'none'    => __( 'بدون بیعانه', 'kasebi-erp' ),
			'fixed'   => __( 'مبلغ ثابت', 'kasebi-erp' ),
			'percent' => __( 'درصد', 'kasebi-erp' ),
			'full'    => __( 'پرداخت کامل', 'kasebi-erp' ),
		],
		'value'   => 'none',
	],
	[
		'id'            => 'kerp-service-deposit-fixed-value',
		'name'          => 'service[deposit_value]',
		'label'         => __( 'مبلغ بیعانه', 'kasebi-erp' ),
		'type'          => 'price',
		'class'         => 'col-md-4',
		'value'         => 0,
		'conditional'   => TRUE,
		'cond_meta'     => 'service[deposit_type]',
		'cond_operator' => '==',
		'cond_expected' => 'fixed',
	],
	[
		'id'            => 'kerp-service-deposit-percent-value',
		'name'          => 'service[deposit_value]',
		'label'         => __( 'درصد بیعانه', 'kasebi-erp' ),
		'type'          => 'number',
		'class'         => 'col-md-4',
		'input_class'   => 'kerp-service-deposit-percent',
		'value'         => 0,
		'conditional'   => TRUE,
		'cond_meta'     => 'service[deposit_type]',
		'cond_operator' => '==',
		'cond_expected' => 'percent',
	],
	[
		'id'    => 'kerp-service-icon',
		'name'  => 'service[icon]',
		'label' => __( 'آیکون', 'kasebi-erp' ),
		'type'  => 'text',
		'class' => 'col-md-4',
		'value' => 'ni ni-calendar-booking',
	],
	[
		'id'      => 'kerp-service-color',
		'name'    => 'service[color]',
		'label'   => __( 'رنگ', 'kasebi-erp' ),
		'type'    => 'select',
		'class'   => 'col-md-4',
		'options' => [
			'primary' => __( 'اصلی', 'kasebi-erp' ),
			'info'    => __( 'آبی', 'kasebi-erp' ),
			'success' => __( 'سبز', 'kasebi-erp' ),
			'warning' => __( 'هشدار', 'kasebi-erp' ),
			'danger'  => __( 'قرمز', 'kasebi-erp' ),
			'purple'  => __( 'بنفش', 'kasebi-erp' ),
			'light'   => __( 'روشن', 'kasebi-erp' ),
		],
		'value'   => 'primary',
	],
	[
		'id'    => 'kerp-service-order',
		'name'  => 'service[order]',
		'label' => __( 'ترتیب نمایش', 'kasebi-erp' ),
		'type'  => 'number',
		'class' => 'col-md-4',
		'value' => 10,
	],
	[
		'id'    => 'kerp-service-active',
		'name'  => 'service[active]',
		'label' => __( 'فعال', 'kasebi-erp' ),
		'type'  => 'switch',
		'class' => 'col-md-3',
		'value' => 1,
	],
	[
		'id'    => 'kerp-service-public',
		'name'  => 'service[public_booking]',
		'label' => __( 'قابل رزرو عمومی', 'kasebi-erp' ),
		'type'  => 'switch',
		'class' => 'col-md-4',
		'value' => 1,
	],
];

if ( ! empty( $employee_options ) ) {
	$fields[] = [
		'id'          => 'kerp-service-employees',
		'name'        => 'service[employee_ids]',
		'label'       => $settings->get_provider_plural_label(),
		'type'        => 'checkbox',
		'class'       => 'col-12 kerp-service-form-choice-group',
		'input_class' => 'kerp-service-employee-option',
		'options'     => $employee_options,
		'value'       => [],
	];
}

foreach ( $taxonomy_groups as $group ) {
	$taxonomy = isset( $group['taxonomy'] ) && is_array( $group['taxonomy'] )
		? $group['taxonomy']
		: [];
	
	$terms = isset( $group['terms'] ) && is_array( $group['terms'] )
		? $group['terms']
		: [];
	
	if ( empty( $terms ) ) {
		continue;
	}
	
	$taxonomy_id = absint( $taxonomy['id'] ?? 0 );
	
	if ( $taxonomy_id <= 0 ) {
		continue;
	}
	
	$options = [];
	
	foreach ( $terms as $term ) {
		$term_id = absint( $term['id'] ?? 0 );
		
		if ( $term_id <= 0 ) {
			continue;
		}
		
		$options[ $term_id ] = (string) ( $term['name'] ?? '' );
	}
	
	if ( empty( $options ) ) {
		continue;
	}
	
	$fields[] = [
		'id'          => 'kerp-service-taxonomy-' . $taxonomy_id,
		'name'        => 'service[term_ids]',
		'label'       => (string) ( $taxonomy['plural_label'] ?? __( 'دسته‌بندی', 'kasebi-erp' ) ),
		'type'        => 'checkbox',
		'class'       => 'col-md-6 kerp-service-form-choice-group',
		'input_class' => 'kerp-service-term-option',
		'options'     => $options,
		'value'       => [],
	];
}

KERP_Helpers_Template::render_modal(
	[
		'id'     => 'appointmentServiceModal',
		'title'  => sprintf(
			__( 'مدیریت %s', 'kasebi-erp' ),
			$settings->get_service_singular_label()
		),
		'action' => 'appointments_save_service',
		'page'   => '/erp/appointments/services/',
		'button' => sprintf(
			__( 'ذخیره %s', 'kasebi-erp' ),
			$settings->get_service_singular_label()
		),
		'size'   => 'xl',
		'fields' => $fields,
	]
);
