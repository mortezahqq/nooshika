<?php

defined( 'ABSPATH' ) || exit;

$settings         = KERP_Modules_Appointments_Settings::instance();
$form_service     = KERP_Modules_Appointments_Form::instance();
$location_types   = $form_service->get_location_type_options();
$service_options  = isset( $service_options ) && is_array( $service_options )
	? $service_options
	: [];
$employee_options = isset( $employee_options ) && is_array( $employee_options )
	? $employee_options
	: [];
$status_options   = isset( $status_options ) && is_array( $status_options )
	? $status_options
	: [];

$fields = [
	[
		'id'    => 'kerp-appointment-id',
		'name'  => 'appointment_id',
		'type'  => 'hidden',
		'value' => '',
	],
	[
		'id'    => 'kerp-appointment-return-page',
		'name'  => 'return_page',
		'type'  => 'hidden',
		'value' => '/erp/appointments/',
	],
	[
		'id'       => 'kerp-appointment-customer-id',
		'name'     => 'customer_id',
		'type'     => 'customer-search',
		'value'    => 0,
		'required' => TRUE,
		'columns'  => 2,
	],
	[
		'id'          => 'kerp-appointment-date',
		'name'        => 'date',
		'label'       => __( 'تاریخ', 'kasebi-erp' ),
		'type'        => 'date',
		'class'       => 'col-md-6',
		'input_class' => 'kerp-appointment-date',
		'value'       => '',
		'required'    => TRUE,
	],
	[
		'id'          => 'kerp-appointment-service',
		'name'        => 'service_id',
		'label'       => $settings->get_service_singular_label(),
		'type'        => 'select',
		'class'       => 'col-md-6',
		'input_class' => 'kerp-appointment-service',
		'options'     => $service_options,
		'value'       => '',
		'placeholder' => __( 'انتخاب کنید', 'kasebi-erp' ),
		'required'    => TRUE,
	],
	[
		'id'          => 'kerp-appointment-employee',
		'name'        => 'employee_id',
		'label'       => $settings->get_provider_singular_label(),
		'type'        => 'select',
		'class'       => 'col-md-6',
		'input_class' => 'kerp-appointment-employee',
		'options'     => $employee_options,
		'value'       => '',
		'placeholder' => __( 'انتخاب کنید', 'kasebi-erp' ),
		'required'    => TRUE,
	],
	[
		'id'          => 'kerp-appointment-time',
		'name'        => 'time',
		'label'       => __( 'ساعت', 'kasebi-erp' ),
		'type'        => 'select',
		'class'       => 'col-md-6',
		'input_class' => 'kerp-appointment-time',
		'options'     => [],
		'value'       => '',
		'placeholder' => sprintf( __( 'ابتدا %1$s، %2$s و تاریخ را انتخاب کنید', 'kasebi-erp' ), $settings->get_service_singular_label(), $settings->get_provider_singular_label() ),
		'required'    => TRUE,
	],
	[
		'id'          => 'kerp-appointment-quantity',
		'name'        => 'quantity',
		'label'       => __( 'تعداد نفرات', 'kasebi-erp' ),
		'type'        => 'number',
		'class'       => 'col-md-4',
		'input_class' => 'number_type',
		'value'       => 1,
	],
	[
		'id'          => 'kerp-appointment-status',
		'name'        => 'status',
		'label'       => __( 'وضعیت', 'kasebi-erp' ),
		'type'        => 'select',
		'class'       => 'col-md-4',
		'options'     => $status_options,
		'value'       => (string) $settings->get( 'default_admin_status', 'confirmed' ),
		'placeholder' => __( 'انتخاب کنید', 'kasebi-erp' ),
	],
	[
		'id'          => 'kerp-appointment-location-type',
		'name'        => 'location_type',
		'label'       => __( 'نوع برگزاری', 'kasebi-erp' ),
		'type'        => 'select',
		'class'       => 'col-md-4',
		'options'     => $location_types,
		'value'       => '',
		'placeholder' => __( 'انتخاب کنید', 'kasebi-erp' ),
	],
	//	[
	//		'id'          => 'kerp-appointment-location',
	//		'name'        => 'location',
	//		'label'       => __( 'محل / لینک برگزاری', 'kasebi-erp' ),
	//		'type'        => 'text',
	//		'class'       => 'col-12',
	//		'input_class' => '',
	//		'value'       => '',
	//	],
	[
		'id'    => 'kerp-appointment-description',
		'name'  => 'description',
		'label' => __( 'توضیحات', 'kasebi-erp' ),
		'type'  => 'textarea',
		'class' => 'col-12',
		'value' => '',
		'rows'  => 3,
	],
	[
		'id'    => 'kerp-appointment-internal-note',
		'name'  => 'internal_note',
		'label' => __( 'یادداشت داخلی', 'kasebi-erp' ),
		'type'  => 'textarea',
		'class' => 'col-12',
		'value' => '',
		'rows'  => 3,
	],
];

KERP_Helpers_Template::render_modal(
	[
		'id'     => 'appointmentModal',
		'title'  => sprintf(
			__( 'ثبت %s', 'kasebi-erp' ),
			$settings->get_appointment_singular_label()
		),
		'action' => 'appointments_save',
		'page'   => '/erp/appointments/',
		'button' => sprintf( __( 'ذخیره %s', 'kasebi-erp' ), $settings->get_appointment_singular_label() ),
		'size'   => 'lg',
		'fields' => $fields,
	]
);
