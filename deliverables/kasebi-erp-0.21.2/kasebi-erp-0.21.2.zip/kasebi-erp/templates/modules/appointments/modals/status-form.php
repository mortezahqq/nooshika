<?php

defined( 'ABSPATH' ) || exit;

$settings       = KERP_Modules_Appointments_Settings::instance();
$status_options = isset( $status_options ) && is_array( $status_options )
	? $status_options
	: $settings->get_status_options( FALSE );

$color_options = [
	'primary'   => __( 'اصلی', 'kasebi-erp' ),
	'secondary' => __( 'ثانویه', 'kasebi-erp' ),
	'success'   => __( 'موفق', 'kasebi-erp' ),
	'info'      => __( 'اطلاعاتی', 'kasebi-erp' ),
	'warning'   => __( 'هشدار', 'kasebi-erp' ),
	'danger'    => __( 'خطر', 'kasebi-erp' ),
	'light'     => __( 'روشن', 'kasebi-erp' ),
	'dark'      => __( 'تیره', 'kasebi-erp' ),
];

$active_tab = 'statuses';

$fields = [
	[
		'id'          => 'kerp-appointment-status-active-tab',
		'name'        => 'active_tab',
		'type'        => 'hidden',
		'input_class' => 'no_clear',
		'value'       => $active_tab,
	],
	[
		'id'    => 'kerp-appointment-status-original-key',
		'name'  => 'original_key',
		'type'  => 'hidden',
		'class' => 'no_clear',
		'value' => '',
	],
	[
		'id'       => 'kerp-appointment-status-key',
		'name'     => 'status[key]',
		'label'    => __( 'کلید', 'kasebi-erp' ),
		'type'     => 'text',
		'class'    => 'col-md-6',
		'value'    => '',
		'required' => TRUE,
	],
	[
		'id'       => 'kerp-appointment-status-label',
		'name'     => 'status[label]',
		'label'    => __( 'عنوان', 'kasebi-erp' ),
		'type'     => 'text',
		'class'    => 'col-md-6',
		'value'    => '',
		'required' => TRUE,
	],
	[
		'id'    => 'kerp-appointment-status-icon',
		'name'  => 'status[icon]',
		'label' => __( 'آیکون', 'kasebi-erp' ),
		'type'  => 'text',
		'class' => 'col-md-4',
		'value' => 'ni ni-clock',
	],
	[
		'id'          => 'kerp-appointment-status-color',
		'name'        => 'status[color]',
		'label'       => __( 'رنگ', 'kasebi-erp' ),
		'type'        => 'select',
		'class'       => 'col-md-4',
		'options'     => $color_options,
		'placeholder' => __( 'انتخاب رنگ', 'kasebi-erp' ),
		'value'       => 'primary',
	],
	[
		'id'    => 'kerp-appointment-status-order',
		'name'  => 'status[order]',
		'label' => __( 'ترتیب', 'kasebi-erp' ),
		'type'  => 'number',
		'class' => 'col-md-4',
		'value' => 10,
	],
	[
		'id'    => 'kerp-appointment-status-active',
		'name'  => 'status[active]',
		'label' => __( 'فعال', 'kasebi-erp' ),
		'type'  => 'switch',
		'class' => 'col-md-4',
		'value' => 1,
	],
	[
		'id'          => 'kerp-appointment-status-allowed-next',
		'name'        => 'status[allowed_next]',
		'label'       => __( 'وضعیت‌های بعدی مجاز', 'kasebi-erp' ),
		'type'        => 'checkbox',
		'class'       => 'col-12',
		'input_class' => 'kerp-status-next-option',
		'options'     => $status_options,
		'value'       => [],
	],
];

KERP_Helpers_Template::render_modal( [
	'id'     => 'appointmentStatusModal',
	'title'  => sprintf( __( 'افزودن یا ویرایش وضعیت %s', 'kasebi-erp' ), $settings->get_appointment_singular_label() ),
	'action' => 'appointments_save_status',
	'page'   => '/erp/appointments/settings/statuses/',
	'button' => __( 'ذخیره وضعیت', 'kasebi-erp' ),
	'size'   => 'lg',
	'fields' => $fields,
] );
