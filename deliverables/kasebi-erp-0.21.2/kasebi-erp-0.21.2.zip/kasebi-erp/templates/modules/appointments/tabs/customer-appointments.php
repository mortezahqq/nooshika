<?php

defined( 'ABSPATH' ) || exit;

if ( ! isset( $customer ) || ! $customer instanceof WP_User ) {
	return;
}
$customer_id  = absint( $customer_id ?? $customer->ID );
$settings           = KERP_Modules_Appointments_Settings::instance();
$customers_settings = KERP_Modules_Customers_Settings::instance();
$return_page  = '/erp/customers/' . $customer_id . '/?tab=appointments';
$result       = KERP_Modules_Appointments_Query::instance()->find(
	[
		'customer_id'   => $customer_id,
		'page_number'   => 1,
		'per_page'      => 100,
		'order'         => 'DESC',
		'enforce_scope' => TRUE,
	]
);
$appointments = (array) ( $result['items'] ?? [] );
$can_create   = kerp_can( 'appointments.create', 'action' );
$add_populate = [
	'appointment_id' => [
		'id'    => '#kerp-appointment-id',
		'type'  => 'text',
		'value' => '',
	],
	'return_page'    => [
		'id'    => '#kerp-appointment-return-page',
		'type'  => 'text',
		'value' => $return_page,
	],
	'customer_id'    => [
		'id'    => '#kerp-appointment-customer-id',
		'type'  => 'customer-search',
		'value' => $customer_id,
	],
];
?>
<div class="kerp-customer-tab-controls">
    <div class="d-lg-none kerp-customer-mobile-nav"><a href="#" class="toggle btn btn-icon btn-trigger" data-target="customerAside" aria-label="<?php esc_attr_e( 'نمایش منوی کاربر', 'kasebi-erp' ); ?>"><em class="ni ni-menu-alt-r icon"></em></a></div>
	<?php if ( $can_create ) : ?>
        <a href="#appointmentModal"
                                              class="btn btn-dim btn-primary btn-icon open_populate_modal kerp-appointment-add-for-customer"
                                              data-modal="#appointmentModal"
                                              data-customer-id="<?php echo esc_attr( $customer_id ); ?>"
                                              data-customer-name="<?php echo esc_attr( get_user_name_by_id( $customer_id ) ); ?>"
                                              data-customer-phone="<?php echo esc_attr( (string) get_user_meta( $customer_id, class_exists( 'KERP_Modules_Customers_Settings' ) ? KERP_Modules_Customers_Settings::instance()
		                                                                                                                                                                                                         ->get( 'phone_meta_key', 'nooshika_phone_num' ) : 'nooshika_phone_num', TRUE ) ); ?>"
                                              data-populate="<?php echo esc_attr( wp_json_encode( $add_populate ) ); ?>"
                                              aria-label="<?php echo esc_attr( sprintf( __( 'ثبت %s', 'kasebi-erp' ), $settings->get_appointment_singular_label() ) ); ?>"><em
                class="ni ni-plus icon"></em></a><?php endif; ?>
</div>
<?php KERP_Helpers_Template::render_template( 'app/components/customer-tab-hero.php', [
	'icon'        => 'ni ni-calendar',
	'eyebrow'     => __( 'زمان‌بندی مشتری', 'kasebi-erp' ),
	'title'       => $settings->get_appointment_plural_label(),
	'description' => sprintf( __( '%1$s ثبت‌شده برای این %2$s', 'kasebi-erp' ), $settings->get_appointment_plural_label(), $customers_settings->get_singular_label() ),
] ); ?>
<div class="nk-block">
	<?php if ( empty( $appointments ) ) : ?>
        <div class="card card-bordered">
        <div
            class="card-inner text-center py-4 text-soft"><?php echo esc_html( sprintf( __( 'برای این %1$s، %2$s ثبت نشده است.', 'kasebi-erp' ), $customers_settings->get_singular_label(), $settings->get_appointment_singular_label() ) ); ?></div>
        </div><?php else : ?>
        <div class="row kerp-appointments-card-grid"><?php foreach ( $appointments as $appointment ) : ?>
            <div
                class="col-xl-6 mb-4"><?php KERP_Helpers_Template::render_template( 'modules/appointments/partials/appointment-card.php', [
				'appointment' => $appointment,
				'return_page' => $return_page,
				'context'     => 'customer',
			] ); ?></div><?php endforeach; ?></div><?php endif; ?>
</div>
