<?php

defined( 'ABSPATH' ) || exit;

if ( ! isset( $employee ) || ! $employee instanceof WP_User ) {
	return;
}
$employee_id = absint( $employee_id ?? $employee->ID );
$settings    = KERP_Modules_Appointments_Settings::instance();
$return_page = '/erp/employees/' . $employee_id . '/?tab=appointments';
$result      = KERP_Modules_Appointments_Query::instance()->find(
	[
		'employee_id' => $employee_id,
		'page_number' => 1,
		'per_page'    => 100,
		'order'       => 'DESC',
	]
);
$appointments = (array) ( $result['items'] ?? [] );
?>
<div class="nk-block nk-block-between">
	<div class="nk-block-head-content align-self-start d-lg-none"><a href="#" class="toggle btn btn-icon btn-trigger mt-n1" data-target="employeeAside"><em class="ni ni-menu-alt-r icon"></em></a></div>
	<div class="nk-block-head"><h6 class="title"><?php echo esc_html( $settings->get_appointment_plural_label() ); ?></h6><p><?php echo esc_html( sprintf( __( '%s مربوط به این %s', 'kasebi-erp' ), $settings->get_appointment_plural_label(), $settings->get_provider_singular_label() ) ); ?></p></div>
</div>
<div class="nk-block">
	<?php if ( empty( $appointments ) ) : ?><div class="card card-bordered"><div class="card-inner text-center py-4 text-soft"><?php echo esc_html( sprintf( __( '%s برای این کارمند ثبت نشده است.', 'kasebi-erp' ), $settings->get_appointment_singular_label() ) ); ?></div></div><?php else : ?><div class="row kerp-appointments-card-grid"><?php foreach ( $appointments as $appointment ) : ?><div class="col-xl-6 mb-4"><?php KERP_Helpers_Template::render_template( 'modules/appointments/partials/appointment-card.php', [ 'appointment' => $appointment, 'return_page' => $return_page, 'context' => 'employee' ] ); ?></div><?php endforeach; ?></div><?php endif; ?>
</div>
