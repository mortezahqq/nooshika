<?php

defined( 'ABSPATH' ) || exit;

/**
 * @var array $service
 */

$service = isset( $service ) && is_array( $service )
	? $service
	: [];

if ( empty( $service ) ) {
	return;
}

$id           = absint( $service['id'] ?? 0 );
$icon         = (string) ( $service['icon'] ?? 'ni ni-calendar-booking' );
$color        = sanitize_key( (string) ( $service['color'] ?? 'primary' ) ) ?: 'primary';
$employee_ids = array_values(
	array_unique(
		array_filter(
			array_map(
				'absint',
				(array) ( $service['employee_ids'] ?? [] )
			)
		)
	)
);
$term_ids     = array_values(
	array_unique(
		array_filter(
			array_map(
				'absint',
				(array) ( $service['term_ids'] ?? [] )
			)
		)
	)
);

$taxonomy_service = KERP_Modules_Appointments_Taxonomies::instance();
$all_terms        = $taxonomy_service->get_terms();
$terms_map        = [];

foreach ( $all_terms as $term ) {
	$term_id = absint( $term['id'] ?? 0 );
	
	if ( $term_id > 0 ) {
		$terms_map[ $term_id ] = $term;
	}
}

$populate = [
	'id'                    => [
		'id'    => '#kerp-appointment-service-id',
		'type'  => 'text',
		'value' => $id,
	],
	'title'                 => [
		'id'    => '#kerp-service-title',
		'type'  => 'text',
		'value' => (string) ( $service['title'] ?? '' ),
	],
	'slug'                  => [
		'id'    => '#kerp-service-slug',
		'type'  => 'text',
		'value' => (string) ( $service['slug'] ?? '' ),
	],
	'description'           => [
		'id'    => '#kerp-service-description',
		'type'  => 'quill',
		'value' => (string) ( $service['description'] ?? '' ),
	],
	'duration'              => [
		'id'    => '#kerp-service-duration',
		'type'  => 'text',
		'value' => absint( $service['duration_min'] ?? 30 ),
	],
	'buffer_before'         => [
		'id'    => '#kerp-service-buffer-before',
		'type'  => 'text',
		'value' => absint( $service['buffer_before_min'] ?? 0 ),
	],
	'buffer_after'          => [
		'id'    => '#kerp-service-buffer-after',
		'type'  => 'text',
		'value' => absint( $service['buffer_after_min'] ?? 0 ),
	],
	'capacity'              => [
		'id'    => '#kerp-service-capacity',
		'type'  => 'text',
		'value' => absint( $service['capacity'] ?? 1 ),
	],
	'price'                 => [
		'id'    => '#kerp-service-price',
		'type'  => 'text',
		'value' => (float) ( $service['price'] ?? 0 ),
	],
	'deposit_type'          => [
		'id'    => '#kerp-service-deposit-type',
		'type'  => 'select',
		'value' => (string) ( $service['deposit_type'] ?? 'none' ),
	],
	'deposit_fixed_value'   => [
		'id'    => '#kerp-service-deposit-fixed-value',
		'type'  => 'text',
		'value' => (float) ( $service['deposit_value'] ?? 0 ),
	],
	'deposit_percent_value' => [
		'id'    => '#kerp-service-deposit-percent-value',
		'type'  => 'text',
		'value' => (float) ( $service['deposit_value'] ?? 0 ),
	],
	'icon'                  => [
		'id'    => '#kerp-service-icon',
		'type'  => 'text',
		'value' => $icon,
	],
	'color'                 => [
		'id'    => '#kerp-service-color',
		'type'  => 'select',
		'value' => $color,
	],
	'order'                 => [
		'id'    => '#kerp-service-order',
		'type'  => 'text',
		'value' => intval( $service['order_index'] ?? 10 ),
	],
	'active'                => [
		'id'    => '#kerp-service-active',
		'type'  => 'checkbox',
		'value' => ! empty( $service['active'] ) ? '1' : '0',
	],
	'public'                => [
		'id'    => '#kerp-service-public',
		'type'  => 'checkbox',
		'value' => ! empty( $service['public_booking'] ) ? '1' : '0',
	],
];

foreach ( KERP_Modules_Appointments_Form::instance()->get_employee_options() as $employee_id => $label ) {
	$employee_id = absint( $employee_id );
	
	if ( $employee_id <= 0 ) {
		continue;
	}
	
	$populate[ 'employee_' . $employee_id ] = [
		'id'    => '#kerp-service-employees_' . $employee_id,
		'type'  => 'checkbox',
		'value' => in_array( $employee_id, $employee_ids, TRUE ) ? '1' : '0',
	];
}

foreach ( $all_terms as $term ) {
	$term_id     = absint( $term['id'] ?? 0 );
	$taxonomy_id = absint( $term['taxonomy_id'] ?? 0 );
	
	if ( $term_id <= 0 || $taxonomy_id <= 0 ) {
		continue;
	}
	
	$populate[ 'term_' . $term_id ] = [
		'id'    => '#kerp-service-taxonomy-' . $taxonomy_id . '_' . $term_id,
		'type'  => 'checkbox',
		'value' => in_array( $term_id, $term_ids, TRUE ) ? '1' : '0',
	];
}

$deposit_type  = sanitize_key( (string) ( $service['deposit_type'] ?? 'none' ) );
$deposit_value = (float) ( $service['deposit_value'] ?? 0 );

$deposit_label = __( 'بدون بیعانه', 'kasebi-erp' );

if ( $deposit_type === 'fixed' ) {
	$deposit_label = sprintf(
		__( 'بیعانه %s', 'kasebi-erp' ),
		number_format_i18n( $deposit_value, 0 )
	);
} elseif ( $deposit_type === 'percent' ) {
	$deposit_label = sprintf(
		__( 'بیعانه %s٪', 'kasebi-erp' ),
		number_format_i18n( $deposit_value, 0 )
	);
} elseif ( $deposit_type === 'full' ) {
	$deposit_label = __( 'پرداخت کامل', 'kasebi-erp' );
}

$buffer_before = absint( $service['buffer_before_min'] ?? 0 );
$buffer_after  = absint( $service['buffer_after_min'] ?? 0 );
?>
<div class="card card-bordered h-100 kerp-service-card">
    <span class="kerp-service-card__accent bg-<?php echo esc_attr( $color ); ?>"></span>

    <div class="card-inner">
        <div class="kerp-service-card__head">
            <div class="kerp-service-card__identity">
				<span
                    class="kerp-service-card__icon bg-<?php echo esc_attr( $color ); ?>-dim text-<?php echo esc_attr( $color ); ?>">
					<em class="<?php echo esc_attr( $icon ); ?> icon"></em>
				</span>

                <div class="kerp-service-card__title-wrap">
                    <h6 class="title mb-1">
						<?php echo esc_html( (string) ( $service['title'] ?? '' ) ); ?>
                    </h6>

                    <div class="kerp-service-card__badges">
						<span
                            class="badge badge-dim <?php echo ! empty( $service['active'] ) ? 'bg-success' : 'bg-light'; ?>">
							<?php
							echo ! empty( $service['active'] )
								? esc_html__( 'فعال', 'kasebi-erp' )
								: esc_html__( 'غیرفعال', 'kasebi-erp' );
							?>
						</span>
						
						<?php if ( ! empty( $service['public_booking'] ) ) : ?>
                            <span class="badge badge-dim bg-info">
								<?php esc_html_e( 'رزرو عمومی', 'kasebi-erp' ); ?>
							</span>
						<?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="dropdown">
                <a href="#"
                   class="btn btn-sm btn-icon btn-trigger dropdown-toggle"
                   data-bs-toggle="dropdown">
                    <em class="ni ni-more-h icon"></em>
                </a>

                <div class="dropdown-menu dropdown-menu-end">
                    <ul class="link-list-opt no-bdr">
                        <li>
                            <a href="#"
                               class="edit_row_item"
                               data-modal="#appointmentServiceModal"
                               data-modal-title="<?php echo esc_attr( sprintf( __( 'ویرایش %s', 'kasebi-erp' ), KERP_Modules_Appointments_Settings::instance()
							                                                                                                                      ->get_service_singular_label() ) ); ?>"
                               data-submit-text="<?php esc_attr_e( 'ذخیره تغییرات', 'kasebi-erp' ); ?>"
                               data-populate="<?php echo esc_attr( wp_json_encode( $populate ) ); ?>">
                                <em class="ni ni-edit icon"></em>
                                <span><?php esc_html_e( 'ویرایش', 'kasebi-erp' ); ?></span>
                            </a>
                        </li>

                        <li class="divider"></li>

                        <li>
                            <a href="#"
                               class="delete_db_item"
                               data-action="appointments_delete_service"
                               data-page="/erp/appointments/services/"
                               data-service_id="<?php echo esc_attr( $id ); ?>"
                               data-item_id="<?php echo esc_attr( $id ); ?>">
                                <em class="ni ni-trash icon"></em>
                                <span><?php esc_html_e( 'حذف', 'kasebi-erp' ); ?></span>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="kerp-service-card__stats">
            <div class="kerp-service-card__stat">
                <em class="ni ni-clock icon"></em>
                <div>
                    <span><?php esc_html_e( 'مدت', 'kasebi-erp' ); ?></span>
                    <strong>
						<?php
						printf(
							esc_html__( '%s دقیقه', 'kasebi-erp' ),
							esc_html( number_format_i18n( absint( $service['duration_min'] ?? 0 ) ) )
						);
						?>
                    </strong>
                </div>
            </div>

            <div class="kerp-service-card__stat">
                <em class="ni ni-users icon"></em>
                <div>
                    <span><?php esc_html_e( 'ظرفیت', 'kasebi-erp' ); ?></span>
                    <strong>
						<?php echo esc_html( number_format_i18n( absint( $service['capacity'] ?? 1 ) ) ); ?>
                    </strong>
                </div>
            </div>

            <div class="kerp-service-card__stat">
                <em class="ni ni-money icon"></em>
                <div>
                    <span><?php esc_html_e( 'قیمت', 'kasebi-erp' ); ?></span>
                    <strong>
						<?php
						$price = (float) ( $service['price'] ?? 0 );
						
						echo $price > 0
							? esc_html( number_format_i18n( $price, 0 ) )
							: esc_html__( 'رایگان', 'kasebi-erp' );
						?>
                    </strong>
                </div>
            </div>

            <div class="kerp-service-card__stat">
                <em class="ni ni-account-setting icon"></em>
                <div>
                    <span><?php esc_html_e( 'ارائه‌دهنده', 'kasebi-erp' ); ?></span>
                    <strong>
						<?php
						echo empty( $employee_ids )
							? esc_html__( 'همه', 'kasebi-erp' )
							: esc_html(
								sprintf(
									__( '%s نفر', 'kasebi-erp' ),
									number_format_i18n( count( $employee_ids ) )
								)
							);
						?>
                    </strong>
                </div>
            </div>
        </div>
		
		<?php if ( trim( (string) ( $service['description'] ?? '' ) ) !== '' ) : ?>
            <div class="kerp-service-card__description">
				<?php echo wp_kses_post( wpautop( (string) $service['description'] ) ); ?>
            </div>
		<?php endif; ?>
		
		<?php if ( ! empty( $term_ids ) ) : ?>
            <div class="kerp-service-card__terms">
				<?php foreach ( $term_ids as $term_id ) : ?>
					<?php
					$term = $terms_map[ $term_id ] ?? [];
					
					if ( empty( $term ) ) {
						continue;
					}
					
					$term_color = sanitize_key( (string) ( $term['color'] ?? 'primary' ) ) ?: 'primary';
					$term_icon  = (string) ( $term['icon'] ?? 'ni ni-tag' );
					?>
                    <span class="badge badge-dim bg-<?php echo esc_attr( $term_color ); ?>">
						<em class="<?php echo esc_attr( $term_icon ); ?> icon"></em>
						<?php echo esc_html( (string) ( $term['name'] ?? '' ) ); ?>
					</span>
				<?php endforeach; ?>
            </div>
		<?php endif; ?>

        <div class="kerp-service-card__footer">
			<span>
				<em class="ni ni-timer icon"></em>
				<?php
				printf(
					esc_html__( 'فاصله قبل/بعد: %1$s / %2$s دقیقه', 'kasebi-erp' ),
					esc_html( number_format_i18n( $buffer_before ) ),
					esc_html( number_format_i18n( $buffer_after ) )
				);
				?>
			</span>

            <span>
				<em class="ni ni-wallet icon"></em>
				<?php echo esc_html( $deposit_label ); ?>
			</span>
        </div>
    </div>
</div>
