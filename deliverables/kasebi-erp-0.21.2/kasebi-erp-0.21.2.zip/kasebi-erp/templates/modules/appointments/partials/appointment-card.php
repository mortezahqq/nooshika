<?php

defined( 'ABSPATH' ) || exit;

/** @var array $appointment */
$appointment = isset( $appointment ) && is_array( $appointment ) ? $appointment : [];

if ( empty( $appointment ) ) {
	return;
}

$id                         = absint( $appointment['id'] ?? 0 );
$service_id                 = absint( $appointment['service_id'] ?? 0 );
$employee_id                = absint( $appointment['employee_id'] ?? 0 );
$customer_id                = absint( $appointment['customer_id'] ?? 0 );
$quantity                   = max( 1, absint( $appointment['quantity'] ?? 1 ) );
$settings                   = KERP_Modules_Appointments_Settings::instance();
$appointment_singular_label = $settings->get_appointment_singular_label();
$appointment_plural_label   = $settings->get_appointment_plural_label();
$service_singular_label     = $settings->get_service_singular_label();
$form_service               = KERP_Modules_Appointments_Form::instance();
$status_key                 = sanitize_key( (string) ( $appointment['status'] ?? '' ) );
$status                     = $settings->get_status( $status_key );
$status_icon                = (string) ( $status['icon'] ?? 'ni ni-clock' );
$status_color               = sanitize_key( (string) ( $status['color'] ?? 'primary' ) ) ?: 'primary';
$service_icon               = (string) ( $appointment['service_icon'] ?? 'ni ni-calendar-booking' );
$service_color              = sanitize_key( (string) ( $appointment['service_color'] ?? 'primary' ) ) ?: 'primary';
$service_title              = trim( (string) ( $appointment['service_title'] ?? '' ) );
$customer_name              = trim( (string) ( $appointment['customer_name'] ?? '' ) );
$customer_phone             = trim( (string) ( $appointment['customer_phone'] ?? '' ) );
$employee_name              = trim( (string) ( $appointment['employee_name'] ?? '' ) );
$description                = trim( (string) ( $appointment['description'] ?? '' ) );
$internal_note              = trim( (string) ( $appointment['internal_note'] ?? '' ) );
$location_type              = sanitize_key( (string) ( $appointment['location_type'] ?? '' ) );
$location                   = trim( (string) ( $appointment['location'] ?? '' ) );
$location_types             = $form_service->get_location_type_options();
$location_label             = (string) ( $location_types[ $location_type ] ?? '' );
$source                     = sanitize_key( (string) ( $appointment['source'] ?? 'admin' ) ) ?: 'admin';
$source_labels              = [
	'admin'    => __( 'پنل مدیریت', 'kasebi-erp' ),
	'employee' => __( 'کارمند', 'kasebi-erp' ),
	'public'   => __( 'رزرو عمومی', 'kasebi-erp' ),
	'api'      => __( 'API', 'kasebi-erp' ),
];
$source_label               = (string) ( $source_labels[ $source ] ?? $source );
$return_page                = isset( $return_page ) && is_string( $return_page ) && str_starts_with( $return_page, '/erp/' )
	? $return_page
	: '/erp/appointments/';

$start_at     = trim( (string) ( $appointment['start_at'] ?? '' ) );
$end_at       = trim( (string) ( $appointment['end_at'] ?? '' ) );
$date_value   = preg_match( '/^\d{4}-\d{2}-\d{2}/', $start_at ) === 1 ? substr( $start_at, 0, 10 ) : '';
$time_value   = preg_match( '/^\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}/', $start_at ) === 1 ? substr( $start_at, 11, 5 ) : '';
$end_time     = preg_match( '/^\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}/', $end_at ) === 1 ? substr( $end_at, 11, 5 ) : '';
$display_date = $date_value !== '' ? KERP_Helpers_Date::gregorian_to_jalali( $date_value ) : '';

$can_edit          = kerp_can( 'appointments.edit', 'action' );
$can_change_status = kerp_can( 'appointments.status.change', 'action' );

$populate = [
	'appointment_id' => [
		'id'    => '#kerp-appointment-id',
		'type'  => 'text',
		'value' => $id,
	],
	'return_page'    => [
		'id'    => '#kerp-appointment-return-page',
		'type'  => 'text',
		'value' => $return_page,
	],
	'customer_id'    => [
		'id'    => '#kerp-appointment-customer-id',
		'type'  => 'customer-search',
		'value' => $customer_id,
		'data'  => [
			'customer-name'  => $customer_name,
			'customer-phone' => $customer_phone,
		],
	],
	'service'        => [
		'id'    => '#kerp-appointment-service',
		'type'  => 'select',
		'value' => $service_id,
		'data'  => [
			'employee' => $employee_id,
		],
	],
	'employee'       => [
		'id'    => '#kerp-appointment-employee',
		'type'  => 'select',
		'value' => $employee_id,
	],
	'date'           => [
		'id'    => '#kerp-appointment-date',
		'type'  => 'text',
		'value' => KERP_Helpers_Date::gregorian_to_jalali( $date_value ),
		'data'  => [
			'time' => $time_value,
		],
	],
	'quantity'       => [
		'id'    => '#kerp-appointment-quantity',
		'type'  => 'text',
		'value' => $quantity,
	],
	'status'         => [
		'id'    => '#kerp-appointment-status',
		'type'  => 'select',
		'value' => $status_key,
	],
	'location_type'  => [
		'id'    => '#kerp-appointment-location-type',
		'type'  => 'select',
		'value' => $location_type,
	],
	'location'       => [
		'id'    => '#kerp-appointment-location',
		'type'  => 'text',
		'value' => $location,
	],
	'description'    => [
		'id'    => '#kerp-appointment-description',
		'type'  => 'text',
		'value' => $description,
	],
	'internal_note'  => [
		'id'    => '#kerp-appointment-internal-note',
		'type'  => 'text',
		'value' => $internal_note,
	],
];

$note_populate = [
	'appointment_id' => [
		'id'    => '#kerp-appointment-note-id',
		'type'  => 'text',
		'value' => $id,
	],
	'return_page'    => [
		'id'    => '#kerp-appointment-note-return-page',
		'type'  => 'text',
		'value' => $return_page,
	],
	'note'           => [
		'id'    => '#kerp-appointment-quick-note',
		'type'  => 'text',
		'value' => $internal_note,
	],
];

$allowed_next  = isset( $status['allowed_next'] ) && is_array( $status['allowed_next'] )
	? array_values( array_unique( array_filter( array_map( 'sanitize_key', $status['allowed_next'] ) ) ) )
	: [];
$next_statuses = [];

foreach ( $allowed_next as $next_key ) {
	$next = $settings->get_status( $next_key );
	
	if ( $next_key === $status_key || empty( $next ) || empty( $next['active'] ) ) {
		continue;
	}
	
	$next_statuses[ $next_key ] = $next;
}

$preferred_next_map = [
	'held'            => [ 'confirmed', 'pending_payment' ],
	'pending_payment' => [ 'confirmed' ],
	'pending'         => [ 'confirmed' ],
	'confirmed'       => [ 'completed' ],
];
$recommended_key    = '';

foreach ( (array) ( $preferred_next_map[ $status_key ] ?? [] ) as $preferred_key ) {
	if ( isset( $next_statuses[ $preferred_key ] ) ) {
		$recommended_key = $preferred_key;
		break;
	}
}

if ( $recommended_key === '' ) {
	foreach ( $next_statuses as $next_key => $next ) {
		$next_color = sanitize_key( (string) ( $next['color'] ?? 'primary' ) );
		
		if ( ! in_array( $next_color, [ 'danger', 'light' ], TRUE ) ) {
			$recommended_key = $next_key;
			break;
		}
	}
}

if ( $recommended_key === '' && ! empty( $next_statuses ) ) {
	$recommended_key = (string) array_key_first( $next_statuses );
}

$recommended_status = $recommended_key !== '' ? (array) ( $next_statuses[ $recommended_key ] ?? [] ) : [];
$other_statuses     = $next_statuses;
if ( $recommended_key !== '' ) {
	unset( $other_statuses[ $recommended_key ] );
}
$customers_settings      = KERP_Modules_Customers_Settings::instance();
$customer_singular_label = $customers_settings->get_singular_label();

$customer_profile_url = $customer_id > 0
	? '/erp/customers/' . $customer_id . '/'
	: '';

$customer_appointments_url = $customer_id > 0
	? '/erp/customers/' . $customer_id . '/?tab=appointments'
	: '';
?>
<div class="card card-bordered kerp-appointment-card">
    <div class="kerp-appointment-card__accent bg-<?php echo esc_attr( $service_color ); ?>"></div>
    <div class="card-inner kerp-appointment-card__inner">
        <div class="kerp-appointment-card__head">
            <div class="kerp-appointment-card__identity">
				<span
                    class="user-avatar md bg-<?php echo esc_attr( $service_color ); ?>-dim text-<?php echo esc_attr( $service_color ); ?> kerp-appointment-card__service-icon">
					<em class="<?php echo esc_attr( $service_icon ); ?>"></em>
				</span>
                <div class="kerp-appointment-card__identity-content">
                    <h6 class="title">
						<?php
						echo esc_html(
							$service_title !== ''
								? $service_title
								: sprintf( __( '%1$s #%2$s', 'kasebi-erp' ), $service_singular_label, $service_id )
						);
						?>
                    </h6>
                    <div class="kerp-appointment-card__subhead">
                        <span>#<?php echo esc_html( number_format_i18n( $id ) ); ?></span>
                        <span><?php echo esc_html( $source_label ); ?></span>
                    </div>
                </div>
            </div>
			
			<?php if ( $can_edit ) : ?>
                <div class="dropdown">
                    <a href="#"
                       class="btn btn-sm btn-icon btn-trigger dropdown-toggle"
                       data-bs-toggle="dropdown">
                        <em class="icon ni ni-more-h"></em>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end">
                        <ul class="link-list-opt no-bdr">
                            <li>
                                <a href="#"
                                   class="edit_row_item kerp-edit-appointment"
                                   data-modal="#appointmentModal"
                                   data-populate="<?php echo esc_attr( wp_json_encode( $populate ) ); ?>">
                                    <em class="icon ni ni-edit"></em>
                                    <span><?php echo esc_html( sprintf( __( 'ویرایش %s', 'kasebi-erp' ), $appointment_singular_label ) ); ?></span>
                                </a>
                            </li>

                            <li>
                                <a href="#appointmentNoteModal"
                                   class="open_populate_modal"
                                   data-modal="#appointmentNoteModal"
                                   data-populate="<?php echo esc_attr( wp_json_encode( $note_populate ) ); ?>">
                                    <em class="icon ni ni-notes"></em>
                                    <span><?php
										echo esc_html(
											$internal_note === ''
												? __( 'افزودن یادداشت', 'kasebi-erp' )
												: __( 'ویرایش یادداشت', 'kasebi-erp' )
										);
										?></span>
                                </a>
                            </li>
							<?php if ( $customer_id > 0 ) : ?>
                                <li class="divider"></li>
                                <li>
                                    <a href="<?php echo esc_url( $customer_profile_url ); ?>"
                                       class="page_activator"
                                       data-url="<?php echo esc_attr( $customer_profile_url ); ?>">
                                        <em class="icon ni ni-user"></em>
                                        <span><?php
											printf(
												esc_html__( 'پروفایل %s', 'kasebi-erp' ),
												esc_html( $customer_singular_label )
											);
											?></span>
                                    </a>
                                </li>

                                <li>
                                    <a href="<?php echo esc_url( $customer_appointments_url ); ?>"
                                       class="page_activator"
                                       data-url="<?php echo esc_attr( $customer_appointments_url ); ?>">
                                        <em class="icon ni ni-history"></em>
                                        <span><?php
											printf( esc_html__( 'سوابق %s', 'kasebi-erp' ), esc_html( $appointment_plural_label ) ); ?></span>
                                    </a>
                                </li>
							<?php endif; ?>
                        </ul>
                    </div>
                </div>
			<?php endif; ?>
        </div>

        <div class="kerp-appointment-card__schedule">
            <div class="kerp-appointment-card__date">
                <em class="icon ni ni-calendar"></em>
                <div>
                    <span><?php esc_html_e( 'تاریخ', 'kasebi-erp' ); ?></span>
                    <strong><?php echo esc_html( $display_date !== '' ? $display_date : '-' ); ?></strong>
                </div>
            </div>
            <div class="kerp-appointment-card__time">
                <em class="icon ni ni-clock"></em>
                <div>
                    <span><?php esc_html_e( 'ساعت', 'kasebi-erp' ); ?></span>
                    <strong dir="ltr">
						<?php echo esc_html( $time_value !== '' ? $time_value : '-' ); ?>
						<?php if ( $end_time !== '' ) : ?>
                            <span>–</span>
							<?php echo esc_html( $end_time ); ?>
						<?php endif; ?>
                    </strong>
                </div>
            </div>
        </div>

        <div class="kerp-appointment-card__status-row">
			<span class="badge badge-dim bg-<?php echo esc_attr( $status_color ); ?> kerp-appointment-card__status">
				<em class="<?php echo esc_attr( $status_icon ); ?> icon"></em>
				<?php echo esc_html( (string) ( $status['label'] ?? $status_key ) ); ?>
			</span>
			
			<?php if ( $can_change_status && ! empty( $recommended_status ) ) : ?>
                <div class="kerp-appointment-card__status-actions">
					<?php
					$recommended_color = sanitize_key( (string) ( $recommended_status['color'] ?? 'primary' ) ) ?: 'primary';
					$recommended_icon  = (string) ( $recommended_status['icon'] ?? 'ni ni-check' );
					?>
                    <a href="#"
                       class="btn btn-sm btn-outline-<?php echo esc_attr( $recommended_color ); ?> row_inline_action"
                       data-action="appointments_change_status"
                       data-item-id="<?php echo esc_attr( $id ); ?>"
                       data-appointment_id="<?php echo esc_attr( $id ); ?>"
                       data-status="<?php echo esc_attr( $recommended_key ); ?>"
                       data-page="<?php echo esc_attr( $return_page ); ?>"
                       data-return_page="<?php echo esc_attr( $return_page ); ?>"
                       data-needs="[]"
                       data-swal-title="<?php
					   echo esc_attr(
						   sprintf(
							   __( 'وضعیت این %1$s به «%2$s» تغییر کند؟', 'kasebi-erp' ),
							   $appointment_singular_label,
							   (string) ( $recommended_status['label'] ?? $recommended_key )
						   )
					   );
					   ?>">
                        <em class="<?php echo esc_attr( $recommended_icon ); ?> icon"></em>
                        <span><?php echo esc_html( (string) ( $recommended_status['label'] ?? $recommended_key ) ); ?></span>
                    </a>
					<?php if ( ! empty( $other_statuses ) ) : ?>
                        <div class="dropdown">
                            <button type="button"
                                    class="btn btn-sm btn-icon btn-light dropdown-toggle"
                                    data-bs-toggle="dropdown"
                                    aria-expanded="false"
                                    aria-label="<?php esc_attr_e( 'سایر وضعیت‌ها', 'kasebi-erp' ); ?>">
                                <em class="icon ni ni-chevron-down"></em>
                            </button>

                            <div class="dropdown-menu dropdown-menu-end">
                                <ul class="link-list-opt no-bdr">
									<?php
									$danger_started = FALSE;
									$index          = 0;
									
									foreach ( $other_statuses as $next_key => $next ) :
										$next_icon = (string) ( $next['icon'] ?? 'ni ni-check' );
										$next_color = sanitize_key(
											(string) ( $next['color'] ?? 'primary' )
										) ?: 'primary';
										
										$is_danger = $next_color === 'danger' || in_array(
												$next_key,
												[
													'cancelled',
													'no_show',
												],
												TRUE
											);
										
										if ( $is_danger && ! $danger_started && $index > 0 ) :
											?>
                                            <li class="divider"></li>
										<?php
										endif;
										
										if ( $is_danger ) {
											$danger_started = TRUE;
										}
										
										$status_label = (string) ( $next['label'] ?? $next_key );
										?>

                                        <li>
                                            <a href="#"
                                               class="row_inline_action<?php echo $is_danger ? ' text-danger' : ''; ?>"
                                               data-action="appointments_change_status"
                                               data-item-id="<?php echo esc_attr( $id ); ?>"
                                               data-appointment_id="<?php echo esc_attr( $id ); ?>"
                                               data-status="<?php echo esc_attr( $next_key ); ?>"
                                               data-page="<?php echo esc_attr( $return_page ); ?>"
                                               data-return_page="<?php echo esc_attr( $return_page ); ?>"
                                               data-needs="[]"
                                               data-swal-title="<?php
											   echo esc_attr(
												   sprintf(
													   __( 'وضعیت این %1$s به «%2$s» تغییر کند؟', 'kasebi-erp' ),
													   $appointment_singular_label,
													   $status_label
												   )
											   );
											   ?>">
                                                <em class="<?php echo esc_attr( $next_icon ); ?> icon"></em>
                                                <span><?php echo esc_html( $status_label ); ?></span>
                                            </a>
                                        </li>
										
										<?php
										$index ++;
									endforeach;
									?>
                                </ul>
                            </div>
                        </div>
					<?php endif; ?>                </div>
			<?php endif; ?>
        </div>

        <div class="kerp-appointment-card__people">
            <div class="kerp-appointment-card__person">
                <em class="icon ni ni-user"></em>
                <div>
                    <span><?php echo esc_html( $customer_singular_label ); ?></span>
                    <strong><?php echo esc_html( $customer_name !== '' ? $customer_name : __( 'مهمان', 'kasebi-erp' ) ); ?></strong>
					<?php if ( $customer_phone !== '' ) : ?>
                        <small dir="ltr"><?php echo esc_html( $customer_phone ); ?></small>
					<?php endif; ?>
                </div>
            </div>
			
			<?php if ( $employee_id > 0 || $employee_name !== '' ) : ?>
                <div class="kerp-appointment-card__person">
                    <em class="icon ni ni-account-setting"></em>
                    <div>
                        <span><?php echo esc_html( $settings->get_provider_singular_label() ); ?></span>
                        <strong><?php echo esc_html( $employee_name !== '' ? $employee_name : '-' ); ?></strong>
                    </div>
                </div>
			<?php endif; ?>
			
			<?php if ( $quantity > 1 ) : ?>
                <div class="kerp-appointment-card__person kerp-appointment-card__quantity">
                    <em class="icon ni ni-users"></em>
                    <div>
                        <span><?php esc_html_e( 'تعداد', 'kasebi-erp' ); ?></span>
                        <strong><?php echo esc_html( number_format_i18n( $quantity ) ); ?></strong>
                    </div>
                </div>
			<?php endif; ?>
        </div>
		
		<?php if ( $location_type !== '' || $location !== '' ) : ?>
            <div class="kerp-appointment-card__detail kerp-appointment-card__location">
                <div class="kerp-appointment-card__detail-icon">
                    <em class="icon ni ni-map-pin"></em>
                </div>
                <div class="kerp-appointment-card__detail-content">
                    <div class="kerp-appointment-card__detail-title">
                        <span><?php esc_html_e( 'شیوه برگزاری', 'kasebi-erp' ); ?></span>
						<?php if ( $location_label !== '' ) : ?>
                            <span class="badge badge-dim bg-light"><?php echo esc_html( $location_label ); ?></span>
						<?php endif; ?>
                    </div>
					<?php if ( $location !== '' ) : ?>
                        <p><?php echo nl2br( esc_html( $location ) ); ?></p>
					<?php endif; ?>
                </div>
            </div>
		<?php endif; ?>
		
		<?php foreach ( KERP_Modules_Appointments_Public_Fields::instance()->get_display_values( (array) ( $appointment['metadata'] ?? [] ) ) as $public_field ) : ?>
            <div class="kerp-appointment-card__detail kerp-appointment-card__public-field">
                <div class="kerp-appointment-card__detail-icon"><em class="icon ni ni-list"></em></div>
                <div class="kerp-appointment-card__detail-content">
                    <div class="kerp-appointment-card__detail-title"><span class="text-break"><?php echo esc_html( $public_field['label'] ); ?></span></div>
                    <div class="kerp-appointment-card__richtext text-break" style="white-space: pre-wrap; overflow-wrap: anywhere;"><?php echo esc_html( $public_field['value'] ); ?></div>
                </div>
            </div>
		<?php endforeach; ?>
		<?php if ( $description !== '' ) : ?>
            <div class="kerp-appointment-card__detail kerp-appointment-card__description">
                <div class="kerp-appointment-card__detail-icon">
                    <em class="icon ni ni-text"></em>
                </div>
                <div class="kerp-appointment-card__detail-content">
                    <div class="kerp-appointment-card__detail-title">
                        <span><?php esc_html_e( 'توضیحات', 'kasebi-erp' ); ?></span>
                    </div>
                    <div class="kerp-appointment-card__richtext">
						<?php echo wp_kses_post( wpautop( $description ) ); ?>
                    </div>
                </div>
            </div>
		<?php endif; ?>

        <div class="kerp-appointment-card__note<?php echo $internal_note === '' ? ' is-empty' : ''; ?>">
            <div class="kerp-appointment-card__detail-icon">
                <em class="icon ni ni-notes"></em>
            </div>
            <div class="kerp-appointment-card__detail-content">
                <div class="kerp-appointment-card__detail-title">
                    <span><?php esc_html_e( 'یادداشت داخلی', 'kasebi-erp' ); ?></span>
					<?php if ( $can_edit ) : ?>
                        <a href="#appointmentNoteModal"
                           class="open_populate_modal kerp-appointment-card__note-action"
                           data-modal="#appointmentNoteModal"
                           data-populate="<?php echo esc_attr( wp_json_encode( $note_populate ) ); ?>">
                            <em class="icon ni ni-edit-alt"></em>
                            <span><?php echo esc_html( $internal_note === '' ? __( 'افزودن', 'kasebi-erp' ) : __( 'ویرایش', 'kasebi-erp' ) ); ?></span>
                        </a>
					<?php endif; ?>
                </div>
				
				<?php if ( $internal_note !== '' ) : ?>
                    <div class="kerp-appointment-card__richtext">
						<?php echo wp_kses_post( wpautop( $internal_note ) ); ?>
                    </div>
				<?php else : ?>
                    <p class="kerp-appointment-card__empty-note"><?php echo esc_html( sprintf( __( 'یادداشتی برای این %s ثبت نشده است.', 'kasebi-erp' ), $appointment_singular_label ) ); ?></p>
				<?php endif; ?>
            </div>
        </div>
    </div>
</div>
