<?php

defined( 'ABSPATH' ) || exit;

$page_context      = isset( $page_context ) && is_array( $page_context ) ? $page_context : [];
$page_query        = isset( $page_context['query'] ) && is_array( $page_context['query'] ) ? $page_context['query'] : [];
$page_route        = '/erp/appointments/schedules/';
$schedules_service = KERP_Modules_Appointments_Schedules::instance();
$form_service      = KERP_Modules_Appointments_Form::instance();
$services_service  = KERP_Modules_Appointments_Services::instance();
$settings          = KERP_Modules_Appointments_Settings::instance();
$employee_options  = $form_service->get_employee_options();
$service_options   = $services_service->get_options( FALSE );
$weekday_options   = $schedules_service->get_weekday_options();

$active_tab = sanitize_key(
	(string) ( $page_query['active_tab'] ?? 'schedules' )
);

if ( ! in_array( $active_tab, [ 'schedules', 'exceptions' ], TRUE ) ) {
	$active_tab = 'schedules';
}

$employee_id = absint(
	$page_query['employee_id'] ?? 0
);

$service_id = isset( $page_query['service_id'] ) && (string) $page_query['service_id'] !== ''
	? absint( $page_query['service_id'] )
	: '';

$query_args = [
	'employee_id' => $employee_id,
	'service_id'  => $service_id,
	'active'      => '',
];

$schedules  = $schedules_service->get_schedules( $query_args );
$exceptions = $schedules_service->get_exceptions( $query_args );

$has_filter = $employee_id > 0 || $service_id !== '';

$filter_fields = [
	[
		'id'    => 'kerp-appointments-schedules-filter-active-tab',
		'name'  => 'active_tab',
		'type'  => 'hidden',
		'value' => $active_tab,
	],
	[
		'id'          => 'kerp-appointments-schedules-filter-employee',
		'name'        => 'employee_id',
		'label'       => $settings->get_provider_singular_label(),
		'type'        => 'select',
		'placeholder' => sprintf( __( 'همه %s', 'kasebi-erp' ), $settings->get_provider_plural_label() ),
		'options'     => $employee_options,
		'value'       => $employee_id > 0 ? $employee_id : '',
		'col'         => 6,
	],
	[
		'id'          => 'kerp-appointments-schedules-filter-service',
		'name'        => 'service_id',
		'label'       => $settings->get_service_singular_label(),
		'type'        => 'select',
		'placeholder' => sprintf( __( 'همه %s', 'kasebi-erp' ), $settings->get_service_plural_label() ),
		'options'     => [
			                 '0' => sprintf( __( 'برنامه عمومی همه %s', 'kasebi-erp' ), $settings->get_service_plural_label() ),
		                 ] + $service_options,
		'value'       => $service_id,
		'col'         => 6,
	],
];

$filter_page = add_query_arg(
	[
		'active_tab' => $active_tab,
	],
	$page_route
);

$schedules_tab_url = add_query_arg(
	[
		'active_tab' => 'schedules',
	],
	$page_route
);

$exceptions_tab_url = add_query_arg(
	[
		'active_tab' => 'exceptions',
	],
	$page_route
);

if ( $employee_id > 0 ) {
	$schedules_tab_url  = add_query_arg( 'employee_id', $employee_id, $schedules_tab_url );
	$exceptions_tab_url = add_query_arg( 'employee_id', $employee_id, $exceptions_tab_url );
}

if ( $service_id !== '' ) {
	$schedules_tab_url  = add_query_arg( 'service_id', $service_id, $schedules_tab_url );
	$exceptions_tab_url = add_query_arg( 'service_id', $service_id, $exceptions_tab_url );
}

$add_schedule = [
	'active_tab'         => [
		'id'    => '#kerp-appointment-schedule-active-tab',
		'type'  => 'text',
		'value' => 'schedules',
	],
	'filter_employee_id' => [
		'id'    => '#kerp-appointment-schedule-filter-employee-id',
		'type'  => 'text',
		'value' => $employee_id,
	],
	'filter_service_id'  => [
		'id'    => '#kerp-appointment-schedule-filter-service-id',
		'type'  => 'text',
		'value' => $service_id,
	],
	'id'                 => [
		'id'    => '#kerp-appointment-schedule-id',
		'type'  => 'text',
		'value' => '',
	],
	'employee'           => [
		'id'    => '#kerp-appointment-schedule-employee',
		'type'  => 'select',
		'value' => $employee_id,
	],
	'service'            => [
		'id'    => '#kerp-appointment-schedule-service',
		'type'  => 'select',
		'value' => $service_id === '' ? 0 : $service_id,
	],
	'weekday'            => [
		'id'    => '#kerp-appointment-schedule-weekday',
		'type'  => 'select',
		'value' => 0,
	],
	'start'              => [
		'id'    => '#kerp-appointment-schedule-start',
		'type'  => 'text',
		'value' => '09:00',
	],
	'end'                => [
		'id'    => '#kerp-appointment-schedule-end',
		'type'  => 'text',
		'value' => '17:00',
	],
	'interval'           => [
		'id'    => '#kerp-appointment-schedule-interval',
		'type'  => 'text',
		'value' => 0,
	],
	'capacity'           => [
		'id'    => '#kerp-appointment-schedule-capacity',
		'type'  => 'text',
		'value' => 0,
	],
	'order'              => [
		'id'    => '#kerp-appointment-schedule-order',
		'type'  => 'text',
		'value' => 10,
	],
	'active'             => [
		'id'    => '#kerp-appointment-schedule-active',
		'type'  => 'checkbox',
		'value' => '1',
	],
];

$add_exception = [
	'active_tab'         => [
		'id'    => '#kerp-appointment-exception-active-tab',
		'type'  => 'text',
		'value' => 'exceptions',
	],
	'filter_employee_id' => [
		'id'    => '#kerp-appointment-exception-filter-employee-id',
		'type'  => 'text',
		'value' => $employee_id,
	],
	'filter_service_id'  => [
		'id'    => '#kerp-appointment-exception-filter-service-id',
		'type'  => 'text',
		'value' => $service_id,
	],
	'id'                 => [
		'id'    => '#kerp-appointment-exception-id',
		'type'  => 'text',
		'value' => '',
	],
	'employee'           => [
		'id'    => '#kerp-appointment-exception-employee',
		'type'  => 'select',
		'value' => $employee_id,
	],
	'service'            => [
		'id'    => '#kerp-appointment-exception-service',
		'type'  => 'select',
		'value' => $service_id === '' ? 0 : $service_id,
	],
	'date'               => [
		'id'    => '#kerp-appointment-exception-date',
		'type'  => 'text',
		'value' => '',
	],
	'type'               => [
		'id'    => '#kerp-appointment-exception-type',
		'type'  => 'select',
		'value' => 'closed',
	],
	'start'              => [
		'id'    => '#kerp-appointment-exception-start',
		'type'  => 'text',
		'value' => '',
	],
	'end'                => [
		'id'    => '#kerp-appointment-exception-end',
		'type'  => 'text',
		'value' => '',
	],
	'capacity'           => [
		'id'    => '#kerp-appointment-exception-capacity',
		'type'  => 'text',
		'value' => 0,
	],
	'note'               => [
		'id'    => '#kerp-appointment-exception-note',
		'type'  => 'text',
		'value' => '',
	],
	'active'             => [
		'id'    => '#kerp-appointment-exception-active',
		'type'  => 'checkbox',
		'value' => '1',
	],
];
?>
<div class="nk-block-head nk-block-head-sm">
    <div class="nk-block-between">
        <div class="nk-block-head-content">
            <h3 class="nk-block-title page-title"><?php esc_html_e( 'برنامه کاری', 'kasebi-erp' ); ?></h3>
            <div class="nk-block-des text-soft">
                <p><?php echo esc_html( sprintf( __( 'ساعات قابل رزرو %s و استثناهای روزانه را مشخص کنید.', 'kasebi-erp' ), $settings->get_provider_plural_label() ) ); ?></p>
            </div>
        </div>
        <div class="nk-block-head-content">
			<?php if ( $active_tab === 'exceptions' ) : ?>
                <a href="#"
                   class="btn btn-primary open_populate_modal"
                   data-modal="#appointmentExceptionModal"
                   data-modal-title="<?php esc_attr_e( 'افزودن استثنا', 'kasebi-erp' ); ?>"
                   data-submit-text="<?php esc_attr_e( 'ذخیره استثنا', 'kasebi-erp' ); ?>"
                   data-populate="<?php echo esc_attr( wp_json_encode( $add_exception ) ); ?>">
                    <em class="kik fa-calendar-minus-02 icon"></em>
                    <span><?php esc_html_e( 'افزودن استثنا', 'kasebi-erp' ); ?></span>
                </a>
			<?php else : ?>
                <a href="#"
                   class="btn btn-primary open_populate_modal"
                   data-modal="#appointmentScheduleModal"
                   data-modal-title="<?php esc_attr_e( 'افزودن برنامه کاری', 'kasebi-erp' ); ?>"
                   data-submit-text="<?php esc_attr_e( 'ذخیره برنامه', 'kasebi-erp' ); ?>"
                   data-populate="<?php echo esc_attr( wp_json_encode( $add_schedule ) ); ?>">
                    <em class="ni ni-plus icon"></em>
                    <span><?php esc_html_e( 'افزودن برنامه', 'kasebi-erp' ); ?></span>
                </a>
			<?php endif; ?>
        </div>
    </div>
</div>

<div class="nk-block">
    <div class="kerp-appointments-view-tabs">
        <a href="<?php echo esc_url( home_url( $schedules_tab_url ) ); ?>"
           class="kerp-appointments-view-tab page_activator<?php echo $active_tab === 'schedules' ? ' active' : ''; ?>"
           data-url="<?php echo esc_attr( $schedules_tab_url ); ?>">
			<span class="kerp-appointments-view-tab-icon">
				<em class="kik fa-calendar-date icon"></em>
			</span>
            <span class="kerp-appointments-view-tab-content">
				<strong><?php esc_html_e( 'برنامه‌های هفتگی', 'kasebi-erp' ); ?></strong>
				<small><?php esc_html_e( 'ساعات و ظرفیت عادی هر هفته', 'kasebi-erp' ); ?></small>
			</span>
            <span class="kerp-appointments-view-tab-count">
				<?php echo esc_html( number_format_i18n( count( $schedules ) ) ); ?>
			</span>
        </a>

        <a href="<?php echo esc_url( home_url( $exceptions_tab_url ) ); ?>"
           class="kerp-appointments-view-tab page_activator<?php echo $active_tab === 'exceptions' ? ' active' : ''; ?>"
           data-url="<?php echo esc_attr( $exceptions_tab_url ); ?>">
			<span class="kerp-appointments-view-tab-icon">
				<em class="kik fa-calendar-minus-02 icon"></em>
			</span>
            <span class="kerp-appointments-view-tab-content">
				<strong><?php esc_html_e( 'استثناها', 'kasebi-erp' ); ?></strong>
				<small><?php esc_html_e( 'تعطیلی، مرخصی و برنامه جایگزین', 'kasebi-erp' ); ?></small>
			</span>
            <span class="kerp-appointments-view-tab-count">
				<?php echo esc_html( number_format_i18n( count( $exceptions ) ) ); ?>
			</span>
        </a>
    </div>
</div>

<div class="nk-block">
    <div class="card card-bordered">
        <div class="card-inner position-relative card-tools-toggle">
            <div class="card-title-group">
                <div class="card-title">
					<?php if ( $active_tab === 'exceptions' ) : ?>
                        <h5 class="title mb-1"><?php esc_html_e( 'استثناهای برنامه کاری', 'kasebi-erp' ); ?></h5>
                        <p class="text-soft mb-0"><?php esc_html_e( 'تغییرات موردی برنامه برای تاریخ‌های مشخص.', 'kasebi-erp' ); ?></p>
					<?php else : ?>
                        <h5 class="title mb-1"><?php esc_html_e( 'برنامه‌های هفتگی', 'kasebi-erp' ); ?></h5>
                        <p class="text-soft mb-0"><?php esc_html_e( 'برای هر روز می‌توانید چند بازه زمانی جدا ثبت کنید.', 'kasebi-erp' ); ?></p>
					<?php endif; ?>
                </div>
                <div class="card-tools">
					<?php
					echo KERP_Helpers_Template::get_template(
						'app/components/list/filter-dropdown.php',
						[
							'has_filter'    => $has_filter,
							'filter_fields' => $filter_fields,
							'action'        => 'erp_request_page_content',
							'page'          => $filter_page,
							'title'         => __( 'فیلتر برنامه کاری', 'kasebi-erp' ),
						]
					);
					?>
                </div>
            </div>
        </div>

        <div class="card-inner border-top">
			<?php if ( $active_tab === 'schedules' ) : ?>
				<?php if ( empty( $schedules ) ) : ?>
                    <div class="text-center text-soft py-4">
						<?php esc_html_e( 'برنامه کاری‌ای با این فیلترها ثبت نشده است.', 'kasebi-erp' ); ?>
                    </div>
				<?php else : ?>
                    <div class="row kerp-appointments-schedule-grid">
						<?php foreach ( $schedules as $schedule ) : ?>
							<?php
							$id                   = absint( $schedule['id'] ?? 0 );
							$schedule_employee_id = absint( $schedule['employee_id'] ?? 0 );
							$schedule_service_id  = absint( $schedule['service_id'] ?? 0 );
							$weekday              = absint( $schedule['weekday'] ?? 0 );
							
							$populate = [
								'active_tab'         => [
									'id'    => '#kerp-appointment-schedule-active-tab',
									'type'  => 'text',
									'value' => 'schedules',
								],
								'filter_employee_id' => [
									'id'    => '#kerp-appointment-schedule-filter-employee-id',
									'type'  => 'text',
									'value' => $employee_id,
								],
								'filter_service_id'  => [
									'id'    => '#kerp-appointment-schedule-filter-service-id',
									'type'  => 'text',
									'value' => $service_id,
								],
								'id'                 => [
									'id'    => '#kerp-appointment-schedule-id',
									'type'  => 'text',
									'value' => $id,
								],
								'employee'           => [
									'id'    => '#kerp-appointment-schedule-employee',
									'type'  => 'select',
									'value' => $schedule_employee_id,
								],
								'service'            => [
									'id'    => '#kerp-appointment-schedule-service',
									'type'  => 'select',
									'value' => $schedule_service_id,
								],
								'weekday'            => [
									'id'    => '#kerp-appointment-schedule-weekday',
									'type'  => 'select',
									'value' => $weekday,
								],
								'start'              => [
									'id'    => '#kerp-appointment-schedule-start',
									'type'  => 'text',
									'value' => substr( (string) ( $schedule['start_time'] ?? '' ), 0, 5 ),
								],
								'end'                => [
									'id'    => '#kerp-appointment-schedule-end',
									'type'  => 'text',
									'value' => substr( (string) ( $schedule['end_time'] ?? '' ), 0, 5 ),
								],
								'interval'           => [
									'id'    => '#kerp-appointment-schedule-interval',
									'type'  => 'text',
									'value' => absint( $schedule['slot_interval'] ?? 0 ),
								],
								'capacity'           => [
									'id'    => '#kerp-appointment-schedule-capacity',
									'type'  => 'text',
									'value' => absint( $schedule['capacity'] ?? 0 ),
								],
								'order'              => [
									'id'    => '#kerp-appointment-schedule-order',
									'type'  => 'text',
									'value' => intval( $schedule['order_index'] ?? 10 ),
								],
								'active'             => [
									'id'    => '#kerp-appointment-schedule-active',
									'type'  => 'checkbox',
									'value' => ! empty( $schedule['active'] ) ? '1' : '0',
								],
							];
							?>
                            <div class="col-md-6 col-xl-4 mb-3">
                                <div class="card card-bordered h-100 kerp-appointments-schedule-card">
                                    <div class="card-inner">
                                        <div class="nk-block-between">
                                            <div>
                                                <h6 class="title mb-1">
													<?php echo esc_html( $weekday_options[ $weekday ] ?? '' ); ?>
                                                </h6>
                                                <div class="sub-text">
													<?php
													echo esc_html(
														$employee_options[ $schedule_employee_id ]
														?? sprintf(
															__( '%1$s #%2$s', 'kasebi-erp' ),
																	$settings->get_provider_singular_label(),
															$schedule_employee_id
														)
													);
													?>
                                                </div>
                                            </div>
                                            <div class="dropdown">
                                                <a href="#"
                                                   class="btn btn-sm btn-icon btn-trigger dropdown-toggle"
                                                   data-bs-toggle="dropdown">
                                                    <em class="ni ni-more-h icon"></em>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-end">
                                                    <ul class="link-list-opt no-bdr">
                                                        <li>
                                                            <a href="#"
                                                               class="edit_row_item"
                                                               data-modal="#appointmentScheduleModal"
                                                               data-modal-title="<?php esc_attr_e( 'ویرایش برنامه کاری', 'kasebi-erp' ); ?>"
                                                               data-submit-text="<?php esc_attr_e( 'ذخیره تغییرات', 'kasebi-erp' ); ?>"
                                                               data-populate="<?php echo esc_attr( wp_json_encode( $populate ) ); ?>">
                                                                <em class="ni ni-edit icon"></em>
                                                                <span><?php esc_html_e( 'ویرایش', 'kasebi-erp' ); ?></span>
                                                            </a>
                                                        </li>
                                                        <li class="divider"></li>
                                                        <li>
                                                            <a href="#"
                                                               class="delete_db_item"
                                                               data-action="appointments_delete_schedule"
                                                               data-page="<?php echo esc_attr( $page_route ); ?>"
                                                               data-active_tab="schedules"
                                                               data-filter_employee_id="<?php echo esc_attr( $employee_id ); ?>"
                                                               data-filter_service_id="<?php echo esc_attr( $service_id ); ?>"
                                                               data-schedule_id="<?php echo esc_attr( $id ); ?>"
                                                               data-item_id="<?php echo esc_attr( $id ); ?>">
                                                                <em class="ni ni-trash icon"></em>
                                                                <span><?php esc_html_e( 'حذف', 'kasebi-erp' ); ?></span>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="kerp-appointments-schedule-time mt-3">
                                            <strong><?php echo esc_html( substr( (string) ( $schedule['start_time'] ?? '' ), 0, 5 ) ); ?></strong>
                                            <span>—</span>
                                            <strong><?php echo esc_html( substr( (string) ( $schedule['end_time'] ?? '' ), 0, 5 ) ); ?></strong>
                                        </div>

                                        <div class="sub-text mt-2">
											<?php
											echo esc_html(
												$schedule_service_id > 0
													? ( $service_options[ $schedule_service_id ] ?? '' )
													: sprintf( __( 'همه %s', 'kasebi-erp' ), $settings->get_service_plural_label() )
											);
											?>
											<?php if ( empty( $schedule['active'] ) ) : ?>
                                                · <?php esc_html_e( 'غیرفعال', 'kasebi-erp' ); ?>
											<?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
						<?php endforeach; ?>
                    </div>
				<?php endif; ?>
			<?php else : ?>
				<?php if ( empty( $exceptions ) ) : ?>
                    <div class="text-center text-soft py-4">
						<?php esc_html_e( 'استثنایی با این فیلترها ثبت نشده است.', 'kasebi-erp' ); ?>
                    </div>
				<?php else : ?>
                    <div class="row kerp-appointments-exception-grid">
						<?php foreach ( $exceptions as $exception ) : ?>
							<?php
							$id                    = absint( $exception['id'] ?? 0 );
							$exception_employee_id = absint( $exception['employee_id'] ?? 0 );
							$exception_service_id  = absint( $exception['service_id'] ?? 0 );
							$type                  = sanitize_key( (string) ( $exception['type'] ?? 'closed' ) );
							$date                  = (string) ( $exception['exception_date'] ?? '' );
							$display_date          = $form_service->to_display_date( $date );
							
							$populate = [
								'active_tab'         => [
									'id'    => '#kerp-appointment-exception-active-tab',
									'type'  => 'text',
									'value' => 'exceptions',
								],
								'filter_employee_id' => [
									'id'    => '#kerp-appointment-exception-filter-employee-id',
									'type'  => 'text',
									'value' => $employee_id,
								],
								'filter_service_id'  => [
									'id'    => '#kerp-appointment-exception-filter-service-id',
									'type'  => 'text',
									'value' => $service_id,
								],
								'id'                 => [
									'id'    => '#kerp-appointment-exception-id',
									'type'  => 'text',
									'value' => $id,
								],
								'employee'           => [
									'id'    => '#kerp-appointment-exception-employee',
									'type'  => 'select',
									'value' => $exception_employee_id,
								],
								'service'            => [
									'id'    => '#kerp-appointment-exception-service',
									'type'  => 'select',
									'value' => $exception_service_id,
								],
								'date'               => [
									'id'    => '#kerp-appointment-exception-date',
									'type'  => 'text',
									'value' => $display_date,
								],
								'type'               => [
									'id'    => '#kerp-appointment-exception-type',
									'type'  => 'select',
									'value' => $type,
								],
								'start'              => [
									'id'    => '#kerp-appointment-exception-start',
									'type'  => 'text',
									'value' => substr( (string) ( $exception['start_time'] ?? '' ), 0, 5 ),
								],
								'end'                => [
									'id'    => '#kerp-appointment-exception-end',
									'type'  => 'text',
									'value' => substr( (string) ( $exception['end_time'] ?? '' ), 0, 5 ),
								],
								'capacity'           => [
									'id'    => '#kerp-appointment-exception-capacity',
									'type'  => 'text',
									'value' => absint( $exception['capacity'] ?? 0 ),
								],
								'note'               => [
									'id'    => '#kerp-appointment-exception-note',
									'type'  => 'text',
									'value' => (string) ( $exception['note'] ?? '' ),
								],
								'active'             => [
									'id'    => '#kerp-appointment-exception-active',
									'type'  => 'checkbox',
									'value' => ! empty( $exception['active'] ) ? '1' : '0',
								],
							];
							?>
                            <div class="col-md-6 col-xl-4 mb-3">
                                <div class="card card-bordered h-100 kerp-appointments-exception-card">
                                    <div class="card-inner">
                                        <div class="nk-block-between">
                                            <div>
												<span
                                                    class="badge badge-dim bg-<?php echo $type === 'closed' ? 'danger' : 'info'; ?>">
													<?php echo $type === 'closed'
														? esc_html__( 'تعطیل', 'kasebi-erp' )
														: esc_html__( 'برنامه جایگزین', 'kasebi-erp' ); ?>
												</span>
                                                <h6 class="title mt-2 mb-1"><?php echo esc_html( $display_date ); ?></h6>
                                            </div>
                                            <div class="dropdown">
                                                <a href="#"
                                                   class="btn btn-sm btn-icon btn-trigger dropdown-toggle"
                                                   data-bs-toggle="dropdown">
                                                    <em class="ni ni-more-h icon"></em>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-end">
                                                    <ul class="link-list-opt no-bdr">
                                                        <li>
                                                            <a href="#"
                                                               class="edit_row_item"
                                                               data-modal="#appointmentExceptionModal"
                                                               data-modal-title="<?php esc_attr_e( 'ویرایش استثنا', 'kasebi-erp' ); ?>"
                                                               data-submit-text="<?php esc_attr_e( 'ذخیره تغییرات', 'kasebi-erp' ); ?>"
                                                               data-populate="<?php echo esc_attr( wp_json_encode( $populate ) ); ?>">
                                                                <em class="ni ni-edit icon"></em>
                                                                <span><?php esc_html_e( 'ویرایش', 'kasebi-erp' ); ?></span>
                                                            </a>
                                                        </li>
                                                        <li class="divider"></li>
                                                        <li>
                                                            <a href="#"
                                                               class="delete_db_item"
                                                               data-action="appointments_delete_exception"
                                                               data-page="<?php echo esc_attr( $page_route ); ?>"
                                                               data-active_tab="exceptions"
                                                               data-filter_employee_id="<?php echo esc_attr( $employee_id ); ?>"
                                                               data-filter_service_id="<?php echo esc_attr( $service_id ); ?>"
                                                               data-exception_id="<?php echo esc_attr( $id ); ?>"
                                                               data-item_id="<?php echo esc_attr( $id ); ?>">
                                                                <em class="ni ni-trash icon"></em>
                                                                <span><?php esc_html_e( 'حذف', 'kasebi-erp' ); ?></span>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="sub-text mt-2">
											<?php
											echo esc_html(
												$employee_options[ $exception_employee_id ]
												?? sprintf(
													__( '%1$s #%2$s', 'kasebi-erp' ),
																	$settings->get_provider_singular_label(),
													$exception_employee_id
												)
											);
											?>
                                            ·
											<?php
											echo esc_html(
												$exception_service_id > 0
													? ( $service_options[ $exception_service_id ] ?? '' )
													: sprintf( __( 'همه %s', 'kasebi-erp' ), $settings->get_service_plural_label() )
											);
											?>
                                        </div>
										
										<?php if ( $type === 'override' ) : ?>
                                            <div class="kerp-appointments-schedule-time mt-3">
                                                <strong><?php echo esc_html( substr( (string) ( $exception['start_time'] ?? '' ), 0, 5 ) ); ?></strong>
                                                <span>—</span>
                                                <strong><?php echo esc_html( substr( (string) ( $exception['end_time'] ?? '' ), 0, 5 ) ); ?></strong>
                                            </div>
										<?php endif; ?>
										
										<?php if ( trim( (string) ( $exception['note'] ?? '' ) ) !== '' ) : ?>
                                            <p class="sub-text mt-2 mb-0">
												<?php echo esc_html( (string) $exception['note'] ); ?>
                                            </p>
										<?php endif; ?>
                                    </div>
                                </div>
                            </div>
						<?php endforeach; ?>
                    </div>
				<?php endif; ?>
			<?php endif; ?>
        </div>
    </div>
</div>
