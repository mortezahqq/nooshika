<?php

defined( 'ABSPATH' ) || exit;

$taxonomy_service = KERP_Modules_Appointments_Taxonomies::instance();
$settings         = KERP_Modules_Appointments_Settings::instance();
$taxonomies       = $taxonomy_service->get_taxonomies( FALSE );
$total_terms      = 0;
$active_count     = 0;

foreach ( $taxonomies as $taxonomy ) {
	$total_terms  += count( (array) ( $taxonomy['terms'] ?? [] ) );
	$active_count += ! empty( $taxonomy['active'] ) ? 1 : 0;
}

$taxonomy_defaults = [
	'id'          => [ 'id' => '#kerp-appointment-taxonomy-id', 'type' => 'text', 'value' => '' ],
	'key'         => [ 'id' => '#kerp-appointment-taxonomy-key', 'type' => 'text', 'value' => '' ],
	'singular'    => [ 'id' => '#kerp-appointment-taxonomy-singular', 'type' => 'text', 'value' => '' ],
	'plural'      => [ 'id' => '#kerp-appointment-taxonomy-plural', 'type' => 'text', 'value' => '' ],
	'description' => [ 'id' => '#kerp-appointment-taxonomy-description', 'type' => 'text', 'value' => '' ],
	'icon'        => [ 'id' => '#kerp-appointment-taxonomy-icon', 'type' => 'text', 'value' => 'ni ni-folder-list' ],
	'color'       => [ 'id' => '#kerp-appointment-taxonomy-color', 'type' => 'select', 'value' => 'primary' ],
	'order'       => [ 'id' => '#kerp-appointment-taxonomy-order', 'type' => 'text', 'value' => 10 ],
	'active'      => [ 'id' => '#kerp-appointment-taxonomy-active', 'type' => 'switch', 'value' => '1' ],
];
?>
<div class="kerp-appointments-taxonomies">
    <div class="nk-block-head nk-block-head-sm">
        <div class="nk-block-between g-3">
            <div class="nk-block-head-content">
                <h3 class="nk-block-title page-title"><?php echo esc_html( sprintf( __( 'دسته‌بندی %s', 'kasebi-erp' ), $settings->get_service_plural_label() ) ); ?></h3>
                <div class="nk-block-des text-soft">
                    <p><?php echo esc_html( sprintf( __( 'ساختارهای دلخواه برای گروه‌بندی %s و گزینه‌های قابل انتخاب هر ساختار را مدیریت کنید.', 'kasebi-erp' ), $settings->get_service_plural_label() ) ); ?></p>
                </div>
            </div>
            <div class="nk-block-head-content">
                <button type="button"
                        class="btn btn-primary open_populate_modal"
                        data-modal="#appointmentTaxonomyModal"
                        data-modal-title="<?php echo esc_attr( sprintf( __( 'افزودن دسته‌بندی %s', 'kasebi-erp' ), $settings->get_service_plural_label() ) ); ?>"
                        data-submit-text="<?php esc_attr_e( 'افزودن دسته‌بندی', 'kasebi-erp' ); ?>"
                        data-populate="<?php echo esc_attr( wp_json_encode( $taxonomy_defaults ) ); ?>">
                    <em class="icon ni ni-plus"></em>
                    <span><?php esc_html_e( 'افزودن دسته‌بندی', 'kasebi-erp' ); ?></span>
                </button>
            </div>
        </div>
    </div>
	<?php if ( ! empty( $taxonomies ) ) : ?>
        <div class="nk-block kerp-taxonomy-summary">
            <div class="card card-bordered kerp-taxonomy-summary-card">
                <div class="row g-0">
                    <div class="col-md-4">
                        <div class="kerp-taxonomy-summary-item">
                            <div class="user-avatar sm bg-primary-dim text-primary"><em
                                    class="icon ni ni-folder-list"></em></div>
                            <div>
                                <div
                                    class="kerp-taxonomy-summary-value"><?php echo esc_html( number_format_i18n( count( $taxonomies ) ) ); ?></div>
                                <div
                                    class="kerp-taxonomy-summary-label"><?php esc_html_e( 'دسته‌بندی', 'kasebi-erp' ); ?></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="kerp-taxonomy-summary-item">
                            <div class="user-avatar sm bg-success-dim text-success"><em
                                    class="icon ni ni-check-circle"></em></div>
                            <div>
                                <div
                                    class="kerp-taxonomy-summary-value"><?php echo esc_html( number_format_i18n( $active_count ) ); ?></div>
                                <div
                                    class="kerp-taxonomy-summary-label"><?php esc_html_e( 'دسته‌بندی فعال', 'kasebi-erp' ); ?></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="kerp-taxonomy-summary-item">
                            <div class="user-avatar sm bg-info-dim text-info"><em class="icon ni ni-tags"></em></div>
                            <div>
                                <div
                                    class="kerp-taxonomy-summary-value"><?php echo esc_html( number_format_i18n( $total_terms ) ); ?></div>
                                <div
                                    class="kerp-taxonomy-summary-label"><?php esc_html_e( 'گزینه ثبت‌شده', 'kasebi-erp' ); ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
	<?php endif; ?>
    <div class="nk-block">
		<?php if ( empty( $taxonomies ) ) : ?>
            <div class="card card-bordered">
                <div class="card-inner kerp-taxonomy-empty">
                    <div class="user-avatar lg bg-primary-dim text-primary">
                        <em class="icon ni ni-folder-plus"></em>
                    </div>
                    <h5><?php esc_html_e( 'هنوز دسته‌بندی‌ای ساخته نشده است.', 'kasebi-erp' ); ?></h5>
                    <p class="text-soft"><?php echo esc_html( sprintf( __( 'برای شروع می‌توانید دسته‌هایی مثل «نوع %s»، «تخصص» یا «شیوه برگزاری» ایجاد کنید.', 'kasebi-erp' ), $settings->get_service_singular_label() ) ); ?></p>
                    <button type="button"
                            class="btn btn-primary open_populate_modal"
                            data-modal="#appointmentTaxonomyModal"
                            data-modal-title="<?php echo esc_attr( sprintf( __( 'افزودن دسته‌بندی %s', 'kasebi-erp' ), $settings->get_service_plural_label() ) ); ?>"
                            data-submit-text="<?php esc_attr_e( 'افزودن دسته‌بندی', 'kasebi-erp' ); ?>"
                            data-populate="<?php echo esc_attr( wp_json_encode( $taxonomy_defaults ) ); ?>">
                        <em class="icon ni ni-plus"></em>
                        <span><?php esc_html_e( 'ایجاد اولین دسته‌بندی', 'kasebi-erp' ); ?></span>
                    </button>
                </div>
            </div>
		<?php endif; ?>
		<?php foreach ( $taxonomies as $taxonomy ) : ?>
			<?php
			$taxonomy_id          = absint( $taxonomy['id'] ?? 0 );
			$taxonomy_icon        = (string) ( $taxonomy['icon'] ?? 'ni ni-folder-list' );
			$taxonomy_color       = sanitize_key( (string) ( $taxonomy['color'] ?? 'primary' ) ) ?: 'primary';
			$taxonomy_description = trim( (string) ( $taxonomy['description'] ?? '' ) );
			$taxonomy_singular    = (string) ( $taxonomy['singular_label'] ?? __( 'گزینه', 'kasebi-erp' ) );
			$taxonomy_plural      = (string) ( $taxonomy['plural_label'] ?? '' );
			$taxonomy_key         = (string) ( $taxonomy['tax_key'] ?? '' );
			$taxonomy_active      = ! empty( $taxonomy['active'] );
			$terms                = (array) ( $taxonomy['terms'] ?? [] );
			$term_name_map        = [];
			
			foreach ( $terms as $map_term ) {
				$map_term_id = absint( $map_term['id'] ?? 0 );
				if ( $map_term_id > 0 ) {
					$term_name_map[ $map_term_id ] = (string) ( $map_term['name'] ?? '' );
				}
			}
			
			$taxonomy_populate = [
				'id'          => [ 'id' => '#kerp-appointment-taxonomy-id', 'type' => 'text', 'value' => $taxonomy_id ],
				'key'         => [
					'id'    => '#kerp-appointment-taxonomy-key',
					'type'  => 'no_change',
					'value' => $taxonomy_key,
				],
				'singular'    => [
					'id'    => '#kerp-appointment-taxonomy-singular',
					'type'  => 'text',
					'value' => $taxonomy_singular,
				],
				'plural'      => [
					'id'    => '#kerp-appointment-taxonomy-plural',
					'type'  => 'text',
					'value' => $taxonomy_plural,
				],
				'description' => [
					'id'    => '#kerp-appointment-taxonomy-description',
					'type'  => 'text',
					'value' => $taxonomy_description,
				],
				'icon'        => [
					'id'    => '#kerp-appointment-taxonomy-icon',
					'type'  => 'text',
					'value' => $taxonomy_icon,
				],
				'color'       => [
					'id'    => '#kerp-appointment-taxonomy-color',
					'type'  => 'select',
					'value' => $taxonomy_color,
				],
				'order'       => [
					'id'    => '#kerp-appointment-taxonomy-order',
					'type'  => 'text',
					'value' => intval( $taxonomy['order_index'] ?? 10 ),
				],
				'active'      => [
					'id'    => '#kerp-appointment-taxonomy-active',
					'type'  => 'switch',
					'value' => $taxonomy_active ? '1' : '0',
				],
			];
			$term_add_populate = [
				'id'          => [ 'id' => '#kerp-appointment-term-id', 'type' => 'text', 'value' => '' ],
				'taxonomy'    => [
					'id'    => '#kerp-appointment-term-taxonomy',
					'type'  => 'select',
					'value' => $taxonomy_id,
				],
				'name'        => [ 'id' => '#kerp-appointment-term-name', 'type' => 'text', 'value' => '' ],
				'slug'        => [ 'id' => '#kerp-appointment-term-slug', 'type' => 'text', 'value' => '' ],
				'parent'      => [ 'id' => '#kerp-appointment-term-parent', 'type' => 'text', 'value' => 0 ],
				'description' => [ 'id' => '#kerp-appointment-term-description', 'type' => 'text', 'value' => '' ],
				'icon'        => [ 'id' => '#kerp-appointment-term-icon', 'type' => 'text', 'value' => 'ni ni-tag' ],
				'color'       => [
					'id'    => '#kerp-appointment-term-color',
					'type'  => 'select',
					'value' => $taxonomy_color,
				],
				'order'       => [ 'id' => '#kerp-appointment-term-order', 'type' => 'text', 'value' => 10 ],
				'active'      => [ 'id' => '#kerp-appointment-term-active', 'type' => 'switch', 'value' => '1' ],
			];
			?>
            <div class="card card-bordered kerp-taxonomy-card">
                <div class="card-inner kerp-taxonomy-card-head">
                    <div class="nk-block-between g-3 align-start">
                        <div class="d-flex align-items-start g-3 min-w-0">
                            <div
                                class="user-avatar md bg-<?php echo esc_attr( $taxonomy_color ); ?>-dim text-<?php echo esc_attr( $taxonomy_color ); ?>">
                                <em class="<?php echo esc_attr( $taxonomy_icon ); ?>"></em>
                            </div>
                            <div class="min-w-0">
                                <div class="d-flex align-items-center flex-wrap" style="gap: 5px">
                                    <h5 class="title mb-0"><?php echo esc_html( $taxonomy_plural ); ?></h5>
                                    <span
                                        class="badge badge-dim <?php echo $taxonomy_active ? 'bg-success' : 'bg-light'; ?>">
										<?php echo $taxonomy_active ? esc_html__( 'فعال', 'kasebi-erp' ) : esc_html__( 'غیرفعال', 'kasebi-erp' ); ?>
									</span>
                                </div>
                                <div class="kerp-taxonomy-meta">
                                    <code dir="ltr"><?php echo esc_html( $taxonomy_key ); ?></code>
                                    <span
                                        class="text-soft small"><?php printf( esc_html__( '%s گزینه', 'kasebi-erp' ), esc_html( number_format_i18n( count( $terms ) ) ) ); ?></span>
                                    <span
                                        class="text-soft small"><?php printf( esc_html__( 'ترتیب %s', 'kasebi-erp' ), esc_html( number_format_i18n( intval( $taxonomy['order_index'] ?? 10 ) ) ) ); ?></span>
                                </div>
								<?php if ( $taxonomy_description !== '' ) : ?>
                                    <p class="text-soft kerp-taxonomy-description"><?php echo esc_html( $taxonomy_description ); ?></p>
								<?php endif; ?>
                            </div>
                        </div>
                        <div class="d-flex align-items-center g-2">
                            <button type="button"
                                    class="btn btn-sm btn-outline-primary open_populate_modal"
                                    data-modal="#appointmentTermModal"
                                    data-modal-title="<?php echo esc_attr( sprintf( __( 'افزودن %s', 'kasebi-erp' ), $taxonomy_singular ) ); ?>"
                                    data-submit-text="<?php esc_attr_e( 'افزودن گزینه', 'kasebi-erp' ); ?>"
                                    data-populate="<?php echo esc_attr( wp_json_encode( $term_add_populate ) ); ?>">
                                <em class="icon ni ni-plus"></em>
                                <span><?php echo esc_html( sprintf( __( 'افزودن %s', 'kasebi-erp' ), $taxonomy_singular ) ); ?></span>
                            </button>
                            <div class="dropdown">
                                <a href="#" class="btn btn-sm btn-icon btn-trigger dropdown-toggle"
                                   data-bs-toggle="dropdown"
                                   aria-label="<?php esc_attr_e( 'عملیات دسته‌بندی', 'kasebi-erp' ); ?>">
                                    <em class="icon ni ni-more-h"></em>
                                </a>
                                <div class="dropdown-menu dropdown-menu-end">
                                    <ul class="link-list-opt no-bdr">
                                        <li>
                                            <a href="#"
                                               class="edit_row_item"
                                               data-modal="#appointmentTaxonomyModal"
                                               data-modal-title="<?php echo esc_attr( sprintf( __( 'ویرایش دسته‌بندی %s', 'kasebi-erp' ), $settings->get_service_plural_label() ) ); ?>"
                                               data-submit-text="<?php esc_attr_e( 'ذخیره تغییرات', 'kasebi-erp' ); ?>"
                                               data-populate="<?php echo esc_attr( wp_json_encode( $taxonomy_populate ) ); ?>">
                                                <em class="icon ni ni-edit"></em>
                                                <span><?php esc_html_e( 'ویرایش', 'kasebi-erp' ); ?></span>
                                            </a>
                                        </li>
                                        <li class="divider"></li>
                                        <li>
                                            <a href="#"
                                               class="delete_db_item text-danger"
                                               data-action="appointments_delete_taxonomy"
                                               data-page="/erp/appointments/taxonomies/"
                                               data-taxonomy_id="<?php echo esc_attr( $taxonomy_id ); ?>"
                                               data-item_id="<?php echo esc_attr( $taxonomy_id ); ?>">
                                                <em class="icon ni ni-trash"></em>
                                                <span><?php esc_html_e( 'حذف دسته‌بندی', 'kasebi-erp' ); ?></span>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-inner border-top kerp-taxonomy-terms">
					<?php if ( empty( $terms ) ) : ?>
                        <div class="d-flex align-items-center justify-content-between flex-wrap g-3 py-1">
                            <div class="d-flex align-items-center g-2 text-soft">
                                <em class="icon ni ni-info"></em>
                                <span><?php esc_html_e( 'برای این دسته‌بندی هنوز گزینه‌ای ثبت نشده است.', 'kasebi-erp' ); ?></span>
                            </div>
                            <button type="button"
                                    class="btn btn-sm btn-light open_populate_modal"
                                    data-modal="#appointmentTermModal"
                                    data-modal-title="<?php echo esc_attr( sprintf( __( 'افزودن %s', 'kasebi-erp' ), $taxonomy_singular ) ); ?>"
                                    data-submit-text="<?php esc_attr_e( 'افزودن گزینه', 'kasebi-erp' ); ?>"
                                    data-populate="<?php echo esc_attr( wp_json_encode( $term_add_populate ) ); ?>">
                                <em class="icon ni ni-plus"></em>
                                <span><?php esc_html_e( 'افزودن اولین گزینه', 'kasebi-erp' ); ?></span>
                            </button>
                        </div>
					<?php else : ?>
                        <div class="kerp-terms-grid">
							<?php foreach ( $terms as $term ) : ?>
								<?php
								$term_id          = absint( $term['id'] ?? 0 );
								$term_name        = (string) ( $term['name'] ?? '' );
								$term_slug        = (string) ( $term['slug'] ?? '' );
								$term_icon        = (string) ( $term['icon'] ?? 'ni ni-tag' );
								$term_color       = sanitize_key( (string) ( $term['color'] ?? 'primary' ) ) ?: 'primary';
								$term_description = trim( (string) ( $term['description'] ?? '' ) );
								$term_parent_id   = absint( $term['parent_id'] ?? 0 );
								$term_parent_name = $term_parent_id > 0 ? (string) ( $term_name_map[ $term_parent_id ] ?? '' ) : '';
								$term_active      = ! empty( $term['active'] );
								$term_populate    = [
									'id'          => [
										'id'    => '#kerp-appointment-term-id',
										'type'  => 'text',
										'value' => $term_id,
									],
									'taxonomy'    => [
										'id'    => '#kerp-appointment-term-taxonomy',
										'type'  => 'select',
										'value' => $taxonomy_id,
									],
									'name'        => [
										'id'    => '#kerp-appointment-term-name',
										'type'  => 'text',
										'value' => $term_name,
									],
									'slug'        => [
										'id'    => '#kerp-appointment-term-slug',
										'type'  => 'text',
										'value' => $term_slug,
									],
									'parent'      => [
										'id'    => '#kerp-appointment-term-parent',
										'type'  => 'text',
										'value' => $term_parent_id,
									],
									'description' => [
										'id'    => '#kerp-appointment-term-description',
										'type'  => 'text',
										'value' => $term_description,
									],
									'icon'        => [
										'id'    => '#kerp-appointment-term-icon',
										'type'  => 'text',
										'value' => $term_icon,
									],
									'color'       => [
										'id'    => '#kerp-appointment-term-color',
										'type'  => 'select',
										'value' => $term_color,
									],
									'order'       => [
										'id'    => '#kerp-appointment-term-order',
										'type'  => 'text',
										'value' => intval( $term['order_index'] ?? 10 ),
									],
									'active'      => [
										'id'    => '#kerp-appointment-term-active',
										'type'  => 'switch',
										'value' => $term_active ? '1' : '0',
									],
								];
								?>
                                <div class="card card-bordered kerp-term-card">
                                    <div class="card-inner">
                                        <div class="d-flex align-items-start justify-content-between g-2">
                                            <div class="d-flex align-items-start g-2 min-w-0">
                                                <div
                                                    class="user-avatar bg-<?php echo esc_attr( $term_color ); ?>-dim
                                                    text-<?php echo esc_attr( $term_color ); ?> fs-16px">
                                                    <em class="<?php echo esc_attr( $term_icon ); ?>"></em>
                                                </div>
                                                <div class="min-w-0">
                                                    <h6 class="title mb-1"><?php echo esc_html( $term_name ); ?></h6>
													<?php if ( $term_slug !== '' ) : ?>
                                                        <code dir="ltr"><?php echo esc_html( $term_slug ); ?></code>
													<?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="dropdown">
                                                <a href="#" class="btn btn-xs btn-icon btn-trigger dropdown-toggle"
                                                   data-bs-toggle="dropdown"
                                                   aria-label="<?php esc_attr_e( 'عملیات گزینه', 'kasebi-erp' ); ?>">
                                                    <em class="icon ni ni-more-h"></em>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-end">
                                                    <ul class="link-list-opt no-bdr">
                                                        <li>
                                                            <a href="#"
                                                               class="edit_row_item"
                                                               data-modal="#appointmentTermModal"
                                                               data-modal-title="<?php echo esc_attr( sprintf( __( 'ویرایش %s', 'kasebi-erp' ), $taxonomy_singular ) ); ?>"
                                                               data-submit-text="<?php esc_attr_e( 'ذخیره تغییرات', 'kasebi-erp' ); ?>"
                                                               data-populate="<?php echo esc_attr( wp_json_encode( $term_populate ) ); ?>">
                                                                <em class="icon ni ni-edit"></em>
                                                                <span><?php esc_html_e( 'ویرایش', 'kasebi-erp' ); ?></span>
                                                            </a>
                                                        </li>
                                                        <li class="divider"></li>
                                                        <li>
                                                            <a href="#"
                                                               class="delete_db_item text-danger"
                                                               data-action="appointments_delete_term"
                                                               data-page="/erp/appointments/taxonomies/"
                                                               data-term_id="<?php echo esc_attr( $term_id ); ?>"
                                                               data-item_id="<?php echo esc_attr( $term_id ); ?>">
                                                                <em class="icon ni ni-trash"></em>
                                                                <span><?php esc_html_e( 'حذف', 'kasebi-erp' ); ?></span>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
										<?php if ( $term_description !== '' ) : ?>
                                            <p class="text-soft kerp-term-card-description"><?php echo esc_html( $term_description ); ?></p>
										<?php endif; ?>
                                        <div class="kerp-term-card-footer">
                                            <div class="d-flex align-items-center flex-wrap g-2">
												<span
                                                    class="badge badge-dim <?php echo $term_active ? 'bg-success' : 'bg-light'; ?>">
													<?php echo $term_active ? esc_html__( 'فعال', 'kasebi-erp' ) : esc_html__( 'غیرفعال', 'kasebi-erp' ); ?>
												</span>
												<?php if ( $term_parent_id > 0 ) : ?>
                                                    <span class="badge badge-dim bg-outline-secondary">
														<?php echo esc_html( $term_parent_name !== '' ? sprintf( __( 'زیرمجموعه %s', 'kasebi-erp' ), $term_parent_name ) : sprintf( __( 'والد #%s', 'kasebi-erp' ), $term_parent_id ) ); ?>
													</span>
												<?php endif; ?>
                                            </div>
                                            <span
                                                class="text-soft small"><?php printf( esc_html__( 'ترتیب %s', 'kasebi-erp' ), esc_html( number_format_i18n( intval( $term['order_index'] ?? 10 ) ) ) ); ?></span>
                                        </div>
                                    </div>
                                </div>
							<?php endforeach; ?>
                        </div>
					<?php endif; ?>
                </div>
            </div>
		<?php endforeach; ?>
    </div>
</div>