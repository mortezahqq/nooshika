<?php

defined( 'ABSPATH' ) || exit;

$page_context = isset( $page_context ) && is_array( $page_context )
	? $page_context
	: [];

$page_query = isset( $page_context['query'] ) && is_array( $page_context['query'] )
	? $page_context['query']
	: [];

$settings    = KERP_Modules_Appointments_Settings::instance();
$page_route  = '/erp/appointments/services/';
$search      = sanitize_text_field( (string) ( $page_query['search'] ?? '' ) );
$active      = isset( $page_query['active'] )
	? sanitize_text_field( (string) $page_query['active'] )
	: '';
$page_number = max( 1, absint( $page_query['page_number'] ?? 1 ) );
$per_page    = max( 1, min( 100, absint( $page_query['per_page'] ?? 24 ) ) );

$result = KERP_Modules_Appointments_Services::instance()->find(
	[
		'search'      => $search,
		'active'      => $active,
		'page_number' => $page_number,
		'per_page'    => $per_page,
	]
);

$services    = (array) ( $result['items'] ?? [] );
$total       = absint( $result['total'] ?? 0 );
$total_pages = max( 1, absint( $result['total_pages'] ?? 1 ) );
$has_filter  = $search !== '' || $active !== '';

$filter_fields = [
	'search' => [
		'id'          => 'kerp-appointments-service-search',
		'name'        => 'search',
		'label'       => __( 'جستجو', 'kasebi-erp' ),
		'type'        => 'search',
		'placeholder' => sprintf( __( 'عنوان، کلید یا توضیحات %s', 'kasebi-erp' ), $settings->get_service_singular_label() ),
		'value'       => $search,
		'col'         => 8,
	],
	'active' => [
		'id'          => 'kerp-appointments-service-active-filter',
		'name'        => 'active',
		'label'       => __( 'وضعیت', 'kasebi-erp' ),
		'type'        => 'select',
		'placeholder' => __( 'همه وضعیت‌ها', 'kasebi-erp' ),
		'options'     => [
			'1' => __( 'فعال', 'kasebi-erp' ),
			'0' => __( 'غیرفعال', 'kasebi-erp' ),
		],
		'value'       => $active,
		'col'         => 4,
	],
];

$add_populate = [
	'id' => [
		'id'    => '#kerp-appointment-service-id',
		'type'  => 'text',
		'value' => '',
	],
	'duration' => [
		'id'    => '#kerp-service-duration',
		'type'  => 'text',
		'value' => absint( $settings->get( 'default_duration', 30 ) ),
	],
	'capacity' => [
		'id'    => '#kerp-service-capacity',
		'type'  => 'text',
		'value' => absint( $settings->get( 'default_capacity', 1 ) ),
	],
	'order' => [
		'id'    => '#kerp-service-order',
		'type'  => 'text',
		'value' => 10,
	],
	'active' => [
		'id'    => '#kerp-service-active',
		'type'  => 'checkbox',
		'value' => '1',
	],
	'public' => [
		'id'    => '#kerp-service-public',
		'type'  => 'checkbox',
		'value' => '1',
	],
];
?>
<div class="nk-block-head nk-block-head-sm">
	<div class="nk-block-between">
		<div class="nk-block-head-content">
			<h3 class="nk-block-title page-title">
				<?php echo esc_html( $settings->get_service_plural_label() ); ?>
			</h3>
			<div class="nk-block-des text-soft">
				<p>
					<?php
					if ( $has_filter ) {
						printf(
							esc_html__( '%s مورد مطابق فیلتر پیدا شد.', 'kasebi-erp' ),
							esc_html( number_format_i18n( $total ) )
						);
					} else {
						printf(
							esc_html__( '%s مورد ثبت شده است.', 'kasebi-erp' ),
							esc_html( number_format_i18n( $total ) )
						);
					}
					?>
				</p>
			</div>
		</div>

		<div class="nk-block-head-content">
			<div class="kerp-services-head-actions">
				<?php
				echo KERP_Helpers_Template::get_template(
					'app/components/list/filter-dropdown.php',
					[
						'has_filter'    => $has_filter,
						'filter_fields' => $filter_fields,
						'page'          => $page_route,
						'action'        => 'erp_request_page_content',
						'title'         => sprintf(
							__( 'فیلتر %s', 'kasebi-erp' ),
							$settings->get_service_plural_label()
						),
					]
				);
				?>

				<a href="#"
				   class="btn btn-primary open_populate_modal"
				   data-modal="#appointmentServiceModal"
				   data-modal-title="<?php echo esc_attr( sprintf( __( 'افزودن %s', 'kasebi-erp' ), $settings->get_service_singular_label() ) ); ?>"
				   data-submit-text="<?php echo esc_attr( sprintf( __( 'ذخیره %s', 'kasebi-erp' ), $settings->get_service_singular_label() ) ); ?>"
				   data-populate="<?php echo esc_attr( wp_json_encode( $add_populate ) ); ?>">
					<em class="ni ni-plus icon"></em>
					<span>
						<?php
						echo esc_html(
							sprintf(
								__( 'افزودن %s', 'kasebi-erp' ),
								$settings->get_service_singular_label()
							)
						);
						?>
					</span>
				</a>
			</div>
		</div>
	</div>
</div>

<div class="nk-block">
	<?php if ( empty( $services ) ) : ?>
		<div class="card card-bordered kerp-services-empty">
			<div class="card-inner text-center">
				<span class="kerp-services-empty__icon">
					<em class="ni ni-property icon"></em>
				</span>

				<h5 class="mt-3 mb-1">
					<?php echo esc_html( sprintf( __( '%s پیدا نشد.', 'kasebi-erp' ), $settings->get_service_singular_label() ) ); ?>
				</h5>

				<p class="text-soft mb-0">
					<?php
					echo $has_filter
						? esc_html__( 'فیلترها را تغییر دهید یا بازنشانی کنید.', 'kasebi-erp' )
						: esc_html( sprintf( __( 'برای شروع، اولین %s قابل رزرو را ایجاد کنید.', 'kasebi-erp' ), $settings->get_service_singular_label() ) );
					?>
				</p>
			</div>
		</div>
	<?php else : ?>
		<div class="row kerp-services-grid">
			<?php foreach ( $services as $service ) : ?>
				<div class="col-md-6 col-xl-4 mb-4">
					<?php
					KERP_Helpers_Template::render_template(
						'modules/appointments/partials/service-card.php',
						[
							'service' => $service,
						]
					);
					?>
				</div>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>
</div>

<?php if ( $total_pages > 1 ) : ?>
	<div class="nk-block">
		<div class="card card-bordered">
			<div class="card-inner">
				<?php
				echo KERP_Helpers_Template::get_template(
					'app/components/list/pagination.php',
					[
						'max_page_num' => $total_pages,
						'current_page' => $page_number,
						'class_name'   => 'appointments_services_pagination_link',
						'show_count'   => 2,
						'action'       => 'erp_request_page_content',
						'page'         => $page_route,
					]
				);
				?>
			</div>
		</div>
	</div>
<?php endif; ?>
