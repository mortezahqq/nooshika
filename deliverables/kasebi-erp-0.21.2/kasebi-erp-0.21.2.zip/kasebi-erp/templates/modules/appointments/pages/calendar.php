<?php

defined( 'ABSPATH' ) || exit;

$page_context = isset( $page_context ) && is_array( $page_context )
	? $page_context
	: [];
$page_query   = isset( $page_context['query'] ) && is_array( $page_context['query'] )
	? $page_context['query']
	: [];

$form_service         = KERP_Modules_Appointments_Form::instance();
$settings             = KERP_Modules_Appointments_Settings::instance();
$list_table           = KERP_Modules_Appointments_List_Table::instance();
$availability_service = KERP_Modules_Appointments_Availability::instance();
$schedules_service    = KERP_Modules_Appointments_Schedules::instance();
$page_route           = '/erp/appointments/calendar/';
$today                = date( 'Y-m-d' );
$anchor               = $form_service->normalize_date( (string) ( $page_query['week'] ?? '' ) );

if ( $anchor === '' ) {
	$anchor = $today;
}

$anchor_timestamp = strtotime( $anchor . ' 12:00:00' );
if ( $anchor_timestamp === FALSE ) {
	$anchor           = $today;
	$anchor_timestamp = strtotime( $anchor . ' 12:00:00' );
}

$weekday            = (int) date( 'w', $anchor_timestamp );
$days_from_saturday = ( $weekday + 1 ) % 7;
$week_start         = date( 'Y-m-d', strtotime( '-' . $days_from_saturday . ' days', $anchor_timestamp ) );
$week_end           = date( 'Y-m-d', strtotime( '+6 days', strtotime( $week_start . ' 12:00:00' ) ) );
$previous           = date( 'Y-m-d', strtotime( '-7 days', strtotime( $week_start . ' 12:00:00' ) ) );
$next               = date( 'Y-m-d', strtotime( '+7 days', strtotime( $week_start . ' 12:00:00' ) ) );
$employee_id        = absint( $page_query['employee_id'] ?? 0 );
$service_id         = absint( $page_query['service_id'] ?? 0 );

$previous_url = add_query_arg(
	array_filter(
		[
			'week'        => $previous,
			'employee_id' => $employee_id ?: NULL,
			'service_id'  => $service_id ?: NULL,
		]
	),
	$page_route
);
$today_url    = add_query_arg(
	array_filter(
		[
			'week'        => $today,
			'employee_id' => $employee_id ?: NULL,
			'service_id'  => $service_id ?: NULL,
		]
	),
	$page_route
);
$next_url     = add_query_arg(
	array_filter(
		[
			'week'        => $next,
			'employee_id' => $employee_id ?: NULL,
			'service_id'  => $service_id ?: NULL,
		]
	),
	$page_route
);
$return_page  = add_query_arg(
	array_filter(
		[
			'week'        => $week_start,
			'employee_id' => $employee_id ?: NULL,
			'service_id'  => $service_id ?: NULL,
		]
	),
	$page_route
);

$result = KERP_Modules_Appointments_Query::instance()->find(
	[
		'date_from'   => $week_start,
		'date_to'     => $week_end,
		'public_fields' => KERP_Modules_Appointments_Public_Fields::instance()->get_filter_values( $page_query ),
		'employee_id' => $employee_id,
		'service_id'  => $service_id,
		'page_number' => 1,
		'per_page'    => 200,
		'order'       => 'ASC',
	]
);

$items   = (array) ( $result['items'] ?? [] );
$by_date = [];

foreach ( $items as $item ) {
	$date_key = substr( (string) ( $item['start_at'] ?? '' ), 0, 10 );
	if ( $date_key !== '' ) {
		$by_date[ $date_key ][] = $item;
	}
}

$weekday_labels = $schedules_service->get_weekday_options();
$can_create     = kerp_can( 'appointments.create', 'action' );
$can_edit       = kerp_can( 'appointments.edit', 'action' );

$filter_values    = [
	'employee_id' => $employee_id,
	'service_id'  => $service_id,
];
$all_filters      = $list_table->get_filters( array_merge( $page_query, $filter_values ) );
$calendar_filters = [
	'week' => [
		'key'   => 'week',
		'name'  => 'week',
		'type'  => 'hidden',
		'value' => $week_start,
		'order' => 0,
	],
];

foreach ( [ 'service_id', 'employee_id' ] as $filter_key ) {
	if ( isset( $all_filters[ $filter_key ] ) ) {
		$calendar_filters[ $filter_key ] = $all_filters[ $filter_key ];
	}
}

foreach ( $all_filters as $filter_key => $field ) {
	if ( str_starts_with( $filter_key, 'public_field_' ) ) {
		$calendar_filters[ $filter_key ] = $field;
	}
}
$has_filter        = $employee_id > 0 || $service_id > 0 || KERP_Modules_Appointments_Public_Fields::instance()->get_filter_values( $page_query ) !== [];
$can_show_free     = $service_id > 0;
$week_display_from = $form_service->to_display_date( $week_start );
$week_display_to   = $form_service->to_display_date( $week_end );
?>
<div class="nk-block-head nk-block-head-sm">
    <div class="nk-block-between g-3">
        <div class="nk-block-head-content">
            <h3 class="nk-block-title page-title"><?php echo esc_html( sprintf( __( 'تقویم %s', 'kasebi-erp' ), $settings->get_appointment_plural_label() ) ); ?></h3>
            <div class="nk-block-des text-soft">
                <p>
					<?php
					echo esc_html(
						sprintf(
							__( '%s تا %s', 'kasebi-erp' ),
							$week_display_from,
							$week_display_to
						)
					);
					?>
                </p>
            </div>
        </div>
        <div class="nk-block-head-content">
            <div class="d-flex align-items-center flex-wrap kerp-appointments-head-actions" style="gap: 10px">
                <a href="<?php echo esc_attr( $previous_url ); ?>"
                   class="btn btn-light page_activator"
                   data-url="<?php echo esc_attr( $previous_url ); ?>">
                    <em class="icon ni ni-chevron-left"></em>
                    <span><?php esc_html_e( 'هفته قبل', 'kasebi-erp' ); ?></span>
                </a>
                <a href="<?php echo esc_attr( $today_url ); ?>"
                   class="btn btn-light page_activator"
                   data-url="<?php echo esc_attr( $today_url ); ?>">
                    <em class="icon ni ni-calendar-check"></em>
                    <span><?php esc_html_e( 'امروز', 'kasebi-erp' ); ?></span>
                </a>
                <a href="<?php echo esc_attr( $next_url ); ?>"
                   class="btn btn-light page_activator"
                   data-url="<?php echo esc_attr( $next_url ); ?>">
                    <span><?php esc_html_e( 'هفته بعد', 'kasebi-erp' ); ?></span>
                    <em class="icon ni ni-chevron-right"></em>
                </a>
				<?php
				echo KERP_Helpers_Template::get_template(
					'app/components/list/filter-dropdown.php',
					[
						'has_filter'    => $has_filter,
						'filter_fields' => $calendar_filters,
						'action'        => 'erp_request_page_content',
						'page'          => $page_route,
						'title'         => __( 'فیلتر تقویم', 'kasebi-erp' ),
					]
				);
				?>
            </div>
        </div>
    </div>
</div>

<?php if ( ! $can_show_free ) : ?>
    <div class="nk-block kerp-calendar-filter-hint">
        <div class="alert alert-light alert-icon">
            <em class="icon ni ni-clock"></em>
            <span><?php echo esc_html( sprintf( __( 'برای مشاهده ساعت‌های آزاد هر روز، %1$s را از فیلتر انتخاب کنید.', 'kasebi-erp' ), $settings->get_service_singular_label() ) ); ?></span>
        </div>
    </div>
<?php endif; ?>

<div class="nk-block">
    <div class="kerp-appointments-calendar-board" data-simplebar data-simplebar-auto-hide="false">
        <div class="kerp-appointments-calendar-board__inner">
			<?php for ( $day_index = 0; $day_index < 7; $day_index ++ ) : ?>
				<?php
				$day_timestamp = strtotime( '+' . $day_index . ' days', strtotime( $week_start . ' 12:00:00' ) );
				$date_key      = date( 'Y-m-d', $day_timestamp );
				$day_items     = (array) ( $by_date[ $date_key ] ?? [] );
				$free_slots    = $can_show_free
					? $availability_service->get_slots( $date_key, $service_id, $employee_id )
					: [];
				
				$free_slot_groups = [];
				
				if ( $employee_id > 0 ) {
					if ( ! empty( $free_slots ) ) {
						$free_slot_groups[ $employee_id ] = $free_slots;
					}
				} else {
					foreach ( $free_slots as $slot_employee_id => $employee_slots ) {
						$slot_employee_id = absint( $slot_employee_id );
						$employee_slots   = (array) $employee_slots;
						
						if ( $slot_employee_id <= 0 || empty( $employee_slots ) ) {
							continue;
						}
						
						$free_slot_groups[ $slot_employee_id ] = $employee_slots;
					}
				}
				
				$total_free_slots = 0;
				
				foreach ( $free_slot_groups as $employee_slots ) {
					$total_free_slots += count( $employee_slots );
				}
				
				$has_free_slots = $total_free_slots > 0;
				$display_date   = $form_service->to_display_date( $date_key );
				$is_today       = $date_key === $today;
				$add_populate   = [
					'appointment_id' => [
						'id'    => '#kerp-appointment-id',
						'type'  => 'text',
						'value' => '',
					],
					'return_page'    => [
						'id'    => '#kerp-appointment-return-page',
						'type'  => 'text',
						'value' => $return_page,
					],
					'date'           => [
						'id'    => '#kerp-appointment-date',
						'type'  => 'text',
						'value' => date_i18n( 'Y-m-d', strtotime( $date_key ) ),
					],
					'service'        => [
						'id'    => '#kerp-appointment-service',
						'type'  => 'select',
						'value' => $service_id,
					],
					'employee'       => [
						'id'    => '#kerp-appointment-employee',
						'type'  => 'select',
						'value' => $employee_id,
					],
				];
				?>
                <div class="kerp-appointments-calendar-column<?php echo $is_today ? ' is-today' : ''; ?>">
                    <div class="kerp-appointments-calendar-column__head">
                        <div class="kerp-appointments-calendar-column__title">
                            <div class="d-flex align-items-center" style="gap: 5px">
                                <strong><?php echo esc_html( $weekday_labels[ $day_index ] ?? '' ); ?></strong>
								<?php if ( $is_today ) : ?>
                                    <span
                                        class="badge badge-dim bg-primary"><?php esc_html_e( 'امروز', 'kasebi-erp' ); ?></span>
								<?php endif; ?>
                            </div>
                            <span class="sub-text"><?php echo esc_html( $display_date ); ?></span>
                        </div>

                        <div class="d-flex align-items-center g-1">
			<span class="badge badge-dim bg-light">
				<?php echo esc_html( number_format_i18n( count( $day_items ) ) ); ?>
			</span>
							
							<?php if ( $can_create && $has_free_slots ) : ?>
                                <div class="dropdown">
                                    <button type="button"
                                            class="btn btn-sm btn-icon btn-trigger dropdown-toggle"
                                            data-bs-toggle="dropdown"
                                            aria-expanded="false"
                                            aria-label="<?php echo esc_attr( sprintf( __( 'افزودن %s', 'kasebi-erp' ), $settings->get_appointment_singular_label() ) ); ?>">
                                        <em class="icon ni ni-plus"></em>
                                    </button>

                                    <div class="dropdown-menu dropdown-menu-end">
                                        <ul class="link-list-opt no-bdr">
                                            <li>
                                                <a href="#appointmentModal"
                                                   class="open_populate_modal"
                                                   data-modal="#appointmentModal"
                                                   data-populate="<?php echo esc_attr( wp_json_encode( $add_populate ) ); ?>">
                                                    <em class="icon ni ni-calendar-booking"></em>
                                                    <span><?php echo esc_html( sprintf( __( 'ثبت %s در این روز', 'kasebi-erp' ), $settings->get_appointment_singular_label() ) ); ?></span>
                                                </a>
                                            </li>
											
											<?php
											$first_employee_id = 0;
											$first_slot        = [];
											
											foreach ( $free_slot_groups as $slot_employee_id => $employee_slots ) {
												if ( empty( $employee_slots ) ) {
													continue;
												}
												
												$first_employee_id = absint( $slot_employee_id );
												$first_slot        = reset( $employee_slots );
												
												break;
											}
											?>
											
											<?php if ( ! empty( $first_slot ) ) : ?>
												<?php
												$first_slot_time     = (string) ( $first_slot['time'] ?? '' );
												$first_slot_populate = $add_populate;
												
												$first_slot_populate['employee']     = [
													'id'    => '#kerp-appointment-employee',
													'type'  => 'select',
													'value' => $first_employee_id,
												];
												$first_slot_populate['date']['data'] = [
													'time' => $first_slot_time,
												];
												?>

                                                <li class="divider"></li>
                                                <li>
                                                    <a href="#appointmentModal"
                                                       class="open_populate_modal"
                                                       data-modal="#appointmentModal"
                                                       data-populate="<?php echo esc_attr( wp_json_encode( $first_slot_populate ) ); ?>">
                                                        <em class="icon ni ni-clock"></em>
                                                        <span><?php echo esc_html(
																sprintf(
																	__( 'اولین ساعت آزاد: %s', 'kasebi-erp' ),
																	$first_slot_time
																)
															);
															?></span>
                                                    </a>
                                                </li>
											<?php endif; ?>
                                        </ul>
                                    </div>
                                </div>
							<?php endif; ?>
                        </div>
                    </div>
					
					<?php if ( $can_show_free ) : ?>
                        <div class="kerp-appointments-calendar-slots">
                            <div class="kerp-appointments-calendar-slots__head">
                                <span><em class="icon ni ni-clock"></em>
                                    <?php esc_html_e( 'ساعت‌های آزاد', 'kasebi-erp' ); ?></span>
                                <span
                                    class="sub-text"><?php echo esc_html( number_format_i18n( $total_free_slots ) ); ?></span>
                            </div>
							
							<?php if ( ! $has_free_slots ) : ?>
                                <div class="kerp-appointments-calendar-slots__empty">
									<?php esc_html_e( 'زمان آزادی وجود ندارد.', 'kasebi-erp' ); ?>
                                </div>
							<?php else : ?>
                                <div class="kerp-appointments-calendar-slots__list">
                                    <div class="kerp-appointments-calendar-slots__list_inner">
										<?php
										$free_slot_group_ids = array_keys( $free_slot_groups );
										$first_employee_id   = absint( reset( $free_slot_group_ids ) );
										$tabs_id             = 'appointment-slots-' . sanitize_html_class( $date_key );
										?>

                                        <ul class="nav nav-tabs kerp-appointments-free-slot-tabs" role="tablist">
											<?php foreach ( $free_slot_groups as $slot_employee_id => $employee_slots ) : ?>
												<?php
												$slot_employee_id = absint( $slot_employee_id );
												$employee_name    = get_user_name_by_id( $slot_employee_id );
												$is_active        = $slot_employee_id === $first_employee_id;
												$tab_id           = $tabs_id . '-employee-' . $slot_employee_id;
												?>
                                                <li class="nav-item" role="presentation">
                                                    <button type="button"
                                                            class="nav-link<?php echo $is_active ? ' active' : ''; ?>"
                                                            data-bs-toggle="tab"
                                                            data-bs-target="#<?php echo esc_attr( $tab_id ); ?>"
                                                            role="tab"
                                                            aria-selected="<?php echo $is_active ? 'true' : 'false'; ?>">
                                                        <span><?php echo esc_html( $employee_name ); ?></span>
                                                        <small>
															<?php echo esc_html( number_format_i18n( count( $employee_slots ) ) ); ?>
                                                        </small>
                                                    </button>
                                                </li>
											<?php endforeach; ?>
                                        </ul>
                                        <div class="tab-content kerp-appointments-free-slot-tab-content">
											<?php foreach ( $free_slot_groups as $slot_employee_id => $employee_slots ) : ?>
												<?php
												$slot_employee_id = absint( $slot_employee_id );
												$is_active        = $slot_employee_id === $first_employee_id;
												$tab_id           = $tabs_id . '-employee-' . $slot_employee_id;
												?>
                                                <div id="<?php echo esc_attr( $tab_id ); ?>"
                                                     class="tab-pane fade<?php echo $is_active ? ' show active' : ''; ?>"
                                                     role="tabpanel">
                                                    <div class="kerp-appointments-free-slot-group__scroll"
                                                         data-simplebar>
                                                        <div class="kerp-appointments-free-slot-group__slots">
															<?php foreach ( $employee_slots as $slot ) : ?>
																<?php
																$slot_time     = (string) ( $slot['time'] ?? '' );
																$slot_populate = $add_populate;
																
																$slot_populate['employee'] = [
																	'id'    => '#kerp-appointment-employee',
																	'type'  => 'select',
																	'value' => $slot_employee_id,
																];
																
																$slot_populate['date']['data'] = [
																	'time' => $slot_time,
																];
																?>
																
																<?php if ( $can_create ) : ?>
                                                                    <a href="#appointmentModal"
                                                                       class="kerp-appointments-free-slot open_populate_modal"
                                                                       data-modal="#appointmentModal"
                                                                       data-populate="<?php echo esc_attr( wp_json_encode( $slot_populate ) ); ?>">
                                                                        <span><?php echo esc_html( $slot_time ); ?></span>
																		
																		<?php if ( absint( $slot['remaining'] ?? 0 ) > 1 ) : ?>
                                                                            <small>
																				<?php echo esc_html( number_format_i18n( absint( $slot['remaining'] ) ) ); ?>
                                                                            </small>
																		<?php endif; ?>
                                                                    </a>
																<?php else : ?>
                                                                    <span class="kerp-appointments-free-slot">
										<span><?php echo esc_html( $slot_time ); ?></span>

										<?php if ( absint( $slot['remaining'] ?? 0 ) > 1 ) : ?>
                                            <small>
												<?php echo esc_html( number_format_i18n( absint( $slot['remaining'] ) ) ); ?>
											</small>
										<?php endif; ?>
									</span>
																<?php endif; ?>
															<?php endforeach; ?>
                                                        </div>
                                                    </div>
                                                </div>
											<?php endforeach; ?>
                                        </div>
                                    </div>
                                </div>
							<?php endif; ?>
                        </div>
					<?php endif; ?>
                    <div class="kerp-appointments-calendar-column__body">
						<?php if ( empty( $day_items ) ) : ?>
                            <div class="kerp-appointments-calendar-empty">
                                <em class="icon ni ni-calendar"></em>
                                <span><?php echo esc_html( sprintf( __( '%s برای این روز ثبت نشده است.', 'kasebi-erp' ), $settings->get_appointment_singular_label() ) ); ?></span>
                            </div>
						<?php endif; ?>
						
						<?php foreach ( $day_items as $appointment ) : ?>
							<?php
							$status      = $settings->get_status( (string) ( $appointment['status'] ?? '' ) );
							$color       = sanitize_key( (string) ( $status['color'] ?? 'primary' ) ) ?: 'primary';
							$status_name = (string) ( $status['label'] ?? $appointment['status'] ?? '' );
							$icon        = (string) ( $appointment['service_icon'] ?? 'ni ni-calendar-booking' );
							$start       = strtotime( (string) ( $appointment['start_at'] ?? '' ) );
							$end         = strtotime( (string) ( $appointment['end_at'] ?? '' ) );
							$start_time  = $start !== FALSE ? date( 'H:i', $start ) : '';
							$end_time    = $end !== FALSE ? date( 'H:i', $end ) : '';
							
							$edit_populate = [
								'appointment_id' => [
									'id'    => '#kerp-appointment-id',
									'type'  => 'text',
									'value' => absint( $appointment['id'] ?? 0 ),
								],
								'return_page'    => [
									'id'    => '#kerp-appointment-return-page',
									'type'  => 'text',
									'value' => $return_page,
								],
								'customer_id'    => [
									'id'    => '#kerp-appointment-customer-id',
									'type'  => 'customer-search',
									'value' => absint( $appointment['customer_id'] ?? 0 ),
									'data'  => [
										'customer-name'  => (string) ( $appointment['customer_name'] ?? '' ),
										'customer-phone' => (string) ( $appointment['customer_phone'] ?? '' ),
									],
								],
								'date'           => [
									'id'    => '#kerp-appointment-date',
									'type'  => 'text',
									'value' => date_i18n( 'Y-m-d', strtotime( $date_key ) ),
									'data'  => [
										'time' => $start_time,
									],
								],
								'service'        => [
									'id'    => '#kerp-appointment-service',
									'type'  => 'select',
									'value' => absint( $appointment['service_id'] ?? 0 ),
									'data'  => [
										'employee' => absint( $appointment['employee_id'] ?? 0 ),
									],
								],
								'employee'       => [
									'id'    => '#kerp-appointment-employee',
									'type'  => 'select',
									'value' => absint( $appointment['employee_id'] ?? 0 ),
								],
								'quantity'       => [
									'id'    => '#kerp-appointment-quantity',
									'type'  => 'text',
									'value' => absint( $appointment['quantity'] ?? 1 ),
								],
								'status'         => [
									'id'    => '#kerp-appointment-status',
									'type'  => 'select',
									'value' => (string) ( $appointment['status'] ?? '' ),
								],
								'location_type'  => [
									'id'    => '#kerp-appointment-location-type',
									'type'  => 'select',
									'value' => (string) ( $appointment['location_type'] ?? '' ),
								],
								'location'       => [
									'id'    => '#kerp-appointment-location',
									'type'  => 'text',
									'value' => (string) ( $appointment['location'] ?? '' ),
								],
								'description'    => [
									'id'    => '#kerp-appointment-description',
									'type'  => 'text',
									'value' => (string) ( $appointment['description'] ?? '' ),
								],
								'internal_note'  => [
									'id'    => '#kerp-appointment-internal-note',
									'type'  => 'text',
									'value' => (string) ( $appointment['internal_note'] ?? '' ),
								],
							];
							?>

                            <a href="#"
                               class="card card-bordered kerp-appointments-calendar-item<?php echo $can_edit ? ' edit_row_item ' : ''; ?>"
								<?php if ( $can_edit ) : ?>
                                    data-modal="#appointmentModal"
                                    data-customer-name="<?php echo esc_attr( (string) ( $appointment['customer_name'] ?? '' ) ); ?>"
                                    data-customer-phone="<?php echo esc_attr( (string) ( $appointment['customer_phone'] ?? '' ) ); ?>"
                                    data-populate="<?php echo esc_attr( wp_json_encode( $edit_populate ) ); ?>"
								<?php endif; ?>>

                                <div class="kerp-appointments-calendar-item__head">
                                    <span class="kerp-appointments-calendar-item__time">
                                        <?php echo esc_html( $start_time ); ?>
                                        <?php if ( $end_time !== '' ) : echo ' - ' . esc_html( $end_time ); endif; ?>
                                    </span>

                                    <span class="badge badge-dim bg-<?php echo esc_attr( $color ); ?>">
						<?php echo esc_html( $status_name ); ?>
					</span>
                                </div>

                                <div class="kerp-appointments-calendar-item__service">
					<span
                        class="user-avatar xs bg-<?php echo esc_attr( $color ); ?>-dim text-<?php echo esc_attr( $color ); ?>">
						<em class="<?php echo esc_attr( $icon ); ?>"></em>
					</span>

                                    <strong>
										<?php echo esc_html( (string) ( $appointment['service_title'] ?? '' ) ); ?>
                                    </strong>
                                </div>
								
								<?php if ( trim( (string) ( $appointment['customer_name'] ?? '' ) ) !== '' ) : ?>
                                    <div class="kerp-appointments-calendar-item__meta">
                                        <em class="icon ni ni-user"></em>
                                        <span><?php echo esc_html( (string) $appointment['customer_name'] ); ?></span>
                                    </div>
								<?php endif; ?>
								
								<?php if ( trim( (string) ( $appointment['employee_name'] ?? '' ) ) !== '' ) : ?>
                                    <div class="kerp-appointments-calendar-item__meta">
                                        <em class="icon ni ni-account-setting"></em>
                                        <span><?php echo esc_html( (string) $appointment['employee_name'] ); ?></span>
                                    </div>
								<?php endif; ?>
                            </a>
						<?php endforeach; ?>
                    </div>
                </div>
			<?php endfor; ?>
        </div>
    </div>
</div>
