<?php

defined( 'ABSPATH' ) || exit;

$page_context = isset( $page_context ) && is_array( $page_context )
	? $page_context
	: [];
$page_query   = isset( $page_context['query'] ) && is_array( $page_context['query'] )
	? $page_context['query']
	: [];
$date_filter  = isset( $page_query['date'] ) && is_array( $page_query['date'] )
	? $page_query['date']
	: [];

$settings      = KERP_Modules_Appointments_Settings::instance();
$query_service = KERP_Modules_Appointments_Query::instance();
$list_table    = KERP_Modules_Appointments_List_Table::instance();
$page_route    = '/erp/appointments/';
$per_page      = KERP_Helpers_Pagination::resolve_per_page(
	basename( __FILE__, '.php' ),
	$page_query,
	(int) $settings->get( 'default_per_page', 20 ),
	200
);
$status_filter = sanitize_key( (string) ( $page_query['status'] ?? '' ) );
$source_filter = sanitize_key( (string) ( $page_query['source'] ?? '' ) );

// Empty select placeholders are posted as "0" by older cached app scripts.
$status_filter = $status_filter === '0' ? '' : $status_filter;
$source_filter = $source_filter === '0' ? '' : $source_filter;

$query_args    = [
	'customer_id' => absint( $page_query['customer_id'] ?? 0 ),
	'service_id'  => absint( $page_query['service_id'] ?? 0 ),
	'employee_id' => absint( $page_query['employee_id'] ?? 0 ),
	'status'      => $status_filter,
	'source'      => $source_filter,
	'search'      => sanitize_text_field( (string) ( $page_query['search'] ?? '' ) ),
	'date_from'   => sanitize_text_field( (string) ( $date_filter['from'] ?? '' ) ),
	'date_to'     => sanitize_text_field( (string) ( $date_filter['to'] ?? '' ) ),
	'public_fields' => KERP_Modules_Appointments_Public_Fields::instance()->get_filter_values( $page_query ),
	'page_number' => max( 1, absint( $page_query['page_number'] ?? 1 ) ),
	'per_page'    => $per_page,
	'order'       => strtoupper( (string) ( $page_query['order'] ?? 'ASC' ) ) === 'DESC' ? 'DESC' : 'ASC',
];
$result        = $query_service->find( $query_args );
$appointments  = (array) ( $result['items'] ?? [] );
$total         = absint( $result['total'] ?? 0 );
$total_pages   = max( 1, absint( $result['total_pages'] ?? 1 ) );
$page_number   = max( 1, absint( $result['page_number'] ?? 1 ) );
$filters       = $list_table->get_filters(
	array_merge(
		$page_query,
		[
			'date' => $date_filter,
		]
	)
);
$has_filter    = ! empty(
array_filter(
	[
		$query_args['customer_id'],
		$query_args['service_id'],
		$query_args['employee_id'],
		$query_args['status'],
		$query_args['source'],
		$query_args['search'],
		$query_args['date_from'],
		$query_args['date_to'],
		$query_args['public_fields'],
	]
)
);
?>
    <div class="nk-block-head nk-block-head-sm">
        <div class="nk-block-between">
            <div class="nk-block-head-content">
                <h3 class="nk-block-title page-title">
					<?php echo esc_html( $settings->get_appointment_plural_label() ); ?>
                </h3>
                <div class="nk-block-des text-soft">
                    <p>
						<?php
						printf(
							esc_html__( 'در مجموع %s مورد ثبت شده است.', 'kasebi-erp' ),
							esc_html( number_format_i18n( $total ) )
						);
						?>
                    </p>
                </div>
            </div>
            <div class="nk-block-head-content">
                <a href="/erp/appointments/calendar/"
                   class="btn btn-light page_activator"
                   data-url="/erp/appointments/calendar/">
                    <em class="ni ni-calendar-alt icon"></em>
                    <span><?php esc_html_e( 'تقویم', 'kasebi-erp' ); ?></span>
                </a>
            </div>
        </div>
    </div>

    <div class="nk-block">
        <div class="card card-bordered">
            <div class="card-inner position-relative card-tools-toggle">
                <div class="card-title-group">
                    <div class="card-tools">
                        <span
                            class="text-soft"><?php echo esc_html( sprintf( __( 'فهرست %s', 'kasebi-erp' ), $settings->get_appointment_plural_label() ) ); ?></span>
                    </div>
                    <div class="card-tools">
                        <ul class="btn-toolbar">
                            <li>
								<?php
								echo KERP_Helpers_Template::get_template(
									'app/components/list/filter-dropdown.php',
									[
										'has_filter'    => $has_filter,
										'filter_fields' => $filters,
										'action'        => 'erp_request_page_content',
										'page'          => $page_route,
									]
								);
								?>
                            </li>
                            <li class="btn-toolbar-sep"></li>
                            <li>
								<?php
								echo KERP_Helpers_Template::get_template(
									'app/components/list/per-page-selector.php',
									[
										'per_page'            => $per_page,
										'available_per_pages' => [ 10, 20, 50, 100 ],
										'action'              => 'erp_request_page_content',
										'page'                => $page_route,
									]
								);
								?>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="nk-block">
		<?php if ( empty( $appointments ) ) : ?>
            <div class="card card-bordered">
                <div class="card-inner text-center py-5">
                    <em class="ni ni-calendar-booking fs-1 text-soft"></em>
                    <h5 class="mt-3 mb-1"><?php echo esc_html( sprintf( __( '%s پیدا نشد.', 'kasebi-erp' ), $settings->get_appointment_singular_label() ) ); ?></h5>
                    <p class="text-soft mb-0"><?php esc_html_e( 'برای مشاهده نتایج دیگر، فیلترهای جستجو را تغییر دهید.', 'kasebi-erp' ); ?></p>
                </div>
            </div>
		<?php else : ?>
            <div class="row g-3 kerp-appointments-card-grid">
				<?php foreach ( $appointments as $appointment ) : ?>
                    <div class="col-12 col-xl-6 col-xxl-4">
						<?php
						KERP_Helpers_Template::render_template(
							'modules/appointments/partials/appointment-card.php',
							[
								'appointment' => $appointment,
								'return_page' => $page_route,
								'context'     => 'main',
							]
						);
						?>
                    </div>
				<?php endforeach; ?>
            </div>
		<?php endif; ?>
    </div>

<?php if ( $total_pages > 1 ) : ?>
    <div class="nk-block">
        <div class="card card-bordered">
            <div class="card-inner">
				<?php
				echo KERP_Helpers_Template::get_template(
					'app/components/list/pagination.php',
					[
						'max_page_num' => $total_pages,
						'current_page' => $page_number,
						'class_name'   => 'appointments_pagination_link',
						'show_count'   => 2,
						'action'       => 'erp_request_page_content',
						'page'         => $page_route,
					]
				);
				?>
            </div>
        </div>
    </div>
<?php endif; ?>
