<?php

defined( 'ABSPATH' ) || exit;

$page_context       = isset( $page_context ) && is_array( $page_context ) ? $page_context : [];
$page_query         = isset( $page_context['query'] ) && is_array( $page_context['query'] ) ? $page_context['query'] : [];
$page_route         = '/erp/activities/';
$occurred           = isset( $page_query['occurred'] ) && is_array( $page_query['occurred'] ) ? $page_query['occurred'] : [];
$per_page           = KERP_Helpers_Pagination::resolve_per_page(
	basename( __FILE__, '.php' ),
	$page_query,
	(int) KERP_Modules_Activities_Settings::instance()->get( 'default_per_page', 20 ),
	200
);
$query_args         = [
	'type_key'    => sanitize_key( (string) ( $page_query['type_key'] ?? '' ) ),
	'created_by'  => absint( $page_query['created_by'] ?? 0 ),
	'search'      => sanitize_text_field( (string) ( $page_query['search'] ?? '' ) ),
	'date_from'   => sanitize_text_field( (string) ( $occurred['from'] ?? '' ) ),
	'date_to'     => sanitize_text_field( (string) ( $occurred['to'] ?? '' ) ),
	'page_number' => max( 1, absint( $page_query['page_number'] ?? 1 ) ),
	'per_page'    => $per_page,
	'order'       => 'DESC',
];
$result             = KERP_Modules_Activities_Query::instance()->find( $query_args );
$activities         = (array) ( $result['items'] ?? [] );
$total              = absint( $result['total'] ?? 0 );
$page_number        = max( 1, absint( $result['page_number'] ?? 1 ) );
$total_pages        = max( 1, absint( $result['total_pages'] ?? 1 ) );
$per_page           = max( 1, absint( $result['per_page'] ?? 20 ) );
$filters            = KERP_Modules_Activities_List_Table::instance()
                                                        ->get_filters( array_merge( $page_query, [ 'occurred' => $occurred ] ) );
$has_filter         = ! empty( array_filter( [
	$query_args['type_key'],
	$query_args['created_by'],
	$query_args['search'],
	$query_args['date_from'],
	$query_args['date_to'],
] ) );
$can_create         = kerp_can( 'activities.create', 'action' );
$customers_settings = KERP_Modules_Customers_Settings::instance();
$singular_label     = $customers_settings->get_singular_label();

?>
<div class="nk-block-head nk-block-head-sm">
    <div class="nk-block-between">
        <div class="nk-block-head-content"><h3
                class="nk-block-title page-title"><?php esc_html_e( 'فعالیت‌ها', 'kasebi-erp' ); ?></h3>
            <div class="nk-block-des text-soft">
                <p><?php printf( esc_html__( 'در مجموع %s فعالیت ثبت شده است.', 'kasebi-erp' ), esc_html( number_format_i18n( $total ) ) ); ?></p>
            </div>
        </div>
        <div class="nk-block-head-content">
			<?php if ( $can_create ) : ?>
                <a href="#activityModal" class="btn btn-primary" data-bs-toggle="modal"
                   data-bs-target="#activityModal">
                    <em class="icon ni ni-plus"></em>
                    <span><?php esc_html_e( 'افزودن فعالیت', 'kasebi-erp' ); ?></span>
                </a>
			<?php endif; ?>
        </div>
    </div>
</div>
<div class="nk-block">
    <div class="card card-stretch">
        <div class="card-inner-group">
            <div class="card-inner position-relative card-tools-toggle">
                <div class="card-title-group">
                    <div class="card-tools"><span
                            class="text-soft"><?php esc_html_e( 'فهرست فعالیت‌های ثبت‌شده', 'kasebi-erp' ); ?></span>
                    </div>
                    <div class="card-tools">
                        <ul class="btn-toolbar gx-1">
                            <li><?php echo KERP_Helpers_Template::get_template( 'app/components/list/filter-dropdown.php', [
									'has_filter'    => $has_filter,
									'filter_fields' => $filters,
									'action'        => 'erp_request_page_content',
									'page'          => $page_route,
								] ); ?></li>
                            <li class="btn-toolbar-sep"></li>
                            <li><?php echo KERP_Helpers_Template::get_template( 'app/components/list/per-page-selector.php', [
									'per_page'            => $per_page,
									'available_per_pages' => [
										10,
										20,
										50,
										100,
									],
									'action'              => 'erp_request_page_content',
									'page'                => $page_route,
								] ); ?></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="card-inner p-0">
                <div class="nk-tb-list nk-tb-ulist is-compact">
                    <div class="nk-tb-item nk-tb-head">
                        <div class="nk-tb-col">
                            <span class="sub-text"><?php echo esc_html( $singular_label ); ?></span>
                        </div>
                        <div class="nk-tb-col tb-col-md"><span
                                class="sub-text"><?php esc_html_e( 'نوع', 'kasebi-erp' ); ?></span></div>
                        <div class="nk-tb-col"><span
                                class="sub-text"><?php esc_html_e( 'عنوان', 'kasebi-erp' ); ?></span></div>
                        <div class="nk-tb-col tb-col-md"><span
                                class="sub-text"><?php esc_html_e( 'توضیحات', 'kasebi-erp' ); ?></span></div>
                        <div class="nk-tb-col nk-tb-col-tools"></div>
                    </div>
					<?php
					if ( empty( $activities ) ) {
						echo '  </div>';
						?>
                        <div class="card-inner text-center py-5">
                            <em class="kik fa-activity fs-1 text-soft"></em>
                            <h5 class="mt-3"><?php esc_html_e( 'فعالیتی یافت نشد.', 'kasebi-erp' ); ?></h5>
                        </div>
						<?php
						echo '  <div>';
					} else {
						foreach ( $activities as $activity ) {
							KERP_Helpers_Template::render_template( 'modules/activities/partials/list-row.php', [
								'activity'    => $activity,
								'return_page' => $page_route,
							] );
						}
					}
					?>
                </div>
            </div>
			<?php if ( $total_pages > 1 ) : ?>
                <div
                    class="card-inner"><?php echo KERP_Helpers_Template::get_template( 'app/components/list/pagination.php', [
					'max_page_num' => $total_pages,
					'current_page' => $page_number,
					'class_name'   => 'activities_pagination_link',
					'show_count'   => 2,
					'action'       => 'erp_request_page_content',
					'page'         => $page_route,
				] ); ?></div><?php endif; ?>
        </div>
    </div>
</div>
<?php if ( $can_create || kerp_can( 'activities.edit', 'action' ) ) : KERP_Modules_Activities_Form::instance()
                                                                                                  ->render_modal( 0, $page_route ); endif; ?>
