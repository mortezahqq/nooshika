<?php

defined( 'ABSPATH' ) || exit;

$settings         = KERP_Modules_Activities_Settings::instance()->all();
$types            = array_values( (array) ( $settings['types'] ?? [] ) );
$modal_id         = 'kerp-activity-type-modal';
$modal_selector   = '#' . $modal_id;
$default_per_page = max( 1, min( 200, absint( $settings['default_per_page'] ?? 20 ) ) );

if ( $types ) {
	$type_orders = array_column( $types, 'order' );
	array_multisort( $type_orders, SORT_ASC, SORT_NUMERIC, $types );
}

$active_types_count = 0;
foreach ( $types as $type ) {
	if ( is_array( $type ) && ! empty( $type['active'] ) ) {
		$active_types_count ++;
	}
}

$add_populate = [
	'original_key' => [ 'id' => '#kerp-activity-type-original-key', 'value' => '', 'type' => 'text' ],
	'key'          => [ 'id' => '#kerp-activity-type-key', 'value' => '', 'type' => 'text' ],
	'label'        => [ 'id' => '#kerp-activity-type-label', 'value' => '', 'type' => 'text' ],
	'icon'         => [ 'id' => '#kerp-activity-type-icon', 'value' => 'kik fa-activity', 'type' => 'text' ],
	'color'        => [ 'id' => '#kerp-activity-type-color', 'value' => 'primary', 'type' => 'select' ],
	'order'        => [ 'id' => '#kerp-activity-type-order', 'value' => 100, 'type' => 'text' ],
	'active'       => [ 'id' => '#kerp-activity-type-active', 'value' => '1', 'type' => 'switch' ],
];
?>
    <div class="kerp-settings-smart kerp-activities-settings">
        <div class="nk-block-head nk-block-head-sm">
            <div class="nk-block-between g-3">
                <div class="nk-block-head-content">
                    <h3 class="nk-block-title page-title"><?php esc_html_e( 'تنظیمات فعالیت‌ها', 'kasebi-erp' ); ?></h3>
                    <div class="nk-block-des text-soft">
                        <p><?php esc_html_e( 'نحوه نمایش فعالیت‌ها و نوع‌های قابل استفاده هنگام ثبت فعالیت را مدیریت کنید.', 'kasebi-erp' ); ?></p>
                    </div>
                </div>
                <div class="nk-block-head-content">
                    <button type="button" class="btn btn-primary open_populate_modal"
                            data-modal="<?php echo esc_attr( $modal_selector ); ?>"
                            data-modal-title="<?php esc_attr_e( 'افزودن نوع فعالیت', 'kasebi-erp' ); ?>"
                            data-submit-text="<?php esc_attr_e( 'افزودن نوع', 'kasebi-erp' ); ?>"
                            data-populate="<?php echo esc_attr( wp_json_encode( $add_populate ) ); ?>">
                        <em class="icon ni ni-plus"></em><span><?php esc_html_e( 'افزودن نوع فعالیت', 'kasebi-erp' ); ?></span>
                    </button>
                </div>
            </div>
        </div>

        <div class="nk-block">
			<?php
			KERP_Helpers_Template::render_template(
				'app/components/settings/hero.php',
				[
					'icon'        => 'kik fa-activity',
					'eyebrow'     => __( 'مدیریت فعالیت‌ها', 'kasebi-erp' ),
					'title'       => __( 'ساختار ثبت و نمایش فعالیت‌ها', 'kasebi-erp' ),
					'description' => __( 'نوع‌های فعالیت را متناسب با فرآیند کاری مجموعه تعریف کنید و تعداد ردیف‌های فهرست را کنترل کنید.', 'kasebi-erp' ),
					'stats'       => [
						[
							'label' => __( 'کل نوع‌ها', 'kasebi-erp' ),
							'value' => number_format_i18n( count( $types ) ),
						],
						[
							'label' => __( 'نوع فعال', 'kasebi-erp' ),
							'value' => number_format_i18n( $active_types_count ),
						],
						[
							'label' => __( 'نمایش در صفحه', 'kasebi-erp' ),
							'value' => number_format_i18n( $default_per_page ),
						],
					],
				]
			);
			?>
        </div>
        <div class="nk-block">
            <div class="kerp-settings-section-head">
                <div><h5 class="title mb-1"><?php esc_html_e( 'انواع فعالیت', 'kasebi-erp' ); ?></h5>
                    <p class="text-soft mb-0"><?php esc_html_e( 'هر نوع، هویت بصری و ترتیب مستقل خود را دارد.', 'kasebi-erp' ); ?></p>
                </div>
            </div>
			<?php if ( ! $types ) : ?>
				<?php
				KERP_Helpers_Template::render_template(
					'app/components/settings/empty-state.php',
					[
						'icon'        => 'kik fa-activity',
						'title'       => __( 'نوع فعالیتی ثبت نشده است.', 'kasebi-erp' ),
						'description' => __( 'برای شروع، اولین نوع فعالیت را ایجاد کنید.', 'kasebi-erp' ),
						'action'      => [
							'label'      => __( 'افزودن نوع فعالیت', 'kasebi-erp' ),
							'icon'       => 'icon ni ni-plus',
							'class'      => 'btn btn-primary open_populate_modal',
							'attributes' => [
								'data-modal'       => $modal_selector,
								'data-modal-title' => __( 'افزودن نوع فعالیت', 'kasebi-erp' ),
								'data-submit-text' => __( 'افزودن نوع', 'kasebi-erp' ),
								'data-populate'    => wp_json_encode( $add_populate ),
							],
						],
					]
				);
				?>
			<?php else : ?>
                <div class="row g-gs kerp-settings-item-grid">
					<?php foreach ( $types as $type ) : ?>
						<?php
						$type_key        = sanitize_key( (string) ( $type['key'] ?? '' ) );
						$type_label      = sanitize_text_field( (string) ( $type['label'] ?? $type_key ) );
						$type_icon       = sanitize_text_field( (string) ( $type['icon'] ?? 'kik fa-activity' ) );
						$type_color      = sanitize_key( (string) ( $type['color'] ?? 'primary' ) );
						$type_text_color = $type_color === 'light' ? 'dark' : $type_color;
						$type_order      = absint( $type['order'] ?? 100 );
						$type_active     = ! empty( $type['active'] );
						if ( $type_key === '' ) {
							continue;
						}
						$edit_populate = [
							'original_key' => [
								'id'    => '#kerp-activity-type-original-key',
								'value' => $type_key,
								'type'  => 'text',
							],
							'key'          => [
								'id'    => '#kerp-activity-type-key',
								'value' => $type_key,
								'type'  => 'text',
							],
							'label'        => [
								'id'    => '#kerp-activity-type-label',
								'value' => $type_label,
								'type'  => 'text',
							],
							'icon'         => [
								'id'    => '#kerp-activity-type-icon',
								'value' => $type_icon,
								'type'  => 'text',
							],
							'color'        => [
								'id'    => '#kerp-activity-type-color',
								'value' => $type_color,
								'type'  => 'select',
							],
							'order'        => [
								'id'    => '#kerp-activity-type-order',
								'value' => $type_order,
								'type'  => 'text',
							],
							'active'       => [
								'id'    => '#kerp-activity-type-active',
								'value' => $type_active ? '1' : '0',
								'type'  => 'switch',
							],
						];
						?>
						<?php
						KERP_Helpers_Template::render_template(
							'app/components/settings/item-card.php',
							[
								'icon'        => $type_icon . ' icon',
								'icon_class'  => 'bg-' . $type_color . '-dim text-' . $type_text_color,
								'label'       => $type_label,
								'key'         => $type_key,
								'active'      => $type_active,
								'description' => __( 'این نوع هنگام ثبت و فیلتر فعالیت‌ها قابل انتخاب است.', 'kasebi-erp' ),
								'actions'     => [
									[
										'label'      => __( 'ویرایش', 'kasebi-erp' ),
										'icon'       => 'icon ni ni-edit',
										'class'      => 'edit_row_item',
										'attributes' => [
											'data-modal'       => $modal_selector,
											'data-modal-title' => __( 'ویرایش نوع فعالیت', 'kasebi-erp' ),
											'data-submit-text' => __( 'ذخیره تغییرات', 'kasebi-erp' ),
											'data-populate'    => wp_json_encode( $edit_populate ),
										],
									],
									[
										'label'          => __( 'حذف', 'kasebi-erp' ),
										'icon'           => 'icon ni ni-trash',
										'class'          => 'delete_db_item',
										'divider_before' => TRUE,
										'attributes'     => [
											'data-action'  => 'activities_delete_type',
											'data-page'    => '/erp/settings/activities/',
											'data-key'     => $type_key,
											'data-item_id' => $type_key,
										],
									],
								],
								'footer'      => [
									[
										'icon' => 'icon ni ni-sort-v',
										'text' => sprintf( __( 'ترتیب %s', 'kasebi-erp' ), number_format_i18n( $type_order ) ),
									],
									[ 'icon' => 'icon ni ni-flag', 'text' => $type_color ],
								],
							]
						);
						?>
					<?php endforeach; ?>
                </div>
			<?php endif; ?>
        </div>
    </div>
<?php
KERP_Helpers_Template::render_modal(
	[
		'id'     => $modal_id,
		'title'  => __( 'افزودن یا ویرایش نوع فعالیت', 'kasebi-erp' ),
		'action' => 'activities_save_type',
		'page'   => '/erp/settings/activities/',
		'button' => __( 'ذخیره', 'kasebi-erp' ),
		'size'   => 'lg',
		'fields' => [
			[
				'id'          => 'kerp-activity-type-original-key',
				'name'        => 'type[original_key]',
				'type'        => 'hidden',
				'input_class' => 'no_clear',
				'value'       => '',
			],
			[
				'id'          => 'kerp-activity-type-key',
				'name'        => 'type[key]',
				'label'       => __( 'کلید انگلیسی', 'kasebi-erp' ),
				'description' => __( 'یک کلید یکتا مانند call یا meeting وارد کنید.', 'kasebi-erp' ),
				'type'        => 'text',
				'class'       => 'col-md-6',
				'input_class' => 'kerp-settings-key-input',
				'value'       => '',
				'required'    => TRUE,
			],
			[
				'id'       => 'kerp-activity-type-label',
				'name'     => 'type[label]',
				'label'    => __( 'عنوان', 'kasebi-erp' ),
				'type'     => 'text',
				'class'    => 'col-md-6',
				'value'    => '',
				'required' => TRUE,
			],
			[
				'id'          => 'kerp-activity-type-icon',
				'name'        => 'type[icon]',
				'label'       => __( 'کلاس آیکون', 'kasebi-erp' ),
				'description' => __( 'نمونه: kik fa-activity یا ni ni-call', 'kasebi-erp' ),
				'type'        => 'text',
				'class'       => 'col-md-6',
				'input_class' => 'kerp-settings-icon-input',
				'value'       => 'kik fa-activity',
			],
			[
				'id'          => 'kerp-activity-type-color',
				'name'        => 'type[color]',
				'label'       => __( 'رنگ', 'kasebi-erp' ),
				'type'        => 'select',
				'class'       => 'col-md-6',
				'input_class' => 'kerp-settings-color-input',
				'value'       => 'primary',
				'options'     => [
					'primary'   => __( 'اصلی', 'kasebi-erp' ),
					'success'   => __( 'سبز', 'kasebi-erp' ),
					'info'      => __( 'آبی', 'kasebi-erp' ),
					'warning'   => __( 'هشدار', 'kasebi-erp' ),
					'danger'    => __( 'قرمز', 'kasebi-erp' ),
					'secondary' => __( 'ثانویه', 'kasebi-erp' ),
					'purple'    => __( 'بنفش', 'kasebi-erp' ),
					'light'     => __( 'روشن', 'kasebi-erp' ),
				],
			],
			[
				'id'    => 'kerp-activity-type-order',
				'name'  => 'type[order]',
				'label' => __( 'ترتیب نمایش', 'kasebi-erp' ),
				'type'  => 'number',
				'class' => 'col-md-6',
				'value' => 100,
				'min'   => 0,
			],
			[
				'id'          => 'kerp-activity-type-active-empty',
				'name'        => 'type[active]',
				'type'        => 'hidden',
				'input_class' => 'no_clear',
				'value'       => '0',
			],
			[
				'id'    => 'kerp-activity-type-active',
				'name'  => 'type[active]',
				'label' => __( 'فعال باشد', 'kasebi-erp' ),
				'type'  => 'switch',
				'class' => 'col-md-6 align-self-end',
				'value' => '1',
			],
		],
	]
);
