<?php

defined( 'ABSPATH' ) || exit;

$activity     = isset( $activity ) && is_array( $activity ) ? $activity : [];
$type         = KERP_Modules_Activities_Settings::instance()
                                                ->get_type( (string) ( $activity['type_key'] ?? '' ) );
$created_by   = get_userdata( absint( $activity['created_by'] ?? 0 ) );
$created_name = $created_by instanceof WP_User ? get_user_name_by_id( $created_by->ID ) : __( 'کاربر حذف‌شده', 'kasebi-erp' );
$populate     = KERP_Modules_Activities_Module::instance()->get_populate_data( $activity );
$return_page  = isset( $return_page ) && is_string( $return_page ) ? $return_page : '/erp/activities/';
$metadata     = is_array( $activity['metadata'] ) ? $activity['metadata'] : [];
$attachments  = esc_url_raw( (string) ( $metadata['attachment'] ?? '' ) );

$occurred_timestamp = strtotime( (string) ( $activity['occurred_at'] ?? '' ) );
$occurred_display   = $occurred_timestamp ? date_i18n( 'j F Y H:i', $occurred_timestamp ) : '—';
?>
<div class="timeline-item">
    <div class="timeline-status bg-<?php echo esc_attr( (string) ( $type['color'] ?? 'light' ) ); ?> is-outline"></div>
    <div class="timeline-date lh-lg"><?php echo esc_html( $occurred_display ); ?></div>
    <div class="timeline-data">
        <div class="d-flex align-items-start justify-content-between g-2">
            <div>
                <h6 class="timeline-title mb-1"><em
                        class="<?php echo esc_attr( (string) ( $type['icon'] ?? '' ) ); ?> me-1"></em><?php echo esc_html( (string) ( $activity['title'] ?? '' ) ); ?>
                </h6>
                <div class="text-soft small mb-2"><?php echo esc_html( (string) ( $type['label'] ?? '' ) ); ?>
                    · <?php echo esc_html( $created_name ); ?></div>
            </div>
			<?php if ( kerp_can( 'activities.edit', 'action' ) || kerp_can( 'activities.delete', 'action' ) ) : ?>
                <div class="dropdown"><a href="#" class="btn btn-sm btn-icon btn-trigger" data-bs-toggle="dropdown"><em
                            class="icon ni ni-more-h"></em></a>
                    <div class="dropdown-menu dropdown-menu-end">
                        <ul class="link-list-opt no-bdr">
							<?php if ( kerp_can( 'activities.edit', 'action' ) ) : ?>
                                <li><a href="#" class="edit_row_item" data-modal="#customerActivityModal"
                                       data-populate="<?php echo esc_attr( wp_json_encode( $populate ) ); ?>"><em
                                        class="icon ni ni-edit"></em><span><?php esc_html_e( 'ویرایش', 'kasebi-erp' ); ?></span></a>
                                </li><?php endif; ?>
							<?php if ( kerp_can( 'activities.delete', 'action' ) ) : ?>
                                <li><a href="#" class="delete_db_item" data-action="activities_delete"
                                       data-page="<?php echo esc_attr( $return_page ); ?>"
                                       data-activity_id="<?php echo esc_attr( (string) $activity['id'] ); ?>"
                                       data-item_id="<?php echo esc_attr( (string) $activity['id'] ); ?>"><em
                                        class="icon ni ni-trash"></em><span><?php esc_html_e( 'حذف', 'kasebi-erp' ); ?></span></a>
                                </li><?php endif; ?>
                        </ul>
                    </div>
                </div>
			<?php endif; ?>
        </div>
		<?php if ( trim( (string) ( $activity['content'] ?? '' ) ) !== '' ) : ?>
            <div class="timeline-des mt-2"><?php echo wp_kses_post( (string) $activity['content'] ); ?></div>
		<?php
		endif;
		if ( $attachments !== '' ) {
			$attachments = array_filter(
				array_map(
					'trim',
					explode( ',', $attachments )
				)
			);
			?>
            <div class="mt-3 d-flex flex-wrap" style="gap: 10px">
				<?php
				foreach ( $attachments as $attachment ) {
					$attachment = esc_url_raw( $attachment );
					
					if ( $attachment === '' ) {
						continue;
					}
					
					$file_data = KERP_Api_File_Upload::instance()
					                                 ->get_uploaded_file_data( $attachment );
					
					$file_path = wp_parse_url( $attachment, PHP_URL_PATH );
					$file_name = ! empty( $file_data['original_name'] )
						? (string) $file_data['original_name']
						: urldecode( wp_basename( (string) $file_path ) );
					?>
                    <a href="<?php echo esc_url( $attachment ); ?>"
                       class="btn btn-sm btn-dim btn-outline-primary"
                       target="_blank"
                       rel="noopener"
                       download>
                        <em class="icon ni ni-clip me-1"></em>
                        <span class="text-truncate w-max-150px"><?php echo esc_html( $file_name ); ?></span>
                    </a>
					<?php
				}
				?>
            </div>
			<?php
		}
		?>
    </div>
</div>