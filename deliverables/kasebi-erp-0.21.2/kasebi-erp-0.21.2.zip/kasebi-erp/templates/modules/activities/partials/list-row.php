<?php

defined( 'ABSPATH' ) || exit;

$activity = isset( $activity ) && is_array( $activity ) ? $activity : [];
$type     = KERP_Modules_Activities_Settings::instance()->get_type(
	(string) ( $activity['type_key'] ?? '' )
);

$customer_id  = absint( $activity['customer_id'] ?? 0 );
$created_by   = get_userdata( absint( $activity['created_by'] ?? 0 ) );
$created_name = $created_by instanceof WP_User
	? get_user_name_by_id( $created_by->ID )
	: __( 'کاربر حذف‌شده', 'kasebi-erp' );
$can_delete   = kerp_can( 'activities.delete', 'action' );
$return_page  = isset( $return_page ) && is_string( $return_page )
	? $return_page
	: '/erp/activities/';

$customer_profile_route    = '/erp/customers/' . $customer_id . '/';
$customer_activities_route = $customer_profile_route . '?tab=activities';

$occurred_timestamp = strtotime( (string) ( $activity['occurred_at'] ?? '' ) );
$occurred_display   = $occurred_timestamp
	? date_i18n( 'j F Y، H:i', $occurred_timestamp )
	: '—';

$metadata    = is_array( $activity['metadata'] ?? NULL )
	? $activity['metadata']
	: [];
$attachments = array_filter(
	array_map(
		'trim',
		explode( ',', (string) ( $metadata['attachment'] ?? '' ) )
	)
);

$singular_label   = KERP_Modules_Customers_Settings::instance()->get_singular_label();
$activity_title   = (string) ( $activity['title'] ?? '' );
$activity_content = (string) ( $activity['content'] ?? '' );
$plain_content    = wp_strip_all_tags( $activity_content );
?>
<div class="nk-tb-item">
    <div class="nk-tb-col">
		<?php
		KERP_Helpers_Template::render_template(
			'app/components/user-card.php',
			[
				'user_id'    => $customer_id,
				'show_phone' => TRUE,
			]
		);
		?>
    </div>
    <div class="nk-tb-col tb-col-md">
		<span
            class="d-inline-flex align-center badge badge-dim bg-<?php echo esc_attr( (string) ( $type['color'] ?? 'light' ) ); ?>">
			<em class="<?php echo esc_attr( (string) ( $type['icon'] ?? '' ) ); ?> me-1"></em>
			<?php echo esc_html( (string) ( $type['label'] ?? '' ) ); ?>
		</span>
    </div>
    <div class="nk-tb-col">
        <span class="fw-medium"><?php echo esc_html( (string) ( $activity['title'] ?? '' ) ); ?></span>
    </div>
    <div class="nk-tb-col tb-col-md">
        <a href="#"
           class="show_public_content_modal kerp-activity-desc-trim"
           data-modal-title="<?php echo esc_attr( $activity_title ); ?>"
           data-content-target="#activity-content-<?php echo esc_attr( $activity['id'] ); ?>">
			<?php echo esc_html( $plain_content ); ?>
        </a>

        <div id="activity-content-<?php echo esc_attr( $activity['id'] ); ?>" class="d-none">
			<?php echo wp_kses_post( $activity_content ); ?>
        </div>
    </div>
    <div class="nk-tb-col">
        <ul class="nk-tb-actions gx-1">
            <li>
				<span class="btn btn-sm btn-icon btn-trigger"
                      data-bs-toggle="tooltip"
                      data-bs-placement="top"
                      title="<?php echo esc_attr( sprintf( __( 'تاریخ انجام: %s', 'kasebi-erp' ), $occurred_display ) ); ?>">
					<em class="icon ni ni-calendar"></em>
				</span>
            </li>
            <li>
				<span class="btn btn-sm btn-icon btn-trigger"
                      data-bs-toggle="tooltip"
                      data-bs-placement="top"
                      title="<?php echo esc_attr( sprintf( __( 'ثبت‌کننده: %s', 'kasebi-erp' ), $created_name ) ); ?>">
					<em class="icon ni ni-user"></em>
				</span>
            </li>
			<?php if ( $attachments ) : ?>
                <li>
                    <div class="dropdown">
                        <a href="#"
                           class="btn btn-sm btn-icon btn-trigger dropdown-toggle"
                           data-bs-toggle="dropdown"
                           title="<?php esc_attr_e( 'فایل‌های ضمیمه', 'kasebi-erp' ); ?>">
                            <span
                                class="badge badge-circle bg-primary"><?php echo esc_html( count( $attachments ) ); ?></span>
                            <em class="kik fa-file-attachment-04 icon p-0 m-0"></em>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end">
                            <ul class="link-list-opt no-bdr">
								<?php
								foreach ( $attachments as $attachment ) {
									$attachment = esc_url_raw( $attachment );
									
									if ( $attachment === '' ) {
										continue;
									}
									
									$file_data = KERP_Api_File_Upload::instance()
									                                 ->get_uploaded_file_data( $attachment );
									$file_path = wp_parse_url( $attachment, PHP_URL_PATH );
									$file_name = ! empty( $file_data['original_name'] )
										? (string) $file_data['original_name']
										: urldecode( wp_basename( (string) $file_path ) );
									?>
                                    <li>
                                        <a href="<?php echo esc_url( $attachment ); ?>"
                                           target="_blank"
                                           rel="noopener"
                                           download>
                                            <em class="icon ni ni-file-download"></em>
                                            <span><?php echo esc_html( $file_name ); ?></span>
                                        </a>
                                    </li>
									<?php
								}
								?>
                            </ul>
                        </div>
                    </div>
                </li>
			<?php endif; ?>
            <li>
                <div class="dropdown">
                    <a href="#"
                       class="dropdown-toggle btn btn-icon btn-trigger"
                       data-bs-toggle="dropdown">
                        <em class="icon ni ni-more-h"></em>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end">
                        <ul class="link-list-opt no-bdr">
                            <li>
                                <a href="<?php echo esc_url( home_url( $customer_profile_route ) ); ?>"
                                   class="page_activator"
                                   data-url="<?php echo esc_attr( $customer_profile_route ); ?>">
                                    <em class="icon ni ni-user-alt"></em>
                                    <span>
										<?php
										printf(
											esc_html__( 'مشخصات %s', 'kasebi-erp' ),
											esc_html( $singular_label )
										);
										?>
									</span>
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo esc_url( home_url( $customer_activities_route ) ); ?>"
                                   class="page_activator"
                                   data-url="<?php echo esc_attr( $customer_activities_route ); ?>">
                                    <em class="kik fa-activity icon"></em>
                                    <span><?php esc_html_e( 'تمام فعالیت‌ها', 'kasebi-erp' ); ?></span>
                                </a>
                            </li>
							<?php if ( $can_delete ) : ?>
                                <li class="divider"></li>
                                <li>
                                    <a href="#"
                                       class="delete_db_item"
                                       data-action="activities_delete"
                                       data-page="<?php echo esc_attr( $return_page ); ?>"
                                       data-activity_id="<?php echo esc_attr( (string) ( $activity['id'] ?? 0 ) ); ?>"
                                       data-item_id="<?php echo esc_attr( (string) ( $activity['id'] ?? 0 ) ); ?>">
                                        <em class="icon ni ni-trash"></em>
                                        <span><?php esc_html_e( 'حذف', 'kasebi-erp' ); ?></span>
                                    </a>
                                </li>
							<?php endif; ?>
                        </ul>
                    </div>
                </div>
            </li>
        </ul>
    </div>
</div>
