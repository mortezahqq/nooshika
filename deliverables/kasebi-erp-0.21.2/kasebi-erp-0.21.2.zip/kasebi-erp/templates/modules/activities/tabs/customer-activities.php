<?php

defined( 'ABSPATH' ) || exit;

$customer_id = absint( $customer_id ?? 0 );
$page_query  = isset( $page_context['query'] ) && is_array( $page_context['query'] ) ? $page_context['query'] : [];
$page_number = max( 1, absint( $page_query['page_number'] ?? 1 ) );
$return_page = add_query_arg( 'tab', 'activities', '/erp/customers/' . $customer_id . '/' );
$result      = KERP_Modules_Activities_Query::instance()->find( [
	'customer_id' => $customer_id,
	'page_number' => $page_number,
	'per_page'    => 20,
	'order'       => 'DESC',
] );
$activities  = (array) ( $result['items'] ?? [] );
$total       = absint( $result['total'] ?? 0 );
$total_pages = max( 1, absint( $result['total_pages'] ?? 1 ) );
?>
<div class="kerp-customer-tab-controls">
    <div class="d-lg-none kerp-customer-mobile-nav">
        <a href="#" class="toggle btn btn-icon btn-trigger" data-target="customerAside" aria-label="<?php esc_attr_e( 'نمایش منوی کاربر', 'kasebi-erp' ); ?>"><em class="icon ni ni-menu-alt-r"></em></a>
    </div>
	<?php if ( kerp_can( 'activities.create', 'action' ) ) : ?>
        <a href="#customerActivityModal" class="btn btn-dim btn-primary btn-icon" data-bs-toggle="modal" data-bs-target="#customerActivityModal" title="<?php esc_attr_e( 'افزودن فعالیت', 'kasebi-erp' ); ?>" aria-label="<?php esc_attr_e( 'افزودن فعالیت', 'kasebi-erp' ); ?>"><em class="icon ni ni-plus"></em></a>
	<?php endif; ?>
</div>
<?php KERP_Helpers_Template::render_template( 'app/components/customer-tab-hero.php', [
	'icon'        => 'kik fa-activity',
	'eyebrow'     => __( 'تعاملات مشتری', 'kasebi-erp' ),
	'title'       => __( 'فعالیت‌ها', 'kasebi-erp' ),
	'description' => sprintf( __( '%s فعالیت ثبت شده است.', 'kasebi-erp' ), number_format_i18n( $total ) ),
] ); ?>
<div class="nk-block">
    <div class="card card-bordered">
        <div class="card-inner">
			<?php if ( empty( $activities ) ) : ?>
                <div class="text-center py-5"><em class="kik fa-activity fs-1 text-soft"></em><h5
                    class="mt-3"><?php esc_html_e( 'هنوز فعالیتی برای این کاربر ثبت نشده است.', 'kasebi-erp' ); ?></h5>
                </div><?php else : ?>
                <div
                    class="timeline"><?php foreach ( $activities as $activity ) : KERP_Helpers_Template::render_template( 'modules/activities/partials/timeline-item.php', [
					'activity'    => $activity,
					'return_page' => $return_page,
				] ); endforeach; ?></div><?php endif; ?>
        </div><?php if ( $total_pages > 1 ) : ?>
            <div
                class="card-inner border-top"><?php echo KERP_Helpers_Template::get_template( 'app/components/list/pagination.php', [
				'max_page_num' => $total_pages,
				'current_page' => $page_number,
				'class_name'   => 'customer_activities_pagination_link',
				'show_count'   => 2,
				'action'       => 'erp_request_page_content',
				'page'         => $return_page,
			] ); ?></div><?php endif; ?></div>
</div>
