<?php

defined( 'ABSPATH' ) || exit;

$customer_id     = absint( $customer_id ?? 0 );
$return_page     = isset( $return_page ) && is_string( $return_page ) && $return_page !== '' ? $return_page : '/erp/activities/';
$modal_id        = sanitize_html_class( (string) ( $modal_id ?? 'activityModal' ) );
$current_time    = current_datetime();
$rounded_minutes = intdiv( (int) $current_time->format( 'i' ), 30 ) * 30;
$rounded_time    = $current_time
	->setTime(
		(int) $current_time->format( 'H' ),
		$rounded_minutes
	)
	->format( 'H:i' );
$singular_label  = KERP_Modules_Customers_Settings::instance()->get_singular_label();

$fields = [
	[
		'id'    => 'kerp-activity-id',
		'name'  => 'activity_id',
		'type'  => 'hidden',
		'class' => 'no_clear',
		'value' => '',
	],
];
if ( $customer_id ) {
	$fields[] = [
		'type'            => 'customer-search',
		'id'              => 'kerp-customer-activity-customer-id',
		'name'            => 'customer_id',
		'value'           => $customer_id,
		'required'        => TRUE,
		'hide_on_profile' => TRUE,
		'input_class'     => 'no_clear',
	];
} else {
	$fields[] = [
		'type'          => 'customer-search',
		'id'            => 'kerp-activity-customer-id',
		'name'          => 'customer_id',
		'value'         => 0,
		'required'      => TRUE,
		'preview_label' => sprintf(
			__( 'ثبت فعالیت برای %s:', 'kasebi-erp' ),
			$singular_label
		),
	];
}
$fields = array_merge( $fields, [
	[
		'id'       => 'kerp-activity-title',
		'name'     => 'title',
		'label'    => __( 'عنوان', 'kasebi-erp' ),
		'type'     => 'text',
		'class'    => 'col-md-6',
		'value'    => '',
		'required' => TRUE,
	],
	[
		'id'          => 'kerp-activity-type-key',
		'name'        => 'type_key',
		'label'       => __( 'نوع فعالیت', 'kasebi-erp' ),
		'type'        => 'select',
		'class'       => 'col-md-6',
		'options'     => KERP_Modules_Activities_Settings::instance()->get_type_options(),
		'placeholder' => __( 'نوع فعالیت را انتخاب کنید', 'kasebi-erp' ),
		'value'       => '',
		'required'    => TRUE,
	],
	
	[
		'id'          => 'kerp-activity-occurred-date',
		'name'        => 'occurred_date',
		'label'       => __( 'تاریخ انجام', 'kasebi-erp' ),
		'type'        => 'date',
		'class'       => 'col-md-6',
		'input_class' => 'persian-date',
		'value'       => date_i18n( 'Y-m-d' ),
		'required'    => TRUE,
	],
	[
		'id'          => 'kerp-activity-occurred-time',
		'name'        => 'occurred_time',
		'label'       => __( 'ساعت انجام', 'kasebi-erp' ),
		'type'        => 'text',
		'class'       => 'col-md-6',
		'input_class' => 'time-picker',
		'value'       => $rounded_time,
		'required'    => TRUE,
	],
	[
		'id'    => 'kerp-activity-content',
		'name'  => 'content',
		'label' => __( 'شرح فعالیت', 'kasebi-erp' ),
		'type'  => 'quill',
		'class' => 'col-12',
		'value' => '',
	],
	[
		'id'             => 'kerp-activity-attachment',
		'name'           => 'attachment',
		'label'          => __( 'فایل ضمیمه', 'kasebi-erp' ),
		'type'           => 'upload',
		'class'          => 'col-12',
		'value'          => '',
		'action'         => 'handle_file_upload',
		'max_files'      => 5,
		'accepted_files' => '',
	],
] );
KERP_Helpers_Template::render_modal( [
	'id'          => $modal_id,
	'title'       => __( 'افزودن یا ویرایش فعالیت', 'kasebi-erp' ),
	'action'      => 'activities_save',
	'page'        => $return_page,
	'button'      => __( 'ذخیره فعالیت', 'kasebi-erp' ),
	'button_text' => __( 'ذخیره فعالیت', 'kasebi-erp' ),
	'size'        => 'lg',
	'fields'      => $fields,
] );
