<?php
defined( 'ABSPATH' ) || exit;
if ( ! current_user_can( KERP_Admin::CAPABILITY ) && ! kerp_can( 'leads.view', 'view' ) ) return;
$service = KERP_Modules_Leads_Service::instance();
$campaigns = $service->get_campaigns();
$options = [];
foreach ( $campaigns as $campaign ) $options[ (int) $campaign['id'] ] = $campaign['name'] . ( $campaign['status'] === 'active' ? '' : ' (بایگانی)' );
$query = (array) ( $page_context['query'] ?? [] );
$selected = isset( $query['campaign_id'] ) && is_scalar( $query['campaign_id'] ) ? absint( $query['campaign_id'] ) : 0;
if ( $selected && ! isset( $options[ $selected ] ) ) { echo '<div class="alert alert-warning">مسیر فروش پیدا نشد.</div>'; return; }
$d = KERP_Modules_Leads_Dashboard::data( $selected );
$route = '/erp/marketing/pipelines/dashboard/';
$members_url = '/erp/leads/' . ( $selected ? '?campaign_id=' . $selected : '' );
$metric_urls = [
    add_query_arg( 'unique_customers', 1, $members_url ),
    $members_url,
    add_query_arg( [ 'joined' => [ 'from' => KERP_Helpers_Date::gregorian_to_jalali( array_key_first( $d['daily'] ) ), 'to' => KERP_Helpers_Date::gregorian_to_jalali( substr( $d['end'], 0, 10 ) ) ] ], $members_url ),
    add_query_arg( 'owner_id', 0, $members_url ),
];
$max_heat = 1;
foreach ( $d['matrix'] as $counts ) $max_heat = max( $max_heat, ...array_values( $counts ) );
?>
<div class="kerp-marketing kerp-pipelines marketing-interior kerp-marketing-dashboard kerp-pipeline-dashboard">
    <div class="marketing-dashboard-hero"><div class="nk-block-between g-3"><div><span class="overline-title">مارکتینگ / گزارش فروش</span><h3 class="nk-block-title">آمار مسیرهای فروش</h3><p class="mb-0"><?php echo esc_html( $selected ? $options[ $selected ] : 'نمای کلی همه مسیرهای فروش' ); ?> · هفت روز اخیر، شامل امروز</p></div><div class="d-flex gap-2 flex-wrap"><a class="btn btn-light page_activator" href="<?php echo esc_url( home_url( $members_url ) ); ?>" data-url="<?php echo esc_attr( $members_url ); ?>">مشاهده مشتریان</a><a class="btn btn-light page_activator" href="<?php echo esc_url( home_url( '/erp/marketing/pipelines/' ) ); ?>" data-url="/erp/marketing/pipelines/">مدیریت مسیرها</a></div></div></div>
    <div class="card card-bordered mb-4"><div class="card-inner d-flex align-items-center justify-content-between flex-wrap gap-3"><div><strong><?php echo esc_html( $selected ? $options[ $selected ] : 'همه مسیرها' ); ?></strong><span class="sub-text">به‌روزرسانی: <?php echo esc_html( KERP_Helpers_Date::local_datetime_to_jalali( $d['end'] ) ); ?> · امروز تا همین لحظه</span></div><?php KERP_Helpers_Template::render_template( 'app/components/list/filter-dropdown.php', [ 'has_filter' => (bool) $selected, 'page' => $route, 'filter_fields' => [ [ 'name' => 'campaign_id', 'label' => 'مسیر فروش', 'type' => 'select', 'options' => $options, 'value' => $selected, 'placeholder' => 'همه مسیرها', 'col' => 12 ] ] ] ); ?></div></div>
    <div class="kerp-pipeline-metrics mb-4">
    <?php foreach ( [ [ 'مشتریان یکتا', (int) ( $d['totals']['customers'] ?? 0 ), 'افراد حاضر در مسیرهای انتخاب‌شده' ], [ 'حضور در مسیرها', (int) ( $d['totals']['memberships'] ?? 0 ), 'هر مشتری در هر مسیر یک‌بار' ], [ 'ورودی جدید مسیر', array_sum( $d['daily'] ), 'تعداد ورود به مسیر در هفت روز اخیر' ], [ 'بدون کارشناس', (int) ( $d['totals']['unassigned'] ?? 0 ), 'ردیف‌های نیازمند تخصیص مسئول' ] ] as $metric_index => $metric ) : ?>
        <a class="card card-bordered marketing-metric-card m-0 page_activator text-reset text-decoration-none" href="<?php echo esc_url( home_url( $metric_urls[ $metric_index ] ) ); ?>" data-url="<?php echo esc_attr( $metric_urls[ $metric_index ] ); ?>"><div class="card-inner"><span class="text-soft"><?php echo esc_html( $metric[0] ); ?></span><strong><?php echo esc_html( number_format_i18n( $metric[1] ) ); ?></strong><small class="text-soft"><?php echo esc_html( $metric[2] ); ?></small></div></a>
    <?php endforeach; ?></div>
    <section class="card card-bordered mb-4"><div class="card-inner"><h5>روند ورود به مسیر فروش</h5><p class="text-soft">ورودهای جدید روزانه؛ ورود یک مشتری به دو مسیر، دو بار شمرده می‌شود.</p>
    <?php if ( array_sum( $d['daily'] ) ) : ?><div class="marketing-chart-canvas"><div class="kasebi-chart" data-chart-type="area" data-color="#6573df" data-legend="0" data-label="ورودی جدید مسیر" data-unit="ورودی" data-labels="<?php echo esc_attr( wp_json_encode( array_values( $d['days'] ) ) ); ?>" data-data="<?php echo esc_attr( wp_json_encode( array_values( $d['daily'] ) ) ); ?>" role="img" aria-label="روند هفت‌روزه ورودی جدید مسیر"></div></div><?php else : ?><p class="text-soft py-3">در این هفت روز ورودی جدیدی ثبت نشده است.</p><?php endif; ?>
    <details class="marketing-chart-data"><summary>اعداد روزانه</summary><div class="marketing-day-values"><?php foreach ( $d['daily'] as $day => $count ) : ?><span><?php echo esc_html( $d['days'][ $day ] . ': ' . number_format_i18n( $count ) ); ?></span><?php endforeach; ?></div></details></div></section>
    <section class="card card-bordered mb-4"><div class="card-inner"><h5>ورودی روزانه مراحل</h5><p class="text-soft">هر خانه: تعداد مشتریان یکتای واردشده به آن مرحله در آن روز. رنگ پررنگ‌تر یعنی ورودی بیشتر؛ ورود تکراری همان فرد در همان روز یک‌بار محاسبه می‌شود.</p>
    <?php if ( ! $selected ) : ?><div class="text-center py-4"><em class="icon ni ni-filter-alt fs-1"></em><h6 class="mt-2">یک مسیر فروش انتخاب کنید</h6><p class="text-soft mb-0">با فیلتر بالای صفحه، ورودی روزانه و توزیع مراحل همان مسیر نمایش داده می‌شود.</p></div>
    <?php elseif ( ! $d['summary']['stages'] ) : ?><p class="text-soft">این مسیر هنوز مرحله‌ای ندارد.</p>
    <?php else : ?><div class="kerp-pipeline-heatmap">
        <?php foreach ( $d['summary']['stages'] as $index => $stage ) : $counts = $d['matrix'][ (int) $stage['id'] ]; ?>
        <div class="kerp-pipeline-heat-row"><div class="kerp-pipeline-heat-label"><strong><?php echo esc_html( number_format_i18n( $index + 1 ) . '. ' . $stage['name'] ); ?></strong><small class="text-soft"><?php echo $stage['active'] ? '' : 'مرحله غیرفعال'; ?></small></div><div class="kerp-pipeline-heat-days">
        <?php foreach ( $counts as $day => $count ) : $level = $count ? max( 1, (int) ceil( 4 * $count / $max_heat ) ) : 0; ?><?php $entry_url = add_query_arg( [ 'campaign_id' => $selected, 'entry_stage' => (int) $stage['id'], 'entry_day' => $d['days'][ $day ], 'unique_customers' => 1 ], '/erp/leads/' ); ?>
        <?php if ( $count ) : ?><a class="kerp-pipeline-heat-cell page_activator" data-level="<?php echo $level; ?>" href="<?php echo esc_url( home_url( $entry_url ) ); ?>" data-url="<?php echo esc_attr( $entry_url ); ?>" aria-label="<?php echo esc_attr( $stage['name'] . '، ' . $d['days'][ $day ] . '، ' . number_format_i18n( $count ) . ' نفر' ); ?>"><?php else : ?><div class="kerp-pipeline-heat-cell" data-level="0"><?php endif; ?><small><?php echo esc_html( substr( $d['days'][ $day ], 5 ) ); ?></small><strong><?php echo esc_html( number_format_i18n( $count ) ); ?></strong><?php echo $count ? '</a>' : '</div>'; ?><?php endforeach; ?></div></div>
        <?php endforeach; ?></div><p class="small text-soft mt-3 mb-0">روزها از راست به چپ از قدیمی به جدید هستند. این آمار از رویدادهای ثبت‌شده ساخته می‌شود؛ یادداشت و تغییر کارشناس ورودی مرحله نیست. مجموع مراحل، تعداد مشتریان یکتای کل بازه نیست.</p><?php endif; ?></div></section>
    <div class="marketing-charts-grid mb-4">
    <?php
    $stage_bars = [];
    if ( $d['summary'] ) {
        foreach ( $d['summary']['stages'] as $stage ) $stage_bars[] = [ 'label' => $stage['name'], 'count' => (int) $stage['member_count'], 'url' => '/erp/leads/?campaign_id=' . $selected . '&stage_id=' . (int) $stage['id'] ];
        if ( $d['summary']['unassigned'] ) $stage_bars[] = [ 'label' => 'بدون مرحله معتبر', 'count' => $d['summary']['unassigned'], 'url' => '' ];
    }
    $owner_bars = [];
    foreach ( $d['owners'] as $owner ) { $user = get_userdata( (int) $owner['owner_id'] ); $owner_bars[] = [ 'label' => $user ? get_user_name_by_id( $user->ID ) : ( $owner['owner_id'] ? 'کارشناس حذف‌شده' : 'تخصیص‌نیافته' ), 'count' => (int) $owner['n'], 'url' => add_query_arg( 'owner_id', (int) $owner['owner_id'], $members_url ) ]; }
    foreach ( [ [ 'مشتریان فعلی هر مرحله', 'نمای لحظه‌ای؛ نشان‌دهنده نرخ تبدیل نیست.', $stage_bars ], [ 'بار کاری کارشناسان', '۱۰ گروه پرتعداد؛ تعداد حضور مشتریان در مسیرهای انتخاب‌شده.', $owner_bars ] ] as $panel ) {
        KERP_Helpers_Template::render_template( 'modules/leads/partials/dashboard-bars.php', [ 'title' => $panel[0], 'description' => $panel[1], 'bars' => $panel[2] ] );
    }
    ?></div>
    <?php if ( ! $selected ) {
        $bars = [];
        foreach ( $d['comparison'] as $item ) $bars[] = [ 'label' => $item['name'], 'count' => (int) $item['recent'], 'url' => $route . '?campaign_id=' . (int) $item['id'] ];
        KERP_Helpers_Template::render_template( 'modules/leads/partials/dashboard-bars.php', [ 'title' => 'مقایسه ورودی مسیرها', 'description' => '۱۰ مسیر اول بر اساس ورودی جدید در هفت روز اخیر؛ برای جزئیات روی مسیر کلیک کنید.', 'bars' => $bars ] );
    } ?>
</div>
