<?php
defined( 'ABSPATH' ) || exit;
if ( ! current_user_can( KERP_Admin::CAPABILITY ) && ! kerp_can( 'leads.view', 'view' ) ) {
	return;
}
$view          = KERP_Modules_Leads_Pipeline_View::class;
$route         = $view::ROUTE;
$query         = (array) ( $page_context['query'] ?? [] );
$per_page      = KERP_Helpers_Pagination::resolve_per_page( 'pipelines', $query, 20, 100 );
$result        = KERP_Modules_Leads_Service::instance()->find_pipelines( $query, $per_page );
$can_configure = KERP_Modules_Leads_View::can_configure();
$search        = is_scalar( $query['search'] ?? '' ) ? sanitize_text_field( (string) ( $query['search'] ?? '' ) ) : '';
$status        = is_scalar( $query['status'] ?? '' ) ? sanitize_key( (string) ( $query['status'] ?? '' ) ) : '';
$filters       = [
	[
		'key'   => 'search',
		'name'  => 'search',
		'label' => 'نام مسیر فروش',
		'type'  => 'text',
		'value' => $search,
		'col'   => 12,
	],
	[
		'key'         => 'status',
		'name'        => 'status',
		'label'       => 'وضعیت',
		'type'        => 'select',
		'options'     => [ 'active' => 'فعال', 'archived' => 'بایگانی' ],
		'placeholder' => 'همه وضعیت‌ها',
		'value'       => $status,
	],
];
?>
<div class="kerp-marketing kerp-pipelines marketing-interior"
     data-leads-nonce="<?php echo esc_attr( wp_create_nonce( 'kerp_leads' ) ); ?>">
    <div class="mb-3"><a class="btn btn-sm btn-outline-primary page_activator"
                         data-url="<?php echo esc_attr( '/erp/marketing/pipelines/dashboard/' ); ?>"
                         href="<?php echo esc_url( home_url( '/erp/marketing/pipelines/dashboard/' ) ); ?>"><em
                class="icon ni ni-bar-chart-alt"></em><span>داشبورد آماری مسیرهای فروش</span></a></div>
    <div class="nk-block-head marketing-page-hero">
        <div class="nk-block-between g-3">
            <div><span class="overline-title">مارکتینگ</span>
                <h3 class="nk-block-title">مسیرهای فروش</h3>
                <p class="mb-0">مسیر حرکت مشتریان بالقوه، مراحل اختصاصی و تعداد اعضای هر مسیر</p></div>
			<?php if ( $can_configure ) : ?>
                <div class="d-flex flex-wrap gap-2">
                <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                        data-bs-target="#kerpPipelineEdit0"><em class="icon ni ni-plus"></em><span>مسیر فروش جدید</span>
                </button>
                <button type="button" class="btn btn-outline-light" data-bs-toggle="modal"
                        data-bs-target="#kerpPipelineConnections">اتصال منابع
                </button>
                <a class="btn btn-outline-light page_activator" data-url="/erp/marketing/pipelines/settings/"
                   href="<?php echo esc_url( home_url( '/erp/marketing/pipelines/settings/' ) ); ?>">تنظیمات مسیرهای
                    فروش</a></div><?php endif; ?>
        </div>
    </div>
    <div class="card card-bordered">
        <div class="card-inner">
            <div class="card-title-group flex-wrap gap-2"><h6 class="title mb-0">مسیرهای فروش <span
                        class="badge kerp-pipeline-badge kerp-pipeline-badge-count"><?php echo esc_html( number_format_i18n( $result['total'] ) ); ?></span>
                </h6>
                <div class="d-flex flex-wrap gap-2">
					<?php
					if ( $can_configure ) {
						KERP_Helpers_Template::render_template( 'app/components/list/bulk-actions.php', [
							'actions'       => [
								'archived' => [
									'label' => 'بایگانی (حفظ سوابق)',
									'icon'  => 'ni ni-archive',
								],
								'active'   => [
									'label' => 'فعال‌سازی',
									'icon'  => 'ni ni-check',
								],
							],
							'action'        => 'leads_pipeline_bulk',
							'page'          => $route,
							'item_selector' => '.kerp-pipeline-select',
						] );
					}
					KERP_Helpers_Template::render_template( 'app/components/list/filter-dropdown.php', [
						'has_filter'    => $search !== '' || $status !== '',
						'filter_fields' => $filters,
						'action'        => 'erp_request_page_content',
						'page'          => $route,
					] );
					KERP_Helpers_Template::render_template( 'app/components/list/per-page-selector.php', [
						'per_page'            => $per_page,
						'available_per_pages' => [
							10,
							20,
							50,
							100,
						],
						'action'              => 'erp_request_page_content',
						'page'                => $route,
					] );
					?></div>
            </div>
        </div>
        <div class="nk-tb-list kerp-marketing-list">
            <div class="nk-tb-item nk-tb-head">
                <div class="nk-tb-col nk-tb-col-check"><?php if ( $can_configure ) : ?><input type="checkbox"
                                                                                              class="form-check-input select_all_rows"
                                                                                              data-target=".kerp-pipeline-select"
                                                                                              aria-label="انتخاب همه مسیرهای فروش این صفحه" <?php disabled( ! $result['items'] ); ?>><?php endif; ?>
                </div><?php foreach ( [ 'مسیر فروش', 'اعضا', 'مراحل', 'وضعیت', 'عملیات' ] as $label ) : ?>
                    <div class="nk-tb-col"><?php echo esc_html( $label ); ?></div><?php endforeach; ?></div>
			<?php foreach ( $result['items'] as $row ) : $detail = $route . (int) $row['id'] . '/';
				$members_url = '/erp/leads/?campaign_id=' . (int) $row['id']; ?>
                <div class="nk-tb-item">
                    <div class="nk-tb-col nk-tb-col-check"><?php if ( $can_configure ) : ?><input type="checkbox"
                                                                                                  class="form-check-input select_item_row kerp-pipeline-select"
                                                                                                  value="<?php echo (int) $row['id']; ?>"
                                                                                                  aria-label="انتخاب <?php echo esc_attr( $row['name'] ); ?>"><?php endif; ?>
                    </div>
                    <div class="nk-tb-col" data-label="مسیر فروش"><a class="page_activator fw-bold"
                                                                     data-url="<?php echo esc_attr( $detail ); ?>"
                                                                     href="<?php echo esc_url( home_url( $detail ) ); ?>"><?php echo esc_html( $row['name'] ); ?></a>
                    </div>
                    <div class="nk-tb-col" data-label="اعضا"><a
                            class="page_activator d-inline-flex align-items-center gap-1 py-2"
                            data-url="<?php echo esc_attr( $members_url ); ?>" href="<?php echo
						esc_url( home_url( $members_url ) ); ?>"
                            aria-label="<?php echo esc_attr( 'مشاهده مشتریان مسیر فروش «' . $row['name'] . '»' ); ?>"><strong><?php echo esc_html( number_format_i18n( $row['member_count'] ) ); ?></strong>
                            نفر<em class="icon ni ni-chevron-right" aria-hidden="true"></em></a></div>
                    <div class="nk-tb-col"
                         data-label="مراحل"><?php echo esc_html( number_format_i18n( $row['stage_count'] ) ); ?> مرحله
                    </div>
                    <div class="nk-tb-col" data-label="وضعیت"><span
                            class="badge kerp-pipeline-badge <?php echo $row['status'] === 'active' ? 'kerp-pipeline-badge-active' : 'kerp-pipeline-badge-muted'; ?>"><?php echo $row['status'] === 'active' ? 'فعال' : 'بایگانی'; ?></span>
                    </div>
                    <div class="nk-tb-col kerp-pipeline-actions-cell" data-label="عملیات"><?php
						$actions   = [
							[
								'title'    => 'مراحل و آمار مسیر فروش',
								'url'      => home_url( $detail ),
								'data_url' => $detail,
								'class'    => 'page_activator',
								'icon'     => 'ni ni-growth',
							],
						];
						$actions[] = [
							'title'    => 'مشاهده مشتریان',
							'url'      => home_url( $members_url ),
							'data_url' => $members_url,
							'class'    => 'page_activator',
							'icon'     => 'ni ni-users',
						];
						if ( $can_configure ) {
							$actions[] = [ 'title' => 'تکثیر مسیر فروش', 'icon' => 'ni ni-copy', 'data' => [ 'bs-toggle' => 'modal', 'bs-target' => '#kerpPipelineDuplicate' . (int) $row['id'] ] ];
							$actions[] = [
								'title' => 'ویرایش مسیر فروش',
								'icon'  => 'ni ni-edit',
								'data'  => [
									'bs-toggle' => 'modal',
									'bs-target' => '#kerpPipelineEdit' . (int) $row['id'],
								],
							];
						}
						if ( $can_configure ) {
							$actions[] = [
								'title' => 'حذف مسیر فروش',
								'icon'  => 'ni ni-trash',
								'class' => 'text-danger',
								'data'  => [
									'bs-toggle' => 'modal',
									'bs-target' => '#kerpPipelineDelete' . (int) $row['id'],
								],
							];
						}
						echo '<div class="kerp-pipeline-list-actions">';
						KERP_Helpers_Template::render_template( 'app/components/list/row-actions.php', [
							'actions' => $actions,
							'display' => 'inline',
						] );
						echo '</div>';
						?></div>
                </div>
			<?php endforeach; ?></div>
		<?php if ( ! $result['items'] ) : ?>
            <div class="card-inner text-center py-5"><em class="icon ni ni-filter-alt fs-1 text-soft"></em><h5
                class="mt-3">مسیر فروشی پیدا نشد</h5>
            <p class="text-soft mb-0">فیلترها را تغییر
                دهید<?php echo $can_configure ? ' یا اولین مسیر فروش را بسازید.' : '.'; ?></p></div><?php endif; ?>
		<?php if ( $result['pages'] > 1 ) : ?>
            <div
                class="card-inner border-top"><?php KERP_Helpers_Template::render_template( 'app/components/list/pagination.php', [
				'max_page_num' => $result['pages'],
				'current_page' => $result['page'],
				'class_name'   => 'kerp_pipeline_pagination_link',
				'show_count'   => 2,
				'action'       => 'erp_request_page_content',
				'page'         => $route,
			] ); ?></div><?php endif; ?>
    </div>
	<?php if ( $can_configure ) {
		$view::campaign_modal();
		foreach ( $result['items'] as $row ) {
			$view::campaign_modal( $row );
			$view::delete_modal( $row );
			$view::duplicate_modal( $row );
		}
		$view::connections_modal();
	} ?>
</div>
