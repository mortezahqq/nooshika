<?php
defined( 'ABSPATH' ) || exit;
if ( ! current_user_can( KERP_Admin::CAPABILITY ) && ! kerp_can( 'leads.view', 'view' ) ) {
	return;
}
$service     = KERP_Modules_Leads_Service::instance();
$view        = KERP_Modules_Leads_View::class;
$query       = (array) ( $page_context['query'] ?? [] );
$campaign_id = absint( $query['campaign_id'] ?? 0 );
$stage_id    = absint( $query['stage_id'] ?? 0 );
$owner_filter = isset( $query['owner_id'] ) && is_scalar( $query['owner_id'] ) && (string) $query['owner_id'] !== '' ? absint( $query['owner_id'] ) : NULL;
if ( $stage_id ) {
	$stage = $service->get_stage( $stage_id );
	if ( ! $campaign_id || ! $stage || (int) $stage['campaign_id'] !== $campaign_id ) {
		$stage_id = 0;
	}
}
$search           = is_scalar( $query['search'] ?? '' ) ? sanitize_text_field( (string) ( $query['search'] ?? '' ) ) : '';
$joined = is_array( $query['joined'] ?? NULL ) ? $query['joined'] : [];
$joined += [ 'from' => '', 'to' => '' ];
$unique_customers = is_scalar( $query['unique_customers'] ?? '' ) && (string) ( $query['unique_customers'] ?? '' ) === '1';
$entry = [ 'stage' => is_scalar( $query['entry_stage'] ?? '' ) ? absint( $query['entry_stage'] ?? 0 ) : 0, 'day' => is_scalar( $query['entry_day'] ?? '' ) ? sanitize_text_field( (string) ( $query['entry_day'] ?? '' ) ) : '' ];
$membership_status = in_array( $query['membership_status'] ?? '', [ 'active', 'exited', 'all' ], TRUE ) ? $query['membership_status'] : ( $entry['stage'] || $entry['day'] || $joined['from'] || $joined['to'] ? 'all' : 'active' );
$registration = [ 'status' => is_string( $query['registration_status'] ?? '' ) ? ( $query['registration_status'] ?? '' ) : '', 'answers' => [], 'query' => [] ];
foreach ( $query as $key => $value ) {
    if ( ! str_starts_with( (string)$key, 'registration_value_' ) || ! is_string( $value ) || $value === '' ) continue;
    $field_key = substr( $key, strlen('registration_value_') );
    if ( ! preg_match( '/^[a-z0-9_]{1,80}$/D', $field_key ) ) continue;
    $registration['answers'][$field_key] = mb_substr( sanitize_text_field( $value ), 0, str_starts_with( $value, 'option:' ) ? 507 : 500 );
    $registration['query'][$key] = $registration['answers'][$field_key];
}
$per_page         = KERP_Helpers_Pagination::resolve_per_page( 'leads', $query, 20, 100 );
$result           = $service->find_memberships( $campaign_id, $stage_id, absint( $query['page_number'] ?? 1 ), $per_page, $search, $owner_filter, $joined, $unique_customers, $entry, $membership_status, $registration );
$registration_statuses = KERP_Modules_Leads_Registration::list_statuses( $result['items'] );
$registration_badges = KERP_Modules_Leads_Registration::list_field_badges( $result['items'] );
$route            = '/erp/leads/';
$return_route     = add_query_arg( [
	'registration_status' => $registration['status'],
	'membership_status' => $membership_status,
	'entry_stage' => $entry['stage'], 'entry_day' => $entry['day'],
	'joined' => $joined,
	'unique_customers' => $unique_customers ? 1 : 0,
	'owner_id' => $owner_filter,
	'campaign_id' => $campaign_id,
	'stage_id'    => $stage_id,
	'search'      => $search,
	'per_page'    => $per_page,
	'page_number' => $result['page'],
], $route );
$return_route = add_query_arg( $registration['query'], $return_route );
// URL query values take precedence over AJAX arguments. Keep list filters, but
// omit the value each control changes so the new selection can take effect.
$per_page_route = add_query_arg( 'page_number', 1, remove_query_arg( [ 'per_page', 'page_number' ], $return_route ) );
$pagination_route = remove_query_arg( 'page_number', $return_route );
$can_manage       = $view::can_manage();
$can_branch       = $can_manage && $campaign_id && $stage_id;
$campaign_options = [];
foreach ( $service->get_campaigns() as $campaign ) {
	$campaign_options[ $campaign['id'] ] = $campaign['name'];
}
$pipeline_summary = $campaign_id && isset( $campaign_options[ $campaign_id ] ) ? $service->pipeline_summary( $campaign_id ) : NULL;
$owner_options = [ 0 => 'تخصیص‌نیافته' ] + $service->sales_employee_options();
if ( $owner_filter && ! isset( $owner_options[ $owner_filter ] ) ) $owner_options[ $owner_filter ] = get_user_name_by_id( $owner_filter );
$filters          = [
    'joined' => [ 'name' => 'joined', 'label' => 'تاریخ ورود به مسیر (شمسی)', 'type' => 'date-range', 'value' => array_map( static fn( $v ) => is_scalar( $v ) ? (string) $v : '', $joined ), 'col' => 12 ],
    'unique_customers' => [ 'name' => 'unique_customers', 'label' => 'نوع نمایش', 'type' => 'select', 'options' => [ 0 => 'همه عضویت‌ها', 1 => 'مشتریان یکتا (یک عضویت برای هر مشتری)' ], 'value' => $unique_customers ? 1 : 0, 'col' => 6 ],
    'owner_id' => [ 'name' => 'owner_id', 'label' => 'کارشناس فروش', 'type' => 'select', 'options' => $owner_options, 'value' => $owner_filter, 'placeholder' => 'همه کارشناسان', 'col' => 6 ],
	'campaign_id' => [
		'name'        => 'campaign_id',
		'label'       => 'مسیر فروش',
		'type'        => 'select',
		'value'       => $campaign_id,
		'options'     => $campaign_options,
		'placeholder' => 'همه مسیرهای فروش',
		'col'         => 6,
	],

];
$filters['registration_status'] = [ 'name' => 'registration_status', 'label' => 'وضعیت فرم ثبت‌نام', 'type' => 'select', 'placeholder' => 'همه', 'options' => [ 'pending' => 'شماره تأیید نشده', 'verified' => 'در انتظار تکمیل اطلاعات', 'completed' => 'ثبت‌نام تکمیل شده' ], 'value' => $registration['status'], 'col' => 6 ];
$registration_fields = $campaign_id ? ( KERP_Modules_Leads_Registration::config( $campaign_id )['fields'] ?? [] ) : [];
$utm_filter_options = KERP_Modules_Leads_Registration::utm_filter_options( $campaign_id );
foreach ( KERP_Modules_Leads_Registration::UTM as $utm_key ) $registration_fields[] = [ 'key' => $utm_key, 'label' => $utm_key, 'type' => 'select', 'options' => $utm_filter_options[$utm_key] ];
foreach ( $registration_fields as $rf ) {
    $options = []; foreach ( $rf['options'] as $option ) $options['option:' . $option] = $option;
    $filter_value = is_string( $registration['answers'][$rf['key']] ?? NULL ) ? $registration['answers'][$rf['key']] : '';
    // Keep previously shared UTM URLs selected while new selects use the shared option prefix.
    if ( in_array( $rf['key'], KERP_Modules_Leads_Registration::UTM, TRUE ) && $filter_value !== '' && ! str_starts_with( $filter_value, 'option:' ) ) $filter_value = 'option:' . $filter_value;
    $filters['registration_' . $rf['key']] = [ 'name' => 'registration_value_' . $rf['key'], 'label' => $rf['label'], 'type' => $rf['type'] === 'text' ? 'text' : 'select', 'placeholder' => $rf['type'] === 'text' ? '' : 'همه', 'options' => $options, 'value' => $filter_value, 'col' => 6 ];
}
?>
<div class="kerp-marketing kerp-pipelines kerp-leads-list marketing-interior">
    <div class="nk-block-head marketing-page-hero">
        <div class="nk-block-between g-3">
            <div><span class="overline-title">مارکتینگ</span>
                <h3 class="nk-block-title">مشتریان بالقوه</h3>
                <p class="mb-0">اعضای مسیرهای فروش، مرحله فعلی و کارشناس مسئول؛ هر مشتری می‌تواند عضو چند مسیر باشد.</p>
            </div>
			<?php if ( $view::can_configure() ) : ?><a class="btn btn-primary page_activator"
                                                       data-url="/erp/marketing/pipelines/"
                                                       href="<?php echo esc_url( home_url( '/erp/marketing/pipelines/' ) ); ?>">
                    مدیریت مسیرهای فروش</a><?php endif; ?>
        </div>
    </div>
	<?php if ( $pipeline_summary !== NULL && $membership_status === 'active' ) {
		KERP_Helpers_Template::render_template( 'modules/leads/partials/stage-filter.php', [
			'summary'       => $pipeline_summary,
			'campaign_id'   => $campaign_id,
			'campaign_name' => $campaign_options[ $campaign_id ],
			'stage_id'      => $stage_id,
			'search'        => $search,
			'per_page'      => $per_page,
            'owner_filter' => $owner_filter,
            'joined' => $joined, 'unique_customers' => $unique_customers, 'entry' => $entry, 'registration' => $registration,
		] );
	} ?>
    <?php if ( ! empty( $result['error'] ) ) : ?><div class="alert alert-danger" role="alert"><?php echo esc_html( $result['error'] ); ?></div><?php endif; ?>
    <div class="card card-bordered">
        <div class="card-inner">
            <div class="card-title-group flex-wrap gap-2"><h6 class="title marketing-list-title mb-0"><?php echo $unique_customers ? 'مشتریان یکتا' : 'عضویت‌ها'; ?> <span
                        class="badge kerp-pipeline-badge kerp-pipeline-badge-count"><?php echo esc_html( number_format_i18n( $result['total'] ) ); ?></span>
                </h6>
                <div class="d-flex flex-wrap gap-2">
					<?php
                    if ( $can_manage ) {
                        $bulk_actions = [
                            'stage' => [ 'label' => 'تغییر مرحله', 'icon' => 'ni ni-growth', 'class' => 'kerp-leads-open-bulk' ],
                            'owner' => [ 'label' => 'تخصیص کارشناس', 'icon' => 'ni ni-user-check', 'class' => 'kerp-leads-open-bulk' ],
                            'exit' => [ 'label' => 'خروج از مسیر فروش', 'icon' => 'ni ni-signout', 'class' => 'kerp-leads-open-bulk text-danger' ],
                            'course' => [ 'label' => 'اعطای دسترسی دوره', 'icon' => 'ni ni-unlock', 'class' => 'kerp-leads-open-bulk' ],
                        ];
                        if ( $can_branch ) $bulk_actions['branch'] = [ 'label' => 'افزودن به مسیر فروش دیگر', 'icon' => 'ni ni-plus', 'class' => 'kerp-leads-open-branch' ];
                        KERP_Helpers_Template::render_template( 'app/components/list/bulk-actions.php', [
                            'actions' => $bulk_actions, 'action' => 'leads_membership_bulk', 'page' => $return_route,
                            'item_selector' => '.kerp-lead-member-select', 'dropdown_class' => 'kerp-leads-bulk-menu',
                        ] );
                    }
					KERP_Helpers_Template::render_template( 'app/components/list/filter-dropdown.php', [
						'has_filter'    => $registration['status'] !== '' || ! empty( $registration['answers'] ) || $membership_status !== 'active' || $search !== '' || $campaign_id || $stage_id || $owner_filter !== NULL || ! empty( $joined['from'] ) || ! empty( $joined['to'] ) || $unique_customers || $entry['stage'] || $entry['day'] !== '',
						'filter_fields' => $filters,
						'action'        => 'erp_request_page_content',
						'page'          => add_query_arg( [ 'stage_id' => 0, 'membership_status' => $membership_status ], $route ),
					] );
					KERP_Helpers_Template::render_template( 'app/components/list/per-page-selector.php', [
						'per_page'            => $per_page,
						'available_per_pages' => [
							10,
							20,
							50,
							100,
						],
						'action'              => 'erp_request_page_content',
						'page'                => $per_page_route,
					] );
					?></div>
            </div>
            <nav class="d-flex flex-wrap align-items-center gap-2 mt-3" aria-label="وضعیت حضور در مسیر">
                <span class="small text-soft">وضعیت حضور:</span>
                <?php foreach ( [ 'all' => 'همه', 'active' => 'داخل مسیر', 'exited' => 'خارج‌شده' ] as $status_key => $status_label ) :
                    $status_url = add_query_arg( [ 'membership_status' => $status_key, 'page_number' => 1 ], $return_route ); ?>
                    <a class="btn btn-sm <?php echo $membership_status === $status_key ? 'btn-primary' : 'btn-outline-light'; ?> page_activator"
                       href="<?php echo esc_url( home_url( $status_url ) ); ?>" data-url="<?php echo esc_attr( $status_url ); ?>" <?php if ( $membership_status === $status_key ) echo 'aria-current="true"'; ?>><?php echo esc_html( $status_label ); ?></a>
                <?php endforeach; ?>
            </nav>
			<?php if ( $can_manage ) : ?><p
                class="small text-soft mt-2 mb-0"><?php echo $can_branch ? 'برای افزودن گروهی به مسیر دیگر، اعضای این صفحه را انتخاب کنید؛ سابقه مسیر فعلی حفظ می‌شود.' : 'برای افزودن گروهی به مسیر دیگر، مسیر فروش را انتخاب کنید و روی کارت مرحله مبدأ بزنید.'; ?></p><?php endif; ?>
        </div>
        <div class="nk-tb-list kerp-marketing-list">
            <div class="nk-tb-item nk-tb-head">
                <div class="nk-tb-col nk-tb-col-check"><?php if ( $can_manage ) : ?><input type="checkbox"
                                                                                           class="form-check-input select_all_rows"
                                                                                           data-target=".kerp-lead-member-select"
                                                                                           aria-label="انتخاب همه اعضای این صفحه" <?php disabled( ! $result['items'] ); ?>><?php endif; ?>
                </div><?php foreach (
					[
						'مشتری بالقوه',
						'مسیر فروش و مرحله',
						'اطلاعات ثبت‌نام',
						'کارشناس',
						'عملیات',
					] as $label
				) : ?>
                    <div class="nk-tb-col"><?php echo esc_html( $label ); ?></div><?php endforeach; ?></div>
			<?php foreach ( $result['items'] as $membership ) :
				$user = get_userdata( (int) $membership['user_id'] );
				$owner = get_userdata( (int) $membership['owner_id'] );
				$name = $user ? get_user_name_by_id( $user->ID ) : '#' . $membership['user_id'];
				$customer_route = '/erp/customers/' . absint( $membership['user_id'] ) . '/?tab=lead-journey';
				$pipeline_route = '/erp/marketing/pipelines/' . absint( $membership['campaign_id'] ) . '/';
                $member_actions = KERP_Modules_Leads_Pipeline_View::configured_actions( $membership, $return_route );
				?>
                <div class="nk-tb-item">
                <div class="nk-tb-col nk-tb-col-check"><?php if ( $can_manage && empty( $membership['exited_at'] ) ) : ?><input type="checkbox"
                                                                                           class="form-check-input select_item_row kerp-lead-member-select"
                                                                                           value="<?php echo absint( $membership['user_id'] ); ?>" data-membership-id="<?php echo absint( $membership['id'] ); ?>"
                                                                                           aria-label="انتخاب <?php echo esc_attr( $name ); ?>"><?php endif; ?>
                </div>
                <div class="nk-tb-col" data-label="مشتری بالقوه">
                    <a class="page_activator kerp-lead-user-card-link"
                       data-url="<?php echo esc_attr( $customer_route ); ?>"
                       href="<?php echo esc_url( home_url( $customer_route ) ); ?>">
						<?php
						if ( $user ) {
							KERP_Helpers_Template::render_template( 'app/components/user-card.php', [
								'user_id'    => (int) $user->ID,
								'show_phone' => TRUE,
							] );
						} else {
							echo esc_html( $name );
						}
						?>
                    </a>
                    <?php $signup_status = $registration_statuses[$membership['user_id'] . ':' . $membership['campaign_id']] ?? ''; if ( $signup_status !== '' ) : ?>
                    <small class="d-block mt-1 text-soft"><?php echo esc_html( [ 'pending' => 'ثبت‌نام: منتظر تأیید شماره', 'verified' => 'ثبت‌نام: اطلاعات تکمیلی ناقص', 'completed' => 'ثبت‌نام: تکمیل شده' ][$signup_status] ?? '' ); ?></small>
                    <?php endif; ?>
                </div>
                  <div class="nk-tb-col kerp-lead-path-cell" data-label="مسیر فروش و مرحله"><a class="page_activator d-block mb-1"
                                                                 data-url="<?php echo esc_attr( $pipeline_route ); ?>"
                                                                 href="<?php echo esc_url( home_url( $pipeline_route ) ); ?>"><?php echo esc_html( $membership['campaign_name'] ); ?></a>
                  <span
                        class="badge kerp-pipeline-badge kerp-pipeline-badge-count"><?php echo esc_html( ! empty( $membership['exited_at'] ) ? 'خارج‌شده · ' . ( $membership['stage_name'] ?: 'بدون مرحله' ) : ( $membership['stage_name'] ?: 'بدون مرحله' ) ); ?></span>
                </div>
                <div class="nk-tb-col kerp-lead-registration-cell" data-label="اطلاعات ثبت‌نام">
                    <?php KERP_Helpers_Template::render_template( 'modules/leads/partials/registration-badges.php', [ 'badges' => $registration_badges[$membership['user_id'] . ':' . $membership['campaign_id']] ?? [] ] ); ?>
                </div>
                <div class="nk-tb-col"
                     data-label="کارشناس"><?php $owner_url = add_query_arg( [ 'owner_id' => (int) $membership['owner_id'], 'page_number' => 1 ], $return_route ); ?><a class="badge kerp-pipeline-badge kerp-pipeline-badge-count page_activator" data-url="<?php echo esc_attr( $owner_url ); ?>" href="<?php echo esc_url( home_url( $owner_url ) ); ?>"><?php echo esc_html( $owner ? get_user_name_by_id( $owner->ID ) : 'تخصیص‌نیافته' ); ?></a></div>
                <div class="nk-tb-col kerp-lead-actions-cell"
                     data-label="عملیات"><?php KERP_Helpers_Template::render_template( 'app/components/list/row-actions.php', [
                        'display' => 'inline',
						'actions' => array_merge( $member_actions, [
                              [
                                  'title' => 'تاریخ ورود: ' . KERP_Helpers_Date::local_datetime_to_jalali( (string) $membership['joined_at'] ),
                                  'icon' => 'ni ni-calendar',
                                  'url' => '',
                              ],
                            [
                                'title' => 'اطلاعات UTM',
                                'class' => 'kerp_load_data_to_modal',
                                'icon' => 'ni ni-link',
                                'data' => [
                                    'action' => 'leads_customer_info', 'info-kind' => 'utm',
                                    'modal' => '#kerpLeadInfoUtm', 'modal-title' => 'اطلاعات UTM',
                                    'user_id' => (int) $membership['user_id'], 'campaign_id' => (int) $membership['campaign_id'],
                                    'leads_nonce' => wp_create_nonce( 'kerp_leads' ),
                                ],
                            ],
                            [
                                'title' => 'اطلاعات فرم ثبت‌نام',
                                'class' => 'kerp_load_data_to_modal',
                                'icon' => 'ni ni-file-text',
                                'data' => [
                                    'action' => 'leads_customer_info', 'info-kind' => 'registration',
                                    'modal' => '#kerpLeadInfoRegistration', 'modal-title' => 'اطلاعات فرم ثبت‌نام',
                                    'user_id' => (int) $membership['user_id'], 'campaign_id' => (int) $membership['campaign_id'],
                                    'leads_nonce' => wp_create_nonce( 'kerp_leads' ),
                                ],
                            ],
							[
								'title' => 'تاریخچه اقدامات',
								'class' => 'kerp_load_data_to_modal',
								'icon'  => 'ni ni-history',
								'data'  => [
									'action'      => 'leads_history',
									'modal'       => '#kerpLeadsHistory',
									'modal-title' => 'تاریخچه اقدامات',
									'user_id'     => (int) $membership['user_id'],
									'campaign_id' => (int) $membership['campaign_id'],
									'leads_nonce' => wp_create_nonce( 'kerp_leads' ),
								],
							],
							[
								'title'    => 'پروفایل و سابقه مشتری',
								'url'      => home_url( $customer_route ),
								'data_url' => $customer_route,
								'class'    => 'page_activator',
								'icon'     => 'ni ni-user',
							],

						] ),
					] ); ?></div>
                </div><?php endforeach; ?></div>
		<?php if ( ! $result['items'] ) : ?>
            <div class="card-inner text-center py-5"><em class="icon ni ni-users fs-1 text-soft"></em><h5 class="mt-3">
                    عضوی پیدا نشد</h5>
                <p class="text-soft mb-0">فیلترها را تغییر دهید یا مسیر فروش دیگری را انتخاب کنید.</p>
            </div><?php endif; ?>
		<?php if ( $result['pages'] > 1 ) : ?>
            <div
                class="card-inner border-top"><?php KERP_Helpers_Template::render_template( 'app/components/list/pagination.php', [
				'max_page_num' => $result['pages'],
				'current_page' => $result['page'],
				'class_name'   => 'kerp_leads_pagination_link',
				'show_count'   => 2,
				'action'       => 'erp_request_page_content',
				'page'         => $pagination_route,
			] ); ?></div><?php endif; ?>
    </div>
	<?php KERP_Helpers_Template::render_template( 'modules/leads/partials/customer-info-modals.php' ); ?>
    <?php if ( $can_manage ) foreach ( $result['items'] as $member ) {
        KERP_Modules_Leads_Pipeline_View::configured_actions( $member, $return_route, TRUE );

        if ( ! empty( $member['exited_at'] ) ) continue;
        $exit_id = 'kerpPipelineMemberExit' . (int) $member['id'];
        $exit_fields = [ [ 'type'=>'quill', 'name'=>'note', 'label'=>'دلیل خروج (اختیاری)', 'class'=>'col-12', 'id'=>$exit_id . '-note' ] ];
        foreach ( [ 'leads_nonce'=>wp_create_nonce( 'kerp_leads' ), 'user_id'=>(int) $member['user_id'], 'campaign_id'=>(int) $member['campaign_id'], 'expected_stage_id'=>(int) $member['current_stage_id'] ] as $key => $value ) $exit_fields[] = [ 'type'=>'hidden', 'name'=>$key, 'value'=>$value, 'id'=>$exit_id . '-' . $key, 'input_class'=>'no_clear' ];
        KERP_Helpers_Template::render_modal( [ 'id'=>$exit_id, 'title'=>'خروج از مسیر فروش', 'action'=>'leads_exit_pipeline', 'page'=>$return_route, 'fields'=>$exit_fields, 'button'=>'تأیید خروج از مسیر', 'body'=>'<div class="col-12"><p>خروج <strong>' . esc_html( get_user_name_by_id( (int) $member['user_id'] ) ) . '</strong> از مسیر <strong>' . esc_html( $member['campaign_name'] ) . '</strong></p><div class="alert alert-warning">تاریخچه حفظ می‌شود و پیامک‌های منتظر این مسیر لغو می‌شوند. در صورت تنظیم پیامک خروج، آن پیامک ارسال خواهد شد. عضویت مشتری در مسیرهای دیگر تغییر نمی‌کند.</div></div>' ] );
    } ?>
	<?php KERP_Helpers_Template::render_modal( [
		'type'  => 'context',
		'id'    => 'kerpLeadsHistory',
		'title' => 'تاریخچه اقدامات',
		'class' => 'modal-lg modal-dialog-scrollable',
		'body'  => '<div class="kerp-dynamic-modal-content" aria-live="polite"></div>',
	] ); ?>
	<?php if ( $can_branch ) :
		ob_start();
		?>
        <div class="col-12"><p class="text-soft">عضویت و سابقه مبدأ حفظ می‌شود. عضویت قبلی در مقصد تغییر نمی‌کند.</p><p
        class="kerp-leads-selection-count"></p>
        <div
            class="kerp-leads-selected-inputs"></div><?php $view::pipeline_picker( 'target_campaign_id', 'target_stage_id', 0, 0, $campaign_id );
		$view::input( 'note', 'توضیح' ); ?></div><?php
		$body   = ob_get_clean();
		$fields = [];
		foreach (
			[
				'leads_nonce'        => wp_create_nonce( 'kerp_leads' ),
				'source_campaign_id' => $campaign_id,
				'source_stage_id'    => $stage_id,
			] as $key => $value
		) {
			$fields[] = [ 'type' => 'hidden', 'name' => $key, 'value' => $value, 'input_class' => 'no_clear' ];
		}
		KERP_Helpers_Template::render_modal( [
			'id'     => 'kerpLeadsBranch',
			'title'  => 'افزودن اعضا به مسیر فروش دیگر',
			'action' => 'leads_branch',
			'page'   => $return_route,
			'body'   => $body,
			'fields' => $fields,
			'button' => 'افزودن به مسیر',
		] );
	endif; ?>
<?php if ( $can_manage ) KERP_Helpers_Template::render_template( 'modules/leads/partials/bulk-modals.php', [ 'return_route' => $return_route, 'campaign_id' => $campaign_id ] ); ?>
</div>
