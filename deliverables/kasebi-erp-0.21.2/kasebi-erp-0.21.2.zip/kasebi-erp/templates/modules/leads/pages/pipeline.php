<?php
defined( 'ABSPATH' ) || exit;
if ( ! current_user_can( KERP_Admin::CAPABILITY ) && ! kerp_can( 'leads.view', 'view' ) ) return;
$service = KERP_Modules_Leads_Service::instance();
$view = KERP_Modules_Leads_Pipeline_View::class;
$pipeline_id = absint( $page_context['route_params']['pipeline_id'] ?? 0 );
$pipeline = $service->get_campaign( $pipeline_id );
if ( ! $pipeline ) { echo '<div class="alert alert-warning">مسیر فروش پیدا نشد.</div>'; return; }
$summary = $service->pipeline_summary( $pipeline_id );
$route = $view::ROUTE . $pipeline_id . '/';
$members_url = '/erp/leads/?campaign_id=' . $pipeline_id;
$can_configure = KERP_Modules_Leads_View::can_configure();
$active_count = count( array_filter( $summary['stages'], static fn( $stage ) => ! empty( $stage['active'] ) ) );
$has_registration_stages = (bool) array_filter( $summary['stages'], [ KERP_Modules_Leads_Registration::class, 'is_reserved_stage' ] );
$next_position = 10;
foreach ( $summary['stages'] as $stage ) $next_position = max( $next_position, (int) $stage['position'] + 10 );
?>
<div class="kerp-marketing kerp-pipelines marketing-interior">
<div class="mb-3"><a class="page_activator" data-url="<?php echo esc_attr( $view::ROUTE ); ?>" href="<?php echo esc_url( home_url( $view::ROUTE ) ); ?>"><em class="icon ni ni-arrow-right"></em> همه مسیرهای فروش</a></div>
<div class="mb-3"><a class="btn btn-sm btn-outline-primary page_activator" data-url="<?php echo esc_attr( '/erp/marketing/pipelines/dashboard/?campaign_id=' . $pipeline_id ); ?>" href="<?php echo esc_url( home_url( '/erp/marketing/pipelines/dashboard/?campaign_id=' . $pipeline_id ) ); ?>"><em class="icon ni ni-bar-chart-alt"></em><span>داشبورد آماری مسیرهای فروش</span></a></div>
<div class="nk-block-head marketing-page-hero kerp-pipeline-hero">
    <div class="kerp-pipeline-hero-layout">
        <div class="kerp-pipeline-hero-intro">
            <span class="overline-title">مارکتینگ / مسیر فروش</span>
            <h3 class="nk-block-title"><?php echo esc_html( $pipeline['name'] ); ?></h3>
            <p class="mb-0"><?php echo $pipeline['status'] === 'active' ? 'مسیر فعال' : 'مسیر بایگانی‌شده · اعضا و سوابق محفوظ هستند'; ?></p>
        </div>
        <div class="kerp-pipeline-hero-actions">
            <a class="btn btn-primary page_activator" data-url="<?php echo esc_attr( $members_url ); ?>" href="<?php echo esc_url( home_url( $members_url ) ); ?>">مشاهده اعضا</a>
            <?php if ( $can_configure ) : ?>
                <button type="button" class="btn btn-outline-light" data-bs-toggle="modal" data-bs-target="#kerpPipelineEdit<?php echo $pipeline_id; ?>">ویرایش مسیر فروش</button>
                <button type="button" class="btn btn-outline-light" data-bs-toggle="modal" data-bs-target="#kerpPipelineExitSMS<?php echo $pipeline_id; ?>"><em class="icon ni ni-mail"></em><span>پیامک خروج</span></button>
                <button type="button" class="btn btn-outline-light" data-bs-toggle="modal" data-bs-target="#kerpPipelineDuplicate<?php echo $pipeline_id; ?>"><em class="icon ni ni-copy"></em><span>تکثیر مسیر فروش</span></button>
            <?php endif; ?>
            <span class="kerp-pipeline-hero-copy"><?php $view::copy_identifier( $pipeline_id, 'شناسه مسیر فروش' ); ?></span>
        </div>
    </div>
</div>
<?php KERP_Helpers_Template::render_template( 'modules/leads/partials/registration-builder.php', [ 'pipeline_id' => $pipeline_id, 'can_configure' => $can_configure ] ); ?>
<?php if ( $can_configure ) $view::exit_sms_modal( $pipeline ); ?>
<div class="kerp-pipeline-metrics mb-4">
<?php foreach ( [ 'کل اعضا' => $summary['total'], 'مراحل فعال' => $active_count, 'مراحل غیرفعال' => count( $summary['stages'] ) - $active_count, 'اعضای بدون مرحله معتبر' => $summary['unassigned'] ] as $label => $value ) : ?>
<div class="card card-bordered m-0"><div class="card-inner"><span class="text-soft"><?php echo esc_html( $label ); ?></span><strong><?php echo esc_html( number_format_i18n( $value ) ); ?></strong></div></div>
<?php endforeach; ?></div>
<div class="card card-bordered"><div class="card-inner border-bottom"><div class="card-title-group flex-wrap gap-2"><div><h5>مراحل مسیر فروش</h5><p class="text-soft mb-0"><?php echo $has_registration_stages ? 'دو مرحله اول برای فرم ثبت‌نام رزرو شده‌اند. اعداد، تعداد اعضای فعلی هر مرحله هستند؛ مراحل بعدی قابل تنظیم‌اند.' : 'اعداد، تعداد اعضای فعلی هر مرحله هستند؛ ترتیب و روش ورود را در ویرایش مرحله تنظیم کنید.'; ?></p></div><?php if ( $can_configure ) : ?><button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#kerpPipelineStage0"><em class="icon ni ni-plus"></em><span>مرحله جدید</span></button><?php endif; ?></div></div>
<?php if ( ! $summary['stages'] ) : ?><div class="card-inner text-center py-5"><em class="icon ni ni-layers fs-1 text-soft"></em><h5 class="mt-3">هنوز مرحله‌ای تعریف نشده است</h5><p class="text-soft mb-0">مراحل مسیر مانند ثبت‌نام، مشاوره، خرید و پشتیبانی را تعریف کنید.</p></div><?php else : ?>
<ol class="kerp-pipeline-stages list-unstyled mb-0">
<?php foreach ( $summary['stages'] as $index => $stage ) :
	$is_registration_stage = KERP_Modules_Leads_Registration::is_reserved_stage( $stage );
	$count = (int) $stage['member_count'];
	$percent = $summary['total'] ? round( 100 * $count / $summary['total'], 1 ) : 0;
	$stage_url = $members_url . '&stage_id=' . (int) $stage['id'];
	$stage_actions = [
		[ 'title' => 'مشاهده اعضا', 'icon' => 'ni ni-users', 'url' => home_url( $stage_url ), 'data_url' => $stage_url, 'class' => 'page_activator' ],
	];
	if ( $can_configure ) {
		$stage_actions[] = [ 'title' => 'اقدام‌های کارشناس', 'icon' => 'ni ni-unlock', 'data' => [ 'bs-toggle' => 'modal', 'bs-target' => '#kerpPipelineStageActions' . (int) $stage['id'] ] ];
		if ( ! $is_registration_stage ) $stage_actions[] = [ 'title' => 'ویرایش مرحله', 'icon' => 'ni ni-edit', 'data' => [ 'bs-toggle' => 'modal', 'bs-target' => '#kerpPipelineStage' . (int) $stage['id'] ] ];
		$stage_actions[] = [ 'title' => 'پیامک زمان‌بندی‌شده', 'icon' => 'ni ni-mail', 'data' => [ 'bs-toggle' => 'modal', 'bs-target' => '#kerpStageSMS' . (int) $stage['id'] ] ];
		if ( ! $is_registration_stage ) $stage_actions[] = [ 'title' => 'حذف مرحله', 'icon' => 'ni ni-trash', 'class' => 'text-danger', 'data' => [ 'bs-toggle' => 'modal', 'bs-target' => '#kerpPipelineStageDelete' . (int) $stage['id'] ] ];
	}
?>
<li class="card-inner kerp-pipeline-stage border-bottom">
<div class="kerp-pipeline-stage-heading">
	<span class="kerp-pipeline-step"><?php echo esc_html( number_format_i18n( $index + 1 ) ); ?></span>
	<div class="kerp-pipeline-stage-title">
		<h6 class="mb-1"><?php echo esc_html( $stage['name'] ); ?></h6>
		<?php if ( $is_registration_stage ) : ?><div class="mb-1"><span class="badge kerp-pipeline-badge kerp-pipeline-badge-count">رزروشده برای فرم ثبت‌نام</span></div><?php endif; ?>
		<span class="text-soft">ترتیب <?php echo esc_html( number_format_i18n( $stage['position'] ) ); ?> · <?php echo esc_html( $view::triggers()[ $stage['trigger_type'] ] ?? $stage['trigger_type'] ); ?><?php if ( $stage['trigger_ref'] !== '' && $stage['trigger_ref'] !== NULL ) : ?> · <?php echo $stage['trigger_type'] === 'gravity_form' ? 'شناسه فرم' : ( $stage['trigger_type'] === 'product_purchase' ? 'شناسه محصول' : ( $stage['trigger_type'] === 'learndash_completed' ? 'شناسه درس' : 'شناسه محرک' ) ); ?> <?php echo esc_html( $stage['trigger_ref'] ); ?><?php endif; ?></span>
	</div>
	<div class="kerp-pipeline-stage-status">
		<span class="badge kerp-pipeline-badge <?php echo $stage['active'] ? 'kerp-pipeline-badge-active' : 'kerp-pipeline-badge-muted'; ?>"><?php echo $stage['active'] ? 'فعال' : 'غیرفعال'; ?></span>
		<span class="kerp-pipeline-stage-copy">
			<button type="button" class="kerp-pipeline-stage-copy-icon clipboard-init"
			        data-clipboard-text="<?php echo (int) $stage['id']; ?>"
			        data-clip-text="کپی" data-clip-success="کپی شد" data-clip-error="کپی ناموفق بود"
			        data-bs-toggle="tooltip" data-bs-placement="top"
			        title="<?php echo esc_attr( 'کپی شناسه مرحله: ' . (int) $stage['id'] ); ?>"
			        aria-label="<?php echo esc_attr( 'کپی شناسه مرحله: ' . (int) $stage['id'] ); ?>">
				<em class="icon ni ni-copy" aria-hidden="true"></em>
				<span class="clipboard-text" role="status" aria-live="polite">کپی</span>
			</button>
		</span>
	</div>
</div>
<div class="kerp-pipeline-stage-bottom"><div class="kerp-pipeline-stage-stat"><div class="d-flex justify-content-between gap-2"><strong><?php echo esc_html( number_format_i18n( $count ) ); ?> نفر</strong><span class="text-soft"><?php echo esc_html( number_format_i18n( $percent, 1 ) ); ?>٪ از اعضا</span></div><div class="progress mt-2" role="progressbar" aria-label="سهم اعضای <?php echo esc_attr( $stage['name'] ); ?>" aria-valuenow="<?php echo esc_attr( $percent ); ?>" aria-valuemin="0" aria-valuemax="100"><div class="progress-bar" style="width:<?php echo esc_attr( $percent ); ?>%"></div></div></div>
<div class="kerp-pipeline-stage-actions"><?php KERP_Helpers_Template::render_template( 'app/components/list/row-actions.php', [ 'actions' => $stage_actions, 'display' => 'inline' ] ); ?></div></div>
</li>
<?php endforeach; ?></ol><?php endif; ?>
</div>
<?php if ( $can_configure ) { $view::campaign_modal( $pipeline, $route ); $view::duplicate_modal( $pipeline ); $view::stage_modal( $pipeline_id, [], $next_position ); foreach ( $summary['stages'] as $stage ) { $view::stage_modal( $pipeline_id, $stage ); $view::delete_stage_modal( $pipeline_id, $stage ); $view::sms_modal( $pipeline_id, $stage ); $view::stage_actions_modal( $pipeline_id, $stage ); } } ?>
</div>
