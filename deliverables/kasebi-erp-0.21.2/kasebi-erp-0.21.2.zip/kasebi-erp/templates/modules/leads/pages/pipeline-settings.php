<?php
defined( 'ABSPATH' ) || exit;
if ( ! KERP_Modules_Leads_View::can_configure() ) return;
$service = KERP_Modules_Leads_Service::instance();
$options = $service->sales_employee_options();
$saved = array_values( array_unique( array_map( 'absint', (array) get_option( 'kerp_leads_sales_users', [] ) ) ) );
$owners = array_values( array_intersect( $saved, array_keys( $options ) ) );
$excluded = count( array_diff( $saved, $owners ) );
?>
<form class="modal_form kerp-pipeline-settings" data-action="leads_save_sales_pool" data-page="/erp/marketing/pipelines/settings/">
<?php KERP_Modules_Leads_View::hidden( 'leads_nonce', wp_create_nonce( 'kerp_leads' ) ); ?>
<div class="nk-block-head nk-block-head-sm"><div class="nk-block-between g-3"><div class="nk-block-head-content"><h3 class="nk-block-title page-title">تنظیمات مسیرهای فروش</h3><p class="text-soft">انتخاب کارکنان مسئول دریافت خودکار مشتریان بالقوه</p></div><div class="nk-block-head-content"><button type="button" class="btn btn-primary submit_modal_form"><em class="icon ni ni-save"></em><span>ذخیره تغییرات</span></button></div></div></div>
<div class="nk-block">
<?php KERP_Helpers_Template::render_template( 'app/components/settings/hero.php', [
	'icon' => 'ni ni-users', 'eyebrow' => 'مارکتینگ', 'title' => 'کارشناسان فروش چرخشی',
	'description' => 'این فهرست بین همه مسیرهای فروش مشترک است. مشتریان بالقوه جدید بدون مسئول، به نوبت به کارکنان انتخاب‌شده تخصیص داده می‌شوند.',
	'stats' => [ [ 'label' => 'کارکنان فعال قابل انتخاب', 'value' => number_format_i18n( count( $options ) ) ], [ 'label' => 'کارشناسان انتخاب‌شده', 'value' => number_format_i18n( count( $owners ) ) ] ],
] ); ?>
</div>
<div class="nk-block"><div class="card card-bordered"><div class="card-inner border-bottom"><div class="card-title-group"><div class="card-title"><h6 class="title"><em class="icon ni ni-users me-1"></em> اعضای چرخه فروش</h6><p class="text-soft mb-0">فقط کارکنان فعال ثبت‌شده در ERP نمایش داده می‌شوند.</p></div></div></div><div class="card-inner">
<?php if ( $excluded ) : ?><div class="alert alert-warning">تعداد <?php echo esc_html( number_format_i18n( $excluded ) ); ?> مورد از انتخاب‌های قبلی، کارمند فعال ERP نیستند و در تخصیص جدید شرکت نمی‌کنند. با ذخیره، فهرست اصلاح می‌شود.</div><?php endif; ?>
<?php if ( ! $options ) : ?><div class="alert alert-info">کارمند فعالی برای انتخاب وجود ندارد. ابتدا کارمند را در بخش کارکنان ثبت و فعال کنید.</div><?php endif; ?>
<div class="row g-3">
<?php KERP_Helpers_Template::render_template( 'app/components/fields/select.php', [ 'field' => [
	'id' => 'kerp-pipeline-sales-employees', 'name' => 'settings[sales_users]', 'type' => 'select',
	'label' => 'کارکنان عضو فروش چرخشی', 'placeholder' => 'انتخاب کارکنان', 'multiple' => TRUE,
	'options' => $options, 'value' => $owners, 'class' => 'col-12', 'input_class' => 'no_clear',
] ] ); ?>
</div>
<p class="text-soft mt-3 mb-0">با خالی‌گذاشتن این فهرست، تخصیص خودکار متوقف می‌شود. حذف کارشناس از چرخه، مسئول مشتریان بالقوه قبلی را تغییر نمی‌دهد. کارکنان غیرفعال یا حذف‌شده هنگام تخصیص جدید کنار گذاشته می‌شوند.</p>
</div></div></div>
<div class="nk-block"><a class="btn btn-outline-light page_activator" data-url="/erp/marketing/pipelines/" href="<?php echo esc_url( home_url( '/erp/marketing/pipelines/' ) ); ?>">بازگشت به مسیرهای فروش</a></div>
</form>
