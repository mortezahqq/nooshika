<?php
defined( 'ABSPATH' ) || exit;
$customer_id        = absint( $customer_id ?? 0 );
$service            = KERP_Modules_Leads_Service::instance();
$view               = KERP_Modules_Leads_View::class;
$memberships        = $service->get_user_memberships( $customer_id );
$events             = $service->get_timeline( $customer_id );
$events_by_campaign = [];
foreach ( $events as $event ) {
	$events_by_campaign[ $event['campaign_id'] ][] = $event;
}
$owner_ids     = array_filter( array_map( 'absint', (array) get_option( 'kerp_leads_sales_users', [] ) ) );
$owners        = $owner_ids ? get_users( [ 'include' => $owner_ids, 'orderby' => 'display_name' ] ) : [];
$owner_choices = [ 0 => 'بدون تخصیص' ];
foreach ( $owners as $owner ) {
	$owner_choices[ $owner->ID ] = get_user_name_by_id( $owner->ID );
}
$return_page  = '/erp/customers/' . $customer_id . '/?tab=lead-journey';
$first_source = (string) get_user_meta( $customer_id, 'kerp_lead_first_source', TRUE );
$entered_at   = (string) get_user_meta( $customer_id, 'kerp_lead_entered_at', TRUE );
$can_manage   = $view::can_manage();
$branch_campaigns = [];
$active_stage_campaigns = [];
foreach ( $service->get_all_stages() as $candidate_stage ) {
    if ( ! empty( $candidate_stage['active'] ) ) $active_stage_campaigns[ (int) $candidate_stage['campaign_id'] ] = TRUE;
}
foreach ( $service->get_campaigns() as $candidate ) {
    if ( $candidate['status'] === 'active' && isset( $active_stage_campaigns[ (int) $candidate['id'] ] ) ) $branch_campaigns[] = (int) $candidate['id'];
}

?>
<div class="kerp-customer-tab-controls d-lg-none">
    <div class="kerp-customer-mobile-nav">
        <a href="#" class="toggle btn btn-icon btn-trigger" data-target="customerAside"
           aria-label="<?php esc_attr_e( 'نمایش منوی کاربر', 'kasebi-erp' ); ?>"><em class="icon ni ni-menu-alt-r"></em></a>
    </div>
</div>
<?php
$journey_description = sprintf( 'اولین منبع: %s', esc_html( [
	                                                            'woocommerce'  => 'خرید از فروشگاه',
                                                                'registration' => 'فرم ثبت‌نام مسیر فروش',
	                                                            'gravity_form' => 'فرم سایت',
	                                                            'import'       => 'ورود گروهی',
	                                                            'manual'       => 'ثبت دستی',
                                                            ][ $first_source ] ?? ( $first_source ?: 'نامشخص' ) ) );
if ( $entered_at ) {
	$journey_description .= ' · ' . sprintf( 'تاریخ ورود: %s', esc_html( KERP_Helpers_Date::local_datetime_to_jalali( $entered_at ) ) );
}
KERP_Helpers_Template::render_template( 'app/components/customer-tab-hero.php', [
	'icon'        => 'ni ni-growth',
	'eyebrow'     => __( 'سفر مشتری', 'kasebi-erp' ),
	'title'       => __( 'مسیرهای فروش مشتری', 'kasebi-erp' ),
	'description' => $journey_description,
] );
?>
<?php if ( ! $memberships ) : ?>
    <div class="alert alert-light">هنوز مسیر فروشی برای این مشتری ثبت نشده است.</div><?php endif; ?>
<?php foreach ( $memberships as $membership ) :
	$campaign_id = (int) $membership['campaign_id'];
	$current_stage_id = (int) $membership['current_stage_id'];
    $has_exited = ! empty( $membership['exited_at'] );
    $branch_targets = array_values( array_diff( $branch_campaigns, [ $campaign_id ] ) );
    $can_branch_here = $current_stage_id && ! empty( $branch_targets );
	$stage_choices = [ 0 => 'انتخاب مرحله' ];
	foreach ( $service->get_stages( $campaign_id ) as $stage ) {
		$stage_choices[ $stage['id'] ] = $stage['name'];
	}
	$hidden        = [ 'user_id' => $customer_id, 'campaign_id' => $campaign_id ];
	$current_owner = get_userdata( (int) $membership['owner_id'] );
	$choices       = $owner_choices;
	if ( $current_owner ) {
		$choices[ $current_owner->ID ] = get_user_name_by_id( $current_owner->ID );
	}
	?>
    <div class="nk-block card card-bordered kerp-journey-path">
        <div class="card-inner kerp-journey-path-head">
            <div class="kerp-journey-path-title">
                <div>
                    <h5><?php echo esc_html( $membership['campaign_name'] ); ?></h5>
                    <p class="kerp-journey-meta">ورود به
                        مسیر: <?php echo esc_html( KERP_Helpers_Date::local_datetime_to_jalali( (string) $membership['joined_at'] ) ); ?>
                        ·
                        کارشناس: <?php echo esc_html( $current_owner ? get_user_name_by_id( $current_owner->ID ) : 'تخصیص‌نیافته' ); ?></p>
                    <?php if ( $has_exited ) : ?><p class="kerp-journey-meta">خروج از مسیر: <?php echo esc_html( KERP_Helpers_Date::local_datetime_to_jalali( (string) $membership['exited_at'] ) ); ?></p><?php endif; ?>
                </div>
                <span
                    class="kerp-journey-current"><span><?php echo $has_exited ? 'آخرین مرحله · خارج‌شده' : 'مرحله فعلی'; ?></span> <?php echo esc_html( $membership['stage_name'] ?: 'بدون مرحله' ); ?></span>
            </div>
            <?php KERP_Helpers_Template::render_template( 'modules/leads/partials/customer-info-buttons.php', [ 'user_id' => $customer_id, 'campaign_id' => $campaign_id ] ); ?>
            <?php
            $configured_actions = KERP_Modules_Leads_Pipeline_View::configured_actions( $membership, $return_page );
            KERP_Helpers_Template::render_template( 'app/components/list/row-actions.php', [ 'display'=>'inline', 'actions'=>$configured_actions ] );
            KERP_Modules_Leads_Pipeline_View::configured_actions( $membership, $return_page, TRUE );
            ?>
            <?php if ( $can_manage && ! $has_exited ) : ?>
                <div class="kerp-journey-actions">
                    <button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal"
                            data-bs-target="#kerpJourneyEdit<?php echo $campaign_id; ?>"><em
                            class="icon ni ni-edit"></em><span>تغییر مرحله و کارشناس</span></button>
					<?php if ( $can_branch_here ) : ?>
                    <button type="button" class="btn btn-sm btn-outline-primary" data-bs-toggle="modal"
                            data-bs-target="#kerpJourneyBranch<?php echo $campaign_id; ?>"><em
                                class="icon ni ni-plus"></em><span>افزودن به مسیر فروش دیگر</span>
                        </button><?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
        <div class="card-inner">
            <div class="kerp-journey-timeline-heading"><h6>روند پیشرفت مشتری</h6>
                <span>جدیدترین اقدامات در ابتدا</span></div>
            <ol class="kerp-journey-timeline">
				<?php foreach ( $events_by_campaign[ $campaign_id ] ?? [] as $event ) :
					$payload = json_decode( (string) $event['payload'], TRUE ) ?: [];
					$actor = get_userdata( (int) $event['actor_id'] );
					$is_entry = ( $event['event_type'] ?? '' ) === 'campaign_joined';
					$event_title = $is_entry ? 'ورود به مسیر فروش' : $event['title'];
					$event_icon = $is_entry ? 'ni-signin' : ( ! empty( $event['stage_id'] ) ? 'ni-growth' : 'ni-history' );
					?>
                    <li class="kerp-journey-event">
                        <span class="kerp-journey-event-node" aria-hidden="true"><em
                                class="icon ni <?php echo esc_attr( $event_icon ); ?>"></em></span>
                        <div class="kerp-journey-event-body">
                            <div class="kerp-journey-event-heading">
                                <strong><?php echo esc_html( $event_title ); ?></strong>
                                <bdi class="kerp-journey-event-date"
                                     dir="ltr"><?php echo esc_html( KERP_Helpers_Date::local_datetime_to_jalali( (string) $event['occurred_at'] ) ); ?></bdi>
                            </div>
                            <small
                                class="text-soft">انجام‌دهنده: <?php echo esc_html( $actor ? get_user_name_by_id( $actor->ID ) : 'خودکار' ); ?></small>
							<?php if ( ! empty( $payload['from_campaign_name'] ) ) : ?><p
                                class="mb-1"><?php echo esc_html( $payload['from_campaign_name'] . ' / ' . $payload['from_stage_name'] . ' ← ' . $payload['to_campaign_name'] . ' / ' . $payload['to_stage_name'] ); ?></p><?php endif; ?>
							<?php if ( ! empty( $payload['note'] ) ) : ?><div class="text-soft kerp-lead-note-content"><?php echo ! empty( $payload['note_format'] ) && $payload['note_format'] === 'html' ? wp_kses_post( $payload['note'] ) : nl2br( esc_html( $payload['note'] ) ); ?></div><?php endif; ?>
							<?php if ( ! empty( $payload['order_id'] ) ) : ?><small>سفارش
                                #<?php echo absint( $payload['order_id'] ); ?></small><?php endif; ?>
                        </div>
                    </li>
				<?php endforeach; ?>
            </ol>
			<?php if ( empty( $events_by_campaign[ $campaign_id ] ) ) : ?><p class="text-soft py-3">هنوز اقدامی در این
                مسیر ثبت نشده است.</p><?php endif; ?>
			<?php if ( $can_manage && ! $has_exited ) : ?>

				<?php
                $exit_id = 'kerpJourneyExit' . $campaign_id;
                $exit_fields = [ [ 'type' => 'quill', 'name' => 'note', 'label' => 'دلیل خروج', 'class' => 'col-12', 'value' => '' ] ];
                foreach ( [ 'leads_nonce' => wp_create_nonce( 'kerp_leads' ), 'expected_stage_id' => $current_stage_id ] + $hidden as $key => $value ) {
                    $exit_fields[] = [ 'type' => 'hidden', 'name' => $key, 'value' => $value, 'input_class' => 'no_clear' ];
                }
                foreach ( $exit_fields as $index => &$field ) $field['id'] = $exit_id . '-field-' . $index;
                unset( $field );
                KERP_Helpers_Template::render_modal( [
                    'id' => $exit_id, 'title' => 'خروج از مسیر فروش', 'action' => 'leads_exit_pipeline', 'page' => $return_page,
                    'fields' => $exit_fields, 'button' => 'تأیید خروج از مسیر',
                    'body' => '<div class="col-12"><div class="alert alert-warning">با خروج از «' . esc_html( $membership['campaign_name'] ) . '»، پیشروی خودکار و پیامک‌های منتظر این مسیر متوقف می‌شوند. تاریخچه و آخرین مرحله حفظ می‌شود. این عملیات ورود مجدد خودکار ندارد.</div></div>',
                ] );
                $edit_id = 'kerpJourneyEdit' . $campaign_id;
                $edit_fields = [
                    [ 'type' => 'select', 'name' => 'stage_id', 'label' => 'مرحله', 'options' => $stage_choices, 'value' => $current_stage_id, 'class' => 'col-md-6', 'input_class' => 'no_clear' ],
                    [ 'type' => 'select', 'name' => 'owner_id', 'label' => 'کارشناس فروش', 'options' => $choices, 'value' => $membership['owner_id'], 'class' => 'col-md-6', 'input_class' => 'no_clear' ],
                    [ 'type' => 'quill', 'name' => 'note', 'label' => 'توضیح تغییرات', 'class' => 'col-12', 'value' => '' ],
                ];
                foreach ( [ 'leads_nonce' => wp_create_nonce( 'kerp_leads' ) ] + $hidden as $key => $value ) {
                    $edit_fields[] = [ 'type' => 'hidden', 'name' => $key, 'value' => $value, 'input_class' => 'no_clear' ];
                }
                foreach ( $edit_fields as $index => &$field ) $field['id'] = $edit_id . '-field-' . $index;
                unset( $field );
                KERP_Helpers_Template::render_modal( [
                    'id' => $edit_id, 'title' => 'تغییر مرحله و کارشناس',
                    'action' => 'leads_update_membership', 'page' => $return_page,
                    'fields' => $edit_fields, 'button' => 'ذخیره تغییرات',
                    'body' => '<div class="col-12"><p class="text-soft mb-0">' . esc_html( $membership['campaign_name'] ) . '</p></div>',
                ] );
				if ( $can_branch_here ) {
					ob_start(); ?>
                    <div class="col-12">
                        <p class="text-soft">کاربر در مرحله «<?php echo esc_html( $membership['stage_name'] ); ?>» این
                            مسیر باقی می‌ماند و هم‌زمان عضو مسیر مقصد می‌شود.</p>
						<?php $view::pipeline_picker( 'target_campaign_id', 'target_stage_id', 0, 0, $campaign_id, FALSE, $branch_targets );
						 ?>
                    </div>
					<?php
					$branch_fields = [
                        [ 'type' => 'quill', 'name' => 'note', 'label' => 'توضیح افزودن به مسیر فروش', 'id' => 'kerpJourneyBranch' . $campaign_id . '-note', 'class' => 'col-12', 'value' => '' ],
                        [ 'type' => 'hidden', 'name' => 'note_format', 'value' => 'html', 'id' => 'kerpJourneyBranch' . $campaign_id . '-format', 'input_class' => 'no_clear' ],
                    ];
					foreach (
						[
							'leads_nonce'        => wp_create_nonce( 'kerp_leads' ),
							'user_id'            => $customer_id,
							'source_campaign_id' => $campaign_id,
							'source_stage_id'    => $current_stage_id,
						] as $key => $value
					) {
						$branch_fields[] = [
							'type'        => 'hidden',
							'name'        => $key,
							'value'       => $value,
							'input_class' => 'no_clear',
							'id'          => 'kerpJourneyBranch' . $campaign_id . '-' . $key,
						];
					}
					KERP_Helpers_Template::render_modal( [
						'id'     => 'kerpJourneyBranch' . $campaign_id,
						'title'  => 'افزودن به مسیر فروش دیگر',
						'action' => 'leads_branch',
						'page'   => $return_page,
						'fields' => $branch_fields,
						'body'   => ob_get_clean(),
						'button' => 'افزودن به مسیر دوم',
					] );
				}
				?>
			
			<?php endif; ?>
        </div>
    </div>
<?php endforeach; ?>
<?php KERP_Helpers_Template::render_template( 'modules/leads/partials/customer-info-modals.php' ); ?>
<?php if ( ! empty( $events_by_campaign[0] ) ) : ?>
    <div class="nk-block card card-bordered">
        <div class="card-inner"><h6>ورود اولیه به پرونده مشتری بالقوه</h6>
			<?php foreach ( $events_by_campaign[0] as $event ) : ?>
                <p><?php echo esc_html( KERP_Helpers_Date::local_datetime_to_jalali( (string) $event['occurred_at'] ) . ' · ' . $event['title'] ); ?></p><?php endforeach; ?>
        </div>
    </div>
<?php endif; ?>
