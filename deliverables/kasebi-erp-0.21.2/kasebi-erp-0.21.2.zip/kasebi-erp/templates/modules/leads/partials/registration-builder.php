<?php
defined( 'ABSPATH' ) || exit;
$config    = KERP_Modules_Leads_Registration::config( $pipeline_id );
$shortcode = '[kerp_pipeline_registration id="' . $pipeline_id . '"]';
?>
    <div class="card card-bordered mb-4 kerp-registration-summary">
        <div class="card-inner kerp-registration-summary-layout">
            <div class="kerp-registration-summary-info"><h6 class="mb-1">فرم ثبت‌نام اولیه</h6>
                <p class="text-soft mb-1"><?php echo empty( $config['enabled'] ) ? 'فرم هنوز منتشر نشده است.' : 'فرم آماده استفاده در برگه‌ها و لندینگ‌های سایت است.'; ?></p>
                <span class="kerp-registration-shortcode-copy">
                    <button type="button" class="btn btn-outline-primary clipboard-init kerp-registration-shortcode"
                            data-clipboard-text="<?php echo esc_attr( $shortcode ); ?>" data-clip-text="کپی شورت‌کد"
                            data-clip-success="کپی شد" data-clip-error="کپی ناموفق بود"
                            title="<?php echo esc_attr( $shortcode ); ?>" aria-label="کپی شورت‌کد فرم ثبت‌نام">
                        <bdi class="kerp-registration-shortcode-code"
                             dir="ltr"><?php echo esc_html( $shortcode ); ?></bdi>
                        <span class="kerp-registration-shortcode-action"><em class="icon ni ni-copy"
                                                                             aria-hidden="true"></em><span
                                class="clipboard-text" role="status" aria-live="polite">کپی شورت‌کد</span></span>
                    </button>
                </span>
            </div>
            <div class="kerp-registration-summary-actions">
                <button type="button" class="btn btn-outline-primary" data-bs-toggle="modal"
                        data-bs-target="#kerpRegistrationPreview<?php echo (int) $pipeline_id; ?>"><em class="icon ni ni-eye" aria-hidden="true"></em><span>پیش‌نمایش فرم</span></button>
			<?php if ( $can_configure ): ?>
                <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                        data-bs-target="#kerpPipelineRegistration">تنظیم فرم ثبت‌نام
                </button><?php endif; ?>
            </div>
        </div>
    </div>
<?php
KERP_Helpers_Template::render_template( 'modules/leads/partials/registration-preview.php', [ 'pipeline_id' => $pipeline_id, 'config' => $config ] );
if ( ! $can_configure ) {
	return;
}
ob_start(); ?>
    <div class="col-12 kerp-registration-builder">
        <div class="alert alert-light">نام و شماره موبایل همیشه اجباری‌اند. با انتشار فرم، دو مرحله اول مسیر برای فرم رزرو می‌شوند:
            «ثبت‌نام اولیه» برای اطلاعات قبل از تأیید موبایل و «تکمیل ثبت‌نام» پس از ثبت نهایی فرم. مراحل عادی بعد از آن‌ها قرار می‌گیرند. برای هر فیلد، محل نمایش را انتخاب کنید.
        </div>
        <h6 class="mb-3">نمایش فرم و فیلدهای ضروری</h6>
        <div class="row g-3 mb-4">
			<?php
			$display_fields = [
				[ 'type'  => 'switch',
				  'name'  => 'show_labels',
				  'label' => 'نمایش عنوان فیلدها (لیبل)',
				  'class' => 'col-12',
				],
				[ 'name' => 'name_label', 'label' => 'عنوان فیلد نام', 'required' => TRUE ],
				[ 'name' => 'name_placeholder', 'label' => 'متن راهنمای داخل فیلد نام (Placeholder)' ],
				[ 'name' => 'phone_label', 'label' => 'عنوان فیلد شماره موبایل', 'required' => TRUE ],
				[ 'name' => 'phone_placeholder', 'label' => 'متن راهنمای داخل فیلد شماره موبایل (Placeholder)' ],
				[ 'name' => 'first_button', 'label' => 'متن دکمه مرحله اول', 'required' => TRUE ],
				[ 'name' => 'second_button', 'label' => 'متن دکمه مرحله دوم', 'required' => TRUE ],
			];
			foreach ( $display_fields as $display_field ) {
				$display_field          += [ 'type'        => 'text',
				                             'class'       => 'col-12 col-sm-6',
				                             'input_class' => 'no_clear',
				];
				$display_field['value'] = $config['display'][ $display_field['name'] ];
				$display_field['name']  = 'display_' . $display_field['name'];
				$display_field['id']    = 'kerpRegistration-' . $display_field['name'];
				KERP_Helpers_Template::render_template( 'app/components/fields/' . $display_field['type'] . '.php', [ 'field' => $display_field ] );
			}
			?>
        </div>
        <h6 class="border-top pt-4 mb-3">فیلدهای تکمیلی</h6>
        <p class="form-note">سوییچ «نمایش پس از تأیید موبایل» خاموش باشد، فیلد در مرحله اول نمایش داده می‌شود؛ روشن
            باشد، در مرحله دوم. با روشن‌کردن «نمایش در جدول لیدها»، پاسخ فیلد در ستون «اطلاعات ثبت‌نام» نمایش داده می‌شود؛ همه فیلدهای انتخاب‌شده در همین ستون قرار می‌گیرند.</p>
        <div class="row g-3">
			<?php
			$registration_rows = array_map( static function( array $row ): array {
				$row['after_otp'] = (int) $row['phase'] === 2 ? 1 : 0;
				$row['options']   = implode( "\n", $row['options'] ?? [] );
				
				return $row;
			}, $config['fields'] ?? [] );
			KERP_Helpers_Template::render_template( 'app/components/fields/repeater.php', [
				'field' => [
					'id'          => 'kerpRegistrationFields',
					'name'        => 'registration_fields',
					'label'       => 'فیلدهای تکمیلی فرم',
					'type'        => 'repeater',
					'class'       => 'col-12',
					'row_class'   => 'col-12',
					'card_class'  => 'kerp-settings-field-card',
					'row_title'   => 'فیلد فرم ثبت‌نام',
					'row_icon'    => 'ni ni-edit',
					'value'       => $registration_rows,
					'button_text' => 'افزودن فیلد',
					'fields'      => [
						[ 'name' => 'key', 'type' => 'hidden' ],
						[
							'name'           => 'label',
							'label'          => 'عنوان فیلد (برای فیلترها و مدیریت)',
							'type'           => 'text',
							'repeater_class' => 'col-12 col-sm-6',
						],
						[
							'name'           => 'form_label',
							'label'          => 'لیبل فیلد در فرم',
							'type'           => 'text',
							'repeater_class' => 'col-12 col-sm-6',
							'description'    => 'به مشتری نمایش داده می‌شود؛ اگر خالی باشد، عنوان فیلد نمایش داده می‌شود.',
						],
						[
							'name'           => 'type',
							'label'          => 'نوع فیلد',
							'type'           => 'select',
							'repeater_class' => 'col-12 col-sm-6',
							'options'        => [
								'text'     => 'متن',
								'checkbox' => 'چک‌باکس (چند انتخاب)',
								'radio'    => 'رادیویی (یک انتخاب)',
								'select'   => 'فهرست کشویی',
							],
						],
						[
							'name'           => 'required',
							'label'          => 'پاسخ الزامی',
							'type'           => 'switch',
							'repeater_class' => 'col-12 col-sm-6',
						],
						[
							'name'           => 'after_otp',
							'label'          => 'نمایش پس از تأیید موبایل',
							'type'           => 'switch',
							'repeater_class' => 'col-12 col-sm-6',
						],
						[
							'name'           => 'placeholder',
							'label'          => 'متن راهنما (Placeholder)',
							'type'           => 'text',
							'repeater_class' => 'col-12',
							'description'    => 'داخل فیلد متن و فهرست کشویی نمایش داده می‌شود؛ برای چک‌باکس و رادیویی، بالای گزینه‌ها می‌آید.',
						],
						[
                            'name'           => 'show_in_leads',
                            'label'          => 'نمایش در جدول لیدها',
                            'type'           => 'switch',
                            'repeater_class' => 'col-12',
                            'description'    => 'پاسخ این فیلد در ستون مشترک «اطلاعات ثبت‌نام» به‌صورت بج نمایش داده می‌شود.',
                        ],
                        [
							'name'           => 'options',
							'label'          => 'گزینه‌ها',
							'type'           => 'textarea',
							'rows'           => 3,
							'repeater_class' => 'col-12',
							'description'    => 'هر گزینه را در یک خط جدا وارد کنید.',
							'conditional'    => TRUE,
							'cond_meta'      => 'type',
							'cond_operator'  => '==',
							'cond_expected'  => wp_json_encode( [ 'checkbox', 'radio', 'select' ] ),
						],
					],
				],
			] );
			?>
        </div>
        <div class="border-top pt-4 mt-4">
            <h6 class="mb-1">تأییدیه فرم</h6>
            <p class="text-soft mb-3">پس از تأیید شماره موبایل و تکمیل ثبت‌نام، چه اتفاقی بیفتد؟</p>
            <div class="row g-3">
				<?php
				$confirmation_fields = [
					[
						'type'     => 'select',
						'name'     => 'confirmation_type',
						'label'    => 'پس از تکمیل فرم',
						'options'  => [ 'message' => 'نمایش پیام', 'redirect' => 'انتقال به صفحه دیگر (ریدایرکت)' ],
						'value'    => $config['confirmation']['type'],
						'required' => TRUE,
					],
					[
						'type'          => 'text',
						'name'          => 'confirmation_redirect_url',
						'label'         => 'آدرس صفحه مقصد',
						'value'         => $config['confirmation']['redirect_url'],
						'required'      => TRUE,
						'description'   => 'آدرس کامل صفحه را با https:// یا http:// وارد کنید.',
						'conditional'   => TRUE,
						'cond_meta'     => 'confirmation_type',
						'cond_expected' => 'redirect',
						'input_class'   => 'fc-direction-ltr no_clear',
					],
					[
						'type'          => 'quill',
						'name'          => 'confirmation_message',
						'label'         => 'پیام پایان ثبت‌نام',
						'value'         => $config['confirmation']['message'],
						'required'      => TRUE,
						'conditional'   => TRUE,
						'cond_meta'     => 'confirmation_type',
						'cond_expected' => 'message',
					],
				];
				foreach ( $confirmation_fields as $confirmation_field ) {
					$confirmation_field       += [ 'class' => 'col-12', 'input_class' => 'no_clear' ];
					$confirmation_field['id'] = 'kerpRegistration-' . $confirmation_field['name'];
					KERP_Helpers_Template::render_template( 'app/components/fields/' . $confirmation_field['type'] . '.php', [ 'field' => $confirmation_field ] );
				}
				?>
            </div>
        </div>
    </div>
<?php
KERP_Helpers_Template::render_modal( [
	'id'     => 'kerpPipelineRegistration',
	'title'  => 'فرم ثبت‌نام مسیر فروش',
	'action' => 'leads_registration_save',
	'page'   => '/erp/marketing/pipelines/' . $pipeline_id . '/',
	'body'   => ob_get_clean(),
	'fields' => [
		[
			'type'        => 'select',
			'name'        => 'enabled',
			'label'       => 'انتشار فرم',
			'options'     => [ 0 => 'پیش‌نویس', 1 => 'منتشر شده' ],
			'value'       => ! empty( $config['enabled'] ) ? 1 : 0,
			'input_class' => 'no_clear',
			'class'       => 'col-12',
			'id'          => 'kerpRegistrationEnabled',
		],
		[ 'type' => 'hidden', 'name' => 'campaign_id', 'value' => $pipeline_id, 'input_class' => 'no_clear' ],
		[ 'type' => 'hidden', 'name' => 'display_settings_present', 'value' => '1', 'input_class' => 'no_clear' ],
		[
			'type'        => 'hidden',
			'name'        => 'leads_nonce',
			'value'       => wp_create_nonce( 'kerp_leads' ),
			'input_class' => 'no_clear',
		],
	],
	'button' => 'ذخیره فرم',
] );
