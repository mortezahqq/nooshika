<?php
defined( 'ABSPATH' ) || exit;
?>
<div class="kerp-lead-info-buttons" role="group" aria-label="اطلاعات مشتری در مسیر فروش">
    <?php foreach ( [ 'utm' => [ 'اطلاعات UTM', 'ni-link' ], 'registration' => [ 'اطلاعات فرم ثبت‌نام', 'ni-file-text' ] ] as $kind => [ $label, $icon ] ) : ?>
        <button type="button" class="btn btn-sm btn-outline-primary kerp_load_data_to_modal"
                data-action="leads_customer_info" data-info-kind="<?php echo esc_attr( $kind ); ?>"
                data-modal="#kerpLeadInfo<?php echo $kind === 'utm' ? 'Utm' : 'Registration'; ?>" data-modal-title="<?php echo esc_attr( $label ); ?>"
                data-user_id="<?php echo absint( $user_id ); ?>" data-campaign_id="<?php echo absint( $campaign_id ); ?>"
                data-leads_nonce="<?php echo esc_attr( wp_create_nonce( 'kerp_leads' ) ); ?>">
            <em class="icon ni <?php echo esc_attr( $icon ); ?>" aria-hidden="true"></em><span><?php echo esc_html( $label ); ?></span>
        </button>
    <?php endforeach; ?>
</div>
