<?php
defined( 'ABSPATH' ) || exit;
$base    = [ 'campaign_id' => $campaign_id, 'search' => $search, 'per_page' => $per_page, 'page_number' => 1, 'membership_status' => 'active' ];
if ( isset( $owner_filter ) ) $base['owner_id'] = $owner_filter;
$base['registration_status'] = $registration['status'] ?? '';
$base = array_merge( $base, $registration['query'] ?? [] );
$base['joined'] = $joined ?? [];
$base['unique_customers'] = ! empty( $unique_customers ) ? 1 : 0;
$base['entry_stage'] = $entry['stage'] ?? 0;
$base['entry_day'] = $entry['day'] ?? '';
$all_url = add_query_arg( array_merge( $base, [ 'stage_id' => 0 ] ), '/erp/leads/' );
?>
<section class="card card-bordered kerp-lead-stage-filter mb-4" aria-label="فیلتر مراحل مسیر فروش">
    <div class="card-inner pb-2">
        <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
            <div><h6 class="mb-1">مراحل <?php echo esc_html( $campaign_name ); ?></h6>
                <p class="small text-soft mb-0">برای نمایش مشتریان، مرحله را انتخاب کنید. تعدادها مربوط به کل اعضای فعلی
                    هر مرحله هستند.</p></div>
            <a class="btn btn-sm btn-outline-primary page_activator" <?php echo ! $stage_id ? 'aria-current="true"' : ''; ?>
               data-url="<?php echo esc_attr( $all_url ); ?>" href="<?php echo esc_url( home_url( $all_url ) ); ?>">همه
                مراحل (<?php echo esc_html( number_format_i18n( $summary['total'] ) ); ?> نفر)</a>
        </div>
    </div>
	<?php if ( $summary['stages'] ) : ?>
        <ol class="kerp-lead-stage-track list-unstyled mb-0" dir="rtl" tabindex="0"
            aria-label="مراحل به ترتیب؛ برای دیدن ادامه پیمایش کنید">
			<?php foreach ( $summary['stages'] as $index => $item ) :
				$selected = $stage_id === (int) $item['id'];
				$url = add_query_arg( array_merge( $base, [ 'stage_id' => (int) $item['id'] ] ), '/erp/leads/' );
				?>
                <li class="kerp-lead-stage-item">
                    <a class="kerp-lead-stage-card page_activator" <?php echo $selected ? 'aria-current="step"' : ''; ?>
                       data-url="<?php echo esc_attr( $url ); ?>" href="<?php echo esc_url( home_url( $url ) ); ?>">
                        <span class="kerp-lead-stage-top"><span
                                class="kerp-pipeline-step"><?php echo esc_html( number_format_i18n( $index + 1 ) ); ?></span><small><?php echo $selected ? 'انتخاب‌شده' : 'مرحله'; ?></small></span>
                        <strong class="kerp-lead-stage-name"><?php echo esc_html( $item['name'] ); ?></strong>
                        <span
                            class="kerp-lead-stage-count"><strong><?php echo esc_html( number_format_i18n( $item['member_count'] ) ); ?></strong> نفر<?php if ( ! $item['active'] ) : ?>
                                <small> · غیرفعال</small><?php endif; ?></span>
                    </a>
					<?php if ( $index < count( $summary['stages'] ) - 1 ) : ?><span class="kerp-lead-stage-arrow"
                                                                                    aria-hidden="true"><i
                            class="uik fa-angle-small-left"></i></span><?php endif; ?>
                </li>
			<?php endforeach; ?>
        </ol>
	<?php else : ?>
        <div class="card-inner text-center py-4"><p class="text-soft mb-0">هنوز مرحله‌ای برای این مسیر فروش تعریف نشده
                است.</p></div>
	<?php endif; ?>
</section>
