<?php
defined( 'ABSPATH' ) || exit;
$is_utm = $info_kind === 'utm';
$title = $is_utm ? 'اطلاعات UTM' : 'اطلاعات فرم ثبت‌نام';
$modal_id = $is_utm ? 'kerpLeadInfoUtm' : 'kerpLeadInfoRegistration';
$utm_labels = [ 'utm_source' => 'منبع', 'utm_medium' => 'رسانه', 'utm_campaign' => 'کمپین', 'utm_term' => 'عبارت جستجو', 'utm_content' => 'محتوای تبلیغ', 'utm_id' => 'شناسه کمپین', 'utm_source_platform' => 'پلتفرم منبع', 'utm_creative_format' => 'قالب تبلیغ', 'utm_marketing_tactic' => 'روش بازاریابی' ];
$utm_cards = [];
if ( $is_utm ) {
    $sources = [ [ 'title' => 'هنگام ورود به مسیر فروش', 'date' => $membership['joined_at'], 'values' => json_decode( (string) ( $membership['utm_json'] ?? '' ), TRUE ) ] ];
    foreach ( $responses['items'] as $entry ) {
        $values = json_decode( (string) $entry['utm_json'], TRUE );
        $values = is_array( $values ) ? $values : [];
        foreach ( $entry['answers'] as $answer ) if ( (int) $answer['phase'] === 0 && ! isset( $values[$answer['field_key']] ) ) $values[$answer['field_key']] = $answer['value'];
        $sources[] = [ 'title' => 'هنگام ارسال فرم ثبت‌نام', 'date' => $entry['created_at'], 'values' => $values ];
    }
    foreach ( $sources as $source ) {
        $values = [];
        foreach ( $utm_labels as $key => $label ) {
            $value = is_array( $source['values'] ) ? ( $source['values'][$key] ?? NULL ) : NULL;
            if ( is_scalar( $value ) && trim( (string) $value ) !== '' ) $values[$key] = (string) $value;
        }
        if ( $values ) $utm_cards[] = [ 'title' => $source['title'], 'date' => $source['date'], 'values' => $values ];
    }
}
?>
<div class="kerp-lead-info <?php echo $is_utm ? 'kerp-lead-info-attribution' : 'kerp-lead-info-registration'; ?>" dir="rtl">
    <div class="kerp-lead-info-summary">
        <h6><?php echo esc_html( $customer_name ); ?></h6>
        <p><?php echo esc_html( $campaign_name ); ?></p>
        <small><?php echo $is_utm ? 'اطلاعات ذخیره‌شده هنگام ورود به این مسیر و ارسال فرم‌های ثبت‌نام.' : 'سوابق ثبت‌نام · جدیدترین ابتدا'; ?></small>
    </div>
    <?php if ( $is_utm ) : ?>
        <?php foreach ( $utm_cards as $card ) : ?>
            <section class="kerp-lead-info-card">
                <div class="kerp-lead-info-heading"><h6><span class="kerp-lead-utm-source-icon"><em class="icon ni ni-link" aria-hidden="true"></em></span><?php echo esc_html( $card['title'] ); ?></h6><span class="kerp-lead-info-date"><em class="icon ni ni-calendar" aria-hidden="true"></em><bdi dir="ltr"><?php echo esc_html( KERP_Helpers_Date::local_datetime_to_jalali( (string) $card['date'] ) ); ?></bdi></span></div>
                <dl class="kerp-lead-info-grid kerp-lead-info-utm">
                    <?php foreach ( $card['values'] as $key => $value ) : ?>
                        <div><dt><span><?php echo esc_html( $utm_labels[$key] ); ?></span><bdi dir="ltr"><?php echo esc_html( $key ); ?></bdi></dt><dd dir="auto" title="<?php echo esc_attr( $value ); ?>"><?php echo esc_html( $value ); ?></dd></div>
                    <?php endforeach; ?>
                </dl>
            </section>
        <?php endforeach; ?>
    <?php else : ?>
        <?php foreach ( $responses['items'] as $entry ) :
            $schema = json_decode( (string) $entry['schema_json'], TRUE );
            $labels = is_array( $schema ) ? array_column( array_filter( $schema, 'is_array' ), 'label', 'key' ) : [];
            $status = [ 'pending' => 'منتظر تأیید شماره', 'verified' => 'در انتظار تکمیل اطلاعات', 'completed' => 'ثبت‌نام تکمیل شده' ][$entry['status']] ?? 'ثبت‌نام';
            ?>
            <section class="kerp-lead-info-card">
                <div class="kerp-lead-info-heading"><span class="kerp-lead-info-status <?php echo $entry['status'] === 'completed' ? 'is-complete' : 'is-pending'; ?>"><em class="icon ni <?php echo $entry['status'] === 'completed' ? 'ni-check-circle' : 'ni-clock'; ?>" aria-hidden="true"></em><?php echo esc_html( $status ); ?></span><span class="kerp-lead-info-date"><em class="icon ni ni-calendar" aria-hidden="true"></em><bdi dir="ltr"><?php echo esc_html( KERP_Helpers_Date::local_datetime_to_jalali( (string) $entry['created_at'] ) ); ?></bdi></span></div>
                <dl class="kerp-lead-info-grid kerp-lead-info-identity">
                    <div><dt>نام ثبت‌شده</dt><dd><?php echo esc_html( $entry['name'] ); ?></dd></div>
                    <div><dt>شماره موبایل</dt><dd><bdi dir="ltr"><?php echo esc_html( KERP_Helpers_Phone::with_zero( $entry['phone'] ) ); ?></bdi></dd></div>
                    <?php foreach ( [ 'verified_at' => 'تأیید شماره موبایل', 'completed_at' => 'تکمیل ثبت‌نام' ] as $key => $label ) : if ( empty( $entry[$key] ) ) continue; ?>
                        <div><dt><?php echo esc_html( $label ); ?></dt><dd><bdi dir="ltr"><?php echo esc_html( KERP_Helpers_Date::local_datetime_to_jalali( (string) $entry[$key] ) ); ?></bdi></dd></div>
                    <?php endforeach; ?>
                </dl>
                <?php foreach ( [ 1 => 'اطلاعات اولیه', 2 => 'اطلاعات تکمیلی' ] as $phase => $phase_title ) :
                    $fields = [];
                    foreach ( $entry['answers'] as $answer ) if ( (int) $answer['phase'] === $phase ) $fields[$answer['field_key']][] = $answer['value'];
                    ?>
                    <section class="kerp-lead-info-phase-section">
                    <h6 class="kerp-lead-info-phase"><span class="kerp-lead-info-phase-number"><?php echo $phase === 1 ? '۱' : '۲'; ?></span><?php echo esc_html( $phase_title ); ?></h6>
                    <?php if ( $fields ) : ?><dl class="kerp-lead-info-grid kerp-lead-info-answers">
                        <?php foreach ( $fields as $key => $values ) : ?><div><dt><?php echo esc_html( $labels[$key] ?? $key ); ?></dt><dd><?php echo esc_html( implode( "\n", $values ) ); ?></dd></div><?php endforeach; ?>
                    </dl><?php else : ?><p class="kerp-lead-info-muted">پاسخی برای این بخش ثبت نشده است.</p><?php endif; ?>
                    </section>
                <?php endforeach; ?>
            </section>
        <?php endforeach; ?>
    <?php endif; ?>
    <?php if ( $is_utm ? ! $utm_cards : ! $responses['items'] ) : ?>
        <div class="text-center py-5"><em class="icon ni <?php echo $is_utm ? 'ni-link' : 'ni-file-text'; ?> fs-1" aria-hidden="true"></em>
            <h6 class="mt-3"><?php echo $is_utm ? 'اطلاعات UTM ثبت نشده است' : 'فرم ثبت‌نامی ثبت نشده است'; ?></h6>
            <p class="kerp-lead-info-muted"><?php echo $is_utm ? 'برای سوابق این صفحه اطلاعات UTM ذخیره نشده است.' : 'این مشتری در این مسیر هنوز فرم ثبت‌نامی ارسال نکرده است.'; ?></p>
        </div>
    <?php endif; ?>
    <?php if ( $responses['pages'] > 1 ) : ?>
        <nav class="kerp-lead-info-pagination" aria-label="صفحه‌بندی اطلاعات ثبت‌نام">
            <?php foreach ( [ $responses['page'] - 1 => 'جدیدتر', $responses['page'] + 1 => 'قدیمی‌تر' ] as $page => $label ) : if ( $page < 1 || $page > $responses['pages'] ) continue; ?>
                <button type="button" class="btn btn-sm btn-outline-primary kerp_load_data_to_modal" data-action="leads_customer_info"
                        data-modal="#<?php echo esc_attr( $modal_id ); ?>" data-modal-title="<?php echo esc_attr( $title ); ?>"
                        data-info-kind="<?php echo esc_attr( $info_kind ); ?>" data-info-page="<?php echo absint( $page ); ?>"
                        data-user_id="<?php echo absint( $user_id ); ?>" data-campaign_id="<?php echo absint( $campaign_id ); ?>"
                        data-leads_nonce="<?php echo esc_attr( wp_create_nonce( 'kerp_leads' ) ); ?>"><?php echo esc_html( $label ); ?></button>
            <?php endforeach; ?>
            <small><?php echo esc_html( sprintf( 'صفحه %s از %s', number_format_i18n( $responses['page'] ), number_format_i18n( $responses['pages'] ) ) ); ?></small>
        </nav>
    <?php endif; ?>
</div>
