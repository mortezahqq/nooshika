<?php
defined( 'ABSPATH' ) || exit;
foreach ( [ 'Utm' => 'اطلاعات UTM', 'Registration' => 'اطلاعات فرم ثبت‌نام' ] as $suffix => $title ) {
    KERP_Helpers_Template::render_modal( [
        'type' => 'context', 'id' => 'kerpLeadInfo' . $suffix, 'title' => $title,
        'class' => 'modal-lg modal-dialog-scrollable',
        'body' => '<div class="kerp-dynamic-modal-content" aria-live="polite"></div>',
    ] );
}
