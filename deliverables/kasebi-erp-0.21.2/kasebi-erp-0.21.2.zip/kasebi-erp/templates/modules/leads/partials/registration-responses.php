<?php
defined( 'ABSPATH' ) || exit;
$labels = array_column( json_decode($entry['schema_json'], TRUE) ?: [], 'label', 'key' );
$status = [ 'pending'=>'شماره تأیید نشده', 'verified'=>'در انتظار تکمیل اطلاعات', 'completed'=>'ثبت‌نام تکمیل شده' ][$entry['status']] ?? '';
?>
<details class="card card-bordered p-3 mb-3"><summary class="d-flex flex-wrap justify-content-between gap-2"><strong>پاسخ‌های ثبت‌نام</strong><span class="badge bg-light text-dark"><?php echo esc_html($status); ?></span><span class="small text-soft"><?php echo esc_html(KERP_Helpers_Date::local_datetime_to_jalali($entry['created_at'])); ?></span></summary>
<p class="small mt-3"><?php echo esc_html($entry['name'] . ' · ' . KERP_Helpers_Phone::with_zero($entry['phone'])); ?></p>
<?php foreach ( [ 'verified_at' => 'تأیید هویت', 'completed_at' => 'تکمیل ثبت‌نام' ] as $date_key => $date_label ) : if ( empty($entry[$date_key]) ) continue; ?><p class="small text-soft mb-1"><?php echo esc_html($date_label . ': ' . KERP_Helpers_Date::local_datetime_to_jalali($entry[$date_key])); ?></p><?php endforeach; ?>
<?php foreach([1=>'اطلاعات اولیه — مرحله اول',2=>'اطلاعات تکمیلی — مرحله دوم',0=>'UTM ثبت‌نام'] as $phase=>$title): ?>
<h6 class="mt-3"><?php echo esc_html($title); ?></h6><dl class="row g-2 mb-0">
<?php foreach($answers as $answer): if((int)$answer['phase']!==$phase) continue; ?>
<div class="col-md-6" style="min-width:0"><dt class="small text-soft"><?php echo esc_html($labels[$answer['field_key']]??$answer['field_key']); ?></dt><dd class="mb-0" style="overflow-wrap:anywhere"><?php echo esc_html($answer['value']); ?></dd></div>
<?php endforeach; ?></dl><?php endforeach; ?>
</details>
