<?php
defined( 'ABSPATH' ) || exit;
$display = $config['display'];
$identity = $identity ?? [];
?>
<form class="kerp-registration<?php echo empty( $display['show_labels'] ) ? ' kerp-registration-hide-labels' : ''; ?>" data-otp-required="<?php echo $identity ? '0' : '1'; ?>" data-display="<?php echo esc_attr( wp_json_encode( $display, JSON_UNESCAPED_UNICODE ) ); ?>" data-campaign="<?php echo absint($campaign_id); ?>" data-fields="<?php echo esc_attr(wp_json_encode(array_values(array_filter($config['fields'],static fn($f)=>(int)$f['phase']===1)),JSON_UNESCAPED_UNICODE)); ?>" dir="rtl" aria-label="ثبت‌نام" novalidate>
<div class="kerp-registration-identity">
    <label><span class="kerp-registration-label"><?php echo esc_html( $display['name_label'] ); ?> <span aria-hidden="true">*</span></span>
        <input name="name" type="text" autocomplete="name" maxlength="190" aria-label="<?php echo esc_attr( $display['name_label'] ); ?>" placeholder="<?php echo esc_attr( $display['name_placeholder'] ); ?>" value="<?php echo esc_attr( $identity['name'] ?? '' ); ?>" required>
    </label>
    <label><span class="kerp-registration-label"><?php echo esc_html( $display['phone_label'] ); ?> <span aria-hidden="true">*</span></span>
        <input name="phone" type="tel" inputmode="tel" autocomplete="tel" dir="ltr" aria-label="<?php echo esc_attr( $display['phone_label'] ); ?>" placeholder="<?php echo esc_attr( $display['phone_placeholder'] ); ?>" value="<?php echo esc_attr( empty( $identity['phone'] ) ? '' : '0' . $identity['phone'] ); ?>" <?php echo ! empty( $identity['phone'] ) ? 'readonly' : ''; ?> required>
    </label>
</div>
<div class="kerp-registration-inputs"></div>
<div class="kerp-registration-confirmation" tabindex="-1" role="status" aria-live="polite" hidden></div>
<button type="submit" class="kerp-registration-submit"><?php echo esc_html( $display['first_button'] ); ?></button>
</form>
