<?php
defined( 'ABSPATH' ) || exit;
if ( ! current_user_can( KERP_Admin::CAPABILITY ) && ! kerp_can( 'leads.view', 'view' ) ) return;
$preview_id = 'kerpRegistrationPreview' . (int) $pipeline_id;
$display = $config['display'];
$confirmation = KERP_Modules_Leads_Registration::normalize_confirmation( [], $config['confirmation'] ?? [] );
if ( is_wp_error( $confirmation ) ) $confirmation = KERP_Modules_Leads_Registration::normalize_confirmation( [] );
// Deliberately no form, submission attributes, campaign payload, nonce or registration token.
$render_preview_field = static function( array $field ) use ( $preview_id ): void {
    $id = $preview_id . '-' . $field['key'];
    $type = $field['type'];
    $label = ( trim( $field['form_label'] ?? '' ) !== '' ? $field['form_label'] : $field['label'] ) . ( ! empty( $field['required'] ) ? ' *' : '' );
    ?>
    <fieldset class="kerp-registration-preview-field">
        <legend class="form-label kerp-registration-preview-label"><?php echo esc_html( $label ); ?></legend>
        <?php if ( in_array( $type, [ 'text', 'tel' ], TRUE ) ) : ?>
            <input class="form-control" type="<?php echo esc_attr( $type ); ?>" aria-label="<?php echo esc_attr( $label ); ?>" placeholder="<?php echo esc_attr( $field['placeholder'] ?? '' ); ?>" autocomplete="off" <?php echo $type === 'tel' ? 'dir="ltr" inputmode="tel"' : ''; ?>>
        <?php elseif ( $type === 'select' ) : ?>
            <select class="form-select" aria-label="<?php echo esc_attr( $label ); ?>">
                <option value=""><?php echo esc_html( ( $field['placeholder'] ?? '' ) ?: 'انتخاب کنید' ); ?></option>
                <?php foreach ( $field['options'] as $option ) : ?><option><?php echo esc_html( $option ); ?></option><?php endforeach; ?>
            </select>
        <?php else : ?>
            <?php if ( ! empty( $field['placeholder'] ) ) : ?><p class="form-note mb-2"><?php echo esc_html( $field['placeholder'] ); ?></p><?php endif; ?>
            <?php foreach ( $field['options'] as $index => $option ) : ?>
                <div class="custom-control custom-<?php echo $type === 'radio' ? 'radio' : 'checkbox'; ?> d-block mb-2">
                    <input class="custom-control-input" type="<?php echo $type === 'radio' ? 'radio' : 'checkbox'; ?>" name="<?php echo esc_attr( $id ); ?>" id="<?php echo esc_attr( $id . '-' . $index ); ?>">
                    <label class="custom-control-label" for="<?php echo esc_attr( $id . '-' . $index ); ?>"><?php echo esc_html( $option ); ?></label>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </fieldset>
    <?php
};
ob_start(); ?>
<div class="kerp-registration-preview<?php echo empty( $display['show_labels'] ) ? ' kerp-registration-preview-hide-labels' : ''; ?>"
     data-first-button="<?php echo esc_attr( $display['first_button'] ); ?>" data-second-button="<?php echo esc_attr( $display['second_button'] ); ?>" dir="rtl">
    <div class="alert alert-light mb-3">پیش‌نمایش تنظیمات ذخیره‌شده؛ بدون ساخت کاربر، ارسال پیامک یا ذخیره اطلاعات. برای ادامه، پرکردن فیلدها لازم نیست.</div>
    <ol class="kerp-registration-preview-progress list-unstyled" aria-label="مراحل پیش‌نمایش">
        <?php foreach ( [ 'اطلاعات اولیه', 'تأیید شماره', 'تکمیل اطلاعات', 'پایان' ] as $index => $label ) : ?>
            <li data-preview-indicator="<?php echo $index; ?>" <?php echo $index === 0 ? 'aria-current="step"' : ''; ?>><span><?php echo esc_html( number_format_i18n( $index + 1 ) ); ?></span><?php echo esc_html( $label ); ?></li>
        <?php endforeach; ?>
    </ol>
    <div class="kerp-registration-preview-card">
        <section data-preview-step="0">
            <h5 tabindex="-1">ثبت‌نام</h5>
            <?php foreach ( [ 'name' => 'text', 'phone' => 'tel' ] as $key => $type ) $render_preview_field( [ 'key' => $key, 'label' => $display[$key . '_label'], 'placeholder' => $display[$key . '_placeholder'], 'type' => $type, 'required' => TRUE ] ); ?>
            <?php foreach ( $config['fields'] as $field ) if ( (int) $field['phase'] === 1 ) $render_preview_field( $field ); ?>
        </section>
        <section data-preview-step="1" class="d-none">
            <h5 tabindex="-1">تأیید شماره موبایل</h5>
            <p class="text-soft">این مرحله نمایشی است؛ کدی ارسال نمی‌شود. با دکمه زیر ادامه دهید.</p>
            <label class="form-label" for="<?php echo esc_attr( $preview_id . '-otp' ); ?>">کد تأیید</label>
            <input class="form-control text-center" id="<?php echo esc_attr( $preview_id . '-otp' ); ?>" type="text" inputmode="numeric" dir="ltr" maxlength="4" placeholder="۱۲۳۴" autocomplete="off">
        </section>
        <section data-preview-step="2" class="d-none">
            <h5 tabindex="-1">تکمیل اطلاعات</h5>
            <?php $second_fields = array_filter( $config['fields'], static fn( $field ) => (int) $field['phase'] === 2 ); ?>
            <?php foreach ( $second_fields as $field ) $render_preview_field( $field ); ?>
            <?php if ( ! $second_fields ) : ?><p class="text-soft mb-0">برای این بخش فیلد تکمیلی تعریف نشده است؛ دکمه زیر پیام پایان فرم را نمایش می‌دهد.</p><?php endif; ?>
        </section>
        <section data-preview-step="3" class="d-none">
            <h5 tabindex="-1">پایان ثبت‌نام</h5>
            <?php if ( $confirmation['type'] === 'redirect' ) : ?>
                <p>در فرم اصلی، کاربر به آدرس زیر منتقل می‌شود:</p>
                <div class="kerp-registration-preview-destination" dir="ltr"><?php echo esc_html( $confirmation['redirect_url'] ); ?></div>
                <p class="form-note mt-2">در پیش‌نمایش انتقال انجام نمی‌شود.</p>
            <?php else : ?>
                <div class="kerp-registration-preview-message"><?php echo wp_kses_post( $confirmation['message'] ); ?></div>
            <?php endif; ?>
        </section>
        <div class="kerp-registration-preview-controls">
            <button type="button" class="btn btn-primary" data-preview-next><?php echo esc_html( $display['first_button'] ); ?></button>
            <button type="button" class="btn btn-outline-primary d-none" data-preview-restart><em class="icon ni ni-reload" aria-hidden="true"></em><span>نمایش دوباره</span></button>
            <button type="button" class="btn btn-outline-light d-none" data-preview-back>مرحله قبل</button>
        </div>
    </div>
</div>
<?php
KERP_Helpers_Template::render_modal( [ 'type' => 'context', 'id' => $preview_id, 'title' => 'پیش‌نمایش فرم ثبت‌نام', 'size' => 'lg', 'body' => ob_get_clean() ] );
