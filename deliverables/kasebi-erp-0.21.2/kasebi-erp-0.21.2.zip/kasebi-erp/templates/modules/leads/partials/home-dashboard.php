<?php
defined( 'ABSPATH' ) || exit;
$dashboard_route = '/erp/marketing/pipelines/dashboard/';
$total           = (int) ( $stats['totals']['memberships'] ?? 0 );
?>
<div class="kerp-leads-home-block">
	<?php if ( $kind === 'entries' ) : ?>
        <div class="kerp-dashboard-metric d-flex align-items-baseline gap-2 mb-2"><strong
                class="fs-24px"><?php echo esc_html( number_format_i18n( array_sum( $stats['daily'] ) ) ); ?></strong><span
                class="sub-text">ورودی در ۷ روز اخیر</span></div>
        <p class="sub-text">شامل امروز تا این لحظه؛ ورود یک مشتری به دو مسیر، دو ورودی محسوب می‌شود.</p>
		<?php if ( array_sum( $stats['daily'] ) ) : ?>
            <div class="position-relative w-100 mb-3" style="height:200px">
                <div class="kasebi-chart" style="height:200px" data-chart-type="bar" data-legend="0"
                     data-color="#8b5cf6" data-label="ورودی مسیر فروش" data-unit="ورودی"
                     data-labels="<?php echo esc_attr( wp_json_encode( array_values( $stats['days'] ) ) ); ?>"
                     data-data="<?php echo esc_attr( wp_json_encode( array_values( $stats['daily'] ) ) ); ?>">
                    <canvas role="img" aria-label="روند ورود به مسیرهای فروش در هفت روز اخیر">نمودار تعداد ورودی روزانه به مسیرهای فروش در هفت روز اخیر.
                    </canvas>
                </div>
            </div>
		<?php else : ?>
            <div class="text-center py-4"><em class="icon ni ni-bar-chart-alt fs-2 text-soft"></em>
                <p class="sub-text mt-2 mb-0">در هفت روز اخیر ورودی جدیدی ثبت نشده است.</p></div><?php endif; ?>
	<?php else :
		$rows = [];
		if ( $kind === 'pipelines' ) {
			$description = '۷ روز اخیر · ۵ مسیر اول بر اساس ورودی جدید؛ برای گزارش مراحل روی مسیر بزنید.';
			foreach ( array_slice( $stats['comparison'], 0, 5 ) as $item ) {
				$rows[] = [
					'label' => $item['name'],
					'count' => (int) $item['recent'],
					'url'   => $dashboard_route . '?campaign_id=' . (int) $item['id'],
				];
			}
		} elseif ( $kind === 'owners' ) {
			$description = 'وضعیت فعلی · تعداد ردیف‌های مشتری در مسیرهای فروش برای هر کارشناس؛ یک مشتری می‌تواند در چند مسیر باشد.';
			foreach ( $stats['owners'] as $item ) {
				$user   = get_userdata( (int) $item['owner_id'] );
				$rows[] = [
					'label' => $user ? get_user_name_by_id( $user->ID ) : ( $item['owner_id'] ? 'کارشناس حذف‌شده' : 'تخصیص‌نیافته' ),
					'count' => (int) $item['n'],
					'url'   => '/erp/leads/?owner_id=' . (int) $item['owner_id'],
				];
			}
			$others = max( 0, $total - array_sum( array_column( $rows, 'count' ) ) );
			if ( $others ) {
				$rows[] = [ 'label' => 'سایر کارشناسان', 'count' => $others, 'url' => '/erp/leads/' ];
			}
		} else {
			$description = 'وضعیت فعلی تخصیص در تمام مسیرها؛ با انتخاب تخصیص‌نیافته‌ها، مشتریان نیازمند مسئول را پیگیری کنید.';
			$unassigned  = (int) ( $stats['totals']['unassigned'] ?? 0 );
			$rows        = [
				[ 'label' => 'دارای کارشناس', 'count' => max( 0, $total - $unassigned ), 'url' => '' ],
				[ 'label' => 'تخصیص‌نیافته', 'count' => $unassigned, 'url' => '/erp/leads/?owner_id=0' ],
			];
		}
		if ( $kind === 'owners' && count( $rows ) > 6 ) {
			$remaining = array_slice( $rows, 5 );
			$rows      = array_slice( $rows, 0, 5 );
			$rows[]    = [
				'label' => 'سایر کارشناسان',
				'count' => array_sum( array_column( $remaining, 'count' ) ),
				'url'   => '/erp/leads/',
			];
		}
		$maximum  = max( array_merge( [ 1 ], array_column( $rows, 'count' ) ) );
		$has_data = array_sum( array_column( $rows, 'count' ) ) > 0;
		?>
        <p class="sub-text mb-3"><?php echo esc_html( $description ); ?></p>
		<?php if ( ! $has_data ) : ?>
        <div class="text-center py-4"><em class="icon ni ni-bar-chart-alt fs-2 text-soft"></em>
            <p class="sub-text mt-2 mb-0">داده‌ای برای نمایش وجود ندارد.</p></div>
	<?php else : ?>
        <ul class="list-unstyled mb-0">
		<?php foreach ( $rows as $index => $row ) : $percent = $kind === 'assignment' ? ( $total ? $row['count'] / $total * 100 : 0 ) : $row['count'] / $maximum * 100; ?>
            <li class="mb-3">
                <div class="d-flex justify-content-between align-items-center gap-2 mb-2"><span class="text-truncate"
                                                                                                style="min-width:0"
                                                                                                title="<?php echo esc_attr( $row['label'] ); ?>"><?php if ( $row['url'] ) : ?>
                            <a class="page_activator" data-url="<?php echo esc_attr( $row['url'] ); ?>"
                               href="<?php echo esc_url( home_url( $row['url'] ) ); ?>"><?php echo esc_html( $row['label'] ); ?></a><?php else : echo esc_html( $row['label'] ); endif; ?></span><strong
                        class="text-nowrap"><?php echo esc_html( number_format_i18n( $row['count'] ) ); ?><?php if ( $kind === 'assignment' ) : ?>
                            <small class="text-soft"> · <?php echo esc_html( number_format_i18n( $percent, 1 ) ); ?>
                            ٪</small><?php endif; ?></strong></div>
                <div class="progress progress-md" aria-hidden="true">
                    <div
                        class="progress-bar bg-<?php echo esc_attr( $kind === 'assignment' ? ( $index === 0 ? 'success' : 'warning' ) : [
							                                                                                                                'primary',
							                                                                                                                'info',
							                                                                                                                'success',
							                                                                                                                'warning',
						                                                                                                                ][ $index % 4 ] ); ?>"
                        style="width:<?php echo esc_attr( $percent ); ?>%"></div>
                </div>
            </li>
		<?php endforeach; ?></ul>
	<?php endif; ?>
	<?php endif; ?>
    <div class="border-top pt-3 mt-3"><a class="page_activator" data-url="<?php echo esc_attr( $dashboard_route ); ?>"
                                         href="<?php echo esc_url( home_url( $dashboard_route ) ); ?>">گزارش کامل
            مسیرهای فروش <em class="icon ni ni-arrow-right" aria-hidden="true"></em></a></div>
</div>
