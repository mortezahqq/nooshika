<?php
defined( 'ABSPATH' ) || exit;
$maximum = max( array_merge( [ 1 ], array_column( $bars, 'count' ) ) );
?>
<section class="card card-bordered"><div class="card-inner"><h5><?php echo esc_html( $title ); ?></h5><p class="text-soft"><?php echo esc_html( $description ); ?></p>
<?php if ( ! $bars ) : ?><p class="text-soft py-3 mb-0">داده‌ای برای نمایش نیست؛ مسیر فروش را انتخاب کنید یا فیلتر را تغییر دهید.</p><?php else : ?>
<ul class="marketing-status-bars">
<?php foreach ( $bars as $bar ) : ?><li style="--marketing-accent:#6573df"><div class="marketing-status-label"><span><?php if ( $bar['url'] ) : ?><a class="page_activator" data-url="<?php echo esc_attr( $bar['url'] ); ?>" href="<?php echo esc_url( home_url( $bar['url'] ) ); ?>"><?php echo esc_html( $bar['label'] ); ?></a><?php else : echo esc_html( $bar['label'] ); endif; ?></span><strong><?php echo esc_html( number_format_i18n( $bar['count'] ) ); ?></strong></div><div class="marketing-status-track" aria-hidden="true"><span style="width:<?php echo esc_attr( 100 * $bar['count'] / $maximum ); ?>%"></span></div></li><?php endforeach; ?></ul><?php endif; ?></div></section>
