<?php
defined( 'ABSPATH' ) || exit;
foreach ( [ 'stage' => 'تغییر گروهی مرحله', 'owner' => 'تخصیص گروهی کارشناس', 'exit' => 'خروج گروهی از مسیر فروش', 'course' => 'اعطای گروهی دسترسی دوره' ] as $operation => $title ) {
    $id = 'kerpLeadsBulk' . ucfirst( $operation );
    $fields = [];
    foreach ( [ 'leads_nonce' => wp_create_nonce( 'kerp_leads' ), 'operation' => $operation ] as $name => $value ) $fields[] = [ 'type' => 'hidden', 'id' => $id . '-' . $name, 'name' => $name, 'value' => $value, 'input_class' => 'no_clear' ];
    ob_start(); ?>
    <div class="col-12"><p class="kerp-leads-selection-count text-soft"></p><div class="kerp-leads-selected-inputs"></div>
    <?php if ( $operation === 'stage' ) : ?>
        <p class="text-soft">ردیف‌های انتخاب‌شده باید متعلق به یک مسیر فروش باشند. مسیر و مرحله مقصد را انتخاب کنید.</p>
        <?php KERP_Modules_Leads_View::pipeline_picker( 'campaign_id', 'stage_id', $campaign_id ); ?>
    <?php elseif ( $operation === 'course' ) : ?>
        <div class="alert alert-warning">برای هر ردیف، دسترسی دوره تنظیم‌شده در مرحله فعلی همان مشتری اعطا می‌شود؛ دوره‌ها ممکن است متفاوت باشند. ردیف‌های بدون اقدام دوره و مشتریان دارای دسترسی قبلی رد می‌شوند. نتیجه در تاریخچه ثبت می‌شود و مرحله مشتری تغییر نمی‌کند.</div>
    <?php elseif ( $operation === 'exit' ) : ?>
        <div class="alert alert-warning">مشتریان از مسیر مربوط به هر ردیف انتخاب‌شده خارج می‌شوند؛ عضویت آن‌ها در مسیرهای دیگر حفظ می‌شود. پیامک‌های منتظر این مسیر لغو و در صورت تنظیم پیامک خروج، آن پیامک ارسال خواهد شد. سابقه مشتریان حفظ می‌شود.</div>
    <?php else : ?>
        <div class="alert alert-warning">اگر مشتریان انتخاب‌شده از قبل کارشناس داشته باشند، کارشناس قبلی جایگزین می‌شود. مسئول پرونده مشتری نیز تغییر خواهد کرد.</div>
    <?php endif; ?></div>
    <?php
    $body = ob_get_clean();
    if ( $operation === 'owner' ) {
        $fields[] = [ 'type' => 'select', 'id' => $id . '-owner', 'name' => 'owner_id', 'label' => 'کارشناس جدید', 'options' => KERP_Modules_Leads_Service::instance()->sales_employee_options(), 'required' => TRUE, 'class' => 'col-12' ];
        $fields[] = [ 'type' => 'checkbox', 'id' => $id . '-confirm', 'name' => 'confirm_replace', 'options' => [ 'yes' => 'تأیید می‌کنم کارشناس قبلی و مسئول مشتریان انتخاب‌شده جایگزین شوند.' ], 'required' => TRUE, 'class' => 'col-12' ];
    }
    if ( $operation === 'exit' ) $fields[] = [ 'type' => 'checkbox', 'id' => $id . '-confirm', 'name' => 'confirm_exit', 'options' => [ 'yes' => 'خروج مشتریان از مسیرهای انتخاب‌شده را تأیید می‌کنم.' ], 'required' => TRUE, 'class' => 'col-12' ];
    if ( $operation === 'course' ) $fields[] = [ 'type'=>'checkbox', 'id'=>$id . '-confirm', 'name'=>'confirm_course', 'options'=>[ 'yes'=>'اعطای دسترسی دوره مرحله فعلی برای مشتریان انتخاب‌شده را تأیید می‌کنم.' ], 'required'=>TRUE, 'class'=>'col-12' ];
    else $fields[] = [ 'type' => 'quill', 'id' => $id . '-note', 'name' => 'note', 'label' => $operation === 'exit' ? 'دلیل خروج (اختیاری)' : 'توضیح تغییرات', 'class' => 'col-12' ];
    KERP_Helpers_Template::render_modal( [ 'id' => $id, 'title' => $title, 'action' => 'leads_membership_bulk', 'page' => $return_route, 'body' => $body, 'fields' => $fields, 'button' => $operation === 'exit' ? 'ثبت خروج مشتریان' : 'اعمال تغییرات' ] );
}
