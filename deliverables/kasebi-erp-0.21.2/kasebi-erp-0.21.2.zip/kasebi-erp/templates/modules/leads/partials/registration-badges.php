<?php
defined( 'ABSPATH' ) || exit;
?>
<?php if ( ! empty( $badges ) ) : ?>
    <div class="kerp-lead-registration-badges">
        <?php foreach ( $badges as $badge ) : ?>
            <span class="badge kerp-lead-registration-badge" title="<?php echo esc_attr( $badge['label'] . ': ' . $badge['value'] ); ?>"><span class="kerp-lead-registration-badge-text"><strong><?php echo esc_html( $badge['label'] ); ?>:</strong> <bdi><?php echo esc_html( $badge['value'] ); ?></bdi></span></span>
        <?php endforeach; ?>
    </div>
<?php else : ?><span class="text-soft" aria-label="اطلاعاتی برای نمایش ثبت نشده است">—</span><?php endif; ?>
