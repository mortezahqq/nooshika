<?php
defined( 'ABSPATH' ) || exit;
?>
<div class="kerp-lead-history" dir="rtl">
    <div class="kerp-history-summary">
        <span class="kerp-history-avatar" aria-hidden="true"><em class="icon ni ni-user"></em></span>
        <div class="kerp-history-identity"><span class="kerp-history-eyebrow">سفر مشتری در مسیر فروش</span><h6><?php echo esc_html( $customer_name ); ?></h6><p><?php echo esc_html( $campaign_name ); ?></p></div>
        <span class="kerp-history-total"><strong><?php echo esc_html( number_format_i18n( $history['total'] ) ); ?></strong><span>اقدام ثبت‌شده</span></span>
    </div>
    <div class="kerp-history-heading"><h6>روند اقدامات</h6><span><em class="icon ni ni-sort-down" aria-hidden="true"></em> جدیدترین ابتدا</span></div>
    <?php if ( ! $history['items'] ) : ?>
        <div class="kerp-history-empty text-center py-5"><em class="icon ni ni-history" aria-hidden="true"></em><h6>هنوز اقدامی ثبت نشده است</h6><p>تغییر مراحل و اقدامات بعدی مشتری در اینجا نمایش داده می‌شوند.</p></div>
    <?php else : ?>
        <ol class="kerp-history-timeline">
            <?php foreach ( $history['items'] as $event ) :
                $actor_id = (int) $event['actor_id'];
                $actor = $actor_id ? get_userdata( $actor_id ) : FALSE;
                $payload = json_decode( (string) $event['payload'], TRUE );
                $note = is_array( $payload ) && isset( $payload['note'] ) && is_string( $payload['note'] ) ? $payload['note'] : '';
                $type = (string) ( $event['event_type'] ?? '' );
                $kind = 'event'; $label = 'اقدام'; $icon = 'ni-history';
                if ( in_array( $type, [ 'campaign_joined', 'pipeline_joined', 'pipeline_branched' ], TRUE ) ) {
                    $kind = 'membership'; $label = 'عضویت در مسیر'; $icon = 'ni-users';
                } elseif ( $type === 'learndash_completed' ) {
                    $kind = 'stage'; $label = 'تکمیل درس لرندش'; $icon = 'ni-book-read';
                } elseif ( ! empty( $event['stage_id'] ) ) {
                    $kind = 'stage'; $label = 'تغییر مرحله'; $icon = 'ni-growth';
                } elseif ( $type === 'owner_assigned' ) {
                    $label = 'تخصیص کارشناس'; $icon = 'ni-user-check';
                } elseif ( $type === 'attendance_changed' ) {
                    $label = 'وضعیت حضور'; $icon = 'ni-calendar-check';
                }
                $date = KERP_Helpers_Date::local_datetime_to_jalali( (string) $event['occurred_at'] );
                ?>
                <li class="kerp-history-event" data-kind="<?php echo esc_attr( $kind ); ?>">
                    <span class="kerp-history-node" aria-hidden="true"><em class="icon ni <?php echo esc_attr( $icon ); ?>"></em></span>
                    <article class="kerp-history-event-card">
                        <div class="kerp-history-event-top"><span class="kerp-history-kind"><?php echo esc_html( $label ); ?></span><span class="kerp-history-date"><em class="icon ni ni-clock" aria-hidden="true"></em><bdi dir="ltr"><?php echo esc_html( $date !== '' ? $date : 'تاریخ نامشخص' ); ?></bdi></span></div>
                        <h6><?php echo esc_html( $event['title'] ); ?></h6>
                        <div class="kerp-history-actor"><em class="icon ni ni-user" aria-hidden="true"></em><span>انجام‌دهنده: <?php echo esc_html( $actor ? get_user_name_by_id( $actor_id ) : ( $actor_id ? 'کاربر حذف‌شده' : 'خودکار' ) ); ?></span></div>
                        <?php
                        $linked_order_id = is_array( $payload ) && is_scalar( $payload['order_id'] ?? NULL ) ? absint( $payload['order_id'] ) : 0;
                        $order_details = $event['order_details'] ?? NULL;
                        if ( $linked_order_id ) : ?>
                            <div class="kerp-history-order">
                                <div class="kerp-history-order-title"><em class="icon ni ni-bag" aria-hidden="true"></em><strong>سفارش <bdi>#<?php echo esc_html( $order_details['number'] ?? $linked_order_id ); ?></bdi></strong><span>اطلاعات UTM سفارش</span></div>
                                <?php if ( ! empty( $order_details['utm'] ) ) : ?>
                                    <dl class="kerp-history-utm">
                                        <?php foreach ( [ 'utm_source' => 'منبع', 'utm_medium' => 'رسانه', 'utm_campaign' => 'کمپین', 'utm_term' => 'عبارت جستجو', 'utm_content' => 'محتوای تبلیغ' ] as $key => $label ) :
                                            if ( ! isset( $order_details['utm'][ $key ] ) ) continue; ?>
                                            <div><dt><?php echo esc_html( $label ); ?></dt><dd dir="auto" title="<?php echo esc_attr( $order_details['utm'][ $key ] ); ?>"><?php echo esc_html( $order_details['utm'][ $key ] ); ?></dd></div>
                                        <?php endforeach; ?>
                                    </dl>
                                <?php else : ?><p class="kerp-history-utm-empty"><?php echo $order_details === NULL ? 'اطلاعات انتساب این سفارش در دسترس نیست.' : 'اطلاعات UTM برای این سفارش ثبت نشده است.'; ?></p><?php endif; ?>
                            </div>
                        <?php endif; ?>
                        <?php if ( $note !== '' ) : ?><div class="kerp-lead-history-note kerp-lead-note-content"><?php echo ( $payload['note_format'] ?? '' ) === 'html' ? wp_kses_post( $note ) : nl2br( esc_html( $note ) ); ?></div><?php endif; ?>
                    </article>
                </li>
            <?php endforeach; ?>
        </ol>
    <?php endif; ?>
    <?php if ( $history['pages'] > 1 ) : ?>
        <nav class="d-flex flex-wrap align-items-center gap-2 border-top pt-3" aria-label="صفحه‌بندی تاریخچه">
            <?php foreach ( [ $history['page'] - 1 => 'جدیدتر', $history['page'] + 1 => 'قدیمی‌تر' ] as $target_page => $label ) :
                if ( $target_page < 1 || $target_page > $history['pages'] ) continue;
                ?>
                <button type="button" class="btn btn-sm btn-outline-primary kerp_load_data_to_modal"
                    data-action="leads_history" data-modal="#kerpLeadsHistory" data-modal-title="تاریخچه اقدامات"
                    data-user_id="<?php echo absint( $user_id ); ?>" data-campaign_id="<?php echo absint( $campaign_id ); ?>"
                    data-history_page="<?php echo absint( $target_page ); ?>" data-leads_nonce="<?php echo esc_attr( wp_create_nonce( 'kerp_leads' ) ); ?>"><?php echo esc_html( $label ); ?></button>
            <?php endforeach; ?>
            <small><?php echo esc_html( sprintf( 'صفحه %d از %d', $history['page'], $history['pages'] ) ); ?></small>
        </nav>
    <?php endif; ?>
</div>
