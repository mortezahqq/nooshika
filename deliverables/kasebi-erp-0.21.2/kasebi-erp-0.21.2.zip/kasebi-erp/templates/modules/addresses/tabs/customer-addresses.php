<?php

defined( 'ABSPATH' ) || exit;

/**
 * @var WP_User $customer
 * @var int     $customer_id
 */

$customer_id             = absint( $customer_id ?? 0 );
$service                 = KERP_Modules_Addresses_Module::instance();
$customer_singular_label = KERP_Modules_Customers_Settings::instance()->get_singular_label();
$addresses               = $service->get_addresses( $customer_id );
$default_id              = $service->get_default_address_id( $customer_id );
$state_options           = $service->get_state_options();
$page_route              = '/erp/customers/' . $customer_id . '/?tab=addresses';
$can_edit                = function_exists( 'kerp_can' ) ? kerp_can( 'customers', 'edit' ) : current_user_can( 'edit_users' );
$first_name              = sanitize_text_field( (string) get_user_meta( $customer_id, 'first_name', TRUE ) );
$last_name               = sanitize_text_field( (string) get_user_meta( $customer_id, 'last_name', TRUE ) );
$phone                   = sanitize_text_field( (string) get_user_meta( $customer_id, 'nooshika_phone_num', TRUE ) );
$empty_populate          = [
	'context'     => [ 'id' => '#kerp-address-context', 'type' => 'text', 'value' => 'customer', ],
	'customer_id' => [ 'id' => '#kerp-address-customer-id', 'type' => 'text', 'value' => $customer_id, ],
	'id'          => [ 'id' => '#kerp-address-id', 'value' => '', 'type' => 'text' ],
	'title'       => [ 'id' => '#kerp-address-title', 'value' => '', 'type' => 'text' ],
	'first_name'  => [ 'id' => '#kerp-address-first-name', 'value' => $first_name, 'type' => 'text' ],
	'last_name'   => [ 'id' => '#kerp-address-last-name', 'value' => $last_name, 'type' => 'text' ],
	'phone'       => [ 'id' => '#kerp-address-phone', 'value' => $phone, 'type' => 'text' ],
	'state'       => [ 'id' => '#kerp-address-state', 'value' => '', 'type' => 'select' ],
	'city'        => [ 'id' => '#kerp-address-city', 'value' => '', 'type' => 'text' ],
	'region'      => [ 'id' => '#kerp-address-region', 'value' => '', 'type' => 'text' ],
	'section'     => [ 'id' => '#kerp-address-section', 'value' => '', 'type' => 'text' ],
	'address_1'   => [ 'id' => '#kerp-address-line', 'value' => '', 'type' => 'text' ],
	'postcode'    => [ 'id' => '#kerp-address-postcode', 'value' => '', 'type' => 'text' ],
	'is_default'  => [ 'id' => '#kerp-address-is-default', 'value' => FALSE, 'type' => 'switch' ],
];
?>
<div class="nk-block kerp-order-address-section">
    <div class="kerp-customer-tab-controls">
        <div class="d-lg-none kerp-customer-mobile-nav">
            <a href="#" class="toggle btn btn-icon btn-trigger" data-target="customerAside"
               aria-label="<?php esc_attr_e( 'نمایش منوی کاربر', 'kasebi-erp' ); ?>"><em class="icon ni ni-menu-alt-r"></em></a>
        </div>
		<?php if ( $can_edit ) : ?>
            <a href="#customerAddressModal"
                           class="btn btn-dim btn-primary btn-icon edit_row_item"
                   data-bs-toggle="modal"
                   data-bs-target="#customerAddressModal"
                   data-modal="#customerAddressModal"
                           data-populate="<?php echo esc_attr( wp_json_encode( $empty_populate ) ); ?>"
                           title="<?php esc_attr_e( 'افزودن آدرس', 'kasebi-erp' ); ?>"
                           aria-label="<?php esc_attr_e( 'افزودن آدرس', 'kasebi-erp' ); ?>">
                    <em class="icon ni ni-plus"></em>
                </a>
		<?php endif; ?>
    </div>
	<?php KERP_Helpers_Template::render_template( 'app/components/customer-tab-hero.php', [
		'icon'        => 'ni ni-map-pin',
		'eyebrow'     => __( 'اطلاعات تحویل', 'kasebi-erp' ),
		'title'       => sprintf( __( 'آدرس‌های %s', 'kasebi-erp' ), $customer_singular_label ),
		'description' => __( 'آدرس‌های قابل استفاده برای تحویل سفارش را مدیریت کنید.', 'kasebi-erp' ),
	] ); ?>
	
	<?php if ( empty( $addresses ) ) : ?>
        <div class="alert alert-light">
            <div class="alert-cta flex-wrap flex-md-nowrap">
                <div class="alert-text">
                    <p><?php printf( esc_html__( 'هنوز آدرسی برای این %s ثبت نشده است.', 'kasebi-erp' ), esc_html( $customer_singular_label ) ); ?></p>
                </div>
            </div>
        </div>
	<?php else : ?>
        <div class="row">
			<?php foreach ( $addresses as $address_id => $address ) : ?>
				<?php
				$is_default = (string) $address_id === (string) $default_id;
				$full_name  = trim( (string) ( $address['first_name'] ?? '' ) . ' ' . (string) ( $address['last_name'] ?? '' ) );
				$populate   = [
					'id'          => [ 'id' => '#kerp-address-id', 'value' => $address_id, 'type' => 'text' ],
					'customer_id' => [
						'id'    => '#kerp-address-customer-id',
						'type'  => 'text',
						'value' => $customer_id,
					],
					'title'       => [
						'id'    => '#kerp-address-title',
						'value' => (string) ( $address['title'] ?? '' ),
						'type'  => 'text',
					],
					'first_name'  => [
						'id'    => '#kerp-address-first-name',
						'value' => (string) ( $address['first_name'] ?? '' ),
						'type'  => 'text',
					],
					'last_name'   => [
						'id'    => '#kerp-address-last-name',
						'value' => (string) ( $address['last_name'] ?? '' ),
						'type'  => 'text',
					],
					'phone'       => [
						'id'    => '#kerp-address-phone',
						'value' => (string) ( $address['phone'] ?? '' ),
						'type'  => 'text',
					],
					'state'       => [
						'id'    => '#kerp-address-state',
						'value' => (string) ( $address['state'] ?? '' ),
						'type'  => 'select',
					],
					'city'        => [
						'id'    => '#kerp-address-city',
						'value' => $service->get_city_label( (string) ( $address['state'] ?? '' ), (string) ( $address['city'] ?? '' ) ),
						'type'  => 'text',
					],
					'region'      => [
						'id'    => '#kerp-address-region',
						'value' => (string) ( $address['region'] ?? '' ),
						'type'  => 'text',
					],
					'section'     => [
						'id'    => '#kerp-address-section',
						'value' => (string) ( $address['section'] ?? '' ),
						'type'  => 'text',
					],
					'address_1'   => [
						'id'    => '#kerp-address-line',
						'value' => (string) ( $address['address_1'] ?? '' ),
						'type'  => 'text',
					],
					'postcode'    => [
						'id'    => '#kerp-address-postcode',
						'value' => (string) ( $address['postcode'] ?? '' ),
						'type'  => 'text',
					],
					'is_default'  => [
						'id'    => '#kerp-address-is-default',
						'value' => $is_default,
						'type'  => 'switch',
					],
				];
				?>
                <div class="col-md-6 mb-4">
                    <div class="card card-bordered h-100">
                        <div class="card-inner">
                            <div class="d-flex align-center justify-between mb-3">
                                <div>
                                    <h6 class="title mb-1">
										<?php echo esc_html( (string) ( $address['title'] ?? '' ) !== '' ? (string) $address['title'] : sprintf( __( 'آدرس %s', 'kasebi-erp' ), $customer_singular_label ) ); ?>
                                    </h6>
									<?php if ( $is_default ) : ?>
                                        <span
                                            class="badge badge-dim bg-success"><?php esc_html_e( 'پیش‌فرض', 'kasebi-erp' ); ?></span>
									<?php endif; ?>
                                </div>
								<?php if ( $can_edit ) : ?>
                                    <div class="dropdown">
                                        <a href="#" class="btn btn-sm btn-icon btn-trigger dropdown-toggle"
                                           data-bs-toggle="dropdown">
                                            <em class="icon ni ni-more-h"></em>
                                        </a>
                                        <div class="dropdown-menu dropdown-menu-end">
                                            <ul class="link-list-opt no-bdr">
                                                <li>
                                                    <a href="#customerAddressModal"
                                                       class="edit_row_item"
                                                       data-bs-toggle="modal"
                                                       data-bs-target="#customerAddressModal"
                                                       data-modal="#customerAddressModal"
                                                       data-populate="<?php echo esc_attr( wp_json_encode( $populate ) ); ?>">
                                                        <em class="icon ni ni-edit"></em>
                                                        <span><?php esc_html_e( 'ویرایش', 'kasebi-erp' ); ?></span>
                                                    </a>
                                                </li>
												<?php if ( ! $is_default ) : ?>
                                                    <li>
                                                        <a href="#"
                                                           class="kerp-address-set-default"
                                                           data-action="addresses_set_default"
                                                           data-page="<?php echo esc_attr( $page_route ); ?>"
                                                           data-customer_id="<?php echo esc_attr( $customer_id ); ?>"
                                                           data-address_id="<?php echo esc_attr( $address_id ); ?>">
                                                            <em class="icon ni ni-check-circle"></em>
                                                            <span><?php esc_html_e( 'انتخاب به‌عنوان پیش‌فرض', 'kasebi-erp' ); ?></span>
                                                        </a>
                                                    </li>
												<?php endif; ?>
                                                <li class="divider"></li>
                                                <li>
                                                    <a href="#"
                                                       class="delete_db_item"
                                                       data-action="addresses_delete"
                                                       data-page="<?php echo esc_attr( $page_route ); ?>"
                                                       data-customer_id="<?php echo esc_attr( $customer_id ); ?>"
                                                       data-address_id="<?php echo esc_attr( $address_id ); ?>">
                                                        <em class="icon ni ni-trash"></em>
                                                        <span><?php esc_html_e( 'حذف آدرس', 'kasebi-erp' ); ?></span>
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
								<?php endif; ?>
                            </div>
							
							<?php if ( $full_name !== '' || ! empty( $address['phone'] ) ) : ?>
                                <div class="user-card mb-3">
                                    <div class="user-info">
										<?php if ( $full_name !== '' ) : ?>
                                            <span class="lead-text"><?php echo esc_html( $full_name ); ?></span>
										<?php endif; ?>
										<?php if ( ! empty( $address['phone'] ) ) : ?>
                                            <span
                                                class="sub-text"><?php echo esc_html( (string) $address['phone'] ); ?></span>
										<?php endif; ?>
                                    </div>
                                </div>
							<?php endif; ?>

                            <p class="mb-2"><?php echo esc_html( $service->get_address_display( $address ) ); ?></p>
							<?php if ( ! empty( $address['postcode'] ) ) : ?>
                                <span class="sub-text">
                                        <?php esc_html_e( 'کدپستی:', 'kasebi-erp' ); ?>
                                        <?php echo esc_html( (string) $address['postcode'] ); ?>
                                    </span>
							<?php endif; ?>
                        </div>
                    </div>
                </div>
			<?php endforeach; ?>
        </div>
	<?php endif; ?>
</div>
