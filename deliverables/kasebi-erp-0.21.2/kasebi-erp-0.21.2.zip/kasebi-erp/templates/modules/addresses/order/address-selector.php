<?php

defined( 'ABSPATH' ) || exit;

/**
 * @var WC_Order|null $order
 * @var int           $customer_id
 * @var string        $mode
 * @var string|null   $selected_address_id
 */

$order       = isset( $order ) && $order instanceof WC_Order ? $order : NULL;
$customer_id = absint( $customer_id ?? 0 );
$mode        = sanitize_key( (string) ( $mode ?? 'create' ) );
$can_manage_addresses = kerp_can( 'customers', 'edit' )
	&& ( kerp_list_scope( 'customers' ) === 'all'
		|| ( kerp_list_scope( 'customers' ) === 'own' && (int) get_user_meta( $customer_id, 'owner_id', TRUE ) === get_current_user_id() ) );
$service     = KERP_Modules_Addresses_Module::instance();
$customer_singular_label = KERP_Modules_Customers_Settings::instance()->get_singular_label();
$addresses   = $customer_id > 0
	? $service->get_addresses( $customer_id )
	: [];

$selected_id = sanitize_key(
	(string) ( $selected_address_id ?? '' )
);

if (
	$selected_id === ''
	&& $order instanceof WC_Order
) {
	$selected_id = sanitize_key(
		(string) $order->get_meta(
			'address_id',
			TRUE
		)
	);
}

if (
	$selected_id === ''
	|| ! isset( $addresses[ $selected_id ] )
) {
	$selected_id = $customer_id > 0
		? $service->get_default_address_id( $customer_id )
		: '';
}

$order_id = $order instanceof WC_Order
	? $order->get_id()
	: 0;
?>

<div class="nk-block kerp-order-address-section">
    <div class="card card-bordered kerp-order-form-section">
        <div class="card-inner">
            <input type="hidden"
                   class="no_clear kerp-order-address-id"
                   data-for="address_id"
                   value="<?php echo esc_attr( $selected_id ); ?>">

            <div class="kerp-order-section-head kerp-order-address-head">
                <div class="kerp-order-address-heading">
                    <div class="kerp-order-section-icon"><em class="icon ni ni-map-pin" aria-hidden="true"></em></div>
                    <div class="kerp-order-address-heading-text">
                    <span class="kerp-order-section-kicker"><?php esc_html_e( 'تحویل', 'kasebi-erp' ); ?></span>
                    <h5 class="kerp-order-section-title">
						<?php esc_html_e( 'آدرس تحویل سفارش', 'kasebi-erp' ); ?>
                    </h5>

                    <p class="text-soft mb-0 mt-1">
						<?php printf( esc_html__( 'آدرس ذخیره‌شده %s را برای این سفارش انتخاب کنید.', 'kasebi-erp' ), esc_html( $customer_singular_label ) ); ?>
                    </p>
                    </div>
                </div>
				
				<?php if ( $customer_id > 0 && $can_manage_addresses ) :
					$add_populate = [
						'context'             => [
							'id'    => '#kerp-address-context',
							'type'  => 'text',
							'value' => 'order',
						],
						'customer_id'         => [
							'id'    => '#kerp-address-customer-id',
							'type'  => 'text',
							'value' => $customer_id,
						],
						'order_id'            => [
							'id'    => '#kerp-address-order-id',
							'type'  => 'text',
							'value' => $order_id,
						],
						'selected_address_id' => [
							'id'    => '#kerp-address-selected-id',
							'type'  => 'text',
							'value' => $selected_id,
						],
						'address_id'          => [
							'id'    => '#kerp-address-id',
							'type'  => 'text',
							'value' => '',
						],
					];
					?>

                    <div class="card-tools">
                        <a href="#"
                           class="btn btn-sm btn-light edit_row_item"
                           data-modal="#customerAddressModal"
                           data-populate="<?php echo esc_attr( wp_json_encode( $add_populate ) ); ?>">
                            <em class="ni ni-plus icon"></em>
                            <span><?php esc_html_e( 'افزودن آدرس', 'kasebi-erp' ); ?></span>
                        </a>
                    </div>
				<?php endif; ?>
            </div>
			
			<?php if ( $customer_id <= 0 ) : ?>
                <div class="alert alert-light mb-0">
                    <p>
						<?php printf( esc_html__( 'ابتدا %s سفارش را انتخاب کنید.', 'kasebi-erp' ), esc_html( $customer_singular_label ) ); ?>
                    </p>
                </div>
			<?php elseif ( empty( $addresses ) ) : ?>
                <div class="alert alert-warning mb-0">
                    <p>
						<?php printf( esc_html__( 'برای این %s آدرسی ثبت نشده است.', 'kasebi-erp' ), esc_html( $customer_singular_label ) ); ?>
                    </p>
                </div>
			<?php else : ?>
                <div class="row">
					<?php foreach ( $addresses as $address_id => $address ) : ?>
						<?php
						$address_id  = sanitize_key( (string) $address_id );
						$is_selected = $address_id === $selected_id;
						$is_default  = ! empty( $address['is_default'] );
						
						$first_name = trim(
							(string) ( $address['first_name'] ?? '' )
						);
						
						$last_name = trim(
							(string) ( $address['last_name'] ?? '' )
						);
						
						$full_name = trim(
							$first_name . ' ' . $last_name
						);
						
						$title = trim(
							(string) ( $address['title'] ?? '' )
						);
						
						if ( $title === '' ) {
							$title = __( 'آدرس تحویل', 'kasebi-erp' );
						}
						
						$phone = trim(
							(string) ( $address['phone'] ?? '' )
						);
						
						$postcode = trim(
							(string) ( $address['postcode'] ?? '' )
						);
						
						$recipient_is_customer = ! isset( $address['recipient_is_customer'] )
						                         || ! empty( $address['recipient_is_customer'] );
						
						$populate = [
							'context'               => [
								'id'    => '#kerp-address-context',
								'type'  => 'text',
								'value' => 'order',
							],
							'customer_id'           => [
								'id'    => '#kerp-address-customer-id',
								'type'  => 'text',
								'value' => $customer_id,
							],
							'order_id'              => [
								'id'    => '#kerp-address-order-id',
								'type'  => 'text',
								'value' => $order_id,
							],
							'selected_address_id'   => [
								'id'    => '#kerp-address-selected-id',
								'type'  => 'text',
								'value' => $selected_id,
							],
							'address_id'            => [
								'id'    => '#kerp-address-id',
								'type'  => 'text',
								'value' => $address_id,
							],
							'title'                 => [
								'id'    => '#kerp-address-title',
								'type'  => 'text',
								'value' => (string) ( $address['title'] ?? '' ),
							],
							'recipient_is_customer' => [
								'id'    => '#address_for_main_customer',
								'type'  => 'checkbox',
								'value' => $recipient_is_customer ? '1' : '0',
							],
							'first_name'            => [
								'id'    => '#kerp-address-first-name',
								'type'  => 'text',
								'value' => $first_name,
							],
							'last_name'             => [
								'id'    => '#kerp-address-last-name',
								'type'  => 'text',
								'value' => $last_name,
							],
							'phone'                 => [
								'id'    => '#kerp-address-phone',
								'type'  => 'text',
								'value' => $phone,
							],
							'state'                 => [
								'id'    => '#kerp-address-state',
								'type'  => 'select',
								'value' => (string) ( $address['state'] ?? '' ),
								'data'  => [
									'city' => ( $address['city'] ?? '' ),
								],
							],
							'city'                  => [
								'id'    => '#kerp-address-city',
								'type'  => 'select',
								'value' => (string) ( $address['city'] ?? '' ),
							],
							'region'                => [
								'id'    => '#kerp-address-region',
								'type'  => 'text',
								'value' => (string) ( $address['region'] ?? '' ),
							],
							'section'               => [
								'id'    => '#kerp-address-section',
								'type'  => 'text',
								'value' => (string) ( $address['section'] ?? '' ),
							],
							'address_1'             => [
								'id'    => '#kerp-address-line',
								'type'  => 'text',
								'value' => (string) ( $address['address_1'] ?? '' ),
							],
							'postcode'              => [
								'id'    => '#kerp-address-postcode',
								'type'  => 'text',
								'value' => $postcode,
							],
						];
						?>

                        <div class="col-md-6 mb-3">
                            <div
                                class="card card-bordered h-100 kerp-order-address-option<?php echo $is_selected ? ' border-primary' : ''; ?>">
                                <div class="card-inner">
                                    <div class="d-flex justify-content-between align-items-start mb-3">
                                        <div class="custom-control custom-radio">
                                            <input type="radio"
                                                   class="custom-control-input kerp-order-address-choice"
                                                   name="kerp_order_address_select"
                                                   id="kerp-order-address-<?php echo esc_attr( $address_id ); ?>"
                                                   value="<?php echo esc_attr( $address_id ); ?>"
												<?php checked( $is_selected ); ?>>

                                            <label class="custom-control-label"
                                                   for="kerp-order-address-<?php echo esc_attr( $address_id ); ?>">
												<?php echo esc_html( $title ); ?>
                                            </label>
                                        </div>

                                        <?php if ( $can_manage_addresses ) : ?>
                                        <div class="dropdown">
                                            <a href="#"
                                               class="btn btn-sm btn-icon btn-trigger dropdown-toggle"
                                               data-bs-toggle="dropdown"
                                               aria-expanded="false">
                                                <em class="ni ni-more-h icon"></em>
                                            </a>

                                            <div class="dropdown-menu dropdown-menu-end">
                                                <ul class="link-list-opt no-bdr">
                                                    <li>
                                                        <a href="#"
                                                           class="edit_row_item kerp-edit-customer-address"
                                                           data-modal="#customerAddressModal"
                                                           data-address-id="<?php echo esc_attr( $address_id ); ?>"
                                                           data-state="<?php echo esc_attr( (string) ( $address['state'] ?? '' ) ); ?>"
                                                           data-city="<?php echo esc_attr( (string) ( $address['city'] ?? '' ) ); ?>"
                                                           data-populate="<?php echo esc_attr( wp_json_encode( $populate ) ); ?>">
                                                            <em class="ni ni-edit icon"></em>
                                                            <span>
																<?php esc_html_e( 'ویرایش آدرس', 'kasebi-erp' ); ?>
															</span>
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                    </div>
									
									<?php if ( $is_default ) : ?>
                                        <div class="mb-2">
											<span class="badge bg-primary">
												<?php esc_html_e( 'آدرس پیش‌فرض', 'kasebi-erp' ); ?>
											</span>
                                        </div>
									<?php endif; ?>
									
									<?php if ( $full_name !== '' ) : ?>
                                        <strong class="d-block mb-1">
											<?php echo esc_html( $full_name ); ?>
                                        </strong>
									<?php endif; ?>
									
									<?php if ( $phone !== '' ) : ?>
                                        <span class="sub-text d-block mb-2">
											<?php echo esc_html( $phone ); ?>
										</span>
									<?php endif; ?>

                                    <span class="sub-text d-block">
										<?php echo esc_html( $service->get_address_display( $address ) ); ?>
									</span>
									
									<?php if ( $postcode !== '' ) : ?>
                                        <span class="sub-text d-block mt-1">
											<?php esc_html_e( 'کدپستی:', 'kasebi-erp' ); ?>
											
											<?php echo esc_html( $postcode ); ?>
										</span>
									<?php endif; ?>
                                </div>
                            </div>
                        </div>
					<?php endforeach; ?>
                </div>
			<?php endif; ?>
        </div>
    </div>


</div>
