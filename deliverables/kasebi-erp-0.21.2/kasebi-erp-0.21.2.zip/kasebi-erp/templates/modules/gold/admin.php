<?php
defined( 'ABSPATH' ) || exit;
KERP_Modules_Gold_Ui::render( isset( $page_context ) && is_array( $page_context ) ? $page_context : [] );
