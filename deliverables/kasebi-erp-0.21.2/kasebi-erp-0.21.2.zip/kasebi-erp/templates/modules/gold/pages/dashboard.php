<?php
defined( 'ABSPATH' ) || exit;
$u = KERP_Modules_Gold_Ui::class; $stats = KERP_Modules_Gold_Ui_Data::summary(); $quote = KERP_Modules_Gold_Module::quote(); $settings = KERP_Modules_Gold_Module::settings();
?>
<details class="card card-bordered kg-help mb-4" open><summary>تازه شروع کرده‌اید؟ از این سه قدم جلو بروید</summary><div class="card-inner"><div class="row g-3">
<?php foreach ( [ [ 'settings', '۱. نرخ و روش فروش را تنظیم کنید', 'نرخ معتبر طلا و سیاست برداشت کیف را بررسی کنید.' ], [ 'books', '۲. حساب‌ها را اضافه کنید', 'بانک، صندوق و تأمین‌کننده را تعریف کنید. برای انتقال، حداقل دو حساب لازم است.' ], [ 'inventory', '۳. کالاها را آماده کنید', 'محصول، وزن و موجودی را بررسی کنید؛ سپس از دکمه «ثبت فروش» استفاده کنید.' ] ] as [ $target, $title, $help ] ) : ?>
<div class="col-md-4"><h6><?php echo esc_html( $title ); ?></h6><p class="sub-text"><?php echo esc_html( $help ); ?></p><?php $u::link( $target, 'رفتن به این بخش', 'btn btn-sm btn-white btn-outline-light', 'arrow-left' ); ?></div>
<?php endforeach; ?></div></div></details>
<div class="nk-block">
<?php KERP_Helpers_Template::render_template( 'app/components/settings/hero.php', [
    'icon' => 'ni ni-coins icon', 'eyebrow' => 'خلاصه امروز · ' . str_replace( '-', '/', KERP_Helpers_Date::gregorian_to_jalali( wp_date( 'Y-m-d' ) ) ),
    'title' => 'تصویر روشن‌تری از بنکداری شما', 'description' => 'از درخواست مشتری تا خرید جایگزین و ارسال؛ کارهای امروز را از همین‌جا پیش ببرید.',
    'class' => 'kg-hero', 'actions' => [ [ 'label' => 'درخواست‌های نیازمند بررسی', 'icon' => 'icon ni ni-inbox', 'href' => $u::url( 'requests', [ 'status' => 'pending' ] ), 'class' => 'btn btn-sm btn-primary page_activator', 'attributes' => [ 'data-url' => wp_make_link_relative( $u::url( 'requests', [ 'status' => 'pending' ] ) ) ] ] ],
    'stats' => [ [ 'label' => 'نرخ معتبر هر گرم', 'value' => $quote ? wc_price( $quote['rate'] ) : 'نیازمند به‌روزرسانی', 'html' => (bool) $quote ], [ 'label' => 'مبنای موجودی‌ها', 'value' => 'طلای عیار ۷۵۰' ] ],
] ); ?>
</div>
<div class="nk-block"><div class="row g-gs">
<?php foreach ( [ [ 'label' => 'موجودی آزاد کاربران', 'value' => $u::weight( $stats['free'] ), 'unit' => 'گرم', 'icon' => 'wallet', 'tone' => 'primary', 'note' => 'بدون وزن رزروشدهٔ برداشت‌ها' ], [ 'label' => 'خرید جایگزین در انتظار', 'value' => $u::weight( $stats['replacement'] ), 'unit' => 'گرم', 'icon' => 'repeat', 'tone' => 'warning', 'note' => number_format_i18n( $stats['replacement_count'] ) . ' سفارش در صف خرید' ], [ 'label' => 'سفارش‌های آماده پیگیری', 'value' => number_format_i18n( $stats['packaging'] ), 'unit' => 'سفارش', 'icon' => 'package', 'tone' => 'info', 'note' => 'در صف آماده‌سازی و بسته‌بندی' ], [ 'label' => 'فروش خالص سفارش‌های امروز', 'value' => $u::money( $stats['sales_total'] ), 'unit' => '', 'html' => true, 'icon' => 'growth', 'tone' => 'success', 'note' => number_format_i18n( $stats['sales_count'] ) . ' سفارش پرداخت‌شده در واحد پول فروشگاه' ] ] as $item ) : ?>
<div class="col-sm-6 col-xl-3"><div class="card card-bordered h-100 kg-metric <?php echo ! empty( $item['html'] ) ? 'kg-metric-money' : ''; ?>"><div class="card-inner"><div class="kg-metric-head"><span class="sub-text"><?php echo esc_html( $item['label'] ); ?></span><span class="user-avatar sm bg-<?php echo esc_attr( $item['tone'] ); ?>-dim text-<?php echo esc_attr( $item['tone'] ); ?>"><?php echo $u::icon( $item['icon'] ); ?></span></div><div class="kg-metric-value"><bdi><?php echo ! empty( $item['html'] ) ? wp_kses_post( $item['value'] ) : esc_html( $item['value'] ); ?></bdi><small><?php echo esc_html( $item['unit'] ); ?></small></div><span class="sub-text"><?php echo esc_html( $item['note'] ); ?></span></div></div></div>
<?php endforeach; ?>
</div></div>
<div class="nk-block"><div class="row g-gs"><div class="col-lg-8">
<?php $u::card( 'کارهایی که منتظر شما هستند', 'صف‌های عملیاتی بنکداری' ); ?>
<div class="kg-worklist">
<?php foreach ( [ [ 'requests', 'درخواست‌های کاربران', 'خرید، تسویه و تحویل طلا', 'inbox', $stats['requests'] ], [ 'replacement', 'خرید طلای جایگزین', 'بررسی وزن و ثبت نتیجه خرید', 'repeat', $stats['replacement_count'] ], [ 'packaging', 'بسته‌بندی و ارسال', 'پیگیری سفارش‌های پرداخت‌شده', 'package', $stats['packaging'] ] ] as [ $target, $label, $note, $icon, $count ] ) : ?>
<a href="<?php echo esc_url( $u::url( $target ) ); ?>" data-url="<?php echo esc_attr( wp_make_link_relative( $u::url( $target ) ) ); ?>" class="kg-work-item page_activator"><span class="user-avatar bg-light text-primary"><?php echo $u::icon( $icon ); ?></span><span class="kg-work-copy"><strong><?php echo esc_html( $label ); ?></strong><span class="sub-text"><?php echo esc_html( $note ); ?></span></span><span class="badge badge-dim <?php echo $count ? 'bg-warning' : 'bg-light'; ?>"><?php echo esc_html( number_format_i18n( $count ) ); ?> مورد</span><?php echo $u::icon( 'chevron-left' ); ?></a>
<?php endforeach; ?>
</div><?php $u::end_card(); ?>
</div><div class="col-lg-4">
<?php $u::card( 'وضعیت راه‌اندازی', 'تنظیمات و اتصال‌های فعال' ); ?>
<ul class="kg-setup-list">
<?php foreach ( [ [ 'نرخ معتبر طلا', (bool) $quote, $quote ? 'به‌روز' : 'نیازمند بررسی' ], [ 'محصول اشتراک پلاس', (bool) $settings['plus_product'], $settings['plus_product'] ? 'تنظیم شده' : 'تنظیم نشده' ], [ 'اعلان پیام‌رسان', KERP_Modules_Gold_Notifications::configured(), KERP_Modules_Gold_Notifications::configured() ? 'تنظیم شده' : 'ثبت داخلی' ] ] as [ $label, $on, $text ] ) : ?>
<li><span><?php echo esc_html( $label ); ?></span><?php echo $u::badge( $on ? 'completed' : 'local', $text ); ?></li>
<?php endforeach; ?>
</ul><div class="mt-3"><?php $u::link( 'settings', 'مدیریت تنظیمات', 'btn btn-sm btn-white btn-outline-light w-100', 'setting' ); ?></div><?php $u::end_card(); ?>
</div></div></div>
<div class="nk-block"><div class="row g-gs"><div class="col-lg-7">
<?php $u::card( 'فروش در هفت روز اخیر', 'تعداد سفارش‌های پرداخت‌شده؛ بدون ترکیب واحدهای پول' ); $week = KERP_Modules_Gold_Ui_Data::week(); $max = max( 1, ...array_column( $week, 'count' ) ); ?>
<div class="kg-chart" role="img" aria-label="تعداد سفارش‌های پرداخت‌شده در هفت روز اخیر">
<?php foreach ( $week as $day ) : ?><div class="kg-chart-column"><strong><?php echo esc_html( number_format_i18n( $day['count'] ) ); ?></strong><div class="kg-chart-track"><span style="height:<?php echo esc_attr( (string) ( $day['count'] / $max * 100 ) ); ?>%"></span></div><small><bdi><?php echo esc_html( $day['day'] ); ?></bdi></small></div><?php endforeach; ?>
</div><?php $u::end_card(); ?>
</div><div class="col-lg-5">
<?php $u::card( 'دسترسی سریع', 'کارهای روزمره با چند کلیک' ); ?>
<div class="kg-shortcuts"><?php $u::link( 'books', 'طرف‌حساب‌ها', 'btn btn-white btn-outline-light', 'users' ); $u::link( 'transfers', 'حواله و تبادل', 'btn btn-white btn-outline-light', 'swap' ); $u::link( 'inventory', 'کالا و انبار', 'btn btn-white btn-outline-light', 'layers' ); $u::link( 'ledger', 'گردش کیف طلایی', 'btn btn-white btn-outline-light', 'wallet' ); ?></div>
<details class="kg-help mt-3"><summary>مبنای این اعداد چیست؟</summary><p>موجودی کیف کاربران، وزن قطعات و دفتر حساب‌های بنکداری مستقل‌اند. فروش امروز پس از کسر بازپرداخت فعلی همان سفارش‌ها نمایش داده می‌شود. جمع این دفترها لزوماً دارایی خالص شما نیست.</p></details><?php $u::end_card(); ?>
</div></div></div>
