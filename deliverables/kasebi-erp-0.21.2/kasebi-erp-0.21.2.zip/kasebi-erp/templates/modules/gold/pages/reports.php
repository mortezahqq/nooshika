<?php
defined( 'ABSPATH' ) || exit;
$u = KERP_Modules_Gold_Ui::class;
try { $data = KERP_Modules_Gold_Ui_Data::report(); } catch ( Throwable $e ) { $u::note( $e->getMessage(), 'danger' ); $data = [ 'start' => $u::get( 'gold_start' ), 'end' => $u::get( 'gold_end' ), 'balances' => [], 'assets' => [], 'sales' => [] ]; }
$today = new DateTimeImmutable( wp_date( 'Y-m-d' ), wp_timezone() );
?>
<div class="nk-block"><?php $u::card( 'بازه گزارش', 'بر اساس منطقه زمانی سایت · حداکثر ۳۶۶ روز' ); ?>
<div class="kg-periods mb-3"><?php foreach ( [ 0 => 'امروز', 6 => 'هفت روز اخیر', 29 => 'سی روز اخیر' ] as $days => $label ) { $u::link( 'reports', $label, 'btn btn-sm btn-white btn-outline-light', '', [ 'gold_start' => KERP_Helpers_Date::gregorian_to_jalali( $today->modify( '-' . $days . ' days' )->format( 'Y-m-d' ) ), 'gold_end' => KERP_Helpers_Date::gregorian_to_jalali( $today->format( 'Y-m-d' ) ) ] ); } ?></div>
<form method="get" action="<?php echo esc_url( $u::url( 'reports' ) ); ?>"><div class="row g-3 align-items-end">
<?php foreach ( [ 'gold_start' => [ 'از تاریخ', $data['start'] ], 'gold_end' => [ 'تا تاریخ', $data['end'] ] ] as $name => [ $label, $value ] ) { KERP_Helpers_Template::render_template( 'app/components/fields/date.php', [ 'field' => [ 'id' => 'kg-' . $name, 'name' => $name, 'label' => $label, 'value' => $value, 'class' => 'col-md-4', 'required' => true ] ] ); } ?>
<div class="col-md-4"><button type="submit" class="btn btn-primary"><?php echo $u::icon( 'filter-alt' ); ?><span>نمایش گزارش</span></button></div></div></form><?php $u::end_card(); ?></div>
<div class="nk-block"><?php $u::card( 'تراز حساب‌های بنکداری', 'ابتدای بازه، گردش و مانده نهایی هر دارایی' );
$money_cell = static function ( $asset, $amount ) use ( $u ) { return $u::html( '<bdi>' . esc_html( KERP_Modules_Gold_Business::amount_label( $asset, (int) $amount ) ) . '</bdi>' ); };
$rows = []; foreach ( $data['balances'] as $row ) { $rows[] = [ $row->label, $money_cell( $row->asset, $row->opening ), $money_cell( $row->asset, $row->incoming ), $money_cell( $row->asset, $row->outgoing ), $money_cell( $row->asset, $row->closing ) ]; }
$u::table( [ 'حساب', 'ابتدای بازه', 'ورودی', 'خروجی', 'مانده پایان بازه' ], $rows, 'گردشی در این بازه ثبت نشده است.', 'با ثبت حواله‌ها، تراز هر حساب در این بخش نمایش داده می‌شود.' ); ?>
<details class="kg-help mt-3"><summary>مبنای محاسبه تراز</summary><p>فقط اسناد ثبت‌شدهٔ حواله و تبادل در این تراز هستند. سفارش ووکامرس و درخواست کیف، سند بانکی خودکار ایجاد نمی‌کنند. موجودی کیف کاربران و قطعات را با این دفتر جمع نکنید؛ ممکن است یک دارایی دو بار شمرده شود.</p></details><?php $u::end_card(); ?></div>
<div class="nk-block"><div class="row g-gs"><div class="col-lg-4"><?php $u::card( 'دارایی ثبت‌شده', 'مانده فعلی؛ مستقل از بازه انتخابی' ); ?>
<div class="kg-asset-list"><?php if ( ! $data['assets'] ) { echo '<p class="text-soft mb-0">هنوز مانده‌ای در حساب‌های دارایی ثبت نشده است.</p>'; } foreach ( $data['assets'] as $asset ) : ?>
<div><span class="user-avatar sm bg-primary-dim"><?php echo $u::icon( $asset->asset === 'gold' ? 'coins' : 'wallet' ); ?></span><div><span class="sub-text"><?php echo $asset->asset === 'gold' ? 'طلای حساب‌های دارایی' : 'وجه بانک، درگاه و صندوق'; ?></span><strong><bdi><?php echo esc_html( KERP_Modules_Gold_Business::amount_label( $asset->asset, (int) $asset->amount ) ); ?></bdi></strong></div></div>
<?php endforeach; ?></div><?php $u::end_card(); ?></div><div class="col-lg-8"><?php $u::card( 'فروش به تفکیک کاربران', 'عضویت پلاس در زمان خرید و منبع سفارش' );
$rows = []; foreach ( $data['sales'] as $row ) { $asset = $row->currency . ':' . $row->decimals; $rows[] = [ KERP_Modules_Gold_Business::source_labels()[ $row->source ] ?? $row->source, $u::html( $row->was_plus ? '<span class="badge badge-dim bg-primary">پلاس</span>' : '<span class="badge badge-dim bg-light">عادی</span>' ), number_format_i18n( $row->orders ), $money_cell( $asset, $row->total ), $money_cell( $asset, $row->refunded ), $money_cell( $asset, (int) $row->total - (int) $row->refunded ) ]; }
$u::table( [ 'منبع فروش', 'نوع کاربر', 'سفارش', 'ارزش سفارش', 'بازپرداخت', 'خالص سفارش' ], $rows, 'فروش ثبت‌شده‌ای در این بازه نیست.' ); ?>
<details class="kg-help mt-3"><summary>نحوه محاسبه فروش</summary><p>مبنای بازه، تاریخ پرداخت است. بازپرداخت، مقدار فعلی بازپرداخت همان سفارش‌هاست و گردش بانکی روز بازپرداخت نیست. ارز، دقت پول و وضعیت‌های مختلف جدا محاسبه می‌شوند. سفارش‌های قدیمی تا ثبت گزارش آن‌ها با ابزار بررسی دوباره، در این گزارش نیستند.</p></details><?php $u::end_card(); ?></div></div></div>
