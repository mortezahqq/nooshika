<?php

defined( 'ABSPATH' ) || exit;

if ( ! isset( $customer ) || ! $customer instanceof WP_User || ! class_exists( 'GFAPI' ) ) {
	return;
}

$customer_id = absint( $customer_id ?? $customer->ID );
$page_query  = isset( $page_context['query'] ) && is_array( $page_context['query'] ) ? $page_context['query'] : [];
$form_id     = absint( $page_query['form_id'] ?? 0 );
$page_number = max( 1, absint( $page_query['page_number'] ?? 1 ) );
$per_page    = absint( $page_query['per_page'] ?? 20 );
$query       = KERP_Modules_Gravity_Forms_Entries_Query::instance();
$result      = $query->find_for_user( $customer_id, compact( 'form_id', 'page_number', 'per_page' ) );
$entries     = (array) ( $result['items'] ?? [] );
$forms       = (array) ( $result['forms'] ?? [] );
$total       = absint( $result['total'] ?? 0 );
$total_pages = max( 1, absint( $result['total_pages'] ?? 1 ) );
$per_page    = absint( $result['per_page'] ?? 20 );
$base_page   = add_query_arg( 'tab', 'gravity-forms-entries', '/erp/customers/' . $customer_id . '/' );
$return_page = add_query_arg( array_filter( [ 'form_id' => $form_id ] ), $base_page );
$form_cache  = [];
$modals      = [];
$form_options = [];

foreach ( $forms as $available_form ) {
	$form_options[ absint( $available_form['id'] ) ] = (string) $available_form['title'];
}

$format_datetime = static function( string $value ): string {
	if ( $value === '' ) { return '—'; }
	$timestamp = strtotime( get_date_from_gmt( $value, 'Y-m-d H:i:s' ) );
	return $timestamp ? date_i18n( 'j F Y، H:i', $timestamp ) : '—';
};

$format_relative_time = static function( string $value ): string {
	if ( $value === '' ) { return ''; }
	$timestamp = strtotime( get_date_from_gmt( $value, 'Y-m-d H:i:s' ) );
	return $timestamp ? sprintf( __( '%s پیش', 'kasebi-erp' ), human_time_diff( $timestamp, current_time( 'timestamp' ) ) ) : '';
};

$field_value_text = static function( array $field ): string {
	$parts = [];
	foreach ( (array) ( $field['values'] ?? [] ) as $value ) {
		$text = trim( (string) ( $value['value'] ?? '' ) );
		if ( $text !== '' ) { $parts[] = $text; }
	}
	return implode( '، ', $parts );
};

$field_icons = [
	'email' => 'ni ni-mail', 'phone' => 'ni ni-call', 'name' => 'ni ni-user', 'address' => 'ni ni-map-pin',
	'date' => 'ni ni-calendar', 'time' => 'ni ni-clock', 'website' => 'ni ni-globe', 'fileupload' => 'ni ni-clip',
	'number' => 'ni ni-hash', 'select' => 'ni ni-list', 'radio' => 'ni ni-check-circle', 'checkbox' => 'ni ni-check-square',
];
$selected_form_title = $form_id > 0 ? (string) ( $form_options[ $form_id ] ?? sprintf( '#%d', $form_id ) ) : '';
?>
<section class="kerp-gf-entries" aria-labelledby="kerp-gf-entries-title">
    <div class="kerp-customer-tab-controls d-lg-none">
        <div class="kerp-customer-mobile-nav">
            <a href="#" class="toggle btn btn-icon btn-trigger" data-target="customerAside"
               aria-label="<?php esc_attr_e( 'نمایش منوی کاربر', 'kasebi-erp' ); ?>"><em class="icon ni ni-menu-alt-r"></em></a>
        </div>
    </div>
    <div class="kerp-gf-entries__hero">
        <div class="kerp-gf-entries__hero-copy">
            <span class="kerp-gf-entries__hero-icon"><em class="uik-r fa-form icon"></em></span>
            <div>
                <span class="kerp-gf-entries__eyebrow"><?php esc_html_e( 'تعاملات ثبت‌شده', 'kasebi-erp' ); ?></span>
                <h5 id="kerp-gf-entries-title"><?php esc_html_e( 'پاسخ‌های فرم‌های کاربر', 'kasebi-erp' ); ?></h5>
                <p><?php esc_html_e( 'خلاصه پاسخ‌ها را مرور کنید و برای مشاهده تمام جزئیات، هر ورودی را باز کنید.', 'kasebi-erp' ); ?></p>
            </div>
        </div>
        <div class="kerp-gf-entries__summary" aria-label="<?php esc_attr_e( 'خلاصه ورودی‌ها', 'kasebi-erp' ); ?>">
            <div><strong><?php echo esc_html( number_format_i18n( $total ) ); ?></strong><span><?php esc_html_e( 'ورودی ثبت‌شده', 'kasebi-erp' ); ?></span></div>
            <span class="kerp-gf-entries__summary-divider"></span>
            <div><strong><?php echo esc_html( number_format_i18n( count( $forms ) ) ); ?></strong><span><?php esc_html_e( 'فرم در دسترس', 'kasebi-erp' ); ?></span></div>
        </div>
    </div>

    <div class="card card-bordered kerp-gf-entries__card">
        <div class="card-inner kerp-gf-entries__toolbar">
            <div class="kerp-gf-entries__toolbar-copy">
                <h6><?php esc_html_e( 'تاریخچه پاسخ‌ها', 'kasebi-erp' ); ?></h6>
                <p><?php echo $selected_form_title !== '' ? esc_html( sprintf( __( 'نمایش ورودی‌های فرم «%s»', 'kasebi-erp' ), $selected_form_title ) ) : esc_html__( 'مرتب‌شده از جدیدترین ورودی', 'kasebi-erp' ); ?></p>
            </div>
            <div class="kerp-gf-entries__tools">
                <?php if ( $selected_form_title !== '' ) : ?><span class="kerp-gf-entries__active-filter"><em class="ni ni-filter-alt icon"></em><?php echo esc_html( $selected_form_title ); ?></span><?php endif; ?>
                <?php KERP_Helpers_Template::render_template( 'app/components/list/filter-dropdown.php', [
					'has_filter' => $form_id > 0,
					'filter_fields' => [ 'form_id' => [ 'name' => 'form_id', 'type' => 'select', 'label' => __( 'فرم', 'kasebi-erp' ), 'placeholder' => __( 'همه فرم‌ها', 'kasebi-erp' ), 'options' => $form_options, 'value' => $form_id, 'col' => 12 ] ],
					'page' => $base_page, 'action' => 'erp_request_page_content', 'apply_class' => 'filter_erp_list', 'reset_class' => 'reset_page_filter', 'title' => __( 'فیلتر ورودی‌ها', 'kasebi-erp' ),
				] ); ?>
                <?php KERP_Helpers_Template::render_template( 'app/components/list/per-page-selector.php', [
					'per_page' => $per_page, 'available_per_pages' => [ 5, 10, 20, 50 ], 'page' => $return_page, 'action' => 'erp_request_page_content',
				] ); ?>
            </div>
        </div>

		<?php if ( empty( $entries ) ) : ?>
            <div class="card-inner text-center py-5">
                <span class="kerp-gf-entries__empty-icon"><em class="uik-r fa-form icon"></em></span>
                <h5 class="mt-3 mb-1"><?php esc_html_e( 'هنوز پاسخی اینجا نیست', 'kasebi-erp' ); ?></h5>
                <p class="text-soft mb-0"><?php esc_html_e( 'فیلتر فرم را تغییر دهید یا پس از ثبت پاسخ دوباره بررسی کنید.', 'kasebi-erp' ); ?></p>
            </div>
		<?php else : ?>
            <div class="kerp-gf-entries__list">
			<?php foreach ( $entries as $entry ) :
				$entry_id = absint( $entry['id'] ?? 0 );
				$entry_form_id = absint( $entry['form_id'] ?? 0 );
				if ( ! isset( $form_cache[ $entry_form_id ] ) ) { $form_cache[ $entry_form_id ] = $query->get_form( $entry_form_id ); }
				$entry_form = $form_cache[ $entry_form_id ];
				$form_title = (string) ( $entry_form['title'] ?? ( $forms[ $entry_form_id ]['title'] ?? sprintf( '#%d', $entry_form_id ) ) );
				$fields = $query->get_public_fields( $entry_form, $entry );
				$preview_fields = array_slice( $fields, 0, 3 );
				$remaining_fields = max( 0, count( $fields ) - count( $preview_fields ) );
				$modal_id = 'gravityFormEntry' . $entry_id;
				$confirmation_modal_id = 'gravityFormConfirmation' . $entry_id;
				$confirmation = $query->get_confirmation_preview( $entry_form, $entry );
				$form_initial = mb_substr( trim( $form_title ), 0, 1 );
				$accent = ( $entry_form_id % 5 ) + 1;
				ob_start();
				?>
                <div class="kerp-gf-entry-modal">
                    <div class="kerp-gf-entry-modal__summary">
                        <span class="kerp-gf-entry-modal__icon"><em class="uik-r fa-form icon"></em></span>
                        <div><span><?php esc_html_e( 'فرم', 'kasebi-erp' ); ?></span><strong><?php echo esc_html( $form_title ); ?></strong></div>
                        <div><span><?php esc_html_e( 'شناسه ورودی', 'kasebi-erp' ); ?></span><strong dir="ltr">#<?php echo esc_html( number_format_i18n( $entry_id ) ); ?></strong></div>
                        <div><span><?php esc_html_e( 'زمان ثبت', 'kasebi-erp' ); ?></span><strong><?php echo esc_html( $format_datetime( (string) ( $entry['date_created'] ?? '' ) ) ); ?></strong></div>
                    </div>
				<?php if ( empty( $fields ) ) : ?>
                    <div class="kerp-gf-entry-modal__empty"><em class="ni ni-info icon"></em><span><?php esc_html_e( 'فیلد قابل نمایشی در این ورودی وجود ندارد.', 'kasebi-erp' ); ?></span></div>
				<?php else : ?>
                    <div class="kerp-gf-entry-modal__fields">
					<?php foreach ( $fields as $field ) : $field_icon = $field_icons[ $field['type'] ] ?? 'ni ni-text'; ?>
                        <div class="kerp-gf-entry-modal__field">
                            <span class="kerp-gf-entry-modal__field-icon"><em class="<?php echo esc_attr( $field_icon ); ?> icon"></em></span>
                            <div><span class="kerp-gf-entry-modal__label"><?php echo esc_html( $field['label'] ?: __( 'بدون عنوان', 'kasebi-erp' ) ); ?></span>
							<?php foreach ( $field['values'] as $field_value ) : ?>
                                <div class="kerp-gf-entry-modal__value"><?php if ( $field_value['label'] !== '' ) : ?><small><?php echo esc_html( $field_value['label'] ); ?></small><?php endif; ?><span><?php echo nl2br( esc_html( $field_value['value'] ) ); ?></span></div>
							<?php endforeach; ?>
                            </div>
                        </div>
					<?php endforeach; ?>
                    </div>
				<?php endif; ?>
                </div>
				<?php
				$modals[] = [ 'type' => 'context', 'id' => $modal_id, 'title' => __( 'جزئیات پاسخ فرم', 'kasebi-erp' ), 'size' => 'lg', 'body' => (string) ob_get_clean() ];
				ob_start();
				?>
                <div class="kerp-gf-entry-modal">
                    <h6><?php echo esc_html( $form_title ); ?></h6>
                    <p class="text-soft small"><?php esc_html_e( 'تأییدیه بر اساس تنظیمات فعلی فرم و پاسخ‌های این ورودی نمایش داده می‌شود.', 'kasebi-erp' ); ?></p>
                    <?php if ( $confirmation['message'] !== '' ) : ?>
                        <div class="kerp-gf-entry-modal__confirmation"><?php echo wp_kses_post( $confirmation['message'] ); ?></div>
                    <?php endif; ?>
                    <?php if ( $confirmation['redirect'] !== '' ) : ?>
                        <p class="text-soft mt-3 mb-1"><?php esc_html_e( 'مقصد تأییدیه فرم', 'kasebi-erp' ); ?></p>
                        <a class="kerp-gf-entry-modal__destination" href="<?php echo esc_url( $confirmation['redirect'] ); ?>" target="_blank" rel="noopener noreferrer" dir="ltr"><?php echo esc_html( $confirmation['redirect'] ); ?></a>
                    <?php elseif ( $confirmation['message'] === '' ) : ?>
                        <div class="kerp-gf-entry-modal__empty"><em class="ni ni-info icon"></em><span><?php esc_html_e( 'تأییدیه قابل نمایشی برای این ورودی وجود ندارد.', 'kasebi-erp' ); ?></span></div>
                    <?php endif; ?>
                </div>
				<?php
				$modals[] = [ 'type' => 'context', 'id' => $confirmation_modal_id, 'title' => __( 'تأییدیه فرم', 'kasebi-erp' ), 'size' => 'lg', 'body' => (string) ob_get_clean() ];
				?>
                <article class="kerp-gf-entry kerp-gf-entry--accent-<?php echo esc_attr( $accent ); ?>">
                    <div class="kerp-gf-entry__head">
                        <div class="kerp-gf-entry__identity">
                            <span class="kerp-gf-entry__avatar" aria-hidden="true"><?php echo esc_html( $form_initial !== '' ? $form_initial : 'F' ); ?></span>
                            <div><span class="kerp-gf-entry__eyebrow"><?php echo esc_html( sprintf( __( 'ورودی %s', 'kasebi-erp' ), '#' . number_format_i18n( $entry_id ) ) ); ?></span><h6><?php echo esc_html( $form_title ); ?></h6></div>
                        </div>
                        <div class="kerp-gf-entry__time"><em class="ni ni-clock icon"></em><div><strong><?php echo esc_html( $format_relative_time( (string) ( $entry['date_created'] ?? '' ) ) ); ?></strong><span><?php echo esc_html( $format_datetime( (string) ( $entry['date_created'] ?? '' ) ) ); ?></span></div></div>
                    </div>

                    <div class="kerp-gf-entry__preview">
					<?php if ( empty( $preview_fields ) ) : ?>
                        <div class="kerp-gf-entry__no-preview"><em class="ni ni-info icon"></em><?php esc_html_e( 'پاسخ قابل نمایشی برای پیش‌نمایش وجود ندارد.', 'kasebi-erp' ); ?></div>
					<?php else : foreach ( $preview_fields as $field ) : $preview_icon = $field_icons[ $field['type'] ] ?? 'ni ni-text'; ?>
                        <div class="kerp-gf-entry__preview-item">
                            <span><em class="<?php echo esc_attr( $preview_icon ); ?> icon"></em></span>
                            <div><small><?php echo esc_html( $field['label'] ?: __( 'بدون عنوان', 'kasebi-erp' ) ); ?></small><strong><?php echo esc_html( $field_value_text( $field ) ); ?></strong></div>
                        </div>
					<?php endforeach; endif; ?>
                    </div>

                    <div class="kerp-gf-entry__foot">
                        <div class="kerp-gf-entry__field-count"><em class="ni ni-list-check icon"></em><span><?php echo esc_html( sprintf( _n( '%s پاسخ ثبت‌شده', '%s پاسخ ثبت‌شده', count( $fields ), 'kasebi-erp' ), number_format_i18n( count( $fields ) ) ) ); ?></span><?php if ( $remaining_fields > 0 ) : ?><small><?php echo esc_html( sprintf( __( '+%s مورد دیگر', 'kasebi-erp' ), number_format_i18n( $remaining_fields ) ) ); ?></small><?php endif; ?></div>
                        <div class="kerp-gf-entry__actions">
                            <button type="button" class="btn btn-sm btn-outline-primary kerp-gf-entry__view nk-tooltip" title="<?php esc_attr_e( 'مشاهده همه پاسخ‌ها', 'kasebi-erp' ); ?>" aria-label="<?php esc_attr_e( 'مشاهده همه پاسخ‌ها', 'kasebi-erp' ); ?>" data-bs-toggle="modal" data-bs-target="#<?php echo esc_attr( $modal_id ); ?>"><span><?php esc_html_e( 'مشاهده همه پاسخ‌ها', 'kasebi-erp' ); ?></span><em class="ni ni-arrow-left icon"></em></button>
                            <button type="button" class="btn btn-sm btn-outline-primary kerp-gf-entry__view nk-tooltip" title="<?php esc_attr_e( 'مشاهده تأییدیه فرم', 'kasebi-erp' ); ?>" aria-label="<?php esc_attr_e( 'مشاهده تأییدیه فرم', 'kasebi-erp' ); ?>" data-bs-toggle="modal" data-bs-target="#<?php echo esc_attr( $confirmation_modal_id ); ?>"><span><?php esc_html_e( 'مشاهده تأییدیه', 'kasebi-erp' ); ?></span><em class="ni ni-check-circle icon"></em></button>
                        </div>
                    </div>
                </article>
			<?php endforeach; ?>
            </div>

			<?php if ( $total_pages > 1 ) : ?>
            <div class="card-inner border-top kerp-gf-entries__pagination">
				<?php KERP_Helpers_Template::render_template( 'app/components/list/pagination.php', [ 'max_page_num' => $total_pages, 'current_page' => $page_number, 'class_name' => 'customer_gravity_entries_pagination_link', 'show_count' => 2, 'action' => 'erp_request_page_content', 'page' => $return_page ] ); ?>
            </div>
			<?php endif; ?>
		<?php endif; ?>
    </div>
</section>

<?php foreach ( $modals as $modal ) { KERP_Helpers_Template::render_modal( $modal ); } ?>
