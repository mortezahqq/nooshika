<?php

defined( 'ABSPATH' ) || exit;

/**
 * @var WP_User $employee
 * @var int     $employee_id
 * @var array   $main_fields
 * @var array   $fields
 */

if ( ! isset( $employee ) || ! $employee instanceof WP_User ) {
	return;
}

$employee_id    = absint( $employee_id ?? $employee->ID );
$fields_service = KERP_Modules_Employees_Fields::instance();
$settings       = KERP_Modules_Employees_Settings::instance();
$main_fields    = isset( $main_fields ) && is_array( $main_fields )
	? $main_fields
	: $fields_service->get_main_profile_view_fields( $employee_id );
$custom_fields  = isset( $fields ) && is_array( $fields )
	? $fields
	: $fields_service->get_custom_profile_view_fields( $employee_id );
$can_edit       = kerp_can( 'employees.update', 'action' );
$modal_id       = 'kerp-employee-profile-modal';
$page_route     = add_query_arg(
	[ 'tab' => 'profile' ],
	'/erp/employees/' . $employee_id . '/'
);
?>
<div class="nk-block nk-block-between">
    <div class="nk-block-head-content align-self-start d-lg-none">
        <a href="#"
           class="toggle btn btn-icon btn-trigger mt-n1"
           data-target="employeeAside">
            <em class="icon ni ni-menu-alt-r"></em>
        </a>
    </div>

    <div class="nk-block-head">
        <h6 class="title">
			<?php
			printf(
				esc_html__( 'اطلاعات %s', 'kasebi-erp' ),
				esc_html( $settings->get_singular_label() )
			);
			?>
        </h6>
        <p><?php esc_html_e( 'اطلاعات اصلی و فیلدهای اختصاصی پرونده کارمند', 'kasebi-erp' ); ?></p>
    </div>

	<?php if ( $can_edit ) : ?>
        <div class="nk-block-head-content" style="margin-right: auto;">
            <a class="btn btn-white btn-icon btn-outline-light"
               data-bs-toggle="modal"
               href="#<?php echo esc_attr( $modal_id ); ?>">
                <em class="icon ni ni-edit"></em>
            </a>
        </div>
	<?php endif; ?>
</div>

<?php do_action( 'kerp_employee_profile_before_main_fields', $employee_id, $employee, $main_fields ); ?>

<div class="nk-block">
    <div class="profile-ud-list">
		<?php foreach ( $main_fields as $field_key => $field ) : ?>
			<?php
			if ( ! is_array( $field ) ) {
				continue;
			}

			$label = trim( (string) ( $field['label'] ?? $field_key ) );
			$value = (string) ( $field['display_value'] ?? '-' );

			if ( $label === '' ) {
				continue;
			}
			?>
            <div class="profile-ud-item">
                <div class="profile-ud wider">
                    <span class="profile-ud-label"><?php echo esc_html( $label ); ?></span>
                    <span class="profile-ud-value"><?php echo esc_html( $value ); ?></span>
                </div>
            </div>
		<?php endforeach; ?>
    </div>
</div>

<?php do_action( 'kerp_employee_profile_after_main_fields', $employee_id, $employee, $main_fields ); ?>

<?php if ( ! empty( $custom_fields ) ) : ?>
    <div class="nk-divider divider md"></div>

    <div class="nk-block mb-2">
        <div class="nk-block-head nk-block-head-line">
            <h6 class="title text-base"><?php esc_html_e( 'اطلاعات تکمیلی', 'kasebi-erp' ); ?></h6>
        </div>

        <div class="profile-ud-list">
			<?php foreach ( $custom_fields as $field_key => $field ) : ?>
				<?php
				if ( ! is_array( $field ) ) {
					continue;
				}

				$label = trim( (string) ( $field['label'] ?? $field_key ) );
				$value = (string) ( $field['display_value'] ?? '-' );

				if ( $label === '' ) {
					continue;
				}
				?>
                <div class="profile-ud-item">
                    <div class="profile-ud wider">
                        <span class="profile-ud-label"><?php echo esc_html( $label ); ?></span>
                        <span class="profile-ud-value"><?php echo esc_html( $value ); ?></span>
                    </div>
                </div>
			<?php endforeach; ?>
        </div>
    </div>
<?php endif; ?>

<?php do_action( 'kerp_employee_profile_after_custom_fields', $employee_id, $employee, $custom_fields ); ?>

<?php
if ( $can_edit ) {
	$modal_fields = [
		[
			'id'          => 'kerp-employee-profile-id',
			'name'        => 'employee_id',
			'type'        => 'hidden',
			'input_class' => 'no_clear',
			'value'       => $employee_id,
		],
	];

	$modal_fields = array_merge(
		$modal_fields,
		array_values(
			$fields_service->get_edit_profile_fields( $employee_id )
		)
	);

	$normalized_fields = [];

	foreach ( $modal_fields as $field ) {
		if ( ! is_array( $field ) ) {
			continue;
		}

		$classes = preg_split(
			'/\s+/',
			trim( (string) ( $field['input_class'] ?? '' ) ),
			-1,
			PREG_SPLIT_NO_EMPTY
		);
		$classes[] = 'no_clear';

		$field['input_class'] = implode(
			' ',
			array_unique( $classes )
		);

		$normalized_fields[] = $field;
	}

	$modal = [
		'id'     => $modal_id,
		'title'  => sprintf(
			__( 'ویرایش اطلاعات %s', 'kasebi-erp' ),
			$settings->get_singular_label()
		),
		'action' => 'employees_save_profile',
		'page'   => $page_route,
		'button' => __( 'ذخیره تغییرات', 'kasebi-erp' ),
		'size'   => 'lg',
		'fields' => $normalized_fields,
	];

	$modal = apply_filters(
		'kerp_employee_profile_modal_data',
		$modal,
		$employee_id,
		$employee
	);

	if ( is_array( $modal ) && ! empty( $modal['id'] ) ) {
		KERP_Helpers_Template::render_modal( $modal );
	}
}
