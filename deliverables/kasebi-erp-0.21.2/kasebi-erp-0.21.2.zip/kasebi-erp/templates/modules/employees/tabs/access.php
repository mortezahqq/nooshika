<?php

defined( 'ABSPATH' ) || exit;

/**
 * @var WP_User $employee
 * @var int     $employee_id
 */

if ( ! isset( $employee ) || ! $employee instanceof WP_User ) {
	return;
}

$employee_id = absint( $employee_id ?? $employee->ID );
$record      = KERP_Services_Access::get_record( $employee_id );

if ( ! is_array( $record ) ) {
	?>
    <div class="alert alert-warning alert-icon">
        <em class="icon ni ni-alert-circle"></em>
        <div>
            <strong><?php esc_html_e( 'رکورد دسترسی پیدا نشد.', 'kasebi-erp' ); ?></strong>
            <p class="mb-0"><?php esc_html_e( 'برای این کارمند هنوز رکورد دسترسی معتبری ثبت نشده است.', 'kasebi-erp' ); ?></p>
        </div>
    </div>
	<?php
	return;
}

$permissions_service           = KERP_Modules_Employees_Permissions::instance();
$roles_service                 = KERP_Modules_Employees_Roles::instance();
$groups                        = $permissions_service->get_groups();
$role_key                      = $roles_service->normalize_key(
	(string) ( $record['role_key'] ?? '' )
);
$role                          = $roles_service->get( $role_key );
$role_label                    = (string) ( $role['label'] ?? $role_key );
$role_icon                     = (string) ( $role['icon'] ?? 'ni ni-shield-check' );
$current_permissions           = [
	'view'   => json_decode(
		(string) ( $record['view_permissions'] ?? '[]' ),
		TRUE
	),
	'action' => json_decode(
		(string) ( $record['action_permissions'] ?? '[]' ),
		TRUE
	),
];
$current_permissions['view']   = is_array( $current_permissions['view'] )
	? $current_permissions['view']
	: [];
$current_permissions['action'] = is_array( $current_permissions['action'] )
	? $current_permissions['action']
	: [];
$current_url                   = '/erp/employees/' . $employee_id . '/?tab=access';
$accordion_id                  = 'kerp-employee-access-accordion-' . $employee_id;
$role_options                  = $roles_service->get_options();
$default_page_options          = KERP_App::instance()->get_user_default_page_options( $employee_id );
$default_page                  = get_user_meta( $employee_id, 'kerp_default_page', TRUE );
$default_page                  = is_string( $default_page ) ? $default_page : '';
$default_page_available        = array_key_exists( $default_page, $default_page_options );
$default_page_label            = $default_page_options[ $default_page ] ?? __( 'صفحه قبلی در دسترس نیست؛ میزکار باز می‌شود.', 'kasebi-erp' );
if ( $default_page === '' ) {
	$role_default_page = KERP_App::instance()->get_user_role_default_page( $employee_id );
	$effective_label = $default_page_options[ $role_default_page ] ?? __( 'میزکار', 'kasebi-erp' );
	if ( $role_default_page === '' ) {
		$effective_label = __( 'میزکار', 'kasebi-erp' );
	}
	$default_page_label = sprintf( __( 'پیش‌فرض نقش: %s', 'kasebi-erp' ), $effective_label );
}

$total_permissions    = 0;
$selected_permissions = 0;

foreach ( $groups as $group ) {
	foreach ( (array) ( $group['blocks'] ?? [] ) as $block ) {
		foreach ( (array) ( $block['permissions'] ?? [] ) as $permission ) {
			$total_permissions ++;
			
			if ( $permissions_service->is_permission_selected( $permission, $current_permissions ) ) {
				$selected_permissions ++;
			}
		}
	}
}
?>
    <div class="nk-block mb-4">
        <div class="card card-bordered">
            <div class="card-inner">
                <div class="d-flex flex-wrap align-items-center justify-content-between gap-3">
                    <div>
                        <h6 class="title"><?php esc_html_e( 'صفحه پیش‌فرض ERP', 'kasebi-erp' ); ?></h6>
                        <p class="text-soft mb-1"><?php esc_html_e( 'صفحه‌ای که هنگام ورود کارمند به آدرس اصلی ERP باز می‌شود.', 'kasebi-erp' ); ?></p>
                        <strong><?php echo esc_html( $default_page_label ); ?></strong>
                    </div>
                    <button type="button" class="btn btn-outline-primary btn-sm"
                            data-bs-toggle="modal" data-bs-target="#kerp-employee-default-page-modal">
                        <em class="icon ni ni-edit"></em>
                        <span><?php esc_html_e( 'تنظیم صفحه پیش‌فرض', 'kasebi-erp' ); ?></span>
                    </button>
                </div>
            </div>
        </div>
    </div>
<?php
$default_page_modal_options = $default_page_options;
unset( $default_page_modal_options[''] );
KERP_Helpers_Template::render_modal(
	[
		'id' => 'kerp-employee-default-page-modal',
		'title' => __( 'صفحه پیش‌فرض ERP کارمند', 'kasebi-erp' ),
		'action' => 'employees_save_default_page',
		'page' => $current_url,
		'button' => __( 'ذخیره صفحه پیش‌فرض', 'kasebi-erp' ),
		'size' => 'md',
		'fields' => [
			[
				'id' => 'kerp-employee-default-page-nonce',
				'name' => 'default_page_nonce',
				'type' => 'hidden',
				'input_class' => 'no_clear',
				'value' => wp_create_nonce( 'kerp-employee-default-page' ),
			],
			[
				'id' => 'kerp-employee-default-page-id',
				'name' => 'employee_id',
				'type' => 'hidden',
				'input_class' => 'no_clear',
				'value' => $employee_id,
			],
			[
				'id' => 'kerp-employee-default-page',
				'name' => 'default_page',
				'label' => __( 'صفحه پیش‌فرض', 'kasebi-erp' ),
				'type' => 'select',
				'class' => 'col-12',
				'input_class' => 'no_clear',
				'placeholder' => $default_page_options[''],
				'options' => $default_page_modal_options,
				'value' => $default_page_available ? $default_page : '',
			],
		],
	]
);
?>
    <form class="modal_form kerp-employee-access-form"
          data-action="employees_save_access"
          data-page="<?php echo esc_attr( $current_url ); ?>">
        <input type="hidden"
               class="no_clear"
               name="employee_id"
               data-for="employee_id"
               value="<?php echo esc_attr( $employee_id ); ?>">

        <div class="nk-block nk-block-between">
            <div class="nk-block-head-content align-self-start d-lg-none">
                <a href="#"
                   class="toggle btn btn-icon btn-trigger mt-n1"
                   data-target="employeeAside">
                    <em class="icon ni ni-menu-alt-r"></em>
                </a>
            </div>
            <div class="nk-block-head">
                <h6 class="title"><?php esc_html_e( 'دسترسی‌های اختصاصی کارمند', 'kasebi-erp' ); ?></h6>
                <p><?php esc_html_e( 'دسترسی‌های این کارمند را مستقل از تنظیمات پیش‌فرض نقش مدیریت کنید.', 'kasebi-erp' ); ?></p>
            </div>
            <div class="nk-block-head-content kerp-employee-access-actions">
                <button type="button"
                        class="btn btn-outline-primary btn-sm"
                        data-bs-toggle="modal"
                        data-bs-target="#kerp-reset-employee-access-modal">
                    <em class="icon ni ni-reload"></em>
                    <span><?php esc_html_e( 'بازنشانی براساس نقش', 'kasebi-erp' ); ?></span>
                </button>
                <button type="button" class="btn btn-primary btn-sm submit_modal_form">
                    <em class="icon ni ni-save"></em>
                    <span><?php esc_html_e( 'ذخیره دسترسی‌ها', 'kasebi-erp' ); ?></span>
                </button>
            </div>
        </div>

        <div class="nk-block">
            <div class="card card-bordered kerp-employee-access-summary">
                <div class="card-inner">
                    <div class="kerp-employee-access-summary__content">
                        <div class="kerp-employee-access-summary__role">
                            <div class="kerp-employee-access-summary__icon">
                                <em class="<?php echo esc_attr( $role_icon ); ?> icon"></em>
                            </div>
                            <div>
                                <span
                                    class="overline-title"><?php esc_html_e( 'نقش سازمانی فعلی', 'kasebi-erp' ); ?></span>
                                <h5 class="mb-1"><?php echo esc_html( $role_label ); ?></h5>
                                <code><?php echo esc_html( $role_key ); ?></code>
                            </div>
                        </div>
                        <div class="kerp-employee-access-summary__stats">
                            <div>
                                <span><?php esc_html_e( 'دسترسی فعال', 'kasebi-erp' ); ?></span>
                                <strong><?php echo esc_html( number_format_i18n( $selected_permissions ) ); ?></strong>
                            </div>
                            <div>
                                <span><?php esc_html_e( 'کل دسترسی‌ها', 'kasebi-erp' ); ?></span>
                                <strong><?php echo esc_html( number_format_i18n( $total_permissions ) ); ?></strong>
                            </div>
                            <div>
                                <span><?php esc_html_e( 'گروه‌ها', 'kasebi-erp' ); ?></span>
                                <strong><?php echo esc_html( number_format_i18n( count( $groups ) ) ); ?></strong>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="nk-block">
            <div class="accordion kerp-employee-access-accordion" id="<?php echo esc_attr( $accordion_id ); ?>">
				<?php $group_counter = 0; ?>
				<?php foreach ( $groups as $group ) : ?>
					<?php
					$group_key      = sanitize_key( (string) ( $group['key'] ?? '' ) );
					$group_blocks   = (array) ( $group['blocks'] ?? [] );
					$group_heading  = 'kerp-access-heading-' . $employee_id . '-' . $group_key;
					$group_collapse = 'kerp-access-collapse-' . $employee_id . '-' . $group_key;
					$group_selected = 0;
					$group_total    = 0;
					$is_first_group = $group_counter === 0;
					$group_counter ++;
					
					foreach ( $group_blocks as $block ) {
						foreach ( (array) ( $block['permissions'] ?? [] ) as $permission ) {
							$group_total ++;
							
							if ( $permissions_service->is_permission_selected( $permission, $current_permissions ) ) {
								$group_selected ++;
							}
						}
					}
					?>
                    <div class="accordion-item card card-bordered">
                        <h2 class="accordion-header" id="<?php echo esc_attr( $group_heading ); ?>">
                            <button type="button"
                                    class="accordion-button<?php echo $is_first_group ? '' : ' collapsed'; ?>"
                                    data-bs-toggle="collapse"
                                    data-bs-target="#<?php echo esc_attr( $group_collapse ); ?>"
                                    aria-expanded="<?php echo $is_first_group ? 'true' : 'false'; ?>"
                                    aria-controls="<?php echo esc_attr( $group_collapse ); ?>">
                            <span class="kerp-employee-access-group__identity">
                                <span class="kerp-employee-access-group__icon">
                                    <em class="<?php echo esc_attr( (string) ( $group['icon'] ?? 'ni ni-lock-alt' ) ); ?> icon"></em>
                                </span>
                                <span>
                                    <strong><?php echo esc_html( (string) ( $group['label'] ?? $group_key ) ); ?></strong>
                                    <small>
								<?php
								printf(
									esc_html__( '%1$s دسترسی از %2$s فعال', 'kasebi-erp' ),
									esc_html( number_format_i18n( $group_selected ) ),
									esc_html( number_format_i18n( $group_total ) )
								);
								?>
                                    </small>
                                </span>
                            </span>
                            </button>
                        </h2>
                        <div id="<?php echo esc_attr( $group_collapse ); ?>"
                             class="accordion-collapse collapse<?php echo $is_first_group ? ' show' : ''; ?>"
                             aria-labelledby="<?php echo esc_attr( $group_heading ); ?>"
                             data-bs-parent="#<?php echo esc_attr( $accordion_id ); ?>">
                            <div class="accordion-body p-4">
                                <div class="row g-gs">
									<?php foreach ( $group_blocks as $block_key => $block ) : ?>
                                        <div class="col-12">
                                            <div class="card card-bordered kerp-employee-access-block">
                                                <div class="card-inner border-bottom">
                                                    <div class="kerp-employee-access-block__head">
                                                <span class="kerp-employee-access-block__icon">
                                                    <em class="<?php echo esc_attr( (string) ( $block['icon'] ?? 'ni ni-lock-alt' ) ); ?> icon"></em>
                                                </span>
                                                        <div>
                                                            <h6 class="title mb-0"><?php echo esc_html( (string) ( $block['label'] ?? $block_key ) ); ?></h6>
															<?php if ( ! empty( $block['description'] ) ) : ?>
                                                                <span
                                                                    class="sub-text"><?php echo esc_html( (string) $block['description'] ); ?></span>
															<?php endif; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="card-inner">
                                                    <div class="row g-3">
														<?php foreach ( (array) ( $block['permissions'] ?? [] ) as $permission_id => $permission ) : ?>
															<?php
															$permission_id  = sanitize_key( (string) $permission_id );
															$permission_key = (string) ( $permission['key'] ?? '' );
															$token          = $permissions_service->get_permission_token(
																$group_key,
																$permission_id
															);
															$selected       = $permissions_service->is_permission_selected(
																$permission,
																$current_permissions
															);
															$scope_options  = $permissions_service->get_scope_options( $permission );
															$selected_scope = $permissions_service->get_selected_scope(
																$permission,
																$current_permissions
															);
															
															if ( $selected_scope === '' ) {
																$selected_scope = $permissions_service->get_default_scope( $permission );
															}
															
															$field_id = 'kerp-employee-permission-' . md5(
																	$employee_id . '-' . $token
																);
															$scope_id = $field_id . '-scope';
															?>
                                                            <div class="col-12">
                                                                <div
                                                                    class="kerp-employee-access-permission<?php echo $selected ? ' is-selected' : ''; ?>">
                                                                    <div class="kerp-employee-access-permission__main">
                                                                        <div
                                                                            class="custom-control custom-control-sm custom-switch">
                                                                            <input type="checkbox"
                                                                                   id="<?php echo esc_attr( $field_id ); ?>"
                                                                                   class="custom-control-input no_clear"
                                                                                   name="permission_ids[]"
                                                                                   data-for="permission_ids"
                                                                                   value="<?php echo esc_attr( $token ); ?>"
																				<?php checked( $selected ); ?>>
                                                                            <label class="custom-control-label"
                                                                                   for="<?php echo esc_attr( $field_id ); ?>">
																				<?php echo esc_html( (string) ( $permission['label'] ?? $permission_key ) ); ?>
                                                                            </label>
                                                                        </div>
																		<?php if ( ! empty( $permission['description'] ) ) : ?>
                                                                            <div
                                                                                class="form-note mt-1"><?php echo esc_html( (string) $permission['description'] ); ?></div>
																		<?php endif; ?>
                                                                    </div>
																	<?php if ( ! empty( $scope_options ) ) : ?>
                                                                        <div
                                                                            class="kerp-employee-access-permission__scope">
                                                                            <label class="form-label"
                                                                                   for="<?php echo esc_attr( $scope_id ); ?>">
																				<?php esc_html_e( 'دامنه دسترسی', 'kasebi-erp' ); ?>
                                                                            </label>
                                                                            <select
                                                                                id="<?php echo esc_attr( $scope_id ); ?>"
                                                                                class="form-select no_clear"
                                                                                name="permission_scopes[<?php echo esc_attr( $token ); ?>]"
                                                                                data-for="permission_scopes[<?php echo esc_attr( $token ); ?>]">
																				<?php foreach ( $scope_options as $scope_key => $scope_label ) : ?>
                                                                                    <option
                                                                                        value="<?php echo esc_attr( $scope_key ); ?>"
																						<?php selected( $selected_scope, $scope_key ); ?>>
																						<?php echo esc_html( $scope_label ); ?>
                                                                                    </option>
																				<?php endforeach; ?>
                                                                            </select>
                                                                        </div>
																	<?php endif; ?>
                                                                </div>
                                                            </div>
														<?php endforeach; ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
									<?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    </div>
				<?php endforeach; ?>
            </div>
        </div>
    </form>

<?php
KERP_Helpers_Template::render_modal(
	[
		'id'     => 'kerp-reset-employee-access-modal',
		'title'  => __( 'بازنشانی نقش و دسترسی‌ها', 'kasebi-erp' ),
		'action' => 'employees_reset_access_to_role',
		'page'   => $current_url,
		'button' => __( 'بازنشانی دسترسی‌ها', 'kasebi-erp' ),
		'size'   => 'md',
		'fields' => [
			[
				'id'          => 'kerp-reset-employee-access-id',
				'name'        => 'employee_id',
				'type'        => 'hidden',
				'input_class' => 'no_clear',
				'value'       => $employee_id,
			],
			[
				'id'          => 'kerp-reset-employee-access-role',
				'name'        => 'role_key',
				'label'       => __( 'نقش سازمانی', 'kasebi-erp' ),
				'description' => __( 'تمام دسترسی‌های اختصاصی فعلی حذف و با دسترسی‌های پیش‌فرض نقش انتخاب‌شده جایگزین می‌شوند.', 'kasebi-erp' ),
				'type'        => 'select',
				'class'       => 'col-12',
				'input_class' => 'no_clear',
				'options'     => $role_options,
				'value'       => $role_key,
			],
		],
	]
);
