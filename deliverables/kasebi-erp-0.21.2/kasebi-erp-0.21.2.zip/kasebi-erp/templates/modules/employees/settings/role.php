<?php

defined( 'ABSPATH' ) || exit;

/**
 * @var array $page_context
 */

$page_context    = isset( $page_context ) && is_array( $page_context ) ? $page_context : [];
$page_query      = isset( $page_context['query'] ) && is_array( $page_context['query'] )
	? $page_context['query']
	: [];
$role_slug       = sanitize_title( (string) ( $page_context['route_params']['role_slug'] ?? '' ) );
$requested_tab   = sanitize_key( (string) ( $page_query['tab'] ?? '' ) );
$roles_service   = KERP_Modules_Employees_Roles::instance();
$profile_service = KERP_Modules_Employees_Role_Profile::instance();
$role_context    = $profile_service->get_context( $role_slug, $requested_tab );
$role            = $role_context['role'] ?? NULL;
$roles_url       = '/erp/settings/employees/roles/';

if ( ! is_array( $role ) ) :
	?>
    <div class="nk-block">
        <div class="card card-bordered">
            <div class="card-inner text-center py-5">
                <em class="icon ni ni-alert-circle fs-1 text-soft"></em>
                <h4 class="mt-3 mb-3"><?php esc_html_e( 'نقش سازمانی پیدا نشد.', 'kasebi-erp' ); ?></h4>
                <a href="<?php echo esc_url( home_url( $roles_url ) ); ?>"
                   class="btn btn-outline-primary page_activator"
                   data-url="<?php echo esc_attr( $roles_url ); ?>">
                    <em class="icon ni ni-arrow-right"></em>
                    <span><?php esc_html_e( 'بازگشت به نقش‌ها', 'kasebi-erp' ); ?></span>
                </a>
            </div>
        </div>
    </div>
	<?php
	return;
endif;

if ( ! kerp_can( 'employees.access.manage', 'action' ) ) :
	?>
    <div class="nk-block">
        <div class="card card-bordered">
            <div class="card-inner text-center py-5">
                <em class="icon ni ni-lock-alt fs-1 text-soft"></em>
                <h4 class="mt-3"><?php esc_html_e( 'دسترسی مدیریت نقش‌ها را ندارید.', 'kasebi-erp' ); ?></h4>
            </div>
        </div>
    </div>
	<?php
	return;
endif;

$role_key            = (string) $role['key'];
$role_label          = (string) ( $role['label'] ?? $role_key );
$role_icon           = (string) ( $role['icon'] ?? 'uik-r fa-id-badge' );
$role_active         = ! empty( $role['active'] );
$employee_count      = $roles_service->count_employees( $role_key );
$replacement_options = $roles_service->get_options( $role_key, FALSE );
$current_url         = $roles_service->get_url( $role_key );
$tabs                = isset( $role_context['tabs'] ) && is_array( $role_context['tabs'] )
	? $role_context['tabs']
	: [];
$active_tab          = sanitize_key( (string) ( $role_context['active_tab'] ?? 'general-settings' ) );
$role_status         = $role_active ? __( 'فعال', 'kasebi-erp' ) : __( 'غیرفعال', 'kasebi-erp' );
?>
    <div class="nk-block">
        <div class="card">
            <div class="card-aside-wrap">
                <div class="card-inner">
					<?php $profile_service->render_tab( $active_tab, $role_context ); ?>
                </div>
                <div class="card-aside card-aside-left user-aside toggle-slide toggle-slide-left toggle-break-lg"
                     data-toggle-body="true"
                     data-content="employeeRoleAside"
                     data-toggle-screen="lg"
                     data-toggle-overlay="true">
                    <div class="card-inner-group" data-simplebar>
                        <div class="card-inner">
                            <div class="user-card">
                                <div class="user-avatar bg-primary">
                                    <em class="<?php echo esc_attr( $role_icon ); ?> icon"></em>
                                </div>
                                <div class="user-info">
                                    <span class="lead-text"><?php echo esc_html( $role_label ); ?></span>
                                    <span class="sub-text"><?php echo esc_html( $role_key ); ?></span>
                                </div>
                                <div class="user-action">
                                    <div class="dropdown">
                                        <a href="#" class="btn btn-icon btn-trigger me-n2" data-bs-toggle="dropdown">
                                            <em class="icon ni ni-more-v"></em>
                                        </a>
                                        <div class="dropdown-menu dropdown-menu-end">
                                            <ul class="link-list-opt no-bdr">
                                                <li>
                                                    <a href="<?php echo esc_url( home_url( $roles_url ) ); ?>"
                                                       class="page_activator"
                                                       data-url="<?php echo esc_attr( $roles_url ); ?>">
                                                        <em class="icon ni ni-arrow-right"></em>
                                                        <span><?php esc_html_e( 'بازگشت به نقش‌ها', 'kasebi-erp' ); ?></span>
                                                    </a>
                                                </li>
                                                <li class="divider"></li>
                                                <li>
                                                    <a href="#deleteEmployeeRoleModal"
                                                       class="text-danger"
                                                       data-bs-toggle="modal"
                                                       data-bs-target="#deleteEmployeeRoleModal"
														<?php echo $employee_count > 0 && empty( $replacement_options ) ? 'aria-disabled="true"' : ''; ?>>
                                                        <em class="icon ni ni-trash"></em>
                                                        <span><?php esc_html_e( 'حذف نقش', 'kasebi-erp' ); ?></span>
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-inner">
                            <div class="user-account-info py-0">
                                <div class="g-2 row">
                                    <div class="d-flex align-center" style="gap: 5px;">
                                        <em class="icon ni ni-users text-primary fs-18px"></em>
                                        <span
                                            class="sub-text"><?php esc_html_e( 'تعداد کارکنان:', 'kasebi-erp' ); ?></span>
                                        <span
                                            class="fw-bold"><?php echo esc_html( number_format_i18n( $employee_count ) ); ?></span>
                                    </div>
                                    <div class="d-flex align-center" style="gap: 5px;">
                                        <em class="icon ni ni-check-circle text-primary fs-18px"></em>
                                        <span class="sub-text"><?php esc_html_e( 'وضعیت:', 'kasebi-erp' ); ?></span>
                                        <span
                                            class="fw-bold<?php echo $role_active ? ' text-success' : ' text-soft'; ?>">
                                        <?php echo esc_html( $role_status ); ?>
                                    </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-inner p-0">
                            <ul class="link-list-menu">
								<?php foreach ( $tabs as $tab_key => $tab ) : ?>
									<?php
									$tab_key   = sanitize_key( (string) ( $tab['key'] ?? $tab_key ) );
									$data_url  = add_query_arg( 'tab', $tab_key, $current_url );
									$is_active = $tab_key === $active_tab;
									?>
                                    <li>
                                        <a href="<?php echo esc_url( home_url( $data_url ) ); ?>"
                                           class="page_activator py-2<?php echo $is_active ? ' active' : ''; ?>"
                                           data-url="<?php echo esc_attr( $data_url ); ?>">
                                            <em class="<?php echo esc_attr( (string) ( $tab['icon'] ?? 'ni ni-lock-alt' ) ); ?> icon"></em>
                                            <span><?php echo esc_html( (string) ( $tab['title'] ?? $tab_key ) ); ?></span>
                                        </a>
                                    </li>
								<?php endforeach; ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php
$edit_fields = [
	[
		'id' => 'kerp-edit-employee-role-default-page',
		'name' => 'role[default_page]',
		'label' => __( 'صفحه پیش‌فرض ERP', 'kasebi-erp' ),
		'type' => 'select',
		'class' => 'col-12',
		'input_class' => 'no_clear',
		'placeholder' => __( 'پیش‌فرض سامانه (میزکار)', 'kasebi-erp' ),
		'options' => KERP_App::instance()->get_default_page_options(),
		'value' => (string) ( $role['default_page'] ?? '' ),
	],
	[
		'id'    => 'kerp-edit-employee-role-key',
		'name'  => 'role_key',
		'type'  => 'hidden',
		'class' => 'no_clear',
		'value' => $role_key,
	],
	[
		'id'          => 'kerp-edit-employee-role-label',
		'name'        => 'role[label]',
		'label'       => __( 'عنوان نقش', 'kasebi-erp' ),
		'type'        => 'text',
		'class'       => 'col-md-6',
		'input_class' => 'no_clear',
		'value'       => $role_label,
		'required'    => TRUE,
	],
	[
		'id'          => 'kerp-edit-employee-role-icon',
		'name'        => 'role[icon]',
		'label'       => __( 'کلاس آیکون', 'kasebi-erp' ),
		'type'        => 'text',
		'class'       => 'col-md-6',
		'input_class' => 'no_clear',
		'value'       => $role_icon,
	],
	[
		'id'          => 'kerp-edit-employee-role-order',
		'name'        => 'role[order]',
		'label'       => __( 'ترتیب', 'kasebi-erp' ),
		'type'        => 'number',
		'class'       => 'col-md-6',
		'input_class' => 'no_clear',
		'value'       => (int) ( $role['order'] ?? 100 ),
	],
	[
		'id'          => 'kerp-edit-employee-role-active',
		'name'        => 'role[active]',
		'label'       => __( 'نقش فعال باشد', 'kasebi-erp' ),
		'type'        => 'switch',
		'class'       => 'col-md-6',
		'input_class' => 'no_clear',
		'value'       => $role_active ? 1 : 0,
	],
];
KERP_Helpers_Template::render_modal(
	[
		'id'     => 'editEmployeeRoleModal',
		'title'  => __( 'ویرایش تنظیمات عمومی نقش', 'kasebi-erp' ),
		'action' => 'employees_update_role',
		'page'   => add_query_arg( 'tab', 'general-settings', $current_url ),
		'button' => __( 'ذخیره تغییرات', 'kasebi-erp' ),
		'size'   => 'lg',
		'fields' => $edit_fields,
	]
);

if ( $employee_count > 0 && empty( $replacement_options ) ) :
	?>
    <div class="alert alert-warning mt-4">
        <em class="icon ni ni-alert-circle"></em>
        <span><?php esc_html_e( 'برای حذف این نقش ابتدا یک نقش سازمانی دیگر ایجاد کنید.', 'kasebi-erp' ); ?></span>
    </div>
<?php
else :
	$delete_fields = [
		[
			'id'    => 'kerp-delete-employee-role-key',
			'name'  => 'role_key',
			'type'  => 'hidden',
			'class' => 'no_clear',
			'value' => $role_key,
		],
	];
	
	if ( $employee_count > 0 ) {
		$delete_fields[] = [
			'id'          => 'kerp-delete-employee-role-replacement',
			'name'        => 'replacement_role_key',
			'label'       => sprintf(
				__( 'نقش جدید %s کارمند', 'kasebi-erp' ),
				number_format_i18n( $employee_count )
			),
			'type'        => 'select',
			'class'       => 'col-12',
			'input_class' => 'no_clear',
			'options'     => $replacement_options,
			'required'    => TRUE,
		];
	}
	
	KERP_Helpers_Template::render_modal(
		[
			'id'     => 'deleteEmployeeRoleModal',
			'title'  => sprintf( __( 'حذف نقش «%s»', 'kasebi-erp' ), $role_label ),
			'action' => 'employees_delete_role',
			'page'   => $roles_url,
			'button' => __( 'حذف نقش', 'kasebi-erp' ),
			'size'   => 'md',
			'fields' => $delete_fields,
		]
	);
endif;
