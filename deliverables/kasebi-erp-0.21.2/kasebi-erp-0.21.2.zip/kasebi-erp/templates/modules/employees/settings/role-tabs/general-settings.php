<?php

defined( 'ABSPATH' ) || exit;

/**
 * @var array  $role
 * @var string $role_key
 */

$role_label        = trim( (string) ( $role['label'] ?? $role_key ) );
$role_icon         = trim( (string) ( $role['icon'] ?? 'uik-r fa-id-badge' ) );
$role_order        = (int) ( $role['order'] ?? 100 );
$role_active       = ! empty( $role['active'] );
$default_page_options = KERP_App::instance()->get_default_page_options();
$role_default_page = (string) ( $role['default_page'] ?? '' );
$role_default_page_label = $role_default_page === ''
	? __( 'پیش‌فرض سامانه (میزکار)', 'kasebi-erp' )
	: ( $default_page_options[ $role_default_page ] ?? __( 'صفحه قبلی در دسترس نیست؛ میزکار باز می‌شود.', 'kasebi-erp' ) );
$role_status       = $role_active
	? __( 'فعال', 'kasebi-erp' )
	: __( 'غیرفعال', 'kasebi-erp' );
$role_status_class = $role_active
	? 'badge-dim bg-success'
	: 'badge-dim bg-light text-soft';
?>
<div class="kerp-role-general">
    <div class="nk-block nk-block-between align-center">
        <div class="nk-block-head-content align-self-start d-lg-none">
            <a href="#" class="toggle btn btn-icon btn-trigger mt-n1" data-target="employeeRoleAside">
                <em class="icon ni ni-menu-alt-r"></em>
            </a>
        </div>
        <div class="nk-block-head mb-0">
            <h5 class="title mb-1"><?php esc_html_e( 'تنظیمات عمومی نقش', 'kasebi-erp' ); ?></h5>
            <p class="text-soft mb-0">
				<?php esc_html_e( 'مشخصات پایه و وضعیت نمایش این نقش سازمانی را مدیریت کنید.', 'kasebi-erp' ); ?>
            </p>
        </div>
        <div class="nk-block-head-content">
            <a href="#editEmployeeRoleModal"
               class="btn btn-primary"
               data-bs-toggle="modal"
               data-bs-target="#editEmployeeRoleModal">
                <em class="icon ni ni-edit"></em>
                <span><?php esc_html_e( 'ویرایش تنظیمات', 'kasebi-erp' ); ?></span>
            </a>
        </div>
    </div>

    <div class="nk-block">
        <div class="card card-bordered kerp-role-hero">
            <div class="card-inner">
                <div class="kerp-role-hero__content">
                    <div class="kerp-role-hero__identity">
                        <div class="kerp-role-hero__icon">
                            <em class="<?php echo esc_attr( $role_icon ); ?> icon"></em>
                        </div>
                        <div class="kerp-role-hero__info">
                            <div class="kerp-role-hero__title">
                                <h4 class="mb-0"><?php echo esc_html( $role_label ); ?></h4>
                                <span class="badge <?php echo esc_attr( $role_status_class ); ?>">
									<?php echo esc_html( $role_status ); ?>
                                </span>
                            </div>
                            <p class="text-soft mb-2">
								<?php esc_html_e( 'نقش سازمانی کارکنان و مبنای اعمال دسترسی‌های پیش‌فرض', 'kasebi-erp' ); ?>
                            </p>
                            <div class="kerp-role-hero__key">
                                <em class="icon ni ni-code"></em>
                                <code><?php echo esc_html( $role_key ); ?></code>
                            </div>
                        </div>
                    </div>
                    <div class="kerp-role-hero__order">
                        <span class="overline-title"><?php esc_html_e( 'اولویت نمایش', 'kasebi-erp' ); ?></span>
                        <strong><?php echo esc_html( number_format_i18n( $role_order ) ); ?></strong>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="nk-block">
        <div class="row g-gs">
            <div class="col-md-6">
                <div class="card card-bordered h-100 kerp-role-meta-card">
                    <div class="card-inner">
                        <div class="kerp-role-meta-card__head">
                            <div class="kerp-role-meta-card__icon">
                                <em class="icon ni ni-tag"></em>
                            </div>
                            <div>
                                <span class="overline-title"><?php esc_html_e( 'عنوان نمایشی', 'kasebi-erp' ); ?></span>
                                <h6 class="mt-1 mb-0"><?php echo esc_html( $role_label ); ?></h6>
                            </div>
                        </div>
                        <p class="text-soft mt-3 mb-0">
							<?php esc_html_e( 'این عنوان در پروفایل کارکنان، فیلترها و بخش مدیریت نقش‌ها نمایش داده می‌شود.', 'kasebi-erp' ); ?>
                        </p>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card card-bordered h-100 kerp-role-meta-card">
                    <div class="card-inner">
                        <div class="kerp-role-meta-card__head">
                            <div class="kerp-role-meta-card__icon">
                                <em class="icon ni ni-code"></em>
                            </div>
                            <div>
                                <span class="overline-title"><?php esc_html_e( 'کلید سیستمی', 'kasebi-erp' ); ?></span>
                                <div class="mt-1">
                                    <code class="kerp-role-code"><?php echo esc_html( $role_key ); ?></code>
                                </div>
                            </div>
                        </div>
                        <p class="text-soft mt-3 mb-0">
							<?php esc_html_e( 'این کلید پس از ایجاد نقش قابل تغییر نیست و برای اتصال ماژول‌ها استفاده می‌شود.', 'kasebi-erp' ); ?>
                        </p>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card card-bordered h-100 kerp-role-meta-card">
                    <div class="card-inner">
                        <div class="kerp-role-meta-card__head">
                            <div class="kerp-role-meta-card__icon">
                                <em class="icon ni ni-img"></em>
                            </div>
                            <div>
                                <span class="overline-title"><?php esc_html_e( 'آیکون نقش', 'kasebi-erp' ); ?></span>
                                <div class="kerp-role-icon-preview mt-1">
                                    <em class="<?php echo esc_attr( $role_icon ); ?> icon"></em>
                                    <code><?php echo esc_html( $role_icon ); ?></code>
                                </div>
                            </div>
                        </div>
                        <p class="text-soft mt-3 mb-0">
							<?php esc_html_e( 'آیکون در کارت نقش، Sidebar و گزینه‌های مرتبط با کارکنان نمایش داده می‌شود.', 'kasebi-erp' ); ?>
                        </p>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card card-bordered h-100 kerp-role-meta-card">
                    <div class="card-inner">
                        <div class="kerp-role-meta-card__head">
                            <div class="kerp-role-meta-card__icon">
                                <em class="icon ni ni-check-circle"></em>
                            </div>
                            <div>
                                <span class="overline-title"><?php esc_html_e( 'وضعیت نقش', 'kasebi-erp' ); ?></span>
                                <div class="mt-1">
                                    <span class="badge <?php echo esc_attr( $role_status_class ); ?>">
										<?php echo esc_html( $role_status ); ?>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <p class="text-soft mt-3 mb-0">
							<?php
							echo esc_html(
								$role_active
									? __( 'این نقش برای تخصیص به کارکنان فعال و قابل انتخاب است.', 'kasebi-erp' )
									: __( 'این نقش در انتخاب‌های جدید نمایش داده نمی‌شود، اما اطلاعات قبلی آن حفظ خواهد شد.', 'kasebi-erp' )
							);
							?>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="nk-block">
        <div class="card card-bordered kerp-role-meta-card">
            <div class="card-inner">
                <span class="overline-title"><?php esc_html_e( 'صفحه پیش‌فرض ERP', 'kasebi-erp' ); ?></span>
                <h6 class="mt-1 mb-0"><?php echo esc_html( $role_default_page_label ); ?></h6>
                <p class="text-soft mt-2 mb-0"><?php esc_html_e( 'برای کارکنان بدون صفحه اختصاصی اعمال می‌شود، به شرط داشتن دسترسی به صفحه. صفحه اختصاصی کارمند اولویت دارد.', 'kasebi-erp' ); ?></p>
            </div>
        </div>
    </div>

    <div class="nk-block">
        <div class="alert alert-light alert-icon">
            <em class="icon ni ni-info-fill"></em>
            <div>
                <strong><?php esc_html_e( 'دسترسی‌های پیش‌فرض', 'kasebi-erp' ); ?></strong>
                <p class="mb-0">
					<?php esc_html_e( 'سطوح و دامنه دسترسی این نقش از تب‌های دیگر همین صفحه مدیریت می‌شوند.', 'kasebi-erp' ); ?>
                </p>
            </div>
        </div>
    </div>
</div>
