<?php

defined( 'ABSPATH' ) || exit;

$settings_service = KERP_Modules_Employees_Settings::instance();
$fields_service   = KERP_Modules_Employees_Fields::instance();
$plural_label     = $settings_service->get_plural_label();
$definitions      = $fields_service->get_all( FALSE );

$field_type_options = [
	'text'     => __( 'متن', 'kasebi-erp' ),
	'email'    => __( 'ایمیل', 'kasebi-erp' ),
	'textarea' => __( 'متن چندخطی', 'kasebi-erp' ),
	'number'   => __( 'عدد', 'kasebi-erp' ),
	'price'    => __( 'مبلغ', 'kasebi-erp' ),
	'date'     => __( 'تاریخ', 'kasebi-erp' ),
	'select'   => __( 'لیست انتخابی', 'kasebi-erp' ),
	'radio'    => __( 'انتخاب تکی', 'kasebi-erp' ),
	'checkbox' => __( 'انتخاب چندتایی', 'kasebi-erp' ),
	'switch'   => __( 'کلید روشن/خاموش', 'kasebi-erp' ),
	'url'      => __( 'نشانی اینترنتی', 'kasebi-erp' ),
	'quill'    => __( 'متن پیشرفته', 'kasebi-erp' ),
];

$field_type_icons = [
	'text'     => 'ni ni-text',
	'email'    => 'ni ni-mail',
	'textarea' => 'ni ni-align-left',
	'number'   => 'ni ni-hash',
	'price'    => 'ni ni-money',
	'date'     => 'ni ni-calendar',
	'select'   => 'ni ni-list-thumb',
	'radio'    => 'ni ni-check-circle',
	'checkbox' => 'ni ni-list-check',
	'switch'   => 'ni ni-toggle-on',
	'url'      => 'ni ni-link',
	'quill'    => 'ni ni-edit-alt',
];

$column_options = [
	'col-12'   => __( 'تمام عرض', 'kasebi-erp' ),
	'col-md-6' => __( 'نصف عرض', 'kasebi-erp' ),
	'col-md-4' => __( 'یک‌سوم عرض', 'kasebi-erp' ),
	'col-md-3' => __( 'یک‌چهارم عرض', 'kasebi-erp' ),
];

$modal_id       = 'kerp-employee-field-modal';
$modal_selector = '#' . $modal_id;
$total_count    = count( $definitions );
$active_count   = 0;
$profile_count  = 0;
$filter_count   = 0;

foreach ( $definitions as $definition ) {
	$active_count  += ! isset( $definition['active'] ) || ! empty( $definition['active'] ) ? 1 : 0;
	$profile_count += ! isset( $definition['show_on_profile'] ) || ! empty( $definition['show_on_profile'] ) ? 1 : 0;
	$filter_count  += ! empty( $definition['filterable'] ) ? 1 : 0;
}

$add_populate = [
	'key'             => [
		'id'    => '#kerp-employee-field-key',
		'value' => '',
		'type'  => 'text',
	],
	'label'           => [
		'id'    => '#kerp-employee-field-label',
		'value' => '',
		'type'  => 'text',
	],
	'description'     => [
		'id'    => '#kerp-employee-field-description',
		'value' => '',
		'type'  => 'text',
	],
	'type'            => [
		'id'    => '#kerp-employee-field-type',
		'value' => 'text',
		'type'  => 'select',
	],
	'placeholder'     => [
		'id'    => '#kerp-employee-field-placeholder',
		'value' => '',
		'type'  => 'text',
	],
	'class'           => [
		'id'    => '#kerp-employee-field-class',
		'value' => 'col-md-6',
		'type'  => 'select',
	],
	'options'         => [
		'id'    => '#kerp-employee-field-options',
		'value' => '',
		'type'  => 'text',
	],
	'active'          => [
		'id'    => '#kerp-employee-field-active',
		'value' => '1',
		'type'  => 'switch',
	],
	'show_on_create'  => [
		'id'    => '#kerp-employee-field-show-on-create',
		'value' => '0',
		'type'  => 'switch',
	],
	'show_on_profile' => [
		'id'    => '#kerp-employee-field-show-on-profile',
		'value' => '1',
		'type'  => 'switch',
	],
	'filterable'      => [
		'id'    => '#kerp-employee-field-filterable',
		'value' => '0',
		'type'  => 'switch',
	],
	'column'          => [
		'id'    => '#kerp-employee-field-column',
		'value' => '0',
		'type'  => 'switch',
	],
	'order'           => [
		'id'    => '#kerp-employee-field-order',
		'value' => 100,
		'type'  => 'text',
	],
];
?>
    <div class="kerp-employees-fields-settings">
        <div class="nk-block-head nk-block-head-sm">
            <div class="nk-block-between g-3">
                <div class="nk-block-head-content">
                    <h3 class="nk-block-title page-title">
						<?php printf( esc_html__( 'فیلدهای اختصاصی %s', 'kasebi-erp' ), esc_html( $plural_label ) ); ?>
                    </h3>
                    <div class="nk-block-des text-soft">
                        <p><?php esc_html_e( 'ساختار اطلاعات اختصاصی کارکنان را برای فرم‌ها، پروفایل، فیلترها و ستون‌های فهرست مدیریت کنید.', 'kasebi-erp' ); ?></p>
                    </div>
                </div>
                <div class="nk-block-head-content">
                    <button type="button"
                            class="btn btn-primary open_populate_modal"
                            data-modal="<?php echo esc_attr( $modal_selector ); ?>"
                            data-modal-title="<?php esc_attr_e( 'افزودن فیلد اختصاصی', 'kasebi-erp' ); ?>"
                            data-submit-text="<?php esc_attr_e( 'افزودن فیلد', 'kasebi-erp' ); ?>"
                            data-populate="<?php echo esc_attr( wp_json_encode( $add_populate ) ); ?>">
                        <em class="icon ni ni-plus"></em>
                        <span><?php esc_html_e( 'افزودن فیلد', 'kasebi-erp' ); ?></span>
                    </button>
                </div>
            </div>
        </div>
        <div class="nk-block">
                        <?php
            KERP_Helpers_Template::render_template(
            	'app/components/settings/hero.php',
            	[
            		'icon'        => 'icon ni ni-user-list',
            		'eyebrow'     => __( 'ساختار اطلاعات کارمند', 'kasebi-erp' ),
            		'title'       => __( 'فیلدهای سفارشی و محل نمایش', 'kasebi-erp' ),
            		'description' => __( 'هر فیلد می‌تواند در فرم افزودن کارمند، پروفایل، فیلترها و ستون‌های فهرست به‌صورت مستقل استفاده شود.', 'kasebi-erp' ),
            		'stats'       => [
            			[
            				'label' => __( 'کل فیلدها', 'kasebi-erp' ),
            				'value' => number_format_i18n( $total_count ),
            			],
            			[
            				'label' => __( 'فعال', 'kasebi-erp' ),
            				'value' => number_format_i18n( $active_count ),
            			],
            			[
            				'label' => __( 'در پروفایل', 'kasebi-erp' ),
            				'value' => number_format_i18n( $profile_count ),
            			],
            			[
            				'label' => __( 'قابل فیلتر', 'kasebi-erp' ),
            				'value' => number_format_i18n( $filter_count ),
            			],
            		],
            	]
            );
            ?>
        </div>
        <div class="nk-block">
			<?php if ( empty( $definitions ) ) : ?>
                                <?php
                KERP_Helpers_Template::render_template(
                	'app/components/settings/empty-state.php',
                	[
                		'icon'        => 'icon ni ni-property-add',
                		'title'       => __( 'هنوز فیلد اختصاصی تعریف نشده است', 'kasebi-erp' ),
                		'description' => __( 'برای ثبت اطلاعاتی مانند شماره قرارداد، مدرک تحصیلی یا سایر اطلاعات منابع انسانی، اولین فیلد اختصاصی را ایجاد کنید.', 'kasebi-erp' ),
                		'action'      => [ 'label' => __( 'افزودن اولین فیلد', 'kasebi-erp' ), 'icon' => 'icon ni ni-plus', 'class' => 'btn btn-primary open_populate_modal', 'attributes' => [ 'data-modal' => $modal_selector, 'data-modal-title' => __( 'افزودن فیلد اختصاصی', 'kasebi-erp' ), 'data-submit-text' => __( 'افزودن فیلد', 'kasebi-erp' ), 'data-populate' => wp_json_encode( $add_populate ) ] ],
                	]
                );
                ?>
			<?php else : ?>
                <div class="row g-gs kerp-settings-field-grid">
					<?php foreach ( $definitions as $field_key => $definition ) : ?>
						<?php
						$field_key         = sanitize_key( (string) ( $definition['key'] ?? $field_key ) );
						$field_label       = sanitize_text_field( (string) ( $definition['label'] ?? $field_key ) );
						$field_description = sanitize_text_field( (string) ( $definition['description'] ?? '' ) );
						$field_type        = sanitize_key( (string) ( $definition['type'] ?? 'text' ) );
						$field_placeholder = sanitize_text_field( (string) ( $definition['placeholder'] ?? '' ) );
						$field_class       = sanitize_text_field( (string) ( $definition['class'] ?? 'col-md-6' ) );
						$field_order       = (int) ( $definition['order'] ?? 100 );
						$field_active      = ! isset( $definition['active'] ) || ! empty( $definition['active'] );
						$field_on_create   = ! empty( $definition['show_on_create'] );
						$field_on_profile  = ! isset( $definition['show_on_profile'] ) || ! empty( $definition['show_on_profile'] );
						$field_filterable  = ! empty( $definition['filterable'] );
						$field_column      = ! empty( $definition['column'] );
						$field_options     = is_array( $definition['options'] ?? NULL ) ? $definition['options'] : [];
						$field_icon        = $field_type_icons[ $field_type ] ?? 'ni ni-property';
						$options_lines     = [];
						
						foreach ( $field_options as $option_key => $option_label ) {
							$option_key = sanitize_key( (string) $option_key );
							if ( $option_key === '' ) {
								continue;
							}
							$options_lines[] = $option_key . '=' . sanitize_text_field( (string) $option_label );
						}
						
						$options_text  = implode( "\n", $options_lines );
						$edit_populate = [
							'key'             => [
								'id'    => '#kerp-employee-field-key',
								'value' => $field_key,
								'type'  => 'no_change',
							],
							'label'           => [
								'id'    => '#kerp-employee-field-label',
								'value' => $field_label,
								'type'  => 'text',
							],
							'description'     => [
								'id'    => '#kerp-employee-field-description',
								'value' => $field_description,
								'type'  => 'text',
							],
							'type'            => [
								'id'    => '#kerp-employee-field-type',
								'value' => $field_type,
								'type'  => 'select',
							],
							'placeholder'     => [
								'id'    => '#kerp-employee-field-placeholder',
								'value' => $field_placeholder,
								'type'  => 'text',
							],
							'class'           => [
								'id'    => '#kerp-employee-field-class',
								'value' => $field_class,
								'type'  => 'select',
							],
							'options'         => [
								'id'    => '#kerp-employee-field-options',
								'value' => $options_text,
								'type'  => 'text',
							],
							'active'          => [
								'id'    => '#kerp-employee-field-active',
								'value' => $field_active ? '1' : '0',
								'type'  => 'switch',
							],
							'show_on_create'  => [
								'id'    => '#kerp-employee-field-show-on-create',
								'value' => $field_on_create ? '1' : '0',
								'type'  => 'switch',
							],
							'show_on_profile' => [
								'id'    => '#kerp-employee-field-show-on-profile',
								'value' => $field_on_profile ? '1' : '0',
								'type'  => 'switch',
							],
							'filterable'      => [
								'id'    => '#kerp-employee-field-filterable',
								'value' => $field_filterable ? '1' : '0',
								'type'  => 'switch',
							],
							'column'          => [
								'id'    => '#kerp-employee-field-column',
								'value' => $field_column ? '1' : '0',
								'type'  => 'switch',
							],
							'order'           => [
								'id'    => '#kerp-employee-field-order',
								'value' => $field_order,
								'type'  => 'text',
							],
						];
						?>
                        <?php
                        $usage = [];
                        if ( $field_on_create ) { $usage[] = [ 'icon' => 'icon ni ni-user-add', 'label' => __( 'فرم افزودن', 'kasebi-erp' ) ]; }
                        if ( $field_on_profile ) { $usage[] = [ 'icon' => 'icon ni ni-user-circle', 'label' => __( 'پروفایل', 'kasebi-erp' ) ]; }
                        if ( $field_filterable ) { $usage[] = [ 'icon' => 'icon ni ni-filter-alt', 'label' => __( 'فیلتر', 'kasebi-erp' ) ]; }
                        if ( $field_column ) { $usage[] = [ 'icon' => 'icon ni ni-view-cols', 'label' => __( 'ستون فهرست', 'kasebi-erp' ) ]; }
                        KERP_Helpers_Template::render_template(
                            'app/components/settings/field-card.php',
                            [
                                'icon'         => $field_icon . ' icon',
                                'label'        => $field_label,
                                'type_label'   => (string) ( $field_type_options[ $field_type ] ?? $field_type ),
                                'key'          => $field_key,
                                'active'       => $field_active,
                                'description'  => $field_description,
                                'usage'        => $usage,
                                'options'      => $field_options,
                                'column_label' => (string) ( $column_options[ $field_class ] ?? $field_class ),
                                'order'        => $field_order,
                                'placeholder'  => $field_placeholder,
                                'actions'      => [
                                    [
                                        'label'      => __( 'ویرایش', 'kasebi-erp' ),
                                        'icon'       => 'icon ni ni-edit',
                                        'class'      => 'edit_row_item',
                                        'attributes' => [
                                            'data-modal'       => $modal_selector,
                                            'data-modal-title' => __( 'ویرایش فیلد اختصاصی', 'kasebi-erp' ),
                                            'data-submit-text' => __( 'ذخیره تغییرات', 'kasebi-erp' ),
                                            'data-populate'    => wp_json_encode( $edit_populate ),
                                        ],
                                    ],
                                    [
                                        'label'          => __( 'حذف', 'kasebi-erp' ),
                                        'icon'           => 'icon ni ni-trash',
                                        'class'          => 'delete_db_item',
                                        'divider_before' => TRUE,
                                        'attributes'     => [
                                            'data-action'  => 'employees_delete_field',
                                            'data-page'    => '/erp/settings/employees/fields/',
                                            'data-key'     => $field_key,
                                            'data-item_id' => $field_key,
                                        ],
                                    ],
                                ],
                            ]
                        );
                        ?>
					<?php endforeach; ?>
                </div>
			<?php endif; ?>
        </div>
    </div>
<?php
KERP_Helpers_Template::render_modal(
	[
		'id'     => $modal_id,
		'title'  => __( 'افزودن یا ویرایش فیلد اختصاصی', 'kasebi-erp' ),
		'action' => 'employees_save_fields',
		'page'   => '/erp/settings/employees/fields/',
		'button' => __( 'ذخیره', 'kasebi-erp' ),
		'size'   => 'lg',
		'fields' => [
			[
				'id'          => 'kerp-employee-field-key',
				'name'        => 'field[key]',
				'label'       => __( 'کلید فیلد', 'kasebi-erp' ),
				'description' => __( 'کلید انگلیسی یکتا؛ همین مقدار به‌عنوان کلید متا استفاده می‌شود.', 'kasebi-erp' ),
				'type'        => 'text',
				'class'       => 'col-md-6',
				'value'       => '',
			],
			[
				'id'    => 'kerp-employee-field-label',
				'name'  => 'field[label]',
				'label' => __( 'عنوان فیلد', 'kasebi-erp' ),
				'type'  => 'text',
				'class' => 'col-md-6',
				'value' => '',
			],
			[
				'id'    => 'kerp-employee-field-description',
				'name'  => 'field[description]',
				'label' => __( 'توضیحات', 'kasebi-erp' ),
				'type'  => 'textarea',
				'class' => 'col-12',
				'rows'  => 3,
				'value' => '',
			],
			[
				'id'      => 'kerp-employee-field-type',
				'name'    => 'field[type]',
				'label'   => __( 'نوع فیلد', 'kasebi-erp' ),
				'type'    => 'select',
				'class'   => 'col-md-6',
				'options' => $field_type_options,
				'value'   => 'text',
			],
			[
				'id'      => 'kerp-employee-field-class',
				'name'    => 'field[class]',
				'label'   => __( 'عرض فیلد', 'kasebi-erp' ),
				'type'    => 'select',
				'class'   => 'col-md-6',
				'options' => $column_options,
				'value'   => 'col-md-6',
			],
			[
				'id'    => 'kerp-employee-field-placeholder',
				'name'  => 'field[placeholder]',
				'label' => __( 'متن جایگزین', 'kasebi-erp' ),
				'type'  => 'text',
				'class' => 'col-12',
				'value' => '',
			],
			[
				'id'            => 'kerp-employee-field-options',
				'name'          => 'field[options]',
				'label'         => __( 'گزینه‌ها', 'kasebi-erp' ),
				'description'   => __( 'هر گزینه را در یک خط و به شکل key=عنوان وارد کنید.', 'kasebi-erp' ),
				'type'          => 'textarea',
				'class'         => 'col-12',
				'rows'          => 6,
				'placeholder'   => "bachelor=کارشناسی\nmaster=کارشناسی ارشد",
				'value'         => '',
				'conditional'   => TRUE,
				'cond_meta'     => 'field[type]',
				'cond_operator' => '==',
				'cond_expected' => wp_json_encode( [ 'select', 'radio', 'checkbox' ] ),
			],
			[
				'id'    => 'kerp-employee-field-order',
				'name'  => 'field[order]',
				'label' => __( 'ترتیب نمایش', 'kasebi-erp' ),
				'type'  => 'number',
				'class' => 'col-md-6',
				'value' => 100,
			],
			[
				'id'          => 'kerp-employee-field-active-empty',
				'name'        => 'field[active]',
				'type'        => 'hidden',
				'input_class' => 'no_clear',
				'value'       => '0',
			],
			[
				'id'    => 'kerp-employee-field-active',
				'name'  => 'field[active]',
				'label' => __( 'فعال باشد', 'kasebi-erp' ),
				'type'  => 'switch',
				'class' => 'col-md-6',
				'value' => '1',
			],
			[
				'id'          => 'kerp-employee-field-show-on-create-empty',
				'name'        => 'field[show_on_create]',
				'type'        => 'hidden',
				'input_class' => 'no_clear',
				'value'       => '0',
			],
			[
				'id'    => 'kerp-employee-field-show-on-create',
				'name'  => 'field[show_on_create]',
				'label' => __( 'در فرم افزودن نمایش داده شود', 'kasebi-erp' ),
				'type'  => 'switch',
				'class' => 'col-md-6',
				'value' => '0',
			],
			[
				'id'          => 'kerp-employee-field-show-on-profile-empty',
				'name'        => 'field[show_on_profile]',
				'type'        => 'hidden',
				'input_class' => 'no_clear',
				'value'       => '0',
			],
			[
				'id'    => 'kerp-employee-field-show-on-profile',
				'name'  => 'field[show_on_profile]',
				'label' => __( 'در پروفایل نمایش داده شود', 'kasebi-erp' ),
				'type'  => 'switch',
				'class' => 'col-md-6',
				'value' => '1',
			],
			[
				'id'          => 'kerp-employee-field-filterable-empty',
				'name'        => 'field[filterable]',
				'type'        => 'hidden',
				'input_class' => 'no_clear',
				'value'       => '0',
			],
			[
				'id'    => 'kerp-employee-field-filterable',
				'name'  => 'field[filterable]',
				'label' => __( 'در فیلترهای فهرست نمایش داده شود', 'kasebi-erp' ),
				'type'  => 'switch',
				'class' => 'col-md-6',
				'value' => '0',
			],
			[
				'id'          => 'kerp-employee-field-column-empty',
				'name'        => 'field[column]',
				'type'        => 'hidden',
				'input_class' => 'no_clear',
				'value'       => '0',
			],
			[
				'id'    => 'kerp-employee-field-column',
				'name'  => 'field[column]',
				'label' => __( 'در ستون‌های فهرست نمایش داده شود', 'kasebi-erp' ),
				'type'  => 'switch',
				'class' => 'col-md-6',
				'value' => '0',
			],
		],
	]
);
