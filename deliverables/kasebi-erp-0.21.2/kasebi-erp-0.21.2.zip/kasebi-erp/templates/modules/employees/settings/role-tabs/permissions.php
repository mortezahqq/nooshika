<?php

defined( 'ABSPATH' ) || exit;

/**
 * @var array  $role
 * @var string $role_key
 * @var array  $tab
 */

$group               = isset( $tab['group'] ) && is_array( $tab['group'] ) ? $tab['group'] : [];
$group_key           = sanitize_key( (string) ( $group['key'] ?? $tab['key'] ?? '' ) );
$blocks              = isset( $group['blocks'] ) && is_array( $group['blocks'] ) ? $group['blocks'] : [];
$permissions_service = KERP_Modules_Employees_Permissions::instance();
$defaults            = $permissions_service->get_defaults( $role_key );
$current_url         = add_query_arg(
	'tab',
	$group_key,
	KERP_Modules_Employees_Roles::instance()->get_url( $role_key )
);
$accordion_id        = 'kerp-role-permissions-' . md5( $role_key . '-' . $group_key );
?>
<form class="modal_form kerp-role-permissions"
      data-action="employees_save_role_permissions"
      data-page="<?php echo esc_attr( $current_url ); ?>">
    <input type="hidden" class="no_clear" data-for="role_key" value="<?php echo esc_attr( $role_key ); ?>">
    <input type="hidden" class="no_clear" data-for="group_key" value="<?php echo esc_attr( $group_key ); ?>">

    <div class="kerp-role-permissions__head">
        <div class="kerp-role-permissions__head-main">
            <div class="nk-block-head-content align-self-start d-lg-none">
                <a href="#" class="toggle btn btn-icon btn-trigger" data-target="employeeRoleAside">
                    <em class="icon ni ni-menu-alt-r"></em>
                </a>
            </div>

            <div class="kerp-role-permissions__heading">
                <div class="kerp-role-permissions__heading-icon">
                    <em class="icon ni ni-shield-check"></em>
                </div>
                <div>
                    <h5><?php echo esc_html( (string) ( $group['label'] ?? $group_key ) ); ?></h5>
                    <p><?php esc_html_e( 'دسترسی‌های پیش‌فرض این گروه برای کارکنانی که این نقش را دریافت می‌کنند.', 'kasebi-erp' ); ?></p>
                </div>
            </div>
        </div>

        <button type="button" class="btn btn-primary btn-sm submit_modal_form kerp-role-permissions__save">
            <em class="icon ni ni-save"></em>
            <span><?php esc_html_e( 'ذخیره تغییرات', 'kasebi-erp' ); ?></span>
        </button>
    </div>

    <div class="kerp-permissions-accordion" id="<?php echo esc_attr( $accordion_id ); ?>">
		<?php $block_position = 0; ?>
		<?php foreach ( $blocks as $block_index => $block ) : ?>
			<?php
			$block_key         = sanitize_key( (string) $block_index );
			$block_permissions = (array) ( $block['permissions'] ?? [] );
			$selected_count    = 0;
			
			foreach ( $block_permissions as $permission ) {
				if ( $permissions_service->is_permission_selected( (array) $permission, $defaults ) ) {
					$selected_count ++;
				}
			}
			
			$collapse_id = 'kerp-permission-block-' . md5( $role_key . '-' . $group_key . '-' . $block_key );
			$is_open     = $block_position === 0;
			?>
            <div class="kerp-permissions-accordion__item">
                <button type="button"
                        class="kerp-permissions-accordion__toggle<?php echo $is_open ? '' : ' collapsed'; ?>"
                        data-bs-toggle="collapse"
                        data-bs-target="#<?php echo esc_attr( $collapse_id ); ?>"
                        aria-expanded="<?php echo $is_open ? 'true' : 'false'; ?>"
                        aria-controls="<?php echo esc_attr( $collapse_id ); ?>">
					<span class="kerp-permissions-accordion__icon">
						<em class="<?php echo esc_attr( (string) ( $block['icon'] ?? 'ni ni-lock-alt' ) ); ?> icon"></em>
					</span>

                    <span class="kerp-permissions-accordion__title-wrap">
						<strong><?php echo esc_html( (string) ( $block['label'] ?? $block_key ) ); ?></strong>
						<?php if ( ! empty( $block['description'] ) ) : ?>
                            <small><?php echo esc_html( (string) $block['description'] ); ?></small>
						<?php endif; ?>
					</span>

                    <span class="kerp-permissions-accordion__meta">
						<span class="kerp-permissions-accordion__count">
							<?php
							printf(
								esc_html__( '%1$s از %2$s فعال', 'kasebi-erp' ),
								esc_html( number_format_i18n( $selected_count ) ),
								esc_html( number_format_i18n( count( $block_permissions ) ) )
							);
							?>
						</span>
						<em class="icon ni ni-chevron-down kerp-permissions-accordion__chevron"></em>
					</span>
                </button>

                <div id="<?php echo esc_attr( $collapse_id ); ?>"
                     class="collapse<?php echo $is_open ? ' show' : ''; ?>">
                    <div class="kerp-permissions-accordion__body">
						<?php if ( empty( $block_permissions ) ) : ?>
                            <div class="kerp-role-permissions__empty">
                                <em class="icon ni ni-lock-alt"></em>
                                <span><?php esc_html_e( 'دسترسی‌ای برای این بخش تعریف نشده است.', 'kasebi-erp' ); ?></span>
                            </div>
						<?php else : ?>
                            <div class="kerp-permission-list">
								<?php foreach ( $block_permissions as $permission_id => $permission ) : ?>
									<?php
									$permission_id  = sanitize_key( (string) $permission_id );
									$permission_key = (string) ( $permission['key'] ?? '' );
									$selected       = $permissions_service->is_permission_selected( $permission, $defaults );
									$scope_options  = $permissions_service->get_scope_options( $permission );
									$selected_scope = $permissions_service->get_selected_scope( $permission, $defaults );
									
									if ( $selected_scope === '' ) {
										$selected_scope = $permissions_service->get_default_scope( $permission );
									}
									
									$field_id = 'kerp-role-permission-' . md5( $role_key . '-' . $group_key . '-' . $permission_id );
									$scope_id = $field_id . '-scope';
									?>
                                    <div class="kerp-permission-item<?php echo $selected ? ' is-selected' : ''; ?>">
                                        <div class="kerp-permission-item__main">
                                            <div
                                                class="custom-control custom-control-sm custom-switch<?php echo $selected ? ' checked' : ''; ?>">
                                                <input type="checkbox"
                                                       id="<?php echo esc_attr( $field_id ); ?>"
                                                       class="custom-control-input no_clear"
                                                       data-for="permission_ids"
                                                       value="<?php echo esc_attr( $permission_id ); ?>"
													<?php checked( $selected ); ?>>
                                                <label class="custom-control-label"
                                                       for="<?php echo esc_attr( $field_id ); ?>">
													<?php echo esc_html( (string) ( $permission['label'] ?? $permission_key ) ); ?>
                                                </label>
                                            </div>
											
											<?php if ( ! empty( $permission['description'] ) ) : ?>
                                                <p><?php echo esc_html( (string) $permission['description'] ); ?></p>
											<?php endif; ?>
                                        </div>
										
										<?php if ( ! empty( $scope_options ) ) : ?>
                                            <div class="kerp-permission-item__scope">
                                                <label for="<?php echo esc_attr( $scope_id ); ?>">
													<?php esc_html_e( 'دامنه دسترسی', 'kasebi-erp' ); ?>
                                                </label>
                                                <select id="<?php echo esc_attr( $scope_id ); ?>"
                                                        class="form-select no_clear"
                                                        data-for="permission_scopes[<?php echo esc_attr( $permission_id ); ?>]">
													<?php foreach ( $scope_options as $scope_key => $scope_label ) : ?>
                                                        <option
                                                            value="<?php echo esc_attr( $scope_key ); ?>" <?php selected( $selected_scope, $scope_key ); ?>>
															<?php echo esc_html( $scope_label ); ?>
                                                        </option>
													<?php endforeach; ?>
                                                </select>
                                            </div>
										<?php endif; ?>
                                    </div>
								<?php endforeach; ?>
                            </div>
						<?php endif; ?>
                    </div>
                </div>
            </div>
			<?php $block_position ++; ?>
		<?php endforeach; ?>
    </div>
</form>
