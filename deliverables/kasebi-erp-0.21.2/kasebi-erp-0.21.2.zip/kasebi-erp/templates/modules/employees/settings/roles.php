<?php

defined( 'ABSPATH' ) || exit;

$roles_service       = KERP_Modules_Employees_Roles::instance();
$permissions_service = KERP_Modules_Employees_Permissions::instance();
$roles               = $roles_service->get_all();
$can_manage_roles    = kerp_can( 'employees.access.manage', 'action' );

$total_roles       = count( $roles );
$active_roles      = 0;
$total_employees   = 0;
$total_permissions = 0;
$prepared_roles    = [];

foreach ( $roles as $role_key => $role ) {
	$role_key            = sanitize_key( (string) $role_key );
	$employee_count      = (int) $roles_service->count_employees( $role_key );
	$default_permissions = $permissions_service->get_defaults( $role_key );
	$view_permissions    = isset( $default_permissions['view'] ) && is_array( $default_permissions['view'] ) ? $default_permissions['view'] : [];
	$action_permissions  = isset( $default_permissions['action'] ) && is_array( $default_permissions['action'] ) ? $default_permissions['action'] : [];
	$permissions_count   = count( $view_permissions ) + count( $action_permissions );
	$role_active         = ! empty( $role['active'] );
	
	$active_roles      += $role_active ? 1 : 0;
	$total_employees   += $employee_count;
	$total_permissions += $permissions_count;
	
	$prepared_roles[ $role_key ] = [
		'label'             => sanitize_text_field( (string) ( $role['label'] ?? $role_key ) ),
		'icon'              => trim( (string) ( $role['icon'] ?? 'uik-r fa-id-badge' ) ),
		'active'            => $role_active,
		'order'             => (int) ( $role['order'] ?? 100 ),
		'url'               => (string) $roles_service->get_url( $role_key ),
		'employee_count'    => $employee_count,
		'permissions_count' => $permissions_count,
	];
}
?>
    <div class="kerp-employees-roles-settings">
        <div class="nk-block-head nk-block-head-sm">
            <div class="nk-block-between g-3">
                <div class="nk-block-head-content">
                    <h3 class="nk-block-title page-title"><?php esc_html_e( 'نقش‌های سازمانی', 'kasebi-erp' ); ?></h3>
                    <div class="nk-block-des text-soft">
                        <p><?php esc_html_e( 'ساختار نقش‌های سازمانی، اعضای هر نقش و دسترسی‌های پیش‌فرض آن‌ها را مدیریت کنید.', 'kasebi-erp' ); ?></p>
                    </div>
                </div>
				<?php if ( $can_manage_roles ) : ?>
                    <div class="nk-block-head-content">
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                data-bs-target="#addEmployeeRoleModal">
                            <em class="icon ni ni-plus"></em>
                            <span><?php esc_html_e( 'افزودن نقش', 'kasebi-erp' ); ?></span>
                        </button>
                    </div>
				<?php endif; ?>
            </div>
        </div>

        <div class="nk-block">
                        <?php
            KERP_Helpers_Template::render_template(
            	'app/components/settings/hero.php',
            	[
            		'icon'        => 'icon ni ni-user-list',
            		'eyebrow'     => __( 'ساختار دسترسی کارکنان', 'kasebi-erp' ),
            		'title'       => __( 'نقش‌ها و دسترسی‌های سازمانی', 'kasebi-erp' ),
            		'description' => __( 'هر نقش مجموعه‌ای از دسترسی‌های پیش‌فرض دارد و کارکنان می‌توانند بر اساس مسئولیت سازمانی به آن متصل شوند.', 'kasebi-erp' ),
            		'stats'       => [
            			[
            				'label' => __( 'کل نقش‌ها', 'kasebi-erp' ),
            				'value' => number_format_i18n( $total_roles ),
            			],
            			[
            				'label' => __( 'نقش‌های فعال', 'kasebi-erp' ),
            				'value' => number_format_i18n( $active_roles ),
            			],
            			[
            				'label' => __( 'کارکنان منتسب', 'kasebi-erp' ),
            				'value' => number_format_i18n( $total_employees ),
            			],
            			[
            				'label' => __( 'دسترسی‌های پیش‌فرض', 'kasebi-erp' ),
            				'value' => number_format_i18n( $total_permissions ),
            			],
            		],
            	]
            );
            ?>
        </div>

        <div class="nk-block">
			<?php if ( empty( $prepared_roles ) ) : ?>
                                <?php
                KERP_Helpers_Template::render_template(
                	'app/components/settings/empty-state.php',
                	[
                		'icon'        => 'icon ni ni-user-list',
                		'title'       => __( 'هنوز نقش سازمانی تعریف نشده است', 'kasebi-erp' ),
                		'description' => __( 'برای گروه‌بندی کارکنان و تعریف دسترسی‌های پیش‌فرض، اولین نقش سازمانی را ایجاد کنید.', 'kasebi-erp' ),
                		'action'      => $can_manage_roles ? [ 'label' => __( 'افزودن اولین نقش', 'kasebi-erp' ), 'icon' => 'icon ni ni-plus', 'class' => 'btn btn-primary', 'attributes' => [ 'data-bs-toggle' => 'modal', 'data-bs-target' => '#addEmployeeRoleModal' ] ] : [],
                	]
                );
                ?>
			<?php else : ?>
                <div class="row g-gs kerp-settings-item-grid">
					<?php foreach ( $prepared_roles as $role_key => $role ) : ?>
                                                <?php
                        KERP_Helpers_Template::render_template(
                        	'app/components/settings/item-card.php',
                        	[
                        		'class'  => 'kerp-employee-role-card',
                        		'icon'   => $role['icon'],
                        		'label'  => $role['label'],
                        		'key'    => $role_key,
                        		'active' => $role['active'],
                        		'meta'   => [
                        			[ 'icon' => 'icon ni ni-users', 'label' => __( 'کارکنان', 'kasebi-erp' ), 'value' => number_format_i18n( $role['employee_count'] ) ],
                        			[ 'icon' => 'icon ni ni-shield-check', 'label' => __( 'دسترسی پیش‌فرض', 'kasebi-erp' ), 'value' => number_format_i18n( $role['permissions_count'] ) ],
                        		],
                        		'footer' => [
                        			[ 'icon' => 'icon ni ni-sort-v', 'text' => sprintf( __( 'ترتیب: %s', 'kasebi-erp' ), number_format_i18n( $role['order'] ) ) ],
                        			[ 'type' => 'link', 'icon' => 'icon ni ni-arrow-right', 'text' => __( 'مدیریت نقش', 'kasebi-erp' ), 'href' => home_url( $role['url'] ), 'class' => 'page_activator text-primary', 'icon_after' => TRUE, 'attributes' => [ 'data-url' => $role['url'] ] ],
                        		],
                        	]
                        );
                        ?>
					<?php endforeach; ?>
                </div>
			<?php endif; ?>
        </div>
    </div>
<?php
if ( $can_manage_roles ) {
	KERP_Helpers_Template::render_modal(
		[
			'id'     => 'addEmployeeRoleModal',
			'title'  => __( 'افزودن نقش سازمانی', 'kasebi-erp' ),
			'action' => 'employees_create_role',
			'page'   => '/erp/settings/employees/roles/',
			'button' => __( 'ایجاد نقش', 'kasebi-erp' ),
			'size'   => 'lg',
			'fields' => [
				[
					'id' => 'kerp-employee-role-default-page',
					'name' => 'role[default_page]',
					'label' => __( 'صفحه پیش‌فرض ERP', 'kasebi-erp' ),
					'type' => 'select',
					'class' => 'col-12',
					'placeholder' => __( 'پیش‌فرض سامانه (میزکار)', 'kasebi-erp' ),
					'options' => KERP_App::instance()->get_default_page_options(),
				],
				[
					'id'          => 'kerp-employee-role-key',
					'name'        => 'role[key]',
					'label'       => __( 'کلید نقش', 'kasebi-erp' ),
					'description' => __( 'یک کلید انگلیسی یکتا مانند marketing-manager وارد کنید.', 'kasebi-erp' ),
					'type'        => 'text',
					'class'       => 'col-md-6',
					'required'    => TRUE,
				],
				[
					'id'       => 'kerp-employee-role-label',
					'name'     => 'role[label]',
					'label'    => __( 'عنوان نقش', 'kasebi-erp' ),
					'type'     => 'text',
					'class'    => 'col-md-6',
					'required' => TRUE,
				],
				[
					'id'    => 'kerp-employee-role-icon',
					'name'  => 'role[icon]',
					'label' => __( 'کلاس آیکون', 'kasebi-erp' ),
					'type'  => 'text',
					'class' => 'col-md-8',
					'value' => 'uik-r fa-id-badge',
				],
				[
					'id'    => 'kerp-employee-role-order',
					'name'  => 'role[order]',
					'label' => __( 'ترتیب', 'kasebi-erp' ),
					'type'  => 'number',
					'class' => 'col-md-4',
					'value' => 100,
				],
				[
					'id'          => 'kerp-employee-role-active-empty',
					'name'        => 'role[active]',
					'type'        => 'hidden',
					'input_class' => 'no_clear',
					'value'       => '0',
				],
				[
					'id'    => 'kerp-employee-role-active',
					'name'  => 'role[active]',
					'label' => __( 'نقش فعال باشد', 'kasebi-erp' ),
					'type'  => 'switch',
					'class' => 'col-12',
					'value' => 1,
				],
			],
		]
	);
}
