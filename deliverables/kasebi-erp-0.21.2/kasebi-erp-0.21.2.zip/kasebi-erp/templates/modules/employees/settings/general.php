<?php

defined( 'ABSPATH' ) || exit;

$settings_service = KERP_Modules_Employees_Settings::instance();
$roles_service    = KERP_Modules_Employees_Roles::instance();
$fields_service   = KERP_Modules_Employees_Fields::instance();

$singular_label     = $settings_service->get_singular_label();
$plural_label       = $settings_service->get_plural_label();
$employee_code      = trim( (string) $settings_service->get( 'employee_code_prefix', 'EMP-' ) );
$auto_employee_code = (bool) $settings_service->get( 'auto_employee_code', TRUE );
$default_role_key   = sanitize_key( (string) $settings_service->get( 'default_role_key', 'employee' ) );
$default_status     = sanitize_key( (string) $settings_service->get( 'default_status', 'active' ) );
$default_per_page   = max( 1, min( 100, (int) $settings_service->get( 'default_per_page', 20 ) ) );
$role_options       = $roles_service->get_options();
$status_options     = $fields_service->statuses();
$current_role       = $roles_service->get( $default_role_key );
$current_url        = '/erp/settings/employees/';

if ( $default_role_key !== '' && ! isset( $role_options[ $default_role_key ] ) && is_array( $current_role ) ) {
	$role_options[ $default_role_key ] = sprintf(
		__( '%s — غیرفعال', 'kasebi-erp' ),
		(string) ( $current_role['label'] ?? $default_role_key )
	);
}

$default_role_label    = (string) ( $role_options[ $default_role_key ] ?? __( 'تعیین نشده', 'kasebi-erp' ) );
$default_status_label  = (string) ( $status_options[ $default_status ] ?? __( 'تعیین نشده', 'kasebi-erp' ) );
$employee_code_preview = $employee_code !== ''
	? $employee_code . '1024'
	: '1024';
?>
<form id="kerp-employees-general-settings-form"
      class="modal_form kerp-employees-settings"
      data-action="employees_save_settings"
      data-page="<?php echo esc_attr( $current_url ); ?>">
    <div class="nk-block-head nk-block-head-sm">
        <div class="nk-block-between">
            <div class="nk-block-head-content">
                <h3 class="nk-block-title page-title">
					<?php
					printf(
						esc_html__( 'تنظیمات عمومی %s', 'kasebi-erp' ),
						esc_html( $plural_label )
					);
					?>
                </h3>
                <div class="nk-block-des text-soft">
                    <p><?php esc_html_e( 'نام‌گذاری، کد پرسنلی و مقادیر پیش‌فرض هنگام ایجاد کارمند را مدیریت کنید.', 'kasebi-erp' ); ?></p>
                </div>
            </div>
            <div class="nk-block-head-content">
                <button type="button" class="btn btn-primary submit_modal_form">
                    <em class="icon ni ni-save"></em>
                    <span><?php esc_html_e( 'ذخیره تغییرات', 'kasebi-erp' ); ?></span>
                </button>
            </div>
        </div>
    </div>

    <div class="nk-block">
                <?php
        KERP_Helpers_Template::render_template(
        	'app/components/settings/hero.php',
        	[
        		'icon'        => 'uik-r fa-id-badge',
        		'eyebrow'     => __( 'ماژول کارکنان', 'kasebi-erp' ),
        		'title'       => $plural_label,
        		'description' => __( 'تنظیمات این صفحه روی فرم افزودن، فهرست و کدگذاری کارکنان اعمال می‌شوند.', 'kasebi-erp' ),
        		'stats'       => [
        			[
        				'label' => __( 'نقش پیش‌فرض', 'kasebi-erp' ),
        				'value' => $default_role_label,
        			],
        			[
        				'label' => __( 'وضعیت پیش‌فرض', 'kasebi-erp' ),
        				'value' => $default_status_label,
        			],
        			[
        				'label' => __( 'نمونه کد', 'kasebi-erp' ),
        				'value' => $employee_code_preview,
        				'tag'   => 'code',
        				'id'    => 'kerp-employee-code-preview',
        			],
        		],
        	]
        );
        ?>
    </div>

    <div class="nk-block">
        <div class="row g-gs">
            <div class="col-xl-8">
                <div class="card card-bordered mb-4">
                    <div class="card-inner border-bottom">
                        <div class="card-title-group align-start">
                            <div class="card-title">
                                <h6 class="title">
                                    <em class="icon ni ni-text-a me-1"></em>
									<?php esc_html_e( 'نام‌گذاری و نمایش', 'kasebi-erp' ); ?>
                                </h6>
                                <p class="text-soft"><?php esc_html_e( 'عنوان‌هایی که در منوها، فرم‌ها و پیام‌های سیستم نمایش داده می‌شوند.', 'kasebi-erp' ); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="card-inner">
                        <div class="row g-4">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label" for="kerp-employees-singular-label">
										<?php esc_html_e( 'عنوان مفرد', 'kasebi-erp' ); ?>
                                    </label>
                                    <div class="form-control-wrap">
                                        <div class="form-icon form-icon-right">
                                            <em class="icon ni ni-user"></em>
                                        </div>
                                        <input type="text"
                                               id="kerp-employees-singular-label"
                                               class="form-control no_clear"
                                               data-for="settings[singular_label]"
                                               data-req="1"
                                               value="<?php echo esc_attr( $singular_label ); ?>">
                                    </div>
                                    <div
                                        class="form-note"><?php esc_html_e( 'مثال: کارمند، همکار یا کارشناس', 'kasebi-erp' ); ?></div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label" for="kerp-employees-plural-label">
										<?php esc_html_e( 'عنوان جمع', 'kasebi-erp' ); ?>
                                    </label>
                                    <div class="form-control-wrap">
                                        <div class="form-icon form-icon-right">
                                            <em class="icon ni ni-users"></em>
                                        </div>
                                        <input type="text"
                                               id="kerp-employees-plural-label"
                                               class="form-control no_clear"
                                               data-for="settings[plural_label]"
                                               data-req="1"
                                               value="<?php echo esc_attr( $plural_label ); ?>">
                                    </div>
                                    <div
                                        class="form-note"><?php esc_html_e( 'مثال: کارمندان، همکاران یا کارشناسان', 'kasebi-erp' ); ?></div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label" for="kerp-employees-per-page">
										<?php esc_html_e( 'تعداد در هر صفحه', 'kasebi-erp' ); ?>
                                    </label>
                                    <div class="form-control-wrap">
                                        <div class="form-icon form-icon-right">
                                            <em class="icon ni ni-list"></em>
                                        </div>
                                        <input type="number"
                                               id="kerp-employees-per-page"
                                               class="form-control number_type no_clear"
                                               data-for="settings[default_per_page]"
                                               min="1"
                                               max="100"
                                               value="<?php echo esc_attr( $default_per_page ); ?>">
                                    </div>
                                    <div
                                        class="form-note"><?php esc_html_e( 'بین ۱ تا ۱۰۰ کارمند در هر صفحه', 'kasebi-erp' ); ?></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card card-bordered">
                    <div class="card-inner border-bottom">
                        <div class="card-title-group align-start">
                            <div class="card-title">
                                <h6 class="title">
                                    <em class="icon ni ni-hash me-1"></em>
									<?php esc_html_e( 'کد پرسنلی', 'kasebi-erp' ); ?>
                                </h6>
                                <p class="text-soft"><?php esc_html_e( 'الگوی تولید کد پرسنلی برای کارکنان جدید را تعیین کنید.', 'kasebi-erp' ); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="card-inner">
                        <div class="row g-4 align-items-end">
                            <div class="col-md-7">
                                <div class="form-group">
                                    <label class="form-label" for="kerp-employee-code-prefix">
										<?php esc_html_e( 'پیشوند کد پرسنلی', 'kasebi-erp' ); ?>
                                    </label>
                                    <div class="form-control-wrap">
                                        <div class="form-icon form-icon-right">
                                            <em class="icon ni ni-code"></em>
                                        </div>
                                        <input type="text"
                                               id="kerp-employee-code-prefix"
                                               class="form-control no_clear"
                                               data-for="settings[employee_code_prefix]"
                                               value="<?php echo esc_attr( $employee_code ); ?>">
                                    </div>
                                    <div class="form-note">
										<?php esc_html_e( 'نمونه خروجی:', 'kasebi-erp' ); ?>
                                        <code
                                            class="ms-1 kerp-employee-code-preview"><?php echo esc_html( $employee_code_preview ); ?></code>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-5">
                                <div class="kerp-settings-switch">
                                    <div class="kerp-settings-switch__content">
                                        <div class="kerp-settings-switch__icon">
                                            <em class="kik fa-magic-wand-01 icon"></em>
                                        </div>
                                        <div>
                                            <strong><?php esc_html_e( 'تولید خودکار کد', 'kasebi-erp' ); ?></strong>
                                            <span><?php esc_html_e( 'برای کارکنان جدید کد ساخته شود.', 'kasebi-erp' ); ?></span>
                                        </div>
                                    </div>
                                    <div class="custom-control custom-switch">
                                        <input type="checkbox"
                                               id="kerp-auto-employee-code"
                                               class="custom-control-input no_clear"
                                               data-for="settings[auto_employee_code]"
                                               value="1"
											<?php checked( $auto_employee_code ); ?>>
                                        <label class="custom-control-label" for="kerp-auto-employee-code"></label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-4">
                <div class="card card-bordered h-100">
                    <div class="card-inner border-bottom">
                        <div class="card-title-group align-start">
                            <div class="card-title">
                                <h6 class="title">
                                    <em class="icon ni ni-setting-alt me-1"></em>
									<?php esc_html_e( 'پیش‌فرض کارمند جدید', 'kasebi-erp' ); ?>
                                </h6>
                                <p class="text-soft"><?php esc_html_e( 'این مقادیر هنگام باز شدن فرم افزودن کارمند انتخاب می‌شوند.', 'kasebi-erp' ); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="card-inner">
                        <div class="form-group">
                            <label class="form-label" for="kerp-employees-default-role">
								<?php esc_html_e( 'نقش سازمانی پیش‌فرض', 'kasebi-erp' ); ?>
                            </label>
                            <div class="form-control-wrap">
                                <select id="kerp-employees-default-role"
                                        class="form-select js-select2 no_clear"
                                        data-for="settings[default_role_key]"
                                        data-search="on">
									<?php foreach ( $role_options as $role_key => $role_label ) : ?>
                                        <option value="<?php echo esc_attr( $role_key ); ?>"
											<?php selected( $default_role_key, $role_key ); ?>>
											<?php echo esc_html( $role_label ); ?>
                                        </option>
									<?php endforeach; ?>
                                </select>
                            </div>
                        </div>

                        <div class="form-group mt-4">
                            <label class="form-label" for="kerp-employees-default-status">
								<?php esc_html_e( 'وضعیت همکاری پیش‌فرض', 'kasebi-erp' ); ?>
                            </label>
                            <div class="form-control-wrap">
                                <select id="kerp-employees-default-status"
                                        class="form-select js-select2 no_clear"
                                        data-for="settings[default_status]">
									<?php foreach ( $status_options as $status_key => $status_label ) : ?>
                                        <option value="<?php echo esc_attr( $status_key ); ?>"
											<?php selected( $default_status, $status_key ); ?>>
											<?php echo esc_html( $status_label ); ?>
                                        </option>
									<?php endforeach; ?>
                                </select>
                            </div>
                        </div>

                        <div class="alert alert-light alert-icon mt-4 mb-0">
                            <em class="icon ni ni-info-fill"></em>
                            <div>
                                <strong><?php esc_html_e( 'نکته', 'kasebi-erp' ); ?></strong>
                                <p class="mb-0">
									<?php esc_html_e( 'تغییر این مقادیر فقط روی کارکنان جدید اثر دارد و اطلاعات کارکنان قبلی را تغییر نمی‌دهد.', 'kasebi-erp' ); ?>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>