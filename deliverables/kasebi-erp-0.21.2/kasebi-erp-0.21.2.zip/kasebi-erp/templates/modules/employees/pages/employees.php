<?php

defined( 'ABSPATH' ) || exit;

/**
 * @var array $page_context
 */

$page_context = isset( $page_context ) && is_array( $page_context )
	? $page_context
	: [];
$query_args   = isset( $page_context['query'] ) && is_array( $page_context['query'] )
	? $page_context['query']
	: [];

$settings           = KERP_Modules_Employees_Settings::instance();
$customer_plural_label = KERP_Modules_Customers_Settings::instance()->get_plural_label();
$roles              = KERP_Modules_Employees_Roles::instance();
$fields             = KERP_Modules_Employees_Fields::instance();
$employees_query    = KERP_Modules_Employees_Query::instance();
$candidates_service = KERP_Modules_Employees_Candidates::instance();
$can_create         = kerp_can( 'employees.create', 'action' );
$section            = sanitize_key( (string) ( $query_args['section'] ?? 'employees' ) );
$section            = $section === 'available' && $can_create ? 'available' : 'employees';
$employees_url      = '/erp/employees/';
$available_url      = '/erp/employees/?section=available';
$candidate_count    = 0;

if ( $section === 'available' ) {
	$candidate_search = sanitize_text_field( (string) ( $query_args['search'] ?? '' ) );
	$result = $candidates_service->find(
		[
			'per_page'    => max( 1, min( 50, absint( $query_args['per_page'] ?? 12 ) ) ),
			'page_number' => max( 1, absint( $query_args['page_number'] ?? 1 ) ),
			'search'      => $candidate_search,
			'wp_role'     => sanitize_key( (string) ( $query_args['wp_role'] ?? '' ) ),
		]
	);
	$candidate_count = $candidate_search === '' && empty( $result['request_args']['wp_role'] )
		? (int) $result['total']
		: $candidates_service->get_count();
} else {
	$candidate_count = $can_create ? $candidates_service->get_count() : 0;
	$result = $employees_query->find(
		[
			'per_page'    => max( 1, min( 50, absint( $query_args['per_page'] ?? $settings->get( 'default_per_page', 20 ) ) ) ),
			'page_number' => max( 1, absint( $query_args['page_number'] ?? 1 ) ),
			'search'      => sanitize_text_field( (string) ( $query_args['search'] ?? '' ) ),
			'role_key'    => sanitize_key( (string) ( $query_args['role_key'] ?? '' ) ),
			'status'      => sanitize_key( (string) ( $query_args['status'] ?? '' ) ),
		]
	);
}

$request_args = isset( $result['request_args'] ) && is_array( $result['request_args'] )
	? $result['request_args']
	: [];
?>
<div class="kerp-employees-table-page" id="kerp-employees-list" data-kerp-table-search data-search-page="/erp/employees/" data-section="<?php echo esc_attr( $section ); ?>">
<div class="nk-block-head nk-block-head-sm">
    <div class="nk-block-between">
        <div class="nk-block-head-content">
            <h3 class="nk-block-title page-title"><?php echo esc_html( $settings->get_plural_label() ); ?></h3>
            <div class="nk-block-des text-soft kerp-employees-summary">
                <p>
					<?php
					if ( $section === 'available' ) {
						printf(
							esc_html__( '%s کاربر برای افزودن به کارکنان آماده است.', 'kasebi-erp' ),
							esc_html( number_format_i18n( (int) $result['total'] ) )
						);
					} else {
						printf(
							esc_html__( '%s کارمند ثبت شده است.', 'kasebi-erp' ),
							esc_html( number_format_i18n( (int) $result['total'] ) )
						);
					}
					?>
                </p>
            </div>
        </div>
		<?php if ( $can_create && $section === 'employees' ) : ?>
            <div class="nk-block-head-content">
                <a href="#addEmployee"
                   class="btn btn-primary"
                   data-bs-toggle="modal"
                   data-bs-target="#addEmployee">
                    <em class="icon ni ni-plus"></em>
                    <span>
						<?php
						printf(
							esc_html__( 'افزودن %s جدید', 'kasebi-erp' ),
							esc_html( $settings->get_singular_label() )
						);
						?>
                    </span>
                </a>
            </div>
		<?php endif; ?>
    </div>
</div>

<div class="nk-block">
    <div class="card card-bordered">
        <div class="card-inner p-0">
            <ul class="nav nav-tabs nav-tabs-mb-icon nav-tabs-card m-0">
                <li class="nav-item">
                    <a href="<?php echo esc_url( home_url( $employees_url ) ); ?>"
                       class="nav-link page_activator<?php echo $section === 'employees' ? ' active' : ''; ?>"
                       data-url="<?php echo esc_attr( $employees_url ); ?>">
                        <em class="icon ni ni-users"></em>
                        <span><?php echo esc_html( $settings->get_plural_label() ); ?></span>
                    </a>
                </li>
				<?php if ( $can_create ) : ?>
                    <li class="nav-item">
                        <a href="<?php echo esc_url( home_url( $available_url ) ); ?>"
                           class="nav-link page_activator<?php echo $section === 'available' ? ' active' : ''; ?>"
                           data-url="<?php echo esc_attr( $available_url ); ?>">
                            <em class="icon ni ni-user-add"></em>
                            <span><?php esc_html_e( 'افزودن از کاربران سایت', 'kasebi-erp' ); ?></span>
                            <span class="badge rounded-pill bg-light ms-1">
								<?php echo esc_html( number_format_i18n( $candidate_count ) ); ?>
                            </span>
                        </a>
                    </li>
				<?php endif; ?>
            </ul>
        </div>
    </div>
</div>

<?php
$filter_role_key = $section === 'available' ? 'wp_role' : 'role_key';
$filter_roles = $section === 'available' ? $candidates_service->get_role_options() : $roles->get_options();
?>
<div class="nk-block mb-3">
                <div class="card-title-group flex-wrap gap-2 mb-3"><h6 class="title mb-0"><?php echo esc_html( $section === 'available' ? __( 'کاربران قابل افزودن', 'kasebi-erp' ) : $settings->get_plural_label() ); ?> <span class="badge badge-dim bg-primary kerp-employees-total"><?php echo esc_html( number_format_i18n( (int) $result['total'] ) ); ?></span></h6></div>
    <div class="card card-bordered kerp-employees-list-card">
        <div class="card-inner position-relative card-tools-toggle">
            <form class="kerp-employees-filters" role="search">
                <input type="hidden" class="kerp-employees-per-page kerp-list-context kerp-filter-input" data-for="per_page" value="<?php echo esc_attr( (int) $result['per_page'] ); ?>">
                <input type="hidden" class="kerp-list-context kerp-filter-input" data-for="section" value="<?php echo esc_attr( $section ); ?>">
                <input type="hidden" class="kerp-list-context kerp-filter-input" data-for="status" value="<?php echo esc_attr( (string) ( $request_args['status'] ?? '' ) ); ?>">
                <div class="card-title-group kerp-employees-tools">
                    <div class="card-tools">
                        <button type="button" class="btn btn-icon search-toggle toggle-search" data-target="search_employees"
                                aria-controls="kerp-employees-search-wrap" aria-expanded="<?php echo empty( $request_args['search'] ) ? 'false' : 'true'; ?>"
                                aria-label="<?php esc_attr_e( 'جستجو میان کارکنان و کاربران سایت', 'kasebi-erp' ); ?>">
                            <em class="icon ni ni-search"></em>
                        </button>
                    </div>
                    <div class="card-tools">
                        <ul class="btn-toolbar gx-1">
                    <?php if ( $section === 'available' && $can_create && $roles->get_options() ) : ?>
                        <li class="d-flex align-items-center gap-2">
                            <span class="small text-soft kerp-employees-selected-count" role="status" aria-live="polite"></span>
                            <?php KERP_Helpers_Template::render_template( 'app/components/list/bulk-actions.php', [
                                'actions' => [ 'assign' => [ 'label' => __( 'افزودن گروهی به کارکنان', 'kasebi-erp' ), 'icon' => 'ni ni-user-add' ] ],
                                'action' => 'employees_assign_existing_users', 'page' => $available_url,
                                'item_selector' => '.kerp-employee-candidate-select', 'dropdown_class' => 'kerp-employees-open-bulk',
                            ] ); ?>
                        </li>
                    <?php endif; ?>
                            <li><?php KERP_Helpers_Template::render_template( 'app/components/list/filter-dropdown.php', [
                            'page' => $section === 'available' ? $available_url : $employees_url,
                            'title' => $section === 'available' ? __( 'فیلتر نقش کاربران سایت', 'kasebi-erp' ) : __( 'فیلتر نقش سازمانی', 'kasebi-erp' ),
                            'has_filter' => ! empty( $request_args[ $filter_role_key ] ),
                            'filter_fields' => [ $filter_role_key => [
                                'type' => 'select', 'name' => $filter_role_key,
                                'label' => __( 'نقش', 'kasebi-erp' ),
                                'options' => $filter_roles,
                                'value' => (string) ( $request_args[ $filter_role_key ] ?? '' ),
                            ] ],
                        ] ); ?></li>
                            <li class="btn-toolbar-sep"></li><li><?php KERP_Helpers_Template::render_template( 'app/components/list/per-page-selector.php', [ 'per_page' => (int) $result['per_page'], 'available_per_pages' => [ 10, 20, 50 ], 'page' => $employees_url ] ); ?></li>
                        </ul>
                    </div>
                    <div id="kerp-employees-search-wrap" class="card-search search-wrap<?php echo empty( $request_args['search'] ) ? '' : ' active'; ?>" data-search="search_employees">
                        <div class="card-body">
                            <div class="search-content">
                                <button type="button" class="search-back btn btn-icon toggle-search" data-target="search_employees" aria-label="<?php esc_attr_e( 'بستن جستجو', 'kasebi-erp' ); ?>"><em class="icon ni ni-arrow-left"></em></button>
                                <input id="kerp-employees-search" type="text" name="search" autocomplete="off"
                                       value="<?php echo esc_attr( (string) ( $request_args['search'] ?? '' ) ); ?>"
                                       class="form-control border-transparent form-focus-none search_kclms_list kerp-table-search" data-for="search"
                                       aria-label="<?php esc_attr_e( 'جستجوی نام کاربران', 'kasebi-erp' ); ?>"
                                       placeholder="<?php echo esc_attr( $section === 'available' ? __( 'جستجو میان کاربران سایت', 'kasebi-erp' ) : __( 'جستجو میان کارکنان', 'kasebi-erp' ) ); ?>">
                                <button type="submit" class="search-submit btn btn-icon submit_search_actions kerp-table-search-submit" aria-label="<?php esc_attr_e( 'جستجو', 'kasebi-erp' ); ?>"><em class="icon ni ni-search"></em></button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
<div class="kerp-employees-results" aria-live="polite" aria-busy="false">
    <?php if ( $section === 'available' ) : ?>
        <div class="alert alert-light alert-icon mx-3 mb-3"><em class="icon ni ni-info-fill"></em><p class="mb-0"><?php printf( esc_html__( '%s، مدیرکل و کاربران دارای نقش سازمانی نمایش داده نمی‌شوند. انتخاب نقش سازمانی، نقش وردپرس کاربر را تغییر نمی‌دهد.', 'kasebi-erp' ), esc_html( $customer_plural_label ) ); ?></p></div>
    <?php endif; ?>
        <div class="nk-tb-list kerp-employees-table<?php echo $section === 'available' ? ' kerp-employees-selectable' : ''; ?>">
            <div class="nk-tb-item nk-tb-head">
                <?php if ( $section === 'available' && $roles->get_options() ) : ?><div class="nk-tb-col nk-tb-col-check"><input type="checkbox" class="form-check-input select_all_rows" data-target=".kerp-employee-candidate-select" aria-label="<?php esc_attr_e( 'انتخاب همه کاربران این صفحه', 'kasebi-erp' ); ?>" <?php disabled( empty( $result['items'] ) ); ?>></div><?php endif; ?>
                <?php foreach ( $section === 'available' ? [ 'کاربر سایت', 'اطلاعات تماس', 'نقش سایت', 'عملیات' ] : [ 'کارمند', 'اطلاعات تماس', 'نقش سازمانی', 'وضعیت', 'عملیات' ] as $label ) : ?><div class="nk-tb-col"><?php echo esc_html( $label ); ?></div><?php endforeach; ?>
            </div>
            <?php if ( $section !== 'available' || ! empty( $roles->get_options() ) ) : ?>
                <?php foreach ( $result['items'] as $user ) {
                    KERP_Helpers_Template::render_template( 'modules/employees/partials/' . ( $section === 'available' ? 'candidate-row.php' : 'employee-row.php' ), [
                        'candidate' => $user, 'employee' => $user, 'role_options' => $roles->get_options(), 'list_query' => $request_args,
                    ] );
                } ?>
            <?php endif; ?>
        </div>
        <?php if ( empty( $result['items'] ) || ( $section === 'available' && empty( $roles->get_options() ) ) ) : ?>
            <div class="card-inner text-center py-5">
                <em class="icon ni ni-user-cross fs-1 text-soft"></em>
                <h5 class="mt-3 mb-1"><?php echo esc_html( $section === 'available' && empty( $roles->get_options() ) ? __( 'نقش فعالی وجود ندارد.', 'kasebi-erp' ) : __( 'کاربری پیدا نشد.', 'kasebi-erp' ) ); ?></h5>
                <p class="text-soft mb-0"><?php echo esc_html( $section === 'available' && empty( $roles->get_options() ) ? __( 'ابتدا یک نقش سازمانی فعال در تنظیمات کارکنان ایجاد کنید.', 'kasebi-erp' ) : __( 'فیلتر نام یا نقش را تغییر دهید یا فیلترها را پاک کنید.', 'kasebi-erp' ) ); ?></p>
            </div>
        <?php endif; ?>
        <?php if ( (int) $result['total_pages'] > 1 && ( $section !== 'available' || ! empty( $roles->get_options() ) ) ) : ?>
            <div class="card-inner border-top">
                <?php KERP_Helpers_Template::render_template( 'app/components/list/pagination.php', [ 'current_page' => (int) $result['page_number'], 'max_page_num' => (int) $result['total_pages'], 'page' => $employees_url ] ); ?>
            </div>
        <?php endif; ?>
</div>
    </div>
</div>
<?php if ( $section === 'available' && $can_create && $roles->get_options() ) : ?>
    <?php KERP_Helpers_Template::render_template( 'modules/employees/partials/bulk-assign-modal.php', [ 'role_options' => $roles->get_options() ] ); ?>
<?php endif; ?>
</div>
