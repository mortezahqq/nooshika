<?php

defined( 'ABSPATH' ) || exit;

/**
 * @var array $page_context
 */

$page_context = isset( $page_context ) && is_array( $page_context )
	? $page_context
	: [];
$employee_id  = absint(
	$page_context['route_params']['employee_id'] ?? 0
);
$query_args   = isset( $page_context['query'] ) && is_array( $page_context['query'] )
	? $page_context['query']
	: [];

$profile_service = KERP_Modules_Employees_Profile::instance();
$profile_context = $profile_service->get_context(
	$employee_id,
	sanitize_key( (string) ( $query_args['tab'] ?? 'profile' ) )
);
$employee        = $profile_context['employee'] ?? NULL;

if ( ! $employee instanceof WP_User ) {
	?>
    <div class="card card-bordered">
        <div class="card-inner text-center py-5">
            <em class="icon ni ni-user-cross fs-1 text-soft"></em>
            <h4 class="mt-3 mb-1"><?php esc_html_e( 'کارمند پیدا نشد.', 'kasebi-erp' ); ?></h4>
            <a href="<?php echo esc_url( home_url( '/erp/employees/' ) ); ?>"
               class="btn btn-outline-primary page_activator mt-3"
               data-url="/erp/employees/">
                <em class="icon ni ni-arrow-right"></em>
                <span><?php esc_html_e( 'بازگشت به کارکنان', 'kasebi-erp' ); ?></span>
            </a>
        </div>
    </div>
	<?php
	return;
}

$settings      = KERP_Modules_Employees_Settings::instance();
$fields        = KERP_Modules_Employees_Fields::instance();
$tabs          = (array) ( $profile_context['tabs'] ?? [] );
$active_tab    = sanitize_key( (string) ( $profile_context['active_tab'] ?? 'profile' ) );
$base_url      = '/erp/employees/' . $employee_id . '/';
$display_name  = get_user_name_by_id( $employee_id );
$phone         = KERP_Modules_Employees_Query::instance()->get_phone( $employee_id );
$access_record = KERP_Services_Access::get_record( $employee_id );
$role_key      = sanitize_key( (string) ( $access_record['role_key'] ?? '' ) );
$role          = KERP_Modules_Employees_Roles::instance()->get( $role_key );
$role_label    = (string) ( $role['label'] ?? $role_key );
$status_key    = sanitize_key(
	(string) get_user_meta(
		$employee_id,
		'kerp_employee_status',
		TRUE
	)
);
$status_label  = (string) ( $fields->statuses()[ $status_key ] ?? __( 'تعیین نشده', 'kasebi-erp' ) );
$employee_code = sanitize_text_field(
	(string) get_user_meta(
		$employee_id,
		'kerp_employee_code',
		TRUE
	)
);
$can_delete    = kerp_can( 'employees.delete', 'action' );
$can_update    = kerp_can( 'employees.update', 'action' );

$profile_dropdown_actions = [];

if ( $can_update ) {
	$profile_dropdown_actions['change_avatar'] = [
		'label'      => __( 'تنظیم تصویر', 'kasebi-erp' ),
		'icon'       => 'ni ni-camera-fill',
		'href'       => '#employeeProfileImageModal',
		'order'      => 10,
		'attributes' => [
			'data-bs-toggle' => 'modal',
			'data-bs-target' => '#employeeProfileImageModal',
		],
	];
}

$can_login_as = kerp_can( 'employees.login_as', 'action' )
                && $employee_id !== get_current_user_id();

if ( $can_login_as ) {
	$profile_dropdown_actions['login_as_employee'] = [
		'label'      => __( 'ورود به عنوان کاربر', 'kasebi-erp' ),
		'icon'       => 'ni ni-signin',
		'href'       => '#',
		'class'      => 'login_as_this',
		'order'      => 80,
		'attributes' => [
			'data-id' => $employee_id,
		],
	];
}
if ( $can_delete ) {
	$profile_dropdown_actions['delete_employee'] = [
		'label'          => sprintf(
			__( 'حذف %s', 'kasebi-erp' ),
			$settings->get_singular_label()
		),
		'icon'           => 'ni ni-user-remove',
		'href'           => '#',
		'class'          => 'delete_db_item',
		'order'          => 100,
		'divider_before' => TRUE,
		'attributes'     => [
			'data-action'      => 'employees_delete',
			'data-page'        => '/erp/employees/',
			'data-employee_id' => $employee_id,
			'data-item_id'     => $employee_id,
		],
	];
}

$profile_dropdown_actions = apply_filters(
	'kerp_employees_profile_dropdown_actions',
	$profile_dropdown_actions,
	$employee,
	$profile_context
);

uasort(
	$profile_dropdown_actions,
	function( array $first, array $second ): int {
		return (int) ( $first['order'] ?? 100 )
		       <=> (int) ( $second['order'] ?? 100 );
	}
);
?>
    <div class="nk-block">
        <div class="card">
            <div class="card-aside-wrap">
                <div class="card-inner">
					<?php
					do_action(
						'kerp_employee_profile_before_tab',
						$employee_id,
						$employee,
						$profile_context
					);
					
					$profile_service->render_tab(
						$active_tab,
						$employee_id,
						array_merge( $profile_context, [ 'page_context' => $page_context ] )
					);
					?>
                </div>

                <div class="card-aside card-aside-left user-aside toggle-slide toggle-slide-left toggle-break-lg"
                     data-toggle-body="true"
                     data-content="employeeAside"
                     data-toggle-screen="lg"
                     data-toggle-overlay="true">
                    <div class="card-inner-group" data-simplebar>
                        <div class="card-inner">
                            <div class="user-card">
								<div class="user-avatar bg-primary kerp-employee-profile-avatar">
									<?php
									echo KERP_Helpers_User::get_user_avatar(
										$employee_id,
										TRUE,
										40
									); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
									?>
                                </div>
                                <div class="user-info">
                                    <span class="lead-text"><?php echo esc_html( $display_name ); ?></span>
                                    <span class="sub-text"><?php echo esc_html( $role_label ); ?></span>
                                </div>
								
								<?php if ( ! empty( $profile_dropdown_actions ) ) : ?>
                                    <div class="user-action">
                                        <div class="dropdown">
                                            <a href="#"
                                               class="btn btn-icon btn-trigger me-n2"
                                               data-bs-toggle="dropdown"
                                               aria-expanded="false">
                                                <em class="icon ni ni-more-v"></em>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-end">
                                                <ul class="link-list-opt no-bdr">
													<?php foreach ( $profile_dropdown_actions as $action_key => $action ) : ?>
														<?php
														if (
															! is_array( $action )
															|| empty( $action['label'] )
															|| isset( $action['visible'] ) && ! $action['visible']
														) {
															continue;
														}
														
														$classes    = preg_split(
															'/\s+/',
															trim( (string) ( $action['class'] ?? '' ) ),
															- 1,
															PREG_SPLIT_NO_EMPTY
														);
														$attributes = isset( $action['attributes'] ) && is_array( $action['attributes'] )
															? $action['attributes']
															: [];
														?>
														<?php if ( ! empty( $action['divider_before'] ) ) : ?>
                                                            <li class="divider"></li>
														<?php endif; ?>
                                                        <li data-action-key="<?php echo esc_attr( (string) $action_key ); ?>">
                                                            <a href="<?php echo esc_url( (string) ( $action['href'] ?? '#' ) ); ?>"
																<?php if ( ! empty( $classes ) ) : ?>
                                                               class="<?php echo esc_attr( implode( ' ', $classes ) ); ?>"
															<?php endif; ?>
															<?php foreach ( $attributes as $attribute_name => $attribute_value ) : ?>
																<?php
																if (
																	$attribute_value === NULL
																	|| $attribute_value === FALSE
																	|| is_array( $attribute_value )
																	|| is_object( $attribute_value )
																) {
																	continue;
																}
																
																$attribute_name = sanitize_key(
																	(string) $attribute_name
																);
																?>
																<?php if ( $attribute_value === TRUE ) : ?>
																	<?php echo esc_attr( $attribute_name ); ?>
																<?php else : ?>
																	<?php echo esc_attr( $attribute_name ); ?>="<?php echo esc_attr( (string) $attribute_value ); ?>"
																<?php endif; ?>
															<?php endforeach; ?>>
															<?php if ( ! empty( $action['icon'] ) ) : ?>
                                                                <em class="<?php echo esc_attr( (string) $action['icon'] ); ?> icon"></em>
															<?php endif; ?>
                                                            <span><?php echo esc_html( (string) $action['label'] ); ?></span>
                                                            </a>
                                                        </li>
														<?php if ( ! empty( $action['divider_after'] ) ) : ?>
                                                            <li class="divider"></li>
														<?php endif; ?>
													<?php endforeach; ?>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
								<?php endif; ?>
                            </div>
                        </div>

                        <div class="card-inner">
                            <div class="user-account-info py-0">
                                <div class="row g-2">
                                    <div class="col-12 d-flex align-center" style="gap: 6px;">
                                        <em class="icon ni ni-call text-primary fs-18px"></em>
                                        <span class="sub-text"><?php esc_html_e( 'موبایل:', 'kasebi-erp' ); ?></span>
                                        <span
                                            class="fw-bold"><?php echo esc_html( $phone !== '' ? $phone : '-' ); ?></span>
                                    </div>
                                    <div class="col-12 d-flex align-center" style="gap: 6px;">
                                        <em class="uik fa-id-badge icon text-primary fs-18px"></em>
                                        <span class="sub-text"><?php esc_html_e( 'کد پرسنلی:', 'kasebi-erp' ); ?></span>
                                        <span
                                            class="fw-bold"><?php echo esc_html( $employee_code !== '' ? $employee_code : '-' ); ?></span>
                                    </div>
                                    <div class="col-12 d-flex align-center" style="gap: 6px;">
                                        <em class="icon ni ni-check-circle text-primary fs-18px"></em>
                                        <span class="sub-text"><?php esc_html_e( 'وضعیت:', 'kasebi-erp' ); ?></span>
                                        <span class="fw-bold"><?php echo esc_html( $status_label ); ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="card-inner p-0">
                            <ul class="link-list-menu">
								<?php foreach ( $tabs as $tab_key => $tab ) : ?>
									<?php
									if ( ! is_array( $tab ) ) {
										continue;
									}
									
									$tab_key = sanitize_key(
										(string) ( $tab['key'] ?? $tab_key )
									);
									
									if ( $tab_key === '' ) {
										continue;
									}
									
									$tab_url = add_query_arg(
										'tab',
										$tab_key,
										$base_url
									);
									?>
                                    <li>
                                        <a href="<?php echo esc_url( home_url( $tab_url ) ); ?>"
                                           class="page_activator<?php echo $active_tab === $tab_key ? ' active' : ''; ?>"
                                           data-url="<?php echo esc_attr( $tab_url ); ?>">
                                            <em class="<?php echo esc_attr( (string) ( $tab['icon'] ?? 'ni ni-circle' ) ); ?> icon"></em>
                                            <span><?php echo esc_html( (string) ( $tab['title'] ?? $tab_key ) ); ?></span>
                                        </a>
                                    </li>
								<?php endforeach; ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

	<?php
	if ( $can_update ) {
		$profile_image_body = KERP_Helpers_Template::get_module_template(
			'employees',
			'partials/profile-image-modal-body.php',
			[
				'employee_id' => $employee_id,
				'active_tab'  => $active_tab,
			]
		);

		if ( is_string( $profile_image_body ) ) {
			KERP_Helpers_Template::render_modal(
				[
					'id'     => 'employeeProfileImageModal',
					'title'  => __( 'تنظیم تصویر پروفایل', 'kasebi-erp' ),
					'action' => 'employees_change_profile_image',
					'page'   => add_query_arg( 'tab', $active_tab, $base_url ),
					'button' => __( 'ثبت تصویر پروفایل', 'kasebi-erp' ),
					'size'   => 'lg',
					'body'   => $profile_image_body,
				]
			);
		}
	}
	?>

<?php
do_action(
	'kerp_employee_profile_after_page',
	$employee_id,
	$employee,
	$profile_context
);
