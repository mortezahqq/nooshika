<?php

defined( 'ABSPATH' ) || exit;

/**
 * @var WP_User $candidate
 * @var array   $role_options
 */

if (
	! isset( $candidate )
	|| ! $candidate instanceof WP_User
	|| empty( $role_options )
) {
	return;
}

$user_id      = (int) $candidate->ID;
$name         = get_user_name_by_id( $user_id );
$email        = sanitize_email( (string) $candidate->user_email );
$phone_key    = KERP_Modules_Employees_Candidates::instance()->get_phone_meta_key();
$phone        = sanitize_text_field( (string) get_user_meta( $user_id, $phone_key, TRUE ) );
$wp_roles     = wp_roles();
$wp_role_names = [];

foreach ( (array) $candidate->roles as $wp_role_key ) {
	$wp_role_key = sanitize_key( (string) $wp_role_key );
	$wp_role_data = $wp_roles instanceof WP_Roles
		? (array) ( $wp_roles->roles[ $wp_role_key ] ?? [] )
		: [];

	$wp_role_names[] = translate_user_role(
		(string) ( $wp_role_data['name'] ?? $wp_role_key )
	);
}

$default_role = sanitize_key(
	(string) KERP_Modules_Employees_Settings::instance()->get(
		'default_role_key',
		'employee'
	)
);

if ( ! isset( $role_options[ $default_role ] ) ) {
	$default_role = (string) array_key_first( $role_options );
}
?>
<div class="col-md-6 col-xl-4">
    <form class="modal_form card card-bordered h-100 kerp-employee-candidate"
          data-action="employees_assign_existing_user"
          data-page="/erp/employees/?section=available">
        <?php foreach ( [ 'search', 'wp_role', 'page_number' ] as $filter_key ) : ?>
            <input type="hidden" class="no_clear" data-for="<?php echo esc_attr( $filter_key ); ?>"
                   value="<?php echo esc_attr( (string) ( $list_query[ $filter_key ] ?? '' ) ); ?>">
        <?php endforeach; ?>
        <input type="hidden"
               class="no_clear"
               name="user_id"
               data-for="user_id"
               value="<?php echo esc_attr( $user_id ); ?>">

        <div class="card-inner">
            <div class="kerp-employee-candidate__head">
                <div class="user-card">
                    <div class="user-avatar md bg-primary">
						<?php
						echo KERP_Helpers_User::get_user_avatar(
							$user_id,
							TRUE,
							56
						); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
						?>
                    </div>
                    <div class="user-info">
                        <h6 class="mb-1"><?php echo esc_html( $name ); ?></h6>
                        <span class="sub-text">#<?php echo esc_html( number_format_i18n( $user_id ) ); ?></span>
                    </div>
                </div>
                <span class="badge badge-dim bg-light">
					<?php echo esc_html( implode( '، ', array_filter( $wp_role_names ) ) ?: __( 'بدون نقش وردپرس', 'kasebi-erp' ) ); ?>
                </span>
            </div>

            <div class="kerp-employee-candidate__contact">
				<?php if ( $phone !== '' ) : ?>
                    <span>
                        <em class="icon ni ni-call"></em>
                        <bdi><?php echo esc_html( $phone ); ?></bdi>
                    </span>
				<?php endif; ?>

				<?php if ( $email !== '' ) : ?>
                    <span>
                        <em class="icon ni ni-mail"></em>
                        <bdi><?php echo esc_html( $email ); ?></bdi>
                    </span>
				<?php endif; ?>
            </div>

            <div class="form-group mt-4">
                <label class="form-label" for="kerp-candidate-role-<?php echo esc_attr( $user_id ); ?>">
					<?php esc_html_e( 'نقش سازمانی در ERP', 'kasebi-erp' ); ?>
                </label>
                <div class="form-control-wrap">
                    <select id="kerp-candidate-role-<?php echo esc_attr( $user_id ); ?>"
                            class="form-control js-select2 no_clear"
                            name="role_key"
                            data-for="role_key"
                            data-req="1">
                        <option value=""><?php esc_html_e( 'انتخاب نقش', 'kasebi-erp' ); ?></option>
						<?php foreach ( $role_options as $role_key => $role_label ) : ?>
                            <option value="<?php echo esc_attr( $role_key ); ?>"
								<?php selected( $default_role, $role_key ); ?>>
								<?php echo esc_html( $role_label ); ?>
                            </option>
						<?php endforeach; ?>
                    </select>
                </div>
            </div>
        </div>

        <div class="card-inner border-top">
            <button type="button" class="btn btn-primary w-100 submit_modal_form">
                <em class="icon ni ni-user-add"></em>
                <span><?php esc_html_e( 'افزودن به کارکنان', 'kasebi-erp' ); ?></span>
            </button>
        </div>
    </form>
</div>
