<?php
defined( 'ABSPATH' ) || exit;
KERP_Helpers_Template::render_modal( [
    'id' => 'kerpEmployeesBulkAssign',
    'title' => __( 'افزودن گروهی به کارکنان', 'kasebi-erp' ),
    'action' => 'employees_assign_existing_users',
    'page' => '/erp/employees/?section=available',
    'size' => 'md',
    'body' => '<div class="col-12"><p class="kerp-employees-bulk-count text-soft"></p><p>' . esc_html__( 'نقش سازمانی انتخاب‌شده برای همه کاربران انتخاب‌شده ثبت می‌شود. نقش وردپرس کاربران تغییر نمی‌کند.', 'kasebi-erp' ) . '</p><div class="kerp-employees-bulk-feedback text-danger" role="alert"></div></div>',
    'fields' => [
        [ 'type' => 'hidden', 'id' => 'kerp-employees-bulk-nonce', 'name' => 'employees_nonce', 'value' => wp_create_nonce( 'kerp_employees_bulk_assign' ), 'input_class' => 'no_clear' ],
        [ 'type' => 'select', 'id' => 'kerp-employees-bulk-role', 'name' => 'role_key', 'label' => __( 'نقش سازمانی', 'kasebi-erp' ), 'options' => $role_options, 'required' => TRUE, 'class' => 'col-12' ],
    ],
    'button' => __( 'افزودن کاربران انتخاب‌شده', 'kasebi-erp' ),
] );
