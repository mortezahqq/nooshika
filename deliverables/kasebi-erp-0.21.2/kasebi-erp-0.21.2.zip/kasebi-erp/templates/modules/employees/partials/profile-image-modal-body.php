<?php

defined( 'ABSPATH' ) || exit;

/**
 * @var int    $employee_id
 * @var string $active_tab
 */

$employee_id = absint( $employee_id ?? 0 );
$active_tab  = sanitize_key( (string) ( $active_tab ?? 'profile' ) );
?>
<div class="col-12">
    <div class="form-group">
        <label class="form-label" for="employee_profile_image">
			<?php esc_html_e( 'انتخاب تصویر', 'kasebi-erp' ); ?>
        </label>
        <div class="upload-zone"
             data-target="#employee_profile_image"
             data-action="employees_handle_profile_image_upload"
             data-max-files="1">
            <div class="dz-message" data-dz-message>
                <span class="dz-message-text"><?php esc_html_e( 'بکشید و رها کنید', 'kasebi-erp' ); ?></span>
                <span class="dz-message-or"><?php esc_html_e( 'یا', 'kasebi-erp' ); ?></span>
                <div class="btn btn-primary"><?php esc_html_e( 'انتخاب کنید', 'kasebi-erp' ); ?></div>
            </div>
        </div>
        <input type="hidden" id="employee_profile_image" data-for="image" data-req="1">
    </div>
</div>

<div class="col-12">
    <div class="border rounded p-3">
        <div class="d-flex align-center justify-between flex-wrap g-2">
            <div>
                <strong><?php esc_html_e( 'استفاده از وبکم', 'kasebi-erp' ); ?></strong>
                <div class="text-soft small">
					<?php esc_html_e( 'در صورت اتصال دوربین، می‌توانید مستقیم عکس بگیرید.', 'kasebi-erp' ); ?>
                </div>
            </div>
            <button type="button" class="btn btn-outline-primary btn-sm start_profile_webcam">
				<?php esc_html_e( 'فعال کردن وبکم', 'kasebi-erp' ); ?>
            </button>
        </div>
        <div class="profile_webcam_box mt-3" style="display: none;">
            <div class="row g-3">
                <div class="col-md-6">
                    <video class="profile_webcam_video w-100 rounded"
                           width="300"
                           height="300"
                           autoplay
                           playsinline
                           muted></video>
                </div>
                <div class="col-md-6">
                    <canvas class="profile_webcam_canvas w-100 rounded" width="500" height="500"></canvas>
                </div>
                <div class="col-12 text-center">
                    <button type="button" class="btn btn-info take_profile_webcam_screenshot">
						<?php esc_html_e( 'پیش‌نمایش تصویر', 'kasebi-erp' ); ?>
                    </button>
                    <button type="button" class="btn btn-success upload_profile_webcam_to_dropzone">
						<?php esc_html_e( 'افزودن به آپلودزون', 'kasebi-erp' ); ?>
                    </button>
                    <button type="button" class="btn btn-light stop_profile_webcam">
						<?php esc_html_e( 'بستن وبکم', 'kasebi-erp' ); ?>
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<input type="hidden" class="no_clear" value="<?php echo esc_attr( (string) $employee_id ); ?>"
       data-for="employee_id">
<input type="hidden" class="no_clear" value="<?php echo esc_attr( $active_tab ); ?>" data-for="tab">
