<?php

defined( 'ABSPATH' ) || exit;

/**
 * @var WP_User $employee
 */

if ( ! isset( $employee ) || ! $employee instanceof WP_User ) {
	return;
}

$employee_id = (int) $employee->ID;
$access      = KERP_Services_Access::get_record( $employee_id );
$role        = KERP_Modules_Employees_Roles::instance()->get(
	(string) ( $access['role_key'] ?? '' )
);
$status_key = sanitize_key(
	(string) get_user_meta(
		$employee_id,
		'kerp_employee_status',
		TRUE
	)
);
$statuses = KERP_Modules_Employees_Fields::instance()->statuses();
$url      = '/erp/employees/' . $employee_id . '/?tab=profile';
$name     = get_user_name_by_id( $employee_id );
$code     = sanitize_text_field(
	(string) get_user_meta(
		$employee_id,
		'kerp_employee_code',
		TRUE
	)
);
?>
<div class="col-sm-6 col-lg-4 col-xxl-3">
    <div class="card card-bordered h-100">
        <div class="card-inner">
            <div class="team">
                <div class="user-card user-card-s2">
                    <div class="user-avatar lg bg-primary">
						<?php
						echo KERP_Helpers_User::get_user_avatar(
							$employee_id,
							TRUE,
							80
						); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
						?>
                    </div>
                    <div class="user-info">
                        <h6>
                            <a href="<?php echo esc_url( home_url( $url ) ); ?>"
                               class="page_activator"
                               data-url="<?php echo esc_attr( $url ); ?>">
								<?php echo esc_html( $name ); ?>
                            </a>
                        </h6>
                        <span class="sub-text"><?php echo esc_html( (string) ( $role['label'] ?? '' ) ); ?></span>
                    </div>
                </div>

                <div class="team-details">
                    <p><?php echo esc_html( $code !== '' ? $code : '—' ); ?></p>
                </div>

                <ul class="team-statistics">
                    <li>
                        <span><?php esc_html_e( 'نقش', 'kasebi-erp' ); ?></span>
                        <span><?php echo esc_html( (string) ( $role['label'] ?? '—' ) ); ?></span>
                    </li>
                    <li>
                        <span><?php esc_html_e( 'وضعیت', 'kasebi-erp' ); ?></span>
                        <span><?php echo esc_html( (string) ( $statuses[ $status_key ] ?? '—' ) ); ?></span>
                    </li>
                </ul>

                <div class="team-view">
                    <a href="<?php echo esc_url( home_url( $url ) ); ?>"
                       class="btn btn-block btn-dim btn-primary page_activator"
                       data-url="<?php echo esc_attr( $url ); ?>">
						<?php esc_html_e( 'مشاهده پروفایل', 'kasebi-erp' ); ?>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
