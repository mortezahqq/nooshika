<?php

defined( 'ABSPATH' ) || exit;

/**
 * @var WP_User $candidate
 * @var array   $role_options
 */

if (
	! isset( $candidate )
	|| ! $candidate instanceof WP_User
	|| empty( $role_options )
) {
	return;
}

$user_id      = (int) $candidate->ID;
$name         = get_user_name_by_id( $user_id );
$email        = sanitize_email( (string) $candidate->user_email );
$phone_key    = KERP_Modules_Employees_Candidates::instance()->get_phone_meta_key();
$phone        = sanitize_text_field( (string) get_user_meta( $user_id, $phone_key, TRUE ) );
$wp_roles     = wp_roles();
$wp_role_names = [];

foreach ( (array) $candidate->roles as $wp_role_key ) {
	$wp_role_key = sanitize_key( (string) $wp_role_key );
	$wp_role_data = $wp_roles instanceof WP_Roles
		? (array) ( $wp_roles->roles[ $wp_role_key ] ?? [] )
		: [];

	$wp_role_names[] = translate_user_role(
		(string) ( $wp_role_data['name'] ?? $wp_role_key )
	);
}

?>
<form class="nk-tb-item kerp-employee-candidate" data-action="employees_assign_existing_user" data-page="/erp/employees/?section=available">
    <div class="nk-tb-col nk-tb-col-check"><input type="checkbox" class="form-check-input select_item_row kerp-employee-candidate-select" value="<?php echo esc_attr( $user_id ); ?>" aria-label="<?php echo esc_attr( sprintf( __( 'انتخاب %s', 'kasebi-erp' ), $name ) ); ?>"></div>
    <div class="nk-tb-col kerp-employees-identity" data-label="کاربر سایت">
        <?php foreach ( [ 'search', 'wp_role', 'page_number', 'per_page' ] as $filter_key ) : ?>
            <input type="hidden" class="no_clear" data-for="<?php echo esc_attr( $filter_key ); ?>" value="<?php echo esc_attr( (string) ( $list_query[ $filter_key ] ?? '' ) ); ?>">
        <?php endforeach; ?>
        <input type="hidden" class="no_clear" data-for="user_id" value="<?php echo esc_attr( $user_id ); ?>">
        <div class="user-card"><div class="user-avatar sm bg-primary"><?php echo KERP_Helpers_User::get_user_avatar( $user_id, TRUE, 36 ); ?></div>
            <div class="user-info"><span class="tb-lead"><?php echo esc_html( $name ); ?></span><span class="sub-text">#<?php echo esc_html( number_format_i18n( $user_id ) ); ?></span></div>
        </div>
    </div>
    <div class="nk-tb-col" data-label="اطلاعات تماس">
        <span class="d-block"><bdi><?php echo esc_html( $phone ?: '—' ); ?></bdi></span>
        <?php if ( $email !== '' ) : ?><span class="sub-text"><bdi><?php echo esc_html( $email ); ?></bdi></span><?php endif; ?>
    </div>
    <div class="nk-tb-col" data-label="نقش سایت"><span class="badge badge-dim bg-primary"><?php echo esc_html( implode( '، ', array_filter( $wp_role_names ) ) ?: __( 'بدون نقش وردپرس', 'kasebi-erp' ) ); ?></span></div>
    <div class="nk-tb-col kerp-employees-actions" data-label="عملیات">
        <button type="button" class="btn btn-icon kerp-row-icon kerp-employees-assign-user"
                data-role-options="<?php echo esc_attr( wp_json_encode( $role_options ) ); ?>"
                title="<?php esc_attr_e( 'افزودن به کارکنان', 'kasebi-erp' ); ?>"
                aria-label="<?php echo esc_attr( sprintf( __( 'افزودن %s به کارکنان', 'kasebi-erp' ), $name ) ); ?>">
            <em class="icon ni ni-user-add" aria-hidden="true"></em>
        </button>
    </div>
</form>
