<?php

defined( 'ABSPATH' ) || exit;

/**
 * @var WP_User $employee
 */

if ( ! isset( $employee ) || ! $employee instanceof WP_User ) {
	return;
}

$employee_id = (int) $employee->ID;
$access      = KERP_Services_Access::get_record( $employee_id );
$role        = KERP_Modules_Employees_Roles::instance()->get(
	(string) ( $access['role_key'] ?? '' )
);
$status_key = sanitize_key(
	(string) get_user_meta(
		$employee_id,
		'kerp_employee_status',
		TRUE
	)
);
$statuses = KERP_Modules_Employees_Fields::instance()->statuses();
$url      = '/erp/employees/' . $employee_id . '/?tab=profile';
$name     = get_user_name_by_id( $employee_id );
$code     = sanitize_text_field(
	(string) get_user_meta(
		$employee_id,
		'kerp_employee_code',
		TRUE
	)
);

$phone_key = KERP_Modules_Employees_Candidates::instance()->get_phone_meta_key();
$phone = sanitize_text_field( (string) get_user_meta( $employee_id, $phone_key, TRUE ) );
$row_actions = [
    [ 'title' => __( 'مشاهده پروفایل', 'kasebi-erp' ), 'icon' => 'ni ni-user', 'class' => 'page_activator', 'url' => home_url( $url ), 'data_url' => $url ],
];
if ( kerp_can( 'employees.login_as', 'action' ) && KERP_Api_Auth::instance()->can_login_as_user( $employee ) ) {
    $row_actions[] = [
        'title' => __( 'ورود به عنوان کاربر', 'kasebi-erp' ),
        'icon' => 'ni ni-signin', 'class' => 'login_as_this', 'url' => '#',
        'data' => [ 'id' => $employee_id ],
    ];
}
if ( kerp_can( 'employees.delete', 'action' ) && $employee_id !== get_current_user_id() ) {
    $row_actions[] = [
        'title' => __( 'حذف از لیست کارمندان', 'kasebi-erp' ),
        'icon' => 'ni ni-user-remove', 'class' => 'delete_db_item text-danger', 'url' => '#',
        'data' => [
            'action' => 'employees_delete', 'page' => '/erp/employees/',
            'employee_id' => $employee_id, 'item_id' => $employee_id,
        ],
    ];
}
?>
<div class="nk-tb-item">
    <div class="nk-tb-col kerp-employees-identity" data-label="کارمند">
        <a href="<?php echo esc_url( home_url( $url ) ); ?>" class="user-card page_activator" data-url="<?php echo esc_attr( $url ); ?>">
            <div class="user-avatar sm bg-primary"><?php echo KERP_Helpers_User::get_user_avatar( $employee_id, TRUE, 36 ); ?></div>
            <div class="user-info"><span class="tb-lead"><?php echo esc_html( $name ); ?></span><span class="sub-text"><?php echo esc_html( $code ?: '#' . number_format_i18n( $employee_id ) ); ?></span></div>
        </a>
    </div>
    <div class="nk-tb-col" data-label="اطلاعات تماس"><span class="d-block"><bdi><?php echo esc_html( $phone ?: '—' ); ?></bdi></span><span class="sub-text"><bdi><?php echo esc_html( $employee->user_email ); ?></bdi></span></div>
    <div class="nk-tb-col" data-label="نقش سازمانی"><span class="badge badge-dim bg-primary"><?php echo esc_html( (string) ( $role['label'] ?? '—' ) ); ?></span></div>
    <div class="nk-tb-col" data-label="وضعیت"><span class="badge badge-dim <?php echo $status_key === 'active' ? 'bg-success' : 'bg-light'; ?>"><?php echo esc_html( (string) ( $statuses[ $status_key ] ?? '—' ) ); ?></span></div>
    <div class="nk-tb-col kerp-employees-actions" data-label="عملیات">
        <?php KERP_Helpers_Template::render_template( 'app/components/list/row-actions.php', [ 'display' => 'inline', 'actions' => $row_actions ] ); ?>
    </div>
</div>
