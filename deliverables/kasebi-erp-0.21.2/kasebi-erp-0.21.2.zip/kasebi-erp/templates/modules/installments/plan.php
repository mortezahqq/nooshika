<?php
defined( 'ABSPATH' ) || exit;

$route_id = KERP_Modules_Installment_Management_Settings::text( (array) ( $page_context['route_params'] ?? [] ), 'plan_id' );
$plans = KERP_Modules_Installment_Management_Settings::all();
$is_new = $route_id === 'new';
if ( ! $is_new && ( ! ctype_digit( $route_id ) || ! isset( $plans[ $route_id ] ) ) ) {
	?>
	<div class="card card-bordered"><div class="card-inner text-center py-5"><em class="icon ni ni-alert-circle fs-1 text-soft"></em><h5 class="mt-3">پلن پیدا نشد.</h5><a class="btn btn-light page_activator" href="/erp/settings/installments/" data-url="/erp/settings/installments/">بازگشت به پلن‌ها</a></div></div>
	<?php
	return;
}
$plan_id = $is_new ? '' : $route_id;
$plan = $is_new ? [] : $plans[ $plan_id ];
$page = '/erp/settings/installments/' . ( $is_new ? 'new' : $plan_id ) . '/';
$product_options = [];
$course_options = [];
$lesson_options = empty( $plan['course_id'] ) ? [] : [ 0 => 'تمام دوره (بدون محدودیت اقساط)' ];
if ( ! empty( $plan['product_id'] ) ) {
	$product_options[ $plan['product_id'] ] = get_the_title( $plan['product_id'] ) . ' (#' . $plan['product_id'] . ')';
}
if ( ! empty( $plan['course_id'] ) ) {
	$course_options[ $plan['course_id'] ] = get_the_title( $plan['course_id'] ) . ' (#' . $plan['course_id'] . ')';
}
	foreach ( KERP_Modules_Installment_Management_Settings::lessons( (int) ( $plan['course_id'] ?? 0 ) ) as $i => $lesson_id ) {
		$lesson_options[ $lesson_id ] = ( $i + 1 ) . '. ' . get_the_title( $lesson_id );
	}
require __DIR__ . '/plan-fields.php';
$groups = [
	'general' => [ 'title' => 'اطلاعات عمومی', 'description' => 'نام پلن، محصول آموزشی و وضعیت فروش را مشخص کنید.', 'fields' => [ 'name', 'enabled', 'product_id', 'course_id' ] ],
	'stages' => [ 'title' => 'اقساط، دسترسی و تگ‌ها', 'description' => 'برای هر قسط، درصد مبلغ، موعد، آخرین درس مجاز و تگ پس از پرداخت را تعیین کنید. رسیدن سررسید به‌تنهایی دسترسی را باز نمی‌کند.', 'fields' => [ 'tag_mode', 'steps' ] ],
	'sms' => [ 'title' => 'پیامک‌ها', 'description' => 'قسط ذخیره‌شده، رویداد، زمان ارسال و گیرنده هر پیامک را مشخص کنید.', 'fields' => [ 'sms' ] ],
];
if ( ! KERP_Modules_Installment_Management_SMS::ENABLED ) { unset( $groups['sms'] ); }
$active_tab = KERP_Modules_Installment_Management_Settings::text( (array) ( $page_context['query'] ?? [] ), 'tab' );
if ( ! isset( $groups[ $active_tab ] ) ) { $active_tab = 'general'; }
?>
<div class="modal_form kerp-installment-plan" data-action="installments_save_plan" data-page="<?php echo esc_attr( $page ); ?>">
	<?php foreach ( $fields as $field ) { if ( $field['type'] === 'hidden' ) { KERP_Helpers_Template::render_template( 'app/components/fields/hidden.php', compact( 'field' ) ); } } ?>
	<div class="nk-block-head nk-block-head-sm"><div class="nk-block-between">
		<div class="nk-block-head-content"><a class="page_activator text-soft" href="/erp/settings/installments/" data-url="/erp/settings/installments/">بازگشت به پلن‌ها</a><h3 class="nk-block-title page-title mt-2"><?php echo esc_html( $is_new ? 'پلن جدید اقساط' : $plan['name'] ); ?></h3></div>
		<div class="nk-block-head-content kerp-installment-plan-actions"><button type="button" class="btn btn-primary submit_modal_form"><em class="icon ni ni-save"></em><span>ذخیره این تب</span></button> <?php if ( ! $is_new ) : ?><button type="button" class="btn btn-outline-danger btn-icon" title="حذف پلن" aria-label="حذف پلن" data-bs-toggle="modal" data-bs-target="#installmentDeletePlan"><em class="icon ni ni-trash"></em></button><?php endif; ?></div>
	</div></div>
	<div class="nk-block"><?php KERP_Helpers_Template::render_template( 'app/components/settings/hero.php', [ 'title' => 'تنظیمات این پلن', 'icon' => 'icon ni ni-wallet', 'description' => 'تنظیمات هر تب را جداگانه ذخیره کنید، سپس به تب بعد بروید. تغییرات فقط برای قراردادهای جدید اعمال می‌شوند.', 'stats' => [ [ 'label' => 'وضعیت فروش', 'value' => ! empty( $plan['enabled'] ) ? 'فعال' : 'غیرفعال' ], [ 'label' => 'تعداد اقساط', 'value' => count( $plan['steps'] ?? [ [], [] ] ) ] ] ] ); ?></div>
	<div class="nk-block">
		<div class="card card-bordered kerp-installment-tabs"><div class="card-inner py-0"><ul class="nav nav-tabs" role="tablist">
			<?php foreach ( $groups as $key => $group ) : ?>
			<li class="nav-item"><a id="installment-tab-<?php echo esc_attr( $key ); ?>" class="nav-link<?php echo $key === $active_tab ? ' active' : ''; ?>" data-bs-toggle="tab" href="#installment-pane-<?php echo esc_attr( $key ); ?>" role="tab" aria-controls="installment-pane-<?php echo esc_attr( $key ); ?>" aria-selected="<?php echo $key === $active_tab ? 'true' : 'false'; ?>"><?php echo esc_html( $group['title'] ); ?></a></li>
			<?php endforeach; ?>
		</ul></div></div>
		<div class="tab-content mt-4">
			<?php foreach ( $groups as $key => $group ) : ?>
			<div id="installment-pane-<?php echo esc_attr( $key ); ?>" class="tab-pane<?php echo $key === $active_tab ? ' active show' : ''; ?>" role="tabpanel" aria-labelledby="installment-tab-<?php echo esc_attr( $key ); ?>">
				<?php if ( $key === 'sms' ) : ?>
                <div class="mb-4"><?php KERP_Helpers_Template::render_template( 'app/components/settings/hero.php', [
                    'icon' => 'icon ni ni-chat-circle', 'eyebrow' => 'ارسال خودکار', 'title' => 'پیامک رویدادهای اقساط',
                    'description' => 'هر قانون، قسط، اکشن، گیرنده و پترن ارسال را تعیین می‌کند. زمان منفی برای یادآوری پیش از سررسید و زمان مثبت برای تأخیر ارسال است؛ بر حسب دقیقه. تغییرات برای قراردادهای جدید اعمال می‌شوند.',
                    'stats' => [ [ 'label' => 'کل قوانین', 'value' => count( $plan['sms'] ?? [] ) ], [ 'label' => 'قوانین فعال', 'value' => count( array_filter( $plan['sms'] ?? [], static fn( $r ) => ! empty( $r['enabled'] ) ) ) ], [ 'label' => 'اکشن‌های قابل انتخاب', 'value' => count( KERP_Modules_Installment_Management_SMS::events() ) ] ],
                ] ); ?></div>
                <?php endif; ?>
				<div class="card card-bordered kerp-installment-panel"><div class="card-inner border-bottom kerp-settings-section-head"><div><h6 class="title"><?php echo esc_html( $group['title'] ); ?></h6><p class="text-soft mb-0"><?php echo esc_html( $group['description'] ); ?></p></div></div>
					<div class="card-inner"><div class="row g-4">
					<?php if ( $key === 'stages' ) : ?>
					<div class="col-12"><div class="kerp-installment-plan-progress" role="group" aria-label="مجموع درصد اقساط">
						<div class="kerp-installment-progress-head"><span>مجموع سهم اقساط</span><strong class="kerp-installment-progress-total">۰٪ از ۱۰۰٪</strong></div>
						<div class="progress" role="progressbar" aria-label="تکمیل درصد اقساط" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><div class="progress-bar" style="width:0%"></div></div>
						<p class="kerp-installment-progress-note text-soft mb-0" aria-live="polite"></p>
					</div></div>
					<?php endif; ?>
					<?php if ( $key === 'stages' ) : ?><div class="col-12"><div class="kerp-installment-rules"><span><em class="icon ni ni-calendar"></em>سررسیدها: به ترتیب افزایشی</span><span><em class="icon ni ni-percent"></em>مجموع سهم‌ها: ۱۰۰٪</span><span><em class="icon ni ni-unlock"></em>دسترسی هر قسط: تا درس انتخاب‌شده</span></div></div><?php endif; ?>
					<?php foreach ( $fields as $field ) { if ( in_array( $field['name'], $group['fields'], TRUE ) ) { KERP_Helpers_Template::render_template( 'app/components/fields/' . $field['type'] . '.php', compact( 'field' ) ); } } ?>
					</div></div>
				</div>
				<?php if ( $key === 'sms' ) : ?>
				<?php KERP_Helpers_Template::render_template( 'modules/installments/sms-variables.php' ); ?>
				<?php if ( ( ! class_exists( 'kasebiSMS' ) || ! method_exists( 'kasebiSMS', 'send_pattern_sms' ) ) ) : ?><div class="alert alert-warning mt-4">سرویس پیامک در دسترس نیست؛ قواعد ذخیره می‌شوند و پس از اتصال سرویس پردازش خواهند شد.</div><?php endif; ?>
				<?php endif; ?>
			</div>
			<?php endforeach; ?>
		</div>
	</div>
</div>
<?php if ( ! $is_new ) {
	KERP_Helpers_Template::render_modal( [ 'id' => 'installmentDeletePlan', 'title' => 'حذف پلن «' . $plan['name'] . '»؛ قراردادهای قبلی حفظ می‌شوند.', 'action' => 'installments_delete_plan', 'page' => '/erp/settings/installments/', 'button' => 'حذف پلن', 'fields' => [
		[ 'id' => 'installment-delete-nonce', 'name' => 'installment_nonce', 'type' => 'hidden', 'value' => wp_create_nonce( 'kerp_installments' ), 'class' => 'no_clear' ],
		[ 'id' => 'installment-delete-id', 'name' => 'plan_id', 'type' => 'hidden', 'value' => $plan_id, 'class' => 'no_clear' ],
	] ] );
} ?>
