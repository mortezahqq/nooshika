<?php
defined( 'ABSPATH' ) || exit;
$variables = KERP_Modules_Installment_Management_SMS::variable_labels();
?>
<div class="card card-bordered mt-4">
    <div class="card-inner border-bottom"><h6 class="title mb-1">متغیرهای قابل استفاده</h6><p class="text-soft mb-0">برای کپی کردن هر متغیر روی آن کلیک کنید. تمام شرط‌های یک قانون باید برقرار باشند.</p></div>
    <div class="card-inner">
        <div class="alert alert-light alert-icon mb-4"><em class="icon ni ni-info" aria-hidden="true"></em><div><strong>ساختار متغیرهای پترن</strong><div class="mt-1"><code dir="ltr">name:{first_name};amount:{amount};link:{payment_url}</code></div></div></div>
        <div class="row g-3 kerp-sms-variables">
            <?php foreach ( $variables as $variable => $label ) : ?>
            <div class="col-12 col-sm-6 col-lg-4 col-xl-3">
                <button type="button" class="kerp-sms-variable clipboard-init" data-clipboard-text="<?php echo esc_attr( $variable ); ?>" data-clip-text="کپی" data-clip-success="کپی شد" data-clip-error="ناموفق">
                    <span class="kerp-sms-variable__content"><span class="kerp-sms-variable__label"><?php echo esc_html( $label ); ?></span><code class="kerp-sms-variable__code"><?php echo esc_html( $variable ); ?></code></span>
                    <span class="kerp-sms-variable__copy"><em class="icon ni ni-copy" aria-hidden="true"></em><span class="clipboard-text">کپی</span></span>
                </button>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>
