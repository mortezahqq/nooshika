<?php
defined( 'ABSPATH' ) || exit;
$page_context['route_params']['plan_id'] = 'new';
require __DIR__ . '/plan.php';
