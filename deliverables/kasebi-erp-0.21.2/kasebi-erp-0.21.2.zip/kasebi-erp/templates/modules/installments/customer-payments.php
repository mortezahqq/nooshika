<?php defined( 'ABSPATH' ) || exit; ?>
<section class="panel_installment_payments" aria-label="پرداخت اقساط">
    <h4>اقساط سفارش</h4>
    <?php foreach ( $parts as $entry ) :
        $part = $entry['order'];
        $due = (int) $part->get_meta( '_kerp_installment_due' );
        $payable = ! $part->is_paid() && $part->has_status( [ 'pending', 'failed' ] ) && $part->needs_payment() && (float) $part->get_total_refunded() <= 0;
    ?>
    <div class="panel_installment_row">
        <div class="panel_installment_identity"><strong>قسط <?php echo esc_html( $entry['number'] ); ?></strong>
            <?php if ( $due ) : ?><span>سررسید: <?php echo esc_html( date_i18n( 'j F Y', $due ) ); ?></span><?php endif; ?>
        </div>
        <div class="panel_installment_amount"><?php echo wp_kses_post( KERP_Helpers_Template::price( $part->get_total(), [ 'currency' => $part->get_currency() ] ) ); ?><span><?php echo esc_html( wc_get_order_status_name( $part->get_status() ) ); ?></span></div>
        <?php if ( $payable ) : ?>
        <a class="w-btn <?php echo esc_attr( kasebi_get_btn_style( 'buy_process_main' ) ); ?>" href="<?php echo esc_url( $part->get_checkout_payment_url() ); ?>" aria-label="<?php echo esc_attr( 'پرداخت آنلاین قسط ' . $entry['number'] ); ?>"><i class="hik-r fa-wallet" aria-hidden="true"></i><span>پرداخت آنلاین</span></a>
        <?php endif; ?>
    </div>
    <?php endforeach; ?>
</section>
