<?php
defined( 'ABSPATH' ) || exit;
$id = (int) $contract['id']; $stage = KERP_Modules_Installment_Management_Service::stage( $contract );
ob_start();
?>
<p class="text-soft"><?php echo esc_html( $contract['plan']['name'] . ' — ' . get_the_title( $contract['course_id'] ) ); ?></p>
<div class="row g-3">
<?php foreach ( $contract['plan']['steps'] as $i => $step ) :
	$order = wc_get_order( $contract['orders'][ $i ] ?? 0 ); $paid = KERP_Modules_Installment_Management_Service::paid( $contract, $i );
	$due = (int) $contract['created_at'] + $step['days'] * DAY_IN_SECONDS;
?>
<div class="col-12 col-md-6"><div class="card card-bordered h-100"><div class="card-inner"><h6>قسط <?php echo esc_html( $i + 1 ); ?> <span class="badge badge-dim <?php echo $paid ? 'bg-success' : 'bg-warning'; ?>"><?php echo esc_html( $paid ? 'پرداخت‌شده' : ( $due < time() ? 'سررسیدشده' : 'در انتظار پرداخت' ) ); ?></span></h6>
<p class="mb-1"><?php echo $order ? wp_kses_post( KERP_Helpers_Template::price( $order->get_total(), [ 'currency' => $order->get_currency() ] ) ) : 'سفارش ساخته نشده'; ?> — <?php echo esc_html( $step['percent'] . '٪' ); ?></p>
<p class="text-soft mb-1">سررسید: <?php echo esc_html( wp_date( 'Y/m/d H:i', $due ) ); ?></p>
<p class="text-soft mb-1">دسترسی: <?php echo esc_html( $step['lesson_id'] ? 'تا پایان ' . get_the_title( $step['lesson_id'] ) : 'تمام دوره' ); ?></p>
<?php if ( $paid && $i >= $stage ) : ?><p class="text-warning">بازشدن این مرحله در انتظار تسویه اقساط قبلی است.</p><?php endif; ?>
<?php if ( $order ) : ?><p class="sub-text">سفارش #<?php echo esc_html( $order->get_id() ); ?> — <?php echo esc_html( wc_get_order_status_name( $order->get_status() ) ); ?></p><?php endif; ?>
<?php if ( $order && $contract['status'] === 'active' && $order->needs_payment() ) : ?><a class="btn btn-sm btn-outline-primary" href="<?php echo esc_url( $order->get_checkout_payment_url() ); ?>" target="_blank" rel="noopener">لینک پرداخت مشتری</a><?php endif; ?>
<?php if ( $can_approve && $contract['status'] === 'active' && ! $paid && $order && $order->has_status( [ 'pending', 'on-hold', 'failed' ] ) && (float) $order->get_total_refunded() <= 0 ) : ?><button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#installmentApprove<?php echo esc_attr( $id . '-' . $i ); ?>">تأیید دریافت وجه</button><?php endif; ?>
</div></div></div>
<?php endforeach; ?>
</div>
<?php if ( ! empty( $contract['state']['sms'] ) ) : ?><p class="text-soft mt-3">گزارش پیامک: <?php $counts = array_count_values( array_column( $contract['state']['sms'], 'status' ) ); echo esc_html( sprintf( '%d ارسال موفق، %d ناموفق، %d در حال ارسال / نیازمند بررسی', $counts['sent'] ?? 0, $counts['failed'] ?? 0, $counts['sending'] ?? 0 ) ); ?></p><?php endif; ?>
<?php
$body = ob_get_clean();
KERP_Helpers_Template::render_modal( [ 'id' => 'installmentDetail' . $id, 'title' => 'قرارداد #' . $id, 'type' => 'context', 'size' => 'lg', 'body' => $body ] );
if ( $can_approve ) {
	foreach ( $contract['plan']['steps'] as $i => $step ) {
		KERP_Helpers_Template::render_modal( [ 'id' => 'installmentApprove' . $id . '-' . $i, 'title' => 'تأیید دریافت قسط ' . ( $i + 1 ), 'action' => 'installments_approve', 'page' => $page, 'button' => 'وجه دریافت شده؛ تأیید قسط', 'fields' => [
			$nonce_field + [ 'id' => 'approve-nonce-' . $id . '-' . $i ],
			[ 'id' => 'approve-contract-' . $id . '-' . $i, 'name' => 'contract_id', 'type' => 'hidden', 'value' => $id, 'class' => 'no_clear' ],
			[ 'id' => 'approve-stage-' . $id . '-' . $i, 'name' => 'stage', 'type' => 'hidden', 'value' => $i + 1, 'class' => 'no_clear' ],
			[ 'id' => 'approve-reference-' . $id . '-' . $i, 'name' => 'reference', 'type' => 'textarea', 'label' => 'شرح دریافت وجه / شماره پیگیری', 'required' => TRUE, 'class' => 'col-12' ],
		] ] );
	}
}
