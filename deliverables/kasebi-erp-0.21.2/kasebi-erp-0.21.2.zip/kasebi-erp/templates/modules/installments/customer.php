<?php
defined( 'ABSPATH' ) || exit;
global $wpdb;
$customer_id = absint( $customer_id ?? 0 );
if ( ! kerp_can( 'installments.view', 'view' ) || ! KERP_Modules_Installment_Management_Api::customer_allowed( $customer_id ) ) { return; }
$query = (array) ( $page_context['query'] ?? [] ); $page = '/erp/customers/' . $customer_id . '/?tab=installments';
$course_id = absint( $query['course_id'] ?? 0 );
$where = $wpdb->prepare( 'user_id=%d', $customer_id );
if ( $course_id ) { $where .= $wpdb->prepare( ' AND course_id=%d', $course_id ); }
$table = KERP_Modules_Installment_Management_Store::table();
$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE {$where}" );
$per_page = KERP_Helpers_Pagination::resolve_per_page( 'installment_contracts', $query, 10, 50 );
$total_pages = max( 1, (int) ceil( $total / $per_page ) ); $current = min( $total_pages, max( 1, absint( $query['page_number'] ?? 1 ) ) );
$contracts = array_map( [ KERP_Modules_Installment_Management_Store::class, 'decode' ], $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE {$where} ORDER BY id DESC LIMIT %d OFFSET %d", $per_page, ( $current - 1 ) * $per_page ), ARRAY_A ) );
$plans = KERP_Modules_Installment_Management_Settings::all(); $options = []; $courses = [];
foreach ( $plans as $id => $plan ) { if ( ! empty( $plan['enabled'] ) ) { $options[ $id ] = $plan['name'] . ' / ' . get_the_title( $plan['product_id'] ) . ' / ' . count( $plan['steps'] ) . ' قسط'; } $courses[ $plan['course_id'] ] = get_the_title( $plan['course_id'] ); }
$can_create = kerp_can( 'installments.create', 'action' ) && kerp_can( 'orders.create', 'action' ); $can_approve = kerp_can( 'installments.approve', 'action' );
?>
<div class="nk-block-head nk-block-head-sm"><div class="nk-block-between"><div class="nk-block-head-content"><h4 class="nk-block-title">اقساط آموزشی</h4><p class="text-soft">قسط اول در روز ثبت قرارداد سررسید می‌شود. دسترسی با پرداخت یا تأیید دریافت وجه باز خواهد شد.</p></div><?php if ( $can_create ) : ?><button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#installmentCreate"><em class="icon ni ni-plus"></em><span>ثبت قرارداد</span></button><?php endif; ?></div></div>
<div class="nk-block"><div class="card card-stretch"><div class="card-inner-group">
<div class="card-inner"><div class="card-title-group"><div class="card-tools"><?php if ( $can_approve ) { KERP_Helpers_Template::render_template( 'app/components/list/bulk-actions.php', [ 'page' => $page, 'action' => 'installments_sync', 'actions' => [ 'sync' => [ 'label' => 'همگام‌سازی با پرداخت‌ها', 'need' => [ 'modal' ] ] ], 'need_fields' => [ 'modal' => [ 'type' => 'modal', 'modalId' => 'installmentSync', 'itemsInput' => 'installment-contract-ids' ] ] ] ); } ?></div><div class="card-tools"><ul class="btn-toolbar gx-1"><li><?php KERP_Helpers_Template::render_template( 'app/components/list/filter-dropdown.php', [ 'page' => $page, 'has_filter' => (bool) $course_id, 'filter_fields' => [ 'course_id' => [ 'key' => 'course_id', 'name' => 'course_id', 'type' => 'select', 'label' => 'دوره', 'options' => $courses, 'value' => $course_id ] ] ] ); ?></li><li><?php KERP_Helpers_Template::render_template( 'app/components/list/per-page-selector.php', [ 'page' => $page, 'per_page' => $per_page, 'available_per_pages' => [ 10, 20, 50 ] ] ); ?></li></ul></div></div></div>
<div class="card-inner p-0"><div class="nk-tb-list nk-tb-ulist is-compact"><div class="nk-tb-item nk-tb-head"><div class="nk-tb-col nk-tb-col-check"><div class="custom-control custom-control-sm custom-checkbox notext"><input type="checkbox" class="custom-control-input select_all_rows" id="contracts-all" data-target=".select_item_row"><label class="custom-control-label" for="contracts-all"></label></div></div><div class="nk-tb-col">قرارداد / دوره</div><div class="nk-tb-col">مرحله دسترسی</div><div class="nk-tb-col">ثبت</div><div class="nk-tb-col"></div></div>
<?php foreach ( $contracts as $contract ) : $id = (int) $contract['id']; $stage = KERP_Modules_Installment_Management_Service::stage( $contract ); ?>
<div class="nk-tb-item"><div class="nk-tb-col nk-tb-col-check"><div class="custom-control custom-control-sm custom-checkbox notext"><input type="checkbox" class="custom-control-input select_item_row" id="contract-<?php echo esc_attr( $id ); ?>" value="<?php echo esc_attr( $id ); ?>"><label class="custom-control-label" for="contract-<?php echo esc_attr( $id ); ?>"></label></div></div><div class="nk-tb-col"><strong><?php echo esc_html( '#' . $id . ' — ' . $contract['plan']['name'] ); ?></strong><span class="sub-text"><?php echo esc_html( get_the_title( $contract['course_id'] ) ); ?></span></div><div class="nk-tb-col"><?php echo esc_html( $contract['status'] === 'active' ? $stage . ' از ' . count( $contract['plan']['steps'] ) : 'ساخت قرارداد کامل نشده' ); ?></div><div class="nk-tb-col"><?php echo esc_html( wp_date( 'Y/m/d', (int) $contract['created_at'] ) ); ?></div><div class="nk-tb-col"><?php KERP_Helpers_Template::render_template( 'app/components/list/row-actions.php', [ 'actions' => [ 'view' => [ 'title' => 'اقساط و لینک پرداخت', 'url' => '#installmentDetail' . $id, 'data' => [ 'bs-toggle' => 'modal', 'bs-target' => '#installmentDetail' . $id ] ] ] ] ); ?></div></div>
<?php endforeach; ?></div><?php if ( ! $contracts ) : ?><div class="card-inner text-center py-5"><em class="icon ni ni-wallet fs-1 text-soft"></em><h5 class="mt-3 mb-1">قرارداد اقساطی ثبت نشده است</h5><p class="text-soft mb-0">از پلن‌های فعال، قرارداد جدیدی برای این مشتری ثبت کنید.</p></div><?php endif; ?></div>
<?php if ( $total_pages > 1 ) : ?><div class="card-inner border-top"><?php KERP_Helpers_Template::render_template( 'app/components/list/pagination.php', [ 'max_page_num' => $total_pages, 'current_page' => $current, 'page' => $page, 'action' => 'erp_request_page_content' ] ); ?></div><?php endif; ?>
</div></div></div>
<?php
$nonce_field = [ 'name' => 'installment_nonce', 'type' => 'hidden', 'value' => wp_create_nonce( 'kerp_installments' ), 'class' => 'no_clear' ];
if ( $can_create ) {
	KERP_Helpers_Template::render_modal( [ 'id' => 'installmentCreate', 'title' => 'ثبت قرارداد فروش اقساطی', 'action' => 'installments_create', 'page' => $page, 'button' => 'ساخت قرارداد و سفارش‌های پرداخت', 'fields' => [
		$nonce_field + [ 'id' => 'installment-create-nonce' ],
		[ 'id' => 'installment-customer', 'name' => 'customer_id', 'type' => 'hidden', 'value' => $customer_id, 'class' => 'no_clear' ],
		[ 'id' => 'installment-request', 'name' => 'request_id', 'type' => 'hidden', 'value' => wp_generate_uuid4(), 'class' => 'no_clear' ],
		[ 'id' => 'installment-create-plan', 'name' => 'plan_id', 'type' => 'select', 'label' => 'پلن فعال (قیمت جاری محصول، با مالیات سفارش)', 'options' => $options, 'required' => TRUE, 'class' => 'col-12' ],
	] ] );
}
if ( $can_approve ) {
	KERP_Helpers_Template::render_modal( [ 'id' => 'installmentSync', 'title' => 'همگام‌سازی قراردادها با پرداخت‌ها', 'action' => 'installments_sync', 'page' => $page, 'button' => 'همگام‌سازی', 'fields' => [
		$nonce_field + [ 'id' => 'installment-sync-nonce' ],
		[ 'id' => 'installment-sync-customer', 'name' => 'customer_id', 'type' => 'hidden', 'value' => $customer_id, 'class' => 'no_clear' ],
		[ 'id' => 'installment-contract-ids', 'name' => 'contract_ids', 'type' => 'hidden' ],
	] ] );
}
foreach ( $contracts as $contract ) { KERP_Helpers_Template::render_template( 'modules/installments/contract-modal.php', compact( 'contract', 'page', 'can_approve', 'nonce_field' ) ); }
