<?php
defined( 'ABSPATH' ) || exit;
$labels = [ 'paid' => 'پرداخت‌شده', 'overdue' => 'معوق', 'today' => 'سررسید امروز', 'upcoming' => 'سررسید آینده', 'review' => 'نیازمند بررسی' ];
$colors = [ 'paid' => 'success', 'overdue' => 'danger', 'today' => 'warning', 'upcoming' => 'primary', 'review' => 'secondary' ];
$chart_colors = [ '#10b981', '#f43f5e', '#eab308', '#818cf8', '#94a3b8' ];
// Format the raw timestamp in site time before ERP calendar conversion; wp_date may be filtered by calendar plugins.
$format_due = static fn( int $timestamp ): string => KERP_Helpers_Date::local_datetime_to_jalali(
    ( new DateTimeImmutable( '@' . $timestamp ) )->setTimezone( wp_timezone() )->format( 'Y-m-d H:i:s' )
);
$total = array_sum( $stats['counts'] );
?>
<?php if ( $kind === 'installments-status' ) : ?>
	<p class="sub-text">وضعیت فعلی <?php echo esc_html( number_format_i18n( $stats['contracts'] ) ); ?> قرارداد فعال در محدوده دسترسی شما</p>
	<?php if ( $total ) : ?>
		<div class="kerp-dashboard-metric d-flex align-items-baseline gap-2 mb-3"><strong class="fs-24px"><?php echo esc_html( number_format_i18n( $total ) ); ?></strong><span class="sub-text">قسط</span></div>
		<div class="kasebi-chart mb-3" style="height:210px;min-width:0" data-chart-type="doughnut" data-cutout="72" data-legend="0" data-unit="قسط" data-labels="<?php echo esc_attr( wp_json_encode( array_values( $labels ) ) ); ?>" data-data="<?php echo esc_attr( wp_json_encode( array_map( static fn( $key ) => (int) $stats['counts'][ $key ], array_keys( $labels ) ) ) ); ?>" data-colors="<?php echo esc_attr( wp_json_encode( $chart_colors ) ); ?>"><canvas role="img" aria-label="سهم هر وضعیت از مجموع اقساط">تعداد و درصد هر وضعیت در راهنمای زیر آمده است.</canvas></div>
        <ul class="list-unstyled mb-0">
		<?php foreach ( $labels as $key => $label ) : $count = $stats['counts'][ $key ]; $percent = 100 * $count / $total; ?>
            <li class="d-flex justify-content-between align-items-center gap-2 py-2"><span><em class="icon ni ni-bullet-fill" aria-hidden="true" style="color:<?php echo esc_attr( $chart_colors[ array_search( $key, array_keys( $labels ), TRUE ) ] ); ?>"></em> <?php echo esc_html( $label ); ?></span><strong class="text-nowrap"><?php echo esc_html( number_format_i18n( $count ) ); ?> <small class="text-soft">· <?php echo esc_html( number_format_i18n( $percent, 1 ) ); ?>٪</small></strong></li>
		<?php endforeach; ?>
		</ul>
		<p class="sub-text small mb-0">معوق: سررسید پیش از امروز. نیازمند بررسی: سفارش حذف‌شده، لغوشده، نامعتبر یا دارای برگشت وجه؛ این موارد در صف وصول محاسبه نشده‌اند.</p>
	<?php else : ?>
		<div class="text-center py-5"><em class="icon ni ni-bar-chart-alt fs-1 text-soft" aria-hidden="true"></em><h6 class="mt-3">قسطی برای نمایش وجود ندارد</h6><p class="sub-text mb-0">پس از ثبت قرارداد فعال، وضعیت اقساط اینجا نمایش داده می‌شود.</p></div>
	<?php endif; ?>
<?php else : ?>
	<p class="sub-text mb-3">۵ قسط اول با اولویت قدیمی‌ترین سررسید؛ شامل معوقات، امروز و ۷ روز آینده. مبالغ، مبلغ کامل هر قسط هستند.</p>
	<?php if ( $stats['rows'] ) : ?>
		<div class="d-none d-xl-block">
		<div class="nk-tb-list is-compact" style="table-layout:fixed;width:100%">
			<div class="nk-tb-item nk-tb-head"><div class="nk-tb-col">مشتری / قرارداد</div><div class="nk-tb-col">مبلغ قسط</div><div class="nk-tb-col">سررسید / وضعیت</div></div>
			<?php foreach ( array_slice( $stats['rows'], 0, 5 ) as $row ) : ?>
			<div class="nk-tb-item"><div class="nk-tb-col"><?php KERP_Helpers_Template::render_template( 'modules/installments/dashboard-customer.php', compact( 'row' ) ); ?></div><div class="nk-tb-col"><strong><?php echo wp_kses_post( KERP_Helpers_Template::price( $row['amount'], [ 'currency' => $row['currency'] ] ) ); ?></strong></div><div class="nk-tb-col"><span class="sub-text"><bdi dir="ltr" class="d-inline-block text-nowrap"><?php echo esc_html( $format_due( (int) $row['due'] ) ); ?></bdi></span><span class="badge badge-dim bg-<?php echo esc_attr( $colors[ $row['status'] ] ); ?>"><?php echo esc_html( $labels[ $row['status'] ] ); ?></span></div></div>
			<?php endforeach; ?>
		</div></div>
		<div class="d-xl-none">
		<?php foreach ( array_slice( $stats['rows'], 0, 5 ) as $row ) : ?>
			<div class="card card-bordered mb-2"><div class="card-inner p-3">
				<?php KERP_Helpers_Template::render_template( 'modules/installments/dashboard-customer.php', compact( 'row' ) ); ?>
				<div class="d-flex justify-content-between flex-wrap gap-2 my-2"><strong><?php echo wp_kses_post( KERP_Helpers_Template::price( $row['amount'], [ 'currency' => $row['currency'] ] ) ); ?></strong><span class="badge badge-dim bg-<?php echo esc_attr( $colors[ $row['status'] ] ); ?>"><?php echo esc_html( $labels[ $row['status'] ] ); ?></span></div>
				<span class="sub-text">سررسید: <bdi dir="ltr" class="d-inline-block text-nowrap"><?php echo esc_html( $format_due( (int) $row['due'] ) ); ?></bdi></span>
			</div></div>
		<?php endforeach; ?>
		</div>
	<?php else : ?>
		<div class="card-inner text-center py-5"><em class="icon ni ni-calendar-check fs-1 text-soft" aria-hidden="true"></em><h6 class="mt-3">قسطی در صف وصول این بازه نیست</h6><p class="sub-text mb-0">قسط معوق یا پرداخت‌نشده‌ای تا هفت روز آینده در محدوده دسترسی شما وجود ندارد.</p></div>
	<?php endif; ?>
<?php endif; ?>
