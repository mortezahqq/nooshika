<?php
defined( 'ABSPATH' ) || exit;
$name = get_user_name_by_id( $row['user_id'] );
$route = '/erp/customers/' . $row['user_id'] . '/';
?>
<?php if ( kerp_can( 'customers', 'view' ) ) : ?>
	<a class="page_activator d-block py-2" data-url="<?php echo esc_attr( $route ); ?>" href="<?php echo esc_url( home_url( $route ) ); ?>"><?php echo esc_html( $name ); ?></a>
<?php else : ?><strong><?php echo esc_html( $name ); ?></strong><?php endif; ?>
<span class="sub-text"><?php echo esc_html( 'قرارداد #' . $row['id'] . ' · قسط ' . $row['stage'] . ' · ' . $row['plan'] ); ?></span>
