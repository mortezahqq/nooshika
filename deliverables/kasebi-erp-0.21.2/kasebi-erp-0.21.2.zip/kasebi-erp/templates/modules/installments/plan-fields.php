<?php
defined( 'ABSPATH' ) || exit;
$plan = $plan ?? []; $plan_id = (string) ( $plan_id ?? '' );
$tags = [];
foreach ( KERP_Modules_Customers_Taxonomies::instance()->get_terms( 'tag' ) as $key => $term ) { $tags[ $key ] = $term['name']; }
$sms_stage_options = [];
foreach ( array_values( $plan['steps'] ?? [] ) as $index => $step ) {
    $sms_stage_options[$index + 1] = sprintf( 'قسط %s · %s٪ مبلغ · %s روز پس از ثبت', number_format_i18n( $index + 1 ), number_format_i18n( (float) $step['percent'], 2 ), number_format_i18n( (int) $step['days'] ) );
}
$fields = [
	[ 'name' => 'installment_nonce', 'type' => 'hidden', 'value' => wp_create_nonce( 'kerp_installments' ) ],
	[ 'name' => 'plan_id', 'type' => 'hidden', 'value' => $plan_id ],
	[ 'name' => 'name', 'type' => 'text', 'label' => 'نام پلن (مثلاً سه قسطه دوره X)', 'value' => $plan['name'] ?? '', 'required' => TRUE ],
	[ 'name' => 'enabled', 'type' => 'switch', 'label' => 'فروش پلن فعال باشد', 'value' => ! empty( $plan['enabled'] ) ],
	[ 'name' => 'product_id', 'type' => 'select', 'label' => 'محصول', 'options' => $product_options, 'value' => $plan['product_id'] ?? '', 'required' => TRUE, 'input_class' => 'select_ajax_search', 'placeholder' => 'جستجوی نام یا شناسه محصول', 'data' => [ 'action' => 'installments_products' ] ],
	[ 'name' => 'course_id', 'type' => 'select', 'label' => 'دوره لرن‌دش', 'options' => $course_options, 'value' => $plan['course_id'] ?? '', 'required' => TRUE, 'input_class' => 'select_ajax_search', 'placeholder' => 'جستجوی نام یا شناسه دوره', 'data' => [ 'action' => 'installments_courses' ] ],
	[ 'name' => 'tag_mode', 'type' => 'select', 'label' => 'رفتار تگ مراحل', 'options' => [ 'append' => 'افزودن تگ هر مرحله و حفظ مراحل قبلی', 'replace' => 'جایگزینی تگ مرحله قبلی همین قرارداد' ], 'value' => $plan['tag_mode'] ?? 'append', 'class' => 'col-12' ],
	[ 'name' => 'steps', 'type' => 'repeater', 'label' => '', 'class' => 'col-12 kerp-installment-steps', 'row_class' => 'col-12 col-lg-6', 'card_class' => 'kerp-settings-field-card kerp-installment-step-card h-100', 'row_title' => 'قسط', 'row_icon' => 'ni ni-wallet', 'button_text' => 'افزودن قسط',
		'value' => $plan['steps'] ?? [ [ 'days' => 0, 'percent' => 50, 'lesson_id' => '', 'tag' => '' ], [ 'days' => 20, 'percent' => 50, 'lesson_id' => 0, 'tag' => '' ] ],
		'fields' => [
			[ 'name' => 'days', 'type' => 'number', 'label' => 'سررسید (روز پس از ثبت)', 'repeater_class' => 'col-12 col-sm-6' ],
			[ 'name' => 'percent', 'type' => 'text', 'label' => 'سهم از مبلغ (%)', 'repeater_class' => 'col-12 col-sm-6', 'placeholder' => '33.33' ],
			[ 'name' => 'lesson_id', 'type' => 'select', 'label' => 'دسترسی تا پایان درس', 'options' => $lesson_options, 'repeater_class' => 'col-12', 'input_class' => 'installment-lesson', 'disabled' => empty( $plan['course_id'] ), 'placeholder' => empty( $plan['course_id'] ) ? 'ابتدا دوره لرن‌دش را انتخاب کنید' : 'انتخاب درس' ],
			[ 'name' => 'tag', 'type' => 'select', 'label' => 'تگ پس از پرداخت / تأیید', 'options' => $tags, 'repeater_class' => 'col-12', 'placeholder' => 'بدون تگ' ],
		],
	],
	[ 'name' => 'sms', 'type' => 'repeater', 'label' => 'پیامک‌های هر مرحله؛ زمان منفی یعنی قبل از سررسید، زمان مثبت یعنی تأخیر (دقیقه)', 'class' => 'col-12', 'row_class' => 'col-12 col-xl-6', 'card_class' => 'kerp-settings-field-card h-100', 'row_title' => 'قانون پیامک', 'row_icon' => 'ni ni-chat-circle', 'button_text' => 'افزودن قانون پیامک', 'value' => $plan['sms'] ?? [], 'fields' => [
		[ 'name' => 'stage', 'type' => 'select', 'label' => 'قسط', 'options' => $sms_stage_options, 'placeholder' => $sms_stage_options ? 'انتخاب قسط ذخیره‌شده' : 'ابتدا اقساط پلن را ذخیره کنید' ],
		[ 'name' => 'event', 'type' => 'select', 'label' => 'اکشن', 'options' => KERP_Modules_Installment_Management_SMS::events() ],
		[ 'name' => 'offset', 'type' => 'text', 'label' => 'فاصله از رویداد (دقیقه)', 'placeholder' => '0' ],
		[ 'name' => 'recipient', 'type' => 'select', 'label' => 'گیرنده', 'options' => KERP_Modules_Installment_Management_SMS::recipients(), 'repeater_class' => 'col-12 col-md-6' ],
		[ 'name' => 'phone_meta', 'type' => 'text', 'label' => 'کلید متای شماره مشتری / والد', 'placeholder' => 'nooshika_phone_num', 'repeater_class' => 'col-12 col-md-6 kerp-installment-sms-meta d-none' ],
		[ 'name' => 'receptor', 'type' => 'text', 'label' => 'شماره‌ها با ویرگول', 'repeater_class' => 'col-12 col-md-6 kerp-installment-sms-custom d-none' ],
		[ 'name' => 'pattern', 'type' => 'text', 'label' => 'نام پترن', 'repeater_class' => 'col-12', 'input_class' => 'fc-direction-ltr' ],
		[ 'name' => 'variables', 'type' => 'textarea', 'label' => 'متغیرهای پترن', 'placeholder' => 'name:{first_name};amount:{amount};link:{payment_url}', 'input_class' => 'fc-direction-ltr', 'repeater_class' => 'col-12', 'rows' => 2 ],
	] ],
];
foreach ( $fields as &$sms_field ) { if ( $sms_field['name'] === 'sms' ) { foreach ( $sms_field['fields'] as &$child ) { $child['repeater_class'] ??= 'col-12 col-md-6'; } unset( $child ); } } unset( $sms_field );
foreach ( $fields as &$field ) { $field['id'] = 'installment-' . ( $plan_id ?: 'new' ) . '-' . $field['name']; $field['class'] ??= $field['type'] === 'hidden' ? 'no_clear' : 'col-12 col-md-6'; $field['input_class'] = trim( ( $field['input_class'] ?? '' ) . ' no_clear' ); } unset( $field );
