<?php
defined( 'ABSPATH' ) || exit;
// Only render the panel's navigation shell; never load the locked step's media or tabs.
$locked_post_id = absint( $post_id ?? $id ?? 0 );
$locked_course_id = absint( learndash_get_course_id( $locked_post_id ) );
$locked_lesson_id = get_post_type( $locked_post_id ) === 'sfwd-lessons'
	? $locked_post_id
	: absint( learndash_course_get_single_parent_step( $locked_course_id, $locked_post_id, 'sfwd-lessons' ) );
?>
<input type="hidden" id="post_id" value="<?php echo esc_attr( $locked_post_id ); ?>">
<div class="lesson_content_container">
    <div class="lesson_page_course_nav" style="display: block;">
        <?php echo nooshika_panel_get_template( 'components/course_nav', [ 'course_id' => $locked_course_id, 'lesson_id' => $locked_lesson_id ] ); ?>
    </div>
    <div class="lesson_main_content">
        <input type="hidden" id="current_item_id" value="<?php echo esc_attr( $locked_post_id ); ?>">
        <div class="no_order_massage" role="status">دسترسی این بخش پس از پرداخت یا تأیید قسط مربوط باز می‌شود. برای مشاهده سفارش‌های پرداخت به بخش سفارش‌های حساب کاربری مراجعه کنید.</div>
        <div class="item_data_row_section">
            <div class="lesson_page_title"><?php echo esc_html( get_the_title( $locked_post_id ) ); ?></div>
            <?php echo nooshika_panel_get_template( 'components/lesson_nav', [ 'post_id' => $locked_post_id ] ); ?>
        </div>
    </div>
</div>
