<?php

defined( 'ABSPATH' ) || exit;

$page_context = isset( $page_context ) && is_array( $page_context ) ? $page_context : [];
$page_query   = isset( $page_context['query'] ) && is_array( $page_context['query'] ) ? $page_context['query'] : [];
$date         = isset( $page_query['date'] ) && is_array( $page_query['date'] ) ? $page_query['date'] : [];
$page_route   = '/erp/hr-reports/';
$per_page     = KERP_Helpers_Pagination::resolve_per_page(
	basename( __FILE__, '.php' ),
	$page_query,
	20,
	100
);
$query_args   = [
	'search'      => sanitize_text_field( (string) ( $page_query['search'] ?? '' ) ),
	'employee_id' => absint( $page_query['employee_id'] ?? 0 ),
	'category'    => sanitize_key( (string) ( $page_query['category'] ?? '' ) ),
	'date_from'   => sanitize_text_field( (string) ( $date['from'] ?? '' ) ),
	'date_to'     => sanitize_text_field( (string) ( $date['to'] ?? '' ) ),
	'page_number' => max( 1, absint( $page_query['page_number'] ?? 1 ) ),
	'per_page'    => $per_page,
];
$result       = KERP_Modules_Hr_Reports_Query::instance()->find( $query_args );
$reports      = (array) ( $result['items'] ?? [] );
$total        = absint( $result['total'] ?? 0 );
$total_pages  = max( 1, absint( $result['total_pages'] ?? 1 ) );
$page_number  = max( 1, absint( $result['page_number'] ?? 1 ) );
$per_page     = max( 1, absint( $result['per_page'] ?? 20 ) );
$filters      = KERP_Modules_Hr_Reports_List_Table::instance()->get_filters(
	array_merge(
		$page_query,
		[ 'date' => $date ]
	)
);
$has_filter   = FALSE;

foreach (
	[
		$query_args['search'],
		$query_args['employee_id'],
		$query_args['category'],
		$query_args['date_from'],
		$query_args['date_to'],
	] as $filter_value
) {
	if ( ! empty( $filter_value ) ) {
		$has_filter = TRUE;
		break;
	}
}

$can_create = kerp_can( 'hr_reports.create', 'action' );
$can_edit   = kerp_can( 'hr_reports.edit', 'action' );
?>
    <div class="nk-block-head nk-block-head-sm">
        <div class="nk-block-between">
            <div class="nk-block-head-content">
                <h3 class="nk-block-title page-title"><?php esc_html_e( 'گزارشات سازمانی', 'kasebi-erp' ); ?></h3>
                <div class="nk-block-des text-soft">
                    <p>
						<?php
						printf(
							esc_html__( 'در مجموع %s گزارش قابل مشاهده است.', 'kasebi-erp' ),
							esc_html( number_format_i18n( $total ) )
						);
						?>
                    </p>
                </div>
            </div>
			<?php if ( $can_create ) : ?>
                <div class="nk-block-head-content">
                    <a href="#hrReportModal"
                       class="btn btn-primary"
                       data-bs-toggle="modal"
                       data-bs-target="#hrReportModal">
                        <em class="icon ni ni-plus"></em>
                        <span><?php esc_html_e( 'ثبت گزارش', 'kasebi-erp' ); ?></span>
                    </a>
                </div>
			<?php endif; ?>
        </div>
    </div>

    <div class="nk-block">
        <div class="card card-bordered">
            <div class="card-inner-group">
                <div class="card-inner position-relative card-tools-toggle">
                    <div class="card-title-group">
                        <div class="card-tools">
                            <span class="text-soft"><?php esc_html_e( 'فهرست گزارش‌ها', 'kasebi-erp' ); ?></span>
                        </div>
                        <div class="card-tools">
                            <ul class="btn-toolbar">
                                <li>
									<?php
									echo KERP_Helpers_Template::get_template(
										'app/components/list/filter-dropdown.php',
										[
											'has_filter'    => $has_filter,
											'filter_fields' => $filters,
											'action'        => 'erp_request_page_content',
											'page'          => $page_route,
										]
									); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
									?>
                                </li>
                                <li class="btn-toolbar-sep"></li>
                                <li>
									<?php
									echo KERP_Helpers_Template::get_template(
										'app/components/list/per-page-selector.php',
										[
											'per_page'            => $per_page,
											'available_per_pages' => [ 10, 20, 50, 100 ],
											'action'              => 'erp_request_page_content',
											'page'                => $page_route,
										]
									); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
									?>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="card-inner p-0">
                    <div class="nk-tb-list nk-tb-ulist is-compact">
                        <div class="nk-tb-item nk-tb-head">
                            <div class="nk-tb-col tb-col-md"><span
                                    class="sub-text"><?php esc_html_e( 'تاریخ', 'kasebi-erp' ); ?></span></div>
                            <div class="nk-tb-col"><span
                                    class="sub-text"><?php esc_html_e( 'کارمند', 'kasebi-erp' ); ?></span></div>
                            <div class="nk-tb-col"><span
                                    class="sub-text"><?php esc_html_e( 'عنوان', 'kasebi-erp' ); ?></span></div>
                            <div class="nk-tb-col tb-col-md"><span
                                    class="sub-text"><?php esc_html_e( 'واحد گزارش', 'kasebi-erp' ); ?></span></div>
                            <div class="nk-tb-col tb-col-md"><span
                                    class="sub-text"><?php esc_html_e( 'توضیحات', 'kasebi-erp' ); ?></span></div>
                            <div class="nk-tb-col nk-tb-col-tools"></div>
                        </div>
						<?php if ( empty( $reports ) ) : ?>
							<?php echo '</div>'; ?>
                            <div class="card-inner text-center py-5">
                                <em class="uik-r fa-document-signed icon fs-1 text-soft"></em>
                                <h5 class="mt-3 mb-1"><?php esc_html_e( 'گزارشی پیدا نشد.', 'kasebi-erp' ); ?></h5>
                            </div>
							<?php echo '<div>'; ?>
						<?php else : ?>
							<?php foreach ( $reports as $report ) : ?>
								<?php
								KERP_Helpers_Template::render_template(
									'modules/hr-reports/partials/report-row.php',
									[
										'report'      => $report,
										'return_page' => $page_route,
										'modal_id'    => 'hrReportModal',
										'show_user'   => TRUE,
									]
								);
								?>
							<?php endforeach; ?>
						<?php endif; ?>
                    </div>
                </div>
            </div>
			<?php if ( $total_pages > 1 ) : ?>
                <div class="card-inner">
					<?php
					echo KERP_Helpers_Template::get_template(
						'app/components/list/pagination.php',
						[
							'max_page_num' => $total_pages,
							'current_page' => $page_number,
							'class_name'   => 'hr_reports_pagination_link',
							'show_count'   => 2,
							'action'       => 'erp_request_page_content',
							'page'         => $page_route,
						]
					); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					?>
                </div>
			<?php endif; ?>
        </div>
    </div>

<?php
if ( $can_create || $can_edit ) {
	KERP_Modules_Hr_Reports_Form::instance()->render_modal(
		$page_route,
		'hrReportModal'
	);
}
