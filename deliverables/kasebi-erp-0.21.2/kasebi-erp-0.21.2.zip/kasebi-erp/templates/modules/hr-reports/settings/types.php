<?php

defined( 'ABSPATH' ) || exit;

$settings              = KERP_Modules_Hr_Reports_Settings::instance();
$types                 = $settings->get_types( FALSE );
$type_options          = $settings->get_type_options( FALSE );
$type_modal_id         = 'hrReportTypeModal';
$delete_modal_id       = 'hrReportTypeDeleteModal';
$color_options         = [
	'primary' => __( 'اصلی', 'kasebi-erp' ),
	'info'    => __( 'آبی', 'kasebi-erp' ),
	'success' => __( 'سبز', 'kasebi-erp' ),
	'warning' => __( 'زرد', 'kasebi-erp' ),
	'danger'  => __( 'قرمز', 'kasebi-erp' ),
	'purple'  => __( 'بنفش', 'kasebi-erp' ),
	'light'   => __( 'خنثی', 'kasebi-erp' ),
];
$active_types_count    = 0;
$described_types_count = 0;

foreach ( $types as $type ) {
	if ( ! is_array( $type ) ) {
		continue;
	}
	if ( ! isset( $type['active'] ) || $type['active'] ) {
		$active_types_count ++;
	}
	if ( trim( (string) ( $type['description'] ?? '' ) ) !== '' ) {
		$described_types_count ++;
	}
}

if ( $types ) {
	$type_orders = [];
	foreach ( $types as $type_key => $type ) {
		$type_orders[ $type_key ] = absint( is_array( $type ) ? ( $type['order'] ?? 100 ) : 100 );
	}
	array_multisort( $type_orders, SORT_ASC, SORT_NUMERIC, $types );
}

$add_populate = [
	'original_key' => [ 'id' => '#kerp-hr-report-type-original-key', 'type' => 'text', 'value' => '' ],
	'key'          => [ 'id' => '#kerp-hr-report-type-key', 'type' => 'text', 'value' => '' ],
	'label'        => [ 'id' => '#kerp-hr-report-type-label', 'type' => 'text', 'value' => '' ],
	'description'  => [ 'id' => '#kerp-hr-report-type-description', 'type' => 'text', 'value' => '' ],
	'icon'         => [ 'id' => '#kerp-hr-report-type-icon', 'type' => 'text', 'value' => 'ni ni-file-text' ],
	'color'        => [ 'id' => '#kerp-hr-report-type-color', 'type' => 'select', 'value' => 'primary' ],
	'order'        => [ 'id' => '#kerp-hr-report-type-order', 'type' => 'text', 'value' => 100 ],
	'active'       => [ 'id' => '#kerp-hr-report-type-active', 'type' => 'switch', 'value' => '1' ],
];
?>
    <div class="kerp-settings-smart kerp-hr-report-settings">
        <div class="nk-block-head nk-block-head-sm">
            <div class="nk-block-between g-3">
                <div class="nk-block-head-content">
                    <h3 class="nk-block-title page-title"><?php esc_html_e( 'انواع گزارشات سازمانی', 'kasebi-erp' ); ?></h3>
                    <div class="nk-block-des text-soft">
                        <p><?php esc_html_e( 'ساختار، هویت بصری و نوع‌های قابل انتخاب هنگام ثبت گزارش سازمانی را مدیریت کنید.', 'kasebi-erp' ); ?></p>
                    </div>
                </div>
                <div class="nk-block-head-content">
                    <button type="button" class="btn btn-primary open_populate_modal"
                            data-modal="#<?php echo esc_attr( $type_modal_id ); ?>"
                            data-modal-title="<?php esc_attr_e( 'افزودن نوع گزارش', 'kasebi-erp' ); ?>"
                            data-submit-text="<?php esc_attr_e( 'افزودن نوع', 'kasebi-erp' ); ?>"
                            data-populate="<?php echo esc_attr( wp_json_encode( $add_populate ) ); ?>"><em
                            class="icon ni ni-plus"></em><span><?php esc_html_e( 'افزودن نوع گزارش', 'kasebi-erp' ); ?></span>
                    </button>
                </div>
            </div>
        </div>

        <div class="nk-block">
                        <?php
            KERP_Helpers_Template::render_template(
            	'app/components/settings/hero.php',
            	[
            		'icon'        => 'uik-r fa-document-signed',
            		'eyebrow'     => __( 'گزارشات سازمانی', 'kasebi-erp' ),
            		'title'       => __( 'تعریف نوع گزارش با هویت مستقل', 'kasebi-erp' ),
            		'description' => __( 'برای هر نوع گزارش عنوان، توضیح، آیکون، رنگ و ترتیب نمایش مشخص کنید.', 'kasebi-erp' ),
            		'stats'       => [
            			[
            				'label' => __( 'کل نوع‌ها', 'kasebi-erp' ),
            				'value' => number_format_i18n( count( $types ) ),
            			],
            			[
            				'label' => __( 'نوع فعال', 'kasebi-erp' ),
            				'value' => number_format_i18n( $active_types_count ),
            			],
            			[
            				'label' => __( 'دارای توضیحات', 'kasebi-erp' ),
            				'value' => number_format_i18n( $described_types_count ),
            			],
            		],
            	]
            );
            ?>
        </div>

        <div class="nk-block">
            <div class="kerp-settings-section-head">
                <div><h5 class="title mb-1"><?php esc_html_e( 'نوع‌های گزارش', 'kasebi-erp' ); ?></h5>
                    <p class="text-soft mb-0"><?php esc_html_e( 'نوع‌های فعال در فرم ثبت گزارش قابل انتخاب هستند.', 'kasebi-erp' ); ?></p>
                </div>
            </div>
			<?php if ( empty( $types ) ) : ?>
                                <?php
                KERP_Helpers_Template::render_template(
                	'app/components/settings/empty-state.php',
                	[
                		'icon'        => 'uik-r fa-document-signed',
                		'title'       => __( 'هنوز نوع گزارشی ثبت نشده است.', 'kasebi-erp' ),
                		'description' => __( 'برای شروع اولین نوع گزارش سازمانی را اضافه کنید.', 'kasebi-erp' ),
                		'action'      => [ 'label' => __( 'افزودن نوع گزارش', 'kasebi-erp' ), 'icon' => 'icon ni ni-plus', 'class' => 'btn btn-primary open_populate_modal', 'attributes' => [ 'data-modal' => '#' . $type_modal_id, 'data-modal-title' => __( 'افزودن نوع گزارش', 'kasebi-erp' ), 'data-submit-text' => __( 'افزودن نوع', 'kasebi-erp' ), 'data-populate' => wp_json_encode( $add_populate ) ] ],
                	]
                );
                ?>
			<?php else : ?>
                <div class="row g-gs kerp-settings-item-grid">
					<?php foreach ( $types as $type_key => $type ) : ?>
						<?php
						if ( ! is_array( $type ) ) {
							continue;
						}
						$type_key = sanitize_key( (string) ( $type['key'] ?? $type_key ) );
						if ( $type_key === '' ) {
							continue;
						}
						$type_label       = sanitize_text_field( (string) ( $type['label'] ?? $type_key ) );
						$type_description = sanitize_text_field( (string) ( $type['description'] ?? '' ) );
						$type_icon        = sanitize_text_field( (string) ( $type['icon'] ?? 'ni ni-file-text' ) );
						$type_color       = sanitize_key( (string) ( $type['color'] ?? 'primary' ) );
						$type_text_color  = $type_color === 'light' ? 'dark' : $type_color;
						$type_order       = absint( $type['order'] ?? 100 );
						$type_active      = ! isset( $type['active'] ) || ! empty( $type['active'] );
						$edit_populate    = [
							'original_key' => [ 'id'    => '#kerp-hr-report-type-original-key',
							                    'type'  => 'text',
							                    'value' => $type_key,
							],
							'key'          => [ 'id'    => '#kerp-hr-report-type-key',
							                    'type'  => 'text',
							                    'value' => $type_key,
							],
							'label'        => [ 'id'    => '#kerp-hr-report-type-label',
							                    'type'  => 'text',
							                    'value' => $type_label,
							],
							'description'  => [ 'id'    => '#kerp-hr-report-type-description',
							                    'type'  => 'text',
							                    'value' => $type_description,
							],
							'icon'         => [ 'id'    => '#kerp-hr-report-type-icon',
							                    'type'  => 'text',
							                    'value' => $type_icon,
							],
							'color'        => [ 'id'    => '#kerp-hr-report-type-color',
							                    'type'  => 'select',
							                    'value' => $type_color,
							],
							'order'        => [ 'id'    => '#kerp-hr-report-type-order',
							                    'type'  => 'text',
							                    'value' => $type_order,
							],
							'active'       => [ 'id'    => '#kerp-hr-report-type-active',
							                    'type'  => 'switch',
							                    'value' => $type_active ? '1' : '0',
							],
						];
						$delete_populate  = [ 'type_key' => [ 'id'    => '#kerp-hr-report-delete-type-key',
						                                      'type'  => 'text',
						                                      'value' => $type_key,
						],
						];
						?>
                                                <?php
                        KERP_Helpers_Template::render_template(
                        	'app/components/settings/item-card.php',
                        	[
                        		'icon'                    => $type_icon . ' icon',
                        		'icon_class'              => 'bg-' . $type_color . '-dim text-' . $type_text_color,
                        		'label'                   => $type_label,
                        		'key'                     => $type_key,
                        		'active'                  => $type_active,
                        		'description'             => $type_description,
                        		'description_placeholder' => __( 'برای این نوع گزارش توضیحی ثبت نشده است.', 'kasebi-erp' ),
                        		'actions'                 => [
                        			[
                        				'label'      => __( 'ویرایش', 'kasebi-erp' ),
                        				'icon'       => 'icon ni ni-edit',
                        				'class'      => 'edit_row_item',
                        				'attributes' => [
                        					'data-modal'       => '#' . $type_modal_id,
                        					'data-modal-title' => __( 'ویرایش نوع گزارش', 'kasebi-erp' ),
                        					'data-submit-text' => __( 'ذخیره تغییرات', 'kasebi-erp' ),
                        					'data-populate'    => wp_json_encode( $edit_populate ),
                        				],
                        			],
                        			[
                        				'label'          => __( 'حذف', 'kasebi-erp' ),
                        				'icon'           => 'icon ni ni-trash',
                        				'class'          => 'edit_row_item',
                        				'divider_before' => TRUE,
                        				'attributes'     => [
                        					'data-modal'       => '#' . $delete_modal_id,
                        					'data-modal-title' => __( 'حذف نوع گزارش', 'kasebi-erp' ),
                        					'data-submit-text' => __( 'حذف نوع', 'kasebi-erp' ),
                        					'data-populate'    => wp_json_encode( $delete_populate ),
                        				],
                        			],
                        		],
                        		'footer'                  => [
                        			[ 'icon' => 'icon ni ni-sort-v', 'text' => sprintf( __( 'ترتیب %s', 'kasebi-erp' ), number_format_i18n( $type_order ) ) ],
                        			[ 'icon' => 'icon ni ni-flag', 'text' => (string) ( $color_options[ $type_color ] ?? $type_color ) ],
                        		],
                        	]
                        );
                        ?>
					<?php endforeach; ?>
                </div>
			<?php endif; ?>
        </div>
    </div>
<?php
KERP_Helpers_Template::render_modal(
	[
		'id'     => $type_modal_id,
		'title'  => __( 'افزودن یا ویرایش نوع گزارش', 'kasebi-erp' ),
		'action' => 'hr_reports_save_type',
		'page'   => '/erp/settings/hr-reports/',
		'button' => __( 'ذخیره نوع گزارش', 'kasebi-erp' ),
		'size'   => 'lg',
		'fields' => [
			[ 'id'          => 'kerp-hr-report-type-original-key',
			  'name'        => 'type[original_key]',
			  'type'        => 'hidden',
			  'input_class' => 'no_clear',
			  'value'       => '',
			],
			[ 'id'          => 'kerp-hr-report-type-key',
			  'name'        => 'type[key]',
			  'label'       => __( 'کلید نوع', 'kasebi-erp' ),
			  'description' => __( 'کلید انگلیسی یکتا مانند incident-report وارد کنید.', 'kasebi-erp' ),
			  'type'        => 'text',
			  'class'       => 'col-md-6',
			  'input_class' => 'kerp-settings-key-input',
			  'value'       => '',
			  'required'    => TRUE,
			],
			[ 'id'       => 'kerp-hr-report-type-label',
			  'name'     => 'type[label]',
			  'label'    => __( 'عنوان نوع گزارش', 'kasebi-erp' ),
			  'type'     => 'text',
			  'class'    => 'col-md-6',
			  'value'    => '',
			  'required' => TRUE,
			],
			[ 'id'          => 'kerp-hr-report-type-description',
			  'name'        => 'type[description]',
			  'label'       => __( 'توضیحات', 'kasebi-erp' ),
			  'description' => __( 'کاربرد این نوع گزارش را برای کاربران توضیح دهید.', 'kasebi-erp' ),
			  'type'        => 'textarea',
			  'class'       => 'col-12',
			  'rows'        => 3,
			  'value'       => '',
			],
			[ 'id'          => 'kerp-hr-report-type-icon',
			  'name'        => 'type[icon]',
			  'label'       => __( 'کلاس آیکون', 'kasebi-erp' ),
			  'description' => __( 'برای مثال ni ni-file-text', 'kasebi-erp' ),
			  'type'        => 'text',
			  'class'       => 'col-md-6',
			  'input_class' => 'kerp-settings-icon-input',
			  'value'       => 'ni ni-file-text',
			],
			[ 'id'          => 'kerp-hr-report-type-color',
			  'name'        => 'type[color]',
			  'label'       => __( 'رنگ', 'kasebi-erp' ),
			  'type'        => 'select',
			  'class'       => 'col-md-6',
			  'input_class' => 'kerp-settings-color-input',
			  'options'     => $color_options,
			  'value'       => 'primary',
			],
			[ 'id'    => 'kerp-hr-report-type-order',
			  'name'  => 'type[order]',
			  'label' => __( 'ترتیب نمایش', 'kasebi-erp' ),
			  'type'  => 'number',
			  'class' => 'col-md-6',
			  'value' => 100,
			  'min'   => 0,
			],
			[ 'id'          => 'kerp-hr-report-type-active-empty',
			  'name'        => 'type[active]',
			  'type'        => 'hidden',
			  'input_class' => 'no_clear',
			  'value'       => '0',
			],
			[ 'id'    => 'kerp-hr-report-type-active',
			  'name'  => 'type[active]',
			  'label' => __( 'فعال باشد', 'kasebi-erp' ),
			  'type'  => 'switch',
			  'class' => 'col-md-6 align-self-end',
			  'value' => '1',
			],
		],
	]
);
KERP_Helpers_Template::render_modal(
	[
		'id'     => $delete_modal_id,
		'title'  => __( 'حذف نوع گزارش', 'kasebi-erp' ),
		'action' => 'hr_reports_delete_type',
		'page'   => '/erp/settings/hr-reports/',
		'button' => __( 'حذف نوع گزارش', 'kasebi-erp' ),
		'size'   => 'md',
		'fields' => [
			[ 'id'          => 'kerp-hr-report-delete-type-key',
			  'name'        => 'type_key',
			  'type'        => 'hidden',
			  'input_class' => 'no_clear',
			  'value'       => '',
			],
			[ 'id'          => 'kerp-hr-report-delete-type-replacement',
			  'name'        => 'replacement_key',
			  'label'       => __( 'نوع جایگزین', 'kasebi-erp' ),
			  'description' => __( 'اگر این نوع در گزارش‌های قبلی استفاده شده، نوع جایگزین را مشخص کنید.', 'kasebi-erp' ),
			  'type'        => 'select',
			  'class'       => 'col-12',
			  'options'     => $type_options,
			  'placeholder' => __( 'نوع جایگزین را انتخاب کنید', 'kasebi-erp' ),
			  'value'       => '',
			],
		],
	]
);
