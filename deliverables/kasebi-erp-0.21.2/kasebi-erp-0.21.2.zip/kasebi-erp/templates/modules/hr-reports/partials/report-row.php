<?php

defined( 'ABSPATH' ) || exit;

$report            = isset( $report ) && is_array( $report )
	? $report
	: [];
$return_page       = isset( $return_page ) && is_string( $return_page ) && $return_page !== ''
	? $return_page
	: '/erp/hr-reports/';
$modal_id          = sanitize_html_class(
	(string) ( $modal_id ?? 'hrReportModal' )
);
$show_user         = ! isset( $show_user ) || (bool) $show_user;
$report_id         = absint( $report['id'] ?? 0 );
$employee_id       = absint( $report['employee_id'] ?? 0 );
$employee          = get_userdata( $employee_id );
$category          = KERP_Modules_Hr_Reports_Settings::instance()->get_category(
	(string) ( $report['category'] ?? '' )
);
$metadata          = isset( $report['metadata'] ) && is_array( $report['metadata'] )
	? $report['metadata']
	: [];
$attachments       = KERP_Modules_Hr_Reports_Form::instance()->get_attachment_items(
	$metadata['attachments'] ?? []
);
$populate          = KERP_Modules_Hr_Reports_Form::instance()->get_populate_data( $report );
$created_timestamp = strtotime(
	(string) ( $report['created_at'] ?? '' )
);
$created_display   = $created_timestamp
	? date_i18n( 'j F Y، H:i', $created_timestamp )
	: '—';
$title             = (string) ( $report['title'] ?? '' );
$content           = (string) ( $report['content'] ?? '' );
$plain_content     = trim( wp_strip_all_tags( $content ) );
$can_edit          = kerp_can( 'hr_reports.edit', 'action' );
$can_delete        = kerp_can( 'hr_reports.delete', 'action' );
$icon              = sanitize_text_field( (string) ( $category['icon'] ?? 'ni ni-file-text' ) );
?>
<div class="nk-tb-item">
    <div class="nk-tb-col tb-col-md">
        <span class="sub-text"><?php echo esc_html( $created_display ); ?></span>
    </div>
	<?php if ( $show_user ) : ?>
        <div class="nk-tb-col">
			<?php if ( $employee instanceof WP_User ) : ?>
				<?php
				KERP_Helpers_Template::render_template(
					'app/components/user-card.php',
					[
						'user_id'    => $employee_id,
						'show_phone' => TRUE,
					]
				);
				?>
			<?php else : ?>
                <span class="text-soft"><?php esc_html_e( 'کاربر حذف‌شده', 'kasebi-erp' ); ?></span>
			<?php endif; ?>
        </div>
	<?php endif; ?>
    <div class="nk-tb-col">
        <span class="fw-medium"><?php echo esc_html( $title ); ?></span>
    </div>
    <div class="nk-tb-col tb-col-md">
        <span class="badge badge-dim bg-<?php echo esc_attr( (string) ( $category['color'] ?? 'light' ) ); ?>">
            <em class="<?php echo esc_attr( $icon ); ?> icon me-1"></em>
            <?php echo esc_html( (string) ( $category['label'] ?? __( 'نامشخص', 'kasebi-erp' ) ) ); ?>
        </span>
    </div>
    <div class="nk-tb-col tb-col-md">
		<?php if ( $plain_content !== '' ) : ?>
            <a href="#"
               class="show_public_content_modal text-soft"
               data-modal-title="<?php echo esc_attr( $title ); ?>"
               data-content-target="#hr-report-content-<?php echo esc_attr( $report_id ); ?>">
				<?php echo esc_html( wp_html_excerpt( $plain_content, 30, '…' ) ); ?>
            </a>
            <div id="hr-report-content-<?php echo esc_attr( $report_id ); ?>" class="d-none">
				<?php echo wp_kses_post( $content ); ?>
            </div>
		<?php else : ?>
            <span class="text-soft">—</span>
		<?php endif; ?>
    </div>
    <div class="nk-tb-col nk-tb-col-tools">
        <ul class="nk-tb-actions">
			<?php if ( ! empty( $attachments ) ) : ?>
                <li>
                    <div class="dropdown">
                        <a href="#"
                           class="btn btn-sm btn-icon btn-trigger dropdown-toggle"
                           data-bs-toggle="dropdown"
                           title="<?php esc_attr_e( 'فایل‌های ضمیمه', 'kasebi-erp' ); ?>"
                           aria-expanded="false">
                                    <span class="badge badge-circle bg-primary">
                                        <?php echo esc_html( count( $attachments ) ); ?>
                                    </span>
                            <em class="kik fa-file-attachment-04 icon p-0 m-0"></em>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end">
                            <ul class="link-list-opt no-bdr">
								<?php foreach ( $attachments as $attachment ) : ?>
                                    <li>
                                        <a href="<?php echo esc_url( (string) ( $attachment['url'] ?? '' ) ); ?>"
                                           target="_blank"
                                           rel="noopener noreferrer">
                                            <em class="icon ni ni-file-download"></em>
                                            <span><?php echo esc_html( (string) ( $attachment['original_name'] ?? '' ) ); ?></span>
                                        </a>
                                    </li>
								<?php endforeach; ?>
                            </ul>
                        </div>
                    </div>
                </li>
			<?php endif; ?>
			<?php if ( $can_edit || $can_delete ) : ?>
                <li>
                    <div class="dropdown">
                        <a href="#"
                           class="btn btn-sm btn-icon btn-trigger dropdown-toggle"
                           data-bs-toggle="dropdown"
                           aria-expanded="false">
                            <em class="icon ni ni-more-h"></em>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end">
                            <ul class="link-list-opt no-bdr">
								<?php if ( $can_edit ) : ?>
                                    <li>
                                        <a href="#"
                                           class="edit_row_item"
                                           data-modal="#<?php echo esc_attr( $modal_id ); ?>"
                                           data-modal-title="<?php esc_attr_e( 'ویرایش گزارش', 'kasebi-erp' ); ?>"
                                           data-submit-text="<?php esc_attr_e( 'ذخیره تغییرات', 'kasebi-erp' ); ?>"
                                           data-populate="<?php echo esc_attr( wp_json_encode( $populate ) ); ?>">
                                            <em class="icon ni ni-edit"></em>
                                            <span><?php esc_html_e( 'ویرایش', 'kasebi-erp' ); ?></span>
                                        </a>
                                    </li>
								<?php endif; ?>
								<?php if ( $can_delete ) : ?>
									<?php if ( $can_edit ) : ?>
                                        <li class="divider"></li>
									<?php endif; ?>
                                    <li>
                                        <a href="#"
                                           class="delete_db_item"
                                           data-action="hr_reports_delete"
                                           data-page="<?php echo esc_attr( $return_page ); ?>"
                                           data-report_id="<?php echo esc_attr( $report_id ); ?>"
                                           data-item_id="<?php echo esc_attr( $report_id ); ?>">
                                            <em class="icon ni ni-trash"></em>
                                            <span><?php esc_html_e( 'حذف', 'kasebi-erp' ); ?></span>
                                        </a>
                                    </li>
								<?php endif; ?>
                            </ul>
                        </div>
                    </div>
                </li>
			<?php endif; ?>
        </ul>
    </div>
</div>
