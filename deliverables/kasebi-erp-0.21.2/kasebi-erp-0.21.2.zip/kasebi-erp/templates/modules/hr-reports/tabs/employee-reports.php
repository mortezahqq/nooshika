<?php

defined( 'ABSPATH' ) || exit;

/**
 * @var WP_User $employee
 * @var int     $employee_id
 */

if ( ! isset( $employee ) || ! $employee instanceof WP_User ) {
	return;
}

$employee_id = absint(
	$employee_id ?? $employee->ID
);
$return_page = '/erp/employees/' . $employee_id . '/?tab=hr-reports';
$result      = KERP_Modules_Hr_Reports_Query::instance()->find(
	[
		'employee_id' => $employee_id,
		'per_page'    => 50,
		'page_number' => 1,
	]
);
$reports     = (array) ( $result['items'] ?? [] );
$total       = absint( $result['total'] ?? 0 );
$can_create  = $employee_id === get_current_user_id()
	&& kerp_can( 'hr_reports.create', 'action' );
$can_edit    = kerp_can( 'hr_reports.edit', 'action' );
?>
<div class="nk-block nk-block-between">
    <div class="nk-block-head-content align-self-start d-lg-none">
        <a href="#"
           class="toggle btn btn-icon btn-trigger mt-n1"
           data-target="employeeAside">
            <em class="icon ni ni-menu-alt-r"></em>
        </a>
    </div>
    <div class="nk-block-head">
        <h6 class="title"><?php esc_html_e( 'گزارش‌های کارمند', 'kasebi-erp' ); ?></h6>
        <p>
			<?php
			printf(
				esc_html__( '%s گزارش ثبت شده است.', 'kasebi-erp' ),
				esc_html( number_format_i18n( $total ) )
			);
			?>
        </p>
    </div>
	<?php if ( $can_create ) : ?>
        <div class="nk-block-head-content">
            <a href="#employeeHrReportModal"
               class="btn btn-primary"
               data-bs-toggle="modal"
               data-bs-target="#employeeHrReportModal">
                <em class="icon ni ni-plus"></em>
                <span><?php esc_html_e( 'ثبت گزارش', 'kasebi-erp' ); ?></span>
            </a>
        </div>
	<?php endif; ?>
</div>

<div class="nk-block">
    <div class="card card-bordered">
        <div class="card-inner p-0">
            <div class="nk-tb-list nk-tb-ulist is-compact">
                <div class="nk-tb-item nk-tb-head">
                    <div class="nk-tb-col tb-col-md"><span class="sub-text"><?php esc_html_e( 'تاریخ', 'kasebi-erp' ); ?></span></div>
                    <div class="nk-tb-col"><span class="sub-text"><?php esc_html_e( 'عنوان', 'kasebi-erp' ); ?></span></div>
                    <div class="nk-tb-col tb-col-md"><span class="sub-text"><?php esc_html_e( 'واحد گزارش', 'kasebi-erp' ); ?></span></div>
                    <div class="nk-tb-col tb-col-md"><span class="sub-text"><?php esc_html_e( 'توضیحات', 'kasebi-erp' ); ?></span></div>
                    <div class="nk-tb-col nk-tb-col-tools"></div>
                </div>
				<?php if ( empty( $reports ) ) : ?>
					<?php echo '</div>'; ?>
                    <div class="card-inner text-center py-5">
                        <em class="uik-r fa-document-signed icon fs-1 text-soft"></em>
                        <h5 class="mt-3 mb-1"><?php esc_html_e( 'گزارشی برای این کارمند ثبت نشده است.', 'kasebi-erp' ); ?></h5>
                    </div>
					<?php echo '<div>'; ?>
				<?php else : ?>
					<?php foreach ( $reports as $report ) : ?>
						<?php
						KERP_Helpers_Template::render_template(
							'modules/hr-reports/partials/report-row.php',
							[
								'report'      => $report,
								'return_page' => $return_page,
								'modal_id'    => 'employeeHrReportModal',
								'show_user'   => FALSE,
							]
						);
						?>
					<?php endforeach; ?>
				<?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php
if ( $can_create || $can_edit ) {
	KERP_Modules_Hr_Reports_Form::instance()->render_modal(
		$return_page,
		'employeeHrReportModal'
	);
}
