<?php defined( 'ABSPATH' ) || exit; ?>
<?php KERP_Helpers_Template::render_template( 'app/components/fields/hidden.php', [
	'field' => [
		'id'    => 'kerp-practice-id',
		'name'  => 'practice_id',
		'value' => 0,
	],
] ); ?>
<div class="col-12"><h6 class="title mb-0">مشخصات تمرین</h6></div>
<?php KERP_Helpers_Template::render_template( 'app/components/fields/text.php', [
	'field' => [
		'id'       => 'kerp-practice-title',
		'name'     => 'title',
		'label'    => 'عنوان تمرین',
		'class'    => 'col-12',
		'required' => TRUE,
	],
] ); ?>
<?php KERP_Helpers_Template::render_template( 'app/components/fields/learndash-search.php', [
	'field' => [
		'id'            => 'kerp-practice-item',
		'name'          => 'item_id',
		'label'         => 'درس یا مبحث',
		'required'      => TRUE,
		'search_action' => 'kerp_practice_search_items',
	],
] ); ?>
<?php KERP_Helpers_Template::render_template( 'app/components/fields/quill.php', [
	'field' => [
		'id'    => 'kerp-practice-content',
		'name'  => 'content',
		'label' => 'شرح تمرین',
		'class' => 'col-12',
	],
] ); ?>
<?php KERP_Helpers_Template::render_template( 'app/components/fields/select.php', [
	'field' => [
		'id'      => 'kerp-practice-status',
		'name'    => 'post_status',
		'label'   => 'وضعیت',
		'options' => [
			'publish' => 'منتشرشده',
			'draft'   => 'پیش‌نویس',
		],
		'value'   => 'publish',
	],
] ); ?>
<div class="col-12 border-top pt-3 mt-3"><h6 class="title mb-1">پیامک‌های این تمرین</h6>
    <p class="text-soft mb-0">پترن‌ها اختیاری هستند؛ اگر پترن هر رویداد خالی باشد، پترن و متغیرهای پیش‌فرضِ همان رویداد
        استفاده می‌شوند. پیام رد پس از رد پاسخ ارسال می‌شود؛ پیام تأیید تنها وقتی ارسال می‌شود که تأیید پاسخ، درس یا
        مبحث بعدی را برای هنرجو باز کند. ارسال به سرویس پیامک فعال و شمارهٔ ثبت‌شدهٔ هنرجو نیاز دارد.</p></div>
<?php if ( ! class_exists( 'kasebiSMS' ) || ! method_exists( 'kasebiSMS', 'send_pattern_sms' ) ) : ?>
    <div class="col-12">
        <div class="alert alert-warning alert-icon mb-0"><em class="icon ni ni-alert-circle"></em><span>سرویس پیامک در دسترس نیست؛ پترن‌ها ذخیره می‌شوند، اما ارسال انجام نمی‌شود.</span>
        </div>
    </div><?php endif; ?>
<?php KERP_Helpers_Template::render_template( 'app/components/fields/text.php', [
	'field' => [
		'id'          => 'kerp-practice-sms-rejected-pattern',
		'name'        => 'sms_rejected_pattern',
		'label'       => 'پترن رد پاسخ',
		'class'       => 'col-md-6',
		'input_class' => 'fc-direction-ltr',
	],
] ); ?>
<?php KERP_Helpers_Template::render_template( 'app/components/fields/text.php', [
	'field' => [
		'id'          => 'kerp-practice-sms-unlock-pattern',
		'name'        => 'sms_unlock_pattern',
		'label'       => 'پترن باز شدن مرحلهٔ بعد',
		'class'       => 'col-md-6',
		'input_class' => 'fc-direction-ltr',
	],
] ); ?>
<?php KERP_Helpers_Template::render_template( 'app/components/fields/textarea.php', [
	'field' => [
		'id'          => 'kerp-practice-sms-rejected-variables',
		'name'        => 'sms_rejected_variables',
		'label'       => 'متغیرهای پترن رد',
		'class'       => 'col-12',
		'input_class' => 'fc-direction-ltr',
		'rows'        => 2,
		'placeholder' => 'name:{user_name};practice:{practice_title};reason:{review_comment}',
	],
] ); ?>
<?php KERP_Helpers_Template::render_template( 'app/components/fields/textarea.php', [
	'field' => [
		'id'          => 'kerp-practice-sms-unlock-variables',
		'name'        => 'sms_unlock_variables',
		'label'       => 'متغیرهای پترن باز شدن',
		'class'       => 'col-12',
		'input_class' => 'fc-direction-ltr',
		'rows'        => 2,
		'placeholder' => 'name:{user_name};next:{next_item_title}',
	],
] ); ?>
<div class="col-12">
    <div class="alert alert-light alert-icon mb-0"><em class="icon ni ni-info"></em><span>متغیرهای قابل استفاده: <code>{user_id}</code>، <code>{user_name}</code>، <code>{practice_title}</code>، <code>{item_title}</code>، <code>{next_item_title}</code>، <code>{review_comment}</code> و <code>{site_name}</code>. شمارهٔ گیرنده از پروفایل هنرجو خوانده می‌شود.</span>
    </div>
</div>
