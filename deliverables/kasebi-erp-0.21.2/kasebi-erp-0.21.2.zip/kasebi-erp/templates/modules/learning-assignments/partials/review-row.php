<?php
defined( 'ABSPATH' ) || exit;

$response_id       = absint( $row['id'] ?? 0 );
$user_id           = absint( $row['user_id'] ?? 0 );
$user              = $user_id ? get_userdata( $user_id ) : FALSE;
$practice_id       = absint( $row['practice_id'] ?? 0 );
$item_id           = absint( $row['item_id'] ?? 0 );
$practice_title    = $practice_id ? get_the_title( $practice_id ) : '';
$item_title        = $item_id ? get_the_title( $item_id ) : '';
$is_topic          = $item_id && get_post_type( $item_id ) === 'sfwd-topic';
$lesson_id         = KERP_Modules_Learning_Assignments_Module::lesson_id_for_topic( $item_id );
$lesson_title      = $lesson_id ? get_the_title( $lesson_id ) : '';
$course_id         = KERP_Modules_Learning_Assignments_Module::course_id_for_item( $item_id );
$course_title      = $course_id ? get_the_title( $course_id ) : '';
$status            = sanitize_key( (string) ( $row['status'] ?? '' ) );
$status_label      = $labels[ $status ] ?? 'نامشخص';
$status_colors     = [ 'pending' => 'warning', 'approved' => 'success', 'rejected' => 'danger', 'changed' => 'light' ];
$created_at        = (string) ( $row['created_at'] ?? '' );
$created_timestamp = $created_at !== '' ? strtotime( $created_at ) : FALSE;
$created_label     = $created_timestamp ? date_i18n( 'Y/m/d H:i', $created_timestamp ) : '—';
$file_urls         = maybe_unserialize( $row['file_url'] ?? '' );
$file_names        = maybe_unserialize( $row['file_name'] ?? '' );
$file_urls         = is_array( $file_urls ) ? $file_urls : [ $file_urls ];
$file_names        = is_array( $file_names ) ? $file_names : [ $file_names ];
$metadata          = json_decode( (string) ( $row['metadata'] ?? '' ), TRUE );
$upload_details    = is_array( $metadata ) && isset( $metadata['upload'] ) && is_array( $metadata['upload'] ) ? $metadata['upload'] : [];
$upload_details    = isset( $upload_details['original_name'] ) ? [ $upload_details ] : $upload_details;
$files             = [];
foreach ( $file_urls as $index => $url ) {
	if ( ! is_scalar( $url ) || trim( (string) $url ) === '' ) {
		continue;
	}
	$resolved_url = KERP_Modules_Learning_Assignments_File_Availability::resolve_url( (string) $url );
	$detail  = $upload_details[ $index ] ?? [];
	$name    = is_array( $detail ) && ! empty( $detail['original_name'] ) ? $detail['original_name'] : ( $file_names[ $index ] ?? '' );
	$name    = is_scalar( $name ) && trim( (string) $name ) !== '' ? (string) $name : 'دریافت فایل';
	$mime    = is_array( $detail ) ? sanitize_mime_type( (string) ( $detail['mime_type'] ?? '' ) ) : '';
	$path    = (string) wp_parse_url( $resolved_url, PHP_URL_PATH );
	$ext     = strtolower( (string) pathinfo( $name !== 'دریافت فایل' ? $name : $path, PATHINFO_EXTENSION ) );
	$files[] = [
		'url'       => $resolved_url,
		'name'      => $name,
		'available' => $resolved_url !== '' && KERP_Modules_Learning_Assignments_File_Availability::is_available( $resolved_url ),
		'is_image'  => in_array( $mime, [ 'image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/avif' ], TRUE ) || in_array( $ext, [ 'jpg', 'jpeg', 'png', 'gif', 'webp', 'avif' ], TRUE ),
	];
}
$comment         = (string) ( $row['file_comment'] ?? '' );
$review_url      = KERP_Modules_Learning_Assignments_File_Availability::resolve_url( (string) ( $row['file_comment_url'] ?? '' ) );
$reviewer_name   = KERP_Modules_Learning_Assignments_Module::reviewer_name( $row );
$has_result      = in_array( $status, [ 'approved', 'rejected', 'changed' ], TRUE );
$result_title    = 'نتیجهٔ بررسی ' . ( $practice_title ?: 'تمرین' );
$metadata_target = 'kerp-review-metadata-' . $response_id;
$populate        = [
	'response_id' => [ 'id' => '#kerp-review-id', 'type' => 'text', 'value' => $response_id ],
	'status'      => [
		'id'    => '#kerp-review-status',
		'type'  => 'select',
		'value' => in_array( $status, [ 'approved', 'rejected' ], TRUE ) ? $status : '',
	],
	'comment'     => [ 'id' => '#kerp-review-comment', 'type' => 'text', 'value' => $comment ],
	'attachment'  => [ 'id' => '#kerp-review-attachment', 'type' => 'upload', 'value' => $review_url ],
];
$column_context  = isset( $column_context ) && is_array( $column_context ) ? $column_context : [
	'singular_label' => $singular_label,
	'enabled'        => $enabled,
];
$is_customer_profile = ! empty( $column_context['customer_id'] );
$columns         = isset( $columns ) && is_array( $columns ) ? $columns : KERP_Modules_Learning_Assignments_Module::review_columns( $column_context );
$cell_context    = array_merge( $column_context, [
	'files'          => $files,
	'status'         => $status,
	'practice_title' => $practice_title,
	'item_title'     => $item_title,
	'lesson_title'   => $lesson_title,
	'course_title'   => $course_title,
	'has_result'     => $has_result,
	'created_label'  => $created_label,
] );
$icons           = [
	'topic'    => 'ni ni-list',
	'lesson'   => 'ni ni-file-text',
	'course'   => 'ni ni-layers',
	'file'     => 'ni ni-file-text',
	'download' => 'ni ni-download',
	'review'   => 'ni ni-check-circle',
	'metadata' => 'ni ni-list-thumb',
	'status'   => [
		'pending'  => 'ni ni-clock',
		'approved' => 'ni ni-check-circle',
		'rejected' => 'ni ni-cross-circle',
		'changed'  => 'ni ni-history',
	],
];
$filtered_icons  = apply_filters( 'kerp_learning_assignments_review_icons', $icons, $row, $cell_context );
if ( is_array( $filtered_icons ) ) {
	$icons = array_replace_recursive( $icons, $filtered_icons );
}
$render_files = static function ( array $file_list ) use ( $icons ): string {
	ob_start();
	foreach ( $file_list as $file ) {
		$is_available = ! empty( $file['available'] );
		$is_image     = $is_available && ! empty( $file['is_image'] );
		$name         = (string) ( $file['name'] ?? 'دریافت فایل' );
		$url          = (string) ( $file['url'] ?? '' );
		?>
		<?php if ( $is_image ) : ?>
            <a class="kerp-review-file kerp-review-image-magnify" href="<?php echo esc_url( $url ); ?>"
               data-image-url="<?php echo esc_url( $url ); ?>"
               data-image-name="<?php echo esc_attr( $name ); ?>"
               title="<?php echo esc_attr( 'پیش‌نمایش ' . $name ); ?>">
		<?php elseif ( $is_available ) : ?>
            <a class="kerp-review-file" href="<?php echo esc_url( $url ); ?>" target="_blank"
               rel="noopener noreferrer" title="<?php echo esc_attr( $name ); ?>">
		<?php else : ?>
            <span class="kerp-review-file is-unavailable" title="فایل در دسترس نیست: <?php echo esc_attr( $name ); ?>">
		<?php endif; ?>
        <span class="kerp-review-file__icon"><em
                class="icon <?php echo esc_attr( (string) $icons['file'] ); ?>" aria-hidden="true"></em></span>
        <span class="kerp-review-file__name"><?php echo esc_html( $name ); ?></span><em
            class="icon <?php echo esc_attr( (string) ( $is_image ? 'ni ni-eye' : $icons['download'] ) ); ?> kerp-review-file__download"
            aria-hidden="true"></em><?php echo $is_available ? '</a>' : '</span>'; ?>
		<?php
	}
	return (string) ob_get_clean();
};
$visible_files         = array_slice( $files, 0, 3 );
$visible_files_content = $render_files( $visible_files );
$has_more_files        = count( $files ) > 3;
$all_files_content     = $has_more_files ? '<div class="kerp-review-files kerp-review-files--modal">' . $render_files( $files ) . '</div>' : '';
$row_icons = [];
if ( $user instanceof WP_User && ! $is_customer_profile ) {
	$profile_route         = '/erp/customers/' . $user_id . '/';
	$settings              = KERP_Modules_Customers_Settings::instance();
	$owner_key             = (string) $settings->get( 'owner_meta_key', 'kerp_customer_owner_id' );
	$owner_id              = absint( get_user_meta( $user_id, $owner_key, TRUE ) );
	$owner_name            = $owner_id > 0 ? get_user_name_by_id( $owner_id ) : '';
	$row_icons['customer'] = [
		'icon'    => 'ni ni-eye',
		'tooltip' => 'مشاهده پروفایل ' . $singular_label,
		'url'     => home_url( $profile_route ),
		'class'   => 'page_activator',
		'data'    => [ 'url' => $profile_route ],
	];
	$row_icons['owner']    = [
		'icon'    => 'ni ni-user-check',
		'tooltip' => $owner_name !== '' ? sprintf( 'مسئول %1$s: %2$s', $singular_label, $owner_name ) : sprintf( 'برای %s مسئولی تعیین نشده است.', $singular_label ),
		'class'   => $owner_name === '' ? 'text-soft' : '',
	];
}
$row_icons['date'] = [ 'icon' => 'ni ni-calendar', 'tooltip' => 'تاریخ ارسال: ' . $created_label ];
if ( $comment !== '' ) {
	$row_icons['comment'] = [
		'icon'    => 'ni ni-notes',
		'tooltip' => $reviewer_name !== '' ? 'نظر ' . $reviewer_name : 'نظر ثبت‌شده',
	];
}
if ( $review_url !== '' ) {
	$row_icons['attachment'] = [
		'icon'    => 'ni ni-clip',
		'tooltip' => $reviewer_name !== '' ? 'پیوست ' . $reviewer_name : 'پیوست بررسی',
	];
}
$result_content = '';
if ( $has_result ) {
	ob_start();
	?>
    <div class="d-flex align-items-center mb-3"><span class="text-soft me-2">وضعیت پاسخ:</span><span
            class="badge badge-dim bg-<?php echo esc_attr( $status_colors[ $status ] ?? 'light' ); ?>"><em
                class="icon <?php echo esc_attr( (string) ( $icons['status'][ $status ] ?? 'ni ni-info' ) ); ?> me-1"></em><?php echo esc_html( $status_label ); ?></span>
    </div>
    <div class="card card-bordered">
        <div class="card-inner"><h6
                class="title mb-2"><?php echo esc_html( $reviewer_name !== '' ? $reviewer_name : 'نظر ثبت‌شده' ); ?></h6>
            <p class="mb-0 <?php echo $comment === '' ? 'text-soft' : ''; ?>"><?php echo $comment !== '' ? nl2br( esc_html( $comment ) ) : 'نظری ثبت نشده است.'; ?></p>
        </div>
    </div>
	<?php if ( $review_url !== '' ) : ?><a class="btn btn-outline-light mt-3"
                                           href="<?php echo esc_url( $review_url ); ?>" target="_blank"
                                           rel="noopener noreferrer"><em class="icon ni ni-clip"></em><span>دریافت پیوست بررسی</span>
        </a><?php endif; ?>
	<?php
	$result_content = (string) ob_get_clean();
}
if ( $comment !== '' && $has_result ) {
	$row_icons['comment']['url']   = '#';
	$row_icons['comment']['class'] = 'show_public_content_modal';
	$row_icons['comment']['data']  = [
		'modal-title'   => $result_title,
		'modal-content' => $result_content,
	];
}
$filtered_icons = apply_filters( 'kerp_learning_assignments_review_row_icons', $row_icons, $row, $cell_context );
$row_icons      = is_array( $filtered_icons ) ? $filtered_icons : [];
$mobile_details = [];
foreach ( [ 'date', 'owner' ] as $detail_key ) {
	if ( ! isset( $row_icons[ $detail_key ] ) || ! is_array( $row_icons[ $detail_key ] ) || ! empty( $row_icons[ $detail_key ]['hidden'] ) ) {
		continue;
	}
	$detail_text = (string) ( $row_icons[ $detail_key ]['tooltip'] ?? $row_icons[ $detail_key ]['title'] ?? '' );
	if ( $detail_text === '' ) {
		continue;
	}
	$mobile_details[ $detail_key ] = $detail_text;
	$row_icons[ $detail_key ]['class'] = trim( (string) ( $row_icons[ $detail_key ]['class'] ?? '' ) . ' kerp-review-desktop-detail' );
}
?>
<div class="nk-tb-item">
	<?php foreach ( $columns as $column_key => $column ) :
		$column_key_class = sanitize_html_class( (string) $column_key );
		$column_class     = trim( sanitize_text_field( (string) ( $column['class'] ?? '' ) ) . ' kerp-review-col kerp-review-col--' . $column_key_class );
		?>
        <div class="nk-tb-col <?php echo esc_attr( $column_class ); ?>">
			<?php if ( ! empty( $column['callback'] ) && is_callable( $column['callback'] ) ) : call_user_func( $column['callback'], $row, $column, $cell_context ); ?>
			<?php elseif ( $column_key === 'select' ) : ?>
                <div class="custom-control custom-control-sm custom-checkbox notext"><input type="checkbox"
                                                                                            class="custom-control-input select_item_row"
                                                                                            id="kerp-review-<?php echo esc_attr( $response_id ); ?>"
                                                                                            value="<?php echo esc_attr( $response_id ); ?>" <?php disabled( $status === 'changed' || ! $enabled ); ?>><label
                    class="custom-control-label" for="kerp-review-<?php echo esc_attr( $response_id ); ?>"></label>
                </div>
			<?php elseif ( $column_key === 'customer' ) : ?>
				<?php if ( $user instanceof WP_User ) : ?>
					<?php ob_start(); ?>
					<?php KERP_Helpers_Template::render_template( 'app/components/user-card.php', [
						'user_id'    => $user_id,
						'show_phone' => TRUE,
					] ); ?>
					<?php $customer_content = (string) ob_get_clean(); ?>
					<?php echo apply_filters( 'kerp_learning_assignments_review_customer_content', $customer_content, $row, $cell_context ); ?>
				<?php else : ?>
                    <span
                        class="text-soft"><?php echo esc_html( $singular_label ); ?> حذف‌شده (#<?php echo esc_html( $user_id ); ?>)</span>
				<?php endif; ?>
			<?php elseif ( $column_key === 'practice' ) : ?>
                <div class="kerp-review-practice"><span
                    class="tb-lead"><?php echo esc_html( $practice_title ?: '—' ); ?></span>
                <div class="kerp-review-path">
				<?php if ( $is_topic ) : ?><span class="kerp-review-path__item"
                                                 title="<?php echo esc_attr( 'سرفصل: ' . ( $item_title ?: '—' ) ); ?>">
                    <em class="icon <?php echo esc_attr( (string) $icons['topic'] ); ?>" aria-hidden="true"></em><span>سرفصل: <?php echo esc_html( $item_title ?: '—' ); ?></span>
                    </span><?php endif; ?>
                <span class="kerp-review-path__item"
                      title="<?php echo esc_attr( 'درس: ' . ( $is_topic ? ( $lesson_title ?: '—' ) : ( $item_title ?: '—' ) ) ); ?>"><em
                        class="icon <?php echo esc_attr( (string) $icons['lesson'] ); ?>" aria-hidden="true"></em><span>درس: <?php echo esc_html( $is_topic ? ( $lesson_title ?: '—' ) : ( $item_title ?: '—' ) ); ?></span></span>
                <span class="kerp-review-path__item kerp-review-path__item--course"
                      title="<?php echo esc_attr( 'دوره: ' . ( $course_title ?: '—' ) ); ?>"><em
                        class="icon <?php echo esc_attr( (string) $icons['course'] ); ?>" aria-hidden="true"></em><span>دوره: <?php echo esc_html( $course_title ?: '—' ); ?></span></span>
                </div><?php if ( $files ) : ?>
                    <div class="d-md-none kerp-review-mobile-files"><span
                        class="sub-text d-block mb-1">فایل‌های پاسخ</span>
					<div class="kerp-review-files"><?php echo $visible_files_content; ?>
						<?php if ( $has_more_files ) : ?><a href="#" class="btn btn-sm btn-light show_public_content_modal kerp-review-files-more"
							data-modal-title="فایل‌های پاسخ <?php echo esc_attr( $practice_title ); ?>"
							data-modal-content="<?php echo esc_attr( $all_files_content ); ?>"><em class="icon ni ni-eye"></em><span>مشاهده بیشتر</span></a><?php endif; ?>
					</div></div><?php endif; ?></div>
                <?php if ( $mobile_details ) : ?>
                <div class="kerp-review-mobile-details">
                    <?php foreach ( $mobile_details as $detail_text ) : ?>
                    <span><?php echo esc_html( $detail_text ); ?></span>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
			<?php elseif ( $column_key === 'files' ) : if ( $files ) : ?>
                <div class="kerp-review-files"><?php echo $visible_files_content; ?>
					<?php if ( $has_more_files ) : ?><a href="#" class="btn btn-sm btn-light show_public_content_modal kerp-review-files-more"
						data-modal-title="فایل‌های پاسخ <?php echo esc_attr( $practice_title ); ?>"
						data-modal-content="<?php echo esc_attr( $all_files_content ); ?>"><em class="icon ni ni-eye"></em><span>مشاهده بیشتر</span></a><?php endif; ?>
				</div><?php else : ?><span class="text-soft">—</span><?php endif; ?>
			<?php elseif ( $column_key === 'result' ) : if ( $has_result ) : ?><a href="#"
                                                                                  class="show_public_content_modal"
                                                                                  data-modal-title="<?php echo esc_attr( $result_title ); ?>"
																   data-modal-content="<?php echo esc_attr( $result_content ); ?>">
                <span class="badge badge-dim bg-<?php echo esc_attr( $status_colors[ $status ] ?? 'light' ); ?>"><em
                        class="icon <?php echo esc_attr( (string) ( $icons['status'][ $status ] ?? 'ni ni-info' ) ); ?> me-1"></em><?php echo esc_html( $status_label ); ?></span>
                </a><?php else : ?><span
                class="badge badge-dim bg-<?php echo esc_attr( $status_colors[ $status ] ?? 'light' ); ?>"><em
                class="icon <?php echo esc_attr( (string) ( $icons['status'][ $status ] ?? 'ni ni-info' ) ); ?> me-1"></em><?php echo esc_html( $status_label ); ?>
                </span><?php endif; ?>
			<?php elseif ( $column_key === 'tools' ) : ?>
                <div
                    class="d-flex align-center justify-end kerp-review-tools"><?php KERP_Helpers_Template::render_template( 'app/components/list/row-icons.php', [ 'items' => $row_icons ] ); ?>
				<?php if ( ! $is_customer_profile ) : ?>
                <a href="#"
                   class="btn btn-sm btn-icon btn-outline-light show_public_content_modal kerp-review-metadata-button"
                   data-modal-title="<?php echo esc_attr( 'متای پاسخ #' . $response_id ); ?>"
                   data-content-target="#<?php echo esc_attr( $metadata_target ); ?>" data-bs-toggle="tooltip"
                   data-bs-placement="top" title="مشاهده متای پاسخ" aria-label="مشاهده متای پاسخ"><em
                    class="icon <?php echo esc_attr( (string) $icons['metadata'] ); ?>" aria-hidden="true"></em>
                </a>
				<?php endif; ?>
				<?php if ( $enabled && $status !== 'changed' ) : ?><a href="#"
                                                                          class="btn btn-sm btn-icon btn-outline-primary edit_row_item kerp-review-check"
                                                                          data-modal="#kerp-review-modal"
                                                                          data-modal-title="<?php echo esc_attr( $status === 'pending' ? 'ثبت نتیجه' : 'ویرایش نتیجه' ); ?>"
                                                                          data-populate="<?php echo esc_attr( wp_json_encode( $populate ) ); ?>"
                                                                          data-bs-toggle="tooltip"
                                                                          data-bs-placement="top"
                                                                          title="<?php echo esc_attr( $status === 'pending' ? 'ثبت نتیجه' : 'ویرایش نتیجه' ); ?>"
                                                                          aria-label="<?php echo esc_attr( $status === 'pending' ? 'ثبت نتیجه' : 'ویرایش نتیجه' ); ?>">
                    <em class="icon <?php echo esc_attr( (string) $icons['review'] ); ?>" aria-hidden="true"></em>
                    </a><?php endif; ?></div>
			<?php else : do_action( 'kerp_learning_assignments_review_column_' . sanitize_key( (string) $column_key ), $row, $column, $cell_context ); endif; ?>
        </div>
	<?php endforeach; ?>
</div>
<?php if ( ! $is_customer_profile ) : ?>
<div id="<?php echo esc_attr( $metadata_target ); ?>"
     class="d-none"><?php echo KERP_Modules_Learning_Assignments_Metadata::render( $row ); ?></div>
<?php endif; ?>
