<?php
defined( 'ABSPATH' ) || exit;
$route = (string) ( $route ?? '/erp/learning-assignments/reviews/' );
KERP_Helpers_Template::render_modal( [
	'id' => 'kerp-review-modal',
	'title' => 'بررسی پاسخ',
	'action' => 'kerp_practice_review',
	'page' => $route,
	'button' => 'ذخیره بررسی',
	'fields' => [
		[ 'type' => 'hidden', 'id' => 'kerp-review-id', 'name' => 'response_id' ],
		[ 'type' => 'select', 'id' => 'kerp-review-status', 'name' => 'status', 'label' => 'نتیجه', 'class' => 'col-12', 'required' => TRUE, 'options' => [ 'approved' => 'تأیید', 'rejected' => 'رد' ] ],
		[ 'type' => 'textarea', 'id' => 'kerp-review-comment', 'name' => 'comment', 'label' => 'نظر شما؛ برای رد الزامی است', 'class' => 'col-12' ],
		[ 'type' => 'upload', 'id' => 'kerp-review-attachment', 'name' => 'attachment', 'label' => 'پیوست بررسی', 'max_files' => 1 ],
	],
] );
