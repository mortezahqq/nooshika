<?php
defined( 'ABSPATH' ) || exit;
$enabled = KERP_Modules_Learning_Assignments_Settings::instance()->post_type_enabled();
?>
<form class="modal_form kerp-appointments-settings" data-action="kerp_practice_save_post_type_status" data-page="/erp/settings/learning-assignments/post-type/">
	<div class="nk-block-head nk-block-head-sm"><div class="nk-block-between">
		<div class="nk-block-head-content"><h3 class="nk-block-title page-title">تنظیمات تمرین</h3><div class="nk-block-des text-soft"><p>نمایش تمرین‌ها و امکان ارسال پاسخ را در سایت مدیریت کنید.</p></div></div>
		<div class="nk-block-head-content"><button type="button" class="btn btn-primary submit_modal_form"><em class="icon ni ni-save"></em><span>ذخیره تنظیمات</span></button></div>
	</div></div>
	<div class="nk-block"><?php KERP_Helpers_Template::render_template( 'app/components/settings/hero.php', [
		'icon' => 'uik-r fa-graduation-cap',
		'eyebrow' => 'ماژول آموزش',
		'title' => 'تمرین‌های درس و مبحث',
		'description' => 'تمرین‌ها در پنل ERP مدیریت می‌شوند و هنرجو پاسخ خود را در تب تمرینِ محتوای آموزشی ثبت می‌کند.',
		'stats' => [ [ 'label' => 'وضعیت پست‌تایپ', 'value' => $enabled ? 'فعال' : 'غیرفعال' ], [ 'label' => 'محل مدیریت', 'value' => 'پنل ERP' ] ],
	] ); ?></div>
	<div class="nk-block"><div class="card card-bordered kerp-appointments-settings-card">
		<div class="card-inner border-bottom"><div class="kerp-appointments-settings-card__head"><span class="kerp-appointments-settings-section-icon"><em class="icon ni ni-power"></em></span><div><h6 class="title mb-1">وضعیت پست‌تایپ تمرین</h6><p class="text-soft mb-0">با غیرفعال‌سازی، تمرین‌ها از پنل هنرجو کنار گذاشته می‌شوند.</p></div></div></div>
		<div class="card-inner"><div class="row g-4">
			<?php KERP_Helpers_Template::render_template( 'app/components/fields/switch.php', [ 'field' => [ 'id' => 'kerp-practice-post-type-enabled', 'name' => 'post_type_enabled', 'label' => 'پست‌تایپ تمرین فعال باشد', 'class' => 'col-12', 'value' => $enabled ] ] ); ?>
			<div class="col-12"><div class="alert alert-light alert-icon mb-0"><em class="icon ni ni-info"></em><div><strong>داده‌های قبلی محفوظ می‌مانند</strong><p class="mb-0 mt-1">در حالت غیرفعال، ساخت و ارسال پاسخ جدید و الزام تأیید تمرین برای تکمیل درس متوقف می‌شود؛ پاسخ‌های قبلی همچنان قابل مشاهده‌اند. تغییر وضعیت از درخواست بعدی سایت اعمال می‌شود.</p></div></div></div>
		</div></div>
	</div></div>
</form>
