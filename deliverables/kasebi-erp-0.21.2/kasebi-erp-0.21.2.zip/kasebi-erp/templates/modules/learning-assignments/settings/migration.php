<?php
defined( 'ABSPATH' ) || exit;

$migration = KERP_Modules_Learning_Assignments_Migration::instance()->status();
$total = (int) $migration['total'];
$migrated = min( $total, (int) $migration['migrated'] );
$remaining = (int) $migration['remaining'];
$percent = $total > 0 ? min( 100, (int) floor( 100 * $migrated / $total ) ) : 100;
?>
<div class="nk-block-head nk-block-head-sm"><div class="nk-block-between">
	<div class="nk-block-head-content"><h3 class="nk-block-title page-title">انتقال پاسخ‌های قدیمی</h3><div class="nk-block-des text-soft"><p>وضعیت انتقال پاسخ‌های تمرین از افزونهٔ قدیمی به جدول جدید ERP.</p></div></div>
	<div class="nk-block-head-content"><a class="btn btn-outline-light page_activator" href="<?php echo esc_url( home_url( '/erp/settings/learning-assignments/post-type/' ) ); ?>" data-url="/erp/settings/learning-assignments/post-type/"><em class="icon ni ni-arrow-right"></em><span>تنظیمات تمرین</span></a></div>
</div></div>
<div class="nk-block"><?php KERP_Helpers_Template::render_template( 'app/components/settings/hero.php', [
	'icon' => 'ni ni-upload-cloud',
	'eyebrow' => 'ماژول آموزش',
	'title' => 'انتقال ایمن پاسخ‌ها',
	'description' => 'پاسخ‌ها و اطلاعات فایل در دسته‌های کوچک کپی می‌شوند. جدول و فایل‌های قبلی بدون تغییر باقی می‌مانند.',
	'stats' => [ [ 'label' => 'پاسخ‌های قدیمی', 'value' => number_format_i18n( $total ) ], [ 'label' => 'باقی‌مانده', 'value' => number_format_i18n( $remaining ) ] ],
] ); ?></div>
<div class="nk-block" id="kerp-practice-migration" data-nonce="<?php echo esc_attr( wp_create_nonce( 'kerp_practice_migrate_legacy' ) ); ?>">
	<div class="card card-bordered kerp-appointments-settings-card">
		<div class="card-inner border-bottom"><div class="kerp-appointments-settings-card__head"><span class="kerp-appointments-settings-section-icon"><em class="icon ni ni-database"></em></span><div><h6 class="title mb-1">پیشرفت انتقال</h6><p class="text-soft mb-0">پس از شروع، دسته‌ها با AJAX پشت‌سرهم منتقل می‌شوند و آمار همین‌جا به‌روز می‌شود.</p></div></div></div>
		<div class="card-inner">
			<?php if ( ! $migration['available'] ) : ?>
				<div class="alert alert-light alert-icon mb-0"><em class="icon ni ni-info"></em><span>جدول پاسخ‌های قدیمی در این سایت پیدا نشد؛ انتقال لازم نیست.</span></div>
			<?php else : ?>
				<div class="row g-3 mb-4">
					<div class="col-sm-4"><span class="sub-text">کل پاسخ‌ها</span><strong class="d-block tb-lead fs-4" data-migration-total><?php echo esc_html( number_format_i18n( $total ) ); ?></strong></div>
					<div class="col-sm-4"><span class="sub-text">منتقل‌شده</span><strong class="d-block tb-lead fs-4 text-success" data-migration-migrated><?php echo esc_html( number_format_i18n( $migrated ) ); ?></strong></div>
					<div class="col-sm-4"><span class="sub-text">باقی‌مانده</span><strong class="d-block tb-lead fs-4" data-migration-remaining><?php echo esc_html( number_format_i18n( $remaining ) ); ?></strong></div>
				</div>
				<div class="d-flex justify-content-between align-items-center mb-2"><span class="sub-text">میزان تکمیل</span><strong data-migration-percent><?php echo esc_html( $percent ); ?>٪</strong></div>
				<div class="progress progress-lg mb-4" role="progressbar" aria-label="پیشرفت انتقال پاسخ‌ها" aria-valuenow="<?php echo esc_attr( $percent ); ?>" aria-valuemin="0" aria-valuemax="100"><div class="progress-bar" data-migration-bar style="width:<?php echo esc_attr( $percent ); ?>%"></div></div>
				<?php if ( $remaining > 0 ) : ?><div class="alert alert-warning alert-icon"><em class="icon ni ni-alert-circle"></em><span>پیش از شروع، ثبت پاسخ در افزونهٔ قدیمی را متوقف کنید. تا پایان انتقال، این صفحه را باز نگه دارید. اگر ارتباط قطع شد، می‌توانید بدون ایجاد پاسخ تکراری دوباره ادامه دهید.</span></div><?php endif; ?>
				<div class="d-flex flex-wrap align-items-center gap-3">
					<button type="button" class="btn btn-primary" data-migration-start <?php disabled( $remaining === 0 ); ?>><em class="icon ni ni-play"></em><span><?php echo $remaining > 0 ? 'شروع انتقال' : 'انتقال کامل شد'; ?></span></button>
					<span class="text-soft" data-migration-message role="status" aria-live="polite"><?php echo $remaining > 0 ? 'آمادهٔ انتقال' : 'همهٔ پاسخ‌های قدیمی منتقل شده‌اند.'; ?></span>
				</div>
			<?php endif; ?>
		</div>
	</div>
	<div class="card card-bordered kerp-appointments-settings-card mt-4"><div class="card-inner border-bottom"><div class="kerp-appointments-settings-card__head"><span class="kerp-appointments-settings-section-icon"><em class="icon ni ni-shield-check"></em></span><div><h6 class="title mb-1">پس از انتقال</h6><p class="text-soft mb-0">اطلاعات قبلی برای کنترل و بازیابی محفوظ می‌مانند.</p></div></div></div><div class="card-inner"><p class="mb-0 text-soft">وضعیت بررسی، نظر، لینک فایل و لاگ پیامکِ موجود به پاسخ جدید منتقل می‌شوند. فایل‌های قدیمی جابه‌جا نمی‌شوند و جدول قدیمی به‌طور خودکار حذف نخواهد شد.</p></div></div>
</div>
