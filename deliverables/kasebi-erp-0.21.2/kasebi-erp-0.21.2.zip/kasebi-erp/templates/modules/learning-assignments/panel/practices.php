<?php
defined( 'ABSPATH' ) || exit;

$post_id = absint( $post_id ?? 0 );
$user_id = get_current_user_id();
$profile_error = KERP_Modules_Learning_Assignments_Module::profile_error( $user_id );
if ( $profile_error ) : ?>
	<div class="kerp-practice-panel">
		<section class="kerp-practice-card kerp-practice-profile-gate" aria-label="تکمیل مشخصات برای ارسال تمرین">
			<header class="kerp-practice-card__header">
				<div class="kerp-practice-card__heading">
					<span class="kerp-practice-card__icon" aria-hidden="true"><em class="hik-r fa-profile-1"></em></span>
					<h3>ابتدا مشخصات خود را تکمیل کنید</h3>
				</div>
			</header>
			<div class="kerp-practice-card__description">
				<p role="status"><?php echo esc_html( $profile_error->get_error_message() ); ?></p>
				<div class="kerp-practice-form__footer">
					<a class="panel_submit_btn kerp-practice-submit kerp-practice-profile-link page_activator" href="<?php echo esc_url( home_url( '/panel/account/' ) ); ?>" data-url="account"><em class="hik-r fa-profile-1" aria-hidden="true"></em><span>تکمیل پروفایل</span><em class="hik-r fa-left-2" aria-hidden="true"></em></a>
				</div>
			</div>
		</section>
	</div>
	<?php return;
endif;
$store = KERP_Modules_Learning_Assignments_Store::instance();
$practices = KERP_Modules_Learning_Assignments_Module::for_item( $post_id );
$labels = [ 'pending' => 'در انتظار بررسی', 'approved' => 'تأییدشده', 'rejected' => 'نیاز به اصلاح', 'changed' => 'جایگزین‌شده' ];
?>
<div class="kerp-practice-panel">
	<div class="kerp-practice-list">
		<?php foreach ( $practices as $practice ) :
			$practice_id = (int) $practice->ID;
			$status = $store->status( $user_id, $practice_id );
			$awaiting_migration = KERP_Modules_Learning_Assignments_Migration::instance()->has_unmigrated_response( $user_id, $practice_id );
			$display_status = $awaiting_migration ? 'migration' : ( $status ?: 'new' );
			$display_label = $awaiting_migration ? 'در حال انتقال' : ( $labels[ $status ] ?? 'ارسال‌نشده' );
			$responses = $store->responses( $user_id, $practice_id, '', 50 );
			$description = wp_kses_post( apply_filters( 'the_content', $practice->post_content ) );
			$file_id = 'kerp-practice-file-' . $practice_id;
			?>
			<section class="kerp-practice-card" aria-labelledby="kerp-practice-title-<?php echo esc_attr( $practice_id ); ?>">
				<header class="kerp-practice-card__header">
					<div class="kerp-practice-card__heading">
						<span class="kerp-practice-card__icon" aria-hidden="true"><em class="hik-r fa-document-align-right-2"></em></span>
						<div><span class="kerp-practice-card__eyebrow">تمرین آموزشی</span><h3 id="kerp-practice-title-<?php echo esc_attr( $practice_id ); ?>"><?php echo esc_html( $practice->post_title ); ?></h3></div>
					</div>
					<span class="kerp-practice-status is-<?php echo esc_attr( $display_status ); ?>"><?php echo esc_html( $display_label ); ?></span>
				</header>
				<?php if ( trim( $description ) !== '' ) : ?><div class="kerp-practice-card__description"><?php echo $description; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div><?php endif; ?>

				<?php if ( $awaiting_migration ) : ?><div class="kerp-practice-notice is-warning" role="status"><em class="hik-r fa-information-circle"></em><span>پاسخ قبلی شما در حال انتقال به سامانهٔ جدید است. پس از انتقال، وضعیت و فایل آن در همین بخش نمایش داده می‌شود.</span></div><?php endif; ?>

				<?php if ( $responses ) : ?>
					<div class="kerp-practice-history">
						<h4>ارسال‌های شما</h4>
						<div class="kerp-practice-history__list">
							<?php foreach ( $responses as $response ) :
								$file_url = maybe_unserialize( $response['file_url'] );
								$file_name = maybe_unserialize( $response['file_name'] );
								$urls = is_array( $file_url ) ? $file_url : [ $file_url ];
								$names = is_array( $file_name ) ? $file_name : [ $file_name ];
								$created_at = ! empty( $response['created_at'] ) ? strtotime( (string) $response['created_at'] ) : FALSE;
								$response_status = (string) ( $response['status'] ?? 'pending' );
								$reviewer_name = KERP_Modules_Learning_Assignments_Module::reviewer_name( $response );
								?>
								<div class="kerp-practice-response">
									<div class="kerp-practice-response__top"><span class="kerp-practice-status is-<?php echo esc_attr( $response_status ); ?>"><?php echo esc_html( $labels[ $response_status ] ?? $response_status ); ?></span><?php if ( $created_at ) : ?><time datetime="<?php echo esc_attr( date( 'c', $created_at ) ); ?>"><?php echo esc_html( date_i18n( 'Y/m/d H:i', $created_at ) ); ?></time><?php endif; ?></div>
									<div class="kerp-practice-response__files">
								<?php foreach ( $urls as $index => $url ) : if ( ! is_scalar( $url ) || ! $url ) { continue; } $name = $names[ $index ] ?? 'فایل تمرین'; $resolved_url = KERP_Modules_Learning_Assignments_File_Availability::resolve_url( (string) $url ); if ( $resolved_url === '' ) { continue; } ?><a href="<?php echo esc_url( $resolved_url ); ?>" target="_blank" rel="noopener noreferrer"><em class="hik-r fa-download" aria-hidden="true"></em><span><?php echo esc_html( is_scalar( $name ) ? (string) $name : 'فایل تمرین' ); ?></span></a><?php endforeach; ?>
									</div>
									<?php if ( $reviewer_name !== '' || ! empty( $response['file_comment'] ) || ! empty( $response['file_comment_url'] ) ) : ?>
										<div class="kerp-practice-feedback">
											<?php if ( $reviewer_name !== '' || ! empty( $response['file_comment'] ) ) : ?><strong><?php echo esc_html( $reviewer_name !== '' ? $reviewer_name : 'نظر ثبت‌شده' ); ?></strong><?php endif; ?>
											<?php if ( ! empty( $response['file_comment'] ) ) : ?><p><?php echo nl2br( esc_html( (string) $response['file_comment'] ) ); ?></p><?php endif; ?>
											<?php $review_attachment_url = KERP_Modules_Learning_Assignments_File_Availability::resolve_url( (string) ( $response['file_comment_url'] ?? '' ) ); ?>
											<?php if ( $review_attachment_url !== '' ) : ?><a href="<?php echo esc_url( $review_attachment_url ); ?>" target="_blank" rel="noopener noreferrer"><em class="hik-r fa-attachment" aria-hidden="true"></em>دریافت پیوست بررسی</a><?php endif; ?>
										</div>
									<?php endif; ?>
								</div>
							<?php endforeach; ?>
						</div>
					</div>
				<?php endif; ?>

				<?php if ( ! $awaiting_migration && ( $status === '' || $status === 'rejected' ) ) : ?>
					<form class="kerp-practice-form" enctype="multipart/form-data">
						<input type="hidden" name="item_id" value="<?php echo esc_attr( $post_id ); ?>">
						<input type="hidden" name="practice_id" value="<?php echo esc_attr( $practice_id ); ?>">
						<div class="kerp-practice-form__intro"><strong><?php echo $status === 'rejected' ? 'ارسال نسخهٔ اصلاح‌شده' : 'ارسال پاسخ تمرین'; ?></strong><span>تا ۱۰۰ فایل انتخاب کنید؛ حداکثر حجم هر فایل ۲۰ مگابایت است و فایل RAR نیز پذیرفته می‌شود.</span></div>
						<div class="kerp-practice-upload">
							<input id="<?php echo esc_attr( $file_id ); ?>" type="file" name="practice_file" class="kerp-practice-upload__input" multiple>
							<label class="kerp-practice-upload__picker" for="<?php echo esc_attr( $file_id ); ?>">
								<span class="kerp-practice-upload__button"><em class="hik-r fa-upload" aria-hidden="true"></em>انتخاب فایل‌ها</span>
								<span class="kerp-practice-upload__placeholder">هنوز فایلی انتخاب نشده</span>
							</label>
							<div class="kerp-practice-upload__files" aria-live="polite"></div>
						</div>
						<div class="kerp-practice-form__footer"><span class="kerp-practice-message" role="status" aria-live="polite"></span><button class="panel_submit_btn btn_second_style kerp-practice-submit" type="submit"><em class="hik-r fa-send-2" aria-hidden="true"></em><span><?php echo $status === 'rejected' ? 'ارسال دوباره' : 'ارسال تمرین'; ?></span></button></div>
					</form>
				<?php endif; ?>
			</section>
		<?php endforeach; ?>
	</div>
	<div class="kerp-practice-panel__note"><em class="hik-r fa-information-circle" aria-hidden="true"></em><span>این درس یا مبحث پس از تأیید همهٔ تمرین‌های آن تکمیل می‌شود.</span></div>
</div>
