<?php
defined( 'ABSPATH' ) || exit;
if ( ! KERP_Modules_Learning_Assignments_Settings::instance()->post_type_enabled() ) : ?>
<div class="nk-block-head nk-block-head-sm"><h3 class="nk-block-title page-title">تمرین‌ها</h3></div>
<div class="nk-block"><div class="card card-bordered"><div class="card-inner text-center py-5"><em class="icon ni ni-alert-circle fs-1 text-soft"></em><h5 class="mt-3 mb-1">پست‌تایپ تمرین غیرفعال است.</h5><p class="text-soft mb-0">داده‌های قبلی حذف نشده‌اند. برای مدیریت دوبارهٔ تمرین‌ها، پست‌تایپ را از تنظیمات فعال کنید.</p><?php if ( kerp_can( 'learning_assignments.manage_settings', 'action' ) ) : ?><a class="btn btn-outline-primary page_activator mt-3" href="<?php echo esc_url( home_url( '/erp/settings/learning-assignments/post-type/' ) ); ?>" data-url="/erp/settings/learning-assignments/post-type/">تنظیمات تمرین</a><?php endif; ?></div></div></div>
<?php return; endif;
$page_query  = isset( $page_context['query'] ) && is_array( $page_context['query'] ) ? $page_context['query'] : [];
$route       = '/erp/learning-assignments/';
$per_page    = KERP_Helpers_Pagination::resolve_per_page( 'learning_assignments', $page_query, 20 );
$page_number = max( 1, absint( $page_query['page_number'] ?? 1 ) );
$search      = sanitize_text_field( (string) ( $page_query['search'] ?? '' ) );
$status      = sanitize_key( (string) ( $page_query['status'] ?? '' ) );
$item_id     = absint( $page_query['item_id'] ?? 0 );
$args        = [
	'post_type'      => KERP_Modules_Learning_Assignments_Module::POST_TYPE,
	'post_status'    => in_array( $status, [ 'publish', 'draft' ], TRUE ) ? $status : [
		'publish',
		'draft',
	],
	'posts_per_page' => $per_page,
	'paged'          => $page_number,
	'orderby'        => 'date',
	'order'          => 'DESC',
	's'              => $search,
];
if ( $item_id ) {
	$args['meta_query'] = [
		[
			'key'     => KERP_Modules_Learning_Assignments_Module::CONNECTED_META,
			'value'   => $item_id,
			'compare' => '=',
		],
	];
}
$query        = new WP_Query( $args );
$items        = get_posts( [
	'post_type'      => [ 'sfwd-lessons', 'sfwd-topic' ],
	'post_status'    => 'publish',
	'posts_per_page' => - 1,
	'orderby'        => 'title',
	'order'          => 'ASC',
] );
$item_options = [];
foreach ( $items as $item ) {
	$item_options[ $item->ID ] = ( $item->post_type === 'sfwd-topic' ? 'مبحث: ' : 'درس: ' ) . $item->post_title;
}
$filters      = [
	'search'  => [ 'type' => 'search', 'label' => 'جستجوی تمرین', 'value' => $search, 'placeholder' => 'عنوان تمرین' ],
	'status'  => [
		'type'    => 'select',
		'label'   => 'وضعیت',
		'value'   => $status,
		'options' => [ 'publish' => 'منتشرشده', 'draft' => 'پیش‌نویس' ],
	],
	'item_id' => [
		'type'    => 'select',
		'label'   => 'درس یا مبحث',
		'value'   => $item_id,
		'options' => $item_options,
		'search'  => TRUE,
	],
];
$new_populate = [
	'practice_id' => [ 'id' => '#kerp-practice-id', 'type' => 'text', 'value' => 0 ],
	'title'       => [ 'id' => '#kerp-practice-title', 'type' => 'text', 'value' => '' ],
	'content'     => [ 'id' => '#kerp-practice-content', 'type' => 'quill', 'value' => '' ],
	'item_id'     => [
		'id'    => '#kerp-practice-item',
		'type'  => 'learndash-search',
		'value' => 0,
		'label' => '',
	],
	'post_status' => [ 'id' => '#kerp-practice-status', 'type' => 'select', 'value' => 'publish' ],
	'sms_rejected_pattern' => [ 'id' => '#kerp-practice-sms-rejected-pattern', 'type' => 'text', 'value' => '' ],
	'sms_rejected_variables' => [ 'id' => '#kerp-practice-sms-rejected-variables', 'type' => 'text', 'value' => '' ],
	'sms_unlock_pattern' => [ 'id' => '#kerp-practice-sms-unlock-pattern', 'type' => 'text', 'value' => '' ],
	'sms_unlock_variables' => [ 'id' => '#kerp-practice-sms-unlock-variables', 'type' => 'text', 'value' => '' ],
];
?>
<div class="nk-block-head nk-block-head-sm">
    <div class="nk-block-between">
        <div class="nk-block-head-content"><h3 class="nk-block-title page-title">تمرین‌ها</h3>
            <div class="nk-block-des text-soft"><p>در
                    مجموع <?php echo esc_html( number_format_i18n( $query->found_posts ) ); ?> تمرین یافت شد.</p></div>
        </div>
        <div class="nk-block-head-content">
            <button type="button" class="btn btn-primary open_populate_modal" data-modal="#kerp-practice-modal"
                    data-modal-title="تمرین جدید"
                    data-populate="<?php echo esc_attr( wp_json_encode( $new_populate ) ); ?>"><em
                    class="icon ni ni-plus"></em><span>تمرین جدید</span></button>
        </div>
    </div>
</div>
<div class="nk-block">
    <div class="card card-stretch">
        <div class="card-inner-group">
            <div class="card-inner position-relative card-tools-toggle">
                <div class="card-title-group">
                    <div
                        class="card-tools"><?php echo KERP_Helpers_Template::get_template( 'app/components/list/bulk-actions.php', [
							'actions' => [
								'publish' => [
									'label' => 'انتشار',
									'icon'  => 'ni ni-check-circle',
								],
								'draft'   => [
									'label' => 'انتقال به پیش‌نویس',
									'icon'  => 'ni ni-edit',
								],
							],
							'action'  => 'kerp_practice_bulk',
							'page'    => $route,
						] ); ?></div>
                    <div class="card-tools">
                        <ul class="btn-toolbar gx-1">
                            <li><?php echo KERP_Helpers_Template::get_template( 'app/components/list/filter-dropdown.php', [
									'has_filter'    => $search !== '' || $status !== '' || $item_id > 0,
									'filter_fields' => $filters,
									'page'          => $route,
								] ); ?></li>
                            <li class="btn-toolbar-sep"></li>
                            <li><?php echo KERP_Helpers_Template::get_template( 'app/components/list/per-page-selector.php', [
									'per_page' => $per_page,
									'page'     => $route,
								] ); ?></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="card-inner p-0">
                <div class="nk-tb-list nk-tb-ulist is-compact">
                    <div class="nk-tb-item nk-tb-head">
                        <div class="nk-tb-col nk-tb-col-check">
                            <div class="custom-control custom-control-sm custom-checkbox notext"><input type="checkbox"
                                                                                                        class="custom-control-input select_all_rows"
                                                                                                        id="kerp-practice-select-all"
                                                                                                        data-target=".select_item_row"><label
                                    class="custom-control-label" for="kerp-practice-select-all"></label></div>
                        </div>
                        <div class="nk-tb-col">تمرین</div>
                        <div class="nk-tb-col">مبحث</div>
                        <div class="nk-tb-col">دوره</div>
                        <div class="nk-tb-col">تاریخ انتشار</div>
                        <div class="nk-tb-col">وضعیت</div>
                        <div class="nk-tb-col nk-tb-col-tools"></div>
                    </div>
					<?php foreach ( $query->posts as $practice ) :
						$connected_id = absint( get_post_meta( $practice->ID, KERP_Modules_Learning_Assignments_Module::CONNECTED_META, TRUE ) );
						$connected_title = $connected_id ? get_the_title( $connected_id ) : '';
						$course_id = KERP_Modules_Learning_Assignments_Module::course_id_for_item( $connected_id );
						$course_title = $course_id ? get_the_title( $course_id ) : '';
						$published_at = $practice->post_status === 'publish' ? get_the_date( 'Y/m/d H:i', $practice ) : '';
						$populate = [
							'practice_id' => [
								'id'    => '#kerp-practice-id',
								'type'  => 'text',
								'value' => $practice->ID,
							],
							'title'       => [
								'id'    => '#kerp-practice-title',
								'type'  => 'text',
								'value' => $practice->post_title,
							],
							'content'     => [
								'id'    => '#kerp-practice-content',
								'type'  => 'quill',
								'value' => $practice->post_content,
							],
							'item_id'     => [
								'id'    => '#kerp-practice-item',
								'type'  => 'learndash-search',
								'value' => $connected_id,
								'label' => $connected_title,
							],
							'post_status' => [
								'id'    => '#kerp-practice-status',
								'type'  => 'select',
								'value' => $practice->post_status,
							],
							'sms_rejected_pattern' => [ 'id' => '#kerp-practice-sms-rejected-pattern', 'type' => 'text', 'value' => get_post_meta( $practice->ID, KERP_Modules_Learning_Assignments_Module::SMS_REJECTED_PATTERN_META, TRUE ) ],
							'sms_rejected_variables' => [ 'id' => '#kerp-practice-sms-rejected-variables', 'type' => 'text', 'value' => get_post_meta( $practice->ID, KERP_Modules_Learning_Assignments_Module::SMS_REJECTED_VARIABLES_META, TRUE ) ],
							'sms_unlock_pattern' => [ 'id' => '#kerp-practice-sms-unlock-pattern', 'type' => 'text', 'value' => get_post_meta( $practice->ID, KERP_Modules_Learning_Assignments_Module::SMS_UNLOCK_PATTERN_META, TRUE ) ],
							'sms_unlock_variables' => [ 'id' => '#kerp-practice-sms-unlock-variables', 'type' => 'text', 'value' => get_post_meta( $practice->ID, KERP_Modules_Learning_Assignments_Module::SMS_UNLOCK_VARIABLES_META, TRUE ) ],
						]; ?>
                        <div class="nk-tb-item">
                            <div class="nk-tb-col nk-tb-col-check">
                                <div class="custom-control custom-control-sm custom-checkbox notext"><input
                                        type="checkbox" class="custom-control-input select_item_row"
                                        id="kerp-practice-<?php echo esc_attr( $practice->ID ); ?>"
                                        value="<?php echo esc_attr( $practice->ID ); ?>"><label
                                        class="custom-control-label"
                                        for="kerp-practice-<?php echo esc_attr( $practice->ID ); ?>"></label></div>
                            </div>
                            <div class="nk-tb-col"><span
                                    class="tb-lead"><?php echo esc_html( $practice->post_title ); ?></span></div>
                            <div class="nk-tb-col"><?php echo esc_html( $connected_title ?: '—' ); ?></div>
                            <div class="nk-tb-col"><?php echo esc_html( $course_title ?: '—' ); ?></div>
                            <div class="nk-tb-col"><?php if ( $published_at ) : ?><span class="d-flex align-items-center"><em class="icon ni ni-calendar text-soft me-1"></em><?php echo esc_html( $published_at ); ?></span><?php else : ?><span class="text-soft">منتشر نشده</span><?php endif; ?></div>
                            <div class="nk-tb-col"><span
                                    class="badge badge-dim bg-<?php echo $practice->post_status === 'publish' ? 'success' : 'warning'; ?>"><?php echo $practice->post_status === 'publish' ? 'منتشرشده' : 'پیش‌نویس'; ?></span>
                            </div>
                            <div
                                class="nk-tb-col nk-tb-col-tools"><?php echo KERP_Helpers_Template::get_template( 'app/components/list/row-actions.php', [
									'actions' => [
										'edit' => [
											'title' => 'ویرایش',
											'icon'  => 'ni ni-edit',
											'class' => 'edit_row_item',
											'data'  => [
												'modal'       => '#kerp-practice-modal',
												'modal-title' => 'ویرایش تمرین',
												'populate'    => $populate,
											],
										],
									],
								] ); ?></div>
                        </div>
					<?php endforeach; ?>
					<?php if ( ! $query->posts ) : ?></div>
                <div class="card-inner text-center py-5">
                    <div class="nk-block-content"><em class="icon ni ni-list-check fs-1 text-soft"></em><h5
                            class="mt-3 mb-1">تمرینی یافت نشد.</h5>
                        <p class="text-soft mb-0"><?php echo $search !== '' || $status !== '' || $item_id ? 'فیلترها را تغییر دهید یا بازنشانی کنید.' : 'برای شروع، تمرین جدیدی ثبت کنید.'; ?></p>
                    </div>
                </div>
                <div><?php endif; ?></div>
            </div>
			<?php if ( $query->max_num_pages > 1 ) : ?>
                <div
                    class="card-inner"><?php echo KERP_Helpers_Template::get_template( 'app/components/list/pagination.php', [
					'max_page_num' => $query->max_num_pages,
					'current_page' => $page_number,
					'page'         => $route,
				] ); ?></div><?php endif; ?>
        </div>
    </div>
</div>
<?php KERP_Helpers_Template::render_modal( [
	'id'     => 'kerp-practice-modal',
	'title'  => 'تمرین جدید',
	'action' => 'kerp_practice_save',
	'page'   => $route,
	'button' => 'ذخیره تمرین',
	'body' => KERP_Helpers_Template::get_template( 'modules/learning-assignments/partials/practice-form-fields.php' ),
] ); ?>
