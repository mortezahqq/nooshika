<?php
defined( 'ABSPATH' ) || exit;
$page_query = isset( $page_context['query'] ) && is_array( $page_context['query'] ) ? $page_context['query'] : [];
$route      = '/erp/learning-assignments/reviews/';
$store      = KERP_Modules_Learning_Assignments_Store::instance();
$migration  = KERP_Modules_Learning_Assignments_Migration::instance()->status();
$enabled    = KERP_Modules_Learning_Assignments_Settings::instance()->post_type_enabled();
$status     = sanitize_key( (string) ( $page_query['status'] ?? 'all' ) );
if ( ! in_array( $status, [ 'pending', 'approved', 'rejected', 'changed', 'all' ], TRUE ) ) {
	$status = 'all';
}
$practice_id      = absint( $page_query['practice_id'] ?? 0 );
$user_id          = absint( $page_query['user_id'] ?? 0 );
$per_page         = KERP_Helpers_Pagination::resolve_per_page( 'learning_assignment_reviews', $page_query, 20 );
$page_number      = max( 1, absint( $page_query['page_number'] ?? 1 ) );
$total            = $store->count_responses( $user_id, $practice_id, $status === 'all' ? '' : $status, TRUE );
$max_pages        = max( 1, (int) ceil( $total / $per_page ) );
$page_number      = min( $page_number, $max_pages );
$rows             = $store->responses( $user_id, $practice_id, $status === 'all' ? '' : $status, $per_page, ( $page_number - 1 ) * $per_page, TRUE );
$review_return_route = add_query_arg( [
	'status'      => $status,
	'practice_id' => $practice_id,
	'user_id'     => $user_id,
	'per_page'    => $per_page,
	'page_number' => $page_number,
], $route );
$labels           = [
	'pending'  => 'در انتظار بررسی',
	'approved' => 'تأییدشده',
	'rejected' => 'ردشده',
	'changed'  => 'جایگزین‌شده',
];
$singular_label   = KERP_Modules_Customers_Settings::instance()->get_singular_label();
$column_context   = [ 'singular_label' => $singular_label, 'enabled' => $enabled, 'route' => $route ];
$columns          = KERP_Modules_Learning_Assignments_Module::review_columns( $column_context );
$practice_options = [];
$review_practice_ids = $store->review_practice_ids();
foreach (
	get_posts( [
		'post_type'      => KERP_Modules_Learning_Assignments_Module::POST_TYPE,
		'post_status'    => [ 'publish', 'draft' ],
		'posts_per_page' => - 1,
		'post__in'       => $review_practice_ids ?: [ 0 ],
	] ) as $practice
) {
	$practice_options[ $practice->ID ] = $practice->post_title;
}
$filters = [
	'status'      => [ 'type' => 'select', 'label' => 'وضعیت', 'value' => $status, 'options' => $labels ],
	'practice_id' => [
		'type'    => 'select',
		'label'   => 'تمرین',
		'value'   => $practice_id,
		'options' => $practice_options,
		'search'  => TRUE,
	],
];
?>
<div class="nk-block-head nk-block-head-sm">
    <div class="nk-block-between">
        <div class="nk-block-head-content"><h3 class="nk-block-title page-title">بررسی پاسخ‌های تمرین</h3>
            <div class="nk-block-des text-soft"><p>در مجموع <?php echo esc_html( number_format_i18n( $total ) ); ?> پاسخ
                    یافت شد.</p></div>
        </div>
    </div>
</div>
<?php if ( ! $enabled ) : ?>
    <div class="nk-block">
        <div class="alert alert-warning alert-icon"><em class="icon ni ni-alert-circle"></em><span>پست‌تایپ تمرین غیرفعال است؛ پاسخ‌های قبلی فقط قابل مشاهده‌اند.</span>
        </div>
    </div><?php endif; ?>
<?php if ( $migration['remaining'] > 0 ) : ?>
    <div class="nk-block">
    <div class="alert alert-warning alert-icon"><em
            class="icon ni ni-alert-circle"></em><span><?php echo esc_html( number_format_i18n( $migration['remaining'] ) ); ?> پاسخ قدیمی هنوز منتقل نشده است و در این فهرست نمایش داده نمی‌شود. <?php if ( kerp_can( 'learning_assignments.manage_settings', 'action' ) ) : ?>
            <a class="page_activator"
               href="<?php echo esc_url( home_url( '/erp/settings/learning-assignments/migration/' ) ); ?>"
               data-url="/erp/settings/learning-assignments/migration/">
                    صفحهٔ انتقال پاسخ‌ها</a><?php endif; ?></span></div></div><?php endif; ?>
<div class="nk-block">
    <div class="card card-stretch">
        <div class="card-inner-group">
            <div class="card-inner position-relative card-tools-toggle">
                <div class="card-title-group">
                    <div class="card-tools"><?php if ( $enabled ) {
							echo KERP_Helpers_Template::get_template( 'app/components/list/bulk-actions.php', [
								'actions'     => [
									'approved' => [
										'label' => 'تأیید پاسخ‌ها',
										'icon'  => 'ni ni-check-circle',
									],
									'rejected' => [
										'label' => 'رد پاسخ‌ها',
										'icon'  => 'ni ni-cross-circle',
										'need'  => [ 'comment' ],
									],
								],
								'need_fields' => [
									'comment' => [
										'type'     => 'textarea',
										'label'    => 'دلیل رد',
										'required' => TRUE,
									],
								],
								'action'      => 'kerp_practice_review_bulk',
								'page'        => $review_return_route,
							] );
						} ?></div>
                    <div class="card-tools">
                        <ul class="btn-toolbar gx-1">
                            <li><?php echo KERP_Helpers_Template::get_template( 'app/components/list/filter-dropdown.php', [
									'has_filter'    => $status !== 'all' || $practice_id > 0 || $user_id > 0,
									'filter_fields' => $filters,
									'page'          => $route,
								] ); ?></li>
                            <li class="btn-toolbar-sep"></li>
                            <li><?php echo KERP_Helpers_Template::get_template( 'app/components/list/per-page-selector.php', [
									'per_page' => $per_page,
									'page'     => $route,
								] ); ?></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="card-inner p-0">
                <div class="nk-tb-list nk-tb-ulist is-compact kerp-practice-reviews-table">
                    <div class="nk-tb-item nk-tb-head">
						<?php foreach ( $columns as $column_key => $column ) : $column_class = sanitize_text_field( (string) ( $column['class'] ?? '' ) ); ?>
                        <div class="nk-tb-col <?php echo esc_attr( trim( $column_class . ' kerp-review-col kerp-review-col--' . sanitize_html_class( (string) $column_key ) ) ); ?>">
							<?php if ( ! empty( $column['header_callback'] ) && is_callable( $column['header_callback'] ) ) : call_user_func( $column['header_callback'], $column, $column_context );
                            elseif ( $column_key === 'select' ) : ?>
                                <div class="custom-control custom-control-sm custom-checkbox notext"><input
                                        type="checkbox" class="custom-control-input select_all_rows"
                                        id="kerp-review-select-all"
                                        data-target=".select_item_row" <?php disabled( ! $enabled ); ?>><label
                                        class="custom-control-label" for="kerp-review-select-all"></label></div>
							<?php else : ?><span
                                class="sub-text"><?php echo esc_html( (string) ( $column['label'] ?? $column_key ) ); ?></span><?php endif; ?>
                            </div><?php endforeach; ?></div>
					<?php foreach ( $rows as $row ) {
						KERP_Helpers_Template::render_template( 'modules/learning-assignments/partials/review-row.php', [
							'row'            => $row,
							'labels'         => $labels,
							'enabled'        => $enabled,
							'singular_label' => $singular_label,
							'columns'        => $columns,
							'column_context' => $column_context,
						] );
					} ?>
					<?php if ( ! $rows ) : ?></div>
                <div class="card-inner text-center py-5">
                    <div class="nk-block-content"><em class="icon ni ni-file-text fs-1 text-soft"></em><h5
                            class="mt-3 mb-1">پاسخی یافت نشد.</h5>
                        <p class="text-soft mb-0"><?php echo $status !== 'all' || $practice_id || $user_id ? 'فیلترها را تغییر دهید یا بازنشانی کنید.' : 'هنوز پاسخی برای تمرین‌ها ارسال نشده است.'; ?></p>
                    </div>
                </div>
                <div><?php endif; ?></div>
            </div>
			<?php if ( $max_pages > 1 ) : ?>
                <div
                    class="card-inner"><?php echo KERP_Helpers_Template::get_template( 'app/components/list/pagination.php', [
					'max_page_num' => $max_pages,
					'current_page' => $page_number,
					'page'         => $route,
				] ); ?></div><?php endif; ?>
        </div>
    </div>
</div>
<?php if ( $enabled ) {
	KERP_Helpers_Template::render_template( 'modules/learning-assignments/partials/review-modal.php', [ 'route' => $review_return_route ] );
} ?>
