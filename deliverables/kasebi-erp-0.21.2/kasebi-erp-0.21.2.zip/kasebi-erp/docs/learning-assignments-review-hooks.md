# هوک‌های جدول پاسخ‌های تمرین

جدول «بررسی پاسخ‌های تمرین» هدر و ردیف‌ها را از یک آرایهٔ مشترک ستون‌ها می‌سازد. کلیدهای پیش‌فرض به‌ترتیب عبارت‌اند از `select`، `customer`، `practice`، `files`، `result` و `tools`.

## ستون‌ها

فیلتر `kerp_learning_assignments_review_columns` دو آرگومان می‌گیرد: آرایهٔ ستون‌ها و context جدول (`singular_label`، `enabled` و `route`). با تغییر ترتیب کلیدها، ترتیب هدر و ردیف با هم عوض می‌شود. حذف کلید، ستون را حذف می‌کند. هر ستون می‌تواند `label`، `class`، `header_callback` و `callback` داشته باشد. `header_callback( $column, $context )` و `callback( $row, $column, $context )` باید محتوای HTML داخل سلول را چاپ کنند. تعیین `callback` برای یک ستون پیش‌فرض، محتوای اصلی آن را جایگزین می‌کند. اگر ستونی callback نداشته باشد، اکشن `kerp_learning_assignments_review_column_{key}` با آرگومان‌های همان callback اجرا می‌شود.

```php
add_filter( 'kerp_learning_assignments_review_columns', function ( array $columns, array $context ): array {
	$tools = $columns['tools'];
	unset( $columns['tools'] );
	$columns['score'] = [
		'label' => 'امتیاز',
		'class' => 'tb-col-md',
		'callback' => static function ( array $row, array $column, array $context ): void {
			echo esc_html( (string) get_post_meta( (int) $row['practice_id'], '_sample_score', TRUE ) );
		},
	];
	$columns['tools'] = $tools;
	return $columns;
}, 10, 2 );
```

Context هر سلول علاوه بر مقادیر جدول، `files`، `status`، `practice_title`، `item_title`، `lesson_title`، `course_title`، `has_result` و `created_label` را دارد. کلاس `tb-col-md` ستون را در عرض‌های کمتر از ۷۶۸ پیکسل پنهان می‌کند؛ برای ستون سفارشی، نمایش موبایل را نیز در نظر بگیرید.

محتوای ستون مشتری پس از ساخت کارت استاندارد از فیلتر `kerp_learning_assignments_review_customer_content` عبور می‌کند. آرگومان‌ها به‌ترتیب HTML کارت، ردیف پاسخ و context سلول هستند. خود ERP محتوای اضافه‌ای به این فیلتر متصل نمی‌کند؛ افزونهٔ بیرونی می‌تواند با `add_filter` اطلاعات موردنیاز را زیر کارت اضافه کند. این فیلتر فقط برای کاربر موجود اجرا می‌شود؛ `callback` ستون `customer` همچنان کل محتوای پیش‌فرض را جایگزین می‌کند.

```php
add_filter( 'kerp_learning_assignments_review_customer_content', static function ( string $html, array $row, array $context ): string {
	return $html . '<span class="text-soft">شناسه پاسخ: ' . esc_html( (string) $row['id'] ) . '</span>';
}, 10, 3 );
```

## آیکون‌ها

`kerp_learning_assignments_review_icons` سه آرگومان می‌گیرد: نگاشت آیکون‌های پیش‌فرض، ردیف پاسخ و context سلول. کلیدها `topic`، `lesson`، `course`، `file`، `download`، `review`، `metadata` و `status` هستند؛ `status` خودش نگاشتی از وضعیت به کلاس آیکون است.

`kerp_learning_assignments_review_row_icons` سه آرگومان می‌گیرد: آیکون‌های ستون آخر، ردیف پاسخ و context. آیکون‌های پیش‌فرض `customer` (مشاهده پروفایل)، `owner` (مسئول مشتری)، `date`، `comment` و `attachment` هستند؛ دو آیکون اول برای مشتری حذف‌شده ساخته نمی‌شوند. ساختار هر آیتم مانند کامپوننت مشترک `app/components/list/row-icons.php` است (`icon`، `tooltip`، `class`، `url` و `data`).

```php
add_filter( 'kerp_learning_assignments_review_row_icons', function ( array $icons, array $row, array $context ): array {
	$icons['external'] = [
		'icon' => 'ni ni-info',
		'tooltip' => 'شناسه پاسخ: ' . (int) $row['id'],
	];
	return $icons;
}, 10, 3 );
```
