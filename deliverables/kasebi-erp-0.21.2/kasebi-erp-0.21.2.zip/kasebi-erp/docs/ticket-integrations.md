# Ticket integrations

Use `KERP_Modules_Tickets_Service::create($data)` for an authenticated customer's
request. `user_id` must match the current user. Pass `false` as the second argument
for ERP staff creation, subject to the existing ticket permission and customer scope.
Call after the submitting form's authentication and request validation; this is a
PHP service, not an AJAX endpoint or an authentication mechanism.

Data accepts `user_id`, `subject`, `message`, optional `priority` (normal by default),
`meta` (including a configured `department`), and `msg_meta` (including `attachment`,
an array of already uploaded HTTP(S) file URLs). Use `KERP_Helpers_File` for uploads.
Structured custom metadata is preserved. Reserved workflow metadata cannot be overridden.

`KERP_Modules_Tickets_Service::reply($data)` checks ERP reply permissions and ticket
scope. Data contains `ticket_id`, `message`, and message `meta` (e.g. `order_id`).
Its optional second argument enables customer mode, limited to the current customer's
own ticket. Sender always comes from the authenticated user.

Both return `status`, `message`, and `data` (`id` is the ERP ticket ID,
`message_id` is the newly created ERP message ID). Failures return `status: error`.
Writes are transactional; notifications run after commit. Legacy IDs must not be
passed as live ERP IDs. Existing migration retains them separately.

Read custom ticket metadata with `KERP_Modules_Tickets_Store::meta('ticket', $id, $key)`.
Read values across messages with `KERP_Modules_Tickets_Store::message_meta_values($id, $key)`.

The chat template fires these actions only after ticket access is verified, in both
ERP and the customer panel. Arguments are `(int $ticket_id, array $ticket, bool $public)`:

- `kasebi_ticket_header_meta`: inside the header metadata list; callbacks emit `<li>` elements.
- `kasebi_before_render_ticket`: before the conversation messages; callbacks emit their detail blocks.
- `kasebi_after_render_ticket`: after the conversation messages, before the composer.

Callback output must escape custom values. Old `nooshika_ticket_header_meta` and
`before_render_ticket` callbacks should register the new names and use ERP IDs/storage.
