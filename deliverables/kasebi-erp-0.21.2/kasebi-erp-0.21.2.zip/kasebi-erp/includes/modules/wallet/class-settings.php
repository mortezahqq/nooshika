<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Wallet_Settings {
	
	private const OPTION     = 'kerp_wallet_charge_settings';
	
	public const  MAX_AMOUNT = 99999999;
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		return self::$instance ??= new self();
	}
	
	private function __construct() {
		add_action( 'kasebi_ajax_wallet_save_settings', [ $this, 'save' ] );
	}
	
	public function get(): array {
		$defaults = [
			'enabled'                    => TRUE,
			'minimum'                    => 1.0,
			'maximum'                    => (float) self::MAX_AMOUNT,
			'presets'                    => [ 100000.0, 500000.0, 1000000.0 ],
			'payment_max_percentage'     => 100.0,
			'payment_max_amount'         => 0.0,
			'withdrawal_enabled'         => FALSE,
			'withdrawal_minimum_balance' => 0.0,
			'withdrawal_debit_timing'    => 'approval',
			'withdrawal_terms'           => '',
			'withdrawal_fields'          => [],
		];
		$saved    = get_option( self::OPTION, [] );
		
		return array_replace( $defaults, is_array( $saved ) ? $saved : [] );
	}
	
	public function limits( int $user_id ): array {
		$settings = $this->get();
		$min      = (float) apply_filters( 'kerp_wallet_charge_min_amount', $settings['minimum'], $user_id );
		$max      = (float) apply_filters( 'kerp_wallet_charge_max_amount', $settings['maximum'], $user_id );
		
		return [ max( 1, $min ), min( self::MAX_AMOUNT, $max > 0 ? $max : self::MAX_AMOUNT ) ];
	}
	
	public function validate( array $input ): array|WP_Error {
		$service = KERP_Modules_Wallet_Service::instance();
		$current = $this->get();
		$minimum = $service->parse_amount( $input['minimum'] ?? '' );
		$maximum = $service->parse_amount( $input['maximum'] ?? '' );
		foreach ( [ $minimum, $maximum ] as $amount ) {
			if ( is_wp_error( $amount ) || $amount < 1 || $amount > self::MAX_AMOUNT || (float) wc_format_decimal( $amount, wc_get_price_decimals() ) !== $amount ) {
				return new WP_Error( 'invalid_limits', 'حداقل و حداکثر شارژ را به صورت مبلغ معتبر وارد کنید.' );
			}
		}
		if ( $maximum < $minimum ) {
			return new WP_Error( 'invalid_limits', 'حداکثر شارژ نباید کمتر از حداقل باشد.' );
		}
		$presets = $input['presets'] ?? [];
		if ( ! is_array( $presets ) || count( $presets ) > 20 ) {
			return new WP_Error( 'invalid_presets', 'حداکثر ۲۰ مبلغ پیشنهادی قابل ثبت است.' );
		}
		$clean = [];
		foreach ( $presets as $value ) {
			if ( is_string( $value ) && trim( $value ) === '' ) {
				continue;
			}
			$amount = $service->parse_amount( $value );
			if ( is_wp_error( $amount ) || $amount < $minimum || $amount > $maximum || (float) wc_format_decimal( $amount, wc_get_price_decimals() ) !== $amount ) {
				return new WP_Error( 'invalid_preset', 'مبالغ پیشنهادی باید معتبر و در محدوده حداقل و حداکثر شارژ باشند.' );
			}
			if ( ! in_array( $amount, $clean, TRUE ) ) {
				$clean[] = $amount;
			}
		}
		if ( ! in_array( $input['enabled'] ?? '', [ '0', '1' ], TRUE ) ) {
			return new WP_Error( 'invalid_enabled', 'وضعیت فعال بودن شارژ معتبر نیست.' );
		}
		$percentage_value = $input['payment_max_percentage'] ?? $current['payment_max_percentage'];
		$percentage_raw   = is_scalar( $percentage_value )
			? KERP_Helpers_Format::sanitize_numbers( (string) $percentage_value )
			: '';
		$percentage       = filter_var( $percentage_raw, FILTER_VALIDATE_FLOAT );
		if ( $percentage === FALSE || $percentage <= 0 || $percentage > 100 ) {
			return new WP_Error( 'invalid_payment_percentage', 'حداکثر درصد پرداخت با کیف پول باید عددی بین ۱ تا ۱۰۰ باشد.' );
		}
		$payment_max_value = $input['payment_max_amount'] ?? $current['payment_max_amount'];
		$payment_max_raw   = is_scalar( $payment_max_value ) ? trim( KERP_Helpers_Format::sanitize_numbers( (string) $payment_max_value ) ) : '';
		if ( $payment_max_raw === '' || preg_match( '/^0(?:[.,]0+)?$/', str_replace( [ ',', '٬', '٫' ], [
				'',
				'',
				'.',
			], $payment_max_raw ) ) ) {
			$payment_max_amount = 0.0;
		} else {
			$payment_max_amount = $service->parse_amount( $payment_max_raw );
			if ( is_wp_error( $payment_max_amount ) || $payment_max_amount < 1 || (float) wc_format_decimal( $payment_max_amount, wc_get_price_decimals() ) !== $payment_max_amount ) {
				return new WP_Error( 'invalid_payment_amount', 'حداکثر مبلغ پرداخت با کیف پول را به‌صورت مبلغ معتبر وارد کنید؛ برای نامحدود بودن صفر بگذارید.' );
			}
		}
		$withdrawal_enabled = $input['withdrawal_enabled'] ?? ( $current['withdrawal_enabled'] ? '1' : '0' );
		if ( ! in_array( $withdrawal_enabled, [ '0', '1' ], TRUE ) ) {
			return new WP_Error( 'invalid_withdrawal_enabled', 'وضعیت درخواست برداشت معتبر نیست.' );
		}
		$withdrawal_min_raw = isset( $input['withdrawal_minimum_balance'] ) && is_scalar( $input['withdrawal_minimum_balance'] ) ? trim( KERP_Helpers_Format::sanitize_numbers( (string) $input['withdrawal_minimum_balance'] ) ) : (string) $current['withdrawal_minimum_balance'];
		if ( $withdrawal_min_raw === '' || preg_match( '/^0(?:[.,]0+)?$/', str_replace( [ ',', '٬', '٫' ], [
				'',
				'',
				'.',
			], $withdrawal_min_raw ) ) ) {
			$withdrawal_minimum = 0.0;
		} else {
			$withdrawal_minimum = $service->parse_amount( $withdrawal_min_raw );
			if ( is_wp_error( $withdrawal_minimum ) ) {
				return new WP_Error( 'invalid_withdrawal_minimum', 'حداقل موجودی لازم برای برداشت معتبر نیست.' );
			}
		}
		$debit_timing = sanitize_key( (string) ( $input['withdrawal_debit_timing'] ?? $current['withdrawal_debit_timing'] ) );
		if ( ! in_array( $debit_timing, [ 'request', 'approval' ], TRUE ) ) {
			return new WP_Error( 'invalid_debit_timing', 'زمان کسر از کیف پول معتبر نیست.' );
		}
		$terms_value = $input['withdrawal_terms'] ?? $current['withdrawal_terms'];
		if ( ! is_scalar( $terms_value ) ) {
			return new WP_Error( 'invalid_withdrawal_terms', 'متن قوانین برداشت معتبر نیست.' );
		}
		$withdrawal_terms = wp_kses_post( (string) $terms_value );
		$field_input      = $input['withdrawal_fields'] ?? $current['withdrawal_fields'];
		if ( ! is_array( $field_input ) || count( $field_input ) > 20 ) {
			return new WP_Error( 'invalid_withdrawal_fields', 'حداکثر ۲۰ فیلد برای فرم برداشت قابل تعریف است.' );
		}
		$withdrawal_fields = [];
		foreach ( $field_input as $field ) {
			if ( ! is_array( $field ) ) {
				continue;
			}
			$key   = is_scalar( $field['key'] ?? '' ) ? sanitize_key( (string) ( $field['key'] ?? '' ) ) : '';
			$label = is_scalar( $field['label'] ?? '' ) ? sanitize_text_field( (string) ( $field['label'] ?? '' ) ) : '';
			$type  = is_scalar( $field['type'] ?? 'text' ) ? sanitize_key( (string) ( $field['type'] ?? 'text' ) ) : '';
			if ( $key === '' && $label === '' ) {
				continue;
			}
			if ( $key === '' || $label === '' || ! in_array( $type, [ 'text', 'textarea', 'number', 'tel' ], TRUE ) ) {
				return new WP_Error( 'invalid_withdrawal_field', 'کلید، عنوان یا نوع یکی از فیلدهای فرم برداشت معتبر نیست.' );
			}
			if ( isset( $withdrawal_fields[ $key ] ) ) {
				return new WP_Error( 'duplicate_withdrawal_field', 'کلید فیلدهای فرم برداشت نباید تکراری باشد.' );
			}
			$withdrawal_fields[ $key ] = [
				'key'      => $key,
				'label'    => $label,
				'type'     => $type,
				'required' => ! empty( $field['required'] ) ? '1' : '0',
			];
		}
		$withdrawal_fields = array_values( $withdrawal_fields );
		
		return [
			'enabled'                    => $input['enabled'] === '1',
			'minimum'                    => $minimum,
			'maximum'                    => $maximum,
			'presets'                    => $clean,
			'payment_max_percentage'     => (float) $percentage,
			'payment_max_amount'         => (float) $payment_max_amount,
			'withdrawal_enabled'         => $withdrawal_enabled === '1',
			'withdrawal_minimum_balance' => (float) $withdrawal_minimum,
			'withdrawal_debit_timing'    => $debit_timing,
			'withdrawal_terms'           => $withdrawal_terms,
			'withdrawal_fields'          => $withdrawal_fields,
		];
	}
	
	public function save(): void {
		if ( ! is_user_logged_in() || ! KERP_App::instance()
		                                        ->current_user_has_access() || ! kerp_can( 'wallet.manage_settings', 'action' ) ) {
			$this->error( 'اجازه تغییر تنظیمات کیف پول را ندارید.' );
		}
		$nonce = isset( $_POST['nonce'] ) && is_string( $_POST['nonce'] ) ? wp_unslash( $_POST['nonce'] ) : '';
		if ( ! wp_verify_nonce( $nonce, 'kerp_wallet_settings' ) ) {
			$this->error( 'اعتبار فرم منقضی شده است؛ صفحه را تازه کنید.' );
		}
		$input = wp_unslash( $_POST );
		if ( isset( $input['settings_payload'] ) ) {
			if ( ! is_string( $input['settings_payload'] ) ) {
				$this->error( 'ساختار تنظیمات ارسال‌شده معتبر نیست.' );
			}
			$payload = json_decode( $input['settings_payload'], TRUE );
			if ( ! is_array( $payload ) || json_last_error() !== JSON_ERROR_NONE ) {
				$this->error( 'ساختار تنظیمات ارسال‌شده معتبر نیست.' );
			}
			$input = $payload;
		}
		$section = sanitize_key( (string) ( $input['section'] ?? '' ) );
		$routes  = [
			'limits'     => '/erp/settings/wallet/',
			'withdrawal' => '/erp/settings/wallet/withdrawal/',
			'sms'        => '/erp/settings/wallet/sms/',
		];
		if ( ! isset( $routes[ $section ] ) ) {
			$this->error( 'بخش تنظیمات کیف پول معتبر نیست.' );
		}
		$current          = $this->get();
		$validation_input = [
			'enabled'                    => ! empty( $current['enabled'] ) ? '1' : '0',
			'minimum'                    => $current['minimum'],
			'maximum'                    => $current['maximum'],
			'presets'                    => $current['presets'],
			'payment_max_percentage'     => $current['payment_max_percentage'],
			'payment_max_amount'         => $current['payment_max_amount'],
			'withdrawal_enabled'         => ! empty( $current['withdrawal_enabled'] ) ? '1' : '0',
			'withdrawal_minimum_balance' => $current['withdrawal_minimum_balance'],
			'withdrawal_debit_timing'    => $current['withdrawal_debit_timing'],
			'withdrawal_terms'           => $current['withdrawal_terms'],
			'withdrawal_fields'          => $current['withdrawal_fields'],
		];
		$settings         = $this->validate( array_replace( $validation_input, $input ) );
		if ( is_wp_error( $settings ) ) {
			$this->error( $settings->get_error_message() );
		}
		update_option( self::OPTION, $settings, FALSE );
		if ( get_option( self::OPTION ) !== $settings ) {
			$this->error( 'ذخیره تنظیمات انجام نشد؛ دوباره تلاش کنید.' );
		}
		if ( $section === 'sms' ) {
			KERP_Modules_Wallet_SMS::instance()
			                       ->save_rules( isset( $input['sms_rules'] ) && is_array( $input['sms_rules'] ) ? $input['sms_rules'] : [] );
		}
		$data = KERP_Api_Page_Content::build_page_response( $routes[ $section ], [], TRUE );
		wp_send_json( array_merge( $data, [
			'status'  => 'success',
			'message' => 'تنظیمات کیف پول ذخیره شد.',
			'msg'     => 'تنظیمات کیف پول ذخیره شد.',
		] ) );
	}
	
	private function error( string $message ): void {
		wp_send_json( [ 'status' => 'error', 'message' => $message, 'msg' => $message ] );
	}
	
}
