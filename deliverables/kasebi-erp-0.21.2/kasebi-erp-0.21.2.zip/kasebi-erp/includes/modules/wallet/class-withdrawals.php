<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Wallet_Withdrawals {
	private const POST_TYPE = 'kerp_wallet_withdraw';
	private static ?self $instance = NULL;

	public static function instance(): self { return self::$instance ??= new self(); }

	private function __construct() {
		add_action( 'init', [ $this, 'register_post_type' ] );
		add_action( 'nooshika_ajax_kerp_wallet_submit_withdrawal', [ $this, 'submit' ] );
		add_action( 'kasebi_ajax_kerp_wallet_update_withdrawal', [ $this, 'update' ] );
		add_action( 'kasebi_ajax_kerp_wallet_get_withdrawal_details', [ $this, 'details' ] );
		add_action( 'kasebi_ajax_kerp_wallet_get_withdrawal_action', [ $this, 'action_form' ] );
	}

	public function register_post_type(): void {
		register_post_type( self::POST_TYPE, [
			'label' => 'درخواست‌های برداشت کیف پول', 'public' => FALSE, 'show_ui' => FALSE,
			'supports' => [ 'author' ], 'capability_type' => 'post', 'map_meta_cap' => TRUE,
		] );
	}

	public function settings(): array {
		$all = KERP_Modules_Wallet_Settings::instance()->get();
		return [
			'enabled' => ! empty( $all['withdrawal_enabled'] ),
			'minimum_balance' => (float) ( $all['withdrawal_minimum_balance'] ?? 0 ),
			'debit_timing' => in_array( $all['withdrawal_debit_timing'] ?? '', [ 'request', 'approval' ], TRUE ) ? $all['withdrawal_debit_timing'] : 'approval',
			'terms' => (string) ( $all['withdrawal_terms'] ?? '' ),
			'fields' => is_array( $all['withdrawal_fields'] ?? NULL ) ? $all['withdrawal_fields'] : [],
		];
	}

	public function submit(): void {
		if ( ! is_user_logged_in() ) { $this->error( 'برای ثبت درخواست وارد حساب کاربری شوید.' ); }
		$settings = $this->settings();
		if ( ! $settings['enabled'] ) { $this->error( 'درخواست برداشت وجه در حال حاضر غیرفعال است.' ); }
		$request_id = $this->post_text( 'request_id' );
		$nonce = $this->post_text( 'nonce' );
		if ( ! wp_is_uuid( $request_id ) || ! wp_verify_nonce( $nonce, 'kerp_wallet_withdrawal_' . $request_id ) ) { $this->error( 'اعتبار فرم منقضی شده است؛ صفحه را تازه کنید.' ); }
		$user_id = get_current_user_id();
		$claim = 'kerp_wallet_withdrawal_request_' . $user_id . '_' . $request_id;
		if ( ! add_option( $claim, [ 'status' => 'processing', 'created_at' => time() ], '', FALSE ) ) { $this->error( 'این درخواست قبلاً ارسال شده است.' ); }
		$amount = KERP_Modules_Wallet_Service::instance()->parse_amount( wp_unslash( $_POST['amount'] ?? '' ) );
		$balance = (float) KERP_Modules_Wallet_Service::instance()->get_balance( $user_id, FALSE );
		if ( is_wp_error( $amount ) || $amount > $balance || $balance < $settings['minimum_balance'] ) {
			delete_option( $claim );
			$this->error( $balance < $settings['minimum_balance'] ? 'موجودی کیف پول شما به حداقل لازم برای برداشت نرسیده است.' : 'مبلغ برداشت معتبر نیست یا از موجودی کیف پول بیشتر است.' );
		}
		$submitted = isset( $_POST['fields'] ) && is_array( $_POST['fields'] ) ? wp_unslash( $_POST['fields'] ) : [];
		$fields = $this->validate_fields( $settings['fields'], $submitted );
		if ( is_wp_error( $fields ) ) { delete_option( $claim ); $this->error( $fields->get_error_message() ); }
		$post_id = wp_insert_post( [ 'post_type' => self::POST_TYPE, 'post_status' => 'publish', 'post_author' => $user_id, 'post_title' => 'برداشت کیف پول' ], TRUE );
		if ( is_wp_error( $post_id ) ) { delete_option( $claim ); $this->error( 'ثبت درخواست انجام نشد.' ); }
		update_post_meta( $post_id, '_kerp_wallet_withdrawal_amount', $amount );
		update_post_meta( $post_id, '_kerp_wallet_withdrawal_status', 'pending' );
		update_post_meta( $post_id, '_kerp_wallet_withdrawal_fields', $fields );
		update_post_meta( $post_id, '_kerp_wallet_withdrawal_request_id', $request_id );
		if ( $settings['debit_timing'] === 'request' ) {
			$debit = $this->debit( $post_id );
			if ( is_wp_error( $debit ) ) { wp_delete_post( $post_id, TRUE ); delete_option( $claim ); $this->error( $debit->get_error_message() ); }
		}
		update_option( $claim, [ 'status' => 'completed', 'withdrawal_id' => $post_id ], FALSE );
		do_action( 'kerp_wallet_withdrawal_created', $this->get( $post_id ) );
		$this->success( 'درخواست برداشت وجه ثبت شد و پس از بررسی نتیجه اعلام می‌شود.' );
	}

	public function update(): void {
		if ( ! is_user_logged_in() || ! KERP_App::instance()->current_user_has_access() || ! kerp_can( 'wallet.manage_withdrawals', 'action' ) ) { $this->error( 'اجازه مدیریت درخواست‌های برداشت را ندارید.' ); }
		$id = absint( $_POST['withdrawal_id'] ?? 0 );
		if ( ! wp_verify_nonce( $this->post_text( 'nonce' ), 'kerp_wallet_withdrawal_admin_' . $id ) ) { $this->error( 'اعتبار فرم منقضی شده است.' ); }
		$request = $this->get( $id );
		if ( ! $request ) { $this->error( 'درخواست پیدا نشد.' ); }
		$status = sanitize_key( $this->post_text( 'status' ) );
		if ( ! in_array( $status, [ 'pending', 'approved', 'paid', 'rejected' ], TRUE ) ) { $this->error( 'وضعیت درخواست معتبر نیست.' ); }
		$old_status = $request['status'];
		if ( in_array( $old_status, [ 'paid', 'rejected' ], TRUE ) && $status !== $old_status ) { $this->error( 'درخواست پرداخت‌شده یا ردشده نهایی است و وضعیت آن قابل تغییر نیست.' ); }
		$bank = sanitize_text_field( $this->post_text( 'bank_name' ) );
		$reference = sanitize_text_field( $this->post_text( 'payment_reference' ) );
		$paid_at = $this->parse_paid_at( $this->post_text( 'paid_date' ), $this->post_text( 'paid_time' ) );
		if ( is_wp_error( $paid_at ) ) { $this->error( $paid_at->get_error_message() ); }
		if ( $paid_at === '' && $this->post_text( 'paid_at' ) !== '' ) {
			$paid_at = sanitize_text_field( str_replace( 'T', ' ', $this->post_text( 'paid_at' ) ) );
		}
		$note = sanitize_textarea_field( $this->post_text( 'admin_note' ) );
		$receipt = esc_url_raw( $this->post_text( 'receipt_url' ) );
		$old_receipt = esc_url_raw( (string) ( $request['receipt'] ?? '' ) );
		if ( $receipt !== '' && $receipt !== $old_receipt ) {
			$file_data = KERP_Api_File_Upload::instance()->get_uploaded_file_data( $receipt );
			if ( ! is_array( $file_data ) || strpos( (string) ( $file_data['mime_type'] ?? '' ), 'image/' ) !== 0 ) {
				$this->error( 'تصویر رسید معتبر نیست؛ فایل را دوباره از دراپ‌زون بارگذاری کنید.' );
			}
		}
		if ( $status === 'paid' && ( $bank === '' || $reference === '' || $paid_at === '' || $receipt === '' ) ) { $this->error( 'برای ثبت پرداخت، نام بانک، شماره پیگیری، تاریخ، ساعت و تصویر رسید الزامی است.' ); }
		if ( in_array( $status, [ 'approved', 'paid' ], TRUE ) && empty( $request['wallet_transaction_id'] ) ) {
			$debit = $this->debit( $id );
			if ( is_wp_error( $debit ) ) { $this->error( $debit->get_error_message() ); }
		}
		if ( $status === 'rejected' && ! empty( $request['wallet_transaction_id'] ) && empty( $request['refund_transaction_id'] ) ) {
			$refund_claim = 'kerp_wallet_withdrawal_refund_' . $id;
			if ( ! add_option( $refund_claim, [ 'status' => 'processing', 'created_at' => time() ], '', FALSE ) ) {
				$request = $this->get( $id );
				if ( empty( $request['refund_transaction_id'] ) ) { $this->error( 'نتیجه تلاش قبلی برای بازگشت وجه نیازمند بررسی است.' ); }
			} else {
			$refund = KERP_Modules_Wallet_Service::instance()->add_transaction( (int) $request['user_id'], 'credit', (float) $request['amount'], 'بازگشت درخواست برداشت ردشده #' . $id . ' [KERP:withdrawal-refund:' . $id . ']' );
			if ( is_wp_error( $refund ) ) { delete_option( $refund_claim ); $this->error( 'بازگشت وجه به کیف پول انجام نشد؛ درخواست رد نشد.' ); }
			update_post_meta( $id, '_kerp_wallet_withdrawal_refund_transaction_id', $refund );
			update_option( $refund_claim, [ 'status' => 'completed', 'transaction_id' => $refund ], FALSE );
			}
		}
		update_post_meta( $id, '_kerp_wallet_withdrawal_status', $status );
		update_post_meta( $id, '_kerp_wallet_withdrawal_bank', $bank );
		update_post_meta( $id, '_kerp_wallet_withdrawal_reference', $reference );
		update_post_meta( $id, '_kerp_wallet_withdrawal_paid_at', $paid_at );
		update_post_meta( $id, '_kerp_wallet_withdrawal_admin_note', $note );
		update_post_meta( $id, '_kerp_wallet_withdrawal_receipt', esc_url_raw( $receipt ) );
		update_post_meta( $id, '_kerp_wallet_withdrawal_updated_by', get_current_user_id() );
		if ( $status !== $old_status ) { do_action( 'kerp_wallet_withdrawal_status_changed', $this->get( $id ), $old_status, $status ); }
		$this->success( 'اطلاعات درخواست برداشت ذخیره شد.', KERP_Api_Page_Content::build_page_response( '/erp/wallet/withdrawals/', [], TRUE ) );
	}

	public function details(): void {
		$this->guard_admin();
		$request = $this->requested_item();
		if ( ! $this->has_payment_details( $request ) ) {
			$this->error( 'اطلاعات واریز این درخواست هنوز تکمیل نشده است.' );
		}
		$this->success( '', [
			'html' => KERP_Helpers_Template::get_template( 'modules/wallet/modals/withdrawal-details.php', [
				'request' => $request,
				'service' => KERP_Modules_Wallet_Service::instance(),
			] ),
		] );
	}

	public function action_form(): void {
		$this->guard_admin();
		$request = $this->requested_item();
		$labels = [];
		foreach ( $this->settings()['fields'] as $definition ) {
			$key = sanitize_key( (string) ( $definition['key'] ?? '' ) );
			if ( $key !== '' ) { $labels[ $key ] = sanitize_text_field( (string) ( $definition['label'] ?? $key ) ); }
		}
		$this->success( '', [
			'html' => KERP_Helpers_Template::get_template( 'modules/wallet/modals/withdrawal-action.php', [
				'request'      => $request,
				'service'      => KERP_Modules_Wallet_Service::instance(),
				'field_labels' => $labels,
				'user'         => get_userdata( (int) $request['user_id'] ),
			] ),
		] );
	}

	public function get( int $id ): array {
		$post = get_post( $id );
		if ( ! $post || $post->post_type !== self::POST_TYPE ) { return []; }
		return [
			'id' => $id, 'user_id' => (int) $post->post_author, 'created_at' => $post->post_date,
			'amount' => (float) get_post_meta( $id, '_kerp_wallet_withdrawal_amount', TRUE ),
			'status' => (string) get_post_meta( $id, '_kerp_wallet_withdrawal_status', TRUE ),
			'fields' => (array) get_post_meta( $id, '_kerp_wallet_withdrawal_fields', TRUE ),
			'wallet_transaction_id' => absint( get_post_meta( $id, '_kerp_wallet_withdrawal_transaction_id', TRUE ) ),
			'refund_transaction_id' => absint( get_post_meta( $id, '_kerp_wallet_withdrawal_refund_transaction_id', TRUE ) ),
			'bank_name' => (string) get_post_meta( $id, '_kerp_wallet_withdrawal_bank', TRUE ),
			'payment_reference' => (string) get_post_meta( $id, '_kerp_wallet_withdrawal_reference', TRUE ),
			'paid_at' => (string) get_post_meta( $id, '_kerp_wallet_withdrawal_paid_at', TRUE ),
			'admin_note' => (string) get_post_meta( $id, '_kerp_wallet_withdrawal_admin_note', TRUE ),
			'receipt' => (string) get_post_meta( $id, '_kerp_wallet_withdrawal_receipt', TRUE ),
		];
	}

	public function find_by_transaction( int $transaction_id, string $details = '' ): array {
		if ( preg_match( '/\[KERP:withdrawal:(\d+)\]/', $details, $match ) ) { return $this->get( absint( $match[1] ) ); }
		$ids = get_posts( [ 'post_type' => self::POST_TYPE, 'post_status' => 'any', 'fields' => 'ids', 'numberposts' => 1, 'meta_key' => '_kerp_wallet_withdrawal_transaction_id', 'meta_value' => $transaction_id ] );
		return $ids ? $this->get( (int) $ids[0] ) : [];
	}

	private function debit( int $id ): int|WP_Error {
		$request = $this->get( $id );
		if ( ! empty( $request['wallet_transaction_id'] ) ) { return (int) $request['wallet_transaction_id']; }
		$claim = 'kerp_wallet_withdrawal_debit_' . $id;
		if ( ! add_option( $claim, [ 'status' => 'processing', 'created_at' => time() ], '', FALSE ) ) {
			$request = $this->get( $id );
			return ! empty( $request['wallet_transaction_id'] ) ? (int) $request['wallet_transaction_id'] : new WP_Error( 'withdrawal_debit_review', 'نتیجه تلاش قبلی برای کسر موجودی نیازمند بررسی است.' );
		}
		$result = KERP_Modules_Wallet_Service::instance()->add_transaction( (int) $request['user_id'], 'debit', (float) $request['amount'], 'برداشت وجه از کیف پول — درخواست #' . $id . ' [KERP:withdrawal:' . $id . ']' );
		if ( is_wp_error( $result ) ) { delete_option( $claim ); }
		else { update_post_meta( $id, '_kerp_wallet_withdrawal_transaction_id', $result ); update_option( $claim, [ 'status' => 'completed', 'transaction_id' => $result ], FALSE ); }
		return $result;
	}

	private function validate_fields( array $definitions, array $submitted ): array|WP_Error {
		$clean = [];
		foreach ( $definitions as $field ) {
			$key = sanitize_key( (string) ( $field['key'] ?? '' ) ); if ( $key === '' ) { continue; }
			$value = isset( $submitted[ $key ] ) && is_scalar( $submitted[ $key ] ) ? sanitize_textarea_field( (string) $submitted[ $key ] ) : '';
			if ( ! empty( $field['required'] ) && trim( $value ) === '' ) { return new WP_Error( 'required_field', sprintf( 'تکمیل فیلد «%s» الزامی است.', sanitize_text_field( (string) ( $field['label'] ?? $key ) ) ) ); }
			$clean[ $key ] = $value;
		}
		return $clean;
	}

	private function parse_paid_at( string $date, string $time ): string|WP_Error {
		$date = sanitize_text_field( $date );
		$time = sanitize_text_field( $time );
		if ( function_exists( 'nooshika_sanitize_numbers' ) ) {
			$date = nooshika_sanitize_numbers( $date );
			$time = nooshika_sanitize_numbers( $time );
		} elseif ( class_exists( 'KERP_Helpers_Format' ) ) {
			$date = KERP_Helpers_Format::sanitize_numbers( $date );
			$time = KERP_Helpers_Format::sanitize_numbers( $time );
		}
		$date = trim( str_replace( '/', '-', $date ) );
		$time = trim( $time );
		if ( $date === '' && $time === '' ) { return ''; }
		if ( $date === '' || $time === '' ) { return new WP_Error( 'wallet_paid_at_incomplete', 'تاریخ و ساعت پرداخت را کامل وارد کنید.' ); }
		if ( class_exists( 'KERP_Helpers_Date' ) ) {
			$converted = KERP_Helpers_Date::jalali_to_gregorian( $date );
			if ( is_string( $converted ) && $converted !== '' ) { $date = str_replace( '/', '-', $converted ); }
		}
		$parsed = DateTimeImmutable::createFromFormat( '!Y-m-d H:i', $date . ' ' . $time, wp_timezone() );
		$errors = DateTimeImmutable::getLastErrors();
		if ( ! $parsed instanceof DateTimeImmutable || ( is_array( $errors ) && ( (int) $errors['warning_count'] > 0 || (int) $errors['error_count'] > 0 ) ) ) {
			return new WP_Error( 'wallet_paid_at_invalid', 'تاریخ یا ساعت پرداخت معتبر نیست.' );
		}
		return $parsed->format( 'Y-m-d H:i:s' );
	}

	private function guard_admin(): void {
		if ( ! is_user_logged_in() || ! KERP_App::instance()->current_user_has_access() || ! kerp_can( 'wallet.manage_withdrawals', 'action' ) ) {
			$this->error( 'اجازه مدیریت درخواست‌های برداشت را ندارید.' );
		}
	}

	private function requested_item(): array {
		$id = absint( $_POST['withdrawal_id'] ?? 0 );
		$request = $id > 0 ? $this->get( $id ) : [];
		if ( empty( $request ) ) { $this->error( 'درخواست برداشت پیدا نشد.' ); }
		return $request;
	}

	public function has_payment_details( array $request ): bool {
		return ( $request['status'] ?? '' ) === 'paid'
			&& trim( (string) ( $request['bank_name'] ?? '' ) ) !== ''
			&& trim( (string) ( $request['payment_reference'] ?? '' ) ) !== ''
			&& trim( (string) ( $request['paid_at'] ?? '' ) ) !== ''
			&& trim( (string) ( $request['receipt'] ?? '' ) ) !== '';
	}

	private function post_text( string $key ): string { return isset( $_POST[ $key ] ) && is_scalar( $_POST[ $key ] ) ? (string) wp_unslash( $_POST[ $key ] ) : ''; }
	private function success( string $message, array $data = [] ): void { wp_send_json( array_merge( [ 'status' => 'success', 'message' => $message, 'msg' => $message ], $data ) ); }
	private function error( string $message ): void { wp_send_json( [ 'status' => 'error', 'message' => $message, 'msg' => $message ] ); exit; }
}
