<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Wallet_Module {
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {
		add_filter( 'kerp_panel_navigation_pages', [ $this, 'register_panel_navigation_settings' ] );
		$this->load_services();
		$this->register_hooks();
	}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	private function load_services(): void {
		KERP_Modules_Wallet_Service::instance();
		KERP_Modules_Wallet_Api::instance();
		KERP_Modules_Wallet_Charge::instance();
		KERP_Modules_Wallet_Settings::instance();
		KERP_Modules_Wallet_Withdrawals::instance();
		KERP_Modules_Wallet_SMS::instance();
	}
	
	private function register_hooks(): void {
		add_filter( 'kerp_app_pages', [ $this, 'register_pages' ], 55 );
		add_filter( 'kerp_customer_profile_tabs', [ $this, 'register_customer_tab' ], 55, 3 );
		add_filter( 'kerp_employee_profile_tabs', [ $this, 'register_employee_tab' ], 55, 3 );
		add_filter( 'kerp_employees_profile_dropdown_actions', [ $this, 'register_employee_dropdown_action' ], 55, 3 );
		add_action( 'kerp_employee_profile_after_page', [ $this, 'render_employee_modal' ], 55, 3 );
		add_filter( 'kerp_customers_profile_account_info_items', [ $this, 'register_account_info_item' ], 55, 3 );
		add_filter( 'kerp_customers_profile_dropdown_actions', [ $this, 'register_profile_dropdown_action' ], 55, 3 );
		add_action( 'kerp_customer_profile_modals', [ $this, 'render_customer_modal' ], 55, 4 );
		add_filter( 'kerp_customers_bulk_actions', [ $this, 'register_customers_bulk_action' ], 55 );
		add_filter( 'kerp_customers_bulk_need_fields', [ $this, 'register_customers_bulk_fields' ], 55, 2 );
		add_filter( 'kerp_customers_execute_bulk_action', [ $this, 'execute_customers_bulk_action' ], 55, 5 );
		add_filter( 'kerp_employee_permission_groups', [ $this, 'register_permissions' ], 45 );
		
		add_filter( 'nooshika_panel_pages_list_final', [ $this, 'register_panel_pages' ], 20, 2 );
		add_filter( 'nooshika_panel_get_template_path', [ $this, 'filter_panel_template_path' ], 20, 2 );
		add_action( 'wp_enqueue_scripts', [ $this, 'register_assets' ], 5 );
		add_action( 'wp_enqueue_scripts', [ $this, 'maybe_enqueue_panel_assets' ], 40 );
	}
	
	public function register_pages( array $pages ): array {
		$settings_group                      = [
			'key'        => 'settings',
			'title'      => 'تنظیمات',
			'icon'       => 'kik fa-settings-02',
			'order'      => 100,
			'sep_before' => TRUE,
		];
		$wallet_menu                         = [
			'key'   => 'wallet-settings',
			'title' => 'کیف پول',
			'icon'  => 'ni ni-wallet-fill',
			'order' => 55,
		];
		$pages['wallet-settings-limits']     = [
			'title'      => __( 'محدودیت‌ها و شارژ کیف پول', 'kasebi-erp' ),
			'route'      => 'settings/wallet',
			'type'       => 'settings',
			'template'   => 'modules/wallet/settings/limits.php',
			'permission' => 'wallet.manage_settings',
			'navigation' => [
				'group' => $settings_group,
				'menu'  => $wallet_menu,
				'title' => 'محدودیت‌ها و شارژ',
				'order' => 10,
			],
		];
		$pages['wallet-settings-withdrawal'] = [
			'title'      => __( 'تنظیمات درخواست وجه', 'kasebi-erp' ),
			'route'      => 'settings/wallet/withdrawal',
			'type'       => 'settings',
			'template'   => 'modules/wallet/settings/withdrawal.php',
			'permission' => 'wallet.manage_settings',
			'navigation' => [
				'group' => $settings_group,
				'menu'  => $wallet_menu,
				'title' => 'درخواست وجه',
				'order' => 20,
			],
		];
		$pages['wallet-settings-sms']        = [
			'title'      => __( 'پیامک‌های کیف پول', 'kasebi-erp' ),
			'route'      => 'settings/wallet/sms',
			'type'       => 'settings',
			'template'   => 'modules/wallet/settings/sms.php',
			'permission' => 'wallet.manage_settings',
			'navigation' => [
				'group' => $settings_group,
				'menu'  => $wallet_menu,
				'title' => 'پیامک',
				'order' => 30,
			],
		];
		$pages['wallet-settings-product']    = [
			'title'      => __( 'محصول سیستمی کیف پول', 'kasebi-erp' ),
			'route'      => 'settings/wallet/product',
			'type'       => 'settings',
			'template'   => 'modules/wallet/settings/product.php',
			'permission' => 'wallet.manage_settings',
			'navigation' => [
				'group' => $settings_group,
				'menu'  => $wallet_menu,
				'title' => 'محصول سیستمی',
				'order' => 40,
			],
		];
		$pages['wallet-withdrawals']         = [
			'title'      => __( 'درخواست‌های برداشت وجه', 'kasebi-erp' ),
			'route'      => 'wallet/withdrawals',
			'type'       => 'list',
			'template'   => 'modules/wallet/pages/withdrawals.php',
			'permission' => 'wallet.manage_withdrawals',
			'navigation' => [
				'group' => [ 'key' => 'sales', 'title' => 'فروش و مالی', 'icon' => 'uik-r fa-money', 'order' => 25 ],
				'icon'  => 'ni ni-wallet-out',
				'title' => 'درخواست‌های برداشت',
				'order' => 58,
			],
		];
		
		return $pages;
	}
	
	public function register_customer_tab( array $tabs, int $customer_id, WP_User $customer ): array {
		$tabs['wallet'] = [
			'key'        => 'wallet',
			'title'      => __( 'کیف پول', 'kasebi-erp' ),
			'icon'       => 'ni ni-wallet-fill',
			'order'      => 55,
			'group'      => 'finance-loyalty',
			'permission' => 'wallet.view',
			'action'     => 'view',
			'template'   => 'modules/wallet/tabs/customer-wallet.php',
		];
		
		return $tabs;
	}
	
	public function can_access_employee( int $employee_id ): bool {
		if ( ! kerp_can( 'employees.view', 'view' ) || ! KERP_Modules_Employees_Query::instance()->get_employee( $employee_id ) ) {
			return FALSE;
		}
		$scope = kerp_list_scope( 'employees' );
		return $scope === 'all' || ( $scope === 'own' && $employee_id === get_current_user_id() );
	}

	public function register_employee_tab( array $tabs, int $employee_id, WP_User $employee ): array {
		if ( ! $this->can_access_employee( $employee_id ) ) {
			return $tabs;
		}
		$tabs['wallet'] = [
			'key' => 'wallet', 'title' => __( 'کیف پول', 'kasebi-erp' ),
			'icon' => 'ni ni-wallet-fill', 'order' => 55,
			'permission' => 'wallet.view', 'action' => 'view',
			'template' => 'modules/wallet/tabs/employee-wallet.php',
		];
		return $tabs;
	}

	public function register_employee_dropdown_action( array $actions, WP_User $employee, array $profile_context ): array {
		if ( ! $this->can_access_employee( (int) $employee->ID ) || ! $this->can_add_transaction() ) {
			return $actions;
		}
		$actions['add_wallet_transaction'] = [
			'label' => __( 'ثبت تراکنش کیف پول', 'kasebi-erp' ), 'icon' => 'ni ni-tranx-fill',
			'href' => '#employeeWalletTransactionModal', 'order' => 55,
			'attributes' => [ 'data-bs-toggle' => 'modal', 'data-bs-target' => '#employeeWalletTransactionModal' ],
		];
		return $actions;
	}

	public function render_employee_modal( int $employee_id, WP_User $employee, array $profile_context ): void {
		if ( ! $this->can_access_employee( $employee_id ) || ! $this->can_add_transaction() ) {
			return;
		}
		KERP_Helpers_Template::render_template( 'modules/wallet/modals/transaction-form.php', [
			'customer_id' => $employee_id, 'customer' => $employee,
			'wallet_entity' => 'employee', 'wallet_singular' => __( 'کارمند', 'kasebi-erp' ),
			'wallet_modal_id' => 'employeeWalletTransactionModal',
			'return_page' => '/erp/employees/' . $employee_id . '/?tab=wallet',
		] );
	}

	public function register_account_info_item( array $items, WP_User $customer, array $profile_context ): array {
		if ( ! kerp_can( 'wallet.view', 'view' ) ) {
			return $items;
		}
		$items['wallet_balance'] = [
			'icon'        => 'ni ni-wallet-fill',
			'label'       => __( 'موجودی کیف پول:', 'kasebi-erp' ),
			'value'       => (string) KERP_Modules_Wallet_Service::instance()->get_balance( (int) $customer->ID, TRUE ),
			'class'       => '',
			'value_class' => 'text-primary',
			'value_html'  => TRUE,
			'visible'     => TRUE,
			'order'       => 40,
		];
		
		return $items;
	}
	
	public function register_profile_dropdown_action( array $actions, WP_User $customer, array $profile_context ): array {
		if ( ! $this->can_add_transaction() ) {
			return $actions;
		}
		
		$actions['add_wallet_transaction'] = [
			'label'      => __( 'ثبت تراکنش کیف پول', 'kasebi-erp' ),
			'icon'       => 'ni ni-tranx-fill',
			'href'       => '#customerWalletTransactionModal',
			'order'      => 55,
			'attributes' => [
				'data-bs-toggle' => 'modal',
				'data-bs-target' => '#customerWalletTransactionModal',
			],
		];
		
		return $actions;
	}
	
	public function render_customer_modal( int $customer_id, WP_User $customer, array $profile_context, string $active_tab ): void {
		if ( ! $this->can_add_transaction() ) {
			return;
		}
		
		$return_page = '/erp/customers/' . $customer_id . '/';
		if ( $active_tab !== '' ) {
			$return_page = add_query_arg( 'tab', sanitize_key( $active_tab ), $return_page );
		}
		
		KERP_Helpers_Template::render_template( 'modules/wallet/modals/transaction-form.php', [
			'customer_id' => $customer_id,
			'customer'    => $customer,
			'return_page' => $return_page,
		] );
	}
	
	public function register_customers_bulk_action( array $actions ): array {
		if ( ! $this->can_add_transaction() ) {
			return $actions;
		}
		
		$actions['wallet_transaction'] = [
			'key'        => 'wallet_transaction',
			'label'      => __( 'ثبت تراکنش کیف پول', 'kasebi-erp' ),
			'action'     => 'customers_bulk_wallet_transaction',
			'permission' => 'customers',
			'capability' => 'edit',
			'need'       => [ 'customer_ids', 'wallet_type', 'wallet_amount', 'wallet_details' ],
			'attributes' => [
				'data-need' => 'customer_ids,wallet_type,wallet_amount,wallet_details',
			],
			'icon'       => 'ni ni-wallet-fill',
			'order'      => 70,
		];
		
		return $actions;
	}
	
	public function register_customers_bulk_fields( array $fields, array $actions = [] ): array {
		if ( ! isset( $actions['wallet_transaction'] ) || ! $this->can_add_transaction() ) {
			return $fields;
		}
		
		$type_options = [];
		if ( kerp_can( 'wallet.credit', 'action' ) ) {
			$type_options['credit'] = __( 'بستانکار / افزایش موجودی', 'kasebi-erp' );
		}
		if ( kerp_can( 'wallet.debit', 'action' ) ) {
			$type_options['debit'] = __( 'بدهکار / کاهش موجودی', 'kasebi-erp' );
		}
		
		$fields['wallet_type']    = [
			'type'        => 'select',
			'label'       => __( 'نوع تراکنش', 'kasebi-erp' ),
			'placeholder' => __( 'نوع تراکنش را انتخاب کنید', 'kasebi-erp' ),
			'options'     => $type_options,
			'required'    => TRUE,
		];
		$fields['wallet_amount']  = [
			'type'        => 'price',
			'label'       => __( 'مبلغ تراکنش (تومان)', 'kasebi-erp' ),
			'placeholder' => __( 'مبلغ را وارد کنید', 'kasebi-erp' ),
			'required'    => TRUE,
		];
		$fields['wallet_details'] = [
			'type'        => 'textarea',
			'label'       => __( 'شرح تراکنش', 'kasebi-erp' ),
			'placeholder' => __( 'شرحی که در تراکنش همه مشتریان ثبت می‌شود', 'kasebi-erp' ),
			'required'    => TRUE,
		];
		
		return $fields;
	}
	
	public function execute_customers_bulk_action( mixed $result, string $action_key, array $customer_ids, array $payload, array $definition ): mixed {
		if ( $action_key !== 'wallet_transaction' ) {
			return $result;
		}
		
		$type = sanitize_key( (string) ( $payload['wallet_type'] ?? '' ) );
		if ( ! in_array( $type, [ 'credit', 'debit' ], TRUE ) || ! kerp_can( 'wallet.' . $type, 'action' ) ) {
			return new WP_Error( 'kerp_wallet_bulk_forbidden', __( 'برای ثبت این نوع تراکنش کیف پول دسترسی لازم را ندارید.', 'kasebi-erp' ) );
		}
		
		$service = KERP_Modules_Wallet_Service::instance();
		$amount  = $service->parse_amount( $payload['wallet_amount'] ?? '' );
		if ( is_wp_error( $amount ) ) {
			return $amount;
		}
		
		$details = trim( sanitize_textarea_field( (string) ( $payload['wallet_details'] ?? '' ) ) );
		if ( $details === '' ) {
			return new WP_Error( 'kerp_wallet_bulk_details_required', __( 'شرح تراکنش را وارد کنید.', 'kasebi-erp' ) );
		}
		
		$scope          = function_exists( 'kerp_list_scope' ) ? kerp_list_scope( 'customers' ) : 'all';
		$settings       = KERP_Modules_Customers_Settings::instance();
		$customer_roles = array_values( array_filter( array_map( 'sanitize_key', (array) $settings->get( 'customer_roles', [] ) ) ) );
		$owner_meta_key = sanitize_key( (string) $settings->get( 'owner_meta_key', 'kerp_customer_owner_id' ) );
		
		foreach ( $customer_ids as $customer_id ) {
			$customer = get_userdata( absint( $customer_id ) );
			if ( ! $customer instanceof WP_User || ( $customer_roles && ! array_intersect( $customer_roles, (array) $customer->roles ) ) ) {
				return new WP_Error( 'kerp_wallet_bulk_invalid_customer', __( 'یکی از مشتریان انتخاب‌شده معتبر نیست.', 'kasebi-erp' ) );
			}
			if ( $scope === 'none' || ( $scope === 'own' && absint( get_user_meta( $customer->ID, $owner_meta_key, TRUE ) ) !== get_current_user_id() ) ) {
				return new WP_Error( 'kerp_wallet_bulk_customer_scope', __( 'به یکی از مشتریان انتخاب‌شده دسترسی ندارید.', 'kasebi-erp' ) );
			}
			if ( $type === 'debit' && (float) $service->get_balance( $customer->ID ) < (float) $amount ) {
				return new WP_Error(
					'kerp_wallet_bulk_insufficient_balance',
					sprintf( __( 'موجودی کیف پول «%s» برای این برداشت کافی نیست.', 'kasebi-erp' ), get_user_name_by_id( $customer->ID ) )
				);
			}
		}
		
		$completed = 0;
		foreach ( $customer_ids as $customer_id ) {
			$transaction = $service->add_transaction( absint( $customer_id ), $type, (float) $amount, $details );
			if ( is_wp_error( $transaction ) ) {
				return new WP_Error(
					'kerp_wallet_bulk_partial_failure',
					sprintf(
						__( '%1$d تراکنش ثبت شد؛ ادامه عملیات با خطا متوقف شد: %2$s', 'kasebi-erp' ),
						$completed,
						$transaction->get_error_message()
					)
				);
			}
			$completed ++;
		}
		
		return TRUE;
	}
	
	public function register_permissions( array $groups ): array {
		$group                     = isset( $groups['sales'] ) && is_array( $groups['sales'] )
			? $groups['sales']
			: [
				'key'    => 'sales',
				'label'  => __( 'فروش و مالی', 'kasebi-erp' ),
				'icon'   => 'uik-r fa-money',
				'order'  => 25,
				'blocks' => [],
			];
		$group['blocks']           = isset( $group['blocks'] ) && is_array( $group['blocks'] ) ? $group['blocks'] : [];
		$group['blocks']['wallet'] = [
			'key'         => 'wallet',
			'label'       => __( 'کیف پول', 'kasebi-erp' ),
			'icon'        => 'uik-r fa-credit-card',
			'order'       => 20,
			'description' => __( 'مشاهده موجودی و مدیریت تراکنش‌های کیف پول کاربران.', 'kasebi-erp' ),
			'permissions' => [
				'wallet_settings'    => [
					'key'   => 'wallet.manage_settings',
					'label' => __( 'مدیریت تنظیمات کیف پول', 'kasebi-erp' ),
					'type'  => 'action',
					'order' => 40,
				],
				'wallet_withdrawals' => [
					'key'   => 'wallet.manage_withdrawals',
					'label' => __( 'مدیریت درخواست‌های برداشت وجه', 'kasebi-erp' ),
					'type'  => 'action',
					'order' => 45,
				],
				'wallet_view'        => [
					'key'   => 'wallet.view',
					'label' => __( 'مشاهده کیف پول و تراکنش‌ها', 'kasebi-erp' ),
					'type'  => 'view',
					'order' => 10,
				],
				'wallet_credit'      => [
					'key'   => 'wallet.credit',
					'label' => __( 'افزایش موجودی کیف پول', 'kasebi-erp' ),
					'type'  => 'action',
					'order' => 20,
				],
				'wallet_debit'       => [
					'key'   => 'wallet.debit',
					'label' => __( 'کاهش موجودی کیف پول', 'kasebi-erp' ),
					'type'  => 'action',
					'order' => 30,
				],
			],
		];
		$groups['sales']           = $group;
		
		return $groups;
	}
	
	public function register_panel_pages( array $pages, array $defaults = [] ): array {
		$pages['wallet'] = [
			'label' => __( 'کیف پول من', 'kasebi-erp' ),
			'icon'  => 'uik-r fa-credit-card',
		];
		
		return $pages;
	}
	
	public function filter_panel_template_path( string $file_path, string $path ): string {
		if ( $path !== 'pages/wallet' ) {
			return $file_path;
		}
		
		return KERP_TEMPLATES_PATH . 'modules/wallet/panel/wallet.php';
	}
	
	public function register_assets(): void {
		wp_register_style(
			'kerp-wallet-panel',
			KERP_ASSETS_URL . 'public/css/wallet-panel.css',
			[],
			function_exists( 'kerp_asset_version' ) ? kerp_asset_version( 'public/css/wallet-panel.css' ) : KERP_VERSION
		);
	}
	
	public function maybe_enqueue_panel_assets(): void {
		if ( ! $this->is_panel_request() ) {
			return;
		}
		wp_enqueue_style( 'kerp-wallet-panel' );
		KERP_Helpers_Panel_Ajax::ensure_dependencies( TRUE );
		wp_enqueue_script( 'kerp-wallet-panel', KERP_ASSETS_URL . 'public/js/wallet-panel.js', [
			'jquery',
			'nooshika_panel_script',
		], kerp_asset_version( 'public/js/wallet-panel.js' ), TRUE );
	}
	
	private function can_add_transaction(): bool {
		return kerp_can( 'wallet.credit', 'action' ) || kerp_can( 'wallet.debit', 'action' );
	}
	
	private function is_panel_request(): bool {
		return is_page( 'panel' );
	}
	

	public function register_panel_navigation_settings( array $rows ): array {
		return KERP_Settings_Panel_Navigation::register_entries( $rows, 'wallet', 'کیف پول', $this->register_panel_pages( [] ) );
	}
}
