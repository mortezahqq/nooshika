<?php

defined( 'ABSPATH' ) || exit;

/** Online top-ups are separate from staff adjustments. Never trust a browser payment result. */
final class KERP_Modules_Wallet_Charge {
    private static ?self $instance = NULL;
    private const PRODUCT_OPTION = 'kerp_wallet_charge_product_id';
    public static function instance(): self { return self::$instance ??= new self(); }
    private function __construct() {
        add_action( 'nooshika_ajax_kerp_wallet_process_charge', [ $this, 'process_charge' ] );
        add_action( 'kasebi_ajax_wallet_repair_product', [ $this, 'repair_product' ] );
        foreach ( [ 'woocommerce_payment_complete', 'woocommerce_order_status_processing', 'woocommerce_order_status_completed', 'kerp_wallet_retry_charge' ] as $hook ) {
            add_action( $hook, [ $this, 'complete' ], 30 );
        }
        add_action( 'woocommerce_order_refunded', [ $this, 'refund' ], 30, 2 );
        add_action( 'kerp_wallet_retry_refund', [ $this, 'refund' ], 10, 2 );
        add_filter( 'woocommerce_get_return_url', [ $this, 'return_url' ], 30, 2 );
        add_action( 'template_redirect', [ $this, 'redirect_return' ], 5 );
        add_filter( 'process_woo_wallet_general_cashback', [ $this, 'allow_cashback' ], 20, 2 );
        add_filter( 'process_woo_wallet_coupon_cashback', [ $this, 'allow_cashback' ], 20, 2 );
        add_filter( 'woocommerce_is_purchasable', [ $this, 'purchasable' ], 20, 2 );
    }

    public function allow_cashback( $allowed, $order ): bool {
        return $this->is_charge( $order ) ? FALSE : (bool) $allowed;
    }

    public function is_charge( $order ): bool {
        return $order instanceof WC_Order && $order->get_meta( '_kerp_order_type' ) === 'wallet_charge';
    }

    // MySQL advisory locks are connection-owned; no timeout-based deletion of another worker's lock.
    private function lock( string $key ): bool {
        global $wpdb;
        return '1' === (string) $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 5)', $this->lock_name( $key ) ) );
    }
    private function unlock( string $key ): void {
        global $wpdb;
        $wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $this->lock_name( $key ) ) );
    }
    private function lock_name( string $key ): string {
        global $wpdb;
        return 'kerp_wallet_' . md5( $wpdb->prefix . ':' . $key );
    }
    private function input( string $key ): string {
        return isset( $_POST[ $key ] ) && is_string( $_POST[ $key ] ) ? wp_unslash( $_POST[ $key ] ) : '';
    }
    private function error( string $message ): void {
        wp_send_json( [ 'status' => 'error', 'message' => $message, 'msg' => $message ] );
    }

    public function get_product(): ?WC_Product {
        if ( ! function_exists( 'wc_get_product' ) ) { return NULL; }
        $product = wc_get_product( absint( get_option( self::PRODUCT_OPTION, 0 ) ) );
        return $product instanceof WC_Product && $product->get_meta( '_kerp_wallet_charge_product' ) === 'yes' ? $product : NULL;
    }
    public function product_healthy( ?WC_Product $product ): bool {
        return $product && $product->is_type( 'simple' ) && $product->get_status() === 'publish'
            && $product->is_virtual() && $product->get_catalog_visibility() === 'hidden'
            && $product->get_tax_status() === 'none' && ! $product->get_manage_stock()
            && $product->get_stock_status() === 'instock' && (float) $product->get_price() === 0.0;
    }
    public function ensure_product(): int|WP_Error {
        if ( ! class_exists( 'WC_Product_Simple' ) || ! $this->lock( 'product' ) ) {
            return new WP_Error( 'product_busy', 'ساخت محصول در دسترس نیست؛ دوباره تلاش کنید.' );
        }
        try {
            $product = $this->get_product();
            if ( ! $product ) {
                $matches = get_posts( [ 'post_type' => 'product', 'post_status' => [ 'publish', 'private', 'draft' ], 'posts_per_page' => 1, 'fields' => 'ids', 'meta_key' => '_kerp_wallet_charge_product', 'meta_value' => 'yes' ] );
                $product = $matches ? wc_get_product( $matches[0] ) : NULL;
            }
            if ( ! $product || ! $product->is_type( 'simple' ) ) { $product = new WC_Product_Simple(); }
            $product->set_name( 'شارژ کیف پول' );
            $product->set_status( 'publish' );
            $product->set_catalog_visibility( 'hidden' );
            $product->set_virtual( TRUE );
            $product->set_sold_individually( TRUE );
            $product->set_manage_stock( FALSE );
            $product->set_stock_status( 'instock' );
            $product->set_regular_price( '0' );
            $product->set_sale_price( '' );
            $product->set_price( '0' );
            $product->set_tax_status( 'none' );
            $product->update_meta_data( '_kerp_wallet_charge_product', 'yes' );
            $id = $product->save();
            if ( ! $id ) { throw new RuntimeException( 'Product save failed' ); }
            update_option( self::PRODUCT_OPTION, $id, FALSE );
            return $id;
        } catch ( Throwable $e ) {
            return new WP_Error( 'product_failed', 'ساخت یا تعمیر محصول شارژ انجام نشد.' );
        } finally { $this->unlock( 'product' ); }
    }
    public function purchasable( bool $allowed, $product ): bool {
        return $product->get_meta( '_kerp_wallet_charge_product' ) === 'yes' ? FALSE : $allowed;
    }
    public function repair_product(): void {
        if ( ! is_user_logged_in() || ! KERP_App::instance()->current_user_has_access() || ! kerp_can( 'wallet.manage_settings', 'action' ) ) {
            $this->error( 'اجازه تغییر تنظیمات کیف پول را ندارید.' );
        }
        if ( ! wp_verify_nonce( $this->input( 'wallet_nonce' ), 'kerp_wallet_product' ) ) { $this->error( 'اعتبار فرم منقضی شده است؛ صفحه را تازه کنید.' ); }
        $result = $this->ensure_product();
        if ( is_wp_error( $result ) ) { $this->error( $result->get_error_message() ); }
        $data = KERP_Api_Page_Content::build_page_response( '/erp/settings/wallet/product/', [], TRUE );
        wp_send_json( array_merge( $data, [ 'status' => 'success', 'message' => 'محصول شارژ بررسی و تعمیر شد.', 'msg' => 'محصول شارژ بررسی و تعمیر شد.' ] ) );
    }

    private function gateway() {
        $method = (string) apply_filters( 'kerp_wallet_charge_payment_method', get_option( 'nooshika_landing_payment_method', 'WC_ZPal' ) );
        // Offline methods cannot establish that money has been received.
        if ( in_array( strtolower( $method ), [ 'wallet', 'woo_wallet', 'cod', 'bacs', 'cheque' ], TRUE ) ) { return NULL; }
        $gateways = WC()->payment_gateways()->get_available_payment_gateways();
        return $gateways[ $method ] ?? NULL;
    }
    public function process_charge(): void {
        if ( ! is_user_logged_in() ) { $this->error( 'ابتدا وارد حساب کاربری شوید.' ); }
        $request = $this->input( 'request_id' );
        if ( ! wp_is_uuid( $request ) || ! wp_verify_nonce( $this->input( 'nonce' ), 'kerp_wallet_charge_' . $request ) ) {
            $this->error( 'اعتبار فرم منقضی شده است؛ صفحه را تازه کنید.' );
        }
        if ( ! KERP_Modules_Wallet_Settings::instance()->get()['enabled'] ) { $this->error( 'شارژ آنلاین کیف پول در حال حاضر غیرفعال است.' ); }
        $service = KERP_Modules_Wallet_Service::instance();
        if ( ! function_exists( 'wc_create_order' ) || ! $service->is_available() ) { $this->error( 'سرویس شارژ در دسترس نیست.' ); }
        $amount = $service->parse_amount( $this->input( 'amount' ) );
        if ( is_wp_error( $amount ) ) { $this->error( $amount->get_error_message() ); }
        $user_id = get_current_user_id();
        [ $minimum, $maximum ] = KERP_Modules_Wallet_Settings::instance()->limits( $user_id );
        if ( $amount < $minimum || ( $maximum > 0 && $amount > $maximum ) || $amount > 99999999 || (float) wc_format_decimal( $amount, wc_get_price_decimals() ) !== $amount ) {
            $this->error( sprintf( 'مبلغ شارژ باید بین %s و %s %s باشد و اعشار آن معتبر باشد.', number_format_i18n( $minimum ), number_format_i18n( $maximum ), get_woocommerce_currency_symbol() ) );
        }
        $gateway = $this->gateway();
        if ( ! $gateway instanceof WC_Payment_Gateway ) { $this->error( 'درگاه آنلاین تنظیم‌شده در نوشیکا فعال نیست.' ); }
        $product_id = $this->ensure_product();
        if ( is_wp_error( $product_id ) ) { $this->error( $product_id->get_error_message() ); }
        if ( ! $this->lock( 'create_' . $user_id ) ) { $this->error( 'درخواست دیگری در حال پردازش است؛ کمی بعد تلاش کنید.' ); }
        $response = NULL;
        try {
            $currency = get_woocommerce_currency();
            $request_key = 'kerp_wallet_order_' . $user_id . '_' . $request;
            $order_id = absint( get_option( $request_key, 0 ) );
            $order = $order_id ? wc_get_order( $order_id ) : FALSE;
            if ( $order_id && ( ! $this->is_charge( $order ) || (int) $order->get_customer_id() !== $user_id || (float) $order->get_meta( '_kerp_wallet_charge_amount' ) !== $amount || $order->get_currency() !== $currency ) ) {
                throw new RuntimeException( 'این فرم قبلاً با مبلغ دیگری ارسال شده است؛ صفحه را تازه کنید.' );
            }
            if ( $order && ! $order->needs_payment() ) {
                $response = [ 'status' => 'success', 'redirect' => $this->panel_url( $order ) ];
            } else {
                if ( ! $order ) {
                    // Serialize different tabs too; reuse only a recent unpaid order with the same currency and amount.
                    $recent = wc_get_orders( [ 'customer_id' => $user_id, 'status' => [ 'pending', 'failed' ], 'created_via' => 'kasebi-erp-wallet', 'limit' => 20, 'orderby' => 'date', 'order' => 'DESC' ] );
                    foreach ( $recent as $candidate ) {
                        if ( $this->is_charge( $candidate ) && (int) $candidate->get_customer_id() === $user_id && $candidate->needs_payment() && $candidate->get_date_created()->getTimestamp() > time() - HOUR_IN_SECONDS && (float) $candidate->get_total() === $amount && (float) $candidate->get_meta( '_kerp_wallet_charge_amount' ) === $amount && $candidate->get_currency() === $currency ) { $order = $candidate; break; }
                    }
                }
                if ( ! $order ) {
                    $order = wc_create_order( [ 'customer_id' => $user_id, 'created_via' => 'kasebi-erp-wallet' ] );
                    if ( ! $order instanceof WC_Order ) { throw new RuntimeException( 'ساخت سفارش انجام نشد.' ); }
                    $order->set_currency( $currency );
                    $order->update_meta_data( '_kerp_order_type', 'wallet_charge' );
                    $order->update_meta_data( '_kerp_wallet_charge_amount', $amount );
                    $order->update_meta_data( '_kerp_wallet_charge_user_id', $user_id );
                    $order->update_meta_data( '_kerp_wallet_charge_currency', $currency );
                    $order->set_billing_email( wp_get_current_user()->user_email );
                    $order->set_billing_phone( get_user_meta( $user_id, 'billing_phone', TRUE ) ?: get_user_meta( $user_id, 'nooshika_phone_num', TRUE ) );
                    $order->set_billing_first_name( get_user_meta( $user_id, 'first_name', TRUE ) );
                    $order->set_billing_last_name( get_user_meta( $user_id, 'last_name', TRUE ) );
                    if ( ! $order->add_product( wc_get_product( $product_id ), 1, [ 'subtotal' => $amount, 'total' => $amount ] ) ) { throw new RuntimeException( 'ثبت مبلغ سفارش انجام نشد.' ); }
                    $order->calculate_totals( FALSE );
                    $order->save();
                }
                if ( (float) $order->get_total() !== $amount ) { throw new RuntimeException( 'مبلغ سفارش با مبلغ شارژ تطبیق ندارد.' ); }
                update_option( $request_key, $order->get_id(), FALSE );
                if ( ! $order->get_meta( '_kerp_wallet_gateway_started' ) || $order->has_status( 'failed' ) ) {
                    $order->set_payment_method( $gateway );
                    $order->save();
                }
                // Schedule before calling the gateway: a lost browser response must not lose recovery.
                $this->schedule( $order->get_id() );
                if ( $order->has_status( 'failed' ) ) {
                    $order->delete_meta_data( '_kerp_wallet_gateway_started' );
                    $order->delete_meta_data( '_kerp_wallet_gateway_redirect' );
                    $order->set_status( 'pending' );
                    $order->save();
                }
                $redirect = (string) $order->get_meta( '_kerp_wallet_gateway_redirect' );
                if ( $redirect === '' ) {
                    if ( $order->get_meta( '_kerp_wallet_gateway_started' ) ) { throw new RuntimeException( 'درخواست پرداخت قبلاً ارسال شده و پاسخ آن نامشخص است؛ وضعیت سفارش را پیگیری کنید.' ); }
                    $order->update_meta_data( '_kerp_wallet_gateway_started', time() );
                    $order->save();
                    $result = $gateway->process_payment( $order->get_id() );
                    if ( ! is_array( $result ) || ( $result['result'] ?? '' ) !== 'success' || empty( $result['redirect'] ) ) {
                        $order->delete_meta_data( '_kerp_wallet_gateway_started' );
                        $order->save();
                        throw new RuntimeException( 'اتصال به درگاه انجام نشد؛ دوباره تلاش کنید.' );
                    }
                    $redirect = esc_url_raw( $result['redirect'] );
                    if ( $redirect === '' ) { throw new RuntimeException( 'نشانی درگاه معتبر نیست.' ); }
                    $order->update_meta_data( '_kerp_wallet_gateway_redirect', $redirect );
                    $order->save();
                }
                $response = [ 'status' => 'success', 'redirect' => $redirect, 'order_id' => $order->get_id() ];
            }
        } catch ( Throwable $e ) {
            $response = [ 'status' => 'error', 'message' => $e instanceof RuntimeException ? $e->getMessage() : 'ایجاد پرداخت انجام نشد؛ دوباره تلاش کنید.' ];
        } finally { $this->unlock( 'create_' . $user_id ); }
        wp_send_json( $response );
    }

    private function schedule( int $order_id, int $refund_id = 0 ): void {
        $hook = $refund_id ? 'kerp_wallet_retry_refund' : 'kerp_wallet_retry_charge';
        $args = $refund_id ? [ $order_id, $refund_id ] : [ $order_id ];
        if ( ! wp_next_scheduled( $hook, $args ) ) { wp_schedule_single_event( time() + 300, $hook, $args ); }
    }

    /** The receipt is written into the ledger row itself, so recovery survives a crash before order metadata is saved. */
    private function ledger_transaction( WC_Order $order, string $type, float $amount, int $refund_id = 0 ): int|WP_Error {
        global $wpdb;
        $user_id = (int) $order->get_customer_id();
        $receipt = 'KERP:' . get_current_blog_id() . ':' . $order->get_id() . ':' . ( $refund_id ?: 'charge' );
        $details = ( $refund_id ? 'برگشت شارژ کیف پول' : 'شارژ آنلاین کیف پول' ) . ' — سفارش #' . $order->get_id() . ' [' . $receipt . ']';
        $existing = $wpdb->get_var( $wpdb->prepare( "SELECT transaction_id FROM {$wpdb->base_prefix}woo_wallet_transactions WHERE user_id = %d AND type = %s AND details = %s LIMIT 1", $user_id, $type, $details ) );
        if ( $wpdb->last_error ) { return new WP_Error( 'ledger_unavailable', 'خواندن دفتر کیف پول انجام نشد.' ); }
        if ( $existing ) { return (int) $existing; }
        $key = 'kerp_wallet_receipt_' . md5( $receipt );
        // An interrupted call with no observable row is ambiguous: never automatically credit it again.
        if ( get_option( $key ) ) { return new WP_Error( 'review', 'نتیجه ثبت قبلی نامشخص است و نیاز به بررسی دارد.' ); }
        if ( ! KERP_Modules_Wallet_Service::instance()->is_available() ) { return new WP_Error( 'unavailable', 'کیف پول در دسترس نیست.' ); }
        if ( $type === 'debit' && (float) woo_wallet()->wallet->get_wallet_balance( $user_id, 'edit' ) < $amount ) { return new WP_Error( 'insufficient', 'موجودی برای برگشت شارژ کافی نیست؛ نیازمند پیگیری است.' ); }
        if ( ! add_option( $key, 'started', '', FALSE ) ) { return new WP_Error( 'review', 'ثبت قبلی نیاز به بررسی دارد.' ); }
        try {
            $id = woo_wallet()->wallet->{$type}( $user_id, $amount, $details, [ 'for' => 'kerp_wallet_charge', 'order_id' => $order->get_id(), 'currency' => $order->get_currency() ] );
            if ( ! $id || is_wp_error( $id ) ) {
                // A returned failure can be retried only after checking that no row was committed.
                $saved = $wpdb->get_var( $wpdb->prepare( "SELECT transaction_id FROM {$wpdb->base_prefix}woo_wallet_transactions WHERE user_id = %d AND type = %s AND details = %s LIMIT 1", $user_id, $type, $details ) );
                if ( $saved ) { return (int) $saved; }
                if ( $wpdb->last_error ) { return new WP_Error( 'review', 'تطبیق تراکنش نیاز به بررسی دارد.' ); }
                delete_option( $key );
                return new WP_Error( 'wallet_retry', 'ثبت در کیف پول انجام نشد؛ تلاش مجدد زمان‌بندی شد.' );
            }
            update_option( $key, (int) $id, FALSE );
            if ( function_exists( 'update_wallet_transaction_meta' ) ) {
                update_wallet_transaction_meta( (int) $id, 'kerp_order_id', $order->get_id(), $user_id );
                update_wallet_transaction_meta( (int) $id, 'kerp_source', $refund_id ? 'charge_refund' : 'online_charge', $user_id );
            }
            return (int) $id;
        } catch ( Throwable $e ) { return new WP_Error( 'review', 'پاسخ ثبت تراکنش نامشخص است؛ نیازمند بررسی است.' ); }
    }

    public function complete( int $order_id ): void {
        $order = wc_get_order( $order_id );
        if ( ! $this->is_charge( $order ) || $order->get_meta( '_kerp_wallet_charge_processed' ) === 'yes' ) { return; }
        if ( ! $order->is_paid() || ! $order->get_date_paid() ) { return; }
        if ( ! $this->lock( 'settle_' . $order_id ) ) { $this->schedule( $order_id ); return; }
        try {
            $order = wc_get_order( $order_id );
            $order->read_meta_data( TRUE );
            if ( $order->get_meta( '_kerp_wallet_charge_processed' ) === 'yes' || ! $order->is_paid() || ! $order->get_date_paid() ) { return; }
            $amount = (float) $order->get_meta( '_kerp_wallet_charge_amount' );
            if ( $order->get_customer_id() <= 0 || ! get_userdata( $order->get_customer_id() ) || ! is_finite( $amount ) || $amount <= 0 || $amount !== (float) $order->get_total() || $order->get_currency() !== $order->get_meta( '_kerp_wallet_charge_currency' ) || (int) $order->get_customer_id() !== (int) $order->get_meta( '_kerp_wallet_charge_user_id' ) || $order->get_total_refunded() > 0 || in_array( $order->get_payment_method(), [ 'wallet', 'woo_wallet', 'cod', 'bacs', 'cheque', '' ], TRUE ) ) {
                $this->problem( $order, 'مبلغ، ارز یا وضعیت سفارش شارژ نیاز به بررسی دارد.', TRUE ); return;
            }
            // Schedule before the write, including recovery from a hard process interruption.
            $this->schedule( $order_id );
            $id = $this->ledger_transaction( $order, 'credit', $amount );
            if ( is_wp_error( $id ) ) { $this->problem( $order, $id->get_error_message(), $id->get_error_code() === 'review' ); return; }
            $order->update_meta_data( '_kerp_wallet_charge_processed', 'yes' );
            $order->update_meta_data( '_kerp_wallet_transaction_id', $id );
            $order->delete_meta_data( '_kerp_wallet_charge_error' );
            $order->save();
            $order->add_order_note( 'شارژ کیف پول ثبت شد. تراکنش #' . $id );
			if ( $order->get_meta( '_kerp_wallet_charge_sms_sent' ) !== 'yes' ) {
				$order->update_meta_data( '_kerp_wallet_charge_sms_sent', 'yes' );
				$order->save();
				do_action( 'kerp_wallet_transaction_created', (int) $id, (int) $order->get_customer_id(), 'credit', $amount, 'شارژ آنلاین کیف پول' );
			}
            wp_clear_scheduled_hook( 'kerp_wallet_retry_charge', [ $order_id ] );
        } catch ( Throwable $e ) {
            $this->schedule( $order_id );
        } finally { $this->unlock( 'settle_' . $order_id ); }
    }
    private function problem( WC_Order $order, string $message, bool $review = FALSE ): void {
        if ( $order->get_meta( '_kerp_wallet_charge_error' ) !== $message ) { $order->add_order_note( $message ); }
        $attempts = (int) $order->get_meta( '_kerp_wallet_charge_attempts' ) + 1;
        $order->update_meta_data( '_kerp_wallet_charge_attempts', $attempts );
        $order->update_meta_data( '_kerp_wallet_charge_error', $message );
        $order->save();
        if ( ! $review && $attempts < 5 ) { $this->schedule( $order->get_id() ); }
        else { wp_clear_scheduled_hook( 'kerp_wallet_retry_charge', [ $order->get_id() ] ); }
    }
    public function refund( int $order_id, int $refund_id ): void {
        $order = wc_get_order( $order_id );
        $refund = wc_get_order( $refund_id );
        if ( ! $this->is_charge( $order ) || ! $refund instanceof WC_Order_Refund || $refund->get_parent_id() !== $order_id ) { return; }
        if ( ! $this->lock( 'settle_' . $order_id ) ) { $this->schedule( $order_id, $refund_id ); return; }
        try {
            $order->read_meta_data( TRUE );
            $key = '_kerp_wallet_refund_' . $refund_id;
            if ( $order->get_meta( $key ) ) { return; }
            if ( $order->get_meta( '_kerp_wallet_charge_processed' ) !== 'yes' ) {
                // A refund may arrive after the ledger insert but before the charge marker was saved.
                global $wpdb;
                $receipt = 'KERP:' . get_current_blog_id() . ':' . $order_id . ':charge';
                $details = 'شارژ آنلاین کیف پول — سفارش #' . $order_id . ' [' . $receipt . ']';
                $credit_id = $wpdb->get_var( $wpdb->prepare( "SELECT transaction_id FROM {$wpdb->base_prefix}woo_wallet_transactions WHERE user_id = %d AND type = %s AND details = %s LIMIT 1", $order->get_customer_id(), 'credit', $details ) );
                if ( ! $credit_id ) {
                    if ( $wpdb->last_error || get_option( 'kerp_wallet_receipt_' . md5( $receipt ) ) ) {
                        $this->problem( $order, 'بازپرداخت ثبت شده است؛ وضعیت شارژ قبلی نیاز به تطبیق دارد.', TRUE );
                    }
                    return;
                }
                $order->update_meta_data( '_kerp_wallet_charge_processed', 'yes' );
                $order->update_meta_data( '_kerp_wallet_transaction_id', (int) $credit_id );
                $order->save();
            }
            $amount = (float) $refund->get_amount();
            if ( ! is_finite( $amount ) || $amount <= 0 || $order->get_total_refunded() > (float) $order->get_meta( '_kerp_wallet_charge_amount' ) ) { return; }
            $this->schedule( $order_id, $refund_id );
            $id = $this->ledger_transaction( $order, 'debit', $amount, $refund_id );
            if ( is_wp_error( $id ) ) {
                $this->problem( $order, 'برگشت شارژ: ' . $id->get_error_message(), TRUE );
                wp_clear_scheduled_hook( 'kerp_wallet_retry_refund', [ $order_id, $refund_id ] );
                return;
            }
            $order->update_meta_data( $key, $id );
            $order->save();
            $order->add_order_note( 'مبلغ بازپرداخت از کیف پول کسر شد. تراکنش #' . $id );
            wp_clear_scheduled_hook( 'kerp_wallet_retry_refund', [ $order_id, $refund_id ] );
        } finally { $this->unlock( 'settle_' . $order_id ); }
    }

    public function panel_url( WC_Order $order ): string {
        return add_query_arg( [ 'wallet_order' => $order->get_id() ], home_url( '/panel/wallet/' ) );
    }
    public function return_url( string $url, $order ): string {
        return $this->is_charge( $order ) ? $this->panel_url( $order ) : $url;
    }
    public function redirect_return(): void {
        $received = function_exists( 'is_order_received_page' ) && is_order_received_page();
        $order_id = $received ? absint( get_query_var( 'order-received' ) ) : ( isset( $_GET['wallet_order'] ) && is_scalar( $_GET['wallet_order'] ) ? absint( $_GET['wallet_order'] ) : 0 );
        if ( ! $order_id || ! is_user_logged_in() ) { return; }
        $order = wc_get_order( $order_id );
        if ( ! $this->is_charge( $order ) || (int) $order->get_customer_id() !== get_current_user_id() ) { return; }
        $this->complete( $order_id );
        if ( $received ) { wp_safe_redirect( $this->panel_url( $order ) ); exit; }
    }
}
