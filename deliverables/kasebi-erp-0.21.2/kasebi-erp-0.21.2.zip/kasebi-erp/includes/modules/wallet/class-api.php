<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Wallet_Api {
	private static ?self $instance = NULL;

	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'kasebi_ajax_wallet_add_transaction', [ $this, 'add_transaction' ] );
	}

	private function __clone() {}
	public function __wakeup(): void { throw new LogicException( 'Cannot unserialize a singleton.' ); }

	public function add_transaction(): void {
		if ( ! is_user_logged_in() || ! KERP_App::instance()->current_user_has_access() ) {
			$this->error( __( 'شما به سامانه دسترسی ندارید.', 'kasebi-erp' ) );
		}

		foreach ( [ 'customer_id', 'employee_id', 'type', 'amount', 'details', 'return_page', 'wallet_nonce', 'wallet_request_id' ] as $field ) {
			if ( isset( $_POST[ $field ] ) && ! is_string( $_POST[ $field ] ) ) {
				$this->error( __( 'درخواست معتبر نیست.', 'kasebi-erp' ) );
			}
		}
		$request_id = (string) wp_unslash( $_POST['wallet_request_id'] ?? '' );
		$nonce = (string) wp_unslash( $_POST['wallet_nonce'] ?? '' );
		$is_employee = isset( $_POST['employee_id'] );
		$employee_id = absint( $_POST['employee_id'] ?? 0 );
		if ( $is_employee && ( isset( $_POST['customer_id'] ) || ! KERP_Modules_Wallet_Module::instance()->can_access_employee( $employee_id ) ) ) {
			$this->error( __( 'به کارمند انتخاب‌شده دسترسی ندارید.', 'kasebi-erp' ) );
		}
		$nonce_suffix = $is_employee ? '_employee_' . $employee_id : '';
		if ( ! wp_is_uuid( $request_id ) || ! wp_verify_nonce( $nonce, 'kerp_wallet_' . $request_id . $nonce_suffix ) ) {
			$this->error( __( 'اعتبار فرم منقضی شده است. صفحه را تازه‌سازی کنید.', 'kasebi-erp' ) );
		}
		$customer_id = $is_employee ? $employee_id : absint( $_POST['customer_id'] ?? 0 );
		$type        = sanitize_key( (string) wp_unslash( $_POST['type'] ?? '' ) );
		$amount = KERP_Modules_Wallet_Service::instance()->parse_amount( wp_unslash( $_POST['amount'] ?? '' ) );
		if ( is_wp_error( $amount ) ) {
			$this->error( $amount->get_error_message() );
		}
		$details     = sanitize_textarea_field( wp_unslash( $_POST['details'] ?? '' ) );
		if ( $is_employee && trim( $details ) === '' ) {
			$this->error( __( 'شرح تراکنش را وارد کنید.', 'kasebi-erp' ) );
		}

		if ( ! in_array( $type, [ 'credit', 'debit' ], TRUE ) ) {
			$this->error( __( 'نوع تراکنش معتبر نیست.', 'kasebi-erp' ) );
		}
		if ( ! kerp_can( 'wallet.' . $type, 'action' ) ) {
			$this->error( __( 'شما اجازه ثبت این نوع تراکنش را ندارید.', 'kasebi-erp' ) );
		}
		if ( $is_employee && $type === 'debit' && (float) KERP_Modules_Wallet_Service::instance()->get_balance( $employee_id ) < $amount ) {
			$this->error( __( 'موجودی کیف پول برای این برداشت کافی نیست.', 'kasebi-erp' ) );
		}

		// A unique option name atomically claims this form, including concurrent retries.
		$request_key = 'kerp_wallet_request_' . get_current_user_id() . '_' . $request_id;
		if ( ! add_option( $request_key, [ 'status' => 'processing', 'created_at' => time() ], '', FALSE ) ) {
			$this->error( __( 'این درخواست قبلاً ارسال شده است. پیش از ثبت مجدد، تراکنش‌ها را بررسی و صفحه را تازه‌سازی کنید.', 'kasebi-erp' ) );
		}
		$result = KERP_Modules_Wallet_Service::instance()->add_transaction( $customer_id, $type, $amount, $details );
		if ( is_wp_error( $result ) ) {
			delete_option( $request_key );
			$this->error( $result->get_error_message() );
		}
		update_option( $request_key, [ 'status' => 'completed', 'transaction_id' => $result ], FALSE );

		$page = sanitize_text_field( wp_unslash( $_POST['return_page'] ?? '' ) );
		if ( $is_employee ) {
			$page = '/erp/employees/' . $employee_id . '/?tab=wallet';
		}
		if ( $page === '' ) {
			$page = add_query_arg( 'tab', 'wallet', '/erp/customers/' . $customer_id . '/' );
		}

		$response = KERP_Api_Page_Content::build_page_response( $page, $this->route_query( $page ), TRUE );
		$this->success( __( 'تراکنش کیف پول با موفقیت ثبت شد.', 'kasebi-erp' ), $response );
	}

	private function route_query( string $page ): array {
		$query = wp_parse_url( $page, PHP_URL_QUERY );
		if ( ! is_string( $query ) || $query === '' ) {
			return [];
		}
		parse_str( $query, $args );
		return is_array( $args ) ? $args : [];
	}

	private function success( string $message, array $data = [] ): void {
		wp_send_json( array_merge( [ 'status' => 'success', 'message' => $message, 'msg' => $message ], $data ) );
	}

	private function error( string $message, array $data = [] ): void {
		wp_send_json( array_merge( [ 'status' => 'error', 'message' => $message, 'msg' => $message ], $data ) );
	}
}
