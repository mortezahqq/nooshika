<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Wallet_Service {
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public function is_available(): bool {
		return function_exists( 'woo_wallet' )
		       && function_exists( 'get_wallet_transactions' )
		       && is_object( woo_wallet() )
		       && isset( woo_wallet()->wallet );
	}
	
	public function get_balance( int $user_id, bool $formatted = FALSE ): float|string {
		if ( $user_id <= 0 || ! $this->is_available() ) {
			return $formatted ? '—' : 0.0;
		}
		
		$balance = (float) woo_wallet()->wallet->get_wallet_balance( $user_id, 'edit' );
		
		return $formatted ? $this->format_amount_text( $balance ) : $balance;
	}
	
	public function get_transactions( int $user_id, int $page_number = 1, int $per_page = 20 ): array {
		$page_number = max( 1, $page_number );
		$per_page    = max( 1, min( 100, $per_page ) );
		
		if ( $user_id <= 0 || ! $this->is_available() ) {
			return [
				'items'       => [],
				'total'       => 0,
				'total_pages' => 1,
				'page_number' => $page_number,
				'per_page'    => $per_page,
			];
		}
		
		$offset = ( $page_number - 1 ) * $per_page;
		$args   = [
			'user_id'  => $user_id,
			'order_by' => 'transaction_id',
			'order'    => 'DESC',
			'limit'    => $offset . ',' . $per_page,
		];
		
		$items = (array) get_wallet_transactions( $args );
		$total = function_exists( 'get_wallet_transactions_count' )
			? absint( get_wallet_transactions_count( [ 'user_id' => $user_id ] ) )
			: count( (array) get_wallet_transactions( [ 'user_id' => $user_id ] ) );
		
		return [
			'items'       => $items,
			'total'       => $total,
			'total_pages' => max( 1, (int) ceil( $total / $per_page ) ),
			'page_number' => $page_number,
			'per_page'    => $per_page,
		];
	}
	
	public function add_transaction( int $user_id, string $type, float $amount, string $details = '' ): int|WP_Error {
		if ( ! $this->is_available() ) {
			return new WP_Error( 'wallet_unavailable', __( 'افزونه کیف پول در دسترس نیست.', 'kasebi-erp' ) );
		}
		if ( $user_id <= 0 || ! get_userdata( $user_id ) instanceof WP_User ) {
			return new WP_Error( 'invalid_wallet_user', __( 'کاربر انتخاب‌شده معتبر نیست.', 'kasebi-erp' ) );
		}
		
		$type   = sanitize_key( $type );
		$amount = (float) $amount;
		if ( ! in_array( $type, [ 'credit', 'debit' ], TRUE ) ) {
			return new WP_Error( 'invalid_wallet_type', __( 'نوع تراکنش معتبر نیست.', 'kasebi-erp' ) );
		}
		if ( ! is_finite( $amount ) || $amount <= 0 ) {
			return new WP_Error( 'invalid_wallet_amount', __( 'مبلغ تراکنش باید بیشتر از صفر باشد.', 'kasebi-erp' ) );
		}
		
		$details = trim( sanitize_textarea_field( $details ) );
		if ( $details === '' ) {
			$details = __( 'اصلاح دستی موجودی کیف پول از ERP', 'kasebi-erp' );
		}
		
		$transaction_id = 'credit' === $type
			? woo_wallet()->wallet->credit( $user_id, $amount, $details, [ 'for' => 'kerp_manual_adjustment' ] )
			: woo_wallet()->wallet->debit( $user_id, $amount, $details, [ 'for' => 'kerp_manual_adjustment' ] );
		
		if ( ! $transaction_id ) {
			$message = 'debit' === $type
				? __( 'ثبت برداشت انجام نشد. موجودی کیف پول یا محدودیت‌های TeraWallet را بررسی کنید.', 'kasebi-erp' )
				: __( 'ثبت افزایش موجودی انجام نشد.', 'kasebi-erp' );
			
			return new WP_Error( 'wallet_transaction_failed', $message );
		}
		
		$transaction_id = absint( $transaction_id );
		if ( function_exists( 'set_wallet_transaction_meta' ) ) {
			set_wallet_transaction_meta( $transaction_id, 'kerp_created_by', get_current_user_id(), $user_id );
			set_wallet_transaction_meta( $transaction_id, 'kerp_source', 'kasebi-erp', $user_id );
		}
		do_action( 'kerp_wallet_transaction_created', $transaction_id, $user_id, $type, $amount, $details );
		
		return $transaction_id;
	}
	
	public function format_amount_text( float $amount, string $currency = '' ): string {
		return KERP_Helpers_Template::price( $amount, $currency ? [ 'currency' => $currency ] : [] );
	}
	
	public function parse_amount( mixed $raw ): float|WP_Error {
		$raw = is_string( $raw ) ? trim( KERP_Helpers_Format::sanitize_numbers( $raw ) ) : $raw;
		$raw = str_replace( [ '٬', '٫' ], [ ',', '.' ], $raw );
		if ( ! preg_match( '/^(?:[0-9]+|[0-9]{1,3}(?:,[0-9]{3})+)(?:\.[0-9]+)?$/D', $raw ) ) {
			return new WP_Error( 'invalid_wallet_amount', __( 'مبلغ تراکنش معتبر نیست.', 'kasebi-erp' ) );
		}
		$amount = (float) str_replace( ',', '', $raw );
		
		return is_finite( $amount ) && $amount > 0 ? $amount : new WP_Error( 'invalid_wallet_amount', __( 'مبلغ تراکنش باید عددی معتبر و بیشتر از صفر باشد.', 'kasebi-erp' ) );
	}
	
	public function format_transaction_amount( object $transaction ): string {
		$amount   = (float) ( $transaction->amount ?? 0 );
		$currency = sanitize_text_field( (string) ( $transaction->currency ?? '' ) );
		
		return $this->format_amount_text( $amount, $currency );
	}
	
	public function format_transaction_date( object $transaction, string $format = 'Y/m/d H:i' ): string {
		$date = trim( (string) ( $transaction->date ?? '' ) );
		if ( $date === '' ) {
			return '—';
		}
		$timestamp = strtotime( $date );
		
		return $timestamp ? date_i18n( $format, $timestamp ) : ( $format === 'H:i' ? '' : $date );
	}
	
	public function get_type_label( string $type ): string {
		return 'credit' === sanitize_key( $type )
			? __( 'بستانکار', 'kasebi-erp' )
			: __( 'بدهکار', 'kasebi-erp' );
	}
	
}
