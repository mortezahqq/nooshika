<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Wallet_SMS {
	private const OPTION = 'kerp_wallet_sms_rules';
	private static ?self $instance = NULL;
	private mixed $service = NULL;

	public static function instance(): self { return self::$instance ??= new self(); }
	private function __construct() {
		add_action( 'kerp_wallet_transaction_created', [ $this, 'transaction_created' ], 20, 5 );
		add_action( 'kerp_wallet_withdrawal_created', [ $this, 'withdrawal_created' ], 20 );
		add_action( 'kerp_wallet_withdrawal_status_changed', [ $this, 'withdrawal_changed' ], 20, 3 );
	}

	public function service_available(): bool { return class_exists( 'kasebiSMS' ) && method_exists( 'kasebiSMS', 'send_pattern_sms' ); }
	public function get_rules(): array { $rules = get_option( self::OPTION, [] ); return is_array( $rules ) ? array_values( $rules ) : []; }
	public function events(): array { return [ 'wallet_credit' => 'واریز وجه به کیف پول مشتری', 'withdrawal_created' => 'ثبت درخواست برداشت وجه', 'withdrawal_paid' => 'تأیید واریز وجه برداشت' ]; }
	public function recipients(): array { return [ 'customer' => 'مشتری', 'custom' => 'شماره دلخواه' ]; }
	public function variables(): array { return [ '{customer_id}' => 'شناسه مشتری', '{customer_name}' => 'نام مشتری', '{customer_phone}' => 'موبایل مشتری', '{amount}' => 'مبلغ تراکنش', '{balance}' => 'موجودی پس از تراکنش', '{withdrawal_id}' => 'شناسه درخواست', '{bank_name}' => 'نام بانک', '{payment_reference}' => 'شماره پیگیری', '{site_name}' => 'نام سایت' ]; }

	public function save_rules( array $rules ): void {
		$clean = [];
		foreach ( $rules as $rule ) {
			if ( ! is_array( $rule ) ) { continue; }
			$event = is_scalar( $rule['event'] ?? '' ) ? sanitize_key( (string) ( $rule['event'] ?? '' ) ) : ''; $recipient = is_scalar( $rule['recipient'] ?? '' ) ? sanitize_key( (string) ( $rule['recipient'] ?? '' ) ) : '';
			$pattern = is_scalar( $rule['pattern'] ?? '' ) ? sanitize_text_field( (string) ( $rule['pattern'] ?? '' ) ) : ''; $receptor = is_scalar( $rule['receptor'] ?? '' ) ? sanitize_text_field( (string) ( $rule['receptor'] ?? '' ) ) : '';
			$variables = is_scalar( $rule['variables'] ?? '' ) ? sanitize_textarea_field( (string) ( $rule['variables'] ?? '' ) ) : '';
			if ( $event === '' && $recipient === '' && $pattern === '' ) { continue; }
			if ( ! isset( $this->events()[ $event ], $this->recipients()[ $recipient ] ) || $pattern === '' ) { continue; }
			$clean[] = [ 'enabled' => '1', 'event' => $event, 'recipient' => $recipient, 'receptor' => $receptor, 'pattern' => $pattern, 'variables' => $variables ];
		}
		update_option( self::OPTION, $clean, FALSE );
	}

	public function transaction_created( int $transaction_id, int $user_id, string $type, float $amount, string $details ): void {
		if ( $type !== 'credit' || str_contains( $details, '[KERP:withdrawal-refund:' ) ) { return; }
		$this->send( 'wallet_credit', [ 'user_id' => $user_id, 'amount' => $amount, 'withdrawal_id' => 0, 'bank_name' => '', 'payment_reference' => '' ] );
	}
	public function withdrawal_created( array $request ): void { $this->send( 'withdrawal_created', $request ); }
	public function withdrawal_changed( array $request, string $old, string $new ): void { if ( $new === 'paid' ) { $this->send( 'withdrawal_paid', $request ); } }

	private function send( string $event, array $data ): void {
		if ( ! $this->service_available() ) { return; }
		$user_id = absint( $data['user_id'] ?? 0 ); $user = get_userdata( $user_id );
		$phone = $this->user_phone( $user_id );
		$context = [
			'{customer_id}' => (string) $user_id, '{customer_name}' => $user ? trim( $user->first_name . ' ' . $user->last_name ) : '',
			'{customer_phone}' => $phone, '{amount}' => $this->amount( $data['amount'] ?? 0 ),
			'{balance}' => $this->amount( KERP_Modules_Wallet_Service::instance()->get_balance( $user_id, FALSE ) ),
			'{withdrawal_id}' => (string) absint( $data['id'] ?? $data['withdrawal_id'] ?? 0 ),
			'{bank_name}' => (string) ( $data['bank_name'] ?? '' ), '{payment_reference}' => (string) ( $data['payment_reference'] ?? '' ), '{site_name}' => (string) get_bloginfo( 'name' ),
		];
		foreach ( $this->get_rules() as $rule ) {
			if ( ( $rule['event'] ?? '' ) !== $event ) { continue; }
			$numbers = $this->numbers( $rule, $phone ); $vars = $this->parse_variables( (string) ( $rule['variables'] ?? '' ) ); $tokens = [];
			foreach ( $vars as $key => $template ) { $tokens[ $key ] = $this->pattern_value( strtr( $template, $context ) ); }
			foreach ( $numbers as $number ) { $payload = [ 'receptor' => $number, 'pattern' => (string) $rule['pattern'] ] + $tokens; $response = $this->sms_service()->send_pattern_sms( $payload ); do_action( 'kerp_wallet_sms_sent', $response, $payload, $rule, $data ); }
		}
	}

	private function numbers( array $rule, string $customer ): array {
		$type = (string) ( $rule['recipient'] ?? '' ); $numbers = [];
		if ( $type === 'customer' ) { $numbers[] = $customer; }
		elseif ( $type === 'custom' ) { $numbers = explode( ',', (string) ( $rule['receptor'] ?? '' ) ); }
		return array_values( array_unique( array_filter( array_map( [ $this, 'normalize_phone' ], $numbers ) ) ) );
	}
	private function user_phone( int $id ): string { foreach ( [ 'nooshika_phone_num', 'billing_phone' ] as $key ) { $phone = $this->normalize_phone( (string) get_user_meta( $id, $key, TRUE ) ); if ( $phone !== '' ) { return $phone; } } return ''; }
	private function normalize_phone( string $raw ): string { if ( function_exists( 'nooshika_sanitize_numbers' ) ) { $raw = nooshika_sanitize_numbers( $raw ); } if ( function_exists( 'remove_zero_from_phone' ) ) { return trim( (string) remove_zero_from_phone( $raw ) ); } return preg_replace( '/\D+/', '', $raw ) ?? ''; }
	private function parse_variables( string $raw ): array { $out = []; foreach ( preg_split( '/\s*;\s*/u', trim( $raw ), -1, PREG_SPLIT_NO_EMPTY ) ?: [] as $item ) { $at = strpos( $item, ':' ); if ( $at === FALSE ) { $at = strpos( $item, '=' ); } if ( $at === FALSE ) { continue; } $key = preg_replace( '/[^A-Za-z0-9_-]/', '', trim( substr( $item, 0, $at ) ) ) ?: ''; if ( $key !== '' ) { $out[ $key ] = trim( substr( $item, $at + 1 ) ); } } return $out; }
	private function pattern_value( string $value ): string { return str_replace( [ ' ', '_' ], '-', sanitize_text_field( $value ) ); }
	private function amount( mixed $amount ): string { return rtrim( rtrim( number_format( (float) $amount, 2, '.', '' ), '0' ), '.' ); }
	private function sms_service(): mixed { return $this->service ??= new kasebiSMS(); }
}
