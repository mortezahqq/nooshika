<?php
defined( 'ABSPATH' ) || exit;

/** Integer micrograms, always expressed as equivalent fineness 750. */
final class KERP_Modules_Gold_Math {
    public const SCALE = 1000000;

    public static function units( $value ): int {
        $value = strtr( trim( (string) $value ), array_combine( preg_split( '//u', '۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩', -1, PREG_SPLIT_NO_EMPTY ), str_split( '01234567890123456789' ) ) );
        if ( ! preg_match( '/^\d{1,8}(?:\.\d{1,6})?$/D', $value ) ) {
            throw new InvalidArgumentException( 'وزن باید عدد مثبت با حداکثر شش رقم اعشار و ممیز نقطه باشد.' );
        }
        [ $whole, $fraction ] = array_pad( explode( '.', $value, 2 ), 2, '' );
        $units = (int) $whole * self::SCALE + (int) str_pad( $fraction, 6, '0' );
        if ( $units <= 0 ) { throw new InvalidArgumentException( 'وزن باید بیشتر از صفر باشد.' ); }
        return $units;
    }

    /** Currency stored in integer minor units, using WooCommerce precision at entry time. */
    public static function money( $value, ?int $decimals = null ): int {
        $decimals = $decimals ?? wc_get_price_decimals();
        if ( $decimals < 0 || $decimals > 6 ) { throw new InvalidArgumentException( 'دقت واحد پول پشتیبانی نمی‌شود.' ); }
        $value = strtr( trim( (string) $value ), array_combine( preg_split( '//u', '۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩', -1, PREG_SPLIT_NO_EMPTY ), str_split( '01234567890123456789' ) ) );
        $pattern = $decimals ? '/^\d{1,12}(?:\.\d{1,' . $decimals . '})?$/D' : '/^\d{1,12}$/D';
        if ( ! preg_match( $pattern, $value ) ) { throw new InvalidArgumentException( 'مبلغ با دقت واحد پول فروشگاه سازگار نیست؛ جداکننده هزارگان وارد نکنید.' ); }
        [ $whole, $fraction ] = array_pad( explode( '.', $value, 2 ), 2, '' );
        $amount = (int) $whole * ( 10 ** $decimals ) + (int) str_pad( $fraction, $decimals, '0' );
        if ( $amount <= 0 || $amount > 999999999999999 ) { throw new InvalidArgumentException( 'مبلغ باید مثبت و در محدوده مجاز باشد.' ); }
        return $amount;
    }

    public static function format_money( int $amount, int $decimals ): string {
        return number_format( $amount / ( 10 ** $decimals ), $decimals, '.', '' );
    }

    public static function equivalent( int $units, int $purity ): int {
        if ( $units <= 0 || $units > 99999999999999 || $purity < 1 || $purity > 1000 ) {
            throw new InvalidArgumentException( 'وزن یا عیار نامعتبر است.' );
        }
        return intdiv( $units * $purity + 375, 750 );
    }

    public static function grams( int $units ): string {
        return sprintf( '%s%d.%06d', $units < 0 ? '-' : '', intdiv( abs( $units ), self::SCALE ), abs( $units ) % self::SCALE );
    }
}
