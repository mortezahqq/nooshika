<?php
defined( 'ABSPATH' ) || exit;

/** Optional fixed-host bot transport. Secrets are read from wp-config, never rendered or logged. */
final class KERP_Modules_Gold_Notifications {
    public static function register(): void {
        add_action( 'kerp_gold_deliver_event', [ self::class, 'deliver' ] );
    }

    public static function configured(): bool {
        return defined( 'KERP_GOLD_BOT_SERVICE' ) && in_array( KERP_GOLD_BOT_SERVICE, [ 'telegram', 'bale' ], true )
            && defined( 'KERP_GOLD_BOT_TOKEN' ) && is_string( KERP_GOLD_BOT_TOKEN ) && preg_match( '/^[A-Za-z0-9:_-]{10,200}$/D', KERP_GOLD_BOT_TOKEN )
            && defined( 'KERP_GOLD_BOT_CHAT_ID' ) && is_scalar( KERP_GOLD_BOT_CHAT_ID ) && (string) KERP_GOLD_BOT_CHAT_ID !== '';
    }

    public static function queue( int $id ): void {
        global $wpdb;
        if ( ! self::configured() ) { return; }
        $wpdb->query( $wpdb->prepare( 'UPDATE ' . KERP_Modules_Gold_Store::table( 'events' ) . " SET delivery='queued' WHERE id=%d AND delivery='local'", $id ) );
        if ( ! wp_next_scheduled( 'kerp_gold_deliver_event', [ $id ] ) ) { wp_schedule_single_event( time() + 1, 'kerp_gold_deliver_event', [ $id ] ); }
    }

    public static function deliver( int $id ): void {
        global $wpdb;
        if ( ! self::configured() ) { return; }
        $table = KERP_Modules_Gold_Store::table( 'events' );
        $now = time();
        // Atomic claim prevents concurrent cron/manual runs from submitting the same event.
        $claimed = $wpdb->query( $wpdb->prepare( "UPDATE $table SET delivery='sending',attempts=attempts+1,last_attempt=%d WHERE id=%d AND attempts<5 AND (delivery IN ('local','queued','failed') OR (delivery='sending' AND last_attempt<%d))", $now, $id, $now - 120 ) );
        if ( $claimed !== 1 ) { return; }
        $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE id=%d", $id ) );
        // Recovery in case PHP terminates while a request is in flight.
        wp_schedule_single_event( time() + 180, 'kerp_gold_deliver_event', [ $id ] );
        $base = KERP_GOLD_BOT_SERVICE === 'telegram' ? 'https://api.telegram.org/bot' : 'https://tapi.bale.ai/bot';
        $detail = '';
        if ( $row->event === 'replacement_pending' ) {
            $units = $wpdb->get_var( $wpdb->prepare( 'SELECT units FROM ' . KERP_Modules_Gold_Store::table( 'replacement' ) . ' WHERE order_id=%d', (int) $row->reference ) );
            if ( $units ) { $detail = "\nوزن لازم برای خرید جایگزین: " . KERP_Modules_Gold_Math::grams( (int) $units ) . ' گرم عیار ۷۵۰'; }
        }
        $text = $row->hashtag . "\n" . KERP_Modules_Gold_Admin::label( $row->event ) . "\nشناسه پیگیری: " . $row->reference . "\nشماره اعلان: " . $id . $detail;
        $response = wp_remote_post( $base . KERP_GOLD_BOT_TOKEN . '/sendMessage', [ 'timeout' => 15, 'redirection' => 0, 'body' => [ 'chat_id' => (string) KERP_GOLD_BOT_CHAT_ID, 'text' => $text ] ] );
        $json = is_wp_error( $response ) ? null : json_decode( wp_remote_retrieve_body( $response ), true );
        $sent = ! is_wp_error( $response ) && wp_remote_retrieve_response_code( $response ) === 200 && is_array( $json ) && ! empty( $json['ok'] );
        $wpdb->update( $table, [ 'delivery' => $sent ? 'sent' : 'failed' ], [ 'id' => $id ] );
        if ( $sent ) { wp_clear_scheduled_hook( 'kerp_gold_deliver_event', [ $id ] ); }
        // At most five attempts. Provider timeouts can cause duplicate messages; event id stays fixed.
    }
}
