<?php
defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Gold_Commerce {
    public static function register(): void {
        add_action( 'woocommerce_checkout_create_order', [ self::class, 'order_snapshot' ], 10, 2 );
        add_action( 'woocommerce_order_status_changed', [ KERP_Modules_Gold_Business::class, 'index_sale' ] );
        add_action( 'woocommerce_order_refunded', [ KERP_Modules_Gold_Business::class, 'index_sale' ], 20 );
        add_action( 'woocommerce_product_options_general_product_data', [ self::class, 'fields' ] );
        add_action( 'woocommerce_admin_process_product_object', [ self::class, 'save' ] );
        add_action( 'woocommerce_checkout_create_order_line_item', [ self::class, 'snapshot' ], 10, 4 );
        add_action( 'woocommerce_payment_complete', [ self::class, 'paid' ] );
        add_action( 'woocommerce_order_status_processing', [ self::class, 'paid' ] );
        add_action( 'woocommerce_order_status_completed', [ self::class, 'paid' ] );
        add_action( 'woocommerce_order_status_cancelled', [ self::class, 'review' ] );
        add_action( 'woocommerce_order_status_failed', [ self::class, 'review' ] );
        add_action( 'woocommerce_order_status_refunded', [ self::class, 'review' ] );
        add_action( 'woocommerce_order_refunded', [ self::class, 'review' ] );
        add_filter( 'woocommerce_checkout_registration_required', [ self::class, 'registration_required' ] );
        // Blocks checkout uses a different lifecycle; reject gold-specific products until supported.
        add_action( 'woocommerce_store_api_checkout_order_processed', [ self::class, 'block_checkout_guard' ] );
    }

    public static function order_snapshot( $order, $data ): void {
        $order->update_meta_data( '_kerp_gold_plus_at_sale', KERP_Modules_Gold_Module::is_plus( (int) $order->get_customer_id() ) ? 'yes' : 'no' );
        $order->update_meta_data( '_kerp_gold_money_decimals', wc_get_price_decimals() );
    }

    public static function fields(): void {
        echo '<div class="options_group show_if_simple">';
        woocommerce_wp_text_input( [ 'id' => '_kerp_gold_replace', 'label' => 'طلای جایگزین (گرم ۷۵۰)', 'description' => 'مجموع وزن معادل طلا و اجرت برای هر واحد؛ مثال 1.300000. خالی یعنی محصول غیرطلایی. قیمت فروش محصول به‌صورت عادی در ووکامرس تعیین می‌شود.' ] );
        echo '</div>';
    }

    public static function save( $product ): void {
        if ( ! current_user_can( 'edit_post', $product->get_id() ) || ! isset( $_POST['_kerp_gold_replace'] ) ) { return; }
        $raw = KERP_Modules_Gold_Module::input( '_kerp_gold_replace' );
        try {
            $value = $raw === '' ? '' : KERP_Modules_Gold_Math::grams( KERP_Modules_Gold_Math::units( $raw ) );
            $product->update_meta_data( '_kerp_gold_replace', $value );
        } catch ( Throwable $e ) { WC_Admin_Meta_Boxes::add_error( $e->getMessage() ); }
    }

    public static function snapshot( $item, $key, $values, $order ): void {
        $product = $values['data'];
        if ( ! $product || ! $product->is_type( 'simple' ) ) { return; }
        $calc = KERP_Modules_Gold_Pricing::calculate( $product, (int) $order->get_customer_id() );
        if ( $product->get_meta( '_kerp_gold_dynamic' ) === 'yes' && ! $calc ) { throw new Exception( 'نرخ معتبر برای محصول طلایی در دسترس نیست.' ); }
        $grams = (string) $product->get_meta( '_kerp_gold_replace' );
        if ( $calc ) { $grams = KERP_Modules_Gold_Math::grams( $calc['replacement_units'] ); }
        if ( $grams !== '' ) {
            $units = KERP_Modules_Gold_Math::units( $grams );
            $quantity = (float) $item->get_quantity();
            if ( $quantity <= 0 || $quantity !== floor( $quantity ) || $quantity > 100000 ) { throw new Exception( 'تعداد محصول طلایی باید عدد صحیح مثبت باشد.' ); }
            $item->add_meta_data( '_kerp_gold_units', $units * (int) $quantity, true );
            $item->add_meta_data( '_kerp_gold_pack', (string) $product->get_meta( '_kerp_gold_pack' ), true );
            if ( $calc ) {
                $item->add_meta_data( '_kerp_gold_physical_units', $calc['physical_units'] * (int) $quantity, true );
                $item->add_meta_data( '_kerp_gold_price_snapshot', $calc, true );
            }
        }
        $s = KERP_Modules_Gold_Module::settings();
        if ( $product->get_id() === (int) $s['plus_product'] ) {
            $item->add_meta_data( '_kerp_plus_days', (int) $s['plus_days'], true );
        }
    }

    public static function registration_required( $required ): bool {
        $id = (int) KERP_Modules_Gold_Module::settings()['plus_product'];
        if ( $id && WC()->cart ) {
            foreach ( WC()->cart->get_cart() as $item ) { if ( (int) $item['product_id'] === $id ) { return true; } }
        }
        return (bool) $required;
    }

    public static function block_checkout_guard( $order ): void {
        $id = (int) KERP_Modules_Gold_Module::settings()['plus_product'];
        foreach ( $order->get_items() as $item ) {
            $product = $item->get_product();
            if ( $product && ( $product->get_meta( '_kerp_gold_replace' ) !== '' || $product->get_meta( '_kerp_gold_dynamic' ) === 'yes' || ( $id && $product->get_id() === $id ) ) ) {
                throw new Exception( 'برای محصولات طلا و اشتراک پلاس از صفحه تسویه‌حساب کلاسیک استفاده کنید.' );
            }
        }
    }

    public static function paid( $order_id ): bool {
        global $wpdb;
        $order = wc_get_order( $order_id );
        if ( ! $order || ! $order->is_paid() ) { return false; }
        $units = 0;
        $days = 0;
        foreach ( $order->get_items() as $item_id => $item ) {
            $units += max( 0, (int) $item->get_meta( '_kerp_gold_units' ) );
            if ( abs( $order->get_qty_refunded_for_item( $item_id ) ) === 0 ) { $days = max( $days, (int) $item->get_meta( '_kerp_plus_days' ) ); }
        }
        try {
            KERP_Modules_Gold_Store::replacement( (int) $order_id, $units );
            if ( $order->get_total_refunded() > 0 ) { self::review( $order_id ); }
            if ( $days > 0 && $order->get_customer_id() ) {
                $paid = $order->get_date_paid();
                $start = $paid ? $paid->getTimestamp() : time();
                $result = $wpdb->query( $wpdb->prepare( 'INSERT IGNORE INTO ' . KERP_Modules_Gold_Store::table( 'memberships' ) . ' (order_id,user_id,expires_at) VALUES (%d,%d,%d)', $order_id, $order->get_customer_id(), $start + $days * DAY_IN_SECONDS ) );
                if ( $result === false ) { throw new RuntimeException( 'ثبت اشتراک ناموفق بود.' ); }
                if ( $result === 1 ) { KERP_Modules_Gold_Module::event( 'plus_activated', (string) $order_id ); }
            }
            KERP_Modules_Gold_Business::index_sale( $order_id );
            KERP_Modules_Gold_Packaging::enqueue( (int) $order_id );
            return true;
        } catch ( Throwable $e ) {
            $order->add_order_note( 'خطای عملیات طلا: ' . $e->getMessage() . ' پس از رفع خطا، عملیات پرداخت طلا را از صفحه بنکداری دوباره اجرا کنید.' );
            KERP_Modules_Gold_Module::event( 'paid_error', (string) $order_id );
            return false;
        }
    }

    public static function review( $order_id ): void {
        global $wpdb;
        $order = wc_get_order( $order_id );
        if ( ! $order ) { return; }
        $table = KERP_Modules_Gold_Store::table( 'replacement' );
        $changed = $wpdb->query( $wpdb->prepare( "UPDATE $table SET status=CASE WHEN status='completed' THEN 'review_bought' ELSE 'review' END,note=%s WHERE order_id=%d AND status IN ('pending','completed')", 'سفارش لغو، ناموفق یا بازپرداخت شده؛ وزن و معامله فروشنده را دستی بررسی کنید.', $order_id ) );
        KERP_Modules_Gold_Packaging::review( (int) $order_id );
        // Revoke Plus only when its line is refunded, or the whole order is invalidated.
        $revoke = $order->has_status( [ 'cancelled', 'failed', 'refunded' ] );
        foreach ( $order->get_items() as $item_id => $item ) {
            if ( (int) $item->get_meta( '_kerp_plus_days' ) > 0 && abs( $order->get_qty_refunded_for_item( $item_id ) ) > 0 ) { $revoke = true; }
        }
        if ( $revoke ) { $wpdb->delete( KERP_Modules_Gold_Store::table( 'memberships' ), [ 'order_id' => (int) $order_id ] ); }
        if ( $changed ) { KERP_Modules_Gold_Module::event( 'replacement_review', (string) $order_id ); }
    }
}
