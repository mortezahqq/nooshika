<?php
defined( 'ABSPATH' ) || exit;
final class KERP_Modules_Gold_Public {
    private static function begin(): void {
        if ( ! defined( 'DONOTCACHEPAGE' ) ) { define( 'DONOTCACHEPAGE', true ); }
        if ( ! headers_sent() ) { nocache_headers(); }
        wp_enqueue_style( 'kerp-gold' ); wp_enqueue_script( 'kerp-gold-panel' );
        echo '<section class="kerp-gold" dir="rtl">';
    }
    public static function svg( string $kind ): string {
        $paths = [ 'wallet' => 'M20 8V6a2 2 0 0 0-2-2H6a3 3 0 0 0 0 6h14v10H6a3 3 0 0 1-3-3V7m17 6h-4v4h4', 'course' => 'M3 5h6a4 4 0 0 1 3 1 4 4 0 0 1 3-1h6v14h-6a4 4 0 0 0-3 1 4 4 0 0 0-3-1H3V5m9 1v14', 'shop' => 'M3 9h18l-2-6H5L3 9zm2 0v12h14V9m-9 12v-7h4v7', 'support' => 'M4 13v-2a8 8 0 0 1 16 0v2M4 12H2v7h4v-7H4zm16 0h2v7h-4v-7h2zm0 7c0 2-3 3-7 3', 'roadmap' => 'M3 5l6-2 6 2 6-2v16l-6 2-6-2-6 2V5zm6-2v16m6-14v16', 'gifts' => 'M3 8h18v5H3V8zm2 5v8h14v-8m-7-5v13M12 8H8a3 3 0 1 1 3-3l1 3zm0 0h4a3 3 0 1 0-3-3l-1 3z', 'ai' => 'M12 3l2.5 6.5L21 12l-6.5 2.5L12 21l-2.5-6.5L3 12l6.5-2.5L12 3z', 'channel' => 'M3 4h18v13H9l-6 4V4z', 'extra' => 'M4 4h6v6H4V4zm10 0h6v6h-6V4zM4 14h6v6H4v-6zm10 0h6v6h-6v-6z' ];
        $path = $paths[ $kind ] ?? $paths['extra'];
        return '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="' . esc_attr( $path ) . '"></path></svg>';
    }
    public static function plus(): string {
        ob_start(); self::begin(); $s = KERP_Modules_Gold_Module::settings(); $active = KERP_Modules_Gold_Module::is_plus( get_current_user_id() );
        echo '<header class="kgp-head"><div><span class="kgp-eyebrow">باشگاه کاربران پلاس</span><h2>' . ( $active ? 'مسیر شما از اینجا ادامه دارد' : 'یک عضویت، مجموعه‌ای از فرصت‌ها' ) . '</h2><p>' . esc_html( $s['landing'] ) . '</p></div><span class="kgp-head-icon">' . self::svg( 'ai' ) . '</span></header>';
        if ( $active ) {
            global $wpdb; $expiry = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT MAX(expires_at) FROM ' . KERP_Modules_Gold_Store::table( 'memberships' ) . ' WHERE user_id=%d', get_current_user_id() ) );
            echo '<div class="kgp-membership"><span class="kgp-dot"></span><strong>اشتراک پلاس شما فعال است</strong><span>اعتبار تا <bdi>' . esc_html( KERP_Modules_Gold_Ui::date( gmdate( 'Y-m-d H:i:s', $expiry ), false ) ) . '</bdi></span></div><div class="kgp-section-title"><h3>خدمات شما</h3><span>بخش موردنظرتان را انتخاب کنید.</span></div><div class="kgp-grid">';
            $descriptions = [ 'wallet' => 'دارایی طلایی و درخواست‌های شما', 'shop' => 'محصولات زینتی و پیشنهادهای فروش', 'course' => 'ادامه یادگیری و محتوای آموزشی', 'support' => 'ارتباط با تیم پشتیبانی', 'roadmap' => 'قدم بعدی مسیر رشد شما', 'gifts' => 'هدایا و امتیازهای ویژه', 'ai' => 'ابزارها و خدمات هوش مصنوعی', 'channel' => 'مطالب و اطلاع‌رسانی‌های اختصاصی', 'extra' => 'دسترسی به خدمات بیشتر' ]; $count = 0;
            foreach ( KERP_Modules_Gold_Module::links() as $key => $label ) { if ( ! $s[ 'link_' . $key ] ) { continue; } ++$count; echo '<a class="kgp-service" href="' . esc_url( $s[ 'link_' . $key ] ) . '"><span class="kgp-service-icon">' . self::svg( $key ) . '</span><h3>' . esc_html( $label ) . '</h3><p>' . esc_html( $descriptions[ $key ] ) . '</p><span class="kgp-service-open">ورود به بخش <span aria-hidden="true">←</span></span></a>'; }
            if ( ! $count ) { echo '<div class="kgp-empty">خدمات شما پس از تنظیم نشانی‌ها، در این بخش نمایش داده می‌شوند.</div>'; } echo '</div>';
        } else {
            echo '<div class="kgp-offer"><div><span class="kgp-eyebrow">همراه مسیر شما</span><h3>خدمات آموزشی و طلایی، کنار هم</h3><p>با عضویت پلاس، خدمات و مسیر آموزش شما در یک پنل در دسترس است.</p><ul class="kgp-benefits"><li>دسترسی یک‌جا به دوره و نقشه راه</li><li>کیف طلایی و خدمات بنکداری</li><li>خدمات و پیشنهادهای ویژه اعضا</li></ul></div><div class="kgp-price-card"><span>اشتراک پلاس</span>';
            $product = $s['plus_product'] ? wc_get_product( $s['plus_product'] ) : false;
            if ( $product && $product->is_purchasable() && $product->is_in_stock() ) { echo '<strong>' . wp_kses_post( $product->get_price_html() ) . '</strong><small>' . esc_html( number_format_i18n( $s['plus_days'] ) ) . ' روز دسترسی به خدمات</small><a class="kgp-button" href="' . esc_url( get_permalink( $product->get_id() ) ) . '">خرید اشتراک پلاس</a>'; }
            else { echo '<p>برای تهیه اشتراک با پشتیبانی تماس بگیرید.</p>'; }
            if ( ! is_user_logged_in() ) { echo '<a class="kgp-text-link" href="' . esc_url( wp_login_url( get_permalink() ) ) . '">قبلاً عضو شده‌اید؟ ورود به حساب</a>'; } echo '</div></div>';
        }
        echo '</section>'; return ob_get_clean();
    }
    public static function wallet(): string {
        ob_start(); self::begin();
        echo '<header class="kgp-head kgp-head-compact"><div><span class="kgp-eyebrow">حساب طلایی شما</span><h2>کیف طلایی</h2><p>موجودی، درخواست‌ها و گردش طلای خود را دنبال کنید.</p></div><span class="kgp-head-icon">' . self::svg( 'wallet' ) . '</span></header>';
        if ( ! is_user_logged_in() ) { echo '<div class="kgp-empty"><h3>به حساب طلایی خود وارد شوید</h3><p>موجودی و سوابق فقط برای صاحب حساب نمایش داده می‌شوند.</p><a class="kgp-button" href="' . esc_url( wp_login_url( get_permalink() ) ) . '">ورود به حساب</a></div></section>'; return ob_get_clean(); }
        KERP_Modules_Gold_Admin::messages(); $id = get_current_user_id(); $balance = KERP_Modules_Gold_Store::balance( $id ); $quote = KERP_Modules_Gold_Module::quote(); $plus = KERP_Modules_Gold_Module::is_plus( $id ); $s = KERP_Modules_Gold_Module::settings();
        global $wpdb; $reserved = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COALESCE(SUM(units),0) FROM ' . KERP_Modules_Gold_Store::table( 'requests' ) . " WHERE user_id=%d AND status='pending' AND kind<>'buy'", $id ) );
        echo '<div class="kgp-wallet-grid"><div class="kgp-balance-card"><div class="kgp-balance-head"><span>موجودی آزاد</span><span class="kgp-status is-local">عیار ۷۵۰</span></div><div class="kgp-balance"><bdi>' . esc_html( KERP_Modules_Gold_Ui::weight( $balance ) ) . '</bdi><small>گرم طلا</small></div><p>موجودی قابل استفاده پس از کسر درخواست‌های رزروشده</p>';
        if ( $plus ) { echo '<a class="kgp-button" href="#gold-wallet-request" data-kgp-kind="buy">خرید طلا</a>'; } echo '</div><div class="kgp-wallet-stats"><div><span>آخرین نرخ معتبر هر گرم</span><strong>' . ( $quote ? wp_kses_post( wc_price( $quote['rate'] ) ) : 'در انتظار به‌روزرسانی' ) . '</strong><small>' . ( $quote ? 'ثبت نرخ: <bdi>' . esc_html( KERP_Modules_Gold_Ui::date( gmdate( 'Y-m-d H:i:s', $quote['timestamp'] ) ) ) . '</bdi>' : 'تا ثبت نرخ معتبر، برآورد نمایش داده نمی‌شود.' ) . '</small></div><div><span>ارزش تقریبی موجودی آزاد</span><strong>' . ( $quote ? wp_kses_post( wc_price( $balance / KERP_Modules_Gold_Math::SCALE * $quote['rate'] ) ) : '—' ) . '</strong></div><div><span>وزن رزروشده درخواست‌ها</span><strong><bdi>' . esc_html( KERP_Modules_Gold_Ui::weight( $reserved ) ) . '</bdi> گرم</strong></div></div></div>';
        if ( $plus ) {
            echo '<div class="kgp-card" id="gold-wallet-request"><div class="kgp-section-title"><h3>درخواست جدید</h3><span>پس از ثبت، تیم بنکداری آن را بررسی می‌کند.</span></div><p class="kgp-info">خرید پس از توافق نرخ، دریافت وجه و تأیید مدیر به موجودی اضافه می‌شود. این فرم پرداخت اینترنتی یا معامله قطعی ایجاد نمی‌کند.</p>';
            KERP_Modules_Gold_Admin::start_form( 'request' ); KERP_Modules_Gold_Ui::hidden( 'reference', wp_generate_uuid4() ); KERP_Modules_Gold_Ui::hidden( 'return_url', get_permalink() );
            echo '<div class="kgp-form-grid"><div class="kg-field"><label class="form-label" for="kgp-kind">نوع درخواست</label><select class="form-control" id="kgp-kind" name="kind"><option value="buy">خرید طلا</option>';
            foreach ( [ 'cash' => 'تسویه نقدی', 'physical' => 'تحویل فیزیکی', 'jewelry' => 'مصرف برای زیورآلات' ] as $kind => $label ) { if ( $s[ 'allow_' . $kind ] ) { echo '<option value="' . esc_attr( $kind ) . '">' . esc_html( $label ) . '</option>'; } }
            echo '</select></div>'; KERP_Modules_Gold_Admin::field( 'grams', 'وزن به گرم عیار ۷۵۰', '', 'text', true ); echo '</div>'; KERP_Modules_Gold_Admin::field( 'note', 'توضیحات درخواست', '', 'text', true );
            if ( $s['allow_physical'] ) { echo '<p class="kgp-hint">حداقل تحویل فیزیکی: <bdi>' . esc_html( $s['physical_min'] ) . '</bdi> گرم. برای مصرف زینتی، نام محصول یا شماره سفارش را در توضیحات بنویسید.</p>'; }
            echo '<div class="kgp-form-bottom"><span class="kgp-estimate" aria-live="polite" data-kgp-rate="' . esc_attr( $quote['rate'] ?? '' ) . '" data-kgp-unit="' . esc_attr( html_entity_decode( wp_strip_all_tags( get_woocommerce_currency_symbol() ) ) ) . '" data-kgp-decimals="' . (int) wc_get_price_decimals() . '">برآورد خرید پس از وارد کردن وزن نمایش داده می‌شود.</span><button class="kgp-button" type="submit">ثبت درخواست</button></div></form></div>';
        } else { echo '<div class="kgp-info">برای ثبت درخواست جدید، اشتراک پلاس فعال لازم است. موجودی و سوابق شما محفوظ است.</div>'; }
        self::history( $id ); echo '</section>'; return ob_get_clean();
    }
    private static function history( int $id ): void {
        global $wpdb; $view = isset( $_GET['gold_history'] ) && $_GET['gold_history'] === 'ledger' ? 'ledger' : 'requests'; $page = max( 1, isset( $_GET['gold_page'] ) ? (int) $_GET['gold_page'] : 1 );
        $table = KERP_Modules_Gold_Store::table( $view ); $total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $table WHERE user_id=%d", $id ) ); $pages = max( 1, (int) ceil( $total / 25 ) ); $page = min( $page, $pages ); $rows = KERP_Modules_Gold_Store::rows( $view, $id, $page );
        echo '<div class="kgp-card"><div class="kgp-section-title"><h3>فعالیت‌های من</h3><span>' . esc_html( number_format_i18n( $total ) ) . ' مورد</span></div><nav class="kgp-history-tabs" aria-label="نوع سوابق">';
        foreach ( [ 'requests' => 'درخواست‌ها', 'ledger' => 'گردش طلایی' ] as $key => $label ) { echo '<a href="' . esc_url( add_query_arg( [ 'gold_history' => $key, 'gold_page' => 1 ], get_permalink() ) ) . '" ' . ( $key === $view ? 'aria-current="page" class="is-active"' : '' ) . '>' . esc_html( $label ) . '</a>'; } echo '</nav>';
        if ( ! $rows ) { echo '<div class="kgp-empty"><span class="kgp-service-icon">' . self::svg( 'wallet' ) . '</span><h3>هنوز فعالیتی ثبت نشده است</h3><p>درخواست‌ها و گردش موجودی طلایی شما در این بخش نمایش داده می‌شوند.</p></div>'; }
        else {
            echo '<div class="kgp-table-wrap"><table class="kgp-table"><thead><tr><th>شماره</th><th>شرح</th><th>وزن</th><th>' . ( $view === 'requests' ? 'وضعیت' : 'موجودی پس از ثبت' ) . '</th><th>زمان</th></tr></thead><tbody>';
            foreach ( $rows as $row ) {
                echo '<tr><td data-label="شماره">#' . (int) $row->id . '</td><td data-label="شرح">';
                if ( $view === 'requests' ) { echo '<strong>' . esc_html( KERP_Modules_Gold_Admin::label( $row->kind ) ) . '</strong><span>' . esc_html( $row->note ) . '</span>'; if ( $row->resolution ) { echo '<small>نتیجه: ' . esc_html( $row->resolution ) . '</small>'; } }
                else { echo esc_html( $row->note ); }
                echo '</td><td data-label="وزن"><bdi>' . esc_html( KERP_Modules_Gold_Ui::weight( (int) ( $row->units ?? $row->delta ) ) ) . '</bdi> گرم</td><td data-label="' . ( $view === 'requests' ? 'وضعیت' : 'موجودی' ) . '">';
                echo $view === 'requests' ? '<span class="kgp-status is-' . esc_attr( $row->status ) . '">' . esc_html( KERP_Modules_Gold_Admin::label( $row->status ) ) . '</span>' : '<bdi>' . esc_html( KERP_Modules_Gold_Ui::weight( (int) $row->balance ) ) . '</bdi> گرم';
                echo '</td><td data-label="زمان"><bdi>' . esc_html( KERP_Modules_Gold_Ui::date( $row->created_at ) ) . '</bdi></td></tr>';
            } echo '</tbody></table></div>';
        }
        if ( $pages > 1 ) { echo '<nav class="kgp-pagination" aria-label="صفحه‌های سوابق">'; if ( $page > 1 ) { echo '<a href="' . esc_url( add_query_arg( [ 'gold_history' => $view, 'gold_page' => $page - 1 ], get_permalink() ) ) . '">صفحه قبل</a>'; } echo '<span>صفحه ' . esc_html( number_format_i18n( $page ) ) . ' از ' . esc_html( number_format_i18n( $pages ) ) . '</span>'; if ( $page < $pages ) { echo '<a href="' . esc_url( add_query_arg( [ 'gold_history' => $view, 'gold_page' => $page + 1 ], get_permalink() ) ) . '">صفحه بعد</a>'; } echo '</nav>'; } echo '</div>';
    }
}
