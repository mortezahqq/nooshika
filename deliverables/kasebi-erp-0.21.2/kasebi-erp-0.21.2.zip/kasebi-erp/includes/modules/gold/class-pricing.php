<?php
defined( 'ABSPATH' ) || exit;

/** Explicit opt-in base formula. WooCommerce continues to handle tax, coupons and the shopping cart. */
final class KERP_Modules_Gold_Pricing {
    private static array $state_changes = [];
    public static function register(): void {
        add_action( 'woocommerce_product_options_general_product_data', [ self::class, 'fields' ], 20 );
        add_action( 'woocommerce_admin_process_product_object', [ self::class, 'save' ], 20 );
        add_action( 'woocommerce_update_product', [ self::class, 'saved' ] );
        add_action( 'woocommerce_new_product', [ self::class, 'saved' ] );
        add_filter( 'woocommerce_product_get_price', [ self::class, 'price' ], 20, 2 );
        add_filter( 'woocommerce_product_get_regular_price', [ self::class, 'price' ], 20, 2 );
        add_filter( 'woocommerce_product_get_sale_price', static function ( $price, $product ) { return $product->get_meta( '_kerp_gold_dynamic' ) === 'yes' ? '' : $price; }, 20, 2 );
        add_action( 'template_redirect', [ self::class, 'no_cache' ] );
        add_filter( 'woocommerce_is_purchasable', [ self::class, 'purchasable' ], 20, 2 );
    }
    public static function no_cache(): void {
        if ( ! function_exists( 'is_product' ) ) { return; }
        $product = is_product() ? wc_get_product( get_queried_object_id() ) : false;
        if ( is_cart() || is_checkout() || ( $product && $product->get_meta( '_kerp_gold_dynamic' ) === 'yes' ) ) {
            if ( ! defined( 'DONOTCACHEPAGE' ) ) { define( 'DONOTCACHEPAGE', true ); }
            if ( ! headers_sent() ) { nocache_headers(); }
        }
    }

    public static function fields(): void {
        echo '<div class="options_group show_if_simple">';
        woocommerce_wp_checkbox( [ 'id' => '_kerp_gold_dynamic', 'label' => 'قیمت‌گذاری طلایی', 'description' => 'اختیاری: ارزش طلا + اجرت درصدی + اجرت ثابت + هزینه پک؛ قوانین مالیات و تخفیف ووکامرس اعمال می‌شوند.' ] );
        foreach ( [ 'weight' => 'وزن واقعی هر واحد (گرم)', 'purity' => 'عیار هر واحد (۱ تا ۱۰۰۰)', 'wage_percent' => 'اجرت درصدی', 'plus_wage_percent' => 'اجرت درصدی پلاس؛ خالی یعنی عمومی', 'wage_fixed' => 'اجرت ثابت هر واحد', 'pack' => 'عنوان پک یا بسته', 'pack_fee' => 'هزینه بسته برای هر واحد' ] as $key => $label ) { woocommerce_wp_text_input( [ 'id' => '_kerp_gold_' . $key, 'label' => $label ] ); }
        woocommerce_wp_select( [ 'id' => '_kerp_gold_state', 'label' => 'وضعیت کالا', 'options' => [ '' => 'پیش‌فرض: موجود' ] + KERP_Modules_Gold_Module::states() ] );
        woocommerce_wp_text_input( [ 'id' => '_kerp_gold_supplier_book', 'label' => 'شناسه حساب تأمین‌کننده', 'description' => 'اختیاری؛ از بخش طرف‌حساب‌های بنکداری.' ] );
        echo '</div>';
    }
    public static function save( $product ): void {
        if ( ! current_user_can( 'edit_post', $product->get_id() ) || ! isset( $_POST['_kerp_gold_state'] ) || ! $product->is_type( 'simple' ) ) { return; }
        $input = [ KERP_Modules_Gold_Module::class, 'input' ];
        try {
            $data = [];
            foreach ( [ 'weight', 'purity', 'wage_percent', 'plus_wage_percent', 'wage_fixed', 'pack', 'pack_fee', 'state', 'supplier_book' ] as $key ) { $data[ $key ] = $input( '_kerp_gold_' . $key ); }
            $data['state'] = $data['state'] ?: 'in_stock';
            if ( ! isset( KERP_Modules_Gold_Module::states()[ $data['state'] ] ) ) { throw new InvalidArgumentException( 'وضعیت محصول نامعتبر است.' ); }
            $enabled = $input( '_kerp_gold_dynamic' ) === 'yes';
            if ( $enabled ) {
                KERP_Modules_Gold_Math::equivalent( KERP_Modules_Gold_Math::units( $data['weight'] ), (int) $data['purity'] );
                if ( ! preg_match( '/^\d{1,4}$/D', $data['purity'] ) ) { throw new InvalidArgumentException( 'عیار نامعتبر است.' ); }
                foreach ( [ 'wage_percent', 'plus_wage_percent' ] as $key ) {
                    if ( $key === 'plus_wage_percent' && $data[ $key ] === '' ) { continue; }
                    $data[ $key ] = $data[ $key ] === '' ? '0' : $data[ $key ];
                    if ( ! preg_match( '/^\d{1,4}(?:\.\d{1,6})?$/D', $data[ $key ] ) || (float) $data[ $key ] > 1000 ) { throw new InvalidArgumentException( 'درصد اجرت نامعتبر است.' ); }
                }
                foreach ( [ 'wage_fixed', 'pack_fee' ] as $key ) {
                    $data[ $key ] = $data[ $key ] === '' ? '0' : $data[ $key ];
                    if ( $data[ $key ] !== '0' ) { KERP_Modules_Gold_Math::money( $data[ $key ] ); }
                }
            }
            if ( $data['supplier_book'] !== '' ) {
                global $wpdb;
                $party = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . KERP_Modules_Gold_Store::table( 'books' ) . ' WHERE id=%d', (int) $data['supplier_book'] ) );
                if ( ! $party || $party->kind !== 'party' ) { throw new InvalidArgumentException( 'حساب تأمین‌کننده معتبر نیست.' ); }
            }
            $old = (string) $product->get_meta( '_kerp_gold_state' );
            self::$state_changes[ $product->get_id() ] = [ $old, $data['state'] ];
            foreach ( $data as $key => $value ) { $product->update_meta_data( '_kerp_gold_' . $key, $value ); }
            $product->update_meta_data( '_kerp_gold_dynamic', $enabled ? 'yes' : 'no' );
        } catch ( Throwable $e ) { WC_Admin_Meta_Boxes::add_error( $e->getMessage() ); }
    }
    public static function saved( int $id ): void {
        if ( ! isset( self::$state_changes[ $id ] ) ) { return; }
        [ $old, $new ] = self::$state_changes[ $id ]; unset( self::$state_changes[ $id ] );
        KERP_Modules_Gold_Business::status_history( $id, 'product', $old, $new );
    }
    public static function calculate( $product, int $user_id ): ?array {
        if ( $product->get_meta( '_kerp_gold_dynamic' ) !== 'yes' ) { return null; }
        $quote = KERP_Modules_Gold_Module::quote(); if ( ! $quote ) { return null; }
        try {
            $weight = KERP_Modules_Gold_Math::equivalent( KERP_Modules_Gold_Math::units( $product->get_meta( '_kerp_gold_weight' ) ), (int) $product->get_meta( '_kerp_gold_purity' ) );
            $percent = $product->get_meta( '_kerp_gold_wage_percent' ) ?: '0';
            $plus_percent = $product->get_meta( '_kerp_gold_plus_wage_percent' );
            if ( $plus_percent !== '' && KERP_Modules_Gold_Module::is_plus( $user_id ) ) { $percent = $plus_percent; }
            $fixed = (float) $product->get_meta( '_kerp_gold_wage_fixed' ); $pack = (float) $product->get_meta( '_kerp_gold_pack_fee' );
            $base = $weight / KERP_Modules_Gold_Math::SCALE * $quote['rate'];
            $wage = $base * (float) $percent / 100 + $fixed;
            $price = round( $base + $wage + $pack, wc_get_price_decimals() );
            if ( ! is_finite( $price ) || $price <= 0 || $price > 999999999999 ) { return null; }
            return [ 'price' => $price, 'physical_units' => $weight, 'replacement_units' => $weight + (int) round( $wage / $quote['rate'] * KERP_Modules_Gold_Math::SCALE ), 'rate' => $quote['rate'], 'wage_percent' => (float) $percent, 'wage' => $wage, 'pack_fee' => $pack ];
        } catch ( Throwable $e ) { return null; }
    }
    public static function price( $price, $product ) {
        if ( $product->get_meta( '_kerp_gold_dynamic' ) !== 'yes' ) { return $price; }
        $result = self::calculate( $product, get_current_user_id() ); return $result ? (string) $result['price'] : '';
    }
    public static function purchasable( $can, $product ): bool {
        $managed = $product->get_meta( '_kerp_gold_replace' ) !== '' || $product->get_meta( '_kerp_gold_dynamic' ) === 'yes';
        if ( ! $managed ) { return (bool) $can; }
        if ( ! $product->is_type( 'simple' ) ) { return false; }
        $state = $product->get_meta( '_kerp_gold_state' ) ?: 'in_stock';
        if ( ! in_array( $state, [ 'in_stock', 'consigned' ], true ) ) { return false; }
        if ( $product->get_meta( '_kerp_gold_dynamic' ) === 'yes' && ! self::calculate( $product, get_current_user_id() ) ) { return false; }
        return (bool) $can;
    }
}
