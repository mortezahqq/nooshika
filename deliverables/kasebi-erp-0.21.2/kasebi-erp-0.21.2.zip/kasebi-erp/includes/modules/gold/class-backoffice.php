<?php
defined( 'ABSPATH' ) || exit;
final class KERP_Modules_Gold_Backoffice {
    private static function input( string $key ): string { return KERP_Modules_Gold_Module::input( $key ); }
    public static function render( string $section ): void { KERP_Modules_Gold_Ui::render_section( $section ); }
    public static function transfer(): void {
        $kind = self::input( 'asset' );
        if ( ! in_array( $kind, [ 'gold', 'money', 'exchange' ], true ) ) { throw new InvalidArgumentException( 'نوع انتقال نامعتبر است.' ); }
        $from = (int) self::input( 'from_book' ); $to = (int) self::input( 'to_book' );
        $legs = [];
        if ( $kind === 'gold' || $kind === 'exchange' ) { $legs[] = [ 'from' => $from, 'to' => $to, 'asset' => 'gold', 'amount' => KERP_Modules_Gold_Math::units( self::input( 'grams' ) ) ]; }
        if ( $kind === 'money' || $kind === 'exchange' ) { $legs[] = [ 'from' => $kind === 'exchange' ? $to : $from, 'to' => $kind === 'exchange' ? $from : $to, 'asset' => KERP_Modules_Gold_Business::money_asset(), 'amount' => KERP_Modules_Gold_Math::money( self::input( 'money' ) ) ]; }
        KERP_Modules_Gold_Business::post( self::input( 'reference' ), self::input( 'note' ), $legs );
    }
    public static function sale(): void {
        $raw_ids = $_POST['product_ids'] ?? []; $raw_qty = $_POST['quantities'] ?? [];
        if ( ! is_array( $raw_ids ) || ! is_array( $raw_qty ) || count( $raw_ids ) > 30 ) { throw new InvalidArgumentException( 'ردیف‌های محصول نامعتبرند.' ); }
        $items = [];
        foreach ( $raw_ids as $i => $id ) {
            if ( ! is_scalar( $id ) || ! isset( $raw_qty[ $i ] ) || ! is_scalar( $raw_qty[ $i ] ) ) { throw new InvalidArgumentException( 'محصول یا تعداد نامعتبر است.' ); }
            if ( (string) $id === '' && (string) $raw_qty[ $i ] === '' ) { continue; }
            $items[] = [ 'product_id' => absint( $id ), 'quantity' => sanitize_text_field( wp_unslash( (string) $raw_qty[ $i ] ) ) ];
        }
        $order_id = KERP_Modules_Gold_Business::offline_sale( [ 'source' => self::input( 'source' ), 'user_id' => self::input( 'user_id' ), 'reference' => self::input( 'reference' ), 'method' => self::input( 'method' ), 'receipt' => self::input( 'receipt' ) ], $items );
        set_transient( 'kerp_gold_sale_result_' . get_current_user_id(), $order_id, 120 );
    }
}
