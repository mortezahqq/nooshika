<?php
defined( 'ABSPATH' ) || exit;
final class KERP_Modules_Gold_Ui_Data {
    public static function summary(): array {
        global $wpdb; $t = [ KERP_Modules_Gold_Store::class, 'table' ];
        [ $from, $until ] = KERP_Modules_Gold_Business::range( wp_date( 'Y-m-d' ), wp_date( 'Y-m-d' ) );
        $sales = $wpdb->get_row( $wpdb->prepare( 'SELECT COUNT(*) count,COALESCE(SUM(total-refunded),0) total FROM ' . $t( 'sales' ) . ' WHERE paid_at>=%s AND paid_at<%s AND currency=%s AND decimals=%d', $from, $until, get_woocommerce_currency(), wc_get_price_decimals() ) );
        return [ 'free' => (int) $wpdb->get_var( 'SELECT COALESCE(SUM(balance),0) FROM ' . $t( 'accounts' ) ),
            'reserved' => (int) $wpdb->get_var( 'SELECT COALESCE(SUM(units),0) FROM ' . $t( 'requests' ) . " WHERE status='pending' AND kind<>'buy'" ),
            'requests' => (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . $t( 'requests' ) . " WHERE status='pending'" ),
            'replacement' => (int) $wpdb->get_var( 'SELECT COALESCE(SUM(units),0) FROM ' . $t( 'replacement' ) . " WHERE status='pending'" ),
            'replacement_count' => (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . $t( 'replacement' ) . " WHERE status='pending'" ),
            'packaging' => (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . $t( 'packaging' ) . " WHERE status IN ('pending','packing','packed')" ),
            'sales_count' => (int) ( $sales->count ?? 0 ), 'sales_total' => (int) ( $sales->total ?? 0 ) ];
    }
    public static function week(): array {
        global $wpdb; $out = []; $today = new DateTimeImmutable( wp_date( 'Y-m-d' ), wp_timezone() );
        for ( $i = 6; $i >= 0; --$i ) { $day = $today->modify( '-' . $i . ' days' )->format( 'Y-m-d' ); [ $from, $to ] = KERP_Modules_Gold_Business::range( $day, $day ); $out[] = [ 'day' => substr( str_replace( '-', '/', KERP_Helpers_Date::gregorian_to_jalali( $day ) ), 5 ), 'count' => (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . KERP_Modules_Gold_Store::table( 'sales' ) . ' WHERE paid_at>=%s AND paid_at<%s', $from, $to ) ) ]; } return $out;
    }
    public static function book_options(): array {
        $options = [ '' => 'انتخاب حساب…' ]; foreach ( KERP_Modules_Gold_Business::books() as $book ) { $options[ $book->id ] = $book->label . ' · ' . ( KERP_Modules_Gold_Business::kinds()[ $book->kind ] ?? '' ); } return $options;
    }
    public static function report(): array {
        global $wpdb; $start = KERP_Modules_Gold_Ui::get( 'gold_start', KERP_Helpers_Date::gregorian_to_jalali( wp_date( 'Y-m-d' ) ) ); $end = KERP_Modules_Gold_Ui::get( 'gold_end', $start );
        $dates = []; foreach ( [ $start, $end ] as $raw ) { $raw = str_replace( '/', '-', KERP_Helpers_Format::sanitize_numbers( $raw ) ); if ( preg_match( '/^(1[2345]\d{2})-/', $raw ) ) { $raw = KERP_Helpers_Date::jalali_to_gregorian( $raw ); } $dates[] = $raw; }
        [ $from, $until ] = KERP_Modules_Gold_Business::range( $dates[0], $dates[1] );
        $p = KERP_Modules_Gold_Store::table( 'postings' ); $d = KERP_Modules_Gold_Store::table( 'documents' ); $b = KERP_Modules_Gold_Store::table( 'books' ); $s = KERP_Modules_Gold_Store::table( 'sales' );
        $query = "SELECT b.label,m.asset,SUM(CASE WHEN d.created_at<%s THEN m.delta ELSE 0 END) opening,SUM(CASE WHEN d.created_at>=%s AND m.delta>0 THEN m.delta ELSE 0 END) incoming,SUM(CASE WHEN d.created_at>=%s AND m.delta<0 THEN -m.delta ELSE 0 END) outgoing,SUM(m.delta) closing FROM (SELECT from_book book_id,asset,-amount delta,document_id FROM $p UNION ALL SELECT to_book book_id,asset,amount delta,document_id FROM $p) m JOIN $d d ON d.id=m.document_id JOIN $b b ON b.id=m.book_id WHERE d.created_at<%s GROUP BY b.id,b.label,m.asset ORDER BY b.id,m.asset";
        return [ 'start' => KERP_Helpers_Date::gregorian_to_jalali( $dates[0] ), 'end' => KERP_Helpers_Date::gregorian_to_jalali( $dates[1] ),
            'balances' => $wpdb->get_results( $wpdb->prepare( $query, $from, $from, $from, $until ) ),
            'assets' => $wpdb->get_results( "SELECT m.asset,SUM(m.delta) amount FROM (SELECT from_book book_id,asset,-amount delta FROM $p UNION ALL SELECT to_book book_id,asset,amount delta FROM $p) m JOIN $b b ON b.id=m.book_id WHERE b.kind IN ('bank','gateway','cash','inventory') GROUP BY m.asset" ),
            'sales' => $wpdb->get_results( $wpdb->prepare( "SELECT currency,decimals,source,was_plus,status,COUNT(*) orders,SUM(total) total,SUM(refunded) refunded FROM $s WHERE paid_at>=%s AND paid_at<%s GROUP BY currency,decimals,source,was_plus,status ORDER BY currency,was_plus DESC", $from, $until ) ),
        ];
    }
}
