<?php
defined( 'ABSPATH' ) || exit;

/** Authenticated pull API; no unconfigured vendor endpoint is called. */
final class KERP_Modules_Gold_Packaging {
    public static function register(): void { add_action( 'rest_api_init', [ self::class, 'routes' ] ); }
    public static function allowed(): bool { return ( current_user_can( 'manage_options' ) || current_user_can( 'kerp_gold_packaging' ) ) && KERP_Modules::instance()->is_module_loaded( 'gold' ); }
    public static function routes(): void {
        register_rest_route( 'kerp/v1', '/gold/packaging/orders', [ 'methods' => 'GET', 'callback' => [ self::class, 'listing' ], 'args' => [ 'page' => [ 'type' => 'integer', 'default' => 1, 'minimum' => 1, 'maximum' => 100000 ] ], 'permission_callback' => [ self::class, 'allowed' ] ] );
        register_rest_route( 'kerp/v1', '/gold/packaging/orders/(?P<id>\d+)', [
            [ 'methods' => 'GET', 'callback' => [ self::class, 'get_order' ], 'permission_callback' => [ self::class, 'allowed' ] ],
            [ 'methods' => 'POST', 'callback' => [ self::class, 'set_status' ], 'args' => [ 'status' => [ 'type' => 'string', 'required' => true, 'enum' => [ 'packing', 'packed', 'shipped', 'error' ] ], 'version' => [ 'type' => 'integer', 'required' => true, 'minimum' => 1 ], 'reference' => [ 'type' => 'string', 'required' => true, 'pattern' => '^[A-Za-z0-9:_-]{1,100}$' ], 'note' => [ 'type' => 'string', 'default' => '', 'maxLength' => 1000 ] ], 'permission_callback' => [ self::class, 'allowed' ] ],
        ] );
    }
    public static function enqueue( int $order_id ): void {
        global $wpdb;
        $order = wc_get_order( $order_id ); if ( ! $order || ! $order->is_paid() || $order->get_total_refunded() > 0 ) { return; }
        $has_gold = false;
        foreach ( $order->get_items() as $item ) { if ( (int) $item->get_meta( '_kerp_gold_units' ) > 0 ) { $has_gold = true; break; } }
        if ( ! $has_gold ) { return; }
        $r = $wpdb->query( $wpdb->prepare( 'INSERT IGNORE INTO ' . KERP_Modules_Gold_Store::table( 'packaging' ) . ' (order_id,note,updated_at) VALUES (%d,%s,%s)', $order_id, '', current_time( 'mysql', true ) ) );
        if ( $r === false ) { $order->add_order_note( 'ثبت صف بسته‌بندی ناموفق بود؛ بررسی دوباره سفارش را اجرا کنید.' ); }
        if ( $r === 1 ) { KERP_Modules_Gold_Module::event( 'packaging_pending', (string) $order_id ); }
    }
    public static function review( int $order_id ): void {
        global $wpdb;
        $r = $wpdb->query( $wpdb->prepare( 'UPDATE ' . KERP_Modules_Gold_Store::table( 'packaging' ) . " SET status='review',version=version+1,updated_at=%s WHERE order_id=%d AND status<>'review'", current_time( 'mysql', true ), $order_id ) );
        if ( $r ) { KERP_Modules_Gold_Module::event( 'packaging_review', (string) $order_id ); }
    }
    private static function payload( $row ): ?array {
        $order = wc_get_order( $row->order_id ); if ( ! $order ) { return null; }
        $items = [];
        foreach ( $order->get_items() as $id => $item ) {
            if ( (int) $item->get_meta( '_kerp_gold_units' ) <= 0 ) { continue; }
            $product = $item->get_product();
            $items[] = [ 'line_id' => $id, 'product_id' => $item->get_product_id(), 'name' => $item->get_name(), 'sku' => $product ? $product->get_sku() : '', 'quantity' => $item->get_quantity(), 'physical_grams_750' => $item->get_meta( '_kerp_gold_physical_units' ) !== '' ? KERP_Modules_Gold_Math::grams( (int) $item->get_meta( '_kerp_gold_physical_units' ) ) : null, 'pack' => (string) $item->get_meta( '_kerp_gold_pack' ) ];
        }
        return [ 'order_id' => (int) $row->order_id, 'status' => $row->status, 'version' => (int) $row->version, 'reference' => $row->reference, 'note' => $row->note, 'shipping' => $order->get_address( 'shipping' ), 'items' => $items ];
    }
    public static function listing( WP_REST_Request $request ): WP_REST_Response {
        global $wpdb;
        $page = max( 1, (int) $request->get_param( 'page' ) );
        $rows = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . KERP_Modules_Gold_Store::table( 'packaging' ) . " WHERE status IN ('pending','packing','packed') ORDER BY order_id LIMIT 50 OFFSET %d", ( $page - 1 ) * 50 ) );
        $data = array_values( array_filter( array_map( [ self::class, 'payload' ], $rows ) ) );
        $response = new WP_REST_Response( [ 'page' => $page, 'orders' => $data ] ); $response->header( 'Cache-Control', 'no-store, private' ); return $response;
    }
    public static function get_order( WP_REST_Request $request ) {
        global $wpdb;
        $row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . KERP_Modules_Gold_Store::table( 'packaging' ) . ' WHERE order_id=%d', (int) $request['id'] ) );
        $data = $row ? self::payload( $row ) : null;
        if ( ! $data ) { return new WP_Error( 'kerp_gold_not_found', 'سفارش بسته‌بندی پیدا نشد.', [ 'status' => 404 ] ); }
        $response = new WP_REST_Response( $data ); $response->header( 'Cache-Control', 'no-store, private' ); return $response;
    }
    public static function update( int $order_id, string $status, int $version, string $reference, string $note ): int {
        global $wpdb;
        $transitions = [ 'pending' => [ 'packing', 'error' ], 'packing' => [ 'packed', 'error' ], 'packed' => [ 'shipped', 'error' ], 'error' => [ 'packing' ] ];
        if ( ! in_array( $status, [ 'packing', 'packed', 'shipped', 'error' ], true ) || ! preg_match( '/^[A-Za-z0-9:_-]{1,100}$/D', $reference ) || $version < 1 ) { throw new InvalidArgumentException( 'وضعیت، نسخه یا شناسه پیگیری نامعتبر است.' ); }
        $table = KERP_Modules_Gold_Store::table( 'packaging' ); $events = KERP_Modules_Gold_Store::table( 'packevents' );
        if ( $wpdb->query( 'START TRANSACTION' ) === false ) { throw new RuntimeException( 'شروع تراکنش ناموفق بود.' ); }
        try {
            $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE order_id=%d FOR UPDATE", $order_id ) );
            if ( ! $row ) { throw new RuntimeException( 'سفارش در صف بسته‌بندی نیست.' ); }
            $seen = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $events WHERE reference=%s", $reference ) );
            if ( $seen ) {
                if ( (int) $seen->order_id !== $order_id || $seen->status !== $status || $seen->note !== $note ) { throw new RuntimeException( 'شناسه پیگیری قبلاً برای عملیات دیگری استفاده شده است.' ); }
                $wpdb->query( 'ROLLBACK' ); return (int) $row->version;
            }
            $order = wc_get_order( $order_id );
            if ( ! $order || ! $order->is_paid() || $order->get_total_refunded() > 0 || ! in_array( $status, $transitions[ $row->status ] ?? [], true ) || (int) $row->version !== $version ) { throw new RuntimeException( 'سفارش قابل پردازش نیست، ترتیب وضعیت نامعتبر است یا نسخه تغییر کرده است.' ); }
            if ( ! $wpdb->insert( $events, [ 'order_id' => $order_id, 'status' => $status, 'reference' => $reference, 'note' => $note, 'actor_id' => get_current_user_id(), 'created_at' => current_time( 'mysql', true ) ] ) ) { throw new RuntimeException( 'ثبت رویداد بسته‌بندی ناموفق بود.' ); }
            if ( $wpdb->update( $table, [ 'status' => $status, 'version' => $version + 1, 'reference' => $reference, 'note' => $note, 'updated_at' => current_time( 'mysql', true ) ], [ 'order_id' => $order_id ] ) !== 1 ) { throw new RuntimeException( 'ثبت وضعیت ناموفق بود.' ); }
            if ( $wpdb->query( 'COMMIT' ) === false ) { throw new RuntimeException( 'ثبت نهایی ناموفق بود.' ); }
        } catch ( Throwable $e ) { $wpdb->query( 'ROLLBACK' ); throw $e; }
        KERP_Modules_Gold_Module::event( 'packaging_' . $status, (string) $order_id ); return $version + 1;
    }
    public static function set_status( WP_REST_Request $request ) {
        try {
            $version = self::update( (int) $request['id'], sanitize_key( (string) $request->get_param( 'status' ) ), (int) $request->get_param( 'version' ), sanitize_text_field( (string) $request->get_param( 'reference' ) ), sanitize_text_field( (string) $request->get_param( 'note' ) ) );
            return new WP_REST_Response( [ 'order_id' => (int) $request['id'], 'version' => $version ] );
        } catch ( Throwable $e ) { return new WP_Error( 'kerp_gold_packaging_conflict', $e->getMessage(), [ 'status' => 409 ] ); }
    }
}
