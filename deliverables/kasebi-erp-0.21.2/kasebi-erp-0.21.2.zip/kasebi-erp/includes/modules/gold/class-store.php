<?php
defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Gold_Store {
    public static function table( string $name ): string {
        global $wpdb;
        if ( ! in_array( $name, [ 'accounts', 'ledger', 'requests', 'replacement', 'memberships', 'events', 'books', 'documents', 'postings', 'sales', 'packaging', 'packevents', 'statushistory' ], true ) ) { throw new InvalidArgumentException( 'table' ); }
        return $wpdb->prefix . 'kerp_gold_' . $name;
    }

    public static function install(): void {
        if ( get_option( 'kerp_gold_db_version' ) === '3' ) { return; }
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $collate = $wpdb->get_charset_collate();
        $queries = [
            'books' => "id bigint unsigned NOT NULL AUTO_INCREMENT, code varchar(100) NOT NULL, label varchar(200) NOT NULL, kind varchar(30) NOT NULL, party_type varchar(30) NOT NULL DEFAULT '', user_id bigint unsigned NOT NULL DEFAULT 0, details text NOT NULL, allow_negative tinyint NOT NULL DEFAULT 0, PRIMARY KEY  (id), UNIQUE KEY code (code)",
            'documents' => "id bigint unsigned NOT NULL AUTO_INCREMENT, reference varchar(100) NOT NULL, note text NOT NULL, actor_id bigint unsigned NOT NULL, reverses_id bigint unsigned DEFAULT NULL, created_at datetime NOT NULL, PRIMARY KEY  (id), UNIQUE KEY reference (reference), UNIQUE KEY reverses_id (reverses_id)",
            'postings' => "id bigint unsigned NOT NULL AUTO_INCREMENT, document_id bigint unsigned NOT NULL, from_book bigint unsigned NOT NULL, to_book bigint unsigned NOT NULL, asset varchar(12) NOT NULL, amount bigint NOT NULL, PRIMARY KEY  (id), KEY from_asset (from_book,asset), KEY to_asset (to_book,asset), KEY document_id (document_id)",
            'sales' => "order_id bigint unsigned NOT NULL, user_id bigint unsigned NOT NULL DEFAULT 0, was_plus tinyint NOT NULL DEFAULT 0, source varchar(20) NOT NULL, currency varchar(12) NOT NULL, decimals tinyint NOT NULL DEFAULT 0, total bigint NOT NULL, refunded bigint NOT NULL DEFAULT 0, paid_at datetime DEFAULT NULL, status varchar(30) NOT NULL, PRIMARY KEY  (order_id), KEY paid_at (paid_at), KEY plus_paid (was_plus,paid_at)",
            'packaging' => "order_id bigint unsigned NOT NULL, status varchar(30) NOT NULL DEFAULT 'pending', version bigint unsigned NOT NULL DEFAULT 1, reference varchar(100) NOT NULL DEFAULT '', note text NOT NULL, updated_at datetime NOT NULL, PRIMARY KEY  (order_id), KEY status (status)",
            'packevents' => "id bigint unsigned NOT NULL AUTO_INCREMENT, order_id bigint unsigned NOT NULL, status varchar(30) NOT NULL, reference varchar(100) NOT NULL, note text NOT NULL, actor_id bigint unsigned NOT NULL, created_at datetime NOT NULL, PRIMARY KEY  (id), UNIQUE KEY reference (reference), KEY order_id (order_id)",
            'statushistory' => "id bigint unsigned NOT NULL AUTO_INCREMENT, object_id bigint unsigned NOT NULL, object_type varchar(20) NOT NULL, old_state varchar(30) NOT NULL, new_state varchar(30) NOT NULL, actor_id bigint unsigned NOT NULL, created_at datetime NOT NULL, PRIMARY KEY  (id), KEY object_id (object_id)" ,
            'events' => "id bigint unsigned NOT NULL AUTO_INCREMENT, event varchar(80) NOT NULL, reference varchar(100) NOT NULL, hashtag varchar(100) NOT NULL, delivery varchar(20) NOT NULL DEFAULT 'local', attempts int unsigned NOT NULL DEFAULT 0, last_attempt bigint unsigned NOT NULL DEFAULT 0, created_at datetime NOT NULL, PRIMARY KEY  (id)",
            'memberships' => "order_id bigint unsigned NOT NULL, user_id bigint unsigned NOT NULL, expires_at bigint unsigned NOT NULL, PRIMARY KEY  (order_id), KEY user_expiry (user_id,expires_at)",
            'accounts' => "user_id bigint unsigned NOT NULL, balance bigint NOT NULL DEFAULT 0, PRIMARY KEY  (user_id)",
            'ledger' => "id bigint unsigned NOT NULL AUTO_INCREMENT, user_id bigint unsigned NOT NULL, delta bigint NOT NULL, balance bigint NOT NULL, reference varchar(100) NOT NULL, note text NOT NULL, actor_id bigint unsigned NOT NULL, created_at datetime NOT NULL, PRIMARY KEY  (id), UNIQUE KEY reference (reference), KEY user_id (user_id)",
            'requests' => "id bigint unsigned NOT NULL AUTO_INCREMENT, user_id bigint unsigned NOT NULL, kind varchar(20) NOT NULL, units bigint NOT NULL, status varchar(20) NOT NULL DEFAULT 'pending', reference varchar(100) NOT NULL, note text NOT NULL, resolution text NOT NULL, created_at datetime NOT NULL, PRIMARY KEY  (id), UNIQUE KEY reference (reference), KEY user_status (user_id,status)",
            'replacement' => "id bigint unsigned NOT NULL AUTO_INCREMENT, order_id bigint unsigned NOT NULL, units bigint NOT NULL, status varchar(20) NOT NULL DEFAULT 'pending', reference varchar(100) NOT NULL DEFAULT '', note text NOT NULL, created_at datetime NOT NULL, PRIMARY KEY  (id), UNIQUE KEY order_id (order_id), KEY status (status)"
        ];
        foreach ( $queries as $name => $columns ) {
            $table = self::table( $name );
            $columns = str_replace( ", ", ",\n", $columns );
            dbDelta( "CREATE TABLE $table (\n$columns\n) ENGINE=InnoDB $collate;" );
            preg_match_all( '/^([a-z_]+)\s+[a-z]+/m', $columns, $expected );
            $actual = $wpdb->get_col( "SHOW COLUMNS FROM $table" );
            if ( array_diff( $expected[1], $actual ) ) { throw new RuntimeException( 'ساختار جدول‌های طلا کامل ایجاد نشد.' ); }
            $engine = $wpdb->get_row( $wpdb->prepare( 'SHOW TABLE STATUS WHERE Name = %s', $table ) );
            if ( ! $engine || strcasecmp( $engine->Engine, 'InnoDB' ) !== 0 ) {
                throw new RuntimeException( 'جدول‌های طلا به InnoDB نیاز دارند.' );
            }
        }
        update_option( 'kerp_gold_db_version', '3', false );
    }

    private static function check( $result ): void {
        if ( $result === false ) { throw new RuntimeException( 'ثبت اطلاعات انجام نشد؛ دوباره بررسی کنید.' ); }
    }

    public static function balance( int $user_id ): int {
        global $wpdb;
        return (int) $wpdb->get_var( $wpdb->prepare( 'SELECT balance FROM ' . self::table( 'accounts' ) . ' WHERE user_id=%d', $user_id ) );
    }

    /** Must be called inside a transaction. Row lock serializes all wallet writes. */
    private static function move( int $user_id, int $delta, string $reference, string $note ): void {
        global $wpdb;
        if ( ! get_userdata( $user_id ) || ! $delta || strlen( $reference ) > 100 || $reference === '' || $note === '' ) {
            throw new InvalidArgumentException( 'کاربر، وزن، شناسه پیگیری و توضیح الزامی است.' );
        }
        $accounts = self::table( 'accounts' );
        self::check( $wpdb->query( $wpdb->prepare( "INSERT IGNORE INTO $accounts (user_id,balance) VALUES (%d,0)", $user_id ) ) );
        $balance = $wpdb->get_var( $wpdb->prepare( "SELECT balance FROM $accounts WHERE user_id=%d FOR UPDATE", $user_id ) );
        if ( $balance === null ) { throw new RuntimeException( 'قفل موجودی ناموفق بود.' ); }
        $balance = (int) $balance + $delta;
        if ( $balance < 0 ) { throw new RuntimeException( 'موجودی آزاد کافی نیست.' ); }
        self::check( $wpdb->insert( self::table( 'ledger' ), [ 'user_id' => $user_id, 'delta' => $delta, 'balance' => $balance, 'reference' => $reference, 'note' => $note, 'actor_id' => get_current_user_id(), 'created_at' => current_time( 'mysql', true ) ] ) );
        self::check( $wpdb->update( $accounts, [ 'balance' => $balance ], [ 'user_id' => $user_id ] ) );
    }

    public static function adjust( int $user_id, int $delta, string $reference, string $note ): void {
        global $wpdb;
        self::check( $wpdb->query( 'START TRANSACTION' ) );
        try {
            self::move( $user_id, $delta, 'manual:' . $reference, $note );
            self::check( $wpdb->query( 'COMMIT' ) );
        } catch ( Throwable $e ) { $wpdb->query( 'ROLLBACK' ); throw $e; }
        KERP_Modules_Gold_Module::event( 'wallet_adjusted', $reference );
    }

    public static function request( int $user_id, string $kind, int $units, string $reference, string $note ): void {
        global $wpdb;
        if ( $units <= 0 || ! in_array( $kind, [ 'buy', 'cash', 'physical', 'jewelry' ], true ) || ! preg_match( '/^[a-f0-9-]{36}$/D', $reference ) ) {
            throw new InvalidArgumentException( 'درخواست نامعتبر است.' );
        }
        $settings = KERP_Modules_Gold_Module::settings();
        if ( ! KERP_Modules_Gold_Module::is_plus( $user_id ) ) { throw new RuntimeException( 'اشتراک پلاس فعال لازم است.' ); }
        if ( $kind !== 'buy' && empty( $settings[ 'allow_' . $kind ] ) ) { throw new RuntimeException( 'این روش برداشت فعال نیست.' ); }
        if ( $kind === 'physical' && $units < KERP_Modules_Gold_Math::units( $settings['physical_min'] ) ) {
            throw new RuntimeException( 'وزن کمتر از حداقل تحویل فیزیکی است.' );
        }
        self::check( $wpdb->query( 'START TRANSACTION' ) );
        try {
            self::check( $wpdb->insert( self::table( 'requests' ), [ 'user_id' => $user_id, 'kind' => $kind, 'units' => $units, 'reference' => $reference, 'note' => $note, 'resolution' => '', 'created_at' => current_time( 'mysql', true ) ] ) );
            $id = (int) $wpdb->insert_id;
            if ( $kind !== 'buy' ) { self::move( $user_id, -$units, 'reserve:' . $id, 'رزرو درخواست #' . $id ); }
            self::check( $wpdb->query( 'COMMIT' ) );
        } catch ( Throwable $e ) { $wpdb->query( 'ROLLBACK' ); throw $e; }
        KERP_Modules_Gold_Module::event( 'request_pending', (string) $id );
    }

    public static function resolve( int $id, string $status, string $reference ): void {
        global $wpdb;
        if ( ! in_array( $status, [ 'completed', 'rejected' ], true ) || $reference === '' ) { throw new InvalidArgumentException( 'نتیجه و شناسه پیگیری لازم است.' ); }
        self::check( $wpdb->query( 'START TRANSACTION' ) );
        try {
            $row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table( 'requests' ) . ' WHERE id=%d FOR UPDATE', $id ) );
            if ( ! $row || $row->status !== 'pending' ) { throw new RuntimeException( 'درخواست قبلاً بررسی شده یا موجود نیست.' ); }
            if ( $row->kind === 'buy' && $status === 'completed' ) {
                self::move( (int) $row->user_id, (int) $row->units, 'buy:' . $id, 'تأیید دریافت وجه خرید: ' . $reference );
            } elseif ( $row->kind !== 'buy' && $status === 'rejected' ) {
                self::move( (int) $row->user_id, (int) $row->units, 'release:' . $id, 'آزادسازی رزرو: ' . $reference );
            }
            self::check( $wpdb->update( self::table( 'requests' ), [ 'status' => $status, 'resolution' => $reference ], [ 'id' => $id ] ) );
            self::check( $wpdb->query( 'COMMIT' ) );
        } catch ( Throwable $e ) { $wpdb->query( 'ROLLBACK' ); throw $e; }
        KERP_Modules_Gold_Module::event( 'request_' . $status, (string) $id );
    }

    public static function rows( string $name, int $user_id = 0, int $page = 1 ): array {
        global $wpdb;
        $table = self::table( $name );
        $where = $user_id ? $wpdb->prepare( ' WHERE user_id=%d', $user_id ) : '';
        return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $table$where ORDER BY id DESC LIMIT 25 OFFSET %d", max( 0, $page - 1 ) * 25 ) );
    }

    public static function replacement( int $order_id, int $units ): void {
        global $wpdb;
        if ( $units <= 0 ) { return; }
        $result = $wpdb->query( $wpdb->prepare( 'INSERT IGNORE INTO ' . self::table( 'replacement' ) . ' (order_id,units,note,created_at) VALUES (%d,%d,%s,%s)', $order_id, $units, 'خرید جایگزین دستی؛ مبلغ و وزن را پیش از تأیید بررسی کنید.', current_time( 'mysql', true ) ) );
        self::check( $result );
        if ( $result === 1 ) { KERP_Modules_Gold_Module::event( 'replacement_pending', (string) $order_id ); }
    }

    public static function complete_replacement( int $id, string $reference ): void {
        global $wpdb;
        if ( $reference === '' ) { throw new InvalidArgumentException( 'شناسه معامله فروشنده لازم است.' ); }
        $changed = $wpdb->query( $wpdb->prepare( 'UPDATE ' . self::table( 'replacement' ) . " SET status='completed',reference=%s WHERE id=%d AND status='pending'", $reference, $id ) );
        if ( $changed !== 1 ) { throw new RuntimeException( 'رکورد در انتظار خرید نیست.' ); }
        KERP_Modules_Gold_Module::event( 'replacement_completed', (string) $id );
    }
}
