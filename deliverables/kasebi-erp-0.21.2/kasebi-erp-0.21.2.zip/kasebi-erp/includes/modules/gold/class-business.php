<?php
defined( 'ABSPATH' ) || exit;

/** Separate business journal. Customer gram-wallet balances are never changed by these postings. */
final class KERP_Modules_Gold_Business {
    public static function kinds(): array { return [ 'party' => 'طرف حساب', 'bank' => 'بانک', 'gateway' => 'درگاه', 'cash' => 'صندوق نقدی', 'inventory' => 'دارایی طلایی', 'opening' => 'افتتاحیه و اصلاح', 'income' => 'فروش و درآمد' ]; }
    public static function parties(): array { return [ 'student' => 'هنرجو', 'customer' => 'مشتری عادی', 'supplier' => 'تأمین‌کننده', 'workshop' => 'کارگاه', 'wholesaler' => 'بنکدار', 'other' => 'سایر' ]; }
    public static function books(): array { global $wpdb; return $wpdb->get_results( 'SELECT * FROM ' . KERP_Modules_Gold_Store::table( 'books' ) . ' ORDER BY id DESC' ); }

    public static function create_book( array $data ): int {
        global $wpdb;
        $kind = $data['kind'] ?? '';
        $party = $kind === 'party' ? ( $data['party_type'] ?? '' ) : '';
        if ( ! isset( self::kinds()[ $kind ] ) || ( $kind === 'party' && ! isset( self::parties()[ $party ] ) ) || empty( $data['label'] ) || ! preg_match( '/^[a-zA-Z0-9:_-]{1,100}$/D', $data['code'] ?? '' ) ) { throw new InvalidArgumentException( 'نوع حساب، نام یا کد یکتا نامعتبر است.' ); }
        $user_id = (int) ( $data['user_id'] ?? 0 );
        if ( $user_id && ! get_userdata( $user_id ) ) { throw new InvalidArgumentException( 'کاربر مرتبط پیدا نشد.' ); }
        $r = $wpdb->insert( KERP_Modules_Gold_Store::table( 'books' ), [ 'code' => $data['code'], 'label' => $data['label'], 'kind' => $kind, 'party_type' => $party, 'user_id' => $user_id, 'details' => $data['details'] ?? '', 'allow_negative' => in_array( $kind, [ 'party', 'opening', 'income' ], true ) ? 1 : 0 ] );
        if ( ! $r ) { throw new RuntimeException( 'حساب ثبت نشد؛ کد یکتا نباید تکراری باشد.' ); }
        return (int) $wpdb->insert_id;
    }

    private static function valid_asset( string $asset ): bool {
        if ( $asset === 'gold' ) { return true; }
        return $asset === self::money_asset();
    }

    public static function money_asset(): string { return get_woocommerce_currency() . ':' . wc_get_price_decimals(); }
    public static function amount_label( string $asset, int $amount ): string {
        if ( $asset === 'gold' ) { return KERP_Modules_Gold_Math::grams( $amount ) . ' گرم ۷۵۰'; }
        [ $currency, $decimals ] = array_pad( explode( ':', $asset ), 2, '0' );
        return KERP_Modules_Gold_Math::format_money( $amount, (int) $decimals ) . ' ' . $currency;
    }

    public static function balance( int $book, string $asset, ?string $before = null ): int {
        global $wpdb;
        $p = KERP_Modules_Gold_Store::table( 'postings' ); $d = KERP_Modules_Gold_Store::table( 'documents' );
        $where = $before ? $wpdb->prepare( ' AND d.created_at<%s', $before ) : '';
        return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(SUM(CASE WHEN p.to_book=%d THEN p.amount ELSE -p.amount END),0) FROM $p p JOIN $d d ON d.id=p.document_id WHERE (p.from_book=%d OR p.to_book=%d) AND p.asset=%s$where", $book, $book, $book, $asset ) );
    }

    /** Post up to 20 balanced transfers as one immutable document. Locks every involved book in ID order. */
    public static function post( string $reference, string $note, array $legs, ?int $reverses = null ): int {
        global $wpdb;
        if ( ! preg_match( '/^[A-Za-z0-9:_-]{1,100}$/D', $reference ) || $note === '' || ! $legs || count( $legs ) > 20 ) { throw new InvalidArgumentException( 'سند، شرح یا ردیف‌های سند نامعتبر است.' ); }
        $ids = []; $deltas = [];
        foreach ( $legs as $leg ) {
            $from = (int) ( $leg['from'] ?? 0 ); $to = (int) ( $leg['to'] ?? 0 ); $amount = $leg['amount'] ?? 0; $asset = $leg['asset'] ?? '';
            if ( $from <= 0 || $to <= 0 || $from === $to || ! is_int( $amount ) || $amount <= 0 || $amount > 999999999999999 || ! self::valid_asset( $asset ) ) { throw new InvalidArgumentException( 'مبدأ، مقصد، مقدار یا نوع دارایی نامعتبر است.' ); }
            $ids[] = $from; $ids[] = $to;
            $deltas[ $from ][ $asset ] = ( $deltas[ $from ][ $asset ] ?? 0 ) - $amount;
            $deltas[ $to ][ $asset ] = ( $deltas[ $to ][ $asset ] ?? 0 ) + $amount;
        }
        $ids = array_values( array_unique( $ids ) ); sort( $ids, SORT_NUMERIC );
        $books = KERP_Modules_Gold_Store::table( 'books' ); $docs = KERP_Modules_Gold_Store::table( 'documents' );
        if ( $wpdb->query( 'START TRANSACTION' ) === false ) { throw new RuntimeException( 'تراکنش شروع نشد.' ); }
        try {
            $locked = $wpdb->get_results( "SELECT * FROM $books WHERE id IN (" . implode( ',', $ids ) . ') ORDER BY id FOR UPDATE' );
            if ( count( $locked ) !== count( $ids ) ) { throw new RuntimeException( 'یکی از حساب‌ها پیدا نشد.' ); }
            foreach ( $locked as $book ) {
                if ( ! $book->allow_negative ) {
                    foreach ( $deltas[ $book->id ] as $asset => $delta ) { if ( self::balance( (int) $book->id, $asset ) + $delta < 0 ) { throw new RuntimeException( 'موجودی حساب «' . $book->label . '» کافی نیست.' ); } }
                }
            }
            if ( $reverses ) {
                $original = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $docs WHERE id=%d FOR UPDATE", $reverses ) );
                if ( ! $original ) { throw new RuntimeException( 'سند اصلی پیدا نشد.' ); }
            }
            $r = $wpdb->insert( $docs, [ 'reference' => $reference, 'note' => $note, 'actor_id' => get_current_user_id(), 'reverses_id' => $reverses, 'created_at' => current_time( 'mysql', true ) ] );
            if ( ! $r ) { throw new RuntimeException( 'سند تکراری است یا ثبت آن انجام نشد.' ); }
            $id = (int) $wpdb->insert_id;
            foreach ( $legs as $leg ) {
                if ( ! $wpdb->insert( KERP_Modules_Gold_Store::table( 'postings' ), [ 'document_id' => $id, 'from_book' => $leg['from'], 'to_book' => $leg['to'], 'asset' => $leg['asset'], 'amount' => $leg['amount'] ] ) ) { throw new RuntimeException( 'ثبت ردیف سند ناموفق بود.' ); }
            }
            if ( $wpdb->query( 'COMMIT' ) === false ) { throw new RuntimeException( 'ثبت نهایی سند ناموفق بود.' ); }
        } catch ( Throwable $e ) { $wpdb->query( 'ROLLBACK' ); throw $e; }
        KERP_Modules_Gold_Module::event( 'business_posted', (string) $id );
        return $id;
    }

    public static function reverse( int $id, string $reference, string $note ): int {
        global $wpdb;
        $doc = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . KERP_Modules_Gold_Store::table( 'documents' ) . ' WHERE id=%d', $id ) );
        if ( ! $doc || $doc->reverses_id ) { throw new RuntimeException( 'سند اصلی معتبر نیست؛ سند اصلاحی دوباره معکوس نمی‌شود.' ); }
        $rows = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . KERP_Modules_Gold_Store::table( 'postings' ) . ' WHERE document_id=%d', $id ) );
        $legs = [];
        foreach ( $rows as $row ) {
            // Historical money precision/currency is preserved; do not reinterpret after a currency change.
            if ( ! self::valid_asset( $row->asset ) ) { throw new RuntimeException( 'برای اصلاح این سند، واحد پول و دقت فروشگاه باید با سند اصلی یکسان باشد.' ); }
            $legs[] = [ 'from' => (int) $row->to_book, 'to' => (int) $row->from_book, 'asset' => $row->asset, 'amount' => (int) $row->amount ];
        }
        return self::post( $reference, $note, $legs, $id );
    }

    public static function source_labels(): array { return [ 'site' => 'سایت', 'physical' => 'حضوری', 'social' => 'شبکه‌های اجتماعی' ]; }

    public static function offline_sale( array $data, array $items ): int {
        $source = $data['source'] ?? '';
        $customer = (int) ( $data['user_id'] ?? 0 );
        if ( ! in_array( $source, [ 'physical', 'social' ], true ) || ! get_userdata( $customer ) || ! preg_match( '/^[a-f0-9-]{36}$/D', $data['reference'] ?? '' ) || ! $items || count( $items ) > 30 ) { throw new InvalidArgumentException( 'کاربر، منبع فروش یا محصولات نامعتبرند.' ); }
        if ( ! in_array( $data['method'] ?? '', [ 'cash', 'bank', 'gateway', 'unpaid' ], true ) ) { throw new InvalidArgumentException( 'روش پرداخت نامعتبر است.' ); }
        if ( $data['method'] !== 'unpaid' && empty( $data['receipt'] ) ) { throw new InvalidArgumentException( 'برای ثبت فروش پرداخت‌شده، شماره رسید لازم است.' ); }
        $products = []; $combined = [];
        foreach ( $items as $line ) { $pid = (int) ( $line['product_id'] ?? 0 ); $qty = $line['quantity'] ?? ''; if ( ! preg_match( '/^[1-9]\d{0,4}$/D', (string) $qty ) ) { throw new InvalidArgumentException( 'تعداد باید عدد صحیح مثبت باشد.' ); } $combined[ $pid ] = ( $combined[ $pid ] ?? 0 ) + (int) $qty; }
        foreach ( $combined as $pid => $qty ) { $products[] = [ 'product_id' => $pid, 'quantity' => $qty ]; }
        $items = $products; $products = [];
        ksort( $combined, SORT_NUMERIC );
        $fingerprint = hash( 'sha256', serialize( [ $source, $customer, $data['method'], $data['receipt'] ?? '', $combined ] ) );
        $key = 'kerp_gold_sale_' . hash( 'sha256', $data['reference'] );
        $job = get_option( $key );
        if ( is_array( $job ) ) { return self::existing_sale( $job, $fingerprint ); }
        foreach ( $items as $line ) {
            $product = wc_get_product( (int) $line['product_id'] );
            $quantity = (int) $line['quantity'];
            if ( ! $product || ! $product->is_type( 'simple' ) || $quantity < 1 || $quantity > 10000 || ! $product->is_purchasable() || ! $product->is_in_stock() || ! $product->has_enough_stock( $quantity ) ) { throw new InvalidArgumentException( 'محصول قابل فروش نیست یا تعداد از موجودی بیشتر است.' ); }
            $products[] = [ $product, $quantity ];
        }
        if ( ! add_option( $key, [ 'status' => 'creating', 'order_id' => 0, 'fingerprint' => $fingerprint ], '', false ) ) {
            return self::existing_sale( (array) get_option( $key ), $fingerprint );
        }
        $order = null;
        try {
            $order = wc_create_order( [ 'customer_id' => $customer, 'created_via' => 'kerp_gold_offline' ] );
            if ( is_wp_error( $order ) ) { throw new RuntimeException( 'ایجاد سفارش انجام نشد.' ); }
            update_option( $key, [ 'status' => 'creating', 'order_id' => $order->get_id(), 'fingerprint' => $fingerprint ], false );
            $order->update_meta_data( '_kerp_gold_source', $source );
            $order->update_meta_data( '_kerp_gold_plus_at_sale', KERP_Modules_Gold_Module::is_plus( $customer ) ? 'yes' : 'no' );
            $order->update_meta_data( '_kerp_gold_receipt', $data['receipt'] ?? '' );
            foreach ( $products as [ $product, $quantity ] ) {
                $calc = KERP_Modules_Gold_Pricing::calculate( $product, $customer );
                $args = [];
                if ( $calc ) { $subtotal = wc_get_price_excluding_tax( $product, [ 'qty' => $quantity, 'price' => $calc['price'] ] ); $args = [ 'subtotal' => $subtotal, 'total' => $subtotal ]; }
                $item_id = $order->add_product( $product, $quantity, $args );
                $item = $order->get_item( $item_id );
                KERP_Modules_Gold_Commerce::snapshot( $item, '', [ 'data' => $product ], $order );
                $item->save();
            }
            $order->set_payment_method( 'kerp_gold_' . $data['method'] );
            $order->set_payment_method_title( [ 'cash' => 'نقد؛ ثبت دستی', 'bank' => 'بانک؛ ثبت دستی', 'gateway' => 'درگاه؛ ثبت دستی رسید', 'unpaid' => 'در انتظار دریافت وجه' ][ $data['method'] ] );
            $order->calculate_totals(); $order->save();
            if ( function_exists( 'wc_reserve_stock_for_order' ) ) { wc_reserve_stock_for_order( $order ); }
            if ( $data['method'] !== 'unpaid' ) { $order->payment_complete( $data['receipt'] ); }
            self::index_sale( $order->get_id() );
            update_option( $key, [ 'status' => 'done', 'order_id' => $order->get_id(), 'fingerprint' => $fingerprint ], false );
            KERP_Modules_Gold_Module::event( 'offline_sale', (string) $order->get_id() );
            return $order->get_id();
        } catch ( Throwable $e ) {
            $id = $order instanceof WC_Order ? $order->get_id() : 0;
            update_option( $key, [ 'status' => 'error', 'order_id' => $id, 'fingerprint' => $fingerprint ], false );
            throw new RuntimeException( 'ثبت فروش کامل نشد. سفارش ' . $id . ' را پیش از تلاش مجدد بررسی کنید. ' . $e->getMessage() );
        }
    }

    private static function existing_sale( array $job, string $fingerprint ): int {
        if ( ( $job['fingerprint'] ?? '' ) !== $fingerprint ) { throw new RuntimeException( 'شناسه ثبت فروش برای اطلاعات متفاوت دوباره استفاده شده است.' ); }
        if ( ( $job['status'] ?? '' ) === 'done' ) { return (int) $job['order_id']; }
        throw new RuntimeException( 'این درخواست قبلاً شروع شده است؛ سفارش شماره ' . (int) ( $job['order_id'] ?? 0 ) . ' را بررسی کنید.' );
    }

    public static function index_sale( $order_id ): void {
        global $wpdb;
        $order = wc_get_order( $order_id ); if ( ! $order ) { return; }
        $managed = false;
        foreach ( $order->get_items() as $item ) { if ( $item->get_meta( '_kerp_gold_units' ) || $item->get_meta( '_kerp_plus_days' ) ) { $managed = true; break; } }
        if ( ! $managed && ! $order->get_meta( '_kerp_gold_source' ) ) { return; }
        $decimals = $order->get_meta( '_kerp_gold_money_decimals' );
        if ( $decimals === '' ) { $decimals = wc_get_price_decimals(); $order->update_meta_data( '_kerp_gold_money_decimals', $decimals ); $order->save_meta_data(); }
        $plus = $order->get_meta( '_kerp_gold_plus_at_sale' ) === 'yes';
        $date = $order->get_date_paid();
        $data = [ 'order_id' => $order->get_id(), 'user_id' => $order->get_customer_id(), 'was_plus' => $plus ? 1 : 0, 'source' => $order->get_meta( '_kerp_gold_source' ) ?: 'site', 'currency' => $order->get_currency(), 'decimals' => (int) $decimals, 'total' => (int) round( (float) $order->get_total() * ( 10 ** (int) $decimals ) ), 'refunded' => (int) round( (float) $order->get_total_refunded() * ( 10 ** (int) $decimals ) ), 'paid_at' => $date ? gmdate( 'Y-m-d H:i:s', $date->getTimestamp() ) : null, 'status' => $order->get_status() ];
        $r = $wpdb->replace( KERP_Modules_Gold_Store::table( 'sales' ), $data );
        if ( $r === false ) { $order->add_order_note( 'ثبت گزارش فروش بنکداری ناموفق بود؛ از ابزار بررسی دوباره سفارش استفاده کنید.' ); }
    }

    public static function range( string $start, string $end ): array {
        $zone = wp_timezone();
        $from = DateTimeImmutable::createFromFormat( '!Y-m-d', $start, $zone ); $to = DateTimeImmutable::createFromFormat( '!Y-m-d', $end, $zone );
        if ( ! $from || ! $to || $from->format( 'Y-m-d' ) !== $start || $to->format( 'Y-m-d' ) !== $end || $to < $from || $from->diff( $to )->days > 366 ) { throw new InvalidArgumentException( 'بازه باید معتبر و حداکثر ۳۶۶ روز باشد.' ); }
        return [ $from->setTimezone( new DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' ), $to->modify( '+1 day' )->setTimezone( new DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' ) ];
    }

    public static function status_history( int $id, string $type, string $old, string $new ): void {
        global $wpdb;
        if ( $old === $new ) { return; }
        $wpdb->insert( KERP_Modules_Gold_Store::table( 'statushistory' ), [ 'object_id' => $id, 'object_type' => $type, 'old_state' => $old, 'new_state' => $new, 'actor_id' => get_current_user_id(), 'created_at' => current_time( 'mysql', true ) ] );
        KERP_Modules_Gold_Module::event( 'inventory_status', $type . ':' . $id . ':' . $new );
    }
}
