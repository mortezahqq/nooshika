<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Hr_Reports_Module {
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {
		KERP_Modules_Hr_Reports_Installer::instance()->maybe_install();
		$this->load_services();
		$this->register_hooks();
	}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public static function table(): string {
		global $wpdb;
		
		return $wpdb->prefix . 'kasebi_erp_hr_reports';
	}
	
	public static function install(): void {
		KERP_Modules_Hr_Reports_Installer::instance()->install();
	}
	
	public function register_pages( array $pages ): array {
		$employees_group = [
			'key'   => 'employees',
			'title' => __( 'منابع انسانی', 'kasebi-erp' ),
			'icon'  => 'uik-r fa-id-badge',
			'order' => 30,
		];
		$settings_group  = [
			'key'        => 'settings',
			'title'      => __( 'تنظیمات', 'kasebi-erp' ),
			'icon'       => 'kik fa-settings-02',
			'order'      => 100,
			'sep_before' => TRUE,
		];
		
		$pages['hr-reports'] = [
			'title'      => __( 'گزارشات سازمانی', 'kasebi-erp' ),
			'route'      => 'hr-reports',
			'type'       => 'page',
			'template'   => 'modules/hr-reports/pages/reports.php',
			'permission' => 'hr_reports.view',
			'navigation' => [
				'group' => apply_filters(
					'kerp_hr_reports_employees_navigation_group',
					$employees_group
				),
				'icon'  => 'uik-r fa-document-signed',
				'order' => 20,
			],
		];
		
		$pages['hr-reports-settings'] = [
			'title'      => __( 'انواع گزارشات سازمانی', 'kasebi-erp' ),
			'route'      => 'settings/hr-reports',
			'type'       => 'settings',
			'template'   => 'modules/hr-reports/settings/types.php',
			'permission' => 'hr_reports.manage_settings',
			'navigation' => [
				'group' => apply_filters(
					'kerp_hr_reports_settings_navigation_group',
					$settings_group
				),
				'icon'  => 'uik-r fa-document-signed',
				'order' => 75,
			],
		];
		
		return $pages;
	}
	
	public function register_employee_tab(
		array $tabs,
		int $employee_id,
		WP_User $employee
	): array {
		if ( ! KERP_Modules_Hr_Reports_Query::instance()->can_view_employee( $employee_id ) ) {
			return $tabs;
		}
		
		$tabs['hr-reports'] = [
			'key'        => 'hr-reports',
			'title'      => __( 'گزارشات', 'kasebi-erp' ),
			'icon'       => 'uik-r fa-document-signed',
			'order'      => 20,
			'permission' => 'hr_reports.view',
			'action'     => 'view',
			'template'   => 'modules/hr-reports/tabs/employee-reports.php',
		];
		
		return $tabs;
	}
	
	public function register_permissions( array $groups ): array {
		if ( ! isset( $groups['employees'] ) || ! is_array( $groups['employees'] ) ) {
			$groups['employees'] = [
				'key'    => 'employees',
				'label'  => __( 'منابع انسانی', 'kasebi-erp' ),
				'icon'   => 'uik-r fa-id-badge',
				'order'  => 30,
				'blocks' => [],
			];
		}
		
		if ( ! isset( $groups['employees']['blocks'] ) || ! is_array( $groups['employees']['blocks'] ) ) {
			$groups['employees']['blocks'] = [];
		}
		
		$groups['employees']['blocks']['hr_reports'] = [
			'key'         => 'hr_reports',
			'label'       => __( 'گزارشات سازمانی', 'kasebi-erp' ),
			'icon'        => 'uik-r fa-document-signed',
			'order'       => 20,
			'description' => __( 'ثبت، مشاهده و مدیریت گزارشات سازمانی کارکنان و پیوست‌های مرتبط.', 'kasebi-erp' ),
			'permissions' => [
				'hr_reports_view'            => [
					'key'         => 'hr_reports.view',
					'label'       => __( 'دسترسی به گزارش‌ها', 'kasebi-erp' ),
					'description' => __( 'امکان ورود به بخش گزارشات سازمانی.', 'kasebi-erp' ),
					'type'        => 'view',
					'order'       => 10,
				],
				'hr_reports_list'            => [
					'key'         => 'hr_reports.list',
					'label'       => __( 'مشاهده فهرست گزارش‌ها', 'kasebi-erp' ),
					'description' => __( 'دامنه گزارش‌هایی که کاربر می‌تواند مشاهده کند.', 'kasebi-erp' ),
					'type'        => 'view',
					'order'       => 20,
					'scope'       => [
						'options' => [
							'own' => __( 'فقط گزارش‌های خود', 'kasebi-erp' ),
							'all' => __( 'همه گزارش‌ها', 'kasebi-erp' ),
						],
						'default' => 'own',
					],
				],
				'hr_reports_create'          => [
					'key'   => 'hr_reports.create',
					'label' => __( 'ثبت گزارش', 'kasebi-erp' ),
					'type'  => 'action',
					'order' => 30,
				],
				'hr_reports_edit'            => [
					'key'   => 'hr_reports.edit',
					'label' => __( 'ویرایش گزارش', 'kasebi-erp' ),
					'type'  => 'action',
					'order' => 40,
				],
				'hr_reports_delete'          => [
					'key'   => 'hr_reports.delete',
					'label' => __( 'حذف گزارش', 'kasebi-erp' ),
					'type'  => 'action',
					'order' => 50,
				],
				'hr_reports_manage_settings' => [
					'key'   => 'hr_reports.manage_settings',
					'label' => __( 'مدیریت انواع گزارشات سازمانی', 'kasebi-erp' ),
					'type'  => 'action',
					'order' => 60,
				],
			],
		];
		
		return $groups;
	}
	
	public function save(
		array $data,
		int $report_id = 0
	): int|WP_Error {
		global $wpdb;
		
		$report_id = absint( $report_id );
		$existing  = $report_id > 0
			? KERP_Modules_Hr_Reports_Query::instance()->get( $report_id )
			: NULL;
		
		if ( $report_id > 0 && ! is_array( $existing ) ) {
			return new WP_Error(
				'kerp_hr_report_not_found',
				__( 'گزارش پیدا نشد.', 'kasebi-erp' )
			);
		}
		
		$title = sanitize_text_field(
			(string) ( $data['title'] ?? '' )
		);
		
		if ( $title === '' ) {
			return new WP_Error(
				'kerp_hr_report_missing_title',
				__( 'عنوان گزارش را وارد کنید.', 'kasebi-erp' )
			);
		}
		
		$content = wp_kses_post(
			(string) ( $data['content'] ?? '' )
		);
		
		if ( trim( wp_strip_all_tags( $content ) ) === '' ) {
			return new WP_Error(
				'kerp_hr_report_missing_content',
				__( 'توضیحات گزارش را وارد کنید.', 'kasebi-erp' )
			);
		}
		
		$category = sanitize_key(
			(string) ( $data['category'] ?? '' )
		);
		
		if ( ! KERP_Modules_Hr_Reports_Settings::instance()->get_type( $category ) ) {
			return new WP_Error(
				'kerp_hr_report_invalid_category',
				__( 'نوع گزارش معتبر نیست.', 'kasebi-erp' )
			);
		}
		
		$metadata     = is_array( $existing['metadata'] ?? NULL )
			? $existing['metadata']
			: [];
		$new_metadata = isset( $data['metadata'] ) && is_array( $data['metadata'] )
			? $data['metadata']
			: [];
		$metadata     = array_merge(
			$metadata,
			$new_metadata
		);
		$now          = current_time( 'mysql' );
		$record       = [
			'category'   => $category,
			'title'      => $title,
			'content'    => $content,
			'updated_at' => $now,
			'metadata'   => wp_json_encode(
				$metadata,
				JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
			),
		];
		
		if ( $report_id > 0 ) {
			$result = $wpdb->update(
				self::table(),
				$record,
				[ 'id' => $report_id ],
				[
					'%s',
					'%s',
					'%s',
					'%s',
					'%s',
				],
				[ '%d' ]
			);
			
			if ( $result === FALSE ) {
				return new WP_Error(
					'kerp_hr_report_update_failed',
					__( 'ویرایش گزارش با خطا مواجه شد.', 'kasebi-erp' )
				);
			}
			
			do_action(
				'kerp_hr_report_saved',
				$report_id,
				$data,
				FALSE
			);
			
			return $report_id;
		}
		
		$record['employee_id'] = get_current_user_id();
		$record['created_at']  = $now;
		
		$result = $wpdb->insert(
			self::table(),
			$record,
			[
				'%s',
				'%s',
				'%s',
				'%s',
				'%s',
				'%d',
				'%s',
			]
		);
		
		if ( ! $result ) {
			return new WP_Error(
				'kerp_hr_report_insert_failed',
				__( 'ثبت گزارش با خطا مواجه شد.', 'kasebi-erp' )
			);
		}
		
		$report_id = (int) $wpdb->insert_id;
		
		do_action(
			'kerp_hr_report_saved',
			$report_id,
			$data,
			TRUE
		);
		
		return $report_id;
	}
	
	public function count_by_type( string $type_key ): int {
		global $wpdb;
		
		$type_key = sanitize_key( $type_key );
		
		if ( $type_key === '' ) {
			return 0;
		}
		
		return absint(
			$wpdb->get_var(
				$wpdb->prepare(
					'SELECT COUNT(*) FROM ' . self::table() . ' WHERE category = %s',
					$type_key
				)
			)
		);
	}
	
	public function replace_type_key(
		string $old_key,
		string $new_key
	): bool {
		global $wpdb;
		
		$old_key = sanitize_key( $old_key );
		$new_key = sanitize_key( $new_key );
		
		if ( $old_key === '' || $new_key === '' || $old_key === $new_key ) {
			return FALSE;
		}
		
		$result = $wpdb->update(
			self::table(),
			[ 'category' => $new_key ],
			[ 'category' => $old_key ],
			[ '%s' ],
			[ '%s' ]
		);
		
		return $result !== FALSE;
	}
	
	public function delete( int $report_id ): bool|WP_Error {
		global $wpdb;
		
		$report_id = absint( $report_id );
		
		if ( $report_id <= 0 ) {
			return new WP_Error(
				'kerp_hr_report_invalid_id',
				__( 'شناسه گزارش معتبر نیست.', 'kasebi-erp' )
			);
		}
		
		if ( ! KERP_Modules_Hr_Reports_Query::instance()->get( $report_id ) ) {
			return new WP_Error(
				'kerp_hr_report_not_found',
				__( 'گزارش پیدا نشد.', 'kasebi-erp' )
			);
		}
		
		$deleted = $wpdb->delete(
			self::table(),
			[ 'id' => $report_id ],
			[ '%d' ]
		);
		
		if ( $deleted === FALSE ) {
			return new WP_Error(
				'kerp_hr_report_delete_failed',
				__( 'حذف گزارش با خطا مواجه شد.', 'kasebi-erp' )
			);
		}
		
		do_action(
			'kerp_hr_report_deleted',
			$report_id
		);
		
		return TRUE;
	}
	
	private function load_services(): void {
		KERP_Modules_Hr_Reports_Settings::instance();
		KERP_Modules_Hr_Reports_Query::instance();
		KERP_Modules_Hr_Reports_Form::instance();
		KERP_Modules_Hr_Reports_List_Table::instance();
		KERP_Modules_Hr_Reports_Api::instance();
	}
	
	private function register_hooks(): void {
		add_filter(
			'kerp_app_pages',
			[ $this, 'register_pages' ],
			31
		);
		add_filter(
			'kerp_employee_profile_tabs',
			[ $this, 'register_employee_tab' ],
			31,
			3
		);
		add_filter(
			'kerp_employee_permission_groups',
			[ $this, 'register_permissions' ],
			31
		);
	}
	
}
