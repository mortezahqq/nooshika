<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Hr_Reports_Query {
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {}
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public function get( int $report_id ): ?array {
		global $wpdb;
		
		$report_id = absint( $report_id );
		
		if ( $report_id <= 0 ) {
			return NULL;
		}
		
		$row = $wpdb->get_row(
			$wpdb->prepare(
				'SELECT * FROM ' . KERP_Modules_Hr_Reports_Module::table() . ' WHERE id = %d LIMIT 1',
				$report_id
			),
			ARRAY_A
		);
		
		return is_array( $row )
			? $this->normalize_row( $row )
			: NULL;
	}
	
	public function find( array $args = [] ): array {
		global $wpdb;
		
		$defaults = [
			'employee_id' => 0,
			'category'    => '',
			'search'      => '',
			'date_from'   => '',
			'date_to'     => '',
			'page_number' => 1,
			'per_page'    => 20,
			'order'       => 'DESC',
		];
		$args     = wp_parse_args( $args, $defaults );
		$where    = [ '1=1' ];
		$params   = [];
		
		$employee_id = absint( $args['employee_id'] );
		
		if ( $employee_id > 0 ) {
			$where[]  = 'employee_id = %d';
			$params[] = $employee_id;
		}
		
		$category = sanitize_key(
			(string) $args['category']
		);
		
		if ( $category !== '' ) {
			$where[]  = 'category = %s';
			$params[] = $category;
		}
		
		$search = sanitize_text_field(
			(string) $args['search']
		);
		
		if ( $search !== '' ) {
			$like = '%' . $wpdb->esc_like( $search ) . '%';
			
			if ( ctype_digit( $search ) ) {
				$where[]  = '(id = %d OR title LIKE %s OR content LIKE %s)';
				$params[] = absint( $search );
				$params[] = $like;
				$params[] = $like;
			} else {
				$where[]  = '(title LIKE %s OR content LIKE %s)';
				$params[] = $like;
				$params[] = $like;
			}
		}
		
		$this->append_date_filter(
			$where,
			$params,
			(string) $args['date_from'],
			'>=',
			'00:00:00'
		);
		$this->append_date_filter(
			$where,
			$params,
			(string) $args['date_to'],
			'<=',
			'23:59:59'
		);
		
		$this->apply_scope(
			$where,
			$params
		);
		
		$page_number = max(
			1,
			absint( $args['page_number'] )
		);
		$per_page    = max(
			1,
			min(
				100,
				absint( $args['per_page'] )
			)
		);
		$offset      = ( $page_number - 1 ) * $per_page;
		$order       = strtoupper( (string) $args['order'] ) === 'ASC'
			? 'ASC'
			: 'DESC';
		$where_sql   = implode( ' AND ', $where );
		$count_sql   = 'SELECT COUNT(*) FROM ' . KERP_Modules_Hr_Reports_Module::table() . ' WHERE ' . $where_sql;
		
		if ( ! empty( $params ) ) {
			$count_sql = $wpdb->prepare(
				$count_sql,
				...$params
			);
		}
		
		$total       = absint(
			$wpdb->get_var( $count_sql )
		);
		$list_sql    = 'SELECT * FROM ' . KERP_Modules_Hr_Reports_Module::table()
			. ' WHERE ' . $where_sql
			. ' ORDER BY created_at ' . $order . ', id ' . $order
			. ' LIMIT %d OFFSET %d';
		$list_params = array_merge(
			$params,
			[ $per_page, $offset ]
		);
		$list_sql    = $wpdb->prepare(
			$list_sql,
			...$list_params
		);
		$rows        = $wpdb->get_results(
			$list_sql,
			ARRAY_A
		);
		$items       = [];
		
		foreach ( (array) $rows as $row ) {
			if ( is_array( $row ) ) {
				$items[] = $this->normalize_row( $row );
			}
		}
		
		return apply_filters(
			'kerp_hr_reports_query_result',
			[
				'items'        => $items,
				'total'        => $total,
				'per_page'     => $per_page,
				'page_number'  => $page_number,
				'total_pages'  => max(
					1,
					(int) ceil( $total / $per_page )
				),
				'request_args' => $args,
			],
			$args
		);
	}
	
	public function can_view_employee( int $employee_id ): bool {
		$employee_id = absint( $employee_id );
		
		if ( $employee_id <= 0 ) {
			return FALSE;
		}
		
		$scope = kerp_list_scope( 'hr_reports' );
		
		if ( $scope === 'all' ) {
			return TRUE;
		}
		
		if ( $scope === 'own' ) {
			return $employee_id === get_current_user_id();
		}
		
		if ( $scope === 'team' ) {
			return in_array(
				$employee_id,
				$this->get_team_user_ids(),
				TRUE
			);
		}
		
		return FALSE;
	}
	
	public function can_access_report( array $report ): bool {
		return $this->can_view_employee(
			absint( $report['employee_id'] ?? 0 )
		);
	}
	
	public function get_employee_options(): array {
		global $wpdb;
		
		$scope = kerp_list_scope( 'hr_reports' );
		
		if ( $scope === 'none' ) {
			return [];
		}
		
		if ( $scope === 'own' ) {
			$user_id = get_current_user_id();
			
			return $user_id > 0
				? [ $user_id => get_user_name_by_id( $user_id ) ]
				: [];
		}
		
		$user_ids = $wpdb->get_col(
			'SELECT DISTINCT employee_id FROM ' . KERP_Modules_Hr_Reports_Module::table() . ' ORDER BY employee_id ASC'
		);
		
		if ( $scope === 'team' ) {
			$user_ids = array_values(
				array_intersect(
					array_map( 'absint', (array) $user_ids ),
					$this->get_team_user_ids()
				)
			);
		}
		
		$options = [];
		
		foreach ( (array) $user_ids as $user_id ) {
			$user_id = absint( $user_id );
			
			if ( $user_id <= 0 ) {
				continue;
			}
			
			$user = get_userdata( $user_id );
			
			$options[ $user_id ] = $user instanceof WP_User
				? get_user_name_by_id( $user_id )
				: sprintf(
					__( 'کاربر حذف‌شده #%s', 'kasebi-erp' ),
					number_format_i18n( $user_id )
				);
		}
		
		return $options;
	}
	
	private function append_date_filter(
		array &$where,
		array &$params,
		string $date,
		string $operator,
		string $time
	): void {
		$date = trim( $date );
		
		if ( $date === '' ) {
			return;
		}
		
		$gregorian_date = KERP_Helpers_Date::jalali_to_gregorian( $date );
		
		if ( ! is_string( $gregorian_date ) || $gregorian_date === '' ) {
			return;
		}
		
		$operator = $operator === '<=' ? '<=' : '>=';
		$where[]  = 'created_at ' . $operator . ' %s';
		$params[] = str_replace( '/', '-', $gregorian_date ) . ' ' . $time;
	}
	
	private function apply_scope(
		array &$where,
		array &$params
	): void {
		$scope = kerp_list_scope( 'hr_reports' );
		
		if ( $scope === 'all' ) {
			return;
		}
		
		if ( $scope === 'own' ) {
			$where[]  = 'employee_id = %d';
			$params[] = get_current_user_id();
			
			return;
		}
		
		if ( $scope === 'team' ) {
			$user_ids = $this->get_team_user_ids();
			
			if ( empty( $user_ids ) ) {
				$where[] = '1=0';
				
				return;
			}
			
			$where[] = 'employee_id IN (' . implode(
				',',
				array_fill(
					0,
					count( $user_ids ),
					'%d'
				)
			) . ')';
			$params  = array_merge(
				$params,
				$user_ids
			);
			
			return;
		}
		
		$where[] = '1=0';
	}
	
	private function get_team_user_ids(): array {
		$user_ids = apply_filters(
			'kerp_hr_reports_team_user_ids',
			[ get_current_user_id() ],
			get_current_user_id()
		);
		$user_ids = is_array( $user_ids )
			? $user_ids
			: [];
		
		return array_values(
			array_unique(
				array_filter(
					array_map(
						'absint',
						$user_ids
					)
				)
			)
		);
	}
	
	private function normalize_row( array $row ): array {
		$row['id']          = absint( $row['id'] ?? 0 );
		$row['employee_id'] = absint( $row['employee_id'] ?? 0 );
		$row['category']    = sanitize_key(
			(string) ( $row['category'] ?? '' )
		);
		$row['title']       = sanitize_text_field(
			(string) ( $row['title'] ?? '' )
		);
		$row['content']     = (string) ( $row['content'] ?? '' );
		$row['metadata']    = json_decode(
			(string) ( $row['metadata'] ?? '' ),
			TRUE
		);
		$row['metadata']    = is_array( $row['metadata'] )
			? $row['metadata']
			: [];
		
		return $row;
	}
}
