<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Hr_Reports_List_Table {
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {}
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public function get_filters( array $values = [] ): array {
		$date = isset( $values['date'] ) && is_array( $values['date'] )
			? $values['date']
			: [];
		
		$filters = [
			'search'   => [
				'key'         => 'search',
				'name'        => 'search',
				'label'       => __( 'جستجو', 'kasebi-erp' ),
				'type'        => 'text',
				'placeholder' => __( 'عنوان، توضیحات یا شناسه گزارش', 'kasebi-erp' ),
				'value'       => sanitize_text_field(
					(string) ( $values['search'] ?? '' )
				),
				'order'       => 10,
				'col'         => 12,
			],
			'employee' => [
				'key'         => 'employee_id',
				'name'        => 'employee_id',
				'label'       => __( 'کارمند', 'kasebi-erp' ),
				'type'        => 'select',
				'placeholder' => __( 'همه کارکنان', 'kasebi-erp' ),
				'options'     => KERP_Modules_Hr_Reports_Query::instance()->get_employee_options(),
				'value'       => absint( $values['employee_id'] ?? 0 ),
				'order'       => 20,
			],
			'category' => [
				'key'         => 'category',
				'name'        => 'category',
				'label'       => __( 'نوع گزارش', 'kasebi-erp' ),
				'type'        => 'select',
				'placeholder' => __( 'همه انواع', 'kasebi-erp' ),
				'options'     => KERP_Modules_Hr_Reports_Settings::instance()->get_type_options( FALSE ),
				'value'       => sanitize_key(
					(string) ( $values['category'] ?? '' )
				),
				'order'       => 30,
			],
			'date'     => [
				'key'   => 'date',
				'name'  => 'date',
				'label' => __( 'تاریخ ثبت گزارش', 'kasebi-erp' ),
				'type'  => 'date-range',
				'col'   => 12,
				'value' => [
					'from' => sanitize_text_field(
						(string) ( $date['from'] ?? '' )
					),
					'to'   => sanitize_text_field(
						(string) ( $date['to'] ?? '' )
					),
				],
				'order' => 40,
			],
		];
		
		if ( kerp_list_scope( 'hr_reports' ) === 'own' ) {
			unset( $filters['employee'] );
		}
		
		$filters = apply_filters(
			'kerp_hr_reports_list_filters',
			$filters,
			$values
		);
		$filters = is_array( $filters )
			? $filters
			: [];
		
		uasort(
			$filters,
			[ $this, 'sort_by_order' ]
		);
		
		return $filters;
	}
	
	public function sort_by_order( array $first, array $second ): int {
		return (int) ( $first['order'] ?? 100 )
			<=> (int) ( $second['order'] ?? 100 );
	}
}
