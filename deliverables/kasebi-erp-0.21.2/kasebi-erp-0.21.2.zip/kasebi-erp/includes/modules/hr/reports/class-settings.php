<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Hr_Reports_Settings {
	public const TYPES_OPTION = 'kerp_hr_report_types';
	private static ?self $instance = NULL;
	private ?array $types = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {
		add_action(
			'update_option_' . self::TYPES_OPTION,
			[ $this, 'clear_cache' ],
			10,
			0
		);
		add_action(
			'add_option_' . self::TYPES_OPTION,
			[ $this, 'clear_cache' ],
			10,
			0
		);
	}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public function get_types( bool $active_only = FALSE ): array {
		if ( $this->types === NULL ) {
			$stored = get_option( self::TYPES_OPTION, NULL );
			
			if ( $stored === NULL ) {
				$stored = $this->defaults();
			}
			
			$this->types = $this->sanitize_types(
				is_array( $stored ) ? $stored : []
			);
		}
		
		$types = $this->types;
		
		if ( $active_only ) {
			$types = array_filter(
				$types,
				function( array $type ): bool {
					return ! isset( $type['active'] ) || (bool) $type['active'];
				}
			);
		}
		
		$types = apply_filters(
			'kerp_hr_report_types',
			$types,
			$active_only
		);
		$types = is_array( $types ) ? $types : [];
		uasort( $types, [ $this, 'sort_types' ] );
		
		return $types;
	}
	
	public function get_type( string $type_key ): ?array {
		$type_key = sanitize_key( $type_key );
		$types    = $this->get_types();
		
		return isset( $types[ $type_key ] ) && is_array( $types[ $type_key ] )
			? $types[ $type_key ]
			: NULL;
	}
	
	public function get_type_options( bool $active_only = TRUE ): array {
		$options = [];
		
		foreach ( $this->get_types( $active_only ) as $type_key => $type ) {
			$options[ $type_key ] = sanitize_text_field(
				(string) ( $type['label'] ?? $type_key )
			);
		}
		
		return $options;
	}
	
	public function save_type(
		array $data,
		string $original_key = ''
	): bool|WP_Error {
		$original_key = sanitize_key( $original_key );
		$type         = $this->sanitize_type( $data );
		$type_key     = $type['key'];
		
		if ( $type_key === '' ) {
			return new WP_Error(
				'kerp_hr_report_type_missing_key',
				__( 'کلید نوع گزارش را وارد کنید.', 'kasebi-erp' )
			);
		}
		
		if ( $type['label'] === '' ) {
			return new WP_Error(
				'kerp_hr_report_type_missing_label',
				__( 'عنوان نوع گزارش را وارد کنید.', 'kasebi-erp' )
			);
		}
		
		$types = $this->get_types();
		
		if (
			$original_key !== ''
			&& $original_key !== $type_key
			&& isset( $types[ $type_key ] )
		) {
			return new WP_Error(
				'kerp_hr_report_type_duplicate',
				__( 'نوع گزارش دیگری با این کلید وجود دارد.', 'kasebi-erp' )
			);
		}
		
		if ( $original_key !== '' && $original_key !== $type_key ) {
			unset( $types[ $original_key ] );
			KERP_Modules_Hr_Reports_Module::instance()->replace_type_key(
				$original_key,
				$type_key
			);
		}
		
		$types[ $type_key ] = $type;
		$this->save_types( $types );
		
		do_action(
			'kerp_hr_report_type_saved',
			$type_key,
			$type,
			$original_key
		);
		
		return TRUE;
	}
	
	public function delete_type(
		string $type_key,
		string $replacement_key = ''
	): bool|WP_Error {
		$type_key        = sanitize_key( $type_key );
		$replacement_key = sanitize_key( $replacement_key );
		$types           = $this->get_types();
		
		if ( ! isset( $types[ $type_key ] ) ) {
			return TRUE;
		}
		
		$usage_count = KERP_Modules_Hr_Reports_Module::instance()->count_by_type( $type_key );
		
		if ( $usage_count > 0 ) {
			if (
				$replacement_key === ''
				|| $replacement_key === $type_key
				|| ! isset( $types[ $replacement_key ] )
			) {
				return new WP_Error(
					'kerp_hr_report_type_used',
					__( 'این نوع در گزارش‌ها استفاده شده است؛ نوع جایگزین را انتخاب کنید.', 'kasebi-erp' )
				);
			}
			
			KERP_Modules_Hr_Reports_Module::instance()->replace_type_key(
				$type_key,
				$replacement_key
			);
		}
		
		unset( $types[ $type_key ] );
		$this->save_types( $types );
		
		do_action(
			'kerp_hr_report_type_deleted',
			$type_key,
			$replacement_key
		);
		
		return TRUE;
	}
	
	public function get_categories(): array {
		return $this->get_types();
	}
	
	public function get_category( string $category_key ): ?array {
		return $this->get_type( $category_key );
	}
	
	public function get_category_options(): array {
		return $this->get_type_options();
	}
	
	public function sort_types( array $first, array $second ): int {
		return (int) ( $first['order'] ?? 100 )
			<=> (int) ( $second['order'] ?? 100 );
	}
	
	public function clear_cache(): void {
		$this->types = NULL;
	}
	
	private function sanitize_types( array $types ): array {
		$clean = [];
		
		foreach ( $types as $type_key => $type ) {
			if ( ! is_array( $type ) ) {
				continue;
			}
			
			$type['key'] = $type['key'] ?? $type_key;
			$type        = $this->sanitize_type( $type );
			
			if ( $type['key'] === '' ) {
				continue;
			}
			
			$clean[ $type['key'] ] = $type;
		}
		
		uasort( $clean, [ $this, 'sort_types' ] );
		
		return $clean;
	}
	
	private function sanitize_type( array $data ): array {
		$active = $data['active'] ?? 0;
		
		if ( is_array( $active ) ) {
			$active = in_array(
				'1',
				array_map( 'strval', $active ),
				TRUE
			);
		} else {
			$active = (string) $active === '1' || $active === TRUE;
		}
		
		return [
			'key'         => sanitize_key( (string) ( $data['key'] ?? '' ) ),
			'label'       => sanitize_text_field( (string) ( $data['label'] ?? '' ) ),
			'description' => sanitize_textarea_field( (string) ( $data['description'] ?? '' ) ),
			'icon'        => sanitize_text_field( (string) ( $data['icon'] ?? 'ni ni-file-text' ) ),
			'color'       => sanitize_key( (string) ( $data['color'] ?? 'primary' ) ),
			'active'      => $active,
			'order'       => absint( $data['order'] ?? 100 ),
		];
	}
	
	private function save_types( array $types ): void {
		$types = $this->sanitize_types( $types );
		
		update_option(
			self::TYPES_OPTION,
			$types,
			FALSE
		);
		
		$this->types = $types;
	}
	
	private function defaults(): array {
		return [
			'cashier'   => [
				'key'         => 'cashier',
				'label'       => __( 'صندوق', 'kasebi-erp' ),
				'description' => '',
				'color'       => 'danger',
				'icon'        => 'ni ni-coins',
				'active'      => TRUE,
				'order'       => 10,
			],
			'hr'        => [
				'key'         => 'hr',
				'label'       => __( 'پرسنلی', 'kasebi-erp' ),
				'description' => '',
				'color'       => 'success',
				'icon'        => 'ni ni-users',
				'active'      => TRUE,
				'order'       => 20,
			],
			'sale'      => [
				'key'         => 'sale',
				'label'       => __( 'فروش', 'kasebi-erp' ),
				'description' => '',
				'color'       => 'warning',
				'icon'        => 'ni ni-cart',
				'active'      => TRUE,
				'order'       => 30,
			],
			'warehouse' => [
				'key'         => 'warehouse',
				'label'       => __( 'انبار', 'kasebi-erp' ),
				'description' => '',
				'color'       => 'info',
				'icon'        => 'ni ni-package',
				'active'      => TRUE,
				'order'       => 40,
			],
		];
	}
}
