<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Hr_Reports_Api {
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {
		$this->register_hooks();
	}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	private function register_hooks(): void {
		add_action(
			'kasebi_ajax_hr_reports_save',
			[ $this, 'save_report' ]
		);
		add_action(
			'kasebi_ajax_hr_reports_delete',
			[ $this, 'delete_report' ]
		);
		add_action(
			'kasebi_ajax_hr_reports_save_type',
			[ $this, 'save_type' ]
		);
		add_action(
			'kasebi_ajax_hr_reports_delete_type',
			[ $this, 'delete_type' ]
		);
	}
	
	public function save_report(): void {
		$report_id = absint(
			$_POST['report_id'] ?? 0
		);
		
		$this->guard(
			$report_id > 0
				? 'edit'
				: 'create'
		);
		
		if ( $report_id > 0 ) {
			$this->guard_item_scope( $report_id );
		}
		
		$attachment_value = $_POST['attachment'] ?? '';
		$attachments      = KERP_Modules_Hr_Reports_Form::instance()->sanitize_attachments(
			is_array( $attachment_value )
				? wp_unslash( $attachment_value )
				: $this->post_text( 'attachment' )
		);
		
		$result = KERP_Modules_Hr_Reports_Module::instance()->save(
			[
				'category' => $this->post_text( 'category' ),
				'title'    => $this->post_text( 'title' ),
				'content'  => $this->post_content( 'content' ),
				'metadata' => [
					'attachments' => $attachments,
				],
			],
			$report_id
		);
		
		if ( is_wp_error( $result ) ) {
			$this->error(
				$result->get_error_message()
			);
		}
		
		$page          = $this->return_page();
		$page_response = KERP_Api_Page_Content::build_page_response(
			$page,
			[],
			TRUE
		);
		$page_response['report_id'] = (int) $result;
		
		$this->success(
			$report_id > 0
				? __( 'گزارش با موفقیت ویرایش شد.', 'kasebi-erp' )
				: __( 'گزارش با موفقیت ثبت شد.', 'kasebi-erp' ),
			$page_response
		);
	}
	
	public function delete_report(): void {
		$this->guard( 'delete' );
		
		$report_id = absint(
			$_POST['report_id']
				?? $_POST['item_id']
				?? 0
		);
		
		$this->guard_item_scope( $report_id );
		
		$result = KERP_Modules_Hr_Reports_Module::instance()->delete(
			$report_id
		);
		
		if ( is_wp_error( $result ) ) {
			$this->error(
				$result->get_error_message()
			);
		}
		
		$page_response = KERP_Api_Page_Content::build_page_response(
			$this->return_page(),
			[],
			TRUE
		);
		
		$this->success(
			__( 'گزارش با موفقیت حذف شد.', 'kasebi-erp' ),
			$page_response
		);
	}
	
	public function save_type(): void {
		$this->guard( 'hr_reports.manage_settings' );
		
		$type = isset( $_POST['type'] ) && is_array( $_POST['type'] )
			? wp_unslash( $_POST['type'] )
			: [];
		$original_key = sanitize_key(
			(string) ( $type['original_key'] ?? '' )
		);
		
		$result = KERP_Modules_Hr_Reports_Settings::instance()->save_type(
			$type,
			$original_key
		);
		
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		
		$page = '/erp/settings/hr-reports/';
		
		$this->success(
			__( 'نوع گزارش با موفقیت ذخیره شد.', 'kasebi-erp' ),
			KERP_Api_Page_Content::build_page_response(
				$page,
				[],
				TRUE
			)
		);
	}
	
	public function delete_type(): void {
		$this->guard( 'hr_reports.manage_settings' );
		
		$type_key = sanitize_key(
			$this->post_text( 'type_key' )
				?: $this->post_text( 'item_id' )
		);
		$replacement_key = sanitize_key(
			$this->post_text( 'replacement_key' )
		);
		
		$result = KERP_Modules_Hr_Reports_Settings::instance()->delete_type(
			$type_key,
			$replacement_key
		);
		
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		
		$page = '/erp/settings/hr-reports/';
		
		$this->success(
			__( 'نوع گزارش حذف شد.', 'kasebi-erp' ),
			KERP_Api_Page_Content::build_page_response(
				$page,
				[],
				TRUE
			)
		);
	}
	
	private function guard_item_scope( int $report_id ): array {
		if ( $report_id <= 0 ) {
			$this->error(
				__( 'شناسه گزارش معتبر نیست.', 'kasebi-erp' )
			);
		}
		
		$report = KERP_Modules_Hr_Reports_Query::instance()->get(
			$report_id
		);
		
		if ( ! is_array( $report ) ) {
			$this->error(
				__( 'گزارش پیدا نشد.', 'kasebi-erp' )
			);
		}
		
		if ( ! KERP_Modules_Hr_Reports_Query::instance()->can_access_report( $report ) ) {
			$this->error(
				__( 'شما به این گزارش دسترسی ندارید.', 'kasebi-erp' )
			);
		}
		
		return $report;
	}
	
	private function guard( string $action ): void {
		if ( ! is_user_logged_in() ) {
			$this->error(
				__( 'برای انجام این عملیات باید وارد حساب کاربری شوید.', 'kasebi-erp' )
			);
		}
		
		if ( ! KERP_App::instance()->current_user_has_access() ) {
			$this->error(
				__( 'شما به سامانه دسترسی ندارید.', 'kasebi-erp' )
			);
		}
		
		$permission = str_contains( $action, '.' )
			? sanitize_text_field( $action )
			: 'hr_reports.' . sanitize_key( $action );
		
		if ( ! kerp_can( $permission, 'action' ) ) {
			$this->error(
				__( 'شما اجازه انجام این عملیات را ندارید.', 'kasebi-erp' )
			);
		}
	}
	
	private function return_page(): string {
		$page = $this->post_text( 'page' );
		
		return $page !== ''
			? $page
			: '/erp/hr-reports/';
	}
	
	private function post_text( string $key ): string {
		if ( ! isset( $_POST[ $key ] ) || is_array( $_POST[ $key ] ) ) {
			return '';
		}
		
		return sanitize_text_field(
			wp_unslash( $_POST[ $key ] )
		);
	}
	
	private function post_content( string $key ): string {
		if ( ! isset( $_POST[ $key ] ) || is_array( $_POST[ $key ] ) ) {
			return '';
		}
		
		return wp_kses_post(
			wp_unslash( $_POST[ $key ] )
		);
	}
	
	private function success(
		string $message,
		array $data = []
	): void {
		wp_send_json(
			array_merge(
				[
					'status'  => 'success',
					'message' => $message,
					'msg'     => $message,
				],
				$data
			)
		);
	}
	
	private function error(
		string $message,
		array $data = []
	): void {
		wp_send_json(
			array_merge(
				[
					'status'  => 'error',
					'message' => $message,
					'msg'     => $message,
				],
				$data
			)
		);
	}
}
