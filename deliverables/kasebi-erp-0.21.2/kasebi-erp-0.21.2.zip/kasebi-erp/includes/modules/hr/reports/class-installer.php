<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Hr_Reports_Installer {
	private const DB_VERSION = '1.0.0';
	private const DB_VERSION_OPTION = 'kerp_hr_reports_db_version';
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {}
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public function maybe_install(): void {
		if ( get_option( self::DB_VERSION_OPTION ) === self::DB_VERSION ) {
			return;
		}
		
		$this->install();
	}
	
	public function install(): void {
		global $wpdb;
		
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		
		$table   = KERP_Modules_Hr_Reports_Module::table();
		$charset = $wpdb->get_charset_collate();
		$sql     = "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			employee_id BIGINT UNSIGNED NOT NULL,
			category VARCHAR(60) NOT NULL,
			title VARCHAR(190) NOT NULL,
			content LONGTEXT NULL,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NULL,
			metadata LONGTEXT NULL,
			PRIMARY KEY  (id),
			KEY idx_employee_created (employee_id, created_at),
			KEY idx_category_created (category, created_at),
			KEY idx_created_at (created_at)
		) {$charset};";
		
		dbDelta( $sql );
		
		update_option(
			self::DB_VERSION_OPTION,
			self::DB_VERSION,
			FALSE
		);
	}
}
