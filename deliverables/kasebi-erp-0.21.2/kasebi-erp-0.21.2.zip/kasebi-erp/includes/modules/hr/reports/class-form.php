<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Hr_Reports_Form {
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {}
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public function render_modal(
		string $return_page = '/erp/hr-reports/',
		string $modal_id = 'hrReportModal'
	): void {
		$modal_id = sanitize_html_class( $modal_id );
		
		$fields = [
			[
				'id'    => 'kerp-hr-report-id',
				'name'  => 'report_id',
				'type'  => 'hidden',
				'value' => '',
			],
			[
				'id'       => 'kerp-hr-report-title',
				'name'     => 'title',
				'label'    => __( 'عنوان گزارش', 'kasebi-erp' ),
				'type'     => 'text',
				'class'    => 'col-md-6',
				'value'    => '',
				'required' => TRUE,
			],
			[
				'id'          => 'kerp-hr-report-category',
				'name'        => 'category',
				'label'       => __( 'نوع گزارش', 'kasebi-erp' ),
				'type'        => 'select',
				'class'       => 'col-md-6',
				'options'     => KERP_Modules_Hr_Reports_Settings::instance()->get_type_options( TRUE ),
				'placeholder' => __( 'انتخاب کنید', 'kasebi-erp' ),
				'value'       => '',
				'required'    => TRUE,
			],
			[
				'id'       => 'kerp-hr-report-content',
				'name'     => 'content',
				'label'    => __( 'توضیحات', 'kasebi-erp' ),
				'type'     => 'quill',
				'class'    => 'col-12',
				'value'    => '',
				'required' => TRUE,
			],
			[
				'id'             => 'kerp-hr-report-attachment',
				'name'           => 'attachment',
				'label'          => __( 'فایل‌های ضمیمه', 'kasebi-erp' ),
				'type'           => 'upload',
				'class'          => 'col-12',
				'value'          => '',
				'action'         => 'handle_file_upload',
				'max_files'      => 10,
				'accepted_files' => '',
			],
		];
		
		KERP_Helpers_Template::render_modal(
			[
				'id'          => $modal_id,
				'title'       => __( 'ثبت یا ویرایش گزارش سازمانی', 'kasebi-erp' ),
				'action'      => 'hr_reports_save',
				'page'        => $return_page,
				'button'      => __( 'ذخیره گزارش', 'kasebi-erp' ),
				'button_text' => __( 'ذخیره گزارش', 'kasebi-erp' ),
				'size'        => 'lg',
				'fields'      => $fields,
			]
		);
	}
	
	public function sanitize_attachments( string|array $value ): array {
		if ( is_string( $value ) ) {
			$value = preg_split(
				'/\s*,\s*/',
				trim( $value ),
				-1,
				PREG_SPLIT_NO_EMPTY
			);
		}
		
		$attachments = [];
		
		foreach ( (array) $value as $attachment_url ) {
			if ( ! is_scalar( $attachment_url ) ) {
				continue;
			}
			
			$attachment_url = esc_url_raw(
				trim( (string) $attachment_url )
			);
			
			if ( $attachment_url === '' ) {
				continue;
			}
			
			$attachments[] = $attachment_url;
		}
		
		return array_values(
			array_unique( $attachments )
		);
	}
	
	public function get_attachment_items( string|array $value ): array {
		$items = [];
		
		foreach ( $this->sanitize_attachments( $value ) as $index => $url ) {
			$file_data = KERP_Api_File_Upload::instance()->get_uploaded_file_data( $url );
			$original_name = is_array( $file_data )
				? sanitize_text_field(
					(string) ( $file_data['original_name'] ?? '' )
				)
				: '';
			
			if ( $original_name === '' ) {
				$original_name = sprintf(
					__( 'فایل ضمیمه %s', 'kasebi-erp' ),
					number_format_i18n( $index + 1 )
				);
			}
			
			$items[] = [
				'url'           => $url,
				'original_name' => $original_name,
				'file_data'     => $file_data,
			];
		}
		
		return $items;
	}
	
	public function get_populate_data( array $report ): array {
		$metadata = isset( $report['metadata'] ) && is_array( $report['metadata'] )
			? $report['metadata']
			: [];
		$attachments = $this->sanitize_attachments(
			$metadata['attachments'] ?? []
		);
		
		return [
			'report_id'  => [
				'id'    => '#kerp-hr-report-id',
				'type'  => 'text',
				'value' => absint( $report['id'] ?? 0 ),
			],
			'title'      => [
				'id'    => '#kerp-hr-report-title',
				'type'  => 'text',
				'value' => (string) ( $report['title'] ?? '' ),
			],
			'category'   => [
				'id'    => '#kerp-hr-report-category',
				'type'  => 'select',
				'value' => sanitize_key(
					(string) ( $report['category'] ?? '' )
				),
			],
			'content'    => [
				'id'    => '#kerp-hr-report-content',
				'type'  => 'quill',
				'value' => (string) ( $report['content'] ?? '' ),
			],
			'attachment' => [
				'id'    => '#kerp-hr-report-attachment',
				'type'  => 'upload',
				'value' => implode( ',', $attachments ),
			],
		];
	}
}
