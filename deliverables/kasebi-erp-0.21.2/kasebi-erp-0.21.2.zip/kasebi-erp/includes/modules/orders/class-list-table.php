<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Orders_List_Table {
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public function get_filters( array $values = [] ): array {
		$date  = isset( $values['date'] ) && is_array( $values['date'] ) ? $values['date'] : [];
		$total = isset( $values['total'] ) && is_array( $values['total'] ) ? $values['total'] : [];
		$state = sanitize_text_field( (string) ( $values['state'] ?? '' ) );
		
		$selected_product_id = is_scalar( $values['product_id'] ?? 0 ) ? absint( $values['product_id'] ?? 0 ) : 0;
		$product_options = [];
		if ( $selected_product_id ) {
			$product = wc_get_product( $selected_product_id );
			$product_options[ $selected_product_id ] = $product instanceof WC_Product
				? wp_strip_all_tags( $product->get_formatted_name() )
				: sprintf( __( 'محصول #%d (حذف‌شده)', 'kasebi-erp' ), $selected_product_id );
		}
		$filters = [
			'date'        => [
				'key'   => 'date',
				'name'  => 'date',
				'label' => __( 'تاریخ', 'kasebi-erp' ),
				'type'  => 'date-range',
				'value' => [
					'from' => sanitize_text_field( (string) ( $date['from'] ?? '' ) ),
					'to'   => sanitize_text_field( (string) ( $date['to'] ?? '' ) ),
				],
				'col'   => 12,
			],
			'order_id'    => [
				'key'   => 'order_id',
				'name'  => 'order_id',
				'label' => __( 'شماره سفارش', 'kasebi-erp' ),
				'type'  => 'text',
				'value' => absint( $values['order_id'] ?? 0 ) ?: '',
				'col'   => 4,
			],
			'search'      => [
				'key'   => 'search',
				'name'  => 'search',
				'label' => __( 'جستجوی سفارش', 'kasebi-erp' ),
				'type'  => 'text',
				'value' => sanitize_text_field( (string) ( $values['search'] ?? '' ) ),
				'col'   => 8,
			],
			'status'      => [
				'key'         => 'status',
				'name'        => 'status',
				'label'       => __( 'وضعیت', 'kasebi-erp' ),
				'type'        => 'select',
				'placeholder' => __( 'همه موارد', 'kasebi-erp' ),
				'options'     => KERP_Modules_Orders_Form::instance()->get_status_options( TRUE ),
				'value'       => sanitize_key( (string) ( $values['status'] ?? '' ) ),
				'col'         => 6,
			],
			'marketer_id' => [
				'key'         => 'marketer_id',
				'name'        => 'marketer_id',
				'label'       => __( 'ثبت‌کننده', 'kasebi-erp' ),
				'type'        => 'select',
				'placeholder' => __( 'همه موارد', 'kasebi-erp' ),
				'options'     => KERP_Modules_Orders_Query::instance()->get_marketer_options(),
				'value'       => absint( $values['marketer_id'] ?? 0 ),
				'col'         => 6,
			],
			'product_id'  => [
				'key'         => 'product_id',
				'name'        => 'product_id',
				'label'       => __( 'محصول', 'kasebi-erp' ),
				'type'        => 'select',
				'placeholder' => __( 'همه موارد', 'kasebi-erp' ),
				'options'     => $product_options,
				'value'       => $selected_product_id,
				'col'         => 12,
				'search'      => TRUE,
				'input_class' => 'select_ajax_search',
				'data'        => [
					'action' => 'search_product_items',
					'placeholder' => 'جستجوی نام، شناسه یا کد محصول',
				],
			],
			'total'       => [
				'key'   => 'total',
				'name'  => 'total',
				'label' => __( 'مبلغ سفارش', 'kasebi-erp' ),
				'type'  => 'price-range',
				'value' => [
					'from' => sanitize_text_field( (string) ( $total['from'] ?? $values['min_total'] ?? '' ) ),
					'to'   => sanitize_text_field( (string) ( $total['to'] ?? $values['max_total'] ?? '' ) ),
				],
				'col'   => 12,
			],
			'state'       => [
				'key'         => 'state',
				'name'        => 'state',
				'label'       => __( 'استان', 'kasebi-erp' ),
				'type'        => 'select',
				'placeholder' => __( 'همه موارد', 'kasebi-erp' ),
				'options'     => $this->get_state_options(),
				'value'       => $state,
				'col'         => 6,
				'input_class' => 'load_city',
				'search'      => TRUE,
				'data'        => [
					'target' => '#order_city_filter',
				],
			],
			'city'        => [
				'key'         => 'city',
				'name'        => 'city',
				'label'       => __( 'شهر', 'kasebi-erp' ),
				'type'        => 'select',
				'placeholder' => __( 'انتخاب شهر', 'kasebi-erp' ),
				'options'     => $this->get_city_options( $state ),
				'value'       => sanitize_text_field( (string) ( $values['city'] ?? '' ) ),
				'col'         => 6,
				'search'      => TRUE,
				'id'          => 'order_city_filter',
			],
		];
		
		$sold_product = is_scalar( $values['sold_product'] ?? '' ) ? (string) ( $values['sold_product'] ?? '' ) : '';
		if ( $sold_product !== '' && $sold_product !== '0' ) {
			$sold_label = __( 'محصول حذف‌شده', 'kasebi-erp' );
			if ( preg_match( '/^product-([1-9][0-9]*)$/', $sold_product, $match ) ) {
				$sold_item = wc_get_product( (int) $match[1] );
				$sold_label = $sold_item instanceof WC_Product ? wp_strip_all_tags( $sold_item->get_formatted_name() ) : sprintf( 'محصول #%d', (int) $match[1] );
			}
			$filters['sold_product'] = [ 'name' => 'sold_product', 'label' => 'فروش پرداخت‌شدهٔ محصول (بدون پرداخت داخلی اقساط)', 'type' => 'select', 'placeholder' => 'همه موارد', 'options' => [ $sold_product => $sold_label ], 'value' => $sold_product, 'col' => 12 ];
		}
		$utm_options = KERP_Modules_Orders_Query::instance()->get_utm_filter_options();
		foreach ( $this->get_utm_labels() as $key => $label ) {
			$value = $values[ $key ] ?? '';
			$filters[ $key ] = [
				'key'         => $key,
				'name'        => $key,
				'label'       => $label,
				'type'        => 'select',
				'placeholder' => __( 'همه موارد', 'kasebi-erp' ),
				'value'       => is_scalar( $value ) ? sanitize_text_field( (string) $value ) : '',
				'col'         => 6,
				'search'      => TRUE,
				'options'     => $utm_options[ $key ] ?? [],
			];
		}

		if ( kerp_list_scope( 'orders' ) !== 'all' ) {
			unset( $filters['marketer_id'] );
		}
		
		$filters = [ 'product_id' => $filters['product_id'] ] + $filters;
		return apply_filters( 'kerp_orders_filters', $filters, $values );
	}
	
	public function get_utm_labels(): array {
		return [
			'utm_source'   => __( 'منبع', 'kasebi-erp' ),
			'utm_medium'   => __( 'رسانه', 'kasebi-erp' ),
			'utm_campaign' => __( 'کمپین', 'kasebi-erp' ),
			'utm_term'     => __( 'عبارت جستجو', 'kasebi-erp' ),
			'utm_content'  => __( 'محتوای تبلیغ', 'kasebi-erp' ),
		];
	}

	public function get_sort_options(): array {
		return apply_filters(
			'kerp_orders_sort_options',
			[
				'newest'     => __( 'جدیدترین', 'kasebi-erp' ),
				'oldest'     => __( 'قدیمی‌ترین', 'kasebi-erp' ),
				'high-price' => __( 'بیشترین قیمت', 'kasebi-erp' ),
				'low-price'  => __( 'کمترین قیمت', 'kasebi-erp' ),
			]
		);
	}
	
	public function get_sort_map(): array {
		return apply_filters(
			'kerp_orders_sort_map',
			[
				'newest'     => [
					'order_by' => 'date',
					'order'    => 'DESC',
				],
				'oldest'     => [
					'order_by' => 'date',
					'order'    => 'ASC',
				],
				'high-price' => [
					'order_by' => 'total',
					'order'    => 'DESC',
				],
				'low-price'  => [
					'order_by' => 'total',
					'order'    => 'ASC',
				],
			]
		);
	}
	
	public function get_state_options(): array {
		$states = [];
		
		if ( function_exists( 'WC' ) && WC()->countries ) {
			$states = (array) WC()->countries->get_states( 'IR' );
		}
		
		return apply_filters( 'kerp_orders_state_filter_options', $states );
	}
	
	public function get_city_options( string $state = '' ): array {
		$state  = sanitize_text_field( $state );
		$cities = [];
		
		if ( $state !== '' && function_exists( 'PWS' ) ) {
			$pws = PWS();
			
			if ( is_object( $pws ) && is_callable( [ $pws, 'cities' ] ) ) {
				$result = $pws::cities( $state );
				$cities = is_array( $result ) ? $result : [];
			}
		}
		
		return apply_filters( 'kerp_orders_city_filter_options', $cities, $state );
	}
	
}
