<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Orders_Form {
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public function get_form_values( ?WC_Order $order ): array {
		if ( ! $order instanceof WC_Order ) {
			$settings = KERP_Modules_Orders_Settings::instance();
			
			return [
				'items'          => [],
				'shipping_title' => (string) $settings->get( 'general', 'default_shipping_title', __( 'ارسال', 'kasebi-erp' ) ),
				'shipping_total' => '',
				'coupon_code'    => '',
				'payment_method' => (string) $settings->get( 'general', 'default_payment_method', '' ),
				'customer_note'  => '',
			];
		}
		
		$items = [];
		
		foreach ( $order->get_items( 'line_item' ) as $item ) {
			if ( ! $item instanceof WC_Order_Item_Product ) {
				continue;
			}
			
			$quantity   = (float) ( $item->get_meta( 'line_decimal_qty', TRUE ) ?: $item->get_quantity() );
			$product_id = (int) ( $item->get_variation_id() ?: $item->get_product_id() );
			$unit_price = $quantity > 0 ? (float) $item->get_subtotal() / $quantity : 0;
			$items[]    = apply_filters(
				'kerp_orders_form_item_value',
				[
					'product_id' => $product_id,
					'quantity'   => $quantity,
					'unit_price' => wc_format_localized_price( $unit_price ),
				],
				$item,
				$order
			);
		}
		
		$shipping_title = '';
		$shipping_total = '';
		$shipping_items = $order->get_items( 'shipping' );
		$shipping       = reset( $shipping_items );
		
		if ( $shipping instanceof WC_Order_Item_Shipping ) {
			$shipping_title = $shipping->get_method_title();
			$shipping_total = wc_format_localized_price( $shipping->get_total() );
		}
		
		$coupon_codes = $order->get_coupon_codes();
		
		return apply_filters(
			'kerp_orders_form_values',
			[
				'items'          => $items,
				'shipping_title' => $shipping_title,
				'shipping_total' => $shipping_total,
				'coupon_code'    => (string) ( $coupon_codes[0] ?? '' ),
				'payment_method' => $order->get_payment_method(),
				'customer_note'  => $order->get_customer_note(),
			],
			$order
		);
	}
	
	public function get_item_fields( ?WC_Order $order = NULL, string $mode = 'create' ): array {
		$fields = [
			[
				'name'        => 'product_id',
				'label'       => __( 'محصول', 'kasebi-erp' ),
				'type'        => 'select',
				'options'     => $this->get_product_options(),
				'input_class' => 'js-select2',
				'required'    => TRUE,
			],
			[
				'name'     => 'quantity',
				'label'    => __( 'تعداد', 'kasebi-erp' ),
				'type'     => 'number',
				'required' => TRUE,
			],
			[
				'name'  => 'unit_price',
				'label' => __( 'قیمت واحد', 'kasebi-erp' ),
				'type'  => 'price',
			],
		];
		
		return apply_filters( 'kerp_orders_form_item_fields', $fields, $order, $mode );
	}
	
	public function render_list_status_modal( string $return_page = '/erp/orders/' ): void {
		if ( ! kerp_can( 'orders.change_status', 'action' ) ) {
			return;
		}
		
		KERP_Helpers_Template::render_modal(
			[
				'id'     => 'orderStatusModal',
				'title'  => __( 'تغییر وضعیت سفارش', 'kasebi-erp' ),
				'action' => 'orders_change_status',
				'page'   => $return_page,
				'button' => __( 'تغییر وضعیت', 'kasebi-erp' ),
				'size'   => 'md',
				'fields' => [
					[
						'id'          => 'order-status-order-id',
						'name'        => 'order_id',
						'type'        => 'hidden',
						'input_class' => 'no_clear',
						'value'       => 0,
					],
					[
						'id'          => 'order-status-value',
						'name'        => 'status',
						'type'        => 'hidden',
						'input_class' => 'no_clear',
						'value'       => '',
					],
					[
						'id'    => 'order-status-note',
						'name'  => 'note',
						'label' => __( 'یادداشت تغییر وضعیت', 'kasebi-erp' ),
						'type'  => 'quill',
						'class' => 'col-12',
					],
				],
			]
		);
	}
	
	public function get_status_options( bool $active_only = FALSE ): array {
		$options = KERP_Modules_Orders_Settings::instance()->get_status_options( $active_only );
		
		return apply_filters( 'kerp_orders_status_options', $options, $active_only );
	}
	
	public function get_status_label( string $status ): string {
		$status = str_replace( 'wc-', '', sanitize_key( $status ) );
		$label  = KERP_Modules_Orders_Settings::instance()->get_status_label( $status );
		
		return apply_filters( 'kerp_orders_status_label', $label, $status );
	}
	
	public function get_status_color( string $status ): string {
		$status = str_replace( 'wc-', '', sanitize_key( $status ) );
		$color  = KERP_Modules_Orders_Settings::instance()->get_status_color( $status );
		
		return apply_filters( 'kerp_orders_status_color', $color, $status );
	}
	
	public function get_allowed_next_statuses( string $current_status ): array {
		return KERP_Modules_Orders_Settings::instance()->get_allowed_next_statuses( $current_status );
	}
	
	public function get_payment_method_options(): array {
		$options = [];
		
		if ( function_exists( 'WC' ) && WC()->payment_gateways() ) {
			foreach ( WC()->payment_gateways()->payment_gateways() as $gateway_id => $gateway ) {
				if ( ! $gateway instanceof WC_Payment_Gateway ) {
					continue;
				}
				
				$options[ $gateway_id ] = $gateway->get_title() ?: $gateway_id;
			}
		}
		
		return apply_filters( 'kerp_orders_payment_method_options', $options );
	}
	
	public function get_payment_method_label( string $payment_method ): string {
		$options = $this->get_payment_method_options();
		
		return isset( $options[ $payment_method ] ) ? (string) $options[ $payment_method ] : '';
	}
	
	public function get_product_options( int $limit = 500 ): array {
		if ( ! function_exists( 'wc_get_products' ) ) {
			return [];
		}
		
		$products = wc_get_products(
			[
				'limit'   => max( 1, min( 1000, $limit ) ),
				'status'  => [ 'publish', 'private' ],
				'orderby' => 'name',
				'order'   => 'ASC',
				'return'  => 'objects',
			]
		);
		$options  = [];
		
		foreach ( (array) $products as $product ) {
			if ( ! $product instanceof WC_Product ) {
				continue;
			}
			
			if ( $product->is_type( 'variable' ) ) {
				foreach ( $product->get_children() as $variation_id ) {
					$variation = wc_get_product( $variation_id );
					
					if ( ! $variation instanceof WC_Product_Variation ) {
						continue;
					}
					
					$options[ $variation_id ] = $variation->get_formatted_name();
				}
				
				continue;
			}
			
			$options[ $product->get_id() ] = $product->get_formatted_name();
		}
		
		return apply_filters( 'kerp_orders_product_options', $options );
	}
	
}
