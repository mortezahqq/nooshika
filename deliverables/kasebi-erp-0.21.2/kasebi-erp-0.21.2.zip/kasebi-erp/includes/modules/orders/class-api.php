<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Orders_Api {
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {
		add_action( 'kasebi_ajax_orders_save', [ $this, 'save' ] );
		add_action( 'kasebi_ajax_orders_change_status', [ $this, 'change_status' ] );
		add_action( 'kasebi_ajax_orders_add_note', [ $this, 'add_note' ] );
		add_action( 'kasebi_ajax_orders_refund', [ $this, 'refund' ] );
		add_action( 'kasebi_ajax_orders_bulk_action', [ $this, 'bulk_action' ] );
		add_action( 'kasebi_ajax_orders_delete', [ $this, 'delete' ] );
		add_action( 'kasebi_ajax_search_product_items', [ $this, 'search_product_items' ] );
		add_action( 'kasebi_ajax_orders_save_general_settings', [ $this, 'save_general_settings' ] );
		add_action( 'kasebi_ajax_orders_backfill_index', [ $this, 'backfill_index' ] );
		add_action( 'kasebi_ajax_orders_save_unit', [ $this, 'save_unit' ] );
		add_action( 'kasebi_ajax_orders_delete_unit', [ $this, 'delete_unit' ] );
		add_action( 'kasebi_ajax_orders_save_status', [ $this, 'save_status' ] );
		add_action( 'kasebi_ajax_orders_save_deferred_settings', [ $this, 'save_deferred_settings' ] );
		add_action( 'kasebi_ajax_orders_save_print_settings', [ $this, 'save_print_settings' ] );
		add_action( 'kasebi_ajax_orders_get_order_items', [ $this, 'get_order_items' ] );
		add_action( 'kasebi_ajax_orders_search_products', [ $this, 'search_products' ] );
		add_action( 'kasebi_ajax_orders_load_product_block', [ $this, 'load_product_block' ] );
	}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public function save(): void {
		$order_id = absint( $_POST['order_id'] ?? 0 );
		
		$this->guard(
			$order_id > 0
				? 'orders.edit'
				: 'orders.create'
		);
		
		if ( $order_id > 0 ) {
			$this->guard_item_scope( $order_id );
		}
		
		$raw_payload = wp_unslash( $_POST );
		if ( $order_id === 0 && KERP_Modules_Payments_Module::enabled() ) { KERP_Modules_Payments_Api::create_order(); return; }
		if ( $order_id > 0 ) {
			$payment_order = wc_get_order( $order_id );
			if ( KERP_Modules_Payments_Module::enabled() && KERP_Modules_Payments_Proforma::is_draft( $payment_order ) ) { KERP_Modules_Payments_Api::save_proforma(); return; }
			if ( $payment_order && ( $payment_order->get_meta( '_kerp_deposit_amount' ) || $payment_order->get_meta( '_kerp_payment_id' ) || $payment_order->get_meta( '_kerp_installment_contract' ) ) ) { $this->error( 'سفارش دارای سند پرداخت یا قرارداد اقساط است؛ برای حفظ تطابق مبلغ و مشتری، پرداخت را از صفحه پیگیری مدیریت کنید.' ); }
		}
		
		$items = isset( $raw_payload['items'] ) && is_array( $raw_payload['items'] )
			? $raw_payload['items']
			: [];
		$extra = isset( $raw_payload['extra'] ) && is_array( $raw_payload['extra'] )
			? map_deep( $raw_payload['extra'], 'sanitize_text_field' )
			: [];
		
		$data = [
			'customer_id'      => absint( $raw_payload['customer_id'] ?? 0 ),
			'items'            => $items,
			'order_date'       => sanitize_text_field( (string) ( $raw_payload['order_date'] ?? '' ) ),
			'shipping_title'   => sanitize_text_field( (string) ( $raw_payload['shipping_title'] ?? '' ) ),
			'shipping_total'   => (string) ( $raw_payload['shipping_total'] ?? '' ),
			'coupon_code'      => sanitize_text_field( (string) ( $raw_payload['coupon_code'] ?? '' ) ),
			'custom_extra_fee' => (string) ( $raw_payload['custom_extra_fee'] ?? '' ),
			'custom_fee'       => (string) ( $raw_payload['custom_fee'] ?? '' ),
			'order_files'      => $raw_payload['order_files'] ?? '',
			'cashier_note'     => isset( $raw_payload['cashier_note'] )
				? wp_kses_post( (string) $raw_payload['cashier_note'] )
				: '',
			'extra'            => $extra,
		];
		
		$data = apply_filters(
			'kerp_orders_api_save_data',
			$data,
			$raw_payload,
			$order_id
		);
		
		if ( ! is_array( $data ) ) {
			$this->error(
				__( 'اطلاعات سفارش معتبر نیست.', 'kasebi-erp' )
			);
		}
		
		$result = KERP_Modules_Orders_Module::instance()->save(
			$data,
			$order_id,
			$raw_payload
		);
		
		if ( is_wp_error( $result ) ) {
			$this->error(
				$result->get_error_message()
			);
		}
		$page = KERP_Modules_Orders_Module::instance()->get_save_return_url( (int) $result );
		$page_response = KERP_Api_Page_Content::build_page_response(
			$page,
			$this->route_query( $page ),
			TRUE
		);
		
		$this->success(
			$order_id > 0
				? __( 'سفارش با موفقیت ویرایش شد.', 'kasebi-erp' )
				: __( 'سفارش با موفقیت ثبت شد.', 'kasebi-erp' ),
			array_merge(
				$page_response,
				[
					'order_id' => (int) $result,
					'url'      => $page,
					'data_url' => $page,
				]
			)
		);
	}
	
	public function change_status(): void {
		$this->guard( 'orders.change_status' );
		$order_id = absint( $_POST['order_id'] ?? 0 );
		$this->guard_item_scope( $order_id );
		$order = KERP_Modules_Orders_Query::instance()->get_order( $order_id );
		
		if ( ! $order instanceof WC_Order ) {
			$this->error( __( 'سفارش پیدا نشد.', 'kasebi-erp' ) );
		}
		
		$status  = str_replace( 'wc-', '', sanitize_key( $this->post_text( 'status' ) ) );
		if ( $order->get_meta( '_kerp_deposit_amount' ) || $order->get_meta( '_kerp_payment_id' ) || $order->get_meta( '_kerp_installment_contract' ) ) { $this->error( 'وضعیت سفارش دارای سند پرداخت از صفحه پرداخت‌ها و تأیید مالی مدیریت می‌شود.' ); }
		$allowed = KERP_Modules_Orders_Form::instance()->get_allowed_next_statuses( $order->get_status() );
		
		if ( ! isset( $allowed[ $status ] ) ) {
			$this->error( __( 'این تغییر وضعیت برای سفارش مجاز نیست.', 'kasebi-erp' ) );
		}
		
		if ( $status !== $order->get_status() ) {
			$order->update_status( $status, $this->post_content( 'note' ), TRUE );
			KERP_Core_Order_Index::instance()->sync_order( $order );
			do_action( 'kerp_orders_status_changed', $order, $status );
		}
		
		$page = $this->return_page( '/erp/orders/' );
		$this->success(
			__( 'وضعیت سفارش با موفقیت تغییر کرد.', 'kasebi-erp' ),
			KERP_Api_Page_Content::build_page_response( $page, $this->route_query( $page ), TRUE )
		);
	}
	
	public function add_note(): void {
		$this->guard( 'orders.add_note' );
		$order_id = absint( $_POST['order_id'] ?? 0 );
		$this->guard_item_scope( $order_id );
		$order = KERP_Modules_Orders_Query::instance()->get_order( $order_id );
		
		if ( ! $order instanceof WC_Order ) {
			$this->error( __( 'سفارش پیدا نشد.', 'kasebi-erp' ) );
		}
		
		$note = $this->post_content( 'note' );
		
		if ( trim( wp_strip_all_tags( $note ) ) === '' ) {
			$this->error( __( 'متن یادداشت را وارد کنید.', 'kasebi-erp' ) );
		}
		
		$order->add_order_note( $note, 0, TRUE );
		$page = $this->return_page( KERP_Modules_Orders_Module::instance()->get_order_edit_url( $order_id ) );
		
		$this->success(
			__( 'یادداشت سفارش ثبت شد.', 'kasebi-erp' ),
			KERP_Api_Page_Content::build_page_response( $page, $this->route_query( $page ), TRUE )
		);
	}

	public function refund(): void {
		if ( ! kerp_can( 'orders.refund', 'action' ) && ! kerp_can( 'orders.edit', 'action' ) ) {
			$this->error( __( 'دسترسی لازم برای عودت سفارش را ندارید.', 'kasebi-erp' ) );
		}

		$order_id = absint( $_POST['order_id'] ?? $_POST['item_id'] ?? 0 );
		$item_id  = absint( $_POST['order_item_id'] ?? 0 );

		$this->guard_item_scope( $order_id );

		$result = KERP_Modules_Orders_Module::instance()->refund_to_wallet( $order_id, $item_id );

		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}

		$page = $this->return_page( '/erp/orders/' );
		$this->success(
			$item_id > 0
				? __( 'مبلغ قلم انتخاب‌شده به کیف پول مشتری عودت شد.', 'kasebi-erp' )
				: __( 'مانده قابل عودت سفارش به کیف پول مشتری واریز شد.', 'kasebi-erp' ),
			array_merge(
				KERP_Api_Page_Content::build_page_response( $page, $this->route_query( $page ), TRUE ),
				[
					'refund_id'      => absint( $result['refund_id'] ?? 0 ),
					'transaction_id' => absint( $result['transaction_id'] ?? 0 ),
				]
			)
		);
	}

	public function bulk_action(): void {
		$operation = sanitize_key( $this->post_text( 'bulk_action' ) ?: $this->post_text( 'operation' ) );
		$order_ids = $_POST['customer_ids'] ?? [];
		$order_ids = is_array( $order_ids )
			? wp_unslash( $order_ids )
			: explode( ',', (string) $order_ids );
		$order_ids = array_values( array_filter( array_unique( array_map( 'absint', $order_ids ) ) ) );
		$payload   = isset( $_POST['payload'] ) && is_array( $_POST['payload'] )
			? wp_unslash( $_POST['payload'] )
			: [];

		if ( empty( $order_ids ) ) {
			$this->error( __( 'حداقل یک سفارش را انتخاب کنید.', 'kasebi-erp' ) );
		}
		if ( ! in_array( $operation, [ 'change_status', 'refund', 'delete' ], TRUE ) ) {
			$this->error( __( 'عملیات گروهی انتخاب‌شده معتبر نیست.', 'kasebi-erp' ) );
		}

		if ( $operation === 'change_status' ) {
			$this->guard( 'orders.change_status' );
		} elseif ( $operation === 'refund' ) {
			if ( ! kerp_can( 'orders.refund', 'action' ) && ! kerp_can( 'orders.edit', 'action' ) ) {
				$this->error( __( 'دسترسی لازم برای عودت سفارش‌ها را ندارید.', 'kasebi-erp' ) );
			}
		} else {
			$this->guard( 'orders.delete' );
		}

		$orders = [];
		foreach ( $order_ids as $order_id ) {
			$order = KERP_Modules_Orders_Query::instance()->get_order( $order_id );
			if ( ! $order instanceof WC_Order ) {
				$this->error( sprintf( __( 'سفارش #%d پیدا نشد یا به آن دسترسی ندارید.', 'kasebi-erp' ), $order_id ) );
			}
			$orders[ $order_id ] = $order;
		}

		if ( $operation === 'change_status' ) {
			$status = str_replace( 'wc-', '', sanitize_key( (string) ( $payload['status'] ?? '' ) ) );
			if ( $status === '' ) {
				$this->error( __( 'وضعیت مقصد را انتخاب کنید.', 'kasebi-erp' ) );
			}

			foreach ( $orders as $order ) {
				if ( $order->get_meta( '_kerp_deposit_amount' ) || $order->get_meta( '_kerp_payment_id' ) || $order->get_meta( '_kerp_installment_contract' ) ) { $this->error( 'وضعیت سفارش دارای سند پرداخت از صفحه پرداخت‌ها و تأیید مالی مدیریت می‌شود.' ); }
				$allowed = KERP_Modules_Orders_Form::instance()->get_allowed_next_statuses( $order->get_status() );
				if ( ! isset( $allowed[ $status ] ) ) {
					$this->error( sprintf( __( 'انتقال سفارش #%1$s از وضعیت فعلی به «%2$s» مجاز نیست.', 'kasebi-erp' ), $order->get_order_number(), KERP_Modules_Orders_Form::instance()->get_status_label( $status ) ) );
				}
			}

			foreach ( $orders as $order ) {
				$order->update_status( $status, __( 'تغییر وضعیت از عملیات گروهی ERP', 'kasebi-erp' ), TRUE );
				KERP_Core_Order_Index::instance()->sync_order( $order );
				do_action( 'kerp_orders_status_changed', $order, $status );
			}
			$message = sprintf( __( 'وضعیت %d سفارش با موفقیت تغییر کرد.', 'kasebi-erp' ), count( $orders ) );
		} elseif ( $operation === 'refund' ) {
			if ( ! class_exists( 'KERP_Modules_Wallet_Service' ) || ! KERP_Modules_Wallet_Service::instance()->is_available() ) {
				$this->error( __( 'سرویس کیف پول در دسترس نیست.', 'kasebi-erp' ) );
			}

			foreach ( $orders as $order ) {
				$remaining = method_exists( $order, 'get_remaining_refund_amount' )
					? (float) $order->get_remaining_refund_amount()
					: max( 0, (float) $order->get_total() - (float) $order->get_total_refunded() );
				if ( ! $order->is_paid() ) {
					$this->error( sprintf( __( 'سفارش #%s پرداخت نشده و قابل عودت نیست.', 'kasebi-erp' ), $order->get_order_number() ) );
				}
				if ( $order->get_customer_id() <= 0 || ! get_userdata( $order->get_customer_id() ) instanceof WP_User || $remaining <= 0 ) {
					$this->error( sprintf( __( 'سفارش #%s مشتری دارای کیف پول یا مبلغ قابل عودت ندارد.', 'kasebi-erp' ), $order->get_order_number() ) );
				}
			}

			$processed = 0;
			foreach ( array_keys( $orders ) as $order_id ) {
				$result = KERP_Modules_Orders_Module::instance()->refund_to_wallet( $order_id );
				if ( is_wp_error( $result ) ) {
					$this->error( sprintf( __( '%1$d سفارش عودت شد؛ عودت سفارش #%2$d انجام نشد: %3$s', 'kasebi-erp' ), $processed, $order_id, $result->get_error_message() ) );
				}
				$processed++;
			}
			$message = sprintf( __( 'مبلغ %d سفارش به کیف پول مشتریان عودت شد.', 'kasebi-erp' ), $processed );
		} else {
			foreach ( array_keys( $orders ) as $order_id ) {
				$result = KERP_Modules_Orders_Module::instance()->delete( $order_id );
				if ( is_wp_error( $result ) ) {
					$this->error( sprintf( __( 'حذف سفارش #%1$d انجام نشد: %2$s', 'kasebi-erp' ), $order_id, $result->get_error_message() ) );
				}
			}
			$message = sprintf( __( '%d سفارش با موفقیت حذف شد.', 'kasebi-erp' ), count( $orders ) );
		}

		$page = $this->return_page( '/erp/orders/' );
		$this->success(
			$message,
			KERP_Api_Page_Content::build_page_response( $page, $this->route_query( $page ), TRUE )
		);
	}
	
	public function delete(): void {
		$this->guard( 'orders.delete' );
		$order_id = absint( $_POST['order_id'] ?? $_POST['item_id'] ?? 0 );
		$this->guard_item_scope( $order_id );
		$result = KERP_Modules_Orders_Module::instance()->delete( $order_id );
		
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		
		$page = $this->return_page( '/erp/orders/' );
		$this->success(
			__( 'سفارش با موفقیت حذف شد.', 'kasebi-erp' ),
			KERP_Api_Page_Content::build_page_response( $page, $this->route_query( $page ), TRUE )
		);
	}
	
	public function search_product_items(): void {
		$this->guard_product_selection();
		
		$search = $this->post_text( 'search' );
		
		if ( mb_strlen( $search ) < 2 ) {
			$this->success(
				'',
				[
					'results' => [],
				]
			);
		}
		
		$data_store = WC_Data_Store::load( 'product' );
		
		$product_ids = $data_store->search_products(
			$search,
			'',
			TRUE,
			FALSE,
			30
		);
		
		$results = [];
		
		foreach ( $product_ids as $product_id ) {
			$product = wc_get_product( $product_id );
			
			if ( ! $product instanceof WC_Product ) {
				continue;
			}
			
			if ( ! $product->is_visible() && ! $product->is_type( 'variation' ) ) {
				continue;
			}
			
			$results[] = [
				'id'   => $product->get_id(),
				'text' => $product->get_formatted_name(),
			];
		}
		
		$this->success(
			'',
			[
				'results' => $results,
			]
		);
	}
	
	public function backfill_index(): void {
		$this->guard( 'orders.manage_settings' );
		if ( ! wp_verify_nonce( $this->post_text( 'backfill_nonce' ), 'kerp_orders_backfill_index' ) ) {
			$this->error( __( 'اعتبار درخواست منقضی شده است. صفحه را تازه‌سازی کنید.', 'kasebi-erp' ) );
		}
		$page = filter_var( $this->post_text( 'batch_page' ), FILTER_VALIDATE_INT, [ 'options' => [ 'min_range' => 1 ] ] );
		if ( $page === FALSE ) {
			$this->error( __( 'شماره دسته نامعتبر است.', 'kasebi-erp' ) );
		}
		try {
			$result = KERP_Modules_Orders_Module::instance()->run_index_backfill( $page );
		} catch ( Throwable $exception ) {
			$this->error( __( 'همگام‌سازی این دسته انجام نشد. دوباره تلاش کنید.', 'kasebi-erp' ) );
		}
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		if ( ! empty( $result['failed'] ) ) {
			$this->error( sprintf( __( 'همگام‌سازی %s سفارش در این دسته ناموفق بود. برای تکرار همین دسته دوباره تلاش کنید.', 'kasebi-erp' ), count( $result['failed'] ) ) );
		}
		$result['done'] = $result['current_page'] >= $result['max_pages'];
		$result['processed'] = min( $result['total'], $page * 100 );
		$this->success( __( 'دسته سفارش‌ها همگام‌سازی شد.', 'kasebi-erp' ), [ 'data' => $result ] );
	}

	public function save_general_settings(): void {
		$this->guard( 'orders.manage_settings' );
		$settings = isset( $_POST['settings'] ) && is_array( $_POST['settings'] )
			? wp_unslash( $_POST['settings'] )
			: [];
		KERP_Modules_Orders_Settings::instance()->update_general( $settings );
		$page = $this->return_page( '/erp/settings/orders/' );
		$this->success(
			__( 'تنظیمات عمومی سفارش‌ها ذخیره شد.', 'kasebi-erp' ),
			KERP_Api_Page_Content::build_page_response( $page, $this->route_query( $page ), TRUE )
		);
	}
	
	public function save_unit(): void {
		$this->guard( 'orders.manage_settings' );
		$unit         = isset( $_POST['unit'] ) && is_array( $_POST['unit'] )
			? wp_unslash( $_POST['unit'] )
			: [];
		$original_key = sanitize_key( (string) ( $unit['original_key'] ?? '' ) );
		$result       = KERP_Modules_Orders_Settings::instance()->save_unit( $unit, $original_key );
		
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		
		$page = '/erp/settings/orders/units/';
		$this->success(
			__( 'واحد محصول ذخیره شد.', 'kasebi-erp' ),
			KERP_Api_Page_Content::build_page_response( $page, [], TRUE )
		);
	}
	
	public function delete_unit(): void {
		$this->guard( 'orders.manage_settings' );
		$unit_key = $this->post_text( 'unit_key' ) ?: $this->post_text( 'item_id' );
		$result   = KERP_Modules_Orders_Settings::instance()->delete_unit( $unit_key );
		
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		
		$page = '/erp/settings/orders/units/';
		$this->success(
			__( 'واحد محصول حذف شد.', 'kasebi-erp' ),
			KERP_Api_Page_Content::build_page_response( $page, [], TRUE )
		);
	}
	
	public function save_status(): void {
		$this->guard( 'orders.manage_settings' );
		$status                 = isset( $_POST['status'] ) && is_array( $_POST['status'] )
			? wp_unslash( $_POST['status'] )
			: [];
		$status['allowed_next'] = isset( $status['allowed_next'] ) && is_array( $status['allowed_next'] )
			? $status['allowed_next']
			: [];
		$result                 = KERP_Modules_Orders_Settings::instance()->save_status( $status );
		
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		
		$page = '/erp/settings/orders/statuses/';
		$this->success(
			__( 'تنظیمات وضعیت سفارش ذخیره شد.', 'kasebi-erp' ),
			KERP_Api_Page_Content::build_page_response( $page, [], TRUE )
		);
	}
	
	public function save_deferred_settings(): void {
		$this->guard( 'orders.manage_settings' );
		$settings = isset( $_POST['settings'] ) && is_array( $_POST['settings'] )
			? wp_unslash( $_POST['settings'] )
			: [];
		KERP_Modules_Orders_Settings::instance()->update_deferred( $settings );
		$page = '/erp/settings/orders/deferred/';
		$this->success(
			__( 'تنظیمات پرداخت مدت‌دار ذخیره شد.', 'kasebi-erp' ),
			KERP_Api_Page_Content::build_page_response( $page, [], TRUE )
		);
	}
	
	public function save_print_settings(): void {
		$this->guard( 'orders.manage_settings' );
		$settings = isset( $_POST['settings'] ) && is_array( $_POST['settings'] )
			? wp_unslash( $_POST['settings'] )
			: [];
		KERP_Modules_Orders_Settings::instance()->update_print( $settings );
		$page = '/erp/settings/orders/print/';
		$this->success(
			__( 'تنظیمات چاپ و فاکتور ذخیره شد.', 'kasebi-erp' ),
			KERP_Api_Page_Content::build_page_response( $page, [], TRUE )
		);
	}
	
	public function get_order_items(): void {
		$order_id = absint( $_POST['order_id'] ?? 0 );
		
		if ( $order_id <= 0 ) {
			$this->error(
				__( 'شناسه سفارش نامعتبر است.', 'kasebi-erp' )
			);
		}
		
		$this->guard_item_scope( $order_id );
		
		$order = KERP_Modules_Orders_Query::instance()->get_order( $order_id );
		
		if ( ! $order instanceof WC_Order ) {
			$this->error(
				__( 'سفارش پیدا نشد.', 'kasebi-erp' )
			);
		}
		
		$items          = [];
		$items_subtotal = 0;
		$items_discount = 0;
		$items_total    = 0;
		
		$reserved_meta_keys = [
			'line_decimal_qty',
			'line_single_total',
			'off_percent',
			'note',
		];
		
		foreach ( $order->get_items( 'line_item' ) as $item ) {
			if ( ! $item instanceof WC_Order_Item_Product ) {
				continue;
			}
			
			$product = $item->get_product();
			
			$quantity_meta = $item->get_meta(
				'line_decimal_qty',
				TRUE
			);
			
			$quantity = $quantity_meta !== ''
				? (float) $quantity_meta
				: (float) $item->get_quantity();
			
			$subtotal = (float) $item->get_subtotal();
			$total    = (float) $item->get_total();
			
			$unit_price_meta = $item->get_meta(
				'line_single_total',
				TRUE
			);
			
			$unit_price = $unit_price_meta !== ''
				? (float) $unit_price_meta
				: (
				$quantity > 0
					? $subtotal / $quantity
					: 0
				);
			
			$discount_percent_meta = $item->get_meta(
				'off_percent',
				TRUE
			);
			
			$discount_percent = $discount_percent_meta !== ''
				? (float) $discount_percent_meta
				: (
				$subtotal > 0
					? max(
					0,
					( ( $subtotal - $total ) / $subtotal ) * 100
				)
					: 0
				);
			
			$discount_percent = max(
				0,
				min(
					100,
					$discount_percent
				)
			);
			
			$final_unit_price = $unit_price * (
					( 100 - $discount_percent ) / 100
				);
			
			$calculated_subtotal = $quantity * $unit_price;
			$calculated_total    = $quantity * $final_unit_price;
			$discount            = max(
				0,
				$calculated_subtotal - $calculated_total
			);
			
			$note = (string) $item->get_meta(
				'note',
				TRUE
			);
			
			$variations = [];
			
			foreach ( $item->get_formatted_meta_data( '_', TRUE ) as $meta ) {
				$meta_key = isset( $meta->key )
					? (string) $meta->key
					: '';
				
				if (
					$meta_key !== ''
					&& in_array(
						$meta_key,
						$reserved_meta_keys,
						TRUE
					)
				) {
					continue;
				}
				
				$label = trim(
					wp_strip_all_tags(
						(string) $meta->display_key
					)
				);
				
				$value = trim(
					wp_strip_all_tags(
						(string) $meta->display_value
					)
				);
				
				if (
					$label === ''
					|| $value === ''
				) {
					continue;
				}
				
				$variations[] = [
					'label' => $label,
					'value' => $value,
				];
			}
			
			$items[] = [
				'item_id'          => $item->get_id(),
				'product_id'       => $item->get_product_id(),
				'variation_id'     => $item->get_variation_id(),
				'name'             => $item->get_name(),
				'image_id'         => $product instanceof WC_Product
					? $product->get_image_id()
					: 0,
				'quantity'         => $quantity,
				'unit_price'       => $unit_price,
				'discount'         => $discount,
				'discount_percent' => $discount_percent,
				'final_unit_price' => $final_unit_price,
				'subtotal'         => $calculated_subtotal,
				'total'            => $calculated_total,
				'note'             => $note,
				'variations'       => $variations,
			];
			
			$items_subtotal += $calculated_subtotal;
			$items_discount += $discount;
			$items_total    += $calculated_total;
		}
		
		$html = KERP_Helpers_Template::get_template(
			'modules/orders/partials/order-items-modal.php',
			[
				'order'       => $order,
				'items'       => $items,
				'can_refund'  => kerp_can( 'orders.refund', 'action' ) || kerp_can( 'orders.edit', 'action' ),
				'return_page' => $this->return_page( '/erp/orders/' ),
				'summary' => [
					'subtotal' => $items_subtotal,
					'discount' => $items_discount,
					'total'    => $items_total,
				],
			]
		);
		
		if ( $html === FALSE ) {
			$this->error(
				__( 'قالب اقلام سفارش پیدا نشد.', 'kasebi-erp' )
			);
		}
		
		$this->success(
			'',
			[
				'html'     => $html,
				'order_id' => $order_id,
			]
		);
	}
	
	public function search_products(): void {
		$this->guard_product_selection();
		
		$search = trim( $this->post_text( 'search' ) );
		
		if ( mb_strlen( $search ) < 2 ) {
			$this->error(
				__( 'حداقل دو کاراکتر برای جستجو وارد کنید.', 'kasebi-erp' )
			);
		}
		
		$product_ids = [];
		
		if ( ctype_digit( $search ) ) {
			$product_id = absint( $search );
			$product    = wc_get_product( $product_id );
			
			if ( $product instanceof WC_Product ) {
				$product_ids[] = $product_id;
			}
		}
		
		$sku_product_id = wc_get_product_id_by_sku( $search );
		
		if ( $sku_product_id > 0 ) {
			array_unshift(
				$product_ids,
				$sku_product_id
			);
		}
		
		$data_store = WC_Data_Store::load( 'product' );
		
		$searched_ids = $data_store->search_products(
			$search,
			'',
			TRUE,
			TRUE,
			30
		);
		
		$product_ids = array_merge(
			$product_ids,
			is_array( $searched_ids ) ? $searched_ids : []
		);
		
		$product_ids = array_values(
			array_unique(
				array_filter(
					array_map(
						'absint',
						$product_ids
					)
				)
			)
		);
		
		$selectable_ids = [];
		
		foreach ( $product_ids as $product_id ) {
			$product = wc_get_product( $product_id );
			
			if ( ! $product instanceof WC_Product ) {
				continue;
			}
			
			if ( $product->is_type( 'variable' ) ) {
				foreach ( $product->get_children() as $variation_id ) {
					$variation = wc_get_product( $variation_id );
					
					if ( ! $variation instanceof WC_Product_Variation ) {
						continue;
					}
					
					if ( ! in_array(
						$variation->get_status(),
						[ 'publish', 'private' ],
						TRUE
					) ) {
						continue;
					}
					
					$selectable_ids[] = $variation->get_id();
				}
				
				continue;
			}
			
			if ( ! in_array(
				$product->get_status(),
				[ 'publish', 'private' ],
				TRUE
			) ) {
				continue;
			}
			
			$selectable_ids[] = $product->get_id();
		}
		
		$selectable_ids = array_values(
			array_unique(
				array_map(
					'absint',
					$selectable_ids
				)
			)
		);
		
		$selectable_ids = apply_filters(
			'kerp_orders_product_search_ids',
			$selectable_ids,
			$search
		);
		
		$selectable_ids = is_array( $selectable_ids )
			? array_values( $selectable_ids )
			: [];
		
		if ( count( $selectable_ids ) === 1 ) {
			$product = wc_get_product(
				absint( $selectable_ids[0] )
			);
			
			if ( $product instanceof WC_Product ) {
				$html = KERP_Helpers_Template::get_template(
					'modules/orders/form/product-picker.php',
					[
						'product' => $product,
					]
				);
				
				if ( $html === FALSE ) {
					$this->error(
						__( 'قالب محصول پیدا نشد.', 'kasebi-erp' )
					);
				}
				
				$this->success(
					'',
					[
						'html'       => $html,
						'product_id' => $product->get_id(),
					]
				);
			}
		}
		
		$html = KERP_Helpers_Template::get_template(
			'modules/orders/form/product-search-list.php',
			[
				'product_ids' => $selectable_ids,
				'search'      => $search,
			]
		);
		
		if ( $html === FALSE ) {
			$this->error(
				__( 'قالب نتایج جستجوی محصول پیدا نشد.', 'kasebi-erp' )
			);
		}
		
		wp_send_json(
			[
				'status'  => 'list',
				'message' => '',
				'msg'     => '',
				'html'    => $html,
				'count'   => count( $selectable_ids ),
			]
		);
	}
	
	public function load_product_block(): void {
		$this->guard_product_selection();
		
		$product_id = absint( $_POST['product_id'] ?? 0 );
		
		if ( $product_id <= 0 ) {
			$this->error(
				__( 'شناسه محصول نامعتبر است.', 'kasebi-erp' )
			);
		}
		
		$product = wc_get_product( $product_id );
		
		if ( ! $product instanceof WC_Product ) {
			$this->error(
				__( 'محصول پیدا نشد.', 'kasebi-erp' )
			);
		}
		
		if (
			! in_array(
				$product->get_status(),
				[ 'publish', 'private' ],
				TRUE
			)
		) {
			$this->error(
				__( 'این محصول قابل انتخاب نیست.', 'kasebi-erp' )
			);
		}
		
		if ( $product->is_type( 'variable' ) ) {
			$variation_ids = [];
			
			foreach ( $product->get_children() as $variation_id ) {
				$variation = wc_get_product( $variation_id );
				
				if ( ! $variation instanceof WC_Product_Variation ) {
					continue;
				}
				
				if (
					! in_array(
						$variation->get_status(),
						[ 'publish', 'private' ],
						TRUE
					)
				) {
					continue;
				}
				
				$variation_ids[] = $variation->get_id();
			}
			
			$variation_ids = apply_filters(
				'kerp_orders_variable_product_variations',
				$variation_ids,
				$product
			);
			
			$variation_ids = is_array( $variation_ids )
				? array_values(
					array_unique(
						array_filter(
							array_map(
								'absint',
								$variation_ids
							)
						)
					)
				)
				: [];
			
			if ( empty( $variation_ids ) ) {
				$this->error(
					__( 'این محصول هیچ متغیر قابل انتخابی ندارد.', 'kasebi-erp' )
				);
			}
			
			$html = KERP_Helpers_Template::get_template(
				'modules/orders/form/product-search-list.php',
				[
					'product_ids' => $variation_ids,
					'parent_id'   => $product->get_id(),
					'search'      => '',
				]
			);
			
			if ( $html === FALSE ) {
				$this->error(
					__( 'قالب متغیرهای محصول پیدا نشد.', 'kasebi-erp' )
				);
			}
			
			$this->success(
				'',
				[
					'html'       => $html,
					'product_id' => $product->get_id(),
					'type'       => 'variable',
					'count'      => count( $variation_ids ),
				]
			);
		}
		
		$html = KERP_Helpers_Template::get_template(
			'modules/orders/form/product-picker.php',
			[
				'product'    => $product,
				'product_id' => $product->get_id(),
			]
		);
		
		if ( $html === FALSE ) {
			$this->error(
				__( 'قالب محصول پیدا نشد.', 'kasebi-erp' )
			);
		}
		
		$this->success(
			'',
			[
				'html'       => $html,
				'product_id' => $product->get_id(),
				'type'       => $product instanceof WC_Product_Variation
					? 'variation'
					: 'product',
			]
		);
	}
	
	private function guard_item_scope( int $order_id ): void {
		$order = KERP_Modules_Orders_Query::instance()->get_order( $order_id );
		
		if ( ! $order instanceof WC_Order ) {
			$this->error( __( 'به این سفارش دسترسی ندارید یا سفارش پیدا نشد.', 'kasebi-erp' ) );
		}
	}
	
	private function guard_product_selection(): void {
		if ( ! kerp_can( 'orders.create', 'action' ) && ! kerp_can( 'orders.view', 'action' ) ) {
			$this->error( __( 'دسترسی لازم را ندارید.', 'kasebi-erp' ) );
		}
	}
	
	private function guard( string $permission ): void {
		if ( ! kerp_can( $permission, 'action' ) ) {
			$this->error( __( 'دسترسی لازم را ندارید.', 'kasebi-erp' ) );
		}
	}
	
	private function post_text( string $key ): string {
		return isset( $_POST[ $key ] ) && ! is_array( $_POST[ $key ] )
			? sanitize_text_field( wp_unslash( $_POST[ $key ] ) )
			: '';
	}
	
	private function post_content( string $key ): string {
		return isset( $_POST[ $key ] ) && ! is_array( $_POST[ $key ] )
			? wp_kses_post( wp_unslash( $_POST[ $key ] ) )
			: '';
	}
	
	private function return_page( string $fallback = '/erp/orders/' ): string {
		$page = $this->post_text( 'return_page' ) ?: $this->post_text( 'page' );
		
		return str_starts_with( $page, '/erp/' ) ? $page : $fallback;
	}
	
	private function route_query( string $page ): array {
		$query = wp_parse_url( $page, PHP_URL_QUERY );
		
		if ( ! is_string( $query ) || $query === '' ) {
			return [];
		}
		
		parse_str( $query, $args );
		
		return is_array( $args ) ? $args : [];
	}
	
	private function success( string $message, array $data = [] ): never {
		wp_send_json(
			array_merge(
				[
					'status'  => 'success',
					'message' => $message,
					'msg'     => $message,
				],
				$data
			)
		);
	}
	
	private function error( string $message, array $data = [] ): never {
		wp_send_json(
			array_merge(
				[
					'status'  => 'error',
					'message' => $message,
					'msg'     => $message,
				],
				$data
			)
		);
	}
	
}
