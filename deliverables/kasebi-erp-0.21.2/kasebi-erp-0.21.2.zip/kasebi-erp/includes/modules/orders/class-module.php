<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Orders_Module {
	
	private const INDEX_BACKFILL_VERSION = '1.0.0';
	
	private const INDEX_BACKFILL_OPTION  = 'kerp_orders_index_backfill_version';
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {
		$this->load_services();
		$this->register_hooks();
		add_action( 'init', [ $this, 'clear_scheduled_index_backfill' ], 30 );
		if ( did_action( 'init' ) ) {
			$this->clear_scheduled_index_backfill();
		}
	}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	private function load_services(): void {
		KERP_Modules_Orders_Dashboard::instance();
		KERP_Modules_Orders_Settings::instance();
		KERP_Modules_Orders_Query::instance();
		KERP_Modules_Orders_Form::instance();
		KERP_Modules_Orders_List_Table::instance();
		KERP_Modules_Orders_Api::instance();
	}
	
	private function register_hooks(): void {
		add_action( 'template_redirect', [ $this, 'maybe_render_print' ], 1 );
		
		add_filter( 'kerp_app_pages', [ $this, 'register_pages' ], 40 );
		add_filter( 'kerp_customer_profile_tabs', [ $this, 'register_customer_tab' ], 50, 3 );
		add_filter( 'kerp_customers_profile_dropdown_actions', [ $this, 'register_profile_dropdown_action' ], 50, 3 );
		add_filter( 'kerp_employee_permission_groups', [ $this, 'register_permissions' ], 40 );
		add_filter( 'kerp_admin_bar_items', [ $this, 'admin_bar_items' ] );
	}
	
	public function maybe_render_print(): void {
		if ( ! is_user_logged_in() ) {
			return;
		}
		
		$action = sanitize_key( (string) ( $_GET['action'] ?? '' ) );
		
		if ( $action !== 'print' ) {
			return;
		}
		
		$request_uri  = wp_unslash( $_SERVER['REQUEST_URI'] ?? '' );
		$request_path = wp_parse_url( $request_uri, PHP_URL_PATH );
		$request_path = is_string( $request_path )
			? trailingslashit( $request_path )
			: '';
		
		if ( $request_path !== '/erp/orders/' ) {
			return;
		}
		
		if ( ! kerp_can( 'orders.view', 'action' ) ) {
			wp_die(
				esc_html__( 'شما اجازه چاپ سفارش را ندارید.', 'kasebi-erp' ),
				esc_html__( 'عدم دسترسی', 'kasebi-erp' ),
				[
					'response' => 403,
				]
			);
		}
		
		$order_id   = absint( $_GET['order_id'] ?? 0 );
		$print_type = sanitize_key( (string) ( $_GET['print_type'] ?? '' ) );
		
		if ( $order_id <= 0 ) {
			wp_die(
				esc_html__( 'شناسه سفارش نامعتبر است.', 'kasebi-erp' ),
				esc_html__( 'چاپ سفارش', 'kasebi-erp' ),
				[
					'response' => 404,
				]
			);
		}
		
		$order = wc_get_order( $order_id );
		
		if ( ! $order instanceof WC_Order ) {
			wp_die(
				esc_html__( 'سفارش پیدا نشد.', 'kasebi-erp' ),
				esc_html__( 'چاپ سفارش', 'kasebi-erp' ),
				[
					'response' => 404,
				]
			);
		}
		
		$print_templates = apply_filters(
			'kerp_orders_print_templates',
			[
				'pre-invoice' => 'modules/orders/print/pre-invoice.php',
				'official'    => 'modules/orders/print/official.php',
				'accounting'  => 'modules/orders/print/accounting.php',
				'roll'        => 'modules/orders/print/roll.php',
			],
			$order
		);
		
		if (
			! isset( $print_templates[ $print_type ] )
			|| ! is_string( $print_templates[ $print_type ] )
			|| $print_templates[ $print_type ] === ''
		) {
			wp_die(
				esc_html__( 'نوع چاپ نامعتبر است.', 'kasebi-erp' ),
				esc_html__( 'چاپ سفارش', 'kasebi-erp' ),
				[
					'response' => 404,
				]
			);
		}
		
		nocache_headers();
		
		do_action(
			'kerp_orders_before_print',
			$order,
			$print_type
		);
		
		KERP_Helpers_Template::render_template(
			$print_templates[ $print_type ],
			[
				'order'      => $order,
				'order_id'   => $order_id,
				'print_type' => $print_type,
			]
		);
		
		do_action(
			'kerp_orders_after_print',
			$order,
			$print_type
		);
		
		exit;
	}
	
	public function run_index_backfill( int $page = 1 ): array|WP_Error {
		$result = KERP_Core_Order_Index::instance()->reindex_batch( max( 1, $page ), 100 );
		
		if ( is_wp_error( $result ) ) {
			do_action( 'kerp_orders_index_backfill_failed', $result, $page );
			
			return $result;
		}
		
		$current_page = max( 1, absint( $result['current_page'] ?? $page ) );
		$max_pages    = absint( $result['max_pages'] ?? 0 );
		
		if ( ! empty( $result['failed'] ) ) {
			do_action( 'kerp_orders_index_backfill_failed', $result, $page );
			return $result;
		}
		
		if ( $current_page >= $max_pages ) {
			update_option( self::INDEX_BACKFILL_OPTION, self::INDEX_BACKFILL_VERSION, FALSE );
			do_action( 'kerp_orders_index_backfill_completed', $result );
		}
		return $result;
	}
	
	public function register_pages( array $pages ): array {
		$sales_group = [
			'key'   => 'sales',
			'title' => __( 'فروش و مالی', 'kasebi-erp' ),
			'icon'  => 'uik-r fa-shopping-cart',
			'order' => 25,
		];
		
		$system_group = [
			'key'        => 'settings',
			'title'      => __( 'تنظیمات', 'kasebi-erp' ),
			'icon'       => 'kik fa-settings-02',
			'order'      => 100,
			'sep_before' => TRUE,
		];
		
		$settings_menu = [
			'key'   => 'orders-settings',
			'title' => __( 'تنظیمات سفارش‌ها', 'kasebi-erp' ),
			'icon'  => 'uik-r fa-shopping-cart',
			'order' => 40,
		];
		
		$pages['orders'] = [
			'title'      => __( 'سفارش‌ها', 'kasebi-erp' ),
			'route'      => 'orders',
			'type'       => 'page',
			'template'   => 'modules/orders/pages/orders.php',
			'permission' => 'orders.view',
			'navigation' => [
				'group' => apply_filters( 'kerp_orders_sales_navigation_group', $sales_group ),
				'icon'  => 'uik-r fa-shopping-cart',
				'order' => 10,
			],
		];
		
		$pages['orders-new'] = [
			'title'      => __( 'ثبت سفارش', 'kasebi-erp' ),
			'route'      => 'orders/new',
			'type'       => 'sub-page',
			'template'   => 'modules/orders/pages/order-new.php',
			'permission' => 'orders.create',
			'navigation' => [
				'hidden' => TRUE,
				'active' => 'orders',
			],
		];
		
		$pages['orders-edit'] = [
			'title'      => __( 'ویرایش سفارش', 'kasebi-erp' ),
			'route'      => 'orders/{order_id}/edit',
			'type'       => 'sub-page',
			'template'   => 'modules/orders/pages/order-edit.php',
			'permission' => 'orders.edit',
			'navigation' => [
				'hidden' => TRUE,
				'active' => 'orders',
			],
		];
		
		$pages['orders-settings-general'] = [
			'title'      => __( 'تنظیمات عمومی سفارش‌ها', 'kasebi-erp' ),
			'route'      => 'settings/orders',
			'type'       => 'settings',
			'template'   => 'modules/orders/settings/general.php',
			'permission' => 'orders.manage_settings',
			'navigation' => [
				'group' => $system_group,
				'menu'  => $settings_menu,
				'title' => __( 'تنظیمات عمومی', 'kasebi-erp' ),
				'order' => 10,
			],
		];
		
		$pages['orders-settings-units'] = [
			'title'      => __( 'واحدهای محصول', 'kasebi-erp' ),
			'route'      => 'settings/orders/units',
			'type'       => 'settings',
			'template'   => 'modules/orders/settings/units.php',
			'permission' => 'orders.manage_settings',
			'navigation' => [
				'group' => $system_group,
				'menu'  => $settings_menu,
				'title' => __( 'واحدهای محصول', 'kasebi-erp' ),
				'order' => 20,
			],
		];
		
		$pages['orders-settings-statuses'] = [
			'title'      => __( 'وضعیت و گردش سفارش', 'kasebi-erp' ),
			'route'      => 'settings/orders/statuses',
			'type'       => 'settings',
			'template'   => 'modules/orders/settings/statuses.php',
			'permission' => 'orders.manage_settings',
			'navigation' => [
				'group' => $system_group,
				'menu'  => $settings_menu,
				'title' => __( 'وضعیت و گردش سفارش', 'kasebi-erp' ),
				'order' => 30,
			],
		];
		
		//		$pages['orders-settings-deferred'] = [
		//			'title'      => __( 'پرداخت مدت‌دار', 'kasebi-erp' ),
		//			'route'      => 'settings/orders/deferred',
		//			'type'       => 'settings',
		//			'template'   => 'modules/orders/settings/deferred.php',
		//			'permission' => 'orders.manage_settings',
		//			'navigation' => [
		//				'group' => $system_group,
		//				'menu'  => $settings_menu,
		//				'title' => __( 'پرداخت مدت‌دار', 'kasebi-erp' ),
		//				'order' => 40,
		//			],
		//		];
		//
		$pages['orders-settings-print'] = [
			'title'      => __( 'چاپ و فاکتور', 'kasebi-erp' ),
			'route'      => 'settings/orders/print',
			'type'       => 'settings',
			'template'   => 'modules/orders/settings/print.php',
			'permission' => 'orders.manage_settings',
			'navigation' => [
				'group' => $system_group,
				'menu'  => $settings_menu,
				'title' => __( 'چاپ و فاکتور', 'kasebi-erp' ),
				'order' => 50,
			],
		];
		
		return $pages;
	}
	
	public function register_customer_tab( array $tabs, int $customer_id, WP_User $customer ): array {
		$tabs['orders'] = [
			'key'        => 'orders',
			'title'      => __( 'سفارش‌ها', 'kasebi-erp' ),
			'icon'       => 'uik-r fa-shopping-cart',
			'order'      => 50,
			'group'      => 'finance-loyalty',
			'permission' => 'orders.view',
			'action'     => 'view',
			'template'   => 'modules/orders/tabs/customer-orders.php',
		];
		
		return $tabs;
	}
	
	public function register_profile_dropdown_action( array $actions, WP_User $customer, array $profile_context ): array {
		if ( ! kerp_can( 'orders.create', 'action' ) ) {
			return $actions;
		}
		
		$url = add_query_arg(
			'customer_id',
			(int) $customer->ID,
			$this->get_new_order_url()
		);
		
		$actions['add_customer_order'] = [
			'label'      => __( 'ثبت سفارش جدید', 'kasebi-erp' ),
			'icon'       => 'uik-r fa-shopping-cart-add',
			'href'       => $url,
			'class'      => 'page_activator',
			'order'      => 50,
			'attributes' => [
				'data-url' => $url,
			],
		];
		
		return $actions;
	}
	
	public function register_permissions( array $groups ): array {
		$group = isset( $groups['sales'] ) && is_array( $groups['sales'] )
			? $groups['sales']
			: [
				'key'    => 'sales',
				'label'  => __( 'فروش و مالی', 'kasebi-erp' ),
				'icon'   => 'uik-r fa-shopping-cart',
				'order'  => 25,
				'blocks' => [],
			];
		
		$group['blocks'] = isset( $group['blocks'] ) && is_array( $group['blocks'] )
			? $group['blocks']
			: [];
		
		$group['blocks']['orders'] = [
			'key'         => 'orders',
			'label'       => __( 'سفارش‌ها', 'kasebi-erp' ),
			'icon'        => 'uik-r fa-shopping-cart',
			'order'       => 10,
			'description' => __( 'مشاهده، ثبت و مدیریت سفارش‌های WooCommerce.', 'kasebi-erp' ),
			'permissions' => [
				'orders_view'          => [
					'key'   => 'orders.view',
					'label' => __( 'دسترسی به بخش سفارش‌ها', 'kasebi-erp' ),
					'type'  => 'view',
					'order' => 10,
				],
				'orders_list'          => [
					'key'         => 'orders.list',
					'label'       => __( 'مشاهده فهرست سفارش‌ها', 'kasebi-erp' ),
					'description' => __( 'دامنه سفارش‌هایی که کارمند می‌تواند مشاهده کند.', 'kasebi-erp' ),
					'type'        => 'view',
					'order'       => 20,
					'scope'       => [
						'options' => [
							'own' => __( 'فقط سفارش‌های ثبت‌شده توسط خود', 'kasebi-erp' ),
							'all' => __( 'همه سفارش‌ها', 'kasebi-erp' ),
						],
						'default' => 'own',
					],
				],
				'orders_create'        => [
					'key'   => 'orders.create',
					'label' => __( 'ثبت سفارش', 'kasebi-erp' ),
					'type'  => 'action',
					'order' => 30,
				],
				'orders_edit'          => [
					'key'   => 'orders.edit',
					'label' => __( 'ویرایش سفارش', 'kasebi-erp' ),
					'type'  => 'action',
					'order' => 40,
				],
				'orders_change_status' => [
					'key'   => 'orders.change_status',
					'label' => __( 'تغییر وضعیت سفارش', 'kasebi-erp' ),
					'type'  => 'action',
					'order' => 50,
				],
				'orders_add_note'      => [
					'key'   => 'orders.add_note',
					'label' => __( 'افزودن یادداشت سفارش', 'kasebi-erp' ),
					'type'  => 'action',
					'order' => 60,
				],
				'orders_refund'        => [
					'key'         => 'orders.refund',
					'label'       => __( 'عودت سفارش به کیف پول', 'kasebi-erp' ),
					'description' => __( 'عودت کامل سفارش یا قلم انتخابی فقط به کیف پول مشتری.', 'kasebi-erp' ),
					'type'        => 'action',
					'order'       => 70,
				],
				'orders_delete'        => [
					'key'   => 'orders.delete',
					'label' => __( 'حذف سفارش', 'kasebi-erp' ),
					'type'  => 'action',
					'order' => 80,
				],
				'orders_settings'      => [
					'key'   => 'orders.manage_settings',
					'label' => __( 'مدیریت تنظیمات سفارش‌ها', 'kasebi-erp' ),
					'type'  => 'action',
					'order' => 90,
				],
			],
		];
		
		$groups['sales'] = $group;
		
		return $groups;
	}
	
	public function save(
		array $data,
		int $order_id = 0,
		array $raw_payload = []
	): int|WP_Error {
		$customer_id = absint( $data['customer_id'] ?? 0 );
		
		if ( $customer_id <= 0 ) {
			return new WP_Error(
				'kerp_orders_customer_required',
				sprintf( __( 'انتخاب %s الزامی است.', 'kasebi-erp' ), KERP_Modules_Customers_Settings::instance()
				                                                                                     ->get_singular_label() )
			);
		}
		
		$is_new = $order_id <= 0;
		$extra  = isset( $data['extra'] ) && is_array( $data['extra'] )
			? $data['extra']
			: [];
		
		$data['extra'] = $extra;
		
		$customer = get_userdata( $customer_id );
		
		if ( ! $customer instanceof WP_User ) {
			return new WP_Error(
				'kerp_orders_customer_not_found',
				sprintf( __( '%s انتخاب‌شده پیدا نشد.', 'kasebi-erp' ), KERP_Modules_Customers_Settings::instance()
				                                                                                       ->get_singular_label() )
			);
		}
		
		$prepared_items = $this->prepare_items(
			isset( $data['items'] ) && is_array( $data['items'] )
				? $data['items']
				: []
		);
		if ( empty( $prepared_items ) ) {
			return new WP_Error(
				'kerp_orders_items_required',
				__( 'حداقل یک محصول به سفارش اضافه کنید.', 'kasebi-erp' )
			);
		}
		
		if ( $is_new ) {
			$order = wc_create_order(
				[
					'status' => ! empty( $data['_kerp_proforma'] ) ? 'pre-invoice' : ( ! empty( $data['_kerp_payment_flow'] ) ? 'pending' : KERP_Modules_Orders_Settings::instance()->get_default_status() ),
				]
			);
			
			if ( is_wp_error( $order ) ) {
				return $order;
			}
			if ( ! empty( $data['_kerp_no_payment_request'] ) ) {
				// Reserve the request before item/integration processing so retries cannot duplicate a partial save.
				$order->update_meta_data( '_kerp_no_payment_request', $data['_kerp_no_payment_request'] );
				$order->update_meta_data( 'marketer_id', get_current_user_id() );
				$order->set_customer_id( $customer_id );
				$order->save();
			}
		} else {
			$order = wc_get_order( $order_id );
			
			if ( ! $order instanceof WC_Order ) {
				return new WP_Error(
					'kerp_orders_not_found',
					__( 'سفارش پیدا نشد.', 'kasebi-erp' )
				);
			}
		}
		
		if ( ! empty( $data['_kerp_proforma'] ) ) {
			$order->set_status( 'pre-invoice' );
			$order->update_meta_data( '_kerp_proforma', $data['_kerp_proforma'] );
			if ( $is_new ) { $order->update_meta_data( '_kerp_proforma_request', $data['_kerp_proforma']['request'] ); }
		}
		$order->set_customer_id( $customer_id );
		
		$this->apply_customer_data(
			$order,
			$customer
		);
		
		$this->apply_order_date(
			$order,
			(string) ( $data['order_date'] ?? '' )
		);
		
		do_action(
			'kerp_orders_before_save',
			$order,
			$data,
			$is_new
		);
		
		$this->sync_order_items(
			$order,
			$prepared_items,
			$data,
			$is_new
		);
		
		$this->apply_shipping(
			$order,
			(string) ( $data['shipping_title'] ?? '' ),
			$data['shipping_total'] ?? ''
		);
		
		$this->apply_core_fees(
			$order,
			$data
		);
		
		/**
		 * ماژول‌های دیگر می‌توانند بعد از Feeهای اصلی،
		 * Feeهای خودشان را از data-for های ارسال‌شده اضافه کنند.
		 */
		do_action(
			'kerp_orders_after_apply_fees',
			$order,
			$raw_payload,
			$data,
			$is_new
		);
		
		$this->apply_order_files(
			$order,
			$data['order_files'] ?? ''
		);
		
		$this->apply_cashier_note(
			$order,
			(string) ( $data['cashier_note'] ?? '' )
		);
		
		if (
			$is_new
			|| absint(
				   $order->get_meta(
					   'marketer_id',
					   TRUE
				   )
			   ) <= 0
		) {
			$order->update_meta_data(
				'marketer_id',
				get_current_user_id()
			);
		}
		
		do_action(
			'kerp_orders_before_calculate_totals',
			$order,
			$data,
			$is_new
		);
		
		$order->calculate_totals( TRUE );
		
		if ( $is_new && ! empty( $data['_kerp_no_payment_request'] ) ) {
			$order->set_payment_method( '' );
			$order->set_payment_method_title( '' );
			$order->update_meta_data( '_kerp_no_payment_request', $data['_kerp_no_payment_request'] );
			$order->set_status( 'completed', 'ثبت مستقیم سفارش بدون شیوه پرداخت از ERP.' );
		}
		
		do_action(
			'kerp_orders_before_order_save',
			$order,
			$data,
			$is_new
		);
		
		$order->save();
		
		do_action(
			'kerp_orders_save_extra',
			$order->get_id(),
			$extra,
			$order,
			$is_new
		);
		
		KERP_Core_Order_Index::instance()
		                     ->sync_order( $order );
		
		do_action(
			$is_new
				? 'kerp_order_created'
				: 'kerp_order_updated',
			$order->get_id(),
			$order
		);
		
		do_action(
			'kerp_orders_after_save',
			$order,
			$data,
			$is_new
		);
		
		return (int) $order->get_id();
	}
	
	/** Apply the existing order-form integrations to a generated installment order. */
	public function apply_installment_context( WC_Order $order, array $raw ): array {
		$data = [ 'customer_id' => $order->get_customer_id(), 'items' => (array) ( $raw['items'] ?? [] ), 'extra' => map_deep( (array) ( $raw['extra'] ?? [] ), 'sanitize_text_field' ) ];
		$data = apply_filters( 'kerp_orders_api_save_data', $data, $raw, 0 );
		$this->apply_order_files( $order, $raw['order_files'] ?? '' );
		$this->apply_cashier_note( $order, wp_kses_post( KERP_Modules_Payments_Settings::text( $raw, 'cashier_note' ) ) );
		do_action( 'kerp_orders_before_order_save', $order, $data, TRUE );
		return $data;
	}
	public function delete( int $order_id ): bool|WP_Error {
		$order = KERP_Modules_Orders_Query::instance()->get_order( $order_id );
		if ( $order && ( $order->get_meta( '_kerp_installment_contract' ) || $order->get_meta( '_kerp_deposit_amount' ) || $order->get_meta( '_kerp_deposit_part' ) ) ) {
			return new WP_Error( 'kerp_installment_delete', 'حذف سفارش متصل به قرارداد اقساط مجاز نیست؛ سوابق پرداخت باید حفظ شوند.' );
		}
		
		if ( ! $order instanceof WC_Order ) {
			return new WP_Error( 'kerp_orders_not_found', __( 'سفارش پیدا نشد.', 'kasebi-erp' ) );
		}
		
		try {
			$order->delete( TRUE );
		}
		catch ( Throwable $exception ) {
			return new WP_Error( 'kerp_orders_delete_failed', $exception->getMessage() );
		}
		
		if ( wc_get_order( $order_id ) instanceof WC_Order ) {
			return new WP_Error( 'kerp_orders_delete_failed', __( 'حذف سفارش انجام نشد.', 'kasebi-erp' ) );
		}
		
		KERP_Core_Order_Index::instance()->delete_order( $order_id );
		do_action( 'kerp_order_deleted', $order_id );
		
		return TRUE;
	}
	
	/**
	 * Create a WooCommerce refund and credit the same amount to the customer wallet.
	 * When an item ID is supplied, only that line's refundable balance is returned.
	 */
	public function refund_to_wallet( int $order_id, int $item_id = 0 ): array|WP_Error {
		$order = KERP_Modules_Orders_Query::instance()->get_order( $order_id );
		if ( $order && ( $order->get_meta( '_kerp_installment_is_parent' ) || $order->get_meta( '_kerp_deposit_orders' ) ) ) {
			return new WP_Error( 'kerp_installment_refund', 'عودت وجه باید روی پرداخت قسط مربوط انجام شود تا مبلغ دوباره بازگردانده نشود.' );
		}
		
		if ( ! $order instanceof WC_Order ) {
			return new WP_Error( 'kerp_orders_not_found', __( 'سفارش پیدا نشد.', 'kasebi-erp' ) );
		}
		if ( ! $order->is_paid() ) {
			return new WP_Error( 'kerp_orders_refund_unpaid', __( 'سفارش پرداخت نشده است و امکان عودت وجه ندارد.', 'kasebi-erp' ) );
		}
		if ( class_exists( 'KERP_Modules_Payments_Cheques' ) ) {
			$collected = KERP_Modules_Payments_Cheques::amount_received( $order );
			if ( $collected !== NULL && $collected + 0.01 < (float) $order->get_total() ) {
				return new WP_Error( 'kerp_cheque_refund_uncollected', 'وجه همه چک‌های این پرداخت هنوز وصول نشده است؛ دریافت اصل چک به معنی وصول وجه نیست.' );
			}
		}
		$customer_id = (int) $order->get_customer_id();
		if ( $customer_id <= 0 || ! get_userdata( $customer_id ) instanceof WP_User ) {
			return new WP_Error( 'kerp_orders_refund_customer', __( 'این سفارش مشتری دارای حساب کاربری ندارد و امکان واریز به کیف پول نیست.', 'kasebi-erp' ) );
		}
		if ( ! class_exists( 'KERP_Modules_Wallet_Service' ) ) {
			return new WP_Error( 'kerp_orders_refund_wallet', __( 'سرویس کیف پول در دسترس نیست.', 'kasebi-erp' ) );
		}
		
		$wallet = KERP_Modules_Wallet_Service::instance();
		if ( ! $wallet->is_available() ) {
			return new WP_Error( 'kerp_orders_refund_wallet', __( 'افزونه کیف پول در دسترس نیست.', 'kasebi-erp' ) );
		}
		if ( $order->get_meta( '_kerp_wallet_refund_in_progress', TRUE ) !== '' ) {
			return new WP_Error( 'kerp_orders_refund_locked', __( 'یک عملیات عودت برای این سفارش در حال انجام است. چند لحظه بعد دوباره تلاش کنید.', 'kasebi-erp' ) );
		}
		
		$amount     = 0.0;
		$line_items = [];
		$item_name  = '';
		
		if ( $item_id > 0 ) {
			$item = $order->get_item( $item_id );
			if ( ! $item instanceof WC_Order_Item_Product ) {
				return new WP_Error( 'kerp_orders_refund_item', __( 'قلم انتخاب‌شده در این سفارش پیدا نشد.', 'kasebi-erp' ) );
			}
			
			$ordered_qty  = (float) $item->get_quantity();
			$refunded_qty = abs( (float) $order->get_qty_refunded_for_item( $item_id ) );
			$refund_qty   = max( 0, $ordered_qty - $refunded_qty );
			$refund_total = max( 0, (float) $item->get_total() - abs( (float) $order->get_total_refunded_for_item( $item_id ) ) );
			$refund_tax   = [];
			$item_taxes   = $item->get_taxes();
			
			foreach ( (array) ( $item_taxes['total'] ?? [] ) as $tax_id => $tax_total ) {
				$remaining_tax         = max( 0, (float) $tax_total - abs( (float) $order->get_tax_refunded_for_item( $item_id, (int) $tax_id ) ) );
				$refund_tax[ $tax_id ] = wc_format_decimal( $remaining_tax );
				$amount                += $remaining_tax;
			}
			
			$amount                 += $refund_total;
			$item_name              = $item->get_name();
			$line_items[ $item_id ] = [
				'qty'          => $refund_qty,
				'refund_total' => wc_format_decimal( $refund_total ),
				'refund_tax'   => $refund_tax,
			];
		} else {
			$amount = method_exists( $order, 'get_remaining_refund_amount' )
				? (float) $order->get_remaining_refund_amount()
				: max( 0, (float) $order->get_total() - (float) $order->get_total_refunded() );
		}
		
		$amount = (float) wc_format_decimal( $amount, wc_get_price_decimals() );
		if ( $amount <= 0 || ( $item_id > 0 && (float) ( $line_items[ $item_id ]['qty'] ?? 0 ) <= 0 ) ) {
			return new WP_Error( 'kerp_orders_refund_empty', __( 'مبلغ قابل عودتی برای این مورد باقی نمانده است.', 'kasebi-erp' ) );
		}
		
		$remaining_order = method_exists( $order, 'get_remaining_refund_amount' )
			? (float) $order->get_remaining_refund_amount()
			: max( 0, (float) $order->get_total() - (float) $order->get_total_refunded() );
		if ( $amount > $remaining_order + 0.000001 ) {
			return new WP_Error( 'kerp_orders_refund_amount', __( 'مبلغ عودت از مانده قابل عودت سفارش بیشتر است.', 'kasebi-erp' ) );
		}
		
		$lock_token = wp_generate_uuid4();
		$order->update_meta_data( '_kerp_wallet_refund_in_progress', $lock_token );
		$order->save();
		
		$details        = $item_id > 0
			? sprintf( __( 'عودت قلم «%1$s» از سفارش #%2$s به کیف پول', 'kasebi-erp' ), $item_name, $order->get_order_number() )
			: sprintf( __( 'عودت سفارش #%s به کیف پول', 'kasebi-erp' ), $order->get_order_number() );
		$transaction_id = 0;
		$refund         = NULL;
		
		try {
			$transaction = $wallet->add_transaction( $customer_id, 'credit', $amount, $details );
			if ( is_wp_error( $transaction ) ) {
				return $transaction;
			}
			$transaction_id = absint( $transaction );
			
			$refund = wc_create_refund( [
				'amount'         => $amount,
				'reason'         => $details,
				'order_id'       => $order_id,
				'line_items'     => $line_items,
				'refund_payment' => FALSE,
				'restock_items'  => FALSE,
			] );
			
			if ( is_wp_error( $refund ) || ! $refund instanceof WC_Order_Refund ) {
				$rollback = $wallet->add_transaction(
					$customer_id,
					'debit',
					$amount,
					sprintf( __( 'برگشت خودکار عودت ناموفق سفارش #%s', 'kasebi-erp' ), $order->get_order_number() )
				);
				if ( is_wp_error( $rollback ) ) {
					$order->add_order_note( __( 'هشدار: ثبت سند عودت ناموفق بود و برگشت اعتبار کیف پول نیز انجام نشد؛ نیازمند پیگیری فوری است.', 'kasebi-erp' ) );
				}
				
				return is_wp_error( $refund )
					? $refund
					: new WP_Error( 'kerp_orders_refund_failed', __( 'ثبت سند عودت انجام نشد.', 'kasebi-erp' ) );
			}
			
			$refund->update_meta_data( '_kerp_wallet_transaction_id', $transaction_id );
			$refund->update_meta_data( '_kerp_refund_destination', 'wallet' );
			$refund->update_meta_data( '_kerp_refunded_by', get_current_user_id() );
			$refund->save();
			
			if ( function_exists( 'set_wallet_transaction_meta' ) ) {
				set_wallet_transaction_meta( $transaction_id, 'kerp_order_id', $order_id, $customer_id );
				set_wallet_transaction_meta( $transaction_id, 'kerp_refund_id', $refund->get_id(), $customer_id );
			}
			
			$order->add_order_note( sprintf(
				__( 'مبلغ %1$s بابت %2$s به کیف پول مشتری عودت شد. شناسه تراکنش: %3$d', 'kasebi-erp' ),
				wp_strip_all_tags( wc_price( $amount, [ 'currency' => $order->get_currency() ] ) ),
				$item_id > 0 ? sprintf( __( 'قلم «%s»', 'kasebi-erp' ), $item_name ) : __( 'مانده سفارش', 'kasebi-erp' ),
				$transaction_id
			) );
			
			$fresh_order = wc_get_order( $order_id );
			if ( $fresh_order instanceof WC_Order ) {
				KERP_Core_Order_Index::instance()->sync_order( $fresh_order );
			}
			
			return [
				'refund_id'      => (int) $refund->get_id(),
				'transaction_id' => $transaction_id,
				'amount'         => $amount,
			];
		}
		catch ( Throwable $exception ) {
			if ( $refund instanceof WC_Order_Refund ) {
				return [
					'refund_id'      => (int) $refund->get_id(),
					'transaction_id' => $transaction_id,
					'amount'         => $amount,
				];
			}
			
			if ( $transaction_id > 0 ) {
				$wallet->add_transaction(
					$customer_id,
					'debit',
					$amount,
					sprintf( __( 'برگشت خودکار عودت ناموفق سفارش #%s', 'kasebi-erp' ), $order->get_order_number() )
				);
			}
			
			return new WP_Error( 'kerp_orders_refund_failed', $exception->getMessage() );
		}
		finally {
			$fresh_order = wc_get_order( $order_id );
			if ( $fresh_order instanceof WC_Order && $fresh_order->get_meta( '_kerp_wallet_refund_in_progress', TRUE ) === $lock_token ) {
				$fresh_order->delete_meta_data( '_kerp_wallet_refund_in_progress' );
				$fresh_order->save();
			}
		}
	}
	
	public function get_new_order_url(): string {
		return '/erp/orders/new/';
	}
	
	public function get_save_return_url( int $order_id, bool $prefer_edit = FALSE ): string {
		$can_view = kerp_can( 'orders.view', 'view' ) || kerp_can( 'orders.view', 'action' );
		$can_edit = kerp_can( 'orders.edit', 'view' ) || kerp_can( 'orders.edit', 'action' );
		if ( ! $prefer_edit && $can_view ) {
			return '/erp/orders/';
		}
		if ( $order_id > 0 && $can_edit && KERP_Modules_Orders_Query::instance()->get_order( $order_id ) ) {
			return $this->get_order_edit_url( $order_id );
		}
		if ( $can_view ) {
			return '/erp/orders/';
		}
		if ( kerp_can( 'orders.create', 'action' ) || kerp_can( 'orders.create', 'view' ) ) {
			return $this->get_new_order_url();
		}
		return '/erp/';
	}
	
	public function get_order_edit_url( int $order_id ): string {
		$order_id = KERP_Modules_Installment_Management_Service::main_order_id( $order_id );
		return '/erp/orders/' . absint( $order_id ) . '/edit/';
	}
	
	public function get_order_url( int $order_id ): string {
		return $this->get_order_edit_url( $order_id );
	}
	
	public function clear_scheduled_index_backfill(): void {
		if ( get_option( 'kerp_orders_manual_backfill_enabled', FALSE ) ) {
			return;
		}
		wp_unschedule_hook( 'kerp_orders_backfill_index' );
		if ( function_exists( 'as_unschedule_all_actions' ) ) {
			as_unschedule_all_actions( 'kerp_orders_backfill_index', NULL, 'kasebi-erp' );
		}
		update_option( 'kerp_orders_manual_backfill_enabled', 1, FALSE );
	}
	
	private function normalize_number( mixed $value, int $precision = 6 ): float {
		if (
			$value === NULL
			|| is_array( $value )
			|| is_object( $value )
		) {
			return 0;
		}
		
		$value = trim( (string) $value );
		
		if ( $value === '' ) {
			return 0;
		}
		
		if ( function_exists( 'nooshika_sanitize_numbers' ) ) {
			$value = nooshika_sanitize_numbers( $value );
		}
		
		/*
		 * ممیز عربی:
		 * 1٬500٫400
		 * →
		 * 1٬500.400
		 */
		$value = str_replace(
			'٫',
			'.',
			$value
		);
		
		/*
		 * جداکننده‌های هزارگان:
		 * 1,500.400
		 * 1٬500.400
		 * →
		 * 1500.400
		 */
		$value = str_replace(
			[
				',',
				'٬',
				' ',
				"\xc2\xa0",
			],
			'',
			$value
		);
		
		$value = preg_replace(
			'/[^0-9.\-]/',
			'',
			$value
		);
		
		if (
			$value === NULL
			|| $value === ''
			|| $value === '.'
			|| $value === '-'
			|| $value === '-.'
		) {
			return 0;
		}
		
		/*
		 * فقط اولین نقطه به‌عنوان ممیز باقی بماند.
		 */
		$negative = str_starts_with( $value, '-' );
		
		$value = ltrim( $value, '-' );
		
		$parts = explode( '.', $value );
		
		$integer = array_shift( $parts );
		$decimal = implode( '', $parts );
		
		$value = $integer !== ''
			? $integer
			: '0';
		
		if ( $decimal !== '' ) {
			$value .= '.' . $decimal;
		}
		
		if ( $negative ) {
			$value = '-' . $value;
		}
		
		return round(
			(float) $value,
			$precision
		);
	}
	
	private function prepare_items( array $items ): array {
		$prepared = [];
		
		foreach ( $items as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}
			$product_id  = absint( $item['product_id'] ?? 0 );
			$quantity    = $this->normalize_number( $item['quantity'] ?? '', 6 );
			$off_percent = $this->normalize_number( $item['off_percent'] ?? '', 4 );
			$unit_price  = $this->normalize_number( $item['unit_price'] ?? '', 6 );
			$subtotal    = $this->normalize_number( $item['subtotal'] ?? '', 6 );
			$line_total  = $this->normalize_number( $item['line_total'] ?? '', 6 );
			
			if (
				$product_id <= 0
				|| $quantity <= 0
			) {
				continue;
			}
			
			$product = wc_get_product(
				$product_id
			);
			
			if ( ! $product instanceof WC_Product ) {
				continue;
			}
			
			$prepared_item = [
				'product_id'  => $product_id,
				'quantity'    => $quantity,
				'off_percent' => $off_percent,
				'unit_price'  => $unit_price,
				'subtotal'    => $subtotal,
				'line_total'  => $line_total,
			];
			
			$prepared_item = apply_filters( 'kerp_orders_prepare_item_data', $prepared_item, $item );
			
			if ( is_array( $prepared_item ) ) {
				$prepared[] = $prepared_item;
			}
		}
		
		return $prepared;
	}
	
	private function remove_replaceable_items( WC_Order $order ): void {
		foreach ( [ 'line_item', 'shipping', 'coupon' ] as $item_type ) {
			foreach ( $order->get_items( $item_type ) as $item_id => $item ) {
				$order->remove_item( $item_id );
			}
		}
	}
	
	private function apply_customer_data( WC_Order $order, WP_User $customer ): void {
		$customer_id = (int) $customer->ID;
		$first_name  = (string) get_user_meta( $customer_id, 'first_name', TRUE );
		$last_name   = (string) get_user_meta( $customer_id, 'last_name', TRUE );
		$email       = (string) $customer->user_email;
		$phone       = KERP_Modules_Customers_Query::instance()->get_customer_phone( $customer_id );
		
		$order->set_billing_first_name( (string) get_user_meta( $customer_id, 'billing_first_name', TRUE ) ?: $first_name );
		$order->set_billing_last_name( (string) get_user_meta( $customer_id, 'billing_last_name', TRUE ) ?: $last_name );
		$order->set_billing_email( (string) get_user_meta( $customer_id, 'billing_email', TRUE ) ?: $email );
		$order->set_billing_phone( (string) get_user_meta( $customer_id, 'billing_phone', TRUE ) ?: $phone );
		$order->set_billing_country( (string) get_user_meta( $customer_id, 'billing_country', TRUE ) ?: 'IR' );
		$order->set_billing_state( (string) get_user_meta( $customer_id, 'billing_state', TRUE ) );
		$order->set_billing_city( (string) get_user_meta( $customer_id, 'billing_city', TRUE ) );
		$order->set_billing_address_1( (string) get_user_meta( $customer_id, 'billing_address_1', TRUE ) );
		$order->set_billing_address_2( (string) get_user_meta( $customer_id, 'billing_address_2', TRUE ) );
		$order->set_billing_postcode( (string) get_user_meta( $customer_id, 'billing_postcode', TRUE ) );
		
		$order->set_shipping_first_name( (string) get_user_meta( $customer_id, 'shipping_first_name', TRUE ) ?: $first_name );
		$order->set_shipping_last_name( (string) get_user_meta( $customer_id, 'shipping_last_name', TRUE ) ?: $last_name );
		$order->set_shipping_country( (string) get_user_meta( $customer_id, 'shipping_country', TRUE ) ?: 'IR' );
		$order->set_shipping_state( (string) get_user_meta( $customer_id, 'shipping_state', TRUE ) ?: (string) get_user_meta( $customer_id, 'billing_state', TRUE ) );
		$order->set_shipping_city( (string) get_user_meta( $customer_id, 'shipping_city', TRUE ) ?: (string) get_user_meta( $customer_id, 'billing_city', TRUE ) );
		$order->set_shipping_address_1( (string) get_user_meta( $customer_id, 'shipping_address_1', TRUE ) ?: (string) get_user_meta( $customer_id, 'billing_address_1', TRUE ) );
		$order->set_shipping_address_2( (string) get_user_meta( $customer_id, 'shipping_address_2', TRUE ) ?: (string) get_user_meta( $customer_id, 'billing_address_2', TRUE ) );
		$order->set_shipping_postcode( (string) get_user_meta( $customer_id, 'shipping_postcode', TRUE ) ?: (string) get_user_meta( $customer_id, 'billing_postcode', TRUE ) );
	}
	
	private function normalize_decimal( mixed $value ): ?string {
		if (
			$value === NULL
			|| is_array( $value )
			|| is_object( $value )
		) {
			return NULL;
		}
		
		$value = trim(
			(string) $value
		);
		
		if ( $value === '' ) {
			return NULL;
		}
		
		if ( function_exists( 'nooshika_sanitize_numbers' ) ) {
			$value = nooshika_sanitize_numbers(
				$value
			);
		}
		
		$value = str_replace(
			[
				',',
				'٬',
				' ',
				"\xc2\xa0",
			],
			'',
			$value
		);
		
		$value = str_replace(
			'٫',
			'.',
			$value
		);
		
		$value = preg_replace(
			'/[^0-9.\-]/',
			'',
			$value
		);
		
		if (
			$value === NULL
			|| $value === ''
			|| $value === '.'
			|| $value === '-'
			|| $value === '-.'
		) {
			return NULL;
		}
		
		$negative = str_starts_with(
			$value,
			'-'
		);
		
		$value = ltrim(
			$value,
			'-'
		);
		
		$parts = explode(
			'.',
			$value
		);
		
		$integer = preg_replace(
			'/\D/',
			'',
			array_shift( $parts )
		);
		
		$decimal = preg_replace(
			'/\D/',
			'',
			implode( '', $parts )
		);
		
		if (
			$integer === ''
			&& $decimal === ''
		) {
			return NULL;
		}
		
		$number = $integer !== ''
			? $integer
			: '0';
		
		if ( $decimal !== '' ) {
			$number .= '.' . $decimal;
		}
		
		if ( $negative ) {
			$number = '-' . $number;
		}
		
		return wc_format_decimal(
			$number
		);
	}
	
	private function sync_order_items(
		WC_Order $order,
		array $items,
		array $data,
		bool $is_new
	): void {
		$current_items = $order->get_items(
			'line_item'
		);
		
		$used_item_ids = [];
		
		foreach ( $items as $item_data ) {
			$product = wc_get_product(
				absint(
					$item_data['product_id'] ?? 0
				)
			);
			
			if ( ! $product instanceof WC_Product ) {
				continue;
			}
			
			$item_id = absint(
				$item_data['item_id'] ?? 0
			);
			
			$order_item = isset( $current_items[ $item_id ] )
			              && $current_items[ $item_id ] instanceof WC_Order_Item_Product
				? $current_items[ $item_id ]
				: new WC_Order_Item_Product();
			
			$quantity    = (float) $item_data['quantity'];
			$unit_price  = (float) $item_data['unit_price'];
			$subtotal    = (float) $item_data['subtotal'];
			$line_total  = (float) $item_data['line_total'];
			$off_percent = (float) $item_data['off_percent'];
			$order_item->set_product(
				$product
			);
			
			$order_item->set_quantity(
				$quantity
			);
			
			$order_item->set_subtotal(
				$subtotal
			);
			
			$order_item->set_total(
				$line_total
			);
			
			if ( $product instanceof WC_Product_Variation ) {
				$order_item->set_variation(
					$product->get_variation_attributes()
				);
			}
			
			/**
			 * متاهای سازگاری با CRM قدیمی.
			 */
			$order_item->update_meta_data(
				'line_decimal_qty',
				$quantity
			);
			
			$order_item->update_meta_data(
				'line_single_total',
				$unit_price
			);
			
			$order_item->update_meta_data(
				'off_percent',
				$off_percent
			);
			
			$note = trim(
				(string) (
					$item_data['note']
					?? ''
				)
			);
			
			if ( $note !== '' ) {
				$order_item->update_meta_data(
					'note',
					$note
				);
			} else {
				$order_item->delete_meta_data(
					'note'
				);
			}
			
			if ( $item_id <= 0 ) {
				$order->add_item(
					$order_item
				);
			}
			
			$order_item->save();
			
			$used_item_ids[] = $order_item->get_id();
			
			do_action(
				'kerp_orders_order_item_saved',
				$order_item,
				$item_data,
				$order,
				$is_new
			);
		}
		
		foreach ( $current_items as $item_id => $current_item ) {
			if (
				in_array(
					(int) $item_id,
					$used_item_ids,
					TRUE
				)
			) {
				continue;
			}
			
			$order->remove_item(
				$item_id
			);
		}
	}
	
	private function apply_shipping(
		WC_Order $order,
		string $title,
		mixed $raw_total
	): void {
		foreach (
			$order->get_items( 'shipping' )
			as $item_id => $item
		) {
			$order->remove_item(
				$item_id
			);
		}
		
		$total = $this->normalize_decimal(
			$raw_total
		);
		
		if (
			$total === NULL
			|| (float) $total <= 0
		) {
			return;
		}
		
		$title = sanitize_text_field(
			$title
		);
		
		if ( $title === '' ) {
			$title = KERP_Modules_Orders_Settings::instance()
			                                     ->get(
				                                     'general',
				                                     'default_shipping_title',
				                                     __( 'ارسال', 'kasebi-erp' )
			                                     );
		}
		
		$shipping = new WC_Order_Item_Shipping();
		
		$shipping->set_method_title(
			$title
		);
		
		$shipping->set_method_id(
			'kerp_manual_shipping'
		);
		
		$shipping->set_total(
			(float) $total
		);
		
		$order->add_item(
			$shipping
		);
	}
	
	private function apply_core_fees(
		WC_Order $order,
		array $data
	): void {
		$this->remove_kerp_fee_items(
			$order
		);
		
		$extra_fee = $this->normalize_decimal(
			$data['custom_extra_fee'] ?? ''
		);
		
		$discount = $this->normalize_decimal(
			$data['custom_fee'] ?? ''
		);
		
		$extra_fee = $extra_fee !== NULL
			? max( 0, (float) $extra_fee )
			: 0;
		
		$discount = $discount !== NULL
			? max( 0, (float) $discount )
			: 0;
		
		$order->update_meta_data(
			'custom_extra_fee',
			$extra_fee
		);
		
		$order->update_meta_data(
			'custom_fee',
			$discount
		);
		
		if ( $extra_fee > 0 ) {
			$this->add_kerp_fee(
				$order,
				'custom_extra_fee',
				__( 'افزایش مبلغ', 'kasebi-erp' ),
				$extra_fee
			);
		}
		
		if ( $discount > 0 ) {
			$this->add_kerp_fee(
				$order,
				'custom_fee',
				__( 'تخفیف سفارش', 'kasebi-erp' ),
				- $discount
			);
		}
	}
	
	public function add_kerp_fee(
		WC_Order $order,
		string $key,
		string $label,
		float $amount,
		array $meta = []
	): ?WC_Order_Item_Fee {
		$key = sanitize_key(
			$key
		);
		
		$label = sanitize_text_field(
			$label
		);
		
		if (
			$key === ''
			|| $label === ''
			|| $amount == 0
		) {
			return NULL;
		}
		
		$fee = new WC_Order_Item_Fee();
		
		$fee->set_name(
			$label
		);
		
		$fee->set_amount(
			$amount
		);
		
		$fee->set_total(
			$amount
		);
		
		$fee->set_tax_status(
			'none'
		);
		
		$fee->update_meta_data(
			'_kerp_fee_key',
			$key
		);
		
		foreach ( $meta as $meta_key => $meta_value ) {
			$meta_key = sanitize_key(
				(string) $meta_key
			);
			
			if ( $meta_key === '' ) {
				continue;
			}
			
			$fee->update_meta_data(
				$meta_key,
				$meta_value
			);
		}
		
		$order->add_item(
			$fee
		);
		
		return $fee;
	}
	
	private function remove_kerp_fee_items(
		WC_Order $order
	): void {
		foreach (
			$order->get_items( 'fee' )
			as $item_id => $fee
		) {
			if ( ! $fee instanceof WC_Order_Item_Fee ) {
				continue;
			}
			
			$fee_key = sanitize_key(
				(string) $fee->get_meta(
					'_kerp_fee_key',
					TRUE
				)
			);
			
			if ( $fee_key === '' ) {
				continue;
			}
			
			$order->remove_item(
				$item_id
			);
		}
	}
	
	private function apply_order_files(
		WC_Order $order,
		mixed $files
	): void {
		$files = $this->normalize_order_files(
			$files
		);
		
		if ( empty( $files ) ) {
			$order->delete_meta_data(
				'order_files'
			);
			
			return;
		}
		
		$order->update_meta_data(
			'order_files',
			$files
		);
	}
	
	private function normalize_order_files(
		mixed $files
	): array {
		if ( is_string( $files ) ) {
			$files = preg_split(
				'/[\r\n,]+/',
				$files,
				- 1,
				PREG_SPLIT_NO_EMPTY
			);
		}
		
		if ( ! is_array( $files ) ) {
			return [];
		}
		
		$result = [];
		
		foreach ( $files as $file ) {
			$url = is_array( $file )
				? (string) ( $file['url'] ?? '' )
				: (string) $file;
			
			$url = esc_url_raw(
				trim( $url )
			);
			
			if ( $url === '' ) {
				continue;
			}
			
			$result[ $url ] = [
				'url' => $url,
			];
		}
		
		return array_values(
			$result
		);
	}
	
	private function apply_cashier_note(
		WC_Order $order,
		string $note
	): void {
		$note = wp_kses_post(
			$note
		);
		
		$plain = trim(
			wp_strip_all_tags(
				str_replace(
					[
						'<br>',
						'<br/>',
						'<br />',
						'&nbsp;',
					],
					'',
					$note
				)
			)
		);
		
		if ( $plain === '' ) {
			$order->delete_meta_data(
				'cashier_note'
			);
			
			return;
		}
		
		$order->update_meta_data(
			'cashier_note',
			$note
		);
	}
	
	private function apply_order_date(
		WC_Order $order,
		string $date
	): void {
		$date = sanitize_text_field(
			$date
		);
		
		if ( $date === '' ) {
			return;
		}
		
		$gregorian = KERP_Helpers_Date::jalali_to_gregorian(
			$date
		);
		
		if (
			! is_string( $gregorian )
			|| $gregorian === ''
		) {
			return;
		}
		
		$current_date = $order->get_date_created();
		
		$time = $current_date
			? $current_date->format( 'H:i:s' )
			: current_datetime()->format( 'H:i:s' );
		
		try {
			$date_time = new WC_DateTime(
				$gregorian . ' ' . $time,
				wp_timezone()
			);
			
			$order->set_date_created(
				$date_time
			);
		}
		catch ( Exception $exception ) {
			return;
		}
	}
	
	public function admin_bar_items( array $items ): array {
		$items['orders'] = [
			'title' => __( 'سفارش‌ها', 'kasebi-erp' ),
			'url'   => '/erp/orders/',
		];
		
		return $items;
	}
	
}
