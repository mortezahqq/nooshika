<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Orders_Query {
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public function find( array $args = [] ): array {
		$defaults = [
			'per_page'      => 20,
			'page_number'   => 1,
			'status'        => '',
			'date'          => [ 'from' => '', 'to' => '' ],
			'search'        => '',
			'city'          => '',
			'state'         => '',
			'marketer_id'   => 0,
			'customer_id'   => 0,
			'product_id'    => 0,
			'total'         => [ 'from' => '', 'to' => '' ],
			'min_total'     => NULL,
			'max_total'     => NULL,
			'sort_order'    => 'newest',
			'order_by'      => 'date',
			'order'         => 'DESC',
			'order_id'      => 0,
			'enforce_scope' => TRUE,
			'count_total' => TRUE,
			'dashboard_batch' => FALSE,
			'before_date' => '',
			'before_order' => 0,
		];
		$args     = wp_parse_args( $args, $defaults );
		$args     = apply_filters( 'kerp_orders_query_args', $args );
		
		if ( ! is_array( $args ) ) {
			$args = $defaults;
		}
		
		$scope = ! empty( $args['enforce_scope'] ) ? kerp_list_scope( 'orders' ) : 'all';
		
		if ( $scope === 'none' ) {
			return $this->empty_result( $args );
		}
		
		if ( $scope === 'own' ) {
			$args['marketer_id'] = get_current_user_id();
		}
		
		$date = isset( $args['date'] ) && is_array( $args['date'] ) ? $args['date'] : [];
		$date = [
			'from' => $this->normalize_filter_date( (string) ( $date['from'] ?? '' ) ),
			'to'   => $this->normalize_filter_date( (string) ( $date['to'] ?? '' ) ),
		];
		
		$total     = isset( $args['total'] ) && is_array( $args['total'] ) ? $args['total'] : [];
		$min_total = $total['from'] ?? $args['min_total'] ?? NULL;
		$max_total = $total['to'] ?? $args['max_total'] ?? NULL;
		
		$sort_order = sanitize_key( (string) ( $args['sort_order'] ?? $args['sort'] ?? 'newest' ) );
		$sort_map   = KERP_Modules_Orders_List_Table::instance()->get_sort_map();
		
		if ( isset( $sort_map[ $sort_order ] ) && is_array( $sort_map[ $sort_order ] ) ) {
			$args['order_by'] = sanitize_key( (string) ( $sort_map[ $sort_order ]['order_by'] ?? 'date' ) );
			$args['order']    = strtoupper( (string) ( $sort_map[ $sort_order ]['order'] ?? 'DESC' ) ) === 'ASC' ? 'ASC' : 'DESC';
		}
		
		$utm = [];
		foreach ( KERP_Modules_Orders_List_Table::instance()->get_utm_labels() as $key => $label ) {
			$value = $args[ $key ] ?? '';
			$utm[ substr( $key, 4 ) ] = is_scalar( $value ) ? sanitize_text_field( (string) $value ) : '';
		}

		$result = KERP_Core_Order_Index::instance()->find_orders(
			[
				'per_page'    => max( 1, min( 100, absint( $args['per_page'] ?? 20 ) ) ),
				'count_total' => (bool) $args['count_total'],
				'dashboard_batch' => (bool) $args['dashboard_batch'],
				'before_date' => (string) $args['before_date'],
				'before_order' => absint( $args['before_order'] ),
				'page_number' => max( 1, absint( $args['page_number'] ?? 1 ) ),
				'status'      => $args['status'] ?: '',
				'date'        => $date,
				'search'      => sanitize_text_field( (string) ( $args['search'] ?? '' ) ),
				'city'        => sanitize_text_field( (string) ( $args['city'] ?: '' ) ),
				'state'       => sanitize_text_field( (string) ( $args['state'] ?: '' ) ),
				'marketer_id' => absint( $args['marketer_id'] ?? 0 ),
				'customer_id' => absint( $args['customer_id'] ?? 0 ),
				// Match both parent products and individual variations in the shared index.
				'product_ids' => absint( $args['product_id'] ?? 0 ) ? [ absint( $args['product_id'] ) ] : [],
				'min_total'   => $this->normalize_total( $min_total ),
				'max_total'   => $this->normalize_total( $max_total ),
				'order_by'    => sanitize_key( (string) ( $args['order_by'] ?? 'date' ) ),
				'order'       => strtoupper( (string) ( $args['order'] ?? 'DESC' ) ) === 'ASC' ? 'ASC' : 'DESC',
				'order_id'    => absint( $args['order_id'] ?? 0 ),
				'sold_product' => is_scalar( $args['sold_product'] ?? '' ) ? (string) ( $args['sold_product'] ?? '' ) : '',
				'utm'         => $utm,
				'utm_match'   => 'exact',
			]
		);
		
		$result['total'] = absint( $result['total_items'] ?? 0 );
		
		return apply_filters( 'kerp_orders_query_results', $result, $args );
	}
	
	public function get_order( int $order_id, bool $enforce_scope = TRUE ): ?WC_Order {
		$order_id = absint( $order_id );
		
		if ( $order_id <= 0 || ! function_exists( 'wc_get_order' ) ) {
			return NULL;
		}
		
		$order = wc_get_order( $order_id );
		
		if ( ! $order instanceof WC_Order ) {
			return NULL;
		}
		
		if ( $enforce_scope && ! $this->can_access_order( $order ) ) {
			return NULL;
		}
		
		return $order;
	}
	
	public function can_access_order( WC_Order|int $order ): bool {
		$order = is_int( $order ) ? wc_get_order( $order ) : $order;
		
		if ( ! $order instanceof WC_Order ) {
			return FALSE;
		}
		
		$scope = kerp_list_scope( 'orders' );
		
		if ( $scope === 'all' ) {
			return TRUE;
		}
		
		if ( $scope !== 'own' ) {
			return FALSE;
		}
		
		$marketer_id = absint( $order->get_meta( 'marketer_id', TRUE ) );
		
		if ( $marketer_id === get_current_user_id() ) {
			return TRUE;
		}
		
		$indexed = KERP_Core_Order_Index::instance()->find_orders(
			[
				'order_id'    => $order->get_id(),
				'marketer_id' => get_current_user_id(),
				'per_page'    => 1,
				'page_number' => 1,
			]
		);
		
		return ! empty( $indexed['items'] );
	}
	
	public function get_customer_options( int $limit = 500 ): array {
		$result  = KERP_Modules_Customers_Query::instance()->find(
			[
				'per_page'    => max( 1, min( 500, $limit ) ),
				'page_number' => 1,
				'orderby'     => 'display_name',
				'order'       => 'ASC',
			]
		);
		$options = [];
		
		foreach ( (array) ( $result['items'] ?? [] ) as $customer ) {
			if ( ! $customer instanceof WP_User ) {
				continue;
			}
			
			$options[ $customer->ID ] = get_user_name_by_id( $customer->ID );
		}
		
		return apply_filters( 'kerp_orders_customer_options', $options );
	}
	
	/** Unique saved attribution values, limited to the viewer's order scope. */
	public function get_utm_filter_options(): array {
		global $wpdb;
		$columns = [ 'utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content' ];
		$options = array_fill_keys( $columns, [] );
		$scope = kerp_list_scope( 'orders' );
		if ( ! in_array( $scope, [ 'all', 'own' ], TRUE ) ) return $options;
		$table = KERP_Core_Order_Index::table();
		$where = $scope === 'own' ? $wpdb->prepare( 'i.marketer_id=%d', get_current_user_id() ) : '1=1';
		if ( class_exists( '\Automattic\WooCommerce\Utilities\OrderUtil' ) && \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled() ) {
			$where .= " AND NOT EXISTS (SELECT 1 FROM {$wpdb->prefix}wc_orders o WHERE o.id=i.order_id AND o.status IN ('trash','auto-draft','wc-auto-draft','draft','wc-draft','checkout-draft','wc-checkout-draft'))";
		} else {
			$where .= " AND NOT EXISTS (SELECT 1 FROM {$wpdb->posts} p WHERE p.ID=i.order_id AND p.post_type='shop_order' AND p.post_status IN ('trash','auto-draft','wc-auto-draft','draft','wc-draft','checkout-draft','wc-checkout-draft'))";
		}
		$queries = [];
		// Column identifiers come only from this fixed allowlist; no order hydration.
		foreach ( $columns as $column ) $queries[] = "SELECT '{$column}' field_key, i.{$column} value FROM {$table} i WHERE {$where} AND i.{$column} IS NOT NULL AND TRIM(i.{$column}) <> '' GROUP BY i.{$column}";
		foreach ( (array) $wpdb->get_results( implode( ' UNION ALL ', $queries ), ARRAY_A ) as $row ) {
			if ( isset( $options[ $row['field_key'] ] ) ) $options[ $row['field_key'] ][ (string) $row['value'] ] = (string) $row['value'];
		}
		foreach ( $options as &$choices ) asort( $choices, SORT_NATURAL | SORT_FLAG_CASE );
		unset( $choices );
		return $options;
	}

	public function get_marketer_options(): array {
		global $wpdb;
		
		$table    = KERP_Core_Order_Index::table();
		$user_ids = $wpdb->get_col(
			"SELECT DISTINCT marketer_id
			FROM {$table}
			WHERE marketer_id > 0
			ORDER BY marketer_id ASC
			LIMIT 500"
		);
		$options  = [];
		
		foreach ( (array) $user_ids as $user_id ) {
			$user_id = absint( $user_id );
			
			if ( $user_id <= 0 || ! get_userdata( $user_id ) instanceof WP_User ) {
				continue;
			}
			
			$options[ $user_id ] = get_user_name_by_id( $user_id );
		}
		
		asort( $options, SORT_NATURAL | SORT_FLAG_CASE );
		
		return apply_filters( 'kerp_orders_marketer_options', $options );
	}
	
	public function get_indexed_product_options( int $limit = 300 ): array {
		global $wpdb;
		
		$table   = KERP_Core_Order_Index::table();
		$rows    = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT product_id, variation_id
				FROM {$table}
				WHERE product_id > 0
				GROUP BY product_id, variation_id
				ORDER BY MAX(date_created_gmt) DESC
				LIMIT %d",
				max( 1, min( 1000, $limit ) )
			),
			ARRAY_A
		);
		$options = [];
		
		foreach ( (array) $rows as $row ) {
			$product_id = absint( $row['variation_id'] ?? 0 ) ?: absint( $row['product_id'] ?? 0 );
			$product    = wc_get_product( $product_id );
			
			if ( ! $product instanceof WC_Product ) {
				continue;
			}
			
			$options[ $product_id ] = $product->get_formatted_name();
		}
		
		return apply_filters( 'kerp_orders_indexed_product_options', $options );
	}
	
	private function normalize_filter_date( string $date ): string {
		$date = sanitize_text_field( $date );
		$date = (string) KERP_Helpers_Format::sanitize_numbers( $date );
		$date = trim( str_replace( [ '/', '.', '\\' ], '-', $date ) );
		
		if ( $date === '' ) {
			return '';
		}
		
		$parts = explode( '-', $date );
		$year  = isset( $parts[0] ) ? absint( $parts[0] ) : 0;
		
		if ( $year > 0 && $year < 1700 ) {
			$converted = KERP_Helpers_Date::jalali_to_gregorian( $date );
			
			if ( is_string( $converted ) && $converted !== '' ) {
				return $converted;
			}
		}
		
		return $date;
	}
	
	private function normalize_total( mixed $value ): ?float {
		if ( $value === NULL || $value === '' ) {
			return NULL;
		}
		
		$value = (string) KERP_Helpers_Format::sanitize_numbers( (string) $value );
		$value = preg_replace( '/[^0-9.\-]/', '', $value );
		
		return is_numeric( $value ) ? (float) $value : NULL;
	}
	
	private function empty_result( array $args ): array {
		return [
			'items'       => [],
			'total_items' => 0,
			'total'       => 0,
			'total_pages' => 0,
			'page_number' => max( 1, absint( $args['page_number'] ?? 1 ) ),
			'per_page'    => max( 1, min( 100, absint( $args['per_page'] ?? 20 ) ) ),
		];
	}
	
}
