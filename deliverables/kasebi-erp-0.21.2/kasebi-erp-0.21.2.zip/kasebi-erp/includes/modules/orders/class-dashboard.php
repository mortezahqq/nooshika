<?php

defined( 'ABSPATH' ) || exit;

/** Permission-scoped SQL aggregates over the ERP order index. */
final class KERP_Modules_Orders_Dashboard {
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		return self::$instance ??= new self();
	}
	
	private function __construct() {
		add_filter( 'kerp_dashboard_blocks', [ $this, 'register_blocks' ] );
	}
	
	public function register_blocks( array $blocks ): array {
		$position = 40;
		foreach (
			[
				'trend'    => 'روند سفارش‌ها',
				'statuses' => 'وضعیت سفارش‌ها',
				'products' => 'محصولات پرفروش',
				'recent'   => 'آخرین سفارش‌ها',
			] as $key => $title
		) {
			$blocks[ 'orders-' . $key ] = [
				'title'           => $title,
				'position'        => $position ++,
				'width'           => in_array( $key, [ 'trend', 'recent' ], TRUE ) ? 8 : 4,
				'module'          => 'orders',
				'permission'      => 'orders.view',
				'permission_type' => 'view',
				'async'           => TRUE,
				'callback'        => [ $this, 'render' ],
			];
		}
		
		return $blocks;
	}
	
	public function render( array $context, array $block ): void {
		if ( ! kerp_can( 'orders.view', 'view' ) || kerp_list_scope( 'orders' ) === 'none' ) {
			return;
		}
		KERP_Helpers_Template::render_template( 'modules/orders/partials/dashboard.php', [
			'kind'  => substr( $block['id'], strlen( 'orders-' ) ),
			'stats' => $this->get_data(),
		] );
	}
	
	public function get_data(): array {
		// Check access before using request-local cached data as well as before querying.
		$data = [
			'daily'    => [],
			'statuses' => [],
			'products' => [],
			'recent'   => [],
			'total'    => 0,
			'paid'     => 0,
			'amounts'  => [],
		];
		if ( ! kerp_can( 'orders.view', 'view' ) || kerp_list_scope( 'orders' ) === 'none' ) {
			return $data;
		}
		
		return KERP_Helpers_Dashboard_Cache::remember( 'orders-v4', [ $this, 'collect' ] );
	}
	
	public function collect( array $state ): array {
        global $wpdb;
        $data = [ 'daily' => [], 'statuses' => [], 'products' => [], 'recent' => [], 'total' => 0, 'paid' => 0, 'amounts' => [] ];
        $scope = kerp_list_scope( 'orders' );
        if ( ! kerp_can( 'orders.view', 'view' ) || ! in_array( $scope, [ 'all', 'own' ], TRUE ) ) {
            return [ 'done' => TRUE, 'data' => $data ];
        }
        $now = ( new DateTimeImmutable( $state['as_of'] ) )->setTimezone( wp_timezone() );
        $start = $now->setTime( 0, 0 )->modify( '-29 days' );
        $utc = new DateTimeZone( 'UTC' );
        $table = KERP_Core_Order_Index::table();
        $where = 'i.date_created_gmt >= %s AND i.date_created_gmt <= %s';
        $values = [ $start->setTimezone( $utc )->format( 'Y-m-d H:i:s' ), $now->setTimezone( $utc )->format( 'Y-m-d H:i:s' ) ];
        if ( $scope === 'own' ) {
            $where .= ' AND i.marketer_id = %d';
            $values[] = get_current_user_id();
        }
        // A trashed order may still have its former status in the index.
        if ( class_exists( '\Automattic\WooCommerce\Utilities\OrderUtil' )
            && \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled() ) {
            $where .= " AND NOT EXISTS (SELECT 1 FROM {$wpdb->prefix}wc_orders live_order WHERE live_order.id = i.order_id AND live_order.status = 'trash')";
        } else {
            $where .= " AND NOT EXISTS (SELECT 1 FROM {$wpdb->posts} live_order WHERE live_order.ID = i.order_id AND live_order.post_type = 'shop_order' AND live_order.post_status = 'trash')";
        }
        $read = static function( string $sql, array $params ) use ( $wpdb ): array {
            $rows = $wpdb->get_results( $wpdb->prepare( $sql, ...$params ), ARRAY_A );
            if ( $wpdb->last_error ) { throw new RuntimeException( 'Order dashboard aggregate query failed: ' . $wpdb->last_error ); }
            return (array) $rows;
        };

        // Only pre-upgrade rows need one-time enrichment, never the normal chart path.
        $legacy = $read( "SELECT DISTINCT i.order_id, i.dashboard_version FROM {$table} i
            WHERE {$where} AND i.dashboard_version <> 1 LIMIT 25", $values );
        if ( $legacy ) {
            $prepared = KERP_Core_Order_Index::instance()->prepare_dashboard_rows( $legacy, microtime( TRUE ) + 1.5 );
            return [ 'done' => FALSE, 'prepared' => (int) ( $state['prepared'] ?? 0 ) + $prepared ];
        }

        // One order can occupy several item rows: amounts must be deduplicated first.
        $orders = "SELECT i.order_id, MAX(i.currency) AS currency,
            MAX(i.dashboard_paid) AS paid, MAX(i.dashboard_is_parent) AS is_parent,
            MAX(i.dashboard_net_total) AS net_total
            FROM {$table} i WHERE {$where} GROUP BY i.order_id";
        $totals = $read( "SELECT COUNT(*) AS total,
            COALESCE(SUM(CASE WHEN paid = 1 AND is_parent = 0 THEN 1 ELSE 0 END), 0) AS paid
            FROM ({$orders}) orders", $values );
        $data['total'] = (int) ( $totals[0]['total'] ?? 0 );
        $data['paid'] = (int) ( $totals[0]['paid'] ?? 0 );
        foreach ( $read( "SELECT currency, SUM(net_total) AS amount FROM ({$orders}) orders
            WHERE paid = 1 AND is_parent = 0 GROUP BY currency", $values ) as $row ) {
            $data['amounts'][ $row['currency'] ] = (float) $row['amount'];
        }

        // UTC ranges are generated from local midnights, including timezone transitions.
        // No dependence on MySQL's optional named timezone tables or fixed UTC offsets.
        $day_cases = [];
        $day_values = [];
        for ( $day = $start; $day <= $now; $day = $day->modify( '+1 day' ) ) {
            $label = $day->format( 'Y-m-d' );
            $data['daily'][ $label ] = 0;
            $day_cases[] = 'WHEN i.date_created_gmt >= %s AND i.date_created_gmt < %s THEN %s';
            array_push( $day_values, $day->setTimezone( $utc )->format( 'Y-m-d H:i:s' ),
                $day->modify( '+1 day' )->setTimezone( $utc )->format( 'Y-m-d H:i:s' ), $label );
        }
        $day_sql = 'CASE ' . implode( ' ', $day_cases ) . ' END';
        foreach ( $read( "SELECT {$day_sql} AS local_day, COUNT(DISTINCT i.order_id) AS total
            FROM {$table} i WHERE {$where} GROUP BY local_day", array_merge( $day_values, $values ) ) as $row ) {
            if ( isset( $data['daily'][ $row['local_day'] ] ) ) { $data['daily'][ $row['local_day'] ] = (int) $row['total']; }
        }
        foreach ( $read( "SELECT i.status, COUNT(DISTINCT i.order_id) AS total FROM {$table} i
            WHERE {$where} GROUP BY i.status ORDER BY total DESC, i.status", $values ) as $row ) {
            $data['statuses'][ str_replace( 'wc-', '', $row['status'] ) ] = (int) $row['total'];
        }
        $product_key = "CASE WHEN i.variation_id > 0 THEN CONCAT('product-', i.variation_id)
            WHEN i.product_id > 0 THEN CONCAT('product-', i.product_id)
            ELSE CONCAT('deleted-', MD5(COALESCE(i.dashboard_item_name, ''))) END";
        foreach ( $read( "SELECT {$product_key} AS product_key, MAX(i.dashboard_item_name) AS label,
            SUM(i.dashboard_item_qty) AS quantity FROM {$table} i
            WHERE {$where} AND i.dashboard_paid = 1 AND i.dashboard_is_parent = 0
                AND i.order_item_id > 0 AND i.dashboard_item_qty > 0
            GROUP BY product_key ORDER BY quantity DESC, product_key LIMIT 5", $values ) as $row ) {
            $data['products'][ $row['product_key'] ] = [ 'label' => $row['label'], 'quantity' => (float) $row['quantity'] ];
        }
        // Only the three visible cards need individual rows; chart queries return aggregates.
        $recent = $read( "SELECT i.order_id, MAX(i.date_created_gmt) AS date_created_gmt,
            MAX(i.customer_id) AS customer_id, MAX(i.status) AS status,
            MAX(i.billing_first_name) AS billing_first_name, MAX(i.billing_last_name) AS billing_last_name
            FROM {$table} i WHERE {$where} GROUP BY i.order_id
            ORDER BY date_created_gmt DESC, i.order_id DESC LIMIT 3", $values );
        $data['recent'] = $recent;
        return [ 'done' => TRUE, 'data' => $data ];
    }
}
