<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Orders_Settings {
	
	public const OPTION_NAME = 'kerp_orders_settings';
	
	private static ?self $instance = NULL;
	private ?array       $settings = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {
		add_action( 'update_option_' . self::OPTION_NAME, [ $this, 'clear_cache' ], 10, 0 );
		add_action( 'add_option_' . self::OPTION_NAME, [ $this, 'clear_cache' ], 10, 0 );
		add_action( 'init', [ $this, 'register_custom_order_statuses' ], 20 );
		add_filter( 'wc_order_statuses', [ $this, 'filter_wc_order_statuses' ], 20 );
		add_filter( 'kerp_orders_print_actions', [ $this, 'filter_print_actions' ], 20, 2 );
		add_filter( 'kerp_orders_print_templates', [ $this, 'filter_print_templates' ], 20, 2 );
		add_filter( 'kerp_orders_print_seller_data', [ $this, 'filter_print_seller_data' ], 20, 3 );
		
		if ( did_action( 'init' ) ) {
			$this->register_custom_order_statuses();
		}
	}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public function register_custom_order_statuses(): void {
		foreach ( $this->get_raw_custom_statuses() as $status_key => $status ) {
			$post_status = 'wc-' . $status_key;
			$label       = sanitize_text_field( (string) ( $status['label'] ?? $status_key ) );
			
			if ( $label === '' || get_post_status_object( $post_status ) ) {
				continue;
			}
			
			register_post_status(
				$post_status,
				[
					'label'                     => $label,
					'public'                    => FALSE,
					'exclude_from_search'       => FALSE,
					'show_in_admin_all_list'    => TRUE,
					'show_in_admin_status_list' => TRUE,
					'label_count'               => _n_noop(
						$label . ' <span class=\"count\">(%s)</span>',
						$label . ' <span class=\"count\">(%s)</span>',
						'kasebi-erp'
					),
				]
			);
		}
	}
	
	public function filter_wc_order_statuses( array $statuses ): array {
		foreach ( $this->get_raw_custom_statuses() as $status_key => $status ) {
			$label = sanitize_text_field( (string) ( $status['label'] ?? $status_key ) );
			
			if ( $label === '' ) {
				continue;
			}
			
			$statuses[ 'wc-' . $status_key ] = $label;
		}
		
		return $statuses;
	}
	
	public function defaults(): array {
		$defaults = [
			'general'  => [
				'default_status'         => 'pending',
				'default_payment_method' => '',
				'default_shipping_title' => __( 'ارسال', 'kasebi-erp' ),
				'default_per_page'       => 20,
				'default_unit'           => 'piece',
			],
			'units'    => $this->default_units(),
			'statuses' => $this->default_statuses(),
			'deferred' => [
				'enabled'               => 0,
				'default_due_days'      => 30,
				'default_due_time'      => '17:00',
				'allow_manual_due_date' => 1,
			],
			'print'    => [
				'seller' => $this->default_seller_data(),
				'types'  => $this->default_print_types(),
			],
		];
		
		return apply_filters( 'kerp_orders_default_settings', $defaults );
	}
	
	public function all(): array {
		if ( $this->settings !== NULL ) {
			return $this->settings;
		}
		
		$defaults = $this->defaults();
		$stored   = get_option( self::OPTION_NAME, NULL );
		$stored   = is_array( $stored ) ? $stored : [];
		
		$general = isset( $stored['general'] ) && is_array( $stored['general'] )
			? array_merge( $defaults['general'], $stored['general'] )
			: $defaults['general'];
		
		$units = array_key_exists( 'units', $stored ) && is_array( $stored['units'] )
			? $stored['units']
			: $defaults['units'];
		
		$stored_statuses = isset( $stored['statuses'] ) && is_array( $stored['statuses'] )
			? $stored['statuses']
			: [];
		$status_defaults = $this->default_statuses();
		$statuses        = [];
		
		foreach ( $status_defaults as $status_key => $status_default ) {
			$statuses[ $status_key ] = isset( $stored_statuses[ $status_key ] ) && is_array( $stored_statuses[ $status_key ] )
				? array_merge( $status_default, $stored_statuses[ $status_key ] )
				: $status_default;
		}
		
		foreach ( $stored_statuses as $status_key => $stored_status ) {
			if ( ! is_array( $stored_status ) || empty( $stored_status['custom'] ) ) {
				continue;
			}
			
			$status_key = $this->normalize_status_key( (string) $status_key );
			
			if ( $status_key === '' || isset( $statuses[ $status_key ] ) ) {
				continue;
			}
			
			$statuses[ $status_key ] = $stored_status;
		}
		
		$deferred = isset( $stored['deferred'] ) && is_array( $stored['deferred'] )
			? array_merge( $defaults['deferred'], $stored['deferred'] )
			: $defaults['deferred'];
		
		$stored_print       = isset( $stored['print'] ) && is_array( $stored['print'] )
			? $stored['print']
			: [];
		$print_seller       = isset( $stored_print['seller'] ) && is_array( $stored_print['seller'] )
			? array_merge( $defaults['print']['seller'], $stored_print['seller'] )
			: $defaults['print']['seller'];
		$stored_print_types = isset( $stored_print['types'] ) && is_array( $stored_print['types'] )
			? $stored_print['types']
			: [];
		$print_types        = [];
		
		foreach ( $defaults['print']['types'] as $type_key => $type_default ) {
			$print_types[ $type_key ] = isset( $stored_print_types[ $type_key ] ) && is_array( $stored_print_types[ $type_key ] )
				? array_merge( $type_default, $stored_print_types[ $type_key ] )
				: $type_default;
		}
		
		$this->settings = $this->sanitize(
			[
				'general'  => $general,
				'units'    => $units,
				'statuses' => $statuses,
				'deferred' => $deferred,
				'print'    => [
					'seller' => $print_seller,
					'types'  => $print_types,
				],
			]
		);
		
		return $this->settings;
	}
	
	public function get( string $section, string $key = '', mixed $default = NULL ): mixed {
		$settings = $this->all();
		
		if ( ! array_key_exists( $section, $settings ) ) {
			return $default;
		}
		
		if ( $key === '' ) {
			return $settings[ $section ];
		}
		
		if ( ! is_array( $settings[ $section ] ) || ! array_key_exists( $key, $settings[ $section ] ) ) {
			return $default;
		}
		
		return $settings[ $section ][ $key ];
	}
	
	public function update_general( array $general ): bool {
		$settings            = $this->all();
		$settings['general'] = array_merge( $settings['general'], $general );
		
		return $this->save_all( $settings );
	}
	
	public function update_deferred( array $deferred ): bool {
		$settings             = $this->all();
		$settings['deferred'] = array_merge( $settings['deferred'], $deferred );
		
		return $this->save_all( $settings );
	}
	
	public function update_print( array $print ): bool {
		$settings = $this->all();
		
		if ( isset( $print['seller'] ) && is_array( $print['seller'] ) ) {
			$settings['print']['seller'] = array_merge(
				$settings['print']['seller'],
				$print['seller']
			);
		}
		
		if ( isset( $print['types'] ) && is_array( $print['types'] ) ) {
			foreach ( $print['types'] as $type_key => $type ) {
				$type_key = sanitize_key( (string) $type_key );
				
				if ( $type_key === '' || ! is_array( $type ) || ! isset( $settings['print']['types'][ $type_key ] ) ) {
					continue;
				}
				
				$settings['print']['types'][ $type_key ] = array_merge(
					$settings['print']['types'][ $type_key ],
					$type
				);
			}
		}
		
		return $this->save_all( $settings );
	}
	
	public function get_units( bool $active_only = FALSE ): array {
		$units = (array) $this->get( 'units', '', [] );
		
		if ( $active_only ) {
			foreach ( $units as $unit_key => $unit ) {
				if ( ! is_array( $unit ) || empty( $unit['active'] ) ) {
					unset( $units[ $unit_key ] );
				}
			}
		}
		
		uasort( $units, [ $this, 'sort_by_order' ] );
		
		return apply_filters( 'kerp_orders_units', $units, $active_only );
	}
	
	public function get_unit( string $unit_key ): ?array {
		$unit_key = sanitize_key( $unit_key );
		$units    = $this->get_units();
		
		return isset( $units[ $unit_key ] ) && is_array( $units[ $unit_key ] )
			? $units[ $unit_key ]
			: NULL;
	}
	
	public function get_unit_options( bool $active_only = TRUE ): array {
		$options = [];
		
		foreach ( $this->get_units( $active_only ) as $unit_key => $unit ) {
			$options[ $unit_key ] = (string) ( $unit['label'] ?? $unit_key );
		}
		
		return $options;
	}
	
	public function get_default_unit(): string {
		$default_unit = sanitize_key( (string) $this->get( 'general', 'default_unit', 'piece' ) );
		$units        = $this->get_units( TRUE );
		
		if ( isset( $units[ $default_unit ] ) ) {
			return $default_unit;
		}
		
		$first_key = array_key_first( $units );
		
		return is_string( $first_key ) ? $first_key : '';
	}
	
	public function save_unit( array $unit, string $original_key = '' ): bool|WP_Error {
		$original_key = sanitize_key( $original_key );
		$clean        = $this->sanitize_unit( $unit );
		$unit_key     = $clean['key'];
		
		if ( $unit_key === '' ) {
			return new WP_Error( 'kerp_order_unit_missing_key', __( 'کلید واحد را وارد کنید.', 'kasebi-erp' ) );
		}
		
		if ( $clean['label'] === '' ) {
			return new WP_Error( 'kerp_order_unit_missing_label', __( 'عنوان واحد را وارد کنید.', 'kasebi-erp' ) );
		}
		
		$settings = $this->all();
		$units    = $settings['units'];
		
		if ( $original_key !== '' && $original_key !== $unit_key && isset( $units[ $unit_key ] ) ) {
			return new WP_Error( 'kerp_order_unit_duplicate', __( 'واحد دیگری با این کلید وجود دارد.', 'kasebi-erp' ) );
		}
		
		if ( $original_key !== '' && $original_key !== $unit_key ) {
			unset( $units[ $original_key ] );
			
			if ( $settings['general']['default_unit'] === $original_key ) {
				$settings['general']['default_unit'] = $unit_key;
			}
		}
		
		$units[ $unit_key ] = $clean;
		$settings['units']  = $units;
		
		$this->save_all( $settings );
		do_action( 'kerp_orders_unit_saved', $unit_key, $clean, $original_key );
		
		return TRUE;
	}
	
	public function delete_unit( string $unit_key ): bool|WP_Error {
		$unit_key = sanitize_key( $unit_key );
		$settings = $this->all();
		
		if ( $unit_key === '' || ! isset( $settings['units'][ $unit_key ] ) ) {
			return TRUE;
		}
		
		if ( $settings['general']['default_unit'] === $unit_key ) {
			return new WP_Error( 'kerp_order_unit_is_default', __( 'ابتدا واحد پیش‌فرض سفارش را تغییر دهید.', 'kasebi-erp' ) );
		}
		
		if ( count( $settings['units'] ) <= 1 ) {
			return new WP_Error( 'kerp_order_unit_last_item', __( 'حداقل یک واحد باید باقی بماند.', 'kasebi-erp' ) );
		}
		
		unset( $settings['units'][ $unit_key ] );
		$this->save_all( $settings );
		do_action( 'kerp_orders_unit_deleted', $unit_key );
		
		return TRUE;
	}
	
	public function get_statuses( bool $active_only = FALSE ): array {
		$statuses = (array) $this->get( 'statuses', '', [] );
		
		if ( $active_only ) {
			foreach ( $statuses as $status_key => $status ) {
				if ( ! is_array( $status ) || empty( $status['active'] ) ) {
					unset( $statuses[ $status_key ] );
				}
			}
		}
		
		uasort( $statuses, [ $this, 'sort_by_order' ] );
		
		return apply_filters( 'kerp_orders_statuses', $statuses, $active_only );
	}
	
	public function get_status( string $status_key ): ?array {
		$status_key = $this->normalize_status_key( $status_key );
		$statuses   = $this->get_statuses();
		
		return isset( $statuses[ $status_key ] ) && is_array( $statuses[ $status_key ] )
			? $statuses[ $status_key ]
			: NULL;
	}
	
	public function get_status_options( bool $active_only = FALSE ): array {
		$options = [];
		
		foreach ( $this->get_statuses( $active_only ) as $status_key => $status ) {
			$options[ $status_key ] = (string) ( $status['label'] ?? $status_key );
		}
		
		return $options;
	}
	
	public function get_status_label( string $status_key ): string {
		$status_key = $this->normalize_status_key( $status_key );
		$status     = $this->get_status( $status_key );
		
		return is_array( $status ) && trim( (string) ( $status['label'] ?? '' ) ) !== ''
			? (string) $status['label']
			: wc_get_order_status_name( $status_key );
	}
	
	public function get_status_color( string $status_key ): string {
		$status_key = $this->normalize_status_key( $status_key );
		$status     = $this->get_status( $status_key );
		$color      = is_array( $status ) ? sanitize_key( (string) ( $status['color'] ?? 'secondary' ) ) : 'secondary';
		
		return $color !== '' ? $color : 'secondary';
	}
	
	public function get_allowed_next_statuses( string $current_status ): array {
		$current_status = $this->normalize_status_key( $current_status );
		$statuses       = $this->get_statuses();
		$transitions    = [];
		
		foreach ( $statuses as $status_key => $status ) {
			$transitions[ $status_key ] = is_array( $status['allowed_next'] ?? NULL )
				? $status['allowed_next']
				: [];
		}
		
		$transitions     = apply_filters( 'kerp_orders_status_transitions', $transitions );
		$transitions     = is_array( $transitions ) ? $transitions : [];
		$allowed         = isset( $transitions[ $current_status ] ) && is_array( $transitions[ $current_status ] )
			? $transitions[ $current_status ]
			: [];
		$active_statuses = $this->get_statuses( TRUE );
		$result          = [];
		
		foreach ( $allowed as $status_key ) {
			$status_key = $this->normalize_status_key( (string) $status_key );
			
			if ( $status_key === '' || $status_key === $current_status || ! isset( $active_statuses[ $status_key ] ) ) {
				continue;
			}
			
			$result[ $status_key ] = (string) ( $active_statuses[ $status_key ]['label'] ?? $status_key );
		}
		
		return apply_filters( 'kerp_orders_allowed_next_statuses', $result, $current_status );
	}
	
	public function get_default_status(): string {
		$default_status = $this->normalize_status_key( (string) $this->get( 'general', 'default_status', 'pending' ) );
		$active         = $this->get_statuses( TRUE );
		
		if ( isset( $active[ $default_status ] ) ) {
			return $default_status;
		}
		
		$first_key = array_key_first( $active );
		
		return is_string( $first_key ) ? $first_key : 'pending';
	}
	
	public function save_status( array $status ): bool|WP_Error {
		$status_key = $this->normalize_status_key( (string) ( $status['key'] ?? '' ) );
		
		if ( $status_key === '' ) {
			return new WP_Error( 'kerp_order_status_missing_key', __( 'کلید وضعیت را وارد کنید.', 'kasebi-erp' ) );
		}
		
		if ( strlen( 'wc-' . $status_key ) > 20 ) {
			return new WP_Error( 'kerp_order_status_key_too_long', __( 'کلید وضعیت حداکثر می‌تواند 17 کاراکتر باشد.', 'kasebi-erp' ) );
		}
		
		$statuses = $this->get_statuses();
		$is_new   = ! isset( $statuses[ $status_key ] );
		
		if ( $is_new ) {
			$woocommerce_statuses = function_exists( 'wc_get_order_statuses' )
				? wc_get_order_statuses()
				: [];
			
			if ( isset( $woocommerce_statuses[ 'wc-' . $status_key ] ) ) {
				return new WP_Error( 'kerp_order_status_duplicate', __( 'وضعیتی با این کلید قبلاً در ووکامرس ثبت شده است.', 'kasebi-erp' ) );
			}
			
			$current_orders = array_column( $statuses, 'order' );
			$base           = [
				'key'          => $status_key,
				'label'        => '',
				'color'        => 'secondary',
				'order'        => ! empty( $current_orders ) ? max( array_map( 'absint', $current_orders ) ) + 10 : 10,
				'active'       => 1,
				'custom'       => 1,
				'allowed_next' => [],
			];
		} else {
			$base             = $statuses[ $status_key ];
			$status['custom'] = ! empty( $base['custom'] ) ? 1 : 0;
		}
		
		$clean = $this->sanitize_status(
			$status_key,
			array_merge( $base, $status )
		);
		
		if ( $clean['label'] === '' ) {
			return new WP_Error( 'kerp_order_status_missing_label', __( 'عنوان وضعیت را وارد کنید.', 'kasebi-erp' ) );
		}
		
		$settings                            = $this->all();
		$settings['statuses'][ $status_key ] = $clean;
		$this->save_all( $settings );
		
		if ( ! empty( $clean['custom'] ) ) {
			$this->register_custom_order_statuses();
		}
		
		do_action( 'kerp_orders_status_settings_saved', $status_key, $clean, $is_new );
		
		return TRUE;
	}
	
	public function get_deferred_settings(): array {
		$deferred = (array) $this->get( 'deferred', '', [] );
		
		return apply_filters( 'kerp_orders_deferred_settings', $deferred );
	}
	
	public function get_print_settings(): array {
		return (array) $this->get( 'print', '', [] );
	}
	
	public function get_print_types( bool $enabled_only = FALSE ): array {
		$print = $this->get_print_settings();
		$types = isset( $print['types'] ) && is_array( $print['types'] ) ? $print['types'] : [];
		
		if ( $enabled_only ) {
			foreach ( $types as $type_key => $type ) {
				if ( ! is_array( $type ) || empty( $type['enabled'] ) ) {
					unset( $types[ $type_key ] );
				}
			}
		}
		
		uasort( $types, [ $this, 'sort_by_order' ] );
		
		return apply_filters( 'kerp_orders_print_types', $types, $enabled_only );
	}
	
	public function filter_print_actions( array $actions, WC_Order $order ): array {
		$order_id = $order->get_id();
		
		foreach ( $this->get_print_types() as $type_key => $type ) {
			if ( empty( $type['enabled'] ) ) {
				unset( $actions[ $type_key ] );
				continue;
			}
			
			$actions[ $type_key ] = [
				'label'  => (string) ( $type['label'] ?? $type_key ),
				'icon'   => (string) ( $type['icon'] ?? 'ni ni-printer' ),
				'href'   => add_query_arg(
					[
						'action'     => 'print',
						'order_id'   => $order_id,
						'print_type' => $type_key,
					],
					'/erp/orders/'
				),
				'target' => '_blank',
				'order'  => absint( $type['order'] ?? 100 ),
			];
		}
		
		uasort( $actions, [ $this, 'sort_by_order' ] );
		
		return $actions;
	}
	
	public function filter_print_templates( array $templates, WC_Order $order ): array {
		$enabled_types = $this->get_print_types( TRUE );
		
		foreach ( array_keys( $templates ) as $type_key ) {
			if ( ! isset( $enabled_types[ $type_key ] ) ) {
				unset( $templates[ $type_key ] );
			}
		}
		
		return $templates;
	}
	
	public function filter_print_seller_data( array $seller, WC_Order $order, string $print_type ): array {
		$print       = $this->get_print_settings();
		$seller_data = isset( $print['seller'] ) && is_array( $print['seller'] ) ? $print['seller'] : [];
		
		return array_merge( $seller, $seller_data );
	}
	
	public function sanitize( array $settings ): array {
		$defaults = $this->defaults();
		$general  = isset( $settings['general'] ) && is_array( $settings['general'] ) ? $settings['general'] : [];
		$units    = isset( $settings['units'] ) && is_array( $settings['units'] ) ? $settings['units'] : [];
		$statuses = isset( $settings['statuses'] ) && is_array( $settings['statuses'] ) ? $settings['statuses'] : [];
		$deferred = isset( $settings['deferred'] ) && is_array( $settings['deferred'] ) ? $settings['deferred'] : [];
		$print    = isset( $settings['print'] ) && is_array( $settings['print'] ) ? $settings['print'] : [];
		
		$clean_units = [];
		foreach ( $units as $unit_key => $unit ) {
			if ( ! is_array( $unit ) ) {
				continue;
			}
			
			$unit['key'] = $unit['key'] ?? $unit_key;
			$clean_unit  = $this->sanitize_unit( $unit );
			
			if ( $clean_unit['key'] !== '' ) {
				$clean_units[ $clean_unit['key'] ] = $clean_unit;
			}
		}
		
		if ( empty( $clean_units ) ) {
			$clean_units = $this->default_units();
		}
		
		$clean_statuses  = [];
		$status_defaults = $this->default_statuses();
		
		foreach ( $status_defaults as $status_key => $status_default ) {
			$status_data                   = isset( $statuses[ $status_key ] ) && is_array( $statuses[ $status_key ] )
				? array_merge( $status_default, $statuses[ $status_key ] )
				: $status_default;
			$clean_statuses[ $status_key ] = $this->sanitize_status( $status_key, $status_data );
		}
		
		foreach ( $statuses as $status_key => $status ) {
			if ( ! is_array( $status ) ) {
				continue;
			}
			
			$status_key = $this->normalize_status_key( (string) $status_key );
			
			if ( $status_key === '' || isset( $clean_statuses[ $status_key ] ) || empty( $status['custom'] ) ) {
				continue;
			}
			
			$clean_statuses[ $status_key ] = $this->sanitize_status(
				$status_key,
				array_merge(
					[
						'key'          => $status_key,
						'label'        => $status_key,
						'color'        => 'secondary',
						'order'        => 100,
						'active'       => 1,
						'custom'       => 1,
						'allowed_next' => [],
					],
					$status
				)
			);
		}
		
		$default_unit = sanitize_key( (string) ( $general['default_unit'] ?? $defaults['general']['default_unit'] ) );
		if ( ! isset( $clean_units[ $default_unit ] ) || empty( $clean_units[ $default_unit ]['active'] ) ) {
			$default_unit = '';
			foreach ( $clean_units as $unit_key => $unit ) {
				if ( ! empty( $unit['active'] ) ) {
					$default_unit = $unit_key;
					break;
				}
			}
		}
		
		$default_status = $this->normalize_status_key( (string) ( $general['default_status'] ?? $defaults['general']['default_status'] ) );
		if ( ! isset( $clean_statuses[ $default_status ] ) || empty( $clean_statuses[ $default_status ]['active'] ) ) {
			$default_status = '';
			foreach ( $clean_statuses as $status_key => $status ) {
				if ( ! empty( $status['active'] ) ) {
					$default_status = $status_key;
					break;
				}
			}
		}
		
		$clean_print_types = [];
		$print_types       = isset( $print['types'] ) && is_array( $print['types'] ) ? $print['types'] : [];
		foreach ( $this->default_print_types() as $type_key => $type_default ) {
			$type                           = isset( $print_types[ $type_key ] ) && is_array( $print_types[ $type_key ] )
				? array_merge( $type_default, $print_types[ $type_key ] )
				: $type_default;
			$clean_print_types[ $type_key ] = $this->sanitize_print_type( $type_key, $type );
		}
		
		$seller = isset( $print['seller'] ) && is_array( $print['seller'] ) ? $print['seller'] : [];
		
		$clean = [
			'general'  => [
				'default_status'         => $default_status ?: 'pending',
				'default_payment_method' => sanitize_key( (string) ( $general['default_payment_method'] ?? '' ) ),
				'default_shipping_title' => sanitize_text_field( (string) ( $general['default_shipping_title'] ?? $defaults['general']['default_shipping_title'] ) ),
				'default_per_page'       => max( 1, min( 200, absint( $general['default_per_page'] ?? 20 ) ) ),
				'default_unit'           => $default_unit,
			],
			'units'    => $clean_units,
			'statuses' => $clean_statuses,
			'deferred' => [
				'enabled'               => $this->sanitize_bool( $deferred['enabled'] ?? 0 ),
				'default_due_days'      => max( 0, min( 3650, absint( $deferred['default_due_days'] ?? 30 ) ) ),
				'default_due_time'      => $this->sanitize_time( (string) ( $deferred['default_due_time'] ?? '17:00' ) ),
				'allow_manual_due_date' => $this->sanitize_bool( $deferred['allow_manual_due_date'] ?? 1 ),
			],
			'print'    => [
				'seller' => [
					'name'          => sanitize_text_field( (string) ( $seller['name'] ?? $defaults['print']['seller']['name'] ) ),
					'phone'         => sanitize_text_field( (string) ( $seller['phone'] ?? '' ) ),
					'address'       => sanitize_textarea_field( (string) ( $seller['address'] ?? $defaults['print']['seller']['address'] ) ),
					'postal_code'   => sanitize_text_field( (string) ( $seller['postal_code'] ?? $defaults['print']['seller']['postal_code'] ) ),
					'national_id'   => sanitize_text_field( (string) ( $seller['national_id'] ?? '' ) ),
					'economic_code' => sanitize_text_field( (string) ( $seller['economic_code'] ?? '' ) ),
				],
				'types'  => $clean_print_types,
			],
		];
		
		return apply_filters( 'kerp_orders_sanitized_settings', $clean, $settings );
	}
	
	public function sort_by_order( array $first, array $second ): int {
		return (int) ( $first['order'] ?? 100 ) <=> (int) ( $second['order'] ?? 100 );
	}
	
	public function clear_cache(): void {
		$this->settings = NULL;
	}
	
	private function save_all( array $settings ): bool {
		$current = $this->all();
		$clean   = $this->sanitize( $settings );
		$result  = update_option( self::OPTION_NAME, $clean, FALSE );
		
		$this->settings = $clean;
		do_action( 'kerp_orders_settings_updated', $clean, $current );
		
		return $result || $clean === $current;
	}
	
	private function default_units(): array {
		return [
			'piece'  => [ 'key' => 'piece', 'label' => __( 'عدد', 'kasebi-erp' ), 'order' => 10, 'active' => 1 ],
			'kg'     => [ 'key' => 'kg', 'label' => __( 'کیلوگرم', 'kasebi-erp' ), 'order' => 20, 'active' => 1 ],
			'gram'   => [ 'key' => 'gram', 'label' => __( 'گرم', 'kasebi-erp' ), 'order' => 30, 'active' => 1 ],
			'meter'  => [ 'key' => 'meter', 'label' => __( 'متر', 'kasebi-erp' ), 'order' => 40, 'active' => 1 ],
			'pack'   => [ 'key' => 'pack', 'label' => __( 'بسته', 'kasebi-erp' ), 'order' => 50, 'active' => 1 ],
			'carton' => [ 'key' => 'carton', 'label' => __( 'کارتن', 'kasebi-erp' ), 'order' => 60, 'active' => 1 ],
			'box'    => [ 'key' => 'box', 'label' => __( 'جعبه', 'kasebi-erp' ), 'order' => 70, 'active' => 1 ],
		];
	}
	
	private function default_statuses(): array {
		$statuses        = function_exists( 'wc_get_order_statuses' ) ? wc_get_order_statuses() : [];
		$custom_statuses = $this->get_raw_custom_statuses();
		$colors          = [
			'pending'    => 'warning',
			'processing' => 'secondary',
			'on-hold'    => 'info',
			'completed'  => 'success',
			'delivered'  => 'light',
			'cancelled'  => 'danger',
			'failed'     => 'danger',
		];
		$transitions     = [
			'pending'    => [ 'processing', 'on-hold', 'cancelled' ],
			'processing' => [ 'completed', 'cancelled' ],
			'on-hold'    => [ 'processing', 'cancelled' ],
			'completed'  => [ 'delivered' ],
			'failed'     => [ 'pending', 'cancelled' ],
		];
		$result          = [];
		$order           = 10;
		
		foreach ( $statuses as $status_key => $status_label ) {
			$status_key = $this->normalize_status_key( (string) $status_key );
			
			if ( $status_key === '' || $status_key === 'refunded' ) {
				continue;
			}
			
			if ( isset( $custom_statuses[ $status_key ] ) ) {
				$custom                = $custom_statuses[ $status_key ];
				$result[ $status_key ] = [
					'key'          => $status_key,
					'label'        => sanitize_text_field( (string) ( $custom['label'] ?? $status_label ) ),
					'color'        => sanitize_key( (string) ( $custom['color'] ?? 'secondary' ) ) ?: 'secondary',
					'order'        => max( 0, absint( $custom['order'] ?? $order ) ),
					'active'       => $this->sanitize_bool( $custom['active'] ?? 1 ),
					'custom'       => 1,
					'allowed_next' => isset( $custom['allowed_next'] ) && is_array( $custom['allowed_next'] ) ? $custom['allowed_next'] : [],
				];
				$order                 += 10;
				continue;
			}
			
			$allowed_next = [];
			foreach ( (array) ( $transitions[ $status_key ] ?? [] ) as $next_status ) {
				$next_status = $this->normalize_status_key( (string) $next_status );
				if ( $next_status !== '' && isset( $statuses[ 'wc-' . $next_status ] ) ) {
					$allowed_next[] = $next_status;
				}
			}
			
			$result[ $status_key ] = [
				'key'          => $status_key,
				'label'        => sanitize_text_field( (string) $status_label ),
				'color'        => $colors[ $status_key ] ?? 'secondary',
				'order'        => $order,
				'active'       => 1,
				'custom'       => 0,
				'allowed_next' => $allowed_next,
			];
			$order                 += 10;
		}
		
		return $result;
	}
	
	private function default_print_types(): array {
		return [
			'pre-invoice' => [
				'key'         => 'pre-invoice',
				'label'       => __( 'پیش‌فاکتور', 'kasebi-erp' ),
				'icon'        => 'ni ni-file-text',
				'order'       => 10,
				'enabled'     => 1,
				'header_text' => '',
				'footer_text' => '',
			],
			'official'    => [
				'key'         => 'official',
				'label'       => __( 'فاکتور رسمی', 'kasebi-erp' ),
				'icon'        => 'ni ni-reports',
				'order'       => 20,
				'enabled'     => 1,
				'header_text' => '',
				'footer_text' => '',
			],
			'accounting'  => [
				'key'         => 'accounting',
				'label'       => __( 'فاکتور حسابداری', 'kasebi-erp' ),
				'icon'        => 'kik fa-calculator',
				'order'       => 30,
				'enabled'     => 1,
				'header_text' => '',
				'footer_text' => '',
			],
			'roll'        => [
				'key'         => 'roll',
				'label'       => __( 'فاکتور رول', 'kasebi-erp' ),
				'icon'        => 'ni ni-printer',
				'order'       => 40,
				'enabled'     => 1,
				'header_text' => '',
				'footer_text' => '',
			],
		];
	}
	
	private function default_seller_data(): array {
		$address_parts = array_filter(
			[
				sanitize_text_field( (string) get_option( 'woocommerce_store_address', '' ) ),
				sanitize_text_field( (string) get_option( 'woocommerce_store_address_2', '' ) ),
				sanitize_text_field( (string) get_option( 'woocommerce_store_city', '' ) ),
			]
		);
		
		return [
			'name'          => get_bloginfo( 'name' ),
			'phone'         => '',
			'address'       => implode( '، ', $address_parts ),
			'postal_code'   => sanitize_text_field( (string) get_option( 'woocommerce_store_postcode', '' ) ),
			'national_id'   => '',
			'economic_code' => '',
		];
	}
	
	private function sanitize_unit( array $unit ): array {
		return [
			'key'    => sanitize_key( (string) ( $unit['key'] ?? '' ) ),
			'label'  => sanitize_text_field( (string) ( $unit['label'] ?? '' ) ),
			'order'  => max( 0, absint( $unit['order'] ?? 100 ) ),
			'active' => $this->sanitize_bool( $unit['active'] ?? 0 ),
		];
	}
	
	private function sanitize_status( string $status_key, array $status ): array {
		$status_key   = $this->normalize_status_key( $status_key );
		$allowed_next = isset( $status['allowed_next'] ) && is_array( $status['allowed_next'] )
			? $status['allowed_next']
			: [];
		$allowed_next = array_values(
			array_unique(
				array_filter(
					array_map( [ $this, 'normalize_status_key' ], $allowed_next )
				)
			)
		);
		$allowed_next = array_values(
			array_filter(
				$allowed_next,
				function( string $next_status ) use ( $status_key ): bool {
					return $next_status !== $status_key;
				}
			)
		);
		
		return [
			'key'          => $status_key,
			'label'        => sanitize_text_field( (string) ( $status['label'] ?? $status_key ) ),
			'color'        => sanitize_key( (string) ( $status['color'] ?? 'secondary' ) ) ?: 'secondary',
			'order'        => max( 0, absint( $status['order'] ?? 100 ) ),
			'active'       => $this->sanitize_bool( $status['active'] ?? 0 ),
			'custom'       => $this->sanitize_bool( $status['custom'] ?? 0 ),
			'allowed_next' => $allowed_next,
		];
	}
	
	private function sanitize_print_type( string $type_key, array $type ): array {
		$icon_classes = preg_split( '/\s+/', trim( (string) ( $type['icon'] ?? 'ni ni-printer' ) ), - 1, PREG_SPLIT_NO_EMPTY );
		$icon_classes = is_array( $icon_classes ) ? array_map( 'sanitize_html_class', $icon_classes ) : [];
		
		return [
			'key'         => sanitize_key( $type_key ),
			'label'       => sanitize_text_field( (string) ( $type['label'] ?? $type_key ) ),
			'icon'        => implode( ' ', array_filter( $icon_classes ) ) ?: 'ni ni-printer',
			'order'       => max( 0, absint( $type['order'] ?? 100 ) ),
			'enabled'     => $this->sanitize_bool( $type['enabled'] ?? 0 ),
			'header_text' => sanitize_textarea_field( (string) ( $type['header_text'] ?? '' ) ),
			'footer_text' => sanitize_textarea_field( (string) ( $type['footer_text'] ?? '' ) ),
		];
	}
	
	private function sanitize_bool( mixed $value ): int {
		if ( is_array( $value ) ) {
			$value = array_map( 'strval', $value );
			
			return in_array( '1', $value, TRUE ) ? 1 : 0;
		}
		
		return in_array( strtolower( trim( (string) $value ) ), [ '1', 'true', 'yes', 'on' ], TRUE ) ? 1 : 0;
	}
	
	private function sanitize_time( string $time ): string {
		$time = trim( KERP_Helpers_Format::sanitize_numbers( $time ) );
		
		if ( preg_match( '/^(?:[01]\d|2[0-3]):[0-5]\d$/', $time ) ) {
			return $time;
		}
		
		return '17:00';
	}
	
	private function get_raw_custom_statuses(): array {
		$stored   = get_option( self::OPTION_NAME, [] );
		$stored   = is_array( $stored ) ? $stored : [];
		$statuses = isset( $stored['statuses'] ) && is_array( $stored['statuses'] )
			? $stored['statuses']
			: [];
		$result   = [];
		
		foreach ( $statuses as $status_key => $status ) {
			if ( ! is_array( $status ) || empty( $status['custom'] ) ) {
				continue;
			}
			
			$status_key = $this->normalize_status_key( (string) $status_key );
			
			if ( $status_key === '' ) {
				continue;
			}
			
			$result[ $status_key ] = $status;
		}
		
		uasort( $result, [ $this, 'sort_by_order' ] );
		
		return $result;
	}
	
	private function normalize_status_key( string $status_key ): string {
		return str_replace( 'wc-', '', sanitize_key( $status_key ) );
	}
	
}
