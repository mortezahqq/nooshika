<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Ajax_Module {
	
	public const  ENDPOINT          = 'kerp-ajax';
	
	public const  PAGE_SLUG         = 'kerp-ajax';
	
	public const  OPTION_PLUGINS    = 'kerp_ajax_active_plugins';
	
	public const  SAVE_ACTION       = 'kerp_save_ajax_settings';
	
	public const  NONCE_ACTION      = 'kerp_save_ajax_settings';
	
	public const  NONCE_NAME        = 'kerp_ajax_settings_nonce';
	
	public const  INSTALL_MU_ACTION = 'kerp_install_ajax_mu_loader';
	
	public const  INSTALL_MU_NONCE  = 'kerp_install_ajax_mu_loader';
	
	private const MODULES_OPTION    = 'kerp_modules_statuses';
	
	private const MU_TEMPLATE       = 'mu-plugins/kasebi-erp-ajax-loader.tmpl';
	
	private const MU_FILENAME       = 'kasebi-erp-ajax-loader.php';
	
	private static ?KERP_Modules_Ajax_Module $instance = NULL;
	
	public static function instance(): KERP_Modules_Ajax_Module {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	/**
	 * This method must be called after registering the KERP autoloader.
	 */
	public static function register_lifecycle_hooks(): void {
		add_action( 'kerp_activated', [ self::class, 'activate' ] );
		add_action( 'kerp_deactivated', [ self::class, 'deactivate' ] );
	}
	
	private function __construct() {
		$this->init_hooks();
	}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize singleton.' );
	}
	
	private function init_hooks(): void {
		if ( is_admin() ) {
			add_action( 'kerp_admin_menu_registered', [ $this, 'register_admin_page' ] );
			add_action( 'admin_post_' . self::SAVE_ACTION, [ $this, 'save_settings' ] );
			add_action( 'admin_post_' . self::INSTALL_MU_ACTION, [ $this, 'install_mu_loader_action' ] );
		}
	}
	
	public static function activate(): void {
		if ( ! self::is_enabled_from_options() ) {
			return;
		}
		
		self::install_mu_loader();
		flush_rewrite_rules();
	}
	
	public static function deactivate(): void {
		self::delete_mu_loader();
		flush_rewrite_rules();
	}
	
	private static function is_enabled_from_options(): bool {
		$statuses = get_option( self::MODULES_OPTION, [] );
		
		if ( is_array( $statuses ) && array_key_exists( 'ajax', $statuses ) ) {
			return $statuses['ajax'] === 'yes';
		}
		
		return TRUE;
	}
	
	public function register_admin_page( string $parent_slug ): void {
		$hook_suffix = add_submenu_page(
			$parent_slug,
			__( 'تنظیمات Ajax', 'kasebi-erp' ),
			__( 'تنظیمات Ajax', 'kasebi-erp' ),
			KERP_Admin::CAPABILITY,
			self::PAGE_SLUG,
			[ $this, 'render_settings_page' ]
		);
		
		if ( is_string( $hook_suffix ) && $hook_suffix !== '' ) {
			KERP_Admin_Menu::instance()->register_screen_hook( $hook_suffix );
		}
	}
	
	public function render_settings_page(): void {
		if ( ! KERP_Admin::can_manage() ) {
			wp_die( esc_html__( 'شما دسترسی لازم برای مشاهده این صفحه را ندارید.', 'kasebi-erp' ) );
		}
		
		$notice = isset( $_GET['kerp_notice'] )
			? sanitize_key( wp_unslash( (string) $_GET['kerp_notice'] ) )
			: '';
		
		KERP_Helpers_Template::render_template(
			'modules/ajax/settings.php',
			[
				'module'           => $this,
				'active_plugins'   => $this->get_active_plugins_for_settings(),
				'selected_plugins' => $this->get_ajax_active_plugins(),
				'mu_loader_path'   => self::get_mu_loader_path(),
				'has_mu_loader'    => self::has_mu_loader(),
				'notice'           => $notice,
			]
		);
	}
	
	public function save_settings(): void {
		if ( ! KERP_Admin::can_manage() ) {
			wp_die( esc_html__( 'شما دسترسی لازم برای انجام این عملیات را ندارید.', 'kasebi-erp' ) );
		}
		
		check_admin_referer( self::NONCE_ACTION, self::NONCE_NAME );
		
		$plugins = isset( $_POST['ajax_active_plugins'] ) && is_array( $_POST['ajax_active_plugins'] )
			? wp_unslash( $_POST['ajax_active_plugins'] )
			: [];
		
		$this->update_ajax_active_plugins( $plugins );
		
		$result = self::install_mu_loader();
		$notice = is_wp_error( $result ) ? 'ajax_save_failed' : 'ajax_saved';
		
		if ( ! is_wp_error( $result ) ) {
			flush_rewrite_rules();
		}
		
		$this->redirect_to_settings( $notice );
	}
	
	public function install_mu_loader_action(): void {
		if ( ! KERP_Admin::can_manage() ) {
			wp_die( esc_html__( 'شما دسترسی لازم برای انجام این عملیات را ندارید.', 'kasebi-erp' ) );
		}
		
		check_admin_referer( self::INSTALL_MU_NONCE, self::INSTALL_MU_NONCE );
		
		$result = self::install_mu_loader();
		$notice = is_wp_error( $result ) ? 'mu_loader_failed' : 'mu_loader_installed';
		
		if ( ! is_wp_error( $result ) ) {
			flush_rewrite_rules();
		}
		
		$this->redirect_to_settings( $notice );
	}
	
	private function redirect_to_settings( string $notice ): void {
		wp_safe_redirect(
			add_query_arg(
				[
					'page'        => self::PAGE_SLUG,
					'kerp_notice' => sanitize_key( $notice ),
				],
				admin_url( 'admin.php' )
			)
		);
		exit;
	}
	
	public static function get_forced_plugins(): array {
		$plugins = [ KERP_BASENAME ];
        $statuses = (array) get_option( 'kerp_modules_statuses', [] );
        if ( ( $statuses['gold'] ?? 'no' ) === 'yes' ) { $plugins[] = 'woocommerce/woocommerce.php'; }
		$plugins = (array) apply_filters( 'kerp_ajax_forced_plugins', $plugins );
		
		return self::sanitize_plugin_basenames( $plugins );
	}
	
	public static function is_forced_plugin( string $plugin_basename ): bool {
		return in_array( $plugin_basename, self::get_forced_plugins(), TRUE );
	}
	
	public function get_active_plugins_for_settings(): array {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
		
		$plugins         = [];
		$active_plugins  = (array) get_option( 'active_plugins', [] );
		$network_plugins = (array) get_site_option( 'active_sitewide_plugins', [] );
		
		foreach ( $active_plugins as $plugin_basename ) {
			$this->add_plugin_to_settings_list( $plugins, (string) $plugin_basename, FALSE );
		}
		
		foreach ( array_keys( $network_plugins ) as $plugin_basename ) {
			$this->add_plugin_to_settings_list( $plugins, (string) $plugin_basename, TRUE );
		}
		
		ksort( $plugins );
		
		return $plugins;
	}
	
	private function add_plugin_to_settings_list( array &$plugins, string $plugin_basename, bool $network ): void {
		$plugin_file = WP_PLUGIN_DIR . '/' . $plugin_basename;
		
		if ( ! is_readable( $plugin_file ) ) {
			return;
		}
		
		$data = get_plugin_data( $plugin_file, FALSE, FALSE );
		
		$plugins[ $plugin_basename ] = [
			'basename' => $plugin_basename,
			'name'     => $data['Name'] ?: $plugin_basename,
			'version'  => $data['Version'] ?? '',
			'network'  => $network,
			'forced'   => $network || self::is_forced_plugin( $plugin_basename ),
		];
	}
	
	public function get_ajax_active_plugins(): array {
		$plugins = get_option( self::OPTION_PLUGINS, [] );
		
		return is_array( $plugins ) ? self::sanitize_plugin_basenames( $plugins ) : [];
	}
	
	public function update_ajax_active_plugins( array $plugins ): void {
		$active_plugins = (array) get_option( 'active_plugins', [] );
		$plugins        = self::sanitize_plugin_basenames( $plugins );
		$plugins        = array_values( array_intersect( $plugins, $active_plugins ) );
		$plugins        = array_merge( $plugins, self::get_forced_plugins() );
		$plugins        = array_values( array_unique( $plugins ) );
		
		update_option( self::OPTION_PLUGINS, $plugins, FALSE );
	}
	
	private static function sanitize_plugin_basenames( array $plugins ): array {
		$clean = [];
		
		foreach ( $plugins as $plugin ) {
			if ( ! is_string( $plugin ) ) {
				continue;
			}
			
			$plugin = plugin_basename( sanitize_text_field( $plugin ) );
			
			if ( $plugin !== '' && str_ends_with( $plugin, '.php' ) ) {
				$clean[] = $plugin;
			}
		}
		
		return array_values( array_unique( $clean ) );
	}
	
	public static function install_mu_loader(): bool|WP_Error {
		$template  = KERP_TEMPLATES_PATH . self::MU_TEMPLATE;
		$file_data = is_readable( $template ) ? file_get_contents( $template ) : FALSE;
		
		if ( ! is_string( $file_data ) ) {
			return new WP_Error( 'kerp_ajax_mu_template_unreadable', __( 'قالب MU Loader خوانده نشد.', 'kasebi-erp' ) );
		}
		
		$file_data = str_replace(
			[
				'{{KERP_AJAX_ENDPOINT}}',
				'{{KERP_AJAX_ACTIVE_PLUGINS_OPTION}}',
				'{{KERP_AJAX_FORCED_PLUGINS}}',
			],
			[
				self::ENDPOINT,
				self::OPTION_PLUGINS,
				var_export( self::get_forced_plugins(), TRUE ),
			],
			$file_data
		);
		
		if ( ! is_dir( WPMU_PLUGIN_DIR ) && ! wp_mkdir_p( WPMU_PLUGIN_DIR ) ) {
			return new WP_Error( 'kerp_ajax_mu_directory_failed', __( 'پوشه mu-plugins ساخته نشد.', 'kasebi-erp' ) );
		}
		
		$result = file_put_contents( self::get_mu_loader_path(), $file_data, LOCK_EX );
		
		if ( $result === FALSE ) {
			return new WP_Error( 'kerp_ajax_mu_write_failed', __( 'فایل Ajax MU Loader ساخته نشد.', 'kasebi-erp' ) );
		}
		
		return TRUE;
	}
	
	public static function delete_mu_loader(): void {
		$target = self::get_mu_loader_path();
		
		if ( ! is_file( $target ) ) {
			return;
		}
		
		$file_data = file_get_contents( $target );
		
		if ( is_string( $file_data ) && str_contains( $file_data, 'Kasebi ERP Ajax Loader' ) ) {
			wp_delete_file( $target );
		}
	}
	
	public static function get_mu_loader_path(): string {
		return trailingslashit( WPMU_PLUGIN_DIR ) . self::MU_FILENAME;
	}
	
	public static function has_mu_loader(): bool {
		return is_file( self::get_mu_loader_path() );
	}
	
}
