<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Followups_Module {
	
	private const DB_VERSION        = '1.0.0';
	
	private const DB_VERSION_OPTION = 'kerp_followups_db_version';
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {
		$this->load_services();
		$this->maybe_install();
		$this->register_hooks();
	}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	private function load_services(): void {
		KERP_Modules_Followups_Settings::instance();
		KERP_Modules_Followups_Query::instance();
		KERP_Modules_Followups_Form::instance();
		KERP_Modules_Followups_List_Table::instance();
		KERP_Modules_Followups_Api::instance();
	}
	
	private function register_hooks(): void {
		add_filter( 'kerp_app_pages', [ $this, 'register_pages' ], 35 );
		add_filter( 'kerp_customer_profile_tabs', [ $this, 'register_customer_tab' ], 35, 3 );
		add_filter( 'kerp_customers_profile_dropdown_actions', [ $this, 'register_profile_dropdown_action' ], 35, 3 );
		add_action( 'kerp_customer_profile_modals', [ $this, 'render_customer_modal' ], 35, 4 );
		add_filter( 'kerp_employee_permission_groups', [ $this, 'register_permissions' ], 35 );
		add_action( 'deleted_user', [ $this, 'handle_deleted_user' ] );
	}
	
	public static function table(): string {
		global $wpdb;
		
		return $wpdb->prefix . 'kasebi_erp_followups';
	}
	
	public static function history_table(): string {
		global $wpdb;
		
		return $wpdb->prefix . 'kasebi_erp_followup_history';
	}
	
	public static function install(): void {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$followups     = self::table();
		$history       = self::history_table();
		$charset       = $wpdb->get_charset_collate();
		$sql_followups = "CREATE TABLE {$followups} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			customer_id BIGINT UNSIGNED NOT NULL,
			type_key VARCHAR(100) NOT NULL,
			title VARCHAR(190) NOT NULL,
			description LONGTEXT NULL,
			due_at DATETIME NOT NULL,
			assignee_id BIGINT UNSIGNED NOT NULL,
			priority VARCHAR(30) NOT NULL DEFAULT 'normal',
			status VARCHAR(30) NOT NULL DEFAULT 'pending',
			outcome LONGTEXT NULL,
			completed_at DATETIME NULL,
			completed_by BIGINT UNSIGNED NULL,
			created_by BIGINT UNSIGNED NOT NULL,
			updated_by BIGINT UNSIGNED NULL,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NULL,
			metadata LONGTEXT NULL,
			PRIMARY KEY  (id),
			KEY idx_customer_status_due (customer_id, status, due_at),
			KEY idx_assignee_status_due (assignee_id, status, due_at),
			KEY idx_type_status_due (type_key, status, due_at),
			KEY idx_status_due (status, due_at),
			KEY idx_created_by (created_by)
		) {$charset};";
		$sql_history   = "CREATE TABLE {$history} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			followup_id BIGINT UNSIGNED NOT NULL,
			event_key VARCHAR(60) NOT NULL,
			note LONGTEXT NULL,
			old_data LONGTEXT NULL,
			new_data LONGTEXT NULL,
			created_by BIGINT UNSIGNED NOT NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY idx_followup_date (followup_id, created_at),
			KEY idx_event_date (event_key, created_at),
			KEY idx_created_by (created_by)
		) {$charset};";
		dbDelta( $sql_followups );
		dbDelta( $sql_history );
		update_option( self::DB_VERSION_OPTION, self::DB_VERSION, FALSE );
	}
	
	public function register_pages( array $pages ): array {
		$customer_plural_label        = KERP_Modules_Customers_Settings::instance()->get_plural_label();
		$crm_group                   = [
			'key'   => 'crm',
			'title' => sprintf( __( 'مدیریت %s', 'kasebi-erp' ), $customer_plural_label ),
			'icon'  => 'kik fa-users-02',
			'order' => 20,
		];
		$settings_group              = [
			'key'        => 'settings',
			'title'      => __( 'تنظیمات', 'kasebi-erp' ),
			'icon'       => 'kik fa-settings-02',
			'order'      => 100,
			'sep_before' => TRUE,
		];
		$settings_menu               = [
			'key'   => 'crm-settings',
			'title' => __( 'تنظیمات CRM', 'kasebi-erp' ),
			'icon'  => 'kik fa-users-02',
			'order' => 50,
		];
		$pages['followups']          = [
			'title'      => __( 'پیگیری‌ها', 'kasebi-erp' ),
			'route'      => 'followups',
			'type'       => 'page',
			'template'   => 'modules/followups/pages/followups.php',
			'permission' => 'followups.view',
			'navigation' => [
				'group' => apply_filters( 'kerp_followups_crm_navigation_group', $crm_group ),
				'icon'  => 'kik fa-clock',
				'order' => 30,
			],
		];
		$pages['followups-settings'] = [
			'title'      => __( 'تنظیمات پیگیری‌ها', 'kasebi-erp' ),
			'route'      => 'settings/followups',
			'type'       => 'settings',
			'template'   => 'modules/followups/settings/general.php',
			'permission' => 'followups.manage_settings',
			'navigation' => [
				'group' => apply_filters( 'kerp_followups_settings_navigation_group', $settings_group ),
				'menu'  => apply_filters( 'kerp_crm_settings_navigation_menu', $settings_menu ),
				'title' => __( 'تنظیمات پیگیری‌ها', 'kasebi-erp' ),
				'order' => 20,
			],
		];
		
		return $pages;
	}
	
	public function register_customer_tab( array $tabs, int $customer_id, WP_User $customer ): array {
		$tabs['followups'] = [
			'key'        => 'followups',
			'title'      => __( 'پیگیری‌ها', 'kasebi-erp' ),
			'icon'       => 'kik fa-clock',
			'order'      => 40,
			'group'      => 'crm',
			'permission' => 'followups.view',
			'action'     => 'view',
			'template'   => 'modules/followups/tabs/customer-followups.php',
		];
		
		return $tabs;
	}
	
	public function register_profile_dropdown_action( array $actions, WP_User $customer, array $profile_context ): array {
		if ( ! kerp_can( 'followups.create', 'action' ) ) {
			return $actions;
		}
		$actions['add_customer_followup'] = [
			'label'      => __( 'ثبت سریع پیگیری', 'kasebi-erp' ),
			'icon'       => 'kik fa-clock',
			'href'       => '#customerFollowupModal',
			'order'      => 40,
			'attributes' => [
				'data-bs-toggle' => 'modal',
				'data-bs-target' => '#customerFollowupModal',
			],
		];
		
		return $actions;
	}
	
	public function render_customer_modal( int $customer_id, WP_User $customer, array $profile_context, string $active_tab ): void {
		if ( ! kerp_can( 'followups.create', 'action' ) && ! kerp_can( 'followups.edit', 'action' ) ) {
			return;
		}
		$return_page = '/erp/customers/' . $customer_id . '/';
		if ( $active_tab !== '' ) {
			$return_page = add_query_arg( 'tab', sanitize_key( $active_tab ), $return_page );
		}
		KERP_Modules_Followups_Form::instance()->render_modal( $customer_id, $return_page, 'customerFollowupModal' );
		KERP_Modules_Followups_Form::instance()->render_action_modals( $return_page, 'customer' );
	}
	
	public function register_permissions( array $groups ): array {
		$customer_plural_label         = KERP_Modules_Customers_Settings::instance()->get_plural_label();
		$group                        = isset( $groups['crm'] ) && is_array( $groups['crm'] ) ? $groups['crm'] : [
			'key'    => 'crm',
			'label'  => sprintf( __( '%s و بازاریابی', 'kasebi-erp' ), $customer_plural_label ),
			'icon'   => 'kik fa-users-02',
			'order'  => 20,
			'blocks' => [],
		];
		$group['blocks']              = isset( $group['blocks'] ) && is_array( $group['blocks'] ) ? $group['blocks'] : [];
		$group['blocks']['followups'] = [
			'key'         => 'followups',
			'label'       => __( 'پیگیری‌ها', 'kasebi-erp' ),
			'icon'        => 'kik fa-clock',
			'order'       => 40,
			'description' => sprintf( __( 'مدیریت سررسیدها و اقدامات بعدی %s.', 'kasebi-erp' ), $customer_plural_label ),
			'permissions' => [
				'followups_view'            => [
					'key'   => 'followups.view',
					'label' => __( 'دسترسی به بخش پیگیری‌ها', 'kasebi-erp' ),
					'type'  => 'view',
					'order' => 10,
				],
				'followups_list'            => [
					'key'         => 'followups.list',
					'label'       => __( 'مشاهده فهرست پیگیری‌ها', 'kasebi-erp' ),
					'description' => __( 'دامنه پیگیری‌هایی که کارمند می‌تواند مشاهده کند.', 'kasebi-erp' ),
					'type'        => 'view',
					'order'       => 20,
					'scope'       => [
						'options' => [
							'own' => __( 'فقط پیگیری‌های مسئول‌شده به خود', 'kasebi-erp' ),
							'all' => __( 'همه پیگیری‌ها', 'kasebi-erp' ),
						],
						'default' => 'own',
					],
				],
				'followups_create'          => [
					'key'   => 'followups.create',
					'label' => __( 'ثبت پیگیری', 'kasebi-erp' ),
					'type'  => 'action',
					'order' => 30,
				],
				'followups_edit'            => [
					'key'   => 'followups.edit',
					'label' => __( 'ویرایش پیگیری', 'kasebi-erp' ),
					'type'  => 'action',
					'order' => 40,
				],
				'followups_complete'        => [
					'key'   => 'followups.complete',
					'label' => __( 'تکمیل پیگیری', 'kasebi-erp' ),
					'type'  => 'action',
					'order' => 50,
				],
				'followups_cancel'          => [
					'key'   => 'followups.cancel',
					'label' => __( 'لغو پیگیری', 'kasebi-erp' ),
					'type'  => 'action',
					'order' => 60,
				],
				'followups_delete'          => [
					'key'   => 'followups.delete',
					'label' => __( 'حذف پیگیری', 'kasebi-erp' ),
					'type'  => 'action',
					'order' => 70,
				],
				'followups_manage_settings' => [
					'key'   => 'followups.manage_settings',
					'label' => __( 'مدیریت تنظیمات پیگیری‌ها', 'kasebi-erp' ),
					'type'  => 'action',
					'order' => 80,
				],
			],
		];
		$groups['crm']                = $group;
		
		return $groups;
	}
	
	public function save( array $data, int $followup_id = 0 ): int|WP_Error {
		global $wpdb;
		$followup_id = absint( $followup_id );
		$existing    = $followup_id > 0 ? KERP_Modules_Followups_Query::instance()->get_by_id( $followup_id ) : NULL;
		if ( $followup_id > 0 && ! is_array( $existing ) ) {
			return new WP_Error( 'kerp_followup_not_found', __( 'پیگیری پیدا نشد.', 'kasebi-erp' ) );
		}
		$customer_id = absint( $data['customer_id'] ?? 0 );
		$customer    = get_userdata( $customer_id );
		if ( ! $customer instanceof WP_User || ! $this->is_customer( $customer ) ) {
			return new WP_Error( 'kerp_followup_invalid_customer', sprintf( __( '%s معتبر نیست.', 'kasebi-erp' ), KERP_Modules_Customers_Settings::instance()->get_singular_label() ) );
		}
		$type_key = sanitize_key( (string) ( $data['type_key'] ?? '' ) );
		$types    = KERP_Modules_Followups_Settings::instance()->get_types();
		if ( $type_key === '' || ! isset( $types[ $type_key ] ) ) {
			return new WP_Error( 'kerp_followup_invalid_type', __( 'نوع پیگیری معتبر نیست.', 'kasebi-erp' ) );
		}
		$title = sanitize_text_field( (string) ( $data['title'] ?? '' ) );
		if ( $title === '' ) {
			return new WP_Error( 'kerp_followup_empty_title', __( 'عنوان پیگیری را وارد کنید.', 'kasebi-erp' ) );
		}
		$due_at = sanitize_text_field( (string) ( $data['due_at'] ?? '' ) );
		if ( $due_at === '' || strtotime( $due_at ) === FALSE ) {
			return new WP_Error( 'kerp_followup_invalid_due_at', __( 'تاریخ و ساعت سررسید معتبر نیست.', 'kasebi-erp' ) );
		}
		$assignee_id            = absint( $data['assignee_id'] ?? 0 );
		$current_assignee_id    = is_array( $existing ) ? absint( $existing['assignee_id'] ?? 0 ) : 0;
		$is_registered_employee = class_exists( 'KERP_Modules_Employees_Query' )
		                          && KERP_Modules_Employees_Query::instance()
		                                                         ->get_employee( $assignee_id ) instanceof WP_User;
		$is_administrator = $assignee_id > 0 && user_can( $assignee_id, 'manage_options' );
		if ( $assignee_id <= 0 || ( ! $is_registered_employee && ! $is_administrator && $assignee_id !== $current_assignee_id ) ) {
			return new WP_Error( 'kerp_followup_invalid_assignee', __( 'مسئول پیگیری باید مدیر سایت یا یکی از کارکنان ثبت‌شده ERP باشد.', 'kasebi-erp' ) );
		}
		$priority = sanitize_key( (string) ( $data['priority'] ?? 'normal' ) );
		if ( ! isset( KERP_Modules_Followups_Settings::instance()->get_priority_options()[ $priority ] ) ) {
			$priority = 'normal';
		}
		$status = sanitize_key( (string) ( $data['status'] ?? 'pending' ) );
		if ( ! in_array( $status, [ 'pending', 'completed', 'cancelled' ], TRUE ) ) {
			$status = 'pending';
		}
		$now      = current_time( 'mysql' );
		$user_id  = get_current_user_id();
		$metadata = [];
		
		if ( is_array( $existing ) ) {
			$existing_metadata = json_decode(
				(string) ( $existing['metadata'] ?? '' ),
				TRUE
			);
			
			if ( is_array( $existing_metadata ) ) {
				$metadata = $existing_metadata;
			}
		}
		
		$new_metadata = isset( $data['metadata'] ) && is_array( $data['metadata'] )
			? $data['metadata']
			: [];
		
		$metadata = array_merge(
			$metadata,
			$new_metadata
		);
		$record   = [
			'customer_id' => $customer_id,
			'type_key'    => $type_key,
			'title'       => $title,
			'description' => wp_kses_post( (string) ( $data['description'] ?? '' ) ),
			'due_at'      => $due_at,
			'assignee_id' => $assignee_id,
			'priority'    => $priority,
			'status'      => $status,
			'updated_by'  => $user_id,
			'updated_at'  => $now,
			'metadata'    => wp_json_encode( $metadata ),
		];
		if ( $followup_id > 0 ) {
			$result = $wpdb->update( self::table(), $record, [ 'id' => $followup_id ], [
				'%d',
				'%s',
				'%s',
				'%s',
				'%s',
				'%d',
				'%s',
				'%s',
				'%d',
				'%s',
				'%s',
			], [ '%d' ] );
			if ( $result === FALSE ) {
				return new WP_Error( 'kerp_followup_update_failed', __( 'ویرایش پیگیری انجام نشد.', 'kasebi-erp' ) );
			}
			$this->add_history( $followup_id, 'updated', '', $existing, array_merge( $existing, $record ) );
			do_action( 'kerp_followup_updated', $followup_id, $record, $existing );
			
			return $followup_id;
		}
		$record['created_by'] = $user_id;
		$record['created_at'] = $now;
		$result               = $wpdb->insert( self::table(), $record, [
			'%d',
			'%s',
			'%s',
			'%s',
			'%s',
			'%d',
			'%s',
			'%s',
			'%d',
			'%s',
			'%s',
			'%d',
			'%s',
		] );
		if ( $result === FALSE ) {
			return new WP_Error( 'kerp_followup_insert_failed', __( 'ثبت پیگیری انجام نشد.', 'kasebi-erp' ) );
		}
		$followup_id = (int) $wpdb->insert_id;
		$this->add_history( $followup_id, 'created', '', [], $record );
		do_action( 'kerp_followup_created', $followup_id, $record );
		
		return $followup_id;
	}
	
	public function complete( int $followup_id, string $outcome ): bool|WP_Error {
		global $wpdb;
		$followup = KERP_Modules_Followups_Query::instance()->get_by_id( $followup_id );
		if ( ! is_array( $followup ) ) {
			return new WP_Error( 'kerp_followup_not_found', __( 'پیگیری پیدا نشد.', 'kasebi-erp' ) );
		}
		$now    = current_time( 'mysql' );
		$data   = [
			'status'       => 'completed',
			'outcome'      => wp_kses_post( $outcome ),
			'completed_at' => $now,
			'completed_by' => get_current_user_id(),
			'updated_by'   => get_current_user_id(),
			'updated_at'   => $now,
		];
		$result = $wpdb->update( self::table(), $data, [ 'id' => $followup_id ], [
			'%s',
			'%s',
			'%s',
			'%d',
			'%d',
			'%s',
		], [ '%d' ] );
		if ( $result === FALSE ) {
			return new WP_Error( 'kerp_followup_complete_failed', __( 'تکمیل پیگیری انجام نشد.', 'kasebi-erp' ) );
		}
		$this->add_history( $followup_id, 'completed', $outcome, $followup, array_merge( $followup, $data ) );
		do_action( 'kerp_followup_completed', $followup_id, $data, $followup );
		
		return TRUE;
	}
	
	public function cancel( int $followup_id, string $note ): bool|WP_Error {
		global $wpdb;
		$followup = KERP_Modules_Followups_Query::instance()->get_by_id( $followup_id );
		if ( ! is_array( $followup ) ) {
			return new WP_Error( 'kerp_followup_not_found', __( 'پیگیری پیدا نشد.', 'kasebi-erp' ) );
		}
		$now    = current_time( 'mysql' );
		$data   = [
			'status'       => 'cancelled',
			'outcome'      => wp_kses_post( $note ),
			'completed_at' => NULL,
			'completed_by' => NULL,
			'updated_by'   => get_current_user_id(),
			'updated_at'   => $now,
		];
		$result = $wpdb->update( self::table(), $data, [ 'id' => $followup_id ], [
			'%s',
			'%s',
			NULL,
			NULL,
			'%d',
			'%s',
		], [ '%d' ] );
		if ( $result === FALSE ) {
			return new WP_Error( 'kerp_followup_cancel_failed', __( 'لغو پیگیری انجام نشد.', 'kasebi-erp' ) );
		}
		$this->add_history( $followup_id, 'cancelled', $note, $followup, array_merge( $followup, $data ) );
		do_action( 'kerp_followup_cancelled', $followup_id, $data, $followup );
		
		return TRUE;
	}
	
	public function reschedule( int $followup_id, string $due_at, string $note = '' ): bool|WP_Error {
		global $wpdb;
		$followup = KERP_Modules_Followups_Query::instance()->get_by_id( $followup_id );
		if ( ! is_array( $followup ) ) {
			return new WP_Error( 'kerp_followup_not_found', __( 'پیگیری پیدا نشد.', 'kasebi-erp' ) );
		}
		if ( $due_at === '' || strtotime( $due_at ) === FALSE ) {
			return new WP_Error( 'kerp_followup_invalid_due_at', __( 'تاریخ و ساعت جدید معتبر نیست.', 'kasebi-erp' ) );
		}
		$now    = current_time( 'mysql' );
		$data   = [
			'due_at'       => $due_at,
			'status'       => 'pending',
			'outcome'      => '',
			'completed_at' => NULL,
			'completed_by' => NULL,
			'updated_by'   => get_current_user_id(),
			'updated_at'   => $now,
		];
		$result = $wpdb->update( self::table(), $data, [ 'id' => $followup_id ], [
			'%s',
			'%s',
			'%s',
			NULL,
			NULL,
			'%d',
			'%s',
		], [ '%d' ] );
		if ( $result === FALSE ) {
			return new WP_Error( 'kerp_followup_reschedule_failed', __( 'زمان‌بندی مجدد پیگیری انجام نشد.', 'kasebi-erp' ) );
		}
		$this->add_history( $followup_id, 'rescheduled', $note, $followup, array_merge( $followup, $data ) );
		do_action( 'kerp_followup_rescheduled', $followup_id, $data, $followup );
		
		return TRUE;
	}
	
	public function delete( int $followup_id ): bool|WP_Error {
		global $wpdb;
		$followup = KERP_Modules_Followups_Query::instance()->get_by_id( $followup_id );
		if ( ! is_array( $followup ) ) {
			return new WP_Error( 'kerp_followup_not_found', __( 'پیگیری پیدا نشد.', 'kasebi-erp' ) );
		}
		$result = $wpdb->delete( self::table(), [ 'id' => $followup_id ], [ '%d' ] );
		if ( $result === FALSE ) {
			return new WP_Error( 'kerp_followup_delete_failed', __( 'حذف پیگیری انجام نشد.', 'kasebi-erp' ) );
		}
		$wpdb->delete( self::history_table(), [ 'followup_id' => $followup_id ], [ '%d' ] );
		do_action( 'kerp_followup_deleted', $followup_id, $followup );
		
		return TRUE;
	}
	
	public function add_history( int $followup_id, string $event_key, string $note = '', array $old_data = [], array $new_data = [] ): void {
		global $wpdb;
		$wpdb->insert(
			self::history_table(),
			[
				'followup_id' => $followup_id,
				'event_key'   => sanitize_key( $event_key ),
				'note'        => wp_kses_post( $note ),
				'old_data'    => wp_json_encode( $old_data ),
				'new_data'    => wp_json_encode( $new_data ),
				'created_by'  => get_current_user_id(),
				'created_at'  => current_time( 'mysql' ),
			],
			[ '%d', '%s', '%s', '%s', '%s', '%d', '%s' ]
		);
	}
	
	public function get_populate_data( array $followup ): array {
		$due_at    = (string) ( $followup['due_at'] ?? '' );
		$timestamp = $due_at !== ''
			? strtotime( $due_at )
			: FALSE;
		
		$metadata = json_decode(
			(string) ( $followup['metadata'] ?? '' ),
			TRUE
		);
		
		$metadata = is_array( $metadata )
			? $metadata
			: [];
		
		return [
			'followup_id' => [
				'id'    => '#kerp-followup-id',
				'type'  => 'text',
				'value' => absint( $followup['id'] ?? 0 ),
			],
			'customer_id' => [
				'id'    => '#kerp-followup-customer-id',
				'type'  => 'select',
				'value' => absint( $followup['customer_id'] ?? 0 ),
			],
			'title'       => [
				'id'    => '#kerp-followup-title',
				'type'  => 'text',
				'value' => (string) ( $followup['title'] ?? '' ),
			],
			'type_key'    => [
				'id'    => '#kerp-followup-type-key',
				'type'  => 'select',
				'value' => (string) ( $followup['type_key'] ?? '' ),
			],
			'assignee_id' => [
				'id'    => '#kerp-followup-assignee-id',
				'type'  => 'select',
				'value' => absint( $followup['assignee_id'] ?? 0 ),
			],
			'priority'    => [
				'id'    => '#kerp-followup-priority',
				'type'  => 'select',
				'value' => (string) ( $followup['priority'] ?? 'normal' ),
			],
			'due_date'    => [
				'id'    => '#kerp-followup-due-date',
				'type'  => 'text',
				'value' => $timestamp
					? date_i18n( 'Y-m-d', $timestamp )
					: '',
			],
			'due_time'    => [
				'id'    => '#kerp-followup-due-time',
				'type'  => 'text',
				'value' => $timestamp
					? wp_date( 'H:i', $timestamp )
					: '',
			],
			'description' => [
				'id'    => '#kerp-followup-description',
				'type'  => 'quill',
				'value' => (string) ( $followup['description'] ?? '' ),
			],
			'attachment'  => [
				'id'    => '#kerp-followup-attachment',
				'type'  => 'upload',
				'value' => (string) ( $metadata['attachment'] ?? '' ),
			],
		];
	}
	
	public function handle_deleted_user( int $user_id ): void {
		global $wpdb;
		$wpdb->delete( self::table(), [ 'customer_id' => $user_id ], [ '%d' ] );
	}
	
	private function is_customer( WP_User $user ): bool {
		$roles      = class_exists( 'KERP_Modules_Customers_Settings' )
			? (array) KERP_Modules_Customers_Settings::instance()->get( 'customer_roles', [ 'customer', 'subscriber' ] )
			: [ 'customer', 'subscriber' ];
		$roles      = array_values( array_filter( array_map( 'sanitize_key', $roles ) ) );
		$user_roles = array_values( array_filter( array_map( 'sanitize_key', (array) $user->roles ) ) );
		
		return ! empty( array_intersect( $roles, $user_roles ) );
	}
	
	private function maybe_install(): void {
		$version = (string) get_option( self::DB_VERSION_OPTION, '0.0.0' );
		if ( version_compare( $version, self::DB_VERSION, '<' ) ) {
			self::install();
		}
	}
	
}
