<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Followups_List_Table {
	private static ?self $instance = NULL;
	public static function instance(): self { if ( self::$instance === NULL ) { self::$instance = new self(); } return self::$instance; }
	private function __construct() {}
	private function __clone() {}
	public function __wakeup(): void { throw new LogicException( 'Cannot unserialize a singleton.' ); }

	public function get_filters( array $values = [] ): array {
		$due = isset( $values['due'] ) && is_array( $values['due'] ) ? $values['due'] : [];
		$filters = [
			'search' => [ 'key' => 'search', 'name' => 'search', 'label' => __( 'جستجو', 'kasebi-erp' ), 'type' => 'text', 'placeholder' => __( 'عنوان یا شرح پیگیری', 'kasebi-erp' ), 'value' => sanitize_text_field( (string) ( $values['search'] ?? '' ) ), 'order' => 5, 'col' => 12 ],
			'status' => [ 'key' => 'status', 'name' => 'status', 'label' => __( 'وضعیت', 'kasebi-erp' ), 'type' => 'select', 'options' => KERP_Modules_Followups_Settings::instance()->get_status_options(), 'placeholder' => __( 'همه وضعیت‌ها', 'kasebi-erp' ), 'value' => sanitize_key( (string) ( $values['status'] ?? '' ) ), 'order' => 10 ],
			'type_key' => [ 'key' => 'type_key', 'name' => 'type_key', 'label' => __( 'نوع پیگیری', 'kasebi-erp' ), 'type' => 'select', 'options' => KERP_Modules_Followups_Settings::instance()->get_type_options( FALSE ), 'placeholder' => __( 'همه انواع', 'kasebi-erp' ), 'value' => sanitize_key( (string) ( $values['type_key'] ?? '' ) ), 'order' => 20 ],
			'assignee_id' => [ 'key' => 'assignee_id', 'name' => 'assignee_id', 'label' => __( 'مسئول', 'kasebi-erp' ), 'type' => 'select', 'options' => KERP_Modules_Followups_Form::instance()->get_assignee_options(), 'placeholder' => __( 'همه کارکنان', 'kasebi-erp' ), 'value' => absint( $values['assignee_id'] ?? 0 ), 'order' => 30 ],
			'priority' => [ 'key' => 'priority', 'name' => 'priority', 'label' => __( 'اولویت', 'kasebi-erp' ), 'type' => 'select', 'options' => KERP_Modules_Followups_Settings::instance()->get_priority_options(), 'placeholder' => __( 'همه اولویت‌ها', 'kasebi-erp' ), 'value' => sanitize_key( (string) ( $values['priority'] ?? '' ) ), 'order' => 40 ],
			'due' => [ 'key' => 'due', 'name' => 'due', 'label' => __( 'سررسید', 'kasebi-erp' ), 'type' => 'date-range', 'col' => 12, 'value' => [ 'from' => $due['from'] ?? '', 'to' => $due['to'] ?? '' ], 'order' => 50 ],
		];
		$filters = apply_filters( 'kerp_followups_list_filters', $filters, $values );
		uasort( $filters, [ $this, 'sort_by_order' ] );
		return $filters;
	}

	public function sort_by_order( array $first, array $second ): int { return (int) ( $first['order'] ?? 100 ) <=> (int) ( $second['order'] ?? 100 ); }
}
