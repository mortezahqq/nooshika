<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Followups_Settings {
	public const OPTION_NAME = 'kerp_followups_settings';
	private static ?self $instance = NULL;
	private ?array $settings = NULL;

	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'update_option_' . self::OPTION_NAME, [ $this, 'clear_cache' ], 10, 0 );
		add_action( 'add_option_' . self::OPTION_NAME, [ $this, 'clear_cache' ], 10, 0 );
	}

	private function __clone() {}

	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}

	public function defaults(): array {
		return apply_filters( 'kerp_followups_default_settings', [
			'default_per_page' => 20,
			'default_priority' => 'normal',
			'types' => [
				'phone' => [ 'key' => 'phone', 'label' => __( 'تماس تلفنی', 'kasebi-erp' ), 'icon' => 'ni ni-call', 'color' => 'primary', 'order' => 10, 'active' => 1 ],
				'message' => [ 'key' => 'message', 'label' => __( 'ارسال پیام', 'kasebi-erp' ), 'icon' => 'ni ni-chat', 'color' => 'info', 'order' => 20, 'active' => 1 ],
				'meeting' => [ 'key' => 'meeting', 'label' => __( 'جلسه', 'kasebi-erp' ), 'icon' => 'ni ni-users', 'color' => 'success', 'order' => 30, 'active' => 1 ],
				'payment' => [ 'key' => 'payment', 'label' => __( 'پیگیری پرداخت', 'kasebi-erp' ), 'icon' => 'ni ni-wallet', 'color' => 'warning', 'order' => 40, 'active' => 1 ],
				'document' => [ 'key' => 'document', 'label' => __( 'دریافت مدارک', 'kasebi-erp' ), 'icon' => 'ni ni-file-docs', 'color' => 'secondary', 'order' => 50, 'active' => 1 ],
				'other' => [ 'key' => 'other', 'label' => __( 'سایر', 'kasebi-erp' ), 'icon' => 'ni ni-more-h', 'color' => 'light', 'order' => 100, 'active' => 1 ],
			],
		] );
	}

	public function all(): array {
		if ( $this->settings !== NULL ) {
			return $this->settings;
		}
		$stored = get_option( self::OPTION_NAME, [] );
		$stored = is_array( $stored ) ? $stored : [];
		$this->settings = wp_parse_args( $stored, $this->defaults() );
		$this->settings['types'] = $this->sanitize_types( $this->settings['types'] ?? [] );
		return $this->settings;
	}

	public function get( string $key, mixed $default = NULL ): mixed {
		$settings = $this->all();
		return array_key_exists( $key, $settings ) ? $settings[ $key ] : $default;
	}

	public function update( array $settings ): bool {
		$current = $this->all();
		$clean   = $this->sanitize( array_merge( $current, $settings ) );
		$result  = update_option( self::OPTION_NAME, $clean, FALSE );
		$this->settings = $clean;
		do_action( 'kerp_followups_settings_updated', $clean, $current );
		return $result || $clean === $current;
	}

	public function get_types( bool $active_only = FALSE ): array {
		$types = (array) $this->get( 'types', [] );
		if ( $active_only ) {
			$types = array_filter( $types, [ $this, 'is_type_active' ] );
		}
		uasort( $types, [ $this, 'sort_by_order' ] );
		return apply_filters( 'kerp_followup_types', $types, $active_only );
	}

	public function get_type( string $key ): array {
		$key   = sanitize_key( $key );
		$types = $this->get_types();
		return $types[ $key ] ?? [ 'key' => $key, 'label' => $key ?: __( 'سایر', 'kasebi-erp' ), 'icon' => 'ni ni-more-h', 'color' => 'light', 'order' => 100, 'active' => 1 ];
	}

	public function get_type_options( bool $active_only = TRUE ): array {
		$options = [];
		foreach ( $this->get_types( $active_only ) as $key => $type ) {
			$options[ $key ] = (string) ( $type['label'] ?? $key );
		}
		return $options;
	}

	public function get_priority_options(): array {
		return apply_filters( 'kerp_followup_priority_options', [
			'low'    => __( 'کم', 'kasebi-erp' ),
			'normal' => __( 'عادی', 'kasebi-erp' ),
			'high'   => __( 'زیاد', 'kasebi-erp' ),
			'urgent' => __( 'فوری', 'kasebi-erp' ),
		] );
	}

	public function get_status_options(): array {
		return apply_filters( 'kerp_followup_status_options', [
			'pending'   => __( 'در انتظار', 'kasebi-erp' ),
			'overdue'   => __( 'عقب‌افتاده', 'kasebi-erp' ),
			'completed' => __( 'انجام‌شده', 'kasebi-erp' ),
			'cancelled' => __( 'لغوشده', 'kasebi-erp' ),
		] );
	}

	public function save_type( array $type, string $original_key = '' ): bool|WP_Error {
		global $wpdb;
		$original_key = sanitize_key( $original_key );
		$key   = sanitize_key( (string) ( $type['key'] ?? '' ) );
		$label = sanitize_text_field( (string) ( $type['label'] ?? '' ) );
		if ( $key === '' ) {
			return new WP_Error( 'kerp_followup_type_empty_key', __( 'کلید نوع پیگیری را وارد کنید.', 'kasebi-erp' ) );
		}
		if ( $label === '' ) {
			return new WP_Error( 'kerp_followup_type_empty_label', __( 'عنوان نوع پیگیری را وارد کنید.', 'kasebi-erp' ) );
		}
		$settings = $this->all();
		$types    = isset( $settings['types'] ) && is_array( $settings['types'] ) ? $settings['types'] : [];
		if ( $original_key !== '' && ! isset( $types[ $original_key ] ) ) {
			return new WP_Error( 'kerp_followup_type_not_found', __( 'نوع پیگیری پیدا نشد.', 'kasebi-erp' ) );
		}
		if ( isset( $types[ $key ] ) && $key !== $original_key ) {
			return new WP_Error( 'kerp_followup_type_duplicate', __( 'نوع دیگری با این کلید وجود دارد.', 'kasebi-erp' ) );
		}
		$icon_classes = preg_split( '/\s+/', trim( (string) ( $type['icon'] ?? '' ) ), -1, PREG_SPLIT_NO_EMPTY );
		$icon_classes = is_array( $icon_classes ) ? array_map( 'sanitize_html_class', $icon_classes ) : [];
		$icon = implode( ' ', array_filter( $icon_classes ) );
		if ( $icon === '' ) {
			$icon = 'kik fa-clock';
		}
		$allowed_colors = [ 'primary', 'success', 'info', 'warning', 'danger', 'secondary', 'purple', 'light' ];
		$color = sanitize_key( (string) ( $type['color'] ?? 'primary' ) );
		if ( ! in_array( $color, $allowed_colors, TRUE ) ) {
			$color = 'primary';
		}
		$new_type = [
			'key'    => $key,
			'label'  => $label,
			'icon'   => $icon,
			'color'  => $color,
			'order'  => max( 0, absint( $type['order'] ?? 100 ) ),
			'active' => ! empty( $type['active'] ) ? 1 : 0,
		];
		if ( $original_key !== '' && $original_key !== $key ) {
			$changed = $wpdb->update( KERP_Modules_Followups_Module::table(), [ 'type_key' => $key ], [ 'type_key' => $original_key ], [ '%s' ], [ '%s' ] );
			if ( $changed === FALSE ) {
				return new WP_Error( 'kerp_followup_type_migration_failed', __( 'انتقال نوع پیگیری‌ها انجام نشد.', 'kasebi-erp' ) );
			}
			unset( $types[ $original_key ] );
		}
		$types[ $key ] = $new_type;
		$settings['types'] = $types;
		return $this->update( $settings );
	}

	public function delete_type( string $key, string $replacement_key ): bool|WP_Error {
		global $wpdb;
		$key             = sanitize_key( $key );
		$replacement_key = sanitize_key( $replacement_key );
		$settings        = $this->all();
		$types           = isset( $settings['types'] ) && is_array( $settings['types'] ) ? $settings['types'] : [];
		if ( $key === '' || ! isset( $types[ $key ] ) ) {
			return new WP_Error( 'kerp_followup_type_not_found', __( 'نوع پیگیری پیدا نشد.', 'kasebi-erp' ) );
		}
		if ( $replacement_key === '' || $replacement_key === $key || ! isset( $types[ $replacement_key ] ) ) {
			return new WP_Error( 'kerp_followup_invalid_replacement', __( 'نوع جایگزین معتبر نیست.', 'kasebi-erp' ) );
		}
		$changed = $wpdb->update( KERP_Modules_Followups_Module::table(), [ 'type_key' => $replacement_key ], [ 'type_key' => $key ], [ '%s' ], [ '%s' ] );
		if ( $changed === FALSE ) {
			return new WP_Error( 'kerp_followup_type_replacement_failed', __( 'جایگزینی نوع پیگیری انجام نشد.', 'kasebi-erp' ) );
		}
		unset( $types[ $key ] );
		$settings['types'] = $types;
		return $this->update( $settings );
	}

	public function sanitize( array $settings ): array {
		$defaults = $this->defaults();
		$priority = sanitize_key( (string) ( $settings['default_priority'] ?? $defaults['default_priority'] ) );
		if ( ! isset( $this->get_priority_options()[ $priority ] ) ) {
			$priority = 'normal';
		}
		$types = $this->sanitize_types( $settings['types'] ?? [] );
		if ( empty( $types ) ) {
			$types = $this->sanitize_types( $defaults['types'] );
		}
		return apply_filters( 'kerp_followups_sanitized_settings', [
			'default_per_page' => max( 1, min( 200, absint( $settings['default_per_page'] ?? $defaults['default_per_page'] ) ) ),
			'default_priority' => $priority,
			'types'            => $types,
		], $settings );
	}

	public function is_type_active( array $type ): bool {
		return ! empty( $type['active'] );
	}

	public function sort_by_order( array $first, array $second ): int {
		return (int) ( $first['order'] ?? 100 ) <=> (int) ( $second['order'] ?? 100 );
	}

	public function clear_cache(): void {
		$this->settings = NULL;
	}

	private function sanitize_types( mixed $types ): array {
		if ( ! is_array( $types ) ) {
			return [];
		}
		$clean = [];
		foreach ( $types as $type_key => $type ) {
			if ( ! is_array( $type ) ) {
				continue;
			}
			$key = sanitize_key( (string) ( $type['key'] ?? $type_key ) );
			if ( $key === '' ) {
				continue;
			}
			$icon_classes = preg_split( '/\s+/', trim( (string) ( $type['icon'] ?? '' ) ), -1, PREG_SPLIT_NO_EMPTY );
			$icon_classes = is_array( $icon_classes ) ? array_map( 'sanitize_html_class', $icon_classes ) : [];
			$clean[ $key ] = [
				'key'    => $key,
				'label'  => sanitize_text_field( (string) ( $type['label'] ?? $key ) ),
				'icon'   => implode( ' ', array_filter( $icon_classes ) ) ?: 'kik fa-clock',
				'color'  => sanitize_key( (string) ( $type['color'] ?? 'primary' ) ),
				'order'  => max( 0, absint( $type['order'] ?? 100 ) ),
				'active' => ! empty( $type['active'] ) ? 1 : 0,
			];
		}
		uasort( $clean, [ $this, 'sort_by_order' ] );
		return $clean;
	}
}
