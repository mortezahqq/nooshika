<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Followups_Query {
	private static ?self $instance = NULL;

	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {}
	private function __clone() {}
	public function __wakeup(): void { throw new LogicException( 'Cannot unserialize a singleton.' ); }

	public function get_by_id( int $followup_id ): ?array {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . KERP_Modules_Followups_Module::table() . ' WHERE id = %d LIMIT 1', $followup_id ), ARRAY_A );
		return is_array( $row ) ? $this->prepare_item( $row ) : NULL;
	}

	public function find( array $args = [] ): array {
		global $wpdb;
		$defaults = [
			'per_page'    => (int) KERP_Modules_Followups_Settings::instance()->get( 'default_per_page', 20 ),
			'page_number' => 1,
			'customer_id' => 0,
			'assignee_id' => 0,
			'type_key'    => '',
			'priority'    => '',
			'status'      => '',
			'due_from'    => '',
			'due_to'      => '',
			'search'      => '',
			'orderby'     => 'due_at',
			'order'       => 'ASC',
		];
		$args = wp_parse_args( $args, $defaults );
		$args = apply_filters( 'kerp_followups_query_args', $args );
		$scope = kerp_list_scope( 'followups' );
		if ( $scope === 'none' ) {
			return $this->empty_result( $args );
		}
		if ( $scope === 'own' ) {
			$args['assignee_id'] = get_current_user_id();
		}
		$where  = [ '1=1' ];
		$params = [];
		$customer_id = absint( $args['customer_id'] );
		if ( $customer_id > 0 ) { $where[] = 'customer_id = %d'; $params[] = $customer_id; }
		$assignee_id = absint( $args['assignee_id'] );
		if ( $assignee_id > 0 ) { $where[] = 'assignee_id = %d'; $params[] = $assignee_id; }
		$type_key = sanitize_key( (string) $args['type_key'] );
		if ( $type_key !== '' ) { $where[] = 'type_key = %s'; $params[] = $type_key; }
		$priority = sanitize_key( (string) $args['priority'] );
		if ( $priority !== '' ) { $where[] = 'priority = %s'; $params[] = $priority; }
		$status = sanitize_key( (string) $args['status'] );
		if ( $status === 'overdue' ) {
			$where[] = "status = 'pending'";
			$where[] = 'due_at < %s';
			$params[] = current_time( 'mysql' );
		} elseif ( $status !== '' ) {
			$where[] = 'status = %s';
			$params[] = $status;
		}
		$due_from = sanitize_text_field( (string) $args['due_from'] );
		if ( $due_from !== '' ) { $where[] = 'due_at >= %s'; $params[] = $due_from . ( strlen( $due_from ) === 10 ? ' 00:00:00' : '' ); }
		$due_to = sanitize_text_field( (string) $args['due_to'] );
		if ( $due_to !== '' ) { $where[] = 'due_at <= %s'; $params[] = $due_to . ( strlen( $due_to ) === 10 ? ' 23:59:59' : '' ); }
		$search = sanitize_text_field( (string) $args['search'] );
		if ( $search !== '' ) {
			$like = '%' . $wpdb->esc_like( $search ) . '%';
			$where[] = '(title LIKE %s OR description LIKE %s OR outcome LIKE %s)';
			$params = array_merge( $params, [ $like, $like, $like ] );
		}
		$where_sql = implode( ' AND ', $where );
		$table = KERP_Modules_Followups_Module::table();
		$count_sql = "SELECT COUNT(*) FROM {$table} WHERE {$where_sql}";
		$total = (int) $wpdb->get_var( empty( $params ) ? $count_sql : $wpdb->prepare( $count_sql, ...$params ) );
		$allowed_orderby = [ 'due_at', 'created_at', 'updated_at', 'priority', 'status', 'id' ];
		$orderby = sanitize_key( (string) $args['orderby'] );
		if ( ! in_array( $orderby, $allowed_orderby, TRUE ) ) { $orderby = 'due_at'; }
		$order = strtoupper( (string) $args['order'] ) === 'DESC' ? 'DESC' : 'ASC';
		$per_page = max( 1, min( 200, absint( $args['per_page'] ) ) );
		$page_number = max( 1, absint( $args['page_number'] ) );
		$offset = ( $page_number - 1 ) * $per_page;
		$list_sql = "SELECT * FROM {$table} WHERE {$where_sql} ORDER BY {$orderby} {$order}, id DESC LIMIT %d OFFSET %d";
		$list_params = array_merge( $params, [ $per_page, $offset ] );
		$rows = $wpdb->get_results( $wpdb->prepare( $list_sql, ...$list_params ), ARRAY_A );
		$items = [];
		foreach ( (array) $rows as $row ) {
			if ( is_array( $row ) ) { $items[] = $this->prepare_item( $row ); }
		}
		$result = [
			'items'        => $items,
			'total'        => $total,
			'per_page'     => $per_page,
			'page_number'  => $page_number,
			'total_pages'  => $per_page > 0 ? (int) ceil( $total / $per_page ) : 0,
			'request_args' => $args,
		];
		return apply_filters( 'kerp_followups_query_results', $result, $args );
	}

	public function get_customer_items( int $customer_id, int $limit = 50 ): array {
		$result = $this->find( [ 'customer_id' => $customer_id, 'per_page' => $limit, 'page_number' => 1 ] );
		return (array) ( $result['items'] ?? [] );
	}

	public function get_history( int $followup_id ): array {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . KERP_Modules_Followups_Module::history_table() . ' WHERE followup_id = %d ORDER BY created_at DESC, id DESC', $followup_id ), ARRAY_A );
		return is_array( $rows ) ? $rows : [];
	}

	public function get_counts( int $assignee_id = 0 ): array {
		global $wpdb;
		$table = KERP_Modules_Followups_Module::table();
		$where = '1=1';
		$params = [];
		$scope = kerp_list_scope( 'followups' );
		if ( $scope === 'none' ) { return [ 'pending' => 0, 'overdue' => 0, 'today' => 0, 'completed' => 0 ]; }
		if ( $scope === 'own' ) { $assignee_id = get_current_user_id(); }
		if ( $assignee_id > 0 ) { $where .= ' AND assignee_id = %d'; $params[] = $assignee_id; }
		$now = current_time( 'mysql' );
		$today_start = current_time( 'Y-m-d' ) . ' 00:00:00';
		$today_end = current_time( 'Y-m-d' ) . ' 23:59:59';
		$sql = "SELECT
			SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) AS pending,
			SUM(CASE WHEN status = 'pending' AND due_at < %s THEN 1 ELSE 0 END) AS overdue,
			SUM(CASE WHEN status = 'pending' AND due_at BETWEEN %s AND %s THEN 1 ELSE 0 END) AS today,
			SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) AS completed
			FROM {$table} WHERE {$where}";
		$all_params = array_merge( [ $now, $today_start, $today_end ], $params );
		$row = $wpdb->get_row( $wpdb->prepare( $sql, ...$all_params ), ARRAY_A );
		return [
			'pending'   => absint( $row['pending'] ?? 0 ),
			'overdue'   => absint( $row['overdue'] ?? 0 ),
			'today'     => absint( $row['today'] ?? 0 ),
			'completed' => absint( $row['completed'] ?? 0 ),
		];
	}

	private function prepare_item( array $row ): array {
		$row['id']           = absint( $row['id'] ?? 0 );
		$row['customer_id']  = absint( $row['customer_id'] ?? 0 );
		$row['assignee_id']  = absint( $row['assignee_id'] ?? 0 );
		$row['created_by']   = absint( $row['created_by'] ?? 0 );
		$row['updated_by']   = absint( $row['updated_by'] ?? 0 );
		$row['completed_by'] = absint( $row['completed_by'] ?? 0 );
		$row['is_overdue']   = (string) ( $row['status'] ?? '' ) === 'pending' && strtotime( (string) ( $row['due_at'] ?? '' ) ) < current_time( 'timestamp' );
		$row['display_status'] = $row['is_overdue'] ? 'overdue' : sanitize_key( (string) ( $row['status'] ?? 'pending' ) );
		return $row;
	}

	private function empty_result( array $args ): array {
		return [ 'items' => [], 'total' => 0, 'per_page' => max( 1, absint( $args['per_page'] ?? 20 ) ), 'page_number' => max( 1, absint( $args['page_number'] ?? 1 ) ), 'total_pages' => 0, 'request_args' => $args ];
	}
}
