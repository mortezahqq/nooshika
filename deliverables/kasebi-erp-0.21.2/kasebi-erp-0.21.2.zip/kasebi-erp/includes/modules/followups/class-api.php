<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Followups_Api {
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {
		add_action( 'kasebi_ajax_followups_save', [ $this, 'save' ] );
		add_action( 'kasebi_ajax_followups_complete', [ $this, 'complete' ] );
		add_action( 'kasebi_ajax_followups_cancel', [ $this, 'cancel' ] );
		add_action( 'kasebi_ajax_followups_reschedule', [ $this, 'reschedule' ] );
		add_action( 'kasebi_ajax_followups_delete', [ $this, 'delete' ] );
		add_action( 'kasebi_ajax_followups_save_settings', [ $this, 'save_settings' ] );
		add_action( 'kasebi_ajax_followups_save_type', [ $this, 'save_type' ] );
		add_action( 'kasebi_ajax_followups_delete_type', [ $this, 'delete_type' ] );
	}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public function save(): void {
		$followup_id = absint( $_POST['followup_id'] ?? 0 );
		$this->guard( $followup_id > 0 ? 'followups.edit' : 'followups.create' );
		$due_at = KERP_Modules_Followups_Form::instance()
		                                     ->combine_datetime( $this->post_text( 'due_date' ), $this->post_text( 'due_time' ) );
		if ( is_wp_error( $due_at ) ) {
			$this->error( $due_at->get_error_message() );
		}
		if ( $followup_id > 0 ) {
			$this->guard_item_scope( $followup_id );
		}
		$assignee_id = absint( $_POST['assignee_id'] ?? 0 );
		if ( kerp_list_scope( 'followups' ) === 'own' ) {
			$assignee_id = get_current_user_id();
		}
		$attachment = esc_url_raw( $this->post_text( 'attachment' ) );
		$result     = KERP_Modules_Followups_Module::instance()->save( [
			'customer_id' => absint( $_POST['customer_id'] ?? 0 ),
			'type_key'    => $this->post_text( 'type_key' ),
			'title'       => $this->post_text( 'title' ),
			'description' => $this->post_raw_text( 'description' ),
			'due_at'      => $due_at,
			'assignee_id' => $assignee_id,
			'priority'    => $this->post_text( 'priority' ),
			'status'      => 'pending',
			'metadata'    => [
				'attachment' => $attachment,
			],
		], $followup_id );
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		$page          = $this->return_page();
		$page_response = KERP_Api_Page_Content::build_page_response( $page, $this->route_query( $page ), TRUE );
		$this->success( $followup_id > 0 ? __( 'پیگیری با موفقیت ویرایش شد.', 'kasebi-erp' ) : __( 'پیگیری با موفقیت ثبت شد.', 'kasebi-erp' ), $page_response );
	}
	
	public function complete(): void {
		$this->guard( 'followups.complete' );
		$this->guard_item_scope( absint( $_POST['followup_id'] ?? 0 ) );
		$result = KERP_Modules_Followups_Module::instance()
		                                       ->complete( absint( $_POST['followup_id'] ?? 0 ), $this->post_raw_text( 'outcome' ) );
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		$page = $this->return_page();
		$this->success( __( 'پیگیری با موفقیت انجام شد.', 'kasebi-erp' ), KERP_Api_Page_Content::build_page_response( $page, $this->route_query( $page ), TRUE ) );
	}
	
	public function cancel(): void {
		$this->guard( 'followups.cancel' );
		$this->guard_item_scope( absint( $_POST['followup_id'] ?? 0 ) );
		$result = KERP_Modules_Followups_Module::instance()
		                                       ->cancel( absint( $_POST['followup_id'] ?? 0 ), $this->post_raw_text( 'note' ) );
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		$page = $this->return_page();
		$this->success( __( 'پیگیری لغو شد.', 'kasebi-erp' ), KERP_Api_Page_Content::build_page_response( $page, $this->route_query( $page ), TRUE ) );
	}
	
	public function reschedule(): void {
		$this->guard( 'followups.edit' );
		$this->guard_item_scope( absint( $_POST['followup_id'] ?? 0 ) );
		$due_at = KERP_Modules_Followups_Form::instance()
		                                     ->combine_datetime( $this->post_text( 'due_date' ), $this->post_text( 'due_time' ) );
		if ( is_wp_error( $due_at ) ) {
			$this->error( $due_at->get_error_message() );
		}
		$result = KERP_Modules_Followups_Module::instance()
		                                       ->reschedule( absint( $_POST['followup_id'] ?? 0 ), $due_at, $this->post_raw_text( 'note' ) );
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		$page = $this->return_page();
		$this->success( __( 'زمان پیگیری تغییر کرد.', 'kasebi-erp' ), KERP_Api_Page_Content::build_page_response( $page, $this->route_query( $page ), TRUE ) );
	}
	
	public function delete(): void {
		$this->guard( 'followups.delete' );
		$this->guard_item_scope( absint( $_POST['followup_id'] ?? $_POST['item_id'] ?? 0 ) );
		$result = KERP_Modules_Followups_Module::instance()
		                                       ->delete( absint( $_POST['followup_id'] ?? $_POST['item_id'] ?? 0 ) );
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		$page = $this->return_page();
		$this->success( __( 'پیگیری حذف شد.', 'kasebi-erp' ), KERP_Api_Page_Content::build_page_response( $page, $this->route_query( $page ), TRUE ) );
	}
	
	public function save_settings(): void {
		$this->guard( 'followups.manage_settings' );
		$settings = isset( $_POST['settings'] ) && is_array( $_POST['settings'] ) ? wp_unslash( $_POST['settings'] ) : [];
		KERP_Modules_Followups_Settings::instance()->update( $settings );
		$page = '/erp/settings/followups/';
		$this->success( __( 'تنظیمات پیگیری‌ها ذخیره شد.', 'kasebi-erp' ), KERP_Api_Page_Content::build_page_response( $page, [], TRUE ) );
	}
	
	public function save_type(): void {
		$this->guard( 'followups.manage_settings' );
		$type   = isset( $_POST['type'] ) && is_array( $_POST['type'] ) ? wp_unslash( $_POST['type'] ) : [];
		$result = KERP_Modules_Followups_Settings::instance()->save_type( $type, $this->post_text( 'original_key' ) );
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		$page = '/erp/settings/followups/';
		$this->success( __( 'نوع پیگیری ذخیره شد.', 'kasebi-erp' ), KERP_Api_Page_Content::build_page_response( $page, [], TRUE ) );
	}
	
	public function delete_type(): void {
		$this->guard( 'followups.manage_settings' );
		$result = KERP_Modules_Followups_Settings::instance()
		                                         ->delete_type( $this->post_text( 'type_key' ) ?: $this->post_text( 'item_id' ), $this->post_text( 'replacement_key' ) );
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		$page = '/erp/settings/followups/';
		$this->success( __( 'نوع پیگیری حذف شد.', 'kasebi-erp' ), KERP_Api_Page_Content::build_page_response( $page, [], TRUE ) );
	}
	
	private function guard_item_scope( int $followup_id ): void {
		$followup = KERP_Modules_Followups_Query::instance()->get_by_id( $followup_id );
		if ( ! is_array( $followup ) ) {
			$this->error( __( 'پیگیری پیدا نشد.', 'kasebi-erp' ) );
		}
		$scope = kerp_list_scope( 'followups' );
		if ( $scope === 'all' ) {
			return;
		}
		if ( $scope === 'own' && absint( $followup['assignee_id'] ?? 0 ) === get_current_user_id() ) {
			return;
		}
		$this->error( __( 'به این پیگیری دسترسی ندارید.', 'kasebi-erp' ) );
	}
	
	private function guard( string $permission ): void {
		if ( ! kerp_can( $permission, 'action' ) ) {
			$this->error( __( 'دسترسی لازم را ندارید.', 'kasebi-erp' ) );
		}
	}
	
	private function post_text( string $key ): string {
		return isset( $_POST[ $key ] ) && ! is_array( $_POST[ $key ] ) ? sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) : '';
	}
	
	private function post_raw_text( string $key ): string {
		return isset( $_POST[ $key ] ) && ! is_array( $_POST[ $key ] ) ? wp_kses_post( wp_unslash( $_POST[ $key ] ) ) : '';
	}
	
	private function return_page(): string {
		$page = $this->post_text( 'return_page' ) ?: $this->post_text( 'page' );
		
		return str_starts_with( $page, '/erp/' ) ? $page : '/erp/followups/';
	}
	
	private function route_query( string $page ): array {
		$query = wp_parse_url( $page, PHP_URL_QUERY );
		if ( ! is_string( $query ) || $query === '' ) {
			return [];
		}
		parse_str( $query, $args );
		
		return is_array( $args ) ? $args : [];
	}
	
	private function success( string $message, array $data = [] ): never {
		wp_send_json( array_merge( [ 'status' => 'success', 'message' => $message, 'msg' => $message ], $data ) );
	}
	
	private function error( string $message, array $data = [] ): never {
		wp_send_json( array_merge( [ 'status' => 'error', 'message' => $message, 'msg' => $message ], $data ) );
	}
	
}
