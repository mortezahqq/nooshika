<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Followups_Form {
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public function render_modal( int $customer_id = 0, string $return_page = '/erp/followups/', string $modal_id = 'followupModal' ): void {
		KERP_Helpers_Template::render_template( 'modules/followups/modals/followup-form.php', [
			'customer_id' => $customer_id,
			'return_page' => $return_page,
			'modal_id'    => $modal_id,
		] );
	}
	
	public function render_action_modals( string $return_page = '/erp/followups/', string $context = 'main' ): void {
		KERP_Helpers_Template::render_template( 'modules/followups/modals/action-modals.php', [
			'return_page' => $return_page,
			'context'     => $context,
		] );
	}
	
	public function get_assignee_options( int $current_assignee_id = 0 ): array {
		$options             = class_exists( 'KERP_Modules_Employees_Query' ) ? KERP_Modules_Employees_Query::instance()
		                                                                                                    ->get_options() : [];
		$current_assignee_id = absint( $current_assignee_id );
		if ( $current_assignee_id > 0 && ! isset( $options[ $current_assignee_id ] ) ) {
			$user = get_userdata( $current_assignee_id );
			if ( $user instanceof WP_User ) {
				$options[ $current_assignee_id ] = sprintf( __( '%s — خارج از فهرست کارکنان', 'kasebi-erp' ), get_user_name_by_id( $current_assignee_id ) );
			}
		}
		
		return apply_filters( 'kerp_followups_assignee_options', is_array( $options ) ? $options : [] );
	}
	
	public function get_creator_options(): array {
		global $wpdb;
		$employee_ids = class_exists( 'KERP_Services_Access' ) ? $wpdb->get_col( 'SELECT DISTINCT user_id FROM ' . KERP_Services_Access::table() . " WHERE role_key IS NOT NULL AND role_key <> ''" ) : [];
		$creator_ids  = $wpdb->get_col( 'SELECT DISTINCT created_by FROM ' . KERP_Modules_Followups_Module::table() . ' WHERE created_by > 0' );
		$user_ids     = array_values( array_unique( array_filter( array_map( 'absint', array_merge( (array) $employee_ids, (array) $creator_ids ) ) ) ) );
		$user_ids     = apply_filters( 'kerp_followups_creator_user_ids', $user_ids );
		$options      = [];
		foreach ( (array) $user_ids as $user_id ) {
			$user_id = absint( $user_id );
			if ( $user_id <= 0 ) {
				continue;
			}
			$user                = get_userdata( $user_id );
			$options[ $user_id ] = $user instanceof WP_User ? get_user_name_by_id( $user_id ) : sprintf( __( 'کاربر حذف‌شده #%s', 'kasebi-erp' ), number_format_i18n( $user_id ) );
		}
		asort( $options, SORT_NATURAL | SORT_FLAG_CASE );
		
		return apply_filters( 'kerp_followups_creator_options', $options );
	}
	
	public function combine_datetime( string $date, string $time ): string|WP_Error {
		$date = sanitize_text_field( $date );
		$time = sanitize_text_field( $time );
		
		if ( function_exists( 'nooshika_sanitize_numbers' ) ) {
			$date = nooshika_sanitize_numbers( $date );
			$time = nooshika_sanitize_numbers( $time );
		}
		
		$date = trim( str_replace( '/', '-', $date ) );
		$time = trim( $time );
		
		if ( $date === '' || $time === '' ) {
			return new WP_Error(
				'kerp_followup_missing_datetime',
				__( 'تاریخ و ساعت سررسید را وارد کنید.', 'kasebi-erp' )
			);
		}
		
		if (
			class_exists( 'KERP_Helpers_Date' )
			&& method_exists( 'KERP_Helpers_Date', 'jalali_to_gregorian' )
		) {
			$converted = KERP_Helpers_Date::jalali_to_gregorian( $date );
			
			if ( is_string( $converted ) && $converted !== '' ) {
				$date = str_replace( '/', '-', $converted );
			}
		}
		
		$time = preg_replace(
			'/\b([ap])\.?\s*m\.?\b/i',
			'$1M',
			$time
		);
		
		$time = preg_replace(
			'/\s*(AM|PM)$/i',
			' $1',
			(string) $time
		);
		
		$time = strtoupper(
			trim(
				preg_replace(
					'/\s+/u',
					' ',
					(string) $time
				)
			)
		);
		
		$formats = preg_match( '/\b(?:AM|PM)$/i', $time )
			? [
				'!Y-m-d g:i A',
				'!Y-m-d g:i:s A',
			]
			: [
				'!Y-m-d H:i',
				'!Y-m-d H:i:s',
			];
		
		foreach ( $formats as $format ) {
			$date_time = DateTimeImmutable::createFromFormat(
				$format,
				$date . ' ' . $time,
				wp_timezone()
			);
			
			$errors = DateTimeImmutable::getLastErrors();
			
			if (
				$date_time instanceof DateTimeImmutable
				&& (
					$errors === FALSE
					|| (
						(int) $errors['warning_count'] === 0
						&& (int) $errors['error_count'] === 0
					)
				)
			) {
				return $date_time->format( 'Y-m-d H:i:s' );
			}
		}
		
		return new WP_Error(
			'kerp_followup_invalid_datetime',
			__( 'تاریخ و ساعت سررسید معتبر نیست.', 'kasebi-erp' )
		);
	}
	
}
