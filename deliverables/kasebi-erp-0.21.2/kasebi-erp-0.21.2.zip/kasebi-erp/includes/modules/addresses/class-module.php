<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Addresses_Module {
	
	private const META_KEY                = 'kerp_customer_addresses';
	
	private const LEGACY_META_KEY         = 'address_list';
	
	private const DEFAULT_META_KEY        = 'kerp_customer_default_address';
	
	private const LEGACY_DEFAULT_META_KEY = 'default_address';
	
	private const ORDER_META_KEY          = 'address_id';
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {
		KERP_Modules_Addresses_Api::instance();
		$this->register_hooks();
	}
	
	public function render_address_modal(
		int $customer_id,
		string $context = 'customer',
		int $order_id = 0,
		string $selected_address_id = ''
	): void {
		$state_options = $this->get_state_options();
		
		KERP_Helpers_Template::render_modal(
			[
				'id'     => 'customerAddressModal',
				'title'  => __( 'افزودن یا ویرایش آدرس', 'kasebi-erp' ),
				'action' => 'addresses_save',
				'page'   => '',
				'button' => __( 'ذخیره آدرس', 'kasebi-erp' ),
				'size'   => 'lg',
				'fields' => [
					[
						'id'          => 'kerp-address-context',
						'name'        => 'context',
						'type'        => 'hidden',
						'input_class' => 'no_clear',
						'value'       => $context,
					],
					[
						'id'          => 'kerp-address-customer-id',
						'name'        => 'address_customer_id',
						'type'        => 'hidden',
						'input_class' => 'no_clear',
						'value'       => $customer_id,
					],
					[
						'id'          => 'kerp-address-order-id',
						'name'        => 'order_id',
						'type'        => 'hidden',
						'input_class' => 'no_clear',
						'value'       => $order_id,
					],
					[
						'id'          => 'kerp-address-selected-id',
						'name'        => 'selected_address_id',
						'type'        => 'hidden',
						'input_class' => 'no_clear',
						'value'       => $selected_address_id,
					],
					[
						'id'    => 'kerp-address-id',
						'name'  => 'address[id]',
						'type'  => 'hidden',
						'value' => '',
					],
					[
						'id'    => 'kerp-address-first-name',
						'name'  => 'address[first_name]',
						'label' => __( 'نام گیرنده', 'kasebi-erp' ),
						'type'  => 'text',
						'col'   => 6,
						'value' => '',
					],
					[
						'id'    => 'kerp-address-last-name',
						'name'  => 'address[last_name]',
						'label' => __( 'نام خانوادگی گیرنده', 'kasebi-erp' ),
						'type'  => 'text',
						'col'   => 6,
						'value' => '',
					],
					[
						'id'    => 'kerp-address-phone',
						'name'  => 'address[phone]',
						'label' => __( 'شماره تماس گیرنده', 'kasebi-erp' ),
						'type'  => 'text',
						'col'   => 6,
						'value' => '',
					],
					[
						'key'         => 'state',
						'id'          => 'kerp-address-state',
						'name'        => 'address[state]',
						'label'       => __( 'استان', 'kasebi-erp' ),
						'type'        => 'select',
						'placeholder' => __( 'انتخاب استان', 'kasebi-erp' ),
						'options'     => $state_options,
						'value'       => '',
						'col'         => 6,
						'input_class' => 'load_city',
						'search'      => TRUE,
						'required'    => TRUE,
						'data'        => [
							'target' => '#kerp-address-city',
						],
					],
					[
						'key'         => 'city',
						'id'          => 'kerp-address-city',
						'name'        => 'address[city]',
						'label'       => __( 'شهر', 'kasebi-erp' ),
						'type'        => 'select',
						'placeholder' => __( 'انتخاب شهر', 'kasebi-erp' ),
						'options'     => [],
						'value'       => '',
						'col'         => 6,
						'search'      => TRUE,
						'required'    => TRUE,
					],
					[
						'id'    => 'kerp-address-region',
						'name'  => 'address[region]',
						'label' => __( 'منطقه / محله', 'kasebi-erp' ),
						'type'  => 'text',
						'col'   => 6,
						'value' => '',
					],
					[
						'id'    => 'kerp-address-section',
						'name'  => 'address[section]',
						'label' => __( 'کوچه / بخش', 'kasebi-erp' ),
						'type'  => 'text',
						'col'   => 6,
						'value' => '',
					],
					[
						'id'    => 'kerp-address-postcode',
						'name'  => 'address[postcode]',
						'label' => __( 'کدپستی', 'kasebi-erp' ),
						'type'  => 'text',
						'col'   => 6,
						'value' => '',
					],
					[
						'id'       => 'kerp-address-line',
						'name'     => 'address[address_1]',
						'label'    => __( 'نشانی کامل', 'kasebi-erp' ),
						'type'     => 'text',
						'value'    => '',
						'required' => TRUE,
					],
				],
			]
		);
	}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	private function register_hooks(): void {
		add_filter( 'kerp_customer_profile_tabs', [ $this, 'register_customer_tab' ], 25, 3 );
		add_action( 'kerp_orders_form_address', [ $this, 'render_order_address' ], 20, 3 );
		add_filter( 'kerp_orders_api_save_data', [ $this, 'inject_order_address_id' ], 20, 3 );
		add_action( 'kerp_orders_before_order_save', [ $this, 'apply_order_address' ], 20, 3 );
		add_action( 'kerp_footer_template', [ $this, 'render_address_footer_modal' ] );
	}
	
	public function register_customer_tab( array $tabs, int $customer_id, WP_User $customer ): array {
		$tabs['addresses'] = [
			'key'        => 'addresses',
			'title'      => __( 'آدرس‌ها', 'kasebi-erp' ),
			'icon'       => 'ni ni-map-pin',
			'order'      => 20,
			'group'      => 'customer-information',
			'permission' => 'customers',
			'action'     => 'view',
			'template'   => 'modules/addresses/tabs/customer-addresses.php',
		];
		
		return $tabs;
	}
	
	public function render_order_address( ?WC_Order $order, int $customer_id, string $mode ): void {
		KERP_Helpers_Template::render_template(
			'modules/addresses/order/address-selector.php',
			[
				'order'       => $order,
				'customer_id' => $customer_id,
				'mode'        => $mode,
			]
		);
	}
	
	public function inject_order_address_id( array $data, array $raw_payload, int $order_id ): array {
		$address_id = isset( $raw_payload['address_id'] ) && ! is_array( $raw_payload['address_id'] )
			? sanitize_key( (string) $raw_payload['address_id'] )
			: '';
		
		$data['address_id'] = $address_id;
		
		return $data;
	}
	
	public function apply_order_address( WC_Order $order, array $data, bool $is_new ): void {
		$customer_id = absint( $data['customer_id'] ?? $order->get_customer_id() );
		$address_id  = sanitize_key( (string) ( $data['address_id'] ?? '' ) );
		
		if ( $customer_id <= 0 || $address_id === '' ) {
			return;
		}
		
		$address = $this->get_address( $customer_id, $address_id );
		
		if ( empty( $address ) ) {
			return;
		}
		
		$first_name = sanitize_text_field( (string) ( $address['first_name'] ?? '' ) );
		$last_name  = sanitize_text_field( (string) ( $address['last_name'] ?? '' ) );
		$phone      = sanitize_text_field( (string) ( $address['phone'] ?? '' ) );
		$postcode   = sanitize_text_field( (string) ( $address['postcode'] ?? '' ) );
		$state      = sanitize_text_field( (string) ( $address['state'] ?? '' ) );
		$city       = sanitize_text_field( (string) ( $address['city'] ?? '' ) );
		$address_1  = $this->get_address_line( $address );
		
		$order->set_billing_first_name( $first_name );
		$order->set_billing_last_name( $last_name );
		$order->set_billing_phone( $phone );
		$order->set_billing_postcode( $postcode );
		$order->set_billing_country( 'IR' );
		$order->set_billing_state( $state );
		$order->set_billing_city( $city );
		$order->set_billing_address_1( $address_1 );
		$order->set_billing_address_2( '' );
		
		$order->set_shipping_first_name( $first_name );
		$order->set_shipping_last_name( $last_name );
		$order->set_shipping_postcode( $postcode );
		$order->set_shipping_country( 'IR' );
		$order->set_shipping_state( $state );
		$order->set_shipping_city( $city );
		$order->set_shipping_address_1( $address_1 );
		$order->set_shipping_address_2( '' );
		$order->update_meta_data( self::ORDER_META_KEY, $address_id );
		
		do_action(
			'kerp_addresses_order_address_applied',
			$order,
			$address,
			$address_id,
			$is_new
		);
	}
	
	public function render_address_footer_modal(): void {
		$this->render_address_modal(
			0,
			'order',
			0,
			''
		);
	}
	
	public function get_addresses( int $customer_id ): array {
		$customer_id = absint( $customer_id );
		
		if ( $customer_id <= 0 ) {
			return [];
		}
		
		$raw = get_user_meta( $customer_id, self::META_KEY, TRUE );
		
		if ( ! is_array( $raw ) || empty( $raw ) ) {
			$raw = $this->get_legacy_addresses( $customer_id );
			
			if ( ! empty( $raw ) ) {
				update_user_meta( $customer_id, self::META_KEY, $raw );
			}
		}
		
		if ( ! is_array( $raw ) ) {
			return [];
		}
		
		$addresses = [];
		
		foreach ( $raw as $key => $address ) {
			if ( ! is_array( $address ) ) {
				continue;
			}
			
			$address_id = sanitize_key( (string) ( $address['id'] ?? $key ) );
			
			if ( $address_id === '' ) {
				continue;
			}
			
			$addresses[ $address_id ] = $this->normalize_address( $address, $address_id );
		}
		
		return $addresses;
	}
	
	public function get_address( int $customer_id, string $address_id ): array {
		$address_id = sanitize_key( $address_id );
		$addresses  = $this->get_addresses( $customer_id );
		
		return isset( $addresses[ $address_id ] ) && is_array( $addresses[ $address_id ] )
			? $addresses[ $address_id ]
			: [];
	}
	
	public function get_default_address_id( int $customer_id ): string {
		$addresses = $this->get_addresses( $customer_id );
		
		if ( empty( $addresses ) ) {
			return '';
		}
		
		$default_id = sanitize_key(
			(string) get_user_meta( $customer_id, self::DEFAULT_META_KEY, TRUE )
		);
		
		if ( $default_id === '' ) {
			$default_id = sanitize_key(
				(string) get_user_meta( $customer_id, self::LEGACY_DEFAULT_META_KEY, TRUE )
			);
		}
		
		if ( $default_id !== '' && isset( $addresses[ $default_id ] ) ) {
			return $default_id;
		}
		
		$default_id = (string) array_key_first( $addresses );
		update_user_meta( $customer_id, self::DEFAULT_META_KEY, $default_id );
		
		return $default_id;
	}
	
	public function save_address( int $customer_id, array $data, string $address_id = '' ): string|WP_Error {
		$customer = get_userdata( $customer_id );
		
		if ( ! $customer instanceof WP_User ) {
			return new WP_Error(
				'kerp_addresses_customer_not_found',
				sprintf( __( '%s پیدا نشد.', 'kasebi-erp' ), KERP_Modules_Customers_Settings::instance()->get_singular_label() )
			);
		}
		
		$addresses  = $this->get_addresses( $customer_id );
		$address_id = sanitize_key( $address_id );
		
		if ( $address_id === '' ) {
			$address_id = $this->generate_address_id( $addresses );
		}
		
		$first_name = sanitize_text_field( (string) ( $data['first_name'] ?? '' ) );
		$last_name  = sanitize_text_field( (string) ( $data['last_name'] ?? '' ) );
		$phone      = sanitize_text_field( (string) ( $data['phone'] ?? '' ) );
		$state      = sanitize_text_field( (string) ( $data['state'] ?? '' ) );
		$city       = sanitize_text_field( (string) ( $data['city'] ?? '' ) );
		$address_1  = sanitize_textarea_field( (string) ( $data['address_1'] ?? '' ) );
		
		if ( $first_name === '' ) {
			$first_name = sanitize_text_field( (string) get_user_meta( $customer_id, 'first_name', TRUE ) );
		}
		
		if ( $last_name === '' ) {
			$last_name = sanitize_text_field( (string) get_user_meta( $customer_id, 'last_name', TRUE ) );
		}
		
		if ( $phone === '' ) {
			$phone = sanitize_text_field( (string) get_user_meta( $customer_id, 'nooshika_phone_num', TRUE ) );
		}
		
		if ( $state === '' || $city === '' || $address_1 === '' ) {
			return new WP_Error(
				'kerp_addresses_required_fields',
				__( 'استان، شهر و نشانی کامل را وارد کنید.', 'kasebi-erp' )
			);
		}
		
		$address = $this->normalize_address(
			[
				'id'         => $address_id,
				'title'      => sanitize_text_field( (string) ( $data['title'] ?? '' ) ),
				'first_name' => $first_name,
				'last_name'  => $last_name,
				'phone'      => $phone,
				'state'      => $state,
				'city'       => $city,
				'region'     => sanitize_text_field( (string) ( $data['region'] ?? '' ) ),
				'section'    => sanitize_text_field( (string) ( $data['section'] ?? '' ) ),
				'address_1'  => $address_1,
				'postcode'   => sanitize_text_field( (string) ( $data['postcode'] ?? '' ) ),
			],
			$address_id
		);
		
		$addresses[ $address_id ] = $address;
		update_user_meta( $customer_id, self::META_KEY, $addresses );
		
		$is_default = ! empty( $data['is_default'] ) || count( $addresses ) === 1;
		
		if ( $is_default ) {
			$this->set_default_address( $customer_id, $address_id );
		}
		
		do_action( 'kerp_customer_address_saved', $customer_id, $address_id, $address );
		
		return $address_id;
	}
	
	public function delete_address( int $customer_id, string $address_id ): bool|WP_Error {
		$address_id = sanitize_key( $address_id );
		$addresses  = $this->get_addresses( $customer_id );
		
		if ( $address_id === '' || ! isset( $addresses[ $address_id ] ) ) {
			return new WP_Error(
				'kerp_addresses_not_found',
				__( 'آدرس پیدا نشد.', 'kasebi-erp' )
			);
		}
		
		unset( $addresses[ $address_id ] );
		update_user_meta( $customer_id, self::META_KEY, $addresses );
		
		$default_id = $this->get_default_address_id( $customer_id );
		
		if ( $default_id === $address_id || ! isset( $addresses[ $default_id ] ) ) {
			$new_default_id = ! empty( $addresses )
				? (string) array_key_first( $addresses )
				: '';
			
			if ( $new_default_id !== '' ) {
				$this->set_default_address( $customer_id, $new_default_id );
			} else {
				delete_user_meta( $customer_id, self::DEFAULT_META_KEY );
			}
		}
		
		do_action( 'kerp_customer_address_deleted', $customer_id, $address_id );
		
		return TRUE;
	}
	
	public function set_default_address( int $customer_id, string $address_id ): bool|WP_Error {
		$address_id = sanitize_key( $address_id );
		$address    = $this->get_address( $customer_id, $address_id );
		
		if ( empty( $address ) ) {
			return new WP_Error(
				'kerp_addresses_not_found',
				__( 'آدرس پیدا نشد.', 'kasebi-erp' )
			);
		}
		
		update_user_meta( $customer_id, self::DEFAULT_META_KEY, $address_id );
		$this->sync_default_customer_meta( $customer_id, $address );
		
		do_action( 'kerp_customer_default_address_changed', $customer_id, $address_id, $address );
		
		return TRUE;
	}
	
	public function get_state_options(): array {
		if ( ! function_exists( 'WC' ) || ! WC()->countries ) {
			return [];
		}
		
		$states = WC()->countries->get_states( 'IR' );
		
		return is_array( $states ) ? $states : [];
	}
	
	public function get_state_label( string $state ): string {
		$states = $this->get_state_options();
		
		return isset( $states[ $state ] )
			? (string) $states[ $state ]
			: $state;
	}
	
	public function get_city_label( string $state, string $city ): string {
		if ( $state === '' || $city === '' || ! function_exists( 'PWS' ) ) {
			return $city;
		}
		
		try {
			$pws = PWS();
			
			if ( is_callable( [ $pws, 'cities' ] ) ) {
				$cities = call_user_func( [ $pws, 'cities' ], $state );
				$cities = is_array( $cities ) ? $cities : [];
				
				if ( isset( $cities[ $city ] ) ) {
					return (string) $cities[ $city ];
				}
			}
		}
		catch ( Throwable $exception ) {
			return $city;
		}
		
		return $city;
	}
	
	public function get_address_line( array $address ): string {
		$parts = array_filter(
			[
				trim( (string) ( $address['region'] ?? '' ) ),
				trim( (string) ( $address['section'] ?? '' ) ),
				trim( (string) ( $address['address_1'] ?? '' ) ),
			]
		);
		
		return implode( ' - ', $parts );
	}
	
	public function get_address_display( array $address ): string {
		$state = $this->get_state_label( (string) ( $address['state'] ?? '' ) );
		$city  = $this->get_city_label(
			(string) ( $address['state'] ?? '' ),
			(string) ( $address['city'] ?? '' )
		);
		$line  = $this->get_address_line( $address );
		
		return implode(
			'، ',
			array_filter(
				[
					$state,
					$city,
					$line,
				]
			)
		);
	}
	
	private function normalize_address( array $address, string $address_id ): array {
		return [
			'id'         => $address_id,
			'title'      => sanitize_text_field( (string) ( $address['title'] ?? '' ) ),
			'first_name' => sanitize_text_field( (string) ( $address['first_name'] ?? '' ) ),
			'last_name'  => sanitize_text_field( (string) ( $address['last_name'] ?? '' ) ),
			'phone'      => sanitize_text_field( (string) ( $address['phone'] ?? '' ) ),
			'state'      => sanitize_text_field( (string) ( $address['state'] ?? '' ) ),
			'city'       => sanitize_text_field( (string) ( $address['city'] ?? '' ) ),
			'region'     => sanitize_text_field( (string) ( $address['region'] ?? '' ) ),
			'section'    => sanitize_text_field( (string) ( $address['section'] ?? '' ) ),
			'address_1'  => sanitize_textarea_field( (string) ( $address['address_1'] ?? '' ) ),
			'postcode'   => sanitize_text_field( (string) ( $address['postcode'] ?? '' ) ),
		];
	}
	
	private function get_legacy_addresses( int $customer_id ): array {
		$raw = get_user_meta( $customer_id, self::LEGACY_META_KEY, TRUE );
		
		if ( is_array( $raw ) ) {
			return $raw;
		}
		
		if ( is_string( $raw ) && $raw !== '' && function_exists( 'kasebi_unminified_string' ) ) {
			$decoded = kasebi_unminified_string( $raw );
			
			if ( is_array( $decoded ) ) {
				return $decoded;
			}
		}
		
		$maybe = maybe_unserialize( $raw );
		
		if ( is_array( $maybe ) ) {
			return $maybe;
		}
		
		if ( is_string( $raw ) && $raw !== '' ) {
			$decoded = json_decode( $raw, TRUE );
			
			if ( is_array( $decoded ) ) {
				return $decoded;
			}
		}
		
		return [];
	}
	
	private function generate_address_id( array $addresses ): string {
		do {
			$address_id = 'address_' . substr( md5( wp_generate_uuid4() ), 0, 12 );
		} while ( isset( $addresses[ $address_id ] ) );
		
		return $address_id;
	}
	
	private function sync_default_customer_meta( int $customer_id, array $address ): void {
		$map = [
			'first_name' => 'billing_first_name',
			'last_name'  => 'billing_last_name',
			'phone'      => 'billing_phone',
			'state'      => 'billing_state',
			'city'       => 'billing_city',
			'postcode'   => 'billing_postcode',
		];
		
		foreach ( $map as $address_key => $meta_key ) {
			update_user_meta(
				$customer_id,
				$meta_key,
				sanitize_text_field( (string) ( $address[ $address_key ] ?? '' ) )
			);
		}
		
		update_user_meta( $customer_id, 'billing_country', 'IR' );
		update_user_meta( $customer_id, 'billing_address_1', $this->get_address_line( $address ) );
		update_user_meta( $customer_id, 'state', sanitize_text_field( (string) ( $address['state'] ?? '' ) ) );
		update_user_meta( $customer_id, 'city', sanitize_text_field( (string) ( $address['city'] ?? '' ) ) );
	}
	
}
