<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Addresses_Api {
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {
		add_action( 'kasebi_ajax_addresses_save', [ $this, 'save' ] );
		add_action( 'kasebi_ajax_addresses_delete', [ $this, 'delete' ] );
		add_action( 'kasebi_ajax_addresses_set_default', [ $this, 'set_default' ] );
		add_action( 'kasebi_ajax_addresses_get_order_block', [ $this, 'get_order_block' ] );
	}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public function save(): void {
		$this->guard( 'edit' );
		
		$customer_id = absint( $_POST['address_customer_id'] ?? 0 );
		$this->guard_customer_scope( $customer_id );
		
		$address = isset( $_POST['address'] ) && is_array( $_POST['address'] )
			? wp_unslash( $_POST['address'] )
			: [];
		
		$address_id = sanitize_key( (string) ( $address['id'] ?? '' ) );
		$result     = KERP_Modules_Addresses_Module::instance()->save_address(
			$customer_id,
			$address,
			$address_id
		);
		
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		
		$context = $this->post_text( 'context' );
		
		if ( $context === 'order' ) {
			$order_id = absint(
				$_POST['order_id'] ?? 0
			);
			
			$order = $order_id > 0
				? wc_get_order( $order_id )
				: NULL;
			
			$selected_address_id = sanitize_key(
				$this->post_text( 'selected_address_id' )
			);
			
			if ( $address_id === '' ) {
				$selected_address_id = (string) $result;
			}
			
			$html = KERP_Helpers_Template::get_template(
				'modules/addresses/order/address-selector.php',
				[
					'order'               => $order instanceof WC_Order ? $order : NULL,
					'customer_id'         => $customer_id,
					'mode'                => $order instanceof WC_Order ? 'edit' : 'create',
					'selected_address_id' => $selected_address_id,
				]
			);
			
			$this->success(
				$address_id !== ''
					? __( 'آدرس با موفقیت ویرایش شد.', 'kasebi-erp' )
					: __( 'آدرس با موفقیت ثبت شد.', 'kasebi-erp' ),
				[
					'address_id'         => (string) $result,
					'address_block_html' => $html,
				]
			);
		}
		$page = $this->get_return_page(
			$customer_id
		);
		
		$this->success(
			$address_id !== ''
				? __( 'آدرس با موفقیت ویرایش شد.', 'kasebi-erp' )
				: __( 'آدرس با موفقیت ثبت شد.', 'kasebi-erp' ),
			array_merge(
				KERP_Api_Page_Content::build_page_response(
					$page,
					[],
					TRUE
				),
				[
					'address_id' => (string) $result,
				]
			)
		);
	}
	
	public function delete(): void {
		$this->guard( 'edit' );
		
		$customer_id = absint( $_POST['customer_id'] ?? 0 );
		$address_id  = $this->post_text( 'address_id' );
		$this->guard_customer_scope( $customer_id );
		
		$result = KERP_Modules_Addresses_Module::instance()->delete_address(
			$customer_id,
			$address_id
		);
		
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		
		$page = $this->get_return_page( $customer_id );
		
		$this->success(
			__( 'آدرس با موفقیت حذف شد.', 'kasebi-erp' ),
			KERP_Api_Page_Content::build_page_response( $page, [], TRUE )
		);
	}
	
	public function set_default(): void {
		$this->guard( 'edit' );
		
		$customer_id = absint( $_POST['customer_id'] ?? 0 );
		$address_id  = $this->post_text( 'address_id' );
		$this->guard_customer_scope( $customer_id );
		
		$result = KERP_Modules_Addresses_Module::instance()->set_default_address(
			$customer_id,
			$address_id
		);
		
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		
		$page = $this->get_return_page( $customer_id );
		
		$this->success(
			__( 'آدرس پیش‌فرض تغییر کرد.', 'kasebi-erp' ),
			KERP_Api_Page_Content::build_page_response( $page, [], TRUE )
		);
	}
	
	public function get_order_block(): void {
		$customer_id = absint( $_POST['customer_id'] ?? 0 );
		$order_id    = absint( $_POST['order_id'] ?? 0 );
		$order_creation = $order_id === 0 && kerp_can( 'orders.create', 'action' );
		$this->guard( 'view', $order_creation );
		$order       = $order_id > 0 ? wc_get_order( $order_id ) : NULL;
		
		if ( $customer_id > 0 ) {
			if ( $order_creation ) {
				if ( ! KERP_Modules_Customers_Query::can_select_for_order( $customer_id ) ) {
					$this->error( __( 'مشتری انتخاب‌شده معتبر نیست.', 'kasebi-erp' ) );
				}
			} else {
				$this->guard_customer_scope( $customer_id );
			}
		}
		
		$html = KERP_Helpers_Template::get_template(
			'modules/addresses/order/address-selector.php',
			[
				'order'       => $order instanceof WC_Order ? $order : NULL,
				'customer_id' => $customer_id,
				'mode'        => $order instanceof WC_Order ? 'edit' : 'create',
			]
		);
		
		if ( $html === FALSE ) {
			$this->error( __( 'قالب انتخاب آدرس پیدا نشد.', 'kasebi-erp' ) );
		}
		
		$this->success(
			'',
			[
				'html' => $html,
			]
		);
	}
	
	private function guard( string $action, bool $order_creation = FALSE ): void {
		if ( ! is_user_logged_in() ) {
			$this->error( __( 'برای انجام این عملیات باید وارد حساب کاربری شوید.', 'kasebi-erp' ) );
		}
		
		if ( ! KERP_App::instance()->current_user_has_access() ) {
			$this->error( __( 'شما به سامانه دسترسی ندارید.', 'kasebi-erp' ) );
		}
		
		if ( function_exists( 'kerp_can' ) && ! kerp_can( 'customers', $action )
			&& ! ( $action === 'view' && $order_creation && kerp_can( 'orders.create', 'action' ) ) ) {
			$this->error( __( 'دسترسی لازم را ندارید.', 'kasebi-erp' ) );
		}
	}
	
	private function guard_customer_scope( int $customer_id ): void {
		$customer = get_userdata( $customer_id );
		
		if ( ! $customer instanceof WP_User ) {
			$this->error( sprintf( __( '%s پیدا نشد.', 'kasebi-erp' ), KERP_Modules_Customers_Settings::instance()->get_singular_label() ) );
		}
		
		if ( ! function_exists( 'kerp_list_scope' ) ) {
			return;
		}
		
		$scope = kerp_list_scope( 'customers' );
		
		if ( $scope === 'none' ) {
			$this->error( __( 'دسترسی لازم را ندارید.', 'kasebi-erp' ) );
		}
		
		if ( $scope !== 'own' ) {
			return;
		}
		
		$owner_id = absint( get_user_meta( $customer_id, 'owner_id', TRUE ) );
		
		if ( $owner_id !== get_current_user_id() ) {
			$this->error( __( 'دسترسی لازم را ندارید.', 'kasebi-erp' ) );
		}
	}
	
	private function get_return_page( int $customer_id ): string {
		$page = $this->post_text( 'page' );
		
		if ( $page !== '' ) {
			return $page;
		}
		
		return '/erp/customers/' . $customer_id . '/?tab=addresses';
	}
	
	private function post_text( string $key ): string {
		if ( ! isset( $_POST[ $key ] ) || is_array( $_POST[ $key ] ) ) {
			return '';
		}
		
		return sanitize_text_field( wp_unslash( $_POST[ $key ] ) );
	}
	
	private function success( string $message, array $data = [] ): void {
		wp_send_json(
			array_merge(
				[
					'status'  => 'success',
					'message' => $message,
					'msg'     => $message,
				],
				$data
			)
		);
	}
	
	private function error( string $message, array $data = [] ): void {
		wp_send_json(
			array_merge(
				[
					'status'  => 'error',
					'message' => $message,
					'msg'     => $message,
				],
				$data
			)
		);
	}
	
}
