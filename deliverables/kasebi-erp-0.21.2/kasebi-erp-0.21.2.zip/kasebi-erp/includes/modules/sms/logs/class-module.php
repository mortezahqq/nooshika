<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Sms_Logs_Module {
	private static ?self $instance = NULL;

	public static function instance(): self {
		return self::$instance ??= new self();
	}

	public static function register_capture_hooks(): void {
		// Capture frontend OTP, cron and early init sends as well as ERP requests.
		add_action( 'kasebi_sms_sending', [ self::class, 'capture_start' ], 10, 2 );
		add_action( 'kasebi_sms_sent', [ self::class, 'capture_result' ], 10, 3 );
	}

	private static function enabled(): bool {
		$statuses = get_option( 'kerp_modules_statuses', [] );
		return is_array( $statuses ) && ( $statuses['sms_logs'] ?? '' ) === 'yes';
	}

	private function __construct() {
		self::ensure_table();
		add_filter( 'kerp_app_pages', [ $this, 'register_pages' ], 30 );
		add_filter( 'kerp_employee_permission_groups', [ $this, 'register_permissions' ] );
		add_action( 'kasebi_ajax_sms_logs_delete', [ $this, 'delete_logs' ] );
	}

	public static function table(): string {
		global $wpdb;
		return $wpdb->prefix . 'kerp_sms_logs';
	}

	private static function ensure_table(): void {
		if ( get_option( 'kerp_sms_logs_db_version' ) === '2' ) return;
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$table = self::table();
		$charset = $wpdb->get_charset_collate();
		dbDelta( "CREATE TABLE {$table} (
			id bigint unsigned NOT NULL AUTO_INCREMENT,
			attempt_id varchar(36) NOT NULL,
			recipient varchar(190) NOT NULL DEFAULT '',
			type varchar(20) NOT NULL DEFAULT '',
			source varchar(190) NOT NULL DEFAULT '',
			gateway varchar(40) NOT NULL DEFAULT '',
			pattern varchar(190) NOT NULL DEFAULT '',
			status varchar(20) NOT NULL DEFAULT 'pending',
			payload longtext NULL,
			request longtext NULL,
			response longtext NULL,
			result longtext NULL,
			created_by bigint unsigned NOT NULL DEFAULT 0,
			created_at datetime NOT NULL,
			completed_at datetime NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY attempt_id (attempt_id),
			KEY status_date (status, created_at),
			KEY recipient (recipient),
			KEY created_at (created_at)
		) {$charset};" );
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $table ) ) ) === $table
			&& $wpdb->get_var( "SHOW COLUMNS FROM {$table} LIKE 'request'" ) === 'request'
			&& $wpdb->get_var( "SHOW COLUMNS FROM {$table} LIKE 'response'" ) === 'response' ) {
			update_option( 'kerp_sms_logs_db_version', '2', FALSE );
		}
	}

	public static function capture_start( string $attempt, array $context ): void {
		if ( ! self::enabled() ) return;
		self::ensure_table();
		global $wpdb;
		$payload = is_array( $context['payload'] ?? NULL ) ? $context['payload'] : [];
		$recipient = $payload['recipient'] ?? $payload['receptor'] ?? '';
		if ( is_scalar( $recipient ) ) {
			$recipient = KERP_Helpers_Format::sanitize_numbers( (string) $recipient );
			$recipient = preg_replace( '/[\s()+-]+/', '', $recipient );
			$recipient = preg_replace( '/^(?:0098|98|0)?(9[0-9]{9})$/', '0$1', $recipient );
		} else {
			$recipient = wp_json_encode( $recipient );
		}
		$wpdb->insert( self::table(), [
			'attempt_id' => $attempt,
			'recipient' => substr( (string) $recipient, 0, 190 ),
			'type' => sanitize_key( $context['type'] ?? '' ),
			'source' => substr( sanitize_text_field( $context['source'] ?? '' ), 0, 190 ),
			'gateway' => substr( sanitize_text_field( $context['gateway'] ?? '' ), 0, 40 ),
			'pattern' => substr( sanitize_text_field( is_scalar( $payload['pattern'] ?? $payload['template'] ?? '' ) ? (string) ( $payload['pattern'] ?? $payload['template'] ?? '' ) : '' ), 0, 190 ),
			'status' => 'pending',
			'payload' => self::encode_exchange( in_array( $context['type'] ?? '', [ 'otp', 'forget' ], TRUE ) ? [ 'recipient' => $recipient, 'pattern' => $payload['pattern'] ?? '' ] : $payload ),
			'created_by' => get_current_user_id(),
			'created_at' => current_time( 'mysql' ),
		] );
	}

	public static function encode_exchange( $value ): string {
		if ( $value instanceof Throwable ) $value = [ 'exception' => get_class( $value ), 'message' => $value->getMessage(), 'code' => $value->getCode(), 'file' => $value->getFile(), 'line' => $value->getLine(), 'trace' => $value->getTraceAsString() ];
		if ( is_wp_error( $value ) ) $value = [ 'errors' => $value->errors, 'error_data' => $value->error_data ];
		return (string) wp_json_encode( self::redact_exchange( $value ), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE | JSON_PARTIAL_OUTPUT_ON_ERROR );
	}

	private static function redact_exchange( $value ) {
		if ( is_object( $value ) ) $value = get_object_vars( $value );
		if ( is_array( $value ) ) {
			foreach ( $value as $key => $item ) {
				$value[ $key ] = is_string( $key ) && preg_match( '/(?:password|passwd|pass|otp|api[_-]?key|secret|authorization|signature|token|order[_-]?key)/i', $key )
					? '[redacted]' : self::redact_exchange( $item );
			}
			return $value;
		}
		if ( is_string( $value ) && in_array( substr( trim( $value ), 0, 1 ), [ '{', '[' ], TRUE ) ) {
			$decoded = json_decode( $value, TRUE );
			if ( is_array( $decoded ) ) return self::redact_exchange( $decoded );
		}
		return $value;
	}

	public static function pretty_exchange( ?string $value ): string {
		if ( $value === NULL || $value === '' ) return 'برای این ارسال ثبت نشده است.';
		$decoded = json_decode( $value, TRUE );
		if ( json_last_error() !== JSON_ERROR_NONE ) return $value;
		if ( is_array( $decoded ) && isset( $decoded['body'] ) && is_string( $decoded['body'] ) ) {
			$body = json_decode( $decoded['body'], TRUE );
			if ( json_last_error() === JSON_ERROR_NONE ) $decoded['body'] = $body;
		}
		return (string) wp_json_encode( $decoded, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE );
	}

	public static function result_summary( string $gateway, $result ): array {
		if ( $result instanceof Throwable ) return [ 'status' => 'failed', 'detail' => 'exception: ' . get_class( $result ) ];
		if ( is_wp_error( $result ) ) return [ 'status' => 'failed', 'detail' => 'gateway_error' ];
		if ( $result === FALSE || $result === NULL || $result === '' ) return [ 'status' => 'failed', 'detail' => 'empty_response' ];
		if ( $result === 'no gateway selected' ) return [ 'status' => 'failed', 'detail' => 'no_gateway' ];
		$data = is_object( $result ) ? (array) $result : ( is_array( $result ) ? $result : [] );
		$status = 'unknown';
		$code = $data['status'] ?? NULL;
		if ( $gateway === 'ks_faraz' && isset( $data['status'] ) ) $status = $code === 'success' ? 'accepted' : 'failed';
		if ( $gateway === 'ks_kavenegar' && isset( $data['status'] ) ) $status = (int) $code === 200 ? 'accepted' : 'failed';
		if ( $gateway === 'ks_smsIR' && isset( $data['status'] ) ) $status = (int) $code === 1 ? 'accepted' : 'failed';
		if ( $gateway === 'ks_signal' && isset( $data['success'] ) ) $status = $data['success'] ? 'accepted' : 'failed';
		if ( $gateway === 'ks_melipayamak' && is_numeric( $result ) ) {
			$status = (float) $result > 1000 ? 'accepted' : 'failed';
			$code = $status === 'failed' ? (string) $result : NULL;
		}
		return [ 'status' => $status, 'detail' => is_scalar( $code ) ? 'gateway_status: ' . substr( sanitize_text_field( (string) $code ), 0, 80 ) : 'unrecognized_response' ];
	}

	public static function capture_result( string $attempt, array $context, $result ): void {
		if ( ! self::enabled() ) return;
		global $wpdb;
		$summary = self::result_summary( (string) ( $context['gateway'] ?? '' ), $result );
		$sensitive = in_array( $context['type'] ?? '', [ 'otp', 'forget' ], TRUE );
		$wpdb->update( self::table(), [ 'status' => $summary['status'], 'result' => $summary['detail'], 'request' => $sensitive ? self::encode_exchange( [ 'redacted' => 'authentication message' ] ) : self::encode_exchange( $context['request'] ?? $context['payload'] ?? [] ), 'response' => $sensitive ? self::encode_exchange( $summary ) : self::encode_exchange( $context['response'] ?? $result ), 'completed_at' => current_time( 'mysql' ) ], [ 'attempt_id' => $attempt ] );
	}

	public function register_pages( array $pages ): array {
		$pages['sms-logs'] = [
			'title' => 'گزارشات پیامک', 'route' => 'sms-logs', 'type' => 'page',
			'template' => 'modules/sms-logs/list.php', 'permission' => 'sms_logs.view',
			'navigation' => [ 'group' => [ 'key' => 'system', 'title' => 'سیستم', 'icon' => 'ni ni-setting', 'order' => 90 ], 'icon' => 'ni ni-mail', 'order' => 40 ],
		];
		return $pages;
	}

	public function register_permissions( array $groups ): array {
		$groups['general']['blocks']['sms_logs'] = [
			'key' => 'sms_logs', 'label' => 'لاگ پیامک‌ها', 'icon' => 'ni ni-mail', 'order' => 90,
			'permissions' => [
				'sms_logs_view' => [ 'key' => 'sms_logs.view', 'label' => 'مشاهده همه لاگ‌های پیامک', 'type' => 'view', 'order' => 10 ],
				'sms_logs_delete' => [ 'key' => 'sms_logs.delete', 'label' => 'حذف لاگ پیامک', 'type' => 'action', 'order' => 20 ],
			],
		];
		return $groups;
	}

	public static function source_label( string $source ): string {
		$parts = explode( '/', $source );
		$labels = [ 'kasebi-erp' => 'ERP', 'nooshika-main' => 'افزونه اصلی کاسبی', 'kasebi-order-sms' => 'پیامک سفارش‌ها', 'nooshika-panel' => 'پنل کاربری' ];
		$label = $labels[ $parts[0] ] ?? $source;
		if ( $parts[0] === 'kasebi-erp' && ! empty( $parts[1] ) ) {
			$modules = KERP_Modules::get_registered_modules();
			$label .= ' / ' . ( $modules[ $parts[1] ]['label'] ?? $parts[1] );
		}
		return $label;
	}

	public static function result_label( string $result ): string {
		$labels = [ 'no_gateway' => 'هیچ درگاهی انتخاب نشده است.', 'empty_response' => 'درگاه پاسخ معتبر ارسال نکرد.', 'gateway_error' => 'درگاه خطا برگرداند.', 'unrecognized_response' => 'پاسخ درگاه قابل تشخیص نبود.', '' => 'نتیجه نهایی هنوز ثبت نشده است.' ];
		if ( isset( $labels[ $result ] ) ) return $labels[ $result ];
		if ( str_starts_with( $result, 'gateway_status: ' ) ) return 'وضعیت اعلام‌شده توسط درگاه: ' . substr( $result, strlen( 'gateway_status: ' ) );
		if ( str_starts_with( $result, 'exception: ' ) ) return 'خطا هنگام ارسال: ' . substr( $result, strlen( 'exception: ' ) );
		return $result;
	}

	public static function find( array $query ): array {
		if ( ! kerp_can( 'sms_logs.view', 'view' ) ) return [ 'rows' => [], 'total' => 0, 'page_number' => 1, 'total_pages' => 1, 'counts' => [] ];
		global $wpdb;
		$table = self::table();
		$where = [ '1=1' ];
		foreach ( [ 'status', 'type', 'gateway' ] as $key ) {
			if ( ! empty( $query[ $key ] ) && is_scalar( $query[ $key ] ) ) $where[] = $wpdb->prepare( "{$key} = %s", sanitize_text_field( (string) $query[ $key ] ) );
		}
		if ( ! empty( $query['search'] ) && is_scalar( $query['search'] ) ) {
			$search = '%' . $wpdb->esc_like( KERP_Helpers_Format::sanitize_numbers( sanitize_text_field( (string) $query['search'] ) ) ) . '%';
			$where[] = $wpdb->prepare( '(recipient LIKE %s OR source LIKE %s OR pattern LIKE %s)', $search, $search, $search );
		}
		$dates = is_array( $query['sent'] ?? NULL ) ? $query['sent'] : [];
		foreach ( [ 'from' => '>=', 'to' => '<=' ] as $key => $operator ) {
			if ( empty( $dates[ $key ] ) ) continue;
			$date = is_scalar( $dates[ $key ] ) ? KERP_Helpers_Date::jalali_to_gregorian( str_replace( '/', '-', (string) $dates[ $key ] ) ) : '';
			$where[] = $date ? $wpdb->prepare( "created_at {$operator} %s", $date . ( $key === 'from' ? ' 00:00:00' : ' 23:59:59' ) ) : '1=0';
		}
		$where = implode( ' AND ', $where );
		$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE {$where}" );
		$counts = [ 'accepted' => 0, 'failed' => 0, 'pending' => 0, 'unknown' => 0 ];
		foreach ( (array) $wpdb->get_results( "SELECT status, COUNT(*) AS status_count FROM {$table} WHERE {$where} GROUP BY status", ARRAY_A ) as $count ) {
			if ( isset( $counts[ $count['status'] ] ) ) $counts[ $count['status'] ] = (int) ( $count['status_count'] ?? 0 );
		}
		$per_page = min( 100, max( 1, absint( $query['per_page'] ?? 20 ) ) );
		$total_pages = max( 1, (int) ceil( $total / $per_page ) );
		$page_number = min( $total_pages, max( 1, absint( $query['page_number'] ?? 1 ) ) );
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE {$where} ORDER BY id DESC LIMIT %d OFFSET %d", $per_page, ( $page_number - 1 ) * $per_page ), ARRAY_A );
		return compact( 'rows', 'total', 'page_number', 'total_pages', 'counts' );
	}

	public function delete_logs(): void {
		if ( ! is_user_logged_in() || ! KERP_App::instance()->current_user_has_access() || ! kerp_can( 'sms_logs.view', 'view' ) || ! kerp_can( 'sms_logs.delete', 'action' ) ) {
			wp_send_json( [ 'status' => 'error', 'message' => 'اجازه حذف لاگ پیامک را ندارید.' ] );
			return;
		}
		if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( is_scalar( $_POST['sms_logs_nonce'] ?? NULL ) ? $_POST['sms_logs_nonce'] : '' ) ), 'kerp_sms_logs_delete' ) ) {
			wp_send_json( [ 'status' => 'error', 'message' => 'درخواست معتبر نیست؛ صفحه را تازه‌سازی کنید.' ] );
			return;
		}
		$raw_ids = is_string( $_POST['sms_log_ids'] ?? NULL ) ? explode( ',', wp_unslash( $_POST['sms_log_ids'] ) ) : [];
		$ids = array_slice( array_unique( array_filter( array_map( 'absint', $raw_ids ) ) ), 0, 100 );
		if ( ! $ids || ( $_POST['operation'] ?? '' ) !== 'delete' ) {
			wp_send_json( [ 'status' => 'error', 'message' => 'لاگ‌های موردنظر را انتخاب کنید.' ] );
			return;
		}
		global $wpdb;
		$placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
		$deleted = $wpdb->query( $wpdb->prepare( 'DELETE FROM ' . self::table() . " WHERE id IN ({$placeholders}) AND status <> 'pending'", ...$ids ) );
		if ( $deleted === FALSE ) {
			wp_send_json( [ 'status' => 'error', 'message' => 'حذف لاگ انجام نشد.' ] );
			return;
		}
		wp_send_json( array_merge( KERP_Api_Page_Content::build_page_response( '/erp/sms-logs/', [], TRUE ), [ 'status' => 'success', 'message' => sprintf( '%d لاگ حذف شد. ارسال‌های در حال پردازش حفظ می‌شوند.', $deleted ) ] ) );
	}
}
