<?php
defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Marketing_Module {
	private static ?self $instance = null;
	public static function instance(): self { return self::$instance ??= new self(); }
	private function __construct() {
		KERP_Modules_Marketing_Store::install();
		KERP_Modules_Marketing_Api::instance();
		add_filter( 'kerp_app_pages', [ $this, 'pages' ] );
		add_filter( 'kerp_employee_permission_groups', [ $this, 'permissions' ] );
		// Core asset cleanup is registered first at this priority; enqueue after it.
		add_action( 'wp_enqueue_scripts', [ $this, 'assets' ], PHP_INT_MAX );
	}
	public function assets(): void {
		if ( kerp_is_erp_request() ) wp_enqueue_style( 'kerp-marketing', KERP_ASSETS_URL . 'app/css/marketing.css', [ KERP_Public_Assets::STYLE_HANDLE ], kerp_asset_version( 'app/css/marketing.css' ) );
	}
	public function pages( array $pages ): array {
		$pages['marketing'] = [ 'title' => 'داشبورد مارکتینگ', 'route' => 'marketing', 'type' => 'page', 'template' => 'modules/marketing/dashboard.php', 'permission' => 'marketing.view',
			'navigation' => [ 'group' => [ 'key' => 'marketing', 'title' => 'مارکتینگ', 'icon' => 'ni ni-growth', 'order' => 26 ], 'icon' => 'ni ni-growth', 'order' => 10 ] ];
		$section_icons = [ 'requests' => 'ni ni-list', 'inbox' => 'ni ni-inbox', 'review' => 'ni ni-check-circle', 'finance' => 'ni ni-wallet' ];
		foreach ( [ 'requests' => 'درخواست‌های تبلیغات', 'inbox' => 'کارتابل من', 'review' => 'بررسی مارکتینگ', 'finance' => 'پرداخت تبلیغات' ] as $key => $title ) {
			$pages['marketing-' . $key] = [ 'title' => $title, 'route' => 'marketing/' . $key, 'type' => 'page', 'template' => 'modules/marketing/' . $key . '.php', 'permission' => 'marketing.view',
				'navigation' => [ 'group' => $pages['marketing']['navigation']['group'], 'icon' => $section_icons[$key], 'order' => 20 + count( $pages ) ] ];
		}
		foreach ( [ 'review' => 'marketing.review', 'finance' => 'marketing.pay' ] as $section => $permission ) {
			if ( ! kerp_can( $permission, 'action' ) ) $pages['marketing-' . $section]['navigation']['hidden'] = true;
		}
		foreach ( [ 'request' => '', 'campaign-dashboard' => '/dashboard' ] as $key => $suffix ) {
			$pages['marketing-' . $key] = [ 'title' => $suffix ? 'داشبورد کمپین' : 'جزئیات درخواست تبلیغ', 'route' => 'marketing/requests/{request_id}' . $suffix, 'type' => 'sub-page', 'template' => 'modules/marketing/' . $key . '.php', 'permission' => 'marketing.view', 'navigation' => [ 'hidden' => true, 'active' => 'marketing-requests' ] ];
		}
		return $pages;
	}
	public function permissions( array $groups ): array {
		$permissions = [];
		foreach ( [ 'view' => 'مشاهده درخواست‌های مرتبط', 'view_all' => 'مشاهده همه درخواست‌ها', 'create' => 'ثبت درخواست', 'edit' => 'ویرایش درخواست', 'metrics' => 'ثبت و اصلاح آمار کمپین', 'complete' => 'اعلام پایان کمپین', 'review' => 'بررسی مدیر مارکتینگ', 'pay' => 'ثبت پرداخت هزینه تبلیغ', 'archive' => 'بایگانی درخواست', 'delete' => 'حذف دائمی درخواست' ] as $key => $label ) {
			$permissions[$key] = [ 'key' => 'marketing.' . $key, 'label' => $label, 'type' => $key === 'view' ? 'view' : 'action', 'order' => count( $permissions ) * 10 ];
		}
		$groups['marketing'] = [ 'key' => 'marketing', 'label' => 'مارکتینگ', 'icon' => 'ni ni-growth', 'order' => 26, 'blocks' => [ 'marketing' => [ 'key' => 'marketing', 'label' => 'درخواست تبلیغات', 'icon' => 'ni ni-growth', 'order' => 10, 'permissions' => $permissions ] ] ];
		return $groups;
	}
}


