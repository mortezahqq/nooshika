<?php
defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Marketing_Store {
	public static function table(): string { global $wpdb; return $wpdb->prefix . 'kerp_marketing_requests'; }
	public static function install(): void {
		if ( get_option( 'kerp_marketing_db_version' ) === '1.1.0' ) return;
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$table = self::table();
		$charset = $wpdb->get_charset_collate();
		dbDelta( "CREATE TABLE {$table} (
			id bigint unsigned NOT NULL AUTO_INCREMENT,
			title varchar(190) NOT NULL,
			ad_type varchar(190) NOT NULL,
			platform varchar(190) NOT NULL,
			cost decimal(18,2) NOT NULL DEFAULT 0,
			execution_date date NOT NULL,
			expected_leads int unsigned NOT NULL DEFAULT 0,
			expected_sales decimal(18,2) NOT NULL DEFAULT 0,
			status varchar(20) NOT NULL DEFAULT 'pending',
			request_token varchar(36) NOT NULL,
			manager_id bigint unsigned NOT NULL,
			finance_id bigint unsigned NOT NULL,
			currency varchar(10) NOT NULL DEFAULT 'IRT',
			history longtext NULL,
			payment_reference varchar(190) NOT NULL DEFAULT '',
			metrics longtext NULL,
			sources longtext NULL,
			metric_entries longtext NULL,
			created_by bigint unsigned NOT NULL,
			updated_by bigint unsigned NOT NULL,
			version bigint unsigned NOT NULL DEFAULT 1,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY request_token (request_token),
			KEY owner_status (created_by,status),
			KEY execution_date (execution_date)
		) ENGINE=InnoDB {$charset};" );
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $table ) ) ) === $table && $wpdb->get_var( "SHOW COLUMNS FROM {$table} LIKE 'sources'" ) && $wpdb->get_var( "SHOW COLUMNS FROM {$table} LIKE 'metric_entries'" ) ) update_option( 'kerp_marketing_db_version', '1.1.0', false );
	}
	public static function can_view(): bool { return kerp_can( 'marketing.view', 'view' ); }
	public static function scope(): string {
		if ( ! self::can_view() ) return '1=0';
		if ( kerp_can( 'marketing.view_all', 'action' ) ) return '1=1';
		$id = (int) get_current_user_id();
		$conditions = [ "created_by={$id}" ];
		if ( kerp_can( 'marketing.review', 'action' ) ) $conditions[] = "status IN ('pending','rejected','finance','paid','completed','archived')";
		if ( kerp_can( 'marketing.pay', 'action' ) ) $conditions[] = "status IN ('finance','paid','completed','archived')";
		return '(' . implode( ' OR ', $conditions ) . ')';
	}
	public static function get( int $id ): ?array {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE id=%d AND ' . self::scope(), $id ), ARRAY_A ) ?: null;
	}
	public static function find( array $query, int $per_page ): array {
		global $wpdb;
		$where = self::scope();
		$search = self::text( $query['search'] ?? '' );
		if ( $search !== '' ) {
			$like = '%' . $wpdb->esc_like( $search ) . '%';
			$where .= $wpdb->prepare( ' AND (title LIKE %s OR platform LIKE %s OR ad_type LIKE %s)', $like, $like, $like );
		}
		$status = self::text( $query['status'] ?? '' );
		if ( ( $query['inbox'] ?? '' ) === 'finance' ) $where .= kerp_can( 'marketing.pay', 'action' ) ? " AND status='finance'" : ' AND 1=0';
		if ( ( $query['inbox'] ?? '' ) === 'review' ) $where .= kerp_can( 'marketing.review', 'action' ) ? " AND status='pending'" : ' AND 1=0';
		if ( ( $query['inbox'] ?? '' ) === 'mine' ) {
			$id = (int) get_current_user_id();
			$work = [ '1=0' ];
			if ( kerp_can( 'marketing.edit', 'action' ) ) $work[] = "(created_by={$id} AND status='rejected')";
			if ( kerp_can( 'marketing.review', 'action' ) ) $work[] = "status='pending'";
			if ( kerp_can( 'marketing.pay', 'action' ) ) $work[] = "status='finance'";
			$where .= ' AND (' . implode( ' OR ', $work ) . ')';
		}
		if ( isset( self::statuses()[$status] ) ) $where .= $wpdb->prepare( ' AND status=%s', $status );
		$table = self::table();
		$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE {$where}" );
		$pages = max( 1, (int) ceil( $total / $per_page ) );
		$page = min( $pages, max( 1, (int) self::text( $query['page_number'] ?? 1 ) ) );
		$items = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE {$where} ORDER BY id DESC LIMIT %d OFFSET %d", $per_page, ( $page - 1 ) * $per_page ), ARRAY_A );
		return compact( 'items', 'total', 'pages', 'page' );
	}
	public static function statuses(): array { return [ 'pending' => 'در انتظار مدیر مارکتینگ', 'rejected' => 'نیازمند اصلاح', 'finance' => 'در انتظار پرداخت مالی', 'paid' => 'پرداخت‌شده', 'completed' => 'پایان‌یافته', 'archived' => 'بایگانی' ]; }
	public static function text( $value ): string { return is_scalar( $value ) ? sanitize_text_field( (string) $value ) : ''; }
	public static function ratio( float $numerator, float $denominator, float $factor = 1 ): ?float { return $denominator > 0 ? $numerator / $denominator * $factor : null; }
	public static function number( $value, bool $integer = false ): float|int|WP_Error {
		$value = KERP_Helpers_Format::sanitize_numbers( self::text( $value ) );
		if ( ! $integer ) {
			$value = str_replace( [ '٬', '٫' ], [ ',', '.' ], $value );
			if ( str_contains( $value, ',' ) && ! preg_match( '/^\d{1,3}(?:,\d{3})+(?:\.\d{1,2})?$/', $value ) ) return new WP_Error( 'number', 'جداکننده مبلغ معتبر نیست.' );
			$value = str_replace( ',', '', $value );
		}
		if ( ! preg_match( $integer ? '/^\d{1,9}$/' : '/^\d{1,12}(?:\.\d{1,2})?$/', $value ) ) return new WP_Error( 'number', 'مقادیر عددی باید نامنفی باشند؛ تعدادها عدد صحیح و مبلغ‌ها حداکثر دو رقم اعشار دارند.' );
		return $integer ? (int) $value : (float) $value;
	}
	public static function validate( array $input ): array|WP_Error {
		$data = [];
		foreach ( [ 'title', 'ad_type', 'platform' ] as $key ) {
			$data[$key] = self::text( $input[$key] ?? '' );
			if ( $data[$key] === '' || mb_strlen( $data[$key] ) > 190 ) return new WP_Error( 'text', 'عنوان کمپین، نوع تبلیغ و پلتفرم الزامی و حداکثر ۱۹۰ نویسه هستند.' );
		}
		foreach ( [ 'cost', 'expected_leads', 'expected_sales' ] as $key ) {
			$data[$key] = self::number( $input[$key] ?? '', $key === 'expected_leads' );
			if ( is_wp_error( $data[$key] ) ) return $data[$key];
		}
		$date = self::daily_date( $input['execution_date'] ?? '' );
		if ( is_wp_error( $date ) ) return $date;
		$data['execution_date'] = $date;
		$source_rows = $input['sources'] ?? [];
		if ( ! is_array( $source_rows ) || count( $source_rows ) > 100 ) return new WP_Error( 'sources', 'حداکثر ۱۰۰ منبع وارد کنید.' );
		$sources = [];
		foreach ( $source_rows as $source_row ) {
			$name = is_array( $source_row ) ? self::text( $source_row['name'] ?? '' ) : '';
			if ( $name === '' ) continue;
			if ( mb_strlen( $name ) > 190 ) return new WP_Error( 'sources', 'نام منبع حداکثر ۱۹۰ نویسه است.' );
			$key = hash( 'sha256', $name );
			if ( isset( $sources[$key] ) ) return new WP_Error( 'sources', 'نام منابع نباید تکراری باشد.' );
			$sources[$key] = $name;
		}
		if ( ! $sources ) return new WP_Error( 'sources', 'حداقل یک منبع برای کمپین اضافه کنید.' );
		$data['sources'] = wp_json_encode( $sources );
		return $data;
	}
	public static function sources( array $row ): array {
		$sources = json_decode( $row['sources'] ?? '[]', true ) ?: [];
		if ( $sources ) return $sources;
		foreach ( json_decode( $row['metrics'] ?? '[]', true ) ?: [] as $metric ) {
			$name = self::text( $metric['source'] ?? '' );
			if ( $name !== '' ) $sources[hash( 'sha256', $name )] = $name;
		}
		if ( ! $sources && ! empty( $row['platform'] ) ) $sources[hash( 'sha256', $row['platform'] )] = $row['platform'];
		return $sources;
	}
	public static function daily_date( $value ): string|WP_Error {
		$date = str_replace( '/', '-', KERP_Helpers_Format::sanitize_numbers( self::text( $value ) ) );
		if ( ! preg_match( '/^1[34][0-9]{2}-[0-9]{1,2}-[0-9]{1,2}$/', $date ) ) return new WP_Error( 'date', 'تاریخ معتبر وارد کنید.' );
		$gregorian = KERP_Helpers_Date::jalali_to_gregorian( $date );
		if ( $gregorian === '' ) return new WP_Error( 'date', 'تاریخ معتبر وارد کنید.' );
		return $gregorian;
	}
	public static function metrics( array $row ): array {
		$totals = [];
		$all = array_merge( array_values( json_decode( $row['metrics'] ?? '[]', true ) ?: [] ), array_values( json_decode( $row['metric_entries'] ?? '[]', true ) ?: [] ) );
		foreach ( $all as $entry ) {
			$key = hash( 'sha256', $entry['source'] );
			if ( ! isset( $totals[$key] ) ) $totals[$key] = [ 'source' => $entry['source'] ] + array_fill_keys( array_keys( self::metric_fields() ), 0 );
			foreach ( self::metric_fields() as $field => $label ) $totals[$key][$field] += (float) ( $entry[$field] ?? 0 );
		}
		return $totals;
	}
	public static function metric_fields(): array {
		return [ 'numbers' => 'تعداد مشتری بالقوه', 'online' => 'تعداد کلیک', 'pre_reg' => 'تعداد تکمیل فرم', 'cost' => 'هزینه واقعی', 'sales' => 'فروش واقعی' ];
	}
	public static function totals( array $rows ): array {
		$total = array_fill_keys( array_keys( self::metric_fields() ), 0 );
		foreach ( $rows as $row ) foreach ( $total as $key => $value ) $total[$key] += (float) ( $row[$key] ?? 0 );
		return $total;
	}
}

