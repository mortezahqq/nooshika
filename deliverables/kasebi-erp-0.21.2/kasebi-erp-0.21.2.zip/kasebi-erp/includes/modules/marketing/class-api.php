<?php
defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Marketing_Api {
	private static ?self $instance = null;
	public static function instance(): self { return self::$instance ??= new self(); }
	private function __construct() {
		foreach ( [ 'save', 'transition', 'metric', 'bulk', 'upload', 'sources', 'delete' ] as $action ) add_action( 'kasebi_ajax_marketing_' . $action, [ $this, $action ] );
	}
	private function input(): array { return wp_unslash( $_POST ); }
	private function guard( string $permission ): void {
		$input = $this->input();
		$payload = is_array( $input['payload'] ?? null ) ? $input['payload'] : [];
		$nonce = KERP_Modules_Marketing_Store::text( $input['marketing_nonce'] ?? ( $payload['marketing_nonce'] ?? '' ) );
		if ( ! wp_verify_nonce( $nonce, 'kerp_marketing' ) || ! KERP_Modules_Marketing_Store::can_view() || ! kerp_can( 'marketing.' . $permission, 'action' ) ) $this->error( 'دسترسی لازم ندارید یا نشست منقضی شده است؛ صفحه را تازه کنید.' );
	}
	private function record(): array {
		$id = (int) KERP_Modules_Marketing_Store::text( $this->input()['id'] ?? '' );
		$row = KERP_Modules_Marketing_Store::get( $id );
		if ( ! $row ) $this->error( 'درخواست پیدا نشد یا به آن دسترسی ندارید.' );
		if ( (int) KERP_Modules_Marketing_Store::text( $this->input()['version'] ?? 0 ) !== (int) $row['version'] ) $this->error( 'این درخواست تغییر کرده است؛ صفحه را تازه کنید.' );
		return $row;
	}
	private function update( array $row, array $data, string $event, string $note = '', bool $fail = true, array $event_meta = [] ): bool {
		global $wpdb;
		$history = json_decode( $row['history'] ?? '[]', true ) ?: [];
		$history[] = [ 'event' => $event, 'note' => $note, 'actor' => get_current_user_id(), 'at' => current_time( 'mysql' ) ] + $event_meta;
		$data += [ 'history' => wp_json_encode( $history ), 'version' => (int) $row['version'] + 1, 'updated_by' => get_current_user_id(), 'updated_at' => current_time( 'mysql' ) ];
		$result = $wpdb->update( KERP_Modules_Marketing_Store::table(), $data, [ 'id' => $row['id'], 'version' => $row['version'] ] );
		if ( $result !== 1 && $fail ) $this->error( 'ذخیره انجام نشد یا درخواست هم‌زمان تغییر کرده است؛ صفحه را تازه کنید.' );
		return $result === 1;
	}
	public function save(): void {
		global $wpdb;
		$input = $this->input();
		$id = (int) KERP_Modules_Marketing_Store::text( $input['id'] ?? 0 );
		$this->guard( $id ? 'edit' : 'create' );
		$row = $id ? $this->record() : null;
		if ( $row && ( ! in_array( $row['status'], [ 'pending', 'rejected' ], true ) ) ) $this->error( 'فقط درخواست بررسی‌نشده یا برگشتی قابل ویرایش است.' );
		$data = KERP_Modules_Marketing_Store::validate( $input );
		if ( is_wp_error( $data ) ) $this->error( $data->get_error_message() );
		$settings = (array) get_option( 'kerp_marketing_settings', [] );
		$data['status'] = 'pending';
		if ( $row ) {
			$sources = json_decode( $data['sources'], true );
			foreach ( KERP_Modules_Marketing_Store::metrics( $row ) as $metric ) {
				$key = hash( 'sha256', $metric['source'] );
				if ( ! isset( $sources[$key] ) ) $this->error( 'منبع دارای آمار را نمی‌توان حذف یا تغییر نام داد.' );
			}
			$this->update( $row, $data, 'اصلاح و ارسال برای مدیر مارکتینگ' );
		} else {
			$token = KERP_Modules_Marketing_Store::text( $input['request_token'] ?? '' );
			if ( ! wp_is_uuid( $token ) ) $this->error( 'شناسه ثبت معتبر نیست؛ صفحه را تازه کنید.' );
			$exists = $wpdb->get_row( $wpdb->prepare( 'SELECT id,created_by FROM ' . KERP_Modules_Marketing_Store::table() . ' WHERE request_token=%s', $token ), ARRAY_A );
			if ( $exists ) {
				if ( (int) $exists['created_by'] !== get_current_user_id() ) $this->error( 'شناسه ثبت معتبر نیست.' );
				$this->success( 'این درخواست قبلاً ثبت شده است.', (int) $exists['id'] );
			}
			$data += [ 'manager_id' => 0, 'finance_id' => 0, 'request_token' => $token, 'currency' => ( $settings['currency'] ?? 'IRT' ) === 'IRR' ? 'IRR' : 'IRT', 'created_by' => get_current_user_id(), 'updated_by' => get_current_user_id(), 'created_at' => current_time( 'mysql' ), 'updated_at' => current_time( 'mysql' ), 'history' => wp_json_encode( [ [ 'event' => 'ثبت و ارجاع به مدیر مارکتینگ', 'actor' => get_current_user_id(), 'at' => current_time( 'mysql' ), 'note' => '' ] ] ) ];
			if ( ! $wpdb->insert( KERP_Modules_Marketing_Store::table(), $data ) ) $this->error( 'ثبت درخواست انجام نشد؛ صفحه را تازه کنید.' );
			$id = (int) $wpdb->insert_id;
		}
		$this->success( 'درخواست به مدیر مارکتینگ ارجاع شد.', $id );
	}
	public function upload(): void {
		$this->guard( 'pay' );
		$row = $this->record();
		if ( $row['status'] !== 'finance' ) $this->error( 'پیوست فقط برای درخواست در انتظار پرداخت مجاز است.' );
		if ( ! is_array( $_FILES['file'] ?? null ) ) $this->error( 'فایل ارسال نشده است.' );
		$result = KERP_Helpers_File::instance()->handle_upload_file( $_FILES['file'], 'kerp-marketing-payments/' . get_current_user_id(), $this->input() );
		if ( empty( $result['ok'] ) ) $this->error( $result['msg'] ?? 'آپلود ناموفق بود.' );
		if ( ! empty( $result['url'] ) ) set_transient( 'kerp_marketing_upload_' . hash( 'sha256', $result['url'] ), [ 'actor' => get_current_user_id(), 'request' => (int) $row['id'] ], DAY_IN_SECONDS );
		wp_send_json( [ 'status' => 'success', 'url' => $result['url'] ] );
	}
	public function transition(): void {
		$input = $this->input();
		$operation = KERP_Modules_Marketing_Store::text( $input['operation'] ?? '' );
		$this->guard( $operation === 'pay' ? 'pay' : ( $operation === 'complete' ? 'complete' : 'review' ) );
		$row = $this->record();
		$note = KERP_Modules_Marketing_Store::text( $input['note'] ?? '' );
		$data = []; $event_meta = [];
		if ( in_array( $operation, [ 'approve', 'reject' ], true ) && $row['status'] === 'pending' ) {
			if ( $operation === 'reject' && $note === '' ) $this->error( 'علت برگشت را وارد کنید.' );
			$data['status'] = $operation === 'approve' ? 'finance' : 'rejected';
			$event = $operation === 'approve' ? 'تأیید مدیر مارکتینگ و ارجاع به مالی' : 'برگشت برای اصلاح';
		} elseif ( $operation === 'pay' && $row['status'] === 'finance' ) {
			$reference = KERP_Modules_Marketing_Store::text( $input['payment_reference'] ?? '' );
			if ( $reference === '' || mb_strlen( $reference ) > 190 ) $this->error( 'مرجع معتبر پرداخت (حداکثر ۱۹۰ نویسه) الزامی است.' );
			$note = is_string( $input['note'] ?? '' ) ? wp_kses_post( $input['note'] ?? '' ) : '';
			$raw_files = $input['payment_files'] ?? '';
			if ( ! is_string( $raw_files ) ) $this->error( 'پیوست نامعتبر است.' );
			$files = array_values( array_unique( array_filter( array_map( 'trim', explode( ',', $raw_files ) ) ) ) );
			if ( count( $files ) > 3 ) $this->error( 'حداکثر سه پیوست مجاز است.' );
			foreach ( $files as $file ) {
				$owner = get_transient( 'kerp_marketing_upload_' . hash( 'sha256', $file ) );
				if ( ! is_array( $owner ) || (int) $owner['actor'] !== get_current_user_id() || (int) $owner['request'] !== (int) $row['id'] ) $this->error( 'پیوست معتبر نیست یا منقضی شده است؛ دوباره بارگذاری کنید.' );
			}
			$event_meta = [ 'note_format' => 'html', 'files' => $files ];
			$data = [ 'status' => 'paid', 'payment_reference' => $reference ];
			$event = 'ثبت پرداخت هزینه تبلیغ';
		} elseif ( $operation === 'complete' && $row['status'] === 'paid' ) {
			$data['status'] = 'completed'; $event = 'پایان کمپین';
		} else $this->error( 'این تغییر وضعیت برای شما یا وضعیت فعلی مجاز نیست.' );
		$this->update( $row, $data, $event, $note, true, $event_meta );
		$this->success( $event, (int) $row['id'] );
	}
	public function sources(): void {
		$this->guard( kerp_can( 'marketing.metrics', 'action' ) ? 'metrics' : 'edit' );
		$row = $this->record();
		$name = KERP_Modules_Marketing_Store::text( $this->input()['source_name'] ?? '' );
		if ( $name === '' || mb_strlen( $name ) > 190 ) $this->error( 'نام منبع را وارد کنید؛ حداکثر ۱۹۰ نویسه.' );
		$sources = KERP_Modules_Marketing_Store::sources( $row );
		$key = hash( 'sha256', $name );
		if ( isset( $sources[$key] ) ) $this->error( 'این منبع قبلاً اضافه شده است.' );
		if ( count( $sources ) >= 100 ) $this->error( 'حداکثر ۱۰۰ منبع برای کمپین مجاز است.' );
		$sources[$key] = $name;
		$this->update( $row, [ 'sources' => wp_json_encode( $sources ) ], 'افزودن منبع کمپین', $name );
		$this->success( 'منبع اضافه شد.', (int) $row['id'] );
	}
	public function metric(): void {
		$this->guard( 'metrics' ); $row = $this->record(); $input = $this->input();
		if ( ! in_array( $row['status'], [ 'paid', 'completed' ], true ) ) $this->error( 'ثبت عملکرد فقط پس از پرداخت مجاز است.' );
		$sources = KERP_Modules_Marketing_Store::sources( $row );
		$source_id = KERP_Modules_Marketing_Store::text( $input['source_id'] ?? '' );
		if ( ! isset( $sources[$source_id] ) ) $this->error( 'یکی از منابع همین کمپین را انتخاب کنید.' );
		$date = KERP_Modules_Marketing_Store::daily_date( $input['metric_date'] ?? '' );
		if ( is_wp_error( $date ) ) $this->error( $date->get_error_message() );
		$metric = [ 'source_id' => $source_id, 'source' => $sources[$source_id], 'date' => $date ];
		foreach ( KERP_Modules_Marketing_Store::metric_fields() as $key => $label ) {
			$metric[$key] = KERP_Modules_Marketing_Store::number( $input[$key] ?? '', ! in_array( $key, [ 'cost', 'sales' ], true ) );
			if ( is_wp_error( $metric[$key] ) ) $this->error( $label . ': ' . $metric[$key]->get_error_message() );
		}
		$entries = json_decode( $row['metric_entries'] ?? '[]', true ) ?: [];
		$key = hash( 'sha256', $source_id . ':' . $date );
		$editing = KERP_Modules_Marketing_Store::text( $input['entry_key'] ?? '' );
		if ( ( isset( $entries[$key] ) && $editing !== $key ) || ( $editing !== '' && ( $editing !== $key || ! isset( $entries[$key] ) ) ) ) $this->error( 'آمار این منبع و تاریخ قبلاً ثبت شده؛ تاریخ و منبع را دوباره انتخاب کنید تا اطلاعات برای ویرایش نمایش داده شود.' );
		if ( ! isset( $entries[$key] ) && count( $entries ) >= 3650 ) $this->error( 'ظرفیت ثبت عملکرد این کمپین تکمیل شده است.' );
		$entries[$key] = $metric;
		$this->update( $row, [ 'metric_entries' => wp_json_encode( $entries ), 'sources' => wp_json_encode( $sources ) ], $editing !== '' ? 'اصلاح عملکرد روزانه' : 'ثبت عملکرد روزانه', $sources[$source_id] . ' · ' . KERP_Modules_Marketing_View::jalali( $date ) );
		$this->success( 'عملکرد منبع ذخیره شد.', (int) $row['id'] );
	}
	public function delete(): void {
		$this->guard( 'delete' );
		$input = $this->input();
		foreach ( [ 'id', 'version' ] as $key ) {
			if ( ! preg_match( '/^[1-9][0-9]*$/', KERP_Modules_Marketing_Store::text( $input[$key] ?? '' ) ) ) $this->error( 'شناسه یا نسخه درخواست معتبر نیست.' );
		}
		if ( ! is_array( $input['confirm_delete'] ?? null ) || ! in_array( 'yes', $input['confirm_delete'], true ) ) $this->error( 'برای حذف دائمی درخواست، تأیید حذف را انتخاب کنید.' );
		$row = $this->record();
		global $wpdb;
		// The request owns its history, sources and metrics in this single row.
		// Recheck scope and version in the atomic delete to reject concurrent changes.
		$result = $wpdb->query( $wpdb->prepare(
			'DELETE FROM ' . KERP_Modules_Marketing_Store::table() . ' WHERE id=%d AND version=%d AND ' . KERP_Modules_Marketing_Store::scope(),
			(int) $row['id'], (int) $row['version']
		) );
		if ( $result !== 1 ) $this->error( 'حذف انجام نشد یا درخواست هم‌زمان تغییر کرده است؛ صفحه را تازه کنید.' );
		$this->success( 'درخواست تبلیغ حذف شد.' );
	}
	public function bulk(): void {
		$this->guard( 'archive' );
		$input = $this->input();
		if ( ( $input['operation'] ?? '' ) !== 'archive' || ! is_array( $input['customer_ids'] ?? null ) || count( $input['customer_ids'] ) > 100 ) $this->error( 'عملیات یا تعداد انتخاب‌ها معتبر نیست.' );
		$rows = [];
		foreach ( $input['customer_ids'] as $value ) if ( ! is_scalar( $value ) || ! ctype_digit( (string) $value ) ) $this->error( 'شناسه انتخاب‌شده معتبر نیست.' );
		foreach ( array_unique( array_map( 'intval', $input['customer_ids'] ) ) as $id ) {
			$row = KERP_Modules_Marketing_Store::get( $id );
			if ( ! $row || ! in_array( $row['status'], [ 'completed', 'rejected' ], true ) ) $this->error( 'فقط درخواست‌های پایان‌یافته یا برگشتی مرتبط با خود را انتخاب کنید.' );
			$rows[] = $row;
		}
		if ( ! $rows ) $this->error( 'درخواستی انتخاب نشده است.' );
		global $wpdb;
		if ( $wpdb->query( 'START TRANSACTION' ) === false ) $this->error( 'شروع عملیات گروهی ناموفق بود.' );
		foreach ( $rows as $row ) {
			if ( ! $this->update( $row, [ 'status' => 'archived' ], 'بایگانی', '', false ) ) {
				$wpdb->query( 'ROLLBACK' );
				$this->error( 'یکی از درخواست‌ها تغییر کرده است؛ هیچ موردی بایگانی نشد. صفحه را تازه کنید.' );
			}
		}
		if ( $wpdb->query( 'COMMIT' ) === false ) { $wpdb->query( 'ROLLBACK' ); $this->error( 'ذخیره عملیات گروهی ناموفق بود.' ); }
		$this->success( 'درخواست‌ها بایگانی شدند.' );
	}
	private function error( string $message ): never { wp_send_json( [ 'status' => 'error', 'message' => $message, 'msg' => $message ] ); }
	private function success( string $message, int $id = 0 ): never {
		$path = $id ? '/erp/marketing/requests/' . $id . '/' : '/erp/marketing/requests/';
		if ( $id && ( $this->input()['action'] ?? '' ) === 'marketing_metric' ) $path .= 'dashboard/';
		wp_send_json( array_merge( [ 'status' => 'success', 'message' => $message, 'msg' => $message ], KERP_Api_Page_Content::build_page_response( $path, [], true ) ) );
	}
}






