<?php
defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Marketing_View {
	
	public static function money( mixed $value, string $currency ): string {
		return KERP_Helpers_Template::price( $value, [ 'currency' => $currency ] );
	}

	public static function money_label( string $currency ): string {
		return $currency === 'IRR' ? 'ریال' : 'تومان';
	}
	
	public static function display( $value, ?int $decimals = NULL ): string {
		return $value === NULL ? '—' : number_format_i18n( (float) $value, $decimals ?? ( (float) $value === floor( (float) $value ) ? 0 : 2 ) );
	}
	
	public static function jalali( string $date ): string {
		return KERP_Helpers_Date::gregorian_to_jalali( $date );
	}
	
	public static function fields( array $definitions, string $prefix, array $values = [] ): array {
		$fields = [];
		foreach ( $definitions as $key => $definition ) {
			$definition = is_array( $definition ) ? $definition : [ 'label' => $definition ];
			// Shared number fields strip signs and decimal points before submission; use text
			// fields so server validation receives the original financial/count input.
			if ( ( $definition['type'] ?? '' ) === 'number' ) {
				$definition['type'] = 'text';
			}
			$fields[] = $definition + [
					'id'          => $prefix . '-' . $key,
					'name'        => $key,
					'type'        => 'text',
					'input_class' => 'no_clear',
					'value'       => $values[ $key ] ?? '',
					'required'    => TRUE,
				];
		}
		
		return $fields;
	}
	
	public static function hidden( string $name, $value ): array {
		return [ 'type' => 'hidden', 'name' => $name, 'value' => $value, 'input_class' => 'no_clear' ];
	}
	
	public static function modal( string $id, string $title, string $action, array $fields, array $row = [], string $body = '', string $footer_note = '' ): void {
		$fields[] = self::hidden( 'marketing_nonce', wp_create_nonce( 'kerp_marketing' ) );
		if ( $row ) {
			$fields[] = self::hidden( 'id', $row['id'] );
			$fields[] = self::hidden( 'version', $row['version'] );
		}
		KERP_Helpers_Template::render_modal( [
			'id'     => $id,
			'title'  => $title,
			'action' => 'marketing_' . $action,
			'page'   => '/erp/marketing/',
			'fields' => $fields,
			'body'   => $body,
			'footer_note' => $footer_note,
			'button' => 'ثبت و ذخیره',
		] );
	}
	
	public static function delete_modal( array $row ): void {
		if ( ! kerp_can( 'marketing.delete', 'action' ) ) return;
		$id = 'marketingDeleteRequest' . (int) $row['id'];
		$fields = [];
		foreach ( [ 'id' => (int) $row['id'], 'version' => (int) $row['version'], 'marketing_nonce' => wp_create_nonce( 'kerp_marketing' ) ] as $name => $value ) {
			$fields[] = self::hidden( $name, $value ) + [ 'id' => $id . '-' . $name ];
		}
		$fields[] = [ 'type' => 'checkbox', 'name' => 'confirm_delete', 'id' => $id . '-confirm', 'class' => 'col-12', 'required' => true, 'options' => [ 'yes' => 'حذف دائمی درخواست و آمار و سوابق آن را تأیید می‌کنم.' ] ];
		$body = '<div class="col-12"><p>حذف درخواست <strong>' . esc_html( $row['title'] ) . '</strong></p><div class="alert alert-danger mb-0">این درخواست به همراه منابع، آمار کمپین، اطلاعات پرداخت و تاریخچه اقدامات آن برای همیشه حذف می‌شود و قابل بازگشت نیست. فایل‌های پیوست از سرور حذف نمی‌شوند.</div></div>';
		KERP_Helpers_Template::render_modal( [ 'id' => $id, 'title' => 'حذف درخواست تبلیغ', 'action' => 'marketing_delete', 'page' => '/erp/marketing/requests/', 'fields' => $fields, 'body' => $body, 'button' => 'حذف دائمی درخواست' ] );
	}

	public static function request_modal( array $row = [] ): void {
		$currency = $row['currency'] ?? ( get_option( 'kerp_marketing_settings', [] )['currency'] ?? 'IRT' );
		$values   = $row;
		if ( $row ) {
			$values['execution_date'] = self::jalali( $row['execution_date'] );
		}
		$fields   = self::fields( [
			'title'          => 'عنوان کمپین / درخواست',
			'ad_type'        => 'نوع تبلیغ',
			'platform'       => 'پلتفرم تبلیغ',
			'execution_date' => [ 'label' => 'تاریخ اجرای تبلیغ', 'type' => 'date' ],
			'cost'           => [
				'label' => 'هزینه تبلیغ',
				'type'  => 'price',
			],
			'expected_leads' => [ 'label' => 'برآورد تعداد مشتری بالقوه', 'type' => 'number' ],
			'expected_sales' => [
				'label' => 'برآورد فروش',
				'type'  => 'price',
			],
		], 'marketing-request', $values );
		$fields[] = [ 'type' => 'repeater', 'name' => 'sources', 'id' => 'marketing-request-sources', 'label' => 'منابع کمپین', 'button_text' => 'افزودن منبع', 'row_class' => 'col-12', 'fields' => [ [ 'type' => 'text', 'name' => 'name', 'label' => 'نام منبع', 'class' => 'col-12', 'required' => false ] ], 'value' => array_map( static fn( $name ) => [ 'name' => $name ], array_values( $row ? KERP_Modules_Marketing_Store::sources( $row ) : [] ) ) ];
		$fields[] = self::hidden( 'request_token', wp_generate_uuid4() );
		self::modal( 'marketingRequestModal', $row ? 'اصلاح و ارسال مجدد درخواست' : 'درخواست تبلیغ جدید', 'save', $fields, $row );
	}
	
	public static function editable( array $row ): bool {
		return kerp_can( 'marketing.edit', 'action' ) && in_array( $row['status'], [
				'pending',
				'rejected',
			], TRUE );
	}
	
	public static function metrics_editable( array $row ): bool {
		return kerp_can( 'marketing.metrics', 'action' ) && in_array( $row['status'], [ 'paid', 'completed' ], true );
	}
}
