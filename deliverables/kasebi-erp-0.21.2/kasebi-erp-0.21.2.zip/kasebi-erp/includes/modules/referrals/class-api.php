<?php
defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Referrals_Api {
    private static ?self $instance=null;
    public static function instance(): self { return self::$instance ??= new self(); }
    private bool $erp = false;
    private function __construct() {
        add_action('nooshika_ajax_kerp_referrals_history',[$this,'history']);
        foreach(['settings','create','toggle','reconcile','users','products','companies'] as $action){
            add_action('nooshika_ajax_kerp_referrals_'.$action,[$this,$action]);
            add_action('kasebi_ajax_referrals_'.$action,function() use ($action): void {
                $this->erp = true;
                try{$this->$action();}finally{$this->erp=false;}
            });
        }
    }
    public function history(): void {
        // Customer history is independent of ERP staff permissions, but always owner-scoped.
        if(!is_user_logged_in()){$this->fail('برای مشاهده معرفی‌ها وارد حساب کاربری شوید.');}
        if(!is_string($_POST['nonce'] ?? null) || !wp_verify_nonce(wp_unslash($_POST['nonce']),'kerp_referrals')){$this->fail('اعتبار صفحه منقضی شده است؛ صفحه را تازه کنید.');}
        $filters=KERP_Modules_Referrals_View::panel_filters(wp_unslash($_POST));
        ob_start();
        KERP_Modules_Referrals_View::listing($filters,get_current_user_id(),false,home_url('/panel/referrals/'));
        $html=ob_get_clean();
        wp_send_json(['status'=>'success','html'=>$html]);
    }
    private function success( string $message ): void {
        $response=['status'=>'success','message'=>$message,'reload'=>true];
        if($this->erp){
            $page=is_string($_POST['page'] ?? null) ? wp_unslash($_POST['page']) : '';
            $path=(string)wp_parse_url($page,PHP_URL_PATH);
            if(!preg_match('#^/erp/(?:referrals/|settings/referrals(?:/(?:general|commissions))?/|customers/[1-9][0-9]*/)$#D',$path)){$path='/erp/referrals/';$page=$path;}
            parse_str((string)wp_parse_url($page,PHP_URL_QUERY),$query);
            $query=array_intersect_key(array_filter($query,'is_scalar'),array_flip(['tab','referral_tab','state','kind','order_id','search','active','page_number','per_page']));
            $response=array_merge(KERP_Api_Page_Content::build_page_response($path,$query,true),['status'=>'success','message'=>$message]);
        }
        wp_send_json($response);
    }
    private function fail( string $message ): void { wp_send_json(['status'=>'error','message'=>$message]); }
    private function guard( string $permission ): void {
        if(!is_user_logged_in() || !KERP_App::instance()->current_user_has_access() || !kerp_can('referrals.'.$permission,'action')){$this->fail('اجازه انجام این عملیات را ندارید.');}
        if($this->erp && in_array($_POST['action'] ?? '',['referrals_users','referrals_products','referrals_companies'],true)){return;} // Read-only, permission-checked searches.
        if(!isset($_POST['nonce']) || !is_string($_POST['nonce']) || !wp_verify_nonce(wp_unslash($_POST['nonce']),'kerp_referrals')){$this->fail('اعتبار فرم منقضی شده است؛ صفحه را تازه کنید.');}
    }
    private function input(): array {
        $out=[];
        foreach(wp_unslash($_POST) as $key=>$value){
            if($key==='product_commissions' && in_array($_POST['action'] ?? '',['referrals_settings','kerp_referrals_settings'],true)){$out[$key]=$value;continue;}
            if($this->erp && in_array($key,['enabled','product_overrides'],true) && $value===['1']){$value='1';}
            if(!is_scalar($value)){$this->fail('ورودی فرم معتبر نیست.');}
            $out[$key]=(string)$value;
        }
        return $out;
    }
    public function settings(): void {
        $this->guard('manage_settings');
        $input=$this->input();
        $section=$input['settings_section'] ?? '';
        $sections=[
            'private'=>['private_discount_type','private_discount_value','company_type','company_value','marketer_type','marketer_value'],
            'general'=>['public_limit','cookie_days','customer_benefit','discount_type','discount_value','referrer_type','referrer_value','payout_status','terms'],
            'commissions'=>[],
        ];
        if(!isset($sections[$section])){$this->fail('بخش تنظیمات معتبر نیست.');}
        $values=KERP_Modules_Referrals_Settings::all();
        foreach($sections[$section] as $key){
            if(array_key_exists($key,$input)){$values[$key]=$input[$key];}
        }
        if($section==='general'){
            // A disabled switch is not posted by the shared ERP form component.
            $values['enabled']=!empty($input['enabled']);
        }
        if($section==='commissions'){
            $values['product_commissions']=$input['product_commissions'] ?? [];
            $values['product_overrides']=false;
        }
        $values=KERP_Modules_Referrals_Settings::sanitize($values);
        if(is_wp_error($values)){$this->fail($values->get_error_message());}
        if($values['enabled'] && class_exists('Kasebi_Referrals',false)){$this->fail('ابتدا افزونه قدیمی کاسبی رفرال را غیرفعال کنید تا دو سامانه هم‌زمان کمیسیون ثبت نکنند.');}
        update_option('kerp_referrals_settings',$values,false);
        $this->success('تنظیمات همکاری در فروش ذخیره شد.');
    }
    public function create(): void {
        $manager=kerp_can('referrals.manage_codes','action');$this->guard($manager ? 'manage_codes':'create_codes');
        $input=$this->input();$admin=KERP_Helpers_User::is_admin();
        if($admin && $this->erp && !empty($input['expires'])){
            $input['expires']=KERP_Helpers_Date::jalali_to_gregorian($input['expires']);
            if($input['expires']===''){$this->fail('تاریخ انقضا معتبر نیست.');}
        }
        $result=KERP_Modules_Referrals_Codes::create_private($input,get_current_user_id(),$admin);
        if(is_wp_error($result)){$this->fail($result->get_error_message());}
        $this->success('کد خصوصی ثبت شد.');
    }
    public function toggle(): void {
        $manager=kerp_can('referrals.manage_codes','action');$this->guard($manager ? 'manage_codes':'create_codes');$input=$this->input();
        if(!KERP_Modules_Referrals_Store::lock()){$this->fail('درخواست دیگری در حال پردازش است.');}
        $message=null;
        try{
            $code=KERP_Modules_Referrals_Store::code(absint($input['code_id'] ?? 0));
            if(!$code || (!$manager && ($code['kind']!=='private' || (int)$code['marketer_id']!==get_current_user_id()))){$message='اجازه تغییر این کد را ندارید.';}
            else{KERP_Modules_Referrals_Store::update('codes',['active'=>($input['active'] ?? '')==='1'?1:0],(int)$code['id']);}
        }catch(Throwable $e){$message='تغییر وضعیت کد انجام نشد.';}finally{KERP_Modules_Referrals_Store::unlock();}
        if($message){$this->fail($message);}$this->success('وضعیت کد تغییر کرد.');
    }
    public function reconcile(): void {
        $this->guard('reconcile');$input=$this->input();$order_id=absint($input['order_id'] ?? 0);
        if(!KERP_Modules_Referrals_Store::referral($order_id)){$this->fail('معرفی سفارش پیدا نشد.');}
        KERP_Modules_Referrals_Settlement::instance()->reconcile($order_id,true);
        $row=KERP_Modules_Referrals_Store::referral($order_id);
        if($row['state']==='review'){$this->fail($row['error'] ?: 'این سفارش همچنان نیازمند بررسی است.');}
        $this->success('وضعیت کمیسیون با سفارش و کیف پول تطبیق داده شد.');
    }
    public function users(): void {
        $this->guard(kerp_can('referrals.manage_codes','action') ? 'manage_codes':'create_codes');$input=$this->input();$term=sanitize_text_field($input[$this->erp ? 'search':'term'] ?? '');
        if(mb_strlen($term)<2){wp_send_json(['status'=>'success','users'=>[],'results'=>[]]);}
        $query=new WP_User_Query(['search'=>'*'.$term.'*','search_columns'=>['display_name','user_login','user_email'],'number'=>15,'fields'=>['ID','display_name']]);
        $rows=[];foreach($query->get_results() as $user){$rows[]=['id'=>(int)$user->ID,'label'=>get_user_name_by_id((int)$user->ID).' (#'.$user->ID.')'];}
        wp_send_json(['status'=>'success','users'=>$rows,'results'=>$rows]);
    }
    public function products(): void {
        $this->guard('manage_settings');$input=$this->input();$search=sanitize_text_field($input['search'] ?? '');
        if(mb_strlen($search)<2){wp_send_json(['results'=>[]]);}
        $ids=WC_Data_Store::load('product')->search_products($search,'',true,false,30);
        $results=[];
        foreach($ids as $id){
            $product=wc_get_product($id);
            if(!$product || $product->get_status()==='trash' || KERP_Modules_Referrals_Codes::wallet_product($product)){continue;}
            $results[]=['id'=>$product->get_id(),'text'=>wp_strip_all_tags($product->get_formatted_name())];
        }
        wp_send_json(['results'=>$results]);
    }
    public function companies(): void {
        $this->guard(kerp_can('referrals.manage_codes','action') ? 'manage_codes':'create_codes');
        $input=$this->input();$search=sanitize_text_field($input['search'] ?? '');
        if(mb_strlen($search)<2){wp_send_json(['users'=>[]]);}
        $query=KERP_Modules_Customers_Query::instance();$result=$query->search($search,10,0);$users=[];
        foreach((array)($result['items'] ?? []) as $user){
            if(!$user instanceof WP_User){continue;}
            $users[]=['id'=>(int)$user->ID,'name'=>get_user_name_by_id((int)$user->ID),'phone'=>$query->get_customer_phone((int)$user->ID)];
        }
        wp_send_json(['users'=>$users]);
    }
}
