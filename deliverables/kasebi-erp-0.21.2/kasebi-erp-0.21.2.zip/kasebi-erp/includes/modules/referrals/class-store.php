<?php
defined( 'ABSPATH' ) || exit;

/** All attribution reservations and settlements use a connection-owned lock. */
final class KERP_Modules_Referrals_Store {
    public static function table( string $suffix ): string { global $wpdb; return $wpdb->prefix . 'kerp_referral_' . $suffix; }
    public static function install(): void {
        if ( get_option( 'kerp_referrals_db_version' ) === '1.0' ) { return; }
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();
        $codes = self::table('codes'); $refs = self::table('orders'); $ledger = self::table('ledger');
        dbDelta( "CREATE TABLE {$codes} (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            code varchar(100) NOT NULL,
            kind varchar(10) NOT NULL,
            public_owner bigint unsigned DEFAULT NULL,
            company_id bigint unsigned NOT NULL DEFAULT 0,
            marketer_id bigint unsigned NOT NULL DEFAULT 0,
            coupon_id bigint unsigned NOT NULL DEFAULT 0,
            title varchar(190) NOT NULL DEFAULT '',
            active tinyint NOT NULL DEFAULT 1,
            rules longtext NOT NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY code (code),
            UNIQUE KEY public_owner (public_owner),
            KEY marketer (marketer_id),
            KEY company (company_id)
        ) {$charset};" );
        dbDelta( "CREATE TABLE {$refs} (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            order_id bigint unsigned NOT NULL,
            code_id bigint unsigned NOT NULL,
            kind varchar(10) NOT NULL,
            customer_id bigint unsigned NOT NULL DEFAULT 0,
            public_customer bigint unsigned DEFAULT NULL,
            referrer_id bigint unsigned NOT NULL DEFAULT 0,
            marketer_id bigint unsigned NOT NULL DEFAULT 0,
            code varchar(100) NOT NULL,
            currency varchar(12) NOT NULL,
            base decimal(20,6) NOT NULL DEFAULT 0,
            order_total decimal(20,6) NOT NULL DEFAULT 0,
            discount decimal(20,6) NOT NULL DEFAULT 0,
            snapshot longtext NOT NULL,
            state varchar(20) NOT NULL DEFAULT 'pending',
            error text NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY order_id (order_id),
            UNIQUE KEY public_customer (public_customer),
            KEY code_id (code_id),
            KEY referrer (referrer_id),
            KEY marketer (marketer_id),
            KEY customer (customer_id),
            KEY state (state)
        ) {$charset};" );
        dbDelta( "CREATE TABLE {$ledger} (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            referral_id bigint unsigned NOT NULL,
            user_id bigint unsigned NOT NULL,
            role varchar(20) NOT NULL,
            amount decimal(20,6) NOT NULL,
            state varchar(20) NOT NULL DEFAULT 'ready',
            transaction_id bigint unsigned NOT NULL DEFAULT 0,
            attempts int unsigned NOT NULL DEFAULT 0,
            error text NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY referral (referral_id),
            KEY user_id (user_id)
        ) {$charset};" );
        foreach ([$codes,$refs,$ledger] as $table) {
            if($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$wpdb->esc_like($table)))!==$table){return;}
        }
        update_option('kerp_referrals_db_version', '1.0', false);
    }
    public static function lock(): bool {
        global $wpdb;
        return (string) $wpdb->get_var( $wpdb->prepare('SELECT GET_LOCK(%s, 10)', 'kerp_ref_' . md5($wpdb->prefix)) ) === '1';
    }
    public static function unlock(): void { global $wpdb; $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)', 'kerp_ref_' . md5($wpdb->prefix))); }
    public static function code( int|string $value ): ?array {
        global $wpdb; $t = self::table('codes');
        return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE " . (is_int($value) ? 'id = %d' : 'code = %s'), $value ), ARRAY_A ) ?: null;
    }
    public static function referral( int $order_id ): ?array {
        global $wpdb; $t = self::table('orders');
        return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t} WHERE order_id = %d", $order_id), ARRAY_A) ?: null;
    }
    public static function used( int $code_id, int $exclude_order = 0 ): int {
        global $wpdb; $t = self::table('orders');
        // Reserved slots remain assigned to their first customer, including failed payments.
        $count = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$t} WHERE code_id = %d AND order_id != %d", $code_id, $exclude_order));
        if ( $wpdb->last_error ) { throw new RuntimeException('خواندن ظرفیت معرفی انجام نشد.'); }
        return (int) $count;
    }
    public static function update( string $table, array $data, int $id ): void {
        global $wpdb;
        if ( false === $wpdb->update(self::table($table), $data, ['id'=>$id]) ) { throw new RuntimeException('ذخیره اطلاعات همکاری در فروش انجام نشد.'); }
    }
    public static function insert( string $table, array $data ): int {
        global $wpdb;
        if ( ! $wpdb->insert(self::table($table), $data) ) { throw new RuntimeException('ثبت اطلاعات همکاری در فروش انجام نشد؛ دوباره تلاش کنید.'); }
        return (int) $wpdb->insert_id;
    }
    public static function listing( array $filters, int $viewer = 0, bool $all = false, bool $include_customer = false ): array {
        global $wpdb; $t = self::table('orders');
        $where = '1=1'; $args = [];
        if ( ! $all ) {
            // Personal affiliate history belongs to the referrer/marketer, not the buyer.
            if ( $viewer <= 0 ) { $where .= ' AND 1=0'; }
            else {
                $where .= ' AND (referrer_id=%d OR marketer_id=%d';
                array_push($args, $viewer, $viewer);
                // The permission-checked ERP customer report also includes their purchases.
                if ( $include_customer ) { $where .= ' OR customer_id=%d'; $args[] = $viewer; }
                $where .= ')';
            }
        }
        foreach ( ['state','kind','order_id','code_id'] as $key ) {
            if ( isset($filters[$key]) && is_scalar($filters[$key]) && (string)$filters[$key] !== '' ) { $where .= " AND {$key}=%s"; $args[] = (string)$filters[$key]; }
        }
        $page = max(1, min(100000, (int)($filters['ref_page'] ?? 1)));
        $sql = "SELECT COUNT(*) FROM {$t} WHERE {$where}";
        $total = (int)$wpdb->get_var($args ? $wpdb->prepare($sql,$args) : $sql);
        $per_page=max(1,min(100,(int)($filters['per_page'] ?? 20)));
        $pages=max(1,(int)ceil($total/$per_page));$page=min($page,$pages);
        $rows = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$t} WHERE {$where} ORDER BY id DESC LIMIT %d OFFSET %d", array_merge($args,[$per_page,($page-1)*$per_page])), ARRAY_A) ?: [];
        return ['rows'=>$rows,'total'=>$total,'page'=>$page,'pages'=>$pages];
    }
    public static function codes_listing( array $filters, int $viewer, bool $all ): array {
        global $wpdb;$t=self::table('codes');$where="kind='private'";$args=[];
        if(!$all){$where.=' AND (marketer_id=%d OR company_id=%d)';array_push($args,$viewer,$viewer);}
        if(in_array($filters['active'] ?? '',['yes','no'],true)){$where.=' AND active=%d';$args[]=($filters['active']==='yes' ? 1:0);}
        if(!empty($filters['search'])){$where.=' AND (code LIKE %s OR title LIKE %s)';$like='%'.$wpdb->esc_like($filters['search']).'%';array_push($args,$like,$like);}
        $sql="SELECT COUNT(*) FROM {$t} WHERE {$where}";
        $total=(int)$wpdb->get_var($args ? $wpdb->prepare($sql,$args):$sql);
        $per_page=max(1,min(100,(int)($filters['per_page'] ?? 20)));
        $pages=max(1,(int)ceil($total/$per_page));$page=min($pages,max(1,(int)($filters['page_number'] ?? 1)));
        $rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM {$t} WHERE {$where} ORDER BY id DESC LIMIT %d OFFSET %d",array_merge($args,[$per_page,($page-1)*$per_page])),ARRAY_A) ?: [];
        return ['rows'=>$rows,'total'=>$total,'page'=>$page,'pages'=>$pages];
    }
    public static function codes( int $viewer, bool $all, int $page = 1 ): array {
        global $wpdb; $t = self::table('codes');
        $where = $all ? "kind='private'" : $wpdb->prepare("kind='private' AND (marketer_id=%d OR company_id=%d)", $viewer,$viewer);
        return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$t} WHERE {$where} ORDER BY id DESC LIMIT 21 OFFSET %d", (max(1,$page)-1)*20), ARRAY_A) ?: [];
    }
    public static function ledger( int $referral_id ): array {
        global $wpdb;$t=self::table('ledger');
        return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$t} WHERE referral_id=%d ORDER BY id DESC LIMIT 100",$referral_id),ARRAY_A) ?: [];
    }
}
