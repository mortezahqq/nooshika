<?php
defined( 'ABSPATH' ) || exit;

/** Native ERP components; the customer panel keeps its independent presentation. */
final class KERP_Modules_Referrals_Admin_View {
    public static function field( string $name, string $label, string $type, mixed $value = '', array $args = [] ): void {
        KERP_Helpers_Template::render_template('app/components/fields/'.$type.'.php',[
            'field'=>array_merge(['id'=>'referrals-'.$name,'name'=>$name,'label'=>$label,'value'=>$value,'class'=>'col-md-6'],$args),
        ]);
    }
    public static function rates( string $prefix, string $label, array $values, bool $card_layout = false ): void {
        $column=$card_layout ? 'col-12':'col-md-6';
        self::field($prefix.'_type',$card_layout ? 'روش محاسبه':'نوع '.$label,'select',$values[$prefix.'_type'],['options'=>['percent'=>'درصد','fixed'=>'مبلغ ثابت'],'required'=>true,'class'=>$column,'input_class'=>'no_clear']);
        foreach(['percent'=>'درصد','fixed'=>'مبلغ'] as $type=>$unit){
            // The shared number field strips decimals; text preserves fractional percentages.
            self::field($prefix.'_value',$card_layout ? $unit:$label.' — '.$unit,$type==='fixed' ? 'price':'text',$values[$prefix.'_value'],[
                'id'=>'referrals-'.$prefix.'-'.$type,'required'=>true,'conditional'=>true,
                'cond_meta'=>$prefix.'_type','cond_operator'=>'==','cond_expected'=>$type,
                'class'=>$column.($values[$prefix.'_type']!==$type ? ' d-none':''),
                'input_class'=>'no_clear',
                'description'=>$type==='percent' ? 'مقدار مجاز از ۰ تا ۱۰۰ است.':'واحد مبلغ: '.get_woocommerce_currency_symbol(),
            ]);
        }
    }
    public static function nonce(): void { self::field('nonce','','hidden',wp_create_nonce('kerp_referrals'),['id'=>'','class'=>'no_clear']); }
    public static function action( string $action, string $label, array $values, string $page ): void {
        ?>
        <form class="modal_form d-inline-block" data-action="<?php echo esc_attr('referrals_'.$action); ?>" data-page="<?php echo esc_attr($page); ?>">
            <?php self::nonce(); foreach($values as $key=>$value){self::field($key,'','hidden',$value,['id'=>'']);} ?>
            <button type="button" class="btn btn-sm btn-outline-light submit_modal_form"><?php echo esc_html($label); ?></button>
        </form>
        <?php
    }
    public static function copy( string $value, string $label ): void {
        ?><span class="d-inline-block"><button type="button" class="btn btn-sm btn-outline-light clipboard-init" data-clipboard-text="<?php echo esc_attr($value); ?>" data-clip-text="<?php echo esc_attr($label); ?>"><em class="icon ni ni-copy"></em><span class="clipboard-text"><?php echo esc_html($label); ?></span></button></span><?php
    }
    public static function notice(): void {
        $message=class_exists('Kasebi_Referrals',false) ? 'افزونه قدیمی کاسبی رفرال فعال است؛ پیش از فعال کردن سامانه جدید آن را غیرفعال کنید.'
            : (!KERP_Modules_Referrals_Settings::available() ? 'پذیرش کدهای جدید غیرفعال است؛ تسویه و پیگیری معرفی‌های قبلی ادامه دارد.':'');
        if($message){echo '<div class="alert alert-warning mb-4" role="status">'.esc_html($message).'</div>';}
    }
    public static function filters( array $query ): array {
        $query=array_filter($query,'is_scalar');
        foreach(['state','kind','order_id'] as $key){if(($query[$key] ?? '')==='0'){unset($query[$key]);}}
        $query['per_page']=in_array((int)($query['per_page'] ?? 20),[10,20,50,100],true) ? (int)($query['per_page'] ?? 20):20;
        $query['ref_page']=$query['page_number'] ?? $query['ref_page'] ?? 1;
        return $query;
    }
    public static function listing( array $query, int $viewer, bool $all, string $route, bool $admin, bool $codes = false ): void {
        $filters=self::filters($query);
        $result=$codes ? KERP_Modules_Referrals_Store::codes_listing($filters,$viewer,$all) : KERP_Modules_Referrals_Store::listing($filters,$viewer,$all);
        $fields=$codes ? [
            ['name'=>'search','label'=>'کد یا عنوان همکاری','type'=>'text','value'=>$filters['search'] ?? ''],
            ['name'=>'active','label'=>'وضعیت کد','type'=>'select','value'=>$filters['active'] ?? '', 'options'=>['yes'=>'فعال','no'=>'غیرفعال']],
        ] : [
            ['name'=>'state','label'=>'وضعیت کمیسیون','type'=>'select','value'=>$filters['state'] ?? '', 'options'=>KERP_Modules_Referrals_View::statuses()],
            ['name'=>'kind','label'=>'نوع معرفی','type'=>'select','value'=>$filters['kind'] ?? '', 'options'=>['public'=>'عمومی','private'=>'خصوصی']],
            ['name'=>'order_id','label'=>'شماره سفارش','type'=>'number','value'=>$filters['order_id'] ?? ''],
        ];
        $has_filter=false;foreach($fields as $field){if(!empty($field['value']) && $field['value']!=='0'){$has_filter=true;}}
        $fields[]=['name'=>'per_page','type'=>'hidden','value'=>$filters['per_page']];
        KERP_Helpers_Template::render_template('modules/referrals/partials/list.php',compact('filters','result','fields','has_filter','viewer','all','route','admin','codes'));
    }
}
