<?php
defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Referrals_Checkout {
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		return self::$instance ??= new self();
	}
	
	private function __construct() {
		add_action( 'nooshika_checkout_before_coupon', [ $this, 'render_field' ] );
		add_action( 'wp_enqueue_scripts', [ $this, 'field_assets' ], 110 );
		add_action( 'nooshika_ajax_kerp_referrals_apply', [ $this, 'apply_field' ] );
		add_action( 'nooshika_ajax_kerp_referrals_remove', [ $this, 'remove_field' ] );
		add_filter( 'nooshika_checkout_manual_coupon_error', [ $this, 'manual_coupon_error' ], 10, 2 );
		add_filter( 'nooshika_checkout_coupon_label', [ $this, 'coupon_label' ], 10, 2 );
		add_filter( 'woocommerce_coupon_is_valid', [ $this, 'validate_coupon' ], 20, 3 );
		add_filter( 'woocommerce_coupon_error', [ $this, 'coupon_error' ], 100, 3 );
		add_filter( 'woocommerce_coupon_get_amount', [ KERP_Modules_Referrals_Codes::class, 'coupon_amount' ], 20, 2 );
		add_filter( 'woocommerce_coupon_get_discount_type', [
			KERP_Modules_Referrals_Codes::class,
			'coupon_type',
		], 20, 2 );
		add_action( 'woocommerce_checkout_order_created', [ $this, 'attach' ], 20 );
		add_action( 'woocommerce_store_api_checkout_order_processed', [ $this, 'attach' ], 20 );
		add_action( 'woocommerce_before_pay_action', [ $this, 'pay' ], 20 );
		add_action( 'template_redirect', [ $this, 'capture_link' ], 5 );
		add_action( 'woocommerce_before_calculate_totals', [ $this, 'apply_link' ], 5 );
		add_action( 'woocommerce_removed_coupon', [ $this, 'forget_link' ] );
		add_filter( 'nooshika_checkout_coupon', [ $this, 'direct_coupon' ], 10, 2 );
		add_shortcode( 'kerp_referral_link', [ $this, 'shortcode' ] );
		if ( ! shortcode_exists( 'kref_link' ) ) {
			add_shortcode( 'kref_link', [ $this, 'shortcode' ] );
		}
	}
	
	public function field_assets(): void {
		if ( kerp_is_erp_request() || ! is_page( [ 'cart', 'checkout', 'shipping', 'user_info' ] ) ) {
			return;
		}
		KERP_Helpers_Panel_Ajax::ensure_dependencies();
		wp_enqueue_style( 'kerp-referrals-checkout', KERP_ASSETS_URL . 'public/css/referrals-checkout.css', [], kerp_asset_version( 'public/css/referrals-checkout.css' ) );
		wp_enqueue_script( 'kerp-referrals-checkout', KERP_ASSETS_URL . 'public/js/referrals-checkout.js', [
			'jquery',
			'nooshika_buy_process',
		], kerp_asset_version( 'public/js/referrals-checkout.js' ), TRUE );
		wp_localize_script( 'kerp-referrals-checkout', 'KERPReferralCheckout', [ 'url' => home_url( '/n-ajax' ) ] );
	}
	
	private function applied_referral( bool $public_only = FALSE ): string {
		if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
			return '';
		}
		foreach ( WC()->cart->get_applied_coupons() as $text ) {
			$coupon = new WC_Coupon( $text );
			if ( ! $coupon->get_meta( '_kerp_referral_code' ) ) {
				continue;
			}
			$code = KERP_Modules_Referrals_Codes::from_coupon( $coupon );
			if ( ! $public_only || ( $code && $code['kind'] === 'public' ) ) {
				return $text;
			}
		}
		
		return '';
	}
	
	public function render_field(): void {
		if ( ! $this->first_purchase() ) {
			return;
		}
		$applied = $this->applied_referral( TRUE );
		if ( ! $applied && ! KERP_Modules_Referrals_Settings::available() ) {
			return;
		}
		KERP_Helpers_Template::render_template( 'modules/referrals/checkout/field.php', compact( 'applied' ) );
	}
	
	private function first_purchase(): bool {
		$user    = get_current_user_id();
		$account = $user ? get_userdata( $user ) : FALSE;
		$email   = $account ? $account->user_email : '';
		if ( function_exists( 'WC' ) && WC()->customer ) {
			$email = WC()->customer->get_billing_email() ?: $email;
		}
		
		return KERP_Modules_Referrals_Codes::first_order( $user, $email, 0 );
	}
	
	public function coupon_label( $label, $coupon ): string {
		$code = KERP_Modules_Referrals_Codes::from_coupon( $coupon );
		
		return $code && $code['kind'] === 'public' ? 'کد معرف' : (string) $label;
	}
	
	public function manual_coupon_error( $error, $text ): string {
		if ( $error ) {
			return (string) $error;
		}
		$coupon = new WC_Coupon( $text );
		$code   = KERP_Modules_Referrals_Codes::from_coupon( $coupon );
		if ( $coupon->get_meta( '_kerp_referral_code' ) && ! $code ) {
			return 'کد واردشده معتبر نیست.';
		}
		if ( $code && $code['kind'] === 'public' ) {
			return 'کد معرف عمومی فقط برای اولین خرید و از بخش «کد معرف دارید؟» قابل استفاده است.';
		}
		if ( $code && $code['kind'] === 'private' && WC()->cart->get_applied_coupons() && WC()->cart->get_applied_coupons() !== [ $text ] ) {
			return 'ابتدا کد فعلی را حذف کنید؛ کد خصوصی با کد دیگری هم‌زمان قابل استفاده نیست.';
		}
		$applied = $this->applied_referral();
		
		return $applied && $applied !== $text ? 'برای استفاده از کد جدید، ابتدا کد فعلی را حذف کنید.' : '';
	}
	
	private function field_guard(): void {
		if ( ! is_string( $_POST['nonce'] ?? NULL ) || ! wp_verify_nonce( wp_unslash( $_POST['nonce'] ), 'kerp_referral_checkout' ) ) {
			$this->field_error( 'اعتبار فرم منقضی شده است؛ صفحه را تازه کنید.' );
		}
		if ( ! function_exists( 'WC' ) || ! WC()->cart || ! function_exists( 'kasebi_create_step_html' ) ) {
			$this->field_error( 'سبد خرید در دسترس نیست.' );
		}
	}
	
	public static function safe_error( string $message ): string {
		// JSON consumers use text(), not HTML. Decode before stripping markup.
		for ( $i = 0; $i < 2; $i ++ ) {
			$message = html_entity_decode( $message, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		}
		$message = trim( wp_strip_all_tags( $message ) );
		if ( ! preg_match( '/[\x{0600}-\x{06FF}]/u', $message ) || preg_match( '/[a-zA-Z]|&(?:#\d+|#x[0-9a-f]+|[a-z]+);/i', $message ) ) {
			return 'کد معرف برای این سفارش قابل استفاده نیست؛ شرایط کد را بررسی کنید یا با پشتیبانی تماس بگیرید.';
		}
		
		return $message;
	}
	
	public function coupon_error( $message, $error_code, $coupon ): string {
		if ( ! $coupon instanceof WC_Coupon || ! $coupon->get_meta( '_kerp_referral_code' ) ) {
			return (string) $message;
		}
		// WooCommerce's numeric reason is available here, before WP_Error collapses it to invalid_coupon.
		$messages = [
			100 => 'کد معرف برای این سفارش قابل استفاده نیست.',
			101 => 'کد معرف دیگر برای این سفارش معتبر نیست و حذف شد.',
			102 => 'این کد معرف برای حساب کاربری یا ایمیل شما مجاز نیست.',
			103 => 'این کد معرف قبلاً روی سفارش اعمال شده است.',
			104 => 'کد معرف با کد دیگری هم‌زمان قابل استفاده نیست؛ ابتدا کد قبلی را حذف کنید.',
			105 => 'کد معرف پیدا نشد؛ کد واردشده را بررسی کنید.',
			106 => (int) $coupon->get_usage_limit() === 0 && (int) $coupon->get_usage_limit_per_user() > 0
				? 'سقف مجاز استفاده شما از این کد معرف رسیده است.' : 'سقف مجاز استفاده از این کد معرف رسیده است.',
			107 => 'مهلت استفاده از این کد معرف به پایان رسیده است.',
			108 => 'مبلغ سفارش به حداقل لازم برای استفاده از این کد معرف نرسیده است.',
			109 => 'این کد معرف برای محصولهای سبد خرید شما قابل استفاده نیست.',
			110 => 'این کد معرف برای محصولهای دارای تخفیف قابل استفاده نیست.',
			111 => 'لطفاً کد معرف را وارد کنید.',
			112 => 'مبلغ سفارش از حداکثر مجاز این کد معرف بیشتر است.',
			113 => 'برخی محصولهای سبد خرید مشمول این کد معرف نیستند.',
			114 => 'دسته‌بندی برخی محصولهای سبد خرید مشمول این کد معرف نیست.',
			115 => 'این کد معرف در سفارش در انتظار پرداخت رزرو شده است؛ سفارش قبلی را از بخش سفارش‌های خود پیگیری کنید.',
			116 => 'ظرفیت این کد معرف فعلاً رزرو شده است؛ کمی بعد دوباره تلاش کنید یا با پشتیبانی تماس بگیرید.',
		];
		
		return self::safe_error( $messages[ (int) $error_code ] ?? ( (int) $error_code === 9000 ? (string) $message : '' ) );
	}
	
	private function field_error( string $message ): void {
		wp_send_json( [ 'status' => 'error', 'msg' => self::safe_error( $message ) ] );
	}
	
	private function field_success( string $message ): void {
		WC()->cart->calculate_totals();
		wp_send_json( array_merge( kasebi_create_step_html( 'checkout' ), [
			'status' => 'success',
			'msg'    => $message,
		] ) );
	}
	
	public function apply_field(): void {
		$this->field_guard();
		if ( ! KERP_Modules_Referrals_Settings::available() ) {
			$this->field_error( 'پذیرش کد معرف در حال حاضر غیرفعال است.' );
		}
		if ( ! $this->first_purchase() ) {
			$this->field_error( 'کد معرف عمومی فقط برای اولین خرید قابل استفاده است.' );
		}
		$text = is_string( $_POST['referral_code'] ?? NULL ) ? wc_format_coupon_code( trim( wp_unslash( $_POST['referral_code'] ) ) ) : '';
		if ( $text === '' || strlen( $text ) > 60 ) {
			$this->field_error( 'کد معرف را به‌درستی وارد کنید.' );
		}
		$coupon = new WC_Coupon( $text );
		$code   = KERP_Modules_Referrals_Codes::from_coupon( $coupon );
		if ( ! $code ) {
			$this->field_error( 'کد معرف معتبر نیست؛ کد تخفیف را در بخش تخفیف وارد کنید.' );
		}
		if ( $code['kind'] !== 'public' ) {
			$this->field_error( 'کد خصوصی را در بخش «کد تخفیف دارید؟» وارد کنید.' );
		}
		$applied = WC()->cart->get_applied_coupons();
		if ( $applied && $applied !== [ $text ] ) {
			$this->field_error( 'ابتدا کد فعلی را حذف کنید؛ کد معرف با کد دیگری هم‌زمان قابل استفاده نیست.' );
		}
		$valid = ( new WC_Discounts( WC()->cart ) )->is_coupon_valid( $coupon );
		if ( is_wp_error( $valid ) ) {
			$this->field_error( $valid->get_error_message() );
		}
		if ( ! $valid ) {
			$this->field_error( 'کد معرف برای این سفارش قابل استفاده نیست.' );
		}
		if ( ! $applied && ! WC()->cart->apply_coupon( $text ) ) {
			$this->field_error( 'کد معرف اعمال نشد؛ شرایط سفارش را بررسی کنید.' );
		}
		$this->field_success( 'کد معرف روی سفارش اعمال شد.' );
	}
	
	public function remove_field(): void {
		$this->field_guard();
		$applied = $this->applied_referral( TRUE );
		if ( $applied ) {
			WC()->cart->remove_coupon( $applied );
			$this->forget_link( $applied );
		}
		$this->field_success( 'کد معرف حذف شد.' );
	}
	
	public function validate_coupon( $valid, $coupon, $discounts ) {
		if ( ! $coupon->get_meta( '_kerp_referral_code' ) ) {
			return $valid;
		}
		$code = KERP_Modules_Referrals_Codes::from_coupon( $coupon );
		if ( ! $code ) {
			throw new Exception( 'کد همکاری در فروش معتبر نیست.', 9000 );
		}
		$object = $discounts->get_object();
		$order  = $object instanceof WC_Order ? $object : NULL;
		$user   = $order ? (int) $order->get_customer_id() : get_current_user_id();
		$email  = $order ? $order->get_billing_email() : ( $user ? get_userdata( $user )->user_email : '' );
		if ( ! $order && function_exists( 'WC' ) && WC()->customer ) {
			$email = WC()->customer->get_billing_email() ?: $email;
		}
		$error = KERP_Modules_Referrals_Codes::eligible( $code, $user, $email, $order ? $order->get_id() : 0 );
		if ( $error ) {
			throw new Exception( $error, 9000 );
		}
		$items = $order ? $order->get_items() : $object->get_cart();
		foreach ( $items as $item ) {
			$product = $order ? $item->get_product() : ( $item['data'] ?? NULL );
			if ( KERP_Modules_Referrals_Codes::wallet_product( $product ) ) {
				throw new Exception( 'شارژ کیف پول مشمول معرفی و تخفیف نیست.', 9000 );
			}
		}
		
		return $valid;
	}
	
	public function capture_link(): void {
		if ( ! KERP_Modules_Referrals_Settings::available() || ! isset( $_GET['ref_id'] ) || ! is_string( $_GET['ref_id'] ) ) {
			return;
		}
		$code = KERP_Modules_Referrals_Store::code( wc_format_coupon_code( wp_unslash( $_GET['ref_id'] ) ) );
		// Existing legacy links are resolved lazily; financial history is never imported implicitly.
		if ( ! $code ) {
			$users = get_users( [
				'meta_key'   => 'kref_code',
				'meta_value' => sanitize_text_field( wp_unslash( $_GET['ref_id'] ) ),
				'number'     => 1,
				'fields'     => 'ID',
			] );
			if ( $users ) {
				$candidate = KERP_Modules_Referrals_Codes::public_code( (int) $users[0] );
				if ( ! is_wp_error( $candidate ) ) {
					$code = $candidate;
				}
			}
		}
		if ( ! $code || ! $code['active'] ) {
			return;
		}
		$expires = time() + (int) KERP_Modules_Referrals_Settings::all()['cookie_days'] * DAY_IN_SECONDS;
		$value   = $code['code'] . '|' . $expires;
		$value   .= '|' . hash_hmac( 'sha256', $value, wp_salt( 'auth' ) );
		wc_setcookie( 'kerp_referral', $value, $expires, is_ssl(), TRUE );
		$_COOKIE['kerp_referral'] = $value;
	}
	
	private function link_code(): string {
		if ( ! isset( $_COOKIE['kerp_referral'] ) || ! is_string( $_COOKIE['kerp_referral'] ) ) {
			return '';
		}
		$parts = explode( '|', wp_unslash( $_COOKIE['kerp_referral'] ) );
		if ( count( $parts ) !== 3 || ! ctype_digit( $parts[1] ) || (int) $parts[1] < time() || ! hash_equals( hash_hmac( 'sha256', $parts[0] . '|' . $parts[1], wp_salt( 'auth' ) ), $parts[2] ) ) {
			return '';
		}
		
		return $parts[0];
	}
	
	public function apply_link( $cart ): void {
		static $busy = FALSE;
		if ( $busy || ! KERP_Modules_Referrals_Settings::available() || $cart->is_empty() || $cart->get_applied_coupons() ) {
			return;
		}
		$code = $this->link_code();
		if ( ! $code ) {
			return;
		}
		$busy = TRUE;
		try {
			$coupon = new WC_Coupon( $code );
			$valid  = ( new WC_Discounts( $cart ) )->is_coupon_valid( $coupon );
			if ( ! is_wp_error( $valid ) && $valid ) {
				$cart->apply_coupon( $code );
			}
		}
		finally {
			$busy = FALSE;
		}
	}
	
	public function forget_link( string $code ): void {
		if ( $this->link_code() !== $code ) {
			return;
		}
		wc_setcookie( 'kerp_referral', '', time() - DAY_IN_SECONDS, is_ssl(), TRUE );
		unset( $_COOKIE['kerp_referral'] );
	}
	
	public function shortcode( $atts = [] ): string {
		if ( ! is_user_logged_in() ) {
			return '';
		}
		$code = KERP_Modules_Referrals_Codes::public_code( get_current_user_id() );
		if ( is_wp_error( $code ) ) {
			return '';
		}
		$atts = shortcode_atts( [ 'url' => '/' ], (array) $atts );
		
		return esc_url( add_query_arg( 'ref_id', $code['code'], home_url( '/' . ltrim( (string) $atts['url'], '/' ) ) ) );
	}
	
	public function direct_coupon( $coupon, WC_Order $order ) {
		if ( $coupon || ! KERP_Modules_Referrals_Settings::available() ) {
			return $coupon;
		}
		$linked = $this->link_code();
		$linked = $linked ? KERP_Modules_Referrals_Store::code( $linked ) : NULL;
		if ( $linked && ! KERP_Modules_Referrals_Codes::eligible( $linked, (int) $order->get_customer_id(), $order->get_billing_email(), $order->get_id(), TRUE ) ) {
			return $linked['code'];
		}
		
		return $coupon;
	}
	
	public function pay( $order ): void {
		// WooCommerce fires before_pay_action outside its gateway exception handler.
		try {
			$this->attach( $order );
		}
		catch ( Exception $e ) {
			wp_die( esc_html( $e->getMessage() ), 'همکاری در فروش', [ 'response' => 400, 'back_link' => TRUE ] );
		}
	}
	
	public function attach( $order ): void {
		if ( ! $order instanceof WC_Order ) {
			$order = wc_get_order( $order );
		}
		if ( ! $order || $order->get_meta( '_kerp_order_type' ) === 'wallet_charge' ) {
			return;
		}
		$code = NULL;
		foreach ( $order->get_coupon_codes() as $text ) {
			$coupon = new WC_Coupon( $text );
			if ( ! $coupon->get_meta( '_kerp_referral_code' ) ) {
				continue;
			}
			if ( $code ) {
				throw new Exception( 'در هر سفارش فقط یک کد معرفی قابل استفاده است.' );
			}
			$code = KERP_Modules_Referrals_Codes::from_coupon( $coupon );
			if ( ! $code ) {
				throw new Exception( 'کد معرفی معتبر نیست.' );
			}
		}
		if ( ! $code ) {
			return;
		}
		if ( ! KERP_Modules_Referrals_Store::lock() ) {
			throw new Exception( 'ثبت معرفی در حال پردازش است؛ دوباره تلاش کنید.' );
		}
		try {
			$existing = KERP_Modules_Referrals_Store::referral( $order->get_id() );
			if ( $existing ) {
				if ( (int) $existing['code_id'] !== (int) $code['id'] || (int) $existing['customer_id'] !== (int) $order->get_customer_id() ) {
					throw new Exception( 'معرف یا مشتری این سفارش قبلاً ثبت شده است.' );
				}
				$this->flag( $order, $existing );
				
				return;
			}
			if ( count( $order->get_coupon_codes() ) > 1 ) {
				throw new Exception( 'کد معرفی با کوپن دیگری قابل جمع نیست.' );
			}
			foreach ( $order->get_items() as $item ) {
				if ( KERP_Modules_Referrals_Codes::wallet_product( $item->get_product() ) ) {
					throw new Exception( 'شارژ کیف پول مشمول معرفی نیست.' );
				}
			}
			$error = KERP_Modules_Referrals_Codes::eligible( $code, (int) $order->get_customer_id(), $order->get_billing_email(), $order->get_id(), TRUE );
			if ( $error ) {
				throw new Exception( $error );
			}
			$rules = KERP_Modules_Referrals_Codes::rules( $code );
			$base  = 0;
			foreach ( $order->get_items() as $item ) {
				$base += max( 0, (float) $item->get_total() );
			}
			$rewards = [];
			foreach (
				[
					'referrer' => (int) $code['company_id'],
					'marketer' => (int) $code['marketer_id'],
					'customer' => (int) $order->get_customer_id(),
				] as $role => $uid
			) {
				if ( ! $uid || empty( $rules[ $role ] ) ) {
					continue;
				}
				$amount = KERP_Modules_Referrals_Settings::amount( $rules[ $role ], $base );
				if ( $role === 'referrer' && ! empty( $rules['product_commissions'] ) ) {
					$amount = $this->configured_product_commission( $order, $rules[ $role ], $rules['product_commissions'] );
				} elseif ( $role === 'referrer' && ! empty( $rules['product_overrides'] ) ) {
					$amount = $this->product_commission( $order, $rules[ $role ] );
				}
				$rewards[ $role ] = [ 'user_id' => $uid, 'amount' => $amount ];
			}
			$row       = [
				'order_id'        => $order->get_id(),
				'code_id'         => (int) $code['id'],
				'kind'            => $code['kind'],
				'customer_id'     => (int) $order->get_customer_id(),
				'public_customer' => $code['kind'] === 'public' ? (int) $order->get_customer_id() : NULL,
				'referrer_id'     => (int) $code['company_id'],
				'marketer_id'     => (int) $code['marketer_id'],
				'code'            => $code['code'],
				'currency'        => $order->get_currency(),
				'base'            => $base,
				'order_total'     => (float) $order->get_total(),
				'discount'        => (float) $order->get_discount_total(),
				'snapshot'        => wp_json_encode( [ 'rules' => $rules, 'rewards' => $rewards ] ),
				'created_at'      => current_time( 'mysql' ),
			];
			$row['id'] = KERP_Modules_Referrals_Store::insert( 'orders', $row );
			$this->flag( $order, $row );
		}
		catch ( Throwable $e ) {
			// Retain a diagnostic; order-pay re-runs reservation before invoking the gateway.
			$order->update_meta_data( '_kerp_referral_checkout_error', $e->getMessage() );
			$order->save_meta_data();
			throw $e;
		}
		finally {
			KERP_Modules_Referrals_Store::unlock();
		}
	}
	
	private function flag( WC_Order $order, array $row ): void {
		$order->update_meta_data( '_kerp_referral_id', (int) $row['id'] );
		$order->update_meta_data( '_kerp_referral_kind', $row['kind'] );
		$order->update_meta_data( '_kerp_referral_code', $row['code'] );
		$order->update_meta_data( '_kerp_referrer_id', (int) $row['referrer_id'] );
		$order->update_meta_data( '_kerp_referral_marketer_id', (int) $row['marketer_id'] );
		$order->delete_meta_data( '_kerp_referral_checkout_error' );
		$order->save_meta_data();
	}
	
	private function configured_product_commission( WC_Order $order, array $fallback, array $rows ): float {
		$rules = array_column( $rows, NULL, 'product_id' );
		$base  = 0;
		$total = 0;
		foreach ( $order->get_items() as $item ) {
			$base += max( 0, (float) $item->get_total() );
		}
		foreach ( $order->get_items() as $item ) {
			$line = max( 0, (float) $item->get_total() );
			$rule = $rules[ $item->get_variation_id() ] ?? $rules[ $item->get_product_id() ] ?? NULL;
			if ( $rule === NULL ) {
				$rule = $fallback;
				// A fixed general reward remains once per order, allocated by line value.
				if ( $rule['type'] === 'fixed' ) {
					$rule['value'] = $base > 0 ? $rule['value'] * $line / $base : 0;
				}
			}
			$total += min( $line, max( 0, (float) $rule['value'] ) * ( $rule['type'] === 'percent' ? $line / 100 : 1 ) );
		}
		
		return round( $total, wc_get_price_decimals() );
	}
	
	private function product_commission( WC_Order $order, array $fallback ): float {
		$total = 0;
		foreach ( $order->get_items() as $item ) {
			$fixed   = NULL;
			$percent = NULL;
			foreach ( array_filter( [ $item->get_variation_id(), $item->get_product_id() ] ) as $id ) {
				$product = wc_get_product( $id );
				if ( ! $product ) {
					continue;
				}
				if ( $fixed === NULL && $product->get_meta( '_product_comm_amount' ) !== '' ) {
					$fixed = KERP_Modules_Referrals_Settings::number( $product->get_meta( '_product_comm_amount' ) );
				}
				if ( $percent === NULL && $product->get_meta( '_product_comm' ) !== '' ) {
					$percent = KERP_Modules_Referrals_Settings::number( $product->get_meta( '_product_comm' ) );
				}
			}
			// Preserve legacy fixed-per-line and 0..1 fraction semantics, including explicit zero.
			if ( $fixed !== NULL ) {
				$rule = [ 'type' => 'fixed', 'value' => $fixed ];
			} elseif ( $percent !== NULL ) {
				$rule = [ 'type' => 'percent', 'value' => $percent <= 1 ? $percent * 100 : $percent ];
			} else {
				$rule = $fallback;
				if ( $rule['type'] === 'fixed' ) {
					$rule['value'] = $fallback['value'] * ( (float) $item->get_total() / max( 1, (float) $order->get_subtotal() - (float) $order->get_discount_total() ) );
				}
			}
			$total += KERP_Modules_Referrals_Settings::amount( $rule, (float) $item->get_total() );
		}
		
		return round( $total, wc_get_price_decimals() );
	}
	
}
