<?php
defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Referrals_View {
    public static function statuses(): array { return ['pending'=>'در انتظار تأیید سفارش','paid'=>'واریزشده','partial'=>'برگشت جزئی','reversed'=>'برگشت / لغو','review'=>'نیازمند پیگیری']; }
    public static function user( int $id ): string { $user=get_userdata($id);return $user ? get_user_name_by_id($id).' (#'.$id.')' : ($id ? 'حساب حذف‌شده #'.$id : 'مهمان'); }
    public static function money( float $amount, string $currency='' ): string { return wp_kses_post(KERP_Helpers_Template::price($amount,$currency ? ['currency'=>$currency] : [])); }
    public static function rule_fields( string $prefix, string $label, array $values ): void {
        ?><div class="kr-field"><label for="kr-<?php echo esc_attr($prefix); ?>-value"><?php echo esc_html($label); ?></label><div class="kr-rate"><select aria-label="<?php echo esc_attr('نوع '.$label); ?>" name="<?php echo esc_attr($prefix); ?>_type"><option value="percent" <?php selected($values[$prefix.'_type'],'percent'); ?>>درصد</option><option value="fixed" <?php selected($values[$prefix.'_type'],'fixed'); ?>>مبلغ ثابت</option></select><input id="kr-<?php echo esc_attr($prefix); ?>-value" name="<?php echo esc_attr($prefix); ?>_value" type="number" min="0" step="0.01" required value="<?php echo esc_attr($values[$prefix.'_value']); ?>"></div></div><?php
    }
    public static function picker( string $name, string $label ): void {
        ?><div class="kr-field kr-picker"><label for="kr-<?php echo esc_attr($name); ?>"><?php echo esc_html($label); ?></label><input id="kr-<?php echo esc_attr($name); ?>" type="search" class="kr-user-search" placeholder="جستجوی نام، نام کاربری یا ایمیل" autocomplete="off"><input type="hidden" name="<?php echo esc_attr($name); ?>" value=""><div class="kr-user-results" role="list"></div><small class="kr-user-selected">یک حساب کاربری انتخاب کنید.</small></div><?php
    }
    public static function public_card( int $user ): void {
        $s=KERP_Modules_Referrals_Settings::all();$code=KERP_Modules_Referrals_Codes::public_code($user);
        if(is_wp_error($code)){echo '<p class="kr-notice">'.esc_html($code->get_error_message()).'</p>';return;}
        $used=KERP_Modules_Referrals_Store::used((int)$code['id']);
        $link=add_query_arg('ref_id',$code['code'],home_url('/'));
        KERP_Helpers_Template::render_template('modules/referrals/panel/invitation.php',compact('s','code','used','link'));
    }
    public static function panel_filters( array $input ): array {
        $filters=[];
        if(is_string($input['state'] ?? null) && isset(self::statuses()[$input['state']])){$filters['state']=$input['state'];}
        if(is_string($input['kind'] ?? null) && in_array($input['kind'],['public','private'],true)){$filters['kind']=$input['kind'];}
        $filters['ref_page']=is_scalar($input['ref_page'] ?? null) ? max(1,min(100000,(int)$input['ref_page'])) : 1;
        return $filters;
    }
    public static function nonce(): void { ?><input type="hidden" name="nonce" value="<?php echo esc_attr(wp_create_nonce('kerp_referrals')); ?>"><?php }
    public static function ledger( int $referral_id, string $currency ): void {
        $entries=KERP_Modules_Referrals_Store::ledger($referral_id);if(!$entries){return;}
        ?><details class="kr-ledger"><summary>جزئیات تراکنش‌ها</summary><?php foreach($entries as $entry): ?><small><?php echo esc_html(self::user((int)$entry['user_id'])); ?> · <?php echo self::money((float)$entry['amount'],$currency); ?> · <?php echo esc_html(['ready'=>'در انتظار ثبت','started'=>'در انتظار تطبیق رسید','done'=>'ثبت‌شده','void'=>'تلاش بدون اثر مالی'][$entry['state']] ?? $entry['state']); ?><br><?php if($entry['transaction_id']): ?>تراکنش کیف پول #<?php echo esc_html($entry['transaction_id']); ?><br><?php endif; ?><code><?php echo esc_html('KERP-REF:'.get_current_blog_id().':'.$entry['id']); ?></code></small><?php endforeach; ?></details><?php
    }
    public static function notice(): void {
        if(class_exists('Kasebi_Referrals',false)){echo '<div class="kr-notice">افزونه قدیمی کاسبی رفرال فعال است؛ برای شروع سامانه جدید ابتدا آن را غیرفعال کنید.</div>';}
        elseif(!KERP_Modules_Referrals_Settings::available()){echo '<div class="kr-notice">پذیرش کدهای جدید فعلاً غیرفعال است. تسویه و پیگیری معرفی‌های ثبت‌شده ادامه دارد.</div>';}
    }
    public static function listing( array $filters, int $viewer, bool $all, string $base, bool $admin = false ): void {
        if(!$all && !$admin){
            $filters=self::panel_filters($filters);
            $result=KERP_Modules_Referrals_Store::listing($filters,$viewer,false);
            KERP_Helpers_Template::render_template('modules/referrals/panel/history.php',compact('filters','viewer','base','result'));
            return;
        }
        $result=KERP_Modules_Referrals_Store::listing($filters,$viewer,$all,$admin);
        ?><section class="kr-card"><div class="kr-section-head"><div><h3>سابقه معرفی‌ها</h3><p><?php echo esc_html(number_format_i18n($result['total'])); ?> سفارش ثبت شده</p></div></div>
        <form class="kr-filters" method="get" action="<?php echo esc_url($base); ?>"><?php if(str_contains($base,'/customers/')): ?><input type="hidden" name="tab" value="referrals"><?php endif; ?><select name="state" aria-label="وضعیت کمیسیون"><option value="">همه وضعیت‌ها</option><?php foreach(self::statuses() as $key=>$label): ?><option value="<?php echo esc_attr($key); ?>" <?php selected($filters['state'] ?? '',$key); ?>><?php echo esc_html($label); ?></option><?php endforeach; ?></select><select name="kind" aria-label="نوع معرفی"><option value="">همه کدها</option><option value="public" <?php selected($filters['kind'] ?? '','public'); ?>>عمومی</option><option value="private" <?php selected($filters['kind'] ?? '','private'); ?>>خصوصی</option></select><input name="order_id" type="number" min="1" placeholder="شماره سفارش" aria-label="شماره سفارش" value="<?php echo esc_attr($filters['order_id'] ?? ''); ?>"><button class="kr-button" type="submit">فیلتر</button></form>
        <div class="kr-table-wrap"><table class="kr-table"><thead><tr><th>سفارش / تاریخ</th><th>معرفی</th><?php if($admin): ?><th>مشتری / دریافت‌کنندگان</th><?php endif; ?><th><?php echo $all || $admin ? 'کمیسیون‌ها' : 'سهم شما'; ?></th><th>واریز خالص</th><th>وضعیت</th></tr></thead><tbody>
        <?php foreach($result['rows'] as $row): $snapshot=(array)json_decode($row['snapshot'],true); ?><tr><td><strong>#<?php echo esc_html($row['order_id']); ?></strong><small><?php echo esc_html(date_i18n('Y/m/d H:i',strtotime($row['created_at']))); ?></small></td><td><code><?php echo esc_html($row['code']); ?></code><small><?php echo $row['kind']==='public' ? 'عمومی' : 'خصوصی'; ?></small></td>
        <?php if($admin): ?><td><?php echo esc_html(self::user((int)$row['customer_id'])); ?><small>معرف: <?php echo esc_html(self::user((int)$row['referrer_id'])); ?></small><?php if($row['marketer_id']): ?><small>بازاریاب: <?php echo esc_html(self::user((int)$row['marketer_id'])); ?></small><?php endif; ?></td><?php endif; ?>
        <td><?php $own=0;foreach((array)($snapshot['rewards'] ?? []) as $role=>$reward){if($all || $admin){echo '<small>'.esc_html(['referrer'=>'معرف','marketer'=>'بازاریاب','customer'=>'مشتری'][$role] ?? $role).': '.self::money((float)$reward['amount'],$row['currency']).'</small>';}elseif((int)$reward['user_id']===$viewer){$own+=(float)$reward['amount'];}}if(!$all && !$admin){echo self::money($own,$row['currency']);} ?><small>تخفیف سفارش: <?php echo self::money((float)$row['discount'],$row['currency']); ?></small></td>
        <td><?php echo self::money(KERP_Modules_Referrals_Settlement::net((int)$row['id'],($all || $admin) ? 0 : $viewer),$row['currency']); ?></td><td><span class="kr-badge kr-state-<?php echo esc_attr($row['state']); ?>"><?php echo esc_html(self::statuses()[$row['state']] ?? $row['state']); ?></span><?php if($row['error']): ?><small class="kr-error"><?php echo esc_html($admin ? $row['error'] : 'تسویه در حال بررسی توسط پشتیبانی است.'); ?></small><?php endif; ?><?php if($admin && kerp_can('referrals.reconcile','action')): ?><form class="kr-form kr-inline" data-action="reconcile"><?php self::nonce(); ?><input type="hidden" name="order_id" value="<?php echo esc_attr($row['order_id']); ?>"><button type="submit" class="kr-button kr-small">تطبیق تسویه</button><span class="kr-feedback" role="status"></span></form><?php endif; ?></td></tr><?php endforeach; ?>
        <?php if(!$result['rows']): ?><tr><td colspan="6" class="kr-empty">هنوز معرفی‌ای با این شرایط ثبت نشده است.</td></tr><?php endif; ?></tbody></table></div>
        <?php if($admin): ?><details class="kr-ledger"><summary>دفتر تراکنش‌های این صفحه</summary><?php foreach($result['rows'] as $row): ?><div class="kr-card"><strong>سفارش #<?php echo esc_html($row['order_id']); ?></strong><?php self::ledger((int)$row['id'],$row['currency']); ?></div><?php endforeach; ?></details><?php endif; ?>
        <?php if($result['pages']>1): ?><nav class="kr-pagination" aria-label="صفحه‌بندی معرفی‌ها"><?php echo wp_kses_post(paginate_links(['base'=>add_query_arg(array_merge(array_intersect_key($filters,array_flip(['state','kind','order_id'])),['ref_page'=>'%#%']),$base),'format'=>'','current'=>$result['page'],'total'=>$result['pages'],'prev_text'=>'قبلی','next_text'=>'بعدی'])); ?></nav><?php endif; ?></section><?php
    }
}
