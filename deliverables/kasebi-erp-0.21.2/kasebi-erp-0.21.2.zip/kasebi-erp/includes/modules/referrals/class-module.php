<?php
defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Referrals_Module {
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		return self::$instance ??= new self();
	}
	
	private function __construct() {
		add_filter( 'kerp_panel_navigation_pages', [ $this, 'register_panel_navigation_settings' ] );
		KERP_Modules_Referrals_Store::install();
		KERP_Modules_Referrals_Checkout::instance();
		KERP_Modules_Referrals_Settlement::instance();
		KERP_Modules_Referrals_Api::instance();
		add_filter( 'kerp_app_pages', [ $this, 'pages' ], 60 );
		add_filter( 'kerp_employee_permission_groups', [ $this, 'permissions' ], 60 );
		add_filter( 'kerp_customer_profile_tabs', [ $this, 'customer_tab' ], 60, 3 );
		add_filter( 'nooshika_panel_pages_list_final', [ $this, 'panel_pages' ], 25 );
		add_filter( 'nooshika_panel_get_template_path', [ $this, 'panel_template' ], 25, 2 );
		add_action( 'wp_enqueue_scripts', [ $this, 'assets' ], PHP_INT_MAX );
		add_action( 'user_register', [ $this, 'new_user' ] );
		add_action( 'woocommerce_admin_order_data_after_order_details', [ $this, 'order_flag' ] );
		add_action( 'kerp_orders_form_referral', [ $this, 'erp_order_flag' ] );
		add_action( 'woocommerce_product_options_pricing', [ $this, 'product_fields' ] );
		add_action( 'woocommerce_admin_process_product_object', [ $this, 'save_product' ] );
		add_action( 'woocommerce_variation_options_pricing', [ $this, 'variation_fields' ], 20, 3 );
		add_action( 'woocommerce_save_product_variation', [ $this, 'save_variation' ], 20, 2 );
	}
	
	public function new_user( int $id ): void {
		if ( KERP_Modules_Referrals_Settings::available() ) {
			KERP_Modules_Referrals_Codes::public_code( $id );
		}
	}
	
	public function pages( array $pages ): array {
		$settings_group = [
			'key'        => 'settings',
			'title'      => 'تنظیمات',
			'order'      => 100,
			'sep_before' => TRUE,
		];
		$settings_menu = [
			'key'   => 'referrals-settings',
			'title' => 'همکاری در فروش',
			'icon'  => 'ni ni-users',
			'order' => 60,
		];
		$pages['referrals']          = [
			'title'      => 'همکاری در فروش',
			'route'      => 'referrals',
			'type'       => 'page',
			'template'   => 'modules/referrals/pages/index.php',
			'permission' => 'referrals.view',
			'navigation' => [
				'group' => [
					'key'   => 'sales',
					'title' => 'فروش و مالی',
					'icon'  => 'ni ni-cart',
					'order' => 25,
				],
				'icon'  => 'ni ni-users',
				'order' => 60,
			],
		];
		$pages['referrals-settings-private'] = [
			'title'      => 'کد خصوصی همکاری در فروش',
			'route'      => 'settings/referrals',
			'type'       => 'settings',
			'template'   => 'modules/referrals/settings/private.php',
			'permission' => 'referrals.manage_settings',
			'navigation' => [
				'group' => $settings_group,
				'menu'  => $settings_menu,
				'title' => 'کد خصوصی',
				'order' => 10,
			],
		];
		$pages['referrals-settings-general'] = [
			'title'      => 'تنظیمات عمومی همکاری در فروش',
			'route'      => 'settings/referrals/general',
			'type'       => 'settings',
			'template'   => 'modules/referrals/settings/general.php',
			'permission' => 'referrals.manage_settings',
			'navigation' => [
				'group' => $settings_group,
				'menu'  => $settings_menu,
				'title' => 'تنظیمات عمومی',
				'order' => 20,
			],
		];
		$pages['referrals-settings-commissions'] = [
			'title'      => 'کمیسیون اختصاصی همکاری در فروش',
			'route'      => 'settings/referrals/commissions',
			'type'       => 'settings',
			'template'   => 'modules/referrals/settings/commissions.php',
			'permission' => 'referrals.manage_settings',
			'navigation' => [
				'group' => $settings_group,
				'menu'  => $settings_menu,
				'title' => 'کمیسیون اختصاصی',
				'order' => 30,
			],
		];
		
		return $pages;
	}
	
	public function permissions( array $groups ): array {
		if ( ! isset( $groups['sales'] ) ) {
			$groups['sales'] = [
				'key'    => 'sales',
				'label'  => 'فروش و مالی',
				'icon'   => 'ni ni-cart',
				'order'  => 25,
				'blocks' => [],
			];
		}
		$permissions = [];
		foreach (
			[
				'view'            => [ 'مشاهده معرفی‌های مرتبط', 'view' ],
				'view_all'        => [ 'مشاهده همه معرفی‌ها', 'action' ],
				'create_codes'    => [ 'ساخت و مدیریت کدهای خصوصی خود', 'action' ],
				'manage_codes'    => [ 'مدیریت همه کدهای خصوصی', 'action' ],
				'manage_settings' => [ 'تنظیمات همکاری در فروش', 'action' ],
				'reconcile'       => [ 'تطبیق و تلاش مجدد تسویه', 'action' ],
			] as $key => $info
		) {
			$permissions[ $key ] = [
				'key'   => 'referrals.' . $key,
				'label' => $info[0],
				'type'  => $info[1],
				'order' => count( $permissions ) * 10,
			];
		}
		$groups['sales']['blocks']['referrals'] = [
			'key'         => 'referrals',
			'label'       => 'همکاری در فروش',
			'icon'        => 'ni ni-users',
			'order'       => 60,
			'permissions' => $permissions,
		];
		
		return $groups;
	}
	
	public function customer_tab( array $tabs, int $customer_id, WP_User $customer ): array {
		$tabs['referrals'] = [
			'key'        => 'referrals',
			'title'      => 'معرفی‌ها',
			'icon'       => 'ni ni-users',
			'order'      => 60,
			'group'      => 'finance-loyalty',
			'permission' => 'referrals.view_all',
			'action'     => 'action',
			'template'   => 'modules/referrals/tabs/customer.php',
		];
		
		return $tabs;
	}
	
	public function panel_pages( array $pages ): array {
		$pages['referrals'] = [ 'label' => 'همکاری در فروش', 'icon' => 'uik-r fa-network' ];
		
		return $pages;
	}
	
	public function panel_template( string $file, string $path ): string {
		return $path === 'pages/referrals' ? KERP_TEMPLATES_PATH . 'modules/referrals/panel/referrals.php' : $file;
	}
	
	public function assets(): void {
		if ( kerp_is_erp_request() || ! is_page( 'panel' ) ) {
			return;
		}
		KERP_Helpers_Panel_Ajax::ensure_dependencies();
		wp_enqueue_style( 'kerp-referrals', KERP_ASSETS_URL . 'public/css/referrals.css', [], kerp_asset_version( 'public/css/referrals.css' ) );
		wp_enqueue_script( 'kerp-referrals', KERP_ASSETS_URL . 'public/js/referrals.js', [ 'jquery' ], kerp_asset_version( 'public/js/referrals.js' ), TRUE );
		wp_localize_script( 'kerp-referrals', 'KERPReferrals', [ 'ajaxUrl' => home_url( '/n-ajax' ), 'historyUrl' => home_url( '/n-ajax' ) ] );
	}
	
	public function order_flag( $order ): void {
		if ( $order->get_meta( '_kerp_referral_id' ) ) {
			echo '<p><strong>همکاری در فروش:</strong> ' . esc_html( $order->get_meta( '_kerp_referral_code' ) ) . ' — ' . esc_html( $order->get_meta( '_kerp_referral_kind' ) === 'public' ? 'معرفی عمومی' : 'کد خصوصی' ) . '</p>';
		}
	}
	
	public function erp_order_flag( $order ): void {
		if ( ! $order instanceof WC_Order || ! $order->get_meta( '_kerp_referral_id' ) ) {
			return;
		}
		echo '<div class="mt-3 alert alert-light"><strong>معرفی ثبت‌شده: </strong>' . esc_html( $order->get_meta( '_kerp_referral_code' ) ) . '<br><small>معرف: ' . esc_html( KERP_Modules_Referrals_View::user( (int) $order->get_meta( '_kerp_referrer_id' ) ) ) . '</small></div>';
	}
	
	public function product_fields(): void {
		foreach (
			[
				'_product_comm'        => 'درصد کمیسیون معرفی عمومی',
				'_product_comm_amount' => 'کمیسیون ثابت هر ردیف سفارش',
			] as $id => $label
		) {
			woocommerce_wp_text_input( [
				'id'                => $id,
				'label'             => $label,
				'type'              => 'number',
				'custom_attributes' => [ 'min' => '0', 'step' => '0.01' ],
				'desc_tip'          => TRUE,
				'description'       => 'خالی = نرخ عمومی. صفر = بدون کمیسیون. مبلغ ثابت بر درصد اولویت دارد؛ تنظیم «نرخ محصول» باید فعال باشد. برای سازگاری قدیمی، درصد ۱ یعنی ۱۰۰٪.',
			] );
		}
	}
	
	public function save_product( $product ): void {
		foreach ( [ '_product_comm', '_product_comm_amount' ] as $key ) {
			if ( ! isset( $_POST[ $key ] ) || ! is_string( $_POST[ $key ] ) ) {
				continue;
			}
			$raw   = wp_unslash( $_POST[ $key ] );
			$value = KERP_Modules_Referrals_Settings::number( $raw );
			if ( $raw === '' ) {
				$product->delete_meta_data( $key );
			} elseif ( $value !== NULL ) {
				$product->update_meta_data( $key, min( $key === '_product_comm' ? 100 : 999999999, $value ) );
			}
		}
	}
	
	public function variation_fields( $loop, $data, $variation ): void {
		foreach (
			[
				'_product_comm'        => 'درصد کمیسیون معرفی',
				'_product_comm_amount' => 'کمیسیون ثابت هر ردیف',
			] as $key => $label
		) {
			woocommerce_wp_text_input( [
				'id'                => $key . '_' . $loop,
				'name'              => $key . '[' . $loop . ']',
				'value'             => get_post_meta( $variation->ID, $key, TRUE ),
				'label'             => $label,
				'type'              => 'number',
				'custom_attributes' => [ 'min' => '0', 'step' => '0.01' ],
				'wrapper_class'     => 'form-row form-row-full',
			] );
		}
	}
	
	public function save_variation( $id, $loop ): void {
		$product = wc_get_product( $id );
		if ( ! $product ) {
			return;
		}
		foreach ( [ '_product_comm', '_product_comm_amount' ] as $key ) {
			if ( ! isset( $_POST[ $key ][ $loop ] ) || ! is_string( $_POST[ $key ][ $loop ] ) ) {
				continue;
			}
			$raw   = wp_unslash( $_POST[ $key ][ $loop ] );
			$value = KERP_Modules_Referrals_Settings::number( $raw );
			if ( $raw === '' ) {
				$product->delete_meta_data( $key );
			} elseif ( $value !== NULL ) {
				$product->update_meta_data( $key, min( $key === '_product_comm' ? 100 : 999999999, $value ) );
			}
		}
		$product->save();
	}
	

	public function register_panel_navigation_settings( array $rows ): array {
		return KERP_Settings_Panel_Navigation::register_entries( $rows, 'referrals', 'همکاری در فروش', $this->panel_pages( [] ) );
	}
}
