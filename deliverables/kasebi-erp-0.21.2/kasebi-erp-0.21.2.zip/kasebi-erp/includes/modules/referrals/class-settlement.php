<?php
defined( 'ABSPATH' ) || exit;

/** An intent is durable before calling TeraWallet; recovery looks up the receipt in its ledger. */
final class KERP_Modules_Referrals_Settlement {
    private static ?self $instance=null;
    public static function instance(): self { return self::$instance ??= new self(); }
    private function __construct() {
        foreach(['woocommerce_payment_complete','woocommerce_order_status_changed','woocommerce_order_refunded','kerp_referrals_reconcile'] as $hook){add_action($hook,[$this,'reconcile'],40);}
    }
    public static function target_factor( array $row, WC_Order $order ): ?float {
        if($order->has_status(['cancelled','failed','refunded'])){return 0.0;}
        $snapshot=(array)json_decode($row['snapshot'],true);
        $status=$snapshot['rules']['payout_status'] ?? 'completed';
        if(!$order->is_paid() || !$order->get_date_paid() || !$order->has_status($status==='processing' ? ['processing','completed'] : ['completed'])){return null;}
        $total=(float)$row['order_total'];
        return $total > 0 ? max(0.0,min(1.0,1-(float)$order->get_total_refunded()/$total)) : 0.0;
    }
    public function reconcile( int $order_id, bool $manual = false ): void {
        $row=KERP_Modules_Referrals_Store::referral($order_id); if(!$row){return;}
        if(!KERP_Modules_Referrals_Store::lock()){$this->schedule($order_id);return;}
        try{
            $row=KERP_Modules_Referrals_Store::referral($order_id);
            $order=wc_get_order($order_id);
            if(!$order instanceof WC_Order){$this->problem($row,'سفارش حذف شده است؛ تطبیق کمیسیون نیاز به بررسی دارد.');return;}
            $snapshot=(array)json_decode($row['snapshot'],true);
            if(!isset($snapshot['rules'],$snapshot['rewards']) || !is_array($snapshot['rewards'])){$this->problem($row,'اطلاعات مبنای کمیسیون معتبر نیست؛ نیازمند بررسی است.');return;}
            if($order->get_currency()!==$row['currency'] || $row['currency']!==get_woocommerce_currency() || (int)$order->get_customer_id()!==(int)$row['customer_id']){$this->problem($row,'ارز یا مشتری سفارش تغییر کرده است؛ تسویه نیاز به بررسی دارد.');return;}
            global $wpdb; $t=KERP_Modules_Referrals_Store::table('ledger');
            // Recover interrupted writes even when a refund arrived before their callback completed.
            $pending=$wpdb->get_results($wpdb->prepare("SELECT * FROM {$t} WHERE referral_id=%d AND state IN ('ready','started') ORDER BY id",$row['id']),ARRAY_A);
            if($wpdb->last_error){throw new RuntimeException('خواندن گردش کمیسیون انجام نشد.');}
            $factor=self::target_factor($row,$order);
            foreach($pending as $intent){
                if($intent['state']==='ready'){
                    // A known failure has no wallet effect. Drop the obsolete intent and recompute
                    // against the current refund/status instead of paying an already-cancelled order.
                    if($factor===null){continue;}
                    $id=$this->find_transaction($row,$intent);
                    if(!$id){KERP_Modules_Referrals_Store::update('ledger',['state'=>'void'],(int)$intent['id']);continue;}
                }
                if($intent['state']==='void'){continue;}
                $error=$this->execute($row,$intent,$manual);if($error){$this->problem($row,$error);return;}
            }
            if($factor===null){return;}
            // Snapshot amounts are immutable. Editing paid orders is surfaced for manual review.
            if($factor>0 && abs((float)$order->get_total()-(float)$row['order_total'])>0.000001){$this->problem($row,'مبلغ سفارش پس از ثبت معرفی تغییر کرده است؛ کمیسیون نیاز به بررسی دارد.');return;}
            foreach((array)($snapshot['rewards'] ?? []) as $role=>$reward){
                $net=$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount),0) FROM {$t} WHERE referral_id=%d AND role=%s AND state='done'",$row['id'],$role));
                if($wpdb->last_error){throw new RuntimeException('خواندن مانده کمیسیون انجام نشد.');}
                $target=round((float)$reward['amount']*$factor,wc_get_price_decimals());
                $delta=round($target-(float)$net,wc_get_price_decimals());
                if(abs($delta)<pow(10,-wc_get_price_decimals())/2){continue;}
                $intent=['referral_id'=>(int)$row['id'],'user_id'=>(int)$reward['user_id'],'role'=>$role,'amount'=>$delta,'state'=>'ready','created_at'=>current_time('mysql')];
                $intent['id']=KERP_Modules_Referrals_Store::insert('ledger',$intent);
                $error=$this->execute($row,$intent,$manual);if($error){$this->problem($row,$error);return;}
            }
            $state=$factor<=0 ? 'reversed' : ($factor<1 ? 'partial' : 'paid');
            KERP_Modules_Referrals_Store::update('orders',['state'=>$state,'error'=>''],(int)$row['id']);
            wp_clear_scheduled_hook('kerp_referrals_reconcile',[$order_id]);
        }catch(Throwable $e){
            if($row){$this->problem($row,'تسویه کامل نشد؛ گزارش تراکنش‌ها را بررسی و تطبیق را دوباره اجرا کنید.');}
        }finally{KERP_Modules_Referrals_Store::unlock();}
    }
    private function schedule( int $order_id ): void {
        if(!wp_next_scheduled('kerp_referrals_reconcile',[$order_id])){wp_schedule_single_event(time()+300,'kerp_referrals_reconcile',[$order_id]);}
    }
    private function problem( array $row, string $message ): void {
        KERP_Modules_Referrals_Store::update('orders',['state'=>'review','error'=>$message],(int)$row['id']);
        $order=wc_get_order((int)$row['order_id']);
        if($order && ($row['error'] ?? '')!==$message){$order->add_order_note('همکاری در فروش: '.$message);}
    }
    private function receipt( array $row, array $intent ): string {
        return 'کمیسیون همکاری در فروش — سفارش #'.$row['order_id'].' [KERP-REF:'.get_current_blog_id().':'.$intent['id'].']';
    }
    private function find_transaction( array $row, array $intent ): int {
        global $wpdb;
        $found=$wpdb->get_row($wpdb->prepare("SELECT transaction_id, amount, currency, deleted FROM {$wpdb->base_prefix}woo_wallet_transactions WHERE blog_id=%d AND user_id=%d AND type=%s AND details=%s LIMIT 1",get_current_blog_id(),$intent['user_id'],(float)$intent['amount']>0 ? 'credit':'debit',$this->receipt($row,$intent)),ARRAY_A);
        if($wpdb->last_error){throw new RuntimeException('خواندن دفتر کیف پول انجام نشد.');}
        if(!$found){return 0;}
        if((int)$found['deleted'] || abs((float)$found['amount']-abs((float)$intent['amount']))>0.000001 || $found['currency']!==$row['currency']){throw new RuntimeException('تراکنش کیف پول با کمیسیون تطبیق ندارد.');}
        return (int)$found['transaction_id'];
    }
    private function complete( array $row, array $intent, int $transaction_id ): void {
        // Persist completion before notifying: reconciliation must never repeat a credit or SMS.
        KERP_Modules_Referrals_Store::update('ledger',['state'=>'done','transaction_id'=>$transaction_id,'error'=>''],(int)$intent['id']);
        if($intent['state']==='done' || (float)$intent['amount']<=0){return;}
        try{
            do_action('kerp_wallet_transaction_created',$transaction_id,(int)$intent['user_id'],'credit',(float)$intent['amount'],$this->receipt($row,$intent));
        }catch(Throwable $e){
            // Notification failure must not turn a confirmed wallet payment into a failed settlement.
            wc_get_logger()->error('Referral wallet notification failed for transaction #'.$transaction_id.': '.$e->getMessage(),['source'=>'kerp-referrals']);
        }
    }
    private function execute( array $row, array $intent, bool $manual = false ): ?string {
        try{
            $id=$this->find_transaction($row,$intent);
            if($id){$this->complete($row,$intent,$id);return null;}
            if($intent['state']==='started'){return 'نتیجه یک تراکنش قبلی نامشخص است؛ برای جلوگیری از پرداخت تکراری باید با دفتر کیف پول تطبیق داده شود.';}
            if(!get_userdata((int)$intent['user_id']) || !function_exists('woo_wallet')){return 'حساب دریافت‌کننده یا سرویس کیف پول در دسترس نیست.';}
            $type=(float)$intent['amount']>0 ? 'credit':'debit'; $amount=abs((float)$intent['amount']);
            if($type==='debit' && (float)woo_wallet()->wallet->get_wallet_balance((int)$intent['user_id'],'edit')<$amount){return 'موجودی کیف پول برای برگشت کمیسیون کافی نیست؛ پس از تأمین موجودی، تطبیق را اجرا کنید.';}
            global $wpdb; $table=KERP_Modules_Referrals_Store::table('ledger');
            $attempts=(int)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(attempts),0) FROM {$table} WHERE referral_id=%d AND role=%s AND state!='done'",$row['id'],$intent['role']));
            if($wpdb->last_error){return 'خواندن سابقه تلاش تسویه انجام نشد.';}
            if(!$manual && $attempts>=5){return 'تلاش خودکار تسویه متوقف شده است؛ پس از بررسی کیف پول، تطبیق را دستی اجرا کنید.';}
            $this->schedule((int)$row['order_id']);
            KERP_Modules_Referrals_Store::update('ledger',['state'=>'started','attempts'=>(int)($intent['attempts'] ?? 0)+1],(int)$intent['id']);
            $result=woo_wallet()->wallet->{$type}((int)$intent['user_id'],$amount,$this->receipt($row,$intent),['for'=>'kerp_referral','currency'=>$row['currency']]);
            // Even a returned success is verified against the authoritative ledger.
            $id=$this->find_transaction($row,$intent);
            if($id){$this->complete($row,$intent,$id);return null;}
            if(!$result || is_wp_error($result)){KERP_Modules_Referrals_Store::update('ledger',['state'=>'ready'],(int)$intent['id']);return 'ثبت تراکنش کیف پول انجام نشد؛ تطبیق مجدد قابل اجراست.';}
            return 'رسید تراکنش در دفتر کیف پول پیدا نشد؛ نیازمند بررسی است.';
        }catch(Throwable $e){return 'نتیجه ثبت یا تطبیق تراکنش نامشخص است؛ گزارش کیف پول را بررسی کنید.';}
    }
    public static function net( int $referral_id, int $viewer = 0 ): float {
        global $wpdb; $t=KERP_Modules_Referrals_Store::table('ledger');
        $where=$viewer ? $wpdb->prepare(' AND user_id=%d',$viewer) : '';
        return (float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount),0) FROM {$t} WHERE referral_id=%d AND state='done' {$where}",$referral_id));
    }
}
