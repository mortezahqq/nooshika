<?php
defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Referrals_Codes {
    public static function rules( array $code ): array {
        if ( $code['kind'] === 'private' ) { return (array) json_decode($code['rules'], true); }
        $s = KERP_Modules_Referrals_Settings::all();
        return ['discount'=>['type'=>$s['discount_type'],'value'=>$s['customer_benefit']==='discount' ? $s['discount_value'] : 0],
            'referrer'=>['type'=>$s['referrer_type'],'value'=>$s['referrer_value']],
            'customer'=>['type'=>$s['discount_type'],'value'=>$s['customer_benefit']==='cashback' ? $s['discount_value'] : 0],
            'product_overrides'=>$s['product_overrides'], 'product_commissions'=>$s['product_commissions'], 'payout_status'=>$s['payout_status']];
    }
    public static function public_code( int $user_id ): array|WP_Error {
        if ( ! get_userdata($user_id) ) { return new WP_Error('user', 'حساب کاربری پیدا نشد.'); }
        if ( ! KERP_Modules_Referrals_Store::lock() ) { return new WP_Error('busy', 'ساخت کد در حال پردازش است؛ دوباره تلاش کنید.'); }
        try {
            global $wpdb; $t = KERP_Modules_Referrals_Store::table('codes');
            $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$t} WHERE public_owner=%d",$user_id), ARRAY_A);
            if ( ! $row ) {
                $legacy = strtolower((string)get_user_meta($user_id,'kref_code',true));
                $code = preg_match('/^[a-z0-9-]{4,60}$/D',$legacy) && ! wc_get_coupon_id_by_code($legacy) && ! KERP_Modules_Referrals_Store::code($legacy) ? $legacy : 'ref-' . strtolower(wp_generate_password(12,false,false));
                $id = KERP_Modules_Referrals_Store::insert('codes', ['code'=>$code,'kind'=>'public','public_owner'=>$user_id,'company_id'=>$user_id,'rules'=>'{}','created_at'=>current_time('mysql')]);
                $row = KERP_Modules_Referrals_Store::code($id);
            }
            self::ensure_coupon($row);
            return KERP_Modules_Referrals_Store::code((int)$row['id']);
        } catch ( Throwable $e ) { return new WP_Error('code_failed', $e->getMessage()); }
        finally { KERP_Modules_Referrals_Store::unlock(); }
    }
    public static function create_private( array $input, int $actor, bool $manager ): array|WP_Error {
        $manager=$manager && KERP_Helpers_User::is_admin($actor);
        $s = KERP_Modules_Referrals_Settings::all();
        $code = wc_format_coupon_code((string)($input['code'] ?? ''));
        $company = absint($input['company_id'] ?? 0);
        $marketer = $manager ? absint($input['marketer_id'] ?? $actor) : $actor;
        $title = sanitize_text_field((string)($input['title'] ?? ''));
        if ( ! preg_match('/^[a-z0-9-]{4,60}$/D',$code) || $title === '' || ! get_userdata($company) || ! get_userdata($marketer) || $company === $marketer ) { return new WP_Error('invalid', 'عنوان، کد انگلیسی (۴ تا ۶۰ حرف/عدد/خط تیره) و دو حساب متفاوت شرکت و بازاریاب الزامی است.'); }
        $rules = ['payout_status'=>$s['payout_status']];
        foreach ( ['discount'=>'private_discount','referrer'=>'company','marketer'=>'marketer'] as $role=>$prefix ) {
            $rule = KERP_Modules_Referrals_Settings::rule($manager ? ($input[$prefix.'_type'] ?? $s[$prefix.'_type']) : $s[$prefix.'_type'], $manager ? ($input[$prefix.'_value'] ?? $s[$prefix.'_value']) : $s[$prefix.'_value']);
            if ( is_wp_error($rule) ) { return $rule; } $rules[$role] = $rule;
        }
        $limit = KERP_Modules_Referrals_Settings::number($manager ? ($input['usage_limit'] ?? 0):0);
        if ( $limit === null || floor($limit) !== $limit || $limit > 1000000 ) { return new WP_Error('limit','سقف استفاده باید عدد صحیح باشد؛ صفر یعنی بدون سقف.'); }
        $expiry = $manager ? (string)($input['expires'] ?? ''):'';
        if ( $expiry !== '' && ( ! preg_match('/^\d{4}-\d{2}-\d{2}$/D',$expiry) || ! strtotime($expiry) || gmdate('Y-m-d',strtotime($expiry)) !== $expiry ) ) { return new WP_Error('expiry','تاریخ انقضا معتبر نیست.'); }
        $rules['usage_limit'] = (int)$limit; $rules['expires'] = $expiry;
        if ( ! KERP_Modules_Referrals_Store::lock() ) { return new WP_Error('busy','درخواست دیگری در حال پردازش است.'); }
        try {
            $existing = KERP_Modules_Referrals_Store::code($code);
            // Replayed identical form submissions recover the same coupon, never create a second one.
            if ( $existing ) {
                if ( $existing['kind'] !== 'private' || (int)$existing['company_id'] !== $company || (int)$existing['marketer_id'] !== $marketer || wp_json_encode(self::rules($existing)) !== wp_json_encode($rules) || $existing['title'] !== $title ) { return new WP_Error('duplicate','این کد قبلاً ثبت شده است.'); }
            } else {
                if ( wc_get_coupon_id_by_code($code) ) { return new WP_Error('duplicate','این کد تخفیف ووکامرس از قبل وجود دارد.'); }
                $id = KERP_Modules_Referrals_Store::insert('codes',['code'=>$code,'kind'=>'private','company_id'=>$company,'marketer_id'=>$marketer,'title'=>$title,'rules'=>wp_json_encode($rules),'created_at'=>current_time('mysql')]);
                $existing = KERP_Modules_Referrals_Store::code($id);
            }
            self::ensure_coupon($existing);
            return KERP_Modules_Referrals_Store::code((int)$existing['id']);
        } catch ( Throwable $e ) { return new WP_Error('create',$e->getMessage()); }
        finally { KERP_Modules_Referrals_Store::unlock(); }
    }
    private static function ensure_coupon( array $row ): void {
        $id = (int)$row['coupon_id'] ?: (int)wc_get_coupon_id_by_code($row['code']);
        $coupon = new WC_Coupon($id);
        if ( $coupon->get_id() ) {
            if ( (int)$coupon->get_meta('_kerp_referral_code') !== (int)$row['id'] ) { throw new RuntimeException('کد با یک کوپن دیگر تداخل دارد.'); }
            if ( ! $row['coupon_id'] ) { KERP_Modules_Referrals_Store::update('codes',['coupon_id'=>$id],(int)$row['id']); }
            return;
        }
        $rules = self::rules($row);
        $coupon->set_code($row['code']);
        $coupon->set_discount_type($rules['discount']['type'] === 'percent' ? 'percent' : 'fixed_cart');
        $coupon->set_amount($rules['discount']['value']);
        $coupon->set_individual_use(true);
        $coupon->set_description('همکاری در فروش ERP — ' . ($row['title'] ?: 'کد عمومی'));
        $coupon->set_usage_limit($row['kind']==='public' ? 0 : (int)($rules['usage_limit'] ?? 0));
        $coupon->set_usage_limit_per_user($row['kind']==='public' ? 1 : 0);
        if ( ! empty($rules['expires']) ) { $coupon->set_date_expires($rules['expires'].' 23:59:59'); }
        $coupon->update_meta_data('_kerp_referral_code',(int)$row['id']);
        $id = $coupon->save();
        if ( ! $id ) { throw new RuntimeException('ساخت کد تخفیف ووکامرس انجام نشد.'); }
        KERP_Modules_Referrals_Store::update('codes',['coupon_id'=>$id],(int)$row['id']);
    }
    public static function from_coupon( $coupon ): ?array {
        $id = (int)$coupon->get_meta('_kerp_referral_code');
        $row = $id ? KERP_Modules_Referrals_Store::code($id) : null;
        return $row && $row['code'] === $coupon->get_code() && (int)$row['coupon_id'] === (int)$coupon->get_id() ? $row : null;
    }
    public static function coupon_amount( $value, $coupon ) {
        $row = self::from_coupon($coupon);
        return $row ? self::rules($row)['discount']['value'] : $value;
    }
    public static function coupon_type( $value, $coupon ) {
        $row = self::from_coupon($coupon);
        return $row ? (self::rules($row)['discount']['type']==='percent' ? 'percent':'fixed_cart') : $value;
    }
    public static function wallet_product( $product ): bool {
        if(!$product){return false;}
        $recharge_id=(int)apply_filters('woo_wallet_rechargeable_product_id',get_option('_woo_wallet_recharge_product',0));
        return $product->get_meta('_kerp_wallet_charge_product')==='yes' || ($recharge_id>0 && (int)$product->get_id()===$recharge_id);
    }
    public static function first_order( int $user, string $email, int $exclude ): bool {
        $statuses = array_diff(array_keys(wc_get_order_statuses()),['wc-cancelled','wc-failed','wc-checkout-draft']);
        foreach ( array_filter([['customer_id'=>$user], $email !== '' ? ['billing_email'=>$email] : null]) as $customer ) {
            if ( isset($customer['customer_id']) && ! $user ) { continue; }
            $page = 1;
            do {
                $orders = wc_get_orders(array_merge($customer,['status'=>array_values($statuses),'exclude'=>$exclude ? [$exclude] : [],'limit'=>50,'page'=>$page++]));
                foreach ( $orders as $order ) {
                    if ( $order->get_meta('_kerp_order_type') === 'wallet_charge' || $order->get_meta('_wallet_rechargeable_order') === true || $order->get_meta('_wallet_rechargeable_order') === '1' ) { continue; }
                    return false;
                }
            } while ( count($orders) === 50 );
        }
        return true;
    }
    /** Called again under the reservation lock after checkout has created the customer. */
    public static function eligible( array $code, int $user, string $email = '', int $order_id = 0, bool $final = false ): ?string {
        if ( ! KERP_Modules_Referrals_Settings::available() || ! $code['active'] ) { return 'این کد همکاری در فروش در حال حاضر فعال نیست.'; }
        if ( ! get_userdata((int)$code['company_id']) || ($code['marketer_id'] && ! get_userdata((int)$code['marketer_id'])) ) { return 'حساب دریافت‌کننده کمیسیون در دسترس نیست.'; }
        foreach (array_filter([(int)$code['company_id'],(int)$code['marketer_id']]) as $owner) {
            $account = get_userdata($owner);
            if ( $user === $owner || ($email !== '' && strtolower($email)===strtolower($account->user_email)) ) { return 'استفاده از کد معرفی خودتان مجاز نیست.'; }
        }
        if ( $code['kind'] !== 'public' ) { return null; }
        if ( $final && $user <= 0 ) { return 'برای استفاده از کد عمومی، وارد حساب شوید یا هنگام خرید حساب بسازید.'; }
        global $wpdb; $t = KERP_Modules_Referrals_Store::table('orders');
        if ( $user && $wpdb->get_var($wpdb->prepare("SELECT id FROM {$t} WHERE public_customer=%d AND order_id!=%d LIMIT 1",$user,$order_id)) ) { return 'این مشتری قبلاً از معرفی عمومی استفاده کرده است.'; }
        if ( $wpdb->last_error ) { return 'بررسی سوابق معرفی انجام نشد.'; }
        if ( ! self::first_order($user,$email,$order_id) ) { return 'کد عمومی فقط برای اولین خرید قابل استفاده است.'; }
        if ( KERP_Modules_Referrals_Store::used((int)$code['id'],$order_id) >= (int)KERP_Modules_Referrals_Settings::all()['public_limit'] ) { return 'ظرفیت معرفی این کد تکمیل شده است.'; }
        return null;
    }
}
