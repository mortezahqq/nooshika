<?php
defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Referrals_Settings {
    public static function defaults(): array {
        return [ 'enabled' => false, 'public_limit' => 20, 'cookie_days' => 5,
            'customer_benefit' => 'discount', 'discount_type' => 'percent', 'discount_value' => 0,
            'referrer_type' => 'percent', 'referrer_value' => 5,
            'private_discount_type' => 'percent', 'private_discount_value' => 0,
            'company_type' => 'percent', 'company_value' => 5,
            'marketer_type' => 'percent', 'marketer_value' => 0,
            'payout_status' => 'completed', 'product_overrides' => false, 'product_commissions' => [], 'terms' => '' ];
    }
    public static function all(): array {
        return array_merge( self::defaults(), (array) get_option( 'kerp_referrals_settings', [] ) );
    }
    public static function available(): bool {
        return ! class_exists( 'Kasebi_Referrals', false ) && function_exists( 'woo_wallet' ) && ! empty( self::all()['enabled'] );
    }
    public static function sanitize( array $input ): array|WP_Error {
        $out = self::defaults();
        foreach ( $out as $key => $default ) {
            if($key==='product_commissions'){continue;}
            if ( isset( $input[$key] ) && ! is_scalar( $input[$key] ) ) { return new WP_Error( 'invalid', 'ورودی تنظیمات معتبر نیست.' ); }
        }
        foreach ( [ 'enabled', 'product_overrides' ] as $key ) { $out[$key] = ! empty( $input[$key] ); }
        foreach ( [ 'public_limit' => [1,100000], 'cookie_days' => [1,365] ] as $key => $range ) {
            $value = self::number( $input[$key] ?? $out[$key] );
            if ( $value === null || floor( $value ) !== $value || $value < $range[0] || $value > $range[1] ) { return new WP_Error( 'invalid', 'سقف معرفی یا مدت اعتبار لینک معتبر نیست.' ); }
            $out[$key] = (int) $value;
        }
        foreach ( [ 'discount', 'referrer', 'private_discount', 'company', 'marketer' ] as $prefix ) {
            $rule = self::rule( $input[$prefix.'_type'] ?? $out[$prefix.'_type'], $input[$prefix.'_value'] ?? $out[$prefix.'_value'] );
            if ( is_wp_error( $rule ) ) { return $rule; }
            $out[$prefix.'_type'] = $rule['type']; $out[$prefix.'_value'] = $rule['value'];
        }
        $out['customer_benefit'] = (string) ( $input['customer_benefit'] ?? 'discount' );
        $out['payout_status'] = (string) ( $input['payout_status'] ?? 'completed' );
        if ( ! in_array( $out['customer_benefit'], ['discount','cashback'], true ) || ! in_array( $out['payout_status'], ['completed','processing'], true ) ) { return new WP_Error( 'invalid', 'نوع پاداش یا وضعیت تسویه معتبر نیست.' ); }
        $out['terms'] = wp_kses_post( (string) ( $input['terms'] ?? '' ) );
        $rows=self::sanitize_product_commissions($input['product_commissions'] ?? []);
        if(is_wp_error($rows)){return $rows;}
        $out['product_commissions']=$rows;
        if($rows){$out['product_overrides']=false;}
        return $out;
    }
    public static function sanitize_product_commissions( mixed $rows ): array|WP_Error {
        if(!is_array($rows) || count($rows)>500){return new WP_Error('products','ردیف‌های کمیسیون محصول معتبر نیستند؛ حداکثر ۵۰۰ ردیف مجاز است.');}
        $clean=[];$seen=[];
        foreach($rows as $row){
            if(!is_array($row) || array_diff(array_keys($row),['product_id','type','value','percent_value','fixed_value'])){return new WP_Error('products','ساختار ردیف کمیسیون محصول معتبر نیست.');}
            foreach($row as $value){if(!is_scalar($value)){return new WP_Error('products','مقادیر ردیف کمیسیون محصول معتبر نیست.');}}
            if(!array_filter($row,static fn($value)=>trim((string)$value)!=='')){continue;}
            $id=self::number($row['product_id'] ?? '');
            $product=$id!==null && $id>0 && floor($id)===$id ? wc_get_product((int)$id):false;
            if(!$product || $product->get_status()==='trash' || KERP_Modules_Referrals_Codes::wallet_product($product)){return new WP_Error('products','در هر ردیف یک محصول معتبر انتخاب کنید؛ شارژ کیف پول مشمول کمیسیون نیست.');}
            if(isset($seen[(int)$id])){return new WP_Error('products','هر محصول فقط یک‌بار می‌تواند در فهرست کمیسیون باشد.');}
            $type=$row['type'] ?? '';
            $rule=self::rule($type,$row[$type.'_value'] ?? $row['value'] ?? '');
            if(is_wp_error($rule)){return $rule;}
            $clean[]=['product_id'=>(int)$id,'type'=>$rule['type'],'value'=>$rule['value']];$seen[(int)$id]=true;
        }
        return $clean;
    }
    /** Read legacy rates into the editor without changing product metadata. */
    public static function product_rows( array $settings ): array {
        if($settings['product_commissions'] || !$settings['product_overrides']){return $settings['product_commissions'];}
        $ids=get_posts(['post_type'=>['product','product_variation'],'post_status'=>['publish','private','draft','pending','future'],
            'posts_per_page'=>-1,'fields'=>'ids','meta_query'=>['relation'=>'OR',
                ['key'=>'_product_comm','value'=>'','compare'=>'!='],['key'=>'_product_comm_amount','value'=>'','compare'=>'!=']]]);
        $rows=[];
        foreach($ids as $id){
            $product=wc_get_product($id);if(!$product || KERP_Modules_Referrals_Codes::wallet_product($product)){continue;}
            $fixed=self::number($product->get_meta('_product_comm_amount'));
            $percent=self::number($product->get_meta('_product_comm'));
            if($product->is_type('variation') && ($parent=wc_get_product($product->get_parent_id()))){
                $fixed??=self::number($parent->get_meta('_product_comm_amount'));
                $percent??=self::number($parent->get_meta('_product_comm'));
            }
            if($fixed===null && $percent===null){continue;}
            $rows[]=['product_id'=>(int)$id,'type'=>$fixed!==null ? 'fixed':'percent','value'=>$fixed ?? ($percent<=1 ? $percent*100:$percent)];
        }
        return $rows;
    }
    public static function number( mixed $value ): ?float {
        if ( ! is_scalar( $value ) ) { return null; }
        $value = strtr( trim( (string) $value ), array_combine( preg_split('//u', '۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩', -1, PREG_SPLIT_NO_EMPTY), str_split('01234567890123456789') ) );
        $value = str_replace( ['٬','٫'], [',','.'], $value );
        if(!preg_match('/^(?:[0-9]+|[0-9]{1,3}(?:,[0-9]{3})+)(?:\.[0-9]+)?$/D',$value)){return null;}
        $value = str_replace(',','',$value);
        return is_finite( (float) $value ) ? (float) $value : null;
    }
    public static function rule( mixed $type, mixed $value ): array|WP_Error {
        $value = self::number( $value );
        if ( ! in_array( $type, ['percent','fixed'], true ) || $value === null || $value > ( $type === 'percent' ? 100 : 999999999 ) ) { return new WP_Error( 'invalid_rate', 'مبلغ باید مثبت یا صفر و درصد بین صفر تا ۱۰۰ باشد.' ); }
        return [ 'type' => $type, 'value' => $value ];
    }
    public static function amount( array $rule, float $base ): float {
        return round( min( max(0, $base), max(0, (float) $rule['value']) * ( $rule['type'] === 'percent' ? max(0, $base) / 100 : 1 ) ), wc_get_price_decimals() );
    }
}
