<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Gravity_Forms_Entries_Module {
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		return self::$instance ??= new self();
	}
	
	private function __construct() {
		KERP_Modules_Gravity_Forms_Entries_Query::instance();
		KERP_Modules_Gravity_Forms_Entries_Submission::instance();
		
		add_filter( 'kerp_customer_profile_tabs', [ $this, 'register_customer_tab' ], 58, 3 );
		add_filter( 'kerp_employee_permission_groups', [ $this, 'register_permissions' ], 58 );
		add_filter( 'kerp_ajax_forced_plugins', [ $this, 'ajax_dependencies' ] );
		
		$this->ensure_ajax_dependencies();
	}
	
	public function register_customer_tab( array $tabs, int $customer_id, WP_User $customer ): array {
		$tabs['gravity-forms-entries'] = [
			'key'        => 'gravity-forms-entries',
			'title'      => __( 'ورودی‌های فرم', 'kasebi-erp' ),
			'icon'       => 'uik-r fa-form',
			'order'      => 90,
			'group'      => 'customer-information',
			'permission' => 'gravity_forms_entries.view',
			'action'     => 'view',
			'template'   => 'modules/gravity-forms-entries/tabs/customer-entries.php',
		];
		
		return $tabs;
	}
	
	public function register_permissions( array $groups ): array {
		$customer_plural_label = KERP_Modules_Customers_Settings::instance()->get_plural_label();
		
		if ( ! isset( $groups['crm'] ) || ! is_array( $groups['crm'] ) ) {
			$groups['crm'] = [
				'key'    => 'crm',
				'label'  => sprintf( __( 'مدیریت %s', 'kasebi-erp' ), $customer_plural_label ),
				'icon'   => 'kik fa-users-02',
				'order'  => 20,
				'blocks' => [],
			];
		}
		
		$groups['crm']['blocks']                          = isset( $groups['crm']['blocks'] ) && is_array( $groups['crm']['blocks'] )
			? $groups['crm']['blocks']
			: [];
		$groups['crm']['blocks']['gravity_forms_entries'] = [
			'key'         => 'gravity_forms_entries',
			'label'       => __( 'ورودی‌های Gravity Forms', 'kasebi-erp' ),
			'icon'        => 'uik-r fa-form',
			'order'       => 90,
			'permissions' => [
				'view' => [
					'key'   => 'gravity_forms_entries.view',
					'label' => __( 'مشاهده ورودی‌های فرم کاربران', 'kasebi-erp' ),
					'type'  => 'view',
					'order' => 10,
				],
			],
		];
		
		return $groups;
	}
	
	public function ajax_dependencies( array $plugins ): array {
		return array_values( array_unique( array_merge( $plugins, [ 'gravityforms/gravityforms.php' ] ) ) );
	}
	
	private function ensure_ajax_dependencies(): void {
		if ( defined( 'KERP_MU_DOING_AJAX' ) && KERP_MU_DOING_AJAX ) {
			return;
		}
		
		$module = KERP_Modules_Ajax_Module::instance();
		$module->update_ajax_active_plugins( $this->ajax_dependencies( $module->get_ajax_active_plugins() ) );
	}
	
}
