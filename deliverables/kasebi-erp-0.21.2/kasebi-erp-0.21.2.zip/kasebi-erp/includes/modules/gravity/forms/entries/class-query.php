<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Gravity_Forms_Entries_Query {

	private static ?self $instance = NULL;

	public static function instance(): self {
		return self::$instance ??= new self();
	}

	private function __construct() {}

	public function get_forms(): array {
		if ( ! class_exists( 'GFAPI' ) ) {
			return [];
		}

		$forms  = array_merge(
			(array) GFAPI::get_forms( TRUE, FALSE, 'title', 'ASC' ),
			(array) GFAPI::get_forms( FALSE, FALSE, 'title', 'ASC' )
		);
		$result = [];

		foreach ( (array) $forms as $form ) {
			$form_id = absint( $form['id'] ?? 0 );

			if ( $form_id === 0 ) {
				continue;
			}

			$result[ $form_id ] = [
				'id'    => $form_id,
				'title' => sanitize_text_field( (string) ( $form['title'] ?? sprintf( '#%d', $form_id ) ) ),
			];
		}

		return (array) apply_filters( 'kerp_gravity_forms_entries_forms', $result );
	}

	public function find_for_user( int $user_id, array $args = [] ): array {
		$defaults = [
			'form_id'     => 0,
			'page_number' => 1,
			'per_page'    => 10,
		];
		$args     = wp_parse_args( $args, $defaults );
		$forms    = $this->get_forms();
		$form_id  = absint( $args['form_id'] );

		if ( $user_id <= 0 || empty( $forms ) || ( $form_id > 0 && ! isset( $forms[ $form_id ] ) ) ) {
			return $this->empty_result( $args );
		}

		$form_ids    = $form_id > 0 ? $form_id : array_keys( $forms );
		$page_number = max( 1, absint( $args['page_number'] ) );
		$per_page    = $this->normalize_per_page( $args['per_page'] );
		$total       = 0;
		$search_criteria = [
			'status'        => 'active',
			'field_filters' => [
				[
					'key'   => 'created_by',
					'value' => $user_id,
				],
			],
		];
		$entries        = GFAPI::get_entries(
			$form_ids,
			$search_criteria,
			[ 'key' => 'date_created', 'direction' => 'DESC' ],
			[
				'offset'    => ( $page_number - 1 ) * $per_page,
				'page_size' => $per_page,
			],
			$total
		);

		if ( is_wp_error( $entries ) ) {
			return array_merge( $this->empty_result( $args ), [ 'error' => $entries->get_error_message() ] );
		}

		$total_pages = max( 1, (int) ceil( $total / $per_page ) );

		return [
			'items'        => array_values( (array) $entries ),
			'total'        => absint( $total ),
			'page_number'  => $page_number,
			'per_page'     => $per_page,
			'total_pages'  => $total_pages,
			'forms'        => $forms,
			'selected_form'=> $form_id,
			'error'        => '',
		];
	}

	public function get_form( int $form_id ): array {
		if ( $form_id <= 0 || ! class_exists( 'GFAPI' ) ) {
			return [];
		}

		$form = GFAPI::get_form( $form_id );

		return is_array( $form ) ? $form : [];
	}

	/** Preview the current confirmation without performing its redirect or resubmitting the entry. */
	public function get_confirmation_preview( array $form, array $entry ): array {
		$result = [ 'message' => '', 'redirect' => '' ];
		if ( empty( $form['id'] ) || absint( $form['id'] ) !== absint( $entry['form_id'] ?? 0 ) ) {
			return $result;
		}

		if ( ! class_exists( 'GFFormDisplay' ) && is_callable( [ 'GFForms', 'include_frontend_files' ] ) ) {
			GFForms::include_frontend_files();
		}
		if ( ! is_callable( [ 'GFFormDisplay', 'handle_confirmation' ] ) ) {
			return $result;
		}

		// AJAX mode returns redirect data instead of sending a Location header.
		$confirmation = GFFormDisplay::handle_confirmation( $form, $entry, TRUE );
		if ( is_string( $confirmation ) ) {
			$result['message'] = wp_kses_post( $confirmation );
		} elseif ( is_array( $confirmation ) ) {
			$result['message'] = wp_kses_post( (string) ( $confirmation['message'] ?? '' ) );
			$result['redirect'] = esc_url_raw( (string) ( $confirmation['redirect'] ?? '' ), [ 'http', 'https' ] );
		}

		return $result;
	}

	public function get_public_fields( array $form, array $entry ): array {
		$rows = [];

		foreach ( (array) ( $form['fields'] ?? [] ) as $field ) {
			$type       = sanitize_key( (string) ( $field->type ?? '' ) );
			$visibility = sanitize_key( (string) ( $field->visibility ?? '' ) );

			if ( in_array( $type, [ 'html', 'section', 'page', 'captcha', 'password', 'hidden' ], TRUE ) || $visibility === 'administrative' ) {
				continue;
			}

			$values = $this->field_values( $field, $entry );

			if ( empty( $values ) ) {
				continue;
			}

			$rows[] = [
				'label'  => sanitize_text_field( (string) ( $field->label ?? '' ) ),
				'type'   => $type,
				'values' => $values,
			];
		}

		return $rows;
	}

	private function field_values( object $field, array $entry ): array {
		$values = [];
		$inputs = isset( $field->inputs ) && is_array( $field->inputs ) ? $field->inputs : [];

		if ( ! empty( $inputs ) ) {
			foreach ( $inputs as $input ) {
				$input_id = (string) ( $input['id'] ?? '' );
				$value    = $this->normalize_value( $entry[ $input_id ] ?? '' );

				if ( $value === '' ) {
					continue;
				}

				$values[] = [
					'label' => sanitize_text_field( (string) ( $input['label'] ?? '' ) ),
					'value' => $value,
				];
			}

			return $values;
		}

		$value = $this->normalize_value( $entry[ (string) ( $field->id ?? '' ) ] ?? '' );

		if ( $value !== '' ) {
			$values[] = [ 'label' => '', 'value' => $value ];
		}

		return $values;
	}

	private function normalize_value( $value ): string {
		if ( is_array( $value ) ) {
			$value = implode( ' ، ', array_filter( array_map( 'strval', $value ) ) );
		} elseif ( is_string( $value ) ) {
			$decoded = json_decode( $value, TRUE );

			if ( is_array( $decoded ) ) {
				$value = implode( ' ، ', array_filter( array_map( 'strval', $decoded ) ) );
			}
		}

		return trim( wp_strip_all_tags( (string) $value ) );
	}

	private function empty_result( array $args ): array {
		return [
			'items'         => [],
			'total'         => 0,
			'page_number'   => max( 1, absint( $args['page_number'] ?? 1 ) ),
			'per_page'      => $this->normalize_per_page( $args['per_page'] ?? 10 ),
			'total_pages'   => 1,
			'forms'         => $this->get_forms(),
			'selected_form' => absint( $args['form_id'] ?? 0 ),
			'error'         => '',
		];
	}

	private function normalize_per_page( $value ): int {
		$value = absint( $value );

		return in_array( $value, [ 5, 10, 20, 50 ], TRUE ) ? $value : 10;
	}
}
