<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Gravity_Forms_Entries_Submission {

	private const PHONE_PROPERTY = 'kerp_customer_phone';

	private static ?self $instance = NULL;

	public static function instance(): self {
		return self::$instance ??= new self();
	}

	private function __construct() {
		add_action( 'gform_field_standard_settings', [ $this, 'render_field_setting' ], 1600 );
		add_action( 'gform_editor_js', [ $this, 'editor_script' ] );
		add_action( 'gform_after_submission', [ $this, 'after_submission' ], 5, 2 );
	}

	public function render_field_setting( int $position ): void {
		if ( $position !== 1600 ) {
			return;
		}
		?>
        <li class="kerp-customer-phone-setting field_setting">
            <label for="kerp_customer_phone" class="section_label">
				<?php esc_html_e( 'اتصال به کاربر ERP', 'kasebi-erp' ); ?>
            </label>
            <input
                type="checkbox"
                id="kerp_customer_phone"
                onclick="SetFieldProperty('<?php echo esc_js( self::PHONE_PROPERTY ); ?>', this.checked);"
                onkeypress="SetFieldProperty('<?php echo esc_js( self::PHONE_PROPERTY ); ?>', this.checked);"
            >
            <label for="kerp_customer_phone" class="inline">
				<?php esc_html_e( 'این فیلد شماره تماس کاربر است', 'kasebi-erp' ); ?>
            </label>
        </li>
		<?php
	}

	public function editor_script(): void {
		?>
        <script type="text/javascript">
            (function($) {
                ['text', 'phone', 'number'].forEach(function(type) {
                    if (typeof fieldSettings[type] !== 'undefined') {
                        fieldSettings[type] += ', .kerp-customer-phone-setting';
                    }
                });

                $(document).on('gform_load_field_settings', function(event, field) {
                    $('#kerp_customer_phone').prop('checked', Boolean(field.<?php echo esc_js( self::PHONE_PROPERTY ); ?>));
                });
            })(jQuery);
        </script>
		<?php
	}

	public function after_submission( array $entry, array $form ): void {
		$entry_id = absint( $entry['id'] ?? 0 );
		$form_id  = absint( $form['id'] ?? 0 );

		if ( $entry_id <= 0 || $form_id <= 0 ) {
			return;
		}

		$current_user_id = get_current_user_id();

		if ( $current_user_id > 0 ) {
			if ( absint( $entry['created_by'] ?? 0 ) !== $current_user_id ) {
				GFAPI::update_entry_property( $entry_id, 'created_by', $current_user_id );
			}

			return;
		}

		$phone = $this->get_phone_from_entry( $entry, $form );

		if ( $phone === '' ) {
			return;
		}

		$user_id = $this->find_user_by_phone( $phone );
		$created = FALSE;

		if ( $user_id <= 0 ) {
			[ $user_id, $created ] = $this->create_customer( $phone, $form_id );
		}

		if ( $user_id > 0 ) {
			GFAPI::update_entry_property( $entry_id, 'created_by', $user_id );

			if ( $created ) {
				KERP_Services_Attribution_First_Touch::instance()->record( $user_id, 'gravity_form', [
					'form_id'    => $form_id,
					'form_title' => (string) ( $form['title'] ?? '' ),
					'entry_id'   => $entry_id,
				] );
			}

			do_action( 'kerp_gravity_forms_entry_synced_to_user', $entry_id, $user_id, $form_id, $phone );
		}
	}

	private function get_phone_from_entry( array $entry, array $form ): string {
		foreach ( (array) ( $form['fields'] ?? [] ) as $field ) {
			if ( empty( $field->{self::PHONE_PROPERTY} ) ) {
				continue;
			}

			$field_id = (string) ( $field->id ?? '' );
			$phone    = KERP_Helpers_Phone::normalize( (string) ( $entry[ $field_id ] ?? '' ) );

			if ( preg_match( '/^9\d{9}$/D', $phone ) ) {
				return $phone;
			}
		}

		return '';
	}

	private function find_user_by_phone( string $phone ): int {
		if ( function_exists( 'get_user_id_by_phone' ) ) {
			$user_id = absint( get_user_id_by_phone( $phone ) );

			if ( $user_id > 0 ) {
				return $user_id;
			}
		}

		$variants = array_unique( [ $phone, KERP_Helpers_Phone::with_zero( $phone ), '98' . $phone, '+98' . $phone ] );
		$settings = KERP_Modules_Customers_Settings::instance();
		$meta_keys = array_unique( [
			sanitize_key( (string) $settings->get( 'phone_meta_key', KERP_Helpers_Phone::get_meta_key() ) ),
			'billing_phone',
		] );

		foreach ( $meta_keys as $meta_key ) {
			if ( $meta_key === '' ) {
				continue;
			}

			$users = get_users( [
				'fields'     => 'ids',
				'number'     => 1,
				'meta_query' => [
					[
						'key'     => $meta_key,
						'value'   => $variants,
						'compare' => 'IN',
					],
				],
			] );

			if ( ! empty( $users ) ) {
				return absint( $users[0] );
			}
		}

		foreach ( $variants as $variant ) {
			$user = get_user_by( 'login', $variant );

			if ( $user instanceof WP_User ) {
				return $user->ID;
			}
		}

		return 0;
	}

	private function create_customer( string $phone, int $form_id ): array {
		$settings = KERP_Modules_Customers_Settings::instance();
		$role     = sanitize_key( (string) $settings->get( 'default_role', 'customer' ) );
		$role     = get_role( $role ) ? $role : 'subscriber';
		$meta_key = sanitize_key( (string) $settings->get( 'phone_meta_key', KERP_Helpers_Phone::get_meta_key() ) );
		$user_id  = wp_insert_user( [
			'user_login'   => $phone,
			'user_pass'    => wp_generate_password( 24, TRUE, TRUE ),
			'display_name' => KERP_Helpers_Phone::with_zero( $phone ),
			'role'         => $role,
			'meta_input'   => [
				$meta_key                        => $phone,
				'billing_phone'                  => $phone,
				'user_registered_funnel'         => 'gravity_forms',
				'user_registered_by_gravity_form'=> $form_id,
			],
		] );

		if ( is_wp_error( $user_id ) ) {
			return [ $this->find_user_by_phone( $phone ), FALSE ];
		}

		do_action( 'kerp_customer_created_from_gravity_forms', $user_id, $phone, $form_id );

		return [ absint( $user_id ), TRUE ];
	}
}
