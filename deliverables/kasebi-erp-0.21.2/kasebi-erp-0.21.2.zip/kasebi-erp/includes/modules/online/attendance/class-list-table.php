<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Online_Attendance_List_Table {
	private static ?self $instance = NULL;
	public static function instance(): self { return self::$instance ??= new self(); }
	private function __construct() {}

	public function get_filters( array $values = [] ): array {
		$joined = isset( $values['joined'] ) && is_array( $values['joined'] ) ? $values['joined'] : [];
		$filters = [
			'joined' => [ 'key' => 'joined', 'name' => 'joined', 'label' => __( 'تاریخ اولین حضور', 'kasebi-erp' ), 'type' => 'date-range', 'col' => 12, 'value' => [ 'from' => (string) ( $joined['from'] ?? '' ), 'to' => (string) ( $joined['to'] ?? '' ) ], 'order' => 5 ],
			'search' => [ 'key' => 'search', 'name' => 'search', 'label' => __( 'جستجو', 'kasebi-erp' ), 'type' => 'text', 'placeholder' => __( 'نام، ایمیل، کلاس، دوره یا اتاق', 'kasebi-erp' ), 'value' => sanitize_text_field( (string) ( $values['search'] ?? '' ) ), 'order' => 10, 'col' => 12 ],
			'post_id' => [ 'key' => 'post_id', 'name' => 'post_id', 'label' => __( 'کلاس', 'kasebi-erp' ), 'type' => 'select', 'options' => $this->post_options( 'post_id', 'post_title' ), 'placeholder' => __( 'همه کلاس‌ها', 'kasebi-erp' ), 'value' => absint( $values['post_id'] ?? 0 ), 'search' => TRUE, 'order' => 20 ],
			'course_id' => [ 'key' => 'course_id', 'name' => 'course_id', 'label' => __( 'دوره', 'kasebi-erp' ), 'type' => 'select', 'options' => $this->post_options( 'course_id', 'course_title' ), 'placeholder' => __( 'همه دوره‌ها', 'kasebi-erp' ), 'value' => absint( $values['course_id'] ?? 0 ), 'search' => TRUE, 'order' => 30 ],
			'room_slug' => [ 'key' => 'room_slug', 'name' => 'room_slug', 'label' => __( 'اسلاگ اتاق', 'kasebi-erp' ), 'type' => 'text', 'value' => sanitize_text_field( (string) ( $values['room_slug'] ?? '' ) ), 'order' => 40 ],
		];
		return $filters;
	}

	public function get_sort_options(): array { return [ 'newest' => __( 'جدیدترین حضور', 'kasebi-erp' ), 'oldest' => __( 'قدیمی‌ترین حضور', 'kasebi-erp' ), 'user_asc' => __( 'نام کاربر', 'kasebi-erp' ), 'class_asc' => __( 'عنوان کلاس', 'kasebi-erp' ) ]; }

	private function post_options( string $column, string $title_alias ): array {
		global $wpdb;
		$table = KERP_Modules_Online_Attendance_Storage::instance()->attendance_table();
		$rows = $wpdb->get_results( "SELECT DISTINCT a.{$column} AS id,p.post_title AS {$title_alias} FROM {$table} a INNER JOIN {$wpdb->posts} p ON p.ID=a.{$column} WHERE a.{$column}>0 ORDER BY p.post_title ASC LIMIT 500", ARRAY_A );
		$options = [];
		foreach ( (array) $rows as $row ) { $options[ absint( $row['id'] ?? 0 ) ] = (string) ( $row[ $title_alias ] ?? '#' . absint( $row['id'] ?? 0 ) ); }
		return $options;
	}
}
