<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Online_Attendance_Module {
	private static ?self $instance = NULL;
	public static function instance(): self { return self::$instance ??= new self(); }
	private function __construct() {
		add_filter( 'kerp_panel_navigation_pages', [ $this, 'register_panel_navigation_settings' ] );
		KERP_Modules_Online_Attendance_Settings::instance();
		KERP_Modules_Online_Attendance_Storage::instance();
		KERP_Modules_Online_Attendance_Query::instance();
		KERP_Modules_Online_Attendance_List_Table::instance();
		KERP_Modules_Online_Attendance_Skyroom::instance();
		KERP_Modules_Online_Attendance_SMS::instance();
		KERP_Modules_Online_Attendance_Api::instance();
		add_filter( 'kerp_app_pages', [ $this, 'register_pages' ], 48 );
		add_filter( 'kerp_customer_profile_tabs', [ $this, 'register_customer_tab' ], 48, 3 );
		add_filter( 'kerp_employee_permission_groups', [ $this, 'register_permissions' ], 50 );
		add_filter( 'nooshika_panel_pages_list_final', [ $this, 'register_panel_page' ], 48 );
		add_filter( 'nooshika_panel_get_template_path', [ $this, 'panel_template_path' ], 48, 2 );
		add_filter( 'nooshika_ld_lesson_fields', [ $this, 'lesson_fields' ], 20, 2 );
		add_filter( 'kerp_ajax_forced_plugins', [ $this, 'ajax_dependencies' ] );
		add_action( 'nooshika_ajax_kerp_skyroom_join', [ $this, 'ajax_join' ] );
		add_action( 'wp_enqueue_scripts', [ $this, 'assets' ], 45 );
		$this->ensure_ajax_dependencies();
	}

	public function lesson_fields( array $fields, int $post_id = 0 ): array {
		$fields[] = [ 'key' => 'sfwd_lesson_skyroom_id', 'label' => __( 'اسلاگ اتاق اسکای‌روم', 'kasebi-erp' ), 'type' => 'text', 'attrs' => [ 'dir' => 'ltr', 'placeholder' => 'room-slug' ] ];
		$fields[] = [ 'key' => 'sfwd_lesson_skyroom_start_at', 'label' => __( 'تاریخ و ساعت شروع کلاس اسکای‌روم', 'kasebi-erp' ), 'type' => 'datetime-local', 'attrs' => [ 'dir' => 'ltr' ] ];
		return $fields;
	}

	public function register_pages( array $pages ): array {
		$learning_group = [ 'key' => 'learning', 'title' => __( 'آموزش', 'kasebi-erp' ), 'icon' => 'uik-r fa-graduation-cap', 'order' => 49 ];
		$settings_group = [ 'key' => 'settings', 'title' => __( 'تنظیمات', 'kasebi-erp' ), 'icon' => 'kik fa-settings-02', 'order' => 100, 'sep_before' => TRUE ];
		$menu = [ 'key' => 'online-attendance-settings', 'title' => __( 'حضور و غیاب آنلاین', 'kasebi-erp' ), 'icon' => 'uik fa-presentation', 'order' => 60 ];
		$pages['online-attendance'] = [
			'title' => __( 'حضور کلاس‌های آنلاین', 'kasebi-erp' ), 'route' => 'online-attendance', 'type' => 'page',
			'template' => 'modules/online-attendance/pages/list.php', 'permission' => 'online_attendance.view',
			'navigation' => [ 'group' => $learning_group, 'icon' => 'uik fa-presentation', 'order' => 30 ],
		];
		$pages['online-attendance-settings'] = [
			'title' => __( 'تنظیمات اسکای‌روم', 'kasebi-erp' ), 'route' => 'settings/online-attendance', 'type' => 'settings',
			'template' => 'modules/online-attendance/settings/general.php', 'permission' => 'online_attendance.manage_settings',
			'navigation' => [ 'group' => $settings_group, 'menu' => $menu, 'title' => __( 'اتصال اسکای‌روم', 'kasebi-erp' ), 'order' => 10 ],
		];
		$pages['online-attendance-sms'] = [
			'title' => __( 'پیامک غیبت کلاس آنلاین', 'kasebi-erp' ), 'route' => 'settings/online-attendance/sms', 'type' => 'settings',
			'template' => 'modules/online-attendance/settings/sms.php', 'permission' => 'online_attendance.manage_settings',
			'navigation' => [ 'group' => $settings_group, 'menu' => $menu, 'title' => __( 'پیامک غیبت', 'kasebi-erp' ), 'order' => 20 ],
		];
		return $pages;
	}

	public function register_permissions( array $groups ): array {
		$group = $groups['learning'] ?? [ 'key' => 'learning', 'label' => __( 'آموزش', 'kasebi-erp' ), 'icon' => 'uik-r fa-graduation-cap', 'order' => 49, 'blocks' => [] ];
		$group['blocks'] = isset( $group['blocks'] ) && is_array( $group['blocks'] ) ? $group['blocks'] : [];
		$group['blocks']['online_attendance'] = [
			'key' => 'online_attendance', 'label' => __( 'حضور و غیاب آنلاین', 'kasebi-erp' ), 'icon' => 'uik fa-presentation', 'order' => 20,
			'permissions' => [
				'view' => [ 'key' => 'online_attendance.view', 'label' => __( 'مشاهده حضورها', 'kasebi-erp' ), 'type' => 'view', 'order' => 10 ],
				'settings' => [ 'key' => 'online_attendance.manage_settings', 'label' => __( 'مدیریت تنظیمات', 'kasebi-erp' ), 'type' => 'action', 'order' => 20 ],
			],
		];
		$groups['learning'] = $group;
		return $groups;
	}

	public function register_customer_tab( array $tabs, int $customer_id, WP_User $customer ): array {
		if ( kerp_can( 'online_attendance.view', 'view' ) ) {
			$tabs['online-attendance'] = [
				'key'        => 'online-attendance',
				'title'      => __( 'حضور کلاس آنلاین', 'kasebi-erp' ),
				'icon'       => 'uik fa-presentation',
				'order'      => 80,
				'group'      => 'planning-learning',
				'permission' => 'online_attendance.view',
				'action'     => 'view',
				'template'   => 'modules/online-attendance/tabs/customer-attendance.php',
			];
		}

		return $tabs;
	}

	public function register_panel_page( array $pages ): array {
		$pages['online-attendance'] = [
			'label' => __( 'تاریخچه حضور', 'kasebi-erp' ),
			'icon'  => 'uik fa-presentation',
		];

		return $pages;
	}

	public function panel_template_path( string $file_path, string $path ): string {
		return $path === 'pages/online-attendance'
			? KERP_TEMPLATES_PATH . 'modules/online-attendance/panel/history.php'
			: $file_path;
	}

	public function ajax_dependencies( array $plugins ): array {
		return array_values( array_unique( array_merge( $plugins, [
			'nooshika-main/nooshika-main.php', 'nooshika-panel/nooshika-panel.php', 'sfwd-lms/sfwd_lms.php',
		] ) ) );
	}

	private function ensure_ajax_dependencies(): void {
		if ( defined( 'KERP_MU_DOING_AJAX' ) && KERP_MU_DOING_AJAX ) { return; }
		$module = KERP_Modules_Ajax_Module::instance();
		$module->update_ajax_active_plugins( $this->ajax_dependencies( $module->get_ajax_active_plugins() ) );
	}

	public function assets(): void {
		if ( ! is_page( 'panel' ) ) { return; }
		KERP_Helpers_Panel_Ajax::ensure_dependencies();
		wp_enqueue_style( 'kerp-online-attendance', KERP_ASSETS_URL . 'public/css/online-attendance.css', [], kerp_asset_version( 'public/css/online-attendance.css' ) );
		wp_enqueue_script( 'kerp-online-attendance', KERP_ASSETS_URL . 'public/js/online-attendance.js', [ 'jquery', 'nooshika_panel_script' ], kerp_asset_version( 'public/js/online-attendance.js' ), TRUE );
		wp_localize_script( 'kerp-online-attendance', 'KERPOnlineAttendance', [
			'ajaxUrl' => home_url( 'n-ajax' ), 'nonce' => wp_create_nonce( 'kerp_skyroom_join' ),
			'loading' => __( 'در حال دریافت لینک ورود…', 'kasebi-erp' ), 'error' => __( 'ساخت لینک ورود ناموفق بود.', 'kasebi-erp' ),
		] );
	}

	public function ajax_join(): void {
		if ( ! is_user_logged_in() ) { $this->join_error( __( 'ابتدا وارد حساب کاربری شوید.', 'kasebi-erp' ) ); }
		$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( (string) $_POST['nonce'] ) ) : '';
		if ( ! wp_verify_nonce( $nonce, 'kerp_skyroom_join' ) ) { $this->join_error( __( 'درخواست نامعتبر است؛ صفحه را تازه‌سازی کنید.', 'kasebi-erp' ) ); }
		$post_id = absint( $_POST['post_id'] ?? 0 );
		$post = $post_id ? get_post( $post_id ) : NULL;
		if ( ! $post instanceof WP_Post || ! in_array( $post->post_type, [ 'sfwd-lessons', 'sfwd-topic' ], TRUE ) ) { $this->join_error( __( 'کلاس معتبر نیست.', 'kasebi-erp' ) ); }
		$user_id = get_current_user_id();
		$course_id = function_exists( 'learndash_get_course_id' ) ? absint( learndash_get_course_id( $post_id ) ) : 0;
		$has_access = current_user_can( 'manage_options' ) || ( $course_id > 0 && function_exists( 'sfwd_lms_has_access' ) && sfwd_lms_has_access( $course_id, $user_id ) );
		if ( ! $has_access ) { $this->join_error( __( 'شما به این کلاس دسترسی ندارید.', 'kasebi-erp' ) ); }
		$slug = sanitize_text_field( (string) get_post_meta( $post_id, 'sfwd_lesson_skyroom_id', TRUE ) );
		if ( $slug === '' ) { $this->join_error( __( 'اتاق اسکای‌روم برای این کلاس تنظیم نشده است.', 'kasebi-erp' ) ); }
		$url = KERP_Modules_Online_Attendance_Skyroom::instance()->create_login_url( $slug, $user_id );
		if ( is_wp_error( $url ) ) { $this->join_error( $url->get_error_message() ); }
		if ( ! KERP_Modules_Online_Attendance_Storage::instance()->record( $user_id, $post_id, $course_id, $slug ) ) { $this->join_error( __( 'ثبت حضور انجام نشد؛ دوباره تلاش کنید.', 'kasebi-erp' ) ); }
		do_action( 'kerp_online_attendance_joined', $user_id, $post_id, $course_id, $slug );
		wp_send_json( [ 'status' => TRUE, 'url' => $url ] );
	}

	private function join_error( string $message ): void {
		wp_send_json( [ 'status' => FALSE, 'message' => $message ], 200 );
		exit;
	}

	public function register_panel_navigation_settings( array $rows ): array {
		return KERP_Settings_Panel_Navigation::register_entries( $rows, 'online_attendance', 'حضور آنلاین', $this->register_panel_page( [] ) );
	}
}
