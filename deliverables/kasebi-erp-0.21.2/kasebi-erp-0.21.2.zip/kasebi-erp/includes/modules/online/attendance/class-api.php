<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Online_Attendance_Api {
	private static ?self $instance = NULL;
	public static function instance(): self { return self::$instance ??= new self(); }
	private function __construct() {
		add_action( 'kasebi_ajax_online_attendance_save_settings', [ $this, 'save_settings' ] );
		add_action( 'kasebi_ajax_online_attendance_save_sms', [ $this, 'save_sms' ] );
	}

	public function save_settings(): void {
		$this->guard();
		$input = isset( $_POST['settings'] ) && is_array( $_POST['settings'] ) ? wp_unslash( $_POST['settings'] ) : [];
		KERP_Modules_Online_Attendance_Settings::instance()->save( $input );
		$this->success( __( 'تنظیمات اسکای‌روم ذخیره شد.', 'kasebi-erp' ), '/erp/settings/online-attendance/' );
	}

	public function save_sms(): void {
		$this->guard();
		$rules = isset( $_POST['sms_rules'] ) && is_array( $_POST['sms_rules'] ) ? wp_unslash( $_POST['sms_rules'] ) : [];
		KERP_Modules_Online_Attendance_SMS::instance()->save_rules( $rules );
		$this->success( __( 'تنظیمات پیامک غیبت ذخیره شد.', 'kasebi-erp' ), '/erp/settings/online-attendance/sms/' );
	}

	private function guard(): void {
		if ( ! function_exists( 'kerp_can' ) || ! kerp_can( 'online_attendance.manage_settings', 'action' ) ) {
			wp_send_json( [ 'status' => 'error', 'message' => __( 'دسترسی لازم را ندارید.', 'kasebi-erp' ), 'msg' => __( 'دسترسی لازم را ندارید.', 'kasebi-erp' ) ] );
		}
	}
	private function success( string $message, string $page ): void {
		$data = class_exists( 'KERP_Api_Page_Content' ) ? KERP_Api_Page_Content::build_page_response( $page, [], TRUE ) : [];
		wp_send_json( array_merge( [ 'status' => 'success', 'message' => $message, 'msg' => $message ], $data ) );
	}
}
