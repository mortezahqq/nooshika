<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Online_Attendance_Settings {
	private const OPTION = 'kerp_online_attendance_settings';
	private static ?self $instance = NULL;

	public static function instance(): self { return self::$instance ??= new self(); }
	private function __construct() {}

	public function all(): array {
		$saved = get_option( self::OPTION, [] );
		$saved = is_array( $saved ) ? $saved : [];
		return wp_parse_args( $saved, [
			'api_url' => (string) get_option( 'kasebi_skyroom_site_url', '' ),
			'api_key' => (string) get_option( 'kasebi_skyroom_api_key', '' ),
			'login_ttl' => 18000,
		] );
	}

	public function get( string $key, mixed $default = '' ): mixed {
		$values = $this->all();
		return $values[ $key ] ?? $default;
	}

	public function save( array $input ): void {
		$url = esc_url_raw( trim( is_scalar( $input['api_url'] ?? '' ) ? (string) $input['api_url'] : '' ) );
		$key = sanitize_text_field( is_scalar( $input['api_key'] ?? '' ) ? (string) $input['api_key'] : '' );
		$ttl = max( 300, min( DAY_IN_SECONDS, absint( $input['login_ttl'] ?? 18000 ) ) );
		update_option( self::OPTION, [ 'api_url' => $url, 'api_key' => $key, 'login_ttl' => $ttl ], FALSE );
	}
}
