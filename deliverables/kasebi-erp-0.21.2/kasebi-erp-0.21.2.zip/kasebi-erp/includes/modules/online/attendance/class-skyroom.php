<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Online_Attendance_Skyroom {
	private static ?self $instance = NULL;
	public static function instance(): self { return self::$instance ??= new self(); }
	private function __construct() {}

	public function create_login_url( string $room_slug, int $user_id ): string|WP_Error {
		$room = $this->request( 'getRoom', [ 'name' => $room_slug ] );
		if ( is_wp_error( $room ) ) { return $room; }
		$room_id = absint( is_object( $room ) ? ( $room->id ?? 0 ) : ( $room['id'] ?? 0 ) );
		if ( $room_id <= 0 ) { return new WP_Error( 'kerp_skyroom_room', __( 'اتاق اسکای‌روم پیدا نشد.', 'kasebi-erp' ) ); }
		$user = get_userdata( $user_id );
		$name = $user ? trim( (string) get_user_name_by_id( $user->ID ) ) : '';
		if ( $name === '' ) { $name = sprintf( __( 'کاربر %d', 'kasebi-erp' ), $user_id ); }
		$ttl = absint( KERP_Modules_Online_Attendance_Settings::instance()->get( 'login_ttl', 18000 ) );
		$result = $this->request( 'createLoginUrl', [
			'room_id' => $room_id, 'user_id' => $user_id, 'nickname' => $name,
			'access' => 1, 'concurrent' => 1, 'ttl' => $ttl,
		] );
		if ( is_wp_error( $result ) ) { return $result; }
		$url = esc_url_raw( is_scalar( $result ) ? (string) $result : '' );
		return $url !== '' ? $url : new WP_Error( 'kerp_skyroom_url', __( 'اسکای‌روم لینک ورود معتبری برنگرداند.', 'kasebi-erp' ) );
	}

	private function request( string $action, array $params ): mixed {
		$settings = KERP_Modules_Online_Attendance_Settings::instance();
		$base = trim( (string) $settings->get( 'api_url' ) );
		$key = trim( (string) $settings->get( 'api_key' ) );
		if ( $base === '' || $key === '' ) { return new WP_Error( 'kerp_skyroom_config', __( 'مسیر API و API Key اسکای‌روم تنظیم نشده است.', 'kasebi-erp' ) ); }
		$url = str_contains( $base, '{api_key}' ) ? str_replace( '{api_key}', rawurlencode( $key ), $base ) : trailingslashit( $base ) . rawurlencode( $key );
		$response = wp_remote_post( $url, [
			'headers' => [ 'Content-Type' => 'application/json; charset=UTF-8' ],
			'body' => wp_json_encode( [ 'action' => $action, 'params' => $params ] ), 'timeout' => 30,
		] );
		if ( is_wp_error( $response ) ) { return $response; }
		if ( wp_remote_retrieve_response_code( $response ) !== 200 ) { return new WP_Error( 'kerp_skyroom_http', __( 'ارتباط با API اسکای‌روم ناموفق بود.', 'kasebi-erp' ) ); }
		$decoded = json_decode( wp_remote_retrieve_body( $response ) );
		if ( ! is_object( $decoded ) || empty( $decoded->ok ) ) {
			$message = is_object( $decoded ) && ! empty( $decoded->error_message ) ? (string) $decoded->error_message : __( 'پاسخ API اسکای‌روم معتبر نیست.', 'kasebi-erp' );
			return new WP_Error( 'kerp_skyroom_api', sanitize_text_field( $message ) );
		}
		return $decoded->result ?? NULL;
	}
}
