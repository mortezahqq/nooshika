<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Online_Attendance_SMS {
	private const OPTION = 'kerp_online_attendance_sms_rules';
	private const CRON_HOOK = 'kerp_online_attendance_check_absences';
	private static ?self $instance = NULL;
	private mixed $service = NULL;

	public static function instance(): self { return self::$instance ??= new self(); }
	private function __construct() {
		add_filter( 'cron_schedules', [ $this, 'cron_schedules' ] );
		add_action( self::CRON_HOOK, [ $this, 'check_absences' ] );
		if ( ! wp_next_scheduled( self::CRON_HOOK ) ) { wp_schedule_event( time() + 300, 'kerp_five_minutes', self::CRON_HOOK ); }
	}

	public function cron_schedules( array $schedules ): array {
		$schedules['kerp_five_minutes'] = [ 'interval' => 300, 'display' => __( 'هر پنج دقیقه', 'kasebi-erp' ) ];
		return $schedules;
	}

	public function service_available(): bool { return class_exists( 'kasebiSMS' ) && method_exists( 'kasebiSMS', 'send_pattern_sms' ); }
	public function get_rules(): array {
		$rules = get_option( self::OPTION, [] );
		if ( ! is_array( $rules ) ) { return []; }
		$output = [];
		foreach ( $rules as $rule ) {
			if ( ! is_array( $rule ) ) { continue; }
			$rule['recipient'] = in_array( (string) ( $rule['recipient'] ?? '' ), [ 'user_meta', 'custom' ], TRUE ) ? (string) $rule['recipient'] : 'user_meta';
			$rule['phone_meta'] = sanitize_key( (string) ( $rule['phone_meta'] ?? '' ) ) ?: 'nooshika_phone_num';
			$output[] = $rule;
		}
		return $output;
	}
	public function variables(): array { return [
		'{user_id}' => __( 'شناسه کاربر', 'kasebi-erp' ), '{user_name}' => __( 'نام کاربر', 'kasebi-erp' ),
		'{first_name}' => __( 'نام', 'kasebi-erp' ), '{last_name}' => __( 'نام خانوادگی', 'kasebi-erp' ),
		'{class_title}' => __( 'عنوان کلاس', 'kasebi-erp' ), '{class_date}' => __( 'تاریخ شروع کلاس', 'kasebi-erp' ),
		'{class_time}' => __( 'ساعت شروع کلاس', 'kasebi-erp' ), '{course_title}' => __( 'عنوان دوره', 'kasebi-erp' ),
		'{site_name}' => __( 'نام سایت', 'kasebi-erp' ),
	]; }

	public function save_rules( array $rules ): void {
		$clean = [];
		foreach ( $rules as $rule ) {
			if ( ! is_array( $rule ) ) { continue; }
			$pattern = sanitize_text_field( is_scalar( $rule['pattern'] ?? '' ) ? (string) $rule['pattern'] : '' );
			$variables = sanitize_textarea_field( is_scalar( $rule['variables'] ?? '' ) ? (string) $rule['variables'] : '' );
			$recipient = sanitize_key( is_scalar( $rule['recipient'] ?? '' ) ? (string) $rule['recipient'] : '' );
			$phone_meta = sanitize_key( is_scalar( $rule['phone_meta'] ?? '' ) ? (string) $rule['phone_meta'] : '' );
			$receptor = sanitize_text_field( is_scalar( $rule['receptor'] ?? '' ) ? (string) $rule['receptor'] : '' );
			$delay = max( 0, min( 10080, absint( $rule['delay_minutes'] ?? 0 ) ) );
			if ( $pattern === '' && $variables === '' && $phone_meta === '' && $receptor === '' ) { continue; }
			$recipient = in_array( $recipient, [ 'user_meta', 'custom' ], TRUE ) ? $recipient : 'user_meta';
			$clean[] = [
				'delay_minutes' => $delay, 'recipient' => $recipient, 'phone_meta' => $phone_meta ?: 'nooshika_phone_num',
				'receptor' => $receptor, 'pattern' => $pattern, 'variables' => $variables,
			];
		}
		update_option( self::OPTION, $clean, FALSE );
		if ( ! wp_next_scheduled( self::CRON_HOOK ) ) { wp_schedule_single_event( time() + 60, self::CRON_HOOK ); }
	}

	public function check_absences(): void {
		$rules = array_values( array_filter( $this->get_rules(), fn( array $rule ): bool => ! empty( $rule['pattern'] ) ) );
		if ( empty( $rules ) || ! $this->service_available() ) { return; }
		$max_delay = max( array_map( fn( array $rule ): int => absint( $rule['delay_minutes'] ?? 0 ), $rules ) );
		$now = time();
		$posts = get_posts( [
			'post_type' => [ 'sfwd-lessons', 'sfwd-topic' ], 'post_status' => 'publish', 'posts_per_page' => 200,
			'meta_query' => [ [ 'key' => 'sfwd_lesson_skyroom_id', 'compare' => 'EXISTS' ], [ 'key' => 'sfwd_lesson_skyroom_start_at', 'compare' => 'EXISTS' ] ],
			'orderby' => 'meta_value', 'meta_key' => 'sfwd_lesson_skyroom_start_at', 'order' => 'DESC',
		] );
		foreach ( $posts as $post ) {
			$start = $this->start_timestamp( (string) get_post_meta( $post->ID, 'sfwd_lesson_skyroom_start_at', TRUE ) );
			if ( $start <= 0 || $start > $now || $start < $now - ( max( DAY_IN_SECONDS, $max_delay * MINUTE_IN_SECONDS ) + DAY_IN_SECONDS ) ) { continue; }
			$course_id = function_exists( 'learndash_get_course_id' ) ? absint( learndash_get_course_id( $post->ID ) ) : 0;
			if ( $course_id <= 0 ) { continue; }
			foreach ( $this->course_user_ids( $course_id ) as $user_id ) {
				if ( KERP_Modules_Online_Attendance_Storage::instance()->has_attended( $user_id, $post->ID ) ) { continue; }
				foreach ( $rules as $rule ) {
					if ( $now < $start + absint( $rule['delay_minutes'] ?? 0 ) * MINUTE_IN_SECONDS ) { continue; }
					$this->send_rule( $rule, $user_id, $post, $course_id, $start );
				}
			}
		}
	}

	private function send_rule( array $rule, int $user_id, WP_Post $post, int $course_id, int $start ): void {
		$storage = KERP_Modules_Online_Attendance_Storage::instance();
		$phones = $this->recipient_numbers( $rule, $user_id );
		if ( empty( $phones ) ) { return; }
		$user = get_userdata( $user_id );
		$context = [
			'{user_id}' => (string) $user_id, '{user_name}' => $user ? (string) get_user_name_by_id( $user_id ) : '',
			'{first_name}' => $user ? (string) $user->first_name : '', '{last_name}' => $user ? (string) $user->last_name : '',
			'{class_title}' => get_the_title( $post ), '{class_date}' => date_i18n( 'Y/m/d', $start ),
			'{class_time}' => date_i18n( 'H:i', $start ), '{course_title}' => get_the_title( $course_id ),
			'{site_name}' => (string) get_bloginfo( 'name' ),
		];
		$tokens = [];
		foreach ( $this->parse_variables( (string) ( $rule['variables'] ?? '' ) ) as $name => $template ) { $tokens[ $name ] = $this->pattern_value( strtr( $template, $context ) ); }
		foreach ( $phones as $phone ) {
			$hash = hash( 'sha256', ( wp_json_encode( $rule ) ?: serialize( $rule ) ) . '|' . $phone );
			if ( ! $storage->claim_notification( $user_id, $post->ID, $hash ) ) { continue; }
			$payload = [ 'receptor' => $phone, 'pattern' => (string) $rule['pattern'] ] + $tokens;
			try {
				$response = $this->sms_service()->send_pattern_sms( $payload );
			} catch ( Throwable $error ) {
				$storage->release_notification( $user_id, $post->ID, $hash );
				do_action( 'kerp_online_attendance_sms_failed', $error, $payload, $rule, $user_id, $post->ID );
				continue;
			}
			if ( is_wp_error( $response ) || $response === FALSE ) { $storage->release_notification( $user_id, $post->ID, $hash ); }
			do_action( 'kerp_online_attendance_sms_sent', $response, $payload, $rule, $user_id, $post->ID );
		}
	}

	private function recipient_numbers( array $rule, int $user_id ): array {
		$recipient = sanitize_key( (string) ( $rule['recipient'] ?? 'user_meta' ) );
		$numbers = [];
		if ( $recipient === 'custom' ) {
			$numbers = preg_split( '/\s*[,،]\s*/u', (string) ( $rule['receptor'] ?? '' ), -1, PREG_SPLIT_NO_EMPTY ) ?: [];
		} else {
			$meta_key = sanitize_key( (string) ( $rule['phone_meta'] ?? 'nooshika_phone_num' ) );
			$numbers[] = get_user_meta( $user_id, $meta_key ?: 'nooshika_phone_num', TRUE );
		}
		return array_values( array_unique( array_filter( array_map( fn( mixed $number ): string => $this->normalize_phone( is_scalar( $number ) ? (string) $number : '' ), $numbers ) ) ) );
	}

	private function course_user_ids( int $course_id ): array {
		if ( ! function_exists( 'learndash_get_users_for_course' ) ) { return []; }
		$result = learndash_get_users_for_course( $course_id, [ 'fields' => 'ids', 'number' => 0 ] );
		if ( is_object( $result ) && is_callable( [ $result, 'get_results' ] ) ) { $result = $result->get_results(); }
		if ( ! is_array( $result ) ) { return []; }
		$ids = [];
		foreach ( $result as $item ) { $ids[] = absint( $item instanceof WP_User ? $item->ID : $item ); }
		return array_values( array_unique( array_filter( $ids ) ) );
	}

	private function start_timestamp( string $value ): int {
		if ( trim( $value ) === '' ) { return 0; }
		try { return ( new DateTimeImmutable( $value, wp_timezone() ) )->getTimestamp(); } catch ( Exception ) { return 0; }
	}
	private function parse_variables( string $raw ): array {
		$out = [];
		foreach ( preg_split( '/\s*;\s*/u', trim( $raw ), -1, PREG_SPLIT_NO_EMPTY ) ?: [] as $item ) {
			$at = strpos( $item, ':' ); if ( $at === FALSE ) { $at = strpos( $item, '=' ); } if ( $at === FALSE ) { continue; }
			$key = preg_replace( '/[^A-Za-z0-9_-]/', '', trim( substr( $item, 0, $at ) ) ) ?: '';
			if ( $key !== '' ) { $out[ $key ] = trim( substr( $item, $at + 1 ) ); }
		}
		return $out;
	}
	private function normalize_phone( string $raw ): string {
		if ( function_exists( 'nooshika_sanitize_numbers' ) ) { $raw = (string) nooshika_sanitize_numbers( $raw ); }
		if ( function_exists( 'remove_zero_from_phone' ) ) { return trim( (string) remove_zero_from_phone( $raw ) ); }
		$digits = preg_replace( '/\D+/', '', $raw ) ?? '';
		return preg_replace( '/^(?:0098|098|98|0)/', '', $digits ) ?? '';
	}
	private function pattern_value( string $value ): string { return str_replace( [ ' ', '_' ], '-', sanitize_text_field( $value ) ); }
	private function sms_service(): mixed { return $this->service ??= new kasebiSMS(); }
}
