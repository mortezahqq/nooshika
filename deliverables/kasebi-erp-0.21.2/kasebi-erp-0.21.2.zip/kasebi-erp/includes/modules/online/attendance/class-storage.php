<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Online_Attendance_Storage {
	private const VERSION = '1.1.0';
	private const VERSION_OPTION = 'kerp_online_attendance_db_version';
	private static ?self $instance = NULL;

	public static function instance(): self { return self::$instance ??= new self(); }
	private function __construct() { $this->maybe_install(); }

	public function attendance_table(): string { global $wpdb; return $wpdb->prefix . 'kerp_online_attendance'; }
	public function notifications_table(): string { global $wpdb; return $wpdb->prefix . 'kerp_online_attendance_sms'; }

	private function maybe_install(): void {
		if ( (string) get_option( self::VERSION_OPTION, '' ) === self::VERSION ) { return; }
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$charset = $wpdb->get_charset_collate();
		$attendance = $this->attendance_table();
		$notifications = $this->notifications_table();
		dbDelta( "CREATE TABLE {$attendance} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			user_id bigint(20) unsigned NOT NULL,
			post_id bigint(20) unsigned NOT NULL,
			course_id bigint(20) unsigned NOT NULL DEFAULT 0,
			room_slug varchar(191) NOT NULL DEFAULT '',
			joined_at datetime NOT NULL,
			last_joined_at datetime NOT NULL,
			join_count bigint(20) unsigned NOT NULL DEFAULT 1,
			PRIMARY KEY  (id),
			UNIQUE KEY user_class (user_id,post_id),
			KEY post_id (post_id),
			KEY joined_at (joined_at)
		) {$charset};" );
		dbDelta( "CREATE TABLE {$notifications} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			user_id bigint(20) unsigned NOT NULL,
			post_id bigint(20) unsigned NOT NULL,
			rule_hash varchar(64) NOT NULL,
			sent_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY user_class_rule (user_id,post_id,rule_hash),
			KEY post_id (post_id)
		) {$charset};" );
		update_option( self::VERSION_OPTION, self::VERSION, FALSE );
	}

	public function record( int $user_id, int $post_id, int $course_id, string $room_slug ): bool {
		global $wpdb;
		$now = current_time( 'mysql', TRUE );
		$sql = $wpdb->prepare(
			"INSERT INTO {$this->attendance_table()} (user_id,post_id,course_id,room_slug,joined_at,last_joined_at)
			 VALUES (%d,%d,%d,%s,%s,%s)
			 ON DUPLICATE KEY UPDATE course_id=VALUES(course_id),room_slug=VALUES(room_slug),last_joined_at=VALUES(last_joined_at),join_count=join_count+1",
			$user_id, $post_id, $course_id, $room_slug, $now, $now
		);
		return $wpdb->query( $sql ) !== FALSE;
	}

	public function has_attended( int $user_id, int $post_id ): bool {
		global $wpdb;
		return (bool) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$this->attendance_table()} WHERE user_id=%d AND post_id=%d LIMIT 1", $user_id, $post_id ) );
	}

	public function notification_sent( int $user_id, int $post_id, string $rule_hash ): bool {
		global $wpdb;
		return (bool) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$this->notifications_table()} WHERE user_id=%d AND post_id=%d AND rule_hash=%s LIMIT 1", $user_id, $post_id, $rule_hash ) );
	}

	public function mark_notification_sent( int $user_id, int $post_id, string $rule_hash ): void {
		global $wpdb;
		$wpdb->query( $wpdb->prepare(
			"INSERT IGNORE INTO {$this->notifications_table()} (user_id,post_id,rule_hash,sent_at) VALUES (%d,%d,%s,%s)",
			$user_id, $post_id, $rule_hash, current_time( 'mysql', TRUE )
		) );
	}

	public function claim_notification( int $user_id, int $post_id, string $rule_hash ): bool {
		global $wpdb;
		$result = $wpdb->query( $wpdb->prepare(
			"INSERT IGNORE INTO {$this->notifications_table()} (user_id,post_id,rule_hash,sent_at) VALUES (%d,%d,%s,%s)",
			$user_id, $post_id, $rule_hash, current_time( 'mysql', TRUE )
		) );
		return $result === 1;
	}

	public function release_notification( int $user_id, int $post_id, string $rule_hash ): void {
		global $wpdb;
		$wpdb->delete( $this->notifications_table(), [ 'user_id' => $user_id, 'post_id' => $post_id, 'rule_hash' => $rule_hash ], [ '%d', '%d', '%s' ] );
	}

	public function recent( int $limit = 100 ): array {
		global $wpdb;
		$limit = max( 1, min( 500, $limit ) );
		return (array) $wpdb->get_results(
			"SELECT a.*,u.display_name,u.user_email,p.post_title FROM {$this->attendance_table()} a
			 LEFT JOIN {$wpdb->users} u ON u.ID=a.user_id LEFT JOIN {$wpdb->posts} p ON p.ID=a.post_id
			 ORDER BY a.joined_at DESC LIMIT {$limit}", ARRAY_A
		);
	}
}
