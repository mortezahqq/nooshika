<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Online_Attendance_Query {
	private static ?self $instance = NULL;
	public static function instance(): self { return self::$instance ??= new self(); }
	private function __construct() {}

	public function find( array $args = [] ): array {
		global $wpdb;
		$args = wp_parse_args( $args, [
			'user_id' => 0, 'post_id' => 0, 'course_id' => 0, 'room_slug' => '', 'search' => '',
			'date_from' => '', 'date_to' => '', 'page_number' => 1, 'per_page' => 20, 'sort_order' => 'newest',
		] );
		$table = KERP_Modules_Online_Attendance_Storage::instance()->attendance_table();
		$where = [ '1=1' ];
		$params = [];
		foreach ( [ 'user_id', 'post_id', 'course_id' ] as $key ) {
			$value = absint( $args[ $key ] ?? 0 );
			if ( $value > 0 ) { $where[] = 'a.' . $key . ' = %d'; $params[] = $value; }
		}
		$room = sanitize_text_field( (string) ( $args['room_slug'] ?? '' ) );
		if ( $room !== '' ) { $where[] = 'a.room_slug LIKE %s'; $params[] = '%' . $wpdb->esc_like( $room ) . '%'; }
		$search = sanitize_text_field( (string) ( $args['search'] ?? '' ) );
		if ( $search !== '' ) {
			$like = '%' . $wpdb->esc_like( $search ) . '%';
			$where[] = '(u.display_name LIKE %s OR u.user_email LIKE %s OR p.post_title LIKE %s OR c.post_title LIKE %s OR a.room_slug LIKE %s)';
			$params = array_merge( $params, [ $like, $like, $like, $like, $like ] );
		}
		$date_from = $this->utc_boundary( (string) ( $args['date_from'] ?? '' ), FALSE );
		if ( $date_from !== '' ) { $where[] = 'a.joined_at >= %s'; $params[] = $date_from; }
		$date_to = $this->utc_boundary( (string) ( $args['date_to'] ?? '' ), TRUE );
		if ( $date_to !== '' ) { $where[] = 'a.joined_at <= %s'; $params[] = $date_to; }

		$page = max( 1, absint( $args['page_number'] ?? 1 ) );
		$per_page = max( 1, min( 200, absint( $args['per_page'] ?? 20 ) ) );
		$sorts = [
			'newest' => 'a.joined_at DESC, a.id DESC', 'oldest' => 'a.joined_at ASC, a.id ASC',
			'user_asc' => 'u.display_name ASC, a.joined_at DESC', 'class_asc' => 'p.post_title ASC, a.joined_at DESC',
		];
		$order_by = $sorts[ sanitize_key( (string) ( $args['sort_order'] ?? '' ) ) ] ?? $sorts['newest'];
		$where_sql = implode( ' AND ', $where );
		$joins = " LEFT JOIN {$wpdb->users} u ON u.ID=a.user_id LEFT JOIN {$wpdb->posts} p ON p.ID=a.post_id LEFT JOIN {$wpdb->posts} c ON c.ID=a.course_id";
		$count_sql = "SELECT COUNT(*) FROM {$table} a {$joins} WHERE {$where_sql}";
		if ( $params ) { $count_sql = $wpdb->prepare( $count_sql, ...$params ); }
		$total = absint( $wpdb->get_var( $count_sql ) );
		$total_pages = max( 1, (int) ceil( $total / $per_page ) );
		$page = min( $page, $total_pages );
		$list_sql = "SELECT a.*,u.display_name,u.user_email,p.post_title,p.post_type,c.post_title AS course_title FROM {$table} a {$joins} WHERE {$where_sql} ORDER BY {$order_by} LIMIT %d OFFSET %d";
		$list_sql = $wpdb->prepare( $list_sql, ...array_merge( $params, [ $per_page, ( $page - 1 ) * $per_page ] ) );
		$items = array_map( [ $this, 'normalize_row' ], (array) $wpdb->get_results( $list_sql, ARRAY_A ) );
		return [ 'items' => $items, 'total' => $total, 'per_page' => $per_page, 'page_number' => $page, 'total_pages' => $total_pages, 'request_args' => $args ];
	}

	private function utc_boundary( string $value, bool $end ): string {
		$value = trim( $value );
		if ( $value === '' ) { return ''; }
		$date = KERP_Helpers_Date::jalali_to_gregorian( $value );
		if ( $date === '' ) { return ''; }
		return get_gmt_from_date( $date . ( $end ? ' 23:59:59' : ' 00:00:00' ) );
	}

	private function normalize_row( array $row ): array {
		foreach ( [ 'id', 'user_id', 'post_id', 'course_id', 'join_count' ] as $key ) { $row[ $key ] = absint( $row[ $key ] ?? 0 ); }
		$row['room_slug'] = sanitize_text_field( (string) ( $row['room_slug'] ?? '' ) );
		return $row;
	}
}
