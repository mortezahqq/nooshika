<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Learning_Assignments_Migration {
	private static ?self $instance = NULL;

	public static function instance(): self { return self::$instance ??= new self(); }
	private function __construct() {}

	public function status(): array {
		global $wpdb;
		$store = KERP_Modules_Learning_Assignments_Store::instance();
		$legacy = $store->legacy_table();
		if ( ! $this->table_exists( $legacy ) ) {
			return [ 'available' => FALSE, 'total' => 0, 'migrated' => 0, 'remaining' => 0 ];
		}
		$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$legacy}" );
		$migrated = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$store->table()} WHERE legacy_id IS NOT NULL" );
		return [ 'available' => TRUE, 'total' => $total, 'migrated' => $migrated, 'remaining' => max( 0, $total - $migrated ) ];
	}

	public function migrate_batch( int $limit = 100 ): array|WP_Error {
		global $wpdb;
		$store = KERP_Modules_Learning_Assignments_Store::instance();
		$legacy = $store->legacy_table();
		if ( ! $this->table_exists( $legacy ) ) {
			return new WP_Error( 'kerp_practice_legacy_missing', 'جدول پاسخ‌های قدیمی پیدا نشد.' );
		}
		$limit = max( 1, min( 200, $limit ) );
		$rows = (array) $wpdb->get_results( $wpdb->prepare(
			"SELECT old.* FROM {$legacy} old LEFT JOIN {$store->table()} current_answers ON current_answers.legacy_id = old.id WHERE current_answers.id IS NULL ORDER BY old.id ASC LIMIT %d",
			$limit
		), ARRAY_A );
		$legacy_meta = $wpdb->prefix . 'ksm_answer_meta';
		$has_legacy_meta = $this->table_exists( $legacy_meta );
		$copied = 0;
		foreach ( $rows as $row ) {
			$legacy_id = absint( $row['id'] ?? 0 );
			if ( ! $legacy_id ) { return new WP_Error( 'kerp_practice_legacy_invalid', 'یکی از پاسخ‌های قدیمی شناسهٔ معتبر ندارد.' ); }
			$metadata = [];
			if ( $has_legacy_meta ) {
				$logs = $this->legacy_sms_logs( $legacy_meta, $legacy_id );
				if ( $logs ) { $metadata[ KERP_Modules_Learning_Assignments_SMS::LOG_META_KEY ] = $logs; }
			}
			$encoded = wp_json_encode( $metadata );
			if ( ! is_string( $encoded ) ) { return new WP_Error( 'kerp_practice_legacy_encode', 'خواندن متای یکی از پاسخ‌های قدیمی ناموفق بود.' ); }
			$inserted = $wpdb->insert( $store->table(), [
				'legacy_id' => $legacy_id,
				'user_id' => absint( $row['user_id'] ?? 0 ),
				'item_id' => absint( $row['item_id'] ?? 0 ),
				'practice_id' => absint( $row['practice_id'] ?? 0 ),
				'status' => (string) ( $row['status'] ?? 'pending' ),
				'created_at' => (string) ( $row['created_at'] ?? current_time( 'mysql' ) ),
				'file_url' => (string) ( $row['file_url'] ?? '' ),
				'file_name' => (string) ( $row['file_name'] ?? '' ),
				'file_comment' => (string) ( $row['file_comment'] ?? '' ),
				'file_comment_url' => (string) ( $row['file_comment_url'] ?? '' ),
				'metadata' => $encoded,
			], [ '%d', '%d', '%d', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s' ] );
			if ( $inserted !== 1 ) {
				$already_copied = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$store->table()} WHERE legacy_id=%d LIMIT 1", $legacy_id ) );
				if ( ! $already_copied ) { return new WP_Error( 'kerp_practice_legacy_insert', sprintf( 'انتقال پاسخ قدیمی #%d ناموفق بود؛ دادهٔ قدیمی تغییری نکرد.', $legacy_id ) ); }
				continue;
			}
			$copied++;
		}
		return [ 'copied' => $copied ] + $this->status();
	}

	public function has_unmigrated_response( int $user_id, int $practice_id ): bool {
		if ( $user_id <= 0 || $practice_id <= 0 ) { return FALSE; }
		global $wpdb;
		$store = KERP_Modules_Learning_Assignments_Store::instance();
		$legacy = $store->legacy_table();
		if ( ! $this->table_exists( $legacy ) ) { return FALSE; }
		return (bool) $wpdb->get_var( $wpdb->prepare(
			"SELECT old.id FROM {$legacy} old LEFT JOIN {$store->table()} current_answers ON current_answers.legacy_id=old.id WHERE old.user_id=%d AND old.practice_id=%d AND current_answers.id IS NULL LIMIT 1",
			$user_id, $practice_id
		) );
	}

	public function has_unmigrated_for_item( int $user_id, int $item_id ): bool {
		if ( $user_id <= 0 || $item_id <= 0 ) { return FALSE; }
		global $wpdb;
		$store = KERP_Modules_Learning_Assignments_Store::instance();
		$legacy = $store->legacy_table();
		if ( ! $this->table_exists( $legacy ) ) { return FALSE; }
		return (bool) $wpdb->get_var( $wpdb->prepare(
			"SELECT old.id FROM {$legacy} old LEFT JOIN {$store->table()} current_answers ON current_answers.legacy_id=old.id WHERE old.user_id=%d AND old.item_id=%d AND current_answers.id IS NULL LIMIT 1",
			$user_id, $item_id
		) );
	}

	private function legacy_sms_logs( string $table, int $answer_id ): array {
		global $wpdb;
		$rows = (array) $wpdb->get_results( $wpdb->prepare(
			"SELECT meta_value,created_at FROM {$table} WHERE answer_id=%d AND meta_key=%s ORDER BY meta_id ASC",
			$answer_id, KERP_Modules_Learning_Assignments_SMS::LOG_META_KEY
		), ARRAY_A );
		$logs = [];
		foreach ( $rows as $row ) {
			$value = json_decode( (string) ( $row['meta_value'] ?? '' ), TRUE );
			if ( json_last_error() !== JSON_ERROR_NONE ) { continue; }
			$logs[] = [ 'created_at' => (string) $row['created_at'], 'value' => $value ];
		}
		return $logs;
	}

	private function table_exists( string $table ): bool {
		global $wpdb;
		return $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $table ) ) ) === $table;
	}
}
