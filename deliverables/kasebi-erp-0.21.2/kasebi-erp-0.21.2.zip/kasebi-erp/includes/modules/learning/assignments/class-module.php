<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Learning_Assignments_Module {
	
	public const POST_TYPE                   = 'sfwd-practice';
	
	public const CONNECTED_META              = 'sfwd_practice_connected_lesson';
	
	public const SMS_REJECTED_PATTERN_META   = '_kerp_practice_sms_rejected_pattern';
	
	public const SMS_REJECTED_VARIABLES_META = '_kerp_practice_sms_rejected_variables';
	
	public const SMS_UNLOCK_PATTERN_META     = '_kerp_practice_sms_unlock_pattern';
	
	public const SMS_UNLOCK_VARIABLES_META   = '_kerp_practice_sms_unlock_variables';
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		return self::$instance ??= new self();
	}
	
	private function __construct() {
		KERP_Modules_Learning_Assignments_Settings::instance();
		KERP_Modules_Learning_Assignments_SMS::instance();
		KERP_Modules_Learning_Assignments_Store::instance();
		add_action( 'init', [ $this, 'register_post_type' ], 21 );
		add_filter( 'kerp_app_pages', [ $this, 'pages' ], 49 );
		add_filter( 'kerp_employee_permission_groups', [ $this, 'permissions' ], 49 );
		add_filter( 'kerp_customer_profile_tabs', [ $this, 'customer_tab' ], 80, 3 );
		add_filter( 'nooshika_panel_tabs_list', [ $this, 'panel_tabs' ], 20, 2 );
		add_filter( 'nooshika_panel_get_template_path', [ $this, 'panel_template' ], 20, 2 );
		add_filter( 'nooshika_panel_can_mark_complete', [ $this, 'can_mark_complete' ], 20, 3 );
		add_filter( 'kerp_admin_bar_items', [ $this, 'admin_bar_items' ], 20 );
		add_action( 'kasebi_ajax_kerp_practice_save', [ $this, 'save_practice' ] );
		add_action( 'kasebi_ajax_kerp_practice_review', [ $this, 'review' ] );
		add_action( 'kasebi_ajax_kerp_practice_bulk', [ $this, 'bulk_action' ] );
		add_action( 'kasebi_ajax_kerp_practice_review_bulk', [ $this, 'bulk_review' ] );
		add_action( 'kasebi_ajax_kerp_practice_search_items', [ $this, 'search_items' ] );
		add_action( 'kasebi_ajax_kerp_practice_save_post_type_status', [ $this, 'save_post_type_status' ] );
		add_action( 'kasebi_ajax_kerp_practice_save_sms_defaults', [ $this, 'save_sms_defaults' ] );
		add_action( 'kasebi_ajax_kerp_practice_migrate_legacy', [ $this, 'migrate_legacy_responses' ] );
		add_action( 'nooshika_ajax_kerp_practice_submit', [ $this, 'submit' ] );
		add_action( 'nooshika_ajax_kerp_practice_upload', [ $this, 'upload_response_file' ] );
		add_action( 'nooshika_ajax_kerp_practice_discard_upload', [ $this, 'discard_response_file' ] );
		add_action( 'wp_enqueue_scripts', [ $this, 'panel_assets' ], 210 );
		add_action( 'wp_enqueue_scripts', [ $this, 'erp_assets' ], PHP_INT_MAX );
		if ( ! defined( 'KERP_MU_DOING_AJAX' ) || ! KERP_MU_DOING_AJAX ) {
			KERP_Helpers_Panel_Ajax::ensure_dependencies();
			$plugins  = (array) get_option( 'nooshika_ajax_active_plugins', [] );
			$required = [
				KERP_BASENAME,
				'sfwd-lms/sfwd_lms.php',
				'nooshika-panel/nooshika-panel.php',
				'nooshika-main/nooshika-main.php',
			];
			$updated  = array_values( array_unique( array_merge( $plugins, $required ) ) );
			if ( $updated !== $plugins ) {
				update_option( 'nooshika_ajax_active_plugins', $updated );
			}
		}
	}
	
	public function register_post_type(): void {
		if ( ! KERP_Modules_Learning_Assignments_Settings::instance()->post_type_enabled() ) {
			return;
		}
		if ( post_type_exists( self::POST_TYPE ) ) {
			return;
		}
		register_post_type( self::POST_TYPE, [
			'labels'              => [ 'name' => 'تمرین‌ها', 'singular_name' => 'تمرین' ],
			'public'              => FALSE,
			'publicly_queryable'  => FALSE,
			'show_ui'             => FALSE,
			'show_in_menu'        => FALSE,
			'show_in_rest'        => FALSE,
			'exclude_from_search' => TRUE,
			'supports'            => [ 'title', 'editor' ],
			'rewrite'             => FALSE,
		] );
	}
	
	public static function for_item( int $item_id ): array {
		if ( ! $item_id || ! KERP_Modules_Learning_Assignments_Settings::instance()->post_type_enabled() ) {
			return [];
		}
		
		return get_posts( [
			'post_type'      => self::POST_TYPE,
			'post_status'    => 'publish',
			'posts_per_page' => - 1,
			'meta_key'       => self::CONNECTED_META,
			'meta_value'     => $item_id,
			'orderby'        => 'menu_order title',
			'order'          => 'ASC',
		] );
	}
	
	public static function course_id_for_item( int $item_id ): int {
		if ( $item_id <= 0 ) {
			return 0;
		}
		$course_id = absint( get_post_meta( $item_id, 'course_id', TRUE ) );
		
		return $course_id ?: ( function_exists( 'learndash_get_course_id' ) ? absint( learndash_get_course_id( $item_id ) ) : 0 );
	}
	
	public static function lesson_id_for_topic( int $item_id ): int {
		if ( $item_id <= 0 || get_post_type( $item_id ) !== 'sfwd-topic' ) {
			return 0;
		}
		$lesson_id = absint( get_post_meta( $item_id, 'lesson_id', TRUE ) );
		
		return $lesson_id ?: ( function_exists( 'learndash_get_lesson_id' ) ? absint( learndash_get_lesson_id( $item_id ) ) : 0 );
	}
	
	public static function reviewer_name( array $response ): string {
		$metadata    = json_decode( (string) ( $response['metadata'] ?? '' ), TRUE );
		$reviewer_id = is_array( $metadata ) && is_scalar( $metadata['reviewer_id'] ?? NULL ) ? absint( $metadata['reviewer_id'] ) : 0;
		if ( ! $reviewer_id ) {
			return '';
		}
		$user = get_userdata( $reviewer_id );
		if ( ! $user instanceof WP_User ) {
			return '';
		}
		return trim( (string) get_user_name_by_id( $reviewer_id ) );
	}
	
	/**
	 * Shared review-table columns. Filter by key to add, remove or reorder columns.
	 * Each column accepts label, class, callback (row, column, context) and header_callback (column, context).
	 */
	public static function review_columns( array $context = [] ): array {
		$columns  = [
			'select'   => [ 'label' => '', 'class' => 'nk-tb-col-check' ],
			'customer' => [ 'label' => (string) ( $context['singular_label'] ?? 'مشتری' ) ],
			'practice' => [ 'label' => 'تمرین' ],
			'files'    => [ 'label' => 'فایل‌های پاسخ', 'class' => 'tb-col-md kerp-review-files-col' ],
			'result'   => [ 'label' => 'نتیجه' ],
			'tools'    => [ 'label' => '', 'class' => 'nk-tb-col-tools' ],
		];
		$filtered = apply_filters( 'kerp_learning_assignments_review_columns', $columns, $context );
		if ( ! is_array( $filtered ) ) {
			return $columns;
		}
		$columns = [];
		foreach ( $filtered as $key => $column ) {
			$key = sanitize_key( (string) $key );
			if ( $key !== '' && is_array( $column ) ) {
				$columns[ $key ] = $column;
			}
		}
		
		return $columns;
	}
	
	public function pages( array $pages ): array {
		$group                                              = [
			'key'   => 'learning',
			'title' => 'آموزش',
			'icon'  => 'uik-r fa-graduation-cap',
			'order' => 49,
		];
		$pages['learning-assignments']                      = [
			'title'      => 'تمرین‌ها',
			'route'      => 'learning-assignments',
			'type'       => 'page',
			'template'   => 'modules/learning-assignments/pages/practices.php',
			'permission' => 'learning_assignments.manage',
			'navigation' => [ 'group' => $group, 'icon' => 'uik-r fa-graduation-cap', 'order' => 10 ],
		];
		$pages['learning-assignment-reviews']               = [
			'title'      => 'بررسی پاسخ‌های تمرین',
			'route'      => 'learning-assignments/reviews',
			'type'       => 'page',
			'template'   => 'modules/learning-assignments/pages/reviews.php',
			'permission' => 'learning_assignments.review',
			'navigation' => [ 'group' => $group, 'icon' => 'ni ni-check-circle', 'order' => 20 ],
		];
		$settings_group                                     = [
			'key'        => 'settings',
			'title'      => 'تنظیمات',
			'icon'       => 'kik fa-settings-02',
			'order'      => 100,
			'sep_before' => TRUE,
		];
		$practice_settings_menu                             = [
			'key'   => 'learning-assignments-settings',
			'title' => 'تنظیمات تمرین',
			'icon'  => 'uik-r fa-graduation-cap',
			'order' => 70,
		];
		$pages['learning-assignment-post-type-settings']    = [
			'title'      => 'تنظیمات تمرین',
			'route'      => 'settings/learning-assignments/post-type',
			'type'       => 'settings',
			'template'   => 'modules/learning-assignments/settings/post-type.php',
			'permission' => 'learning_assignments.manage_settings',
			'navigation' => [
				'group' => $settings_group,
				'menu'  => $practice_settings_menu,
				'title' => 'وضعیت پست‌تایپ',
				'order' => 10,
			],
		];
		$pages['learning-assignment-sms-defaults-settings'] = [
			'title'      => 'پیامک پیش‌فرض تمرین',
			'route'      => 'settings/learning-assignments/sms-defaults',
			'type'       => 'settings',
			'template'   => 'modules/learning-assignments/settings/sms-defaults.php',
			'permission' => 'learning_assignments.manage_settings',
			'navigation' => [
				'group' => $settings_group,
				'menu'  => $practice_settings_menu,
				'title' => 'پیامک پیش‌فرض',
				'order' => 15,
			],
		];
		$pages['learning-assignment-migration-settings']    = [
			'title'      => 'انتقال پاسخ‌های تمرین',
			'route'      => 'settings/learning-assignments/migration',
			'type'       => 'settings',
			'template'   => 'modules/learning-assignments/settings/migration.php',
			'permission' => 'learning_assignments.manage_settings',
			'navigation' => [
				'group' => $settings_group,
				'menu'  => $practice_settings_menu,
				'title' => 'انتقال پاسخ‌های قدیمی',
				'order' => 20,
			],
		];
		
		return $pages;
	}
	
	public function permissions( array $groups ): array {
		$groups['learning'] = [
			'key'    => 'learning',
			'label'  => 'آموزش',
			'icon'   => 'uik-r fa-graduation-cap',
			'order'  => 49,
			'blocks' => [
				'learning_assignments' => [
					'key'         => 'learning_assignments',
					'label'       => 'تمرین‌ها',
					'icon'        => 'uik-r fa-graduation-cap',
					'order'       => 10,
					'permissions' => [
						'manage'   => [
							'key'   => 'learning_assignments.manage',
							'label' => 'ساخت و ویرایش تمرین',
							'type'  => 'action',
							'order' => 10,
						],
						'review'   => [
							'key'   => 'learning_assignments.review',
							'label' => 'بررسی پاسخ‌ها',
							'type'  => 'action',
							'order' => 20,
						],
						'settings' => [
							'key'   => 'learning_assignments.manage_settings',
							'label' => 'مدیریت تنظیمات تمرین',
							'type'  => 'action',
							'order' => 30,
						],
					],
				],
			],
		];
		
		return $groups;
	}
	
	public function customer_tab( array $tabs, int $customer_id, WP_User $customer ): array {
		if (
			! kerp_can( 'learning_assignments.review', 'action' )
			|| ! KERP_Modules_Learning_Assignments_Store::instance()->can_review_user( $customer_id )
		) {
			return $tabs;
		}
		$tabs['learning-assignments'] = [
			'key'        => 'learning-assignments',
			'title'      => 'تمرین‌ها',
			'icon'       => 'ni ni-file-text',
			'order'      => 85,
			'group'      => 'planning-learning',
			'permission' => 'learning_assignments.review',
			'action'     => 'action',
			'template'   => 'modules/learning-assignments/tabs/customer-practices.php',
		];
		
		return $tabs;
	}
	
	public function panel_tabs( array $tabs, int $post_id ): array {
		if ( in_array( get_post_type( $post_id ), [
				'sfwd-lessons',
				'sfwd-topic',
			], TRUE ) && self::for_item( $post_id ) ) {
			if ( get_current_user_id() ) {
				KERP_Modules_Learning_Assignments_Store::instance()->sync_progress( get_current_user_id(), $post_id );
			}
			$tabs['practices'] = [ 'label' => 'تمرین‌ها' ];
		}
		
		return $tabs;
	}
	
	public function panel_template( string $path, string $name ): string {
		return $name === 'item_tabs/practices' ? KERP_TEMPLATES_PATH . 'modules/learning-assignments/panel/practices.php' : $path;
	}
	
	public function can_mark_complete( bool $can, int $user_id, int $item_id ): bool {
		if ( ! $can ) {
			return FALSE;
		}
		foreach ( self::for_item( $item_id ) as $practice ) {
			if ( KERP_Modules_Learning_Assignments_Store::instance()
			                                            ->status( $user_id, (int) $practice->ID ) !== 'approved' ) {
				return FALSE;
			}
		}
		
		return TRUE;
	}
	
	public function admin_bar_items( array $items ): array {
		if ( ! isset( $items['orders'] ) || ! kerp_can( 'learning_assignments.review', 'action' ) ) {
			return $items;
		}
		
		$items['learning-assignment-reviews'] = [
			'title' => __( 'بررسی پاسخ‌ها', 'kasebi-erp' ),
			'url'   => '/erp/learning-assignments/reviews/',
		];
		
		return $items;
	}
	
	private function allowed_item( int $item_id ): bool {
		$post = get_post( $item_id );
		
		return $post instanceof WP_Post && in_array( $post->post_type, [
				'sfwd-lessons',
				'sfwd-topic',
			], TRUE ) && $post->post_status === 'publish';
	}
	
	private function manage_guard( string $permission ): void {
		if ( ! is_user_logged_in() || ! KERP_App::instance()
		                                        ->current_user_has_access() || ! kerp_can( $permission, 'action' ) ) {
			$this->ajax_error( 'دسترسی لازم را ندارید.' );
		}
	}
	
	private function active_guard(): void {
		if ( ! KERP_Modules_Learning_Assignments_Settings::instance()->post_type_enabled() ) {
			$this->ajax_error( 'پست‌تایپ تمرین غیرفعال است.' );
		}
	}
	
	public function save_post_type_status(): void {
		$this->manage_guard( 'learning_assignments.manage_settings' );
		$enabled = isset( $_POST['post_type_enabled'] ) && is_scalar( $_POST['post_type_enabled'] ) && (string) $_POST['post_type_enabled'] === '1';
		KERP_Modules_Learning_Assignments_Settings::instance()->save_post_type_enabled( $enabled );
		$this->ajax_success( 'وضعیت پست‌تایپ تمرین ذخیره شد.', '/erp/settings/learning-assignments/post-type/' );
	}
	
	public function save_sms_defaults(): void {
		$this->manage_guard( 'learning_assignments.manage_settings' );
		$nonce = isset( $_POST['sms_defaults_nonce'] ) && is_scalar( $_POST['sms_defaults_nonce'] ) ? sanitize_text_field( wp_unslash( (string) $_POST['sms_defaults_nonce'] ) ) : '';
		if ( ! wp_verify_nonce( $nonce, 'kerp_practice_save_sms_defaults' ) ) {
			$this->ajax_error( 'درخواست ذخیره‌سازی معتبر نیست.' );
		}
		KERP_Modules_Learning_Assignments_Settings::instance()->save_sms_defaults( $_POST );
		$this->ajax_success( 'پترن‌های پیش‌فرض تمرین ذخیره شدند.', '/erp/settings/learning-assignments/sms-defaults/' );
	}
	
	public function migrate_legacy_responses(): void {
		$this->manage_guard( 'learning_assignments.manage_settings' );
		$nonce = isset( $_POST['migration_nonce'] ) && is_scalar( $_POST['migration_nonce'] ) ? sanitize_text_field( wp_unslash( (string) $_POST['migration_nonce'] ) ) : '';
		if ( ! wp_verify_nonce( $nonce, 'kerp_practice_migrate_legacy' ) ) {
			$this->ajax_error( 'درخواست انتقال معتبر نیست.' );
		}
		$result = KERP_Modules_Learning_Assignments_Migration::instance()->migrate_batch();
		if ( is_wp_error( $result ) ) {
			$this->ajax_error( $result->get_error_message() );
		}
		wp_send_json( [
			'status'  => 'success',
			'message' => sprintf( '%d پاسخ منتقل شد؛ %d پاسخ باقی مانده است.', $result['copied'], $result['remaining'] ),
			'data'    => $result,
		] );
	}
	
	public function erp_assets(): void {
		if ( ! kerp_is_erp_request() ) {
			return;
		}
		wp_enqueue_style( 'kerp-practice-reviews', KERP_ASSETS_URL . 'app/css/practice-reviews.css', [], kerp_asset_version( 'app/css/practice-reviews.css' ) );
		wp_enqueue_script( 'kerp-practice-migration', KERP_ASSETS_URL . 'app/js/modules/practice-migration.js', [ 'kerp-app' ], kerp_asset_version( 'app/js/modules/practice-migration.js' ), TRUE );
	}
	
	private function ajax_error( string $message ): never {
		wp_send_json( [ 'status' => 'error', 'message' => $message, 'msg' => $message ] );
	}
	
	private function ajax_success( string $message, string $page ): never {
		wp_send_json( array_merge( [
			'status'  => 'success',
			'message' => $message,
			'msg'     => $message,
		], KERP_Api_Page_Content::build_page_response( $page, [], TRUE ) ) );
	}
	
	public function save_practice(): void {
		$this->manage_guard( 'learning_assignments.manage' );
		$this->active_guard();
		$id      = absint( $_POST['practice_id'] ?? 0 );
		$item_id = absint( $_POST['item_id'] ?? 0 );
		$title   = sanitize_text_field( wp_unslash( (string) ( $_POST['title'] ?? '' ) ) );
		$content = wp_kses_post( wp_unslash( (string) ( $_POST['content'] ?? '' ) ) );
		$status  = ( $_POST['post_status'] ?? '' ) === 'draft' ? 'draft' : 'publish';
		if ( ! $this->allowed_item( $item_id ) || $title === '' ) {
			$this->ajax_error( 'عنوان و درس/مبحث منتشرشده معتبر لازم است.' );
		}
		$previous = $id ? get_post( $id ) : NULL;
		if ( $id && ( ! $previous instanceof WP_Post || $previous->post_type !== self::POST_TYPE ) ) {
			$this->ajax_error( 'تمرین پیدا نشد.' );
		}
		if ( $id && KERP_Modules_Learning_Assignments_Store::instance()
		                                                   ->has_responses( $id ) && ( absint( get_post_meta( $id, self::CONNECTED_META, TRUE ) ) !== $item_id || $status !== 'publish' ) ) {
			$this->ajax_error( 'تمرینی که پاسخ دارد باید منتشرشده و متصل به همان درس بماند.' );
		}
		$post = [
			'post_type'    => self::POST_TYPE,
			'post_title'   => $title,
			'post_content' => $content,
			'post_status'  => $status,
		];
		if ( $id ) {
			$post['ID'] = $id;
		}
		$saved = $id ? wp_update_post( $post, TRUE ) : wp_insert_post( $post, TRUE );
		if ( is_wp_error( $saved ) ) {
			$this->ajax_error( $saved->get_error_message() );
		}
		update_post_meta( $saved, self::CONNECTED_META, $item_id );
		KERP_Modules_Learning_Assignments_SMS::instance()->save_practice_patterns( (int) $saved, $_POST );
		$this->ajax_success( 'تمرین ذخیره شد.', '/erp/learning-assignments/' );
	}
	
	public function review(): void {
		$this->manage_guard( 'learning_assignments.review' );
		$this->active_guard();
		$id         = absint( $_POST['response_id'] ?? 0 );
		$row        = KERP_Modules_Learning_Assignments_Store::instance()->response( $id );
		$status     = sanitize_key( (string) ( $_POST['status'] ?? '' ) );
		$comment    = sanitize_textarea_field( wp_unslash( (string) ( $_POST['comment'] ?? '' ) ) );
		$attachment = esc_url_raw( wp_unslash( (string) ( $_POST['attachment'] ?? '' ) ) );
		$this->review_one( $id, $status, $comment, $attachment );
		$this->ajax_success( 'نتیجهٔ بررسی ذخیره شد.', $this->review_return_page( (int) ( $row['user_id'] ?? 0 ) ) );
	}
	
	private function review_return_page( int $user_id ): string {
		$page = isset( $_POST['page'] ) && is_scalar( $_POST['page'] ) ? sanitize_text_field( wp_unslash( (string) $_POST['page'] ) ) : '';
		$query = (string) wp_parse_url( $page, PHP_URL_QUERY );
		parse_str( $query, $args );
		// Keep list filters separate from the review form's status and response ID.
		$filters = [];
		if ( isset( $args['status'] ) && is_scalar( $args['status'] ) && in_array( (string) $args['status'], [ 'all', 'pending', 'approved', 'rejected', 'changed' ], TRUE ) ) {
			$filters['status'] = (string) $args['status'];
		}
		foreach ( [ 'practice_id', 'user_id', 'per_page', 'page_number' ] as $key ) {
			if ( isset( $args[ $key ] ) && is_scalar( $args[ $key ] ) ) {
				$filters[ $key ] = absint( $args[ $key ] );
			}
		}
		if ( $user_id > 0 && preg_match( '~^/erp/customers/([0-9]+)/?(?:\?.*)?$~', $page, $matches ) && (int) $matches[1] === $user_id ) {
			if ( ( $args['tab'] ?? '' ) === 'learning-assignments' ) {
				unset( $filters['user_id'] );
				return add_query_arg( $filters, '/erp/customers/' . $user_id . '/?tab=learning-assignments' );
			}
		}
		if ( preg_match( '~^/erp/learning-assignments/reviews/?(?:\?.*)?$~', $page ) ) {
			return add_query_arg( $filters, '/erp/learning-assignments/reviews/' );
		}
		
		return '/erp/learning-assignments/reviews/';
	}
	
	private function review_one( int $id, string $status, string $comment, string $attachment = '' ): void {
		$store    = KERP_Modules_Learning_Assignments_Store::instance();
		$row      = $store->response( $id );
		$practice = $row ? get_post( (int) $row['practice_id'] ) : NULL;
		if ( ! $row || ! $store->can_review_user( (int) $row['user_id'] ) || $row['status'] === 'changed' || ! in_array( $status, [
				'approved',
				'rejected',
			], TRUE ) || ! $practice instanceof WP_Post || $practice->post_type !== self::POST_TYPE || absint( get_post_meta( $practice->ID, self::CONNECTED_META, TRUE ) ) !== (int) $row['item_id'] ) {
			$this->ajax_error( 'پاسخ یا وضعیت معتبر نیست.' );
		}
		if ( $status === 'rejected' && $comment === '' ) {
			$this->ajax_error( 'برای رد تمرین، دلیل را وارد کنید.' );
		}
		if ( $attachment === '' ) {
			$attachment = (string) ( $row['file_comment_url'] ?? '' );
		}
		$previous_status = (string) $row['status'];
		if ( ! $store->update_response( $id, $status, $comment, $attachment, get_current_user_id() ) ) {
			$this->ajax_error( 'ذخیره بررسی انجام نشد.' );
		}
		$item_approved  = $store->sync_progress( (int) $row['user_id'], (int) $row['item_id'] );
		$just_completed = $status === 'approved' && $previous_status !== 'approved' && $item_approved;
		KERP_Modules_Learning_Assignments_SMS::instance()
		                                     ->notify_review( $row, $previous_status, $status, $comment, $just_completed );
	}
	
	private function selected_ids(): array {
		$raw = $_POST['customer_ids'] ?? [];
		
		return array_slice( array_values( array_unique( array_filter( array_map( 'absint', is_array( $raw ) ? $raw : [] ) ) ) ), 0, 200 );
	}
	
	public function search_items(): void {
		$this->manage_guard( 'learning_assignments.manage' );
		$this->active_guard();
		$search = sanitize_text_field( wp_unslash( (string) ( $_POST['search'] ?? '' ) ) );
		if ( mb_strlen( $search ) < 2 ) {
			wp_send_json( [ 'status' => 'success', 'results' => [] ] );
		}
		$query   = new WP_Query( [
			'post_type'      => [ 'sfwd-lessons', 'sfwd-topic' ],
			'post_status'    => 'publish',
			's'              => $search,
			'posts_per_page' => 20,
			'no_found_rows'  => TRUE,
			'orderby'        => 'title',
			'order'          => 'ASC',
		] );
		$results = array_map( static fn( WP_Post $post ): array => [
			'id'   => $post->ID,
			'text' => $post->post_title . ' — ' . ( $post->post_type === 'sfwd-topic' ? 'مبحث' : 'درس' ),
		], $query->posts );
		wp_send_json( [ 'status' => 'success', 'results' => $results ] );
	}
	
	public function bulk_action(): void {
		$this->manage_guard( 'learning_assignments.manage' );
		$this->active_guard();
		$operation = sanitize_key( (string) ( $_POST['bulk_action'] ?? '' ) );
		$ids       = $this->selected_ids();
		if ( ! in_array( $operation, [ 'publish', 'draft' ], TRUE ) || ! $ids ) {
			$this->ajax_error( 'عملیات یا تمرین‌های انتخابی معتبر نیست.' );
		}
		foreach ( $ids as $id ) {
			$post = get_post( $id );
			if ( ! $post instanceof WP_Post || $post->post_type !== self::POST_TYPE || ( $operation === 'publish' && ! $this->allowed_item( absint( get_post_meta( $id, self::CONNECTED_META, TRUE ) ) ) ) || ( $operation === 'draft' && KERP_Modules_Learning_Assignments_Store::instance()
			                                                                                                                                                                                                                                                                     ->has_responses( $id ) ) ) {
				$this->ajax_error( 'یکی از تمرین‌ها معتبر نیست یا پاسخ ثبت‌شده دارد.' );
			}
		}
		foreach ( $ids as $id ) {
			$result = wp_update_post( [ 'ID' => $id, 'post_status' => $operation ], TRUE );
			if ( is_wp_error( $result ) ) {
				$this->ajax_error( $result->get_error_message() );
			}
		}
		$this->ajax_success( 'وضعیت تمرین‌های انتخابی تغییر کرد.', '/erp/learning-assignments/' );
	}
	
	public function bulk_review(): void {
		$this->manage_guard( 'learning_assignments.review' );
		$this->active_guard();
		$operation = sanitize_key( (string) ( $_POST['bulk_action'] ?? '' ) );
		$ids       = $this->selected_ids();
		$payload   = isset( $_POST['payload'] ) && is_array( $_POST['payload'] ) ? wp_unslash( $_POST['payload'] ) : [];
		$comment   = sanitize_textarea_field( (string) ( $payload['comment'] ?? '' ) );
		if ( ! in_array( $operation, [
				'approved',
				'rejected',
			], TRUE ) || ! $ids || ( $operation === 'rejected' && $comment === '' ) ) {
			$this->ajax_error( 'عملیات یا دلیل رد معتبر نیست.' );
		}
		$single_user_id = 0;
		$store = KERP_Modules_Learning_Assignments_Store::instance();
		foreach ( $ids as $id ) {
			$row      = $store->response( $id );
			$practice = $row ? get_post( (int) $row['practice_id'] ) : NULL;
			if ( ! $row || ! $store->can_review_user( (int) $row['user_id'] ) || $row['status'] === 'changed' || ! $practice instanceof WP_Post || $practice->post_type !== self::POST_TYPE || absint( get_post_meta( $practice->ID, self::CONNECTED_META, TRUE ) ) !== (int) $row['item_id'] ) {
				$this->ajax_error( 'یکی از پاسخ‌های انتخابی معتبر نیست.' );
			}
			if ( $single_user_id === 0 ) {
				$single_user_id = (int) $row['user_id'];
			} elseif ( $single_user_id !== (int) $row['user_id'] ) {
				$single_user_id = - 1;
			}
		}
		foreach ( $ids as $id ) {
			$this->review_one( $id, $operation, $comment );
		}
		$this->ajax_success( 'پاسخ‌های انتخابی بررسی شدند.', $this->review_return_page( $single_user_id ) );
	}
	
	public function panel_assets(): void {
		if ( ! is_page( 'panel' ) ) {
			return;
		}
		wp_enqueue_style( 'kerp-practices', KERP_ASSETS_URL . 'public/css/learning-assignments.css', [ 'nooshika_panel_styles' ], kerp_asset_version( 'public/css/learning-assignments.css' ) );
		wp_enqueue_script( 'kerp-practices', KERP_ASSETS_URL . 'public/js/learning-assignments.js', [ 'jquery' ], kerp_asset_version( 'public/js/learning-assignments.js' ), TRUE );
		wp_localize_script( 'kerp-practices', 'KERPPractices', [
			'ajaxUrl' => home_url( '/n-ajax' ),
			'nonce'   => wp_create_nonce( 'kerp_practice_submit' ),
		] );
	}
	
	public function submit(): void {
		if ( ! KERP_Modules_Learning_Assignments_Settings::instance()->post_type_enabled() ) {
			wp_send_json_error( 'تمرین‌ها غیرفعال هستند.', 403 );
		}
		if ( ! is_user_logged_in() ) {
			wp_send_json_error( 'ابتدا وارد شوید.', 403 );
		}
		$nonce = sanitize_text_field( wp_unslash( (string) ( $_POST['nonce'] ?? '' ) ) );
		if ( ! wp_verify_nonce( $nonce, 'kerp_practice_submit' ) ) {
			wp_send_json_error( 'درخواست نامعتبر است.', 403 );
		}
		$item_id     = absint( $_POST['item_id'] ?? 0 );
		$practice_id = absint( $_POST['practice_id'] ?? 0 );
		$user_id     = get_current_user_id();
		$error       = $this->submission_error( $item_id, $practice_id, $user_id );
		if ( $error ) {
			wp_send_json_error( $error->get_error_message(), (int) $error->get_error_data() );
		}
		$store           = KERP_Modules_Learning_Assignments_Store::instance();
		$previous_status = $store->status( $user_id, $practice_id );
		$raw_tokens      = $_POST['upload_tokens'] ?? [];
		if ( ! is_array( $raw_tokens ) || ! $raw_tokens || count( $raw_tokens ) > 100 ) {
			wp_send_json_error( 'فایل‌های آپلودشده معتبر نیستند.', 400 );
		}
		$tokens      = [];
		$urls        = [];
		$names       = [];
		$upload_meta = [];
		foreach ( $raw_tokens as $raw_token ) {
			if ( ! is_scalar( $raw_token ) ) {
				wp_send_json_error( 'فایل‌های آپلودشده معتبر نیستند.', 400 );
			}
			$token = sanitize_text_field( wp_unslash( (string) $raw_token ) );
			if ( $token === '' || in_array( $token, $tokens, TRUE ) ) {
				wp_send_json_error( 'فایل‌های آپلودشده معتبر نیستند.', 400 );
			}
			$uploaded = $this->staged_upload( $token, $user_id, $item_id, $practice_id );
			if ( is_wp_error( $uploaded ) ) {
				wp_send_json_error( $uploaded->get_error_message(), 400 );
			}
			$tokens[]      = $token;
			$urls[]        = esc_url_raw( $uploaded['url'] );
			$names[]       = sanitize_file_name( $uploaded['name'] );
			$upload_meta[] = [
				'storage'       => (string) ( $uploaded['storage'] ?? '' ),
				'original_name' => sanitize_file_name( (string) ( $uploaded['original_name'] ?? $uploaded['name'] ) ),
			];
		}
		if ( ! $store->add_response( $user_id, $item_id, $practice_id, count( $urls ) === 1 ? $urls[0] : $urls, count( $names ) === 1 ? $names[0] : $names, [
			'upload' => count( $upload_meta ) === 1 ? $upload_meta[0] : $upload_meta,
		] ) ) {
			wp_send_json_error( 'ثبت پاسخ انجام نشد.', 500 );
		}
		foreach ( $tokens as $token ) {
			delete_transient( $this->upload_transient_key( $token ) );
		}
		if ( $previous_status === 'rejected' ) {
			$store->supersede_rejected( $user_id, $practice_id );
		}
		$store->sync_progress( $user_id, $item_id );
		wp_send_json_success( [ 'message' => 'تمرین ارسال شد و در انتظار بررسی است.' ] );
	}
	
	public function upload_response_file(): void {
		if ( ! KERP_Modules_Learning_Assignments_Settings::instance()->post_type_enabled() || ! is_user_logged_in() ) {
			wp_send_json_error( 'دسترسی به آپلود تمرین ندارید.', 403 );
		}
		$nonce = sanitize_text_field( wp_unslash( (string) ( $_POST['nonce'] ?? '' ) ) );
		if ( ! wp_verify_nonce( $nonce, 'kerp_practice_submit' ) ) {
			wp_send_json_error( 'درخواست نامعتبر است.', 403 );
		}
		$item_id     = absint( $_POST['item_id'] ?? 0 );
		$practice_id = absint( $_POST['practice_id'] ?? 0 );
		$user_id     = get_current_user_id();
		$error       = $this->submission_error( $item_id, $practice_id, $user_id );
		if ( $error ) {
			wp_send_json_error( $error->get_error_message(), (int) $error->get_error_data() );
		}
		$file     = $_FILES['practice_file'] ?? NULL;
		$uploaded = is_array( $file ) ? $this->upload( $file ) : new WP_Error( 'missing_file', 'فایلی انتخاب نشده است.' );
		if ( is_wp_error( $uploaded ) ) {
			wp_send_json_error( $uploaded->get_error_message(), 400 );
		}
		$token                     = wp_generate_password( 40, FALSE, FALSE );
		$uploaded['original_name'] = sanitize_file_name( (string) $file['name'] );
		$uploaded['user_id']       = $user_id;
		$uploaded['item_id']       = $item_id;
		$uploaded['practice_id']   = $practice_id;
		if ( ! set_transient( $this->upload_transient_key( $token ), $uploaded, HOUR_IN_SECONDS ) ) {
			$this->delete_staged_file( $uploaded );
			wp_send_json_error( 'ثبت فایل آپلودشده انجام نشد.', 500 );
		}
		wp_send_json_success( [ 'token' => $token, 'name' => $uploaded['original_name'] ] );
	}
	
	public function discard_response_file(): void {
		if ( ! is_user_logged_in() ) {
			wp_send_json_error( 'دسترسی ندارید.', 403 );
		}
		$nonce = sanitize_text_field( wp_unslash( (string) ( $_POST['nonce'] ?? '' ) ) );
		if ( ! wp_verify_nonce( $nonce, 'kerp_practice_submit' ) ) {
			wp_send_json_error( 'درخواست نامعتبر است.', 403 );
		}
		$token    = sanitize_text_field( wp_unslash( (string) ( $_POST['upload_token'] ?? '' ) ) );
		$uploaded = get_transient( $this->upload_transient_key( $token ) );
		if ( ! is_array( $uploaded ) || (int) ( $uploaded['user_id'] ?? 0 ) !== get_current_user_id() ) {
			wp_send_json_error( 'فایل معتبر نیست.', 404 );
		}
		delete_transient( $this->upload_transient_key( $token ) );
		$this->delete_staged_file( $uploaded );
		wp_send_json_success();
	}
	
	private function delete_staged_file( array $uploaded ): void {
		if ( ( $uploaded['storage'] ?? '' ) === 'local' ) {
			$name = (string) ( $uploaded['name'] ?? '' );
			if ( $name !== '' && $name === wp_basename( $name ) ) {
				$upload_dir = wp_upload_dir();
				if ( empty( $upload_dir['error'] ) ) {
					wp_delete_file( trailingslashit( $upload_dir['basedir'] ) . 'learning-assignments/' . $name );
				}
			}
		}
	}
	
	private function upload_transient_key( string $token ): string {
		return 'kerp_practice_upload_' . hash( 'sha256', $token );
	}
	
	private function staged_upload( string $token, int $user_id, int $item_id, int $practice_id ): array|WP_Error {
		if ( $token === '' ) {
			return new WP_Error( 'missing_upload', 'ابتدا فایل تمرین را آپلود کنید.' );
		}
		$uploaded = get_transient( $this->upload_transient_key( $token ) );
		if ( ! is_array( $uploaded ) || (int) ( $uploaded['user_id'] ?? 0 ) !== $user_id || (int) ( $uploaded['item_id'] ?? 0 ) !== $item_id || (int) ( $uploaded['practice_id'] ?? 0 ) !== $practice_id || empty( $uploaded['url'] ) || empty( $uploaded['name'] ) ) {
			return new WP_Error( 'invalid_upload', 'آپلود فایل معتبر نیست یا زمان آن به پایان رسیده است؛ دوباره فایل را انتخاب کنید.' );
		}
		
		return $uploaded;
	}
	
	public static function profile_error( int $user_id ): ?WP_Error {
		$first_name = trim( sanitize_text_field( (string) get_user_meta( $user_id, 'first_name', TRUE ) ) );
		$last_name  = trim( sanitize_text_field( (string) get_user_meta( $user_id, 'last_name', TRUE ) ) );
		if ( $first_name === '' || $last_name === '' || $first_name === 'کاربر' ) {
			return new WP_Error( 'incomplete_profile', 'برای ارسال تمرین، لطفاً نام و نام خانوادگی واقعی خود را در بخش «پروفایل من» تکمیل کنید. نام «کاربر» قابل قبول نیست.', 400 );
		}
		
		return NULL;
	}
	
	private function submission_error( int $item_id, int $practice_id, int $user_id ): ?WP_Error {
		$profile_error = self::profile_error( $user_id );
		if ( $profile_error ) {
			return $profile_error;
		}
		$practice = get_post( $practice_id );
		if ( ! $this->allowed_item( $item_id ) || ! $practice instanceof WP_Post || $practice->post_type !== self::POST_TYPE || $practice->post_status !== 'publish' || absint( get_post_meta( $practice_id, self::CONNECTED_META, TRUE ) ) !== $item_id ) {
			return new WP_Error( 'invalid_practice', 'تمرین معتبر نیست.', 400 );
		}
		if ( KERP_Modules_Learning_Assignments_Migration::instance()
		                                                ->has_unmigrated_response( $user_id, $practice_id ) ) {
			return new WP_Error( 'migration_pending', 'پاسخ‌های قبلی این تمرین هنوز به سامانهٔ جدید منتقل نشده‌اند.', 409 );
		}
		$course_id = function_exists( 'learndash_get_course_id' ) ? absint( learndash_get_course_id( $item_id ) ) : 0;
		if ( ! $course_id || ! function_exists( 'sfwd_lms_has_access' ) || ! sfwd_lms_has_access( $course_id, $user_id ) || ( function_exists( 'ld_lesson_access_from' ) && ld_lesson_access_from( get_post_type( $item_id ) === 'sfwd-topic' ? absint( get_post_meta( $item_id, 'lesson_id', TRUE ) ) : $item_id, $user_id ) ) || ( function_exists( 'check_pre_step_is_complete' ) && ! check_pre_step_is_complete( $item_id ) ) ) {
			return new WP_Error( 'no_access', 'به این درس دسترسی ندارید.', 403 );
		}
		$status = KERP_Modules_Learning_Assignments_Store::instance()->status( $user_id, $practice_id );
		if ( $status === 'approved' || $status === 'pending' ) {
			return new WP_Error( 'already_sent', 'این تمرین قبلاً ارسال شده و در انتظار نتیجه است.', 400 );
		}
		
		return NULL;
	}
	
	private function upload( array $file ): array|WP_Error {
		if ( (int) ( $file['error'] ?? UPLOAD_ERR_NO_FILE ) !== UPLOAD_ERR_OK || (int) ( $file['size'] ?? 0 ) < 1 || (int) ( $file['size'] ?? 0 ) > 20 * 1024 * 1024 ) {
			return new WP_Error( 'invalid_file', 'فایل معتبر با حجم حداکثر ۲۰ مگابایت انتخاب کنید.' );
		}
		$result = KERP_Helpers_File::instance()
		                           ->handle_upload_file( wp_unslash( $file ), 'learning-assignments', [ 'direct' => TRUE ] );
		
		return ! empty( $result['ok'] ) && ! empty( $result['url'] ) && ! empty( $result['name'] )
			? $result
			: new WP_Error( 'upload_failed', (string) ( $result['msg'] ?? 'بارگذاری فایل انجام نشد.' ) );
	}
	
}
