<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Learning_Assignments_File_Availability {
	public static function resolve_url( string $url ): string {
		$url = trim( $url );
		if ( $url === '' ) {
			return '';
		}

		if ( wp_http_validate_url( $url ) ) {
			return $url;
		}

		if ( str_starts_with( $url, '//' ) ) {
			return ( is_ssl() ? 'https:' : 'http:' ) . $url;
		}

		if ( str_starts_with( $url, '/' ) ) {
			return home_url( $url );
		}

		$uploads = wp_upload_dir();
		if ( empty( $uploads['error'] ) && ! empty( $uploads['baseurl'] ) ) {
			$base_path = ltrim( (string) ( wp_parse_url( (string) $uploads['baseurl'], PHP_URL_PATH ) ?? '' ), '/' );
			if ( $base_path !== '' && str_starts_with( ltrim( $url, '/' ), trailingslashit( $base_path ) ) ) {
				return home_url( '/' . ltrim( $url, '/' ) );
			}
			return trailingslashit( (string) $uploads['baseurl'] ) . ltrim( $url, '/' );
		}

		return '';
	}

	public static function is_available( string $url ): bool {
		$url = self::resolve_url( $url );
		$parts = wp_parse_url( $url );
		if ( ! is_array( $parts ) || ! in_array( strtolower( (string) ( $parts['scheme'] ?? '' ) ), [ 'http', 'https' ], TRUE ) || empty( $parts['host'] ) || empty( $parts['path'] ) ) {
			return FALSE;
		}

		$uploads = wp_upload_dir();
		$base_url = wp_parse_url( (string) ( $uploads['baseurl'] ?? '' ) );
		if ( empty( $uploads['error'] ) && is_array( $base_url ) && ! empty( $uploads['basedir'] ) && self::same_origin( $parts, $base_url ) ) {
			$base_path = rtrim( (string) ( $base_url['path'] ?? '' ), '/' );
			$prefix = $base_path . '/';
			$path = (string) $parts['path'];
			if ( str_starts_with( $path, $prefix ) ) {
				return self::local_file_exists( (string) $uploads['basedir'], substr( $path, strlen( $prefix ) ) );
			}
		}

		return self::remote_url_works( $url );
	}

	private static function same_origin( array $url, array $base ): bool {
		return strcasecmp( (string) ( $url['host'] ?? '' ), (string) ( $base['host'] ?? '' ) ) === 0
			&& (int) ( $url['port'] ?? 0 ) === (int) ( $base['port'] ?? 0 );
	}

	private static function local_file_exists( string $basedir, string $encoded_relative ): bool {
		$relative = rawurldecode( $encoded_relative );
		if ( $relative === '' || str_contains( $relative, '\\' ) || str_contains( $relative, "\0" ) ) { return FALSE; }
		$segments = explode( '/', $relative );
		if ( array_filter( $segments, static fn( string $segment ): bool => $segment === '' || $segment === '.' || $segment === '..' ) ) { return FALSE; }

		$base = realpath( $basedir );
		if ( $base === FALSE ) { return FALSE; }
		$path = realpath( $base . DIRECTORY_SEPARATOR . implode( DIRECTORY_SEPARATOR, $segments ) );
		if ( $path === FALSE ) { return FALSE; }
		$base_normalized = rtrim( str_replace( '\\', '/', $base ), '/' ) . '/';
		$path_normalized = str_replace( '\\', '/', $path );
		return str_starts_with( strtolower( $path_normalized ), strtolower( $base_normalized ) ) && is_file( $path ) && is_readable( $path );
	}

	private static function remote_url_works( string $url ): bool {
		$cache_key = 'kerp_practice_file_availability_' . md5( $url );
		$cached = get_transient( $cache_key );
		if ( $cached === 'available' ) { return TRUE; }
		if ( $cached === 'missing' ) { return FALSE; }

		$args = [ 'timeout' => 3, 'redirection' => 3 ];
		$response = wp_safe_remote_head( $url, $args );
		$code = is_wp_error( $response ) ? 0 : (int) wp_remote_retrieve_response_code( $response );
		if ( in_array( $code, [ 405, 501 ], TRUE ) ) {
			$response = wp_safe_remote_get( $url, $args + [
				'headers' => [ 'Range' => 'bytes=0-0' ],
				'limit_response_size' => 1,
			] );
			$code = is_wp_error( $response ) ? 0 : (int) wp_remote_retrieve_response_code( $response );
		}
		$available = $code >= 200 && $code < 300;
		if ( $available ) {
			$content_type = strtolower( (string) wp_remote_retrieve_header( $response, 'content-type' ) );
			$available = ! str_contains( $content_type, 'text/html' );
		}
		set_transient( $cache_key, $available ? 'available' : 'missing', 15 * MINUTE_IN_SECONDS );
		return $available;
	}
}
