<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Learning_Assignments_Settings {
	private const STATUS_OPTION = 'kerp_learning_assignments_post_type_enabled';
	private const SMS_DEFAULTS_OPTION = 'kerp_learning_assignments_sms_defaults';
	private static ?self $instance = NULL;

	public static function instance(): self { return self::$instance ??= new self(); }
	private function __construct() {}

	public function post_type_enabled(): bool {
		return get_option( self::STATUS_OPTION, '1' ) === '1';
	}

	public function save_post_type_enabled( bool $enabled ): void {
		update_option( self::STATUS_OPTION, $enabled ? '1' : '0', FALSE );
	}

	public function sms_defaults(): array {
		$stored = get_option( self::SMS_DEFAULTS_OPTION, [] );
		$stored = is_array( $stored ) ? $stored : [];
		return [
			'rejected_pattern' => (string) ( $stored['rejected_pattern'] ?? '' ),
			'rejected_variables' => (string) ( $stored['rejected_variables'] ?? '' ),
			'unlock_pattern' => (string) ( $stored['unlock_pattern'] ?? '' ),
			'unlock_variables' => (string) ( $stored['unlock_variables'] ?? '' ),
		];
	}

	public function save_sms_defaults( array $input ): void {
		$defaults = [];
		foreach ( [ 'rejected_pattern', 'rejected_variables', 'unlock_pattern', 'unlock_variables' ] as $key ) {
			$raw = $input[ $key ] ?? '';
			$value = is_scalar( $raw ) ? (string) wp_unslash( $raw ) : '';
			$defaults[ $key ] = str_ends_with( $key, '_variables' ) ? sanitize_textarea_field( $value ) : sanitize_text_field( $value );
		}
		update_option( self::SMS_DEFAULTS_OPTION, $defaults, FALSE );
	}

}
