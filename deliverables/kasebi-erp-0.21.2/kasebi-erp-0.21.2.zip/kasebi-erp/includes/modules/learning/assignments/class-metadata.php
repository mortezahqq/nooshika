<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Learning_Assignments_Metadata {
	public static function render( array $response ): string {
		$metadata = json_decode( (string) ( $response['metadata'] ?? '' ), TRUE );
		if ( ! is_array( $metadata ) || ! $metadata ) {
			return '<p class="text-soft mb-0">متایی برای این پاسخ ثبت نشده است.</p>';
		}

		$html = '<div class="kerp-review-meta">';
		$handled = [];
		$upload = $metadata['upload'] ?? NULL;
		if ( is_array( $upload ) && $upload ) {
			$handled[] = 'upload';
			$files = isset( $upload['original_name'] ) ? [ $upload ] : $upload;
			$html .= '<section class="kerp-review-meta__section"><h6>فایل‌های آپلودشده</h6>';
			foreach ( $files as $index => $file ) {
				if ( ! is_array( $file ) ) { continue; }
				$html .= '<div class="kerp-review-meta__group"><strong>فایل ' . esc_html( (string) ( (int) $index + 1 ) ) . '</strong>';
				foreach ( $file as $key => $value ) {
					$html .= self::field( self::label( (string) $key ), $value );
				}
				$html .= '</div>';
			}
			$html .= '</section>';
		}

		$reviewer_id = is_scalar( $metadata['reviewer_id'] ?? NULL ) ? absint( $metadata['reviewer_id'] ) : 0;
		$reviewed_at = is_scalar( $metadata['reviewed_at'] ?? NULL ) ? (string) $metadata['reviewed_at'] : '';
		if ( $reviewer_id || $reviewed_at !== '' ) {
			$handled[] = 'reviewer_id';
			$handled[] = 'reviewed_at';
			$html .= '<section class="kerp-review-meta__section"><h6>بررسی پاسخ</h6>';
			if ( $reviewer_id ) {
				$name = KERP_Modules_Learning_Assignments_Module::reviewer_name( $response );
				$html .= self::field( 'بررسی‌کننده', $name !== '' ? $name . ' (#' . $reviewer_id . ')' : 'کاربر حذف‌شده (#' . $reviewer_id . ')' );
			}
			if ( $reviewed_at !== '' ) {
				$timestamp = strtotime( $reviewed_at );
				$html .= self::field( 'زمان بررسی', $timestamp ? date_i18n( 'Y/m/d H:i', $timestamp ) : $reviewed_at );
			}
			$html .= '</section>';
		}

		$logs = $metadata[ KERP_Modules_Learning_Assignments_SMS::LOG_META_KEY ] ?? NULL;
		if ( is_array( $logs ) && $logs ) {
			$handled[] = KERP_Modules_Learning_Assignments_SMS::LOG_META_KEY;
			$html .= '<section class="kerp-review-meta__section"><h6>گزارش ارسال پیامک</h6>';
			foreach ( $logs as $index => $entry ) {
				if ( ! is_array( $entry ) ) { continue; }
				$html .= '<div class="kerp-review-meta__group"><strong>ارسال ' . esc_html( (string) ( (int) $index + 1 ) ) . '</strong>';
				if ( is_scalar( $entry['created_at'] ?? NULL ) && (string) $entry['created_at'] !== '' ) {
					$created_at = (string) $entry['created_at'];
					$timestamp = strtotime( $created_at );
					$html .= self::field( 'زمان ثبت', $timestamp ? date_i18n( 'Y/m/d H:i', $timestamp ) : $created_at );
				}
				$value = isset( $entry['value'] ) && is_array( $entry['value'] ) ? $entry['value'] : $entry;
				foreach ( $value as $key => $item ) {
					if ( $key === 'created_at' ) { continue; }
					$html .= self::field( $key === 'status' ? 'وضعیت ارسال' : self::label( (string) $key ), self::translated_value( (string) $key, $item ) );
				}
				$html .= '</div>';
			}
			$html .= '</section>';
		}

		$other = array_diff_key( $metadata, array_flip( $handled ) );
		if ( $other ) {
			$html .= '<section class="kerp-review-meta__section"><h6>سایر اطلاعات</h6>';
			foreach ( $other as $key => $value ) {
				$html .= self::field( self::label( (string) $key ), self::translated_value( (string) $key, $value ) );
			}
			$html .= '</section>';
		}

		return $html . '</div>';
	}

	private static function field( string $label, mixed $value, int $depth = 0 ): string {
		$html = '<div class="kerp-review-meta__field"><span>' . esc_html( $label ) . '</span><div>';
		if ( is_array( $value ) ) {
			if ( $depth >= 6 ) {
				$html .= '<span class="text-soft">جزئیات بیشتر قابل نمایش نیست.</span>';
			} elseif ( ! $value ) {
				$html .= '<span class="text-soft">—</span>';
			} else {
				$html .= '<div class="kerp-review-meta__nested">';
				foreach ( $value as $key => $item ) {
					$nested_label = is_int( $key ) ? 'مورد ' . ( $key + 1 ) : self::label( (string) $key );
					$html .= self::field( $nested_label, self::translated_value( (string) $key, $item ), $depth + 1 );
				}
				$html .= '</div>';
			}
		} elseif ( is_bool( $value ) ) {
			$html .= esc_html( $value ? 'بله' : 'خیر' );
		} elseif ( $value === NULL || $value === '' ) {
			$html .= '<span class="text-soft">—</span>';
		} else {
			$html .= esc_html( (string) $value );
		}
		return $html . '</div></div>';
	}

	private static function translated_value( string $key, mixed $value ): mixed {
		if ( preg_match( '/token|secret|password|api[_-]?key|authorization/i', $key ) ) { return 'پنهان‌شده'; }
		if ( ! is_scalar( $value ) ) { return $value; }
		return match ( $key ) {
			'event' => [ 'rejected' => 'رد پاسخ', 'unlock' => 'باز شدن درس بعدی' ][ (string) $value ] ?? $value,
			'status' => [ 'failed' => 'ناموفق', 'returned' => 'پاسخ از پنل دریافت شد' ][ (string) $value ] ?? $value,
			'storage' => [ 'local' => 'فضای ذخیره‌سازی سایت' ][ (string) $value ] ?? $value,
			default => $value,
		};
	}

	private static function label( string $key ): string {
		$labels = [
			'original_name' => 'نام اصلی فایل', 'storage' => 'محل ذخیره‌سازی',
			'reviewer_id' => 'شناسه بررسی‌کننده', 'reviewed_at' => 'زمان بررسی',
			'event' => 'رویداد', 'status' => 'وضعیت', 'pattern' => 'پترن پیامک',
			'receptor' => 'شماره گیرنده', 'provider_response' => 'پاسخ پنل پیامکی',
			'message' => 'پیام', 'code' => 'کد', 'type' => 'نوع', 'data' => 'داده',
			'id' => 'شناسه', 'messageid' => 'شناسه پیامک', 'message_id' => 'شناسه پیامک',
			'success' => 'موفق', 'error' => 'خطا', 'details' => 'جزئیات',
			'date' => 'تاریخ', 'cost' => 'هزینه', 'sender' => 'فرستنده',
			'statusText' => 'شرح وضعیت', 'status_text' => 'شرح وضعیت',
		];
		return $labels[ $key ] ?? trim( str_replace( [ '_', '-' ], ' ', $key ) );
	}
}
