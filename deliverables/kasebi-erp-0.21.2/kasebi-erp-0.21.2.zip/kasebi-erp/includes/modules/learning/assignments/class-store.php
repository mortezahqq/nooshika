<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Learning_Assignments_Store {
	private const VERSION = '2.0.0';
	private const VERSION_OPTION = 'kerp_learning_assignments_db_version';
	private static ?self $instance = NULL;

	public static function instance(): self { return self::$instance ??= new self(); }
	private function __construct() { $this->maybe_install(); }

	public function table(): string { global $wpdb; return $wpdb->prefix . 'kerp_practice_answers'; }
	public function legacy_table(): string { global $wpdb; return $wpdb->prefix . 'ksm_answers'; }

	private function maybe_install(): void {
		if ( get_option( self::VERSION_OPTION ) === self::VERSION ) { return; }
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$table = $this->table();
		$charset = $wpdb->get_charset_collate();
		dbDelta( "CREATE TABLE {$table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			legacy_id bigint(20) unsigned NULL,
			user_id bigint(20) unsigned NOT NULL,
			item_id bigint(20) unsigned NOT NULL,
			practice_id bigint(20) unsigned NOT NULL,
			status varchar(20) NOT NULL DEFAULT 'pending',
			created_at datetime NOT NULL,
			file_url text NOT NULL,
			file_name text NOT NULL,
			file_comment longtext NULL,
			file_comment_url text NULL,
			metadata longtext NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY legacy_id (legacy_id),
			KEY user_practice (user_id,practice_id),
			KEY status_created (status,created_at),
			KEY item_id (item_id)
		) {$charset};" );
		update_option( self::VERSION_OPTION, self::VERSION, FALSE );
	}

	public function add_response_meta( int $response_id, string $key, mixed $value ): bool {
		$key = sanitize_key( $key );
		if ( $response_id <= 0 || $key === '' ) { return FALSE; }
		global $wpdb;
		$row = $this->response( $response_id );
		if ( ! $row ) { return FALSE; }
		$meta = $this->decode_metadata( $row['metadata'] ?? '' );
		$meta[ $key ] = isset( $meta[ $key ] ) && is_array( $meta[ $key ] ) ? $meta[ $key ] : [];
		$meta[ $key ][] = [ 'created_at' => current_time( 'mysql' ), 'value' => $value ];
		$encoded = wp_json_encode( $meta );
		return is_string( $encoded ) && $wpdb->update( $this->table(), [ 'metadata' => $encoded ], [ 'id' => $response_id ], [ '%s' ], [ '%d' ] ) !== FALSE;
	}

	public function response_meta( int $response_id, string $key ): array {
		$key = sanitize_key( $key );
		if ( $response_id <= 0 || $key === '' ) { return []; }
		$row = $this->response( $response_id );
		$meta = $this->decode_metadata( $row['metadata'] ?? '' );
		return isset( $meta[ $key ] ) && is_array( $meta[ $key ] ) ? $meta[ $key ] : [];
	}

	private function decode_metadata( mixed $value ): array {
		$decoded = is_string( $value ) ? json_decode( $value, TRUE ) : NULL;
		return is_array( $decoded ) ? $decoded : [];
	}

	public function responses( int $user_id = 0, int $practice_id = 0, string $status = '', int $limit = 50, int $offset = 0, bool $enforce_customer_scope = FALSE ): array {
		global $wpdb;
		$where = [ '1=1' ];
		$args = [];
		if ( $user_id ) { $where[] = 'user_id=%d'; $args[] = $user_id; }
		if ( $practice_id ) { $where[] = 'practice_id=%d'; $args[] = $practice_id; }
		if ( in_array( $status, [ 'pending', 'approved', 'rejected', 'changed' ], TRUE ) ) { $where[] = 'status=%s'; $args[] = $status; }
		if ( $enforce_customer_scope ) { $this->append_customer_scope( $where, $args ); }
		$args[] = max( 1, min( 200, $limit ) );
		$args[] = max( 0, $offset );
		$sql = "SELECT * FROM {$this->table()} AS responses WHERE " . implode( ' AND ', $where ) . ' ORDER BY created_at DESC,id DESC LIMIT %d OFFSET %d';
		return (array) $wpdb->get_results( $wpdb->prepare( $sql, $args ), ARRAY_A );
	}

	public function count_responses( int $user_id = 0, int $practice_id = 0, string $status = '', bool $enforce_customer_scope = FALSE ): int {
		global $wpdb;
		$where = [ '1=1' ]; $args = [];
		if ( $user_id ) { $where[] = 'user_id=%d'; $args[] = $user_id; }
		if ( $practice_id ) { $where[] = 'practice_id=%d'; $args[] = $practice_id; }
		if ( in_array( $status, [ 'pending', 'approved', 'rejected', 'changed' ], TRUE ) ) { $where[] = 'status=%s'; $args[] = $status; }
		if ( $enforce_customer_scope ) { $this->append_customer_scope( $where, $args ); }
		$sql = "SELECT COUNT(*) FROM {$this->table()} AS responses WHERE " . implode( ' AND ', $where );
		return (int) $wpdb->get_var( $args ? $wpdb->prepare( $sql, $args ) : $sql );
	}

	public function review_practice_ids( int $user_id = 0, bool $enforce_customer_scope = TRUE ): array {
		global $wpdb;
		$where = [ '1=1' ];
		$args  = [];
		if ( $user_id > 0 ) {
			$where[] = 'responses.user_id=%d';
			$args[]  = $user_id;
		}
		if ( $enforce_customer_scope ) {
			$this->append_customer_scope( $where, $args );
		}
		$sql = "SELECT DISTINCT responses.practice_id FROM {$this->table()} AS responses WHERE " . implode( ' AND ', $where );
		$ids = $args ? $wpdb->get_col( $wpdb->prepare( $sql, $args ) ) : $wpdb->get_col( $sql );

		return array_values( array_unique( array_filter( array_map( 'absint', (array) $ids ) ) ) );
	}

	public function can_review_user( int $user_id ): bool {
		if ( $user_id <= 0 ) { return FALSE; }
		$scope = kerp_list_scope( 'customers' );
		if ( $scope === 'all' ) { return get_userdata( $user_id ) instanceof WP_User; }
		if ( ! in_array( $scope, [ 'own', 'team' ], TRUE ) ) { return FALSE; }
		$owner_key = (string) KERP_Modules_Customers_Settings::instance()->get( 'owner_meta_key', 'kerp_customer_owner_id' );

		return absint( get_user_meta( $user_id, $owner_key, TRUE ) ) === get_current_user_id();
	}

	private function append_customer_scope( array &$where, array &$args ): void {
		$scope = kerp_list_scope( 'customers' );
		if ( $scope === 'all' ) { return; }
		if ( ! in_array( $scope, [ 'own', 'team' ], TRUE ) ) {
			$where[] = '1=0';
			return;
		}
		global $wpdb;
		$owner_key = (string) KERP_Modules_Customers_Settings::instance()->get( 'owner_meta_key', 'kerp_customer_owner_id' );
		$where[] = "EXISTS (SELECT 1 FROM {$wpdb->usermeta} AS customer_scope WHERE customer_scope.user_id=responses.user_id AND customer_scope.meta_key=%s AND customer_scope.meta_value=%s)";
		$args[] = $owner_key;
		$args[] = (string) get_current_user_id();
	}

	public function response( int $id ): ?array {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$this->table()} WHERE id=%d", $id ), ARRAY_A );
		return is_array( $row ) ? $row : NULL;
	}

	public function has_responses( int $practice_id ): bool {
		global $wpdb;
		return (bool) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$this->table()} WHERE practice_id=%d LIMIT 1", $practice_id ) );
	}

	public function add_response( int $user_id, int $item_id, int $practice_id, string|array $url, string|array $name, array $metadata = [] ): int|false {
		global $wpdb;
		$encoded = wp_json_encode( $metadata );
		if ( ! is_string( $encoded ) ) { return FALSE; }
		$inserted = $wpdb->insert( $this->table(), [
			'user_id' => $user_id, 'item_id' => $item_id, 'practice_id' => $practice_id,
			'status' => 'pending', 'created_at' => current_time( 'mysql' ),
			'file_url' => maybe_serialize( $url ), 'file_name' => maybe_serialize( $name ), 'file_comment' => '', 'file_comment_url' => '', 'metadata' => $encoded,
		], [ '%d', '%d', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s' ] );
		return $inserted === 1 ? (int) $wpdb->insert_id : FALSE;
	}

	public function update_response( int $id, string $status, string $comment, string $attachment, int $reviewer_id ): bool {
		if ( $reviewer_id <= 0 ) { return FALSE; }
		$row = $this->response( $id );
		if ( ! $row ) { return FALSE; }
		$metadata = $this->decode_metadata( $row['metadata'] ?? '' );
		$metadata['reviewer_id'] = $reviewer_id;
		$metadata['reviewed_at'] = current_time( 'mysql' );
		$encoded = wp_json_encode( $metadata );
		if ( ! is_string( $encoded ) ) { return FALSE; }
		global $wpdb;
		return $wpdb->update( $this->table(), [ 'status' => $status, 'file_comment' => $comment, 'file_comment_url' => $attachment, 'metadata' => $encoded ], [ 'id' => $id ], [ '%s', '%s', '%s', '%s' ], [ '%d' ] ) !== FALSE;
	}

	public function supersede_rejected( int $user_id, int $practice_id ): void {
		global $wpdb;
		$wpdb->update( $this->table(), [ 'status' => 'changed' ], [ 'user_id' => $user_id, 'practice_id' => $practice_id, 'status' => 'rejected' ], [ '%s' ], [ '%d', '%d', '%s' ] );
	}

	public function status( int $user_id, int $practice_id ): string {
		global $wpdb;
		$statuses = (array) $wpdb->get_col( $wpdb->prepare(
			"SELECT status FROM {$this->table()} WHERE user_id=%d AND practice_id=%d AND status<>'changed'",
			$user_id, $practice_id
		) );
		if ( ! $statuses ) { return ''; }
		if ( in_array( 'pending', $statuses, TRUE ) ) { return 'pending'; }
		if ( in_array( 'rejected', $statuses, TRUE ) ) { return 'rejected'; }
		return count( array_diff( $statuses, [ 'approved' ] ) ) === 0 ? 'approved' : '';
	}

	public function sync_progress( int $user_id, int $item_id ): bool {
		if ( KERP_Modules_Learning_Assignments_Migration::instance()->has_unmigrated_for_item( $user_id, $item_id ) ) { return FALSE; }
		$practices = KERP_Modules_Learning_Assignments_Module::for_item( $item_id );
		if ( ! $practices ) { return FALSE; }
		$all_approved = TRUE;
		foreach ( $practices as $practice ) {
			$status = $this->status( $user_id, (int) $practice->ID );
			update_user_meta( $user_id, 'practice_status_' . $practice->ID, $status );
			if ( $status !== 'approved' ) { $all_approved = FALSE; }
		}
		if ( $all_approved && function_exists( 'learndash_process_mark_complete' ) ) {
			learndash_process_mark_complete( $user_id, $item_id );
		} elseif ( ! $all_approved && function_exists( 'learndash_process_mark_incomplete' ) && function_exists( 'learndash_get_course_id' ) ) {
			$course_id = absint( learndash_get_course_id( $item_id ) );
			if ( $course_id ) { learndash_process_mark_incomplete( $user_id, $course_id, $item_id ); }
		}
		return $all_approved;
	}
}
