<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Learning_Assignments_SMS {
	public const LOG_META_KEY = 'sms_send_log';
	private static ?self $instance = NULL;
	private ?object $service = NULL;

	public static function instance(): self { return self::$instance ??= new self(); }
	private function __construct() {}

	public function save_practice_patterns( int $practice_id, array $input ): void {
		foreach ( [
			'sms_rejected_pattern' => KERP_Modules_Learning_Assignments_Module::SMS_REJECTED_PATTERN_META,
			'sms_unlock_pattern' => KERP_Modules_Learning_Assignments_Module::SMS_UNLOCK_PATTERN_META,
			'sms_rejected_variables' => KERP_Modules_Learning_Assignments_Module::SMS_REJECTED_VARIABLES_META,
			'sms_unlock_variables' => KERP_Modules_Learning_Assignments_Module::SMS_UNLOCK_VARIABLES_META,
		] as $field => $meta_key ) {
			$raw = $input[ $field ] ?? '';
			$value = is_scalar( $raw ) ? (string) wp_unslash( $raw ) : '';
			$value = str_ends_with( $field, '_variables' ) ? sanitize_textarea_field( $value ) : sanitize_text_field( $value );
			update_post_meta( $practice_id, $meta_key, $value );
		}
	}

	public function item_complete( int $user_id, int $item_id ): bool {
		if ( ! $user_id || ! $item_id || ! function_exists( 'learndash_get_course_id' ) ) { return FALSE; }
		$course_id = absint( learndash_get_course_id( $item_id ) );
		if ( ! $course_id ) { return FALSE; }
		$type = get_post_type( $item_id );
		if ( $type === 'sfwd-topic' && function_exists( 'learndash_is_topic_complete' ) ) {
			return (bool) learndash_is_topic_complete( $user_id, $item_id, $course_id );
		}
		if ( $type === 'sfwd-lessons' && function_exists( 'learndash_is_lesson_complete' ) ) {
			return (bool) learndash_is_lesson_complete( $user_id, $item_id, $course_id );
		}
		return FALSE;
	}

	public function notify_review( array $response, string $previous_status, string $status, string $comment, bool $just_completed ): void {
		if ( $status === $previous_status ) { return; }
		$practice_id = absint( $response['practice_id'] ?? 0 );
		$response_id = absint( $response['id'] ?? 0 );
		$user_id = absint( $response['user_id'] ?? 0 );
		$item_id = absint( $response['item_id'] ?? 0 );
		if ( ! $response_id || ! $practice_id || ! $user_id || ! $item_id ) { return; }
		if ( $status === 'rejected' ) {
			$this->send( $response_id, $practice_id, $user_id, $item_id, 'rejected', $comment );
			return;
		}
		if ( $status !== 'approved' || ! $just_completed ) { return; }
		$next_id = $this->next_step_id( $item_id );
		if ( $next_id && $this->next_step_accessible( $user_id, $item_id, $next_id ) ) {
			$this->send( $response_id, $practice_id, $user_id, $item_id, 'unlock', $comment, $next_id );
		}
	}

	private function next_step_id( int $item_id ): int {
		if ( ! function_exists( 'learndash_get_course_id' ) ) { return 0; }
		$course_id = absint( learndash_get_course_id( $item_id ) );
		if ( ! $course_id ) { return 0; }
		$post = get_post( $item_id );
		if ( ! $post instanceof WP_Post ) { return 0; }
		if ( $post->post_type === 'sfwd-topic' && function_exists( 'nooshika_get_next_topic' ) ) {
			return absint( nooshika_get_next_topic( $post, $course_id ) );
		}
		if ( $post->post_type === 'sfwd-lessons' && function_exists( 'nooshika_get_next_lesson' ) ) {
			return absint( nooshika_get_next_lesson( $post, $course_id ) );
		}
		return 0;
	}

	private function next_step_accessible( int $user_id, int $item_id, int $next_id ): bool {
		$course_id = absint( learndash_get_course_id( $item_id ) );
		if ( ! $course_id || absint( learndash_get_course_id( $next_id ) ) !== $course_id ) { return FALSE; }
		$next = get_post( $next_id );
		if ( ! $next instanceof WP_Post || $next->post_status !== 'publish' || $this->item_complete( $user_id, $next_id ) ) { return FALSE; }
		$course_settings = get_post_meta( $course_id, '_sfwd-courses', TRUE );
		if ( is_array( $course_settings ) && ( $course_settings['sfwd-courses_course_disable_lesson_progression'] ?? '' ) === 'on' ) { return FALSE; }
		if ( ! function_exists( 'sfwd_lms_has_access' ) || ! sfwd_lms_has_access( $course_id, $user_id ) ) { return FALSE; }
		$lesson_id = get_post_type( $next_id ) === 'sfwd-topic' ? absint( get_post_meta( $next_id, 'lesson_id', TRUE ) ) : $next_id;
		if ( ! $lesson_id || ! function_exists( 'ld_lesson_access_from' ) || ld_lesson_access_from( $lesson_id, $user_id ) ) { return FALSE; }
		return TRUE;
	}

	private function send( int $response_id, int $practice_id, int $user_id, int $item_id, string $event, string $comment, int $next_id = 0 ): void {
		if ( ! class_exists( 'kasebiSMS' ) || ! method_exists( 'kasebiSMS', 'send_pattern_sms' ) ) { return; }
		$pattern_key = $event === 'rejected' ? KERP_Modules_Learning_Assignments_Module::SMS_REJECTED_PATTERN_META : KERP_Modules_Learning_Assignments_Module::SMS_UNLOCK_PATTERN_META;
		$variables_key = $event === 'rejected' ? KERP_Modules_Learning_Assignments_Module::SMS_REJECTED_VARIABLES_META : KERP_Modules_Learning_Assignments_Module::SMS_UNLOCK_VARIABLES_META;
		$pattern = trim( (string) get_post_meta( $practice_id, $pattern_key, TRUE ) );
		$raw_variables = (string) get_post_meta( $practice_id, $variables_key, TRUE );
		if ( $pattern === '' ) {
			$defaults = KERP_Modules_Learning_Assignments_Settings::instance()->sms_defaults();
			$pattern = trim( $defaults[ $event === 'rejected' ? 'rejected_pattern' : 'unlock_pattern' ] );
			$raw_variables = $defaults[ $event === 'rejected' ? 'rejected_variables' : 'unlock_variables' ];
		}
		if ( $pattern === '' ) { return; }
		$phone = $this->phone( $user_id );
		if ( $phone === '' ) { return; }
		$user = get_userdata( $user_id );
		$context = [
			'{user_id}' => (string) $user_id,
			'{user_name}' => $user ? trim( $user->first_name . ' ' . $user->last_name ) : '',
			'{practice_title}' => (string) get_the_title( $practice_id ),
			'{item_title}' => (string) get_the_title( $item_id ),
			'{next_item_title}' => $next_id ? (string) get_the_title( $next_id ) : '',
			'{review_comment}' => $comment,
			'{site_name}' => (string) get_bloginfo( 'name' ),
		];
		$payload = [ 'receptor' => $phone, 'pattern' => $pattern ];
		foreach ( preg_split( '/\s*;\s*/u', trim( $raw_variables ), -1, PREG_SPLIT_NO_EMPTY ) ?: [] as $part ) {
			$separator = strpos( $part, ':' );
			if ( $separator === FALSE ) { $separator = strpos( $part, '=' ); }
			if ( $separator === FALSE ) { continue; }
			$key = preg_replace( '/[^A-Za-z0-9_-]/', '', trim( substr( $part, 0, $separator ) ) );
			if ( $key !== '' ) { $payload[ $key ] = str_replace( [ ' ', '_' ], '-', sanitize_text_field( strtr( trim( substr( $part, $separator + 1 ) ), $context ) ) ); }
		}
		try {
			$this->service ??= new kasebiSMS();
			$result = $this->service->send_pattern_sms( $payload );
			$failed = $result === FALSE || $result === 'no gateway selected' || ( function_exists( 'is_wp_error' ) && is_wp_error( $result ) );
		} catch ( Throwable $error ) {
			$result = $error;
			$failed = TRUE;
		}
		if ( ! $this->log_response( $response_id, $event, $pattern, $phone, $result, $failed ) ) {
			do_action( 'kerp_learning_assignments_sms_log_failed', $response_id, $event, $result );
		}
		if ( $failed ) {
			do_action( 'kerp_learning_assignments_sms_failed', $result, $event, $practice_id, $user_id );
		} else {
			do_action( 'kerp_learning_assignments_sms_sent', $result, $payload, $event, $practice_id, $user_id );
		}
	}

	private function log_response( int $response_id, string $event, string $pattern, string $phone, mixed $result, bool $failed ): bool {
		try {
			return KERP_Modules_Learning_Assignments_Store::instance()->add_response_meta( $response_id, self::LOG_META_KEY, [
				'event' => $event,
				'status' => $failed ? 'failed' : 'returned',
				'pattern' => $pattern,
				'receptor' => $phone,
				'provider_response' => $this->normalize_response( $result ),
			] );
		} catch ( Throwable $error ) {
			return FALSE;
		}
	}

	private function normalize_response( mixed $result, int $depth = 0 ): mixed {
		if ( $depth >= 8 ) { return '[response depth limit]'; }
		if ( $result instanceof Throwable ) {
			return [ 'type' => get_class( $result ), 'code' => $result->getCode(), 'message' => $result->getMessage() ];
		}
		if ( function_exists( 'is_wp_error' ) && is_wp_error( $result ) ) {
			return [ 'type' => 'WP_Error', 'code' => $result->get_error_code(), 'message' => $result->get_error_message(), 'data' => $this->normalize_response( $result->get_error_data(), $depth + 1 ) ];
		}
		if ( is_object( $result ) ) { $result = get_object_vars( $result ); }
		if ( is_array( $result ) ) {
			foreach ( $result as $key => $value ) { $result[ $key ] = $this->normalize_response( $value, $depth + 1 ); }
			return $result;
		}
		if ( is_resource( $result ) ) { return '[resource]'; }
		return $result;
	}

	private function phone( int $user_id ): string {
		foreach ( [ 'nooshika_phone_num', 'billing_phone' ] as $meta_key ) {
			$number = (string) get_user_meta( $user_id, $meta_key, TRUE );
			if ( function_exists( 'nooshika_sanitize_numbers' ) ) { $number = nooshika_sanitize_numbers( $number ); }
			$number = function_exists( 'remove_zero_from_phone' ) ? (string) remove_zero_from_phone( $number ) : ( preg_replace( '/\D+/', '', $number ) ?? '' );
			if ( trim( $number ) !== '' ) { return trim( $number ); }
		}
		return '';
	}
}
