<?php
defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Installment_Management_Settings {
	public const OPTION = 'kerp_installment_plans';
	public static function all(): array { $plans = get_option( self::OPTION, [] ); return is_array( $plans ) ? $plans : []; }
	public static function text( array $input, string $key ): string { $value = $input[ $key ] ?? ''; return is_scalar( $value ) ? sanitize_text_field( (string) $value ) : ''; }
	public static function lessons( int $course_id ): array {
		if ( ! $course_id || ! function_exists( 'learndash_course_get_steps_by_type' ) ) { return []; }
		return array_values( array_map( 'absint', (array) learndash_course_get_steps_by_type( $course_id, 'sfwd-lessons' ) ) );
	}

	/** A contract copies this validated configuration; later edits affect new sales only. */
	public static function validate( array $input, bool $general_only = FALSE ): array|WP_Error {
		// Shared switch fields submit checked values as an array; unchecked fields are omitted.
		if ( isset( $input['enabled'] ) && is_array( $input['enabled'] ) ) { $input['enabled'] = $input['enabled'] === [ '1' ] ? '1' : '0'; }
		$name = self::text( $input, 'name' );
		$product_id = absint( self::text( $input, 'product_id' ) );
		$course_id = absint( self::text( $input, 'course_id' ) );
		$product = wc_get_product( $product_id );
		if ( $name === '' || ! $product ) {
			return new WP_Error( 'plan', 'نام پلن و یک محصول معتبر لازم است.' );
		}
		$lessons = self::lessons( $course_id );
		if ( get_post_type( $course_id ) !== 'sfwd-courses' || get_post_status( $course_id ) !== 'publish' || ! $lessons ) { return new WP_Error( 'course', 'دوره منتشرشده دارای درس را انتخاب کنید.' ); }
		if ( $general_only ) {
			return [ 'name' => $name, 'product_id' => $product_id, 'course_id' => $course_id, 'enabled' => self::text( $input, 'enabled' ) === '1' ];
		}
		$steps = []; $previous_day = -1; $previous_limit = -1; $total = 0;
		foreach ( (array) ( $input['steps'] ?? [] ) as $row ) {
			if ( ! is_array( $row ) ) { return new WP_Error( 'steps', 'ساختار مراحل معتبر نیست.' ); }
			if ( ! array_filter( $row, static fn( $v ) => is_scalar( $v ) && (string) $v !== '' ) ) { continue; }
			$days = self::text( $row, 'days' ); $percent = self::text( $row, 'percent' ); $limit = self::text( $row, 'lesson_id' );
			if ( ! preg_match( '/^\d{1,4}$/', $days ) || (int) $days > 3650 || ! preg_match( '/^\d{1,3}(?:\.\d{1,2})?$/', $percent ) || (float) $percent <= 0 || (float) $percent > 100 || ! ctype_digit( $limit ) ) {
				return new WP_Error( 'steps', 'روز سررسید، درصد مثبت و سقف دسترسی هر مرحله الزامی است.' );
			}
			$day = (int) $days; $lesson = absint( $limit ); $index = $lesson ? array_search( $lesson, $lessons, TRUE ) : count( $lessons );
			if ( $index === FALSE || $index < $previous_limit || $day <= $previous_day ) {
				return new WP_Error( 'sequence', 'روزهای سررسید باید به ترتیب افزایش یابند؛ سقف دسترسی نباید کاهش یابد و درس باید متعلق به همین دوره باشد.' );
			}
			$tag = sanitize_key( self::text( $row, 'tag' ) );
			if ( $tag !== '' && ! KERP_Modules_Customers_Taxonomies::instance()->get_term( 'tag', $tag ) ) { return new WP_Error( 'tag', 'تگ انتخاب‌شده در ERP وجود ندارد.' ); }
			$bp = (int) round( (float) $percent * 100 );
			$steps[] = [ 'days' => $day, 'percent' => $bp / 100, 'lesson_id' => $lesson, 'tag' => $tag ];
			$total += $bp; $previous_day = $day; $previous_limit = $index;
		}
		if ( count( $steps ) < 2 || count( $steps ) > 24 ) {
			return new WP_Error( 'total', 'تعداد اقساط باید بین ۲ تا ۲۴ باشد.' );
		}
		if ( $total !== 10000 ) {
			return new WP_Error( 'total', sprintf( 'مجموع سهم اقساط %s درصد است؛ مجموع باید دقیقاً ۱۰۰ درصد باشد.', number_format_i18n( $total / 100, 2 ) ) );
		}
		$sms = KERP_Modules_Installment_Management_SMS::ENABLED
			? KERP_Modules_Installment_Management_SMS::validate( (array) ( $input['sms'] ?? [] ), count( $steps ) )
			: (array) ( $input['sms'] ?? [] );
		if ( is_wp_error( $sms ) ) { return $sms; }
		return [ 'name' => $name, 'product_id' => $product_id, 'course_id' => $course_id, 'enabled' => self::text( $input, 'enabled' ) === '1',
			'tag_mode' => self::text( $input, 'tag_mode' ) === 'replace' ? 'replace' : 'append', 'steps' => $steps, 'sms' => $sms, 'sms_enabled' => ! empty( $input['sms_enabled'] ) ];
	}

	public static function save( array $input ): string|WP_Error {
		$id = sanitize_key( self::text( $input, 'plan_id' ) );
		$plans = self::all();
		if ( $id !== '' && ! isset( $plans[ $id ] ) ) { return new WP_Error( 'missing', 'پلن پیدا نشد.' ); }
		$tab = self::text( $input, 'active_tab' );
		$stored = $plans[ $id ] ?? [ 'tag_mode' => 'append', 'steps' => [], 'sms' => [] ];
		if ( $tab === 'sms' ) {
			if ( $id === '' || count( $stored['steps'] ?? [] ) < 2 ) { return new WP_Error( 'sms', 'ابتدا اطلاعات عمومی و اقساط پلن را ذخیره کنید.' ); }
			$rules = KERP_Modules_Installment_Management_SMS::validate( (array) ( $input['sms'] ?? [] ), count( $stored['steps'] ), TRUE );
			if ( is_wp_error( $rules ) ) { return $rules; }
			$plans[$id] = array_merge( $stored, [ 'sms' => $rules, 'sms_enabled' => TRUE ] );
			update_option( self::OPTION, $plans, FALSE );
			return $id;
		}
		if ( $tab === 'stages' ) {
			if ( $id === '' ) { return new WP_Error( 'plan', 'ابتدا اطلاعات عمومی پلن را ذخیره کنید.' ); }
			$input = array_merge( $stored, [ 'steps' => (array) ( $input['steps'] ?? [] ), 'tag_mode' => self::text( $input, 'tag_mode' ) ] );
			$input['enabled'] = ! empty( $stored['enabled'] ) ? '1' : '0';
		}
		if ( ! KERP_Modules_Installment_Management_SMS::ENABLED ) { $input['sms'] = (array) ( $plans[ $id ]['sms'] ?? [] ); }
		if ( $tab === 'stages' ) { $input['sms'] = []; }
		$plan = self::validate( $input, $tab === 'general' );
		if ( is_wp_error( $plan ) ) { return $plan; }
		if ( $tab === 'stages' ) { $plan['sms'] = $stored['sms'] ?? []; }
		if ( $tab === 'general' ) { $plan = array_merge( $stored, $plan ); }
		$id = $id ?: (string) ( max( (int) get_option( 'kerp_installment_last_plan_id', 0 ), $plans ? max( array_map( 'intval', array_keys( $plans ) ) ) : 0 ) + 1 );
		update_option( 'kerp_installment_last_plan_id', max( (int) $id, (int) get_option( 'kerp_installment_last_plan_id', 0 ) ), FALSE );
		$plans[ $id ] = $plan;
		update_option( self::OPTION, $plans, FALSE );
		return $id;
	}
}
