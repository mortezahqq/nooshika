<?php
defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Installment_Management_Access {
	private static bool $booted = FALSE;
	public static function boot(): void {
		if ( self::$booted ) { return; } self::$booted = TRUE;
		add_filter( 'kerp_followup_types', [ KERP_Modules_Installment_Management_Followups::class, 'types' ] );
		add_action( 'init', [ self::class, 'register_status' ], 25 );
		if ( did_action( 'init' ) ) { self::register_status(); }
		add_filter( 'wc_order_statuses', static fn( $statuses ) => $statuses + [ 'wc-await-install' => 'در انتظار پرداخت اقساط' ] );
		add_filter( 'kerp_orders_statuses', static function( $statuses ) {
			$statuses['await-install'] = [ 'label' => 'در انتظار پرداخت اقساط', 'active' => TRUE, 'color' => 'info', 'order' => 56, 'allowed_next' => [] ]; return $statuses;
		} );
		add_filter( 'kerp_orders_allowed_next_statuses', static fn( $statuses, $current ) => $current === 'await-install' ? [] : array_diff_key( $statuses, [ 'await-install' => TRUE ] ), 100, 2 );
		add_filter( 'woocommerce_order_needs_payment', static fn( $needs, $order ) => $order->get_meta( '_kerp_installment_is_parent' ) ? FALSE : $needs, 100, 2 );
		foreach ( [ 'woocommerce_payment_complete', 'woocommerce_order_status_changed', 'woocommerce_order_refunded' ] as $hook ) {
			add_action( $hook, [ KERP_Modules_Installment_Management_Service::class, 'order_changed' ], 30 );
		}
		add_filter( 'sfwd_lms_has_access', [ self::class, 'filter_access' ], 99, 3 );
		add_filter( 'ld_lesson_access_from', [ self::class, 'lesson_date' ], 99, 3 );
		add_filter( 'nooshika_panel_can_mark_complete', [ self::class, 'can_complete' ], 99, 3 );
		add_filter( 'learndash_process_mark_complete', [ self::class, 'complete_step' ], 99, 3 );
		add_filter( 'nooshika_panel_get_template_path', [ self::class, 'panel_template' ], 99, 3 );
		add_action( 'template_redirect', [ self::class, 'direct_page' ], 1 );
		foreach ( [ 'sfwd-lessons', 'sfwd-topic', 'sfwd-quiz' ] as $type ) { add_filter( 'rest_prepare_' . $type, [ self::class, 'rest_content' ], 99, 2 ); }
		add_action( 'woocommerce_before_pay_action', [ self::class, 'guard_payment' ], 1 );
		add_action( 'kasebi_after_order_details', [ self::class, 'customer_payments' ] );
		add_filter( 'woocommerce_available_payment_gateways', [ self::class, 'online_gateways' ], 100 );
		add_action( 'nooshika_ajax_kerp_skyroom_join', [ self::class, 'guard_class' ], 1 );
	}
	public static function register_status(): void {
		$label = 'در انتظار پرداخت اقساط';
		register_post_status( 'wc-await-install', [ 'label' => $label, 'public' => FALSE, 'show_in_admin_all_list' => TRUE, 'show_in_admin_status_list' => TRUE, 'label_count' => _n_noop( $label . ' (%s)', $label . ' (%s)' ) ] );
	}
	/** This guard intentionally never grants access or bypasses existing drip/prerequisite rules. */
	public static function allowed( int $user_id, int $post_id, int $course_id = 0 ): bool {
		if ( ! $user_id || user_can( $user_id, 'manage_options' ) || ! function_exists( 'learndash_get_course_id' ) ) { return TRUE; }
		$course_id = $course_id ?: absint( learndash_get_course_id( $post_id ) );
		if ( ! $course_id ) { return TRUE; }
		$contract = KERP_Modules_Installment_Management_Store::for_course( $user_id, $course_id );
		if ( ! $contract ) { return TRUE; }
		$stage = KERP_Modules_Installment_Management_Service::stage( $contract );
		if ( $stage === 0 ) { return FALSE; }
		if ( $post_id === $course_id ) { return TRUE; }
		$limit = (int) $contract['plan']['steps'][ $stage - 1 ]['lesson_id'];
		if ( $limit === 0 ) { return TRUE; }
		$lesson_id = get_post_type( $post_id ) === 'sfwd-lessons' ? $post_id : ( function_exists( 'learndash_course_get_single_parent_step' ) ? absint( learndash_course_get_single_parent_step( $course_id, $post_id, 'sfwd-lessons' ) ) : 0 );
		$lessons = KERP_Modules_Installment_Management_Settings::lessons( $course_id );
		$position = array_search( $lesson_id, $lessons, TRUE ); $cutoff = array_search( $limit, $lessons, TRUE );
		// Course-level quizzes require the final installment; removed boundaries fail closed.
		return $position !== FALSE && $cutoff !== FALSE && $position <= $cutoff;
	}
	public static function filter_access( $access, $post_id, $user_id ) { return $access && self::allowed( (int) $user_id, (int) $post_id ); }
	public static function lesson_date( $timestamp, $lesson_id, $user_id ) { return self::allowed( (int) $user_id, (int) $lesson_id ) ? $timestamp : max( (int) $timestamp, time() + YEAR_IN_SECONDS ); }
	public static function can_complete( $allowed, $user_id, $post_id ) { return $allowed && self::allowed( (int) $user_id, (int) $post_id ); }
	public static function complete_step( $allowed, $post, $user ) { return $allowed && self::allowed( (int) ( $user->ID ?? 0 ), (int) ( $post->ID ?? 0 ) ); }
	public static function panel_template( string $path, string $template, array $args = [] ): string {
		if ( in_array( $template, [ 'sub_pages/item', 'sub_pages/lesson', 'sub_pages/topic', 'sub_pages/quiz' ], TRUE ) && ! self::allowed( get_current_user_id(), absint( $args['post_id'] ?? $args['id'] ?? 0 ), absint( $args['course_id'] ?? 0 ) ) ) {
			return KERP_TEMPLATES_PATH . 'modules/installments/locked.php';
		}
		return $path;
	}
	public static function direct_page(): void {
		if ( is_singular( [ 'sfwd-lessons', 'sfwd-topic', 'sfwd-quiz' ] ) && ! self::allowed( get_current_user_id(), get_queried_object_id() ) ) {
			wp_die( 'دسترسی این بخش پس از پرداخت یا تأیید قسط مربوط باز می‌شود.', 'دسترسی اقساطی', [ 'response' => 403, 'back_link' => TRUE ] );
		}
	}
	public static function rest_content( $response, $post ) {
		return self::allowed( get_current_user_id(), (int) $post->ID ) ? $response : new WP_Error( 'kerp_installment_locked', 'این بخش هنوز در پلن اقساطی شما باز نشده است.', [ 'status' => 403 ] );
	}
	public static function guard_payment( $order ): void {
		$id = (int) $order->get_meta( '_kerp_installment_contract' );
		if ( ! $id ) { return; }
		$contract = KERP_Modules_Installment_Management_Store::get( $id );
		$index = $contract ? array_search( $order->get_id(), array_map( 'intval', $contract['orders'] ), TRUE ) : FALSE;
		if ( ! $contract || $contract['status'] !== 'active' || $index === FALSE || ! KERP_Modules_Installment_Management_Service::valid_order( $contract, $index, $order ) ) {
			wp_die( 'قرارداد اقساط این سفارش معتبر یا فعال نیست.', 'اقساط', [ 'response' => 403 ] );
		}
	}
	public static function online_gateways( array $gateways ): array {
		$order_id = absint( get_query_var( 'order-pay' ) );
		$order = $order_id ? wc_get_order( $order_id ) : FALSE;
		if ( $order && $order->get_meta( '_kerp_installment_contract' ) ) {
			foreach ( array_keys( $gateways ) as $key ) {
				if ( in_array( $key, [ 'bacs', 'cheque', 'cod' ], TRUE ) || str_starts_with( $key, 'kerp_' ) ) { unset( $gateways[ $key ] ); }
			}
		}
		return $gateways;
	}
	public static function customer_payments( $order ): void {
		$user_id = get_current_user_id();
		if ( ! $user_id || (int) $order->get_customer_id() !== $user_id ) { return; }
		$contract = KERP_Modules_Installment_Management_Store::get( (int) $order->get_meta( '_kerp_installment_contract' ) );
		if ( ! $contract || $contract['status'] !== 'active' || (int) $contract['user_id'] !== $user_id ) { return; }
		$parent_id = (int) ( $contract['plan']['parent_order_id'] ?? 0 );
		$show_all = $parent_id === $order->get_id() || ( ! $parent_id && (int) ( $contract['orders'][0] ?? 0 ) === $order->get_id() );
		$parts = [];
		foreach ( $contract['orders'] as $index => $part_id ) {
			if ( ! $show_all && (int) $part_id !== $order->get_id() ) { continue; }
			$part = wc_get_order( $part_id );
			if ( $part && KERP_Modules_Installment_Management_Service::valid_order( $contract, $index, $part ) ) {
				$parts[] = [ 'order' => $part, 'number' => $index + 1 ];
			}
		}
		if ( $parts ) { KERP_Helpers_Template::render_template( 'modules/installments/customer-payments.php', compact( 'parts' ) ); }
	}
	public static function guard_class(): void {
		$post_id = absint( is_scalar( $_POST['post_id'] ?? 0 ) ? $_POST['post_id'] : 0 );
		if ( ! self::allowed( get_current_user_id(), $post_id ) ) { wp_send_json( [ 'status' => FALSE, 'message' => 'دسترسی این کلاس پس از پرداخت قسط مربوط باز می‌شود.' ] ); }
	}
}
