<?php
defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Installment_Management_Dashboard {
	private static ?self $instance = NULL;


	public static function instance(): self { return self::$instance ??= new self(); }
	private function __construct() { add_filter( 'kerp_dashboard_blocks', [ $this, 'register_blocks' ] ); }

	public function register_blocks( array $blocks ): array {
		foreach ( [ 'status' => [ 'وضعیت اقساط', 4 ], 'due' => [ 'اقساط در انتظار وصول', 8 ] ] as $key => $definition ) {
			$blocks[ 'installments-' . $key ] = [
				'title' => $definition[0], 'width' => $definition[1], 'position' => $key === 'status' ? 60 : 61,
				'module' => 'installment_management', 'permission' => 'installments.view', 'permission_type' => 'view',
				'async' => TRUE, 'callback' => [ $this, 'render' ],
			];
		}
		return $blocks;
	}

	public function render( array $context, array $block ): void {
		if ( ! kerp_can( 'installments.view', 'view' ) || kerp_list_scope( 'customers' ) === 'none' ) { return; }
		$kind = $block['id'] ?? '';
		if ( ! in_array( $kind, [ 'installments-status', 'installments-due' ], TRUE ) ) { return; }
		KERP_Helpers_Template::render_template( 'modules/installments/dashboard.php', [ 'kind' => $kind, 'stats' => $this->get_data() ] );
	}

	public function get_data(): array {

		$data = [ 'counts' => array_fill_keys( [ 'paid', 'overdue', 'today', 'upcoming', 'review' ], 0 ), 'rows' => [], 'contracts' => 0 ];
		if ( ! kerp_can( 'installments.view', 'view' ) || kerp_list_scope( 'customers' ) === 'none' || ! function_exists( 'wc_get_order' ) ) { return $data; }
        return KERP_Helpers_Dashboard_Cache::remember( 'installments-v2', [ $this, 'collect' ] );
    }

    public function collect( array $state ): array {
        $data = $state['data'] ?? [ 'counts' => array_fill_keys( [ 'paid', 'overdue', 'today', 'upcoming', 'review' ], 0 ), 'rows' => [], 'contracts' => 0 ];
		global $wpdb;
		$table = KERP_Modules_Installment_Management_Store::table();
		$where = "status='active'";
		if ( kerp_list_scope( 'customers' ) === 'own' ) {
			$where .= $wpdb->prepare( " AND user_id IN (SELECT user_id FROM {$wpdb->usermeta} WHERE meta_key='owner_id' AND CAST(meta_value AS UNSIGNED)=%d)", get_current_user_id() );
		}
		$now = new DateTimeImmutable( $state['as_of'] );
		$today = $now->format( 'Y-m-d' );
		$until = $now->modify( '+7 days' )->setTime( 23, 59, 59 )->getTimestamp();
		$cursor = (int) ( $state['cursor'] ?? 0 );
        $allowed_customers = [];
		$deadline = microtime( TRUE ) + 1.5;
		$processed = 0;
		// Bound each fetch and the preview, without truncating the chart's totals.
		{
			$batch = (array) $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE {$where} AND id>%d ORDER BY id LIMIT 20", $cursor ), ARRAY_A );
			foreach ( $batch as $raw ) {
				if ( $processed > 0 && microtime( TRUE ) >= $deadline ) { break; }
				++$processed;
				$cursor = (int) $raw['id'];
                $allowed_customers[ $raw['user_id'] ] ??= KERP_Modules_Installment_Management_Api::customer_allowed( (int) $raw['user_id'] );
                if ( ! $allowed_customers[ $raw['user_id'] ] ) { continue; }
				$contract = KERP_Modules_Installment_Management_Store::decode( $raw );
				++$data['contracts'];
				foreach ( $contract['plan']['steps'] ?? [] as $index => $step ) {
					$order = wc_get_order( $contract['orders'][ $index ] ?? 0 );
					$due = (int) $contract['created_at'] + (int) $step['days'] * DAY_IN_SECONDS;
					$day = ( new DateTimeImmutable( '@' . $due ) )->setTimezone( wp_timezone() )->format( 'Y-m-d' );
					if ( ! $order || ! KERP_Modules_Installment_Management_Service::valid_order( $contract, $index, $order ) || $order->has_status( [ 'cancelled', 'refunded', 'trash' ] ) || (float) $order->get_total_refunded() > 0 ) {
						$status = 'review';
					} elseif ( $order->is_paid() ) {
						$status = 'paid';
					} else {
						$status = $day < $today ? 'overdue' : ( $day === $today ? 'today' : 'upcoming' );
					}
					++$data['counts'][ $status ];
					if ( in_array( $status, [ 'paid', 'review' ], TRUE ) || $due > $until ) { continue; }
					$data['rows'][] = [
						'id' => $cursor, 'user_id' => (int) $contract['user_id'], 'stage' => $index + 1,
						'plan' => (string) ( $contract['plan']['name'] ?? '' ), 'due' => $due, 'status' => $status,
						'amount' => (float) $contract['plan']['totals'][ $index ], 'currency' => $contract['plan']['currency'],
					];
				}
				usort( $data['rows'], static fn( $a, $b ) => [ $a['due'], $a['id'], $a['stage'] ] <=> [ $b['due'], $b['id'], $b['stage'] ] );
				$data['rows'] = array_slice( $data['rows'], 0, 8 );
			}
		}
        if ( count( $batch ) === 20 || $processed < count( $batch ) ) { return [ 'done' => FALSE, 'data' => $data, 'cursor' => $cursor ]; }
		return [ 'done' => TRUE, 'data' => $data ];
	}
}
