<?php
defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Installment_Management_Module {
	private static ?self $instance = NULL;
	public static function instance(): self { return self::$instance ??= new self(); }
	private function __construct() {
		KERP_Modules_Installment_Management_Store::install();
		KERP_Modules_Installment_Management_Access::boot();
		KERP_Modules_Installment_Management_Api::boot();
		KERP_Modules_Installment_Management_Dashboard::instance();
		add_filter( 'kerp_app_pages', [ $this, 'pages' ], 60 );
		add_filter( 'kerp_employee_permission_groups', [ $this, 'permissions' ], 60 );
		add_filter( 'kerp_customer_profile_tabs', [ $this, 'tabs' ], 60 );
		add_action( 'woocommerce_payment_complete', [ $this, 'payment_changed' ], 30 );
		add_action( 'woocommerce_order_status_changed', [ $this, 'payment_changed' ], 30 );
		add_action( 'woocommerce_order_refunded', [ $this, 'payment_changed' ], 30 );
		add_action( KERP_Modules_Installment_Management_SMS::CRON, [ KERP_Modules_Installment_Management_SMS::class, 'tick' ] );
		add_filter( 'cron_schedules', static function( array $schedules ): array { $schedules['kerp_installments_five_minutes'] = [ 'interval' => 300, 'display' => 'هر پنج دقیقه (اقساط)' ]; return $schedules; } );
		if ( ! wp_next_scheduled( KERP_Modules_Installment_Management_SMS::CRON ) ) { wp_schedule_event( time() + 300, 'kerp_installments_five_minutes', KERP_Modules_Installment_Management_SMS::CRON ); }
		add_filter( 'kerp_ajax_forced_plugins', [ $this, 'dependencies' ] );
		if ( ! defined( 'KERP_MU_DOING_AJAX' ) || ! KERP_MU_DOING_AJAX ) {
			$ajax = KERP_Modules_Ajax_Module::instance();
			$ajax->update_ajax_active_plugins( $this->dependencies( $ajax->get_ajax_active_plugins() ) );
			// The lesson and topic screens also render through the lightweight customer endpoint.
			$plugins = (array) get_option( 'nooshika_ajax_active_plugins', [] );
			$required = array_merge( $this->dependencies( $plugins ), [ KERP_BASENAME, 'nooshika-panel/nooshika-panel.php' ] );
			$required = array_values( array_unique( $required ) );
			if ( $required !== $plugins ) { update_option( 'nooshika_ajax_active_plugins', $required ); }
		}
	}
	public function dependencies( array $plugins ): array { return array_values( array_unique( array_merge( $plugins, [ 'woocommerce/woocommerce.php', 'sfwd-lms/sfwd_lms.php', 'nooshika-main/nooshika-main.php' ] ) ) ); }
	public function payment_changed( int $order_id ): void {
		$order = wc_get_order( $order_id );
		if ( $order && $order->get_meta( '_kerp_installment_contract' ) ) { KERP_Modules_Installment_Management_SMS::send_contract( (int) $order->get_meta( '_kerp_installment_contract' ) ); }
	}
	public function pages( array $pages ): array {
		$pages['installment-settings'] = [ 'title' => 'پلن‌های اقساط و دسترسی آموزشی', 'route' => 'settings/installments', 'type' => 'settings', 'template' => 'modules/installments/settings.php', 'permission' => 'installments.manage_settings',
			'navigation' => [ 'group' => [ 'key' => 'settings', 'title' => 'تنظیمات', 'icon' => 'kik fa-settings-02', 'order' => 100, 'sep_before' => TRUE ], 'menu' => [ 'key' => 'orders-settings', 'title' => __( 'تنظیمات سفارش‌ها', 'kasebi-erp' ), 'icon' => 'uik-r fa-shopping-cart', 'order' => 40 ], 'title' => 'فروش اقساطی', 'icon' => 'ni ni-wallet', 'order' => 57 ] ];
		$pages['installment-plan-new'] = [ 'title' => 'پلن جدید اقساط', 'route' => 'settings/installments/new', 'type' => 'sub-page', 'template' => 'modules/installments/plan-new.php', 'permission' => 'installments.manage_settings', 'navigation' => [ 'hidden' => TRUE, 'active' => 'installment-settings' ] ];
		$pages['installment-plan'] = [ 'title' => 'تنظیمات پلن اقساط', 'route' => 'settings/installments/{plan_id}', 'type' => 'sub-page', 'template' => 'modules/installments/plan.php', 'permission' => 'installments.manage_settings', 'navigation' => [ 'hidden' => TRUE, 'active' => 'installment-settings' ] ];
		return $pages;
	}
	public function tabs( array $tabs ): array {
		$tabs['installments'] = [ 'key' => 'installments', 'title' => 'اقساط آموزشی', 'icon' => 'ni ni-wallet', 'order' => 57, 'group' => 'finance-loyalty', 'permission' => 'installments.view', 'action' => 'view', 'template' => 'modules/installments/customer.php' ];
		return $tabs;
	}
	public function permissions( array $groups ): array {
		$permissions = [];
		foreach ( [ 'view' => 'مشاهده قرارداد و اقساط', 'create' => 'ثبت قرارداد اقساط', 'approve' => 'تأیید دریافت قسط', 'manage_settings' => 'تنظیم پلن‌های اقساط' ] as $key => $label ) {
			$permissions[ $key ] = [ 'key' => 'installments.' . $key, 'label' => $label, 'type' => $key === 'view' ? 'view' : 'action', 'order' => count( $permissions ) * 10 ];
		}
		$groups['installments'] = [ 'key' => 'installments', 'label' => 'فروش اقساطی', 'icon' => 'ni ni-wallet', 'order' => 57, 'blocks' => [ 'installments' => [ 'key' => 'installments', 'label' => 'اقساط آموزشی', 'permissions' => $permissions ] ] ];
		return $groups;
	}
}
