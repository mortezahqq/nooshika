<?php
defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Installment_Management_SMS {
	public const CRON = 'kerp_installments_tick';
	// Rules are copied into new contracts; existing contract snapshots remain unchanged.
	public const ENABLED = TRUE;
	private static ?object $service = NULL;
	public static function events(): array { return [ 'created' => 'ثبت قرارداد', 'due' => 'سررسید قسط پرداخت‌نشده', 'paid' => 'پرداخت یا تأیید قسط و بازشدن مرحله' ]; }
	public static function recipients(): array { return [ 'customer' => 'مشتری', 'employee' => 'مسئول پیگیری اقساط', 'admin' => 'مدیر (شماره‌های تنظیمات پیامک)', 'user_meta' => 'شماره از متای مشتری / والد', 'custom' => 'شماره دلخواه' ]; }
	public static function operators(): array { return [ 'eq' => 'برابر', 'ne' => 'نابرابر', 'contains' => 'شامل', 'empty' => 'خالی', 'not_empty' => 'غیرخالی', 'gt' => 'بزرگ‌تر (عدد)', 'lt' => 'کوچک‌تر (عدد)' ]; }
	public static function variables(): array { return [ '{user_name}', '{first_name}', '{last_name}', '{user_id}', '{plan_name}', '{product_title}', '{course_title}', '{stage}', '{amount}', '{currency}', '{due_date}', '{order_id}', '{payment_url}', '{site_name}' ]; }
	public static function variable_labels(): array {
		return array_combine( self::variables(), [ 'نام کامل مشتری', 'نام مشتری', 'نام خانوادگی مشتری', 'شناسه مشتری', 'نام پلن', 'نام محصول', 'نام دوره', 'شماره قسط', 'مبلغ قسط', 'واحد پول', 'سررسید شمسی', 'شناسه سفارش قسط', 'لینک پرداخت قسط', 'نام سایت' ] );
	}
	public static function validate( array $rows, int $count, bool $simple = FALSE ): array|WP_Error {
		$rules = [];
		foreach ( $rows as $row ) {
			if ( ! is_array( $row ) ) { return new WP_Error( 'sms', 'ساختار قانون پیامک معتبر نیست.' ); }
			if ( ! array_filter( $row, static fn( $v ) => is_scalar( $v ) && (string) $v !== '' ) ) { continue; }
			$rule = [];
			foreach ( [ 'enabled', 'stage', 'event', 'offset', 'recipient', 'phone_meta', 'receptor', 'pattern', 'variables', 'required_tag', 'excluded_tag', 'meta_key', 'operator', 'meta_value', 'payment_method' ] as $key ) {
				$rule[ $key ] = KERP_Modules_Installment_Management_Settings::text( $row, $key );
			}
			foreach ( [ 'stage', 'offset' ] as $key ) { $rule[$key] = KERP_Helpers_Format::sanitize_numbers( $rule[$key] ); }
			if ( $simple || ! array_key_exists( 'enabled', $row ) ) { $rule['enabled'] = '1'; }
			if ( $simple ) {
				foreach ( [ 'required_tag', 'excluded_tag', 'payment_method', 'meta_key', 'operator', 'meta_value' ] as $key ) { $rule[$key] = ''; }
			}
			if ( $rule['recipient'] !== 'custom' ) { $rule['receptor'] = ''; }
			if ( $rule['recipient'] !== 'user_meta' ) { $rule['phone_meta'] = ''; }
			if ( ! ctype_digit( $rule['stage'] ) ) { return new WP_Error( 'sms', 'شماره قسط باید عدد صحیح مثبت باشد.' ); }
			$rule['stage'] = absint( $rule['stage'] );
			if ( $rule['stage'] < 1 || $rule['stage'] > $count || ! isset( self::events()[ $rule['event'] ], self::recipients()[ $rule['recipient'] ] ) || $rule['pattern'] === '' ) { return new WP_Error( 'sms', 'شماره مرحله، رویداد، گیرنده و پترن معتبر برای هر قانون پیامک لازم است.' ); }
			if ( $rule['offset'] === '' ) { $rule['offset'] = '0'; }
			if ( ! preg_match( '/^-?\d{1,6}$/', $rule['offset'] ) || abs( (int) $rule['offset'] ) > 525600 || ( $rule['event'] !== 'due' && (int) $rule['offset'] < 0 ) ) { return new WP_Error( 'sms', 'زمان پیامک باید بر حسب دقیقه باشد؛ زمان منفی فقط برای یادآوری پیش از سررسید مجاز است.' ); }
			if ( $rule['meta_key'] !== '' && ! isset( self::operators()[ $rule['operator'] ] ) ) { return new WP_Error( 'sms', 'عملگر شرط متای کاربر را انتخاب کنید.' ); }
			foreach ( [ 'required_tag', 'excluded_tag' ] as $key ) { if ( $rule[ $key ] !== '' && ! KERP_Modules_Customers_Taxonomies::instance()->get_term( 'tag', $rule[ $key ] ) ) { return new WP_Error( 'sms', 'تگ شرط پیامک معتبر نیست.' ); } }
			if ( ( $rule['recipient'] === 'custom' && $rule['receptor'] === '' ) || ( $rule['recipient'] === 'user_meta' && $rule['phone_meta'] === '' ) ) { return new WP_Error( 'sms', 'شماره گیرنده یا کلید متای شماره را وارد کنید.' ); }
			$rule['offset'] = (int) $rule['offset']; $rule['enabled'] = $rule['enabled'] === '1';
			$rules[] = $rule;
		}
		return $rules;
	}
	public static function tick(): void {
		global $wpdb;
		// A durable cursor prevents large installations from starving older contracts.
		$cursor = absint( get_option( 'kerp_installment_cron_cursor', 0 ) );
		$ids = $wpdb->get_col( $wpdb->prepare( 'SELECT id FROM ' . KERP_Modules_Installment_Management_Store::table() . " WHERE status='active' AND id>%d ORDER BY id ASC LIMIT 100", $cursor ) );
		foreach ( $ids as $id ) {
			KERP_Modules_Installment_Management_Service::sync( (int) $id );
			self::send_contract( (int) $id );
			$cursor = (int) $id;
		}
		update_option( 'kerp_installment_cron_cursor', count( $ids ) < 100 ? 0 : $cursor, FALSE );
	}
	public static function condition( array $rule, int $user_id, $order ): bool {
		$tags = (array) KERP_Modules_Customers_Taxonomies::instance()->get_customer_terms( $user_id, 'tag' );
		if ( $rule['required_tag'] !== '' && ! in_array( $rule['required_tag'], $tags, TRUE ) ) { return FALSE; }
		if ( $rule['excluded_tag'] !== '' && in_array( $rule['excluded_tag'], $tags, TRUE ) ) { return FALSE; }
		if ( $rule['payment_method'] !== '' && $order->get_payment_method() !== $rule['payment_method'] ) { return FALSE; }
		if ( $rule['meta_key'] === '' ) { return TRUE; }
		$value = get_user_meta( $user_id, $rule['meta_key'], TRUE ); $value = is_scalar( $value ) ? (string) $value : '';
		$expected = $rule['meta_value'];
		return match ( $rule['operator'] ) {
			'eq' => $value === $expected, 'ne' => $value !== $expected, 'contains' => $expected !== '' && str_contains( $value, $expected ),
			'empty' => $value === '', 'not_empty' => $value !== '',
			'gt' => is_numeric( $value ) && is_numeric( $expected ) && (float) $value > (float) $expected,
			'lt' => is_numeric( $value ) && is_numeric( $expected ) && (float) $value < (float) $expected, default => FALSE,
		};
	}
	public static function send_contract( int $id ): void {
		if ( ! self::ENABLED ) { return; }
		if ( ! class_exists( 'kasebiSMS' ) || ! method_exists( 'kasebiSMS', 'send_pattern_sms' ) ) { return; }
		$contract = KERP_Modules_Installment_Management_Store::get( $id );
		if ( ! $contract || $contract['status'] !== 'active' || empty( $contract['plan']['sms_enabled'] ) ) { return; }
		$lock = 'user_' . $contract['user_id'];
		if ( ! KERP_Modules_Installment_Management_Store::lock( $lock ) ) { return; }
		try {
			$contract = KERP_Modules_Installment_Management_Store::get( $id ); $state = $contract['state'];
			$stage = KERP_Modules_Installment_Management_Service::stage( $contract ); $user_id = (int) $contract['user_id'];
			foreach ( $contract['plan']['sms'] as $rule_index => $rule ) {
				if ( ! $rule['enabled'] ) { continue; }
				$i = $rule['stage'] - 1; $order = wc_get_order( $contract['orders'][ $i ] ?? 0 );
				if ( ! $order || ! KERP_Modules_Installment_Management_Service::valid_order( $contract, $i, $order ) || $order->has_status( [ 'cancelled', 'refunded', 'failed' ] ) || (float) $order->get_total_refunded() > 0 ) { continue; }
				$due = (int) $contract['created_at'] + $contract['plan']['steps'][ $i ]['days'] * DAY_IN_SECONDS;
				if ( $rule['event'] === 'due' && KERP_Modules_Installment_Management_Service::paid( $contract, $i ) ) { continue; }
				if ( $rule['event'] === 'paid' && $stage < $rule['stage'] ) { continue; }
				if ( $rule['event'] === 'paid' ) {
					$paid_at = $order->get_date_paid();
					$state['paid_at'][ $i ] ??= $paid_at ? $paid_at->getTimestamp() : time();
				}
				$anchor = match ( $rule['event'] ) { 'due' => $due, 'paid' => (int) $state['paid_at'][ $i ], default => (int) $contract['created_at'] };
				if ( time() < $anchor + $rule['offset'] * MINUTE_IN_SECONDS || ! self::condition( $rule, $user_id, $order ) ) { continue; }
				$user = get_userdata( $user_id );
				$context = [ '{user_name}' => $user ? $user->display_name : '', '{first_name}' => $user ? $user->first_name : '', '{last_name}' => $user ? $user->last_name : '', '{user_id}' => (string) $user_id,
					'{plan_name}' => $contract['plan']['name'], '{product_title}' => get_the_title( $contract['plan']['product_id'] ), '{course_title}' => get_the_title( $contract['course_id'] ), '{stage}' => (string) $rule['stage'],
					'{amount}' => (string) $order->get_total(), '{currency}' => $order->get_currency(), '{due_date}' => KERP_Helpers_Date::gregorian_to_jalali( ( new DateTimeImmutable( '@' . $due ) )->setTimezone( wp_timezone() )->format( 'Y-m-d' ) ), '{order_id}' => (string) $order->get_id(), '{payment_url}' => $order->get_checkout_payment_url(), '{site_name}' => get_bloginfo( 'name' ) ];
				foreach ( self::numbers( $rule, $user_id, $order, (int) $contract['created_by'] ) as $number ) {
					$key = hash( 'sha256', $rule_index . '|' . $number ); $log = $state['sms'][ $key ] ?? [];
					if ( in_array( $log['status'] ?? '', [ 'sent', 'sending' ], TRUE ) || (int) ( $log['retry_at'] ?? 0 ) > time() ) { continue; }
					$payload = [ 'receptor' => $number, 'pattern' => $rule['pattern'] ];
					foreach ( preg_split( '/\s*;\s*/u', $rule['variables'], -1, PREG_SPLIT_NO_EMPTY ) ?: [] as $part ) {
						$pair = preg_split( '/[:=]/', $part, 2 );
						if ( count( $pair ) !== 2 ) { continue; }
						$name = preg_replace( '/[^A-Za-z0-9_-]/', '', trim( $pair[0] ) );
						if ( $name === '' || in_array( $name, [ 'receptor', 'pattern' ], TRUE ) ) { continue; }
						$value = strtr( trim( $pair[1] ), $context );
						// WooCommerce order keys contain underscores; altering them breaks payment links.
						$payload[ $name ] = str_contains( $pair[1], '{payment_url}' ) ? $value : str_replace( [ ' ', '_' ], '-', $value );
					}
					$attempt = (int) ( $log['attempts'] ?? 0 ) + 1;
					$state['sms'][ $key ] = [ 'status' => 'sending', 'at' => time(), 'attempts' => $attempt, 'rule' => $rule_index, 'stage' => $rule['stage'] ];
					if ( ! KERP_Modules_Installment_Management_Store::update( $id, [ 'state' => $state ] ) ) { continue; }
					try { self::$service ??= new kasebiSMS(); $result = self::$service->send_pattern_sms( $payload ); $status = self::delivery_status( $result ); }
					catch ( Throwable $error ) { $result = $error; $status = 'failed'; }
					// An unrecognized provider response requires review, not an automatic duplicate send.
					$state['sms'][ $key ]['status'] = $status === 'unknown' ? 'sending' : $status;
					$state['sms'][ $key ]['retry_at'] = time() + min( DAY_IN_SECONDS, 300 * ( 2 ** min( $attempt, 8 ) ) );
					KERP_Modules_Installment_Management_Store::update( $id, [ 'state' => $state ] );
					do_action( 'kerp_installment_sms_' . $status, $result, $payload, $rule, $id );
				}
			}
			KERP_Modules_Installment_Management_Store::update( $id, [ 'state' => $state ] );
		} finally { KERP_Modules_Installment_Management_Store::unlock( $lock ); }
	}
	public static function delivery_status( mixed $result ): string {
		if ( is_wp_error( $result ) || $result instanceof Throwable || $result === FALSE || $result === 'no gateway selected' ) { return 'failed'; }
		if ( $result === TRUE ) { return 'sent'; }
		$data = is_object( $result ) ? get_object_vars( $result ) : $result;
		if ( is_array( $data ) ) {
			foreach ( [ 'success', 'ok' ] as $key ) { if ( array_key_exists( $key, $data ) ) { return ! empty( $data[ $key ] ) ? 'sent' : 'failed'; } }
			if ( ! empty( $data['error'] ) || ! empty( $data['errors'] ) ) { return 'failed'; }
			if ( isset( $data['status'] ) && is_scalar( $data['status'] ) ) {
				$status = strtolower( (string) $data['status'] );
				if ( in_array( $status, [ 'ok', 'success', '1', '200', '201', '202' ], TRUE ) ) { return 'sent'; }
				if ( is_numeric( $status ) || in_array( $status, [ 'error', 'failed', 'fail' ], TRUE ) ) { return 'failed'; }
			}
		}
		return 'unknown';
	}
	private static function numbers( array $rule, int $user_id, $order, int $employee_id ): array {
		$raw = match ( $rule['recipient'] ) {
			'employee' => get_user_meta( $employee_id, 'nooshika_phone_num', TRUE ),
			'admin' => get_option( 'kasebi_sms_admin_phone_number', '' ), 'custom' => $rule['receptor'],
			'user_meta' => get_user_meta( $user_id, $rule['phone_meta'], TRUE ),
			default => get_user_meta( $user_id, 'nooshika_phone_num', TRUE ) ?: $order->get_billing_phone(),
		};
		if ( ! is_scalar( $raw ) ) { return []; }
		$numbers = preg_split( '/[,،\s]+/u', (string) $raw, -1, PREG_SPLIT_NO_EMPTY ) ?: [];
		return array_values( array_unique( array_filter( array_map( static function ( string $number ): string {
			$number = KERP_Helpers_Format::sanitize_numbers( $number );
			$number = preg_replace( '/\D+/', '', $number );
			$number = preg_replace( '/^(?:0098|98|0)(?=9\d{9}$)/', '', $number );
			return preg_match( '/^9\d{9}$/', $number ) ? $number : '';
		}, $numbers ) ) ) );
	}
}
