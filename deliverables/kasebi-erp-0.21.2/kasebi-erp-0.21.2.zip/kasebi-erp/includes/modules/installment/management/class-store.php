<?php
defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Installment_Management_Store {
	public static function table(): string { global $wpdb; return $wpdb->prefix . 'kerp_installment_contracts'; }
	public static function install(): void {
		if ( get_option( 'kerp_installment_db_version' ) === '1' ) { return; }
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$table = self::table(); $charset = $wpdb->get_charset_collate();
		dbDelta( "CREATE TABLE {$table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			user_id bigint(20) unsigned NOT NULL,
			course_id bigint(20) unsigned NOT NULL,
			created_by bigint(20) unsigned NOT NULL,
			request_id varchar(64) NOT NULL,
			created_at bigint(20) unsigned NOT NULL,
			status varchar(20) NOT NULL DEFAULT 'building',
			plan longtext NOT NULL,
			orders longtext NOT NULL,
			state longtext NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY request_id (request_id),
			KEY user_course (user_id,course_id),
			KEY status_id (status,id)
		) {$charset};" );
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $table ) ) ) === $table ) { update_option( 'kerp_installment_db_version', '1', FALSE ); }
	}
	public static function decode( ?array $row ): ?array {
		if ( ! $row ) { return NULL; }
		foreach ( [ 'plan', 'orders', 'state' ] as $key ) { $row[ $key ] = json_decode( (string) $row[ $key ], TRUE ) ?: []; }
		return $row;
	}
	public static function get( int $id ): ?array { global $wpdb; return self::decode( $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE id=%d', $id ), ARRAY_A ) ); }
	public static function for_course( int $user_id, int $course_id ): ?array {
		global $wpdb;
		return self::decode( $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table() . " WHERE user_id=%d AND course_id=%d AND status IN ('active','building') ORDER BY id DESC LIMIT 1", $user_id, $course_id ), ARRAY_A ) );
	}
	public static function for_user( int $user_id ): array {
		global $wpdb;
		return array_map( [ self::class, 'decode' ], $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . self::table() . " WHERE user_id=%d AND status='active' ORDER BY id", $user_id ), ARRAY_A ) );
	}
	public static function update( int $id, array $data ): bool {
		global $wpdb;
		foreach ( [ 'plan', 'orders', 'state' ] as $key ) { if ( isset( $data[ $key ] ) ) { $data[ $key ] = wp_json_encode( $data[ $key ] ); } }
		return $wpdb->update( self::table(), $data, [ 'id' => $id ] ) !== FALSE;
	}
	/** Connection-scoped lock, also released by MySQL if the PHP worker dies. */
	public static function lock( string $key ): bool { global $wpdb; return (int) $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 0)', 'kerp_inst_' . md5( $wpdb->prefix . $key ) ) ) === 1; }
	public static function unlock( string $key ): void { global $wpdb; $wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', 'kerp_inst_' . md5( $wpdb->prefix . $key ) ) ); }
}
