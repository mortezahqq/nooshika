<?php
defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Installment_Management_Service {
	public static function balance( $order ): ?array {
		if ( $order instanceof WC_Order && $order->get_meta( '_kerp_deposit_amount' ) ) { return KERP_Modules_Payments_Deposit::balance( $order ); }
		if ( $order instanceof WC_Order && ! $order->get_meta( '_kerp_installment_contract' ) ) {
			$received = KERP_Modules_Payments_Cheques::amount_received( $order ); $total = (float) $order->get_total();
			if ( $received !== NULL ) { return [ 'total' => $total, 'paid' => $received, 'remaining' => max( 0, $total - $received ), 'due' => NULL, 'payable' => FALSE, 'percent' => $total > 0 ? round( 100 * $received / $total ) : 0 ]; }
		}
		if ( ! $order || ! $order->get_meta( '_kerp_installment_contract' ) ) { return NULL; }
		$contract = KERP_Modules_Installment_Management_Store::get( (int) $order->get_meta( '_kerp_installment_contract' ) );
		if ( ! $contract || $contract['status'] !== 'active' ) { return NULL; }
		$total = (float) array_sum( $contract['plan']['totals'] ); $paid = 0.0; $due = NULL; $payable = FALSE;
		foreach ( $contract['orders'] as $index => $id ) {
			$part = wc_get_order( $id );
			if ( ! $part || ! self::valid_order( $contract, $index, $part ) ) { continue; }
			$received = KERP_Modules_Payments_Cheques::amount_received( $part );
			if ( $received !== NULL ) { $paid += $received; }
			elseif ( $part->is_paid() || $part->has_status( 'refunded' ) ) { $paid += max( 0, (float) $part->get_total() - (float) $part->get_total_refunded() ); }
			if ( $due === NULL && ! self::paid( $contract, $index ) ) {
				$due = (int) $contract['created_at'] + (int) $contract['plan']['steps'][ $index ]['days'] * DAY_IN_SECONDS;
			}
			if ( ! $part->is_paid() && $part->has_status( [ 'pending', 'failed', 'finance-review' ] ) ) { $payable = TRUE; }
		}
		$paid = min( $total, $paid );
		return [ 'total' => $total, 'paid' => $paid, 'remaining' => max( 0, $total - $paid ), 'due' => $due, 'payable' => $payable, 'percent' => $total > 0 ? round( 100 * $paid / $total ) : 0 ];
	}
	/** The sales order is distinct from the gateway-compatible installment orders. */
	public static function main_order_id( int $order_id ): int {
		$order = wc_get_order( $order_id );
		return $order ? ( (int) $order->get_meta( '_kerp_installment_parent_order' ) ?: $order_id ) : $order_id;
	}
	public static function payment_order_ids( int $order_id ): array {
		$order = wc_get_order( $order_id );
		if ( $order && $order->get_meta( '_kerp_deposit_orders' ) ) {
			return array_merge( [ $order_id ], array_map( static fn( $part ) => $part->get_id(), KERP_Modules_Payments_Deposit::orders( $order ) ) );
		}
		if ( $order && $order->get_meta( '_kerp_installment_is_parent' ) ) {
			$contract = KERP_Modules_Installment_Management_Store::get( (int) $order->get_meta( '_kerp_installment_contract' ) );
			if ( $contract && (int) ( $contract['plan']['parent_order_id'] ?? 0 ) === $order_id ) {
				return array_values( array_unique( array_merge( [ $order_id ], array_map( 'intval', $contract['orders'] ) ) ) );
			}
		}
		return [ $order_id ];
	}
	/** Amounts in the shop currency; the final installment carries the rounding remainder. */
	public static function split( float $total, array $steps, int $decimals ): array {
		$units = (int) round( $total * ( 10 ** $decimals ) ); $remaining = $units; $amounts = [];
		foreach ( $steps as $i => $step ) {
			$amount = $i === count( $steps ) - 1 ? $remaining : (int) round( $units * $step['percent'] / 100 );
			$remaining -= $amount; $amounts[] = $amount / ( 10 ** $decimals );
		}
		return $amounts;
	}

	public static function create( int $user_id, string $plan_id, string $request_id, ?float $base_total = NULL, array $order_context = [], ?WC_Order $existing_parent = NULL ): array|WP_Error {
		global $wpdb;
		$lock = 'user_' . $user_id;
		if ( ! KERP_Modules_Installment_Management_Store::lock( $lock ) ) { return new WP_Error( 'busy', 'درخواست دیگری در حال پردازش است؛ دوباره تلاش کنید.' ); }
		$created = []; $id = 0; $parent = NULL;
		$assignee = $existing_parent ? (int) $existing_parent->get_meta( 'marketer_id' ) : get_current_user_id();
		if ( $existing_parent && ( ! KERP_Modules_Payments_Proforma::is_draft( $existing_parent ) || $existing_parent->get_customer_id() !== $user_id || $existing_parent->get_meta( '_kerp_installment_contract' ) ) ) { KERP_Modules_Installment_Management_Store::unlock( $lock ); return new WP_Error( 'parent', 'پیش‌فاکتور معتبر نیست.' ); }
		try {
			$existing = $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . KERP_Modules_Installment_Management_Store::table() . ' WHERE request_id=%s', $request_id ) );
			if ( $existing ) {
				$row = KERP_Modules_Installment_Management_Store::get( (int) $existing );
				if ( (int) $row['user_id'] !== $user_id || ! in_array( $row['status'], [ 'active', 'failed' ], TRUE ) ) { return new WP_Error( 'request', 'این درخواست قبلاً ثبت شده و نیاز به بررسی دارد.' ); }
				if ( $row['status'] === 'active' ) { return $row; }
				// Retry only after rollback has cancelled every order from the failed contract.
				$old_orders = array_merge( $row['orders'], [ (int) ( $row['plan']['parent_order_id'] ?? 0 ) ] );
				foreach ( array_filter( $old_orders ) as $old_id ) {
					$old_order = wc_get_order( $old_id );
					if ( $existing_parent && (int) $old_id === $existing_parent->get_id() && KERP_Modules_Payments_Proforma::is_draft( $old_order ) ) { continue; }
					if ( $old_order && ( $old_order->is_paid() || ! $old_order->has_status( 'cancelled' ) || (float) $old_order->get_total_refunded() > 0 ) ) { return new WP_Error( 'request', 'سفارش‌های تلاش قبلی هنوز تعیین تکلیف نشده‌اند.' ); }
				}
				$row['plan']['original_request_id'] = $request_id;
				if ( ! KERP_Modules_Installment_Management_Store::update( (int) $existing, [ 'request_id' => wp_generate_uuid4(), 'plan' => $row['plan'] ] ) ) { return new WP_Error( 'request', 'آماده‌سازی تلاش مجدد ناموفق بود؛ دوباره تلاش کنید.' ); }
			}
			$plan = KERP_Modules_Installment_Management_Settings::all()[ $plan_id ] ?? NULL;
			$followups_ready = KERP_Modules_Installment_Management_Followups::ready( $assignee );
			if ( is_wp_error( $followups_ready ) ) { return $followups_ready; }
			if ( ! $plan || empty( $plan['enabled'] ) || ! get_userdata( $user_id ) ) { return new WP_Error( 'plan', 'مشتری یا پلن فروش فعال معتبر نیست.' ); }
			$valid = KERP_Modules_Installment_Management_Settings::validate( $plan );
			if ( is_wp_error( $valid ) ) { return $valid; }
			if ( KERP_Modules_Installment_Management_Store::for_course( $user_id, $plan['course_id'] ) || sfwd_lms_has_access( $plan['course_id'], $user_id ) ) {
				return new WP_Error( 'access', 'این مشتری قبلاً به دوره دسترسی دارد یا قرارداد اقساط همین دوره برای او ثبت شده است.' );
			}
			$product = wc_get_product( $plan['product_id'] );
			if ( ! $product || ! $product->is_purchasable() || ! $product->is_in_stock() || (float) $product->get_price() <= 0 ) { return new WP_Error( 'product', 'محصول در حال حاضر قابل فروش نیست.' ); }
			// One purchased unit is apportioned across payment orders. No stock-managed products.
			if ( $product->managing_stock() ) { return new WP_Error( 'stock', 'فروش اقساطی فقط برای محصول آموزشی بدون مدیریت موجودی مجاز است.' ); }
			if ( $base_total !== NULL && ( ! is_finite( $base_total ) || $base_total <= 0 ) ) { return new WP_Error( 'amount', 'مبلغ پایه سفارش معتبر نیست.' ); }
			$amounts = self::split( $base_total ?? (float) wc_get_price_excluding_tax( $product ), $plan['steps'], wc_get_price_decimals() );
			if ( min( $amounts ) <= 0 ) { return new WP_Error( 'amount', 'مبلغ محصول برای تعداد و درصد اقساط انتخاب‌شده کافی نیست.' ); }
			$plan['id'] = $plan_id; $plan['currency'] = get_woocommerce_currency(); $plan['totals'] = []; $now = time();
			$plan['automatic_followups'] = TRUE;
			$ok = $wpdb->insert( KERP_Modules_Installment_Management_Store::table(), [ 'user_id' => $user_id, 'course_id' => $plan['course_id'], 'created_by' => $assignee, 'request_id' => $request_id, 'created_at' => $now, 'status' => 'building', 'plan' => wp_json_encode( $plan ), 'orders' => '[]', 'state' => '{}' ] );
			if ( ! $ok ) { throw new RuntimeException( 'ثبت قرارداد انجام نشد.' ); }
			$id = (int) $wpdb->insert_id;
			$customer = new WC_Customer( $user_id );
			$context_data = [];
			if ( $existing_parent ) { $parent = $existing_parent; } else {
				$parent = wc_create_order( [ 'customer_id' => $user_id, 'created_via' => 'kerp_installment_sale', 'status' => 'await-install' ] );
				if ( is_wp_error( $parent ) ) { throw new RuntimeException( $parent->get_error_message() ); }
				$parent->update_meta_data( '_kerp_installment_contract', $id );
				$parent->update_meta_data( '_kerp_installment_is_parent', 1 );
				$parent->update_meta_data( 'marketer_id', get_current_user_id() );
				$parent->set_address( $customer->get_billing(), 'billing' );
				$parent_item = new WC_Order_Item_Product(); $parent_item->set_product( $product ); $parent_item->set_quantity( 1 );
				$parent_item->set_subtotal( array_sum( $amounts ) ); $parent_item->set_total( array_sum( $amounts ) );
				$parent->add_item( $parent_item );
				$context_data = $order_context ? KERP_Modules_Orders_Module::instance()->apply_installment_context( $parent, $order_context ) : [];
				$parent->calculate_totals(); $parent->save();
			}
			$plan['parent_order_id'] = $parent->get_id();
			if ( ! KERP_Modules_Installment_Management_Store::update( $id, [ 'plan' => $plan ] ) ) { throw new RuntimeException( 'ذخیره سفارش اصلی ناموفق بود.' ); }
			$taxes = [ 'total' => [], 'subtotal' => [] ];
			$gross_parts = $existing_parent ? self::split( (float) $parent->get_total(), $plan['steps'], wc_get_price_decimals() ) : [];
			$tax_parts = [];
			if ( $existing_parent ) { foreach ( $parent->get_items( 'tax' ) as $tax ) { $tax_parts[$tax->get_rate_id()] = self::split( (float) $tax->get_tax_total(), $plan['steps'], wc_get_price_decimals() ); } }
			foreach ( $plan['steps'] as $index => $step ) {
				$order = wc_create_order( [ 'customer_id' => $user_id, 'parent' => $parent->get_id(), 'created_via' => 'kerp_installment_payment', 'status' => 'pending' ] );
				if ( is_wp_error( $order ) ) { throw new RuntimeException( $order->get_error_message() ); }
				$created[] = $order->get_id();
				$order->set_address( $existing_parent ? $parent->get_address( 'billing' ) : $customer->get_billing(), 'billing' );
				$item = new WC_Order_Item_Product(); $item->set_product( $product ); $item->set_quantity( 1 );
				$item->set_name( $product->get_name() . ' — قسط ' . ( $index + 1 ) . ' / ' . count( $plan['steps'] ) );
				$item->set_subtotal( $amounts[ $index ] ); $item->set_total( $amounts[ $index ] ); $order->add_item( $item );
				$order->update_meta_data( '_kerp_installment_contract', $id );
				$order->update_meta_data( '_kerp_installment_parent_order', $parent->get_id() );
				$order->update_meta_data( 'marketer_id', $assignee );
				$order->update_meta_data( '_kerp_installment_stage', $index + 1 );
				$order->update_meta_data( '_kerp_installment_due', $now + $step['days'] * DAY_IN_SECONDS );
				if ( $order_context ) { KERP_Modules_Orders_Module::instance()->apply_installment_context( $order, $order_context ); }
				if ( $existing_parent ) {
					$part_taxes = []; foreach ( $tax_parts as $rate => $parts ) { $part_taxes[$rate] = $parts[$index]; }
					$net = $gross_parts[$index] - array_sum( $part_taxes );
					if ( $net <= 0 ) { throw new RuntimeException( 'مبلغ قسط معتبر نیست.' ); }
					$item->set_total( $net ); $item->set_subtotal( $net ); $item->set_taxes( [ 'total' => $part_taxes, 'subtotal' => $part_taxes ] ); $item->save();
					$order->update_taxes(); $order->calculate_totals( FALSE );
				} else { $order->calculate_totals(); }
				$order->save();
				foreach ( $item->get_taxes() as $kind => $rates ) { foreach ( $rates as $rate => $amount ) { $taxes[ $kind ][ $rate ] = ( $taxes[ $kind ][ $rate ] ?? 0 ) + (float) $amount; } }
				$plan['totals'][ $index ] = (string) $order->get_total();
				$order->add_order_note( sprintf( 'قرارداد اقساط #%d؛ پلن %s؛ قسط %d.', $id, $plan['name'], $index + 1 ) );
				if ( ! KERP_Modules_Installment_Management_Store::update( $id, [ 'orders' => $created, 'plan' => $plan ] ) ) { throw new RuntimeException( 'ذخیره شناسه سفارش‌ها ناموفق بود.' ); }
			}
			// Preserve the exact sum, including tax rounding across the installment orders.
			if ( ! $existing_parent ) {
				$parent_item->set_taxes( $taxes ); $parent_item->save();
				$parent->update_taxes();
				$parent->calculate_totals( FALSE ); $parent->save();
			}
			if ( $order_context ) {
				do_action( 'kerp_orders_save_extra', $parent->get_id(), $context_data['extra'] ?? [], $parent, TRUE );
				do_action( 'kerp_order_created', $parent->get_id(), $parent );
				do_action( 'kerp_orders_after_save', $parent, $context_data, TRUE );
			}
			$followups = KERP_Modules_Installment_Management_Followups::create( KERP_Modules_Installment_Management_Store::get( $id ) );
			if ( is_wp_error( $followups ) ) { throw new RuntimeException( $followups->get_error_message() ); }
			if ( ! KERP_Modules_Installment_Management_Store::update( $id, [ 'status' => 'active' ] ) ) { throw new RuntimeException( 'فعال‌سازی قرارداد انجام نشد.' ); }
			if ( $existing_parent ) {
				$parent->update_meta_data( '_kerp_installment_contract', $id );
				$parent->update_meta_data( '_kerp_installment_is_parent', 1 );
				$parent->set_status( 'await-install' ); $parent->save();
			}
			return KERP_Modules_Installment_Management_Store::get( $id );
		} catch ( Throwable $error ) {
			if ( $existing_parent && $parent instanceof WC_Order && ! $parent->is_paid() ) {
				$parent->delete_meta_data( '_kerp_installment_contract' );
				$parent->delete_meta_data( '_kerp_installment_is_parent' );
				$parent->set_status( 'pre-invoice' ); $parent->save();
			}
			if ( $id ) { $failed_contract = KERP_Modules_Installment_Management_Store::get( $id ); if ( $failed_contract ) { KERP_Modules_Installment_Management_Followups::sync( $failed_contract, TRUE ); } }
			if ( ! $existing_parent && $parent instanceof WC_Order && ! $parent->is_paid() ) { $parent->update_status( 'cancelled', 'ساخت قرارداد اقساط کامل نشد.' ); }
			foreach ( $created as $order_id ) { $order = wc_get_order( $order_id ); if ( $order && ! $order->is_paid() ) { $order->update_status( 'cancelled', 'ساخت قرارداد اقساط کامل نشد.' ); } }
			if ( $id ) { KERP_Modules_Installment_Management_Store::update( $id, [ 'status' => 'failed', 'orders' => $created ] ); }
			return new WP_Error( 'create', $error->getMessage() );
		} finally { KERP_Modules_Installment_Management_Store::unlock( $lock ); }
	}

	public static function paid( array $contract, int $index ): bool {
		$order = ! empty( $contract['orders'][ $index ] ) && function_exists( 'wc_get_order' ) ? wc_get_order( $contract['orders'][ $index ] ) : FALSE;
		return $order && self::valid_order( $contract, $index, $order ) && $order->is_paid() && (float) $order->get_total_refunded() <= 0;
	}
	public static function valid_order( array $contract, int $index, $order ): bool {
		return (int) $order->get_customer_id() === (int) $contract['user_id']
			&& (int) $order->get_meta( '_kerp_installment_contract' ) === (int) $contract['id']
			&& (int) $order->get_meta( '_kerp_installment_stage' ) === $index + 1
			&& isset( $contract['plan']['totals'][ $index ], $contract['plan']['currency'] )
			&& (string) $order->get_currency() === (string) $contract['plan']['currency']
			&& abs( (float) $order->get_total() - (float) $contract['plan']['totals'][ $index ] ) < 0.000001;
	}
	public static function stage( array $contract ): int {
		if ( $contract['status'] !== 'active' ) { return 0; }
		$count = 0;
		foreach ( $contract['plan']['steps'] as $i => $step ) { if ( ! self::paid( $contract, $i ) ) { break; } $count++; }
		return $count;
	}
	public static function order_changed( int $order_id ): void {
		$order = wc_get_order( $order_id );
		if ( $order && $order->get_meta( '_kerp_installment_contract' ) ) { self::sync( (int) $order->get_meta( '_kerp_installment_contract' ) ); }
	}
	public static function sync( int $id ): void {
		static $running = [];
		if ( isset( $running[ $id ] ) ) { return; }
		$contract = KERP_Modules_Installment_Management_Store::get( $id );
		if ( ! $contract || $contract['status'] !== 'active' ) { return; }
		$lock = 'user_' . $contract['user_id'];
		if ( ! KERP_Modules_Installment_Management_Store::lock( $lock ) ) { return; }
		$running[ $id ] = TRUE;
		try {
			$contract = KERP_Modules_Installment_Management_Store::get( $id );
			$stage = self::stage( $contract ); $state = $contract['state'];
			$previous = (int) ( $state['stage'] ?? 0 );
			if ( function_exists( 'ld_update_course_access' ) && ( ( $previous === 0 && $stage > 0 ) || ( $previous > 0 && $stage === 0 ) ) ) {
				ld_update_course_access( (int) $contract['user_id'], (int) $contract['course_id'], $stage === 0 );
			}
			$taxonomy = KERP_Modules_Customers_Taxonomies::instance();
			$tags = (array) $taxonomy->get_customer_terms( (int) $contract['user_id'], 'tag' );
			$owned = array_filter( (array) get_user_meta( (int) $contract['user_id'], '_kerp_installment_owned_tags', TRUE ) ); $desired = [];
			// A shared tag can be required by several courses. Compute their union before removing it.
			foreach ( KERP_Modules_Installment_Management_Store::for_user( (int) $contract['user_id'] ) as $other ) {
				$other_stage = self::stage( $other );
				foreach ( $other['plan']['steps'] as $i => $step ) {
					if ( $i < $other_stage && $step['tag'] !== '' && ( $other['plan']['tag_mode'] === 'append' || $i === $other_stage - 1 ) ) { $desired[] = $step['tag']; }
				}
			}
			$tags = array_values( array_diff( $tags, array_diff( $owned, $desired ) ) );
			$new_owned = array_unique( array_merge( array_intersect( $owned, $desired ), array_diff( $desired, $tags ) ) );
			$tags = array_values( array_unique( array_merge( $tags, $desired ) ) );
			$taxonomy->set_customer_terms( (int) $contract['user_id'], 'tag', $tags );
			update_user_meta( (int) $contract['user_id'], '_kerp_installment_owned_tags', array_values( $new_owned ) );
			$state['owned_tags'] = array_values( $new_owned ); $state['stage'] = $stage;
			KERP_Modules_Installment_Management_Store::update( $id, [ 'state' => $state ] );
			KERP_Modules_Installment_Management_Followups::sync( $contract );
			$parent = ! empty( $contract['plan']['parent_order_id'] ) ? wc_get_order( $contract['plan']['parent_order_id'] ) : FALSE;
			if ( $parent && (int) $parent->get_meta( '_kerp_installment_contract' ) === $id ) {
				$status = $stage === count( $contract['orders'] ) ? 'completed' : 'await-install';
				if ( ! $parent->has_status( $status ) ) { $parent->update_status( $status, 'همگام‌سازی وضعیت سفارش با پرداخت اقساط.' ); }
			}
		} finally { unset( $running[ $id ] ); KERP_Modules_Installment_Management_Store::unlock( $lock ); }
	}
}
