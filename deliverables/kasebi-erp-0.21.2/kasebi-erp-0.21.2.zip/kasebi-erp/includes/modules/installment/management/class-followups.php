<?php
defined( 'ABSPATH' ) || exit;

/** Automatic collection tasks use the existing followup records and audit history. */
final class KERP_Modules_Installment_Management_Followups {
	public static function ready( int $assignee ): bool|WP_Error {
		if ( ! KERP_Modules::instance()->is_module_loaded( 'followups' ) ) {
			return new WP_Error( 'followups', 'برای ثبت پیگیری سررسید اقساط، ماژول پیگیری‌ها باید فعال باشد.' );
		}
		if ( $assignee <= 0 || ( ! user_can( $assignee, 'manage_options' ) && ! ( KERP_Modules_Employees_Query::instance()->get_employee( $assignee ) instanceof WP_User ) ) ) {
			return new WP_Error( 'followups', 'مسئول پیگیری اقساط باید مدیر سایت یا یکی از کارکنان ERP باشد.' );
		}
		return TRUE;
	}
	public static function types( array $types ): array {
		$types['installment_payment'] = [ 'key' => 'installment_payment', 'label' => 'وصول قسط', 'icon' => 'ni ni-wallet', 'color' => 'info', 'order' => 65, 'active' => 1 ];
		return $types;
	}
	private static function record( int $contract_id, int $stage ): ?array {
		global $wpdb;
		// Recovery also works if the process stops before the order metadata is saved.
		$token = '"source_key":"kerp-installment:' . $contract_id . ':' . $stage . '"';
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . KERP_Modules_Followups_Module::table() . ' WHERE metadata LIKE %s ORDER BY id LIMIT 1', '%' . $wpdb->esc_like( $token ) . '%' ), ARRAY_A );
	}
	/** Caller holds the contract customer's lock. Only new contracts create tasks. */
	public static function create( array $contract ): bool|WP_Error {
		$module = KERP_Modules_Followups_Module::instance();
		foreach ( $contract['orders'] as $index => $order_id ) {
			if ( $index === 0 && (int) $contract['plan']['steps'][ $index ]['days'] === 0 ) { continue; }
			if ( self::record( (int) $contract['id'], $index + 1 ) ) { continue; }
			$main_id = (int) $contract['plan']['parent_order_id'];
			$due = (int) $contract['created_at'] + (int) $contract['plan']['steps'][ $index ]['days'] * DAY_IN_SECONDS;
			$result = $module->save( [
				'customer_id' => (int) $contract['user_id'], 'assignee_id' => (int) $contract['created_by'],
				'type_key' => 'installment_payment', 'title' => sprintf( 'پیگیری قسط %d سفارش #%d', $index + 1, $main_id ),
				'description' => sprintf( 'مبلغ قسط: %s — %s', wp_strip_all_tags( wc_price( $contract['plan']['totals'][ $index ], [ 'currency' => $contract['plan']['currency'] ] ) ), esc_html( $contract['plan']['name'] ) ) . '<br><a href="' . esc_url( home_url( '/erp/orders/' . $main_id . '/edit/' ) ) . '">مشاهده سفارش و ثبت پرداخت</a>',
				'due_at' => wp_date( 'Y-m-d H:i:s', $due ), 'priority' => 'normal', 'status' => 'pending',
				'metadata' => [ 'source_key' => 'kerp-installment:' . $contract['id'] . ':' . ( $index + 1 ), 'contract_id' => (int) $contract['id'], 'order_id' => $main_id, 'payment_order_id' => (int) $order_id, 'stage' => $index + 1 ],
			] );
			if ( is_wp_error( $result ) ) { return $result; }
		}
		return TRUE;
	}
	public static function sync( array $contract, bool $cancel = FALSE ): void {
		if ( empty( $contract['plan']['automatic_followups'] ) || ! KERP_Modules::instance()->is_module_loaded( 'followups' ) ) { return; }
		foreach ( $contract['orders'] as $index => $order_id ) {
			$record = self::record( (int) $contract['id'], $index + 1 );
			if ( ! $record || $record['status'] !== 'pending' ) { continue; }
			if ( $cancel ) { KERP_Modules_Followups_Module::instance()->cancel( (int) $record['id'], 'ساخت قرارداد اقساط کامل نشد.' ); }
			elseif ( KERP_Modules_Installment_Management_Service::paid( $contract, $index ) ) {
				KERP_Modules_Followups_Module::instance()->complete( (int) $record['id'], 'پرداخت قسط تأیید شد؛ تکمیل خودکار پیگیری وصول.' );
			}
		}
	}
}
