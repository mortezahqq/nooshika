<?php
defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Installment_Management_Api {
	public static function boot(): void {
		foreach ( [ 'save_plan', 'delete_plan', 'plan_options', 'bulk_plans', 'create', 'approve', 'sync', 'products', 'courses' ] as $method ) { add_action( 'kasebi_ajax_installments_' . $method, [ self::class, $method ] ); }
	}
	public static function plan_options(): void {
		self::guard( 'manage_settings' );
		$results = [];
		if ( self::text( 'kind' ) === 'product' ) {
			$product = wc_get_product( absint( self::text( 'product_id' ) ) );
			if ( ! $product || $product->get_status() !== 'publish' ) { self::error( 'محصول معتبر نیست.' ); }
			$ids = array_merge( (array) get_post_meta( $product->get_id(), '_related_course', TRUE ), (array) get_post_meta( $product->get_parent_id() ?: $product->get_id(), '_related_course', TRUE ) );
			foreach ( array_unique( array_filter( array_map( 'absint', $ids ) ) ) as $id ) {
				if ( get_post_type( $id ) === 'sfwd-courses' && get_post_status( $id ) === 'publish' ) { $results[] = [ 'id' => $id, 'text' => get_the_title( $id ) ]; }
			}
		} else {
			$id = absint( self::text( 'course_id' ) );
			if ( get_post_type( $id ) !== 'sfwd-courses' || get_post_status( $id ) !== 'publish' ) { self::error( 'دوره معتبر نیست.' ); }
			foreach ( KERP_Modules_Installment_Management_Settings::lessons( $id ) as $index => $lesson ) { $results[] = [ 'id' => $lesson, 'text' => ( $index + 1 ) . '. ' . get_the_title( $lesson ) ]; }
		}
		wp_send_json( [ 'status' => 'success', 'results' => $results ] );
	}
	public static function delete_plan(): void {
		self::guard( 'manage_settings' );
		if ( ! KERP_Modules_Installment_Management_Store::lock( 'settings' ) ) { self::error( 'تنظیمات در حال ذخیره است؛ دوباره تلاش کنید.' ); }
		$id = self::text( 'plan_id' );
		try {
			$plans = KERP_Modules_Installment_Management_Settings::all();
			$found = isset( $plans[ $id ] );
			if ( $found ) {
				update_option( 'kerp_installment_last_plan_id', max( (int) get_option( 'kerp_installment_last_plan_id', 0 ), max( array_map( 'intval', array_keys( $plans ) ) ) ), FALSE );
				unset( $plans[ $id ] );
				update_option( KERP_Modules_Installment_Management_Settings::OPTION, $plans, FALSE );
			}
		} finally { KERP_Modules_Installment_Management_Store::unlock( 'settings' ); }
		if ( ! $found ) { self::error( 'پلن پیدا نشد.' ); }
		self::success( 'پلن حذف شد. قراردادهای قبلی حفظ شدند.', '/erp/settings/installments/' );
	}
	private static function search_term(): string {
		if ( ! is_user_logged_in() || ! KERP_App::instance()->current_user_has_access() || ! kerp_can( 'installments.manage_settings', 'action' ) ) { self::error( 'دسترسی لازم را ندارید.' ); }
		$search = self::text( 'search' );
		if ( mb_strlen( $search ) < 2 ) { wp_send_json( [ 'results' => [] ] ); exit; }
		return $search;
	}
	public static function products(): void {
		$search = self::search_term();
		$ids = WC_Data_Store::load( 'product' )->search_products( $search, '', TRUE, FALSE, 50 );
		$results = [];
		foreach ( $ids as $id ) {
			$product = wc_get_product( $id );
			if ( ! $product ) { continue; }
			$results[] = [ 'id' => $product->get_id(), 'text' => wp_strip_all_tags( $product->get_formatted_name() ) ];
		}
		wp_send_json( [ 'results' => $results ] );
	}
	public static function courses(): void {
		$search = self::search_term();
		$args = [ 'post_type' => 'sfwd-courses', 'post_status' => 'publish', 'posts_per_page' => 30, 'orderby' => 'title', 'order' => 'ASC' ];
		if ( ctype_digit( $search ) ) { $args['p'] = (int) $search; } else { $args['s'] = $search; }
		$results = [];
		foreach ( get_posts( $args ) as $course ) {
			$results[] = [ 'id' => $course->ID, 'text' => $course->post_title . ' (#' . $course->ID . ')' ];
		}
		wp_send_json( [ 'results' => $results ] );
	}
	private static function text( string $key ): string { return KERP_Modules_Installment_Management_Settings::text( wp_unslash( $_POST ), $key ); }
	private static function guard( string $permission ): void {
		if ( ! is_user_logged_in() || ! KERP_App::instance()->current_user_has_access() || ! kerp_can( 'installments.' . $permission, 'action' ) ) { self::error( 'دسترسی لازم را ندارید.' ); }
		if ( ! wp_verify_nonce( self::text( 'installment_nonce' ), 'kerp_installments' ) ) { self::error( 'اعتبار فرم منقضی شده است؛ صفحه را تازه‌سازی کنید.' ); }
	}
	public static function customer_allowed( int $user_id ): bool {
		if ( ! get_userdata( $user_id ) ) { return FALSE; }
		$scope = kerp_list_scope( 'customers' );
		return $scope === 'all' || ( $scope === 'own' && (int) get_user_meta( $user_id, 'owner_id', TRUE ) === get_current_user_id() );
	}
	public static function save_plan(): void {
		self::guard( 'manage_settings' );
		if ( ! KERP_Modules_Installment_Management_Store::lock( 'settings' ) ) { self::error( 'تنظیمات در حال ذخیره است؛ دوباره تلاش کنید.' ); }
		try { $result = KERP_Modules_Installment_Management_Settings::save( wp_unslash( $_POST ) ); }
		finally { KERP_Modules_Installment_Management_Store::unlock( 'settings' ); }
		if ( is_wp_error( $result ) ) {
			$tabs = [ 'plan' => 'general', 'course' => 'general', 'steps' => 'stages', 'sequence' => 'stages', 'tag' => 'stages', 'total' => 'stages', 'sms' => 'sms' ];
			$tab = $tabs[ $result->get_error_code() ] ?? '';
			if ( $tab === '' ) { self::error( $result->get_error_message() ); }
			wp_send_json( [ 'status' => 'error', 'message' => $result->get_error_message(), 'validation_pane' => 'installment-pane-' . $tab ] );
			return;
		}
		$active_tab = self::text( 'active_tab' );
		$allowed_tabs = KERP_Modules_Installment_Management_SMS::ENABLED ? [ 'general', 'stages', 'sms' ] : [ 'general', 'stages' ];
		if ( ! in_array( $active_tab, $allowed_tabs, TRUE ) ) { $active_tab = 'general'; }
		self::success( 'پلن ذخیره شد. قراردادهای قبلی بدون تغییر باقی می‌مانند.', '/erp/settings/installments/' . rawurlencode( (string) $result ) . '/?tab=' . $active_tab );
	}
	public static function bulk_plans(): void {
		self::guard( 'manage_settings' );
		$ids = array_filter( array_map( 'absint', explode( ',', self::text( 'plan_ids' ) ) ) );
		$operation = self::text( 'operation' );
		if ( ! $ids || ! in_array( $operation, [ 'enable', 'disable' ], TRUE ) ) { self::error( 'پلن و عملیات معتبر را انتخاب کنید.' ); }
		if ( ! KERP_Modules_Installment_Management_Store::lock( 'settings' ) ) { self::error( 'تنظیمات در حال ذخیره است؛ دوباره تلاش کنید.' ); }
		$error = '';
		try {
			$plans = KERP_Modules_Installment_Management_Settings::all();
			foreach ( $ids as $id ) {
				if ( ! isset( $plans[ $id ] ) ) { $error = 'یکی از پلن‌ها پیدا نشد.'; break; }
				if ( $operation === 'enable' ) { $valid = KERP_Modules_Installment_Management_Settings::validate( $plans[ $id ] ); if ( is_wp_error( $valid ) ) { $error = $valid->get_error_message(); break; } }
				$plans[ $id ]['enabled'] = $operation === 'enable';
			}
			if ( $error === '' ) { update_option( KERP_Modules_Installment_Management_Settings::OPTION, $plans, FALSE ); }
		} finally { KERP_Modules_Installment_Management_Store::unlock( 'settings' ); }
		if ( $error !== '' ) { self::error( $error ); }
		self::success( 'وضعیت فروش پلن‌ها به‌روزرسانی شد.', '/erp/settings/installments/' );
	}
	public static function create(): void {
		self::guard( 'create' );
		$user_id = absint( self::text( 'customer_id' ) );
		if ( ! self::customer_allowed( $user_id ) || ! kerp_can( 'orders.create', 'action' ) ) { self::error( 'اجازه ثبت سفارش برای این مشتری را ندارید.' ); }
		$request = self::text( 'request_id' );
		if ( ! wp_is_uuid( $request ) ) { self::error( 'شناسه درخواست معتبر نیست.' ); }
		$result = KERP_Modules_Installment_Management_Service::create( $user_id, self::text( 'plan_id' ), $request );
		if ( is_wp_error( $result ) ) { self::error( $result->get_error_message() ); }
		KERP_Modules_Installment_Management_SMS::send_contract( (int) $result['id'] );
		self::success( 'قرارداد و سفارش‌های پرداخت ساخته شدند؛ قسط اول در انتظار پرداخت یا تأیید است.', '/erp/customers/' . $user_id . '/?tab=installments' );
	}
	public static function approve(): void {
		self::guard( 'approve' );
		$id = absint( self::text( 'contract_id' ) ); $stage = absint( self::text( 'stage' ) ); $reference = self::text( 'reference' );
		$contract = KERP_Modules_Installment_Management_Store::get( $id );
		if ( ! $contract || $contract['status'] !== 'active' || ! self::customer_allowed( (int) $contract['user_id'] ) || ! isset( $contract['orders'][ $stage - 1 ] ) ) { self::error( 'قرارداد یا مرحله در محدوده دسترسی شما نیست.' ); }
		$lock = 'approve_' . $id;
		if ( ! KERP_Modules_Installment_Management_Store::lock( $lock ) ) { self::error( 'درخواست تأیید دیگری در حال پردازش است.' ); }
		$error = '';
		try {
			$order = wc_get_order( $contract['orders'][ $stage - 1 ] );
			if ( $order && $order->get_meta( '_kerp_payment_id' ) ) { $error = 'این قسط سند پرداخت دارد؛ بررسی آن را از صفحه پرداخت‌ها انجام دهید.'; }
			elseif ( ! $order || ! KERP_Modules_Installment_Management_Service::valid_order( $contract, $stage - 1, $order ) ) { $error = 'مشتری، مبلغ یا مشخصات سفارش قسط با قرارداد مطابقت ندارد.'; }
			elseif ( ! KERP_Modules_Installment_Management_Service::paid( $contract, $stage - 1 ) ) {
				if ( $reference === '' || ! $order->has_status( [ 'pending', 'on-hold', 'failed' ] ) || (float) $order->get_total_refunded() > 0 ) { $error = 'شرح دریافت / شماره پیگیری لازم است؛ سفارش لغوشده یا مرجوع‌شده قابل تأیید نیست.'; }
				else {
					$order->update_meta_data( '_kerp_installment_approved_by', get_current_user_id() );
					$order->update_meta_data( '_kerp_installment_reference', $reference ); $order->save();
					$order->add_order_note( sprintf( 'تأیید دریافت قسط توسط کارشناس #%d؛ شرح: %s', get_current_user_id(), $reference ) );
					$order->payment_complete();
					if ( ! $order->is_paid() ) { $error = 'وضعیت سفارش به پرداخت‌شده تغییر نکرد؛ سفارش را بررسی کنید.'; }
				}
			}
		} finally { KERP_Modules_Installment_Management_Store::unlock( $lock ); }
		if ( $error !== '' ) { self::error( $error ); }
		KERP_Modules_Installment_Management_Service::sync( $id );
		self::success( 'دریافت قسط تأیید شد. دسترسی بر اساس اقساط پرداخت‌شده به ترتیب باز می‌شود.', '/erp/customers/' . $contract['user_id'] . '/?tab=installments' );
	}
	public static function sync(): void {
		self::guard( 'approve' );
		$user_id = absint( self::text( 'customer_id' ) );
		$ids = array_values( array_unique( array_filter( array_map( 'absint', explode( ',', self::text( 'contract_ids' ) ) ) ) ) );
		if ( ! self::customer_allowed( $user_id ) || ! $ids || count( $ids ) > 100 ) { self::error( 'انتخاب قرارداد معتبر نیست.' ); }
		foreach ( $ids as $id ) { $contract = KERP_Modules_Installment_Management_Store::get( $id ); if ( ! $contract || (int) $contract['user_id'] !== $user_id ) { self::error( 'یکی از قراردادها متعلق به این مشتری نیست.' ); } }
		foreach ( $ids as $id ) { KERP_Modules_Installment_Management_Service::sync( $id ); KERP_Modules_Installment_Management_SMS::send_contract( $id ); }
		self::success( 'دسترسی و تگ‌ها با پرداخت‌های ثبت‌شده همگام شدند.', '/erp/customers/' . $user_id . '/?tab=installments' );
	}
	private static function error( string $message ): never { wp_send_json( [ 'status' => 'error', 'message' => $message, 'msg' => $message ] ); exit; }
	private static function success( string $message, string $page ): never {
		parse_str( (string) wp_parse_url( $page, PHP_URL_QUERY ), $query );
		wp_send_json( array_merge( [ 'status' => 'success', 'message' => $message, 'msg' => $message ], KERP_Api_Page_Content::build_page_response( $page, $query, TRUE ) ) ); exit;
	}
}
