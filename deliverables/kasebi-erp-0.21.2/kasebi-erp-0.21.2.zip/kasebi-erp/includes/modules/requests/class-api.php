<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Requests_Api {
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {
		$this->register_hooks();
	}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public function save(): void {
		$request_id = absint(
			$_POST['request_id'] ?? 0
		);
		
		$this->guard(
			$request_id > 0
				? 'requests.edit'
				: 'requests.create'
		);
		
		$existing = $request_id > 0
			? $this->guard_item_scope( $request_id )
			: NULL;
		$requester_context = sanitize_key(
			$this->post_text( 'requester_context' )
		) ?: 'employee';
		$requester_id = absint(
			$_POST['requester_id'] ?? 0
		);
		$can_create_for_others = kerp_can(
			'requests.create_for_others',
			'action'
		);

		if ( $request_id > 0 && is_array( $existing ) ) {
			$requester_context = sanitize_key(
				(string) ( $existing['requester_context'] ?? 'employee' )
			) ?: 'employee';
			$requester_id = absint(
				$existing['requester_id'] ?? 0
			);
		} elseif ( ! $can_create_for_others ) {
			if ( $requester_context !== 'employee' ) {
				$this->error(
					__( 'اجازه ثبت درخواست برای این نوع درخواست‌دهنده را ندارید.', 'kasebi-erp' )
				);
			}

			$requester_id = get_current_user_id();
		}

		if ( $requester_id <= 0 ) {
			$this->error(
				__( 'درخواست‌دهنده معتبر نیست.', 'kasebi-erp' )
			);
		}

		if (
			! KERP_Modules_Requests_Form::instance()->is_valid_requester(
				$requester_id,
				$requester_context
			)
		) {
			$this->error(
				__( 'درخواست‌دهنده معتبر نیست.', 'kasebi-erp' )
			);
		}
		
		$type_key = $this->post_text( 'type_key' );
		$type     = KERP_Modules_Requests_Settings::instance()
		                                          ->get_type( $type_key );
		
		if ( ! is_array( $type ) ) {
			$this->error(
				__( 'نوع درخواست معتبر نیست.', 'kasebi-erp' )
			);
		}

		if (
			! KERP_Modules_Requests_Settings::instance()->type_supports_context(
				$type,
				$requester_context
			)
		) {
			$this->error(
				__( 'این نوع درخواست برای درخواست‌دهنده انتخاب‌شده قابل استفاده نیست.', 'kasebi-erp' )
			);
		}
		
		$assignee_id = absint(
			$_POST['assignee_id'] ?? 0
		);
		
		if (
			$assignee_id <= 0
			&& ! empty( $type['default_assignee_id'] )
		) {
			$assignee_id = absint(
				$type['default_assignee_id']
			);
		}
		
		if (
			$request_id > 0
			&& $assignee_id <= 0
			&& is_array( $existing )
		) {
			$assignee_id = absint(
				$existing['assignee_id'] ?? 0
			);
		}
		
		if (
			$request_id > 0
			&& is_array( $existing )
			&& ! kerp_can( 'requests.assign', 'action' )
		) {
			$assignee_id = absint(
				$existing['assignee_id'] ?? 0
			);
		}
		
		if (
			$assignee_id !== absint(
				is_array( $existing )
					? $existing['assignee_id'] ?? 0
					: 0
			)
			&& ! KERP_Modules_Requests_Form::instance()
			                               ->is_valid_reviewer( $assignee_id )
		) {
			$this->error(
				__( 'مسئول بررسی انتخاب‌شده معتبر نیست.', 'kasebi-erp' )
			);
		}
		
		if (
			$request_id === 0
			&& $assignee_id === get_current_user_id()
		) {
			$this->error(
				__( 'نمی‌توانید درخواست را برای خودتان ارسال کنید.', 'kasebi-erp' )
			);
		}
		
		$due_at = KERP_Modules_Requests_Form::instance()
		                                    ->combine_datetime(
			                                    $this->post_text( 'due_date' ),
			                                    $this->post_text( 'due_time' )
		                                    );
		if ( is_wp_error( $due_at ) ) {
			$this->error( $due_at->get_error_message() );
		}
		
		if (
			$due_at === ''
			&& absint( $type['default_due_days'] ?? 0 ) > 0
		) {
			$due_at = current_datetime()
				->modify(
					'+' . absint( $type['default_due_days'] ) . ' days'
				)
				->setTime( 17, 0 )
				->format( 'Y-m-d H:i:s' );
		}
		
		$attachment_value = $_POST['attachment'] ?? '';
		$attachments      = KERP_Modules_Requests_Form::instance()
		                                              ->sanitize_attachments(
			                                              is_array( $attachment_value )
				                                              ? wp_unslash( $attachment_value )
				                                              : $this->post_text( 'attachment' )
		                                              );
		
		$result = KERP_Modules_Requests_Module::instance()->save(
			[
				'type_key'          => $type_key,
				'requester_context' => $requester_context,
				'requester_id'      => $requester_id,
				'assignee_id'  => $assignee_id,
				'title'        => $this->post_text( 'title' ),
				'description'  => $this->post_content( 'description' ),
				'priority'     => $this->post_text( 'priority' )
					?: sanitize_key(
						(string) ( $type['default_priority'] ?? 'normal' )
					),
				'due_at'       => $due_at,
				'metadata'     => [
					'attachments' => $attachments,
				],
			],
			$request_id
		);
		
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		
		$page                        = $this->return_page();
		$page_response               = KERP_Api_Page_Content::build_page_response(
			$page,
			$this->route_query( $page ),
			TRUE
		);
		$page_response['request_id'] = (int) $result;
		
		$this->success(
			$request_id > 0
				? __( 'درخواست با موفقیت ویرایش شد.', 'kasebi-erp' )
				: __( 'درخواست با موفقیت ثبت شد.', 'kasebi-erp' ),
			$page_response
		);
	}
	
	public function assign(): void {
		$this->guard( 'requests.assign' );
		
		$request_id = absint(
			$_POST['request_id'] ?? 0
		);
		
		$this->guard_item_scope( $request_id );
		
		$assignee_id = absint(
			$_POST['assignee_id'] ?? 0
		);
		
		if (
			! KERP_Modules_Requests_Form::instance()
			                            ->is_valid_reviewer( $assignee_id )
		) {
			$this->error(
				__( 'مسئول بررسی انتخاب‌شده معتبر نیست.', 'kasebi-erp' )
			);
		}
		
		$result = KERP_Modules_Requests_Module::instance()->assign(
			$request_id,
			$assignee_id,
			$this->post_content( 'note' )
		);
		
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		
		$this->page_success(
			__( 'مسئول بررسی تغییر کرد.', 'kasebi-erp' )
		);
	}
	
	public function start_review(): void {
		$this->transition(
			'requests.review',
			'reviewing',
			__( 'بررسی درخواست آغاز شد.', 'kasebi-erp' ),
			FALSE
		);
	}
	
	public function request_info(): void {
		$this->transition(
			'requests.request_info',
			'needs_info',
			$this->post_content( 'content' ),
			TRUE
		);
	}
	
	public function respond(): void {
		$this->guard( 'requests.respond' );
		
		$request_id = absint(
			$_POST['request_id'] ?? 0
		);
		$request    = $this->guard_item_scope( $request_id );
		
		if (
			! KERP_Modules_Requests_Query::instance()
			                             ->is_participant( $request )
		) {
			$this->error(
				__( 'فقط طرف‌های درخواست می‌توانند پاسخ ثبت کنند.', 'kasebi-erp' )
			);
		}
		
		$content = $this->post_content( 'content' );
		
		if ( trim( wp_strip_all_tags( $content ) ) === '' ) {
			$this->error(
				__( 'متن پاسخ را وارد کنید.', 'kasebi-erp' )
			);
		}
		
		$attachments = KERP_Modules_Requests_Form::instance()
		                                         ->sanitize_attachments(
			                                         $this->post_text( 'attachment' )
		                                         );
		$result      = KERP_Modules_Requests_Module::instance()->transition(
			$request_id,
			'reviewing',
			$content,
			[ 'attachments' => $attachments ]
		);
		
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		
		KERP_Modules_Requests_History::instance()->add(
			$request_id,
			'responded',
			$content,
			[ 'attachments' => $attachments ]
		);
		
		$this->page_success(
			__( 'پاسخ تکمیلی ثبت شد.', 'kasebi-erp' )
		);
	}
	
	public function approve(): void {
		$this->transition(
			'requests.approve',
			'approved',
			$this->post_content( 'content' ),
			FALSE
		);
	}
	
	public function reject(): void {
		$this->transition(
			'requests.reject',
			'rejected',
			$this->post_content( 'content' ),
			TRUE
		);
	}
	
	public function cancel(): void {
		$this->transition(
			'requests.cancel',
			'cancelled',
			$this->post_content( 'content' ),
			TRUE
		);
	}
	
	public function complete(): void {
		$this->guard( 'requests.complete' );
		
		$request_id = absint(
			$_POST['request_id'] ?? 0
		);
		
		$this->guard_item_scope( $request_id );
		
		$content = $this->post_content( 'content' );
		
		if ( trim( wp_strip_all_tags( $content ) ) === '' ) {
			$this->error(
				__( 'نتیجه انجام درخواست را وارد کنید.', 'kasebi-erp' )
			);
		}
		
		$attachments = KERP_Modules_Requests_Form::instance()
		                                         ->sanitize_attachments(
			                                         $this->post_text( 'attachment' )
		                                         );
		$result      = KERP_Modules_Requests_Module::instance()->transition(
			$request_id,
			'completed',
			$content,
			[ 'attachments' => $attachments ]
		);
		
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		
		$this->page_success(
			__( 'درخواست با موفقیت تکمیل شد.', 'kasebi-erp' )
		);
	}
	
	public function comment(): void {
		$this->guard( 'requests.comment' );
		
		$request_id = absint(
			$_POST['request_id'] ?? 0
		);
		$request    = $this->guard_item_scope( $request_id );
		
		if (
			! KERP_Modules_Requests_Query::instance()
			                             ->is_participant( $request )
			&& ! current_user_can( 'manage_options' )
		) {
			$this->error(
				__( 'فقط طرف‌های درخواست می‌توانند پیام ثبت کنند.', 'kasebi-erp' )
			);
		}
		
		$result = KERP_Modules_Requests_Module::instance()->add_comment(
			$request_id,
			$this->post_content( 'content' ),
			KERP_Modules_Requests_Form::instance()->sanitize_attachments(
				$this->post_text( 'attachment' )
			)
		);
		
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		
		$this->page_success(
			__( 'پیام با موفقیت ثبت شد.', 'kasebi-erp' )
		);
	}
	
	public function delete(): void {
		$this->guard( 'requests.delete' );
		
		$request_id = absint(
			$_POST['request_id']
			?? $_POST['item_id']
			   ?? 0
		);
		
		$this->guard_item_scope( $request_id );
		
		$result = KERP_Modules_Requests_Module::instance()
		                                      ->delete( $request_id );
		
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		
		$page = $this->return_page();
		
		if ( str_contains( $page, '/erp/requests/' . $request_id ) ) {
			$page = '/erp/requests/';
		}
		
		$this->success(
			__( 'درخواست حذف شد.', 'kasebi-erp' ),
			KERP_Api_Page_Content::build_page_response(
				$page,
				$this->route_query( $page ),
				TRUE
			)
		);
	}
	
	public function save_type(): void {
		$this->guard( 'requests.manage_settings' );
		
		$type         = isset( $_POST['type'] )
		                && is_array( $_POST['type'] )
			? wp_unslash( $_POST['type'] )
			: [];
		$original_key = sanitize_key(
			(string) ( $type['original_key'] ?? '' )
		);
		
		$result = KERP_Modules_Requests_Settings::instance()
		                                        ->save_type(
			                                        $type,
			                                        $original_key
		                                        );
		
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		
		$page = '/erp/settings/requests/';
		
		$this->success(
			__( 'نوع درخواست با موفقیت ذخیره شد.', 'kasebi-erp' ),
			KERP_Api_Page_Content::build_page_response(
				$page,
				[],
				TRUE
			)
		);
	}
	
	public function delete_type(): void {
		$this->guard( 'requests.manage_settings' );
		
		$type_key        = sanitize_key(
			$this->post_text( 'type_key' )
				?: $this->post_text( 'item_id' )
		);
		$replacement_key = sanitize_key(
			$this->post_text( 'replacement_key' )
		);
		
		$result = KERP_Modules_Requests_Settings::instance()
		                                        ->delete_type(
			                                        $type_key,
			                                        $replacement_key
		                                        );
		
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		
		$page = '/erp/settings/requests/';
		
		$this->success(
			__( 'نوع درخواست حذف شد.', 'kasebi-erp' ),
			KERP_Api_Page_Content::build_page_response(
				$page,
				[],
				TRUE
			)
		);
	}
	
	private function transition(
		string $permission,
		string $new_status,
		string $content,
		bool $content_required
	): void {
		$this->guard( $permission );
		
		$request_id = absint(
			$_POST['request_id'] ?? 0
		);
		
		$this->guard_item_scope( $request_id );
		
		if (
			$content_required
			&& trim( wp_strip_all_tags( $content ) ) === ''
		) {
			$this->error(
				__( 'توضیحات این عملیات را وارد کنید.', 'kasebi-erp' )
			);
		}
		
		$result = KERP_Modules_Requests_Module::instance()->transition(
			$request_id,
			$new_status,
			$content
		);
		
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		
		$messages = [
			'reviewing'  => __( 'بررسی درخواست آغاز شد.', 'kasebi-erp' ),
			'needs_info' => __( 'درخواست اطلاعات بیشتر ثبت شد.', 'kasebi-erp' ),
			'approved'   => __( 'درخواست تأیید شد.', 'kasebi-erp' ),
			'rejected'   => __( 'درخواست رد شد.', 'kasebi-erp' ),
			'cancelled'  => __( 'درخواست لغو شد.', 'kasebi-erp' ),
		];
		
		$this->page_success(
			$messages[ $new_status ]
			?? __( 'وضعیت درخواست تغییر کرد.', 'kasebi-erp' )
		);
	}
	
	private function guard_item_scope( int $request_id ): array {
		$request = KERP_Modules_Requests_Query::instance()->get(
			$request_id
		);
		
		if ( ! is_array( $request ) ) {
			$this->error(
				__( 'درخواست پیدا نشد.', 'kasebi-erp' )
			);
		}
		
		if (
			! KERP_Modules_Requests_Query::instance()
			                             ->can_view( $request )
		) {
			$this->error(
				__( 'به این درخواست دسترسی ندارید.', 'kasebi-erp' )
			);
		}
		
		return $request;
	}
	
	private function guard( string $permission ): void {
		if ( ! is_user_logged_in() ) {
			$this->error(
				__( 'برای انجام این عملیات وارد حساب کاربری شوید.', 'kasebi-erp' )
			);
		}
		
		if ( ! KERP_App::instance()->current_user_has_access() ) {
			$this->error(
				__( 'به سامانه دسترسی ندارید.', 'kasebi-erp' )
			);
		}
		
		if ( ! kerp_can( $permission, 'action' ) ) {
			$this->error(
				__( 'دسترسی لازم را ندارید.', 'kasebi-erp' )
			);
		}
	}
	
	private function return_page(): string {
		$page = $this->post_text( 'return_page' )
			?: $this->post_text( 'page' );
		
		return str_starts_with( $page, '/erp/' )
			? $page
			: '/erp/requests/';
	}
	
	private function route_query( string $page ): array {
		$query = wp_parse_url( $page, PHP_URL_QUERY );
		
		if ( ! is_string( $query ) || $query === '' ) {
			return [];
		}
		
		parse_str( $query, $args );
		
		return is_array( $args ) ? $args : [];
	}
	
	private function post_text( string $key ): string {
		if (
			! isset( $_POST[ $key ] )
			|| is_array( $_POST[ $key ] )
		) {
			return '';
		}
		
		return sanitize_text_field(
			wp_unslash( $_POST[ $key ] )
		);
	}
	
	private function post_content( string $key ): string {
		if (
			! isset( $_POST[ $key ] )
			|| is_array( $_POST[ $key ] )
		) {
			return '';
		}
		
		return wp_kses_post(
			wp_unslash( $_POST[ $key ] )
		);
	}
	
	private function page_success( string $message ): never {
		$page = $this->return_page();
		
		$this->success(
			$message,
			KERP_Api_Page_Content::build_page_response(
				$page,
				$this->route_query( $page ),
				TRUE
			)
		);
	}
	
	private function success(
		string $message,
		array $data = []
	): never {
		wp_send_json(
			array_merge(
				[
					'status'  => 'success',
					'message' => $message,
					'msg'     => $message,
				],
				$data
			)
		);
	}
	
	private function error(
		string $message,
		array $data = []
	): never {
		wp_send_json(
			array_merge(
				[
					'status'  => 'error',
					'message' => $message,
					'msg'     => $message,
				],
				$data
			)
		);
	}
	
	private function register_hooks(): void {
		add_action(
			'kasebi_ajax_requests_save',
			[ $this, 'save' ]
		);
		add_action(
			'kasebi_ajax_requests_assign',
			[ $this, 'assign' ]
		);
		add_action(
			'kasebi_ajax_requests_start_review',
			[ $this, 'start_review' ]
		);
		add_action(
			'kasebi_ajax_requests_request_info',
			[ $this, 'request_info' ]
		);
		add_action(
			'kasebi_ajax_requests_respond',
			[ $this, 'respond' ]
		);
		add_action(
			'kasebi_ajax_requests_approve',
			[ $this, 'approve' ]
		);
		add_action(
			'kasebi_ajax_requests_reject',
			[ $this, 'reject' ]
		);
		add_action(
			'kasebi_ajax_requests_cancel',
			[ $this, 'cancel' ]
		);
		add_action(
			'kasebi_ajax_requests_complete',
			[ $this, 'complete' ]
		);
		add_action(
			'kasebi_ajax_requests_comment',
			[ $this, 'comment' ]
		);
		add_action(
			'kasebi_ajax_requests_delete',
			[ $this, 'delete' ]
		);
		add_action(
			'kasebi_ajax_requests_save_type',
			[ $this, 'save_type' ]
		);
		add_action(
			'kasebi_ajax_requests_delete_type',
			[ $this, 'delete_type' ]
		);
	}
	
}
