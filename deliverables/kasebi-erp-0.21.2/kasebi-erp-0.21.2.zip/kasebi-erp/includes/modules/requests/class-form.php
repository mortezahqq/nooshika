<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Requests_Form {
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public function get_reviewer_options(
		int $exclude_user_id = 0
	): array {
		global $wpdb;
		
		$exclude_user_id = $exclude_user_id < 0
			? 0
			: (
			$exclude_user_id > 0
				? $exclude_user_id
				: get_current_user_id()
			);
		
		$user_ids = [];
		
		if ( class_exists( 'KERP_Services_Access' ) ) {
			$access_table = KERP_Services_Access::table();
			$employee_ids = $wpdb->get_col(
				"SELECT DISTINCT user_id
				FROM {$access_table}
				WHERE role_key IS NOT NULL
				AND role_key <> ''"
			);
			
			$user_ids = array_merge(
				$user_ids,
				(array) $employee_ids
			);
		}
		
		$manager_ids = get_users(
			[
				'capability' => 'manage_options',
				'fields'     => 'ids',
				'number'     => 500,
				'orderby'    => 'display_name',
				'order'      => 'ASC',
			]
		);
		
		$user_ids = array_merge(
			$user_ids,
			(array) $manager_ids
		);
		
		if ( is_multisite() ) {
			foreach ( get_super_admins() as $user_login ) {
				$manager = get_user_by( 'login', $user_login );
				
				if ( $manager instanceof WP_User ) {
					$user_ids[] = (int) $manager->ID;
				}
			}
		}
		
		$user_ids = array_values(
			array_unique(
				array_filter(
					array_map(
						'absint',
						$user_ids
					)
				)
			)
		);
		
		$options = [];
		
		foreach ( $user_ids as $user_id ) {
			if (
				$exclude_user_id > 0
				&& $user_id === $exclude_user_id
			) {
				continue;
			}
			
			$user = get_userdata( $user_id );
			
			if ( ! $user instanceof WP_User ) {
				continue;
			}
			
			$label = get_user_name_by_id( $user_id );
			
			if (
				user_can( $user, 'manage_options' )
				|| is_multisite() && is_super_admin( $user_id )
			) {
				$label = sprintf(
					__( '%s — مدیرکل', 'kasebi-erp' ),
					$label
				);
			}
			
			$options[ $user_id ] = $label;
		}
		
		$options = apply_filters(
			'kerp_requests_reviewer_options',
			$options,
			$exclude_user_id
		);
		
		if ( ! is_array( $options ) ) {
			return [];
		}
		
		if ( $exclude_user_id > 0 ) {
			unset( $options[ $exclude_user_id ] );
		}
		
		asort(
			$options,
			SORT_NATURAL | SORT_FLAG_CASE
		);
		
		return $options;
	}
	
	public function get_requester_options( string $context = '' ): array {
		global $wpdb;
		
		$context = sanitize_key( $context );
		$table   = KERP_Modules_Requests_Module::table();
		
		if ( $context !== '' ) {
			$rows = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT DISTINCT requester_context, requester_id
					FROM {$table}
					WHERE requester_context = %s
					AND requester_id > 0
					ORDER BY requester_id ASC",
					$context
				),
				ARRAY_A
			);
		} else {
			$rows = $wpdb->get_results(
				"SELECT DISTINCT requester_context, requester_id
				FROM {$table}
				WHERE requester_id > 0
				ORDER BY requester_context ASC, requester_id ASC",
				ARRAY_A
			);
		}
		
		$options = [];
		
		foreach ( (array) $rows as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			
			$user_id     = absint( $row['requester_id'] ?? 0 );
			$row_context = sanitize_key(
				(string) ( $row['requester_context'] ?? 'employee' )
			) ?: 'employee';
			
			if ( $user_id <= 0 ) {
				continue;
			}
			
			$label = $this->get_requester_label( $user_id, $row_context );
			
			if ( $label === '' ) {
				continue;
			}
			
			if ( $context === '' && $row_context === 'customer' ) {
				$label = sprintf(
					__( '%1$s — %2$s', 'kasebi-erp' ),
					$label,
					KERP_Modules_Customers_Settings::instance()->get_singular_label()
				);
			}
			
			$options[ $user_id ] = $label;
		}
		
		asort(
			$options,
			SORT_NATURAL | SORT_FLAG_CASE
		);
		
		$options = apply_filters(
			'kerp_requests_requester_options',
			$options,
			$context
		);
		
		return is_array( $options ) ? $options : [];
	}
	
	public function get_requester_label( int $requester_id, string $context ): string {
		$requester_id = absint( $requester_id );
		$context      = sanitize_key( $context ) ?: 'employee';
		
		if ( $requester_id <= 0 ) {
			return '';
		}
		
		$label = get_user_name_by_id( $requester_id );
		
		if ( $label === '' ) {
			return '';
		}
		
		return (string) apply_filters(
			'kerp_request_requester_label',
			$label,
			$requester_id,
			$context
		);
	}
	
	public function get_requester_profile_url( int $requester_id, string $context ): string {
		$requester_id = absint( $requester_id );
		$context      = sanitize_key( $context ) ?: 'employee';
		
		if ( $requester_id <= 0 ) {
			return '';
		}
		
		$url = '';
		
		if ( $context === 'customer' ) {
			$url = '/erp/customers/' . $requester_id . '/?tab=requests';
		} elseif (
			$context === 'employee'
			&& class_exists( 'KERP_Modules_Employees_Query' )
			&& KERP_Modules_Employees_Query::instance()->get_employee( $requester_id ) instanceof WP_User
		) {
			$url = '/erp/employees/' . $requester_id . '/?tab=requests';
		}
		
		return (string) apply_filters(
			'kerp_request_requester_profile_url',
			$url,
			$requester_id,
			$context
		);
	}
	
	public function is_valid_requester( int $requester_id, string $context ): bool {
		$requester_id = absint( $requester_id );
		$context      = sanitize_key( $context ) ?: 'employee';
		
		if ( $requester_id <= 0 ) {
			return FALSE;
		}
		
		if ( $context === 'customer' ) {
			$valid = class_exists( 'KERP_Modules_Customers_Query' )
			         && KERP_Modules_Customers_Query::instance()->get_customer( $requester_id ) instanceof WP_User;
		} elseif ( $context === 'employee' ) {
			$valid = get_userdata( $requester_id ) instanceof WP_User;
		} else {
			$valid = FALSE;
		}
		
		return (bool) apply_filters(
			'kerp_request_is_valid_requester',
			$valid,
			$requester_id,
			$context
		);
	}
	
	public function is_valid_reviewer( int $user_id ): bool {
		if ( $user_id <= 0 || $user_id === get_current_user_id() ) {
			return FALSE;
		}
		
		$options = $this->get_reviewer_options();
		
		return isset( $options[ $user_id ] );
	}
	
	public function sanitize_attachments(
		string|array $value
	): array {
		if ( is_string( $value ) ) {
			$value = preg_split(
				'/\s*,\s*/',
				trim( $value ),
				- 1,
				PREG_SPLIT_NO_EMPTY
			);
		}
		
		$attachments = [];
		
		foreach ( (array) $value as $attachment_url ) {
			if ( ! is_scalar( $attachment_url ) ) {
				continue;
			}
			
			$attachment_url = esc_url_raw(
				trim( (string) $attachment_url )
			);
			
			if ( $attachment_url === '' ) {
				continue;
			}
			
			$attachments[] = $attachment_url;
		}
		
		return array_values(
			array_unique( $attachments )
		);
	}
	
	public function get_attachment_items(
		string|array $value
	): array {
		$items = [];
		
		foreach ( $this->sanitize_attachments( $value ) as $index => $url ) {
			$file_data = KERP_Api_File_Upload::instance()
			                                 ->get_uploaded_file_data( $url );
			
			$original_name = is_array( $file_data )
				? sanitize_text_field(
					(string) ( $file_data['original_name'] ?? '' )
				)
				: '';
			
			if ( $original_name === '' ) {
				$original_name = sprintf(
					__( 'فایل ضمیمه %s', 'kasebi-erp' ),
					number_format_i18n( $index + 1 )
				);
			}
			
			$items[] = [
				'url'           => $url,
				'original_name' => $original_name,
				'file_data'     => $file_data,
			];
		}
		
		return $items;
	}
	
	public function combine_datetime(
		string $date,
		string $time
	): string|WP_Error {
		$date = sanitize_text_field( $date );
		$time = sanitize_text_field( $time );
		
		if ( function_exists( 'nooshika_sanitize_numbers' ) ) {
			$date = nooshika_sanitize_numbers( $date );
			$time = nooshika_sanitize_numbers( $time );
		}
		
		$date = trim(
			str_replace( '/', '-', $date )
		);
		$time = trim( $time );
		
		if ( $date === '' && $time === '' ) {
			return '';
		}
		
		if ( $date === '' || $time === '' ) {
			return new WP_Error(
				'kerp_request_missing_datetime',
				__( 'برای تعیین مهلت، تاریخ و ساعت را کامل وارد کنید.', 'kasebi-erp' )
			);
		}
		
		$converted = KERP_Helpers_Date::jalali_to_gregorian( $date );
		
		if ( is_string( $converted ) && $converted !== '' ) {
			$date = str_replace( '/', '-', $converted );
		}
		
		$time = str_ireplace(
			[
				'ق.ظ',
				'ق ظ',
				'ب.ظ',
				'ب ظ',
			],
			[
				'AM',
				'AM',
				'PM',
				'PM',
			],
			$time
		);
		
		$time = preg_replace(
			'/\b([ap])\.?\s*m\.?\b/i',
			'$1M',
			$time
		);
		
		$time = strtoupper(
			trim(
				preg_replace(
					'/\s+/u',
					' ',
					(string) $time
				)
			)
		);
		
		$has_meridiem = preg_match(
			                '/(?:AM|PM)$/i',
			                $time
		                ) === 1;
		
		$formats = $has_meridiem
			? [
				'!Y-m-d g:i A',
				'!Y-m-d g:i:s A',
			]
			: [
				'!Y-m-d H:i',
				'!Y-m-d H:i:s',
			];
		
		foreach ( $formats as $format ) {
			$date_time = DateTimeImmutable::createFromFormat(
				$format,
				$date . ' ' . $time,
				wp_timezone()
			);
			$errors    = DateTimeImmutable::getLastErrors();
			
			if (
				$date_time instanceof DateTimeImmutable
				&& (
					$errors === FALSE
					|| (
						(int) $errors['warning_count'] === 0
						&& (int) $errors['error_count'] === 0
					)
				)
			) {
				return $date_time->format( 'Y-m-d H:i:s' );
			}
		}
		
		return new WP_Error(
			'kerp_request_invalid_datetime',
			__( 'تاریخ یا ساعت مهلت معتبر نیست.', 'kasebi-erp' )
		);
	}
	
	public function get_populate_data(
		array $request,
		string $modal_id = 'requestModal'
	): array {
		$due_at      = (string) ( $request['due_at'] ?? '' );
		$timestamp   = $due_at !== ''
			? strtotime( $due_at )
			: FALSE;
		$metadata    = isset( $request['metadata'] ) && is_array( $request['metadata'] )
			? $request['metadata']
			: [];
		$attachments = $this->sanitize_attachments(
			$metadata['attachments'] ?? []
		);
		$prefix      = 'kerp-request-' . sanitize_html_class( $modal_id );
		
		return [
			'request_id'        => [
				'id'    => '#' . $prefix . '-id',
				'type'  => 'text',
				'value' => absint( $request['id'] ?? 0 ),
			],
			'requester_context' => [
				'id'    => '#' . $prefix . '-requester-context',
				'type'  => 'text',
				'value' => sanitize_key(
					(string) ( $request['requester_context'] ?? 'employee' )
				),
			],
			'requester_id'      => [
				'id'    => '#' . $prefix . '-requester-id',
				'type'  => 'text',
				'value' => absint( $request['requester_id'] ?? 0 ),
			],
			'assignee_id'       => [
				'id'    => '#' . $prefix . '-assignee-id',
				'type'  => 'select',
				'value' => absint( $request['assignee_id'] ?? 0 ),
			],
			'type_key'          => [
				'id'    => '#' . $prefix . '-type-key',
				'type'  => 'select',
				'value' => sanitize_key(
					(string) ( $request['type_key'] ?? '' )
				),
			],
			'title'             => [
				'id'    => '#' . $prefix . '-title',
				'type'  => 'text',
				'value' => (string) ( $request['title'] ?? '' ),
			],
			'description'       => [
				'id'    => '#' . $prefix . '-description',
				'type'  => 'quill',
				'value' => (string) ( $request['description'] ?? '' ),
			],
			'priority'          => [
				'id'    => '#' . $prefix . '-priority',
				'type'  => 'select',
				'value' => sanitize_key(
					(string) ( $request['priority'] ?? 'normal' )
				),
			],
			'due_date'          => [
				'id'    => '#' . $prefix . '-due-date',
				'type'  => 'text',
				'value' => $timestamp
					? date_i18n( 'Y-m-d', $timestamp )
					: '',
			],
			'due_time'          => [
				'id'    => '#' . $prefix . '-due-time',
				'type'  => 'text',
				'value' => $timestamp
					? wp_date( 'H:i', $timestamp )
					: '',
			],
			'attachment'        => [
				'id'    => '#' . $prefix . '-attachment',
				'type'  => 'upload',
				'value' => implode( ',', $attachments ),
			],
		];
	}
	
	public function render_request_modal(
		string $return_page = '/erp/requests/',
		string $modal_id = 'requestModal',
		string $requester_context = 'employee',
		int $requester_id = 0,
		int $assignee_id = 0
	): void {
		KERP_Helpers_Template::render_template(
			'modules/requests/modals/request-form.php',
			[
				'return_page'       => $return_page,
				'modal_id'          => $modal_id,
				'requester_context' => $requester_context,
				'requester_id'      => $requester_id,
				'assignee_id'       => $assignee_id,
			]
		);
	}
	
	public function render_action_modals(
		string $return_page,
		string $context = 'main'
	): void {
		KERP_Helpers_Template::render_template(
			'modules/requests/modals/action-modals.php',
			[
				'return_page' => $return_page,
				'context'     => sanitize_key( $context ),
			]
		);
	}
	
}
