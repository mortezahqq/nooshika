<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Requests_Installer {

	private const DB_VERSION = '1.1.0';
	private const DB_VERSION_OPTION = 'kerp_requests_db_version';

	private static ?self $instance = NULL;

	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	private function __construct() {}

	private function __clone() {}

	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}

	public function maybe_install(): void {
		if ( get_option( self::DB_VERSION_OPTION ) === self::DB_VERSION ) {
			return;
		}

		$this->install();
	}

	public function install(): void {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$requests = KERP_Modules_Requests_Module::table();
		$history  = KERP_Modules_Requests_Module::history_table();
		$charset  = $wpdb->get_charset_collate();

		if ( $this->table_exists( $requests ) && ! $this->column_exists( $requests, 'requester_context' ) ) {
			$wpdb->query(
				"ALTER TABLE {$requests}
				ADD requester_context VARCHAR(50) NOT NULL DEFAULT 'employee' AFTER type_key"
			);
		}

		$request_sql = "CREATE TABLE {$requests} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			type_key VARCHAR(100) NOT NULL,
			requester_context VARCHAR(50) NOT NULL DEFAULT 'employee',
			requester_id BIGINT UNSIGNED NOT NULL,
			created_by BIGINT UNSIGNED NOT NULL,
			assignee_id BIGINT UNSIGNED NOT NULL,
			title VARCHAR(190) NOT NULL,
			description LONGTEXT NULL,
			priority VARCHAR(30) NOT NULL DEFAULT 'normal',
			status VARCHAR(30) NOT NULL DEFAULT 'pending',
			due_at DATETIME NULL,
			completed_at DATETIME NULL,
			updated_by BIGINT UNSIGNED NULL,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NULL,
			metadata LONGTEXT NULL,
			PRIMARY KEY  (id),
			KEY idx_context_requester_status (requester_context, requester_id, status),
			KEY idx_requester_status (requester_id, status),
			KEY idx_assignee_status (assignee_id, status),
			KEY idx_created_by (created_by),
			KEY idx_type_status (type_key, status),
			KEY idx_status_due (status, due_at),
			KEY idx_created_at (created_at)
		) {$charset};";

		$history_sql = "CREATE TABLE {$history} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			request_id BIGINT UNSIGNED NOT NULL,
			event_key VARCHAR(60) NOT NULL,
			actor_id BIGINT UNSIGNED NOT NULL,
			old_status VARCHAR(30) NULL,
			new_status VARCHAR(30) NULL,
			content LONGTEXT NULL,
			metadata LONGTEXT NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY idx_request_date (request_id, created_at),
			KEY idx_event_date (event_key, created_at),
			KEY idx_actor_id (actor_id)
		) {$charset};";

		dbDelta( $request_sql );
		dbDelta( $history_sql );

		if ( $this->column_exists( $requests, 'requester_context' ) ) {
			$wpdb->query(
				"UPDATE {$requests}
				SET requester_context = 'employee'
				WHERE requester_context IS NULL OR requester_context = ''"
			);
		}

		update_option(
			self::DB_VERSION_OPTION,
			self::DB_VERSION,
			FALSE
		);
	}

	private function table_exists( string $table ): bool {
		global $wpdb;

		return $wpdb->get_var(
			$wpdb->prepare(
				'SHOW TABLES LIKE %s',
				$wpdb->esc_like( $table )
			)
		) === $table;
	}

	private function column_exists( string $table, string $column ): bool {
		global $wpdb;

		$column = sanitize_key( $column );

		if ( $column === '' ) {
			return FALSE;
		}

		$result = $wpdb->get_var(
			$wpdb->prepare(
				"SHOW COLUMNS FROM {$table} LIKE %s",
				$column
			)
		);

		return is_string( $result ) && $result !== '';
	}
}
