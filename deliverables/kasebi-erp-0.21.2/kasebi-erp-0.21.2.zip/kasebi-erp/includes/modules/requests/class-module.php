<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Requests_Module {
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {
		$this->load_services();
		KERP_Modules_Requests_Installer::instance()->maybe_install();
		$this->register_hooks();
	}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public static function table(): string {
		global $wpdb;
		
		return $wpdb->prefix . 'kasebi_erp_requests';
	}
	
	public static function history_table(): string {
		global $wpdb;
		
		return $wpdb->prefix . 'kasebi_erp_request_history';
	}
	
	public static function install(): void {
		KERP_Modules_Requests_Installer::instance()->install();
	}
	
	public function register_pages( array $pages ): array {
		$customer_singular_label = KERP_Modules_Customers_Settings::instance()->get_singular_label();
		$employees_group         = [
			'key'   => 'employees',
			'title' => __( 'منابع انسانی', 'kasebi-erp' ),
			'icon'  => 'uik-r fa-id-badge',
			'order' => 30,
		];
		$customer_plural         = KERP_Modules_Customers_Settings::instance()->get_plural_label();
		$crm_group               = [
			'key'   => 'crm',
			'title' => sprintf(
				__( 'مدیریت %s', 'kasebi-erp' ),
				$customer_plural
			),
			'icon'  => 'kik fa-users-02',
			'order' => 20,
		];
		$settings_group          = [
			'key'        => 'settings',
			'title'      => __( 'تنظیمات', 'kasebi-erp' ),
			'icon'       => 'kik fa-settings-02',
			'order'      => 100,
			'sep_before' => TRUE,
		];
		$settings_menu           = [
			'key'   => 'crm-settings',
			'title' => __( 'تنظیمات CRM', 'kasebi-erp' ),
			'icon'  => 'kik fa-users-02',
			'order' => 50,
		];
		
		$pages['requests'] = [
			'title'      => __( 'درخواست‌های کارکنان', 'kasebi-erp' ),
			'route'      => 'requests',
			'type'       => 'page',
			'template'   => 'modules/requests/pages/requests.php',
			'permission' => 'requests.view',
			'navigation' => [
				'group' => apply_filters(
					'kerp_requests_employees_navigation_group',
					$employees_group
				),
				'icon'  => 'uik-r fa-inbox',
				'order' => 30,
			],
		];
		
		$pages['request'] = [
			'title'      => __( 'جزئیات درخواست', 'kasebi-erp' ),
			'route'      => 'requests/{request_id}',
			'type'       => 'sub-page',
			'template'   => 'modules/requests/pages/request.php',
			'permission' => 'requests.view',
			'navigation' => [
				'hidden' => TRUE,
				'active' => 'requests',
			],
		];
		
		$pages['customer-requests'] = [
			'title'      => __( 'درخواست‌ها', 'kasebi-erp' ),
			'route'      => 'customer-requests',
			'type'       => 'page',
			'template'   => 'modules/requests/pages/requests.php',
			'permission' => 'requests.view',
			'navigation' => [
				'group' => apply_filters(
					'kerp_requests_customers_navigation_group',
					$crm_group
				),
				'icon'  => 'uik-r fa-inbox',
				'order' => 20,
			],
		];
		
		$pages['customer-request'] = [
			'title'      => sprintf( __( 'جزئیات درخواست %s', 'kasebi-erp' ), $customer_singular_label ),
			'route'      => 'customer-requests/{request_id}',
			'type'       => 'sub-page',
			'template'   => 'modules/requests/pages/request.php',
			'permission' => 'requests.view',
			'navigation' => [
				'hidden' => TRUE,
				'active' => 'customer-requests',
			],
		];
		
		$pages['requests-settings'] = [
			'title'      => __( 'انواع درخواست‌ها', 'kasebi-erp' ),
			'route'      => 'settings/requests',
			'type'       => 'settings',
			'template'   => 'modules/requests/settings/types.php',
			'permission' => 'requests.manage_settings',
			'navigation' => [
				'group' => apply_filters(
					'kerp_requests_settings_navigation_group',
					$settings_group
				),
				'menu'  => apply_filters(
					'kerp_crm_settings_navigation_menu',
					$settings_menu
				),
				'title' => __( 'انواع درخواست‌ها', 'kasebi-erp' ),
				'order' => 30,
			],
		];
		
		return $pages;
	}
	
	public function register_employee_tab(
		array $tabs,
		int $employee_id,
		WP_User $employee
	): array {
		$tabs['requests'] = [
			'key'        => 'requests',
			'title'      => __( 'درخواست‌ها', 'kasebi-erp' ),
			'icon'       => 'uik-r fa-inbox',
			'order'      => 30,
			'permission' => 'requests.view',
			'action'     => 'view',
			'template'   => 'modules/requests/tabs/employee-requests.php',
		];
		
		return $tabs;
	}
	
	public function register_customer_tab(
		array $tabs,
		int $customer_id,
		WP_User $customer
	): array {
		$tabs['requests'] = [
			'key'        => 'requests',
			'title'      => __( 'درخواست‌ها', 'kasebi-erp' ),
			'icon'       => 'uik-r fa-inbox',
			'order'      => 50,
			'group'      => 'crm',
			'permission' => 'requests.view',
			'action'     => 'view',
			'template'   => 'modules/requests/tabs/customer-requests.php',
		];
		
		return $tabs;
	}
	
	public function register_customer_profile_action(
		array $actions,
		WP_User $customer,
		array $profile_context
	): array {
		if (
			! kerp_can( 'requests.create', 'action' )
			|| ! kerp_can( 'requests.create_for_others', 'action' )
		) {
			return $actions;
		}
		
		$actions['add_customer_request'] = [
			'label'      => __( 'ثبت درخواست', 'kasebi-erp' ),
			'icon'       => 'hik fa-document-add-1',
			'href'       => '#customerRequestModal',
			'order'      => 45,
			'attributes' => [
				'data-bs-toggle' => 'modal',
				'data-bs-target' => '#customerRequestModal',
			],
		];
		
		return $actions;
	}
	
	public function render_customer_request_modal(
		int $customer_id,
		WP_User $customer,
		array $profile_context,
		string $active_tab
	): void {
		$can_create = kerp_can( 'requests.create', 'action' )
		              && kerp_can( 'requests.create_for_others', 'action' );
		$can_edit   = kerp_can( 'requests.edit', 'action' );
		
		if ( ! $can_create && ! $can_edit ) {
			return;
		}
		
		$return_page = '/erp/customers/' . $customer_id . '/';
		
		if ( $active_tab !== '' ) {
			$return_page = add_query_arg(
				'tab',
				sanitize_key( $active_tab ),
				$return_page
			);
		}
		
		KERP_Modules_Requests_Form::instance()->render_request_modal(
			$return_page,
			'customerRequestModal',
			'customer',
			$customer_id
		);
	}
	
	public function register_employee_profile_action(
		array $actions,
		WP_User $employee,
		array $profile_context
	): array {
		if ( ! kerp_can( 'requests.create', 'action' ) ) {
			return $actions;
		}
		
		if ( (int) $employee->ID === get_current_user_id() ) {
			return $actions;
		}
		
		$actions['add_employee_request'] = [
			'label'      => __( 'افزودن درخواست', 'kasebi-erp' ),
			'icon'       => 'ni ni-file-plus',
			'href'       => '#requestModal',
			'order'      => 30,
			'attributes' => [
				'data-bs-toggle' => 'modal',
			],
		];
		
		return $actions;
	}
	
	public function register_permissions( array $groups ): array {
		$customer_plural_label = KERP_Modules_Customers_Settings::instance()->get_plural_label();
		if (
			! isset( $groups['employees'] )
			|| ! is_array( $groups['employees'] )
		) {
			$groups['employees'] = [
				'key'    => 'employees',
				'label'  => __( 'منابع انسانی', 'kasebi-erp' ),
				'icon'   => 'uik-r fa-id-badge',
				'order'  => 30,
				'blocks' => [],
			];
		}
		
		if (
			! isset( $groups['employees']['blocks'] )
			|| ! is_array( $groups['employees']['blocks'] )
		) {
			$groups['employees']['blocks'] = [];
		}
		
		$groups['employees']['blocks']['requests'] = [
			'key'         => 'requests',
			'label'       => __( 'درخواست‌ها', 'kasebi-erp' ),
			'icon'        => 'uik-r fa-inbox',
			'order'       => 30,
			'description' => sprintf( __( 'ارسال، ارجاع، بررسی و پاسخ به درخواست‌های کارکنان و %s.', 'kasebi-erp' ), $customer_plural_label ),
			'permissions' => [
				'requests_view'              => [
					'key'         => 'requests.view',
					'label'       => __( 'دسترسی به بخش درخواست‌ها', 'kasebi-erp' ),
					'description' => __( 'امکان ورود به فهرست و جزئیات درخواست‌ها.', 'kasebi-erp' ),
					'type'        => 'view',
					'order'       => 10,
				],
				'requests_list'              => [
					'key'         => 'requests.list',
					'label'       => __( 'مشاهده فهرست درخواست‌ها', 'kasebi-erp' ),
					'description' => __( 'دامنه درخواست‌هایی که کاربر می‌تواند مشاهده کند.', 'kasebi-erp' ),
					'type'        => 'view',
					'order'       => 20,
					'scope'       => [
						'options' => [
							'own' => __( 'فقط درخواست‌های مرتبط با خود', 'kasebi-erp' ),
							'all' => __( 'همه درخواست‌ها', 'kasebi-erp' ),
						],
						'default' => 'own',
					],
				],
				'requests_create'            => [
					'key'   => 'requests.create',
					'label' => __( 'ثبت درخواست', 'kasebi-erp' ),
					'type'  => 'action',
					'order' => 30,
				],
				'requests_create_for_others' => [
					'key'   => 'requests.create_for_others',
					'label' => __( 'ثبت درخواست برای دیگران', 'kasebi-erp' ),
					'type'  => 'action',
					'order' => 40,
				],
				'requests_edit'              => [
					'key'   => 'requests.edit',
					'label' => __( 'ویرایش درخواست', 'kasebi-erp' ),
					'type'  => 'action',
					'order' => 50,
				],
				'requests_assign'            => [
					'key'   => 'requests.assign',
					'label' => __( 'تغییر مسئول بررسی', 'kasebi-erp' ),
					'type'  => 'action',
					'order' => 60,
				],
				'requests_review'            => [
					'key'   => 'requests.review',
					'label' => __( 'شروع بررسی درخواست', 'kasebi-erp' ),
					'type'  => 'action',
					'order' => 70,
				],
				'requests_request_info'      => [
					'key'   => 'requests.request_info',
					'label' => __( 'درخواست اطلاعات بیشتر', 'kasebi-erp' ),
					'type'  => 'action',
					'order' => 80,
				],
				'requests_respond'           => [
					'key'   => 'requests.respond',
					'label' => __( 'ثبت پاسخ تکمیلی', 'kasebi-erp' ),
					'type'  => 'action',
					'order' => 90,
				],
				'requests_approve'           => [
					'key'   => 'requests.approve',
					'label' => __( 'تأیید درخواست', 'kasebi-erp' ),
					'type'  => 'action',
					'order' => 100,
				],
				'requests_reject'            => [
					'key'   => 'requests.reject',
					'label' => __( 'رد درخواست', 'kasebi-erp' ),
					'type'  => 'action',
					'order' => 110,
				],
				'requests_cancel'            => [
					'key'   => 'requests.cancel',
					'label' => __( 'لغو درخواست', 'kasebi-erp' ),
					'type'  => 'action',
					'order' => 120,
				],
				'requests_complete'          => [
					'key'   => 'requests.complete',
					'label' => __( 'تکمیل درخواست', 'kasebi-erp' ),
					'type'  => 'action',
					'order' => 130,
				],
				'requests_comment'           => [
					'key'   => 'requests.comment',
					'label' => __( 'ثبت پیام در درخواست', 'kasebi-erp' ),
					'type'  => 'action',
					'order' => 140,
				],
				'requests_delete'            => [
					'key'   => 'requests.delete',
					'label' => __( 'حذف درخواست', 'kasebi-erp' ),
					'type'  => 'action',
					'order' => 150,
				],
				'requests_manage_settings'   => [
					'key'   => 'requests.manage_settings',
					'label' => __( 'مدیریت انواع درخواست‌ها', 'kasebi-erp' ),
					'type'  => 'action',
					'order' => 160,
				],
			],
		];
		
		return $groups;
	}
	
	public function render_employee_request_modal(
		int $employee_id,
		WP_User $employee,
		array $profile_context
	): void {
		$can_create = kerp_can( 'requests.create', 'action' );
		$can_edit   = kerp_can( 'requests.edit', 'action' );
		
		if ( ! $can_create && ! $can_edit ) {
			return;
		}
		
		$active_tab      = sanitize_key(
			(string) ( $profile_context['active_tab'] ?? 'profile' )
		);
		$return_page     = add_query_arg(
			[
				'tab' => $active_tab,
			],
			'/erp/employees/' . $employee_id . '/'
		);
		$current_user_id = get_current_user_id();
		$fixed_assignee  = $employee_id !== $current_user_id
			? $employee_id
			: 0;
		
		KERP_Modules_Requests_Form::instance()->render_request_modal(
			$return_page,
			'requestModal',
			'employee',
			$current_user_id,
			$fixed_assignee
		);
		
		if ( $can_edit ) {
			KERP_Modules_Requests_Form::instance()->render_request_modal(
				$return_page,
				'customerRequestEditModal',
				'customer'
			);
		}
	}
	
	public function save(
		array $data,
		int $request_id = 0
	): int|WP_Error {
		global $wpdb;
		
		$request_id = absint( $request_id );
		$existing   = $request_id > 0
			? KERP_Modules_Requests_Query::instance()->get( $request_id )
			: NULL;
		$type_key   = sanitize_key(
			(string) ( $data['type_key'] ?? '' )
		);
		$type       = KERP_Modules_Requests_Settings::instance()
		                                            ->get_type( $type_key );
		
		if ( ! is_array( $type ) ) {
			return new WP_Error(
				'kerp_request_invalid_type',
				__( 'نوع درخواست معتبر نیست.', 'kasebi-erp' )
			);
		}
		
		$title = sanitize_text_field(
			(string) ( $data['title'] ?? '' )
		);
		
		if ( $title === '' ) {
			return new WP_Error(
				'kerp_request_missing_title',
				__( 'عنوان درخواست را وارد کنید.', 'kasebi-erp' )
			);
		}
		
		$requester_context = sanitize_key(
			(string) ( $data['requester_context'] ?? 'employee' )
		) ?: 'employee';
		$requester_id      = absint(
			$data['requester_id'] ?? 0
		);
		
		if (
			! KERP_Modules_Requests_Settings::instance()->type_supports_context(
				$type,
				$requester_context
			)
		) {
			return new WP_Error(
				'kerp_request_invalid_context',
				__( 'این نوع درخواست برای درخواست‌دهنده انتخاب‌شده قابل استفاده نیست.', 'kasebi-erp' )
			);
		}
		
		if (
			! KERP_Modules_Requests_Form::instance()->is_valid_requester(
				$requester_id,
				$requester_context
			)
		) {
			return new WP_Error(
				'kerp_request_invalid_requester',
				__( 'درخواست‌دهنده معتبر نیست.', 'kasebi-erp' )
			);
		}
		
		$assignee_id = absint(
			$data['assignee_id'] ?? 0
		);
		$assignee    = get_userdata( $assignee_id );
		
		if ( ! $assignee instanceof WP_User ) {
			return new WP_Error(
				'kerp_request_invalid_assignee',
				__( 'مسئول بررسی معتبر نیست.', 'kasebi-erp' )
			);
		}
		
		$priority   = sanitize_key(
			(string) ( $data['priority'] ?? 'normal' )
		);
		$priorities = KERP_Modules_Requests_Settings::instance()
		                                            ->priorities();
		
		if ( ! isset( $priorities[ $priority ] ) ) {
			$priority = 'normal';
		}
		
		$metadata     = is_array( $existing )
		                && isset( $existing['metadata'] )
		                && is_array( $existing['metadata'] )
			? $existing['metadata']
			: [];
		$new_metadata = isset( $data['metadata'] )
		                && is_array( $data['metadata'] )
			? $data['metadata']
			: [];
		$metadata     = array_merge(
			$metadata,
			$new_metadata
		);
		
		if ( isset( $metadata['attachments'] ) ) {
			$metadata['attachments'] = KERP_Modules_Requests_Form::instance()
			                                                     ->sanitize_attachments( $metadata['attachments'] );
		}
		
		$now     = current_time( 'mysql' );
		$user_id = get_current_user_id();
		$record  = [
			'type_key'          => $type_key,
			'requester_context' => $requester_context,
			'requester_id'      => $requester_id,
			'assignee_id'       => $assignee_id,
			'title'             => $title,
			'description'       => wp_kses_post(
				(string) ( $data['description'] ?? '' )
			),
			'priority'          => $priority,
			'due_at'            => ! empty( $data['due_at'] )
				? sanitize_text_field( (string) $data['due_at'] )
				: NULL,
			'updated_by'        => $user_id,
			'updated_at'        => $now,
			'metadata'          => wp_json_encode(
				$metadata,
				JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
			),
		];
		
		if ( is_array( $existing ) ) {
			$old_assignee_id = absint(
				$existing['assignee_id'] ?? 0
			);
			
			$updated = $wpdb->update(
				self::table(),
				$record,
				[ 'id' => $request_id ],
				[
					'%s',
					'%s',
					'%d',
					'%d',
					'%s',
					'%s',
					'%s',
					'%s',
					'%d',
					'%s',
					'%s',
				],
				[ '%d' ]
			);
			
			if ( $updated === FALSE ) {
				return new WP_Error(
					'kerp_request_update_failed',
					__( 'ویرایش درخواست انجام نشد.', 'kasebi-erp' )
				);
			}
			
			KERP_Modules_Requests_History::instance()->add(
				$request_id,
				'updated',
				__( 'اطلاعات درخواست ویرایش شد.', 'kasebi-erp' )
			);
			
			if ( $old_assignee_id !== $assignee_id ) {
				KERP_Modules_Requests_History::instance()->add(
					$request_id,
					'assigned',
					sprintf(
						__( 'مسئول بررسی به %s تغییر کرد.', 'kasebi-erp' ),
						get_user_name_by_id( $assignee_id )
					),
					[
						'old_assignee_id' => $old_assignee_id,
						'new_assignee_id' => $assignee_id,
					]
				);
				
				do_action(
					'kerp_request_assigned',
					$request_id,
					$assignee_id,
					$old_assignee_id
				);
			}
			
			do_action(
				'kerp_request_updated',
				$request_id,
				$record,
				$existing
			);
			
			return $request_id;
		}
		
		$record['status']       = 'pending';
		$record['created_by']   = $user_id;
		$record['created_at']   = $now;
		$record['completed_at'] = NULL;
		
		$inserted = $wpdb->insert(
			self::table(),
			$record,
			[
				'%s',
				'%s',
				'%d',
				'%d',
				'%s',
				'%s',
				'%s',
				'%s',
				'%d',
				'%s',
				'%s',
				'%s',
				'%d',
				'%s',
				'%s',
			]
		);
		
		if ( $inserted === FALSE ) {
			return new WP_Error(
				'kerp_request_create_failed',
				__( 'ثبت درخواست انجام نشد.', 'kasebi-erp' )
			);
		}
		
		$request_id = (int) $wpdb->insert_id;
		
		KERP_Modules_Requests_History::instance()->add(
			$request_id,
			'created',
			__( 'درخواست ثبت شد.', 'kasebi-erp' ),
			[
				'assignee_id'       => $assignee_id,
				'type_key'          => $type_key,
				'requester_context' => $requester_context,
			]
		);
		
		$request = KERP_Modules_Requests_Query::instance()->get(
			$request_id
		);
		
		do_action(
			'kerp_request_created',
			$request_id,
			$request
		);
		
		return $request_id;
	}
	
	public function assign(
		int $request_id,
		int $assignee_id,
		string $note = ''
	): bool|WP_Error {
		global $wpdb;
		
		$request = KERP_Modules_Requests_Query::instance()->get(
			$request_id
		);
		
		if ( ! is_array( $request ) ) {
			return new WP_Error(
				'kerp_request_not_found',
				__( 'درخواست پیدا نشد.', 'kasebi-erp' )
			);
		}
		
		$assignee = get_userdata( $assignee_id );
		
		if ( ! $assignee instanceof WP_User ) {
			return new WP_Error(
				'kerp_request_invalid_assignee',
				__( 'مسئول بررسی معتبر نیست.', 'kasebi-erp' )
			);
		}
		
		$old_assignee_id = absint(
			$request['assignee_id'] ?? 0
		);
		
		if ( $old_assignee_id === $assignee_id ) {
			return TRUE;
		}
		
		$updated = $wpdb->update(
			self::table(),
			[
				'assignee_id' => $assignee_id,
				'updated_by'  => get_current_user_id(),
				'updated_at'  => current_time( 'mysql' ),
			],
			[ 'id' => $request_id ],
			[
				'%d',
				'%d',
				'%s',
			],
			[ '%d' ]
		);
		
		if ( $updated === FALSE ) {
			return new WP_Error(
				'kerp_request_assign_failed',
				__( 'تغییر مسئول بررسی انجام نشد.', 'kasebi-erp' )
			);
		}
		
		$content = trim( wp_strip_all_tags( $note ) ) !== ''
			? wp_kses_post( $note )
			: sprintf(
				__( 'مسئول بررسی به %s تغییر کرد.', 'kasebi-erp' ),
				get_user_name_by_id( $assignee_id )
			);
		
		KERP_Modules_Requests_History::instance()->add(
			$request_id,
			'assigned',
			$content,
			[
				'old_assignee_id' => $old_assignee_id,
				'new_assignee_id' => $assignee_id,
			]
		);
		
		do_action(
			'kerp_request_assigned',
			$request_id,
			$assignee_id,
			$old_assignee_id
		);
		
		return TRUE;
	}
	
	public function transition(
		int $request_id,
		string $new_status,
		string $content = '',
		array $metadata = []
	): bool|WP_Error {
		global $wpdb;
		
		$request = KERP_Modules_Requests_Query::instance()->get(
			$request_id
		);
		
		if ( ! is_array( $request ) ) {
			return new WP_Error(
				'kerp_request_not_found',
				__( 'درخواست پیدا نشد.', 'kasebi-erp' )
			);
		}
		
		$old_status = sanitize_key(
			(string) ( $request['status'] ?? '' )
		);
		$new_status = sanitize_key( $new_status );
		$validation = KERP_Modules_Requests_Workflow::instance()
		                                            ->validate_transition(
			                                            $old_status,
			                                            $new_status
		                                            );
		
		if ( is_wp_error( $validation ) ) {
			return $validation;
		}
		
		$now     = current_time( 'mysql' );
		$update  = [
			'status'     => $new_status,
			'updated_by' => get_current_user_id(),
			'updated_at' => $now,
		];
		$formats = [
			'%s',
			'%d',
			'%s',
		];
		
		if ( $new_status === 'completed' ) {
			$update['completed_at'] = $now;
			$formats[]              = '%s';
		}
		
		$updated = $wpdb->update(
			self::table(),
			$update,
			[ 'id' => $request_id ],
			$formats,
			[ '%d' ]
		);
		
		if ( $updated === FALSE ) {
			return new WP_Error(
				'kerp_request_transition_failed',
				__( 'تغییر وضعیت درخواست انجام نشد.', 'kasebi-erp' )
			);
		}
		
		KERP_Modules_Requests_History::instance()->add(
			$request_id,
			$new_status,
			$content,
			$metadata,
			$old_status,
			$new_status
		);
		
		$updated_request = KERP_Modules_Requests_Query::instance()
		                                              ->get( $request_id );
		
		do_action(
			'kerp_request_status_changed',
			$request_id,
			$new_status,
			$old_status,
			$updated_request
		);
		
		if ( $new_status === 'completed' ) {
			do_action(
				'kerp_request_completed',
				$request_id,
				$updated_request
			);
		}
		
		return TRUE;
	}
	
	public function add_comment(
		int $request_id,
		string $content,
		array $attachments = []
	): int|WP_Error {
		$content     = wp_kses_post( $content );
		$attachments = KERP_Modules_Requests_Form::instance()
		                                         ->sanitize_attachments( $attachments );
		
		if ( trim( wp_strip_all_tags( $content ) ) === '' && empty( $attachments ) ) {
			return new WP_Error(
				'kerp_request_empty_comment',
				__( 'متن پیام یا فایل ضمیمه را وارد کنید.', 'kasebi-erp' )
			);
		}
		
		$history_id = KERP_Modules_Requests_History::instance()->add(
			$request_id,
			'comment',
			$content,
			[ 'attachments' => $attachments ]
		);
		
		if ( is_wp_error( $history_id ) ) {
			return $history_id;
		}
		
		do_action(
			'kerp_request_comment_added',
			$request_id,
			$history_id
		);
		
		return $history_id;
	}
	
	public function delete( int $request_id ): bool|WP_Error {
		global $wpdb;
		
		$request = KERP_Modules_Requests_Query::instance()->get(
			$request_id
		);
		
		if ( ! is_array( $request ) ) {
			return TRUE;
		}
		
		$wpdb->delete(
			self::history_table(),
			[ 'request_id' => $request_id ],
			[ '%d' ]
		);
		
		$deleted = $wpdb->delete(
			self::table(),
			[ 'id' => $request_id ],
			[ '%d' ]
		);
		
		if ( $deleted === FALSE ) {
			return new WP_Error(
				'kerp_request_delete_failed',
				__( 'حذف درخواست انجام نشد.', 'kasebi-erp' )
			);
		}
		
		do_action(
			'kerp_request_deleted',
			$request_id,
			$request
		);
		
		return TRUE;
	}
	
	public function count_by_type( string $type_key ): int {
		global $wpdb;
		
		return (int) $wpdb->get_var(
			$wpdb->prepare(
				'SELECT COUNT(*)
				FROM ' . self::table() . '
				WHERE type_key = %s',
				sanitize_key( $type_key )
			)
		);
	}
	
	public function replace_type_key(
		string $old_key,
		string $new_key
	): void {
		global $wpdb;
		
		$old_key = sanitize_key( $old_key );
		$new_key = sanitize_key( $new_key );
		
		if (
			$old_key === ''
			|| $new_key === ''
			|| $old_key === $new_key
		) {
			return;
		}
		
		$wpdb->update(
			self::table(),
			[ 'type_key' => $new_key ],
			[ 'type_key' => $old_key ],
			[ '%s' ],
			[ '%s' ]
		);
	}
	
	public function handle_deleted_user( int $user_id ): void {
		global $wpdb;
		
		$user_id = absint( $user_id );
		
		if ( $user_id <= 0 ) {
			return;
		}
		
		$wpdb->update(
			self::table(),
			[ 'assignee_id' => 0 ],
			[ 'assignee_id' => $user_id ],
			[ '%d' ],
			[ '%d' ]
		);
	}
	
	private function load_services(): void {
		KERP_Modules_Requests_Installer::instance();
		KERP_Modules_Requests_Settings::instance();
		KERP_Modules_Requests_History::instance();
		KERP_Modules_Requests_Workflow::instance();
		KERP_Modules_Requests_Query::instance();
		KERP_Modules_Requests_Form::instance();
		KERP_Modules_Requests_List_Table::instance();
		KERP_Modules_Requests_Api::instance();
	}
	
	private function register_hooks(): void {
		add_filter(
			'kerp_app_pages',
			[ $this, 'register_pages' ],
			32
		);
		add_filter(
			'kerp_employee_profile_tabs',
			[ $this, 'register_employee_tab' ],
			32,
			3
		);
		add_filter(
			'kerp_customer_profile_tabs',
			[ $this, 'register_customer_tab' ],
			32,
			3
		);
		add_filter(
			'kerp_customers_profile_dropdown_actions',
			[ $this, 'register_customer_profile_action' ],
			32,
			3
		);
		add_action(
			'kerp_customer_profile_modals',
			[ $this, 'render_customer_request_modal' ],
			32,
			4
		);
		add_filter(
			'kerp_employee_permission_groups',
			[ $this, 'register_permissions' ],
			32
		);
		add_action(
			'deleted_user',
			[ $this, 'handle_deleted_user' ]
		);
		add_filter(
			'kerp_employees_profile_dropdown_actions',
			[ $this, 'register_employee_profile_action' ],
			20,
			3
		);
		add_action(
			'kerp_employee_profile_after_page',
			[ $this, 'render_employee_request_modal' ],
			20,
			3
		);
	}
	
}
