<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Requests_Settings {
	
	public const TYPES_OPTION = 'kerp_requests_types';
	
	private static ?self $instance = NULL;
	
	private ?array $types = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {
		add_action(
			'update_option_' . self::TYPES_OPTION,
			[ $this, 'clear_cache' ],
			10,
			0
		);
		add_action(
			'add_option_' . self::TYPES_OPTION,
			[ $this, 'clear_cache' ],
			10,
			0
		);
	}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public function get_types( bool $active_only = FALSE ): array {
		if ( $this->types === NULL ) {
			$stored = get_option(
				self::TYPES_OPTION,
				NULL
			);
			
			if ( $stored === NULL ) {
				$stored = $this->defaults();
			}
			
			$this->types = is_array( $stored )
				? $stored
				: [];
		}
		
		$types = [];
		
		foreach ( $this->types as $type_key => $type ) {
			if ( ! is_array( $type ) ) {
				continue;
			}
			
			$type_key = sanitize_key(
				(string) ( $type['key'] ?? $type_key )
			);
			
			if ( $type_key === '' ) {
				continue;
			}
			
			$type['key']      = $type_key;
			$type['contexts'] = $this->normalize_contexts(
				$type['contexts'] ?? [ 'employee' ]
			);
			
			$types[ $type_key ] = $type;
		}
		
		if ( $active_only ) {
			$active_types = [];
			
			foreach ( $types as $type_key => $type ) {
				if (
					! is_array( $type )
					|| isset( $type['active'] ) && ! $type['active']
				) {
					continue;
				}
				
				$active_types[ $type_key ] = $type;
			}
			
			$types = $active_types;
		}
		
		$types = apply_filters(
			'kerp_requests_types',
			$types,
			$active_only
		);
		
		$types = is_array( $types ) ? $types : [];
		
		uasort( $types, [ $this, 'sort_types' ] );
		
		return $types;
	}
	
	public function get_type( string $type_key ): ?array {
		$type_key = sanitize_key( $type_key );
		$types    = $this->get_types();
		
		return isset( $types[ $type_key ] ) && is_array( $types[ $type_key ] )
			? $types[ $type_key ]
			: NULL;
	}
	
	public function requester_contexts(): array {
		$contexts = apply_filters(
			'kerp_requests_requester_contexts',
			[
				'employee' => __( 'کارکنان و مدیران', 'kasebi-erp' ),
				'customer' => __( 'کاربران', 'kasebi-erp' ),
			]
		);
		
		return is_array( $contexts ) ? $contexts : [];
	}
	
	public function type_supports_context( array $type, string $context ): bool {
		$context = sanitize_key( $context );
		
		if ( $context === '' ) {
			return FALSE;
		}
		
		return in_array(
			$context,
			$this->normalize_contexts( $type['contexts'] ?? [ 'employee' ] ),
			TRUE
		);
	}
	
	public function get_type_options(
		bool $active_only = TRUE,
		string $context = ''
	): array {
		$options = [];
		$context = sanitize_key( $context );
		
		foreach ( $this->get_types( $active_only ) as $type_key => $type ) {
			if ( $context !== '' && ! $this->type_supports_context( $type, $context ) ) {
				continue;
			}
			
			$options[ $type_key ] = sanitize_text_field(
				(string) ( $type['label'] ?? $type_key )
			);
		}
		
		return $options;
	}
	
	public function save_type(
		array $data,
		string $original_key = ''
	): bool|WP_Error {
		$original_key = sanitize_key( $original_key );
		$type         = $this->sanitize_type( $data );
		$type_key     = $type['key'];
		
		if ( $type_key === '' ) {
			return new WP_Error(
				'kerp_request_type_missing_key',
				__( 'کلید نوع درخواست را وارد کنید.', 'kasebi-erp' )
			);
		}
		
		if ( $type['label'] === '' ) {
			return new WP_Error(
				'kerp_request_type_missing_label',
				__( 'عنوان نوع درخواست را وارد کنید.', 'kasebi-erp' )
			);
		}
		
		$types = $this->get_types();
		
		if (
			$original_key !== ''
			&& $original_key !== $type_key
			&& isset( $types[ $type_key ] )
		) {
			return new WP_Error(
				'kerp_request_type_duplicate',
				__( 'نوع درخواست دیگری با این کلید وجود دارد.', 'kasebi-erp' )
			);
		}
		
		if ( $original_key !== '' && $original_key !== $type_key ) {
			unset( $types[ $original_key ] );
			KERP_Modules_Requests_Module::instance()->replace_type_key(
				$original_key,
				$type_key
			);
		}
		
		$types[ $type_key ] = $type;
		
		$this->save_types( $types );
		
		do_action(
			'kerp_request_type_saved',
			$type_key,
			$type,
			$original_key
		);
		
		return TRUE;
	}
	
	public function delete_type(
		string $type_key,
		string $replacement_key = ''
	): bool|WP_Error {
		$type_key        = sanitize_key( $type_key );
		$replacement_key = sanitize_key( $replacement_key );
		$types           = $this->get_types();
		
		if ( ! isset( $types[ $type_key ] ) ) {
			return TRUE;
		}
		
		$usage_count = KERP_Modules_Requests_Module::instance()
		                                           ->count_by_type( $type_key );
		
		if ( $usage_count > 0 ) {
			if (
				$replacement_key === ''
				|| $replacement_key === $type_key
				|| ! isset( $types[ $replacement_key ] )
			) {
				return new WP_Error(
					'kerp_request_type_used',
					__( 'این نوع در درخواست‌ها استفاده شده است؛ نوع جایگزین را انتخاب کنید.', 'kasebi-erp' )
				);
			}
			
			KERP_Modules_Requests_Module::instance()->replace_type_key(
				$type_key,
				$replacement_key
			);
		}
		
		unset( $types[ $type_key ] );
		
		$this->save_types( $types );
		
		do_action(
			'kerp_request_type_deleted',
			$type_key,
			$replacement_key
		);
		
		return TRUE;
	}
	
	public function statuses(): array {
		return (array) apply_filters(
			'kerp_request_statuses',
			[
				'pending'    => __( 'در انتظار بررسی', 'kasebi-erp' ),
				'reviewing'  => __( 'در حال بررسی', 'kasebi-erp' ),
				'needs_info' => __( 'نیازمند اطلاعات بیشتر', 'kasebi-erp' ),
				'approved'   => __( 'تأیید شده', 'kasebi-erp' ),
				'rejected'   => __( 'رد شده', 'kasebi-erp' ),
				'cancelled'  => __( 'لغو شده', 'kasebi-erp' ),
				'completed'  => __( 'انجام شده', 'kasebi-erp' ),
			]
		);
	}
	
	public function priorities(): array {
		return (array) apply_filters(
			'kerp_request_priorities',
			[
				'low'    => __( 'کم', 'kasebi-erp' ),
				'normal' => __( 'معمولی', 'kasebi-erp' ),
				'high'   => __( 'زیاد', 'kasebi-erp' ),
				'urgent' => __( 'فوری', 'kasebi-erp' ),
			]
		);
	}
	
	public function status_classes(): array {
		return [
			'pending'    => 'bg-warning',
			'reviewing'  => 'bg-info',
			'needs_info' => 'bg-danger',
			'approved'   => 'bg-success',
			'rejected'   => 'bg-danger',
			'cancelled'  => 'bg-light',
			'completed'  => 'bg-success',
		];
	}
	
	public function priority_classes(): array {
		return [
			'low'    => 'bg-light',
			'normal' => 'bg-info',
			'high'   => 'bg-warning',
			'urgent' => 'bg-danger',
		];
	}
	
	public function sort_types(
		array $first,
		array $second
	): int {
		return (int) ( $first['order'] ?? 100 )
		       <=> (int) ( $second['order'] ?? 100 );
	}
	
	public function clear_cache(): void {
		$this->types = NULL;
	}
	
	private function sanitize_type( array $data ): array {
		$active = $data['active'] ?? 0;
		
		if ( is_array( $active ) ) {
			$active = in_array(
				'1',
				array_map( 'strval', $active ),
				TRUE
			);
		} else {
			$active = (string) $active === '1';
		}
		
		$priority   = sanitize_key(
			(string) ( $data['default_priority'] ?? 'normal' )
		);
		$priorities = $this->priorities();
		
		if ( ! isset( $priorities[ $priority ] ) ) {
			$priority = 'normal';
		}
		
		return [
			'key'                 => sanitize_key(
				(string) ( $data['key'] ?? '' )
			),
			'label'               => sanitize_text_field(
				(string) ( $data['label'] ?? '' )
			),
			'description'         => sanitize_textarea_field(
				(string) ( $data['description'] ?? '' )
			),
			'icon'                => sanitize_text_field(
				(string) ( $data['icon'] ?? 'ni ni-file-text' )
			),
			'color'               => sanitize_key(
				(string) ( $data['color'] ?? 'primary' )
			),
			'default_assignee_id' => absint(
				$data['default_assignee_id'] ?? 0
			),
			'default_priority'    => $priority,
			'default_due_days'    => max(
				0,
				absint( $data['default_due_days'] ?? 0 )
			),
			'contexts'            => $this->normalize_contexts(
				$data['contexts'] ?? [ 'employee' ]
			),
			'active'              => $active,
			'order'               => absint(
				$data['order'] ?? 100
			),
		];
	}
	
	private function normalize_contexts( mixed $contexts ): array {
		if ( is_string( $contexts ) ) {
			$contexts = preg_split(
				'/\s*,\s*/',
				trim( $contexts ),
				- 1,
				PREG_SPLIT_NO_EMPTY
			);
		}
		
		$normalized = [];
		
		foreach ( (array) $contexts as $context ) {
			$context = sanitize_key( (string) $context );
			
			if ( $context === '' ) {
				continue;
			}
			
			$normalized[] = $context;
		}
		
		$normalized = array_values( array_unique( $normalized ) );
		
		return $normalized ?: [ 'employee' ];
	}
	
	private function save_types( array $types ): void {
		uasort( $types, [ $this, 'sort_types' ] );
		
		update_option(
			self::TYPES_OPTION,
			$types,
			FALSE
		);
		
		$this->types = $types;
	}
	
	private function defaults(): array {
		return [
			'general_request'   => [
				'key'                 => 'general_request',
				'label'               => __( 'درخواست عمومی', 'kasebi-erp' ),
				'description'         => __( 'درخواست عمومی بین کارکنان و مدیران.', 'kasebi-erp' ),
				'icon'                => 'ni ni-file-text',
				'color'               => 'primary',
				'default_assignee_id' => 0,
				'default_priority'    => 'normal',
				'default_due_days'    => 0,
				'contexts'            => [ 'employee' ],
				'active'              => TRUE,
				'order'               => 10,
			],
			'leave_request'     => [
				'key'                 => 'leave_request',
				'label'               => __( 'درخواست مرخصی', 'kasebi-erp' ),
				'description'         => __( 'ثبت و بررسی درخواست مرخصی کارکنان.', 'kasebi-erp' ),
				'icon'                => 'ni ni-calendar',
				'color'               => 'info',
				'default_assignee_id' => 0,
				'default_priority'    => 'normal',
				'default_due_days'    => 1,
				'contexts'            => [ 'employee' ],
				'active'              => TRUE,
				'order'               => 20,
			],
			'equipment_request' => [
				'key'                 => 'equipment_request',
				'label'               => __( 'درخواست تجهیزات', 'kasebi-erp' ),
				'description'         => __( 'درخواست ابزار، تجهیزات یا دسترسی موردنیاز.', 'kasebi-erp' ),
				'icon'                => 'ni ni-setting',
				'color'               => 'warning',
				'default_assignee_id' => 0,
				'default_priority'    => 'normal',
				'default_due_days'    => 3,
				'contexts'            => [ 'employee' ],
				'active'              => TRUE,
				'order'               => 30,
			],
		];
	}
	
}
