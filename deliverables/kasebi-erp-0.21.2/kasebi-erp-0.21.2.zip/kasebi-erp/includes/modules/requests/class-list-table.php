<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Requests_List_Table {
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public function get_filters( array $values = [], string $requester_context = 'employee' ): array {
		$requester_context = sanitize_key( $requester_context ) ?: 'employee';
		$date              = isset( $values['date'] ) && is_array( $values['date'] )
			? $values['date']
			: [];
		$due               = isset( $values['due'] ) && is_array( $values['due'] )
			? $values['due']
			: [];
		
		$filters = [
			'search'      => [
				'key'         => 'search',
				'name'        => 'search',
				'label'       => __( 'جستجو', 'kasebi-erp' ),
				'type'        => 'text',
				'placeholder' => __( 'عنوان، شرح یا شناسه درخواست', 'kasebi-erp' ),
				'value'       => sanitize_text_field(
					(string) ( $values['search'] ?? '' )
				),
				'order'       => 5,
				'col'         => 12,
			],
			'status'      => [
				'key'         => 'status',
				'name'        => 'status',
				'label'       => __( 'وضعیت', 'kasebi-erp' ),
				'type'        => 'select',
				'options'     => KERP_Modules_Requests_Settings::instance()
				                                               ->statuses(),
				'placeholder' => __( 'همه وضعیت‌ها', 'kasebi-erp' ),
				'value'       => sanitize_key(
					(string) ( $values['status'] ?? '' )
				),
				'order'       => 10,
			],
			'type_key'    => [
				'key'         => 'type_key',
				'name'        => 'type_key',
				'label'       => __( 'نوع درخواست', 'kasebi-erp' ),
				'type'        => 'select',
				'options'     => KERP_Modules_Requests_Settings::instance()
				                                               ->get_type_options( FALSE, $requester_context ),
				'placeholder' => __( 'همه انواع', 'kasebi-erp' ),
				'value'       => sanitize_key(
					(string) ( $values['type_key'] ?? '' )
				),
				'order'       => 20,
			],
			'assignee_id' => [
				'key'         => 'assignee_id',
				'name'        => 'assignee_id',
				'label'       => __( 'مسئول بررسی', 'kasebi-erp' ),
				'type'        => 'select',
				'options'     => KERP_Modules_Requests_Form::instance()
				                                           ->get_reviewer_options( - 1 ),
				'placeholder' => __( 'همه مسئولان', 'kasebi-erp' ),
				'value'       => absint(
					$values['assignee_id'] ?? 0
				),
				'order'       => 30,
			],
			'priority'    => [
				'key'         => 'priority',
				'name'        => 'priority',
				'label'       => __( 'اولویت', 'kasebi-erp' ),
				'type'        => 'select',
				'options'     => KERP_Modules_Requests_Settings::instance()
				                                               ->priorities(),
				'placeholder' => __( 'همه اولویت‌ها', 'kasebi-erp' ),
				'value'       => sanitize_key(
					(string) ( $values['priority'] ?? '' )
				),
				'order'       => 50,
			],
			'date'        => [
				'key'   => 'date',
				'name'  => 'date',
				'label' => __( 'تاریخ ثبت', 'kasebi-erp' ),
				'type'  => 'date-range',
				'col'   => 12,
				'value' => [
					'from' => sanitize_text_field(
						(string) ( $date['from'] ?? '' )
					),
					'to'   => sanitize_text_field(
						(string) ( $date['to'] ?? '' )
					),
				],
				'order' => 60,
			],
			'due'         => [
				'key'   => 'due',
				'name'  => 'due',
				'label' => __( 'مهلت پاسخ', 'kasebi-erp' ),
				'type'  => 'date-range',
				'col'   => 12,
				'value' => [
					'from' => sanitize_text_field(
						(string) ( $due['from'] ?? '' )
					),
					'to'   => sanitize_text_field(
						(string) ( $due['to'] ?? '' )
					),
				],
				'order' => 70,
			],
		];
		
		$filters = apply_filters(
			'kerp_requests_list_filters',
			$filters,
			$values,
			$requester_context
		);
		
		$filters = is_array( $filters ) ? $filters : [];
		
		uasort( $filters, [ $this, 'sort_by_order' ] );
		
		return $filters;
	}
	
	public function sort_by_order(
		array $first,
		array $second
	): int {
		return (int) ( $first['order'] ?? 100 )
		       <=> (int) ( $second['order'] ?? 100 );
	}
	
}
