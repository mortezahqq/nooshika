<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Requests_Workflow {
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public function transitions(): array {
		return (array) apply_filters(
			'kerp_request_status_transitions',
			[
				'pending'    => [
					'reviewing',
					'cancelled',
				],
				'reviewing'  => [
					'needs_info',
					'approved',
					'rejected',
					'cancelled',
				],
				'needs_info' => [
					'reviewing',
					'cancelled',
				],
				'approved'   => [
					'completed',
					'cancelled',
				],
				'rejected'   => [],
				'cancelled'  => [],
				'completed'  => [],
			]
		);
	}
	
	public function can_transition(
		string $old_status,
		string $new_status
	): bool {
		$old_status = sanitize_key( $old_status );
		$new_status = sanitize_key( $new_status );
		$map        = $this->transitions();
		$allowed    = isset( $map[ $old_status ] ) && is_array( $map[ $old_status ] )
			? $map[ $old_status ]
			: [];
		
		$can_transition = in_array(
			$new_status,
			$allowed,
			TRUE
		);
		
		return (bool) apply_filters(
			'kerp_request_can_transition',
			$can_transition,
			$old_status,
			$new_status
		);
	}
	
	public function validate_transition(
		string $old_status,
		string $new_status
	): bool|WP_Error {
		if ( $this->can_transition( $old_status, $new_status ) ) {
			return TRUE;
		}
		
		return new WP_Error(
			'kerp_request_invalid_transition',
			__( 'تغییر وضعیت انتخاب‌شده برای این درخواست مجاز نیست.', 'kasebi-erp' )
		);
	}
	
}
