<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Requests_History {

	private static ?self $instance = NULL;

	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	private function __construct() {}

	private function __clone() {}

	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}

	public function add(
		int $request_id,
		string $event_key,
		string $content = '',
		array $metadata = [],
		string $old_status = '',
		string $new_status = '',
		int $actor_id = 0
	): int|WP_Error {
		global $wpdb;

		$request_id = absint( $request_id );
		$event_key  = sanitize_key( $event_key );
		$actor_id   = $actor_id > 0
			? $actor_id
			: get_current_user_id();

		if ( $request_id <= 0 || $event_key === '' ) {
			return new WP_Error(
				'kerp_request_invalid_history',
				__( 'اطلاعات تاریخچه درخواست معتبر نیست.', 'kasebi-erp' )
			);
		}

		$inserted = $wpdb->insert(
			KERP_Modules_Requests_Module::history_table(),
			[
				'request_id' => $request_id,
				'event_key'  => $event_key,
				'actor_id'   => $actor_id,
				'old_status' => sanitize_key( $old_status ),
				'new_status' => sanitize_key( $new_status ),
				'content'    => wp_kses_post( $content ),
				'metadata'   => wp_json_encode(
					$metadata,
					JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
				),
				'created_at' => current_time( 'mysql' ),
			],
			[
				'%d',
				'%s',
				'%d',
				'%s',
				'%s',
				'%s',
				'%s',
				'%s',
			]
		);

		if ( $inserted === FALSE ) {
			return new WP_Error(
				'kerp_request_history_failed',
				__( 'ثبت تاریخچه درخواست انجام نشد.', 'kasebi-erp' )
			);
		}

		$history_id = (int) $wpdb->insert_id;

		do_action(
			'kerp_request_history_added',
			$history_id,
			$request_id,
			$event_key
		);

		return $history_id;
	}

	public function get_items(
		int $request_id,
		int $limit = 200
	): array {
		global $wpdb;

		$request_id = absint( $request_id );
		$limit      = max( 1, min( 500, $limit ) );

		if ( $request_id <= 0 ) {
			return [];
		}

		$sql = $wpdb->prepare(
			'SELECT *
			FROM ' . KERP_Modules_Requests_Module::history_table() . '
			WHERE request_id = %d
			ORDER BY id ASC
			LIMIT %d',
			$request_id,
			$limit
		);

		$items = $wpdb->get_results( $sql, ARRAY_A );

		return is_array( $items ) ? $items : [];
	}

	public function event_labels(): array {
		return (array) apply_filters(
			'kerp_request_history_event_labels',
			[
				'created'        => __( 'درخواست ثبت شد', 'kasebi-erp' ),
				'updated'        => __( 'اطلاعات درخواست ویرایش شد', 'kasebi-erp' ),
				'assigned'       => __( 'مسئول بررسی تغییر کرد', 'kasebi-erp' ),
				'reviewing'      => __( 'بررسی درخواست آغاز شد', 'kasebi-erp' ),
				'needs_info'     => __( 'اطلاعات بیشتری درخواست شد', 'kasebi-erp' ),
				'responded'      => __( 'پاسخ تکمیلی ثبت شد', 'kasebi-erp' ),
				'approved'       => __( 'درخواست تأیید شد', 'kasebi-erp' ),
				'rejected'       => __( 'درخواست رد شد', 'kasebi-erp' ),
				'cancelled'      => __( 'درخواست لغو شد', 'kasebi-erp' ),
				'completed'      => __( 'درخواست انجام شد', 'kasebi-erp' ),
				'comment'        => __( 'پیام جدید ثبت شد', 'kasebi-erp' ),
				'attachment'     => __( 'فایل ضمیمه شد', 'kasebi-erp' ),
				'type_replaced'  => __( 'نوع درخواست جایگزین شد', 'kasebi-erp' ),
			]
		);
	}
}
