<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Requests_Query {

	private static ?self $instance = NULL;

	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	private function __construct() {}

	private function __clone() {}

	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}

	public function get( int $request_id ): ?array {
		global $wpdb;

		$request_id = absint( $request_id );

		if ( $request_id <= 0 ) {
			return NULL;
		}

		$row = $wpdb->get_row(
			$wpdb->prepare(
				'SELECT *
				FROM ' . KERP_Modules_Requests_Module::table() . '
				WHERE id = %d
				LIMIT 1',
				$request_id
			),
			ARRAY_A
		);

		return is_array( $row ) ? $this->prepare_item( $row ) : NULL;
	}

	public function find( array $args = [] ): array {
		global $wpdb;

		$defaults = [
			'per_page'     => 20,
			'page_number'  => 1,
			'search'       => '',
			'type_key'     => '',
			'status'       => '',
			'priority'     => '',
			'requester_context' => '',
			'requester_id'      => 0,
			'created_by'   => 0,
			'assignee_id'  => 0,
			'employee_id'       => 0,
			'customer_id'       => 0,
			'relation'     => '',
			'date_from'    => '',
			'date_to'      => '',
			'due_from'     => '',
			'due_to'       => '',
			'overdue'      => FALSE,
			'orderby'      => 'created_at',
			'order'        => 'DESC',
			'enforce_scope'=> TRUE,
		];

		$args = wp_parse_args( $args, $defaults );
		$args = apply_filters( 'kerp_requests_query_args', $args );

		if ( ! is_array( $args ) ) {
			$args = $defaults;
		}

		$scope = ! empty( $args['enforce_scope'] )
			? kerp_list_scope( 'requests' )
			: 'all';

		if ( $scope === 'none' ) {
			return $this->empty_result( $args );
		}

		$where  = [ '1=1' ];
		$params = [];

		if ( $scope === 'own' ) {
			$current_user_id = get_current_user_id();
			$where[] = '(
				(requester_context = %s AND requester_id = %d)
				OR created_by = %d
				OR assignee_id = %d
			)';
			$params[] = 'employee';
			$params[] = $current_user_id;
			$params[] = $current_user_id;
			$params[] = $current_user_id;
		}

		$search = sanitize_text_field(
			(string) ( $args['search'] ?? '' )
		);

		if ( $search !== '' ) {
			$like = '%' . $wpdb->esc_like( $search ) . '%';
			$where[] = '(
				id = %d
				OR title LIKE %s
				OR description LIKE %s
			)';
			$params[] = absint( $search );
			$params[] = $like;
			$params[] = $like;
		}

		$type_key = sanitize_key(
			(string) ( $args['type_key'] ?? '' )
		);

		if ( $type_key !== '' ) {
			$where[]  = 'type_key = %s';
			$params[] = $type_key;
		}

		$status = sanitize_key(
			(string) ( $args['status'] ?? '' )
		);

		if ( $status !== '' ) {
			$where[]  = 'status = %s';
			$params[] = $status;
		}

		$priority = sanitize_key(
			(string) ( $args['priority'] ?? '' )
		);

		if ( $priority !== '' ) {
			$where[]  = 'priority = %s';
			$params[] = $priority;
		}

		$requester_context = sanitize_key(
			(string) ( $args['requester_context'] ?? '' )
		);

		if ( $requester_context !== '' ) {
			$where[]  = 'requester_context = %s';
			$params[] = $requester_context;
		}

		foreach (
			[
				'requester_id',
				'created_by',
				'assignee_id',
			] as $id_key
		) {
			$id_value = absint( $args[ $id_key ] ?? 0 );

			if ( $id_value <= 0 ) {
				continue;
			}

			$where[]  = $id_key . ' = %d';
			$params[] = $id_value;
		}

		$employee_id = absint(
			$args['employee_id'] ?? 0
		);
		$relation = sanitize_key(
			(string) ( $args['relation'] ?? '' )
		);

		if ( $employee_id > 0 ) {
			if ( $relation === 'requester' ) {
				$where[]  = '(requester_context = %s AND requester_id = %d)';
				$params[] = 'employee';
				$params[] = $employee_id;
			} elseif ( $relation === 'assignee' ) {
				$where[]  = 'assignee_id = %d';
				$params[] = $employee_id;
			} else {
				$where[] = '(
					(requester_context = %s AND requester_id = %d)
					OR created_by = %d
					OR assignee_id = %d
				)';
				$params[] = 'employee';
				$params[] = $employee_id;
				$params[] = $employee_id;
				$params[] = $employee_id;
			}
		}

		$customer_id = absint(
			$args['customer_id'] ?? 0
		);

		if ( $customer_id > 0 ) {
			$where[]  = '(requester_context = %s AND requester_id = %d)';
			$params[] = 'customer';
			$params[] = $customer_id;
		}

		$this->add_datetime_condition(
			$where,
			$params,
			'created_at',
			(string) ( $args['date_from'] ?? '' ),
			'>='
		);
		$this->add_datetime_condition(
			$where,
			$params,
			'created_at',
			(string) ( $args['date_to'] ?? '' ),
			'<='
		);
		$this->add_datetime_condition(
			$where,
			$params,
			'due_at',
			(string) ( $args['due_from'] ?? '' ),
			'>='
		);
		$this->add_datetime_condition(
			$where,
			$params,
			'due_at',
			(string) ( $args['due_to'] ?? '' ),
			'<='
		);

		if ( ! empty( $args['overdue'] ) ) {
			$where[] = "due_at IS NOT NULL
				AND due_at < %s
				AND status NOT IN ('completed', 'cancelled', 'rejected')";
			$params[] = current_time( 'mysql' );
		}

		$where_sql = implode( ' AND ', $where );
		$table     = KERP_Modules_Requests_Module::table();

		$count_sql = "SELECT COUNT(*)
			FROM {$table}
			WHERE {$where_sql}";

		$total = (int) $wpdb->get_var(
			empty( $params )
				? $count_sql
				: $wpdb->prepare( $count_sql, ...$params )
		);

		$per_page = max(
			1,
			min(
				100,
				absint( $args['per_page'] ?? 20 )
			)
		);
		$page_number = max(
			1,
			absint( $args['page_number'] ?? 1 )
		);
		$offset = ( $page_number - 1 ) * $per_page;

		$order_map = [
			'id'         => 'id',
			'created_at' => 'created_at',
			'updated_at' => 'updated_at',
			'due_at'     => 'due_at',
			'title'      => 'title',
			'priority'   => 'priority',
			'status'     => 'status',
		];
		$orderby = $order_map[
			sanitize_key(
				(string) ( $args['orderby'] ?? 'created_at' )
			)
		] ?? 'created_at';
		$order = strtoupper(
			(string) ( $args['order'] ?? 'DESC' )
		) === 'ASC'
			? 'ASC'
			: 'DESC';

		$list_sql = "SELECT *
			FROM {$table}
			WHERE {$where_sql}
			ORDER BY {$orderby} {$order}, id {$order}
			LIMIT %d OFFSET %d";

		$list_params = array_merge(
			$params,
			[
				$per_page,
				$offset,
			]
		);

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				$list_sql,
				...$list_params
			),
			ARRAY_A
		);

		$items = [];

		foreach ( (array) $rows as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}

			$items[] = $this->prepare_item( $row );
		}

		$result = [
			'items'        => $items,
			'total'        => $total,
			'per_page'     => $per_page,
			'page_number'  => $page_number,
			'total_pages'  => (int) ceil( $total / $per_page ),
			'request_args' => $args,
		];

		return apply_filters(
			'kerp_requests_query_results',
			$result,
			$args
		);
	}

	public function statistics( array $args = [] ): array {
		$base_args = wp_parse_args(
			$args,
			[
				'per_page'    => 1,
				'page_number' => 1,
			]
		);

		$pending = $this->find(
			array_merge(
				$base_args,
				[ 'status' => 'pending' ]
			)
		);
		$needs_info = $this->find(
			array_merge(
				$base_args,
				[ 'status' => 'needs_info' ]
			)
		);
		$approved = $this->find(
			array_merge(
				$base_args,
				[ 'status' => 'approved' ]
			)
		);
		$completed = $this->find(
			array_merge(
				$base_args,
				[ 'status' => 'completed' ]
			)
		);
		$overdue = $this->find(
			array_merge(
				$base_args,
				[ 'overdue' => TRUE ]
			)
		);
		$assigned = $this->find(
			array_merge(
				$base_args,
				[
					'assignee_id' => get_current_user_id(),
					'status'      => '',
				]
			)
		);

		return [
			'pending'    => (int) $pending['total'],
			'needs_info' => (int) $needs_info['total'],
			'approved'   => (int) $approved['total'],
			'completed'  => (int) $completed['total'],
			'overdue'    => (int) $overdue['total'],
			'assigned'   => (int) $assigned['total'],
		];
	}

	public function can_view( array $request ): bool {
		if ( current_user_can( 'manage_options' ) ) {
			return TRUE;
		}

		$scope = kerp_list_scope( 'requests' );

		if ( $scope === 'all' ) {
			return TRUE;
		}

		if ( $scope !== 'own' ) {
			return FALSE;
		}

		$current_user_id   = get_current_user_id();
		$requester_context = sanitize_key(
			(string) ( $request['requester_context'] ?? 'employee' )
		) ?: 'employee';

		if (
			$requester_context === 'employee'
			&& absint( $request['requester_id'] ?? 0 ) === $current_user_id
		) {
			return TRUE;
		}

		return in_array(
			$current_user_id,
			[
				absint( $request['created_by'] ?? 0 ),
				absint( $request['assignee_id'] ?? 0 ),
			],
			TRUE
		);
	}

	public function is_participant(
		array $request,
		int $user_id = 0
	): bool {
		$user_id = $user_id > 0
			? $user_id
			: get_current_user_id();

		$requester_context = sanitize_key(
			(string) ( $request['requester_context'] ?? 'employee' )
		) ?: 'employee';

		if (
			$requester_context === 'employee'
			&& absint( $request['requester_id'] ?? 0 ) === $user_id
		) {
			return TRUE;
		}

		return in_array(
			$user_id,
			[
				absint( $request['created_by'] ?? 0 ),
				absint( $request['assignee_id'] ?? 0 ),
			],
			TRUE
		);
	}

	private function prepare_item( array $row ): array {
		$metadata = json_decode(
			(string) ( $row['metadata'] ?? '' ),
			TRUE
		);

		$row['metadata'] = is_array( $metadata )
			? $metadata
			: [];

		$row['id']                = absint( $row['id'] ?? 0 );
		$row['requester_context'] = sanitize_key(
			(string) ( $row['requester_context'] ?? 'employee' )
		) ?: 'employee';
		$row['requester_id']      = absint( $row['requester_id'] ?? 0 );
		$row['created_by']   = absint( $row['created_by'] ?? 0 );
		$row['assignee_id']  = absint( $row['assignee_id'] ?? 0 );
		$row['updated_by']   = absint( $row['updated_by'] ?? 0 );

		return $row;
	}

	private function add_datetime_condition(
		array &$where,
		array &$params,
		string $column,
		string $value,
		string $operator
	): void {
		$value = sanitize_text_field( $value );

		if ( $value === '' ) {
			return;
		}

		$converted = KERP_Helpers_Date::jalali_to_gregorian( $value );

		if ( is_string( $converted ) && $converted !== '' ) {
			$value = $converted;
		}

		if ( $operator === '<=' ) {
			$value .= ' 23:59:59';
		} else {
			$value .= ' 00:00:00';
		}

		$where[]  = $column . ' ' . $operator . ' %s';
		$params[] = $value;
	}

	private function empty_result( array $args ): array {
		return [
			'items'        => [],
			'total'        => 0,
			'per_page'     => max(
				1,
				absint( $args['per_page'] ?? 20 )
			),
			'page_number'  => max(
				1,
				absint( $args['page_number'] ?? 1 )
			),
			'total_pages'  => 0,
			'request_args' => $args,
		];
	}
}
