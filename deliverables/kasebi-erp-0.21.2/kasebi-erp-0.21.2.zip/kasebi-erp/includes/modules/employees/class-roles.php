<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Employees_Roles {
	public const OPTION_NAME = 'kerp_employees_roles';

	private static ?self $instance = NULL;

	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	private function __construct() {}

	private function __clone() {}

	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}

	public function get_all( bool $active_only = FALSE ): array {
		$roles = $this->get_stored_roles();
		$roles = apply_filters( 'kerp_employees_roles', $roles );
		$roles = $this->sanitize_roles( is_array( $roles ) ? $roles : [] );

		if ( $active_only ) {
			$roles = array_filter(
				$roles,
				[ $this, 'is_role_active' ]
			);
		}

		uasort( $roles, [ $this, 'sort_roles' ] );

		return $roles;
	}

	public function defaults(): array {
		return [
			'marketing_manager' => [
				'key'    => 'marketing_manager',
				'label'  => __( 'مدیر بازاریابی', 'kasebi-erp' ),
				'icon'   => 'uik-r fa-megaphone',
				'active' => TRUE,
				'order'  => 20,
			],
			'marketer' => [
				'key'    => 'marketer',
				'label'  => __( 'بازاریاب', 'kasebi-erp' ),
				'icon'   => 'uik-r fa-user',
				'active' => TRUE,
				'order'  => 30,
			],
			'support' => [
				'key'    => 'support',
				'label'  => __( 'پشتیبان', 'kasebi-erp' ),
				'icon'   => 'uik-r fa-headset',
				'active' => TRUE,
				'order'  => 40,
			],
			'accountant' => [
				'key'    => 'accountant',
				'label'  => __( 'حسابدار', 'kasebi-erp' ),
				'icon'   => 'uik-r fa-calculator',
				'active' => TRUE,
				'order'  => 50,
			],
			'employee' => [
				'key'    => 'employee',
				'label'  => __( 'کارمند', 'kasebi-erp' ),
				'icon'   => 'uik-r fa-id-badge',
				'active' => TRUE,
				'order'  => 100,
			],
		];
	}

	public function get( string $role_key ): ?array {
		$role_key = $this->normalize_key( $role_key );
		$roles    = $this->get_all();

		return isset( $roles[ $role_key ] ) && is_array( $roles[ $role_key ] )
			? $roles[ $role_key ]
			: NULL;
	}

	public function get_by_slug( string $role_slug ): ?array {
		return $this->get( $this->key_from_slug( $role_slug ) );
	}

	public function get_options( string $excluded_role = '', bool $active_only = TRUE ): array {
		$excluded_role = $this->normalize_key( $excluded_role );
		$options       = [];

		foreach ( $this->get_all( $active_only ) as $role_key => $role ) {
			if ( $role_key === $excluded_role ) {
				continue;
			}

			$options[ $role_key ] = (string) ( $role['label'] ?? $role_key );
		}

		return $options;
	}

	public function create( array $role_data ): array|WP_Error {
		$valid = $this->validate_default_page( $role_data );
		if ( is_wp_error( $valid ) ) {
			return $valid;
		}
		$role = $this->sanitize_role( $role_data );

		if ( $role['key'] === '' || $this->is_reserved_role_key( $role['key'] ) ) {
			return new WP_Error(
				'kerp_employee_role_key_required',
				__( 'کلید نقش را وارد کنید.', 'kasebi-erp' )
			);
		}

		if ( $role['label'] === '' ) {
			return new WP_Error(
				'kerp_employee_role_label_required',
				__( 'عنوان نقش را وارد کنید.', 'kasebi-erp' )
			);
		}

		if ( $this->get( $role['key'] ) ) {
			return new WP_Error(
				'kerp_employee_role_exists',
				__( 'نقشی با این کلید قبلاً ثبت شده است.', 'kasebi-erp' )
			);
		}

		$roles                 = $this->get_stored_roles();
		$roles[ $role['key'] ] = $role;

		if ( ! $this->save_roles( $roles ) ) {
			return new WP_Error(
				'kerp_employee_role_create_failed',
				__( 'ایجاد نقش انجام نشد.', 'kasebi-erp' )
			);
		}

		do_action( 'kerp_employee_role_created', $role['key'], $role );

		return $role;
	}

	public function update( string $role_key, array $role_data ): array|WP_Error {
		$role_key = $this->normalize_key( $role_key );
		$roles    = $this->get_stored_roles();

		if ( $role_key === '' || ! isset( $roles[ $role_key ] ) ) {
			return new WP_Error(
				'kerp_employee_role_not_editable',
				__( 'این نقش قابل ویرایش نیست یا وجود ندارد.', 'kasebi-erp' )
			);
		}

		$role_data['key'] = $role_key;
		if ( ! array_key_exists( 'default_page', $role_data ) ) {
			$role_data['default_page'] = $roles[ $role_key ]['default_page'] ?? '';
		} else {
			$valid = $this->validate_default_page( $role_data );
			if ( is_wp_error( $valid ) ) {
				return $valid;
			}
		}
		$role             = $this->sanitize_role( $role_data );

		if ( $role['label'] === '' ) {
			return new WP_Error(
				'kerp_employee_role_label_required',
				__( 'عنوان نقش را وارد کنید.', 'kasebi-erp' )
			);
		}

		$roles[ $role_key ] = $role;

		if ( ! $this->save_roles( $roles ) ) {
			return new WP_Error(
				'kerp_employee_role_update_failed',
				__( 'ذخیره نقش انجام نشد.', 'kasebi-erp' )
			);
		}

		do_action( 'kerp_employee_role_updated', $role_key, $role );

		return $role;
	}

	public function delete( string $role_key, string $replacement_role_key = '' ): bool|WP_Error {
		$role_key            = $this->normalize_key( $role_key );
		$replacement_role_key = $this->normalize_key( $replacement_role_key );
		$roles               = $this->get_stored_roles();

		if ( $role_key === '' || ! isset( $roles[ $role_key ] ) ) {
			return new WP_Error(
				'kerp_employee_role_not_deletable',
				__( 'این نقش قابل حذف نیست یا وجود ندارد.', 'kasebi-erp' )
			);
		}

		$employees_count = $this->count_employees( $role_key );

		if ( $employees_count > 0 ) {
			if ( $replacement_role_key === '' ) {
				return new WP_Error(
					'kerp_employee_role_replacement_required',
					__( 'نقش جایگزین کارکنان را انتخاب کنید.', 'kasebi-erp' )
				);
			}

			if ( $replacement_role_key === $role_key || ! $this->get( $replacement_role_key ) ) {
				return new WP_Error(
					'kerp_employee_role_replacement_invalid',
					__( 'نقش جایگزین معتبر نیست.', 'kasebi-erp' )
				);
			}

			$reassigned = $this->reassign_employees( $role_key, $replacement_role_key );

			if ( is_wp_error( $reassigned ) ) {
				return $reassigned;
			}
		}

		unset( $roles[ $role_key ] );

		if ( ! $this->save_roles( $roles ) ) {
			return new WP_Error(
				'kerp_employee_role_delete_failed',
				__( 'حذف نقش انجام نشد.', 'kasebi-erp' )
			);
		}

		do_action(
			'kerp_employee_role_deleted',
			$role_key,
			$replacement_role_key,
			$employees_count
		);

		return TRUE;
	}

	public function count_employees( string $role_key ): int {
		global $wpdb;

		$role_key = $this->normalize_key( $role_key );

		if ( $role_key === '' ) {
			return 0;
		}

		return (int) $wpdb->get_var(
			$wpdb->prepare(
				'SELECT COUNT(*) FROM ' . KERP_Services_Access::table() . ' WHERE role_key = %s',
				$role_key
			)
		);
	}

	public function slug( string $role_key ): string {
		return str_replace( '_', '-', $this->normalize_key( $role_key ) );
	}

	public function key_from_slug( string $role_slug ): string {
		return $this->normalize_key(
			str_replace( '-', '_', sanitize_title( $role_slug ) )
		);
	}

	public function get_url( string $role_key ): string {
		return '/erp/settings/employees/role/' . $this->slug( $role_key ) . '/';
	}

	public function normalize_key( string $role_key ): string {
		return sanitize_key( str_replace( '-', '_', $role_key ) );
	}

	public function is_reserved_role_key( string $role_key ): bool {
		$role_key = $this->normalize_key( $role_key );
		$reserved = [
			'administrator',
			'general_manager',
			'super_admin',
		];

		return in_array( $role_key, $reserved, TRUE );
	}

	public function is_role_active( array $role ): bool {
		return ! empty( $role['active'] );
	}

	public function sort_roles( array $first_role, array $second_role ): int {
		return (int) ( $first_role['order'] ?? 100 ) <=> (int) ( $second_role['order'] ?? 100 );
	}


	private function save_roles( array $roles ): bool {
		$updated = update_option( self::OPTION_NAME, $roles, FALSE );

		return $updated || get_option( self::OPTION_NAME, [] ) === $roles;
	}

	private function get_stored_roles(): array {
		$stored = get_option( self::OPTION_NAME, NULL );

		if ( $stored === NULL ) {
			return $this->sanitize_roles( $this->defaults() );
		}

		return $this->sanitize_roles( is_array( $stored ) ? $stored : [] );
	}

	private function sanitize_roles( array $roles ): array {
		$clean = [];

		foreach ( $roles as $role_key => $role_data ) {
			if ( ! is_array( $role_data ) ) {
				continue;
			}

			if ( empty( $role_data['key'] ) ) {
				$role_data['key'] = $role_key;
			}

			$role = $this->sanitize_role( $role_data );

			if ( $role['key'] === '' || $this->is_reserved_role_key( $role['key'] ) ) {
				continue;
			}

			$clean[ $role['key'] ] = $role;
		}

		return $clean;
	}

	private function validate_default_page( array $role_data ): bool|WP_Error {
		$page = $role_data['default_page'] ?? '';
		if ( ! is_string( $page ) || ( $page !== '' && ! array_key_exists( $page, KERP_App::instance()->get_default_page_options() ) ) ) {
			return new WP_Error( 'kerp_employee_role_invalid_default_page', __( 'صفحه پیش‌فرض نقش باید یک صفحه فعال و معتبر ERP باشد.', 'kasebi-erp' ) );
		}
		return TRUE;
	}

	private function sanitize_role( array $role_data ): array {
		$role_key = $this->normalize_key( (string) ( $role_data['key'] ?? '' ) );
		$label    = sanitize_text_field( (string) ( $role_data['label'] ?? '' ) );
		$icon     = sanitize_text_field( (string) ( $role_data['icon'] ?? '' ) );

		if ( $icon === '' ) {
			$icon = 'uik-r fa-id-badge';
		}

		return [
			'key'    => $role_key,
			'label'  => $label,
			'icon'   => $icon,
			'active' => ! empty( $role_data['active'] ),
			'order'  => (int) ( $role_data['order'] ?? 100 ),
			'default_page' => is_string( $role_data['default_page'] ?? '' ) ? sanitize_key( $role_data['default_page'] ?? '' ) : '',
		];
	}

	private function reassign_employees( string $source_role_key, string $target_role_key ): int|WP_Error {
		global $wpdb;

		$employee_ids = $wpdb->get_col(
			$wpdb->prepare(
				'SELECT user_id FROM ' . KERP_Services_Access::table() . ' WHERE role_key = %s',
				$source_role_key
			)
		);
		$employee_ids = array_values(
			array_filter(
				array_unique(
					array_map( 'absint', $employee_ids )
				)
			)
		);

		if ( empty( $employee_ids ) ) {
			return 0;
		}

		$updated = $wpdb->query(
			$wpdb->prepare(
				'UPDATE ' . KERP_Services_Access::table() . '
				SET role_key = %s, version = version + 1, updated_at = %s
				WHERE role_key = %s',
				$target_role_key,
				current_time( 'mysql' ),
				$source_role_key
			)
		);

		if ( $updated === FALSE ) {
			return new WP_Error(
				'kerp_employee_role_reassign_failed',
				__( 'تغییر نقش کارکنان انجام نشد.', 'kasebi-erp' )
			);
		}

		foreach ( $employee_ids as $employee_id ) {
			do_action(
				'kerp_employee_role_changed',
				$employee_id,
				$source_role_key,
				$target_role_key
			);
		}

		if ( in_array( get_current_user_id(), $employee_ids, TRUE ) ) {
			KERP_Services_Access::hydrate( get_current_user_id() );
		}

		return count( $employee_ids );
	}
}
