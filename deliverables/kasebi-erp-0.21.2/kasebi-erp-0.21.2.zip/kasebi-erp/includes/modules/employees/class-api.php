<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Employees_Api {
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {
		$this->register_hooks();
	}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	private function register_hooks(): void {
		add_action( 'kasebi_ajax_employees_save_default_page', [ $this, 'save_default_page' ] );
		add_action(
			'kasebi_ajax_employees_create',
			[ $this, 'create' ]
		);
		add_action(
			'kasebi_ajax_employees_update',
			[ $this, 'save_profile' ]
		);
		add_action(
			'kasebi_ajax_employees_save_profile',
			[ $this, 'save_profile' ]
		);
		add_action(
			'kasebi_ajax_employees_change_profile_image',
			[ $this, 'change_profile_image' ]
		);
		add_action(
			'kasebi_ajax_employees_handle_profile_image_upload',
			[ $this, 'handle_profile_image_upload' ]
		);
		add_action(
			'kasebi_ajax_employees_save_access',
			[ $this, 'save_access' ]
		);
		add_action(
			'kasebi_ajax_employees_reset_access_to_role',
			[ $this, 'reset_access_to_role' ]
		);
		add_action(
			'kasebi_ajax_employees_apply_role_defaults',
			[ $this, 'apply_role_defaults' ]
		);
		add_action(
			'kasebi_ajax_employees_save_settings',
			[ $this, 'save_settings' ]
		);
		add_action(
			'kasebi_ajax_employees_save_fields',
			[ $this, 'save_fields' ]
		);
		add_action(
			'kasebi_ajax_employees_delete_field',
			[ $this, 'delete_field' ]
		);
		add_action(
			'kasebi_ajax_employees_delete',
			[ $this, 'delete' ]
		);
	}
	
	public function create(): void {
		$this->guard( 'employees.create' );
		
		$payload = [
			'first_name' => $this->post_text( 'first_name' ),
			'last_name'  => $this->post_text( 'last_name' ),
			'phone'      => $this->post_text( 'phone' ),
			'email'      => $this->post_text( 'email' ),
		];
		
		$user_id = $this->persist_user( 0, $payload );
		
		if ( is_wp_error( $user_id ) ) {
			$this->error( $user_id->get_error_message() );
		}
		
		$employee_data = [
			'employee_code'     => $this->post_text( 'employee_code' ),
			'role_key'          => $this->post_text( 'role_key' ),
			'employment_type'   => $this->post_text( 'employment_type' ),
			'employment_status' => $this->post_text( 'employment_status' ),
			'started_at'        => $this->post_text( 'started_at' ),
			'ended_at'          => $this->post_text( 'ended_at' ),
		];
		
		$this->save_employee_data(
			(int) $user_id,
			$employee_data
		);
		$this->save_custom_fields_from_request(
			(int) $user_id,
			$this->request_meta(),
			'create'
		);
		
		$path = '/erp/employees/' . (int) $user_id . '/?tab=profile';
		
		$page_response                = KERP_Api_Page_Content::build_page_response(
			$path,
			[ 'tab' => 'profile' ],
		);
		$page_response['employee_id'] = $user_id;
		
		$this->success(
			__( 'کارمند با موفقیت ایجاد شد.', 'kasebi-erp' ),
			$page_response
		);
	}
	
	public function save_profile(): void {
		$this->guard( 'employees.update' );
		
		$employee_id = absint(
			$_POST['employee_id'] ?? 0
		);
		$employee    = KERP_Modules_Employees_Query::instance()->get_employee(
			$employee_id
		);
		
		if ( ! $employee instanceof WP_User ) {
			$this->error( __( 'کارمند پیدا نشد.', 'kasebi-erp' ) );
		}
		
		$request_meta = $this->request_meta();
		$payload      = [
			'first_name' => sanitize_text_field(
				(string) ( $request_meta['first_name'] ?? '' )
			),
			'last_name'  => sanitize_text_field(
				(string) ( $request_meta['last_name'] ?? '' )
			),
			'phone'      => sanitize_text_field(
				(string) ( $request_meta['phone'] ?? '' )
			),
			'email'      => sanitize_email(
				(string) ( $request_meta['email'] ?? '' )
			),
		];
		
		$result = $this->persist_user(
			$employee_id,
			$payload
		);
		
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		
		$this->save_employee_data(
			$employee_id,
			[
				'employee_code'     => $request_meta['employee_code'] ?? '',
				'role_key'          => $request_meta['role_key'] ?? '',
				'employment_type'   => $request_meta['employment_type'] ?? '',
				'employment_status' => $request_meta['employment_status'] ?? '',
				'started_at'        => $request_meta['started_at'] ?? '',
				'ended_at'          => $request_meta['ended_at'] ?? '',
			]
		);
		$this->save_custom_fields_from_request(
			$employee_id,
			$request_meta,
			'profile'
		);
		
		do_action(
			'kerp_employee_profile_updated',
			$employee_id,
			$request_meta,
			$employee
		);
		
		$page_response                = KERP_Api_Page_Content::build_page_response(
			'/erp/employees/' . $employee_id . '/',
			[ 'tab' => 'profile' ],
			TRUE
		);
		$page_response['employee_id'] = $employee_id;
		
		$this->success(
			__( 'اطلاعات کارمند با موفقیت ذخیره شد.', 'kasebi-erp' ),
			$page_response
		);
	}

	public function change_profile_image(): void {
		$this->guard( 'employees.update' );

		$employee_id = absint( $_POST['employee_id'] ?? 0 );
		$employee    = KERP_Modules_Employees_Query::instance()->get_employee(
			$employee_id
		);

		if ( ! $employee instanceof WP_User ) {
			$this->error( __( 'کارمند پیدا نشد.', 'kasebi-erp' ) );
		}

		$image = isset( $_POST['image'] ) && ! is_array( $_POST['image'] )
			? esc_url_raw( wp_unslash( $_POST['image'] ) )
			: '';

		if ( $image === '' ) {
			$this->error( __( 'تصویر انتخاب‌شده معتبر نیست.', 'kasebi-erp' ) );
		}

		update_user_meta(
			$employee_id,
			'nooshika_user_avatar_url',
			$image
		);

		$active_tab = sanitize_key(
			(string) ( $_POST['tab'] ?? 'profile' )
		);
		$active_tab = $active_tab !== '' ? $active_tab : 'profile';
		$route      = '/erp/employees/' . $employee_id . '/';

		$page_response = KERP_Api_Page_Content::build_page_response(
			$route,
			[ 'tab' => $active_tab ],
			TRUE
		);

		$this->success(
			__( 'تصویر پروفایل کارمند با موفقیت ذخیره شد.', 'kasebi-erp' ),
			$page_response
		);
	}

	public function handle_profile_image_upload(): void {
		$this->guard( 'employees.update' );

		if ( empty( $_FILES['file'] ) || ! is_array( $_FILES['file'] ) ) {
			$this->error( __( 'فایل تصویر ارسال نشده است.', 'kasebi-erp' ) );
		}

		$context = [
			'file_name'         => isset( $_POST['file_name'] )
				? sanitize_text_field( wp_unslash( $_POST['file_name'] ) )
				: '',
			'dzuuid'            => isset( $_POST['dzuuid'] )
				? sanitize_text_field( wp_unslash( $_POST['dzuuid'] ) )
				: '',
			'dzchunkindex'      => isset( $_POST['dzchunkindex'] )
				? (int) $_POST['dzchunkindex']
				: -1,
			'dztotalchunkcount' => isset( $_POST['dztotalchunkcount'] )
				? (int) $_POST['dztotalchunkcount']
				: -1,
			'dztotalfilesize'   => isset( $_POST['dztotalfilesize'] )
				? absint( $_POST['dztotalfilesize'] )
				: 0,
			'direct'            => TRUE,
		];

		$result = KERP_Helpers_File::instance()->handle_upload_file(
			$_FILES['file'],
			'user_avatars',
			$context
		);

		wp_send_json(
			[
				'status'     => ! empty( $result['ok'] ) ? 'success' : 'error',
				'message'    => (string) ( $result['msg'] ?? '' ),
				'attachment' => (string) ( $result['url'] ?? '' ),
				'url'        => (string) ( $result['url'] ?? '' ),
				'storage'    => (string) ( $result['storage'] ?? '' ),
				'data'       => $result,
			]
		);
	}
	
	public function save_default_page(): void {
		$this->guard( 'employees.access.manage' );
		$nonce = $this->post_text( 'default_page_nonce' );
		if ( ! is_user_logged_in() || ! KERP_App::instance()->current_user_has_access() || ! wp_verify_nonce( $nonce, 'kerp-employee-default-page' ) ) {
			$this->error( __( 'درخواست معتبر نیست؛ صفحه را تازه‌سازی کنید.', 'kasebi-erp' ) );
		}
		$employee_id = absint( $_POST['employee_id'] ?? 0 );
		$employee = KERP_Modules_Employees_Query::instance()->get_employee( $employee_id );
		if ( ! $employee instanceof WP_User ) {
			$this->error( __( 'کارمند پیدا نشد.', 'kasebi-erp' ) );
		}
		if ( ! isset( $_POST['default_page'] ) || ! is_string( $_POST['default_page'] ) ) {
			$this->error( __( 'صفحه پیش‌فرض معتبر نیست.', 'kasebi-erp' ) );
		}
		$page = wp_unslash( $_POST['default_page'] );
		$options = KERP_App::instance()->get_user_default_page_options( $employee_id );
		if ( ! array_key_exists( $page, $options ) ) {
			$this->error( __( 'صفحه انتخاب‌شده فعال نیست یا کارمند به آن دسترسی ندارد.', 'kasebi-erp' ) );
		}
		$current = get_user_meta( $employee_id, 'kerp_default_page', TRUE );
		if ( $current !== $page && ! update_user_meta( $employee_id, 'kerp_default_page', $page ) ) {
			$this->error( __( 'ذخیره صفحه پیش‌فرض انجام نشد.', 'kasebi-erp' ) );
		}
		$this->success(
			__( 'صفحه پیش‌فرض کارمند ذخیره شد.', 'kasebi-erp' ),
			KERP_Api_Page_Content::build_page_response( '/erp/employees/' . $employee_id . '/', [ 'tab' => 'access' ], TRUE )
		);
	}

	public function save_access(): void {
		$this->guard( 'employees.access.manage' );
		
		$employee_id = absint( $_POST['employee_id'] ?? 0 );
		$employee    = KERP_Modules_Employees_Query::instance()->get_employee(
			$employee_id
		);
		
		if ( ! $employee instanceof WP_User ) {
			$this->error( __( 'کارمند پیدا نشد.', 'kasebi-erp' ) );
		}
		
		$record = KERP_Services_Access::get_record( $employee_id );
		
		if ( ! is_array( $record ) ) {
			$this->error( __( 'رکورد دسترسی کارمند پیدا نشد.', 'kasebi-erp' ) );
		}
		
		$role_key = KERP_Modules_Employees_Roles::instance()->normalize_key(
			(string) ( $record['role_key'] ?? '' )
		);
		$role     = KERP_Modules_Employees_Roles::instance()->get( $role_key );
		
		if ( ! is_array( $role ) ) {
			$this->error( __( 'نقش سازمانی کارمند معتبر نیست.', 'kasebi-erp' ) );
		}
		
		$current_permissions = [
			'view'   => $this->decode_permissions(
				$record['view_permissions'] ?? ''
			),
			'action' => $this->decode_permissions(
				$record['action_permissions'] ?? ''
			),
		];
		$resolved            = KERP_Modules_Employees_Permissions::instance()
		                                                         ->resolve_employee_selection(
			                                                         $this->post_array( 'permission_ids' ),
			                                                         $this->post_array( 'permission_scopes' ),
			                                                         $current_permissions
		                                                         );
		
		$result = KERP_Services_Access::set_permissions(
			$employee_id,
			$resolved['view'],
			$resolved['action'],
			$this->get_access_preserved_args( $record, $role_key )
		);
		
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		
		do_action(
			'kerp_employee_access_updated',
			$employee_id,
			$resolved,
			$record
		);
		
		$page_response = KERP_Api_Page_Content::build_page_response(
			'/erp/employees/' . $employee_id . '/',
			[ 'tab' => 'access' ],
			TRUE
		);
		
		$this->success(
			__( 'دسترسی‌های کارمند ذخیره شد.', 'kasebi-erp' ),
			$page_response
		);
	}
	
	public function reset_access_to_role(): void {
		$this->guard( 'employees.access.manage' );
		
		$employee_id = absint( $_POST['employee_id'] ?? 0 );
		$employee    = KERP_Modules_Employees_Query::instance()->get_employee(
			$employee_id
		);
		
		if ( ! $employee instanceof WP_User ) {
			$this->error( __( 'کارمند پیدا نشد.', 'kasebi-erp' ) );
		}
		
		$role_key = KERP_Modules_Employees_Roles::instance()->normalize_key(
			$this->post_text( 'role_key' )
		);
		$role     = KERP_Modules_Employees_Roles::instance()->get( $role_key );
		
		if ( ! is_array( $role ) || empty( $role['active'] ) ) {
			$this->error( __( 'نقش سازمانی فعال و معتبر نیست.', 'kasebi-erp' ) );
		}
		
		$defaults = KERP_Modules_Employees_Permissions::instance()
		                                              ->get_defaults( $role_key );
		$record   = KERP_Services_Access::get_record( $employee_id );
		$result   = KERP_Services_Access::set_permissions(
			$employee_id,
			$defaults['view'],
			$defaults['action'],
			$this->get_access_preserved_args( $record, $role_key )
		);
		
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		
		do_action(
			'kerp_employee_access_reset_to_role',
			$employee_id,
			$role_key,
			$defaults,
			$employee
		);
		
		$page_response = KERP_Api_Page_Content::build_page_response(
			'/erp/employees/' . $employee_id . '/',
			[ 'tab' => 'access' ],
			TRUE
		);
		
		$this->success(
			sprintf(
				__( 'نقش و دسترسی‌های %1$s براساس «%2$s» بازنشانی شد.', 'kasebi-erp' ),
				get_user_name_by_id( $employee_id ),
				(string) ( $role['label'] ?? $role_key )
			),
			$page_response
		);
	}
	
	public function apply_role_defaults(): void {
		$this->guard( 'employees.access.manage' );
		
		$role_key = KERP_Modules_Employees_Roles::instance()->normalize_key(
			$this->post_text( 'role_key' )
		);
		$defaults = KERP_Modules_Employees_Permissions::instance()
		                                              ->get_defaults( $role_key );
		
		$this->success(
			__( 'دسترسی‌های پیش‌فرض نقش دریافت شد.', 'kasebi-erp' ),
			[
				'permissions' => array_values(
					array_unique(
						array_merge(
							$defaults['view'],
							$defaults['action']
						)
					)
				),
			]
		);
	}
	
	public function save_settings(): void {
		$this->guard( 'employees.access.manage' );
		
		$settings = isset( $_POST['settings'] )
		            && is_array( $_POST['settings'] )
			? wp_unslash( $_POST['settings'] )
			: [];
		
		KERP_Modules_Employees_Settings::instance()->save( $settings );
		
		$page_response = KERP_Api_Page_Content::build_page_response(
			'/erp/settings/employees/',
			[],
			TRUE
		);
		
		$this->success(
			sprintf(
				__( 'تنظیمات %s ذخیره شد.', 'kasebi-erp' ),
				KERP_Modules_Employees_Settings::instance()
				                               ->get_plural_label()
			),
			$page_response
		);
	}
	
	public function save_fields(): void {
		$this->guard( 'employees.access.manage' );
		
		$field = isset( $_POST['field'] )
		         && is_array( $_POST['field'] )
			? wp_unslash( $_POST['field'] )
			: [];
		
		$field_key   = sanitize_key(
			(string) ( $field['key'] ?? '' )
		);
		$field_label = sanitize_text_field(
			(string) ( $field['label'] ?? '' )
		);
		
		if ( $field_key === '' ) {
			$this->error( __( 'کلید فیلد را وارد کنید.', 'kasebi-erp' ) );
		}
		
		if ( $field_label === '' ) {
			$this->error( __( 'عنوان فیلد را وارد کنید.', 'kasebi-erp' ) );
		}
		
		$field['key']      = $field_key;
		$field['name']     = $field_key;
		$field['meta_key'] = $field_key;
		$field['label']    = $field_label;
		$field['required'] = FALSE;
		
		KERP_Modules_Employees_Fields::instance()->upsert( $field );
		
		$page_response = KERP_Api_Page_Content::build_page_response(
			'/erp/settings/employees/fields/',
			[],
			TRUE
		);
		
		$this->success(
			__( 'فیلد اختصاصی با موفقیت ذخیره شد.', 'kasebi-erp' ),
			$page_response
		);
	}
	
	public function delete_field(): void {
		$this->guard( 'employees.access.manage' );
		
		$field_key = sanitize_key(
			$this->post_text( 'key' )
				?: $this->post_text( 'item_id' )
		);
		
		if ( $field_key === '' ) {
			$this->error( __( 'شناسه فیلد ارسال نشده است.', 'kasebi-erp' ) );
		}
		
		KERP_Modules_Employees_Fields::instance()->delete( $field_key );
		
		$page_response = KERP_Api_Page_Content::build_page_response(
			'/erp/settings/employees/fields/',
			[],
			TRUE
		);
		
		$this->success(
			__( 'فیلد اختصاصی با موفقیت حذف شد.', 'kasebi-erp' ),
			$page_response
		);
	}
	
	public function delete(): void {
		$this->guard( 'employees.delete' );
		
		$employee_id = absint(
			$_POST['employee_id']
			?? $_POST['item_id']
			   ?? 0
		);
		
		if ( $employee_id <= 0 ) {
			$this->error( __( 'شناسه کارمند معتبر نیست.', 'kasebi-erp' ) );
		}
		
		if ( $employee_id === get_current_user_id() ) {
			$this->error(
				__( 'نمی‌توانید دسترسی ERP حساب خودتان را حذف کنید.', 'kasebi-erp' )
			);
		}
		
		$employee = KERP_Modules_Employees_Query::instance()->get_employee(
			$employee_id
		);
		
		if ( ! $employee instanceof WP_User ) {
			$this->error( __( 'کارمند پیدا نشد.', 'kasebi-erp' ) );
		}
		
		KERP_Services_Access::remove_permissions( $employee_id );
		
		do_action(
			'kerp_employee_deleted',
			$employee_id,
			$employee
		);
		
		$page_response = KERP_Api_Page_Content::build_page_response(
			'/erp/employees/',
			[],
			TRUE
		);
		
		$this->success(
			__( 'کارمند از ERP حذف شد و حساب وردپرس او حفظ شد.', 'kasebi-erp' ),
			$page_response
		);
	}
	
	private function persist_user(
		int $employee_id,
		array $payload
	): int|WP_Error {
		$first_name = sanitize_text_field(
			(string) ( $payload['first_name'] ?? '' )
		);
		$last_name  = sanitize_text_field(
			(string) ( $payload['last_name'] ?? '' )
		);
		$phone      = $this->normalize_phone(
			(string) ( $payload['phone'] ?? '' )
		);
		$email      = sanitize_email(
			(string) ( $payload['email'] ?? '' )
		);
		
		if ( $first_name === '' || $last_name === '' || $phone === '' ) {
			return new WP_Error(
				'kerp_employee_required_fields',
				__( 'نام، نام خانوادگی و شماره موبایل الزامی است.', 'kasebi-erp' )
			);
		}
		
		if ( $email !== '' && ! is_email( $email ) ) {
			return new WP_Error(
				'kerp_employee_invalid_email',
				__( 'ایمیل واردشده معتبر نیست.', 'kasebi-erp' )
			);
		}
		
		$user_data = [
			'first_name'   => $first_name,
			'last_name'    => $last_name,
			'display_name' => trim( $first_name . ' ' . $last_name ),
			'user_email'   => $email,
		];
		
		if ( $employee_id > 0 ) {
			$user_data['ID'] = $employee_id;
			$result          = wp_update_user( $user_data );
		} else {
			$existing_user_id = $this->find_user_by_phone( $phone );
			
			if ( $existing_user_id > 0 ) {
				return new WP_Error(
					'kerp_employee_user_exists',
					__(
						'کاربری با این موبایل وجود دارد؛ او را از بخش کاربران سایت به کارکنان اضافه کنید.',
						'kasebi-erp'
					)
				);
			}
			
			$user_login = sanitize_user( $phone, TRUE );
			
			if ( username_exists( $user_login ) ) {
				$user_login .= '-' . wp_generate_password(
						4,
						FALSE,
						FALSE
					);
			}
			
			if ( ! get_role( 'employee' ) instanceof WP_Role ) {
				add_role(
					'employee',
					__( 'کارمند', 'kasebi-erp' ),
					[
						'read' => TRUE,
					]
				);
			}
			
			$wp_role = sanitize_key(
				(string) apply_filters(
					'kerp_employee_new_user_wp_role',
					'employee',
					$payload
				)
			);
			
			if ( ! get_role( $wp_role ) instanceof WP_Role ) {
				$wp_role = 'employee';
			}
			
			$user_data['user_login'] = $user_login;
			$user_data['user_pass']  = wp_generate_password(
				20,
				TRUE,
				TRUE
			);
			$user_data['role']       = $wp_role;
			
			$result = wp_insert_user( $user_data );
		}
		
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		
		$user_id        = (int) $result;
		$phone_meta_key = sanitize_key(
			(string) KERP_Modules_Employees_Settings::instance()->get(
				'phone_meta_key',
				'nooshika_phone_num'
			)
		);
		
		update_user_meta( $user_id, $phone_meta_key, $phone );
		update_user_meta( $user_id, 'billing_phone', $phone );
		
		return $user_id;
	}
	
	private function save_employee_data(
		int $employee_id,
		array $data
	): void {
		$settings = KERP_Modules_Employees_Settings::instance();
		$fields   = KERP_Modules_Employees_Fields::instance();
		$roles    = KERP_Modules_Employees_Roles::instance();
		
		$role_key = $roles->normalize_key(
			(string) ( $data['role_key'] ?? '' )
		);
		$role     = $roles->get( $role_key );
		
		if ( ! is_array( $role ) ) {
			$this->error( __( 'نقش سازمانی معتبر نیست.', 'kasebi-erp' ) );
		}
		
		$status   = sanitize_key(
			(string) ( $data['employment_status'] ?? '' )
		);
		$statuses = $fields->statuses();
		
		if ( ! isset( $statuses[ $status ] ) ) {
			$status = sanitize_key(
				(string) $settings->get( 'default_status', 'active' )
			);
		}
		
		$employment_type  = sanitize_key(
			(string) ( $data['employment_type'] ?? '' )
		);
		$employment_types = $fields->employment_types();
		
		if ( ! isset( $employment_types[ $employment_type ] ) ) {
			$employment_type = 'full_time';
		}
		
		$employee_code = sanitize_text_field(
			(string) ( $data['employee_code'] ?? '' )
		);
		
		if (
			$employee_code === ''
			&& $settings->get( 'auto_employee_code', TRUE )
		) {
			$employee_code = sanitize_text_field(
				                 (string) $settings->get(
					                 'employee_code_prefix',
					                 'EMP-'
				                 )
			                 ) . $employee_id;
		}
		
		update_user_meta(
			$employee_id,
			'kerp_employee_code',
			$employee_code
		);
		update_user_meta(
			$employee_id,
			'kerp_employee_employment_type',
			$employment_type
		);
		update_user_meta(
			$employee_id,
			'kerp_employee_status',
			$status
		);
		update_user_meta(
			$employee_id,
			'kerp_employee_started_at',
			$this->normalize_date(
				(string) ( $data['started_at'] ?? '' )
			)
		);
		update_user_meta(
			$employee_id,
			'kerp_employee_ended_at',
			$this->normalize_date(
				(string) ( $data['ended_at'] ?? '' )
			)
		);
		
		$record = KERP_Services_Access::get_record( $employee_id );
		
		if ( is_array( $record ) ) {
			$view_permissions   = $this->decode_permissions(
				$record['view_permissions'] ?? ''
			);
			$action_permissions = $this->decode_permissions(
				$record['action_permissions'] ?? ''
			);
		} else {
			$defaults           = KERP_Modules_Employees_Permissions::instance()
			                                                        ->get_defaults( $role_key );
			$view_permissions   = $defaults['view'];
			$action_permissions = $defaults['action'];
		}
		
		$result = KERP_Services_Access::set_permissions(
			$employee_id,
			$view_permissions,
			$action_permissions,
			$this->get_access_preserved_args( $record, $role_key )
		);
		
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
	}
	
	private function save_custom_fields_from_request(
		int $employee_id,
		array $request_meta,
		string $context
	): void {
		$fields_service = KERP_Modules_Employees_Fields::instance();
		$definitions    = $fields_service->get_all( FALSE );
		
		foreach ( $definitions as $field_key => $definition ) {
			if ( ! is_array( $definition ) ) {
				continue;
			}
			
			$field_key = sanitize_key(
				(string) ( $definition['key'] ?? $field_key )
			);
			$meta_key  = sanitize_key(
				(string) ( $definition['meta_key'] ?? $field_key )
			);
			
			if ( $meta_key === '' ) {
				continue;
			}
			
			if (
				$context === 'create'
				&& empty( $definition['show_on_create'] )
			) {
				continue;
			}
			
			$value_exists = array_key_exists( $field_key, $request_meta )
			                || array_key_exists( $meta_key, $request_meta );
			
			if ( $value_exists ) {
				$value = array_key_exists( $meta_key, $request_meta )
					? $request_meta[ $meta_key ]
					: $request_meta[ $field_key ];
				
				update_user_meta(
					$employee_id,
					$meta_key,
					$fields_service->sanitize_value(
						$value,
						$definition
					)
				);
				
				continue;
			}
			
			$type = sanitize_key(
				(string) ( $definition['type'] ?? 'text' )
			);
			
			if (
				$context === 'profile'
				&& in_array(
					$type,
					[ 'switch', 'checkbox', 'multi-select' ],
					TRUE
				)
			) {
				update_user_meta(
					$employee_id,
					$meta_key,
					$type === 'switch' ? '0' : []
				);
			}
		}
	}
	
	private function get_access_preserved_args(
		?array $record,
		string $role_key
	): array {
		$args = [ 'role_key' => $role_key ];
		
		if ( ! is_array( $record ) ) {
			return $args;
		}
		
		$assignment_key = sanitize_key(
			(string) ( $record['assignment_key'] ?? '' )
		);
		
		if ( $assignment_key !== '' ) {
			$args['assignment_key'] = $assignment_key;
		}
		
		$meta = json_decode(
			(string) ( $record['meta'] ?? '' ),
			TRUE
		);
		
		if ( is_array( $meta ) ) {
			$args['meta'] = $meta;
		}
		
		return $args;
	}
	
	private function request_meta(): array {
		return isset( $_POST['meta'] ) && is_array( $_POST['meta'] )
			? wp_unslash( $_POST['meta'] )
			: [];
	}
	
	private function decode_permissions( mixed $value ): array {
		$decoded = json_decode( (string) $value, TRUE );
		
		if ( ! is_array( $decoded ) ) {
			return [];
		}
		
		$clean = [];
		
		foreach ( $decoded as $permission ) {
			if ( ! is_scalar( $permission ) ) {
				continue;
			}
			
			$permission = strtolower( trim( (string) $permission ) );
			
			if ( $permission !== '' ) {
				$clean[] = $permission;
			}
		}
		
		return array_values( array_unique( $clean ) );
	}
	
	private function normalize_date( string $value ): string {
		$value = sanitize_text_field( $value );
		
		if ( $value === '' ) {
			return '';
		}
		
		if (
			class_exists( 'KERP_Helpers_Date' )
			&& method_exists( 'KERP_Helpers_Date', 'jalali_to_gregorian' )
		) {
			$converted = KERP_Helpers_Date::jalali_to_gregorian( $value );
			
			if ( is_string( $converted ) && $converted !== '' ) {
				return $converted;
			}
		}
		
		return $value;
	}
	
	private function find_user_by_phone( string $phone ): int {
		$users = get_users(
			[
				'number'     => 1,
				'fields'     => 'ids',
				'meta_key'   => (string) KERP_Modules_Employees_Settings::instance()
				                                                        ->get( 'phone_meta_key', 'nooshika_phone_num' ),
				'meta_value' => $phone,
			]
		);
		
		return absint( $users[0] ?? 0 );
	}
	
	private function normalize_phone( string $phone ): string {
		if ( function_exists( 'nooshika_sanitize_numbers' ) ) {
			$phone = nooshika_sanitize_numbers( $phone );
		}
		
		$phone = preg_replace( '/[^0-9+]/', '', $phone ) ?? '';
		
		if ( function_exists( 'remove_zero_from_phone' ) ) {
			return (string) remove_zero_from_phone( $phone );
		}
		
		return ltrim( $phone, '0' );
	}
	
	private function guard( string $permission ): void {
		if ( ! kerp_can( $permission, 'action' ) ) {
			$this->error( __( 'دسترسی لازم را ندارید.', 'kasebi-erp' ) );
		}
	}
	
	private function post_text( string $key ): string {
		if ( ! isset( $_POST[ $key ] ) || is_array( $_POST[ $key ] ) ) {
			return '';
		}
		
		return sanitize_text_field(
			wp_unslash( $_POST[ $key ] )
		);
	}
	
	private function post_array( string $key ): array {
		if ( ! isset( $_POST[ $key ] ) || ! is_array( $_POST[ $key ] ) ) {
			return [];
		}
		
		return wp_unslash( $_POST[ $key ] );
	}
	
	private function success(
		string $message,
		array $data = []
	): never {
		wp_send_json(
			array_merge(
				[
					'status'  => 'success',
					'message' => $message,
					'msg'     => $message,
				],
				$data
			)
		);
	}
	
	private function error(
		string $message,
		array $data = []
	): never {
		wp_send_json(
			array_merge(
				[
					'status'  => 'error',
					'message' => $message,
					'msg'     => $message,
				],
				$data
			)
		);
	}
	
}
