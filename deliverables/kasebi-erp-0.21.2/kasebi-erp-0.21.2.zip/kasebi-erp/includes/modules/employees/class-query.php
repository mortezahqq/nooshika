<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Employees_Query {
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public function get_employee( int $user_id ): ?WP_User {
		if ( $user_id <= 0 ) {
			return NULL;
		}
		
		$access = KERP_Services_Access::get_record( $user_id );
		
		if (
			! is_array( $access )
			|| sanitize_key( (string) ( $access['role_key'] ?? '' ) ) === ''
		) {
			return NULL;
		}
		
		$user = get_userdata( $user_id );
		
		return $user instanceof WP_User ? $user : NULL;
	}
	
	public function find( array $args = [], bool $enforce_scope = TRUE ): array {
		global $wpdb;
		
		$settings = KERP_Modules_Employees_Settings::instance();
		$defaults = [
			'per_page'    => (int) $settings->get( 'default_per_page', 20 ),
			'page_number' => 1,
			'search'      => '',
			'role_key'    => '',
			'status'      => '',
			'include'     => [],
			'orderby'     => 'display_name',
			'order'       => 'ASC',
		];
		
		$args = wp_parse_args( $args, $defaults );
		$args = apply_filters( 'kerp_employees_query_args', $args );
		if ( $enforce_scope ) {
			$scope = kerp_list_scope( 'employees' );
			
			if ( $scope === 'none' ) {
				return $this->empty_result( $args );
			}
			
			if ( $scope === 'own' ) {
				$args['include'] = [ get_current_user_id() ];
			}
		}
		if ( $scope === 'none' ) {
			return $this->empty_result( $args );
		}
		
		if ( $scope === 'own' ) {
			$args['include'] = [ get_current_user_id() ];
		}
		
		$per_page    = max( 1, min( 100, absint( $args['per_page'] ) ) );
		$page_number = max( 1, absint( $args['page_number'] ) );
		$access      = KERP_Services_Access::table();
		$where       = [
			'a.role_key IS NOT NULL',
			'a.role_key <> \'\'',
		];
		$params      = [];
		
		$role_key = sanitize_key( (string) $args['role_key'] );
		
		if ( $role_key !== '' ) {
			$where[]  = 'a.role_key = %s';
			$params[] = $role_key;
		}
		
		$status = sanitize_key( (string) $args['status'] );
		
		if ( $status !== '' ) {
			$where[]  = "EXISTS (
				SELECT 1
				FROM {$wpdb->usermeta} AS employee_status
				WHERE employee_status.user_id = users.ID
				AND employee_status.meta_key = 'kerp_employee_status'
				AND employee_status.meta_value = %s
			)";
			$params[] = $status;
		}
		
		$include = array_values(
			array_unique(
				array_filter(
					array_map(
						'absint',
						(array) $args['include']
					)
				)
			)
		);
		
		if ( ! empty( $include ) ) {
			$placeholders = implode(
				', ',
				array_fill( 0, count( $include ), '%d' )
			);
			$where[]      = "users.ID IN ({$placeholders})";
			$params       = array_merge( $params, $include );
		}
		
		$search = sanitize_text_field( (string) $args['search'] );
		
		if ( $search !== '' ) {
            // Match only first/last names; separate words may match either field.
            $name_parts = preg_split( '/\s+/u', trim( $search ), -1, PREG_SPLIT_NO_EMPTY );
            foreach ( $name_parts ?: [] as $name_part ) {
                $where[] = "EXISTS (
                    SELECT 1 FROM {$wpdb->usermeta} AS employee_name
                    WHERE employee_name.user_id = users.ID
                        AND employee_name.meta_key IN ('first_name', 'last_name')
                        AND employee_name.meta_value LIKE %s
                )";
                $params[] = '%' . $wpdb->esc_like( $name_part ) . '%';
            }
        }

		$where_sql = implode( ' AND ', $where );
		$count_sql = "
			SELECT COUNT(DISTINCT users.ID)
			FROM {$wpdb->users} AS users
			INNER JOIN {$access} AS a
				ON a.user_id = users.ID
			WHERE {$where_sql}
		";
		
		$total = (int) $wpdb->get_var(
			empty( $params )
				? $count_sql
				: $wpdb->prepare( $count_sql, ...$params )
		);
		
		$allowed_orderby = [
			'display_name' => 'users.display_name',
			'registered'   => 'users.user_registered',
			'id'           => 'users.ID',
		];
		$orderby         = $allowed_orderby[ sanitize_key( (string) $args['orderby'] ) ] ?? 'users.display_name';
		$order           = strtoupper( (string) $args['order'] ) === 'DESC'
			? 'DESC'
			: 'ASC';
		$offset          = ( $page_number - 1 ) * $per_page;
		
		$list_sql    = "
			SELECT DISTINCT users.ID
			FROM {$wpdb->users} AS users
			INNER JOIN {$access} AS a
				ON a.user_id = users.ID
			WHERE {$where_sql}
			ORDER BY {$orderby} {$order}
			LIMIT %d OFFSET %d
		";
		$list_params = array_merge(
			$params,
			[ $per_page, $offset ]
		);
		$user_ids    = $wpdb->get_col(
			$wpdb->prepare(
				$list_sql,
				...$list_params
			)
		);
		$items       = [];
		
		foreach ( $user_ids as $user_id ) {
			$user = get_userdata( (int) $user_id );
			
			if ( $user instanceof WP_User ) {
				$items[] = $user;
			}
		}
		
		$result = [
			'items'        => $items,
			'total'        => $total,
			'per_page'     => $per_page,
			'page_number'  => $page_number,
			'total_pages'  => $per_page > 0
				? (int) ceil( $total / $per_page )
				: 0,
			'request_args' => $args,
		];
		
		return apply_filters(
			'kerp_employees_query_results',
			$result,
			$args
		);
	}
	
	public function get_options( int $exclude = 0, bool $enforce_scope = TRUE ): array {
		$result = $this->find(
			[
				'per_page'    => 100,
				'page_number' => 1,
			],
			$enforce_scope
		);
		
		$options = [];
		
		foreach ( $result['items'] as $user ) {
			if ( (int) $user->ID === $exclude ) {
				continue;
			}
			
			$options[ (int) $user->ID ] = get_user_name_by_id(
				(int) $user->ID
			);
		}
		
		return $options;
	}
	
	public function get_phone( int $user_id ): string {
		$meta_key = sanitize_key(
			(string) KERP_Modules_Employees_Settings::instance()->get(
				'phone_meta_key',
				'nooshika_phone_num'
			)
		);
		
		return sanitize_text_field(
			(string) get_user_meta(
				$user_id,
				$meta_key,
				TRUE
			)
		);
	}
	
	private function empty_result( array $args ): array {
		return [
			'items'        => [],
			'total'        => 0,
			'per_page'     => max(
				1,
				absint( $args['per_page'] ?? 20 )
			),
			'page_number'  => max(
				1,
				absint( $args['page_number'] ?? 1 )
			),
			'total_pages'  => 0,
			'request_args' => $args,
		];
	}
	
}
