<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Employees_Module {
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {
		$this->load_services();
		$this->register_hooks();
	}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	private function load_services(): void {
		KERP_Modules_Employees_Settings::instance();
		KERP_Modules_Employees_Roles::instance();
		KERP_Modules_Employees_Permissions::instance();
		KERP_Modules_Employees_Role_Profile::instance();
		KERP_Modules_Employees_Roles_Api::instance();
		KERP_Modules_Employees_Fields::instance();
		KERP_Modules_Employees_Query::instance();
		KERP_Modules_Employees_Candidates::instance();
		KERP_Modules_Employees_Candidates_Api::instance();
		KERP_Modules_Employees_Profile::instance();
		KERP_Modules_Employees_Api::instance();
	}
	
	private function register_hooks(): void {
		add_filter( 'kerp_app_pages', [ $this, 'register_pages' ], 25 );
		add_filter( 'kerp_employee_permission_groups', [ $this, 'register_employee_permissions' ], 25 );
		add_action( 'kerp_footer_template', [ $this, 'render_add_modal' ] );
		add_action( 'init', [ $this, 'register_employee_role' ], 5 );
	}
	
	public function register_pages( array $pages ): array {
		$settings = KERP_Modules_Employees_Settings::instance();
		
		$employees_group = [
			'key'   => 'employees',
			'title' => __( 'منابع انسانی', 'kasebi-erp' ),
			'icon'  => 'uik-r fa-id-badge',
			'order' => 30,
		];
		$settings_group  = [
			'key'        => 'settings',
			'title'      => __( 'تنظیمات', 'kasebi-erp' ),
			'icon'       => 'kik fa-settings-02',
			'order'      => 100,
			'sep_before' => TRUE,
		];
		$settings_menu   = [
			'key'   => 'employees-settings',
			'title' => sprintf(
				__( 'تنظیمات %s', 'kasebi-erp' ),
				$settings->get_plural_label()
			),
			'icon'  => 'uik-r fa-id-badge',
			'order' => 30,
		];
		
		$pages['employees']                  = [
			'title'      => $settings->get_plural_label(),
			'route'      => 'employees',
			'type'       => 'page',
			'template'   => 'modules/employees/pages/employees.php',
			'permission' => 'employees.view',
			'navigation' => [
				'group' => $employees_group,
				'icon'  => 'ni ni-users',
				'order' => 10,
			],
		];
		$pages['employee']                   = [
			'title'      => sprintf(
				__( 'پروفایل %s', 'kasebi-erp' ),
				$settings->get_singular_label()
			),
			'route'      => 'employees/{employee_id}',
			'type'       => 'sub-page',
			'template'   => 'modules/employees/pages/employee.php',
			'permission' => 'employees.view',
			'navigation' => [
				'hidden' => TRUE,
				'active' => 'employees',
			],
		];
		$pages['employees-settings-general'] = [
			'title'      => sprintf(
				__( 'تنظیمات عمومی %s', 'kasebi-erp' ),
				$settings->get_plural_label()
			),
			'route'      => 'settings/employees',
			'type'       => 'settings',
			'template'   => 'modules/employees/settings/general.php',
			'permission' => 'employees.access.manage',
			'navigation' => [
				'group' => $settings_group,
				'menu'  => $settings_menu,
				'title' => __( 'تنظیمات عمومی', 'kasebi-erp' ),
				'order' => 10,
			],
		];
		$pages['employees-settings-fields']  = [
			'title'      => sprintf(
				__( 'فیلدهای اختصاصی %s', 'kasebi-erp' ),
				$settings->get_plural_label()
			),
			'route'      => 'settings/employees/fields',
			'type'       => 'settings',
			'template'   => 'modules/employees/settings/fields.php',
			'permission' => 'employees.access.manage',
			'navigation' => [
				'group' => $settings_group,
				'menu'  => $settings_menu,
				'title' => __( 'فیلدهای اختصاصی', 'kasebi-erp' ),
				'order' => 20,
			],
		];
		
		$pages['employees-settings-roles'] = [
			'title'      => __( 'نقش‌های سازمانی', 'kasebi-erp' ),
			'route'      => 'settings/employees/roles',
			'type'       => 'settings',
			'template'   => 'modules/employees/settings/roles.php',
			'permission' => 'employees.access.manage',
			'navigation' => [
				'group' => $settings_group,
				'menu'  => $settings_menu,
				'title' => __( 'نقش‌های سازمانی', 'kasebi-erp' ),
				'order' => 30,
			],
		];
		$pages['employees-settings-role']  = [
			'title'      => __( 'جزئیات نقش سازمانی', 'kasebi-erp' ),
			'route'      => 'settings/employees/role/{role_slug}',
			'type'       => 'sub-page',
			'template'   => 'modules/employees/settings/role.php',
			'permission' => 'employees.access.manage',
			'navigation' => [
				'hidden' => TRUE,
				'active' => 'employees-settings-roles',
			],
		];
		
		return $pages;
	}
	
	public function register_employee_permissions( array $groups ): array {
		if ( ! isset( $groups['employees'] ) || ! is_array( $groups['employees'] ) ) {
			$groups['employees'] = [
				'key'    => 'employees',
				'label'  => __( 'منابع انسانی', 'kasebi-erp' ),
				'icon'   => 'uik-r fa-id-badge',
				'order'  => 30,
				'blocks' => [],
			];
		}
		
		$groups['employees']['blocks']['employees'] = [
			'key'         => 'employees',
			'label'       => KERP_Modules_Employees_Settings::instance()->get_plural_label(),
			'icon'        => 'ni ni-users',
			'order'       => 10,
			'permissions' => [
				'employees_view'          => [
					'key'         => 'employees.view',
					'label'       => __( 'دسترسی به بخش کارکنان', 'kasebi-erp' ),
					'description' => __( 'امکان ورود به فهرست و پروفایل کارکنان', 'kasebi-erp' ),
					'type'        => 'view',
					'order'       => 10,
				],
				'employees_list'          => [
					'key'         => 'employees.list',
					'label'       => __( 'مشاهده فهرست کارکنان', 'kasebi-erp' ),
					'description' => __( 'دامنه کارکنانی که در فهرست قابل مشاهده هستند.', 'kasebi-erp' ),
					'type'        => 'view',
					'order'       => 20,
					'scope'       => [
						'options' => [
							'own' => __( 'فقط پروفایل خود', 'kasebi-erp' ),
							'all' => __( 'همه کارکنان', 'kasebi-erp' ),
						],
						'default' => 'own',
					],
				],
				'employees_create'        => [
					'key'   => 'employees.create',
					'label' => __( 'افزودن کارمند', 'kasebi-erp' ),
					'type'  => 'action',
					'order' => 30,
				],
				'employees_update'        => [
					'key'   => 'employees.update',
					'label' => __( 'ویرایش اطلاعات کارمند', 'kasebi-erp' ),
					'type'  => 'action',
					'order' => 40,
				],
				'employees_status_change' => [
					'key'   => 'employees.status.change',
					'label' => __( 'تغییر وضعیت همکاری', 'kasebi-erp' ),
					'type'  => 'action',
					'order' => 50,
				],
				'employees_access_manage' => [
					'key'         => 'employees.access.manage',
					'label'       => __( 'مدیریت نقش‌ها و دسترسی‌ها', 'kasebi-erp' ),
					'description' => __( 'ویرایش نقش سازمانی و دسترسی‌های کارکنان', 'kasebi-erp' ),
					'type'        => 'action',
					'order'       => 60,
				],
				'employees_login_as'      => [
					'key'   => 'employees.login_as',
					'label' => __( 'ورود با حساب کارمند', 'kasebi-erp' ),
					'type'  => 'action',
					'order' => 70,
				],
				'employees_delete'        => [
					'key'   => 'employees.delete',
					'label' => __( 'حذف کارمند از ERP', 'kasebi-erp' ),
					'type'  => 'action',
					'order' => 100,
				],
			],
		];
		
		return $groups;
	}
	
	public function render_add_modal(): void {
		if ( ! kerp_can( 'employees.create', 'action' ) ) {
			return;
		}
		
		$settings = KERP_Modules_Employees_Settings::instance();
		
		KERP_Helpers_Template::render_modal(
			[
				'id'     => 'addEmployee',
				'title'  => sprintf(
					__( 'افزودن %s', 'kasebi-erp' ),
					$settings->get_singular_label()
				),
				'action' => 'employees_create',
				'page'   => 'employees',
				'button' => __( 'ثبت', 'kasebi-erp' ),
				'fields' => KERP_Modules_Employees_Fields::instance()->get_create_fields(),
			]
		);
	}
	
	public function register_employee_role(): void {
		if ( get_role( 'employee' ) instanceof WP_Role ) {
			return;
		}
		
		add_role(
			'employee',
			__( 'کارمند', 'kasebi-erp' ),
			[
				'read' => TRUE,
			]
		);
	}
	
}
