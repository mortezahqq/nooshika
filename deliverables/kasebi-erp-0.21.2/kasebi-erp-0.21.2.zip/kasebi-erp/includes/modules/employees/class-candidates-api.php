<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Employees_Candidates_Api {

	private static ?self $instance = NULL;

	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	private function __construct() {
        add_action( 'kasebi_ajax_employees_assign_existing_users', [ $this, 'assign_existing_users' ] );
		add_action(
			'kasebi_ajax_employees_assign_existing_user',
			[ $this, 'assign_existing_user' ]
		);
	}

	private function __clone() {}

	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}

	public function assign_existing_user(): void {
		$this->guard();

		$user_id  = absint( $_POST['user_id'] ?? 0 );
		$role_key = KERP_Modules_Employees_Roles::instance()->normalize_key(
			$this->post_text( 'role_key' )
		);
		$user      = get_userdata( $user_id );
		$role      = KERP_Modules_Employees_Roles::instance()->get( $role_key );

		if ( ! $user instanceof WP_User ) {
			$this->error( __( 'کاربر پیدا نشد.', 'kasebi-erp' ) );
		}

		if ( ! KERP_Modules_Employees_Candidates::instance()->is_assignable( $user ) ) {
			$this->error(
				__( 'این کاربر قابل افزودن به فهرست کارکنان نیست.', 'kasebi-erp' )
			);
		}

		if ( ! is_array( $role ) || empty( $role['active'] ) ) {
			$this->error( __( 'نقش سازمانی معتبر نیست.', 'kasebi-erp' ) );
		}

        $result = $this->assign_user( $user, $role_key );
        if ( is_wp_error( $result ) ) $this->error( $result->get_error_message() );

		$page_response = KERP_Api_Page_Content::build_page_response(
			'/erp/employees/',
			[
				'section' => 'available',
				'search' => $this->post_text( 'search' ),
				'wp_role' => sanitize_key( $this->post_text( 'wp_role' ) ),
				'page_number' => max( 1, absint( $this->post_text( 'page_number' ) ) ),
                'per_page' => max( 1, min( 50, absint( $this->post_text( 'per_page' ) ?: 12 ) ) ),
			],
			TRUE
		);

		$this->success(
			sprintf(
				__( '%1$s با نقش «%2$s» به فهرست کارکنان اضافه شد.', 'kasebi-erp' ),
				get_user_name_by_id( $user_id ),
				(string) ( $role['label'] ?? $role_key )
			),
			$page_response
		);
	}

    public function assign_existing_users(): void {
        $this->guard();
        if ( ! wp_verify_nonce( $this->post_text( 'employees_nonce' ), 'kerp_employees_bulk_assign' ) ) {
            $this->error( __( 'اعتبار درخواست تمام شده است؛ صفحه را دوباره بارگذاری کنید.', 'kasebi-erp' ) );
        }
        $role_key = KERP_Modules_Employees_Roles::instance()->normalize_key( $this->post_text( 'role_key' ) );
        $role = KERP_Modules_Employees_Roles::instance()->get( $role_key );
        if ( ! is_array( $role ) || empty( $role['active'] ) ) {
            $this->error( __( 'نقش سازمانی معتبر نیست.', 'kasebi-erp' ) );
        }
        $raw_ids = $_POST['user_ids'] ?? [];
        if ( ! is_array( $raw_ids ) || ! $raw_ids || count( $raw_ids ) > 50 ) {
            $this->error( __( 'بین یک تا ۵۰ کاربر را انتخاب کنید.', 'kasebi-erp' ) );
        }
        $ids = [];
        foreach ( $raw_ids as $id ) {
            if ( ! is_scalar( $id ) || ! ctype_digit( (string) $id ) || (int) $id <= 0 ) {
                $this->error( __( 'شناسه کاربران معتبر نیست.', 'kasebi-erp' ) );
            }
            $ids[] = (int) $id;
        }
        $assigned = [];
        $failed = [];
        foreach ( array_unique( $ids ) as $id ) {
            $user = get_userdata( $id );
            $result = $user instanceof WP_User ? $this->assign_user( $user, $role_key ) : new WP_Error( 'missing_user', __( 'کاربر پیدا نشد.', 'kasebi-erp' ) );
            if ( is_wp_error( $result ) ) $failed[ $id ] = $result->get_error_message();
            else $assigned[] = $id;
        }
        $message = sprintf( __( '%1$s کاربر با نقش «%2$s» به کارکنان اضافه شد؛ %3$s کاربر اضافه نشد.', 'kasebi-erp' ), number_format_i18n( count( $assigned ) ), (string) $role['label'], number_format_i18n( count( $failed ) ) );
        foreach ( array_slice( $failed, 0, 5, TRUE ) as $id => $reason ) $message .= ' #' . $id . ': ' . $reason;
        $data = [ 'assigned_ids' => $assigned, 'failed_users' => $failed ];
        if ( ! $assigned ) $this->error( $message, $data );
        $data = array_merge( $data, KERP_Api_Page_Content::build_page_response( '/erp/employees/', [
            'section' => 'available', 'search' => $this->post_text( 'search' ), 'wp_role' => sanitize_key( $this->post_text( 'wp_role' ) ),
            'page_number' => max( 1, absint( $this->post_text( 'page_number' ) ) ), 'per_page' => max( 1, min( 50, absint( $this->post_text( 'per_page' ) ?: 12 ) ) ),
        ], TRUE ) );
        $this->success( $message, $data );
    }

    private function assign_user( WP_User $user, string $role_key ): bool|WP_Error {
        $user_id = (int) $user->ID;
        if ( ! KERP_Modules_Employees_Candidates::instance()->is_assignable( $user ) ) {
            return new WP_Error( 'not_assignable', __( 'این کاربر قابل افزودن به فهرست کارکنان نیست.', 'kasebi-erp' ) );
        }
		$permissions = KERP_Modules_Employees_Permissions::instance()->get_defaults( $role_key );
		$existing    = KERP_Services_Access::get_record( $user_id );
		$views       = $permissions['view'];
		$actions     = $permissions['action'];
		$access_args = [
			'role_key' => $role_key,
		];

		if ( is_array( $existing ) ) {
			$views   = array_values(
				array_unique(
					array_merge(
						$this->decode_list( $existing['view_permissions'] ?? '' ),
						$views
					)
				)
			);
			$actions = array_values(
				array_unique(
					array_merge(
						$this->decode_list( $existing['action_permissions'] ?? '' ),
						$actions
					)
				)
			);

			$access_args['assignment_key'] = sanitize_key(
				(string) ( $existing['assignment_key'] ?? '' )
			);
			$meta = json_decode( (string) ( $existing['meta'] ?? '' ), TRUE );

			if ( is_array( $meta ) ) {
				$access_args['meta'] = $meta;
			}
		}

		$result = KERP_Services_Access::set_permissions(
			$user_id,
			$views,
			$actions,
			$access_args
		);

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		$this->initialize_employee_meta( $user_id );

		do_action(
			'kerp_employee_assigned_from_existing_user',
			$user_id,
			$role_key,
			$user
		);

        return TRUE;
    }

	private function initialize_employee_meta( int $user_id ): void {
		$settings = KERP_Modules_Employees_Settings::instance();

		if ( trim( (string) get_user_meta( $user_id, 'kerp_employee_status', TRUE ) ) === '' ) {
			update_user_meta(
				$user_id,
				'kerp_employee_status',
				sanitize_key( (string) $settings->get( 'default_status', 'active' ) )
			);
		}

		$employee_code = trim(
			(string) get_user_meta( $user_id, 'kerp_employee_code', TRUE )
		);

		if ( $employee_code === '' && $settings->get( 'auto_employee_code', TRUE ) ) {
			update_user_meta(
				$user_id,
				'kerp_employee_code',
				sanitize_text_field(
					(string) $settings->get( 'employee_code_prefix', 'EMP-' )
				) . $user_id
			);
		}
	}

	private function decode_list( mixed $value ): array {
		$decoded = json_decode( (string) $value, TRUE );

		if ( ! is_array( $decoded ) ) {
			return [];
		}

		$clean = [];

		foreach ( $decoded as $permission ) {
			if ( ! is_scalar( $permission ) ) {
				continue;
			}

			$permission = strtolower( trim( (string) $permission ) );

			if ( $permission !== '' ) {
				$clean[] = $permission;
			}
		}

		return array_values( array_unique( $clean ) );
	}

	private function guard(): void {
		if ( ! kerp_can( 'employees.create', 'action' ) ) {
			$this->error( __( 'دسترسی لازم را ندارید.', 'kasebi-erp' ) );
		}
	}

	private function post_text( string $key ): string {
		if ( ! isset( $_POST[ $key ] ) || is_array( $_POST[ $key ] ) ) {
			return '';
		}

		return sanitize_text_field( wp_unslash( $_POST[ $key ] ) );
	}

	private function success( string $message, array $data = [] ): never {
		wp_send_json(
			array_merge(
				[
					'status'  => 'success',
					'message' => $message,
					'msg'     => $message,
				],
				$data
			)
		);
	}

	private function error( string $message, array $data = [] ): never {
		wp_send_json(
			array_merge(
				[
					'status'  => 'error',
					'message' => $message,
					'msg'     => $message,
				],
				$data
			)
		);
	}
}
