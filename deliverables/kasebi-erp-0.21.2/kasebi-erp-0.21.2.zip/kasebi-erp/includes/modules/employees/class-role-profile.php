<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Employees_Role_Profile {
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public function get_context( string $role_slug, string $requested_tab = '' ): array {
		$role = KERP_Modules_Employees_Roles::instance()->get_by_slug( $role_slug );
		
		if ( ! is_array( $role ) ) {
			return [
				'role'       => NULL,
				'tabs'       => [],
				'active_tab' => '',
			];
		}
		
		$tabs       = $this->get_tabs( $role );
		$active_tab = $this->resolve_active_tab( $requested_tab, $tabs );
		
		return apply_filters(
			'kerp_employee_role_profile_context',
			[
				'role'       => $role,
				'role_key'   => (string) $role['key'],
				'tabs'       => $tabs,
				'active_tab' => $active_tab,
			],
			$role
		);
	}
	
	public function get_tabs( array $role ): array {
		$tabs = [
			'general-settings' => [
				'key'   => 'general-settings',
				'title' => __( 'تنظیمات عمومی نقش', 'kasebi-erp' ),
				'icon'  => 'kik fa-settings-02',
				'order' => 10,
				'type'  => 'general-settings',
			],
		];
		
		foreach ( KERP_Modules_Employees_Permissions::instance()->get_groups() as $group_key => $group ) {
			$group_key = sanitize_key( (string) ( $group['key'] ?? $group_key ) );
			
			if ( $group_key === '' || empty( $group['blocks'] ) ) {
				continue;
			}
			
			$tabs[ $group_key ] = [
				'key'   => $group_key,
				'title' => (string) ( $group['label'] ?? $group_key ),
				'icon'  => (string) ( $group['icon'] ?? 'ni ni-lock-alt' ),
				'order' => 100 + (int) ( $group['order'] ?? 100 ),
				'type'  => 'permissions',
				'group' => $group,
			];
		}
		
		$tabs = apply_filters(
			'kerp_employee_role_profile_tabs',
			$tabs,
			(string) $role['key'],
			$role
		);
		$tabs = is_array( $tabs ) ? $tabs : [];
		uasort( $tabs, [ $this, 'sort_tabs' ] );
		
		return $tabs;
	}
	
	public function render_tab( string $tab_key, array $context ): void {
		$tabs = isset( $context['tabs'] ) && is_array( $context['tabs'] )
			? $context['tabs']
			: [];
		$tab  = isset( $tabs[ $tab_key ] ) && is_array( $tabs[ $tab_key ] )
			? $tabs[ $tab_key ]
			: [];
		
		if ( empty( $tab ) ) {
			return;
		}
		
		$template = (string) ( $tab['type'] ?? 'permissions' ) === 'general-settings'
			? 'modules/employees/settings/role-tabs/general-settings.php'
			: 'modules/employees/settings/role-tabs/permissions.php';
		
		KERP_Helpers_Template::render_template(
			$template,
			[
				'role'         => $context['role'],
				'role_key'     => (string) $context['role_key'],
				'role_context' => $context,
				'tab'          => $tab,
			]
		);
	}
	
	public function sort_tabs( array $first_tab, array $second_tab ): int {
		return (int) ( $first_tab['order'] ?? 100 ) <=> (int) ( $second_tab['order'] ?? 100 );
	}
	
	private function resolve_active_tab( string $requested_tab, array $tabs ): string {
		$requested_tab = sanitize_key( $requested_tab );
		
		if ( $requested_tab !== '' && isset( $tabs[ $requested_tab ] ) ) {
			return $requested_tab;
		}
		
		return isset( $tabs['general-settings'] ) ? 'general-settings' : (string) array_key_first( $tabs );
	}
	
}
