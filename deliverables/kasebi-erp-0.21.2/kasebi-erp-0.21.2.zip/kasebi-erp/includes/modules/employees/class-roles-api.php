<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Employees_Roles_Api {
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {
		$this->register_hooks();
	}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	private function register_hooks(): void {
		add_action( 'kasebi_ajax_employees_create_role', [ $this, 'create_role' ] );
		add_action( 'kasebi_ajax_employees_update_role', [ $this, 'update_role' ] );
		add_action( 'kasebi_ajax_employees_save_role_permissions', [ $this, 'save_role_permissions' ] );
		add_action( 'kasebi_ajax_employees_delete_role', [ $this, 'delete_role' ] );
	}
	
	public function create_role(): void {
		$this->guard();
		$role = KERP_Modules_Employees_Roles::instance()->create( $this->post_array( 'role' ) );
		
		if ( is_wp_error( $role ) ) {
			$this->error( $role->get_error_message() );
		}
		
		$role_url = KERP_Modules_Employees_Roles::instance()->get_url( (string) $role['key'] );
		$page     = KERP_Api_Page_Content::build_page_response( $role_url, [], TRUE );
		$this->success( __( 'نقش سازمانی با موفقیت ایجاد شد.', 'kasebi-erp' ), $page );
	}
	
	public function update_role(): void {
		$this->guard();
		$roles_service = KERP_Modules_Employees_Roles::instance();
		$role_key      = $roles_service->normalize_key( $this->post_text( 'role_key' ) );
		$role          = $roles_service->update( $role_key, $this->post_array( 'role' ) );
		
		if ( is_wp_error( $role ) ) {
			$this->error( $role->get_error_message() );
		}
		
		$page = KERP_Api_Page_Content::build_page_response(
			add_query_arg( 'tab', 'general-settings', $roles_service->get_url( $role_key ) ),
			[],
			TRUE
		);
		$this->success( __( 'تنظیمات عمومی نقش ذخیره شد.', 'kasebi-erp' ), $page );
	}
	
	public function save_role_permissions(): void {
		$this->guard();
		$roles_service       = KERP_Modules_Employees_Roles::instance();
		$permissions_service = KERP_Modules_Employees_Permissions::instance();
		$role_key            = $roles_service->normalize_key( $this->post_text( 'role_key' ) );
		$group_key           = sanitize_key( $this->post_text( 'group_key' ) );
		$permission_ids      = $this->post_array( 'permission_ids' );
		$permission_scopes   = $this->post_array( 'permission_scopes' );
		$saved               = $permissions_service->save_role_group_defaults(
			$role_key,
			$group_key,
			$permission_ids,
			$permission_scopes
		);
		
		if ( is_wp_error( $saved ) ) {
			$this->error( $saved->get_error_message() );
		}
		
		$page = KERP_Api_Page_Content::build_page_response(
			add_query_arg( 'tab', $group_key, $roles_service->get_url( $role_key ) ),
			[],
			TRUE
		);
		$this->success( __( 'دسترسی‌های پیش‌فرض این بخش ذخیره شد.', 'kasebi-erp' ), $page );
	}
	
	public function delete_role(): void {
		$this->guard();
		$roles_service        = KERP_Modules_Employees_Roles::instance();
		$role_key             = $roles_service->normalize_key( $this->post_text( 'role_key' ) );
		$replacement_role_key = $roles_service->normalize_key( $this->post_text( 'replacement_role_key' ) );
		$deleted              = $roles_service->delete( $role_key, $replacement_role_key );
		
		if ( is_wp_error( $deleted ) ) {
			$this->error( $deleted->get_error_message() );
		}
		
		KERP_Modules_Employees_Permissions::instance()->delete_role_defaults( $role_key );
		$page = KERP_Api_Page_Content::build_page_response( '/erp/settings/employees/roles/', [], TRUE );
		$this->success( __( 'نقش سازمانی حذف شد و نقش کارکنان آن تغییر کرد.', 'kasebi-erp' ), $page );
	}
	
	private function guard(): void {
		if ( function_exists( 'kerp_can' ) && kerp_can( 'employees.access.manage', 'action' ) ) {
			return;
		}
		
		if ( current_user_can( 'list_users' ) ) {
			return;
		}
		
		$this->error( __( 'دسترسی لازم را ندارید.', 'kasebi-erp' ) );
	}
	
	private function post_text( string $key ): string {
		if ( ! isset( $_POST[ $key ] ) || is_array( $_POST[ $key ] ) ) {
			return '';
		}
		
		return sanitize_text_field( wp_unslash( $_POST[ $key ] ) );
	}
	
	private function post_array( string $key ): array {
		if ( ! isset( $_POST[ $key ] ) || ! is_array( $_POST[ $key ] ) ) {
			return [];
		}
		
		return wp_unslash( $_POST[ $key ] );
	}
	
	private function success( string $message, array $data = [] ): never {
		wp_send_json(
			array_merge(
				[
					'status'  => 'success',
					'message' => $message,
					'msg'     => $message,
				],
				$data
			)
		);
	}
	
	private function error( string $message, array $data = [] ): never {
		wp_send_json(
			array_merge(
				[
					'status'  => 'error',
					'message' => $message,
					'msg'     => $message,
				],
				$data
			)
		);
	}
	
}
