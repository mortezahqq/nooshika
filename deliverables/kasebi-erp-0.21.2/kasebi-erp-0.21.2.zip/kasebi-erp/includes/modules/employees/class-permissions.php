<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Employees_Permissions {
	public const ROLE_DEFAULTS_OPTION = 'kerp_employees_role_default_permissions';

	private static ?self $instance = NULL;

	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	private function __construct() {}

	private function __clone() {}

	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}

	public function get_groups(): array {
		$groups = [
			'general' => [
				'key'    => 'general',
				'label'  => __( 'عمومی', 'kasebi-erp' ),
				'icon'   => 'uik fa-dashboard',
				'order'  => 10,
				'blocks' => [
					'dashboard' => [
						'key'         => 'dashboard',
						'label'       => __( 'میزکار', 'kasebi-erp' ),
						'icon'        => 'uik fa-apps',
						'order'       => 10,
						'permissions' => [
							'dashboard_view' => [
								'key'   => 'dashboard.view',
								'label' => __( 'مشاهده میزکار', 'kasebi-erp' ),
								'type'  => 'view',
								'order' => 10,
							],
						],
					],
				],
			],
		];
		$groups = apply_filters( 'kerp_employee_permission_groups', $groups );
		$groups = is_array( $groups ) ? $groups : [];
		$groups = $this->sync_with_navigation( $groups );
		$clean  = [];

		foreach ( $groups as $group_key => $group ) {
			if ( ! is_array( $group ) ) {
				continue;
			}

			$group = $this->sanitize_group( (string) $group_key, $group );

			if ( $group['key'] === '' || empty( $group['blocks'] ) ) {
				continue;
			}

			$clean[ $group['key'] ] = $group;
		}

		uasort( $clean, [ $this, 'sort_by_order' ] );

		return $clean;
	}

	public function get_group( string $group_key ): ?array {
		$group_key = sanitize_key( $group_key );
		$groups    = $this->get_groups();

		return isset( $groups[ $group_key ] ) ? $groups[ $group_key ] : NULL;
	}

	public function get_defaults( string $role_key ): array {
		$role_key     = KERP_Modules_Employees_Roles::instance()->normalize_key( $role_key );
		$all_defaults = $this->get_hook_defaults( $role_key );
		$defaults     = isset( $all_defaults[ $role_key ] ) && is_array( $all_defaults[ $role_key ] )
			? $all_defaults[ $role_key ]
			: [];
		$defaults     = apply_filters(
			'kerp_employee_role_default_permissions',
			$defaults,
			$role_key,
			$all_defaults
		);
		$defaults     = is_array( $defaults ) ? $defaults : [];
		$saved        = get_option( self::ROLE_DEFAULTS_OPTION, [] );
		$saved        = is_array( $saved ) ? $saved : [];

		if ( isset( $saved[ $role_key ] ) && is_array( $saved[ $role_key ] ) ) {
			$defaults = $saved[ $role_key ];
		}

		return [
			'view'   => $this->sanitize_permissions( (array) ( $defaults['view'] ?? [] ) ),
			'action' => $this->sanitize_permissions( (array) ( $defaults['action'] ?? [] ) ),
		];
	}

	public function save_role_defaults(
		string $role_key,
		array $view_permissions,
		array $action_permissions
	): bool|WP_Error {
		$role_key = KERP_Modules_Employees_Roles::instance()->normalize_key( $role_key );

		if ( $role_key === '' || ! KERP_Modules_Employees_Roles::instance()->get( $role_key ) ) {
			return new WP_Error(
				'kerp_employee_role_permissions_invalid_role',
				__( 'نقش سازمانی معتبر نیست.', 'kasebi-erp' )
			);
		}

		$defaults              = get_option( self::ROLE_DEFAULTS_OPTION, [] );
		$defaults              = is_array( $defaults ) ? $defaults : [];
		$defaults[ $role_key ] = [
			'view'   => $this->sanitize_permissions( $view_permissions ),
			'action' => $this->sanitize_permissions( $action_permissions ),
		];

		return $this->update_defaults_option( $defaults, $role_key );
	}

	public function save_role_group_defaults(
		string $role_key,
		string $group_key,
		array $selected_permission_ids,
		array $permission_scopes = []
	): bool|WP_Error {
		$role_key = KERP_Modules_Employees_Roles::instance()->normalize_key( $role_key );
		$group_key = sanitize_key( $group_key );
		$group      = $this->get_group( $group_key );

		if ( $role_key === '' || ! KERP_Modules_Employees_Roles::instance()->get( $role_key ) ) {
			return new WP_Error(
				'kerp_employee_role_permissions_invalid_role',
				__( 'نقش سازمانی معتبر نیست.', 'kasebi-erp' )
			);
		}

		if ( ! is_array( $group ) ) {
			return new WP_Error(
				'kerp_employee_permission_group_invalid',
				__( 'گروه دسترسی معتبر نیست.', 'kasebi-erp' )
			);
		}

		$known          = $this->get_group_permission_keys( $group );
		$selected       = $this->resolve_group_selection(
			$group,
			$selected_permission_ids,
			$permission_scopes
		);
		$current        = $this->get_defaults( $role_key );
		$current_view   = array_values( array_diff( $current['view'], $known['view'] ) );
		$current_action = array_values( array_diff( $current['action'], $known['action'] ) );

		return $this->save_role_defaults(
			$role_key,
			array_merge( $current_view, $selected['view'] ),
			array_merge( $current_action, $selected['action'] )
		);
	}

	public function delete_role_defaults( string $role_key ): bool {
		$role_key = KERP_Modules_Employees_Roles::instance()->normalize_key( $role_key );
		$defaults = get_option( self::ROLE_DEFAULTS_OPTION, [] );
		$defaults = is_array( $defaults ) ? $defaults : [];

		if ( ! array_key_exists( $role_key, $defaults ) ) {
			return TRUE;
		}

		unset( $defaults[ $role_key ] );
		$updated = update_option( self::ROLE_DEFAULTS_OPTION, $defaults, FALSE );

		return $updated || get_option( self::ROLE_DEFAULTS_OPTION, [] ) === $defaults;
	}

	public function is_permission_selected( array $permission, array $defaults ): bool {
		$type        = (string) ( $permission['type'] ?? 'action' ) === 'view' ? 'view' : 'action';
		$permissions = isset( $defaults[ $type ] ) && is_array( $defaults[ $type ] )
			? $defaults[ $type ]
			: [];

		if ( $this->has_scope( $permission ) ) {
			return $this->get_selected_scope( $permission, $defaults ) !== '';
		}

		return in_array( (string) ( $permission['key'] ?? '' ), $permissions, TRUE );
	}

	public function get_selected_scope( array $permission, array $defaults ): string {
		if ( ! $this->has_scope( $permission ) ) {
			return '';
		}

		$type        = (string) ( $permission['type'] ?? 'action' ) === 'view' ? 'view' : 'action';
		$permissions = isset( $defaults[ $type ] ) && is_array( $defaults[ $type ] )
			? $defaults[ $type ]
			: [];
		$key         = (string) ( $permission['key'] ?? '' );

		foreach ( array_keys( $this->get_scope_options( $permission ) ) as $scope ) {
			if ( in_array( $key . '.' . $scope, $permissions, TRUE ) ) {
				return $scope;
			}
		}

		return '';
	}

	public function get_scope_options( array $permission ): array {
		$scope = isset( $permission['scope'] ) && is_array( $permission['scope'] )
			? $permission['scope']
			: [];

		return isset( $scope['options'] ) && is_array( $scope['options'] )
			? $scope['options']
			: [];
	}

	public function get_default_scope( array $permission ): string {
		$scope         = isset( $permission['scope'] ) && is_array( $permission['scope'] )
			? $permission['scope']
			: [];
		$options       = $this->get_scope_options( $permission );
		$default_scope = sanitize_key( (string) ( $scope['default'] ?? '' ) );

		if ( $default_scope !== '' && isset( $options[ $default_scope ] ) ) {
			return $default_scope;
		}

		return (string) array_key_first( $options );
	}

	public function get_permission_token(
		string $group_key,
		string $permission_id
	): string {
		$group_key     = sanitize_key( $group_key );
		$permission_id = sanitize_key( $permission_id );

		if ( $group_key === '' || $permission_id === '' ) {
			return '';
		}

		return $group_key . '--' . $permission_id;
	}

	public function resolve_employee_selection(
		array $selected_tokens,
		array $permission_scopes = [],
		array $current_permissions = []
	): array {
		$groups             = $this->get_groups();
		$selected_by_group  = [];
		$scopes_by_group    = [];
		$known              = [
			'view'   => [],
			'action' => [],
		];

		foreach ( $groups as $group_key => $group ) {
			$group_keys       = $this->get_group_permission_keys( $group );
			$known['view']    = array_merge( $known['view'], $group_keys['view'] );
			$known['action']  = array_merge( $known['action'], $group_keys['action'] );
			$selected_by_group[ $group_key ] = [];
			$scopes_by_group[ $group_key ]   = [];
		}

		foreach ( $selected_tokens as $token ) {
			if ( ! is_scalar( $token ) ) {
				continue;
			}

			$parts = explode( '--', (string) $token, 2 );

			if ( count( $parts ) !== 2 ) {
				continue;
			}

			$group_key     = sanitize_key( $parts[0] );
			$permission_id = sanitize_key( $parts[1] );

			if (
				$group_key === ''
				|| $permission_id === ''
				|| ! isset( $groups[ $group_key ] )
			) {
				continue;
			}

			$selected_by_group[ $group_key ][] = $permission_id;
		}

		foreach ( $permission_scopes as $token => $scope ) {
			if ( ! is_scalar( $token ) || ! is_scalar( $scope ) ) {
				continue;
			}

			$parts = explode( '--', (string) $token, 2 );

			if ( count( $parts ) !== 2 ) {
				continue;
			}

			$group_key     = sanitize_key( $parts[0] );
			$permission_id = sanitize_key( $parts[1] );

			if (
				$group_key === ''
				|| $permission_id === ''
				|| ! isset( $groups[ $group_key ] )
			) {
				continue;
			}

			$scopes_by_group[ $group_key ][ $permission_id ] = sanitize_key(
				(string) $scope
			);
		}

		$result = [
			'view'   => [],
			'action' => [],
		];

		foreach ( $groups as $group_key => $group ) {
			$resolved = $this->resolve_group_selection(
				$group,
				$selected_by_group[ $group_key ] ?? [],
				$scopes_by_group[ $group_key ] ?? []
			);

			$result['view'] = array_merge(
				$result['view'],
				$resolved['view']
			);
			$result['action'] = array_merge(
				$result['action'],
				$resolved['action']
			);
		}

		$current_view = $this->sanitize_permissions(
			(array) ( $current_permissions['view'] ?? [] )
		);
		$current_action = $this->sanitize_permissions(
			(array) ( $current_permissions['action'] ?? [] )
		);
		$known['view']   = array_values( array_unique( $known['view'] ) );
		$known['action'] = array_values( array_unique( $known['action'] ) );

		$result['view'] = $this->sanitize_permissions(
			array_merge(
				array_values( array_diff( $current_view, $known['view'] ) ),
				$result['view']
			)
		);
		$result['action'] = $this->sanitize_permissions(
			array_merge(
				array_values( array_diff( $current_action, $known['action'] ) ),
				$result['action']
			)
		);

		return $result;
	}

	public function split_selected( array $selected ): array {
		$known = [
			'view'   => [],
			'action' => [],
		];

		foreach ( $this->get_groups() as $group ) {
			$group_keys      = $this->get_group_permission_keys( $group );
			$known['view']   = array_merge( $known['view'], $group_keys['view'] );
			$known['action'] = array_merge( $known['action'], $group_keys['action'] );
		}

		$selected = $this->sanitize_permissions( $selected );

		return [
			'view'   => array_values( array_intersect( $selected, array_unique( $known['view'] ) ) ),
			'action' => array_values( array_intersect( $selected, array_unique( $known['action'] ) ) ),
		];
	}

	public function sanitize_permissions( array $permissions ): array {
		$clean = [];

		foreach ( $permissions as $permission ) {
			if ( ! is_scalar( $permission ) ) {
				continue;
			}

			$permission = strtolower( trim( (string) $permission ) );
			$permission = (string) preg_replace( '/[^a-z0-9_.*:\-]/', '', $permission );

			if ( $permission !== '' ) {
				$clean[] = $permission;
			}
		}

		return array_values( array_unique( $clean ) );
	}

	public function sort_by_order( array $first_item, array $second_item ): int {
		$order = (int) ( $first_item['order'] ?? 100 ) <=> (int) ( $second_item['order'] ?? 100 );

		if ( $order !== 0 ) {
			return $order;
		}

		return strcmp(
			(string) ( $first_item['label'] ?? '' ),
			(string) ( $second_item['label'] ?? '' )
		);
	}

	private function sync_with_navigation( array $groups ): array {
		$pages = KERP_App::instance()->get_registered_pages();

		foreach ( $pages as $page_key => $page ) {
			if ( ! is_array( $page ) ) {
				continue;
			}

			$navigation = isset( $page['navigation'] ) && is_array( $page['navigation'] )
				? $page['navigation']
				: [];
			$group = isset( $navigation['group'] ) && is_array( $navigation['group'] )
				? $navigation['group']
				: [];
			$group_key = sanitize_key( (string) ( $group['key'] ?? '' ) );

			if ( $group_key === '' || ! isset( $groups[ $group_key ] ) || ! is_array( $groups[ $group_key ] ) ) {
				continue;
			}

			$groups[ $group_key ]['key']   = $group_key;
			$groups[ $group_key ]['label'] = (string) ( $group['title'] ?? $groups[ $group_key ]['label'] ?? $group_key );
			$groups[ $group_key ]['icon']  = (string) ( $group['icon'] ?? $groups[ $group_key ]['icon'] ?? 'ni ni-lock-alt' );
			$groups[ $group_key ]['order'] = (int) ( $group['order'] ?? $groups[ $group_key ]['order'] ?? 100 );

			$page_key = sanitize_key( (string) $page_key );

			if (
				$page_key === '' ||
				empty( $groups[ $group_key ]['blocks'][ $page_key ] ) ||
				! is_array( $groups[ $group_key ]['blocks'][ $page_key ] )
			) {
				continue;
			}

			$groups[ $group_key ]['blocks'][ $page_key ]['label'] = (string) (
				$navigation['title']
					?? $page['title']
					?? $groups[ $group_key ]['blocks'][ $page_key ]['label']
					?? $page_key
			);
			$groups[ $group_key ]['blocks'][ $page_key ]['icon'] = (string) (
				$navigation['icon']
					?? $page['icon']
					?? $groups[ $group_key ]['blocks'][ $page_key ]['icon']
					?? 'ni ni-lock-alt'
			);
		}

		return $groups;
	}

	private function sanitize_group( string $group_key, array $group ): array {
		$group_key = sanitize_key( (string) ( $group['key'] ?? $group_key ) );
		$blocks    = isset( $group['blocks'] ) && is_array( $group['blocks'] )
			? $group['blocks']
			: [];

		if ( empty( $blocks ) && ! empty( $group['permissions'] ) && is_array( $group['permissions'] ) ) {
			$blocks[ $group_key ] = [
				'key'         => $group_key,
				'label'       => (string) ( $group['label'] ?? $group_key ),
				'icon'        => (string) ( $group['icon'] ?? 'ni ni-lock-alt' ),
				'order'       => 10,
				'permissions' => $group['permissions'],
			];
		}

		$clean_blocks = [];

		foreach ( $blocks as $block_key => $block ) {
			if ( ! is_array( $block ) ) {
				continue;
			}

			$block = $this->sanitize_block( (string) $block_key, $block );

			if ( $block['key'] !== '' && ! empty( $block['permissions'] ) ) {
				$clean_blocks[ $block['key'] ] = $block;
			}
		}

		uasort( $clean_blocks, [ $this, 'sort_by_order' ] );

		return [
			'key'         => $group_key,
			'label'       => sanitize_text_field( (string) ( $group['label'] ?? $group_key ) ),
			'icon'        => sanitize_text_field( (string) ( $group['icon'] ?? 'ni ni-lock-alt' ) ),
			'order'       => (int) ( $group['order'] ?? 100 ),
			'blocks'      => $clean_blocks,
			'permissions' => $this->flatten_permissions( $clean_blocks ),
		];
	}

	private function sanitize_block( string $block_key, array $block ): array {
		$block_key   = sanitize_key( (string) ( $block['key'] ?? $block_key ) );
		$permissions = isset( $block['permissions'] ) && is_array( $block['permissions'] )
			? $block['permissions']
			: [];
		$clean       = [];

		foreach ( $permissions as $permission_id => $permission ) {
			if ( ! is_array( $permission ) ) {
				continue;
			}

			$permission = $this->sanitize_permission( (string) $permission_id, $permission );

			if ( $permission['id'] !== '' && $permission['key'] !== '' ) {
				$clean[ $permission['id'] ] = $permission;
			}
		}

		uasort( $clean, [ $this, 'sort_by_order' ] );

		return [
			'key'         => $block_key,
			'label'       => sanitize_text_field( (string) ( $block['label'] ?? $block_key ) ),
			'icon'        => sanitize_text_field( (string) ( $block['icon'] ?? 'ni ni-lock-alt' ) ),
			'order'       => (int) ( $block['order'] ?? 100 ),
			'description' => sanitize_text_field( (string) ( $block['description'] ?? '' ) ),
			'permissions' => $clean,
		];
	}

	private function sanitize_permission( string $permission_id, array $permission ): array {
		$permission_id  = sanitize_key( (string) ( $permission['id'] ?? $permission_id ) );
		$permission_key = strtolower( trim( (string) ( $permission['key'] ?? '' ) ) );
		$permission_key = (string) preg_replace( '/[^a-z0-9_.*:\-]/', '', $permission_key );
		$type           = sanitize_key( (string) ( $permission['type'] ?? 'action' ) );

		return [
			'id'          => $permission_id,
			'key'         => $permission_key,
			'label'       => sanitize_text_field( (string) ( $permission['label'] ?? $permission_key ) ),
			'description' => sanitize_text_field( (string) ( $permission['description'] ?? '' ) ),
			'type'        => $type === 'view' ? 'view' : 'action',
			'order'       => (int) ( $permission['order'] ?? 100 ),
			'scope'       => $this->sanitize_scope( $permission['scope'] ?? [] ),
		];
	}

	private function sanitize_scope( mixed $scope ): array {
		if ( ! is_array( $scope ) || empty( $scope ) ) {
			return [];
		}

		if ( isset( $scope['options'] ) && is_array( $scope['options'] ) ) {
			$options = $scope['options'];
			$default = sanitize_key( (string) ( $scope['default'] ?? '' ) );
		} else {
			$options = $scope;
			$default = '';
		}

		$clean = [];

		foreach ( $options as $scope_key => $scope_label ) {
			$scope_key = sanitize_key( (string) $scope_key );

			if ( $scope_key === '' || ! is_scalar( $scope_label ) ) {
				continue;
			}

			$clean[ $scope_key ] = sanitize_text_field( (string) $scope_label );
		}

		if ( empty( $clean ) ) {
			return [];
		}

		if ( $default === '' || ! isset( $clean[ $default ] ) ) {
			$default = (string) array_key_first( $clean );
		}

		return [
			'options' => $clean,
			'default' => $default,
		];
	}

	private function has_scope( array $permission ): bool {
		return ! empty( $this->get_scope_options( $permission ) );
	}

	private function flatten_permissions( array $blocks ): array {
		$permissions = [];

		foreach ( $blocks as $block ) {
			foreach ( (array) ( $block['permissions'] ?? [] ) as $permission_id => $permission ) {
				$permissions[ $permission_id ] = $permission;
			}
		}

		return $permissions;
	}

	private function get_group_permission_keys( array $group ): array {
		$keys = [
			'view'   => [],
			'action' => [],
		];

		foreach ( (array) ( $group['blocks'] ?? [] ) as $block ) {
			foreach ( (array) ( $block['permissions'] ?? [] ) as $permission ) {
				$type = (string) ( $permission['type'] ?? 'action' ) === 'view' ? 'view' : 'action';
				$key  = (string) ( $permission['key'] ?? '' );

				if ( $key === '' ) {
					continue;
				}

				if ( $this->has_scope( $permission ) ) {
					$keys[ $type ][] = $key;

					foreach ( array_keys( $this->get_scope_options( $permission ) ) as $scope ) {
						$keys[ $type ][] = $key . '.' . $scope;
					}
				} else {
					$keys[ $type ][] = $key;
				}
			}
		}

		$keys['view']   = array_values( array_unique( $keys['view'] ) );
		$keys['action'] = array_values( array_unique( $keys['action'] ) );

		return $keys;
	}

	private function resolve_group_selection(
		array $group,
		array $selected_permission_ids,
		array $permission_scopes
	): array {
		$permissions = isset( $group['permissions'] ) && is_array( $group['permissions'] )
			? $group['permissions']
			: [];
		$selected_ids = [];

		foreach ( $selected_permission_ids as $permission_id ) {
			if ( ! is_scalar( $permission_id ) ) {
				continue;
			}

			$permission_id = sanitize_key( (string) $permission_id );

			if ( $permission_id !== '' ) {
				$selected_ids[] = $permission_id;
			}
		}

		$selected_ids = array_values( array_unique( $selected_ids ) );
		$result       = [
			'view'   => [],
			'action' => [],
		];

		foreach ( $selected_ids as $permission_id ) {
			if ( ! isset( $permissions[ $permission_id ] ) || ! is_array( $permissions[ $permission_id ] ) ) {
				continue;
			}

			$permission = $permissions[ $permission_id ];
			$type       = (string) ( $permission['type'] ?? 'action' ) === 'view' ? 'view' : 'action';
			$key        = (string) ( $permission['key'] ?? '' );

			if ( $key === '' ) {
				continue;
			}

			if ( $this->has_scope( $permission ) ) {
				$scope = isset( $permission_scopes[ $permission_id ] ) && is_scalar( $permission_scopes[ $permission_id ] )
					? sanitize_key( (string) $permission_scopes[ $permission_id ] )
					: '';
				$options = $this->get_scope_options( $permission );

				if ( $scope === '' || ! isset( $options[ $scope ] ) ) {
					$scope = $this->get_default_scope( $permission );
				}

				if ( $scope !== '' ) {
					$result[ $type ][] = $key . '.' . $scope;
				}
			} else {
				$result[ $type ][] = $key;
			}
		}

		$result['view']   = $this->sanitize_permissions( $result['view'] );
		$result['action'] = $this->sanitize_permissions( $result['action'] );

		return $result;
	}

	private function get_hook_defaults( string $requested_role ): array {
		$defaults = apply_filters(
			'kerp_employee_default_permissions',
			[],
			$requested_role
		);

		return is_array( $defaults ) ? $defaults : [];
	}

	private function update_defaults_option( array $defaults, string $role_key ): bool|WP_Error {
		$updated = update_option( self::ROLE_DEFAULTS_OPTION, $defaults, FALSE );

		if ( ! $updated && get_option( self::ROLE_DEFAULTS_OPTION, [] ) !== $defaults ) {
			return new WP_Error(
				'kerp_employee_role_permissions_save_failed',
				__( 'ذخیره دسترسی‌های پیش‌فرض نقش انجام نشد.', 'kasebi-erp' )
			);
		}

		do_action(
			'kerp_employee_role_default_permissions_updated',
			$role_key,
			$defaults[ $role_key ]
		);

		return TRUE;
	}
}
