<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Employees_Settings {
	
	public const OPTION_NAME = 'kerp_employees_settings';
	
	private static ?self $instance = NULL;
	private ?array       $settings = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public function defaults(): array {
		return [
			'singular_label'       => __( 'کارمند', 'kasebi-erp' ),
			'plural_label'         => __( 'کارمندان', 'kasebi-erp' ),
			'phone_meta_key'       => 'nooshika_phone_num',
			'employee_code_prefix' => 'EMP-',
			'auto_employee_code'   => TRUE,
			'default_status'       => 'active',
			'default_role_key'     => 'employee',
			'default_per_page'     => 20,
		];
	}
	
	public function all(): array {
		if ( $this->settings === NULL ) {
			$stored         = get_option( self::OPTION_NAME, [] );
			$this->settings = wp_parse_args( is_array( $stored ) ? $stored : [], $this->defaults() );
		}
		
		return apply_filters( 'kerp_employees_settings', $this->settings );
	}
	
	public function get( string $key, mixed $default = NULL ): mixed {
		$all = $this->all();
		
		return $all[ $key ] ?? $default;
	}
	
	public function get_singular_label(): string {
		return sanitize_text_field( (string) $this->get( 'singular_label', __( 'کارمند', 'kasebi-erp' ) ) );
	}
	
	public function get_plural_label(): string {
		return sanitize_text_field( (string) $this->get( 'plural_label', __( 'کارمندان', 'kasebi-erp' ) ) );
	}
	
	public function save( array $data ): bool {
		$stored  = get_option( self::OPTION_NAME, [] );
		$current = wp_parse_args(
			is_array( $stored ) ? $stored : [],
			$this->defaults()
		);
		
		$role_options   = KERP_Modules_Employees_Roles::instance()->get_options();
		$status_options = KERP_Modules_Employees_Fields::instance()->statuses();
		
		$default_role_key = sanitize_key(
			(string) ( $data['default_role_key'] ?? $current['default_role_key'] )
		);
		
		if ( ! isset( $role_options[ $default_role_key ] ) ) {
			$default_role_key = (string) array_key_first( $role_options );
		}
		
		$default_status = sanitize_key(
			(string) ( $data['default_status'] ?? $current['default_status'] )
		);
		
		if ( ! isset( $status_options[ $default_status ] ) ) {
			$default_status = 'active';
		}
		
		$clean = [
			'singular_label'       => sanitize_text_field(
				(string) ( $data['singular_label'] ?? $current['singular_label'] )
			),
			'plural_label'         => sanitize_text_field(
				(string) ( $data['plural_label'] ?? $current['plural_label'] )
			),
			'phone_meta_key'       => sanitize_key(
				(string) ( $current['phone_meta_key'] ?? 'nooshika_phone_num' )
			),
			'employee_code_prefix' => sanitize_text_field(
				(string) ( $data['employee_code_prefix'] ?? $current['employee_code_prefix'] )
			),
			'auto_employee_code'   => ! empty( $data['auto_employee_code'] ),
			'default_status'       => $default_status,
			'default_role_key'     => $default_role_key,
			'default_per_page'     => max(
				1,
				min(
					100,
					absint( $data['default_per_page'] ?? $current['default_per_page'] )
				)
			),
		];
		
		if ( $clean['singular_label'] === '' ) {
			$clean['singular_label'] = __( 'کارمند', 'kasebi-erp' );
		}
		
		if ( $clean['plural_label'] === '' ) {
			$clean['plural_label'] = __( 'کارمندان', 'kasebi-erp' );
		}
		
		$clean = apply_filters(
			'kerp_employees_settings_before_save',
			$clean,
			$data,
			$current
		);
		
		$this->settings = $clean;
		
		return update_option(
			self::OPTION_NAME,
			$clean,
			FALSE
		);
	}
	
}
