<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Employees_Candidates {

	private static ?self $instance = NULL;

	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	private function __construct() {}

	private function __clone() {}

	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}

	public function find( array $args = [] ): array {
		global $wpdb;

		$defaults = [
			'per_page'    => 12,
			'page_number' => 1,
			'search'      => '',
			'wp_role'     => '',
			'orderby'     => 'display_name',
			'order'       => 'ASC',
			'count_only'  => FALSE,
		];

		$args        = wp_parse_args( $args, $defaults );
		$args        = apply_filters( 'kerp_employees_candidate_query_args', $args );
		$per_page    = max( 1, min( 50, absint( $args['per_page'] ) ) );
		$page_number = max( 1, absint( $args['page_number'] ) );
		$search      = sanitize_text_field( (string) $args['search'] );
		$wp_role     = sanitize_key( (string) $args['wp_role'] );
		$args['search'] = $search;
		$args['wp_role'] = $wp_role;
		$access      = KERP_Services_Access::table();
		$cap_key     = $wpdb->get_blog_prefix() . 'capabilities';
		$where       = [
			"NOT EXISTS (
				SELECT 1
				FROM {$access} AS assigned_employee
				WHERE assigned_employee.user_id = users.ID
					AND assigned_employee.role_key IS NOT NULL
					AND assigned_employee.role_key <> ''
			)",
		];
		$params      = [];

		$excluded_roles = $this->get_excluded_wp_roles();

		if ( ! empty( $excluded_roles ) ) {
			$role_conditions = [];

			foreach ( $excluded_roles as $role_key ) {
				$role_conditions[] = 'excluded_capabilities.meta_value LIKE %s';
			}

			$where[] = "NOT EXISTS (
				SELECT 1
				FROM {$wpdb->usermeta} AS excluded_capabilities
				WHERE excluded_capabilities.user_id = users.ID
					AND excluded_capabilities.meta_key = %s
					AND (" . implode( ' OR ', $role_conditions ) . ")
			)";
			$params[] = $cap_key;

			foreach ( $excluded_roles as $role_key ) {
				$params[] = '%' . $wpdb->esc_like( '"' . $role_key . '";b:1' ) . '%';
			}
		}

		$excluded_ids = $this->get_super_admin_ids();

		if ( ! empty( $excluded_ids ) ) {
			$placeholders = implode( ', ', array_fill( 0, count( $excluded_ids ), '%d' ) );
			$where[]      = "users.ID NOT IN ({$placeholders})";
			$params       = array_merge( $params, $excluded_ids );
		}

		if ( $wp_role !== '' ) {
			if ( ! isset( $this->get_role_options()[ $wp_role ] ) ) {
				$where[] = '1 = 0';
			} else {
				$where[] = "EXISTS (
					SELECT 1 FROM {$wpdb->usermeta} AS selected_capabilities
					WHERE selected_capabilities.user_id = users.ID
					AND selected_capabilities.meta_key = %s
					AND selected_capabilities.meta_value LIKE %s
				)";
				$params[] = $cap_key;
				$params[] = '%' . $wpdb->esc_like( '"' . $wp_role . '";b:1' ) . '%';
			}
		}

		if ( $search !== '' ) {
            // Match only first/last names; separate words may match either field.
            $name_parts = preg_split( '/\s+/u', trim( $search ), -1, PREG_SPLIT_NO_EMPTY );
            foreach ( $name_parts ?: [] as $name_part ) {
                $where[] = "EXISTS (
                    SELECT 1 FROM {$wpdb->usermeta} AS candidate_name
                    WHERE candidate_name.user_id = users.ID
                        AND candidate_name.meta_key IN ('first_name', 'last_name')
                        AND candidate_name.meta_value LIKE %s
                )";
                $params[] = '%' . $wpdb->esc_like( $name_part ) . '%';
            }
        }

		$where_sql = implode( ' AND ', $where );

		$count_sql = "
			SELECT COUNT(*)
			FROM {$wpdb->users} AS users
			WHERE {$where_sql}
		";

		$prepared_count_sql = empty( $params )
			? $count_sql
			: $wpdb->prepare( $count_sql, ...$params );
		$total              = (int) $wpdb->get_var( $prepared_count_sql );

		$page_number = min( $page_number, max( 1, (int) ceil( $total / $per_page ) ) );
		$args['page_number'] = $page_number;
		$offset = ( $page_number - 1 ) * $per_page;

		if ( ! empty( $args['count_only'] ) ) {
			$result = [
				'items'        => [],
				'total'        => $total,
				'per_page'     => $per_page,
				'page_number'  => $page_number,
				'total_pages'  => $per_page > 0 ? (int) ceil( $total / $per_page ) : 0,
				'request_args' => $args,
			];

			return apply_filters( 'kerp_employees_candidate_query_results', $result, $args );
		}

		$allowed_orderby = [
			'display_name' => 'users.display_name',
			'registered'   => 'users.user_registered',
			'id'           => 'users.ID',
		];
		$orderby = $allowed_orderby[ sanitize_key( (string) $args['orderby'] ) ]
			?? 'users.display_name';
		$order = strtoupper( (string) $args['order'] ) === 'DESC'
			? 'DESC'
			: 'ASC';

		$list_sql = "
			SELECT users.ID
			FROM {$wpdb->users} AS users
			WHERE {$where_sql}
			ORDER BY {$orderby} {$order}
			LIMIT %d OFFSET %d
		";
		$list_params = array_merge( $params, [ $per_page, $offset ] );
		$user_ids    = $wpdb->get_col(
			$wpdb->prepare(
				$list_sql,
				...$list_params
			)
		);
		$items = [];

		foreach ( $user_ids as $user_id ) {
			$user = get_userdata( (int) $user_id );

			if ( $user instanceof WP_User && $this->is_assignable( $user ) ) {
				$items[] = $user;
			}
		}

		$result = [
			'items'        => $items,
			'total'        => $total,
			'per_page'     => $per_page,
			'page_number'  => $page_number,
			'total_pages'  => $per_page > 0 ? (int) ceil( $total / $per_page ) : 0,
			'request_args' => $args,
		];

		return apply_filters( 'kerp_employees_candidate_query_results', $result, $args );
	}

	public function get_role_options(): array {
		$options = [];
		$excluded = $this->get_excluded_wp_roles();
		foreach ( wp_roles()->roles as $key => $role ) {
			if ( ! in_array( $key, $excluded, TRUE ) ) {
				$options[ $key ] = translate_user_role( (string) $role['name'] );
			}
		}
		return $options;
	}

	public function get_count(): int {
		$result = $this->find(
			[
				'per_page'    => 1,
				'page_number' => 1,
				'count_only'  => TRUE,
			]
		);

		return (int) $result['total'];
	}

	public function is_assignable( WP_User|int $user ): bool {
		$user = is_int( $user ) ? get_userdata( $user ) : $user;

		if ( ! $user instanceof WP_User ) {
			return FALSE;
		}

		if ( $this->is_general_manager( $user ) ) {
			return FALSE;
		}

		if ( $this->is_customer( $user ) ) {
			return FALSE;
		}

		if ( $this->is_employee( (int) $user->ID ) ) {
			return FALSE;
		}

		return (bool) apply_filters(
			'kerp_employee_user_is_assignable',
			TRUE,
			$user
		);
	}

	public function is_employee( int $user_id ): bool {
		$record = KERP_Services_Access::get_record( $user_id );

		return is_array( $record )
			&& sanitize_key( (string) ( $record['role_key'] ?? '' ) ) !== '';
	}

	public function is_customer( WP_User|int $user ): bool {
		$user = is_int( $user ) ? get_userdata( $user ) : $user;

		if ( ! $user instanceof WP_User ) {
			return FALSE;
		}

		$customer_roles = $this->get_customer_roles();
		$user_roles     = array_values( array_map( 'sanitize_key', (array) $user->roles ) );
		$is_customer    = ! empty( array_intersect( $customer_roles, $user_roles ) );

		return (bool) apply_filters(
			'kerp_employee_candidate_is_customer',
			$is_customer,
			$user,
			$customer_roles
		);
	}

	public function is_general_manager( WP_User|int $user ): bool {
		$user = is_int( $user ) ? get_userdata( $user ) : $user;

		if ( ! $user instanceof WP_User ) {
			return FALSE;
		}

		$is_manager = is_super_admin( (int) $user->ID )
			|| user_can( $user, 'manage_options' );

		return (bool) apply_filters(
			'kerp_employee_candidate_is_general_manager',
			$is_manager,
			$user
		);
	}

	public function get_customer_roles(): array {
		$roles = class_exists( 'KERP_Modules_Customers_Settings' )
			? (array) KERP_Modules_Customers_Settings::instance()->get(
				'customer_roles',
				[ 'customer', 'subscriber' ]
			)
			: [ 'customer', 'subscriber' ];

		$roles = array_values(
			array_unique(
				array_filter(
					array_map(
						'sanitize_key',
						$roles
					)
				)
			)
		);

		return (array) apply_filters( 'kerp_employee_candidate_customer_roles', $roles );
	}

	public function get_excluded_wp_roles(): array {
		$excluded = $this->get_customer_roles();
		$wp_roles = wp_roles();

		if ( $wp_roles instanceof WP_Roles ) {
			foreach ( $wp_roles->roles as $role_key => $role_data ) {
				$capabilities = isset( $role_data['capabilities'] ) && is_array( $role_data['capabilities'] )
					? $role_data['capabilities']
					: [];

				if ( ! empty( $capabilities['manage_options'] ) ) {
					$excluded[] = sanitize_key( (string) $role_key );
				}
			}
		}

		$excluded = array_values(
			array_unique(
				array_filter(
					array_map(
						'sanitize_key',
						$excluded
					)
				)
			)
		);

		return (array) apply_filters( 'kerp_employee_candidate_excluded_wp_roles', $excluded );
	}

	public function get_phone_meta_key(): string {
		if ( class_exists( 'KERP_Modules_Customers_Settings' ) ) {
			$meta_key = sanitize_key(
				(string) KERP_Modules_Customers_Settings::instance()->get(
					'phone_meta_key',
					'nooshika_phone_num'
				)
			);

			if ( $meta_key !== '' ) {
				return $meta_key;
			}
		}

		return sanitize_key(
			(string) KERP_Modules_Employees_Settings::instance()->get(
				'phone_meta_key',
				'nooshika_phone_num'
			)
		);
	}

	private function get_super_admin_ids(): array {
		if ( ! is_multisite() ) {
			return [];
		}

		$user_ids = [];

		foreach ( get_super_admins() as $user_login ) {
			$user = get_user_by( 'login', $user_login );

			if ( $user instanceof WP_User ) {
				$user_ids[] = (int) $user->ID;
			}
		}

		return array_values( array_unique( array_filter( $user_ids ) ) );
	}
}
