<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Employees_Profile {
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public function get_context(
		int $employee_id,
		string $requested_tab = ''
	): array {
		$employee = KERP_Modules_Employees_Query::instance()->get_employee(
			$employee_id
		);
		
		if ( ! $employee instanceof WP_User ) {
			return [
				'employee'    => NULL,
				'employee_id' => 0,
				'tabs'        => [],
				'active_tab'  => '',
				'main_fields' => [],
				'fields'      => [],
			];
		}
		
		$tabs       = $this->get_tabs( $employee );
		$active_tab = $this->resolve_active_tab(
			$requested_tab,
			$tabs
		);
		
		return apply_filters(
			'kerp_employee_profile_context',
			[
				'employee'    => $employee,
				'employee_id' => (int) $employee->ID,
				'tabs'        => $tabs,
				'active_tab'  => $active_tab,
				'main_fields' => KERP_Modules_Employees_Fields::instance()
				                                              ->get_main_profile_view_fields( (int) $employee->ID ),
				'fields'      => KERP_Modules_Employees_Fields::instance()
				                                              ->get_custom_profile_view_fields( (int) $employee->ID ),
			],
			$employee
		);
	}
	
	public function get_tabs( WP_User|int $employee ): array {
		$employee = is_int( $employee )
			? get_userdata( $employee )
			: $employee;
		
		if ( ! $employee instanceof WP_User ) {
			return [];
		}
		
		$tabs = [
			'profile' => [
				'key'        => 'profile',
				'title'      => __( 'پروفایل', 'kasebi-erp' ),
				'icon'       => 'ni ni-user',
				'order'      => 10,
				'permission' => 'employees.view',
				'action'     => 'view',
				'template'   => 'modules/employees/tabs/profile.php',
			],
			'access'  => [
				'key'        => 'access',
				'title'      => __( 'دسترسی‌ها', 'kasebi-erp' ),
				'icon'       => 'ni ni-lock-alt',
				'order'      => 200,
				'permission' => 'employees.access.manage',
				'action'     => 'action',
				'template'   => 'modules/employees/tabs/access.php',
			],
		];
		
		$tabs = apply_filters(
			'kerp_employee_profile_tabs',
			$tabs,
			(int) $employee->ID,
			$employee
		);
		
		$tabs = is_array( $tabs ) ? $tabs : [];
		
		$tabs = array_filter(
			$tabs,
			[ $this, 'can_view_tab' ]
		);
		
		uasort( $tabs, [ $this, 'sort_tabs' ] );
		
		return $tabs;
	}
	
	public function render_tab(
		string $tab_key,
		int $employee_id,
		array $context = []
	): void {
		$employee = KERP_Modules_Employees_Query::instance()->get_employee(
			$employee_id
		);
		
		if ( ! $employee instanceof WP_User ) {
			return;
		}
		
		$tabs = $this->get_tabs( $employee );
		$tab  = $tabs[ sanitize_key( $tab_key ) ] ?? NULL;
		
		if ( ! is_array( $tab ) ) {
			return;
		}
		
		$args = array_merge(
			$context,
			[
				'employee'    => $employee,
				'employee_id' => (int) $employee->ID,
				'tab'         => $tab,
			]
		);
		
		if ( ! empty( $tab['callback'] ) && is_callable( $tab['callback'] ) ) {
			call_user_func( $tab['callback'], $args );
			
			return;
		}
		
		if ( ! empty( $tab['template'] ) ) {
			KERP_Helpers_Template::render_template(
				(string) $tab['template'],
				$args
			);
			
			return;
		}
		
		do_action(
			'kerp_employee_profile_tab_' . sanitize_key(
				(string) ( $tab['key'] ?? $tab_key )
			),
			(int) $employee->ID,
			$employee,
			$tab,
			$args
		);
	}
	
	public function can_view_tab( mixed $tab ): bool {
		if ( ! is_array( $tab ) ) {
			return FALSE;
		}
		
		$permission = trim( (string) ( $tab['permission'] ?? '' ) );
		$action     = (string) ( $tab['action'] ?? 'view' );
		
		if ( $permission === '' ) {
			return TRUE;
		}
		
		return kerp_can(
			$permission,
			$action === 'view' ? 'view' : 'action'
		);
	}
	
	public function sort_tabs( array $first, array $second ): int {
		return (int) ( $first['order'] ?? 100 )
		       <=> (int) ( $second['order'] ?? 100 );
	}
	
	private function resolve_active_tab(
		string $requested_tab,
		array $tabs
	): string {
		$requested_tab = sanitize_key( $requested_tab );
		
		if ( $requested_tab !== '' && isset( $tabs[ $requested_tab ] ) ) {
			return $requested_tab;
		}
		
		return (string) ( array_key_first( $tabs ) ?? '' );
	}
	
}
