<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Employees_Fields {

	public const OPTION_NAME = 'kerp_employees_custom_fields';

	private static ?self $instance = NULL;

	private ?array $fields = NULL;

	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	private function __construct() {
		add_action(
			'update_option_' . self::OPTION_NAME,
			[ $this, 'clear_cache' ],
			10,
			0
		);
		add_action(
			'add_option_' . self::OPTION_NAME,
			[ $this, 'clear_cache' ],
			10,
			0
		);
	}

	private function __clone() {}

	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}

	public function get_all( bool $active_only = FALSE ): array {
		if ( $this->fields === NULL ) {
			$stored       = get_option( self::OPTION_NAME, [] );
			$this->fields = is_array( $stored ) ? $stored : [];
		}

		$fields = $this->fields;

		if ( $active_only ) {
			$fields = array_filter(
				$fields,
				[ $this, 'is_field_active' ]
			);
		}

		$fields = apply_filters(
			'kerp_employees_custom_fields',
			$fields,
			$active_only
		);

		$fields = is_array( $fields ) ? $fields : [];

		$this->sort( $fields );

		return $fields;
	}

	public function get( string $field_key ): ?array {
		$field_key = sanitize_key( $field_key );
		$fields    = $this->get_all();

		return isset( $fields[ $field_key ] ) && is_array( $fields[ $field_key ] )
			? $fields[ $field_key ]
			: NULL;
	}

	public function save( array $fields ): bool {
		$clean = [];

		foreach ( $fields as $field_key => $field ) {
			if ( ! is_array( $field ) ) {
				continue;
			}

			$field['key'] = $field['key'] ?? $field_key;
			$field        = $this->sanitize_definition( $field );

			if ( $field['key'] === '' ) {
				continue;
			}

			$clean[ $field['key'] ] = $field;
		}

		$this->sort( $clean );

		$updated      = update_option( self::OPTION_NAME, $clean, FALSE );
		$this->fields = $clean;

		do_action( 'kerp_employees_custom_fields_saved', $clean );

		return $updated || get_option( self::OPTION_NAME, [] ) === $clean;
	}

	public function upsert( array $field ): bool {
		$field = $this->sanitize_definition( $field );

		if ( $field['key'] === '' ) {
			return FALSE;
		}

		$fields                  = $this->get_all();
		$fields[ $field['key'] ] = $field;

		return $this->save( $fields );
	}

	public function delete( string $field_key ): bool {
		$field_key = sanitize_key( $field_key );
		$fields    = $this->get_all();

		if ( ! isset( $fields[ $field_key ] ) ) {
			return TRUE;
		}

		unset( $fields[ $field_key ] );

		return $this->save( $fields );
	}

	public function get_create_fields(): array {
		$fields = $this->get_main_fields( 0, FALSE );

		foreach ( $this->get_all( TRUE ) as $field_key => $definition ) {
			if ( empty( $definition['show_on_create'] ) ) {
				continue;
			}

			$fields[ $field_key ] = $this->to_form_field( $definition );
		}

		$fields = apply_filters( 'kerp_employees_create_fields', $fields );
		$fields = is_array( $fields ) ? $fields : [];

		$this->sort( $fields );

		return $fields;
	}

	public function get_main_profile_fields( WP_User|int $employee ): array {
		$employee = is_int( $employee )
			? get_userdata( $employee )
			: $employee;

		if ( ! $employee instanceof WP_User ) {
			return [];
		}

		return $this->get_main_fields( (int) $employee->ID, TRUE );
	}

	public function get_profile_fields( int $employee_id = 0 ): array {
		$fields = [];

		foreach ( $this->get_all( TRUE ) as $field_key => $definition ) {
			if ( empty( $definition['show_on_profile'] ) ) {
				continue;
			}

			$field          = $this->to_form_field( $definition );
			$field['value'] = $employee_id > 0
				? get_user_meta(
					$employee_id,
					(string) $definition['meta_key'],
					TRUE
				)
				: '';

			$fields[ $field_key ] = $field;
		}

		$fields = apply_filters(
			'kerp_employee_profile_fields',
			$fields,
			$employee_id
		);

		$fields = is_array( $fields ) ? $fields : [];

		$this->sort( $fields );

		return $fields;
	}

	public function get_edit_profile_fields( int $employee_id ): array {
		$fields = $this->get_main_profile_fields( $employee_id );

		foreach ( $this->get_all( TRUE ) as $field_key => $definition ) {
			if ( ! is_array( $definition ) ) {
				continue;
			}

			$field_key = sanitize_key(
				(string) ( $definition['key'] ?? $field_key )
			);

			if ( $field_key === '' || isset( $fields[ $field_key ] ) ) {
				continue;
			}

			$field          = $this->to_form_field( $definition );
			$field['value'] = get_user_meta(
				$employee_id,
				(string) ( $definition['meta_key'] ?? $field_key ),
				TRUE
			);

			$fields[ $field_key ] = $field;
		}

		$fields = apply_filters(
			'kerp_employee_edit_profile_fields',
			$fields,
			$employee_id
		);

		$fields = is_array( $fields ) ? $fields : [];

		$normalized = [];

		foreach ( $fields as $field_key => $field ) {
			if ( ! is_array( $field ) ) {
				continue;
			}

			$field_key = sanitize_key(
				(string) ( $field['key'] ?? $field_key )
			);

			if ( $field_key === '' ) {
				continue;
			}

			$field['key']  = $field_key;
			$field['name'] = 'meta[' . $field_key . ']';
			$field['id']   = $field['id']
				?? 'kerp-employee-profile-meta-' . $field_key;

			$normalized[ $field_key ] = $field;
		}

		$this->sort( $normalized );

		return $normalized;
	}

	public function get_main_profile_view_fields( int $employee_id ): array {
		$fields = $this->get_main_profile_fields( $employee_id );

		return $this->prepare_view_fields(
			$fields,
			'kerp_employee_main_profile_view_fields',
			$employee_id
		);
	}

	public function get_custom_profile_view_fields( int $employee_id ): array {
		$fields = $this->get_profile_fields( $employee_id );

		return $this->prepare_view_fields(
			$fields,
			'kerp_employee_custom_profile_view_fields',
			$employee_id
		);
	}

	public function sanitize_value( mixed $value, array $field ): mixed {
		$type = sanitize_key( (string) ( $field['type'] ?? 'text' ) );

		if ( is_array( $value ) ) {
			$values = [];

			foreach ( $value as $item ) {
				$values[] = $this->sanitize_value( $item, $field );
			}

			return array_values( $values );
		}

		$value = wp_unslash( (string) $value );

		return match ( $type ) {
			'email' => sanitize_email( $value ),
			'url' => esc_url_raw( $value ),
			'number', 'price' => $this->sanitize_number( $value ),
			'textarea', 'quill' => wp_kses_post( $value ),
			'select', 'radio', 'switch' => sanitize_key( $value ),
			'checkbox', 'multi-select' => sanitize_text_field( $value ),
			default => sanitize_text_field( $value ),
		};
	}

	public function format_display_value( mixed $value, array $field ): string {
		$type    = sanitize_key( (string) ( $field['type'] ?? 'text' ) );
		$options = isset( $field['options'] ) && is_array( $field['options'] )
			? $field['options']
			: [];

		if ( is_array( $value ) ) {
			$values = [];

			foreach ( $value as $item ) {
				$item_key = (string) $item;
				$values[] = (string) ( $options[ $item_key ] ?? $item_key );
			}

			$value = implode(
				'، ',
				array_filter(
					array_map(
						'trim',
						$values
					)
				)
			);
		} elseif (
			in_array(
				$type,
				[ 'select', 'radio', 'checkbox', 'multi-select' ],
				TRUE
			)
		) {
			$value_key = (string) $value;
			$value     = (string) ( $options[ $value_key ] ?? $value_key );
		} elseif ( $type === 'date' && $value !== '' ) {
			$timestamp = is_numeric( $value )
				? (int) $value
				: strtotime( (string) $value );

			if ( $timestamp ) {
				$value = date_i18n( 'Y/m/d', $timestamp );
			}
		} elseif ( $type === 'switch' ) {
			$value = ! empty( $value )
				? __( 'بله', 'kasebi-erp' )
				: __( 'خیر', 'kasebi-erp' );
		}

		$value = trim(
			wp_strip_all_tags(
				(string) $value
			)
		);

		return $value !== '' || $value === '0'
			? $value
			: '-';
	}

	public function statuses(): array {
		return (array) apply_filters(
			'kerp_employee_statuses',
			[
				'active'     => __( 'فعال', 'kasebi-erp' ),
				'inactive'   => __( 'غیرفعال', 'kasebi-erp' ),
				'suspended'  => __( 'تعلیق‌شده', 'kasebi-erp' ),
				'terminated' => __( 'قطع همکاری', 'kasebi-erp' ),
				'pending'    => __( 'در انتظار شروع', 'kasebi-erp' ),
			]
		);
	}

	public function employment_types(): array {
		return (array) apply_filters(
			'kerp_employee_employment_types',
			[
				'full_time' => __( 'تمام‌وقت', 'kasebi-erp' ),
				'part_time' => __( 'پاره‌وقت', 'kasebi-erp' ),
				'contract'  => __( 'قراردادی', 'kasebi-erp' ),
				'consultant'=> __( 'مشاور', 'kasebi-erp' ),
				'intern'    => __( 'کارآموز', 'kasebi-erp' ),
			]
		);
	}

	public function is_field_active( mixed $field ): bool {
		return is_array( $field )
			&& ( ! isset( $field['active'] ) || ! empty( $field['active'] ) );
	}

	public function sort_items( array $first, array $second ): int {
		return (int) ( $first['order'] ?? 100 )
			<=> (int) ( $second['order'] ?? 100 );
	}

	public function clear_cache(): void {
		$this->fields = NULL;
	}

	private function get_main_fields( int $employee_id, bool $profile ): array {
		$employee = $employee_id > 0
			? get_userdata( $employee_id )
			: NULL;
		$settings = KERP_Modules_Employees_Settings::instance();
		$roles    = KERP_Modules_Employees_Roles::instance();
		$access   = $employee_id > 0
			? KERP_Services_Access::get_record( $employee_id )
			: NULL;
		$role_key = sanitize_key(
			(string) (
				$access['role_key']
				?? $settings->get( 'default_role_key', 'employee' )
			)
		);
		$role_options = $roles->get_options();

		if ( $role_key !== '' && ! isset( $role_options[ $role_key ] ) ) {
			$current_role = $roles->get( $role_key );

			if ( is_array( $current_role ) ) {
				$role_options[ $role_key ] = (string) (
					$current_role['label']
					?? $role_key
				);
			}
		}

		$phone_meta_key = sanitize_key(
			(string) $settings->get(
				'phone_meta_key',
				'nooshika_phone_num'
			)
		);

		$phone = $employee_id > 0
			? sanitize_text_field(
				(string) get_user_meta(
					$employee_id,
					$phone_meta_key,
					TRUE
				)
			)
			: '';

		if ( $phone === '' && $employee_id > 0 ) {
			$phone = sanitize_text_field(
				(string) get_user_meta(
					$employee_id,
					'billing_phone',
					TRUE
				)
			);
		}

		$meta_value = function( string $meta_key ) use ( $employee_id ): string {
			return $employee_id > 0
				? (string) get_user_meta( $employee_id, $meta_key, TRUE )
				: '';
		};

		$fields = [
			'first_name' => [
				'id'       => 'kerp-employee-profile-first-name',
				'name'     => 'first_name',
				'key'      => 'first_name',
				'label'    => __( 'نام', 'kasebi-erp' ),
				'type'     => 'text',
				'class'    => 'col-md-6',
				'value'    => $employee instanceof WP_User ? $employee->first_name : '',
				'required' => TRUE,
				'order'    => 10,
			],
			'last_name' => [
				'id'       => 'kerp-employee-profile-last-name',
				'name'     => 'last_name',
				'key'      => 'last_name',
				'label'    => __( 'نام خانوادگی', 'kasebi-erp' ),
				'type'     => 'text',
				'class'    => 'col-md-6',
				'value'    => $employee instanceof WP_User ? $employee->last_name : '',
				'required' => TRUE,
				'order'    => 20,
			],
			'phone' => [
				'id'       => 'kerp-employee-profile-phone',
				'name'     => 'phone',
				'key'      => 'phone',
				'label'    => __( 'شماره موبایل', 'kasebi-erp' ),
				'type'     => 'text',
				'class'    => 'col-md-6',
				'value'    => $phone,
				'required' => TRUE,
				'order'    => 30,
			],
			'email' => [
				'id'    => 'kerp-employee-profile-email',
				'name'  => 'email',
				'key'   => 'email',
				'label' => __( 'ایمیل', 'kasebi-erp' ),
				'type'  => 'email',
				'class' => 'col-md-6',
				'value' => $employee instanceof WP_User ? $employee->user_email : '',
				'order' => 40,
			],
			'employee_code' => [
				'id'    => 'kerp-employee-profile-code',
				'name'  => 'employee_code',
				'key'   => 'employee_code',
				'label' => __( 'کد پرسنلی', 'kasebi-erp' ),
				'type'  => 'text',
				'class' => 'col-md-6',
				'value' => $meta_value( 'kerp_employee_code' ),
				'order' => 50,
			],
			'role_key' => [
				'id'       => 'kerp-employee-profile-role',
				'name'     => 'role_key',
				'key'      => 'role_key',
				'label'    => __( 'نقش سازمانی', 'kasebi-erp' ),
				'type'     => 'select',
				'class'    => 'col-md-6',
				'options'  => $role_options,
				'value'    => $role_key,
				'required' => TRUE,
				'order'    => 60,
			],
			'employment_type' => [
				'id'      => 'kerp-employee-profile-type',
				'name'    => 'employment_type',
				'key'     => 'employment_type',
				'label'   => __( 'نوع همکاری', 'kasebi-erp' ),
				'type'    => 'select',
				'class'   => 'col-md-6',
				'options' => $this->employment_types(),
				'value'   => $meta_value( 'kerp_employee_employment_type' ) ?: 'full_time',
				'order'   => 70,
			],
			'employment_status' => [
				'id'      => 'kerp-employee-profile-status',
				'name'    => 'employment_status',
				'key'     => 'employment_status',
				'label'   => __( 'وضعیت همکاری', 'kasebi-erp' ),
				'type'    => 'select',
				'class'   => 'col-md-6',
				'options' => $this->statuses(),
				'value'   => $meta_value( 'kerp_employee_status' )
					?: (string) $settings->get( 'default_status', 'active' ),
				'order'   => 80,
			],
			'started_at' => [
				'id'    => 'kerp-employee-profile-started-at',
				'name'  => 'started_at',
				'key'   => 'started_at',
				'label' => __( 'تاریخ شروع همکاری', 'kasebi-erp' ),
				'type'  => 'date',
				'class' => 'col-md-6',
				'value' => $meta_value( 'kerp_employee_started_at' ),
				'order' => 90,
			],
			'ended_at' => [
				'id'    => 'kerp-employee-profile-ended-at',
				'name'  => 'ended_at',
				'key'   => 'ended_at',
				'label' => __( 'تاریخ پایان همکاری', 'kasebi-erp' ),
				'type'  => 'date',
				'class' => 'col-md-6',
				'value' => $meta_value( 'kerp_employee_ended_at' ),
				'order' => 100,
			],
		];

		if ( ! $profile ) {
			unset( $fields['ended_at'] );
		}

		$fields = apply_filters(
			$profile
				? 'kerp_employee_main_profile_fields'
				: 'kerp_employee_main_create_fields',
			$fields,
			$employee_id,
			$employee
		);

		$fields = is_array( $fields ) ? $fields : [];

		$this->sort( $fields );

		return $fields;
	}

	private function prepare_view_fields(
		array $fields,
		string $filter,
		int $employee_id
	): array {
		foreach ( $fields as $field_key => &$field ) {
			if ( ! is_array( $field ) ) {
				continue;
			}

			$field['key'] = sanitize_key(
				(string) ( $field['key'] ?? $field_key )
			);
			$field['display_value'] = $this->format_display_value(
				$field['value'] ?? '',
				$field
			);
		}
		unset( $field );

		$fields = apply_filters( $filter, $fields, $employee_id );
		$fields = is_array( $fields ) ? $fields : [];

		$this->sort( $fields );

		return $fields;
	}

	private function sanitize_definition( array $field ): array {
		$key  = sanitize_key(
			(string) ( $field['key'] ?? $field['name'] ?? '' )
		);
		$type = sanitize_key(
			(string) ( $field['type'] ?? 'text' )
		);

		$allowed_types = [
			'text',
			'email',
			'number',
			'price',
			'date',
			'textarea',
			'select',
			'radio',
			'checkbox',
			'multi-select',
			'switch',
			'url',
			'quill',
		];

		if ( ! in_array( $type, $allowed_types, TRUE ) ) {
			$type = 'text';
		}

		$options = $field['options'] ?? [];

		if ( is_string( $options ) ) {
			$option_rows = preg_split(
				'/\R+|\s*\|\s*/u',
				trim( $options ),
				-1,
				PREG_SPLIT_NO_EMPTY
			);

			$parsed_options = [];

			foreach ( (array) $option_rows as $option_row ) {
				$parts = array_map(
					'trim',
					explode( '=', (string) $option_row, 2 )
				);

				$option_key   = sanitize_key(
					(string) ( $parts[0] ?? '' )
				);
				$option_label = sanitize_text_field(
					(string) ( $parts[1] ?? '' )
				);

				if ( $option_key === '' || $option_label === '' ) {
					continue;
				}

				$parsed_options[ $option_key ] = $option_label;
			}

			$options = $parsed_options;
		}

		$options = is_array( $options ) ? $options : [];

		$clean_options = [];

		foreach ( $options as $option_key => $option_label ) {
			$option_key = sanitize_key( (string) $option_key );

			if ( $option_key === '' ) {
				continue;
			}

			$clean_options[ $option_key ] = sanitize_text_field(
				(string) $option_label
			);
		}

		return [
			'key'             => $key,
			'name'            => $key,
			'meta_key'        => $key,
			'label'           => sanitize_text_field(
				(string) ( $field['label'] ?? $key )
			),
			'description'     => sanitize_textarea_field(
				(string) ( $field['description'] ?? '' )
			),
			'type'            => $type,
			'placeholder'     => sanitize_text_field(
				(string) ( $field['placeholder'] ?? '' )
			),
			'class'           => sanitize_text_field(
				(string) ( $field['class'] ?? 'col-md-6' )
			),
			'options'         => $clean_options,
			'required'        => FALSE,
			'active'          => ! isset( $field['active'] )
				|| ! empty( $field['active'] ),
			'show_on_create'  => ! empty( $field['show_on_create'] ),
			'show_on_profile' => ! isset( $field['show_on_profile'] )
				|| ! empty( $field['show_on_profile'] ),
			'filterable'      => ! empty( $field['filterable'] ),
			'column'          => ! empty( $field['column'] ),
			'order'           => (int) ( $field['order'] ?? 100 ),
		];
	}

	private function to_form_field( array $definition ): array {
		return [
			'id'          => 'kerp-employee-custom-field-' . $definition['key'],
			'name'        => 'meta[' . $definition['key'] . ']',
			'key'         => $definition['key'],
			'meta_key'    => $definition['meta_key'],
			'label'       => $definition['label'],
			'description' => $definition['description'],
			'type'        => $definition['type'],
			'placeholder' => $definition['placeholder'],
			'class'       => $definition['class'],
			'options'     => $definition['options'],
			'required'    => FALSE,
			'order'       => $definition['order'],
		];
	}

	private function sanitize_number( string $value ): string {
		if ( function_exists( 'nooshika_sanitize_numbers' ) ) {
			$value = nooshika_sanitize_numbers( $value );
		}

		$value = str_replace(
			[ ',', '٬', '،', ' ' ],
			'',
			$value
		);

		return preg_replace( '/[^0-9.\-]/', '', $value ) ?? '';
	}

	private function sort( array &$items ): void {
		uasort( $items, [ $this, 'sort_items' ] );
	}
}
