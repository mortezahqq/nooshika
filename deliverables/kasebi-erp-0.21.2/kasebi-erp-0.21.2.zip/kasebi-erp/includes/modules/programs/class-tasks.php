<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Programs_Tasks {

	private static ?self $instance = NULL;

	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	private function __construct() {}

	private function __clone() {}

	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}

	public function table_name(): string {
		global $wpdb;
		return $wpdb->prefix . 'kerp_program_daily_tasks';
	}

	public function get_status_options(): array {
		return [
			'active'    => __( 'فعال', 'kasebi-erp' ),
			'completed' => __( 'انجام‌شده', 'kasebi-erp' ),
			'cancelled' => __( 'لغوشده', 'kasebi-erp' ),
			'archived'  => __( 'آرشیوشده', 'kasebi-erp' ),
		];
	}

	public function get( int $task_id ): ?array {
		global $wpdb;
		$task_id = absint( $task_id );
		if ( $task_id <= 0 ) {
			return NULL;
		}
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$this->table_name()} WHERE id = %d LIMIT 1", $task_id ), ARRAY_A );
		return is_array( $row ) ? $this->hydrate( $row ) : NULL;
	}

	public function get_by_plan( int $plan_id, bool $active_only = TRUE ): array {
		global $wpdb;
		$plan_id = absint( $plan_id );
		if ( $plan_id <= 0 ) {
			return [];
		}
		$where = $active_only ? " AND status IN ('active','completed')" : '';
		$rows  = $wpdb->get_results(
			$wpdb->prepare( "SELECT * FROM {$this->table_name()} WHERE plan_id = %d{$where} ORDER BY sort_order ASC, id ASC", $plan_id ),
			ARRAY_A
		);
		return array_map( [ $this, 'hydrate' ], (array) $rows );
	}

	/** Save a daily task and keep its planned time unique within the student's day. */
	public function save_scheduled_task( array $data, int $task_id = 0 ): int|WP_Error {
		global $wpdb;

		$task_id = absint( $task_id );
		$existing = $task_id > 0 ? $this->get( $task_id ) : NULL;
		if ( $task_id > 0 && ! is_array( $existing ) ) {
			return new WP_Error( 'kerp_programs_task_not_found', __( 'آیتم برنامه پیدا نشد.', 'kasebi-erp' ) );
		}
		$old_plan_id = absint( $existing['plan_id'] ?? 0 );
		$plan_id = absint( $data['plan_id'] ?? $old_plan_id );
		$plan = KERP_Modules_Programs_Plans::instance()->get( $plan_id );
		if ( ! is_array( $plan ) ) {
			return new WP_Error( 'kerp_programs_invalid_plan', __( 'برنامه روزانه معتبر نیست.', 'kasebi-erp' ) );
		}
		$start = $this->normalize_schedule_time( $data['scheduled_start'] ?? '' );
		$end = $this->normalize_schedule_time( $data['scheduled_end'] ?? '' );
		if ( is_wp_error( $start ) ) {
			return $start;
		}
		if ( is_wp_error( $end ) ) {
			return $end;
		}
		if ( ( $start === '' ) !== ( $end === '' ) ) {
			return new WP_Error( 'kerp_programs_schedule_incomplete', __( 'برای زمان‌بندی، ساعت شروع و پایان را با هم وارد کنید.', 'kasebi-erp' ) );
		}
		if ( $start !== '' && $this->time_to_minutes( $end ) <= $this->time_to_minutes( $start ) ) {
			return new WP_Error( 'kerp_programs_schedule_order', __( 'ساعت پایان باید بعد از ساعت شروع باشد.', 'kasebi-erp' ) );
		}

		$lock_name = 'kerp_daily_schedule_' . md5( get_current_blog_id() . ':' . (int) $plan['customer_id'] . ':' . (string) $plan['plan_date'] );
		if ( (int) $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 5)', $lock_name ) ) !== 1 ) {
			return new WP_Error( 'kerp_programs_schedule_busy', __( 'زمان‌بندی این روز هم‌اکنون در حال ویرایش است؛ دوباره تلاش کنید.', 'kasebi-erp' ) );
		}

		try {
			$status = sanitize_key( (string) ( $data['status'] ?? $existing['status'] ?? 'active' ) );
			if ( $start !== '' && in_array( $status, [ 'active', 'completed' ], TRUE ) ) {
				$conflict = $this->find_schedule_conflict(
					(int) $plan['customer_id'],
					(string) $plan['plan_date'],
					$start,
					$end,
					$task_id
				);
				if ( is_array( $conflict ) ) {
					return new WP_Error(
						'kerp_programs_schedule_overlap',
						sprintf(
							__( 'این بازه با آیتم «%1$s» از ساعت %2$s تا %3$s تداخل دارد.', 'kasebi-erp' ),
							(string) $conflict['title'],
							(string) $conflict['scheduled_start'],
							(string) $conflict['scheduled_end']
						)
					);
				}
			}

			$data['meta'] = isset( $data['meta'] ) && is_array( $data['meta'] ) ? $data['meta'] : [];
			$data['meta']['scheduled_start'] = $start;
			$data['meta']['scheduled_end'] = $end;
			$result = $this->save( $data, $task_id );
			if ( is_wp_error( $result ) ) {
				return $result;
			}
			$this->reorder_plan_tasks_by_schedule( $plan_id );
			if ( $old_plan_id > 0 && $old_plan_id !== $plan_id ) {
				$this->reorder_plan_tasks_by_schedule( $old_plan_id );
			}
			return $result;
		} finally {
			$wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $lock_name ) );
		}
	}

	private function normalize_schedule_time( mixed $value ): string|WP_Error {
		$value = trim( (string) $value );
		if ( class_exists( 'KERP_Helpers_Format' ) ) {
			$value = KERP_Helpers_Format::sanitize_numbers( $value );
		}
		if ( $value === '' ) {
			return '';
		}
		if ( preg_match( '/^(?:[01]\d|2[0-3]):[0-5]\d$/', $value ) !== 1 ) {
			return new WP_Error( 'kerp_programs_schedule_time', __( 'ساعت شروع و پایان باید با قالب ۲۴ ساعته مانند 08:30 وارد شوند.', 'kasebi-erp' ) );
		}
		return $value;
	}

	private function time_to_minutes( string $time ): int {
		[ $hour, $minute ] = array_map( 'intval', explode( ':', $time ) );
		return $hour * 60 + $minute;
	}

	private function find_schedule_conflict( int $customer_id, string $plan_date, string $start, string $end, int $exclude_id ): ?array {
		global $wpdb;
		$ids = $wpdb->get_col( $wpdb->prepare(
			"SELECT t.id FROM {$this->table_name()} t INNER JOIN {$wpdb->prefix}kerp_program_daily_plans p ON p.id=t.plan_id WHERE p.customer_id=%d AND p.plan_date=%s AND t.status IN ('active','completed') AND t.id<>%d",
			$customer_id,
			$plan_date,
			$exclude_id
		) );
		$start_minutes = $this->time_to_minutes( $start );
		$end_minutes = $this->time_to_minutes( $end );
		foreach ( (array) $ids as $id ) {
			$task = $this->get( (int) $id );
			if ( ! is_array( $task ) ) {
				continue;
			}
			$other_start = (string) ( $task['scheduled_start'] ?? '' );
			$other_end = (string) ( $task['scheduled_end'] ?? '' );
			if ( preg_match( '/^(?:[01]\d|2[0-3]):[0-5]\d$/', $other_start ) !== 1 || preg_match( '/^(?:[01]\d|2[0-3]):[0-5]\d$/', $other_end ) !== 1 ) {
				continue;
			}
			if ( $start_minutes < $this->time_to_minutes( $other_end ) && $end_minutes > $this->time_to_minutes( $other_start ) ) {
				return $task;
			}
		}
		return NULL;
	}

	private function reorder_plan_tasks_by_schedule( int $plan_id ): void {
		global $wpdb;
		$tasks = $this->get_by_plan( $plan_id, FALSE );
		foreach ( $tasks as &$task ) {
			$start = (string) ( $task['scheduled_start'] ?? '' );
			$task['_schedule_minutes'] = preg_match( '/^(?:[01]\d|2[0-3]):[0-5]\d$/', $start ) === 1 ? $this->time_to_minutes( $start ) : NULL;
		}
		unset( $task );
		usort( $tasks, static function ( array $a, array $b ): int {
			$a_scheduled = $a['_schedule_minutes'] !== NULL;
			$b_scheduled = $b['_schedule_minutes'] !== NULL;
			if ( $a_scheduled !== $b_scheduled ) {
				return $a_scheduled ? -1 : 1;
			}
			if ( $a_scheduled && $a['_schedule_minutes'] !== $b['_schedule_minutes'] ) {
				return $a['_schedule_minutes'] <=> $b['_schedule_minutes'];
			}
			return ( (int) $a['sort_order'] <=> (int) $b['sort_order'] ) ?: ( (int) $a['id'] <=> (int) $b['id'] );
		} );
		foreach ( $tasks as $index => $task ) {
			$wpdb->update( $this->table_name(), [ 'sort_order' => ( $index + 1 ) * 10 ], [ 'id' => (int) $task['id'] ], [ '%d' ], [ '%d' ] );
		}
	}

	public function save( array $data, int $task_id = 0 ): int|WP_Error {
		global $wpdb;
		$task_id  = absint( $task_id );
		$existing = $task_id > 0 ? $this->get( $task_id ) : NULL;
		$plan_id  = absint( $data['plan_id'] ?? $existing['plan_id'] ?? 0 );
		$plan     = KERP_Modules_Programs_Plans::instance()->get( $plan_id );
		$type_id  = absint( $data['task_type_id'] ?? $existing['task_type_id'] ?? 0 );
		$type     = KERP_Modules_Programs_Types::instance()->get( $type_id );
		$unit_id  = absint( $data['unit_id'] ?? $existing['unit_id'] ?? 0 );
		$title    = sanitize_text_field( (string) ( $data['title'] ?? '' ) );
		$status   = sanitize_key( (string) ( $data['status'] ?? $existing['status'] ?? 'active' ) );

		if ( ! is_array( $plan ) ) {
			return new WP_Error( 'kerp_programs_invalid_plan', __( 'برنامه روزانه معتبر نیست.', 'kasebi-erp' ) );
		}
		if ( ! is_array( $type ) ) {
			return new WP_Error( 'kerp_programs_invalid_task_type', __( 'نوع آیتم برنامه معتبر نیست.', 'kasebi-erp' ) );
		}
		if ( $unit_id > 0 && ! KERP_Modules_Programs_Units::instance()->get( $unit_id ) ) {
			return new WP_Error( 'kerp_programs_invalid_unit', __( 'واحد انتخاب‌شده معتبر نیست.', 'kasebi-erp' ) );
		}
		if ( $title === '' ) {
			return new WP_Error( 'kerp_programs_task_title_required', __( 'عنوان آیتم برنامه الزامی است.', 'kasebi-erp' ) );
		}
		if ( ! isset( $this->get_status_options()[ $status ] ) ) {
			return new WP_Error( 'kerp_programs_invalid_task_status', __( 'وضعیت آیتم برنامه معتبر نیست.', 'kasebi-erp' ) );
		}
		if ( array_key_exists( 'term_ids', $data ) ) {
			$validated_terms = KERP_Modules_Programs_Taxonomies::instance()->validate_term_ids( is_array( $data['term_ids'] ) ? $data['term_ids'] : [] );
			if ( is_wp_error( $validated_terms ) ) {
				return $validated_terms;
			}
			$data['term_ids'] = $validated_terms;
		}

		$target_value = $this->sanitize_decimal( $data['target_value'] ?? NULL );
		$now          = current_time( 'mysql' );
		$row          = [
			'plan_id'                 => $plan_id,
			'source_template_task_id' => absint( $data['source_template_task_id'] ?? $existing['source_template_task_id'] ?? 0 ),
			'task_type_id'            => $type_id,
			'unit_id'                 => $unit_id,
			'title'                   => $title,
			'description'             => wp_kses_post( (string) ( $data['description'] ?? '' ) ),
			'target_value'            => $target_value,
			'target_text'             => wp_kses_post( (string) ( $data['target_text'] ?? '' ) ),
			'is_required'             => ! empty( $data['is_required'] ) ? 1 : 0,
			'status'                  => $status,
			'sort_order'              => intval( $data['sort_order'] ?? 10 ),
			'updated_at'              => $now,
		];
		if ( $task_id > 0 ) {
			$result = $wpdb->update( $this->table_name(), $row, [ 'id' => $task_id ] );
		} else {
			$row['created_at'] = $now;
			$result            = $wpdb->insert( $this->table_name(), $row );
			$task_id           = (int) $wpdb->insert_id;
		}
		if ( $result === FALSE || $task_id <= 0 ) {
			return new WP_Error( 'kerp_programs_task_save_failed', __( 'ذخیره آیتم برنامه انجام نشد.', 'kasebi-erp' ) );
		}

		if ( array_key_exists( 'term_ids', $data ) ) {
			$term_ids = is_array( $data['term_ids'] ) ? $data['term_ids'] : [];
			$term_result = KERP_Modules_Programs_Taxonomies::instance()->set_object_terms(
				KERP_Modules_Programs_Taxonomies::OBJECT_TASK,
				$task_id,
				$term_ids
			);
			if ( is_wp_error( $term_result ) ) {
				return $term_result;
			}
		}

		if ( isset( $data['meta'] ) && is_array( $data['meta'] ) ) {
			foreach ( $data['meta'] as $meta_key => $meta_value ) {
				$meta_key = sanitize_key( (string) $meta_key );
				if ( $meta_key === '' ) {
					continue;
				}
				KERP_Helpers_Meta::instance()->update_task_meta( $task_id, $meta_key, $meta_value );
			}
		}

		do_action( 'kerp_program_task_saved', $task_id, $plan_id, $data );
		return $task_id;
	}

	public function delete( int $task_id ): bool|WP_Error {
		global $wpdb;
		$task = $this->get( $task_id );
		if ( ! is_array( $task ) ) {
			return new WP_Error( 'kerp_programs_task_not_found', __( 'آیتم برنامه پیدا نشد.', 'kasebi-erp' ) );
		}
		if ( $this->has_result( $task_id ) ) {
			$result = $wpdb->update(
				$this->table_name(),
				[ 'status' => 'cancelled', 'updated_at' => current_time( 'mysql' ) ],
				[ 'id' => $task_id ]
			);
			return $result !== FALSE ? TRUE : new WP_Error( 'kerp_programs_task_cancel_failed', __( 'آیتم دارای نتیجه است و لغو آن انجام نشد.', 'kasebi-erp' ) );
		}
		return $this->force_delete( $task_id );
	}

	public function force_delete( int $task_id ): bool|WP_Error {
		global $wpdb;
		$task_id = absint( $task_id );
		if ( $task_id <= 0 ) {
			return FALSE;
		}
		if ( $this->has_result( $task_id ) ) {
			return new WP_Error( 'kerp_programs_task_has_result', __( 'آیتم دارای نتیجه قابل حذف کامل نیست.', 'kasebi-erp' ) );
		}
		KERP_Modules_Programs_Taxonomies::instance()->delete_object_terms( KERP_Modules_Programs_Taxonomies::OBJECT_TASK, $task_id );
		KERP_Modules_Programs_Resources::instance()->delete_by_task( $task_id );
		KERP_Helpers_Meta::instance()->delete_task_meta( $task_id );
		$result = $wpdb->delete( $this->table_name(), [ 'id' => $task_id ], [ '%d' ] );
		return $result !== FALSE;
	}

	public function has_result( int $task_id ): bool {
		global $wpdb;
		$count = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}kerp_program_results WHERE task_id = %d", absint( $task_id ) ) );
		return $count > 0;
	}

	public function find_by_source_template_task( int $plan_id, int $source_template_task_id ): ?array {
		global $wpdb;
		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$this->table_name()} WHERE plan_id = %d AND source_template_task_id = %d LIMIT 1",
				absint( $plan_id ),
				absint( $source_template_task_id )
			),
			ARRAY_A
		);
		return is_array( $row ) ? $this->hydrate( $row ) : NULL;
	}

	public function sanitize_decimal( mixed $value ): ?string {
		if ( $value === NULL || $value === '' ) {
			return NULL;
		}
		$value = (string) $value;
		if ( function_exists( 'nooshika_sanitize_numbers' ) ) {
			$value = nooshika_sanitize_numbers( $value );
		}
		$value = str_replace( [ ',', '٬' ], [ '.', '' ], $value );
		$value = preg_replace( '/[^0-9.\-]/', '', $value );
		if ( ! is_string( $value ) || $value === '' || ! is_numeric( $value ) ) {
			return NULL;
		}
		return number_format( (float) $value, 6, '.', '' );
	}

	private function hydrate( array $row ): array {
		$row['id']                      = absint( $row['id'] ?? 0 );
		$row['plan_id']                 = absint( $row['plan_id'] ?? 0 );
		$row['source_template_task_id'] = absint( $row['source_template_task_id'] ?? 0 );
		$row['task_type_id']            = absint( $row['task_type_id'] ?? 0 );
		$row['unit_id']                 = absint( $row['unit_id'] ?? 0 );
		$row['is_required']             = ! empty( $row['is_required'] );
		$row['sort_order']              = intval( $row['sort_order'] ?? 10 );
		$row['scheduled_start']         = (string) KERP_Helpers_Meta::instance()->get_task_meta( (int) $row['id'], 'scheduled_start', TRUE );
		$row['scheduled_end']           = (string) KERP_Helpers_Meta::instance()->get_task_meta( (int) $row['id'], 'scheduled_end', TRUE );
		$row['term_ids']                = KERP_Modules_Programs_Taxonomies::instance()->get_object_term_ids( KERP_Modules_Programs_Taxonomies::OBJECT_TASK, (int) $row['id'] );
		$row['resources']               = KERP_Modules_Programs_Resources::instance()->get_by_task( (int) $row['id'] );
		$row['result']                  = class_exists( 'KERP_Modules_Programs_Results' ) ? KERP_Modules_Programs_Results::instance()->get_by_task( (int) $row['id'] ) : NULL;
		return $row;
	}
}
