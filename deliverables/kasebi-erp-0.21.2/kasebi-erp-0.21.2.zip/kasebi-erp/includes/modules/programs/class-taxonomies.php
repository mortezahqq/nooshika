<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Programs_Taxonomies {

	public const OBJECT_TASK          = 'daily_task';
	public const OBJECT_TEMPLATE_TASK = 'template_task';

	private static ?self $instance = NULL;

	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	private function __construct() {}

	private function __clone() {}

	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}

	public function taxonomy_table(): string {
		global $wpdb;
		return $wpdb->prefix . 'kerp_program_taxonomies';
	}

	public function term_table(): string {
		global $wpdb;
		return $wpdb->prefix . 'kerp_program_terms';
	}

	public function relationship_table(): string {
		global $wpdb;
		return $wpdb->prefix . 'kerp_program_term_relationships';
	}

	public function get_taxonomy( int $taxonomy_id ): ?array {
		global $wpdb;
		$taxonomy_id = absint( $taxonomy_id );
		if ( $taxonomy_id <= 0 ) {
			return NULL;
		}
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$this->taxonomy_table()} WHERE id = %d LIMIT 1", $taxonomy_id ), ARRAY_A );
		return is_array( $row ) ? $this->hydrate_taxonomy( $row ) : NULL;
	}

	public function get_taxonomy_by_key( string $taxonomy_key ): ?array {
		global $wpdb;
		$taxonomy_key = sanitize_key( $taxonomy_key );
		if ( $taxonomy_key === '' ) {
			return NULL;
		}
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$this->taxonomy_table()} WHERE taxonomy_key = %s LIMIT 1", $taxonomy_key ), ARRAY_A );
		return is_array( $row ) ? $this->hydrate_taxonomy( $row ) : NULL;
	}

	public function get_taxonomies( bool $active_only = FALSE ): array {
		global $wpdb;
		$where = $active_only ? ' WHERE active = 1' : '';
		$rows  = $wpdb->get_results( "SELECT * FROM {$this->taxonomy_table()}{$where} ORDER BY sort_order ASC, id ASC", ARRAY_A );
		return array_map( [ $this, 'hydrate_taxonomy' ], (array) $rows );
	}

	public function save_taxonomy( array $data, int $taxonomy_id = 0 ): int|WP_Error {
		global $wpdb;
		$taxonomy_id  = absint( $taxonomy_id );
		$existing     = $taxonomy_id > 0 ? $this->get_taxonomy( $taxonomy_id ) : NULL;
		$taxonomy_key = sanitize_key( (string) ( $data['taxonomy_key'] ?? $existing['taxonomy_key'] ?? '' ) );
		$label        = sanitize_text_field( (string) ( $data['label'] ?? '' ) );
		$plural_label = sanitize_text_field( (string) ( $data['plural_label'] ?? '' ) );

		if ( $taxonomy_key === '' || $label === '' || $plural_label === '' ) {
			return new WP_Error( 'kerp_programs_invalid_taxonomy', __( 'کلید، عنوان و عنوان جمع دسته‌بندی الزامی است.', 'kasebi-erp' ) );
		}
		$duplicate = $this->get_taxonomy_by_key( $taxonomy_key );
		if ( is_array( $duplicate ) && (int) $duplicate['id'] !== $taxonomy_id ) {
			return new WP_Error( 'kerp_programs_duplicate_taxonomy', __( 'این کلید دسته‌بندی قبلاً استفاده شده است.', 'kasebi-erp' ) );
		}

		$row = [
			'taxonomy_key' => $taxonomy_key,
			'label'        => $label,
			'plural_label' => $plural_label,
			'description'  => sanitize_textarea_field( (string) ( $data['description'] ?? '' ) ),
			'hierarchical' => ! empty( $data['hierarchical'] ) ? 1 : 0,
			'multiple'     => ! empty( $data['multiple'] ) ? 1 : 0,
			'required'     => ! empty( $data['required'] ) ? 1 : 0,
			'active'       => ! empty( $data['active'] ) ? 1 : 0,
			'sort_order'   => intval( $data['sort_order'] ?? 10 ),
		];
		if ( $taxonomy_id > 0 ) {
			$result = $wpdb->update( $this->taxonomy_table(), $row, [ 'id' => $taxonomy_id ] );
		} else {
			$result      = $wpdb->insert( $this->taxonomy_table(), $row );
			$taxonomy_id = (int) $wpdb->insert_id;
		}
		if ( $result === FALSE || $taxonomy_id <= 0 ) {
			return new WP_Error( 'kerp_programs_taxonomy_save_failed', __( 'ذخیره دسته‌بندی انجام نشد.', 'kasebi-erp' ) );
		}
		return $taxonomy_id;
	}

	/** Import the bundled tree without overwriting existing terms or their settings. */
	public function import_math_topics(): array|WP_Error {
        return $this->import_subject_topics( 'math' );
    }

    public static function topic_import_subjects(): array {
        return [ 'math' => 'ریاضی', 'chemistry' => 'شیمی', 'physics' => 'فیزیک', 'biology' => 'زیست‌شناسی' ];
    }

    public function import_subject_topics( string $subject ): array|WP_Error {
        $subjects = self::topic_import_subjects();
        if ( ! isset( $subjects[ $subject ] ) ) {
            return new WP_Error( 'kerp_import_subject', __( 'درس انتخاب‌شده معتبر نیست.', 'kasebi-erp' ) );
        }
        $label = $subjects[ $subject ];
		global $wpdb;
		// A database-scoped lock also prevents duplicates from simultaneous requests.
		$lock = 'kerp_topics_' . md5( $this->taxonomy_table() );
		if ( (int) $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 0)', $lock ) ) !== 1 ) {
			return new WP_Error( 'kerp_math_import_busy', __( 'ایمپورت دیگری در حال اجراست؛ کمی بعد دوباره تلاش کنید.', 'kasebi-erp' ) );
		}
		try {
			$candidates = array_values( array_filter( $this->get_taxonomies( FALSE ), static function ( $item ) {
				return in_array( $item['taxonomy_key'], [ 'topic', 'topics' ], TRUE ) ||
					in_array( trim( $item['label'] ), [ 'مبحث', 'مباحث' ], TRUE ) ||
					in_array( trim( $item['plural_label'] ), [ 'مبحث', 'مباحث' ], TRUE );
			} ) );
			if ( count( $candidates ) > 1 ) {
				return new WP_Error( 'kerp_topics_ambiguous', __( 'بیش از یک تکسونومی با نام یا کلید مبحث وجود دارد؛ ابتدا نام‌گذاری آن‌ها را مشخص کنید.', 'kasebi-erp' ) );
			}
			$taxonomy = $candidates[0] ?? NULL;
			$taxonomy_id = $taxonomy ? (int) $taxonomy['id'] : $this->save_taxonomy( [
				'taxonomy_key' => 'topic',
				'label' => 'مبحث', 'plural_label' => 'مباحث',
				'description' => 'مباحث درسی و زیرمبحث‌ها؛ دسته‌بندی آموزشی مستقل از حذفیات سالانهٔ کنکور.',
				'hierarchical' => 1, 'multiple' => 1, 'required' => 0, 'active' => 1, 'sort_order' => 10,
			] );
			if ( is_wp_error( $taxonomy_id ) ) {
				return $taxonomy_id;
			}
			if ( $taxonomy && empty( $taxonomy['hierarchical'] ) ) {
				$result = $this->save_taxonomy( array_merge( $taxonomy, [ 'hierarchical' => 1 ] ), $taxonomy_id );
				if ( is_wp_error( $result ) ) {
					return $result;
				}
			}
			$root_name = 'مباحث ' . $label;
			$root_slug = $subject . '-topics';
			$root = NULL;
			foreach ( $this->get_terms( $taxonomy_id, FALSE ) as $term ) {
				if ( $term['slug'] === $root_slug || ( (int) $term['parent_id'] === 0 && $term['name'] === $root_name ) ) {
					if ( $root || (int) $term['parent_id'] !== 0 ) {
						return new WP_Error( 'kerp_topics_root_conflict', __( 'شاخهٔ درس در تکسونومی مبحث مبهم است یا جابه‌جا شده؛ ابتدا ساختار آن را بررسی کنید.', 'kasebi-erp' ) );
					}
					$root = $term;
				}
			}
			$root_id = $root ? (int) $root['id'] : $this->save_term( [
				'taxonomy_id' => $taxonomy_id, 'parent_id' => 0, 'name' => $root_name,
				'slug' => $root_slug, 'active' => 1, 'sort_order' => ( array_search( $subject, array_keys( $subjects ), TRUE ) + 1 ) * 10,
			] );
			if ( is_wp_error( $root_id ) ) {
				return $root_id;
			}
			$migrated = $this->move_legacy_subject_topics( $subject, $taxonomy_id, $root_id );
			if ( is_wp_error( $migrated ) ) {
				return $migrated;
			}
			$by_slug = [];
			$by_parent_name = [];
			foreach ( $this->get_terms( $taxonomy_id, FALSE ) as $term ) {
				$by_slug[ $term['slug'] ] = $term;
				$by_parent_name[ $term['parent_id'] ][ $term['name'] ] = $term;
			}
			$created = $root ? 0 : 1;
			$skipped = $root ? 1 : 0;
			$visit = function ( array $nodes, int $parent_id = 0, array $path = [] ) use ( &$visit, &$by_slug, &$by_parent_name, &$created, &$skipped, $taxonomy_id, $subject ) {
				$order = 0;
				foreach ( $nodes as $name => $children ) {
					if ( is_int( $name ) ) {
						$name = $children;
						$children = [];
					}
					$order += 10;
					$node_path = array_merge( $path, [ $name ] );
					$slug = $subject . '-' . substr( hash( 'sha256', implode( '/', $node_path ) ), 0, 24 );
					$existing = $by_slug[ $slug ] ?? $by_parent_name[ $parent_id ][ $name ] ?? NULL;
					if ( $existing ) {
						if ( (int) $existing['parent_id'] !== $parent_id ) {
							return new WP_Error( 'kerp_math_import_conflict', sprintf( __( 'مسیر «%s» قبلاً جابه‌جا شده است؛ برای جلوگیری از تغییر ساختار موجود، ایمپورت متوقف شد.', 'kasebi-erp' ), implode( ' / ', $node_path ) ) );
						}
						$id = (int) $existing['id'];
						$skipped++;
					} else {
						$id = $this->save_term( [ 'taxonomy_id' => $taxonomy_id, 'parent_id' => $parent_id, 'name' => $name, 'slug' => $slug, 'active' => 1, 'sort_order' => $order ] );
						if ( is_wp_error( $id ) ) {
							return $id;
						}
						$record = [ 'id' => $id, 'parent_id' => $parent_id, 'name' => $name, 'slug' => $slug ];
						$by_slug[ $slug ] = $record;
						$by_parent_name[ $parent_id ][ $name ] = $record;
						$created++;
					}
					$result = $visit( $children, $id, $node_path );
					if ( is_wp_error( $result ) ) {
						return $result;
					}
				}
				return TRUE;
			};
			$result = $visit( require __DIR__ . '/' . $subject . '-topics.php', $root_id );
			if ( is_wp_error( $result ) ) {
				return new WP_Error( 'kerp_math_import_incomplete', sprintf( __( '%1$s تعداد %2$d گزینه تا این مرحله اضافه شد. اجرای مجدد از موارد باقی‌مانده ادامه می‌یابد.', 'kasebi-erp' ), $result->get_error_message(), $created ) );
			}
			return [ 'taxonomy_id' => $taxonomy_id, 'root_id' => $root_id, 'created' => $created, 'skipped' => $skipped, 'migrated' => $migrated ];
		} finally {
			$wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $lock ) );
		}
	}

	/** Move an earlier import in one statement, retaining term IDs and relationships. */
	private function move_legacy_subject_topics( string $subject, int $taxonomy_id, int $root_id ): int|WP_Error {
		global $wpdb;
		$legacy = $this->get_taxonomy_by_key( $subject . '_topics' );
		if ( ! $legacy || (int) $legacy['id'] === $taxonomy_id ) {
			return 0;
		}
		$terms = $this->get_terms( (int) $legacy['id'], FALSE );
		$target = $this->get_terms( $taxonomy_id, FALSE );
		$slugs = array_column( $target, 'id', 'slug' );
		$root_names = [];
		foreach ( $target as $term ) {
			if ( (int) $term['parent_id'] === $root_id ) {
				$root_names[ $term['name'] ] = TRUE;
			}
		}
		$ids = array_fill_keys( array_column( $terms, 'id' ), TRUE );
		foreach ( $terms as $term ) {
			if ( isset( $slugs[ $term['slug'] ] ) || ( (int) $term['parent_id'] === 0 && isset( $root_names[ $term['name'] ] ) ) ) {
				return new WP_Error( 'kerp_topics_migration_conflict', __( 'بعضی مباحث هم در تکسونومی قبلی و هم در مقصد وجود دارند؛ انتقال خودکار برای حفظ ارتباطات متوقف شد.', 'kasebi-erp' ) );
			}
			if ( $term['parent_id'] && ! isset( $ids[ $term['parent_id'] ] ) ) {
				return new WP_Error( 'kerp_topics_migration_parent', __( 'ساختار والدهای تکسونومی قبلی معتبر نیست؛ ابتدا آن را اصلاح کنید.', 'kasebi-erp' ) );
			}
		}
		if ( $terms && $wpdb->query( $wpdb->prepare(
			"UPDATE {$this->term_table()} SET taxonomy_id = %d, parent_id = CASE WHEN parent_id = 0 THEN %d ELSE parent_id END WHERE taxonomy_id = %d",
			$taxonomy_id, $root_id, (int) $legacy['id']
		) ) === FALSE ) {
			return new WP_Error( 'kerp_topics_migration_failed', __( 'انتقال مباحث قبلی انجام نشد؛ دوباره تلاش کنید.', 'kasebi-erp' ) );
		}
		$result = $this->delete_taxonomy( (int) $legacy['id'] );
		return is_wp_error( $result ) ? $result : count( $terms );
	}

	public function delete_taxonomy( int $taxonomy_id ): bool|WP_Error {
		global $wpdb;
		$taxonomy = $this->get_taxonomy( $taxonomy_id );
		if ( ! is_array( $taxonomy ) ) {
			return new WP_Error( 'kerp_programs_taxonomy_not_found', __( 'دسته‌بندی پیدا نشد.', 'kasebi-erp' ) );
		}
		$term_count = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$this->term_table()} WHERE taxonomy_id = %d", $taxonomy_id ) );
		if ( $term_count > 0 ) {
			return new WP_Error( 'kerp_programs_taxonomy_has_terms', __( 'ابتدا گزینه‌های این دسته‌بندی را حذف کنید.', 'kasebi-erp' ) );
		}
		$result = $wpdb->delete( $this->taxonomy_table(), [ 'id' => $taxonomy_id ], [ '%d' ] );
		if ( $result === FALSE ) {
			return new WP_Error( 'kerp_programs_taxonomy_delete_failed', __( 'حذف دسته‌بندی انجام نشد.', 'kasebi-erp' ) );
		}
		KERP_Helpers_Meta::instance()->delete_taxonomy_meta( $taxonomy_id );
		return TRUE;
	}

	public static function term_icons(): array {
		return [ 'ni ni-folder' => 'پوشه', 'ni ni-book' => 'کتاب', 'ni ni-tag' => 'برچسب', 'ni ni-layers' => 'لایه‌ها', 'ni ni-file-text' => 'سند', 'ni ni-star' => 'ستاره' ];
	}

	public static function term_colors(): array {
		return [ 'blue' => 'آبی', 'green' => 'سبز', 'purple' => 'بنفش', 'orange' => 'نارنجی', 'red' => 'قرمز', 'gray' => 'خاکستری' ];
	}

	public function explorer_terms( int $taxonomy_id ): array {
		global $wpdb;
		$terms = $this->get_terms( $taxonomy_id, FALSE );
		$meta_table = KERP_Helpers_Meta::instance()->table_name();
		$meta = [];
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT m.object_id, m.meta_key, m.meta_value FROM {$meta_table} m INNER JOIN {$this->term_table()} t ON t.id = m.object_id WHERE m.object_type = %s AND t.taxonomy_id = %d AND m.meta_key IN ('explorer_icon', 'explorer_color') ORDER BY m.meta_id ASC",
			KERP_Helpers_Meta::TYPE_PROGRAM_TERM, $taxonomy_id
		), ARRAY_A );
		foreach ( (array) $rows as $row ) {
			$meta[ $row['object_id'] ][ $row['meta_key'] ] ??= maybe_unserialize( $row['meta_value'] );
		}
		$usage = $wpdb->get_results( $wpdb->prepare(
			"SELECT r.term_id, COUNT(*) AS total FROM {$this->relationship_table()} r INNER JOIN {$this->term_table()} t ON t.id = r.term_id WHERE t.taxonomy_id = %d GROUP BY r.term_id", $taxonomy_id
		), ARRAY_A );
		$usage = array_column( (array) $usage, 'total', 'term_id' );
		$children = array_count_values( array_column( $terms, 'parent_id' ) );
		foreach ( $terms as &$term ) {
			$icon = $meta[ $term['id'] ]['explorer_icon'] ?? '';
			$color = $meta[ $term['id'] ]['explorer_color'] ?? '';
			$term['icon'] = isset( self::term_icons()[ $icon ] ) ? $icon : 'ni ni-folder';
			$term['color'] = isset( self::term_colors()[ $color ] ) ? $color : 'blue';
			$term['children_count'] = $children[ $term['id'] ] ?? 0;
			$term['usage'] = (int) ( $usage[ $term['id'] ] ?? 0 );
			$term['can_delete'] = ! $term['usage'] && ! $term['children_count'];
		}
		unset( $term );
		return $terms;
	}

	/** Serialize moves per taxonomy and commit parent and sibling order together. */
	public function move_term( int $taxonomy_id, int $term_id, int $parent_id, int $before_id = 0 ): bool|WP_Error {
		global $wpdb;
		$taxonomy = $this->get_taxonomy( $taxonomy_id );
		if ( ! $taxonomy || ! $taxonomy['hierarchical'] ) {
			return new WP_Error( 'invalid_taxonomy', 'دسته‌بندی سلسله‌مراتبی معتبر نیست.' );
		}
		if ( $wpdb->query( 'START TRANSACTION' ) === FALSE ) {
			return new WP_Error( 'move_failed', 'ذخیرهٔ جابه‌جایی ممکن نشد.' );
		}
		$committed = FALSE;
		try {
			$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$this->term_table()} WHERE taxonomy_id = %d ORDER BY sort_order, name, id FOR UPDATE", $taxonomy_id ), ARRAY_A );
			$map = array_column( (array) $rows, NULL, 'id' );
			if ( ! isset( $map[ $term_id ] ) || ( $parent_id && ! isset( $map[ $parent_id ] ) ) || $before_id === $term_id ) {
				return new WP_Error( 'invalid_destination', 'مبدأ یا مقصد معتبر نیست.' );
			}
			$seen = [ $term_id => TRUE ];
			$current = $parent_id;
			while ( $current ) {
				if ( isset( $seen[ $current ] ) || ! isset( $map[ $current ] ) ) {
					return new WP_Error( 'term_cycle', 'انتقال به خود دسته یا زیرمجموعهٔ آن مجاز نیست.' );
				}
				$seen[ $current ] = TRUE;
				$current = (int) $map[ $current ]['parent_id'];
			}
			$siblings = array_values( array_filter( array_keys( $map ), static fn( $id ) => (int) $id !== $term_id && (int) $map[ $id ]['parent_id'] === $parent_id ) );
			$index = $before_id ? array_search( $before_id, $siblings, FALSE ) : count( $siblings );
			if ( $index === FALSE ) {
				return new WP_Error( 'invalid_order', 'دستهٔ مرجع ترتیب در مقصد وجود ندارد.' );
			}
			array_splice( $siblings, $index, 0, [ $term_id ] );
			foreach ( $siblings as $position => $id ) {
				if ( $wpdb->update( $this->term_table(), [ 'parent_id' => $parent_id, 'sort_order' => ( $position + 1 ) * 10 ], [ 'id' => $id, 'taxonomy_id' => $taxonomy_id ], [ '%d', '%d' ], [ '%d', '%d' ] ) === FALSE ) {
					return new WP_Error( 'move_failed', 'ذخیرهٔ ترتیب انجام نشد؛ دوباره تلاش کنید.' );
				}
			}
			$committed = $wpdb->query( 'COMMIT' ) !== FALSE;
			return $committed ? TRUE : new WP_Error( 'move_failed', 'ثبت جابه‌جایی انجام نشد.' );
		} finally {
			if ( ! $committed ) {
				$wpdb->query( 'ROLLBACK' );
			}
		}
	}

	public function get_term( int $term_id ): ?array {
		global $wpdb;
		$term_id = absint( $term_id );
		if ( $term_id <= 0 ) {
			return NULL;
		}
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$this->term_table()} WHERE id = %d LIMIT 1", $term_id ), ARRAY_A );
		return is_array( $row ) ? $this->hydrate_term( $row ) : NULL;
	}

	public function get_terms( int $taxonomy_id = 0, bool $active_only = FALSE ): array {
		global $wpdb;
		$where  = [];
		$values = [];
		if ( $taxonomy_id > 0 ) {
			$where[]  = 'taxonomy_id = %d';
			$values[] = absint( $taxonomy_id );
		}
		if ( $active_only ) {
			$where[] = 'active = 1';
		}
		$sql = "SELECT * FROM {$this->term_table()}";
		if ( $where ) {
			$sql .= ' WHERE ' . implode( ' AND ', $where );
		}
		$sql .= ' ORDER BY taxonomy_id ASC, sort_order ASC, name ASC';
		if ( $values ) {
			$sql = $wpdb->prepare( $sql, $values );
		}
		$rows = $wpdb->get_results( $sql, ARRAY_A );
		return array_map( [ $this, 'hydrate_term' ], (array) $rows );
	}

	public function get_term_options( int $taxonomy_id, int $exclude_id = 0 ): array {
		$options = [ 0 => __( 'بدون والد', 'kasebi-erp' ) ];
		$terms = array_column( $this->get_terms( $taxonomy_id, FALSE ), NULL, 'id' );
		foreach ( $terms as $term ) {
			$path = [];
			$seen = [];
			$current = $term;
			$excluded = FALSE;
			while ( $current && ! isset( $seen[ $current['id'] ] ) ) {
				$seen[ $current['id'] ] = TRUE;
				$excluded = $excluded || ( $exclude_id > 0 && (int) $current['id'] === $exclude_id );
				array_unshift( $path, (string) $current['name'] );
				$current = $terms[ $current['parent_id'] ] ?? NULL;
			}
			if ( $excluded ) {
				continue;
			}
			$options[ (int) $term['id'] ] = implode( ' / ', $path );
		}
		return $options;
	}

	public function save_term( array $data, int $term_id = 0 ): int|WP_Error {
		global $wpdb;
		$term_id     = absint( $term_id );
		$existing    = $term_id > 0 ? $this->get_term( $term_id ) : NULL;
		$taxonomy_id = absint( $data['taxonomy_id'] ?? $existing['taxonomy_id'] ?? 0 );
		$taxonomy    = $this->get_taxonomy( $taxonomy_id );
		$name        = sanitize_text_field( (string) ( $data['name'] ?? '' ) );
		$slug        = sanitize_title( (string) ( $data['slug'] ?? $name ) );
		$parent_id   = absint( $data['parent_id'] ?? 0 );

		if ( ! is_array( $taxonomy ) || $name === '' || $slug === '' ) {
			return new WP_Error( 'kerp_programs_invalid_term', __( 'دسته‌بندی، نام و نامک گزینه معتبر نیست.', 'kasebi-erp' ) );
		}
		if ( empty( $taxonomy['hierarchical'] ) ) {
			$parent_id = 0;
		}
		if ( $parent_id > 0 ) {
			$parent = $this->get_term( $parent_id );
			if ( ! is_array( $parent ) || (int) $parent['taxonomy_id'] !== $taxonomy_id ) {
				return new WP_Error( 'kerp_programs_invalid_parent_term', __( 'گزینه والد متعلق به دسته‌بندی انتخاب‌شده نیست.', 'kasebi-erp' ) );
			}
			if ( $term_id > 0 && $this->would_create_cycle( $term_id, $parent_id ) ) {
				return new WP_Error( 'kerp_programs_term_cycle', __( 'انتخاب این والد باعث ایجاد حلقه در ساختار دسته‌بندی می‌شود.', 'kasebi-erp' ) );
			}
		}
		$duplicate = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$this->term_table()} WHERE taxonomy_id = %d AND slug = %s LIMIT 1", $taxonomy_id, $slug ) );
		if ( $duplicate && absint( $duplicate ) !== $term_id ) {
			return new WP_Error( 'kerp_programs_duplicate_term', __( 'این نامک در دسته‌بندی انتخاب‌شده قبلاً استفاده شده است.', 'kasebi-erp' ) );
		}

		$row = [
			'taxonomy_id' => $taxonomy_id,
			'parent_id'   => $parent_id,
			'name'        => $name,
			'slug'        => $slug,
			'description' => sanitize_textarea_field( (string) ( $data['description'] ?? '' ) ),
			'active'      => ! empty( $data['active'] ) ? 1 : 0,
			'sort_order'  => intval( $data['sort_order'] ?? 10 ),
		];
		if ( $term_id > 0 ) {
			$result = $wpdb->update( $this->term_table(), $row, [ 'id' => $term_id ] );
		} else {
			$result  = $wpdb->insert( $this->term_table(), $row );
			$term_id = (int) $wpdb->insert_id;
		}
		if ( $result === FALSE || $term_id <= 0 ) {
			return new WP_Error( 'kerp_programs_term_save_failed', __( 'ذخیره گزینه انجام نشد.', 'kasebi-erp' ) );
		}
		return $term_id;
	}

	public function delete_term( int $term_id ): bool|WP_Error {
		global $wpdb;
		$term = $this->get_term( $term_id );
		if ( ! is_array( $term ) ) {
			return new WP_Error( 'kerp_programs_term_not_found', __( 'گزینه پیدا نشد.', 'kasebi-erp' ) );
		}
		$children = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$this->term_table()} WHERE parent_id = %d", $term_id ) );
		if ( $children > 0 ) {
			return new WP_Error( 'kerp_programs_term_has_children', __( 'این گزینه دارای زیرمجموعه است و قابل حذف نیست.', 'kasebi-erp' ) );
		}
		$usage = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$this->relationship_table()} WHERE term_id = %d", $term_id ) );
		if ( $usage > 0 ) {
			return new WP_Error( 'kerp_programs_term_in_use', __( 'این گزینه در آیتم‌های برنامه استفاده شده و قابل حذف نیست.', 'kasebi-erp' ) );
		}
		$result = $wpdb->delete( $this->term_table(), [ 'id' => $term_id ], [ '%d' ] );
		if ( $result === FALSE ) {
			return new WP_Error( 'kerp_programs_term_delete_failed', __( 'حذف گزینه انجام نشد.', 'kasebi-erp' ) );
		}
		KERP_Helpers_Meta::instance()->delete_term_meta( $term_id );
		return TRUE;
	}

	public function get_grouped_terms( bool $active_only = TRUE ): array {
		$groups = [];
		foreach ( $this->get_taxonomies( $active_only ) as $taxonomy ) {
			$groups[] = [
				'taxonomy' => $taxonomy,
				'terms'    => $this->get_terms( (int) $taxonomy['id'], $active_only ),
			];
		}
		return $groups;
	}

	public function get_object_term_ids( string $object_type, int $object_id ): array {
		global $wpdb;
		$object_type = $this->sanitize_object_type( $object_type );
		$object_id   = absint( $object_id );
		if ( $object_type === '' || $object_id <= 0 ) {
			return [];
		}
		$ids = $wpdb->get_col( $wpdb->prepare( "SELECT term_id FROM {$this->relationship_table()} WHERE object_type = %s AND object_id = %d ORDER BY id ASC", $object_type, $object_id ) );
		return array_values( array_unique( array_filter( array_map( 'absint', (array) $ids ) ) ) );
	}

	public function get_object_terms( string $object_type, int $object_id ): array {
		$terms = [];
		foreach ( $this->get_object_term_ids( $object_type, $object_id ) as $term_id ) {
			$term = $this->get_term( $term_id );
			if ( is_array( $term ) ) {
				$terms[] = $term;
			}
		}
		return $terms;
	}

	public function validate_term_ids( array $term_ids ): array|WP_Error {
		$term_ids    = array_values( array_unique( array_filter( array_map( 'absint', $term_ids ) ) ) );
		$by_taxonomy = [];
		foreach ( $term_ids as $term_id ) {
			$term = $this->get_term( $term_id );
			if ( ! is_array( $term ) || empty( $term['active'] ) ) {
				return new WP_Error( 'kerp_programs_invalid_term_id', __( 'یکی از گزینه‌های انتخاب‌شده معتبر یا فعال نیست.', 'kasebi-erp' ) );
			}
			$taxonomy = $this->get_taxonomy( (int) $term['taxonomy_id'] );
			if ( ! is_array( $taxonomy ) || empty( $taxonomy['active'] ) ) {
				return new WP_Error( 'kerp_programs_inactive_taxonomy', __( 'یکی از گزینه‌های انتخاب‌شده متعلق به دسته‌بندی غیرفعال است.', 'kasebi-erp' ) );
			}
			$by_taxonomy[ (int) $term['taxonomy_id'] ][] = $term_id;
		}
		foreach ( $this->get_taxonomies( TRUE ) as $taxonomy ) {
			$selected = $by_taxonomy[ (int) $taxonomy['id'] ] ?? [];
			if ( ! empty( $taxonomy['required'] ) && empty( $selected ) ) {
				return new WP_Error( 'kerp_programs_required_taxonomy', sprintf( __( 'انتخاب %s الزامی است.', 'kasebi-erp' ), (string) $taxonomy['label'] ) );
			}
			if ( empty( $taxonomy['multiple'] ) && count( $selected ) > 1 ) {
				return new WP_Error( 'kerp_programs_single_taxonomy', sprintf( __( 'برای %s فقط یک گزینه قابل انتخاب است.', 'kasebi-erp' ), (string) $taxonomy['label'] ) );
			}
		}
		return $term_ids;
	}

	public function set_object_terms( string $object_type, int $object_id, array $term_ids ): bool|WP_Error {
		global $wpdb;
		$object_type = $this->sanitize_object_type( $object_type );
		$object_id   = absint( $object_id );
		if ( $object_type === '' || $object_id <= 0 ) {
			return new WP_Error( 'kerp_programs_invalid_term_object', __( 'آیتم مقصد برای اتصال گزینه معتبر نیست.', 'kasebi-erp' ) );
		}
		$validated = $this->validate_term_ids( $term_ids );
		if ( is_wp_error( $validated ) ) {
			return $validated;
		}
		$term_ids = $validated;
		$wpdb->delete( $this->relationship_table(), [ 'object_type' => $object_type, 'object_id' => $object_id ], [ '%s', '%d' ] );
		foreach ( $term_ids as $term_id ) {
			$result = $wpdb->insert( $this->relationship_table(), [ 'object_type' => $object_type, 'object_id' => $object_id, 'term_id' => $term_id ], [ '%s', '%d', '%d' ] );
			if ( $result === FALSE ) {
				return new WP_Error( 'kerp_programs_term_relationship_failed', __( 'اتصال گزینه به آیتم برنامه انجام نشد.', 'kasebi-erp' ) );
			}
		}
		return TRUE;
	}

	public function copy_object_terms( string $from_type, int $from_id, string $to_type, int $to_id ): bool|WP_Error {
		return $this->set_object_terms( $to_type, $to_id, $this->get_object_term_ids( $from_type, $from_id ) );
	}

	public function delete_object_terms( string $object_type, int $object_id ): bool {
		global $wpdb;
		$result = $wpdb->delete( $this->relationship_table(), [ 'object_type' => $this->sanitize_object_type( $object_type ), 'object_id' => absint( $object_id ) ], [ '%s', '%d' ] );
		return $result !== FALSE;
	}

	private function would_create_cycle( int $term_id, int $parent_id ): bool {
		$visited = [];
		$current = $parent_id;
		while ( $current > 0 ) {
			if ( $current === $term_id || isset( $visited[ $current ] ) ) {
				return TRUE;
			}
			$visited[ $current ] = TRUE;
			$term = $this->get_term( $current );
			if ( ! is_array( $term ) ) {
				break;
			}
			$current = absint( $term['parent_id'] ?? 0 );
		}
		return FALSE;
	}

	private function sanitize_object_type( string $object_type ): string {
		$object_type = sanitize_key( $object_type );
		return in_array( $object_type, [ self::OBJECT_TASK, self::OBJECT_TEMPLATE_TASK ], TRUE ) ? $object_type : '';
	}

	private function hydrate_taxonomy( array $row ): array {
		$row['id']           = absint( $row['id'] ?? 0 );
		$row['hierarchical'] = ! empty( $row['hierarchical'] );
		$row['multiple']     = ! empty( $row['multiple'] );
		$row['required']     = ! empty( $row['required'] );
		$row['active']       = ! empty( $row['active'] );
		$row['sort_order']   = intval( $row['sort_order'] ?? 10 );
		return $row;
	}

	private function hydrate_term( array $row ): array {
		$row['id']          = absint( $row['id'] ?? 0 );
		$row['taxonomy_id'] = absint( $row['taxonomy_id'] ?? 0 );
		$row['parent_id']   = absint( $row['parent_id'] ?? 0 );
		$row['active']      = ! empty( $row['active'] );
		$row['sort_order']  = intval( $row['sort_order'] ?? 10 );
		return $row;
	}
}
