<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Programs_Dashboard {
	private static ?self $instance = NULL;
	public static function instance(): self { if ( self::$instance === NULL ) { self::$instance = new self(); } return self::$instance; }
	private function __construct() {}
	private function __clone() {}
	public function __wakeup(): void { throw new LogicException( 'Cannot unserialize a singleton.' ); }

	public function get_data(): array {
		global $wpdb;
		$today = current_time( 'Y-m-d' );
		$timestamp = strtotime( $today . ' 12:00:00' );
		$week_start = date( 'Y-m-d', strtotime( '-' . ( ( (int) date( 'w', $timestamp ) + 1 ) % 7 ) . ' days', $timestamp ) );
		$week_end = date( 'Y-m-d', strtotime( '+6 days', strtotime( $week_start . ' 12:00:00' ) ) );
		$scope = kerp_list_scope( 'programs' );
		if ( $scope === 'none' ) { return $this->empty_data( $week_start, $week_end ); }
		$scope_sql = ''; $scope_args = [];
		if ( $scope === 'own' ) { $scope_sql = ' AND p.employee_id=%d'; $scope_args[] = get_current_user_id(); }
		$plan_args = array_merge( [ $week_start, $week_end ], $scope_args );
		$plan_row = $wpdb->get_row( $wpdb->prepare(
			"SELECT COUNT(*) plans, COUNT(DISTINCT p.customer_id) customers, SUM(p.status='published') published
			 FROM {$wpdb->prefix}kerp_program_daily_plans p WHERE p.plan_date BETWEEN %s AND %s AND p.status<>'archived'{$scope_sql}", $plan_args
		), ARRAY_A );
		$task_args = array_merge( [ $week_start, $week_end ], $scope_args );
		$task_row = $wpdb->get_row( $wpdb->prepare(
			"SELECT COUNT(DISTINCT t.id) tasks, COUNT(DISTINCT r.id) results
			 FROM {$wpdb->prefix}kerp_program_daily_plans p
			 INNER JOIN {$wpdb->prefix}kerp_program_daily_tasks t ON t.plan_id=p.id AND t.status IN ('active','completed')
			 LEFT JOIN {$wpdb->prefix}kerp_program_results r ON r.task_id=t.id
			 WHERE p.plan_date BETWEEN %s AND %s AND p.status<>'archived'{$scope_sql}", $task_args
		), ARRAY_A );
		$comment_args = array_merge( [ $week_start, $week_end ], $scope_args );
		$comments = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(c.id) FROM {$wpdb->prefix}kerp_program_comments c INNER JOIN {$wpdb->prefix}kerp_program_daily_plans p ON p.id=c.plan_id WHERE p.plan_date BETWEEN %s AND %s AND p.status<>'archived'{$scope_sql}", $comment_args
		) );
		$recent = KERP_Modules_Programs_Plans::instance()->find( [ 'date_from' => $week_start, 'date_to' => $week_end, 'per_page' => 6, 'order' => 'DESC' ] );
		$tasks = absint( $task_row['tasks'] ?? 0 ); $results = absint( $task_row['results'] ?? 0 );
		return [
			'week_start' => $week_start, 'week_end' => $week_end,
			'plans' => absint( $plan_row['plans'] ?? 0 ), 'published' => absint( $plan_row['published'] ?? 0 ),
			'customers' => absint( $plan_row['customers'] ?? 0 ), 'tasks' => $tasks, 'results' => $results,
			'comments' => $comments, 'completion' => $tasks > 0 ? round( $results / $tasks * 100, 1 ) : 0,
			'recent' => (array) ( $recent['items'] ?? [] ),
		];
	}

	private function empty_data( string $from, string $to ): array { return [ 'week_start' => $from, 'week_end' => $to, 'plans' => 0, 'published' => 0, 'customers' => 0, 'tasks' => 0, 'results' => 0, 'comments' => 0, 'completion' => 0, 'recent' => [] ]; }
}
