<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Programs_Installer {
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public function install(): void {
		global $wpdb;
		
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		
		$charset_collate = $wpdb->get_charset_collate();
		$prefix          = $wpdb->prefix;
		
		$sql   = [];
		$sql[] = "CREATE TABLE {$prefix}kerp_meta (
			meta_id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			object_type varchar(64) NOT NULL,
			object_id bigint(20) unsigned NOT NULL,
			meta_key varchar(191) NOT NULL,
			meta_value longtext NULL,
			PRIMARY KEY  (meta_id),
			KEY object_lookup (object_type,object_id),
			KEY meta_key (meta_key(191)),
			KEY object_meta (object_type,object_id,meta_key(128))
		) {$charset_collate};";
		
		$sql[] = "CREATE TABLE {$prefix}kerp_program_templates (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			title varchar(191) NOT NULL,
			description longtext NULL,
			status varchar(20) NOT NULL DEFAULT 'active',
			day_count int(10) unsigned NOT NULL DEFAULT 1,
			created_by bigint(20) unsigned NOT NULL DEFAULT 0,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY status (status),
			KEY created_by (created_by)
		) {$charset_collate};";
		
		$sql[] = "CREATE TABLE {$prefix}kerp_program_template_days (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			template_id bigint(20) unsigned NOT NULL,
			day_number int(10) unsigned NOT NULL,
			title varchar(191) NOT NULL DEFAULT '',
			description longtext NULL,
			sort_order int(11) NOT NULL DEFAULT 10,
			PRIMARY KEY  (id),
			UNIQUE KEY template_day (template_id,day_number),
			KEY template_id (template_id),
			KEY sort_order (sort_order)
		) {$charset_collate};";
		
		$sql[] = "CREATE TABLE {$prefix}kerp_program_task_types (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			type_key varchar(100) NOT NULL,
			label varchar(191) NOT NULL,
			description longtext NULL,
			primary_value_type varchar(30) NOT NULL DEFAULT 'number',
			icon varchar(191) NOT NULL DEFAULT 'ni ni-check-circle',
			active tinyint(1) unsigned NOT NULL DEFAULT 1,
			system tinyint(1) unsigned NOT NULL DEFAULT 0,
			sort_order int(11) NOT NULL DEFAULT 10,
			PRIMARY KEY  (id),
			UNIQUE KEY type_key (type_key),
			KEY active (active),
			KEY sort_order (sort_order)
		) {$charset_collate};";
		
		$sql[] = "CREATE TABLE {$prefix}kerp_program_units (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			unit_key varchar(100) NOT NULL,
			label varchar(191) NOT NULL,
			symbol varchar(50) NOT NULL DEFAULT '',
			value_type varchar(30) NOT NULL DEFAULT 'number',
			decimal_allowed tinyint(1) unsigned NOT NULL DEFAULT 0,
			decimals tinyint(3) unsigned NOT NULL DEFAULT 0,
			active tinyint(1) unsigned NOT NULL DEFAULT 1,
			system tinyint(1) unsigned NOT NULL DEFAULT 0,
			sort_order int(11) NOT NULL DEFAULT 10,
			PRIMARY KEY  (id),
			UNIQUE KEY unit_key (unit_key),
			KEY active (active),
			KEY sort_order (sort_order)
		) {$charset_collate};";
		
		$sql[] = "CREATE TABLE {$prefix}kerp_program_taxonomies (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			taxonomy_key varchar(100) NOT NULL,
			label varchar(191) NOT NULL,
			plural_label varchar(191) NOT NULL,
			description text NULL,
			hierarchical tinyint(1) unsigned NOT NULL DEFAULT 0,
			multiple tinyint(1) unsigned NOT NULL DEFAULT 0,
			required tinyint(1) unsigned NOT NULL DEFAULT 0,
			active tinyint(1) unsigned NOT NULL DEFAULT 1,
			sort_order int(11) NOT NULL DEFAULT 10,
			PRIMARY KEY  (id),
			UNIQUE KEY taxonomy_key (taxonomy_key),
			KEY active (active),
			KEY sort_order (sort_order)
		) {$charset_collate};";
		
		$sql[] = "CREATE TABLE {$prefix}kerp_program_terms (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			taxonomy_id bigint(20) unsigned NOT NULL,
			parent_id bigint(20) unsigned NOT NULL DEFAULT 0,
			name varchar(191) NOT NULL,
			slug varchar(191) NOT NULL,
			description text NULL,
			active tinyint(1) unsigned NOT NULL DEFAULT 1,
			sort_order int(11) NOT NULL DEFAULT 10,
			PRIMARY KEY  (id),
			UNIQUE KEY taxonomy_slug (taxonomy_id,slug),
			KEY taxonomy_id (taxonomy_id),
			KEY parent_id (parent_id),
			KEY active (active)
		) {$charset_collate};";
		
		$sql[] = "CREATE TABLE {$prefix}kerp_program_template_tasks (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			template_day_id bigint(20) unsigned NOT NULL,
			task_type_id bigint(20) unsigned NOT NULL DEFAULT 0,
			unit_id bigint(20) unsigned NOT NULL DEFAULT 0,
			title varchar(191) NOT NULL,
			description longtext NULL,
			target_value decimal(20,6) NULL,
			target_text longtext NULL,
			is_required tinyint(1) unsigned NOT NULL DEFAULT 1,
			status varchar(20) NOT NULL DEFAULT 'active',
			sort_order int(11) NOT NULL DEFAULT 10,
			PRIMARY KEY  (id),
			KEY template_day_id (template_day_id),
			KEY task_type_id (task_type_id),
			KEY unit_id (unit_id),
			KEY status (status),
			KEY sort_order (sort_order)
		) {$charset_collate};";
		
		$sql[] = "CREATE TABLE {$prefix}kerp_program_daily_plans (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			customer_id bigint(20) unsigned NOT NULL,
			plan_date date NOT NULL,
			source_template_id bigint(20) unsigned NOT NULL DEFAULT 0,
			employee_id bigint(20) unsigned NOT NULL DEFAULT 0,
			title varchar(191) NOT NULL DEFAULT '',
			description longtext NULL,
			status varchar(20) NOT NULL DEFAULT 'draft',
			created_by bigint(20) unsigned NOT NULL DEFAULT 0,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY customer_date (customer_id,plan_date),
			KEY customer_id (customer_id),
			KEY plan_date (plan_date),
			KEY status (status),
			KEY employee_id (employee_id),
			KEY source_template_id (source_template_id)
		) {$charset_collate};";
		
		$sql[] = "CREATE TABLE {$prefix}kerp_program_daily_tasks (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			plan_id bigint(20) unsigned NOT NULL,
			source_template_task_id bigint(20) unsigned NOT NULL DEFAULT 0,
			task_type_id bigint(20) unsigned NOT NULL DEFAULT 0,
			unit_id bigint(20) unsigned NOT NULL DEFAULT 0,
			title varchar(191) NOT NULL,
			description longtext NULL,
			target_value decimal(20,6) NULL,
			target_text longtext NULL,
			is_required tinyint(1) unsigned NOT NULL DEFAULT 1,
			status varchar(20) NOT NULL DEFAULT 'active',
			sort_order int(11) NOT NULL DEFAULT 10,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY plan_id (plan_id),
			KEY source_template (plan_id,source_template_task_id),
			KEY task_type_id (task_type_id),
			KEY unit_id (unit_id),
			KEY status (status),
			KEY sort_order (sort_order)
		) {$charset_collate};";

		$sql[] = "CREATE TABLE {$prefix}kerp_program_comments (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			plan_id bigint(20) unsigned NOT NULL,
			content longtext NOT NULL,
			visible_to_user tinyint(1) unsigned NOT NULL DEFAULT 0,
			content_format varchar(10) NOT NULL DEFAULT 'text',
			created_by bigint(20) unsigned NOT NULL,
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY plan_id (plan_id),
			KEY created_by (created_by),
			KEY created_at (created_at)
		) {$charset_collate};";

		$sql[] = "CREATE TABLE {$prefix}kerp_program_task_resources (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			task_id bigint(20) unsigned NOT NULL,
			type_key varchar(50) NOT NULL DEFAULT 'link',
			title varchar(191) NOT NULL,
			resource_url text NOT NULL,
			reference_id bigint(20) unsigned NOT NULL DEFAULT 0,
			description longtext NULL,
			sort_order int(11) NOT NULL DEFAULT 10,
			created_by bigint(20) unsigned NOT NULL DEFAULT 0,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY task_id (task_id),
			KEY type_key (type_key),
			KEY reference_id (reference_id),
			KEY sort_order (sort_order)
		) {$charset_collate};";
		
		$sql[] = "CREATE TABLE {$prefix}kerp_program_term_relationships (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			object_type varchar(64) NOT NULL,
			object_id bigint(20) unsigned NOT NULL,
			term_id bigint(20) unsigned NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY object_term (object_type,object_id,term_id),
			KEY object_lookup (object_type,object_id),
			KEY term_id (term_id)
		) {$charset_collate};";
		
		$sql[] = "CREATE TABLE {$prefix}kerp_program_results (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			task_id bigint(20) unsigned NOT NULL,
			customer_id bigint(20) unsigned NOT NULL,
			value_decimal decimal(20,6) NULL,
			value_text longtext NULL,
			status varchar(30) NOT NULL DEFAULT 'submitted',
			created_by bigint(20) unsigned NOT NULL DEFAULT 0,
			submitted_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY task_result (task_id),
			KEY customer_id (customer_id),
			KEY status (status),
			KEY submitted_at (submitted_at)
		) {$charset_collate};";
		
		$sql[] = "CREATE TABLE {$prefix}kerp_program_reviews (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			result_id bigint(20) unsigned NOT NULL,
			reviewer_id bigint(20) unsigned NOT NULL,
			status varchar(30) NOT NULL DEFAULT 'pending',
			score decimal(10,2) NULL,
			public_note longtext NULL,
			private_note longtext NULL,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY result_review (result_id),
			KEY reviewer_id (reviewer_id),
			KEY status (status)
		) {$charset_collate};";
		
		foreach ( $sql as $statement ) {
			dbDelta( $statement );
		}
		
		$this->seed_defaults();
	}
	
	private function seed_defaults(): void {
		KERP_Modules_Programs_Types::instance()->seed_defaults();
		KERP_Modules_Programs_Units::instance()->seed_defaults();
	}
	
}
