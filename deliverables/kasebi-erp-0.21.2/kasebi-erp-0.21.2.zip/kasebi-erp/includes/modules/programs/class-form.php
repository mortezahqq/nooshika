<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Programs_Form {
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public function render_modals(): void {
		if ( kerp_can( 'programs.create', 'action' ) || kerp_can( 'programs.edit', 'action' ) ) {
			KERP_Helpers_Template::render_template( 'modules/programs/modals/plan-form.php', [
				'employee_options' => $this->get_employee_options(),
			] );
			KERP_Helpers_Template::render_template( 'modules/programs/modals/task-form.php', [
				'type_options'    => KERP_Modules_Programs_Types::instance()->get_options(),
				'unit_options'    => KERP_Modules_Programs_Units::instance()->get_options(),
				'taxonomy_groups' => KERP_Modules_Programs_Taxonomies::instance()->get_grouped_terms(),
			] );
			KERP_Helpers_Template::render_template( 'modules/programs/modals/comment-form.php' );
			KERP_Helpers_Template::render_template( 'modules/programs/modals/resource-form.php', [
				'type_options' => KERP_Modules_Programs_Resources::instance()->get_type_options(),
			] );
		}
		if ( kerp_can( 'programs.create', 'action' ) ) {
			KERP_Helpers_Template::render_template( 'modules/programs/modals/template-load-form.php', [
				'template_options' => KERP_Modules_Programs_Templates::instance()->get_options(),
				'employee_options' => $this->get_employee_options(),
			] );
		}
		if ( kerp_can( 'programs.templates.manage', 'action' ) ) {
			KERP_Helpers_Template::render_template( 'modules/programs/modals/template-form.php' );
			KERP_Helpers_Template::render_template( 'modules/programs/modals/template-day-form.php' );
			KERP_Helpers_Template::render_template( 'modules/programs/modals/template-task-form.php', [
				'type_options'    => KERP_Modules_Programs_Types::instance()->get_options(),
				'unit_options'    => KERP_Modules_Programs_Units::instance()->get_options(),
				'taxonomy_groups' => KERP_Modules_Programs_Taxonomies::instance()->get_grouped_terms(),
			] );
		}
		if ( kerp_can( 'programs.results.edit', 'action' ) ) {
			KERP_Helpers_Template::render_template( 'modules/programs/modals/result-form.php' );
		}
		if ( kerp_can( 'programs.results.review', 'action' ) ) {
			KERP_Helpers_Template::render_template( 'modules/programs/modals/review-form.php' );
		}
		if ( kerp_can( 'programs.types.manage', 'action' ) ) {
			KERP_Helpers_Template::render_template( 'modules/programs/modals/type-form.php' );
		}
		if ( kerp_can( 'programs.units.manage', 'action' ) ) {
			KERP_Helpers_Template::render_template( 'modules/programs/modals/unit-form.php' );
		}
		if ( kerp_can( 'programs.taxonomies.manage', 'action' ) ) {
			KERP_Helpers_Template::render_template( 'modules/programs/modals/taxonomy-form.php' );
			foreach ( KERP_Modules_Programs_Taxonomies::instance()->get_taxonomies( FALSE ) as $taxonomy ) {
				KERP_Helpers_Template::render_template( 'modules/programs/modals/term-form.php', [
					'taxonomy'       => $taxonomy,
					'parent_options' => KERP_Modules_Programs_Taxonomies::instance()
					                                                    ->get_term_options( (int) $taxonomy['id'] ),
				] );
			}
		}
	}
	
	public function get_employee_options(): array {
		if ( ! class_exists( 'KERP_Modules_Employees_Query' ) ) {
			return [];
		}
		$options = KERP_Modules_Employees_Query::instance()->get_options( 0, TRUE );
		$options = is_array( $options ) ? $options : [];
		$scope   = kerp_list_scope( 'programs' );
		if ( $scope === 'none' ) {
			return [];
		}
		if ( $scope === 'own' ) {
			$user_id = get_current_user_id();
			
			return isset( $options[ $user_id ] ) ? [ $user_id => $options[ $user_id ] ] : [];
		}
		
		return $options;
	}
	
	public function get_taxonomy_fields( string $id_prefix = 'kerp-program-task', bool $enhance_hierarchical_multiple = FALSE ): array {
		$fields = [];
		foreach ( KERP_Modules_Programs_Taxonomies::instance()->get_grouped_terms() as $group ) {
			$taxonomy    = isset( $group['taxonomy'] ) && is_array( $group['taxonomy'] ) ? $group['taxonomy'] : [];
			$terms       = isset( $group['terms'] ) && is_array( $group['terms'] ) ? $group['terms'] : [];
			$taxonomy_id = absint( $taxonomy['id'] ?? 0 );
			if ( $taxonomy_id <= 0 || empty( $terms ) ) {
				continue;
			}
			$options = [];
			foreach ( $terms as $term ) {
				$term_id = absint( $term['id'] ?? 0 );
				if ( $term_id > 0 ) {
					$options[ $term_id ] = (string) ( $term['name'] ?? '' );
				}
			}
			if ( empty( $options ) ) {
				continue;
			}
			$is_tree_picker = $enhance_hierarchical_multiple && ! empty( $taxonomy['hierarchical'] ) && ! empty( $taxonomy['multiple'] );
			$fields[] = [
				'id'          => $id_prefix . '-taxonomy-' . $taxonomy_id,
				'name'        => 'terms[' . $taxonomy_id . ']' . ( ! empty( $taxonomy['multiple'] ) ? '[]' : '' ),
				'label'       => (string) ( $taxonomy['plural_label'] ?? $taxonomy['label'] ?? __( 'دسته‌بندی', 'kasebi-erp' ) ),
				'type'        => $is_tree_picker ? 'taxonomy-tree' : 'select',
				'class'       => $is_tree_picker ? 'col-12' : 'col-md-6',
				'input_class' => ! empty( $taxonomy['multiple'] ) ? 'form-select select2' : '',
				'options'     => $options,
				'terms'       => $is_tree_picker ? $terms : [],
				'taxonomy_id' => $taxonomy_id,
				'value'       => ! empty( $taxonomy['multiple'] ) ? [] : '',
				'multiple'    => ! empty( $taxonomy['multiple'] ),
				'required'    => ! empty( $taxonomy['required'] ),
				'placeholder' => sprintf(
					__( 'انتخاب %s', 'kasebi-erp' ),
					(string) ( $taxonomy['label'] ?? '' )
				),
			];
		}
		
		return $fields;
	}
	
	public function flatten_term_groups( mixed $terms ): array {
		if ( ! is_array( $terms ) ) {
			return [];
		}
		$term_ids = [];
		foreach ( $terms as $value ) {
			if ( is_array( $value ) ) {
				foreach ( $value as $term_id ) {
					$term_ids[] = absint( $term_id );
				}
			} else {
				$term_ids[] = absint( $value );
			}
		}
		
		return array_values( array_unique( array_filter( $term_ids ) ) );
	}
	
	public function sanitize_meta_json( string $json ): array|WP_Error {
		$json = trim( $json );
		if ( $json === '' ) {
			return [];
		}
		$decoded = json_decode( wp_unslash( $json ), TRUE );
		if ( ! is_array( $decoded ) || json_last_error() !== JSON_ERROR_NONE ) {
			return new WP_Error( 'kerp_programs_invalid_json', __( 'ساختار JSON معتبر نیست.', 'kasebi-erp' ) );
		}
		
		return $decoded;
	}
	
}
