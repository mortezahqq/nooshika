<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Programs_Public {
	
	public const SHORTCODE        = 'kerp_my_programs';
	
	public const PANEL_PAGE       = 'my-programs';
	
	public const AJAX_SAVE_RESULT = 'programs_public_save_result';
	public const AJAX_LEARNDASH_CONTENT = 'programs_public_learndash_content';
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {
		add_filter( 'kerp_panel_navigation_pages', [ $this, 'register_panel_navigation_settings' ] );
		add_shortcode( self::SHORTCODE, [ $this, 'render_shortcode' ] );
		add_filter( 'nooshika_panel_pages_list_final', [ $this, 'register_panel_pages' ], 10, 2 );
		add_filter( 'nooshika_panel_get_template_path', [ $this, 'filter_panel_template_path' ], 10, 3 );
		add_action( 'wp_enqueue_scripts', [ $this, 'register_assets' ], 5 );
		add_action( 'wp_enqueue_scripts', [ $this, 'maybe_enqueue_assets' ], 40 );
		add_action( 'kasebi_ajax_' . self::AJAX_SAVE_RESULT, [ $this, 'ajax_save_result' ] );
		add_action( 'kasebi_ajax_' . self::AJAX_LEARNDASH_CONTENT, [ $this, 'ajax_learndash_content' ] );
		add_action( 'nooshika_ajax_custom_upload_file', [ $this, 'custom_upload_file' ] );
	}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public function register_panel_pages( array $pages, array $defaults = [] ): array {
		$pages[ self::PANEL_PAGE ] = [
			'label' => __( 'برنامه‌های من', 'kasebi-erp' ),
			'icon'  => 'uik fa-calendar icon',
		];
		
		return $pages;
	}
	
	public function filter_panel_template_path( string $file_path, string $path, array $args = [] ): string {
		if (
			$path !== 'pages/' . self::PANEL_PAGE ||
			( $args['current'] ?? '' ) !== self::PANEL_PAGE
		) {
			return $file_path;
		}
		
		return KERP_TEMPLATES_PATH . 'modules/programs/panel/my-programs.php';
	}
	
	public function register_assets(): void {
		wp_register_script( 'kerp-numeric-inputs', KERP_ASSETS_URL . 'shared/js/numeric-inputs.js', [], kerp_asset_version( 'shared/js/numeric-inputs.js' ), TRUE );
		wp_register_style(
			'kerp-programs-panel',
			KERP_ASSETS_URL . 'public/css/programs-panel.css',
			[],
			kerp_asset_version( 'public/css/programs-panel.css' )
		);
		
		wp_register_script(
			'kerp-programs-panel',
			KERP_ASSETS_URL . 'public/js/programs-panel.js',
			[ 'jquery', 'kerp-numeric-inputs' ],
			kerp_asset_version( 'public/js/programs-panel.js' ),
			TRUE
		);
	}
	
	public function maybe_enqueue_assets(): void {
		if ( ! $this->is_panel_request() ) {
			return;
		}
		
		$this->enqueue_assets();
	}
	
	public function render_shortcode( array $atts = [] ): string {
		$this->enqueue_assets();
		
		if ( ! is_user_logged_in() ) {
			return KERP_Helpers_Template::get_template(
				'modules/programs/public/my-programs.php',
				[
					'calendar'    => [],
					'day_context' => [],
				]
			);
		}
		
		$day = isset( $_REQUEST['day'] )
			? KERP_Modules_Programs_Plans::instance()->normalize_date(
				sanitize_text_field(
					wp_unslash(
						(string) $_REQUEST['day']
					)
				)
			)
			: '';
		
		if ( $day !== '' ) {
			return KERP_Helpers_Template::get_template(
				'modules/programs/public/my-programs.php',
				[
					'calendar'    => [],
					'day_context' => $this->get_day_context( $day ),
				]
			);
		}
		
		$view = isset( $_REQUEST['view'] ) ? sanitize_key( wp_unslash( (string) $_REQUEST['view'] ) ) : 'week';
		$view = in_array( $view, [ 'week', 'month' ], TRUE ) ? $view : 'week';

		$month = isset( $_REQUEST['month'] )
			? $this->normalize_jalali_month(
				sanitize_text_field(
					wp_unslash(
						(string) $_REQUEST['month']
					)
				)
			)
			: '';
		
		if ( $month === '' ) {
			$month = $this->get_current_jalali_month();
		}
		
		$calendar = $view === 'month'
			? $this->get_calendar_context( $month )
			: $this->get_week_calendar_context( isset( $_REQUEST['week'] ) ? sanitize_text_field( wp_unslash( (string) $_REQUEST['week'] ) ) : current_time( 'Y-m-d' ) );
		$summary = KERP_Modules_Programs_Overview::instance()->public_summary(
			get_current_user_id(),
			(string) ( $calendar['date_from'] ?? current_time( 'Y-m-d' ) ),
			(string) ( $calendar['date_to'] ?? current_time( 'Y-m-d' ) )
		);

		return KERP_Helpers_Template::get_template(
			'modules/programs/public/my-programs.php',
			[
				'calendar'    => $calendar,
				'day_context' => [],
				'summary'     => $summary,
			]
		);
	}

	private function get_week_range(): array {
		$today = current_time( 'Y-m-d' );
		$timestamp = strtotime( $today . ' 12:00:00' );
		$offset = ( (int) date( 'w', $timestamp ) + 1 ) % 7;
		$from = date( 'Y-m-d', strtotime( '-' . $offset . ' days', $timestamp ) );
		return [ 'date_from' => $from, 'date_to' => date( 'Y-m-d', strtotime( '+6 days', strtotime( $from . ' 12:00:00' ) ) ) ];
	}
	
	public function ajax_save_result(): void {
		$this->verify_public_nonce();
		
		if ( ! is_user_logged_in() ) {
			$this->json_error(
				__( 'برای ثبت گزارش باید وارد حساب کاربری شوید.', 'kasebi-erp' )
			);
		}
		
		$user_id = get_current_user_id();
		$task_id = absint( $_POST['task_id'] ?? 0 );
		
		/*
		 * مهم:
		 * Task باید حتماً متعلق به خود کاربر باشد.
		 */
		$task = $this->get_public_task(
			$task_id,
			$user_id
		);
		
		if ( ! is_array( $task ) ) {
			$this->json_error(
				__( 'این فعالیت برای حساب کاربری شما معتبر نیست.', 'kasebi-erp' )
			);
		}
		
		/*
		 * نوع فعالیت.
		 */
		$type = KERP_Modules_Programs_Types::instance()->get(
			absint( $task['task_type_id'] ?? 0 )
		);
		
		if ( ! is_array( $type ) ) {
			$this->json_error(
				__( 'نوع فعالیت معتبر نیست.', 'kasebi-erp' )
			);
		}
		
		$type_key = sanitize_key(
			(string) ( $type['type_key'] ?? '' )
		);
		
		$value_type = sanitize_key(
			(string) ( $type['primary_value_type'] ?? '' )
		);
		
		$numeric_types = [
			'number',
			'duration',
			'score',
		];
		
		$value_decimal = NULL;
		
		/*
		 * مقدار واقعی فقط برای Typeهای عددی.
		 */
		if ( in_array( $value_type, $numeric_types, TRUE ) ) {
			$raw_value = isset( $_POST['value_decimal'] )
				? wp_unslash( (string) $_POST['value_decimal'] )
				: '';
			
			$clean = KERP_Helpers_Format::sanitize_numbers(
				trim( $raw_value )
			);
			
			if (
				$clean === '' ||
				! is_numeric( $clean )
			) {
				$this->json_error(
					__( 'مقدار انجام‌شده را وارد کنید.', 'kasebi-erp' )
				);
			}
			
			$value_decimal = (float) $clean;
			if ( ! is_finite( $value_decimal ) || $value_decimal < 0 || ( $type_key === 'test' && floor( $value_decimal ) !== $value_decimal ) ) {
				$this->json_error( __( 'مقدار انجام‌شده باید عددی نامنفی باشد؛ تعداد تست باید عدد صحیح باشد.', 'kasebi-erp' ) );
			}
		}
		
		/*
		 * زمان شروع / پایان.
		 */
		$started_at = $this->sanitize_time(
			$_POST['started_at'] ?? ''
		);
		
		$ended_at = $this->sanitize_time(
			$_POST['ended_at'] ?? ''
		);
		
		if ( is_wp_error( $started_at ) ) {
			$this->json_error(
				$started_at->get_error_message()
			);
		}
		
		if ( is_wp_error( $ended_at ) ) {
			$this->json_error(
				$ended_at->get_error_message()
			);
		}
		
		/*
		 * زمان مفید.
		 */
		$effective_minutes_raw = isset( $_POST['effective_minutes'] )
			? KERP_Helpers_Format::sanitize_numbers(
				wp_unslash(
					(string) $_POST['effective_minutes']
				)
			)
			: '';
		
		if ( $effective_minutes_raw !== '' && ! ctype_digit( $effective_minutes_raw ) ) {
			$this->json_error( __( 'زمان مفید را به دقیقه و به صورت عدد صحیح نامنفی وارد کنید.', 'kasebi-erp' ) );
		}
		$effective_minutes = $effective_minutes_raw === ''
			? ''
			: absint( $effective_minutes_raw );
		
		/*
		 * Metaهای اختصاصی Type.
		 */
		$correct_count = '';
		$wrong_count   = '';
		$blank_count   = '';
		$progress_from = '';
		$progress_to   = '';
		
		/*
		 * Test
		 *
		 * کاربر:
		 * - تعداد کل انجام‌شده
		 * - صحیح
		 * - نزده
		 *
		 * غلط محاسبه می‌شود.
		 */
		if ( $type_key === 'test' ) {
			foreach ( [ 'correct_count', 'blank_count' ] as $count_key ) {
				$count_value = $_POST[ $count_key ] ?? '';
				if ( ! is_scalar( $count_value ) || ( $count_value !== '' && ! ctype_digit( KERP_Helpers_Format::sanitize_numbers( wp_unslash( (string) $count_value ) ) ) ) ) {
					$this->json_error( __( 'تعداد صحیح و نزده باید عدد صحیح نامنفی باشد.', 'kasebi-erp' ) );
				}
			}
			$correct_count = absint(
				KERP_Helpers_Format::sanitize_numbers(
					wp_unslash(
						(string) (
							$_POST['correct_count']
							?? ''
						)
					)
				)
			);
			
			$blank_count = absint(
				KERP_Helpers_Format::sanitize_numbers(
					wp_unslash(
						(string) (
							$_POST['blank_count']
							?? '0'
						)
					)
				)
			);
			
			$total_count = $value_decimal !== NULL
				? (int) floor( (float) $value_decimal )
				: 0;
			
			if ( $total_count <= 0 ) {
				$this->json_error(
					__( 'تعداد تست‌های انجام‌شده معتبر نیست.', 'kasebi-erp' )
				);
			}
			
			if ( $correct_count + $blank_count > $total_count ) {
				$this->json_error(
					__(
						'مجموع تعداد صحیح و نزده نمی‌تواند بیشتر از تعداد تست‌های انجام‌شده باشد.',
						'kasebi-erp'
					)
				);
			}
			
			$wrong_count = max(
				0,
				$total_count
				- $correct_count
				- $blank_count
			);
		}
		
		/*
		 * Study
		 */
		if ( $type_key === 'study' ) {
			$progress_from = sanitize_text_field(
				wp_unslash(
					(string) (
						$_POST['progress_from']
						?? ''
					)
				)
			);
			
			$progress_to = sanitize_text_field(
				wp_unslash(
					(string) (
						$_POST['progress_to']
						?? ''
					)
				)
			);
		}
		
		if ( $type_key === 'study' ) {
			$existing = KERP_Modules_Programs_Results::instance()->get_by_task( $task_id );
			foreach ( [ 'progress_from', 'progress_to' ] as $key ) {
				$value = KERP_Helpers_Format::sanitize_numbers( ${$key} );
				if ( $value === '' || ctype_digit( $value ) ) {
					${$key} = $value;
					continue;
				}
				$previous = is_array( $existing ) ? (string) KERP_Helpers_Meta::instance()->get_result_meta( (int) $existing['id'], $key, TRUE ) : '';
				if ( ${$key} !== $previous ) {
					$this->json_error( __( 'بازه مطالعه را فقط با شماره وارد کنید؛ توضیحات را در بخش گزارش بنویسید.', 'kasebi-erp' ) );
				}
			}
			if ( ctype_digit( $progress_from ) && ctype_digit( $progress_to ) && (float) $progress_to < (float) $progress_from ) {
				$this->json_error( __( 'شماره پایان مطالعه نباید کمتر از شماره شروع باشد.', 'kasebi-erp' ) );
			}
		}

		/*
		 * فایل‌ها قبلاً با custom_upload_file آپلود شده‌اند.
		 *
		 * اینجا فقط URLها را دریافت می‌کنیم.
		 */
		$attachments = [];
		
		if (
			isset( $_POST['attachments'] ) &&
			is_array( $_POST['attachments'] )
		) {
			foreach ( wp_unslash( $_POST['attachments'] ) as $attachment ) {
				$attachment = esc_url_raw(
					trim( (string) $attachment )
				);
				
				if ( $attachment === '' ) {
					continue;
				}
				
				$attachments[] = $attachment;
			}
		}
		
		$attachments = array_values(
			array_unique(
				$attachments
			)
		);
		
		if ( count( $attachments ) > 5 ) {
			$this->json_error(
				__(
					'حداکثر ۵ فایل می‌توانید برای هر گزارش ثبت کنید.',
					'kasebi-erp'
				)
			);
		}
		
		/*
		 * Result را فقط از روی Task پیدا می‌کنیم.
		 *
		 * result_id ارسالی Front قابل اعتماد نیست.
		 */
		$results = KERP_Modules_Programs_Results::instance();
		
		$existing_result = $results->get_by_task(
			$task_id
		);
		
		$result_id = is_array( $existing_result )
			? absint( $existing_result['id'] ?? 0 )
			: 0;
		
		/*
		 * داده Result.
		 */
		$data = [
			'task_id'       => $task_id,
			'value_decimal' => $value_decimal,
			
			'value_text' => wp_kses_post(
				wp_unslash(
					(string) (
						$_POST['value_text']
						?? ''
					)
				)
			),
			
			/*
			 * ثبت یا ویرایش توسط دانش‌آموز
			 * یعنی نیازمند بررسی مجدد.
			 */
			'status'     => 'pending_review',
			
			'meta' => [
				'started_at'        => $started_at,
				'ended_at'          => $ended_at,
				'effective_minutes' => $effective_minutes,
				'correct_count'     => $correct_count,
				'wrong_count'       => $wrong_count,
				'blank_count'       => $blank_count,
				'progress_from'     => $progress_from,
				'progress_to'       => $progress_to,
				'attachment'        => $attachments,
			],
		];
		
		$saved = $results->save(
			$data,
			$result_id
		);
		
		if ( is_wp_error( $saved ) ) {
			$this->json_error(
				$saved->get_error_message()
			);
		}
		
		$saved_result_id = absint( $saved );
		
		/*
		 * اگر قبلاً Review ثبت شده باشد و دانش‌آموز
		 * گزارش را ویرایش کند، Review دوباره Pending شود.
		 */
		$review = method_exists(
			$results,
			'get_review_by_result'
		)
			? $results->get_review_by_result(
				$saved_result_id
			)
			: NULL;
		
		if (
			is_array( $review ) &&
			method_exists(
				$results,
				'review_table'
			)
		) {
			$review_id = absint(
				$review['id'] ?? 0
			);
			
			if ( $review_id > 0 ) {
				global $wpdb;
				
				$wpdb->update(
					$results->review_table(),
					[
						'status'     => 'pending',
						'updated_at' => current_time( 'mysql' ),
					],
					[
						'id' => $review_id,
					],
					[
						'%s',
						'%s',
					],
					[
						'%d',
					]
				);
			}
		}
		
		$this->json_success(
			[
				'result_id' => $saved_result_id,
				
				'message' => $result_id > 0
					? __(
						'گزارش فعالیت با موفقیت به‌روزرسانی شد.',
						'kasebi-erp'
					)
					: __(
						'گزارش فعالیت با موفقیت ثبت شد.',
						'kasebi-erp'
					),
			]
		);
	}

	public function ajax_learndash_content(): void {
		$this->verify_public_nonce();
		if ( ! is_user_logged_in() ) { $this->json_error( __( 'برای مشاهده محتوا وارد حساب کاربری شوید.', 'kasebi-erp' ) ); }
		$resource_id = absint( $_POST['resource_id'] ?? 0 );
		$resource = KERP_Modules_Programs_Resources::instance()->get( $resource_id );
		if ( ! is_array( $resource ) || (string) ( $resource['type_key'] ?? '' ) !== 'learndash' ) { $this->json_error( __( 'محتوای آموزشی پیدا نشد.', 'kasebi-erp' ) ); }
		$task = $this->get_public_task( absint( $resource['task_id'] ?? 0 ), get_current_user_id() );
		if ( ! is_array( $task ) ) { $this->json_error( __( 'شما به این محتوای برنامه دسترسی ندارید.', 'kasebi-erp' ) ); }
		$post_id = absint( $resource['reference_id'] ?? 0 );
		$post = $post_id ? get_post( $post_id ) : NULL;
		if ( ! $post instanceof WP_Post || ! in_array( $post->post_type, [ 'sfwd-lessons', 'sfwd-topic' ], TRUE ) || $post->post_status !== 'publish' ) { $this->json_error( __( 'درس یا سرفصل LearnDash معتبر نیست.', 'kasebi-erp' ) ); }
		if ( ! function_exists( 'learndash_get_course_id' ) || ! function_exists( 'nooshika_panel_get_template' ) ) { $this->json_error( __( 'امکان نمایش محتوای LearnDash در حال حاضر در دسترس نیست.', 'kasebi-erp' ) ); }
		$course_id = absint( learndash_get_course_id( $post_id ) );
		if ( $course_id <= 0 ) { $this->json_error( __( 'دوره مرتبط با این محتوا پیدا نشد.', 'kasebi-erp' ) ); }
		$html = KERP_Helpers_Template::get_template( 'modules/programs/public/learndash-content.php', [ 'course_id' => $course_id, 'post_id' => $post_id ] );
		if ( ! is_string( $html ) || trim( $html ) === '' ) { $this->json_error( __( 'محتوای درس قابل نمایش نیست.', 'kasebi-erp' ) ); }
		$html = preg_replace( '/\b(?:uik(?:-[a-z])?|hik(?:-[a-z])?|kik(?:-[a-z])?|fas|far|fal|fad)\s+(fa-[a-z0-9_-]+)/i', 'uik $1 icon', $html );
		$this->json_success( [ 'html' => $html, 'title' => get_the_title( $post_id ) ] );
	}
	
	private function enqueue_assets(): void {
		if ( ! wp_style_is( 'kerp-programs-panel', 'registered' ) || ! wp_script_is( 'kerp-programs-panel', 'registered' ) ) {
			$this->register_assets();
		}
		
		wp_enqueue_style( 'kerp-programs-panel' );
		wp_enqueue_script( 'kerp-programs-panel' );
		wp_localize_script( 'kerp-programs-panel', 'KERPProgramsPanel', [
			'ajaxUrl'  => home_url( '/' . KERP_Modules_Ajax_Module::ENDPOINT . '/' ),
			'nonce'    => wp_create_nonce( 'ksp_ajax_nonce' ),
			'maxFiles' => 5,
			'i18n'     => [
				'saving'        => __( 'در حال ذخیره گزارش...', 'kasebi-erp' ),
				'saved'         => __( 'گزارش با موفقیت ذخیره شد.', 'kasebi-erp' ),
				'genericError'  => __( 'خطایی رخ داد. دوباره تلاش کنید.', 'kasebi-erp' ),
				'tooManyFiles'  => __( 'حداکثر ۵ فایل می‌توانید برای هر گزارش ثبت کنید.', 'kasebi-erp' ),
				'invalidResult' => __( 'اطلاعات گزارش را کامل کنید.', 'kasebi-erp' ),
			],
		] );
	}
	
	private function is_panel_request(): bool {
		return is_page( 'panel' );
	}
	
	private function get_calendar_context( string $month ): array {
		global $wpdb;
		
		$month = $this->normalize_jalali_month( $month );
		if ( $month === '' ) {
			$month = $this->get_current_jalali_month();
		}
		
		$range = $this->get_jalali_month_range( $month );
		if ( empty( $range ) ) {
			return [];
		}
		
		$plans_table   = KERP_Modules_Programs_Plans::instance()->table_name();
		$tasks_table   = KERP_Modules_Programs_Tasks::instance()->table_name();
		$results_table = KERP_Modules_Programs_Results::instance()->table_name();
		$user_id       = get_current_user_id();
		
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT
					p.plan_date,
					COUNT(t.id) AS task_count,
					SUM(CASE WHEN r.id IS NOT NULL THEN 1 ELSE 0 END) AS done_count,
					SUM(CASE WHEN r.id IS NULL THEN 1 ELSE 0 END) AS pending_count
				FROM {$plans_table} p
				INNER JOIN {$tasks_table} t ON t.plan_id = p.id AND t.status IN ('active','completed')
				LEFT JOIN {$results_table} r ON r.task_id = t.id
				WHERE p.customer_id = %d
					AND p.status = 'published'
					AND p.plan_date BETWEEN %s AND %s
				GROUP BY p.plan_date
				ORDER BY p.plan_date ASC",
				$user_id,
				$range['date_from'],
				$range['date_to']
			),
			ARRAY_A
		);
		
		$counts = [];
		$total  = $done = $pending = 0;
		
		foreach ( (array) $rows as $row ) {
			$date = KERP_Modules_Programs_Plans::instance()->normalize_date( (string) ( $row['plan_date'] ?? '' ) );
			if ( $date === '' ) {
				continue;
			}
			
			$counts[ $date ] = [
				'total'   => absint( $row['task_count'] ?? 0 ),
				'done'    => absint( $row['done_count'] ?? 0 ),
				'pending' => absint( $row['pending_count'] ?? 0 ),
			];
			
			$total   += $counts[ $date ]['total'];
			$done    += $counts[ $date ]['done'];
			$pending += $counts[ $date ]['pending'];
		}
		
		$first_timestamp = strtotime( $range['date_from'] . ' 12:00:00' );
		$days_in_month   = absint( $range['days'] );
		$first_weekday   = $first_timestamp !== FALSE ? ( ( (int) date( 'w', $first_timestamp ) + 1 ) % 7 ) : 0;
		$today           = current_time( 'Y-m-d' );
		$days            = [];
		
		for ( $day = 1; $day <= $days_in_month; $day ++ ) {
			$timestamp = strtotime( $range['date_from'] . ' +' . ( $day - 1 ) . ' days' );
			if ( $timestamp === FALSE ) {
				continue;
			}
			
			$date       = date( 'Y-m-d', $timestamp );
			$day_counts = $counts[ $date ] ?? [ 'total' => 0, 'done' => 0, 'pending' => 0 ];
			
			$days[] = [
				'date'     => $date,
				'day'      => $day,
				'is_today' => $date === $today,
				'total'    => $day_counts['total'],
				'done'     => $day_counts['done'],
				'pending'  => $day_counts['pending'],
				'route'    => $this->panel_day_route( $date ),
			];
		}
		
		return [
			'view'           => 'month',
			'date_from'      => $range['date_from'],
			'date_to'        => $range['date_to'],
			'month'          => $month,
			'month_title'    => $first_timestamp !== FALSE ? date_i18n( 'F Y', $first_timestamp ) : $month,
			'first_weekday'  => $first_weekday,
			'days'           => $days,
			'weekdays'       => [
				__( 'شنبه', 'kasebi-erp' ),
				__( 'یکشنبه', 'kasebi-erp' ),
				__( 'دوشنبه', 'kasebi-erp' ),
				__( 'سه‌شنبه', 'kasebi-erp' ),
				__( 'چهارشنبه', 'kasebi-erp' ),
				__( 'پنجشنبه', 'kasebi-erp' ),
				__( 'جمعه', 'kasebi-erp' ),
			],
			'previous_route' => $this->panel_month_route( $this->shift_jalali_month( $month, - 1 ) ),
			'current_route'  => $this->panel_month_route( $this->get_current_jalali_month() ),
			'next_route'     => $this->panel_month_route( $this->shift_jalali_month( $month, 1 ) ),
			'week_route'     => $this->panel_week_route( $range['date_from'] ),
			'month_route'    => $this->panel_month_route( $month ),
			'total'          => $total,
			'done'           => $done,
			'pending'        => $pending,
		];
	}

	private function get_week_calendar_context( string $anchor ): array {
		global $wpdb;
		$anchor = KERP_Modules_Programs_Plans::instance()->normalize_date( $anchor );
		if ( $anchor === '' ) { $anchor = current_time( 'Y-m-d' ); }
		$stamp = strtotime( $anchor . ' 12:00:00' );
		$offset = ( (int) date( 'w', $stamp ) + 1 ) % 7;
		$from = date( 'Y-m-d', strtotime( '-' . $offset . ' days', $stamp ) );
		$to = date( 'Y-m-d', strtotime( '+6 days', strtotime( $from . ' 12:00:00' ) ) );
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT p.plan_date,COUNT(t.id) task_count,SUM(CASE WHEN r.id IS NOT NULL THEN 1 ELSE 0 END) done_count,SUM(CASE WHEN r.id IS NULL THEN 1 ELSE 0 END) pending_count
			 FROM {$wpdb->prefix}kerp_program_daily_plans p
			 INNER JOIN {$wpdb->prefix}kerp_program_daily_tasks t ON t.plan_id=p.id AND t.status IN ('active','completed')
			 LEFT JOIN {$wpdb->prefix}kerp_program_results r ON r.task_id=t.id
			 WHERE p.customer_id=%d AND p.status='published' AND p.plan_date BETWEEN %s AND %s GROUP BY p.plan_date",
			get_current_user_id(), $from, $to
		), ARRAY_A );
		$counts = []; $total = $done = $pending = 0;
		foreach ( (array) $rows as $row ) { $counts[ $row['plan_date'] ] = [ 'total' => absint( $row['task_count'] ), 'done' => absint( $row['done_count'] ), 'pending' => absint( $row['pending_count'] ) ]; $total += absint( $row['task_count'] ); $done += absint( $row['done_count'] ); $pending += absint( $row['pending_count'] ); }
		$days = []; $today = current_time( 'Y-m-d' );
		for ( $i = 0; $i < 7; $i++ ) { $date = date( 'Y-m-d', strtotime( '+' . $i . ' days', strtotime( $from . ' 12:00:00' ) ) ); $item = $counts[ $date ] ?? [ 'total' => 0, 'done' => 0, 'pending' => 0 ]; $days[] = array_merge( $item, [ 'date' => $date, 'day' => KERP_Helpers_Format::sanitize_numbers( date_i18n( 'j', strtotime( $date . ' 12:00:00' ) ) ), 'is_today' => $date === $today, 'route' => $this->panel_day_route( $date ) . '&back_view=week&week=' . rawurlencode( $from ) ] ); }
		$jalali_month = $this->normalize_jalali_month( KERP_Helpers_Format::sanitize_numbers( date_i18n( 'Y-m', strtotime( $from . ' 12:00:00' ) ) ) );
		return [
			'view' => 'week', 'date_from' => $from, 'date_to' => $to, 'first_weekday' => 0, 'days' => $days,
			'month_title' => sprintf( __( '%1$s تا %2$s', 'kasebi-erp' ), KERP_Modules_Programs_Plans::instance()->display_date( $from ), KERP_Modules_Programs_Plans::instance()->display_date( $to ) ),
			'weekdays' => [ __( 'شنبه', 'kasebi-erp' ), __( 'یکشنبه', 'kasebi-erp' ), __( 'دوشنبه', 'kasebi-erp' ), __( 'سه‌شنبه', 'kasebi-erp' ), __( 'چهارشنبه', 'kasebi-erp' ), __( 'پنجشنبه', 'kasebi-erp' ), __( 'جمعه', 'kasebi-erp' ) ],
			'previous_route' => $this->panel_week_route( date( 'Y-m-d', strtotime( '-7 days', strtotime( $from . ' 12:00:00' ) ) ) ),
			'current_route' => $this->panel_week_route( current_time( 'Y-m-d' ) ), 'next_route' => $this->panel_week_route( date( 'Y-m-d', strtotime( '+7 days', strtotime( $from . ' 12:00:00' ) ) ) ),
			'week_route' => $this->panel_week_route( $from ), 'month_route' => $this->panel_month_route( $jalali_month ), 'total' => $total, 'done' => $done, 'pending' => $pending,
		];
	}
	
	private function get_day_context( string $date ): array {
		global $wpdb;
		
		$date = KERP_Modules_Programs_Plans::instance()->normalize_date( $date );
		if ( $date === '' ) {
			return [];
		}
		
		$plans_table   = KERP_Modules_Programs_Plans::instance()->table_name();
		$tasks_table   = KERP_Modules_Programs_Tasks::instance()->table_name();
		$types_table   = KERP_Modules_Programs_Types::instance()->table_name();
		$units_table   = KERP_Modules_Programs_Units::instance()->table_name();
		$results       = KERP_Modules_Programs_Results::instance();
		$results_table = $results->table_name();
		$reviews_table = $results->review_table();
		$user_id       = get_current_user_id();
		
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT
					t.*,
					p.plan_date,
					p.employee_id,
					tt.type_key,
					tt.label AS type_label,
					tt.primary_value_type,
					tt.icon AS type_icon,
					u.label AS unit_label,
					u.symbol AS unit_symbol,
					r.id AS result_id,
					r.value_decimal AS result_value_decimal,
					r.value_text AS result_value_text,
					r.status AS result_status,
					r.submitted_at AS result_submitted_at,
					r.updated_at AS result_updated_at,
					rv.id AS review_id,
					rv.status AS review_status,
					rv.score AS review_score,
					rv.public_note AS review_public_note,
					rv.updated_at AS review_updated_at
				FROM {$plans_table} p
				INNER JOIN {$tasks_table} t ON t.plan_id = p.id
				LEFT JOIN {$types_table} tt ON tt.id = t.task_type_id
				LEFT JOIN {$units_table} u ON u.id = t.unit_id
				LEFT JOIN {$results_table} r ON r.task_id = t.id
				LEFT JOIN {$reviews_table} rv ON rv.result_id = r.id
				WHERE p.customer_id = %d
					AND p.status = 'published'
					AND p.plan_date = %s
					AND t.status IN ('active','completed')
				ORDER BY t.sort_order ASC, t.id ASC",
				$user_id,
				$date
			),
			ARRAY_A
		);
		
		$tasks = [];
		$done  = 0;
		
		foreach ( (array) $rows as $row ) {
			$task    = $this->prepare_public_task( $row );
			$tasks[] = $task;
			if ( ! empty( $task['has_result'] ) ) {
				$done ++;
			}
		}
		
		$timestamp    = strtotime( $date . ' 12:00:00' );
		$jalali_month = $timestamp !== FALSE
			? $this->normalize_jalali_month( KERP_Helpers_Format::sanitize_numbers( date_i18n( 'Y-m', $timestamp ) ) )
			: '';
		
		if ( $jalali_month === '' ) {
			$jalali_month = $this->get_current_jalali_month();
		}
		$back_view = isset( $_REQUEST['back_view'] ) ? sanitize_key( wp_unslash( (string) $_REQUEST['back_view'] ) ) : 'month';
		$back_week = isset( $_REQUEST['week'] ) ? sanitize_text_field( wp_unslash( (string) $_REQUEST['week'] ) ) : $date;
		
		return [
			'date'          => $date,
			'date_display'  => KERP_Modules_Programs_Plans::instance()->display_date( $date ),
			'weekday'       => $timestamp !== FALSE ? date_i18n( 'l', $timestamp ) : '',
			'tasks'         => $tasks,
			'comments'      => KERP_Modules_Programs_Comments::instance()->get_for_current_user_day( $date ),
			'total'         => count( $tasks ),
			'done'          => $done,
			'pending'       => max( 0, count( $tasks ) - $done ),
			'back_route'    => $back_view === 'week' ? $this->panel_week_route( $back_week ) : $this->panel_month_route( $jalali_month ),
			'current_route' => $this->panel_day_route( $date ),
		];
	}
	
	private function prepare_public_task( array $row ): array {
		$result_id = absint( $row['result_id'] ?? 0 );
		$meta      = $result_id > 0 ? KERP_Helpers_Meta::instance()->get_result_meta( $result_id ) : [];
		$meta      = is_array( $meta ) ? $meta : [];
		$task_meta = KERP_Helpers_Meta::instance()->get_task_meta( absint( $row['id'] ?? 0 ) );
		$task_meta = is_array( $task_meta ) ? $task_meta : [];
		
		$meta_value = static function( string $key ) use ( $meta ): mixed {
			$values = isset( $meta[ $key ] ) && is_array( $meta[ $key ] ) ? $meta[ $key ] : [];
			
			return array_key_exists( 0, $values ) ? $values[0] : '';
		};

		$task_meta_value = static function( string $key ) use ( $task_meta ): mixed {
			$values = isset( $task_meta[ $key ] ) && is_array( $task_meta[ $key ] ) ? $task_meta[ $key ] : [];

			return array_key_exists( 0, $values ) ? $values[0] : '';
		};
		
		$unit_display = trim( (string) ( $row['unit_symbol'] ?? '' ) );
		if ( $unit_display === '' ) {
			$unit_display = trim( (string) ( $row['unit_label'] ?? '' ) );
		}
		
		$target_value = $this->format_decimal( $row['target_value'] ?? '' );
		$result_value = $this->format_decimal( $row['result_value_decimal'] ?? '' );
		$type_key     = sanitize_key( (string) ( $row['type_key'] ?? '' ) );
		$value_type   = sanitize_key( (string) ( $row['primary_value_type'] ?? '' ) );
		$attachments  = $this->normalize_attachments( $meta_value( 'attachment' ) );
		$correct      = absint( $meta_value( 'correct_count' ) );
		$blank        = absint( $meta_value( 'blank_count' ) );
		$wrong_meta   = $meta_value( 'wrong_count' );
		$wrong        = $wrong_meta === '' ? NULL : absint( $wrong_meta );
		
		if ( $type_key === 'test' && $wrong === NULL && $result_value !== '' && is_numeric( $result_value ) ) {
			$wrong = max( 0, absint( $result_value ) - $correct - $blank );
		}
		
		$target_display = $target_value !== ''
			? trim( $target_value . ' ' . $unit_display )
			: __( 'بدون هدف عددی', 'kasebi-erp' );
		
		$result_display = __( 'ثبت نشده', 'kasebi-erp' );
		if ( $result_id > 0 ) {
			if ( $result_value !== '' ) {
				$result_display = trim( $result_value . ' ' . $unit_display );
			} elseif ( $type_key === 'content' ) {
				$result_display = __( 'انجام شده', 'kasebi-erp' );
			} elseif ( trim( (string) ( $row['result_value_text'] ?? '' ) ) !== '' ) {
				$result_display = wp_trim_words( wp_strip_all_tags( (string) $row['result_value_text'] ), 12 );
			} else {
				$result_display = __( 'ثبت شده', 'kasebi-erp' );
			}
		}
		
		$review_status  = sanitize_key( (string) ( $row['review_status'] ?? '' ) );
		$review_options = KERP_Modules_Programs_Settings::instance()->get_review_status_options();
		
		return [
			'id'                => absint( $row['id'] ?? 0 ),
			'title'             => (string) ( $row['title'] ?? '' ),
			'description'       => (string) ( $row['description'] ?? '' ),
			'target_text'       => (string) ( $row['target_text'] ?? '' ),
			'target_value'      => $target_value,
			'target_display'    => $target_display,
			'is_required'       => ! empty( $row['is_required'] ),
			'type_key'          => $type_key,
			'type_label'        => (string) ( $row['type_label'] ?? __( 'فعالیت', 'kasebi-erp' ) ),
			'type_icon'         => (string) ( $row['type_icon'] ?? '' ),
			'value_type'        => $value_type,
			'unit_display'      => $unit_display,
			'has_result'        => $result_id > 0,
			'result_id'         => $result_id,
			'result_value'      => $result_value,
			'result_display'    => $result_display,
			'result_text'       => (string) ( $row['result_value_text'] ?? '' ),
			'result_status'     => sanitize_key( (string) ( $row['result_status'] ?? '' ) ),
			'submitted_at'      => (string) ( $row['result_submitted_at'] ?? '' ),
			'scheduled_start'   => trim( (string) $task_meta_value( 'scheduled_start' ) ),
			'scheduled_end'     => trim( (string) $task_meta_value( 'scheduled_end' ) ),
			'started_at'        => trim( (string) $meta_value( 'started_at' ) ),
			'ended_at'          => trim( (string) $meta_value( 'ended_at' ) ),
			'effective_minutes' => $this->format_decimal( $meta_value( 'effective_minutes' ) ),
			'correct_count'     => $correct,
			'wrong_count'       => $wrong,
			'blank_count'       => $blank,
			'progress_from'     => trim( (string) $meta_value( 'progress_from' ) ),
			'progress_to'       => trim( (string) $meta_value( 'progress_to' ) ),
			'attachments'       => $attachments,
			'resources'         => KERP_Modules_Programs_Resources::instance()->get_by_task( absint( $row['id'] ?? 0 ) ),
			'review'            => [
				'id'           => absint( $row['review_id'] ?? 0 ),
				'status'       => $review_status,
				'status_label' => $review_status !== '' ? (string) ( $review_options[ $review_status ] ?? $review_status ) : '',
				'score'        => $this->format_decimal( $row['review_score'] ?? '' ),
				'public_note'  => (string) ( $row['review_public_note'] ?? '' ),
				'updated_at'   => (string) ( $row['review_updated_at'] ?? '' ),
			],
		];
	}
	
	private function get_public_task( int $task_id, int $user_id ): ?array {
		global $wpdb;
		
		$task_id = absint( $task_id );
		$user_id = absint( $user_id );
		if ( $task_id <= 0 || $user_id <= 0 ) {
			return NULL;
		}
		
		$tasks_table = KERP_Modules_Programs_Tasks::instance()->table_name();
		$plans_table = KERP_Modules_Programs_Plans::instance()->table_name();
		$row         = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT t.*
				FROM {$tasks_table} t
				INNER JOIN {$plans_table} p ON p.id = t.plan_id
				WHERE t.id = %d
					AND p.customer_id = %d
					AND p.status = 'published'
					AND t.status IN ('active','completed')
				LIMIT 1",
				$task_id,
				$user_id
			),
			ARRAY_A
		);
		
		return is_array( $row ) ? $row : NULL;
	}
	
	private function get_existing_attachments( int $result_id ): array {
		if ( $result_id <= 0 ) {
			return [];
		}
		
		$value = KERP_Helpers_Meta::instance()->get_result_meta( $result_id, 'attachment', TRUE );
		
		return $this->normalize_attachments( $value );
	}
	
	private function normalize_attachments( mixed $value ): array {
		if ( is_string( $value ) ) {
			$value = preg_split( '/\s*,\s*/', $value, - 1, PREG_SPLIT_NO_EMPTY );
		}
		
		if ( ! is_array( $value ) ) {
			return [];
		}
		
		return array_values( array_unique( array_filter( array_map(
			static fn( mixed $url ): string => esc_url_raw( trim( (string) $url ) ),
			$value
		) ) ) );
	}
	
	private function handle_result_uploads( array $existing, int $user_id ): array|WP_Error {
		$files = $this->normalize_uploaded_files( $_FILES['attachments'] ?? [] );
		if ( count( $existing ) + count( $files ) > 5 ) {
			return new WP_Error( 'kerp_programs_public_max_files', __( 'حداکثر ۵ فایل می‌توانید برای هر گزارش ثبت کنید.', 'kasebi-erp' ) );
		}
		
		if ( empty( $files ) ) {
			return [ 'urls' => $existing, 'files' => [] ];
		}
		
		require_once ABSPATH . 'wp-admin/includes/file.php';
		
		$allowed_mimes = [
			'jpg|jpeg|jpe' => 'image/jpeg',
			'png'          => 'image/png',
			'gif'          => 'image/gif',
			'webp'         => 'image/webp',
			'avif'         => 'image/avif',
			'pdf'          => 'application/pdf',
		];
		
		$max_size          = min( wp_max_upload_size(), 10 * MB_IN_BYTES );
		$urls              = $existing;
		$paths             = [];
		$subdir            = '/kerp/program-results/' . absint( $user_id );
		$upload_dir_filter = static function( array $dirs ) use ( $subdir ): array {
			$dirs['path']   = $dirs['basedir'] . $subdir;
			$dirs['url']    = $dirs['baseurl'] . $subdir;
			$dirs['subdir'] = $subdir;
			
			return $dirs;
		};
		
		add_filter( 'upload_dir', $upload_dir_filter );
		
		foreach ( $files as $file ) {
			if ( absint( $file['size'] ?? 0 ) > $max_size ) {
				remove_filter( 'upload_dir', $upload_dir_filter );
				$this->cleanup_uploaded_files( $paths );
				
				return new WP_Error( 'kerp_programs_public_file_too_large', __( 'حجم یکی از فایل‌ها بیشتر از حد مجاز است.', 'kasebi-erp' ) );
			}
			
			$uploaded = wp_handle_upload( $file, [ 'test_form' => FALSE, 'mimes' => $allowed_mimes ] );
			if ( ! is_array( $uploaded ) || ! empty( $uploaded['error'] ) || empty( $uploaded['url'] ) ) {
				remove_filter( 'upload_dir', $upload_dir_filter );
				$this->cleanup_uploaded_files( $paths );
				
				return new WP_Error(
					'kerp_programs_public_upload_failed',
					is_array( $uploaded ) && ! empty( $uploaded['error'] )
						? sanitize_text_field( (string) $uploaded['error'] )
						: __( 'بارگذاری فایل انجام نشد.', 'kasebi-erp' )
				);
			}
			
			$url = esc_url_raw( (string) $uploaded['url'] );
			if ( $url !== '' ) {
				$urls[] = $url;
			}
			if ( ! empty( $uploaded['file'] ) ) {
				$paths[] = (string) $uploaded['file'];
			}
		}
		
		remove_filter( 'upload_dir', $upload_dir_filter );
		
		return [
			'urls'  => array_values( array_unique( array_filter( $urls ) ) ),
			'files' => $paths,
		];
	}
	
	private function normalize_uploaded_files( mixed $files ): array {
		if ( ! is_array( $files ) || empty( $files['name'] ) ) {
			return [];
		}
		
		if ( ! is_array( $files['name'] ) ) {
			return empty( $files['name'] ) ? [] : [ $files ];
		}
		
		$normalized = [];
		$count      = count( $files['name'] );
		for ( $index = 0; $index < $count; $index ++ ) {
			$name  = sanitize_file_name( (string) ( $files['name'][ $index ] ?? '' ) );
			$error = absint( $files['error'][ $index ] ?? UPLOAD_ERR_NO_FILE );
			
			if ( $name === '' || $error === UPLOAD_ERR_NO_FILE || $error !== UPLOAD_ERR_OK ) {
				continue;
			}
			
			$normalized[] = [
				'name'     => $name,
				'type'     => sanitize_mime_type( (string) ( $files['type'][ $index ] ?? '' ) ),
				'tmp_name' => (string) ( $files['tmp_name'][ $index ] ?? '' ),
				'error'    => $error,
				'size'     => absint( $files['size'][ $index ] ?? 0 ),
			];
		}
		
		return $normalized;
	}
	
	private function cleanup_uploaded_files( array $paths ): void {
		foreach ( $paths as $path ) {
			$path = (string) $path;
			if ( $path !== '' && is_file( $path ) ) {
				wp_delete_file( $path );
			}
		}
	}
	
	private function sanitize_time( mixed $value ): string|WP_Error {
		$value = KERP_Helpers_Format::sanitize_numbers( trim( wp_unslash( (string) $value ) ) );
		if ( $value === '' ) {
			return '';
		}
		
		if ( preg_match( '/^(\d{1,2}):(\d{2})$/', $value, $matches ) !== 1 ) {
			return new WP_Error( 'kerp_programs_public_invalid_time', __( 'فرمت ساعت باید به شکل 18:30 باشد.', 'kasebi-erp' ) );
		}
		
		$hour   = (int) $matches[1];
		$minute = (int) $matches[2];
		if ( $hour < 0 || $hour > 23 || $minute < 0 || $minute > 59 ) {
			return new WP_Error( 'kerp_programs_public_invalid_time', __( 'ساعت واردشده معتبر نیست.', 'kasebi-erp' ) );
		}
		
		return sprintf( '%02d:%02d', $hour, $minute );
	}
	
	private function get_current_jalali_month(): string {
		$month = KERP_Helpers_Format::sanitize_numbers( date_i18n( 'Y-m', current_time( 'timestamp' ) ) );
		$month = $this->normalize_jalali_month( $month );
		
		return $month !== '' ? $month : '1400-01';
	}
	
	private function normalize_jalali_month( string $month ): string {
		$month = KERP_Helpers_Format::sanitize_numbers( trim( $month ) );
		$month = str_replace( '/', '-', $month );
		if ( preg_match( '/^(\d{4})-(\d{1,2})$/', $month, $matches ) !== 1 ) {
			return '';
		}
		
		$year         = (int) $matches[1];
		$month_number = (int) $matches[2];
		if ( $year < 1000 || $year >= 1700 || $month_number < 1 || $month_number > 12 ) {
			return '';
		}
		
		return sprintf( '%04d-%02d', $year, $month_number );
	}
	
	private function get_jalali_month_range( string $month ): array {
		$month = $this->normalize_jalali_month( $month );
		if ( $month === '' ) {
			return [];
		}
		
		[ $year, $month_number ] = array_map( 'intval', explode( '-', $month ) );
		$next_year  = $month_number === 12 ? $year + 1 : $year;
		$next_month = $month_number === 12 ? 1 : $month_number + 1;
		$date_from  = KERP_Helpers_Date::jalali_to_gregorian( sprintf( '%04d-%02d-01', $year, $month_number ) );
		$next_first = KERP_Helpers_Date::jalali_to_gregorian( sprintf( '%04d-%02d-01', $next_year, $next_month ) );
		
		if ( ! is_string( $date_from ) || $date_from === '' || ! is_string( $next_first ) || $next_first === '' ) {
			return [];
		}
		
		$next_timestamp  = strtotime( $next_first . ' 12:00:00' );
		$first_timestamp = strtotime( $date_from . ' 12:00:00' );
		if ( $next_timestamp === FALSE || $first_timestamp === FALSE ) {
			return [];
		}
		
		$date_to = date( 'Y-m-d', strtotime( '-1 day', $next_timestamp ) );
		$days    = (int) round( ( $next_timestamp - $first_timestamp ) / DAY_IN_SECONDS );
		
		return [ 'date_from' => $date_from, 'date_to' => $date_to, 'days' => $days ];
	}
	
	private function shift_jalali_month( string $month, int $offset ): string {
		$month = $this->normalize_jalali_month( $month );
		if ( $month === '' ) {
			return $this->get_current_jalali_month();
		}
		
		[ $year, $month_number ] = array_map( 'intval', explode( '-', $month ) );
		$index     = ( $year * 12 ) + ( $month_number - 1 ) + $offset;
		$new_year  = (int) floor( $index / 12 );
		$new_month = ( $index % 12 ) + 1;
		
		if ( $new_month <= 0 ) {
			$new_month += 12;
			$new_year --;
		}
		
		return sprintf( '%04d-%02d', $new_year, $new_month );
	}
	
	private function panel_month_route( string $month ): string {
		$month = $this->normalize_jalali_month( $month );
		
		if ( $month === '' ) {
			$month = $this->get_current_jalali_month();
		}
		
		return self::PANEL_PAGE . '?view=month&month=' . rawurlencode( $month );
	}

	private function panel_week_route( string $date ): string {
		$date = KERP_Modules_Programs_Plans::instance()->normalize_date( $date );
		return self::PANEL_PAGE . '?view=week&week=' . rawurlencode( $date !== '' ? $date : current_time( 'Y-m-d' ) );
	}
	
	private function panel_day_route( string $date ): string {
		$date = KERP_Modules_Programs_Plans::instance()->normalize_date( $date );
		
		if ( $date === '' ) {
			return self::PANEL_PAGE;
		}
		
		return self::PANEL_PAGE . '?day=' . rawurlencode( $date );
	}
	
	private function format_decimal( mixed $value ): string {
		if ( $value === NULL || $value === '' ) {
			return '';
		}
		
		$value = KERP_Helpers_Format::sanitize_numbers( trim( (string) $value ) );
		if ( ! is_numeric( $value ) ) {
			return sanitize_text_field( $value );
		}
		
		$formatted = number_format( (float) $value, 6, '.', '' );
		$formatted = rtrim( rtrim( $formatted, '0' ), '.' );
		
		return ( $formatted === '' || $formatted === '-0' ) ? '0' : $formatted;
	}
	
	private function verify_public_nonce(): void {
		$nonce = sanitize_text_field( wp_unslash( (string) ( $_POST['nonce'] ?? '' ) ) );
		if ( $nonce === '' || ! wp_verify_nonce( $nonce, 'ksp_ajax_nonce' ) ) {
			$this->json_error( __( 'اعتبار درخواست منقضی شده است. صفحه را تازه کنید.', 'kasebi-erp' ) );
		}
	}
	
	private function json_success( array $data = [] ): void {
		wp_send_json( array_merge( [ 'status' => 'success' ], $data ) );
	}
	
	private function json_error( string $message ): void {
		wp_send_json( [ 'status' => 'error', 'message' => $message, 'msg' => $message ] );
	}
	
	public function custom_upload_file(): void {
		if ( ! is_user_logged_in() ) {
			wp_send_json( [
				'status' => 'error',
				'msg'    => 'برای آپلود فایل باید وارد حساب کاربری شوید.',
			] );
		}
		
		if ( empty( $_FILES['file'] ) || ! is_array( $_FILES['file'] ) ) {
			wp_send_json( [
				'status' => 'error',
				'msg'    => 'فایلی ارسال نشده است.',
			] );
		}
		
		$file = $_FILES['file'];
		
		if ( ! empty( $file['error'] ) ) {
			wp_send_json( [
				'status' => 'error',
				'msg'    => 'در آپلود فایل خطایی رخ داده است.',
			] );
		}
		
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		
		$allowed_mimes = [
			'jpg|jpeg|jpe' => 'image/jpeg',
			'png'          => 'image/png',
			'gif'          => 'image/gif',
			'webp'         => 'image/webp',
			'avif'         => 'image/avif',
			'pdf'          => 'application/pdf',
		];
		
		$uploaded = wp_handle_upload(
			$file,
			[
				'test_form' => FALSE,
				'mimes'     => $allowed_mimes,
			]
		);
		
		if ( ! is_array( $uploaded ) || ! empty( $uploaded['error'] ) ) {
			wp_send_json( [
				'status' => 'error',
				'msg'    => is_array( $uploaded ) && ! empty( $uploaded['error'] )
					? $uploaded['error']
					: 'آپلود فایل انجام نشد.',
			] );
		}
		
		$attachment = [
			'post_mime_type' => $uploaded['type'],
			'post_title'     => sanitize_text_field(
				pathinfo( $file['name'], PATHINFO_FILENAME )
			),
			'post_content'   => '',
			'post_status'    => 'inherit',
		];
		
		$attachment_id = wp_insert_attachment(
			$attachment,
			$uploaded['file']
		);
		
		if ( is_wp_error( $attachment_id ) ) {
			wp_send_json( [
				'status' => 'error',
				'msg'    => $attachment_id->get_error_message(),
			] );
		}
		
		$metadata = wp_generate_attachment_metadata(
			$attachment_id,
			$uploaded['file']
		);
		
		if ( ! empty( $metadata ) ) {
			wp_update_attachment_metadata(
				$attachment_id,
				$metadata
			);
		}
		
		wp_send_json( [
			'status'        => 'success',
			'url'           => wp_get_attachment_url( $attachment_id ),
			'attachment_id' => $attachment_id,
		] );
	}
	

	public function register_panel_navigation_settings( array $rows ): array {
		return KERP_Settings_Panel_Navigation::register_entries( $rows, 'programs', 'برنامه‌ها', $this->register_panel_pages( [] ) );
	}
}
