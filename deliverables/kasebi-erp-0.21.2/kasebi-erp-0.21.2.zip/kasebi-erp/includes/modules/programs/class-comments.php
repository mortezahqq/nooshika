<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Programs_Comments {

	private static ?self $instance = NULL;

	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {}
	private function __clone() {}
	public function __wakeup(): void { throw new LogicException( 'Cannot unserialize a singleton.' ); }

	public function table_name(): string {
		global $wpdb;
		return $wpdb->prefix . 'kerp_program_comments';
	}

	public function get( int $comment_id ): ?array {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$this->table_name()} WHERE id=%d LIMIT 1", absint( $comment_id ) ), ARRAY_A );
		return is_array( $row ) ? $this->hydrate( $row ) : NULL;
	}

	public function get_by_plan( int $plan_id ): array {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$this->table_name()} WHERE plan_id=%d ORDER BY created_at DESC, id DESC", absint( $plan_id ) ), ARRAY_A );
		return array_map( [ $this, 'hydrate' ], (array) $rows );
	}

	public function get_for_current_user_day( string $date ): array {
		global $wpdb;
		$user_id = get_current_user_id();
		$date = KERP_Modules_Programs_Plans::instance()->normalize_date( $date );
		if ( $user_id <= 0 || $date === '' ) {
			return [];
		}
		$plans_table = KERP_Modules_Programs_Plans::instance()->table_name();
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT c.* FROM {$this->table_name()} c INNER JOIN {$plans_table} p ON p.id=c.plan_id
			 WHERE p.customer_id=%d AND p.status='published' AND p.plan_date=%s AND c.visible_to_user=1
			 ORDER BY c.created_at DESC, c.id DESC", $user_id, $date
		), ARRAY_A );
		return array_map( [ $this, 'hydrate' ], (array) $rows );
	}

	public function save( int $plan_id, string $content, bool $visible_to_user = FALSE ): int|WP_Error {
		global $wpdb;
		if ( ! KERP_Modules_Programs_Plans::instance()->get( $plan_id ) ) {
			return new WP_Error( 'kerp_program_comment_invalid_plan', __( 'برنامه پیدا نشد.', 'kasebi-erp' ) );
		}
		$content = wp_kses_post( $content );
		$plain_text = html_entity_decode( wp_strip_all_tags( $content ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		if ( preg_replace( '/[\s\p{Z}\p{Cf}]+/u', '', $plain_text ) === '' ) {
			return new WP_Error( 'kerp_program_comment_empty', __( 'متن کامنت را وارد کنید.', 'kasebi-erp' ) );
		}
		$result = $wpdb->insert( $this->table_name(), [
			'plan_id' => $plan_id,
			'content' => $content,
			'visible_to_user' => $visible_to_user ? 1 : 0,
			'content_format' => 'html',
			'created_by' => get_current_user_id(),
			'created_at' => current_time( 'mysql' ),
		], [ '%d', '%s', '%d', '%s', '%d', '%s' ] );
		return $result !== FALSE ? (int) $wpdb->insert_id : new WP_Error( 'kerp_program_comment_save_failed', __( 'ثبت کامنت انجام نشد.', 'kasebi-erp' ) );
	}

	public function delete( int $comment_id ): bool|WP_Error {
		global $wpdb;
		if ( ! $this->get( $comment_id ) ) {
			return new WP_Error( 'kerp_program_comment_not_found', __( 'کامنت پیدا نشد.', 'kasebi-erp' ) );
		}
		$result = $wpdb->delete( $this->table_name(), [ 'id' => absint( $comment_id ) ], [ '%d' ] );
		return $result !== FALSE ? TRUE : new WP_Error( 'kerp_program_comment_delete_failed', __( 'حذف کامنت انجام نشد.', 'kasebi-erp' ) );
	}

	public function delete_by_plan( int $plan_id ): void {
		global $wpdb;
		$wpdb->delete( $this->table_name(), [ 'plan_id' => absint( $plan_id ) ], [ '%d' ] );
	}

	public function render_content( array $comment ): string {
		$content = (string) ( $comment['content'] ?? '' );
		return ( $comment['content_format'] ?? 'text' ) === 'html'
			? wp_kses_post( $content )
			: nl2br( esc_html( $content ) );
	}

	private function hydrate( array $row ): array {
		$row['id'] = absint( $row['id'] ?? 0 );
		$row['plan_id'] = absint( $row['plan_id'] ?? 0 );
		$row['created_by'] = absint( $row['created_by'] ?? 0 );
		$row['visible_to_user'] = ! empty( $row['visible_to_user'] );
		$row['author_badge'] = (string) get_user_meta( $row['created_by'], 'kerp_comment_badge', TRUE );
		$user = get_userdata( $row['created_by'] );
		$row['author_name'] = $user instanceof WP_User ? get_user_name_by_id( $user->ID ) : __( 'کاربر حذف‌شده', 'kasebi-erp' );
		$row['author_avatar'] = get_avatar_url( $row['created_by'], [ 'size' => 48 ] );
		return $row;
	}
}
