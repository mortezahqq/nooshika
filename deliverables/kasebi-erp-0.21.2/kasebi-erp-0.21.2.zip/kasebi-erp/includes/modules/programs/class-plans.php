<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Programs_Plans {
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public function table_name(): string {
		global $wpdb;
		
		return $wpdb->prefix . 'kerp_program_daily_plans';
	}
	
	public function get( int $plan_id ): ?array {
		global $wpdb;
		$plan_id = absint( $plan_id );
		if ( $plan_id <= 0 ) {
			return NULL;
		}
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$this->table_name()} WHERE id = %d LIMIT 1", $plan_id ), ARRAY_A );
		
		return is_array( $row ) ? $this->hydrate( $row ) : NULL;
	}
	
	public function get_by_customer_date( int $customer_id, string $plan_date ): ?array {
		global $wpdb;
		$customer_id = absint( $customer_id );
		$plan_date   = $this->normalize_date( $plan_date );
		if ( $customer_id <= 0 || $plan_date === '' ) {
			return NULL;
		}
		$row = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$this->table_name()} WHERE customer_id = %d AND plan_date = %s LIMIT 1", $customer_id, $plan_date ),
			ARRAY_A
		);
		
		return is_array( $row ) ? $this->hydrate( $row ) : NULL;
	}
	
	public function find( array $args = [] ): array {
		global $wpdb;
		$args   = wp_parse_args(
			$args,
			[
				'customer_id'   => 0,
				'employee_id'   => 0,
				'status'        => '',
				'date_from'     => '',
				'date_to'       => '',
				'search'        => '',
				'page_number'   => 1,
				'per_page'      => 20,
				'order'         => 'DESC',
				'enforce_scope' => TRUE,
			]
		);
		$where  = [ '1=1' ];
		$values = [];
		if ( ! empty( $args['enforce_scope'] ) ) {
			$scope = kerp_list_scope( 'programs' );
			if ( $scope === 'none' ) {
				return [
					'items'       => [],
					'total'       => 0,
					'page_number' => 1,
					'per_page'    => max( 1, absint( $args['per_page'] ) ),
					'total_pages' => 1,
				];
			}
			if ( $scope === 'own' ) {
				$args['employee_id'] = get_current_user_id();
			}
		}
		if ( absint( $args['customer_id'] ) > 0 ) {
			$where[]  = 'p.customer_id = %d';
			$values[] = absint( $args['customer_id'] );
		}
		if ( absint( $args['employee_id'] ) > 0 ) {
			$where[]  = 'p.employee_id = %d';
			$values[] = absint( $args['employee_id'] );
		}
		$status = sanitize_key( (string) $args['status'] );
		if ( $status !== '' ) {
			$where[]  = 'p.status = %s';
			$values[] = $status;
		}
		$date_from = $this->normalize_date( (string) $args['date_from'] );
		$date_to   = $this->normalize_date( (string) $args['date_to'] );
		if ( $date_from !== '' ) {
			$where[]  = 'p.plan_date >= %s';
			$values[] = $date_from;
		}
		if ( $date_to !== '' ) {
			$where[]  = 'p.plan_date <= %s';
			$values[] = $date_to;
		}
		$search = sanitize_text_field( (string) $args['search'] );
		if ( $search !== '' ) {
			$where[]  = 'p.title LIKE %s';
			$values[] = '%' . $wpdb->esc_like( $search ) . '%';
		}
		$page_number = max( 1, absint( $args['page_number'] ) );
		$per_page    = max( 1, min( 200, absint( $args['per_page'] ) ) );
		$offset      = ( $page_number - 1 ) * $per_page;
		$order       = strtoupper( (string) $args['order'] ) === 'ASC' ? 'ASC' : 'DESC';
		$where_sql   = implode( ' AND ', $where );
		$count_sql   = "SELECT COUNT(*) FROM {$this->table_name()} p WHERE {$where_sql}";
		$data_sql    = "SELECT p.* FROM {$this->table_name()} p WHERE {$where_sql} ORDER BY p.plan_date {$order}, p.id {$order} LIMIT %d OFFSET %d";
		$total       = $values ? (int) $wpdb->get_var( $wpdb->prepare( $count_sql, $values ) ) : (int) $wpdb->get_var( $count_sql );
		$data_values = array_merge( $values, [ $per_page, $offset ] );
		$rows        = $wpdb->get_results( $wpdb->prepare( $data_sql, $data_values ), ARRAY_A );
		
		return [
			'items'       => array_map( [ $this, 'hydrate' ], (array) $rows ),
			'total'       => $total,
			'page_number' => $page_number,
			'per_page'    => $per_page,
			'total_pages' => max( 1, (int) ceil( $total / $per_page ) ),
		];
	}
	
	public function save( array $data, int $plan_id = 0 ): int|WP_Error {
		global $wpdb;
		$plan_id     = absint( $plan_id );
		$existing    = $plan_id > 0 ? $this->get( $plan_id ) : NULL;
		$customer_id = absint( $data['customer_id'] ?? $existing['customer_id'] ?? 0 );
		$plan_date   = $this->normalize_date( (string) ( $data['plan_date'] ?? $existing['plan_date'] ?? '' ) );
		$status      = sanitize_key( (string) ( $data['status'] ?? $existing['status'] ?? KERP_Modules_Programs_Settings::instance()
		                                                                                                                ->get( 'default_plan_status', 'draft' ) ) );
		
		if ( $customer_id <= 0 || ! get_userdata( $customer_id ) ) {
			return new WP_Error( 'kerp_programs_invalid_customer', __( 'کاربر انتخاب‌شده معتبر نیست.', 'kasebi-erp' ) );
		}
		if ( $plan_date === '' ) {
			return new WP_Error( 'kerp_programs_invalid_date', __( 'تاریخ برنامه معتبر نیست.', 'kasebi-erp' ) );
		}
		$employee_id = absint( $data['employee_id'] ?? $existing['employee_id'] ?? 0 );
		if ( $employee_id > 0 && ! get_userdata( $employee_id ) ) {
			return new WP_Error( 'kerp_programs_invalid_employee', __( 'مشاور مسئول انتخاب‌شده معتبر نیست.', 'kasebi-erp' ) );
		}
		if ( ! isset( KERP_Modules_Programs_Settings::instance()->get_plan_status_options()[ $status ] ) ) {
			return new WP_Error( 'kerp_programs_invalid_plan_status', __( 'وضعیت برنامه معتبر نیست.', 'kasebi-erp' ) );
		}
		$duplicate = $this->get_by_customer_date( $customer_id, $plan_date );
		if ( is_array( $duplicate ) && (int) $duplicate['id'] !== $plan_id ) {
			return new WP_Error( 'kerp_programs_duplicate_plan', __( 'برای این کاربر در تاریخ انتخاب‌شده قبلاً برنامه ثبت شده است.', 'kasebi-erp' ) );
		}
		
		$now = current_time( 'mysql' );
		$row = [
			'customer_id'        => $customer_id,
			'plan_date'          => $plan_date,
			'source_template_id' => absint( $data['source_template_id'] ?? $existing['source_template_id'] ?? 0 ),
			'employee_id'        => $employee_id,
			'title'              => sanitize_text_field( (string) ( $data['title'] ?? '' ) ),
			'description'        => wp_kses_post( (string) ( $data['description'] ?? '' ) ),
			'status'             => $status,
			'updated_at'         => $now,
		];
		if ( $plan_id > 0 ) {
			$result = $wpdb->update( $this->table_name(), $row, [ 'id' => $plan_id ] );
		} else {
			$row['created_by'] = get_current_user_id();
			$row['created_at'] = $now;
			$result            = $wpdb->insert( $this->table_name(), $row );
			$plan_id           = (int) $wpdb->insert_id;
		}
		if ( $result === FALSE || $plan_id <= 0 ) {
			return new WP_Error( 'kerp_programs_plan_save_failed', __( 'ذخیره برنامه روزانه انجام نشد.', 'kasebi-erp' ) );
		}
		
		do_action( 'kerp_program_plan_saved', $plan_id, $data );
		
		return $plan_id;
	}
	
	public function delete( int $plan_id ): bool|WP_Error {
		global $wpdb;
		$plan = $this->get( $plan_id );
		if ( ! is_array( $plan ) ) {
			return new WP_Error( 'kerp_programs_plan_not_found', __( 'برنامه روزانه پیدا نشد.', 'kasebi-erp' ) );
		}
		$result_count = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->prefix}kerp_program_results r INNER JOIN {$wpdb->prefix}kerp_program_daily_tasks t ON t.id = r.task_id WHERE t.plan_id = %d",
				$plan_id
			)
		);
		if ( $result_count > 0 ) {
			$updated = $wpdb->update( $this->table_name(), [
				'status'     => 'archived',
				'updated_at' => current_time( 'mysql' ),
			], [ 'id' => $plan_id ] );
			
			return $updated !== FALSE ? TRUE : new WP_Error( 'kerp_programs_plan_archive_failed', __( 'برنامه دارای نتیجه است و آرشیو آن انجام نشد.', 'kasebi-erp' ) );
		}
		$tasks = KERP_Modules_Programs_Tasks::instance()->get_by_plan( $plan_id, FALSE );
		foreach ( $tasks as $task ) {
			KERP_Modules_Programs_Tasks::instance()->force_delete( (int) $task['id'] );
		}
		$result = $wpdb->delete( $this->table_name(), [ 'id' => $plan_id ], [ '%d' ] );
		if ( $result === FALSE ) {
			return new WP_Error( 'kerp_programs_plan_delete_failed', __( 'حذف برنامه انجام نشد.', 'kasebi-erp' ) );
		}
		KERP_Helpers_Meta::instance()->delete_plan_meta( $plan_id );
		KERP_Modules_Programs_Comments::instance()->delete_by_plan( $plan_id );
		
		return TRUE;
	}
	
	public function count_for_customer( int $customer_id ): int {
		global $wpdb;
		
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$this->table_name()} WHERE customer_id = %d", absint( $customer_id ) ) );
	}
	
	/** Copy the visible customer's previous Saturday-Friday week into the selected week. */
	public function copy_previous_week( int $customer_id, string $target_week_start ): array|WP_Error {
		global $wpdb;
		$customer_id       = absint( $customer_id );
		$target_week_start = $this->normalize_date( $target_week_start );
		if ( $customer_id <= 0 || ! get_userdata( $customer_id ) || $target_week_start === '' ) {
			return new WP_Error( 'kerp_programs_copy_week_invalid', __( 'کاربر یا تاریخ هفته معتبر نیست.', 'kasebi-erp' ) );
		}
		$target_timestamp  = strtotime( $target_week_start . ' 12:00:00' );
		$weekday           = (int) date( 'w', $target_timestamp );
		$target_week_start = date( 'Y-m-d', strtotime( '-' . ( ( $weekday + 1 ) % 7 ) . ' days', $target_timestamp ) );
		$source_start      = date( 'Y-m-d', strtotime( '-7 days', strtotime( $target_week_start . ' 12:00:00' ) ) );
		$source_end        = date( 'Y-m-d', strtotime( '+6 days', strtotime( $source_start . ' 12:00:00' ) ) );
		$source            = $this->find( [
			'customer_id' => $customer_id,
			'date_from'   => $source_start,
			'date_to'     => $source_end,
			'per_page'    => 200,
			'order'       => 'ASC'
		] );
		$source_plans      = (array) ( $source['items'] ?? [] );
		if ( empty( $source_plans ) ) {
			return new WP_Error( 'kerp_programs_copy_week_empty', __( 'در هفته قبل برنامه‌ای برای بارگذاری وجود ندارد.', 'kasebi-erp' ) );
		}
		
		$created_plans = 0;
		$created_tasks = 0;
		$skipped_plans = 0;
		$wpdb->query( 'START TRANSACTION' );
		foreach ( $source_plans as $source_plan ) {
			$offset      = (int) floor( ( strtotime( (string) $source_plan['plan_date'] . ' 12:00:00' ) - strtotime( $source_start . ' 12:00:00' ) ) / DAY_IN_SECONDS );
			$target_date = date( 'Y-m-d', strtotime( '+' . $offset . ' days', strtotime( $target_week_start . ' 12:00:00' ) ) );
			if ( $this->get_by_customer_date( $customer_id, $target_date ) ) {
				$skipped_plans ++;
				continue;
			}
			$employee_id = kerp_list_scope( 'programs' ) === 'own' ? get_current_user_id() : absint( $source_plan['employee_id'] ?? 0 );
			$new_plan_id = $this->save( [
				'customer_id'        => $customer_id,
				'plan_date'          => $target_date,
				'source_template_id' => absint( $source_plan['source_template_id'] ?? 0 ),
				'employee_id'        => $employee_id,
				'title'              => (string) ( $source_plan['title'] ?? '' ),
				'description'        => (string) ( $source_plan['description'] ?? '' ),
				'status'             => 'draft',
			] );
			if ( is_wp_error( $new_plan_id ) ) {
				$wpdb->query( 'ROLLBACK' );
				
				return $new_plan_id;
			}
			$created_plans ++;
			foreach (
				KERP_Modules_Programs_Tasks::instance()
				                           ->get_by_plan( (int) $source_plan['id'], FALSE ) as $source_task
			) {
				$new_task_id = KERP_Modules_Programs_Tasks::instance()->save( [
					'plan_id'                 => (int) $new_plan_id,
					'source_template_task_id' => absint( $source_task['source_template_task_id'] ?? 0 ),
					'task_type_id'            => absint( $source_task['task_type_id'] ?? 0 ),
					'unit_id'                 => absint( $source_task['unit_id'] ?? 0 ),
					'title'                   => (string) ( $source_task['title'] ?? '' ),
					'description'             => (string) ( $source_task['description'] ?? '' ),
					'target_value'            => $source_task['target_value'] ?? NULL,
					'target_text'             => (string) ( $source_task['target_text'] ?? '' ),
					'is_required'             => ! empty( $source_task['is_required'] ),
					'status'                  => 'active',
					'sort_order'              => (int) ( $source_task['sort_order'] ?? 10 ),
					'term_ids'                => (array) ( $source_task['term_ids'] ?? [] ),
				] );
				if ( is_wp_error( $new_task_id ) ) {
					$wpdb->query( 'ROLLBACK' );
					
					return $new_task_id;
				}
				$all_meta = KERP_Helpers_Meta::instance()->get_task_meta( (int) $source_task['id'] );
				foreach ( is_array( $all_meta ) ? $all_meta : [] as $meta_key => $values ) {
					foreach ( is_array( $values ) ? $values : [] as $value ) {
						KERP_Helpers_Meta::instance()->add_task_meta( (int) $new_task_id, (string) $meta_key, $value );
					}
				}
				foreach ( (array) ( $source_task['resources'] ?? [] ) as $resource ) {
					$resource_result = KERP_Modules_Programs_Resources::instance()->save( [
						'task_id'      => (int) $new_task_id,
						'type_key'     => (string) ( $resource['type_key'] ?? 'link' ),
						'title'        => (string) ( $resource['title'] ?? '' ),
						'resource_url' => (string) ( $resource['resource_url'] ?? '' ),
						'reference_id' => (int) ( $resource['reference_id'] ?? 0 ),
						'room_id'      => (string) ( $resource['room_id'] ?? '' ),
						'description'  => (string) ( $resource['description'] ?? '' ),
						'sort_order'   => (int) ( $resource['sort_order'] ?? 10 ),
					] );
					if ( is_wp_error( $resource_result ) ) {
						$wpdb->query( 'ROLLBACK' );
						
						return $resource_result;
					}
				}
				$created_tasks ++;
			}
		}
		$wpdb->query( 'COMMIT' );
		
		return compact( 'created_plans', 'created_tasks', 'skipped_plans' );
	}
	
	public function normalize_date( string $date ): string {
		$date = trim( $date );
		if ( function_exists( 'nooshika_sanitize_numbers' ) ) {
			$date = nooshika_sanitize_numbers( $date );
		} elseif ( class_exists( 'KERP_Helpers_Format' ) && method_exists( 'KERP_Helpers_Format', 'sanitize_numbers' ) ) {
			$date = KERP_Helpers_Format::sanitize_numbers( $date );
		}
		$date = str_replace( '/', '-', $date );
		if ( preg_match( '/^\d{4}-\d{1,2}-\d{1,2}$/', $date ) !== 1 ) {
			return '';
		}
		$year = (int) substr( $date, 0, 4 );
		if ( $year < 1700 && class_exists( 'KERP_Helpers_Date' ) ) {
			$converted = KERP_Helpers_Date::jalali_to_gregorian( $date );
			if ( is_string( $converted ) && $converted !== '' ) {
				$date = $converted;
			}
		}
		$timestamp = strtotime( $date . ' 12:00:00' );
		if ( $timestamp === FALSE ) {
			return '';
		}
		$normalized = date( 'Y-m-d', $timestamp );
		$parts      = array_map( 'intval', explode( '-', $normalized ) );
		if ( count( $parts ) !== 3 || ! checkdate( $parts[1], $parts[2], $parts[0] ) ) {
			return '';
		}
		
		return $normalized;
	}
	
	public function display_date( string $date ): string {
		$timestamp = strtotime( $date . ' 12:00:00' );
		
		return $timestamp !== FALSE ? date_i18n( 'j F Y', $timestamp ) : '';
	}
	
	private function hydrate( array $row ): array {
		global $wpdb;
		$row['id']                 = absint( $row['id'] ?? 0 );
		$row['customer_id']        = absint( $row['customer_id'] ?? 0 );
		$row['employee_id']        = absint( $row['employee_id'] ?? 0 );
		$row['source_template_id'] = absint( $row['source_template_id'] ?? 0 );
		$row['task_count']         = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}kerp_program_daily_tasks WHERE plan_id = %d AND status <> 'archived'", (int) $row['id'] ) );
		$row['result_count']       = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}kerp_program_results r INNER JOIN {$wpdb->prefix}kerp_program_daily_tasks t ON t.id = r.task_id WHERE t.plan_id = %d", (int) $row['id'] ) );
		$row['comment_count']      = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}kerp_program_comments WHERE plan_id = %d", (int) $row['id'] ) );
		
		return $row;
	}
	
}
