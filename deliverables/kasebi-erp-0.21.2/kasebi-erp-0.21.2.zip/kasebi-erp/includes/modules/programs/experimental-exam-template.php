<?php

defined( 'ABSPATH' ) || exit;

return [
	'title'       => 'برنامه نمونه هفت‌روزه کنکور تجربی',
	'description' => 'یک برنامه متعادل هفت‌روزه برای مرور مباحث اصلی، تست زمان‌دار، تحلیل پاسخ‌ها و جمع‌بندی کنکور تجربی.',
	'days'        => [
		[
			'title' => 'زیست و شیمی پایه',
			'tasks' => [
				[ 'title' => 'مطالعه زیست دهم؛ یاخته و دنیای زنده', 'type' => 'study', 'unit' => 'page', 'target' => 30, 'subject' => 'biology' ],
				[ 'title' => 'تست زیست دهم', 'type' => 'test', 'unit' => 'test', 'target' => 40, 'subject' => 'biology' ],
				[ 'title' => 'مطالعه شیمی دهم؛ ساختار اتم و جدول تناوبی', 'type' => 'study', 'unit' => 'page', 'target' => 25, 'subject' => 'chemistry' ],
				[ 'title' => 'تست شیمی دهم', 'type' => 'test', 'unit' => 'test', 'target' => 30, 'subject' => 'chemistry' ],
			],
		],
		[
			'title' => 'ریاضی و فیزیک پایه',
			'tasks' => [
				[ 'title' => 'مطالعه ریاضی؛ تابع و معادله', 'type' => 'study', 'unit' => 'page', 'target' => 25, 'subject' => 'math' ],
				[ 'title' => 'تست ریاضی؛ تابع و معادله', 'type' => 'test', 'unit' => 'test', 'target' => 35, 'subject' => 'math' ],
				[ 'title' => 'مطالعه فیزیک؛ حرکت‌شناسی و دینامیک', 'type' => 'study', 'unit' => 'page', 'target' => 25, 'subject' => 'physics' ],
				[ 'title' => 'تست فیزیک؛ حرکت‌شناسی و دینامیک', 'type' => 'test', 'unit' => 'test', 'target' => 30, 'subject' => 'physics' ],
			],
		],
		[
			'title' => 'زیست و شیمی یازدهم',
			'tasks' => [
				[ 'title' => 'مطالعه زیست یازدهم؛ تنظیم عصبی و حواس', 'type' => 'study', 'unit' => 'page', 'target' => 30, 'subject' => 'biology' ],
				[ 'title' => 'تست ترکیبی زیست یازدهم', 'type' => 'test', 'unit' => 'test', 'target' => 45, 'subject' => 'biology' ],
				[ 'title' => 'مطالعه شیمی یازدهم؛ ترموشیمی و محلول‌ها', 'type' => 'study', 'unit' => 'page', 'target' => 25, 'subject' => 'chemistry' ],
				[ 'title' => 'تست شیمی یازدهم', 'type' => 'test', 'unit' => 'test', 'target' => 35, 'subject' => 'chemistry' ],
			],
		],
		[
			'title' => 'حسابان و الکتریسیته',
			'tasks' => [
				[ 'title' => 'مطالعه ریاضی؛ حد، پیوستگی و مشتق', 'type' => 'study', 'unit' => 'page', 'target' => 30, 'subject' => 'math' ],
				[ 'title' => 'تست زمان‌دار حد و مشتق', 'type' => 'test', 'unit' => 'test', 'target' => 40, 'subject' => 'math' ],
				[ 'title' => 'مطالعه فیزیک؛ الکتریسیته ساکن و جریان', 'type' => 'study', 'unit' => 'page', 'target' => 25, 'subject' => 'physics' ],
				[ 'title' => 'تست فیزیک الکتریسیته', 'type' => 'test', 'unit' => 'test', 'target' => 35, 'subject' => 'physics' ],
			],
		],
		[
			'title' => 'زیست و شیمی دوازدهم',
			'tasks' => [
				[ 'title' => 'مطالعه زیست دوازدهم؛ ژنتیک و مولکول‌های اطلاعاتی', 'type' => 'study', 'unit' => 'page', 'target' => 35, 'subject' => 'biology' ],
				[ 'title' => 'تست ترکیبی ژنتیک', 'type' => 'test', 'unit' => 'test', 'target' => 45, 'subject' => 'biology' ],
				[ 'title' => 'مطالعه شیمی دوازدهم؛ تعادل و الکتروشیمی', 'type' => 'study', 'unit' => 'page', 'target' => 30, 'subject' => 'chemistry' ],
				[ 'title' => 'تست شیمی دوازدهم', 'type' => 'test', 'unit' => 'test', 'target' => 35, 'subject' => 'chemistry' ],
			],
		],
		[
			'title' => 'مرور و رفع اشکال',
			'tasks' => [
				[ 'title' => 'مرور نکات نشان‌دار زیست‌شناسی', 'type' => 'study', 'unit' => 'minute', 'target' => 75, 'subject' => 'biology' ],
				[ 'title' => 'مرور فرمول‌های ریاضی و فیزیک', 'type' => 'study', 'unit' => 'minute', 'target' => 75, 'subject' => 'math' ],
				[ 'title' => 'آزمونک ترکیبی دروس اختصاصی', 'type' => 'test', 'unit' => 'test', 'target' => 80 ],
				[ 'title' => 'تحلیل تست‌های غلط و نزده', 'type' => 'study', 'unit' => 'minute', 'target' => 90 ],
			],
		],
		[
			'title' => 'آزمون جامع و تحلیل',
			'tasks' => [
				[ 'title' => 'اجرای آزمون جامع شبیه‌ساز کنکور تجربی', 'type' => 'exam', 'unit' => 'score', 'target' => 100, 'target_text' => 'آزمون در ۱۸۰ دقیقه و با رعایت ترتیب دفترچه‌ها اجرا شود.' ],
				[ 'title' => 'تحلیل کامل آزمون و ثبت مباحث نیازمند مرور', 'type' => 'study', 'unit' => 'minute', 'target' => 120 ],
				[ 'title' => 'مرور نهایی خلاصه‌ها و نکات پرتکرار', 'type' => 'study', 'unit' => 'minute', 'target' => 60 ],
			],
		],
	],
];
