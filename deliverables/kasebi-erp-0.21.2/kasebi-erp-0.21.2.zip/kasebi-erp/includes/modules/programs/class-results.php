<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Programs_Results {
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public function table_name(): string {
		global $wpdb;
		
		return $wpdb->prefix . 'kerp_program_results';
	}
	
	public function review_table(): string {
		global $wpdb;
		
		return $wpdb->prefix . 'kerp_program_reviews';
	}
	
	public function get( int $result_id ): ?array {
		global $wpdb;
		
		$result_id = absint( $result_id );
		
		if ( $result_id <= 0 ) {
			return NULL;
		}
		
		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$this->table_name()} WHERE id = %d LIMIT 1",
				$result_id
			),
			ARRAY_A
		);
		
		return is_array( $row ) ? $this->hydrate_result( $row ) : NULL;
	}
	
	public function get_by_task( int $task_id ): ?array {
		global $wpdb;
		
		$task_id = absint( $task_id );
		
		if ( $task_id <= 0 ) {
			return NULL;
		}
		
		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$this->table_name()} WHERE task_id = %d LIMIT 1",
				$task_id
			),
			ARRAY_A
		);
		
		return is_array( $row ) ? $this->hydrate_result( $row ) : NULL;
	}
	
	public function find( array $args = [] ): array {
		global $wpdb;
		
		$args = wp_parse_args(
			$args,
			[
				'search'        => '',
				'customer_id'   => 0,
				'employee_id'   => 0,
				'status'        => '',
				'date_from'     => '',
				'date_to'       => '',
				'page_number'   => 1,
				'per_page'      => 20,
				'enforce_scope' => TRUE,
			]
		);
		
		[ $where_sql, $values, $scope_blocked ] = $this->build_list_where( $args );
		
		$page_number = max( 1, absint( $args['page_number'] ) );
		$per_page    = max( 1, min( 200, absint( $args['per_page'] ) ) );
		
		if ( $scope_blocked ) {
			return [
				'items'       => [],
				'total'       => 0,
				'page_number' => 1,
				'per_page'    => $per_page,
				'total_pages' => 1,
			];
		}
		
		$offset = ( $page_number - 1 ) * $per_page;
		
		$joins = "
			INNER JOIN {$wpdb->prefix}kerp_program_daily_tasks t
				ON t.id = r.task_id
			INNER JOIN {$wpdb->prefix}kerp_program_daily_plans p
				ON p.id = t.plan_id
			LEFT JOIN {$wpdb->prefix}kerp_program_task_types tt
				ON tt.id = t.task_type_id
			LEFT JOIN {$wpdb->prefix}kerp_program_units un
				ON un.id = t.unit_id
			LEFT JOIN {$this->review_table()} rv
				ON rv.result_id = r.id
			LEFT JOIN {$wpdb->users} cu
				ON cu.ID = r.customer_id
			LEFT JOIN {$wpdb->users} eu
				ON eu.ID = p.employee_id
		";
		
		$count_sql = "
			SELECT COUNT(DISTINCT r.id)
			FROM {$this->table_name()} r
			{$joins}
			WHERE {$where_sql}
		";
		
		$total = $values
			? (int) $wpdb->get_var( $wpdb->prepare( $count_sql, $values ) )
			: (int) $wpdb->get_var( $count_sql );
		
		$data_sql = "
			SELECT
				r.id,
				r.task_id,
				r.customer_id,
				r.value_decimal,
				r.value_text,
				r.status,
				r.created_by,
				r.submitted_at,
				r.updated_at,
				t.plan_id,
				t.task_type_id,
				t.unit_id,
				t.title AS task_title,
				t.target_value,
				t.target_text,
				t.status AS task_status,
				p.plan_date,
				p.title AS plan_title,
				p.employee_id,
				p.status AS plan_status,
				tt.type_key,
				tt.label AS type_label,
				tt.primary_value_type,
				tt.icon AS type_icon,
				un.label AS unit_label,
				un.symbol AS unit_symbol,
				cu.display_name AS customer_name,
				eu.display_name AS employee_name,
				rv.id AS review_id,
				rv.reviewer_id,
				rv.status AS review_status,
				rv.score AS review_score
			FROM {$this->table_name()} r
			{$joins}
			WHERE {$where_sql}
			ORDER BY r.submitted_at DESC, r.id DESC
			LIMIT %d OFFSET %d
		";
		
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				$data_sql,
				array_merge( $values, [ $per_page, $offset ] )
			),
			ARRAY_A
		);
		
		return [
			'items'       => array_map( [ $this, 'hydrate_list_result' ], (array) $rows ),
			'total'       => $total,
			'page_number' => $page_number,
			'per_page'    => $per_page,
			'total_pages' => max( 1, (int) ceil( $total / $per_page ) ),
		];
	}
	
	public function get_stats( array $args = [] ): array {
		global $wpdb;
		
		$args = wp_parse_args(
			$args,
			[
				'search'        => '',
				'customer_id'   => 0,
				'employee_id'   => 0,
				'status'        => '',
				'date_from'     => '',
				'date_to'       => '',
				'enforce_scope' => TRUE,
			]
		);
		
		[ $where_sql, $values, $scope_blocked ] = $this->build_list_where( $args );
		
		if ( $scope_blocked ) {
			return [
				'total'              => 0,
				'waiting_review'     => 0,
				'approved'           => 0,
				'revision_requested' => 0,
				'rejected'           => 0,
			];
		}
		
		$joins = "
			INNER JOIN {$wpdb->prefix}kerp_program_daily_tasks t
				ON t.id = r.task_id
			INNER JOIN {$wpdb->prefix}kerp_program_daily_plans p
				ON p.id = t.plan_id
			LEFT JOIN {$wpdb->users} cu
				ON cu.ID = r.customer_id
		";
		
		$sql = "
			SELECT
				COUNT(DISTINCT r.id) AS total,
				SUM(CASE WHEN r.status IN ('submitted', 'pending_review') THEN 1 ELSE 0 END) AS waiting_review,
				SUM(CASE WHEN r.status = 'approved' THEN 1 ELSE 0 END) AS approved,
				SUM(CASE WHEN r.status = 'revision_requested' THEN 1 ELSE 0 END) AS revision_requested,
				SUM(CASE WHEN r.status = 'rejected' THEN 1 ELSE 0 END) AS rejected
			FROM {$this->table_name()} r
			{$joins}
			WHERE {$where_sql}
		";
		
		$row = $values
			? $wpdb->get_row( $wpdb->prepare( $sql, $values ), ARRAY_A )
			: $wpdb->get_row( $sql, ARRAY_A );
		
		$row = is_array( $row ) ? $row : [];
		
		return [
			'total'              => absint( $row['total'] ?? 0 ),
			'waiting_review'     => absint( $row['waiting_review'] ?? 0 ),
			'approved'           => absint( $row['approved'] ?? 0 ),
			'revision_requested' => absint( $row['revision_requested'] ?? 0 ),
			'rejected'           => absint( $row['rejected'] ?? 0 ),
		];
	}
	
	/**
	 * نتایج یک هفته برنامه را با اطلاعات موردنیاز UI در یک Query برمی‌گرداند.
	 * هفته همیشه از شنبه تا جمعه محاسبه می‌شود.
	 */
	public function find_week( string $week_start, array $args = [] ): array {
		global $wpdb;
		
		$args = wp_parse_args(
			$args,
			[
				'customer_id'   => 0,
				'employee_id'   => 0,
				'status'        => '',
				'review_status' => '',
				'enforce_scope' => TRUE,
			]
		);
		
		$timezone = wp_timezone();
		$plans    = KERP_Modules_Programs_Plans::instance();
		$anchor   = $plans->normalize_date( $week_start );
		
		if ( $anchor === '' ) {
			$anchor = wp_date( 'Y-m-d', NULL, $timezone );
		}
		
		$anchor_date = DateTimeImmutable::createFromFormat(
			'!Y-m-d',
			$anchor,
			$timezone
		);
		
		if ( ! $anchor_date instanceof DateTimeImmutable ) {
			$anchor_date = new DateTimeImmutable( 'today', $timezone );
		}
		
		$weekday            = (int) $anchor_date->format( 'w' );
		$days_from_saturday = ( $weekday + 1 ) % 7;
		$start_date         = $anchor_date->modify( '-' . $days_from_saturday . ' days' );
		$end_date           = $start_date->modify( '+6 days' );
		$week_start         = $start_date->format( 'Y-m-d' );
		$week_end           = $end_date->format( 'Y-m-d' );
		
		$where  = [ 'p.plan_date >= %s', 'p.plan_date <= %s' ];
		$values = [ $week_start, $week_end ];
		
		if ( ! empty( $args['enforce_scope'] ) ) {
			$scope = kerp_list_scope( 'programs' );
			
			if ( $scope === 'none' ) {
				return $this->empty_week_result( $week_start, $week_end );
			}
			
			if ( $scope === 'own' ) {
				$args['employee_id'] = get_current_user_id();
			}
		}
		
		if ( absint( $args['customer_id'] ) > 0 ) {
			$where[]  = 'r.customer_id = %d';
			$values[] = absint( $args['customer_id'] );
		}
		
		if ( absint( $args['employee_id'] ) > 0 ) {
			$where[]  = 'p.employee_id = %d';
			$values[] = absint( $args['employee_id'] );
		}
		
		$status = sanitize_key( (string) $args['status'] );
		
		if ( $status !== '' ) {
			$where[]  = 'r.status = %s';
			$values[] = $status;
		}
		
		$review_status = sanitize_key( (string) $args['review_status'] );
		
		if ( $review_status !== '' ) {
			if ( $review_status === 'not_reviewed' ) {
				$where[] = 'rv.id IS NULL';
			} else {
				$where[]  = 'rv.status = %s';
				$values[] = $review_status;
			}
		}
		
		$where_sql = implode( ' AND ', $where );
		
		$sql = "SELECT
			r.*,
			t.plan_id AS joined_plan_id,
			t.task_type_id AS joined_task_type_id,
			t.unit_id AS joined_unit_id,
			t.title AS joined_task_title,
			t.description AS joined_task_description,
			t.target_value AS joined_target_value,
			t.target_text AS joined_target_text,
			t.is_required AS joined_is_required,
			t.status AS joined_task_status,
			t.sort_order AS joined_task_sort_order,
			p.plan_date AS joined_plan_date,
			p.title AS joined_plan_title,
			p.description AS joined_plan_description,
			p.employee_id AS joined_employee_id,
			p.status AS joined_plan_status,
			tt.type_key AS joined_type_key,
			tt.label AS joined_type_label,
			tt.primary_value_type AS joined_value_type,
			tt.icon AS joined_type_icon,
			u.label AS joined_unit_label,
			u.symbol AS joined_unit_symbol,
			u.decimal_allowed AS joined_unit_decimal_allowed,
			u.decimals AS joined_unit_decimals,
			rv.id AS joined_review_id,
			rv.reviewer_id AS joined_reviewer_id,
			rv.status AS joined_review_status,
			rv.score AS joined_review_score,
			rv.public_note AS joined_review_public_note,
			rv.private_note AS joined_review_private_note,
			rv.created_at AS joined_review_created_at,
			rv.updated_at AS joined_review_updated_at
		FROM {$this->table_name()} r
		INNER JOIN {$wpdb->prefix}kerp_program_daily_tasks t ON t.id = r.task_id
		INNER JOIN {$wpdb->prefix}kerp_program_daily_plans p ON p.id = t.plan_id
		LEFT JOIN {$wpdb->prefix}kerp_program_task_types tt ON tt.id = t.task_type_id
		LEFT JOIN {$wpdb->prefix}kerp_program_units u ON u.id = t.unit_id
		LEFT JOIN {$this->review_table()} rv ON rv.result_id = r.id
		WHERE {$where_sql}
		ORDER BY p.plan_date ASC, t.sort_order ASC, r.id ASC";
		
		$rows = $wpdb->get_results(
			$wpdb->prepare( $sql, $values ),
			ARRAY_A
		);
		
		$rows = is_array( $rows ) ? $rows : [];
		
		if ( empty( $rows ) ) {
			return $this->empty_week_result( $week_start, $week_end );
		}
		
		$result_ids = array_values(
			array_filter(
				array_map(
					static fn( array $row ): int => absint( $row['id'] ?? 0 ),
					$rows
				)
			)
		);
		
		$meta_map = $this->get_result_meta_map( $result_ids );
		$items    = [];
		$by_date  = [];
		$stats    = [
			'total'              => 0,
			'not_reviewed'       => 0,
			'pending'            => 0,
			'approved'           => 0,
			'revision_requested' => 0,
			'rejected'           => 0,
		];
		
		foreach ( $rows as $row ) {
			$result_id = absint( $row['id'] ?? 0 );
			$item      = $this->hydrate_week_result(
				$row,
				(array) ( $meta_map[ $result_id ] ?? [] )
			);
			
			$date_key = $plans->normalize_date(
				(string) ( $item['plan']['plan_date'] ?? '' )
			);
			
			if ( $date_key === '' ) {
				continue;
			}
			
			$items[]                = $item;
			$by_date[ $date_key ][] = $item;
			$stats['total'] ++;
			
			$review = $item['review'] ?? NULL;
			
			if ( ! is_array( $review ) ) {
				$stats['not_reviewed'] ++;
				continue;
			}
			
			$review_key = sanitize_key( (string) ( $review['status'] ?? 'pending' ) );
			
			if ( isset( $stats[ $review_key ] ) ) {
				$stats[ $review_key ] ++;
			}
		}
		
		return [
			'items'      => $items,
			'by_date'    => $by_date,
			'total'      => count( $items ),
			'week_start' => $week_start,
			'week_end'   => $week_end,
			'stats'      => $stats,
		];
	}
	
	public function save( array $data, int $result_id = 0 ): int|WP_Error {
		global $wpdb;
		
		$result_id = absint( $result_id );
		$existing  = $result_id > 0 ? $this->get( $result_id ) : NULL;
		$task_id   = is_array( $existing )
			? absint( $existing['task_id'] ?? 0 )
			: absint( $data['task_id'] ?? 0 );
		$task      = KERP_Modules_Programs_Tasks::instance()->get( $task_id );
		
		if ( ! is_array( $task ) ) {
			return new WP_Error(
				'kerp_programs_invalid_result_task',
				__( 'آیتم برنامه برای ثبت نتیجه معتبر نیست.', 'kasebi-erp' )
			);
		}
		
		$plan = KERP_Modules_Programs_Plans::instance()->get(
			(int) $task['plan_id']
		);
		
		if ( ! is_array( $plan ) ) {
			return new WP_Error(
				'kerp_programs_invalid_result_plan',
				__( 'برنامه مربوط به نتیجه پیدا نشد.', 'kasebi-erp' )
			);
		}
		
		$customer_id    = (int) $plan['customer_id'];
		$status         = sanitize_key( (string) ( $data['status'] ?? $existing['status'] ?? 'submitted' ) );
		$status_options = KERP_Modules_Programs_Settings::instance()->get_result_status_options();
		
		if ( ! isset( $status_options[ $status ] ) ) {
			$status = 'submitted';
		}
		
		$duplicate = $this->get_by_task( $task_id );
		
		if ( is_array( $duplicate ) && (int) $duplicate['id'] !== $result_id ) {
			return new WP_Error(
				'kerp_programs_duplicate_result',
				__( 'برای این آیتم قبلاً نتیجه ثبت شده است؛ همان نتیجه را ویرایش کنید.', 'kasebi-erp' )
			);
		}
		
		$now = current_time( 'mysql' );
		$row = [
			'task_id'       => $task_id,
			'customer_id'   => $customer_id,
			'value_decimal' => KERP_Modules_Programs_Tasks::instance()
			                                              ->sanitize_decimal( $data['value_decimal'] ?? NULL ),
			'value_text'    => wp_kses_post( (string) ( $data['value_text'] ?? '' ) ),
			'status'        => $status,
			'updated_at'    => $now,
		];
		
		if ( $result_id > 0 ) {
			$result = $wpdb->update(
				$this->table_name(),
				$row,
				[ 'id' => $result_id ]
			);
		} else {
			$row['created_by']   = get_current_user_id();
			$row['submitted_at'] = $now;
			$result              = $wpdb->insert( $this->table_name(), $row );
			$result_id           = (int) $wpdb->insert_id;
		}
		
		if ( $result === FALSE || $result_id <= 0 ) {
			return new WP_Error(
				'kerp_programs_result_save_failed',
				__( 'ذخیره نتیجه انجام نشد.', 'kasebi-erp' )
			);
		}
		
		if ( isset( $data['meta'] ) && is_array( $data['meta'] ) ) {
			foreach ( $data['meta'] as $meta_key => $meta_value ) {
				$meta_key = sanitize_key( (string) $meta_key );
				
				if ( $meta_key !== '' ) {
					KERP_Helpers_Meta::instance()->update_result_meta(
						$result_id,
						$meta_key,
						$meta_value
					);
				}
			}
		}
		
		/*
		 * ثبت Result به معنی completed شدن Task نیست.
		 * وضعیت Task مستقل از گزارش انجام مدیریت می‌شود.
		 */
		do_action( 'kerp_program_result_saved', $result_id, $task_id, $data );
		
		return $result_id;
	}
	
	public function get_review( int $review_id ): ?array {
		global $wpdb;
		
		$review_id = absint( $review_id );
		
		if ( $review_id <= 0 ) {
			return NULL;
		}
		
		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$this->review_table()} WHERE id = %d LIMIT 1",
				$review_id
			),
			ARRAY_A
		);
		
		return is_array( $row ) ? $this->hydrate_review( $row ) : NULL;
	}
	
	public function get_review_by_result( int $result_id ): ?array {
		global $wpdb;
		
		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$this->review_table()} WHERE result_id = %d LIMIT 1",
				absint( $result_id )
			),
			ARRAY_A
		);
		
		return is_array( $row ) ? $this->hydrate_review( $row ) : NULL;
	}
	
	public function save_review( array $data, int $review_id = 0 ): int|WP_Error {
		global $wpdb;
		
		$review_id = absint( $review_id );
		$existing  = $review_id > 0 ? $this->get_review( $review_id ) : NULL;
		$result_id = is_array( $existing )
			? absint( $existing['result_id'] ?? 0 )
			: absint( $data['result_id'] ?? 0 );
		$result    = $this->get( $result_id );
		
		if ( ! is_array( $result ) ) {
			return new WP_Error(
				'kerp_programs_invalid_review_result',
				__( 'نتیجه برای بررسی معتبر نیست.', 'kasebi-erp' )
			);
		}
		
		$duplicate = $this->get_review_by_result( $result_id );
		
		if ( is_array( $duplicate ) && $review_id <= 0 ) {
			$review_id = (int) $duplicate['id'];
			$existing  = $duplicate;
		}
		
		$status = sanitize_key(
			(string) ( $data['status'] ?? $existing['status'] ?? 'pending' )
		);
		
		if ( ! isset( KERP_Modules_Programs_Settings::instance()->get_review_status_options()[ $status ] ) ) {
			return new WP_Error(
				'kerp_programs_invalid_review_status',
				__( 'وضعیت بررسی معتبر نیست.', 'kasebi-erp' )
			);
		}
		
		$score = KERP_Modules_Programs_Tasks::instance()->sanitize_decimal(
			$data['score'] ?? NULL
		);
		$now   = current_time( 'mysql' );
		$row   = [
			'result_id'    => $result_id,
			'reviewer_id'  => get_current_user_id(),
			'status'       => $status,
			'score'        => $score,
			'public_note'  => wp_kses_post( (string) ( $data['public_note'] ?? '' ) ),
			'private_note' => wp_kses_post( (string) ( $data['private_note'] ?? '' ) ),
			'updated_at'   => $now,
		];
		
		if ( $review_id > 0 ) {
			$saved = $wpdb->update(
				$this->review_table(),
				$row,
				[ 'id' => $review_id ]
			);
		} else {
			$row['created_at'] = $now;
			$saved             = $wpdb->insert( $this->review_table(), $row );
			$review_id         = (int) $wpdb->insert_id;
		}
		
		if ( $saved === FALSE || $review_id <= 0 ) {
			return new WP_Error(
				'kerp_programs_review_save_failed',
				__( 'ذخیره بررسی نتیجه انجام نشد.', 'kasebi-erp' )
			);
		}
		
		$result_status = $status === 'pending'
			? 'pending_review'
			: $status;
		
		$wpdb->update(
			$this->table_name(),
			[
				'status'     => $result_status,
				'updated_at' => $now,
			],
			[ 'id' => $result_id ]
		);
		
		if ( isset( $data['meta'] ) && is_array( $data['meta'] ) ) {
			foreach ( $data['meta'] as $meta_key => $meta_value ) {
				$meta_key = sanitize_key( (string) $meta_key );
				
				if ( $meta_key !== '' ) {
					KERP_Helpers_Meta::instance()->update_review_meta(
						$review_id,
						$meta_key,
						$meta_value
					);
				}
			}
		}
		
		do_action( 'kerp_program_result_reviewed', $result_id, $review_id, $status );
		
		return $review_id;
	}
	
	public function calculate_achievement( array $task, array $result ): ?float {
		$target = isset( $task['target_value'] ) && $task['target_value'] !== NULL
			? (float) $task['target_value']
			: 0.0;
		$actual = isset( $result['value_decimal'] ) && $result['value_decimal'] !== NULL
			? (float) $result['value_decimal']
			: 0.0;
		
		if ( $target <= 0 ) {
			return NULL;
		}
		
		return round( ( $actual / $target ) * 100, 2 );
	}
	
	private function build_list_where( array $args ): array {
		global $wpdb;
		
		$where  = [ '1=1' ];
		$values = [];
		
		if ( ! empty( $args['enforce_scope'] ) ) {
			$scope = kerp_list_scope( 'programs' );
			
			if ( $scope === 'none' ) {
				return [ '1=0', [], TRUE ];
			}
			
			if ( $scope === 'own' ) {
				$args['employee_id'] = get_current_user_id();
			}
		}
		
		$search = sanitize_text_field( (string) ( $args['search'] ?? '' ) );
		
		if ( $search !== '' ) {
			$like    = '%' . $wpdb->esc_like( $search ) . '%';
			$where[] = '(
				cu.display_name LIKE %s
				OR cu.user_login LIKE %s
				OR cu.user_email LIKE %s
				OR t.title LIKE %s
				OR p.title LIKE %s
				OR r.value_text LIKE %s
			)';
			array_push( $values, $like, $like, $like, $like, $like, $like );
		}
		
		if ( absint( $args['customer_id'] ?? 0 ) > 0 ) {
			$where[]  = 'r.customer_id = %d';
			$values[] = absint( $args['customer_id'] );
		}
		
		if ( absint( $args['employee_id'] ?? 0 ) > 0 ) {
			$where[]  = 'p.employee_id = %d';
			$values[] = absint( $args['employee_id'] );
		}
		
		$status = sanitize_key( (string) ( $args['status'] ?? '' ) );
		
		if ( $status !== '' ) {
			$where[]  = 'r.status = %s';
			$values[] = $status;
		}
		
		$date_from = KERP_Modules_Programs_Plans::instance()->normalize_date(
			(string) ( $args['date_from'] ?? '' )
		);
		$date_to   = KERP_Modules_Programs_Plans::instance()->normalize_date(
			(string) ( $args['date_to'] ?? '' )
		);
		
		if ( $date_from !== '' ) {
			$where[]  = 'p.plan_date >= %s';
			$values[] = $date_from;
		}
		
		if ( $date_to !== '' ) {
			$where[]  = 'p.plan_date <= %s';
			$values[] = $date_to;
		}
		
		return [ implode( ' AND ', $where ), $values, FALSE ];
	}
	
	private function hydrate_list_result( array $row ): array {
		$result = [
			'id'                 => absint( $row['id'] ?? 0 ),
			'task_id'            => absint( $row['task_id'] ?? 0 ),
			'customer_id'        => absint( $row['customer_id'] ?? 0 ),
			'value_decimal'      => $row['value_decimal'] ?? NULL,
			'value_text'         => (string) ( $row['value_text'] ?? '' ),
			'status'             => sanitize_key( (string) ( $row['status'] ?? 'submitted' ) ),
			'created_by'         => absint( $row['created_by'] ?? 0 ),
			'submitted_at'       => (string) ( $row['submitted_at'] ?? '' ),
			'updated_at'         => (string) ( $row['updated_at'] ?? '' ),
			'plan_id'            => absint( $row['plan_id'] ?? 0 ),
			'task_type_id'       => absint( $row['task_type_id'] ?? 0 ),
			'unit_id'            => absint( $row['unit_id'] ?? 0 ),
			'task_title'         => (string) ( $row['task_title'] ?? '' ),
			'target_value'       => $row['target_value'] ?? NULL,
			'target_text'        => (string) ( $row['target_text'] ?? '' ),
			'task_status'        => sanitize_key( (string) ( $row['task_status'] ?? '' ) ),
			'plan_date'          => (string) ( $row['plan_date'] ?? '' ),
			'plan_title'         => (string) ( $row['plan_title'] ?? '' ),
			'employee_id'        => absint( $row['employee_id'] ?? 0 ),
			'plan_status'        => sanitize_key( (string) ( $row['plan_status'] ?? '' ) ),
			'type_key'           => sanitize_key( (string) ( $row['type_key'] ?? '' ) ),
			'type_label'         => (string) ( $row['type_label'] ?? '' ),
			'primary_value_type' => sanitize_key( (string) ( $row['primary_value_type'] ?? '' ) ),
			'type_icon'          => (string) ( $row['type_icon'] ?? '' ),
			'unit_label'         => (string) ( $row['unit_label'] ?? '' ),
			'unit_symbol'        => (string) ( $row['unit_symbol'] ?? '' ),
			'customer_name'      => (string) ( $row['customer_name'] ?? '' ),
			'employee_name'      => (string) ( $row['employee_name'] ?? '' ),
		];
		
		$review_id        = absint( $row['review_id'] ?? 0 );
		$result['review'] = $review_id > 0
			? [
				'id'          => $review_id,
				'result_id'   => absint( $row['id'] ?? 0 ),
				'reviewer_id' => absint( $row['reviewer_id'] ?? 0 ),
				'status'      => sanitize_key( (string) ( $row['review_status'] ?? 'pending' ) ),
				'score'       => $row['review_score'] ?? NULL,
			]
			: NULL;
		
		return $result;
	}
	
	private function empty_week_result( string $week_start, string $week_end ): array {
		return [
			'items'      => [],
			'by_date'    => [],
			'total'      => 0,
			'week_start' => $week_start,
			'week_end'   => $week_end,
			'stats'      => [
				'total'              => 0,
				'not_reviewed'       => 0,
				'pending'            => 0,
				'approved'           => 0,
				'revision_requested' => 0,
				'rejected'           => 0,
			],
		];
	}
	
	private function get_result_meta_map( array $result_ids ): array {
		global $wpdb;
		
		$result_ids = array_values(
			array_unique(
				array_filter(
					array_map( 'absint', $result_ids )
				)
			)
		);
		
		if ( empty( $result_ids ) ) {
			return [];
		}
		
		$placeholders = implode(
			',',
			array_fill( 0, count( $result_ids ), '%d' )
		);
		$meta_table   = KERP_Helpers_Meta::instance()->table_name();
		$values       = array_merge(
			[ KERP_Helpers_Meta::TYPE_PROGRAM_RESULT ],
			$result_ids
		);
		
		$sql  = $wpdb->prepare(
			"SELECT object_id, meta_key, meta_value
			FROM {$meta_table}
			WHERE object_type = %s
			AND object_id IN ({$placeholders})
			ORDER BY meta_id ASC",
			$values
		);
		$rows = $wpdb->get_results( $sql, ARRAY_A );
		$map  = [];
		
		foreach ( (array) $rows as $row ) {
			$object_id = absint( $row['object_id'] ?? 0 );
			$meta_key  = sanitize_key( (string) ( $row['meta_key'] ?? '' ) );
			
			if ( $object_id <= 0 || $meta_key === '' ) {
				continue;
			}
			
			$map[ $object_id ][ $meta_key ] = maybe_unserialize(
				$row['meta_value'] ?? ''
			);
		}
		
		return $map;
	}
	
	private function hydrate_week_result( array $row, array $meta ): array {
		$result = [
			'id'            => absint( $row['id'] ?? 0 ),
			'task_id'       => absint( $row['task_id'] ?? 0 ),
			'customer_id'   => absint( $row['customer_id'] ?? 0 ),
			'value_decimal' => $row['value_decimal'] ?? NULL,
			'value_text'    => (string) ( $row['value_text'] ?? '' ),
			'status'        => sanitize_key( (string) ( $row['status'] ?? 'submitted' ) ),
			'created_by'    => absint( $row['created_by'] ?? 0 ),
			'submitted_at'  => (string) ( $row['submitted_at'] ?? '' ),
			'updated_at'    => (string) ( $row['updated_at'] ?? '' ),
			'meta'          => $meta,
		];
		
		$result['task'] = [
			'id'           => absint( $row['task_id'] ?? 0 ),
			'plan_id'      => absint( $row['joined_plan_id'] ?? 0 ),
			'task_type_id' => absint( $row['joined_task_type_id'] ?? 0 ),
			'unit_id'      => absint( $row['joined_unit_id'] ?? 0 ),
			'title'        => (string) ( $row['joined_task_title'] ?? '' ),
			'description'  => (string) ( $row['joined_task_description'] ?? '' ),
			'target_value' => $row['joined_target_value'] ?? NULL,
			'target_text'  => (string) ( $row['joined_target_text'] ?? '' ),
			'is_required'  => ! empty( $row['joined_is_required'] ) ? 1 : 0,
			'status'       => sanitize_key( (string) ( $row['joined_task_status'] ?? 'active' ) ),
			'sort_order'   => intval( $row['joined_task_sort_order'] ?? 10 ),
		];
		
		$result['plan'] = [
			'id'          => absint( $row['joined_plan_id'] ?? 0 ),
			'customer_id' => absint( $row['customer_id'] ?? 0 ),
			'plan_date'   => (string) ( $row['joined_plan_date'] ?? '' ),
			'title'       => (string) ( $row['joined_plan_title'] ?? '' ),
			'description' => (string) ( $row['joined_plan_description'] ?? '' ),
			'employee_id' => absint( $row['joined_employee_id'] ?? 0 ),
			'status'      => sanitize_key( (string) ( $row['joined_plan_status'] ?? '' ) ),
		];
		
		$result['type'] = [
			'id'                 => absint( $row['joined_task_type_id'] ?? 0 ),
			'type_key'           => sanitize_key( (string) ( $row['joined_type_key'] ?? '' ) ),
			'label'              => (string) ( $row['joined_type_label'] ?? '' ),
			'primary_value_type' => sanitize_key( (string) ( $row['joined_value_type'] ?? '' ) ),
			'icon'               => (string) ( $row['joined_type_icon'] ?? '' ),
		];
		
		$result['unit'] = [
			'id'              => absint( $row['joined_unit_id'] ?? 0 ),
			'label'           => (string) ( $row['joined_unit_label'] ?? '' ),
			'symbol'          => (string) ( $row['joined_unit_symbol'] ?? '' ),
			'decimal_allowed' => ! empty( $row['joined_unit_decimal_allowed'] ) ? 1 : 0,
			'decimals'        => absint( $row['joined_unit_decimals'] ?? 0 ),
		];
		
		$review_id = absint( $row['joined_review_id'] ?? 0 );
		
		$result['review'] = $review_id > 0
			? [
				'id'           => $review_id,
				'result_id'    => absint( $row['id'] ?? 0 ),
				'reviewer_id'  => absint( $row['joined_reviewer_id'] ?? 0 ),
				'status'       => sanitize_key( (string) ( $row['joined_review_status'] ?? 'pending' ) ),
				'score'        => $row['joined_review_score'] ?? NULL,
				'public_note'  => (string) ( $row['joined_review_public_note'] ?? '' ),
				'private_note' => (string) ( $row['joined_review_private_note'] ?? '' ),
				'created_at'   => (string) ( $row['joined_review_created_at'] ?? '' ),
				'updated_at'   => (string) ( $row['joined_review_updated_at'] ?? '' ),
			]
			: NULL;
		
		return $result;
	}
	
	private function hydrate_result( array $row ): array {
		$row['id']          = absint( $row['id'] ?? 0 );
		$row['task_id']     = absint( $row['task_id'] ?? 0 );
		$row['customer_id'] = absint( $row['customer_id'] ?? 0 );
		$row['review']      = $this->get_review_by_result( (int) $row['id'] );
		
		return $row;
	}
	
	private function hydrate_review( array $row ): array {
		$row['id']          = absint( $row['id'] ?? 0 );
		$row['result_id']   = absint( $row['result_id'] ?? 0 );
		$row['reviewer_id'] = absint( $row['reviewer_id'] ?? 0 );
		
		return $row;
	}
	
}
