<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Programs_Resources {
	private static ?self $instance = NULL;
	public static function instance(): self { if ( self::$instance === NULL ) { self::$instance = new self(); } return self::$instance; }
	private function __construct() {}
	private function __clone() {}
	public function __wakeup(): void { throw new LogicException( 'Cannot unserialize a singleton.' ); }
	public function table_name(): string { global $wpdb; return $wpdb->prefix . 'kerp_program_task_resources'; }

	public function get_types(): array {
		$types = [
			'content' => [ 'label' => __( 'محتوا', 'kasebi-erp' ), 'icon' => 'ni ni-notes' ],
			'video' => [ 'label' => __( 'ویدیو', 'kasebi-erp' ), 'icon' => 'ni ni-play-circle' ],
			'file' => [ 'label' => __( 'فایل', 'kasebi-erp' ), 'icon' => 'ni ni-file' ],
			'skyroom' => [ 'label' => __( 'کلاس اسکای‌روم', 'kasebi-erp' ), 'icon' => 'ni ni-video' ],
			'exam' => [ 'label' => __( 'آزمون', 'kasebi-erp' ), 'icon' => 'ni ni-edit-alt' ],
			'link' => [ 'label' => __( 'لینک آموزشی', 'kasebi-erp' ), 'icon' => 'ni ni-link' ],
		];
		if ( $this->is_learndash_active() ) {
			$types['learndash'] = [ 'label' => __( 'ویدیو آموزشی (LearnDash)', 'kasebi-erp' ), 'icon' => 'ni ni-book-read' ];
		}
		$filtered = apply_filters( 'kerp_program_resource_types', $types );
		return is_array( $filtered ) ? $filtered : $types;
	}
	public function get_type_options(): array { $out = []; foreach ( $this->get_types() as $key => $type ) { $out[ sanitize_key( (string) $key ) ] = sanitize_text_field( (string) ( $type['label'] ?? $key ) ); } return $out; }
	public function is_learndash_active(): bool { return defined( 'LEARNDASH_VERSION' ) || class_exists( 'SFWD_LMS' ); }
	public function get_learndash_post_types(): array {
		return array_values( array_filter( [ 'sfwd-lessons', 'sfwd-topic' ], 'post_type_exists' ) );
	}
	public function search_learndash( string $search, int $page = 1, int $limit = 20 ): array {
		if ( ! $this->is_learndash_active() || empty( $this->get_learndash_post_types() ) ) { return []; }
		$query = new WP_Query( [ 'post_type' => $this->get_learndash_post_types(), 'post_status' => 'publish', 's' => sanitize_text_field( $search ), 'posts_per_page' => max( 1, min( 50, $limit ) ), 'paged' => max( 1, $page ), 'orderby' => 'title', 'order' => 'ASC', 'no_found_rows' => TRUE ] );
		$labels = [ 'sfwd-lessons' => __( 'درس', 'kasebi-erp' ), 'sfwd-topic' => __( 'سرفصل', 'kasebi-erp' ) ];
		return array_map( static function( WP_Post $post ) use ( $labels ): array { return [ 'id' => $post->ID, 'text' => sprintf( '%1$s — %2$s', $post->post_title, $labels[ $post->post_type ] ?? $post->post_type ) ]; }, $query->posts );
	}
	public function get( int $id ): ?array { global $wpdb; $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$this->table_name()} WHERE id=%d LIMIT 1", absint( $id ) ), ARRAY_A ); return is_array( $row ) ? $this->hydrate( $row ) : NULL; }
	public function get_by_task( int $task_id ): array { global $wpdb; $rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$this->table_name()} WHERE task_id=%d ORDER BY sort_order,id", absint( $task_id ) ), ARRAY_A ); return array_map( [ $this, 'hydrate' ], (array) $rows ); }

	public function save( array $data, int $id = 0 ): int|WP_Error {
		global $wpdb; $id = absint( $id ); $existing = $id ? $this->get( $id ) : NULL;
		$task_id = absint( $data['task_id'] ?? $existing['task_id'] ?? 0 );
		if ( ! KERP_Modules_Programs_Tasks::instance()->get( $task_id ) ) { return new WP_Error( 'kerp_resource_invalid_task', __( 'آیتم برنامه پیدا نشد.', 'kasebi-erp' ) ); }
		$type = sanitize_key( (string) ( $data['type_key'] ?? $existing['type_key'] ?? 'link' ) ); $types = $this->get_types();
		if ( ! isset( $types[ $type ] ) ) { return new WP_Error( 'kerp_resource_invalid_type', __( 'نوع محتوا معتبر نیست.', 'kasebi-erp' ) ); }
		$title = sanitize_text_field( (string) ( $data['title'] ?? '' ) );
		$description = $type === 'content' ? wp_kses_post( (string) ( $data['description'] ?? '' ) ) : sanitize_textarea_field( (string) ( $data['description'] ?? '' ) );
		$reference_id = absint( $data['reference_id'] ?? 0 );
		$url = esc_url_raw( trim( (string) ( $data['resource_url'] ?? '' ) ) );
		if ( $type === 'learndash' ) {
			$post = $reference_id ? get_post( $reference_id ) : NULL;
			if ( ! $this->is_learndash_active() || ! $post instanceof WP_Post || ! in_array( $post->post_type, $this->get_learndash_post_types(), TRUE ) || $post->post_status !== 'publish' ) { return new WP_Error( 'kerp_resource_invalid_learndash', __( 'درس یا سرفصل LearnDash معتبر نیست.', 'kasebi-erp' ) ); }
			$url = get_permalink( $post );
			if ( $title === '' ) { $title = get_the_title( $post ); }
		} elseif ( $type === 'skyroom' ) {
			$room_id = sanitize_text_field( (string) ( $data['room_id'] ?? '' ) );
			if ( $room_id === '' ) { return new WP_Error( 'kerp_resource_room_required', __( 'شناسه اتاق اسکای‌روم الزامی است.', 'kasebi-erp' ) ); }
			$url = esc_url_raw( apply_filters( 'kerp_program_skyroom_room_url', 'https://www.skyroom.online/ch/' . rawurlencode( $room_id ), $room_id ) );
		} elseif ( $type === 'content' ) {
			$url = '';
			if ( trim( wp_strip_all_tags( $description ) ) === '' ) { return new WP_Error( 'kerp_resource_content_required', __( 'متن محتوا الزامی است.', 'kasebi-erp' ) ); }
		}
		if ( $title === '' || ( $type !== 'content' && $url === '' ) ) { return new WP_Error( 'kerp_resource_required', __( 'عنوان و اطلاعات محتوا الزامی است.', 'kasebi-erp' ) ); }
		$now = current_time( 'mysql' ); $row = [ 'task_id' => $task_id, 'type_key' => $type, 'title' => $title, 'resource_url' => $url, 'reference_id' => $reference_id, 'description' => $description, 'sort_order' => intval( $data['sort_order'] ?? 10 ), 'updated_at' => $now ];
		if ( $id ) { if ( ! $existing ) { return new WP_Error( 'kerp_resource_not_found', __( 'محتوا پیدا نشد.', 'kasebi-erp' ) ); } $result = $wpdb->update( $this->table_name(), $row, [ 'id' => $id ] ); }
		else { $row['created_by'] = get_current_user_id(); $row['created_at'] = $now; $result = $wpdb->insert( $this->table_name(), $row ); $id = (int) $wpdb->insert_id; }
		return $result !== FALSE && $id > 0 ? $id : new WP_Error( 'kerp_resource_save_failed', __( 'ذخیره محتوا انجام نشد.', 'kasebi-erp' ) );
	}
	public function delete( int $id ): bool|WP_Error { global $wpdb; if ( ! $this->get( $id ) ) { return new WP_Error( 'kerp_resource_not_found', __( 'محتوا پیدا نشد.', 'kasebi-erp' ) ); } return $wpdb->delete( $this->table_name(), [ 'id' => absint( $id ) ], [ '%d' ] ) !== FALSE ? TRUE : new WP_Error( 'kerp_resource_delete_failed', __( 'حذف محتوا انجام نشد.', 'kasebi-erp' ) ); }
	public function delete_by_task( int $task_id ): void { global $wpdb; $wpdb->delete( $this->table_name(), [ 'task_id' => absint( $task_id ) ], [ '%d' ] ); }
	private function hydrate( array $row ): array { $row['id'] = absint( $row['id'] ?? 0 ); $row['task_id'] = absint( $row['task_id'] ?? 0 ); $row['reference_id'] = absint( $row['reference_id'] ?? 0 ); $row['sort_order'] = intval( $row['sort_order'] ?? 10 ); $type = $this->get_types()[ sanitize_key( (string) ( $row['type_key'] ?? '' ) ) ] ?? []; $row['type_label'] = (string) ( $type['label'] ?? __( 'محتوا', 'kasebi-erp' ) ); $row['type_icon'] = (string) ( $type['icon'] ?? 'ni ni-link' ); $row['reference_title'] = $row['reference_id'] ? get_the_title( $row['reference_id'] ) : ''; $row['room_id'] = (string) ( $row['type_key'] ?? '' ) === 'skyroom' ? rawurldecode( basename( (string) wp_parse_url( (string) ( $row['resource_url'] ?? '' ), PHP_URL_PATH ) ) ) : ''; return $row; }
}
