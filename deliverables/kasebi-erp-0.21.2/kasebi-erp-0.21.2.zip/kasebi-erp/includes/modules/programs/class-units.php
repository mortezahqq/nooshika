<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Programs_Units {

	private static ?self $instance = NULL;

	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	private function __construct() {}

	private function __clone() {}

	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}

	public function table_name(): string {
		global $wpdb;

		return $wpdb->prefix . 'kerp_program_units';
	}

	public function get( int $unit_id ): ?array {
		global $wpdb;

		$unit_id = absint( $unit_id );
		if ( $unit_id <= 0 ) {
			return NULL;
		}

		$row = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$this->table_name()} WHERE id = %d LIMIT 1", $unit_id ),
			ARRAY_A
		);

		return is_array( $row ) ? $this->hydrate( $row ) : NULL;
	}

	public function get_by_key( string $unit_key ): ?array {
		global $wpdb;

		$unit_key = sanitize_key( $unit_key );
		if ( $unit_key === '' ) {
			return NULL;
		}

		$row = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$this->table_name()} WHERE unit_key = %s LIMIT 1", $unit_key ),
			ARRAY_A
		);

		return is_array( $row ) ? $this->hydrate( $row ) : NULL;
	}

	public function all( bool $active_only = FALSE ): array {
		global $wpdb;

		$where = $active_only ? ' WHERE active = 1' : '';
		$rows  = $wpdb->get_results(
			"SELECT * FROM {$this->table_name()}{$where} ORDER BY sort_order ASC, id ASC",
			ARRAY_A
		);

		return array_map( [ $this, 'hydrate' ], (array) $rows );
	}

	public function get_options( bool $active_only = TRUE ): array {
		$options = [ 0 => __( 'بدون واحد', 'kasebi-erp' ) ];
		foreach ( $this->all( $active_only ) as $unit ) {
			$label = (string) $unit['label'];
			if ( (string) $unit['symbol'] !== '' ) {
				$label .= ' (' . (string) $unit['symbol'] . ')';
			}
			$options[ (int) $unit['id'] ] = $label;
		}

		return $options;
	}

	public function get_value_type_options(): array {
		return [
			'integer' => __( 'عدد صحیح', 'kasebi-erp' ),
			'decimal' => __( 'عدد اعشاری', 'kasebi-erp' ),
			'percent' => __( 'درصد', 'kasebi-erp' ),
			'score'   => __( 'نمره', 'kasebi-erp' ),
			'time'    => __( 'زمان', 'kasebi-erp' ),
		];
	}

	public function save( array $data, int $unit_id = 0 ): int|WP_Error {
		global $wpdb;

		$unit_id   = absint( $unit_id );
		$existing  = $unit_id > 0 ? $this->get( $unit_id ) : NULL;
		$unit_key  = sanitize_key( (string) ( $data['unit_key'] ?? $existing['unit_key'] ?? '' ) );
		$label     = sanitize_text_field( (string) ( $data['label'] ?? '' ) );
		$value_type = sanitize_key( (string) ( $data['value_type'] ?? 'integer' ) );

		if ( $unit_key === '' || $label === '' ) {
			return new WP_Error( 'kerp_programs_invalid_unit', __( 'کلید و عنوان واحد الزامی است.', 'kasebi-erp' ) );
		}
		if ( ! isset( $this->get_value_type_options()[ $value_type ] ) ) {
			return new WP_Error( 'kerp_programs_invalid_unit_type', __( 'نوع مقدار واحد معتبر نیست.', 'kasebi-erp' ) );
		}

		$duplicate = $this->get_by_key( $unit_key );
		if ( is_array( $duplicate ) && (int) $duplicate['id'] !== $unit_id ) {
			return new WP_Error( 'kerp_programs_duplicate_unit', __( 'این کلید واحد قبلاً استفاده شده است.', 'kasebi-erp' ) );
		}

		$decimal_allowed = ! empty( $data['decimal_allowed'] ) || $value_type === 'decimal';
		$row = [
			'unit_key'        => $unit_key,
			'label'           => $label,
			'symbol'          => sanitize_text_field( (string) ( $data['symbol'] ?? '' ) ),
			'value_type'      => $value_type,
			'decimal_allowed' => $decimal_allowed ? 1 : 0,
			'decimals'        => $decimal_allowed ? max( 0, min( 6, absint( $data['decimals'] ?? 2 ) ) ) : 0,
			'active'          => ! empty( $data['active'] ) ? 1 : 0,
			'system'          => ! empty( $existing['system'] ) ? 1 : ( ! empty( $data['system'] ) ? 1 : 0 ),
			'sort_order'      => intval( $data['sort_order'] ?? 10 ),
		];

		if ( $unit_id > 0 ) {
			$result = $wpdb->update( $this->table_name(), $row, [ 'id' => $unit_id ] );
		} else {
			$result  = $wpdb->insert( $this->table_name(), $row );
			$unit_id = (int) $wpdb->insert_id;
		}

		if ( $result === FALSE || $unit_id <= 0 ) {
			return new WP_Error( 'kerp_programs_unit_save_failed', __( 'ذخیره واحد انجام نشد.', 'kasebi-erp' ) );
		}

		return $unit_id;
	}

	public function delete( int $unit_id ): bool|WP_Error {
		global $wpdb;

		$unit = $this->get( $unit_id );
		if ( ! is_array( $unit ) ) {
			return new WP_Error( 'kerp_programs_unit_not_found', __( 'واحد پیدا نشد.', 'kasebi-erp' ) );
		}
		if ( ! empty( $unit['system'] ) ) {
			return new WP_Error( 'kerp_programs_system_unit', __( 'واحد سیستمی قابل حذف نیست.', 'kasebi-erp' ) );
		}
		if ( $this->count_usage( $unit_id ) > 0 ) {
			return new WP_Error( 'kerp_programs_unit_in_use', __( 'این واحد در برنامه‌ها استفاده شده و قابل حذف نیست.', 'kasebi-erp' ) );
		}

		$result = $wpdb->delete( $this->table_name(), [ 'id' => $unit_id ], [ '%d' ] );
		if ( $result === FALSE ) {
			return new WP_Error( 'kerp_programs_unit_delete_failed', __( 'حذف واحد انجام نشد.', 'kasebi-erp' ) );
		}

		KERP_Helpers_Meta::instance()->delete_unit_meta( $unit_id );

		return TRUE;
	}

	public function count_usage( int $unit_id ): int {
		global $wpdb;

		$unit_id  = absint( $unit_id );
		$daily    = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}kerp_program_daily_tasks WHERE unit_id = %d", $unit_id ) );
		$template = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}kerp_program_template_tasks WHERE unit_id = %d", $unit_id ) );

		return $daily + $template;
	}

	public function seed_defaults(): void {
		$defaults = [
			[ 'unit_key' => 'test', 'label' => 'تست', 'symbol' => 'تست', 'value_type' => 'integer', 'system' => 1, 'sort_order' => 10 ],
			[ 'unit_key' => 'page', 'label' => 'صفحه', 'symbol' => 'صفحه', 'value_type' => 'integer', 'system' => 1, 'sort_order' => 20 ],
			[ 'unit_key' => 'minute', 'label' => 'دقیقه', 'symbol' => 'دقیقه', 'value_type' => 'integer', 'system' => 1, 'sort_order' => 30 ],
			[ 'unit_key' => 'hour', 'label' => 'ساعت', 'symbol' => 'ساعت', 'value_type' => 'decimal', 'decimal_allowed' => 1, 'decimals' => 2, 'system' => 1, 'sort_order' => 40 ],
			[ 'unit_key' => 'percent', 'label' => 'درصد', 'symbol' => '%', 'value_type' => 'percent', 'decimal_allowed' => 1, 'decimals' => 2, 'system' => 1, 'sort_order' => 50 ],
			[ 'unit_key' => 'score', 'label' => 'نمره', 'symbol' => 'نمره', 'value_type' => 'score', 'decimal_allowed' => 1, 'decimals' => 2, 'system' => 1, 'sort_order' => 60 ],
		];

		foreach ( $defaults as $item ) {
			if ( $this->get_by_key( $item['unit_key'] ) ) {
				continue;
			}
			$item['active'] = 1;
			$this->save( $item );
		}
	}

	private function hydrate( array $row ): array {
		$row['id']              = absint( $row['id'] ?? 0 );
		$row['active']          = ! empty( $row['active'] );
		$row['system']          = ! empty( $row['system'] );
		$row['decimal_allowed'] = ! empty( $row['decimal_allowed'] );
		$row['decimals']        = absint( $row['decimals'] ?? 0 );
		$row['sort_order']      = intval( $row['sort_order'] ?? 10 );

		return $row;
	}
}
