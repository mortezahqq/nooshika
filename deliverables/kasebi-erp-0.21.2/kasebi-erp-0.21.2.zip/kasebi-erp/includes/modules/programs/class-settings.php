<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Programs_Settings {

	private const OPTION_KEY = 'kerp_programs_settings';

	private static ?self $instance = NULL;

	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	private function __construct() {}

	private function __clone() {}

	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}

	public function defaults(): array {
		return [
			'plan_singular_label'     => 'برنامه روزانه',
			'plan_plural_label'       => 'برنامه‌های روزانه',
			'template_singular_label' => 'قالب برنامه',
			'template_plural_label'   => 'قالب‌های برنامه',
			'task_singular_label'     => 'آیتم برنامه',
			'task_plural_label'       => 'آیتم‌های برنامه',
			'default_plan_status'     => 'draft',
			'default_per_page'        => 20,
		];
	}

	public function all(): array {
		$stored = get_option( self::OPTION_KEY, [] );
		$stored = is_array( $stored ) ? $stored : [];

		return wp_parse_args( $stored, $this->defaults() );
	}

	public function get( string $key, mixed $default = NULL ): mixed {
		$data = $this->all();

		return array_key_exists( $key, $data ) ? $data[ $key ] : $default;
	}

	public function update( array $values ): void {
		$current = $this->all();
		$labels  = [
			'plan_singular_label',
			'plan_plural_label',
			'template_singular_label',
			'template_plural_label',
			'task_singular_label',
			'task_plural_label',
		];

		foreach ( $labels as $key ) {
			if ( ! array_key_exists( $key, $values ) ) {
				continue;
			}

			$value = sanitize_text_field( (string) $values[ $key ] );
			if ( $value !== '' ) {
				$current[ $key ] = $value;
			}
		}

		if ( array_key_exists( 'default_plan_status', $values ) ) {
			$status = sanitize_key( (string) $values['default_plan_status'] );
			if ( isset( $this->get_plan_status_options()[ $status ] ) ) {
				$current['default_plan_status'] = $status;
			}
		}

		if ( array_key_exists( 'default_per_page', $values ) ) {
			$current['default_per_page'] = max( 5, min( 200, absint( $values['default_per_page'] ) ) );
		}

		update_option( self::OPTION_KEY, $current, FALSE );
	}

	public function get_plan_status_options(): array {
		return [
			'draft'     => __( 'پیش‌نویس', 'kasebi-erp' ),
			'published' => __( 'منتشرشده', 'kasebi-erp' ),
			'archived'  => __( 'آرشیوشده', 'kasebi-erp' ),
		];
	}

	public function get_result_status_options(): array {
		return [
			'submitted'          => __( 'ثبت‌شده', 'kasebi-erp' ),
			'pending_review'     => __( 'در انتظار بررسی', 'kasebi-erp' ),
			'revision_requested' => __( 'نیازمند اصلاح', 'kasebi-erp' ),
			'approved'           => __( 'تأییدشده', 'kasebi-erp' ),
			'rejected'           => __( 'ردشده', 'kasebi-erp' ),
		];
	}

	public function get_review_status_options(): array {
		return [
			'pending'            => __( 'در انتظار بررسی', 'kasebi-erp' ),
			'approved'           => __( 'تأیید', 'kasebi-erp' ),
			'revision_requested' => __( 'درخواست اصلاح', 'kasebi-erp' ),
			'rejected'           => __( 'رد', 'kasebi-erp' ),
		];
	}

	public function get_plan_singular_label(): string {
		return (string) $this->get( 'plan_singular_label', 'برنامه روزانه' );
	}

	public function get_plan_plural_label(): string {
		return (string) $this->get( 'plan_plural_label', 'برنامه‌های روزانه' );
	}

	public function get_template_singular_label(): string {
		return (string) $this->get( 'template_singular_label', 'قالب برنامه' );
	}

	public function get_template_plural_label(): string {
		return (string) $this->get( 'template_plural_label', 'قالب‌های برنامه' );
	}

	public function get_task_singular_label(): string {
		return (string) $this->get( 'task_singular_label', 'آیتم برنامه' );
	}

	public function get_task_plural_label(): string {
		return (string) $this->get( 'task_plural_label', 'آیتم‌های برنامه' );
	}
}
