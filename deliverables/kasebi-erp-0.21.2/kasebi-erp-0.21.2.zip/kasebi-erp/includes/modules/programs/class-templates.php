<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Programs_Templates {
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public function table_name(): string {
		global $wpdb;
		
		return $wpdb->prefix . 'kerp_program_templates';
	}
	
	public function day_table(): string {
		global $wpdb;
		
		return $wpdb->prefix . 'kerp_program_template_days';
	}
	
	public function task_table(): string {
		global $wpdb;
		
		return $wpdb->prefix . 'kerp_program_template_tasks';
	}
	
	public function get_status_options(): array {
		return [
			'active'   => __( 'فعال', 'kasebi-erp' ),
			'archived' => __( 'آرشیوشده', 'kasebi-erp' ),
		];
	}
	
	public function get( int $template_id ): ?array {
		global $wpdb;
		$template_id = absint( $template_id );
		if ( $template_id <= 0 ) {
			return NULL;
		}
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$this->table_name()} WHERE id = %d LIMIT 1", $template_id ), ARRAY_A );
		
		return is_array( $row ) ? $this->hydrate_template( $row ) : NULL;
	}
	
	public function find( array $args = [] ): array {
		global $wpdb;
		$args   = wp_parse_args( $args, [ 'search' => '', 'status' => '', 'page_number' => 1, 'per_page' => 20 ] );
		$where  = [ '1=1' ];
		$values = [];
		$search = sanitize_text_field( (string) $args['search'] );
		$status = sanitize_key( (string) $args['status'] );
		if ( $search !== '' ) {
			$where[]  = 'title LIKE %s';
			$values[] = '%' . $wpdb->esc_like( $search ) . '%';
		}
		if ( $status !== '' ) {
			$where[]  = 'status = %s';
			$values[] = $status;
		}
		$page_number = max( 1, absint( $args['page_number'] ) );
		$per_page    = max( 1, min( 200, absint( $args['per_page'] ) ) );
		$offset      = ( $page_number - 1 ) * $per_page;
		$where_sql   = implode( ' AND ', $where );
		$count_sql   = "SELECT COUNT(*) FROM {$this->table_name()} WHERE {$where_sql}";
		$data_sql    = "SELECT * FROM {$this->table_name()} WHERE {$where_sql} ORDER BY updated_at DESC, id DESC LIMIT %d OFFSET %d";
		$total       = $values ? (int) $wpdb->get_var( $wpdb->prepare( $count_sql, $values ) ) : (int) $wpdb->get_var( $count_sql );
		$rows        = $wpdb->get_results( $wpdb->prepare( $data_sql, array_merge( $values, [
			$per_page,
			$offset,
		] ) ), ARRAY_A );
		
		return [
			'items'       => array_map( [ $this, 'hydrate_template' ], (array) $rows ),
			'total'       => $total,
			'page_number' => $page_number,
			'per_page'    => $per_page,
			'total_pages' => max( 1, (int) ceil( $total / $per_page ) ),
		];
	}
	
	public function get_options( bool $active_only = TRUE ): array {
		$result  = $this->find( [ 'status' => $active_only ? 'active' : '', 'per_page' => 200 ] );
		$options = [];
		foreach ( (array) $result['items'] as $template ) {
			$options[ (int) $template['id'] ] = (string) $template['title'];
		}
		
		return $options;
	}
	
	public function save( array $data, int $template_id = 0 ): int|WP_Error {
		global $wpdb;
		$template_id = absint( $template_id );
		$existing    = $template_id > 0 ? $this->get( $template_id ) : NULL;
		$title       = sanitize_text_field( (string) ( $data['title'] ?? '' ) );
		$status      = sanitize_key( (string) ( $data['status'] ?? $existing['status'] ?? 'active' ) );
		$day_count   = max( 1, min( 365, absint( $data['day_count'] ?? $existing['day_count'] ?? 1 ) ) );
		if ( $title === '' ) {
			return new WP_Error( 'kerp_programs_template_title_required', __( 'عنوان قالب برنامه الزامی است.', 'kasebi-erp' ) );
		}
		if ( ! isset( $this->get_status_options()[ $status ] ) ) {
			return new WP_Error( 'kerp_programs_invalid_template_status', __( 'وضعیت قالب برنامه معتبر نیست.', 'kasebi-erp' ) );
		}
		$now = current_time( 'mysql' );
		$row = [
			'title'       => $title,
			'description' => wp_kses_post( (string) ( $data['description'] ?? '' ) ),
			'status'      => $status,
			'day_count'   => $day_count,
			'updated_at'  => $now,
		];
		if ( $template_id > 0 ) {
			$result = $wpdb->update( $this->table_name(), $row, [ 'id' => $template_id ] );
		} else {
			$row['created_by'] = get_current_user_id();
			$row['created_at'] = $now;
			$result            = $wpdb->insert( $this->table_name(), $row );
			$template_id       = (int) $wpdb->insert_id;
		}
		if ( $result === FALSE || $template_id <= 0 ) {
			return new WP_Error( 'kerp_programs_template_save_failed', __( 'ذخیره قالب برنامه انجام نشد.', 'kasebi-erp' ) );
		}
		$days_result = $this->ensure_days(
			$template_id,
			$day_count
		);
		
		if ( is_wp_error( $days_result ) ) {
			return $days_result;
		}
		do_action( 'kerp_program_template_saved', $template_id, $data );
		
		return $template_id;
	}

	/** Import the bundled seven-day sample once and return the existing copy on later runs. */
	public function import_experimental_exam_sample(): array|WP_Error {
		global $wpdb;
		$sample_key = 'experimental_exam_7_day';
		$meta       = KERP_Helpers_Meta::instance();
		$lock       = 'kerp_template_' . md5( $this->table_name() . $sample_key );
		if ( (int) $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 0)', $lock ) ) !== 1 ) {
			return new WP_Error( 'kerp_programs_sample_import_busy', __( 'ایمپورت دیگری در حال اجراست؛ کمی بعد دوباره تلاش کنید.', 'kasebi-erp' ) );
		}
		try {
			$existing_id = absint( $wpdb->get_var( $wpdb->prepare(
				"SELECT t.id FROM {$this->table_name()} t INNER JOIN {$meta->table_name()} m ON m.object_id = t.id WHERE m.object_type = %s AND m.meta_key = %s AND m.meta_value = %s LIMIT 1",
				KERP_Helpers_Meta::TYPE_PROGRAM_TEMPLATE,
				'sample_key',
				$sample_key
			) ) );
			if ( $existing_id > 0 ) {
				return [ 'template_id' => $existing_id, 'created' => FALSE, 'tasks' => 0 ];
			}

			KERP_Modules_Programs_Types::instance()->seed_defaults();
			KERP_Modules_Programs_Units::instance()->seed_defaults();
			$type_keys = [ 'study', 'test', 'exam' ];
			$unit_keys = [ 'page', 'test', 'minute', 'score' ];
			$types = [];
			$units = [];
			foreach ( $type_keys as $key ) {
				$item = KERP_Modules_Programs_Types::instance()->get_by_key( $key );
				if ( ! is_array( $item ) ) {
					return new WP_Error( 'kerp_programs_sample_type_missing', __( 'نوع آیتم‌های پیش‌فرض برای ساخت قالب در دسترس نیست.', 'kasebi-erp' ) );
				}
				$types[ $key ] = (int) $item['id'];
			}
			foreach ( $unit_keys as $key ) {
				$item = KERP_Modules_Programs_Units::instance()->get_by_key( $key );
				if ( ! is_array( $item ) ) {
					return new WP_Error( 'kerp_programs_sample_unit_missing', __( 'واحدهای پیش‌فرض برای ساخت قالب در دسترس نیست.', 'kasebi-erp' ) );
				}
				$units[ $key ] = (int) $item['id'];
			}

			$subject_terms = [];
			foreach ( KERP_Modules_Programs_Taxonomies::instance()->get_terms( 0, FALSE ) as $term ) {
				if ( (int) $term['parent_id'] === 0 && preg_match( '/^(math|chemistry|physics|biology)-topics$/', (string) $term['slug'], $match ) ) {
					$subject_terms[ $match[1] ] = (int) $term['id'];
				}
			}
			$definition = require __DIR__ . '/experimental-exam-template.php';
			if ( ! is_array( $definition ) || count( (array) ( $definition['days'] ?? [] ) ) !== 7 ) {
				return new WP_Error( 'kerp_programs_sample_invalid', __( 'ساختار قالب نمونه معتبر نیست.', 'kasebi-erp' ) );
			}
			if ( $wpdb->query( 'START TRANSACTION' ) === FALSE ) {
				return new WP_Error( 'kerp_programs_sample_import_failed', __( 'شروع ایمپورت قالب انجام نشد.', 'kasebi-erp' ) );
			}
			$committed = FALSE;
			try {
				$template_id = $this->save( [
					'title'       => (string) $definition['title'],
					'description' => (string) $definition['description'],
					'day_count'   => 7,
					'status'      => 'active',
				] );
				if ( is_wp_error( $template_id ) ) {
					return $template_id;
				}
				$days = array_values( $this->get_days( (int) $template_id ) );
				if ( count( $days ) !== 7 ) {
					return new WP_Error( 'kerp_programs_sample_days_failed', __( 'ساخت هفت روز قالب کامل نشد.', 'kasebi-erp' ) );
				}
				$task_count = 0;
				foreach ( $definition['days'] as $day_index => $day_definition ) {
					$day_id = $this->save_day( [
						'template_id' => (int) $template_id,
						'day_number'  => $day_index + 1,
						'title'       => (string) $day_definition['title'],
						'description' => sprintf( __( 'روز %s از برنامه نمونه کنکور تجربی', 'kasebi-erp' ), number_format_i18n( $day_index + 1 ) ),
						'sort_order'  => ( $day_index + 1 ) * 10,
					], (int) $days[ $day_index ]['id'] );
					if ( is_wp_error( $day_id ) ) {
						return $day_id;
					}
					foreach ( (array) $day_definition['tasks'] as $task_index => $task ) {
						$subject = sanitize_key( (string) ( $task['subject'] ?? '' ) );
						$result = $this->save_task( [
							'template_day_id' => (int) $day_id,
							'task_type_id'    => $types[ $task['type'] ],
							'unit_id'         => $units[ $task['unit'] ],
							'title'           => (string) $task['title'],
							'description'     => '',
							'target_value'    => $task['target'],
							'target_text'     => (string) ( $task['target_text'] ?? '' ),
							'is_required'     => 1,
							'status'          => 'active',
							'sort_order'      => ( $task_index + 1 ) * 10,
							'term_ids'        => isset( $subject_terms[ $subject ] ) ? [ $subject_terms[ $subject ] ] : [],
						] );
						if ( is_wp_error( $result ) ) {
							return $result;
						}
						$task_count++;
					}
				}
				if ( ! $meta->update_template_meta( (int) $template_id, 'sample_key', $sample_key ) ) {
					return new WP_Error( 'kerp_programs_sample_marker_failed', __( 'ثبت شناسه قالب نمونه انجام نشد.', 'kasebi-erp' ) );
				}
				$committed = $wpdb->query( 'COMMIT' ) !== FALSE;
				return $committed
					? [ 'template_id' => (int) $template_id, 'created' => TRUE, 'tasks' => $task_count ]
					: new WP_Error( 'kerp_programs_sample_import_failed', __( 'ثبت نهایی قالب نمونه انجام نشد.', 'kasebi-erp' ) );
			} finally {
				if ( ! $committed ) {
					$wpdb->query( 'ROLLBACK' );
				}
			}
		} finally {
			$wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $lock ) );
		}
	}

	public function delete( int $template_id ): string|WP_Error {
		global $wpdb;
		$template = $this->get( $template_id );
		if ( ! is_array( $template ) ) {
			return new WP_Error( 'kerp_programs_template_not_found', __( 'قالب برنامه پیدا نشد.', 'kasebi-erp' ) );
		}
		$usage = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}kerp_program_daily_plans WHERE source_template_id = %d", $template_id ) );
		if ( $usage > 0 ) {
			$updated = $wpdb->update( $this->table_name(), [
				'status'     => 'archived',
				'updated_at' => current_time( 'mysql' ),
			], [ 'id' => $template_id ] );
			
			return $updated !== FALSE ? 'archived' : new WP_Error( 'kerp_programs_template_archive_failed', __( 'قالب استفاده‌شده فقط قابل آرشیو است و آرشیو انجام نشد.', 'kasebi-erp' ) );
		}
		if ( $wpdb->query( 'START TRANSACTION' ) === FALSE ) {
			return new WP_Error( 'kerp_programs_template_delete_failed', __( 'شروع عملیات حذف قالب انجام نشد.', 'kasebi-erp' ) );
		}
		$committed = FALSE;
		try {
			foreach ( $this->get_days( $template_id ) as $day ) {
				$result = $this->force_delete_day( (int) $day['id'] );
				if ( is_wp_error( $result ) ) {
					return $result;
				}
			}
			KERP_Helpers_Meta::instance()->delete_template_meta( $template_id );
			$result = $wpdb->delete( $this->table_name(), [ 'id' => $template_id ], [ '%d' ] );
			if ( $result !== 1 ) {
				return new WP_Error( 'kerp_programs_template_delete_failed', __( 'حذف قالب برنامه انجام نشد.', 'kasebi-erp' ) );
			}
			$committed = $wpdb->query( 'COMMIT' ) !== FALSE;
			return $committed
				? 'deleted'
				: new WP_Error( 'kerp_programs_template_delete_failed', __( 'ثبت نهایی حذف قالب انجام نشد.', 'kasebi-erp' ) );
		} finally {
			if ( ! $committed ) {
				$wpdb->query( 'ROLLBACK' );
			}
		}
	}
	
	public function get_day( int $day_id ): ?array {
		global $wpdb;
		$day_id = absint( $day_id );
		if ( $day_id <= 0 ) {
			return NULL;
		}
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$this->day_table()} WHERE id = %d LIMIT 1", $day_id ), ARRAY_A );
		
		return is_array( $row ) ? $this->hydrate_day( $row ) : NULL;
	}
	
	public function get_days( int $template_id ): array {
		global $wpdb;
		$rows = $wpdb->get_results(
			$wpdb->prepare( "SELECT * FROM {$this->day_table()} WHERE template_id = %d ORDER BY day_number ASC, sort_order ASC, id ASC", absint( $template_id ) ),
			ARRAY_A
		);
		
		return array_map( [ $this, 'hydrate_day' ], (array) $rows );
	}
	
	public function save_day( array $data, int $day_id = 0 ): int|WP_Error {
		global $wpdb;
		$day_id      = absint( $day_id );
		$existing    = $day_id > 0 ? $this->get_day( $day_id ) : NULL;
		$template_id = absint( $data['template_id'] ?? $existing['template_id'] ?? 0 );
		$day_number  = max( 1, absint( $data['day_number'] ?? $existing['day_number'] ?? 1 ) );
		if ( ! $this->get( $template_id ) ) {
			return new WP_Error( 'kerp_programs_invalid_template', __( 'قالب برنامه معتبر نیست.', 'kasebi-erp' ) );
		}
		$duplicate = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$this->day_table()} WHERE template_id = %d AND day_number = %d LIMIT 1", $template_id, $day_number ) );
		if ( $duplicate && absint( $duplicate ) !== $day_id ) {
			return new WP_Error( 'kerp_programs_duplicate_template_day', __( 'این شماره روز قبلاً در قالب ثبت شده است.', 'kasebi-erp' ) );
		}
		$row = [
			'template_id' => $template_id,
			'day_number'  => $day_number,
			'title'       => sanitize_text_field( (string) ( $data['title'] ?? '' ) ),
			'description' => wp_kses_post( (string) ( $data['description'] ?? '' ) ),
			'sort_order'  => intval( $data['sort_order'] ?? $day_number * 10 ),
		];
		if ( $day_id > 0 ) {
			$result = $wpdb->update( $this->day_table(), $row, [ 'id' => $day_id ] );
		} else {
			$result = $wpdb->insert( $this->day_table(), $row );
			$day_id = (int) $wpdb->insert_id;
		}
		if ( $result === FALSE || $day_id <= 0 ) {
			return new WP_Error( 'kerp_programs_template_day_save_failed', __( 'ذخیره روز قالب انجام نشد.', 'kasebi-erp' ) );
		}
		$this->refresh_day_count( $template_id );
		
		return $day_id;
	}
	
	public function delete_day( int $day_id ): bool|WP_Error {
		global $wpdb;
		$day = $this->get_day( $day_id );
		if ( ! is_array( $day ) ) {
			return new WP_Error( 'kerp_programs_template_day_not_found', __( 'روز قالب پیدا نشد.', 'kasebi-erp' ) );
		}
		if ( count( $this->get_tasks_by_day( $day_id, FALSE ) ) > 0 ) {
			return new WP_Error( 'kerp_programs_template_day_has_tasks', __( 'ابتدا آیتم‌های این روز را حذف کنید.', 'kasebi-erp' ) );
		}
		$result = $wpdb->delete( $this->day_table(), [ 'id' => $day_id ], [ '%d' ] );
		if ( $result === FALSE ) {
			return new WP_Error( 'kerp_programs_template_day_delete_failed', __( 'حذف روز قالب انجام نشد.', 'kasebi-erp' ) );
		}
		KERP_Helpers_Meta::instance()->delete_template_day_meta( $day_id );
		$this->refresh_day_count( (int) $day['template_id'] );
		
		return TRUE;
	}
	
	public function get_task( int $task_id ): ?array {
		global $wpdb;
		$task_id = absint( $task_id );
		if ( $task_id <= 0 ) {
			return NULL;
		}
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$this->task_table()} WHERE id = %d LIMIT 1", $task_id ), ARRAY_A );
		
		return is_array( $row ) ? $this->hydrate_task( $row ) : NULL;
	}
	
	public function get_tasks_by_day( int $day_id, bool $active_only = TRUE ): array {
		global $wpdb;
		$where = $active_only ? " AND status = 'active'" : '';
		$rows  = $wpdb->get_results(
			$wpdb->prepare( "SELECT * FROM {$this->task_table()} WHERE template_day_id = %d{$where} ORDER BY sort_order ASC, id ASC", absint( $day_id ) ),
			ARRAY_A
		);
		
		return array_map( [ $this, 'hydrate_task' ], (array) $rows );
	}

	/**
	 * Save a template task with an optional planned time range.
	 * A database lock serializes schedule checks for the same template day.
	 */
	public function save_scheduled_task( array $data, int $task_id = 0 ): int|WP_Error {
		global $wpdb;

		$task_id = absint( $task_id );
		$existing = $task_id > 0 ? $this->get_task( $task_id ) : NULL;
		if ( $task_id > 0 && ! is_array( $existing ) ) {
			return new WP_Error( 'kerp_programs_template_task_not_found', __( 'آیتم قالب پیدا نشد.', 'kasebi-erp' ) );
		}
		$old_day_id = absint( $existing['template_day_id'] ?? 0 );
		$day_id = absint( $data['template_day_id'] ?? $old_day_id );
		$start = $this->normalize_schedule_time( $data['scheduled_start'] ?? '' );
		$end = $this->normalize_schedule_time( $data['scheduled_end'] ?? '' );

		if ( is_wp_error( $start ) ) {
			return $start;
		}
		if ( is_wp_error( $end ) ) {
			return $end;
		}
		if ( ( $start === '' ) !== ( $end === '' ) ) {
			return new WP_Error( 'kerp_programs_schedule_incomplete', __( 'برای زمان‌بندی، ساعت شروع و پایان را با هم وارد کنید.', 'kasebi-erp' ) );
		}
		if ( $start !== '' && $this->time_to_minutes( $end ) <= $this->time_to_minutes( $start ) ) {
			return new WP_Error( 'kerp_programs_schedule_order', __( 'ساعت پایان باید بعد از ساعت شروع باشد.', 'kasebi-erp' ) );
		}
		if ( $day_id <= 0 || ! $this->get_day( $day_id ) ) {
			return new WP_Error( 'kerp_programs_schedule_day', __( 'روز قالب برای زمان‌بندی معتبر نیست.', 'kasebi-erp' ) );
		}

		$lock_name = 'kerp_template_schedule_' . md5( get_current_blog_id() . ':' . $day_id );
		$locked = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 5)', $lock_name ) ) === 1;
		if ( ! $locked ) {
			return new WP_Error( 'kerp_programs_schedule_busy', __( 'زمان‌بندی این روز هم‌اکنون در حال ویرایش است؛ دوباره تلاش کنید.', 'kasebi-erp' ) );
		}

		try {
			if ( $start !== '' ) {
				$conflict = $this->find_schedule_conflict( $day_id, $start, $end, $task_id );
				if ( is_array( $conflict ) ) {
					return new WP_Error(
						'kerp_programs_schedule_overlap',
						sprintf(
							__( 'این بازه با آیتم «%1$s» از ساعت %2$s تا %3$s تداخل دارد.', 'kasebi-erp' ),
							(string) $conflict['title'],
							(string) $conflict['scheduled_start'],
							(string) $conflict['scheduled_end']
						)
					);
				}
			}

			$data['meta'] = isset( $data['meta'] ) && is_array( $data['meta'] ) ? $data['meta'] : [];
			$data['meta']['scheduled_start'] = $start;
			$data['meta']['scheduled_end'] = $end;
			$result = $this->save_task( $data, $task_id );
			if ( is_wp_error( $result ) ) {
				return $result;
			}

			$this->reorder_day_tasks_by_schedule( $day_id );
			if ( $old_day_id > 0 && $old_day_id !== $day_id ) {
				$this->reorder_day_tasks_by_schedule( $old_day_id );
			}
			return $result;
		} finally {
			$wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $lock_name ) );
		}
	}

	private function normalize_schedule_time( mixed $value ): string|WP_Error {
		$value = trim( (string) $value );
		if ( class_exists( 'KERP_Helpers_Format' ) ) {
			$value = KERP_Helpers_Format::sanitize_numbers( $value );
		}
		if ( $value === '' ) {
			return '';
		}
		if ( preg_match( '/^(?:[01]\d|2[0-3]):[0-5]\d$/', $value ) !== 1 ) {
			return new WP_Error( 'kerp_programs_schedule_time', __( 'ساعت شروع و پایان باید با قالب ۲۴ ساعته مانند 08:30 وارد شوند.', 'kasebi-erp' ) );
		}
		return $value;
	}

	private function time_to_minutes( string $time ): int {
		[ $hour, $minute ] = array_map( 'intval', explode( ':', $time ) );
		return $hour * 60 + $minute;
	}

	private function find_schedule_conflict( int $day_id, string $start, string $end, int $exclude_id ): ?array {
		$start_minutes = $this->time_to_minutes( $start );
		$end_minutes = $this->time_to_minutes( $end );
		foreach ( $this->get_tasks_by_day( $day_id, TRUE ) as $task ) {
			if ( (int) $task['id'] === $exclude_id ) {
				continue;
			}
			$other_start = (string) ( $task['scheduled_start'] ?? '' );
			$other_end = (string) ( $task['scheduled_end'] ?? '' );
			if ( preg_match( '/^(?:[01]\d|2[0-3]):[0-5]\d$/', $other_start ) !== 1 || preg_match( '/^(?:[01]\d|2[0-3]):[0-5]\d$/', $other_end ) !== 1 ) {
				continue;
			}
			if ( $start_minutes < $this->time_to_minutes( $other_end ) && $end_minutes > $this->time_to_minutes( $other_start ) ) {
				$task['scheduled_start'] = $other_start;
				$task['scheduled_end'] = $other_end;
				return $task;
			}
		}
		return NULL;
	}

	private function reorder_day_tasks_by_schedule( int $day_id ): void {
		global $wpdb;
		$tasks = $this->get_tasks_by_day( $day_id, FALSE );
		foreach ( $tasks as &$task ) {
			$start = (string) ( $task['scheduled_start'] ?? '' );
			$task['_schedule_minutes'] = preg_match( '/^(?:[01]\d|2[0-3]):[0-5]\d$/', $start ) === 1 ? $this->time_to_minutes( $start ) : NULL;
		}
		unset( $task );
		usort( $tasks, static function ( array $a, array $b ): int {
			$a_scheduled = $a['_schedule_minutes'] !== NULL;
			$b_scheduled = $b['_schedule_minutes'] !== NULL;
			if ( $a_scheduled !== $b_scheduled ) {
				return $a_scheduled ? -1 : 1;
			}
			if ( $a_scheduled && $a['_schedule_minutes'] !== $b['_schedule_minutes'] ) {
				return $a['_schedule_minutes'] <=> $b['_schedule_minutes'];
			}
			return ( (int) $a['sort_order'] <=> (int) $b['sort_order'] ) ?: ( (int) $a['id'] <=> (int) $b['id'] );
		} );
		foreach ( $tasks as $index => $task ) {
			$wpdb->update( $this->task_table(), [ 'sort_order' => ( $index + 1 ) * 10 ], [ 'id' => (int) $task['id'] ], [ '%d' ], [ '%d' ] );
		}
	}

	public function save_task( array $data, int $task_id = 0 ): int|WP_Error {
		global $wpdb;
		$task_id  = absint( $task_id );
		$existing = $task_id > 0 ? $this->get_task( $task_id ) : NULL;
		$day_id   = absint( $data['template_day_id'] ?? $existing['template_day_id'] ?? 0 );
		$day      = $this->get_day( $day_id );
		$type_id  = absint( $data['task_type_id'] ?? $existing['task_type_id'] ?? 0 );
		$type     = KERP_Modules_Programs_Types::instance()->get( $type_id );
		$unit_id  = absint( $data['unit_id'] ?? $existing['unit_id'] ?? 0 );
		$title    = sanitize_text_field( (string) ( $data['title'] ?? '' ) );
		$status   = sanitize_key( (string) ( $data['status'] ?? $existing['status'] ?? 'active' ) );
		if ( ! is_array( $day ) || ! is_array( $type ) || $title === '' ) {
			return new WP_Error( 'kerp_programs_invalid_template_task', __( 'روز قالب، نوع آیتم و عنوان معتبر الزامی است.', 'kasebi-erp' ) );
		}
		if ( $unit_id > 0 && ! KERP_Modules_Programs_Units::instance()->get( $unit_id ) ) {
			return new WP_Error( 'kerp_programs_invalid_unit', __( 'واحد انتخاب‌شده معتبر نیست.', 'kasebi-erp' ) );
		}
		if ( ! in_array( $status, [ 'active', 'archived' ], TRUE ) ) {
			$status = 'active';
		}
		if ( array_key_exists( 'term_ids', $data ) ) {
			$validated_terms = KERP_Modules_Programs_Taxonomies::instance()
			                                                   ->validate_term_ids( is_array( $data['term_ids'] ) ? $data['term_ids'] : [] );
			if ( is_wp_error( $validated_terms ) ) {
				return $validated_terms;
			}
			$data['term_ids'] = $validated_terms;
		}
		$row = [
			'template_day_id' => $day_id,
			'task_type_id'    => $type_id,
			'unit_id'         => $unit_id,
			'title'           => $title,
			'description'     => wp_kses_post( (string) ( $data['description'] ?? '' ) ),
			'target_value'    => KERP_Modules_Programs_Tasks::instance()
			                                                ->sanitize_decimal( $data['target_value'] ?? NULL ),
			'target_text'     => wp_kses_post( (string) ( $data['target_text'] ?? '' ) ),
			'is_required'     => ! empty( $data['is_required'] ) ? 1 : 0,
			'status'          => $status,
			'sort_order'      => intval( $data['sort_order'] ?? 10 ),
		];
		if ( $task_id > 0 ) {
			$result = $wpdb->update( $this->task_table(), $row, [ 'id' => $task_id ] );
		} else {
			$result  = $wpdb->insert( $this->task_table(), $row );
			$task_id = (int) $wpdb->insert_id;
		}
		if ( $result === FALSE || $task_id <= 0 ) {
			return new WP_Error( 'kerp_programs_template_task_save_failed', __( 'ذخیره آیتم قالب انجام نشد.', 'kasebi-erp' ) );
		}
		if ( array_key_exists( 'term_ids', $data ) ) {
			$term_ids    = is_array( $data['term_ids'] ) ? $data['term_ids'] : [];
			$term_result = KERP_Modules_Programs_Taxonomies::instance()->set_object_terms(
				KERP_Modules_Programs_Taxonomies::OBJECT_TEMPLATE_TASK,
				$task_id,
				$term_ids
			);
			if ( is_wp_error( $term_result ) ) {
				return $term_result;
			}
		}
		if ( isset( $data['meta'] ) && is_array( $data['meta'] ) ) {
			foreach ( $data['meta'] as $meta_key => $meta_value ) {
				$meta_key = sanitize_key( (string) $meta_key );
				if ( $meta_key !== '' ) {
					KERP_Helpers_Meta::instance()->update_template_task_meta( $task_id, $meta_key, $meta_value );
				}
			}
		}
		
		return $task_id;
	}
	
	public function delete_task( int $task_id ): bool|WP_Error {
		if ( ! $this->get_task( $task_id ) ) {
			return new WP_Error( 'kerp_programs_template_task_not_found', __( 'آیتم قالب پیدا نشد.', 'kasebi-erp' ) );
		}
		
		return $this->force_delete_task( $task_id );
	}
	
	public function load_for_customer(
		int $template_id,
		int $customer_id,
		string $start_date,
		int $employee_id = 0,
		string $plan_status = 'draft'
	): array|WP_Error {
		global $wpdb;
		$template    = $this->get( $template_id );
		$customer_id = absint( $customer_id );
		$start_date  = KERP_Modules_Programs_Plans::instance()->normalize_date( $start_date );
		$plan_status = sanitize_key( $plan_status );
		if ( ! is_array( $template ) || $customer_id <= 0 || ! get_userdata( $customer_id ) || $start_date === '' ) {
			return new WP_Error( 'kerp_programs_invalid_template_load', __( 'قالب، مشتری یا تاریخ شروع معتبر نیست.', 'kasebi-erp' ) );
		}
		if ( ! isset( KERP_Modules_Programs_Settings::instance()->get_plan_status_options()[ $plan_status ] ) ) {
			$plan_status = 'draft';
		}
		$days = $this->get_days( $template_id );
		if ( empty( $days ) ) {
			return new WP_Error( 'kerp_programs_template_empty', __( 'این قالب روزی برای بارگذاری ندارد.', 'kasebi-erp' ) );
		}
		
		$wpdb->query( 'START TRANSACTION' );
		$plan_ids      = [];
		$created_plans = 0;
		$created_tasks = 0;
		$skipped_tasks = 0;
		foreach ( $days as $day ) {
			$offset    = max( 0, (int) $day['day_number'] - 1 );
			$timestamp = strtotime( '+' . $offset . ' days', strtotime( $start_date . ' 12:00:00' ) );
			if ( $timestamp === FALSE ) {
				$wpdb->query( 'ROLLBACK' );
				
				return new WP_Error( 'kerp_programs_template_date_failed', __( 'محاسبه تاریخ روزهای قالب انجام نشد.', 'kasebi-erp' ) );
			}
			$plan_date = date( 'Y-m-d', $timestamp );
			$plan      = KERP_Modules_Programs_Plans::instance()->get_by_customer_date( $customer_id, $plan_date );
			if ( ! is_array( $plan ) ) {
				$plan_id = KERP_Modules_Programs_Plans::instance()->save(
					[
						'customer_id'        => $customer_id,
						'plan_date'          => $plan_date,
						'source_template_id' => $template_id,
						'employee_id'        => $employee_id,
						'title'              => (string) ( $day['title'] !== '' ? $day['title'] : $template['title'] ),
						'description'        => (string) ( $day['description'] !== '' ? $day['description'] : $template['description'] ),
						'status'             => $plan_status,
					]
				);
				if ( is_wp_error( $plan_id ) ) {
					$wpdb->query( 'ROLLBACK' );
					
					return $plan_id;
				}
				$plan = KERP_Modules_Programs_Plans::instance()->get( (int) $plan_id );
				$created_plans ++;
			}
			if ( ! is_array( $plan ) ) {
				$wpdb->query( 'ROLLBACK' );
				
				return new WP_Error( 'kerp_programs_plan_load_failed', __( 'ساخت برنامه روزانه از قالب انجام نشد.', 'kasebi-erp' ) );
			}
			$plan_id    = (int) $plan['id'];
			$plan_ids[] = $plan_id;
			foreach ( $this->get_tasks_by_day( (int) $day['id'], TRUE ) as $template_task ) {
				if ( KERP_Modules_Programs_Tasks::instance()
				                                ->find_by_source_template_task( $plan_id, (int) $template_task['id'] ) ) {
					$skipped_tasks ++;
					continue;
				}
				$task_id = KERP_Modules_Programs_Tasks::instance()->save(
					[
						'plan_id'                 => $plan_id,
						'source_template_task_id' => (int) $template_task['id'],
						'task_type_id'            => (int) $template_task['task_type_id'],
						'unit_id'                 => (int) $template_task['unit_id'],
						'title'                   => (string) $template_task['title'],
						'description'             => (string) $template_task['description'],
						'target_value'            => $template_task['target_value'],
						'target_text'             => (string) $template_task['target_text'],
						'is_required'             => ! empty( $template_task['is_required'] ),
						'sort_order'              => (int) $template_task['sort_order'],
						'status'                  => 'active',
						'term_ids'                => (array) $template_task['term_ids'],
					]
				);
				if ( is_wp_error( $task_id ) ) {
					$wpdb->query( 'ROLLBACK' );
					
					return $task_id;
				}
				$this->copy_template_task_meta( (int) $template_task['id'], (int) $task_id );
				$created_tasks ++;
			}
		}
		$wpdb->query( 'COMMIT' );
		do_action( 'kerp_program_template_loaded', $template_id, $customer_id, $plan_ids );
		
		return [
			'plan_ids'      => array_values( array_unique( $plan_ids ) ),
			'created_plans' => $created_plans,
			'created_tasks' => $created_tasks,
			'skipped_tasks' => $skipped_tasks,
		];
	}
	
	private function ensure_days( int $template_id, int $day_count ): bool|WP_Error {
		global $wpdb;
		
		$template_id = absint( $template_id );
		$day_count   = max( 1, min( 365, absint( $day_count ) ) );
		
		if ( $template_id <= 0 ) {
			return new WP_Error(
				'kerp_programs_invalid_template',
				__( 'قالب برنامه معتبر نیست.', 'kasebi-erp' )
			);
		}
		
		/*
		 * حذف روزهایی که از تعداد جدید بیشتر هستند.
		 *
		 * مثال:
		 * تعداد قبلی: 7
		 * تعداد جدید: 5
		 *
		 * روزهای 6 و 7 به همراه آیتم‌هایشان حذف می‌شوند.
		 */
		$extra_days = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT id
			FROM {$this->day_table()}
			WHERE template_id = %d
			AND day_number > %d
			ORDER BY day_number DESC",
				$template_id,
				$day_count
			),
			ARRAY_A
		);
		
		foreach ( (array) $extra_days as $day ) {
			$day_id = absint( $day['id'] ?? 0 );
			
			if ( $day_id <= 0 ) {
				continue;
			}
			
			$result = $this->force_delete_day( $day_id );
			
			if ( is_wp_error( $result ) ) {
				return $result;
			}
		}
		
		/*
		 * ساخت روزهای کمبود.
		 */
		for ( $day_number = 1; $day_number <= $day_count; $day_number ++ ) {
			$result = $this->ensure_day(
				$template_id,
				$day_number
			);
			
			if ( is_wp_error( $result ) ) {
				return $result;
			}
		}
		
		return TRUE;
	}
	
	private function force_delete_day( int $day_id ): bool|WP_Error {
		global $wpdb;
		
		$day_id = absint( $day_id );
		
		if ( $day_id <= 0 ) {
			return new WP_Error(
				'kerp_programs_invalid_template_day',
				__( 'روز قالب معتبر نیست.', 'kasebi-erp' )
			);
		}
		
		foreach ( $this->get_tasks_by_day( $day_id, FALSE ) as $task ) {
			$task_id = absint( $task['id'] ?? 0 );
			
			if ( $task_id <= 0 ) {
				continue;
			}
			
			if ( ! $this->force_delete_task( $task_id ) ) {
				return new WP_Error(
					'kerp_programs_template_task_delete_failed',
					__( 'حذف یکی از آیتم‌های روز قالب انجام نشد.', 'kasebi-erp' )
				);
			}
		}
		
		KERP_Helpers_Meta::instance()->delete_template_day_meta(
			$day_id
		);
		
		$result = $wpdb->delete(
			$this->day_table(),
			[
				'id' => $day_id,
			],
			[
				'%d',
			]
		);
		
		if ( $result !== 1 ) {
			return new WP_Error(
				'kerp_programs_template_day_delete_failed',
				__( 'حذف روز قالب انجام نشد.', 'kasebi-erp' )
			);
		}
		
		return TRUE;
	}
	
	private function ensure_day( int $template_id, int $day_number ): bool|WP_Error {
		global $wpdb;
		
		$template_id = absint( $template_id );
		$day_number  = max( 1, absint( $day_number ) );
		
		$exists = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT id
			FROM {$this->day_table()}
			WHERE template_id = %d
			AND day_number = %d
			LIMIT 1",
				$template_id,
				$day_number
			)
		);
		
		if ( $exists ) {
			return TRUE;
		}
		
		$result = $wpdb->insert(
			$this->day_table(),
			[
				'template_id' => $template_id,
				'day_number'  => $day_number,
				'title'       => sprintf(
					__( 'روز %s', 'kasebi-erp' ),
					number_format_i18n( $day_number )
				),
				'description' => '',
				'sort_order'  => $day_number * 10,
			],
			[
				'%d',
				'%d',
				'%s',
				'%s',
				'%d',
			]
		);
		
		if ( $result === FALSE ) {
			return new WP_Error(
				'kerp_programs_template_day_create_failed',
				__( 'ایجاد روز قالب انجام نشد.', 'kasebi-erp' )
			);
		}
		
		return TRUE;
	}
	
	private function refresh_day_count( int $template_id ): void {
		global $wpdb;
		$max_day = (int) $wpdb->get_var( $wpdb->prepare( "SELECT MAX(day_number) FROM {$this->day_table()} WHERE template_id = %d", $template_id ) );
		$wpdb->update( $this->table_name(), [
			'day_count'  => max( 1, $max_day ),
			'updated_at' => current_time( 'mysql' ),
		], [ 'id' => $template_id ] );
	}
	
	private function force_delete_task( int $task_id ): bool {
		global $wpdb;
		KERP_Modules_Programs_Taxonomies::instance()
		                                ->delete_object_terms( KERP_Modules_Programs_Taxonomies::OBJECT_TEMPLATE_TASK, $task_id );
		KERP_Helpers_Meta::instance()->delete_template_task_meta( $task_id );
		
		return $wpdb->delete( $this->task_table(), [ 'id' => $task_id ], [ '%d' ] ) === 1;
	}
	
	private function copy_template_task_meta( int $template_task_id, int $task_id ): void {
		$all_meta = KERP_Helpers_Meta::instance()->get_template_task_meta( $template_task_id );
		if ( ! is_array( $all_meta ) ) {
			return;
		}
		foreach ( $all_meta as $meta_key => $values ) {
			if ( ! is_array( $values ) ) {
				continue;
			}
			foreach ( $values as $value ) {
				KERP_Helpers_Meta::instance()->add_task_meta( $task_id, (string) $meta_key, $value );
			}
		}
	}
	
	private function hydrate_template( array $row ): array {
		global $wpdb;
		$row['id']          = absint( $row['id'] ?? 0 );
		$row['day_count']   = absint( $row['day_count'] ?? 1 );
		$row['task_count']  = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$this->task_table()} t INNER JOIN {$this->day_table()} d ON d.id = t.template_day_id WHERE d.template_id = %d AND t.status = 'active'",
				(int) $row['id']
			)
		);
		$row['usage_count'] = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}kerp_program_daily_plans WHERE source_template_id = %d", (int) $row['id'] ) );
		
		return $row;
	}
	
	private function hydrate_day( array $row ): array {
		$row['id']          = absint( $row['id'] ?? 0 );
		$row['template_id'] = absint( $row['template_id'] ?? 0 );
		$row['day_number']  = absint( $row['day_number'] ?? 1 );
		$row['sort_order']  = intval( $row['sort_order'] ?? 10 );
		$row['task_count']  = count( $this->get_tasks_by_day( (int) $row['id'], TRUE ) );
		
		return $row;
	}
	
	private function hydrate_task( array $row ): array {
		$row['id']              = absint( $row['id'] ?? 0 );
		$row['template_day_id'] = absint( $row['template_day_id'] ?? 0 );
		$row['task_type_id']    = absint( $row['task_type_id'] ?? 0 );
		$row['unit_id']         = absint( $row['unit_id'] ?? 0 );
		$row['is_required']     = ! empty( $row['is_required'] );
		$row['sort_order']      = intval( $row['sort_order'] ?? 10 );
		$row['scheduled_start'] = (string) KERP_Helpers_Meta::instance()->get_template_task_meta( (int) $row['id'], 'scheduled_start', TRUE );
		$row['scheduled_end']   = (string) KERP_Helpers_Meta::instance()->get_template_task_meta( (int) $row['id'], 'scheduled_end', TRUE );
		$row['term_ids']        = KERP_Modules_Programs_Taxonomies::instance()
		                                                          ->get_object_term_ids( KERP_Modules_Programs_Taxonomies::OBJECT_TEMPLATE_TASK, (int) $row['id'] );
		
		return $row;
	}
	
}
