<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Programs_Types {

	private static ?self $instance = NULL;

	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	private function __construct() {}

	private function __clone() {}

	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}

	public function table_name(): string {
		global $wpdb;

		return $wpdb->prefix . 'kerp_program_task_types';
	}

	public function get( int $type_id ): ?array {
		global $wpdb;

		$type_id = absint( $type_id );
		if ( $type_id <= 0 ) {
			return NULL;
		}

		$row = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$this->table_name()} WHERE id = %d LIMIT 1", $type_id ),
			ARRAY_A
		);

		return is_array( $row ) ? $this->hydrate( $row ) : NULL;
	}

	public function get_by_key( string $type_key ): ?array {
		global $wpdb;

		$type_key = sanitize_key( $type_key );
		if ( $type_key === '' ) {
			return NULL;
		}

		$row = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$this->table_name()} WHERE type_key = %s LIMIT 1", $type_key ),
			ARRAY_A
		);

		return is_array( $row ) ? $this->hydrate( $row ) : NULL;
	}

	public function all( bool $active_only = FALSE ): array {
		global $wpdb;

		$where = $active_only ? ' WHERE active = 1' : '';
		$rows  = $wpdb->get_results(
			"SELECT * FROM {$this->table_name()}{$where} ORDER BY sort_order ASC, id ASC",
			ARRAY_A
		);

		return array_map( [ $this, 'hydrate' ], (array) $rows );
	}

	public function get_options( bool $active_only = TRUE ): array {
		$options = [];
		foreach ( $this->all( $active_only ) as $type ) {
			$options[ (int) $type['id'] ] = (string) $type['label'];
		}

		return $options;
	}

	public function get_value_type_options(): array {
		return [
			'number'   => __( 'عدد', 'kasebi-erp' ),
			'text'     => __( 'متن', 'kasebi-erp' ),
			'boolean'  => __( 'انجام / عدم انجام', 'kasebi-erp' ),
			'duration' => __( 'زمان / مدت', 'kasebi-erp' ),
			'score'    => __( 'نمره', 'kasebi-erp' ),
		];
	}

	public function save( array $data, int $type_id = 0 ): int|WP_Error {
		global $wpdb;

		$type_id    = absint( $type_id );
		$existing   = $type_id > 0 ? $this->get( $type_id ) : NULL;
		$type_key   = sanitize_key( (string) ( $data['type_key'] ?? $existing['type_key'] ?? '' ) );
		$label      = sanitize_text_field( (string) ( $data['label'] ?? '' ) );
		$value_type = sanitize_key( (string) ( $data['primary_value_type'] ?? 'number' ) );

		if ( $type_key === '' || $label === '' ) {
			return new WP_Error( 'kerp_programs_invalid_type', __( 'کلید و عنوان نوع آیتم الزامی است.', 'kasebi-erp' ) );
		}

		if ( ! isset( $this->get_value_type_options()[ $value_type ] ) ) {
			return new WP_Error( 'kerp_programs_invalid_value_type', __( 'نوع مقدار اصلی معتبر نیست.', 'kasebi-erp' ) );
		}

		$duplicate = $this->get_by_key( $type_key );
		if ( is_array( $duplicate ) && (int) $duplicate['id'] !== $type_id ) {
			return new WP_Error( 'kerp_programs_duplicate_type', __( 'این کلید نوع آیتم قبلاً استفاده شده است.', 'kasebi-erp' ) );
		}

		$row = [
			'type_key'           => $type_key,
			'label'              => $label,
			'description'        => sanitize_textarea_field( (string) ( $data['description'] ?? '' ) ),
			'primary_value_type' => $value_type,
			'icon'               => sanitize_text_field( (string) ( $data['icon'] ?? 'ni ni-check-circle' ) ),
			'active'             => ! empty( $data['active'] ) ? 1 : 0,
			'system'             => ! empty( $existing['system'] ) ? 1 : ( ! empty( $data['system'] ) ? 1 : 0 ),
			'sort_order'         => intval( $data['sort_order'] ?? 10 ),
		];

		if ( $type_id > 0 ) {
			$result = $wpdb->update( $this->table_name(), $row, [ 'id' => $type_id ] );
		} else {
			$result  = $wpdb->insert( $this->table_name(), $row );
			$type_id = (int) $wpdb->insert_id;
		}

		if ( $result === FALSE || $type_id <= 0 ) {
			return new WP_Error( 'kerp_programs_type_save_failed', __( 'ذخیره نوع آیتم انجام نشد.', 'kasebi-erp' ) );
		}

		if ( array_key_exists( 'fields', $data ) ) {
			$fields = $this->sanitize_fields_schema( $data['fields'] );
			KERP_Helpers_Meta::instance()->update_task_type_meta( $type_id, 'fields', $fields );
		}

		return $type_id;
	}

	public function delete( int $type_id ): bool|WP_Error {
		global $wpdb;

		$type = $this->get( $type_id );
		if ( ! is_array( $type ) ) {
			return new WP_Error( 'kerp_programs_type_not_found', __( 'نوع آیتم پیدا نشد.', 'kasebi-erp' ) );
		}
		if ( ! empty( $type['system'] ) ) {
			return new WP_Error( 'kerp_programs_system_type', __( 'نوع آیتم سیستمی قابل حذف نیست.', 'kasebi-erp' ) );
		}
		if ( $this->count_usage( $type_id ) > 0 ) {
			return new WP_Error( 'kerp_programs_type_in_use', __( 'این نوع آیتم در برنامه‌ها استفاده شده و قابل حذف نیست.', 'kasebi-erp' ) );
		}

		$result = $wpdb->delete( $this->table_name(), [ 'id' => $type_id ], [ '%d' ] );
		if ( $result === FALSE ) {
			return new WP_Error( 'kerp_programs_type_delete_failed', __( 'حذف نوع آیتم انجام نشد.', 'kasebi-erp' ) );
		}

		KERP_Helpers_Meta::instance()->delete_task_type_meta( $type_id );

		return TRUE;
	}

	public function count_usage( int $type_id ): int {
		global $wpdb;

		$type_id = absint( $type_id );
		$daily   = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}kerp_program_daily_tasks WHERE task_type_id = %d", $type_id ) );
		$template = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}kerp_program_template_tasks WHERE task_type_id = %d", $type_id ) );

		return $daily + $template;
	}

	public function seed_defaults(): void {
		$defaults = [
			[ 'type_key' => 'study', 'label' => 'مطالعه', 'primary_value_type' => 'number', 'icon' => 'uik-r fa-book', 'system' => 1, 'sort_order' => 10 ],
			[ 'type_key' => 'test', 'label' => 'تست', 'primary_value_type' => 'number', 'icon' => 'uik-r fa-test', 'system' => 1, 'sort_order' => 20 ],
			[ 'type_key' => 'exam', 'label' => 'آزمون', 'primary_value_type' => 'score', 'icon' => 'uik-r fa-document-signed', 'system' => 1, 'sort_order' => 30 ],
			[ 'type_key' => 'content', 'label' => 'مشاهده محتوا', 'primary_value_type' => 'boolean', 'icon' => 'uik-r fa-play', 'system' => 1, 'sort_order' => 40 ],
		];

		foreach ( $defaults as $item ) {
			if ( $this->get_by_key( $item['type_key'] ) ) {
				continue;
			}
			$item['active']      = 1;
			$item['description'] = '';
			$this->save( $item );
		}
	}

	public function sanitize_fields_schema( mixed $fields ): array {
		if ( is_string( $fields ) ) {
			$decoded = json_decode( wp_unslash( $fields ), TRUE );
			$fields  = is_array( $decoded ) ? $decoded : [];
		}
		if ( ! is_array( $fields ) ) {
			return [];
		}

		$clean = [];
		foreach ( $fields as $field ) {
			if ( ! is_array( $field ) ) {
				continue;
			}
			$key   = sanitize_key( (string) ( $field['key'] ?? '' ) );
			$label = sanitize_text_field( (string) ( $field['label'] ?? '' ) );
			$type  = sanitize_key( (string) ( $field['type'] ?? 'text' ) );
			if ( $key === '' || $label === '' ) {
				continue;
			}
			$clean[] = [
				'key'      => $key,
				'label'    => $label,
				'type'     => $type,
				'required' => ! empty( $field['required'] ),
			];
		}

		return $clean;
	}

	public function get_fields_schema( int $type_id ): array {
		$fields = KERP_Helpers_Meta::instance()->get_task_type_meta( $type_id, 'fields', TRUE );

		return is_array( $fields ) ? $fields : [];
	}

	private function hydrate( array $row ): array {
		$row['id']         = absint( $row['id'] ?? 0 );
		$row['active']     = ! empty( $row['active'] );
		$row['system']     = ! empty( $row['system'] );
		$row['sort_order'] = intval( $row['sort_order'] ?? 10 );
		$row['fields']     = $this->get_fields_schema( (int) $row['id'] );

		return $row;
	}
}
