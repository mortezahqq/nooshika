<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Programs_Api {
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {
		$this->register_hooks();
	}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public function save_plan(): void {
		$plan_id = absint( $_POST['plan_id'] ?? 0 );
		$this->guard( $plan_id > 0 ? 'programs.edit' : 'programs.create' );
		if ( $plan_id > 0 ) {
			$this->guard_plan_scope( $plan_id );
		}
		$employee_id = absint( $_POST['employee_id'] ?? 0 );
		if ( kerp_list_scope( 'programs' ) === 'own' ) {
			$employee_id = get_current_user_id();
		}
		$result = KERP_Modules_Programs_Plans::instance()->save(
			[
				'customer_id' => absint( $_POST['customer_id'] ?? 0 ),
				'plan_date'   => $this->post_text( 'plan_date' ),
				'employee_id' => $employee_id,
				'title'       => $this->post_text( 'title' ),
				'description' => $this->post_content( 'description' ),
				'status'      => $this->post_text( 'status' ),
			],
			$plan_id
		);
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		$this->page_success( $plan_id > 0 ? __( 'برنامه روزانه ویرایش شد.', 'kasebi-erp' ) : __( 'برنامه روزانه ثبت شد.', 'kasebi-erp' ) );
	}
	
	public function delete_plan(): void {
		$this->guard( 'programs.delete' );
		$plan_id = absint( $_POST['item_id'] ?? $_POST['plan_id'] ?? 0 );
		$this->guard_plan_scope( $plan_id );
		$result = KERP_Modules_Programs_Plans::instance()->delete( $plan_id );
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		$this->page_success( __( 'برنامه روزانه حذف یا در صورت داشتن نتیجه آرشیو شد.', 'kasebi-erp' ) );
	}

	public function save_comment(): void {
		$this->guard( 'programs.edit' );
		$plan_id = absint( $_POST['plan_id'] ?? 0 );
		$this->guard_plan_scope( $plan_id );
		$result = KERP_Modules_Programs_Comments::instance()->save( $plan_id, $this->post_content( 'content' ), $this->post_bool( 'visible_to_user' ) );
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		$this->page_success( __( 'کامنت ثبت شد.', 'kasebi-erp' ) );
	}

	public function delete_comment(): void {
		$this->guard( 'programs.edit' );
		$comment_id = absint( $_POST['item_id'] ?? $_POST['comment_id'] ?? 0 );
		$comments = KERP_Modules_Programs_Comments::instance();
		$comment = $comments->get( $comment_id );
		if ( ! is_array( $comment ) ) {
			$this->error( __( 'کامنت پیدا نشد.', 'kasebi-erp' ) );
		}
		$this->guard_plan_scope( (int) $comment['plan_id'] );
		$result = $comments->delete( $comment_id );
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		$this->page_success( __( 'کامنت حذف شد.', 'kasebi-erp' ) );
	}
	
	public function save_task(): void {
		$task_id = absint( $_POST['task_id'] ?? 0 );
		
		$this->guard( 'programs.edit' );
		
		$tasks = KERP_Modules_Programs_Tasks::instance();
		$types = KERP_Modules_Programs_Types::instance();
		
		$plan_id       = absint( $_POST['plan_id'] ?? 0 );
		$existing_task = NULL;
		
		/*
		 * در حالت ویرایش، plan_id را از خود Task می‌گیریم.
		 * بنابراین امکان انتقال Task به Plan دیگر از طریق POST وجود ندارد.
		 */
		if ( $task_id > 0 ) {
			$existing_task = $tasks->get( $task_id );
			
			if ( ! is_array( $existing_task ) ) {
				$this->error(
					__( 'آیتم برنامه پیدا نشد.', 'kasebi-erp' )
				);
			}
			
			$plan_id = absint(
				$existing_task['plan_id'] ?? 0
			);
		}
		
		if ( $plan_id <= 0 ) {
			$this->error(
				__( 'برنامه روزانه معتبر نیست.', 'kasebi-erp' )
			);
		}
		
		$this->guard_plan_scope( $plan_id );
		
		/*
		 * نوع Task.
		 */
		$task_type_id = absint(
			$_POST['task_type_id'] ?? 0
		);
		
		$type = $types->get( $task_type_id );
		
		if ( ! is_array( $type ) ) {
			$this->error(
				__( 'نوع آیتم برنامه معتبر نیست.', 'kasebi-erp' )
			);
		}
		
		/*
		 * اگر Task قبلاً نتیجه دارد، تغییر نوع آن می‌تواند
		 * ساختار Result قبلی را خراب کند.
		 *
		 * مثلاً:
		 * test -> study
		 *
		 * چون Result تست دارای correct_count / blank_count است
		 * ولی Result مطالعه progress_from / progress_to دارد.
		 */
		if (
			$task_id > 0 &&
			is_array( $existing_task ) &&
			$tasks->has_result( $task_id ) &&
			absint( $existing_task['task_type_id'] ?? 0 ) !== $task_type_id
		) {
			$this->error(
				__( 'نوع آیتمی که برای آن نتیجه ثبت شده است قابل تغییر نیست.', 'kasebi-erp' )
			);
		}
		
		$value_type = sanitize_key(
			(string) ( $type['primary_value_type'] ?? '' )
		);
		
		/*
		 * فقط این Value Typeها هدف عددی دارند.
		 */
		$numeric_value_types = [
			'number',
			'duration',
			'score',
		];
		
		$has_numeric_target = in_array(
			$value_type,
			$numeric_value_types,
			TRUE
		);
		
		/*
		 * برای Typeهای غیرعددی، unit و target_value
		 * باید صراحتاً پاک شوند.
		 *
		 * این موضوع مخصوصاً هنگام تغییر Type مهم است،
		 * چون ممکن است مقادیر قبلی همچنان در POST وجود داشته باشند.
		 */
		$unit_id      = 0;
		$target_value = '';
		
		if ( $has_numeric_target ) {
			$unit_id = absint(
				$_POST['unit_id'] ?? 0
			);
			
			$target_value = $this->post_text(
				'target_value'
			);
			
			/*
			 * اگر مقدار هدف وارد شده باشد باید عدد معتبر باشد.
			 *
			 * sanitize_decimal نهایی دوباره در Tasks::save()
			 * نیز انجام می‌شود، اما اینجا خطای UX بهتری می‌دهیم.
			 */
			if ( $target_value !== '' ) {
				$normalized_target = KERP_Helpers_Format::sanitize_numbers(
					$target_value
				);
				
				$normalized_target = str_replace(
					[ '٬', ',' ],
					[ '', '.' ],
					$normalized_target
				);
				
				if ( ! is_numeric( $normalized_target ) ) {
					$this->error(
						__( 'مقدار هدف باید یک عدد معتبر باشد.', 'kasebi-erp' )
					);
				}
				
				if ( (float) $normalized_target < 0 ) {
					$this->error(
						__( 'مقدار هدف نمی‌تواند منفی باشد.', 'kasebi-erp' )
					);
				}
				
				$target_value = $normalized_target;
			}
		}
		
		/*
		 * عنوان.
		 */
		$title = $this->post_text( 'title' );
		
		if ( $title === '' ) {
			$this->error(
				__( 'عنوان آیتم برنامه الزامی است.', 'kasebi-erp' )
			);
		}
		
		/*
		 * Status.
		 */
		$status = sanitize_key(
			$this->post_text( 'status' ) ?: 'active'
		);
		
		$status_options = $tasks->get_status_options();
		
		if ( ! isset( $status_options[ $status ] ) ) {
			$this->error(
				__( 'وضعیت آیتم برنامه معتبر نیست.', 'kasebi-erp' )
			);
		}
		
		/*
		 * Taxonomies.
		 */
		$term_ids = KERP_Modules_Programs_Form::instance()
		                                      ->flatten_term_groups(
			                                      $this->post_array( 'terms' )
		                                      );
		
		/*
		 * ذخیره Task.
		 */
		$result = $tasks->save_scheduled_task(
			[
				'plan_id'      => $plan_id,
				'task_type_id' => $task_type_id,
				
				/*
				 * برای Type غیرعددی این دو مقدار
				 * حتماً 0 / خالی هستند.
				 */
				'unit_id'      => $unit_id,
				'target_value' => $target_value,
				
				'title'       => $title,
				'description' => $this->post_content( 'description' ),
				'target_text' => $this->post_content( 'target_text' ),
				
				'is_required' => $this->post_bool( 'is_required' ),
				'status'      => $status,
				'sort_order'  => intval(
					$_POST['sort_order'] ?? 10
				),
				'scheduled_start' => $this->post_text( 'scheduled_start' ),
				'scheduled_end'   => $this->post_text( 'scheduled_end' ),
				
				'term_ids' => $term_ids,
			],
			$task_id
		);
		
		if ( is_wp_error( $result ) ) {
			$this->error(
				$result->get_error_message()
			);
		}
		
		$this->page_success(
			$task_id > 0
				? __( 'آیتم برنامه ویرایش شد.', 'kasebi-erp' )
				: __( 'آیتم برنامه افزوده شد.', 'kasebi-erp' )
		);
	}

	public function save_task_resource(): void {
		$this->guard( 'programs.edit' );
		$resource_id = absint( $_POST['resource_id'] ?? 0 );
		$service = KERP_Modules_Programs_Resources::instance();
		$existing = $resource_id ? $service->get( $resource_id ) : NULL;
		$task_id = $resource_id && is_array( $existing )
			? absint( $existing['task_id'] ?? 0 )
			: absint( $_POST['task_id'] ?? 0 );
		$task = KERP_Modules_Programs_Tasks::instance()->get( $task_id );
		if ( ! is_array( $task ) ) { $this->error( __( 'آیتم برنامه پیدا نشد.', 'kasebi-erp' ) ); }
		$this->guard_plan_scope( (int) $task['plan_id'] );
		$type_key = sanitize_key( $this->post_text( 'type_key' ) );
		$url = $type_key === 'file' ? $this->post_text( 'file_url' ) : $this->post_text( 'resource_url' );
		$result = $service->save( [
			'task_id' => $task_id, 'type_key' => $type_key, 'title' => $this->post_text( 'title' ),
			'resource_url' => $url,
			'reference_id' => absint( $_POST['learndash_id'] ?? 0 ),
			'room_id' => $this->post_text( 'room_id' ),
			'description' => $type_key === 'content' ? $this->post_content( 'content_body' ) : $this->post_textarea( 'description' ),
			'sort_order' => intval( $_POST['sort_order'] ?? 10 ),
		], $resource_id );
		if ( is_wp_error( $result ) ) { $this->error( $result->get_error_message() ); }
		$this->page_success( __( 'محتوا به آیتم برنامه متصل شد.', 'kasebi-erp' ) );
	}

	public function search_learndash_content(): void {
		$this->guard( 'programs.edit' );
		$service = KERP_Modules_Programs_Resources::instance();
		if ( ! $service->is_learndash_active() ) {
			$this->error( __( 'افزونه LearnDash فعال نیست.', 'kasebi-erp' ) );
		}
		$search = $this->post_text( 'search' );
		if ( mb_strlen( $search ) < 2 ) {
			$this->success( '', [ 'results' => [] ] );
		}
		$this->success( '', [ 'results' => $service->search_learndash( $search, absint( $_POST['page'] ?? 1 ) ) ] );
	}

	public function delete_task_resource(): void {
		$this->guard( 'programs.edit' );
		$service = KERP_Modules_Programs_Resources::instance();
		$resource = $service->get( absint( $_POST['item_id'] ?? $_POST['resource_id'] ?? 0 ) );
		if ( ! is_array( $resource ) ) { $this->error( __( 'محتوا پیدا نشد.', 'kasebi-erp' ) ); }
		$task = KERP_Modules_Programs_Tasks::instance()->get( (int) $resource['task_id'] );
		if ( ! is_array( $task ) ) { $this->error( __( 'آیتم برنامه پیدا نشد.', 'kasebi-erp' ) ); }
		$this->guard_plan_scope( (int) $task['plan_id'] );
		$result = $service->delete( (int) $resource['id'] );
		if ( is_wp_error( $result ) ) { $this->error( $result->get_error_message() ); }
		$this->page_success( __( 'محتوای متصل‌شده حذف شد.', 'kasebi-erp' ) );
	}
	
	public function delete_task(): void {
		$this->guard( 'programs.edit' );
		$task_id = absint( $_POST['item_id'] ?? $_POST['task_id'] ?? 0 );
		$task    = KERP_Modules_Programs_Tasks::instance()->get( $task_id );
		if ( ! is_array( $task ) ) {
			$this->error( __( 'آیتم برنامه پیدا نشد.', 'kasebi-erp' ) );
		}
		$this->guard_plan_scope( (int) $task['plan_id'] );
		$result = KERP_Modules_Programs_Tasks::instance()->delete( $task_id );
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		$this->page_success( __( 'آیتم برنامه حذف یا در صورت داشتن نتیجه لغو شد.', 'kasebi-erp' ) );
	}
	
	public function save_template(): void {
		$this->guard( 'programs.templates.manage' );
		$template_id = absint( $_POST['template_id'] ?? 0 );
		$result      = KERP_Modules_Programs_Templates::instance()->save(
			[
				'title'       => $this->post_text( 'title' ),
				'description' => $this->post_content( 'description' ),
				'day_count'   => absint( $_POST['day_count'] ?? 1 ),
				'status'      => $this->post_text( 'status' ) ?: 'active',
			],
			$template_id
		);
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		$this->success(
			$template_id > 0 ? __( 'قالب برنامه ویرایش شد.', 'kasebi-erp' ) : __( 'قالب برنامه ثبت شد.', 'kasebi-erp' ),
			KERP_Api_Page_Content::build_page_response( '/erp/programs/templates/' . (int) $result . '/', [], TRUE )
		);
	}

	public function import_experimental_exam_template(): void {
		$this->guard( 'programs.templates.manage' );
		if ( ! wp_verify_nonce( $this->post_text( 'import_nonce' ), 'kerp_import_experimental_exam_template' ) ) {
			$this->error( __( 'اعتبار درخواست پایان یافته؛ صفحه را تازه کنید.', 'kasebi-erp' ) );
			return;
		}
		$result = KERP_Modules_Programs_Templates::instance()->import_experimental_exam_sample();
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
			return;
		}
		$template_id = absint( $result['template_id'] ?? 0 );
		$message = ! empty( $result['created'] )
			? sprintf( __( 'قالب نمونه هفت‌روزه با %s آیتم ساخته شد.', 'kasebi-erp' ), number_format_i18n( absint( $result['tasks'] ?? 0 ) ) )
			: __( 'این قالب نمونه قبلاً ایمپورت شده بود.', 'kasebi-erp' );
		$page = '/erp/programs/templates/' . $template_id . '/';
		$this->success( $message, KERP_Api_Page_Content::build_page_response( $page, [], TRUE ) );
	}
	
	public function delete_template(): void {
		$this->guard( 'programs.templates.manage' );
		$template_id = absint( $_POST['item_id'] ?? $_POST['template_id'] ?? 0 );
		$result      = KERP_Modules_Programs_Templates::instance()->delete( $template_id );
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
			return;
		}
		$this->page_success(
			$result === 'archived'
				? __( 'این قالب در برنامه‌ها استفاده شده است و با موفقیت آرشیو شد.', 'kasebi-erp' )
				: __( 'قالب برنامه با موفقیت حذف شد.', 'kasebi-erp' )
		);
	}
	
	public function load_template(): void {
		$this->guard( 'programs.create' );
		$employee_id = absint( $_POST['employee_id'] ?? 0 );
		if ( kerp_list_scope( 'programs' ) === 'own' ) {
			$employee_id = get_current_user_id();
		}
		$result = KERP_Modules_Programs_Templates::instance()->load_for_customer(
			absint( $_POST['template_id'] ?? 0 ),
			absint( $_POST['customer_id'] ?? 0 ),
			$this->post_text( 'start_date' ),
			$employee_id,
			$this->post_text( 'status' ) ?: 'draft'
		);
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		$created_plans = absint( $result['created_plans'] ?? 0 );
		$created_tasks = absint( $result['created_tasks'] ?? 0 );
		$this->page_success(
			sprintf(
				__( 'قالب بارگذاری شد؛ %1$s برنامه و %2$s آیتم جدید ساخته شد.', 'kasebi-erp' ),
				number_format_i18n( $created_plans ),
				number_format_i18n( $created_tasks )
			)
		);
	}

	public function load_previous_week(): void {
		$this->guard( 'programs.create' );
		$result = KERP_Modules_Programs_Plans::instance()->copy_previous_week(
			absint( $_POST['customer_id'] ?? 0 ),
			$this->post_text( 'week_start' )
		);
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		$this->page_success( sprintf(
			__( 'هفته قبل بارگذاری شد؛ %1$s برنامه و %2$s آیتم ساخته شد و %3$s روزِ دارای برنامه نادیده گرفته شد.', 'kasebi-erp' ),
			number_format_i18n( absint( $result['created_plans'] ?? 0 ) ),
			number_format_i18n( absint( $result['created_tasks'] ?? 0 ) ),
			number_format_i18n( absint( $result['skipped_plans'] ?? 0 ) )
		) );
	}
	
	public function save_template_day(): void {
		$this->guard( 'programs.templates.manage' );
		$day_id = absint( $_POST['day_id'] ?? 0 );
		$result = KERP_Modules_Programs_Templates::instance()->save_day(
			[
				'template_id' => absint( $_POST['template_id'] ?? 0 ),
				'day_number'  => absint( $_POST['day_number'] ?? 1 ),
				'title'       => $this->post_text( 'title' ),
				'description' => $this->post_content( 'description' ),
				'sort_order'  => intval( $_POST['sort_order'] ?? 10 ),
			],
			$day_id
		);
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		$this->page_success( __( 'روز قالب ذخیره شد.', 'kasebi-erp' ) );
	}
	
	public function delete_template_day(): void {
		$this->guard( 'programs.templates.manage' );
		$result = KERP_Modules_Programs_Templates::instance()
		                                         ->delete_day( absint( $_POST['item_id'] ?? $_POST['day_id'] ?? 0 ) );
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		$this->page_success( __( 'روز قالب حذف شد.', 'kasebi-erp' ) );
	}
	
	public function save_template_task(): void {
		$this->guard( 'programs.templates.manage' );
		$task_id = absint( $_POST['template_task_id'] ?? 0 );
		$result  = KERP_Modules_Programs_Templates::instance()->save_scheduled_task(
			[
				'template_day_id' => absint( $_POST['template_day_id'] ?? 0 ),
				'task_type_id'    => absint( $_POST['task_type_id'] ?? 0 ),
				'unit_id'         => absint( $_POST['unit_id'] ?? 0 ),
				'title'           => $this->post_text( 'title' ),
				'description'     => $this->post_content( 'description' ),
				'target_value'    => $this->post_text( 'target_value' ),
				'target_text'     => $this->post_content( 'target_text' ),
				'is_required'     => $this->post_bool( 'is_required' ),
				'sort_order'      => intval( $_POST['sort_order'] ?? 10 ),
				'scheduled_start' => $this->post_text( 'scheduled_start' ),
				'scheduled_end'   => $this->post_text( 'scheduled_end' ),
				'term_ids'        => KERP_Modules_Programs_Form::instance()
				                                               ->flatten_term_groups( $this->post_array( 'terms' ) ),
			],
			$task_id
		);
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		$this->page_success( __( 'آیتم قالب ذخیره شد.', 'kasebi-erp' ) );
	}
	
	public function delete_template_task(): void {
		$this->guard( 'programs.templates.manage' );
		$result = KERP_Modules_Programs_Templates::instance()
		                                         ->delete_task( absint( $_POST['item_id'] ?? $_POST['template_task_id'] ?? 0 ) );
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		$this->page_success( __( 'آیتم قالب حذف شد.', 'kasebi-erp' ) );
	}
	
	public function save_result(): void {
		$this->guard( 'programs.results.edit' );
		
		$result_id = absint( $_POST['result_id'] ?? 0 );
		$task_id   = absint( $_POST['task_id'] ?? 0 );
		
		$task = KERP_Modules_Programs_Tasks::instance()->get( $task_id );
		
		if ( ! is_array( $task ) ) {
			$this->error(
				__( 'آیتم برنامه پیدا نشد.', 'kasebi-erp' )
			);
		}
		
		$this->guard_plan_scope(
			(int) $task['plan_id']
		);
		
		/*
		 * اگر در حال ویرایش Result هستیم،
		 * حتماً باید همان Result متعلق به همین Task باشد.
		 */
		if ( $result_id > 0 ) {
			$existing_result = KERP_Modules_Programs_Results::instance()->get(
				$result_id
			);
			
			if (
				! is_array( $existing_result ) ||
				absint( $existing_result['task_id'] ?? 0 ) !== $task_id
			) {
				$this->error(
					__( 'نتیجه انتخاب‌شده متعلق به این آیتم نیست.', 'kasebi-erp' )
				);
			}
		}
		
		$type = KERP_Modules_Programs_Types::instance()->get(
			absint( $task['task_type_id'] ?? 0 )
		);
		
		if ( ! is_array( $type ) ) {
			$this->error(
				__( 'نوع آیتم معتبر نیست.', 'kasebi-erp' )
			);
		}
		
		$type_key = sanitize_key(
			(string) ( $type['type_key'] ?? '' )
		);
		
		$value_type = sanitize_key(
			(string) ( $type['primary_value_type'] ?? '' )
		);
		
		$numeric_value_types = [
			'number',
			'duration',
			'score',
		];
		
		/*
		 * مقدار واقعی.
		 */
		$value_decimal = NULL;
		
		if ( in_array( $value_type, $numeric_value_types, TRUE ) ) {
			$value_decimal_raw = $this->post_text( 'value_decimal' );
			
			if ( $value_decimal_raw !== '' ) {
				$value_decimal = KERP_Modules_Programs_Tasks::instance()
				                                            ->sanitize_decimal( $value_decimal_raw );
			}
		}
		
		/*
		 * ساعت شروع و پایان.
		 */
		$started_at = $this->post_text( 'started_at' );
		$ended_at   = $this->post_text( 'ended_at' );
		
		foreach (
			[
				'started_at' => $started_at,
				'ended_at'   => $ended_at,
			] as $time_key => $time_value
		) {
			if (
				$time_value !== '' &&
				preg_match(
					'/^(?:[01]\d|2[0-3]):[0-5]\d$/',
					$time_value
				) !== 1
			) {
				$this->error(
					$time_key === 'started_at'
						? __( 'ساعت شروع معتبر نیست.', 'kasebi-erp' )
						: __( 'ساعت پایان معتبر نیست.', 'kasebi-erp' )
				);
			}
		}
		
		$effective_minutes = absint(
			$_POST['effective_minutes'] ?? 0
		);
		
		/*
		 * اطلاعات تست.
		 */
		$correct_count = 0;
		$blank_count   = 0;
		$wrong_count   = 0;
		
		if ( $type_key === 'test' ) {
			$correct_count = absint(
				$_POST['correct_count'] ?? 0
			);
			
			$blank_count = absint(
				$_POST['blank_count'] ?? 0
			);
			
			$total_count = $value_decimal !== NULL
				? absint( $value_decimal )
				: 0;
			
			if ( $correct_count + $blank_count > $total_count ) {
				$this->error(
					__( 'مجموع پاسخ‌های صحیح و نزده نمی‌تواند بیشتر از تعداد تست انجام‌شده باشد.', 'kasebi-erp' )
				);
			}
			
			$wrong_count = max(
				0,
				$total_count - $correct_count - $blank_count
			);
		}
		
		/*
		 * محدوده مطالعه.
		 */
		$progress_from = '';
		$progress_to   = '';
		
		if ( $type_key === 'study' ) {
			$progress_from = sanitize_text_field(
				wp_unslash(
					$_POST['progress_from'] ?? ''
				)
			);
			
			$progress_to = sanitize_text_field(
				wp_unslash(
					$_POST['progress_to'] ?? ''
				)
			);
		}
		
		/*
		 * فایل ضمیمه.
		 *
		 * کامپوننت upload ممکن است مقدار را به صورت
		 * رشته CSV یا Array ارسال کند.
		 */
		$attachment = $_POST['attachment'] ?? [];
		
		if ( is_string( $attachment ) ) {
			$attachment = wp_unslash( $attachment );
			
			$attachment = preg_split(
				'/\s*,\s*/',
				$attachment,
				- 1,
				PREG_SPLIT_NO_EMPTY
			);
		}
		
		$attachment = is_array( $attachment )
			? $attachment
			: [];
		
		$attachment = array_values(
			array_unique(
				array_filter(
					array_map(
						static function( $url ): string {
							return esc_url_raw(
								trim(
									(string) $url
								)
							);
						},
						$attachment
					)
				)
			)
		);
		
		if ( count( $attachment ) > 5 ) {
			$this->error(
				__( 'حداکثر ۵ فایل می‌توانید ضمیمه کنید.', 'kasebi-erp' )
			);
		}
		
		$result = KERP_Modules_Programs_Results::instance()->save(
			[
				'task_id'       => $task_id,
				'value_decimal' => $value_decimal,
				'value_text'    => $this->post_content( 'value_text' ),
				
				/*
				 * دیگر از فرم Status نمی‌گیریم.
				 * Result داخلی همچنان submitted ذخیره می‌شود.
				 */
				'status'        => 'submitted',
				
				'meta' => [
					'started_at'        => $started_at,
					'ended_at'          => $ended_at,
					'effective_minutes' => $effective_minutes,
					
					'correct_count' => $correct_count,
					'wrong_count'   => $wrong_count,
					'blank_count'   => $blank_count,
					
					'progress_from' => $progress_from,
					'progress_to'   => $progress_to,
					
					'attachment' => $attachment,
				],
			],
			$result_id
		);
		
		if ( is_wp_error( $result ) ) {
			$this->error(
				$result->get_error_message()
			);
		}
		
		$this->page_success(
			__( 'گزارش انجام آیتم ذخیره شد.', 'kasebi-erp' )
		);
	}
	
	public function save_review(): void {
		$this->guard( 'programs.results.review' );
		$review_id  = absint( $_POST['review_id'] ?? 0 );
		$result_id  = absint( $_POST['result_id'] ?? 0 );
		$result_row = KERP_Modules_Programs_Results::instance()->get( $result_id );
		if ( ! is_array( $result_row ) ) {
			$this->error( __( 'نتیجه پیدا نشد.', 'kasebi-erp' ) );
		}
		$task = KERP_Modules_Programs_Tasks::instance()->get( (int) $result_row['task_id'] );
		if ( ! is_array( $task ) ) {
			$this->error( __( 'آیتم مربوط به نتیجه پیدا نشد.', 'kasebi-erp' ) );
		}
		$this->guard_plan_scope( (int) $task['plan_id'] );
		$result = KERP_Modules_Programs_Results::instance()->save_review(
			[
				'result_id'    => $result_id,
				'status'       => $this->post_text( 'status' ),
				'score'        => $this->post_text( 'score' ),
				'public_note'  => $this->post_content( 'public_note' ),
				'private_note' => $this->post_content( 'private_note' ),
			],
			$review_id
		);
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		$this->page_success( __( 'بررسی نتیجه ذخیره شد.', 'kasebi-erp' ) );
	}
	
	public function save_type(): void {
		$this->guard( 'programs.types.manage' );
		$type_id = absint( $_POST['type_id'] ?? 0 );
		$fields  = KERP_Modules_Programs_Form::instance()->sanitize_meta_json( $this->post_textarea( 'fields_json' ) );
		if ( is_wp_error( $fields ) ) {
			$this->error( $fields->get_error_message() );
		}
		$result = KERP_Modules_Programs_Types::instance()->save(
			[
				'type_key'           => $this->post_text( 'type_key' ),
				'label'              => $this->post_text( 'label' ),
				'description'        => $this->post_textarea( 'description' ),
				'primary_value_type' => $this->post_text( 'primary_value_type' ),
				'icon'               => $this->post_text( 'icon' ),
				'active'             => $this->post_bool( 'active' ),
				'sort_order'         => intval( $_POST['sort_order'] ?? 10 ),
				'fields'             => $fields,
			],
			$type_id
		);
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		$this->page_success( __( 'نوع آیتم ذخیره شد.', 'kasebi-erp' ) );
	}
	
	public function delete_type(): void {
		$this->guard( 'programs.types.manage' );
		$result = KERP_Modules_Programs_Types::instance()
		                                     ->delete( absint( $_POST['item_id'] ?? $_POST['type_id'] ?? 0 ) );
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		$this->page_success( __( 'نوع آیتم حذف شد.', 'kasebi-erp' ) );
	}
	
	public function save_unit(): void {
		$this->guard( 'programs.units.manage' );
		$unit_id = absint( $_POST['unit_id'] ?? 0 );
		$result  = KERP_Modules_Programs_Units::instance()->save(
			[
				'unit_key'        => $this->post_text( 'unit_key' ),
				'label'           => $this->post_text( 'label' ),
				'symbol'          => $this->post_text( 'symbol' ),
				'value_type'      => $this->post_text( 'value_type' ),
				'decimal_allowed' => $this->post_bool( 'decimal_allowed' ),
				'decimals'        => absint( $_POST['decimals'] ?? 0 ),
				'active'          => $this->post_bool( 'active' ),
				'sort_order'      => intval( $_POST['sort_order'] ?? 10 ),
			],
			$unit_id
		);
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		$this->page_success( __( 'واحد ذخیره شد.', 'kasebi-erp' ) );
	}
	
	public function delete_unit(): void {
		$this->guard( 'programs.units.manage' );
		$result = KERP_Modules_Programs_Units::instance()
		                                     ->delete( absint( $_POST['item_id'] ?? $_POST['unit_id'] ?? 0 ) );
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		$this->page_success( __( 'واحد حذف شد.', 'kasebi-erp' ) );
	}
	
	public function save_taxonomy(): void {
		$this->guard( 'programs.taxonomies.manage' );
		$taxonomy_id = absint( $_POST['taxonomy_id'] ?? 0 );
		$result      = KERP_Modules_Programs_Taxonomies::instance()->save_taxonomy(
			[
				'taxonomy_key' => $this->post_text( 'taxonomy_key' ),
				'label'        => $this->post_text( 'label' ),
				'plural_label' => $this->post_text( 'plural_label' ),
				'description'  => $this->post_textarea( 'description' ),
				'hierarchical' => $this->post_bool( 'hierarchical' ),
				'multiple'     => $this->post_bool( 'multiple' ),
				'required'     => $this->post_bool( 'required' ),
				'active'       => $this->post_bool( 'active' ),
				'sort_order'   => intval( $_POST['sort_order'] ?? 10 ),
			],
			$taxonomy_id
		);
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		$this->page_success( __( 'دسته‌بندی ذخیره شد.', 'kasebi-erp' ) );
	}
	
	public function delete_taxonomy(): void {
		$this->guard( 'programs.taxonomies.manage' );
		$result = KERP_Modules_Programs_Taxonomies::instance()
		                                          ->delete_taxonomy( absint( $_POST['item_id'] ?? $_POST['taxonomy_id'] ?? 0 ) );
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		$this->page_success( __( 'دسته‌بندی حذف شد.', 'kasebi-erp' ) );
	}
	
	public function import_math_topics(): void {
		$this->import_topics_response( 'math', 'kerp_import_math_topics' );
	}

	public function import_subject_topics(): void {
		$this->import_topics_response( $this->post_text( 'subject' ), 'kerp_import_subject_topics' );
	}

	private function import_topics_response( string $subject, string $nonce_action ): void {
		$this->guard( 'programs.taxonomies.manage' );
		if ( ! wp_verify_nonce( $this->post_text( 'import_nonce' ), $nonce_action ) ) {
			$this->error( __( 'اعتبار درخواست تمام شده است؛ صفحه را تازه کنید.', 'kasebi-erp' ) );
			return;
		}
		$result = KERP_Modules_Programs_Taxonomies::instance()->import_subject_topics( $subject );
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
			return;
		}
		$page = '/erp/programs/settings/terms/?taxonomy_id=' . $result['taxonomy_id'] . '&term_focus=' . $result['root_id'];
		$this->success(
			sprintf( __( 'ایمپورت در تکسونومی مبحث انجام شد: %1$d گزینه اضافه شد، %2$d گزینه از قبل موجود بود و %3$d گزینه از ساختار قبلی منتقل شد.', 'kasebi-erp' ), $result['created'], $result['skipped'], $result['migrated'] ),
			KERP_Api_Page_Content::build_page_response( $page, $this->route_query( $page ), TRUE )
		);
	}

	public function term_explorer(): void {
		$this->guard( 'programs.taxonomies.manage' );
		if ( ! wp_verify_nonce( $this->post_text( 'nonce' ), 'kerp_term_explorer' ) ) {
			$this->error( 'اعتبار درخواست پایان یافته؛ صفحه را تازه کنید.' );
			return;
		}
		$service = KERP_Modules_Programs_Taxonomies::instance();
		$taxonomy_id = absint( $this->post_text( 'taxonomy_id' ) );
		$taxonomy = $service->get_taxonomy( $taxonomy_id );
		if ( ! $taxonomy || ! $taxonomy['hierarchical'] ) {
			$this->error( 'دسته‌بندی سلسله‌مراتبی معتبر نیست.' );
			return;
		}
		$operation = $this->post_text( 'operation' );
		$term_id = absint( $this->post_text( 'term_id' ) );
		$term = $term_id ? $service->get_term( $term_id ) : NULL;
		if ( $term_id && ( ! $term || (int) $term['taxonomy_id'] !== $taxonomy_id ) ) {
			$this->error( 'دسته پیدا نشد یا متعلق به این تکسونومی نیست.' );
			return;
		}
		$result = TRUE;
		if ( $operation === 'move' && $term ) {
			$result = $service->move_term( $taxonomy_id, $term_id, absint( $this->post_text( 'parent_id' ) ), absint( $this->post_text( 'before_id' ) ) );
		} elseif ( $operation === 'status' && $term ) {
			$active = $this->post_text( 'active' );
			if ( ! in_array( $active, [ '0', '1' ], TRUE ) ) {
				$this->error( 'وضعیت معتبر نیست.' );
				return;
			}
			$result = $service->save_term( array_merge( $term, [ 'active' => (int) $active ] ), $term_id );
		} elseif ( $operation === 'delete' && $term ) {
			$result = $service->delete_term( $term_id );
		} elseif ( $operation !== 'list' && $operation !== 'details' ) {
			$this->error( 'عملیات معتبر نیست.' );
			return;
		}
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
			return;
		}
		$this->success( '', [ 'terms' => $service->explorer_terms( $taxonomy_id ) ] );
	}

	public function save_term(): void {
		$this->guard( 'programs.taxonomies.manage' );
		if ( ! wp_verify_nonce( $this->post_text( 'term_nonce' ), 'kerp_save_program_term' ) ) {
			$this->error( 'اعتبار فرم پایان یافته؛ صفحه را تازه کنید.' );
			return;
		}
		$term_id = absint( $_POST['term_id'] ?? 0 );
		$result  = KERP_Modules_Programs_Taxonomies::instance()->save_term(
			[
				'taxonomy_id' => absint( $_POST['taxonomy_id'] ?? 0 ),
				'parent_id'   => absint( $_POST['parent_id'] ?? 0 ),
				'name'        => $this->post_text( 'name' ),
				'slug'        => $this->post_text( 'slug' ),
				'description' => $this->post_textarea( 'description' ),
				'active'      => $this->post_bool( 'active' ),
				'sort_order'  => intval( $_POST['sort_order'] ?? 10 ),
			],
			$term_id
		);
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
			return;
		}
		$meta = KERP_Helpers_Meta::instance();
		foreach ( [ 'icon' => KERP_Modules_Programs_Taxonomies::term_icons(), 'color' => KERP_Modules_Programs_Taxonomies::term_colors() ] as $key => $allowed ) {
			if ( isset( $_POST[ $key ] ) ) {
				$value = $this->post_text( $key );
				if ( isset( $allowed[ $value ] ) ) {
					$meta->update_term_meta( (int) $result, 'explorer_' . $key, $value );
				}
			}
		}
		$page = add_query_arg( [ 'taxonomy_id' => absint( $_POST['taxonomy_id'] ?? 0 ), 'term_focus' => absint( $result ) ], '/erp/programs/settings/terms/' );
		$this->success( __( 'گزینه ذخیره شد.', 'kasebi-erp' ), KERP_Api_Page_Content::build_page_response( $page, $this->route_query( $page ), TRUE ) );
	}
	
	public function delete_term(): void {
		$this->guard( 'programs.taxonomies.manage' );
		$result = KERP_Modules_Programs_Taxonomies::instance()
		                                          ->delete_term( absint( $_POST['item_id'] ?? $_POST['term_id'] ?? 0 ) );
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		$this->page_success( __( 'گزینه حذف شد.', 'kasebi-erp' ) );
	}
	
	public function save_settings(): void {
		$this->guard( 'programs.manage_settings' );
		KERP_Modules_Programs_Settings::instance()->update(
			[
				'plan_singular_label'     => $this->post_text( 'plan_singular_label' ),
				'plan_plural_label'       => $this->post_text( 'plan_plural_label' ),
				'template_singular_label' => $this->post_text( 'template_singular_label' ),
				'template_plural_label'   => $this->post_text( 'template_plural_label' ),
				'task_singular_label'     => $this->post_text( 'task_singular_label' ),
				'task_plural_label'       => $this->post_text( 'task_plural_label' ),
				'default_plan_status'     => $this->post_text( 'default_plan_status' ),
				'default_per_page'        => absint( $_POST['default_per_page'] ?? 20 ),
			]
		);
		$this->page_success( __( 'تنظیمات برنامه‌ها ذخیره شد.', 'kasebi-erp' ) );
	}
	
	public function get_result_details(): void {
		$this->guard( 'programs.results.view' );
		
		$result_id = absint( $_POST['result_id'] ?? 0 );
		
		if ( $result_id <= 0 ) {
			$this->error( __( 'شناسه نتیجه نامعتبر است.', 'kasebi-erp' ) );
		}
		
		$result = KERP_Modules_Programs_Results::instance()->get( $result_id );
		
		if ( ! is_array( $result ) ) {
			$this->error( __( 'نتیجه پیدا نشد.', 'kasebi-erp' ) );
		}
		
		$task = KERP_Modules_Programs_Tasks::instance()->get(
			absint( $result['task_id'] ?? 0 )
		);
		
		if ( ! is_array( $task ) ) {
			$this->error( __( 'آیتم مربوط به نتیجه پیدا نشد.', 'kasebi-erp' ) );
		}
		
		$this->guard_plan_scope( absint( $task['plan_id'] ?? 0 ) );
		
		$plan = KERP_Modules_Programs_Plans::instance()->get(
			absint( $task['plan_id'] ?? 0 )
		);
		
		if ( ! is_array( $plan ) ) {
			$this->error( __( 'برنامه مربوط به نتیجه پیدا نشد.', 'kasebi-erp' ) );
		}
		
		$type = KERP_Modules_Programs_Types::instance()->get(
			absint( $task['task_type_id'] ?? 0 )
		);
		
		$unit = KERP_Modules_Programs_Units::instance()->get(
			absint( $task['unit_id'] ?? 0 )
		);
		
		$return_page = sanitize_text_field(
			wp_unslash(
				$_POST['return_page'] ?? '/erp/programs/results/'
			)
		);
		
		if ( $return_page === '' ) {
			$return_page = '/erp/programs/results/';
		}
		
		$html = KERP_Helpers_Template::get_template(
			'modules/programs/partials/result-detail.php',
			[
				'result'      => $result,
				'task'        => $task,
				'plan'        => $plan,
				'type'        => is_array( $type ) ? $type : [],
				'unit'        => is_array( $unit ) ? $unit : [],
				'review'      => isset( $result['review'] ) && is_array( $result['review'] )
					? $result['review']
					: NULL,
				'return_page' => $return_page,
			]
		);
		
		$this->success(
			'',
			[
				'html' => $html,
			]
		);
	}
	
	private function guard_plan_scope( int $plan_id ): array {
		$plan = KERP_Modules_Programs_Plans::instance()->get( $plan_id );
		if ( ! is_array( $plan ) ) {
			$this->error( __( 'برنامه روزانه پیدا نشد.', 'kasebi-erp' ) );
		}
		$scope = kerp_list_scope( 'programs' );
		if ( $scope === 'none' || ( $scope === 'own' && (int) $plan['employee_id'] !== get_current_user_id() ) ) {
			$this->error( __( 'به این برنامه دسترسی ندارید.', 'kasebi-erp' ) );
		}
		
		return $plan;
	}
	
	private function guard( string $permission ): void {
		if ( ! is_user_logged_in() ) {
			$this->error( __( 'برای انجام این عملیات وارد حساب کاربری شوید.', 'kasebi-erp' ) );
		}
		if ( ! KERP_App::instance()->current_user_has_access() ) {
			$this->error( __( 'به سامانه دسترسی ندارید.', 'kasebi-erp' ) );
		}
		if ( ! kerp_can( $permission, 'action' ) ) {
			$this->error( __( 'دسترسی لازم را ندارید.', 'kasebi-erp' ) );
		}
	}
	
	private function post_text( string $key ): string {
		if ( ! isset( $_POST[ $key ] ) || is_array( $_POST[ $key ] ) ) {
			return '';
		}
		
		return sanitize_text_field( wp_unslash( $_POST[ $key ] ) );
	}
	
	private function post_textarea( string $key ): string {
		if ( ! isset( $_POST[ $key ] ) || is_array( $_POST[ $key ] ) ) {
			return '';
		}
		
		return sanitize_textarea_field( wp_unslash( $_POST[ $key ] ) );
	}
	
	private function post_content( string $key ): string {
		if ( ! isset( $_POST[ $key ] ) || is_array( $_POST[ $key ] ) ) {
			return '';
		}
		
		return wp_kses_post( wp_unslash( $_POST[ $key ] ) );
	}
	
	private function post_array( string $key ): array {
		if ( ! isset( $_POST[ $key ] ) || ! is_array( $_POST[ $key ] ) ) {
			return [];
		}
		
		return wp_unslash( $_POST[ $key ] );
	}
	
	private function post_bool( string $key ): bool {
		if ( ! isset( $_POST[ $key ] ) ) {
			return FALSE;
		}
		$value = $_POST[ $key ];
		if ( is_array( $value ) ) {
			return ! empty( $value );
		}
		
		return in_array( strtolower( (string) $value ), [ '1', 'true', 'yes', 'on' ], TRUE );
	}
	
	private function return_page(): string {
		$page = $this->post_text( 'return_page' ) ?: $this->post_text( 'page' );
		if ( ! str_starts_with( $page, '/erp/programs' ) ) {
			return '/erp/programs/';
		}
		
		return $page;
	}
	
	private function route_query( string $page ): array {
		$query = wp_parse_url( $page, PHP_URL_QUERY );
		if ( ! is_string( $query ) || $query === '' ) {
			return [];
		}
		parse_str( $query, $args );
		
		return is_array( $args ) ? $args : [];
	}
	
	private function page_success( string $message ): void {
		$page = $this->return_page();
		$this->success( $message, KERP_Api_Page_Content::build_page_response( $page, $this->route_query( $page ), TRUE ) );
	}
	
	private function success( string $message, array $data = [] ): void {
		wp_send_json( array_merge( [ 'status' => 'success', 'message' => $message, 'msg' => $message ], $data ) );
	}
	
	private function error( string $message, array $data = [] ): void {
		wp_send_json( array_merge( [ 'status' => 'error', 'message' => $message, 'msg' => $message ], $data ) );
	}
	
	private function register_hooks(): void {
		$hooks = [
			'programs_save_plan'            => 'save_plan',
			'programs_delete_plan'          => 'delete_plan',
			'programs_save_comment'         => 'save_comment',
			'programs_delete_comment'       => 'delete_comment',
			'programs_save_task'            => 'save_task',
			'programs_delete_task'          => 'delete_task',
			'programs_save_task_resource'   => 'save_task_resource',
			'programs_delete_task_resource' => 'delete_task_resource',
			'programs_search_learndash_content' => 'search_learndash_content',
			'programs_save_template'        => 'save_template',
			'programs_import_experimental_exam_template' => 'import_experimental_exam_template',
			'programs_delete_template'      => 'delete_template',
			'programs_load_template'        => 'load_template',
			'programs_load_previous_week'   => 'load_previous_week',
			'programs_save_template_day'    => 'save_template_day',
			'programs_delete_template_day'  => 'delete_template_day',
			'programs_save_template_task'   => 'save_template_task',
			'programs_delete_template_task' => 'delete_template_task',
			'programs_save_result'          => 'save_result',
			'programs_save_review'          => 'save_review',
			'programs_save_type'            => 'save_type',
			'programs_delete_type'          => 'delete_type',
			'programs_save_unit'            => 'save_unit',
			'programs_delete_unit'          => 'delete_unit',
			'programs_save_taxonomy'        => 'save_taxonomy',
			'programs_delete_taxonomy'      => 'delete_taxonomy',
			'programs_save_term'            => 'save_term',
			'programs_term_explorer'        => 'term_explorer',
			'programs_import_math_topics'   => 'import_math_topics',
			'programs_import_subject_topics' => 'import_subject_topics',
			'programs_delete_term'          => 'delete_term',
			'programs_save_settings'        => 'save_settings',
			'programs_get_result_details'   => 'get_result_details',
		];
		foreach ( $hooks as $action => $method ) {
			add_action( 'kasebi_ajax_' . $action, [ $this, $method ] );
		}
	}
	
}
