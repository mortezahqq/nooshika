<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Programs_Performance {
	private const AJAX_ACTION = 'programs_student_performance';
	private const NONCE_ACTION = 'kerp_programs_student_performance';
	private static ?self $instance = NULL;

	public static function instance(): self {
		if ( self::$instance === NULL ) { self::$instance = new self(); }
		return self::$instance;
	}
	private function __construct() {
		add_action( 'kasebi_ajax_' . self::AJAX_ACTION, [ $this, 'ajax' ] );
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_assets' ], PHP_INT_MAX );
	}
	private function __clone() {}
	public function __wakeup(): void { throw new LogicException( 'Cannot unserialize a singleton.' ); }

	public function enqueue_assets(): void {
		if ( ! kerp_is_erp_request() ) { return; }
		wp_enqueue_style( 'kerp-program-performance', KERP_ASSETS_URL . 'shared/css/program-performance.css', [ KERP_Public_Assets::STYLE_HANDLE ], kerp_asset_version( 'shared/css/program-performance.css' ) );
		wp_enqueue_script( 'kerp-program-performance', KERP_ASSETS_URL . 'shared/js/program-performance.js', [ KERP_Public_Assets::SCRIPT_HANDLE ], kerp_asset_version( 'shared/js/program-performance.js' ), TRUE );
	}

	public function render( array $args ): void {
		$taxonomy = $this->topic_taxonomy();
		if ( ! $taxonomy ) { return; }
		$terms = KERP_Modules_Programs_Taxonomies::instance()->get_terms( (int) $taxonomy['id'], TRUE );
		KERP_Helpers_Template::render_template( 'modules/programs/components/performance.php', [
			'customer_id' => absint( $args['customer_id'] ?? 0 ),
			'anchor_date' => $this->display_input_date( (string) ( $args['anchor_date'] ?? current_time( 'Y-m-d' ) ) ),
			'taxonomy' => $taxonomy,
			'terms' => $terms,
			'nonce' => wp_create_nonce( self::NONCE_ACTION ),
		] );
	}

	public function ajax(): void {
		$nonce = sanitize_text_field( wp_unslash( (string) ( $_POST['nonce'] ?? '' ) ) );
		if ( ! wp_verify_nonce( $nonce, self::NONCE_ACTION ) || ! is_user_logged_in() ) { $this->error( __( 'اعتبار درخواست منقضی شده است.', 'kasebi-erp' ) ); }
		$customer_id = absint( $_POST['customer_id'] ?? 0 );
		if ( ! KERP_App::instance()->current_user_has_access() || ! kerp_can( 'programs.view', 'view' ) || ! get_userdata( $customer_id ) ) { $this->error( __( 'به گزارش این دانش‌آموز دسترسی ندارید.', 'kasebi-erp' ) ); }
		$period = sanitize_key( (string) ( $_POST['period'] ?? 'weekly' ) );
		if ( ! in_array( $period, [ 'weekly', 'monthly', 'term' ], TRUE ) ) { $period = 'weekly'; }
		$anchor = $this->normalize_input_date( (string) ( $_POST['anchor_date'] ?? '' ) );
		if ( $anchor === '' ) { $this->error( __( 'تاریخ گزارش معتبر نیست.', 'kasebi-erp' ) ); }
		$ranges = $this->ranges( $period, $anchor );
		$taxonomy = $this->topic_taxonomy();
		if ( ! $taxonomy ) { $this->error( __( 'تکسونومی مبحث پیدا نشد.', 'kasebi-erp' ) ); }
		$focus_id = absint( $_POST['term_id'] ?? 0 );
		$terms = KERP_Modules_Programs_Taxonomies::instance()->get_terms( (int) $taxonomy['id'], FALSE );
		$map = array_column( $terms, NULL, 'id' );
		if ( $focus_id && ! isset( $map[ $focus_id ] ) ) { $this->error( __( 'مبحث انتخاب‌شده معتبر نیست.', 'kasebi-erp' ) ); }
		$current = $this->aggregate( $this->rows( $customer_id, $ranges['current']['from'], $ranges['current']['to'] ), (int) $taxonomy['id'], $focus_id, $map );
		$previous = $this->aggregate( $this->rows( $customer_id, $ranges['previous']['from'], $ranges['previous']['to'] ), (int) $taxonomy['id'], $focus_id, $map );
		$categories = [];
		foreach ( array_unique( array_merge( array_keys( $current['groups'] ), array_keys( $previous['groups'] ) ) ) as $id ) {
			$categories[] = [
				'id' => (int) $id,
				'name' => (string) ( $map[ $id ]['name'] ?? __( 'بدون مبحث', 'kasebi-erp' ) ),
				'current' => $current['groups'][ $id ] ?? $this->empty_metrics(),
				'previous' => $previous['groups'][ $id ] ?? $this->empty_metrics(),
			];
		}
		usort( $categories, static fn( $a, $b ) => strnatcasecmp( $a['name'], $b['name'] ) );
		wp_send_json( [ 'status' => 'success', 'data' => [
			'categories' => $categories,
			'current_exams' => $current['exams'],
			'previous_exams' => $previous['exams'],
			'current_label' => $this->range_label( $ranges['current'] ),
			'previous_label' => $this->range_label( $ranges['previous'] ),
			'focus_label' => $focus_id ? (string) $map[ $focus_id ]['name'] : __( 'مباحث سطح بالا', 'kasebi-erp' ),
		] ] );
	}

	private function topic_taxonomy(): ?array {
		$taxonomies = KERP_Modules_Programs_Taxonomies::instance();
		foreach ( [ 'topic', 'topics', 'subject' ] as $key ) {
			$item = $taxonomies->get_taxonomy_by_key( $key );
			if ( is_array( $item ) && ! empty( $item['hierarchical'] ) ) { return $item; }
		}
		foreach ( $taxonomies->get_taxonomies( TRUE ) as $item ) { if ( ! empty( $item['hierarchical'] ) ) { return $item; } }
		return NULL;
	}

	private function ranges( string $period, string $anchor ): array {
		$stamp = strtotime( $anchor . ' 12:00:00' );
		if ( $period === 'weekly' ) {
			$from = strtotime( '-' . ( ( (int) date( 'w', $stamp ) + 1 ) % 7 ) . ' days', $stamp );
			$to = strtotime( '+6 days', $from );
			$previous_from = strtotime( '-7 days', $from );
			$previous_to = strtotime( '-1 day', $from );
		} elseif ( $period === 'monthly' ) {
			$from = strtotime( date( 'Y-m-01', $stamp ) . ' 12:00:00' );
			$to = strtotime( '+1 month -1 day', $from );
			$previous_from = strtotime( '-1 month', $from );
			$previous_to = strtotime( '-1 day', $from );
		} else {
			$month = (int) date( 'n', $stamp );
			$start_month = (int) floor( ( $month - 1 ) / 3 ) * 3 + 1;
			$from = strtotime( date( 'Y', $stamp ) . '-' . sprintf( '%02d', $start_month ) . '-01 12:00:00' );
			$to = strtotime( '+3 months -1 day', $from );
			$previous_from = strtotime( '-3 months', $from );
			$previous_to = strtotime( '-1 day', $from );
		}
		return [ 'current' => [ 'from' => date( 'Y-m-d', $from ), 'to' => date( 'Y-m-d', $to ) ], 'previous' => [ 'from' => date( 'Y-m-d', $previous_from ), 'to' => date( 'Y-m-d', $previous_to ) ] ];
	}

	private function rows( int $customer_id, string $from, string $to ): array {
		global $wpdb;
		$where = "p.customer_id=%d AND p.plan_date BETWEEN %s AND %s AND p.status<>'archived' AND t.status IN ('active','completed')";
		$args = [ $customer_id, $from, $to ];
		if ( kerp_list_scope( 'programs' ) === 'none' ) { return []; }
		if ( kerp_list_scope( 'programs' ) === 'own' ) { $where .= ' AND p.employee_id=%d'; $args[] = get_current_user_id(); }
		$sql = "SELECT t.id, p.plan_date, tt.type_key, u.unit_key, t.target_value, r.value_decimal AS actual_value, r.id AS result_id
			FROM {$wpdb->prefix}kerp_program_daily_plans p INNER JOIN {$wpdb->prefix}kerp_program_daily_tasks t ON t.plan_id=p.id
			LEFT JOIN {$wpdb->prefix}kerp_program_results r ON r.task_id=t.id LEFT JOIN {$wpdb->prefix}kerp_program_task_types tt ON tt.id=t.task_type_id
			LEFT JOIN {$wpdb->prefix}kerp_program_units u ON u.id=t.unit_id WHERE {$where} ORDER BY p.plan_date,t.sort_order,t.id";
		return (array) $wpdb->get_results( $wpdb->prepare( $sql, $args ), ARRAY_A );
	}

	private function aggregate( array $rows, int $taxonomy_id, int $focus_id, array $map ): array {
		global $wpdb;
		$ids = array_values( array_filter( array_map( static fn( $row ) => absint( $row['id'] ?? 0 ), $rows ) ) );
		$relations = [];
		if ( $ids ) {
			$holders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
			$args = array_merge( [ KERP_Modules_Programs_Taxonomies::OBJECT_TASK ], $ids, [ $taxonomy_id ] );
			$sql = "SELECT r.object_id,r.term_id FROM {$wpdb->prefix}kerp_program_term_relationships r INNER JOIN {$wpdb->prefix}kerp_program_terms tr ON tr.id=r.term_id WHERE r.object_type=%s AND r.object_id IN ({$holders}) AND tr.taxonomy_id=%d";
			foreach ( (array) $wpdb->get_results( $wpdb->prepare( $sql, $args ), ARRAY_A ) as $rel ) { $relations[ (int) $rel['object_id'] ][] = (int) $rel['term_id']; }
		}
		$groups = []; $exams = [];
		foreach ( $rows as $row ) {
			$buckets = [];
			foreach ( $relations[ (int) $row['id'] ] ?? [] as $term_id ) {
				$path = []; $seen = [];
				while ( isset( $map[ $term_id ] ) && ! isset( $seen[ $term_id ] ) ) { $seen[ $term_id ] = TRUE; array_unshift( $path, $term_id ); $term_id = (int) $map[ $term_id ]['parent_id']; }
				if ( $focus_id ) {
					$position = array_search( $focus_id, $path, TRUE );
					if ( $position === FALSE ) { continue; }
					$buckets[] = $path[ $position + 1 ] ?? $focus_id;
				} elseif ( $path ) { $buckets[] = $path[0]; }
			}
			foreach ( array_unique( $buckets ) as $bucket ) {
				$groups[ $bucket ] ??= $this->empty_metrics();
				$type = sanitize_key( (string) ( $row['type_key'] ?? '' ) );
				$actual = is_numeric( $row['actual_value'] ?? NULL ) ? (float) $row['actual_value'] : 0.0;
				$target = is_numeric( $row['target_value'] ?? NULL ) ? (float) $row['target_value'] : 0.0;
				if ( $type === 'test' ) { $groups[ $bucket ]['tests_target'] += $target; $groups[ $bucket ]['tests_actual'] += $actual; }
				if ( $type === 'study' ) {
					$divisor = sanitize_key( (string) ( $row['unit_key'] ?? '' ) ) === 'minute' ? 60 : 1;
					$groups[ $bucket ]['hours_target'] += $target / $divisor; $groups[ $bucket ]['hours_actual'] += $actual / $divisor;
				}
				if ( $type === 'exam' && ! empty( $row['result_id'] ) && is_numeric( $row['actual_value'] ?? NULL ) ) { $groups[ $bucket ]['exam_sum'] += $actual; $groups[ $bucket ]['exam_count']++; }
			}
			if ( sanitize_key( (string) ( $row['type_key'] ?? '' ) ) === 'exam' && ! empty( $row['result_id'] ) && is_numeric( $row['actual_value'] ?? NULL ) && ( ! $focus_id || ! empty( $buckets ) ) ) { $exams[] = [ 'date' => (string) $row['plan_date'], 'score' => round( (float) $row['actual_value'], 2 ) ]; }
		}
		foreach ( $groups as &$group ) { foreach ( [ 'tests_target', 'tests_actual', 'hours_target', 'hours_actual' ] as $key ) { $group[ $key ] = round( $group[ $key ], 2 ); } $group['exam_average'] = $group['exam_count'] ? round( $group['exam_sum'] / $group['exam_count'], 2 ) : NULL; unset( $group['exam_sum'] ); } unset( $group );
		return [ 'groups' => $groups, 'exams' => $exams ];
	}

	private function empty_metrics(): array { return [ 'tests_target' => 0.0, 'tests_actual' => 0.0, 'hours_target' => 0.0, 'hours_actual' => 0.0, 'exam_sum' => 0.0, 'exam_count' => 0, 'exam_average' => NULL ]; }
	private function range_label( array $range ): string { $plans = KERP_Modules_Programs_Plans::instance(); return sprintf( __( '%1$s تا %2$s', 'kasebi-erp' ), $plans->display_date( $range['from'] ), $plans->display_date( $range['to'] ) ); }
	private function display_input_date( string $date ): string { $timestamp = strtotime( $date . ' 12:00:00' ); return $timestamp !== FALSE ? date_i18n( 'Y-m-d', $timestamp ) : ''; }
	private function normalize_input_date( string $date ): string {
		$date = KERP_Helpers_Format::sanitize_numbers( sanitize_text_field( wp_unslash( $date ) ) );
		$date = str_replace( '/', '-', trim( $date ) );
		$year = (int) strtok( $date, '-' );
		if ( $year > 0 && $year < 1700 ) { $converted = KERP_Helpers_Date::jalali_to_gregorian( $date ); return is_string( $converted ) ? $converted : ''; }
		return KERP_Modules_Programs_Plans::instance()->normalize_date( $date );
	}
	private function error( string $message ): void { wp_send_json( [ 'status' => 'error', 'message' => $message, 'msg' => $message ] ); }
}
