<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Programs_Overview {

	public const AJAX_ACTION = 'programs_overview';
	private const NONCE_ACTION = 'kerp_programs_overview';
	private static ?self $instance = NULL;

	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'kasebi_ajax_' . self::AJAX_ACTION, [ $this, 'ajax' ] );
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_assets' ], PHP_INT_MAX );
	}

	private function __clone() {}
	public function __wakeup(): void { throw new LogicException( 'Cannot unserialize a singleton.' ); }

	public function enqueue_assets(): void {
		if ( ! kerp_is_erp_request() && ! is_page( 'panel' ) && ! wp_script_is( 'kerp-programs-panel', 'enqueued' ) ) {
			return;
		}
		wp_enqueue_style(
			'kerp-program-admin',
			KERP_ASSETS_URL . 'shared/css/program-admin.css',
			kerp_is_erp_request() ? [ KERP_Public_Assets::STYLE_HANDLE ] : [ 'kerp-programs-panel' ],
			kerp_asset_version( 'shared/css/program-admin.css' )
		);
		wp_enqueue_style(
			'kerp-program-overview',
			KERP_ASSETS_URL . 'shared/css/program-overview.css',
			kerp_is_erp_request() ? [ KERP_Public_Assets::STYLE_HANDLE ] : [ 'kerp-programs-panel' ],
			kerp_asset_version( 'shared/css/program-overview.css' )
		);
		wp_enqueue_script(
			'kerp-program-overview',
			KERP_ASSETS_URL . 'shared/js/program-overview.js',
			kerp_is_erp_request() ? [ KERP_Public_Assets::SCRIPT_HANDLE ] : [ 'kerp-programs-panel' ],
			kerp_asset_version( 'shared/js/program-overview.js' ),
			TRUE
		);
	}

	public function render( array $args ): void {
		$context = sanitize_key( (string) ( $args['context'] ?? 'customer' ) );
		if ( ! in_array( $context, [ 'template', 'customer', 'public' ], TRUE ) ) {
			return;
		}
		$taxonomies = $this->hierarchical_taxonomies();
		if ( empty( $taxonomies ) ) {
			return;
		}
		$preferred = $this->preferred_taxonomy_id( $taxonomies );
		KERP_Helpers_Template::render_template( 'modules/programs/components/overview.php', [
			'context'       => $context,
			'customer_id'   => absint( $args['customer_id'] ?? 0 ),
			'template_id'   => absint( $args['template_id'] ?? 0 ),
			'date_from'     => $this->display_input_date( (string) ( $args['date_from'] ?? '' ) ),
			'date_to'       => $this->display_input_date( (string) ( $args['date_to'] ?? '' ) ),
			'day_from'      => max( 1, absint( $args['day_from'] ?? 1 ) ),
			'day_to'        => max( 1, absint( $args['day_to'] ?? 1 ) ),
			'taxonomies'    => $taxonomies,
			'taxonomy_id'   => absint( $args['taxonomy_id'] ?? $preferred ),
			'level'         => max( 1, absint( $args['level'] ?? 1 ) ),
			'nonce'         => wp_create_nonce( self::NONCE_ACTION ),
		] );
	}

	public function public_summary( int $customer_id, string $date_from, string $date_to ): array {
		$taxonomies = $this->hierarchical_taxonomies();
		if ( $customer_id <= 0 || empty( $taxonomies ) ) {
			return [ 'groups' => [], 'task_count' => 0, 'has_actual' => TRUE ];
		}
		$taxonomy_id = $this->preferred_taxonomy_id( $taxonomies );
		$taxonomy = KERP_Modules_Programs_Taxonomies::instance()->get_taxonomy( $taxonomy_id );
		$data = $this->aggregate( $this->customer_rows( $customer_id, $date_from, $date_to, TRUE ), $taxonomy_id, 1, 'daily_task' );
		$data['taxonomy_label'] = is_array( $taxonomy ) ? (string) ( $taxonomy['plural_label'] ?? '' ) : '';
		return $data;
	}

	public function ajax(): void {
		$nonce = sanitize_text_field( wp_unslash( (string) ( $_POST['nonce'] ?? '' ) ) );
		if ( ! wp_verify_nonce( $nonce, self::NONCE_ACTION ) ) {
			$this->error( __( 'اعتبار درخواست منقضی شده است. صفحه را تازه کنید.', 'kasebi-erp' ) );
		}
		if ( ! is_user_logged_in() ) {
			$this->error( __( 'برای مشاهده گزارش وارد حساب کاربری شوید.', 'kasebi-erp' ) );
		}

		$context = sanitize_key( (string) ( $_POST['context'] ?? '' ) );
		$customer_id = absint( $_POST['customer_id'] ?? 0 );
		$template_id = absint( $_POST['template_id'] ?? 0 );
		$is_public = $context === 'public';

		if ( $is_public ) {
			$customer_id = get_current_user_id();
		} elseif ( $context === 'template' ) {
			if ( ! KERP_App::instance()->current_user_has_access() || ! kerp_can( 'programs.templates.manage', 'action' ) ) {
				$this->error( __( 'به گزارش این قالب دسترسی ندارید.', 'kasebi-erp' ) );
			}
			if ( ! KERP_Modules_Programs_Templates::instance()->get( $template_id ) ) {
				$this->error( __( 'قالب پیدا نشد.', 'kasebi-erp' ) );
			}
		} elseif ( $context === 'customer' ) {
			if ( ! KERP_App::instance()->current_user_has_access() || ! kerp_can( 'programs.view', 'view' ) || ! get_userdata( $customer_id ) ) {
				$this->error( __( 'به گزارش این دانش‌آموز دسترسی ندارید.', 'kasebi-erp' ) );
			}
		} else {
			$this->error( __( 'نوع گزارش معتبر نیست.', 'kasebi-erp' ) );
		}

		$taxonomy_id = absint( $_POST['taxonomy_id'] ?? 0 );
		$taxonomy = KERP_Modules_Programs_Taxonomies::instance()->get_taxonomy( $taxonomy_id );
		if ( ! is_array( $taxonomy ) || empty( $taxonomy['hierarchical'] ) ) {
			$this->error( __( 'دسته‌بندی سلسله‌مراتبی معتبر نیست.', 'kasebi-erp' ) );
		}

		$level = max( 1, min( 20, absint( $_POST['level'] ?? 1 ) ) );
		if ( $context === 'template' ) {
			$from = max( 1, absint( $_POST['day_from'] ?? 1 ) );
			$to   = max( $from, absint( $_POST['day_to'] ?? $from ) );
			$rows = $this->template_rows( $template_id, $from, $to );
			$range_label = sprintf( __( 'روز %1$s تا %2$s قالب', 'kasebi-erp' ), number_format_i18n( $from ), number_format_i18n( $to ) );
		} else {
			$plans = KERP_Modules_Programs_Plans::instance();
			$from = $this->normalize_input_date( (string) ( $_POST['date_from'] ?? '' ) );
			$to   = $this->normalize_input_date( (string) ( $_POST['date_to'] ?? '' ) );
			if ( $from === '' || $to === '' || $from > $to ) {
				$this->error( __( 'بازه زمانی معتبر نیست.', 'kasebi-erp' ) );
			}
			$rows = $this->customer_rows( $customer_id, $from, $to, $is_public );
			$range_label = sprintf( __( '%1$s تا %2$s', 'kasebi-erp' ), $plans->display_date( $from ), $plans->display_date( $to ) );
		}

		$data = $this->aggregate( $rows, $taxonomy_id, $level, $context === 'template' ? 'template_task' : 'daily_task' );
		$data['range_label'] = $range_label;
		$data['level'] = $level;
		$data['taxonomy_label'] = (string) $taxonomy['plural_label'];
		wp_send_json( [ 'status' => 'success', 'data' => $data ] );
	}

	private function hierarchical_taxonomies(): array {
		$result = [];
		foreach ( KERP_Modules_Programs_Taxonomies::instance()->get_taxonomies( TRUE ) as $taxonomy ) {
			if ( empty( $taxonomy['hierarchical'] ) ) { continue; }
			$terms = KERP_Modules_Programs_Taxonomies::instance()->get_terms( (int) $taxonomy['id'], FALSE );
			$map = array_column( $terms, NULL, 'id' );
			$max_depth = 1;
			foreach ( $terms as $term ) {
				$depth = 1; $seen = []; $parent = (int) $term['parent_id'];
				while ( $parent && isset( $map[ $parent ] ) && ! isset( $seen[ $parent ] ) ) {
					$seen[ $parent ] = TRUE; $depth++; $parent = (int) $map[ $parent ]['parent_id'];
				}
				$max_depth = max( $max_depth, $depth );
			}
			$result[] = [ 'id' => (int) $taxonomy['id'], 'label' => (string) $taxonomy['plural_label'], 'max_depth' => min( 20, $max_depth ) ];
		}
		return $result;
	}

	private function preferred_taxonomy_id( array $taxonomies ): int {
		$all = KERP_Modules_Programs_Taxonomies::instance();
		foreach ( [ 'topic', 'topics' ] as $key ) {
			$item = $all->get_taxonomy_by_key( $key );
			if ( $item && ! empty( $item['hierarchical'] ) ) { return (int) $item['id']; }
		}
		return (int) $taxonomies[0]['id'];
	}

	private function template_rows( int $template_id, int $from, int $to ): array {
		global $wpdb;
		return (array) $wpdb->get_results( $wpdb->prepare(
			"SELECT t.id, t.task_type_id, t.unit_id, t.target_value, NULL AS actual_value, NULL AS result_id,
				tt.label AS type_label, tt.icon AS type_icon, u.unit_key, u.label AS unit_label, u.symbol AS unit_symbol
			 FROM {$wpdb->prefix}kerp_program_template_days d
			 INNER JOIN {$wpdb->prefix}kerp_program_template_tasks t ON t.template_day_id=d.id AND t.status='active'
			 LEFT JOIN {$wpdb->prefix}kerp_program_task_types tt ON tt.id=t.task_type_id
			 LEFT JOIN {$wpdb->prefix}kerp_program_units u ON u.id=t.unit_id
			 WHERE d.template_id=%d AND d.day_number BETWEEN %d AND %d ORDER BY d.day_number,t.sort_order,t.id",
			$template_id, $from, $to
		), ARRAY_A );
	}

	private function customer_rows( int $customer_id, string $from, string $to, bool $public ): array {
		global $wpdb;
		$where = "p.customer_id=%d AND p.plan_date BETWEEN %s AND %s AND p.status<>'archived' AND t.status IN ('active','completed')";
		$args = [ $customer_id, $from, $to ];
		if ( $public ) {
			$where .= " AND p.status='published'";
		} elseif ( kerp_list_scope( 'programs' ) === 'none' ) {
			return [];
		} elseif ( kerp_list_scope( 'programs' ) === 'own' ) {
			$where .= ' AND p.employee_id=%d'; $args[] = get_current_user_id();
		}
		$sql = "SELECT t.id, t.task_type_id, t.unit_id, t.target_value, r.value_decimal AS actual_value, r.id AS result_id,
				tt.label AS type_label, tt.icon AS type_icon, u.unit_key, u.label AS unit_label, u.symbol AS unit_symbol
			 FROM {$wpdb->prefix}kerp_program_daily_plans p
			 INNER JOIN {$wpdb->prefix}kerp_program_daily_tasks t ON t.plan_id=p.id
			 LEFT JOIN {$wpdb->prefix}kerp_program_results r ON r.task_id=t.id
			 LEFT JOIN {$wpdb->prefix}kerp_program_task_types tt ON tt.id=t.task_type_id
			 LEFT JOIN {$wpdb->prefix}kerp_program_units u ON u.id=t.unit_id
			 WHERE {$where} ORDER BY p.plan_date,t.sort_order,t.id";
		return (array) $wpdb->get_results( $wpdb->prepare( $sql, $args ), ARRAY_A );
	}

	private function aggregate( array $rows, int $taxonomy_id, int $level, string $object_type ): array {
		global $wpdb;
		$terms = KERP_Modules_Programs_Taxonomies::instance()->get_terms( $taxonomy_id, FALSE );
		$map = array_column( $terms, NULL, 'id' );
		$ids = array_values( array_filter( array_map( static fn( $row ) => absint( $row['id'] ?? 0 ), $rows ) ) );
		$relations = [];
		if ( $ids ) {
			$placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
			$sql = "SELECT r.object_id,r.term_id FROM {$wpdb->prefix}kerp_program_term_relationships r INNER JOIN {$wpdb->prefix}kerp_program_terms tr ON tr.id=r.term_id WHERE r.object_type=%s AND r.object_id IN ({$placeholders}) AND tr.taxonomy_id=%d";
			$query_args = array_merge( [ $object_type ], $ids, [ $taxonomy_id ] );
			foreach ( (array) $wpdb->get_results( $wpdb->prepare( $sql, $query_args ), ARRAY_A ) as $relation ) {
				$relations[ (int) $relation['object_id'] ][] = (int) $relation['term_id'];
			}
		}

		$groups = [];
		foreach ( $rows as $row ) {
			$bucket_ids = [];
			foreach ( $relations[ (int) $row['id'] ] ?? [] as $term_id ) {
				$path = []; $seen = [];
				while ( isset( $map[ $term_id ] ) && ! isset( $seen[ $term_id ] ) ) {
					$seen[ $term_id ] = TRUE; array_unshift( $path, $map[ $term_id ] ); $term_id = (int) $map[ $term_id ]['parent_id'];
				}
				if ( $path ) { $bucket_ids[] = (int) $path[ min( $level - 1, count( $path ) - 1 ) ]['id']; }
			}
			$bucket_ids = array_values( array_unique( $bucket_ids ?: [ 0 ] ) );
			foreach ( $bucket_ids as $bucket_id ) {
				$name = $bucket_id && isset( $map[ $bucket_id ] ) ? (string) $map[ $bucket_id ]['name'] : __( 'بدون مبحث', 'kasebi-erp' );
				$groups[ $bucket_id ] ??= [ 'id' => $bucket_id, 'name' => $name, 'metrics' => [] ];
				$metric = $this->metric( $row );
				$key = $metric['key'];
				$groups[ $bucket_id ]['metrics'][ $key ] ??= $metric;
				$is_count = empty( $row['unit_key'] ) && ( $row['target_value'] === NULL || $row['target_value'] === '' );
				$groups[ $bucket_id ]['metrics'][ $key ]['target'] += $is_count ? 1 : $this->metric_value( $row['target_value'] ?? NULL, $row['unit_key'] ?? '' );
				if ( ( $row['actual_value'] !== NULL && $row['actual_value'] !== '' ) || ( $is_count && ! empty( $row['result_id'] ) ) ) {
					$groups[ $bucket_id ]['metrics'][ $key ]['actual'] += $is_count ? 1 : $this->metric_value( $row['actual_value'], $row['unit_key'] ?? '' );
					$groups[ $bucket_id ]['metrics'][ $key ]['reported']++;
				}
				$groups[ $bucket_id ]['metrics'][ $key ]['tasks']++;
			}
		}
		$max = [];
		foreach ( $groups as &$group ) {
			$group['metrics'] = array_values( $group['metrics'] );
			foreach ( $group['metrics'] as &$metric ) {
				$metric['target'] = round( $metric['target'], 2 );
				$metric['actual'] = round( $metric['actual'], 2 );
				$metric['achievement'] = $metric['target'] > 0 ? round( $metric['actual'] / $metric['target'] * 100, 1 ) : NULL;
				$max[ $metric['key'] ] = max( $max[ $metric['key'] ] ?? 0, $metric['target'], $metric['actual'] );
			}
			unset( $metric );
		}
		unset( $group );
		foreach ( $groups as &$group ) {
			foreach ( $group['metrics'] as &$metric ) { $metric['scale'] = $max[ $metric['key'] ] ?? 0; }
			unset( $metric );
		}
		unset( $group );
		usort( $groups, static fn( $a, $b ) => strnatcasecmp( $a['name'], $b['name'] ) );
		return [ 'groups' => array_values( $groups ), 'task_count' => count( $rows ), 'has_actual' => $object_type === 'daily_task' ];
	}

	private function metric( array $row ): array {
		$unit_key = sanitize_key( (string) ( $row['unit_key'] ?? '' ) );
		$is_time = in_array( $unit_key, [ 'minute', 'hour' ], TRUE );
		$type_id = absint( $row['task_type_id'] ?? 0 );
		$unit = $is_time ? __( 'ساعت', 'kasebi-erp' ) : trim( (string) ( $row['unit_symbol'] ?: $row['unit_label'] ) );
		return [
			'key' => $type_id . ':' . ( $is_time ? 'time' : ( $unit_key ?: 'count' ) ),
			'type' => (string) ( $row['type_label'] ?: __( 'فعالیت', 'kasebi-erp' ) ),
			'icon' => sanitize_html_class( (string) ( $row['type_icon'] ?? '' ) ),
			'unit' => $unit ?: __( 'آیتم', 'kasebi-erp' ), 'target' => 0.0, 'actual' => 0.0, 'tasks' => 0, 'reported' => 0,
		];
	}

	private function metric_value( mixed $value, string $unit_key ): float {
		$value = is_numeric( $value ) ? (float) $value : 0.0;
		return sanitize_key( $unit_key ) === 'minute' ? $value / 60 : $value;
	}

	private function display_input_date( string $date ): string {
		$timestamp = strtotime( $date . ' 12:00:00' );
		return $timestamp !== FALSE ? date_i18n( 'Y-m-d', $timestamp ) : '';
	}

	private function normalize_input_date( string $date ): string {
		$date = KERP_Helpers_Format::sanitize_numbers( sanitize_text_field( wp_unslash( $date ) ) );
		$date = str_replace( '/', '-', trim( $date ) );
		$year = (int) strtok( $date, '-' );
		if ( $year > 0 && $year < 1700 ) {
			$converted = KERP_Helpers_Date::jalali_to_gregorian( $date );
			return is_string( $converted ) ? $converted : '';
		}
		return KERP_Modules_Programs_Plans::instance()->normalize_date( $date );
	}

	private function error( string $message ): void {
		wp_send_json( [ 'status' => 'error', 'message' => $message, 'msg' => $message ] );
	}
}
