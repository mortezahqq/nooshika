<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Programs_Module {
	
	private const DB_VERSION        = '1.6.0';
	
	private const DB_VERSION_OPTION = 'kerp_programs_db_version';
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {
		$this->load_services();
		$this->maybe_install();
		$this->register_hooks();
	}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	private function load_services(): void {
		KERP_Modules_Programs_Installer::instance();
		KERP_Modules_Programs_Settings::instance();
		KERP_Modules_Programs_Types::instance();
		KERP_Modules_Programs_Units::instance();
		KERP_Modules_Programs_Taxonomies::instance();
		KERP_Modules_Programs_Plans::instance();
		KERP_Modules_Programs_Comments::instance();
		KERP_Modules_Programs_Tasks::instance();
		KERP_Modules_Programs_Resources::instance();
		KERP_Modules_Programs_Templates::instance();
		KERP_Modules_Programs_Results::instance();
		KERP_Modules_Programs_Overview::instance();
		KERP_Modules_Programs_Performance::instance();
		KERP_Modules_Programs_Dashboard::instance();
		KERP_Modules_Programs_Form::instance();
		KERP_Modules_Programs_Api::instance();
		KERP_Modules_Programs_Public::instance();
	}
	
	private function maybe_install(): void {
		if ( (string) get_option( self::DB_VERSION_OPTION, '' ) === self::DB_VERSION ) {
			return;
		}
		KERP_Modules_Programs_Installer::instance()->install();
		update_option( self::DB_VERSION_OPTION, self::DB_VERSION, FALSE );
	}
	
	private function register_hooks(): void {
		add_filter( 'kerp_app_pages', [ $this, 'register_pages' ], 47 );
		add_filter( 'kerp_employee_permission_groups', [ $this, 'register_permissions' ], 47 );
		add_filter( 'kerp_customer_profile_tabs', [ $this, 'register_customer_tab' ], 47, 3 );
		add_filter( 'kerp_employee_profile_tabs', [ $this, 'register_employee_tab' ], 47, 3 );
		add_action( 'kerp_footer_template', [ $this, 'render_modals' ], 47 );
		add_filter( 'kerp_admin_bar_items', [ $this, 'admin_bar_items' ] );
	}
	
	public function register_pages( array $pages ): array {
		$settings      = KERP_Modules_Programs_Settings::instance();
		$group         = [
			'key'   => 'programs',
			'title' => __( 'برنامه‌ها و پایش عملکرد', 'kasebi-erp' ),
			'icon'  => 'uik-r fa-list-check',
			'order' => 47,
		];
		$settings_menu = [
			'key'   => 'programs-settings',
			'title' => __( 'تنظیمات', 'kasebi-erp' ),
			'icon'  => 'ni ni-setting-alt',
			'order' => 90,
		];
		
		$pages['programs']                     = [
			'title'      => $settings->get_plan_plural_label(),
			'route'      => 'programs',
			'type'       => 'page',
			'template'   => 'modules/programs/pages/programs.php',
			'permission' => 'programs.view',
			'navigation' => [ 'group' => $group, 'icon' => 'ni ni-calendar-check', 'order' => 10 ],
		];
		$pages['programs-dashboard']           = [
			'title'      => __( 'داشبورد برنامه‌ریزی', 'kasebi-erp' ),
			'route'      => 'programs/dashboard',
			'type'       => 'page',
			'template'   => 'modules/programs/pages/dashboard.php',
			'permission' => 'programs.view',
			'navigation' => [ 'group' => $group, 'icon' => 'ni ni-dashboard', 'order' => 5 ],
		];
		$pages['program']                      = [
			'title'      => $settings->get_plan_singular_label(),
			'route'      => 'programs/{plan_id}',
			'type'       => 'sub-page',
			'template'   => 'modules/programs/pages/program.php',
			'permission' => 'programs.view',
			'navigation' => [ 'hidden' => TRUE, 'active' => 'programs' ],
		];
		$pages['program-templates']            = [
			'title'      => $settings->get_template_plural_label(),
			'route'      => 'programs/templates',
			'type'       => 'page',
			'template'   => 'modules/programs/pages/templates.php',
			'permission' => 'programs.templates.manage',
			'navigation' => [ 'group' => $group, 'icon' => 'ni ni-template', 'order' => 20 ],
		];
		$pages['program-template']             = [
			'title'      => $settings->get_template_singular_label(),
			'route'      => 'programs/templates/{template_id}',
			'type'       => 'sub-page',
			'template'   => 'modules/programs/pages/template.php',
			'permission' => 'programs.templates.manage',
			'navigation' => [ 'hidden' => TRUE, 'active' => 'program-templates' ],
		];
		$pages['program-results']              = [
			'title'      => __( 'نتایج و بررسی', 'kasebi-erp' ),
			'route'      => 'programs/results',
			'type'       => 'page',
			'template'   => 'modules/programs/pages/results.php',
			'permission' => 'programs.results.view',
			'navigation' => [ 'group' => $group, 'icon' => 'ni ni-check-circle', 'order' => 30 ],
		];
		$pages['programs-settings-general']    = [
			'title'      => __( 'تنظیمات عمومی برنامه‌ها', 'kasebi-erp' ),
			'route'      => 'programs/settings',
			'type'       => 'settings',
			'template'   => 'modules/programs/settings/general.php',
			'permission' => 'programs.manage_settings',
			'navigation' => [
				'group' => $group,
				'menu'  => $settings_menu,
				'title' => __( 'عمومی', 'kasebi-erp' ),
				'order' => 10,
			],
		];
		$pages['programs-settings-types']      = [
			'title'      => __( 'انواع آیتم برنامه', 'kasebi-erp' ),
			'route'      => 'programs/settings/types',
			'type'       => 'settings',
			'template'   => 'modules/programs/settings/types.php',
			'permission' => 'programs.types.manage',
			'navigation' => [
				'group' => $group,
				'menu'  => $settings_menu,
				'title' => __( 'انواع آیتم', 'kasebi-erp' ),
				'order' => 20,
			],
		];
		$pages['programs-settings-units']      = [
			'title'      => __( 'واحدهای برنامه', 'kasebi-erp' ),
			'route'      => 'programs/settings/units',
			'type'       => 'settings',
			'template'   => 'modules/programs/settings/units.php',
			'permission' => 'programs.units.manage',
			'navigation' => [
				'group' => $group,
				'menu'  => $settings_menu,
				'title' => __( 'واحدها', 'kasebi-erp' ),
				'order' => 30,
			],
		];
		$pages['programs-settings-taxonomies'] = [
			'title'      => __( 'دسته‌بندی‌های برنامه', 'kasebi-erp' ),
			'route'      => 'programs/settings/taxonomies',
			'type'       => 'settings',
			'template'   => 'modules/programs/settings/taxonomies.php',
			'permission' => 'programs.taxonomies.manage',
			'navigation' => [
				'group' => $group,
				'menu'  => $settings_menu,
				'title' => __( 'دسته‌بندی‌ها', 'kasebi-erp' ),
				'order' => 40,
			],
		];
		$pages['programs-settings-terms']      = [
			'title'      => __( 'گزینه‌های دسته‌بندی', 'kasebi-erp' ),
			'route'      => 'programs/settings/terms',
			'type'       => 'settings',
			'template'   => 'modules/programs/settings/terms.php',
			'permission' => 'programs.taxonomies.manage',
			'navigation' => [
				'group' => $group,
				'menu'  => $settings_menu,
				'title' => __( 'گزینه‌ها', 'kasebi-erp' ),
				'order' => 50,
			],
		];
		
		return $pages;
	}
	
	public function register_permissions( array $groups ): array {
		$groups['programs'] = [
			'key'    => 'programs',
			'label'  => __( 'برنامه‌ها و پایش عملکرد', 'kasebi-erp' ),
			'icon'   => 'uik-r fa-list-check',
			'order'  => 47,
			'blocks' => [
				'programs' => [
					'key'         => 'programs',
					'label'       => __( 'برنامه‌ها', 'kasebi-erp' ),
					'icon'        => 'ni ni-calendar-check',
					'order'       => 10,
					'permissions' => [
						'view'     => [
							'key'   => 'programs.view',
							'label' => __( 'دسترسی به بخش برنامه‌ها', 'kasebi-erp' ),
							'type'  => 'view',
							'order' => 10,
						],
						'list'     => [
							'key'   => 'programs.list',
							'label' => __( 'مشاهده برنامه‌ها', 'kasebi-erp' ),
							'type'  => 'view',
							'order' => 20,
							'scope' => [
								'options' => [
									'own' => __( 'فقط برنامه‌های مسئولیت خود', 'kasebi-erp' ),
									'all' => __( 'همه برنامه‌ها', 'kasebi-erp' ),
								],
								'default' => 'own',
							],
						],
						'create'   => [
							'key'   => 'programs.create',
							'label' => __( 'ایجاد برنامه و بارگذاری قالب', 'kasebi-erp' ),
							'type'  => 'action',
							'order' => 30,
						],
						'edit'     => [
							'key'   => 'programs.edit',
							'label' => __( 'ویرایش برنامه و آیتم‌ها', 'kasebi-erp' ),
							'type'  => 'action',
							'order' => 40,
						],
						'delete'   => [
							'key'   => 'programs.delete',
							'label' => __( 'حذف یا آرشیو برنامه', 'kasebi-erp' ),
							'type'  => 'action',
							'order' => 50,
						],
						'template' => [
							'key'   => 'programs.templates.manage',
							'label' => __( 'مدیریت قالب‌های برنامه', 'kasebi-erp' ),
							'type'  => 'action',
							'order' => 60,
						],
					],
				],
				'results'  => [
					'key'         => 'results',
					'label'       => __( 'نتایج و بررسی', 'kasebi-erp' ),
					'icon'        => 'ni ni-check-circle',
					'order'       => 20,
					'permissions' => [
						'view'   => [
							'key'   => 'programs.results.view',
							'label' => __( 'مشاهده نتایج', 'kasebi-erp' ),
							'type'  => 'view',
							'order' => 10,
						],
						'edit'   => [
							'key'   => 'programs.results.edit',
							'label' => __( 'ثبت و ویرایش نتیجه', 'kasebi-erp' ),
							'type'  => 'action',
							'order' => 20,
						],
						'review' => [
							'key'   => 'programs.results.review',
							'label' => __( 'بررسی و امتیازدهی نتیجه', 'kasebi-erp' ),
							'type'  => 'action',
							'order' => 30,
						],
					],
				],
				'settings' => [
					'key'         => 'settings',
					'label'       => __( 'ساختار و تنظیمات', 'kasebi-erp' ),
					'icon'        => 'ni ni-setting-alt',
					'order'       => 30,
					'permissions' => [
						'general'    => [
							'key'   => 'programs.manage_settings',
							'label' => __( 'تنظیمات عمومی', 'kasebi-erp' ),
							'type'  => 'action',
							'order' => 10,
						],
						'types'      => [
							'key'   => 'programs.types.manage',
							'label' => __( 'مدیریت انواع آیتم', 'kasebi-erp' ),
							'type'  => 'action',
							'order' => 20,
						],
						'units'      => [
							'key'   => 'programs.units.manage',
							'label' => __( 'مدیریت واحدها', 'kasebi-erp' ),
							'type'  => 'action',
							'order' => 30,
						],
						'taxonomies' => [
							'key'   => 'programs.taxonomies.manage',
							'label' => __( 'مدیریت دسته‌بندی و گزینه‌ها', 'kasebi-erp' ),
							'type'  => 'action',
							'order' => 40,
						],
					],
				],
			],
		];
		
		return $groups;
	}
	
	public function register_customer_tab( array $tabs, int $customer_id, WP_User $customer ): array {
		if ( kerp_can( 'programs.view', 'view' ) ) {
			$tabs['programs'] = [
				'key'        => 'programs',
				'title'      => KERP_Modules_Programs_Settings::instance()->get_plan_plural_label(),
				'icon'       => 'ni ni-calendar-check',
				'order'      => 75,
				'group'      => 'planning-learning',
				'permission' => 'programs.view',
				'action'     => 'view',
				'template'   => 'modules/programs/tabs/customer-programs.php',
			];
		}
		
		return $tabs;
	}
	
	public function register_employee_tab( array $tabs, int $employee_id, WP_User $employee ): array {
		if ( kerp_can( 'programs.view', 'view' ) ) {
			$tabs['programs'] = [
				'key'        => 'programs',
				'title'      => __( 'برنامه‌های مسئولیت', 'kasebi-erp' ),
				'icon'       => 'ni ni-calendar-check',
				'order'      => 75,
				'permission' => 'programs.view',
				'action'     => 'view',
				'template'   => 'modules/programs/tabs/employee-programs.php',
			];
		}
		
		return $tabs;
	}
	
	public function render_modals(): void {
		KERP_Modules_Programs_Form::instance()->render_modals();
	}
	
	public function admin_bar_items( array $items ): array {
		$items['programs'] = [
			'title' => KERP_Modules_Programs_Settings::instance()->get_plan_plural_label(),
			'url'   => '/erp/programs/dashboard/',
		];
		
		return $items;
	}
	
}
