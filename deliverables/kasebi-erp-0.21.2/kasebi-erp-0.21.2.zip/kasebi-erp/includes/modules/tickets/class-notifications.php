<?php
defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Tickets_Notifications {
	public static function events(): array { return [ 'created' => 'ثبت تیکت', 'replied' => 'پاسخ جدید', 'status_changed' => 'تغییر وضعیت', 'assigned' => 'واگذاری مسئول', 'referred' => 'ارجاع پیام' ]; }
	public static function recipients(): array { return [ 'customer' => 'کاربر تیکت', 'employee' => 'مسئول (یا مدیران عمومی)', 'referred' => 'کارشناس ارجاع / واگذاری', 'custom' => 'شماره دلخواه' ]; }
	public static function variables(): array { return [ '{ticket_id}' => 'شماره تیکت', '{subject}' => 'موضوع', '{status}' => 'وضعیت', '{customer_name}' => 'نام مشتری', '{first_name}' => 'نام', '{sender_name}' => 'فرستنده', '{url}' => 'لینک مناسب گیرنده', '{erp_url}' => 'لینک ERP', '{panel_url}' => 'لینک پنل کاربر', '{date}' => 'تاریخ شمسی', '{site_name}' => 'نام سایت' ]; }
	public static function rules(): array { return array_map( static function ( $rule ) { if ( ( $rule['recipient'] ?? '' ) === 'initiator' ) { $rule['recipient'] = 'customer'; } return $rule; }, (array) get_option( 'kerp_tickets_sms_rules', [] ) ); }
	public static function save_rules( array $rules ): void {
		$clean = [];
		foreach ( $rules as $rule ) {
			if ( ! is_array( $rule ) ) { continue; }
			if ( empty( $rule['pattern'] ) && empty( $rule['event'] ) ) { continue; }
			if ( ! isset( self::events()[$rule['event'] ?? ''], self::recipients()[$rule['recipient'] ?? ''] ) || empty( $rule['pattern'] ) ) { throw new RuntimeException( 'رویداد، گیرنده و نام پترن همه قوانین را تکمیل کنید.' ); }
			$row = []; foreach ( [ 'event', 'status', 'recipient', 'receptor', 'pattern', 'sender', 'enabled', 'legacy' ] as $key ) { $row[$key] = sanitize_text_field( $rule[$key] ?? '' ); } $row['variables'] = sanitize_textarea_field( $rule['variables'] ?? '' );
            $row['enabled'] = '1'; $row['sender'] = '';
            if ( $row['event'] !== 'status_changed' ) { $row['status'] = ''; }
            if ( $row['status'] !== '' && ! isset( KERP_Modules_Tickets_Store::statuses()[$row['status']] ) ) { throw new RuntimeException( 'وضعیت تیکت نامعتبر است.' ); }
            $clean[] = $row;
		}
		update_option( 'kerp_tickets_sms_rules', $clean, FALSE );
	}
	public static function import_rules(): void {
		$rules = self::rules();
		foreach ( [
			[ 'ticket_received_admin', 'created', 'employee', 'owner', '' ], [ 'ticket_created_customer', 'created', 'customer', 'staff', '' ],
			[ 'ticket_answered_admin', 'replied', 'employee', 'owner', '' ], [ 'ticket_answered_customer', 'replied', 'customer', 'staff', '' ],
			[ 'ticket_pending_customer', 'status_changed', 'customer', '', 'need_action' ], [ 'ticket_referred_admin', 'referred', 'referred', '', '' ]
		] as [ $old, $event, $recipient, $sender, $status ] ) {
			$pattern = get_option( 'sms_pattern_' . $old ); if ( ! $pattern || in_array( $old, array_column( $rules, 'legacy' ), TRUE ) ) { continue; }
			$rules[] = [ 'legacy' => $old, 'enabled' => '1', 'event' => $event, 'recipient' => $recipient, 'sender' => $sender, 'status' => $status, 'pattern' => $pattern, 'receptor' => '', 'variables' => 'token:{url};token10:' . ( $event === 'created' ? '{customer_name}' : ( $status === 'need_action' ? '{first_name}' : '{sender_name}' ) ) ];
		}
		if ( ! in_array( 'responseChange', array_column( $rules, 'legacy' ), TRUE ) ) { $rules[] = [ 'legacy' => 'responseChange', 'enabled' => '1', 'event' => 'assigned', 'recipient' => 'referred', 'sender' => '', 'status' => '', 'pattern' => 'responseChange', 'receptor' => '', 'variables' => 'token:{subject};token2:{url}' ]; }
		self::save_rules( $rules );
	}
	public static function send( string $event, int $id, int $referred = 0 ): void {
		$store = KERP_Modules_Tickets_Store::class; $ticket = $store::get( $id ); if ( ! $ticket ) { return; }
		$owner = (int) $ticket['user_id']; $sender = get_current_user_id(); $responsible = (int) $store::meta( 'ticket', $id, 'ticket_responsible_user' ); $initiator = (int) $store::meta( 'ticket', $id, 'sender_id' );
		$internal = isset( $store::staff()[$owner] );
		$erp = home_url( '/erp/customers/' . (int) $ticket['user_id'] . '/?tab=tickets&ticket_id=' . $id ); $panel = home_url( '/panel/tickets/support/' . $id . '/' );
		$context = [ '{ticket_id}' => (string) $id, '{subject}' => $ticket['subject'], '{status}' => $store::statuses()[$ticket['status']] ?? $ticket['status'], '{customer_name}' => get_userdata( $owner )->display_name ?? '', '{first_name}' => get_user_meta( $owner, 'first_name', TRUE ), '{sender_name}' => get_userdata( $sender )->display_name ?? '', '{erp_url}' => $erp, '{panel_url}' => $panel, '{date}' => $store::date( current_time( 'mysql' ) ), '{site_name}' => get_bloginfo( 'name' ) ];
		foreach ( self::rules() as $rule ) {
			if ( $rule['event'] !== $event || ( $event === 'status_changed' && ! empty( $rule['status'] ) && $rule['status'] !== $ticket['status'] ) ) { continue; }
			$recipient = $rule['recipient']; $user = [ 'customer' => $owner, 'employee' => $responsible, 'referred' => $referred, 'initiator' => $initiator ][$recipient] ?? 0;
			if ( $internal && $event === 'replied' && ! empty( $rule['legacy'] ) ) {
				if ( $rule['legacy'] !== 'ticket_answered_customer' ) { continue; }
				$user = $sender === $owner ? $initiator : $owner;
			}
			if ( $user && ( get_user_meta( $user, 'customer_sms_notif', TRUE ) ?: 'send' ) !== 'send' ) { continue; }
			$phones = $user ? ( get_user_meta( $user, 'nooshika_phone_num', TRUE ) ?: get_user_meta( $user, 'billing_phone', TRUE ) ) : ( $recipient === 'custom' ? $rule['receptor'] : ( $recipient === 'employee' ? get_option( 'sms_general_manager_numbers', '' ) : '' ) );
			$context['{url}'] = $recipient === 'customer' && ! $internal ? $panel : $erp;
			foreach ( array_unique( array_filter( array_map( 'trim', explode( ',', (string) $phones ) ) ) ) as $phone ) {
				$payload = [];
				foreach ( preg_split( '/[;\r\n]+/', $rule['variables'] ) as $part ) { $pair = preg_split( '/[:=]/', $part, 2 ); if ( count( $pair ) === 2 && preg_match( '/^[a-zA-Z0-9_-]+$/', trim( $pair[0] ) ) ) { $payload[trim( $pair[0] )] = strtr( trim( $pair[1] ), $context ); } }
				$payload['receptor'] = $phone; $payload['template'] = $rule['pattern'];
				try { if ( class_exists( 'kasebiSMS' ) ) { $response = ( new kasebiSMS() )->send_pattern_sms( $payload ); do_action( 'kerp_ticket_sms_sent', $response, $payload, $ticket ); } } catch ( Throwable $e ) { do_action( 'kerp_ticket_notification_failed', $id, $event, $e ); }
			}
		}
		if ( in_array( $event, [ 'created', 'replied' ], TRUE ) ) {
			$recipients = $event === 'created' ? [ $owner, $responsible ?: 3 ] : [ $sender === $owner ? ( $internal ? $initiator : ( $responsible ?: $initiator ) ) : $owner ];
			foreach ( array_unique( array_filter( $recipients ) ) as $user_id ) {
				if ( ( get_user_meta( $user_id, 'customer_email_notif', TRUE ) ?: 'send' ) !== 'send' ) { continue; }
				$email = get_user_meta( $user_id, 'email', TRUE ) ?: ( get_userdata( $user_id )->user_email ?? '' ); $url = $user_id === $owner && ! $internal ? $panel : $erp;
				if ( is_email( $email ) ) { wp_mail( $email, ( $event === 'created' ? 'تیکت جدید: ' : 'پاسخ جدید: ' ) . $ticket['subject'], '<p>' . esc_html( $ticket['subject'] ) . '</p><p><a href="' . esc_url( $url ) . '">مشاهده گفت‌وگو</a></p>', [ 'Content-Type: text/html; charset=UTF-8' ] ); }
			}
		}
		do_action( 'kerp_ticket_' . $event, $ticket, $referred );
	}
}
