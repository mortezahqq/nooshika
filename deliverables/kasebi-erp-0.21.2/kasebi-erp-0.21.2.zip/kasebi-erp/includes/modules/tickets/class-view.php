<?php
defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Tickets_View {
	
	public static function hidden( string $name, $value ): void {
		echo '<input type="hidden" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '">';
	}
	
	public static function start( string $operation, int $id = 0, bool $public = FALSE ): void {
		echo '<form class="kerp-ticket-form" enctype="multipart/form-data" data-public="' . ( $public ? '1' : '0' ) . '" data-endpoint="' . esc_url( home_url( $public ? '/n-ajax' : '/kerp-ajax' ) ) . '"><div class="row g-3">';
		self::hidden( 'tickets_nonce', wp_create_nonce( 'kerp_tickets' ) );
		self::hidden( 'operation', $operation );
		self::hidden( 'ticket_id', $id );
	}
	
	public static function end( string $label = 'ذخیره' ): void {
		echo '<div class="col-12"><button type="submit" class="btn btn-primary">' . esc_html( $label ) . '</button></div></div></form>';
	}
	
	public static function button( string $target, string $label, string $class = 'btn-outline-primary' ): void {
		echo '<button type="button" class="btn btn-sm ' . esc_attr( $class ) . '" data-bs-toggle="modal" data-bs-target="#' . esc_attr( $target ) . '">' . esc_html( $label ) . '</button>';
	}
	
	public static function editor( bool $public = FALSE, string $department = '', bool $show_ready_replies = TRUE ): void {
        ob_start();
		if ( $show_ready_replies && ! $public && kerp_can( 'tickets.reply', 'action' ) ) {
			$rows = KERP_Modules_Tickets_Store::ready_replies();
			echo '<div class="col-12"><div class="dropdown kerp-ticket-ready-menu" data-department="' . esc_attr( $department ) . '"><button type="button" class="btn btn-icon btn-sm dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false" title="پاسخ آماده" aria-label="پاسخ آماده"><em class="icon ni ni-hash"></em></button><div class="dropdown-menu dropdown-menu-end"><div class="kerp-ticket-ready-items">';
			foreach ( $rows as $row ) {
				echo '<button type="button" class="dropdown-item kerp-ticket-ready-insert" data-content="' . esc_attr( $row['content'] ?? '' ) . '" data-department="' . esc_attr( $row['department'] ?? '' ) . '">' . esc_html( $row['label'] ?? '' ) . '</button>';
			}
			echo '</div><p class="kerp-ticket-ready-empty text-soft px-3 py-2 mb-0">پاسخی برای این دپارتمان ثبت نشده است.</p><div class="dropdown-divider"></div><button type="button" class="dropdown-item kerp-ticket-ready-add" data-bs-toggle="modal" data-bs-target="#kerp-ticket-quick-ready">افزودن پاسخ آماده</button><a class="dropdown-item page_activator" href="' . esc_url( home_url( '/erp/tickets/settings/replies/' ) ) . '" data-url="/erp/tickets/settings/replies/">مدیریت پاسخ‌های آماده</a></div></div></div>';
		}
        $ready_menu = ob_get_clean();
        echo '<div class="col-12 nk-reply-form-editor">';
		KERP_Helpers_Template::render_template( 'app/components/fields/quill.php', [ 'field' => [ 'name' => 'content', 'label' => '', 'value' => '', 'options' => [], 'type' => 'quill', 'class' => 'col-12' ] ] );
        echo '<div class="reply_form_upload_section p-3" id="kerp-ticket-response-upload" hidden>';
		KERP_Helpers_Template::render_template( 'app/components/fields/upload.php', [ 'field' => array_replace( [ 'id' => 'kerp-ticket-reply-attachments', 'name' => 'ticket_attachments', 'label' => 'پیوست‌ها (حداکثر ۵۰ فایل)', 'value' => '', 'options' => [], 'type' => 'upload', 'class' => 'col-12' ], [
			'max_files'    => 50,
			'action' => $public ? 'kerp_tickets_save' : 'tickets_save',
		] ) ] );
        echo '</div><div class="nk-reply-form-tools"><ul class="nk-reply-form-actions g-1"><li class="me-2"><button type="submit" class="btn btn-primary">ارسال پاسخ</button></li><li>' . $ready_menu . '</li><li><button type="button" class="btn btn-icon btn-sm" data-ticket-upload-toggle aria-controls="kerp-ticket-response-upload" aria-expanded="false" title="افزودن فایل ضمیمه" aria-label="افزودن فایل ضمیمه"><em class="' . ( $public ? 'hik-r fa-attachment' : 'icon ni ni-clip-v' ) . '"></em></button></li></ul></div></div>';
	}
	
	public static function record_modal( int $customer = 0, ?array $ticket = NULL, bool $public = FALSE ): void {
        $store = KERP_Modules_Tickets_Store::class;
        $id = (int) ( $ticket['id'] ?? 0 );
        $fields = [
            [ 'type' => 'hidden', 'name' => 'tickets_nonce', 'value' => wp_create_nonce( 'kerp_tickets' ) ],
            [ 'type' => 'hidden', 'name' => 'operation', 'value' => $id ? 'edit' : 'create' ],
            [ 'type' => 'hidden', 'name' => 'ticket_id', 'value' => $id ],
            [ 'type' => 'hidden', 'name' => 'ticket_endpoint', 'value' => home_url( $public ? '/n-ajax' : '/kerp-ajax' ) ],
            [ 'type' => 'hidden', 'name' => 'ticket_public', 'value' => $public ? '1' : '0' ],
            [ 'type' => 'hidden', 'name' => 'customer_id', 'value' => $customer ],
            [ 'type' => 'text', 'name' => 'subject', 'label' => 'موضوع تیکت', 'value' => $ticket['subject'] ?? '', 'class' => 'col-12', 'required' => TRUE ],
            [ 'type' => 'select', 'name' => 'department', 'label' => 'دپارتمان', 'value' => $id ? $store::meta( 'ticket', $id, 'department' ) : '', 'options' => $store::labels( 'departments' ), 'class' => 'col-6' ],
            [ 'type' => 'select', 'name' => 'priority', 'label' => 'اولویت', 'value' => $ticket['priority'] ?? 'normal', 'options' => $store::priorities(), 'class' => 'col-6' ],
        ];
        if ( ! $id && ! $public && ! $customer ) {
            $fields[] = [ 'type' => 'customer-search', 'name' => 'customer_id', 'label' => 'مشتری', 'class' => 'col-12' ];
            $fields[] = [ 'type' => 'select', 'name' => 'staff_owner', 'label' => 'یا گفت‌وگوی داخلی با کارشناس', 'options' => [ 0 => 'برای مشتری انتخاب‌شده' ] + $store::staff(), 'class' => 'col-12' ];
        }
        if ( ! $id ) {
            $fields[] = [ 'type' => 'quill', 'name' => 'content', 'label' => 'متن پیام', 'class' => 'col-12', 'required' => TRUE ];
            $fields[] = [ 'id' => 'kerp-ticket-record-attachments', 'type' => 'upload', 'name' => 'ticket_attachments', 'label' => 'پیوست‌ها (حداکثر ۵۰ فایل)', 'class' => 'col-12', 'max_files' => 50, 'action' => $public ? 'kerp_tickets_save' : 'tickets_save' ];
        }
        $fields = apply_filters( 'kerp_ticket_record_fields', $fields, $customer, $ticket, $public );
        KERP_Helpers_Template::render_modal( [
            'id' => 'kerp-ticket-record', 'title' => $id ? 'ویرایش تیکت' : 'تیکت جدید',
            'action' => $public ? 'kerp_tickets_save' : 'tickets_save',
            'button' => $id ? 'ذخیره تغییرات' : 'ثبت تیکت', 'fields' => $fields,
        ] );
    }

    public static function ready_modal(): void {
        static $rendered = FALSE;
        if ( $rendered || ! kerp_can( 'tickets.reply', 'action' ) ) { return; }
        $rendered = TRUE;
        KERP_Helpers_Template::render_modal( [
            'id' => 'kerp-ticket-quick-ready', 'title' => 'افزودن پاسخ آماده', 'action' => 'tickets_save', 'button' => 'ذخیره پاسخ آماده',
            'fields' => [
                [ 'type' => 'hidden', 'name' => 'tickets_nonce', 'value' => wp_create_nonce( 'kerp_tickets' ) ],
                [ 'type' => 'hidden', 'name' => 'operation', 'value' => 'ready' ],
                [ 'type' => 'hidden', 'name' => 'inline_ready', 'value' => 1 ],
                [ 'type' => 'hidden', 'name' => 'index', 'value' => '' ],
                [ 'type' => 'text', 'name' => 'label', 'label' => 'عنوان پاسخ', 'class' => 'col-12', 'required' => TRUE ],
                [ 'type' => 'select', 'name' => 'department', 'label' => 'دپارتمان', 'options' => [ '' => 'همه دپارتمان‌ها' ] + KERP_Modules_Tickets_Store::labels( 'departments' ), 'class' => 'col-12' ],
                [ 'type' => 'textarea', 'name' => 'content', 'label' => 'متن پاسخ', 'class' => 'col-12', 'required' => TRUE ],
            ],
        ] );
    }

	public static function attachments( array $message, bool $public = FALSE ): void {
		global $wpdb;
		$attachments = KERP_Modules_Tickets_Store::meta( 'message', (int) $message['id'], 'attachment', [] );
		if ( ! is_array( $attachments ) ) {
			$attachments = array_filter( explode( ',', (string) $attachments ) );
		}
		if ( ! empty( $message['attachment'] ) ) {
			$attachments = array_merge( $attachments, array_filter( explode( ',', (string) $message['attachment'] ) ) );
		}
		$attachments = array_values( array_unique( array_filter( $attachments, 'is_string' ) ) );
		if ( ! $attachments ) {
			return;
		}
		echo '<div class="kerp-ticket-attachments">';
		foreach ( $attachments as $url ) {
			if ( ! is_string( $url ) || ! esc_url( $url ) ) {
				continue;
			}
			$path     = wp_parse_url( $url, PHP_URL_PATH );
			$name     = rawurldecode( basename( (string) $path ) );
			$ext      = strtolower( pathinfo( $name, PATHINFO_EXTENSION ) );
			$original = $wpdb->get_var( $wpdb->prepare( 'SELECT original_name FROM ' . KERP_Modules_Tickets_Store::table( 'files' ) . ' WHERE file_url=%s LIMIT 1', $url ) );
			if ( $original ) {
				$name = $original;
			}
			if ( ! $ext ) {
				$ext = strtolower( pathinfo( $name, PATHINFO_EXTENSION ) );
			}
			$is_image = in_array( $ext, [ 'png', 'jpg', 'jpeg', 'gif', 'webp', 'bmp', 'svg', 'avif' ], TRUE );
			$is_audio = in_array( $ext, [ 'mp3', 'wav', 'ogg', 'oga', 'm4a', 'aac', 'flac', 'opus' ], TRUE );
			$is_video = in_array( $ext, [ 'mp4', 'm4v', 'webm', 'mov', 'ogv' ], TRUE );
			echo '<div class="kerp-ticket-attachment ' . ( $is_image ? 'is-image' : ( $is_audio || $is_video ? 'is-media' : 'is-file' ) ) . '">';
			if ( $is_image ) {
				echo '<a class="kerp-ticket-image-preview" href="' . esc_url( $url ) . '" data-image-name="' . esc_attr( $name ) . '" aria-label="' . esc_attr( 'بزرگ‌نمایی تصویر: ' . $name ) . '"><img loading="lazy" src="' . esc_url( $url ) . '" alt="' . esc_attr( $name ) . '"></a>';
			} elseif ( $is_video ) {
				echo '<video controls playsinline preload="metadata" aria-label="' . esc_attr( $name ) . '" src="' . esc_url( $url ) . '"></video>';
			} elseif ( $is_audio ) {
				echo '<audio controls preload="metadata" aria-label="' . esc_attr( $name ) . '" src="' . esc_url( $url ) . '"></audio>';
			}
			echo '<a class="kerp-ticket-file" target="_blank" rel="noopener" download="' . esc_attr( $name ) . '" href="' . esc_url( $url ) . '" title="' . esc_attr( $name ) . '">' . '<span>' . esc_html( $name ) . '</span><em class="' . ( $public ? 'hik-r fa-download' : 'icon ni ni-download' ) . '" aria-hidden="true"></em></a></div>';
		}
		if ( count( $attachments ) > 1 ) {
			echo '<button type="button" class="btn btn-sm btn-outline-primary kerp-ticket-download-all">دانلود همه پیوست‌ها</button>';
		}
		echo '</div>';
	}
	
}
