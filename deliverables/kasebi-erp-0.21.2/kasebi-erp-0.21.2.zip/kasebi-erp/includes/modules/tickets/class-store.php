<?php
defined( 'ABSPATH' ) || exit;

/** ERP-owned storage. Legacy identifiers are retained separately from live primary keys. */
final class KERP_Modules_Tickets_Store {
	public static function ready_replies(): array {
		$rows = get_user_meta( get_current_user_id(), 'ticket_ready_template', TRUE );
		if ( ! is_array( $rows ) ) { return []; }
		// Preserve stored indices so editing a legacy response targets the same record.
		return array_filter( $rows, static function ( $row ): bool {
			if ( ! is_array( $row ) ) { return FALSE; }
			foreach ( [ 'label', 'content', 'department' ] as $key ) {
				if ( isset( $row[$key] ) && ! is_scalar( $row[$key] ) ) { return FALSE; }
			}
			return TRUE;
		} );
	}
	public static function table( string $name ): string { global $wpdb; return $wpdb->prefix . 'kerp_support_' . $name; }
	public static function install(): void {
		if ( get_option( 'kerp_tickets_schema' ) === '2' ) { return; }
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$charset = $wpdb->get_charset_collate();
		$schemas = [
			'tickets' => "id bigint unsigned NOT NULL AUTO_INCREMENT, legacy_id bigint unsigned DEFAULT NULL, user_id bigint unsigned NOT NULL, subject varchar(255) NOT NULL, priority varchar(20) NOT NULL DEFAULT 'normal', status varchar(40) NOT NULL DEFAULT 'open', last_message_id bigint unsigned DEFAULT NULL, last_message_at datetime DEFAULT NULL, created_at datetime NOT NULL, deleted_at datetime DEFAULT NULL, PRIMARY KEY  (id), UNIQUE KEY legacy_id (legacy_id), KEY owner_status (user_id,status), KEY last_message_at (last_message_at)",
			'messages' => "id bigint unsigned NOT NULL AUTO_INCREMENT, legacy_id bigint unsigned DEFAULT NULL, ticket_id bigint unsigned NOT NULL, sender_id bigint unsigned NOT NULL, reply_to bigint unsigned DEFAULT NULL, message longtext NOT NULL, attachment text DEFAULT NULL, sent_at datetime NOT NULL, PRIMARY KEY  (id), UNIQUE KEY legacy_id (legacy_id), KEY ticket_messages (ticket_id,id)",
			'meta' => "id bigint unsigned NOT NULL AUTO_INCREMENT, kind varchar(20) NOT NULL, object_id bigint unsigned NOT NULL, meta_key varchar(191) NOT NULL, meta_value longtext DEFAULT NULL, PRIMARY KEY  (id), KEY object_meta (kind,object_id,meta_key)",
			'files' => "id bigint unsigned NOT NULL AUTO_INCREMENT, legacy_id bigint unsigned DEFAULT NULL, user_id bigint unsigned NOT NULL, original_name varchar(255) NOT NULL, saved_name varchar(255) NOT NULL, file_url text NOT NULL, file_path text NOT NULL, file_ext varchar(20) NOT NULL, ip_address varchar(45) DEFAULT NULL, uploaded_at datetime NOT NULL, PRIMARY KEY  (id), UNIQUE KEY legacy_id (legacy_id)"
		];
		foreach ( $schemas as $name => $schema ) { dbDelta( 'CREATE TABLE ' . self::table( $name ) . " (\n" . str_replace( ', ', ",\n", $schema ) . "\n) ENGINE=InnoDB $charset;" ); }
		foreach ( array_keys( $schemas ) as $name ) { if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( self::table( $name ) ) ) ) !== self::table( $name ) ) { return; } }
		update_option( 'kerp_tickets_schema', '2', FALSE );
	}
	public static function checked( $result ) { if ( $result === FALSE ) { throw new RuntimeException( 'ذخیره اطلاعات انجام نشد. دوباره تلاش کنید.' ); } return $result; }
	public static function get( int $id ): ?array { global $wpdb; return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table( 'tickets' ) . ' WHERE id=%d AND deleted_at IS NULL', $id ), ARRAY_A ) ?: NULL; }
	public static function message( int $id ): ?array { global $wpdb; return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table( 'messages' ) . ' WHERE id=%d', $id ), ARRAY_A ) ?: NULL; }
	public static function meta( string $kind, int $id, string $key, $default = '' ) {
		global $wpdb;
		$value = $wpdb->get_var( $wpdb->prepare( 'SELECT meta_value FROM ' . self::table( 'meta' ) . ' WHERE kind=%s AND object_id=%d AND meta_key=%s ORDER BY id LIMIT 1', $kind, $id, $key ) );
		return $value === NULL ? $default : maybe_unserialize( $value );
	}
	public static function put( string $kind, int $id, string $key, $value ): void {
		global $wpdb;
		self::checked( $wpdb->delete( self::table( 'meta' ), [ 'kind' => $kind, 'object_id' => $id, 'meta_key' => $key ] ) );
		self::checked( $wpdb->insert( self::table( 'meta' ), [ 'kind' => $kind, 'object_id' => $id, 'meta_key' => $key, 'meta_value' => maybe_serialize( $value ) ] ) );
	}
	public static function statuses(): array { return [ 'open' => 'باز', 'answered' => 'پاسخ داده شده', 'need_action' => 'درحال انجام', 'scheduled' => 'در پروسه', 'in-progress' => 'درحال رسیدگی', 'closed' => 'بسته' ]; }
	public static function priorities(): array { return [ 'low' => 'کم', 'normal' => 'معمولی', 'high' => 'زیاد', 'urgent' => 'فوری' ]; }
	public static function options( string $key ): array { return (array) get_option( 'kerp_tickets_' . $key, $key === 'departments' ? [ 'supp' => [ 'label' => 'پشتیبانی' ] ] : [] ); }
	public static function labels( string $key ): array { $out = []; foreach ( self::options( $key ) as $slug => $row ) { $out[$slug] = $row['label'] ?? $slug; } return $out; }
	public static function staff(): array {
        $options = KERP_Modules_Requests_Form::instance()->get_reviewer_options( -1 );
        foreach ( get_users( [ 'role' => 'employee', 'fields' => [ 'ID', 'display_name' ] ] ) as $user ) { $options[(int) $user->ID] = $user->display_name; }
        return $options;
    }
    public static function can_customer( int $id ): bool {
        if ( current_user_can( 'manage_options' ) || current_user_can( KERP_Admin::CAPABILITY ) ) { return (bool) get_userdata( $id ); }
        $result = KERP_Modules_Customers_Query::instance()->find( [ 'include' => [ $id ], 'per_page' => 1 ] );
        foreach ( $result['items'] as $user ) { if ( (int) $user->ID === $id ) { return TRUE; } }
        return FALSE;
    }
	public static function can_view( array $ticket, bool $public = FALSE ): bool {
		if ( ! get_current_user_id() ) { return FALSE; }
		if ( $public ) { return (int) $ticket['user_id'] === get_current_user_id(); }
		if ( ! kerp_can( 'tickets.view', 'view' ) || kerp_list_scope( 'tickets' ) === 'none' ) { return FALSE; }
		global $wpdb;
		return (bool) $wpdb->get_var( $wpdb->prepare( 'SELECT t.id FROM ' . self::table( 'tickets' ) . ' t WHERE t.id=%d AND ' . self::scope_sql(), $ticket['id'] ) );
	}
	private static function related_sql( int $id, string $type = '' ): string {
		global $wpdb;
		if ( $type === 'all' || $type === '0' ) { $type = ''; }
		$meta = self::table( 'meta' );
		$parts = [];
		if ( $type === '' || $type === 'user_id' ) { $parts[] = $wpdb->prepare( 't.user_id=%d', $id ); }
		foreach ( [ 'sender_id' => 'sender_id', 'responsible' => 'ticket_responsible_user' ] as $filter => $key ) {
			if ( $type === '' || $type === $filter ) { $parts[] = $wpdb->prepare( "EXISTS (SELECT 1 FROM $meta m WHERE m.kind='ticket' AND m.object_id=t.id AND m.meta_key=%s AND m.meta_value=%s)", $key, (string) $id ); }
		}
		if ( $type === '' || $type === 'reply_to' ) { $parts[] = $wpdb->prepare( "EXISTS (SELECT 1 FROM " . self::table( 'messages' ) . " msg JOIN $meta m ON m.kind='message' AND m.object_id=msg.id WHERE msg.ticket_id=t.id AND m.meta_key='attached_to_employee' AND m.meta_value=%s)", (string) $id ); }
		return '(' . implode( ' OR ', $parts ?: [ '0=1' ] ) . ')';
	}
	public static function scope_sql(): string {
		global $wpdb;
		if ( ! kerp_can( 'tickets.view', 'view' ) || kerp_list_scope( 'tickets' ) === 'none' ) { return '0=1'; }
		if ( kerp_list_scope( 'tickets' ) === 'all' ) { return '1=1'; }
		$parts = [ self::related_sql( get_current_user_id() ) ];
		$tags = array_filter( explode( ',', (string) get_user_meta( get_current_user_id(), 'assigned_tags', TRUE ) ) );
		foreach ( $tags as $tag ) { $parts[] = self::message_meta_sql( 'message_tag', $tag ); }
		return '(' . implode( ' OR ', $parts ) . ')';
	}
	private static function message_meta_sql( string $key, string $value ): string {
		global $wpdb;
		return $wpdb->prepare( "EXISTS (SELECT 1 FROM " . self::table( 'messages' ) . ' msg JOIN ' . self::table( 'meta' ) . " m ON m.kind='message' AND m.object_id=msg.id WHERE msg.ticket_id=t.id AND m.meta_key=%s AND m.meta_value=%s)", $key, $value );
	}
	public static function find( array $args, int $customer = 0, bool $public = FALSE ): array {
		global $wpdb;
		$where = [ 't.deleted_at IS NULL', $public ? $wpdb->prepare( 't.user_id=%d', get_current_user_id() ?: -1 ) : self::scope_sql() ];
		if ( $customer ) { $where[] = $wpdb->prepare( 't.user_id=%d', $customer ); }
		foreach ( [ 'status', 'priority' ] as $field ) { if ( ! empty( $args[$field] ) ) { $where[] = $wpdb->prepare( "t.$field=%s", $args[$field] ); } }
		if ( ! empty( $args['department'] ) ) { $where[] = $wpdb->prepare( 'EXISTS (SELECT 1 FROM ' . self::table( 'meta' ) . " m WHERE m.kind='ticket' AND m.object_id=t.id AND m.meta_key='department' AND m.meta_value=%s)", $args['department'] ); }
		if ( ! empty( $args['tag'] ) ) { $where[] = self::message_meta_sql( 'message_tag', $args['tag'] ); }
		if ( ! empty( $args['admin_id'] ) ) { $where[] = self::related_sql( absint( $args['admin_id'] ), sanitize_key( $args['admin_type'] ?? '' ) ); }
		if ( ! empty( $args['search'] ) ) { $like = '%' . $wpdb->esc_like( $args['search'] ) . '%'; $where[] = $wpdb->prepare( '(t.subject LIKE %s OR t.id=%d OR EXISTS (SELECT 1 FROM ' . self::table( 'messages' ) . ' msg WHERE msg.ticket_id=t.id AND msg.message LIKE %s))', $like, absint( $args['search'] ), $like ); }
		$sql = ' FROM ' . self::table( 'tickets' ) . ' t WHERE ' . implode( ' AND ', $where );
		$total = (int) $wpdb->get_var( 'SELECT COUNT(*)' . $sql );
		$per = max( 1, min( 100, absint( $args['per_page'] ?? 20 ) ) );
		$pages = max( 1, (int) ceil( $total / $per ) ); $page = min( $pages, max( 1, absint( $args['page_number'] ?? 1 ) ) );
		$pin = "EXISTS (SELECT 1 FROM " . self::table( 'meta' ) . " p WHERE p.kind='ticket' AND p.object_id=t.id AND p.meta_key='is_pinned' AND p.meta_value='yes')";
		$items = $wpdb->get_results( 'SELECT t.*' . $sql . " ORDER BY $pin DESC, COALESCE(t.last_message_at,t.created_at) DESC,t.id DESC LIMIT $per OFFSET " . ( ( $page - 1 ) * $per ), ARRAY_A );
		return compact( 'items', 'total', 'pages', 'page', 'per' );
	}
	public static function messages( int $id ): array { global $wpdb; return (array) $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . self::table( 'messages' ) . ' WHERE ticket_id=%d ORDER BY sent_at,id', $id ), ARRAY_A ); }
	/** Internal persistence primitives; callers own validation and the transaction. */
	public static function create_record( int $owner, string $subject, string $priority, string $department ): int {
		global $wpdb;
		self::checked( $wpdb->insert( self::table( 'tickets' ), [ 'user_id' => $owner, 'subject' => $subject, 'priority' => $priority, 'status' => 'open', 'created_at' => current_time( 'mysql' ) ] ) );
		$id = (int) $wpdb->insert_id;
		self::put( 'ticket', $id, 'sender_id', get_current_user_id() );
		$default = absint( self::options( 'departments' )[$department]['responsible'] ?? 0 );
		if ( $default && isset( self::staff()[$default] ) ) { self::put( 'ticket', $id, 'ticket_responsible_user', $default ); }
		return $id;
	}
	public static function append_message( int $id, string $content, array $attachments, int $parent = 0, bool $created = FALSE ): int {
		global $wpdb;
		$now = current_time( 'mysql' );
		self::checked( $wpdb->insert( self::table( 'messages' ), [ 'ticket_id' => $id, 'sender_id' => get_current_user_id(), 'reply_to' => $parent ?: NULL, 'message' => $content, 'sent_at' => $now ] ) );
		$mid = (int) $wpdb->insert_id;
		self::put( 'message', $mid, 'attachment', $attachments );
		$ticket = self::get( $id );
		$status = $created || (int) $ticket['user_id'] === get_current_user_id() ? 'open' : 'answered';
		self::checked( $wpdb->update( self::table( 'tickets' ), [ 'last_message_id' => $mid, 'last_message_at' => $now, 'status' => $status ], [ 'id' => $id ] ) );
		if ( (int) $ticket['user_id'] !== get_current_user_id() ) { self::put( 'ticket', $id, 'user_checked', 0 ); }
		return $mid;
	}
	public static function message_meta_values( int $ticket_id, string $key ): array {
		global $wpdb;
		$values = $wpdb->get_col( $wpdb->prepare( 'SELECT m.meta_value FROM ' . self::table( 'meta' ) . ' m INNER JOIN ' . self::table( 'messages' ) . " msg ON msg.id=m.object_id WHERE m.kind='message' AND msg.ticket_id=%d AND m.meta_key=%s ORDER BY msg.id,m.id", $ticket_id, $key ) );
		return array_map( 'maybe_unserialize', (array) $values );
	}
	public static function date( string $value ): string { return $value ? (string) KERP_Helpers_Date::local_datetime_to_jalali( $value ) : '—'; }
}
