<?php
defined( 'ABSPATH' ) || exit;

/** Server-side integrations. Call after the form's authentication and request validation. */
final class KERP_Modules_Tickets_Service {
	public static function create( array $data, bool $public = TRUE ): array { return self::save( $data, TRUE, $public ); }
	public static function reply( array $data, bool $public = FALSE ): array { return self::save( $data, FALSE, $public ); }

	private static function save( array $data, bool $create, bool $public ): array {
		global $wpdb;
		$store = KERP_Modules_Tickets_Store::class;
		$transaction = FALSE;
		try {
			if ( ! KERP_Modules::instance()->is_module_loaded( 'tickets' ) ) { throw new RuntimeException( 'ماژول تیکت فعال نیست.' ); }
			$actor = get_current_user_id();
			if ( ! $actor ) { throw new RuntimeException( 'برای ثبت درخواست وارد حساب شوید.' ); }
			if ( ! $public && ( ! kerp_can( 'tickets.view', 'view' ) || ! kerp_can( 'tickets.' . ( $create ? 'create' : 'reply' ), 'action' ) ) ) { throw new RuntimeException( 'دسترسی لازم را ندارید.' ); }
			if ( isset( $data['sender_id'] ) && absint( $data['sender_id'] ) !== $actor ) { throw new RuntimeException( 'فرستنده پیام معتبر نیست.' ); }
			$owner = absint( $data['user_id'] ?? $actor );
			$id = absint( $data['ticket_id'] ?? 0 );
			$meta = (array) ( $data['meta'] ?? [] );
			$msg_meta = $create ? (array) ( $data['msg_meta'] ?? [] ) : $meta;
			$content = wp_kses_post( $data['message'] ?? '' );
			if ( trim( wp_strip_all_tags( $content ) ) === '' && ! preg_match( '/<img\b[^>]*\bsrc\s*=/i', $content ) ) { throw new RuntimeException( 'متن پیام را وارد کنید.' ); }
			if ( $create ) {
				$subject = sanitize_text_field( $data['subject'] ?? '' );
				$priority = sanitize_key( $data['priority'] ?? 'normal' );
				$department = sanitize_key( $meta['department'] ?? '' );
				if ( ! $subject || ! isset( $store::priorities()[$priority], $store::labels( 'departments' )[$department] ) ) { throw new RuntimeException( 'عنوان، دپارتمان و اولویت معتبر را وارد کنید.' ); }
				if ( ! get_userdata( $owner ) || ( $public && $owner !== $actor ) || ( ! $public && $owner !== $actor && ! isset( $store::staff()[$owner] ) && ! $store::can_customer( $owner ) ) ) { throw new RuntimeException( 'به این مشتری دسترسی ندارید.' ); }
			}
			$attachments = (array) ( $msg_meta['attachment'] ?? [] );
			if ( count( $attachments ) > 50 ) { throw new RuntimeException( 'حداکثر ۵۰ پیوست مجاز است.' ); }
			foreach ( $attachments as &$url ) {
				if ( ! is_string( $url ) || ! preg_match( '#^https?://#i', $url ) || ! ( $url = esc_url_raw( $url ) ) ) { throw new RuntimeException( 'آدرس پیوست معتبر نیست.' ); }
			}
			unset( $url );
			$store::checked( $wpdb->query( 'START TRANSACTION' ) ); $transaction = TRUE;
			if ( $create ) {
				$id = $store::create_record( $owner, $subject, $priority, $department );
				self::save_meta( 'ticket', $id, $meta );
				$store::put( 'ticket', $id, 'department', $department );
				$store::put( 'ticket', $id, 'priority', $priority );
			} else {
				$wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . $store::table( 'tickets' ) . ' WHERE id=%d FOR UPDATE', $id ) );
				$ticket = $store::get( $id );
				if ( ! $ticket || ! $store::can_view( $ticket, $public ) ) { throw new RuntimeException( 'تیکت پیدا نشد یا دسترسی ندارید.' ); }
			}
			$mid = $store::append_message( $id, $content, array_values( $attachments ), 0, $create );
			self::save_meta( 'message', $mid, $msg_meta );
			$store::put( 'ticket', $id, 'last_actor', $actor );
			$store::checked( $wpdb->query( 'COMMIT' ) ); $transaction = FALSE;
		} catch ( Throwable $error ) {
			if ( $transaction ) { $wpdb->query( 'ROLLBACK' ); }
			return [ 'status' => 'error', 'message' => $error->getMessage(), 'data' => [] ];
		}
		$event = $create ? 'created' : 'replied';
		try { KERP_Modules_Tickets_Notifications::send( $event, $id, 0 ); }
		catch ( Throwable $error ) { do_action( 'kerp_ticket_notification_failed', $id, $event, $error ); }
		return [ 'status' => 'success', 'message' => 'درخواست ثبت شد.', 'data' => [ 'id' => $id, 'message_id' => $mid ] ];
	}

	private static function save_meta( string $kind, int $id, array $meta ): void {
		// Workflow state is owned by ERP, never by custom form metadata.
		$reserved = [ 'sender_id', 'department', 'priority', 'ticket_responsible_user', 'last_actor', 'user_checked', 'is_pinned', 'ticket_tags', 'attached_users', 'attachment', 'attached_to_employee', 'message_tag' ];
		foreach ( $meta as $key => $value ) {
			$key = sanitize_key( (string) $key );
			if ( $key !== '' && ! in_array( $key, $reserved, TRUE ) ) { KERP_Modules_Tickets_Store::put( $kind, $id, $key, $value ); }
		}
	}
}
