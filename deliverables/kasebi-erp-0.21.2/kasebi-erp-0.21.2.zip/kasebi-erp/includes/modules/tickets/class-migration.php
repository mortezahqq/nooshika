<?php
defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Tickets_Migration {
	public static function exists( string $name ): bool { global $wpdb; $table = $wpdb->prefix . 'kclms_' . $name; return $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $table ) ) ) === $table; }
	/** Each ticket and all its dependent rows commit together. Never overwrite an ERP record. */
	public static function run(): array {
		global $wpdb;
		$store = KERP_Modules_Tickets_Store::class;
		$lock = 'kerp_tickets_migration_' . get_current_blog_id();
		if ( ! $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s,0)', $lock ) ) ) { throw new RuntimeException( 'انتقال دیگری در حال اجراست؛ کمی بعد تلاش کنید.' ); }
		try {
			$source = $wpdb->prefix . 'kclms_';
			if ( self::exists( 'tickets' ) ) {
				foreach ( [ 'ticket_messages', 'tickets_meta', 'ticket_messages_meta' ] as $required ) { if ( ! self::exists( $required ) ) { throw new RuntimeException( 'جدول قدیمی ناقص است: ' . $required ); } }
				$rows = $wpdb->get_results( 'SELECT s.* FROM ' . $source . 'tickets s LEFT JOIN ' . $store::table( 'tickets' ) . ' d ON d.legacy_id=s.id WHERE d.id IS NULL ORDER BY s.id LIMIT 10', ARRAY_A );
				if ( $wpdb->last_error ) { throw new RuntimeException( 'خواندن تیکت‌های قدیمی ناموفق بود.' ); }
				foreach ( (array) $rows as $ticket ) {
					$store::checked( $wpdb->query( 'START TRANSACTION' ) );
					try {
						$old = (int) $ticket['id']; unset( $ticket['id'] ); $ticket['legacy_id'] = $old;
						$last = $ticket['last_message_id']; $ticket['last_message_id'] = NULL;
						$store::checked( $wpdb->insert( $store::table( 'tickets' ), $ticket ) ); $id = (int) $wpdb->insert_id;
						self::copy_meta( 'tickets_meta', 'ticket_id', $old, 'ticket', $id );
						$legacy_priority = $store::meta( 'ticket', $id, 'priority' );
						if ( isset( $store::priorities()[$legacy_priority] ) ) { $store::checked( $wpdb->update( $store::table( 'tickets' ), [ 'priority' => $legacy_priority ], [ 'id' => $id ] ) ); }
						$messages = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$source}ticket_messages WHERE ticket_id=%d ORDER BY id", $old ), ARRAY_A );
						if ( $wpdb->last_error ) { throw new RuntimeException( 'خواندن پیام‌های قدیمی ناموفق بود.' ); }
						$map = []; $parents = [];
						foreach ( (array) $messages as $message ) {
							$old_message = (int) $message['id']; unset( $message['id'] ); $parents[$old_message] = $message['reply_to'];
							$message['legacy_id'] = $old_message; $message['ticket_id'] = $id; $message['reply_to'] = NULL;
							$store::checked( $wpdb->insert( $store::table( 'messages' ), $message ) ); $new_message = (int) $wpdb->insert_id; $map[$old_message] = $new_message;
							self::copy_meta( 'ticket_messages_meta', 'ticket_message_id', $old_message, 'message', $new_message );
						}
						foreach ( $parents as $child => $parent ) { if ( $parent ) { $store::put( 'message', $map[$child], 'legacy_reply_to', $parent ); } if ( isset( $map[$parent] ) ) { $store::checked( $wpdb->update( $store::table( 'messages' ), [ 'reply_to' => $map[$parent] ], [ 'id' => $map[$child] ] ) ); } }
						$store::checked( $wpdb->update( $store::table( 'tickets' ), [ 'last_message_id' => $map[$last] ?? NULL ], [ 'id' => $id ] ) );
						$store::checked( $wpdb->query( 'COMMIT' ) );
					} catch ( Throwable $e ) { $wpdb->query( 'ROLLBACK' ); throw $e; }
				}
			}
			// Preserve upload names and paths; attachments keep their original URLs and files are never moved.
			if ( self::exists( 'uploaded_files' ) ) {
				$files = $wpdb->get_results( 'SELECT s.* FROM ' . $source . 'uploaded_files s LEFT JOIN ' . $store::table( 'files' ) . ' d ON d.legacy_id=s.id WHERE d.id IS NULL ORDER BY s.id LIMIT 200', ARRAY_A );
				if ( $wpdb->last_error ) { throw new RuntimeException( 'خواندن پیوست‌های قدیمی ناموفق بود.' ); }
				foreach ( (array) $files as $file ) { $file['legacy_id'] = $file['id']; unset( $file['id'] ); $store::checked( $wpdb->insert( $store::table( 'files' ), $file ) ); }
			}
			foreach ( [ 'departments', 'tags' ] as $key ) {
				if ( get_option( 'kerp_tickets_imported_' . $key ) ) { continue; }
				$legacy = (array) get_option( 'kclms_ticket_' . $key, [] ); add_option( 'kerp_tickets_legacy_' . $key, $legacy, '', FALSE );
				$existing = (array) get_option( 'kerp_tickets_' . $key, [] ); update_option( 'kerp_tickets_' . $key, array_replace( $legacy, $existing ), FALSE );
				update_option( 'kerp_tickets_imported_' . $key, 1, FALSE );
			}
			// Personal replies, employee tag access and notification preferences remain on the same WP users.
			if ( ! get_option( 'kerp_tickets_legacy_sms_imported' ) ) { KERP_Modules_Tickets_Notifications::import_rules(); update_option( 'kerp_tickets_legacy_sms_imported', 1, FALSE ); }
			$remaining = self::exists( 'tickets' ) ? (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . $source . 'tickets s LEFT JOIN ' . $store::table( 'tickets' ) . ' d ON d.legacy_id=s.id WHERE d.id IS NULL' ) : 0;
			$remaining += self::exists( 'uploaded_files' ) ? (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . $source . 'uploaded_files s LEFT JOIN ' . $store::table( 'files' ) . ' d ON d.legacy_id=s.id WHERE d.id IS NULL' ) : 0;
			if ( ! $remaining ) { update_option( 'kerp_tickets_migrated_at', current_time( 'mysql' ), FALSE ); }
			return [ 'remaining' => $remaining, 'done' => $remaining === 0 ];
		} finally { $wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $lock ) ); }
	}
	private static function copy_meta( string $table, string $foreign, int $old, string $kind, int $id ): void {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT meta_key,meta_value FROM {$wpdb->prefix}kclms_{$table} WHERE {$foreign}=%d ORDER BY id", $old ), ARRAY_A );
		if ( $wpdb->last_error ) { throw new RuntimeException( 'خواندن اطلاعات جانبی ناموفق بود.' ); }
		foreach ( (array) $rows as $row ) { KERP_Modules_Tickets_Store::checked( $wpdb->insert( KERP_Modules_Tickets_Store::table( 'meta' ), [ 'kind' => $kind, 'object_id' => $id, 'meta_key' => $row['meta_key'], 'meta_value' => $row['meta_value'] ] ) ); }
	}
}
