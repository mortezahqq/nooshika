<?php
defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Tickets_Api {
	private static ?self $instance = NULL;
	public static function instance(): self { return self::$instance ??= new self(); }
	private function __construct() {
		add_action( 'kasebi_ajax_tickets_save', [ $this, 'handle' ] );
		add_action( 'nooshika_ajax_kerp_tickets_save', [ $this, 'public_handle' ] );
	}
	public function public_handle(): void { $this->handle( TRUE ); }
	private function require_permission( string $key ): void { if ( ! kerp_can( 'tickets.' . $key, in_array( $key, [ 'view', 'list' ], TRUE ) ? 'view' : 'action' ) ) { throw new RuntimeException( 'دسترسی لازم را ندارید.' ); } }
	public function handle( bool $public = FALSE ): void {
		global $wpdb;
		$store = KERP_Modules_Tickets_Store::class; $transaction = FALSE;
		try {
			if ( ! is_user_logged_in() ) { throw new RuntimeException( 'برای ادامه، وارد حساب خود شوید.' ); }
			if ( ! wp_verify_nonce( $_POST['tickets_nonce'] ?? '', 'kerp_tickets' ) ) {
				wp_send_json( [ 'status' => 'error', 'code' => 'ticket_nonce_expired', 'tickets_nonce' => wp_create_nonce( 'kerp_tickets' ), 'message' => 'ارسال درخواست انجام نشد؛ دوباره تلاش کنید.' ] );
			}
			$data = wp_unslash( $_POST ); $op = sanitize_key( $data['operation'] ?? '' ); $id = absint( $data['ticket_id'] ?? 0 );
			if ( $public && ! in_array( $op, [ 'create', 'reply', 'status', 'rate', 'upload' ], TRUE ) ) { throw new RuntimeException( 'عملیات مجاز نیست.' ); }
			if ( ! $public ) { $this->require_permission( 'view' ); }
			if ( $op === 'upload' ) {
				if ( ! $public ) { $this->require_permission( $id ? 'reply' : 'create' ); }
				if ( $id && ( ! $store::get( $id ) || ! $store::can_view( $store::get( $id ), $public ) ) ) { throw new RuntimeException( 'به این تیکت دسترسی ندارید.' ); }
				if ( empty( $_FILES['file'] ) ) { throw new RuntimeException( 'فایل ارسال نشده است.' ); }
				$ctx = [];
				if ( isset( $data['dzchunkindex'] ) ) {
					$ctx = [ 'dzuuid' => get_current_user_id() . '-' . sanitize_key( $data['dzuuid'] ?? '' ), 'dzchunkindex' => (int) $data['dzchunkindex'], 'dztotalchunkcount' => absint( $data['dztotalchunkcount'] ?? 0 ), 'dztotalfilesize' => absint( $data['dztotalfilesize'] ?? 0 ) ];
				}
				$result = KERP_Helpers_File::instance()->handle_upload_file( $_FILES['file'], 'kerp-tickets/' . get_current_user_id(), $ctx );
				if ( ! $result['ok'] ) { throw new RuntimeException( $result['msg'] ); }
				$token = '';
				if ( $result['url'] ) {
					$store::checked( $wpdb->insert( $store::table( 'files' ), [ 'user_id' => get_current_user_id(), 'original_name' => sanitize_file_name( $_FILES['file']['name'] ), 'saved_name' => $result['name'], 'file_url' => $result['url'], 'file_path' => '', 'file_ext' => pathinfo( $result['name'], PATHINFO_EXTENSION ), 'uploaded_at' => current_time( 'mysql' ) ] ) );
					$token = wp_generate_uuid4(); set_transient( 'kerp_ticket_file_' . $token, [ 'user' => get_current_user_id(), 'ticket' => $id, 'url' => $result['url'] ], DAY_IN_SECONDS );
				}
				wp_send_json( [ 'status' => 'success', 'token' => $token, 'url' => $result['url'] ?? '' ] );
			}
			if ( $op === 'migrate' ) { $this->require_permission( 'manage_settings' ); $result = KERP_Modules_Tickets_Migration::run(); wp_send_json( array_merge( [ 'status' => 'success', 'message' => $result['done'] ? 'انتقال اطلاعات کامل شد.' : 'بخش بعدی در حال انتقال است.' ], $result ) ); }
			if ( in_array( $op, [ 'settings', 'taxonomy', 'ready', 'access' ], TRUE ) ) {
				$this->require_permission( $op === 'ready' ? 'reply' : 'manage_settings' ); $this->settings( $op, $data );
				if ( $op === 'ready' && ! empty( $data['inline_ready'] ) ) { wp_send_json( [ 'status' => 'success', 'message' => 'پاسخ آماده ذخیره شد.', 'ready_rows' => KERP_Modules_Tickets_Store::ready_replies() ] ); }
				$this->respond( 'تنظیمات ذخیره شد.', $public, 0 );
			}
			$ticket = $id ? $store::get( $id ) : NULL;
			if ( $op !== 'create' && $op !== 'bulk' && ( ! $ticket || ! $store::can_view( $ticket, $public ) ) ) { throw new RuntimeException( 'تیکت پیدا نشد یا دسترسی ندارید.' ); }
			$permission = [ 'create' => 'create', 'reply' => 'reply', 'edit' => 'edit', 'tag' => 'edit', 'assign' => 'assign', 'refer' => 'assign', 'status' => 'status', 'bulk' => 'status', 'delete' => 'delete', 'delete_message' => 'delete', 'rate' => 'reply' ];
			if ( ! isset( $permission[$op] ) ) { throw new RuntimeException( 'عملیات نامعتبر است.' ); }
			if ( ! $public ) { $this->require_permission( $permission[$op] ); }
			$message_id = absint( $data['message_id'] ?? 0 ); $message = $message_id ? $store::message( $message_id ) : NULL;
			if ( in_array( $op, [ 'tag', 'refer', 'rate', 'delete_message' ], TRUE ) && ( ! $message || (int) $message['ticket_id'] !== $id ) ) { throw new RuntimeException( 'پیام متعلق به این تیکت نیست.' ); }
			$store::checked( $wpdb->query( 'START TRANSACTION' ) ); $transaction = TRUE;
			if ( $id ) { $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . $store::table( 'tickets' ) . ' WHERE id=%d FOR UPDATE', $id ) ); }
			$event = ''; $event_user = 0;
			if ( $op === 'create' || $op === 'edit' ) {
				$subject = sanitize_text_field( $data['subject'] ?? '' ); $priority = sanitize_key( $data['priority'] ?? 'normal' ); $department = sanitize_key( $data['department'] ?? '' );
				if ( $subject === '' || ! isset( $store::priorities()[$priority] ) || ! isset( $store::labels( 'departments' )[$department] ) ) { throw new RuntimeException( 'عنوان، دپارتمان و اولویت معتبر را وارد کنید.' ); }
				if ( $op === 'create' ) {
					$owner = $public ? get_current_user_id() : absint( $data['customer_id'] ?? 0 );
					if ( ! $public && ! empty( $data['staff_owner'] ) ) { $owner = absint( $data['staff_owner'] ); if ( ! isset( $store::staff()[$owner] ) ) { throw new RuntimeException( 'کارشناس معتبر را انتخاب کنید.' ); } }
					if ( ! get_userdata( $owner ) ) { throw new RuntimeException( 'کاربر معتبر را انتخاب کنید.' ); }
					if ( ! $public && $owner !== get_current_user_id() && ! isset( $store::staff()[$owner] ) && ! $store::can_customer( $owner ) ) { throw new RuntimeException( 'دسترسی به این مشتری ندارید.' ); }
					$id = $store::create_record( $owner, $subject, $priority, $department );
					$event = 'created';
				} else { $store::checked( $wpdb->update( $store::table( 'tickets' ), compact( 'subject', 'priority' ), [ 'id' => $id ] ) ); }
				$store::put( 'ticket', $id, 'department', $department );
				$store::put( 'ticket', $id, 'priority', $priority );
			}
            if ( $op === 'edit' && array_key_exists( 'employee_id', $data ) ) {
                $this->require_permission( 'assign' );
                $employee = absint( $data['employee_id'] );
                if ( $employee && ! isset( $store::staff()[$employee] ) ) { throw new RuntimeException( 'کارشناس معتبر را انتخاب کنید.' ); }
                if ( $employee !== (int) $store::meta( 'ticket', $id, 'ticket_responsible_user' ) ) {
                    $store::put( 'ticket', $id, 'ticket_responsible_user', $employee );
                    $event = 'assigned'; $event_user = $employee;
                }
            }
			if ( $op === 'create' || $op === 'reply' ) {
				$content = wp_kses_post( $data['content'] ?? '' );
				if ( trim( wp_strip_all_tags( $content ) ) === '' && ! preg_match( '/<img\b[^>]*\bsrc\s*=/i', $content ) ) { throw new RuntimeException( 'متن پیام را وارد کنید.' ); }
				$parent = absint( $data['reply_to'] ?? 0 ); $parent_message = $parent ? $store::message( $parent ) : NULL;
				if ( $parent && ( ! $parent_message || (int) $parent_message['ticket_id'] !== $id ) ) { throw new RuntimeException( 'پیام مرجع نامعتبر است.' ); }
				$attachments = [];
				$tokens = (array) ( $data['file_tokens'] ?? [] ); if ( count( $tokens ) > 50 ) { throw new RuntimeException( 'حداکثر ۵۰ فایل مجاز است.' ); }
				foreach ( $tokens as $token ) {
					$upload = get_transient( 'kerp_ticket_file_' . sanitize_key( $token ) );
					if ( ! is_array( $upload ) || $upload['user'] !== get_current_user_id() || ( (int) $upload['ticket'] !== ( $op === 'create' ? 0 : $id ) ) ) { throw new RuntimeException( 'اعتبار پیوست تمام شده؛ آن را دوباره انتخاب کنید.' ); }
					$attachments[] = $upload['url'];
				}
				if ( ! empty( $_FILES['ticket_files']['name'] ) ) {
					$files = $_FILES['ticket_files']; if ( ! is_array( $files['name'] ) || count( $files['name'] ) > 50 ) { throw new RuntimeException( 'حداکثر ۵۰ فایل مجاز است.' ); }
					foreach ( $files['name'] as $index => $name ) {
						if ( $files['error'][$index] === UPLOAD_ERR_NO_FILE ) { continue; }
						$file = []; foreach ( [ 'name', 'type', 'tmp_name', 'error', 'size' ] as $key ) { $file[$key] = $files[$key][$index]; }
						$uploaded = KERP_Helpers_File::instance()->handle_upload_file( $file, 'kerp-tickets/' . $id );
						if ( ! $uploaded['ok'] ) { throw new RuntimeException( $uploaded['msg'] ); } $attachments[] = $uploaded['url'];
					}
				}
				$mid = $store::append_message( $id, $content, $attachments, $parent, $op === 'create' );
				$ticket = $store::get( $id );
				if ( $op === 'reply' ) { $event = 'replied'; }
			}
			if ( $op === 'status' || $op === 'bulk' ) {
				$status = sanitize_key( $data['status'] ?? '' );
				if ( ! isset( $store::statuses()[$status] ) || ( $public && $status !== 'closed' ) ) { throw new RuntimeException( 'وضعیت نامعتبر است.' ); }
				$ids = $op === 'bulk' ? array_unique( array_map( 'absint', (array) ( $data['ids'] ?? [] ) ) ) : [ $id ];
				if ( ! $ids || count( $ids ) > 100 ) { throw new RuntimeException( 'تیکت‌ها را انتخاب کنید (حداکثر ۱۰۰ مورد).' ); }
				foreach ( $ids as $target ) { $row = $store::get( $target ); if ( ! $row || ! $store::can_view( $row, $public ) ) { throw new RuntimeException( 'به یکی از تیکت‌ها دسترسی ندارید.' ); } }
				foreach ( $ids as $target ) { $store::checked( $wpdb->update( $store::table( 'tickets' ), [ 'status' => $status ], [ 'id' => $target ] ) ); }
				$event = 'status_changed';
			}
			if ( $op === 'assign' || $op === 'refer' ) {
				$employee = absint( $data['employee_id'] ?? 0 ); if ( $employee && ! isset( $store::staff()[$employee] ) ) { throw new RuntimeException( 'کارشناس معتبر را انتخاب کنید.' ); }
				$store::put( $op === 'assign' ? 'ticket' : 'message', $op === 'assign' ? $id : $message_id, $op === 'assign' ? 'ticket_responsible_user' : 'attached_to_employee', $employee );
				$event = $op === 'assign' ? 'assigned' : 'referred'; $event_user = $employee;
			}
			if ( $op === 'tag' ) { $tag = sanitize_key( $data['tag'] ?? '' ); if ( $tag && ! isset( $store::labels( 'tags' )[$tag] ) ) { throw new RuntimeException( 'تگ نامعتبر است.' ); } $store::put( 'message', $message_id, 'message_tag', $tag ); }
			if ( $op === 'rate' ) {
				$rate = absint( $data['rate'] ?? 0 ); $key = 'user_rate_' . get_current_user_id();
				if ( $rate < 1 || $rate > 5 || (int) $message['sender_id'] === get_current_user_id() || $store::meta( 'message', $message_id, $key ) ) { throw new RuntimeException( 'امتیاز باید بین ۱ تا ۵ باشد و برای پاسخ دیگران فقط یک‌بار ثبت شود.' ); }
				$store::put( 'message', $message_id, $key, $rate ); $store::put( 'message', $message_id, 'last_user_rate', $rate );
			}
			if ( $op === 'delete_message' || $op === 'delete' ) {
				$messages = $op === 'delete' ? $store::messages( $id ) : [ $message ];
				foreach ( $messages as $row ) { $store::checked( $wpdb->delete( $store::table( 'meta' ), [ 'kind' => 'message', 'object_id' => $row['id'] ] ) ); $store::checked( $wpdb->delete( $store::table( 'messages' ), [ 'id' => $row['id'] ] ) ); $store::checked( $wpdb->update( $store::table( 'messages' ), [ 'reply_to' => NULL ], [ 'reply_to' => $row['id'] ] ) ); }
				if ( $op === 'delete' ) { $store::checked( $wpdb->delete( $store::table( 'meta' ), [ 'kind' => 'ticket', 'object_id' => $id ] ) ); $store::checked( $wpdb->update( $store::table( 'tickets' ), [ 'deleted_at' => current_time( 'mysql' ) ], [ 'id' => $id ] ) ); $id = 0; }
				else { $remaining = $store::messages( $id ); $last = end( $remaining ); $store::checked( $wpdb->update( $store::table( 'tickets' ), [ 'last_message_id' => $last['id'] ?? NULL, 'last_message_at' => $last['sent_at'] ?? NULL ], [ 'id' => $id ] ) ); }
			}
			if ( $id ) {
				$store::put( 'ticket', $id, 'last_actor', get_current_user_id() );
				if ( in_array( $op, [ 'tag', 'refer', 'delete_message' ], TRUE ) ) {
					$tags = []; $assigned = [];
					foreach ( $store::messages( $id ) as $msg ) { $tags[] = $store::meta( 'message', (int) $msg['id'], 'message_tag' ); $assigned[] = $store::meta( 'message', (int) $msg['id'], 'attached_to_employee' ); }
					$store::put( 'ticket', $id, 'ticket_tags', array_values( array_unique( array_filter( $tags ) ) ) );
					$store::put( 'ticket', $id, 'attached_users', array_values( array_unique( array_filter( $assigned ) ) ) );
				}
			}
			// Addons validate and persist extra record fields inside the same transaction.
			if ( $id && in_array( $op, [ 'create', 'edit' ], TRUE ) ) { do_action( 'kerp_ticket_record_saved', $id, $data, $op, $public ); }
			$store::checked( $wpdb->query( 'COMMIT' ) ); $transaction = FALSE;
			if ( $event ) { foreach ( $op === 'bulk' ? $ids : [ $id ] as $notify_id ) { try { KERP_Modules_Tickets_Notifications::send( $event, $notify_id, $event_user ); } catch ( Throwable $notification_error ) { do_action( 'kerp_ticket_notification_failed', $notify_id, $event, $notification_error ); } } }
			$this->respond( 'اطلاعات ذخیره شد.', $public, $id, (int) ( $ticket['user_id'] ?? 0 ) );
		} catch ( Throwable $e ) { if ( $transaction ) { $wpdb->query( 'ROLLBACK' ); } wp_send_json( [ 'status' => 'error', 'message' => $e->getMessage() ] ); }
	}
	private function settings( string $op, array $data ): void {
		$store = KERP_Modules_Tickets_Store::class;
		if ( $op === 'access' ) {
			$employee = absint( $data['employee_id'] ?? 0 ); if ( ! isset( $store::staff()[$employee] ) ) { throw new RuntimeException( 'کارشناس را انتخاب کنید.' ); }
			$tags = array_values( array_intersect( array_map( 'sanitize_key', (array) ( $data['tags'] ?? [] ) ), array_keys( $store::labels( 'tags' ) ) ) );
			update_user_meta( $employee, 'assigned_tags', $tags ? ',' . implode( ',', $tags ) . ',' : '' ); return;
		}
		if ( $op === 'settings' ) {
            $numbers = KERP_Helpers_Format::sanitize_numbers( (string) ( $data['general_manager_numbers'] ?? '' ) );
            $numbers = preg_split( '/[\s,،;]+/u', trim( $numbers ), -1, PREG_SPLIT_NO_EMPTY );
            foreach ( $numbers as $number ) { if ( ! preg_match( '/^\+?[0-9]{10,15}$/', $number ) ) { throw new RuntimeException( 'شماره مدیران عمومی معتبر نیست.' ); } }
            KERP_Modules_Tickets_Notifications::save_rules( (array) ( $data['sms_rules'] ?? [] ) );
            if ( array_key_exists( 'general_manager_numbers', $data ) ) { update_option( 'sms_general_manager_numbers', implode( ',', array_unique( $numbers ) ) ); }
            return;
        }
		if ( $op === 'ready' ) {
			$rows = KERP_Modules_Tickets_Store::ready_replies(); $index = (string) ( $data['index'] ?? '' );
			if ( $index !== '' && ! isset( $rows[absint( $index )] ) ) { throw new RuntimeException( 'پاسخ آماده پیدا نشد.' ); }
			if ( ! empty( $data['remove'] ) ) { unset( $rows[absint( $index )] ); }
			else { $row = [ 'label' => sanitize_text_field( $data['label'] ?? '' ), 'content' => wp_kses_post( $data['content'] ?? '' ), 'department' => sanitize_key( $data['department'] ?? '' ) ]; if ( ! $row['label'] || ! $row['content'] ) { throw new RuntimeException( 'عنوان و متن پاسخ را وارد کنید.' ); } if ( $index === '' ) { $rows[] = $row; } else { $rows[absint( $index )] = $row; } }
			update_user_meta( get_current_user_id(), 'ticket_ready_template', array_values( $rows ) ); return;
		}
		$key = sanitize_key( $data['kind'] ?? '' ); if ( ! in_array( $key, [ 'departments', 'tags' ], TRUE ) ) { throw new RuntimeException( 'نوع تنظیم نامعتبر است.' ); }
		$slug = sanitize_key( $data['slug'] ?? '' ); $label = sanitize_text_field( $data['label'] ?? '' ); if ( ! $slug || ! $label ) { throw new RuntimeException( 'عنوان و نامک الزامی است.' ); }
		$rows = $store::options( $key );
		if ( ! empty( $data['remove'] ) ) {
			global $wpdb; $meta_key = $key === 'departments' ? 'department' : 'message_tag';
			if ( $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . $store::table( 'meta' ) . ' WHERE meta_key=%s AND meta_value=%s LIMIT 1', $meta_key, $slug ) ) ) { throw new RuntimeException( 'این مورد استفاده شده است؛ عنوان آن را ویرایش کنید.' ); } unset( $rows[$slug] );
		} else { $employee = absint( $data['employee_id'] ?? 0 ); if ( $employee && ! isset( $store::staff()[$employee] ) ) { throw new RuntimeException( 'کارشناس معتبر نیست.' ); } $rows[$slug] = array_replace( (array) ( $rows[$slug] ?? [] ), [ 'label' => $label, 'responsible' => $employee ] ); }
		update_option( 'kerp_tickets_' . $key, $rows, FALSE );
	}
	private function respond( string $message, bool $public, int $id, int $customer = 0 ): void {
		$ticket = $id ? KERP_Modules_Tickets_Store::get( $id ) : NULL;
		$url = $public ? home_url( '/panel/tickets/' . ( $id ? 'support/' . $id . '/' : '' ) ) : home_url( $ticket ? '/erp/customers/' . (int) $ticket['user_id'] . '/?tab=tickets&ticket_id=' . $id : ( $customer ? '/erp/customers/' . $customer . '/?tab=tickets' : '/erp/tickets/' ) );
		if ( ! $public && ! $id ) { $candidate = sanitize_text_field( wp_unslash( $_POST['return_page'] ?? '' ) ); if ( preg_match( '~^/erp/tickets/settings/(departments|sms|replies)/$~', $candidate ) ) { $url = home_url( $candidate ); } }
		$response = [ 'status' => 'success', 'message' => $message, 'url' => $url ];
		if ( ! $public ) { $response = array_merge( $response, KERP_Api_Page_Content::build_page_response( $url, [], TRUE ) ); }
        else {
            $args = [ 'user_id' => get_current_user_id(), 'current' => 'tickets', 'id' => $id ];
            $response['content'] = KERP_Helpers_Template::get_template( 'modules/tickets/pages/' . ( $id ? 'chat' : 'list' ) . '.php', [ 'tickets_public' => TRUE, 'ticket_public_id' => $id ] );
            $response['nav'] = nooshika_panel_get_template( 'main/nav', $args );
            $response['title'] = nooshika_panel_get_page_title( $id ? [ 'tickets', 'support', $id ] : [ 'tickets' ] );
            $response['msg'] = $message;
        }
		wp_send_json( $response );
	}
}
