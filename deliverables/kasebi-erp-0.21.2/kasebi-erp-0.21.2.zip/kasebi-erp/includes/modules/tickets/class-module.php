<?php
defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Tickets_Module {
	private static ?self $instance = NULL;
	public static function instance(): self { return self::$instance ??= new self(); }
	private function __construct() {
		KERP_Modules_Tickets_Store::install();
		KERP_Modules_Tickets_Api::instance();
		KERP_Modules_Tickets_Panel::instance();
		add_filter( 'kerp_app_pages', [ $this, 'pages' ] );
		add_filter( 'kerp_employee_permission_groups', [ $this, 'permissions' ] );
		add_filter( 'kerp_customer_profile_tabs', [ $this, 'customer_tab' ], 50, 3 );
		add_filter( 'kerp_customers_profile_dropdown_actions', [ $this, 'customer_action' ], 50, 3 );
		add_action( 'kerp_customer_profile_modals', [ $this, 'customer_modal' ], 50, 4 );
		// Core clears unrelated assets first at this priority; modules are registered afterwards.
		add_action( 'wp_enqueue_scripts', [ $this, 'assets' ], PHP_INT_MAX );
		add_filter( 'kerp_admin_bar_items', static function( array $items ): array { $items['ticket_system'] = [ 'title' => 'تیکت‌ها', 'url' => '/erp/tickets/' ]; return $items; }, 99 );
	}
	public function pages( array $pages ): array {
		$group = [ 'key' => 'crm', 'title' => sprintf( __( 'مدیریت %s', 'kasebi-erp' ), KERP_Modules_Customers_Settings::instance()->get_plural_label() ), 'icon' => 'kik fa-users-02', 'order' => 20 ];
		$settings_group = [ 'key' => 'settings', 'title' => __( 'تنظیمات', 'kasebi-erp' ), 'icon' => 'kik fa-settings-02', 'order' => 100, 'sep_before' => TRUE ];
		$settings_menu = [ 'key' => 'tickets-settings', 'title' => 'تنظیمات تیکت‌ها', 'icon' => 'ni ni-chat-circle', 'order' => 46 ];
		$pages['tickets'] = [ 'title' => 'همه تیکت‌ها', 'route' => 'tickets', 'type' => 'page', 'template' => 'modules/tickets/pages/list.php', 'permission' => 'tickets.view', 'navigation' => [ 'group' => $group, 'icon' => 'ni ni-inbox', 'order' => 46 ] ];
		foreach ( [ 'departments' => 'دپارتمان و تگ', 'sms' => 'پیامک', 'replies' => 'پاسخ آماده' ] as $key => $title ) {
			$pages['tickets-settings-' . $key] = [ 'title' => $title, 'route' => 'tickets/settings/' . $key, 'type' => 'settings', 'template' => 'modules/tickets/settings/' . $key . '.php', 'permission' => $key === 'replies' ? 'tickets.reply' : 'tickets.manage_settings', 'navigation' => [ 'group' => $settings_group, 'menu' => $settings_menu, 'title' => $title, 'order' => array_search( $key, [ 'departments', 'sms', 'replies' ], TRUE ) * 10 + 10 ] ];
		}
		return $pages;
	}
	public function customer_tab( array $tabs, int $id, WP_User $customer ): array {
		if ( kerp_can( 'tickets.view', 'view' ) ) { $tabs['tickets'] = [ 'key' => 'tickets', 'title' => 'تیکت‌ها', 'icon' => 'ni ni-chat-circle', 'order' => 75, 'group' => 'crm', 'permission' => 'tickets.view', 'action' => 'view', 'template' => 'modules/tickets/tabs/customer.php' ]; }
		return $tabs;
	}
	public function customer_action( array $actions, WP_User $customer, array $profile_context ): array {
		if ( ! kerp_can( 'tickets.view', 'view' ) || ! kerp_can( 'tickets.create', 'action' ) ) { return $actions; }
		$actions['add_customer_ticket'] = [
			'label' => 'ثبت تیکت', 'icon' => 'ni ni-chat-circle', 'href' => '#kerp-ticket-record', 'order' => 45,
			'attributes' => [ 'data-bs-toggle' => 'modal', 'data-bs-target' => '#kerp-ticket-record' ],
		];
		return $actions;
	}
	public function customer_modal( int $customer_id, WP_User $customer, array $profile_context, string $active_tab ): void {
		// The tickets tab already renders this same shared modal.
		if ( $active_tab === 'tickets' || ! kerp_can( 'tickets.view', 'view' ) || ! kerp_can( 'tickets.create', 'action' ) ) { return; }
		echo '<div class="kerp-tickets">';
		KERP_Modules_Tickets_View::record_modal( $customer_id );
		echo '</div>';
	}
	public function permissions( array $groups ): array {
		$permissions = [];
		foreach ( [ 'view' => 'مشاهده بخش تیکت', 'list' => 'فهرست تیکت‌ها', 'create' => 'ثبت تیکت', 'reply' => 'پاسخ و پاسخ آماده شخصی', 'edit' => 'ویرایش مشخصات و تگ و سنجاق', 'assign' => 'واگذاری و ارجاع پیام', 'status' => 'تغییر وضعیت', 'delete' => 'حذف تیکت و پیام', 'manage_settings' => 'تنظیمات و انتقال اطلاعات' ] as $key => $label ) {
			$permissions[$key] = [ 'key' => 'tickets.' . $key, 'label' => $label, 'type' => in_array( $key, [ 'view', 'list' ], TRUE ) ? 'view' : 'action' ];
		}
		$permissions['list']['scope'] = [ 'options' => [ 'own' => 'مرتبط با من و تگ‌های مجاز من', 'all' => 'همه تیکت‌ها' ], 'default' => 'own' ];
		$groups['tickets'] = [ 'key' => 'tickets', 'label' => 'تیکت‌ها', 'icon' => 'ni ni-chat-circle', 'order' => 46, 'blocks' => [ 'tickets' => [ 'key' => 'tickets', 'label' => 'پشتیبانی', 'permissions' => $permissions ] ] ];
		return $groups;
	}
	public function assets(): void {
        if ( kerp_is_erp_request() || is_page( 'panel' ) ) {
            $uploader_url = plugins_url( 'nooshika-panel/assets/plugins/quill/' );
            wp_enqueue_style( 'nooshika_quill_image_uploader_styles', $uploader_url . 'quill.imageUploader.min.css' );
            if ( kerp_is_erp_request() ) {
                wp_enqueue_script( 'kerp-ticket-image-uploader', $uploader_url . 'quill.imageUploader.min.js', [ 'kerp-quill' ], FALSE, TRUE );
                $scripts = wp_scripts();
                if ( isset( $scripts->registered['kerp-app'] ) ) { $scripts->registered['kerp-app']->deps[] = 'kerp-ticket-image-uploader'; }
            }
        }
		if ( kerp_is_erp_request() || is_page( 'panel' ) ) { wp_enqueue_style( 'kerp-tickets', KERP_ASSETS_URL . 'public/css/tickets.css', [], kerp_asset_version( 'public/css/tickets.css' ) ); }
	}
}
