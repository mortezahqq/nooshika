<?php
defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Tickets_Panel {
	private static ?self $instance = NULL;
	public static function instance(): self { return self::$instance ??= new self(); }
	private function __construct() {
		add_filter( 'kerp_panel_navigation_pages', [ $this, 'register_panel_navigation_settings' ] );
		add_filter( 'nooshika_panel_pages_list_final', [ $this, 'pages' ], 99 );
		add_filter( 'nooshika_panel_get_template_path', [ $this, 'template' ], 99, 2 );
		add_action( 'wp_enqueue_scripts', [ $this, 'assets' ], 300 );
		add_action( 'template_redirect', [ $this, 'redirect' ], -100 );
		// ERP modules themselves load during init; an earlier init callback would never run here.
		$this->retire_manager();
		// Freeze the retired interface, including already-open browser tabs, before a migration can start.
		foreach ( [ 'kclms_request_page_content', 'kclms_request_back_btn', 'kclms_add_user_ticket', 'kclms_add_ticket_answer', 'kclms_change_ticket_status', 'kclms_change_ticket_status_bulk', 'kclms_save_ticket_settings', 'kclms_delete_ticket', 'kclms_delete_ticket_massage', 'kclms_set_msg_tag', 'kclms_remove_msg_tag', 'kclms_reply_msg_to_employee', 'kclms_set_rating_for_msg', 'kclms_set_ticket_pin', 'kclms_add_template_item', 'kclms_delete_template_item', 'send_new_ticket', 'send_ticket_msg', 'nooshika_panel_add_user_ticket', 'panel_mark_ticket_as_closed', 'panel_add_ticket_answer', 'admin_delete_ticket_item' ] as $action ) {
			add_action( 'nooshika_ajax_' . $action, [ $this, 'retired' ], -999 );
		}
		foreach ( [ 'kclms_update_employee_data', 'kclms_update_inline_meta', 'kclms_save_site_settings', 'kclms_add_option_item', 'kclms_delete_option_item' ] as $action ) { add_action( 'nooshika_ajax_' . $action, [ $this, 'retired' ], -999 ); }
	}
	public function retired(): void { wp_send_json( [ 'status' => 'error', 'message' => 'مدیریت تیکت‌ها به ERP منتقل شده است. صفحه را تازه کنید.', 'redirect' => home_url( kerp_can( 'tickets.view', 'view' ) ? '/erp/tickets/' : '/panel/tickets/' ) ] ); }
	public function retire_manager(): void {
		remove_action( 'init', 'nooshika_panel_maybe_sync_manager_page', 20 );
		remove_shortcode( 'kasebi-panel-manager' );
		add_shortcode( 'kasebi-panel-manager', function(): string { return '<a href="' . esc_url( home_url( kerp_can( 'tickets.view', 'view' ) ? '/erp/tickets/' : '/panel/tickets/' ) ) . '">ورود به تیکت‌ها</a>'; } );
	}
	public function redirect(): void {
		$path = wp_parse_url( wp_unslash( $_SERVER['REQUEST_URI'] ?? '' ), PHP_URL_PATH );
		if ( preg_match( '~^' . preg_quote( (string) wp_parse_url( home_url( '/erp/tickets/' ), PHP_URL_PATH ), '~' ) . '(\d+)/?$~', (string) $path, $match ) ) {
			$ticket = KERP_Modules_Tickets_Store::get( (int) $match[1] );
			if ( $ticket && KERP_Modules_Tickets_Store::can_view( $ticket ) ) {
				wp_safe_redirect( home_url( '/erp/customers/' . (int) $ticket['user_id'] . '/?tab=tickets&ticket_id=' . (int) $ticket['id'] ), 302 ); exit;
			}
			return;
		}
		$old_public = ! empty( $_GET['ticket_id'] ) && untrailingslashit( (string) $path ) === untrailingslashit( (string) wp_parse_url( home_url( '/panel/tickets/' ), PHP_URL_PATH ) );
		if ( ! $old_public && ! preg_match( '~^' . preg_quote( (string) wp_parse_url( home_url( '/panel-manager' ), PHP_URL_PATH ), '~' ) . '(?:/|$)~', (string) $path ) ) { return; }
		$id = absint( $_GET['ticket_id'] ?? 0 ); $new = 0;
		if ( $id ) { global $wpdb; $new = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . KERP_Modules_Tickets_Store::table( 'tickets' ) . ' WHERE legacy_id=%d', $id ) ); }
		$staff = kerp_can( 'tickets.view', 'view' ); $url = $staff ? '/erp/tickets/' : '/panel/tickets/';
		if ( $new ) { $ticket = KERP_Modules_Tickets_Store::get( $new ); if ( $ticket && KERP_Modules_Tickets_Store::can_view( $ticket, ! $staff ) ) { $url = $staff ? '/erp/customers/' . (int) $ticket['user_id'] . '/?tab=tickets&ticket_id=' . $new : '/panel/tickets/support/' . $new . '/'; } }
		wp_safe_redirect( home_url( $url ), 302 ); exit;
	}
	public function pages( array $pages ): array { $pages['tickets'] = [ 'label' => 'تیکت‌های من', 'icon' => 'hik-r fa-message-18', 'type' => 'page' ]; return $pages; }
	public function template( string $file, string $path ): string {
		if ( in_array( $path, [ 'pages/tickets', 'sub_pages/support' ], TRUE ) ) { return KERP_TEMPLATES_PATH . 'modules/tickets/panel/tickets.php'; }
		return $file;
	}
	public function assets(): void {
		if ( ! is_page( 'panel' ) ) { return; }
		KERP_Helpers_Panel_Ajax::ensure_dependencies();
		// Reuse the panel's Quill: loading another copy resets its registered image-upload module.
		wp_enqueue_script( 'kerp-tickets-panel', KERP_ASSETS_URL . 'public/js/tickets-panel.js', [ 'jquery', 'nooshika_quill_script', 'nooshika_quill_image_uploader_script', 'nooshika_dropzone_script', 'nooshika_panel_script' ], kerp_asset_version( 'public/js/tickets-panel.js' ), TRUE );
	}

	public function register_panel_navigation_settings( array $rows ): array {
		return KERP_Settings_Panel_Navigation::register_entries( $rows, 'tickets', 'تیکت‌ها', $this->pages( [] ) );
	}
}
