<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Customer_Club_Api {
	private static ?self $instance = NULL;
	public static function instance(): self { return self::$instance ??= new self(); }

	private function __construct() {
		add_action( 'kasebi_ajax_customer_club_settings', [ $this, 'settings' ] );
		add_action( 'kasebi_ajax_customer_club_reward_save', [ $this, 'reward_save' ] );
		add_action( 'kasebi_ajax_customer_club_reward_toggle', [ $this, 'reward_toggle' ] );
		add_action( 'kasebi_ajax_customer_club_fulfill', [ $this, 'fulfill' ] );
		add_action( 'nooshika_ajax_kerp_club_redeem', [ $this, 'redeem' ] );
	}

	public function settings(): void {
		$this->guard_admin();
		$input = wp_unslash( $_POST );
		$values = KERP_Modules_Customer_Club_Settings::sanitize( $input );
		if ( is_wp_error( $values ) ) { $this->fail( $values->get_error_message() ); }
		update_option( KERP_Modules_Customer_Club_Settings::OPTION, $values, FALSE );
		$this->success( 'تنظیمات باشگاه مشتریان ذخیره شد.', '/erp/settings/customer-club/' );
	}

	public function reward_save(): void {
		$this->guard_admin();
		$type = sanitize_key( (string) ( $_POST['type'] ?? '' ) );
		$title = sanitize_text_field( wp_unslash( (string) ( $_POST['title'] ?? '' ) ) );
		$cost = absint( $_POST['coin_cost'] ?? 0 );
		$value_raw = KERP_Helpers_Format::sanitize_numbers( trim( (string) ( $_POST['value'] ?? '0' ) ) );
		$value = preg_match( '/^[0-9]+(?:\.[0-9]+)?$/D', $value_raw ) ? (float) $value_raw : NULL;
		$stock_raw = KERP_Helpers_Format::sanitize_numbers( (string) ( $_POST['stock'] ?? '-1' ) );
		$limit = absint( $_POST['per_user_limit'] ?? 0 );
		if ( $title === '' || $cost < 1 || ! in_array( $type, [ 'wallet', 'coupon', 'gift', 'course' ], TRUE ) || $value === NULL || ! preg_match( '/^-?[0-9]+$/D', $stock_raw ) ) { $this->fail( 'اطلاعات هدیه کامل یا معتبر نیست.' ); }
		if ( in_array( $type, [ 'wallet', 'coupon' ], TRUE ) && $value <= 0 ) { $this->fail( 'مبلغ کیف پول یا کد تخفیف باید بیشتر از صفر باشد.' ); }
		$data = [
			'title' => $title,
			'description' => wp_kses_post( wp_unslash( (string) ( $_POST['description'] ?? '' ) ) ),
			'image_id' => absint( $_POST['image_id'] ?? 0 ),
			'type' => $type,
			'coin_cost' => $cost,
			'value' => $value,
			'stock' => max( -1, (int) $stock_raw ),
			'per_user_limit' => $limit,
			'active' => ! empty( $_POST['active'] ) ? 1 : 0,
			'starts_at' => $this->date( $_POST['starts_at'] ?? '' ),
			'ends_at' => $this->date( $_POST['ends_at'] ?? '' ),
		];
		$result = KERP_Modules_Customer_Club_Store::save_reward( $data, absint( $_POST['reward_id'] ?? 0 ) );
		if ( is_wp_error( $result ) ) { $this->fail( $result->get_error_message() ); }
		$this->success( 'هدیه ذخیره شد.', '/erp/customer-club/rewards/' );
	}

	public function reward_toggle(): void {
		$this->guard_admin();
		$reward = KERP_Modules_Customer_Club_Store::reward( absint( $_POST['reward_id'] ?? 0 ) );
		if ( ! $reward ) { $this->fail( 'هدیه پیدا نشد.' ); }
		$reward['active'] = ! (int) $reward['active'];
		$id = (int) $reward['id'];
		unset( $reward['id'] );
		$result = KERP_Modules_Customer_Club_Store::save_reward( $reward, $id );
		if ( is_wp_error( $result ) ) { $this->fail( $result->get_error_message() ); }
		$this->success( 'وضعیت هدیه تغییر کرد.', '/erp/customer-club/rewards/' );
	}

	public function redeem(): void {
		if ( ! is_user_logged_in() || ! is_string( $_POST['nonce'] ?? NULL ) || ! wp_verify_nonce( wp_unslash( $_POST['nonce'] ), 'kerp_club_redeem' ) ) { $this->fail( 'اعتبار درخواست منقضی شده است.' ); }
		$result = KERP_Modules_Customer_Club_Rewards::redeem( get_current_user_id(), absint( $_POST['reward_id'] ?? 0 ), (string) ( $_POST['request_id'] ?? '' ) );
		if ( is_wp_error( $result ) ) { $this->fail( $result->get_error_message() ); }
		wp_send_json( [ 'status' => 'success', 'message' => 'هدیه ثبت شد و قابل لغو نیست.', 'reload' => TRUE ] );
	}

	public function fulfill(): void {
		$this->guard_admin();
		$id = absint( $_POST['redemption_id'] ?? 0 );
		$reference = sanitize_text_field( wp_unslash( (string) ( $_POST['fulfillment_ref'] ?? '' ) ) );
		global $wpdb;
		$table = KERP_Modules_Customer_Club_Store::table( 'redemptions' );
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id=%d", $id ), ARRAY_A );
		if ( ! $row || ! in_array( $row['status'], [ 'pending', 'review' ], TRUE ) ) { $this->fail( 'این درخواست قابل تحویل نیست.' ); }
		if ( FALSE === $wpdb->update( $table, [ 'status' => 'fulfilled', 'fulfillment_ref' => $reference ], [ 'id' => $id ] ) ) { $this->fail( 'ثبت تحویل انجام نشد.' ); }
		$this->success( 'هدیه به‌عنوان تحویل‌شده ثبت شد.', '/erp/customer-club/rewards/' );
	}

	private function guard_admin(): void {
		if ( ! is_user_logged_in() || ! KERP_App::instance()->current_user_has_access() || ! kerp_can( 'customer_club.manage', 'action' ) ) { $this->fail( 'اجازه انجام این عملیات را ندارید.' ); }
		if ( ! is_string( $_POST['nonce'] ?? NULL ) || ! wp_verify_nonce( wp_unslash( $_POST['nonce'] ), 'kerp_customer_club' ) ) { $this->fail( 'اعتبار فرم منقضی شده است.' ); }
	}

	private function date( mixed $value ): ?string {
		$value = sanitize_text_field( wp_unslash( (string) $value ) );
		if ( $value === '' ) { return NULL; }
		$converted = KERP_Helpers_Date::jalali_to_gregorian( $value );
		return $converted ? $converted . ' 00:00:00' : NULL;
	}

	private function fail( string $message ): never { wp_send_json( [ 'status' => 'error', 'message' => $message ] ); }
	private function success( string $message, string $path ): never {
		$response = KERP_Api_Page_Content::build_page_response( $path, [], TRUE );
		wp_send_json( array_merge( $response, [ 'status' => 'success', 'message' => $message ] ) );
	}
}
