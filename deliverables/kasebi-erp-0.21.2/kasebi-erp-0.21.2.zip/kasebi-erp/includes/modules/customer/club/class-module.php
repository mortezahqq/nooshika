<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Customer_Club_Module {
	private static ?self $instance = NULL;
	public static function instance(): self { return self::$instance ??= new self(); }

	private function __construct() {
		add_filter( 'kerp_panel_navigation_pages', [ $this, 'register_panel_navigation_settings' ] );
		KERP_Modules_Customer_Club_Store::install();
		if ( ! get_option( 'kerp_customer_club_started_at' ) ) { update_option( 'kerp_customer_club_started_at', current_time( 'mysql' ), FALSE ); }
		KERP_Modules_Customer_Club_Engine::instance();
		KERP_Modules_Customer_Club_Api::instance();
		add_filter( 'kerp_app_pages', [ $this, 'pages' ], 65 );
		add_filter( 'kerp_employee_permission_groups', [ $this, 'permissions' ], 65 );
		add_filter( 'kerp_customer_profile_tabs', [ $this, 'customer_tab' ], 65, 3 );
		add_filter( 'nooshika_panel_pages_list_final', [ $this, 'panel_pages' ], 30 );
		add_filter( 'nooshika_panel_get_template_path', [ $this, 'panel_template' ], 30, 2 );
		add_action( 'wp_enqueue_scripts', [ $this, 'assets' ], 50 );
		if ( ! wp_next_scheduled( 'kerp_customer_club_birthdays' ) ) { wp_schedule_event( strtotime( 'tomorrow 00:10' ), 'daily', 'kerp_customer_club_birthdays' ); }
	}

	public function pages( array $pages ): array {
		$group = [ 'key' => 'sales', 'title' => 'فروش و مالی', 'icon' => 'uik-r fa-money', 'order' => 25 ];
		$pages['customer-club-rewards'] = [ 'title' => 'هدایای باشگاه مشتریان', 'route' => 'customer-club/rewards', 'type' => 'page', 'template' => 'modules/customer-club/pages/rewards.php', 'permission' => 'customer_club.manage', 'navigation' => [ 'group' => $group, 'icon' => 'ni ni-gift', 'order' => 65 ] ];
		$pages['customer-club-settings'] = [ 'title' => 'تنظیمات باشگاه مشتریان', 'route' => 'settings/customer-club', 'type' => 'settings', 'template' => 'modules/customer-club/settings/general.php', 'permission' => 'customer_club.manage', 'navigation' => [ 'group' => [ 'key' => 'settings', 'title' => 'تنظیمات', 'order' => 100, 'sep_before' => TRUE ], 'icon' => 'ni ni-coins', 'order' => 65 ] ];
		return $pages;
	}

	public function permissions( array $groups ): array {
		$groups['sales'] ??= [ 'key' => 'sales', 'label' => 'فروش و مالی', 'icon' => 'uik-r fa-money', 'order' => 25, 'blocks' => [] ];
		$groups['sales']['blocks']['customer_club'] = [ 'key' => 'customer_club', 'label' => 'باشگاه مشتریان', 'icon' => 'ni ni-coins', 'order' => 65, 'permissions' => [
			'view' => [ 'key' => 'customer_club.view', 'label' => 'مشاهده گردش سکه مشتری', 'type' => 'view', 'order' => 10 ],
			'manage' => [ 'key' => 'customer_club.manage', 'label' => 'مدیریت قوانین و هدایا', 'type' => 'action', 'order' => 20 ],
		] ];
		return $groups;
	}

	public function customer_tab( array $tabs, int $customer_id, WP_User $customer ): array {
		$tabs['customer_club'] = [ 'key' => 'customer_club', 'title' => KERP_Modules_Customer_Club_Settings::label(), 'icon' => 'ni ni-coins', 'order' => 65, 'group' => 'finance-loyalty', 'permission' => 'customer_club.view', 'action' => 'view', 'template' => 'modules/customer-club/tabs/customer.php' ];
		return $tabs;
	}

	public function panel_pages( array $pages ): array { $pages['customer-club'] = [ 'label' => 'باشگاه مشتریان', 'icon' => 'ni ni-coins' ]; return $pages; }
	public function panel_template( string $file, string $path ): string { return $path === 'pages/customer-club' ? KERP_TEMPLATES_PATH . 'modules/customer-club/panel/customer-club.php' : $file; }

	public function assets(): void {
		if ( function_exists( 'kerp_is_erp_request' ) && kerp_is_erp_request() ) {
			wp_enqueue_media();
			wp_enqueue_script( 'kerp-customer-club-admin', KERP_ASSETS_URL . 'app/js/customer-club-admin.js', [ 'jquery' ], kerp_asset_version( 'app/js/customer-club-admin.js' ), TRUE );
		}
		if ( is_singular( 'post' ) && is_user_logged_in() ) {
			wp_enqueue_script( 'kerp-club-reading', KERP_ASSETS_URL . 'public/js/customer-club-reading.js', [], kerp_asset_version( 'public/js/customer-club-reading.js' ), TRUE );
			wp_localize_script( 'kerp-club-reading', 'KERPClubReading', [ 'url' => admin_url( 'admin-ajax.php' ), 'nonce' => wp_create_nonce( 'kerp_club_article' ), 'postId' => get_queried_object_id(), 'seconds' => 60, 'scroll' => 70 ] );
		}
		if ( is_page( 'panel' ) ) {
			wp_enqueue_style( 'kerp-customer-club', KERP_ASSETS_URL . 'public/css/customer-club.css', [], kerp_asset_version( 'public/css/customer-club.css' ) );
			wp_enqueue_script( 'kerp-customer-club', KERP_ASSETS_URL . 'public/js/customer-club.js', [ 'jquery' ], kerp_asset_version( 'public/js/customer-club.js' ), TRUE );
			wp_localize_script( 'kerp-customer-club', 'KERPClub', [ 'url' => home_url( '/n-ajax' ) ] );
		}
	}

	public function register_panel_navigation_settings( array $rows ): array {
		return KERP_Settings_Panel_Navigation::register_entries( $rows, 'customer_club', 'باشگاه مشتریان', $this->panel_pages( [] ) );
	}
}
