<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Customer_Club_Rewards {
	public static function redeem( int $user_id, int $reward_id, string $request_key ): int|WP_Error {
		global $wpdb;
		$request_key = substr( sanitize_key( $request_key ), 0, 64 );
		if ( strlen( $request_key ) < 16 ) { return new WP_Error( 'invalid_request', 'شناسه درخواست معتبر نیست.' ); }
		$lock = 'kerp_club_reward_' . md5( $wpdb->prefix . ':' . $reward_id );
		if ( (string) $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s,10)', $lock ) ) !== '1' ) { return new WP_Error( 'busy', 'درخواست دیگری در حال پردازش است.' ); }
		try {
			$table = KERP_Modules_Customer_Club_Store::table( 'redemptions' );
			$existing = $wpdb->get_row( $wpdb->prepare( "SELECT id,user_id,status FROM {$table} WHERE request_key=%s", $request_key ), ARRAY_A );
			if ( $existing ) { return (int) $existing['user_id'] === $user_id && $existing['status'] !== 'failed' ? (int) $existing['id'] : new WP_Error( 'duplicate_request', 'این درخواست قبلاً پردازش شده است.' ); }
			$reward = KERP_Modules_Customer_Club_Store::reward( $reward_id );
			$now = current_time( 'mysql' );
			if ( ! $reward || ! $reward['active'] || ( $reward['starts_at'] && $reward['starts_at'] > $now ) || ( $reward['ends_at'] && $reward['ends_at'] < $now ) ) { return new WP_Error( 'unavailable', 'این هدیه در دسترس نیست.' ); }
			if ( (int) $reward['stock'] >= 0 && KERP_Modules_Customer_Club_Store::redemption_count( $reward_id ) >= (int) $reward['stock'] ) { return new WP_Error( 'stock', 'موجودی این هدیه تمام شده است.' ); }
			if ( (int) $reward['per_user_limit'] > 0 && KERP_Modules_Customer_Club_Store::redemption_count( $reward_id, $user_id ) >= (int) $reward['per_user_limit'] ) { return new WP_Error( 'user_limit', 'سقف دریافت این هدیه برای شما تکمیل شده است.' ); }
			if ( KERP_Modules_Customer_Club_Store::balance( $user_id ) < (int) $reward['coin_cost'] ) { return new WP_Error( 'balance', 'موجودی سکه برای این هدیه کافی نیست.' ); }
			$snapshot = wp_json_encode( array_intersect_key( $reward, array_flip( [ 'id', 'title', 'description', 'type', 'coin_cost', 'value' ] ) ), JSON_UNESCAPED_UNICODE );
			if ( ! $wpdb->insert( $table, [ 'request_key' => $request_key, 'user_id' => $user_id, 'reward_id' => $reward_id, 'coin_cost' => (int) $reward['coin_cost'], 'reward_snapshot' => $snapshot, 'status' => 'created', 'created_at' => $now ] ) ) { return new WP_Error( 'create_failed', 'ثبت درخواست هدیه انجام نشد.' ); }
			$id = (int) $wpdb->insert_id;
			$spent = KERP_Modules_Customer_Club_Store::spend( $user_id, (int) $reward['coin_cost'], 'redemption', 'reward-redemption-' . $id, 'دریافت هدیه: ' . $reward['title'] );
			if ( is_wp_error( $spent ) ) { $wpdb->update( $table, [ 'status' => 'failed' ], [ 'id' => $id ] ); return $spent; }
			$status = 'pending';
			$reference = '';
			if ( $reward['type'] === 'wallet' ) {
				$result = KERP_Modules_Wallet_Service::instance()->add_transaction( $user_id, 'credit', (float) $reward['value'], 'پاداش باشگاه مشتریان #' . $id . ' [KERP:club:' . $id . ']' );
				if ( ! is_wp_error( $result ) ) { $status = 'fulfilled'; $reference = (string) $result; } else { $status = 'review'; }
			} elseif ( $reward['type'] === 'coupon' ) {
				$coupon = new WC_Coupon();
				$code = 'club-' . $user_id . '-' . wp_generate_password( 8, FALSE, FALSE );
				$coupon->set_code( $code ); $coupon->set_amount( (float) $reward['value'] ); $coupon->set_discount_type( 'fixed_cart' );
				$coupon->set_usage_limit( 1 ); $coupon->set_usage_limit_per_user( 1 ); $coupon->set_email_restrictions( [ get_userdata( $user_id )->user_email ] );
				$coupon->add_meta_data( '_kerp_club_redemption_id', $id, TRUE );
				try { $coupon->save(); $status = 'fulfilled'; $reference = $code; } catch ( Throwable $e ) { $status = 'review'; }
			}
			$wpdb->update( $table, [ 'status' => $status, 'fulfillment_ref' => $reference ], [ 'id' => $id ] );
			do_action( 'kerp_customer_club_redeemed', $id, $user_id, $reward, $status );
			return $id;
		} finally {
			$wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $lock ) );
		}
	}
}
