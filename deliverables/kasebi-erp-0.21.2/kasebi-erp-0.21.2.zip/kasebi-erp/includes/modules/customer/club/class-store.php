<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Customer_Club_Store {
	private const DB_VERSION = '1.1';

	public static function table( string $name ): string {
		global $wpdb;
		return $wpdb->prefix . 'kerp_club_' . $name;
	}

	public static function install(): void {
		if ( get_option( 'kerp_customer_club_db_version' ) === self::DB_VERSION ) { return; }
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$charset = $wpdb->get_charset_collate();
		$ledger = self::table( 'ledger' );
		$rewards = self::table( 'rewards' );
		$redemptions = self::table( 'redemptions' );
		dbDelta( "CREATE TABLE {$ledger} (
			id bigint unsigned NOT NULL AUTO_INCREMENT,
			request_key varchar(64) DEFAULT NULL,
			user_id bigint unsigned NOT NULL,
			amount bigint NOT NULL,
			remaining bigint NOT NULL DEFAULT 0,
			event varchar(50) NOT NULL,
			reference_key varchar(191) NOT NULL,
			description text NULL,
			expires_at datetime NULL,
			created_at datetime NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY request_key (request_key),
			UNIQUE KEY reference_key (reference_key),
			KEY user_balance (user_id,remaining,expires_at),
			KEY user_history (user_id,id),
			KEY event_limit (user_id,event,created_at)
		) {$charset};" );
		dbDelta( "CREATE TABLE {$rewards} (
			id bigint unsigned NOT NULL AUTO_INCREMENT,
			title varchar(190) NOT NULL,
			description text NULL,
			image_id bigint unsigned NOT NULL DEFAULT 0,
			type varchar(20) NOT NULL,
			coin_cost bigint unsigned NOT NULL,
			value decimal(20,6) NOT NULL DEFAULT 0,
			stock bigint NOT NULL DEFAULT -1,
			per_user_limit int unsigned NOT NULL DEFAULT 0,
			active tinyint NOT NULL DEFAULT 1,
			starts_at datetime NULL,
			ends_at datetime NULL,
			created_at datetime NOT NULL,
			PRIMARY KEY (id),
			KEY availability (active,starts_at,ends_at)
		) {$charset};" );
		dbDelta( "CREATE TABLE {$redemptions} (
			id bigint unsigned NOT NULL AUTO_INCREMENT,
			user_id bigint unsigned NOT NULL,
			reward_id bigint unsigned NOT NULL,
			coin_cost bigint unsigned NOT NULL,
			reward_snapshot longtext NOT NULL,
			status varchar(20) NOT NULL,
			fulfillment_ref varchar(190) NOT NULL DEFAULT '',
			created_at datetime NOT NULL,
			PRIMARY KEY (id),
			KEY user_id (user_id),
			KEY reward_id (reward_id),
			KEY status (status)
		) {$charset};" );
		foreach ( [ $ledger, $rewards, $redemptions ] as $table ) {
			if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $table ) ) ) !== $table ) { return; }
		}
		update_option( 'kerp_customer_club_db_version', self::DB_VERSION, FALSE );
	}

	public static function balance( int $user_id ): int {
		global $wpdb;
		$table = self::table( 'ledger' );
		return max( 0, (int) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(SUM(remaining),0) FROM {$table} WHERE user_id=%d AND (remaining<0 OR expires_at IS NULL OR expires_at>%s)", $user_id, current_time( 'mysql' ) ) ) );
	}

	public static function history( int $user_id, int $limit = 100 ): array {
		global $wpdb;
		$table = self::table( 'ledger' );
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE user_id=%d ORDER BY id DESC LIMIT %d", $user_id, min( 100, max( 1, $limit ) ) ), ARRAY_A ) ?: [];
	}

	public static function award( int $user_id, int $amount, string $event, string $reference, string $description = '' ): int|WP_Error {
		if ( $user_id < 1 || $amount < 1 || ! get_userdata( $user_id ) ) { return new WP_Error( 'invalid_award', 'کاربر یا تعداد سکه معتبر نیست.' ); }
		global $wpdb;
		$table = self::table( 'ledger' );
		$reference = substr( sanitize_key( $reference ), 0, 191 );
		$event = substr( sanitize_key( $event ), 0, 50 );
		$existing = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE reference_key=%s", $reference ) );
		if ( $existing ) { return $existing; }
		$days = (int) KERP_Modules_Customer_Club_Settings::all()['expiration_days'];
		$expires = $days > 0 ? wp_date( 'Y-m-d H:i:s', current_time( 'timestamp' ) + DAY_IN_SECONDS * $days ) : NULL;
		$ok = $wpdb->insert( $table, [ 'user_id' => $user_id, 'amount' => $amount, 'remaining' => $amount, 'event' => $event, 'reference_key' => $reference, 'description' => sanitize_text_field( $description ), 'expires_at' => $expires, 'created_at' => current_time( 'mysql' ) ], [ '%d', '%d', '%d', '%s', '%s', '%s', '%s', '%s' ] );
		if ( ! $ok ) {
			$existing = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE reference_key=%s", $reference ) );
			return $existing ?: new WP_Error( 'award_failed', 'ثبت سکه انجام نشد.' );
		}
		do_action( 'kerp_customer_club_awarded', $user_id, $amount, $event, (int) $wpdb->insert_id );
		return (int) $wpdb->insert_id;
	}

	public static function spend( int $user_id, int $amount, string $event, string $reference, string $description = '' ): int|WP_Error {
		if ( $amount < 1 ) { return new WP_Error( 'invalid_spend', 'تعداد سکه معتبر نیست.' ); }
		global $wpdb;
		$table = self::table( 'ledger' );
		$lock = 'kerp_club_' . md5( $wpdb->prefix . ':' . $user_id );
		if ( (string) $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s,10)', $lock ) ) !== '1' ) { return new WP_Error( 'busy', 'درخواست دیگری در حال پردازش است.' ); }
		try {
			$wpdb->query( 'START TRANSACTION' );
			$existing = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE reference_key=%s", $reference ) );
			if ( $existing ) { $wpdb->query( 'COMMIT' ); return $existing; }
			if ( self::balance( $user_id ) < $amount ) { $wpdb->query( 'ROLLBACK' ); return new WP_Error( 'insufficient_coins', 'موجودی سکه کافی نیست.' ); }
			$lots = $wpdb->get_results( $wpdb->prepare( "SELECT id,remaining FROM {$table} WHERE user_id=%d AND remaining>0 AND (expires_at IS NULL OR expires_at>%s) ORDER BY CASE WHEN expires_at IS NULL THEN 1 ELSE 0 END, expires_at, id FOR UPDATE", $user_id, current_time( 'mysql' ) ), ARRAY_A );
			$available = array_sum( array_map( static fn( $row ) => (int) $row['remaining'], $lots ) );
			if ( $available < $amount ) { $wpdb->query( 'ROLLBACK' ); return new WP_Error( 'insufficient_coins', 'موجودی سکه کافی نیست.' ); }
			$left = $amount;
			foreach ( $lots as $lot ) {
				$used = min( $left, (int) $lot['remaining'] );
				if ( FALSE === $wpdb->update( $table, [ 'remaining' => (int) $lot['remaining'] - $used ], [ 'id' => (int) $lot['id'] ], [ '%d' ], [ '%d' ] ) ) { throw new RuntimeException(); }
				$left -= $used;
				if ( $left === 0 ) { break; }
			}
			if ( ! $wpdb->insert( $table, [ 'user_id' => $user_id, 'amount' => -$amount, 'remaining' => 0, 'event' => sanitize_key( $event ), 'reference_key' => substr( sanitize_key( $reference ), 0, 191 ), 'description' => sanitize_text_field( $description ), 'expires_at' => NULL, 'created_at' => current_time( 'mysql' ) ] ) ) { throw new RuntimeException(); }
			$id = (int) $wpdb->insert_id;
			$wpdb->query( 'COMMIT' );
			return $id;
		} catch ( Throwable $e ) {
			$wpdb->query( 'ROLLBACK' );
			return new WP_Error( 'spend_failed', 'کسر سکه کامل نشد؛ دوباره تلاش کنید.' );
		} finally {
			$wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $lock ) );
		}
	}

	public static function reverse( int $user_id, int $amount, string $reference, string $description = '' ): int|WP_Error {
		if ( $amount < 1 ) { return new WP_Error( 'invalid_reverse', 'تعداد سکه برگشتی معتبر نیست.' ); }
		global $wpdb;
		$table = self::table( 'ledger' );
		$lock = 'kerp_club_' . md5( $wpdb->prefix . ':' . $user_id );
		if ( (string) $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s,10)', $lock ) ) !== '1' ) { return new WP_Error( 'busy', 'درخواست دیگری در حال پردازش است.' ); }
		try {
			$wpdb->query( 'START TRANSACTION' );
			$existing = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE reference_key=%s", $reference ) );
			if ( $existing ) { $wpdb->query( 'COMMIT' ); return $existing; }
			$left = $amount;
			$lots = $wpdb->get_results( $wpdb->prepare( "SELECT id,remaining FROM {$table} WHERE user_id=%d AND remaining>0 AND (expires_at IS NULL OR expires_at>%s) ORDER BY CASE WHEN expires_at IS NULL THEN 1 ELSE 0 END,expires_at,id", $user_id, current_time( 'mysql' ) ), ARRAY_A );
			foreach ( $lots as $lot ) {
				$used = min( $left, (int) $lot['remaining'] );
				if ( FALSE === $wpdb->update( $table, [ 'remaining' => (int) $lot['remaining'] - $used ], [ 'id' => (int) $lot['id'] ], [ '%d' ], [ '%d' ] ) ) { throw new RuntimeException(); }
				$left -= $used;
				if ( $left === 0 ) { break; }
			}
			$ok = $wpdb->insert( $table, [ 'user_id' => $user_id, 'amount' => -$amount, 'remaining' => -$left, 'event' => 'purchase_refund', 'reference_key' => substr( sanitize_key( $reference ), 0, 191 ), 'description' => sanitize_text_field( $description ), 'expires_at' => NULL, 'created_at' => current_time( 'mysql' ) ] );
			if ( ! $ok ) { throw new RuntimeException(); }
			$id = (int) $wpdb->insert_id;
			$wpdb->query( 'COMMIT' );
			return $id;
		} catch ( Throwable $e ) {
			$wpdb->query( 'ROLLBACK' );
			return new WP_Error( 'reverse_failed', 'برگشت سکه ثبت نشد.' );
		} finally {
			$wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $lock ) );
		}
	}

	public static function reference_total( int $user_id, string $prefix ): int {
		global $wpdb;
		$table = self::table( 'ledger' );
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(SUM(amount),0) FROM {$table} WHERE user_id=%d AND reference_key LIKE %s", $user_id, $wpdb->esc_like( $prefix ) . '%' ) );
	}

	public static function event_count( int $user_id, string $event, string $period ): int {
		global $wpdb;
		$table = self::table( 'ledger' );
		$now = current_time( 'timestamp' );
		$start = match ( $period ) {
			'day' => strtotime( 'today', $now ),
			'week' => strtotime( 'monday this week', $now ),
			'month' => strtotime( wp_date( 'Y-m-01 00:00:00', $now ) ),
			'year' => strtotime( wp_date( 'Y-01-01 00:00:00', $now ) ),
			default => 0,
		};
		$sql = "SELECT COUNT(*) FROM {$table} WHERE user_id=%d AND event=%s AND amount>0";
		$args = [ $user_id, $event ];
		if ( $start ) { $sql .= ' AND created_at>=%s'; $args[] = wp_date( 'Y-m-d H:i:s', $start ); }
		return (int) $wpdb->get_var( $wpdb->prepare( $sql, $args ) );
	}

	public static function rewards( bool $available_only = FALSE ): array {
		global $wpdb;
		$table = self::table( 'rewards' );
		$where = '';
		if ( $available_only ) {
			$now = current_time( 'mysql' );
			$where = $wpdb->prepare( ' WHERE active=1 AND (starts_at IS NULL OR starts_at<=%s) AND (ends_at IS NULL OR ends_at>=%s)', $now, $now );
		}
		return $wpdb->get_results( "SELECT * FROM {$table}{$where} ORDER BY active DESC,coin_cost,id", ARRAY_A ) ?: [];
	}

	public static function reward( int $id ): ?array {
		global $wpdb;
		$table = self::table( 'rewards' );
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id=%d", $id ), ARRAY_A ) ?: NULL;
	}

	public static function save_reward( array $data, int $id = 0 ): int|WP_Error {
		global $wpdb;
		$table = self::table( 'rewards' );
		$data['created_at'] = $id ? ( self::reward( $id )['created_at'] ?? current_time( 'mysql' ) ) : current_time( 'mysql' );
		$ok = $id ? $wpdb->update( $table, $data, [ 'id' => $id ] ) : $wpdb->insert( $table, $data );
		return $ok === FALSE ? new WP_Error( 'reward_failed', 'ذخیره هدیه انجام نشد.' ) : ( $id ?: (int) $wpdb->insert_id );
	}

	public static function redemption_count( int $reward_id, int $user_id = 0 ): int {
		global $wpdb;
		$table = self::table( 'redemptions' );
		$sql = "SELECT COUNT(*) FROM {$table} WHERE reward_id=%d AND status!='failed'";
		$args = [ $reward_id ];
		if ( $user_id ) { $sql .= ' AND user_id=%d'; $args[] = $user_id; }
		return (int) $wpdb->get_var( $wpdb->prepare( $sql, $args ) );
	}

	public static function redemptions( int $user_id, int $limit = 20 ): array {
		global $wpdb;
		$table = self::table( 'redemptions' );
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE user_id=%d ORDER BY id DESC LIMIT %d", $user_id, min( 100, max( 1, $limit ) ) ), ARRAY_A ) ?: [];
	}

	public static function all_redemptions( int $limit = 100 ): array {
		global $wpdb;
		$table = self::table( 'redemptions' );
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} ORDER BY id DESC LIMIT %d", min( 500, max( 1, $limit ) ) ), ARRAY_A ) ?: [];
	}
}
