<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Customer_Club_Engine {
	private static ?self $instance = NULL;
	public static function instance(): self { return self::$instance ??= new self(); }

	private function __construct() {
		foreach ( [ 'woocommerce_payment_complete', 'woocommerce_order_status_processing', 'woocommerce_order_status_completed', 'woocommerce_order_refunded' ] as $hook ) {
			add_action( $hook, [ $this, 'reconcile_order' ], 70 );
		}
		add_action( 'transition_comment_status', [ $this, 'comment_status' ], 20, 3 );
		add_action( 'wp_ajax_kerp_club_article_read', [ $this, 'article_read' ] );
		add_action( 'kerp_customer_club_birthdays', [ $this, 'birthdays' ] );
	}

	public function reconcile_order( mixed $order_id ): void {
		$order = $order_id instanceof WC_Order ? $order_id : wc_get_order( absint( $order_id ) );
		// Installment receipts already earn/reverse their own purchase rewards.
		if ( $order && $order->get_meta( '_kerp_installment_is_parent' ) ) { return; }
		if ( ! $order instanceof WC_Order || ! KERP_Modules_Customer_Club_Settings::all()['enabled'] ) { return; }
		$user_id = (int) $order->get_customer_id();
		if ( $user_id < 1 || ! $order->is_paid() || $order->has_status( [ 'cancelled', 'failed' ] ) ) { return; }
		$started = strtotime( (string) get_option( 'kerp_customer_club_started_at', '' ) );
		$paid_at = $order->get_date_paid();
		if ( $started && $paid_at && $paid_at->getTimestamp() < $started ) { return; }
		$settings = KERP_Modules_Customer_Club_Settings::all();
		$goods = 0.0;
		$refunded = 0.0;
		foreach ( $order->get_items( 'line_item' ) as $item_id => $item ) {
			$goods += max( 0.0, (float) $item->get_total() );
			$refunded += abs( (float) $order->get_total_refunded_for_item( $item_id ) );
		}
		$deductions = 0.0;
		foreach ( $order->get_items( 'fee' ) as $fee ) {
			if ( (float) $fee->get_total() < 0 ) { $deductions += abs( (float) $fee->get_total() ); }
		}
		if ( in_array( $order->get_payment_method(), [ 'wallet', 'woo_wallet' ], TRUE ) ) { $deductions = $goods; }
		$eligible = max( 0, $goods - $deductions - $refunded );
		$target = (int) floor( $eligible / max( 1, (int) $settings['purchase_step'] ) ) * max( 1, (int) $settings['purchase_coins'] );
		$prefix = 'purchase-order-' . $order->get_id() . '-';
		$current = KERP_Modules_Customer_Club_Store::reference_total( $user_id, $prefix );
		$delta = $target - $current;
		if ( $delta > 0 ) {
			KERP_Modules_Customer_Club_Store::award( $user_id, $delta, 'purchase', $prefix . 'credit-' . $target, sprintf( 'سکه خرید سفارش #%d', $order->get_id() ) );
		} elseif ( $delta < 0 ) {
			KERP_Modules_Customer_Club_Store::reverse( $user_id, abs( $delta ), $prefix . 'refund-' . $target, sprintf( 'برگشت سکه سفارش #%d', $order->get_id() ) );
		}
	}

	public function comment_status( string $new, string $old, WP_Comment $comment ): void {
		if ( $new !== 'approved' || $old === 'approved' || (int) $comment->user_id < 1 ) { return; }
		$this->award_rule( (int) $comment->user_id, 'comment_approved', 'comment-approved-' . $comment->comment_ID, 'تأیید دیدگاه' );
	}

	public function article_read(): void {
		if ( ! is_user_logged_in() || ! check_ajax_referer( 'kerp_club_article', 'nonce', FALSE ) ) { wp_send_json_error( [ 'message' => 'درخواست معتبر نیست.' ], 403 ); }
		$post_id = absint( $_POST['post_id'] ?? 0 );
		if ( ! $post_id || get_post_status( $post_id ) !== 'publish' || get_post_type( $post_id ) !== 'post' ) { wp_send_json_error( [ 'message' => 'مقاله معتبر نیست.' ], 400 ); }
		$result = $this->award_rule( get_current_user_id(), 'article_read', 'article-read-' . get_current_user_id() . '-' . $post_id, 'مطالعه مقاله: ' . get_the_title( $post_id ) );
		wp_send_json_success( [ 'awarded' => ! is_wp_error( $result ) ] );
	}

	public function birthdays(): void {
		$today = current_time( 'Y-m-d' );
		$users = get_users( [ 'meta_key' => 'birthday', 'meta_compare' => 'EXISTS', 'fields' => [ 'ID' ], 'number' => -1 ] );
		foreach ( $users as $user ) {
			$birthday = KERP_Helpers_Date::jalali_to_gregorian( (string) get_user_meta( $user->ID, 'birthday', TRUE ) );
			if ( $birthday && substr( $birthday, 5 ) === substr( $today, 5 ) ) {
				$this->award_rule( (int) $user->ID, 'birthday', 'birthday-' . $user->ID . '-' . substr( $today, 0, 4 ), 'هدیه تولد' );
			}
		}
	}

	private function award_rule( int $user_id, string $event, string $reference, string $description ): int|WP_Error {
		$settings = KERP_Modules_Customer_Club_Settings::all();
		$rule = $settings['rules'][ $event ] ?? NULL;
		if ( empty( $settings['enabled'] ) || ! is_array( $rule ) || empty( $rule['enabled'] ) ) { return new WP_Error( 'disabled', 'این قانون فعال نیست.' ); }
		$limit = (int) $rule['limit'];
		if ( $limit > 0 && KERP_Modules_Customer_Club_Store::event_count( $user_id, $event, (string) $rule['period'] ) >= $limit ) { return new WP_Error( 'limit', 'سقف دریافت این پاداش تکمیل شده است.' ); }
		return KERP_Modules_Customer_Club_Store::award( $user_id, (int) $rule['coins'], $event, $reference, $description );
	}
}
