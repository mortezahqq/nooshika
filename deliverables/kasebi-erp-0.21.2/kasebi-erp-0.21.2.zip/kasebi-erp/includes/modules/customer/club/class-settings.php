<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Customer_Club_Settings {
	public const OPTION = 'kerp_customer_club_settings';

	public static function defaults(): array {
		return [
			'enabled' => TRUE,
			'unit_name' => 'سکه',
			'unit_icon' => 'ni ni-coins',
			'unit_color' => '#f4a100',
			'unit_image_id' => 0,
			'expiration_days' => 0,
			'purchase_step' => 200000,
			'purchase_coins' => 1,
			'rules' => [
				'comment_approved' => [ 'enabled' => TRUE, 'coins' => 2, 'limit' => 5, 'period' => 'day' ],
				'article_read' => [ 'enabled' => TRUE, 'coins' => 1, 'limit' => 1, 'period' => 'day' ],
				'birthday' => [ 'enabled' => TRUE, 'coins' => 20, 'limit' => 1, 'period' => 'year' ],
			],
		];
	}

	public static function all(): array {
		$saved = get_option( self::OPTION, [] );
		$saved = is_array( $saved ) ? $saved : [];
		$settings = array_replace_recursive( self::defaults(), $saved );
		$settings['rules'] = array_intersect_key( $settings['rules'], self::defaults()['rules'] );
		return $settings;
	}

	public static function label( int $amount = 1 ): string {
		return trim( (string) self::all()['unit_name'] ) ?: 'سکه';
	}

	public static function sanitize( mixed $input ): array|WP_Error {
		if ( ! is_array( $input ) ) {
			return new WP_Error( 'invalid_settings', 'ساختار تنظیمات باشگاه معتبر نیست.' );
		}
		$out = self::defaults();
		$out['enabled'] = ! empty( $input['enabled'] );
		$out['unit_name'] = sanitize_text_field( (string) ( $input['unit_name'] ?? '' ) );
		$icon_classes = preg_split( '/\s+/', trim( (string) ( $input['unit_icon'] ?? '' ) ) ) ?: [];
		$out['unit_icon'] = implode( ' ', array_filter( array_map( 'sanitize_html_class', $icon_classes ) ) );
		$out['unit_color'] = sanitize_hex_color( (string) ( $input['unit_color'] ?? '' ) ) ?: '#f4a100';
		$out['unit_image_id'] = absint( $input['unit_image_id'] ?? 0 );
		foreach ( [ 'expiration_days', 'purchase_step', 'purchase_coins' ] as $key ) {
			$value = self::integer( $input[ $key ] ?? NULL );
			if ( $value === NULL || $value < ( $key === 'expiration_days' ? 0 : 1 ) ) {
				return new WP_Error( 'invalid_number', 'مقادیر عددی تنظیمات باید عدد صحیح معتبر باشند.' );
			}
			$out[ $key ] = $value;
		}
		$rules = is_array( $input['rules'] ?? NULL ) ? $input['rules'] : [];
		foreach ( $out['rules'] as $event => $default ) {
			$row = is_array( $rules[ $event ] ?? NULL ) ? $rules[ $event ] : [];
			$coins = self::integer( $row['coins'] ?? NULL );
			$limit = self::integer( $row['limit'] ?? NULL );
			$period = sanitize_key( (string) ( $row['period'] ?? '' ) );
			if ( $coins === NULL || $coins < 1 || $limit === NULL || $limit < 0 || ! in_array( $period, [ 'day', 'week', 'month', 'year', 'lifetime' ], TRUE ) ) {
				return new WP_Error( 'invalid_rule', 'مقدار، سقف یا دوره یکی از قوانین امتیازدهی معتبر نیست.' );
			}
			$out['rules'][ $event ] = [ 'enabled' => ! empty( $row['enabled'] ), 'coins' => $coins, 'limit' => $limit, 'period' => $period ];
		}
		if ( $out['unit_name'] === '' || mb_strlen( $out['unit_name'] ) > 30 ) {
			return new WP_Error( 'invalid_name', 'عنوان واحد باید بین ۱ تا ۳۰ نویسه باشد.' );
		}
		if ( $out['unit_icon'] === '' ) { $out['unit_icon'] = 'ni ni-coins'; }
		return $out;
	}

	private static function integer( mixed $value ): ?int {
		if ( ! is_scalar( $value ) ) { return NULL; }
		$value = KERP_Helpers_Format::sanitize_numbers( trim( (string) $value ) );
		return preg_match( '/^[0-9]+$/D', $value ) ? (int) $value : NULL;
	}
}
