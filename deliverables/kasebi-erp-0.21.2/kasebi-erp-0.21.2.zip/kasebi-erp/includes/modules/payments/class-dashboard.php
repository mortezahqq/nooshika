<?php
defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Payments_Dashboard {
	private static ?self $instance = NULL;

	public static function instance(): self { return self::$instance ??= new self(); }
	private function __construct() {
		add_filter( 'kerp_dashboard_blocks', [ $this, 'register_blocks' ] );
	}
	public function register_blocks( array $blocks ): array {
		foreach ( [ 'trend' => 'روند پرداخت‌های وصول‌شده', 'methods' => 'خلاصه روش‌های پرداخت' ] as $kind => $title ) {
			$blocks[ 'payments-' . $kind ] = [
				'title' => $title, 'position' => $kind === 'trend' ? 50 : 51, 'width' => 6,
				'module' => 'payments', 'permission' => 'payments.view', 'permission_type' => 'view',
				'async' => TRUE, 'callback' => [ $this, 'render' ],
			];
		}
		return $blocks;
	}
	public function render( array $context, array $block ): void {
		if ( ! kerp_can( 'payments.view', 'view' ) || kerp_list_scope( 'orders' ) === 'none' ) { return; }
		$kind = substr( (string) ( $block['id'] ?? '' ), strlen( 'payments-' ) );
		if ( ! in_array( $kind, [ 'trend', 'methods' ], TRUE ) ) { return; }
		KERP_Helpers_Template::render_template( 'modules/payments/dashboard.php', [ 'kind' => $kind, 'stats' => $this->data() ] );
	}
	public function data(): array {
        if ( ! kerp_can( 'payments.view', 'view' ) || ! in_array( kerp_list_scope( 'orders' ), [ 'own', 'all' ], TRUE ) ) { return [ 'daily' => [], 'labels' => [], 'methods' => [], 'total' => 0 ]; }
        return KERP_Helpers_Dashboard_Cache::remember( 'payments', [ $this, 'collect' ] );
    }

    public function collect( array $state ): array {
        $now = new DateTimeImmutable( $state['as_of'] );
		$start = $now->setTime( 0, 0 )->modify( '-29 days' );
		$data = $state['data'] ?? [ 'daily' => [], 'labels' => [], 'methods' => [], 'total' => 0 ];
        $data['labels'] = [];
		for ( $day = $start; $day <= $now; $day = $day->modify( '+1 day' ) ) {
			$key = $day->format( 'Y-m-d' );
			$data['daily'][ $key ] ??= 0;
			$data['labels'][] = KERP_Helpers_Date::gregorian_to_jalali( $key );
		}
		$scope = kerp_list_scope( 'orders' );
		if ( ! kerp_can( 'payments.view', 'view' ) || ! in_array( $scope, [ 'own', 'all' ], TRUE ) ) { return $data; }

		global $wpdb;
		// Payment timestamps are UTC. Boundaries and day buckets use the site timezone.
		$utc = new DateTimeZone( 'UTC' );
		$where = $wpdb->prepare( 'created_at >= %s AND created_at <= %s', $start->setTimezone( $utc )->format( 'Y-m-d H:i:s' ), $now->setTimezone( $utc )->format( 'Y-m-d H:i:s' ) );
		if ( $scope === 'own' ) { $where .= $wpdb->prepare( ' AND created_by=%d', get_current_user_id() ); }
		$table = KERP_Modules_Payments_Store::table();
		$cursor = (int) ( $state['cursor'] ?? 0 );
		$cursor_date = (string) ( $state['cursor_date'] ?? '' );
        $allowed_orders = [];
		$deadline = microtime( TRUE ) + 1.5;
		$processed = 0;
		{
			// Read bounded batches without loading receipt payloads. Apply the same entity check as the payment list.
			$rows = (array) $wpdb->get_results( $wpdb->prepare( "SELECT id,order_id,method,currency,status,amount,created_at FROM {$table} WHERE {$where} AND (created_at > %s OR (created_at = %s AND id > %d)) ORDER BY created_at,id LIMIT 50", $cursor_date, $cursor_date, $cursor ), ARRAY_A );
			foreach ( $rows as $row ) {
				if ( $processed > 0 && microtime( TRUE ) >= $deadline ) { break; }
				++$processed;
				$cursor = (int) $row['id'];
				$cursor_date = $row['created_at'];
                if ( $row['order_id'] ) {
                    $allowed_orders[ $row['order_id'] ] ??= (bool) KERP_Modules_Orders_Query::instance()->get_order( (int) $row['order_id'] );
                    if ( ! $allowed_orders[ $row['order_id'] ] ) { continue; }
                }
				$day = substr( get_date_from_gmt( $row['created_at'], 'Y-m-d H:i:s' ), 0, 10 );
				if ( ! isset( $data['daily'][ $day ] ) ) { continue; }
				$key = $row['method'] . ':' . $row['currency'];
				$data['methods'][ $key ] ??= [ 'method' => $row['method'], 'currency' => $row['currency'], 'count' => 0, 'paid' => 0, 'review' => 0 ];
				++$data['total'];
				++$data['methods'][ $key ]['count'];
				if ( $row['status'] === 'paid' ) {
					++$data['daily'][ $day ];
					$data['methods'][ $key ]['paid'] += (float) $row['amount'];
				}
				if ( $row['status'] === 'review' ) { ++$data['methods'][ $key ]['review']; }
			}
		}
        if ( count( $rows ) === 50 || $processed < count( $rows ) ) { return [ 'done' => FALSE, 'data' => $data, 'cursor' => $cursor, 'cursor_date' => $cursor_date ]; }
		uasort( $data['methods'], static fn( $a, $b ) => $b['count'] <=> $a['count'] );
		return [ 'done' => TRUE, 'data' => $data ];
	}
}
