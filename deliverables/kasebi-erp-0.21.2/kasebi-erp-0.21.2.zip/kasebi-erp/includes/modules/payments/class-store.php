<?php
defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Payments_Store {
	public static function table(): string { global $wpdb; return $wpdb->prefix . 'kerp_payments'; }
	public static function has_for_order( int $order_id ): bool {
		static $cache = [];
		$scope = kerp_list_scope( 'orders' );
		if ( $order_id <= 0 || $scope === 'none' ) { return FALSE; }
		$key = get_current_user_id() . ':' . $scope . ':' . $order_id;
		if ( ! array_key_exists( $key, $cache ) ) {
			global $wpdb;
			$where = self::order_where( $order_id );
			if ( $scope === 'own' ) { $where .= $wpdb->prepare( ' AND created_by=%d', get_current_user_id() ); }
			$cache[ $key ] = (bool) $wpdb->get_var( 'SELECT id FROM ' . self::table() . ' WHERE ' . $where . ' LIMIT 1' );
		}
		return $cache[ $key ];
	}
	private static function order_where( int $order_id ): string {
		$ids = KERP_Modules_Installment_Management_Service::payment_order_ids( $order_id );
		return 'order_id IN (' . implode( ',', array_map( 'absint', $ids ) ) . ')';
	}
	public static function install(): void {
		if ( get_option( 'kerp_payments_db_version' ) === '2' ) { return; }
		global $wpdb; require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$table = self::table(); $charset = $wpdb->get_charset_collate();
		dbDelta( "CREATE TABLE $table (
		id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
		request_id varchar(36) NOT NULL,
		order_id bigint(20) unsigned NOT NULL DEFAULT 0,
		customer_id bigint(20) unsigned NOT NULL,
		created_by bigint(20) unsigned NOT NULL,
		method varchar(100) NOT NULL,
		amount decimal(26,8) NOT NULL DEFAULT 0,
		currency varchar(12) NOT NULL,
		status varchar(24) NOT NULL,
		payload longtext NOT NULL,
		created_at datetime NOT NULL,
		reviewed_by bigint(20) unsigned NOT NULL DEFAULT 0,
		PRIMARY KEY (id), UNIQUE KEY request_id (request_id), KEY order_id (order_id), KEY status_creator (status,created_by),
		KEY dashboard_date (created_at,id), KEY dashboard_creator_date (created_by,created_at,id)
		) $charset;" );
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $table ) ) ) === $table ) { update_option( 'kerp_payments_db_version', '2', FALSE ); }
	}
	public static function get( int $id ): ?array { global $wpdb; return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE id=%d', $id ), ARRAY_A ); }
	public static function update( int $id, array $data ): bool { global $wpdb; return $wpdb->update( self::table(), $data, [ 'id' => $id ] ) !== FALSE; }
	public static function lock( string $key ): bool { global $wpdb; return (int) $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s,0)', 'kerp_pay_' . md5( $wpdb->prefix . $key ) ) ) === 1; }
	public static function unlock( string $key ): void { global $wpdb; $wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', 'kerp_pay_' . md5( $wpdb->prefix . $key ) ) ); }
	public static function find( array $query ): array {
		global $wpdb; $where = [ '1=1' ]; $scope = kerp_list_scope( 'orders' );
		if ( $scope === 'none' ) { $where[] = '1=0'; }
		if ( $scope === 'own' ) { $where[] = $wpdb->prepare( 'created_by=%d', get_current_user_id() ); }
		foreach ( [ 'method', 'status' ] as $key ) { $value = KERP_Modules_Payments_Settings::text( $query, $key ); if ( $value !== '' ) { $where[] = $wpdb->prepare( "$key=%s", $value ); } }
		if ( ! empty( $query['order_id'] ) ) { $where[] = self::order_where( absint( $query['order_id'] ) ); }
		$sql = ' FROM ' . self::table() . ' WHERE ' . implode( ' AND ', $where );
		$total = (int) $wpdb->get_var( 'SELECT COUNT(*)' . $sql ); $per = min( 50, max( 1, absint( $query['per_page'] ?? 20 ) ) );
		$pages = max( 1, (int) ceil( $total / $per ) ); $page = min( $pages, max( 1, absint( $query['page_number'] ?? 1 ) ) );
		return [ 'rows' => $wpdb->get_results( $wpdb->prepare( 'SELECT *' . $sql . ' ORDER BY id DESC LIMIT %d OFFSET %d', $per, ( $page - 1 ) * $per ), ARRAY_A ), 'pages' => $pages, 'page' => $page, 'total' => $total ];
	}
}
