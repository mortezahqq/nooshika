<?php
defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Payments_Module {
	private static ?self $instance = NULL;
	public static function instance(): self { return self::$instance ??= new self(); }
	public static function enabled(): bool { return self::$instance !== NULL; }
	private function __construct() {
		KERP_Modules_Payments_Store::install(); KERP_Modules_Payments_Api::boot();
		KERP_Modules_Payments_Dashboard::instance();
		add_filter( 'kerp_app_pages', [ $this, 'pages' ], 65 );
		add_filter( 'kerp_employee_permission_groups', [ $this, 'permissions' ], 65 );
		self::boot_runtime();
		add_action( 'wp_loaded', [ $this, 'gateway_dependencies' ] );
		add_filter( 'kerp_ajax_forced_plugins', static fn( $p ) => array_values( array_unique( array_merge( $p, [ 'woocommerce/woocommerce.php' ], (array) get_option( 'kerp_payments_gateway_plugins', [] ) ) ) ) );
		add_action( 'kerp_orders_form_payment_method', static function( $order, $customer, $mode ) { KERP_Helpers_Template::render_template( 'modules/payments/order-fields.php', compact( 'order', 'mode' ) ); }, 10, 3 );

	}
	public static function boot_runtime(): void {
		static $booted = FALSE; if ( $booted ) { return; } $booted = TRUE;
		KERP_Modules_Payments_Cheques::boot();
		add_action( 'init', [ self::class, 'statuses' ], 25 ); if ( did_action( 'init' ) ) { self::statuses(); }
		add_filter( 'wc_order_statuses', static fn( $s ) => $s + [ 'wc-part-payment' => 'پیش‌پرداخت / مانده‌دار', 'wc-pre-invoice' => 'پیش‌فاکتور', 'wc-finance-review' => 'در انتظار تأیید مالی', 'wc-installments' => 'در حال پرداخت اقساط' ], 25 );
		add_filter( 'woocommerce_order_is_paid_statuses', static fn( $s ) => array_unique( array_merge( $s, [ 'installments' ] ) ) );
		add_filter( 'woocommerce_valid_order_statuses_for_payment_complete', static fn( $s ) => array_unique( array_merge( $s, [ 'finance-review', 'part-payment' ] ) ) );
		add_filter( 'kerp_orders_statuses', static function( $s ) {
			foreach ( [ 'part-payment' => 'پیش‌پرداخت / مانده‌دار', 'pre-invoice' => 'پیش‌فاکتور', 'finance-review' => 'در انتظار تأیید مالی', 'installments' => 'در حال پرداخت اقساط' ] as $key => $label ) { $s[ $key ] = [ 'label' => $label, 'active' => TRUE, 'color' => 'warning', 'order' => 55, 'allowed_next' => [] ]; }
			return $s;
		} );
		add_filter( 'kerp_orders_allowed_next_statuses', static fn( $s, $current ) => in_array( $current, [ 'finance-review', 'pre-invoice', 'part-payment' ], TRUE ) ? [] : array_diff_key( $s, [ 'part-payment' => TRUE, 'pre-invoice' => TRUE, 'installments' => TRUE, 'finance-review' => TRUE ] ), 100, 2 );
		add_action( 'woocommerce_order_status_changed', [ KERP_Modules_Payments_Service::class, 'changed' ], 50 );
		add_action( 'woocommerce_payment_complete', [ KERP_Modules_Payments_Service::class, 'changed' ], 50 );
		add_action( 'woocommerce_order_refunded', [ KERP_Modules_Payments_Service::class, 'changed' ], 50 );
		add_filter( 'woocommerce_order_needs_payment', static fn( $needs, $order ) => $needs && KERP_Modules_Payments_Deposit::payable( $order ), 20, 2 );
		add_filter( 'woocommerce_available_payment_gateways', static function( $gateways ) {
			global $wp_query;
			if ( ! $wp_query instanceof WP_Query ) { return $gateways; }
			$id = absint( get_query_var( 'order-pay' ) ); $order = $id ? wc_get_order( $id ) : FALSE;
			if ( $order && $order->get_meta( '_kerp_payment_gateway' ) ) { return array_intersect_key( $gateways, [ $order->get_meta( '_kerp_payment_gateway' ) => TRUE ] ); }
			return $gateways;
		// Gateway plugins (including SnappPay) must finish updating their objects before pruning.
		}, PHP_INT_MAX );
	}
	public function gateway_dependencies(): void {
		if ( defined( 'KERP_MU_DOING_AJAX' ) && KERP_MU_DOING_AJAX ) { return; }
		$active = array_unique( array_merge( (array) get_option( 'active_plugins', [] ), array_keys( (array) get_site_option( 'active_sitewide_plugins', [] ) ) ) ); $plugins = [];
		// Keep the site's existing SMS provider available on the reduced ERP AJAX endpoint.
		if ( in_array( 'nooshika-main/nooshika-main.php', $active, TRUE ) ) { $plugins[] = 'nooshika-main/nooshika-main.php'; }
		foreach ( WC()->payment_gateways()->payment_gateways() as $gateway ) {
			$file = ( new ReflectionClass( $gateway ) )->getFileName(); if ( ! $file ) { continue; }
			$file = plugin_basename( $file );
			foreach ( $active as $plugin ) { if ( $file === $plugin || str_starts_with( $file, dirname( $plugin ) . '/' ) ) { $plugins[] = $plugin; } }
		}
		$plugins = array_values( array_unique( $plugins ) );
		if ( $plugins !== get_option( 'kerp_payments_gateway_plugins', [] ) ) { update_option( 'kerp_payments_gateway_plugins', $plugins, FALSE ); }
		$ajax = KERP_Modules_Ajax_Module::instance(); $ajax->update_ajax_active_plugins( array_values( array_unique( array_merge( $ajax->get_ajax_active_plugins(), $plugins, [ 'woocommerce/woocommerce.php' ] ) ) ) );
	}
	public static function statuses(): void {
		foreach ( [ 'part-payment' => 'پیش‌پرداخت / مانده‌دار', 'pre-invoice' => 'پیش‌فاکتور', 'finance-review' => 'در انتظار تأیید مالی', 'installments' => 'در حال پرداخت اقساط' ] as $key => $label ) { register_post_status( 'wc-' . $key, [ 'label' => $label, 'public' => FALSE, 'show_in_admin_all_list' => TRUE, 'show_in_admin_status_list' => TRUE, 'label_count' => _n_noop( $label . ' (%s)', $label . ' (%s)' ) ] ); }
	}
	public function pages( array $pages ): array {
		$pages['cheque-settings'] = [ 'title' => 'مراحل و پیامک چک', 'route' => 'settings/payments/cheques', 'type' => 'settings', 'template' => 'modules/payments/cheques-settings.php', 'permission' => 'payments.manage_settings' ];
		$pages['payments'] = [ 'title' => 'پرداخت‌ها', 'route' => 'payments', 'type' => 'page', 'template' => 'modules/payments/list.php', 'permission' => 'payments.view', 'navigation' => [ 'group' => [ 'key' => 'sales', 'title' => 'فروش', 'icon' => 'ni ni-cart', 'order' => 30 ], 'title' => 'پرداخت‌ها', 'icon' => 'ni ni-wallet', 'order' => 30 ] ];
		$pages['payment-settings'] = [ 'title' => 'تنظیمات پرداخت', 'route' => 'settings/payments', 'type' => 'settings', 'template' => 'modules/payments/settings.php', 'permission' => 'payments.manage_settings', 'navigation' => [ 'group' => [ 'key' => 'settings', 'title' => 'تنظیمات', 'icon' => 'ni ni-setting', 'order' => 100 ], 'menu' => [ 'key' => 'orders-settings', 'title' => __( 'تنظیمات سفارش‌ها', 'kasebi-erp' ), 'icon' => 'uik-r fa-shopping-cart', 'order' => 40 ], 'title' => 'پرداخت', 'icon' => 'ni ni-wallet', 'order' => 58 ] ];
		return $pages;
	}
	public function permissions( array $groups ): array {
		$items = []; foreach ( [ 'view' => 'مشاهده پرداخت‌ها', 'create' => 'ثبت پرداخت', 'approve' => 'تأیید و رد مالی', 'manage_settings' => 'تنظیمات روش‌های پرداخت' ] as $key => $label ) { $items[ $key ] = [ 'key' => 'payments.' . $key, 'label' => $label, 'type' => $key === 'view' ? 'view' : 'action' ]; }
		$groups['payments'] = [ 'key' => 'payments', 'label' => 'پرداخت‌ها', 'icon' => 'ni ni-wallet', 'order' => 58, 'blocks' => [ 'payments' => [ 'key' => 'payments', 'label' => 'پرداخت‌ها', 'permissions' => $items ] ] ]; return $groups;
	}
}
