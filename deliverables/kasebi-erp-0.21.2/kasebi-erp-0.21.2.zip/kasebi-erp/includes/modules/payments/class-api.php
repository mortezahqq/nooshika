<?php
defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Payments_Api {
	
	public static function boot(): void {
		foreach ( [ 'create_order', 'save_proforma', 'preview', 'submit', 'review', 'save_settings', 'upload', 'order_payments', 'order_payment_form', 'send_sms' ] as $method ) {
			add_action( 'kasebi_ajax_payments_' . $method, [ self::class, $method ] );
		}
	}
	
	private static function input(): array {
		return wp_unslash( $_POST );
	}
	
	private static function guard( string $permission, bool $allow_order_creation = FALSE ): void {
		$allowed = kerp_can( 'payments.' . $permission, $permission === 'view' ? 'view' : 'action' )
			|| ( $permission === 'create' && $allow_order_creation && kerp_can( 'orders.create', 'action' ) );
		if ( ! is_user_logged_in() || ! KERP_App::instance()
		                                        ->current_user_has_access() || ! $allowed ) {
			self::error( 'دسترسی لازم را ندارید.' );
		}
		if ( ! wp_verify_nonce( KERP_Modules_Payments_Settings::text( self::input(), 'payment_nonce' ), 'kerp_payments' ) ) {
			self::error( 'اعتبار فرم منقضی شده است؛ صفحه را تازه کنید.' );
		}
	}
	
	private static function error( string $message ): void {
		wp_send_json( [ 'status' => 'error', 'message' => $message, 'msg' => $message ] );
		exit;
	}
	
	private static function success( string $message, string $page ): void {
		wp_send_json( array_merge( [
			'status'  => 'success',
			'message' => $message,
			'msg'     => $message,
		], KERP_Api_Page_Content::build_page_response( $page, [], TRUE ) ) );
		exit;
	}
	
	public static function order_payments(): void {
		self::guard( 'view' );
		$raw = self::input();
		$order = KERP_Modules_Orders_Query::instance()->get_order( absint( $raw['order_id'] ?? 0 ) );
		if ( ! $order ) { self::error( 'سفارش پیدا نشد یا به آن دسترسی ندارید.' ); }
		$result = KERP_Modules_Payments_Store::find( [ 'order_id' => $order->get_id(), 'per_page' => 10, 'page_number' => absint( $raw['page_number'] ?? 1 ) ] );
		$html = KERP_Helpers_Template::get_template( 'modules/payments/order-popup.php', compact( 'order', 'result' ) );
		wp_send_json( [ 'status' => 'success', 'html' => $html ] );
	}
	public static function order_payment_form(): void {
		self::guard( 'create' ); self::guard( 'view' );
		$order = KERP_Modules_Orders_Query::instance()->get_order( absint( self::input()['order_id'] ?? 0 ) );
		if ( ! $order ) { self::error( 'سفارش پیدا نشد یا به آن دسترسی ندارید.' ); }
		if ( KERP_Modules_Payments_Proforma::is_draft( $order ) ) {
			$details = KERP_Modules_Payments_Proforma::details( $order );
			if ( is_wp_error( $details ) ) { self::error( $details->get_error_message() ); }
			$html = KERP_Helpers_Template::get_template( 'modules/payments/proforma-start.php', compact( 'order', 'details' ) );
			wp_send_json( [ 'status' => 'success', 'html' => $html ] ); return;
		}
		$html = KERP_Helpers_Template::get_template( 'modules/payments/order-summary.php', [ 'order' => $order, 'modals_only' => TRUE, 'body_only' => TRUE, 'target_payment_order_id' => ( $order->get_meta( '_kerp_installment_is_parent' ) || $order->get_meta( '_kerp_deposit_orders' ) ) ? 0 : $order->get_id() ] );
		if ( trim( $html ) === '' ) { self::error( 'قسط قابل پرداختی وجود ندارد یا پرداخت فعلی در حال بررسی است.' ); }
		wp_send_json( [ 'status' => 'success', 'html' => $html ] );
	}

	public static function save_settings(): void {
		self::guard( 'manage_settings' );
		$raw = self::input();
		$result = KERP_Modules_Payments_Settings::save( (array) ( $raw['methods'] ?? [] ), isset( $raw['cash_sms'] ) ? (array) $raw['cash_sms'] : NULL );
		if ( is_wp_error( $result ) ) {
			self::error( $result->get_error_message() );
		}
		$active_tab = KERP_Modules_Payments_Settings::text( $raw, 'active_tab' );
		if ( ! in_array( $active_tab, array_merge( [ 'cash' ], array_keys( KERP_Modules_Payments_Settings::labels() ) ), TRUE ) ) { $active_tab = 'card'; }
		self::success( 'تنظیمات پرداخت ذخیره شد.', '/erp/settings/payments/?tab=' . $active_tab );
	}

	public static function send_sms(): void {
		self::guard( 'create' );
		self::guard( 'view' );
		$order = KERP_Modules_Orders_Query::instance()->get_order( absint( self::input()['order_id'] ?? 0 ) );
		if ( ! $order ) { self::error( 'سفارش پیدا نشد یا به آن دسترسی ندارید.' ); }
		$result = KERP_Modules_Payments_SMS::send( $order );
		if ( is_wp_error( $result ) ) { self::error( $result->get_error_message() ); }
		wp_send_json( [ 'status' => 'success', 'message' => 'پیامک لینک پرداخت برای مشتری ارسال شد.' ] );
	}
	
	public static function upload(): void {
		self::guard( 'create', TRUE );
		$file = $_FILES['file'] ?? NULL;
		if ( ! is_array( $file ) ) {
			self::error( 'فایل ارسال نشده است.' );
		}
		$result = KERP_Helpers_File::instance()
		                           ->handle_upload_file( $file, 'kerp-payment-receipts/' . get_current_user_id(), $_POST );
		if ( empty( $result['ok'] ) ) {
			self::error( $result['msg'] ?? 'بارگذاری ناموفق بود.' );
		}
		set_transient( 'kerp_payment_upload_' . hash( 'sha256', $result['url'] ), get_current_user_id(), 7 * DAY_IN_SECONDS );
		wp_send_json( [ 'status' => 'success', 'url' => $result['url'] ] );
	}
	
	public static function preview(): void {
		self::guard( 'create', TRUE );
		$raw      = self::input();
		$customer = absint( $raw['customer_id'] ?? 0 );
		if ( ! KERP_Modules_Payments_Service::customer( $customer, absint( $raw['order_id'] ?? 0 ) === 0 && absint( $raw['payment_order_id'] ?? 0 ) === 0 ) ) {
			self::error( 'ابتدا کاربر را انتخاب کنید.' );
		}
		$items = array_values( array_filter( (array) ( $raw['items'] ?? [] ), static fn( $r ) => is_array( $r ) && ! empty( $r['product_id'] ) ) );
		$plans = [];
		if ( count( $items ) === 1 && KERP_Modules::instance()->is_module_loaded( 'installment_management' ) ) {
			foreach ( KERP_Modules_Installment_Management_Settings::all() as $id => $plan ) {
				if ( ! empty( $plan['enabled'] ) && (int) $plan['product_id'] === absint( $items[0]['product_id'] ) ) {
					$plans[] = [ 'id' => (string) $id, 'text' => $plan['name'] ];
				}
			}
		}
		$rows  = [];
		$error = '';
		if ( KERP_Modules_Payments_Settings::text( $raw, 'payment_type' ) === 'installment' ) {
			$result = KERP_Modules_Payments_Service::installment( $raw );
			if ( is_wp_error( $result ) ) {
				$error = $result->get_error_message();
			} else {
				$product = wc_get_product( $result['plan']['product_id'] );
				$rates   = $product->is_taxable() && wc_tax_enabled() ? WC_Tax::get_rates( $product->get_tax_class(), new WC_Customer( $customer ) ) : [];
				foreach ( KERP_Modules_Installment_Management_Service::split( $result['total'], $result['plan']['steps'], wc_get_price_decimals() ) as $i => $amount ) {
					$amount += array_sum( array_map( 'wc_round_tax_total', WC_Tax::calc_tax( $amount, $rates, FALSE ) ) );
					$rows[] = [
						'stage'  => $i + 1,
						'amount' => $amount,
						'date'   => gmdate( 'c', time() + (int) $result['plan']['steps'][ $i ]['days'] * DAY_IN_SECONDS ),
						'days'   => (int) $result['plan']['steps'][ $i ]['days'],
					];
				}
			}
		}
		wp_send_json( [
			'status'   => 'success',
			'plans'    => $plans,
			'schedule' => $rows,
			'error'    => $error,
			'currency' => get_woocommerce_currency_symbol(),
		] );
	}
	
	public static function create_order(): void {
		if ( ( self::input()['registration_mode'] ?? '' ) === 'proforma' ) { self::save_proforma(); return; }
		if ( KERP_Modules_Payments_Settings::text( self::input(), 'payment_method' ) === 'kerp_none' ) { self::save_without_payment(); return; }
		self::save_payment( TRUE );
	}

	private static function new_order_data( array $raw ): array {
		$data = [
			'customer_id' => absint( $raw['customer_id'] ?? 0 ),
			'items' => (array) ( $raw['items'] ?? [] ),
			'extra' => map_deep( (array) ( $raw['extra'] ?? [] ), 'sanitize_text_field' ),
		];
		foreach ( [ 'order_date', 'shipping_title', 'shipping_total', 'coupon_code', 'custom_extra_fee', 'custom_fee', 'order_files' ] as $key ) {
			$data[ $key ] = KERP_Modules_Payments_Settings::text( $raw, $key );
		}
		$data['cashier_note'] = wp_kses_post( KERP_Modules_Payments_Settings::text( $raw, 'cashier_note' ) );
		$data['_kerp_payment_flow'] = TRUE;
		$data = apply_filters( 'kerp_orders_api_save_data', $data, $raw, 0 );
		$data['_kerp_payment_flow'] = TRUE;
		return $data;
	}

	private static function save_without_payment(): void {
		self::guard( 'create', TRUE );
		$raw = self::input();
		if ( ! kerp_can( 'orders.create', 'action' ) || absint( $raw['order_id'] ?? 0 ) > 0 ) {
			self::error( 'این عملیات فقط برای ثبت سفارش جدید مجاز است.' );
		}
		$customer = absint( $raw['customer_id'] ?? 0 );
		if ( ! KERP_Modules_Payments_Service::customer( $customer, TRUE ) ) { self::error( 'مشتری در محدوده دسترسی شما نیست.' ); }
		$request = KERP_Modules_Payments_Settings::text( $raw, 'payment_request' );
		if ( ! wp_is_uuid( $request ) ) { self::error( 'شناسه درخواست نامعتبر است.' ); }
		$lock = 'request_' . $request;
		if ( ! KERP_Modules_Payments_Store::lock( $lock ) ) { self::error( 'درخواست در حال پردازش است.' ); }
		$error = '';
		$id = 0;
		try {
			global $wpdb;
			if ( $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . KERP_Modules_Payments_Store::table() . ' WHERE request_id=%s', $request ) )
				|| wc_get_orders( [ 'limit' => 1, 'return' => 'ids', 'meta_query' => [ [ 'key' => '_kerp_proforma_request', 'value' => $request ] ] ] ) ) {
				throw new RuntimeException( 'این درخواست قبلاً استفاده شده است؛ صفحه سفارش را تازه کنید.' );
			}
			$prior = wc_get_orders( [ 'limit' => 1, 'meta_query' => [ [ 'key' => '_kerp_no_payment_request', 'value' => $request ] ] ] );
			if ( $prior ) {
				$order = reset( $prior );
				if ( (int) $order->get_meta( 'marketer_id' ) !== get_current_user_id() || $order->get_customer_id() !== $customer || ! $order->has_status( 'completed' ) ) {
					throw new RuntimeException( 'این درخواست قبلاً استفاده شده است؛ صفحه سفارش را تازه کنید.' );
				}
				$id = $order->get_id();
			} else {
				$data = self::new_order_data( $raw );
				$data['_kerp_no_payment_request'] = $request;
				$result = KERP_Modules_Orders_Module::instance()->save( $data, 0, $raw );
				if ( is_wp_error( $result ) ) { throw new RuntimeException( $result->get_error_message() ); }
				$id = (int) $result;
			}
		} catch ( Throwable $e ) { $error = $e->getMessage(); }
		finally { KERP_Modules_Payments_Store::unlock( $lock ); }
		if ( $error !== '' ) { self::error( $error ); }
		self::success( 'سفارش بدون شیوه پرداخت ثبت و تکمیل شد.', KERP_Modules_Orders_Module::instance()->get_save_return_url( $id, TRUE ) );
	}
	
	public static function save_proforma(): void {
		self::guard( 'create', absint( self::input()['order_id'] ?? 0 ) === 0 );
		$result = KERP_Modules_Payments_Proforma::save( self::input() );
			if ( is_wp_error( $result ) ) { self::error( $result->get_error_message() ); }
		self::success( 'پیش‌فاکتور بدون ثبت پرداخت ذخیره شد.', KERP_Modules_Orders_Module::instance()->get_save_return_url( (int) $result, TRUE ) );
	}

	public static function submit(): void {
		self::save_payment( FALSE );
	}
	
	private static function save_payment( bool $new ): void {
		self::guard( 'create', $new );
		$raw = self::input();
		if ( $new && ! kerp_can( 'orders.create', 'action' ) ) {
			self::error( 'مجوز ثبت سفارش ندارید.' );
		}
		$method = KERP_Modules_Payments_Settings::text( $raw, 'payment_method' );
		if ( ! isset( KERP_Modules_Payments_Settings::methods()[ $method ] ) ) {
			self::error( 'روش پرداخت فعال را انتخاب کنید.' );
		}
		$receipt = KERP_Modules_Payments_Service::rows( $method, $raw );
		if ( is_wp_error( $receipt ) ) {
			self::error( $receipt->get_error_message() );
		}
		$receipt = KERP_Modules_Payments_Cheques::initial( $receipt, $method );
		$request = KERP_Modules_Payments_Settings::text( $raw, 'payment_request' );
		if ( ! wp_is_uuid( $request ) ) {
			self::error( 'شناسه درخواست نامعتبر است.' );
		}
		$customer    = absint( $raw['customer_id'] ?? 0 );
		$order       = NULL;
		$installment = NULL;
		if ( $new ) {
			if ( ! KERP_Modules_Payments_Service::customer( $customer, TRUE ) ) {
				self::error( 'مشتری در محدوده دسترسی شما نیست.' );
			}
			$type = KERP_Modules_Payments_Settings::text( $raw, 'payment_type' );
			if ( ! in_array( $type, [ 'cash', 'installment', 'deposit' ], TRUE ) ) {
				self::error( 'نوع پرداخت را مشخص کنید.' );
			}
			if ( $type === 'deposit' ) {
				$advance = KERP_Modules_Payments_Service::number( $raw['deposit_amount'] ?? 0 );
				if ( $advance <= 0 ) { self::error( 'مبلغ پیش‌پرداخت را وارد کنید.' ); }
				if ( $receipt['rows'] && abs( array_sum( array_column( $receipt['rows'], 'amount' ) ) - $advance ) > pow( 10, -wc_get_price_decimals() ) / 2 ) { self::error( 'جمع رسیدها باید برابر مبلغ پیش‌پرداخت باشد.' ); }
			}
			if ( $type === 'installment' ) {
				$installment = KERP_Modules_Payments_Service::installment( $raw );
				if ( is_wp_error( $installment ) ) {
					self::error( $installment->get_error_message() );
				}
			}
		} else {
			$order = KERP_Modules_Orders_Query::instance()->get_order( absint( $raw['payment_order_id'] ?? 0 ) );
			if ( ! $order ) {
				self::error( 'سفارش در محدوده دسترسی شما نیست.' );
			}
			$customer = $order->get_customer_id();
		}
		$lock = $new ? 'request_' . $request : 'order_' . $order->get_id();
		if ( ! KERP_Modules_Payments_Store::lock( $lock ) ) {
			self::error( 'درخواست در حال پردازش است.' );
		}
		global $wpdb;
		$error      = '';
		$payment_id = 0;
		$target     = 0;
		$replaced_payment = 0;
		try {
			if ( $new && wc_get_orders( [ 'limit' => 1, 'return' => 'ids', 'meta_query' => [ [ 'key' => '_kerp_no_payment_request', 'value' => $request ] ] ] ) ) {
				throw new RuntimeException( 'این درخواست قبلاً بدون شیوه پرداخت ثبت شده است؛ صفحه سفارش را تازه کنید.' );
			}
			if ( $new && wc_get_orders( [ 'limit' => 1, 'return' => 'ids', 'meta_query' => [ [ 'key' => '_kerp_proforma_request', 'value' => $request ] ] ] ) ) {
				throw new RuntimeException( 'این درخواست به‌صورت پیش‌فاکتور ذخیره شده است؛ پرداخت را از همان سفارش شروع کنید.' );
			}
			$existing = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . KERP_Modules_Payments_Store::table() . ' WHERE request_id=%s', $request ), ARRAY_A );
			if ( $existing ) {
				if ( (int) $existing['created_by'] !== get_current_user_id() || (int) $existing['customer_id'] !== $customer ) {
					throw new RuntimeException( 'شناسه درخواست قبلاً استفاده شده است.' );
				}
				if ( ! $new && (int) $existing['order_id'] !== $order->get_id()
					&& ! ( ( $order->get_meta( '_kerp_deposit_orders' ) || ( $order->get_meta( '_kerp_proforma' ) && $order->get_meta( '_kerp_installment_is_parent' ) ) )
						&& KERP_Modules_Installment_Management_Service::main_order_id( (int) $existing['order_id'] ) === $order->get_id() ) ) {
					throw new RuntimeException( 'شناسه درخواست مربوط به سفارش دیگری است.' );
				}
				// A completed failure is retryable under the same lock and request ID.
				// Reuse its ledger row; successful or interrupted requests must never create another order.
				if ( $existing['status'] === 'failed' && ( ! $new || ! (int) $existing['order_id'] ) ) {
					$payment_id = (int) $existing['id'];
					$previous_payload = json_decode( (string) $existing['payload'], TRUE ) ?: [];
					$receipt['previous_errors'] = (array) ( $previous_payload['previous_errors'] ?? [] );
					if ( ! empty( $previous_payload['error'] ) ) { $receipt['previous_errors'][] = $previous_payload['error']; }
					$existing = NULL;
				}
			}
			if ( $existing ) {
				$target = (int) $existing['order_id'];
				if ( ! $target || $existing['status'] === 'building' ) {
					throw new RuntimeException( 'ثبت قبلی نیازمند بررسی است؛ از فهرست پرداخت‌ها پیگیری کنید.' );
				}
				if ( $existing['status'] === 'failed' ) { $error = 'تلاش قبلی برای ثبت پرداخت ناموفق بود.'; }
			} else {
				if ( $order ) {
					$order = wc_get_order( $order->get_id() );
					if ( $order && $order->get_meta( '_kerp_deposit_amount' ) ) {
						$order = KERP_Modules_Payments_Deposit::create( $order, $order->get_meta( '_kerp_deposit_amount' ) );
						if ( is_wp_error( $order ) ) { throw new RuntimeException( $order->get_error_message() ); }
					}
					// A retry after contract creation must continue its first invoice, not create a second contract.
					if ( $order && $order->get_meta( '_kerp_proforma' ) && $order->get_meta( '_kerp_installment_is_parent' ) ) {
						$contract = KERP_Modules_Installment_Management_Store::get( (int) $order->get_meta( '_kerp_installment_contract' ) );
						if ( $contract && $contract['status'] === 'active' ) { $order = wc_get_order( $contract['orders'][0] ); }
					}
					if ( KERP_Modules_Payments_Proforma::is_draft( $order ) ) {
						$order = KERP_Modules_Payments_Proforma::activate( $order, $request, $receipt );
						if ( is_wp_error( $order ) ) { throw new RuntimeException( $order->get_error_message() ); }
					}
					if ( ! $order || $order->is_paid() || ! $order->has_status( [ 'pending', 'failed', 'finance-review' ] ) || (float) $order->get_total() <= 0 ) {
						throw new RuntimeException( 'فقط سفارش پرداخت‌نشده قابل تغییر است.' );
					}
					if ( $receipt['rows'] && abs( array_sum( array_column( $receipt['rows'], 'amount' ) ) - (float) $order->get_total() ) > pow( 10, -wc_get_price_decimals() ) / 2 ) {
						throw new RuntimeException( 'جمع مبالغ رسیدها باید برابر مبلغ قابل پرداخت باشد.' );
					}
					$pending = $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . KERP_Modules_Payments_Store::table() . " WHERE order_id=%d AND status IN ('review','pending','building') LIMIT 1", $order->get_id() ) );
					if ( $pending ) {
						$previous = KERP_Modules_Payments_Store::get( (int) $pending );
						if ( $previous && KERP_Modules_Payments_Cheques::replacement_blocked( $previous ) ) { throw new RuntimeException( 'بخشی از سند وصول شده یا اصل چک دریافت شده است؛ تغییر روش پرداخت این سند مجاز نیست.' ); }
						if ( ! kerp_can( 'orders.edit', 'action' ) || (int) ( $raw['replace_payment_id'] ?? 0 ) !== (int) $pending
							|| (int) $order->get_meta( '_kerp_payment_id' ) !== (int) $pending || ! $previous
							|| ! in_array( $previous['status'], [ 'pending', 'review' ], TRUE ) ) {
							throw new RuntimeException( 'پرداخت سفارش تغییر کرده است؛ صفحه را تازه کنید و دوباره اقدام کنید.' );
						}
						$replaced_payment = (int) $pending;
					}
				}
				$payment_data = [
					'request_id'  => $request,
					'order_id'    => $order ? $order->get_id() : 0,
					'customer_id' => $customer,
					'created_by'  => get_current_user_id(),
					'method'      => $method,
					'currency'    => get_woocommerce_currency(),
					'status'      => 'building',
					'payload'     => wp_json_encode( $receipt ),
					'created_at'  => current_time( 'mysql', TRUE ),
				];
				if ( $payment_id ) {
					unset( $payment_data['created_at'] );
					$ok = KERP_Modules_Payments_Store::update( $payment_id, $payment_data );
				} else { $ok = $wpdb->insert( KERP_Modules_Payments_Store::table(), $payment_data ); }
				if ( ! $ok ) {
					throw new RuntimeException( 'ثبت اولیه سند پرداخت ناموفق بود.' );
				}
				$payment_id = $payment_id ?: (int) $wpdb->insert_id;
				if ( $new && $installment ) {
					$contract = KERP_Modules_Installment_Management_Service::create( $customer, $installment['id'], $request, $installment['total'], $raw );
					if ( is_wp_error( $contract ) ) {
						throw new RuntimeException( $contract->get_error_message() );
					}
					$order = wc_get_order( $contract['orders'][0] );
				} elseif ( $new ) {
					$data = self::new_order_data( $raw );
					$id                         = KERP_Modules_Orders_Module::instance()->save( $data, 0, $raw );
					if ( is_wp_error( $id ) ) {
						throw new RuntimeException( $id->get_error_message() );
					}
					$order = wc_get_order( $id );
				}
				$target = $order->get_id();
				KERP_Modules_Payments_Store::update( $payment_id, [ 'order_id' => $target ] );
				if ( $new && $type === 'deposit' ) {
					$part = KERP_Modules_Payments_Deposit::create( $order, $raw['deposit_amount'] ?? 0 );
					if ( is_wp_error( $part ) ) { throw new RuntimeException( $part->get_error_message() ); }
					$order = $part;
				}
				KERP_Modules_Payments_Store::update( $payment_id, [ 'order_id' => $order->get_id() ] );
				$result = KERP_Modules_Payments_Service::attach( $payment_id, $order, $method, $receipt );
				if ( is_wp_error( $result ) ) {
					throw new RuntimeException( $result->get_error_message() );
				}
				if ( $replaced_payment ) {
					KERP_Modules_Payments_Store::update( $replaced_payment, [ 'status' => 'superseded' ] );
					$order->add_order_note( 'شیوه پرداخت تغییر کرد؛ سند #' . $replaced_payment . ' با سند #' . $payment_id . ' جایگزین شد.' );
				}
			}
		}
		catch ( Throwable $e ) {
			$error = $e->getMessage();
			if ( $payment_id ) {
				$receipt['error'] = $error;
				KERP_Modules_Payments_Store::update( $payment_id, [
					'status'  => 'failed',
					'payload' => wp_json_encode( $receipt ),
				] );
			}
		}
		finally {
			KERP_Modules_Payments_Store::unlock( $lock );
		}
		if ( $payment_id && $error === '' ) { KERP_Modules_Payments_Cheques_Notifications::process( $payment_id ); }
		if ( $replaced_payment && $error === '' ) { KERP_Modules_Payments_Cheques_Notifications::process( $replaced_payment ); }
		if ( $error !== '' && ! $target ) {
			self::error( $error );
		}
		$target = KERP_Modules_Installment_Management_Service::main_order_id( $target );
		$page = KERP_Modules_Orders_Module::instance()->get_save_return_url( $target, TRUE );
		$retry_message = $page === '/erp/orders/' . $target . '/edit/'
			? ' از همین صفحه پرداخت را دوباره ثبت کنید.'
			: ' برای پیگیری پرداخت سفارش #' . $target . ' با مسئول مجاز تماس بگیرید؛ سفارش جدید ثبت نکنید.';
		self::success( $error !== '' ? 'سفارش ثبت شد اما پرداخت ثبت نشد: ' . $error . $retry_message : 'سفارش و درخواست پرداخت ثبت شد.', $page );
	}
	
	public static function review(): void {
		self::guard( 'approve' );
		$raw      = self::input();
		$ids      = array_unique( array_filter( array_map( 'absint', explode( ',', KERP_Modules_Payments_Settings::text( $raw, 'payment_ids' ) ) ) ) );
		$decision = KERP_Modules_Payments_Settings::text( $raw, 'decision' );
		$note     = KERP_Modules_Payments_Settings::text( $raw, 'note' );
		if ( ! $ids || count( $ids ) > 50 || ! in_array( $decision, [ 'approve', 'reject' ], TRUE ) || $note === '' ) {
			self::error( 'پرداخت، تصمیم و توضیح بررسی را مشخص کنید.' );
		}
		$errors = [];
		$count  = 0;
		foreach ( $ids as $id ) {
			$p     = KERP_Modules_Payments_Store::get( $id );
			$order = $p ? KERP_Modules_Orders_Query::instance()->get_order( (int) $p['order_id'] ) : NULL;
			if ( ! $order || $p['status'] !== 'review' || ( $decision === 'approve' && $p['status'] !== 'review' ) ) {
				$errors[] = '#' . $id . ': وضعیت یا دسترسی معتبر نیست.';
				continue;
			}
			$lock = 'order_' . $order->get_id();
			if ( ! KERP_Modules_Payments_Store::lock( $lock ) ) {
				$errors[] = '#' . $id . ': در حال پردازش.';
				continue;
			}
			try {
				$p     = KERP_Modules_Payments_Store::get( $id );
				$order = wc_get_order( (int) $p['order_id'] );
				if ( $p['status'] !== 'review' || $order->is_paid() || (float) $order->get_total_refunded() > 0 || ! $order->has_status( [
						'finance-review',
						'pending',
					] ) || (int) $order->get_meta( '_kerp_payment_id' ) !== $id || (int) $order->get_customer_id() !== (int) $p['customer_id'] || $order->get_currency() !== $p['currency'] || abs( (float) $order->get_total() - (float) $p['amount'] ) > 0.000001 ) {
					throw new RuntimeException( 'مشخصات یا وضعیت سفارش تغییر کرده است.' );
				}
				if ( ! KERP_Modules_Payments_Deposit::payable( $order ) ) { throw new RuntimeException( 'ساختار یا وضعیت سفارش پیش‌پرداخت معتبر نیست.' ); }
				$payload                = json_decode( $p['payload'], TRUE ) ?: [];
				if ( ! empty( $payload['cheque_flow'] ) ) { throw new RuntimeException( 'هر چک را از جزئیات سند و مراحل اختصاصی آن بررسی کنید.' ); }
				$payload['review_note'] = $note;
				$payload['reviewed_at'] = time();
				if ( ! KERP_Modules_Payments_Store::update( $id, [
					'payload'     => wp_json_encode( $payload ),
					'reviewed_by' => get_current_user_id(),
					'status'      => $decision === 'approve' ? 'review' : 'rejected',
				] ) ) {
					throw new RuntimeException( 'ثبت نتیجه بررسی ناموفق بود.' );
				}
				$order->add_order_note( 'بررسی مالی توسط #' . get_current_user_id() . ': ' . $note );
				if ( $decision === 'approve' ) {
					$order->payment_complete();
					KERP_Modules_Payments_Service::changed( $order->get_id() );
				} else {
					$order->delete_meta_data( '_kerp_payment_gateway' );
					$order->delete_meta_data( '_kerp_payment_id' );
					$order->save();
					$order->update_status( 'pending', 'پرداخت رد شد؛ امکان ثبت مجدد پرداخت وجود دارد.' );
				}
				$count ++;
			}
			catch ( Throwable $e ) {
				$errors[] = '#' . $id . ': ' . $e->getMessage();
			}
			finally {
				KERP_Modules_Payments_Store::unlock( $lock );
			}
		}
		self::success( 'تعداد بررسی‌شده: ' . $count . ( $errors ? '؛ ' . implode( ' / ', $errors ) : '' ), '/erp/payments/' );
	}
	
}
