<?php
defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Payments_SMS {
	public static function variables(): array {
		return [ '{payment_url}', '{customer_name}', '{first_name}', '{last_name}', '{order_id}', '{order_number}', '{amount}', '{currency}', '{site_name}' ];
	}

	public static function configured(): bool {
		$settings = KERP_Modules_Payments_Settings::cash_sms();
		return $settings['enabled'] === '1' && $settings['pattern'] !== '' && str_contains( $settings['variables'], '{payment_url}' );
	}

	public static function send( WC_Order $order ): bool|WP_Error {
		if ( ! self::configured() ) { return new WP_Error( 'settings', 'ابتدا پیامک لینک پرداخت را در تنظیمات پرداخت، تب نقدی، فعال و تنظیم کنید.' ); }
		if ( ! class_exists( 'kasebiSMS' ) || ! method_exists( 'kasebiSMS', 'send_pattern_sms' ) ) { return new WP_Error( 'service', 'سرویس پیامک در دسترس نیست.' ); }
		$lock = 'order_' . $order->get_id();
		if ( ! KERP_Modules_Payments_Store::lock( $lock ) ) { return new WP_Error( 'busy', 'درخواست در حال پردازش است؛ کمی بعد دوباره تلاش کنید.' ); }
		try {
			$order = wc_get_order( $order->get_id() );
			$row = $order ? KERP_Modules_Payments_Store::get( (int) $order->get_meta( '_kerp_payment_id' ) ) : NULL;
			if ( ! $order || ! $row || $row['status'] !== 'pending' || (int) $row['order_id'] !== $order->get_id() || (int) $row['customer_id'] !== $order->get_customer_id() || $row['method'] !== $order->get_meta( '_kerp_payment_gateway' ) || $row['currency'] !== $order->get_currency() || abs( (float) $row['amount'] - (float) $order->get_total() ) > 0.000001 || $order->is_paid() || ! $order->needs_payment() || (float) $order->get_total_refunded() > 0 ) {
				return new WP_Error( 'payment', 'لینک پرداخت فعال و قابل پرداختی برای این سفارش وجود ندارد.' );
			}
			if ( (int) $order->get_meta( '_kerp_payment_sms_attempt' ) > time() - 60 ) { return new WP_Error( 'recent', 'ارسال پیامک اخیراً انجام شده است؛ برای ارسال دوباره یک دقیقه صبر کنید.' ); }
			$raw_phone = get_user_meta( $order->get_customer_id(), 'nooshika_phone_num', TRUE ) ?: $order->get_billing_phone();
			$phone = is_scalar( $raw_phone ) ? preg_replace( '/[\s()+-]/u', '', KERP_Helpers_Format::sanitize_numbers( (string) $raw_phone ) ) : '';
			$phone = preg_replace( '/^(?:0098|98|0)(?=9\d{9}$)/', '', $phone );
			if ( ! preg_match( '/^9\d{9}$/D', $phone ) ) { return new WP_Error( 'phone', 'شماره موبایل معتبر برای مشتری ثبت نشده است.' ); }
			$settings = KERP_Modules_Payments_Settings::cash_sms();
			$variables = KERP_Modules_Payments_Settings::sms_variables( $settings['variables'] );
			if ( is_wp_error( $variables ) ) { return $variables; }
			$user = get_userdata( $order->get_customer_id() );
			$context = [ '{payment_url}' => $order->get_checkout_payment_url(), '{customer_name}' => $user ? $user->display_name : $order->get_formatted_billing_full_name(), '{first_name}' => $order->get_billing_first_name(), '{last_name}' => $order->get_billing_last_name(), '{order_id}' => (string) $order->get_id(), '{order_number}' => (string) $order->get_order_number(), '{amount}' => (string) $order->get_total(), '{currency}' => $order->get_currency(), '{site_name}' => get_bloginfo( 'name' ) ];
			$payload = [ 'receptor' => $phone, 'pattern' => $settings['pattern'] ];
			foreach ( $variables as $key => $value ) {
				$resolved = strtr( $value, $context );
				// Preserve the URL and its WooCommerce order key exactly.
				$payload[ $key ] = str_contains( $value, '{payment_url}' ) ? $resolved : str_replace( [ ' ', '_' ], '-', $resolved );
			}
			$order->update_meta_data( '_kerp_payment_sms_attempt', time() );
			$order->save();
			$response = ( new kasebiSMS() )->send_pattern_sms( $payload );
			$status = self::delivery_status( $response );
			if ( $status !== 'sent' ) { return new WP_Error( 'delivery', $status === 'failed' ? 'ارسال پیامک ناموفق بود؛ تنظیمات سرویس و پترن را بررسی کنید.' : 'سرویس پیامک نتیجه قطعی برنگرداند؛ پیش از ارسال مجدد، گزارش سرویس را بررسی کنید.' ); }
			$order->add_order_note( 'پیامک لینک پرداخت توسط کاربر #' . get_current_user_id() . ' ارسال شد.' );
			return TRUE;
		} catch ( Throwable $error ) {
			return new WP_Error( 'sms', 'ارسال پیامک کامل نشد؛ گزارش سرویس پیامک را بررسی کنید.' );
		} finally { KERP_Modules_Payments_Store::unlock( $lock ); }
	}

	public static function delivery_status( mixed $response ): string {
		if ( is_wp_error( $response ) || $response === FALSE || $response === 'no gateway selected' ) { return 'failed'; }
		if ( $response === TRUE ) { return 'sent'; }
		$data = is_object( $response ) ? get_object_vars( $response ) : $response;
		if ( ! is_array( $data ) ) { return 'unknown'; }
		if ( ! empty( $data['error'] ) || ! empty( $data['errors'] ) ) { return 'failed'; }
		foreach ( [ 'success', 'ok' ] as $key ) {
			if ( array_key_exists( $key, $data ) ) { return in_array( $data[ $key ], [ TRUE, 1, '1', 'true' ], TRUE ) ? 'sent' : 'failed'; }
		}
		if ( isset( $data['status'] ) && is_scalar( $data['status'] ) ) {
			$status = strtolower( (string) $data['status'] );
			return in_array( $status, [ 'ok', 'success', '1', '200', '201', '202' ], TRUE ) ? 'sent' : 'failed';
		}
		return 'unknown';
	}
}
