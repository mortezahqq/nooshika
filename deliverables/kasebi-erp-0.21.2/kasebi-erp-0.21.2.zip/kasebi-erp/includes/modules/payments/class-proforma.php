<?php
defined( 'ABSPATH' ) || exit;

/** A quotation stores intent only; payment initiation owns all financial side effects. */
final class KERP_Modules_Payments_Proforma {
	public static function is_draft( $order ): bool {
		return $order instanceof WC_Order && $order->has_status( 'pre-invoice' ) && ! $order->is_paid() && (bool) $order->get_meta( '_kerp_proforma' );
	}
	public static function save( array $raw ): int|WP_Error {
		$id = absint( $raw['order_id'] ?? 0 );
		if ( ! kerp_can( $id ? 'orders.edit' : 'orders.create', 'action' ) ) { return new WP_Error( 'permission', 'مجوز ذخیره سفارش ندارید.' ); }
		$customer = absint( $raw['customer_id'] ?? 0 );
		if ( ! KERP_Modules_Payments_Service::customer( $customer, $id === 0 ) ) { return new WP_Error( 'customer', 'مشتری در محدوده دسترسی شما نیست.' ); }
		$request = KERP_Modules_Payments_Settings::text( $raw, 'payment_request' );
		$type = KERP_Modules_Payments_Settings::text( $raw, 'payment_type' );
		if ( ! wp_is_uuid( $request ) || ! in_array( $type, [ 'cash', 'installment', 'deposit' ], TRUE ) ) { return new WP_Error( 'input', 'نوع پرداخت یا شناسه درخواست معتبر نیست.' ); }
		if ( $type === 'deposit' && KERP_Modules_Payments_Service::number( $raw['deposit_amount'] ?? 0 ) <= 0 ) { return new WP_Error( 'deposit', 'مبلغ پیش‌پرداخت را وارد کنید.' ); }
		if ( $type === 'installment' ) {
			$plan = KERP_Modules_Payments_Service::installment( $raw );
			if ( is_wp_error( $plan ) ) { return $plan; }
		}
		$lock = $id ? 'order_' . $id : 'request_' . $request;
		if ( ! KERP_Modules_Payments_Store::lock( $lock ) ) { return new WP_Error( 'busy', 'درخواست در حال پردازش است.' ); }
		try {
			if ( $id ) {
				$order = KERP_Modules_Orders_Query::instance()->get_order( $id );
				if ( ! self::is_draft( $order ) || $order->get_meta( '_kerp_payment_id' ) || $order->get_meta( '_kerp_installment_contract' ) ) { throw new RuntimeException( 'پیش‌فاکتور تغییر کرده است؛ صفحه را تازه کنید.' ); }
			} else {
				global $wpdb;
				if ( wc_get_orders( [ 'limit' => 1, 'return' => 'ids', 'meta_query' => [ [ 'key' => '_kerp_no_payment_request', 'value' => $request ] ] ] ) ) { throw new RuntimeException( 'این درخواست قبلاً بدون شیوه پرداخت ثبت شده است؛ صفحه سفارش را تازه کنید.' ); }
				if ( $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . KERP_Modules_Payments_Store::table() . ' WHERE request_id=%s', $request ) ) ) { throw new RuntimeException( 'این درخواست قبلاً برای پرداخت استفاده شده است؛ صفحه سفارش را تازه کنید.' ); }
				$prior = wc_get_orders( [ 'limit' => 1, 'meta_query' => [ [ 'key' => '_kerp_proforma_request', 'value' => $request ] ] ] );
				if ( $prior ) {
					$order = reset( $prior );
					if ( (int) $order->get_meta( 'marketer_id' ) !== get_current_user_id() || $order->get_customer_id() !== $customer ) { throw new RuntimeException( 'شناسه درخواست قبلاً استفاده شده است.' ); }
					return $order->get_id();
				}
			}
			$data = [ 'customer_id' => $customer, 'items' => (array) ( $raw['items'] ?? [] ), 'extra' => map_deep( (array) ( $raw['extra'] ?? [] ), 'sanitize_text_field' ) ];
			foreach ( [ 'order_date', 'shipping_title', 'shipping_total', 'coupon_code', 'custom_extra_fee', 'custom_fee', 'order_files' ] as $key ) { $data[$key] = KERP_Modules_Payments_Settings::text( $raw, $key ); }
			$data['cashier_note'] = wp_kses_post( KERP_Modules_Payments_Settings::text( $raw, 'cashier_note' ) );
			$data = apply_filters( 'kerp_orders_api_save_data', $data, $raw, $id );
			$data['_kerp_proforma'] = [ 'type' => $type, 'plan' => $type === 'installment' ? $plan['id'] : '', 'request' => $request, 'deposit_amount' => $type === 'deposit' ? KERP_Modules_Payments_Service::number( $raw['deposit_amount'] ?? 0 ) : 0 ];
			return KERP_Modules_Orders_Module::instance()->save( $data, $id, $raw );
		} catch ( Throwable $e ) { return new WP_Error( 'proforma', $e->getMessage() ); }
		finally { KERP_Modules_Payments_Store::unlock( $lock ); }
	}
	/** Always rebuild amounts from the saved order, never the modal payload. */
	public static function details( WC_Order $order ): array|WP_Error {
		$intent = (array) $order->get_meta( '_kerp_proforma' );
		if ( $order->get_currency() !== get_woocommerce_currency() || (float) $order->get_total() <= 0 ) { return new WP_Error( 'amount', 'مبلغ یا واحد پول پیش‌فاکتور معتبر نیست.' ); }
		if ( ( $intent['type'] ?? '' ) === 'deposit' ) {
			$amount = KERP_Modules_Payments_Deposit::amount( $intent['deposit_amount'] ?? 0, (float) $order->get_total() );
			return is_wp_error( $amount ) ? $amount : [ 'amount' => $amount, 'installment' => NULL, 'deposit' => TRUE ];
		}
		if ( ( $intent['type'] ?? '' ) !== 'installment' ) { return [ 'amount' => (float) $order->get_total(), 'installment' => NULL ]; }
		$items = [];
		foreach ( $order->get_items() as $item ) { $items[] = [ 'product_id' => $item->get_variation_id() ?: $item->get_product_id(), 'quantity' => $item->get_quantity(), 'line_total' => $item->get_total() ]; }
		$result = KERP_Modules_Payments_Service::installment( [ 'items' => $items, 'payment_plan' => $intent['plan'] ?? '', 'shipping_total' => $order->get_shipping_total(), 'coupon_code' => implode( ',', $order->get_coupon_codes() ) ] );
		if ( is_wp_error( $result ) ) { return $result; }
		$result['total'] = (float) $order->get_total() - (float) $order->get_total_tax();
		$amounts = KERP_Modules_Installment_Management_Service::split( (float) $order->get_total(), $result['plan']['steps'], wc_get_price_decimals() );
		return [ 'amount' => $amounts[0], 'installment' => $result ];
	}
	public static function activate( WC_Order $order, string $request, array $receipt ): WC_Order|WP_Error {
		if ( ! kerp_can( 'orders.edit', 'action' ) || ! self::is_draft( $order ) ) { return new WP_Error( 'permission', 'مجوز شروع پرداخت این پیش‌فاکتور را ندارید.' ); }
		$details = self::details( $order );
		if ( is_wp_error( $details ) ) { return $details; }
		if ( $receipt['rows'] && abs( array_sum( array_column( $receipt['rows'], 'amount' ) ) - $details['amount'] ) > pow( 10, -wc_get_price_decimals() ) / 2 ) { return new WP_Error( 'amount', 'جمع مبالغ رسیدها باید برابر مبلغ قابل پرداخت باشد.' ); }
		if ( ! empty( $details['deposit'] ) ) { return KERP_Modules_Payments_Deposit::create( $order, $details['amount'] ); }
		if ( $details['installment'] ) {
			$plan = $details['installment'];
			$contract = KERP_Modules_Installment_Management_Service::create( $order->get_customer_id(), $plan['id'], $request, $plan['total'], [], $order );
			return is_wp_error( $contract ) ? $contract : wc_get_order( $contract['orders'][0] );
		}
		$order->update_status( 'pending', 'شروع پرداخت پیش‌فاکتور.' );
		return $order;
	}
}
