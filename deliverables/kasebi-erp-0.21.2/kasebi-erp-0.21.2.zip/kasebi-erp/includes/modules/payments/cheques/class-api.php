<?php
defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Payments_Cheques_Api {
	private static function guard( string $cap ): void {
		if ( ! is_user_logged_in() || ! KERP_App::instance()->current_user_has_access() || ! kerp_can( $cap, 'action' ) || ! wp_verify_nonce( KERP_Modules_Payments_Settings::text( $_POST, 'payment_nonce' ), 'kerp_payments' ) ) { wp_send_json( [ 'status' => 'error', 'message' => 'دسترسی یا اعتبار درخواست معتبر نیست.' ] ); exit; }
	}
	public static function upload(): void {
		$sample = ( $_POST['sample'] ?? '' ) === '1'; self::guard( $sample ? 'payments.manage_settings' : 'payments.approve' );
		try {
			$url = self::file( 'file', [ 'id' => 0 ], 0 );
			if ( ! $url ) { throw new RuntimeException( 'فایل انتخاب نشده است.' ); }
			set_transient( 'kerp_cheque_upload_' . hash( 'sha256', $url ), get_current_user_id(), DAY_IN_SECONDS );
			wp_send_json( [ 'status' => 'success', 'url' => $url ] );
		} catch ( Throwable $e ) { wp_send_json( [ 'status' => 'error', 'message' => $e->getMessage() ] ); }
	}
	public static function file( string $key, array $row, int $index, string $fallback = '' ): string {
		$file = $_FILES[$key] ?? NULL;
		if ( ! $file || (int) ( $file['error'] ?? UPLOAD_ERR_NO_FILE ) === UPLOAD_ERR_NO_FILE ) { return $fallback; }
		if ( ! is_array( $file ) || ! is_scalar( $file['name'] ?? NULL ) || (int) ( $file['size'] ?? 0 ) > 10 * MB_IN_BYTES ) { throw new RuntimeException( 'تصویر باید حداکثر ۱۰ مگابایت باشد.' ); }
		$type = wp_check_filetype_and_ext( (string) $file['tmp_name'], (string) $file['name'], [ 'jpg|jpeg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp' ] );
		if ( empty( $type['ext'] ) || empty( $type['type'] ) ) { throw new RuntimeException( 'فقط تصویر JPG، PNG یا WebP مجاز است.' ); }
		$result = KERP_Helpers_File::instance()->handle_upload_file( $file, 'kerp-cheques/' . get_current_user_id() . '/' . (int) $row['id'] . '/' . $index, [ 'file_name' => wp_generate_uuid4() ] );
		if ( empty( $result['ok'] ) ) { throw new RuntimeException( $result['msg'] ?? 'بارگذاری ناموفق بود.' ); }
		return $result['url'];
	}
	public static function settings(): void {
		self::guard( 'payments.manage_settings' ); $raw = wp_unslash( $_POST ); $old = KERP_Modules_Payments_Cheques::settings();
		try {
			$data = []; foreach ( [ 'sample', 'guide', 'address', 'beneficiary', 'release' ] as $key ) { $data[$key] = $key === 'guide' || $key === 'address' ? sanitize_textarea_field( is_string( $raw[$key] ?? NULL ) ? $raw[$key] : '' ) : KERP_Modules_Payments_Settings::text( $raw, $key ); }
			$data['enabled'] = ! empty( $raw['enabled'] ) ? '1' : '0'; $data['finance_user'] = absint( $raw['finance_user'] ?? 0 );
			$data['reminder_hours'] = max( 1, min( 720, absint( KERP_Helpers_Format::sanitize_numbers( KERP_Modules_Payments_Settings::text( $raw, 'reminder_hours' ) ) ) ) );
			if ( ! in_array( $data['release'], [ 'received', 'collected' ], TRUE ) ) { throw new RuntimeException( 'مرحله مجاز ادامه سفارش را مشخص کنید.' ); }
			if ( $data['sample'] !== $old['sample'] && $data['sample'] !== '' && (int) get_transient( 'kerp_cheque_upload_' . hash( 'sha256', $data['sample'] ) ) !== get_current_user_id() ) { throw new RuntimeException( 'نمونه چک را از همین صفحه بارگذاری کنید.' ); }
			if ( $data['enabled'] === '1' ) {
				$ready = KERP_Modules_Installment_Management_Followups::ready( $data['finance_user'] );
				if ( is_wp_error( $ready ) ) { throw new RuntimeException( $ready->get_error_message() ); }
				if ( $data['sample'] === '' || $data['address'] === '' || $data['beneficiary'] === '' ) { throw new RuntimeException( 'نمونه چک، ذی‌نفع و آدرس دریافت را تکمیل کنید.' ); }
			}
			$data['sms'] = [];
			foreach ( (array) ( $raw['sms'] ?? [] ) as $rule ) {
				if ( ! is_array( $rule ) ) { throw new RuntimeException( 'قانون پیامک معتبر نیست.' ); }
				if ( empty( $rule['pattern'] ) && empty( $rule['event'] ) ) { continue; }
				$event = KERP_Modules_Payments_Settings::text( $rule, 'event' );
				if ( ! isset( KERP_Modules_Payments_Cheques::states()[$event] ) ) { throw new RuntimeException( 'مرحله پیامک را انتخاب کنید.' ); }
				$rule['stage'] = '1'; $rule['event'] = 'created';
				$validated = KERP_Modules_Installment_Management_SMS::validate( [ $rule ], 1 );
				if ( is_wp_error( $validated ) ) { throw new RuntimeException( $validated->get_error_message() ); }
				$valid = $validated[0]; $valid['event'] = $event;
				KERP_Modules_Payments_Cheques_Notifications::variables( $valid['variables'] );
				$data['sms'][] = $valid;
			}
			if ( count( $data['sms'] ) > 50 ) { throw new RuntimeException( 'حداکثر ۵۰ قانون پیامک مجاز است.' ); }
			update_option( KERP_Modules_Payments_Cheques::OPTION, $data, FALSE );
			wp_send_json( array_merge( [ 'status' => 'success', 'message' => 'تنظیمات مراحل چک ذخیره شد.' ], KERP_Api_Page_Content::build_page_response( '/erp/settings/payments/cheques/', [], TRUE ) ) );
		} catch ( Throwable $e ) { wp_send_json( [ 'status' => 'error', 'message' => $e->getMessage() ] ); }
	}
	public static function finance(): void {
		self::guard( 'payments.approve' ); $raw = wp_unslash( $_POST );
		$result = self::perform( $raw, FALSE );
		if ( is_wp_error( $result ) ) { wp_send_json( [ 'status' => 'error', 'message' => $result->get_error_message() ] ); }
		wp_send_json( array_merge( [ 'status' => 'success', 'message' => 'مرحله چک ثبت شد.' ], KERP_Api_Page_Content::build_page_response( '/erp/payments/', [], TRUE ) ) );
	}
	public static function perform( array $raw, bool $customer ): bool|WP_Error {
		$id = absint( $raw['payment_id'] ?? 0 ); $row = KERP_Modules_Payments_Store::get( $id );
		$order = $row ? ( $customer ? wc_get_order( (int) $row['order_id'] ) : KERP_Modules_Orders_Query::instance()->get_order( (int) $row['order_id'] ) ) : NULL;
		if ( ! $row || ! $order || ( $customer && ( (int) $row['customer_id'] !== get_current_user_id() || $order->get_customer_id() !== get_current_user_id() ) ) ) { return new WP_Error( 'scope', 'چک پیدا نشد یا به آن دسترسی ندارید.' ); }
		$lock = 'order_' . $order->get_id(); if ( ! KERP_Modules_Payments_Store::lock( $lock ) ) { return new WP_Error( 'busy', 'درخواست در حال پردازش است؛ دوباره تلاش کنید.' ); }
		try {
			$row = KERP_Modules_Payments_Store::get( $id ); $order = wc_get_order( $order->get_id() );
			$payload = KERP_Modules_Payments_Cheques::transition( $row, $order, absint( $raw['check_index'] ?? 0 ), absint( $raw['version'] ?? 0 ), KERP_Modules_Payments_Settings::text( $raw, 'decision' ), $raw, $customer );
			KERP_Modules_Payments_Cheques::apply( $row, $order, $payload );
		} catch ( Throwable $e ) { return new WP_Error( 'cheque', $e->getMessage() ); }
		finally { KERP_Modules_Payments_Store::unlock( $lock ); }
		KERP_Modules_Payments_Cheques_Notifications::process( $id ); return TRUE;
	}
	public static function customer(): void {
		if ( ! is_page( 'panel' ) || ( $_SERVER['REQUEST_METHOD'] ?? '' ) !== 'POST' || ! isset( $_POST['kerp_cheque_customer'] ) ) { return; }
		if ( ! is_user_logged_in() || ! wp_verify_nonce( KERP_Modules_Payments_Settings::text( $_POST, 'cheque_nonce' ), 'kerp_cheque_customer' ) ) { wp_die( 'اعتبار درخواست منقضی شده است.', '', [ 'response' => 403 ] ); }
		$raw = wp_unslash( $_POST ); $result = self::perform( $raw, TRUE );
		set_transient( 'kerp_cheque_notice_' . get_current_user_id(), [ 'error' => is_wp_error( $result ), 'text' => is_wp_error( $result ) ? $result->get_error_message() : 'اطلاعات ثبت شد؛ وضعیت بعدی را از همین صفحه پیگیری کنید.' ], 120 );
		wp_safe_redirect( KERP_Modules_Payments_Cheques::url( absint( $raw['payment_id'] ?? 0 ), absint( $raw['check_index'] ?? 0 ) ) ); exit;
	}
}
