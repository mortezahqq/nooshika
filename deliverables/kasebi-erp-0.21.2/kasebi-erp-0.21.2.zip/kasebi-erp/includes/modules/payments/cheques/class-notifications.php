<?php
defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Payments_Cheques_Notifications {
	public static function tokens(): array { return [ '{customer_name}' => 'نام مشتری', '{order_id}' => 'شماره سفارش', '{amount}' => 'مبلغ چک', '{due_date}' => 'سررسید شمسی', '{stage}' => 'وضعیت چک', '{cheque_url}' => 'لینک چک در پنل', '{site_name}' => 'نام سایت' ]; }
	public static function variables( string $text ): array {
		$result = [];
		foreach ( preg_split( '/\s*;\s*/u', $text, -1, PREG_SPLIT_NO_EMPTY ) ?: [] as $entry ) {
			$pair = preg_split( '/[:=]/', $entry, 2 ); $key = trim( $pair[0] );
			if ( count( $pair ) !== 2 || ! preg_match( '/^[a-zA-Z][a-zA-Z0-9_-]*$/D', $key ) || in_array( $key, [ 'pattern', 'receptor' ], TRUE ) || isset( $result[$key] ) ) { throw new RuntimeException( 'متغیرهای پیامک را با ساختار token:{cheque_url} و کلیدهای یکتا وارد کنید.' ); }
			preg_match_all( '/\{[^{}]+\}/', $pair[1], $matches );
			if ( array_diff( $matches[0], array_keys( self::tokens() ) ) ) { throw new RuntimeException( 'متغیر پیامک ناشناخته است.' ); }
			$result[$key] = trim( $pair[1] );
		}
		return $result;
	}
	public static function tick(): void {
		global $wpdb;
		$cursor = absint( get_option( 'kerp_cheque_cursor', 0 ) );
		$ids = $wpdb->get_col( $wpdb->prepare( 'SELECT id FROM ' . KERP_Modules_Payments_Store::table() . " WHERE id>%d AND payload LIKE %s ORDER BY id LIMIT 50", $cursor, '%"cheque_flow"%' ) );
		foreach ( $ids as $id ) { self::process( (int) $id ); $cursor = (int) $id; }
		update_option( 'kerp_cheque_cursor', count( $ids ) < 50 ? 0 : $cursor, FALSE );
	}
	public static function process( int $id ): void {
		$row = KERP_Modules_Payments_Store::get( $id ); if ( ! $row ) { return; }
		$lock = 'order_' . $row['order_id']; if ( ! KERP_Modules_Payments_Store::lock( $lock ) ) { return; }
		try {
			$row = KERP_Modules_Payments_Store::get( $id ); $order = wc_get_order( (int) $row['order_id'] ); $payload = json_decode( $row['payload'], TRUE ) ?: [];
			if ( empty( $payload['cheque_flow'] ) ) { return; }
			if ( ! $order || ! KERP_Modules_Payments_Cheques::active( $row, $order ) ) {
				if ( KERP_Modules::instance()->is_module_loaded( 'followups' ) ) {
					foreach ( $payload['cheque_flow']['checks'] as &$closed ) {
						if ( empty( $closed['task'] ) ) { continue; }
						$task = KERP_Modules_Followups_Query::instance()->get_by_id( (int) $closed['task'] );
						if ( $task && $task['status'] === 'pending' ) {
							$cancelled = KERP_Modules_Followups_Module::instance()->cancel( (int) $closed['task'], 'سند پرداخت دیگر فعال نیست.' );
							if ( is_wp_error( $cancelled ) ) { $closed['task_error'] = $cancelled->get_error_message(); continue; }
						}
						$closed['task'] = 0;
					} unset( $closed );
					KERP_Modules_Payments_Store::update( $id, [ 'payload' => wp_json_encode( $payload ) ] );
				} return;
			}
			// Recover a completed state write if the order callback was interrupted.
			KERP_Modules_Payments_Cheques::apply( $row, $order, $payload );
			$flow =& $payload['cheque_flow'];
			foreach ( $flow['checks'] as $index => &$check ) {
				self::task( $row, $flow, $check, $index );
				foreach ( $flow['settings']['sms'] as $rule_id => $rule ) {
					$key = $check['version'] . ':' . $rule_id . ':' . ( (int) $rule['offset'] === 0 ? (int) ( $check['sms_round'] ?? 0 ) : 0 );
					if ( empty( $rule['enabled'] ) || $rule['event'] !== $check['state'] || isset( $check['sms'][$key] ) || time() < $check['entered'] + $rule['offset'] * MINUTE_IN_SECONDS || ! KERP_Modules_Installment_Management_SMS::condition( $rule, (int) $row['customer_id'], $order ) ) { continue; }
					if ( ! class_exists( 'kasebiSMS' ) || ! method_exists( 'kasebiSMS', 'send_pattern_sms' ) ) { $check['sms_error'] = 'سرویس پیامک در دسترس نیست.'; continue; }
					$phones = self::phones( $rule, $row, $flow['settings'] );
					if ( ! $phones ) { $check['sms_error'] = 'شماره گیرنده پیامک معتبر نیست.'; continue; }
					$user = get_userdata( (int) $row['customer_id'] );
					$context = [ '{customer_name}' => $user ? $user->display_name : '', '{order_id}' => (string) KERP_Modules_Installment_Management_Service::main_order_id( $order->get_id() ), '{amount}' => $payload['rows'][$index]['amount'], '{due_date}' => KERP_Helpers_Date::gregorian_to_jalali( $payload['rows'][$index]['due'] ?? '' ), '{stage}' => KERP_Modules_Payments_Cheques::states()[$check['state']], '{cheque_url}' => KERP_Modules_Payments_Cheques::url( $id, $index ), '{site_name}' => get_bloginfo( 'name' ) ];
					$variables = self::variables( $rule['variables'] );
					// Persist the attempt before the remote call; an ambiguous response must not send twice.
					$check['sms'][$key] = [ 'at' => time(), 'status' => 'sending' ];
					if ( ! KERP_Modules_Payments_Store::update( $id, [ 'payload' => wp_json_encode( $payload ) ] ) ) { return; }
					$results = [];
					foreach ( $phones as $phone ) {
						$data = [ 'receptor' => $phone, 'pattern' => $rule['pattern'] ]; foreach ( $variables as $name => $value ) { $data[$name] = strtr( $value, $context ); }
						try { $results[] = KERP_Modules_Payments_SMS::delivery_status( ( new kasebiSMS() )->send_pattern_sms( $data ) ); } catch ( Throwable $e ) { $results[] = 'unknown'; }
					}
					$check['sms'][$key]['status'] = count( array_filter( $results, static fn( $s ) => $s !== 'sent' ) ) ? 'failed_or_unknown' : 'sent';
					unset( $check['sms_error'] );
				}
			}
			unset( $check ); KERP_Modules_Payments_Store::update( $id, [ 'payload' => wp_json_encode( $payload ) ] );
		} catch ( Throwable $e ) { /* Persisted attempts remain visible; the next cron can resume pending work. */ }
		finally { KERP_Modules_Payments_Store::unlock( $lock ); }
	}
	private static function phones( array $rule, array $row, array $settings ): array {
		$raw = match( $rule['recipient'] ) {
			'admin' => get_option( 'kasebi_sms_admin_phone_number', '' ), 'employee' => get_user_meta( (int) $settings['finance_user'], 'nooshika_phone_num', TRUE ), 'custom' => $rule['receptor'], 'user_meta' => get_user_meta( (int) $row['customer_id'], $rule['phone_meta'], TRUE ), default => get_user_meta( (int) $row['customer_id'], 'nooshika_phone_num', TRUE ),
		};
		if ( ! is_scalar( $raw ) ) { return []; }
		$result = [];
		foreach ( preg_split( '/[,،\s]+/u', KERP_Helpers_Format::sanitize_numbers( (string) $raw ), -1, PREG_SPLIT_NO_EMPTY ) ?: [] as $phone ) { $phone = preg_replace( '/\D/', '', $phone ); $phone = preg_replace( '/^(?:0098|98|0)(?=9\d{9}$)/', '', $phone ); if ( preg_match( '/^9\d{9}$/D', $phone ) ) { $result[] = $phone; } }
		return array_values( array_unique( $result ) );
	}
	private static function task( array $row, array $flow, array &$check, int $index ): void {
		if ( ! KERP_Modules::instance()->is_module_loaded( 'followups' ) ) { $check['task_error'] = 'ماژول پیگیری فعال نیست.'; return; }
		$module = KERP_Modules_Followups_Module::instance();
		if ( ! empty( $check['task'] ) && (int) ( $check['task_version'] ?? 0 ) !== (int) $check['version'] ) { $done = $module->complete( (int) $check['task'], 'مرحله چک تغییر کرد.' ); if ( is_wp_error( $done ) ) { $check['task_error'] = $done->get_error_message(); return; } $check['task'] = 0; }
		if ( $check['state'] === 'collected' || ! empty( $check['task'] ) ) { return; }
		global $wpdb; $source = 'kerp-cheque:' . $row['id'] . ':' . $index . ':' . $check['version'];
		$existing = $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . KERP_Modules_Followups_Module::table() . ' WHERE metadata LIKE %s LIMIT 1', '%' . $wpdb->esc_like( '"source_key":"' . $source . '"' ) . '%' ) );
		if ( $existing ) { $check['task'] = (int) $existing; $check['task_version'] = $check['version']; return; }
		$finance = in_array( $check['state'], [ 'review', 'shipped', 'received' ], TRUE );
		$id = $module->save( [ 'customer_id' => (int) $row['customer_id'], 'assignee_id' => $finance ? (int) $flow['settings']['finance_user'] : (int) $row['created_by'], 'type_key' => 'cheque_review', 'title' => 'چک #' . $row['id'] . '-' . ( $index + 1 ) . ': ' . KERP_Modules_Payments_Cheques::states()[$check['state']], 'description' => 'پیگیری مرحله چک در پرداخت سفارش #' . KERP_Modules_Installment_Management_Service::main_order_id( (int) $row['order_id'] ), 'due_at' => wp_date( 'Y-m-d H:i:s', $check['entered'] + (int) $flow['settings']['reminder_hours'] * HOUR_IN_SECONDS ), 'priority' => 'normal', 'status' => 'pending', 'metadata' => [ 'source_key' => $source, 'payment_id' => (int) $row['id'], 'check_index' => $index, 'order_id' => (int) $row['order_id'] ] ] );
		if ( is_wp_error( $id ) ) { $check['task_error'] = $id->get_error_message(); return; }
		$check['task'] = $id; $check['task_version'] = $check['version']; unset( $check['task_error'] );
	}
}
