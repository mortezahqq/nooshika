<?php
defined( 'ABSPATH' ) || exit;

/** Cheque state belongs to a receipt row, not to the entire payment. */
final class KERP_Modules_Payments_Cheques {
	const OPTION = 'kerp_cheque_workflow';
	const CRON = 'kerp_cheques_tick';
	public static function states(): array { return [ 'customer' => 'منتظر تکمیل مشتری', 'review' => 'منتظر استعلام مالی', 'correction' => 'نیازمند اصلاح', 'rejected' => 'رد استعلام', 'shipping' => 'منتظر ارسال اصل چک', 'shipped' => 'ارسال‌شده؛ منتظر دریافت', 'discrepancy' => 'مغایرت در دریافت', 'received' => 'اصل چک دریافت و تأیید شد', 'collected' => 'وجه چک وصول شد' ]; }
	public static function settings(): array { return array_merge( [ 'enabled' => '0', 'sample' => '', 'guide' => '', 'address' => '', 'beneficiary' => '', 'release' => 'collected', 'finance_user' => 0, 'reminder_hours' => 48, 'sms' => [] ], (array) get_option( self::OPTION, [] ) ); }
	public static function enabled(): bool { return self::settings()['enabled'] === '1'; }
	public static function date( string $value ): string { return KERP_Helpers_Date::jalali_to_gregorian( str_replace( '/', '-', KERP_Helpers_Format::sanitize_numbers( trim( $value ) ) ) ); }
	public static function url( int $id, int $index ): string { return home_url( '/panel/cheques/cheque/' . $id . '-' . $index . '/' ); }
	public static function boot(): void {
		add_action( 'kasebi_ajax_cheques_save_settings', [ KERP_Modules_Payments_Cheques_Api::class, 'settings' ] );
		add_action( 'kasebi_ajax_cheques_upload', [ KERP_Modules_Payments_Cheques_Api::class, 'upload' ] );
		add_action( 'kasebi_ajax_cheques_upload_sample', static function() { $_POST['sample'] = '1'; KERP_Modules_Payments_Cheques_Api::upload(); } );
		add_action( 'kasebi_ajax_cheques_action', [ KERP_Modules_Payments_Cheques_Api::class, 'finance' ] );
		add_action( 'template_redirect', [ KERP_Modules_Payments_Cheques_Api::class, 'customer' ], 20 );
		add_filter( 'nooshika_panel_pages_list_default', static function( $pages ) {
			if ( ! self::enabled() ) {
				global $wpdb;
				if ( ! get_current_user_id() || ! $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . KERP_Modules_Payments_Store::table() . ' WHERE customer_id=%d AND payload LIKE %s LIMIT 1', get_current_user_id(), '%"cheque_flow"%' ) ) ) { return $pages; }
			}
			$pages['cheques'] = [ 'label' => 'چک‌های من', 'icon' => 'hik-r fa-document-download-1' ]; return $pages;
		} );
		add_filter( 'nooshika_panel_get_template_path', static function( $file, $path ) { return in_array( $path, [ 'pages/cheques', 'sub_pages/cheque' ], TRUE ) ? KERP_INC_PATH . '../templates/modules/payments/cheques-customer.php' : $file; }, 10, 2 );
		add_action( self::CRON, [ KERP_Modules_Payments_Cheques_Notifications::class, 'tick' ] );
		if ( ! wp_next_scheduled( self::CRON ) ) { wp_schedule_event( time() + 60, 'hourly', self::CRON ); }
		add_filter( 'kerp_followup_types', static function( $types ) { $types['cheque_review'] = [ 'key' => 'cheque_review', 'label' => 'پیگیری چک', 'icon' => 'ni ni-file-check', 'color' => 'warning', 'order' => 66, 'active' => 1 ]; return $types; } );
		add_action( 'wp_enqueue_scripts', static function() { if ( is_page( 'panel' ) ) { wp_enqueue_style( 'kerp-customer-cheques', KERP_ASSETS_URL . 'cheques-customer.css', [], (string) filemtime( KERP_ASSETS_PATH . 'cheques-customer.css' ) ); } } );
	}
	public static function initial( array $receipt, string $method ): array {
		if ( ! self::enabled() || ! in_array( $method, [ 'kerp_cheque', 'kerp_mixed' ], TRUE ) ) { return $receipt; }
		$settings = self::settings(); $checks = [];
		foreach ( $receipt['rows'] as $i => $row ) {
			if ( $method === 'kerp_mixed' && ( $receipt['row_methods'][$i] ?? '' ) !== 'cheque' ) { continue; }
			$checks[$i] = [ 'state' => 'customer', 'version' => 1, 'entered' => time(), 'history' => [ [ 'state' => 'customer', 'at' => time(), 'by' => get_current_user_id(), 'note' => 'ثبت درخواست تکمیل چک' ] ], 'image' => '', 'shipping' => [], 'sms' => [], 'task' => 0 ];
		}
		if ( $checks ) { $receipt['cheque_flow'] = [ 'settings' => $settings, 'checks' => $checks, 'cash_confirmed' => $method !== 'kerp_mixed', 'cash_history' => [] ]; $receipt['status'] = 'finance-review'; }
		return $receipt;
	}
	public static function active( array $row, WC_Order $order ): bool {
		return in_array( $row['status'], [ 'review', 'accepted', 'paid' ], TRUE ) && (int) $order->get_meta( '_kerp_payment_id' ) === (int) $row['id']
			&& $order->get_customer_id() === (int) $row['customer_id'] && $order->get_currency() === $row['currency']
			&& abs( (float) $row['amount'] - (float) $order->get_total() ) < 0.000001 && ! $order->has_status( [ 'cancelled', 'refunded', 'failed' ] ) && (float) $order->get_total_refunded() === 0.0;
	}
	public static function replacement_blocked( array $row ): bool {
		$flow = ( json_decode( $row['payload'], TRUE ) ?: [] )['cheque_flow'] ?? NULL;
		if ( ! $flow ) { return FALSE; }
		if ( $row['method'] === 'kerp_mixed' && ! empty( $flow['cash_confirmed'] ) ) { return TRUE; }
		foreach ( $flow['checks'] as $check ) { if ( in_array( $check['state'], [ 'received', 'collected' ], TRUE ) ) { return TRUE; } }
		return FALSE;
	}
	public static function amount_received( WC_Order $order ): ?float {
		$id = (int) $order->get_meta( '_kerp_payment_id' ); if ( ! $id ) { return NULL; }
		$row = KERP_Modules_Payments_Store::get( $id ); $payload = $row ? json_decode( $row['payload'], TRUE ) : [];
		if ( empty( $payload['cheque_flow'] ) || ! self::active( $row, $order ) ) { return NULL; }
		$total = 0;
		foreach ( $payload['rows'] as $i => $receipt ) {
			$check = $payload['cheque_flow']['checks'][$i] ?? NULL;
			if ( $check ? $check['state'] === 'collected' : ! empty( $payload['cheque_flow']['cash_confirmed'] ) ) { $total += (float) $receipt['amount']; }
		}
		return $total;
	}
	public static function apply( array $row, WC_Order $order, array $payload ): void {
		$flow = $payload['cheque_flow']; $ready = (bool) $flow['cash_confirmed']; $collected = $ready;
		foreach ( $flow['checks'] as $check ) {
			$ready = $ready && in_array( $check['state'], $flow['settings']['release'] === 'received' ? [ 'received', 'collected' ] : [ 'collected' ], TRUE );
			$collected = $collected && $check['state'] === 'collected';
		}
		$status = $ready ? ( $collected ? 'paid' : 'accepted' ) : 'review';
		if ( ! KERP_Modules_Payments_Store::update( (int) $row['id'], [ 'payload' => wp_json_encode( $payload ), 'status' => $status ] ) ) { throw new RuntimeException( 'ذخیره مراحل چک ناموفق بود.' ); }
		if ( $ready && ! $order->is_paid() ) { $order->payment_complete(); }
	}
	public static function transition( array $row, WC_Order $order, int $index, int $version, string $action, array $input, bool $customer ): array {
		$payload = json_decode( $row['payload'], TRUE ) ?: [];
		if ( empty( $payload['cheque_flow'] ) || ! self::active( $row, $order ) ) { throw new RuntimeException( 'این درخواست چک دیگر فعال نیست.' ); }
		$flow =& $payload['cheque_flow'];
		if ( $action === 'cash' && ! $customer && $row['method'] === 'kerp_mixed' && empty( $flow['cash_confirmed'] ) ) {
			$note = KERP_Modules_Payments_Settings::text( $input, 'note' ); if ( $note === '' ) { throw new RuntimeException( 'توضیح تأیید بخش نقدی الزامی است.' ); }
			$flow['cash_confirmed'] = TRUE; $flow['cash_history'][] = [ 'by' => get_current_user_id(), 'at' => time(), 'note' => $note ]; return $payload;
		}
		if ( ! isset( $flow['checks'][$index] ) || (int) $flow['checks'][$index]['version'] !== $version ) { throw new RuntimeException( 'اطلاعات تغییر کرده است؛ صفحه را تازه کنید.' ); }
		$check =& $flow['checks'][$index]; $state = $check['state'];
		if ( $action === 'sms' && ! $customer ) {
			$rules = array_filter( $flow['settings']['sms'], static fn( $rule ) => ! empty( $rule['enabled'] ) && $rule['event'] === $state && (int) $rule['offset'] === 0 );
			if ( ! $rules ) { throw new RuntimeException( 'پیامک فوری برای مرحله فعلی این چک تعریف نشده است.' ); }
			$last = max( array_merge( [ 0 ], array_column( $check['sms'], 'at' ) ) );
			if ( $last > time() - 60 ) { throw new RuntimeException( 'برای ارسال مجدد یک دقیقه صبر کنید؛ ابتدا گزارش سرویس را بررسی کنید.' ); }
			$check['sms_round'] = (int) ( $check['sms_round'] ?? 0 ) + 1;
			$check['history'][] = [ 'state' => $state, 'at' => time(), 'by' => get_current_user_id(), 'note' => 'درخواست ارسال مجدد پیامک مرحله' ];
			return $payload;
		}
		$allowed = $customer ? [ 'submit' => [ 'customer', 'correction', 'rejected' ], 'ship' => [ 'shipping', 'discrepancy' ] ] : [ 'approve' => [ 'review' ], 'correct' => [ 'review' ], 'reject' => [ 'review' ], 'receive' => [ 'shipped' ], 'discrepancy' => [ 'shipped' ], 'collect' => [ 'received' ] ];
		if ( ! in_array( $state, $allowed[$action] ?? [], TRUE ) ) { throw new RuntimeException( 'این اقدام در مرحله فعلی مجاز نیست.' ); }
		$note = KERP_Modules_Payments_Settings::text( $input, 'note' );
		if ( ! $customer && $note === '' ) { throw new RuntimeException( 'نتیجه بررسی و توضیح مالی الزامی است.' ); }
		$before = [ 'fields' => $payload['rows'][$index], 'image' => $check['image'], 'shipping' => $check['shipping'] ];
		if ( $action === 'submit' ) {
			$definitions = $payload['method_fields']['cheque'] ?? $payload['fields'];
			foreach ( $definitions as $field ) {
				if ( $field['key'] === 'due' ) { continue; }
				$value = KERP_Modules_Payments_Settings::text( (array) ( $input['fields'] ?? [] ), $field['key'] );
				if ( $field['type'] === 'upload' ) { $value = KERP_Modules_Payments_Cheques_Api::file( 'field_' . $field['key'], $row, $index, $payload['rows'][$index][$field['key']] ?? '' ); }
				if ( ! empty( $field['required'] ) && $value === '' ) { throw new RuntimeException( 'فیلد «' . $field['label'] . '» الزامی است.' ); }
				if ( $value !== '' && $field['type'] === 'number' && KERP_Modules_Payments_Service::number( $value ) < 0 ) { throw new RuntimeException( 'عدد معتبر وارد کنید.' ); }
				if ( $value !== '' && $field['type'] === 'date' ) { $value = self::date( $value ); if ( ! $value ) { throw new RuntimeException( 'تاریخ معتبر نیست.' ); } }
				$payload['rows'][$index][$field['key']] = $value;
			}
			$check['image'] = KERP_Modules_Payments_Cheques_Api::file( 'image', $row, $index, $check['image'] );
			if ( ! $check['image'] ) { throw new RuntimeException( 'تصویر چک را بارگذاری کنید.' ); }
		}
		if ( $action === 'ship' ) {
			$method = KERP_Modules_Payments_Settings::text( $input, 'shipping_method' );
			$date = self::date( KERP_Modules_Payments_Settings::text( $input, 'shipping_date' ) );
			$tracking = KERP_Modules_Payments_Settings::text( $input, 'tracking' );
			if ( ! in_array( $method, [ 'post', 'courier', 'in_person' ], TRUE ) || ! $date || ( $method !== 'in_person' && $tracking === '' ) ) { throw new RuntimeException( 'روش ارسال، تاریخ شمسی و کد رهگیری را کامل کنید.' ); }
			$proof = KERP_Modules_Payments_Cheques_Api::file( 'shipping_proof', $row, $index );
			if ( $method !== 'in_person' && ! $proof ) { throw new RuntimeException( 'تصویر رسید ارسال لازم است.' ); }
			$check['shipping'] = [ 'method' => $method, 'date' => $date, 'tracking' => $tracking, 'proof' => $proof ];
		}
		$next = [ 'submit' => 'review', 'ship' => 'shipped', 'approve' => 'shipping', 'correct' => 'correction', 'reject' => 'rejected', 'receive' => 'received', 'discrepancy' => 'discrepancy', 'collect' => 'collected' ][$action];
		$evidence = $customer ? '' : KERP_Modules_Payments_Settings::text( $input, 'evidence' );
		if ( $evidence && (int) get_transient( 'kerp_cheque_upload_' . hash( 'sha256', $evidence ) ) !== get_current_user_id() ) { throw new RuntimeException( 'پیوست بررسی را در همین فرم بارگذاری کنید.' ); }
		$check['history'][] = [ 'state' => $next, 'at' => time(), 'by' => get_current_user_id(), 'note' => $note, 'evidence' => $evidence, 'before' => $before ];
		$check['state'] = $next; $check['version']++; $check['entered'] = time();
		return $payload;
	}
}
