<?php
defined( 'ABSPATH' ) || exit;

/** A sales order keeps its full total; two hidden invoices collect the advance and balance. */
final class KERP_Modules_Payments_Deposit {
	public static function amount( mixed $value, float $total ): float|WP_Error {
		$amount = round( KERP_Modules_Payments_Service::number( $value ), wc_get_price_decimals() );
		return $amount > 0 && $amount < $total ? $amount : new WP_Error( 'deposit', 'پیش‌پرداخت باید بیشتر از صفر و کمتر از مبلغ کل سفارش باشد.' );
	}
	public static function orders( WC_Order $parent ): array {
		$result = [];
		foreach ( (array) $parent->get_meta( '_kerp_deposit_orders' ) as $index => $id ) {
			$part = wc_get_order( (int) $id );
			$expected = $index === 0 ? (float) $parent->get_meta( '_kerp_deposit_amount' ) : (float) $parent->get_total() - (float) $parent->get_meta( '_kerp_deposit_amount' );
			if ( $part && (int) $part->get_meta( '_kerp_installment_parent_order' ) === $parent->get_id()
				&& (int) $part->get_meta( '_kerp_deposit_part' ) === $index + 1 && abs( (float) $part->get_total() - $expected ) < 0.000001 && $part->get_customer_id() === $parent->get_customer_id()
				&& $part->get_currency() === $parent->get_currency() ) { $result[] = $part; }
		}
		return $result;
	}
	public static function payable( WC_Order $part ): bool {
		if ( ! $part->get_meta( '_kerp_deposit_part' ) ) { return ! $part->get_meta( '_kerp_deposit_orders' ); }
		$parent = wc_get_order( (int) $part->get_meta( '_kerp_installment_parent_order' ) );
		return $parent && $parent->has_status( 'part-payment' ) && in_array( $part->get_id(), array_map( static fn( $order ) => $order->get_id(), self::orders( $parent ) ), TRUE );
	}
	public static function create( WC_Order $parent, mixed $value ): WC_Order|WP_Error {
		$parts = self::orders( $parent );
		if ( count( $parts ) === 2 ) { return $parts[0]; }
		if ( $parent->get_meta( '_kerp_deposit_orders' ) || $parent->is_paid() || $parent->get_meta( '_kerp_installment_contract' ) ) { return new WP_Error( 'deposit', 'ساختار پرداخت سفارش قابل تغییر نیست.' ); }
		$amount = self::amount( $value, (float) $parent->get_total() );
		if ( is_wp_error( $amount ) ) { return $amount; }
		$created = [];
		try {
			$parent->update_meta_data( '_kerp_deposit_amount', $amount ); $parent->save();
			foreach ( [ $amount, round( (float) $parent->get_total() - $amount, wc_get_price_decimals() ) ] as $index => $total ) {
				$part = wc_create_order( [ 'customer_id' => $parent->get_customer_id(), 'parent' => $parent->get_id(), 'created_via' => 'kerp_installment_payment', 'status' => 'pending' ] );
				if ( is_wp_error( $part ) ) { throw new RuntimeException( $part->get_error_message() ); }
				$created[] = $part;
				$part->set_currency( $parent->get_currency() );
				$part->set_address( $parent->get_address( 'billing' ), 'billing' );
				// Reuse the existing hidden payment-invoice marker; this is not an installment contract.
				$part->update_meta_data( '_kerp_installment_parent_order', $parent->get_id() );
				$part->update_meta_data( '_kerp_deposit_part', $index + 1 );
				$part->update_meta_data( 'marketer_id', $parent->get_meta( 'marketer_id' ) );
				$item = new WC_Order_Item_Fee();
				$item->set_name( ( $index === 0 ? 'پیش‌پرداخت' : 'تسویه مانده' ) . ' سفارش #' . $parent->get_order_number() );
				$item->set_tax_status( 'none' ); $item->set_amount( $total ); $item->set_total( $total );
				$part->add_item( $item ); $part->calculate_totals( FALSE ); $part->save();
			}
			$parent->update_meta_data( '_kerp_deposit_orders', array_map( static fn( $part ) => $part->get_id(), $created ) );
			$parent->save(); $parent->update_status( 'part-payment', 'ثبت سفارش با پیش‌پرداخت؛ مبلغ کامل هنوز وصول نشده است.' );
			return $created[0];
		} catch ( Throwable $e ) {
			foreach ( $created as $part ) { $part->update_status( 'cancelled', 'ساخت پیش‌پرداخت ناموفق بود.' ); }
			$parent->delete_meta_data( '_kerp_deposit_orders' ); $parent->save();
			return new WP_Error( 'deposit', $e->getMessage() );
		}
	}
	public static function balance( WC_Order $parent ): ?array {
		if ( ! $parent->get_meta( '_kerp_deposit_amount' ) ) { return NULL; }
		$paid = 0.0; $payable = FALSE;
		foreach ( self::orders( $parent ) as $part ) {
			$received = KERP_Modules_Payments_Cheques::amount_received( $part );
			if ( $received !== NULL ) { $paid += $received; }
			elseif ( $part->is_paid() || $part->has_status( 'refunded' ) ) { $paid += max( 0, (float) $part->get_total() - (float) $part->get_total_refunded() ); }
			if ( ! $part->is_paid() && $part->has_status( [ 'pending', 'failed', 'finance-review' ] ) ) { $payable = TRUE; }
		}
		$total = (float) $parent->get_total(); $paid = min( $total, $paid );
		return [ 'total' => $total, 'paid' => $paid, 'remaining' => max( 0, $total - $paid ), 'percent' => $total > 0 ? round( 100 * $paid / $total ) : 0, 'due' => NULL, 'payable' => $payable ];
	}
	public static function sync( WC_Order $part ): void {
		if ( ! $part->get_meta( '_kerp_deposit_part' ) ) { return; }
		$parent = wc_get_order( (int) $part->get_meta( '_kerp_installment_parent_order' ) );
		if ( ! $parent || $parent->has_status( [ 'cancelled', 'refunded' ] ) ) { return; }
		$balance = self::balance( $parent );
		if ( ! $balance || count( self::orders( $parent ) ) !== 2 ) { return; }
		$released = ! array_filter( self::orders( $parent ), static fn( $child ) => ! $child->is_paid() || (float) $child->get_total_refunded() > 0 );
		if ( $released && ! $parent->is_paid() ) { $parent->payment_complete(); }
		elseif ( ! $released && ! $parent->has_status( 'part-payment' ) ) { $parent->update_status( 'part-payment', 'سفارش دارای مانده پرداخت است.' ); }
	}
}
