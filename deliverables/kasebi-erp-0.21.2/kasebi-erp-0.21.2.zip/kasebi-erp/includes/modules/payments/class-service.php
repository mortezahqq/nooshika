<?php
defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Payments_Service {
	public static function retry_order( WC_Order $order ): ?WC_Order {
		if ( ! kerp_can( 'payments.view', 'view' ) || ! kerp_can( 'payments.create', 'action' ) ) { return NULL; }
		global $wpdb;
		foreach ( KERP_Modules_Installment_Management_Service::payment_order_ids( $order->get_id() ) as $id ) {
			$part = KERP_Modules_Orders_Query::instance()->get_order( $id );
			if ( ! $part ) { continue; }
			$action = self::payment_action( $part );
			if ( ! $action || $action['replace'] ) { continue; }
			$rejected = $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . KERP_Modules_Payments_Store::table() . " WHERE order_id=%d AND status IN ('rejected','failed') ORDER BY id DESC LIMIT 1", $id ) );
			if ( $rejected ) { return $part; }
		}
		return NULL;
	}
	public static function payment_action( WC_Order $order ): ?array {
		if ( ! KERP_Modules_Payments_Deposit::payable( $order ) ) { return NULL; }
		if ( ! kerp_can( 'payments.create', 'action' ) || $order->is_paid() || ! $order->has_status( [ 'pending', 'failed', 'finance-review' ] ) ) { return NULL; }
		global $wpdb;
		$open = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . KERP_Modules_Payments_Store::table() . " WHERE order_id=%d AND status IN ('pending','review','building') LIMIT 1", $order->get_id() ) );
		if ( ! $open ) { return [ 'replace' => FALSE, 'payment_id' => 0 ]; }
		$payment = KERP_Modules_Payments_Store::get( $open );
		if ( $payment && KERP_Modules_Payments_Cheques::replacement_blocked( $payment ) ) { return NULL; }
		if ( $payment && in_array( $payment['status'], [ 'pending', 'review' ], TRUE ) && (int) $order->get_meta( '_kerp_payment_id' ) === $open && kerp_can( 'orders.edit', 'action' ) ) { return [ 'replace' => TRUE, 'payment_id' => $open ]; }
		return NULL;
	}
	/** Receipt date pickers emit numeric Jalali dates, not Excel's textual datetime. */
	public static function valid_receipt_date( string $value ): bool {
		$value = str_replace( '/', '-', KERP_Helpers_Format::sanitize_numbers( trim( $value ) ) );
		if ( preg_match( '/^(\d{4})-(\d{1,2})-(\d{1,2})$/D', $value, $parts ) ) {
			$year = (int) $parts[1]; $month = (int) $parts[2]; $day = (int) $parts[3];
			if ( $year >= 1700 ) { return checkdate( $month, $day, $year ); }
			$date = KERP_Helpers_Date::jalali_to_gregorian( $value );
			if ( $date === '' ) { return FALSE; }
			// Esfand 30 must not roll into the following year in a non-leap year.
			return $date < KERP_Helpers_Date::jalali_to_gregorian( ( $year + 1 ) . '-1-1' );
		}
		return KERP_Helpers_Date::parse_excel_jalali_datetime( $value ) !== NULL;
	}
	public static function number( mixed $value ): float {
		if ( ! is_scalar( $value ) ) { return -1; }
		$value = str_replace( [ '۰','۱','۲','۳','۴','۵','۶','۷','۸','۹','٠','١','٢','٣','٤','٥','٦','٧','٨','٩',',','٬' ], [ '0','1','2','3','4','5','6','7','8','9','0','1','2','3','4','5','6','7','8','9','','' ], (string) $value );
		return $value === '' ? 0 : ( is_numeric( $value ) && is_finite( (float) $value ) ? (float) $value : -1 );
	}
	public static function customer( int $id, bool $order_creation = FALSE ): bool {
		if ( $order_creation && KERP_Modules_Customers_Query::can_select_for_order( $id ) ) { return TRUE; }
		$scope = kerp_list_scope( 'customers' );
		return $id > 0 && get_userdata( $id ) && ( $scope === 'all' || ( $scope === 'own' && (int) get_user_meta( $id, 'owner_id', TRUE ) === get_current_user_id() ) );
	}
	public static function installment( array $raw ): array|WP_Error {
		if ( ! KERP_Modules::instance()->is_module_loaded( 'installment_management' ) || ! kerp_can( 'installments.create', 'action' ) ) { return new WP_Error( 'plan', 'ماژول اقساط یا مجوز ثبت قرارداد فعال نیست.' ); }
		$items = array_values( array_filter( (array) ( $raw['items'] ?? [] ), static fn( $r ) => is_array( $r ) && ! empty( $r['product_id'] ) ) );
		if ( count( $items ) !== 1 || self::number( $items[0]['quantity'] ?? 0 ) !== 1.0 ) { return new WP_Error( 'items', 'سفارش اقساطی باید یک محصول با تعداد یک داشته باشد.' ); }
		$plans = KERP_Modules_Installment_Management_Settings::all(); $product_id = absint( $items[0]['product_id'] );
		$available = array_filter( $plans, static fn( $p ) => ! empty( $p['enabled'] ) && (int) $p['product_id'] === $product_id );
		if ( ! $available ) { return new WP_Error( 'plan', 'برای این محصول پلن اقساطی فعال تعریف نشده است.' ); }
		$plan_id = KERP_Modules_Payments_Settings::text( $raw, 'payment_plan' );
		if ( ! isset( $available[ $plan_id ] ) ) { return new WP_Error( 'plan', 'یکی از پلن‌های اقساط همین محصول را انتخاب کنید.', [ 'plans' => array_map( static fn( $p ) => $p['name'], $available ) ] ); }
		$plan = $available[ $plan_id ]; $valid = KERP_Modules_Installment_Management_Settings::validate( $plan );
		if ( is_wp_error( $valid ) ) { return $valid; }
		if ( self::number( $raw['shipping_total'] ?? 0 ) != 0 || KERP_Modules_Payments_Settings::text( $raw, 'coupon_code' ) !== '' ) { return new WP_Error( 'amount', 'سفارش آموزشی اقساطی هزینه ارسال یا کد تخفیف ندارد؛ تخفیف را در مبلغ سفارش وارد کنید.' ); }
		$total = self::number( $items[0]['line_total'] ?? 0 ) + self::number( $raw['custom_extra_fee'] ?? 0 ) - self::number( $raw['custom_fee'] ?? 0 );
		if ( $total <= 0 ) { return new WP_Error( 'amount', 'مبلغ سفارش باید مثبت باشد.' ); }
		return [ 'id' => $plan_id, 'plan' => $plan, 'total' => $total ];
	}
	public static function rows( string $method, array $raw ): array|WP_Error {
		if ( $method === 'kerp_mixed' ) {
			$settings = KERP_Modules_Payments_Settings::all();
			if ( empty( $settings['card']['enabled'] ) || empty( $settings['cheque']['enabled'] ) ) {
				return new WP_Error( 'receipt', 'برای پرداخت ترکیبی، روش کارت و چک باید فعال باشند.' );
			}
			$result = [ 'rows' => [], 'fields' => [], 'row_methods' => [], 'method_fields' => [], 'status' => 'completed' ];
			foreach ( [ 'card', 'cheque' ] as $part ) {
				$receipt = self::rows( 'kerp_' . $part, $raw );
				if ( is_wp_error( $receipt ) ) { return new WP_Error( 'receipt', KERP_Modules_Payments_Settings::labels()[ $part ] . ': ' . $receipt->get_error_message() ); }
				$result['method_fields'][ $part ] = $receipt['fields'];
				foreach ( $receipt['rows'] as $row ) {
					$result['rows'][] = $row;
					$result['row_methods'][] = $part;
				}
				if ( $receipt['status'] !== 'completed' ) { $result['status'] = 'finance-review'; }
			}
			if ( count( $result['rows'] ) > 50 ) { return new WP_Error( 'receipt', 'حداکثر ۵۰ ردیف در مجموع رسیدها و چک‌ها ثبت کنید.' ); }
			return $result;
		}
		$key = str_starts_with( $method, 'kerp_' ) ? substr( $method, 5 ) : '';
		$config = KERP_Modules_Payments_Settings::all()[ $key ] ?? NULL;
		if ( ! $config ) { return [ 'rows' => [], 'fields' => [], 'status' => 'pending' ]; }
		$cheque_flow = $key === 'cheque' && KERP_Modules_Payments_Cheques::enabled();
		if ( $cheque_flow && ! in_array( 'due', array_column( $config['fields'], 'key' ), TRUE ) ) { $config['fields'][] = [ 'key' => 'due', 'label' => 'تاریخ سررسید', 'type' => 'date', 'required' => '1' ]; }
		if ( $cheque_flow ) { foreach ( $config['fields'] as &$definition ) { if ( $definition['key'] === 'due' ) { $definition['type'] = 'date'; $definition['required'] = '1'; } } unset( $definition ); }
		$rows = [];
		foreach ( (array) ( $raw[ 'receipts_' . $key ] ?? [] ) as $row ) {
			if ( ! is_array( $row ) ) { return new WP_Error( 'receipt', 'ساختار رسید معتبر نیست.' ); }
			if ( ! array_filter( $row, static fn( $v ) => is_scalar( $v ) && (string) $v !== '' ) ) { continue; }
			$amount = self::number( $row['amount'] ?? 0 );
			if ( $amount <= 0 ) { return new WP_Error( 'receipt', 'مبلغ هر ردیف رسید باید مثبت باشد.' ); }
			$clean = [ 'amount' => wc_format_decimal( $amount, wc_get_price_decimals() ) ];
			foreach ( $config['fields'] as $field ) {
				$value = KERP_Modules_Payments_Settings::text( $row, $field['key'] );
				if ( ( $cheque_flow ? $field['key'] === 'due' : ! empty( $field['required'] ) ) && $value === '' ) { return new WP_Error( 'receipt', 'فیلد «' . $field['label'] . '» الزامی است.' ); }
				if ( $value !== '' && $field['type'] === 'number' && self::number( $value ) < 0 ) { return new WP_Error( 'receipt', 'عدد فیلد «' . $field['label'] . '» معتبر نیست.' ); }
				if ( $value !== '' && $field['type'] === 'date' && ! self::valid_receipt_date( $value ) ) { return new WP_Error( 'receipt', 'تاریخ فیلد «' . $field['label'] . '» معتبر نیست.' ); }
				if ( $value !== '' && $field['type'] === 'upload' ) {
					$owner = (int) get_transient( 'kerp_payment_upload_' . hash( 'sha256', $value ) );
					if ( $owner !== get_current_user_id() ) { return new WP_Error( 'receipt', 'فایل رسید باید توسط شما در همین فرم بارگذاری شود.' ); }
				}
				$clean[ $field['key'] ] = $value;
				if ( $cheque_flow && $value !== '' && $field['type'] === 'date' ) {
					$clean[$field['key']] = KERP_Modules_Payments_Cheques::date( $value );
					if ( ! $clean[$field['key']] ) { return new WP_Error( 'receipt', 'تاریخ شمسی معتبر وارد کنید.' ); }
				}
			}
			$rows[] = $clean;
		}
		if ( ! $rows || count( $rows ) > 50 ) { return new WP_Error( 'receipt', 'حداقل یک و حداکثر ۵۰ ردیف رسید ثبت کنید.' ); }
		return [ 'rows' => $rows, 'fields' => $config['fields'], 'status' => $config['status'] ];
	}
	public static function attach( int $payment_id, WC_Order $order, string $method, array $receipt ): bool|WP_Error {
		if ( ! KERP_Modules_Payments_Deposit::payable( $order ) ) { return new WP_Error( 'deposit', 'ساختار یا وضعیت سفارش پیش‌پرداخت معتبر نیست.' ); }
		if ( $order->get_meta( '_kerp_installment_is_parent' ) || $order->is_paid() || (float) $order->get_total() <= 0 || ! $order->has_status( [ 'pending', 'failed', 'finance-review' ] ) ) { return new WP_Error( 'order', 'این سفارش قابل پرداخت نیست.' ); }
		if ( $receipt['rows'] && abs( array_sum( array_column( $receipt['rows'], 'amount' ) ) - (float) $order->get_total() ) > pow( 10, -wc_get_price_decimals() ) / 2 ) { return new WP_Error( 'amount', 'جمع مبالغ رسیدها باید دقیقاً برابر مبلغ قابل پرداخت (' . wp_strip_all_tags( $order->get_formatted_order_total() ) . ') باشد.' ); }
		$offline = (bool) $receipt['rows'];
		$payload = wp_json_encode( $receipt );
		if ( ! KERP_Modules_Payments_Store::update( $payment_id, [ 'order_id' => $order->get_id(), 'amount' => $order->get_total(), 'currency' => $order->get_currency(), 'status' => $offline ? 'review' : 'pending', 'payload' => $payload ] ) ) { return new WP_Error( 'storage', 'ثبت سند پرداخت انجام نشد.' ); }
		$order->set_payment_method( $method ); $order->set_payment_method_title( KERP_Modules_Payments_Settings::methods()[ $method ] );
		$order->update_meta_data( '_kerp_payment_id', $payment_id );
		if ( ! $offline ) { $order->update_meta_data( '_kerp_payment_gateway', $method ); } else { $order->delete_meta_data( '_kerp_payment_gateway' ); }
		$order->save();
		if ( $offline && $receipt['status'] === 'completed' ) {
			$order->payment_complete(); $order->update_status( 'completed', 'ثبت پرداخت طبق تنظیمات روش آفلاین.' ); self::changed( $order->get_id() );
		} else { $order->update_status( $offline ? 'finance-review' : 'pending', $offline ? 'رسید بازاریاب ثبت شد؛ در انتظار تأیید مالی.' : 'لینک پرداخت برای مشتری آماده است.' ); }
		return TRUE;
	}
	public static function changed( int $id ): void {
		static $running = FALSE; if ( $running ) { return; } $running = TRUE;
		try {
			$order = wc_get_order( $id ); if ( ! $order ) { return; }
			KERP_Modules_Payments_Deposit::sync( $order );
			$payment_id = (int) $order->get_meta( '_kerp_payment_id' );
			if ( $payment_id ) {
				$payment = KERP_Modules_Payments_Store::get( $payment_id );
				if ( $payment && (int) $payment['order_id'] === $id && (int) $payment['customer_id'] === (int) $order->get_customer_id() && $payment['currency'] === $order->get_currency() && abs( (float) $payment['amount'] - (float) $order->get_total() ) < 0.000001 ) {
					$status = (float) $order->get_total_refunded() > 0 ? 'refunded' : ( $order->is_paid() ? 'paid' : ( $order->has_status( [ 'cancelled', 'failed', 'refunded' ] ) ? 'rejected' : $payment['status'] ) );
					$payload = json_decode( $payment['payload'], TRUE ) ?: [];
					if ( empty( $payload['cheque_flow'] ) || in_array( $status, [ 'refunded', 'rejected' ], TRUE ) ) { KERP_Modules_Payments_Store::update( $payment_id, [ 'status' => $status ] ); }
				}
			}
			$contract_id = (int) $order->get_meta( '_kerp_installment_contract' );
			if ( ! $contract_id ) { return; }
			$contract = KERP_Modules_Installment_Management_Store::get( $contract_id );
			if ( ! $contract || $contract['status'] !== 'active' ) { return; }
			$first = wc_get_order( $contract['orders'][0] );
			if ( empty( $contract['plan']['parent_order_id'] ) && $first && $first->is_paid() && (float) $first->get_total_refunded() <= 0 ) {
				$stage = KERP_Modules_Installment_Management_Service::stage( $contract );
				$first->update_status( $stage === count( $contract['orders'] ) ? 'completed' : 'installments' );
			}
			KERP_Modules_Installment_Management_Service::sync( $contract_id );
		} finally { $running = FALSE; }
	}
}
