<?php
defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Payments_Settings {
	
	public const OPTION = 'kerp_payments_settings';
	
	public static function text( array $data, string $key ): string {
		return isset( $data[ $key ] ) && is_scalar( $data[ $key ] ) ? sanitize_text_field( (string) $data[ $key ] ) : '';
	}
	
	public static function labels(): array {
		return [ 'card' => 'کارت‌به‌کارت / کارتخوان', 'cheque' => 'چک', 'usdt' => 'تتر', 'cash_hand' => 'دریافت نقدی' ];
	}
	
	public static function types(): array {
		return [
			'text'     => 'متن',
			'textarea' => 'توضیحات',
			'number'   => 'عدد',
			'date'     => 'تاریخ',
			'upload'   => 'فایل / رسید',
		];
	}
	
	public static function all(): array {
		$saved  = (array) get_option( self::OPTION, [] );
		$result = [];
		foreach ( self::labels() as $key => $label ) {
			$fields         = match ( $key ) {
				'cash_hand' => [ [ 'key' => 'note', 'label' => 'توضیحات دریافت نقدی', 'type' => 'textarea', 'required' => '0' ] ],
				'card' => [
					[ 'key' => 'bank', 'label' => 'بانک / بانک کارتخوان', 'type' => 'text', 'required' => '1' ],
					[
						'key'      => 'account',
						'label'    => 'شماره حساب / کارت مقصد',
						'type'     => 'text',
						'required' => '0',
					],
					[ 'key' => 'reference', 'label' => 'شماره پیگیری', 'type' => 'text', 'required' => '1' ],
					[ 'key' => 'receipt', 'label' => 'تصویر رسید', 'type' => 'upload', 'required' => '1' ],
				],
				'cheque' => [
					[ 'key' => 'bank', 'label' => 'بانک', 'type' => 'text', 'required' => '1' ],
					[
						'key'      => 'number',
						'label'    => 'شماره چک / شناسه صیادی',
						'type'     => 'text',
						'required' => '1',
					],
					[ 'key' => 'due', 'label' => 'تاریخ سررسید', 'type' => 'date', 'required' => '1' ],
					[ 'key' => 'owner', 'label' => 'صادرکننده', 'type' => 'text', 'required' => '1' ],
				],
				default => [
					[ 'key' => 'network', 'label' => 'شبکه انتقال', 'type' => 'text', 'required' => '1' ],
					[ 'key' => 'txid', 'label' => 'شناسه تراکنش (TxID)', 'type' => 'text', 'required' => '1' ],
					[ 'key' => 'quantity', 'label' => 'تعداد تتر', 'type' => 'number', 'required' => '1' ],
					[ 'key' => 'wallet', 'label' => 'آدرس کیف پول مقصد', 'type' => 'text', 'required' => '1' ],
				],
			};
			$result[ $key ] = $saved[ $key ] ?? [ 'enabled' => '0', 'status' => 'finance-review', 'fields' => $fields ];
		}
		
		return $result;
	}
	
	public static function cash_sms(): array {
		$saved = (array) get_option( self::OPTION, [] );
		return array_merge( [ 'enabled' => '0', 'pattern' => '', 'variables' => 'token:{payment_url}' ], (array) ( $saved['cash_sms'] ?? [] ) );
	}

	public static function sms_variables( string $text ): array|WP_Error {
		$variables = [];
		foreach ( preg_split( '/\s*;\s*/u', $text, -1, PREG_SPLIT_NO_EMPTY ) ?: [] as $part ) {
			$pair = preg_split( '/[:=]/', $part, 2 );
			$name = trim( $pair[0] );
			if ( count( $pair ) !== 2 || ! preg_match( '/^[A-Za-z][A-Za-z0-9_-]*$/D', $name ) || in_array( $name, [ 'receptor', 'pattern' ], TRUE ) || isset( $variables[ $name ] ) || trim( $pair[1] ) === '' ) {
				return new WP_Error( 'sms_variables', 'متغیرهای پیامک را با کلید یکتا و ساختار token:{payment_url} وارد کنید.' );
			}
			$value = trim( $pair[1] );
			preg_match_all( '/\{[^{}]+\}/', $value, $matches );
			if ( array_diff( $matches[0], KERP_Modules_Payments_SMS::variables() ) ) {
				return new WP_Error( 'sms_variables', 'متغیر ناشناخته‌ای در تنظیمات پیامک وجود دارد.' );
			}
			$variables[ $name ] = $value;
		}
		return $variables;
	}

	public static function save( array $input, ?array $cash_sms = NULL ): bool|WP_Error {
		$result = [];
		$result['cash_sms'] = self::cash_sms();
		if ( $cash_sms !== NULL ) {
			// Shared form serialization sends checked switches as ['1'].
			if ( isset( $cash_sms['enabled'] ) && is_array( $cash_sms['enabled'] ) ) { $cash_sms['enabled'] = $cash_sms['enabled'] === [ '1' ] ? '1' : '0'; }
			$result['cash_sms'] = [ 'enabled' => self::text( $cash_sms, 'enabled' ) === '1' ? '1' : '0', 'pattern' => self::text( $cash_sms, 'pattern' ), 'variables' => self::text( $cash_sms, 'variables' ) ];
			$variables = self::sms_variables( $result['cash_sms']['variables'] );
			if ( is_wp_error( $variables ) ) { return $variables; }
			if ( $result['cash_sms']['enabled'] === '1' && ( $result['cash_sms']['pattern'] === '' || ! str_contains( implode( ';', $variables ), '{payment_url}' ) ) ) {
				return new WP_Error( 'sms', 'برای فعال‌سازی پیامک، نام پترن و متغیر {payment_url} را وارد کنید.' );
			}
		}
		foreach ( self::labels() as $key => $label ) {
			$row    = (array) ( $input[ $key ] ?? [] );
			$fields = [];
			$status = self::text( $row, 'status' );
			if ( ! in_array( $status, [ 'finance-review', 'completed' ], TRUE ) ) {
				return new WP_Error( 'status', 'وضعیت پس از ثبت معتبر نیست.' );
			}
			foreach ( (array) ( $row['fields'] ?? [] ) as $field ) {
				if ( ! is_array( $field ) ) {
					return new WP_Error( 'fields', 'فیلد نامعتبر است.' );
				}
				$name  = self::text( $field, 'key' );
				$title = self::text( $field, 'label' );
				if ( $name === '' && $title === '' ) {
					continue;
				}
				$type = self::text( $field, 'type' );
				if ( ! preg_match( '/^[a-z][a-z0-9_]{0,39}$/D', $name ) || $name === 'amount' || isset( $fields[ $name ] ) || $title === '' || ! isset( self::types()[ $type ] ) ) {
					return new WP_Error( 'fields', 'کلید لاتین یکتا، عنوان و نوع معتبر برای هر فیلد لازم است؛ کلید amount رزرو شده است.' );
				}
				$fields[ $name ] = [
					'key'      => $name,
					'label'    => $title,
					'type'     => $type,
					'required' => self::text( $field, 'required' ) === '1' ? '1' : '0',
				];
			}
			if ( count( $fields ) > 30 ) {
				return new WP_Error( 'fields', 'حداکثر ۳۰ فیلد برای هر روش مجاز است.' );
			}
			$result[ $key ] = [
				'enabled' => ! empty( $row['enabled'] ) ? '1' : '0',
				'status'  => $status,
				'fields'  => array_values( $fields ),
			];
		}
		update_option( self::OPTION, $result, FALSE );
		
		return TRUE;
	}
	
	public static function methods(): array {
		$result = [];
		foreach ( WC()->payment_gateways()->payment_gateways() as $id => $gateway ) {
			if ( $gateway->enabled === 'yes' && ! in_array( $id, [ 'bacs', 'cheque', 'cod' ], TRUE ) ) {
				$title = wp_strip_all_tags( $gateway->get_title() );
				$result[ $id ] = str_contains( $title, 'پرداخت آنلاین' ) ? $title : $title . ' (پرداخت آنلاین)';
			}
		}
		foreach ( self::all() as $key => $row ) {
			if ( ! empty( $row['enabled'] ) ) {
				$result[ 'kerp_' . $key ] = self::labels()[ $key ];
			}
		}
		
		if ( isset( $result['kerp_card'], $result['kerp_cheque'] ) ) {
			$result['kerp_mixed'] = 'ترکیبی: کارت‌به‌کارت / کارتخوان + چک';
		}
		return $result;
	}
	
	public static function fields( string $key ): array {
		$result = [
			[
				'name'           => 'amount',
				'label'          => 'مبلغ این ردیف (' . get_woocommerce_currency_symbol() . ')',
				'type'           => 'price',
				'repeater_class' => 'col-12 col-sm-6 col-lg-4',
			],
		];
		if ( $key === 'cheque' && KERP_Modules_Payments_Cheques::enabled() ) {
			$result[] = [ 'name' => 'due', 'label' => 'سررسید چک (شمسی)', 'type' => 'date', 'repeater_class' => 'col-12 col-sm-6' ];
			return $result;
		}
		foreach ( self::all()[ $key ]['fields'] as $field ) {
			$result[] = [
				'name'           => $field['key'],
				'label'          => $field['label'] . ( ! empty( $field['required'] ) ? ' *' : '' ),
				'type'           => $field['type'],
				'action'         => 'payments_upload',
				'max_files'      => 1,
				'repeater_class' => in_array( $field['type'], [ 'upload', 'textarea' ], TRUE ) ? 'col-12' : ( $field['type'] === 'date' ? 'col-12 col-sm-6' : 'col-12 col-sm-6 col-lg-4' ),
			];
		}
		
		return $result;
	}
	
}
