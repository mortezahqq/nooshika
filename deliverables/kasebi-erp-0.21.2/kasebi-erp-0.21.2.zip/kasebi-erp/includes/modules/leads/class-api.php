<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Leads_Api {
	private static ?self $instance = NULL;
	public static function instance(): self { return self::$instance ??= new self(); }
	private function __construct() {
		if ( (string) get_option( 'kerp_leads_webhook_key', '' ) === '' ) update_option( 'kerp_leads_webhook_key', wp_generate_password( 40, FALSE, FALSE ), FALSE );
		add_action( 'kasebi_ajax_leads_exit_pipeline', [ $this, 'ajax_exit_pipeline' ] );
		add_action( 'kasebi_ajax_leads_update_membership', [ $this, 'ajax_update_membership' ] );
		add_action( 'kasebi_ajax_leads_membership_bulk', [ $this, 'ajax_membership_bulk' ] );
		add_action( 'kasebi_ajax_leads_history', [ $this, 'ajax_history' ] );
		add_action( 'kasebi_ajax_leads_customer_info', [ $this, 'ajax_customer_info' ] );
		add_action( 'kasebi_ajax_leads_delete_campaign', [ $this, 'ajax_delete_campaign' ] );
		add_action( 'rest_api_init', [ $this, 'register_routes' ] );
		add_action( 'kasebi_ajax_leads_save_campaign', [ $this, 'ajax_save_campaign' ] );
		add_action( 'kasebi_ajax_leads_duplicate_campaign', [ $this, 'ajax_duplicate_campaign' ] );
		add_action( 'kasebi_ajax_leads_pipeline_bulk', [ $this, 'ajax_pipeline_bulk' ] );
		add_action( 'kasebi_ajax_leads_save_stage', [ $this, 'ajax_save_stage' ] );
		add_action( 'kasebi_ajax_leads_save_stage_sms', [ $this, 'ajax_save_stage_sms' ] );
		add_action( 'kasebi_ajax_leads_save_exit_sms', [ $this, 'ajax_save_exit_sms' ] );
		add_action( 'kasebi_ajax_leads_save_stage_actions', [ $this, 'ajax_save_stage_actions' ] );
        add_action( 'kasebi_ajax_leads_run_stage_action', [ $this, 'ajax_run_stage_action' ] );
		add_action( 'kasebi_ajax_leads_grant_stage_course', [ $this, 'ajax_grant_stage_course' ] );
		add_action( 'kasebi_ajax_leads_no_answer', [ $this, 'ajax_no_answer' ] );
		add_action( 'kasebi_ajax_leads_delete_stage', [ $this, 'ajax_delete_stage' ] );
		add_action( 'kasebi_ajax_leads_search_products', [ $this, 'ajax_search_products' ] );
		add_action( 'kasebi_ajax_leads_search_lessons', [ $this, 'ajax_search_lessons' ] );
		add_action( 'kasebi_ajax_leads_search_courses', [ $this, 'ajax_search_courses' ] );
		add_action( 'kasebi_ajax_leads_upsert', [ $this, 'ajax_upsert' ] );
		add_action( 'kasebi_ajax_leads_move_stage', [ $this, 'ajax_move_stage' ] );
		add_action( 'kasebi_ajax_leads_set_attendance', [ $this, 'ajax_set_attendance' ] );
		add_action( 'kasebi_ajax_leads_assign_owner', [ $this, 'ajax_assign_owner' ] );
		add_action( 'kasebi_ajax_leads_branch', [ $this, 'ajax_branch' ] );
		add_action( 'kasebi_ajax_leads_save_settings', [ $this, 'ajax_save_settings' ] );
		add_action( 'kasebi_ajax_leads_save_sales_pool', [ $this, 'ajax_save_sales_pool' ] );
		add_action( 'kasebi_ajax_leads_import', [ $this, 'ajax_import' ] );
		add_action( 'admin_post_kerp_leads_import', [ $this, 'post_import' ] );
	}
	private function __clone() {}
	public function __wakeup(): void { throw new LogicException( 'Cannot unserialize a singleton.' ); }

	public function register_routes(): void {
		register_rest_route( 'kasebi-erp/v1', '/leads', [ 'methods' => 'POST', 'callback' => [ $this, 'rest_upsert' ], 'permission_callback' => [ $this, 'webhook_permission' ] ] );
		register_rest_route( 'kasebi-erp/v1', '/leads/stage', [ 'methods' => 'POST', 'callback' => [ $this, 'rest_stage' ], 'permission_callback' => [ $this, 'webhook_permission' ] ] );
		register_rest_route( 'kasebi-erp/v1', '/leads/attendance', [ 'methods' => 'POST', 'callback' => [ $this, 'rest_attendance' ], 'permission_callback' => [ $this, 'webhook_permission' ] ] );
		register_rest_route( 'kasebi-erp/v1', '/leads/import', [ 'methods' => 'POST', 'callback' => [ $this, 'rest_import' ], 'permission_callback' => [ $this, 'manage_permission' ] ] );
	}

	public function webhook_permission( WP_REST_Request $request ): bool|WP_Error {
		if ( $this->can_manage() ) return TRUE;
		$provided = (string) ( $request->get_header( 'X-KERP-Webhook-Key' ) ?: $request->get_param( 'api_key' ) );
		$stored = (string) get_option( 'kerp_leads_webhook_key', '' );
		return $stored !== '' && $provided !== '' && hash_equals( $stored, $provided ) ? TRUE : new WP_Error( 'kerp_webhook_unauthorized', 'کلید Webhook معتبر نیست.', [ 'status' => 401 ] );
	}
	public function manage_permission(): bool { return $this->can_manage(); }

	public function rest_upsert( WP_REST_Request $request ): WP_REST_Response|WP_Error {
		$data = (array) $request->get_json_params();
		if ( ! $data ) $data = $request->get_params();
		$data['event_type'] = 'webhook';
		$result = KERP_Modules_Leads_Service::instance()->upsert_lead( $data );
		return is_wp_error( $result ) ? $result : new WP_REST_Response( $result, ! empty( $result['created'] ) ? 201 : 200 );
	}
	public function rest_stage( WP_REST_Request $request ): WP_REST_Response|WP_Error {
		$data = (array) ( $request->get_json_params() ?: $request->get_params() ); $user_id = absint( $data['user_id'] ?? 0 );
		if ( ! $user_id && ! empty( $data['phone'] ) ) { $user_id = KERP_Helpers_Phone::get_user_id( (string) $data['phone'] ); if ( ! $user_id ) $user_id = KERP_Helpers_Phone::get_user_id( (string) $data['phone'], 'billing_phone' ); }
		$external_id = sanitize_text_field( (string) ( $data['external_id'] ?? '' ) );
		$result = KERP_Modules_Leads_Service::instance()->move_stage( $user_id, absint( $data['campaign_id'] ?? 0 ), absint( $data['stage_id'] ?? 0 ), [ 'event_type' => 'webhook', 'fingerprint' => $external_id !== '' ? 'webhook:' . $external_id : '', 'payload' => (array) ( $data['payload'] ?? [] ) ] );
		return is_wp_error( $result ) ? $result : new WP_REST_Response( [ 'success' => TRUE, 'user_id' => $user_id ] );
	}
	public function rest_attendance( WP_REST_Request $request ): WP_REST_Response|WP_Error {
		$data = (array) ( $request->get_json_params() ?: $request->get_params() ); $user_id = absint( $data['user_id'] ?? 0 );
		if ( ! $user_id && ! empty( $data['phone'] ) ) { $user_id = KERP_Helpers_Phone::get_user_id( (string) $data['phone'] ); if ( ! $user_id ) $user_id = KERP_Helpers_Phone::get_user_id( (string) $data['phone'], 'billing_phone' ); }
		$result = KERP_Modules_Leads_Service::instance()->set_attendance( $user_id, absint( $data['campaign_id'] ?? 0 ), sanitize_key( (string) ( $data['attendance'] ?? '' ) ), [ 'source' => 'webhook' ] );
		return is_wp_error( $result ) ? $result : new WP_REST_Response( [ 'success' => TRUE, 'user_id' => $user_id ] );
	}
	public function rest_import( WP_REST_Request $request ): WP_REST_Response|WP_Error {
		$files = $request->get_file_params(); $file = $files['file'] ?? [];
		if ( empty( $file['tmp_name'] ) ) return new WP_Error( 'kerp_import_missing', 'فایل CSV یا XLSX ارسال نشده است.', [ 'status' => 400 ] );
		$result = KERP_Modules_Leads_Importer::import_file( (string) $file['tmp_name'], [ 'campaign_id' => absint( $request->get_param( 'campaign_id' ) ), 'stage_id' => absint( $request->get_param( 'stage_id' ) ), 'source' => sanitize_text_field( (string) $request->get_param( 'source' ) ) ?: 'import' ] );
		return is_wp_error( $result ) ? $result : new WP_REST_Response( $result );
	}

    public function ajax_update_membership(): void {
        $this->guard_manage();
        foreach ( [ 'user_id', 'campaign_id', 'stage_id', 'owner_id' ] as $key ) {
            if ( ! isset( $_POST[ $key ] ) || ! is_scalar( $_POST[ $key ] ) || ! preg_match( '/^[0-9]+$/D', (string) $_POST[ $key ] ) ) $this->respond( new WP_Error( 'invalid_input', 'اطلاعات فرم معتبر نیست.' ), '' );
        }
        $note = isset( $_POST['note'] ) && is_string( $_POST['note'] ) ? wp_kses_post( wp_unslash( $_POST['note'] ) ) : '';
        if ( trim( wp_strip_all_tags( $note ) ) === '' ) $note = '';
        $result = KERP_Modules_Leads_Service::instance()->update_membership( absint( $_POST['user_id'] ), absint( $_POST['campaign_id'] ), absint( $_POST['stage_id'] ), absint( $_POST['owner_id'] ), $note );
        $this->respond( $result, 'تغییرات مسیر فروش ذخیره شد.' );
    }

    public function ajax_membership_bulk(): void {
        $this->guard_manage();
        global $wpdb;
        $operation = $_POST['operation'] ?? '';
        if ( ! is_string( $operation ) || ! in_array( $operation, [ 'owner', 'stage', 'exit', 'course' ], TRUE ) ) $this->respond( new WP_Error( 'operation', 'عملیات معتبر نیست.' ), '' );
        $ids = $_POST['membership_ids'] ?? [];
        if ( ! is_array( $ids ) || ! $ids || count( $ids ) > 100 ) $this->respond( new WP_Error( 'selection', 'بین ۱ تا ۱۰۰ ردیف انتخاب کنید.' ), '' );
        foreach ( $ids as $id ) if ( ! is_scalar( $id ) || ! ctype_digit( (string) $id ) || ! (int) $id ) $this->respond( new WP_Error( 'selection', 'انتخاب ردیف معتبر نیست.' ), '' );
        $ids = array_values( array_unique( array_map( 'absint', $ids ) ) );
        $service = KERP_Modules_Leads_Service::instance();
        $owner = isset( $_POST['owner_id'] ) && is_scalar( $_POST['owner_id'] ) ? absint( $_POST['owner_id'] ) : 0;
        $campaign = isset( $_POST['campaign_id'] ) && is_scalar( $_POST['campaign_id'] ) ? absint( $_POST['campaign_id'] ) : 0;
        $stage = isset( $_POST['stage_id'] ) && is_scalar( $_POST['stage_id'] ) ? absint( $_POST['stage_id'] ) : 0;
        if ( $operation === 'owner' ) {
            if ( ! is_array( $_POST['confirm_replace'] ?? NULL ) || ! in_array( 'yes', $_POST['confirm_replace'], TRUE ) ) $this->respond( new WP_Error( 'confirmation', 'جایگزینی کارشناس قبلی را تأیید کنید.' ), '' );
            if ( ! isset( $service->sales_employee_options()[ $owner ] ) ) $this->respond( new WP_Error( 'owner', 'کارشناس فعال انتخاب کنید.' ), '' );
        } elseif ( $operation === 'course' ) {
            if ( ! is_array( $_POST['confirm_course'] ?? NULL ) || ! in_array( 'yes', $_POST['confirm_course'], TRUE ) ) $this->respond( new WP_Error( 'confirmation', 'اعطای دسترسی دوره را تأیید کنید.' ), '' );
        } elseif ( $operation === 'exit' ) {
            if ( ! is_array( $_POST['confirm_exit'] ?? NULL ) || ! in_array( 'yes', $_POST['confirm_exit'], TRUE ) ) $this->respond( new WP_Error( 'confirmation', 'خروج مشتریان انتخاب‌شده را تأیید کنید.' ), '' );
        } else {
            $valid = $service->validate_destination( $campaign, $stage );
            if ( ! $stage || is_wp_error( $valid ) ) $this->respond( new WP_Error( 'stage', 'مسیر و مرحله معتبر انتخاب کنید.' ), '' );
        }
        $table = KERP_Modules_Leads_Module::table( 'memberships' );
        $rows = (array) $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE id IN (" . implode( ',', array_fill( 0, count( $ids ), '%d' ) ) . ')', ...$ids ), ARRAY_A );
        if ( count( $rows ) !== count( $ids ) ) $this->respond( new WP_Error( 'missing', 'برخی ردیف‌ها دیگر موجود نیستند؛ صفحه را تازه کنید.' ), '' );
        if ( $operation === 'course' ) {
            $done = 0; $failed = 0; $existing = 0; $unconfigured = 0; $errors = [];
            foreach ( $rows as $row ) {
                $course_id = (int) ( $service->stage_actions( (int) $row['current_stage_id'] )['course_access'] ?? 0 );
                if ( ! $course_id ) { ++$unconfigured; continue; }
                $outcome = $service->grant_stage_course( (int) $row['user_id'], (int) $row['campaign_id'], (int) $row['current_stage_id'], $course_id );
                if ( ! is_wp_error( $outcome ) ) ++$done;
                elseif ( $outcome->get_error_code() === 'already_enrolled' ) ++$existing;
                else { ++$failed; $errors[] = [ 'membership_id'=>(int) $row['id'], 'message'=>$outcome->get_error_message() ]; }
            }
            $this->respond( [ 'updated'=>$done, 'failed'=>$failed, 'existing'=>$existing, 'unconfigured'=>$unconfigured, 'errors'=>$errors ], sprintf( '%d دسترسی ثبت شد؛ %d ردیف از قبل دسترسی داشت؛ %d ردیف بدون اقدام دوره؛ %d ردیف ناموفق.', $done, $existing, $unconfigured, $failed ) );
        }
        foreach ( $rows as $row ) if ( $operation === 'stage' && (int) $row['campaign_id'] !== $campaign ) $this->respond( new WP_Error( 'scope', 'تمام ردیف‌ها باید متعلق به مسیر فروش انتخاب‌شده باشند.' ), '' );
        $note = isset( $_POST['note'] ) && is_string( $_POST['note'] ) ? wp_kses_post( wp_unslash( $_POST['note'] ) ) : '';
        if ( trim( wp_strip_all_tags( $note ) ) === '' ) $note = '';
        $done = 0; $failed = 0;
        foreach ( $rows as $row ) {
            $result = $operation === 'exit'
                ? $service->exit_pipeline( (int) $row['user_id'], (int) $row['campaign_id'], $note, (int) $row['current_stage_id'] )
                : $service->update_membership( (int) $row['user_id'], (int) $row['campaign_id'], $operation === 'stage' ? $stage : (int) $row['current_stage_id'], $operation === 'owner' ? $owner : (int) $row['owner_id'], $note );
            if ( is_wp_error( $result ) ) ++$failed; else ++$done;
        }
        $this->respond( [ 'updated' => $done, 'failed' => $failed ], sprintf( '%d ردیف ذخیره شد؛ %d ردیف ناموفق بود.', $done, $failed ) );
    }

	public function ajax_history(): void {
		$this->guard_nonce();
		if ( ! current_user_can( KERP_Admin::CAPABILITY ) && ! kerp_can( 'leads.view', 'view' ) ) {
			$this->respond( new WP_Error( 'forbidden', 'دسترسی کافی ندارید.' ), '' );
		}
		$user_id = isset( $_POST['user_id'] ) && is_scalar( $_POST['user_id'] ) ? absint( $_POST['user_id'] ) : 0;
		$campaign_id = isset( $_POST['campaign_id'] ) && is_scalar( $_POST['campaign_id'] ) ? absint( $_POST['campaign_id'] ) : 0;
		$page = isset( $_POST['history_page'] ) && is_scalar( $_POST['history_page'] ) ? absint( $_POST['history_page'] ) : 1;
		$service = KERP_Modules_Leads_Service::instance();
		$campaign = $service->get_campaign( $campaign_id );
		if ( ! $user_id || ! $campaign || ! $service->get_membership( $user_id, $campaign_id ) ) {
			$this->respond( new WP_Error( 'not_found', 'عضویت مشتری در این مسیر فروش پیدا نشد.' ), '' );
		}
		$history = $service->get_membership_history( $user_id, $campaign_id, $page );
        $order_details = [];
        foreach ( $history['items'] as &$event ) {
            $payload = json_decode( (string) $event['payload'], TRUE );
            $order_id = is_array( $payload ) && is_scalar( $payload['order_id'] ?? NULL ) ? absint( $payload['order_id'] ) : 0;
            if ( ! $order_id ) continue;
            if ( ! array_key_exists( $order_id, $order_details ) ) {
                $order_details[ $order_id ] = NULL;
                $order = function_exists( 'wc_get_order' ) ? wc_get_order( $order_id ) : FALSE;
                if ( $order && $order instanceof WC_Order ) {
                    $order_user = (int) $order->get_user_id();
                    if ( ! $order_user && $order->get_billing_phone() !== '' ) {
                        $order_user = (int) KERP_Helpers_Phone::get_user_id( $order->get_billing_phone() );
                        if ( ! $order_user ) $order_user = (int) KERP_Helpers_Phone::get_user_id( $order->get_billing_phone(), 'billing_phone' );
                    }
                    if ( $order_user === $user_id ) {
                        $utm = [];
                        foreach ( [ 'utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content' ] as $key ) {
                            $value = $order->get_meta( '_wc_order_attribution_' . $key, TRUE );
                            if ( is_scalar( $value ) && trim( (string) $value ) !== '' ) $utm[ $key ] = (string) $value;
                        }
                        $order_details[ $order_id ] = [ 'number' => $order->get_order_number(), 'utm' => $utm ];
                    }
                }
            }
            $event['order_details'] = $order_details[ $order_id ];
        }
        unset( $event );
		$user = get_userdata( $user_id );
		ob_start();
		KERP_Helpers_Template::render_template( 'modules/leads/partials/history.php', [
			'history' => $history, 'user_id' => $user_id, 'campaign_id' => $campaign_id,
			'customer_name' => $user ? get_user_name_by_id( $user_id ) : '#' . $user_id,
			'campaign_name' => $campaign['name'],
		] );
		wp_send_json( [ 'status' => 'success', 'html' => ob_get_clean() ] );
	}

    public function ajax_customer_info(): void {
        $this->guard_nonce();
        if ( ! current_user_can( KERP_Admin::CAPABILITY ) && ! kerp_can( 'leads.view', 'view' ) ) $this->respond( new WP_Error( 'forbidden', 'دسترسی کافی ندارید.' ), '' );
        foreach ( [ 'user_id', 'campaign_id' ] as $key ) {
            if ( ! is_scalar( $_POST[$key] ?? NULL ) || ! ctype_digit( (string) $_POST[$key] ) || (int) $_POST[$key] < 1 ) $this->respond( new WP_Error( 'invalid_input', 'مشتری و مسیر فروش معتبر انتخاب کنید.' ), '' );
        }
        $info_kind = $_POST['info_kind'] ?? '';
        if ( ! in_array( $info_kind, [ 'registration', 'utm' ], TRUE ) ) $this->respond( new WP_Error( 'invalid_input', 'نوع اطلاعات معتبر نیست.' ), '' );
        $user_id = (int) $_POST['user_id']; $campaign_id = (int) $_POST['campaign_id'];
        $service = KERP_Modules_Leads_Service::instance();
        $campaign = $service->get_campaign( $campaign_id );
        $membership = $service->get_membership( $user_id, $campaign_id );
        if ( ! $campaign || ! $membership ) $this->respond( new WP_Error( 'not_found', 'عضویت مشتری در این مسیر فروش پیدا نشد.' ), '' );
        $page = is_scalar( $_POST['info_page'] ?? NULL ) ? max( 1, absint( $_POST['info_page'] ) ) : 1;
        $responses = KERP_Modules_Leads_Registration::get_response_page( $user_id, $campaign_id, $page );
        $customer_name = get_userdata( $user_id ) ? get_user_name_by_id( $user_id ) : '#' . $user_id;
        $campaign_name = $campaign['name'];
        ob_start();
        KERP_Helpers_Template::render_template( 'modules/leads/partials/customer-info.php', compact( 'responses', 'membership', 'info_kind', 'user_id', 'campaign_id', 'customer_name', 'campaign_name' ) );
        wp_send_json( [ 'status' => 'success', 'html' => ob_get_clean() ] );
    }

	public function ajax_duplicate_campaign(): void {
		$this->guard_settings();
		$id = $_POST['campaign_id'] ?? '';
		if ( ! is_scalar( $id ) || ! ctype_digit( (string) $id ) || (int) $id < 1 || ! is_string( $_POST['name'] ?? NULL ) ) $this->respond( new WP_Error( 'invalid_pipeline', 'اطلاعات مسیر فروش معتبر نیست.' ), '' );
		$result = KERP_Modules_Leads_Service::instance()->duplicate_campaign( (int) $id, wp_unslash( $_POST['name'] ) );
		if ( ! is_wp_error( $result ) ) $_POST['page'] = '/erp/marketing/pipelines/' . $result . '/';
		$this->respond( $result, 'مسیر فروش با تمام تنظیمات و مراحل تکثیر شد.' );
	}

    public function ajax_delete_campaign(): void {
        $this->guard_settings();
        $id = $_POST['campaign_id'] ?? '';
        if ( ! is_scalar( $id ) || ! ctype_digit( (string) $id ) || (int) $id < 1 ) $this->respond( new WP_Error( 'invalid_pipeline', 'مسیر فروش معتبر نیست.' ), '' );
        if ( ! is_array( $_POST['confirm_delete'] ?? NULL ) || ! in_array( 'yes', $_POST['confirm_delete'], TRUE ) ) $this->respond( new WP_Error( 'confirm_delete', 'حذف مسیر و سوابق آن را تأیید کنید.' ), '' );
        $this->respond( KERP_Modules_Leads_Service::instance()->delete_campaign( (int) $id ), 'مسیر فروش حذف شد.' );
    }

	public function ajax_save_campaign(): void { $this->guard_settings(); $result = KERP_Modules_Leads_Service::instance()->save_campaign( $this->post_array( 'campaign' ), absint( $_POST['campaign_id'] ?? 0 ) ); $this->respond( $result, 'کمپین ذخیره شد.' ); }
	public function ajax_save_exit_sms(): void {
		$this->guard_settings();
		$id = $_POST['campaign_id'] ?? '';
		if ( ! is_scalar( $id ) || ! ctype_digit( (string) $id ) || (int) $id < 1 || ! is_array( $_POST['exit_sms'] ?? NULL ) ) $this->respond( new WP_Error( 'invalid', 'تنظیمات یا مسیر فروش معتبر نیست.' ), '' );
		$this->respond( KERP_Modules_Leads_SMS::save_exit( (int) $id, $this->post_array( 'exit_sms' ) ), 'تنظیمات پیامک خروج ذخیره شد.' );
	}
	public function ajax_save_stage_actions(): void {
		$this->guard_settings();
		foreach ( [ 'campaign_id', 'stage_id' ] as $key ) {
			$value = $_POST[$key] ?? '';
			if ( ! is_scalar( $value ) || ! ctype_digit( (string) $value ) || (int) $value < 1 ) $this->respond( new WP_Error( 'invalid', 'مسیر یا مرحله معتبر نیست.' ), '' );
		}
        if ( ! is_array( $_POST['stage_buttons'] ?? NULL ) ) $this->respond( new WP_Error( 'invalid', 'ساختار دکمه‌ها معتبر نیست؛ صفحه را تازه کنید.' ), '' );
		$this->respond( KERP_Modules_Leads_Actions::save( (int) $_POST['campaign_id'], (int) $_POST['stage_id'], $this->post_array( 'stage_buttons' ) ), 'اقدام‌های مرحله ذخیره شدند.' );
	}
    public function ajax_run_stage_action(): void {
        $this->guard_manage();
        foreach ( [ 'user_id','campaign_id','stage_id' ] as $key ) if ( ! is_scalar( $_POST[$key] ?? NULL ) || ! ctype_digit( (string) $_POST[$key] ) || (int) $_POST[$key] < 1 ) $this->respond( new WP_Error( 'invalid', 'اطلاعات مشتری یا مرحله معتبر نیست.' ), '' );
        foreach ( [ 'button_key','revision','request_id','due_date','due_time','note' ] as $key ) if ( isset( $_POST[$key] ) && ! is_string( $_POST[$key] ) ) $this->respond( new WP_Error( 'invalid', 'اطلاعات اقدام معتبر نیست.' ), '' );
        $this->respond( KERP_Modules_Leads_Actions::execute( (int) $_POST['user_id'], (int) $_POST['campaign_id'], (int) $_POST['stage_id'], wp_unslash( $_POST['button_key'] ?? '' ), wp_unslash( $_POST['revision'] ?? '' ), wp_unslash( $_POST['request_id'] ?? '' ), wp_unslash( $_POST['due_date'] ?? '' ), wp_unslash( $_POST['due_time'] ?? '' ), wp_unslash( $_POST['note'] ?? '' ) ), 'اقدام مرحله اجرا شد.' );
    }
	public function ajax_grant_stage_course(): void {
		$this->guard_manage();
		foreach ( [ 'user_id', 'campaign_id', 'stage_id', 'course_id' ] as $key ) {
			$value = $_POST[$key] ?? '';
			if ( ! is_scalar( $value ) || ! ctype_digit( (string) $value ) || (int) $value < 1 ) $this->respond( new WP_Error( 'invalid', 'اطلاعات اقدام معتبر نیست.' ), '' );
		}
		$this->respond( KERP_Modules_Leads_Service::instance()->grant_stage_course( (int) $_POST['user_id'], (int) $_POST['campaign_id'], (int) $_POST['stage_id'], (int) $_POST['course_id'] ), 'دسترسی دوره برای مشتری ثبت شد.' );
	}
    public function ajax_no_answer(): void {
        $this->guard_manage();
        if ( ! current_user_can( KERP_Admin::CAPABILITY ) && ! kerp_can( 'followups.create', 'action' ) ) $this->respond( new WP_Error( 'permission', 'دسترسی ثبت پیگیری ندارید.' ), '' );
        foreach ( [ 'user_id', 'campaign_id', 'stage_id' ] as $key ) if ( ! is_scalar( $_POST[$key] ?? NULL ) || ! ctype_digit( (string) $_POST[$key] ) || (int) $_POST[$key] < 1 ) $this->respond( new WP_Error( 'invalid', 'اطلاعات مشتری یا مرحله معتبر نیست.' ), '' );
        foreach ( [ 'due_date', 'due_time', 'request_id', 'note' ] as $key ) if ( isset( $_POST[$key] ) && ! is_string( $_POST[$key] ) ) $this->respond( new WP_Error( 'invalid', 'اطلاعات پیگیری معتبر نیست.' ), '' );
        $this->respond( KERP_Modules_Leads_Service::instance()->record_no_answer( (int) $_POST['user_id'], (int) $_POST['campaign_id'], (int) $_POST['stage_id'], wp_unslash( $_POST['due_date'] ?? '' ), wp_unslash( $_POST['due_time'] ?? '' ), wp_unslash( $_POST['note'] ?? '' ), wp_unslash( $_POST['request_id'] ?? '' ) ), 'عدم پاسخ ثبت شد؛ پیگیری ساخته شد و پیامک‌های تنظیم‌شده در صف قرار گرفتند.' );
    }
	public function ajax_save_stage_sms(): void {
		$this->guard_settings();
		foreach ( [ 'campaign_id', 'stage_id' ] as $key ) {
			$value = $_POST[$key] ?? '';
			if ( ! is_scalar( $value ) || ! ctype_digit( (string) $value ) || (int) $value < 1 ) $this->respond( new WP_Error( 'stage', 'مرحله یا مسیر فروش معتبر نیست.' ), '' );
		}
		if ( isset( $_POST['sms_rules'] ) && ! is_array( $_POST['sms_rules'] ) ) $this->respond( new WP_Error( 'rules', 'تنظیمات پیامک معتبر نیست.' ), '' );
		$this->respond( KERP_Modules_Leads_SMS::save( (int) $_POST['campaign_id'], (int) $_POST['stage_id'], $this->post_array( 'sms_rules' ) ), 'تنظیمات پیامک مرحله ذخیره شد؛ زمان‌بندی برای ورودهای بعدی اعمال می‌شود.' );
	}
	public function ajax_delete_stage(): void {
		$this->guard_settings();
		foreach ( [ 'campaign_id', 'stage_id' ] as $key ) {
			$value = $_POST[$key] ?? '';
			if ( ! is_scalar( $value ) || ! ctype_digit( (string) $value ) || (int) $value < 1 ) $this->respond( new WP_Error( 'invalid_stage', 'مرحله یا مسیر فروش معتبر نیست.' ), '' );
		}
		if ( ! is_array( $_POST['confirm_delete'] ?? NULL ) || ! in_array( 'yes', $_POST['confirm_delete'], TRUE ) ) $this->respond( new WP_Error( 'confirm_delete', 'حذف دائمی مرحله را تأیید کنید.' ), '' );
		$this->respond( KERP_Modules_Leads_Service::instance()->delete_stage( (int) $_POST['campaign_id'], (int) $_POST['stage_id'] ), 'مرحله حذف شد.' );
	}
	public function ajax_save_stage(): void { $this->guard_settings(); $result = KERP_Modules_Leads_Service::instance()->save_stage( $this->post_array( 'stage' ), absint( $_POST['stage_id'] ?? 0 ) ); $this->respond( $result, 'مرحله ذخیره شد.' ); }
	public function ajax_exit_pipeline(): void {
		$this->guard_manage();
		foreach ( [ 'user_id', 'campaign_id', 'expected_stage_id' ] as $key ) {
			if ( ! isset( $_POST[$key] ) || ! is_scalar( $_POST[$key] ) || ! ctype_digit( (string) $_POST[$key] ) ) $this->respond( new WP_Error( 'invalid_input', 'اطلاعات خروج معتبر نیست.' ), '' );
		}
		$note = isset( $_POST['note'] ) && is_string( $_POST['note'] ) ? wp_kses_post( wp_unslash( $_POST['note'] ) ) : '';
		$this->respond( KERP_Modules_Leads_Service::instance()->exit_pipeline( (int) $_POST['user_id'], (int) $_POST['campaign_id'], $note, (int) $_POST['expected_stage_id'] ), 'خروج مشتری از مسیر فروش ثبت شد.' );
	}

	public function ajax_upsert(): void { $this->guard_manage(); $data = $this->post_array( 'lead' ) ?: wp_unslash( $_POST ); $result = KERP_Modules_Leads_Service::instance()->upsert_lead( $data ); $this->respond( $result, 'مشتری بالقوه ثبت شد.' ); }
	public function ajax_move_stage(): void { $this->guard_manage(); $result = KERP_Modules_Leads_Service::instance()->move_stage( absint( $_POST['user_id'] ?? 0 ), absint( $_POST['campaign_id'] ?? 0 ), absint( $_POST['stage_id'] ?? 0 ), [ 'event_type' => 'manual', 'payload' => [ 'note' => sanitize_textarea_field( wp_unslash( (string) ( $_POST['note'] ?? '' ) ) ) ] ] ); $this->respond( $result, 'مرحله مشتری بالقوه تغییر کرد.' ); }
	public function ajax_set_attendance(): void { $this->guard_manage(); $result = KERP_Modules_Leads_Service::instance()->set_attendance( absint( $_POST['user_id'] ?? 0 ), absint( $_POST['campaign_id'] ?? 0 ), sanitize_key( wp_unslash( (string) ( $_POST['attendance'] ?? '' ) ) ) ); $this->respond( $result, 'وضعیت حضور ذخیره شد.' ); }
	public function ajax_assign_owner(): void { $this->guard_manage(); $result = KERP_Modules_Leads_Service::instance()->assign_owner( absint( $_POST['user_id'] ?? 0 ), absint( $_POST['campaign_id'] ?? 0 ), absint( $_POST['owner_id'] ?? 0 ) ); $this->respond( $result, 'کارشناس فروش تخصیص داده شد.' ); }
	public function ajax_branch(): void {
		$this->guard_manage();
		$rich_note = isset( $_POST['note_format'] ) && $_POST['note_format'] === 'html';
        $note = isset( $_POST['note'] ) && is_string( $_POST['note'] ) ? wp_unslash( $_POST['note'] ) : '';
        if ( $rich_note && trim( wp_strip_all_tags( $note ) ) === '' ) $note = '';
		$ids = isset( $_POST['user_ids'] ) && is_array( $_POST['user_ids'] ) ? $_POST['user_ids'] : [ $_POST['user_id'] ?? 0 ];
		$result = KERP_Modules_Leads_Service::instance()->branch_many( $ids, absint( $_POST['source_campaign_id'] ?? 0 ), absint( $_POST['source_stage_id'] ?? 0 ), absint( $_POST['target_campaign_id'] ?? 0 ), absint( $_POST['target_stage_id'] ?? 0 ), $rich_note ? wp_kses_post( $note ) : sanitize_textarea_field( $note ), $rich_note );
		if ( is_wp_error( $result ) ) $this->respond( $result, '' );
		$message = sprintf( '%d کاربر اضافه شد؛ %d کاربر قبلاً عضو بود؛ %d خطا.', $result['added'], $result['existing'], $result['failed'] );
		if ( $result['errors'] ) $message .= ' ' . implode( ' / ', array_slice( $result['errors'], 0, 5 ) );
		$this->respond( $result, $message );
	}
	public function ajax_save_settings(): void {
		$this->guard_settings(); $settings = $this->post_array( 'settings' );
		if ( array_key_exists( 'sales_users', $settings ) ) {
			$result = KERP_Modules_Leads_Service::instance()->save_sales_pool( $settings['sales_users'] );
			if ( is_wp_error( $result ) ) $this->respond( $result, '' );
		}
		if ( isset( $settings['gf_phone_fields'] ) ) {
			$map = []; foreach ( (array) $settings['gf_phone_fields'] as $form => $field ) if ( absint( $form ) && sanitize_text_field( (string) $field ) !== '' ) $map[ absint( $form ) ] = sanitize_text_field( (string) $field ); update_option( 'kerp_leads_gf_phone_fields', $map, FALSE );
		}
		if ( ! empty( $settings['regenerate_key'] ) ) update_option( 'kerp_leads_webhook_key', wp_generate_password( 40, FALSE, FALSE ), FALSE );
		$this->respond( TRUE, 'تنظیمات مشتری بالقوه ذخیره شد.' );
	}
	public function ajax_import(): void { $this->guard_manage(); if ( empty( $_FILES['file']['tmp_name'] ) ) wp_send_json_error( [ 'message' => 'فایل ارسال نشده است.' ], 400 ); $result = KERP_Modules_Leads_Importer::import_file( (string) $_FILES['file']['tmp_name'], [ 'campaign_id' => absint( $_POST['campaign_id'] ?? 0 ), 'stage_id' => absint( $_POST['stage_id'] ?? 0 ), 'source' => sanitize_text_field( wp_unslash( (string) ( $_POST['source'] ?? 'import' ) ) ) ] ); $this->respond( $result, 'ورود گروهی انجام شد.' ); }
	public function post_import(): void {
		if ( ! $this->can_manage() ) wp_die( 'دسترسی کافی ندارید.' );
		check_admin_referer( 'kerp_leads_import' );
		$result = empty( $_FILES['file']['tmp_name'] ) ? new WP_Error( 'missing', 'فایل ارسال نشده است.' ) : KERP_Modules_Leads_Importer::import_file( (string) $_FILES['file']['tmp_name'], [ 'campaign_id' => absint( $_POST['campaign_id'] ?? 0 ), 'stage_id' => absint( $_POST['stage_id'] ?? 0 ), 'source' => sanitize_text_field( wp_unslash( (string) ( $_POST['source'] ?? 'import' ) ) ) ] );
		$key = 'kerp_leads_import_' . get_current_user_id(); set_transient( $key, is_wp_error( $result ) ? [ 'error' => $result->get_error_message() ] : $result, 120 );
		wp_safe_redirect( home_url( '/erp/leads/?import_result=1' ) ); exit;
	}

	public function ajax_search_courses(): void {
		$this->guard_settings();
		if ( ! function_exists( 'ld_update_course_access' ) ) wp_send_json( [ 'status'=>'error', 'results'=>[], 'message'=>'لرندش فعال نیست.' ], 503 );
		$search = isset( $_POST['search'] ) && is_string( $_POST['search'] ) ? sanitize_text_field( wp_unslash( $_POST['search'] ) ) : '';
		if ( mb_strlen( $search ) < 2 ) wp_send_json( [ 'results'=>[] ] );
		$query = new WP_Query( [ 'post_type'=>'sfwd-courses', 'post_status'=>'publish', 's'=>mb_substr( $search, 0, 100 ), 'posts_per_page'=>30, 'orderby'=>'title', 'order'=>'ASC', 'no_found_rows'=>TRUE ] );
		$results = [];
		foreach ( $query->posts as $post ) $results[] = [ 'id'=>$post->ID, 'text'=>wp_strip_all_tags( $post->post_title ) . ' (#' . $post->ID . ')' ];
		wp_send_json( [ 'results'=>$results ] );
	}

	public function ajax_search_lessons(): void {
		$this->guard_settings();
		if ( ! function_exists( 'learndash_process_mark_complete' ) ) wp_send_json( [ 'status' => 'error', 'results' => [], 'message' => 'لرندش فعال نیست.' ], 503 );
		$search = isset( $_POST['search'] ) && is_string( $_POST['search'] ) ? sanitize_text_field( wp_unslash( $_POST['search'] ) ) : '';
		if ( mb_strlen( $search ) < 2 ) wp_send_json( [ 'results' => [] ] );
		$query = new WP_Query( [ 'post_type' => [ 'sfwd-lessons', 'sfwd-topic' ], 'post_status' => 'publish', 's' => mb_substr( $search, 0, 100 ), 'posts_per_page' => 30, 'orderby' => 'title', 'order' => 'ASC', 'no_found_rows' => TRUE ] );
		$results = [];
		foreach ( $query->posts as $post ) {
			$results[] = [ 'id' => $post->ID, 'text' => wp_strip_all_tags( $post->post_title ) . ' — ' . ( $post->post_type === 'sfwd-lessons' ? 'درس' : 'مبحث' ) . ' (#' . $post->ID . ')' ];
		}
		wp_send_json( [ 'results' => $results ] );
	}

	public function ajax_search_products(): void {
		$this->guard_settings();
		if ( ! class_exists( 'WC_Data_Store' ) || ! function_exists( 'wc_get_product' ) ) wp_send_json( [ 'results' => [], 'message' => 'ووکامرس فعال نیست.' ], 503 );
		$search = isset( $_POST['search'] ) && is_string( $_POST['search'] ) ? sanitize_text_field( wp_unslash( $_POST['search'] ) ) : '';
		if ( mb_strlen( $search ) < 2 ) wp_send_json( [ 'results' => [] ] );
		$search = mb_substr( $search, 0, 100 );
		$ids = WC_Data_Store::load( 'product' )->search_products( $search, '', TRUE, FALSE, 30 );
		$results = [];
		foreach ( array_slice( $ids, 0, 30 ) as $id ) {
			$product = wc_get_product( $id );
			if ( ! $product || in_array( $product->get_status(), [ 'trash', 'auto-draft' ], TRUE ) ) continue;
			$results[] = [ 'id' => $product->get_id(), 'text' => wp_strip_all_tags( $product->get_formatted_name() ) ];
		}
		wp_send_json( [ 'results' => $results ] );
	}

	public function ajax_save_sales_pool(): void {
		$this->guard_settings();
		$settings = $this->post_array( 'settings' );
		$result = KERP_Modules_Leads_Service::instance()->save_sales_pool( $settings['sales_users'] ?? [] );
		$this->respond( $result, 'کارشناسان فروش چرخشی ذخیره شدند.' );
	}

	public function ajax_pipeline_bulk(): void {
		$this->guard_settings();
		$operation = isset( $_POST['operation'] ) && is_string( $_POST['operation'] ) ? sanitize_key( wp_unslash( $_POST['operation'] ) ) : '';
		if ( ! in_array( $operation, [ 'active', 'archived' ], TRUE ) ) $this->respond( new WP_Error( 'operation', 'عملیات معتبر نیست.' ), '' );
		$raw_ids = $_POST['customer_ids'] ?? [];
		if ( ! is_array( $raw_ids ) || count( $raw_ids ) > 100 || array_filter( $raw_ids, 'is_array' ) ) $this->respond( new WP_Error( 'selection', 'انتخاب معتبر نیست.' ), '' );
		$ids = array_values( array_unique( array_filter( array_map( 'absint', $raw_ids ) ) ) );
		if ( ! $ids ) $this->respond( new WP_Error( 'selection', 'حداقل یک مسیر فروش را انتخاب کنید.' ), '' );
		global $wpdb;
		$table = KERP_Modules_Leads_Module::table( 'campaigns' );
		$placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
		$count = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE id IN ({$placeholders})", ...$ids ) );
		if ( $count !== count( $ids ) ) $this->respond( new WP_Error( 'missing', 'یکی از مسیرهای فروش پیدا نشد؛ صفحه را تازه کنید.' ), '' );
		$result = $wpdb->query( $wpdb->prepare( "UPDATE {$table} SET status=%s,updated_at=%s WHERE id IN ({$placeholders})", ...array_merge( [ $operation, current_time( 'mysql' ) ], $ids ) ) );
		$this->respond( $result === FALSE ? new WP_Error( 'save', 'تغییر وضعیت انجام نشد.' ) : $result, 'وضعیت مسیرهای فروش انتخاب‌شده ذخیره شد؛ اعضا و سوابق حفظ شدند.' );
	}

	private function respond( mixed $result, string $message ): void {
		if ( is_wp_error( $result ) ) wp_send_json( [ 'status' => 'error', 'message' => $result->get_error_message(), 'msg' => $result->get_error_message() ] );
		$data = [ 'status' => 'success', 'message' => $message, 'msg' => $message, 'result' => $result ];
		$page = sanitize_text_field( wp_unslash( (string) ( $_POST['page'] ?? '' ) ) );
		if ( $page !== '' ) $data = array_merge( $data, KERP_Api_Page_Content::build_page_response( $page, [], TRUE ) );
		wp_send_json( $data );
	}
	private function post_array( string $key ): array { return isset( $_POST[ $key ] ) && is_array( $_POST[ $key ] ) ? (array) wp_unslash( $_POST[ $key ] ) : []; }
	private function guard_nonce(): void {
		$nonce = isset( $_POST['leads_nonce'] ) && is_string( $_POST['leads_nonce'] ) ? wp_unslash( $_POST['leads_nonce'] ) : '';
		if ( ! is_user_logged_in() || ! KERP_App::instance()->current_user_has_access() || ! wp_verify_nonce( $nonce, 'kerp_leads' ) ) $this->respond( new WP_Error( 'kerp_leads_nonce', 'دسترسی یا اعتبار فرم کافی نیست؛ صفحه را تازه کنید.' ), '' );
	}
	private function guard_manage(): void { $this->guard_nonce(); if ( ! $this->can_manage() ) $this->respond( new WP_Error( 'kerp_leads_forbidden', 'دسترسی کافی ندارید.' ), '' ); }
	private function guard_settings(): void { $this->guard_nonce(); if ( ! current_user_can( KERP_Admin::CAPABILITY ) && ( ! function_exists( 'kerp_can' ) || ! kerp_can( 'leads.manage_settings', 'action' ) ) ) $this->respond( new WP_Error( 'kerp_leads_forbidden', 'دسترسی کافی ندارید.' ), '' ); }
	private function can_manage(): bool { return current_user_can( KERP_Admin::CAPABILITY ) || ( function_exists( 'kerp_can' ) && kerp_can( 'leads.manage', 'action' ) ); }
}
