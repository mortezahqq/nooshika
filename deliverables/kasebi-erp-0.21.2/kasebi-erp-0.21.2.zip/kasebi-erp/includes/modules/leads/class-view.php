<?php
defined( 'ABSPATH' ) || exit;

/** Shared, escaped form controls for the ERP's delegated form handler. */
final class KERP_Modules_Leads_View {
	public static function can_manage(): bool { return current_user_can( KERP_Admin::CAPABILITY ) || kerp_can( 'leads.manage', 'action' ); }
	public static function can_configure(): bool { return current_user_can( KERP_Admin::CAPABILITY ) || kerp_can( 'leads.manage_settings', 'action' ); }
	public static function open_form( string $action, string $page, array $hidden = [] ): void {
		echo '<form class="modal_form kerp-leads-form" data-action="' . esc_attr( $action ) . '" data-page="' . esc_attr( $page ) . '">';
		self::hidden( 'leads_nonce', wp_create_nonce( 'kerp_leads' ) );
		foreach ( $hidden as $key => $value ) self::hidden( $key, $value );
	}
	public static function hidden( string $key, mixed $value ): void { echo '<input type="hidden" data-for="' . esc_attr( $key ) . '" name="' . esc_attr( $key ) . '" value="' . esc_attr( (string) $value ) . '">'; }
	public static function input( string $key, string $label, mixed $value = '', string $type = 'text', bool $required = FALSE ): void {
		echo '<label class="form-group d-block"><span class="form-label">' . esc_html( $label ) . '</span><input class="form-control" name="' . esc_attr( $key ) . '" data-for="' . esc_attr( $key ) . '" type="' . esc_attr( $type ) . '" value="' . esc_attr( (string) $value ) . '"' . ( $required ? ' required data-req="1"' : '' ) . '></label>';
	}
	public static function select( string $key, string $label, array $choices, mixed $value = '', string $extra = '' ): void {
		echo '<label class="form-group d-block"><span class="form-label">' . esc_html( $label ) . '</span><select class="form-select" name="' . esc_attr( $key ) . '" data-for="' . esc_attr( $key ) . '" ' . $extra . '>';
		foreach ( $choices as $id => $name ) echo '<option value="' . esc_attr( (string) $id ) . '"' . selected( (string) $value, (string) $id, FALSE ) . '>' . esc_html( $name ) . '</option>';
		echo '</select></label>';
	}
	public static function pipeline_picker( string $campaign_key, string $stage_key, int $campaign_id = 0, int $stage_id = 0, int $exclude = 0, bool $filter = FALSE, ?array $allowed_campaign_ids = NULL ): void {
		$service = KERP_Modules_Leads_Service::instance();
		$choices = [ 0 => $filter ? 'همه مسیرهای فروش' : 'انتخاب مسیر فروش' ];
		foreach ( $service->get_campaigns() as $campaign ) {
            if ( $allowed_campaign_ids !== NULL && ! in_array( (int) $campaign['id'], $allowed_campaign_ids, TRUE ) ) continue;
			if ( (int) $campaign['id'] !== $exclude && ( $filter || $campaign['status'] === 'active' ) ) $choices[ $campaign['id'] ] = $campaign['name'];
		}
		echo '<div class="kerp-pipeline-picker row g-2">';
		echo '<div class="col-md-6">'; self::select( $campaign_key, 'مسیر فروش', $choices, $campaign_id, 'data-lead-pipeline' ); echo '</div>';
		echo '<div class="col-md-6"><label class="form-group d-block"><span class="form-label">مرحله</span><select class="form-select" name="' . esc_attr( $stage_key ) . '" data-for="' . esc_attr( $stage_key ) . '" data-lead-stage><option value="0">' . ( $filter ? 'همه مراحل' : 'انتخاب مرحله' ) . '</option>';
		foreach ( $service->get_all_stages() as $stage ) {
			if ( ! isset( $choices[ $stage['campaign_id'] ] ) || ( ! $filter && empty( $stage['active'] ) ) ) continue;
			$visible = (int) $stage['campaign_id'] === $campaign_id;
			echo '<option data-pipeline="' . absint( $stage['campaign_id'] ) . '" value="' . absint( $stage['id'] ) . '"' . selected( $stage_id, (int) $stage['id'], FALSE ) . ( $visible ? '' : ' hidden disabled' ) . '>' . esc_html( $stage['name'] ) . '</option>';
		}
		echo '</select></label></div></div>';
	}
	public static function submit( string $label ): void { echo '<button type="button" class="btn btn-primary submit_modal_form">' . esc_html( $label ) . '</button>'; }
	public static function stage_form( int $campaign_id, array $stage = [] ): void {
		$next_position = 10;
		if ( ! $stage ) foreach ( KERP_Modules_Leads_Service::instance()->get_stages( $campaign_id ) as $item ) $next_position = max( $next_position, (int) $item['position'] + 10 );
		self::open_form( 'leads_save_stage', '/erp/marketing/pipelines/' . $campaign_id . '/', [ 'stage_id' => $stage['id'] ?? 0, 'stage[campaign_id]' => $campaign_id ] );
		echo '<div class="row g-3"><div class="col-md-4">'; self::input( 'stage[name]', 'عنوان مرحله', $stage['name'] ?? '', 'text', TRUE ); echo '</div><div class="col-md-2">';
		self::input( 'stage[position]', 'ترتیب', $stage['position'] ?? $next_position, 'number' ); echo '</div><div class="col-md-3">';
		self::select( 'stage[trigger_type]', 'ورود به مرحله با', [ '' => 'انتخاب کنید' ] + KERP_Modules_Leads_Pipeline_View::triggers( TRUE ), $stage['trigger_type'] ?? 'manual', 'required data-req="1"' ); echo '</div><div class="col-md-3">';
		self::input( 'stage[trigger_ref]', 'شناسه فرم / محصول', $stage['trigger_ref'] ?? '' ); echo '</div><div class="col-md-4">';
		self::select( 'stage[active]', 'وضعیت مرحله', [ 1 => 'فعال', 0 => 'غیرفعال (حفظ سابقه)' ], $stage['active'] ?? 1 ); echo '</div></div>';
		self::submit( $stage ? 'ذخیره مرحله' : 'افزودن مرحله به این مسیر فروش' ); echo '</form>';
	}
}
