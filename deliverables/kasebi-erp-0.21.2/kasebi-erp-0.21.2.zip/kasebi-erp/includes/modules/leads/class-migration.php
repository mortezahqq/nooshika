<?php
defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Leads_Migration {
	/** Repair upgrades from schemas whose dbDelta definitions put multiple fields on one line. */
	public static function ensure_exit_column(): bool {
		global $wpdb;
		$table = KERP_Modules_Leads_Module::table( 'memberships' );
		$column_query = $wpdb->prepare( "SHOW COLUMNS FROM {$table} LIKE %s", $wpdb->esc_like( 'exited_at' ) );
		if ( $wpdb->get_var( $column_query ) === 'exited_at' ) return TRUE;
		$lock = 'kerp_lead_exit_schema_' . md5( $wpdb->prefix );
		if ( (int) $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 5)', $lock ) ) !== 1 ) return FALSE;
		try {
			// A concurrent request may have completed the upgrade while we waited.
			if ( $wpdb->get_var( $column_query ) === 'exited_at' ) return TRUE;
			if ( $wpdb->last_error ) return FALSE;
			if ( $wpdb->query( "ALTER TABLE {$table} ADD COLUMN exited_at DATETIME NULL DEFAULT NULL" ) === FALSE ) return FALSE;
			return $wpdb->get_var( $column_query ) === 'exited_at';
		} finally {
			$wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $lock ) );
		}
	}

	/** Preserve existing memberships and history while making legacy shared stages pipeline-owned. */
	public static function run(): bool {
		global $wpdb;
		$stages = KERP_Modules_Leads_Module::table( 'stages' );
		$members = KERP_Modules_Leads_Module::table( 'memberships' );
		$events = KERP_Modules_Leads_Module::table( 'events' );
		$campaigns = KERP_Modules_Leads_Module::table( 'campaigns' );
		$lock = 'kerp_lead_migrate_' . md5( $wpdb->prefix );
		if ( (int) $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 5)', $lock ) ) !== 1 ) return FALSE;
		try {
			// Branch membership and its two audit events must support rollback together.
			foreach ( [ $members, $events ] as $table ) {
				$status = $wpdb->get_row( $wpdb->prepare( 'SHOW TABLE STATUS WHERE Name=%s', $table ), ARRAY_A );
				if ( ! $status ) return FALSE;
				if ( strcasecmp( (string) $status['Engine'], 'InnoDB' ) !== 0 && $wpdb->query( "ALTER TABLE {$table} ENGINE=InnoDB" ) === FALSE ) return FALSE;
			}
			$legacy = $wpdb->get_results( "SELECT * FROM {$stages} WHERE campaign_id=0", ARRAY_A );
			if ( $wpdb->last_error ) return FALSE;
			foreach ( $legacy as $stage ) {
				$id = (int) $stage['id'];
				$ids = $wpdb->get_col( $wpdb->prepare( "SELECT campaign_id FROM {$members} WHERE current_stage_id=%d UNION SELECT campaign_id FROM {$events} WHERE stage_id=%d", $id, $id ) );
				if ( $wpdb->last_error ) return FALSE;
				foreach ( $ids as $campaign_id ) {
					$campaign_id = (int) $campaign_id;
					if ( ! $campaign_id ) continue;
					// Stable slug permits safe retries after a partially completed upgrade.
					$slug = 'legacy-stage-' . $id;
					$new_id = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$stages} WHERE campaign_id=%d AND slug=%s", $campaign_id, $slug ) );
					if ( ! $new_id ) {
						$copy = $stage; unset( $copy['id'] );
						$copy['campaign_id'] = $campaign_id; $copy['slug'] = $slug;
						if ( $wpdb->insert( $stages, $copy ) === FALSE ) return FALSE;
						$new_id = (int) $wpdb->insert_id;
					}
					if ( $wpdb->update( $members, [ 'current_stage_id' => $new_id ], [ 'campaign_id' => $campaign_id, 'current_stage_id' => $id ] ) === FALSE ) return FALSE;
					if ( $wpdb->update( $events, [ 'stage_id' => $new_id ], [ 'campaign_id' => $campaign_id, 'stage_id' => $id ] ) === FALSE ) return FALSE;
				}
			}
			// Keep old rows for audit/recovery; they are no longer selectable.
			if ( $wpdb->update( $stages, [ 'active' => 0 ], [ 'campaign_id' => 0 ] ) === FALSE ) return FALSE;
			return $wpdb->query( "UPDATE {$campaigns} SET type='pipeline' WHERE type IN ('campaign','webinar')" ) !== FALSE;
		} finally {
			$wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $lock ) );
		}
	}
}
