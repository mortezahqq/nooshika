<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Leads_Importer {
	public static function import_file( string $path, array $defaults = [] ): array|WP_Error {
		if ( ! is_readable( $path ) ) return new WP_Error( 'kerp_import_file', 'فایل ورودی قابل خواندن نیست.' );
		$ext = strtolower( pathinfo( $path, PATHINFO_EXTENSION ) );
		$signature = (string) file_get_contents( $path, FALSE, NULL, 0, 4 );
		$rows = $ext === 'xlsx' || str_starts_with( $signature, "PK\x03\x04" ) ? self::read_xlsx( $path ) : self::read_csv( $path );
		if ( is_wp_error( $rows ) ) return $rows;
		if ( ! $rows ) return [ 'created' => 0, 'updated' => 0, 'failed' => 0, 'errors' => [] ];
		$headers = array_map( [ self::class, 'normalize_header' ], array_shift( $rows ) );
		$result = [ 'created' => 0, 'updated' => 0, 'failed' => 0, 'errors' => [] ];
		foreach ( $rows as $index => $values ) {
			$row = array_combine( $headers, array_pad( array_slice( $values, 0, count( $headers ) ), count( $headers ), '' ) );
			if ( ! is_array( $row ) || empty( $row['phone'] ) ) { $result['failed']++; $result['errors'][] = 'ردیف ' . ( $index + 2 ) . ': موبایل خالی است.'; continue; }
			$utm = []; foreach ( [ 'utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content' ] as $key ) if ( ! empty( $row[ $key ] ) ) $utm[ $key ] = $row[ $key ];
			$lead = KERP_Modules_Leads_Service::instance()->upsert_lead( array_merge( $defaults, [ 'phone' => $row['phone'], 'name' => $row['name'] ?? '', 'source' => $row['source'] ?? ( $defaults['source'] ?? 'import' ), 'campaign_id' => absint( $row['campaign_id'] ?? ( $defaults['campaign_id'] ?? 0 ) ), 'stage_id' => absint( $row['stage_id'] ?? ( $defaults['stage_id'] ?? 0 ) ), 'owner_id' => absint( $row['owner_id'] ?? ( $defaults['owner_id'] ?? 0 ) ), 'utm' => $utm ] ) );
			if ( is_wp_error( $lead ) ) { $result['failed']++; $result['errors'][] = 'ردیف ' . ( $index + 2 ) . ': ' . $lead->get_error_message(); }
			elseif ( ! empty( $lead['created'] ) ) $result['created']++; else $result['updated']++;
		}
		$result['errors'] = array_slice( $result['errors'], 0, 50 );
		return $result;
	}

	private static function read_csv( string $path ): array|WP_Error {
		$handle = fopen( $path, 'rb' ); if ( ! $handle ) return new WP_Error( 'kerp_csv', 'CSV باز نشد.' );
		$sample = (string) fgets( $handle ); rewind( $handle ); $delimiter = substr_count( $sample, ';' ) > substr_count( $sample, ',' ) ? ';' : ',';
		$rows = []; while ( ( $row = fgetcsv( $handle, 0, $delimiter ) ) !== FALSE ) { if ( isset( $row[0] ) ) $row[0] = preg_replace( '/^\xEF\xBB\xBF/', '', (string) $row[0] ); $rows[] = $row; } fclose( $handle ); return $rows;
	}
	private static function read_xlsx( string $path ): array|WP_Error {
		if ( ! class_exists( 'ZipArchive' ) ) return new WP_Error( 'kerp_xlsx_zip', 'برای خواندن Excel افزونه ZipArchive لازم است.' );
		$zip = new ZipArchive(); if ( $zip->open( $path ) !== TRUE ) return new WP_Error( 'kerp_xlsx', 'فایل Excel معتبر نیست.' );
		$shared = []; $shared_xml = $zip->getFromName( 'xl/sharedStrings.xml' );
		if ( $shared_xml ) { $xml = simplexml_load_string( $shared_xml ); if ( $xml ) foreach ( $xml->si as $si ) { $text = ''; if ( isset( $si->t ) ) $text = (string) $si->t; else foreach ( $si->r as $run ) $text .= (string) $run->t; $shared[] = $text; } }
		$sheet_xml = $zip->getFromName( 'xl/worksheets/sheet1.xml' ); $zip->close(); if ( ! $sheet_xml ) return new WP_Error( 'kerp_xlsx_sheet', 'برگه اول Excel پیدا نشد.' );
		$xml = simplexml_load_string( $sheet_xml ); if ( ! $xml ) return new WP_Error( 'kerp_xlsx_xml', 'ساختار Excel خوانده نشد.' );
		$rows = []; foreach ( $xml->sheetData->row as $row ) { $values = []; $column = 0; foreach ( $row->c as $cell ) { $ref = (string) $cell['r']; preg_match( '/^[A-Z]+/', $ref, $m ); $target = self::column_index( $m[0] ?? 'A' ); while ( $column < $target ) { $values[] = ''; $column++; } $value = (string) $cell->v; if ( (string) $cell['t'] === 's' ) $value = $shared[ (int) $value ] ?? ''; elseif ( (string) $cell['t'] === 'inlineStr' ) $value = (string) $cell->is->t; $values[] = $value; $column++; } $rows[] = $values; }
		return $rows;
	}
	private static function column_index( string $letters ): int { $index = 0; foreach ( str_split( $letters ) as $char ) $index = $index * 26 + ord( $char ) - 64; return max( 0, $index - 1 ); }
	private static function normalize_header( string $header ): string { $header = strtolower( trim( preg_replace( '/^\xEF\xBB\xBF/', '', $header ) ) ); $map = [ 'mobile' => 'phone', 'موبایل' => 'phone', 'شماره موبایل' => 'phone', 'نام' => 'name', 'منبع' => 'source', 'کمپین' => 'campaign_id', 'مرحله' => 'stage_id', 'کارشناس' => 'owner_id' ]; return $map[ $header ] ?? sanitize_key( $header ); }
}
