<?php
defined( 'ABSPATH' ) || exit;

/** Presentation helpers for the marketing pipeline pages; existing lead services own writes. */
final class KERP_Modules_Leads_Pipeline_View {
	public const ROUTE = '/erp/marketing/pipelines/';

	public static function copy_identifier( int $id, string $label ): void {
		?>
		<button type="button" class="btn btn-sm btn-outline-primary clipboard-init my-2"
		        data-clipboard-text="<?php echo esc_attr( (string) $id ); ?>"
		        data-clip-text="کپی" data-clip-success="کپی شد" data-clip-error="کپی ناموفق بود"
		        aria-label="<?php echo esc_attr( 'کپی ' . $label . ' ' . $id ); ?>">
			<span><?php echo esc_html( $label ); ?>: <bdi dir="ltr"><?php echo esc_html( (string) $id ); ?></bdi></span>
			<em class="icon ni ni-copy" aria-hidden="true"></em><span class="clipboard-text" aria-live="polite">کپی</span>
		</button>
		<?php
	}

	public static function triggers( bool $selectable = FALSE ): array {
		$choices = [ 'manual' => 'تغییر دستی', 'gravity_form' => 'تکمیل فرم گرویتی', 'product_purchase' => 'خرید محصول', 'learndash_completed' => 'تکمیل درس لرندش در پنل کاربری' ];
		// Retain the display label for existing records, but do not offer this trigger in forms.
		if ( ! $selectable ) $choices += [ 'webhook' => 'رویداد سیستم دیگر', 'registration_started' => 'ارسال اطلاعات اولیه فرم', 'registration_completed' => 'تکمیل فرم پس از تأیید موبایل' ];
		return $choices;
	}

	private static function field( string $name, string $label, mixed $value = '', array $extra = [] ): array {
		return $extra + [ 'type' => 'text', 'name' => $name, 'label' => $label, 'value' => $value, 'input_class' => 'no_clear', 'class' => 'col-12' ];
	}

	private static function modal( string $id, string $title, string $action, string $route, array $fields, string $body = '' ): void {
		if ( ! KERP_Modules_Leads_View::can_configure() ) return;
		$fields[] = self::field( 'leads_nonce', '', wp_create_nonce( 'kerp_leads' ), [ 'type' => 'hidden' ] );
		foreach ( $fields as $index => &$field ) $field['id'] = $id . '-field-' . $index;
		unset( $field );
		KERP_Helpers_Template::render_modal( [ 'id' => $id, 'title' => $title, 'action' => $action, 'page' => $route, 'fields' => $fields, 'body' => $body, 'button' => 'ذخیره' ] );
	}

	public static function campaign_modal( array $row = [], string $route = self::ROUTE ): void {
		self::modal( 'kerpPipelineEdit' . (int) ( $row['id'] ?? 0 ), $row ? 'ویرایش مسیر فروش' : 'ساخت مسیر فروش', 'leads_save_campaign', $route, [
			self::field( 'campaign_id', '', $row['id'] ?? 0, [ 'type' => 'hidden' ] ),
			self::field( 'campaign[name]', 'نام مسیر فروش', $row['name'] ?? '', [ 'required' => TRUE ] ),
			self::field( 'campaign[status]', 'وضعیت', $row['status'] ?? 'active', [ 'type' => 'select', 'required' => TRUE, 'options' => [ 'active' => 'فعال', 'archived' => 'بایگانی (حفظ اعضا و سوابق)' ] ] ),
		] );
	}

	public static function duplicate_modal( array $row ): void {
		self::modal( 'kerpPipelineDuplicate' . (int) $row['id'], 'تکثیر مسیر فروش', 'leads_duplicate_campaign', self::ROUTE, [
			self::field( 'campaign_id', '', (int) $row['id'], [ 'type' => 'hidden' ] ),
			self::field( 'name', 'نام مسیر جدید', mb_substr( $row['name'], 0, 175 ) . ' (کپی)', [ 'required' => TRUE ] ),
		], '<div class="col-12"><p>تنظیمات مسیر، تمام مراحل فعال و غیرفعال، اتصال فرم‌ها و محصولات و تنظیمات پیامک مراحل کپی می‌شوند. مشتریان، تاریخچه و صف پیامک‌های قبلی کپی نمی‌شوند.</p><p class="text-soft">وضعیت فعال یا بایگانی مسیر نیز حفظ می‌شود؛ مسیر فعال جدید با همان اتصال‌های خودکار کار خواهد کرد.</p></div>' );
	}

	public static function stage_modal( int $campaign_id, array $row = [], int $next_position = 10 ): void {
		if ( KERP_Modules_Leads_Registration::is_reserved_stage( $row ) ) return;
		$trigger = $row['trigger_type'] ?? 'manual';
		$reference = absint( $row['trigger_ref'] ?? 0 );
		$forms = [];
		if ( class_exists( 'GFAPI' ) ) foreach ( GFAPI::get_forms( TRUE, FALSE ) as $form ) $forms[ (int) $form['id'] ] = $form['title'];
		if ( $trigger === 'gravity_form' && $reference && ! isset( $forms[ $reference ] ) ) $forms[ $reference ] = 'فرم قبلی در دسترس نیست؛ فرم دیگری انتخاب کنید';
		$products = [];
		if ( $trigger === 'product_purchase' && $reference ) {
			$product = function_exists( 'wc_get_product' ) ? wc_get_product( $reference ) : FALSE;
			$products[ $reference ] = $product ? wp_strip_all_tags( $product->get_formatted_name() ) : 'محصول قبلی در دسترس نیست؛ محصول دیگری انتخاب کنید';
		}
		self::modal( 'kerpPipelineStage' . (int) ( $row['id'] ?? 0 ), $row ? 'ویرایش مرحله' : 'افزودن مرحله', 'leads_save_stage', self::ROUTE . $campaign_id . '/', [
			self::field( 'stage_id', '', $row['id'] ?? 0, [ 'type' => 'hidden' ] ),
			self::field( 'stage[campaign_id]', '', $campaign_id, [ 'type' => 'hidden' ] ),
			self::field( 'stage[name]', 'عنوان مرحله', $row['name'] ?? '', [ 'required' => TRUE ] ),
			self::field( 'stage[position]', 'ترتیب نمایش (عدد کمتر، مرحله زودتر)', $row['position'] ?? $next_position, [ 'type' => 'number', 'class' => 'col-md-6' ] ),
			self::field( 'stage[active]', 'وضعیت مرحله', $row['active'] ?? 1, [ 'type' => 'select', 'required' => TRUE, 'class' => 'col-md-6', 'options' => [ 1 => 'فعال', 0 => 'غیرفعال (حفظ سابقه)' ] ] ),
			self::field( 'stage[trigger_type]', 'ورود به مرحله با', $trigger === 'webhook' ? '' : $trigger, [ 'type' => 'select', 'required' => TRUE, 'options' => self::triggers( TRUE ) ] ),
			self::field( 'stage[form_id]', 'فرم گرویتی', $trigger === 'gravity_form' ? $reference : '', [ 'type' => 'select', 'options' => $forms, 'placeholder' => $forms ? 'انتخاب فرم' : 'فرم فعالی در دسترس نیست', 'class' => 'col-12 kerp-lead-form-field' . ( $trigger === 'gravity_form' ? '' : ' d-none' ), 'disabled' => $trigger !== 'gravity_form', 'required' => TRUE ] ),
			self::field( 'stage[product_id]', 'محصول یا تنوع محصول', $trigger === 'product_purchase' ? $reference : '', [ 'type' => 'lead-product', 'selected_label' => $products[ $reference ] ?? '', 'class' => 'col-12 kerp-lead-product-field' . ( $trigger === 'product_purchase' ? '' : ' d-none' ) ] ),
			self::field( 'stage[lesson_id]', 'درس یا مبحث لرندش', $trigger === 'learndash_completed' ? $reference : '', [ 'type' => 'lead-product', 'resource_label' => 'درس یا مبحث', 'search_action' => 'leads_search_lessons', 'selected_label' => $trigger === 'learndash_completed' && $reference ? get_the_title( $reference ) : '', 'class' => 'col-12 kerp-lead-lesson-field' . ( $trigger === 'learndash_completed' ? '' : ' d-none' ) ] ),
		] );
	}

    public static function sms_modal( int $campaign_id, array $stage ): void {
        $config = KERP_Modules_Leads_SMS::config( (int)$stage['id'] );
        $config['rules'] = $config['rules'] ?? [];
        foreach ( $config['rules'] as &$rule ) $rule['trigger'] = $rule['trigger'] ?? 'entry';
        unset( $rule );
        $condition_fields = KERP_Modules_Leads_SMS::condition_fields( $campaign_id );
        ob_start();
        ?>
        <div class="col-12"><p class="fw-bold"><?php echo esc_html($stage['name']); ?></p><p class="text-soft">زمان از رویداد انتخاب‌شده (ورود به مرحله یا ثبت عدم پاسخ) محاسبه می‌شود؛ برای مثال عدد ۲۴ با واحد ساعت یعنی یک روز بعد. عدد صفر یعنی بدون زمان انتظار، در اولین نوبت ارسال پس از رویداد. متن پیامک در پنل سرویس پیامک و با کد پترن مشخص می‌شود. متغیرها را مانند <code dir="ltr">token:{customer_name}</code> وارد و با ; جدا کنید.</p><div class="alert alert-warning">ذخیره تنظیمات، پیامک‌های منتظر قبلی این مرحله را لغو می‌کند و فقط برای رویدادهای بعدی اعمال می‌شود. ارسال با زمان‌بند سایت انجام می‌شود و ممکن است در سایت کم‌ترافیک تأخیر داشته باشد.</div>
        <?php if ( ! class_exists('kasebiSMS') ) : ?><div class="alert alert-warning">سرویس پیامک در دسترس نیست؛ تا فعال‌شدن آن پیامک‌ها در صف می‌مانند.</div><?php endif; ?>
        <p class="text-soft">مقدار پترن می‌تواند ثابت یا ترکیبی باشد؛ مثال: <code dir="ltr">token:تهران;token2:سلام {customer_name}</code>. متن ثابت بدون تغییر ارسال می‌شود. شرط در زمان ارسال با آخرین پاسخ ثبت‌نام همین مسیر بررسی می‌شود؛ برای فیلد چندانتخابی، انتخاب‌شدن مقدار کافی است. پاسخ خالی یا نامطابق باعث لغو آن پیامک می‌شود.</p>
        <div class="row g-2 kerp-sms-variables mb-3">
        <div class="col-12 text-soft small">متغیر «پاسخ فرم» را کپی و بعد از نام توکن پترن قرار دهید. آخرین پاسخ ثبت‌نام همین مشتری در این مسیر هنگام ارسال استفاده می‌شود؛ پاسخ‌های چندانتخابی با «،» جدا و پاسخ ثبت‌نشده خالی ارسال می‌شود.</div>
        <?php foreach(KERP_Modules_Leads_SMS::variables( $campaign_id ) as $token=>$label) : ?>
        <div class="col-12 col-sm-6"><button type="button" class="kerp-sms-variable clipboard-init" data-clipboard-text="<?php echo esc_attr($token); ?>" data-clip-text="کپی" data-clip-success="کپی شد" data-clip-error="ناموفق"><span class="kerp-sms-variable__content"><span class="kerp-sms-variable__label"><?php echo esc_html($label); ?></span><code class="kerp-sms-variable__code"><?php echo esc_html($token); ?></code></span><span class="kerp-sms-variable__copy"><em class="icon ni ni-copy"></em><span class="clipboard-text">کپی</span></span></button></div>
        <?php endforeach; ?></div></div>
        <?php
        $body = ob_get_clean();
        self::modal( 'kerpStageSMS' . (int)$stage['id'], 'پیامک‌های زمان‌بندی‌شده مرحله', 'leads_save_stage_sms', self::ROUTE . $campaign_id . '/', [
            self::field('campaign_id','',$campaign_id,['type'=>'hidden']),
            self::field('stage_id','',$stage['id'],['type'=>'hidden']),
            ['type'=>'repeater','name'=>'sms_rules','label'=>'پیامک‌ها','class'=>'col-12','row_class'=>'col-12','button_text'=>'افزودن پیامک','value'=>$config['rules']??[], 'fields'=>[
                ['type'=>'select','name'=>'enabled','label'=>'وضعیت','options'=>['0'=>'غیرفعال','1'=>'فعال'],'class'=>'col-md-6'],
                ['type'=>'select','name'=>'trigger','label'=>'رویداد شروع زمان‌بندی','options'=>['entry'=>'ورود به مرحله','no_answer'=>'ثبت عدم پاسخ مشتری'],'class'=>'col-md-6'],
                ['type'=>'text','name'=>'delay','label'=>'زمان انتظار پس از رویداد','class'=>'col-md-6'],
                ['type'=>'select','name'=>'unit','label'=>'واحد تأخیر','options'=>['hour'=>'ساعت','day'=>'روز','minute'=>'دقیقه'],'class'=>'col-md-6'],
                ['type'=>'text','name'=>'pattern','label'=>'کد پترن پیامک','class'=>'col-md-6'],
                ['type'=>'textarea','name'=>'variables','label'=>'متغیرهای پترن','class'=>'col-12'],
                ['type'=>'select','name'=>'condition_field','label'=>'ارسال فقط برای پاسخ این فیلد','options'=>[ '0'=>'بدون شرط' ] + $condition_fields,'class'=>'col-md-6'],
                ['type'=>'text','name'=>'condition_value','label'=>'پاسخ برابر با','class'=>'col-md-6','placeholder'=>'مثلاً تهران','conditional'=>TRUE,'cond_meta'=>'condition_field','cond_operator'=>'==','cond_expected'=>wp_json_encode( array_keys( $condition_fields ) )],
                ['type'=>'select','name'=>'stay','label'=>'در صورت خروج از مرحله','options'=>['1'=>'لغو پیامک منتظر','0'=>'ارسال طبق زمان‌بندی'],'class'=>'col-12'],
            ]],
        ], $body );
    }
    public static function exit_sms_modal( array $campaign ): void {
        if ( ! KERP_Modules_Leads_View::can_configure() ) return;
        $id = (int) $campaign['id'];
        $rule = KERP_Modules_Leads_SMS::exit_config( $id )['rules'][0] ?? [];
        ob_start(); ?>
        <div class="col-12"><p class="fw-bold mb-2"><?php echo esc_html( $campaign['name'] ); ?></p>
            <p class="text-soft">پس از ثبت خروج مشتری از این مسیر، پیامک در اولین نوبت ارسال برای او فرستاده می‌شود. متن را در پنل سرویس پیامک به‌صورت پترن تعریف کنید؛ برای مثال «ببخشید که نتوانستیم همراهتان باشیم».</p>
            <p class="text-soft">برای توقف ارسال، کد پترن و متغیرها را خالی ذخیره کنید. این تنظیم برای خروج‌های بعدی است؛ پیامک‌های قبلیِ ارسال‌نشده نیز لغو می‌شوند.</p></div>
        <div class="col-12"><div class="row g-2 kerp-sms-variables mb-3">
        <div class="col-12 text-soft small">متغیرهای «پاسخ فرم» از آخرین ثبت‌نام مشتری در همین مسیر هنگام ارسال خوانده می‌شوند؛ پاسخ ثبت‌نشده خالی است.</div>
        <?php foreach ( KERP_Modules_Leads_SMS::variables( $id ) as $token => $label ) : ?>
            <div class="col-12 col-sm-6"><button type="button" class="kerp-sms-variable clipboard-init" data-clipboard-text="<?php echo esc_attr( $token ); ?>" data-clip-text="کپی" data-clip-success="کپی شد" data-clip-error="ناموفق"><span class="kerp-sms-variable__content"><span class="kerp-sms-variable__label"><?php echo esc_html( $label ); ?></span><code class="kerp-sms-variable__code"><?php echo esc_html( $token ); ?></code></span><span class="kerp-sms-variable__copy"><em class="icon ni ni-copy"></em><span class="clipboard-text">کپی</span></span></button></div>
        <?php endforeach; ?></div></div>
        <?php $body = ob_get_clean();
        self::modal( 'kerpPipelineExitSMS' . $id, 'پیامک خروج از مسیر فروش', 'leads_save_exit_sms', self::ROUTE . $id . '/', [
            self::field( 'campaign_id', '', $id, [ 'type'=>'hidden' ] ),
            self::field( 'exit_sms[pattern]', 'کد پترن پیامک خروج', $rule['pattern'] ?? '' ),
            self::field( 'exit_sms[variables]', 'متغیرهای پترن', $rule['variables'] ?? '', [ 'type'=>'textarea', 'placeholder'=>'token:{customer_name};token2:{pipeline_name}' ] ),
        ], $body );
    }
    public static function stage_actions_modal( int $campaign_id, array $stage ): void {
        if ( ! KERP_Modules_Leads_View::can_configure() ) return;
        $rows = KERP_Modules_Leads_Actions::buttons( (int) $stage['id'] );
        foreach ( $rows as &$row ) {
            $row['sms_enabled'] = empty( $row['sms'] ) ? 0 : 1;
            $row['sms'] = KERP_Modules_Leads_SMS::button_rules( $row );
        }
        unset( $row );
        $sms_fields = KERP_Modules_Leads_SMS::condition_fields( $campaign_id );
        $sms_cond = [ 'conditional'=>TRUE, 'cond_meta'=>'sms_enabled', 'cond_operator'=>'==', 'cond_expected'=>'1' ];
        $sms_help = '<div class="col-12"><p class="text-soft">پیامک هر دکمه بعد از موفقیت عملیات آن زمان‌بندی می‌شود؛ صفر یعنی اولین نوبت ارسال. شرط با آخرین پاسخ فرم همین مسیر هنگام ارسال بررسی می‌شود. پیامک اختصاصی دکمه جایگزین پیامک عمومی خروج یا عدم پاسخ آن اقدام می‌شود؛ پیامک ورود به مرحله بعد مستقل باقی می‌ماند.</p><div class="row g-2 kerp-sms-variables mb-3">';
        foreach ( KERP_Modules_Leads_SMS::variables( $campaign_id ) as $token=>$label ) $sms_help .= '<div class="col-12 col-sm-6"><button type="button" class="kerp-sms-variable clipboard-init" data-clipboard-text="' . esc_attr( $token ) . '" data-clip-text="کپی" data-clip-success="کپی شد" data-clip-error="ناموفق"><span class="kerp-sms-variable__content"><span class="kerp-sms-variable__label">' . esc_html( $label ) . '</span><code class="kerp-sms-variable__code">' . esc_html( $token ) . '</code></span><span class="kerp-sms-variable__copy"><em class="icon ni ni-copy"></em><span class="clipboard-text">کپی</span></span></button></div>';
        $sms_help .= '</div><p class="text-soft small">متغیر «پاسخ فرم» را کپی و بعد از نام توکن پترن قرار دهید. آخرین پاسخ ثبت‌نام همین مشتری در این مسیر هنگام ارسال استفاده می‌شود؛ پاسخ‌های چندانتخابی با «،» جدا و پاسخ ثبت‌نشده خالی ارسال می‌شود.</p></div>';
        self::modal( 'kerpPipelineStageActions' . (int) $stage['id'], 'اقدام‌های کارشناس · ' . $stage['name'], 'leads_save_stage_actions', self::ROUTE . $campaign_id . '/', [
            self::field( 'campaign_id', '', $campaign_id, [ 'type'=>'hidden' ] ),
            self::field( 'stage_id', '', (int) $stage['id'], [ 'type'=>'hidden' ] ),
            [ 'type'=>'repeater','name'=>'stage_buttons','label'=>'دکمه‌های این مرحله','class'=>'col-12','row_class'=>'col-12','row_title'=>'دکمه اقدام','card_class'=>'kerp-settings-field-card','button_text'=>'افزودن دکمه','value'=>$rows,'fields'=>[
                [ 'type'=>'hidden','name'=>'key' ],
                [ 'type'=>'text','name'=>'label','label'=>'عنوان دکمه','class'=>'col-md-6' ],
                [ 'type'=>'select','name'=>'transition','label'=>'پس از انجام عملیات','class'=>'col-md-6','options'=>[ 'stay'=>'ماندن در همین مرحله','next'=>'رفتن به مرحله فعال بعدی','exit'=>'خروج از مسیر فروش' ] ],
                [ 'type'=>'switch','name'=>'followup','label'=>'ایجاد پیگیری؛ زمان را کارشناس وارد کند','class'=>'col-12' ],
                [ 'type'=>'lead-product','name'=>'course_id','label'=>'اعطای دسترسی دوره لرندش','resource_label'=>'دوره لرندش','search_action'=>'leads_search_courses','required'=>FALSE,'class'=>'col-12' ],
                [ 'type'=>'lead-product','name'=>'product_id','label'=>'ایجاد سفارش برای محصول (اختیاری)','required'=>FALSE,'class'=>'col-12' ],
                [ 'type'=>'switch','name'=>'sms_enabled','label'=>'ارسال پیامک اختصاصی این دکمه','class'=>'col-12' ],
                [ 'type'=>'button-sms','name'=>'sms','class'=>'col-12','condition_fields'=>$sms_fields,'condition_options'=>KERP_Modules_Leads_SMS::condition_options( $campaign_id ) ] + $sms_cond,
            ] ],
        ], '<div class="col-12"><p>هر دکمه می‌تواند چند عملیات داشته باشد. ترتیب اجرا: ثبت پیگیری، اعطای دوره، ایجاد سفارش، سپس تغییر مرحله یا خروج و زمان‌بندی پیامک دکمه.</p><p class="text-soft">مثال: «تأیید» با دوره و رفتن به مرحله بعد؛ «رد» با خروج؛ «ثبت سفارش» با محصول و رفتن به مرحله بعد. سفارش یک عدد از محصول، با قیمت فعلی و در انتظار پرداخت ساخته می‌شود. عملیات اجراشده در صورت خطای بعدی برگشت داده نمی‌شوند و در تاریخچه ثبت خواهند شد.</p></div>' . $sms_help );
    }
    public static function configured_actions( array $member, string $route, bool $modals = FALSE ): array {
        if ( ! KERP_Modules_Leads_View::can_manage() || ! empty( $member['exited_at'] ) || empty( $member['current_stage_id'] ) ) return [];
        $actions = [];
        foreach ( KERP_Modules_Leads_Actions::buttons( (int) $member['current_stage_id'] ) as $button ) {
            if ( ! KERP_Modules_Leads_Actions::allowed( $button ) ) continue;
            $id = 'kerpPipelineAction' . (int) $member['id'] . '-' . $button['key'];
            $icon = $button['transition'] === 'exit' ? 'signout' : ( $button['product_id'] ? 'cart' : ( $button['course_id'] ? 'unlock' : ( $button['followup'] ? 'call' : 'arrow-left' ) ) );
            $actions[] = [ 'title'=>$button['label'], 'icon'=>'ni ni-' . $icon, 'data'=>[ 'bs-toggle'=>'modal', 'bs-target'=>'#' . $id ] ];
            if ( ! $modals ) continue;
            $fields = [];
            foreach ( [ 'user_id'=>$member['user_id'], 'campaign_id'=>$member['campaign_id'], 'stage_id'=>$member['current_stage_id'], 'button_key'=>$button['key'], 'revision'=>KERP_Modules_Leads_Actions::revision( $button ), 'request_id'=>wp_generate_uuid4(), 'leads_nonce'=>wp_create_nonce( 'kerp_leads' ) ] as $name=>$value ) $fields[] = self::field( $name, '', $value, [ 'type'=>'hidden','id'=>$id . '-' . $name ] );
            if ( $button['followup'] ) {
                $fields[] = self::field( 'due_date', 'تاریخ پیگیری (شمسی)', '', [ 'type'=>'date','class'=>'col-md-6','required'=>TRUE,'id'=>$id . '-date' ] );
                $fields[] = self::field( 'due_time', 'ساعت پیگیری', '', [ 'type'=>'text','input_class'=>'time-picker','class'=>'col-md-6','required'=>TRUE,'id'=>$id . '-time' ] );
            }
            $fields[] = self::field( 'note', 'یادداشت', '', [ 'type'=>'quill','id'=>$id . '-note' ] );
            $summary = [];
            if ( $button['followup'] ) $summary[] = 'ایجاد پیگیری برای کارشناس مسئول (در نبود مسئول: شما)';
            if ( $button['followup'] && empty( $button['sms'] ) ) $summary[] = 'زمان‌بندی پیامک‌های رویداد ثبت عدم پاسخ، در صورت تنظیم برای همین مرحله';
            if ( $button['course_id'] ) $summary[] = 'اعطای دسترسی دوره: ' . get_the_title( $button['course_id'] );
            if ( $button['product_id'] ) $summary[] = 'ایجاد سفارش در انتظار پرداخت، یک عدد: ' . get_the_title( $button['product_id'] );
            if ( $button['transition'] !== 'stay' ) $summary[] = $button['transition'] === 'next' ? 'انتقال به مرحله فعال بعدی' : ( empty( $button['sms'] ) ? 'خروج از مسیر و اجرای پیامک خروج تنظیم‌شده' : 'خروج از مسیر فروش' );
            if ( ! empty( $button['sms'] ) ) {
                foreach ( KERP_Modules_Leads_SMS::button_rules( $button ) as $sms ) {
                $summary[] = 'پیامک اختصاصی دکمه؛ پترن ' . $sms['pattern'] . '، پس از ' . $sms['delay'] . ' ' . [ 'minute'=>'دقیقه','hour'=>'ساعت','day'=>'روز' ][$sms['unit']];
                if ( $sms['condition_field'] !== '' ) $summary[] = 'شرط ارسال: ' . ( KERP_Modules_Leads_SMS::condition_fields( (int) $member['campaign_id'] )[$sms['condition_field']] ?? 'فیلد فرم' ) . ' برابر با ' . $sms['condition_value'];
                }
            }
            $body = '<div class="col-12"><p>برای ' . esc_html( get_user_name_by_id( (int) $member['user_id'] ) ) . ' این عملیات اجرا شود؟</p><ul><li>' . implode( '</li><li>', array_map( 'esc_html', $summary ) ) . '</li></ul></div>';
            if ( $button['product_id'] && function_exists( 'wc_get_product' ) && ( $product = wc_get_product( $button['product_id'] ) ) ) $body .= '<div class="col-12"><p>قیمت فعلی محصول: ' . KERP_Helpers_Template::price( $product->get_price() ) . '</p><p class="text-soft">قیمت و مالیات نهایی هنگام ساخت سفارش محاسبه می‌شوند.</p></div>';
            KERP_Helpers_Template::render_modal( [ 'id'=>$id,'title'=>$button['label'],'action'=>'leads_run_stage_action','page'=>$route,'fields'=>$fields,'body'=>$body,'button'=>'تأیید و اجرا' ] );
        }
        return $actions;
    }
    public static function customer_action_course( array $membership ): int {
        if ( ! KERP_Modules_Leads_View::can_manage() || ! empty( $membership['exited_at'] ) || ! function_exists( 'sfwd_lms_has_access' ) || ! function_exists( 'ld_update_course_access' ) ) return 0;
        $stage_id = (int) $membership['current_stage_id'];
        $service = KERP_Modules_Leads_Service::instance();
        $stage = $service->get_stage( $stage_id );
        $campaign = $service->get_campaign( (int) $membership['campaign_id'] );
        $course_id = (int) ( $service->stage_actions( $stage_id )['course_access'] ?? 0 );
        if ( ! $campaign || $campaign['status'] !== 'active' || ! $stage || (int) $stage['campaign_id'] !== (int) $membership['campaign_id'] || ! $stage['active'] || ! $course_id || get_post_type( $course_id ) !== 'sfwd-courses' || get_post_status( $course_id ) !== 'publish' ) return 0;
        return $course_id;
    }
    public static function can_record_no_answer( array $member ): bool {
        return KERP_Modules_Leads_View::can_manage() && empty( $member['exited_at'] ) && ! empty( $member['current_stage_id'] ) && class_exists( 'KERP_Modules_Followups_Module' ) && KERP_Modules::instance()->is_module_loaded( 'followups' ) && ( current_user_can( KERP_Admin::CAPABILITY ) || kerp_can( 'followups.create', 'action' ) );
    }
    public static function no_answer_modal( array $member, string $route ): void {
        if ( ! self::can_record_no_answer( $member ) ) return;
        $id = 'kerpPipelineNoAnswer' . (int) $member['id'];
        $fields = [];
        foreach ( [ 'user_id'=>$member['user_id'], 'campaign_id'=>$member['campaign_id'], 'stage_id'=>$member['current_stage_id'], 'request_id'=>wp_generate_uuid4(), 'leads_nonce'=>wp_create_nonce( 'kerp_leads' ) ] as $name=>$value ) $fields[] = self::field( $name, '', $value, [ 'type'=>'hidden', 'id'=>$id . '-' . $name ] );
        $fields[] = self::field( 'due_date', 'تاریخ پیگیری (شمسی)', '', [ 'type'=>'date', 'class'=>'col-md-6', 'required'=>TRUE, 'id'=>$id . '-date' ] );
        $fields[] = self::field( 'due_time', 'ساعت پیگیری', '', [ 'type'=>'text', 'input_class'=>'time-picker', 'class'=>'col-md-6', 'required'=>TRUE, 'id'=>$id . '-time' ] );
        $fields[] = self::field( 'note', 'یادداشت پیگیری', '', [ 'type'=>'quill', 'id'=>$id . '-note' ] );
        KERP_Helpers_Template::render_modal( [ 'id'=>$id, 'title'=>'عدم پاسخ مشتری و ثبت پیگیری', 'action'=>'leads_no_answer', 'page'=>$route, 'fields'=>$fields, 'button'=>'ثبت عدم پاسخ و پیگیری', 'body'=>'<div class="col-12"><p>زمان تماس بعدی را مشخص کنید. پیگیری برای کارشناس مسئول مشتری ثبت می‌شود؛ اگر کارشناس ندارد، به شما اختصاص می‌یابد.</p><p class="text-soft">مرحله مشتری تغییر نمی‌کند. فقط پیامک‌های تنظیم‌شده با رویداد «ثبت عدم پاسخ مشتری» زمان‌بندی می‌شوند.</p></div>' ] );
    }
    public static function customer_course_action( array $membership, int $user_id, string $return_page, bool $modal_only = FALSE ): void {
        $course_id = self::customer_action_course( $membership );
        if ( ! $course_id ) return;
        $stage_id = (int) $membership['current_stage_id'];
        $has_access = sfwd_lms_has_access( $course_id, $user_id );
        $id = 'kerpPipelineCourse' . (int) $membership['id'];
        if ( ! $modal_only ) : ?>
        <div class="mt-3 p-3 border rounded">
            <h6 class="mb-2">اقدام‌های این مرحله</h6>
            <div class="d-flex flex-wrap align-items-center justify-content-between gap-2">
                <span><?php echo esc_html( get_the_title( $course_id ) ); ?></span>
                <?php if ( $has_access ) : ?><span class="badge bg-success-dim text-success"><em class="icon ni ni-check-circle" aria-hidden="true"></em> دسترسی دارد</span>
                <?php else : ?><button type="button" class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#<?php echo esc_attr( $id ); ?>"><em class="icon ni ni-unlock"></em><span>اعطای دسترسی دوره</span></button><?php endif; ?>
            </div>
        </div>
        <?php
        endif;
        if ( $has_access ) return;
        $fields = [];
        foreach ( [ 'user_id'=>$user_id, 'campaign_id'=>(int) $membership['campaign_id'], 'stage_id'=>$stage_id, 'course_id'=>$course_id, 'leads_nonce'=>wp_create_nonce( 'kerp_leads' ) ] as $name => $value ) $fields[] = self::field( $name, '', $value, [ 'type'=>'hidden', 'id'=>$id . '-' . $name ] );
        KERP_Helpers_Template::render_modal( [ 'id'=>$id, 'title'=>'اعطای دسترسی دوره', 'action'=>'leads_grant_stage_course', 'page'=>$return_page, 'fields'=>$fields, 'body'=>'<div class="col-12"><p>دسترسی دوره <strong>' . esc_html( get_the_title( $course_id ) ) . '</strong> برای <strong>' . esc_html( get_user_name_by_id( $user_id ) ) . '</strong> ثبت شود؟</p><p class="text-soft">این اقدام در تاریخچه مشتری ثبت می‌شود.</p></div>', 'button'=>'تأیید و اعطای دسترسی' ] );
    }
    public static function delete_stage_modal( int $campaign_id, array $row ): void {
        if ( ! KERP_Modules_Leads_View::can_configure() || KERP_Modules_Leads_Registration::is_reserved_stage( $row ) ) return;
        $id = 'kerpPipelineStageDelete' . (int) $row['id'];
        $fields = [
            [ 'type' => 'hidden', 'name' => 'campaign_id', 'value' => $campaign_id, 'id' => $id . '-campaign', 'input_class' => 'no_clear' ],
            [ 'type' => 'hidden', 'name' => 'stage_id', 'value' => (int) $row['id'], 'id' => $id . '-stage', 'input_class' => 'no_clear' ],
            [ 'type' => 'hidden', 'name' => 'leads_nonce', 'value' => wp_create_nonce( 'kerp_leads' ), 'id' => $id . '-nonce', 'input_class' => 'no_clear' ],
            [ 'type' => 'checkbox', 'name' => 'confirm_delete', 'id' => $id . '-confirm', 'class' => 'col-12', 'required' => TRUE, 'options' => [ 'yes' => 'حذف دائمی این مرحله را تأیید می‌کنم.' ] ],
        ];
        $body = '<div class="col-12"><p>حذف مرحله <strong>' . esc_html( $row['name'] ) . '</strong></p><div class="alert alert-warning mb-0">حذف مرحله قابل بازگشت نیست و اتصال خودکار فرم یا محصول به این مرحله نیز حذف می‌شود. فقط مرحله‌ای که مشتری و سابقه ثبت‌شده ندارد قابل حذف است. برای کنارگذاشتن مرحله دارای سابقه، آن را در بخش ویرایش غیرفعال کنید.</div></div>';
        KERP_Helpers_Template::render_modal( [ 'id' => $id, 'title' => 'حذف مرحله', 'action' => 'leads_delete_stage', 'page' => self::ROUTE . $campaign_id . '/', 'fields' => $fields, 'body' => $body, 'button' => 'حذف دائمی مرحله' ] );
    }

    public static function delete_modal( array $row ): void {
        if ( ! KERP_Modules_Leads_View::can_configure() ) return;
        $id = 'kerpPipelineDelete' . (int) $row['id'];
        $fields = [
            [ 'type' => 'hidden', 'name' => 'campaign_id', 'value' => (int) $row['id'], 'id' => $id . '-id', 'input_class' => 'no_clear' ],
            [ 'type' => 'hidden', 'name' => 'leads_nonce', 'value' => wp_create_nonce( 'kerp_leads' ), 'id' => $id . '-nonce', 'input_class' => 'no_clear' ],
            [ 'type' => 'checkbox', 'name' => 'confirm_delete', 'id' => $id . '-confirm', 'class' => 'col-12', 'required' => TRUE, 'options' => [ 'yes' => 'حذف دائمی این مسیر، مراحل و سوابق آن را تأیید می‌کنم.' ] ],
        ];
        $body = '<div class="col-12"><p>حذف مسیر فروش <strong>' . esc_html( $row['name'] ) . '</strong></p><div class="alert alert-danger mb-0">تمام مراحل، عضویت مشتریان و تاریخچه اقدامات همین مسیر حذف می‌شوند و قابل بازگشت نیستند. حساب مشتریان، مسئول پرونده، سفارش‌ها و سایر مسیرها باقی می‌مانند.</div><p class="text-soft mt-3 mb-0">برای توقف فعالیت با حفظ سوابق، از گزینه بایگانی در عملیات گروهی استفاده کنید.</p></div>';
        KERP_Helpers_Template::render_modal( [ 'id' => $id, 'title' => 'حذف مسیر فروش', 'action' => 'leads_delete_campaign', 'page' => self::ROUTE, 'body' => $body, 'fields' => $fields, 'button' => 'حذف دائمی مسیر فروش' ] );
    }

	public static function connections_modal(): void {
		if ( ! KERP_Modules_Leads_View::can_configure() ) return;
		$body = '<div class="col-12"><p class="text-soft">این اتصال‌ها برای همه مسیرهای فروش مشترک هستند. کارشناسان فروش را در تنظیمات مسیرهای فروش انتخاب کنید.</p><p class="text-break" dir="ltr">' . esc_html( rest_url( 'kasebi-erp/v1/leads' ) ) . '</p><label class="form-label" for="kerpPipelineWebhook">کلید Webhook</label><input id="kerpPipelineWebhook" class="form-control" dir="ltr" readonly value="' . esc_attr( (string) get_option( 'kerp_leads_webhook_key', '' ) ) . '"></div>';
		self::modal( 'kerpPipelineConnections', 'اتصال منابع', 'leads_save_settings', self::ROUTE, [
		], $body );
	}
}
