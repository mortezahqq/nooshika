<?php
defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Leads_Dashboard {
    private static ?self $instance = NULL;
    private ?array $block_data = NULL;

    public static function instance(): self { return self::$instance ??= new self(); }
    private function __construct() {
        add_filter( 'kerp_dashboard_blocks', [ $this, 'register_blocks' ] );
    }

    public function register_blocks( array $blocks ): array {
        $position = 30;
        foreach ( [ 'entries' => 'ورودی مشتریان به مسیرهای فروش', 'pipelines' => 'مقایسه ورودی مسیرهای فروش', 'owners' => 'بار کاری کارشناسان فروش', 'assignment' => 'وضعیت تخصیص کارشناس فروش' ] as $kind => $title ) {
            $blocks[ 'leads-' . $kind ] = [
                'title' => $title, 'position' => $position++, 'width' => in_array( $kind, [ 'entries', 'owners' ], TRUE ) ? 8 : 4,
                'module' => 'leads', 'permission' => 'leads.view', 'permission_type' => 'view',
                'async' => TRUE, 'callback' => [ $this, 'render_block' ],
            ];
        }
        return $blocks;
    }

    public function render_block( array $context, array $block ): void {
        if ( ! kerp_can( 'leads.view', 'view' ) ) return;
        $kind = substr( (string) ( $block['id'] ?? '' ), strlen( 'leads-' ) );
        if ( ! in_array( $kind, [ 'entries', 'pipelines', 'owners', 'assignment' ], TRUE ) ) return;
        // Aggregate once per request for all four home blocks; no queries during registration.
        $this->block_data = KERP_Helpers_Dashboard_Cache::remember( 'leads-home-v2', [ self::class, 'collect_home' ] );
        KERP_Helpers_Template::render_template( 'modules/leads/partials/home-dashboard.php', [ 'kind' => $kind, 'stats' => $this->block_data ] );
    }

    public static function collect_home( array $state ): array {
        global $wpdb;
        $now = new DateTimeImmutable( $state['as_of'] );
        $start = $now->setTime( 0, 0 )->modify( '-6 days' );
        $data = $state['data'] ?? [ 'days' => [], 'daily' => [], 'totals' => [ 'memberships' => 0, 'unassigned' => 0 ], 'owners' => [], 'comparison' => [] ];
        for ( $i = 0; $i < 7; ++$i ) {
            $day = $start->modify( '+' . $i . ' days' )->format( 'Y-m-d' );
            $data['days'][ $day ] = KERP_Helpers_Date::gregorian_to_jalali( $day );
            $data['daily'][ $day ] ??= 0;
        }
        $m = KERP_Modules_Leads_Module::table( 'memberships' );
        $c = KERP_Modules_Leads_Module::table( 'campaigns' );
        $cursor = (int) ( $state['cursor'] ?? 0 );
        $upper_id = isset( $state['upper_id'] ) ? (int) $state['upper_id'] : (int) $wpdb->get_var( "SELECT MAX(id) FROM {$m}" );
        // Primary-key scan: no unbounded COUNT(DISTINCT), GROUP BY or repeated OFFSET.
        $rows = (array) $wpdb->get_results( $wpdb->prepare( "SELECT m.id,m.owner_id,m.campaign_id,m.joined_at,m.exited_at,c.name FROM {$m} m INNER JOIN {$c} c ON c.id=m.campaign_id WHERE m.id>%d AND m.id<=%d ORDER BY m.id LIMIT 500", $cursor, $upper_id ), ARRAY_A );
        foreach ( $rows as $row ) {
            $cursor = (int) $row['id'];
            if ( empty( $row['exited_at'] ) ) {
            ++$data['totals']['memberships'];
            if ( ! $row['owner_id'] ) { ++$data['totals']['unassigned']; }
            $owner = (int) $row['owner_id'];
            $data['owners'][ $owner ] ??= [ 'owner_id' => $owner, 'n' => 0 ];
            ++$data['owners'][ $owner ]['n'];
            }
            $id = (int) $row['campaign_id'];
            $data['comparison'][ $id ] ??= [ 'id' => $id, 'name' => $row['name'], 'total' => 0, 'recent' => 0 ];
            if ( empty( $row['exited_at'] ) ) ++$data['comparison'][ $id ]['total'];
            $day = substr( $row['joined_at'], 0, 10 );
            if ( isset( $data['daily'][ $day ] ) && $row['joined_at'] <= $now->format( 'Y-m-d H:i:s' ) ) {
                ++$data['daily'][ $day ];
                ++$data['comparison'][ $id ]['recent'];
            }
        }
        if ( count( $rows ) === 500 ) { return [ 'done' => FALSE, 'data' => $data, 'cursor' => $cursor, 'upper_id' => $upper_id ]; }
        uasort( $data['owners'], static fn( $a, $b ) => [ -$a['n'], $a['owner_id'] ] <=> [ -$b['n'], $b['owner_id'] ] );
        uasort( $data['comparison'], static fn( $a, $b ) => [ -$a['recent'], -$a['total'], $a['id'] ] <=> [ -$b['recent'], -$b['total'], $b['id'] ] );
        $data['owners'] = array_slice( $data['owners'], 0, 10 );
        $data['comparison'] = array_slice( $data['comparison'], 0, 5 );
        return [ 'done' => TRUE, 'data' => $data ];
    }

    public static function data( int $campaign_id ): array {
        global $wpdb;
        $m = KERP_Modules_Leads_Module::table( 'memberships' );
        $e = KERP_Modules_Leads_Module::table( 'events' );
        $c = KERP_Modules_Leads_Module::table( 'campaigns' );
        $now = current_datetime();
        $start = $now->setTime( 0, 0 )->modify( '-6 days' );
        $end = $now->format( 'Y-m-d H:i:s' );
        $days = [];
        for ( $i = 0; $i < 7; ++$i ) {
            $day = $start->modify( '+' . $i . ' days' )->format( 'Y-m-d' );
            $days[ $day ] = KERP_Helpers_Date::gregorian_to_jalali( $day );
        }
        $scope = $campaign_id ? $wpdb->prepare( ' AND m.campaign_id=%d', $campaign_id ) : '';
        $totals = (array) $wpdb->get_row( "SELECT COUNT(*) memberships,COUNT(DISTINCT m.user_id) customers,COALESCE(SUM(m.owner_id=0),0) unassigned FROM {$m} m JOIN {$c} c ON c.id=m.campaign_id WHERE m.exited_at IS NULL{$scope}", ARRAY_A );
        $daily = array_fill_keys( array_keys( $days ), 0 );
        $rows = $wpdb->get_results( $wpdb->prepare( "SELECT DATE(m.joined_at) day,COUNT(*) n FROM {$m} m JOIN {$c} c ON c.id=m.campaign_id WHERE m.joined_at >= %s AND m.joined_at <= %s{$scope} GROUP BY DATE(m.joined_at)", $start->format( 'Y-m-d H:i:s' ), $end ), ARRAY_A );
        foreach ( (array) $rows as $row ) if ( isset( $daily[ $row['day'] ] ) ) $daily[ $row['day'] ] = (int) $row['n'];
        $owners = (array) $wpdb->get_results( "SELECT m.owner_id,COUNT(*) n FROM {$m} m JOIN {$c} c ON c.id=m.campaign_id WHERE m.exited_at IS NULL{$scope} GROUP BY m.owner_id ORDER BY n DESC,m.owner_id LIMIT 10", ARRAY_A );
        $comparison = (array) $wpdb->get_results( $wpdb->prepare( "SELECT c.id,c.name,COALESCE(SUM(m.id IS NOT NULL AND m.exited_at IS NULL),0) total,COALESCE(SUM(m.joined_at >= %s AND m.joined_at <= %s),0) recent FROM {$c} c LEFT JOIN {$m} m ON m.campaign_id=c.id GROUP BY c.id,c.name ORDER BY recent DESC,total DESC,c.id LIMIT 10", $start->format( 'Y-m-d H:i:s' ), $end ), ARRAY_A );
        $summary = $campaign_id ? KERP_Modules_Leads_Service::instance()->pipeline_summary( $campaign_id ) : NULL;
        $matrix = []; $entry_total = 0;
        if ( $summary ) {
            foreach ( $summary['stages'] as $stage ) $matrix[ (int) $stage['id'] ] = array_fill_keys( array_keys( $days ), 0 );
            // Only stage-entry events. Notes, owner changes and outgoing branches are not entries.
            $entries = (array) $wpdb->get_results( $wpdb->prepare( "SELECT e.stage_id,DATE(e.occurred_at) day,COUNT(DISTINCT e.user_id) n FROM {$e} e WHERE e.campaign_id=%d AND e.stage_id>0 AND e.occurred_at >= %s AND e.occurred_at <= %s AND e.event_type IN ('stage_changed','manual','product_purchased','gravity_form','learndash_completed','webhook','pipeline_joined') GROUP BY e.stage_id,DATE(e.occurred_at)", $campaign_id, $start->format( 'Y-m-d H:i:s' ), $end ), ARRAY_A );
            foreach ( $entries as $row ) {
                if ( isset( $matrix[ (int) $row['stage_id'] ][ $row['day'] ] ) ) {
                    $matrix[ (int) $row['stage_id'] ][ $row['day'] ] = (int) $row['n'];
                    $entry_total += (int) $row['n'];
                }
            }
        }
        return compact( 'days', 'daily', 'totals', 'owners', 'comparison', 'summary', 'matrix', 'entry_total', 'end' );
    }
}
