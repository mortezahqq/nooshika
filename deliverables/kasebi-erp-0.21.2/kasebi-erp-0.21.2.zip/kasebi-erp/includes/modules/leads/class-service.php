<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Leads_Service {
	private static ?self $instance = NULL;
	public static function instance(): self { return self::$instance ??= new self(); }
	private function __construct() {}
	private function __clone() {}
    public function record_no_answer( int $user_id, int $campaign_id, int $stage_id, string $date, string $time, string $note, string $request_id ): bool|WP_Error {
        if ( ! class_exists( 'KERP_Modules_Followups_Module' ) || ! KERP_Modules::instance()->is_module_loaded( 'followups' ) ) return new WP_Error( 'followups', 'ماژول پیگیری‌ها باید فعال باشد.' );
        $date = KERP_Helpers_Date::jalali_to_gregorian( str_replace( '/', '-', KERP_Helpers_Format::sanitize_numbers( $date ) ) );
        $time = KERP_Helpers_Format::sanitize_numbers( $time );
        if ( $date === '' || ! preg_match( '/^(?:[01][0-9]|2[0-3]):[0-5][0-9]$/D', $time ) || ! preg_match( '/^[a-zA-Z0-9-]{16,64}$/D', $request_id ) ) return new WP_Error( 'date', 'تاریخ و ساعت پیگیری معتبر وارد کنید.' );
        $due = $date . ' ' . $time . ':00';
        if ( $due <= current_time( 'mysql' ) ) return new WP_Error( 'date', 'زمان پیگیری باید در آینده باشد.' );
        global $wpdb;
        $table = KERP_Modules_Leads_Module::table( 'memberships' );
        $fingerprint = 'no-answer:' . hash( 'sha256', $user_id . ':' . $campaign_id . ':' . $request_id );
        if ( $wpdb->query( 'START TRANSACTION' ) === FALSE ) return new WP_Error( 'save', 'شروع ثبت اقدام ناموفق بود.' );
        try {
            $member = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE user_id=%d AND campaign_id=%d FOR UPDATE", $user_id, $campaign_id ), ARRAY_A );
            if ( ! $member || ! empty( $member['exited_at'] ) || (int) $member['current_stage_id'] !== $stage_id ) throw new RuntimeException( 'مرحله مشتری تغییر کرده است؛ صفحه را تازه کنید.' );
            if ( $this->fingerprint_exists( $fingerprint ) ) { $wpdb->query( 'ROLLBACK' ); return TRUE; }
            $stage = $this->get_stage( $stage_id ); $campaign = $this->get_campaign( $campaign_id );
            if ( ! $stage || ! $stage['active'] || (int) $stage['campaign_id'] !== $campaign_id || ! $campaign || $campaign['status'] !== 'active' ) throw new RuntimeException( 'مسیر و مرحله فعال نیستند.' );
            $assignee = (int) $member['owner_id'] ?: get_current_user_id();
            $followup = KERP_Modules_Followups_Module::instance()->save( [ 'customer_id'=>$user_id, 'assignee_id'=>$assignee, 'type_key'=>'phone', 'title'=>'عدم پاسخ مشتری · ' . $campaign['name'], 'description'=>wp_kses_post( $note ), 'due_at'=>$due, 'priority'=>'normal', 'status'=>'pending', 'metadata'=>[ 'source_key'=>$fingerprint, 'campaign_id'=>$campaign_id, 'stage_id'=>$stage_id ] ] );
            if ( is_wp_error( $followup ) ) throw new RuntimeException( $followup->get_error_message() );
            $event = $this->add_event( $user_id, $campaign_id, (int) $member['id'], $stage_id, 'no_answer', 'عدم پاسخ مشتری؛ پیگیری ثبت شد', [ 'followup_id'=>$followup, 'due_at'=>$due, 'note'=>wp_kses_post( $note ), 'note_format'=>'html' ], $fingerprint );
            if ( ! $event || ! KERP_Modules_Leads_SMS::enqueue( $event, $user_id, $campaign_id, $stage_id, 'no_answer' ) ) throw new RuntimeException( 'ثبت تاریخچه یا صف پیامک ناموفق بود.' );
            if ( $wpdb->query( 'COMMIT' ) === FALSE ) throw new RuntimeException( 'ذخیره اقدام ناموفق بود.' );
            return TRUE;
        } catch ( Throwable $error ) {
            $wpdb->query( 'ROLLBACK' );
            return new WP_Error( 'no_answer', $error->getMessage() );
        }
    }
	public function stage_actions( int $stage_id ): array {
		$config = get_option( 'kerp_lead_stage_actions_' . $stage_id, [] );
		return is_array( $config ) ? $config : [];
	}
	public function save_stage_actions( int $campaign_id, int $stage_id, int $course_id ): bool|WP_Error {
		$stage = $this->get_stage( $stage_id );
		if ( ! $stage || (int) $stage['campaign_id'] !== $campaign_id || ! $this->get_campaign( $campaign_id ) ) return new WP_Error( 'scope', 'مرحله متعلق به این مسیر نیست.' );
		if ( $course_id && ( ! function_exists( 'ld_update_course_access' ) || get_post_type( $course_id ) !== 'sfwd-courses' || get_post_status( $course_id ) !== 'publish' ) ) return new WP_Error( 'course', 'یک دوره منتشرشده لرندش انتخاب کنید.' );
		$config = [ 'course_access' => $course_id ];
		if ( $this->stage_actions( $stage_id ) === $config ) return TRUE;
		return update_option( 'kerp_lead_stage_actions_' . $stage_id, $config, FALSE ) ? TRUE : new WP_Error( 'save', 'تنظیم اقدام ذخیره نشد.' );
	}
	public function grant_stage_course( int $user_id, int $campaign_id, int $stage_id, int $course_id ): bool|WP_Error {
		global $wpdb;
		if ( ! function_exists( 'ld_update_course_access' ) || ! function_exists( 'sfwd_lms_has_access' ) ) return new WP_Error( 'learndash', 'لرندش فعال نیست.' );
		$lock = 'kerp-course-' . md5( $wpdb->prefix . ':' . $user_id . ':' . $course_id );
		if ( (int) $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 0)', $lock ) ) !== 1 ) return new WP_Error( 'busy', 'اقدام دیگری در حال اجراست؛ دوباره تلاش کنید.' );
		try {
			$member = $this->get_membership( $user_id, $campaign_id );
			$stage = $this->get_stage( $stage_id ); $campaign = $this->get_campaign( $campaign_id );
			if ( ! $member || ! empty( $member['exited_at'] ) || (int) $member['current_stage_id'] !== $stage_id || ! $stage || ! $stage['active'] || (int) $stage['campaign_id'] !== $campaign_id || ! $campaign || $campaign['status'] !== 'active' ) return new WP_Error( 'scope', 'مرحله یا وضعیت مشتری تغییر کرده است؛ صفحه را تازه کنید.' );
			if ( $course_id < 1 || (int) ( $this->stage_actions( $stage_id )['course_access'] ?? 0 ) !== $course_id || get_post_type( $course_id ) !== 'sfwd-courses' || get_post_status( $course_id ) !== 'publish' || ! get_userdata( $user_id ) ) return new WP_Error( 'course', 'اقدام یا دوره این مرحله معتبر نیست؛ صفحه را تازه کنید.' );
			if ( sfwd_lms_has_access( $course_id, $user_id ) ) return new WP_Error( 'already_enrolled', 'مشتری از قبل به این دوره دسترسی دارد.' );
			if ( ! ld_update_course_access( $user_id, $course_id, FALSE ) ) return new WP_Error( 'grant_failed', 'اعطای دسترسی دوره انجام نشد.' );
			if ( ! $this->add_event( $user_id, $campaign_id, (int) $member['id'], $stage_id, 'course_access_granted', 'اعطای دسترسی دوره «' . get_the_title( $course_id ) . '»', [ 'course_id'=>$course_id, 'action_type'=>'course_access' ] ) ) return new WP_Error( 'history', 'دسترسی دوره داده شد، اما ثبت تاریخچه ناموفق بود.' );
			return TRUE;
		} catch ( Throwable $error ) {
			return new WP_Error( 'action_failed', 'اجرای اقدام کامل نشد؛ وضعیت دسترسی دوره را بررسی کنید.' );
		} finally { $wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $lock ) ); }
	}
	public function __wakeup(): void { throw new LogicException( 'Cannot unserialize a singleton.' ); }

	public function upsert_lead( array $data ): array|WP_Error {
		$campaign_id = absint( $data['campaign_id'] ?? 0 );
		$stage_id = absint( $data['stage_id'] ?? 0 );
		if ( $campaign_id || $stage_id ) {
			$valid = $this->validate_destination( $campaign_id, $stage_id );
			if ( is_wp_error( $valid ) ) return $valid;
		}
		$phone = KERP_Helpers_Phone::normalize( sanitize_text_field( (string) ( $data['phone'] ?? '' ) ) );
		if ( $phone === '' || strlen( $phone ) < 7 ) return new WP_Error( 'kerp_lead_phone', 'شماره موبایل معتبر الزامی است.' );
		$user_id = KERP_Helpers_Phone::get_user_id( $phone );
		if ( ! $user_id ) $user_id = KERP_Helpers_Phone::get_user_id( $phone, 'billing_phone' );
		$created = FALSE;
		if ( ! $user_id ) {
			$name = sanitize_text_field( (string) ( $data['name'] ?? '' ) );
			$parts = preg_split( '/\s+/u', trim( $name ), 2, PREG_SPLIT_NO_EMPTY );
			$login = 'lead_' . $phone;
			if ( username_exists( $login ) ) $login .= '_' . strtolower( wp_generate_password( 4, FALSE, FALSE ) );
			$user_id = wp_insert_user( [
				'user_login' => $login, 'user_pass' => wp_generate_password( 24, TRUE, TRUE ),
				'first_name' => (string) ( $parts[0] ?? '' ), 'last_name' => (string) ( $parts[1] ?? '' ),
				'display_name' => $name !== '' ? $name : KERP_Helpers_Phone::with_zero( $phone ),
				'role' => (string) KERP_Modules_Customers_Settings::instance()->get( 'default_role', 'customer' ),
			] );
			if ( is_wp_error( $user_id ) ) return $user_id;
			$user_id = absint( $user_id ); $created = TRUE;
			update_user_meta( $user_id, KERP_Helpers_Phone::get_meta_key(), $phone );
			update_user_meta( $user_id, 'billing_phone', $phone );
		} elseif ( ! empty( $data['name'] ) ) {
			$user = get_userdata( $user_id );
			if ( $user instanceof WP_User && trim( $user->first_name . ' ' . $user->last_name ) === '' ) {
				$name = sanitize_text_field( (string) $data['name'] );
				$parts = preg_split( '/\s+/u', trim( $name ), 2, PREG_SPLIT_NO_EMPTY );
				wp_update_user( [ 'ID' => $user_id, 'first_name' => (string) ( $parts[0] ?? '' ), 'last_name' => (string) ( $parts[1] ?? '' ), 'display_name' => $name ] );
			}
		}

		$first_lead = ! metadata_exists( 'user', $user_id, 'kerp_lead_entered_at' );
		$source = sanitize_text_field( (string) ( $data['source'] ?? '' ) );
		$utm = $this->sanitize_utm( (array) ( $data['utm'] ?? [] ) );
		if ( $source !== '' && ! metadata_exists( 'user', $user_id, 'kerp_lead_first_source' ) ) {
			update_user_meta( $user_id, 'kerp_lead_first_source', $source );
			update_user_meta( $user_id, 'kerp_lead_first_utm', $utm );
		}
		if ( ! metadata_exists( 'user', $user_id, 'kerp_lead_entered_at' ) ) update_user_meta( $user_id, 'kerp_lead_entered_at', current_time( 'mysql' ) );
		if ( $source !== '' ) update_user_meta( $user_id, 'kerp_lead_last_source', $source );
		if ( $created || $first_lead ) $this->add_event( $user_id, 0, 0, 0, 'lead_created', 'ایجاد پرونده مشتری بالقوه', [ 'source' => $source, 'utm' => $utm ] );
		$campaign_id = absint( $data['campaign_id'] ?? 0 );
		$membership_id = 0;
		if ( $campaign_id ) {
			$membership_id = $this->join_campaign( $user_id, $campaign_id, $source, $utm, absint( $data['owner_id'] ?? 0 ) );
			if ( is_wp_error( $membership_id ) ) return $membership_id;
			$stage_id = absint( $data['stage_id'] ?? 0 );
			if ( $stage_id ) {
				$moved = $this->move_stage( $user_id, $campaign_id, $stage_id, [ 'event_type' => sanitize_key( (string) ( $data['event_type'] ?? 'stage_changed' ) ), 'fingerprint' => (string) ( $data['fingerprint'] ?? '' ), 'payload' => [ 'source' => $source, 'utm' => $utm ] ] );
				if ( is_wp_error( $moved ) ) return $moved;
			}
		}
		do_action( 'kerp_lead_upserted', $user_id, $data, $created );
		return [ 'user_id' => $user_id, 'membership_id' => $membership_id, 'created' => $created ];
	}

	public function join_campaign( int $user_id, int $campaign_id, string $source = '', array $utm = [], int $owner_id = 0 ): int|WP_Error {
		global $wpdb;
		if ( ! get_userdata( $user_id ) ) return new WP_Error( 'kerp_lead_membership', 'کاربر معتبر نیست.' );
		$valid = $this->validate_destination( $campaign_id );
		if ( is_wp_error( $valid ) ) return $valid;
		$table = KERP_Modules_Leads_Module::table( 'memberships' );
		$id = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE user_id=%d AND campaign_id=%d", $user_id, $campaign_id ) );
		if ( $id ) {
			$existing = $this->get_membership( $user_id, $campaign_id );
			if ( ! empty( $existing['exited_at'] ) ) return new WP_Error( 'pipeline_exited', 'این مشتری از مسیر فروش خارج شده است.' );
			return $id;
		}
		$customer_owner = $this->customer_owner( $user_id );
		if ( $customer_owner ) $owner_id = $customer_owner;
		elseif ( ! $owner_id ) $owner_id = $this->next_owner();
		if ( $source !== '' && ! metadata_exists( 'user', $user_id, 'kerp_lead_first_source' ) ) {
			update_user_meta( $user_id, 'kerp_lead_first_source', sanitize_text_field( $source ) );
			update_user_meta( $user_id, 'kerp_lead_first_utm', $this->sanitize_utm( $utm ) );
		}
		if ( ! metadata_exists( 'user', $user_id, 'kerp_lead_entered_at' ) ) update_user_meta( $user_id, 'kerp_lead_entered_at', current_time( 'mysql' ) );
		$now = current_time( 'mysql' );
		$wpdb->insert( $table, [ 'user_id' => $user_id, 'campaign_id' => $campaign_id, 'attendance' => 'unknown', 'owner_id' => $owner_id, 'source' => sanitize_text_field( $source ), 'utm_json' => wp_json_encode( $this->sanitize_utm( $utm ), JSON_UNESCAPED_UNICODE ), 'joined_at' => $now, 'updated_at' => $now ] );
		if ( ! $wpdb->insert_id ) return new WP_Error( 'kerp_lead_join_failed', 'عضویت مشتری بالقوه در کمپین ثبت نشد.' );
		$id = (int) $wpdb->insert_id;
		$this->add_event( $user_id, $campaign_id, $id, 0, 'campaign_joined', 'عضویت در کمپین', [ 'source' => $source, 'utm' => $utm ] );
		return $id;
	}

	/** Join once; existing members are never moved or reactivated by this integration. */
	public function join_pipeline( int $user_id, int $campaign_id, array $context = [] ): array|WP_Error {
		global $wpdb;
		if ( $user_id < 1 || $campaign_id < 1 || ! get_userdata( $user_id ) ) return new WP_Error( 'invalid_user', 'کاربر یا مسیر معتبر نیست.' );
		if ( isset( $context['stage_id'] ) && ( ! is_scalar( $context['stage_id'] ) || ! ctype_digit( (string) $context['stage_id'] ) || (int) $context['stage_id'] < 1 ) ) return new WP_Error( 'invalid_stage', 'شناسه مرحله شروع معتبر نیست.' );
		if ( isset( $context['note'] ) && ! is_string( $context['note'] ) ) return new WP_Error( 'invalid_note', 'توضیح معتبر نیست.' );
		$campaigns = KERP_Modules_Leads_Module::table( 'campaigns' );
		$members = KERP_Modules_Leads_Module::table( 'memberships' );
		$stages = KERP_Modules_Leads_Module::table( 'stages' );
		if ( $wpdb->query( 'START TRANSACTION' ) === FALSE ) return new WP_Error( 'join_failed', 'شروع افزودن به مسیر ناموفق بود.' );
		$error = NULL;
		try {
			$campaign = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$campaigns} WHERE id=%d FOR UPDATE", $campaign_id ), ARRAY_A );
			if ( ! $campaign || $campaign['status'] !== 'active' ) throw new RuntimeException( 'مسیر فروش فعال پیدا نشد.' );
			$existing = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$members} WHERE user_id=%d AND campaign_id=%d FOR UPDATE", $user_id, $campaign_id ), ARRAY_A );
			if ( $existing ) {
				$wpdb->query( 'ROLLBACK' );
				return ! empty( $existing['exited_at'] ) ? new WP_Error( 'pipeline_exited', 'این مشتری از مسیر فروش خارج شده است.' ) : [ 'status' => 'existing', 'membership_id' => (int) $existing['id'], 'stage_id' => (int) $existing['current_stage_id'] ];
			}
			$stage_id = isset( $context['stage_id'] ) ? (int) $context['stage_id'] : (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$stages} WHERE campaign_id=%d AND active=1 AND trigger_type NOT IN ('registration_started','registration_completed') ORDER BY position,id LIMIT 1 FOR UPDATE", $campaign_id ) );
			if ( ! $stage_id ) throw new RuntimeException( 'مسیر فروش مرحله فعال ندارد.' );
			$valid = $this->validate_destination( $campaign_id, $stage_id );
			if ( is_wp_error( $valid ) ) { $error = $valid; throw new RuntimeException(); }
			$source = isset( $context['source'] ) && is_string( $context['source'] ) ? sanitize_text_field( $context['source'] ) : 'integration';
			$membership_id = $this->join_campaign( $user_id, $campaign_id, $source );
			if ( is_wp_error( $membership_id ) ) { $error = $membership_id; throw new RuntimeException(); }
			$moved = $this->move_stage_write( $user_id, $campaign_id, $stage_id, [ 'event_type' => 'pipeline_joined', 'payload' => [ 'source' => $source, 'note' => sanitize_textarea_field( $context['note'] ?? '' ) ] ], $change );
			if ( is_wp_error( $moved ) ) { $error = $moved; throw new RuntimeException(); }
			if ( $wpdb->query( 'COMMIT' ) === FALSE ) throw new RuntimeException( 'ذخیره ورود به مسیر ناموفق بود.' );
		} catch ( Throwable $failure ) {
			$wpdb->query( 'ROLLBACK' );
			wp_cache_delete( $user_id, 'user_meta' );
			return $error ?? new WP_Error( 'join_failed', $failure->getMessage() );
		}
		$this->notify_stage_changed( $change );
		return [ 'status' => 'joined', 'membership_id' => $membership_id, 'stage_id' => $stage_id ];
	}

    /** Atomic second-step answers, movement, completion and notification. Caller has verified the registration token. */
    public function complete_registration( array $entry, array $answers ): bool|WP_Error {
        global $wpdb;
        $registrations = KERP_Modules_Leads_Registration::table();
        $responses = KERP_Modules_Leads_Registration::table( 'answers' );
        $members = KERP_Modules_Leads_Module::table( 'memberships' );
        if ( $wpdb->query( 'START TRANSACTION' ) === FALSE ) return new WP_Error( 'registration_save', 'شروع ذخیره ناموفق بود.' );
        $change = NULL;
        try {
            $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$registrations} WHERE id=%d FOR UPDATE", $entry['id'] ), ARRAY_A );
            if ( ! $row || ! hash_equals( $row['token_hash'], $entry['token_hash'] ) || ! in_array( $row['status'], [ 'verified', 'completed' ], TRUE ) || (int)$row['expires'] < time() ) throw new RuntimeException( 'تأیید شماره معتبر نیست.' );
            if ( $row['status'] === 'completed' ) { $wpdb->query( 'ROLLBACK' ); return TRUE; }
            $uid = (int)$row['user_id']; $cid = (int)$row['campaign_id'];
            $member = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$members} WHERE user_id=%d AND campaign_id=%d FOR UPDATE", $uid, $cid ), ARRAY_A );
            if ( ! $member || ! empty( $member['exited_at'] ) ) throw new RuntimeException( 'ادامه ثبت‌نام این مسیر امکان‌پذیر نیست.' );
            $valid = $this->validate_destination( $cid, (int)$row['stage_two'] );
            if ( is_wp_error( $valid ) ) throw new RuntimeException( $valid->get_error_message() );
            if ( $wpdb->delete( $responses, [ 'entry_id' => $row['id'], 'phase' => 2 ] ) === FALSE ) throw new RuntimeException( 'ذخیره پاسخ‌ها ناموفق بود.' );
            foreach ( $answers as $key => $values ) foreach ( $values as $value ) if ( $wpdb->insert( $responses, [ 'entry_id' => $row['id'], 'phase' => 2, 'field_key' => $key, 'value' => $value ] ) === FALSE ) throw new RuntimeException( 'ذخیره پاسخ‌ها ناموفق بود.' );
            $payload = [ 'registration_id' => (int)$row['id'], 'utm' => json_decode( $row['utm_json'], TRUE ) ?: [] ];
            if ( (int)$member['current_stage_id'] === (int)$row['stage_one'] ) {
                $moved = $this->move_stage_write( $uid, $cid, (int)$row['stage_two'], [ 'fingerprint' => 'registration:' . $row['id'], 'payload' => $payload ], $change );
                if ( is_wp_error( $moved ) ) throw new RuntimeException( $moved->get_error_message() );
            }
            if ( ! $this->add_event( $uid, $cid, (int)$member['id'], (int)$row['stage_two'], 'registration_completed', 'تکمیل فرم ثبت‌نام پس از تأیید شماره', $payload ) ) throw new RuntimeException( 'ثبت تاریخچه ناموفق بود.' );
            if ( $wpdb->update( $registrations, [ 'status' => 'completed', 'completed_at' => current_time( 'mysql' ) ], [ 'id' => $row['id'] ] ) === FALSE ) throw new RuntimeException( 'ثبت نهایی ناموفق بود.' );
            if ( $wpdb->query( 'COMMIT' ) === FALSE ) throw new RuntimeException( 'ذخیره ناموفق بود.' );
        } catch ( Throwable $error ) { $wpdb->query( 'ROLLBACK' ); return new WP_Error( 'registration_save', $error->getMessage() ); }
        $this->notify_stage_changed( $change );
        return TRUE;
    }

	/** Exit retains the last stage and history; repeating an exit is a no-op. */
	public function exit_pipeline( int $user_id, int $campaign_id, string $note = '', ?int $expected_stage_id = NULL, bool $send_exit_sms = TRUE ): bool|WP_Error {
		global $wpdb;
		if ( $user_id < 1 || $campaign_id < 1 ) return new WP_Error( 'invalid_membership', 'کاربر یا مسیر معتبر نیست.' );
		$table = KERP_Modules_Leads_Module::table( 'memberships' );
		if ( $wpdb->query( 'START TRANSACTION' ) === FALSE ) return new WP_Error( 'exit_failed', 'شروع ثبت خروج ناموفق بود.' );
		try {
			$member = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE user_id=%d AND campaign_id=%d FOR UPDATE", $user_id, $campaign_id ), ARRAY_A );
			if ( ! $member ) throw new RuntimeException( 'مسیر فروش مشتری پیدا نشد.' );
			if ( ! empty( $member['exited_at'] ) ) { $wpdb->query( 'ROLLBACK' ); return TRUE; }
			$stage_id = (int) $member['current_stage_id'];
			if ( $expected_stage_id !== NULL && $stage_id !== $expected_stage_id ) throw new RuntimeException( 'مرحله مشتری تغییر کرده است؛ صفحه را تازه کنید.' );
			$now = current_time( 'mysql' );
			if ( $wpdb->update( $table, [ 'exited_at' => $now, 'updated_at' => $now ], [ 'id' => $member['id'] ] ) !== 1 ) throw new RuntimeException( 'خروج ذخیره نشد.' );
			$payload = [ 'note' => wp_kses_post( $note ), 'note_format' => 'html', 'from_stage_id' => $stage_id ];
			$event_id = $this->add_event( $user_id, $campaign_id, (int) $member['id'], $stage_id, 'pipeline_exited', 'خروج از مسیر فروش', $payload );
			if ( ! $event_id ) throw new RuntimeException( 'ثبت تاریخچه خروج ناموفق بود.' );
			$queue = KERP_Modules_Leads_SMS::table();
			if ( $wpdb->query( $wpdb->prepare( "UPDATE {$queue} SET status='cancelled' WHERE user_id=%d AND campaign_id=%d AND status='pending'", $user_id, $campaign_id ) ) === FALSE ) throw new RuntimeException( 'لغو پیامک‌های منتظر ناموفق بود.' );
			if ( $send_exit_sms && ! KERP_Modules_Leads_SMS::enqueue_exit( $event_id, $user_id, $campaign_id, $stage_id ) ) throw new RuntimeException( 'ثبت پیامک خروج ناموفق بود.' );
			if ( $wpdb->query( 'COMMIT' ) === FALSE ) throw new RuntimeException( 'ذخیره خروج ناموفق بود.' );
		} catch ( Throwable $error ) {
			$wpdb->query( 'ROLLBACK' );
			return new WP_Error( 'exit_failed', $error->getMessage() );
		}
		try { do_action( 'kerp_leads_pipeline_exited', $user_id, $campaign_id, $stage_id, [ 'event_id' => $event_id, 'membership_id' => (int) $member['id'], 'exited_at' => $now, 'payload' => $payload ] ); }
		catch ( Throwable $error ) { error_log( 'kerp_leads_pipeline_exited callback failed: ' . $error->getMessage() ); }
		return TRUE;
	}

	/** Advance an existing member, preserving the normal timeline and SMS flow. */
	public function advance_stage( int $user_id, int $campaign_id, array $context = [] ): array|WP_Error {
		global $wpdb;
		if ( $user_id < 1 || $campaign_id < 1 || ! get_userdata( $user_id ) ) return new WP_Error( 'invalid_user', 'کاربر یا مسیر معتبر نیست.' );
		$event_id = $context['event_id'] ?? '';
		$expected = $context['expected_stage_id'] ?? NULL;
		if ( ! is_string( $event_id ) || strlen( $event_id ) > 500 || ( $expected !== NULL && ( ! is_scalar( $expected ) || ! ctype_digit( (string) $expected ) ) ) ) return new WP_Error( 'invalid_context', 'شناسه رویداد یا مرحله مبدأ معتبر نیست.' );
		$fingerprint = $event_id !== '' ? 'advance:' . hash( 'sha256', $user_id . ':' . $campaign_id . ':' . $event_id ) : '';
		$memberships = KERP_Modules_Leads_Module::table( 'memberships' );
		$stages_table = KERP_Modules_Leads_Module::table( 'stages' );
		if ( $wpdb->query( 'START TRANSACTION' ) === FALSE ) return new WP_Error( 'advance_failed', 'شروع انتقال ناموفق بود.' );
		$error = NULL;
		try {
			$membership = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$memberships} WHERE user_id=%d AND campaign_id=%d FOR UPDATE", $user_id, $campaign_id ), ARRAY_A );
			if ( ! $membership ) { $error = new WP_Error( 'missing_membership', 'کاربر عضو این مسیر فروش نیست.' ); throw new RuntimeException(); }
			if ( ! empty( $membership['exited_at'] ) ) { $error = new WP_Error( 'pipeline_exited', 'این مشتری از مسیر فروش خارج شده است.' ); throw new RuntimeException(); }
			$current = (int) $membership['current_stage_id'];
			if ( $fingerprint !== '' && $this->fingerprint_exists( $fingerprint ) ) {
				$wpdb->query( 'ROLLBACK' );
				return [ 'status' => 'duplicate', 'stage_id' => $current ];
			}
			$valid = $this->validate_destination( $campaign_id );
			if ( is_wp_error( $valid ) ) { $error = $valid; throw new RuntimeException(); }
			if ( $expected !== NULL && $current !== (int) $expected ) { $error = new WP_Error( 'stage_mismatch', 'مرحله فعلی با مرحله مبدأ مورد انتظار یکسان نیست.' ); throw new RuntimeException(); }
			$stages = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$stages_table} WHERE campaign_id=%d ORDER BY position,id FOR UPDATE", $campaign_id ), ARRAY_A );
			if ( $wpdb->last_error ) throw new RuntimeException();
			$passed = $current === 0; $target = 0;
			foreach ( $stages as $stage ) {
				if ( $current === 0 && KERP_Modules_Leads_Registration::is_reserved_stage( $stage ) ) continue;
				if ( (int) $stage['id'] === $current ) { $passed = TRUE; continue; }
				if ( $passed && ! empty( $stage['active'] ) ) { $target = (int) $stage['id']; break; }
			}
			if ( ! $target ) { $error = new WP_Error( $passed ? 'no_next_stage' : 'invalid_current_stage', $passed ? 'مرحله فعال بعدی وجود ندارد.' : 'مرحله فعلی در این مسیر پیدا نشد.' ); throw new RuntimeException(); }
			$payload = [ 'source' => 'integration', 'event_id' => $event_id, 'from_stage_id' => $current ];
			if ( isset( $context['note'] ) && is_string( $context['note'] ) ) $payload['note'] = sanitize_textarea_field( $context['note'] );
			$moved = $this->move_stage_write( $user_id, $campaign_id, $target, [ 'event_type' => 'stage_changed', 'fingerprint' => $fingerprint, 'payload' => $payload ], $change );
			if ( is_wp_error( $moved ) ) { $error = $moved; throw new RuntimeException(); }
			if ( $wpdb->query( 'COMMIT' ) === FALSE ) throw new RuntimeException();
			$this->notify_stage_changed( $change );
			return [ 'status' => 'advanced', 'from_stage_id' => $current, 'stage_id' => $target ];
		} catch ( Throwable $exception ) {
			$wpdb->query( 'ROLLBACK' );
			return $error ?? new WP_Error( 'advance_failed', 'انتقال مرحله انجام نشد؛ دوباره تلاش کنید.' );
		}
	}

	public function move_stage( int $user_id, int $campaign_id, int $stage_id, array $context = [] ): bool|WP_Error {
		global $wpdb;
		if ( $wpdb->query( 'START TRANSACTION' ) === FALSE ) return new WP_Error( 'stage_failed', 'شروع تغییر مرحله ناموفق بود.' );
		try {
			$result = $this->move_stage_write( $user_id, $campaign_id, $stage_id, $context, $change );
			if ( is_wp_error( $result ) ) { $wpdb->query( 'ROLLBACK' ); return $result; }
			if ( $wpdb->query( 'COMMIT' ) === FALSE ) throw new RuntimeException( 'ذخیره مرحله ناموفق بود.' );
		} catch ( Throwable $error ) { $wpdb->query( 'ROLLBACK' ); return new WP_Error( 'stage_failed', $error->getMessage() ); }
		$this->notify_stage_changed( $change );
		return TRUE;
	}

	/** Transaction-owning callers dispatch the captured notification only after COMMIT. */
	private function move_stage_write( int $user_id, int $campaign_id, int $stage_id, array $context, ?array &$change ): bool|WP_Error {
		$change = NULL;
		global $wpdb;
		$stage = $this->get_stage( $stage_id );
		$valid = $this->validate_destination( $campaign_id, $stage_id );
		if ( is_wp_error( $valid ) ) return $valid;
		if ( ! $stage_id ) return new WP_Error( 'kerp_lead_stage', 'مرحله را انتخاب کنید.' );
		$membership_id = $this->join_campaign( $user_id, $campaign_id );
		if ( is_wp_error( $membership_id ) ) return $membership_id;
		$fingerprint = sanitize_text_field( (string) ( $context['fingerprint'] ?? '' ) );
		if ( $fingerprint !== '' && $this->fingerprint_exists( $fingerprint ) ) return TRUE;
		$table = KERP_Modules_Leads_Module::table( 'memberships' );
		$previous_stage = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id=%d FOR UPDATE", $membership_id ), ARRAY_A );
		if ( ! $previous_stage || ! empty( $previous_stage['exited_at'] ) ) return new WP_Error( 'pipeline_exited', 'این مشتری از مسیر فروش خارج شده است.' );
		if ( isset( $context['expected_stage_id'] ) && (int)$previous_stage['current_stage_id'] !== (int)$context['expected_stage_id'] ) return new WP_Error( 'stage_mismatch', 'مرحله مشتری تغییر کرده است؛ صفحه را تازه کنید.' );
		$ok = $wpdb->update( KERP_Modules_Leads_Module::table( 'memberships' ), [ 'current_stage_id' => $stage_id, 'updated_at' => current_time( 'mysql' ) ], [ 'id' => $membership_id ], [ '%d', '%s' ], [ '%d' ] );
		if ( $ok === FALSE ) return new WP_Error( 'kerp_lead_stage_write', 'مرحله ذخیره نشد.' );
		$entry_event = $this->add_event( $user_id, $campaign_id, $membership_id, $stage_id, sanitize_key( (string) ( $context['event_type'] ?? 'stage_changed' ) ), 'ورود به مرحله «' . $stage['name'] . '»', (array) ( $context['payload'] ?? [] ), $fingerprint );
		if ( ! $entry_event ) return new WP_Error( 'kerp_lead_event_write', 'ثبت تاریخچه مرحله ناموفق بود.' );
		if ( (int) ( $previous_stage['current_stage_id'] ?? 0 ) !== $stage_id && ! KERP_Modules_Leads_SMS::enqueue( $entry_event, $user_id, $campaign_id, $stage_id ) ) return new WP_Error( 'sms_queue', 'مرحله ثبت شد ولی زمان‌بندی پیامک کامل نشد؛ گزارش را بررسی کنید.' );
		$from_id = (int) ( $previous_stage['current_stage_id'] ?? 0 );
		if ( $from_id !== $stage_id ) {
			$from = $from_id ? $this->get_stage( $from_id ) : NULL;
			$change = [ 'user_id' => $user_id, 'campaign_id' => $campaign_id, 'from_stage_id' => $from_id, 'to_stage_id' => $stage_id,
				'event_id' => $entry_event, 'membership_id' => $membership_id,
				'is_forward' => $from && ( (int) $stage['position'] > (int) $from['position'] || ( (int) $stage['position'] === (int) $from['position'] && $stage_id > $from_id ) ),
				'event_type' => sanitize_key( (string) ( $context['event_type'] ?? 'stage_changed' ) ), 'payload' => (array) ( $context['payload'] ?? [] ) ];
		}
		return TRUE;
	}

	private function notify_stage_changed( ?array $change ): void {
		if ( ! $change ) return;
		try {
			do_action( 'kerp_leads_stage_changed', $change['user_id'], $change['campaign_id'], $change['from_stage_id'], $change['to_stage_id'], $change );
		} catch ( Throwable $error ) {
			// A third-party callback cannot undo an already persisted stage or trigger a retry.
			error_log( 'kerp_leads_stage_changed callback failed for event ' . $change['event_id'] . ': ' . $error->getMessage() );
		}
	}

	public function set_attendance( int $user_id, int $campaign_id, string $attendance, array $context = [] ): bool|WP_Error {
		global $wpdb;
		if ( ! in_array( $attendance, [ 'unknown', 'present', 'absent' ], TRUE ) ) return new WP_Error( 'kerp_attendance', 'وضعیت حضور معتبر نیست.' );
		$membership_id = $this->join_campaign( $user_id, $campaign_id );
		if ( is_wp_error( $membership_id ) ) return $membership_id;
		$wpdb->update( KERP_Modules_Leads_Module::table( 'memberships' ), [ 'attendance' => $attendance, 'updated_at' => current_time( 'mysql' ) ], [ 'id' => $membership_id ] );
		$this->add_event( $user_id, $campaign_id, $membership_id, 0, 'attendance_changed', $attendance === 'present' ? 'حضور در وبینار' : ( $attendance === 'absent' ? 'غیبت در وبینار' : 'حضور نامشخص' ), $context );
		return TRUE;
	}

    public function update_membership( int $user_id, int $campaign_id, int $stage_id, int $owner_id, string $note ): bool|WP_Error {
        global $wpdb;
        $previous = $this->get_membership( $user_id, $campaign_id );
        if ( ! $previous ) return new WP_Error( 'missing_membership', 'مسیر فروش مشتری پیدا نشد.' );
        if ( ! empty( $previous['exited_at'] ) ) return new WP_Error( 'pipeline_exited', 'این مشتری از مسیر فروش خارج شده است.' );
        $stage_changed = (int) $previous['current_stage_id'] !== $stage_id;
        if ( $stage_changed ) {
            if ( ! $stage_id ) return new WP_Error( 'missing_stage', 'مرحله را انتخاب کنید.' );
            $valid = $this->validate_destination( $campaign_id, $stage_id );
            if ( is_wp_error( $valid ) ) return $valid;
        }
        if ( $owner_id && ! get_userdata( $owner_id ) ) return new WP_Error( 'invalid_owner', 'کارشناس انتخاب‌شده معتبر نیست.' );
        if ( $wpdb->query( 'START TRANSACTION' ) === FALSE ) return new WP_Error( 'save_failed', 'شروع ذخیره تغییرات ناموفق بود.' );
        try {
            $table = KERP_Modules_Leads_Module::table( 'memberships' );
            $locked = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id=%d FOR UPDATE", $previous['id'] ), ARRAY_A );
            if ( ! $locked || ! empty( $locked['exited_at'] ) ) throw new RuntimeException( 'این مشتری از مسیر فروش خارج شده است.' );
            if ( (int) $locked['current_stage_id'] !== (int) $previous['current_stage_id'] || (int) $locked['owner_id'] !== (int) $previous['owner_id'] ) throw new RuntimeException( 'اطلاعات مشتری تغییر کرده است؛ صفحه را تازه کنید.' );
            if ( (int) $previous['owner_id'] !== $owner_id ) {
                $result = $this->assign_owner( $user_id, $campaign_id, $owner_id );
                if ( is_wp_error( $result ) ) throw new RuntimeException( $result->get_error_message() );
            }
            $payload = [ 'note' => wp_kses_post( $note ), 'note_format' => 'html' ];
            if ( $stage_changed ) {
                $result = $this->move_stage_write( $user_id, $campaign_id, $stage_id, [ 'event_type' => 'manual', 'payload' => $payload ], $change );
                if ( is_wp_error( $result ) ) throw new RuntimeException( $result->get_error_message() );
            } elseif ( $note !== '' && ! $this->add_event( $user_id, $campaign_id, (int) $previous['id'], $stage_id, 'note_added', 'ثبت توضیح در مسیر فروش', $payload ) ) {
                throw new RuntimeException( 'توضیح ذخیره نشد.' );
            }
            if ( $wpdb->query( 'COMMIT' ) === FALSE ) throw new RuntimeException( 'ذخیره تغییرات ناموفق بود.' );
        } catch ( Throwable $error ) {
            $wpdb->query( 'ROLLBACK' );
            wp_cache_delete( $user_id, 'user_meta' );
            return new WP_Error( 'membership_save', $error->getMessage() );
        }
        $this->notify_stage_changed( $change ?? NULL );
        return TRUE;
    }

	public function assign_owner( int $user_id, int $campaign_id, int $owner_id ): bool|WP_Error {
		global $wpdb;
		if ( $owner_id && ! get_userdata( $owner_id ) ) return new WP_Error( 'kerp_lead_owner', 'کارشناس انتخاب‌شده معتبر نیست.' );
		$membership_id = $this->join_campaign( $user_id, $campaign_id );
		if ( is_wp_error( $membership_id ) ) return $membership_id;
		$previous = $this->get_membership( $user_id, $campaign_id );
		$ok = $wpdb->update( KERP_Modules_Leads_Module::table( 'memberships' ), [ 'owner_id' => $owner_id, 'updated_at' => current_time( 'mysql' ) ], [ 'id' => $membership_id ], [ '%d', '%s' ], [ '%d' ] );
		if ( $ok === FALSE ) return new WP_Error( 'kerp_lead_owner_save', 'تخصیص کارشناس ذخیره نشد.' );
        $meta_key = $this->customer_owner_meta_key();
        if ( $owner_id ) update_user_meta( $user_id, $meta_key, $owner_id );
        else delete_user_meta( $user_id, $meta_key );
        if ( absint( get_user_meta( $user_id, $meta_key, TRUE ) ) !== $owner_id ) {
            $wpdb->update( KERP_Modules_Leads_Module::table( 'memberships' ), [ 'owner_id' => (int) $previous['owner_id'], 'updated_at' => $previous['updated_at'] ], [ 'id' => $membership_id ] );
            return new WP_Error( 'kerp_customer_owner_save', 'مسئول مشتری ذخیره نشد؛ دوباره تلاش کنید.' );
        }
		$owner = $owner_id ? get_userdata( $owner_id ) : NULL;
		$this->add_event( $user_id, $campaign_id, $membership_id, 0, 'owner_assigned', $owner instanceof WP_User ? 'تخصیص به «' . get_user_name_by_id( $owner->ID ) . '»' : 'حذف تخصیص کارشناس' );
		return TRUE;
	}

	public function add_event( int $user_id, int $campaign_id, int $membership_id, int $stage_id, string $type, string $title, array $payload = [], string $fingerprint = '' ): int {
		global $wpdb;
		$ok = $wpdb->insert( KERP_Modules_Leads_Module::table( 'events' ), [ 'membership_id' => $membership_id ?: NULL, 'user_id' => $user_id, 'campaign_id' => $campaign_id, 'stage_id' => $stage_id ?: NULL, 'event_type' => sanitize_key( $type ), 'title' => sanitize_text_field( $title ), 'actor_id' => get_current_user_id(), 'fingerprint' => $fingerprint !== '' ? $fingerprint : NULL, 'payload' => wp_json_encode( $payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ), 'occurred_at' => current_time( 'mysql' ) ] );
		return $ok === FALSE ? 0 : (int) $wpdb->insert_id;
	}

	public function validate_destination( int $campaign_id, int $stage_id = 0 ): bool|WP_Error {
		$campaign = $this->get_campaign( $campaign_id );
		if ( ! $campaign || $campaign['status'] !== 'active' ) return new WP_Error( 'kerp_pipeline_invalid', 'مسیر فروش فعال را انتخاب کنید.' );
		if ( $stage_id ) {
			$stage = $this->get_stage( $stage_id );
			if ( ! $stage || empty( $stage['active'] ) || (int) $stage['campaign_id'] !== $campaign_id ) return new WP_Error( 'kerp_pipeline_stage', 'مرحله انتخاب‌شده متعلق به این مسیر فروش نیست یا غیرفعال است.' );
		}
		return TRUE;
	}

	public function get_membership( int $user_id, int $campaign_id ): ?array {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . KERP_Modules_Leads_Module::table( 'memberships' ) . ' WHERE user_id=%d AND campaign_id=%d', $user_id, $campaign_id ), ARRAY_A );
	}

	/** Add a parallel membership. Existing destinations are never rewound or reassigned. */
	public function branch( int $user_id, int $source_campaign_id, int $source_stage_id, int $target_campaign_id, int $target_stage_id, string $note = '', bool $rich_note = FALSE ): array|WP_Error {
		global $wpdb;
		if ( $source_campaign_id === $target_campaign_id ) return new WP_Error( 'kerp_branch_same', 'مسیر فروش مقصد باید با مبدأ متفاوت باشد.' );
		if ( ! get_userdata( $user_id ) || ! $source_stage_id || ! $target_stage_id ) return new WP_Error( 'kerp_branch_input', 'کاربر و مرحله مبدأ و مقصد را انتخاب کنید.' );
		$valid = $this->validate_destination( $target_campaign_id, $target_stage_id );
		if ( is_wp_error( $valid ) ) return $valid;
		$source_stage = $this->get_stage( $source_stage_id );
		$source_campaign = $this->get_campaign( $source_campaign_id );
		$target_campaign = $this->get_campaign( $target_campaign_id );
		if ( ! $source_campaign || ! $source_stage || (int) $source_stage['campaign_id'] !== $source_campaign_id ) return new WP_Error( 'kerp_branch_source', 'مرحله مبدأ معتبر نیست.' );
		$table = KERP_Modules_Leads_Module::table( 'memberships' );
		if ( $wpdb->query( 'START TRANSACTION' ) === FALSE ) return new WP_Error( 'kerp_branch_db', 'شروع ثبت عضویت ناموفق بود.' );
		try {
			$source = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE user_id=%d AND campaign_id=%d FOR UPDATE", $user_id, $source_campaign_id ), ARRAY_A );
			if ( ! $source || ! empty( $source['exited_at'] ) || (int) $source['current_stage_id'] !== $source_stage_id ) {
				$wpdb->query( 'ROLLBACK' );
				return new WP_Error( 'kerp_branch_stale', 'کاربر دیگر در مرحله مبدأ انتخاب‌شده نیست؛ صفحه را تازه کنید.' );
			}
			$existing = $this->get_membership( $user_id, $target_campaign_id );
			if ( $existing ) {
				$wpdb->query( 'ROLLBACK' );
				return [ 'added' => FALSE, 'membership_id' => (int) $existing['id'] ];
			}
			$now = current_time( 'mysql' );
			$ok = $wpdb->insert( $table, [ 'user_id' => $user_id, 'campaign_id' => $target_campaign_id, 'current_stage_id' => $target_stage_id, 'owner_id' => $this->customer_owner( $user_id ) ?: (int) $source['owner_id'], 'attendance' => 'unknown', 'source' => 'pipeline:' . $source_campaign_id, 'utm_json' => $source['utm_json'], 'joined_at' => $now, 'updated_at' => $now ] );
			if ( $ok === FALSE ) throw new RuntimeException( 'membership' );
			$id = (int) $wpdb->insert_id;
			$target_stage = $this->get_stage( $target_stage_id );
			$payload = [ 'from_campaign_id' => $source_campaign_id, 'from_campaign_name' => $source_campaign['name'], 'from_stage_id' => $source_stage_id, 'from_stage_name' => $source_stage['name'], 'to_campaign_id' => $target_campaign_id, 'to_campaign_name' => $target_campaign['name'], 'to_stage_id' => $target_stage_id, 'to_stage_name' => $target_stage['name'], 'note' => $rich_note ? wp_kses_post( $note ) : sanitize_textarea_field( $note ), 'note_format' => $rich_note ? 'html' : 'text' ];
			$in = $this->add_event( $user_id, $target_campaign_id, $id, $target_stage_id, 'pipeline_joined', 'ورود از «' . $source_campaign['name'] . '» به «' . $target_stage['name'] . '»', $payload );
			$out = $this->add_event( $user_id, $source_campaign_id, (int) $source['id'], $source_stage_id, 'pipeline_branched', 'عضویت هم‌زمان در «' . $target_campaign['name'] . '»', $payload );
			if ( ! $in || ! $out || $wpdb->query( 'COMMIT' ) === FALSE ) throw new RuntimeException( 'history' );
			$this->notify_stage_changed( [ 'user_id' => $user_id, 'campaign_id' => $target_campaign_id, 'from_stage_id' => 0, 'to_stage_id' => $target_stage_id, 'event_id' => $in, 'membership_id' => $id, 'is_forward' => FALSE, 'event_type' => 'pipeline_joined', 'payload' => $payload ] );
			return [ 'added' => TRUE, 'membership_id' => $id ];
		} catch ( Throwable $error ) {
			$wpdb->query( 'ROLLBACK' );
			return new WP_Error( 'kerp_branch_save', 'عضویت و تاریخچه ذخیره نشد؛ دوباره تلاش کنید.' );
		}
	}

	public function branch_many( array $user_ids, int $source_campaign_id, int $source_stage_id, int $target_campaign_id, int $target_stage_id, string $note = '', bool $rich_note = FALSE ): array|WP_Error {
		$user_ids = array_values( array_unique( array_filter( array_map( 'absint', $user_ids ) ) ) );
		if ( ! $user_ids || count( $user_ids ) > 100 ) return new WP_Error( 'kerp_branch_selection', 'بین ۱ تا ۱۰۰ کاربر را انتخاب کنید.' );
		$valid = $this->validate_destination( $target_campaign_id, $target_stage_id );
		if ( is_wp_error( $valid ) ) return $valid;
		if ( ! $source_stage_id || ! $target_stage_id || $source_campaign_id === $target_campaign_id ) return new WP_Error( 'kerp_branch_selection', 'مراحل مبدأ و مقصد را در دو مسیر فروش متفاوت انتخاب کنید.' );
		$result = [ 'added' => 0, 'existing' => 0, 'failed' => 0, 'errors' => [] ];
		foreach ( $user_ids as $user_id ) {
			$outcome = $this->branch( $user_id, $source_campaign_id, $source_stage_id, $target_campaign_id, $target_stage_id, $note, $rich_note );
			if ( is_wp_error( $outcome ) ) { $result['failed']++; $result['errors'][] = '#' . $user_id . ': ' . $outcome->get_error_message(); }
			else $result[ $outcome['added'] ? 'added' : 'existing' ]++;
		}
		return $result;
	}

	public function find_memberships( int $campaign_id = 0, int $stage_id = 0, int $page = 1, int $per_page = 50, string $search = '', ?int $owner_id = NULL, array $joined = [], bool $unique_customers = FALSE, array $entry = [], string $membership_status = 'active', array $registration = [] ): array {
		global $wpdb;
		$m = KERP_Modules_Leads_Module::table( 'memberships' ); $c = KERP_Modules_Leads_Module::table( 'campaigns' ); $s = KERP_Modules_Leads_Module::table( 'stages' );
		$where = $membership_status === 'all' ? '1=1' : ( $membership_status === 'exited' ? 'm.exited_at IS NOT NULL' : 'm.exited_at IS NULL' );
		if ( $campaign_id ) $where .= $wpdb->prepare( ' AND m.campaign_id=%d', $campaign_id );
		if ( $owner_id !== NULL ) $where .= $wpdb->prepare( ' AND m.owner_id=%d', $owner_id );
		if ( $stage_id ) $where .= $wpdb->prepare( ' AND m.current_stage_id=%d', $stage_id );
		$search = sanitize_text_field( $search );
		if ( $search !== '' ) {
			$like = '%' . $wpdb->esc_like( $search ) . '%';
			$where .= $wpdb->prepare( " AND (EXISTS (SELECT 1 FROM {$wpdb->users} u WHERE u.ID=m.user_id AND u.display_name LIKE %s)
				OR EXISTS (SELECT 1 FROM {$wpdb->usermeta} um WHERE um.user_id=m.user_id AND um.meta_key IN ('first_name','last_name','billing_phone','nooshika_phone_num') AND um.meta_value LIKE %s))", $like, $like );
		}
		// Compare local membership timestamps directly so date indexes remain usable.
		$bounds = [];
		foreach ( [ 'from', 'to' ] as $edge ) {
			$raw = $joined[ $edge ] ?? '';
			$date = is_scalar( $raw ) ? trim( (string) $raw ) : '';
			if ( $date === '' && is_scalar( $raw ) ) continue;
			$bounds[ $edge ] = KERP_Helpers_Date::jalali_to_gregorian( str_replace( '/', '-', $date ) );
			if ( $bounds[ $edge ] === '' ) return [ 'items' => [], 'total' => 0, 'pages' => 1, 'page' => 1, 'error' => 'تاریخ ورود به مسیر معتبر نیست؛ تاریخ شمسی وارد کنید.' ];
		}
		if ( isset( $bounds['from'], $bounds['to'] ) && $bounds['from'] > $bounds['to'] ) return [ 'items' => [], 'total' => 0, 'pages' => 1, 'page' => 1, 'error' => 'تاریخ شروع نباید بعد از تاریخ پایان باشد.' ];
		if ( isset( $bounds['from'] ) ) $where .= $wpdb->prepare( ' AND m.joined_at >= %s', $bounds['from'] . ' 00:00:00' );
		if ( isset( $bounds['to'] ) ) {
			$until = ( new DateTimeImmutable( $bounds['to'], wp_timezone() ) )->modify( '+1 day' )->format( 'Y-m-d' );
			$where .= $wpdb->prepare( ' AND m.joined_at < %s', $until . ' 00:00:00' );
		}
		// Heatmap drill-down follows historical entries, regardless of the current stage.
		if ( ! empty( $entry['stage'] ) || ! empty( $entry['day'] ) ) {
			$entry_stage = is_scalar( $entry['stage'] ?? NULL ) ? absint( $entry['stage'] ) : 0;
			$entry_day = is_scalar( $entry['day'] ?? NULL ) ? KERP_Helpers_Date::jalali_to_gregorian( str_replace( '/', '-', (string) $entry['day'] ) ) : '';
			if ( ! $campaign_id || ! $entry_stage || $entry_day === '' ) return [ 'items' => [], 'total' => 0, 'pages' => 1, 'page' => 1, 'error' => 'برای ورودی روزانه، مسیر فروش، مرحله و تاریخ شمسی معتبر را انتخاب کنید.' ];
			$entry_until = ( new DateTimeImmutable( $entry_day, wp_timezone() ) )->modify( '+1 day' )->format( 'Y-m-d' );
			$e = KERP_Modules_Leads_Module::table( 'events' );
			$where .= $wpdb->prepare( " AND EXISTS (SELECT 1 FROM {$e} e WHERE e.user_id=m.user_id AND e.campaign_id=m.campaign_id AND e.stage_id=%d AND e.occurred_at >= %s AND e.occurred_at < %s AND e.event_type IN ('stage_changed','manual','product_purchased','gravity_form','learndash_completed','webhook','pipeline_joined'))", $entry_stage, $entry_day . ' 00:00:00', $entry_until . ' 00:00:00' );
		}
		$where .= KERP_Modules_Leads_Registration::filter_sql( $registration, $campaign_id );
		// Select one matching membership per customer before counting and pagination.
		if ( $unique_customers ) $where = "m.id IN (SELECT MIN(m.id) FROM {$m} m WHERE {$where} GROUP BY m.user_id)";
		$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$m} m WHERE {$where}" );
		$per_page = max( 1, min( 100, $per_page ) );
		$pages = max( 1, (int) ceil( $total / $per_page ) ); $page = max( 1, min( $pages, $page ) );
		$items = (array) $wpdb->get_results( $wpdb->prepare( "SELECT m.*,c.name campaign_name,s.name stage_name FROM {$m} m JOIN {$c} c ON c.id=m.campaign_id LEFT JOIN {$s} s ON s.id=m.current_stage_id WHERE {$where} ORDER BY m.updated_at DESC,m.id DESC LIMIT %d OFFSET %d", $per_page, ( $page - 1 ) * $per_page ), ARRAY_A );
		return compact( 'items', 'total', 'pages', 'page' );
	}

	/** Count independently: joining both tables would multiply memberships by stages. */
	public function find_pipelines( array $query, int $per_page ): array {
		global $wpdb;
		$c = KERP_Modules_Leads_Module::table( 'campaigns' );
		$s = KERP_Modules_Leads_Module::table( 'stages' );
		$m = KERP_Modules_Leads_Module::table( 'memberships' );
		$where = '1=1';
		$search = isset( $query['search'] ) && is_scalar( $query['search'] ) ? sanitize_text_field( (string) $query['search'] ) : '';
		$status = isset( $query['status'] ) && is_scalar( $query['status'] ) ? (string) $query['status'] : '';
		if ( $search !== '' ) $where .= $wpdb->prepare( ' AND c.name LIKE %s', '%' . $wpdb->esc_like( $search ) . '%' );
		if ( in_array( $status, [ 'active', 'archived' ], TRUE ) ) $where .= $wpdb->prepare( ' AND c.status=%s', $status );
		$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$c} c WHERE {$where}" );
		$per_page = max( 1, min( 100, $per_page ) );
		$pages = max( 1, (int) ceil( $total / $per_page ) );
		$page = min( $pages, max( 1, absint( $query['page_number'] ?? 1 ) ) );
		$items = (array) $wpdb->get_results( $wpdb->prepare( "SELECT c.*,
			(SELECT COUNT(*) FROM {$s} s WHERE s.campaign_id=c.id) stage_count,
			(SELECT COUNT(*) FROM {$m} m WHERE m.campaign_id=c.id AND m.exited_at IS NULL) member_count
			FROM {$c} c WHERE {$where} ORDER BY c.id DESC LIMIT %d OFFSET %d", $per_page, ( $page - 1 ) * $per_page ), ARRAY_A );
		return compact( 'items', 'total', 'pages', 'page' );
	}

	public function pipeline_summary( int $campaign_id ): array {
		global $wpdb;
		$s = KERP_Modules_Leads_Module::table( 'stages' );
		$m = KERP_Modules_Leads_Module::table( 'memberships' );
		$stages = (array) $wpdb->get_results( $wpdb->prepare( "SELECT s.*,
			(SELECT COUNT(*) FROM {$m} m WHERE m.campaign_id=s.campaign_id AND m.current_stage_id=s.id AND m.exited_at IS NULL) member_count
			FROM {$s} s WHERE s.campaign_id=%d ORDER BY s.position,s.id", $campaign_id ), ARRAY_A );
		$total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$m} WHERE campaign_id=%d AND exited_at IS NULL", $campaign_id ) );
		$unassigned = max( 0, $total - array_sum( array_column( $stages, 'member_count' ) ) );
		return compact( 'stages', 'total', 'unassigned' );
	}

    /** Remove only this pipeline's records, never customers, orders or other paths. */
    public function delete_campaign( int $campaign_id ): bool|WP_Error {
        global $wpdb;
        if ( $campaign_id < 1 ) return new WP_Error( 'invalid_pipeline', 'مسیر فروش معتبر نیست.' );
        $campaigns = KERP_Modules_Leads_Module::table( 'campaigns' );
        if ( $wpdb->query( 'START TRANSACTION' ) === FALSE ) return new WP_Error( 'delete_start', 'شروع حذف ناموفق بود.' );
        try {
            $exists = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$campaigns} WHERE id=%d FOR UPDATE", $campaign_id ) );
            if ( ! $exists ) {
                $wpdb->query( 'ROLLBACK' );
                return new WP_Error( 'missing_pipeline', 'مسیر فروش پیدا نشد؛ صفحه را تازه کنید.' );
            }
            foreach ( [ 'events', 'memberships', 'stages' ] as $name ) {
                if ( $wpdb->delete( KERP_Modules_Leads_Module::table( $name ), [ 'campaign_id' => $campaign_id ], [ '%d' ] ) === FALSE ) throw new RuntimeException();
            }
            if ( $wpdb->delete( $campaigns, [ 'id' => $campaign_id ], [ '%d' ] ) !== 1 ) throw new RuntimeException();
            if ( $wpdb->query( 'COMMIT' ) === FALSE ) throw new RuntimeException();
        } catch ( Throwable $error ) {
            $wpdb->query( 'ROLLBACK' );
            return new WP_Error( 'pipeline_delete_failed', 'حذف مسیر فروش انجام نشد؛ دوباره تلاش کنید.' );
        }
        return TRUE;
    }

	public function duplicate_campaign( int $source_id, string $name ): int|WP_Error {
		global $wpdb;
		$name = sanitize_text_field( $name );
		if ( $source_id < 1 || $name === '' || mb_strlen( $name ) > 190 ) return new WP_Error( 'invalid_pipeline', 'مسیر مبدأ و نام معتبر تا ۱۹۰ نویسه وارد کنید.' );
		$campaigns = KERP_Modules_Leads_Module::table( 'campaigns' );
		$stages = KERP_Modules_Leads_Module::table( 'stages' );
		if ( $wpdb->query( 'START TRANSACTION' ) === FALSE ) return new WP_Error( 'copy_start', 'شروع تکثیر ناموفق بود.' );
		$option_names = [];
		try {
			$source = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$campaigns} WHERE id=%d FOR UPDATE", $source_id ), ARRAY_A );
			if ( ! $source ) throw new RuntimeException();
			$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$stages} WHERE campaign_id=%d ORDER BY position,id FOR UPDATE", $source_id ), ARRAY_A );
			if ( $wpdb->last_error ) throw new RuntimeException();
			$now = current_time( 'mysql' );
			unset( $source['id'] );
			$source['name'] = $name;
			$source['created_by'] = get_current_user_id();
			$source['created_at'] = $source['updated_at'] = $now;
			if ( $wpdb->insert( $campaigns, $source ) !== 1 ) throw new RuntimeException();
			$new_id = (int) $wpdb->insert_id;
			foreach ( $rows as $row ) {
				$old_stage_id = (int) $row['id'];
				unset( $row['id'] );
				$row['campaign_id'] = $new_id;
				$row['created_at'] = $row['updated_at'] = $now;
				if ( $wpdb->insert( $stages, $row ) !== 1 ) throw new RuntimeException();
				$new_stage_id = (int) $wpdb->insert_id;
				$action_config = $this->stage_actions( $old_stage_id );
				if ( $action_config ) {
					$action_option = 'kerp_lead_stage_actions_' . $new_stage_id;
					if ( $wpdb->insert( $wpdb->options, [ 'option_name'=>$action_option, 'option_value'=>maybe_serialize( $action_config ), 'autoload'=>'no' ] ) !== 1 ) throw new RuntimeException();
					$option_names[] = $action_option;
				}
				$raw = $wpdb->get_var( $wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_name=%s FOR UPDATE", 'kerp_lead_stage_sms_' . $old_stage_id ) );
				if ( $wpdb->last_error ) throw new RuntimeException();
				if ( $raw !== NULL ) {
					$config = maybe_unserialize( $raw );
					if ( ! is_array( $config ) ) throw new RuntimeException();
					$config['revision'] = wp_generate_uuid4();
					$option_name = 'kerp_lead_stage_sms_' . $new_stage_id;
					// Write inside the same transaction, without publishing uncommitted option caches.
					if ( $wpdb->insert( $wpdb->options, [ 'option_name' => $option_name, 'option_value' => maybe_serialize( $config ), 'autoload' => 'no' ] ) !== 1 ) throw new RuntimeException();
					$option_names[] = $option_name;
				}
			}
			$exit_config = KERP_Modules_Leads_SMS::exit_config( $source_id );
			if ( $exit_config ) {
				$exit_config['revision'] = wp_generate_uuid4();
				$option_name = 'kerp_lead_exit_sms_' . $new_id;
				if ( $wpdb->insert( $wpdb->options, [ 'option_name'=>$option_name, 'option_value'=>maybe_serialize( $exit_config ), 'autoload'=>'no' ] ) !== 1 ) throw new RuntimeException();
				$option_names[] = $option_name;
			}
			if ( $wpdb->query( 'COMMIT' ) === FALSE ) throw new RuntimeException();
		} catch ( Throwable $error ) {
			$wpdb->query( 'ROLLBACK' );
			return new WP_Error( 'pipeline_copy_failed', 'تکثیر مسیر فروش انجام نشد؛ صفحه را تازه کنید و دوباره تلاش کنید.' );
		}
		update_option( 'kerp_lead_registration_' . $new_id, KERP_Modules_Leads_Registration::config( $source_id ), FALSE );
		foreach ( $option_names as $option_name ) wp_cache_delete( $option_name, 'options' );
		wp_cache_delete( 'notoptions', 'options' );
		return $new_id;
	}

	public function save_campaign( array $data, int $id = 0 ): int|WP_Error {
		global $wpdb; $name = sanitize_text_field( (string) ( $data['name'] ?? '' ) );
		if ( $name === '' ) return new WP_Error( 'kerp_campaign_name', 'نام کمپین الزامی است.' );
		$now = current_time( 'mysql' );
		$existing = $id ? $this->get_campaign( $id ) : NULL;
		if ( $id && ! $existing ) return new WP_Error( 'kerp_pipeline_missing', 'مسیر فروش پیدا نشد.' );
		$row = [ 'name' => $name, 'type' => 'pipeline', 'status' => in_array( (string) ( $data['status'] ?? '' ), [ 'active', 'archived' ], TRUE ) ? $data['status'] : ( $existing['status'] ?? 'active' ), 'updated_at' => $now ];
		if ( $id ) $ok = $wpdb->update( KERP_Modules_Leads_Module::table( 'campaigns' ), $row, [ 'id' => $id ] );
		else { $row['created_by'] = get_current_user_id(); $row['created_at'] = $now; $ok = $wpdb->insert( KERP_Modules_Leads_Module::table( 'campaigns' ), $row ); $id = (int) $wpdb->insert_id; }
		return $ok === FALSE || ! $id ? new WP_Error( 'kerp_campaign_save', 'ذخیره کمپین انجام نشد.' ) : $id;
	}

	public function delete_stage( int $campaign_id, int $stage_id ): bool|WP_Error {
		if ( $campaign_id < 1 || $stage_id < 1 ) return new WP_Error( 'invalid_stage', 'مرحله یا مسیر فروش معتبر نیست.' );
		$stage = $this->get_stage( $stage_id );
		if ( ! $stage || (int) $stage['campaign_id'] !== $campaign_id || ! $this->get_campaign( $campaign_id ) ) return new WP_Error( 'invalid_stage', 'مرحله در این مسیر فروش پیدا نشد.' );
		if ( KERP_Modules_Leads_Registration::is_reserved_stage( $stage ) ) return new WP_Error( 'reserved_stage', 'دو مرحله اول برای فرم ثبت‌نام رزرو شده‌اند و قابل حذف نیستند.' );
		global $wpdb;
		$stages = KERP_Modules_Leads_Module::table( 'stages' );
		$memberships = KERP_Modules_Leads_Module::table( 'memberships' );
		$events = KERP_Modules_Leads_Module::table( 'events' );
		// Keep referenced stages intact so customer journeys and analytics retain their links.
		$result = $wpdb->query( $wpdb->prepare(
			"DELETE FROM {$stages} WHERE id=%d AND campaign_id=%d
			 AND NOT EXISTS (SELECT 1 FROM {$memberships} WHERE current_stage_id=%d)
			 AND NOT EXISTS (SELECT 1 FROM {$events} WHERE stage_id=%d)",
			$stage_id, $campaign_id, $stage_id, $stage_id
		) );
		if ( $result === FALSE ) return new WP_Error( 'stage_delete_failed', 'حذف مرحله انجام نشد؛ دوباره تلاش کنید.' );
		if ( $result !== 1 ) return new WP_Error( 'stage_in_use', 'مرحله حذف نشد؛ ممکن است تغییر کرده باشد یا مشتری یا سابقه داشته باشد. صفحه را تازه کنید. برای حفظ سوابق، مرحله را از بخش ویرایش غیرفعال کنید.' );
		return TRUE;
	}

	public function save_stage( array $data, int $id = 0 ): int|WP_Error {
		global $wpdb; $name = sanitize_text_field( (string) ( $data['name'] ?? '' ) );
		if ( $name === '' ) return new WP_Error( 'kerp_stage_name', 'نام مرحله الزامی است.' );
		$campaign_id = absint( $data['campaign_id'] ?? 0 );
		if ( ! $campaign_id || ! $this->get_campaign( $campaign_id ) ) return new WP_Error( 'kerp_stage_campaign', 'هر مرحله باید متعلق به یک مسیر فروش مشخص باشد.' );
		$existing = $id ? $this->get_stage( $id ) : NULL;
		if ( $id && ( ! $existing || (int) $existing['campaign_id'] !== $campaign_id ) ) return new WP_Error( 'kerp_stage_campaign', 'تغییر مسیر فروش مرحله مجاز نیست؛ در مقصد مرحله جدید بسازید.' );
		if ( KERP_Modules_Leads_Registration::is_reserved_stage( $existing ?? [] ) || KERP_Modules_Leads_Registration::is_reserved_stage( $data ) ) return new WP_Error( 'reserved_stage', 'دو مرحله اول برای فرم ثبت‌نام رزرو شده‌اند و قابل ویرایش نیستند.' );
		$trigger = sanitize_key( (string) ( $data['trigger_type'] ?? 'manual' ) );
		$ref_key = match ( $trigger ) { 'gravity_form' => 'form_id', 'learndash_completed' => 'lesson_id', default => 'product_id' };
		if ( in_array( $trigger, [ 'gravity_form', 'product_purchase', 'learndash_completed' ], TRUE ) && array_key_exists( $ref_key, $data ) ) $data['trigger_ref'] = $data[ $ref_key ];
		if ( isset( $data['trigger_ref'] ) && ! is_scalar( $data['trigger_ref'] ) ) return new WP_Error( 'kerp_stage_reference', 'انتخاب فرم، محصول یا درس معتبر نیست.' );
		if ( ! in_array( $trigger, [ 'manual', 'gravity_form', 'product_purchase', 'learndash_completed', 'webhook' ], TRUE ) ) $trigger = 'manual';
		if ( $trigger !== 'manual' && ! absint( $data['campaign_id'] ?? 0 ) ) return new WP_Error( 'kerp_stage_campaign', 'مرحله خودکار باید به یک کمپین مشخص متصل باشد.' );
		if ( in_array( $trigger, [ 'gravity_form', 'product_purchase', 'learndash_completed' ], TRUE ) && ! preg_match( '/^[1-9][0-9]*$/D', (string) ( $data['trigger_ref'] ?? '' ) ) ) return new WP_Error( 'kerp_stage_reference', 'فرم، محصول یا درس موردنظر را انتخاب کنید.' );
		if ( $trigger === 'gravity_form' ) {
			$form = class_exists( 'GFAPI' ) ? GFAPI::get_form( absint( $data['trigger_ref'] ) ) : FALSE;
			if ( ! is_array( $form ) || empty( $form['is_active'] ) || ! empty( $form['is_trash'] ) ) return new WP_Error( 'kerp_stage_form', 'یک فرم گرویتی فعال انتخاب کنید.' );
		}
		if ( $trigger === 'product_purchase' ) {
			$product = function_exists( 'wc_get_product' ) ? wc_get_product( absint( $data['trigger_ref'] ) ) : FALSE;
			if ( ! $product || in_array( $product->get_status(), [ 'trash', 'auto-draft' ], TRUE ) ) return new WP_Error( 'kerp_stage_product', 'یک محصول معتبر انتخاب کنید.' );
		}
		if ( $trigger === 'manual' ) $data['trigger_ref'] = '';
		if ( $trigger === 'learndash_completed' ) {
			$lesson = get_post( absint( $data['trigger_ref'] ) );
			if ( ! function_exists( 'learndash_process_mark_complete' ) || ! $lesson instanceof WP_Post || ! in_array( $lesson->post_type, [ 'sfwd-lessons', 'sfwd-topic' ], TRUE ) || $lesson->post_status !== 'publish' ) return new WP_Error( 'kerp_stage_lesson', 'یک درس یا مبحث منتشرشده از لرندش انتخاب کنید.' );
		}
		if ( $trigger === 'webhook' && ! array_key_exists( 'trigger_ref', $data ) ) $data['trigger_ref'] = ( $existing['trigger_type'] ?? '' ) === 'webhook' ? ( $existing['trigger_ref'] ?? '' ) : '';
		$now = current_time( 'mysql' ); $slug = sanitize_title( (string) ( $data['slug'] ?? $name ) );
		if ( $slug === '' || strlen( $slug ) > 90 ) $slug = 'stage-' . substr( md5( $name ), 0, 12 );
		$proposal_status = sanitize_key( (string) ( $data['proposal_status'] ?? $slug ) );
		if ( $proposal_status === '' ) $proposal_status = 'custom-' . substr( md5( $name ), 0, 12 );
		$row = [ 'campaign_id' => absint( $data['campaign_id'] ?? 0 ), 'name' => $name, 'slug' => $slug, 'proposal_status' => $proposal_status, 'trigger_type' => $trigger, 'trigger_ref' => sanitize_text_field( (string) ( $data['trigger_ref'] ?? '' ) ), 'position' => absint( $data['position'] ?? 0 ), 'active' => empty( $data['active'] ) ? 0 : 1, 'updated_at' => $now ];
		$has_form_stages = $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . KERP_Modules_Leads_Module::table( 'stages' ) . " WHERE campaign_id=%d AND trigger_type IN ('registration_started','registration_completed') LIMIT 1", $campaign_id ) );
		if ( $wpdb->last_error ) return new WP_Error( 'kerp_stage_save', 'خواندن ترتیب مراحل انجام نشد.' );
		if ( $has_form_stages ) $row['position'] = max( 30, $row['position'] );
		if ( $id ) $ok = $wpdb->update( KERP_Modules_Leads_Module::table( 'stages' ), $row, [ 'id' => $id ] );
		else { $row['created_at'] = $now; $ok = $wpdb->insert( KERP_Modules_Leads_Module::table( 'stages' ), $row ); $id = (int) $wpdb->insert_id; }
		return $ok === FALSE || ! $id ? new WP_Error( 'kerp_stage_save', 'ذخیره مرحله انجام نشد.' ) : $id;
	}

	public function get_campaigns(): array { global $wpdb; return (array) $wpdb->get_results( 'SELECT * FROM ' . KERP_Modules_Leads_Module::table( 'campaigns' ) . ' ORDER BY id DESC', ARRAY_A ); }
	public function get_campaign( int $id ): ?array { global $wpdb; $row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . KERP_Modules_Leads_Module::table( 'campaigns' ) . ' WHERE id=%d', $id ), ARRAY_A ); return is_array( $row ) ? $row : NULL; }
	public function get_stages( int $campaign_id = 0 ): array { global $wpdb; if ( ! $campaign_id ) return []; return (array) $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . KERP_Modules_Leads_Module::table( 'stages' ) . ' WHERE active=1 AND campaign_id=%d ORDER BY position,id', $campaign_id ), ARRAY_A ); }
	public function get_all_stages(): array { global $wpdb; return (array) $wpdb->get_results( 'SELECT * FROM ' . KERP_Modules_Leads_Module::table( 'stages' ) . ' WHERE campaign_id>0 ORDER BY campaign_id,position,id', ARRAY_A ); }
	public function get_stage( int $id ): ?array { global $wpdb; $row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . KERP_Modules_Leads_Module::table( 'stages' ) . ' WHERE id=%d', $id ), ARRAY_A ); return is_array( $row ) ? $row : NULL; }
	public function get_user_memberships( int $user_id ): array { global $wpdb; $m = KERP_Modules_Leads_Module::table( 'memberships' ); $c = KERP_Modules_Leads_Module::table( 'campaigns' ); $s = KERP_Modules_Leads_Module::table( 'stages' ); return (array) $wpdb->get_results( $wpdb->prepare( "SELECT m.*,c.name campaign_name,c.type campaign_type,s.name stage_name FROM {$m} m JOIN {$c} c ON c.id=m.campaign_id LEFT JOIN {$s} s ON s.id=m.current_stage_id WHERE m.user_id=%d ORDER BY m.joined_at DESC", $user_id ), ARRAY_A ); }
	/** A bounded history scoped to one customer's sales path. */
	public function get_membership_history( int $user_id, int $campaign_id, int $page = 1 ): array {
		global $wpdb;
		$table = KERP_Modules_Leads_Module::table( 'events' );
		$where = $wpdb->prepare( ' WHERE user_id=%d AND campaign_id=%d', $user_id, $campaign_id );
		$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}{$where}" );
		$pages = max( 1, (int) ceil( $total / 30 ) );
		$page = max( 1, min( $pages, $page ) );
		$items = (array) $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table}{$where} ORDER BY occurred_at DESC,id DESC LIMIT %d OFFSET %d", 30, ( $page - 1 ) * 30 ), ARRAY_A );
		return compact( 'items', 'total', 'pages', 'page' );
	}

	public function get_timeline( int $user_id ): array { global $wpdb; $e = KERP_Modules_Leads_Module::table( 'events' ); $c = KERP_Modules_Leads_Module::table( 'campaigns' ); $s = KERP_Modules_Leads_Module::table( 'stages' ); return (array) $wpdb->get_results( $wpdb->prepare( "SELECT e.*,c.name campaign_name,s.name stage_name FROM {$e} e LEFT JOIN {$c} c ON c.id=e.campaign_id LEFT JOIN {$s} s ON s.id=e.stage_id WHERE e.user_id=%d ORDER BY e.occurred_at DESC,e.id DESC", $user_id ), ARRAY_A ); }
	public function get_recent_leads( int $limit = 100 ): array { global $wpdb; $m = KERP_Modules_Leads_Module::table( 'memberships' ); $c = KERP_Modules_Leads_Module::table( 'campaigns' ); $s = KERP_Modules_Leads_Module::table( 'stages' ); return (array) $wpdb->get_results( $wpdb->prepare( "SELECT m.*,c.name campaign_name,s.name stage_name FROM {$m} m JOIN {$c} c ON c.id=m.campaign_id LEFT JOIN {$s} s ON s.id=m.current_stage_id ORDER BY m.updated_at DESC LIMIT %d", min( 500, max( 1, $limit ) ) ), ARRAY_A ); }

	/** Use the ERP employee identity (access role), never the WordPress user directory. */
	public function sales_employee_options(): array {
		global $wpdb;
		$access = KERP_Services_Access::table();
		$ids = $wpdb->get_col( "SELECT u.ID FROM {$wpdb->users} u INNER JOIN {$access} a ON a.user_id=u.ID
			WHERE a.role_key IS NOT NULL AND a.role_key<>'' AND NOT EXISTS (
			SELECT 1 FROM {$wpdb->usermeta} s WHERE s.user_id=u.ID AND s.meta_key='kerp_employee_status' AND s.meta_value NOT IN ('','active')
			) ORDER BY u.display_name,u.ID" );
		$options = [];
		foreach ( $ids as $id ) $options[ (int) $id ] = get_user_name_by_id( (int) $id );
		return $options;
	}

	public function sales_pool(): array {
		$owners = array_values( array_unique( array_filter( array_map( 'absint', (array) get_option( 'kerp_leads_sales_users', [] ) ) ) ) );
		return array_values( array_intersect( $owners, array_keys( $this->sales_employee_options() ) ) );
	}

	public function save_sales_pool( mixed $ids ): bool|WP_Error {
		if ( ! is_array( $ids ) ) return new WP_Error( 'invalid_sales_pool', 'فهرست کارشناسان معتبر نیست.' );
		foreach ( $ids as $id ) if ( ! is_scalar( $id ) || ! preg_match( '/^[1-9][0-9]*$/D', (string) $id ) ) return new WP_Error( 'invalid_sales_pool', 'شناسه کارشناس معتبر نیست.' );
		$ids = array_values( array_unique( array_map( 'absint', $ids ) ) );
		if ( array_diff( $ids, array_keys( $this->sales_employee_options() ) ) ) return new WP_Error( 'invalid_sales_employee', 'فقط کارکنان فعال ERP را می‌توانید به فهرست فروش چرخشی اضافه کنید.' );
		$current = (array) get_option( 'kerp_leads_sales_users', [] );
		if ( $current === $ids ) return TRUE;
		if ( ! update_option( 'kerp_leads_sales_users', $ids, FALSE ) ) return new WP_Error( 'sales_pool_save', 'ذخیره کارشناسان انجام نشد؛ دوباره تلاش کنید.' );
		update_option( 'kerp_leads_owner_cursor', 0, FALSE );
		return TRUE;
	}

    private function customer_owner_meta_key(): string {
        $key = class_exists( 'KERP_Modules_Customers_Settings' )
            ? (string) KERP_Modules_Customers_Settings::instance()->get( 'owner_meta_key', 'kerp_customer_owner_id' )
            : 'kerp_customer_owner_id';
        return $key !== '' ? $key : 'kerp_customer_owner_id';
    }

    private function customer_owner( int $user_id ): int {
        $owner_id = absint( get_user_meta( $user_id, $this->customer_owner_meta_key(), TRUE ) );
        return $owner_id && get_userdata( $owner_id ) ? $owner_id : 0;
    }

	private function next_owner(): int {
		$owners = $this->sales_pool();
		if ( ! $owners ) return 0;
		$cursor = (int) get_option( 'kerp_leads_owner_cursor', 0 ); $owner = $owners[ $cursor % count( $owners ) ];
		update_option( 'kerp_leads_owner_cursor', $cursor + 1, FALSE ); return $owner;
	}
	private function sanitize_utm( array $utm ): array { $out = []; foreach ( [ 'utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content' ] as $key ) if ( isset( $utm[ $key ] ) && $utm[ $key ] !== '' ) $out[ $key ] = sanitize_text_field( (string) $utm[ $key ] ); return $out; }
	private function nullable_date( mixed $date ): ?string { $date = sanitize_text_field( (string) $date ); return $date !== '' && strtotime( $date ) ? wp_date( 'Y-m-d H:i:s', strtotime( $date ) ) : NULL; }
	private function fingerprint_exists( string $fingerprint ): bool { global $wpdb; return (bool) $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . KERP_Modules_Leads_Module::table( 'events' ) . ' WHERE fingerprint=%s', $fingerprint ) ); }
}
