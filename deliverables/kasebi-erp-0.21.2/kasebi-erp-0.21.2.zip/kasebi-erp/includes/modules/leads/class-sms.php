<?php
defined( 'ABSPATH' ) || exit;

/** Scheduled stage messages. Queue times are Unix UTC seconds, not local MySQL dates. */
final class KERP_Modules_Leads_SMS {
    public static function table(): string { global $wpdb; return $wpdb->prefix . 'kerp_lead_sms_queue'; }
    public static function init(): void {
        add_filter( 'cron_schedules', static function( $s ) { $s['kerp_lead_sms_minute'] = [ 'interval' => 60, 'display' => 'پیامک مراحل فروش' ]; return $s; } );
        add_action( 'kerp_lead_sms_tick', [ self::class, 'process' ] );
        if ( get_option( 'kerp_lead_sms_db_version' ) !== '1' ) {
            global $wpdb;
            require_once ABSPATH . 'wp-admin/includes/upgrade.php';
            $table = self::table(); $charset = $wpdb->get_charset_collate();
            dbDelta( "CREATE TABLE {$table} (
                id bigint unsigned NOT NULL AUTO_INCREMENT,
                event_id bigint unsigned NOT NULL, rule_index int unsigned NOT NULL,
                user_id bigint unsigned NOT NULL, campaign_id bigint unsigned NOT NULL,
                stage_id bigint unsigned NOT NULL, revision varchar(36) NOT NULL,
                due_at bigint unsigned NOT NULL, claimed_at bigint unsigned NOT NULL DEFAULT 0,
                status varchar(20) NOT NULL DEFAULT 'pending', rule longtext NOT NULL,
                PRIMARY KEY  (id), UNIQUE KEY event_rule (event_id,rule_index), KEY due_status (status,due_at), KEY stage_status (stage_id,status)
            ) ENGINE=InnoDB {$charset};" );
            if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $table ) ) ) === $table ) update_option( 'kerp_lead_sms_db_version', '1', false );
        }
        if ( ! wp_next_scheduled( 'kerp_lead_sms_tick' ) ) wp_schedule_event( time() + 60, 'kerp_lead_sms_minute', 'kerp_lead_sms_tick' );
    }
    public static function variables( int $campaign = 0 ): array {
        $variables = [ '{customer_name}' => 'نام مشتری', '{first_name}' => 'نام', '{last_name}' => 'نام خانوادگی', '{pipeline_name}' => 'مسیر فروش', '{stage_name}' => 'مرحله', '{site_name}' => 'نام سایت' ];
        if ( $campaign ) foreach ( KERP_Modules_Leads_Registration::config( $campaign )['fields'] ?? [] as $field ) $variables['{form_' . $field['key'] . '}'] = 'پاسخ فرم: ' . $field['label'];
        return $variables;
    }
    public static function registration_variables( int $user, int $campaign ): array {
        global $wpdb;
        $context = [];
        foreach ( KERP_Modules_Leads_Registration::config( $campaign )['fields'] ?? [] as $field ) $context['{form_' . $field['key'] . '}'] = [];
        if ( ! $context ) return [];
        $entries = KERP_Modules_Leads_Registration::table(); $answers = KERP_Modules_Leads_Registration::table( 'answers' );
        $rows = $wpdb->get_results( $wpdb->prepare( "SELECT field_key,value FROM {$answers} WHERE entry_id=(SELECT MAX(id) FROM {$entries} WHERE user_id=%d AND campaign_id=%d) AND phase IN (1,2) ORDER BY id", $user, $campaign ), ARRAY_A );
        foreach ( (array) $rows as $row ) {
            $token = '{form_' . $row['field_key'] . '}';
            if ( isset( $context[$token] ) ) $context[$token][] = (string) $row['value'];
        }
        return array_map( static fn( $values ) => implode( '، ', array_unique( $values ) ), $context );
    }
    public static function config( int $stage ): array { $value = get_option( 'kerp_lead_stage_sms_' . $stage, [] ); return is_array( $value ) ? $value : []; }
    public static function exit_config( int $campaign ): array { $value = get_option( 'kerp_lead_exit_sms_' . $campaign, [] ); return is_array( $value ) ? $value : []; }
    public static function save_exit( int $campaign, array $input ): bool|WP_Error {
        if ( ! KERP_Modules_Leads_Service::instance()->get_campaign( $campaign ) ) return new WP_Error( 'campaign', 'مسیر فروش پیدا نشد.' );
        foreach ( $input as $value ) if ( ! is_scalar( $value ) ) return new WP_Error( 'rules', 'تنظیمات پیامک معتبر نیست.' );
        $pattern = trim( (string) ( $input['pattern'] ?? '' ) );
        $variables = trim( (string) ( $input['variables'] ?? '' ) );
        $rules = $pattern === '' && $variables === '' ? [] : self::validate( [ [ 'pattern'=>$pattern, 'variables'=>$variables, 'delay'=>'0', 'unit'=>'minute', 'enabled'=>'1', 'stay'=>'0' ] ], $campaign );
        if ( is_wp_error( $rules ) ) return $rules;
        if ( ! update_option( 'kerp_lead_exit_sms_' . $campaign, [ 'revision'=>wp_generate_uuid4(), 'rules'=>$rules ], false ) ) return new WP_Error( 'save', 'تنظیمات ذخیره نشد.' );
        return true;
    }
    public static function enqueue_exit( int $event, int $user, int $campaign, int $stage ): bool {
        global $wpdb; $config = self::exit_config( $campaign );
        foreach ( $config['rules'] ?? [] as $index => $rule ) {
            if ( $rule['enabled'] !== '1' ) continue;
            $rule['event_kind'] = 'pipeline_exit';
            if ( false === $wpdb->insert( self::table(), [ 'event_id'=>$event, 'rule_index'=>$index, 'user_id'=>$user, 'campaign_id'=>$campaign, 'stage_id'=>$stage, 'revision'=>$config['revision'], 'due_at'=>time(), 'status'=>'pending', 'rule'=>wp_json_encode( $rule ) ] ) ) return false;
        }
        return true;
    }
    public static function parse_variables( string $raw, int $campaign = 0 ): array|WP_Error {
        $out = [];
        foreach ( preg_split( '/\s*;\s*/u', trim( $raw ), -1, PREG_SPLIT_NO_EMPTY ) ?: [] as $part ) {
            $pair = preg_split( '/[:=]/', $part, 2 ); $key = trim( $pair[0] );
            if ( count( $pair ) !== 2 || ! preg_match( '/^[A-Za-z][A-Za-z0-9_-]*$/D', $key ) || in_array( $key, [ 'receptor', 'pattern' ], true ) || isset( $out[$key] ) || trim( $pair[1] ) === '' ) return new WP_Error( 'variables', 'متغیرها را به شکل token:{customer_name} و با جداکننده ; وارد کنید.' );
            preg_match_all( '/\{[^{}]+\}/', $pair[1], $matches );
            if ( array_diff( $matches[0], array_keys( self::variables( $campaign ) ) ) ) return new WP_Error( 'variables', 'متغیر ناشناخته در پترن پیامک؛ متغیر را از فهرست همین مسیر کپی کنید.' );
            $out[$key] = trim( $pair[1] );
        }
        return $out;
    }
    public static function button_revision( array $button ): string {
        $rules = self::button_rules( $button );
        // Preserve queued single-message revisions when saving the migrated repeater.
        return md5( wp_json_encode( [ $button['key'], $button['transition'], count( $rules ) === 1 ? $rules[0] : $rules ] ) );
    }
    public static function button_rules( array $button ): array {
        $sms = $button['sms'] ?? [];
        return isset( $sms['pattern'] ) ? [ $sms ] : array_values( $sms );
    }
    public static function enqueue_button( int $user, int $campaign, int $stage, int $membership, array $button, string $execution ): bool {
        global $wpdb;
        if ( empty( $button['sms'] ) ) return TRUE;
        if ( $wpdb->query( 'START TRANSACTION' ) === FALSE ) return FALSE;
        try {
            $event = KERP_Modules_Leads_Service::instance()->add_event( $user, $campaign, $membership, $stage, 'stage_action_sms', 'زمان‌بندی پیامک دکمه «' . $button['label'] . '»', [ 'button_key'=>$button['key'], 'transition'=>$button['transition'] ], 'button-sms:' . hash( 'sha256', $execution ) );
            if ( ! $event ) throw new RuntimeException();
            $scheduled_at = time();
            foreach ( self::button_rules( $button ) as $index=>$rule ) {
            $rule['event_kind'] = 'button_action'; $rule['button_key'] = $button['key']; $rule['button_label'] = $button['label']; $rule['transition'] = $button['transition'];
            $delay = (int) $rule['delay'] * [ 'minute'=>60, 'hour'=>3600, 'day'=>86400 ][$rule['unit']];
            if ( $wpdb->insert( self::table(), [ 'event_id'=>$event, 'rule_index'=>$index, 'user_id'=>$user, 'campaign_id'=>$campaign, 'stage_id'=>$stage, 'revision'=>self::button_revision( $button ), 'due_at'=>$scheduled_at+$delay, 'status'=>'pending', 'rule'=>wp_json_encode( $rule ) ] ) === FALSE ) throw new RuntimeException();
            }
            if ( $wpdb->query( 'COMMIT' ) === FALSE ) throw new RuntimeException();
            return TRUE;
        } catch ( Throwable $e ) { $wpdb->query( 'ROLLBACK' ); return FALSE; }
    }
    public static function condition_fields( int $campaign ): array {
        $fields = [];
        foreach ( KERP_Modules_Leads_Registration::config( $campaign )['fields'] ?? [] as $field ) $fields[$field['key']] = $field['label'];
        return $fields;
    }
    public static function condition_options( int $campaign ): array {
        $options = []; $text_fields = [];
        foreach ( KERP_Modules_Leads_Registration::config( $campaign )['fields'] ?? [] as $field ) {
            $options[$field['key']] = array_values( $field['options'] ?? [] );
            if ( $field['type'] === 'text' ) $text_fields[] = $field['key'];
        }
        if ( $text_fields ) {
            global $wpdb;
            $entries = KERP_Modules_Leads_Registration::table(); $answers = KERP_Modules_Leads_Registration::table( 'answers' );
            $rows = $wpdb->get_results( $wpdb->prepare( "SELECT DISTINCT a.field_key,a.value FROM {$answers} a INNER JOIN {$entries} e ON e.id=a.entry_id WHERE e.campaign_id=%d AND a.phase IN (1,2) AND a.value<>'' ORDER BY a.value", $campaign ), ARRAY_A );
            foreach ( $rows as $row ) if ( in_array( $row['field_key'], $text_fields, TRUE ) ) $options[$row['field_key']][] = (string) $row['value'];
        }
        return $options;
    }
    public static function matches_condition( array $rule, int $user, int $campaign ): bool {
        $key = (string) ( $rule['condition_field'] ?? '' );
        if ( $key === '' || $key === '0' ) return true;
        // Read the latest submission in this pipeline only; never mix older answers.
        global $wpdb;
        $entries = KERP_Modules_Leads_Registration::table(); $answers = KERP_Modules_Leads_Registration::table( 'answers' );
        $values = $wpdb->get_col( $wpdb->prepare( "SELECT value FROM {$answers} WHERE entry_id=(SELECT MAX(id) FROM {$entries} WHERE user_id=%d AND campaign_id=%d) AND field_key=%s AND phase IN (1,2)", $user, $campaign, $key ) );
        if ( ! $values ) return false;
        $expected = trim( (string) ( $rule['condition_value'] ?? '' ) );
        return in_array( $expected, array_map( static fn( $v ) => trim( (string) $v ), $values ), true );
    }
    public static function validate( array $rows, int $campaign = 0 ): array|WP_Error {
        if ( count( $rows ) > 20 ) return new WP_Error( 'rules', 'حداکثر ۲۰ پیامک برای هر مرحله تعریف کنید.' );
        $clean = [];
        foreach ( $rows as $row ) {
            if ( ! is_array( $row ) ) return new WP_Error( 'rules', 'اطلاعات پیامک معتبر نیست.' );
            foreach ( $row as $value ) if ( ! is_scalar( $value ) ) return new WP_Error( 'rules', 'اطلاعات پیامک معتبر نیست.' );
            $pattern = sanitize_text_field( $row['pattern'] ?? '' );
            if ( $pattern === '' && trim( $row['delay'] ?? '' ) === '' && trim( $row['variables'] ?? '' ) === '' ) continue;
            $delay = trim( KERP_Helpers_Format::sanitize_numbers( (string) ( $row['delay'] ?? '' ) ) );
            if ( $delay === '' ) $delay = '0';
            $unit = $row['unit'] ?? ''; $enabled = $row['enabled'] ?? '0'; $stay = $row['stay'] ?? '1';
            if ( $unit === '' && preg_match( '/^0+$/D', $delay ) ) $unit = 'minute';
            if ( $pattern === '' || strlen( $pattern ) > 190 ) return new WP_Error( 'rules', 'کد پترن پیامک را وارد کنید؛ حداکثر ۱۹۰ کاراکتر.' );
            if ( ! preg_match( '/^[0-9]+$/D', $delay ) ) return new WP_Error( 'rules', 'زمان انتظار پیامک باید عدد صحیح صفر یا بیشتر باشد.' );
            if ( ! isset( [ 'minute'=>60, 'hour'=>3600, 'day'=>86400 ][$unit] ) ) return new WP_Error( 'rules', 'واحد زمان پیامک را انتخاب کنید: دقیقه، ساعت یا روز.' );
            if ( (int) $delay * [ 'minute'=>60, 'hour'=>3600, 'day'=>86400 ][$unit] > 31536000 ) return new WP_Error( 'rules', 'زمان انتظار پیامک نباید بیشتر از یک سال باشد.' );
            if ( ! in_array( $enabled, ['0','1'], true ) || ! in_array( $stay, ['0','1'], true ) ) return new WP_Error( 'rules', 'تنظیمات فعال‌بودن پیامک یا شرط ماندن در مرحله معتبر نیست.' );
            $raw = sanitize_textarea_field( $row['variables'] ?? '' ); $parsed = self::parse_variables( $raw, $campaign );
            if ( is_wp_error( $parsed ) ) return $parsed;
            $trigger = (string) ( $row['trigger'] ?? 'entry' );
            if ( $trigger === '' ) $trigger = 'entry';
            if ( ! in_array( $trigger, [ 'entry', 'no_answer' ], true ) ) return new WP_Error( 'trigger', 'رویداد پیامک معتبر نیست.' );
            $field = (string) ( $row['condition_field'] ?? '' );
            if ( $field === '0' ) $field = '';
            $value = trim( sanitize_text_field( (string) ( $row['condition_value'] ?? '' ) ) );
            if ( $field !== '' && ( ! $campaign || ! isset( self::condition_fields( $campaign )[$field] ) || $value === '' || mb_strlen( $value ) > 500 ) ) return new WP_Error( 'condition', 'فیلد شرط را از فرم همین مسیر انتخاب و مقدار آن را وارد کنید.' );
            $clean[] = [ 'enabled'=>$enabled, 'delay'=>(int)$delay, 'unit'=>$unit, 'pattern'=>$pattern, 'variables'=>$raw, 'stay'=>$stay, 'trigger'=>$trigger, 'condition_field'=>$field, 'condition_value'=>$field === '' ? '' : $value ];
        }
        return $clean;
    }
    public static function save( int $campaign, int $stage_id, array $rows ): bool|WP_Error {
        $stage = KERP_Modules_Leads_Service::instance()->get_stage( $stage_id );
        if ( ! $stage || (int)$stage['campaign_id'] !== $campaign || ! KERP_Modules_Leads_Service::instance()->get_campaign( $campaign ) ) return new WP_Error( 'stage', 'مرحله متعلق به این مسیر نیست.' );
        $rules = self::validate( $rows, $campaign ); if ( is_wp_error( $rules ) ) return $rules;
        $config = [ 'revision'=>wp_generate_uuid4(), 'rules'=>$rules ];
        if ( ! update_option( 'kerp_lead_stage_sms_' . $stage_id, $config, false ) ) return new WP_Error( 'save', 'تنظیمات ذخیره نشد.' );
        global $wpdb;
        $events = KERP_Modules_Leads_Module::table( 'events' );
        $wpdb->query( $wpdb->prepare( 'UPDATE ' . self::table() . " SET status='cancelled' WHERE stage_id=%d AND status='pending' AND revision<>%s AND event_id NOT IN (SELECT id FROM {$events} WHERE event_type IN ('pipeline_exited','stage_action_sms'))", $stage_id, $config['revision'] ) );
        return true;
    }
    public static function enqueue( int $event, int $user, int $campaign, int $stage, string $trigger = 'entry' ): bool {
        global $wpdb; $config = self::config( $stage );
        foreach ( $config['rules'] ?? [] as $index => $rule ) {
            if ( $rule['enabled'] !== '1' ) continue;
            if ( ( $rule['trigger'] ?? 'entry' ) !== $trigger ) continue;
            $seconds = $rule['delay'] * ['minute'=>60,'hour'=>3600,'day'=>86400][$rule['unit']];
            if ( false === $wpdb->insert( self::table(), [ 'event_id'=>$event,'rule_index'=>$index,'user_id'=>$user,'campaign_id'=>$campaign,'stage_id'=>$stage,'revision'=>$config['revision'],'due_at'=>time()+$seconds,'status'=>'pending','rule'=>wp_json_encode($rule) ] ) ) return false;
        }
        return true;
    }
    public static function process(): void {
        global $wpdb;
        $table = self::table();
        // A crashed/uncertain dispatch is never retried automatically (avoids duplicate SMS).
        $wpdb->query( $wpdb->prepare( "UPDATE {$table} SET status='unknown' WHERE status='processing' AND claimed_at<%d", time()-900 ) );
        if ( ! class_exists( 'kasebiSMS' ) ) return;
        $jobs = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE status='pending' AND due_at<=%d ORDER BY due_at,id LIMIT 30", time() ), ARRAY_A );
        foreach ( $jobs as $job ) {
            if ( $wpdb->update( $table, ['status'=>'processing','claimed_at'=>time()], ['id'=>$job['id'],'status'=>'pending'] ) !== 1 ) continue;
            $status = 'cancelled';
            try { $status = self::dispatch( $job ); } catch ( Throwable $error ) { $status = 'unknown'; }
            $wpdb->update( $table, ['status'=>$status], ['id'=>$job['id'],'status'=>'processing'] );
            $service = KERP_Modules_Leads_Service::instance();
            $membership = $service->get_membership( (int)$job['user_id'], (int)$job['campaign_id'] );
            $job_rule = json_decode( $job['rule'], TRUE );
            if ( ( $job_rule['event_kind'] ?? '' ) === 'button_action' && $membership ) {
                $labels = [ 'sent'=>'ارسال به سرویس', 'failed'=>'ارسال ناموفق', 'unknown'=>'نتیجه نامشخص', 'cancelled'=>'لغو' ];
                $service->add_event( (int)$job['user_id'], (int)$job['campaign_id'], (int)$membership['id'], (int)$job['stage_id'], 'sms_' . $status, 'پیامک دکمه «' . $job_rule['button_label'] . '» · ' . $labels[$status], [ 'sms_job_id'=>(int)$job['id'], 'button_key'=>$job_rule['button_key'] ], 'lead-sms:' . $job['id'] );
                continue;
            }
            $exit_message = ( json_decode( $job['rule'], true )['event_kind'] ?? '' ) === 'pipeline_exit';
            if ( $exit_message && $membership ) {
                $service->add_event( (int)$job['user_id'], (int)$job['campaign_id'], (int)$membership['id'], (int)$job['stage_id'], 'sms_' . $status, ['sent'=>'پیامک خروج به سرویس ارسال شد','failed'=>'ارسال پیامک خروج ناموفق بود','unknown'=>'نتیجه ارسال پیامک خروج نامشخص است','cancelled'=>'پیامک خروج لغو شد'][$status], ['sms_job_id'=>(int)$job['id'], 'sms_kind'=>'pipeline_exit'], 'lead-sms:' . $job['id'] );
                continue;
            }
            if ( $membership ) $service->add_event( (int)$job['user_id'], (int)$job['campaign_id'], (int)$membership['id'], (int)$job['stage_id'], 'sms_' . $status, ['sent'=>'پیامک مرحله به سرویس ارسال شد','failed'=>'ارسال پیامک مرحله ناموفق بود','unknown'=>'نتیجه ارسال پیامک مرحله نامشخص است','cancelled'=>'پیامک زمان‌بندی‌شده مرحله لغو شد'][$status], ['sms_job_id'=>(int)$job['id']], 'lead-sms:' . $job['id'] );
        }
    }
    private static function dispatch( array $job ): string {
        global $wpdb;
        $service = KERP_Modules_Leads_Service::instance();
        $stage = $service->get_stage( (int)$job['stage_id'] ); $campaign = $service->get_campaign( (int)$job['campaign_id'] );
        $member = $service->get_membership( (int)$job['user_id'], (int)$job['campaign_id'] );
        $rule = json_decode( $job['rule'], true );
        if ( ! is_array( $rule ) ) return 'cancelled';
        $is_exit = ( $rule['event_kind'] ?? '' ) === 'pipeline_exit';
        $is_button = ( $rule['event_kind'] ?? '' ) === 'button_action';
        $config = $is_exit ? self::exit_config( (int)$job['campaign_id'] ) : self::config( (int)$job['stage_id'] );
        if ( $is_button ) {
            $buttons = array_column( KERP_Modules_Leads_Actions::buttons( (int)$job['stage_id'] ), NULL, 'key' );
            $button = $buttons[$rule['button_key'] ?? ''] ?? NULL;
            if ( ! $button || empty( $button['sms'] ) ) return 'cancelled';
            $config = [ 'revision'=>self::button_revision( $button ) ];
        }
        $events = KERP_Modules_Leads_Module::table( 'events' );
        $event = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$events} WHERE id=%d", $job['event_id'] ), ARRAY_A );
        if ( ! $campaign || $campaign['status'] !== 'active' || ! $member || ! $event || (int)$event['membership_id'] !== (int)$member['id'] || (int)$event['campaign_id'] !== (int)$job['campaign_id'] || (int)$event['stage_id'] !== (int)$job['stage_id'] || (int)$event['user_id'] !== (int)$job['user_id'] || ($config['revision']??'') !== $job['revision'] ) return 'cancelled';
        if ( $is_button ) {
            $payload = json_decode( $event['payload'] ?? '', TRUE );
            if ( $event['event_type'] !== 'stage_action_sms' || ( $payload['button_key'] ?? '' ) !== $rule['button_key'] || ( $payload['transition'] ?? '' ) !== $rule['transition'] || ! $stage || ! $stage['active'] || (int)$stage['campaign_id'] !== (int)$job['campaign_id'] ) return 'cancelled';
            if ( $rule['transition'] === 'exit' ) {
                if ( empty( $member['exited_at'] ) ) return 'cancelled';
                if ( $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$events} WHERE membership_id=%d AND id>%d AND event_type='pipeline_exited' LIMIT 1", $member['id'], $job['event_id'] ) ) ) return 'cancelled';
            } elseif ( ! empty( $member['exited_at'] ) ) return 'cancelled';
        } elseif ( $is_exit ) {
            if ( empty( $member['exited_at'] ) || $event['event_type'] !== 'pipeline_exited' ) return 'cancelled';
            if ( $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$events} WHERE membership_id=%d AND id>%d AND event_type='pipeline_exited' LIMIT 1", $member['id'], $job['event_id'] ) ) ) return 'cancelled';
        } elseif ( ! $stage || ! $stage['active'] || (int)$stage['campaign_id'] !== (int)$job['campaign_id'] || ! empty( $member['exited_at'] ) ) return 'cancelled';
        if ( ! $is_exit && ! $is_button && $rule['stay'] === '1' ) {
            if ( (int)$member['current_stage_id'] !== (int)$job['stage_id'] ) return 'cancelled';
            // Leaving and returning does not revive messages from the previous visit.
            if ( $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$events} WHERE membership_id=%d AND id>%d AND stage_id IS NOT NULL AND stage_id<>%d AND event_type NOT IN ('sms_sent','sms_failed','sms_unknown','sms_cancelled') LIMIT 1", $member['id'], $job['event_id'], $job['stage_id'] ) ) ) return 'cancelled';
        }
        if ( ! self::matches_condition( $rule, (int) $job['user_id'], (int) $job['campaign_id'] ) ) return 'cancelled';
        $user = get_userdata( (int)$job['user_id'] ); if ( ! $user ) return 'cancelled';
        $phone = '';
        foreach ( ['nooshika_phone_num','billing_phone'] as $key ) {
            $raw = get_user_meta( $user->ID, $key, true );
            if ( ! is_scalar($raw) ) continue;
            $candidate = preg_replace('/[\s()+-]/u','',KERP_Helpers_Format::sanitize_numbers((string)$raw));
            $candidate = preg_replace('/^(?:0098|98|0)(?=9\d{9}$)/','',$candidate);
            if ( preg_match('/^9\d{9}$/D',$candidate) ) { $phone=$candidate; break; }
        }
        if ( $phone === '' ) return 'failed';
        $context = ['{customer_name}'=>$user->display_name,'{first_name}'=>$user->first_name,'{last_name}'=>$user->last_name,'{pipeline_name}'=>$campaign['name'],'{stage_name}'=>$stage['name'] ?? 'بدون مرحله','{site_name}'=>get_bloginfo('name')];
        $tokens = self::parse_variables($rule['variables'], (int) $job['campaign_id']); if ( is_wp_error($tokens) ) return 'failed';
        $payload = ['receptor'=>$phone,'pattern'=>$rule['pattern']];
        // Preserve literal text; keep the established formatting for substituted variables.
        $context = array_map( static fn( $value ) => str_replace( [' ', '_'], '-', (string) $value ), $context );
        if ( str_contains( $rule['variables'], '{form_' ) ) $context += self::registration_variables( (int) $job['user_id'], (int) $job['campaign_id'] );
        foreach($tokens as $key=>$value) $payload[$key]=strtr($value,$context);
        return KERP_Modules_Payments_SMS::delivery_status( (new kasebiSMS())->send_pattern_sms($payload) );
    }
}
