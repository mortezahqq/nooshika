<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Leads_Integrations {
	private static ?self $instance = NULL;
	public static function instance(): self { return self::$instance ??= new self(); }
	private function __construct() {
		add_action( 'kerp_leads_join_pipeline', [ $this, 'join_pipeline' ], 10, 3 );
		add_action( 'kerp_leads_exit_pipeline', [ $this, 'exit_pipeline' ], 10, 3 );
		add_action( 'kerp_leads_advance_stage', [ $this, 'advance_stage' ], 10, 3 );
		add_action( 'gform_after_submission', [ $this, 'gravity_submission' ], 20, 2 );
		add_action( 'nooshika_panel_step_completed', [ $this, 'learndash_completed' ], 20, 3 );
		add_action( 'woocommerce_order_status_processing', [ $this, 'woocommerce_order' ], 30 );
		add_action( 'woocommerce_order_status_completed', [ $this, 'woocommerce_order' ], 30 );
	}
	private function __clone() {}

	/** Trusted server-side action; the caller authorizes its originating request. */
	public function join_pipeline( mixed $user_id, mixed $campaign_id, mixed $context = [] ): void {
		if ( ! is_scalar( $user_id ) || ! ctype_digit( (string) $user_id ) || ! is_scalar( $campaign_id ) || ! ctype_digit( (string) $campaign_id ) || ! is_array( $context ) ) {
			$result = new WP_Error( 'invalid_input', 'اطلاعات ورود به مسیر معتبر نیست.' );
		} else {
			$result = KERP_Modules_Leads_Service::instance()->join_pipeline( (int) $user_id, (int) $campaign_id, $context );
		}
		do_action( 'kerp_leads_join_pipeline_result', $result, $user_id, $campaign_id, $context );
	}

	/** Trusted server-side integration; callers must authorize any originating HTTP request. */
	public function advance_stage( mixed $user_id, mixed $campaign_id, mixed $context = [] ): void {
		if ( ! is_scalar( $user_id ) || ! is_scalar( $campaign_id ) || ! ctype_digit( (string) $user_id ) || ! ctype_digit( (string) $campaign_id ) || ! is_array( $context ) ) {
			$result = new WP_Error( 'invalid_input', 'اطلاعات انتقال مرحله معتبر نیست.' );
		} else {
			$result = KERP_Modules_Leads_Service::instance()->advance_stage( (int) $user_id, (int) $campaign_id, $context );
		}
		// Actions have no return value; integrations can observe the outcome here.
		do_action( 'kerp_leads_advance_stage_result', $result, $user_id, $campaign_id, $context );
	}
	/** Trusted server-side action, with the same caller authorization contract as advance_stage. */
	public function exit_pipeline( mixed $user_id, mixed $campaign_id, mixed $context = [] ): void {
		if ( ! is_scalar( $user_id ) || ! ctype_digit( (string) $user_id ) || ! is_scalar( $campaign_id ) || ! ctype_digit( (string) $campaign_id ) || ! is_array( $context ) || ( isset( $context['note'] ) && ! is_string( $context['note'] ) ) || ( isset( $context['expected_stage_id'] ) && ( ! is_scalar( $context['expected_stage_id'] ) || ! ctype_digit( (string) $context['expected_stage_id'] ) ) ) ) {
			$result = new WP_Error( 'invalid_input', 'اطلاعات خروج از مسیر معتبر نیست.' );
		} else {
			$result = KERP_Modules_Leads_Service::instance()->exit_pipeline( (int) $user_id, (int) $campaign_id, $context['note'] ?? '', isset( $context['expected_stage_id'] ) ? (int) $context['expected_stage_id'] : NULL );
		}
		do_action( 'kerp_leads_exit_pipeline_result', $result, $user_id, $campaign_id, $context );
	}
	public function __wakeup(): void { throw new LogicException( 'Cannot unserialize a singleton.' ); }

	public function gravity_submission( array $entry, array $form ): void {
		$form_id = absint( $form['id'] ?? 0 );
		foreach ( $this->matching_stages( 'gravity_form', (string) $form_id ) as $stage ) {
			$phone = $this->gravity_phone( $entry, $form_id );
			if ( $phone === '' ) continue;
			$name = $this->gravity_name( $entry );
			KERP_Modules_Leads_Service::instance()->upsert_lead( [
				'phone' => $phone, 'name' => $name, 'source' => 'gravity-forms',
				'campaign_id' => absint( $stage['campaign_id'] ), 'stage_id' => absint( $stage['id'] ),
				'event_type' => 'gravity_form',
				'fingerprint' => 'gf:' . $form_id . ':' . absint( $entry['id'] ?? 0 ) . ':' . absint( $stage['id'] ),
				'utm' => $this->gravity_utm( $entry ),
			] );
		}
	}

	public function woocommerce_order( int $order_id ): void {
		if ( ! function_exists( 'wc_get_order' ) ) return;
		$order = wc_get_order( $order_id );
		if ( $order && $order->get_meta( '_kerp_installment_is_parent' ) ) return;
		if ( ! $order ) return;
		$user_id = absint( $order->get_user_id() );
		$phone = (string) $order->get_billing_phone();
		if ( ! $user_id && $phone !== '' ) {
			$result = KERP_Modules_Leads_Service::instance()->upsert_lead( [ 'phone' => $phone, 'name' => trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() ), 'source' => 'woocommerce' ] );
			if ( ! is_wp_error( $result ) ) $user_id = absint( $result['user_id'] ?? 0 );
		}
		if ( ! $user_id ) return;
		foreach ( $order->get_items() as $item ) {
			$product_ids = array_unique( [ absint( $item->get_product_id() ), absint( $item->get_variation_id() ) ] );
			foreach ( $product_ids as $product_id ) {
				if ( ! $product_id ) continue;
				foreach ( $this->matching_stages( 'product_purchase', (string) $product_id ) as $stage ) {
					KERP_Modules_Leads_Service::instance()->join_campaign( $user_id, absint( $stage['campaign_id'] ), 'woocommerce' );
					KERP_Modules_Leads_Service::instance()->move_stage( $user_id, absint( $stage['campaign_id'] ), absint( $stage['id'] ), [ 'event_type' => 'product_purchased', 'fingerprint' => 'wc:' . $order_id . ':' . $product_id . ':' . absint( $stage['id'] ), 'payload' => [ 'order_id' => $order_id, 'product_id' => $product_id ] ] );
				}
			}
		}
	}

	/** Only verified completions emitted by the customer panel enter these stages. */
	public function learndash_completed( mixed $user_id, mixed $lesson_id, mixed $course_id ): void {
		foreach ( [ $user_id, $lesson_id, $course_id ] as $id ) if ( ! is_scalar( $id ) || ! ctype_digit( (string) $id ) || (int) $id < 1 ) return;
		$user_id = (int) $user_id; $lesson_id = (int) $lesson_id; $course_id = (int) $course_id;
		if ( get_current_user_id() !== $user_id || ! function_exists( 'kasebi_ld_is_step_complete' ) || ! function_exists( 'sfwd_lms_has_access' ) ) return;
		$lesson = get_post( $lesson_id );
		if ( ! $lesson instanceof WP_Post || ! in_array( $lesson->post_type, [ 'sfwd-lessons', 'sfwd-topic' ], TRUE ) || $lesson->post_status !== 'publish' ) return;
		if ( ! sfwd_lms_has_access( $course_id, $user_id ) || ! kasebi_ld_is_step_complete( $user_id, $lesson_id, $course_id ) ) return;
		$service = KERP_Modules_Leads_Service::instance();
		foreach ( $this->matching_stages( 'learndash_completed', (string) $lesson_id ) as $stage ) {
			$campaign_id = (int) $stage['campaign_id']; $stage_id = (int) $stage['id'];
			$membership = $service->join_campaign( $user_id, $campaign_id, 'learndash' );
			if ( is_wp_error( $membership ) ) continue;
			$service->move_stage( $user_id, $campaign_id, $stage_id, [
				'event_type' => 'learndash_completed', 'fingerprint' => 'ld-panel:' . $user_id . ':' . $lesson_id . ':' . $stage_id,
				'payload' => [ 'source' => 'learndash', 'lesson_id' => $lesson_id, 'course_id' => $course_id, 'note' => 'تکمیل درس «' . wp_strip_all_tags( $lesson->post_title ) . '» در پنل کاربری' ],
			] );
		}
	}

	private function matching_stages( string $type, string $ref ): array {
		global $wpdb;
		$stages = KERP_Modules_Leads_Module::table( 'stages' );
		$campaigns = KERP_Modules_Leads_Module::table( 'campaigns' );
		return (array) $wpdb->get_results( $wpdb->prepare( "SELECT s.* FROM {$stages} s JOIN {$campaigns} c ON c.id=s.campaign_id WHERE s.active=1 AND c.status='active' AND s.trigger_type=%s AND s.trigger_ref=%s ORDER BY s.campaign_id,s.position,s.id", $type, $ref ), ARRAY_A );
	}
	private function gravity_phone( array $entry, int $form_id ): string {
		$map = (array) get_option( 'kerp_leads_gf_phone_fields', [] );
		$field = sanitize_text_field( (string) ( $map[ $form_id ] ?? '' ) );
		if ( $field !== '' && ! empty( $entry[ $field ] ) ) return (string) $entry[ $field ];
		foreach ( $entry as $value ) {
			if ( ! is_scalar( $value ) ) continue;
			$phone = KERP_Helpers_Phone::normalize( (string) $value );
			if ( preg_match( '/^9\d{9}$/D', $phone ) ) return $phone;
		}
		return '';
	}
	private function gravity_name( array $entry ): string {
		foreach ( [ 'name', 'full_name', '1.3', '1.6', '2.3', '2.6' ] as $key ) if ( ! empty( $entry[ $key ] ) ) return sanitize_text_field( (string) $entry[ $key ] );
		return '';
	}
	private function gravity_utm( array $entry ): array { $utm = []; foreach ( [ 'utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content' ] as $key ) if ( ! empty( $entry[ $key ] ) ) $utm[ $key ] = $entry[ $key ]; return $utm; }
}
