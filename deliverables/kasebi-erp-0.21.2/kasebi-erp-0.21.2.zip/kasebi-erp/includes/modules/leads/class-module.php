<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Leads_Module {
	
	private const DB_VERSION        = '1.2.1';
	
	private const DB_VERSION_OPTION = 'kerp_leads_db_version';
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		return self::$instance ??= new self();
	}
	
	private function __construct() {
		$this->maybe_install();
		KERP_Modules_Leads_Service::instance();
		KERP_Modules_Leads_Integrations::instance();
		KERP_Modules_Leads_Api::instance();
		KERP_Modules_Leads_Registration::init();
		KERP_Modules_Leads_SMS::init();
        KERP_Modules_Leads_Dashboard::instance();
		$this->register_hooks();
	}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public static function table( string $name ): string {
		global $wpdb;
		
		return $wpdb->prefix . 'kasebi_erp_lead_' . sanitize_key( $name );
	}
	
	public static function install(): void {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$charset     = $wpdb->get_charset_collate();
		$campaigns   = self::table( 'campaigns' );
		$stages      = self::table( 'stages' );
		$memberships = self::table( 'memberships' );
		$events      = self::table( 'events' );
		dbDelta( "CREATE TABLE {$campaigns} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			name VARCHAR(190) NOT NULL, type VARCHAR(20) NOT NULL DEFAULT 'pipeline',
			status VARCHAR(20) NOT NULL DEFAULT 'active', starts_at DATETIME NULL, ends_at DATETIME NULL,
			created_by BIGINT UNSIGNED NOT NULL DEFAULT 0, created_at DATETIME NOT NULL, updated_at DATETIME NOT NULL,
			metadata LONGTEXT NULL, PRIMARY KEY (id), KEY idx_status_type (status,type)
		) ENGINE=InnoDB {$charset};" );
		dbDelta( "CREATE TABLE {$stages} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, campaign_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			name VARCHAR(190) NOT NULL, slug VARCHAR(100) NOT NULL, proposal_status VARCHAR(100) NOT NULL,
			trigger_type VARCHAR(30) NOT NULL DEFAULT 'manual', trigger_ref VARCHAR(190) NULL,
			position INT UNSIGNED NOT NULL DEFAULT 0, active TINYINT(1) NOT NULL DEFAULT 1,
			created_at DATETIME NOT NULL, updated_at DATETIME NOT NULL, PRIMARY KEY (id),
			KEY idx_campaign_position (campaign_id,position), KEY idx_trigger (trigger_type,trigger_ref)
		) ENGINE=InnoDB {$charset};" );
		dbDelta( "CREATE TABLE {$memberships} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, user_id BIGINT UNSIGNED NOT NULL, campaign_id BIGINT UNSIGNED NOT NULL,
			current_stage_id BIGINT UNSIGNED NULL, attendance VARCHAR(20) NOT NULL DEFAULT 'unknown', owner_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			source VARCHAR(190) NULL, utm_json LONGTEXT NULL, joined_at DATETIME NOT NULL, updated_at DATETIME NOT NULL,
			exited_at DATETIME NULL,
			PRIMARY KEY (id), UNIQUE KEY uniq_user_campaign (user_id,campaign_id), KEY idx_campaign_stage (campaign_id,current_stage_id),
			KEY idx_owner (owner_id), KEY idx_user (user_id)
		) ENGINE=InnoDB {$charset};" );
		dbDelta( "CREATE TABLE {$events} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, membership_id BIGINT UNSIGNED NULL, user_id BIGINT UNSIGNED NOT NULL,
			campaign_id BIGINT UNSIGNED NOT NULL DEFAULT 0, stage_id BIGINT UNSIGNED NULL, event_type VARCHAR(40) NOT NULL,
			title VARCHAR(190) NOT NULL, actor_id BIGINT UNSIGNED NOT NULL DEFAULT 0, fingerprint VARCHAR(190) NULL,
			payload LONGTEXT NULL, occurred_at DATETIME NOT NULL, PRIMARY KEY (id), UNIQUE KEY uniq_fingerprint (fingerprint),
			KEY idx_user_date (user_id,occurred_at), KEY idx_campaign_date (campaign_id,occurred_at), KEY idx_membership (membership_id)
		) ENGINE=InnoDB {$charset};" );
		if ( KERP_Modules_Leads_Migration::ensure_exit_column() && KERP_Modules_Leads_Migration::run() ) {
			update_option( self::DB_VERSION_OPTION, self::DB_VERSION, FALSE );
		}
	}
	
	private function maybe_install(): void {
		if ( version_compare( (string) get_option( self::DB_VERSION_OPTION, '0.0.0' ), self::DB_VERSION, '<' ) ) {
			self::install();
		}
	}
	
	private function register_hooks(): void {
		add_filter( 'kerp_app_pages', [ $this, 'register_pages' ], 32 );
		add_filter( 'kerp_customer_profile_tabs', [ $this, 'register_customer_tab' ], 32, 3 );
		add_filter( 'kerp_employee_permission_groups', [ $this, 'register_permissions' ], 32 );
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue' ], PHP_INT_MAX );
	}
	
	public function enqueue(): void {
		if ( kerp_is_erp_request() ) {
			wp_enqueue_style( 'kerp-marketing', KERP_ASSETS_URL . 'app/css/marketing.css', [ KERP_Public_Assets::STYLE_HANDLE ], kerp_asset_version( 'app/css/marketing.css' ) );
		}
	}
	
	public function register_pages( array $pages ): array {
		$crm                     = [
			'key'   => 'marketing',
			'title' => 'مارکتینگ',
			'icon'  => 'ni ni-growth',
			'order' => 26,
		];
		$pages['leads']          = [
			'title'      => 'مشتریان بالقوه',
			'route'      => 'leads',
			'type'       => 'page',
			'template'   => 'modules/leads/pages/leads.php',
			'permission' => 'leads.view',
			'navigation' => [
				'group' => $crm,
				'icon'  => 'ni ni-user-add',
				'order' => 50,
			],
		];
		$pages['marketing-pipelines'] = [
			'title'      => 'مسیرهای فروش',
			'route'      => 'marketing/pipelines',
			'type'       => 'page',
			'template'   => 'modules/leads/pages/pipelines.php',
			'permission' => 'leads.view',
			'navigation' => [
				'group' => $crm,
				'icon'  => 'ni ni-filter-alt',
				'order' => 5,
			],
		];
        $pages['marketing-pipeline-dashboard'] = [
            'title' => 'آمار مسیرهای فروش', 'route' => 'marketing/pipelines/dashboard',
            'type' => 'page', 'template' => 'modules/leads/pages/pipeline-dashboard.php',
            'permission' => 'leads.view',
            'navigation' => [ 'group' => $crm, 'icon' => 'ni ni-bar-chart-alt', 'order' => 6 ],
        ];
		$pages['marketing-pipeline-settings'] = [
			'title' => 'تنظیمات مسیرهای فروش', 'route' => 'marketing/pipelines/settings',
			'type' => 'settings', 'template' => 'modules/leads/pages/pipeline-settings.php',
			'permission' => 'leads.manage_settings',
			'navigation' => [ 'group' => $crm, 'icon' => 'ni ni-setting', 'order' => 60 ],
		];
		$pages['marketing-pipeline'] = [
			'title' => 'جزئیات مسیر فروش', 'route' => 'marketing/pipelines/{pipeline_id}',
			'type' => 'sub-page', 'template' => 'modules/leads/pages/pipeline.php',
			'permission' => 'leads.view',
			'navigation' => [ 'hidden' => TRUE, 'active' => 'marketing-pipelines' ],
		];
		
		return $pages;
	}
	
	public function register_customer_tab( array $tabs, int $customer_id, WP_User $customer ): array {
		$tabs['lead-journey'] = [
			'key'        => 'lead-journey',
			'title'      => 'مشتری بالقوه و کمپین',
			'icon'       => 'ni ni-growth',
			'order'      => 25,
			'group'      => 'crm',
			'permission' => 'leads.view',
			'action'     => 'view',
			'template'   => 'modules/leads/tabs/customer-journey.php',
		];
		
		return $tabs;
	}
	
	public function register_permissions( array $groups ): array {
		$groups['crm']                    ??= [
			'key'    => 'crm',
			'label'  => 'مدیریت مشتریان',
			'icon'   => 'kik fa-users-02',
			'order'  => 20,
			'blocks' => [],
		];
		$groups['crm']['blocks']['leads'] = [
			'key'         => 'leads',
			'label'       => 'مشتری بالقوه و کمپین',
			'icon'        => 'ni ni-growth',
			'order'       => 15,
			'permissions' => [
				'view'     => [
					'key'   => 'leads.view',
					'label' => 'مشاهده مشتریان بالقوه و کمپین‌ها',
					'type'  => 'view',
					'order' => 10,
				],
				'manage'   => [
					'key'   => 'leads.manage',
					'label' => 'ثبت و تغییر مشتری بالقوه و مرحله',
					'type'  => 'action',
					'order' => 20,
				],
				'settings' => [
					'key'   => 'leads.manage_settings',
					'label' => 'مدیریت مراحل و اتصال‌ها',
					'type'  => 'action',
					'order' => 30,
				],
			],
		];
		
		return $groups;
	}
	
}
