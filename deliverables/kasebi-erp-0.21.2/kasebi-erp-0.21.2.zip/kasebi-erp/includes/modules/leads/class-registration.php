<?php
defined( 'ABSPATH' ) || exit;

/** Two-step public registration; all network actions use the dedicated ERP endpoint. */
final class KERP_Modules_Leads_Registration {
    public const UTM = [ 'utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content', 'utm_id', 'utm_source_platform', 'utm_creative_format', 'utm_marketing_tactic' ];
    public static function table( string $suffix = 'entries' ): string { global $wpdb; return $wpdb->prefix . 'kerp_lead_registration_' . $suffix; }
    public static function init(): void {
        self::install();
        self::upgrade_reserved_stages();
        add_shortcode( 'kerp_pipeline_registration', [ self::class, 'shortcode' ] );
        foreach ( [ 'start', 'verify', 'resend', 'finish' ] as $action ) add_action( 'kasebi_ajax_leads_registration_' . $action, static function() use ( $action ) { self::public_action( $action ); } );
        add_action( 'kasebi_ajax_leads_registration_save', [ self::class, 'save' ] );
    }
    public static function is_reserved_stage( array $stage ): bool {
        return in_array( $stage['trigger_type'] ?? '', [ 'registration_started', 'registration_completed' ], TRUE );
    }

    /** Add the form's two stages once, retaining ordinary stages, IDs and their relative order. */
    public static function ensure_stages( int $campaign_id ): array|WP_Error {
        global $wpdb;
        $campaigns = KERP_Modules_Leads_Module::table( 'campaigns' );
        $stages = KERP_Modules_Leads_Module::table( 'stages' );
        if ( $campaign_id < 1 || $wpdb->query( 'START TRANSACTION' ) === FALSE ) return new WP_Error( 'registration_stages', 'آماده‌سازی مراحل فرم انجام نشد.' );
        try {
            if ( ! $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$campaigns} WHERE id=%d FOR UPDATE", $campaign_id ) ) ) throw new RuntimeException( 'مسیر فروش پیدا نشد.' );
            $rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$stages} WHERE campaign_id=%d ORDER BY position,id FOR UPDATE", $campaign_id ), ARRAY_A );
            if ( $wpdb->last_error ) throw new RuntimeException( 'خواندن مراحل مسیر ناموفق بود.' );
            $reserved = [];
            foreach ( $rows as $row ) if ( self::is_reserved_stage( $row ) ) $reserved[$row['trigger_type']] = $row;
            if ( count( $reserved ) === 2 ) {
                if ( $wpdb->query( 'COMMIT' ) === FALSE ) throw new RuntimeException( 'ذخیره مراحل فرم ناموفق بود.' );
                return [ $reserved['registration_started'], $reserved['registration_completed'] ];
            }
            if ( ! $reserved && $wpdb->query( $wpdb->prepare( "UPDATE {$stages} SET position=position+30 WHERE campaign_id=%d", $campaign_id ) ) === FALSE ) throw new RuntimeException( 'تنظیم ترتیب مراحل ناموفق بود.' );
            $now = current_time( 'mysql' );
            foreach ( [ 'registration_started' => [ 'ثبت‌نام اولیه', 10 ], 'registration_completed' => [ 'تکمیل ثبت‌نام', 20 ] ] as $trigger => [ $name, $position ] ) {
                if ( isset( $reserved[$trigger] ) ) continue;
                $row = [ 'campaign_id' => $campaign_id, 'name' => $name, 'slug' => $trigger, 'proposal_status' => '', 'trigger_type' => $trigger, 'trigger_ref' => '', 'position' => $position, 'active' => 1, 'created_at' => $now, 'updated_at' => $now ];
                if ( $wpdb->insert( $stages, $row ) !== 1 ) throw new RuntimeException( 'ساخت مراحل رزروشده فرم ناموفق بود.' );
                $row['id'] = (int) $wpdb->insert_id;
                $reserved[$trigger] = $row;
            }
            self::align_existing_registrations( $campaign_id, (int) $reserved['registration_started']['id'], (int) $reserved['registration_completed']['id'] );
            if ( $wpdb->query( 'COMMIT' ) === FALSE ) throw new RuntimeException( 'ذخیره مراحل فرم ناموفق بود.' );
            return [ $reserved['registration_started'], $reserved['registration_completed'] ];
        } catch ( Throwable $error ) {
            $wpdb->query( 'ROLLBACK' );
            return new WP_Error( 'registration_stages', $error->getMessage() );
        }
    }

    /** Only memberships still at their last form-driven stage move; later staff/integration moves stay intact. */
    private static function align_existing_registrations( int $campaign_id, int $first_id, int $second_id ): void {
        global $wpdb;
        if ( get_option( 'kerp_lead_registration_db' ) !== '1' ) return;
        $entries = self::table(); $members = KERP_Modules_Leads_Module::table( 'memberships' ); $events = KERP_Modules_Leads_Module::table( 'events' );
        $rows = $wpdb->get_results( $wpdb->prepare( "SELECT re.*,m.id membership_id,m.current_stage_id FROM {$entries} re JOIN {$members} m ON m.user_id=re.user_id AND m.campaign_id=re.campaign_id WHERE re.campaign_id=%d AND m.source='registration' AND m.exited_at IS NULL AND re.id=(SELECT MAX(latest.id) FROM {$entries} latest WHERE latest.user_id=re.user_id AND latest.campaign_id=re.campaign_id) FOR UPDATE", $campaign_id ), ARRAY_A );
        if ( $wpdb->last_error ) throw new RuntimeException( 'خواندن ثبت‌نام‌های قبلی ناموفق بود.' );
        foreach ( $rows as $row ) {
            $completed = $row['status'] === 'completed';
            $from = (int) ( $completed ? $row['stage_two'] : $row['stage_one'] );
            $to = $completed ? $second_id : $first_id;
            if ( ! in_array( $row['status'], [ 'pending', 'verified', 'completed' ], TRUE ) || (int) $row['current_stage_id'] !== $from || $from === $to ) continue;
            // Unknown integration events are treated conservatively as possible moves.
            $last_move = $wpdb->get_row( $wpdb->prepare( "SELECT event_type,payload,fingerprint,stage_id FROM {$events} WHERE membership_id=%d AND event_type NOT IN ('registration_started','registration_verified','registration_completed','owner_assigned','note_added','attendance_changed') ORDER BY id DESC LIMIT 1", $row['membership_id'] ), ARRAY_A );
            if ( $wpdb->last_error ) throw new RuntimeException( 'خواندن سوابق ثبت‌نام ناموفق بود.' );
            $payload = json_decode( $last_move['payload'] ?? '', TRUE ) ?: [];
            $form_move = $completed
                ? ( $last_move['fingerprint'] ?? '' ) === 'registration:' . $row['id']
                : ( ( $last_move['event_type'] ?? '' ) === 'pipeline_joined' && ( $payload['source'] ?? '' ) === 'registration' );
            if ( ! $form_move || (int) ( $last_move['stage_id'] ?? 0 ) !== $from ) continue;
            if ( $wpdb->update( $members, [ 'current_stage_id' => $to ], [ 'id' => $row['membership_id'], 'current_stage_id' => $from ] ) === FALSE ) throw new RuntimeException( 'هماهنگ‌سازی مرحله ثبت‌نام ناموفق بود.' );
            if ( ! KERP_Modules_Leads_Service::instance()->add_event( (int) $row['user_id'], $campaign_id, (int) $row['membership_id'], $to, 'registration_stages_reserved', 'هماهنگ‌سازی با مراحل رزروشده فرم ثبت‌نام', [ 'from_stage_id' => $from, 'to_stage_id' => $to, 'registration_id' => (int) $row['id'] ] ) ) throw new RuntimeException( 'ثبت سابقه هماهنگ‌سازی مراحل ناموفق بود.' );
        }
        // In-flight OTP sessions keep their tokens/answers and complete against the reserved stages.
        if ( $wpdb->query( $wpdb->prepare( "UPDATE {$entries} SET stage_one=%d,stage_two=%d WHERE campaign_id=%d AND status IN ('pending','verified')", $first_id, $second_id, $campaign_id ) ) === FALSE ) throw new RuntimeException( 'هماهنگ‌سازی فرم‌های در حال تکمیل ناموفق بود.' );
    }

    private static function upgrade_reserved_stages(): void {
        if ( get_option( 'kerp_lead_registration_db' ) !== '1' || get_option( 'kerp_lead_registration_reserved_stages' ) === '1' ) return;
        global $wpdb;
        $entries = self::table(); $success = TRUE;
        $campaigns = KERP_Modules_Leads_Service::instance()->get_campaigns();
        if ( $wpdb->last_error ) return;
        foreach ( $campaigns as $campaign ) {
            $id = (int) $campaign['id'];
            if ( empty( self::config( $id )['enabled'] ) ) {
                $has_entries = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$entries} WHERE campaign_id=%d LIMIT 1", $id ) );
                if ( $wpdb->last_error ) { $success = FALSE; continue; }
                if ( ! $has_entries ) continue;
            }
            if ( is_wp_error( self::ensure_stages( $id ) ) ) $success = FALSE;
        }
        if ( $success ) update_option( 'kerp_lead_registration_reserved_stages', '1', FALSE );
    }
    private static function install(): void {
        if ( get_option( 'kerp_lead_registration_db' ) === '1' ) return;
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $table = self::table(); $answers = self::table( 'answers' ); $charset = $wpdb->get_charset_collate();
        dbDelta( "CREATE TABLE {$table} (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            campaign_id bigint unsigned NOT NULL,
            user_id bigint unsigned NOT NULL,
            phone varchar(20) NOT NULL,
            name varchar(190) NOT NULL,
            stage_one bigint unsigned NOT NULL,
            stage_two bigint unsigned NOT NULL,
            status varchar(20) NOT NULL DEFAULT 'pending',
            token_hash varchar(64) NOT NULL,
            otp_hash varchar(64) NOT NULL DEFAULT '',
            attempts int unsigned NOT NULL DEFAULT 0,
            otp_expires bigint unsigned NOT NULL DEFAULT 0,
            expires bigint unsigned NOT NULL DEFAULT 0,
            sent_at bigint unsigned NOT NULL DEFAULT 0,
            schema_json longtext NOT NULL,
            utm_json longtext NOT NULL,
            created_at datetime NOT NULL,
            verified_at datetime NULL,
            completed_at datetime NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY token_hash (token_hash),
            KEY customer_path (user_id,campaign_id),
            KEY path_status (campaign_id,status)
        ) ENGINE=InnoDB {$charset};" );
        dbDelta( "CREATE TABLE {$answers} (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            entry_id bigint unsigned NOT NULL,
            field_key varchar(80) NOT NULL,
            phase tinyint unsigned NOT NULL,
            value varchar(500) NOT NULL,
            PRIMARY KEY  (id),
            KEY entry_field (entry_id,field_key),
            KEY field_value (field_key,value(100))
        ) ENGINE=InnoDB {$charset};" );
        if ( $wpdb->get_var( "SHOW COLUMNS FROM {$table} LIKE 'token_hash'" ) && $wpdb->get_var( "SHOW COLUMNS FROM {$answers} LIKE 'field_key'" ) ) update_option( 'kerp_lead_registration_db', '1', FALSE );
    }
    private static function confirmation_defaults(): array {
        return [ 'type' => 'message', 'message' => '<p>ثبت‌نام شما با موفقیت تکمیل شد.</p>', 'redirect_url' => '' ];
    }
    private static function display_defaults(): array {
        return [
            'show_labels' => TRUE,
            'name_label' => 'نام و نام خانوادگی', 'name_placeholder' => '',
            'phone_label' => 'شماره موبایل', 'phone_placeholder' => '',
            'first_button' => 'ثبت و دریافت کد تأیید', 'second_button' => 'تکمیل ثبت‌نام',
        ];
    }
    public static function config( int $id ): array {
        $config = (array) get_option( 'kerp_lead_registration_' . $id, [] );
        $config += [ 'enabled' => FALSE, 'fields' => [] ];
        $config['confirmation'] = array_merge( self::confirmation_defaults(), is_array( $config['confirmation'] ?? NULL ) ? $config['confirmation'] : [] );
        $config['display'] = array_merge( self::display_defaults(), is_array( $config['display'] ?? NULL ) ? $config['display'] : [] );
        return $config;
    }
    public static function normalize_display( array $input, array $previous = [] ): array|WP_Error {
        $display = self::display_defaults();
        foreach ( $display as $key => $default ) {
            $value = $input[$key] ?? $previous[$key] ?? $default;
            if ( $key === 'show_labels' ) {
                // Shared modal switches send the checked value as a one-item array.
                if ( is_array( $value ) ) {
                    if ( count( $value ) > 1 ) return new WP_Error( 'display', 'وضعیت نمایش عنوان فیلدها معتبر نیست.' );
                    $value = $value ? reset( $value ) : '0';
                }
                if ( ! is_scalar( $value ) || ! in_array( (string) $value, [ '', '0', '1' ], TRUE ) ) return new WP_Error( 'display', 'وضعیت نمایش عنوان فیلدها معتبر نیست.' );
                $display[$key] = (string) $value === '1';
                continue;
            }
            if ( ! is_string( $value ) ) return new WP_Error( 'display', 'تنظیمات متن‌های فرم معتبر نیست.' );
            $value = sanitize_text_field( $value );
            if ( mb_strlen( $value ) > 190 ) return new WP_Error( 'display', 'متن عنوان، راهنما و دکمه‌ها نباید بیشتر از ۱۹۰ کاراکتر باشد.' );
            if ( $value === '' && ! str_ends_with( $key, '_placeholder' ) ) return new WP_Error( 'display', 'عنوان فیلدهای ضروری و متن هر دو دکمه را وارد کنید.' );
            $display[$key] = $value;
        }
        return $display;
    }
    public static function normalize_confirmation( array $input, array $previous = [] ): array|WP_Error {
        $confirmation = self::confirmation_defaults();
        foreach ( $confirmation as $key => $default ) {
            if ( isset( $previous[$key] ) && is_string( $previous[$key] ) ) $confirmation[$key] = $previous[$key];
            if ( array_key_exists( $key, $input ) ) {
                if ( ! is_string( $input[$key] ) ) return new WP_Error( 'confirmation', 'تنظیمات تأییدیه فرم معتبر نیست.' );
                $confirmation[$key] = trim( $input[$key] );
            }
        }
        if ( ! in_array( $confirmation['type'], [ 'message', 'redirect' ], TRUE ) ) return new WP_Error( 'confirmation', 'نوع تأییدیه فرم را انتخاب کنید.' );
        $confirmation['message'] = wp_kses_post( $confirmation['message'] );
        if ( $confirmation['type'] === 'message' ) {
            $text = html_entity_decode( wp_strip_all_tags( $confirmation['message'] ), ENT_QUOTES, 'UTF-8' );
            if ( preg_replace( '/[\s\p{Z}\x{200B}-\x{200D}\x{FEFF}]+/u', '', $text ) === '' ) return new WP_Error( 'confirmation', 'متن پیام پایان ثبت‌نام را وارد کنید.' );
        }
        $url = trim( $confirmation['redirect_url'] );
        $parts = wp_parse_url( $url );
        $valid_url = $parts && in_array( strtolower( $parts['scheme'] ?? '' ), [ 'http', 'https' ], TRUE ) && ! empty( $parts['host'] ) && ! isset( $parts['user'] ) && ! isset( $parts['pass'] ) && ! preg_match( '/[\x00-\x20\x7f\\\\]/', $url );
        if ( $confirmation['type'] === 'redirect' && ! $valid_url ) return new WP_Error( 'confirmation', 'آدرس کامل مقصد را با http:// یا https:// وارد کنید.' );
        $confirmation['redirect_url'] = $valid_url ? esc_url_raw( $url, [ 'http', 'https' ] ) : '';
        return $confirmation;
    }
    private static function completion_response( array $config, bool $already_completed = FALSE ): array {
        $confirmation = self::normalize_confirmation( [], $config['confirmation'] ?? [] );
        if ( is_wp_error( $confirmation ) ) $confirmation = self::confirmation_defaults();
        return [
            'completed' => TRUE,
            'msg' => $already_completed ? 'ثبت‌نام قبلاً تکمیل شده است.' : 'ثبت‌نام با موفقیت تکمیل شد.',
            'confirmation' => $confirmation['type'] === 'redirect'
                ? [ 'type' => 'redirect', 'url' => $confirmation['redirect_url'] ]
                : [ 'type' => 'message', 'html' => $confirmation['message'] ],
        ];
    }
    public static function normalize_fields( array $rows ): array|WP_Error {
        // The shared repeater includes one empty row for adding the next field.
        if ( count( $rows ) > 25 ) return new WP_Error( 'fields', 'حداکثر ۲۴ فیلد قابل تعریف است.' );
        $fields = [];
        foreach ( $rows as $row ) {
            if ( ! is_array( $row ) ) return new WP_Error( 'field', 'ساختار فیلد معتبر نیست.' );
            foreach ( [ 'key', 'label', 'form_label', 'type', 'phase', 'options', 'placeholder' ] as $key ) if ( isset( $row[$key] ) && ! is_scalar( $row[$key] ) ) return new WP_Error( 'field', 'اطلاعات فیلد معتبر نیست.' );
            foreach ( [ 'required', 'after_otp', 'show_in_leads' ] as $flag ) {
                $value = $row[$flag] ?? '0';
                // Shared modal switches submit a single checked value as an array.
                if ( is_array( $value ) ) {
                    if ( count( $value ) > 1 ) return new WP_Error( 'field', 'وضعیت سوییچ معتبر نیست.' );
                    $value = $value ? reset( $value ) : '0';
                }
                if ( ! is_scalar( $value ) || ! in_array( (string) $value, [ '', '0', '1' ], TRUE ) ) return new WP_Error( 'field', 'وضعیت سوییچ معتبر نیست.' );
                $row[$flag] = (string) $value === '1';
            }
            $label = sanitize_text_field( $row['label'] ?? '' );
            $form_label = sanitize_text_field( $row['form_label'] ?? '' );
            if ( mb_strlen( $form_label ) > 190 ) return new WP_Error( 'field', 'لیبل فیلد در فرم نباید بیشتر از ۱۹۰ کاراکتر باشد.' );
            $placeholder = sanitize_text_field( $row['placeholder'] ?? '' );
            if ( mb_strlen( $placeholder ) > 190 ) return new WP_Error( 'field', 'متن راهنمای فیلد نباید بیشتر از ۱۹۰ کاراکتر باشد.' );
            $key = sanitize_key( $row['key'] ?? '' );
            if ( $key === '' && $label === '' && $form_label === '' && $placeholder === '' && empty( $row['type'] ) && trim( (string) ( $row['options'] ?? '' ) ) === '' && ! $row['required'] && ! $row['after_otp'] && ! $row['show_in_leads'] ) continue;
            if ( count( $fields ) >= 24 ) return new WP_Error( 'fields', 'حداکثر ۲۴ فیلد قابل تعریف است.' );
            if ( ! $key ) $key = 'f_' . str_replace( '-', '', wp_generate_uuid4() );
            $type = $row['type'] ?? '';
            $phase = isset( $row['phase'] ) ? (int) $row['phase'] : ( $row['after_otp'] ? 2 : 1 );
            if ( $label === '' || strlen( $key ) > 80 || ! preg_match( '/^f_[a-z0-9_]+$/D', $key ) || isset( $fields[$key] ) || ! in_array( $type, [ 'text', 'checkbox', 'radio', 'select' ], TRUE ) || ! in_array( $phase, [ 1, 2 ], TRUE ) ) return new WP_Error( 'field', 'عنوان، نوع و بخش فیلد را درست انتخاب کنید.' );
            $options = array_values( array_unique( array_filter( array_map( 'sanitize_text_field', preg_split( '/\r?\n/', (string) ( $row['options'] ?? '' ) ) ), static fn($v) => $v !== '' ) ) );
            if ( $type !== 'text' && ( ! $options || count( $options ) > 50 ) ) return new WP_Error( 'options', 'برای گزینه‌ها بین ۱ تا ۵۰ سطر وارد کنید.' );
            foreach ( $options as $v ) if ( mb_strlen( $v ) > 190 ) return new WP_Error( 'options', 'متن گزینه بیش از حد طولانی است.' );
            $fields[$key] = [ 'key' => $key, 'label' => mb_substr( $label, 0, 190 ), 'form_label' => $form_label, 'placeholder' => $placeholder, 'type' => $type, 'phase' => $phase, 'required' => ! empty( $row['required'] ), 'show_in_leads' => $row['show_in_leads'], 'options' => $type === 'text' ? [] : $options ];
        }
        return array_values( $fields );
    }
    public static function validate_answers( array $fields, array $posted, int $phase ): array|WP_Error {
        $out = [];
        foreach ( $fields as $field ) {
            if ( (int) $field['phase'] !== $phase ) continue;
            $raw = $posted[$field['key']] ?? ( $field['type'] === 'checkbox' ? [] : '' );
            if ( $field['type'] === 'checkbox' ) {
                if ( ! is_array( $raw ) || count( $raw ) > 50 ) return new WP_Error( 'answer', 'پاسخ معتبر نیست.' );
            } else {
                if ( ! is_string( $raw ) ) return new WP_Error( 'answer', 'پاسخ معتبر نیست.' );
                $raw = [ $raw ];
            }
            $values = [];
            foreach ( $raw as $v ) {
                if ( ! is_string( $v ) || mb_strlen( $v ) > 500 ) return new WP_Error( 'answer', 'پاسخ بیش از حد طولانی است.' );
                $v = sanitize_text_field( $v );
                if ( $v === '' ) continue;
                if ( $field['type'] !== 'text' && ! in_array( $v, $field['options'], TRUE ) ) return new WP_Error( 'answer', 'گزینه انتخاب‌شده معتبر نیست.' );
                $values[] = $v;
            }
            if ( $field['required'] && ! $values ) return new WP_Error( 'required', 'فیلد «' . ( trim( $field['form_label'] ?? '' ) !== '' ? $field['form_label'] : $field['label'] ) . '» الزامی است.' );
            $out[$field['key']] = array_values( array_unique( $values ) );
        }
        return $out;
    }
    public static function save(): void {
        if ( ! is_user_logged_in() || ! KERP_App::instance()->current_user_has_access() || ! KERP_Modules_Leads_View::can_configure() || ! wp_verify_nonce( self::post( 'leads_nonce' ), 'kerp_leads' ) ) self::fail( 'دسترسی یا اعتبار فرم کافی نیست.', 403 );
        if ( get_option( 'kerp_lead_registration_db' ) !== '1' ) self::fail( 'جدول‌های ثبت‌نام هنوز آماده نیستند؛ وضعیت دیتابیس را بررسی کنید.' );
        $id = absint( self::post( 'campaign_id' ) );
        if ( ! KERP_Modules_Leads_Service::instance()->get_campaign( $id ) ) self::fail( 'مسیر پیدا نشد.' );
        $fields = self::normalize_fields( isset( $_POST['registration_fields'] ) && is_array( $_POST['registration_fields'] ) ? wp_unslash( $_POST['registration_fields'] ) : [] );
        if ( is_wp_error( $fields ) ) self::fail( $fields->get_error_message() );
        $confirmation_input = [];
        foreach ( [ 'type', 'message', 'redirect_url' ] as $key ) {
            if ( isset( $_POST['confirmation_' . $key] ) ) $confirmation_input[$key] = wp_unslash( $_POST['confirmation_' . $key] );
        }
        $confirmation = self::normalize_confirmation( $confirmation_input, self::config( $id )['confirmation'] );
        if ( is_wp_error( $confirmation ) ) self::fail( $confirmation->get_error_message() );
        $display_input = [];
        foreach ( array_keys( self::display_defaults() ) as $key ) {
            if ( isset( $_POST['display_' . $key] ) ) $display_input[$key] = wp_unslash( $_POST['display_' . $key] );
        }
        // Retain settings for an older open editor, but allow the new switch to be unchecked.
        if ( self::post( 'display_settings_present' ) === '1' && ! isset( $display_input['show_labels'] ) ) $display_input['show_labels'] = '0';
        $display = self::normalize_display( $display_input, self::config( $id )['display'] );
        if ( is_wp_error( $display ) ) self::fail( $display->get_error_message() );
        $enabled = self::post( 'enabled' ) === '1';
        if ( $enabled ) {
            $stages = self::ensure_stages( $id );
            if ( is_wp_error( $stages ) ) self::fail( $stages->get_error_message() );
        }
        update_option( 'kerp_lead_registration_' . $id, [ 'enabled' => $enabled, 'fields' => $fields, 'confirmation' => $confirmation, 'display' => $display ], FALSE );
        wp_send_json( [ 'status' => 'success', 'msg' => 'فرم ثبت‌نام ذخیره شد.' ] + KERP_Api_Page_Content::build_page_response( '/erp/marketing/pipelines/' . $id . '/', [], TRUE ) );
    }
    private static function stages( int $id ): array { return array_values( array_filter( KERP_Modules_Leads_Service::instance()->get_stages( $id ), [ self::class, 'is_reserved_stage' ] ) ); }
    private static function post( string $key ): string { return isset( $_POST[$key] ) && is_string( $_POST[$key] ) ? wp_unslash( $_POST[$key] ) : ''; }
    private static function fail( string $msg, int $status = 400 ): never { wp_send_json( [ 'status' => 'error', 'msg' => $msg, 'restart' => $status === 410 ], $status ); }
    private static function lock( string $key ): string {
        global $wpdb; $name = 'kerp_reg_' . hash( 'sha256', $key ); $name = substr( $name, 0, 64 );
        if ( (int) $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 3)', $name ) ) !== 1 ) throw new RuntimeException( 'درخواست در حال پردازش است؛ دوباره تلاش کنید.' );
        return $name;
    }
    private static function unlock( string $name ): void { global $wpdb; $wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $name ) ); }
    private static function limit( string $key, int $max ): void {
        $lock = self::lock( 'limit:' . $key );
        try {
            $key = 'kerp_reg_rate_' . hash( 'sha256', $key ); $state = get_transient( $key );
            if ( ! is_array( $state ) || $state['until'] <= time() ) $state = [ 'n' => 0, 'until' => time() + 900 ];
            if ( $state['n'] >= $max ) throw new RuntimeException( 'تعداد درخواست‌ها زیاد است؛ کمی بعد دوباره تلاش کنید.' );
            ++$state['n']; set_transient( $key, $state, max( 1, $state['until'] - time() ) );
        } finally { self::unlock( $lock ); }
    }
    public static function public_action( string $action ): void {
        if ( ($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST' || ! wp_verify_nonce( self::post( 'nonce' ), 'kerp_lead_registration' ) ) self::fail( 'اعتبار فرم منقضی شده؛ صفحه را تازه کنید.', 403 );
        if ( get_option( 'kerp_lead_registration_db' ) !== '1' ) self::fail( 'فرم موقتاً در دسترس نیست.', 503 );
        try {
            if ( $action === 'start' ) $result = self::start();
            else {
                $token = self::post( 'token' );
                if ( ! preg_match( '/^[a-f0-9]{64}$/D', $token ) ) throw new RuntimeException( 'جلسه ثبت‌نام معتبر نیست.' );
                $lock = self::lock( 'session:' . $token );
                try { $result = self::continue_registration( $action, $token ); }
                finally { self::unlock( $lock ); }
            }
        } catch ( Throwable $error ) { self::fail( $error->getMessage(), $error->getCode() === 410 ? 410 : 400 ); }
        wp_send_json( [ 'status' => 'success' ] + $result );
    }
    /** The authenticated account, never a user selected by a submitted phone number. */
    public static function account_identity(): array {
        $uid = get_current_user_id();
        $user = $uid ? get_userdata( $uid ) : FALSE;
        if ( ! $user ) return [];
        $phone = '';
        foreach ( [ KERP_Helpers_Phone::get_meta_key(), 'billing_phone' ] as $key ) {
            $candidate = KERP_Helpers_Phone::normalize( (string) get_user_meta( $uid, $key, TRUE ) );
            if ( preg_match( '/^9[0-9]{9}$/D', $candidate ) ) { $phone = $candidate; break; }
        }
        return [ 'user_id' => $uid, 'name' => (string) $user->display_name, 'phone' => $phone ];
    }
    private static function profile_name( string $name ): array {
        $name = trim( sanitize_text_field( $name ) );
        $parts = preg_split( '/\s+/u', $name, 2 );
        return [ 'display_name' => $name, 'first_name' => $parts[0] ?? '', 'last_name' => $parts[1] ?? '' ];
    }
    private static function save_profile_name( int $user_id, string $name ): void {
        $result = wp_update_user( [ 'ID' => $user_id ] + self::profile_name( $name ) );
        if ( is_wp_error( $result ) ) throw new RuntimeException( 'ذخیره نام در پروفایل مشتری ناموفق بود؛ دوباره تلاش کنید.' );
    }
    private static function start(): array {
        global $wpdb;
        self::limit( 'ip:' . ( $_SERVER['REMOTE_ADDR'] ?? '' ), 20 );
        $id = absint( self::post( 'campaign_id' ) ); $config = self::config( $id ); $service = KERP_Modules_Leads_Service::instance();
        $campaign = $service->get_campaign( $id ); $stages = self::stages( $id );
        if ( empty( $config['enabled'] ) || ! $campaign || $campaign['status'] !== 'active' || count( $stages ) < 2 ) throw new RuntimeException( 'ثبت‌نام این مسیر در دسترس نیست.' );
        $account = self::account_identity();
        $authenticated = ! empty( $account['user_id'] );
        $name = sanitize_text_field( self::post( 'name' ) );
        $phone = $account['phone'] ?? '';
        if ( $phone === '' ) $phone = KERP_Helpers_Phone::normalize( KERP_Helpers_Format::sanitize_numbers( self::post( 'phone' ) ) );
        if ( $name === '' ) throw new RuntimeException( 'فیلد «' . $config['display']['name_label'] . '» الزامی است.' );
        if ( mb_strlen( $name ) > 190 ) throw new RuntimeException( 'مقدار «' . $config['display']['name_label'] . '» نباید بیشتر از ۱۹۰ کاراکتر باشد.' );
        if ( ! preg_match( '/^9[0-9]{9}$/D', $phone ) ) throw new RuntimeException( 'فیلد «' . $config['display']['phone_label'] . '» را با شماره موبایل معتبر وارد کنید.' );
        $answers = self::validate_answers( $config['fields'], self::posted_answers(), 1 );
        if ( is_wp_error( $answers ) ) throw new RuntimeException( $answers->get_error_message() );
        self::limit( 'phone:' . $phone, 5 );
        $lock = self::lock( 'phone:' . $phone );
        try {
            $uid = $authenticated ? (int) $account['user_id'] : ( KERP_Helpers_Phone::get_user_id( $phone ) ?: KERP_Helpers_Phone::get_user_id( $phone, 'billing_phone' ) );
            if ( ! $uid ) {
                $uid = wp_insert_user( [ 'user_login' => 'lead_' . $phone, 'user_pass' => wp_generate_password( 32, TRUE, TRUE ), 'role' => get_role( 'customer' ) ? 'customer' : 'subscriber' ] + self::profile_name( $name ) );
                if ( is_wp_error( $uid ) ) throw new RuntimeException( 'ثبت اطلاعات ناموفق بود؛ دوباره تلاش کنید.' );
                update_user_meta( $uid, KERP_Helpers_Phone::get_meta_key(), $phone );
                update_user_meta( $uid, 'billing_phone', $phone );
                update_user_meta( $uid, 'kerp_registration_phone_verified', 0 );
            }
            $existing = $service->get_membership( $uid, $id );
            if ( ! empty( $existing['exited_at'] ) ) throw new RuntimeException( 'ثبت‌نام این مسیر برای این شماره امکان‌پذیر نیست.' );
            $utm = [];
            foreach ( self::UTM as $key ) { $v = self::post( $key ); if ( $v !== '' ) $utm[$key] = mb_substr( sanitize_text_field( $v ), 0, 500 ); }
            if ( ! $existing ) {
                $joined = $service->join_pipeline( $uid, $id, [ 'stage_id' => (int) $stages[0]['id'], 'source' => 'registration', 'note' => $authenticated ? 'ثبت‌نام اولیه با حساب واردشده.' : 'ثبت‌نام اولیه؛ شماره هنوز تأیید نشده است.' ] );
                if ( is_wp_error( $joined ) ) throw new RuntimeException( $joined->get_error_message() );
            }
            if ( ! $existing && $utm ) $wpdb->update( KERP_Modules_Leads_Module::table( 'memberships' ), [ 'utm_json' => wp_json_encode( $utm, JSON_UNESCAPED_UNICODE ) ], [ 'user_id' => $uid, 'campaign_id' => $id ] );
            $token = bin2hex( random_bytes( 32 ) );
            $row = [ 'campaign_id' => $id, 'user_id' => $uid, 'phone' => $phone, 'name' => $name, 'stage_one' => $stages[0]['id'], 'stage_two' => $stages[1]['id'], 'token_hash' => hash( 'sha256', $token ), 'schema_json' => wp_json_encode( $config['fields'], JSON_UNESCAPED_UNICODE ), 'utm_json' => wp_json_encode( $utm, JSON_UNESCAPED_UNICODE ), 'created_at' => current_time( 'mysql' ), 'expires' => time() + 1800 ];
            if ( $authenticated ) { $row['status'] = 'verified'; $row['verified_at'] = current_time( 'mysql' ); }
            if ( $wpdb->query( 'START TRANSACTION' ) === FALSE ) throw new RuntimeException( 'ذخیره فرم ناموفق بود.' );
            try {
            if ( $wpdb->insert( self::table(), $row ) === FALSE ) throw new RuntimeException( 'ذخیره فرم ناموفق بود.' );
            $entry_id = (int) $wpdb->insert_id;
            self::store_answers( $entry_id, $answers, 1 );
            // Attribution belongs to this submission even before verification; never overwrite an existing customer's account details.
            foreach ( $utm as $key => $value ) self::store_answers( $entry_id, [ $key => [ $value ] ], 0 );
            $member = $service->get_membership( $uid, $id );
            if ( ! $service->add_event( $uid, $id, (int) $member['id'], (int) $stages[0]['id'], 'registration_started', $authenticated ? 'ثبت فرم اولیه با حساب واردشده' : 'ثبت فرم اولیه؛ در انتظار تأیید شماره', [ 'registration_id' => $entry_id, 'utm' => $utm ] ) ) throw new RuntimeException( 'ثبت تاریخچه فرم ناموفق بود.' );
            if ( $authenticated && ! $service->add_event( $uid, $id, (int) $member['id'], (int) $stages[0]['id'], 'registration_verified', 'ادامه ثبت‌نام با حساب واردشده؛ بدون نیاز به کد پیامکی', [ 'registration_id' => $entry_id, 'method' => 'authenticated_session' ] ) ) throw new RuntimeException( 'ثبت سابقه تأیید حساب ناموفق بود.' );
            if ( $wpdb->query( 'COMMIT' ) === FALSE ) throw new RuntimeException( 'ذخیره فرم ناموفق بود.' );
            } catch ( Throwable $e ) { $wpdb->query( 'ROLLBACK' ); throw $e; }
            if ( $authenticated ) {
                self::save_profile_name( $uid, $name );
                return [ 'token' => $token, 'verified' => TRUE, 'fields' => array_values( array_filter( $config['fields'], static fn( $field ) => (int) $field['phase'] === 2 ) ), 'msg' => 'اطلاعات اولیه ثبت شد؛ اطلاعات تکمیلی را وارد کنید.' ];
            }
            $send = self::send_code( $entry_id, $phone );
            return [ 'token' => $token, 'msg' => is_wp_error( $send ) ? $send->get_error_message() : 'کد تأیید ارسال شد.', 'sms_sent' => ! is_wp_error( $send ) ];
        } finally { self::unlock( $lock ); }
    }
    private static function posted_answers(): array { return isset( $_POST['answers'] ) && is_array( $_POST['answers'] ) ? wp_unslash( $_POST['answers'] ) : []; }
    private static function store_answers( int $id, array $answers, int $phase ): void {
        global $wpdb;
        foreach ( $answers as $key => $values ) foreach ( $values as $value ) if ( $wpdb->insert( self::table( 'answers' ), [ 'entry_id' => $id, 'field_key' => $key, 'phase' => $phase, 'value' => $value ] ) === FALSE ) throw new RuntimeException( 'ذخیره پاسخ‌ها ناموفق بود.' );
    }
    private static function send_code( int $id, string $phone ): bool|WP_Error {
        global $wpdb;
        $otp = (string) random_int( 1000, 9999 );
        $saved = $wpdb->update( self::table(), [ 'otp_hash' => hash_hmac( 'sha256', $otp, wp_salt() ), 'otp_expires' => time() + 180, 'sent_at' => time(), 'attempts' => 0 ], [ 'id' => $id ] );
        if ( $saved === FALSE ) return new WP_Error( 'otp', 'ذخیره کد ناموفق بود.' );
        try {
        if ( class_exists( 'KSP_Modules_Sms_Module' ) ) $result = KSP_Modules_Sms_Module::send_otp( $phone, $otp );
        elseif ( class_exists( 'kasebiSMS' ) ) $result = ( new kasebiSMS() )->send_otp_sms( $phone, $otp );
        else $result = new WP_Error( 'sms', 'سرویس پیامک در دسترس نیست.' );
        } catch ( Throwable $e ) { $result = new WP_Error( 'sms', 'ارسال پیامک ناموفق بود.' ); }
        if ( KERP_Modules_Payments_SMS::delivery_status( $result ) === 'failed' ) { $wpdb->update( self::table(), [ 'otp_hash' => '', 'sent_at' => 0 ], [ 'id' => $id ] ); return new WP_Error( 'sms', 'ارسال پیامک ناموفق بود؛ دریافت مجدد را بزنید.' ); }
        return TRUE;
    }
    private static function continue_registration( string $action, string $token ): array {
        global $wpdb;
        $table = self::table(); $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE token_hash=%s", hash( 'sha256', $token ) ), ARRAY_A );
        if ( ! $row || (int) $row['expires'] < time() ) throw new RuntimeException( 'زمان ثبت‌نام تمام شده؛ فرم را دوباره ارسال کنید.', 410 );
        $config = self::config( (int) $row['campaign_id'] ); $service = KERP_Modules_Leads_Service::instance(); $campaign = $service->get_campaign( (int) $row['campaign_id'] );
        if ( empty( $config['enabled'] ) || ! $campaign || $campaign['status'] !== 'active' ) throw new RuntimeException( 'ثبت‌نام این مسیر متوقف شده است.' );
        if ( $action === 'resend' ) {
            if ( $row['status'] !== 'pending' || (int) $row['sent_at'] + 60 > time() ) throw new RuntimeException( 'برای دریافت مجدد کمی صبر کنید.' );
            self::limit( 'phone:' . $row['phone'], 5 ); self::limit( 'ip:' . ($_SERVER['REMOTE_ADDR'] ?? ''), 20 );
            $sent = self::send_code( (int) $row['id'], $row['phone'] ); if ( is_wp_error( $sent ) ) throw new RuntimeException( $sent->get_error_message() );
            return [ 'msg' => 'کد جدید ارسال شد.' ];
        }
        $fields = json_decode( $row['schema_json'], TRUE ) ?: [];
        if ( $action === 'verify' ) {
            if ( $row['status'] === 'pending' ) {
                if ( ! $row['otp_hash'] || (int) $row['otp_expires'] < time() || (int) $row['attempts'] >= 5 ) throw new RuntimeException( 'کد منقضی شده؛ کد جدید دریافت کنید.' );
                if ( $wpdb->query( $wpdb->prepare( "UPDATE {$table} SET attempts=attempts+1 WHERE id=%d", $row['id'] ) ) !== 1 ) throw new RuntimeException( 'بررسی کد ناموفق بود.' );
                $code = KERP_Helpers_Format::sanitize_numbers( self::post( 'otp' ) );
                if ( ! hash_equals( $row['otp_hash'], hash_hmac( 'sha256', $code, wp_salt() ) ) ) throw new RuntimeException( 'کد تأیید صحیح نیست.' );
                if ( $wpdb->query( 'START TRANSACTION' ) === FALSE ) throw new RuntimeException( 'ثبت تأیید ناموفق بود.' );
                try {
                    if ( $wpdb->update( $table, [ 'status' => 'verified', 'verified_at' => current_time( 'mysql' ), 'otp_hash' => '', 'expires' => time() + 1800 ], [ 'id' => $row['id'] ] ) === FALSE ) throw new RuntimeException( 'ثبت تأیید ناموفق بود.' );
                    $member = $service->get_membership( (int)$row['user_id'], (int)$row['campaign_id'] );
                    if ( ! $member || ! $service->add_event( (int)$row['user_id'], (int)$row['campaign_id'], (int)$member['id'], (int)$row['stage_one'], 'registration_verified', 'تأیید شماره موبایل با کد پیامکی', [ 'registration_id' => (int)$row['id'] ] ) ) throw new RuntimeException( 'ثبت تاریخچه تأیید ناموفق بود.' );
                    if ( $wpdb->query( 'COMMIT' ) === FALSE ) throw new RuntimeException( 'ثبت تأیید ناموفق بود.' );
                } catch ( Throwable $e ) { $wpdb->query( 'ROLLBACK' ); throw $e; }
                update_user_meta( $row['user_id'], 'kerp_registration_phone_verified', 1 );
            }
            // Existing accounts are updated only after proof of phone ownership.
            self::save_profile_name( (int) $row['user_id'], (string) $row['name'] );
            return [ 'fields' => array_values( array_filter( $fields, static fn($f) => (int)$f['phase'] === 2 ) ), 'msg' => 'شماره تأیید شد؛ اطلاعات تکمیلی را ثبت کنید.' ];
        }
        if ( ! in_array( $row['status'], [ 'verified', 'completed' ], TRUE ) ) throw new RuntimeException( 'ابتدا شماره موبایل را تأیید کنید.' );
        if ( $row['status'] === 'completed' ) return self::completion_response( $config, TRUE );
        $answers = self::validate_answers( $fields, self::posted_answers(), 2 );
        if ( is_wp_error( $answers ) ) throw new RuntimeException( $answers->get_error_message() );
        $result = $service->complete_registration( $row, $answers );
        if ( is_wp_error( $result ) ) throw new RuntimeException( $result->get_error_message() );
        return self::completion_response( $config );
    }
    public static function shortcode( array|string $atts = [] ): string {
        $atts = shortcode_atts( [ 'id' => 0 ], $atts ); $id = absint( $atts['id'] ); $config = self::config( $id );
        $campaign = KERP_Modules_Leads_Service::instance()->get_campaign( $id );
        if ( empty( $config['enabled'] ) || ! $campaign || $campaign['status'] !== 'active' ) return '';
        wp_enqueue_script( 'kerp-lead-registration', KERP_ASSETS_URL . 'public/js/lead-registration.js', [ 'jquery', 'nooshika_main_script' ], kerp_asset_version( 'public/js/lead-registration.js' ), TRUE );
        wp_enqueue_style( 'kerp-lead-registration', KERP_ASSETS_URL . 'public/css/lead-registration.css', [], kerp_asset_version( 'public/css/lead-registration.css' ) );
        wp_localize_script( 'kerp-lead-registration', 'KERPRegistration', [ 'url' => home_url( '/' . KERP_Modules_Ajax_Module::ENDPOINT . '/' ), 'nonce' => wp_create_nonce( 'kerp_lead_registration' ) ] );
        $identity = self::account_identity();
        if ( $identity && $config['display']['first_button'] === self::display_defaults()['first_button'] ) $config['display']['first_button'] = 'ادامه ثبت‌نام';
        ob_start(); KERP_Helpers_Template::render_template( 'modules/leads/partials/registration-public.php', [ 'campaign_id' => $id, 'config' => $config, 'identity' => $identity ] ); return ob_get_clean();
    }
    public static function list_statuses( array $memberships ): array {
        if ( ! $memberships || get_option( 'kerp_lead_registration_db' ) !== '1' ) return [];
        global $wpdb; $table = self::table();
        $users = implode( ',', array_unique( array_map( 'absint', array_column( $memberships, 'user_id' ) ) ) );
        $campaigns = implode( ',', array_unique( array_map( 'absint', array_column( $memberships, 'campaign_id' ) ) ) );
        $rows = $wpdb->get_results( "SELECT user_id,campaign_id,status FROM {$table} WHERE id IN (SELECT MAX(id) FROM {$table} WHERE user_id IN ({$users}) AND campaign_id IN ({$campaigns}) GROUP BY user_id,campaign_id)", ARRAY_A );
        $out = []; foreach ( (array)$rows as $row ) $out[$row['user_id'] . ':' . $row['campaign_id']] = $row['status'];
        return $out;
    }
    /** Read-only, scoped records; never expose OTP credentials or registration tokens. */
    public static function get_response_page( int $user_id, int $campaign_id, int $page = 1 ): array {
        $empty = [ 'items' => [], 'total' => 0, 'page' => 1, 'pages' => 1 ];
        if ( get_option( 'kerp_lead_registration_db' ) !== '1' || ! is_user_logged_in() || ! KERP_App::instance()->current_user_has_access() || ( ! current_user_can( KERP_Admin::CAPABILITY ) && ! kerp_can( 'leads.view', 'view' ) ) ) return $empty;
        global $wpdb; $table = self::table(); $answers_table = self::table( 'answers' );
        $where = $wpdb->prepare( ' WHERE user_id=%d AND campaign_id=%d', $user_id, $campaign_id );
        $total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}{$where}" );
        $pages = max( 1, (int) ceil( $total / 10 ) ); $page = max( 1, min( $pages, $page ) );
        $items = (array) $wpdb->get_results( $wpdb->prepare( "SELECT id,name,phone,status,schema_json,utm_json,created_at,verified_at,completed_at FROM {$table}{$where} ORDER BY id DESC LIMIT %d OFFSET %d", 10, ( $page - 1 ) * 10 ), ARRAY_A );
        $answers = [];
        if ( $items ) {
            $ids = array_map( 'absint', array_column( $items, 'id' ) );
            $rows = (array) $wpdb->get_results( $wpdb->prepare( "SELECT entry_id,field_key,phase,value FROM {$answers_table} WHERE entry_id IN (" . implode( ',', array_fill( 0, count( $ids ), '%d' ) ) . ') ORDER BY phase,id', ...$ids ), ARRAY_A );
            foreach ( $rows as $row ) $answers[(int) $row['entry_id']][] = $row;
        }
        foreach ( $items as &$item ) $item['answers'] = $answers[(int) $item['id']] ?? [];
        unset( $item );
        return compact( 'items', 'total', 'page', 'pages' );
    }

    public static function render_responses( int $user_id, int $campaign_id ): void {
        foreach ( self::get_response_page( $user_id, $campaign_id )['items'] as $entry ) {
            $answers = $entry['answers'];
            KERP_Helpers_Template::render_template( 'modules/leads/partials/registration-responses.php', compact( 'entry', 'answers' ) );
        }
    }
    /** Current display settings apply to the latest submission for each displayed membership. */
    public static function list_field_badges( array $memberships ): array {
        if ( ! $memberships || get_option( 'kerp_lead_registration_db' ) !== '1' || ! is_user_logged_in() || ! KERP_App::instance()->current_user_has_access() || ( ! current_user_can( KERP_Admin::CAPABILITY ) && ! kerp_can( 'leads.view', 'view' ) ) ) return [];
        global $wpdb;
        $definitions = []; $pairs = []; $keys = [];
        foreach ( $memberships as $member ) {
            $campaign_id = absint( $member['campaign_id'] ); $user_id = absint( $member['user_id'] );
            if ( ! isset( $definitions[$campaign_id] ) ) {
                $definitions[$campaign_id] = [];
                foreach ( self::config( $campaign_id )['fields'] as $field ) {
                    if ( empty( $field['show_in_leads'] ) ) continue;
                    $definitions[$campaign_id][$field['key']] = $field['label'];
                    $keys[$field['key']] = $field['key'];
                }
            }
            if ( $definitions[$campaign_id] ) $pairs[$user_id . ':' . $campaign_id] = $wpdb->prepare( '(user_id=%d AND campaign_id=%d)', $user_id, $campaign_id );
        }
        if ( ! $pairs ) return [];
        $entries = self::table(); $answers = self::table( 'answers' );
        $where = implode( ' OR ', $pairs );
        $fields_sql = $wpdb->prepare( 'ra.field_key IN (' . implode( ',', array_fill( 0, count( $keys ), '%s' ) ) . ')', ...array_values( $keys ) );
        $rows = (array) $wpdb->get_results( "SELECT re.user_id,re.campaign_id,ra.field_key,ra.value FROM {$entries} re INNER JOIN (SELECT MAX(id) id FROM {$entries} WHERE {$where} GROUP BY user_id,campaign_id) latest ON latest.id=re.id INNER JOIN {$answers} ra ON ra.entry_id=re.id WHERE ra.phase IN (1,2) AND {$fields_sql} ORDER BY ra.id", ARRAY_A );
        $values = [];
        foreach ( $rows as $row ) {
            if ( ! isset( $definitions[(int) $row['campaign_id']][$row['field_key']] ) || (string) $row['value'] === '' ) continue;
            $values[$row['user_id'] . ':' . $row['campaign_id']][$row['field_key']][] = (string) $row['value'];
        }
        $badges = [];
        foreach ( $memberships as $member ) {
            $pair = $member['user_id'] . ':' . $member['campaign_id'];
            foreach ( $definitions[(int) $member['campaign_id']] ?? [] as $key => $label ) {
                if ( ! empty( $values[$pair][$key] ) ) $badges[$pair][] = [ 'label' => $label, 'value' => implode( '، ', array_unique( $values[$pair][$key] ) ) ];
            }
        }
        return $badges;
    }

    public static function utm_filter_options( int $campaign_id = 0 ): array {
        $options = array_fill_keys( self::UTM, [] );
        if ( get_option( 'kerp_lead_registration_db' ) !== '1' || ! is_user_logged_in() || ! KERP_App::instance()->current_user_has_access() || ( ! current_user_can( KERP_Admin::CAPABILITY ) && ! kerp_can( 'leads.view', 'view' ) ) ) return $options;
        global $wpdb;
        $answers = self::table( 'answers' ); $entries = self::table();
        $where = $wpdb->prepare( 'ra.phase=0 AND ra.value<>%s AND ra.field_key IN (' . implode( ',', array_fill( 0, count( self::UTM ), '%s' ) ) . ')', '', ...self::UTM );
        if ( $campaign_id > 0 ) $where .= $wpdb->prepare( ' AND re.campaign_id=%d', $campaign_id );
        $rows = (array) $wpdb->get_results( "SELECT DISTINCT ra.field_key,ra.value FROM {$answers} ra INNER JOIN {$entries} re ON re.id=ra.entry_id WHERE {$where} ORDER BY ra.field_key,ra.value", ARRAY_A );
        foreach ( $rows as $row ) $options[$row['field_key']][] = (string) $row['value'];
        return $options;
    }

    public static function filter_sql( array $filter, int $campaign_id = 0 ): string {
        global $wpdb;
        $clauses = []; $types = array_column( self::config( $campaign_id )['fields'] ?? [], 'type', 'key' );
        foreach ( (array)($filter['answers'] ?? []) as $key => $value ) {
            if ( ! is_string( $value ) || $value === '' || ! preg_match( '/^[a-z0-9_]{1,80}$/D', (string)$key ) ) continue;
            $answers = self::table( 'answers' );
            $is_utm = in_array( $key, self::UTM, TRUE );
            $exact = $is_utm || ( isset( $types[$key] ) && $types[$key] !== 'text' );
            if ( $exact && str_starts_with( $value, 'option:' ) ) $value = substr( $value, 7 );
            $op = $exact ? '=' : 'LIKE';
            $phase = $is_utm ? ' AND ra.phase=0' : '';
            $clauses[] = $wpdb->prepare( "EXISTS (SELECT 1 FROM {$answers} ra WHERE ra.entry_id=re.id AND ra.field_key=%s{$phase} AND ra.value {$op} %s)", $key, $exact ? $value : '%' . $wpdb->esc_like( mb_substr( $value, 0, 500 ) ) . '%' );
        }
        $status = $filter['status'] ?? '';
        if ( in_array( $status, [ 'pending', 'verified', 'completed' ], TRUE ) ) $clauses[] = $wpdb->prepare( 're.status=%s', $status );
        if ( ! $clauses ) return '';
        $table = self::table();
        return " AND EXISTS (SELECT 1 FROM {$table} re WHERE re.campaign_id=m.campaign_id AND re.user_id=m.user_id AND " . implode( ' AND ', $clauses ) . ')';
    }
}
