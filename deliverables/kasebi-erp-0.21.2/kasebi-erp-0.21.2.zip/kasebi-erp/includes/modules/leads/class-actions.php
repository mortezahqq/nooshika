<?php
defined( 'ABSPATH' ) || exit;

/** Configurable operator buttons. Effects run in order; transitions always run last. */
final class KERP_Modules_Leads_Actions {
    public static function buttons( int $stage ): array {
        $config = KERP_Modules_Leads_Service::instance()->stage_actions( $stage );
        if ( isset( $config['buttons'] ) ) return $config['buttons'];
        $course = (int) ( $config['course_access'] ?? 0 );
        return $course ? [ [ 'key'=>'legacy_course', 'label'=>'اعطای دسترسی دوره', 'course_id'=>$course, 'product_id'=>0, 'followup'=>FALSE, 'transition'=>'stay' ] ] : [];
    }
    public static function normalize( array $rows, int $campaign = 0 ): array|WP_Error {
        if ( count( $rows ) > 13 ) return new WP_Error( 'actions', 'حداکثر ۱۲ دکمه برای هر مرحله تعریف کنید.' );
        $out = [];
        foreach ( $rows as $row ) {
            if ( ! is_array( $row ) ) return new WP_Error( 'actions', 'ساختار اقدام معتبر نیست.' );
            foreach ( [ 'key','label','course_id','product_id','transition' ] as $key ) if ( isset( $row[$key] ) && ! is_scalar( $row[$key] ) ) return new WP_Error( 'actions', 'اطلاعات اقدام معتبر نیست.' );
            $followup = $row['followup'] ?? '0';
            if ( is_array( $followup ) && count( $followup ) <= 1 ) $followup = $followup ? reset( $followup ) : '0';
            if ( ! is_scalar( $followup ) || ! in_array( (string) $followup, [ '', '0', '1' ], TRUE ) ) return new WP_Error( 'actions', 'تنظیم پیگیری معتبر نیست.' );
            $label = sanitize_text_field( $row['label'] ?? '' );
            $transition = (string) ( $row['transition'] ?? '' ) ?: 'stay';
            foreach ( [ 'course_id','product_id' ] as $key ) if ( ! preg_match( '/^[0-9]*$/D', (string) ( $row[$key] ?? '' ) ) ) return new WP_Error( 'actions', 'دوره یا محصول معتبر نیست.' );
            $course = (int) ( $row['course_id'] ?? 0 ); $product = (int) ( $row['product_id'] ?? 0 );
            $sms_enabled = $row['sms_enabled'] ?? '0';
            if ( is_array( $sms_enabled ) && count( $sms_enabled ) <= 1 ) $sms_enabled = $sms_enabled ? reset( $sms_enabled ) : '0';
            if ( ! is_scalar( $sms_enabled ) || ! in_array( (string) $sms_enabled, [ '', '0', '1' ], TRUE ) ) return new WP_Error( 'sms', 'وضعیت پیامک معتبر نیست.' );
            $sms = [];
            if ( (string) $sms_enabled === '1' ) {
                if ( array_key_exists( 'sms', $row ) ) {
                    if ( ! is_array( $row['sms'] ) || count( $row['sms'] ) > 21 ) return new WP_Error( 'sms', 'حداکثر ۲۰ پیامک برای هر دکمه تعریف کنید.' );
                    $inputs = [];
                    foreach ( $row['sms'] as $input ) {
                        if ( ! is_array( $input ) ) return new WP_Error( 'sms', 'اطلاعات پیامک معتبر نیست.' );
                        $clean = [ 'enabled'=>'1', 'stay'=>'0' ];
                        foreach ( [ 'pattern','variables','delay','unit','condition_field','condition_value' ] as $field ) {
                            if ( ! is_scalar( $input[$field] ?? '' ) ) return new WP_Error( 'sms', 'اطلاعات پیامک معتبر نیست.' );
                            $clean[$field] = (string) ( $input[$field] ?? '' );
                        }
                        if ( count( array_filter( array_diff_key( $clean, [ 'enabled'=>1,'stay'=>1 ] ), static fn($v)=>trim($v)!=='' ) ) === 0 ) continue;
                        if ( trim( $clean['pattern'] ) === '' ) return new WP_Error( 'sms', 'کد پترن هر پیامک را وارد کنید.' );
                        $inputs[] = $clean;
                    }
                    if ( count( $inputs ) > 20 ) return new WP_Error( 'sms', 'حداکثر ۲۰ پیامک برای هر دکمه تعریف کنید.' );
                    $rules = KERP_Modules_Leads_SMS::validate( $inputs, $campaign );
                } else {
                $input = [ 'enabled'=>'1', 'stay'=>'0' ];
                foreach ( [ 'pattern','variables','delay','unit','condition_field','condition_value' ] as $field ) {
                    if ( ! is_scalar( $row['sms_' . $field] ?? '' ) ) return new WP_Error( 'sms', 'تنظیمات پیامک دکمه معتبر نیست.' );
                    $input[$field] = (string) ( $row['sms_' . $field] ?? '' );
                }
                $rules = KERP_Modules_Leads_SMS::validate( [ $input ], $campaign );
                }
                if ( is_wp_error( $rules ) ) return $rules;
                if ( ! $rules ) return new WP_Error( 'sms', 'پترن و زمان‌بندی پیامک دکمه را وارد کنید.' );
                $sms = $rules;
            }
            if ( $label === '' && ! $course && ! $product && ! $followup && ! $sms && $transition === 'stay' && empty( $row['key'] ) ) continue;
            if ( $label === '' || mb_strlen( $label ) > 100 || ! in_array( $transition, [ 'stay','next','exit' ], TRUE ) || ( ! $course && ! $product && ! $followup && ! $sms && $transition === 'stay' ) ) return new WP_Error( 'actions', 'عنوان دکمه و حداقل یک عملیات را مشخص کنید.' );
            if ( $course && ( ! function_exists( 'ld_update_course_access' ) || get_post_type( $course ) !== 'sfwd-courses' || get_post_status( $course ) !== 'publish' ) ) return new WP_Error( 'course', 'دوره منتشرشده لرندش انتخاب کنید.' );
            if ( $product && ! self::product( $product ) ) return new WP_Error( 'product', 'محصول ساده یا تنوع محصول قابل خرید انتخاب کنید.' );
            $key = sanitize_key( $row['key'] ?? '' ) ?: 'a_' . str_replace( '-', '', wp_generate_uuid4() );
            if ( strlen( $key ) > 64 || isset( $out[$key] ) ) return new WP_Error( 'actions', 'شناسه دکمه تکراری یا نامعتبر است.' );
            $out[$key] = [ 'key'=>$key, 'label'=>$label, 'course_id'=>$course, 'product_id'=>$product, 'followup'=>(bool) $followup, 'transition'=>$transition ];
            if ( $sms ) $out[$key]['sms'] = $sms;
        }
        if ( count( $out ) > 12 ) return new WP_Error( 'actions', 'حداکثر ۱۲ دکمه تعریف کنید.' );
        return array_values( $out );
    }
    private static function product( int $id ) {
        $p = function_exists( 'wc_get_product' ) ? wc_get_product( $id ) : FALSE;
        return $p && $p->is_type( [ 'simple','variation' ] ) && $p->get_status() === 'publish' && $p->is_purchasable() && $p->is_in_stock() ? $p : FALSE;
    }
    public static function save( int $campaign, int $stage, array $rows ): bool|WP_Error {
        $service = KERP_Modules_Leads_Service::instance(); $record = $service->get_stage( $stage );
        if ( ! $record || (int) $record['campaign_id'] !== $campaign ) return new WP_Error( 'scope', 'مرحله متعلق به این مسیر نیست.' );
        $buttons = self::normalize( $rows, $campaign ); if ( is_wp_error( $buttons ) ) return $buttons;
        // Retain the legacy bulk-course operation when exactly one course is configured.
        $courses = array_values( array_unique( array_filter( array_column( $buttons, 'course_id' ) ) ) );
        $config = [ 'buttons'=>$buttons, 'course_access'=>count( $courses ) === 1 ? $courses[0] : 0 ];
        if ( $service->stage_actions( $stage ) === $config ) return TRUE;
        return update_option( 'kerp_lead_stage_actions_' . $stage, $config, FALSE ) ? TRUE : new WP_Error( 'save', 'ذخیره اقدام‌ها ناموفق بود.' );
    }
    public static function allowed( array $button ): bool {
        if ( ! KERP_Modules_Leads_View::can_manage() ) return FALSE;
        $admin = current_user_can( KERP_Admin::CAPABILITY );
        if ( $button['followup'] && ( ! KERP_Modules::instance()->is_module_loaded( 'followups' ) || ( ! $admin && ! kerp_can( 'followups.create', 'action' ) ) ) ) return FALSE;
        if ( $button['product_id'] && ( ! KERP_Modules::instance()->is_module_loaded( 'orders' ) || ( ! $admin && ! kerp_can( 'orders.create', 'action' ) ) ) ) return FALSE;
        return TRUE;
    }
    public static function execute( int $user, int $campaign, int $stage, string $key, string $revision, string $request, string $date, string $time, string $note ): bool|WP_Error {
        global $wpdb;
        if ( ! preg_match( '/^[a-zA-Z0-9-]{16,64}$/D', $request ) ) return new WP_Error( 'request', 'شناسه درخواست معتبر نیست.' );
        $service = KERP_Modules_Leads_Service::instance();
        $buttons = array_column( self::buttons( $stage ), NULL, 'key' ); $button = $buttons[$key] ?? NULL;
        if ( ! $button || ! hash_equals( self::revision( $button ), $revision ) || ! self::allowed( $button ) ) return new WP_Error( 'action', 'اقدام تغییر کرده یا دسترسی اجرای آن را ندارید؛ صفحه را تازه کنید.' );
        $lock = 'kerp-action-' . md5( $wpdb->prefix . ':' . $user . ':' . $campaign );
        if ( (int) $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 0)', $lock ) ) !== 1 ) return new WP_Error( 'busy', 'اقدام دیگری در حال اجراست.' );
        try {
            $member = $service->get_membership( $user, $campaign );
            if ( ! $member || ! empty( $member['exited_at'] ) || (int) $member['current_stage_id'] !== $stage ) return new WP_Error( 'scope', 'مرحله یا وضعیت مشتری تغییر کرده است؛ صفحه را تازه کنید.' );
            $valid = $service->validate_destination( $campaign, $stage ); if ( is_wp_error( $valid ) ) return $valid;
            $due = '';
            if ( $button['followup'] ) {
                $d = KERP_Helpers_Date::jalali_to_gregorian( str_replace( '/', '-', KERP_Helpers_Format::sanitize_numbers( $date ) ) );
                $t = KERP_Helpers_Format::sanitize_numbers( $time );
                if ( ! $d || ! preg_match( '/^(?:[01][0-9]|2[0-3]):[0-5][0-9]$/D', $t ) || ( $due = $d . ' ' . $t . ':00' ) <= current_time( 'mysql' ) ) return new WP_Error( 'date', 'تاریخ شمسی و ساعت آینده را برای پیگیری وارد کنید.' );
            }
            $product = $button['product_id'] ? self::product( $button['product_id'] ) : FALSE;
            if ( $button['product_id'] && ! $product ) return new WP_Error( 'product', 'محصول در دسترس یا قابل خرید نیست.' );
            if ( $button['course_id'] && ( ! function_exists( 'ld_update_course_access' ) || ! function_exists( 'sfwd_lms_has_access' ) || get_post_status( $button['course_id'] ) !== 'publish' || get_post_type( $button['course_id'] ) !== 'sfwd-courses' ) ) return new WP_Error( 'course', 'دوره لرندش در دسترس نیست.' );
            if ( $button['transition'] === 'next' ) {
                $passed = FALSE; $next = FALSE;
                foreach ( $service->get_stages( $campaign ) as $s ) { if ( $passed ) { $next = TRUE; break; } if ( (int) $s['id'] === $stage ) $passed = TRUE; }
                if ( ! $next ) return new WP_Error( 'next', 'مرحله فعال بعدی وجود ندارد.' );
            }
            // A new visit starts after the most recent event in a different stage.
            $events = KERP_Modules_Leads_Module::table( 'events' );
            $visit = (int) $wpdb->get_var( $wpdb->prepare( "SELECT MAX(id) FROM {$events} WHERE membership_id=%d AND stage_id<>%d AND event_type NOT LIKE 'sms_%%'", $member['id'], $stage ) );
            $repeatable = ! $button['product_id'] && ! $button['course_id'] && $button['transition'] === 'stay';
            $state_key = 'kerp_lead_action_' . hash( 'sha256', $member['id'] . ':' . $stage . ':' . $visit . ':' . $key . ( $repeatable ? ':' . $request : '' ) );
            $state = get_option( $state_key, [] );
            if ( ! empty( $state['complete'] ) ) return TRUE;
            if ( ! empty( $state['busy'] ) ) return new WP_Error( 'uncertain', 'نتیجه اجرای قبلی نیاز به بررسی دارد؛ برای جلوگیری از ثبت تکراری، اجرای مجدد متوقف شد. تاریخچه مشتری را بررسی کنید.' );
            if ( isset( $state['revision'] ) && $state['revision'] !== $revision ) return new WP_Error( 'changed', 'این اقدام قبلاً بخشی از عملیات را اجرا کرده است؛ ابتدا نتیجه قبلی را بررسی کنید.' );
            $state['revision'] = $revision;
            foreach ( [ 'followup','course_id','product_id','transition','sms' ] as $effect ) {
                if ( empty( $button[$effect] ) || ( $effect === 'transition' && $button[$effect] === 'stay' ) || isset( $state[$effect] ) ) continue;
                $state['busy'] = $effect;
                if ( ! update_option( $state_key, $state, FALSE ) ) throw new RuntimeException( 'ثبت وضعیت اجرای اقدام ناموفق بود.' );
                $result = TRUE;
                if ( $effect === 'followup' ) $result = KERP_Modules_Followups_Module::instance()->save( [ 'customer_id'=>$user, 'assignee_id'=>(int) $member['owner_id'] ?: get_current_user_id(), 'type_key'=>'phone', 'title'=>$button['label'], 'description'=>wp_kses_post( $note ), 'due_at'=>$due, 'priority'=>'normal', 'status'=>'pending', 'metadata'=>[ 'source_key'=>$state_key, 'campaign_id'=>$campaign, 'stage_id'=>$stage ] ] );
                if ( $effect === 'followup' && ! is_wp_error( $result ) && $result ) {
                    $event = $service->add_event( $user, $campaign, (int) $member['id'], $stage, 'no_answer', 'ثبت پیگیری با اقدام «' . $button['label'] . '»', [ 'followup_id'=>$result, 'due_at'=>$due, 'note'=>wp_kses_post( $note ), 'note_format'=>'html' ] );
                    if ( ! $event || ( empty( $button['sms'] ) && ! KERP_Modules_Leads_SMS::enqueue( $event, $user, $campaign, $stage, 'no_answer' ) ) ) $result = new WP_Error( 'sms', 'پیگیری ساخته شد اما ثبت تاریخچه یا صف پیامک ناموفق بود.' );
                }
                if ( $effect === 'course_id' ) $result = sfwd_lms_has_access( $button['course_id'], $user ) ? TRUE : ld_update_course_access( $user, $button['course_id'], FALSE );
                if ( $effect === 'product_id' ) {
                    $price = (float) $product->get_price();
                    $result = KERP_Modules_Orders_Module::instance()->save( [ 'customer_id'=>$user, '_kerp_payment_flow'=>TRUE, 'items'=>[ [ 'product_id'=>$button['product_id'], 'quantity'=>1, 'unit_price'=>$price, 'subtotal'=>$price, 'line_total'=>$price, 'off_percent'=>0 ] ], 'cashier_note'=>'اقدام مسیر فروش: ' . $button['label'] ] );
                }
                if ( $effect === 'transition' ) $result = $button[$effect] === 'exit' ? $service->exit_pipeline( $user, $campaign, $note, $stage, empty( $button['sms'] ) ) : $service->advance_stage( $user, $campaign, [ 'expected_stage_id'=>$stage, 'event_id'=>$state_key, 'note'=>$note ] );
                if ( $effect === 'sms' ) $result = KERP_Modules_Leads_SMS::enqueue_button( $user, $campaign, $stage, (int) $member['id'], $button, $state_key );
                if ( is_wp_error( $result ) || ! $result ) {
                    $message = is_wp_error( $result ) ? $result->get_error_message() : 'عملیات انجام نشد.';
                    $service->add_event( $user, $campaign, (int) $member['id'], $stage, 'stage_action_failed', 'خطا در اقدام «' . $button['label'] . '»', [ 'effect'=>$effect, 'error'=>$message, 'results'=>$state ] );
                    return new WP_Error( 'partial', $message . ' ممکن است عملیات قبلی انجام شده باشد؛ تاریخچه را بررسی کنید. اجرای تکراری مسدود شده است.' );
                }
                $state[$effect] = $result; unset( $state['busy'] );
                if ( ! update_option( $state_key, $state, FALSE ) ) throw new RuntimeException( 'نتیجه عملیات ذخیره نشد؛ اجرای مجدد نیاز به بررسی دارد.' );
                if ( ! $service->add_event( $user, $campaign, (int) $member['id'], $stage, 'stage_action_effect', 'اقدام «' . $button['label'] . '»', [ 'effect'=>$effect, 'result'=>$result, 'course_id'=>$button['course_id'], 'product_id'=>$button['product_id'] ] ) ) throw new RuntimeException( 'عملیات اجرا شد اما ثبت تاریخچه ناموفق بود.' );
            }
            $state['complete'] = TRUE;
            if ( ! update_option( $state_key, $state, FALSE ) ) throw new RuntimeException( 'ثبت تکمیل اقدام ناموفق بود.' );
            return TRUE;
        } catch ( Throwable $e ) { return new WP_Error( 'action', $e->getMessage() ); }
        finally { $wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $lock ) ); }
    }
    public static function revision( array $button ): string { return hash( 'sha256', wp_json_encode( $button ) ); }
}
