<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Customers_Notes_Query {
	private static ?self $instance = NULL;
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		return self::$instance;
	}
	private function __construct() {}
	private function __clone() {}
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	public function get_by_id( int $note_id ): ?array {
		global $wpdb;
		$note_id = absint( $note_id );
		if ( ! $note_id ) {
			return NULL;
		}
		$row = $wpdb->get_row(
			$wpdb->prepare(
				'SELECT * FROM ' . KERP_Modules_Customers_Notes::table() . ' WHERE id = %d LIMIT 1',
				$note_id
			),
			ARRAY_A
		);
		return is_array( $row ) ? $this->normalize( $row ) : NULL;
	}
	public function get_by_customer( int $customer_id, array $args = [] ): array {
		global $wpdb;
		$customer_id = absint( $customer_id );
		if ( ! $customer_id ) {
			return [];
		}
		$args = wp_parse_args(
			$args,
			[
				'pinned_only' => FALSE,
				'type'        => '',
				'limit'       => 0,
			]
		);
		$where  = [ 'customer_id = %d' ];
		$values = [ $customer_id ];
		if ( ! empty( $args['pinned_only'] ) ) {
			$where[] = 'is_pinned = 1';
		}
		$type = sanitize_key( (string) $args['type'] );
		if ( $type !== '' ) {
			$where[]  = 'type = %s';
			$values[] = $type;
		}
		$sql = 'SELECT * FROM ' . KERP_Modules_Customers_Notes::table()
		       . ' WHERE ' . implode( ' AND ', $where )
		       . ' ORDER BY is_pinned DESC, created_at DESC, id DESC';
		$limit = absint( $args['limit'] );
		if ( $limit ) {
			$sql     .= ' LIMIT %d';
			$values[] = $limit;
		}
		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $values ), ARRAY_A );
		if ( ! is_array( $rows ) ) {
			return [];
		}
		$notes_service = KERP_Modules_Customers_Notes::instance();
		$notes         = [];
		foreach ( $rows as $row ) {
			$note = $this->normalize( $row );
			if ( ! $notes_service->can_view_note( $note ) ) {
				continue;
			}
			$notes[] = $note;
		}
		return apply_filters( 'kerp_customer_notes_results', $notes, $customer_id, $args );
	}
	public function get_pinned_by_customer( int $customer_id, int $limit = 5 ): array {
		return $this->get_by_customer(
			$customer_id,
			[
				'pinned_only' => TRUE,
				'limit'       => max( 1, min( 20, $limit ) ),
			]
		);
	}
	private function normalize( array $row ): array {
		return [
			'id'          => absint( $row['id'] ?? 0 ),
			'customer_id' => absint( $row['customer_id'] ?? 0 ),
			'type'        => sanitize_key( (string) ( $row['type'] ?? 'general' ) ),
			'content'     => (string) ( $row['content'] ?? '' ),
			'is_pinned'   => ! empty( $row['is_pinned'] ) ? 1 : 0,
			'visibility'  => sanitize_key( (string) ( $row['visibility'] ?? KERP_Modules_Customers_Notes::VISIBILITY_ALL_STAFF ) ),
			'created_by'  => absint( $row['created_by'] ?? 0 ),
			'updated_by'  => absint( $row['updated_by'] ?? 0 ),
			'created_at'  => sanitize_text_field( (string) ( $row['created_at'] ?? '' ) ),
			'updated_at'  => sanitize_text_field( (string) ( $row['updated_at'] ?? '' ) ),
		];
	}
}
