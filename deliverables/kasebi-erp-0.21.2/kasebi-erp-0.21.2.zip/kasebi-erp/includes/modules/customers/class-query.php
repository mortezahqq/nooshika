<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Customers_Query {
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public function find( array $args = [] ): array {
		$settings = KERP_Modules_Customers_Settings::instance();
		$defaults = [
			'per_page'    => (int) $settings->get( 'default_per_page', 20 ),
			'page_number' => 1,
			'search'      => '',
			'roles'       => (array) $settings->get(
				'customer_roles',
				[ 'customer', 'subscriber' ]
			),
			'include'     => [],
			'exclude'     => [],
			'registered'  => [
				'from' => '',
				'to'   => '',
			],
			'city'        => '',
			'state'       => '',
			'gender'      => '',
			'owner_id'    => 0,
			'label'       => '',
			'tag'         => '',
			'source'      => '',
			'orderby'     => 'registered',
			'order'       => 'DESC',
			'count_total' => TRUE,
		];
		$args     = array_filter(
			$args,
			function( $value, $key ) {
				return str_starts_with( (string) $key, 'first_touch_' ) || ( $value !== 0 && $value !== '0' );
			},
			ARRAY_FILTER_USE_BOTH
		);
		
		$args  = wp_parse_args( $args, $defaults );
		$scope = kerp_list_scope( 'customers' );
		
		if ( $scope === 'none' ) {
			return [
				'items'        => [],
				'total'        => 0,
				'per_page'     => max( 1, min( 500, absint( $args['per_page'] ) ) ),
				'page_number'  => max( 1, absint( $args['page_number'] ) ),
				'total_pages'  => 0,
				'query_args'   => [],
				'request_args' => $args,
			];
		}
		
		if ( $scope === 'own' ) {
			$args['owner_id'] = get_current_user_id();
		}
		
		$args = apply_filters( 'kerp_customers_query_args', $args );
		
		$page_number = max( 1, absint( $args['page_number'] ) );
		$per_page    = max( 1, min( 500, absint( $args['per_page'] ) ) );
		$roles       = is_array( $args['roles'] ) ? $args['roles'] : [ $args['roles'] ];
		$roles       = array_values( array_filter( array_map( 'sanitize_key', $roles ) ) );
		
		$query_args = [
			'number'      => $per_page,
			'offset'      => ( $page_number - 1 ) * $per_page,
			'count_total' => (bool) $args['count_total'],
			'orderby'     => sanitize_key( (string) $args['orderby'] ),
			'order'       => strtoupper( (string) $args['order'] ) === 'ASC' ? 'ASC' : 'DESC',
			'role__in'    => $roles,
		];
		
		$include = array_values( array_filter( array_map( 'absint', (array) $args['include'] ) ) );
		$exclude = array_values( array_filter( array_map( 'absint', (array) $args['exclude'] ) ) );
		
		if ( ! empty( $include ) ) {
			$query_args['include'] = $include;
		}
		
		if ( ! empty( $exclude ) ) {
			$query_args['exclude'] = $exclude;
		}
		
		$search = sanitize_text_field( (string) $args['search'] );
		if ( $search !== '' ) {
			$query_args['search']         = '*' . $search . '*';
			$query_args['search_columns'] = [ 'ID', 'user_login', 'user_email', 'display_name', 'user_nicename' ];
		}
		
		$date_query = $this->build_date_query( $args );
		if ( ! empty( $date_query ) ) {
			$query_args['date_query'] = $date_query;
		}
		
		$meta_query = $this->build_meta_query( $args );
		if ( ! empty( $meta_query ) ) {
			$query_args['meta_query'] = $meta_query;
		}
		
		$query_args = apply_filters( 'kerp_customers_wp_user_query_args', $query_args, $args );
		$first_touch_where = $this->build_first_touch_where( $args );
		$query = new WP_User_Query();
		$filter = static function( $candidate ) use ( $query, $first_touch_where ): void {
			if ( $candidate === $query && $first_touch_where !== '' ) {
				$candidate->query_where .= ' AND ' . $first_touch_where;
			}
		};
		add_action( 'pre_user_query', $filter );
		try {
			$query->prepare_query( $query_args );
			if ( ! empty( $args['customers_dashboard_sql'] ) ) {
				global $wpdb;
				// Compile the established role/meta/scope filters without loading users.
				return [ 'sql' => "SELECT DISTINCT {$wpdb->users}.ID, {$wpdb->users}.user_registered {$query->query_from} {$query->query_where}" ];
			}
			$query->query();
		} finally {
			remove_action( 'pre_user_query', $filter );
		}
		$users      = $query->get_results();
		$total      = (int) $query->get_total();
		
		$result = [
			'items'        => is_array( $users ) ? $users : [],
			'total'        => $total,
			'per_page'     => $per_page,
			'page_number'  => $page_number,
			'total_pages'  => $per_page > 0 ? (int) ceil( $total / $per_page ) : 0,
			'query_args'   => $query_args,
			'request_args' => $args,
		];
		
		return apply_filters( 'kerp_customers_query_results', $result, $args, $query );
	}
	
	private function build_first_touch_where( array &$args ): string {
		global $wpdb;
		$conditions = [];
		$active = [];
		$fields = KERP_Modules_Customers_List_Table::instance()->get_first_touch_fields();
		foreach ( $fields as $key => $field ) {
			$value = $args[ $key ] ?? '';
			$value = is_scalar( $value ) ? sanitize_text_field( (string) $value ) : '';
			$args[ $key ] = $value;
			if ( $value === '' || $value === '0' ) { continue; }
			if ( $key === 'first_touch_type' && $value === '__unknown__' ) {
				$conditions[] = "COALESCE(ft.touch_type, '') IN ('', 'unknown')";
				continue;
			}
			if ( $key === 'first_touch_type' && $value === '__products__' ) {
				$conditions[] = "ft.touch_type IN ('landing_order', 'site_registration')";
				continue;
			}
			$exact = TRUE; // First-touch filters select a stored value, not a substring.
			$conditions[] = $wpdb->prepare( 'ft.' . $field['column'] . ( $exact ? ' = %s' : ' LIKE %s' ), $exact ? $value : '%' . $wpdb->esc_like( $value ) . '%' );
			$active[ $field['legacy'] ] = [ $value, $exact ];
		}
		$type = $args['first_touch_type'];
		$raw_form_choice = $args['first_touch_form_id'] ?? '';
		$dependent = [
			'first_touch_form_id' => 'gravity_form',
			'first_touch_landing_product' => 'landing_order',
			'first_touch_cart_product' => 'site_registration',
		];
		foreach ( $dependent as $key => $parent ) {
			$args[ $key ] = $type === $parent && is_scalar( $args[ $key ] ?? '' ) ? absint( $args[ $key ] ?? 0 ) : 0;
		}
        $parse_choice = static function( $value ): array {
            $value = is_scalar( $value ) ? (string) $value : '';
            if ( preg_match( '/^except:([1-9][0-9]*(?:,[1-9][0-9]*){0,5})$/', $value, $match ) ) {
                return [ array_map( 'absint', explode( ',', $match[1] ) ), TRUE ];
            }
            return [ ctype_digit( $value ) && (int) $value > 0 ? [ (int) $value ] : [], FALSE ];
        };
        [ $form_ids, $form_exclude ] = $parse_choice( $type === 'gravity_form' ? ( $raw_form_choice ?? '' ) : '' );
        $args['first_touch_form_id'] = $form_ids ? ( $form_exclude ? 'except:' . implode( ',', $form_ids ) : $form_ids[0] ) : 0;
        [ $product_ids, $product_exclude ] = $parse_choice( in_array( $type, [ 'landing_order', 'site_registration', '__products__' ], TRUE ) ? ( $args['first_touch_product'] ?? '' ) : '' );
        if ( ! $product_ids ) {
            $old_product = $args['first_touch_landing_product'] ?: $args['first_touch_cart_product'];
            if ( $old_product ) { $product_ids = [ $old_product ]; }
        }
        if ( $form_ids ) {
            $conditions[] = 'ft.form_id > 0 AND ft.form_id ' . ( $form_exclude ? 'NOT IN' : 'IN' ) . ' (' . implode( ',', $form_ids ) . ')';
        }
        if ( $product_ids ) {
            $items_table = KERP_Services_Attribution_First_Touch::items_table();
            $conditions[] = "EXISTS (SELECT 1 FROM {$items_table} fi WHERE fi.first_touch_id = ft.id
                AND ((ft.touch_type = 'landing_order' AND fi.item_kind = 'landing') OR (ft.touch_type = 'site_registration' AND fi.item_kind = 'cart'))
                AND fi.product_id > 0 AND fi.product_id " . ( $product_exclude ? 'NOT IN' : 'IN' ) . ' (' . implode( ',', $product_ids ) . '))';
        }
		if ( ! $conditions ) { return ''; }
		$table = KERP_Services_Attribution_First_Touch::table();
		$match = implode( ' AND ', $conditions );
		$sql = "EXISTS (SELECT 1 FROM {$table} ft WHERE ft.user_id = {$wpdb->users}.ID AND {$match})";
		// Parse legacy arrays rather than matching across serialized field boundaries.
		$legacy_ids = [];
		$known_legacy_ids = [];
		foreach ( KERP_Services_Attribution_First_Touch::instance()->get_legacy_list_data() as $user_id => $data ) {
			if ( $type === '__unknown__' && ! in_array( trim( (string) ( $data['type'] ?? '' ) ), [ '', 'unknown' ], TRUE ) ) {
				$known_legacy_ids[] = absint( $user_id );
				continue;
			}
			$matches = TRUE;
			foreach ( $active as $key => [ $value, $exact ] ) {
				$actual = $data[ $key ] ?? '';
				if ( ! is_scalar( $actual ) || ( $exact ? (string) $actual !== $value : mb_stripos( (string) $actual, $value ) === FALSE ) ) { $matches = FALSE; break; }
			}
            if ( $type === '__products__' && ! in_array( $data['type'] ?? '', [ 'landing_order', 'site_registration' ], TRUE ) ) { continue; }
            $form_id = absint( $data['form_id'] ?? 0 );
            if ( ! $matches || ( $form_ids && ( ! $form_id || in_array( $form_id, $form_ids, TRUE ) === $form_exclude ) ) ) { continue; }
            if ( $product_ids ) {
                $found = FALSE;
                $legacy_items = ( $data['type'] ?? '' ) === 'landing_order' ? 'products' : 'cart_items';
                foreach ( (array) ( $data[ $legacy_items ] ?? [] ) as $item ) {
                    $id = is_array( $item ) ? absint( $item['product_id'] ?? 0 ) : 0;
                    if ( $id > 0 && in_array( $id, $product_ids, TRUE ) !== $product_exclude ) { $found = TRUE; break; }
                }
                if ( ! $found ) { continue; }
            }
			$legacy_ids[] = absint( $user_id );
		}
		if ( $legacy_ids ) {
			$sql .= ' OR (' . "NOT EXISTS (SELECT 1 FROM {$table} ft_current WHERE ft_current.user_id = {$wpdb->users}.ID) AND {$wpdb->users}.ID IN (" . implode( ',', $legacy_ids ) . '))';
		}
		if ( $type === '__unknown__' && ! $active ) {
			$without_known_legacy = $known_legacy_ids ? ' AND ' . $wpdb->users . '.ID NOT IN (' . implode( ',', $known_legacy_ids ) . ')' : '';
			$sql .= " OR (NOT EXISTS (SELECT 1 FROM {$table} ft_current WHERE ft_current.user_id = {$wpdb->users}.ID){$without_known_legacy})";
		}
		return '(' . $sql . ')';
	}
	public static function search_scope( bool $order_creation = FALSE ): string {
		if ( $order_creation && is_user_logged_in() && KERP_App::instance()->current_user_has_access() && kerp_can( 'orders.create', 'action' ) ) {
			return 'all';
		}
		foreach ( [ 'all', 'own' ] as $scope ) {
			if ( kerp_can( 'customers.search.' . $scope, 'action' ) ) {
				return $scope;
			}
		}

		return 'none';
	}

	public function search(
		string $search,
		int $limit = 10,
		int $offset = 0,
		bool $order_creation = FALSE
	): array {
		global $wpdb;
		KERP_Modules_Customers_Search_Timing::mark( 'query_start' );
		
		$search = trim(
			sanitize_text_field( $search )
		);
		
		$limit  = max( 1, min( 50, $limit ) );
		$offset = max( 0, $offset );
		
		if ( $search === '' ) {
			return [
				'items'  => [],
				'total'  => 0,
				'limit'  => $limit,
				'offset' => $offset,
				'search' => '',
			];
		}
		
		$roles = (array) KERP_Modules_Customers_Settings::instance()->get( 'customer_roles', [ 'customer', 'subscriber' ] );
		$roles = array_values( array_filter( array_map( 'sanitize_key', $roles ) ) );
		$roles = (array) apply_filters( 'kerp_customers_search_roles', $roles, $search );
		$index = KERP_Modules_Customers_Search_Index::instance();
		$scope = self::search_scope( $order_creation );
		$user_ids = [];
		$total = 0;
		if ( $scope !== 'none' && $index->ready() ) {
			$table = KERP_Modules_Customers_Search_Index::table();
			$where = '1 = 1';
			$scope_parameters = [];
			if ( $roles ) {
				$role_conditions = [];
				foreach ( $roles as $role ) {
					$role_conditions[] = 'roles LIKE %s';
					$scope_parameters[] = '%"' . $wpdb->esc_like( (string) $role ) . '"%';
				}
				$where .= ' AND (' . implode( ' OR ', $role_conditions ) . ')';
			}
			if ( $scope === 'own' ) {
				$where .= ' AND owner_id = %d';
				$scope_parameters[] = get_current_user_id();
			}
			$numeric_search = KERP_Helpers_Format::sanitize_numbers( $search );
			$normalized_phone = $this->normalize_phone_search( $numeric_search );
			$is_phone_search = preg_match( '/^[0-9+().\s-]+$/', $numeric_search ) === 1
				&& strlen( preg_replace( '/[^0-9]/', '', $numeric_search ) ) > 0;
			if ( $is_phone_search ) {
				$phone_like = '%' . $wpdb->esc_like( $normalized_phone !== '' ? $normalized_phone : $search ) . '%';
				$match = '(phone LIKE %s OR billing_phone LIKE %s)';
				$match_parameters = [ $phone_like, $phone_like ];
			} else {
				$name = preg_replace( '/\s+/u', ' ', $search ) ?? $search;
				$names = function_exists( 'separate_first_last_from_name' )
					? separate_first_last_from_name( $name )
					: array_combine( [ 'first', 'last' ], array_pad( explode( ' ', $name, 2 ), 2, '' ) );
				$first_like = '%' . $wpdb->esc_like( (string) $names['first'] ) . '%';
				if ( (string) $names['last'] !== '' ) {
					$match = '(first_name LIKE %s AND last_name LIKE %s)';
					$match_parameters = [ $first_like, '%' . $wpdb->esc_like( (string) $names['last'] ) . '%' ];
				} else {
					$match = '(first_name LIKE %s OR last_name LIKE %s)';
					$match_parameters = [ $first_like, $first_like ];
				}
			}
			$text_like = '%' . $wpdb->esc_like( $search ) . '%';
			$sources = [
				[ $match, $match_parameters, $is_phone_search ? 'phone' : 'name' ],
				[ '(user_id = %d OR display_name LIKE %s OR user_login LIKE %s OR user_email LIKE %s)',
					[ absint( $normalized_phone ), $text_like, $text_like, $text_like ], 'fallback' ],
			];
			foreach ( $sources as [ $match, $match_parameters, $source ] ) {
				$parameters = array_merge( $match_parameters, $scope_parameters );
				$base_sql = "FROM {$table} WHERE {$match} AND {$where}";
				$list_query = $wpdb->prepare(
					"SELECT user_id {$base_sql} ORDER BY user_id ASC LIMIT %d OFFSET %d",
					...array_merge( $parameters, [ $limit, $offset ] )
				);
				$started = microtime( TRUE );
				$user_ids = array_map( 'absint', (array) $wpdb->get_col( $list_query ) );
				KERP_Modules_Customers_Search_Timing::mark( 'db_search_' . $source );
				KERP_Modules_Customers_Search_Timing::explain_slow_query( $list_query, ( microtime( TRUE ) - $started ) * 1000 );
				if ( count( $user_ids ) < $limit && ( $offset === 0 || $user_ids ) ) {
					$total = $offset + count( $user_ids );
				} else {
					$total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) {$base_sql}", ...$parameters ) );
				}
				KERP_Modules_Customers_Search_Timing::mark( 'db_count_' . $source );
				if ( $total > 0 ) { break; }
			}
		}

		$users = [];
		
		if ( ! empty( $user_ids ) ) {
			update_meta_cache( 'user', $user_ids );
			KERP_Modules_Customers_Search_Timing::mark( 'load_user_meta' );
			
			$users = get_users(
				[
					'include' => $user_ids,
					'orderby' => 'include',
				]
			);
		}
		
		KERP_Modules_Customers_Search_Timing::mark( 'load_users' );
		
		$result = [
			'items'  => is_array( $users ) ? $users : [],
			'total'  => $total,
			'limit'  => $limit,
			'offset' => $offset,
			'search' => $search,
		];
		
		$result = apply_filters(
			'kerp_customers_search_results',
			$result,
			$search,
			[
				'limit'  => $limit,
				'offset' => $offset,
				'roles'  => $roles,
			]
		);
		KERP_Modules_Customers_Search_Timing::mark( 'search_result_filters' );
		
		return $result;
	}
	
	public function get_customer_phone( int $customer_id ): string {
		$customer_id = absint( $customer_id );
		
		if ( ! $customer_id ) {
			return '';
		}
		
		$phone_meta_key = (string) KERP_Modules_Customers_Settings::instance()
		                                                          ->get(
			                                                          'phone_meta_key',
			                                                          'nooshika_phone_num'
		                                                          );
		
		$phone = get_user_meta(
			$customer_id,
			$phone_meta_key,
			TRUE
		);
		
		if ( $phone === '' ) {
			$phone = get_user_meta(
				$customer_id,
				'billing_phone',
				TRUE
			);
		}
		
		return sanitize_text_field(
			(string) $phone
		);
	}
	
	public static function can_select_for_order( int $customer_id ): bool {
		return $customer_id > 0 && is_user_logged_in() && KERP_App::instance()->current_user_has_access()
			&& kerp_can( 'orders.create', 'action' ) && get_userdata( $customer_id ) instanceof WP_User;
	}

	public function get_customer( int $customer_id ): ?WP_User {
		$customer_id = absint( $customer_id );
		
		if ( ! $customer_id ) {
			return NULL;
		}
		
		$user = get_userdata( $customer_id );
		
		if ( ! $user instanceof WP_User ) {
			return NULL;
		}
		
		return apply_filters( 'kerp_customers_get_customer', $user, $customer_id );
	}
	
	private function build_date_query( array $args ): array {
		$from = $this->sanitize_date( (string) $args['registered']['from'] );
		$to   = $this->sanitize_date( (string) $args['registered']['to'] );
		
		if ( $from === '' && $to === '' ) {
			return [];
		}
		
		$query = [
			'inclusive' => TRUE,
		];
		
		if ( $from !== '' ) {
			$query['after'] = $from . ' 00:00:00';
		}
		
		if ( $to !== '' ) {
			$query['before'] = $to . ' 23:59:59';
		}
		
		return [ $query ];
	}
	
	private function build_meta_query( array $args ): array {
		$settings   = KERP_Modules_Customers_Settings::instance();
		$taxonomies = KERP_Modules_Customers_Taxonomies::instance();
		$meta_query = [ 'relation' => 'AND' ];
		
		$map = [
			'city'     => 'billing_city',
			'state'    => 'billing_state',
			'gender'   => 'user',
			'owner_id' => (string) $settings->get( 'owner_meta_key', 'kerp_customer_owner_id' ),
			'source'   => $taxonomies->get_meta_key( KERP_Modules_Customers_Taxonomies::TYPE_SOURCE ),
		];
		
		foreach ( $map as $arg_key => $meta_key ) {
			$value = $args[ $arg_key ] ?? '';
			
			if ( $value === '' || $value === 0 || $value === '0' ) {
				continue;
			}
			
			if ( $arg_key === 'owner_id' ) {
				$value = absint( $value );
			} elseif ( $arg_key === 'gender' ) {
				$value = sanitize_key( (string) $value );
				
				if ( ! in_array( $value, [ 'male', 'female', 'other' ], TRUE ) ) {
					continue;
				}
			} else {
				$value = sanitize_text_field( (string) $value );
			}
			
			$meta_query[] = [
				'key'     => $meta_key,
				'value'   => $value,
				'compare' => '=',
			];
		}
		
		foreach (
			[
				'label' => KERP_Modules_Customers_Taxonomies::TYPE_LABEL,
				'tag'   => KERP_Modules_Customers_Taxonomies::TYPE_TAG,
			] as $arg_key => $taxonomy_type
		) {
			$value = sanitize_key( (string) ( $args[ $arg_key ] ?? '' ) );
			if ( $value === '' ) {
				continue;
			}
			
			$meta_query[] = [
				'key'     => $taxonomies->get_meta_key( $taxonomy_type ),
				'value'   => '"' . $value . '"',
				'compare' => 'LIKE',
			];
		}
		
		$custom_fields = KERP_Modules_Customers_Fields::instance()->get_all( TRUE );
		foreach ( $custom_fields as $field_key => $field ) {
			if ( empty( $field['filterable'] ) || ! array_key_exists( $field_key, $args ) ) {
				continue;
			}
			
			$value = $args[ $field_key ];
			if ( $value === '' || $value === NULL ) {
				continue;
			}
			
			$meta_query[] = [
				'key'     => $field['meta_key'],
				'value'   => is_scalar( $value ) ? sanitize_text_field( (string) $value ) : '',
				'compare' => '=',
			];
		}
		
		return count( $meta_query ) > 1 ? $meta_query : [];
	}
	
	private function normalize_phone_search( string $phone ): string {
		if ( function_exists( 'nooshika_sanitize_numbers' ) ) {
			$phone = (string) nooshika_sanitize_numbers( $phone );
		}
		$phone = preg_replace(
			         '/[^0-9+]/',
			         '',
			         $phone
		         ) ?? '';
		
		if (
			$phone !== '' &&
			function_exists( 'remove_zero_from_phone' )
		) {
			$phone = (string) remove_zero_from_phone( $phone );
		}
		
		return $phone;
	}
	
	private function sanitize_date( string $date ): string {
		$date = trim( sanitize_text_field( $date ) );
		if ( $date === '' ) {
			return '';
		}
		$date      = nooshika_jalali_to_gregorian( $date );
		$timestamp = strtotime( $date );
		
		return $timestamp ? gmdate( 'Y-m-d', $timestamp ) : '';
	}
	
}
