<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Customers_Profile {
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public function get_context( int $customer_id, string $requested_tab = '' ): array {
		$customer = KERP_Modules_Customers_Query::instance()->get_customer( $customer_id );
		
		if ( ! $customer instanceof WP_User ) {
			return [
				'customer'   => NULL,
				'tabs'       => [],
				'active_tab' => '',
				'fields'     => [],
			];
		}
		
		$tabs       = $this->get_tabs( $customer );
		$active_tab = $this->resolve_active_tab( $requested_tab, $tabs );
		
		return apply_filters(
			'kerp_customer_profile_context',
			[
				'customer'    => $customer,
				'customer_id' => $customer->ID,
				'tabs'        => $tabs,
				'active_tab'  => $active_tab,
				'main_fields' => KERP_Modules_Customers_Fields::instance()->get_main_profile_fields( $customer ),
				'fields'      => KERP_Modules_Customers_Fields::instance()->get_profile_fields( $customer->ID ),
				'taxonomies'  => [
					'labels' => KERP_Modules_Customers_Taxonomies::instance()->get_customer_terms(
						$customer->ID,
						KERP_Modules_Customers_Taxonomies::TYPE_LABEL
					),
					'tags'   => KERP_Modules_Customers_Taxonomies::instance()->get_customer_terms(
						$customer->ID,
						KERP_Modules_Customers_Taxonomies::TYPE_TAG
					),
					'source' => KERP_Modules_Customers_Taxonomies::instance()->get_customer_terms(
						$customer->ID,
						KERP_Modules_Customers_Taxonomies::TYPE_SOURCE
					),
				],
			],
			$customer
		);
	}
	
	public function get_tabs( WP_User|int $customer ): array {
		$customer = is_int( $customer ) ? get_userdata( $customer ) : $customer;
		
		if ( ! $customer instanceof WP_User ) {
			return [];
		}
		
		$tabs = [
			'profile' => [
				'key'        => 'profile',
				'title'      => __( 'پروفایل', 'kasebi-erp' ),
				'icon'       => 'ni ni-user',
				'order'      => 10,
				'permission' => 'customers',
				'action'     => 'view',
				'template'   => 'modules/customers/tabs/profile.php',
			],
		];
		
		$tabs = apply_filters( 'kerp_customer_profile_tabs', $tabs, $customer->ID, $customer );
		
		$tabs = array_filter(
			$tabs,
			function( array $tab ): bool {
				$permission = (string) ( $tab['permission'] ?? '' );
				$action     = (string) ( $tab['action'] ?? 'view' );
				
				if ( $permission === '' || ! function_exists( 'kerp_can' ) ) {
					return TRUE;
				}
				
				return kerp_can( $permission, $action );
			}
		);
		
		uasort(
			$tabs,
			static fn( array $first, array $second ): int => (int) ( $first['order'] ?? 100 ) <=> (int) ( $second['order'] ?? 100 )
		);
		
		return $tabs;
	}

	/**
	 * Return the shared groups used by customer profile modules.
	 */
	public function get_tab_groups(): array {
		$groups = [
			'customer-information' => [
				'key'   => 'customer-information',
				'title' => __( 'اطلاعات مشتری', 'kasebi-erp' ),
				'icon'  => 'ni ni-user-list',
				'order' => 20,
			],
			'crm'                  => [
				'key'   => 'crm',
				'title' => __( 'CRM و ارتباطات', 'kasebi-erp' ),
				'icon'  => 'ni ni-growth',
				'order' => 30,
			],
			'finance-loyalty'      => [
				'key'   => 'finance-loyalty',
				'title' => __( 'مالی و وفاداری', 'kasebi-erp' ),
				'icon'  => 'ni ni-wallet',
				'order' => 40,
			],
			'planning-learning'    => [
				'key'   => 'planning-learning',
				'title' => __( 'برنامه‌ریزی و آموزش', 'kasebi-erp' ),
				'icon'  => 'ni ni-calendar-check',
				'order' => 50,
			],
		];

		$groups = apply_filters( 'kerp_customer_profile_tab_groups', $groups );

		return is_array( $groups ) ? $groups : [];
	}

	/**
	 * Build direct links and grouped toggle rows for the customer profile menu.
	 */
	public function get_navigation( array $tabs, string $active_tab = '' ): array {
		$registered_groups = $this->get_tab_groups();
		$active_tab        = sanitize_key( $active_tab );
		$rows              = [];

		foreach ( $tabs as $fallback_key => $tab ) {
			if ( ! is_array( $tab ) ) {
				continue;
			}

			$tab_key = sanitize_key( (string) ( $tab['key'] ?? $fallback_key ) );

			if ( $tab_key === '' ) {
				continue;
			}

			$tab['key']    = $tab_key;
			$tab['active'] = $tab_key === $active_tab;
			$group_value   = $tab['group'] ?? '';
			$group         = [];

			if ( is_string( $group_value ) ) {
				$group_key = sanitize_key( $group_value );
				$group     = isset( $registered_groups[ $group_key ] ) && is_array( $registered_groups[ $group_key ] )
					? $registered_groups[ $group_key ]
					: [];
			} elseif ( is_array( $group_value ) ) {
				$group_key = sanitize_key( (string) ( $group_value['key'] ?? '' ) );
				$defaults  = isset( $registered_groups[ $group_key ] ) && is_array( $registered_groups[ $group_key ] )
					? $registered_groups[ $group_key ]
					: [];
				$group     = array_merge( $defaults, $group_value );
			}

			$group_key = sanitize_key( (string) ( $group['key'] ?? '' ) );

			if ( $group_key === '' ) {
				$rows[ 'tab:' . $tab_key ] = [
					'type'   => 'tab',
					'key'    => $tab_key,
					'title'  => sanitize_text_field( (string) ( $tab['title'] ?? $tab_key ) ),
					'order'  => (int) ( $tab['order'] ?? 100 ),
					'active' => ! empty( $tab['active'] ),
					'tab'    => $tab,
				];

				continue;
			}

			$row_key = 'group:' . $group_key;

			if ( ! isset( $rows[ $row_key ] ) ) {
				$rows[ $row_key ] = [
					'type'     => 'group',
					'key'      => $group_key,
					'title'    => sanitize_text_field( (string) ( $group['title'] ?? $group_key ) ),
					'icon'     => (string) ( $group['icon'] ?? 'ni ni-folder-list' ),
					'order'    => (int) ( $group['order'] ?? 100 ),
					'active'   => FALSE,
					'children' => [],
				];
			}

			$rows[ $row_key ]['children'][ $tab_key ] = $tab;

			if ( ! empty( $tab['active'] ) ) {
				$rows[ $row_key ]['active'] = TRUE;
			}
		}

		foreach ( $rows as &$row ) {
			if ( ( $row['type'] ?? '' ) !== 'group' ) {
				continue;
			}

			$this->sort_navigation_items( $row['children'] );
		}
		unset( $row );

		$this->sort_navigation_items( $rows );
		$rows = apply_filters( 'kerp_customer_profile_navigation', $rows, $tabs, $active_tab );

		return is_array( $rows ) ? $rows : [];
	}
	
	public function render_tab( string $tab_key, int $customer_id, array $context = [] ): void {
		$customer = KERP_Modules_Customers_Query::instance()->get_customer( $customer_id );
		
		if ( ! $customer instanceof WP_User ) {
			return;
		}
		
		$tabs = $this->get_tabs( $customer );
		$tab  = $tabs[ sanitize_key( $tab_key ) ] ?? NULL;
		
		if ( ! is_array( $tab ) ) {
			return;
		}
		
		$args = array_merge(
			$context,
			[
				'customer'    => $customer,
				'customer_id' => $customer->ID,
				'tab'         => $tab,
			]
		);
		
		if ( ! empty( $tab['callback'] ) && is_callable( $tab['callback'] ) ) {
			call_user_func( $tab['callback'], $args );
			
			return;
		}
		
		if ( ! empty( $tab['template'] ) ) {
			KERP_Helpers_Template::render_template( (string) $tab['template'], $args );
			
			return;
		}
		
		do_action(
			'kerp_customer_profile_tab_' . sanitize_key( (string) $tab['key'] ),
			$customer->ID,
			$customer,
			$tab,
			$args
		);
	}
	
	private function resolve_active_tab( string $requested_tab, array $tabs ): string {
		$requested_tab = sanitize_key( $requested_tab );
		
		if ( $requested_tab !== '' && isset( $tabs[ $requested_tab ] ) ) {
			return $requested_tab;
		}
		
		return (string) ( array_key_first( $tabs ) ?? '' );
	}

	private function sort_navigation_items( array &$items ): void {
		uasort(
			$items,
			static function( array $first, array $second ): int {
				$order = (int) ( $first['order'] ?? 100 ) <=> (int) ( $second['order'] ?? 100 );

				if ( $order !== 0 ) {
					return $order;
				}

				return strcmp(
					(string) ( $first['title'] ?? '' ),
					(string) ( $second['title'] ?? '' )
				);
			}
		);
	}
	
}
