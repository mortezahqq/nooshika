<?php

defined( 'ABSPATH' ) || exit;

/** Materialized picker data; WordPress remains the source of truth. */
final class KERP_Modules_Customers_Search_Index {

	private const VERSION = '1';
	private const STATE = 'kerp_customers_search_index_state';
	private const CRON = 'kerp_customers_search_index_batch';
	private static ?self $instance = NULL;

	public static function instance(): self { return self::$instance ??= new self(); }
	public static function table(): string { global $wpdb; return $wpdb->prefix . 'kerp_customers_search_index'; }

	private function __construct() {
		add_action( 'init', [ $this, 'initialize' ], 6 );
		add_action( self::CRON, [ $this, 'build_batch' ] );
		add_action( 'user_register', [ $this, 'sync' ], 100 );
		add_action( 'profile_update', [ $this, 'sync' ], 100 );
		foreach ( [ 'added_user_meta', 'updated_user_meta', 'deleted_user_meta' ] as $hook ) {
			add_action( $hook, [ $this, 'meta_changed' ], 100, 4 );
		}
		add_action( 'deleted_user', [ $this, 'remove' ] );
		add_action( 'remove_user_from_blog', [ $this, 'remove_from_blog' ], 100, 2 );
		add_action( 'update_option_' . KERP_Modules_Customers_Settings::OPTION_NAME, [ $this, 'settings_changed' ], 20, 2 );
	}

	public function initialize(): void {
		global $wpdb;
		if ( get_option( 'kerp_customers_search_index_version' ) !== self::VERSION ) {
			require_once ABSPATH . 'wp-admin/includes/upgrade.php';
			$table = self::table();
			$collate = $wpdb->get_charset_collate();
			dbDelta( "CREATE TABLE {$table} (
				user_id bigint(20) unsigned NOT NULL,
				first_name text NOT NULL,
				last_name text NOT NULL,
				phone text NOT NULL,
				billing_phone text NOT NULL,
				display_name varchar(250) NOT NULL DEFAULT '',
				user_login varchar(60) NOT NULL DEFAULT '',
				user_email varchar(100) NOT NULL DEFAULT '',
				roles longtext NOT NULL,
				owner_id bigint(20) unsigned NOT NULL DEFAULT 0,
				PRIMARY KEY  (user_id),
				KEY owner_user (owner_id,user_id)
			) {$collate};" );
			if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $table ) ) ) !== $table ) { return; }
			update_option( 'kerp_customers_search_index_version', self::VERSION, FALSE );
			$this->restart();
		}
		if ( ! get_option( self::STATE ) ) { $this->restart(); }
		$is_manual_request = ( $_POST['action'] ?? '' ) === 'customers_rebuild_search_index';
		if ( ! $is_manual_request && ! $this->ready() && ( get_option( self::STATE, [] )['mode'] ?? '' ) !== 'manual' ) { $this->build_batch(); }
	}

	public function ready(): bool { return ! empty( get_option( self::STATE, [] )['ready'] ); }

	public function restart( bool $background = TRUE ): void {
		update_option( self::STATE, [ 'cursor' => 0, 'ready' => FALSE, 'generation' => wp_generate_uuid4(), 'mode' => $background ? 'background' : 'manual' ], FALSE );
		if ( $background ) { $this->schedule(); }
	}

	private function schedule(): void {
		if ( ( get_option( self::STATE, [] )['mode'] ?? '' ) === 'manual' ) { return; }
		if ( ! wp_next_scheduled( self::CRON ) ) { wp_schedule_single_event( time() + 10, self::CRON ); }
	}

	public function status(): array {
		global $wpdb;
		$state = get_option( self::STATE, [] );
		$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->users}" );
		$remaining = ! empty( $state['ready'] ) ? 0 : (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->users} WHERE ID > %d", (int) ( $state['cursor'] ?? 0 ) ) );
		$processed = max( 0, $total - $remaining );
		return [ 'total' => $total, 'remaining' => $remaining, 'processed' => $processed,
			'percent' => $total > 0 ? (int) floor( $processed * 100 / $total ) : ( ! empty( $state['ready'] ) ? 100 : 0 ),
			'page' => (int) ceil( $processed / 250 ), 'batch_size' => 250,
			'complete' => ! empty( $state['ready'] ), 'generation' => (string) ( $state['generation'] ?? '' ) ];
	}

	public function manual_batch( string $generation ): array {
		$state = get_option( self::STATE, [] );
		if ( $generation !== '' && $generation !== ( $state['generation'] ?? '' ) ) {
			return [ 'error' => __( 'ایندکس در درخواست دیگری بازسازی شده است. صفحه را تازه‌سازی کنید.', 'kasebi-erp' ) ];
		}
		if ( ! $state || ( $generation === '' && ! empty( $state['ready'] ) ) ) {
			$this->restart( FALSE );
		} else {
			$state['mode'] = 'manual';
			update_option( self::STATE, $state, FALSE );
		}
		wp_clear_scheduled_hook( self::CRON );
		return $this->build_batch();
	}

	public function settings_changed( $old, $new ): void {
		foreach ( [ 'phone_meta_key', 'owner_meta_key' ] as $key ) {
			if ( ( $old[ $key ] ?? '' ) !== ( $new[ $key ] ?? '' ) ) { $this->restart(); break; }
		}
	}

	public function meta_changed( $meta_id, $user_id, $key, $value ): void {
		global $wpdb;
		$settings = KERP_Modules_Customers_Settings::instance();
		if ( in_array( $key, [ 'first_name', 'last_name', 'billing_phone',
			(string) $settings->get( 'phone_meta_key', 'nooshika_phone_num' ),
			(string) $settings->get( 'owner_meta_key', 'kerp_customer_owner_id' ),
			$wpdb->get_blog_prefix() . 'capabilities' ], TRUE ) ) { $this->sync( (int) $user_id ); }
	}

	public function remove( int $user_id ): void {
		global $wpdb;
		$wpdb->delete( self::table(), [ 'user_id' => $user_id ], [ '%d' ] );
	}

	public function remove_from_blog( int $user_id, int $blog_id ): void {
		if ( $blog_id === get_current_blog_id() ) { $this->remove( $user_id ); }
	}

	public function sync( int $user_id ): bool {
		global $wpdb;
		$user = get_userdata( $user_id );
		if ( ! $user ) { $this->remove( $user_id ); return TRUE; }
		$settings = KERP_Modules_Customers_Settings::instance();
		// Read persisted roles, since role hooks can fire before WP_User is refreshed.
		$capabilities = (array) get_user_meta( $user_id, $wpdb->get_blog_prefix() . 'capabilities', TRUE );
		$roles = array_values( array_filter( array_keys( $capabilities ), static fn( $role ) => ! empty( $capabilities[ $role ] ) && isset( wp_roles()->roles[ $role ] ) ) );
		$owner = get_user_meta( $user_id, (string) $settings->get( 'owner_meta_key', 'kerp_customer_owner_id' ), TRUE );
		$data = [
			'user_id' => $user_id,
			'first_name' => (string) get_user_meta( $user_id, 'first_name', TRUE ),
			'last_name' => (string) get_user_meta( $user_id, 'last_name', TRUE ),
			'phone' => (string) get_user_meta( $user_id, (string) $settings->get( 'phone_meta_key', 'nooshika_phone_num' ), TRUE ),
			'billing_phone' => (string) get_user_meta( $user_id, 'billing_phone', TRUE ),
			'display_name' => $user->display_name, 'user_login' => $user->user_login, 'user_email' => $user->user_email,
			'roles' => maybe_serialize( $roles ),
			'owner_id' => is_scalar( $owner ) && ctype_digit( (string) $owner ) ? (int) $owner : 0,
		];
		$ok = $wpdb->replace( self::table(), $data ) !== FALSE;
		if ( ! $ok && $this->ready() ) { $this->restart(); }
		return $ok;
	}

	public function build_batch(): array {
		global $wpdb;
		$state = get_option( self::STATE, [] );
		if ( ! $state || ! empty( $state['ready'] ) ) { return $this->status(); }
		$lock = 'kerp_customers_search_index_lock';
		$lease = get_option( $lock );
		if ( $lease !== FALSE && (int) $lease < time() - 300 ) {
			// Compare the lease in SQL so another request's new lock cannot be removed.
			$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name = %s AND option_value = %s", $lock, (string) $lease ) );
			wp_cache_delete( $lock, 'options' );
		}
		if ( ! add_option( $lock, time(), '', FALSE ) ) { $this->schedule(); return array_merge( $this->status(), [ 'busy' => TRUE ] ); }
		try {
			$ids = $wpdb->get_col( $wpdb->prepare( "SELECT ID FROM {$wpdb->users} WHERE ID > %d ORDER BY ID ASC LIMIT 250", (int) $state['cursor'] ) );
			if ( $wpdb->last_error ) { $this->schedule(); return [ 'error' => __( 'خواندن کاربران برای ایندکس انجام نشد. دوباره تلاش کنید.', 'kasebi-erp' ) ]; }
			update_meta_cache( 'user', $ids );
			foreach ( $ids as $id ) {
				if ( ! $this->sync( (int) $id ) ) { $this->schedule(); return [ 'error' => __( 'ذخیره ایندکس انجام نشد. دوباره تلاش کنید.', 'kasebi-erp' ) ]; }
				$state['cursor'] = (int) $id;
			}
			if ( ( get_option( self::STATE, [] )['generation'] ?? '' ) !== $state['generation'] ) { $this->schedule(); return [ 'error' => __( 'بازسازی دیگری شروع شده است. صفحه را تازه‌سازی کنید.', 'kasebi-erp' ) ]; }
			$state['ready'] = count( $ids ) < 250;
			update_option( self::STATE, $state, FALSE );
			if ( ! $state['ready'] ) { $this->schedule(); }
			return $this->status();
		} finally { delete_option( $lock ); }
	}
}
