<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Customers_Dashboard {
	private static ?self $instance = NULL;


	public static function instance(): self { return self::$instance ??= new self(); }
	private function __construct() {
		add_filter( 'kerp_dashboard_blocks', [ $this, 'register_blocks' ] );
		add_action( 'kasebi_ajax_customers_dashboard_memberships', [ $this, 'memberships' ] );
	}

	public function register_blocks( array $blocks ): array {
		$position = 20;
		foreach ( [ 'memberships' => 'عضویت‌های جدید', 'channels' => 'مسیرهای عضویت', 'products' => 'محصولات اولین ورود', 'forms' => 'فرم‌های اولین ورود' ] as $key => $title ) {
			$blocks[ 'customers-' . $key ] = [
				'title' => $title, 'position' => $position++, 'width' => $key === 'memberships' ? 8 : ( $key === 'channels' ? 4 : 6 ),
				'module' => 'customers', 'permission' => 'customers', 'permission_type' => 'view',
				'async' => TRUE, 'callback' => [ $this, 'render' ],
			];
		}
		return $blocks;
	}

	public function render( array $context, array $block ): void {
		if ( ! kerp_can( 'customers', 'view' ) || kerp_list_scope( 'customers' ) === 'none' ) { return; }
		// Identify the chart through the shared dashboard block ID.
		$kind = substr( $block['id'], strlen( 'customers-' ) );
		KERP_Helpers_Template::render_template( 'modules/customers/partials/dashboard.php', [
			'kind' => $kind, 'stats' => $this->get_data(), 'series' => $this->series( 7 ),
		] );
	}

	public function memberships(): void {
		if ( ! kerp_can( 'customers', 'view' ) || kerp_list_scope( 'customers' ) === 'none' ) {
			wp_send_json( [ 'status' => 'error', 'msg' => 'دسترسی لازم را ندارید.' ], 403 );
		}
		$nonce = isset( $_POST['nonce'] ) && is_string( $_POST['nonce'] ) ? wp_unslash( $_POST['nonce'] ) : '';
		if ( ! wp_verify_nonce( $nonce, 'kerp-customers-dashboard' ) ) {
			wp_send_json( [ 'status' => 'error', 'msg' => 'درخواست معتبر نیست؛ دوباره تلاش کنید.' ], 403 );
		}
		$days = isset( $_POST['days'] ) && is_scalar( $_POST['days'] ) ? absint( $_POST['days'] ) : 7;
		if ( ! in_array( $days, [ 7, 15, 30 ], TRUE ) ) {
			wp_send_json( [ 'status' => 'error', 'msg' => 'بازه زمانی معتبر نیست.' ], 400 );
		}
        try { $series = $this->series( $days ); }
        catch ( KERP_Helpers_Dashboard_Pending $pending ) { wp_send_json( [ 'status' => 'pending' ] ); return; }
		wp_send_json( [ 'status' => 'success', 'chart' => $series, 'total' => number_format_i18n( array_sum( $series['data'] ) ), 'period' => $days . ' روز اخیر' ] );
	}

	public function series( int $days ): array {
		$data = array_slice( $this->get_data()['daily'], -$days, NULL, TRUE );
		return [ 'labels' => array_map( [ KERP_Helpers_Date::class, 'gregorian_to_jalali' ], array_keys( $data ) ), 'data' => array_values( $data ) ];
	}

	public function get_data(): array {
        if ( ! kerp_can( 'customers', 'view' ) || ! in_array( kerp_list_scope( 'customers' ), [ 'all', 'own' ], TRUE ) ) { return [ 'daily' => [], 'channels' => [], 'products' => [], 'forms' => [], 'total' => 0 ]; }
        return KERP_Helpers_Dashboard_Cache::remember( 'customers-sql-v2', [ $this, 'collect' ] );
    }

    public function collect( array $state ): array {
        global $wpdb;
        $data = $state['data'] ?? [ 'daily' => [], 'channels' => [], 'products' => [], 'forms' => [], 'total' => 0 ];
        if ( ! kerp_can( 'customers', 'view' ) || ! in_array( kerp_list_scope( 'customers' ), [ 'all', 'own' ], TRUE ) ) {
            return [ 'done' => TRUE, 'data' => [ 'daily' => [], 'channels' => [], 'products' => [], 'forms' => [], 'total' => 0 ] ];
        }
        $now = ( new DateTimeImmutable( $state['as_of'] ) )->setTimezone( wp_timezone() );
        $start = $now->setTime( 0, 0 )->modify( '-29 days' );
        $utc = new DateTimeZone( 'UTC' );
        $window = static function( array $query, array $args ) use ( $start, $now, $utc ): array {
            if ( empty( $args['customers_dashboard_sql'] ) ) { return $query; }
            $query['date_query'] = [ [ 'after' => $start->setTimezone( $utc )->format( 'Y-m-d H:i:s' ), 'before' => $now->setTimezone( $utc )->format( 'Y-m-d H:i:s' ), 'inclusive' => TRUE ] ];
            $query['fields'] = 'ID';
            $query['count_total'] = FALSE;
            return $query;
        };
        add_filter( 'kerp_customers_wp_user_query_args', $window, 100, 2 );
        try {
            $compiled = KERP_Modules_Customers_Query::instance()->find( [ 'customers_dashboard_sql' => TRUE, 'customers_dashboard_window' => TRUE, 'count_total' => FALSE ] );
        } finally { remove_filter( 'kerp_customers_wp_user_query_args', $window, 100 ); }
        if ( empty( $compiled['sql'] ) ) { throw new RuntimeException( 'Customer dashboard scope could not be compiled.' ); }
        $users = $compiled['sql'];
        $touch = KERP_Services_Attribution_First_Touch::table();
        $items = KERP_Services_Attribution_First_Touch::items_table();
        $read = static function( string $sql ): array {
            global $wpdb;
            $rows = $wpdb->get_results( $sql, ARRAY_A );
            if ( $wpdb->last_error ) { throw new RuntimeException( 'Customer dashboard aggregate failed: ' . $wpdb->last_error ); }
            return (array) $rows;
        };
        if ( empty( $state['aggregated'] ) ) {
            $total = $read( "SELECT COUNT(*) AS total FROM ({$users}) u" );
            $data['total'] = (int) ( $total[0]['total'] ?? 0 );
            $cases = [];
            foreach ( new DatePeriod( $start, new DateInterval( 'P1D' ), $now->modify( '+1 second' ) ) as $day ) {
                $label = $day->format( 'Y-m-d' );
                $data['daily'][ $label ] = 0;
                $cases[] = $wpdb->prepare( 'WHEN u.user_registered >= %s AND u.user_registered < %s THEN %s',
                    $day->setTimezone( $utc )->format( 'Y-m-d H:i:s' ), $day->modify( '+1 day' )->setTimezone( $utc )->format( 'Y-m-d H:i:s' ), $label );
            }
            $day_sql = 'CASE ' . implode( ' ', $cases ) . ' END';
            foreach ( $read( "SELECT {$day_sql} AS day, COUNT(*) AS total FROM ({$users}) u GROUP BY day" ) as $row ) {
                if ( isset( $data['daily'][ $row['day'] ] ) ) { $data['daily'][ $row['day'] ] = (int) $row['total']; }
            }
            $names = KERP_Modules_Customers_List_Table::instance()->get_first_touch_fields()['first_touch_type']['options'];
            foreach ( $read( "SELECT COALESCE(NULLIF(ft.touch_type, ''), 'unknown') AS channel, COUNT(DISTINCT u.ID) AS total
                FROM ({$users}) u LEFT JOIN {$touch} ft ON ft.user_id = u.ID GROUP BY channel ORDER BY total DESC" ) as $row ) {
                $data['channels'][ $row['channel'] ] = [ 'label' => $names[ $row['channel'] ] ?? 'مسیر نامشخص', 'count' => (int) $row['total'] ];
            }
            foreach ( $read( "SELECT i.product_id, MAX(NULLIF(i.product_name, '')) AS label, COUNT(DISTINCT u.ID) AS total
                FROM ({$users}) u INNER JOIN {$touch} ft ON ft.user_id = u.ID INNER JOIN {$items} i ON i.first_touch_id = ft.id
                WHERE i.product_id > 0 AND ((ft.touch_type = 'landing_order' AND i.item_kind = 'landing')
                    OR (ft.touch_type = 'site_registration' AND i.item_kind = 'cart'))
                GROUP BY i.product_id ORDER BY total DESC, i.product_id" ) as $row ) {
                $data['products'][ (int) $row['product_id'] ] = [ 'label' => $row['label'] ?: 'محصول #' . $row['product_id'], 'count' => (int) $row['total'] ];
            }
            foreach ( $read( "SELECT ft.form_id, MAX(ft.context_json) AS context_json, COUNT(DISTINCT u.ID) AS total
                FROM ({$users}) u INNER JOIN {$touch} ft ON ft.user_id = u.ID
                WHERE ft.touch_type = 'gravity_form' AND ft.form_id > 0 GROUP BY ft.form_id ORDER BY total DESC, ft.form_id" ) as $row ) {
                $context = json_decode( (string) $row['context_json'], TRUE );
                $title = $context['form_title'] ?? '';
                if ( ! $title && class_exists( 'GFAPI' ) ) {
                    $form = GFAPI::get_form( (int) $row['form_id'] ); $title = is_array( $form ) ? ( $form['title'] ?? '' ) : '';
                }
                $data['forms'][ (int) $row['form_id'] ] = [ 'label' => $title ?: 'فرم #' . $row['form_id'], 'count' => (int) $row['total'] ];
            }
        }
        // Serialized legacy metadata cannot be grouped safely in SQL. Only those
        // exceptional users use the existing fallback; canonical users never hydrate.
        $legacy = $read( $wpdb->prepare( "SELECT u.ID, u.user_registered FROM ({$users}) u
            LEFT JOIN {$touch} ft ON ft.user_id = u.ID WHERE ft.id IS NULL AND u.ID > %d
            AND EXISTS (SELECT 1 FROM {$wpdb->usermeta} lm WHERE lm.user_id = u.ID AND lm.meta_key = %s)
            ORDER BY u.ID LIMIT 100", (int) ( $state['legacy_cursor'] ?? 0 ), KERP_Services_Attribution_First_Touch::LEGACY_META_KEY ) );
        if ( $legacy ) {
            $fallback = [ 'daily' => array_fill_keys( array_keys( $data['daily'] ), 0 ), 'channels' => [], 'products' => [], 'forms' => [], 'total' => 0 ];
            $this->accumulate( $fallback, array_map( static fn( $row ) => (object) $row, $legacy ) );
            $data['channels']['unknown']['count'] -= $fallback['total'];
            foreach ( [ 'channels', 'products', 'forms' ] as $key ) {
                foreach ( $fallback[ $key ] as $id => $row ) {
                    $data[ $key ][ $id ] ??= [ 'label' => $row['label'], 'count' => 0 ];
                    $data[ $key ][ $id ]['count'] += $row['count'];
                }
            }
            if ( count( $legacy ) === 100 ) {
                return [ 'done' => FALSE, 'data' => $data, 'aggregated' => TRUE, 'legacy_cursor' => (int) end( $legacy )['ID'] ];
            }
        }
        if ( empty( $data['channels']['unknown']['count'] ) ) { unset( $data['channels']['unknown'] ); }
        foreach ( [ 'channels', 'products', 'forms' ] as $key ) { uasort( $data[ $key ], static fn( $a, $b ) => $b['count'] <=> $a['count'] ); }
        return [ 'done' => TRUE, 'data' => $data ];
    }

	private function accumulate( array &$data, array $users ): void {
		if ( ! $users ) { return; }
		global $wpdb;
		$ids = array_map( static fn( $user ) => (int) $user->ID, $users );
		$touches = KERP_Services_Attribution_First_Touch::instance()->get_list_data( $ids );
		$items = [];
		$table = KERP_Services_Attribution_First_Touch::items_table();
		$touch_table = KERP_Services_Attribution_First_Touch::table();
		$placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT ft.user_id, i.product_id, i.product_name, i.item_kind FROM {$table} i INNER JOIN {$touch_table} ft ON ft.id=i.first_touch_id WHERE ft.user_id IN ({$placeholders})", ...$ids ), ARRAY_A );
		foreach ( (array) $rows as $row ) { $items[ (int) $row['user_id'] ][] = $row; }
        $names = KERP_Modules_Customers_List_Table::instance()->get_first_touch_fields()['first_touch_type']['options'];
		foreach ( $users as $user ) {
			$day = substr( get_date_from_gmt( $user->user_registered, 'Y-m-d H:i:s' ), 0, 10 );
			if ( ! isset( $data['daily'][ $day ] ) ) { continue; }
			++$data['daily'][ $day ]; ++$data['total'];
			$touch = $touches[ $user->ID ] ?? [];
			$type = (string) ( $touch['touch_type'] ?? $touch['type'] ?? '' );
			$this->increment( $data['channels'], $type ?: 'unknown', $names[ $type ] ?? 'مسیر نامشخص' );
			if ( $type === 'gravity_form' && ! empty( $touch['form_id'] ) ) {
				$id = absint( $touch['form_id'] );
				$title = $touch['form_title'] ?? '';
				if ( ! $title && ! isset( $data['forms'][ $id ] ) && class_exists( 'GFAPI' ) ) {
					$form = GFAPI::get_form( $id ); $title = is_array( $form ) ? ( $form['title'] ?? '' ) : '';
				}
				$this->increment( $data['forms'], $id, $title ?: 'فرم #' . $id );
			}
			if ( ! in_array( $type, [ 'landing_order', 'site_registration' ], TRUE ) ) { continue; }
			$kind = $type === 'landing_order' ? 'landing' : 'cart';
			// Canonical records win over legacy metadata; count each product once per customer.
			$products = ! empty( $touch['id'] ) ? ( $items[ $user->ID ] ?? [] ) : ( $touch[ $kind === 'landing' ? 'products' : 'cart_items' ] ?? [] );
			$seen = [];
			foreach ( (array) $products as $product ) {
				if ( ! is_array( $product ) || ( $product['item_kind'] ?? $kind ) !== $kind ) { continue; }
				$id = absint( $product['product_id'] ?? 0 );
				if ( ! $id || isset( $seen[ $id ] ) ) { continue; }
				$seen[ $id ] = TRUE;
				$this->increment( $data['products'], $id, (string) ( $product['product_name'] ?? $product['name'] ?? '' ) ?: 'محصول #' . $id );
			}
		}
	}

	private function increment( array &$rows, string|int $id, string $label ): void {
		$rows[ $id ] ??= [ 'label' => $label, 'count' => 0 ];
		++$rows[ $id ]['count'];
	}
}
