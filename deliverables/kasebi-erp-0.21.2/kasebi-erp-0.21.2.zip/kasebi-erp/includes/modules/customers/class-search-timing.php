<?php

defined( 'ABSPATH' ) || exit;

/** Opt-in search diagnostics. Set KERP_CUSTOMERS_SEARCH_TIMING to true to enable. */
final class KERP_Modules_Customers_Search_Timing {

	private static float $started = 0;
	private static float $previous = 0;
	private static int $queries = 0;
	private static string $request_id = '';

	public static function mark( string $stage ): void {
		if ( ! defined( 'KERP_CUSTOMERS_SEARCH_TIMING' ) || ! KERP_CUSTOMERS_SEARCH_TIMING ) {
			return;
		}

		global $wpdb;
		$now = microtime( TRUE );
		$query_count = (int) ( $wpdb->num_queries ?? 0 );
		$first = self::$started === 0.0;
		if ( $first ) {
			self::$started = self::$previous = $now;
			self::$queries = $query_count;
			self::$request_id = uniqid( 'cs-', FALSE );
			register_shutdown_function( [ self::class, 'shutdown' ] );
		}

		$entry = [
			'request_id' => self::$request_id,
			'stage' => $stage,
			'step_ms' => number_format( ( $now - self::$previous ) * 1000, 2, '.', '' ),
			'elapsed_ms' => number_format( ( $now - self::$started ) * 1000, 2, '.', '' ),
			'request_ms' => number_format( ( $now - (float) ( $_SERVER['REQUEST_TIME_FLOAT'] ?? self::$started ) ) * 1000, 2, '.', '' ),
			'db_queries' => $query_count - self::$queries,
		];
		if ( $first ) {
			$entry['pre_handler_ms'] = $entry['request_ms'];
			$entry['pre_handler_db_queries'] = $query_count;
		}
		// Never log the search term, SQL, user IDs, or customer details.
		error_log( '[customers_search timing] ' . wp_json_encode( $entry ) );
		self::$queries = $query_count;
		self::$previous = microtime( TRUE );
	}

	public static function shutdown(): void {
		$error = error_get_last();
		$fatal = $error && in_array( $error['type'], [ E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR ], TRUE );
		self::mark( $fatal ? 'request_shutdown_fatal' : 'request_shutdown' );
	}

	/** EXPLAIN does not execute the slow SELECT again. No SQL or values are logged. */
	public static function explain_slow_query( string $sql, float $duration_ms ): void {
		if ( $duration_ms < 1000 || ! defined( 'KERP_CUSTOMERS_SEARCH_TIMING' ) || ! KERP_CUSTOMERS_SEARCH_TIMING ) {
			return;
		}

		global $wpdb;
		$rows = $wpdb->get_results( 'EXPLAIN ' . $sql, ARRAY_A );
		$plan = [];
		foreach ( (array) $rows as $row ) {
			$entry = array_intersect_key( $row, array_flip( [
				'id', 'select_type', 'table', 'type', 'possible_keys', 'key', 'key_len', 'rows', 'filtered',
			] ) );
			$extra = (string) ( $row['Extra'] ?? '' );
			$entry['temporary'] = stripos( $extra, 'Using temporary' ) !== FALSE;
			$entry['filesort'] = stripos( $extra, 'Using filesort' ) !== FALSE;
			$plan[] = $entry;
		}
		error_log( '[customers_search plan] ' . wp_json_encode( [
			'request_id' => self::$request_id,
			'plan' => $plan,
		] ) );
		self::mark( 'db_explain' );
	}
}
