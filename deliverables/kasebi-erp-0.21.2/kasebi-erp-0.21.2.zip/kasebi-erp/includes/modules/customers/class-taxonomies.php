<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Customers_Taxonomies {
	
	public const OPTION_NAME = 'kerp_customers_taxonomies';
	
	public const TYPE_LABEL  = 'label';
	
	public const TYPE_TAG    = 'tag';
	
	public const TYPE_SOURCE = 'source';
	
	private static ?self $instance = NULL;
	
	private ?array $terms = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {
		add_action( 'update_option_' . self::OPTION_NAME, [ $this, 'clear_cache' ], 10, 0 );
		add_action( 'add_option_' . self::OPTION_NAME, [ $this, 'clear_cache' ], 10, 0 );
	}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public function get_all(): array {
		if ( $this->terms === NULL ) {
			$stored      = get_option( self::OPTION_NAME, [] );
			$this->terms = is_array( $stored ) ? $stored : [];
		}
		
		$terms = wp_parse_args(
			$this->terms,
			[
				self::TYPE_LABEL  => [],
				self::TYPE_TAG    => [],
				self::TYPE_SOURCE => [],
			]
		);
		
		return apply_filters( 'kerp_customers_taxonomies', $terms );
	}
	
	public function get_terms( string $type, bool $active_only = TRUE ): array {
		$type  = $this->sanitize_type( $type );
		$terms = $this->get_all()[ $type ] ?? [];
		
		if ( $active_only ) {
			$terms = array_filter(
				$terms,
				static fn( array $term ): bool => ! isset( $term['active'] ) || ! empty( $term['active'] )
			);
		}
		
		uasort(
			$terms,
			static fn( array $first, array $second ): int => (int) ( $first['order'] ?? 100 ) <=> (int) ( $second['order'] ?? 100 )
		);
		
		return apply_filters( 'kerp_customers_taxonomy_terms', $terms, $type, $active_only );
	}
	
	public function get_term( string $type, string $term_key ): ?array {
		$type     = $this->sanitize_type( $type );
		$term_key = sanitize_key( $term_key );
		$terms    = $this->get_terms( $type, FALSE );
		
		return isset( $terms[ $term_key ] ) && is_array( $terms[ $term_key ] )
			? $terms[ $term_key ]
			: NULL;
	}
	
	public function save_term( string $type, array $term ): bool {
		$type = $this->sanitize_type( $type );
		$key  = sanitize_key( (string) ( $term['key'] ?? $term['slug'] ?? '' ) );
		
		if ( $key === '' ) {
			return FALSE;
		}
		
		$all = $this->get_all();
		
		$all[ $type ][ $key ] = [
			'key'         => $key,
			'name'        => sanitize_text_field( (string) ( $term['name'] ?? $key ) ),
			'description' => sanitize_textarea_field( (string) ( $term['description'] ?? '' ) ),
			'color'       => sanitize_hex_color( (string) ( $term['color'] ?? '' ) ) ?: '',
			'icon'        => (string) ( $term['icon'] ?? '' ) ?: '',
			'active'      => ! isset( $term['active'] ) || ! empty( $term['active'] ),
			'order'       => (int) ( $term['order'] ?? 100 ),
		];
		
		return $this->save_all( $all );
	}
	
	public function delete_term( string $type, string $term_key ): bool {
		$type     = $this->sanitize_type( $type );
		$term_key = sanitize_key( $term_key );
		$all      = $this->get_all();
		
		if ( ! isset( $all[ $type ][ $term_key ] ) ) {
			return TRUE;
		}
		
		unset( $all[ $type ][ $term_key ] );
		
		return $this->save_all( $all );
	}
	
	public function get_customer_terms( int $customer_id, string $type ): array|string {
		$customer_id = absint( $customer_id );
		$type        = $this->sanitize_type( $type );
		
		if ( ! $customer_id ) {
			return $type === self::TYPE_SOURCE ? '' : [];
		}
		
		$value = get_user_meta( $customer_id, $this->get_meta_key( $type ), TRUE );
		
		if ( $type === self::TYPE_SOURCE ) {
			return sanitize_key( (string) $value );
		}
		
		$value = is_array( $value ) ? $value : [];
		
		return array_values( array_unique( array_filter( array_map( 'sanitize_key', $value ) ) ) );
	}
	
	public function set_customer_terms( int $customer_id, string $type, array|string $value ): bool {
		$customer_id = absint( $customer_id );
		$type        = $this->sanitize_type( $type );
		
		if ( ! $customer_id ) {
			return FALSE;
		}
		
		if ( $type === self::TYPE_SOURCE ) {
			$value = sanitize_key( (string) $value );
		} else {
			$value = is_array( $value ) ? $value : [ $value ];
			$value = array_values( array_unique( array_filter( array_map( 'sanitize_key', $value ) ) ) );
		}
		
		return (bool) update_user_meta( $customer_id, $this->get_meta_key( $type ), $value );
	}
	
	public function get_options( string $type ): array {
		$options = [];
		
		foreach ( $this->get_terms( $type ) as $term_key => $term ) {
			$options[ $term_key ] = (string) ( $term['name'] ?? $term_key );
		}
		
		return $options;
	}
	
	public function get_meta_key( string $type ): string {
		return match ( $this->sanitize_type( $type ) ) {
			self::TYPE_LABEL => 'kerp_customer_labels',
			self::TYPE_TAG => 'kerp_customer_tags',
			self::TYPE_SOURCE => 'kerp_customer_source',
		};
	}
	
	private function save_all( array $terms ): bool {
		$result      = update_option( self::OPTION_NAME, $terms, FALSE );
		$this->terms = $terms;
		
		do_action( 'kerp_customers_taxonomies_saved', $terms );
		
		return $result;
	}
	
	private function sanitize_type( string $type ): string {
		$type = sanitize_key( $type );
		
		return in_array( $type, [ self::TYPE_LABEL, self::TYPE_TAG, self::TYPE_SOURCE ], TRUE )
			? $type
			: self::TYPE_TAG;
	}
	
	public function clear_cache(): void {
		$this->terms = NULL;
	}
	
	public function get_profile_fields( int $customer_id = 0 ): array {
		$fields = [
			self::TYPE_LABEL  => [
				'id'            => 'kerp-customer-profile-tax-label',
				'name'          => 'tax[' . self::TYPE_LABEL . ']',
				'key'           => self::TYPE_LABEL,
				'taxonomy_type' => self::TYPE_LABEL,
				'label'         => __( 'دسته‌‎بندی‌ها', 'kasebi-erp' ),
				'type'          => 'select',
				'multiple'      => TRUE,
				'input_class'   => 'js-select2',
				'placeholder'   => __( 'دسته‌بندی‌ها را انتخاب کنید', 'kasebi-erp' ),
				'class'         => 'col-md-6',
				'value'         => $this->get_customer_terms(
					$customer_id,
					self::TYPE_LABEL
				),
				'options'       => $this->get_options(
					self::TYPE_LABEL
				),
				'order'         => 10,
			],
			self::TYPE_TAG    => [
				'id'            => 'kerp-customer-profile-tax-tag',
				'name'          => 'tax[' . self::TYPE_TAG . ']',
				'key'           => self::TYPE_TAG,
				'taxonomy_type' => self::TYPE_TAG,
				'label'         => __( 'تگ‌ها', 'kasebi-erp' ),
				'type'          => 'select',
				'multiple'      => TRUE,
				'input_class'   => 'js-select2',
				'placeholder'   => __( 'تگ‌ها را انتخاب کنید', 'kasebi-erp' ),
				'class'         => 'col-md-6',
				'value'         => $this->get_customer_terms(
					$customer_id,
					self::TYPE_TAG
				),
				'options'       => $this->get_options(
					self::TYPE_TAG
				),
				'order'         => 20,
			],
			self::TYPE_SOURCE => [
				'id'            => 'kerp-customer-profile-tax-source',
				'name'          => 'tax[' . self::TYPE_SOURCE . ']',
				'key'           => self::TYPE_SOURCE,
				'taxonomy_type' => self::TYPE_SOURCE,
				'label'         => __( 'شیوه آشنایی', 'kasebi-erp' ),
				'type'          => 'select',
				'input_class'   => 'js-select2',
				'class'         => 'col-md-6',
				'value'         => $this->get_customer_terms(
					$customer_id,
					self::TYPE_SOURCE
				),
				'options'       => $this->get_options(
					self::TYPE_SOURCE
				),
				'order'         => 30,
			],
		];
		
		$fields = apply_filters(
			'kerp_customer_profile_taxonomy_fields',
			$fields,
			$customer_id
		);
		
		$normalized = [];
		
		foreach ( $fields as $field_key => $field ) {
			if ( ! is_array( $field ) ) {
				continue;
			}
			
			$field_key = sanitize_key(
				(string) ( $field['key'] ?? $field_key )
			);
			
			if ( $field_key === '' ) {
				continue;
			}
			
			$field['key']           = $field_key;
			$field['name']          = 'tax[' . $field_key . ']';
			$field['taxonomy_type'] = sanitize_key(
				(string) ( $field['taxonomy_type'] ?? $field_key )
			);
			$field['id']            = $field['id']
			                          ?? 'kerp-customer-profile-tax-' . $field_key;
			
			$normalized[ $field_key ] = $field;
		}
		
		uasort(
			$normalized,
			static fn( array $first, array $second ): int => (int) ( $first['order'] ?? 100 )
			                                                 <=>
			                                                 (int) ( $second['order'] ?? 100 )
		);
		
		return $normalized;
	}
	
	public function get_profile_modal_fields( int $customer_id ): array {
		$fields = [];
		
		foreach ( $this->get_profile_fields( $customer_id ) as $type => $field ) {
			$type = sanitize_key( (string) $type );
			
			if (
				in_array(
					$type,
					[ self::TYPE_LABEL, self::TYPE_TAG ],
					TRUE
				) && (string) ( $field['type'] ?? '' ) === 'checkbox'
			) {
				$fields[ $type . '_empty' ] = [
					'id'    => 'kerp-customer-profile-tax-' . $type . '-empty',
					'name'  => 'tax[' . $type . ']',
					'type'  => 'hidden',
					'value' => '',
				];
			}
			
			$fields[ $type ] = $field;
		}
		
		return apply_filters(
			'kerp_customer_profile_taxonomy_modal_fields',
			$fields,
			$customer_id
		);
	}
	
	public function get_profile_taxonomies(): array {
		$taxonomies = [
			self::TYPE_LABEL  => [
				'key'      => self::TYPE_LABEL,
				'meta_key' => $this->get_meta_key( self::TYPE_LABEL ),
				'label'    => __( 'دسته‌‎بندی‌ها', 'kasebi-erp' ),
				'multiple' => TRUE,
				'order'    => 10,
			],
			self::TYPE_TAG    => [
				'key'      => self::TYPE_TAG,
				'meta_key' => $this->get_meta_key( self::TYPE_TAG ),
				'label'    => __( 'تگ‌ها', 'kasebi-erp' ),
				'multiple' => TRUE,
				'order'    => 20,
			],
			self::TYPE_SOURCE => [
				'key'      => self::TYPE_SOURCE,
				'meta_key' => $this->get_meta_key( self::TYPE_SOURCE ),
				'label'    => __( 'شیوه آشنایی', 'kasebi-erp' ),
				'multiple' => FALSE,
				'order'    => 30,
			],
		];
		
		$taxonomies = apply_filters(
			'kerp_customer_profile_taxonomies',
			$taxonomies
		);
		
		uasort(
			$taxonomies,
			static fn( array $first, array $second ): int => (int) ( $first['order'] ?? 100 )
			                                                 <=>
			                                                 (int) ( $second['order'] ?? 100 )
		);
		
		return $taxonomies;
	}
	
}
