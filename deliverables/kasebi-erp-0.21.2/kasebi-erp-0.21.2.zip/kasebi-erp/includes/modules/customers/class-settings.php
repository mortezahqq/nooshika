<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Customers_Settings {

	public const OPTION_NAME = 'kerp_customers_settings';

	private static ?self $instance = NULL;

	private ?array $settings = NULL;

	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	private function __construct() {
		add_action( 'update_option_' . self::OPTION_NAME, [ $this, 'clear_cache' ], 10, 0 );
		add_action( 'add_option_' . self::OPTION_NAME, [ $this, 'clear_cache' ], 10, 0 );
	}

	private function __clone() {}

	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}

	public function defaults(): array {
		$defaults = [
			'singular_label'       => __( 'مشتری', 'kasebi-erp' ),
			'plural_label'         => __( 'مشتریان', 'kasebi-erp' ),
			'default_role'         => 'customer',
			'customer_roles'       => [ 'customer', 'subscriber' ],
			'require_first_name'   => TRUE,
			'require_last_name'    => TRUE,
			'require_phone'        => TRUE,
			'require_email'        => FALSE,
			'username_source'      => 'phone',
			'phone_meta_key'       => 'nooshika_phone_num',
			'owner_meta_key'       => 'kerp_customer_owner_id',
			'default_per_page'     => 20,
			'show_registration_at' => TRUE,
		];

		return apply_filters( 'kerp_customers_default_settings', $defaults );
	}

	public function all(): array {
		if ( $this->settings !== NULL ) {
			return $this->settings;
		}

		$stored = get_option( self::OPTION_NAME, [] );
		$stored = is_array( $stored ) ? $stored : [];

		$this->settings = wp_parse_args( $stored, $this->defaults() );

		return $this->settings;
	}

	public function get( string $key, mixed $default = NULL ): mixed {
		$settings = $this->all();

		return array_key_exists( $key, $settings )
			? $settings[ $key ]
			: $default;
	}

	public function update( array $settings ): bool {
		$current = $this->all();
		$clean   = $this->sanitize( array_merge( $current, $settings ) );
		$result  = update_option( self::OPTION_NAME, $clean, FALSE );

		$this->settings = $clean;

		do_action( 'kerp_customers_settings_updated', $clean, $current );

		return $result || $clean === $current;
	}

	public function sanitize( array $settings ): array {
		$defaults = $this->defaults();
		$clean    = [];

		$clean['singular_label'] = sanitize_text_field(
			(string) ( $settings['singular_label'] ?? $defaults['singular_label'] )
		);

		$clean['plural_label'] = sanitize_text_field(
			(string) ( $settings['plural_label'] ?? $defaults['plural_label'] )
		);

		$clean['default_role'] = sanitize_key(
			(string) ( $settings['default_role'] ?? $defaults['default_role'] )
		);

		$roles = $settings['customer_roles'] ?? $defaults['customer_roles'];
		$roles = is_array( $roles ) ? $roles : [ $roles ];
		$roles = array_values( array_unique( array_filter( array_map( 'sanitize_key', $roles ) ) ) );

		$clean['customer_roles'] = ! empty( $roles )
			? $roles
			: $defaults['customer_roles'];

		foreach ( [
			'require_first_name',
			'require_last_name',
			'require_phone',
			'require_email',
			'show_registration_at',
		] as $boolean_key ) {
			$clean[ $boolean_key ] = ! empty( $settings[ $boolean_key ] );
		}

		$username_source = sanitize_key(
			(string) ( $settings['username_source'] ?? $defaults['username_source'] )
		);

		$clean['username_source'] = in_array(
			$username_source,
			[ 'phone', 'email', 'generated' ],
			TRUE
		)
			? $username_source
			: 'phone';

		$clean['phone_meta_key'] = sanitize_key(
			(string) ( $settings['phone_meta_key'] ?? $defaults['phone_meta_key'] )
		);

		$clean['owner_meta_key'] = sanitize_key(
			(string) ( $settings['owner_meta_key'] ?? $defaults['owner_meta_key'] )
		);

		$clean['default_per_page'] = max(
			1,
			min( 200, absint( $settings['default_per_page'] ?? $defaults['default_per_page'] ) )
		);

		return apply_filters( 'kerp_customers_sanitized_settings', $clean, $settings );
	}

	public function get_singular_label(): string {
		$label = trim( (string) $this->get( 'singular_label', __( 'مشتری', 'kasebi-erp' ) ) );

		return $label !== '' ? $label : __( 'مشتری', 'kasebi-erp' );
	}

	public function get_plural_label(): string {
		$label = trim( (string) $this->get( 'plural_label', __( 'مشتریان', 'kasebi-erp' ) ) );

		return $label !== '' ? $label : __( 'مشتریان', 'kasebi-erp' );
	}

	public function clear_cache(): void {
		$this->settings = NULL;
	}
}
