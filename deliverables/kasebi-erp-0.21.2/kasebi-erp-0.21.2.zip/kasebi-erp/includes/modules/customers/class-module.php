<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Customers_Module {
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {
		$this->load_services();
		$this->register_hooks();
	}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	private function load_services(): void {
		KERP_Modules_Customers_Dashboard::instance();
		KERP_Modules_Customers_Settings::instance();
		KERP_Modules_Customers_Fields::instance();
		KERP_Modules_Customers_Taxonomies::instance();
		KERP_Modules_Customers_Legacy_Taxonomy_Migration::instance();
		KERP_Modules_Customers_Query::instance();
		KERP_Modules_Customers_List_Table::instance();
		KERP_Modules_Customers_Profile::instance();
		KERP_Modules_Customers_Notes::instance();
		KERP_Modules_Customers_Notes_Query::instance();
		KERP_Modules_Customers_Notes_Api::instance();
		KERP_Modules_Customers_History::instance();
		KERP_Modules_Customers_Bulk_Actions::instance();
		KERP_Modules_Customers_Api::instance();
	}
	
	private function register_hooks(): void {
		add_filter( 'kerp_app_pages', [ $this, 'register_pages' ], 20 );
		add_action( 'kerp_footer_template', [ $this, 'render_add_customer_modal' ] );
		add_filter( 'kerp_employee_permission_groups', [ $this, 'register_employee_permissions' ], 20 );
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_first_touch_migration' ], PHP_INT_MAX );
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_legacy_taxonomy_migration' ], PHP_INT_MAX );
	}

	public function enqueue_first_touch_migration(): void {
		if ( kerp_is_erp_request() ) {
			wp_enqueue_script( 'kerp-first-touch-migration', KERP_ASSETS_URL . 'app/js/modules/first-touch-migration.js', [ 'kerp-app' ], kerp_asset_version( 'app/js/modules/first-touch-migration.js' ), TRUE );
		}
	}

	public function enqueue_legacy_taxonomy_migration(): void {
		if ( kerp_is_erp_request() ) {
			wp_enqueue_script( 'kerp-legacy-taxonomy-migration', KERP_ASSETS_URL . 'app/js/modules/legacy-taxonomy-migration.js', [ 'kerp-app' ], kerp_asset_version( 'app/js/modules/legacy-taxonomy-migration.js' ), TRUE );
		}
	}
	
	public function register_pages( array $pages ): array {
		$settings     = KERP_Modules_Customers_Settings::instance();
		$plural_label = $settings->get_plural_label();
		
		$crm_group = [
			'key'   => 'crm',
			'title' => sprintf( __( 'مدیریت %s', 'kasebi-erp' ), $plural_label ),
			'icon'  => 'kik fa-users-02',
			'order' => 20,
		];
		
		$system_group = [
			'key'        => 'settings',
			'title'      => __( 'تنظیمات', 'kasebi-erp' ),
			'icon'       => 'kik fa-settings-02',
			'order'      => 100,
			'sep_before' => TRUE,
		];
		
		$settings_menu = [
			'key'   => 'customers-settings',
			'title' => sprintf( __( 'تنظیمات %s', 'kasebi-erp' ), $plural_label ),
			'icon'  => 'kik fa-users-02',
			'order' => 20,
		];
		
		$pages['customers'] = [
			'title'      => $plural_label,
			'route'      => 'customers',
			'type'       => 'page',
			'template'   => 'modules/customers/pages/customers.php',
			'permission' => 'customers',
			'navigation' => [
				'group' => $crm_group,
				'icon'  => 'ni ni-users',
				'order' => 10,
			],
		];
		
		$pages['customers-settings-general'] = [
			'title'      => sprintf( __( 'تنظیمات عمومی %s', 'kasebi-erp' ), $plural_label ),
			'route'      => 'settings/customers',
			'type'       => 'settings',
			'template'   => 'modules/customers/settings/general.php',
			'permission' => 'customers.manage_settings',
			'navigation' => [
				'group' => $system_group,
				'menu'  => $settings_menu,
				'title' => __( 'تنظیمات عمومی', 'kasebi-erp' ),
				'order' => 10,
			],
		];
		
		$pages['customers-settings-fields'] = [
			'title'      => sprintf( __( 'فیلدهای اختصاصی %s', 'kasebi-erp' ), $plural_label ),
			'route'      => 'settings/customers/fields',
			'type'       => 'settings',
			'template'   => 'modules/customers/settings/fields.php',
			'permission' => 'customers.manage_settings',
			'navigation' => [
				'group' => $system_group,
				'menu'  => $settings_menu,
				'title' => __( 'فیلدهای اختصاصی', 'kasebi-erp' ),
				'order' => 20,
			],
		];
		
		$pages['customers-settings-taxonomies'] = [
			'title'      => __( 'برچسب‌ها و دسته‌بندی', 'kasebi-erp' ),
			'route'      => 'settings/customers/taxonomies',
			'type'       => 'settings',
			'template'   => 'modules/customers/settings/taxonomies.php',
			'permission' => 'customers.manage_settings',
			'navigation' => [
				'group' => $system_group,
				'menu'  => $settings_menu,
				'title' => __( 'دسته‌‎بندی‌، تگ و شیوه آشنایی', 'kasebi-erp' ),
				'order' => 30,
			],
		];
		
		$pages['customer'] = [
			'title'      => sprintf(
				__( 'پروفایل %s', 'kasebi-erp' ),
				$settings->get_singular_label()
			),
			'route'      => 'customers/{customer_id}',
			'type'       => 'sub-page',
			'template'   => 'modules/customers/pages/customer.php',
			'permission' => 'customers',
			'navigation' => [
				'hidden' => TRUE,
				'active' => 'customers',
			],
		];
		
		return $pages;
	}
	
	public function register_employee_permissions( array $groups ): array {
		$settings       = KERP_Modules_Customers_Settings::instance();
		$singular_label = $settings->get_singular_label();
		$plural_label   = $settings->get_plural_label();

		if ( ! isset( $groups['crm'] ) || ! is_array( $groups['crm'] ) ) {
			$groups['crm'] = [
				'key'    => 'crm',
				'label'  => sprintf( __( 'مدیریت %s', 'kasebi-erp' ), $plural_label ),
				'icon'   => 'kik fa-users-02',
				'order'  => 20,
				'blocks' => [],
			];
		}
		
		$groups['crm']['blocks']['customers'] = [
			'key'         => 'customers',
			'label'       => $plural_label,
			'icon'        => 'ni ni-users',
			'order'       => 10,
			'permissions' => [
				'customers'          => [
					'key'   => 'customers',
					'label' => sprintf( __( 'مشاهده بخش %s', 'kasebi-erp' ), $plural_label ),
					'type'  => 'view',
					'order' => 10,
				],
				'customers_list'     => [
					'key'         => 'customers.list',
					'label'       => sprintf( __( 'مشاهده فهرست %s', 'kasebi-erp' ), $plural_label ),
					'description' => sprintf( __( 'دامنه %s که در فهرست قابل مشاهده هستند.', 'kasebi-erp' ), $plural_label ),
					'type'        => 'view',
					'order'       => 15,
					'scope'       => [
						'options' => [
							'own' => sprintf( __( 'فقط %s متعلق به خود', 'kasebi-erp' ), $plural_label ),
							'all' => sprintf( __( 'همه %s', 'kasebi-erp' ), $plural_label ),
						],
						'default' => 'own',
					],
				],
				'customers_search'   => [
					'key'         => 'customers.search',
					'label'       => sprintf( __( 'جستجوی %s', 'kasebi-erp' ), $plural_label ),
					'description' => __( 'دامنه جستجو در سربرگ و انتخاب‌گرها، مستقل از دسترسی فهرست.', 'kasebi-erp' ),
					'type'        => 'action',
					'order'       => 18,
					'scope'       => [
						'options' => [
							'own' => sprintf( __( 'فقط %s متعلق به خود', 'kasebi-erp' ), $plural_label ),
							'all' => sprintf( __( 'همه %s', 'kasebi-erp' ), $plural_label ),
						],
						'default' => 'own',
					],
				],
				'customers_create'   => [
					'key'   => 'customers.create',
					'label' => sprintf( __( 'افزودن %s', 'kasebi-erp' ), $singular_label ),
					'type'  => 'action',
					'order' => 20,
				],
				'customers_edit'     => [
					'key'   => 'customers.edit',
					'label' => sprintf( __( 'ویرایش %s', 'kasebi-erp' ), $singular_label ),
					'type'  => 'action',
					'order' => 30,
				],
				'customers_delete'   => [
					'key'   => 'customers.delete',
					'label' => sprintf( __( 'حذف %s', 'kasebi-erp' ), $singular_label ),
					'type'  => 'action',
					'order' => 40,
				],
				'customers_history'  => [
					'key'         => 'customers.history.view',
					'label'       => sprintf( __( 'مشاهده سوابق تغییرات %s', 'kasebi-erp' ), $plural_label ),
					'description' => __( 'نمایش مقدار قبلی و جدید متاهای کاربر و فرد انجام‌دهنده تغییر.', 'kasebi-erp' ),
					'type'        => 'view',
					'order'       => 45,
				],
				'customers_settings' => [
					'key'   => 'customers.manage_settings',
					'label' => sprintf( __( 'مدیریت تنظیمات %s', 'kasebi-erp' ), $plural_label ),
					'type'  => 'action',
					'order' => 50,
				],
			],
		];
		
		return $groups;
	}
	
	public function render_add_customer_modal(): void {
		if ( ! kerp_can( 'customers.create', 'action' ) ) {
			return;
		}
		
		$settings = KERP_Modules_Customers_Settings::instance();
		$modal    = [
			'id'          => 'addCustomer',
			'title'       => sprintf(
				__( 'افزودن %s', 'kasebi-erp' ),
				$settings->get_singular_label()
			),
			'action'      => 'customers_create',
			'page'        => 'customers',
			'button'      => __( 'ثبت', 'kasebi-erp' ),
			'button_text' => __( 'ثبت', 'kasebi-erp' ),
			'size'        => 'lg',
			'fields'      => KERP_Modules_Customers_Fields::instance()->get_create_fields(),
		];
		
		$modal = apply_filters( 'kerp_customers_add_modal_data', $modal );
		
		if ( ! is_array( $modal ) || empty( $modal['id'] ) ) {
			return;
		}
		
		KERP_Helpers_Template::render_modal( $modal );
	}
	
}
