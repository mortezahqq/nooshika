<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Customers_Notes_Api {
	private static ?self $instance = NULL;
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		return self::$instance;
	}
	private function __construct() {
		$this->register_hooks();
	}
	private function __clone() {}
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	private function register_hooks(): void {
		add_action( 'kasebi_ajax_customers_notes_save', [ $this, 'save_note' ] );
		add_action( 'kasebi_ajax_customers_notes_delete', [ $this, 'delete_note' ] );
	}
	public function save_note(): void {
		$customer_id = absint( $_POST['customer_id'] ?? 0 );
		$note_id     = absint( $_POST['note_id'] ?? 0 );
		$customer    = get_userdata( $customer_id );
		if ( ! $customer instanceof WP_User ) {
			$this->error( sprintf( __( '%s پیدا نشد.', 'kasebi-erp' ), KERP_Modules_Customers_Settings::instance()->get_singular_label() ) );
		}
		if ( $note_id ) {
			$this->guard( 'edit' );
			$note = KERP_Modules_Customers_Notes_Query::instance()->get_by_id( $note_id );
			if ( ! $note ) {
				$this->error( __( 'یادداشت پیدا نشد.', 'kasebi-erp' ) );
			}
			if ( (int) $note['customer_id'] !== $customer_id ) {
				$this->error( sprintf( __( 'یادداشت متعلق به این %s نیست.', 'kasebi-erp' ), KERP_Modules_Customers_Settings::instance()->get_singular_label() ) );
			}
			if ( ! KERP_Modules_Customers_Notes::instance()->can_view_note( $note ) ) {
				$this->error( __( 'شما اجازه مشاهده این یادداشت را ندارید.', 'kasebi-erp' ) );
			}
		} else {
			$this->guard( 'create' );
		}
		$result = KERP_Modules_Customers_Notes::instance()->save(
			[
				'customer_id' => $customer_id,
				'type'        => $this->post_text( 'type' ),
				'content'     => $this->post_textarea( 'content' ),
				'is_pinned'   => ! empty( $_POST['is_pinned'] ),
				'visibility'  => $this->post_text( 'visibility' ),
			],
			$note_id
		);
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		$page_response = KERP_Api_Page_Content::build_page_response(
			'/erp/customers/' . $customer_id . '/',
			[ 'tab' => 'notes' ],
			TRUE
		);
		$singular_label = KERP_Modules_Customers_Settings::instance()->get_singular_label();
		$this->success(
			$note_id
				? sprintf( __( 'یادداشت %s با موفقیت ویرایش شد.', 'kasebi-erp' ), $singular_label )
				: sprintf( __( 'یادداشت %s با موفقیت ثبت شد.', 'kasebi-erp' ), $singular_label ),
			array_merge( $page_response, [ 'note_id' => (int) $result ] )
		);
	}
	public function delete_note(): void {
		$this->guard( 'delete' );
		$note_id = absint( $_POST['note_id'] ?? $_POST['item_id'] ?? 0 );
		if ( ! $note_id ) {
			$this->error( __( 'شناسه یادداشت معتبر نیست.', 'kasebi-erp' ) );
		}
		$note = KERP_Modules_Customers_Notes_Query::instance()->get_by_id( $note_id );
		if ( ! $note ) {
			$this->error( __( 'یادداشت پیدا نشد.', 'kasebi-erp' ) );
		}
		if ( ! KERP_Modules_Customers_Notes::instance()->can_view_note( $note ) ) {
			$this->error( __( 'شما اجازه مشاهده این یادداشت را ندارید.', 'kasebi-erp' ) );
		}
		$result = KERP_Modules_Customers_Notes::instance()->delete( $note_id );
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		$customer_id = (int) $note['customer_id'];
		$page_response = KERP_Api_Page_Content::build_page_response(
			'/erp/customers/' . $customer_id . '/',
			[ 'tab' => 'notes' ],
			TRUE
		);
		$singular_label = KERP_Modules_Customers_Settings::instance()->get_singular_label();
		$this->success(
			sprintf( __( 'یادداشت %s با موفقیت حذف شد.', 'kasebi-erp' ), $singular_label ),
			$page_response
		);
	}
	private function guard( string $action ): void {
		if ( ! is_user_logged_in() ) {
			$this->error( __( 'برای انجام این عملیات باید وارد حساب کاربری شوید.', 'kasebi-erp' ) );
		}
		if ( ! KERP_App::instance()->current_user_has_access() ) {
			$this->error( __( 'شما به سامانه دسترسی ندارید.', 'kasebi-erp' ) );
		}
		if ( ! kerp_can( 'customers.notes.' . sanitize_key( $action ), 'action' ) ) {
			$this->error( __( 'شما اجازه انجام این عملیات را ندارید.', 'kasebi-erp' ) );
		}
	}
	private function post_text( string $key ): string {
		return sanitize_text_field( wp_unslash( $_POST[ $key ] ?? '' ) );
	}
	private function post_textarea( string $key ): string {
		return sanitize_textarea_field( wp_unslash( $_POST[ $key ] ?? '' ) );
	}
	private function success( string $message, array $data = [] ): never {
		wp_send_json(
			array_merge(
				[
					'status'  => 'success',
					'message' => $message,
				],
				$data
			)
		);
	}
	private function error( string $message, array $data = [] ): never {
		wp_send_json(
			array_merge(
				[
					'status'  => 'error',
					'message' => $message,
				],
				$data
			)
		);
	}
}
