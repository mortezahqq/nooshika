<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Customers_Api {
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {
		$this->register_hooks();
	}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	private function register_hooks(): void {
		add_action( 'kasebi_ajax_customers_search', [ $this, 'search_user' ] );
		add_action( 'kasebi_ajax_orders_search_customers', [ $this, 'search_order_customers' ] );
		add_action( 'kasebi_ajax_customers_create', [ $this, 'create_customer' ] );
		
		add_action( 'kasebi_ajax_handle_file_upload_avatar', [ $this, 'handle_file_upload_avatar' ] );
		add_action( 'kasebi_ajax_change_user_profile_image', [ $this, 'change_user_profile_image' ] );
		add_action( 'kasebi_ajax_customers_save_profile', [ $this, 'save_profile' ] );
		add_action( 'kasebi_ajax_customers_delete_customer', [ $this, 'delete_customer' ] );
		
		add_action( 'kasebi_ajax_customers_save_settings', [ $this, 'save_settings' ] );
		add_action( 'kasebi_ajax_customers_rebuild_search_index', [ $this, 'rebuild_search_index' ] );
		add_action( 'kasebi_ajax_customers_migrate_first_touch', [ $this, 'migrate_first_touch' ] );
		add_action( 'kasebi_ajax_customers_migrate_legacy_taxonomies', [ $this, 'migrate_legacy_taxonomies' ] );
		add_action( 'kasebi_ajax_customers_save_fields', [ $this, 'save_fields' ] );
		add_action( 'kasebi_ajax_customers_delete_field', [ $this, 'delete_field' ] );
		add_action( 'kasebi_ajax_customers_save_taxonomy_term', [ $this, 'save_taxonomy_term' ] );
		add_action( 'kasebi_ajax_customers_delete_taxonomy_term', [ $this, 'delete_taxonomy_term' ] );
		add_action( 'kasebi_ajax_customers_bulk_action', [ $this, 'bulk_action' ] );
	}
	
	public function search_user(): void {
		$this->search_customers();
	}

	public function search_order_customers(): void {
		if ( ! is_user_logged_in() || ! KERP_App::instance()->current_user_has_access() || ! kerp_can( 'orders.create', 'action' ) ) {
			$this->error( __( 'دسترسی لازم را ندارید.', 'kasebi-erp' ) );
		}
		$this->search_customers( TRUE );
	}

	private function search_customers( bool $order_creation = FALSE ): void {
		KERP_Modules_Customers_Search_Timing::mark( 'handler_start' );
		if ( KERP_Modules_Customers_Query::search_scope( $order_creation ) === 'none' ) {
			$this->error( __( 'دسترسی لازم را ندارید.', 'kasebi-erp' ) );
		}
		KERP_Modules_Customers_Search_Timing::mark( 'permission_check' );

		
		$search = $this->post_text( 'search' );
		$limit  = max(
			1,
			min(
				50,
				absint( $_POST['limit'] ?? 10 )
			)
		);
		$offset = max(
			0,
			absint( $_POST['offset'] ?? 0 )
		);
		
		KERP_Modules_Customers_Search_Timing::mark( 'request_input' );
		if ( $search === '' ) {
			$this->success(
				'',
				[
					'searchResult' => '',
					'users'        => [],
					'total'        => 0,
				]
			);
		}
		
		if ( ! KERP_Modules_Customers_Search_Index::instance()->ready() ) {
			$this->error( __( 'ایندکس جستجوی مشتریان در حال آماده‌سازی است. کمی بعد دوباره تلاش کنید.', 'kasebi-erp' ) );
		}
		$result = KERP_Modules_Customers_Query::instance()->search(
			$search,
			$limit,
			$offset,
			$order_creation
		);
		
		$users = isset( $result['items'] ) && is_array( $result['items'] )
			? $result['items']
			: [];
		
		$search_result = $order_creation ? '' : KERP_Helpers_Template::get_template(
			'modules/customers/partials/search-result.php',
			[
				'users'          => $users,
				'search'         => $search,
				'total'          => (int) ( $result['total'] ?? 0 ),
				'singular_label' => KERP_Modules_Customers_Settings::instance()->get_singular_label(),
			]
		);
		
		KERP_Modules_Customers_Search_Timing::mark( 'render_template' );

		$response_users = [];
		
		foreach ( $users as $user ) {
			if ( ! $user instanceof WP_User ) {
				continue;
			}
			
			$response_users[] = [
				'id'    => $user->ID,
				'name'  => get_user_name_by_id( $user->ID ),
				'phone' => KERP_Modules_Customers_Query::instance()->get_customer_phone( $user->ID ),
				'url'   => $order_creation ? '' : home_url( '/erp/customers/' . $user->ID . '/' ),
			];
		}
		
		KERP_Modules_Customers_Search_Timing::mark( 'response_ready' );
		$this->success(
			'',
			[
				'searchResult' => $search_result,
				'users'        => $response_users,
				'total'        => (int) ( $result['total'] ?? 0 ),
			]
		);
	}
	
	public function create_customer(): void {
		$this->guard( 'create' );
		
		$settings   = KERP_Modules_Customers_Settings::instance();
		$first_name = $this->post_text( 'first_name' );
		$last_name  = $this->post_text( 'last_name' );
		$phone      = $this->normalize_phone( $this->post_text( 'phone' ) );
		$email      = sanitize_email( $this->post_text( 'email' ) );
		
		if ( $settings->get( 'require_first_name', TRUE ) && $first_name === '' ) {
			$this->error( __( 'نام را وارد کنید.', 'kasebi-erp' ) );
		}
		
		if ( $settings->get( 'require_last_name', TRUE ) && $last_name === '' ) {
			$this->error( __( 'نام خانوادگی را وارد کنید.', 'kasebi-erp' ) );
		}
		
		if ( $settings->get( 'require_phone', TRUE ) && $phone === '' ) {
			$this->error( __( 'شماره موبایل را وارد کنید.', 'kasebi-erp' ) );
		}
		
		$existing_user_id = $this->find_user_by_phone( $phone );
		if ( $phone !== '' && $existing_user_id ) {
			$this->error( __( 'کاربری با این شماره موبایل قبلاً ثبت شده است.', 'kasebi-erp' ) );
		}
		
		if ( $email !== '' && email_exists( $email ) ) {
			$this->error( __( 'کاربری با این ایمیل قبلاً ثبت شده است.', 'kasebi-erp' ) );
		}
		
		$user_login = $this->build_username( $phone, $email );
		if ( $user_login === '' ) {
			$this->error( __( 'امکان تولید نام کاربری وجود ندارد.', 'kasebi-erp' ) );
		}
		
		if ( username_exists( $user_login ) ) {
			$user_login .= '-' . wp_generate_password( 5, FALSE, FALSE );
		}
		
		$user_data = [
			'user_login'   => $user_login,
			'user_pass'    => wp_generate_password( 20, TRUE, TRUE ),
			'user_email'   => $email,
			'first_name'   => $first_name,
			'last_name'    => $last_name,
			'display_name' => trim( $first_name . ' ' . $last_name ) ?: $user_login,
			'role'         => sanitize_key( (string) $settings->get( 'default_role', 'customer' ) ),
		];
		
		$user_data = apply_filters( 'kerp_customers_create_user_data', $user_data, $_POST );
		$user_id   = wp_insert_user( $user_data );
		
		if ( is_wp_error( $user_id ) ) {
			$this->error( $user_id->get_error_message() );
		}
		
		$user_id = absint( $user_id );
		
		if ( $phone !== '' ) {
			update_user_meta( $user_id, (string) $settings->get( 'phone_meta_key', 'nooshika_phone_num' ), $phone );
			update_user_meta( $user_id, 'billing_phone', $phone );
		}
		
		update_user_meta(
			$user_id,
			(string) $settings->get( 'owner_meta_key', 'kerp_customer_owner_id' ),
			get_current_user_id()
		);
		
		$this->save_custom_fields_from_request( $user_id );
		$this->save_taxonomies_from_request( $user_id );
		
		do_action( 'kerp_customer_created', $user_id, $user_data, $_POST );
		
		$data_url = '/erp/customers/' . $user_id . '/';
		
		$singular_label = KERP_Modules_Customers_Settings::instance()->get_singular_label();
		
		$this->success(
			sprintf(
				__( '%s با موفقیت ایجاد شد.', 'kasebi-erp' ),
				$singular_label
			),
			[
				'customer_id' => $user_id,
				'url'         => home_url( $data_url ),
				'data_url'    => $data_url,
			]
		);
	}
	
	public function handle_file_upload_avatar() {
		if ( empty( $_FILES['file'] ) ) {
			wp_send_json_error( [ 'status' => 'error', 'message' => 'فایل ارسال نشده است.' ] );
		}
		
		$file = $_FILES['file'];
		
		$ctx = [
			'file_name'         => isset( $_POST['file_name'] )
				? sanitize_text_field( wp_unslash( $_POST['file_name'] ) )
				: '',
			'dzuuid'            => isset( $_POST['dzuuid'] )
				? sanitize_text_field( wp_unslash( $_POST['dzuuid'] ) )
				: '',
			'dzchunkindex'      => isset( $_POST['dzchunkindex'] )
				? (int) $_POST['dzchunkindex']
				: - 1,
			'dztotalchunkcount' => isset( $_POST['dztotalchunkcount'] )
				? (int) $_POST['dztotalchunkcount']
				: - 1,
			'dztotalfilesize'   => isset( $_POST['dztotalfilesize'] )
				? absint( $_POST['dztotalfilesize'] )
				: 0,
			'direct'            => TRUE,
		];
		
		$result = KERP_Helpers_File::instance()->handle_upload_file(
			$file,
			'user_avatars',
			$ctx
		);
		
		wp_send_json( [
			'status'     => ! empty( $result['ok'] ) ? 'success' : 'error',
			'message'    => $result['msg'] ?? '',
			'attachment' => $result['url'] ?? '',
			'url'        => $result['url'] ?? '',
			'storage'    => $result['storage'] ?? '',
			'data'       => $result,
		] );
	}
	
	public function change_user_profile_image(): void {
		$customers_settings = KERP_Modules_Customers_Settings::instance();
		
		$singular_label = $customers_settings->get_singular_label();
		$plural_label   = $customers_settings->get_plural_label();
		
		if ( ! KERP_Services_UI_Gate::can( 'customers.update', 'action' ) ) {
			$this->error(
				sprintf(
					__( 'شما اجازه ویرایش %s را ندارید.', 'kasebi-erp' ),
					$plural_label
				)
			);
		}
		
		$customer_id = isset( $_POST['id'] )
			? absint( wp_unslash( $_POST['id'] ) )
			: 0;
		
		if ( ! $customer_id ) {
			$this->error(
				sprintf(
					__( 'شناسه %s معتبر نیست.', 'kasebi-erp' ),
					$singular_label
				)
			);
		}
		
		$customer = get_userdata( $customer_id );
		
		if ( ! $customer instanceof WP_User ) {
			$this->error(
				sprintf(
					__( '%s پیدا نشد.', 'kasebi-erp' ),
					$singular_label
				)
			);
		}
		
		$image = isset( $_POST['image'] )
			? esc_url_raw( wp_unslash( $_POST['image'] ) )
			: '';
		
		if ( $image === '' ) {
			$this->error(
				sprintf(
					__( 'تصویر %s معتبر نیست.', 'kasebi-erp' ),
					$singular_label
				)
			);
		}
		
		update_user_meta(
			$customer_id,
			'nooshika_user_avatar_url',
			$image
		);
		$route         = $_POST['page'] ?: sprintf( '/erp/customers/%d/', $customer_id );
		$page_response = KERP_Api_Page_Content::build_page_response(
			$route,
			[],
			TRUE
		);
		
		$this->success(
			sprintf(
				__( 'تصویر با موفقیت ذخیره شد.', 'kasebi-erp' ),
				$singular_label
			),
			$page_response
		);
	}
	
	public function save_profile(): void {
		$this->guard( 'edit' );
		
		$customer_id = isset( $_POST['customer_id'] )
			? absint( wp_unslash( $_POST['customer_id'] ) )
			: 0;
		
		if ( ! $customer_id && isset( $_POST['id'] ) ) {
			$customer_id = absint( wp_unslash( $_POST['id'] ) );
		}
		
		$customer           = get_userdata( $customer_id );
		$customers_settings = KERP_Modules_Customers_Settings::instance();
		$singular_label     = $customers_settings->get_singular_label();
		
		if ( ! $customer instanceof WP_User ) {
			$this->error(
				sprintf(
					__( '%s پیدا نشد.', 'kasebi-erp' ),
					$singular_label
				)
			);
		}

		$history_snapshot = KERP_Modules_Customers_History::instance()->snapshot( $customer_id );
		
		$request_meta = (
			isset( $_POST['meta'] ) &&
			is_array( $_POST['meta'] )
		)
			? wp_unslash( $_POST['meta'] )
			: [];
		
		$first_name = sanitize_text_field(
			(string) ( $request_meta['first_name'] ?? '' )
		);
		
		$last_name = sanitize_text_field(
			(string) ( $request_meta['last_name'] ?? '' )
		);
		
		$email = sanitize_email(
			(string) ( $request_meta['email'] ?? '' )
		);
		
		$phone = $this->normalize_phone(
			sanitize_text_field(
				(string) ( $request_meta['phone'] ?? '' )
			)
		);
		
		if (
			$customers_settings->get( 'require_first_name', TRUE ) &&
			$first_name === ''
		) {
			$this->error(
				__( 'نام را وارد کنید.', 'kasebi-erp' )
			);
		}
		
		if (
			$customers_settings->get( 'require_last_name', TRUE ) &&
			$last_name === ''
		) {
			$this->error(
				__( 'نام خانوادگی را وارد کنید.', 'kasebi-erp' )
			);
		}
		
		if (
			$customers_settings->get( 'require_phone', TRUE ) &&
			$phone === ''
		) {
			$this->error(
				__( 'شماره موبایل را وارد کنید.', 'kasebi-erp' )
			);
		}
		
		if ( $email !== '' ) {
			$existing_email_user_id = email_exists( $email );
			
			if (
				$existing_email_user_id &&
				absint( $existing_email_user_id ) !== $customer_id
			) {
				$this->error(
					__( 'این ایمیل قبلاً برای کاربر دیگری ثبت شده است.', 'kasebi-erp' )
				);
			}
		}
		
		if ( $phone !== '' ) {
			$existing_phone_user_id = $this->find_user_by_phone( $phone );
			
			if (
				$existing_phone_user_id &&
				$existing_phone_user_id !== $customer_id
			) {
				$this->error(
					__( 'این شماره موبایل قبلاً برای کاربر دیگری ثبت شده است.', 'kasebi-erp' )
				);
			}
		}
		
		$user_data = [
			'ID'           => $customer_id,
			'first_name'   => $first_name,
			'last_name'    => $last_name,
			'display_name' => trim( $first_name . ' ' . $last_name )
				?: get_user_name_by_id( $customer_id ),
		];
		
		if ( array_key_exists( 'email', $request_meta ) ) {
			$user_data['user_email'] = $email;
		}
		
		$result = wp_update_user( $user_data );
		
		if ( is_wp_error( $result ) ) {
			$this->error(
				$result->get_error_message()
			);
		}
		
		if ( array_key_exists( 'phone', $request_meta ) ) {
			$phone_meta_key = (string) $customers_settings->get(
				'phone_meta_key',
				'nooshika_phone_num'
			);
			
			update_user_meta(
				$customer_id,
				$phone_meta_key,
				$phone
			);
			
			update_user_meta(
				$customer_id,
				'billing_phone',
				$phone
			);
		}
		if ( array_key_exists( 'owner_id', $request_meta ) ) {
			$owner_id = absint( $request_meta['owner_id'] );
			
			if ( $owner_id > 0 ) {
				$owner = get_userdata( $owner_id );
				
				if ( ! $owner instanceof WP_User ) {
					$this->error(
						__( 'مسئول انتخاب‌شده معتبر نیست.', 'kasebi-erp' )
					);
				}
			}
			
			$owner_meta_key = (string) $customers_settings->get(
				'owner_meta_key',
				'kerp_customer_owner_id'
			);
			
			if ( $owner_id > 0 ) {
				update_user_meta(
					$customer_id,
					$owner_meta_key,
					$owner_id
				);
			} else {
				delete_user_meta(
					$customer_id,
					$owner_meta_key
				);
			}
		}
		$this->save_custom_fields_from_request( $customer_id );
		$this->save_taxonomies_from_request( $customer_id );
		KERP_Modules_Customers_History::instance()->record_snapshot_changes(
			$customer_id,
			$history_snapshot
		);
		
		do_action(
			'kerp_customer_profile_updated',
			$customer_id,
			[
				'meta' => $request_meta,
				'tax'  => (
					isset( $_POST['tax'] ) &&
					is_array( $_POST['tax'] )
				)
					? wp_unslash( $_POST['tax'] )
					: [],
			],
			$customer
		);
		
		$page_response = KERP_Api_Page_Content::build_page_response(
			'/erp/customers/' . $customer_id . '/',
			[],
			TRUE
		);
		
		$page_response['customer_id'] = $customer_id;
		
		$this->success(
			sprintf(
				__( 'اطلاعات %s با موفقیت ذخیره شد.', 'kasebi-erp' ),
				$singular_label
			),
			$page_response
		);
	}
	
	public function delete_customer(): void {
		$this->guard( 'delete' );
		
		$customers_settings = KERP_Modules_Customers_Settings::instance();
		$singular_label     = $customers_settings->get_singular_label();
		
		$customer_id = isset( $_POST['customer_id'] )
			? absint( wp_unslash( $_POST['customer_id'] ) )
			: 0;
		
		if ( ! $customer_id ) {
			$this->error(
				sprintf(
					__( 'شناسه %s معتبر نیست.', 'kasebi-erp' ),
					$singular_label
				)
			);
		}
		
		$customer = get_userdata( $customer_id );
		
		if ( ! $customer instanceof WP_User ) {
			$this->error(
				sprintf(
					__( '%s پیدا نشد.', 'kasebi-erp' ),
					$singular_label
				)
			);
		}
		
		if ( get_current_user_id() === $customer_id ) {
			$this->error(
				sprintf(
					__( 'امکان حذف %s فعلی وجود ندارد.', 'kasebi-erp' ),
					$singular_label
				)
			);
		}
		
		require_once ABSPATH . 'wp-admin/includes/user.php';
		
		$deleted = wp_delete_user( $customer_id );
		
		if ( ! $deleted ) {
			$this->error(
				sprintf(
					__( 'حذف %s با خطا روبه‌رو شد.', 'kasebi-erp' ),
					$singular_label
				)
			);
		}
		
		do_action(
			'kerp_customers_customer_deleted',
			$customer_id,
			$customer
		);
		
		$page_response = KERP_Api_Page_Content::build_page_response(
			'/erp/customers/',
			[],
			TRUE
		);
		
		$this->success(
			sprintf(
				__( '%s با موفقیت حذف شد.', 'kasebi-erp' ),
				$singular_label
			),
			$page_response
		);
	}
	
	public function save_settings(): void {
		$this->guard( 'settings' );
		
		$settings = isset( $_POST['settings'] ) && is_array( $_POST['settings'] )
			? wp_unslash( $_POST['settings'] )
			: wp_unslash( $_POST );
		
		$customers_settings = KERP_Modules_Customers_Settings::instance();
		
		$customers_settings->update( $settings );
		
		$page_response = KERP_Api_Page_Content::build_page_response(
			'/erp/settings/customers/',
			[],
			TRUE
		);
		
		$this->success(
			sprintf(
				__( 'تنظیمات %s ذخیره شد.', 'kasebi-erp' ),
				$customers_settings->get_plural_label()
			),
			$page_response
		);
	}

	public function rebuild_search_index(): void {
		$this->guard( 'settings' );
		if ( ! wp_verify_nonce( $this->post_text( 'index_nonce' ), 'kerp_customers_search_index' ) ) {
			$this->error( __( 'درخواست بازسازی ایندکس معتبر نیست.', 'kasebi-erp' ) );
		}
		$index = KERP_Modules_Customers_Search_Index::instance();
		$result = $index->manual_batch( $this->post_text( 'generation' ) );
		if ( ! empty( $result['error'] ) ) { $this->error( $result['error'] ); }
		$this->success( __( 'دسته ایندکس پردازش شد.', 'kasebi-erp' ), [ 'data' => $result ] );
	}

	public function migrate_first_touch(): void {
		$this->guard( 'settings' );
		$nonce = $this->post_text( 'migration_nonce' );
		if ( ! wp_verify_nonce( $nonce, 'kerp_first_touch_migration' ) ) {
			$this->error( __( 'درخواست انتقال First Touch معتبر نیست.', 'kasebi-erp' ) );
		}

		$result = KERP_Services_Attribution_First_Touch::instance()->migrate_legacy_batch();
		$this->success(
			sprintf( __( '%1$d رکورد منتقل شد؛ %2$d رکورد باقی مانده است.', 'kasebi-erp' ), $result['copied'], $result['remaining'] ),
			[ 'data' => $result ]
		);
	}

	public function migrate_legacy_taxonomies(): void {
		$this->guard( 'settings' );
		$nonce = $this->post_text( 'migration_nonce' );

		if ( ! wp_verify_nonce( $nonce, 'kerp_legacy_taxonomy_migration' ) ) {
			$this->error( __( 'درخواست انتقال دسته‌بندی‌های قدیمی معتبر نیست.', 'kasebi-erp' ) );
		}

		$result = KERP_Modules_Customers_Legacy_Taxonomy_Migration::instance()->migrate_batch();
		$this->success(
			sprintf(
				__( '%1$d کاربر منتقل شد؛ %2$d کاربر باقی مانده است.', 'kasebi-erp' ),
				$result['copied'],
				$result['remaining']
			),
			[ 'data' => $result ]
		);
	}
	
	public function save_fields(): void {
		$this->guard( 'settings' );
		
		$field = isset( $_POST['field'] ) && is_array( $_POST['field'] )
			? wp_unslash( $_POST['field'] )
			: [];
		
		$field_key = sanitize_key(
			(string) ( $field['key'] ?? '' )
		);
		
		$field_label = sanitize_text_field(
			(string) ( $field['label'] ?? '' )
		);
		
		if ( $field_key === '' ) {
			$this->error(
				__( 'کلید فیلد را وارد کنید.', 'kasebi-erp' )
			);
		}
		
		if ( $field_label === '' ) {
			$this->error(
				__( 'عنوان فیلد را وارد کنید.', 'kasebi-erp' )
			);
		}
		
		/*
		 * کلید فیلد و کلید متا یک مقدار هستند.
		 * فیلدهای اختصاصی نیز هیچ‌گاه اجباری نیستند.
		 */
		$field['key']      = $field_key;
		$field['name']     = $field_key;
		$field['meta_key'] = $field_key;
		$field['label']    = $field_label;
		$field['required'] = FALSE;
		
		KERP_Modules_Customers_Fields::instance()->upsert(
			$field
		);
		
		$page_response = KERP_Api_Page_Content::build_page_response(
			'/erp/settings/customers/fields/',
			[],
			TRUE
		);
		
		$this->success(
			__( 'فیلد اختصاصی با موفقیت ذخیره شد.', 'kasebi-erp' ),
			$page_response
		);
	}
	
	public function delete_field(): void {
		$this->guard( 'settings' );
		
		$field_key = sanitize_key(
			$this->post_text( 'key' )
				?: $this->post_text( 'item_id' )
		);
		
		if ( $field_key === '' ) {
			$this->error(
				__( 'شناسه فیلد ارسال نشده است.', 'kasebi-erp' )
			);
		}
		
		KERP_Modules_Customers_Fields::instance()->delete(
			$field_key
		);
		
		$page_response = KERP_Api_Page_Content::build_page_response(
			'/erp/settings/customers/fields/',
			[],
			TRUE
		);
		
		$this->success(
			__( 'فیلد اختصاصی با موفقیت حذف شد.', 'kasebi-erp' ),
			$page_response
		);
	}
	
	public function save_taxonomy_term(): void {
		$this->guard( 'settings' );
		
		$allowed_types = [
			KERP_Modules_Customers_Taxonomies::TYPE_LABEL,
			KERP_Modules_Customers_Taxonomies::TYPE_TAG,
			KERP_Modules_Customers_Taxonomies::TYPE_SOURCE,
		];
		
		$type = sanitize_key(
			$this->post_text( 'type' )
		);
		
		if ( ! in_array( $type, $allowed_types, TRUE ) ) {
			$this->error(
				__( 'نوع مورد ارسال‌شده معتبر نیست.', 'kasebi-erp' )
			);
		}
		
		$active_tab = sanitize_key(
			$this->post_text( 'tab' )
		);
		
		if ( ! in_array( $active_tab, $allowed_types, TRUE ) ) {
			$active_tab = $type;
		}
		
		$raw_term = (
			isset( $_POST['term'] ) &&
			is_array( $_POST['term'] )
		)
			? wp_unslash( $_POST['term'] )
			: [];
		
		/*
		 * term[active] در کامپوننت Switch ممکن است
		 * به‌صورت آرایه [1] ارسال شود.
		 */
		$term_active = ! empty( $raw_term['active'] );
		
		$term = [
			'key' => sanitize_key(
				(string) (
					$raw_term['key'] ??
					$this->post_text( 'key' )
				)
			),
			
			'name' => sanitize_text_field(
				(string) (
					$raw_term['name'] ??
					$this->post_text( 'name' )
				)
			),
			
			'description' => sanitize_textarea_field(
				(string) (
					$raw_term['description'] ??
					$this->post_text( 'description' )
				)
			),
			
			'color' => sanitize_hex_color(
				(string) (
					$raw_term['color'] ??
					$this->post_text( 'color' )
				)
			) ?: '',
			'icon'  => $raw_term['icon'] ?: '',
			
			'active' => $term_active,
			
			'order' => absint(
				$raw_term['order'] ??
				$_POST['order'] ??
				100
			),
		];
		
		if ( $term['key'] === '' ) {
			$this->error(
				__( 'کلید مورد را وارد کنید.', 'kasebi-erp' )
			);
		}
		
		if ( $term['name'] === '' ) {
			$this->error(
				__( 'عنوان مورد را وارد کنید.', 'kasebi-erp' )
			);
		}
		
		$saved = KERP_Modules_Customers_Taxonomies::instance()->save_term( $type, $term );
		
		if ( ! $saved ) {
			$this->error(
				__( 'ذخیره مورد انجام نشد.', 'kasebi-erp' )
			);
		}
		
		$page_response = KERP_Api_Page_Content::build_page_response(
			'/erp/settings/customers/taxonomies/',
			[
				'tab' => $active_tab,
			],
			TRUE
		);
		
		$this->success(
			__( 'مورد با موفقیت ذخیره شد.', 'kasebi-erp' ),
			$page_response
		);
	}
	
	public function delete_taxonomy_term(): void {
		$this->guard( 'settings' );
		
		$allowed_types = [
			KERP_Modules_Customers_Taxonomies::TYPE_LABEL,
			KERP_Modules_Customers_Taxonomies::TYPE_TAG,
			KERP_Modules_Customers_Taxonomies::TYPE_SOURCE,
		];
		
		$type = sanitize_key(
			$this->post_text( 'type' )
		);
		
		if ( ! in_array( $type, $allowed_types, TRUE ) ) {
			$this->error(
				__( 'نوع مورد ارسال‌شده معتبر نیست.', 'kasebi-erp' )
			);
		}
		
		$active_tab = sanitize_key(
			$this->post_text( 'tab' )
		);
		
		if ( ! in_array( $active_tab, $allowed_types, TRUE ) ) {
			$active_tab = $type;
		}
		
		/*
		 * اسکریپت عمومی حذف هم key و هم item_id را
		 * می‌تواند ارسال کند.
		 */
		$term_key = sanitize_key(
			$this->post_text( 'key' ) ?:
				$this->post_text( 'item_id' )
		);
		
		if ( $term_key === '' ) {
			$this->error(
				__( 'شناسه مورد ارسال نشده است.', 'kasebi-erp' )
			);
		}
		
		$deleted = KERP_Modules_Customers_Taxonomies::instance()->delete_term( $type, $term_key );
		
		if ( ! $deleted ) {
			$this->error(
				__( 'حذف مورد انجام نشد.', 'kasebi-erp' )
			);
		}
		
		$page_response = KERP_Api_Page_Content::build_page_response(
			'customers-settings-taxonomies',
			[
				'tab' => $active_tab,
			],
			TRUE
		);
		
		$this->success(
			__( 'مورد با موفقیت حذف شد.', 'kasebi-erp' ),
			$page_response
		);
	}
	
	public function bulk_action(): void {
		$this->guard( 'edit' );
		
		$action_key   = sanitize_key( $this->post_text( 'bulk_action' ) ?: $this->post_text( 'operation' ) );
		$customer_ids = $_POST['customer_ids'] ?? [];
		$customer_ids = is_array( $customer_ids )
			? wp_unslash( $customer_ids )
			: explode( ',', (string) $customer_ids );
		$customer_ids = array_values(
			array_filter(
				array_unique(
					array_map( 'absint', $customer_ids )
				)
			)
		);
		$payload      = isset( $_POST['payload'] ) && is_array( $_POST['payload'] )
			? wp_unslash( $_POST['payload'] )
			: wp_unslash( $_POST );
		$result       = KERP_Modules_Customers_Bulk_Actions::instance()->execute(
			$action_key,
			$customer_ids,
			$payload
		);
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		$customers_settings = KERP_Modules_Customers_Settings::instance();
		$items_label        = count( $customer_ids ) === 1
			? $customers_settings->get_singular_label()
			: $customers_settings->get_plural_label();
		$page_response      = KERP_Api_Page_Content::build_page_response(
			'/erp/customers/',
			[],
			TRUE
		);
		$this->success(
			sprintf(
				__( 'عملیات گروهی برای %1$d %2$s با موفقیت انجام شد.', 'kasebi-erp' ),
				count( $customer_ids ),
				$items_label
			),
			$page_response
		);
	}
	
	private function save_custom_fields_from_request( int $customer_id ): void {
		$fields_service = KERP_Modules_Customers_Fields::instance();
		$fields         = $fields_service->get_all( FALSE );
		
		$request_meta        = isset( $_POST['meta'] ) && is_array( $_POST['meta'] )
			? $_POST['meta']
			: [];
		$processed_meta_keys = [];
		
		/*
		 * ابتدا فیلدهای تعریف‌شده در تنظیمات ذخیره می‌شوند تا
		 * پاک‌سازی مقدار بر اساس نوع فیلد انجام شود.
		 *
		 * هر دو فرمت زیر پشتیبانی می‌شوند:
		 *
		 * meta[field_key]
		 * field_key
		 */
		foreach ( $fields as $field_key => $field ) {
			if ( ! is_array( $field ) ) {
				continue;
			}
			
			$field_key = sanitize_key(
				(string) ( $field['key'] ?? $field_key )
			);
			
			$meta_key = sanitize_key(
				(string) ( $field['meta_key'] ?? $field_key )
			);
			
			if ( $meta_key === '' ) {
				continue;
			}
			
			$value_exists = FALSE;
			$value        = NULL;
			
			if ( array_key_exists( $meta_key, $request_meta ) ) {
				$value_exists = TRUE;
				$value        = $request_meta[ $meta_key ];
			} elseif ( array_key_exists( $field_key, $request_meta ) ) {
				$value_exists = TRUE;
				$value        = $request_meta[ $field_key ];
			} elseif ( array_key_exists( $field_key, $_POST ) ) {
				/*
				 * پشتیبانی از فرم‌های قدیمی که فیلد را مستقیم می‌فرستند.
				 */
				$value_exists = TRUE;
				$value        = $_POST[ $field_key ];
			}
			
			if ( ! $value_exists ) {
				continue;
			}
			
			$value = $fields_service->sanitize_value(
				$value,
				$field
			);
			
			update_user_meta(
				$customer_id,
				$meta_key,
				$value
			);
			
			$processed_meta_keys[ $meta_key ] = TRUE;
		}
		$reserved_meta_keys = [
			'first_name',
			'last_name',
			'email',
			'phone',
			'owner_id',
		];
		/*
		 * هر متای دیگری که داخل meta[...] آمده ولی در فیلدهای
		 * اختصاصی تعریف نشده نیز ذخیره می‌شود.
		 */
		foreach ( $request_meta as $raw_meta_key => $raw_value ) {
			$meta_key = sanitize_key( (string) $raw_meta_key );
			
			if (
				$meta_key === '' ||
				in_array( $meta_key, $reserved_meta_keys, TRUE ) ||
				isset( $processed_meta_keys[ $meta_key ] ) ||
				! $this->can_save_customer_meta( $meta_key )
			) {
				continue;
			}
			
			update_user_meta(
				$customer_id,
				$meta_key,
				$this->sanitize_customer_meta_value( $raw_value )
			);
		}
	}
	
	private function save_taxonomies_from_request( int $customer_id ): void {
		$request_tax = (
			isset( $_POST['tax'] ) &&
			is_array( $_POST['tax'] )
		)
			? wp_unslash( $_POST['tax'] )
			: [];
		
		if ( empty( $request_tax ) ) {
			return;
		}
		
		$taxonomies_service = KERP_Modules_Customers_Taxonomies::instance();
		$definitions        = $taxonomies_service->get_profile_taxonomies();
		
		foreach ( $request_tax as $raw_tax_key => $raw_value ) {
			$tax_key = sanitize_key(
				(string) $raw_tax_key
			);
			
			if (
				$tax_key === '' ||
				! isset( $definitions[ $tax_key ] ) ||
				! is_array( $definitions[ $tax_key ] )
			) {
				continue;
			}
			
			$definition = $definitions[ $tax_key ];
			$multiple   = ! empty( $definition['multiple'] );
			
			if (
				in_array(
					$tax_key,
					[
						KERP_Modules_Customers_Taxonomies::TYPE_LABEL,
						KERP_Modules_Customers_Taxonomies::TYPE_TAG,
						KERP_Modules_Customers_Taxonomies::TYPE_SOURCE,
					],
					TRUE
				)
			) {
				$taxonomies_service->set_customer_terms(
					$customer_id,
					$tax_key,
					$raw_value
				);
				
				continue;
			}
			
			/*
			 * تکسونومی‌های افزوده‌شده با هوک، در متای تعریف‌شده
			 * برای همان تکسونومی ذخیره می‌شوند.
			 */
			$meta_key = sanitize_key(
				(string) ( $definition['meta_key'] ?? $tax_key )
			);
			
			if (
				$meta_key === '' ||
				! $this->can_save_customer_meta( $meta_key )
			) {
				continue;
			}
			
			if ( $multiple ) {
				$value = is_array( $raw_value )
					? $raw_value
					: [ $raw_value ];
				
				$value = array_values(
					array_unique(
						array_filter(
							array_map(
								static fn( mixed $item ): string => sanitize_key( (string) $item ),
								$value
							)
						)
					)
				);
			} else {
				if ( is_array( $raw_value ) ) {
					$raw_value = reset( $raw_value );
				}
				
				$value = sanitize_key(
					(string) $raw_value
				);
			}
			
			update_user_meta(
				$customer_id,
				$meta_key,
				$value
			);
		}
	}
	
	private function build_username( string $phone, string $email ): string {
		$source = (string) KERP_Modules_Customers_Settings::instance()->get( 'username_source', 'phone' );
		
		return match ( $source ) {
			'email' => $email !== '' ? sanitize_user( strstr( $email, '@', TRUE ) ?: $email, TRUE ) : '',
			'generated' => 'customer-' . strtolower( wp_generate_password( 10, FALSE, FALSE ) ),
			default => sanitize_user( $phone, TRUE ),
		};
	}
	
	private function normalize_phone( string $phone ): string {
		if ( function_exists( 'nooshika_sanitize_numbers' ) ) {
			$phone = nooshika_sanitize_numbers( $phone );
		}
		
		$phone = preg_replace( '/[^0-9+]/', '', $phone ) ?? '';
		
		if ( function_exists( 'remove_zero_from_phone' ) ) {
			$phone = (string) remove_zero_from_phone( $phone );
		} else {
			$phone = ltrim( $phone, '0' );
		}
		
		return $phone;
	}
	
	private function find_user_by_phone( string $phone ): int {
		if ( $phone === '' ) {
			return 0;
		}
		
		if ( function_exists( 'get_user_id_by_phone' ) ) {
			return absint( get_user_id_by_phone( $phone ) );
		}
		
		$meta_key = (string) KERP_Modules_Customers_Settings::instance()->get( 'phone_meta_key', 'nooshika_phone_num' );
		$users    = get_users(
			[
				'number'     => 1,
				'fields'     => 'ids',
				'meta_key'   => $meta_key,
				'meta_value' => $phone,
			]
		);
		
		return absint( $users[0] ?? 0 );
	}
	
	private function guard( string $action ): void {
		if ( function_exists( 'kerp_can' ) ) {
			if ( ! kerp_can( 'customers', $action ) ) {
				$this->error( __( 'دسترسی لازم را ندارید.', 'kasebi-erp' ) );
			}
			
			return;
		}
		
		if ( ! current_user_can( 'list_users' ) ) {
			$this->error( __( 'دسترسی لازم را ندارید.', 'kasebi-erp' ) );
		}
	}
	
	private function post_text( string $key ): string {
		if ( ! isset( $_POST[ $key ] ) || is_array( $_POST[ $key ] ) ) {
			return '';
		}
		
		return sanitize_text_field( wp_unslash( $_POST[ $key ] ) );
	}
	
	private function success( string $message, array $data = [] ) {
		wp_send_json(
			array_merge(
				[
					'status'  => 'success',
					'message' => $message,
					'msg'     => $message,
				],
				$data
			)
		);
	}
	
	private function error( string $message, array $data = [] ) {
		wp_send_json(
			array_merge(
				[
					'status'  => 'error',
					'message' => $message,
					'msg'     => $message,
				],
				$data
			)
		);
	}
	
	private function sanitize_customer_meta_value( mixed $value ): mixed {
		if ( is_array( $value ) ) {
			$clean = [];
			
			foreach ( $value as $key => $item ) {
				$clean_key = is_int( $key )
					? $key
					: sanitize_key( (string) $key );
				
				if ( $clean_key === '' ) {
					continue;
				}
				
				$clean[ $clean_key ] = $this->sanitize_customer_meta_value(
					$item
				);
			}
			
			return $clean;
		}
		
		if ( is_bool( $value ) ) {
			return $value ? 1 : 0;
		}
		
		if ( is_int( $value ) || is_float( $value ) ) {
			return $value;
		}
		
		return sanitize_text_field(
			wp_unslash( (string) $value )
		);
	}
	
	private function can_save_customer_meta( string $meta_key ): bool {
		global $wpdb;
		
		$blocked_meta_keys = [
			$wpdb->prefix . 'capabilities',
			$wpdb->prefix . 'user_level',
			'session_tokens',
			'wp_user-settings',
			'wp_user-settings-time',
		];
		
		$blocked_meta_keys = apply_filters(
			'kerp_customers_blocked_profile_meta_keys',
			$blocked_meta_keys,
			$meta_key
		);
		
		if ( in_array( $meta_key, $blocked_meta_keys, TRUE ) ) {
			return FALSE;
		}
		
		if ( is_protected_meta( $meta_key, 'user' ) ) {
			return FALSE;
		}
		
		return (bool) apply_filters(
			'kerp_customers_can_save_profile_meta',
			TRUE,
			$meta_key
		);
	}
	
}
