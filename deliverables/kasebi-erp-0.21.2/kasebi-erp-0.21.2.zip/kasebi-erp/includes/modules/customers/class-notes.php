<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Customers_Notes {
	
	public const VISIBILITY_ALL_STAFF = 'all_staff';
	
	public const VISIBILITY_MANAGERS  = 'managers';
	
	public const VISIBILITY_OWNER     = 'owner';
	
	public const VISIBILITY_PRIVATE   = 'private';
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {
		$this->register_hooks();
	}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	private function register_hooks(): void {
		add_filter( 'kerp_customer_profile_tabs', [ $this, 'register_profile_tab' ], 20, 3 );
		add_filter( 'kerp_customers_profile_dropdown_actions', [ $this, 'register_profile_dropdown_action' ], 20, 3 );
		add_action( 'kerp_customer_profile_before_tab', [ $this, 'render_pinned_notes' ], 10, 3 );
		add_action( 'kerp_customer_profile_modals', [ $this, 'render_profile_modal' ], 10, 4 );
		add_action( 'deleted_user', [ $this, 'delete_customer_notes' ] );
	}
	
	public static function table(): string {
		global $wpdb;
		
		return $wpdb->prefix . 'kasebi_erp_customer_notes';
	}
	
	public static function install(): void {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$table   = self::table();
		$charset = $wpdb->get_charset_collate();
		$sql     = "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			customer_id BIGINT UNSIGNED NOT NULL,
			type VARCHAR(50) NOT NULL DEFAULT 'general',
			content LONGTEXT NOT NULL,
			is_pinned TINYINT(1) UNSIGNED NOT NULL DEFAULT 0,
			visibility VARCHAR(30) NOT NULL DEFAULT 'all_staff',
			created_by BIGINT UNSIGNED NOT NULL,
			updated_by BIGINT UNSIGNED NULL,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NULL,
			PRIMARY KEY  (id),
			KEY idx_customer_id (customer_id),
			KEY idx_customer_pinned (customer_id, is_pinned),
			KEY idx_type (type),
			KEY idx_created_by (created_by),
			KEY idx_created_at (created_at)
		) {$charset};";
		dbDelta( $sql );
	}
	
	public function register_profile_tab( array $tabs, int $customer_id, WP_User $customer ): array {
		if ( ! $this->can( 'view', 'view' ) ) {
			return $tabs;
		}
		$tabs['notes'] = [
			'key'        => 'notes',
			'title'      => __( 'یادداشت‌ها', 'kasebi-erp' ),
			'icon'       => 'ni ni-note-add',
			'order'      => 20,
			'group'      => 'customer-information',
			'permission' => 'customers.notes.view',
			'action'     => 'view',
			'template'   => 'modules/customers/tabs/notes.php',
		];
		
		return $tabs;
	}
	
	public function register_profile_dropdown_action(
		array $actions,
		WP_User $customer,
		array $profile_context
	): array {
		if ( ! $this->can( 'create', 'action' ) ) {
			return $actions;
		}
		
		$actions['add_customer_note'] = [
			'label'      => __( 'افزودن سریع یادداشت', 'kasebi-erp' ),
			'icon'       => 'ni ni-note-add',
			'href'       => '#customerNoteModal',
			'order'      => 20,
			'attributes' => [
				'data-bs-toggle' => 'modal',
				'data-bs-target' => '#customerNoteModal',
			],
		];
		
		return $actions;
	}
	
	public function render_pinned_notes( int $customer_id, WP_User $customer, array $profile_context ): void {
		if ( ! $this->can( 'view', 'view' ) ) {
			return;
		}
		$notes = KERP_Modules_Customers_Notes_Query::instance()->get_pinned_by_customer( $customer_id );
		if ( empty( $notes ) ) {
			return;
		}
		KERP_Helpers_Template::render_template(
			'modules/customers/partials/pinned-notes.php',
			[
				'customer'        => $customer,
				'customer_id'     => $customer_id,
				'notes'           => $notes,
				'profile_context' => $profile_context,
			]
		);
	}
	
	public function render_profile_modal(
		int $customer_id,
		WP_User $customer,
		array $profile_context,
		string $active_tab
	): void {
		if (
			! $this->can( 'create', 'action' ) &&
			! $this->can( 'edit', 'action' )
		) {
			return;
		}
		
		$return_page = (string) (
			$profile_context['url']
			?? '/erp/customers/' . $customer_id . '/'
		);
		
		KERP_Helpers_Template::render_template(
			'modules/customers/modals/note-form.php',
			[
				'customer_id' => $customer_id,
				'customer'    => $customer,
				'return_page' => $return_page,
			]
		);
	}
	
	public function get_types(): array {
		$types = [
			'general'      => [
				'label'       => __( 'یادداشت عمومی', 'kasebi-erp' ),
				'icon'        => 'ni ni-note-add',
				'badge_class' => 'bg-outline-primary',
			],
			'important'    => [
				'label'       => __( 'نکته مهم', 'kasebi-erp' ),
				'icon'        => 'ni ni-alert-circle',
				'badge_class' => 'bg-outline-warning',
			],
			'preference'   => [
				'label'       => sprintf( __( 'ترجیحات %s', 'kasebi-erp' ), KERP_Modules_Customers_Settings::instance()->get_singular_label() ),
				'icon'        => 'ni ni-user-check',
				'badge_class' => 'bg-outline-info',
			],
			'financial'    => [
				'label'       => __( 'نکته مالی', 'kasebi-erp' ),
				'icon'        => 'ni ni-coins',
				'badge_class' => 'bg-outline-success',
			],
			'confidential' => [
				'label'       => __( 'محرمانه', 'kasebi-erp' ),
				'icon'        => 'ni ni-lock-alt',
				'badge_class' => 'bg-outline-danger',
			],
		];
		$types = apply_filters( 'kerp_customer_note_types', $types );
		
		return is_array( $types ) ? $types : [];
	}
	
	public function get_type_options(): array {
		$options = [];
		foreach ( $this->get_types() as $key => $type ) {
			$options[ sanitize_key( (string) $key ) ] = sanitize_text_field( (string) ( $type['label'] ?? $key ) );
		}
		
		return $options;
	}
	
	public function get_type( string $type ): array {
		$types = $this->get_types();
		$type  = sanitize_key( $type );
		if ( isset( $types[ $type ] ) && is_array( $types[ $type ] ) ) {
			return $types[ $type ];
		}
		if ( isset( $types['general'] ) && is_array( $types['general'] ) ) {
			return $types['general'];
		}
		
		return [
			'label'       => __( 'یادداشت عمومی', 'kasebi-erp' ),
			'icon'        => 'ni ni-note-add',
			'badge_class' => 'bg-outline-primary',
		];
	}
	
	public function get_visibilities(): array {
		$visibilities = [
			self::VISIBILITY_ALL_STAFF => __( 'همه کارکنان', 'kasebi-erp' ),
			self::VISIBILITY_MANAGERS  => __( 'فقط مدیران', 'kasebi-erp' ),
			self::VISIBILITY_OWNER     => sprintf( __( 'فقط مسئول %s', 'kasebi-erp' ), KERP_Modules_Customers_Settings::instance()->get_singular_label() ),
			self::VISIBILITY_PRIVATE   => __( 'فقط ثبت‌کننده', 'kasebi-erp' ),
		];
		$visibilities = apply_filters( 'kerp_customer_note_visibilities', $visibilities );
		
		return is_array( $visibilities ) ? $visibilities : [];
	}
	
	public function get_visibility_label( string $visibility ): string {
		$visibilities = $this->get_visibilities();
		
		return (string) ( $visibilities[ sanitize_key( $visibility ) ] ?? $visibilities[ self::VISIBILITY_ALL_STAFF ] );
	}
	
	public function save( array $data, int $note_id = 0 ): int|WP_Error {
		global $wpdb;
		$note_id     = absint( $note_id );
		$customer_id = absint( $data['customer_id'] ?? 0 );
		$customer    = get_userdata( $customer_id );
		if ( ! $customer instanceof WP_User ) {
			return new WP_Error( 'kerp_customer_note_invalid_customer', sprintf( __( '%s معتبر نیست.', 'kasebi-erp' ), KERP_Modules_Customers_Settings::instance()->get_singular_label() ) );
		}
		$types = $this->get_types();
		$type  = sanitize_key( (string) ( $data['type'] ?? 'general' ) );
		if ( ! isset( $types[ $type ] ) ) {
			$type = 'general';
		}
		$visibilities = $this->get_visibilities();
		$visibility   = sanitize_key( (string) ( $data['visibility'] ?? self::VISIBILITY_ALL_STAFF ) );
		if ( ! isset( $visibilities[ $visibility ] ) ) {
			$visibility = self::VISIBILITY_ALL_STAFF;
		}
		$content = sanitize_textarea_field( (string) ( $data['content'] ?? '' ) );
		if ( $content === '' ) {
			return new WP_Error( 'kerp_customer_note_empty_content', __( 'متن یادداشت را وارد کنید.', 'kasebi-erp' ) );
		}
		$now     = current_time( 'mysql' );
		$user_id = get_current_user_id();
		$record  = [
			'customer_id' => $customer_id,
			'type'        => $type,
			'content'     => $content,
			'is_pinned'   => ! empty( $data['is_pinned'] ) ? 1 : 0,
			'visibility'  => $visibility,
			'updated_by'  => $user_id,
			'updated_at'  => $now,
		];
		if ( $note_id ) {
			$existing = KERP_Modules_Customers_Notes_Query::instance()->get_by_id( $note_id );
			if ( ! $existing ) {
				return new WP_Error( 'kerp_customer_note_not_found', __( 'یادداشت پیدا نشد.', 'kasebi-erp' ) );
			}
			if ( (int) $existing['customer_id'] !== $customer_id ) {
				return new WP_Error( 'kerp_customer_note_customer_mismatch', sprintf( __( 'یادداشت متعلق به این %s نیست.', 'kasebi-erp' ), KERP_Modules_Customers_Settings::instance()->get_singular_label() ) );
			}
			$result = $wpdb->update(
				self::table(),
				$record,
				[ 'id' => $note_id ],
				[ '%d', '%s', '%s', '%d', '%s', '%d', '%s' ],
				[ '%d' ]
			);
			if ( $result === FALSE ) {
				return new WP_Error( 'kerp_customer_note_update_failed', __( 'ویرایش یادداشت انجام نشد.', 'kasebi-erp' ) );
			}
			do_action( 'kerp_customer_note_updated', $note_id, $customer_id, $record, $existing );
			
			return $note_id;
		}
		$record['created_by'] = $user_id;
		$record['created_at'] = $now;
		$result               = $wpdb->insert(
			self::table(),
			$record,
			[ '%d', '%s', '%s', '%d', '%s', '%d', '%s', '%d', '%s' ]
		);
		if ( $result === FALSE ) {
			return new WP_Error( 'kerp_customer_note_insert_failed', __( 'ثبت یادداشت انجام نشد.', 'kasebi-erp' ) );
		}
		$note_id = (int) $wpdb->insert_id;
		do_action( 'kerp_customer_note_created', $note_id, $customer_id, $record );
		
		return $note_id;
	}
	
	public function delete( int $note_id ): bool|WP_Error {
		global $wpdb;
		$note = KERP_Modules_Customers_Notes_Query::instance()->get_by_id( $note_id );
		if ( ! $note ) {
			return new WP_Error( 'kerp_customer_note_not_found', __( 'یادداشت پیدا نشد.', 'kasebi-erp' ) );
		}
		$result = $wpdb->delete( self::table(), [ 'id' => $note_id ], [ '%d' ] );
		if ( $result === FALSE ) {
			return new WP_Error( 'kerp_customer_note_delete_failed', __( 'حذف یادداشت انجام نشد.', 'kasebi-erp' ) );
		}
		do_action( 'kerp_customer_note_deleted', $note_id, (int) $note['customer_id'], $note );
		
		return TRUE;
	}
	
	public function can_view_note( array $note ): bool {
		if ( ! $this->can( 'view', 'view' ) ) {
			return FALSE;
		}
		if ( $this->can( 'view_confidential', 'view' ) ) {
			return TRUE;
		}
		$current_user_id = get_current_user_id();
		$visibility      = sanitize_key( (string) ( $note['visibility'] ?? self::VISIBILITY_ALL_STAFF ) );
		
		return match ( $visibility ) {
			self::VISIBILITY_PRIVATE => (int) ( $note['created_by'] ?? 0 ) === $current_user_id,
			self::VISIBILITY_OWNER => $this->get_customer_owner_id( (int) ( $note['customer_id'] ?? 0 ) ) === $current_user_id,
			self::VISIBILITY_MANAGERS => FALSE,
			default => TRUE,
		};
	}
	
	public function get_populate_data( array $note ): array {
		return [
			'note_id'    => [
				'id'    => '#kerp-customer-note-id',
				'type'  => 'text',
				'value' => absint( $note['id'] ?? 0 ),
			],
			'type'       => [
				'id'    => '#kerp-customer-note-type',
				'type'  => 'select',
				'value' => sanitize_key( (string) ( $note['type'] ?? 'general' ) ),
			],
			'visibility' => [
				'id'    => '#kerp-customer-note-visibility',
				'type'  => 'select',
				'value' => sanitize_key( (string) ( $note['visibility'] ?? self::VISIBILITY_ALL_STAFF ) ),
			],
			'content'    => [
				'id'    => '#kerp-customer-note-content',
				'type'  => 'text',
				'value' => (string) ( $note['content'] ?? '' ),
			],
			'is_pinned'  => [
				'id'    => '#kerp-customer-note-is-pinned',
				'type'  => 'switch',
				'value' => ! empty( $note['is_pinned'] ) ? 1 : 0,
			],
		];
	}
	
	public function delete_customer_notes( int $customer_id ): void {
		global $wpdb;
		$wpdb->delete( self::table(), [ 'customer_id' => $customer_id ], [ '%d' ] );
	}
	
	private function get_customer_owner_id( int $customer_id ): int {
		$owner_meta_key = (string) KERP_Modules_Customers_Settings::instance()->get(
			'owner_meta_key',
			'kerp_customer_owner_id'
		);
		
		return absint( get_user_meta( $customer_id, $owner_meta_key, TRUE ) );
	}
	
	private function can( string $action, string $type = 'action' ): bool {
		return kerp_can( 'customers.notes.' . sanitize_key( $action ), $type );
	}
	
}
