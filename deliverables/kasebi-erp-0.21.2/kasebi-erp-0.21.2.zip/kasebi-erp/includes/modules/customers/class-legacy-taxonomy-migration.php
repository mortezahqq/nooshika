<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Customers_Legacy_Taxonomy_Migration {

	private const MARKER_META_KEY = '_kerp_legacy_customer_taxonomies_migrated';

	private const LEGACY_OWNER_META_KEY = 'ncp_user_marketer_id';

	private const VERSION = 2;

	private const MAP = [
		'user-type'  => KERP_Modules_Customers_Taxonomies::TYPE_LABEL,
		'user-group' => KERP_Modules_Customers_Taxonomies::TYPE_TAG,
	];

	private static ?self $instance = NULL;

	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	private function __construct() {}

	private function __clone() {}

	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}

	public function status(): array {
		global $wpdb;

		$taxonomies = array_keys( self::MAP );
		$placeholders = implode( ', ', array_fill( 0, count( $taxonomies ), '%s' ) );
		$legacy_term_rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT term_id, taxonomy FROM {$wpdb->term_taxonomy} WHERE taxonomy IN ({$placeholders})",
				...$taxonomies
			),
			ARRAY_A
		);
		$term_total = count( $legacy_term_rows );
		$term_migrated = $this->count_migrated_options( $legacy_term_rows );
		$source_user_sql = "SELECT DISTINCT tr.object_id AS user_id
			FROM {$wpdb->term_relationships} tr
			INNER JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id = tr.term_taxonomy_id
			INNER JOIN {$wpdb->users} u ON u.ID = tr.object_id
			WHERE tt.taxonomy IN ({$placeholders})
			UNION
			SELECT DISTINCT legacy_owner.user_id
			FROM {$wpdb->usermeta} legacy_owner
			INNER JOIN {$wpdb->users} u ON u.ID = legacy_owner.user_id
			WHERE legacy_owner.meta_key = %s
				AND CAST(legacy_owner.meta_value AS UNSIGNED) > 0";
		$source_user_params = array_merge( $taxonomies, [ self::LEGACY_OWNER_META_KEY ] );

		$user_total = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM ({$source_user_sql}) legacy_users",
				...$source_user_params
			)
		);
		$owner_total = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(DISTINCT legacy_owner.user_id)
				 FROM {$wpdb->usermeta} legacy_owner
				 INNER JOIN {$wpdb->users} u ON u.ID = legacy_owner.user_id
				 WHERE legacy_owner.meta_key = %s
				 	AND CAST(legacy_owner.meta_value AS UNSIGNED) > 0",
				self::LEGACY_OWNER_META_KEY
			)
		);

		$params = array_merge( $source_user_params, [ self::MARKER_META_KEY, self::VERSION ] );
		$migrated = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(DISTINCT legacy_users.user_id)
				 FROM ({$source_user_sql}) legacy_users
				 INNER JOIN {$wpdb->usermeta} marker
				 	ON marker.user_id = legacy_users.user_id
				 	AND marker.meta_key = %s AND marker.meta_value = %d",
				...$params
			)
		);

		$remaining      = max( 0, $user_total - $migrated );
		$term_remaining = max( 0, $term_total - $term_migrated );

		return [
			'available'     => $term_total > 0 || $user_total > 0,
			'term_total'    => $term_total,
			'term_migrated' => $term_migrated,
			'term_remaining' => $term_remaining,
			'owner_total'   => $owner_total,
			'total'         => $user_total,
			'migrated'      => min( $user_total, $migrated ),
			'remaining'     => $remaining,
			'work_remaining' => $remaining + $term_remaining,
			'complete'      => $remaining === 0 && $term_remaining === 0,
		];
	}

	public function migrate_batch( int $limit = 100 ): array {
		global $wpdb;

		$limit    = max( 1, min( 500, $limit ) );
		$term_map = $this->migrate_options();
		$taxonomies = array_keys( self::MAP );
		$placeholders = implode( ', ', array_fill( 0, count( $taxonomies ), '%s' ) );
		$source_user_sql = "SELECT DISTINCT tr.object_id AS user_id
			FROM {$wpdb->term_relationships} tr
			INNER JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id = tr.term_taxonomy_id
			INNER JOIN {$wpdb->users} u ON u.ID = tr.object_id
			WHERE tt.taxonomy IN ({$placeholders})
			UNION
			SELECT DISTINCT legacy_owner.user_id
			FROM {$wpdb->usermeta} legacy_owner
			INNER JOIN {$wpdb->users} u ON u.ID = legacy_owner.user_id
			WHERE legacy_owner.meta_key = %s
				AND CAST(legacy_owner.meta_value AS UNSIGNED) > 0";
		$user_ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT legacy_users.user_id
				 FROM ({$source_user_sql}) legacy_users
				 LEFT JOIN {$wpdb->usermeta} marker
				 	ON marker.user_id = legacy_users.user_id
				 	AND marker.meta_key = %s AND marker.meta_value = %d
				 WHERE marker.umeta_id IS NULL
				 ORDER BY legacy_users.user_id ASC
				 LIMIT %d",
				...array_merge(
					$taxonomies,
					[ self::LEGACY_OWNER_META_KEY, self::MARKER_META_KEY, self::VERSION ],
					[ $limit ]
				)
			)
		);

		if ( empty( $user_ids ) ) {
			return array_merge( $this->status(), [ 'copied' => 0 ] );
		}

		$user_ids = array_values( array_filter( array_map( 'absint', $user_ids ) ) );
		$id_placeholders = implode( ', ', array_fill( 0, count( $user_ids ), '%d' ) );
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT tr.object_id AS user_id, tt.taxonomy, tt.term_id
				 FROM {$wpdb->term_relationships} tr
				 INNER JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id = tr.term_taxonomy_id
				 WHERE tr.object_id IN ({$id_placeholders}) AND tt.taxonomy IN ({$placeholders})",
				...array_merge( $user_ids, $taxonomies )
			),
			ARRAY_A
		);

		$assignments = [];

		foreach ( $rows as $row ) {
			$user_id  = absint( $row['user_id'] ?? 0 );
			$taxonomy = (string) ( $row['taxonomy'] ?? '' );
			$term_id  = absint( $row['term_id'] ?? 0 );
			$type     = self::MAP[ $taxonomy ] ?? '';
			$term_key = $term_map[ $taxonomy ][ $term_id ] ?? '';

			if ( $user_id && $type !== '' && $term_key !== '' ) {
				$assignments[ $user_id ][ $type ][] = $term_key;
			}
		}

		$taxonomies_service = KERP_Modules_Customers_Taxonomies::instance();
		$owner_meta_key = sanitize_key(
			(string) KERP_Modules_Customers_Settings::instance()->get(
				'owner_meta_key',
				'kerp_customer_owner_id'
			)
		);
		$owner_meta_key = $owner_meta_key !== '' ? $owner_meta_key : 'kerp_customer_owner_id';
		$copied        = 0;
		$owner_copied  = 0;
		$owner_skipped = 0;

		foreach ( $user_ids as $user_id ) {
			foreach ( array_values( self::MAP ) as $type ) {
				$legacy_keys = $assignments[ $user_id ][ $type ] ?? [];

				if ( empty( $legacy_keys ) ) {
					continue;
				}

				$current = (array) $taxonomies_service->get_customer_terms( $user_id, $type );
				$merged  = array_values( array_unique( array_merge( $current, $legacy_keys ) ) );
				$taxonomies_service->set_customer_terms( $user_id, $type, $merged );
			}

			$legacy_owner_id = absint( get_user_meta( $user_id, self::LEGACY_OWNER_META_KEY, TRUE ) );

			if ( $legacy_owner_id > 0 ) {
				$current_owner_id = absint( get_user_meta( $user_id, $owner_meta_key, TRUE ) );

				if ( $current_owner_id > 0 ) {
					$owner_skipped ++;
				} elseif ( get_userdata( $legacy_owner_id ) instanceof WP_User ) {
					update_user_meta( $user_id, $owner_meta_key, $legacy_owner_id );
					$owner_copied ++;
				} else {
					$owner_skipped ++;
				}
			}

			update_user_meta( $user_id, self::MARKER_META_KEY, self::VERSION );
			$copied ++;
		}

		return array_merge(
			$this->status(),
			[
				'copied'        => $copied,
				'owner_copied'  => $owner_copied,
				'owner_skipped' => $owner_skipped,
			]
		);
	}

	private function migrate_options(): array {
		global $wpdb;

		$taxonomies = array_keys( self::MAP );
		$placeholders = implode( ', ', array_fill( 0, count( $taxonomies ), '%s' ) );
		$legacy_terms = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT t.term_id, t.name, t.slug, tt.taxonomy, tt.description
				 FROM {$wpdb->terms} t
				 INNER JOIN {$wpdb->term_taxonomy} tt ON tt.term_id = t.term_id
				 WHERE tt.taxonomy IN ({$placeholders})
				 ORDER BY t.term_id ASC",
				...$taxonomies
			),
			ARRAY_A
		);

		$all = get_option( KERP_Modules_Customers_Taxonomies::OPTION_NAME, [] );
		$all = is_array( $all ) ? $all : [];
		$map = [];

		foreach ( $legacy_terms as $index => $legacy_term ) {
			$taxonomy = (string) ( $legacy_term['taxonomy'] ?? '' );
			$type     = self::MAP[ $taxonomy ] ?? '';
			$term_id  = absint( $legacy_term['term_id'] ?? 0 );

			if ( $type === '' || ! $term_id ) {
				continue;
			}

			$all[ $type ] = isset( $all[ $type ] ) && is_array( $all[ $type ] ) ? $all[ $type ] : [];
			$key = $this->find_destination_key( $all[ $type ], $taxonomy, $term_id, (string) $legacy_term['name'] );

			if ( $key === '' ) {
				$key = sanitize_key( 'legacy-' . $taxonomy . '-' . $term_id );
			}

			if ( isset( $all[ $type ][ $key ] ) && is_array( $all[ $type ][ $key ] ) ) {
				$all[ $type ][ $key ]['legacy_taxonomy'] = $taxonomy;
				$all[ $type ][ $key ]['legacy_term_id']  = $term_id;
			} else {
				$all[ $type ][ $key ] = [
					'key'             => $key,
					'name'            => sanitize_text_field( (string) $legacy_term['name'] ),
					'description'     => sanitize_textarea_field( (string) $legacy_term['description'] ),
					'color'           => '',
					'icon'            => '',
					'active'          => TRUE,
					'order'           => 100 + $index,
					'legacy_taxonomy' => $taxonomy,
					'legacy_term_id'  => $term_id,
				];
			}

			$map[ $taxonomy ][ $term_id ] = $key;
		}

		update_option( KERP_Modules_Customers_Taxonomies::OPTION_NAME, $all, FALSE );
		KERP_Modules_Customers_Taxonomies::instance()->clear_cache();

		return $map;
	}

	private function find_destination_key( array $terms, string $taxonomy, int $term_id, string $name ): string {
		foreach ( $terms as $key => $term ) {
			if ( ! is_array( $term ) ) {
				continue;
			}

			if (
				(string) ( $term['legacy_taxonomy'] ?? '' ) === $taxonomy
				&& absint( $term['legacy_term_id'] ?? 0 ) === $term_id
			) {
				return sanitize_key( (string) $key );
			}
		}

		foreach ( $terms as $key => $term ) {
			if (
				is_array( $term )
				&& (string) ( $term['name'] ?? '' ) === $name
				&& empty( $term['legacy_term_id'] )
			) {
				return sanitize_key( (string) $key );
			}
		}

		return '';
	}

	private function count_migrated_options( array $legacy_terms ): int {
		$expected = [];

		foreach ( $legacy_terms as $legacy_term ) {
			$taxonomy = (string) ( $legacy_term['taxonomy'] ?? '' );
			$term_id  = absint( $legacy_term['term_id'] ?? 0 );

			if ( isset( self::MAP[ $taxonomy ] ) && $term_id ) {
				$expected[ $taxonomy . ':' . $term_id ] = TRUE;
			}
		}

		$stored = get_option( KERP_Modules_Customers_Taxonomies::OPTION_NAME, [] );
		$stored = is_array( $stored ) ? $stored : [];
		$found  = [];

		foreach ( self::MAP as $taxonomy => $type ) {
			$terms = isset( $stored[ $type ] ) && is_array( $stored[ $type ] ) ? $stored[ $type ] : [];

			foreach ( $terms as $term ) {
				if ( ! is_array( $term ) || (string) ( $term['legacy_taxonomy'] ?? '' ) !== $taxonomy ) {
					continue;
				}

				$signature = $taxonomy . ':' . absint( $term['legacy_term_id'] ?? 0 );

				if ( isset( $expected[ $signature ] ) ) {
					$found[ $signature ] = TRUE;
				}
			}
		}

		return count( $found );
	}
}
