<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Customers_History {
	private const SCHEMA_VERSION = '1.0.0';

	private const SCHEMA_VERSION_OPTION = 'kerp_customer_meta_history_schema_version';

	private static ?self $instance = NULL;

	private array $pending_updates = [];

	private array $pending_deletes = [];

	private array $recorded_fingerprints = [];

	private array $field_definitions = [];

	private bool $table_ready = FALSE;

	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	private function __construct() {
		$this->maybe_install();
		$this->table_ready = self::table_exists();
		add_filter( 'kerp_customer_profile_tabs', [ $this, 'register_profile_tab' ], 25, 3 );
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_assets' ] );
		add_action( 'kasebi_ajax_customers_history_load_more', [ $this, 'ajax_load_more' ] );
		add_action( 'deleted_user', [ $this, 'delete_customer_history' ] );
	}

	private function __clone() {}

	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}

	public static function table(): string {
		global $wpdb;

		return $wpdb->prefix . 'kerp_customer_meta_history';
	}

	public static function install(): void {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$table   = self::table();
		$charset = $wpdb->get_charset_collate();
		$sql     = "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			customer_id BIGINT UNSIGNED NOT NULL,
			meta_key VARCHAR(255) NOT NULL,
			event_type VARCHAR(20) NOT NULL,
			old_value LONGTEXT NULL,
			new_value LONGTEXT NULL,
			actor_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY idx_customer_created (customer_id, created_at),
			KEY idx_customer_meta (customer_id, meta_key(191)),
			KEY idx_actor (actor_id)
		) {$charset};";

		dbDelta( $sql );

		if ( self::table_exists() ) {
			update_option( self::SCHEMA_VERSION_OPTION, self::SCHEMA_VERSION, FALSE );
		}
	}

	public static function table_exists(): bool {
		global $wpdb;

		$table = self::table();

		return $wpdb->get_var(
			$wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $table ) )
		) === $table;
	}

	public function maybe_install(): void {
		if (
			(string) get_option( self::SCHEMA_VERSION_OPTION, '' ) !== self::SCHEMA_VERSION
			|| ! self::table_exists()
		) {
			self::install();
		}
	}

	public function enqueue_assets(): void {
		if ( ! kerp_is_erp_request() ) {
			return;
		}

		wp_enqueue_script(
			'kerp-customer-history',
			KERP_ASSETS_URL . 'app/js/modules/customer-history.js',
			[ 'kerp-app' ],
			kerp_asset_version( 'app/js/modules/customer-history.js' ),
			TRUE
		);
	}

	public function register_profile_tab( array $tabs, int $customer_id, WP_User $customer ): array {
		if (
			! kerp_can( 'customers.history.view', 'view' )
			|| ! $this->can_view_customer( $customer_id )
		) {
			return $tabs;
		}

		$tabs['history'] = [
			'key'        => 'history',
			'title'      => __( 'سوابق تغییرات', 'kasebi-erp' ),
			'icon'       => 'ni ni-history',
			'order'      => 999,
			'permission' => 'customers.history.view',
			'action'     => 'view',
			'template'   => 'modules/customers/tabs/history.php',
		];

		return $tabs;
	}

	public function capture_added_meta( int $meta_id, int $customer_id, string $meta_key, mixed $meta_value ): void {
		if ( ! $this->should_record( $customer_id, $meta_key, $meta_value ) ) {
			return;
		}

		$this->insert( $customer_id, $meta_key, 'added', NULL, $meta_value );
	}

	public function capture_update( int $meta_id, int $customer_id, string $meta_key, mixed $new_value ): void {
		if ( ! $this->should_record( $customer_id, $meta_key, $new_value ) ) {
			return;
		}

		$metadata = get_metadata_by_mid( 'user', $meta_id );
		$this->pending_updates[ $meta_id ] = $metadata ? $metadata->meta_value : NULL;
	}

	public function record_update( int $meta_id, int $customer_id, string $meta_key, mixed $new_value ): void {
		if ( ! array_key_exists( $meta_id, $this->pending_updates ) ) {
			return;
		}

		$old_value = $this->pending_updates[ $meta_id ];
		unset( $this->pending_updates[ $meta_id ] );

		if ( $this->values_equal( $old_value, $new_value ) ) {
			return;
		}

		$this->insert( $customer_id, $meta_key, 'updated', $old_value, $new_value );
	}

	public function capture_delete( array $meta_ids, int $customer_id, string $meta_key, mixed $meta_value ): void {
		if ( ! $this->should_record( $customer_id, $meta_key, $meta_value ) ) {
			return;
		}

		$this->pending_deletes[ $this->delete_key( $customer_id, $meta_key ) ] = $this->normalize_value_list(
			get_user_meta( $customer_id, $meta_key, FALSE )
		);
	}

	public function record_delete( array $meta_ids, int $customer_id, string $meta_key, mixed $meta_value ): void {
		$key = $this->delete_key( $customer_id, $meta_key );

		if ( ! array_key_exists( $key, $this->pending_deletes ) ) {
			return;
		}

		$old_value = $this->pending_deletes[ $key ];
		unset( $this->pending_deletes[ $key ] );
		$new_value = $this->normalize_value_list( get_user_meta( $customer_id, $meta_key, FALSE ) );

		$this->insert( $customer_id, $meta_key, 'deleted', $old_value, $new_value );
	}

	public function find( int $customer_id, array $args = [] ): array {
		global $wpdb;

		$customer_id = absint( $customer_id );
		$per_page    = max( 1, min( 100, absint( $args['per_page'] ?? 20 ) ) );
		$page_number = max( 1, absint( $args['page_number'] ?? 1 ) );
		$event_type  = sanitize_key( (string) ( $args['event_type'] ?? '' ) );
		$meta_key    = sanitize_text_field( (string) ( $args['meta_key'] ?? '' ) );
		$where       = [ 'customer_id = %d' ];
		$params      = [ $customer_id ];
		$meta_keys   = $this->get_trackable_meta_keys( $customer_id );

		if ( $meta_keys === [] ) {
			return [
				'items'       => [],
				'total'       => 0,
				'total_pages' => 1,
				'page_number' => 1,
				'per_page'    => $per_page,
			];
		}

		$where[] = 'meta_key IN (' . implode( ', ', array_fill( 0, count( $meta_keys ), '%s' ) ) . ')';
		$params  = array_merge( $params, $meta_keys );

		if ( in_array( $event_type, [ 'added', 'updated', 'deleted' ], TRUE ) ) {
			$where[]  = 'event_type = %s';
			$params[] = $event_type;
		}

		if ( $meta_key !== '' ) {
			$where[]  = 'meta_key LIKE %s';
			$params[] = '%' . $wpdb->esc_like( $meta_key ) . '%';
		}

		$where_sql = implode( ' AND ', $where );
		$table     = self::table();
		$total     = (int) $wpdb->get_var(
			$wpdb->prepare( "SELECT COUNT(id) FROM {$table} WHERE {$where_sql}", ...$params )
		);
		$total_pages = max( 1, (int) ceil( $total / $per_page ) );
		$page_number = min( $page_number, $total_pages );
		$query_params = array_merge( $params, [ ( $page_number - 1 ) * $per_page, $per_page ] );
		$items = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE {$where_sql} ORDER BY id DESC LIMIT %d, %d",
				...$query_params
			),
			ARRAY_A
		);

		return [
			'items'       => is_array( $items ) ? $items : [],
			'total'       => $total,
			'total_pages' => $total_pages,
			'page_number' => $page_number,
			'per_page'    => $per_page,
		];
	}

	public function snapshot( int $customer_id ): array {
		$snapshot = [];

		foreach ( get_user_meta( $customer_id ) as $meta_key => $values ) {
			$meta_key = (string) $meta_key;

			if ( ! $this->should_record( $customer_id, $meta_key, $values ) ) {
				continue;
			}

			$snapshot[ $meta_key ] = $this->normalize_value_list( is_array( $values ) ? $values : [ $values ] );
		}

		return $snapshot;
	}

	public function record_snapshot_changes( int $customer_id, array $before ): void {
		$after = $this->snapshot( $customer_id );
		$keys  = array_unique( array_merge( array_keys( $before ), array_keys( $after ) ) );

		foreach ( $keys as $meta_key ) {
			$had_old = array_key_exists( $meta_key, $before );
			$has_new = array_key_exists( $meta_key, $after );
			$old     = $had_old ? $before[ $meta_key ] : NULL;
			$new     = $has_new ? $after[ $meta_key ] : NULL;

			if ( $this->values_equal( $old, $new ) ) {
				continue;
			}

			$event_type = ! $had_old ? 'added' : ( ! $has_new ? 'deleted' : 'updated' );
			$this->insert( $customer_id, (string) $meta_key, $event_type, $old, $new );
		}
	}

	public function ajax_load_more(): void {
		if (
			! is_user_logged_in()
			|| ! KERP_App::instance()->current_user_has_access()
			|| ! kerp_can( 'customers.history.view', 'view' )
		) {
			$this->send_error( __( 'شما اجازه مشاهده سوابق تغییرات را ندارید.', 'kasebi-erp' ) );
		}

		$customer_id = absint( $_POST['customer_id'] ?? 0 );
		$customer    = KERP_Modules_Customers_Query::instance()->get_customer( $customer_id );

		if ( ! $customer instanceof WP_User ) {
			$this->send_error( __( 'کاربر پیدا نشد.', 'kasebi-erp' ) );
		}

		if ( ! $this->can_view_customer( $customer_id ) ) {
			$this->send_error( __( 'این کاربر خارج از دامنه دسترسی شما است.', 'kasebi-erp' ) );
		}

		$page_number = max( 2, absint( $_POST['page_number'] ?? 2 ) );
		$per_page    = max( 1, min( 100, absint( $_POST['per_page'] ?? 20 ) ) );
		$result      = $this->find(
			$customer_id,
			[
				'event_type'  => sanitize_key( wp_unslash( (string) ( $_POST['event_type'] ?? '' ) ) ),
				'page_number' => $page_number,
				'per_page'    => $per_page,
			]
		);
		$html = '';

		foreach ( (array) ( $result['items'] ?? [] ) as $item ) {
			$html .= KERP_Helpers_Template::get_template(
				'modules/customers/partials/history-item.php',
				[
					'item'        => $item,
					'customer_id' => $customer_id,
					'service'     => $this,
				]
			);
		}

		$current_page = max( 1, absint( $result['page_number'] ?? $page_number ) );
		$total_pages  = max( 1, absint( $result['total_pages'] ?? 1 ) );

		wp_send_json(
			[
				'status'      => 'success',
				'message'     => '',
				'html'        => $html,
				'page_number' => $current_page,
				'next_page'   => $current_page + 1,
				'has_more'    => $current_page < $total_pages,
			]
		);
	}

	public function event_labels(): array {
		return [
			'added'   => __( 'افزوده شد', 'kasebi-erp' ),
			'updated' => __( 'ویرایش شد', 'kasebi-erp' ),
			'deleted' => __( 'حذف شد', 'kasebi-erp' ),
		];
	}

	public function get_meta_label( string $meta_key, int $customer_id ): string {
		$labels = [
			'first_name'                 => __( 'نام', 'kasebi-erp' ),
			'last_name'                  => __( 'نام خانوادگی', 'kasebi-erp' ),
			'billing_phone'              => __( 'شماره موبایل', 'kasebi-erp' ),
			'nooshika_phone_num'         => __( 'شماره موبایل', 'kasebi-erp' ),
			'user_gender'                => __( 'جنسیت', 'kasebi-erp' ),
			'birthday'                   => __( 'تاریخ تولد', 'kasebi-erp' ),
			'national_id'                => __( 'کد ملی', 'kasebi-erp' ),
			'kerp_customer_owner_id'     => __( 'مسئول مشتری', 'kasebi-erp' ),
		];

		foreach ( KERP_Modules_Customers_Fields::instance()->get_edit_profile_fields( $customer_id ) as $field ) {
			$key = sanitize_key( (string) ( $field['meta_key'] ?? '' ) );
			if ( $key !== '' && ! empty( $field['label'] ) ) {
				$labels[ $key ] = (string) $field['label'];
			}
		}

		foreach ( KERP_Modules_Customers_Taxonomies::instance()->get_profile_taxonomies() as $taxonomy ) {
			if ( ! is_array( $taxonomy ) ) {
				continue;
			}

			$key = sanitize_key( (string) ( $taxonomy['meta_key'] ?? '' ) );

			if ( $key !== '' && ! empty( $taxonomy['label'] ) ) {
				$labels[ $key ] = (string) $taxonomy['label'];
			}
		}

		return (string) apply_filters(
			'kerp_customer_history_meta_label',
			$labels[ $meta_key ] ?? $meta_key,
			$meta_key,
			$customer_id
		);
	}

	/**
	 * Meta keys that are editable through the ERP customer profile form.
	 */
	public function get_trackable_meta_keys( int $customer_id ): array {
		$meta_keys = [];

		foreach ( KERP_Modules_Customers_Fields::instance()->get_edit_profile_fields( $customer_id ) as $field_key => $field ) {
			if ( ! is_array( $field ) ) {
				continue;
			}

			$field_key = sanitize_key( (string) ( $field['key'] ?? $field_key ) );

			if ( $field_key === 'email' ) {
				continue;
			}

			$meta_key = sanitize_key( (string) ( $field['meta_key'] ?? $field_key ) );

			if ( $meta_key !== '' ) {
				$meta_keys[] = $meta_key;
			}
		}

		foreach ( KERP_Modules_Customers_Taxonomies::instance()->get_profile_taxonomies() as $taxonomy_key => $taxonomy ) {
			if ( ! is_array( $taxonomy ) ) {
				continue;
			}

			$meta_key = sanitize_key( (string) ( $taxonomy['meta_key'] ?? $taxonomy_key ) );

			if ( $meta_key !== '' ) {
				$meta_keys[] = $meta_key;
			}
		}

		$meta_keys = apply_filters(
			'kerp_customer_history_trackable_meta_keys',
			array_values( array_unique( $meta_keys ) ),
			$customer_id
		);

		return array_values(
			array_unique(
				array_filter(
					array_map( 'sanitize_key', is_array( $meta_keys ) ? $meta_keys : [] )
				)
			)
		);
	}

	public function format_value( mixed $stored_value, string $meta_key = '', int $customer_id = 0 ): string {
		$value = $this->unserialize_value( $stored_value );

		if ( $value === NULL || $value === '' || $value === [] ) {
			return __( 'خالی', 'kasebi-erp' );
		}

		$meta_key = sanitize_key( $meta_key );

		if ( $meta_key !== '' && $customer_id > 0 ) {
			$owner_meta_key = sanitize_key(
				(string) KERP_Modules_Customers_Settings::instance()->get(
					'owner_meta_key',
					'kerp_customer_owner_id'
				)
			);

			if ( $meta_key === $owner_meta_key ) {
				$user_ids   = is_array( $value ) ? $value : [ $value ];
				$user_names = [];

				foreach ( $user_ids as $user_id ) {
					$user = get_userdata( absint( $user_id ) );

					if ( $user instanceof WP_User ) {
						$user_names[] = (string) get_user_name_by_id( $user->ID );
					}
				}

				if ( $user_names !== [] ) {
					return implode( '، ', $user_names );
				}
			}

			$taxonomy_value = $this->format_taxonomy_value( $meta_key, $value, $customer_id );

			if ( $taxonomy_value !== NULL ) {
				return $taxonomy_value;
			}

			$field = $this->get_field_definition( $meta_key, $customer_id );

			if ( $field !== [] ) {
				$formatted = KERP_Modules_Customers_Fields::instance()->format_display_value( $value, $field );

				return $formatted !== '-' ? $formatted : __( 'خالی', 'kasebi-erp' );
			}
		}

		if ( is_bool( $value ) ) {
			return $value ? __( 'بله', 'kasebi-erp' ) : __( 'خیر', 'kasebi-erp' );
		}

		if ( is_array( $value ) || is_object( $value ) ) {
			$value = wp_json_encode( $value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
		}

		$value = trim( wp_strip_all_tags( (string) $value ) );

		return $value !== '' ? mb_substr( $value, 0, 500 ) : __( 'خالی', 'kasebi-erp' );
	}

	private function get_field_definition( string $meta_key, int $customer_id ): array {
		if ( ! isset( $this->field_definitions[ $customer_id ] ) ) {
			$this->field_definitions[ $customer_id ] = [];

			foreach ( KERP_Modules_Customers_Fields::instance()->get_edit_profile_fields( $customer_id ) as $field_key => $field ) {
				if ( ! is_array( $field ) ) {
					continue;
				}

				$field_key     = sanitize_key( (string) ( $field['key'] ?? $field_key ) );
				$field_meta_key = sanitize_key( (string) ( $field['meta_key'] ?? $field_key ) );

				if ( $field_meta_key !== '' ) {
					$this->field_definitions[ $customer_id ][ $field_meta_key ] = $field;
				}
			}

			$taxonomies_service = KERP_Modules_Customers_Taxonomies::instance();
			$taxonomy_fields    = $taxonomies_service->get_profile_fields( $customer_id );

			foreach ( $taxonomies_service->get_profile_taxonomies() as $taxonomy_key => $taxonomy ) {
				if ( ! is_array( $taxonomy ) ) {
					continue;
				}

				$taxonomy_key = sanitize_key( (string) ( $taxonomy['key'] ?? $taxonomy_key ) );
				$meta_key     = sanitize_key( (string) ( $taxonomy['meta_key'] ?? $taxonomy_key ) );

				if ( $meta_key === '' ) {
					continue;
				}

				$field = isset( $taxonomy_fields[ $taxonomy_key ] ) && is_array( $taxonomy_fields[ $taxonomy_key ] )
					? $taxonomy_fields[ $taxonomy_key ]
					: $taxonomy;

				$field['type']     = 'select';
				$field['multiple'] = ! empty( $taxonomy['multiple'] );

				$this->field_definitions[ $customer_id ][ $meta_key ] = $field;
			}
		}

		return $this->field_definitions[ $customer_id ][ $meta_key ] ?? [];
	}

	private function format_taxonomy_value( string $meta_key, mixed $value, int $customer_id ): ?string {
		$taxonomies = KERP_Modules_Customers_Taxonomies::instance();
		$fields     = $taxonomies->get_profile_fields( $customer_id );

		foreach ( $taxonomies->get_profile_taxonomies() as $taxonomy_key => $taxonomy ) {
			if ( ! is_array( $taxonomy ) ) {
				continue;
			}

			$taxonomy_key = sanitize_key( (string) ( $taxonomy['key'] ?? $taxonomy_key ) );
			$field_meta_key = sanitize_key( (string) ( $taxonomy['meta_key'] ?? $taxonomy_key ) );

			if ( $field_meta_key !== $meta_key ) {
				continue;
			}

			$field   = isset( $fields[ $taxonomy_key ] ) && is_array( $fields[ $taxonomy_key ] )
				? $fields[ $taxonomy_key ]
				: [];
			$options = isset( $field['options'] ) && is_array( $field['options'] )
				? $field['options']
				: $taxonomies->get_options( $taxonomy_key );
			$values  = $this->flatten_values( is_array( $value ) ? $value : [ $value ] );
			$labels  = [];

			foreach ( $values as $item ) {
				$item_key = sanitize_key( (string) $item );

				if ( $item_key === '' ) {
					continue;
				}

				$labels[] = isset( $options[ $item_key ] )
					? (string) $options[ $item_key ]
					: __( 'گزینه حذف‌شده', 'kasebi-erp' );
			}

			$labels = array_values( array_unique( array_filter( array_map( 'trim', $labels ) ) ) );

			return $labels !== [] ? implode( '، ', $labels ) : __( 'خالی', 'kasebi-erp' );
		}

		return NULL;
	}

	private function flatten_values( array $values ): array {
		$flattened = [];

		array_walk_recursive(
			$values,
			static function( mixed $value ) use ( &$flattened ): void {
				$flattened[] = $value;
			}
		);

		return $flattened;
	}

	public function delete_customer_history( int $customer_id ): void {
		global $wpdb;

		$wpdb->delete( self::table(), [ 'customer_id' => $customer_id ], [ '%d' ] );
	}

	private function insert(
		int $customer_id,
		string $meta_key,
		string $event_type,
		mixed $old_value,
		mixed $new_value
	): void {
		global $wpdb;

		if ( $this->is_effectively_empty( $old_value ) && $this->is_effectively_empty( $new_value ) ) {
			return;
		}

		if ( ! $this->table_ready ) {
			self::install();
			$this->table_ready = self::table_exists();
		}

		if ( ! $this->table_ready ) {
			do_action( 'kerp_customer_meta_history_insert_failed', $customer_id, $meta_key, 'missing_table' );
			return;
		}

		$fingerprint = md5(
			$customer_id . '|' . $meta_key . '|' . $event_type . '|'
			. maybe_serialize( $old_value ) . '|' . maybe_serialize( $new_value )
		);

		if ( isset( $this->recorded_fingerprints[ $fingerprint ] ) ) {
			return;
		}

		$inserted = $wpdb->insert(
			self::table(),
			[
				'customer_id' => $customer_id,
				'meta_key'    => $meta_key,
				'event_type'  => $event_type,
				'old_value'   => maybe_serialize( $old_value ),
				'new_value'   => maybe_serialize( $new_value ),
				'actor_id'    => get_current_user_id(),
				'created_at'  => current_time( 'mysql' ),
			],
			[ '%d', '%s', '%s', '%s', '%s', '%d', '%s' ]
		);

		if ( $inserted === FALSE ) {
			do_action( 'kerp_customer_meta_history_insert_failed', $customer_id, $meta_key, (string) $wpdb->last_error );
			return;
		}

		$this->recorded_fingerprints[ $fingerprint ] = TRUE;
	}

	private function should_record( int $customer_id, string $meta_key, mixed $meta_value ): bool {
		if ( $customer_id <= 0 || $meta_key === '' ) {
			return FALSE;
		}

		$meta_key      = sanitize_key( $meta_key );
		$should_record = in_array( $meta_key, $this->get_trackable_meta_keys( $customer_id ), TRUE );

		return (bool) apply_filters(
			'kerp_customer_meta_history_should_record',
			$should_record,
			$customer_id,
			$meta_key,
			$meta_value
		);
	}

	private function values_equal( mixed $first, mixed $second ): bool {
		return maybe_serialize( $first ) === maybe_serialize( $second );
	}

	private function is_effectively_empty( mixed $value ): bool {
		$value = $this->unserialize_value( $value );

		if ( $value === NULL ) {
			return TRUE;
		}

		if ( is_string( $value ) ) {
			return trim( $value ) === '';
		}

		if ( is_array( $value ) ) {
			if ( $value === [] ) {
				return TRUE;
			}

			foreach ( $value as $item ) {
				if ( ! $this->is_effectively_empty( $item ) ) {
					return FALSE;
				}
			}

			return TRUE;
		}

		return FALSE;
	}

	private function delete_key( int $customer_id, string $meta_key ): string {
		return $customer_id . ':' . $meta_key;
	}

	private function normalize_value_list( array $values ): mixed {
		$values = array_map( [ $this, 'unserialize_value' ], $values );

		if ( $values === [] ) {
			return NULL;
		}

		if ( count( $values ) === 1 ) {
			return reset( $values );
		}

		return $values;
	}

	private function unserialize_value( mixed $value ): mixed {
		for ( $depth = 0; $depth < 5 && is_string( $value ) && is_serialized( $value ); $depth++ ) {
			$unserialized = maybe_unserialize( $value );

			if ( $unserialized === $value ) {
				break;
			}

			$value = $unserialized;
		}

		if ( is_array( $value ) ) {
			foreach ( $value as $key => $item ) {
				$value[ $key ] = $this->unserialize_value( $item );
			}
		}

		return $value;
	}

	private function can_view_customer( int $customer_id ): bool {
		if (
			current_user_can( 'manage_options' )
			|| current_user_can( KERP_Admin::CAPABILITY )
		) {
			return get_userdata( $customer_id ) instanceof WP_User;
		}

		$result = KERP_Modules_Customers_Query::instance()->find(
			[
				'include'     => [ $customer_id ],
				'per_page'    => 1,
				'page_number' => 1,
			]
		);

		foreach ( (array) ( $result['items'] ?? [] ) as $customer ) {
			if ( $customer instanceof WP_User && (int) $customer->ID === $customer_id ) {
				return TRUE;
			}
		}

		return FALSE;
	}

	private function send_error( string $message ): never {
		wp_send_json(
			[
				'status'  => 'error',
				'message' => $message,
			]
		);
	}
}
