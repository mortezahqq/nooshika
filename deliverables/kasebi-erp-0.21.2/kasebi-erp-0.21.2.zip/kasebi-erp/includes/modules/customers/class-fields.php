<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Customers_Fields {
	
	public const OPTION_NAME = 'kerp_customers_custom_fields';
	
	private static ?self $instance = NULL;
	
	private ?array $fields = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {
		add_action( 'update_option_' . self::OPTION_NAME, [ $this, 'clear_cache' ], 10, 0 );
		add_action( 'add_option_' . self::OPTION_NAME, [ $this, 'clear_cache' ], 10, 0 );
	}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public function get_all( bool $active_only = FALSE ): array {
		if ( $this->fields === NULL ) {
			$stored       = get_option( self::OPTION_NAME, [] );
			$this->fields = is_array( $stored ) ? $stored : [];
		}
		
		$fields = $this->fields;
		
		if ( $active_only ) {
			$fields = array_filter(
				$fields,
				static fn( array $field ): bool => ! isset( $field['active'] ) || ! empty( $field['active'] )
			);
		}
		
		$fields = apply_filters( 'kerp_customers_custom_fields', $fields, $active_only );
		$this->sort( $fields );
		
		return $fields;
	}
	
	public function get( string $field_key ): ?array {
		$field_key = sanitize_key( $field_key );
		$fields    = $this->get_all();
		
		return isset( $fields[ $field_key ] ) && is_array( $fields[ $field_key ] )
			? $fields[ $field_key ]
			: NULL;
	}
	
	public function save( array $fields ): bool {
		$clean = [];
		
		foreach ( $fields as $field_key => $field ) {
			if ( ! is_array( $field ) ) {
				continue;
			}
			
			$field['key'] = $field['key'] ?? $field_key;
			$field        = $this->sanitize_definition( $field );
			
			if ( empty( $field['key'] ) ) {
				continue;
			}
			
			$clean[ $field['key'] ] = $field;
		}
		
		$this->sort( $clean );
		$result       = update_option( self::OPTION_NAME, $clean, FALSE );
		$this->fields = $clean;
		
		do_action( 'kerp_customers_custom_fields_saved', $clean );
		
		return $result;
	}
	
	public function upsert( array $field ): bool {
		$field = $this->sanitize_definition( $field );
		
		if ( empty( $field['key'] ) ) {
			return FALSE;
		}
		
		$fields                  = $this->get_all();
		$fields[ $field['key'] ] = $field;
		
		return $this->save( $fields );
	}
	
	public function delete( string $field_key ): bool {
		$field_key = sanitize_key( $field_key );
		$fields    = $this->get_all();
		
		if ( ! isset( $fields[ $field_key ] ) ) {
			return TRUE;
		}
		
		unset( $fields[ $field_key ] );
		
		return $this->save( $fields );
	}
	
	public function get_create_fields(): array {
		$settings = KERP_Modules_Customers_Settings::instance();
		$fields   = [
			'first_name' => [
				'name'     => 'first_name',
				'key'      => 'first_name',
				'label'    => __( 'نام', 'kasebi-erp' ),
				'type'     => 'text',
				'class'    => 'col-md-6',
				'required' => (bool) $settings->get( 'require_first_name', TRUE ),
				'order'    => 10,
			],
			'last_name'  => [
				'name'     => 'last_name',
				'key'      => 'last_name',
				'label'    => __( 'نام خانوادگی', 'kasebi-erp' ),
				'type'     => 'text',
				'class'    => 'col-md-6',
				'required' => (bool) $settings->get( 'require_last_name', TRUE ),
				'order'    => 20,
			],
			'phone'      => [
				'name'     => 'phone',
				'key'      => 'phone',
				'label'    => __( 'شماره موبایل', 'kasebi-erp' ),
				'type'     => 'text',
				'class'    => 'col-md-6',
				'required' => (bool) $settings->get( 'require_phone', TRUE ),
				'order'    => 30,
			],
		];
		
		foreach ( $this->get_all( TRUE ) as $field_key => $definition ) {
			if ( empty( $definition['show_on_create'] ) ) {
				continue;
			}
			
			$fields[ $field_key ] = $this->to_form_field( $definition );
		}
		
		$fields = apply_filters( 'kerp_customers_create_fields', $fields );
		$this->sort( $fields );
		
		return $fields;
	}
	
	public function get_main_profile_fields( WP_User|int $customer ): array {
		$customer = is_int( $customer )
			? get_userdata( $customer )
			: $customer;
		
		if ( ! $customer instanceof WP_User ) {
			return [];
		}
		
		$settings = KERP_Modules_Customers_Settings::instance();
		
		$phone_key = sanitize_key(
			(string) $settings->get(
				'phone_meta_key',
				'nooshika_phone_num'
			)
		);
		
		$owner_key = sanitize_key(
			(string) $settings->get(
				'owner_meta_key',
				'kerp_customer_owner_id'
			)
		);
		
		$phone = sanitize_text_field(
			(string) get_user_meta(
				$customer->ID,
				$phone_key,
				TRUE
			)
		);
		
		if ( $phone === '' ) {
			$phone = sanitize_text_field(
				(string) get_user_meta(
					$customer->ID,
					'billing_phone',
					TRUE
				)
			);
		}
		/*
		 * دریافت گزینه‌های مسئول رکورد از کارمندان ثبت‌شده ERP.
		 */
		$owner_options = KERP_Modules_Employees_Query::instance()->get_options();
		
		$owner_options = apply_filters(
			'kerp_customers_owner_options',
			$owner_options,
			$customer->ID,
			$customer
		);
		
		$owner_options = is_array( $owner_options )
			? $owner_options
			: [];
		
		$fields = [
			'first_name' => [
				'id'       => 'kerp-customer-profile-first-name',
				'name'     => 'first_name',
				'key'      => 'first_name',
				'label'    => __( 'نام', 'kasebi-erp' ),
				'type'     => 'text',
				'class'    => 'col-md-6',
				'value'    => $customer->first_name,
				'required' => (bool) $settings->get(
					'require_first_name',
					TRUE
				),
				'order'    => 10,
			],
			
			'last_name' => [
				'id'       => 'kerp-customer-profile-last-name',
				'name'     => 'last_name',
				'key'      => 'last_name',
				'label'    => __( 'نام خانوادگی', 'kasebi-erp' ),
				'type'     => 'text',
				'class'    => 'col-md-6',
				'value'    => $customer->last_name,
				'required' => (bool) $settings->get(
					'require_last_name',
					TRUE
				),
				'order'    => 20,
			],
			
			'birthday' => [
				'id'       => 'kerp-customer-profile-birthday',
				'name'     => 'meta[birthday]',
				'key'      => 'birthday',
				'meta_key' => 'birthday',
				'label'    => __( 'تاریخ تولد', 'kasebi-erp' ),
				'type'     => 'date',
				'class'    => 'col-md-6',
				'value'    => (string) get_user_meta(
					$customer->ID,
					'birthday',
					TRUE
				),
				'required' => FALSE,
				'order'    => 30,
			],
			
			'gender' => [
				'id'       => 'kerp-customer-profile-gender',
				'name'     => 'meta[user_gender]',
				'key'      => 'gender',
				'meta_key' => 'user_gender',
				'label'    => __( 'جنسیت', 'kasebi-erp' ),
				'type'     => 'radio',
				'class'    => 'col-md-6',
				'value'    => sanitize_key(
					(string) get_user_meta(
						$customer->ID,
						'user_gender',
						TRUE
					)
				),
				'options'  => [
					'male'   => __( 'مرد', 'kasebi-erp' ),
					'female' => __( 'زن', 'kasebi-erp' ),
					'other'  => __( 'سایر', 'kasebi-erp' ),
				],
				'required' => FALSE,
				'order'    => 40,
			],
			
			'national_id' => [
				'id'       => 'kerp-customer-profile-national-id',
				'name'     => 'meta[national_id]',
				'key'      => 'national_id',
				'meta_key' => 'national_id',
				'label'    => __( 'کد ملی', 'kasebi-erp' ),
				'type'     => 'text',
				'class'    => 'col-md-6',
				'value'    => (string) get_user_meta(
					$customer->ID,
					'national_id',
					TRUE
				),
				'required' => FALSE,
				'order'    => 50,
			],
			
			'landline_phone' => [
				'id'       => 'kerp-customer-profile-landline-phone',
				'name'     => 'meta[landline_phone]',
				'key'      => 'landline_phone',
				'meta_key' => 'landline_phone',
				'label'    => __( 'شماره ثابت', 'kasebi-erp' ),
				'type'     => 'text',
				'class'    => 'col-md-6',
				'value'    => (string) get_user_meta(
					$customer->ID,
					'landline_phone',
					TRUE
				),
				'required' => FALSE,
				'order'    => 60,
			],
			
			'phone' => [
				'id'       => 'kerp-customer-profile-phone',
				'name'     => 'phone',
				'key'      => 'phone',
				'meta_key' => $phone_key,
				'label'    => __( 'شماره همراه', 'kasebi-erp' ),
				'type'     => 'text',
				'class'    => 'col-md-6',
				'value'    => $phone,
				'required' => (bool) $settings->get(
					'require_phone',
					TRUE
				),
				'order'    => 70,
			],
			
			'second_phone' => [
				'id'       => 'kerp-customer-profile-second-phone',
				'name'     => 'meta[user_fax]',
				'key'      => 'user_fax',
				'meta_key' => 'user_fax',
				'label'    => __( 'شماره همراه دوم', 'kasebi-erp' ),
				'type'     => 'text',
				'class'    => 'col-md-6',
				'value'    => (string) get_user_meta(
					$customer->ID,
					'user_fax',
					TRUE
				),
				'required' => FALSE,
				'order'    => 80,
			],
			
			'postcode' => [
				'id'       => 'kerp-customer-profile-postcode',
				'name'     => 'meta[billing_postcode]',
				'key'      => 'billing_postcode',
				'meta_key' => 'billing_postcode',
				'label'    => __( 'کد پستی', 'kasebi-erp' ),
				'type'     => 'text',
				'class'    => 'col-md-6',
				'value'    => (string) get_user_meta(
					$customer->ID,
					'billing_postcode',
					TRUE
				),
				'required' => FALSE,
				'order'    => 90,
			],
			
			'address' => [
				'id'          => 'kerp-customer-profile-address',
				'name'        => 'meta[billing_address_1]',
				'key'         => 'billing_address_1',
				'meta_key'    => 'billing_address_1',
				'label'       => __( 'آدرس', 'kasebi-erp' ),
				'type'        => 'textarea',
				'class'       => 'col-12',
				'value'       => (string) get_user_meta(
					$customer->ID,
					'billing_address_1',
					TRUE
				),
				'rows'        => 3,
				'placeholder' => __( 'آدرس کامل را وارد کنید.', 'kasebi-erp' ),
				'required'    => FALSE,
				'order'       => 100,
			],
			
			'owner_id' => [
				'id'          => 'kerp-customer-profile-owner-id',
				'name'        => 'meta[' . $owner_key . ']',
				'key'         => 'owner_id',
				'meta_key'    => $owner_key,
				'label'       => sprintf(
					__( 'مسئول %s', 'kasebi-erp' ),
					$settings->get_singular_label()
				),
				'type'        => 'select',
				'class'       => 'col-md-6',
				'value'       => absint(
					get_user_meta(
						$customer->ID,
						$owner_key,
						TRUE
					)
				),
				'options'     => $owner_options,
				'placeholder' => __( 'مسئول را انتخاب کنید.', 'kasebi-erp' ),
				'required'    => FALSE,
				'order'       => 110,
			],
		];
		
		$fields = apply_filters(
			'kerp_customer_main_profile_fields',
			$fields,
			$customer->ID,
			$customer
		);
		
		$fields = is_array( $fields )
			? $fields
			: [];
		
		$this->sort( $fields );
		
		return $fields;
	}
	
	public function get_profile_fields( int $customer_id = 0 ): array {
		$fields = [];
		
		foreach ( $this->get_all( TRUE ) as $field_key => $definition ) {
			if ( empty( $definition['show_on_profile'] ) ) {
				continue;
			}
			
			$field          = $this->to_form_field( $definition );
			$field['value'] = $customer_id > 0
				? get_user_meta( $customer_id, $definition['meta_key'], TRUE )
				: '';
			
			$fields[ $field_key ] = $field;
		}
		
		$fields = apply_filters( 'kerp_customer_profile_fields', $fields, $customer_id );
		$this->sort( $fields );
		
		return $fields;
	}
	
	public function sanitize_value( mixed $value, array $field ): mixed {
		$type = sanitize_key( (string) ( $field['type'] ?? 'text' ) );
		
		if ( is_array( $value ) ) {
			return array_values(
				array_map(
					fn( mixed $item ): mixed => $this->sanitize_value( $item, $field ),
					$value
				)
			);
		}
		
		$value = wp_unslash( (string) $value );
		
		return match ( $type ) {
			'email' => sanitize_email( $value ),
			'url' => esc_url_raw( $value ),
			'number', 'price' => $this->sanitize_number( $value ),
			'textarea', 'quill' => wp_kses_post( $value ),
			'select', 'radio', 'switch' => sanitize_key( $value ),
			'checkbox', 'multi-select' => sanitize_text_field( $value ),
			default => sanitize_text_field( $value ),
		};
	}
	
	private function sanitize_definition( array $field ): array {
		$key  = sanitize_key( (string) ( $field['key'] ?? $field['name'] ?? '' ) );
		$type = sanitize_key( (string) ( $field['type'] ?? 'text' ) );
		
		$allowed_types = [
			'text',
			'email',
			'number',
			'price',
			'date',
			'textarea',
			'select',
			'radio',
			'checkbox',
			'multi-select',
			'switch',
			'url',
			'quill',
		];
		
		if ( ! in_array( $type, $allowed_types, TRUE ) ) {
			$type = 'text';
		}
		
		$options = $field['options'] ?? [];
		
		if ( is_string( $options ) ) {
			$option_rows = preg_split(
				'/\R+|\s*\|\s*/u',
				trim( $options ),
				- 1,
				PREG_SPLIT_NO_EMPTY
			);
			
			$parsed_options = [];
			
			foreach ( (array) $option_rows as $option_row ) {
				$parts = array_map(
					'trim',
					explode( '=', (string) $option_row, 2 )
				);
				
				$option_key   = sanitize_key( (string) ( $parts[0] ?? '' ) );
				$option_label = sanitize_text_field( (string) ( $parts[1] ?? '' ) );
				
				if ( $option_key === '' || $option_label === '' ) {
					continue;
				}
				
				$parsed_options[ $option_key ] = $option_label;
			}
			
			$options = $parsed_options;
		}
		
		$options = is_array( $options ) ? $options : [];
		
		$clean_options = [];
		foreach ( $options as $option_key => $option_label ) {
			$option_key = sanitize_key( (string) $option_key );
			if ( $option_key === '' ) {
				continue;
			}
			$clean_options[ $option_key ] = sanitize_text_field( (string) $option_label );
		}
		
		return [
			'key'             => $key,
			'name'            => $key,
			'meta_key'        => $key,
			'label'           => sanitize_text_field( (string) ( $field['label'] ?? $key ) ),
			'description'     => sanitize_textarea_field( (string) ( $field['description'] ?? '' ) ),
			'type'            => $type,
			'placeholder'     => sanitize_text_field( (string) ( $field['placeholder'] ?? '' ) ),
			'class'           => sanitize_text_field( (string) ( $field['class'] ?? 'col-md-6' ) ),
			'options'         => $clean_options,
			'required'        => FALSE,
			'active'          => ! isset( $field['active'] ) || ! empty( $field['active'] ),
			'show_on_create'  => ! empty( $field['show_on_create'] ),
			'show_on_profile' => ! isset( $field['show_on_profile'] ) || ! empty( $field['show_on_profile'] ),
			'filterable'      => ! empty( $field['filterable'] ),
			'column'          => ! empty( $field['column'] ),
			'order'           => (int) ( $field['order'] ?? 100 ),
		];
	}
	
	private function to_form_field( array $definition ): array {
		return [
			'name'        => $definition['key'],
			'key'         => $definition['key'],
			'meta_key'    => $definition['meta_key'],
			'label'       => $definition['label'],
			'description' => $definition['description'],
			'type'        => $definition['type'],
			'placeholder' => $definition['placeholder'],
			'class'       => $definition['class'],
			'options'     => $definition['options'],
			'required'    => FALSE,
			'order'       => $definition['order'],
		];
	}
	
	private function sanitize_number( string $value ): string {
		if ( function_exists( 'nooshika_sanitize_numbers' ) ) {
			$value = nooshika_sanitize_numbers( $value );
		}
		
		$value = str_replace( [ ',', '٬', '،', ' ' ], '', $value );
		
		return preg_replace( '/[^0-9.\-]/', '', $value ) ?? '';
	}
	
	private function sort( array &$items ): void {
		uasort(
			$items,
			static fn( array $first, array $second ): int => (int) ( $first['order'] ?? 100 ) <=> (int) ( $second['order'] ?? 100 )
		);
	}
	
	public function clear_cache(): void {
		$this->fields = NULL;
	}
	
	public function get_edit_profile_fields( int $customer_id ): array {
		$fields = $this->get_main_profile_fields( $customer_id );
		
		foreach ( $this->get_profile_fields( $customer_id ) as $field_key => $field ) {
			if ( isset( $fields[ $field_key ] ) ) {
				continue;
			}
			
			$fields[ $field_key ] = $field;
		}
		
		$fields = apply_filters(
			'kerp_customer_edit_profile_fields',
			$fields,
			$customer_id
		);
		
		$normalized = [];
		
		foreach ( $fields as $field_key => $field ) {
			if ( ! is_array( $field ) ) {
				continue;
			}
			
			$field_key = sanitize_key(
				(string) ( $field['key'] ?? $field_key )
			);
			
			if ( $field_key === '' ) {
				continue;
			}
			
			$field['key']  = $field_key;
			$field['name'] = 'meta[' . $field_key . ']';
			$field['id']   = $field['id']
			                 ?? 'kerp-customer-profile-meta-' . $field_key;
			
			$normalized[ $field_key ] = $field;
		}
		
		$this->sort( $normalized );
		
		return $normalized;
	}
	
	public function get_profile_view_fields( int $customer_id ): array {
		$fields = $this->get_edit_profile_fields( $customer_id );
		
		foreach ( $fields as $field_key => &$field ) {
			$field['display_value'] = $this->format_display_value(
				$field['value'] ?? '',
				$field
			);
			$field['key']           = sanitize_key(
				(string) ( $field['key'] ?? $field_key )
			);
		}
		unset( $field );
		
		$fields = apply_filters(
			'kerp_customer_profile_view_fields',
			$fields,
			$customer_id
		);
		
		$this->sort( $fields );
		
		return $fields;
	}
	
	public function format_display_value( mixed $value, array $field ): string {
		$type    = sanitize_key( (string) ( $field['type'] ?? 'text' ) );
		$options = isset( $field['options'] ) && is_array( $field['options'] )
			? $field['options']
			: [];
		
		if ( is_array( $value ) ) {
			$values = [];
			
			foreach ( $value as $item ) {
				$item_key = (string) $item;
				$values[] = (string) ( $options[ $item_key ] ?? $item_key );
			}
			
			$value = implode(
				'، ',
				array_filter(
					array_map(
						'trim',
						$values
					)
				)
			);
		} elseif (
			in_array(
				$type,
				[ 'select', 'radio', 'checkbox', 'multi-select' ],
				TRUE
			)
		) {
			$value_key = (string) $value;
			$value     = (string) ( $options[ $value_key ] ?? $value_key );
		} elseif ( $type === 'date' && $value !== '' ) {
			$timestamp = is_numeric( $value )
				? (int) $value
				: strtotime( (string) $value );
			
			if ( $timestamp ) {
				$value = date_i18n( 'Y/m/d', $timestamp );
			}
		} elseif ( $type === 'switch' ) {
			$value = ! empty( $value )
				? __( 'بله', 'kasebi-erp' )
				: __( 'خیر', 'kasebi-erp' );
		}
		
		$value = trim(
			wp_strip_all_tags(
				(string) $value
			)
		);
		
		return $value !== '' || $value === '0'
			? $value
			: '-';
	}
	
}
