<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Customers_List_Table {
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public function get_filters( array $values = [] ): array {
		$taxonomies    = KERP_Modules_Customers_Taxonomies::instance();
		$owner_options = KERP_Modules_Employees_Query::instance()->get_options();
		$owner_options = apply_filters(
			'kerp_customers_owner_options',
			$owner_options
		);
		$owner_options = is_array( $owner_options )
			? $owner_options
			: [];
		
		$gender = sanitize_key(
			(string) ( $values['gender'] ?? '' )
		);
		
		if ( ! in_array( $gender, [ 'male', 'female', 'other' ], TRUE ) ) {
			$gender = '';
		}
		
		$filters = [
			'registered_from' => [
				'key'   => 'registered',
				'name'  => 'registered',
				'label' => __( 'تاریخ عضویت', 'kasebi-erp' ),
				'type'  => 'date-range',
				'col'   => 12,
				'value' => $values['registered'] ?? [
						'from' => '',
						'to'   => '',
					],
				'order' => 20,
			],
			
			'gender' => [
				'key'         => 'gender',
				'name'        => 'gender',
				'label'       => __( 'جنسیت', 'kasebi-erp' ),
				'type'        => 'select',
				'options'     => [
					'male'   => __( 'مرد', 'kasebi-erp' ),
					'female' => __( 'زن', 'kasebi-erp' ),
					'other'  => __( 'سایر', 'kasebi-erp' ),
				],
				'placeholder' => __( 'همه جنسیت‌ها', 'kasebi-erp' ),
				'value'       => $gender,
				'order'       => 30,
			],
			
			'owner_id' => [
				'key'         => 'owner_id',
				'name'        => 'owner_id',
				'label'       => __( 'بازاریاب', 'kasebi-erp' ),
				'type'        => 'select',
				'options'     => is_array( $owner_options )
					? $owner_options
					: [],
				'placeholder' => __( 'همه بازاریاب‌ها', 'kasebi-erp' ),
				'value'       => absint( $values['owner_id'] ?? 0 ),
				'order'       => 35,
			],
			
			'source' => [
				'key'         => 'source',
				'name'        => 'source',
				'label'       => __( 'شیوه آشنایی', 'kasebi-erp' ),
				'type'        => 'select',
				'options'     => $taxonomies->get_options(
					KERP_Modules_Customers_Taxonomies::TYPE_SOURCE
				),
				'placeholder' => __( 'همه موارد', 'kasebi-erp' ),
				'value'       => sanitize_key(
					(string) ( $values['source'] ?? '' )
				),
				'order'       => 40,
			],
			
			'label' => [
				'key'         => 'label',
				'name'        => 'label',
				'label'       => __( 'دسته‌بندی', 'kasebi-erp' ),
				'type'        => 'select',
				'search'      => TRUE,
				'options'     => $taxonomies->get_options(
					KERP_Modules_Customers_Taxonomies::TYPE_LABEL
				),
				'placeholder' => __( 'همه دسته‌بندی‌ها', 'kasebi-erp' ),
				'value'       => sanitize_key(
					(string) ( $values['label'] ?? '' )
				),
				'order'       => 50,
			],
			
			'tag' => [
				'key'         => 'tag',
				'name'        => 'tag',
				'label'       => __( 'تگ', 'kasebi-erp' ),
				'type'        => 'select',
				'options'     => $taxonomies->get_options(
					KERP_Modules_Customers_Taxonomies::TYPE_TAG
				),
				'placeholder' => __( 'همه تگ‌ها', 'kasebi-erp' ),
				'value'       => sanitize_key(
					(string) ( $values['tag'] ?? '' )
				),
				'order'       => 60,
			],
		];
		
		foreach (
			KERP_Modules_Customers_Fields::instance()->get_all( TRUE )
			as $field_key => $field
		) {
			if ( empty( $field['filterable'] ) ) {
				continue;
			}
			
			$filters[ $field_key ] = [
				'key'         => $field_key,
				'name'        => $field_key,
				'label'       => $field['label'],
				'type'        => $field['type'],
				'options'     => $field['options'] ?? [],
				'placeholder' => $field['placeholder'] ?? '',
				'value'       => $values[ $field_key ] ?? '',
				'order'       => (int) ( $field['order'] ?? 100 ),
			];
		}
		
		$first_touch_options                                          = $this->get_first_touch_filter_options();
		$first_touch_options['first_touch_type']['landing_order']     = 'ثبت سفارش لندینگ';
		$first_touch_options['first_touch_type']['gravity_form']      = 'تکمیل فرم گرویتی';
		$first_touch_options['first_touch_type']['site_registration'] = 'ورود و ثبت‌نام سایت';
		$first_touch_options['first_touch_type']['__products__']      = 'خرید محصول';
		$first_touch_labels                                           = [
			'first_touch_type'         => 'شیوه عضویت',
			'first_touch_source_type'  => 'Source Type',
			'first_touch_utm_source'   => 'UTM Source',
			'first_touch_utm_medium'   => 'UTM Medium',
			'first_touch_utm_campaign' => 'UTM Campaign',
			'first_touch_utm_term'     => 'UTM Term',
			'first_touch_utm_content'  => 'UTM Content',
			'first_touch_landing'      => 'Landing Page',
			'first_touch_referrer'     => 'Referrer',
			'first_touch_redirect'     => 'Redirect URL',
		];
		foreach ( $this->get_first_touch_fields() as $key => $field ) {
			$value = $values[ $key ] ?? '';
			if ( $key === 'first_touch_type' && $value === '__unknown__' ) {
				$first_touch_options[ $key ]['__unknown__'] = 'نامشخص';
			}
			$filters[ $key ] = [
				'key'         => $key,
				'name'        => $key,
				'label'       => $first_touch_labels[ $key ],
				'type'        => 'select',
				'search'      => TRUE,
				'options'     => $first_touch_options[ $key ] ?? [],
				'placeholder' => 'همه موارد',
				'value'       => is_scalar( $value ) ? sanitize_text_field( (string) $value ) : '',
				'col'         => 6,
				'order'       => $key === 'first_touch_type' ? 200 : 202,
			];
		}
		
		foreach ( $this->get_first_touch_choice_filters( $values ) as $key => $field ) {
			$filters[ $key ] = $field;
		}
		$filters = apply_filters(
			'kerp_customers_list_filters',
			$filters,
			$values
		);
		
		$this->sort( $filters );
		
		return $filters;
	}
	
	private function get_first_touch_filter_options(): array {
		global $wpdb;
		$fields  = $this->get_first_touch_fields();
		$options = array_fill_keys( array_keys( $fields ), [] );
		if ( ! kerp_can( 'customers', 'view' ) || ! in_array( kerp_list_scope( 'customers' ), [
				'all',
				'own',
			], TRUE ) ) {
			return $options;
		}
		$compiled = KERP_Modules_Customers_Query::instance()->find( [
			'customers_dashboard_sql' => TRUE,
			'count_total'             => FALSE,
		] );
		if ( empty( $compiled['sql'] ) ) {
			return $options;
		}
		$users   = $compiled['sql'];
		$table   = KERP_Services_Attribution_First_Touch::table();
		$queries = [];
		foreach ( $fields as $key => $field ) {
			// Identifiers come only from the fixed field definitions above.
			$column    = $field['column'];
			$queries[] = $wpdb->prepare( "SELECT %s AS field_key, ft.{$column} AS value FROM {$table} ft
				INNER JOIN ({$users}) u ON u.ID = ft.user_id WHERE ft.{$column} IS NOT NULL AND ft.{$column} <> '' GROUP BY ft.{$column}", $key );
		}
		foreach ( (array) $wpdb->get_results( implode( ' UNION ALL ', $queries ), ARRAY_A ) as $row ) {
			$options[ $row['field_key'] ][ $row['value'] ] = $row['value'];
		}
		// Keep legacy values available without leaking values from out-of-scope users.
		$legacy = $wpdb->get_results( $wpdb->prepare( "SELECT m.meta_value FROM ({$users}) u
			INNER JOIN {$wpdb->usermeta} m ON m.user_id = u.ID AND m.meta_key = %s
			LEFT JOIN {$table} ft ON ft.user_id = u.ID WHERE ft.id IS NULL
			AND m.umeta_id = (SELECT MIN(lm.umeta_id) FROM {$wpdb->usermeta} lm WHERE lm.user_id = m.user_id AND lm.meta_key = m.meta_key)", KERP_Services_Attribution_First_Touch::LEGACY_META_KEY ), ARRAY_A );
		foreach ( (array) $legacy as $row ) {
			$data = maybe_unserialize( $row['meta_value'] );
			if ( ! is_array( $data ) ) {
				continue;
			}
			foreach ( $fields as $key => $field ) {
				$value = $data[ $field['legacy'] ] ?? '';
				if ( is_scalar( $value ) && (string) $value !== '' ) {
					$options[ $key ][ (string) $value ] = (string) $value;
				}
			}
		}
		foreach ( $options as &$values ) {
			asort( $values, SORT_NATURAL | SORT_FLAG_CASE );
		}
		unset( $values );
		
		return $options;
	}
	
	public function get_first_touch_fields(): array {
		return [
			'first_touch_type'         => [
				'column'  => 'touch_type',
				'legacy'  => 'type',
				'label'   => __( 'اولین ورود: مسیر عضویت', 'kasebi-erp' ),
				'options' => [
					'landing_order'     => __( 'ثبت سفارش از لندینگ', 'kasebi-erp' ),
					'gravity_form'      => __( 'تکمیل فرم گرویتی', 'kasebi-erp' ),
					'site_registration' => __( 'ورود و ثبت‌نام سایت', 'kasebi-erp' ),
				],
			],
			'first_touch_source_type'  => [
				'column' => 'source_type',
				'legacy' => 'source_type',
				'label'  => __( 'اولین ورود: نوع منبع', 'kasebi-erp' ),
			],
			'first_touch_utm_source'   => [
				'column' => 'utm_source',
				'legacy' => 'utm_source',
				'label'  => __( 'اولین ورود: منبع', 'kasebi-erp' ),
			],
			'first_touch_utm_medium'   => [
				'column' => 'utm_medium',
				'legacy' => 'utm_medium',
				'label'  => __( 'اولین ورود: رسانه', 'kasebi-erp' ),
			],
			'first_touch_utm_campaign' => [
				'column' => 'utm_campaign',
				'legacy' => 'utm_campaign',
				'label'  => __( 'اولین ورود: کمپین', 'kasebi-erp' ),
			],
			'first_touch_utm_term'     => [
				'column' => 'utm_term',
				'legacy' => 'utm_term',
				'label'  => __( 'اولین ورود: عبارت جستجو', 'kasebi-erp' ),
			],
			'first_touch_utm_content'  => [
				'column' => 'utm_content',
				'legacy' => 'utm_content',
				'label'  => __( 'اولین ورود: محتوای تبلیغ', 'kasebi-erp' ),
			],
			'first_touch_landing'      => [
				'column' => 'landing_url',
				'legacy' => 'landing_page',
				'label'  => __( 'اولین ورود: صفحه فرود', 'kasebi-erp' ),
			],
			'first_touch_referrer'     => [
				'column' => 'referrer_url',
				'legacy' => 'referrer',
				'label'  => __( 'اولین ورود: ارجاع‌دهنده', 'kasebi-erp' ),
			],
			'first_touch_redirect'     => [
				'column' => 'redirect_url',
				'legacy' => 'redirect_to',
				'label'  => __( 'اولین ورود: مقصد عضویت', 'kasebi-erp' ),
			],
		];
	}
	
	private function get_first_touch_choice_filters( array $values ): array {
		global $wpdb;
		$forms    = [];
		$products = [ 'landing' => [], 'cart' => [] ];
		if ( ! kerp_can( 'customers', 'view' ) || ! in_array( kerp_list_scope( 'customers' ), [
				'all',
				'own',
			], TRUE ) ) {
			return [];
		}
		$compiled = KERP_Modules_Customers_Query::instance()->find( [
			'customers_dashboard_sql' => TRUE,
			'count_total'             => FALSE,
		] );
		if ( empty( $compiled['sql'] ) ) {
			return [];
		}
		$users   = $compiled['sql'];
		$touches = KERP_Services_Attribution_First_Touch::table();
		$items   = KERP_Services_Attribution_First_Touch::items_table();
		foreach (
			(array) $wpdb->get_results( "SELECT ft.form_id, MAX(ft.context_json) AS context_json FROM {$touches} ft
            INNER JOIN ({$users}) u ON u.ID = ft.user_id WHERE ft.touch_type = 'gravity_form' AND ft.form_id > 0 GROUP BY ft.form_id", ARRAY_A ) as $row
		) {
			$context = json_decode( (string) $row['context_json'], TRUE );
			$id      = (int) $row['form_id'];
			$title   = $context['form_title'] ?? '';
			if ( ! $title && class_exists( 'GFAPI' ) ) {
				$form  = GFAPI::get_form( $id );
				$title = is_array( $form ) ? ( $form['title'] ?? '' ) : '';
			}
			$forms[ $id ] = $title ?: 'Form #' . $id;
		}
		foreach (
			(array) $wpdb->get_results( "SELECT i.item_kind, i.product_id, MAX(i.product_name) AS name FROM {$items} i
            INNER JOIN {$touches} ft ON ft.id = i.first_touch_id INNER JOIN ({$users}) u ON u.ID = ft.user_id
            WHERE i.product_id > 0 AND ((ft.touch_type = 'landing_order' AND i.item_kind = 'landing') OR (ft.touch_type = 'site_registration' AND i.item_kind = 'cart'))
            GROUP BY i.item_kind, i.product_id ORDER BY name", ARRAY_A ) as $item
		) {
			$products[ $item['item_kind'] ][ (int) $item['product_id'] ] = $item['name'] ?: 'Product #' . $item['product_id'];
		}
		$legacy = $wpdb->get_results( $wpdb->prepare( "SELECT m.meta_value FROM ({$users}) u
            INNER JOIN {$wpdb->usermeta} m ON m.user_id = u.ID AND m.meta_key = %s LEFT JOIN {$touches} ft ON ft.user_id = u.ID
            WHERE ft.id IS NULL AND m.umeta_id = (SELECT MIN(lm.umeta_id) FROM {$wpdb->usermeta} lm WHERE lm.user_id = m.user_id AND lm.meta_key = m.meta_key)", KERP_Services_Attribution_First_Touch::LEGACY_META_KEY ), ARRAY_A );
		foreach ( (array) $legacy as $row ) {
			$data = maybe_unserialize( $row['meta_value'] );
			if ( ! is_array( $data ) ) {
				continue;
			}
			$type = $data['type'] ?? '';
			if ( $type === 'gravity_form' && ! empty( $data['form_id'] ) ) {
				$forms[ absint( $data['form_id'] ) ] ??= $data['form_title'] ?? 'Form #' . $data['form_id'];
			}
			if ( ! in_array( $type, [ 'landing_order', 'site_registration' ], TRUE ) ) {
				continue;
			}
			$kind = $type === 'landing_order' ? 'landing' : 'cart';
			foreach ( (array) ( $data[ $kind === 'landing' ? 'products' : 'cart_items' ] ?? [] ) as $item ) {
				if ( is_array( $item ) && ! empty( $item['product_id'] ) ) {
					$products[ $kind ][ absint( $item['product_id'] ) ] ??= $item['name'] ?? 'Product #' . $item['product_id'];
				}
			}
		}
		$result = [];
		foreach (
			[
				'first_touch_form_id' => [ 'فرم ورود', 'gravity_form', $forms ],
				'first_touch_product' => [
					'محصول ثبت شده',
					'landing_order|site_registration|__products__',
					$products['landing'] + $products['cart'],
				],
			] as $key => [$label, $parent_value, $options]
		) {
			$selected = is_scalar( $values[ $key ] ?? '' ) ? (string) $values[ $key ] : '';
			if ( preg_match( '/^except:[1-9][0-9]*(?:,[1-9][0-9]*){0,5}$/', $selected ) ) {
				$options[ $selected ] = 'Other';
			}
			$result[ $key ] = [
				'key'              => $key,
				'name'             => $key,
				'label'            => $label,
				'type'             => 'select',
				'options'          => $options,
				'placeholder'      => __( 'همه موارد', 'kasebi-erp' ),
				'value'            => $selected,
				'col'              => 12,
				'order'            => 201,
				'search'           => TRUE,
				'depends_on'       => 'first_touch_type',
				'depends_value'    => $parent_value,
				'depends_operator' => $key === 'first_touch_product' ? 'in' : 'equals',
			];
		}
		
		return $result;
	}
	
	public function render_first_touch_column( WP_User $customer, array $column = [], array $context = [] ): void {
		$data = $context['first_touches'][ $customer->ID ] ?? [];
		KERP_Helpers_Template::render_template( 'modules/customers/partials/first-touch-summary.php', [ 'data' => $data ] );
	}
	
	public function get_columns(): array {
		$columns = [
			'customer' => [
				'key'      => 'customer',
				'label'    => KERP_Modules_Customers_Settings::instance()->get_singular_label(),
				'callback' => [ $this, 'render_customer_column' ],
				'order'    => 10,
			],
			'label'    => [
				'key'           => 'label',
				'label'         => __( 'دسته‌بندی', 'kasebi-erp' ),
				'taxonomy_type' => KERP_Modules_Customers_Taxonomies::TYPE_LABEL,
				'callback'      => [ $this, 'render_taxonomy_column' ],
				'class'         => 'tb-col-md',
				'order'         => 20,
			],
			'tag'      => [
				'key'           => 'tag',
				'label'         => __( 'تگ', 'kasebi-erp' ),
				'taxonomy_type' => KERP_Modules_Customers_Taxonomies::TYPE_TAG,
				'callback'      => [ $this, 'render_taxonomy_column' ],
				'class'         => 'tb-col-md',
				'order'         => 30,
			],
			'source'   => [
				'key'           => 'source',
				'label'         => __( 'شیوه آشنایی', 'kasebi-erp' ),
				'taxonomy_type' => KERP_Modules_Customers_Taxonomies::TYPE_SOURCE,
				'callback'      => [ $this, 'render_taxonomy_column' ],
				'class'         => 'tb-col-md',
				'order'         => 40,
			],
		];
		
		foreach ( KERP_Modules_Customers_Fields::instance()->get_all( TRUE ) as $field_key => $field ) {
			if ( empty( $field['column'] ) ) {
				continue;
			}
			
			$columns[ $field_key ] = [
				'key'      => $field_key,
				'label'    => $field['label'],
				'meta_key' => $field['meta_key'],
				'field'    => $field,
				'callback' => [ $this, 'render_custom_field_column' ],
				'class'    => 'tb-col-md',
				'order'    => (int) ( $field['order'] ?? 100 ),
			];
		}
		
		$columns['first_touch'] = [
			'key'      => 'first_touch',
			'label'    => __( 'اولین ورود', 'kasebi-erp' ),
			'class'    => 'kerp-attribution-column',
			'callback' => [ $this, 'render_first_touch_column' ],
			'order'    => 90,
		];
		$columns                = apply_filters( 'kerp_customers_list_columns', $columns );
		$this->sort( $columns );
		
		return $columns;
	}
	
	public function get_bulk_actions(): array {
		return KERP_Modules_Customers_Bulk_Actions::instance()->get_actions();
	}
	
	public function render_column( string $column_key, WP_User $customer, array $context = [] ): void {
		$columns = $this->get_columns();
		$column  = $columns[ $column_key ] ?? [];
		
		if ( empty( $column ) ) {
			return;
		}
		
		if ( ! empty( $column['callback'] ) && is_callable( $column['callback'] ) ) {
			call_user_func( $column['callback'], $customer, $column, $context );
			
			return;
		}
		
		if ( ! empty( $column['meta_key'] ) ) {
			echo esc_html( (string) get_user_meta( $customer->ID, $column['meta_key'], TRUE ) );
			
			return;
		}
		
		do_action( 'kerp_customers_render_column_' . sanitize_key( $column_key ), $customer, $column, $context );
	}
	
	public function render_customer_column(
		WP_User $customer,
		array $column = [],
		array $context = []
	): void {
		KERP_Helpers_Template::render_template( 'app/components/user-card.php', [
			'user_id'    => $customer->ID,
			'show_phone' => TRUE,
		] );
	}
	
	public function render_custom_field_column(
		WP_User $customer,
		array $column = [],
		array $context = []
	): void {
		$field = isset( $column['field'] ) && is_array( $column['field'] )
			? $column['field']
			: KERP_Modules_Customers_Fields::instance()->get( (string) ( $column['key'] ?? '' ) );
		
		if ( ! is_array( $field ) ) {
			return;
		}
		
		$meta_key = sanitize_key( (string) ( $column['meta_key'] ?? $field['meta_key'] ?? '' ) );
		if ( $meta_key === '' ) {
			return;
		}
		
		$value = get_user_meta( $customer->ID, $meta_key, TRUE );
		echo esc_html( KERP_Modules_Customers_Fields::instance()->format_display_value( $value, $field ) );
	}
	
	public function render_taxonomy_column(
		WP_User $customer,
		array $column = [],
		array $context = []
	): void {
		$type = sanitize_key( (string) ( $column['taxonomy_type'] ?? '' ) );
		
		if ( $type === '' ) {
			return;
		}
		
		$taxonomies = KERP_Modules_Customers_Taxonomies::instance();
		$term_keys  = $taxonomies->get_customer_terms( $customer->ID, $type );
		$term_keys  = is_array( $term_keys ) ? $term_keys : [ $term_keys ];
		$term_keys  = array_values( array_filter( array_map( 'sanitize_key', $term_keys ) ) );
		
		if ( empty( $term_keys ) ) {
			return;
		}
		
		echo '<div class="d-flex align-items-center flex-wrap fs-16px" style="gap: 10px">';
		
		foreach ( $term_keys as $term_key ) {
			$term = $taxonomies->get_term( $type, $term_key );
			
			if ( ! is_array( $term ) ) {
				continue;
			}
			
			$name = sanitize_text_field( (string) ( $term['name'] ?? $term_key ) );
			$icon = $this->sanitize_icon_class( (string) ( $term['icon'] ?? '' ) );
			
			if ( $icon !== '' ) {
				printf(
					'<span class="d-inline-flex align-items-center justify-content-center" data-bs-toggle="tooltip" data-bs-placement="top" title="%1$s"><em class="%2$s"></em></span>',
					esc_attr( $name ),
					esc_attr( $icon )
				);
				
				continue;
			}
			
			printf(
				'<span class="badge badge-dim bg-outline-secondary">%s</span>',
				esc_html( $name )
			);
		}
		
		echo '</div>';
	}
	
	public function render_row_icons_column(
		WP_User $customer,
		array $column = [],
		array $context = []
	): void {
		$settings   = KERP_Modules_Customers_Settings::instance();
		$owner_key  = (string) $settings->get( 'owner_meta_key', 'kerp_customer_owner_id' );
		$owner_id   = absint( get_user_meta( $customer->ID, $owner_key, TRUE ) );
		$owner      = $owner_id ? get_userdata( $owner_id ) : FALSE;
		$owner_name = $owner instanceof WP_User ? get_user_name_by_id( $owner->ID ) : '';
		
		$registered_date = date_i18n( 'j F Y', strtotime( $customer->user_registered ) );
		
		$singular_label = $settings->get_singular_label();
		
		$items = [
			'owner'         => [
				'icon'    => 'ni ni-user-check',
				'tooltip' => $owner_name !== ''
					? sprintf(
						__( 'مسئول %1$s: %2$s', 'kasebi-erp' ),
						$singular_label,
						$owner_name
					)
					: sprintf(
						__( 'برای %s مسئولی تعیین نشده است.', 'kasebi-erp' ),
						$singular_label
					),
				'class'   => $owner_name === '' ? 'text-soft' : '',
			],
			'register_date' => [
				'icon'    => 'ni ni-calendar',
				'tooltip' => sprintf(
					__( 'تاریخ عضویت: %s', 'kasebi-erp' ),
					$registered_date
				),
			],
		];
		
		$items = apply_filters(
			'kerp_customers_row_icons',
			$items,
			$customer,
			$context
		);
		
		KERP_Helpers_Template::render_template(
			'app/components/list/row-icons.php',
			[
				'items'   => $items,
				'context' => $context,
			]
		);
	}
	
	private function sanitize_icon_class( string $icon ): string {
		$classes = preg_split( '/\s+/', trim( $icon ) );
		$classes = is_array( $classes ) ? $classes : [];
		$classes = array_filter( array_map( 'sanitize_html_class', $classes ) );
		
		return implode( ' ', $classes );
	}
	
	private function sort( array &$items ): void {
		uasort(
			$items,
			static fn( array $first, array $second ): int => (int) ( $first['order'] ?? 100 ) <=> (int) ( $second['order'] ?? 100 )
		);
	}
	
}
