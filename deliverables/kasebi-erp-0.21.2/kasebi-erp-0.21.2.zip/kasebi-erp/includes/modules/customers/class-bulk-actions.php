<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Customers_Bulk_Actions {
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public function get_actions(): array {
		$actions = [
			'add_label'    => [
				'key'        => 'add_label',
				'label'      => __( 'افزودن برچسب', 'kasebi-erp' ),
				'action'     => 'customers_bulk_add_label',
				'permission' => 'customers',
				'capability' => 'edit',
				'need'       => [ 'customer_ids', 'label' ],
				'attributes' => [
					'data-need' => 'customer_ids,label',
				],
				'icon'       => 'ni ni-label',
				'order'      => 10,
			],
			'remove_label' => [
				'key'        => 'remove_label',
				'label'      => __( 'حذف برچسب', 'kasebi-erp' ),
				'action'     => 'customers_bulk_remove_label',
				'permission' => 'customers',
				'capability' => 'edit',
				'need'       => [ 'customer_ids', 'label' ],
				'attributes' => [
					'data-need' => 'customer_ids,label',
				],
				'icon'       => 'ni ni-label-alt',
				'order'      => 20,
			],
			'add_tag'      => [
				'key'        => 'add_tag',
				'label'      => __( 'افزودن تگ', 'kasebi-erp' ),
				'action'     => 'customers_bulk_add_tag',
				'permission' => 'customers',
				'capability' => 'edit',
				'need'       => [ 'customer_ids', 'tag' ],
				'attributes' => [
					'data-need' => 'customer_ids,tag',
				],
				'icon'       => 'ni ni-tag',
				'order'      => 30,
			],
			'remove_tag'   => [
				'key'        => 'remove_tag',
				'label'      => __( 'حذف تگ', 'kasebi-erp' ),
				'action'     => 'customers_bulk_remove_tag',
				'permission' => 'customers',
				'capability' => 'edit',
				'need'       => [ 'customer_ids', 'tag' ],
				'attributes' => [
					'data-need' => 'customer_ids,tag',
				],
				'icon'       => 'ni ni-tag-alt',
				'order'      => 40,
			],
			'set_source'   => [
				'key'        => 'set_source',
				'label'      => __( 'تغییر شیوه آشنایی', 'kasebi-erp' ),
				'action'     => 'customers_bulk_set_source',
				'permission' => 'customers',
				'capability' => 'edit',
				'need'       => [ 'customer_ids', 'source' ],
				'attributes' => [
					'data-need' => 'customer_ids,source',
				],
				'icon'       => 'ni ni-link-alt',
				'order'      => 50,
			],
			'assign_owner' => [
				'key'        => 'assign_owner',
				'label'      => __( 'تخصیص مسئول', 'kasebi-erp' ),
				'action'     => 'customers_bulk_assign_owner',
				'permission' => 'customers',
				'capability' => 'assign',
				'need'       => [ 'customer_ids', 'owner_id' ],
				'attributes' => [
					'data-need' => 'customer_ids,owner_id',
				],
				'icon'       => 'ni ni-user-check',
				'order'      => 60,
			],
		];
		
		$actions = apply_filters( 'kerp_customers_bulk_actions', $actions );
		
		$actions = array_filter(
			$actions,
			fn( array $action ): bool => $this->can(
				(string) ( $action['permission'] ?? 'customers' ),
				(string) ( $action['capability'] ?? 'edit' )
			)
		);
		
		uasort(
			$actions,
			static fn( array $first, array $second ): int => (int) ( $first['order'] ?? 100 ) <=> (int) ( $second['order'] ?? 100 )
		);
		
		return $actions;
	}
	
	public function execute( string $action_key, array $customer_ids, array $payload = [] ): bool|WP_Error {
		$action_key   = sanitize_key( $action_key );
		$customer_ids = array_values( array_filter( array_unique( array_map( 'absint', $customer_ids ) ) ) );
		$actions      = $this->get_actions();
		$definition   = $actions[ $action_key ] ?? NULL;
		
		if ( ! is_array( $definition ) ) {
			return new WP_Error( 'kerp_customers_bulk_action_invalid', __( 'عملیات گروهی معتبر نیست.', 'kasebi-erp' ) );
		}
		
		if ( empty( $customer_ids ) ) {
			return new WP_Error( 'kerp_customers_bulk_no_customers', sprintf( __( 'هیچ %s انتخاب نشده است.', 'kasebi-erp' ), KERP_Modules_Customers_Settings::instance()
			                                                                                                                                                ->get_singular_label() ) );
		}
		
		foreach ( (array) ( $definition['need'] ?? [] ) as $required_key ) {
			if ( $required_key === 'customer_ids' ) {
				continue;
			}
			if ( ! array_key_exists( $required_key, $payload ) || $payload[ $required_key ] === '' ) {
				return new WP_Error(
					'kerp_customers_bulk_missing_value',
					sprintf(
					/* translators: %s: required payload key. */
						__( 'مقدار موردنیاز «%s» ارسال نشده است.', 'kasebi-erp' ),
						$required_key
					)
				);
			}
		}
		
		do_action( 'kerp_customers_before_bulk_action', $action_key, $customer_ids, $payload, $definition );
		
		$result = match ( $action_key ) {
			'add_label' => $this->update_array_term( $customer_ids, KERP_Modules_Customers_Taxonomies::TYPE_LABEL, $payload['label'], TRUE ),
			'remove_label' => $this->update_array_term( $customer_ids, KERP_Modules_Customers_Taxonomies::TYPE_LABEL, $payload['label'], FALSE ),
			'add_tag' => $this->update_array_term( $customer_ids, KERP_Modules_Customers_Taxonomies::TYPE_TAG, $payload['tag'], TRUE ),
			'remove_tag' => $this->update_array_term( $customer_ids, KERP_Modules_Customers_Taxonomies::TYPE_TAG, $payload['tag'], FALSE ),
			'set_source' => $this->set_source( $customer_ids, $payload['source'] ),
			'assign_owner' => $this->assign_owner( $customer_ids, absint( $payload['owner_id'] ) ),
			default => apply_filters( 'kerp_customers_execute_bulk_action', NULL, $action_key, $customer_ids, $payload, $definition ),
		};
		
		if ( $result === NULL ) {
			do_action( 'kerp_customers_bulk_action_' . $action_key, $customer_ids, $payload, $definition );
			$result = TRUE;
		}
		
		do_action( 'kerp_customers_after_bulk_action', $action_key, $customer_ids, $payload, $definition, $result );
		
		return $result;
	}
	
	private function update_array_term( array $customer_ids, string $type, mixed $term, bool $add ): bool {
		$taxonomies = KERP_Modules_Customers_Taxonomies::instance();
		$term       = sanitize_key( (string) $term );
		
		foreach ( $customer_ids as $customer_id ) {
			$terms = (array) $taxonomies->get_customer_terms( $customer_id, $type );
			
			if ( $add ) {
				$terms[] = $term;
			} else {
				$terms = array_values( array_diff( $terms, [ $term ] ) );
			}
			
			$taxonomies->set_customer_terms( $customer_id, $type, $terms );
		}
		
		return TRUE;
	}
	
	private function set_source( array $customer_ids, mixed $source ): bool {
		$source     = sanitize_key( (string) $source );
		$taxonomies = KERP_Modules_Customers_Taxonomies::instance();
		
		foreach ( $customer_ids as $customer_id ) {
			$taxonomies->set_customer_terms(
				$customer_id,
				KERP_Modules_Customers_Taxonomies::TYPE_SOURCE,
				$source
			);
		}
		
		return TRUE;
	}
	
	private function assign_owner( array $customer_ids, int $owner_id ): bool {
		$meta_key = (string) KERP_Modules_Customers_Settings::instance()
		                                                    ->get( 'owner_meta_key', 'kerp_customer_owner_id' );
		
		foreach ( $customer_ids as $customer_id ) {
			update_user_meta( $customer_id, $meta_key, $owner_id );
		}
		
		return TRUE;
	}
	
	private function can( string $permission, string $action ): bool {
		if ( function_exists( 'kerp_can' ) ) {
			return kerp_can( sanitize_key( $permission ), sanitize_key( $action ) );
		}
		
		return current_user_can( 'edit_users' );
	}
	
}
