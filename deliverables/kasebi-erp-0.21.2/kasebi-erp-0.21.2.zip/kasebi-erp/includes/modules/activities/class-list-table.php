<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Activities_List_Table {
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public function get_filters( array $values = [] ): array {
		$occurred = isset( $values['occurred'] ) && is_array( $values['occurred'] ) ? $values['occurred'] : [];
		$filters  = [
			'search'     => [
				'key'         => 'search',
				'name'        => 'search',
				'label'       => __( 'جستجو', 'kasebi-erp' ),
				'type'        => 'text',
				'placeholder' => __( 'عنوان یا شرح فعالیت', 'kasebi-erp' ),
				'value'       => sanitize_text_field( (string) ( $values['search'] ?? '' ) ),
				'order'       => 5,
				'col'         => 12,
			],
			'type_key'   => [
				'key'         => 'type_key',
				'name'        => 'type_key',
				'label'       => __( 'نوع فعالیت', 'kasebi-erp' ),
				'type'        => 'select',
				'options'     => KERP_Modules_Activities_Settings::instance()->get_type_options( FALSE ),
				'placeholder' => __( 'همه انواع', 'kasebi-erp' ),
				'value'       => sanitize_key( (string) ( $values['type_key'] ?? '' ) ),
				'order'       => 20,
			],
			'created_by' => [
				'key'         => 'created_by',
				'name'        => 'created_by',
				'label'       => __( 'ثبت‌کننده', 'kasebi-erp' ),
				'type'        => 'select',
				'options'     => KERP_Modules_Activities_Form::instance()->get_creator_options(),
				'placeholder' => __( 'همه کاربران', 'kasebi-erp' ),
				'value'       => absint( $values['created_by'] ?? 0 ),
				'order'       => 30,
			],
			'occurred'   => [
				'key'   => 'occurred',
				'name'  => 'occurred',
				'label' => __( 'تاریخ فعالیت', 'kasebi-erp' ),
				'type'  => 'date-range',
				'col'   => 12,
				'value' => [
					'from' => $occurred['from'] ?? '',
					'to'   => $occurred['to'] ?? '',
				],
				'order' => 40,
			],
		];
		$filters  = apply_filters( 'kerp_activities_list_filters', $filters, $values );
		uasort( $filters, static fn( array $first, array $second ): int => (int) ( $first['order'] ?? 100 ) <=> (int) ( $second['order'] ?? 100 ) );
		
		return $filters;
	}
	
}
