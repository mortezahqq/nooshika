<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Activities_Api {
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {
		add_action( 'kasebi_ajax_activities_save', [ $this, 'save_activity' ] );
		add_action( 'kasebi_ajax_activities_delete', [ $this, 'delete_activity' ] );
		add_action( 'kasebi_ajax_activities_save_settings', [ $this, 'save_settings' ] );
		add_action( 'kasebi_ajax_activities_save_type', [ $this, 'save_type' ] );
		add_action( 'kasebi_ajax_activities_delete_type', [ $this, 'delete_type' ] );
	}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public function save_activity(): void {
		$activity_id = absint( $_POST['activity_id'] ?? 0 );
		$this->guard( $activity_id ? 'edit' : 'create' );
		$occurred_date = $this->post_text( 'occurred_date' );
		$occurred_time = $this->post_text( 'occurred_time' );
		
		$gregorian_date = KERP_Helpers_Date::jalali_to_gregorian( $occurred_date );
		
		if ( empty( $gregorian_date ) ) {
			$this->error( __( 'تاریخ انجام فعالیت معتبر نیست.', 'kasebi-erp' ) );
		}
		
		$occurred_time = $this->normalize_time(
			$this->post_text( 'occurred_time' )
		);
		
		if ( is_wp_error( $occurred_time ) ) {
			$this->error( $occurred_time->get_error_message() );
		}
		
		$occurred_at = $gregorian_date . ' ' . $occurred_time . ':00';
		$attachment  = $this->sanitize_attachments(
			$this->post_text( 'attachment' )
		);
		
		$result = KERP_Modules_Activities_Module::instance()->save(
			[
				'customer_id' => absint( $_POST['customer_id'] ?? 0 ),
				'type_key'    => $this->post_text( 'type_key' ),
				'title'       => $this->post_text( 'title' ),
				'content'     => $this->post_content( 'content' ),
				'occurred_at' => $occurred_at,
				'metadata'    => [
					'attachment' => $attachment,
				],
			],
			$activity_id
		);
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		$page          = $this->post_text( 'page' );
		$page          = $page !== '' ? $page : '/erp/activities/';
		$page_response = KERP_Api_Page_Content::build_page_response( $page, [], TRUE );
		$this->success( $activity_id ? __( 'فعالیت با موفقیت ویرایش شد.', 'kasebi-erp' ) : __( 'فعالیت با موفقیت ثبت شد.', 'kasebi-erp' ), array_merge( $page_response, [ 'activity_id' => (int) $result ] ) );
	}
	
	private function normalize_time( string $time ): string|WP_Error {
		$time = sanitize_text_field( $time );
		
		if ( function_exists( 'nooshika_sanitize_numbers' ) ) {
			$time = nooshika_sanitize_numbers( $time );
		}
		
		$time = trim( $time );
		
		if ( $time === '' ) {
			return new WP_Error(
				'kerp_activity_missing_time',
				__( 'ساعت فعالیت را وارد کنید.', 'kasebi-erp' )
			);
		}
		
		$time = str_ireplace(
			[
				'ق.ظ',
				'ق ظ',
				'ب.ظ',
				'ب ظ',
			],
			[
				'AM',
				'AM',
				'PM',
				'PM',
			],
			$time
		);
		
		$time = preg_replace(
			'/\b([ap])\.?\s*m\.?\b/i',
			'$1M',
			$time
		);
		
		$time = strtoupper(
			trim(
				preg_replace(
					'/\s+/u',
					' ',
					(string) $time
				)
			)
		);
		
		$has_meridiem = preg_match(
			                '/(?:AM|PM)$/i',
			                $time
		                ) === 1;
		
		$formats = $has_meridiem
			? [
				'!g:i A',
				'!g:i:s A',
			]
			: [
				'!H:i',
				'!H:i:s',
			];
		
		foreach ( $formats as $format ) {
			$date_time = DateTimeImmutable::createFromFormat(
				$format,
				$time,
				wp_timezone()
			);
			
			$errors = DateTimeImmutable::getLastErrors();
			
			if (
				$date_time instanceof DateTimeImmutable
				&& (
					$errors === FALSE
					|| (
						(int) $errors['warning_count'] === 0
						&& (int) $errors['error_count'] === 0
					)
				)
			) {
				return $date_time->format( 'H:i' );
			}
		}
		
		return new WP_Error(
			'kerp_activity_invalid_time',
			__( 'ساعت فعالیت معتبر نیست.', 'kasebi-erp' )
		);
	}
	
	private function sanitize_attachments( string $value ): string {
		$attachments = preg_split(
			'/\s*,\s*/',
			trim( $value ),
			- 1,
			PREG_SPLIT_NO_EMPTY
		);
		
		$clean = [];
		
		foreach ( (array) $attachments as $attachment ) {
			$attachment = esc_url_raw(
				trim( (string) $attachment )
			);
			
			if ( $attachment === '' ) {
				continue;
			}
			
			$clean[] = $attachment;
		}
		
		return implode(
			',',
			array_unique( $clean )
		);
	}
	
	public function delete_activity(): void {
		$this->guard( 'delete' );
		$activity_id = absint( $_POST['activity_id'] ?? $_POST['item_id'] ?? 0 );
		if ( ! $activity_id ) {
			$this->error( __( 'شناسه فعالیت معتبر نیست.', 'kasebi-erp' ) );
		}
		$result = KERP_Modules_Activities_Module::instance()->delete( $activity_id );
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		$page          = $this->post_text( 'page' );
		$page          = $page !== '' ? $page : '/erp/activities/';
		$page_response = KERP_Api_Page_Content::build_page_response( $page, [], TRUE );
		$this->success( __( 'فعالیت با موفقیت حذف شد.', 'kasebi-erp' ), $page_response );
	}
	
	public function save_settings(): void {
		$this->guard( 'manage_settings' );
		$settings = isset( $_POST['settings'] ) && is_array( $_POST['settings'] ) ? wp_unslash( $_POST['settings'] ) : [];
		KERP_Modules_Activities_Settings::instance()->update( $settings );
		$page_response = KERP_Api_Page_Content::build_page_response( '/erp/settings/activities/', [], TRUE );
		$this->success( __( 'تنظیمات فعالیت‌ها ذخیره شد.', 'kasebi-erp' ), $page_response );
	}
	
	public function save_type(): void {
		$this->guard( 'manage_settings' );
		
		$raw_type = (
			isset( $_POST['type'] ) &&
			is_array( $_POST['type'] )
		)
			? wp_unslash( $_POST['type'] )
			: [];
		
		$active_value = $raw_type['active'] ?? 0;
		
		if ( is_array( $active_value ) ) {
			$active = in_array(
				'1',
				array_map( 'strval', $active_value ),
				TRUE
			);
		} else {
			$active = (string) $active_value === '1';
		}
		
		$result = KERP_Modules_Activities_Settings::instance()->save_type(
			[
				'key'    => sanitize_key(
					(string) ( $raw_type['key'] ?? '' )
				),
				'label'  => sanitize_text_field(
					(string) ( $raw_type['label'] ?? '' )
				),
				'icon'   => trim(
					(string) ( $raw_type['icon'] ?? '' )
				),
				'color'  => sanitize_key(
					(string) ( $raw_type['color'] ?? 'primary' )
				),
				'order'  => absint(
					$raw_type['order'] ?? 100
				),
				'active' => $active,
			],
			sanitize_key(
				(string) ( $raw_type['original_key'] ?? '' )
			)
		);
		
		if ( is_wp_error( $result ) ) {
			$this->error(
				$result->get_error_message()
			);
		}
		
		$page_response = KERP_Api_Page_Content::build_page_response(
			'/erp/settings/activities/',
			[],
			TRUE
		);
		
		$this->success(
			__( 'نوع فعالیت با موفقیت ذخیره شد.', 'kasebi-erp' ),
			$page_response
		);
	}
	
	public function delete_type(): void {
		$this->guard( 'manage_settings' );
		
		$type_key = sanitize_key(
			$this->post_text( 'key' )
				?: $this->post_text( 'item_id' )
		);
		
		if ( $type_key === '' ) {
			$this->error(
				__( 'شناسه نوع فعالیت ارسال نشده است.', 'kasebi-erp' )
			);
		}
		
		$result = KERP_Modules_Activities_Settings::instance()->delete_type(
			$type_key
		);
		
		if ( is_wp_error( $result ) ) {
			$this->error(
				$result->get_error_message()
			);
		}
		
		$page_response = KERP_Api_Page_Content::build_page_response(
			'/erp/settings/activities/',
			[],
			TRUE
		);
		
		$this->success(
			__( 'نوع فعالیت با موفقیت حذف شد.', 'kasebi-erp' ),
			$page_response
		);
	}
	
	private function guard( string $action ): void {
		if ( ! is_user_logged_in() ) {
			$this->error( __( 'برای انجام این عملیات باید وارد حساب کاربری شوید.', 'kasebi-erp' ) );
		}
		if ( ! KERP_App::instance()->current_user_has_access() ) {
			$this->error( __( 'شما به سامانه دسترسی ندارید.', 'kasebi-erp' ) );
		}
		if ( ! kerp_can( 'activities.' . sanitize_key( $action ), 'action' ) ) {
			$this->error( __( 'شما اجازه انجام این عملیات را ندارید.', 'kasebi-erp' ) );
		}
	}
	
	private function post_text( string $key ): string {
		if ( ! isset( $_POST[ $key ] ) || is_array( $_POST[ $key ] ) ) {
			return '';
		}
		
		return sanitize_text_field( wp_unslash( $_POST[ $key ] ) );
	}
	
	private function post_content( string $key ): string {
		if ( ! isset( $_POST[ $key ] ) || is_array( $_POST[ $key ] ) ) {
			return '';
		}
		
		return wp_kses_post( wp_unslash( $_POST[ $key ] ) );
	}
	
	private function success( string $message, array $data = [] ): void {
		wp_send_json( array_merge( [ 'status' => 'success', 'message' => $message, 'msg' => $message ], $data ) );
	}
	
	private function error( string $message, array $data = [] ): void {
		wp_send_json( array_merge( [ 'status' => 'error', 'message' => $message, 'msg' => $message ], $data ) );
	}
	
}
