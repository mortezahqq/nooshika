<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Activities_Query {
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public function get_by_id( int $activity_id ): ?array {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . KERP_Modules_Activities_Module::table() . ' WHERE id = %d LIMIT 1', absint( $activity_id ) ), ARRAY_A );
		
		return is_array( $row ) ? $this->normalize_row( $row ) : NULL;
	}
	
	public function find( array $args = [] ): array {
		global $wpdb;
		$defaults = [
			'customer_id' => 0,
			'type_key'    => '',
			'created_by'  => 0,
			'search'      => '',
			'date_from'   => '',
			'date_to'     => '',
			'page_number' => 1,
			'per_page'    => KERP_Modules_Activities_Settings::instance()->get( 'default_per_page', 20 ),
			'order'       => 'DESC',
		];
		$args     = wp_parse_args( $args, $defaults );
		$where    = [ '1=1' ];
		$params   = [];
		if ( absint( $args['customer_id'] ) ) {
			$where[]  = 'customer_id = %d';
			$params[] = absint( $args['customer_id'] );
		}
		$type_key = sanitize_key( (string) $args['type_key'] );
		if ( $type_key !== '' ) {
			$where[]  = 'type_key = %s';
			$params[] = $type_key;
		}
		if ( absint( $args['created_by'] ) ) {
			$where[]  = 'created_by = %d';
			$params[] = absint( $args['created_by'] );
		}
		$search = sanitize_text_field( (string) $args['search'] );
		if ( $search !== '' ) {
			$like     = '%' . $wpdb->esc_like( $search ) . '%';
			$where[]  = '(title LIKE %s OR content LIKE %s)';
			$params[] = $like;
			$params[] = $like;
		}
		$date_from = trim( (string) $args['date_from'] );
		
		if ( $date_from !== '' ) {
			$gregorian_date = KERP_Helpers_Date::jalali_to_gregorian( $date_from );
			
			if ( $gregorian_date !== '' ) {
				$where[]  = 'occurred_at >= %s';
				$params[] = $gregorian_date . ' 00:00:00';
			}
		}
		$date_to = trim( (string) $args['date_to'] );
		
		if ( $date_to !== '' ) {
			$gregorian_date = KERP_Helpers_Date::jalali_to_gregorian( $date_to );
			
			if ( $gregorian_date !== '' ) {
				$where[]  = 'occurred_at <= %s';
				$params[] = $gregorian_date . ' 23:59:59';
			}
		}
		$scope = kerp_list_scope( 'activities' );
		if ( $scope === 'own' ) {
			$where[]  = 'created_by = %d';
			$params[] = get_current_user_id();
		} elseif ( $scope === 'team' ) {
			$team_user_ids = apply_filters( 'kerp_activities_team_user_ids', [ get_current_user_id() ], get_current_user_id() );
			$team_user_ids = array_values( array_filter( array_map( 'absint', is_array( $team_user_ids ) ? $team_user_ids : [] ) ) );
			if ( empty( $team_user_ids ) ) {
				$where[] = '1=0';
			} else {
				$where[] = 'created_by IN (' . implode( ',', array_fill( 0, count( $team_user_ids ), '%d' ) ) . ')';
				$params  = array_merge( $params, $team_user_ids );
			}
		} elseif ( $scope === 'none' ) {
			$where[] = '1=0';
		}
		$page_number = max( 1, absint( $args['page_number'] ) );
		$per_page    = max( 1, min( 200, absint( $args['per_page'] ) ) );
		$offset      = ( $page_number - 1 ) * $per_page;
		$order       = strtoupper( (string) $args['order'] ) === 'ASC' ? 'ASC' : 'DESC';
		$where_sql   = implode( ' AND ', $where );
		$count_sql   = 'SELECT COUNT(*) FROM ' . KERP_Modules_Activities_Module::table() . ' WHERE ' . $where_sql;
		if ( ! empty( $params ) ) {
			$count_sql = $wpdb->prepare( $count_sql, ...$params );
		}
		$total       = absint( $wpdb->get_var( $count_sql ) );
		$list_sql    = 'SELECT * FROM ' . KERP_Modules_Activities_Module::table() . ' WHERE ' . $where_sql . ' ORDER BY occurred_at ' . $order . ', id ' . $order . ' LIMIT %d OFFSET %d';
		$list_params = array_merge( $params, [ $per_page, $offset ] );
		$list_sql    = $wpdb->prepare( $list_sql, ...$list_params );
		$rows        = $wpdb->get_results( $list_sql, ARRAY_A );
		$items       = [];
		foreach ( (array) $rows as $row ) {
			if ( is_array( $row ) ) {
				$items[] = $this->normalize_row( $row );
			}
		}
		
		return apply_filters( 'kerp_activities_query_result', [
			'items'        => $items,
			'total'        => $total,
			'per_page'     => $per_page,
			'page_number'  => $page_number,
			'total_pages'  => max( 1, (int) ceil( $total / $per_page ) ),
			'request_args' => $args,
		], $args );
	}
	
	private function normalize_row( array $row ): array {
		foreach ( [ 'id', 'customer_id', 'created_by', 'updated_by' ] as $key ) {
			$row[ $key ] = absint( $row[ $key ] ?? 0 );
		}
		$row['type_key'] = sanitize_key( (string) ( $row['type_key'] ?? '' ) );
		$row['title']    = sanitize_text_field( (string) ( $row['title'] ?? '' ) );
		$row['content']  = (string) ( $row['content'] ?? '' );
		$row['metadata'] = json_decode( (string) ( $row['metadata'] ?? '' ), TRUE );
		$row['metadata'] = is_array( $row['metadata'] ) ? $row['metadata'] : [];
		
		return $row;
	}
	
}
