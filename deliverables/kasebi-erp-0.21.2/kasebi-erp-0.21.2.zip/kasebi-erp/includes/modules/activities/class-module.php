<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Activities_Module {
	
	private const DB_VERSION        = '1.0.0';
	
	private const DB_VERSION_OPTION = 'kerp_activities_db_version';
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {
		$this->load_services();
		$this->maybe_install();
		$this->register_hooks();
	}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	private function load_services(): void {
		KERP_Modules_Activities_Settings::instance();
		KERP_Modules_Activities_Query::instance();
		KERP_Modules_Activities_Form::instance();
		KERP_Modules_Activities_List_Table::instance();
		KERP_Modules_Activities_Api::instance();
	}
	
	private function register_hooks(): void {
		add_filter( 'kerp_app_pages', [ $this, 'register_pages' ], 30 );
		add_filter( 'kerp_customer_profile_tabs', [ $this, 'register_customer_tab' ], 30, 3 );
		add_filter( 'kerp_customers_profile_dropdown_actions', [ $this, 'register_profile_dropdown_action' ], 30, 3 );
		add_action( 'kerp_customer_profile_modals', [ $this, 'render_customer_modal' ], 30, 4 );
		add_action( 'deleted_user', [ $this, 'delete_customer_activities' ] );
		add_filter( 'kerp_employee_permission_groups', [ $this, 'register_employee_permissions' ], 30 );
	}
	
	public static function table(): string {
		global $wpdb;
		
		return $wpdb->prefix . 'kasebi_erp_activities';
	}
	
	public static function install(): void {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$table   = self::table();
		$charset = $wpdb->get_charset_collate();
		$sql     = "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			customer_id BIGINT UNSIGNED NOT NULL,
			type_key VARCHAR(100) NOT NULL,
			title VARCHAR(190) NOT NULL,
			content LONGTEXT NULL,
			occurred_at DATETIME NOT NULL,
			created_by BIGINT UNSIGNED NOT NULL,
			updated_by BIGINT UNSIGNED NULL,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NULL,
			metadata LONGTEXT NULL,
			PRIMARY KEY  (id),
			KEY idx_customer_date (customer_id, occurred_at),
			KEY idx_type_date (type_key, occurred_at),
			KEY idx_creator_date (created_by, occurred_at),
			KEY idx_occurred_at (occurred_at)
		) {$charset};";
		dbDelta( $sql );
		update_option( self::DB_VERSION_OPTION, self::DB_VERSION, FALSE );
	}
	
	public function register_employee_permissions( array $groups ): array {
		$customer_plural_label = KERP_Modules_Customers_Settings::instance()->get_plural_label();

		if ( ! isset( $groups['crm'] ) || ! is_array( $groups['crm'] ) ) {
			$groups['crm'] = [
				'key'    => 'crm',
				'label'  => sprintf( __( 'مدیریت %s', 'kasebi-erp' ), $customer_plural_label ),
				'icon'   => 'kik fa-users-02',
				'order'  => 20,
				'blocks' => [],
			];
		}
		
		$groups['crm']['blocks']['activities'] = [
			'key'         => 'activities',
			'label'       => __( 'فعالیت‌ها', 'kasebi-erp' ),
			'icon'        => 'kik fa-activity',
			'order'       => 20,
			'permissions' => [
				'activities_view'            => [
					'key'   => 'activities.view',
					'label' => __( 'مشاهده فعالیت‌ها', 'kasebi-erp' ),
					'type'  => 'view',
					'order' => 10,
				],
				'activities_list'            => [
					'key'         => 'activities.list',
					'label'       => __( 'مشاهده فهرست فعالیت‌ها', 'kasebi-erp' ),
					'description' => __( 'دامنه فعالیت‌هایی که در فهرست قابل مشاهده هستند.', 'kasebi-erp' ),
					'type'        => 'view',
					'order'       => 15,
					'scope'       => [
						'options' => [
							'own' => __( 'فقط فعالیت‌های ثبت‌شده توسط خود', 'kasebi-erp' ),
							'all' => __( 'همه فعالیت‌ها', 'kasebi-erp' ),
						],
						'default' => 'own',
					],
				],
				'activities_create'          => [
					'key'   => 'activities.create',
					'label' => __( 'ثبت فعالیت', 'kasebi-erp' ),
					'type'  => 'action',
					'order' => 20,
				],
				'activities_edit'            => [
					'key'   => 'activities.edit',
					'label' => __( 'ویرایش فعالیت', 'kasebi-erp' ),
					'type'  => 'action',
					'order' => 30,
				],
				'activities_delete'          => [
					'key'   => 'activities.delete',
					'label' => __( 'حذف فعالیت', 'kasebi-erp' ),
					'type'  => 'action',
					'order' => 40,
				],
				'activities_manage_settings' => [
					'key'   => 'activities.manage_settings',
					'label' => __( 'مدیریت تنظیمات فعالیت‌ها', 'kasebi-erp' ),
					'type'  => 'action',
					'order' => 50,
				],
			],
		];
		
		return $groups;
	}
	
	public function register_pages( array $pages ): array {
		$customer_plural_label         = KERP_Modules_Customers_Settings::instance()->get_plural_label();
		$crm_group                    = [
			'key'   => 'crm',
			'title' => sprintf( __( 'مدیریت %s', 'kasebi-erp' ), $customer_plural_label ),
			'icon'  => 'kik fa-users-02',
			'order' => 20,
		];
		$settings_group               = [
			'key'        => 'settings',
			'title'      => __( 'تنظیمات', 'kasebi-erp' ),
			'icon'       => 'kik fa-settings-02',
			'order'      => 100,
			'sep_before' => TRUE,
		];
		$settings_menu                = [
			'key'   => 'crm-settings',
			'title' => __( 'تنظیمات CRM', 'kasebi-erp' ),
			'icon'  => 'kik fa-users-02',
			'order' => 50,
		];
		$pages['activities']          = [
			'title'      => __( 'فعالیت‌ها', 'kasebi-erp' ),
			'route'      => 'activities',
			'type'       => 'page',
			'template'   => 'modules/activities/pages/activities.php',
			'permission' => 'activities.view',
			'navigation' => [
				'group' => apply_filters( 'kerp_activities_crm_navigation_group', $crm_group ),
				'icon'  => 'kik fa-activity',
				'order' => 20,
			],
		];
		$pages['activities-settings'] = [
			'title'      => __( 'تنظیمات فعالیت‌ها', 'kasebi-erp' ),
			'route'      => 'settings/activities',
			'type'       => 'settings',
			'template'   => 'modules/activities/settings/general.php',
			'permission' => 'activities.manage_settings',
			'navigation' => [
				'group' => apply_filters( 'kerp_activities_settings_navigation_group', $settings_group ),
				'menu'  => apply_filters( 'kerp_crm_settings_navigation_menu', $settings_menu ),
				'title' => __( 'تنظیمات فعالیت‌ها', 'kasebi-erp' ),
				'order' => 10,
			],
		];
		
		return $pages;
	}
	
	public function register_customer_tab( array $tabs, int $customer_id, WP_User $customer ): array {
		$tabs['activities'] = [
			'key'        => 'activities',
			'title'      => __( 'فعالیت‌ها', 'kasebi-erp' ),
			'icon'       => 'kik fa-activity',
			'order'      => 30,
			'group'      => 'crm',
			'permission' => 'activities.view',
			'action'     => 'view',
			'template'   => 'modules/activities/tabs/customer-activities.php',
		];
		
		return $tabs;
	}
	
	public function register_profile_dropdown_action( array $actions, WP_User $customer, array $profile_context ): array {
		if ( ! kerp_can( 'activities.create', 'action' ) ) {
			return $actions;
		}
		$actions['add_customer_activity'] = [
			'label'      => __( 'ثبت سریع فعالیت', 'kasebi-erp' ),
			'icon'       => 'kik fa-activity',
			'href'       => '#customerActivityModal',
			'order'      => 30,
			'attributes' => [
				'data-bs-toggle' => 'modal',
				'data-bs-target' => '#customerActivityModal',
			],
		];
		
		return $actions;
	}
	
	public function render_customer_modal( int $customer_id, WP_User $customer, array $profile_context, string $active_tab ): void {
		if ( ! kerp_can( 'activities.create', 'action' ) && ! kerp_can( 'activities.edit', 'action' ) ) {
			return;
		}
		$return_page = '/erp/customers/' . $customer_id . '/';
		if ( $active_tab !== '' ) {
			$return_page = add_query_arg( 'tab', sanitize_key( $active_tab ), $return_page );
		}
		KERP_Helpers_Template::render_template( 'modules/activities/modals/activity-form.php', [
			'customer_id' => $customer_id,
			'return_page' => $return_page,
			'modal_id'    => 'customerActivityModal',
		] );
	}
	
	public function save( array $data, int $activity_id = 0 ): int|WP_Error {
		global $wpdb;
		$activity_id = absint( $activity_id );
		$customer_id = absint( $data['customer_id'] ?? 0 );
		if ( ! ( get_userdata( $customer_id ) instanceof WP_User ) ) {
			return new WP_Error( 'kerp_activity_invalid_customer', sprintf( __( '%s معتبر نیست.', 'kasebi-erp' ), KERP_Modules_Customers_Settings::instance()->get_singular_label() ) );
		}
		$type_key = sanitize_key( (string) ( $data['type_key'] ?? '' ) );
		$types    = KERP_Modules_Activities_Settings::instance()->get_types();
		if ( $type_key === '' || ! isset( $types[ $type_key ] ) ) {
			return new WP_Error( 'kerp_activity_invalid_type', __( 'نوع فعالیت معتبر نیست.', 'kasebi-erp' ) );
		}
		$title = sanitize_text_field( (string) ( $data['title'] ?? '' ) );
		if ( $title === '' ) {
			return new WP_Error( 'kerp_activity_empty_title', __( 'عنوان فعالیت را وارد کنید.', 'kasebi-erp' ) );
		}
		$occurred_at = sanitize_text_field( (string) ( $data['occurred_at'] ?? '' ) );
		if ( $occurred_at === '' || ! strtotime( $occurred_at ) ) {
			return new WP_Error( 'kerp_activity_invalid_date', __( 'تاریخ فعالیت معتبر نیست.', 'kasebi-erp' ) );
		}
		$now      = current_time( 'mysql' );
		$user_id  = get_current_user_id();
		$metadata = [];
		
		if ( is_array( $existing ) ) {
			$existing_metadata = json_decode(
				(string) ( $existing['metadata'] ?? '' ),
				TRUE
			);
			
			if ( is_array( $existing_metadata ) ) {
				$metadata = $existing_metadata;
			}
		}
		
		$new_metadata = isset( $data['metadata'] ) && is_array( $data['metadata'] )
			? $data['metadata']
			: [];
		
		$metadata = array_merge(
			$metadata,
			$new_metadata
		);
		$record   = [
			'customer_id' => $customer_id,
			'type_key'    => $type_key,
			'title'       => $title,
			'content'     => wp_kses_post(
				(string) ( $data['content'] ?? '' )
			),
			'occurred_at' => $occurred_at,
			'updated_by'  => $user_id,
			'updated_at'  => $now,
			'metadata'    => wp_json_encode(
				$metadata,
				JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
			),
		];
		if ( $activity_id ) {
			$existing = KERP_Modules_Activities_Query::instance()->get_by_id( $activity_id );
			if ( ! $existing ) {
				return new WP_Error( 'kerp_activity_not_found', __( 'فعالیت پیدا نشد.', 'kasebi-erp' ) );
			}
			$result = $wpdb->update( self::table(), $record, [ 'id' => $activity_id ], [
				'%d',
				'%s',
				'%s',
				'%s',
				'%s',
				'%d',
				'%s',
				'%s',
			], [ '%d' ] );
			if ( $result === FALSE ) {
				return new WP_Error( 'kerp_activity_update_failed', __( 'ویرایش فعالیت انجام نشد.', 'kasebi-erp' ) );
			}
			do_action( 'kerp_activity_updated', $activity_id, $record, $existing );
			
			return $activity_id;
		}
		$record['created_by'] = $user_id;
		$record['created_at'] = $now;
		$result               = $wpdb->insert( self::table(), $record, [
			'%d',
			'%s',
			'%s',
			'%s',
			'%s',
			'%d',
			'%s',
			'%s',
			'%d',
			'%s',
		] );
		if ( $result === FALSE ) {
			return new WP_Error( 'kerp_activity_insert_failed', __( 'ثبت فعالیت انجام نشد.', 'kasebi-erp' ) );
		}
		$activity_id = (int) $wpdb->insert_id;
		do_action( 'kerp_activity_created', $activity_id, $record );
		
		return $activity_id;
	}
	
	public function delete( int $activity_id ): bool|WP_Error {
		global $wpdb;
		$activity = KERP_Modules_Activities_Query::instance()->get_by_id( $activity_id );
		if ( ! $activity ) {
			return new WP_Error( 'kerp_activity_not_found', __( 'فعالیت پیدا نشد.', 'kasebi-erp' ) );
		}
		$result = $wpdb->delete( self::table(), [ 'id' => $activity_id ], [ '%d' ] );
		if ( $result === FALSE ) {
			return new WP_Error( 'kerp_activity_delete_failed', __( 'حذف فعالیت انجام نشد.', 'kasebi-erp' ) );
		}
		do_action( 'kerp_activity_deleted', $activity_id, $activity );
		
		return TRUE;
	}
	
	public function get_populate_data( array $activity ): array {
		$metadata = json_decode( (string) ( $activity['metadata'] ?? '' ), TRUE );
		$metadata = is_array( $metadata ) ? $metadata : [];
		
		$occurred_at        = (string) ( $activity['occurred_at'] ?? '' );
		$occurred_timestamp = $occurred_at !== '' ? strtotime( $occurred_at ) : FALSE;
		
		return [
			'activity_id'   => [
				'id'    => '#kerp-activity-id',
				'type'  => 'text',
				'value' => absint( $activity['id'] ?? 0 ),
			],
			'customer_id'   => [
				'id'    => '#kerp-activity-customer-id',
				'type'  => 'select',
				'value' => absint( $activity['customer_id'] ?? 0 ),
			],
			'type_key'      => [
				'id'    => '#kerp-activity-type-key',
				'type'  => 'select',
				'value' => sanitize_key( (string) ( $activity['type_key'] ?? '' ) ),
			],
			'title'         => [
				'id'    => '#kerp-activity-title',
				'type'  => 'text',
				'value' => (string) ( $activity['title'] ?? '' ),
			],
			'content'       => [
				'id'    => '#kerp-activity-content',
				'type'  => 'quill',
				'value' => (string) ( $activity['content'] ?? '' ),
			],
			'occurred_date' => [
				'id'    => '#kerp-activity-occurred-date',
				'type'  => 'text',
				'value' => $occurred_timestamp
					? date_i18n( 'Y/m/d', $occurred_timestamp )
					: '',
			],
			'occurred_time' => [
				'id'    => '#kerp-activity-occurred-time',
				'type'  => 'text',
				'value' => $occurred_timestamp
					? date_i18n( 'H:i', $occurred_timestamp )
					: '',
			],
			'attachment'    => [
				'id'    => '#kerp-activity-attachment',
				'type'  => 'upload',
				'value' => esc_url_raw( (string) ( $metadata['attachment'] ?? '' ) ),
			],
		];
	}
	
	public function delete_customer_activities( int $user_id ): void {
		global $wpdb;
		$wpdb->delete( self::table(), [ 'customer_id' => absint( $user_id ) ], [ '%d' ] );
	}
	
	private function maybe_install(): void {
		$installed = (string) get_option( self::DB_VERSION_OPTION, '0.0.0' );
		if ( version_compare( $installed, self::DB_VERSION, '<' ) ) {
			self::install();
		}
	}
	
}
