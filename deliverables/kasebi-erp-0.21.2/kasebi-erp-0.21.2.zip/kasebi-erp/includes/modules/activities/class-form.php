<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Activities_Form {
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public function render_modal( int $customer_id = 0, string $return_page = '/erp/activities/' ): void {
		KERP_Helpers_Template::render_template( 'modules/activities/modals/activity-form.php', [
			'customer_id' => absint( $customer_id ),
			'return_page' => $return_page,
		] );
	}
	
	public function get_customer_options(): array {
		$options  = [];
		$settings = KERP_Modules_Customers_Settings::instance();
		$users    = get_users( apply_filters( 'kerp_activities_customer_query_args', [
			'number'   => 500,
			'orderby'  => 'display_name',
			'order'    => 'ASC',
			'role__in' => (array) $settings->get( 'customer_roles', [ 'customer', 'subscriber' ] ),
		] ) );
		foreach ( $users as $user ) {
			if ( $user instanceof WP_User ) {
				$options[ $user->ID ] = get_user_name_by_id( $user->ID );
			}
		}
		
		return apply_filters( 'kerp_activities_customer_options', $options );
	}
	
	public function get_creator_options(): array {
		global $wpdb;
		
		$employee_ids = $wpdb->get_col(
			'SELECT DISTINCT user_id
		FROM ' . KERP_Services_Access::table() . "
		WHERE role_key IS NOT NULL
		AND role_key <> ''"
		);
		
		$activity_creator_ids = $wpdb->get_col(
			'SELECT DISTINCT created_by
		FROM ' . KERP_Modules_Activities_Module::table() . '
		WHERE created_by > 0'
		);
		
		$user_ids = array_merge(
			(array) $employee_ids,
			(array) $activity_creator_ids
		);
		
		$user_ids = array_values(
			array_unique(
				array_filter(
					array_map(
						'absint',
						$user_ids
					)
				)
			)
		);
		
		$user_ids = apply_filters(
			'kerp_activities_creator_user_ids',
			$user_ids
		);
		
		$user_ids = is_array( $user_ids )
			? array_values(
				array_unique(
					array_filter(
						array_map(
							'absint',
							$user_ids
						)
					)
				)
			)
			: [];
		
		$options = [];
		
		foreach ( $user_ids as $user_id ) {
			$user = get_userdata( $user_id );
			
			if ( ! $user instanceof WP_User ) {
				$options[ $user_id ] = sprintf(
					__( 'کاربر حذف‌شده #%s', 'kasebi-erp' ),
					number_format_i18n( $user_id )
				);
				
				continue;
			}
			
			$options[ $user_id ] = get_user_name_by_id( $user_id );
		}
		
		asort(
			$options,
			SORT_NATURAL | SORT_FLAG_CASE
		);
		
		$options = apply_filters(
			'kerp_activities_creator_options',
			$options
		);
		
		return is_array( $options )
			? $options
			: [];
	}
	
}
