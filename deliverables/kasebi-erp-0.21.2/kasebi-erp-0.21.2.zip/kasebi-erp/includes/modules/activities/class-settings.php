<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Activities_Settings {
	
	public const OPTION_NAME = 'kerp_activities_settings';
	
	private static ?self $instance = NULL;
	private ?array       $settings = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {
		add_action( 'update_option_' . self::OPTION_NAME, [ $this, 'clear_cache' ], 10, 0 );
		add_action( 'add_option_' . self::OPTION_NAME, [ $this, 'clear_cache' ], 10, 0 );
	}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public function defaults(): array {
		return apply_filters( 'kerp_activities_default_settings', [
			'default_per_page' => 20,
			'types'            => [
				'call'           => [
					'key'    => 'call',
					'label'  => __( 'تماس تلفنی', 'kasebi-erp' ),
					'icon'   => 'ni ni-call',
					'color'  => 'primary',
					'order'  => 10,
					'active' => 1,
				],
				'meeting'        => [
					'key'    => 'meeting',
					'label'  => __( 'جلسه حضوری', 'kasebi-erp' ),
					'icon'   => 'ni ni-users',
					'color'  => 'success',
					'order'  => 20,
					'active' => 1,
				],
				'online_meeting' => [
					'key'    => 'online_meeting',
					'label'  => __( 'جلسه آنلاین', 'kasebi-erp' ),
					'icon'   => 'ni ni-video',
					'color'  => 'info',
					'order'  => 30,
					'active' => 1,
				],
				'sms'            => [
					'key'    => 'sms',
					'label'  => __( 'ارسال پیامک', 'kasebi-erp' ),
					'icon'   => 'ni ni-mobile',
					'color'  => 'warning',
					'order'  => 40,
					'active' => 1,
				],
				'message'        => [
					'key'    => 'message',
					'label'  => __( 'ارسال پیام', 'kasebi-erp' ),
					'icon'   => 'ni ni-chat',
					'color'  => 'purple',
					'order'  => 50,
					'active' => 1,
				],
				'document'       => [
					'key'    => 'document',
					'label'  => __( 'ارسال فایل یا مدارک', 'kasebi-erp' ),
					'icon'   => 'ni ni-file-docs',
					'color'  => 'secondary',
					'order'  => 60,
					'active' => 1,
				],
				'other'          => [
					'key'    => 'other',
					'label'  => __( 'سایر', 'kasebi-erp' ),
					'icon'   => 'ni ni-more-h',
					'color'  => 'light',
					'order'  => 100,
					'active' => 1,
				],
			],
		] );
	}
	
	public function all(): array {
		if ( $this->settings !== NULL ) {
			return $this->settings;
		}
		$stored                  = get_option( self::OPTION_NAME, [] );
		$stored                  = is_array( $stored ) ? $stored : [];
		$this->settings          = wp_parse_args( $stored, $this->defaults() );
		$this->settings['types'] = $this->sanitize_types( $this->settings['types'] ?? [] );
		
		return $this->settings;
	}
	
	public function get( string $key, mixed $default = NULL ): mixed {
		$settings = $this->all();
		
		return array_key_exists( $key, $settings ) ? $settings[ $key ] : $default;
	}
	
	public function update( array $settings ): bool {
		$current        = $this->all();
		$clean          = $this->sanitize( array_merge( $current, $settings ) );
		$result         = update_option( self::OPTION_NAME, $clean, FALSE );
		$this->settings = $clean;
		do_action( 'kerp_activities_settings_updated', $clean, $current );
		
		return $result || $clean === $current;
	}
	
	public function sanitize( array $settings ): array {
		$defaults = $this->defaults();
		$types    = $this->sanitize_types( $settings['types'] ?? [] );
		if ( empty( $types ) ) {
			$types = $this->sanitize_types( $defaults['types'] );
		}
		
		return apply_filters( 'kerp_activities_sanitized_settings', [
			'default_per_page' => max( 1, min( 200, absint( $settings['default_per_page'] ?? $defaults['default_per_page'] ) ) ),
			'types'            => $types,
		], $settings );
	}
	
	public function get_types( bool $active_only = FALSE ): array {
		$types = (array) $this->get( 'types', [] );
		if ( $active_only ) {
			$types = array_filter( $types, static fn( array $type ): bool => ! empty( $type['active'] ) );
		}
		uasort( $types, static fn( array $first, array $second ): int => (int) ( $first['order'] ?? 100 ) <=> (int) ( $second['order'] ?? 100 ) );
		
		return apply_filters( 'kerp_activity_types', $types, $active_only );
	}
	
	public function get_type( string $key ): array {
		$key   = sanitize_key( $key );
		$types = $this->get_types();
		if ( isset( $types[ $key ] ) ) {
			return $types[ $key ];
		}
		
		return [
			'key'    => $key,
			'label'  => $key !== '' ? $key : __( 'سایر', 'kasebi-erp' ),
			'icon'   => 'ni ni-more-h',
			'color'  => 'light',
			'order'  => 100,
			'active' => 1,
		];
	}
	
	public function get_type_options( bool $active_only = TRUE ): array {
		$options = [];
		foreach ( $this->get_types( $active_only ) as $key => $type ) {
			$options[ $key ] = (string) ( $type['label'] ?? $key );
		}
		
		return $options;
	}
	
	public function save_type(
		array $type,
		string $original_key = ''
	): bool|WP_Error {
		global $wpdb;
		
		$original_key = sanitize_key( $original_key );
		$key          = sanitize_key(
			(string) ( $type['key'] ?? '' )
		);
		$label        = sanitize_text_field(
			(string) ( $type['label'] ?? '' )
		);
		
		if ( $key === '' ) {
			return new WP_Error(
				'kerp_activity_type_empty_key',
				__( 'کلید نوع فعالیت را وارد کنید.', 'kasebi-erp' )
			);
		}
		
		if ( $label === '' ) {
			return new WP_Error(
				'kerp_activity_type_empty_label',
				__( 'عنوان نوع فعالیت را وارد کنید.', 'kasebi-erp' )
			);
		}
		
		$settings = $this->all();
		$types    = isset( $settings['types'] ) && is_array( $settings['types'] )
			? $settings['types']
			: [];
		
		if (
			$original_key !== '' &&
			! isset( $types[ $original_key ] )
		) {
			return new WP_Error(
				'kerp_activity_type_not_found',
				__( 'نوع فعالیت موردنظر پیدا نشد.', 'kasebi-erp' )
			);
		}
		
		if (
			isset( $types[ $key ] ) &&
			$key !== $original_key
		) {
			return new WP_Error(
				'kerp_activity_type_duplicate_key',
				__( 'نوع فعالیت دیگری با این کلید ثبت شده است.', 'kasebi-erp' )
			);
		}
		
		$icon_classes = preg_split(
			'/\s+/',
			trim( (string) ( $type['icon'] ?? '' ) ),
			- 1,
			PREG_SPLIT_NO_EMPTY
		);
		
		$icon_classes = is_array( $icon_classes )
			? array_map( 'sanitize_html_class', $icon_classes )
			: [];
		
		$icon = implode(
			' ',
			array_filter( $icon_classes )
		);
		
		if ( $icon === '' ) {
			$icon = 'kik fa-activity';
		}
		
		$allowed_colors = [
			'primary',
			'success',
			'info',
			'warning',
			'danger',
			'secondary',
			'purple',
			'light',
		];
		
		$color = sanitize_key(
			(string) ( $type['color'] ?? 'primary' )
		);
		
		if ( ! in_array( $color, $allowed_colors, TRUE ) ) {
			$color = 'primary';
		}
		
		$new_type = [
			'key'    => $key,
			'label'  => $label,
			'icon'   => $icon,
			'color'  => $color,
			'order'  => max(
				0,
				absint( $type['order'] ?? 100 )
			),
			'active' => ! empty( $type['active'] ) ? 1 : 0,
		];
		
		$type_key_changed = (
			$original_key !== '' &&
			$original_key !== $key
		);
		
		if ( $type_key_changed ) {
			$updated_activities = $wpdb->update(
				KERP_Modules_Activities_Module::table(),
				[
					'type_key' => $key,
				],
				[
					'type_key' => $original_key,
				],
				[
					'%s',
				],
				[
					'%s',
				]
			);
			
			if ( $updated_activities === FALSE ) {
				return new WP_Error(
					'kerp_activity_type_migration_failed',
					__( 'به‌روزرسانی نوع فعالیت‌های قبلی انجام نشد.', 'kasebi-erp' )
				);
			}
			
			unset( $types[ $original_key ] );
		}
		
		$types[ $key ] = $new_type;
		
		$saved = $this->update(
			[
				'types' => $types,
			]
		);
		
		if ( ! $saved ) {
			if ( $type_key_changed ) {
				$wpdb->update(
					KERP_Modules_Activities_Module::table(),
					[
						'type_key' => $original_key,
					],
					[
						'type_key' => $key,
					],
					[
						'%s',
					],
					[
						'%s',
					]
				);
			}
			
			return new WP_Error(
				'kerp_activity_type_save_failed',
				__( 'ذخیره نوع فعالیت انجام نشد.', 'kasebi-erp' )
			);
		}
		
		do_action(
			'kerp_activity_type_saved',
			$key,
			$new_type,
			$original_key
		);
		
		return TRUE;
	}
	
	public function delete_type(
		string $type_key
	): bool|WP_Error {
		global $wpdb;
		
		$type_key = sanitize_key( $type_key );
		
		if ( $type_key === '' ) {
			return new WP_Error(
				'kerp_activity_type_empty_key',
				__( 'شناسه نوع فعالیت معتبر نیست.', 'kasebi-erp' )
			);
		}
		
		$settings = $this->all();
		$types    = isset( $settings['types'] ) && is_array( $settings['types'] )
			? $settings['types']
			: [];
		
		if ( ! isset( $types[ $type_key ] ) ) {
			return new WP_Error(
				'kerp_activity_type_not_found',
				__( 'نوع فعالیت موردنظر پیدا نشد.', 'kasebi-erp' )
			);
		}
		
		if ( count( $types ) <= 1 ) {
			return new WP_Error(
				'kerp_activity_type_last_item',
				__( 'حداقل یک نوع فعالیت باید باقی بماند.', 'kasebi-erp' )
			);
		}
		
		$activities_count = (int) $wpdb->get_var(
			$wpdb->prepare(
				'SELECT COUNT(id)
			FROM ' . KERP_Modules_Activities_Module::table() . '
			WHERE type_key = %s',
				$type_key
			)
		);
		
		if ( $activities_count > 0 ) {
			return new WP_Error(
				'kerp_activity_type_in_use',
				__(
					'این نوع در فعالیت‌های ثبت‌شده استفاده شده است؛ به‌جای حذف، آن را غیرفعال کنید.',
					'kasebi-erp'
				)
			);
		}
		
		$deleted_type = $types[ $type_key ];
		
		unset( $types[ $type_key ] );
		
		$saved = $this->update(
			[
				'types' => $types,
			]
		);
		
		if ( ! $saved ) {
			return new WP_Error(
				'kerp_activity_type_delete_failed',
				__( 'حذف نوع فعالیت انجام نشد.', 'kasebi-erp' )
			);
		}
		
		do_action(
			'kerp_activity_type_deleted',
			$type_key,
			$deleted_type
		);
		
		return TRUE;
	}
	
	public function clear_cache(): void {
		$this->settings = NULL;
	}
	
	private function sanitize_types( mixed $types ): array {
		$types = is_array( $types ) ? $types : [];
		$clean = [];
		foreach ( $types as $row_key => $type ) {
			if ( ! is_array( $type ) ) {
				continue;
			}
			$key = sanitize_key( (string) ( $type['key'] ?? $row_key ) );
			if ( $key === '' ) {
				continue;
			}
			$label = sanitize_text_field( (string) ( $type['label'] ?? '' ) );
			if ( $label === '' ) {
				continue;
			}
			$icon_classes  = preg_split( '/\s+/', trim( (string) ( $type['icon'] ?? '' ) ), - 1, PREG_SPLIT_NO_EMPTY );
			$icon_classes  = is_array( $icon_classes ) ? array_map( 'sanitize_html_class', $icon_classes ) : [];
			$color         = sanitize_html_class( (string) ( $type['color'] ?? 'light' ) );
			$clean[ $key ] = [
				'key'    => $key,
				'label'  => $label,
				'icon'   => implode( ' ', array_filter( $icon_classes ) ),
				'color'  => $color !== '' ? $color : 'light',
				'order'  => max( 0, absint( $type['order'] ?? 100 ) ),
				'active' => ! empty( $type['active'] ) ? 1 : 0,
			];
		}
		
		return $clean;
	}
	
}
