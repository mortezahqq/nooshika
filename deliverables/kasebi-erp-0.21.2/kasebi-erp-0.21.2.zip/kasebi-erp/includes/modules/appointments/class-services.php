<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Appointments_Services {
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public function find( array $args = [] ): array {
		global $wpdb;
		$table  = KERP_Modules_Appointments_Installer::instance()->services_table();
		$args   = wp_parse_args( $args, [ 'search' => '', 'active' => '', 'page_number' => 1, 'per_page' => 50 ] );
		$where  = [ '1=1' ];
		$params = [];
		$search = sanitize_text_field( (string) $args['search'] );
		if ( $search !== '' ) {
			$where[]  = '(title LIKE %s OR description LIKE %s OR slug LIKE %s)';
			$like     = '%' . $wpdb->esc_like( $search ) . '%';
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
		}
		if ( $args['active'] !== '' ) {
			$where[]  = 'active = %d';
			$params[] = ! empty( $args['active'] ) ? 1 : 0;
		}
		$page_number  = max( 1, absint( $args['page_number'] ) );
		$per_page     = max( 1, min( 200, absint( $args['per_page'] ) ) );
		$offset       = ( $page_number - 1 ) * $per_page;
		$where_sql    = implode( ' AND ', $where );
		$count_sql    = "SELECT COUNT(*) FROM {$table} WHERE {$where_sql}";
		$query_sql    = "SELECT * FROM {$table} WHERE {$where_sql} ORDER BY order_index ASC, title ASC, id ASC LIMIT %d OFFSET %d";
		$count_query  = empty( $params ) ? $count_sql : $wpdb->prepare( $count_sql, $params );
		$query_params = array_merge( $params, [ $per_page, $offset ] );
		$total        = (int) $wpdb->get_var( $count_query );
		$items        = $wpdb->get_results( $wpdb->prepare( $query_sql, $query_params ), ARRAY_A );
		$items        = is_array( $items ) ? array_map( [ $this, 'hydrate' ], $items ) : [];
		
		return [
			'items'       => $items,
			'total'       => $total,
			'page_number' => $page_number,
			'per_page'    => $per_page,
			'total_pages' => max( 1, (int) ceil( $total / $per_page ) ),
		];
	}
	
	public function get( int $service_id ): array {
		global $wpdb;
		$service_id = absint( $service_id );
		if ( $service_id <= 0 ) {
			return [];
		}
		$table = KERP_Modules_Appointments_Installer::instance()->services_table();
		$row   = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d LIMIT 1", $service_id ), ARRAY_A );
		
		return is_array( $row ) ? $this->hydrate( $row ) : [];
	}
	
	public function get_options( bool $active_only = TRUE ): array {
		$result  = $this->find( [ 'active' => $active_only ? 1 : '', 'per_page' => 200 ] );
		$options = [];
		foreach ( $result['items'] as $service ) {
			$options[ (int) $service['id'] ] = (string) $service['title'];
		}
		
		return $options;
	}
	
	public function save( array $data, int $service_id = 0 ): int|WP_Error {
		global $wpdb;
		$table      = KERP_Modules_Appointments_Installer::instance()->services_table();
		$service_id = absint( $service_id );
		$title      = sanitize_text_field( (string) ( $data['title'] ?? '' ) );
		if ( $title === '' ) {
			return new WP_Error( 'kerp_appointments_service_title', sprintf( __( 'عنوان %s الزامی است.', 'kasebi-erp' ), KERP_Modules_Appointments_Settings::instance()
			                                                                                                                                               ->get_service_singular_label() ) );
		}
		$slug = sanitize_title( (string) ( $data['slug'] ?? '' ) );
		if ( $slug === '' ) {
			$slug = sanitize_title( $title );
		}
		$slug         = $this->unique_slug( $slug, $service_id );
		$deposit_type = sanitize_key( (string) ( $data['deposit_type'] ?? 'none' ) );
		if ( ! in_array( $deposit_type, [ 'none', 'fixed', 'percent', 'full' ], TRUE ) ) {
			$deposit_type = 'none';
		}
		$now = current_time( 'mysql' );
		$row = [
			'title'             => $title,
			'slug'              => $slug,
			'description'       => (string) ( $data['description'] ?? '' ),
			'duration_min'      => max( 5, min( 1440, absint( $data['duration_min'] ?? KERP_Modules_Appointments_Settings::instance()
			                                                                                                             ->get( 'default_duration', 30 ) ) ) ),
			'buffer_before_min' => max( 0, min( 720, absint( $data['buffer_before_min'] ?? 0 ) ) ),
			'buffer_after_min'  => max( 0, min( 720, absint( $data['buffer_after_min'] ?? 0 ) ) ),
			'price'             => $this->normalize_number( $data['price'] ?? 0 ),
			'deposit_type'      => $deposit_type,
			'deposit_value'     => $this->normalize_number( $data['deposit_value'] ?? 0 ),
			'capacity'          => max( 1, min( 1000, absint( $data['capacity'] ?? KERP_Modules_Appointments_Settings::instance()
			                                                                                                         ->get( 'default_capacity', 1 ) ) ) ),
			'icon'              => sanitize_text_field( (string) ( $data['icon'] ?? 'ni ni-calendar-booking' ) ),
			'color'             => sanitize_key( (string) ( $data['color'] ?? 'primary' ) ) ?: 'primary',
			'active'            => ! empty( $data['active'] ) ? 1 : 0,
			'public_booking'    => ! empty( $data['public_booking'] ) ? 1 : 0,
			'order_index'       => intval( $data['order'] ?? $data['order_index'] ?? 10 ),
			'updated_by'        => get_current_user_id(),
			'updated_at'        => $now,
			'metadata'          => wp_json_encode( is_array( $data['metadata'] ?? NULL ) ? $data['metadata'] : [], JSON_UNESCAPED_UNICODE ),
		];
		if ( $service_id > 0 ) {
			if ( empty( $this->get( $service_id ) ) ) {
				return new WP_Error( 'kerp_appointments_service_not_found', sprintf( __( '%s پیدا نشد.', 'kasebi-erp' ), KERP_Modules_Appointments_Settings::instance()
				                                                                                                                                           ->get_service_singular_label() ) );
			}
			$updated = $wpdb->update( $table, $row, [ 'id' => $service_id ] );
			if ( $updated === FALSE ) {
				return new WP_Error( 'kerp_appointments_service_update_failed', sprintf( __( 'ذخیره %s انجام نشد.', 'kasebi-erp' ), KERP_Modules_Appointments_Settings::instance()
				                                                                                                                                                      ->get_service_singular_label() ) );
			}
		} else {
			$row['created_by'] = get_current_user_id();
			$row['created_at'] = $now;
			$inserted          = $wpdb->insert( $table, $row );
			if ( $inserted === FALSE ) {
				return new WP_Error( 'kerp_appointments_service_insert_failed', sprintf( __( 'ایجاد %s انجام نشد.', 'kasebi-erp' ), KERP_Modules_Appointments_Settings::instance()
				                                                                                                                                                      ->get_service_singular_label() ) );
			}
			$service_id = (int) $wpdb->insert_id;
		}
		$this->sync_employees( $service_id, (array) ( $data['employee_ids'] ?? [] ) );
		$this->sync_terms( $service_id, (array) ( $data['term_ids'] ?? [] ) );
		do_action( 'kerp_appointments_service_saved', $service_id, $this->get( $service_id ) );
		
		return $service_id;
	}
	
	public function delete( int $service_id ): bool|WP_Error {
		global $wpdb;
		$service_id = absint( $service_id );
		if ( $service_id <= 0 || empty( $this->get( $service_id ) ) ) {
			return new WP_Error( 'kerp_appointments_service_not_found', sprintf( __( '%s پیدا نشد.', 'kasebi-erp' ), KERP_Modules_Appointments_Settings::instance()
			                                                                                                                                           ->get_service_singular_label() ) );
		}
		$count = (int) $wpdb->get_var( $wpdb->prepare(
			'SELECT COUNT(*) FROM ' . KERP_Modules_Appointments_Installer::instance()
			                                                             ->appointments_table() . ' WHERE service_id = %d',
			$service_id
		) );
		if ( $count > 0 ) {
			return new WP_Error( 'kerp_appointments_service_in_use', sprintf( __( 'این %1$s در %2$s استفاده شده است؛ به‌جای حذف آن را غیرفعال کنید.', 'kasebi-erp' ), KERP_Modules_Appointments_Settings::instance()
			                                                                                                                                                                                            ->get_service_singular_label(), KERP_Modules_Appointments_Settings::instance()
			                                                                                                                                                                                                                                                              ->get_appointment_plural_label() ) );
		}
		$wpdb->delete( KERP_Modules_Appointments_Installer::instance()
		                                                  ->service_employees_table(), [ 'service_id' => $service_id ] );
		$wpdb->delete( KERP_Modules_Appointments_Installer::instance()
		                                                  ->service_terms_table(), [ 'service_id' => $service_id ] );
		$wpdb->delete( KERP_Modules_Appointments_Installer::instance()
		                                                  ->schedules_table(), [ 'service_id' => $service_id ] );
		$wpdb->delete( KERP_Modules_Appointments_Installer::instance()
		                                                  ->exceptions_table(), [ 'service_id' => $service_id ] );
		$deleted = $wpdb->delete( KERP_Modules_Appointments_Installer::instance()
		                                                             ->services_table(), [ 'id' => $service_id ] );
		if ( $deleted === FALSE ) {
			return new WP_Error( 'kerp_appointments_service_delete_failed', sprintf( __( 'حذف %s انجام نشد.', 'kasebi-erp' ), KERP_Modules_Appointments_Settings::instance()
			                                                                                                                                                    ->get_service_singular_label() ) );
		}
		do_action( 'kerp_appointments_service_deleted', $service_id );
		
		return TRUE;
	}
	
	public function get_employee_ids( int $service_id ): array {
		global $wpdb;
		$table = KERP_Modules_Appointments_Installer::instance()->service_employees_table();
		$ids   = $wpdb->get_col( $wpdb->prepare( "SELECT employee_id FROM {$table} WHERE service_id = %d ORDER BY employee_id ASC", absint( $service_id ) ) );
		
		return array_values( array_unique( array_filter( array_map( 'absint', (array) $ids ) ) ) );
	}
	
	public function get_term_ids( int $service_id ): array {
		global $wpdb;
		$table = KERP_Modules_Appointments_Installer::instance()->service_terms_table();
		$ids   = $wpdb->get_col( $wpdb->prepare( "SELECT term_id FROM {$table} WHERE service_id = %d ORDER BY term_id ASC", absint( $service_id ) ) );
		
		return array_values( array_unique( array_filter( array_map( 'absint', (array) $ids ) ) ) );
	}
	
	public function calculate_payable_amount( array $service ): float {
		$price = (float) ( $service['price'] ?? 0 );
		$type  = sanitize_key( (string) ( $service['deposit_type'] ?? 'none' ) );
		$value = (float) ( $service['deposit_value'] ?? 0 );
		if ( $type === 'fixed' ) {
			return max( 0, min( $price, $value ) );
		}
		if ( $type === 'percent' ) {
			return max( 0, min( $price, $price * max( 0, min( 100, $value ) ) / 100 ) );
		}
		if ( $type === 'full' ) {
			return $price;
		}
		
		return 0.0;
	}
	
	private function hydrate( array $row ): array {
		$row['id']                = absint( $row['id'] ?? 0 );
		$row['duration_min']      = absint( $row['duration_min'] ?? 0 );
		$row['buffer_before_min'] = absint( $row['buffer_before_min'] ?? 0 );
		$row['buffer_after_min']  = absint( $row['buffer_after_min'] ?? 0 );
		$row['price']             = (float) ( $row['price'] ?? 0 );
		$row['deposit_value']     = (float) ( $row['deposit_value'] ?? 0 );
		$row['capacity']          = absint( $row['capacity'] ?? 1 );
		$row['active']            = ! empty( $row['active'] );
		$row['public_booking']    = ! empty( $row['public_booking'] );
		$row['order_index']       = intval( $row['order_index'] ?? 10 );
		$row['employee_ids']      = $this->get_employee_ids( $row['id'] );
		$row['term_ids']          = $this->get_term_ids( $row['id'] );
		$metadata                 = json_decode( (string) ( $row['metadata'] ?? '' ), TRUE );
		$row['metadata']          = is_array( $metadata ) ? $metadata : [];
		
		return $row;
	}
	
	private function sync_employees( int $service_id, array $employee_ids ): void {
		global $wpdb;
		$table = KERP_Modules_Appointments_Installer::instance()->service_employees_table();
		$wpdb->delete( $table, [ 'service_id' => $service_id ] );
		$employee_ids = array_values( array_unique( array_filter( array_map( 'absint', $employee_ids ) ) ) );
		foreach ( $employee_ids as $employee_id ) {
			$wpdb->insert( $table, [
				'service_id'  => $service_id,
				'employee_id' => $employee_id,
				'created_at'  => current_time( 'mysql' ),
			] );
		}
	}
	
	private function sync_terms( int $service_id, array $term_ids ): void {
		global $wpdb;
		$table = KERP_Modules_Appointments_Installer::instance()->service_terms_table();
		$wpdb->delete( $table, [ 'service_id' => $service_id ] );
		$term_ids = array_values( array_unique( array_filter( array_map( 'absint', $term_ids ) ) ) );
		foreach ( $term_ids as $term_id ) {
			$wpdb->insert( $table, [
				'service_id' => $service_id,
				'term_id'    => $term_id,
				'created_at' => current_time( 'mysql' ),
			] );
		}
	}
	
	private function unique_slug( string $slug, int $exclude_id = 0 ): string {
		global $wpdb;
		$table = KERP_Modules_Appointments_Installer::instance()->services_table();
		$base  = $slug !== '' ? $slug : 'service';
		$slug  = $base;
		$i     = 2;
		while ( TRUE ) {
			$sql    = "SELECT id FROM {$table} WHERE slug = %s";
			$params = [ $slug ];
			if ( $exclude_id > 0 ) {
				$sql      .= ' AND id <> %d';
				$params[] = $exclude_id;
			}
			$found = (int) $wpdb->get_var( $wpdb->prepare( $sql . ' LIMIT 1', $params ) );
			if ( $found <= 0 ) {
				return $slug;
			}
			$slug = $base . '-' . $i;
			$i ++;
		}
	}
	
	private function normalize_number( mixed $value, int $precision = 6 ): float {
		if ( $value === NULL || is_array( $value ) || is_object( $value ) ) {
			return 0.0;
		}
		$value = trim( (string) $value );
		if ( $value === '' ) {
			return 0.0;
		}
		if ( function_exists( 'nooshika_sanitize_numbers' ) ) {
			$value = nooshika_sanitize_numbers( $value );
		} elseif ( class_exists( 'KERP_Helpers_Format' ) && method_exists( 'KERP_Helpers_Format', 'sanitize_numbers' ) ) {
			$value = KERP_Helpers_Format::sanitize_numbers( $value );
		}
		$value = str_replace( '٫', '.', $value );
		$value = str_replace( [ ',', '٬', ' ', "\xc2\xa0" ], '', $value );
		$value = preg_replace( '/[^0-9.\-]/', '', $value );
		if ( ! is_string( $value ) || in_array( $value, [ '', '.', '-', '-.' ], TRUE ) ) {
			return 0.0;
		}
		$negative = str_starts_with( $value, '-' );
		$value    = ltrim( $value, '-' );
		$parts    = explode( '.', $value );
		$integer  = array_shift( $parts );
		$decimal  = implode( '', $parts );
		$number   = ( $integer !== '' ? $integer : '0' ) . ( $decimal !== '' ? '.' . $decimal : '' );
		if ( $negative ) {
			$number = '-' . $number;
		}
		
		return round( (float) $number, $precision );
	}
	
}
