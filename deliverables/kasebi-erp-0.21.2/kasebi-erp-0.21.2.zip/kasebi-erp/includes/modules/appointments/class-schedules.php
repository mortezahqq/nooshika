<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Appointments_Schedules {
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public function get_schedules( array $args = [] ): array {
		global $wpdb;
		$table  = KERP_Modules_Appointments_Installer::instance()->schedules_table();
		$args   = wp_parse_args( $args, [ 'employee_id' => 0, 'service_id' => '', 'weekday' => '', 'active' => '' ] );
		$where  = [ '1=1' ];
		$params = [];
		if ( absint( $args['employee_id'] ) > 0 ) {
			$where[]  = 'employee_id = %d';
			$params[] = absint( $args['employee_id'] );
		}
		if ( $args['service_id'] !== '' ) {
			$where[]  = 'service_id = %d';
			$params[] = absint( $args['service_id'] );
		}
		if ( $args['weekday'] !== '' ) {
			$where[]  = 'weekday = %d';
			$params[] = max( 0, min( 6, intval( $args['weekday'] ) ) );
		}
		if ( $args['active'] !== '' ) {
			$where[]  = 'active = %d';
			$params[] = ! empty( $args['active'] ) ? 1 : 0;
		}
		$sql  = "SELECT * FROM {$table} WHERE " . implode( ' AND ', $where ) . ' ORDER BY weekday ASC, start_time ASC, order_index ASC, id ASC';
		$rows = empty( $params ) ? $wpdb->get_results( $sql, ARRAY_A ) : $wpdb->get_results( $wpdb->prepare( $sql, $params ), ARRAY_A );
		
		return is_array( $rows ) ? array_map( [ $this, 'hydrate_schedule' ], $rows ) : [];
	}
	
	public function get_schedule( int $schedule_id ): array {
		global $wpdb;
		$table = KERP_Modules_Appointments_Installer::instance()->schedules_table();
		$row   = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d LIMIT 1", absint( $schedule_id ) ), ARRAY_A );
		
		return is_array( $row ) ? $this->hydrate_schedule( $row ) : [];
	}
	
	public function save_schedule( array $data, int $schedule_id = 0 ): int|WP_Error {
		global $wpdb;
		$table       = KERP_Modules_Appointments_Installer::instance()->schedules_table();
		$schedule_id = absint( $schedule_id );
		$employee_id = absint( $data['employee_id'] ?? 0 );
		$service_id  = absint( $data['service_id'] ?? 0 );
		$weekday     = max( 0, min( 6, intval( $data['weekday'] ?? 0 ) ) );
		$start_time  = $this->sanitize_time( (string) ( $data['start_time'] ?? '' ) );
		$end_time    = $this->sanitize_time( (string) ( $data['end_time'] ?? '' ) );
		if ( $employee_id <= 0 || ! get_userdata( $employee_id ) instanceof WP_User ) {
			return new WP_Error( 'kerp_appointments_schedule_employee', sprintf( __( '%s معتبر نیست.', 'kasebi-erp' ), KERP_Modules_Appointments_Settings::instance()->get_provider_singular_label() ) );
		}
		if ( $service_id > 0 && empty( KERP_Modules_Appointments_Services::instance()->get( $service_id ) ) ) {
			return new WP_Error( 'kerp_appointments_schedule_service', sprintf( __( '%s معتبر نیست.', 'kasebi-erp' ), KERP_Modules_Appointments_Settings::instance()->get_service_singular_label() ) );
		}
		if ( $start_time === '' || $end_time === '' || $start_time >= $end_time ) {
			return new WP_Error( 'kerp_appointments_schedule_time', __( 'بازه زمانی برنامه کاری معتبر نیست.', 'kasebi-erp' ) );
		}
		$now = current_time( 'mysql' );
		$row = [
			'employee_id'   => $employee_id,
			'service_id'    => $service_id,
			'weekday'       => $weekday,
			'start_time'    => $start_time,
			'end_time'      => $end_time,
			'slot_interval' => max( 0, min( 1440, absint( $data['slot_interval'] ?? 0 ) ) ),
			'capacity'      => max( 0, min( 1000, absint( $data['capacity'] ?? 0 ) ) ),
			'active'        => ! empty( $data['active'] ) ? 1 : 0,
			'order_index'   => intval( $data['order'] ?? $data['order_index'] ?? 10 ),
			'updated_by'    => get_current_user_id(),
			'updated_at'    => $now,
		];
		if ( $schedule_id > 0 ) {
			if ( empty( $this->get_schedule( $schedule_id ) ) ) {
				return new WP_Error( 'kerp_appointments_schedule_not_found', __( 'برنامه کاری پیدا نشد.', 'kasebi-erp' ) );
			}
			if ( $wpdb->update( $table, $row, [ 'id' => $schedule_id ] ) === FALSE ) {
				return new WP_Error( 'kerp_appointments_schedule_update_failed', __( 'ذخیره برنامه کاری انجام نشد.', 'kasebi-erp' ) );
			}
			
			return $schedule_id;
		}
		$row['created_by'] = get_current_user_id();
		$row['created_at'] = $now;
		if ( $wpdb->insert( $table, $row ) === FALSE ) {
			return new WP_Error( 'kerp_appointments_schedule_insert_failed', __( 'ایجاد برنامه کاری انجام نشد.', 'kasebi-erp' ) );
		}
		
		return (int) $wpdb->insert_id;
	}
	
	public function delete_schedule( int $schedule_id ): bool|WP_Error {
		global $wpdb;
		$schedule_id = absint( $schedule_id );
		if ( empty( $this->get_schedule( $schedule_id ) ) ) {
			return new WP_Error( 'kerp_appointments_schedule_not_found', __( 'برنامه کاری پیدا نشد.', 'kasebi-erp' ) );
		}
		$deleted = $wpdb->delete( KERP_Modules_Appointments_Installer::instance()
		                                                             ->schedules_table(), [ 'id' => $schedule_id ] );
		
		return $deleted !== FALSE;
	}
	
	public function get_exceptions( array $args = [] ): array {
		global $wpdb;
		$table  = KERP_Modules_Appointments_Installer::instance()->exceptions_table();
		$args   = wp_parse_args( $args, [
			'employee_id' => 0,
			'service_id'  => '',
			'from'        => '',
			'to'          => '',
			'active'      => '',
		] );
		$where  = [ '1=1' ];
		$params = [];
		if ( absint( $args['employee_id'] ) > 0 ) {
			$where[]  = 'employee_id = %d';
			$params[] = absint( $args['employee_id'] );
		}
		if ( $args['service_id'] !== '' ) {
			$where[]  = 'service_id = %d';
			$params[] = absint( $args['service_id'] );
		}
		if ( (string) $args['from'] !== '' ) {
			$where[]  = 'exception_date >= %s';
			$params[] = sanitize_text_field( (string) $args['from'] );
		}
		if ( (string) $args['to'] !== '' ) {
			$where[]  = 'exception_date <= %s';
			$params[] = sanitize_text_field( (string) $args['to'] );
		}
		if ( $args['active'] !== '' ) {
			$where[]  = 'active = %d';
			$params[] = ! empty( $args['active'] ) ? 1 : 0;
		}
		$sql  = "SELECT * FROM {$table} WHERE " . implode( ' AND ', $where ) . ' ORDER BY exception_date DESC, start_time ASC, id DESC';
		$rows = empty( $params ) ? $wpdb->get_results( $sql, ARRAY_A ) : $wpdb->get_results( $wpdb->prepare( $sql, $params ), ARRAY_A );
		
		return is_array( $rows ) ? array_map( [ $this, 'hydrate_exception' ], $rows ) : [];
	}
	
	public function get_exception( int $exception_id ): array {
		global $wpdb;
		$table = KERP_Modules_Appointments_Installer::instance()->exceptions_table();
		$row   = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d LIMIT 1", absint( $exception_id ) ), ARRAY_A );
		
		return is_array( $row ) ? $this->hydrate_exception( $row ) : [];
	}
	
	public function save_exception( array $data, int $exception_id = 0 ): int|WP_Error {
		global $wpdb;
		$table        = KERP_Modules_Appointments_Installer::instance()->exceptions_table();
		$exception_id = absint( $exception_id );
		$employee_id  = absint( $data['employee_id'] ?? 0 );
		$service_id   = absint( $data['service_id'] ?? 0 );
		$type         = sanitize_key( (string) ( $data['type'] ?? 'closed' ) );
		if ( ! in_array( $type, [ 'closed', 'override' ], TRUE ) ) {
			$type = 'closed';
		}
		$date = KERP_Modules_Appointments_Form::instance()
		                                      ->normalize_date( (string) ( $data['date'] ?? $data['exception_date'] ?? '' ) );
		if ( $employee_id <= 0 || ! get_userdata( $employee_id ) instanceof WP_User ) {
			return new WP_Error( 'kerp_appointments_exception_employee', sprintf( __( '%s معتبر نیست.', 'kasebi-erp' ), KERP_Modules_Appointments_Settings::instance()->get_provider_singular_label() ) );
		}
		if ( $service_id > 0 && empty( KERP_Modules_Appointments_Services::instance()->get( $service_id ) ) ) {
			return new WP_Error( 'kerp_appointments_exception_service', sprintf( __( '%s معتبر نیست.', 'kasebi-erp' ), KERP_Modules_Appointments_Settings::instance()->get_service_singular_label() ) );
		}
		if ( $date === '' ) {
			return new WP_Error( 'kerp_appointments_exception_date', __( 'تاریخ استثنا معتبر نیست.', 'kasebi-erp' ) );
		}
		$start_time = $this->sanitize_time( (string) ( $data['start_time'] ?? '' ) );
		$end_time   = $this->sanitize_time( (string) ( $data['end_time'] ?? '' ) );
		if ( $type === 'override' && ( $start_time === '' || $end_time === '' || $start_time >= $end_time ) ) {
			return new WP_Error( 'kerp_appointments_exception_time', __( 'برای تغییر برنامه، بازه زمانی معتبر وارد کنید.', 'kasebi-erp' ) );
		}
		if ( $type === 'closed' ) {
			$start_time = NULL;
			$end_time   = NULL;
		}
		$now = current_time( 'mysql' );
		$row = [
			'employee_id'    => $employee_id,
			'service_id'     => $service_id,
			'exception_date' => $date,
			'type'           => $type,
			'start_time'     => $start_time,
			'end_time'       => $end_time,
			'capacity'       => max( 0, min( 1000, absint( $data['capacity'] ?? 0 ) ) ),
			'note'           => sanitize_textarea_field( (string) ( $data['note'] ?? '' ) ),
			'active'         => ! empty( $data['active'] ) ? 1 : 0,
			'updated_by'     => get_current_user_id(),
			'updated_at'     => $now,
		];
		if ( $exception_id > 0 ) {
			if ( empty( $this->get_exception( $exception_id ) ) ) {
				return new WP_Error( 'kerp_appointments_exception_not_found', __( 'استثنا پیدا نشد.', 'kasebi-erp' ) );
			}
			if ( $wpdb->update( $table, $row, [ 'id' => $exception_id ] ) === FALSE ) {
				return new WP_Error( 'kerp_appointments_exception_update_failed', __( 'ذخیره استثنا انجام نشد.', 'kasebi-erp' ) );
			}
			
			return $exception_id;
		}
		$row['created_by'] = get_current_user_id();
		$row['created_at'] = $now;
		if ( $wpdb->insert( $table, $row ) === FALSE ) {
			return new WP_Error( 'kerp_appointments_exception_insert_failed', __( 'ایجاد استثنا انجام نشد.', 'kasebi-erp' ) );
		}
		
		return (int) $wpdb->insert_id;
	}
	
	public function delete_exception( int $exception_id ): bool|WP_Error {
		global $wpdb;
		$exception_id = absint( $exception_id );
		if ( empty( $this->get_exception( $exception_id ) ) ) {
			return new WP_Error( 'kerp_appointments_exception_not_found', __( 'استثنا پیدا نشد.', 'kasebi-erp' ) );
		}
		$deleted = $wpdb->delete( KERP_Modules_Appointments_Installer::instance()
		                                                             ->exceptions_table(), [ 'id' => $exception_id ] );
		
		return $deleted !== FALSE;
	}
	
	public function get_weekday_options(): array {
		return [
			0 => 'شنبه',
			1 => 'یکشنبه',
			2 => 'دوشنبه',
			3 => 'سه‌شنبه',
			4 => 'چهارشنبه',
			5 => 'پنجشنبه',
			6 => 'جمعه',
		];
	}
	
	public function weekday_from_date( string $date ): int {
		$timestamp = strtotime( $date . ' 12:00:00' );
		if ( $timestamp === FALSE ) {
			return 0;
		}
		$iso = (int) date( 'N', $timestamp );
		$map = [ 6 => 0, 7 => 1, 1 => 2, 2 => 3, 3 => 4, 4 => 5, 5 => 6 ];
		
		return $map[ $iso ] ?? 0;
	}
	
	private function hydrate_schedule( array $row ): array {
		foreach ( [ 'id', 'employee_id', 'service_id', 'weekday', 'slot_interval', 'capacity' ] as $key ) {
			$row[ $key ] = absint( $row[ $key ] ?? 0 );
		}
		$row['active']      = ! empty( $row['active'] );
		$row['order_index'] = intval( $row['order_index'] ?? 10 );
		
		return $row;
	}
	
	private function hydrate_exception( array $row ): array {
		foreach ( [ 'id', 'employee_id', 'service_id', 'capacity' ] as $key ) {
			$row[ $key ] = absint( $row[ $key ] ?? 0 );
		}
		$row['active'] = ! empty( $row['active'] );
		
		return $row;
	}
	
	private function sanitize_time( string $value ): string {
		$value = trim( $value );
		
		if ( function_exists( 'nooshika_sanitize_numbers' ) ) {
			$value = nooshika_sanitize_numbers( $value );
		}
		
		$value = strtoupper(
			preg_replace(
				'/\s+/',
				' ',
				$value
			)
		);
		
		if (
			preg_match(
				'/^(\d{1,2}):(\d{2})(?::(\d{2}))?\s*(AM|PM)?$/i',
				$value,
				$match
			) !== 1
		) {
			return '';
		}
		
		$hour   = (int) $match[1];
		$minute = (int) $match[2];
		$second = isset( $match[3] ) && $match[3] !== ''
			? (int) $match[3]
			: 0;
		
		$meridiem = isset( $match[4] )
			? strtoupper( $match[4] )
			: '';
		
		if (
			$minute > 59
			|| $second > 59
		) {
			return '';
		}
		
		if ( $meridiem !== '' ) {
			if ( $hour < 1 || $hour > 12 ) {
				return '';
			}
			
			if ( $meridiem === 'AM' ) {
				$hour = $hour === 12
					? 0
					: $hour;
			} else {
				$hour = $hour === 12
					? 12
					: $hour + 12;
			}
		} elseif ( $hour > 23 ) {
			return '';
		}
		
		return sprintf(
			'%02d:%02d:%02d',
			$hour,
			$minute,
			$second
		);
	}
	
}
