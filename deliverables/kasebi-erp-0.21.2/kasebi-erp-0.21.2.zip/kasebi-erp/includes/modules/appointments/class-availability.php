<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Appointments_Availability {
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public function get_slots(
		string $date,
		int $service_id,
		int $employee_id = 0,
		int $exclude_appointment_id = 0
	): array {
		$form_service = KERP_Modules_Appointments_Form::instance();
		$services     = KERP_Modules_Appointments_Services::instance();
		
		$date       = $form_service->normalize_date( $date );
		$service_id = absint( $service_id );
		$service    = $services->get( $service_id );
		
		if ( $date === '' || $service_id <= 0 || empty( $service ) || empty( $service['active'] ) ) {
			return [];
		}
		if ( ! KERP_Modules_Appointments_Settings::instance()->is_booking_date_active( $date ) ) {
			return [];
		}
		
		$assigned = array_values(
			array_filter(
				array_map(
					'absint',
					(array) $services->get_employee_ids( $service_id )
				)
			)
		);
		
		if ( $employee_id <= 0 ) {
			if ( empty( $assigned ) ) {
				$employee_ids = array_map(
					'absint',
					array_keys( $form_service->get_employee_options() )
				);
			} else {
				$employee_ids = $assigned;
			}
			
			$grouped_slots = [];
			
			foreach ( $employee_ids as $current_employee_id ) {
				if ( $current_employee_id <= 0 ) {
					continue;
				}
				
				$grouped_slots[ $current_employee_id ] = $this->get_slots(
					$date,
					$service_id,
					$current_employee_id,
					$exclude_appointment_id
				);
			}
			
			return $grouped_slots;
		}
		
		$employee_id = absint( $employee_id );
		
		if ( ! empty( $assigned ) && ! in_array( $employee_id, $assigned, TRUE ) ) {
			return [];
		}
		
		$ranges = $this->get_ranges(
			$date,
			$service_id,
			$employee_id
		);
		
		if ( empty( $ranges ) ) {
			return [];
		}
		
		$duration = max(
			5,
			absint( $service['duration_min'] ?? 30 )
		);
		
		$buffer_before = max(
			0,
			absint( $service['buffer_before_min'] ?? 0 )
		);
		
		$buffer_after = max(
			0,
			absint( $service['buffer_after_min'] ?? 0 )
		);
		
		$settings = KERP_Modules_Appointments_Settings::instance();
		
		$default_slot = max(
			5,
			absint( $settings->get( 'default_slot_interval', 30 ) )
		);
		
		$default_cap = max(
			1,
			absint(
				$service['capacity'] ?? $settings->get( 'default_capacity', 1 )
			)
		);
		
		$slots = [];
		
		foreach ( $ranges as $range ) {
			$interval = max(
				5,
				absint( $range['slot_interval'] ?? 0 ) ?: $default_slot
			);
			
			$capacity = max(
				1,
				absint( $range['capacity'] ?? 0 ) ?: $default_cap
			);
			
			$range_start = strtotime(
				$date . ' ' . (string) $range['start_time']
			);
			
			$range_end = strtotime(
				$date . ' ' . (string) $range['end_time']
			);
			
			if (
				$range_start === FALSE ||
				$range_end === FALSE ||
				$range_start >= $range_end
			) {
				continue;
			}
			
			for (
				$cursor = $range_start;
				$cursor < $range_end;
				$cursor += $interval * MINUTE_IN_SECONDS
			) {
				$actual_end = $cursor + $duration * MINUTE_IN_SECONDS;
				
				if ( $actual_end > $range_end ) {
					break;
				}
				
				$check_start = $cursor - $buffer_before * MINUTE_IN_SECONDS;
				$check_end   = $actual_end + $buffer_after * MINUTE_IN_SECONDS;
				
				$start_at = date(
					'Y-m-d H:i:s',
					$cursor
				);
				
				$end_at = date(
					'Y-m-d H:i:s',
					$actual_end
				);
				
				$busy = KERP_Modules_Appointments_Query::instance()->get_busy_quantity(
					$employee_id,
					date( 'Y-m-d H:i:s', $check_start ),
					date( 'Y-m-d H:i:s', $check_end ),
					$exclude_appointment_id
				);
				
				$remaining = max(
					0,
					$capacity - $busy
				);
				
				if ( $remaining <= 0 ) {
					continue;
				}
				
				$key = date(
					'H:i',
					$cursor
				);
				
				$slots[ $key ] = [
					'time'      => $key,
					'start_at'  => $start_at,
					'end_at'    => $end_at,
					'capacity'  => $capacity,
					'remaining' => $remaining,
				];
			}
		}
		
		ksort(
			$slots,
			SORT_STRING
		);
		
		return array_values( $slots );
	}
	
	public function is_available( string $start_at, int $service_id, int $employee_id, int $quantity = 1, int $exclude_appointment_id = 0 ): bool {
		$timestamp = strtotime( $start_at );
		if ( $timestamp === FALSE ) {
			return FALSE;
		}
		$date = date( 'Y-m-d', $timestamp, );
		$time = date( 'H:i', $timestamp );
		foreach ( $this->get_slots( $date, $service_id, $employee_id, $exclude_appointment_id ) as $slot ) {
			if ( (string) $slot['time'] === $time && absint( $slot['remaining'] ) >= max( 1, $quantity ) ) {
				return TRUE;
			}
		}
		
		return FALSE;
	}
	
	private function get_ranges( string $date, int $service_id, int $employee_id ): array {
		$exceptions = KERP_Modules_Appointments_Schedules::instance()->get_exceptions( [
			'employee_id' => $employee_id,
			'from'        => $date,
			'to'          => $date,
			'active'      => 1,
		] );
		$matching   = array_values( array_filter( $exceptions, function( array $item ) use ( $service_id ): bool {
			return absint( $item['service_id'] ?? 0 ) === 0 || absint( $item['service_id'] ?? 0 ) === $service_id;
		} ) );
		$override   = array_values( array_filter( $matching, fn( array $item ): bool => (string) ( $item['type'] ?? '' ) === 'override' ) );
		if ( ! empty( $override ) ) {
			$specific = array_values( array_filter( $override, fn( array $item ): bool => absint( $item['service_id'] ?? 0 ) === $service_id ) );
			$rows     = ! empty( $specific ) ? $specific : $override;
			
			return array_map( function( array $item ): array {
				return [
					'start_time'    => (string) ( $item['start_time'] ?? '' ),
					'end_time'      => (string) ( $item['end_time'] ?? '' ),
					'slot_interval' => 0,
					'capacity'      => absint( $item['capacity'] ?? 0 ),
				];
			}, $rows );
		}
		$closed = array_filter( $matching, fn( array $item ): bool => (string) ( $item['type'] ?? '' ) === 'closed' );
		if ( ! empty( $closed ) ) {
			return [];
		}
		$weekday            = KERP_Modules_Appointments_Schedules::instance()->weekday_from_date( $date );
		$schedules          = KERP_Modules_Appointments_Schedules::instance()->get_schedules( [
			'employee_id' => $employee_id,
			'weekday'     => $weekday,
			'active'      => 1,
		] );
		$matching_schedules = array_values( array_filter( $schedules, function( array $item ) use ( $service_id ): bool {
			return absint( $item['service_id'] ?? 0 ) === 0 || absint( $item['service_id'] ?? 0 ) === $service_id;
		} ) );
		$specific           = array_values( array_filter( $matching_schedules, fn( array $item ): bool => absint( $item['service_id'] ?? 0 ) === $service_id ) );
		
		return ! empty( $specific ) ? $specific : $matching_schedules;
	}
	
}
