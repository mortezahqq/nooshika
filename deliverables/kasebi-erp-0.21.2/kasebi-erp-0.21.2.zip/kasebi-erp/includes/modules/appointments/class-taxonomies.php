<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Appointments_Taxonomies {
	private static ?self $instance = NULL;
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		return self::$instance;
	}
	private function __construct() {}
	private function __clone() {}
	public function __wakeup(): void { throw new LogicException( 'Cannot unserialize a singleton.' ); }

	public function get_taxonomies( bool $active_only = FALSE ): array {
		global $wpdb;
		$table = KERP_Modules_Appointments_Installer::instance()->taxonomies_table();
		$sql   = "SELECT * FROM {$table}";
		if ( $active_only ) {
			$sql .= ' WHERE active = 1';
		}
		$sql .= ' ORDER BY order_index ASC, singular_label ASC, id ASC';
		$rows = $wpdb->get_results( $sql, ARRAY_A );
		if ( ! is_array( $rows ) ) {
			return [];
		}
		foreach ( $rows as &$row ) {
			$row['id']          = absint( $row['id'] ?? 0 );
			$row['active']      = ! empty( $row['active'] );
			$row['order_index'] = intval( $row['order_index'] ?? 10 );
			$row['terms']       = $this->get_terms( $row['id'], $active_only );
		}
		unset( $row );
		return $rows;
	}

	public function get_taxonomy( int $taxonomy_id ): array {
		global $wpdb;
		$table = KERP_Modules_Appointments_Installer::instance()->taxonomies_table();
		$row   = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d LIMIT 1", absint( $taxonomy_id ) ), ARRAY_A );
		if ( ! is_array( $row ) ) {
			return [];
		}
		$row['id']          = absint( $row['id'] ?? 0 );
		$row['active']      = ! empty( $row['active'] );
		$row['order_index'] = intval( $row['order_index'] ?? 10 );
		return $row;
	}

	public function get_terms( int $taxonomy_id = 0, bool $active_only = FALSE ): array {
		global $wpdb;
		$table  = KERP_Modules_Appointments_Installer::instance()->terms_table();
		$where  = [ '1=1' ];
		$params = [];
		if ( $taxonomy_id > 0 ) {
			$where[]  = 'taxonomy_id = %d';
			$params[] = absint( $taxonomy_id );
		}
		if ( $active_only ) {
			$where[] = 'active = 1';
		}
		$sql = "SELECT * FROM {$table} WHERE " . implode( ' AND ', $where ) . ' ORDER BY order_index ASC, name ASC, id ASC';
		$rows = empty( $params ) ? $wpdb->get_results( $sql, ARRAY_A ) : $wpdb->get_results( $wpdb->prepare( $sql, $params ), ARRAY_A );
		if ( ! is_array( $rows ) ) {
			return [];
		}
		foreach ( $rows as &$row ) {
			$row['id']          = absint( $row['id'] ?? 0 );
			$row['taxonomy_id'] = absint( $row['taxonomy_id'] ?? 0 );
			$row['parent_id']   = absint( $row['parent_id'] ?? 0 );
			$row['active']      = ! empty( $row['active'] );
			$row['order_index'] = intval( $row['order_index'] ?? 10 );
		}
		unset( $row );
		return $rows;
	}

	public function get_term( int $term_id ): array {
		global $wpdb;
		$table = KERP_Modules_Appointments_Installer::instance()->terms_table();
		$row   = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d LIMIT 1", absint( $term_id ) ), ARRAY_A );
		if ( ! is_array( $row ) ) {
			return [];
		}
		$row['id']          = absint( $row['id'] ?? 0 );
		$row['taxonomy_id'] = absint( $row['taxonomy_id'] ?? 0 );
		$row['parent_id']   = absint( $row['parent_id'] ?? 0 );
		$row['active']      = ! empty( $row['active'] );
		$row['order_index'] = intval( $row['order_index'] ?? 10 );
		return $row;
	}

	public function save_taxonomy( array $data, int $taxonomy_id = 0 ): int|WP_Error {
		global $wpdb;
		$table          = KERP_Modules_Appointments_Installer::instance()->taxonomies_table();
		$taxonomy_id    = absint( $taxonomy_id );
		$singular_label = sanitize_text_field( (string) ( $data['singular_label'] ?? '' ) );
		$plural_label   = sanitize_text_field( (string) ( $data['plural_label'] ?? '' ) );
		$tax_key        = sanitize_key( (string) ( $data['key'] ?? $data['tax_key'] ?? '' ) );
		if ( $singular_label === '' || $plural_label === '' ) {
			return new WP_Error( 'kerp_appointments_taxonomy_labels', __( 'عنوان مفرد و جمع دسته‌بندی الزامی است.', 'kasebi-erp' ) );
		}
		if ( $tax_key === '' ) {
			$tax_key = sanitize_key( sanitize_title( $singular_label ) );
		}
		if ( $tax_key === '' ) {
			$tax_key = 'taxonomy_' . wp_generate_password( 6, FALSE, FALSE );
		}
		$duplicate = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT id FROM {$table} WHERE tax_key = %s AND id <> %d LIMIT 1",
			$tax_key,
			$taxonomy_id
		) );
		if ( $duplicate > 0 ) {
			return new WP_Error( 'kerp_appointments_taxonomy_duplicate', __( 'کلید این دسته‌بندی قبلاً استفاده شده است.', 'kasebi-erp' ) );
		}
		$now = current_time( 'mysql' );
		$row = [
			'tax_key'        => $tax_key,
			'singular_label' => $singular_label,
			'plural_label'   => $plural_label,
			'description'    => sanitize_textarea_field( (string) ( $data['description'] ?? '' ) ),
			'icon'           => sanitize_text_field( (string) ( $data['icon'] ?? 'ni ni-folder-list' ) ),
			'color'          => sanitize_key( (string) ( $data['color'] ?? 'primary' ) ) ?: 'primary',
			'active'         => ! empty( $data['active'] ) ? 1 : 0,
			'order_index'    => intval( $data['order'] ?? $data['order_index'] ?? 10 ),
			'updated_by'     => get_current_user_id(),
			'updated_at'     => $now,
		];
		if ( $taxonomy_id > 0 ) {
			if ( empty( $this->get_taxonomy( $taxonomy_id ) ) ) {
				return new WP_Error( 'kerp_appointments_taxonomy_not_found', __( 'دسته‌بندی پیدا نشد.', 'kasebi-erp' ) );
			}
			if ( $wpdb->update( $table, $row, [ 'id' => $taxonomy_id ] ) === FALSE ) {
				return new WP_Error( 'kerp_appointments_taxonomy_update_failed', __( 'ذخیره دسته‌بندی انجام نشد.', 'kasebi-erp' ) );
			}
			return $taxonomy_id;
		}
		$row['created_by'] = get_current_user_id();
		$row['created_at'] = $now;
		if ( $wpdb->insert( $table, $row ) === FALSE ) {
			return new WP_Error( 'kerp_appointments_taxonomy_insert_failed', __( 'ایجاد دسته‌بندی انجام نشد.', 'kasebi-erp' ) );
		}
		return (int) $wpdb->insert_id;
	}

	public function delete_taxonomy( int $taxonomy_id ): bool|WP_Error {
		global $wpdb;
		$taxonomy_id = absint( $taxonomy_id );
		if ( empty( $this->get_taxonomy( $taxonomy_id ) ) ) {
			return new WP_Error( 'kerp_appointments_taxonomy_not_found', __( 'دسته‌بندی پیدا نشد.', 'kasebi-erp' ) );
		}
		$term_ids = array_column( $this->get_terms( $taxonomy_id ), 'id' );
		if ( ! empty( $term_ids ) ) {
			$placeholders = implode( ',', array_fill( 0, count( $term_ids ), '%d' ) );
			$service_terms = KERP_Modules_Appointments_Installer::instance()->service_terms_table();
			$wpdb->query( $wpdb->prepare( "DELETE FROM {$service_terms} WHERE term_id IN ({$placeholders})", $term_ids ) );
		}
		$wpdb->delete( KERP_Modules_Appointments_Installer::instance()->terms_table(), [ 'taxonomy_id' => $taxonomy_id ] );
		$deleted = $wpdb->delete( KERP_Modules_Appointments_Installer::instance()->taxonomies_table(), [ 'id' => $taxonomy_id ] );
		return $deleted !== FALSE;
	}

	public function save_term( array $data, int $term_id = 0 ): int|WP_Error {
		global $wpdb;
		$table       = KERP_Modules_Appointments_Installer::instance()->terms_table();
		$term_id     = absint( $term_id );
		$taxonomy_id = absint( $data['taxonomy_id'] ?? 0 );
		$name        = sanitize_text_field( (string) ( $data['name'] ?? '' ) );
		if ( $taxonomy_id <= 0 || empty( $this->get_taxonomy( $taxonomy_id ) ) ) {
			return new WP_Error( 'kerp_appointments_term_taxonomy', __( 'دسته‌بندی معتبر نیست.', 'kasebi-erp' ) );
		}
		if ( $name === '' ) {
			return new WP_Error( 'kerp_appointments_term_name', __( 'عنوان ترم الزامی است.', 'kasebi-erp' ) );
		}
		$slug = sanitize_title( (string) ( $data['slug'] ?? '' ) );
		if ( $slug === '' ) {
			$slug = sanitize_title( $name );
		}
		$duplicate = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT id FROM {$table} WHERE taxonomy_id = %d AND slug = %s AND id <> %d LIMIT 1",
			$taxonomy_id,
			$slug,
			$term_id
		) );
		if ( $duplicate > 0 ) {
			return new WP_Error( 'kerp_appointments_term_duplicate', __( 'این ترم قبلاً در دسته‌بندی ثبت شده است.', 'kasebi-erp' ) );
		}
		$parent_id = absint( $data['parent_id'] ?? 0 );
		if ( $parent_id === $term_id ) {
			$parent_id = 0;
		}
		if ( $parent_id > 0 ) {
			$parent = $this->get_term( $parent_id );
			if ( empty( $parent ) || absint( $parent['taxonomy_id'] ?? 0 ) !== $taxonomy_id ) {
				return new WP_Error( 'kerp_appointments_term_parent', __( 'ترم والد باید از همین دسته‌بندی باشد.', 'kasebi-erp' ) );
			}
		}
		$now = current_time( 'mysql' );
		$row = [
			'taxonomy_id' => $taxonomy_id,
			'parent_id'   => $parent_id,
			'name'        => $name,
			'slug'        => $slug,
			'description' => sanitize_textarea_field( (string) ( $data['description'] ?? '' ) ),
			'icon'        => sanitize_text_field( (string) ( $data['icon'] ?? 'ni ni-tag' ) ),
			'color'       => sanitize_key( (string) ( $data['color'] ?? 'primary' ) ) ?: 'primary',
			'active'      => ! empty( $data['active'] ) ? 1 : 0,
			'order_index' => intval( $data['order'] ?? $data['order_index'] ?? 10 ),
			'updated_at'  => $now,
		];
		if ( $term_id > 0 ) {
			if ( empty( $this->get_term( $term_id ) ) ) {
				return new WP_Error( 'kerp_appointments_term_not_found', __( 'ترم پیدا نشد.', 'kasebi-erp' ) );
			}
			if ( $wpdb->update( $table, $row, [ 'id' => $term_id ] ) === FALSE ) {
				return new WP_Error( 'kerp_appointments_term_update_failed', __( 'ذخیره ترم انجام نشد.', 'kasebi-erp' ) );
			}
			return $term_id;
		}
		$row['created_at'] = $now;
		if ( $wpdb->insert( $table, $row ) === FALSE ) {
			return new WP_Error( 'kerp_appointments_term_insert_failed', __( 'ایجاد ترم انجام نشد.', 'kasebi-erp' ) );
		}
		return (int) $wpdb->insert_id;
	}

	public function delete_term( int $term_id ): bool|WP_Error {
		global $wpdb;
		$term_id = absint( $term_id );
		if ( empty( $this->get_term( $term_id ) ) ) {
			return new WP_Error( 'kerp_appointments_term_not_found', __( 'ترم پیدا نشد.', 'kasebi-erp' ) );
		}
		$wpdb->delete( KERP_Modules_Appointments_Installer::instance()->service_terms_table(), [ 'term_id' => $term_id ] );
		$wpdb->update( KERP_Modules_Appointments_Installer::instance()->terms_table(), [ 'parent_id' => 0 ], [ 'parent_id' => $term_id ] );
		$deleted = $wpdb->delete( KERP_Modules_Appointments_Installer::instance()->terms_table(), [ 'id' => $term_id ] );
		return $deleted !== FALSE;
	}

	public function get_grouped_terms( bool $active_only = TRUE ): array {
		$groups = [];
		foreach ( $this->get_taxonomies( $active_only ) as $taxonomy ) {
			$groups[ (int) $taxonomy['id'] ] = [
				'taxonomy' => $taxonomy,
				'terms'    => $this->get_terms( (int) $taxonomy['id'], $active_only ),
			];
		}
		return $groups;
	}
}
