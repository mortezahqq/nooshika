<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Appointments_List_Table {
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public function get_filters( array $values = [] ): array {
		$date     = isset( $values['date'] ) && is_array( $values['date'] ) ? $values['date'] : [];
		$settings = KERP_Modules_Appointments_Settings::instance();
		$filters  = [
			'status'      => [
				'key'         => 'status',
				'name'        => 'status',
				'label'       => __( 'وضعیت', 'kasebi-erp' ),
				'type'        => 'select',
				'options'     => $settings->get_status_options( FALSE ),
				'placeholder' => __( 'همه وضعیت‌ها', 'kasebi-erp' ),
				'value'       => sanitize_key( (string) ( $values['status'] ?? '' ) ),
				'order'       => 10,
			],
			'service_id'  => [
				'key'         => 'service_id',
				'name'        => 'service_id',
				'label'       => $settings->get_service_singular_label(),
				'type'        => 'select',
				'options'     => KERP_Modules_Appointments_Services::instance()->get_options( FALSE ),
				'placeholder' => sprintf( __( 'همه %s', 'kasebi-erp' ), $settings->get_service_plural_label() ),
				'value'       => absint( $values['service_id'] ?? 0 ),
				'order'       => 20,
			],
			'employee_id' => [
				'key'         => 'employee_id',
				'name'        => 'employee_id',
				'label'       => $settings->get_provider_singular_label(),
				'type'        => 'select',
				'options'     => KERP_Modules_Appointments_Form::instance()->get_employee_options(),
				'placeholder' => sprintf( __( 'همه %s', 'kasebi-erp' ), $settings->get_provider_plural_label() ),
				'value'       => absint( $values['employee_id'] ?? 0 ),
				'order'       => 30,
			],
			'source'      => [
				'key'         => 'source',
				'name'        => 'source',
				'label'       => __( 'منبع ثبت', 'kasebi-erp' ),
				'type'        => 'select',
				'options'     => [
					'admin'    => __( 'پنل مدیریت', 'kasebi-erp' ),
					'employee' => __( 'کارمند', 'kasebi-erp' ),
					'public'   => __( 'رزرو عمومی', 'kasebi-erp' ),
					'api'      => __( 'API', 'kasebi-erp' ),
				],
				'placeholder' => __( 'همه منابع', 'kasebi-erp' ),
				'value'       => sanitize_key( (string) ( $values['source'] ?? '' ) ),
				'order'       => 40,
			],
			'date'        => [
				'key'   => 'date',
				'name'  => 'date',
				'label' => sprintf( __( 'تاریخ %s', 'kasebi-erp' ), $settings->get_appointment_singular_label() ),
				'type'  => 'date-range',
				'col'   => 12,
				'value' => [
					'from' => sanitize_text_field( (string) ( $date['from'] ?? '' ) ),
					'to'   => sanitize_text_field( (string) ( $date['to'] ?? '' ) ),
				],
				'order' => 50,
			],
		];
		foreach ( KERP_Modules_Appointments_Public_Fields::instance()->get_filterable_fields() as $key => $field ) {
			$filter_key = 'public_field_' . $key;
			$options = [];
			foreach ( (array) $field['options'] as $option_key => $option_label ) {
				$options[ 'choice_' . $option_key ] = $option_label;
			}
			$filters[ $filter_key ] = [
				'key' => $filter_key,
				'name' => $filter_key,
				'label' => (string) ( $field['label'] ?? $key ),
				'type' => 'select',
				'options' => $options,
				'placeholder' => __( 'همه گزینه‌ها', 'kasebi-erp' ),
				'value' => is_scalar( $values[ $filter_key ] ?? '' ) ? (string) ( $values[ $filter_key ] ?? '' ) : '',
				'order' => 60 + (int) ( $field['order'] ?? 100 ),
			];
		}
		$filters = apply_filters( 'kerp_appointments_list_filters', $filters, $values );
		uasort( $filters, [ $this, 'sort_by_order' ] );
		
		return $filters;
	}
	
	private function sort_by_order( array $first, array $second ): int {
		return (int) ( $first['order'] ?? 100 ) <=> (int) ( $second['order'] ?? 100 );
	}
	
}
