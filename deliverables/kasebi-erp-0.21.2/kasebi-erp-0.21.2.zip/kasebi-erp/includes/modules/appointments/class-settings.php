<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Appointments_Settings {
	
	private const OPTION_KEY = 'kerp_appointments_settings';
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public function defaults(): array {
		return [
			'appointment_singular_label'  => 'نوبت',
			'appointment_plural_label'    => 'نوبت‌ها',
			'service_singular_label'      => 'خدمت',
			'service_plural_label'        => 'خدمات',
			'provider_singular_label'     => 'کارشناس',
			'provider_plural_label'       => 'کارشناسان',
			'default_duration'            => 30,
			'default_slot_interval'       => 30,
			'default_capacity'            => 1,
			'default_per_page'            => 20,
			'default_admin_status'        => 'confirmed',
			'hold_minutes'                => 15,
			'booking_start_date'          => '',
			'booking_end_date'            => '',
			'booking_terms_checkbox_text' => 'شرایط رزرو و لغو نوبت را خوانده‌ام و می‌پذیرم.',
			'booking_cancellation_terms'  => '',
			'statuses'                    => $this->default_statuses(),
			'location_types'              => $this->default_location_types(),
		];
	}
	
	public function all(): array {
		$stored                 = get_option( self::OPTION_KEY, [] );
		$stored                 = is_array( $stored ) ? $stored : [];
		$data                   = wp_parse_args( $stored, $this->defaults() );
		$data['statuses']       = isset( $stored['statuses'] ) && is_array( $stored['statuses'] )
			? $stored['statuses']
			: $this->default_statuses();
		$data['location_types'] = isset( $stored['location_types'] ) && is_array( $stored['location_types'] )
			? $stored['location_types']
			: $this->default_location_types();
		
		return $data;
	}
	
	public function get( string $key, mixed $default = NULL ): mixed {
		$data = $this->all();
		
		return array_key_exists( $key, $data ) ? $data[ $key ] : $default;
	}
	
	public function update( array $values ): bool|WP_Error {
		$current   = $this->all();
		foreach ( [ 'booking_start_date', 'booking_end_date' ] as $key ) {
			if ( ! array_key_exists( $key, $values ) ) {
				continue;
			}
			if ( ! is_scalar( $values[ $key ] ) ) {
				return new WP_Error( 'kerp_appointments_invalid_booking_date', __( 'تاریخ بازه فعال بودن نوبت‌دهی معتبر نیست.', 'kasebi-erp' ) );
			}
			$raw = trim( (string) $values[ $key ] );
			$date = $raw === '' ? '' : KERP_Helpers_Date::jalali_to_gregorian( str_replace( '/', '-', KERP_Helpers_Format::sanitize_numbers( $raw ) ) );
			if ( $raw !== '' && $date === '' ) {
				return new WP_Error( 'kerp_appointments_invalid_booking_date', __( 'تاریخ شروع و پایان را به‌صورت شمسی و معتبر وارد کنید.', 'kasebi-erp' ) );
			}
			$current[ $key ] = $date;
		}
		if ( $current['booking_start_date'] !== '' && $current['booking_end_date'] !== '' && $current['booking_start_date'] > $current['booking_end_date'] ) {
			return new WP_Error( 'kerp_appointments_invalid_booking_range', __( 'تاریخ پایان نوبت‌دهی نباید قبل از تاریخ شروع باشد.', 'kasebi-erp' ) );
		}
		$text_keys = [
			'appointment_singular_label',
			'appointment_plural_label',
			'service_singular_label',
			'service_plural_label',
			'provider_singular_label',
			'provider_plural_label',
			'booking_terms_checkbox_text',
		];
		foreach ( $text_keys as $key ) {
			if ( array_key_exists( $key, $values ) ) {
				$value = sanitize_text_field( (string) $values[ $key ] );
				if ( $value !== '' ) {
					$current[ $key ] = $value;
				}
			}
		}
		$number_limits = [
			'default_duration'      => [ 5, 1440 ],
			'default_slot_interval' => [ 5, 1440 ],
			'default_capacity'      => [ 1, 1000 ],
			'default_per_page'      => [ 5, 200 ],
			'hold_minutes'          => [ 1, 1440 ],
		];
		foreach ( $number_limits as $key => $limits ) {
			if ( ! array_key_exists( $key, $values ) ) {
				continue;
			}
			$current[ $key ] = max( $limits[0], min( $limits[1], absint( $values[ $key ] ) ) );
		}
		if ( array_key_exists( 'default_admin_status', $values ) ) {
			$status = sanitize_key( (string) $values['default_admin_status'] );
			if ( isset( $current['statuses'][ $status ] ) ) {
				$current['default_admin_status'] = $status;
			}
		}
		if ( array_key_exists( 'booking_cancellation_terms', $values ) ) {
			$current['booking_cancellation_terms'] = wp_kses_post( (string) $values['booking_cancellation_terms'] );
		}
		update_option( self::OPTION_KEY, $current, FALSE );
		return TRUE;
	}

	public function is_booking_date_active( string $date ): bool {
		$date = KERP_Modules_Appointments_Form::instance()->normalize_date( $date );
		$start = (string) $this->get( 'booking_start_date', '' );
		$end = (string) $this->get( 'booking_end_date', '' );
		return $date !== '' && ( $start === '' || $date >= $start ) && ( $end === '' || $date <= $end );
	}
	
	public function get_statuses( bool $active_only = FALSE ): array {
		$statuses = $this->get( 'statuses', [] );
		$statuses = is_array( $statuses ) ? $statuses : [];
		if ( $active_only ) {
			$statuses = array_filter( $statuses, fn( array $status ): bool => ! empty( $status['active'] ) );
		}
		uasort( $statuses, [ $this, 'sort_by_order' ] );
		
		return $statuses;
	}
	
	public function get_status( string $key ): array {
		$key      = sanitize_key( $key );
		$statuses = $this->get_statuses();
		
		return isset( $statuses[ $key ] ) && is_array( $statuses[ $key ] ) ? $statuses[ $key ] : [];
	}
	
	public function get_status_options( bool $active_only = TRUE ): array {
		$options = [];
		foreach ( $this->get_statuses( $active_only ) as $key => $status ) {
			$options[ $key ] = (string) ( $status['label'] ?? $key );
		}
		
		return $options;
	}
	
	public function save_status( array $status, string $original_key = '' ): string|WP_Error {
		$statuses     = $this->get_statuses();
		$original_key = sanitize_key( $original_key );
		$key          = sanitize_key( (string) ( $status['key'] ?? $original_key ) );
		$label        = sanitize_text_field( (string) ( $status['label'] ?? '' ) );
		if ( $key === '' || $label === '' ) {
			return new WP_Error( 'kerp_appointments_invalid_status', __( 'کلید و عنوان وضعیت الزامی است.', 'kasebi-erp' ) );
		}
		if ( $original_key !== '' && $original_key !== $key && isset( $statuses[ $key ] ) ) {
			return new WP_Error( 'kerp_appointments_duplicate_status', __( 'این کلید وضعیت قبلاً استفاده شده است.', 'kasebi-erp' ) );
		}
		$allowed_next = isset( $status['allowed_next'] ) && is_array( $status['allowed_next'] )
			? array_values( array_unique( array_filter( array_map( 'sanitize_key', $status['allowed_next'] ) ) ) )
			: [];
		$item         = [
			'key'          => $key,
			'label'        => $label,
			'icon'         => sanitize_text_field( (string) ( $status['icon'] ?? 'ni ni-clock' ) ),
			'color'        => sanitize_key( (string) ( $status['color'] ?? 'primary' ) ) ?: 'primary',
			'active'       => ! empty( $status['active'] ),
			'order'        => intval( $status['order'] ?? 10 ),
			'allowed_next' => $allowed_next,
			'system'       => ! empty( $statuses[ $original_key ]['system'] ) || ! empty( $status['system'] ),
		];
		if ( $original_key !== '' && $original_key !== $key ) {
			unset( $statuses[ $original_key ] );
		}
		$statuses[ $key ]    = $item;
		$current             = $this->all();
		$current['statuses'] = $statuses;
		update_option( self::OPTION_KEY, $current, FALSE );
		
		return $key;
	}
	
	public function delete_status( string $key, string $replacement_key = '' ): bool|WP_Error {
		$key             = sanitize_key( $key );
		$replacement_key = sanitize_key( $replacement_key );
		$statuses        = $this->get_statuses();
		if ( ! isset( $statuses[ $key ] ) ) {
			return new WP_Error( 'kerp_appointments_status_not_found', __( 'وضعیت پیدا نشد.', 'kasebi-erp' ) );
		}
		if ( ! empty( $statuses[ $key ]['system'] ) ) {
			return new WP_Error( 'kerp_appointments_system_status', __( 'وضعیت‌های سیستمی قابل حذف نیستند.', 'kasebi-erp' ) );
		}
		$count = KERP_Modules_Appointments_Query::instance()->count_by_status( $key );
		if ( $count > 0 ) {
			if ( $replacement_key === '' || ! isset( $statuses[ $replacement_key ] ) || $replacement_key === $key ) {
				return new WP_Error( 'kerp_appointments_status_in_use', sprintf( __( 'این وضعیت در %s استفاده شده است؛ وضعیت جایگزین انتخاب کنید.', 'kasebi-erp' ), $this->get_appointment_plural_label() ) );
			}
			KERP_Modules_Appointments_Query::instance()->replace_status( $key, $replacement_key );
		}
		unset( $statuses[ $key ] );
		$current             = $this->all();
		$current['statuses'] = $statuses;
		if ( (string) $current['default_admin_status'] === $key ) {
			$current['default_admin_status'] = $replacement_key !== '' ? $replacement_key : 'confirmed';
		}
		update_option( self::OPTION_KEY, $current, FALSE );
		
		return TRUE;
	}
	
	public function can_transition( string $from, string $to ): bool {
		$from = sanitize_key( $from );
		$to   = sanitize_key( $to );
		
		if ( $from === $to ) {
			return TRUE;
		}
		
		$status = $this->get_status( $from );
		
		if ( empty( $status ) ) {
			return TRUE;
		}
		
		$allowed = isset( $status['allowed_next'] ) && is_array( $status['allowed_next'] )
			? $status['allowed_next']
			: [];
		
		return in_array(
			$to,
			$allowed,
			TRUE
		);
	}
	
	public function get_appointment_singular_label(): string {
		return (string) $this->get( 'appointment_singular_label', 'نوبت' );
	}
	
	public function get_appointment_plural_label(): string {
		return (string) $this->get( 'appointment_plural_label', 'نوبت‌ها' );
	}
	
	public function get_service_singular_label(): string {
		return (string) $this->get( 'service_singular_label', 'خدمت' );
	}
	
	public function get_service_plural_label(): string {
		return (string) $this->get( 'service_plural_label', 'خدمات' );
	}
	
	public function get_provider_singular_label(): string {
		return (string) $this->get( 'provider_singular_label', 'کارشناس' );
	}
	
	public function get_provider_plural_label(): string {
		return (string) $this->get( 'provider_plural_label', 'کارشناسان' );
	}
	
	public function get_booking_terms_checkbox_text(): string {
		return (string) $this->get( 'booking_terms_checkbox_text', 'شرایط رزرو و لغو نوبت را خوانده‌ام و می‌پذیرم.' );
	}
	
	public function get_booking_cancellation_terms(): string {
		return (string) $this->get( 'booking_cancellation_terms', '' );
	}
	
	private function sort_by_order( array $first, array $second ): int {
		return (int) ( $first['order'] ?? 100 ) <=> (int) ( $second['order'] ?? 100 );
	}
	
	private function default_statuses(): array {
		return [
			'held'            => [
				'key'          => 'held',
				'label'        => 'رزرو موقت',
				'icon'         => 'ni ni-clock',
				'color'        => 'warning',
				'active'       => TRUE,
				'order'        => 5,
				'allowed_next' => [ 'pending_payment', 'confirmed', 'expired', 'cancelled' ],
				'system'       => TRUE,
			],
			'pending_payment' => [
				'key'          => 'pending_payment',
				'label'        => 'در انتظار پرداخت',
				'icon'         => 'ni ni-wallet',
				'color'        => 'warning',
				'active'       => TRUE,
				'order'        => 10,
				'allowed_next' => [ 'confirmed', 'expired', 'cancelled' ],
				'system'       => TRUE,
			],
			'pending'         => [
				'key'          => 'pending',
				'label'        => 'در انتظار تایید',
				'icon'         => 'ni ni-clock',
				'color'        => 'info',
				'active'       => TRUE,
				'order'        => 20,
				'allowed_next' => [ 'confirmed', 'cancelled' ],
				'system'       => FALSE,
			],
			'confirmed'       => [
				'key'          => 'confirmed',
				'label'        => 'تایید شده',
				'icon'         => 'ni ni-check-circle',
				'color'        => 'success',
				'active'       => TRUE,
				'order'        => 30,
				'allowed_next' => [ 'completed', 'cancelled', 'no_show' ],
				'system'       => FALSE,
			],
			'completed'       => [
				'key'          => 'completed',
				'label'        => 'انجام شده',
				'icon'         => 'ni ni-check',
				'color'        => 'success',
				'active'       => TRUE,
				'order'        => 40,
				'allowed_next' => [],
				'system'       => FALSE,
			],
			'cancelled'       => [
				'key'          => 'cancelled',
				'label'        => 'لغو شده',
				'icon'         => 'ni ni-cross-circle',
				'color'        => 'danger',
				'active'       => TRUE,
				'order'        => 50,
				'allowed_next' => [],
				'system'       => FALSE,
			],
			'no_show'         => [
				'key'          => 'no_show',
				'label'        => 'عدم حضور',
				'icon'         => 'ni ni-user-cross',
				'color'        => 'danger',
				'active'       => TRUE,
				'order'        => 60,
				'allowed_next' => [],
				'system'       => FALSE,
			],
			'expired'         => [
				'key'          => 'expired',
				'label'        => 'منقضی شده',
				'icon'         => 'ni ni-history',
				'color'        => 'light',
				'active'       => TRUE,
				'order'        => 70,
				'allowed_next' => [],
				'system'       => TRUE,
			],
		];
	}
	
	public function get_location_types( bool $active_only = FALSE ): array {
		$types = $this->get( 'location_types', [] );
		$types = is_array( $types ) ? $types : [];
		
		if ( $active_only ) {
			$types = array_filter(
				$types,
				fn( array $type ): bool => ! empty( $type['active'] )
			);
		}
		
		uasort( $types, [ $this, 'sort_by_order' ] );
		
		return $types;
	}
	
	public function get_location_type( string $key ): array {
		$key   = sanitize_key( $key );
		$types = $this->get_location_types();
		
		return isset( $types[ $key ] ) && is_array( $types[ $key ] )
			? $types[ $key ]
			: [];
	}
	
	public function get_location_type_options( bool $active_only = TRUE ): array {
		$options = [];
		
		foreach ( $this->get_location_types( $active_only ) as $key => $type ) {
			$options[ $key ] = (string) ( $type['label'] ?? $key );
		}
		
		return $options;
	}
	
	public function save_location_type( array $type, string $original_key = '' ): string|WP_Error {
		$types        = $this->get_location_types();
		$original_key = sanitize_key( $original_key );
		$key          = sanitize_key( (string) ( $type['key'] ?? $original_key ) );
		$label        = sanitize_text_field( (string) ( $type['label'] ?? '' ) );
		
		if ( $key === '' || $label === '' ) {
			return new WP_Error(
				'kerp_appointments_invalid_location_type',
				__( 'کلید و عنوان نوع برگزاری الزامی است.', 'kasebi-erp' )
			);
		}
		
		if (
			$original_key !== '' &&
			$original_key !== $key &&
			isset( $types[ $key ] )
		) {
			return new WP_Error(
				'kerp_appointments_duplicate_location_type',
				__( 'این کلید نوع برگزاری قبلاً استفاده شده است.', 'kasebi-erp' )
			);
		}
		
		$item = [
			'key'    => $key,
			'label'  => $label,
			'icon'   => sanitize_text_field( (string) ( $type['icon'] ?? 'uik-r fa-map-marker' ) ),
			'color'  => sanitize_key( (string) ( $type['color'] ?? 'primary' ) ) ?: 'primary',
			'active' => ! empty( $type['active'] ),
			'order'  => intval( $type['order'] ?? 10 ),
		];
		
		if ( $original_key !== '' && $original_key !== $key ) {
			KERP_Modules_Appointments_Query::instance()->replace_location_type(
				$original_key,
				$key
			);
			
			unset( $types[ $original_key ] );
		}
		
		$types[ $key ] = $item;
		
		$current                   = $this->all();
		$current['location_types'] = $types;
		
		update_option( self::OPTION_KEY, $current, FALSE );
		
		return $key;
	}
	
	public function delete_location_type( string $key ): bool|WP_Error {
		$key   = sanitize_key( $key );
		$types = $this->get_location_types();
		
		if ( ! isset( $types[ $key ] ) ) {
			return new WP_Error(
				'kerp_appointments_location_type_not_found',
				__( 'نوع برگزاری پیدا نشد.', 'kasebi-erp' )
			);
		}
		
		$count = KERP_Modules_Appointments_Query::instance()->count_by_location_type( $key );
		
		if ( $count > 0 ) {
			return new WP_Error(
				'kerp_appointments_location_type_in_use',
				sprintf( __( 'این نوع برگزاری در %s استفاده شده است و قابل حذف نیست. می‌توانید آن را غیرفعال کنید.', 'kasebi-erp' ), $this->get_appointment_plural_label() )
			);
		}
		
		unset( $types[ $key ] );
		
		$current                   = $this->all();
		$current['location_types'] = $types;
		
		update_option( self::OPTION_KEY, $current, FALSE );
		
		return TRUE;
	}
	
	private function default_location_types(): array {
		return [
			'in_person' => [
				'key'    => 'in_person',
				'label'  => 'حضوری',
				'icon'   => 'uik-r fa-map-marker',
				'color'  => 'primary',
				'active' => TRUE,
				'order'  => 10,
			],
			'phone'     => [
				'key'    => 'phone',
				'label'  => 'تلفنی',
				'icon'   => 'uik-r fa-phone-call',
				'color'  => 'success',
				'active' => TRUE,
				'order'  => 20,
			],
			'online'    => [
				'key'    => 'online',
				'label'  => 'آنلاین',
				'icon'   => 'uik-r fa-globe',
				'color'  => 'info',
				'active' => TRUE,
				'order'  => 30,
			],
			'other'     => [
				'key'    => 'other',
				'label'  => 'سایر',
				'icon'   => 'uik-r fa-apps',
				'color'  => 'secondary',
				'active' => TRUE,
				'order'  => 40,
			],
		];
	}
	
}
