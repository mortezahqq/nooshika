<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Appointments_Booking_Product {
	private const OPTION_KEY = 'kerp_appointments_booking_product_id';
	private const META_KEY   = '_kerp_appointments_booking_product';
	private static ?self $instance = NULL;
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		return self::$instance;
	}
	private function __construct() {}
	private function __clone() {}
	public function __wakeup(): void { throw new LogicException( 'Cannot unserialize a singleton.' ); }

	public function get_product_id(): int {
		$product_id = absint( get_option( self::OPTION_KEY, 0 ) );
		if ( $this->is_valid_product( $product_id ) ) {
			return $product_id;
		}
		$product_id = $this->find_existing_product_id();
		if ( $product_id > 0 ) {
			update_option( self::OPTION_KEY, $product_id, FALSE );
			return $product_id;
		}
		return 0;
	}

	public function ensure_product(): int|WP_Error {
		if ( ! class_exists( 'WooCommerce' ) || ! class_exists( 'WC_Product_Simple' ) ) {
			return new WP_Error( 'kerp_appointments_woocommerce_missing', __( 'ووکامرس برای محصول رزرو فعال نیست.', 'kasebi-erp' ) );
		}
		$product_id = $this->get_product_id();
		if ( $product_id > 0 ) {
			$product = wc_get_product( $product_id );
			if ( $product instanceof WC_Product ) {
				$this->normalize_product( $product );
				return $product_id;
			}
		}
		$product = new WC_Product_Simple();
		$product->set_name( sprintf( __( 'رزرو %s', 'kasebi-erp' ), KERP_Modules_Appointments_Settings::instance()->get_appointment_singular_label() ) );
		$product->set_status( 'publish' );
		$product->set_catalog_visibility( 'hidden' );
		$product->set_virtual( TRUE );
		$product->set_manage_stock( FALSE );
		$product->set_sold_individually( FALSE );
		$product->set_stock_status( 'instock' );
		$product->set_regular_price( '0' );
		$product->set_price( '0' );
		$product->set_tax_status( 'none' );
		$product->update_meta_data( self::META_KEY, '1' );
		$product_id = $product->save();
		if ( $product_id <= 0 ) {
			return new WP_Error( 'kerp_appointments_product_create_failed', __( 'محصول سیستمی رزرو ایجاد نشد.', 'kasebi-erp' ) );
		}
		update_option( self::OPTION_KEY, $product_id, FALSE );
		return (int) $product_id;
	}

	public function recreate_product(): int|WP_Error {
		delete_option( self::OPTION_KEY );
		return $this->ensure_product();
	}

	public function get_product(): ?WC_Product {
		$product_id = $this->get_product_id();
		$product    = $product_id > 0 ? wc_get_product( $product_id ) : FALSE;
		return $product instanceof WC_Product ? $product : NULL;
	}

	private function is_valid_product( int $product_id ): bool {
		if ( $product_id <= 0 || ! function_exists( 'wc_get_product' ) ) {
			return FALSE;
		}
		$product = wc_get_product( $product_id );
		return $product instanceof WC_Product && (string) $product->get_meta( self::META_KEY, TRUE ) === '1';
	}

	private function find_existing_product_id(): int {
		$query = new WP_Query( [
			'post_type'      => 'product',
			'post_status'    => [ 'publish', 'private', 'draft' ],
			'posts_per_page' => 1,
			'fields'         => 'ids',
			'no_found_rows'  => TRUE,
			'meta_query'     => [
				[
					'key'   => self::META_KEY,
					'value' => '1',
			],
			],
		] );
		return ! empty( $query->posts ) ? absint( $query->posts[0] ) : 0;
	}

	private function normalize_product( WC_Product $product ): void {
		$changed = FALSE;
		if ( $product->get_catalog_visibility() !== 'hidden' ) {
			$product->set_catalog_visibility( 'hidden' );
			$changed = TRUE;
		}
		if ( ! $product->is_virtual() ) {
			$product->set_virtual( TRUE );
			$changed = TRUE;
		}
		if ( $product->get_manage_stock() ) {
			$product->set_manage_stock( FALSE );
			$changed = TRUE;
		}
		if ( (string) $product->get_meta( self::META_KEY, TRUE ) !== '1' ) {
			$product->update_meta_data( self::META_KEY, '1' );
			$changed = TRUE;
		}
		if ( $changed ) {
			$product->save();
		}
	}
}
