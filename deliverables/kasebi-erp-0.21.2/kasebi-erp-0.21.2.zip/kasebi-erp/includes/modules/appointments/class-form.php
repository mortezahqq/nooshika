<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Appointments_Form {
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public function render_modals(): void {
		if ( kerp_can( 'appointments.create', 'action' ) || kerp_can( 'appointments.edit', 'action' ) ) {
			KERP_Helpers_Template::render_template( 'modules/appointments/modals/appointment-form.php', [
				'employee_options' => $this->get_employee_options(),
				'service_options'  => KERP_Modules_Appointments_Services::instance()->get_options(),
				'status_options'   => KERP_Modules_Appointments_Settings::instance()->get_status_options(),
			] );
		}
		if ( kerp_can( 'appointments.services.manage', 'action' ) ) {
			KERP_Helpers_Template::render_template( 'modules/appointments/modals/service-form.php', [
				'employee_options' => $this->get_employee_options(),
				'taxonomy_groups'  => KERP_Modules_Appointments_Taxonomies::instance()->get_grouped_terms(),
			] );
		}
		if ( kerp_can( 'appointments.taxonomies.manage', 'action' ) ) {
			KERP_Helpers_Template::render_template( 'modules/appointments/modals/taxonomy-form.php' );
			KERP_Helpers_Template::render_template( 'modules/appointments/modals/term-form.php', [
				'taxonomies' => KERP_Modules_Appointments_Taxonomies::instance()->get_taxonomies(),
			] );
		}
		if ( kerp_can( 'appointments.schedules.manage', 'action' ) ) {
			KERP_Helpers_Template::render_template( 'modules/appointments/modals/schedule-form.php', [
				'employee_options' => $this->get_employee_options(),
				'service_options'  => KERP_Modules_Appointments_Services::instance()->get_options(),
				'weekday_options'  => KERP_Modules_Appointments_Schedules::instance()->get_weekday_options(),
			] );
			KERP_Helpers_Template::render_template( 'modules/appointments/modals/exception-form.php', [
				'employee_options' => $this->get_employee_options(),
				'service_options'  => KERP_Modules_Appointments_Services::instance()->get_options(),
			] );
		}
		if ( kerp_can( 'appointments.manage_settings', 'action' ) ) {
			KERP_Helpers_Template::render_template( 'modules/appointments/modals/status-form.php', [
				'status_options' => KERP_Modules_Appointments_Settings::instance()->get_status_options( FALSE ),
			] );
			KERP_Helpers_Template::render_template(
				'modules/appointments/modals/location-type-form.php'
			);
		}
		if ( kerp_can( 'appointments.edit', 'action' ) ) {
			KERP_Helpers_Template::render_template(
				'modules/appointments/modals/appointment-note-form.php'
			);
		}
	}
	
	public function get_employee_options( bool $enforce_scope = TRUE ): array {
		if ( class_exists( 'KERP_Modules_Employees_Query' ) ) {
			$options = KERP_Modules_Employees_Query::instance()->get_options(
				0,
				$enforce_scope
			);
			
			return is_array( $options ) ? $options : [];
		}
		
		return [];
	}
	
	public function get_employee_options_for_service(
		int $service_id,
		bool $enforce_scope = TRUE
	): array {
		$options = $this->get_employee_options( $enforce_scope );
		$ids     = KERP_Modules_Appointments_Services::instance()->get_employee_ids( $service_id );
		
		if ( empty( $ids ) ) {
			return $options;
		}
		
		return array_intersect_key(
			$options,
			array_fill_keys( $ids, TRUE )
		);
	}
	
	public function normalize_date( string $date ): string {
		$date = trim( $date );
		$date = KERP_Helpers_Format::sanitize_numbers( $date );
		$date = str_replace( '/', '-', $date );
		if ( preg_match( '/^\d{4}-\d{1,2}-\d{1,2}$/', $date ) !== 1 ) {
			return '';
		}
		$year = (int) substr( $date, 0, 4 );
		if ( $year < 1700 && class_exists( 'KERP_Helpers_Date' ) ) {
			$converted = KERP_Helpers_Date::jalali_to_gregorian( $date );
			if ( ! is_string( $converted ) || $converted === '' ) {
				return '';
			}
			$date = $converted;
		}
		$dt     = DateTimeImmutable::createFromFormat( '!Y-m-d', $date, wp_timezone() );
		$errors = DateTimeImmutable::getLastErrors();
		if ( ! $dt instanceof DateTimeImmutable || ( $errors !== FALSE && ( (int) $errors['warning_count'] > 0 || (int) $errors['error_count'] > 0 ) ) ) {
			return '';
		}
		
		return $dt->format( 'Y-m-d' );
	}
	
	public function combine_datetime( string $date, string $time ): string|WP_Error {
		$date = $this->normalize_date( $date );
		$time = trim( $time );
		if ( function_exists( 'nooshika_sanitize_numbers' ) ) {
			$time = nooshika_sanitize_numbers( $time );
		}
		if ( $date === '' || preg_match( '/^(\d{1,2}):(\d{2})(?::\d{2})?$/', $time, $match ) !== 1 ) {
			return new WP_Error( 'kerp_appointments_invalid_datetime', sprintf( __( 'تاریخ یا ساعت %s معتبر نیست.', 'kasebi-erp' ), KERP_Modules_Appointments_Settings::instance()
			                                                                                                                                                          ->get_appointment_singular_label() ) );
		}
		$hour   = (int) $match[1];
		$minute = (int) $match[2];
		if ( $hour > 23 || $minute > 59 ) {
			return new WP_Error( 'kerp_appointments_invalid_datetime', sprintf( __( 'تاریخ یا ساعت %s معتبر نیست.', 'kasebi-erp' ), KERP_Modules_Appointments_Settings::instance()
			                                                                                                                                                          ->get_appointment_singular_label() ) );
		}
		
		return sprintf( '%s %02d:%02d:00', $date, $hour, $minute );
	}
	
	public function to_display_date( string $mysql_date ): string {
		$timestamp = strtotime( $mysql_date . ' 12:00:00' );
		
		return $timestamp !== FALSE ? date_i18n( 'j F Y', $timestamp ) : '';
	}
	
	public function to_display_datetime( string $mysql_datetime ): string {
		$timestamp = strtotime( $mysql_datetime );
		
		return $timestamp !== FALSE ? date_i18n( 'Y/m/d H:i', $timestamp ) : '';
	}
	
	public function get_location_type_options(): array {
		return KERP_Modules_Appointments_Settings::instance()
		                                         ->get_location_type_options();
	}
	
}
