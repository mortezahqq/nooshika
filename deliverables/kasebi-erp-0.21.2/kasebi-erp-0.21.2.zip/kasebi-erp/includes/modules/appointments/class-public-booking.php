<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Appointments_Public_Booking {
	
	public const  BOOKING_SHORTCODE = 'kerp_appointment_booking';
	
	public const  HISTORY_SHORTCODE = 'kerp_appointment_history';
	
	private const PENDING_PREFIX    = 'kerp_appointment_booking_';
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {
		add_filter( 'kerp_panel_navigation_pages', [ $this, 'register_panel_navigation_settings' ] );
		add_shortcode( self::BOOKING_SHORTCODE, [ $this, 'render_booking_shortcode' ] );
		add_shortcode( self::HISTORY_SHORTCODE, [ $this, 'render_history_shortcode' ] );
		
		add_filter( 'nooshika_panel_pages_list_final', [ $this, 'register_panel_pages' ], 10, 2 );
		add_filter( 'nooshika_panel_get_template_path', [ $this, 'filter_panel_template_path' ], 10, 2 );
		
		add_action( 'wp_enqueue_scripts', [ $this, 'register_assets' ], 5 );
		add_action( 'wp_enqueue_scripts', [ $this, 'maybe_enqueue_assets' ], 40 );
		add_action( 'kasebi_ajax_appointments_public_month', [ $this, 'ajax_month' ] );
		add_action( 'kasebi_ajax_appointments_public_slots', [ $this, 'ajax_slots' ] );
		add_action( 'kasebi_ajax_appointments_public_submit', [ $this, 'ajax_submit' ] );
		
		add_action( 'kasebi_ajax_appointments_public_verify_otp', [ $this, 'ajax_verify_otp' ] );
		add_action( 'nooshika_ajax_appointments_public_verify_otp', [ $this, 'ajax_verify_otp' ] );
		
		add_action( 'woocommerce_payment_complete', [ $this, 'confirm_appointment_from_order' ] );
		add_action( 'woocommerce_order_status_processing', [ $this, 'confirm_appointment_from_order' ] );
		add_action( 'woocommerce_order_status_completed', [ $this, 'confirm_appointment_from_order' ] );
		add_action( 'woocommerce_order_status_cancelled', [ $this, 'cancel_appointment_from_order' ] );
		add_action( 'woocommerce_order_status_failed', [ $this, 'cancel_appointment_from_order' ] );
		add_filter( 'woocommerce_get_return_url', [ $this, 'filter_order_return_url' ], 20, 2 );
		add_action( 'template_redirect', [ $this, 'redirect_woocommerce_thankyou' ], 20 );
	}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public function register_assets(): void {
		wp_register_style(
			'kerp-appointments-public-booking',
			KERP_ASSETS_URL . 'public/css/appointments-booking.css',
			[],
			function_exists( 'kerp_asset_version' ) ? kerp_asset_version( 'public/css/appointments-booking.css' ) : KERP_VERSION
		);
		wp_register_script(
			'kerp-appointments-public-booking',
			KERP_ASSETS_URL . 'public/js/appointments-booking.js',
			[ 'jquery' ],
			function_exists( 'kerp_asset_version' ) ? kerp_asset_version( 'public/js/appointments-booking.js' ) : KERP_VERSION,
			TRUE
		);
	}
	
	public function maybe_enqueue_assets(): void {
		if ( ! $this->current_page_has_public_shortcode() && ! $this->is_receipt_request() ) {
			return;
		}
		$this->enqueue_assets();
	}
	
	private function enqueue_assets(): void {
		wp_enqueue_style( 'kerp-appointments-public-booking' );
		wp_enqueue_script( 'kerp-appointments-public-booking' );
		wp_localize_script(
			'kerp-appointments-public-booking',
			'KERPAppointmentsPublic',
			[
				'ajaxUrl' => home_url( '/' . KERP_Modules_Ajax_Module::ENDPOINT . '/' ),
				'nonce'   => wp_create_nonce( 'ksp_ajax_nonce' ),
				'today'   => date( 'Y-m-d' ),
				'month'   => date( 'Y-m' ),
				'i18n'    => [
					'loading'             => __( 'در حال دریافت اطلاعات...', 'kasebi-erp' ),
					'chooseService'       => __( 'ابتدا یک خدمت را انتخاب کنید.', 'kasebi-erp' ),
					'chooseSlot'          => __( 'روز و ساعت موردنظر را انتخاب کنید.', 'kasebi-erp' ),
					'noServices'          => __( 'خدمتی با این فیلترها پیدا نشد.', 'kasebi-erp' ),
					'noSlots'             => __( 'برای این روز ساعت آزادی وجود ندارد.', 'kasebi-erp' ),
					'noMonthAvailability' => __( 'در این ماه زمان آزادی وجود ندارد.', 'kasebi-erp' ),
					'invalidCustomer'     => __( 'اطلاعات فردی را کامل وارد کنید.', 'kasebi-erp' ),
					'chooseGateway'       => __( 'روش پرداخت را انتخاب کنید.', 'kasebi-erp' ),
					'genericError'        => __( 'خطایی رخ داد. دوباره تلاش کنید.', 'kasebi-erp' ),
				],
			]
		);
	}
	
	public function render_booking_shortcode( array $atts = [] ): string {
		$this->enqueue_assets();
		$receipt = $this->get_receipt_context();
		if ( ! empty( $receipt ) ) {
			$output = KERP_Helpers_Template::get_template(
				'modules/appointments/public/receipt.php',
				$receipt
			);
			
			return is_string( $output ) ? $output : '';
		}
		
		$services         = array_values(
			array_filter(
				(array) ( KERP_Modules_Appointments_Services::instance()->find( [
						'active'   => 1,
						'per_page' => 200,
					] )['items'] ?? [] ),
				static fn( array $service ): bool => ! empty( $service['active'] ) && ! empty( $service['public_booking'] )
			)
		);
		$taxonomies       = KERP_Modules_Appointments_Taxonomies::instance()->get_taxonomies( TRUE );
		$employee_options = [];
		foreach ( $services as $service ) {
			foreach ( (array) ( $service['employee_ids'] ?? [] ) as $employee_id ) {
				$employee_id = absint( $employee_id );
				if ( $employee_id > 0 && ! isset( $employee_options[ $employee_id ] ) ) {
					$employee_options[ $employee_id ] = get_user_name_by_id( $employee_id );
				}
			}
		}
		natcasesort( $employee_options );
		$customer_fields = KERP_Modules_Appointments_Public_Fields::instance()->get_form_fields();
		$gateways        = $this->get_available_gateways();
		$user_data       = $this->get_current_customer_values( $customer_fields );
		$settings        = KERP_Modules_Appointments_Settings::instance();
		$output          = KERP_Helpers_Template::get_template(
			'modules/appointments/public/booking.php',
			[
				'services'         => $services,
				'taxonomies'       => $taxonomies,
				'employee_options' => $employee_options,
				'customer_fields'  => $customer_fields,
				'gateways'         => $gateways,
				'user_data'        => $user_data,
				'settings'         => $settings,
			]
		);
		
		return is_string( $output ) ? $output : '';
	}
	
	public function render_history_shortcode( array $atts = [] ): string {
		$this->enqueue_assets();
		$settings = KERP_Modules_Appointments_Settings::instance();
		if ( ! is_user_logged_in() ) {
			$output = KERP_Helpers_Template::get_template(
				'modules/appointments/public/history.php',
				[
					'appointments' => [],
					'settings'     => $settings,
					'login_url'    => add_query_arg( 'redirect_to', rawurlencode( get_permalink() ?: home_url( '/' ) ), home_url( '/login/' ) ),
					'is_logged_in' => FALSE,
				]
			);
			
			return is_string( $output ) ? $output : '';
		}
		$result = KERP_Modules_Appointments_Query::instance()->find( [
			'customer_id'   => get_current_user_id(),
			'page_number'   => 1,
			'per_page'      => 200,
			'order'         => 'DESC',
			'enforce_scope' => FALSE,
		] );
		$output = KERP_Helpers_Template::get_template(
			'modules/appointments/public/history.php',
			[
				'appointments' => (array) ( $result['items'] ?? [] ),
				'settings'     => $settings,
				'login_url'    => '',
				'is_logged_in' => TRUE,
			]
		);
		
		return is_string( $output ) ? $output : '';
	}
	
	public function register_panel_pages( array $pages, array $defaults = [] ): array {
		$pages['appointment-history'] = [
			'label' => __( 'سوابق نوبت‌های من', 'kasebi-erp' ),
			'icon'  => 'kik fa-calendar-check-02',
		];
		
		return $pages;
	}
	
	public function filter_panel_template_path( string $file_path, string $path ): string {
		if ( $path !== 'pages/appointment-history' ) {
			return $file_path;
		}
		
		return KERP_TEMPLATES_PATH . 'modules/appointments/panel/appointment-history.php';
	}
	
	public function ajax_month(): void {
		$this->verify_public_nonce();
		
		$service_id  = absint( $_POST['service_id'] ?? 0 );
		$employee_id = absint( $_POST['employee_id'] ?? 0 );
		$month       = sanitize_text_field( wp_unslash( $_POST['month'] ?? '' ) );
		
		if ( preg_match( '/^\d{4}-\d{2}$/', $month ) !== 1 ) {
			$this->json_error( __( 'ماه انتخاب‌شده معتبر نیست.', 'kasebi-erp' ) );
		}
		
		$service = $this->get_public_service( $service_id );
		
		if ( empty( $service ) ) {
			$this->json_error(
				sprintf(
					__( '%s انتخاب‌شده معتبر نیست.', 'kasebi-erp' ),
					KERP_Modules_Appointments_Settings::instance()->get_service_singular_label()
				)
			);
		}
		
		$form_service = KERP_Modules_Appointments_Form::instance();
		
		$anchor_date = $month . '-01';
		
		/*
		 * تاریخ میلادی اصلی را به to_display_date می‌دهیم.
		 * مثلاً:
		 * 2026-08-01 => 10 مرداد 1405
		 */
		$display_anchor = $form_service->to_display_date( $anchor_date );
		
		if ( function_exists( 'nooshika_sanitize_numbers' ) ) {
			$normalized_display = nooshika_sanitize_numbers( $display_anchor );
		} elseif ( class_exists( 'KERP_Helpers_Format' ) ) {
			$normalized_display = KERP_Helpers_Format::sanitize_numbers( $display_anchor );
		} else {
			$normalized_display = $display_anchor;
		}
		
		if (
			preg_match(
				'/^\d{1,2}\s+(.+?)\s+(\d{4})$/u',
				trim( $normalized_display ),
				$matches
			) !== 1
		) {
			$this->json_error( __( 'تبدیل ماه شمسی انجام نشد.', 'kasebi-erp' ) );
		}
		
		$jalali_month_names = [
			'فروردین'  => 1,
			'اردیبهشت' => 2,
			'خرداد'    => 3,
			'تیر'      => 4,
			'مرداد'    => 5,
			'شهریور'   => 6,
			'مهر'      => 7,
			'آبان'     => 8,
			'آذر'      => 9,
			'دی'       => 10,
			'بهمن'     => 11,
			'اسفند'    => 12,
		];
		
		$jalali_month_name = trim( (string) $matches[1] );
		$jalali_year       = (int) $matches[2];
		$jalali_month      = (int) ( $jalali_month_names[ $jalali_month_name ] ?? 0 );
		
		if ( $jalali_year <= 0 || $jalali_month <= 0 ) {
			$this->json_error( __( 'ماه شمسی معتبر نیست.', 'kasebi-erp' ) );
		}
		
		$jalali_start = sprintf(
			'%04d-%02d-01',
			$jalali_year,
			$jalali_month
		);
		
		$next_year  = $jalali_year;
		$next_month = $jalali_month + 1;
		
		if ( $next_month > 12 ) {
			$next_month = 1;
			$next_year ++;
		}
		
		$jalali_next_start = sprintf(
			'%04d-%02d-01',
			$next_year,
			$next_month
		);
		
		$gregorian_start = KERP_Helpers_Date::jalali_to_gregorian(
			$jalali_start
		);
		
		$gregorian_next_start = KERP_Helpers_Date::jalali_to_gregorian(
			$jalali_next_start
		);
		
		if ( $gregorian_start === '' || $gregorian_next_start === '' ) {
			$this->json_error( __( 'تبدیل ماه شمسی انجام نشد.', 'kasebi-erp' ) );
		}
		
		$month_start = strtotime( $gregorian_start . ' 12:00:00' );
		$month_end   = strtotime( $gregorian_next_start . ' 12:00:00' );
		
		if ( $month_start === FALSE || $month_end === FALSE ) {
			$this->json_error( __( 'ماه انتخاب‌شده معتبر نیست.', 'kasebi-erp' ) );
		}
		
		$days_in_month = (int) round(
			( $month_end - $month_start ) / DAY_IN_SECONDS
		);
		
		$today        = date( 'Y-m-d' );
		$available    = [];
		$dates        = [];
		$display_days = [];
		
		for ( $day = 1; $day <= $days_in_month; $day ++ ) {
			$date = date(
				'Y-m-d',
				strtotime(
					'+' . ( $day - 1 ) . ' days',
					$month_start
				)
			);
			
			$dates[ $day ]         = $date;
			$display_days[ $date ] = $day;
			
			if ( $date < $today ) {
				continue;
			}
			
			$groups = $this->get_grouped_slots(
				$date,
				$service_id,
				$employee_id
			);
			
			$count = 0;
			
			foreach ( $groups as $slots ) {
				$count += count( $slots );
			}
			
			if ( $count > 0 ) {
				$available[ $date ] = $count;
			}
		}
		
		/*
		 * از "10 مرداد 1405" فقط "مرداد 1405" را نگه می‌داریم.
		 */
		$month_title = preg_replace(
			'/^\S+\s+/u',
			'',
			trim( $display_anchor )
		);
		
		$this->json_success(
			[
				'month'           => $month,
				'month_title'     => $month_title,
				'days_in_month'   => $days_in_month,
				'first_weekday'   => (int) date( 'w', $month_start ),
				'dates'           => $dates,
				'display_days'    => $display_days,
				'available_dates' => $available,
			]
		);
	}
	
	public function ajax_slots(): void {
		$this->verify_public_nonce();
		$date        = KERP_Modules_Appointments_Form::instance()->normalize_date( $this->post_text( 'date' ) );
		$service_id  = absint( $_POST['service_id'] ?? 0 );
		$employee_id = absint( $_POST['employee_id'] ?? 0 );
		if ( $date === '' || $date < date( 'Y-m-d' ) ) {
			$this->json_error( __( 'تاریخ انتخاب‌شده معتبر نیست.', 'kasebi-erp' ) );
		}
		$service = $this->get_public_service( $service_id );
		if ( empty( $service ) ) {
			$this->json_error( __( 'خدمت انتخاب‌شده معتبر نیست.', 'kasebi-erp' ) );
		}
		$groups = $this->get_grouped_slots( $date, $service_id, $employee_id );
		$items  = [];
		foreach ( $groups as $slot_employee_id => $slots ) {
			if ( empty( $slots ) ) {
				continue;
			}
			$items[] = [
				'employee_id'   => absint( $slot_employee_id ),
				'employee_name' => get_user_name_by_id( absint( $slot_employee_id ) ),
				'slots'         => array_values( array_map( static function( array $slot ): array {
					return [
						'time'      => (string) ( $slot['time'] ?? '' ),
						'remaining' => absint( $slot['remaining'] ?? 0 ),
					];
				}, $slots ) ),
			];
		}
		$this->json_success( [
			'date'         => $date,
			'display_date' => KERP_Modules_Appointments_Form::instance()->to_display_date( $date ),
			'employees'    => $items,
		] );
	}
	
	public function ajax_submit(): void {
		$this->verify_public_nonce();
		
		$payload = $this->sanitize_booking_payload();
		
		if ( is_wp_error( $payload ) ) {
			$this->json_error( $payload->get_error_message() );
		}
		
		$service = $this->get_public_service(
			absint( $payload['service_id'] )
		);
		
		if ( empty( $service ) ) {
			$this->json_error(
				__( 'خدمت انتخاب‌شده معتبر نیست.', 'kasebi-erp' )
			);
		}
		
		$slots = KERP_Modules_Appointments_Availability::instance()->get_slots(
			(string) $payload['date'],
			absint( $payload['service_id'] ),
			absint( $payload['employee_id'] )
		);
		
		$valid_slot = FALSE;
		
		foreach ( $slots as $slot ) {
			if (
				(string) ( $slot['time'] ?? '' ) === (string) $payload['time'] &&
				absint( $slot['remaining'] ?? 0 ) > 0
			) {
				$valid_slot = TRUE;
				break;
			}
		}
		
		if ( ! $valid_slot ) {
			$this->json_error(
				__( 'این ساعت دیگر در دسترس نیست. ساعت دیگری انتخاب کنید.', 'kasebi-erp' )
			);
		}
		
		if ( is_user_logged_in() ) {
			$customer_id = get_current_user_id();
			
			$this->update_customer_data(
				$customer_id,
				$payload
			);
			
			$this->complete_booking(
				$payload,
				$customer_id
			);
			
			return;
		}
		
		$phone = (string) $payload['phone'];
		
		set_transient(
			$this->pending_key( $phone ),
			$payload,
			20 * MINUTE_IN_SECONDS
		);
		
		$result = $this->send_otp( $phone );
		
		if ( is_wp_error( $result ) ) {
			delete_transient(
				$this->pending_key( $phone )
			);
			
			$this->json_error(
				$result->get_error_message()
			);
		}
		
		wp_send_json(
			[
				'status' => 'need_otp',
				'msg'    => __( 'کد تایید ارسال شد.', 'kasebi-erp' ),
			]
		);
	}
	
	private function complete_booking( array $payload, int $customer_id ): void {
		$appointment_id = $this->create_public_appointment( $payload, $customer_id );
		if ( is_wp_error( $appointment_id ) ) {
			$this->json_error( $appointment_id->get_error_message() );
		}
		
		$appointment = KERP_Modules_Appointments_Query::instance()->get_by_id( $appointment_id );
		$payable     = (float) ( $appointment['payable_amount'] ?? 0 );
		
		$receipt_url = $this->build_receipt_url(
			(string) ( $payload['receipt_base_url'] ?? home_url( '/' ) ),
			$appointment_id,
			''
		);
		
		if ( $payable <= 0 ) {
			KERP_Modules_Appointments_Manager::instance()->change_status(
				$appointment_id,
				'confirmed'
			);
			
			wp_send_json(
				[
					'result'   => 'success',
					'redirect' => $receipt_url,
				]
			);
		}
		
		$order = $this->create_payment_order(
			$appointment,
			$payload,
			$customer_id
		);
		
		if ( is_wp_error( $order ) ) {
			$this->json_error( $order->get_error_message() );
		}
		
		$receipt_url = $this->build_receipt_url(
			(string) ( $payload['receipt_base_url'] ?? home_url( '/' ) ),
			$appointment_id,
			$order->get_order_key()
		);
		
		$order->update_meta_data(
			'_kerp_appointment_receipt_url',
			$receipt_url
		);
		
		$order->save();
		
		$this->link_order_to_appointment(
			$appointment_id,
			$order->get_id()
		);
		
		$gateway_id = sanitize_key(
			(string) ( $payload['payment_method'] ?? '' )
		);
		
		$gateways = $this->get_available_gateways();
		$gateway  = $gateways[ $gateway_id ] ?? NULL;
		
		if ( ! $gateway instanceof WC_Payment_Gateway ) {
			$this->json_error(
				__( 'روش پرداخت انتخاب‌شده در دسترس نیست.', 'kasebi-erp' )
			);
		}
		
		$order->set_payment_method( $gateway );
		$order->save();
		
		$result = $gateway->process_payment(
			$order->get_id()
		);
		
		if (
			! is_array( $result ) ||
			(string) ( $result['result'] ?? '' ) !== 'success' ||
			empty( $result['redirect'] )
		) {
			$this->json_error(
				__( 'شروع فرایند پرداخت انجام نشد.', 'kasebi-erp' )
			);
		}
		
		wp_send_json(
			[
				'result'   => 'success',
				'redirect' => esc_url_raw( (string) $result['redirect'] ),
			]
		);
	}
	
	public function ajax_verify_otp(): void {
		$phone = $this->normalize_phone( $this->post_text( 'phone' ) );
		$otp   = sanitize_text_field( $this->post_text( 'otp' ) );
		if ( $phone === '' || $otp === '' ) {
			$this->json_error( __( 'کد تایید یا شماره موبایل معتبر نیست.', 'kasebi-erp' ) );
		}
		$otp_data = get_transient( 'otp_' . $phone );
		if ( ! is_array( $otp_data ) || empty( $otp_data['otp'] ) || empty( $otp_data['created'] ) ) {
			$this->json_error( __( 'کد تایید منقضی شده است.', 'kasebi-erp' ) );
		}
		if ( (int) $otp_data['created'] + 180 < time() ) {
			delete_transient( 'otp_' . $phone );
			$this->json_error( __( 'کد تایید منقضی شده است.', 'kasebi-erp' ) );
		}
		$wrong_key = 'kerp_appointment_otp_wrong_' . md5( $phone );
		$wrong_try = absint( get_transient( $wrong_key ) );
		if ( $wrong_try >= 5 ) {
			$this->json_error( __( 'تعداد تلاش ناموفق بیش از حد مجاز است. چند دقیقه بعد دوباره تلاش کنید.', 'kasebi-erp' ) );
		}
		if ( ! hash_equals( (string) $otp_data['otp'], $otp ) ) {
			set_transient( $wrong_key, $wrong_try + 1, 5 * MINUTE_IN_SECONDS );
			$this->json_error( __( 'کد تایید صحیح نیست.', 'kasebi-erp' ) );
		}
		$payload = get_transient( $this->pending_key( $phone ) );
		if ( ! is_array( $payload ) ) {
			$this->json_error( __( 'اطلاعات رزرو منقضی شده است. رزرو را دوباره انجام دهید.', 'kasebi-erp' ) );
		}
		if ( (string) ( $payload['phone'] ?? '' ) !== $phone ) {
			$this->json_error( __( 'شماره موبایل رزرو با شماره تاییدشده مطابقت ندارد.', 'kasebi-erp' ) );
		}
		$customer_id = $this->resolve_customer( $payload );
		if ( is_wp_error( $customer_id ) ) {
			$this->json_error( $customer_id->get_error_message() );
		}
		$user = get_userdata( $customer_id );
		
		if ( ! $user instanceof WP_User ) {
			$this->json_error(
				__( 'اطلاعات کاربر معتبر نیست.', 'kasebi-erp' )
			);
		}
		
		wp_clear_auth_cookie();
		wp_set_current_user( $customer_id );
		wp_set_auth_cookie( $customer_id, TRUE );
		
		do_action(
			'wp_login',
			$user->user_login,
			$user
		);
		delete_transient( 'otp_' . $phone );
		delete_transient( $wrong_key );
		delete_transient( $this->pending_key( $phone ) );
		
		$this->complete_booking(
			$payload,
			$customer_id
		);
	}
	
	private function update_customer_data( int $user_id, array $payload ): void {
		$customers_settings = class_exists( 'KERP_Modules_Customers_Settings' )
			? KERP_Modules_Customers_Settings::instance()
			: NULL;
		
		$phone_meta_key = $customers_settings
			? sanitize_key(
				(string) $customers_settings->get(
					'phone_meta_key',
					'nooshika_phone_num'
				)
			)
			: 'nooshika_phone_num';
		
		$first_name = sanitize_text_field(
			(string) ( $payload['first_name'] ?? '' )
		);
		
		$last_name = sanitize_text_field(
			(string) ( $payload['last_name'] ?? '' )
		);
		
		$phone = sanitize_text_field(
			(string) ( $payload['phone'] ?? '' )
		);
		
		wp_update_user(
			[
				'ID'           => $user_id,
				'first_name'   => $first_name,
				'last_name'    => $last_name,
				'display_name' => trim(
					$first_name . ' ' . $last_name
				),
			]
		);
		
		update_user_meta(
			$user_id,
			$phone_meta_key,
			$phone
		);
		
		update_user_meta(
			$user_id,
			'billing_phone',
			$phone
		);
		
		$secondary_phone = sanitize_text_field(
			(string) ( $payload['secondary_phone'] ?? '' )
		);
		
		if ( $secondary_phone !== '' ) {
			update_user_meta(
				$user_id,
				apply_filters(
					'kerp_appointments_secondary_phone_meta_key',
					'kerp_secondary_phone'
				),
				$secondary_phone
			);
		}
		
		$fields_service = KERP_Modules_Appointments_Public_Fields::instance();
		$definitions    = $fields_service->get_all( TRUE );
		
		foreach ( (array) ( $payload['customer_fields'] ?? [] ) as $field_key => $value ) {
			$field_key = sanitize_key(
				(string) $field_key
			);
			
			if (
				$field_key === '' ||
				! isset( $definitions[ $field_key ] )
			) {
				continue;
			}
			
			update_user_meta(
				$user_id,
				$field_key,
				$fields_service->sanitize_value(
					$value,
					$definitions[ $field_key ]
				)
			);
		}
	}
	
	public function ajax_resend_otp(): void {
		$phone = $this->normalize_phone( $this->post_text( 'phone' ) );
		if ( $phone === '' || ! is_array( get_transient( $this->pending_key( $phone ) ) ) ) {
			$this->json_error( __( 'درخواست رزرو معتبر نیست.', 'kasebi-erp' ) );
		}
		$result = $this->send_otp( $phone );
		if ( is_wp_error( $result ) ) {
			$this->json_error( $result->get_error_message() );
		}
		wp_send_json( [
			'status' => 'success',
			'msg'    => __( 'کد تایید دوباره ارسال شد.', 'kasebi-erp' ),
		] );
	}
	
	public function confirm_appointment_from_order( int $order_id ): void {
		$order = wc_get_order( $order_id );
		if ( ! $order instanceof WC_Order ) {
			return;
		}
		$appointment_id = absint( $order->get_meta( '_kerp_appointment_id', TRUE ) );
		if ( $appointment_id <= 0 ) {
			return;
		}
		$appointment = KERP_Modules_Appointments_Query::instance()->get_by_id( $appointment_id );
		if ( empty( $appointment ) || (string) ( $appointment['status'] ?? '' ) !== 'pending_payment' ) {
			return;
		}
		KERP_Modules_Appointments_Manager::instance()->change_status( $appointment_id, 'confirmed' );
	}
	
	public function cancel_appointment_from_order( int $order_id ): void {
		$order = wc_get_order( $order_id );
		if ( ! $order instanceof WC_Order ) {
			return;
		}
		$appointment_id = absint( $order->get_meta( '_kerp_appointment_id', TRUE ) );
		if ( $appointment_id <= 0 ) {
			return;
		}
		$appointment = KERP_Modules_Appointments_Query::instance()->get_by_id( $appointment_id );
		if ( empty( $appointment ) || (string) ( $appointment['status'] ?? '' ) !== 'pending_payment' ) {
			return;
		}
		KERP_Modules_Appointments_Manager::instance()->change_status(
			$appointment_id,
			'cancelled',
			__( 'پرداخت سفارش ناموفق یا لغو شد.', 'kasebi-erp' )
		);
	}
	
	public function filter_order_return_url( string $return_url, WC_Order $order ): string {
		$receipt_url = esc_url_raw( (string) $order->get_meta( '_kerp_appointment_receipt_url', TRUE ) );
		
		return $receipt_url !== '' ? $receipt_url : $return_url;
	}
	
	public function redirect_woocommerce_thankyou(): void {
		if ( ! function_exists( 'is_wc_endpoint_url' ) || ! is_wc_endpoint_url( 'order-received' ) ) {
			return;
		}
		$order_id = absint( get_query_var( 'order-received' ) );
		if ( $order_id <= 0 ) {
			return;
		}
		$order = wc_get_order( $order_id );
		if ( ! $order instanceof WC_Order ) {
			return;
		}
		$receipt_url = esc_url_raw( (string) $order->get_meta( '_kerp_appointment_receipt_url', TRUE ) );
		if ( $receipt_url === '' ) {
			return;
		}
		wp_safe_redirect( $receipt_url );
		exit;
	}
	
	private function create_public_appointment( array $payload, int $customer_id ): int|WP_Error {
		$service = $this->get_public_service( absint( $payload['service_id'] ?? 0 ) );
		if ( empty( $service ) ) {
			return new WP_Error( 'kerp_public_invalid_service', __( 'خدمت انتخاب‌شده معتبر نیست.', 'kasebi-erp' ) );
		}
		$payable = KERP_Modules_Appointments_Services::instance()->calculate_payable_amount( $service );
		$status  = $payable > 0 ? 'pending_payment' : 'held';
		
		return KERP_Modules_Appointments_Manager::instance()->save( [
			'customer_id'    => $customer_id,
			'service_id'     => absint( $payload['service_id'] ?? 0 ),
			'employee_id'    => absint( $payload['employee_id'] ?? 0 ),
			'date'           => (string) ( $payload['date'] ?? '' ),
			'time'           => (string) ( $payload['time'] ?? '' ),
			'quantity'       => 1,
			'status'         => $status,
			'source'         => 'public',
			'location_type'  => (string) ( $payload['location_type'] ?? '' ),
			'location'       => (string) ( $payload['location'] ?? '' ),
			'description'    => '',
			'internal_note'  => '',
			'price'          => (float) ( $service['price'] ?? 0 ),
			'payable_amount' => $payable,
			'metadata'       => [
				'public_booking'  => TRUE,
				'secondary_phone' => (string) ( $payload['secondary_phone'] ?? '' ),
				'customer_fields' => (array) ( $payload['customer_fields'] ?? [] ),
			],
		] );
	}
	
	private function create_payment_order( array $appointment, array $payload, int $customer_id ): WC_Order|WP_Error {
		if ( ! function_exists( 'wc_create_order' ) ) {
			return new WP_Error( 'kerp_public_wc_missing', __( 'ووکامرس برای پرداخت در دسترس نیست.', 'kasebi-erp' ) );
		}
		$product = KERP_Modules_Appointments_Booking_Product::instance()->get_product();
		if ( ! $product instanceof WC_Product ) {
			$product_id = KERP_Modules_Appointments_Booking_Product::instance()->ensure_product();
			if ( is_wp_error( $product_id ) ) {
				return $product_id;
			}
			$product = wc_get_product( $product_id );
		}
		if ( ! $product instanceof WC_Product ) {
			return new WP_Error( 'kerp_public_booking_product_missing', __( 'محصول سیستمی رزرو در دسترس نیست.', 'kasebi-erp' ) );
		}
		$order = wc_create_order( [ 'customer_id' => $customer_id ] );
		if ( is_wp_error( $order ) ) {
			return $order;
		}
		$payable = max( 0, (float) ( $appointment['payable_amount'] ?? 0 ) );
		$item    = new WC_Order_Item_Product();
		$item->set_product( $product );
		$item->set_quantity( 1 );
		$item->set_subtotal( $payable );
		$item->set_total( $payable );
		$item->add_meta_data( KERP_Modules_Appointments_Settings::instance()
		                                                        ->get_service_singular_label(), (string) ( $appointment['service_title'] ?? '' ), TRUE );
		$item->add_meta_data( __( 'تاریخ', 'kasebi-erp' ), KERP_Modules_Appointments_Form::instance()
		                                                                                 ->to_display_date( substr( (string) $appointment['start_at'], 0, 10 ) ), TRUE );
		$item->add_meta_data( __( 'ساعت', 'kasebi-erp' ), substr( (string) $appointment['start_at'], 11, 5 ), TRUE );
		$order->add_item( $item );
		$order->set_address( [
			'first_name' => (string) ( $payload['first_name'] ?? '' ),
			'last_name'  => (string) ( $payload['last_name'] ?? '' ),
			'phone'      => (string) ( $payload['phone'] ?? '' ),
		], 'billing' );
		$order->update_meta_data( '_kerp_appointment_booking', '1' );
		$order->update_meta_data( '_kerp_appointment_id', absint( $appointment['id'] ?? 0 ) );
		$order->update_meta_data( '_kerp_appointment_service_id', absint( $appointment['service_id'] ?? 0 ) );
		$order->update_meta_data( '_kerp_appointment_employee_id', absint( $appointment['employee_id'] ?? 0 ) );
		$order->update_meta_data( '_kerp_appointment_receipt_base_url', esc_url_raw( (string) ( $payload['receipt_base_url'] ?? '' ) ) );
		$order->calculate_totals( FALSE );
		$order->save();
		
		return $order;
	}
	
	private function link_order_to_appointment( int $appointment_id, int $order_id ): void {
		global $wpdb;
		$wpdb->update(
			KERP_Modules_Appointments_Installer::instance()->appointments_table(),
			[
				'order_id'   => absint( $order_id ),
				'updated_at' => current_time( 'mysql' ),
			],
			[ 'id' => absint( $appointment_id ) ]
		);
	}
	
	private function resolve_customer( array $payload ): int|WP_Error {
		$phone              = (string) ( $payload['phone'] ?? '' );
		$user_id            = function_exists( 'get_user_id_by_phone' ) ? absint( get_user_id_by_phone( $phone ) ) : 0;
		$customers_settings = class_exists( 'KERP_Modules_Customers_Settings' ) ? KERP_Modules_Customers_Settings::instance() : NULL;
		$phone_meta_key     = $customers_settings
			? sanitize_key( (string) $customers_settings->get( 'phone_meta_key', 'nooshika_phone_num' ) )
			: 'nooshika_phone_num';
		if ( $user_id <= 0 ) {
			$users   = get_users( [
				'number'     => 1,
				'fields'     => 'ids',
				'meta_key'   => $phone_meta_key,
				'meta_value' => $phone,
			] );
			$user_id = ! empty( $users ) ? absint( $users[0] ) : 0;
		}
		$first_name = sanitize_text_field( (string) ( $payload['first_name'] ?? '' ) );
		$last_name  = sanitize_text_field( (string) ( $payload['last_name'] ?? '' ) );
		if ( $user_id <= 0 ) {
			$role    = get_role( 'customer' ) ? 'customer' : get_option( 'default_role', 'subscriber' );
			$user_id = wp_insert_user( [
				'user_login'   => 'booking_' . wp_generate_uuid4(),
				'user_pass'    => wp_generate_password( 24, TRUE, TRUE ),
				'first_name'   => $first_name,
				'last_name'    => $last_name,
				'display_name' => trim( $first_name . ' ' . $last_name ),
				'role'         => $role,
			] );
			if ( is_wp_error( $user_id ) ) {
				return $user_id;
			}
		} else {
			$result = wp_update_user( [
				'ID'           => $user_id,
				'first_name'   => $first_name,
				'last_name'    => $last_name,
				'display_name' => trim( $first_name . ' ' . $last_name ),
			] );
			if ( is_wp_error( $result ) ) {
				return $result;
			}
		}
		update_user_meta( $user_id, $phone_meta_key, $phone );
		update_user_meta( $user_id, 'billing_phone', $phone );
		$secondary_phone = sanitize_text_field( (string) ( $payload['secondary_phone'] ?? '' ) );
		if ( $secondary_phone !== '' ) {
			update_user_meta( $user_id, apply_filters( 'kerp_appointments_secondary_phone_meta_key', 'kerp_secondary_phone' ), $secondary_phone );
		}
		$fields_service = KERP_Modules_Appointments_Public_Fields::instance();
		$definitions    = $fields_service->get_all( TRUE );
		
		foreach ( (array) ( $payload['customer_fields'] ?? [] ) as $field_key => $value ) {
			$field_key = sanitize_key( (string) $field_key );
			
			if ( $field_key === '' || ! isset( $definitions[ $field_key ] ) ) {
				continue;
			}
			
			update_user_meta(
				$user_id,
				$field_key,
				$fields_service->sanitize_value(
					$value,
					$definitions[ $field_key ]
				)
			);
		}
		
		return absint( $user_id );
	}
	
	private function sanitize_booking_payload(): array|WP_Error {
		$service_id     = absint( $_POST['service_id'] ?? 0 );
		$employee_id    = absint( $_POST['employee_id'] ?? 0 );
		$date           = KERP_Modules_Appointments_Form::instance()->normalize_date( $this->post_text( 'date' ) );
		$time           = $this->post_text( 'time' );
		$first_name     = $this->post_text( 'first_name' );
		$last_name      = $this->post_text( 'last_name' );
		$phone          = $this->normalize_phone( $this->post_text( 'phone' ) );
		$payment_method = sanitize_key( $this->post_text( 'payment_method' ) );
		$receipt_base   = esc_url_raw( $this->post_text( 'receipt_base_url' ) );
		if ( $service_id <= 0 || $employee_id <= 0 || $date === '' || preg_match( '/^\d{2}:\d{2}$/', $time ) !== 1 ) {
			return new WP_Error( 'kerp_public_invalid_slot', __( 'خدمت، کارشناس، روز و ساعت را کامل انتخاب کنید.', 'kasebi-erp' ) );
		}
		if ( $date < date( 'Y-m-d' ) ) {
			return new WP_Error( 'kerp_public_past_date', __( 'امکان رزرو برای تاریخ گذشته وجود ندارد.', 'kasebi-erp' ) );
		}
		if ( $first_name === '' || $last_name === '' || $phone === '' ) {
			return new WP_Error( 'kerp_public_customer_required', __( 'نام، نام خانوادگی و هر دو شماره تلفن را وارد کنید.', 'kasebi-erp' ) );
		}
		$service = $this->get_public_service( $service_id );
		if ( empty( $service ) ) {
			return new WP_Error( 'kerp_public_invalid_service', __( 'خدمت انتخاب‌شده معتبر نیست.', 'kasebi-erp' ) );
		}
		if ( KERP_Modules_Appointments_Services::instance()
		                                       ->calculate_payable_amount( $service ) > 0 && $payment_method === '' ) {
			return new WP_Error( 'kerp_public_gateway_required', __( 'روش پرداخت را انتخاب کنید.', 'kasebi-erp' ) );
		}
		$raw_fields      = isset( $_POST['customer_fields'] ) && is_array( $_POST['customer_fields'] ) ? wp_unslash( $_POST['customer_fields'] ) : [];
		$customer_fields = [];
		$fields_service  = KERP_Modules_Appointments_Public_Fields::instance();
		$definitions     = $fields_service->get_all( TRUE );
		
		foreach ( $raw_fields as $key => $value ) {
			$key = sanitize_key( (string) $key );
			
			if ( $key === '' || ! isset( $definitions[ $key ] ) ) {
				continue;
			}
			
			$value = $fields_service->sanitize_value(
				$value,
				$definitions[ $key ]
			);
			
			if (
				! empty( $definitions[ $key ]['required'] ) &&
				( $value === '' || $value === [] )
			) {
				return new WP_Error(
					'kerp_public_required_field',
					sprintf(
						__( 'فیلد «%s» الزامی است.', 'kasebi-erp' ),
						(string) $definitions[ $key ]['label']
					)
				);
			}
			
			$customer_fields[ $key ] = $value;
		}
		
		return [
			'service_id'       => $service_id,
			'employee_id'      => $employee_id,
			'date'             => $date,
			'time'             => $time,
			'first_name'       => $first_name,
			'last_name'        => $last_name,
			'phone'            => $phone,
			'payment_method'   => $payment_method,
			'receipt_base_url' => $receipt_base !== '' ? $receipt_base : ( get_permalink() ?: home_url( '/' ) ),
			'customer_fields'  => $customer_fields,
		];
	}
	
	private function get_grouped_slots( string $date, int $service_id, int $employee_id ): array {
		$availability = KERP_Modules_Appointments_Availability::instance();
		if ( $employee_id > 0 ) {
			$slots = $availability->get_slots( $date, $service_id, $employee_id );
			
			return ! empty( $slots ) ? [ $employee_id => $slots ] : [];
		}
		$grouped = $availability->get_slots( $date, $service_id, 0 );
		if ( ! empty( $grouped ) && $this->looks_grouped_slots( $grouped ) ) {
			return $grouped;
		}
		$employee_ids = KERP_Modules_Appointments_Services::instance()->get_employee_ids( $service_id );
		if ( empty( $employee_ids ) ) {
			$employee_ids = array_map( 'absint', array_keys( KERP_Modules_Appointments_Form::instance()
			                                                                               ->get_employee_options() ) );
		}
		$groups = [];
		foreach ( $employee_ids as $slot_employee_id ) {
			$slot_employee_id = absint( $slot_employee_id );
			if ( $slot_employee_id <= 0 ) {
				continue;
			}
			$slots = $availability->get_slots( $date, $service_id, $slot_employee_id );
			if ( ! empty( $slots ) ) {
				$groups[ $slot_employee_id ] = $slots;
			}
		}
		
		return $groups;
	}
	
	private function looks_grouped_slots( array $slots ): bool {
		$first = reset( $slots );
		if ( ! is_array( $first ) ) {
			return FALSE;
		}
		
		return ! array_key_exists( 'time', $first );
	}
	
	private function get_public_service( int $service_id ): array {
		$service = KERP_Modules_Appointments_Services::instance()->get( $service_id );
		
		return ! empty( $service ) && ! empty( $service['active'] ) && ! empty( $service['public_booking'] ) ? $service : [];
	}
	
	private function get_available_gateways(): array {
		$payment_methods = get_option( 'nooshika_landing_payment_method', 'WC_ZPal' );
		$payment_methods = array_filter(
			array_map(
				'trim',
				explode( ',', (string) $payment_methods )
			)
		);
		
		if (
			empty( $payment_methods ) ||
			! function_exists( 'WC' ) ||
			! WC() ||
			! WC()->payment_gateways()
		) {
			return [];
		}
		
		$available_gateways = WC()->payment_gateways()->payment_gateways();
		$gateways           = [];
		
		foreach ( $available_gateways as $gateway ) {
			$payment_method = (string) $gateway->id;
			
			if ( ! in_array( $payment_method, $payment_methods, TRUE ) ) {
				continue;
			}
			
			$gateways[ $payment_method ] = $gateway;
		}
		
		return $gateways;
	}
	
	private function send_otp( string $phone ): mixed {
		$phone = $this->normalize_phone( $phone );
		if ( $phone === '' ) {
			return new WP_Error( 'kerp_public_invalid_phone', __( 'شماره موبایل معتبر نیست.', 'kasebi-erp' ) );
		}
		$existing = get_transient( 'otp_' . $phone );
		if ( is_array( $existing ) && (int) ( $existing['created'] ?? 0 ) + 10 > time() ) {
			return new WP_Error( 'kerp_public_otp_wait', __( 'برای ارسال دوباره کد، کمی صبر کنید.', 'kasebi-erp' ) );
		}
		$otp = (string) random_int( 1000, 9999 );
		set_transient( 'otp_' . $phone, [
			'otp'     => $otp,
			'created' => time(),
			'user_id' => function_exists( 'get_user_id_by_phone' ) ? absint( get_user_id_by_phone( $phone ) ) : 0,
		], 180 );
		if ( class_exists( 'KSP_Modules_Sms_Module' ) && method_exists( 'KSP_Modules_Sms_Module', 'send_otp' ) ) {
			$result = KSP_Modules_Sms_Module::send_otp( $phone, $otp );
			
			return is_wp_error( $result ) ? $result : TRUE;
		}
		if ( class_exists( 'kasebiSMS' ) ) {
			$result = ( new kasebiSMS() )->send_otp_sms( $phone, $otp );
			
			return is_wp_error( $result ) ? $result : TRUE;
		}
		
		return new WP_Error( 'kerp_public_otp_provider_missing', __( 'سرویس ارسال کد تایید در دسترس نیست.', 'kasebi-erp' ) );
	}
	
	private function normalize_phone( string $phone ): string {
		$phone = sanitize_text_field( $phone );
		if ( function_exists( 'nooshika_sanitize_numbers' ) ) {
			$phone = nooshika_sanitize_numbers( $phone );
		}
		if ( function_exists( 'remove_zero_from_phone' ) ) {
			$phone = remove_zero_from_phone( $phone );
		} else {
			$phone = preg_replace( '/\D+/', '', $phone ) ?? '';
			$phone = ltrim( $phone, '0' );
		}
		
		return sanitize_text_field( $phone );
	}
	
	private function get_current_customer_values( array $custom_fields ): array {
		$data = [
			'first_name'      => '',
			'last_name'       => '',
			'phone'           => '',
			'secondary_phone' => '',
			'custom_fields'   => [],
		];
		if ( ! is_user_logged_in() ) {
			return $data;
		}
		$user                    = wp_get_current_user();
		$data['first_name']      = (string) $user->first_name;
		$data['last_name']       = (string) $user->last_name;
		$phone_key               = class_exists( 'KERP_Modules_Customers_Settings' )
			? sanitize_key( (string) KERP_Modules_Customers_Settings::instance()
			                                                        ->get( 'phone_meta_key', 'nooshika_phone_num' ) )
			: 'nooshika_phone_num';
		$data['phone']           = sanitize_text_field( (string) get_user_meta( $user->ID, $phone_key, TRUE ) );
		$data['secondary_phone'] = sanitize_text_field( (string) get_user_meta( $user->ID, apply_filters( 'kerp_appointments_secondary_phone_meta_key', 'kerp_secondary_phone' ), TRUE ) );
		foreach ( $custom_fields as $field_key => $field ) {
			$meta_key                            = sanitize_key( (string) ( $field['meta_key'] ?? $field_key ) );
			$data['custom_fields'][ $field_key ] = $meta_key !== '' ? get_user_meta( $user->ID, $meta_key, TRUE ) : '';
		}
		
		return $data;
	}
	
	private function get_receipt_context(): array {
		$appointment_id = absint( $_GET['kerp_appointment_receipt'] ?? 0 );
		if ( $appointment_id <= 0 ) {
			return [];
		}
		$appointment = KERP_Modules_Appointments_Query::instance()->get_by_id( $appointment_id );
		if ( empty( $appointment ) ) {
			return [];
		}
		$order    = NULL;
		$order_id = absint( $appointment['order_id'] ?? 0 );
		if ( $order_id > 0 ) {
			$order = wc_get_order( $order_id );
			$key   = sanitize_text_field( wp_unslash( $_GET['key'] ?? '' ) );
			if ( ! $order instanceof WC_Order || $key === '' || ! hash_equals( $order->get_order_key(), $key ) ) {
				return [];
			}
		} elseif ( is_user_logged_in() && absint( $appointment['customer_id'] ?? 0 ) !== get_current_user_id() ) {
			return [];
		}
		
		return [
			'appointment' => $appointment,
			'order'       => $order,
			'settings'    => KERP_Modules_Appointments_Settings::instance(),
		];
	}
	
	private function build_receipt_url( string $base_url, int $appointment_id, string $order_key ): string {
		$args = [ 'kerp_appointment_receipt' => absint( $appointment_id ) ];
		if ( $order_key !== '' ) {
			$args['key'] = $order_key;
		}
		
		return add_query_arg( $args, $base_url !== '' ? $base_url : home_url( '/' ) );
	}
	
	private function pending_key( string $phone ): string {
		return self::PENDING_PREFIX . md5( $phone );
	}
	
	private function post_text( string $key ): string {
		return isset( $_POST[ $key ] ) ? sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) : '';
	}
	
	private function verify_public_nonce(): void {
		$nonce = $this->post_text( 'nonce' );
		if ( $nonce === '' || ! wp_verify_nonce( $nonce, 'ksp_ajax_nonce' ) ) {
			$this->json_error( __( 'اعتبار درخواست منقضی شده است. صفحه را تازه کنید.', 'kasebi-erp' ) );
		}
	}
	
	private function json_success( array $data = [] ): void {
		wp_send_json( array_merge( [ 'status' => 'success' ], $data ) );
	}
	
	private function json_error( string $message ): void {
		wp_send_json( [ 'status' => 'error', 'msg' => $message ] );
	}
	
	private function current_page_has_public_shortcode(): bool {
		if ( ! is_singular() ) {
			return FALSE;
		}
		$post = get_post();
		if ( ! $post instanceof WP_Post ) {
			return FALSE;
		}
		if ( is_page( 'panel' ) ) {
			return TRUE;
		}
		
		return has_shortcode( $post->post_content, self::BOOKING_SHORTCODE ) || has_shortcode( $post->post_content, self::HISTORY_SHORTCODE );
	}
	
	private function is_receipt_request(): bool {
		return absint( $_GET['kerp_appointment_receipt'] ?? 0 ) > 0;
	}
	

	public function register_panel_navigation_settings( array $rows ): array {
		return KERP_Settings_Panel_Navigation::register_entries( $rows, 'appointments', 'نوبت‌ها', $this->register_panel_pages( [] ) );
	}
}
