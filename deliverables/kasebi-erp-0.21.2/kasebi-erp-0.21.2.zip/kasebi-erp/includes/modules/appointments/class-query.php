<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Appointments_Query {
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public function find( array $args = [] ): array {
		global $wpdb;
		$appointments = KERP_Modules_Appointments_Installer::instance()->appointments_table();
		$services     = KERP_Modules_Appointments_Installer::instance()->services_table();
		$args         = wp_parse_args( $args, [
			'customer_id'   => 0,
			'service_id'    => 0,
			'employee_id'   => 0,
			'status'        => '',
			'source'        => '',
			'search'        => '',
			'date_from'     => '',
			'date_to'       => '',
			'public_fields' => [],
			'page_number'   => 1,
			'per_page'      => 20,
			'order'         => 'ASC',
			'enforce_scope' => TRUE,
		] );
		$where        = [ '1=1' ];
		$params       = [];
		if ( absint( $args['customer_id'] ) > 0 ) {
			$where[]  = 'a.customer_id = %d';
			$params[] = absint( $args['customer_id'] );
		}
		if ( absint( $args['service_id'] ) > 0 ) {
			$where[]  = 'a.service_id = %d';
			$params[] = absint( $args['service_id'] );
		}
		if ( absint( $args['employee_id'] ) > 0 ) {
			$where[]  = 'a.employee_id = %d';
			$params[] = absint( $args['employee_id'] );
		}
		$status = sanitize_key( (string) $args['status'] );
		if ( $status !== '' ) {
			$where[]  = 'a.status = %s';
			$params[] = $status;
		}
		$source = sanitize_key( (string) $args['source'] );
		if ( $source !== '' ) {
			$where[]  = 'a.source = %s';
			$params[] = $source;
		}
		$date_from = KERP_Modules_Appointments_Form::instance()->normalize_date( (string) $args['date_from'] );
		$date_to   = KERP_Modules_Appointments_Form::instance()->normalize_date( (string) $args['date_to'] );
		if ( $date_from !== '' ) {
			$where[]  = 'a.start_at >= %s';
			$params[] = $date_from . ' 00:00:00';
		}
		if ( $date_to !== '' ) {
			$where[]  = 'a.start_at <= %s';
			$params[] = $date_to . ' 23:59:59';
		}
		$search = sanitize_text_field( (string) $args['search'] );
		if ( $search !== '' ) {
			$like     = '%' . $wpdb->esc_like( $search ) . '%';
			$where[]  = '(a.customer_name LIKE %s OR a.customer_phone LIKE %s OR a.description LIKE %s OR s.title LIKE %s)';
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
		}
		if ( ! empty( $args['enforce_scope'] ) && function_exists( 'kerp_list_scope' ) && kerp_list_scope( 'appointments' ) === 'own' ) {
			$where[]  = 'a.employee_id = %d';
			$params[] = get_current_user_id();
		}
		$definitions = KERP_Modules_Appointments_Public_Fields::instance()->get_filterable_fields();
		foreach ( (array) $args['public_fields'] as $key => $value ) {
			if ( ! isset( $definitions[ $key ] ) || ! is_scalar( $value ) || (string) $value === '' ) {
				continue;
			}
			$value = sanitize_text_field( (string) $value );
			if ( ! array_key_exists( $value, (array) $definitions[ $key ]['options'] ) ) {
				$where[] = '1=0';
				continue;
			}
			// Guard legacy empty/invalid JSON; match exact scalar or multi-choice membership.
			$path = '$.customer_fields.' . wp_json_encode( (string) $key );
			$extract = "JSON_EXTRACT(CASE WHEN JSON_VALID(a.metadata) THEN a.metadata ELSE '{}' END, %s)";
			$where[] = "(JSON_UNQUOTE({$extract}) = %s OR JSON_CONTAINS({$extract}, %s))";
			array_push( $params, $path, $value, $path, wp_json_encode( $value ) );
		}
		$where_sql   = implode( ' AND ', $where );
		$page_number = max( 1, absint( $args['page_number'] ) );
		$per_page    = max( 1, min( 200, absint( $args['per_page'] ) ) );
		$offset      = ( $page_number - 1 ) * $per_page;
		$order       = strtoupper( sanitize_key( (string) $args['order'] ) ) === 'DESC' ? 'DESC' : 'ASC';
		$count_sql   = "SELECT COUNT(*) FROM {$appointments} a LEFT JOIN {$services} s ON s.id = a.service_id WHERE {$where_sql}";
		$list_sql    = "SELECT a.*, s.title AS service_title, s.icon AS service_icon, s.color AS service_color, s.duration_min AS service_duration FROM {$appointments} a LEFT JOIN {$services} s ON s.id = a.service_id WHERE {$where_sql} ORDER BY a.start_at {$order}, a.id {$order} LIMIT %d OFFSET %d";
		$count_query = empty( $params ) ? $count_sql : $wpdb->prepare( $count_sql, $params );
		$total       = (int) $wpdb->get_var( $count_query );
		$list_params = array_merge( $params, [ $per_page, $offset ] );
		$rows        = $wpdb->get_results( $wpdb->prepare( $list_sql, $list_params ), ARRAY_A );
		$items       = is_array( $rows ) ? array_map( [ $this, 'hydrate' ], $rows ) : [];
		
		return [
			'items'       => $items,
			'total'       => $total,
			'page_number' => $page_number,
			'per_page'    => $per_page,
			'total_pages' => max( 1, (int) ceil( $total / $per_page ) ),
		];
	}
	
	public function get_by_id( int $appointment_id ): array {
		global $wpdb;
		$appointments = KERP_Modules_Appointments_Installer::instance()->appointments_table();
		$services     = KERP_Modules_Appointments_Installer::instance()->services_table();
		$row          = $wpdb->get_row( $wpdb->prepare(
			"SELECT a.*, s.title AS service_title, s.icon AS service_icon, s.color AS service_color, s.duration_min AS service_duration FROM {$appointments} a LEFT JOIN {$services} s ON s.id = a.service_id WHERE a.id = %d LIMIT 1",
			absint( $appointment_id )
		), ARRAY_A );
		
		return is_array( $row ) ? $this->hydrate( $row ) : [];
	}
	
	public function get_range( string $from, string $to, array $args = [] ): array {
		$args['date_from']   = $from;
		$args['date_to']     = $to;
		$args['per_page']    = 500;
		$args['page_number'] = 1;
		
		return (array) ( $this->find( $args )['items'] ?? [] );
	}
	
	public function get_counts(): array {
		global $wpdb;
		$table  = KERP_Modules_Appointments_Installer::instance()->appointments_table();
		$where  = '1=1';
		$params = [];
		if ( function_exists( 'kerp_list_scope' ) && kerp_list_scope( 'appointments' ) === 'own' ) {
			$where    .= ' AND employee_id = %d';
			$params[] = get_current_user_id();
		}
		$sql    = "SELECT status, COUNT(*) AS total FROM {$table} WHERE {$where} GROUP BY status";
		$rows   = empty( $params ) ? $wpdb->get_results( $sql, ARRAY_A ) : $wpdb->get_results( $wpdb->prepare( $sql, $params ), ARRAY_A );
		$counts = [];
		foreach ( (array) $rows as $row ) {
			$counts[ sanitize_key( (string) ( $row['status'] ?? '' ) ) ] = absint( $row['total'] ?? 0 );
		}
		
		return $counts;
	}
	
	public function count_by_status( string $status ): int {
		global $wpdb;
		$table = KERP_Modules_Appointments_Installer::instance()->appointments_table();
		
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE status = %s", sanitize_key( $status ) ) );
	}
	
	public function replace_status( string $from, string $to ): void {
		global $wpdb;
		$wpdb->update(
			KERP_Modules_Appointments_Installer::instance()->appointments_table(),
			[
				'status'     => sanitize_key( $to ),
				'updated_at' => current_time( 'mysql' ),
				'updated_by' => get_current_user_id(),
			],
			[ 'status' => sanitize_key( $from ) ]
		);
	}
	
	public function get_busy_quantity( int $employee_id, string $start_at, string $end_at, int $exclude_id = 0 ): int {
		global $wpdb;
		$table        = KERP_Modules_Appointments_Installer::instance()->appointments_table();
		$blocking     = [ 'held', 'pending_payment', 'pending', 'confirmed', 'completed' ];
		$placeholders = implode( ',', array_fill( 0, count( $blocking ), '%s' ) );
		$sql          = "SELECT COALESCE(SUM(quantity),0) FROM {$table} WHERE employee_id = %d AND status IN ({$placeholders}) AND (status <> 'held' OR hold_until IS NULL OR hold_until >= %s) AND start_at < %s AND end_at > %s";
		$params       = array_merge( [ $employee_id ], $blocking, [ current_time( 'mysql' ), $end_at, $start_at ] );
		if ( $exclude_id > 0 ) {
			$sql      .= ' AND id <> %d';
			$params[] = $exclude_id;
		}
		
		return (int) $wpdb->get_var( $wpdb->prepare( $sql, $params ) );
	}
	
	private function hydrate( array $row ): array {
		foreach (
			[
				'id',
				'customer_id',
				'service_id',
				'employee_id',
				'quantity',
				'order_id',
				'created_by',
				'updated_by',
				'cancelled_by',
			] as $key
		) {
			$row[ $key ] = absint( $row[ $key ] ?? 0 );
		}
		$row['price']          = (float) ( $row['price'] ?? 0 );
		$row['payable_amount'] = (float) ( $row['payable_amount'] ?? 0 );
		$metadata              = json_decode( (string) ( $row['metadata'] ?? '' ), TRUE );
		$row['metadata']       = is_array( $metadata ) ? $metadata : [];
		if ( $row['customer_id'] > 0 && get_userdata( $row['customer_id'] ) instanceof WP_User ) {
			$row['customer_name'] = get_user_name_by_id( $row['customer_id'] );
			$phone_meta           = class_exists( 'KERP_Modules_Customers_Settings' )
				? sanitize_key( (string) KERP_Modules_Customers_Settings::instance()
				                                                        ->get( 'phone_meta_key', 'nooshika_phone_num' ) )
				: 'nooshika_phone_num';
			$current_phone        = sanitize_text_field( (string) get_user_meta( $row['customer_id'], $phone_meta, TRUE ) );
			if ( $current_phone !== '' ) {
				$row['customer_phone'] = $current_phone;
			}
		}
		$row['employee_name'] = $row['employee_id'] > 0 && get_userdata( $row['employee_id'] ) instanceof WP_User
			? get_user_name_by_id( $row['employee_id'] )
			: '';
		
		return $row;
	}
	
	public function count_by_location_type( string $location_type ): int {
		global $wpdb;
		
		$table = KERP_Modules_Appointments_Installer::instance()->appointments_table();
		
		return (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$table} WHERE location_type = %s",
				sanitize_key( $location_type )
			)
		);
	}
	
	public function replace_location_type( string $from, string $to ): void {
		global $wpdb;
		
		$wpdb->update(
			KERP_Modules_Appointments_Installer::instance()->appointments_table(),
			[
				'location_type' => sanitize_key( $to ),
				'updated_at'    => current_time( 'mysql' ),
				'updated_by'    => get_current_user_id(),
			],
			[
				'location_type' => sanitize_key( $from ),
			]
		);
	}
	
}
