<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Appointments_SMS {
	
	private const OPTION_KEY = 'kerp_appointments_sms_rules';
	
	private static ?self $instance = NULL;
	
	private ?kasebiSMS $sms_service = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {
		add_action( 'kerp_appointment_created', [ $this, 'handle_created' ], 20, 2 );
		add_action( 'kerp_appointment_status_changed', [ $this, 'handle_status_changed' ], 20, 3 );
	}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public function service_available(): bool {
		return class_exists( 'kasebiSMS' )
		       && method_exists( 'kasebiSMS', 'send_pattern_sms' );
	}
	
	public function get_rules(): array {
		$rules = get_option( self::OPTION_KEY, [] );
		
		return is_array( $rules ) ? array_values( $rules ) : [];
	}
	
	public function save_rules( array $rules ): void {
		$clean = [];
		
		foreach ( $rules as $rule ) {
			if ( ! is_array( $rule ) ) {
				continue;
			}
			
			$event     = sanitize_key( (string) ( $rule['event'] ?? '' ) );
			$status    = sanitize_key( (string) ( $rule['status'] ?? '' ) );
			$recipient = sanitize_key( (string) ( $rule['recipient'] ?? '' ) );
			$pattern   = sanitize_text_field( (string) ( $rule['pattern'] ?? '' ) );
			$receptor  = sanitize_text_field( (string) ( $rule['receptor'] ?? '' ) );
			$variables = sanitize_textarea_field( (string) ( $rule['variables'] ?? '' ) );
			
			/* ردیف خالی انتهای Repeater ذخیره نشود. */
			if ( $event === '' && $recipient === '' && $pattern === '' && $receptor === '' && $variables === '' ) {
				continue;
			}
			
			if ( ! isset( $this->get_action_options()[ $event ] ) ) {
				continue;
			}
			
			if ( ! isset( $this->get_recipient_options()[ $recipient ] ) ) {
				continue;
			}
			
			$clean[] = [
				'enabled'   => ! empty( $rule['enabled'] ) ? '1' : '0',
				'event'     => $event,
				'status'    => $status,
				'recipient' => $recipient,
				'receptor'  => $receptor,
				'pattern'   => $pattern,
				'variables' => $variables,
			];
		}
		
		update_option( self::OPTION_KEY, $clean, FALSE );
	}
	
	public function get_action_options(): array {
		$settings = KERP_Modules_Appointments_Settings::instance();
		$options  = [
			'created'        => sprintf( __( 'پس از ثبت %s با هر وضعیت', 'kasebi-erp' ), $settings->get_appointment_singular_label() ),
			'status_changed' => sprintf( __( 'پس از هر تغییر وضعیت %s', 'kasebi-erp' ), $settings->get_appointment_singular_label() ),
		];
		
		foreach ( $settings->get_statuses( FALSE ) as $status_key => $status ) {
			$status_key = sanitize_key( (string) $status_key );
			$label      = (string) ( $status['label'] ?? $status_key );
			
			$options[ 'created_status_' . $status_key ] = sprintf(
				__( 'پس از ثبت %1$s با وضعیت «%2$s»', 'kasebi-erp' ),
				$settings->get_appointment_singular_label(),
				$label
			);
			
			$options[ 'status_changed_' . $status_key ] = sprintf(
				__( 'پس از تغییر وضعیت %1$s به «%2$s»', 'kasebi-erp' ),
				$settings->get_appointment_singular_label(),
				$label
			);
		}
		
		return $options;
	}
	
	public function get_recipient_options(): array {
		$settings                = KERP_Modules_Appointments_Settings::instance();
		$customer_singular_label = KERP_Modules_Customers_Settings::instance()->get_singular_label();
		
		return [
			'customer' => $customer_singular_label,
			'employee' => $settings->get_provider_singular_label(),
			'custom'   => __( 'شماره دلخواه', 'kasebi-erp' ),
		];
	}
	
	public function get_available_variables(): array {
		$customer_singular_label = KERP_Modules_Customers_Settings::instance()->get_singular_label();

		return [
			'{appointment_id}'         => __( 'شناسه نوبت', 'kasebi-erp' ),
			'{appointment_date}'       => __( 'تاریخ نوبت', 'kasebi-erp' ),
			'{appointment_time}'       => __( 'ساعت نوبت', 'kasebi-erp' ),
			'{appointment_datetime}'   => __( 'تاریخ و ساعت نوبت', 'kasebi-erp' ),
			'{appointment_status}'     => __( 'عنوان وضعیت نوبت', 'kasebi-erp' ),
			'{appointment_status_key}' => __( 'کلید وضعیت نوبت', 'kasebi-erp' ),
			'{customer_id}'            => sprintf( __( 'شناسه %s', 'kasebi-erp' ), $customer_singular_label ),
			'{customer_name}'          => sprintf( __( 'نام کامل %s', 'kasebi-erp' ), $customer_singular_label ),
			'{first_name}'             => sprintf( __( 'نام %s', 'kasebi-erp' ), $customer_singular_label ),
			'{last_name}'              => sprintf( __( 'نام خانوادگی %s', 'kasebi-erp' ), $customer_singular_label ),
			'{customer_phone}'         => sprintf( __( 'شماره موبایل %s', 'kasebi-erp' ), $customer_singular_label ),
			'{employee_id}'            => __( 'شناسه کارشناس', 'kasebi-erp' ),
			'{employee_name}'          => __( 'نام کارشناس', 'kasebi-erp' ),
			'{employee_phone}'         => __( 'شماره موبایل کارشناس', 'kasebi-erp' ),
			'{service_id}'             => __( 'شناسه خدمت', 'kasebi-erp' ),
			'{service_title}'          => __( 'عنوان خدمت', 'kasebi-erp' ),
			'{location_type}'          => __( 'نوع برگزاری', 'kasebi-erp' ),
			'{location}'               => __( 'محل برگزاری', 'kasebi-erp' ),
			'{price}'                  => __( 'قیمت', 'kasebi-erp' ),
			'{payable_amount}'         => __( 'مبلغ قابل پرداخت', 'kasebi-erp' ),
			'{order_id}'               => __( 'شناسه سفارش', 'kasebi-erp' ),
			'{site_name}'              => __( 'نام سایت', 'kasebi-erp' ),
		];
	}
	
	public function handle_created( array $appointment, array $existing = [] ): void {
		if ( empty( $appointment ) ) {
			return;
		}
		
		$status = sanitize_key(
			(string) ( $appointment['status'] ?? '' )
		);
		
		$this->send_for_event(
			'created',
			$appointment,
			$status
		);
	}
	
	public function handle_status_changed(
		array $appointment,
		string $old_status,
		string $new_status
	): void {
		if ( empty( $appointment ) ) {
			return;
		}
		
		$new_status = sanitize_key( $new_status );
		if ( $new_status === '' ) {
			return;
		}
		
		$this->send_for_event(
			'status_changed',
			$appointment,
			$new_status
		);
	}
	
	private function send_for_event(
		string $event,
		array $appointment,
		string $status = ''
	): void {
		if ( ! $this->service_available() ) {
			return;
		}
		
		$event  = sanitize_key( $event );
		$status = sanitize_key( $status );
		
		foreach ( $this->get_rules() as $rule ) {
			/*
			 * بررسی نوع اکشن:
			 *
			 * created
			 * status_changed
			 */
			$rule_event = sanitize_key(
				(string) ( $rule['event'] ?? '' )
			);
			
			if ( $rule_event !== $event ) {
				continue;
			}
			
			/*
			 * بررسی وضعیت نوبت.
			 *
			 * اگر status قانون خالی باشد،
			 * قانون برای همه وضعیت‌ها اجرا می‌شود.
			 */
			$rule_status = sanitize_key(
				(string) ( $rule['status'] ?? '' )
			);
			
			if (
				$rule_status !== ''
				&& $rule_status !== $status
			) {
				continue;
			}
			
			$this->send_rule( $rule, $appointment );
		}
	}
	
	private function send_rule( array $rule, array $appointment ): void {
		$pattern = trim( (string) ( $rule['pattern'] ?? '' ) );
		if ( $pattern === '' ) {
			return;
		}
		
		$service = $this->sms_service();
		if ( ! $service ) {
			return;
		}
		
		$recipients = $this->get_recipient_numbers( $rule, $appointment );
		if ( empty( $recipients ) ) {
			return;
		}
		
		$context   = $this->build_context( $appointment );
		$variables = $this->parse_variables( (string) ( $rule['variables'] ?? '' ) );
		$data      = [];
		
		foreach ( $variables as $name => $template ) {
			if ( in_array( strtolower( $name ), [ 'receptor', 'pattern' ], TRUE ) ) {
				continue;
			}
			
			$value         = strtr( $template, $context );
			$data[ $name ] = $this->sanitize_pattern_value( $value );
		}
		
		foreach ( $recipients as $phone ) {
			$payload = [
				           'receptor' => $phone,
				           'pattern'  => $pattern,
			           ] + $data;
			
			$response = $service->send_pattern_sms( $payload );
			
			do_action(
				'kerp_appointments_sms_sent',
				$response,
				$payload,
				$rule,
				$appointment
			);
		}
	}
	
	private function sms_service(): ?kasebiSMS {
		if ( $this->sms_service instanceof kasebiSMS ) {
			return $this->sms_service;
		}
		
		if ( ! $this->service_available() ) {
			return NULL;
		}
		
		$this->sms_service = new kasebiSMS();
		
		return $this->sms_service;
	}
	
	private function parse_variables( string $value ): array {
		$output = [];
		$items  = preg_split( '/\s*;\s*/u', trim( $value ), - 1, PREG_SPLIT_NO_EMPTY );
		
		if ( ! is_array( $items ) ) {
			return $output;
		}
		
		foreach ( $items as $item ) {
			$position = strpos( $item, ':' );
			
			/* برای سازگاری با تنظیمات قدیمی، = هم پذیرفته می‌شود. */
			if ( $position === FALSE ) {
				$position = strpos( $item, '=' );
			}
			
			if ( $position === FALSE ) {
				continue;
			}
			
			$name     = trim( substr( $item, 0, $position ) );
			$template = trim( substr( $item, $position + 1 ) );
			$name     = preg_replace( '/[^A-Za-z0-9_-]/', '', $name ) ?? '';
			
			if ( $name === '' ) {
				continue;
			}
			
			$output[ $name ] = $template;
		}
		
		return $output;
	}
	
	private function build_context( array $appointment ): array {
		$settings       = KERP_Modules_Appointments_Settings::instance();
		$appointment_id = absint( $appointment['id'] ?? 0 );
		$customer_id    = absint( $appointment['customer_id'] ?? 0 );
		$employee_id    = absint( $appointment['employee_id'] ?? 0 );
		$service_id     = absint( $appointment['service_id'] ?? 0 );
		$order_id       = absint( $appointment['order_id'] ?? 0 );
		$status_key     = sanitize_key( (string) ( $appointment['status'] ?? '' ) );
		$status         = $settings->get_status( $status_key );
		$status_label   = (string) ( $status['label'] ?? $status_key );
		$start_at       = (string) ( $appointment['start_at'] ?? '' );
		$date_mysql     = substr( $start_at, 0, 10 );
		$time           = strlen( $start_at ) >= 16 ? substr( $start_at, 11, 5 ) : '';
		$date           = $date_mysql !== ''
			? KERP_Modules_Appointments_Form::instance()->to_display_date( $date_mysql )
			: '';
		
		$customer_name = trim( (string) ( $appointment['customer_name'] ?? '' ) );
		if ( $customer_id > 0 && function_exists( 'get_user_name_by_id' ) ) {
			$resolved_customer_name = trim( (string) get_user_name_by_id( $customer_id ) );
			if ( $resolved_customer_name !== '' ) {
				$customer_name = $resolved_customer_name;
			}
		}
		
		$first_name = $customer_id > 0
			? trim( (string) get_user_meta( $customer_id, 'first_name', TRUE ) )
			: '';
		$last_name  = $customer_id > 0
			? trim( (string) get_user_meta( $customer_id, 'last_name', TRUE ) )
			: '';
		
		if ( $first_name === '' && $customer_name !== '' ) {
			$name_parts = preg_split( '/\s+/u', $customer_name, 2 );
			$first_name = (string) ( $name_parts[0] ?? '' );
			$last_name  = $last_name !== '' ? $last_name : (string) ( $name_parts[1] ?? '' );
		}
		
		$employee_name = '';
		if ( $employee_id > 0 && function_exists( 'get_user_name_by_id' ) ) {
			$employee_name = trim( (string) get_user_name_by_id( $employee_id ) );
		}
		
		$employee_phone = $this->get_user_phone( $employee_id );
		$customer_phone = $this->normalize_phone( (string) ( $appointment['customer_phone'] ?? '' ) );
		if ( $customer_phone === '' ) {
			$customer_phone = $this->get_user_phone( $customer_id );
		}
		
		$location_type_key = sanitize_key( (string) ( $appointment['location_type'] ?? '' ) );
		$location_type     = $settings->get_location_type( $location_type_key );
		$location_label    = (string) ( $location_type['label'] ?? $location_type_key );
		
		return [
			'{appointment_id}'         => (string) $appointment_id,
			'{appointment_date}'       => $date,
			'{appointment_time}'       => $time,
			'{appointment_datetime}'   => trim( $date . ' ' . $time ),
			'{appointment_status}'     => $status_label,
			'{appointment_status_key}' => $status_key,
			'{customer_id}'            => (string) $customer_id,
			'{customer_name}'          => $customer_name,
			'{first_name}'             => $first_name,
			'{last_name}'              => $last_name,
			'{customer_phone}'         => $customer_phone,
			'{employee_id}'            => (string) $employee_id,
			'{employee_name}'          => $employee_name,
			'{employee_phone}'         => $employee_phone,
			'{service_id}'             => (string) $service_id,
			'{service_title}'          => trim( (string) ( $appointment['service_title'] ?? '' ) ),
			'{location_type}'          => $location_label,
			'{location}'               => trim( (string) ( $appointment['location'] ?? '' ) ),
			'{price}'                  => $this->normalize_amount( $appointment['price'] ?? 0 ),
			'{payable_amount}'         => $this->normalize_amount( $appointment['payable_amount'] ?? 0 ),
			'{order_id}'               => (string) $order_id,
			'{site_name}'              => (string) get_bloginfo( 'name' ),
		];
	}
	
	private function get_recipient_numbers( array $rule, array $appointment ): array {
		$recipient = sanitize_key( (string) ( $rule['recipient'] ?? '' ) );
		$numbers   = [];
		
		switch ( $recipient ) {
			case 'customer':
				$phone = $this->normalize_phone( (string) ( $appointment['customer_phone'] ?? '' ) );
				if ( $phone === '' ) {
					$phone = $this->get_user_phone( absint( $appointment['customer_id'] ?? 0 ) );
				}
				$numbers[] = $phone;
				break;
			
			case 'employee':
				$numbers[] = $this->get_user_phone( absint( $appointment['employee_id'] ?? 0 ) );
				break;
			
			case 'custom':
				$numbers = array_map(
					[ $this, 'normalize_phone' ],
					explode( ',', (string) ( $rule['receptor'] ?? '' ) )
				);
				break;
		}
		
		return array_values(
			array_unique(
				array_filter( $numbers )
			)
		);
	}
	
	private function get_user_phone( int $user_id ): string {
		if ( $user_id <= 0 ) {
			return '';
		}
		
		if ( class_exists( 'KERP_Modules_Employees_Query' ) ) {
			$phone = KERP_Modules_Employees_Query::instance()->get_phone( $user_id );
			$phone = $this->normalize_phone( (string) $phone );
			if ( $phone !== '' ) {
				return $phone;
			}
		}
		
		foreach ( [ 'nooshika_phone_num', 'billing_phone' ] as $meta_key ) {
			$phone = $this->normalize_phone( (string) get_user_meta( $user_id, $meta_key, TRUE ) );
			if ( $phone !== '' ) {
				return $phone;
			}
		}
		
		return '';
	}
	
	private function normalize_phone( string $raw ): string {
		if ( function_exists( 'nooshika_sanitize_numbers' ) ) {
			$raw = (string) nooshika_sanitize_numbers( $raw );
		}
		
		if ( function_exists( 'remove_zero_from_phone' ) ) {
			return trim( (string) remove_zero_from_phone( $raw ) );
		}
		
		$digits = preg_replace( '/\D+/', '', $raw ) ?? '';
		
		if ( preg_match( '/^(0098|098|98)(\d{10})$/', $digits, $match ) ) {
			return $match[2];
		}
		
		if ( preg_match( '/^0(\d{10})$/', $digits, $match ) ) {
			return $match[1];
		}
		
		return $digits;
	}
	
	private function sanitize_pattern_value( mixed $value ): string {
		$value = is_scalar( $value ) ? (string) $value : '';
		$value = sanitize_text_field( $value );
		$value = str_replace( ' ', '-', $value );
		$value = str_replace( '_', '-', $value );
		
		return (string) apply_filters( 'kerp_appointments_sms_pattern_value', $value );
	}
	
	private function normalize_amount( mixed $value ): string {
		if ( ! is_numeric( $value ) ) {
			return '0';
		}
		
		$value = (float) $value;
		
		if ( floor( $value ) === $value ) {
			return (string) (int) $value;
		}
		
		return rtrim( rtrim( number_format( $value, 6, '.', '' ), '0' ), '.' );
	}
	
}
