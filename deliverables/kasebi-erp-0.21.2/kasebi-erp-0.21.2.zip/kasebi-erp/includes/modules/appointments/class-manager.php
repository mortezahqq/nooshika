<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Appointments_Manager {
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public function save( array $data, int $appointment_id = 0 ): int|WP_Error {
		global $wpdb;
		$table          = KERP_Modules_Appointments_Installer::instance()->appointments_table();
		$appointment_id = absint( $appointment_id );
		$existing       = $appointment_id > 0 ? KERP_Modules_Appointments_Query::instance()
		                                                                       ->get_by_id( $appointment_id ) : [];
		if ( $appointment_id > 0 && empty( $existing ) ) {
			return new WP_Error( 'kerp_appointments_not_found', sprintf( __( '%s پیدا نشد.', 'kasebi-erp' ), KERP_Modules_Appointments_Settings::instance()
			                                                                                                                                   ->get_appointment_singular_label() ) );
		}
		$service_id  = absint( $data['service_id'] ?? 0 );
		$employee_id = absint( $data['employee_id'] ?? 0 );
		$customer_id = absint( $data['customer_id'] ?? 0 );
		$quantity    = max( 1, absint( $data['quantity'] ?? 1 ) );
		$service     = KERP_Modules_Appointments_Services::instance()->get( $service_id );
		if ( empty( $service ) || empty( $service['active'] ) ) {
			return new WP_Error( 'kerp_appointments_invalid_service', sprintf( __( '%s معتبر نیست.', 'kasebi-erp' ), KERP_Modules_Appointments_Settings::instance()
			                                                                                                                                           ->get_service_singular_label() ) );
		}
		$employee_options = KERP_Modules_Appointments_Form::instance()->get_employee_options_for_service(
			$service_id,
			FALSE
		);
		
		if ( $employee_id <= 0 || ! isset( $employee_options[ $employee_id ] ) ) {
			return new WP_Error(
				'kerp_appointments_invalid_employee',
				sprintf(
					__( '%1$s برای این %2$s معتبر نیست.', 'kasebi-erp' ),
					KERP_Modules_Appointments_Settings::instance()->get_provider_singular_label(),
					KERP_Modules_Appointments_Settings::instance()->get_service_singular_label()
				)
			);
		}
		if ( $customer_id <= 0 || ! get_userdata( $customer_id ) instanceof WP_User ) {
			$customer_singular_label = KERP_Modules_Customers_Settings::instance()->get_singular_label();
			
			return new WP_Error(
				'kerp_appointments_invalid_customer',
				sprintf(
					__( '%s معتبر نیست.', 'kasebi-erp' ),
					$customer_singular_label
				)
			);
		}
		$start_at = (string) ( $data['start_at'] ?? '' );
		if ( $start_at === '' ) {
			$combined = KERP_Modules_Appointments_Form::instance()->combine_datetime(
				(string) ( $data['date'] ?? '' ),
				(string) ( $data['time'] ?? '' )
			);
			if ( is_wp_error( $combined ) ) {
				return $combined;
			}
			$start_at = $combined;
		}
		$start_timestamp = strtotime( $start_at );
		if ( $start_timestamp === FALSE ) {
			return new WP_Error( 'kerp_appointments_invalid_start', sprintf( __( 'زمان شروع %s معتبر نیست.', 'kasebi-erp' ), KERP_Modules_Appointments_Settings::instance()
			                                                                                                                                                   ->get_appointment_singular_label() ) );
		}
		$end_at = date(
			'Y-m-d H:i:s',
			$start_timestamp + max( 5, absint( $service['duration_min'] ?? 30 ) ) * MINUTE_IN_SECONDS
		);
		// Keep existing records editable when their date falls outside a newly configured window.
		$unchanged_outside_window = ! empty( $existing )
			&& ! KERP_Modules_Appointments_Settings::instance()->is_booking_date_active( substr( $start_at, 0, 10 ) )
			&& $start_at === (string) $existing['start_at']
			&& $service_id === (int) $existing['service_id']
			&& $employee_id === (int) $existing['employee_id']
			&& $quantity <= (int) $existing['quantity'];
		if ( ! $unchanged_outside_window && ! KERP_Modules_Appointments_Settings::instance()->is_booking_date_active( substr( $start_at, 0, 10 ) ) ) {
			return new WP_Error( 'kerp_appointments_outside_booking_window', __( 'تاریخ انتخاب‌شده خارج از بازه فعال بودن نوبت‌دهی است.', 'kasebi-erp' ) );
		}
		if ( ! $unchanged_outside_window && ! KERP_Modules_Appointments_Availability::instance()
		                                             ->is_available( $start_at, $service_id, $employee_id, $quantity, $appointment_id ) ) {
			return new WP_Error( 'kerp_appointments_slot_unavailable', __( 'این بازه زمانی دیگر ظرفیت کافی ندارد.', 'kasebi-erp' ) );
		}
		$settings = KERP_Modules_Appointments_Settings::instance();
		$status   = sanitize_key( (string) ( $data['status'] ?? $settings->get( 'default_admin_status', 'confirmed' ) ) );
		if ( empty( $settings->get_status( $status ) ) ) {
			$status = 'confirmed';
		}
		if ( ! empty( $existing ) && ! $settings->can_transition( (string) $existing['status'], $status ) ) {
			return new WP_Error( 'kerp_appointments_invalid_transition', __( 'تغییر وضعیت انتخاب‌شده در گردش فعلی مجاز نیست.', 'kasebi-erp' ) );
		}
		$customer_name  = get_user_name_by_id( $customer_id );
		$phone_meta     = class_exists( 'KERP_Modules_Customers_Settings' )
			? sanitize_key( (string) KERP_Modules_Customers_Settings::instance()
			                                                        ->get( 'phone_meta_key', 'nooshika_phone_num' ) )
			: 'nooshika_phone_num';
		$customer_phone = sanitize_text_field( (string) get_user_meta( $customer_id, $phone_meta, TRUE ) );
		$price          = array_key_exists( 'price', $data ) ? $this->normalize_number( $data['price'] ) : (float) $service['price'];
		$payable_amount = array_key_exists( 'payable_amount', $data )
			? $this->normalize_number( $data['payable_amount'] )
			: KERP_Modules_Appointments_Services::instance()->calculate_payable_amount( $service );
		$now            = current_time( 'mysql' );
		$hold_until     = NULL;
		if ( in_array( $status, [ 'held', 'pending_payment' ], TRUE ) ) {
			$existing_hold_until = trim( (string) ( $existing['hold_until'] ?? '' ) );
			if ( $existing_hold_until !== '' && strtotime( $existing_hold_until ) !== FALSE ) {
				$hold_until = $existing_hold_until;
			} else {
				$hold_until = date(
					'Y-m-d H:i:s',
					current_time( 'timestamp', TRUE ) + max( 1, absint( $settings->get( 'hold_minutes', 15 ) ) ) * MINUTE_IN_SECONDS,
				);
			}
		}
		$location_type = sanitize_key(
			(string) ( $data['location_type'] ?? '' )
		);
		
		if (
			$location_type !== '' &&
			empty( $settings->get_location_type( $location_type ) )
		) {
			return new WP_Error(
				'kerp_appointments_invalid_location_type',
				__( 'نوع برگزاری انتخاب‌شده معتبر نیست.', 'kasebi-erp' )
			);
		}
		$row = [
			'customer_id'    => $customer_id,
			'service_id'     => $service_id,
			'employee_id'    => $employee_id,
			'start_at'       => $start_at,
			'end_at'         => $end_at,
			'status'         => $status,
			'source'         => sanitize_key( (string) ( $data['source'] ?? 'admin' ) ) ?: 'admin',
			'quantity'       => $quantity,
			'order_id'       => absint( $data['order_id'] ?? ( $existing['order_id'] ?? 0 ) ),
			'price'          => max( 0, $price ),
			'payable_amount' => max( 0, $payable_amount ),
			'customer_name'  => sanitize_text_field( $customer_name ),
			'customer_phone' => $customer_phone,
			'location_type'  => $location_type,
			'location'       => sanitize_textarea_field( (string) ( $data['location'] ?? '' ) ),
			'description'    => wp_kses_post( (string) ( $data['description'] ?? '' ) ),
			'internal_note'  => wp_kses_post( (string) ( $data['internal_note'] ?? '' ) ),
			'hold_until'     => $hold_until,
			'updated_by'     => get_current_user_id(),
			'updated_at'     => $now,
			'metadata'       => wp_json_encode( is_array( $data['metadata'] ?? NULL ) ? $data['metadata'] : ( $existing['metadata'] ?? [] ), JSON_UNESCAPED_UNICODE ),
		];
		if ( $status === 'cancelled' && (string) ( $existing['status'] ?? '' ) !== 'cancelled' ) {
			$row['cancelled_by']  = get_current_user_id();
			$row['cancel_reason'] = sanitize_textarea_field( (string) ( $data['cancel_reason'] ?? '' ) );
		}
		if ( $appointment_id > 0 ) {
			if ( $wpdb->update( $table, $row, [ 'id' => $appointment_id ] ) === FALSE ) {
				return new WP_Error( 'kerp_appointments_update_failed', sprintf( __( 'ذخیره %s انجام نشد.', 'kasebi-erp' ), KERP_Modules_Appointments_Settings::instance()
				                                                                                                                                              ->get_appointment_singular_label() ) );
			}
		} else {
			$row['created_by'] = get_current_user_id();
			$row['created_at'] = $now;
			if ( $wpdb->insert( $table, $row ) === FALSE ) {
				return new WP_Error( 'kerp_appointments_insert_failed', sprintf( __( 'ثبت %s انجام نشد.', 'kasebi-erp' ), KERP_Modules_Appointments_Settings::instance()
				                                                                                                                                            ->get_appointment_singular_label() ) );
			}
			$appointment_id = (int) $wpdb->insert_id;
		}
		$appointment = KERP_Modules_Appointments_Query::instance()->get_by_id( $appointment_id );
		do_action( empty( $existing ) ? 'kerp_appointment_created' : 'kerp_appointment_updated', $appointment, $existing );
		if ( ! empty( $existing ) && (string) $existing['status'] !== $status ) {
			do_action( 'kerp_appointment_status_changed', $appointment, (string) $existing['status'], $status );
		}
		
		return $appointment_id;
	}
	
	public function save_note(
		int $appointment_id,
		string $note
	): bool|WP_Error {
		global $wpdb;
		
		$appointment_id = absint(
			$appointment_id
		);
		
		$appointment = KERP_Modules_Appointments_Query::instance()->get_by_id(
			$appointment_id
		);
		
		if ( empty( $appointment ) ) {
			return new WP_Error(
				'kerp_appointments_not_found',
				sprintf( __( '%s پیدا نشد.', 'kasebi-erp' ), KERP_Modules_Appointments_Settings::instance()
				                                                                               ->get_appointment_singular_label() )
			);
		}
		
		$previous_note = (string) (
			$appointment['internal_note'] ?? ''
		);
		
		$result = $wpdb->update(
			KERP_Modules_Appointments_Installer::instance()->appointments_table(),
			[
				'internal_note' => wp_kses_post( $note ),
				'updated_by'    => get_current_user_id(),
				'updated_at'    => current_time( 'mysql' ),
			],
			[
				'id' => $appointment_id,
			]
		);
		
		if ( $result === FALSE ) {
			return new WP_Error(
				'kerp_appointments_note_failed',
				__( 'ذخیره یادداشت انجام نشد.', 'kasebi-erp' )
			);
		}
		
		$current = KERP_Modules_Appointments_Query::instance()->get_by_id(
			$appointment_id
		);
		
		do_action(
			'kerp_appointment_note_updated',
			$current,
			$previous_note
		);
		
		return TRUE;
	}
	
	public function change_status( int $appointment_id, string $status, string $note = '' ): bool|WP_Error {
		global $wpdb;
		$appointment = KERP_Modules_Appointments_Query::instance()->get_by_id( $appointment_id );
		if ( empty( $appointment ) ) {
			return new WP_Error( 'kerp_appointments_not_found', sprintf( __( '%s پیدا نشد.', 'kasebi-erp' ), KERP_Modules_Appointments_Settings::instance()
			                                                                                                                                   ->get_appointment_singular_label() ) );
		}
		$status   = sanitize_key( $status );
		$settings = KERP_Modules_Appointments_Settings::instance();
		if ( empty( $settings->get_status( $status ) ) ) {
			return new WP_Error( 'kerp_appointments_invalid_status', __( 'وضعیت معتبر نیست.', 'kasebi-erp' ) );
		}
		$old_status = sanitize_key( (string) $appointment['status'] );
		if ( ! $settings->can_transition( $old_status, $status ) ) {
			return new WP_Error( 'kerp_appointments_invalid_transition', __( 'این تغییر وضعیت در گردش فعلی مجاز نیست.', 'kasebi-erp' ) );
		}
		$row = [
			'status'     => $status,
			'updated_by' => get_current_user_id(),
			'updated_at' => current_time( 'mysql' ),
			'hold_until' => NULL,
		];
		if ( in_array( $status, [ 'held', 'pending_payment' ], TRUE ) ) {
			$row['hold_until'] = date(
				'Y-m-d H:i:s',
				current_time( 'timestamp', TRUE ) + max( 1, absint( $settings->get( 'hold_minutes', 15 ) ) ) * MINUTE_IN_SECONDS,
			);
		}
		if ( $status === 'cancelled' ) {
			$row['cancelled_by']  = get_current_user_id();
			$row['cancel_reason'] = sanitize_textarea_field( $note );
		}
		if ( $wpdb->update( KERP_Modules_Appointments_Installer::instance()
		                                                       ->appointments_table(), $row, [ 'id' => $appointment_id ] ) === FALSE ) {
			return new WP_Error( 'kerp_appointments_status_failed', __( 'تغییر وضعیت انجام نشد.', 'kasebi-erp' ) );
		}
		$current = KERP_Modules_Appointments_Query::instance()->get_by_id( $appointment_id );
		do_action( 'kerp_appointment_status_changed', $current, $old_status, $status );
		if ( $status === 'cancelled' ) {
			do_action( 'kerp_appointment_cancelled', $current );
		}
		
		return TRUE;
	}
	
	public function delete( int $appointment_id ): bool|WP_Error {
		global $wpdb;
		$appointment = KERP_Modules_Appointments_Query::instance()->get_by_id( $appointment_id );
		if ( empty( $appointment ) ) {
			return new WP_Error( 'kerp_appointments_not_found', sprintf( __( '%s پیدا نشد.', 'kasebi-erp' ), KERP_Modules_Appointments_Settings::instance()
			                                                                                                                                   ->get_appointment_singular_label() ) );
		}
		if ( absint( $appointment['order_id'] ?? 0 ) > 0 ) {
			return new WP_Error( 'kerp_appointments_has_order', sprintf( __( 'این %s به سفارش متصل است؛ به‌جای حذف، وضعیت آن را لغو کنید.', 'kasebi-erp' ), KERP_Modules_Appointments_Settings::instance()
			                                                                                                                                                                                  ->get_appointment_singular_label() ) );
		}
		$deleted = $wpdb->delete( KERP_Modules_Appointments_Installer::instance()
		                                                             ->appointments_table(), [ 'id' => absint( $appointment_id ) ] );
		if ( $deleted === FALSE ) {
			return new WP_Error( 'kerp_appointments_delete_failed', sprintf( __( 'حذف %s انجام نشد.', 'kasebi-erp' ), KERP_Modules_Appointments_Settings::instance()
			                                                                                                                                            ->get_appointment_singular_label() ) );
		}
		do_action( 'kerp_appointment_deleted', $appointment );
		
		return TRUE;
	}
	
	private function normalize_number( mixed $value ): float {
		if ( $value === NULL || is_array( $value ) || is_object( $value ) ) {
			return 0.0;
		}
		$value = trim( (string) $value );
		if ( function_exists( 'nooshika_sanitize_numbers' ) ) {
			$value = nooshika_sanitize_numbers( $value );
		}
		$value = str_replace( '٫', '.', $value );
		$value = str_replace( [ ',', '٬', ' ', "\xc2\xa0" ], '', $value );
		$value = preg_replace( '/[^0-9.\-]/', '', $value );
		
		return is_string( $value ) && is_numeric( $value ) ? (float) $value : 0.0;
	}
	
}
