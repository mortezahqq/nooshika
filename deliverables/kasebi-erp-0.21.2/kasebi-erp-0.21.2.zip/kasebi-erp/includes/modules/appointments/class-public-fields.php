<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Appointments_Public_Fields {
	
	private const OPTION_NAME = 'kerp_appointments_public_fields';
	
	private static ?self $instance = NULL;
	
	private ?array $fields = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {
		add_action( 'update_option_' . self::OPTION_NAME, [ $this, 'clear_cache' ], 10, 0 );
		add_action( 'add_option_' . self::OPTION_NAME, [ $this, 'clear_cache' ], 10, 0 );
	}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public function get_all( bool $active_only = FALSE ): array {
		if ( $this->fields === NULL ) {
			$stored       = get_option( self::OPTION_NAME, [] );
			$this->fields = is_array( $stored ) ? $stored : [];
		}
		
		$fields = $this->fields;
		
		if ( $active_only ) {
			$fields = array_filter(
				$fields,
				static fn( array $field ): bool => ! isset( $field['active'] ) || ! empty( $field['active'] )
			);
		}
		
		$this->sort( $fields );
		
		return apply_filters(
			'kerp_appointments_public_fields',
			$fields,
			$active_only
		);
	}
	
	public function get_form_fields(): array {
		$fields = [];
		
		foreach ( $this->get_all( TRUE ) as $key => $definition ) {
			$fields[ $key ] = [
				'key'         => $key,
				'meta_key'    => $key,
				'label'       => (string) ( $definition['label'] ?? $key ),
				'description' => (string) ( $definition['description'] ?? '' ),
				'type'        => (string) ( $definition['type'] ?? 'text' ),
				'placeholder' => (string) ( $definition['placeholder'] ?? '' ),
				'options'     => (array) ( $definition['options'] ?? [] ),
				'required'    => ! empty( $definition['required'] ),
				'order'       => (int) ( $definition['order'] ?? 100 ),
			];
		}
		
		$this->sort( $fields );
		
		return $fields;
	}

	public function get_filterable_fields(): array {
		return array_filter( $this->get_all(), static fn( array $field ): bool =>
			in_array( $field['type'] ?? '', [ 'select', 'radio', 'multi-select', 'checkbox' ], TRUE ) && ! empty( $field['options'] )
		);
	}

	public function get_filter_values( array $values ): array {
		$result = [];
		foreach ( $this->get_filterable_fields() as $key => $field ) {
			$value = $values[ 'public_field_' . $key ] ?? '';
			if ( is_scalar( $value ) && (string) $value !== '' && (string) $value !== '0' ) {
				$value = (string) $value;
				$result[ $key ] = sanitize_text_field( str_starts_with( $value, 'choice_' ) ? substr( $value, 7 ) : $value );
			}
		}
		return $result;
	}

	public function get_display_values( array $metadata ): array {
		$definitions = $this->get_all();
		$result = [];
		foreach ( (array) ( $metadata['customer_fields'] ?? [] ) as $key => $value ) {
			$field = (array) ( $definitions[ $key ] ?? [] );
			$labels = [];
			foreach ( is_array( $value ) ? $value : [ $value ] as $item ) {
				if ( ! is_scalar( $item ) || (string) $item === '' ) {
					continue;
				}
				$text = (string) ( $field['options'][ (string) $item ] ?? $item );
				if ( ( $field['type'] ?? '' ) === 'date' ) {
					$date = KERP_Modules_Appointments_Form::instance()->normalize_date( $text );
					$text = $date !== '' ? KERP_Helpers_Date::gregorian_to_jalali( $date ) : $text;
				} elseif ( ( $field['type'] ?? '' ) === 'switch' ) {
					$text = (string) $item === '1' ? __( 'بله', 'kasebi-erp' ) : __( 'خیر', 'kasebi-erp' );
				}
				$labels[] = $text;
			}
			if ( $labels !== [] ) {
				$result[] = [ 'label' => (string) ( $field['label'] ?? $key ), 'value' => implode( '، ', $labels ) ];
			}
		}
		return $result;
	}
	
	public function upsert( array $field ): bool {
		$field = $this->sanitize_definition( $field );
		
		if ( $field['key'] === '' ) {
			return FALSE;
		}
		
		$fields                  = $this->get_all();
		$fields[ $field['key'] ] = $field;
		
		$this->sort( $fields );
		
		$result       = update_option( self::OPTION_NAME, $fields, FALSE );
		$this->fields = $fields;
		
		return $result;
	}
	
	public function delete( string $key ): bool {
		$key    = sanitize_key( $key );
		$fields = $this->get_all();
		
		if ( ! isset( $fields[ $key ] ) ) {
			return TRUE;
		}
		
		unset( $fields[ $key ] );
		
		$result       = update_option( self::OPTION_NAME, $fields, FALSE );
		$this->fields = $fields;
		
		return $result;
	}
	
	public function sanitize_value( mixed $value, array $field ): mixed {
		$type = sanitize_key( (string) ( $field['type'] ?? 'text' ) );
		
		if ( is_array( $value ) ) {
			return array_values(
				array_map(
					fn( mixed $item ): mixed => $this->sanitize_value( $item, $field ),
					$value
				)
			);
		}
		
		$value = wp_unslash( (string) $value );
		
		return match ( $type ) {
			'email' => sanitize_email( $value ),
			'number' => $this->sanitize_number( $value ),
			'textarea' => sanitize_textarea_field( $value ),
			'select', 'radio', 'switch' => sanitize_key( $value ),
			'checkbox', 'multi-select' => sanitize_text_field( $value ),
			default => sanitize_text_field( $value ),
		};
	}
	
	private function sanitize_definition( array $field ): array {
		$key  = sanitize_key( (string) ( $field['key'] ?? '' ) );
		$type = sanitize_key( (string) ( $field['type'] ?? 'text' ) );
		
		$allowed_types = [
			'text',
			'email',
			'number',
			'date',
			'textarea',
			'select',
			'radio',
			'checkbox',
			'multi-select',
			'switch',
		];
		
		if ( ! in_array( $type, $allowed_types, TRUE ) ) {
			$type = 'text';
		}
		
		$options = $field['options'] ?? [];
		
		if ( is_string( $options ) ) {
			$rows    = preg_split(
				'/\R+/u',
				trim( $options ),
				- 1,
				PREG_SPLIT_NO_EMPTY
			);
			$options = [];
			
			foreach ( (array) $rows as $row ) {
				$parts = array_map( 'trim', explode( '=', (string) $row, 2 ) );
				
				$option_key   = sanitize_key( (string) ( $parts[0] ?? '' ) );
				$option_label = sanitize_text_field( (string) ( $parts[1] ?? '' ) );
				
				if ( $option_key === '' || $option_label === '' ) {
					continue;
				}
				
				$options[ $option_key ] = $option_label;
			}
		}
		
		$clean_options = [];
		
		foreach ( (array) $options as $option_key => $option_label ) {
			$option_key = sanitize_key( (string) $option_key );
			
			if ( $option_key === '' ) {
				continue;
			}
			
			$clean_options[ $option_key ] = sanitize_text_field( (string) $option_label );
		}
		
		return [
			'key'         => $key,
			'label'       => sanitize_text_field( (string) ( $field['label'] ?? '' ) ),
			'description' => sanitize_textarea_field( (string) ( $field['description'] ?? '' ) ),
			'type'        => $type,
			'placeholder' => sanitize_text_field( (string) ( $field['placeholder'] ?? '' ) ),
			'options'     => $clean_options,
			'required'    => ! empty( $field['required'] ),
			'active'      => ! isset( $field['active'] ) || ! empty( $field['active'] ),
			'order'       => (int) ( $field['order'] ?? 100 ),
		];
	}
	
	private function sanitize_number( string $value ): string {
		if ( function_exists( 'nooshika_sanitize_numbers' ) ) {
			$value = nooshika_sanitize_numbers( $value );
		}
		
		return preg_replace( '/[^0-9.\-]/', '', $value ) ?? '';
	}
	
	private function sort( array &$fields ): void {
		uasort(
			$fields,
			static fn( array $a, array $b ): int => (int) ( $a['order'] ?? 100 ) <=> (int) ( $b['order'] ?? 100 )
		);
	}
	
	public function clear_cache(): void {
		$this->fields = NULL;
	}
	
}
