<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Appointments_Module {
	
	private const DB_VERSION        = '1.0.0';
	
	private const DB_VERSION_OPTION = 'kerp_appointments_db_version';
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {
		$this->load_services();
		$this->maybe_install();
		$this->register_hooks();
	}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	private function load_services(): void {
		KERP_Modules_Appointments_Installer::instance();
		KERP_Modules_Appointments_Settings::instance();
		KERP_Modules_Appointments_SMS::instance();
		KERP_Modules_Appointments_Services::instance();
		KERP_Modules_Appointments_Taxonomies::instance();
		KERP_Modules_Appointments_Schedules::instance();
		KERP_Modules_Appointments_Form::instance();
		KERP_Modules_Appointments_Query::instance();
		KERP_Modules_Appointments_Availability::instance();
		KERP_Modules_Appointments_Manager::instance();
		KERP_Modules_Appointments_Booking_Product::instance();
		KERP_Modules_Appointments_Public_Booking::instance();
		KERP_Modules_Appointments_List_Table::instance();
		KERP_Modules_Appointments_Api::instance();
		KERP_Modules_Appointments_Public_Fields::instance();
	}
	
	private function maybe_install(): void {
		if ( (string) get_option( self::DB_VERSION_OPTION, '' ) !== self::DB_VERSION ) {
			KERP_Modules_Appointments_Installer::instance()->install();
			update_option( self::DB_VERSION_OPTION, self::DB_VERSION, FALSE );
		}
		KERP_Modules_Appointments_Booking_Product::instance()->ensure_product();
	}
	
	private function register_hooks(): void {
		add_filter( 'kerp_app_pages', [ $this, 'register_pages' ], 45 );
		add_filter( 'kerp_employee_permission_groups', [ $this, 'register_permissions' ], 45 );
		add_filter( 'kerp_customer_profile_tabs', [ $this, 'register_customer_tab' ], 45, 3 );
		add_filter( 'kerp_employee_profile_tabs', [ $this, 'register_employee_tab' ], 45, 3 );
		add_action( 'kerp_footer_template', [ $this, 'render_modals' ], 45 );
		add_filter( 'kerp_admin_bar_items', [ $this, 'admin_bar_items' ] );
	}
	
	public function register_pages( array $pages ): array {
		$settings                                      = KERP_Modules_Appointments_Settings::instance();
		$group                                         = [
			'key'   => 'appointments',
			'title' => $settings->get_appointment_plural_label(),
			'icon'  => 'uik-r fa-calendar',
			'order' => 45,
		];
		$pages['appointments']                         = [
			'title'      => $settings->get_appointment_plural_label(),
			'route'      => 'appointments',
			'type'       => 'page',
			'template'   => 'modules/appointments/pages/appointments.php',
			'permission' => 'appointments.view',
			'navigation' => [ 'group' => $group, 'icon' => 'ni ni-calendar-booking', 'order' => 10 ],
		];
		$pages['appointments-calendar']                = [
			'title'      => sprintf( __( 'تقویم %s', 'kasebi-erp' ), $settings->get_appointment_plural_label() ),
			'route'      => 'appointments/calendar',
			'type'       => 'page',
			'template'   => 'modules/appointments/pages/calendar.php',
			'permission' => 'appointments.view',
			'navigation' => [ 'group' => $group, 'icon' => 'ni ni-calendar-alt', 'order' => 20 ],
		];
		$pages['appointments-services']                = [
			'title'      => $settings->get_service_plural_label(),
			'route'      => 'appointments/services',
			'type'       => 'page',
			'template'   => 'modules/appointments/pages/services.php',
			'permission' => 'appointments.services.manage',
			'navigation' => [ 'group' => $group, 'icon' => 'ni ni-property', 'order' => 30 ],
		];
		$pages['appointments-taxonomies']              = [
			'title'      => sprintf( __( 'دسته‌بندی %s', 'kasebi-erp' ), $settings->get_service_plural_label() ),
			'route'      => 'appointments/taxonomies',
			'type'       => 'page',
			'template'   => 'modules/appointments/pages/taxonomies.php',
			'permission' => 'appointments.taxonomies.manage',
			'navigation' => [ 'group' => $group, 'icon' => 'ni ni-folder-list', 'order' => 40 ],
		];
		$pages['appointments-schedules']               = [
			'title'      => __( 'برنامه کاری', 'kasebi-erp' ),
			'route'      => 'appointments/schedules',
			'type'       => 'page',
			'template'   => 'modules/appointments/pages/schedules.php',
			'permission' => 'appointments.schedules.manage',
			'navigation' => [ 'group' => $group, 'icon' => 'ni ni-clock', 'order' => 50 ],
		];
		$settings_menu                                 = [
			'key'   => 'appointments-settings',
			'title' => __( 'تنظیمات', 'kasebi-erp' ),
			'icon'  => 'ni ni-setting-alt',
			'order' => 90,
		];
		$pages['appointments-settings-general']        = [
			'title'      => sprintf( __( 'تنظیمات عمومی %s', 'kasebi-erp' ), $settings->get_appointment_plural_label() ),
			'route'      => 'appointments/settings',
			'type'       => 'settings',
			'template'   => 'modules/appointments/settings/general.php',
			'permission' => 'appointments.manage_settings',
			'navigation' => [
				'group' => $group,
				'menu'  => $settings_menu,
				'title' => __( 'عمومی', 'kasebi-erp' ),
				'order' => 10,
			],
		];
		$pages['appointments-settings-sms']            = [
			'title'      => sprintf( __( 'تنظیمات پیامک %s', 'kasebi-erp' ), $settings->get_appointment_plural_label() ),
			'route'      => 'appointments/settings/sms',
			'type'       => 'settings',
			'template'   => 'modules/appointments/settings/sms.php',
			'permission' => 'appointments.manage_settings',
			'navigation' => [
				'group' => $group,
				'menu'  => $settings_menu,
				'title' => __( 'پیامک', 'kasebi-erp' ),
				'order' => 15,
			],
		];
		$pages['appointments-settings-labels']         = [
			'title'      => sprintf( __( 'لیبل‌های %s', 'kasebi-erp' ), $settings->get_appointment_plural_label() ),
			'route'      => 'appointments/settings/labels',
			'type'       => 'settings',
			'template'   => 'modules/appointments/settings/labels.php',
			'permission' => 'appointments.manage_settings',
			'navigation' => [
				'group' => $group,
				'menu'  => $settings_menu,
				'title' => __( 'لیبل‌ها', 'kasebi-erp' ),
				'order' => 20,
			],
		];
		$pages['appointments-settings-statuses']       = [
			'title'      => sprintf( __( 'وضعیت‌های %s', 'kasebi-erp' ), $settings->get_appointment_singular_label() ),
			'route'      => 'appointments/settings/statuses',
			'type'       => 'settings',
			'template'   => 'modules/appointments/settings/statuses.php',
			'permission' => 'appointments.manage_settings',
			'navigation' => [
				'group' => $group,
				'menu'  => $settings_menu,
				'title' => __( 'وضعیت‌ها', 'kasebi-erp' ),
				'order' => 30,
			],
		];
		$pages['appointments-settings-location-types'] = [
			'title'      => sprintf( __( 'انواع برگزاری %s', 'kasebi-erp' ), $settings->get_appointment_singular_label() ),
			'route'      => 'appointments/settings/location-types',
			'type'       => 'settings',
			'template'   => 'modules/appointments/settings/location-types.php',
			'permission' => 'appointments.manage_settings',
			'navigation' => [
				'group' => $group,
				'menu'  => $settings_menu,
				'title' => __( 'انواع برگزاری', 'kasebi-erp' ),
				'order' => 40,
			],
		];
		$pages['appointments-settings-product']        = [
			'title'      => __( 'محصول سیستمی رزرو', 'kasebi-erp' ),
			'route'      => 'appointments/settings/product',
			'type'       => 'settings',
			'template'   => 'modules/appointments/settings/product.php',
			'permission' => 'appointments.manage_settings',
			'navigation' => [
				'group' => $group,
				'menu'  => $settings_menu,
				'title' => __( 'محصول رزرو', 'kasebi-erp' ),
				'order' => 40,
			],
		];
		$pages['appointments-settings-public-fields']  = [
			'title'      => __( 'فیلدهای فرم رزرو عمومی', 'kasebi-erp' ),
			'route'      => 'appointments/settings/public-fields',
			'type'       => 'settings',
			'template'   => 'modules/appointments/settings/public-fields.php',
			'permission' => 'appointments.manage_settings',
			'navigation' => [
				'group' => $group,
				'menu'  => $settings_menu,
				'title' => __( 'فرم رزرو', 'kasebi-erp' ),
				'order' => 50,
			],
		];
		
		return $pages;
	}
	
	public function register_permissions( array $groups ): array {
		$settings               = KERP_Modules_Appointments_Settings::instance();
		$groups['appointments'] = [
			'key'    => 'appointments',
			'label'  => $settings->get_appointment_plural_label(),
			'icon'   => 'uik-r fa-calendar',
			'order'  => 45,
			'blocks' => [
				'appointments' => [
					'key'         => 'appointments',
					'label'       => $settings->get_appointment_plural_label(),
					'icon'        => 'ni ni-calendar-booking',
					'order'       => 10,
					'permissions' => [
						'view'   => [
							'key'   => 'appointments.view',
							'label' => sprintf( __( 'دسترسی به بخش %s', 'kasebi-erp' ), $settings->get_appointment_plural_label() ),
							'type'  => 'view',
							'order' => 10,
						],
						'list'   => [
							'key'   => 'appointments.list',
							'label' => sprintf( __( 'مشاهده %s', 'kasebi-erp' ), $settings->get_appointment_plural_label() ),
							'type'  => 'view',
							'order' => 20,
							'scope' => [
								'options' => [
									'own' => sprintf( __( 'فقط %s خود', 'kasebi-erp' ), $settings->get_appointment_plural_label() ),
									'all' => sprintf( __( 'همه %s', 'kasebi-erp' ), $settings->get_appointment_plural_label() ),
								],
								'default' => 'own',
							],
						],
						'create' => [
							'key'   => 'appointments.create',
							'label' => sprintf( __( 'ثبت %s', 'kasebi-erp' ), $settings->get_appointment_singular_label() ),
							'type'  => 'action',
							'order' => 30,
						],
						'edit'   => [
							'key'   => 'appointments.edit',
							'label' => sprintf( __( 'ویرایش %s', 'kasebi-erp' ), $settings->get_appointment_singular_label() ),
							'type'  => 'action',
							'order' => 40,
						],
						'status' => [
							'key'   => 'appointments.status.change',
							'label' => sprintf( __( 'تغییر وضعیت %s', 'kasebi-erp' ), $settings->get_appointment_singular_label() ),
							'type'  => 'action',
							'order' => 50,
						],
						'delete' => [
							'key'   => 'appointments.delete',
							'label' => sprintf( __( 'حذف %s', 'kasebi-erp' ), $settings->get_appointment_singular_label() ),
							'type'  => 'action',
							'order' => 60,
						],
					],
				],
				'management'   => [
					'key'         => 'appointments-management',
					'label'       => sprintf( __( 'مدیریت %s', 'kasebi-erp' ), $settings->get_appointment_plural_label() ),
					'icon'        => 'ni ni-setting-alt',
					'order'       => 20,
					'permissions' => [
						'services'   => [
							'key'   => 'appointments.services.manage',
							'label' => sprintf( __( 'مدیریت %s', 'kasebi-erp' ), $settings->get_service_plural_label() ),
							'type'  => 'action',
							'order' => 10,
						],
						'taxonomies' => [
							'key'   => 'appointments.taxonomies.manage',
							'label' => sprintf( __( 'مدیریت دسته‌بندی %s', 'kasebi-erp' ), $settings->get_service_plural_label() ),
							'type'  => 'action',
							'order' => 20,
						],
						'schedules'  => [
							'key'   => 'appointments.schedules.manage',
							'label' => __( 'مدیریت برنامه کاری', 'kasebi-erp' ),
							'type'  => 'action',
							'order' => 30,
						],
						'settings'   => [
							'key'   => 'appointments.manage_settings',
							'label' => sprintf( __( 'مدیریت تنظیمات %s', 'kasebi-erp' ), $settings->get_appointment_plural_label() ),
							'type'  => 'action',
							'order' => 40,
						],
					],
				],
			],
		];
		
		return $groups;
	}
	
	public function register_customer_tab( array $tabs, int $customer_id, WP_User $customer ): array {
		if ( kerp_can( 'appointments.view', 'view' ) ) {
			$tabs['appointments'] = [
				'key'        => 'appointments',
				'title'      => KERP_Modules_Appointments_Settings::instance()->get_appointment_plural_label(),
				'icon'       => 'ni ni-calendar-booking',
				'order'      => 70,
				'group'      => 'planning-learning',
				'permission' => 'appointments.view',
				'action'     => 'view',
				'template'   => 'modules/appointments/tabs/customer-appointments.php',
			];
		}
		
		return $tabs;
	}
	
	public function register_employee_tab( array $tabs, int $employee_id, WP_User $employee ): array {
		if ( kerp_can( 'appointments.view', 'view' ) ) {
			$tabs['appointments'] = [
				'key'        => 'appointments',
				'title'      => KERP_Modules_Appointments_Settings::instance()->get_appointment_plural_label(),
				'icon'       => 'ni ni-calendar-booking',
				'order'      => 70,
				'permission' => 'appointments.view',
				'action'     => 'view',
				'template'   => 'modules/appointments/tabs/employee-appointments.php',
			];
		}
		
		return $tabs;
	}
	
	public function render_modals(): void {
		KERP_Modules_Appointments_Form::instance()->render_modals();
	}
	
	public function admin_bar_items( array $items ): array {
		$items['appointments'] = [
			'title' => KERP_Modules_Appointments_Settings::instance()->get_appointment_plural_label(),
			'url'   => '/erp/appointments/',
		];
		
		return $items;
	}
	
}
