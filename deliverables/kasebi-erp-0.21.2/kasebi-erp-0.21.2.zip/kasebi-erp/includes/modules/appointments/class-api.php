<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Appointments_Api {
	
	private static ?self $instance = NULL;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {
		add_action( 'kasebi_ajax_appointments_save', [ $this, 'save' ] );
		add_action( 'kasebi_ajax_appointments_delete', [ $this, 'delete' ] );
		add_action( 'kasebi_ajax_appointments_change_status', [ $this, 'change_status' ] );
		add_action( 'kasebi_ajax_appointments_get_slots', [ $this, 'get_slots' ] );
		add_action( 'kasebi_ajax_appointments_get_time_options', [ $this, 'get_time_options' ] );
		add_action( 'kasebi_ajax_appointments_get_service_employees', [ $this, 'get_service_employees' ] );
		add_action( 'kasebi_ajax_appointments_save_service', [ $this, 'save_service' ] );
		add_action( 'kasebi_ajax_appointments_delete_service', [ $this, 'delete_service' ] );
		add_action( 'kasebi_ajax_appointments_save_taxonomy', [ $this, 'save_taxonomy' ] );
		add_action( 'kasebi_ajax_appointments_delete_taxonomy', [ $this, 'delete_taxonomy' ] );
		add_action( 'kasebi_ajax_appointments_save_term', [ $this, 'save_term' ] );
		add_action( 'kasebi_ajax_appointments_delete_term', [ $this, 'delete_term' ] );
		add_action( 'kasebi_ajax_appointments_save_schedule', [ $this, 'save_schedule' ] );
		add_action( 'kasebi_ajax_appointments_delete_schedule', [ $this, 'delete_schedule' ] );
		add_action( 'kasebi_ajax_appointments_save_exception', [ $this, 'save_exception' ] );
		add_action( 'kasebi_ajax_appointments_delete_exception', [ $this, 'delete_exception' ] );
		add_action( 'kasebi_ajax_appointments_save_settings', [ $this, 'save_settings' ] );
		add_action( 'kasebi_ajax_appointments_save_sms_settings', [ $this, 'save_sms_settings' ] );
		add_action( 'kasebi_ajax_appointments_save_status', [ $this, 'save_status' ] );
		add_action( 'kasebi_ajax_appointments_delete_status', [ $this, 'delete_status' ] );
		add_action( 'kasebi_ajax_appointments_repair_booking_product', [ $this, 'repair_booking_product' ] );
		add_action( 'kasebi_ajax_appointments_save_note', [ $this, 'save_note' ] );
		add_action( 'kasebi_ajax_appointments_save_location_type', [ $this, 'save_location_type' ] );
		add_action( 'kasebi_ajax_appointments_delete_location_type', [ $this, 'delete_location_type' ] );
		add_action( 'kasebi_ajax_appointments_save_public_field', [ $this, 'save_public_field' ] );
		add_action( 'kasebi_ajax_appointments_delete_public_field', [ $this, 'delete_public_field' ] );
	}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	private function get_schedules_response( string $default_tab = 'schedules' ): array {
		$active_tab = sanitize_key(
			$this->post_text( 'active_tab' )
		);
		
		if ( ! in_array( $active_tab, [ 'schedules', 'exceptions' ], TRUE ) ) {
			$active_tab = $default_tab;
		}
		
		$query = [
			'active_tab' => $active_tab,
		];
		
		$filter_employee_id = absint(
			$_POST['filter_employee_id'] ?? 0
		);
		
		if ( $filter_employee_id > 0 ) {
			$query['employee_id'] = $filter_employee_id;
		}
		
		$filter_service_id = $this->post_text(
			'filter_service_id'
		);
		
		if ( $filter_service_id !== '' ) {
			$query['service_id'] = absint(
				$filter_service_id
			);
		}
		
		return KERP_Api_Page_Content::build_page_response(
			'/erp/appointments/schedules/',
			$query,
			TRUE
		);
	}
	
	public function save(): void {
		$appointment_id = absint( $_POST['appointment_id'] ?? 0 );
		$this->guard( $appointment_id > 0 ? 'appointments.edit' : 'appointments.create' );
		if ( $appointment_id > 0 ) {
			$this->guard_item_scope( $appointment_id );
		}
		$data = $this->post_array( 'appointment' );
		if ( empty( $data ) ) {
			$data = wp_unslash( $_POST );
		}
		if ( function_exists( 'kerp_list_scope' ) && kerp_list_scope( 'appointments' ) === 'own' ) {
			$data['employee_id'] = get_current_user_id();
		}
		$result = KERP_Modules_Appointments_Manager::instance()->save( $data, $appointment_id );
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		$page = $this->return_page( '/erp/appointments/' );
		$this->success(
			$appointment_id > 0 ? sprintf( __( '%s با موفقیت ویرایش شد.', 'kasebi-erp' ), KERP_Modules_Appointments_Settings::instance()
			                                                                                                                ->get_appointment_singular_label() ) : sprintf( __( '%s با موفقیت ثبت شد.', 'kasebi-erp' ), KERP_Modules_Appointments_Settings::instance()
			                                                                                                                                                                                                                                              ->get_appointment_singular_label() ),
			KERP_Api_Page_Content::build_page_response( $page, $this->route_query( $page ), TRUE )
		);
	}
	
	public function delete(): void {
		$this->guard( 'appointments.delete' );
		$appointment_id = absint( $_POST['appointment_id'] ?? $_POST['item_id'] ?? 0 );
		$this->guard_item_scope( $appointment_id );
		$result = KERP_Modules_Appointments_Manager::instance()->delete( $appointment_id );
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		$page = $this->return_page( '/erp/appointments/' );
		$this->success( sprintf( __( '%s حذف شد.', 'kasebi-erp' ), KERP_Modules_Appointments_Settings::instance()
		                                                                                             ->get_appointment_singular_label() ), KERP_Api_Page_Content::build_page_response( $page, $this->route_query( $page ), TRUE ) );
	}
	
	public function change_status(): void {
		$this->guard( 'appointments.status.change' );
		$appointment_id = absint( $_POST['appointment_id'] ?? 0 );
		$this->guard_item_scope( $appointment_id );
		$result = KERP_Modules_Appointments_Manager::instance()->change_status(
			$appointment_id,
			$this->post_text( 'status' ),
			$this->post_textarea( 'note' )
		);
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		$page = $this->return_page( '/erp/appointments/' );
		$this->success( sprintf( __( 'وضعیت %s تغییر کرد.', 'kasebi-erp' ), KERP_Modules_Appointments_Settings::instance()
		                                                                                                      ->get_appointment_singular_label() ), KERP_Api_Page_Content::build_page_response( $page, $this->route_query( $page ), TRUE ) );
	}
	
	public function get_slots(): void {
		$this->guard( 'appointments.view', 'view' );
		$appointment_id = absint( $_POST['appointment_id'] ?? 0 );
		$slots          = KERP_Modules_Appointments_Availability::instance()->get_slots(
			$this->post_text( 'date' ),
			absint( $_POST['service_id'] ?? 0 ),
			absint( $_POST['employee_id'] ?? 0 ),
			$appointment_id
		);
		$this->success( '', [ 'slots' => $slots ] );
	}
	
	public function get_time_options(): void {
		$this->guard( 'appointments.view', 'view' );
		
		$date           = $this->post_text( 'date' );
		$service_id     = absint( $_POST['service_id'] ?? 0 );
		$employee_id    = absint( $_POST['employee_id'] ?? 0 );
		$appointment_id = absint( $_POST['appointment_id'] ?? 0 );
		
		if ( $date === '' || $service_id <= 0 || $employee_id <= 0 ) {
			$this->success(
				'',
				[
					'options' => [],
				]
			);
		}
		
		$slots = KERP_Modules_Appointments_Availability::instance()->get_slots(
			$date,
			$service_id,
			$employee_id,
			$appointment_id
		);
		
		$options = [];
		
		if ( $appointment_id > 0 && ! KERP_Modules_Appointments_Settings::instance()->is_booking_date_active( $date ) ) {
			$this->guard_item_scope( $appointment_id );
			$existing = KERP_Modules_Appointments_Query::instance()->get_by_id( $appointment_id );
			if ( (int) $existing['service_id'] === $service_id && (int) $existing['employee_id'] === $employee_id
				&& substr( (string) $existing['start_at'], 0, 10 ) === KERP_Modules_Appointments_Form::instance()->normalize_date( $date ) ) {
				$time = substr( (string) $existing['start_at'], 11, 5 );
				$options[ $time ] = $time . ' - ' . __( 'زمان ثبت‌شده (خارج از بازه فعال)', 'kasebi-erp' );
			}
		}
		
		foreach ( $slots as $slot ) {
			$time      = sanitize_text_field( (string) ( $slot['time'] ?? '' ) );
			$remaining = absint( $slot['remaining'] ?? 0 );
			
			if ( $time === '' ) {
				continue;
			}
			
			$options[ $time ] = $remaining > 1
				? sprintf(
					__( '%1$s - %2$s ظرفیت آزاد', 'kasebi-erp' ),
					$time,
					number_format_i18n( $remaining )
				)
				: $time;
		}
		
		$this->success(
			'',
			[
				'options' => $options,
			]
		);
	}
	
	public function get_service_employees(): void {
		$this->guard( 'appointments.view', 'view' );
		$service_id = absint( $_POST['service_id'] ?? 0 );
		$options    = KERP_Modules_Appointments_Form::instance()->get_employee_options_for_service( $service_id );
		$employees  = [];
		foreach ( $options as $id => $label ) {
			$employees[] = [ 'id' => absint( $id ), 'label' => (string) $label ];
		}
		$this->success( '', [ 'employees' => $employees ] );
	}
	
	public function save_service(): void {
		$this->guard( 'appointments.services.manage' );
		$service    = $this->post_array( 'service' );
		$service_id = absint( $service['id'] ?? $_POST['service_id'] ?? 0 );
		$result     = KERP_Modules_Appointments_Services::instance()->save( $service, $service_id );
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		$page = '/erp/appointments/services/';
		$this->success( $service_id > 0 ? sprintf( __( '%s ویرایش شد.', 'kasebi-erp' ), KERP_Modules_Appointments_Settings::instance()
		                                                                                                                  ->get_service_singular_label() ) : sprintf( __( '%s ایجاد شد.', 'kasebi-erp' ), KERP_Modules_Appointments_Settings::instance()
		                                                                                                                                                                                                                                    ->get_service_singular_label() ), KERP_Api_Page_Content::build_page_response( $page, [], TRUE ) );
	}
	
	public function delete_service(): void {
		$this->guard( 'appointments.services.manage' );
		$result = KERP_Modules_Appointments_Services::instance()
		                                            ->delete( absint( $_POST['service_id'] ?? $_POST['item_id'] ?? 0 ) );
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		$page = '/erp/appointments/services/';
		$this->success( sprintf( __( '%s حذف شد.', 'kasebi-erp' ), KERP_Modules_Appointments_Settings::instance()
		                                                                                             ->get_service_singular_label() ), KERP_Api_Page_Content::build_page_response( $page, [], TRUE ) );
	}
	
	public function save_taxonomy(): void {
		$this->guard( 'appointments.taxonomies.manage' );
		$data        = $this->post_array( 'taxonomy' );
		$taxonomy_id = absint( $data['id'] ?? $_POST['taxonomy_id'] ?? 0 );
		$result      = KERP_Modules_Appointments_Taxonomies::instance()->save_taxonomy( $data, $taxonomy_id );
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		$page = '/erp/appointments/taxonomies/';
		$this->success( __( 'دسته‌بندی ذخیره شد.', 'kasebi-erp' ), KERP_Api_Page_Content::build_page_response( $page, [], TRUE ) );
	}
	
	public function delete_taxonomy(): void {
		$this->guard( 'appointments.taxonomies.manage' );
		$result = KERP_Modules_Appointments_Taxonomies::instance()
		                                              ->delete_taxonomy( absint( $_POST['taxonomy_id'] ?? $_POST['item_id'] ?? 0 ) );
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		$page = '/erp/appointments/taxonomies/';
		$this->success( __( 'دسته‌بندی حذف شد.', 'kasebi-erp' ), KERP_Api_Page_Content::build_page_response( $page, [], TRUE ) );
	}
	
	public function save_term(): void {
		$this->guard( 'appointments.taxonomies.manage' );
		$data    = $this->post_array( 'term' );
		$term_id = absint( $data['id'] ?? $_POST['term_id'] ?? 0 );
		$result  = KERP_Modules_Appointments_Taxonomies::instance()->save_term( $data, $term_id );
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		$page = '/erp/appointments/taxonomies/';
		$this->success( __( 'ترم ذخیره شد.', 'kasebi-erp' ), KERP_Api_Page_Content::build_page_response( $page, [], TRUE ) );
	}
	
	public function delete_term(): void {
		$this->guard( 'appointments.taxonomies.manage' );
		$result = KERP_Modules_Appointments_Taxonomies::instance()
		                                              ->delete_term( absint( $_POST['term_id'] ?? $_POST['item_id'] ?? 0 ) );
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		$page = '/erp/appointments/taxonomies/';
		$this->success( __( 'ترم حذف شد.', 'kasebi-erp' ), KERP_Api_Page_Content::build_page_response( $page, [], TRUE ) );
	}
	
	public function save_schedule(): void {
		$this->guard( 'appointments.schedules.manage' );
		$data        = $this->post_array( 'schedule' );
		$schedule_id = absint( $data['id'] ?? $_POST['schedule_id'] ?? 0 );
		$result      = KERP_Modules_Appointments_Schedules::instance()->save_schedule( $data, $schedule_id );
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		$page = '/erp/appointments/schedules/';
		$this->success(
			__( 'برنامه کاری ذخیره شد.', 'kasebi-erp' ),
			$this->get_schedules_response( 'schedules' )
		);
	}
	
	public function delete_schedule(): void {
		$this->guard( 'appointments.schedules.manage' );
		$result = KERP_Modules_Appointments_Schedules::instance()
		                                             ->delete_schedule( absint( $_POST['schedule_id'] ?? $_POST['item_id'] ?? 0 ) );
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		$page = '/erp/appointments/schedules/';
		$this->success(
			__( 'برنامه کاری حذف شد.', 'kasebi-erp' ),
			$this->get_schedules_response( 'schedules' )
		);
	}
	
	public function save_exception(): void {
		$this->guard( 'appointments.schedules.manage' );
		$data         = $this->post_array( 'exception' );
		$exception_id = absint( $data['id'] ?? $_POST['exception_id'] ?? 0 );
		$result       = KERP_Modules_Appointments_Schedules::instance()->save_exception( $data, $exception_id );
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		$page = '/erp/appointments/schedules/';
		$this->success(
			__( 'استثنای برنامه ذخیره شد.', 'kasebi-erp' ),
			$this->get_schedules_response( 'exceptions' )
		);
	}
	
	public function delete_exception(): void {
		$this->guard( 'appointments.schedules.manage' );
		$result = KERP_Modules_Appointments_Schedules::instance()
		                                             ->delete_exception( absint( $_POST['exception_id'] ?? $_POST['item_id'] ?? 0 ) );
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		$page = '/erp/appointments/schedules/';
		$this->success(
			__( 'استثنا حذف شد.', 'kasebi-erp' ),
			$this->get_schedules_response( 'exceptions' )
		);
	}
	
	public function save_settings(): void {
		$this->guard( 'appointments.manage_settings' );
		$result = KERP_Modules_Appointments_Settings::instance()->update( $this->post_array( 'settings' ) );
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		
		$active_tab = $this->settings_active_tab( 'general' );
		
		$this->success(
			sprintf( __( 'تنظیمات %s ذخیره شد.', 'kasebi-erp' ), KERP_Modules_Appointments_Settings::instance()
			                                                                                       ->get_appointment_plural_label() ),
			$this->settings_page_response( $active_tab )
		);
	}
	
	public function save_sms_settings(): void {
		$this->guard( 'appointments.manage_settings' );
		
		KERP_Modules_Appointments_SMS::instance()->save_rules(
			$this->post_array( 'sms_rules' )
		);
		
		$active_tab = $this->settings_active_tab( 'sms' );
		
		$this->success(
			__( 'تنظیمات پیامک ذخیره شد.', 'kasebi-erp' ),
			$this->settings_page_response( $active_tab )
		);
	}
	
	public function save_status(): void {
		$this->guard( 'appointments.manage_settings' );
		$result = KERP_Modules_Appointments_Settings::instance()->save_status(
			$this->post_array( 'status' ),
			$this->post_text( 'original_key' )
		);
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		$active_tab = $this->settings_active_tab( 'statuses' );
		
		$this->success(
			sprintf( __( 'وضعیت %s ذخیره شد.', 'kasebi-erp' ), KERP_Modules_Appointments_Settings::instance()
			                                                                                     ->get_appointment_singular_label() ),
			$this->settings_page_response( $active_tab )
		);
	}
	
	public function delete_status(): void {
		$this->guard( 'appointments.manage_settings' );
		$result = KERP_Modules_Appointments_Settings::instance()->delete_status(
			$this->post_text( 'status_key' ) ?: $this->post_text( 'item_id' ),
			$this->post_text( 'replacement_key' )
		);
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		$active_tab = $this->settings_active_tab( 'statuses' );
		
		$this->success(
			__( 'وضعیت حذف شد.', 'kasebi-erp' ),
			$this->settings_page_response( $active_tab )
		);
	}
	
	public function repair_booking_product(): void {
		$this->guard( 'appointments.manage_settings' );
		$result = KERP_Modules_Appointments_Booking_Product::instance()->ensure_product();
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		$active_tab = $this->settings_active_tab( 'product' );
		
		$this->success(
			__( 'محصول سیستمی رزرو آماده است.', 'kasebi-erp' ),
			array_merge(
				$this->settings_page_response( $active_tab ),
				[
					'product_id' => absint( $result ),
				]
			)
		);
	}
	
	public function save_note(): void {
		$this->guard( 'appointments.edit' );
		
		$appointment_id = absint(
			$_POST['appointment_id'] ?? 0
		);
		
		$this->guard_item_scope(
			$appointment_id
		);
		
		$result = KERP_Modules_Appointments_Manager::instance()->save_note(
			$appointment_id,
			$this->post_textarea( 'note' )
		);
		
		if ( is_wp_error( $result ) ) {
			$this->error(
				$result->get_error_message()
			);
		}
		
		$page = $this->return_page(
			'/erp/appointments/'
		);
		
		$this->success(
			sprintf( __( 'یادداشت %s ذخیره شد.', 'kasebi-erp' ), KERP_Modules_Appointments_Settings::instance()
			                                                                                       ->get_appointment_singular_label() ),
			KERP_Api_Page_Content::build_page_response(
				$page,
				$this->route_query( $page ),
				TRUE
			)
		);
	}
	
	public function save_location_type(): void {
		$this->guard( 'appointments.manage_settings' );
		
		$result = KERP_Modules_Appointments_Settings::instance()->save_location_type(
			$this->post_array( 'location_type' ),
			$this->post_text( 'original_key' )
		);
		
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		
		$active_tab = $this->settings_active_tab( 'location_types' );
		
		$this->success(
			__( 'نوع برگزاری ذخیره شد.', 'kasebi-erp' ),
			$this->settings_page_response( $active_tab )
		);
	}
	
	public function delete_location_type(): void {
		$this->guard( 'appointments.manage_settings' );
		
		$result = KERP_Modules_Appointments_Settings::instance()->delete_location_type(
			$this->post_text( 'location_type_key' ) ?: $this->post_text( 'item_id' )
		);
		
		if ( is_wp_error( $result ) ) {
			$this->error( $result->get_error_message() );
		}
		
		$active_tab = $this->settings_active_tab( 'location_types' );
		
		$this->success(
			__( 'نوع برگزاری حذف شد.', 'kasebi-erp' ),
			$this->settings_page_response( $active_tab )
		);
	}
	
	public function save_public_field(): void {
		$this->guard( 'appointments.manage_settings' );
		
		$field = isset( $_POST['field'] ) && is_array( $_POST['field'] )
			? wp_unslash( $_POST['field'] )
			: [];
		
		$key   = sanitize_key( (string) ( $field['key'] ?? '' ) );
		$label = sanitize_text_field( (string) ( $field['label'] ?? '' ) );
		
		if ( $key === '' ) {
			$this->error( __( 'کلید فیلد را وارد کنید.', 'kasebi-erp' ) );
		}
		
		if ( $label === '' ) {
			$this->error( __( 'عنوان فیلد را وارد کنید.', 'kasebi-erp' ) );
		}
		
		$field['key']   = $key;
		$field['label'] = $label;
		
		KERP_Modules_Appointments_Public_Fields::instance()->upsert( $field );
		
		$page = '/erp/appointments/settings/public-fields/';
		
		$this->success(
			__( 'فیلد فرم رزرو ذخیره شد.', 'kasebi-erp' ),
			KERP_Api_Page_Content::build_page_response( $page, [], TRUE )
		);
	}
	
	public function delete_public_field(): void {
		$this->guard( 'appointments.manage_settings' );
		
		$key = sanitize_key(
			$this->post_text( 'key' )
				?: $this->post_text( 'item_id' )
		);
		
		if ( $key === '' ) {
			$this->error( __( 'شناسه فیلد ارسال نشده است.', 'kasebi-erp' ) );
		}
		
		KERP_Modules_Appointments_Public_Fields::instance()->delete( $key );
		
		$page = '/erp/appointments/settings/public-fields/';
		
		$this->success(
			__( 'فیلد فرم رزرو حذف شد.', 'kasebi-erp' ),
			KERP_Api_Page_Content::build_page_response( $page, [], TRUE )
		);
	}
	
	private function settings_active_tab( string $default = 'general' ): string {
		$allowed_tabs = [
			'general',
			'labels',
			'statuses',
			'location_types',
			'product',
			'sms',
		];
		
		$active_tab = sanitize_key(
			$this->post_text( 'active_tab' )
		);
		
		if ( ! in_array( $active_tab, $allowed_tabs, TRUE ) ) {
			$active_tab = $default;
		}
		
		return $active_tab;
	}
	
	private function settings_page_url( string $active_tab ): string {
		$pages = [
			'general'        => '/erp/appointments/settings/',
			'labels'         => '/erp/appointments/settings/labels/',
			'statuses'       => '/erp/appointments/settings/statuses/',
			'location_types' => '/erp/appointments/settings/location-types/',
			'product'        => '/erp/appointments/settings/product/',
			'sms'            => '/erp/appointments/settings/sms/',
		];
		
		return $pages[ $active_tab ]
		       ?? $pages['general'];
	}
	
	private function settings_page_response( string $active_tab ): array {
		$page = $this->settings_page_url( $active_tab );
		
		return array_merge(
			KERP_Api_Page_Content::build_page_response(
				$page,
				[],
				TRUE
			),
			[
				'active_tab' => $active_tab,
			]
		);
	}
	
	private function guard_item_scope( int $appointment_id ): void {
		$appointment = KERP_Modules_Appointments_Query::instance()->get_by_id( $appointment_id );
		if ( empty( $appointment ) ) {
			$this->error( sprintf( __( '%s پیدا نشد.', 'kasebi-erp' ), KERP_Modules_Appointments_Settings::instance()
			                                                                                             ->get_appointment_singular_label() ) );
		}
		if ( ! function_exists( 'kerp_list_scope' ) || kerp_list_scope( 'appointments' ) === 'all' ) {
			return;
		}
		if ( absint( $appointment['employee_id'] ?? 0 ) === get_current_user_id() ) {
			return;
		}
		$this->error( sprintf( __( 'به این %s دسترسی ندارید.', 'kasebi-erp' ), KERP_Modules_Appointments_Settings::instance()
		                                                                                                         ->get_appointment_singular_label() ) );
	}
	
	private function guard( string $permission, string $mode = 'action' ): void {
		if ( ! function_exists( 'kerp_can' ) || ! kerp_can( $permission, $mode ) ) {
			$this->error( __( 'دسترسی لازم را ندارید.', 'kasebi-erp' ) );
		}
	}
	
	private function post_array( string $key ): array {
		return isset( $_POST[ $key ] ) && is_array( $_POST[ $key ] ) ? wp_unslash( $_POST[ $key ] ) : [];
	}
	
	private function post_text( string $key ): string {
		return isset( $_POST[ $key ] ) && ! is_array( $_POST[ $key ] ) ? sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) : '';
	}
	
	private function post_textarea( string $key ): string {
		return isset( $_POST[ $key ] ) && ! is_array( $_POST[ $key ] ) ? sanitize_textarea_field( wp_unslash( $_POST[ $key ] ) ) : '';
	}
	
	private function return_page( string $fallback ): string {
		$page = $this->post_text( 'return_page' ) ?: $this->post_text( 'page' );
		
		return str_starts_with( $page, '/erp/' ) ? $page : $fallback;
	}
	
	private function route_query( string $page ): array {
		$query = wp_parse_url( $page, PHP_URL_QUERY );
		if ( ! is_string( $query ) || $query === '' ) {
			return [];
		}
		parse_str( $query, $args );
		
		return is_array( $args ) ? $args : [];
	}
	
	private function success( string $message, array $data = [] ): void {
		wp_send_json( array_merge( [ 'status' => 'success', 'message' => $message, 'msg' => $message ], $data ) );
	}
	
	private function error( string $message, array $data = [] ): void {
		wp_send_json( array_merge( [ 'status' => 'error', 'message' => $message, 'msg' => $message ], $data ) );
	}
	
}
