<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules_Appointments_Installer {
	private static ?self $instance = NULL;
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		return self::$instance;
	}
	private function __construct() {}
	private function __clone() {}
	public function __wakeup(): void { throw new LogicException( 'Cannot unserialize a singleton.' ); }

	public function install(): void {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$charset = $wpdb->get_charset_collate();
		$appointments = $this->appointments_table();
		$services = $this->services_table();
		$service_employees = $this->service_employees_table();
		$taxonomies = $this->taxonomies_table();
		$terms = $this->terms_table();
		$service_terms = $this->service_terms_table();
		$schedules = $this->schedules_table();
		$exceptions = $this->exceptions_table();
		$sql = [];
		$sql[] = "CREATE TABLE {$services} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			title VARCHAR(190) NOT NULL,
			slug VARCHAR(190) NOT NULL,
			description LONGTEXT NULL,
			duration_min SMALLINT UNSIGNED NOT NULL DEFAULT 30,
			buffer_before_min SMALLINT UNSIGNED NOT NULL DEFAULT 0,
			buffer_after_min SMALLINT UNSIGNED NOT NULL DEFAULT 0,
			price DECIMAL(20,4) NOT NULL DEFAULT 0,
			deposit_type VARCHAR(30) NOT NULL DEFAULT 'none',
			deposit_value DECIMAL(20,4) NOT NULL DEFAULT 0,
			capacity SMALLINT UNSIGNED NOT NULL DEFAULT 1,
			icon VARCHAR(190) NOT NULL DEFAULT 'ni ni-calendar-booking',
			color VARCHAR(40) NOT NULL DEFAULT 'primary',
			active TINYINT(1) NOT NULL DEFAULT 1,
			public_booking TINYINT(1) NOT NULL DEFAULT 1,
			order_index INT NOT NULL DEFAULT 10,
			created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
			updated_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NULL,
			metadata LONGTEXT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY uq_slug (slug),
			KEY idx_active_order (active, order_index)
		) {$charset};";
		$sql[] = "CREATE TABLE {$service_employees} (
			service_id BIGINT UNSIGNED NOT NULL,
			employee_id BIGINT UNSIGNED NOT NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (service_id, employee_id),
			KEY idx_employee (employee_id)
		) {$charset};";
		$sql[] = "CREATE TABLE {$taxonomies} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			tax_key VARCHAR(100) NOT NULL,
			singular_label VARCHAR(190) NOT NULL,
			plural_label VARCHAR(190) NOT NULL,
			description TEXT NULL,
			icon VARCHAR(190) NOT NULL DEFAULT 'ni ni-folder-list',
			color VARCHAR(40) NOT NULL DEFAULT 'primary',
			active TINYINT(1) NOT NULL DEFAULT 1,
			order_index INT NOT NULL DEFAULT 10,
			created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
			updated_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY uq_tax_key (tax_key),
			KEY idx_active_order (active, order_index)
		) {$charset};";
		$sql[] = "CREATE TABLE {$terms} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			taxonomy_id BIGINT UNSIGNED NOT NULL,
			parent_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			name VARCHAR(190) NOT NULL,
			slug VARCHAR(190) NOT NULL,
			description TEXT NULL,
			icon VARCHAR(190) NOT NULL DEFAULT 'ni ni-tag',
			color VARCHAR(40) NOT NULL DEFAULT 'primary',
			active TINYINT(1) NOT NULL DEFAULT 1,
			order_index INT NOT NULL DEFAULT 10,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY uq_taxonomy_slug (taxonomy_id, slug),
			KEY idx_taxonomy_active_order (taxonomy_id, active, order_index),
			KEY idx_parent (parent_id)
		) {$charset};";
		$sql[] = "CREATE TABLE {$service_terms} (
			service_id BIGINT UNSIGNED NOT NULL,
			term_id BIGINT UNSIGNED NOT NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (service_id, term_id),
			KEY idx_term (term_id)
		) {$charset};";
		$sql[] = "CREATE TABLE {$schedules} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			employee_id BIGINT UNSIGNED NOT NULL,
			service_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			weekday TINYINT UNSIGNED NOT NULL DEFAULT 0,
			start_time TIME NOT NULL,
			end_time TIME NOT NULL,
			slot_interval SMALLINT UNSIGNED NOT NULL DEFAULT 0,
			capacity SMALLINT UNSIGNED NOT NULL DEFAULT 0,
			active TINYINT(1) NOT NULL DEFAULT 1,
			order_index INT NOT NULL DEFAULT 10,
			created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
			updated_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NULL,
			PRIMARY KEY  (id),
			KEY idx_employee_weekday (employee_id, weekday, active),
			KEY idx_service_weekday (service_id, weekday, active)
		) {$charset};";
		$sql[] = "CREATE TABLE {$exceptions} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			employee_id BIGINT UNSIGNED NOT NULL,
			service_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			exception_date DATE NOT NULL,
			type VARCHAR(30) NOT NULL DEFAULT 'closed',
			start_time TIME NULL,
			end_time TIME NULL,
			capacity SMALLINT UNSIGNED NOT NULL DEFAULT 0,
			note TEXT NULL,
			active TINYINT(1) NOT NULL DEFAULT 1,
			created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
			updated_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NULL,
			PRIMARY KEY  (id),
			KEY idx_employee_date (employee_id, exception_date, active),
			KEY idx_service_date (service_id, exception_date, active)
		) {$charset};";
		$sql[] = "CREATE TABLE {$appointments} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			customer_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			service_id BIGINT UNSIGNED NOT NULL,
			employee_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			start_at DATETIME NOT NULL,
			end_at DATETIME NOT NULL,
			status VARCHAR(50) NOT NULL DEFAULT 'confirmed',
			source VARCHAR(50) NOT NULL DEFAULT 'admin',
			quantity SMALLINT UNSIGNED NOT NULL DEFAULT 1,
			order_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			price DECIMAL(20,4) NOT NULL DEFAULT 0,
			payable_amount DECIMAL(20,4) NOT NULL DEFAULT 0,
			customer_name VARCHAR(190) NULL,
			customer_phone VARCHAR(60) NULL,
			location_type VARCHAR(50) NULL,
			location TEXT NULL,
			description LONGTEXT NULL,
			internal_note LONGTEXT NULL,
			cancel_reason LONGTEXT NULL,
			hold_until DATETIME NULL,
			cancelled_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
			created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
			updated_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NULL,
			metadata LONGTEXT NULL,
			PRIMARY KEY  (id),
			KEY idx_customer_start (customer_id, start_at),
			KEY idx_employee_start (employee_id, start_at),
			KEY idx_service_start (service_id, start_at),
			KEY idx_status_start (status, start_at),
			KEY idx_order (order_id)
		) {$charset};";
		foreach ( $sql as $statement ) {
			dbDelta( $statement );
		}
	}

	public function appointments_table(): string { global $wpdb; return $wpdb->prefix . 'kasebi_erp_appointments'; }
	public function services_table(): string { global $wpdb; return $wpdb->prefix . 'kasebi_erp_appointment_services'; }
	public function service_employees_table(): string { global $wpdb; return $wpdb->prefix . 'kasebi_erp_appointment_service_employees'; }
	public function taxonomies_table(): string { global $wpdb; return $wpdb->prefix . 'kasebi_erp_appointment_taxonomies'; }
	public function terms_table(): string { global $wpdb; return $wpdb->prefix . 'kasebi_erp_appointment_terms'; }
	public function service_terms_table(): string { global $wpdb; return $wpdb->prefix . 'kasebi_erp_appointment_service_terms'; }
	public function schedules_table(): string { global $wpdb; return $wpdb->prefix . 'kasebi_erp_appointment_schedules'; }
	public function exceptions_table(): string { global $wpdb; return $wpdb->prefix . 'kasebi_erp_appointment_schedule_exceptions'; }
}
