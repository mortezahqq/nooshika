<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Core_Order_Index {

	private static ?KERP_Core_Order_Index $instance = NULL;

	private wpdb $db;

	private string $table;

	public static function instance(): KERP_Core_Order_Index {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	private function __construct() {
		global $wpdb;

		$this->db    = $wpdb;
		$this->table = self::table();

		add_action( 'woocommerce_after_order_object_save', [ $this, 'on_order_saved' ], 100, 2 );
		add_action( 'woocommerce_order_status_changed', [ $this, 'on_status_changed' ], 100, 4 );
		add_action( 'woocommerce_before_delete_order', [ $this, 'on_order_deleted' ], 100 );
		add_action( 'before_delete_post', [ $this, 'on_post_deleted' ], 100 );
		add_action( 'woocommerce_order_refunded', [ $this, 'sync_order' ], 100 );
		add_action( 'woocommerce_refund_deleted', [ $this, 'on_refund_deleted' ], 100, 2 );
	}

	private function __clone() {}

	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize singleton.' );
	}

	public static function table(): string {
		global $wpdb;

		return $wpdb->prefix . 'kasebi_erp_order_index';
	}

	public static function install(): void {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$table   = self::table();
		$charset = $wpdb->get_charset_collate();
		$sql     = "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			order_id BIGINT UNSIGNED NOT NULL,
			order_item_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			customer_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			product_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			variation_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			item_qty DECIMAL(20,6) NOT NULL DEFAULT 0,
			item_subtotal DECIMAL(20,6) NOT NULL DEFAULT 0,
			item_total DECIMAL(20,6) NOT NULL DEFAULT 0,
			status VARCHAR(32) NOT NULL,
			date_created_gmt DATETIME NOT NULL,
			billing_first_name VARCHAR(100) NULL,
			billing_last_name VARCHAR(100) NULL,
			billing_phone VARCHAR(50) NULL,
			billing_email VARCHAR(190) NULL,
			billing_state VARCHAR(100) NULL,
			billing_city VARCHAR(100) NULL,
			billing_address_1 TEXT NULL,
			marketer_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			utm_source VARCHAR(150) NULL,
			utm_medium VARCHAR(150) NULL,
			utm_campaign VARCHAR(200) NULL,
			utm_term VARCHAR(200) NULL,
			utm_content VARCHAR(200) NULL,
			total DECIMAL(20,6) NOT NULL DEFAULT 0,
			currency VARCHAR(10) NULL,
			dashboard_version TINYINT UNSIGNED NOT NULL DEFAULT 0,
			dashboard_paid TINYINT UNSIGNED NOT NULL DEFAULT 0,
			dashboard_net_total DECIMAL(20,6) NOT NULL DEFAULT 0,
			dashboard_is_parent TINYINT UNSIGNED NOT NULL DEFAULT 0,
			dashboard_item_qty DECIMAL(20,6) NOT NULL DEFAULT 0,
			dashboard_item_name TEXT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY uniq_order_item (order_id, order_item_id),
			KEY idx_customer_date (customer_id, date_created_gmt),
			KEY idx_product_date (product_id, variation_id, date_created_gmt),
			KEY idx_status_date (status, date_created_gmt),
			KEY idx_marketer_date (marketer_id, date_created_gmt),
			KEY idx_dashboard_date (date_created_gmt, order_id),
			KEY idx_marketer_dashboard (marketer_id, date_created_gmt, order_id),
			KEY idx_phone (billing_phone),
			KEY idx_email (billing_email),
			KEY idx_state_city (billing_state, billing_city),
			KEY idx_utm_source (utm_source),
			KEY idx_utm_campaign (utm_campaign)
		) {$charset};";

		dbDelta( $sql );
	}

	public function on_order_saved( mixed $order, mixed $data_store = NULL ): void {
		if ( $order instanceof WC_Order ) {
			$this->sync_order( $order );
		}
	}

	public function on_status_changed( int $order_id, string $old_status, string $new_status, mixed $order ): void {
		$order = $order instanceof WC_Order ? $order : wc_get_order( $order_id );

		if ( $order instanceof WC_Order ) {
			$this->sync_order( $order );
		}
	}

	public function on_order_deleted( mixed $order ): void {
		$order_id = $order instanceof WC_Order ? $order->get_id() : absint( $order );

		if ( $order_id > 0 ) {
			$this->delete_order( $order_id );
		}
	}

	public function on_post_deleted( int $post_id ): void {
		if ( get_post_type( $post_id ) === 'shop_order' ) {
			$this->delete_order( $post_id );
		}
	}

	public function on_refund_deleted( int $refund_id, int $order_id ): void {
		$this->sync_order( $order_id );
	}

	public function sync_order( WC_Order|int $order ): bool|WP_Error {
		$order = is_int( $order ) ? wc_get_order( $order ) : $order;

		if ( ! $order instanceof WC_Order ) {
			return new WP_Error( 'kerp_order_index_invalid_order', __( 'سفارش معتبر نیست.', 'kasebi-erp' ) );
		}

		$order_id = (int) $order->get_id();
		$rows     = $this->build_rows( $order );

		$this->db->query( 'START TRANSACTION' );

		$deleted = $this->db->delete( $this->table, [ 'order_id' => $order_id ], [ '%d' ] );

		if ( $deleted === FALSE ) {
			$this->db->query( 'ROLLBACK' );

			return new WP_Error( 'kerp_order_index_delete_failed', $this->db->last_error );
		}

		foreach ( $rows as $row ) {
			if ( $this->db->insert( $this->table, $row ) === FALSE ) {
				$this->db->query( 'ROLLBACK' );

				$error = new WP_Error( 'kerp_order_index_insert_failed', $this->db->last_error );
				do_action( 'kerp_order_index_sync_failed', $order_id, $error );

				return $error;
			}
		}

		$this->db->query( 'COMMIT' );
		do_action( 'kerp_order_index_synced', $order_id, $rows );

		return TRUE;
	}

	public function delete_order( int $order_id ): bool {
		$result = $this->db->delete( $this->table, [ 'order_id' => $order_id ], [ '%d' ] );

		if ( $result !== FALSE ) {
			do_action( 'kerp_order_index_deleted', $order_id );
		}

		return $result !== FALSE;
	}

	private function build_rows( WC_Order $order ): array {
		// WooCommerce editor/checkout drafts are not sales or ERP pro-forma orders.
		if ( $order->has_status( [ 'auto-draft', 'checkout-draft', 'draft', 'trash' ] ) ) { return []; }
		// Exclude internal payment orders at the source, including index rebuilds and counts.
		if ( $order->get_created_via() === 'kerp_installment_payment' || $order->get_meta( '_kerp_installment_parent_order' ) ) { return []; }
		$order_id    = (int) $order->get_id();
		$customer_id = (int) $order->get_customer_id();
		$date        = $order->get_date_created();

		if ( $date instanceof WC_DateTime ) {
			$date = clone $date;
			$date->setTimezone( new DateTimeZone( 'UTC' ) );
			$date_created_gmt = $date->date( 'Y-m-d H:i:s' );
		} else {
			$date_created_gmt = current_time( 'mysql', TRUE );
		}

		$billing_first_name = (string) $order->get_billing_first_name();
		$billing_last_name  = (string) $order->get_billing_last_name();
		$billing_phone      = (string) $order->get_billing_phone();

		if ( $customer_id > 0 ) {
			$billing_first_name = $billing_first_name ?: (string) get_user_meta( $customer_id, 'first_name', TRUE );
			$billing_last_name  = $billing_last_name ?: (string) get_user_meta( $customer_id, 'last_name', TRUE );
			$billing_phone      = $billing_phone ?: (string) get_user_meta( $customer_id, 'nooshika_phone_num', TRUE );
		}

		$marketer_id = absint( $order->get_meta( 'marketer_id', TRUE ) );

		if ( $marketer_id === 0 && $customer_id > 0 ) {
			$marketer_id = absint( get_user_meta( $customer_id, 'user_marketer_id', TRUE ) );
		}

		$common = [
			'order_id'           => $order_id,
			'customer_id'        => $customer_id,
			'status'             => 'wc-' . str_replace( 'wc-', '', $order->get_status() ),
			'date_created_gmt'   => $date_created_gmt,
			'billing_first_name' => $billing_first_name ?: NULL,
			'billing_last_name'  => $billing_last_name ?: NULL,
			'billing_phone'      => $billing_phone ?: NULL,
			'billing_email'      => $order->get_billing_email() ?: NULL,
			'billing_state'      => $order->get_billing_state() ?: NULL,
			'billing_city'       => $order->get_billing_city() ?: NULL,
			'billing_address_1'  => $order->get_billing_address_1() ?: NULL,
			'marketer_id'        => $marketer_id,
			'utm_source'         => $order->get_meta( '_wc_order_attribution_utm_source', TRUE ) ?: NULL,
			'utm_medium'         => $order->get_meta( '_wc_order_attribution_utm_medium', TRUE ) ?: NULL,
			'utm_campaign'       => $order->get_meta( '_wc_order_attribution_utm_campaign', TRUE ) ?: NULL,
			'utm_term'           => $order->get_meta( '_wc_order_attribution_utm_term', TRUE ) ?: NULL,
			'utm_content'        => $order->get_meta( '_wc_order_attribution_utm_content', TRUE ) ?: NULL,
			'total'              => (float) $order->get_total(),
			'currency'           => strtoupper( (string) $order->get_currency() ) ?: NULL,
			'dashboard_version'  => 1,
			'dashboard_paid'     => (int) $order->is_paid(),
			'dashboard_net_total' => max( 0, (float) $order->get_total() - (float) $order->get_total_refunded() ),
			'dashboard_is_parent' => (int) (bool) $order->get_meta( '_kerp_installment_is_parent' ),
		];

		$rows = [];

		foreach ( $order->get_items( 'line_item' ) as $item ) {
			if ( ! $item instanceof WC_Order_Item_Product ) {
				continue;
			}

			$rows[] = array_merge(
				$common,
				[
					'order_item_id' => (int) $item->get_id(),
					'product_id'    => (int) $item->get_product_id(),
					'variation_id'  => (int) $item->get_variation_id(),
					'item_qty'      => (float) ( $item->get_meta( 'line_decimal_qty', TRUE ) ?: $item->get_quantity() ),
					'item_subtotal' => (float) $item->get_subtotal(),
					'item_total'    => (float) $item->get_total(),
					'dashboard_item_qty' => max( 0, (float) $item->get_quantity() + (float) $order->get_qty_refunded_for_item( $item->get_id() ) ),
					'dashboard_item_name' => $item->get_name(),
				]
			);
		}

		if ( empty( $rows ) ) {
			$rows[] = array_merge(
				$common,
				[
					'order_item_id' => 0,
					'product_id'    => 0,
					'variation_id'  => 0,
					'item_qty'      => 0,
					'item_subtotal' => 0,
					'item_total'    => 0,
				]
			);
		}

		return $rows;
	}

	public function find_orders( array $args = [] ): array {
		$defaults = [
			'per_page'     => 20,
			'page_number'  => 1,
			'status'       => '',
			'date'         => [ 'from' => '', 'to' => '' ],
			'search'       => '',
			'city'         => '',
			'state'        => '',
			'marketer_id'  => 0,
			'customer_id'  => 0,
			'product_id'   => 0,
			'variation_id' => 0,
			'product_ids'  => [],
			'utm'          => [],
			'utm_match'    => 'exact',
			'min_total'    => NULL,
			'max_total'    => NULL,
			'order_by'     => 'date',
			'order'        => 'DESC',
			'order_id'     => 0,
			'count_total'  => TRUE,
			'dashboard_batch' => FALSE,
			'before_date'  => '',
			'before_order' => 0,
		];
		$args = wp_parse_args( $args, $defaults );

		$where  = [ '1=1' ];
		$values = [];
		if ( $args['before_date'] !== '' && absint( $args['before_order'] ) > 0 ) {
			$where[] = '(date_created_gmt < %s OR (date_created_gmt = %s AND order_id < %d))';
			array_push( $values, (string) $args['before_date'], (string) $args['before_date'], absint( $args['before_order'] ) );
		}

		// Check the authoritative store so previously indexed drafts disappear without deleting orders.
		if ( class_exists( '\Automattic\WooCommerce\Utilities\OrderUtil' )
			&& \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled() ) {
			$where[] = "order_id NOT IN (SELECT id FROM {$this->db->prefix}wc_orders WHERE status IN (%s,%s,%s,%s,%s,%s,%s))";
		} else {
			$where[] = "order_id NOT IN (SELECT ID FROM {$this->db->posts} WHERE post_type = 'shop_order' AND post_status IN (%s,%s,%s,%s,%s,%s,%s))";
		}
		array_push( $values, 'trash', 'auto-draft', 'wc-auto-draft', 'draft', 'wc-draft', 'checkout-draft', 'wc-checkout-draft' );

		if ( absint( $args['order_id'] ) > 0 ) {
			$where[]  = 'order_id = %d';
			$values[] = absint( $args['order_id'] );
		}

		if ( absint( $args['customer_id'] ) > 0 ) {
			$where[]  = 'customer_id = %d';
			$values[] = absint( $args['customer_id'] );
		}

		$statuses = is_array( $args['status'] ) ? $args['status'] : [ $args['status'] ];
		$statuses = array_values( array_filter( array_map( [ $this, 'normalize_status' ], $statuses ) ) );

		if ( $statuses ) {
			$where[] = 'status IN (' . implode( ',', array_fill( 0, count( $statuses ), '%s' ) ) . ')';
			array_push( $values, ...$statuses );
		}

		$date = is_array( $args['date'] ) ? $args['date'] : [];

		if ( ! empty( $date['from'] ) ) {
			$where[]  = 'date_created_gmt >= %s';
			$values[] = $this->normalize_date_boundary( (string) $date['from'], FALSE );
		}

		if ( ! empty( $date['to'] ) ) {
			$where[]  = 'date_created_gmt <= %s';
			$values[] = $this->normalize_date_boundary( (string) $date['to'], TRUE );
		}

		foreach ( [ 'city' => 'billing_city', 'state' => 'billing_state' ] as $arg_key => $column ) {
			$value = sanitize_text_field( (string) $args[ $arg_key ] );
			if ( $value !== '' ) {
				$where[]  = "{$column} = %s";
				$values[] = $value;
			}
		}

		foreach ( [ 'marketer_id', 'product_id', 'variation_id' ] as $numeric_key ) {
			$value = absint( $args[ $numeric_key ] );
			if ( $value > 0 ) {
				$where[]  = "{$numeric_key} = %d";
				$values[] = $value;
			}
		}

		$product_ids = array_values( array_filter( array_map( 'absint', (array) $args['product_ids'] ) ) );
		if ( $product_ids ) {
			$placeholders = implode( ',', array_fill( 0, count( $product_ids ), '%d' ) );
			$where[]      = "(product_id IN ({$placeholders}) OR variation_id IN ({$placeholders}))";
			array_push( $values, ...$product_ids, ...$product_ids );
		}

		$sold_product = is_scalar( $args['sold_product'] ?? '' ) ? (string) ( $args['sold_product'] ?? '' ) : '';
		if ( $sold_product !== '' && $sold_product !== '0' ) {
			// Match the exact bestseller bucket, including variations and deleted products.
			if ( preg_match( '/^product-([1-9][0-9]*)$/', $sold_product, $match ) ) {
				$where[] = '(CASE WHEN variation_id > 0 THEN variation_id ELSE product_id END) = %d';
				$values[] = (int) $match[1];
			} elseif ( preg_match( '/^deleted-([a-f0-9]{32})$/', $sold_product, $match ) ) {
				$where[] = "variation_id = 0 AND product_id = 0 AND MD5(COALESCE(dashboard_item_name, '')) = %s";
				$values[] = $match[1];
			} else {
				$where[] = '1=0';
			}
			$where[] = 'dashboard_paid = 1 AND dashboard_is_parent = 0 AND order_item_id > 0 AND dashboard_item_qty > 0';
		}

		$utm_columns = [
			'source'   => 'utm_source',
			'medium'   => 'utm_medium',
			'campaign' => 'utm_campaign',
			'term'     => 'utm_term',
			'content'  => 'utm_content',
		];
		$utm = is_array( $args['utm'] ) ? $args['utm'] : [];

		foreach ( $utm_columns as $key => $column ) {
			$value = sanitize_text_field( (string) ( $utm[ $key ] ?? '' ) );
			if ( $value !== '' ) {
				$contains = $args['utm_match'] === 'contains';
				$where[]  = $contains ? "{$column} LIKE %s" : "{$column} = %s";
				$values[] = $contains ? '%' . $this->db->esc_like( $value ) . '%' : $value;
			}
		}

		if ( $args['min_total'] !== NULL && is_numeric( $args['min_total'] ) ) {
			$where[]  = 'total >= %f';
			$values[] = (float) $args['min_total'];
		}

		if ( $args['max_total'] !== NULL && is_numeric( $args['max_total'] ) ) {
			$where[]  = 'total <= %f';
			$values[] = (float) $args['max_total'];
		}

		$search = sanitize_text_field( (string) $args['search'] );
		if ( $search !== '' ) {
			$like      = '%' . $this->db->esc_like( $search ) . '%';
			$where[]   = '(CAST(order_id AS CHAR) LIKE %s OR billing_first_name LIKE %s OR billing_last_name LIKE %s OR billing_phone LIKE %s OR billing_email LIKE %s)';
			array_push( $values, $like, $like, $like, $like, $like );
		}

		$where_sql    = implode( ' AND ', $where );
		$per_page     = max( 1, min( 200, absint( $args['per_page'] ) ) );
		$page_number  = max( 1, absint( $args['page_number'] ) );
		$offset       = ( $page_number - 1 ) * $per_page;
		$order        = strtoupper( (string) $args['order'] ) === 'ASC' ? 'ASC' : 'DESC';
		$order_column = (string) $args['order_by'] === 'total' ? 'MAX(total)' : 'MAX(date_created_gmt)';

		$count_sql = "SELECT COUNT(DISTINCT order_id) FROM {$this->table} WHERE {$where_sql}";
		$from_sql = $this->table;
		$query_values = array_merge( $values, [ $per_page, $offset ] );
		if ( ! empty( $args['dashboard_batch'] ) && ! $args['count_total'] && $args['order_by'] === 'date' && $order === 'DESC' ) {
			// Limit indexed order keys BEFORE aggregating line-item rows. MAX(date)
			// over the whole period otherwise sorts every matching order per batch.
			$from_sql .= " INNER JOIN (
				SELECT DISTINCT order_id, date_created_gmt FROM {$this->table}
				WHERE {$where_sql}
				ORDER BY date_created_gmt DESC, order_id DESC
				LIMIT %d OFFSET %d
			) AS dashboard_orders USING (order_id, date_created_gmt)";
			$query_values = array_merge( $values, [ $per_page, $offset ], $values, [ $per_page, 0 ] );
		}
		$dashboard_columns = ! empty( $args['dashboard_batch'] )
			? ', MIN(dashboard_version) AS dashboard_version, MAX(dashboard_paid) AS dashboard_paid, MAX(dashboard_net_total) AS dashboard_net_total, MAX(dashboard_is_parent) AS dashboard_is_parent'
			: '';
		$query_sql = "SELECT
			order_id,
			MAX(customer_id) AS customer_id,
			MAX(status) AS status,
			MAX(date_created_gmt) AS date_created_gmt,
			MAX(billing_first_name) AS billing_first_name,
			MAX(billing_last_name) AS billing_last_name,
			MAX(billing_phone) AS billing_phone,
			MAX(billing_email) AS billing_email,
			MAX(billing_state) AS billing_state,
			MAX(billing_city) AS billing_city,
			MAX(marketer_id) AS marketer_id,
			MAX(total) AS total,
			MAX(currency) AS currency,
			SUM(item_qty) AS indexed_item_qty {$dashboard_columns}
			FROM {$from_sql}
			WHERE {$where_sql}
			GROUP BY order_id
			ORDER BY {$order_column} {$order}, order_id {$order}
			LIMIT %d OFFSET %d";

		$total_items = $args['count_total'] ? (int) $this->db->get_var( $this->prepare_query( $count_sql, $values ) ) : 0;
		$items        = $this->db->get_results( $this->prepare_query( $query_sql, $query_values ), ARRAY_A );

		return [
			'items'        => is_array( $items ) ? $items : [],
			'total_items'  => $total_items,
			'total_pages'  => (int) ceil( $total_items / $per_page ),
			'page_number' => $page_number,
			'per_page'     => $per_page,
		];
	}

	/** Upgrade only legacy rows already selected by the scoped dashboard query. */
	public function prepare_dashboard_rows( array $rows, float $deadline ): int {
		$prepared = 0;
		foreach ( $rows as $row ) {
			if ( (int) ( $row['dashboard_version'] ?? 0 ) === 1 ) { continue; }
			$order_id = absint( $row['order_id'] );
			$result = $this->sync_order( $order_id );
			if ( is_wp_error( $result ) ) {
				if ( $result->get_error_code() === 'kerp_order_index_invalid_order' ) {
					if ( ! $this->delete_order( $order_id ) ) { throw new RuntimeException( 'Could not remove stale indexed order.' ); }
				} else {
					throw new RuntimeException( 'Could not prepare indexed order analytics: ' . $result->get_error_message() );
				}
			}
			++$prepared;
			if ( microtime( TRUE ) >= $deadline ) { break; }
		}
		return $prepared;
	}

	/** IDs must come from a permission-scoped order query. No WooCommerce hydration. */
	public function dashboard_items( array $order_ids ): array {
		$ids = array_values( array_unique( array_filter( array_map( 'absint', $order_ids ) ) ) );
		if ( ! $ids ) { return []; }
		$placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
		$rows = $this->db->get_results( $this->db->prepare(
			"SELECT order_id, product_id, variation_id, dashboard_item_qty, dashboard_item_name
			FROM {$this->table} WHERE order_id IN ({$placeholders}) AND dashboard_version = 1 AND order_item_id > 0", ...$ids
		), ARRAY_A );
		if ( $this->db->last_error ) { throw new RuntimeException( 'Could not read indexed dashboard items.' ); }
		$grouped = [];
		foreach ( (array) $rows as $row ) { $grouped[ (int) $row['order_id'] ][] = $row; }
		return $grouped;
	}

	public function reindex_batch( int $page = 1, int $per_page = 100 ): array|WP_Error {
		if ( ! function_exists( 'wc_get_orders' ) ) {
			return new WP_Error( 'kerp_woocommerce_unavailable', __( 'ووکامرس فعال نیست.', 'kasebi-erp' ) );
		}

		$result = wc_get_orders(
			[
				'limit'    => max( 1, min( 500, $per_page ) ),
				'page'     => max( 1, $page ),
				'paginate' => TRUE,
				'return'   => 'ids',
				'orderby'  => 'ID',
				'order'    => 'ASC',
				'status'   => array_keys( wc_get_order_statuses() ),
			]
		);

		$indexed = 0;
		$failed  = [];

		foreach ( $result->orders ?? [] as $order_id ) {
			$sync = $this->sync_order( (int) $order_id );
			if ( is_wp_error( $sync ) ) {
				$failed[ (int) $order_id ] = $sync->get_error_message();
			} else {
				$indexed++;
			}
		}

		return [
			'indexed'    => $indexed,
			'failed'     => $failed,
			'total'      => (int) ( $result->total ?? 0 ),
			'max_pages'  => (int) ( $result->max_num_pages ?? 0 ),
			'current_page' => max( 1, $page ),
		];
	}

	private function normalize_status( mixed $status ): string {
		$status = sanitize_key( (string) $status );

		return $status !== '' ? 'wc-' . str_replace( 'wc-', '', $status ) : '';
	}

	private function normalize_date_boundary( string $date, bool $end_of_day ): string {
		$date = sanitize_text_field( $date );

		if ( strlen( $date ) <= 10 ) {
			$date .= $end_of_day ? ' 23:59:59' : ' 00:00:00';
		}

		return get_gmt_from_date( $date );
	}

	private function prepare_query( string $query, array $values ): string {
		return $values ? $this->db->prepare( $query, ...$values ) : $query;
	}
}
