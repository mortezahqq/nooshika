<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Core_Router {
	
	private static ?KERP_Core_Router $instance = NULL;
	
	public static function instance(): KERP_Core_Router {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {
		add_action( 'init', [ $this, 'register_rewrite_rules' ], 10 );
		add_filter( 'query_vars', [ $this, 'register_query_vars' ] );
	}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize singleton.' );
	}
	
	public function register_rewrite_rules(): void {
		add_rewrite_rule(
			'^erp(?:/(.*))?/?$',
			'index.php?pagename=erp&kerp_route=$matches[1]',
			'top'
		);
	}
	
	public function register_query_vars( array $query_vars ): array {
		if ( ! in_array( 'kerp_route', $query_vars, TRUE ) ) {
			$query_vars[] = 'kerp_route';
		}
		
		return $query_vars;
	}
	
	public function is_erp_request(): bool {
		if ( is_admin() ) {
			return FALSE;
		}
		
		$page_id = KERP_Install_Installer::get_page_id();
		
		if ( $page_id > 0 && is_page( $page_id ) ) {
			return TRUE;
		}
		
		if ( is_page( 'erp' ) || get_query_var( 'pagename' ) === 'erp' ) {
			return TRUE;
		}
		
		global $wp;
		
		$request = isset( $wp->request )
			? trim( rawurldecode( (string) $wp->request ), '/' )
			: '';
		
		$request = $this->remove_home_path( $request );
		
		return $request === 'erp' || str_starts_with( $request, 'erp/' );
	}
	
	public function get_route(): array {
		$route = (string) get_query_var( 'kerp_route', '' );
		
		if ( $route === '' ) {
			global $wp;
			
			$request = isset( $wp->request )
				? trim( rawurldecode( (string) $wp->request ), '/' )
				: '';
			
			$request = $this->remove_home_path( $request );
			
			if ( $request === 'erp' ) {
				$route = '';
			} elseif ( str_starts_with( $request, 'erp/' ) ) {
				$route = substr( $request, 4 );
			}
		}
		
		return $this->normalize_route_parts( $route );
	}
	
	public function get_current_url(): string {
		$fallback = '/erp/';
		
		if ( empty( $_SERVER['REQUEST_URI'] ) ) {
			return $fallback;
		}
		
		$request_uri   = wp_unslash( (string) $_SERVER['REQUEST_URI'] );
		$request_parts = wp_parse_url( $request_uri );
		
		if ( ! is_array( $request_parts ) || empty( $request_parts['path'] ) ) {
			return $fallback;
		}
		
		$request_path = '/' . ltrim( rawurldecode( (string) $request_parts['path'] ), '/' );
		$home_path    = trim(
			(string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ),
			'/'
		);
		
		if ( $home_path !== '' ) {
			$home_prefix = '/' . $home_path;
			
			if ( $request_path === $home_prefix ) {
				$request_path = '/';
			} elseif ( str_starts_with( $request_path, $home_prefix . '/' ) ) {
				$request_path = '/' . ltrim(
						substr( $request_path, strlen( $home_prefix ) ),
						'/'
					);
			}
		}
		
		if ( $request_path === '/erp' ) {
			$request_path = $fallback;
		} elseif ( ! str_starts_with( $request_path, '/erp/' ) ) {
			return $fallback;
		}
		
		if ( ! empty( $request_parts['query'] ) ) {
			$request_path .= '?' . (string) $request_parts['query'];
		}
		
		return wp_validate_redirect( $request_path, $fallback );
	}
	
	public function resolve( string $input = '' ): array {
		$query = [];
		
		if ( $input === '' ) {
			$parts = $this->get_route();
			
			if ( ! empty( $_SERVER['REQUEST_URI'] ) ) {
				$current_url = wp_parse_url(
					wp_unslash( (string) $_SERVER['REQUEST_URI'] )
				);
				
				if ( is_array( $current_url ) && ! empty( $current_url['query'] ) ) {
					wp_parse_str( (string) $current_url['query'], $query );
				}
			}
		} else {
			$parsed = wp_parse_url( $input );
			
			if ( ! is_array( $parsed ) ) {
				return [];
			}
			
			if ( ! empty( $parsed['query'] ) ) {
				wp_parse_str( (string) $parsed['query'], $query );
			}
			
			$path = trim(
				rawurldecode( (string) ( $parsed['path'] ?? '' ) ),
				'/'
			);
			
			$path = $this->remove_home_path( $path );
			
			if ( $path === 'erp' ) {
				$path = '';
			} elseif ( str_starts_with( $path, 'erp/' ) ) {
				$path = substr( $path, 4 );
			}
			
			$parts = $this->normalize_route_parts( $path );
		}
		
		return $this->resolve_parts( $parts, $query );
	}
	
	public function resolve_parts( array $parts, array $query = [] ): array {
		$parts = $this->normalize_route_parts( $parts );
		$pages = KERP_App::instance()->get_registered_pages();
		
		if ( empty( $parts ) ) {
			$definition = isset( $pages['dashboard'] ) && is_array( $pages['dashboard'] )
				? $pages['dashboard']
				: [];
			
			return $this->build_resolved_route(
				'dashboard',
				$definition,
				[],
				$query,
				[],
				! empty( $definition )
			);
		}
		
		$matched_page       = '';
		$matched_definition = [];
		$matched_params     = [];
		$matched_score      = - 1;
		
		foreach ( $pages as $page_key => $definition ) {
			if ( ! is_array( $definition ) ) {
				continue;
			}
			
			$pattern = $this->get_page_pattern( (string) $page_key, $definition );
			$match   = $this->match_pattern( $pattern, $parts );
			
			if ( $match === NULL || $match['score'] <= $matched_score ) {
				continue;
			}
			
			$matched_page       = sanitize_key( (string) $page_key );
			$matched_definition = $definition;
			$matched_params     = $match['params'];
			$matched_score      = $match['score'];
		}
		
		if ( $matched_page === '' ) {
			// Older ERP controls send a registered page key, while navigation sends
			// its route. Resolve both through the same definition (never guess IDs).
			if ( count( $parts ) === 1 && isset( $pages[ $parts[0] ] ) ) {
				$key = $parts[0];
				$pattern = $this->get_page_pattern( $key, $pages[ $key ] );
				if ( ! str_contains( implode( '/', $pattern ), '{' ) ) {
					return $this->build_resolved_route( $key, $pages[ $key ], $pattern, $query, [], TRUE );
				}
			}
			return $this->build_resolved_route(
				sanitize_key( (string) $parts[0] ),
				[],
				$parts,
				$query,
				[],
				FALSE
			);
		}
		
		return $this->build_resolved_route(
			$matched_page,
			$matched_definition,
			$parts,
			$query,
			$matched_params,
			TRUE
		);
	}
	
	private function get_page_pattern( string $page_key, array $definition ): array {
		if ( array_key_exists( 'route', $definition ) ) {
			$route = trim( (string) $definition['route'], '/' );
		} else {
			$route = $page_key === 'dashboard' ? '' : $page_key;
		}
		
		if ( $route === '' ) {
			return [];
		}
		
		return array_values(
			array_filter(
				array_map(
					static fn( string $part ): string => trim( rawurldecode( $part ) ),
					explode( '/', $route )
				),
				static fn( string $part ): bool => $part !== ''
			)
		);
	}
	
	private function match_pattern( array $pattern, array $parts ): ?array {
		if ( count( $pattern ) !== count( $parts ) ) {
			return NULL;
		}
		
		$params       = [];
		$static_parts = 0;
		
		foreach ( $pattern as $index => $pattern_part ) {
			$route_part = (string) ( $parts[ $index ] ?? '' );
			
			if ( preg_match( '/^\{([A-Za-z][A-Za-z0-9_-]*)\}$/', $pattern_part, $matches ) ) {
				$param_key = sanitize_key( (string) $matches[1] );
				
				if ( $param_key === '' || $route_part === '' ) {
					return NULL;
				}
				
				if (
					( $param_key === 'id' || str_ends_with( $param_key, '_id' ) ) &&
					! preg_match( '/^\d+$/D', $route_part )
				) {
					return NULL;
				}
				
				$params[ $param_key ] = (
					$param_key === 'id' || str_ends_with( $param_key, '_id' )
				)
					? absint( $route_part )
					: $route_part;
				
				continue;
			}
			
			if ( sanitize_title( $pattern_part ) !== $route_part ) {
				return NULL;
			}
			
			$static_parts ++;
		}
		
		return [
			'params' => $params,
			'score'  => ( $static_parts * 1000 ) + count( $pattern ),
		];
	}
	
	private function build_resolved_route(
		string $page,
		array $definition,
		array $parts,
		array $query,
		array $params,
		bool $found
	): array {
		$type = sanitize_key( (string) ( $definition['type'] ?? 'page' ) );
		
		if ( $type === '' ) {
			$type = 'page';
		}
		
		$id = NULL;
		
		if ( isset( $params['id'] ) ) {
			$id = absint( $params['id'] );
		} elseif (
			isset( $parts[1] ) &&
			preg_match( '/^\d+$/D', (string) $parts[1] )
		) {
			$id = absint( $parts[1] );
		}
		
		return [
			'page'       => $page,
			'id'         => $id,
			'parts'      => $parts,
			'query'      => $query,
			'type'       => $type,
			'params'     => $params,
			'definition' => $definition,
			'found'      => $found,
		];
	}
	
	private function normalize_route_parts( array|string $route ): array {
		$parts = is_array( $route )
			? $route
			: explode( '/', trim( $route, '/' ) );
		
		$normalized = [];
		
		foreach ( $parts as $part ) {
			$part = sanitize_title( rawurldecode( trim( (string) $part ) ) );
			
			if ( $part !== '' ) {
				$normalized[] = $part;
			}
		}
		
		return $normalized;
	}
	
	private function remove_home_path( string $path ): string {
		$path      = trim( $path, '/' );
		$home_path = trim(
			(string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ),
			'/'
		);
		
		if ( $home_path === '' ) {
			return $path;
		}
		
		if ( $path === $home_path ) {
			return '';
		}
		
		if ( str_starts_with( $path, $home_path . '/' ) ) {
			return trim( substr( $path, strlen( $home_path ) ), '/' );
		}
		
		return $path;
	}
	
}
