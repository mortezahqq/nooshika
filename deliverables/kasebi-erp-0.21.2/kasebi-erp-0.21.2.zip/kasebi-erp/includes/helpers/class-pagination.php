<?php
final class KERP_Helpers_Pagination {
	public static function resolve_per_page(
		string $key,
		array $query,
		int $default = 20,
		int $max = 500
	): int {
		$key      = sanitize_key( $key );
		$meta_key = "kerp_{$key}_per_page";
		$user_id  = get_current_user_id();
		
		$default = max( 1, min( $max, $default ) );
		
		$saved = $user_id > 0
			? absint( get_user_meta( $user_id, $meta_key, TRUE ) )
			: 0;
		
		$per_page = $saved > 0
			? $saved
			: $default;
		
		if ( isset( $query['per_page'] ) && absint( $query['per_page'] ) > 0 ) {
			$per_page = absint( $query['per_page'] );
			$per_page = max( 1, min( $max, $per_page ) );
			
			if ( $user_id > 0 ) {
				update_user_meta( $user_id, $meta_key, $per_page );
			}
		}
		
		return max( 1, min( $max, $per_page ) );
	}
}