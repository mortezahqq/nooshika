<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Helpers_Template {

	/** Render monetary values through the main plugin's shared price component.
	 * Currency is a display label only; amounts are never converted here.
	 */
	public static function price( mixed $amount, array $args = [], ?float $regular_price = NULL ): string {
		if ( $amount === NULL ) {
			return '—';
		}
		$amount = (float) $amount;
		$args['currency'] = $args['currency'] ?? get_woocommerce_currency();
		if ( ! function_exists( 'nooshika_get_template' ) ) {
			return wp_kses_post( wc_price( $amount, $args ) );
		}
		$html = (string) nooshika_get_template( 'components/price.php', [
			'price' => [ 'price' => $amount, 'regular_price' => $regular_price ?? $amount ],
		] );
		// Inline elements keep the component valid inside labels, buttons and paragraphs.
		$html = str_replace( [ '<div', '</div>', 'price_box_container price_direction_top' ], [ '<span', '</span>', 'price_box_container price_direction_top kerp-price' ], $html );
		if ( ! empty( $args['currency'] ) ) {
			$html = preg_replace_callback( '/(<span class="currency">).*?(<\/span>)/u', static fn( $match ) => $match[1] . esc_html( get_woocommerce_currency_symbol( $args['currency'] ) ) . $match[2], $html );
		}
		return wp_kses_post( $html );
	}

	
	/**
	 * دریافت مسیر کامل قالب.
	 *
	 * @param   string  $template  مسیر نسبی قالب از پوشه templates.
	 * @param   array   $args      داده‌های ارسالی به قالب.
	 *
	 * @return string|false
	 */
	public static function get_template_path( string $template, array $args = [] ): string|false {
		$template = wp_normalize_path( $template );
		$template = ltrim( $template, '/\\' );
		
		/*
		 * جلوگیری از دسترسی به مسیرهای خارج از پوشه قالب‌ها.
		 */
		if (
			$template === '' ||
			str_contains( $template, '../' ) ||
			str_contains( $template, '..\\' )
		) {
			return FALSE;
		}
		
		$template_path = KERP_TEMPLATES_PATH . $template;
		
		/**
		 * امکان تغییر مسیر قالب توسط ماژول‌ها یا قالب وردپرس.
		 */
		$template_path = apply_filters(
			'kerp_template_path',
			$template_path,
			$template,
			$args
		);
		
		if (
			! is_string( $template_path ) ||
			! is_readable( $template_path )
		) {
			return FALSE;
		}
		
		return $template_path;
	}
	
	/**
	 * دریافت خروجی رندرشده قالب.
	 *
	 * @param   string  $template  مسیر نسبی قالب.
	 * @param   array   $args      متغیرهای قابل استفاده در قالب.
	 *
	 * @return string|false
	 */
	public static function get_template( string $template, array $args = [] ): string|false {
		$template_path = self::get_template_path( $template, $args );
		
		if ( $template_path === FALSE ) {
			return FALSE;
		}
		
		if ( ! empty( $args ) ) {
			extract( $args, EXTR_SKIP );
		}
		
		ob_start();
		
		include $template_path;
		
		return (string) ob_get_clean();
	}
	
	/**
	 * نمایش مستقیم قالب.
	 *
	 * @param   string  $template  مسیر نسبی قالب.
	 * @param   array   $args      متغیرهای قابل استفاده در قالب.
	 */
	public static function render_template( string $template, array $args = [] ): void {
		$output = self::get_template( $template, $args );
		
		if ( $output === FALSE ) {
			return;
		}
		
		echo $output;
	}
	
	/**
	 * دریافت خروجی قالب یک ماژول.
	 *
	 * مسیر نهایی:
	 * templates/modules/{module}/{template}
	 */
	public static function get_module_template(
		string $module,
		string $template,
		array $args = []
	): string|false {
		$module   = trim( wp_normalize_path( $module ), '/\\' );
		$template = trim( wp_normalize_path( $template ), '/\\' );
		
		if ( $module === '' || $template === '' ) {
			return FALSE;
		}
		
		return self::get_template(
			'modules/' . $module . '/' . $template,
			$args
		);
	}
	
	/**
	 * نمایش قالب یک ماژول.
	 */
	public static function render_module_template(
		string $module,
		string $template,
		array $args = []
	): void {
		$output = self::get_module_template( $module, $template, $args );
		
		if ( $output === FALSE ) {
			return;
		}
		
		echo $output; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
	
	public static function render_modal( array $modal ): void {
		$modal = wp_parse_args(
			$modal,
			[
				'type'        => 'form',
				'id'          => '',
				'title'       => '',
				'action'      => '',
				'page'        => '',
				'button'      => __( 'ثبت', 'kasebi-erp' ),
				'button_text' => '',
				'size'        => 'lg',
				'class'       => '',
				'fields'      => [],
				'body'        => '',
				'footer'      => '',
			]
		);
		
		$modal['id'] = sanitize_html_class(
			(string) $modal['id']
		);
		
		if ( $modal['id'] === '' ) {
			return;
		}
		
		$modal['type'] = sanitize_key(
			(string) $modal['type']
		);
		
		if ( ! in_array( $modal['type'], [ 'form', 'context' ], TRUE ) ) {
			$modal['type'] = 'form';
		}
		
		$modal['size'] = sanitize_key(
			(string) $modal['size']
		);
		
		if ( ! in_array( $modal['size'], [ 'sm', 'md', 'lg', 'xl' ], TRUE ) ) {
			$modal['size'] = 'lg';
		}
		
		if ( empty( $modal['class'] ) ) {
			$modal['class'] = 'modal-' . $modal['size'];
		}
		
		$modal['class'] = implode(
			' ',
			array_filter(
				array_map(
					'sanitize_html_class',
					preg_split(
						'/\s+/',
						(string) $modal['class']
					)
				)
			)
		);
		
		if (
			empty( $modal['button'] ) &&
			! empty( $modal['button_text'] )
		) {
			$modal['button'] = $modal['button_text'];
		}
		
		if ( ! is_array( $modal['fields'] ) ) {
			$modal['fields'] = [];
		}
		
		$template = $modal['type'] === 'context'
			? 'app/components/modal-context.php'
			: 'app/components/modal-form.php';
		
		$template = apply_filters(
			'kerp_modal_template',
			$template,
			$modal
		);
		
		self::render_template(
			$template,
			$modal
		);
	}
	
}