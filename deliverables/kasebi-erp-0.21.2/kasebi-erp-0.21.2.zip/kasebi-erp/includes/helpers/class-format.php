<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Helpers_Format {

	/**
	 * تبدیل ارقام فارسی، انگلیسی و عربی به قالب درخواستی.
	 *
	 * @param string|array $value  مقدار ورودی.
	 * @param string       $format قالب مقصد: en، fa یا ar.
	 *
	 * @return string|array
	 */
	public static function sanitize_numbers( string|array $value, string $format = 'en' ): string|array {
		$chars = [
			'fa' => [ '۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹' ],
			'en' => [ '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' ],
			'ar' => [ '٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩' ],
		];

		if ( ! isset( $chars[ $format ] ) ) {
			$format = 'en';
		}

		$numbers = $chars[ $format ];
		unset( $chars[ $format ] );

		foreach ( $chars as $char ) {
			$value = str_replace( $char, $numbers, $value );
		}

		return $value;
	}

	/**
	 * تفکیک نام کامل به نام و نام خانوادگی.
	 *
	 * @return array{first:string,last:string}
	 */
	public static function split_first_last_name( string $name ): array {
		$normalized_name = preg_replace( '/\s+/u', ' ', trim( $name ) );
		$name            = is_string( $normalized_name ) ? trim( $normalized_name ) : '';

		if ( $name === '' ) {
			return [
				'first' => '',
				'last'  => '',
			];
		}

		$parts = explode( ' ', $name );
		$first = array_shift( $parts ) ?: '';

		return [
			'first' => $first,
			'last'  => implode( ' ', $parts ),
		];
	}

	/**
	 * فشرده‌سازی آرایه برای نگهداری یا انتقال کوتاه‌تر.
	 */
	public static function minify_array( array $array ): string {
		$compressed = gzcompress( serialize( $array ), 9 );

		if ( $compressed === FALSE ) {
			return '';
		}

		return strtr(
			base64_encode( addslashes( $compressed ) ),
			'+/=',
			'-_,'
		);
	}

	/**
	 * بازکردن مقدار ساخته‌شده با minify_array().
	 *
	 * داده‌های خراب یا دست‌کاری‌شده بدون ایجاد Warning/TypeError به آرایه خالی
	 * تبدیل می‌شوند. ساخت Object نیز هنگام unserialize مجاز نیست.
	 */
	public static function unminify_string( string $string ): array {
		if ( $string === '' ) {
			return [];
		}

		$decoded = base64_decode( strtr( $string, '-_,', '+/=' ), TRUE );

		if ( $decoded === FALSE ) {
			return [];
		}

		$uncompressed = @gzuncompress( stripslashes( $decoded ) );

		if ( $uncompressed === FALSE ) {
			return [];
		}

		$data = @unserialize( $uncompressed, [ 'allowed_classes' => FALSE ] );

		return is_array( $data ) ? $data : [];
	}
}
