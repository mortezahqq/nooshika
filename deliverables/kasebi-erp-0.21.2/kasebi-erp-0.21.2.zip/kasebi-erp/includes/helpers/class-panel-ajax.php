<?php
defined( 'ABSPATH' ) || exit;

/** Dependencies needed by ERP modules on the customer panel's lightweight endpoint. */
final class KERP_Helpers_Panel_Ajax {
	public static function ensure_dependencies( bool $payments = FALSE ): void {
		if ( ! function_exists( 'n_ajax_get_current_page_basename' ) ) { return; }
		$allowed = (array) get_option( 'nooshika_ajax_active_plugins', [] );
		$required = [ KERP_BASENAME, 'woocommerce/woocommerce.php', 'woo-wallet/woo-wallet.php' ];
		if ( $payments && function_exists( 'WC' ) && WC() ) {
			$method = (string) apply_filters( 'kerp_wallet_charge_payment_method', get_option( 'nooshika_landing_payment_method', 'WC_ZPal' ) );
			$gateways = WC()->payment_gateways()->payment_gateways();
			$gateway = $gateways[ $method ] ?? NULL;
			if ( is_object( $gateway ) ) {
				// Include the selected gateway and any plugin providing its base class.
				$active = (array) get_option( 'active_plugins', [] );
				$reflection = new ReflectionClass( $gateway );
				do {
					$file = $reflection->getFileName();
					if ( ! $file ) { continue; }
					$file = plugin_basename( $file );
					foreach ( $active as $plugin ) {
						if ( ! is_string( $plugin ) ) { continue; }
						$directory = dirname( $plugin );
						if ( $file === $plugin || ( $directory !== '.' && str_starts_with( $file, $directory . '/' ) ) ) { $required[] = $plugin; }
					}
				} while ( $reflection = $reflection->getParentClass() );
			}
		}
		$updated = array_values( array_unique( array_merge( $allowed, $required ) ) );
		if ( $updated !== $allowed ) { update_option( 'nooshika_ajax_active_plugins', $updated ); }
	}
}
