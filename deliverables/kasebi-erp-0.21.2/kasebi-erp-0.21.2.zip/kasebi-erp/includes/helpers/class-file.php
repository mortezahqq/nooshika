<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Helpers_File {
	
	private static ?self $instance = NULL;
	
	private function __construct() {}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new RuntimeException( 'Cannot unserialize singleton.' );
	}
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	/**
	 * ذخیره فایل معمولی یا فایل آپلودشده به‌صورت chunk.
	 *
	 * کلیدهای قابل استفاده در $ctx:
	 * - file_name
	 * - dzuuid
	 * - dzchunkindex
	 * - dztotalchunkcount
	 * - dztotalfilesize
	 * - direct
	 *
	 * @param   array   $file    مقدار متناظر فایل در $_FILES.
	 * @param   string  $folder  پوشه مقصد داخل uploads.
	 * @param   array   $ctx     اطلاعات تکمیلی آپلود.
	 *
	 * @return array{ok:bool,url:string,name:string,msg:string,storage:string}
	 */
	public function handle_upload_file( array $file, string $folder, array $ctx = [] ): array {
		$validation = $this->validate_uploaded_file( $file );
		
		if ( $validation !== '' ) {
			return $this->response( FALSE, '', '', $validation, 'none' );
		}
		
		$folder = $this->sanitize_folder( $folder );
		
		if ( $folder === '' ) {
			return $this->response( FALSE, '', '', 'پوشه مقصد معتبر نیست.', 'none' );
		}
		
		$original_name = wp_basename( (string) $file['name'] );
		$allowed_mimes = $this->get_allowed_mimes();
		$file_type     = wp_check_filetype( $original_name, $allowed_mimes );
		$ext           = strtolower( (string) ( $file_type['ext'] ?? '' ) );
		$mime_type     = (string) ( $file_type['type'] ?? '' );
		
		if ( $ext === '' || $mime_type === '' ) {
			return $this->response( FALSE, '', '', 'پسوند فایل مجاز نیست.', 'none' );
		}
		
		$upload_dir = wp_upload_dir();
		
		if ( ! empty( $upload_dir['error'] ) ) {
			return $this->response(
				FALSE,
				'',
				'',
				'دسترسی به پوشه آپلود وردپرس ممکن نیست: ' . sanitize_text_field( (string) $upload_dir['error'] ),
				'none'
			);
		}
		
		$basedir = trailingslashit( (string) $upload_dir['basedir'] );
		$baseurl = trailingslashit( (string) $upload_dir['baseurl'] );
		
		$local_dir = wp_normalize_path( $basedir . $folder );
		$local_url = trailingslashit( $baseurl . $folder );
		
		if ( ! wp_mkdir_p( $local_dir ) || ! is_dir( $local_dir ) || ! is_writable( $local_dir ) ) {
			return $this->response( FALSE, '', '', 'پوشه مقصد قابل ساخت یا قابل نوشتن نیست.', 'none' );
		}
		
		$chunk_index  = isset( $ctx['dzchunkindex'] ) ? (int) $ctx['dzchunkindex'] : - 1;
		$total_chunks = isset( $ctx['dztotalchunkcount'] ) ? (int) $ctx['dztotalchunkcount'] : - 1;
		$is_chunked   = $chunk_index >= 0 || $total_chunks >= 0;
		
		if ( $is_chunked && ( $chunk_index < 0 || $total_chunks < 1 || $chunk_index >= $total_chunks ) ) {
			return $this->response( FALSE, '', '', 'اطلاعات چانک معتبر نیست.', 'none' );
		}
		
		$base_name = $this->resolve_base_name( $original_name, $ctx );
		
		if ( ! $is_chunked ) {
			$verified_type = wp_check_filetype_and_ext(
				(string) $file['tmp_name'],
				$original_name,
				$allowed_mimes
			);
			if ( $ext === 'rar' && ( empty( $verified_type['ext'] ) || empty( $verified_type['type'] ) ) && $this->has_rar_signature( (string) $file['tmp_name'] ) ) {
				$verified_type = [ 'ext' => 'rar', 'type' => 'application/vnd.rar' ];
			}
			
			if ( empty( $verified_type['ext'] ) || empty( $verified_type['type'] ) ) {
				return $this->response( FALSE, '', '', 'نوع فایل قابل تأیید نیست.', 'none' );
			}
			
			$saved_name       = $this->build_saved_name( $local_dir, $base_name, $ext );
			$local_final_path = trailingslashit( $local_dir ) . $saved_name;
			$local_final_url  = $local_url . rawurlencode( $saved_name );
			
			if ( ! $this->move_uploaded_file( (string) $file['tmp_name'], $local_final_path ) ) {
				return $this->response( FALSE, '', '', 'آپلود ناموفق بود.', 'none' );
			}
			
			$this->set_file_permissions( $local_final_path );
			
			return $this->response(
				TRUE,
				$local_final_url,
				$saved_name,
				'فایل ذخیره شد.',
				'local'
			);
		}
		
		$dzuuid = isset( $ctx['dzuuid'] )
			? sanitize_text_field( (string) $ctx['dzuuid'] )
			: '';
		
		if ( $dzuuid === '' ) {
			$dzuuid = wp_generate_uuid4();
		}
		
		$tmp_root   = wp_normalize_path( $basedir . 'panel_manager-tmp' );
		$chunks_dir = wp_normalize_path( $tmp_root . '/chunks/' . md5( $dzuuid ) );
		$merge_dir  = wp_normalize_path( $tmp_root . '/merged' );
		
		if (
			! wp_mkdir_p( $chunks_dir ) ||
			! wp_mkdir_p( $merge_dir ) ||
			! is_writable( $chunks_dir ) ||
			! is_writable( $merge_dir )
		) {
			return $this->response( FALSE, '', '', 'پوشه موقت آپلود قابل نوشتن نیست.', 'none' );
		}
		
		$saved_name = $this->resolve_chunk_saved_name(
			$chunks_dir,
			$local_dir,
			$base_name,
			$ext,
			$original_name
		);
		
		if ( $saved_name === '' ) {
			return $this->response( FALSE, '', '', 'ساخت نام فایل نهایی ناموفق بود.', 'none' );
		}
		
		$chunk_path = $chunks_dir . '/chunk_' . sprintf( '%06d', $chunk_index ) . '.part';
		
		if ( ! $this->move_uploaded_file( (string) $file['tmp_name'], $chunk_path ) ) {
			return $this->response( FALSE, '', $saved_name, 'ذخیره چانک ناموفق بود.', 'none' );
		}
		
		$merge_lock = fopen( $chunks_dir . '/.merge.lock', 'c' );
		
		if ( ! is_resource( $merge_lock ) ) {
			return $this->response( FALSE, '', $saved_name, 'ایجاد قفل ادغام ناموفق بود.', 'none' );
		}
		
		if ( ! flock( $merge_lock, LOCK_EX ) ) {
			fclose( $merge_lock );
			
			return $this->response( FALSE, '', $saved_name, 'قفل‌کردن عملیات ادغام ناموفق بود.', 'none' );
		}
		
		if ( ! $this->all_chunks_exist( $chunks_dir, $total_chunks ) ) {
			flock( $merge_lock, LOCK_UN );
			fclose( $merge_lock );
			
			return $this->response( TRUE, '', $saved_name, 'چانک دریافت شد.', 'chunk' );
		}
		
		@set_time_limit( 0 );
		@ini_set( 'max_execution_time', '0' );
		@ignore_user_abort( TRUE );
		
		$merged_path = $merge_dir . '/' . $saved_name;
		$merge_error = $this->merge_chunks( $chunks_dir, $total_chunks, $merged_path );
		
		if ( $merge_error !== '' ) {
			flock( $merge_lock, LOCK_UN );
			fclose( $merge_lock );
			
			return $this->response( FALSE, '', $saved_name, $merge_error, 'none' );
		}
		
		$verified_type = wp_check_filetype_and_ext(
			$merged_path,
			$original_name,
			$allowed_mimes
		);
		
		if ( empty( $verified_type['ext'] ) || empty( $verified_type['type'] ) ) {
			@unlink( $merged_path );
			$this->cleanup_chunks( $chunks_dir, $total_chunks );
			flock( $merge_lock, LOCK_UN );
			fclose( $merge_lock );
			
			return $this->response( FALSE, '', $saved_name, 'نوع فایل نهایی قابل تأیید نیست.', 'none' );
		}
		
		$expected_size = isset( $ctx['dztotalfilesize'] ) ? absint( $ctx['dztotalfilesize'] ) : 0;
		$actual_size   = file_exists( $merged_path ) ? (int) filesize( $merged_path ) : 0;
		
		if ( $expected_size > 0 && $actual_size !== $expected_size ) {
			@unlink( $merged_path );
			$this->cleanup_chunks( $chunks_dir, $total_chunks );
			flock( $merge_lock, LOCK_UN );
			fclose( $merge_lock );
			
			return $this->response( FALSE, '', $saved_name, 'حجم فایل نهایی با حجم مورد انتظار مطابقت ندارد.', 'none' );
		}
		
		$direct = filter_var( $ctx['direct'] ?? FALSE, FILTER_VALIDATE_BOOLEAN );
		
		if ( ! $direct ) {
			$ftp_result = $this->try_ftp_upload_from_local_path(
				$merged_path,
				$saved_name,
				$folder,
				$original_name
			);
			
			if ( ! empty( $ftp_result['ok'] ) ) {
				@unlink( $merged_path );
				$this->cleanup_chunks( $chunks_dir, $total_chunks );
				flock( $merge_lock, LOCK_UN );
				fclose( $merge_lock );
				
				return wp_parse_args( $ftp_result, [
					'ok'      => TRUE,
					'url'     => '',
					'name'    => $saved_name,
					'msg'     => 'فایل ذخیره شد.',
					'storage' => 'ftp',
				] );
			}
		}
		
		$local_final_path = trailingslashit( $local_dir ) . $saved_name;
		$local_final_url  = $local_url . rawurlencode( $saved_name );
		
		@unlink( $local_final_path );
		
		if ( $this->move_local_file( $merged_path, $local_final_path ) ) {
			$this->set_file_permissions( $local_final_path );
			$this->cleanup_chunks( $chunks_dir, $total_chunks );
			
			flock( $merge_lock, LOCK_UN );
			fclose( $merge_lock );
			
			return $this->response(
				TRUE,
				$local_final_url,
				$saved_name,
				$direct
					? 'فایل روی هاست اصلی ذخیره شد.'
					: 'FTP در دسترس نبود؛ فایل روی هاست اصلی ذخیره شد.',
				'local'
			);
		}
		
		@unlink( $merged_path );
		$this->cleanup_chunks( $chunks_dir, $total_chunks );
		flock( $merge_lock, LOCK_UN );
		fclose( $merge_lock );
		
		return $this->response(
			FALSE,
			'',
			$saved_name,
			'ساخت فایل انجام شد اما ذخیره نهایی محلی ناموفق بود.',
			'none'
		);
	}
	
	private function validate_uploaded_file( array $file ): string {
		if ( ! isset( $file['tmp_name'], $file['name'] ) ) {
			return 'فایل معتبر نیست.';
		}
		
		$error = isset( $file['error'] ) ? (int) $file['error'] : UPLOAD_ERR_OK;
		
		if ( $error !== UPLOAD_ERR_OK ) {
			return $this->get_upload_error_message( $error );
		}
		
		$tmp_name = (string) $file['tmp_name'];
		
		if ( $tmp_name === '' || ! is_uploaded_file( $tmp_name ) ) {
			return 'فایل معتبر نیست.';
		}
		
		return '';
	}
	
	private function get_upload_error_message( int $error ): string {
		return match ( $error ) {
			UPLOAD_ERR_INI_SIZE,
			UPLOAD_ERR_FORM_SIZE => 'حجم فایل بیشتر از حد مجاز است.',
			UPLOAD_ERR_PARTIAL => 'فایل به‌صورت ناقص دریافت شد.',
			UPLOAD_ERR_NO_FILE => 'فایلی ارسال نشده است.',
			UPLOAD_ERR_NO_TMP_DIR => 'پوشه موقت سرور در دسترس نیست.',
			UPLOAD_ERR_CANT_WRITE => 'نوشتن فایل روی دیسک ناموفق بود.',
			UPLOAD_ERR_EXTENSION => 'آپلود فایل توسط یکی از افزونه‌های PHP متوقف شد.',
			default => 'آپلود فایل ناموفق بود.',
		};
	}
	
	private function get_allowed_mimes(): array {
		$allowed_mimes = [
			'jpg|jpeg|jpe'   => 'image/jpeg',
			'png'            => 'image/png',
			'webp'           => 'image/webp',
			'gif'            => 'image/gif',
			'mp4|m4v'        => 'video/mp4',
			'mov|qt'         => 'video/quicktime',
			'3gp|3gpp'       => 'video/3gpp',
			'mkv'            => 'video/x-matroska',
			'zip'            => 'application/zip',
			'rar'            => 'application/vnd.rar',
			'pdf'            => 'application/pdf',
			'doc'            => 'application/msword',
			'docx'           => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
			'xls'            => 'application/vnd.ms-excel',
			'xlsx'           => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
			'txt|asc|c|cc|h' => 'text/plain',
			'mp3|m4a|m4b'    => 'audio/mpeg',
			'ogg|oga'        => 'audio/ogg',
		];
		
		/**
		 * فیلتر MIME Typeهای مجاز در آپلود KERP.
		 *
		 * @param   array  $allowed_mimes
		 */
		return (array) apply_filters( 'kerp_file_allowed_mimes', $allowed_mimes );
	}

	private function has_rar_signature( string $path ): bool {
		$handle = @fopen( $path, 'rb' );
		if ( ! is_resource( $handle ) ) { return FALSE; }
		$header = fread( $handle, 8 );
		fclose( $handle );
		return is_string( $header ) && ( str_starts_with( $header, "Rar!\x1a\x07\x00" ) || str_starts_with( $header, "Rar!\x1a\x07\x01\x00" ) );
	}
	
	private function sanitize_folder( string $folder ): string {
		$folder = trim( wp_normalize_path( $folder ), '/' );
		
		if ( $folder === '' ) {
			return '';
		}
		
		$segments = [];
		
		foreach ( explode( '/', $folder ) as $segment ) {
			$segment = trim( $segment );
			
			if ( $segment === '' || $segment === '.' || $segment === '..' ) {
				continue;
			}
			
			$segment = preg_replace( '/[^\p{L}\p{N}._-]/u', '-', $segment );
			$segment = trim( (string) $segment, '.-_' );
			
			if ( $segment !== '' ) {
				$segments[] = $segment;
			}
		}
		
		return implode( '/', $segments );
	}
	
	private function resolve_base_name( string $original_name, array $ctx ): string {
		$custom_title = isset( $ctx['file_name'] )
			? sanitize_text_field( (string) $ctx['file_name'] )
			: '';
		
		$base_name = $custom_title !== ''
			? $custom_title
			: pathinfo( $original_name, PATHINFO_FILENAME );
		
		$base_name = preg_replace( '/[^\p{L}\p{N}\s._-]/u', '', $base_name );
		$base_name = preg_replace( '/\s+/u', '-', (string) $base_name );
		$base_name = trim( (string) $base_name, '.-_' );
		
		return $base_name !== '' ? $base_name : 'file';
	}
	
	private function build_saved_name( string $local_dir, string $base_name, string $ext ): string {
		$candidate = sprintf(
			'%s_%s.%s',
			$base_name,
			current_time( 'Y-m-d_H-i-s' ),
			$ext
		);
		
		return wp_unique_filename( $local_dir, $candidate );
	}
	
	private function resolve_chunk_saved_name(
		string $chunks_dir,
		string $local_dir,
		string $base_name,
		string $ext,
		string $original_name
	): string {
		$meta_path = $chunks_dir . '/upload.json';
		$lock_path = $chunks_dir . '/.meta.lock';
		$lock      = fopen( $lock_path, 'c' );
		
		if ( ! is_resource( $lock ) || ! flock( $lock, LOCK_EX ) ) {
			if ( is_resource( $lock ) ) {
				fclose( $lock );
			}
			
			return '';
		}
		
		$meta = [];
		
		if ( file_exists( $meta_path ) ) {
			$decoded = json_decode( (string) file_get_contents( $meta_path ), TRUE );
			
			if ( is_array( $decoded ) ) {
				$meta = $decoded;
			}
		}
		
		$saved_name = isset( $meta['saved_name'] )
			? sanitize_file_name( (string) $meta['saved_name'] )
			: '';
		
		if ( $saved_name === '' ) {
			$saved_name = $this->build_saved_name( $local_dir, $base_name, $ext );
			
			file_put_contents(
				$meta_path,
				wp_json_encode( [
					'saved_name'    => $saved_name,
					'original_name' => $original_name,
					'created_at'    => time(),
				], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ),
				LOCK_EX
			);
		}
		
		flock( $lock, LOCK_UN );
		fclose( $lock );
		
		return $saved_name;
	}
	
	private function move_uploaded_file( string $source, string $destination ): bool {
		if ( @move_uploaded_file( $source, $destination ) ) {
			return TRUE;
		}
		
		return @copy( $source, $destination );
	}
	
	private function move_local_file( string $source, string $destination ): bool {
		if ( @rename( $source, $destination ) ) {
			return TRUE;
		}
		
		if ( @copy( $source, $destination ) ) {
			@unlink( $source );
			
			return TRUE;
		}
		
		return FALSE;
	}
	
	private function all_chunks_exist( string $chunks_dir, int $total_chunks ): bool {
		for ( $i = 0; $i < $total_chunks; $i ++ ) {
			$chunk_path = $chunks_dir . '/chunk_' . sprintf( '%06d', $i ) . '.part';
			
			if ( ! is_file( $chunk_path ) ) {
				return FALSE;
			}
		}
		
		return TRUE;
	}
	
	private function merge_chunks( string $chunks_dir, int $total_chunks, string $merged_path ): string {
		@unlink( $merged_path );
		
		$output = fopen( $merged_path, 'wb' );
		
		if ( ! is_resource( $output ) ) {
			return 'ساخت فایل نهایی ناموفق بود.';
		}
		
		for ( $i = 0; $i < $total_chunks; $i ++ ) {
			$chunk_path = $chunks_dir . '/chunk_' . sprintf( '%06d', $i ) . '.part';
			
			if ( ! is_file( $chunk_path ) ) {
				fclose( $output );
				@unlink( $merged_path );
				
				return 'یک یا چند چانک پیدا نشد.';
			}
			
			$input = fopen( $chunk_path, 'rb' );
			
			if ( ! is_resource( $input ) ) {
				fclose( $output );
				@unlink( $merged_path );
				
				return 'خواندن چانک ناموفق بود.';
			}
			
			$result = stream_copy_to_stream( $input, $output );
			fclose( $input );
			
			if ( $result === FALSE ) {
				fclose( $output );
				@unlink( $merged_path );
				
				return 'ادغام چانک‌ها ناموفق بود.';
			}
		}
		
		if ( ! fflush( $output ) ) {
			fclose( $output );
			@unlink( $merged_path );
			
			return 'نوشتن فایل نهایی ناموفق بود.';
		}
		
		fclose( $output );
		
		return '';
	}
	
	private function cleanup_chunks( string $chunks_dir, int $total_chunks ): void {
		for ( $i = 0; $i < $total_chunks; $i ++ ) {
			@unlink( $chunks_dir . '/chunk_' . sprintf( '%06d', $i ) . '.part' );
		}
		
		@unlink( $chunks_dir . '/upload.json' );
		@unlink( $chunks_dir . '/.meta.lock' );
		@unlink( $chunks_dir . '/.merge.lock' );
		@rmdir( $chunks_dir );
	}
	
	private function try_ftp_upload_from_local_path(
		string $local_path,
		string $saved_name,
		string $folder,
		string $original_name
	): array {
		/**
		 * امکان جایگزینی آپلود FTP بدون وابستگی مستقیم به کد قدیمی.
		 * برای اعلام عدم انجام آپلود، NULL برگردانید.
		 */
		$filtered_result = apply_filters(
			'kerp_file_ftp_upload_result',
			NULL,
			$local_path,
			$saved_name,
			$folder,
			$original_name
		);
		
		if ( is_array( $filtered_result ) ) {
			return $filtered_result;
		}
		
		if ( function_exists( 'panel_manager_try_ftp_upload_from_local_path' ) ) {
			$result = panel_manager_try_ftp_upload_from_local_path(
				$local_path,
				$saved_name,
				$folder,
				$original_name
			);
			
			return is_array( $result ) ? $result : [];
		}
		
		return [];
	}
	
	private function set_file_permissions( string $path ): void {
		$permissions = defined( 'FS_CHMOD_FILE' ) ? FS_CHMOD_FILE : 0644;
		@chmod( $path, $permissions );
	}
	
	private function response(
		bool $ok,
		string $url,
		string $name,
		string $message,
		string $storage
	): array {
		return [
			'ok'      => $ok,
			'url'     => $url,
			'name'    => $name,
			'msg'     => $message,
			'storage' => $storage,
		];
	}
	
}
