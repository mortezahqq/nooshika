<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Helpers_Meta {

	public const TYPE_PROGRAM_PLAN          = 'program_plan';
	public const TYPE_PROGRAM_TASK          = 'program_task';
	public const TYPE_PROGRAM_TEMPLATE      = 'program_template';
	public const TYPE_PROGRAM_TEMPLATE_DAY  = 'program_template_day';
	public const TYPE_PROGRAM_TEMPLATE_TASK = 'program_template_task';
	public const TYPE_PROGRAM_TASK_TYPE     = 'program_task_type';
	public const TYPE_PROGRAM_UNIT          = 'program_unit';
	public const TYPE_PROGRAM_TAXONOMY      = 'program_taxonomy';
	public const TYPE_PROGRAM_TERM          = 'program_term';
	public const TYPE_PROGRAM_RESULT        = 'program_result';
	public const TYPE_PROGRAM_REVIEW        = 'program_review';

	private static ?self $instance = NULL;

	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	private function __construct() {}

	private function __clone() {}

	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}

	public function table_name(): string {
		global $wpdb;

		return $wpdb->prefix . 'kerp_meta';
	}

	public function get_meta(
		string $object_type,
		int $object_id,
		string $meta_key = '',
		bool $single = FALSE
	): mixed {
		global $wpdb;

		$object_type = $this->sanitize_object_type( $object_type );
		$object_id   = absint( $object_id );
		$meta_key    = sanitize_key( $meta_key );

		if ( $object_type === '' || $object_id <= 0 ) {
			return $single ? '' : [];
		}

		$cache_key = $this->cache_key( $object_type, $object_id );
		$all_meta  = wp_cache_get( $cache_key, 'kerp_meta' );

		if ( ! is_array( $all_meta ) ) {
			$table = $this->table_name();
			$rows  = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT meta_key, meta_value FROM {$table} WHERE object_type = %s AND object_id = %d ORDER BY meta_id ASC",
					$object_type,
					$object_id
				),
				ARRAY_A
			);
			$all_meta = [];

			foreach ( (array) $rows as $row ) {
				$key = sanitize_key( (string) ( $row['meta_key'] ?? '' ) );
				if ( $key === '' ) {
					continue;
				}
				$all_meta[ $key ][] = maybe_unserialize( $row['meta_value'] ?? '' );
			}

			wp_cache_set( $cache_key, $all_meta, 'kerp_meta' );
		}

		if ( $meta_key === '' ) {
			return $all_meta;
		}

		$values = isset( $all_meta[ $meta_key ] ) && is_array( $all_meta[ $meta_key ] )
			? $all_meta[ $meta_key ]
			: [];

		if ( $single ) {
			return array_key_exists( 0, $values ) ? $values[0] : '';
		}

		return $values;
	}

	public function add_meta(
		string $object_type,
		int $object_id,
		string $meta_key,
		mixed $meta_value,
		bool $unique = FALSE
	): int|false {
		global $wpdb;

		$object_type = $this->sanitize_object_type( $object_type );
		$object_id   = absint( $object_id );
		$meta_key    = sanitize_key( $meta_key );

		if ( $object_type === '' || $object_id <= 0 || $meta_key === '' ) {
			return FALSE;
		}

		if ( $unique && $this->metadata_exists( $object_type, $object_id, $meta_key ) ) {
			return FALSE;
		}

		$result = $wpdb->insert(
			$this->table_name(),
			[
				'object_type' => $object_type,
				'object_id'   => $object_id,
				'meta_key'    => $meta_key,
				'meta_value'  => maybe_serialize( $meta_value ),
			],
			[ '%s', '%d', '%s', '%s' ]
		);

		if ( $result === FALSE ) {
			return FALSE;
		}

		$this->flush_cache( $object_type, $object_id );

		return (int) $wpdb->insert_id;
	}

	public function update_meta(
		string $object_type,
		int $object_id,
		string $meta_key,
		mixed $meta_value
	): bool {
		global $wpdb;

		$object_type = $this->sanitize_object_type( $object_type );
		$object_id   = absint( $object_id );
		$meta_key    = sanitize_key( $meta_key );

		if ( $object_type === '' || $object_id <= 0 || $meta_key === '' ) {
			return FALSE;
		}

		if ( ! $this->metadata_exists( $object_type, $object_id, $meta_key ) ) {
			return $this->add_meta( $object_type, $object_id, $meta_key, $meta_value, TRUE ) !== FALSE;
		}

		$result = $wpdb->update(
			$this->table_name(),
			[ 'meta_value' => maybe_serialize( $meta_value ) ],
			[
				'object_type' => $object_type,
				'object_id'   => $object_id,
				'meta_key'    => $meta_key,
			],
			[ '%s' ],
			[ '%s', '%d', '%s' ]
		);

		if ( $result === FALSE ) {
			return FALSE;
		}

		$this->flush_cache( $object_type, $object_id );

		return TRUE;
	}

	public function delete_meta(
		string $object_type,
		int $object_id,
		string $meta_key = '',
		mixed $meta_value = NULL
	): bool {
		global $wpdb;

		$object_type = $this->sanitize_object_type( $object_type );
		$object_id   = absint( $object_id );
		$meta_key    = sanitize_key( $meta_key );

		if ( $object_type === '' || $object_id <= 0 ) {
			return FALSE;
		}

		$where  = [ 'object_type = %s', 'object_id = %d' ];
		$values = [ $object_type, $object_id ];

		if ( $meta_key !== '' ) {
			$where[]  = 'meta_key = %s';
			$values[] = $meta_key;
		}

		if ( $meta_value !== NULL ) {
			$where[]  = 'meta_value = %s';
			$values[] = maybe_serialize( $meta_value );
		}

		$sql = "DELETE FROM {$this->table_name()} WHERE " . implode( ' AND ', $where );
		$result = $wpdb->query( $wpdb->prepare( $sql, $values ) );

		if ( $result === FALSE ) {
			return FALSE;
		}

		$this->flush_cache( $object_type, $object_id );

		return TRUE;
	}

	public function metadata_exists( string $object_type, int $object_id, string $meta_key ): bool {
		$meta_key = sanitize_key( $meta_key );

		if ( $meta_key === '' ) {
			return FALSE;
		}

		$all_meta = $this->get_meta( $object_type, $object_id );

		return is_array( $all_meta ) && array_key_exists( $meta_key, $all_meta );
	}

	public function get_plan_meta( int $plan_id, string $meta_key = '', bool $single = FALSE ): mixed {
		return $this->get_meta( self::TYPE_PROGRAM_PLAN, $plan_id, $meta_key, $single );
	}

	public function add_plan_meta( int $plan_id, string $meta_key, mixed $meta_value, bool $unique = FALSE ): int|false {
		return $this->add_meta( self::TYPE_PROGRAM_PLAN, $plan_id, $meta_key, $meta_value, $unique );
	}

	public function update_plan_meta( int $plan_id, string $meta_key, mixed $meta_value ): bool {
		return $this->update_meta( self::TYPE_PROGRAM_PLAN, $plan_id, $meta_key, $meta_value );
	}

	public function delete_plan_meta( int $plan_id, string $meta_key = '', mixed $meta_value = NULL ): bool {
		return $this->delete_meta( self::TYPE_PROGRAM_PLAN, $plan_id, $meta_key, $meta_value );
	}

	public function get_task_meta( int $task_id, string $meta_key = '', bool $single = FALSE ): mixed {
		return $this->get_meta( self::TYPE_PROGRAM_TASK, $task_id, $meta_key, $single );
	}

	public function add_task_meta( int $task_id, string $meta_key, mixed $meta_value, bool $unique = FALSE ): int|false {
		return $this->add_meta( self::TYPE_PROGRAM_TASK, $task_id, $meta_key, $meta_value, $unique );
	}

	public function update_task_meta( int $task_id, string $meta_key, mixed $meta_value ): bool {
		return $this->update_meta( self::TYPE_PROGRAM_TASK, $task_id, $meta_key, $meta_value );
	}

	public function delete_task_meta( int $task_id, string $meta_key = '', mixed $meta_value = NULL ): bool {
		return $this->delete_meta( self::TYPE_PROGRAM_TASK, $task_id, $meta_key, $meta_value );
	}

	public function get_template_meta( int $template_id, string $meta_key = '', bool $single = FALSE ): mixed {
		return $this->get_meta( self::TYPE_PROGRAM_TEMPLATE, $template_id, $meta_key, $single );
	}

	public function add_template_meta( int $template_id, string $meta_key, mixed $meta_value, bool $unique = FALSE ): int|false {
		return $this->add_meta( self::TYPE_PROGRAM_TEMPLATE, $template_id, $meta_key, $meta_value, $unique );
	}

	public function update_template_meta( int $template_id, string $meta_key, mixed $meta_value ): bool {
		return $this->update_meta( self::TYPE_PROGRAM_TEMPLATE, $template_id, $meta_key, $meta_value );
	}

	public function delete_template_meta( int $template_id, string $meta_key = '', mixed $meta_value = NULL ): bool {
		return $this->delete_meta( self::TYPE_PROGRAM_TEMPLATE, $template_id, $meta_key, $meta_value );
	}

	public function get_template_day_meta( int $day_id, string $meta_key = '', bool $single = FALSE ): mixed {
		return $this->get_meta( self::TYPE_PROGRAM_TEMPLATE_DAY, $day_id, $meta_key, $single );
	}

	public function add_template_day_meta( int $day_id, string $meta_key, mixed $meta_value, bool $unique = FALSE ): int|false {
		return $this->add_meta( self::TYPE_PROGRAM_TEMPLATE_DAY, $day_id, $meta_key, $meta_value, $unique );
	}

	public function update_template_day_meta( int $day_id, string $meta_key, mixed $meta_value ): bool {
		return $this->update_meta( self::TYPE_PROGRAM_TEMPLATE_DAY, $day_id, $meta_key, $meta_value );
	}

	public function delete_template_day_meta( int $day_id, string $meta_key = '', mixed $meta_value = NULL ): bool {
		return $this->delete_meta( self::TYPE_PROGRAM_TEMPLATE_DAY, $day_id, $meta_key, $meta_value );
	}

	public function get_template_task_meta( int $task_id, string $meta_key = '', bool $single = FALSE ): mixed {
		return $this->get_meta( self::TYPE_PROGRAM_TEMPLATE_TASK, $task_id, $meta_key, $single );
	}

	public function add_template_task_meta( int $task_id, string $meta_key, mixed $meta_value, bool $unique = FALSE ): int|false {
		return $this->add_meta( self::TYPE_PROGRAM_TEMPLATE_TASK, $task_id, $meta_key, $meta_value, $unique );
	}

	public function update_template_task_meta( int $task_id, string $meta_key, mixed $meta_value ): bool {
		return $this->update_meta( self::TYPE_PROGRAM_TEMPLATE_TASK, $task_id, $meta_key, $meta_value );
	}

	public function delete_template_task_meta( int $task_id, string $meta_key = '', mixed $meta_value = NULL ): bool {
		return $this->delete_meta( self::TYPE_PROGRAM_TEMPLATE_TASK, $task_id, $meta_key, $meta_value );
	}

	public function get_task_type_meta( int $type_id, string $meta_key = '', bool $single = FALSE ): mixed {
		return $this->get_meta( self::TYPE_PROGRAM_TASK_TYPE, $type_id, $meta_key, $single );
	}

	public function add_task_type_meta( int $type_id, string $meta_key, mixed $meta_value, bool $unique = FALSE ): int|false {
		return $this->add_meta( self::TYPE_PROGRAM_TASK_TYPE, $type_id, $meta_key, $meta_value, $unique );
	}

	public function update_task_type_meta( int $type_id, string $meta_key, mixed $meta_value ): bool {
		return $this->update_meta( self::TYPE_PROGRAM_TASK_TYPE, $type_id, $meta_key, $meta_value );
	}

	public function delete_task_type_meta( int $type_id, string $meta_key = '', mixed $meta_value = NULL ): bool {
		return $this->delete_meta( self::TYPE_PROGRAM_TASK_TYPE, $type_id, $meta_key, $meta_value );
	}

	public function get_unit_meta( int $unit_id, string $meta_key = '', bool $single = FALSE ): mixed {
		return $this->get_meta( self::TYPE_PROGRAM_UNIT, $unit_id, $meta_key, $single );
	}

	public function add_unit_meta( int $unit_id, string $meta_key, mixed $meta_value, bool $unique = FALSE ): int|false {
		return $this->add_meta( self::TYPE_PROGRAM_UNIT, $unit_id, $meta_key, $meta_value, $unique );
	}

	public function update_unit_meta( int $unit_id, string $meta_key, mixed $meta_value ): bool {
		return $this->update_meta( self::TYPE_PROGRAM_UNIT, $unit_id, $meta_key, $meta_value );
	}

	public function delete_unit_meta( int $unit_id, string $meta_key = '', mixed $meta_value = NULL ): bool {
		return $this->delete_meta( self::TYPE_PROGRAM_UNIT, $unit_id, $meta_key, $meta_value );
	}

	public function get_taxonomy_meta( int $taxonomy_id, string $meta_key = '', bool $single = FALSE ): mixed {
		return $this->get_meta( self::TYPE_PROGRAM_TAXONOMY, $taxonomy_id, $meta_key, $single );
	}

	public function add_taxonomy_meta( int $taxonomy_id, string $meta_key, mixed $meta_value, bool $unique = FALSE ): int|false {
		return $this->add_meta( self::TYPE_PROGRAM_TAXONOMY, $taxonomy_id, $meta_key, $meta_value, $unique );
	}

	public function update_taxonomy_meta( int $taxonomy_id, string $meta_key, mixed $meta_value ): bool {
		return $this->update_meta( self::TYPE_PROGRAM_TAXONOMY, $taxonomy_id, $meta_key, $meta_value );
	}

	public function delete_taxonomy_meta( int $taxonomy_id, string $meta_key = '', mixed $meta_value = NULL ): bool {
		return $this->delete_meta( self::TYPE_PROGRAM_TAXONOMY, $taxonomy_id, $meta_key, $meta_value );
	}

	public function get_term_meta( int $term_id, string $meta_key = '', bool $single = FALSE ): mixed {
		return $this->get_meta( self::TYPE_PROGRAM_TERM, $term_id, $meta_key, $single );
	}

	public function add_term_meta( int $term_id, string $meta_key, mixed $meta_value, bool $unique = FALSE ): int|false {
		return $this->add_meta( self::TYPE_PROGRAM_TERM, $term_id, $meta_key, $meta_value, $unique );
	}

	public function update_term_meta( int $term_id, string $meta_key, mixed $meta_value ): bool {
		return $this->update_meta( self::TYPE_PROGRAM_TERM, $term_id, $meta_key, $meta_value );
	}

	public function delete_term_meta( int $term_id, string $meta_key = '', mixed $meta_value = NULL ): bool {
		return $this->delete_meta( self::TYPE_PROGRAM_TERM, $term_id, $meta_key, $meta_value );
	}

	public function get_result_meta( int $result_id, string $meta_key = '', bool $single = FALSE ): mixed {
		return $this->get_meta( self::TYPE_PROGRAM_RESULT, $result_id, $meta_key, $single );
	}

	public function add_result_meta( int $result_id, string $meta_key, mixed $meta_value, bool $unique = FALSE ): int|false {
		return $this->add_meta( self::TYPE_PROGRAM_RESULT, $result_id, $meta_key, $meta_value, $unique );
	}

	public function update_result_meta( int $result_id, string $meta_key, mixed $meta_value ): bool {
		return $this->update_meta( self::TYPE_PROGRAM_RESULT, $result_id, $meta_key, $meta_value );
	}

	public function delete_result_meta( int $result_id, string $meta_key = '', mixed $meta_value = NULL ): bool {
		return $this->delete_meta( self::TYPE_PROGRAM_RESULT, $result_id, $meta_key, $meta_value );
	}

	public function get_review_meta( int $review_id, string $meta_key = '', bool $single = FALSE ): mixed {
		return $this->get_meta( self::TYPE_PROGRAM_REVIEW, $review_id, $meta_key, $single );
	}

	public function add_review_meta( int $review_id, string $meta_key, mixed $meta_value, bool $unique = FALSE ): int|false {
		return $this->add_meta( self::TYPE_PROGRAM_REVIEW, $review_id, $meta_key, $meta_value, $unique );
	}

	public function update_review_meta( int $review_id, string $meta_key, mixed $meta_value ): bool {
		return $this->update_meta( self::TYPE_PROGRAM_REVIEW, $review_id, $meta_key, $meta_value );
	}

	public function delete_review_meta( int $review_id, string $meta_key = '', mixed $meta_value = NULL ): bool {
		return $this->delete_meta( self::TYPE_PROGRAM_REVIEW, $review_id, $meta_key, $meta_value );
	}

	private function sanitize_object_type( string $object_type ): string {
		return sanitize_key( $object_type );
	}

	private function cache_key( string $object_type, int $object_id ): string {
		return $object_type . ':' . $object_id;
	}

	private function flush_cache( string $object_type, int $object_id ): void {
		wp_cache_delete( $this->cache_key( $object_type, $object_id ), 'kerp_meta' );
	}
}
