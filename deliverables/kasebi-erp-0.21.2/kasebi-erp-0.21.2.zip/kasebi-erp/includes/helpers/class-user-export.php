<?php

defined( 'ABSPATH' ) || exit;

/** Opt-in export providers. No endpoint is installed until a module registers one. */
final class KERP_Helpers_User_Export {

	private static array $actions = [];

	/**
	 * $query($filters, $page_number, $per_page) returns user_ids and total, or WP_Error.
	 * It must query only the scope accessible to the current operator, in stable ID order.
	 * $permission($filters) must return strictly TRUE to authorize every batch.
	 * $phone($user_id), when supplied, resolves the module's own contact field.
	 */
	public static function register( string $action, callable $permission, callable $query, ?callable $phone = NULL ): void {
		if ( $action === '' || sanitize_key( $action ) !== $action || isset( self::$actions[ $action ] ) || has_action( 'kasebi_ajax_' . $action ) ) {
			throw new InvalidArgumentException( 'Export action must be unique and use a sanitized key.' );
		}
		self::$actions[ $action ] = TRUE;
		add_action( 'kasebi_ajax_' . $action, static function() use ( $action, $permission, $query, $phone ): void {
			$nonce = $_POST['export_nonce'] ?? '';
			if ( ! is_user_logged_in() || ! is_string( $nonce ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $nonce ) ), 'kerp_user_export_' . $action ) ) {
				wp_send_json( [ 'status' => 'error', 'message' => __( 'دسترسی خروجی معتبر نیست؛ صفحه را دوباره باز کنید.', 'kasebi-erp' ) ], 403 );
			}
			$filters = wp_unslash( $_POST );
			foreach ( [ 'action', 'export_nonce', 'page_number', 'per_page', 'user_ids' ] as $key ) {
				unset( $filters[ $key ] );
			}
			if ( $permission( $filters ) !== TRUE ) {
				wp_send_json( [ 'status' => 'error', 'message' => __( 'اجازه دریافت این خروجی را ندارید.', 'kasebi-erp' ) ], 403 );
			}
			$page = filter_var( $_POST['page_number'] ?? 1, FILTER_VALIDATE_INT, [ 'options' => [ 'min_range' => 1 ] ] );
			$per_page = filter_var( $_POST['per_page'] ?? 100, FILTER_VALIDATE_INT, [ 'options' => [ 'min_range' => 1, 'max_range' => 200 ] ] );
			if ( $page === FALSE || $per_page === FALSE ) {
				wp_send_json( [ 'status' => 'error', 'message' => __( 'صفحه‌بندی خروجی معتبر نیست.', 'kasebi-erp' ) ], 400 );
			}
			$result = $query( $filters, $page, $per_page );
			if ( is_wp_error( $result ) ) {
				wp_send_json( [ 'status' => 'error', 'message' => $result->get_error_message() ], 400 );
			}
			if ( ! is_array( $result ) || ! isset( $result['user_ids'], $result['total'] ) || ! is_array( $result['user_ids'] ) || ! is_int( $result['total'] ) || $result['total'] < 0 || count( $result['user_ids'] ) > $per_page ) {
				wp_send_json( [ 'status' => 'error', 'message' => __( 'پاسخ منبع خروجی معتبر نیست.', 'kasebi-erp' ) ], 500 );
			}
			$ids = [];
			$rows = [];
			foreach ( $result['user_ids'] as $value ) {
				$id = filter_var( $value, FILTER_VALIDATE_INT, [ 'options' => [ 'min_range' => 1 ] ] );
				$user = $id ? get_userdata( $id ) : FALSE;
				if ( ! $user || isset( $ids[ $id ] ) ) {
					wp_send_json( [ 'status' => 'error', 'message' => __( 'فهرست کاربران تغییر کرده است؛ دوباره خروجی بگیرید.', 'kasebi-erp' ) ], 409 );
				}
				$ids[ $id ] = $id;
				$name = trim( $user->first_name . ' ' . $user->last_name );
				$contact = $phone ? $phone( $id ) : get_user_meta( $id, 'nooshika_phone_num', TRUE );
				if ( ! $phone && $contact === '' ) {
					$contact = get_user_meta( $id, 'billing_phone', TRUE );
				}
				$rows[] = [ $name !== '' ? $name : $user->display_name, (string) $contact ];
			}
			wp_send_json( [
				'status' => 'success', 'user_ids' => array_values( $ids ), 'rows' => $rows,
				'total' => $result['total'], 'page_number' => $page, 'per_page' => $per_page,
				'total_pages' => (int) ceil( $result['total'] / $per_page ),
			] );
		} );
	}
}
