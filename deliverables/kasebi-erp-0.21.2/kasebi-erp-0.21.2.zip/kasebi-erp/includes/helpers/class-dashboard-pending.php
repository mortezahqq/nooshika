<?php
defined( 'ABSPATH' ) || exit;

/** A bounded dashboard batch completed; the next request resumes its checkpoint. */
final class KERP_Helpers_Dashboard_Pending extends RuntimeException {
    public function __construct( public readonly array $progress = [] ) {
        parent::__construct( 'Dashboard snapshot is not ready.' );
    }
}
