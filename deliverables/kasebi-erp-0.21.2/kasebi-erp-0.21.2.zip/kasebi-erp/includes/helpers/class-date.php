<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Helpers_Date {

	/** Convert a stored Gregorian date to Jalali without locale filters or timezone shifts. */
	public static function gregorian_to_jalali( string $date ): string {
		if ( ! preg_match( '/^([0-9]{4})-([0-9]{2})-([0-9]{2})$/', $date, $parts ) || ! checkdate( (int) $parts[2], (int) $parts[3], (int) $parts[1] ) || (int) $parts[1] < 623 ) return '';
		$zone = new DateTimeZone( 'UTC' );
		$target = new DateTimeImmutable( $date, $zone );
		$year = (int) $parts[1] - 621;
		$start = new DateTimeImmutable( self::jalali_to_gregorian( $year . '-01-01' ), $zone );
		if ( $target < $start ) {
			--$year;
			$start = new DateTimeImmutable( self::jalali_to_gregorian( $year . '-01-01' ), $zone );
		}
		$days = (int) $start->diff( $target )->days;
		$month = 1;
		while ( $month < 12 && $days >= ( $month <= 6 ? 31 : 30 ) ) {
			$days -= $month <= 6 ? 31 : 30;
			++$month;
		}
		return sprintf( '%04d-%02d-%02d', $year, $month, $days + 1 );
	}

	/** Format an already local MySQL datetime; retain its local clock time. */
	public static function local_datetime_to_jalali( string $datetime ): string {
		if ( ! preg_match( '/^([0-9]{4}-[0-9]{2}-[0-9]{2}) ([0-9]{2}):([0-9]{2}):([0-9]{2})$/', $datetime, $parts ) || (int) $parts[2] > 23 || (int) $parts[3] > 59 || (int) $parts[4] > 59 ) return '';
		$date = self::gregorian_to_jalali( $parts[1] );
		return $date === '' ? '' : $date . ' ' . $parts[2] . ':' . $parts[3];
	}

	/**
	 * تبدیل تاریخ جلالی به میلادی.
	 *
	 * @return array<int,int|string>|string
	 */
	public static function jalali_to_gregorian(
		string $date,
		bool $array = FALSE,
		string $separator = '-'
	): array|string {
		if ( $separator === '' ) {
			return $array ? [] : '';
		}

		$date    = KERP_Helpers_Format::sanitize_numbers( trim( $date ) );
		$explode = array_map( 'trim', explode( $separator, $date ) );

		if ( count( $explode ) !== 3 ) {
			return $array ? [] : '';
		}

		foreach ( $explode as $part ) {
			if ( $part === '' || ! ctype_digit( $part ) ) {
				return $array ? [] : '';
			}
		}

		$jy = (int) $explode[0];
		$jm = (int) $explode[1];
		$jd = (int) $explode[2];

		if ( ! self::is_valid_jalali_date( $jy, $jm, $jd ) ) {
			return $array ? [] : '';
		}

		$jy += 1595;

		$days = -355668
			+ ( 365 * $jy )
			+ ( (int) ( $jy / 33 ) * 8 )
			+ (int) ( ( ( $jy % 33 ) + 3 ) / 4 )
			+ $jd
			+ ( ( $jm < 7 ) ? ( $jm - 1 ) * 31 : ( ( $jm - 7 ) * 30 ) + 186 );

		$gy   = 400 * (int) ( $days / 146097 );
		$days %= 146097;

		if ( $days > 36524 ) {
			$gy   += 100 * (int) ( --$days / 36524 );
			$days %= 36524;

			if ( $days >= 365 ) {
				$days++;
			}
		}

		$gy   += 4 * (int) ( $days / 1461 );
		$days %= 1461;

		if ( $days > 365 ) {
			$gy   += (int) ( ( $days - 1 ) / 365 );
			$days = ( $days - 1 ) % 365;
		}

		$gd = $days + 1;

		$gregorian_month_days = [
			0,
			31,
			( ( $gy % 4 === 0 && $gy % 100 !== 0 ) || $gy % 400 === 0 ) ? 29 : 28,
			31,
			30,
			31,
			30,
			31,
			31,
			30,
			31,
			30,
			31,
		];

		for ( $gm = 0; $gm < 13 && $gd > $gregorian_month_days[ $gm ]; $gm++ ) {
			$gd -= $gregorian_month_days[ $gm ];
		}

		$gm_formatted = str_pad( (string) $gm, 2, '0', STR_PAD_LEFT );
		$gd_formatted = str_pad( (string) $gd, 2, '0', STR_PAD_LEFT );

		return $array
			? [ $gy, $gm_formatted, $gd_formatted ]
			: "{$gy}-{$gm_formatted}-{$gd_formatted}";
	}

	/**
	 * تبدیل تاریخ متنی خروجی Excel از جلالی به MySQL datetime.
	 */
	public static function parse_excel_jalali_datetime( string $date_string ): ?string {
		$date_string = trim( $date_string );

		if ( $date_string === '' ) {
			return NULL;
		}

		$date_string = KERP_Helpers_Format::sanitize_numbers( $date_string );
		$date_string = str_replace(
			[ '،', ',', 'ي', 'ك' ],
			[ ' ', ' ', 'ی', 'ک' ],
			$date_string
		);
		$date_string = preg_replace( '/\s+/u', ' ', $date_string );

		if ( ! is_string( $date_string ) ) {
			return NULL;
		}

		$months = [
			'فروردین'  => '01',
			'اردیبهشت' => '02',
			'خرداد'    => '03',
			'تیر'      => '04',
			'مرداد'    => '05',
			'شهریور'   => '06',
			'مهر'      => '07',
			'آبان'     => '08',
			'ابان'     => '08',
			'آذر'      => '09',
			'اذر'      => '09',
			'دی'       => '10',
			'بهمن'     => '11',
			'اسفند'    => '12',
		];

		$matched = preg_match(
			'/^(?P<day>\d{1,2})\s+(?P<month>[\x{0600}-\x{06FF}]+)\s+(?P<year>\d{4})\s+(?P<time>\d{1,2}:\d{2}(?::\d{2})?)$/u',
			trim( $date_string ),
			$matches
		);

		if ( $matched !== 1 ) {
			return NULL;
		}

		$month_name = trim( $matches['month'] );

		if ( ! isset( $months[ $month_name ] ) ) {
			return NULL;
		}

		$time_parts = array_map( 'intval', explode( ':', $matches['time'] ) );
		$hour       = $time_parts[0] ?? -1;
		$minute     = $time_parts[1] ?? -1;
		$second     = $time_parts[2] ?? 0;

		if ( $hour > 23 || $minute > 59 || $second > 59 ) {
			return NULL;
		}

		$jalali_date = sprintf(
			'%d-%s-%02d',
			(int) $matches['year'],
			$months[ $month_name ],
			(int) $matches['day']
		);
		$gregorian_date = self::jalali_to_gregorian( $jalali_date );

		if ( $gregorian_date === '' ) {
			return NULL;
		}

		return sprintf(
			'%s %02d:%02d:%02d',
			$gregorian_date,
			$hour,
			$minute,
			$second
		);
	}

	private static function is_valid_jalali_date( int $year, int $month, int $day ): bool {
		if ( $year < 1 || $month < 1 || $month > 12 || $day < 1 ) {
			return FALSE;
		}

		$max_day = $month <= 6 ? 31 : 30;

		if ( $month === 12 && $day === 30 ) {
			return in_array( $year % 33, [ 1, 5, 9, 13, 17, 22, 26, 30 ], TRUE );
		}
		return $day <= $max_day;
	}
}
