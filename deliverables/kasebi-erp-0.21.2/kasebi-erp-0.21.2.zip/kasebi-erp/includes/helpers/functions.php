<?php

defined( 'ABSPATH' ) || exit;

function kerp_asset_version( string $asset ): string|int {
	$path = KERP_ASSETS_PATH . ltrim( $asset, '/' );
	
	return is_file( $path ) ? (int) filemtime( $path ) : KERP_VERSION;
}

function kerp_is_erp_request(): bool {
	return KERP_Core_Router::instance()->is_erp_request();
}

function kerp_get_login_url( string $redirect_to = '' ): string {
	$login_url = (string) apply_filters( 'kerp_login_url', home_url( '/login/' ), $redirect_to );
	
	if ( $redirect_to === '' ) {
		return $login_url;
	}
	
	$query_arg = sanitize_key( (string) apply_filters( 'kerp_login_redirect_query_arg', 'redirect_to' ) );
	$query_arg = $query_arg !== '' ? $query_arg : 'redirect';
	
	return add_query_arg( $query_arg, $redirect_to, $login_url );
}

function kerp_can( string $permission, string $type = 'action' ): bool {
	return KERP_Services_UI_Gate::can( $permission, $type );
}

function kerp_can_page( string $page ): bool {
	return KERP_Services_UI_Gate::can_page( $page );
}

function kerp_list_scope( string $resource ): string {
	return KERP_Services_UI_Gate::list_scope( $resource );
}
