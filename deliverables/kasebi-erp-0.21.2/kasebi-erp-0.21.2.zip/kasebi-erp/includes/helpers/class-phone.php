<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Helpers_Phone {

	/**
	 * نرمال‌سازی شماره تلفن؛ خروجی پیش‌فرض بدون صفر و کد کشور است.
	 */
	public static function normalize( string $phone, bool $remove_country_code = TRUE ): string {
		$phone = KERP_Helpers_Format::sanitize_numbers( $phone );
		$phone = preg_replace( '/[^0-9]/', '', $phone );
		$phone = is_string( $phone ) ? $phone : '';

		if ( $remove_country_code ) {
			if ( str_starts_with( $phone, '0098' ) ) {
				$phone = substr( $phone, 4 );
			} elseif ( str_starts_with( $phone, '98' ) && strlen( $phone ) === 12 ) {
				$phone = substr( $phone, 2 );
			}
		}

		if ( str_starts_with( $phone, '09' ) ) {
			$phone = substr( $phone, 1 );
		}

		return $phone;
	}

	/**
	 * دریافت شماره در قالب داخلی ایران با صفر ابتدایی.
	 */
	public static function with_zero( string $phone ): string {
		$phone = self::normalize( $phone );

		if ( $phone === '' ) {
			return '';
		}

		return str_starts_with( $phone, '0' ) ? $phone : '0' . $phone;
	}

	/**
	 * کلید متای شماره تلفن کاربر.
	 */
	public static function get_meta_key(): string {
		$meta_key = apply_filters( 'kerp_user_phone_meta_key', 'nooshika_phone_num' );
		$meta_key = is_string( $meta_key ) ? sanitize_key( $meta_key ) : '';

		return $meta_key !== '' ? $meta_key : 'nooshika_phone_num';
	}

	/**
	 * پیدا‌کردن شناسه کاربر با شماره تلفن.
	 */
	public static function get_user_id( string $phone, string $meta_key = '' ): int {
		$phone = self::normalize( $phone );

		if ( $phone === '' ) {
			return 0;
		}

		$meta_key = $meta_key !== '' ? sanitize_key( $meta_key ) : self::get_meta_key();

		if ( $meta_key === '' ) {
			return 0;
		}

		$users = get_users( [
			'meta_key'   => $meta_key,
			'meta_value' => $phone,
			'number'     => 1,
			'fields'     => 'ID',
		] );

		return ! empty( $users ) ? (int) $users[0] : 0;
	}
}
