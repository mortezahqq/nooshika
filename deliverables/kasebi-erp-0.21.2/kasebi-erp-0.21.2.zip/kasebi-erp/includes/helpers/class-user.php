<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Helpers_User {
	
	/**
	 * دریافت اولین نقش کاربر.
	 */
	public static function get_role( int $user_id ): string {
		$user = get_user_by( 'id', $user_id );
		
		if ( ! $user instanceof WP_User ) {
			return '';
		}
		
		return $user->roles[0] ?? '';
	}
	
	/**
	 * دریافت نام مناسب برای نمایش کاربر.
	 */
	public static function get_display_name(
		?int $user_id = NULL,
		bool $phone = TRUE,
		bool $echo_default = TRUE
	): string {
		$user_id = $user_id ?: get_current_user_id();
		$default = self::get_default_display_name();
		
		if ( ! $user_id ) {
			return $echo_default ? $default : '';
		}
		
		$user = get_user_by( 'ID', $user_id );
		
		if ( ! $user instanceof WP_User ) {
			return $echo_default ? $default : '';
		}
		
		$name = function_exists( 'get_user_name_by_id' )
            ? trim( (string) get_user_name_by_id( $user_id, $phone, $echo_default ) )
            : trim( (string) ( $user->display_name ?: $user->user_login ) );

		return $name !== '' ? $name : ( $echo_default ? $default : '' );
	}
	
	/**
	 * بررسی دسترسی مدیریتی کاربر.
	 */
	public static function is_admin( int $user_id = 0 ): bool {
		$user_id = $user_id ?: get_current_user_id();
		
		return $user_id > 0 && user_can( $user_id, 'manage_options' );
	}
	
	private static function get_default_display_name(): string {
		$default = trim( (string) get_option( 'kerp_default_user_name', '' ) );
		
		/*
		 * سازگاری موقت با مقدار ذخیره‌شده در پروژه قدیمی.
		 */
		if ( $default === '' ) {
			$default = trim( (string) get_option( 'nooshika_default_user_name', '' ) );
		}
		
		if ( $default === '' ) {
			$default = __( 'کاربر', 'kasebi-erp' );
		}
		
		$default = apply_filters( 'kerp_default_user_display_name', $default );
		
		return is_string( $default ) && $default !== ''
			? $default
			: __( 'کاربر', 'kasebi-erp' );
	}
	
	/**
	 * دریافت آواتار یا حروف ابتدایی نام کاربر.
	 *
	 * @param   int|null  $user_id   شناسه کاربر؛ در صورت خالی بودن، کاربر جاری.
	 * @param   bool      $as_image  در صورت وجود تصویر، خروجی تگ img باشد.
	 * @param   int       $size      اندازه آواتار.
	 *
	 * @return string
	 */
	public static function get_user_avatar(
		?int $user_id = NULL,
		bool $as_image = TRUE,
		int $size = 40
	): string {
		$user_id = $user_id ?: get_current_user_id();
		$size    = max( 1, absint( $size ) );
		
		if ( ! $user_id ) {
			return '';
		}
		
		$user = get_userdata( $user_id );
		
		if ( ! $user instanceof WP_User ) {
			return '';
		}
		
		if ( $as_image ) {
			$avatar_url = self::get_user_avatar_url( $user_id );
			
			if ( $avatar_url ) {
				return sprintf(
					'<img src="%1$s" alt="%2$s" class="avatar photo" width="%3$d" height="%3$d" loading="lazy">',
					esc_url( $avatar_url ),
					esc_attr( self::get_display_name( $user_id ) ?: __( 'آواتار کاربر', 'kasebi-erp' ) ),
					$size
				);
			}
		}
		
		return self::get_user_initials( $user );
	}
	
	/**
	 * دریافت آدرس تصویر اختصاصی کاربر.
	 */
	public static function get_user_avatar_url( ?int $user_id = NULL ): string {
		$user_id = $user_id ?: get_current_user_id();
		
		if ( ! $user_id ) {
			return '';
		}
		
		$avatar = trim(
			(string) get_user_meta(
				$user_id,
				'nooshika_user_avatar_url',
				TRUE
			)
		);
		
		if ( $avatar === '' ) {
			return '';
		}
		
		/*
		 * اگر مقدار متا از قبل یک URL کامل باشد.
		 */
		if ( wp_http_validate_url( $avatar ) ) {
			return $avatar;
		}
		
		$upload_dir = wp_upload_dir();
		
		if ( ! empty( $upload_dir['error'] ) || empty( $upload_dir['baseurl'] ) ) {
			return '';
		}
		
		return trailingslashit( $upload_dir['baseurl'] ) . ltrim( $avatar, '/' );
	}
	
	/**
	 * تولید حروف ابتدایی نام کاربر.
	 */
	private static function get_user_initials( WP_User $user ): string {
		$first_name = trim( (string) $user->first_name );
		$last_name  = trim( (string) $user->last_name );
		
		if ( $first_name !== '' || $last_name !== '' ) {
			$initials = [];
			
			if ( $first_name !== '' ) {
				$initials[] = mb_substr( $first_name, 0, 1 );
			}
			
			if ( $last_name !== '' ) {
				$initials[] = mb_substr( $last_name, 0, 1 );
			}
			
			return implode( '‌', $initials );
		}
		
		$fallback_name = self::get_display_name( (int) $user->ID );
		
		return $fallback_name !== ''
			? mb_substr( $fallback_name, 0, 1 )
			: '';
	}
	
}
