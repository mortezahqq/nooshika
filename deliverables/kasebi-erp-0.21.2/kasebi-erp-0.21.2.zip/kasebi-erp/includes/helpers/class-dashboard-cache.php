<?php
defined( 'ABSPATH' ) || exit;

/** Cache data, never rendered HTML, nonces or permission-dependent action markup. */
final class KERP_Helpers_Dashboard_Cache {
    private static array $memory = [];

    public static function register(): void {
        foreach ( [ 'added_user_meta', 'updated_user_meta', 'deleted_user_meta', 'added_post_meta', 'updated_post_meta', 'deleted_post_meta', 'added_order_meta', 'updated_order_meta', 'deleted_order_meta' ] as $hook ) {
            add_action( $hook, [ self::class, 'ownership_changed' ], 10, 3 );
        }
    }

    public static function ownership_changed( $meta_id, $object_id, $key ): void {
        if ( in_array( $key, [ 'owner_id', 'marketer_id', 'user_marketer_id' ], TRUE ) ) {
            update_option( 'kerp_dashboard_scope_revision', wp_generate_uuid4(), FALSE );
        }
    }

    public static function remember( string $name, callable $step ): array {
        $user = wp_get_current_user();
        $context = [
            'version' => 1, 'site' => get_current_blog_id(), 'user' => $user->ID,
            'caps' => $user->allcaps, 'roles' => $user->roles,
            'orders' => kerp_list_scope( 'orders' ), 'customers' => kerp_list_scope( 'customers' ),
            'day' => current_datetime()->format( 'Y-m-d' ), 'timezone' => wp_timezone_string(),
            'revision' => get_option( 'kerp_dashboard_scope_revision', '' ),
            'customer_roles' => get_option( 'kerp_customers_settings', [] ),
        ];
        $key = 'kerp_dash_' . md5( $name . wp_json_encode( apply_filters( 'kerp_dashboard_cache_context', $context, $name ) ) );
        if ( isset( self::$memory[ $key ] ) ) { return self::$memory[ $key ]; }
        $cached = get_transient( $key );
        if ( is_array( $cached ) ) { return self::$memory[ $key ] = $cached; }

        // A unique option_name and INSERT IGNORE provide an atomic cross-worker lease.
        $lock = $key . '_lock';
        $token = wp_generate_uuid4();
        $lease = [ 'token' => $token, 'expires' => time() + 120 ];
        global $wpdb;
        $acquired = $wpdb->query( $wpdb->prepare( "INSERT IGNORE INTO {$wpdb->options} (option_name,option_value,autoload) VALUES (%s,%s,'no')", $lock, maybe_serialize( $lease ) ) );
        if ( $acquired === FALSE ) { throw new RuntimeException( 'Dashboard lease could not be acquired.' ); }
        wp_cache_delete( $lock, 'options' );
        wp_cache_delete( 'notoptions', 'options' );
        if ( ! $acquired ) {
            $old = get_option( $lock );
            if ( is_array( $old ) && ( $old['expires'] ?? PHP_INT_MAX ) < time() ) {
                self::unlock( $lock, $old );
            }
            throw new KERP_Helpers_Dashboard_Pending( [ 'phase' => 'locked' ] );
        }
        try {
            // Another worker may have published between our first read and lease acquisition.
            $cached = get_transient( $key );
            if ( is_array( $cached ) ) { return self::$memory[ $key ] = $cached; }
            $state = get_transient( $key . '_work' );
            if ( ! is_array( $state ) ) { $state = [ 'as_of' => current_datetime()->format( DATE_ATOM ) ]; }
            $next = $step( $state );
            if ( ! empty( $wpdb->last_error ) ) { throw new RuntimeException( 'Dashboard query failed.' ); }
            if ( empty( $next['done'] ) ) {
                $next['_batches'] = (int) ( $state['_batches'] ?? 0 ) + 1;
                if ( ! set_transient( $key . '_work', array_merge( $state, $next ), 15 * MINUTE_IN_SECONDS ) ) {
                    throw new RuntimeException( 'Dashboard checkpoint could not be saved.' );
                }
                throw new KERP_Helpers_Dashboard_Pending( [
                    'phase' => 'processing', 'batches' => $next['_batches'],
                    'processed' => (int) ( $next['processed'] ?? 0 ),
                    'prepared' => (int) ( $next['prepared'] ?? 0 ),
                ] );
            }
            $data = $next['data'];
            if ( ! set_transient( $key, $data, 5 * MINUTE_IN_SECONDS ) ) {
                throw new RuntimeException( 'Dashboard snapshot could not be saved.' );
            }
            delete_transient( $key . '_work' );
            return self::$memory[ $key ] = $data;
        } finally {
            self::unlock( $lock, $lease );
        }
    }

    private static function unlock( string $key, array $lease ): void {
        global $wpdb;
        // Compare-and-delete: a timed-out worker must not remove a successor's lease.
        $wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name=%s AND option_value=%s", $key, maybe_serialize( $lease ) ) );
        wp_cache_delete( $key, 'options' );
    }
}
