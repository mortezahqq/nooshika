<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Plugin {
	
	private static ?KERP_Plugin $instance = NULL;
	
	public static function instance(): KERP_Plugin {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {
		$this->load_core();
		$this->load_admin();
		$this->init_hooks();
	}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize singleton.' );
	}
	
	private function init_hooks(): void {
		add_action( 'init', [ KERP_Install_Installer::class, 'maybe_upgrade' ], 5 );
		add_action( 'init', [ $this, 'load_modules' ], 20 );
	}
	
	private function load_core(): void {
		KERP_Modules::instance();
		KERP_Core_Router::instance();
		KERP_Services_Session::instance();
		KERP_Services_Access::instance();
		KERP_Services_UI_Gate::instance();
		KERP_Services_Auth_Guard::instance();
		KERP_Services_Attribution_First_Touch::instance();
		// Track storefront/admin writes even when the customers module is disabled.
		KERP_Modules_Customers_Search_Index::instance();
		KERP_App::instance();
		KERP_Settings_Panel_Navigation::instance();
		KERP_App_Admin_Bar::instance();
		KERP_Public_Assets::instance();
		
		KERP_Api_Page_Content::register();
		KERP_App_Dashboard::register();
		KERP_Helpers_Dashboard_Cache::register();
		KERP_Api_Auth::instance();
		KERP_Api_User_Preferences::instance();
		KERP_Api_File_Upload::instance();
		
		if ( class_exists( 'WooCommerce' ) ) {
			KERP_Core_Order_Index::instance();
		}
	}
	
	private function load_admin(): void {
		if ( is_admin() ) {
			KERP_Admin::instance();
		}
	}
	
	public function load_modules(): void {
		do_action( 'kerp_before_modules_load' );
		KERP_Modules::instance()->load_enabled_modules();
		do_action( 'kerp_modules_loaded', KERP_Modules::instance()->get_loaded_modules() );
	}
	
	public static function get_path( string $path = '' ): string {
		return KERP_PATH . ltrim( $path, '/' );
	}
	
	public static function get_url( string $path = '' ): string {
		return KERP_URL . ltrim( $path, '/' );
	}
	
	public static function get_template_path( string $path = '' ): string {
		return KERP_TEMPLATES_PATH . ltrim( $path, '/' );
	}
	
	public static function get_asset_path( string $path = '' ): string {
		return KERP_ASSETS_PATH . ltrim( $path, '/' );
	}
	
	public static function get_asset_url( string $path = '' ): string {
		return KERP_ASSETS_URL . ltrim( $path, '/' );
	}
	
}
