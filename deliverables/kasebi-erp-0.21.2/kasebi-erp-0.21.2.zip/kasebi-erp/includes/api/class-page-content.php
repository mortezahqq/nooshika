<?php

defined( 'ABSPATH' ) || exit;

class KERP_Api_Page_Content {
	
	public static function register(): void {
		add_action( 'kasebi_ajax_erp_request_page_content', [ __CLASS__, 'request' ] );
		add_action( 'kasebi_ajax_erp_request_back_btn', [ __CLASS__, 'request' ] );
	}
	
	public static function request(): void {
		if (
			! is_user_logged_in() ||
			! KERP_App::instance()->current_user_has_access()
		) {
			self::send_error(
				'شما اجازه دسترسی به سامانه را ندارید.'
			);
		}
		
		$action = sanitize_key(
			wp_unslash( $_POST['action'] ?? '' )
		);
		
		$page = trim( wp_strip_all_tags( wp_unslash( (string) ( $_POST['page'] ?? '' ) ) ) );
		
		if ( $page === '' ) {
			self::send_error(
				'مسیر صفحه ارسال نشده است.'
			);
		}
		
		$args = self::get_clean_query_args(
			$_POST
		);
		
		$include_url = $action !== 'erp_request_back_btn';
		
		$return = self::build_page_response(
			$page,
			$args,
			$include_url
		);
		
		$return['message'] = '';
		$return['status']  = 'success';
		
		wp_send_json( $return );
	}
	
	private static function current_user_can_view( array $page_context ): bool {
		$page_definition = isset( $page_context['definition'] ) && is_array( $page_context['definition'] )
			? $page_context['definition']
			: [];

		if ( ! empty( $page_definition['unrestricted'] ) ) {
			return TRUE;
		}
		
		$permission = sanitize_text_field(
			(string) (
				$page_context['permission']
				?? $page_definition['permission']
				   ?? ''
			)
		);
		
		if ( $permission !== '' ) {
			return kerp_can( $permission, 'view' ) || kerp_can( $permission, );
		}
		
		$page_slug = sanitize_key(
			(string) (
				$page_context['slug']
				?? $page_context['page']
				   ?? $page_context['key']
				      ?? ''
			)
		);
		
		return $page_slug !== '' && kerp_can_page( $page_slug );
	}
	
	private static function get_clean_query_args( array $input ): array {
		unset( $input['action'], $input['page'] );
		
		return self::sanitize_query_args( wp_unslash( $input ) );
	}
	
	private static function sanitize_query_args( array $input ): array {
		$args = [];
		
		foreach ( $input as $key => $value ) {
			$clean_key = is_int( $key ) ? $key : sanitize_key( (string) $key );
			
			if ( $clean_key === '' ) {
				continue;
			}
			
			$value = self::sanitize_query_value( $value );
			
			if ( $value === '' || $value === NULL || $value === [] ) {
				continue;
			}
			
			$args[ $clean_key ] = $value;
		}
		
		return $args;
	}
	
	private static function sanitize_query_value( mixed $value ): mixed {
		if ( ! is_array( $value ) ) {
			return sanitize_text_field( (string) $value );
		}
		
		return self::sanitize_query_args( $value );
	}
	
	private static function bind_request_context( array $page_context ): void {
		$request_data = [];
		
		if ( ! empty( $page_context['query'] ) && is_array( $page_context['query'] ) ) {
			$request_data = $page_context['query'];
		}
		
		if ( ! empty( $page_context['params'] ) && is_array( $page_context['params'] ) ) {
			$request_data = array_replace( $request_data, $page_context['params'] );
		}
		
		if ( isset( $page_context['id'] ) && $page_context['id'] !== NULL ) {
			$request_data['id'] = absint( $page_context['id'] );
		}
		
		foreach ( $request_data as $key => $value ) {
			$_REQUEST[ $key ] = $value;
		}
	}
	
	private static function build_page_url( array $page_context ): string {
		$parts = isset( $page_context['parts'] ) && is_array( $page_context['parts'] )
			? $page_context['parts']
			: [];
		
		$parts = array_values( array_filter( array_map(
			static fn( mixed $part ): string => sanitize_title( (string) $part ),
			$parts
		) ) );
		
		$path = empty( $parts )
			? '/erp/'
			: '/erp/' . implode( '/', $parts ) . '/';
		
		$url = home_url( $path );
		
		if ( ! empty( $page_context['query'] ) && is_array( $page_context['query'] ) ) {
			$query = array_filter(
				$page_context['query'],
				static fn( mixed $value ): bool => $value !== 0 && $value !== '0'
			);
			
			if ( ! empty( $query ) ) {
				$url = add_query_arg( $query, $url );
			}
		}
		
		return $url;
	}
	
	private static function send_error( string $message ): void {
		wp_send_json( [
			'message' => $message,
			'status'  => 'error',
		] );
	}
	
	public static function build_page_response(
		string $page,
		array $args = [],
		bool $include_url = TRUE
	): array {
		$page = trim( wp_strip_all_tags( $page ) );
		
		if ( $page === '' ) {
			self::send_error( 'مسیر صفحه ارسال نشده است.' );
		}
		
		$args = self::sanitize_query_args( $args );
		
		$route = KERP_Core_Router::instance()->resolve( $page );
		
		$page_context = KERP_App::instance()->resolve_page_context(
			$route
		);
		
		if ( empty( $page_context['found'] ) ) {
			self::send_error( 'صفحه مورد نظر پیدا نشد.' );
		}
		
		if ( ! self::current_user_can_view( $page_context ) ) {
			self::send_error( 'شما اجازه مشاهده این صفحه را ندارید.' );
		}
		
		$route_query = (
			isset( $page_context['query'] ) &&
			is_array( $page_context['query'] )
		)
			? self::sanitize_query_args( $page_context['query'] )
			: [];
		
		/*
		 * Query استخراج‌شده از URL نسبت به آرگومان‌های ورودی
		 * اولویت دارد.
		 */
		$page_context['query'] = array_replace(
			$args,
			$route_query
		);
		
		self::bind_request_context( $page_context );
		
		$main = KERP_Helpers_Template::get_template(
			'app/main.php',
			[
				'page_context' => $page_context,
			]
		);
		
		if ( $main === FALSE ) {
			self::send_error( 'قالب اصلی سامانه پیدا نشد.' );
		}
		
		$site_title = get_bloginfo( 'name' );
		
		$page_title = wp_strip_all_tags(
			(string) ( $page_context['title'] ?? '' )
		);
		
		$response = [
			'main'  => $main,
			'title' => $page_title !== ''
				? $page_title . ' | ' . $site_title
				: $site_title,
		];
		
		if ( $include_url ) {
			$response['url'] = self::build_page_url(
				$page_context
			);
		}
		
		return $response;
	}
	
}
