<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Api_User_Preferences {
	
	/**
	 * متای اصلی ERP.
	 */
	public const META_DARK_MODE = 'kerp_dark_mode';
	
	/**
	 * متای قدیمی CRM.
	 *
	 * فعلاً برای سازگاری با قالب‌ها و اطلاعات قبلی نگه داشته شده است.
	 */
	public const LEGACY_META_DARK_MODE = 'crm_dark_mode';
	
	private static ?KERP_Api_User_Preferences $instance = NULL;
	
	public static function instance(): KERP_Api_User_Preferences {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {
		$this->register_hooks();
	}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	private function register_hooks(): void {
		add_action( 'kasebi_ajax_change_dark_mode', [ $this, 'save_dark_mode' ] );
		add_action( 'kasebi_ajax_change_skin', [ $this, 'change_skin' ] );
		add_action( 'kasebi_ajax_settings_save_profile', [ $this, 'save_profile' ] );
	}
	
	public function change_skin(): void {
		if ( ! is_user_logged_in() ) {
			wp_send_json(
				[
					'status'  => 'error',
					'message' => __( 'برای تغییر پوسته باید وارد حساب کاربری شوید.', 'kasebi-erp' ),
				]
			);
		}
		
		$skin = isset( $_POST['value'] )
			? sanitize_key( wp_unslash( $_POST['value'] ) )
			: '';
		
		$allowed_skins = [
			'default',
			'green',
			'blue',
			'egyptian',
			'purple',
			'red',
		];
		
		$allowed_skins = apply_filters(
			'kerp_allowed_user_skins',
			$allowed_skins
		);
		
		if ( ! in_array( $skin, $allowed_skins, TRUE ) ) {
			wp_send_json(
				[
					'status'  => 'error',
					'message' => __( 'پوسته انتخاب‌شده معتبر نیست.', 'kasebi-erp' ),
				]
			);
		}
		
		$user_id      = get_current_user_id();
		$current_skin = get_user_meta( $user_id, 'kerp_skin', TRUE );
		
		if ( $current_skin !== $skin ) {
			update_user_meta( $user_id, 'kerp_skin', $skin );
		}
		
		wp_send_json(
			[
				'status'  => 'success',
				'message' => __( 'پوسته با موفقیت تغییر کرد.', 'kasebi-erp' ),
				'value'   => $skin,
				'reload'  => TRUE,
			]
		);
	}
	
	/**
	 * ذخیره وضعیت دارک مود کاربر جاری.
	 */
	public function save_dark_mode(): void {
		$this->verify_request();
		
		$user_id = get_current_user_id();
		
		$is_active = $this->sanitize_boolean(
			$_POST['value'] ?? FALSE
		);
		$value     = $is_active ? '1' : '0';
		
		$updated = update_user_meta(
			$user_id,
			self::META_DARK_MODE,
			$value
		);
		
		/*
		 * سازگاری موقت با کدهای قدیمی CRM.
		 *
		 * وقتی تمام قالب‌ها از is_dark_mode() استفاده کردند،
		 * می‌توان این update را حذف کرد.
		 */
		update_user_meta(
			$user_id,
			self::LEGACY_META_DARK_MODE,
			$value
		);
		
		/*
		 * update_user_meta در صورت برابر بودن مقدار جدید و قبلی FALSE می‌دهد.
		 * بنابراین FALSE لزوماً به معنای خطا نیست.
		 */
		$current_value = get_user_meta(
			$user_id,
			self::META_DARK_MODE,
			TRUE
		);
		
		if ( (string) $current_value !== $value ) {
			$this->send_error(
				__( 'ذخیره تنظیمات ظاهری انجام نشد.', 'kasebi-erp' )
			);
		}
		
		do_action(
			'kerp_user_dark_mode_updated',
			$user_id,
			$is_active,
			$updated
		);
		
		wp_send_json(
			[
				'status'    => 'success',
				'message'   => __(
					'تنظیمات ظاهری ذخیره شد.',
					'kasebi-erp'
				),
				'dark_mode' => $is_active,
			]
		);
	}
	
	public function save_profile(): void {
		$this->verify_request();
		
		$user_id = get_current_user_id();
		$user    = get_userdata( $user_id );
		
		if ( ! $user instanceof WP_User ) {
			$this->send_error( __( 'حساب کاربری پیدا نشد.', 'kasebi-erp' ) );
		}
		
		$profile = isset( $_POST['profile'] ) && is_array( $_POST['profile'] )
			? wp_unslash( $_POST['profile'] )
			: [];
		
		$first_name       = sanitize_text_field( (string) ( $profile['first_name'] ?? '' ) );
		$last_name        = sanitize_text_field( (string) ( $profile['last_name'] ?? '' ) );
		$email_raw        = trim( (string) ( $profile['email'] ?? '' ) );
		$email            = sanitize_email( $email_raw );
		$phone            = KERP_Helpers_Phone::normalize( sanitize_text_field( (string) ( $profile['phone'] ?? '' ) ) );
		$new_password     = isset( $profile['new_password'] ) && ! is_array( $profile['new_password'] ) ? (string) $profile['new_password'] : '';
		$confirm_password = isset( $profile['confirm_password'] ) && ! is_array( $profile['confirm_password'] ) ? (string) $profile['confirm_password'] : '';
		
		if ( $first_name === '' ) {
			$this->send_error( __( 'نام را وارد کنید.', 'kasebi-erp' ) );
		}
		
		if ( $last_name === '' ) {
			$this->send_error( __( 'نام خانوادگی را وارد کنید.', 'kasebi-erp' ) );
		}
		
		if ( $email_raw !== '' && $email === '' ) {
			$this->send_error( __( 'ایمیل واردشده معتبر نیست.', 'kasebi-erp' ) );
		}
		
		if ( $email !== '' ) {
			$email_user_id = absint( email_exists( $email ) );
			
			if ( $email_user_id > 0 && $email_user_id !== $user_id ) {
				$this->send_error( __( 'این ایمیل قبلاً برای کاربر دیگری ثبت شده است.', 'kasebi-erp' ) );
			}
		}
		
		if ( $phone !== '' ) {
			$phone_user_id = KERP_Helpers_Phone::get_user_id( $phone );
			
			if ( $phone_user_id > 0 && $phone_user_id !== $user_id ) {
				$this->send_error( __( 'این شماره موبایل قبلاً برای کاربر دیگری ثبت شده است.', 'kasebi-erp' ) );
			}
		}
		
		$change_password = $new_password !== '' || $confirm_password !== '';
		
		if ( $change_password ) {
			if ( $new_password === '' || $confirm_password === '' ) {
				$this->send_error( __( 'برای تغییر رمز عبور، هر دو فیلد رمز را تکمیل کنید.', 'kasebi-erp' ) );
			}
			
			if ( $new_password !== $confirm_password ) {
				$this->send_error( __( 'رمز عبور جدید و تکرار آن یکسان نیستند.', 'kasebi-erp' ) );
			}
		}
		
		$display_name = trim( $first_name . ' ' . $last_name );
		$user_data    = [
			'ID'           => $user_id,
			'first_name'   => $first_name,
			'last_name'    => $last_name,
			'display_name' => $display_name !== '' ? $display_name : get_user_name_by_id( $user_id ),
		];
		
		if ( $email !== '' ) {
			$user_data['user_email'] = $email;
		}
		
		if ( $change_password ) {
			$user_data['user_pass'] = $new_password;
		}
		
		$result = wp_update_user( $user_data );
		
		if ( is_wp_error( $result ) ) {
			$this->send_error( $result->get_error_message() );
		}
		
		$phone_meta_key = KERP_Helpers_Phone::get_meta_key();
		update_user_meta( $user_id, $phone_meta_key, $phone );
		update_user_meta( $user_id, 'billing_phone', $phone );
		if ( array_key_exists( 'comment_badge', $profile ) && is_scalar( $profile['comment_badge'] ) ) {
			update_user_meta( $user_id, 'kerp_comment_badge', sanitize_text_field( (string) $profile['comment_badge'] ) );
		}
		
		do_action( 'kerp_current_user_profile_updated', $user_id, $profile, $change_password );
		
		$page_response = KERP_Api_Page_Content::build_page_response( '/erp/settings/', [], TRUE );
		$message       = $change_password
			? __( 'اطلاعات حساب کاربری و رمز عبور با موفقیت ذخیره شد.', 'kasebi-erp' )
			: __( 'اطلاعات حساب کاربری با موفقیت ذخیره شد.', 'kasebi-erp' );
		
		wp_send_json( array_merge( $page_response, [ 'status' => 'success', 'message' => $message ] ) );
	}
	
	/**
	 * دریافت وضعیت دارک مود.
	 */
	public function is_dark_mode( ?int $user_id = NULL ): bool {
		$user_id = $user_id ?: get_current_user_id();
		
		if ( $user_id <= 0 ) {
			return FALSE;
		}
		
		/*
		 * ابتدا کلید جدید ERP بررسی می‌شود.
		 */
		if ( metadata_exists( 'user', $user_id, self::META_DARK_MODE ) ) {
			return $this->sanitize_boolean(
				get_user_meta(
					$user_id,
					self::META_DARK_MODE,
					TRUE
				)
			);
		}
		
		/*
		 * بازگشت به کلید قدیمی CRM.
		 */
		
		return $this->sanitize_boolean(
			get_user_meta(
				$user_id,
				self::LEGACY_META_DARK_MODE,
				TRUE
			)
		);
	}
	
	/**
	 * کلاس مناسب body برای حالت تاریک.
	 */
	public function get_body_class( ?int $user_id = NULL ): string {
		return $this->is_dark_mode( $user_id )
			? 'dark-mode'
			: '';
	}
	
	/**
	 * مقدار مناسب برای کلاس active کلید دارک مود.
	 */
	public function get_switch_class( ?int $user_id = NULL ): string {
		return $this->is_dark_mode( $user_id )
			? 'active'
			: '';
	}
	
	private function verify_request(): void {
		if ( ! is_user_logged_in() ) {
			$this->send_error(
				__( 'برای انجام این عملیات وارد حساب شوید.', 'kasebi-erp' ),
				401
			);
		}
		
		if ( ! KERP_App::instance()->current_user_has_access() ) {
			$this->send_error(
				__( 'شما به ERP دسترسی ندارید.', 'kasebi-erp' ),
				403
			);
		}
	}
	
	private function sanitize_boolean( mixed $value ): bool {
		if ( is_bool( $value ) ) {
			return $value;
		}
		
		if ( is_int( $value ) || is_float( $value ) ) {
			return (int) $value === 1;
		}
		
		$value = strtolower(
			trim(
				sanitize_text_field(
					wp_unslash( (string) $value )
				)
			)
		);
		
		return in_array(
			$value,
			[
				'1',
				'true',
				'yes',
				'on',
				'active',
			],
			TRUE
		);
	}
	
	private function send_error(
		string $message,
		int $status_code = 400
	): void {
		wp_send_json(
			[
				'status'  => 'error',
				'message' => $message,
			],
			$status_code
		);
	}
	
}
