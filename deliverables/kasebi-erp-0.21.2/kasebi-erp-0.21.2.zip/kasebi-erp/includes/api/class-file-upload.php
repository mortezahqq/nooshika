<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Api_File_Upload {
	
	private static ?self $instance = NULL;
	private string       $uploaded_files;
	private string       $db_charset;
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {
		global $wpdb;
		
		$this->uploaded_files = $wpdb->prefix . 'kasebi_erp_uploaded_files';
		$this->db_charset     = $wpdb->get_charset_collate();
		
		add_action(
			'kasebi_ajax_handle_file_upload',
			[ $this, 'handle_file_upload' ]
		);
	}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize a singleton.' );
	}
	
	public static function install(): void {
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( self::instance()->get_uploaded_files_table_query() );
	}
	
	public function handle_file_upload(): void {
		if (
			! is_user_logged_in() ||
			! KERP_App::instance()->current_user_has_access()
		) {
			wp_send_json( [
				'status'  => 'error',
				'message' => __( 'شما اجازه بارگذاری فایل را ندارید.', 'kasebi-erp' ),
			] );
		}
		
		if ( empty( $_FILES['file'] ) || ! is_array( $_FILES['file'] ) ) {
			wp_send_json( [
				'status'  => 'error',
				'message' => __( 'فایلی ارسال نشده است.', 'kasebi-erp' ),
			] );
		}
		
		$upload_context = sanitize_key(
			wp_unslash( $_POST['upload_context'] ?? 'general' )
		);
		
		$directory = trim(
			(string) apply_filters(
				'kerp_file_upload_directory',
				$upload_context,
				$upload_context
			),
			'/'
		);
		
		$can_upload = (bool) apply_filters(
			'kerp_can_upload_file',
			TRUE,
			$upload_context,
			get_current_user_id()
		);
		
		if ( ! $can_upload ) {
			wp_send_json( [
				'status'  => 'error',
				'message' => __( 'شما اجازه بارگذاری این فایل را ندارید.', 'kasebi-erp' ),
			] );
		}
		
		$context = [
			'file_name'         => sanitize_text_field(
				wp_unslash( $_POST['file_name'] ?? '' )
			),
			'dzuuid'            => sanitize_text_field(
				wp_unslash( $_POST['dzuuid'] ?? '' )
			),
			'dzchunkindex'      => isset( $_POST['dzchunkindex'] )
				? absint( $_POST['dzchunkindex'] )
				: - 1,
			'dztotalchunkcount' => isset( $_POST['dztotalchunkcount'] )
				? absint( $_POST['dztotalchunkcount'] )
				: - 1,
			'dztotalfilesize'   => isset( $_POST['dztotalfilesize'] )
				? absint( $_POST['dztotalfilesize'] )
				: 0,
			'direct'            => TRUE,
		];
		
		$file   = wp_unslash( $_FILES['file'] );
		$result = KERP_Helpers_File::instance()->handle_upload_file(
			$file,
			$directory,
			$context
		);
		
		if ( empty( $result['ok'] ) ) {
			wp_send_json( [
				'status'     => 'error',
				'message'    => $result['msg'] ?? __( 'بارگذاری فایل ناموفق بود.', 'kasebi-erp' ),
				'attachment' => '',
				'url'        => '',
				'storage'    => $result['storage'] ?? 'none',
				'data'       => $result,
			] );
		}
		
		$file_url = esc_url_raw( (string) ( $result['url'] ?? '' ) );
		
		if ( $file_url === '' ) {
			wp_send_json( [
				'status'     => 'success',
				'message'    => $result['msg'] ?? '',
				'attachment' => '',
				'url'        => '',
				'storage'    => $result['storage'] ?? 'chunk',
				'data'       => $result,
			] );
		}
		
		$file_id = $this->insert_uploaded_file(
			$file,
			$result,
			$upload_context,
			$context
		);
		
		if ( is_wp_error( $file_id ) ) {
			wp_send_json( [
				'status'     => 'error',
				'message'    => $file_id->get_error_message(),
				'attachment' => $file_url,
				'url'        => $file_url,
				'storage'    => $result['storage'] ?? '',
				'data'       => $result,
			] );
		}
		
		$result['file_id'] = $file_id;
		
		do_action(
			'kerp_file_uploaded',
			[
				'id'             => $file_id,
				'user_id'        => get_current_user_id(),
				'upload_context' => $upload_context,
				'name'           => (string) ( $result['name'] ?? '' ),
				'original_name'  => sanitize_text_field( wp_basename( (string) ( $file['name'] ?? '' ) ) ),
				'path'           => $this->get_record_path( $this->resolve_file_path( $file_url ) ),
				'url'            => $file_url,
				'storage'        => (string) ( $result['storage'] ?? '' ),
			]
		);
		
		wp_send_json( [
			'status'     => 'success',
			'message'    => $result['msg'] ?? '',
			'attachment' => $file_url,
			'url'        => $file_url,
			'file_id'    => $file_id,
			'storage'    => $result['storage'] ?? '',
			'data'       => $result,
		] );
	}
	
	public function get_uploaded_file_data( string $file_url ): ?array {
		global $wpdb;
		
		$file_url = esc_url_raw( $file_url );
		
		if ( $file_url === '' ) {
			return NULL;
		}
		
		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$this->uploaded_files} WHERE file_url = %s ORDER BY id DESC LIMIT 1",
				$file_url
			),
			ARRAY_A
		);
		
		return is_array( $row ) ? $row : NULL;
	}
	
	private function insert_uploaded_file(
		array $file,
		array $result,
		string $upload_context,
		array $context
	): int|WP_Error {
		global $wpdb;
		
		$original_name = sanitize_text_field(
			wp_basename( (string) ( $file['name'] ?? '' ) )
		);
		$saved_name    = sanitize_file_name(
			(string) ( $result['name'] ?? '' )
		);
		$file_url      = esc_url_raw( (string) ( $result['url'] ?? '' ) );
		$absolute_path = $this->resolve_file_path( $file_url );
		$file_path     = $this->get_record_path( $absolute_path );
		$file_type     = wp_check_filetype( $original_name );
		$file_ext      = sanitize_key(
			(string) ( $file_type['ext'] ?? pathinfo( $saved_name, PATHINFO_EXTENSION ) )
		);
		$mime_type     = sanitize_mime_type(
			(string) ( $file_type['type'] ?? ( $file['type'] ?? '' ) )
		);
		$file_size     = absint( $context['dztotalfilesize'] ?? 0 );
		
		if ( $file_size === 0 && $absolute_path !== '' && is_file( $absolute_path ) ) {
			$file_size = (int) filesize( $absolute_path );
		}
		
		if ( $file_size === 0 ) {
			$file_size = absint( $file['size'] ?? 0 );
		}
		
		$ip_address = sanitize_text_field(
			wp_unslash( $_SERVER['REMOTE_ADDR'] ?? '' )
		);
		$ip_address = filter_var( $ip_address, FILTER_VALIDATE_IP )
			? $ip_address
			: NULL;
		
		$data = apply_filters(
			'kerp_uploaded_file_record_data',
			[
				'user_id'        => get_current_user_id(),
				'upload_context' => $upload_context,
				'original_name'  => $original_name,
				'saved_name'     => $saved_name,
				'file_url'       => $file_url,
				'file_path'      => $file_path !== '' ? $file_path : $file_url,
				'file_ext'       => $file_ext,
				'mime_type'      => $mime_type,
				'file_size'      => $file_size,
				'storage'        => sanitize_key( (string) ( $result['storage'] ?? 'local' ) ),
				'ip_address'     => $ip_address,
				'uploaded_at'    => current_time( 'mysql' ),
			],
			$file,
			$result
		);
		
		$inserted = $wpdb->insert(
			$this->uploaded_files,
			$data,
			[
				'%d',
				'%s',
				'%s',
				'%s',
				'%s',
				'%s',
				'%s',
				'%s',
				'%d',
				'%s',
				'%s',
				'%s',
			]
		);
		
		if ( $inserted === FALSE ) {
			return new WP_Error(
				'kerp_uploaded_file_insert_failed',
				__( 'فایل بارگذاری شد اما ثبت اطلاعات آن در پایگاه داده ناموفق بود.', 'kasebi-erp' )
			);
		}
		
		return (int) $wpdb->insert_id;
	}
	
	private function resolve_file_path( string $file_url ): string {
		$upload_dir = wp_upload_dir();
		$base_url   = trailingslashit( (string) ( $upload_dir['baseurl'] ?? '' ) );
		$base_dir   = trailingslashit( (string) ( $upload_dir['basedir'] ?? '' ) );
		
		if ( $base_url === '' || $base_dir === '' || ! str_starts_with( $file_url, $base_url ) ) {
			return '';
		}
		
		$relative_path = rawurldecode(
			ltrim( substr( $file_url, strlen( $base_url ) ), '/' )
		);
		
		return wp_normalize_path( $base_dir . $relative_path );
	}
	
	private function get_record_path( string $absolute_path ): string {
		if ( $absolute_path === '' ) {
			return '';
		}
		
		$absolute_path = wp_normalize_path( $absolute_path );
		$abspath       = trailingslashit( wp_normalize_path( ABSPATH ) );
		
		if ( str_starts_with( $absolute_path, $abspath ) ) {
			return '/' . ltrim( substr( $absolute_path, strlen( $abspath ) ), '/' );
		}
		
		return $absolute_path;
	}
	
	private function get_uploaded_files_table_query(): string {
		return <<<SQL
			CREATE TABLE {$this->uploaded_files} (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				upload_context VARCHAR(100) NOT NULL DEFAULT 'general',
				original_name VARCHAR(255) NOT NULL,
				saved_name VARCHAR(255) NOT NULL,
				file_url TEXT NOT NULL,
				file_path TEXT NOT NULL,
				file_ext VARCHAR(20) NOT NULL DEFAULT '',
				mime_type VARCHAR(100) NOT NULL DEFAULT '',
				file_size BIGINT UNSIGNED NOT NULL DEFAULT 0,
				storage VARCHAR(20) NOT NULL DEFAULT 'local',
				ip_address VARCHAR(45) DEFAULT NULL,
				uploaded_at DATETIME NOT NULL,
				PRIMARY KEY (id),
				KEY user_id (user_id),
				KEY upload_context (upload_context),
				KEY uploaded_at (uploaded_at)
			) {$this->db_charset};
		SQL;
	}
	
}