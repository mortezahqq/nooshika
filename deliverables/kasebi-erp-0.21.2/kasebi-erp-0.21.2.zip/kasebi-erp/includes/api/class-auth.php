<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Api_Auth {
	
	private const IMPERSONATOR_COOKIE = 'kerp_impersonator';
	
	private const IMPERSONATION_TTL   = 7200;
	
	private static ?KERP_Api_Auth $instance = NULL;
	
	public static function instance(): KERP_Api_Auth {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {
		add_action(
			'kasebi_ajax_login_as_user',
			[ $this, 'login_as_user' ]
		);
		
		add_action(
			'kasebi_ajax_reset_password',
			[ $this, 'reset_password' ]
		);
		
		add_action(
			'kasebi_ajax_restore_admin_session',
			[ $this, 'restore_admin_session' ]
		);
	}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize singleton.' );
	}
	
	/**
	 * ورود مدیر به حساب کاربر انتخاب‌شده.
	 */
	public function login_as_user(): void {
		$this->verify_nonce();
		$this->verify_impersonation_permission();
		
		$actor_id = get_current_user_id();
		$target   = $this->get_requested_user();
		
		if ( $target->ID === $actor_id ) {
			$this->send_error(
				__( 'شما هم‌اکنون با همین حساب وارد شده‌اید.', 'kasebi-erp' )
			);
		}
		
		if ( ! $this->can_manage_target_user( $target ) ) {
			$this->send_error(
				__( 'اجازه ورود به حساب این کاربر را ندارید.', 'kasebi-erp' ),
				403
			);
		}
		
		$this->set_impersonator_cookie( $actor_id );
		
		wp_clear_auth_cookie();
		wp_set_current_user( $target->ID );
		wp_set_auth_cookie(
			$target->ID,
			TRUE,
			is_ssl()
		);
		
		do_action(
			'kerp_auth_login_as_user',
			$actor_id,
			$target->ID
		);
		
		$redirect_url = apply_filters(
			'kerp_auth_login_as_user_redirect',
			home_url( '/erp/' ),
			$target,
			$actor_id
		);
		
		wp_send_json(
			[
				'status'  => 'success',
				'message' => sprintf(
				/* translators: %s: user display name */
					__(
						'با حساب %s وارد شدید.',
						'kasebi-erp'
					),
					get_user_name_by_id( $target->ID )
				),
				'url'     => esc_url_raw( $redirect_url ),
				'user_id' => (int) $target->ID,
			]
		);
	}
	
	/**
	 * بازگشت از حساب کاربر به حساب مدیر اصلی.
	 */
	public function restore_admin_session(): void {
		$this->verify_nonce();
		
		if ( ! is_user_logged_in() ) {
			$this->send_error(
				__( 'نشست کاربری فعالی وجود ندارد.', 'kasebi-erp' ),
				401
			);
		}
		
		$impersonator_id = $this->get_impersonator_id();
		
		if ( $impersonator_id <= 0 ) {
			$this->send_error(
				__(
					'اطلاعات حساب مدیر اصلی پیدا نشد.',
					'kasebi-erp'
				),
				403
			);
		}
		
		$impersonator = get_userdata( $impersonator_id );
		
		if ( ! $impersonator instanceof WP_User ) {
			$this->clear_impersonator_cookie();
			
			$this->send_error(
				__( 'حساب مدیر اصلی معتبر نیست.', 'kasebi-erp' ),
				403
			);
		}
		
		$capability = $this->get_impersonation_capability();
		
		if ( ! user_can( $impersonator, $capability ) ) {
			$this->clear_impersonator_cookie();
			
			$this->send_error(
				__(
					'مدیر اصلی دیگر مجوز لازم را ندارد.',
					'kasebi-erp'
				),
				403
			);
		}
		
		$current_user_id = get_current_user_id();
		
		wp_clear_auth_cookie();
		wp_set_current_user( $impersonator->ID );
		wp_set_auth_cookie(
			$impersonator->ID,
			TRUE,
			is_ssl()
		);
		
		$this->clear_impersonator_cookie();
		
		do_action(
			'kerp_auth_restore_admin_session',
			$impersonator->ID,
			$current_user_id
		);
		
		wp_send_json(
			[
				'status'  => 'success',
				'message' => __(
					'به حساب مدیر بازگشتید.',
					'kasebi-erp'
				),
				'url'     => esc_url_raw( home_url( '/erp/' ) ),
			]
		);
	}
	
	/**
	 * تولید رمز جدید برای یک کاربر.
	 */
	public function reset_password(): void {
		$this->verify_nonce();
		$this->verify_password_reset_permission();
		
		$actor_id = get_current_user_id();
		$target   = $this->get_requested_user();
		
		if ( $target->ID === $actor_id ) {
			$this->send_error(
				__(
					'برای تغییر رمز حساب خودتان از بخش تنظیمات حساب استفاده کنید.',
					'kasebi-erp'
				)
			);
		}
		
		if ( ! $this->can_manage_target_user( $target ) ) {
			$this->send_error(
				__(
					'اجازه تغییر رمز این کاربر را ندارید.',
					'kasebi-erp'
				),
				403
			);
		}
		
		$new_password = wp_generate_password(
			12,
			FALSE,
			FALSE
		);
		
		wp_set_password(
			$new_password,
			$target->ID
		);
		
		clean_user_cache( $target->ID );
		
		do_action(
			'kerp_auth_user_password_reset',
			$target->ID,
			$actor_id
		);
		
		$password_html = sprintf(
			'<div class="kerp-new-password">
				<p>%1$s</p>
				<p>
					<code dir="ltr">%2$s</code>
				</p>
				<p class="text-soft">%3$s</p>
			</div>',
			esc_html__(
				'رمز عبور جدید:',
				'kasebi-erp'
			),
			esc_html( $new_password ),
			esc_html__(
				'رمز را در محل امن ذخیره و برای کاربر ارسال کنید.',
				'kasebi-erp'
			)
		);
		
		wp_send_json(
			[
				'status'  => 'success',
				'message' => __(
					'رمز عبور با موفقیت تغییر کرد.',
					'kasebi-erp'
				),
				'html'    => $password_html,
				'user_id' => (int) $target->ID,
			]
		);
	}
	
	/**
	 * آیا اکنون در حالت ورود به‌عنوان کاربر قرار داریم؟
	 */
	public function is_impersonating(): bool {
		return $this->get_impersonator_id() > 0;
	}
	
	/**
	 * شناسه مدیر اصلی.
	 */
	public function get_impersonator_id(): int {
		$cookie = isset( $_COOKIE[ self::IMPERSONATOR_COOKIE ] )
			? sanitize_text_field(
				wp_unslash(
					(string) $_COOKIE[ self::IMPERSONATOR_COOKIE ]
				)
			)
			: '';
		
		if ( $cookie === '' || ! str_contains( $cookie, '.' ) ) {
			return 0;
		}
		
		[ $encoded_payload, $received_signature ] = explode(
			'.',
			$cookie,
			2
		);
		
		if (
			$encoded_payload === '' ||
			$received_signature === ''
		) {
			return 0;
		}
		
		$expected_signature = $this->sign_payload(
			$encoded_payload
		);
		
		if (
			! hash_equals(
				$expected_signature,
				$received_signature
			)
		) {
			return 0;
		}
		
		$decoded_payload = $this->base64_url_decode(
			$encoded_payload
		);
		
		if ( $decoded_payload === '' ) {
			return 0;
		}
		
		$payload = json_decode(
			$decoded_payload,
			TRUE
		);
		
		if ( ! is_array( $payload ) ) {
			return 0;
		}
		
		$user_id = absint( $payload['user_id'] ?? 0 );
		$expires = absint( $payload['expires'] ?? 0 );
		
		if (
			$user_id <= 0 ||
			$expires <= time()
		) {
			$this->clear_impersonator_cookie();
			
			return 0;
		}
		
		return $user_id;
	}
	
	private function get_requested_user(): WP_User {
		$user_id = absint(
			wp_unslash( $_POST['user_id'] ?? 0 )
		);
		
		if ( $user_id <= 0 ) {
			$this->send_error(
				__( 'شناسه کاربر معتبر نیست.', 'kasebi-erp' )
			);
		}
		
		$user = get_userdata( $user_id );
		
		if ( ! $user instanceof WP_User ) {
			$this->send_error(
				__( 'کاربر موردنظر پیدا نشد.', 'kasebi-erp' ),
				404
			);
		}
		
		return $user;
	}
	
	private function verify_nonce(): void {
		if ( ! is_user_logged_in() ) {
			$this->send_error(
				__( 'برای انجام این عملیات وارد حساب شوید.', 'kasebi-erp' ),
				401
			);
		}
	}
	
	public function can_login_as_user( WP_User $target ): bool {
		return is_user_logged_in()
			&& $target->ID !== get_current_user_id()
			&& current_user_can( $this->get_impersonation_capability() )
			&& $this->can_manage_target_user( $target );
	}

	private function verify_impersonation_permission(): void {
		$capability = $this->get_impersonation_capability();
		
		if ( ! current_user_can( $capability ) ) {
			$this->send_error(
				__(
					'اجازه ورود به حساب کاربران را ندارید.',
					'kasebi-erp'
				),
				403
			);
		}
	}
	
	private function verify_password_reset_permission(): void {
		$capability = (string) apply_filters(
			'kerp_auth_password_reset_capability',
			'manage_options'
		);
		
		if (
			$capability === '' ||
			! current_user_can( $capability )
		) {
			$this->send_error(
				__(
					'اجازه تغییر رمز کاربران را ندارید.',
					'kasebi-erp'
				),
				403
			);
		}
	}
	
	private function get_impersonation_capability(): string {
		$capability = (string) apply_filters(
			'kerp_auth_impersonation_capability',
			'manage_options'
		);
		
		return $capability !== ''
			? $capability
			: 'manage_options';
	}
	
	private function can_manage_target_user( WP_User $target ): bool {
		$actor_id = get_current_user_id();
		
		/*
		 * در شبکه وردپرس، فقط Super Admin می‌تواند وارد
		 * حساب یک Super Admin دیگر شود.
		 */
		if (
			is_multisite() &&
			is_super_admin( $target->ID ) &&
			! is_super_admin( $actor_id )
		) {
			return FALSE;
		}
		
		return (bool) apply_filters(
			'kerp_auth_can_manage_target_user',
			TRUE,
			$target,
			$actor_id
		);
	}
	
	private function set_impersonator_cookie( int $user_id ): void {
		$expires = time() + self::IMPERSONATION_TTL;
		
		$payload = [
			'user_id' => $user_id,
			'expires' => $expires,
		];
		
		$encoded_payload = $this->base64_url_encode(
			wp_json_encode( $payload )
		);
		
		$signature = $this->sign_payload(
			$encoded_payload
		);
		
		$this->set_cookie(
			self::IMPERSONATOR_COOKIE,
			$encoded_payload . '.' . $signature,
			$expires
		);
		
		/*
		 * setcookie مقدار $_COOKIE را در همان درخواست تغییر نمی‌دهد.
		 */
		$_COOKIE[ self::IMPERSONATOR_COOKIE ] =
			$encoded_payload . '.' . $signature;
	}
	
	private function clear_impersonator_cookie(): void {
		$this->set_cookie(
			self::IMPERSONATOR_COOKIE,
			'',
			time() - HOUR_IN_SECONDS
		);
		
		unset( $_COOKIE[ self::IMPERSONATOR_COOKIE ] );
	}
	
	private function set_cookie(
		string $name,
		string $value,
		int $expires
	): void {
		setcookie(
			$name,
			$value,
			[
				'expires'  => $expires,
				'path'     => '/',
				'domain'   => defined( 'COOKIE_DOMAIN' )
					? (string) COOKIE_DOMAIN
					: '',
				'secure'   => is_ssl(),
				'httponly' => TRUE,
				'samesite' => 'Lax',
			]
		);
	}
	
	private function sign_payload( string $payload ): string {
		return hash_hmac(
			'sha256',
			$payload,
			wp_salt( 'auth' )
		);
	}
	
	private function base64_url_encode( string $value ): string {
		return rtrim(
			strtr(
				base64_encode( $value ),
				'+/',
				'-_'
			),
			'='
		);
	}
	
	private function base64_url_decode( string $value ): string {
		$remainder = strlen( $value ) % 4;
		
		if ( $remainder > 0 ) {
			$value .= str_repeat(
				'=',
				4 - $remainder
			);
		}
		
		$decoded = base64_decode(
			strtr(
				$value,
				'-_',
				'+/'
			),
			TRUE
		);
		
		return is_string( $decoded )
			? $decoded
			: '';
	}
	
	private function send_error(
		string $message,
		int $status_code = 400
	): void {
		wp_send_json(
			[
				'status'  => 'error',
				'message' => $message,
			],
			$status_code
		);
	}
	
}
