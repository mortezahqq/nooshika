<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Settings_Panel_Navigation {
	public const OPTION = 'kerp_panel_navigation_pages';
	private const LEGACY_OPTION = 'kerp_panel_navigation';
	public const PERMISSION = 'panel_navigation.manage_settings';
	private static ?self $instance = NULL;

	public static function instance(): self { return self::$instance ??= new self(); }

	private function __construct() {
		add_filter( 'kerp_app_pages', [ $this, 'register_page' ] );
		add_filter( 'kerp_employee_permission_groups', [ $this, 'register_permissions' ], 100 );
		add_filter( 'nooshika_panel_pages_list_final', [ $this, 'apply_navigation' ], PHP_INT_MAX );
		add_action( 'kasebi_ajax_panel_navigation_save', [ $this, 'save' ] );
	}

	public function register_page( array $pages ): array {
		$pages['panel-navigation-settings'] = [
			'title' => 'نمایش ماژول‌ها در پنل کاربری', 'route' => 'settings/panel-navigation',
			'type' => 'settings', 'template' => 'app/pages/panel-navigation-settings.php',
			'permission' => self::PERMISSION,
			'navigation' => [
				'group' => [ 'key' => 'settings', 'title' => 'تنظیمات', 'icon' => 'kik fa-settings-02', 'order' => 100, 'sep_before' => TRUE ],
				'icon' => 'ni ni-layout', 'order' => 95,
			],
		];
		return $pages;
	}

	public function register_permissions( array $groups ): array {
		$groups['panel_navigation'] = [
			'key' => 'panel_navigation', 'label' => 'نمایش پنل کاربری', 'icon' => 'ni ni-layout', 'order' => 100,
			'blocks' => [ 'panel_navigation' => [
				'key' => 'panel_navigation', 'label' => 'نمایش ماژول‌ها',
				'permissions' => [ 'manage_settings' => [ 'key' => self::PERMISSION, 'label' => 'مدیریت عنوان و آیکون ماژول‌ها در پنل کاربری', 'type' => 'action' ] ],
			] ],
		];
		return $groups;
	}

	/** Each loaded module registers its own public pages through this filter. */
	public static function register_entries( array $rows, string $module, string $label, array $pages ): array {
		foreach ( $pages as $key => $page ) {
			$rows[ $key ] = [ 'module' => $module, 'label' => $label, 'title' => $page['label'], 'icon' => $page['icon'] ];
		}
		return $rows;
	}

	public function rows(): array {
		$saved = get_option( self::OPTION, [] );
		$saved = is_array( $saved ) ? $saved : [];
		$legacy = get_option( self::LEGACY_OPTION, [] );
		$legacy = is_array( $legacy ) ? $legacy : [];
		$rows = [];
		foreach ( (array) apply_filters( 'kerp_panel_navigation_pages', [] ) as $key => $definition ) {
			if ( ! is_string( $key ) || ! preg_match( '/^[a-z0-9_-]+$/D', $key ) || ! is_array( $definition ) || ! is_string( $definition['module'] ?? NULL ) ) { continue; }
			if ( ! KERP_Modules::instance()->is_module_loaded( $definition['module'] ) ) { continue; }
			$default_title = (string) ( $definition['title'] ?? $key );
			$default_icon = (string) ( $definition['icon'] ?? '' );
			// Keep existing choices until a page is explicitly saved or reset.
			$custom = is_array( $saved[ $key ] ?? NULL ) ? $saved[ $key ] : ( $legacy[ $definition['module'] ] ?? [] );
			$custom = is_array( $custom ) ? $custom : [];
			$rows[ $key ] = [
				'label' => (string) ( $definition['label'] ?? $default_title ),
				'module' => $definition['module'],
				'default_title' => $default_title, 'default_icon' => $default_icon,
				'title' => is_string( $custom['title'] ?? NULL ) && $custom['title'] !== '' ? $custom['title'] : $default_title,
				'icon' => is_string( $custom['icon'] ?? NULL ) && $custom['icon'] !== '' ? $custom['icon'] : $default_icon,
				'custom' => $custom,
			];
		}
		return $rows;
	}

	public function apply_navigation( array $pages ): array {
		foreach ( $this->rows() as $key => $row ) {
			// Never create a page, alter visibility, or replace unrelated page attributes.
			if ( ! isset( $pages[ $key ] ) || ! is_array( $pages[ $key ] ) ) { continue; }
			foreach ( [ 'title' => 'label', 'icon' => 'icon' ] as $field => $attribute ) {
				if ( is_string( $row['custom'][ $field ] ?? NULL ) && $row['custom'][ $field ] !== '' ) {
					$pages[ $key ][ $attribute ] = $row[ $field ];
				}
			}
		}
		return $pages;
	}

	public function save(): void {
		if ( ! is_user_logged_in() || ! KERP_App::instance()->current_user_has_access() || ! kerp_can( self::PERMISSION, 'action' ) ) {
			$this->error( 'اجازه تغییر تنظیمات نمایش پنل کاربری را ندارید.' );
		}
		$nonce = is_string( $_POST['nonce'] ?? NULL ) ? wp_unslash( $_POST['nonce'] ) : '';
		if ( ! wp_verify_nonce( $nonce, 'kerp_panel_navigation' ) ) { $this->error( 'اعتبار فرم منقضی شده است؛ صفحه را تازه کنید.' ); }
		$payload = is_string( $_POST['settings_payload'] ?? NULL ) ? json_decode( wp_unslash( $_POST['settings_payload'] ), TRUE ) : NULL;
		if ( ! is_array( $payload ) || ! $payload ) { $this->error( 'ساختار تنظیمات معتبر نیست.' ); }
		$rows = $this->rows();
		$stored = get_option( self::OPTION, [] );
		$clean = is_array( $stored ) ? $stored : [];
		foreach ( $payload as $key => $values ) {
			if ( ! isset( $rows[ $key ] ) || ! is_array( $values ) || ! is_string( $values['title'] ?? NULL ) || ! is_string( $values['icon'] ?? NULL ) ) {
				$this->error( 'یکی از ماژول‌ها یا مقادیر ارسال‌شده معتبر نیست.' );
			}
			$title = trim( sanitize_text_field( $values['title'] ) );
			$icon = trim( $values['icon'] );
			if ( strlen( $title ) > 600 || strlen( $icon ) > 300 || ( $icon !== '' && ! preg_match( '/^[a-zA-Z0-9_-]+(?:\s+[a-zA-Z0-9_-]+)*$/D', $icon ) ) ) {
				$this->error( 'عنوان بیش از حد طولانی است یا کلاس آیکون معتبر نیست: ' . $rows[ $key ]['label'] );
			}
			$icon = preg_replace( '/\s+/', ' ', $icon );
			$clean[ $key ] = [
				'title' => $title === $rows[ $key ]['default_title'] ? '' : $title,
				'icon' => $icon === $rows[ $key ]['default_icon'] ? '' : $icon,
			];
		}
		if ( $clean !== $stored && ! update_option( self::OPTION, $clean, FALSE ) ) { $this->error( 'ذخیره تنظیمات انجام نشد؛ دوباره تلاش کنید.' ); }
		wp_send_json( [ 'status' => 'success', 'message' => 'تنظیمات نمایش ماژول‌ها ذخیره شد.' ] );
	}

	private function error( string $message ): void { wp_send_json( [ 'status' => 'error', 'message' => $message ] ); }
}
