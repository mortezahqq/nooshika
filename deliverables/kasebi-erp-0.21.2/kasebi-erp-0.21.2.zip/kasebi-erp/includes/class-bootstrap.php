<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Bootstrap {
	
	public static function init(): void {
		self::register_autoloader();
		KERP_Modules_Sms_Logs_Module::register_capture_hooks();
		KERP_Modules_Ajax_Module::register_lifecycle_hooks();
		require_once KERP_INC_PATH . 'helpers/functions.php';
		
		add_action( 'plugins_loaded', [ self::class, 'boot' ], 20 );
		add_action( 'before_woocommerce_init', [ self::class, 'declare_woocommerce_compatibility' ] );
		// Managed coupons must not turn into unrestricted discounts when their module is disabled.
		add_filter( 'woocommerce_coupon_is_valid', [ self::class, 'guard_referral_coupon' ], 5, 2 );
		add_action( 'woocommerce_before_pay_action', [ self::class, 'guard_referral_payment' ], 5 );
        add_filter( 'woocommerce_is_purchasable', [ self::class, 'guard_gold_product' ], 5, 2 );
        add_action( 'woocommerce_before_pay_action', [ self::class, 'guard_gold_payment' ], 5 );
		
		register_activation_hook( KERP_FILE, [ self::class, 'activate' ] );
		register_deactivation_hook( KERP_FILE, [ self::class, 'deactivate' ] );
	}
	
	public static function autoload( string $class ): void {
		$prefix = 'KERP_';
		
		if ( ! str_starts_with( $class, $prefix ) ) {
			return;
		}
		
		$relative_class = substr( $class, strlen( $prefix ) );
		
		if ( ! preg_match( '/^[A-Za-z0-9_]+$/', $relative_class ) ) {
			return;
		}
		
		$parts = array_values(
			array_filter(
				explode( '_', strtolower( $relative_class ) )
			)
		);
		
		if ( empty( $parts ) ) {
			return;
		}
		
		$candidates = [];
		$count      = count( $parts );
		
		/*
		 * مسیرهای احتمالی را از ساختار تو‌در‌تو تا نام فایل چندبخشی می‌سازد.
		 */
		for ( $filename_parts_count = 1; $filename_parts_count <= $count; $filename_parts_count ++ ) {
			$folder_parts = array_slice(
				$parts,
				0,
				$count - $filename_parts_count
			);
			
			$filename_parts = array_slice(
				$parts,
				$count - $filename_parts_count
			);
			
			$folder    = implode( '/', $folder_parts );
			$file_name = 'class-' . implode( '-', $filename_parts ) . '.php';
			
			$candidates[] = KERP_INC_PATH
			                . ( $folder !== '' ? $folder . '/' : '' )
			                . $file_name;
		}
		
		foreach ( $candidates as $path ) {
			if ( ! is_readable( $path ) ) {
				continue;
			}
			
			require_once $path;
			
			return;
		}
	}
	
	public static function boot(): void {
		KERP_Plugin::instance();
		if ( get_option( 'kerp_payments_db_version' ) ) { KERP_Modules_Payments_Module::boot_runtime(); }
		// Existing installment contracts must keep their access boundaries if the module is disabled.
		if ( get_option( 'kerp_installment_db_version' ) ) {
			KERP_Modules_Installment_Management_Access::boot();
		}
	}

	public static function guard_referral_coupon( $valid, $coupon ) {
		if ( $coupon->get_meta( '_kerp_referral_code' ) && ! KERP_Modules::instance()->is_module_loaded( 'referrals' ) ) {
			throw new Exception( 'ماژول همکاری در فروش یا پیش‌نیازهای آن فعال نیست.' );
		}
		return $valid;
	}

	public static function guard_referral_payment( $order ): void {
		if ( KERP_Modules::instance()->is_module_loaded( 'referrals' ) || $order->get_meta( '_kerp_referral_id' ) ) { return; }
		foreach ( $order->get_coupon_codes() as $code ) {
			$coupon = new WC_Coupon( $code );
			if ( $coupon->get_meta( '_kerp_referral_code' ) ) {
				wp_die( 'ثبت معرفی این سفارش کامل نشده و ماژول همکاری در فروش فعال نیست.', 'همکاری در فروش', [ 'response' => 400, 'back_link' => true ] );
			}
		}
	}
	
    public static function guard_gold_product( $purchasable, $product ) {
        if ( KERP_Modules::instance()->is_module_loaded( 'gold' ) ) { return $purchasable; }
        $settings = (array) get_option( 'kerp_gold_settings', [] );
        if ( $product->get_meta( '_kerp_gold_replace' ) !== '' || $product->get_meta( '_kerp_gold_dynamic' ) === 'yes' || ( (int) ( $settings['plus_product'] ?? 0 ) > 0 && $product->get_id() === (int) $settings['plus_product'] ) ) { return false; }
        return $purchasable;
    }

    public static function guard_gold_payment( $order ): void {
        if ( KERP_Modules::instance()->is_module_loaded( 'gold' ) ) { return; }
        foreach ( $order->get_items() as $item ) {
            $product = $item->get_product();
            if ( $item->get_meta( '_kerp_gold_units' ) || $item->get_meta( '_kerp_plus_days' ) || ( $product && ! self::guard_gold_product( true, $product ) ) ) {
                wp_die( 'برای پرداخت این سفارش، ماژول بنکداری و کیف طلایی باید فعال باشد.', 'بنکداری طلا', [ 'response' => 400, 'back_link' => true ] );
            }
        }
    }

	public static function activate(): void {
		KERP_Install_Installer::activate();
		do_action( 'kerp_activated' );
	}
	
	public static function deactivate(): void {
		KERP_Install_Installer::deactivate();
		do_action( 'kerp_deactivated' );
	}
	
	public static function declare_woocommerce_compatibility(): void {
		if ( class_exists( '\\Automattic\\WooCommerce\\Utilities\\FeaturesUtil' ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
				'custom_order_tables',
				KERP_FILE,
				TRUE
			);
		}
	}
	
	private static function register_autoloader(): void {
		spl_autoload_register( [ self::class, 'autoload' ] );
	}
	
}
