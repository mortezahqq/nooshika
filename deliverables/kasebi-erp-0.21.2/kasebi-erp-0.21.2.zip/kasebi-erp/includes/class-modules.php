<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Modules {
	
	private const OPTION_KEY   = 'kerp_modules_statuses';
	
	private const DEPENDENCIES = [
		'woocommerce'    => [
			'label'  => 'WooCommerce',
			'plugin' => 'woocommerce/woocommerce.php',
		],
		'gravityforms'   => [
			'label'  => 'Gravity Forms',
			'plugin' => 'gravityforms/gravityforms.php',
		],
		'learndash'      => [
			'label'  => 'LearnDash LMS',
			'plugin' => 'sfwd-lms/sfwd_lms.php',
		],
		'nooshika-panel' => [
			'label'  => 'Kasebi User Panel',
			'plugin' => 'nooshika-panel/nooshika-panel.php',
		],
		'woo-wallet'     => [
			'label'  => 'TeraWallet',
			'plugin' => 'woo-wallet/woo-wallet.php',
		],
		'kasebi-wc'      => [
			'label'  => 'Kasebi WC Management',
			'plugin' => 'kasebi-wc-management/kasebi-wc-management.php',
		],
	];
	
	private static ?KERP_Modules $instance = NULL;
	
	private array $loaded_modules = [];
	
	public static function instance(): KERP_Modules {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize singleton.' );
	}
	
	public static function get_registered_modules(): array {
		$customer_settings       = KERP_Modules_Customers_Settings::instance();
		$customer_singular_label = $customer_settings->get_singular_label();
		$customer_plural_label   = $customer_settings->get_plural_label();
		
		$modules = [
            'gold' => self::module(
                'gold', 'بنکداری و کیف طلایی', 'کیف گرمی عیار ۷۵۰، انبار قطعات، پنل پلاس و صف خرید جایگزین دستی.',
                'KERP_Modules_Gold_Module', 'optional', 'dashicons-money-alt', FALSE, FALSE, [ 'woocommerce' ]
            ),
			'sms_logs' => self::module(
				'sms_logs', 'لاگ پیامک‌ها', 'سابقه ارسال پیامک‌های کاسبی، ورود، سفارش و ERP.',
				'KERP_Modules_Sms_Logs_Module', 'v1', 'ni ni-mail', TRUE, FALSE
			),
			'ajax'      => self::module(
				'ajax',
				'Ajax اختصاصی',
				'Endpoint سبک Ajax، مدیریت افزونه‌های مجاز و MU Loader اختصاصی ERP.',
				'KERP_Modules_Ajax_Module',
				'v1',
				'uik-r fa-route',
				TRUE,
				FALSE,
				[],
				[],
				''
			),
			/*
			 * مدیریت کاربران هدف
			 */
			'customers' => self::module(
				'customers',
				$customer_plural_label,
				sprintf( 'پروفایل، آدرس، دسته‌بندی، بازاریاب و اطلاعات پایه %s.', $customer_singular_label ),
				'KERP_Modules_Customers_Module',
				'v1',
				'uik-r fa-user',
				TRUE,
				FALSE,
				[],
				[],
				''
			),
			
			'activities' => self::module(
				'activities',
				'فعالیت‌ها',
				sprintf( 'یادداشت، تماس، جلسه و سابقه ارتباط با %s.', $customer_singular_label ),
				'KERP_Modules_Activities_Module',
				'v1',
				'uik-r fa-call-history',
				TRUE,
				FALSE,
				[],
				[],
				'customers'
			),
			
			'leads' => self::module(
				'leads',
				'مشتری بالقوه و کمپین',
				'مدیریت مشتری بالقوه مبتنی بر کاربر، کمپین و وبینار، مراحل خودکار و تایم‌لاین جذب.',
				'KERP_Modules_Leads_Module',
				'v1',
				'uik-r fa-filter',
				TRUE,
				FALSE,
				[],
				[ 'customers' ],
				'customers'
			),
			
			'followups' => self::module(
				'followups',
				'پیگیری‌ها',
				'سررسید، مسئول پیگیری، نتیجه و تاریخچه اقدامات.',
				'KERP_Modules_Followups_Module',
				'v1',
				'uik-r fa-clock',
				TRUE,
				FALSE,
				[],
				[ 'employees' ],
				'customers'
			),
			
			'requests'      => self::module(
				'requests',
				'درخواست‌ها',
				'درخواست‌های سازمانی، ارجاع و گردش وضعیت.',
				'KERP_Modules_Requests_Module',
				'v1',
				'uik-r fa-inbox',
				TRUE,
				FALSE,
				[],
				[ 'employees' ],
				'employees'
			),
			'addresses'     => self::module(
				'addresses',
				sprintf( 'آدرس‌های %s', $customer_singular_label ),
				sprintf( 'مدیریت چند آدرس برای %s و انتخاب آدرس تحویل سفارش.', $customer_singular_label ),
				'KERP_Modules_Addresses_Module',
				'v1',
				'uik fa-map-marker',
				TRUE,
				FALSE,
				[ 'woocommerce' ],
				[ 'customers' ],
				'customers'
			),
			//			'visits'    => self::module(
			//				'visits',
			//				'ویزیت‌ها',
			//				'ثبت ویزیت حضوری، شروع، پایان، مسئول و نتیجه.',
			//				'KERP_Modules_Visits_Module',
			//				'optional',
			//				'uik-r fa-location-alt',
			//				FALSE,
			//				FALSE,
			//				[],
			//				[ 'employees' ],
			//				'customers'
			//			),
			//
			'wallet'        => self::module(
				'wallet',
				'کیف پول',
				sprintf( 'نمایش موجودی و تراکنش‌های %s یا کارمند.', $customer_singular_label ),
				'KERP_Modules_Wallet_Module',
				'optional',
				'uik-r fa-credit-card',
				FALSE,
				FALSE,
				[ 'woocommerce', 'woo-wallet' ],
				[],
				'customers'
			),
			'referrals'     => self::module(
				'referrals', 'همکاری در فروش', 'کد معرفی عمومی و خصوصی، تخفیف و تسویه کمیسیون در کیف پول.',
				'KERP_Modules_Referrals_Module', 'optional', 'uik-r fa-network', FALSE, FALSE,
				[ 'woocommerce', 'woo-wallet' ], [ 'wallet', 'customers' ], 'customers'
			),
			'customer_club' => self::module(
				'customer_club',
				sprintf( 'باشگاه %s', $customer_plural_label ),
				sprintf( 'سکه، مأموریت‌ها، هدایا و پاداش‌های %s.', $customer_plural_label ),
				'KERP_Modules_Customer_Club_Module',
				'optional',
				'uik-r fa-crown',
				FALSE,
				FALSE,
				[ 'woocommerce' ],
				[ 'customers' ],
				'customers'
			),
			//
			//			'gravity_forms_leads' => self::module(
			//				'gravity_forms_leads',
			//				'مشتریان بالقوه Gravity Forms',
			//				sprintf( 'تبدیل Entry فرم‌ها به %1$s، درخواست یا نقطه شروع مسیر %1$s.', $customer_singular_label ),
			//				'KERP_Modules_Gravity_Forms_Leads_Module',
			//				'optional',
			//				'uik-r fa-form',
			//				FALSE,
			//				FALSE,
			//				[ 'gravityforms' ],
			//				[],
			//				'customers'
			//			),
			
			//			'rfm'          => self::module(
			//				'rfm',
			//				'تحلیل RFM',
			//				sprintf( 'تحلیل تازگی، تکرار و ارزش خرید %s.', $customer_singular_label ),
			//				'KERP_Modules_Rfm_Module',
			//				'future',
			//				'uik-r fa-chart-pie',
			//				FALSE,
			//				FALSE,
			//				[],
			//				[ 'sales_reports' ],
			//				'customers'
			//			),
			
			/*
			 * منابع انسانی
			 */
			'employees'     => self::module(
				'employees',
				'کارمندان',
				'پروفایل کارمند، نقش سازمانی، تیم و وضعیت همکاری.',
				'KERP_Modules_Employees_Module',
				'v1',
				'uik-r fa-id-badge',
				TRUE,
				FALSE,
				[],
				[],
				''
			),
			
			'hr_reports' => self::module(
				'hr_reports',
				'گزارشات سازمانی',
				'ثبت و بررسی گزارش‌های کارمندان و پیوست‌های مرتبط.',
				'KERP_Modules_Hr_Reports_Module',
				'v1',
				'uik-r fa-document-signed',
				TRUE,
				FALSE,
				[],
				[],
				'employees'
			),
			
			'employee_warnings' => self::module(
				'employee_warnings',
				'اخطار کارمندان',
				'الگوی اخطار، صدور و سوابق اخطارهای کارمندان.',
				'KERP_Modules_Employee_Warnings_Module',
				'optional',
				'uik-r fa-shield-exclamation',
				FALSE,
				FALSE,
				[],
				[],
				'employees'
			),
			
			/*
			 * فروش و سفارش‌ها
			 */
			'orders'            => self::module(
				'orders',
				'سفارش‌ها',
				'نمایش، ثبت و مدیریت سفارش‌های WooCommerce با سازگاری HPOS.',
				'KERP_Modules_Orders_Module',
				'v1',
				'uik-r fa-shopping-cart',
				TRUE,
				FALSE,
				[ 'woocommerce' ],
				[ 'customers' ],
				''
			),
			
			'sales_reports' => self::module(
				'sales_reports',
				'گزارش فروش',
				sprintf( 'گزارش سفارش، محصول، %s و عملکرد فروش بر پایه Order Index.', $customer_singular_label ),
				'KERP_Modules_Sales_Reports_Module',
				'v1',
				'uik-r fa-chart-histogram',
				TRUE,
				FALSE,
				[ 'woocommerce' ],
				[],
				'orders'
			),
			
			'payments'               => self::module( 'payments', 'مدیریت پرداخت‌ها',
				'پرداخت نقدی و اقساطی، رسیدهای آفلاین و تأیید مالی.', 'KERP_Modules_Payments_Module', 'optional', 'hik fa-wallet', FALSE, FALSE, [ 'woocommerce' ], [
					'orders',
					'customers',
				], 'orders' ),
			'installment_management' => self::module(
				'installment_management',
				'مدیریت پرداخت اقساطی',
				'پلن‌های فروش اقساطی، دسترسی مرحله‌ای لرن‌دش، تگ و پیامک هر قسط.',
				'KERP_Modules_Installment_Management_Module',
				'optional',
				'uik-r fa-receipt',
				FALSE,
				FALSE,
				[ 'woocommerce', 'learndash' ],
				[ 'customers', 'orders' ],
				'orders'
			),
			'marketing'              => self::module(
				'marketing', 'درخواست تبلیغات', 'ثبت درخواست تبلیغ و تحلیل عملکرد منابع هر کمپین.',
				'KERP_Modules_Marketing_Module', 'v1', 'uik fa-stats', FALSE, FALSE, [], [ 'employees' ]
			),
			'appointments'           => self::module(
				'appointments',
				'نوبت‌دهی',
				'مدیریت خدمات، برنامه کاری، رزرو آنلاین و نوبت‌های سازمان.',
				'KERP_Modules_Appointments_Module',
				'v1',
				'uik-r fa-calendar',
				FALSE,
				FALSE,
				[ 'woocommerce' ],
				[ 'employees' ],
				''
			),
			
			/*
			 * ماژول‌های مستقل
			 */
			
			'tickets' => self::module(
				'tickets',
				'تیکت‌ها',
				'پشتیبانی، گفت‌وگو، ارجاع و انتقال تیکت‌های قدیمی.',
				'KERP_Modules_Tickets_Module',
				'v1',
				'uik-r fa-ticket',
				FALSE,
				FALSE,
				[],
				[ 'customers', 'employees' ],
				''
			),
			
			'programs' => self::module(
				'programs',
				'برنامه‌ها و پایش عملکرد',
				'برنامه‌های روزانه و هفتگی آموزشی، تغذیه، ورزش یا درمان.',
				'KERP_Modules_Programs_Module',
				'v1',
				'uik-r fa-list-check',
				FALSE,
				FALSE,
				[],
				[ 'customers', 'employees' ],
				''
			),
			
			'online_attendance' => self::module(
				'online_attendance',
				'حضور و غیاب کلاس آنلاین',
				'اتصال به اسکای‌روم، ثبت حضور هنرجو و اعلان غیبت کلاس‌های LearnDash.',
				'KERP_Modules_Online_Attendance_Module',
				'v1',
				'uik fa-presentation',
				TRUE,
				FALSE,
				[ 'learndash', 'nooshika-panel' ],
				[],
				''
			),
			
			'learning_assignments' => self::module(
				'learning_assignments',
				'تمرین‌ها',
				'ساخت تمرین، دریافت پاسخ هنرجو، بررسی و تکمیل درس در LearnDash.',
				'KERP_Modules_Learning_Assignments_Module',
				'v1',
				'uik-r fa-graduation-cap',
				FALSE,
				FALSE,
				[ 'learndash' ],
				[],
				''
			),
			
			'gravity_forms_entries' => self::module(
				'gravity_forms_entries',
				'ورودی‌های فرم',
				'اتصال ورودی‌های Gravity Forms به کاربران و نمایش پاسخ‌ها در پروفایل ERP.',
				'KERP_Modules_Gravity_Forms_Entries_Module',
				'optional',
				'uik-r fa-form',
				FALSE,
				FALSE,
				[ 'gravityforms' ],
				[ 'customers' ],
				'customers'
			),
		];
		
		return (array) apply_filters( 'kerp_registered_modules', $modules );
	}
	
	private static function module(
		string $key,
		string $label,
		string $description,
		string $class,
		string $stage,
		string $icon,
		bool $default_enabled,
		bool $license_required,
		array $requires = [],
		array $requires_modules = [],
		string $parent = '',
	): array {
		return [
			'key'              => $key,
			'label'            => __( $label, 'kasebi-erp' ),
			'description'      => __( $description, 'kasebi-erp' ),
			'class'            => $class,
			'stage'            => $stage,
			'icon'             => $icon,
			'default_enabled'  => $default_enabled,
			'requires'         => $requires,
			'requires_modules' => $requires_modules,
			'parent'           => $parent,
			'license_required' => $license_required,
		];
	}
	
	public function load_enabled_modules(): void {
		$pending        = self::get_registered_modules();
		$loaded_in_pass = TRUE;
		
		while ( ! empty( $pending ) && $loaded_in_pass ) {
			$loaded_in_pass = FALSE;
			
			foreach ( $pending as $key => $module ) {
				if ( ! $this->can_load_module( $key, $module ) ) {
					continue;
				}
				
				$this->load_module( $key, $module );
				unset( $pending[ $key ] );
				
				$loaded_in_pass = TRUE;
			}
		}
		
		foreach ( $pending as $key => $module ) {
			do_action( 'kerp_module_not_loaded', $key, $module );
		}
	}
	
	/**
	 * Check module required internal modules.
	 */
	private function has_required_modules( array $module ): bool {
		$requires_modules = $module['requires_modules'] ?? [];
		
		if ( empty( $requires_modules ) ) {
			return TRUE;
		}
		
		foreach ( $requires_modules as $required_module ) {
			if ( ! $this->is_module_enabled( $required_module ) ) {
				return FALSE;
			}
			
			if ( ! $this->is_module_loaded( $required_module ) ) {
				return FALSE;
			}
		}
		
		return TRUE;
	}
	
	/**
	 * Check module can be loaded.
	 */
	public function can_load_module( string $key, array $module ): bool {
		if ( $key == 'ajax' ) {
			return TRUE;
		}
		if ( ! $this->is_module_enabled( $key ) ) {
			return FALSE;
		}
		
		if ( ! $this->is_parent_enabled( $module ) ) {
			return FALSE;
		}
		
		if ( ! $this->has_required_dependencies( $module ) ) {
			return FALSE;
		}
		
		if ( ! $this->has_required_modules( $module ) ) {
			return FALSE;
		}
		
		if ( ! $this->has_valid_license( $key, $module ) ) {
			return FALSE;
		}
		
		return TRUE;
	}
	
	/**
	 * Check parent module is enabled.
	 */
	private function is_parent_enabled( array $module ): bool {
		$parent = $module['parent'] ?? '';
		
		if ( $parent === '' ) {
			return TRUE;
		}
		
		return $this->is_module_enabled( $parent );
	}
	
	/**
	 * Check module required dependencies.
	 */
	private function has_required_dependencies( array $module ): bool {
		$requires = $module['requires'] ?? [];
		
		if ( empty( $requires ) ) {
			return TRUE;
		}
		
		foreach ( $requires as $dependency ) {
			if ( ! $this->is_dependency_active( $dependency ) ) {
				return FALSE;
			}
		}
		
		return TRUE;
	}
	
	/**
	 * Check dependency is active.
	 */
	public function is_dependency_active( string $dependency ): bool {
		$dependencies = self::DEPENDENCIES;
		
		if ( empty( $dependencies[ $dependency ]['plugin'] ) ) {
			return TRUE;
		}
		
		$plugin         = $dependencies[ $dependency ]['plugin'];
		$active_plugins = (array) get_option( 'active_plugins', [] );
		
		if ( in_array( $plugin, $active_plugins, TRUE ) ) {
			return TRUE;
		}
		
		$network_plugins = (array) get_site_option( 'active_sitewide_plugins', [] );
		
		return isset( $network_plugins[ $plugin ] );
	}
	
	/**
	 * Check module license.
	 */
	private function has_valid_license( string $key, array $module ): bool {
		if ( empty( $module['license_required'] ) ) {
			return TRUE;
		}
		
		return (bool) apply_filters( 'kerp_module_has_valid_license', TRUE, $key, $module );
	}
	
	private function load_module( string $key, array $module ): void {
		if ( $this->is_module_loaded( $key ) ) {
			return;
		}
		
		$class = (string) ( $module['class'] ?? '' );
		
		if ( $class === '' || ! class_exists( $class ) || ! is_callable( [ $class, 'instance' ] ) ) {
			throw new RuntimeException( sprintf( 'ERP module "%s" must expose a public static instance() method.', $key ) );
		}
		
		$class::instance();
		$this->loaded_modules[] = $key;
		
		do_action( 'kerp_module_loaded', $key, $module );
	}
	
	public function get_statuses(): array {
		$statuses = get_option( self::OPTION_KEY, [] );
		
		return is_array( $statuses ) ? $statuses : [];
	}
	
	public function save_statuses( array $statuses ): void {
		$clean = [];
		
		foreach ( self::get_registered_modules() as $key => $module ) {
			$clean[ $key ] = ! empty( $statuses[ $key ] ) && $this->is_module_available( $key ) ? 'yes' : 'no';
		}
		
		foreach ( self::get_registered_modules() as $key => $module ) {
			if ( ( $clean[ $key ] ?? 'no' ) !== 'yes' ) {
				continue;
			}
			
			foreach ( $module['requires'] ?? [] as $dependency ) {
				if ( ! $this->is_dependency_active( (string) $dependency ) ) {
					$clean[ $key ] = 'no';
					continue 2;
				}
			}
			
			foreach ( $module['requires_modules'] ?? [] as $required_module ) {
				if ( ( $clean[ $required_module ] ?? 'no' ) !== 'yes' ) {
					$clean[ $key ] = 'no';
					continue 2;
				}
			}
		}
		
		update_option( self::OPTION_KEY, $clean, FALSE );
		do_action( 'kerp_modules_statuses_saved', $clean );
	}
	
	public function is_module_enabled( string $key ): bool {
		$module   = $this->get_module( $key );
		$statuses = $this->get_statuses();
		
		if ( empty( $module ) ) {
			return FALSE;
		}
		
		if ( array_key_exists( $key, $statuses ) ) {
			return $statuses[ $key ] === 'yes';
		}
		
		return ! empty( $module['default_enabled'] ) && $this->is_module_available( $key );
	}
	
	public function is_module_available( string $key ): bool {
		$module = $this->get_module( $key );
		$class  = (string) ( $module['class'] ?? '' );
		
		return $class !== '' && class_exists( $class ) && is_callable( [ $class, 'instance' ] );
	}
	
	/**
	 * Get module by key.
	 */
	public function get_module( string $key ): array {
		$modules = self::get_registered_modules();
		
		return $modules[ $key ] ?? [];
	}
	
	public function get_loaded_modules(): array {
		return $this->loaded_modules;
	}
	
	public function is_module_loaded( string $key ): bool {
		return in_array( $key, $this->loaded_modules, TRUE );
	}
	
	/**
	 * Get parent modules.
	 */
	public function get_parent_modules(): array {
		$parents = [];
		
		foreach ( self::get_registered_modules() as $key => $module ) {
			if ( empty( $module['parent'] ) ) {
				$parents[ $key ] = $module;
			}
		}
		
		return $parents;
	}
	
	/**
	 * Get children of module.
	 */
	public function get_children( string $parent_key ): array {
		$children = [];
		
		foreach ( self::get_registered_modules() as $key => $module ) {
			if ( ( $module['parent'] ?? '' ) === $parent_key ) {
				$children[ $key ] = $module;
			}
		}
		
		return $children;
	}
	
	/**
	 * Check module has children.
	 */
	public function has_children( string $parent_key ): bool {
		return ! empty( $this->get_children( $parent_key ) );
	}
	
	/**
	 * Get dependency data.
	 */
	public static function get_dependency( string $dependency ): array {
		return self::DEPENDENCIES[ $dependency ] ?? [
				'label'  => $dependency,
				'plugin' => '',
			];
	}
	
	/**
	 * Get module missing dependencies.
	 */
	public function get_missing_dependencies( array $module ): array {
		$missing = [];
		
		$requires = $module['requires'] ?? [];
		
		foreach ( $requires as $dependency ) {
			if ( ! $this->is_dependency_active( $dependency ) ) {
				$data = self::get_dependency( $dependency );
				
				$missing[ 'plugin:' . $dependency ] = [
					'type'   => 'plugin',
					'key'    => $dependency,
					'label'  => $data['label'] ?? $dependency,
					'plugin' => $data['plugin'] ?? '',
				];
			}
		}
		
		$requires_modules = $module['requires_modules'] ?? [];
		
		foreach ( $requires_modules as $required_module ) {
			if ( ! $this->is_module_enabled( $required_module ) ) {
				$module_data = $this->get_module( $required_module );
				
				$missing[ 'module:' . $required_module ] = [
					'type'  => 'module',
					'key'   => $required_module,
					'label' => $module_data['label'] ?? $required_module,
				];
			}
		}
		
		return $missing;
	}
	
}
