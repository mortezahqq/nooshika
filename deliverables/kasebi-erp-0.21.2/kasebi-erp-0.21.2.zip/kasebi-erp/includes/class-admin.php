<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Admin {

	public const CAPABILITY = 'kerp_manage_erp';

	private static ?KERP_Admin $instance = NULL;

	public static function instance(): KERP_Admin {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	private function __construct() {
		$this->load_components();
	}

	private function __clone() {}

	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize singleton.' );
	}

	private function load_components(): void {
		KERP_Admin_Menu::instance();
		KERP_Admin_Assets::instance();
		KERP_Admin_Modules_Page::instance();

		do_action( 'kerp_admin_loaded', $this );
	}

	public static function can_manage(): bool {
		return current_user_can( self::CAPABILITY ) || current_user_can( 'manage_options' );
	}
}
