<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Public_Assets {
	
	public const STYLE_HANDLE  = 'kerp-app';
	
	public const SCRIPT_HANDLE = 'kerp-app';
	
	private static ?KERP_Public_Assets $instance = NULL;
	
	public static function instance(): KERP_Public_Assets {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {
		add_action( 'wp_enqueue_scripts', [ $this, 'dequeue_unrelated_assets' ], PHP_INT_MAX );
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue' ], PHP_INT_MAX );
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_numeric_inputs' ], PHP_INT_MAX );
	}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize singleton.' );
	}
	
	public function enqueue_numeric_inputs(): void {
		if ( is_page( 'panel' ) || kerp_is_erp_request() ) {
			wp_enqueue_script( 'kerp-numeric-inputs', KERP_ASSETS_URL . 'shared/js/numeric-inputs.js', [], kerp_asset_version( 'shared/js/numeric-inputs.js' ), TRUE );
		}
	}

	public function enqueue(): void {
		if ( ! kerp_is_erp_request() ) {
			return;
		}
		$skin          = sanitize_key( (string) get_user_meta( get_current_user_id(), 'kerp_skin', TRUE ) );
		$allowed_skins = [
			'default',
			'blue',
			'egyptian',
			'green',
			'purple',
			'red',
		];
		
		if ( ! in_array( $skin, $allowed_skins, TRUE ) ) {
			$skin = 'default';
		}
		
		wp_enqueue_style( 'nooshika_fonts_css' );
		wp_enqueue_style( 'kerp-dashlite', KERP_ASSETS_URL . 'app/css/dashlite.rtl.css', [ 'nooshika_fonts_css' ], kerp_asset_version( 'app/css/dashlite.rtl.css' ) );
		wp_enqueue_style( 'kerp-quill', KERP_ASSETS_URL . 'app/css/vendors/quill.rtl.css', [ 'kerp-dashlite' ], kerp_asset_version( 'app/css/vendors/quill.rtl.css' ) );
		wp_enqueue_style( 'kerp-cropper', KERP_ASSETS_URL . 'app/css/vendors/cropper.css', [ 'kerp-dashlite' ], kerp_asset_version( 'app/css/vendors/cropper.css' ) );
		wp_enqueue_style( 'kerp-datepicker', KERP_ASSETS_URL . 'app/css/vendors/persianDatepicker-default.css', [ 'kerp-dashlite' ], kerp_asset_version( 'app/css/vendors/persianDatepicker-default.css' ) );
		wp_enqueue_style(
			self::STYLE_HANDLE,
			KERP_ASSETS_URL . 'app/css/app.css',
			[
				'kerp-dashlite',
				'kerp-quill',
				'kerp-cropper',
				'kerp-datepicker',
			],
			kerp_asset_version( 'app/css/app.css' )
		);
		if ( 'default' !== $skin ) {
			$skin_path = 'app/css/skins/theme-' . $skin . '.css';
			wp_enqueue_style(
				'kerp-skin',
				KERP_ASSETS_URL . $skin_path,
				[ 'kerp-app' ],
				kerp_asset_version( $skin_path )
			);
		}
		
		// Restore the main plugin's site stylesheet after ERP clears frontend assets.
		if ( wp_style_is( 'nooshika_custom_styles', 'registered' ) ) {
			wp_enqueue_style( 'nooshika_custom_styles' );
		}

		wp_enqueue_script(
			'kerp-bundle',
			KERP_ASSETS_URL . 'app/js/vendors/bundle.js',
			[],
			kerp_asset_version( 'app/js/vendors/bundle.js' ),
			FALSE
		);
		
		wp_enqueue_script(
			'kerp-cropper',
			KERP_ASSETS_URL . 'app/js/vendors/cropper.js',
			[ 'kerp-bundle' ],
			kerp_asset_version( 'app/js/vendors/cropper.js' ),
			TRUE
		);
		
		wp_enqueue_script(
			'kerp-quill',
			KERP_ASSETS_URL . 'app/js/vendors/quill.js',
			[ 'kerp-bundle' ],
			kerp_asset_version( 'app/js/vendors/quill.js' ),
			TRUE
		);
		
		wp_enqueue_script(
			'kerp-datepicker',
			KERP_ASSETS_URL . 'app/js/vendors/persianDatepicker.min.js',
			[ 'kerp-bundle' ],
			kerp_asset_version( 'app/js/vendors/persianDatepicker.min.js' ),
			TRUE
		);
		
		wp_enqueue_script(
			'kerp-dragula',
			KERP_ASSETS_URL . 'app/js/vendors/dragula.min.js',
			[ 'kerp-bundle' ],
			kerp_asset_version( 'app/js/vendors/dragula.min.js' ),
			TRUE
		);
		
		wp_enqueue_script(
			'kerp-xlsx',
			KERP_ASSETS_URL . 'app/js/vendors/xlsx.full.min.js',
			[ 'kerp-bundle' ],
			kerp_asset_version( 'app/js/vendors/xlsx.full.min.js' ),
			TRUE
		);
		
		wp_enqueue_script(
			self::SCRIPT_HANDLE,
			KERP_ASSETS_URL . 'app/js/app.js',
			[
				'kerp-bundle',
				'kerp-cropper',
				'kerp-quill',
				'kerp-datepicker',
				'kerp-dragula',
				'kerp-xlsx',
			],
			kerp_asset_version( 'app/js/app.js' ),
			TRUE
		);
		wp_localize_script( self::SCRIPT_HANDLE, 'KERPData', KERP_App::instance()->get_boot_data() );
		wp_localize_script( self::SCRIPT_HANDLE, 'KERPPriceData', [
			'template' => KERP_Helpers_Template::price( 1 ),
			'zero_template' => KERP_Helpers_Template::price( 0 ),
			'currency' => get_woocommerce_currency_symbol(),
		] );
	}
	
	public function dequeue_unrelated_assets(): void {
		if ( ! kerp_is_erp_request() ) {
			return;
		}
		
		global $wp_styles, $wp_scripts;
		
		if ( $wp_styles instanceof WP_Styles ) {
			foreach ( (array) $wp_styles->queue as $handle ) {
				wp_dequeue_style( $handle );
			}
		}
		
		if ( $wp_scripts instanceof WP_Scripts ) {
			foreach ( (array) $wp_scripts->queue as $handle ) {
				wp_dequeue_script( $handle );
			}
		}
		remove_action( 'wp_footer', 'add_kasebi_footer_options' );
		remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
		remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
		remove_action( 'wp_print_styles', 'print_emoji_styles' );
		remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
		remove_action( 'admin_print_styles', 'print_emoji_styles' );
		remove_filter( 'comment_text_rss', 'wp_staticize_emoji' );
		remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );
		add_filter( 'tiny_mce_plugins', 'disable_emojis_tinymce' );
	}
	
}
