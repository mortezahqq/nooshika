<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Services_Auth_Guard {

	private static ?KERP_Services_Auth_Guard $instance = NULL;

	public static function instance(): KERP_Services_Auth_Guard {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	private function __construct() {
		add_action( 'template_redirect', [ $this, 'protect_erp' ], 1 );
	}

	private function __clone() {}

	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize singleton.' );
	}

	public function protect_erp(): void {
		if ( ! kerp_is_erp_request() || is_user_logged_in() ) {
			return;
		}

		$redirect_to = KERP_Core_Router::instance()->get_current_url();
		wp_safe_redirect( kerp_get_login_url( $redirect_to ) );
		exit;
	}
}
