<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Services_Session {

	private const KEY = 'kasebi_erp';

	/** Request-local permissions after releasing the session lock for dashboard reads. */
	private static ?array $read_context = NULL;

	public static function release_for_reading(): void {
		self::$read_context = self::get_context();
		if ( session_status() === PHP_SESSION_ACTIVE ) {
			session_write_close();
		}
	}

	private static ?KERP_Services_Session $instance = NULL;

	public static function instance(): KERP_Services_Session {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	private function __construct() {
		add_action( 'wp_logout', [ $this, 'clear' ] );
	}

	private function __clone() {}

	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize singleton.' );
	}

	public function start(): void {
		self::ensure_started();
	}

	private static function ensure_started(): bool {
		if ( session_status() === PHP_SESSION_ACTIVE ) {
			return TRUE;
		}

		if ( headers_sent() ) {
			return FALSE;
		}

		session_start();

		return session_status() === PHP_SESSION_ACTIVE;
	}

	public static function set_context( array $data ): void {
		self::$read_context = NULL;
		if ( ! self::ensure_started() ) {
			return;
		}

		$_SESSION[ self::KEY ] = array_merge( self::get_context(), $data );
	}

	public static function get_context(): array {
		if ( self::$read_context !== NULL ) {
			return self::$read_context;
		}
		if ( ! self::ensure_started() ) {
			return [];
		}

		$context = $_SESSION[ self::KEY ] ?? [];

		return is_array( $context ) ? $context : [];
	}

	public function clear(): void {
		self::$read_context = NULL;
		if ( self::ensure_started() ) {
			unset( $_SESSION[ self::KEY ] );
		}
	}

	public static function set_user( int $user_id ): void {
		$current_user_id = (int) ( self::get_context()['user_id'] ?? 0 );

		if ( $current_user_id !== 0 && $current_user_id !== $user_id ) {
			self::instance()->clear();
		}

		self::set_context( [ 'user_id' => $user_id ] );
	}

	public static function set_role( ?string $role ): void {
		self::set_context( [ 'role' => $role ] );
	}

	public static function get_role(): ?string {
		$role = self::get_context()['role'] ?? NULL;

		return is_string( $role ) && $role !== '' ? $role : NULL;
	}

	public static function set_permissions( array $views, array $actions ): void {
		self::set_context(
			[
				'permissions' => [
					'view'   => array_values( array_unique( $views ) ),
					'action' => array_values( array_unique( $actions ) ),
				],
			]
		);
	}

	public static function get_permissions(): array {
		$permissions = self::get_context()['permissions'] ?? [];

		return [
			'view'   => is_array( $permissions['view'] ?? NULL ) ? $permissions['view'] : [],
			'action' => is_array( $permissions['action'] ?? NULL ) ? $permissions['action'] : [],
		];
	}

	public static function set_permissions_meta( int $version ): void {
		self::set_context(
			[
				'meta' => [
					'version'   => $version,
					'loaded_at' => time(),
				],
			]
		);
	}

	public static function get_permissions_meta(): array {
		$meta = self::get_context()['meta'] ?? [];

		return [
			'version'   => (int) ( $meta['version'] ?? 0 ),
			'loaded_at' => (int) ( $meta['loaded_at'] ?? 0 ),
		];
	}

	public static function reset_permissions(): void {
		self::set_role( NULL );
		self::set_permissions( [], [] );
		self::set_permissions_meta( 0 );
	}
}
