<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Services_Attribution_First_Touch {
	public const LEGACY_META_KEY = 'kerp_first_touch';
	private const BROWSER_COOKIE = 'kerp_first_touch_v1';
	private const COOKIE_TTL     = 15552000;
	private const SCHEMA_VERSION = '1.0.0';
	private const SCHEMA_OPTION  = 'kerp_first_touch_db_version';
	private static ?self $instance = NULL;

	public static function instance(): self { return self::$instance ??= new self(); }

	private function __construct() {
		$this->maybe_install();
		add_action( 'template_redirect', [ $this, 'capture_browser_first_touch' ], 1 );
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_browser_capture' ], 1 );
		add_action( 'user_register', [ $this, 'capture_known_registration' ], 5 );
		add_action( 'woocommerce_checkout_order_created', [ $this, 'attach_landing_order' ], 8 );
		add_action( 'kerp_customer_profile_after_fields', [ $this, 'render_customer_profile' ], 20, 2 );
	}

	public static function table(): string { global $wpdb; return $wpdb->prefix . 'kerp_first_touches'; }
	public static function items_table(): string { global $wpdb; return $wpdb->prefix . 'kerp_first_touch_items'; }

	public function enqueue_browser_capture(): void {
		if ( is_user_logged_in() ) { return; }
		wp_enqueue_script( 'kerp-first-touch-capture', KERP_ASSETS_URL . 'public/js/first-touch-capture.js', [], kerp_asset_version( 'public/js/first-touch-capture.js' ), FALSE );
	}

	public function capture_browser_first_touch(): void {
		if ( is_user_logged_in() || $this->read_browser_context() !== [] || headers_sent() ) { return; }
		$request_uri = isset( $_SERVER['REQUEST_URI'] ) && is_scalar( $_SERVER['REQUEST_URI'] ) ? wp_unslash( (string) $_SERVER['REQUEST_URI'] ) : '/';
		$landing_url = esc_url_raw( home_url( '/' . ltrim( $request_uri, '/' ) ) );
		$referrer    = isset( $_SERVER['HTTP_REFERER'] ) && is_scalar( $_SERVER['HTTP_REFERER'] ) ? esc_url_raw( wp_unslash( (string) $_SERVER['HTTP_REFERER'] ) ) : '';
		$context     = $this->sanitize_context( [
			'source_type' => $this->detect_source_type( $_GET, $referrer ),
			'utm_source' => $this->query_value( 'utm_source' ), 'utm_medium' => $this->query_value( 'utm_medium' ), 'utm_campaign' => $this->query_value( 'utm_campaign' ),
			'utm_content' => $this->query_value( 'utm_content' ), 'utm_term' => $this->query_value( 'utm_term' ), 'landing_page' => $landing_url, 'referrer' => $referrer,
		] );
		if ( $context === [] ) { return; }
		$value = wp_json_encode( $context, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
		if ( ! is_string( $value ) || strlen( $value ) > 3800 ) { return; }
		setcookie( self::BROWSER_COOKIE, $value, [ 'expires' => time() + self::COOKIE_TTL, 'path' => '/', 'secure' => is_ssl(), 'httponly' => FALSE, 'samesite' => 'Lax' ] );
		$_COOKIE[ self::BROWSER_COOKIE ] = $value;
	}

	public static function install(): void {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$touches = self::table();
		$items   = self::items_table();
		$collate = $wpdb->get_charset_collate();
		dbDelta( "CREATE TABLE {$touches} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			user_id bigint(20) unsigned NOT NULL,
			touch_type varchar(40) NOT NULL,
			source_type varchar(40) NOT NULL DEFAULT '',
			registered_at datetime NOT NULL,
			landing_url text NULL,
			referrer_url text NULL,
			redirect_url text NULL,
			redirect_post_id bigint(20) unsigned NULL,
			redirect_post_type varchar(40) NOT NULL DEFAULT '',
			form_id bigint(20) unsigned NULL,
			entry_id bigint(20) unsigned NULL,
			order_id bigint(20) unsigned NULL,
			utm_source varchar(191) NOT NULL DEFAULT '',
			utm_medium varchar(191) NOT NULL DEFAULT '',
			utm_campaign varchar(191) NOT NULL DEFAULT '',
			utm_content varchar(191) NOT NULL DEFAULT '',
			utm_term varchar(191) NOT NULL DEFAULT '',
			context_json longtext NULL,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY user_id (user_id),
			KEY registered_at (registered_at),
			KEY touch_type_registered (touch_type,registered_at),
			KEY source_type (source_type),
			KEY form_id (form_id),
			KEY order_id (order_id),
			KEY redirect_post_id (redirect_post_id),
			KEY utm_source (utm_source),
			KEY utm_campaign (utm_campaign)
		) {$collate};" );
		dbDelta( "CREATE TABLE {$items} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			first_touch_id bigint(20) unsigned NOT NULL,
			item_kind varchar(20) NOT NULL,
			product_id bigint(20) unsigned NOT NULL,
			variation_id bigint(20) unsigned NULL,
			quantity decimal(18,4) unsigned NOT NULL DEFAULT 1,
			product_name varchar(255) NOT NULL DEFAULT '',
			PRIMARY KEY  (id),
			KEY first_touch_id (first_touch_id),
			KEY product_id (product_id),
			KEY variation_id (variation_id),
			KEY kind_product (item_kind,product_id)
		) {$collate};" );
		update_option( self::SCHEMA_OPTION, self::SCHEMA_VERSION, FALSE );
	}

	public function record( int $user_id, string $type, array $context = [] ): bool {
		if ( $user_id <= 0 || $this->has_touch( $user_id ) || get_user_meta( $user_id, self::LEGACY_META_KEY, TRUE ) !== '' ) { return FALSE; }
		return $this->insert_record( $user_id, $type, array_merge( $this->read_marketing_context(), $context ) );
	}

	public function get( int $user_id ): array {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE user_id = %d LIMIT 1', $user_id ), ARRAY_A );
		if ( ! is_array( $row ) ) {
			$legacy = get_user_meta( $user_id, self::LEGACY_META_KEY, TRUE );
			return is_array( $legacy ) ? $legacy : [];
		}
		$data = json_decode( (string) ( $row['context_json'] ?? '' ), TRUE );
		$data = is_array( $data ) ? $data : [];
		$data = array_merge( $data, [
			'id' => absint( $row['id'] ), 'type' => (string) $row['touch_type'], 'source_type' => (string) $row['source_type'], 'registered_at' => (string) $row['registered_at'],
			'landing_page' => (string) $row['landing_url'], 'referrer' => (string) $row['referrer_url'], 'redirect_to' => (string) $row['redirect_url'],
			'redirect_post_id' => absint( $row['redirect_post_id'] ), 'redirect_post_type' => (string) $row['redirect_post_type'],
			'form_id' => absint( $row['form_id'] ), 'entry_id' => absint( $row['entry_id'] ), 'order_id' => absint( $row['order_id'] ),
			'utm_source' => (string) $row['utm_source'], 'utm_medium' => (string) $row['utm_medium'], 'utm_campaign' => (string) $row['utm_campaign'],
			'utm_content' => (string) $row['utm_content'], 'utm_term' => (string) $row['utm_term'],
		] );
		$data['products'] = $data['cart_items'] = [];
		$items = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . self::items_table() . ' WHERE first_touch_id = %d ORDER BY id ASC', $row['id'] ), ARRAY_A );
		foreach ( (array) $items as $item ) {
			$value = [ 'product_id' => absint( $item['product_id'] ), 'variation_id' => absint( $item['variation_id'] ), 'name' => (string) $item['product_name'], 'quantity' => (float) $item['quantity'] ];
			$data[ ( $item['item_kind'] ?? '' ) === 'cart' ? 'cart_items' : 'products' ][] = $value;
		}
		return array_filter( $data, static fn( mixed $value ): bool => $value !== '' && $value !== 0 && $value !== [] && $value !== NULL );
	}

	public function get_legacy_list_data(): array {
		static $data = NULL;
		if ( $data !== NULL ) { return $data; }
		global $wpdb;
		$table = self::table();
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT user_id, meta_value FROM {$wpdb->usermeta} m WHERE meta_key = %s AND NOT EXISTS (SELECT 1 FROM {$table} ft WHERE ft.user_id = m.user_id)", self::LEGACY_META_KEY ), ARRAY_A );
		$data = [];
		foreach ( (array) $rows as $row ) {
			$value = maybe_unserialize( $row['meta_value'] );
			if ( is_array( $value ) ) { $data[ (int) $row['user_id'] ] = $value; }
		}
		return $data;
	}

	public function get_list_data( array $user_ids ): array {
		global $wpdb;
		$user_ids = array_values( array_unique( array_filter( array_map( 'absint', $user_ids ) ) ) );
		if ( ! $user_ids ) { return []; }
		$placeholders = implode( ',', array_fill( 0, count( $user_ids ), '%d' ) );
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . self::table() . " WHERE user_id IN ({$placeholders})", ...$user_ids ), ARRAY_A );
		$data = [];
		foreach ( (array) $rows as $row ) {
			$context = json_decode( (string) ( $row['context_json'] ?? '' ), TRUE );
			$data[ (int) $row['user_id'] ] = array_merge( is_array( $context ) ? $context : [], $row );
		}
		// Canonical records need no legacy user-meta hydration.
        $legacy_ids = array_values( array_diff( $user_ids, array_keys( $data ) ) );
        if ( $legacy_ids ) { update_meta_cache( 'user', $legacy_ids ); }
		foreach ( $user_ids as $user_id ) {
			if ( isset( $data[ $user_id ] ) ) { continue; }
			$legacy = get_user_meta( $user_id, self::LEGACY_META_KEY, TRUE );
			if ( ! is_array( $legacy ) ) { $data[ $user_id ] = []; continue; }
			$data[ $user_id ] = array_merge( $legacy, [
				'touch_type' => $legacy['type'] ?? '', 'landing_url' => $legacy['landing_page'] ?? '',
				'referrer_url' => $legacy['referrer'] ?? '', 'redirect_url' => $legacy['redirect_to'] ?? '',
			] );
		}
		return $data;
	}

	public function capture_known_registration( int $user_id ): void {
		$action = sanitize_key( (string) ( $_REQUEST['action'] ?? '' ) );
		if ( in_array( $action, [ 'submit_landing_order', 'verify_landing_form_otp' ], TRUE ) ) {
			$this->record( $user_id, 'landing_order', $this->landing_context( $action ) ); return;
		}
		if ( in_array( $action, [ 'verify_login_otp', 'register_user_pass' ], TRUE ) ) {
			$this->record( $user_id, 'site_registration', array_merge( $this->requested_redirect_context(), [ 'cart_items' => $this->cart_snapshot() ] ) );
		}
	}

	public function attach_landing_order( $order ): void {
		global $wpdb;
		if ( ! $order instanceof WC_Order ) { return; }
		$action = sanitize_key( (string) ( $_REQUEST['action'] ?? '' ) );
		if ( ! in_array( $action, [ 'submit_landing_order', 'verify_landing_form_otp' ], TRUE ) ) { return; }
		$wpdb->query( $wpdb->prepare( 'UPDATE ' . self::table() . ' SET order_id=%d,updated_at=%s WHERE user_id=%d AND touch_type=%s AND order_id IS NULL', $order->get_id(), current_time( 'mysql', TRUE ), $order->get_customer_id(), 'landing_order' ) );
	}

	public function migration_status(): array {
		global $wpdb;
		$total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(DISTINCT user_id) FROM {$wpdb->usermeta} WHERE meta_key=%s", self::LEGACY_META_KEY ) );
		$migrated = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(DISTINCT t.user_id) FROM ' . self::table() . ' t INNER JOIN ' . $wpdb->usermeta . ' m ON m.user_id=t.user_id AND m.meta_key=%s', self::LEGACY_META_KEY ) );
		return [ 'total' => $total, 'migrated' => min( $total, $migrated ), 'remaining' => max( 0, $total - $migrated ) ];
	}

	public function migrate_legacy_batch( int $limit = 100 ): array {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT m.user_id,m.meta_value FROM ' . $wpdb->usermeta . ' m LEFT JOIN ' . self::table() . ' t ON t.user_id=m.user_id WHERE m.meta_key=%s AND t.id IS NULL ORDER BY m.umeta_id ASC LIMIT %d', self::LEGACY_META_KEY, max( 1, min( 500, $limit ) ) ), ARRAY_A );
		$copied = 0;
		foreach ( (array) $rows as $row ) {
			$data = maybe_unserialize( $row['meta_value'] ?? '' );
			if ( is_array( $data ) && ! empty( $data['type'] ) && $this->insert_record( absint( $row['user_id'] ), (string) $data['type'], $data, (string) ( $data['registered_at'] ?? '' ) ) ) { $copied ++; }
		}
		return array_merge( [ 'copied' => $copied ], $this->migration_status() );
	}

	public function render_customer_profile( int $customer_id, WP_User $customer ): void {
		$data = $this->get( $customer_id );
		if ( ! empty( $data ) && class_exists( 'KERP_Helpers_Template' ) ) { KERP_Helpers_Template::render_template( 'modules/customers/partials/first-touch.php', compact( 'customer_id', 'customer', 'data' ) ); }
	}

	private function maybe_install(): void { if ( (string) get_option( self::SCHEMA_OPTION, '' ) !== self::SCHEMA_VERSION ) { self::install(); } }
	private function has_touch( int $user_id ): bool { global $wpdb; return (bool) $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . self::table() . ' WHERE user_id=%d LIMIT 1', $user_id ) ); }

	private function insert_record( int $user_id, string $type, array $context, string $registered_at = '' ): bool {
		global $wpdb;
		$type = sanitize_key( $type );
		if ( $user_id <= 0 || ! in_array( $type, [ 'landing_order', 'gravity_form', 'site_registration' ], TRUE ) ) { return FALSE; }
		$data = $this->sanitize_context( $context );
		$registered_at = $this->valid_mysql_date( $registered_at ) ?: current_time( 'mysql', TRUE );
		$now = current_time( 'mysql', TRUE );
		$row = [
			'user_id' => $user_id, 'touch_type' => $type, 'source_type' => $data['source_type'] ?? '', 'registered_at' => $registered_at,
			'landing_url' => $data['landing_page'] ?? '', 'referrer_url' => $data['referrer'] ?? '', 'redirect_url' => $data['redirect_to'] ?? '',
			'redirect_post_id' => absint( $data['redirect_post_id'] ?? 0 ) ?: NULL, 'redirect_post_type' => $data['redirect_post_type'] ?? '',
			'form_id' => absint( $data['form_id'] ?? 0 ) ?: NULL, 'entry_id' => absint( $data['entry_id'] ?? 0 ) ?: NULL, 'order_id' => absint( $data['order_id'] ?? 0 ) ?: NULL,
			'utm_source' => $data['utm_source'] ?? '', 'utm_medium' => $data['utm_medium'] ?? '', 'utm_campaign' => $data['utm_campaign'] ?? '',
			'utm_content' => $data['utm_content'] ?? '', 'utm_term' => $data['utm_term'] ?? '',
			'context_json' => wp_json_encode( array_merge( $data, [ 'type' => $type, 'registered_at' => $registered_at ] ), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ),
			'created_at' => $now, 'updated_at' => $now,
		];
		$wpdb->query( 'START TRANSACTION' );
		if ( $wpdb->insert( self::table(), $row ) === FALSE ) { $wpdb->query( 'ROLLBACK' ); return FALSE; }
		$touch_id = absint( $wpdb->insert_id );
		foreach ( [ 'products' => 'landing', 'cart_items' => 'cart' ] as $key => $kind ) {
			foreach ( (array) ( $data[ $key ] ?? [] ) as $item ) {
				if ( $wpdb->insert( self::items_table(), [ 'first_touch_id' => $touch_id, 'item_kind' => $kind, 'product_id' => absint( $item['product_id'] ?? 0 ), 'variation_id' => absint( $item['variation_id'] ?? 0 ) ?: NULL, 'quantity' => max( 0.0001, (float) ( $item['quantity'] ?? 1 ) ), 'product_name' => (string) ( $item['name'] ?? '' ) ] ) === FALSE ) { $wpdb->query( 'ROLLBACK' ); return FALSE; }
			}
		}
		$wpdb->query( 'COMMIT' );
		$this->clear_browser_cookie();
		do_action( 'kerp_first_touch_recorded', $user_id, array_merge( $data, [ 'id' => $touch_id, 'type' => $type, 'registered_at' => $registered_at ] ) );
		return TRUE;
	}

	private function valid_mysql_date( string $value ): string {
		$value = trim( $value ); $date = DateTimeImmutable::createFromFormat( 'Y-m-d H:i:s', $value, new DateTimeZone( 'UTC' ) );
		return $date && $date->format( 'Y-m-d H:i:s' ) === $value ? $value : '';
	}

	private function landing_context( string $action ): array {
		$product_ids = $this->parse_product_ids( $_POST['product_id'] ?? '' );
		if ( $action === 'verify_landing_form_otp' && empty( $product_ids ) ) {
			$phone = $this->normalize_phone( (string) ( $_POST['phone'] ?? '' ) ); $order = $phone !== '' ? get_transient( 'kasebi_order_' . $phone ) : FALSE;
			if ( is_array( $order ) ) { $product_ids = $this->parse_product_ids( $order['product_id'] ?? '' ); }
		}
		return [ 'product_ids' => $product_ids, 'products' => $this->products_from_ids( $product_ids ) ];
	}

	private function requested_redirect(): string {
		$value = $_POST['redirect_to'] ?? $_GET['redirect_to'] ?? $_GET['redirect'] ?? '';
		if ( ! is_scalar( $value ) || ( $value = wp_sanitize_redirect( wp_unslash( (string) $value ) ) ) === '' ) { return ''; }
		if ( ! preg_match( '#^https?://#i', $value ) ) { $value = home_url( '/' . ltrim( $value, '/' ) ); }
		$url = wp_validate_redirect( $value, home_url( '/panel/' ) ); $home = wp_parse_url( home_url( '/' ) ); $parts = wp_parse_url( $url );
		if ( ! is_array( $parts ) || ( $parts['host'] ?? '' ) !== ( $home['host'] ?? '' ) ) { return ''; }
		return ( $parts['path'] ?? '/' ) . ( isset( $parts['query'] ) ? '?' . $parts['query'] : '' );
	}

	private function requested_redirect_context(): array {
		$redirect = $this->requested_redirect(); if ( $redirect === '' ) { return []; } $context = [ 'redirect_to' => $redirect ];
		$post_id = function_exists( 'url_to_postid' ) ? absint( url_to_postid( home_url( $redirect ) ) ) : 0;
		if ( $post_id > 0 ) { $context['redirect_post_id'] = $post_id; $context['redirect_post_title'] = get_the_title( $post_id ); $context['redirect_post_type'] = get_post_type( $post_id ); }
		return $context;
	}

	private function cart_snapshot(): array {
		if ( ! function_exists( 'WC' ) || ! WC()->cart ) { return []; } $items = [];
		foreach ( WC()->cart->get_cart() as $cart_item ) { $product = $cart_item['data'] ?? NULL; if ( $product instanceof WC_Product ) { $items[] = [ 'product_id' => absint( $cart_item['product_id'] ?? $product->get_id() ), 'variation_id' => absint( $cart_item['variation_id'] ?? 0 ), 'name' => $product->get_name(), 'quantity' => max( 1, absint( $cart_item['quantity'] ?? 1 ) ) ]; } }
		return $items;
	}

	private function products_from_ids( array $product_ids ): array {
		$products = []; foreach ( $product_ids as $product_id ) { $product = function_exists( 'wc_get_product' ) ? wc_get_product( $product_id ) : NULL; $products[] = [ 'product_id' => $product_id, 'name' => $product instanceof WC_Product ? $product->get_name() : '', 'quantity' => 1 ]; } return $products;
	}

	private function parse_product_ids( mixed $value ): array { $values = is_array( $value ) ? $value : preg_split( '/\s*,\s*/', (string) $value ); return array_values( array_unique( array_filter( array_map( 'absint', (array) $values ) ) ) ); }

	private function sanitize_context( array $context ): array {
		$result = [];
		foreach ( $context as $key => $value ) {
			$key = sanitize_key( (string) $key ); if ( $key === '' || $value === '' || $value === [] || $value === NULL ) { continue; }
			if ( in_array( $key, [ 'form_id', 'entry_id', 'order_id', 'redirect_post_id' ], TRUE ) ) { $result[ $key ] = absint( $value ); }
			elseif ( $key === 'product_ids' ) { $result[ $key ] = $this->parse_product_ids( $value ); }
			elseif ( in_array( $key, [ 'products', 'cart_items' ], TRUE ) && is_array( $value ) ) { $result[ $key ] = array_map( static fn( array $item ): array => [ 'product_id' => absint( $item['product_id'] ?? 0 ), 'variation_id' => absint( $item['variation_id'] ?? 0 ), 'name' => mb_substr( sanitize_text_field( (string) ( $item['name'] ?? '' ) ), 0, 255 ), 'quantity' => max( 0.0001, (float) ( $item['quantity'] ?? 1 ) ) ], $value ); }
			elseif ( in_array( $key, [ 'landing_page', 'referrer' ], TRUE ) ) { $result[ $key ] = esc_url_raw( (string) $value ); }
			else { $result[ $key ] = mb_substr( sanitize_text_field( (string) $value ), 0, 500 ); }
		}
		return $result;
	}

	private function read_marketing_context(): array {
		$source = $this->parse_sourcebuster_cookie( 'sbjs_first' ); $extra = $this->parse_sourcebuster_cookie( 'sbjs_first_add' );
		$sourcebuster = $this->sanitize_context( [ 'source_type' => $source['typ'] ?? '', 'utm_source' => $source['src'] ?? '', 'utm_medium' => $source['mdm'] ?? '', 'utm_campaign' => $source['cmp'] ?? '', 'utm_content' => $source['cnt'] ?? '', 'utm_term' => $source['trm'] ?? '', 'landing_page' => $extra['ep'] ?? '', 'referrer' => $extra['rf'] ?? '' ] );
		return array_replace( $this->read_browser_context(), $sourcebuster );
	}

	private function read_browser_context(): array {
		if ( empty( $_COOKIE[ self::BROWSER_COOKIE ] ) || ! is_scalar( $_COOKIE[ self::BROWSER_COOKIE ] ) ) { return []; }
		$value = wp_unslash( (string) $_COOKIE[ self::BROWSER_COOKIE ] );
		if ( strlen( $value ) > 4096 ) { return []; }
		$data = json_decode( $value, TRUE );
		if ( ! is_array( $data ) ) { $data = json_decode( rawurldecode( $value ), TRUE ); }
		if ( ! is_array( $data ) ) { return []; }
		$allowed = array_flip( [ 'source_type', 'utm_source', 'utm_medium', 'utm_campaign', 'utm_content', 'utm_term', 'landing_page', 'referrer' ] );
		$data = $this->sanitize_context( array_intersect_key( $data, $allowed ) );
		if ( ! empty( $data['landing_page'] ) && wp_parse_url( $data['landing_page'], PHP_URL_HOST ) !== wp_parse_url( home_url( '/' ), PHP_URL_HOST ) ) { unset( $data['landing_page'] ); }
		return $data;
	}

	private function detect_source_type( array $query, string $referrer ): string {
		if ( isset( $query['utm_source'] ) && is_scalar( $query['utm_source'] ) && (string) $query['utm_source'] !== '' ) { return 'campaign'; }
		if ( $referrer === '' ) { return 'direct'; }
		$referrer_host = wp_parse_url( $referrer, PHP_URL_HOST );
		$site_host = wp_parse_url( home_url( '/' ), PHP_URL_HOST );
		return $referrer_host !== '' && $referrer_host === $site_host ? 'internal' : 'referral';
	}

	private function query_value( string $key ): string {
		return isset( $_GET[ $key ] ) && is_scalar( $_GET[ $key ] ) ? wp_unslash( (string) $_GET[ $key ] ) : '';
	}

	private function clear_browser_cookie(): void {
		unset( $_COOKIE[ self::BROWSER_COOKIE ] );
		if ( ! headers_sent() ) { setcookie( self::BROWSER_COOKIE, '', [ 'expires' => time() - HOUR_IN_SECONDS, 'path' => '/', 'secure' => is_ssl(), 'httponly' => FALSE, 'samesite' => 'Lax' ] ); }
	}

	private function parse_sourcebuster_cookie( string $name ): array {
		if ( empty( $_COOKIE[ $name ] ) || ! is_scalar( $_COOKIE[ $name ] ) ) { return []; } $value = rawurldecode( wp_unslash( (string) $_COOKIE[ $name ] ) );
		if ( ! str_contains( $value, '|||' ) ) { $decoded = base64_decode( $value, TRUE ); if ( is_string( $decoded ) && str_contains( $decoded, '|||' ) ) { $value = $decoded; } }
		$result = []; foreach ( explode( '|||', $value ) as $part ) { [ $key, $item ] = array_pad( explode( '=', $part, 2 ), 2, '' ); $key = sanitize_key( $key ); if ( $key !== '' ) { $result[ $key ] = html_entity_decode( $item, ENT_QUOTES | ENT_HTML5, 'UTF-8' ); } } return $result;
	}

	private function normalize_phone( string $phone ): string {
		$phone = strtr( $phone, [ '۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9','٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9' ] ); $phone = preg_replace( '/\D+/', '', $phone ) ?: ''; return preg_replace( '/^(?:0098|98|0)/', '', $phone ) ?: '';
	}
}
