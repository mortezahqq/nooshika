<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Services_UI_Gate {

	private static ?KERP_Services_UI_Gate $instance = NULL;

	public static function instance(): KERP_Services_UI_Gate {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	private function __construct() {}

	private function __clone() {}

	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize singleton.' );
	}

	public static function can( string $key, string $type = 'action' ): bool {
		if ( self::is_admin_bypass() ) {
			return TRUE;
		}

		$type        = $type === 'view' ? 'view' : 'action';
		$key         = strtolower( trim( $key ) );
		$permissions = self::get_permissions( $type );

		return self::permissions_allow( $permissions, $key );
	}

	/** Check another user's access without changing the current ERP session. */
	public static function can_for_user( int $user_id, string $key, string $type = 'action' ): bool {
		if ( user_can( $user_id, 'manage_options' ) || user_can( $user_id, KERP_Admin::CAPABILITY ) ) {
			return TRUE;
		}

		$record = KERP_Services_Access::get_record( $user_id );
		$type = $type === 'view' ? 'view' : 'action';
		$permissions = json_decode( (string) ( $record[ $type . '_permissions' ] ?? '[]' ), TRUE );

		return self::permissions_allow( is_array( $permissions ) ? $permissions : [], strtolower( trim( $key ) ) );
	}

	private static function permissions_allow( array $permissions, string $key ): bool {

		if ( $key === '' ) {
			return FALSE;
		}

		if ( in_array( '*', $permissions, TRUE ) || in_array( $key, $permissions, TRUE ) ) {
			return TRUE;
		}

		foreach ( $permissions as $permission ) {
			if ( self::match_wildcard( (string) $permission, $key ) ) {
				return TRUE;
			}
		}

		return FALSE;
	}

	public static function can_page( string $page ): bool {
		$page = preg_replace( '/[^a-z0-9_.:\\-]/', '', strtolower( trim( $page ) ) );

		return $page !== '' && self::can( 'page.' . $page, 'view' );
	}

	public static function list_filter( string $resource ): array {
		if ( self::is_admin_bypass() ) {
			return [ 'own', 'team', 'all' ];
		}

		$allowed = [];

		foreach ( [ 'own', 'team', 'all' ] as $scope ) {
			if ( self::can( $resource . '.list.' . $scope, 'view' ) ) {
				$allowed[] = $scope;
			}
		}

		return $allowed ?: [ 'none' ];
	}

	public static function list_scope( string $resource ): string {
		$allowed = self::list_filter( $resource );

		foreach ( [ 'all', 'team', 'own' ] as $scope ) {
			if ( in_array( $scope, $allowed, TRUE ) ) {
				return $scope;
			}
		}

		return 'none';
	}

	public static function get_permissions( string $type ): array {
		$permissions = KERP_Services_Session::get_permissions();

		return is_array( $permissions[ $type ] ?? NULL ) ? $permissions[ $type ] : [];
	}

	private static function match_wildcard( string $pattern, string $key ): bool {
		if ( $pattern === $key ) {
			return TRUE;
		}

		$pattern = preg_quote( $pattern, '#' );
		$pattern = str_replace( '\\*', '.*', $pattern );

		return (bool) preg_match( '#^' . $pattern . '$#', $key );
	}

	private static function is_admin_bypass(): bool {
		return in_array( 'administrator', (array) wp_get_current_user()->roles, TRUE );
	}
}
