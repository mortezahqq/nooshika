<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Services_Access {

	private static ?KERP_Services_Access $instance = NULL;

	public static function instance(): KERP_Services_Access {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	private function __construct() {
		add_action( 'wp_loaded', [ $this, 'hydrate_if_needed' ], 20 );
		add_action( 'wp_login', [ $this, 'hydrate_after_login' ], 20, 2 );
	}

	private function __clone() {}

	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize singleton.' );
	}

	public static function table(): string {
		global $wpdb;

		return $wpdb->prefix . 'kasebi_erp_user_access';
	}

	public static function install(): void {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$table   = self::table();
		$charset = $wpdb->get_charset_collate();
		$sql     = "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			user_id BIGINT UNSIGNED NOT NULL,
			role_key VARCHAR(100) NULL,
			assignment_key VARCHAR(150) NULL,
			view_permissions LONGTEXT NOT NULL,
			action_permissions LONGTEXT NOT NULL,
			meta LONGTEXT NULL,
			version INT UNSIGNED NOT NULL DEFAULT 1,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY uniq_user_id (user_id),
			KEY idx_role_key (role_key),
			KEY idx_assignment_key (assignment_key)
		) {$charset};";

		dbDelta( $sql );
	}

	public static function set_permissions(
		int $user_id,
		array $view_permissions = [],
		array $action_permissions = [],
		array $args = []
	): bool|WP_Error {
		global $wpdb;

		if ( $user_id <= 0 || ! get_userdata( $user_id ) ) {
			return new WP_Error( 'kerp_invalid_access_user', __( 'کاربر معتبر نیست.', 'kasebi-erp' ) );
		}

		$existing = self::get_record( $user_id );
		$now      = current_time( 'mysql' );
		$meta     = isset( $args['meta'] ) && is_array( $args['meta'] ) ? $args['meta'] : [];
		$data     = [
			'user_id'            => $user_id,
			'role_key'           => self::nullable_key( $args['role_key'] ?? NULL ),
			'assignment_key'     => self::nullable_key( $args['assignment_key'] ?? NULL ),
			'view_permissions'   => wp_json_encode( self::sanitize_permissions( $view_permissions ) ),
			'action_permissions' => wp_json_encode( self::sanitize_permissions( $action_permissions ) ),
			'meta'               => wp_json_encode( $meta ),
			'version'            => $existing ? ( (int) $existing['version'] + 1 ) : 1,
			'updated_at'         => $now,
		];

		if ( $existing ) {
			$result = $wpdb->update(
				self::table(),
				$data,
				[ 'user_id' => $user_id ],
				[ '%d', '%s', '%s', '%s', '%s', '%s', '%d', '%s' ],
				[ '%d' ]
			);
		} else {
			$data['created_at'] = $now;
			$result             = $wpdb->insert(
				self::table(),
				$data,
				[ '%d', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s' ]
			);
		}

		if ( $result === FALSE ) {
			return new WP_Error( 'kerp_access_save_failed', __( 'ذخیره دسترسی کاربر انجام نشد.', 'kasebi-erp' ) );
		}

		do_action( 'kerp_access_updated', $user_id, self::get_record( $user_id ) );

		if ( get_current_user_id() === $user_id ) {
			self::hydrate( $user_id );
		}

		return TRUE;
	}

	public static function remove_permissions( int $user_id ): bool {
		global $wpdb;

		$result = $wpdb->delete( self::table(), [ 'user_id' => $user_id ], [ '%d' ] );

		if ( get_current_user_id() === $user_id ) {
			KERP_Services_Session::reset_permissions();
		}

		do_action( 'kerp_access_removed', $user_id );

		return $result !== FALSE;
	}

	public static function get_record( int $user_id ): ?array {
		global $wpdb;

		$row = $wpdb->get_row(
			$wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE user_id = %d LIMIT 1', $user_id ),
			ARRAY_A
		);

		return is_array( $row ) ? $row : NULL;
	}

	public static function user_has_access( int $user_id ): bool {
		return self::get_record( $user_id ) !== NULL;
	}

	public function hydrate_if_needed(): void {
		if ( ! is_user_logged_in() ) {
			return;
		}

		$should_hydrate = kerp_is_erp_request() || wp_doing_ajax() || ( defined( 'KERP_DOING_AJAX' ) && KERP_DOING_AJAX );
		$should_hydrate = (bool) apply_filters( 'kerp_should_hydrate_access', $should_hydrate );

		if ( ! $should_hydrate ) {
			return;
		}

		$user_id         = get_current_user_id();
		$context         = KERP_Services_Session::get_context();
		$session_user_id = (int) ( $context['user_id'] ?? 0 );
		$session_version = (int) ( KERP_Services_Session::get_permissions_meta()['version'] ?? 0 );
		$db_version      = self::get_version( $user_id );

		if ( $session_user_id !== $user_id || $session_version !== $db_version ) {
			self::hydrate( $user_id );
		}
	}

	public function hydrate_after_login( string $user_login, WP_User $user ): void {
		self::hydrate( (int) $user->ID );
	}

	public static function hydrate( int $user_id ): void {
		$record = self::get_record( $user_id );

		KERP_Services_Session::set_user( $user_id );

		if ( ! $record ) {
			KERP_Services_Session::set_role( NULL );
			KERP_Services_Session::set_permissions( [], [] );
			KERP_Services_Session::set_permissions_meta( 0 );

			return;
		}

		$views   = json_decode( (string) $record['view_permissions'], TRUE );
		$actions = json_decode( (string) $record['action_permissions'], TRUE );

		KERP_Services_Session::set_role( $record['role_key'] ?: NULL );
		KERP_Services_Session::set_permissions(
			is_array( $views ) ? $views : [],
			is_array( $actions ) ? $actions : []
		);
		KERP_Services_Session::set_permissions_meta( (int) $record['version'] );
	}

	private static function get_version( int $user_id ): int {
		global $wpdb;

		return (int) $wpdb->get_var(
			$wpdb->prepare( 'SELECT version FROM ' . self::table() . ' WHERE user_id = %d LIMIT 1', $user_id )
		);
	}

	private static function sanitize_permissions( array $permissions ): array {
		$clean = [];

		foreach ( $permissions as $permission ) {
			if ( ! is_scalar( $permission ) ) {
				continue;
			}

			$permission = strtolower( trim( (string) $permission ) );
			$permission = (string) preg_replace( '/[^a-z0-9_.*:\\-]/', '', $permission );

			if ( $permission !== '' ) {
				$clean[] = $permission;
			}
		}

		return array_values( array_unique( $clean ) );
	}

	private static function nullable_key( mixed $value ): ?string {
		$value = sanitize_key( (string) $value );

		return $value !== '' ? $value : NULL;
	}
}
