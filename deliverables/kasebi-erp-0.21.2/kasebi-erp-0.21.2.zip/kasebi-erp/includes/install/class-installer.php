<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Install_Installer {
	
	private const VERSION_OPTION    = 'kerp_version';
	
	private const DB_VERSION_OPTION = 'kerp_db_version';
	
	private const PAGE_ID_OPTION    = 'kerp_page_id';
	
	public static function activate(): void {
		self::install_schema();
		self::install_capabilities();
		self::create_erp_page();
		
		update_option( self::VERSION_OPTION, KERP_VERSION, FALSE );
		update_option( self::DB_VERSION_OPTION, KERP_DB_VERSION, FALSE );
		
		KERP_Core_Router::instance()->register_rewrite_rules();
		flush_rewrite_rules();
	}
	
	public static function deactivate(): void {
		flush_rewrite_rules();
	}
	
	public static function maybe_upgrade(): void {
		$db_version = (string) get_option( self::DB_VERSION_OPTION, '0.0.1' );
		
		if ( version_compare( $db_version, KERP_DB_VERSION, '<' ) ) {
			self::install_schema();
			update_option( self::DB_VERSION_OPTION, KERP_DB_VERSION, FALSE );
		}
		
		$page_id = absint( get_option( self::PAGE_ID_OPTION, 0 ) );
		
		if ( $page_id === 0 || ! get_post_status( $page_id ) ) {
			self::create_erp_page();
		}
		
		update_option( self::VERSION_OPTION, KERP_VERSION, FALSE );
	}
	
	private static function install_schema(): void {
		KERP_Services_Access::install();
		KERP_Core_Order_Index::install();
		KERP_Modules_Customers_Notes::install();
		KERP_Modules_Customers_History::install();
		KERP_Api_File_Upload::install();
		KERP_Services_Attribution_First_Touch::install();
	}
	
	private static function install_capabilities(): void {
		$administrator = get_role( 'administrator' );
		
		if ( $administrator instanceof WP_Role ) {
			$administrator->add_cap( KERP_Admin::CAPABILITY );
			$administrator->add_cap( 'kerp_access_erp' );
		}
	}
	
	private static function create_erp_page(): int {
		$stored_page_id = absint( get_option( self::PAGE_ID_OPTION, 0 ) );
		
		if ( $stored_page_id && get_post_status( $stored_page_id ) ) {
			return $stored_page_id;
		}
		
		$existing_page = get_page_by_path( 'erp', OBJECT, 'page' );
		
		if ( $existing_page instanceof WP_Post ) {
			update_option( self::PAGE_ID_OPTION, $existing_page->ID, FALSE );
			
			return (int) $existing_page->ID;
		}
		
		$page_id = wp_insert_post(
			[
				'post_title'     => __( 'کاسبی ERP', 'kasebi-erp' ),
				'post_name'      => 'erp',
				'post_content'   => '[kasebi-erp]',
				'post_status'    => 'publish',
				'post_type'      => 'page',
				'comment_status' => 'closed',
			],
			TRUE
		);
		
		if ( is_wp_error( $page_id ) ) {
			return 0;
		}
		
		update_option( self::PAGE_ID_OPTION, (int) $page_id, FALSE );
		
		return (int) $page_id;
	}
	
	public static function get_page_id(): int {
		return absint( get_option( self::PAGE_ID_OPTION, 0 ) );
	}
	
}
