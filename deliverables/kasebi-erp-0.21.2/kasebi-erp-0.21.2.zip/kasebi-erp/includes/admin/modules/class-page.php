<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Admin_Modules_Page {
	
	public const SAVE_ACTION  = 'kerp_save_modules';
	
	public const NONCE_ACTION = 'kerp_save_modules';
	
	public const NONCE_NAME   = 'kerp_modules_nonce';
	
	private static ?KERP_Admin_Modules_Page $instance = NULL;
	
	public static function instance(): KERP_Admin_Modules_Page {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {
		add_action( 'admin_post_' . self::SAVE_ACTION, [ $this, 'save' ] );
	}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize singleton.' );
	}
	
	public function render(): void {
		if ( ! KERP_Admin::can_manage() ) {
			wp_die( esc_html__( 'شما دسترسی لازم برای مشاهده این صفحه را ندارید.', 'kasebi-erp' ) );
		}
		
		$notice          = isset( $_GET['kerp_notice'] ) ? sanitize_key( wp_unslash( $_GET['kerp_notice'] ) ) : '';
		$modules_manager = KERP_Modules::instance();
		
		KERP_Helpers_Template::render_template( 'admin/modules-page.php',
			[
				'modules_manager' => $modules_manager,
				'parent_modules'  => $modules_manager->get_parent_modules(),
				'notice'          => $notice,
			]
		);
	}
	
	public function save(): void {
		if ( ! KERP_Admin::can_manage() ) {
			wp_die( esc_html__( 'شما دسترسی لازم برای انجام این عملیات را ندارید.', 'kasebi-erp' ) );
		}
		
		check_admin_referer( self::NONCE_ACTION, self::NONCE_NAME );
		
		$posted   = isset( $_POST['modules'] ) && is_array( $_POST['modules'] )
			? wp_unslash( $_POST['modules'] )
			: [];
		$statuses = [];
		foreach ( KERP_Modules::get_registered_modules() as $key => $module ) {
			$key              = sanitize_key( (string) $key );
			$statuses[ $key ] = isset( $posted[ $key ] ) && (string) $posted[ $key ] === '1';
		}
		
		KERP_Modules::instance()->save_statuses( $statuses );
		
		wp_safe_redirect(
			add_query_arg(
				[
					'page'        => KERP_Admin_Menu::PAGE_MODULES,
					'kerp_notice' => 'modules_saved',
				],
				admin_url( 'admin.php' )
			)
		);
		exit;
	}
	
}
