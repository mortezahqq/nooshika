<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Admin_Menu {
	
	public const ROOT_SLUG    = 'kasebi-erp';
	
	public const PAGE_MODULES = 'kasebi-erp';
	
	private static ?KERP_Admin_Menu $instance = NULL;
	
	private array $screen_hooks = [];
	
	public static function instance(): KERP_Admin_Menu {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {
		add_action( 'admin_menu', [ $this, 'register_menu' ], 20 );
	}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize singleton.' );
	}
	
	public function register_menu(): void {
		$hook = add_menu_page(
			__( 'کاسبی ERP', 'kasebi-erp' ),
			__( 'کاسبی ERP', 'kasebi-erp' ),
			KERP_Admin::CAPABILITY,
			self::ROOT_SLUG,
			[ KERP_Admin_Modules_Page::instance(), 'render' ],
			'dashicons-screenoptions',
			3
		);
		
		if ( is_string( $hook ) && $hook !== '' ) {
			$this->screen_hooks[] = $hook;
		}
		
		do_action( 'kerp_admin_menu_registered', self::ROOT_SLUG );
	}
	
	public function is_erp_screen( string $hook_suffix ): bool {
		if ( in_array( $hook_suffix, $this->screen_hooks, TRUE ) ) {
			return TRUE;
		}
		
		return (bool) apply_filters(
			'kerp_is_admin_screen',
			FALSE,
			$hook_suffix
		);
	}
	
	public function register_screen_hook( string $hook_suffix ): void {
		if (
			$hook_suffix !== '' &&
			! in_array( $hook_suffix, $this->screen_hooks, TRUE )
		) {
			$this->screen_hooks[] = $hook_suffix;
		}
	}
	
}
