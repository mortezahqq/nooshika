<?php

defined( 'ABSPATH' ) || exit;

final class KERP_Admin_Assets {

	private static ?KERP_Admin_Assets $instance = NULL;

	public static function instance(): KERP_Admin_Assets {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	private function __construct() {
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue' ] );
	}

	private function __clone() {}

	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize singleton.' );
	}

	public function enqueue( string $hook_suffix ): void {
		if ( ! KERP_Admin_Menu::instance()->is_erp_screen( $hook_suffix ) ) {
			return;
		}

		wp_enqueue_style(
			'kerp-admin',
			KERP_ASSETS_URL . 'admin/css/admin.css',
			[ 'dashicons' ],
			kerp_asset_version( 'admin/css/admin.css' )
		);

		wp_enqueue_script(
			'kerp-admin',
			KERP_ASSETS_URL . 'admin/js/admin.js',
			[],
			kerp_asset_version( 'admin/js/admin.js' ),
			TRUE
		);

		wp_localize_script(
			'kerp-admin',
			'KERPAdminData',
			[
				'i18n' => [
					'saving' => __( 'در حال ذخیره…', 'kasebi-erp' ),
				],
			]
		);
	}
}
