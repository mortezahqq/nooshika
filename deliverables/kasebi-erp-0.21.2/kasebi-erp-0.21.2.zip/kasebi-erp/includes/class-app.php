<?php

defined( 'ABSPATH' ) || exit;

final class KERP_App {
	
	private static ?KERP_App $instance = NULL;
	
	public static function instance(): KERP_App {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {
		add_action( 'init', [ $this, 'register_shortcode' ] );
		add_action( 'template_redirect', [ $this, 'prepare_shell' ], 20 );
		add_filter( 'template_include', [ $this, 'use_app_template' ], 99 );
	}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize singleton.' );
	}
	
	public function register_shortcode(): void {
		add_shortcode( 'kasebi-erp', [ $this, 'render_mount' ] );
	}
	
	public function prepare_shell(): void {
		if ( kerp_is_erp_request() ) {
			show_admin_bar( FALSE );

			if ( is_user_logged_in() && $this->current_user_has_access() && empty( KERP_Core_Router::instance()->get_route() ) ) {
				$route = $this->get_user_default_route( get_current_user_id() );
				if ( $route !== '' ) {
					wp_safe_redirect( home_url( '/erp/' . $route . '/' ) );
					exit;
				}
			}
		}
	}

	/** Only registered static pages that this employee may open are selectable. */
	public function get_user_default_page_options( int $user_id ): array {
		$options = [ '' => __( 'استفاده از پیش‌فرض نقش (در نبود آن: میزکار)', 'kasebi-erp' ) ];
		foreach ( $this->get_registered_pages() as $key => $page ) {
			if ( $this->user_can_open_default_page( $user_id, $key, $page ) ) {
				$options[ $key ] = (string) ( $page['title'] ?? $key );
			}
		}
		return $options;
	}

	public function get_default_page_options(): array {
		$options = [];
		foreach ( $this->get_registered_pages() as $key => $page ) {
			if ( strpbrk( (string) $page['route'], '{}?#' ) === FALSE ) {
				$options[ $key ] = (string) ( $page['title'] ?? $key );
			}
		}
		return $options;
	}

	public function get_user_role_default_page( int $user_id ): string {
		$record = KERP_Services_Access::get_record( $user_id );
		if ( empty( $record['role_key'] ) || ! class_exists( 'KERP_Modules_Employees_Roles' ) ) {
			return '';
		}
		$role = KERP_Modules_Employees_Roles::instance()->get( (string) $record['role_key'] );
		return (string) ( $role['default_page'] ?? '' );
	}

	public function get_user_default_route( int $user_id ): string {
		$key = get_user_meta( $user_id, 'kerp_default_page', TRUE );
		if ( is_string( $key ) && $key === '' ) {
			$key = $this->get_user_role_default_page( $user_id );
		}
		if ( ! is_string( $key ) || $key === '' ) {
			return '';
		}
		$pages = $this->get_registered_pages();
		if ( ! isset( $pages[ $key ] ) || ! $this->user_can_open_default_page( $user_id, $key, $pages[ $key ] ) ) {
			return '';
		}
		return trim( (string) $pages[ $key ]['route'], '/' );
	}

	private function user_can_open_default_page( int $user_id, string $key, array $page ): bool {
		$route = trim( (string) $page['route'], '/' );
		if ( strpbrk( $route, '{}?#' ) !== FALSE ) {
			return FALSE;
		}
		$permission = trim( (string) ( $page['permission'] ?? '' ) );
		return ! empty( $page['unrestricted'] ) || ( $permission !== ''
			? KERP_Services_UI_Gate::can_for_user( $user_id, $permission, 'view' ) || KERP_Services_UI_Gate::can_for_user( $user_id, $permission )
			: KERP_Services_UI_Gate::can_for_user( $user_id, 'page.' . $key, 'view' ) );
	}
	
	public function use_app_template( string $template ): string {
		if ( ! kerp_is_erp_request() ) {
			return $template;
		}
		
		$app_template = KERP_TEMPLATES_PATH . 'app.php';
		
		return is_readable( $app_template ) ? $app_template : $template;
	}
	
	public function render_mount(): string {
		return '<div id="kerp-app" class="kerp-app" aria-live="polite"></div>';
	}
	
	public function current_user_has_access(): bool {
		if (
			current_user_can( KERP_Admin::CAPABILITY ) ||
			current_user_can( 'manage_options' )
		) {
			return TRUE;
		}
		
		return KERP_Services_Access::user_has_access( get_current_user_id() );
	}
	
	public function get_boot_data(): array {
		$user = wp_get_current_user();
		
		return [
			'version'     => KERP_VERSION,
			'homeUrl'     => home_url( '/erp/' ),
			'ajaxUrl'     => home_url( '/kerp-ajax' ),
			'route'       => KERP_Core_Router::instance()->get_route(),
			'modules'     => KERP_Modules::instance()->get_loaded_modules(),
			'permissions' => KERP_Services_Session::get_permissions(),
			'role'        => KERP_Services_Session::get_role(),
			'user'        => [
				'id'          => (int) $user->ID,
				'displayName' => KERP_Helpers_User::get_display_name( (int) $user->ID ),
			],
			'nonce'       => wp_create_nonce( 'kerp_app' ),
		];
	}
	
	public function get_registered_pages(): array {
		$pages = [
			'dashboard' => [
				'title'      => __( 'میزکار', 'kasebi-erp' ),
				'route'      => '',
				'type'       => 'page',
				'template'   => 'app/pages/dashboard.php',
				'permission' => '',
				'navigation' => [
					'group' => [
						'key'   => 'general',
						'title' => __( 'عمومی', 'kasebi-erp' ),
						'icon'  => 'uik fa-dashboard',
						'order' => 10,
					],
					'icon'  => 'uik fa-apps',
					'order' => 10,
				],
			],
			'settings'  => [
				'title'      => __( 'تنظیمات کاربری', 'kasebi-erp' ),
				'route'      => 'settings',
				'type'       => 'page',
				'template'   => 'app/pages/settings.php',
				'permission' => '',
				'unrestricted' => TRUE,
				'navigation' => [
					'group' => [
						'key'        => 'settings',
						'title'      => __( 'تنظیمات', 'kasebi-erp' ),
						'icon'       => 'kik fa-settings-02',
						'order'      => 100,
						'sep_before' => TRUE,
					],
					'icon'  => 'kik fa-settings-02',
					'order' => 100,
				],
			],
		];
		
		$pages = apply_filters( 'kerp_app_pages', $pages );
		
		if ( ! is_array( $pages ) ) {
			return [];
		}
		
		$registered_pages = [];
		
		foreach ( $pages as $page_key => $definition ) {
			$page_key = sanitize_key( (string) $page_key );
			
			if ( $page_key === '' || ! is_array( $definition ) ) {
				continue;
			}
			
			if ( ! array_key_exists( 'route', $definition ) ) {
				$definition['route'] = $page_key === 'dashboard'
					? ''
					: $page_key;
			}
			
			$registered_pages[ $page_key ] = $definition;
		}
		
		return $registered_pages;
	}
	
	public function get_current_page_context(): array {
		return $this->create_page_context(
			KERP_Core_Router::instance()->resolve()
		);
	}
	
	public function resolve_page_context( array $route ): array {
		if ( isset( $route['page'] ) && isset( $route['parts'] ) ) {
			if ( ! array_key_exists( 'found', $route ) ) {
				$pages          = $this->get_registered_pages();
				$page_slug      = sanitize_key( (string) $route['page'] );
				$route['found'] = isset( $pages[ $page_slug ] );
			}
			
			return $this->create_page_context( $route );
		}
		
		$query = [];
		
		if ( isset( $route['query'] ) && is_array( $route['query'] ) ) {
			$query = $route['query'];
			unset( $route['query'] );
		}
		
		return $this->create_page_context(
			KERP_Core_Router::instance()->resolve_parts( $route, $query )
		);
	}
	
	private function create_page_context( array $resolved ): array {
		$parts = isset( $resolved['parts'] ) && is_array( $resolved['parts'] )
			? array_values( $resolved['parts'] )
			: [];
		
		$query = isset( $resolved['query'] ) && is_array( $resolved['query'] )
			? $resolved['query']
			: [];
		
		$route_params = isset( $resolved['params'] ) && is_array( $resolved['params'] )
			? $resolved['params']
			: [];
		
		$found = ! empty( $resolved['found'] );
		
		if ( ! $found ) {
			return [
				'slug'           => 'not-found',
				'key'            => 'not-found',
				'page'           => 'not-found',
				'requested_page' => sanitize_key( (string) ( $resolved['page'] ?? '' ) ),
				'title'          => __( 'صفحه پیدا نشد', 'kasebi-erp' ),
				'template'       => 'app/pages/not-found.php',
				'permission'     => '',
				'route'          => $parts,
				'parts'          => $parts,
				'params'         => array_slice( $parts, 1 ),
				'route_params'   => [],
				'query'          => $query,
				'id'             => NULL,
				'type'           => 'page',
				'definition'     => [],
				'found'          => FALSE,
			];
		}
		
		$page_slug = sanitize_key( (string) ( $resolved['page'] ?? 'dashboard' ) );
		$pages     = $this->get_registered_pages();
		$page      = isset( $pages[ $page_slug ] ) && is_array( $pages[ $page_slug ] )
			? $pages[ $page_slug ]
			: [];
		
		if ( empty( $page ) ) {
			$resolved['found'] = FALSE;
			
			return $this->create_page_context( $resolved );
		}
		
		return [
			'slug'         => $page_slug,
			'key'          => $page_slug,
			'page'         => $page_slug,
			'title'        => (string) ( $page['title'] ?? $page_slug ),
			'template'     => (string) (
				$page['template']
				?? 'app/pages/not-found.php'
			),
			'permission'   => (string) ( $page['permission'] ?? '' ),
			'route'        => $parts,
			'parts'        => $parts,
			'params'       => array_slice( $parts, 1 ),
			'route_params' => $route_params,
			'query'        => $query,
			'id'           => isset( $resolved['id'] ) && $resolved['id'] !== NULL
				? absint( $resolved['id'] )
				: NULL,
			'type'         => sanitize_key( (string) ( $page['type'] ?? 'page' ) ),
			'definition'   => $page,
			'found'        => TRUE,
		];
	}
	
}
