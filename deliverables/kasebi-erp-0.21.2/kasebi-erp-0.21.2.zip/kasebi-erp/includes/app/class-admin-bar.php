<?php

defined( 'ABSPATH' ) || exit;

final class KERP_App_Admin_Bar {
	
	private static ?KERP_App_Admin_Bar $instance = NULL;
	
	public static function instance(): KERP_App_Admin_Bar {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	private function __construct() {
		add_action( 'admin_bar_menu', [ $this, 'register_menu' ], 999 );
	}
	
	private function __clone() {}
	
	public function __wakeup(): void {
		throw new LogicException( 'Cannot unserialize singleton.' );
	}
	
	public function register_menu( WP_Admin_Bar $wp_admin_bar ): void {
		if ( ! is_user_logged_in() || ! KERP_App::instance()->current_user_has_access() ) {
			return;
		}
		
		$wp_admin_bar->add_node( [
			'id'    => 'kerp-manager',
			'title' => __( 'کاسبی ERP', 'kasebi-erp' ),
			'href'  => home_url( '/erp/' ),
			'meta'  => [
				'target' => '_blank',
			],
		] );
		
		$items = [
			'customers' => [
				'title' => KERP_Modules_Customers_Settings::instance()->get_plural_label(),
				'url'   => '/erp/customers/',
			],
		];
		
		$items = apply_filters( 'kerp_admin_bar_items', $items );
		
		foreach ( $items as $key => $item ) {
			if ( empty( $item['title'] ) || empty( $item['url'] ) ) {
				continue;
			}

			$parent = sanitize_key( (string) ( $item['parent'] ?? '' ) );
			
			$wp_admin_bar->add_node( [
				'id'     => 'kerp-' . sanitize_key( $key ),
				'parent' => $parent !== '' ? 'kerp-' . $parent : 'kerp-manager',
				'title'  => (string) $item['title'],
				'href'   => home_url( (string) $item['url'] ),
				'meta'   => [
					'target' => '_blank',
				],
			] );
		}
	}
	
}
