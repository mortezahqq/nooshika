<?php

defined( 'ABSPATH' ) || exit;

/** The home workspace is composed of blocks registered by active modules. */
final class KERP_App_Dashboard {
	public static function register(): void {
		add_action( 'kasebi_ajax_dashboard_blocks', [ self::class, 'request_blocks' ] );
	}

	public static function request_blocks(): void {
		$nonce = isset( $_POST['nonce'] ) && is_string( $_POST['nonce'] ) ? wp_unslash( $_POST['nonce'] ) : '';
		if ( ! is_user_logged_in() || ! KERP_App::instance()->current_user_has_access() || ! kerp_can_page( 'dashboard' ) || ! wp_verify_nonce( $nonce, 'kerp-dashboard' ) ) {
			wp_send_json( [ 'status' => 'error', 'message' => 'دسترسی یا اعتبار درخواست کافی نیست؛ صفحه را تازه‌سازی کنید.' ], 403 );
			return;
		}
		// Access hydration has completed. Do not serialize independent dashboard
		// requests behind PHP's session lock; subsequent permission reads use a snapshot.
		KERP_Services_Session::release_for_reading();
		$module = isset( $_POST['module'] ) && is_string( $_POST['module'] ) ? sanitize_key( wp_unslash( $_POST['module'] ) ) : '';
		$context = [ 'user_id' => get_current_user_id(), 'page_context' => [] ];
		$html = [];
		foreach ( self::get_blocks( $context ) as $block ) {
			if ( empty( $block['async'] ) || $block['module'] !== $module ) { continue; }
			$level = ob_get_level();
			ob_start();
			try {
				call_user_func( $block['callback'], $context, $block );
				$html[ $block['id'] ] = (string) ob_get_clean();
			} catch ( Throwable $error ) {
				while ( ob_get_level() > $level ) { ob_end_clean(); }
				if ( $error instanceof KERP_Helpers_Dashboard_Pending ) {
					wp_send_json( [ 'status' => 'pending', 'progress' => $error->progress ] );
					return;
				}
				error_log( sprintf( 'ERP dashboard %s: %s', $block['id'], $error->getMessage() ) );
				wp_send_json( [ 'status' => 'error', 'message' => 'دریافت اطلاعات این بخش انجام نشد؛ دوباره تلاش کنید.' ], 500 );
				return;
			}
		}
		wp_send_json( [ 'status' => $html ? 'success' : 'unavailable', 'blocks' => $html ] );
	}

	/**
	 * Definitions are keyed by a unique, module-prefixed ID, not by position.
	 * Callbacks echo trusted template HTML; they receive ($context, $block).
	 * See docs/dashboard-blocks.md for the registration contract.
	 */
	public static function get_blocks( array $context = [] ): array {
		if ( ! KERP_App::instance()->current_user_has_access() || ! kerp_can_page( 'dashboard' ) ) {
			return [];
		}

		$definitions = apply_filters( 'kerp_dashboard_blocks', [], $context );
		if ( ! is_array( $definitions ) ) {
			return [];
		}

		$blocks = [];
		foreach ( $definitions as $id => $definition ) {
			if ( ! is_string( $id ) || $id === '' || sanitize_key( $id ) !== $id || ! is_array( $definition ) ) {
				continue;
			}

			$block = array_merge( [
				'title'      => '',
				'position'   => 100,
				'width'      => 12,
				'module'     => '',
				'permission' => '',
				'permission_type' => 'view',
				'callback'   => NULL,
			], $definition );
			$block['async'] = ! empty( $definition['async'] );
			$block['id'] = $id;

			if ( ! is_string( $block['module'] ) || ! is_string( $block['permission'] )
				|| ! is_string( $block['permission_type'] ) || ! is_string( $block['title'] )
				|| ! is_numeric( $block['position'] ) || ! is_numeric( $block['width'] ) ) {
				continue;
			}
			if ( $block['module'] !== '' && ! KERP_Modules::instance()->is_module_loaded( $block['module'] ) ) {
				continue;
			}
			if ( $block['permission'] !== '' && ! kerp_can( $block['permission'], $block['permission_type'] ) ) {
				continue;
			}
			if ( ! is_callable( $block['callback'] ) ) {
				continue;
			}

			$block['position'] = (int) $block['position'];
			$block['width'] = max( 1, min( 12, (int) $block['width'] ) );
			$blocks[ $id ] = $block;
		}

		// PHP's stable sort retains registration order for equal positions.
		uasort( $blocks, static fn( array $a, array $b ): int => $a['position'] <=> $b['position'] );
		return $blocks;
	}

	public static function render( array $context = [] ): void {
		$rendered = FALSE;
		foreach ( self::get_blocks( $context ) as $block ) {
			if ( $block['async'] ) {
				$content = '<div class="text-center py-4" role="status"><span class="spinner-border spinner-border-sm text-primary" aria-hidden="true"></span><p class="sub-text mt-2 mb-0">در حال آماده‌سازی اطلاعات…</p></div>';
				$rendered = TRUE;
				KERP_Helpers_Template::render_template( 'app/components/dashboard/block.php', compact( 'block', 'content' ) );
				continue;
			}
			$level = ob_get_level();
			ob_start();
			try {
				call_user_func( $block['callback'], $context, $block );
				$content = (string) ob_get_clean();
			} catch ( Throwable $error ) {
				while ( ob_get_level() > $level ) {
					ob_end_clean();
				}
				// Keep other modules usable without exposing exception details to users.
				error_log( sprintf( 'ERP dashboard block "%s": %s', $block['id'], $error->getMessage() ) );
				$content = '<p class="text-soft mb-0" role="status">'
					. esc_html__( 'نمایش این بخش در حال حاضر امکان‌پذیر نیست.', 'kasebi-erp' ) . '</p>';
			}

			if ( trim( $content ) === '' ) {
				continue;
			}
			$rendered = TRUE;
			KERP_Helpers_Template::render_template( 'app/components/dashboard/block.php', compact( 'block', 'content' ) );
		}

		if ( ! $rendered ) {
			KERP_Helpers_Template::render_template( 'app/components/dashboard/empty.php' );
		}
	}
}
