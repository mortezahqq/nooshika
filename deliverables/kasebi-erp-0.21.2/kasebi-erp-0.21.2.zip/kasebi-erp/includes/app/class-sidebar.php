<?php

defined( 'ABSPATH' ) || exit;

class KERP_App_Sidebar {
	
	private static ?self $instance = NULL;
	
	private function __construct() {}
	
	public static function instance(): self {
		if ( self::$instance === NULL ) {
			self::$instance = new self();
		}
		
		return self::$instance;
	}
	
	public function get_context( array $page_context ): array {
		$pages        = KERP_App::instance()->get_registered_pages();
		$current_page = sanitize_key(
			(string) (
				$page_context['slug']
				?? $page_context['key']
				   ?? $page_context['page']
				      ?? 'dashboard'
			)
		);
		
		$current_definition = (
			isset( $page_context['definition'] ) &&
			is_array( $page_context['definition'] )
		)
			? $page_context['definition']
			: ( $pages[ $current_page ] ?? [] );
		
		$current_navigation = (
			isset( $current_definition['navigation'] ) &&
			is_array( $current_definition['navigation'] )
		)
			? $current_definition['navigation']
			: [];
		
		/*
		 * صفحات مخفی، مانند customers/{id}، می‌توانند
		 * یکی از صفحات قابل نمایش منو را فعال کنند.
		 */
		$active_page = sanitize_key(
			(string) ( $current_navigation['active'] ?? $current_page )
		);
		
		$groups       = [];
		$active_group = '';
		$active_menu  = '';
		foreach ( $pages as $page_key => $page ) {
			if ( ! is_array( $page ) ) {
				continue;
			}
			
			$page_key = sanitize_key( (string) $page_key );
			
			if ( $page_key === '' ) {
				continue;
			}
			
			$navigation = (
				isset( $page['navigation'] ) &&
				is_array( $page['navigation'] )
			)
				? $page['navigation']
				: [];
			if (
				empty( $navigation ) ||
				! empty( $navigation['hidden'] ) ||
				! $this->can_show_page( $page_key, $page )
			) {
				continue;
			}
			
			$group = (
				isset( $navigation['group'] ) &&
				is_array( $navigation['group'] )
			)
				? $navigation['group']
				: [];
			
			$group_key = sanitize_key(
				(string) ( $group['key'] ?? 'general' )
			);
			
			if ( $group_key === '' ) {
				continue;
			}
			
			if ( ! isset( $groups[ $group_key ] ) ) {
				$groups[ $group_key ] = [
					'key'        => $group_key,
					'title'      => sanitize_text_field(
						(string) ( $group['title'] ?? 'عمومی' )
					),
					'icon'       => $group['icon'] ?? 'menu-circled',
					'order'      => (int) ( $group['order'] ?? 10 ),
					'sep_before' => ! empty( $group['sep_before'] ),
					'sep_after'  => ! empty( $group['sep_after'] ),
					'active'     => FALSE,
					'rows'       => [],
				];
			}
			
			$link = $this->get_page_link( $page );
			
			/*
			 * مسیرهای پارامتری مستقیماً در سایدبار نمایش داده نمی‌شوند.
			 */
			if ( empty( $link ) ) {
				continue;
			}
			
			$item = [
				'type'     => 'page',
				'key'      => $page_key,
				'title'    => sanitize_text_field(
					(string) (
						$navigation['title']
						?? $page['title']
						   ?? $page_key
					)
				),
				'icon'     => (string) ( $navigation['icon'] ?? $page['icon'] ?? 'file' ),
				'order'    => (int) ( $navigation['order'] ?? 10 ),
				'active'   => $page_key === $active_page,
				'href'     => $link['href'],
				'data_url' => $link['data_url'],
			];
			
			$menu = (
				isset( $navigation['menu'] ) &&
				is_array( $navigation['menu'] )
			)
				? $navigation['menu']
				: [];
			
			/*
			 * صفحه مستقیماً در سطح دوم نمایش داده شود.
			 */
			if ( empty( $menu ) ) {
				$row_key = 'page:' . $page_key;
				
				$groups[ $group_key ]['rows'][ $row_key ] = $item;
				
				if ( $item['active'] ) {
					$groups[ $group_key ]['active'] = TRUE;
					$active_group                   = $group_key;
				}
				
				continue;
			}
			
			/*
			 * صفحه در سطح سوم و زیر یک منوی بازشو نمایش داده شود.
			 */
			$menu_key = sanitize_key(
				(string) ( $menu['key'] ?? '' )
			);
			
			if ( $menu_key === '' ) {
				continue;
			}
			
			$row_key = 'menu:' . $menu_key;
			
			if ( ! isset( $groups[ $group_key ]['rows'][ $row_key ] ) ) {
				$groups[ $group_key ]['rows'][ $row_key ] = [
					'type'     => 'menu',
					'key'      => $menu_key,
					'title'    => sanitize_text_field(
						(string) ( $menu['title'] ?? $menu_key )
					),
					'icon'     => (string) ( $menu['icon'] ?? 'folder' ),
					'order'    => (int) ( $menu['order'] ?? 10 ),
					'active'   => FALSE,
					'children' => [],
				];
			}
			
			$groups[ $group_key ]['rows'][ $row_key ]['children'][ $page_key ] = $item;
			
			if ( $item['active'] ) {
				$groups[ $group_key ]['rows'][ $row_key ]['active'] = TRUE;
				$groups[ $group_key ]['active']                     = TRUE;
				
				$active_group = $group_key;
				$active_menu  = $menu_key;
			}
		}
		
		foreach ( $groups as &$group ) {
			foreach ( $group['rows'] as &$row ) {
				if (
					isset( $row['type'] ) &&
					$row['type'] === 'menu'
				) {
					$this->sort_items( $row['children'] );
				}
			}
			
			unset( $row );
			
			$this->sort_items( $group['rows'] );
		}
		
		unset( $group );
		
		$this->sort_items( $groups );
		
		/*
		 * اگر صفحه فعلی navigation مشخصی نداشت،
		 * اولین گروه مجاز به‌صورت پیش‌فرض باز باشد.
		 */
		if ( $active_group === '' && ! empty( $groups ) ) {
			$first_group_key = array_key_first( $groups );
			
			$groups[ $first_group_key ]['active'] = TRUE;
			$active_group                         = $first_group_key;
		}
		$groups = apply_filters(
			'kerp_sidebar_groups',
			$groups,
			$page_context
		);
		
		if ( ! is_array( $groups ) ) {
			$groups = [];
		}
		
		return [
			'groups' => $groups,
			'active' => [
				'group' => $active_group,
				'menu'  => $active_menu,
				'page'  => $active_page,
			],
		];
	}
	
	private function can_show_page(
		string $page_key,
		array $page
	): bool {
		if ( ! empty( $page['unrestricted'] ) ) {
			return TRUE;
		}

		$permission = sanitize_text_field(
			(string) ( $page['permission'] ?? '' )
		);
		
		if ( $permission !== '' ) {
			return kerp_can( $permission, 'view' ) || kerp_can( $permission );
		}
		
		return kerp_can_page( $page_key );
	}
	
	private function get_page_link( array $page ): array {
		$route = trim(
			(string) ( $page['route'] ?? '' ),
			'/'
		);
		
		if ( str_contains( $route, '{' ) ) {
			return [];
		}
		
		$data_url = $route === ''
			? '/erp/'
			: '/erp/' . $route . '/';
		
		return [
			'href'     => home_url( $data_url ),
			'data_url' => $data_url,
		];
	}
	
	private function sort_items( array &$items ): void {
		uasort(
			$items,
			static function( array $first, array $second ): int {
				$order_comparison =
					(int) ( $first['order'] ?? 10 )
					<=>
					(int) ( $second['order'] ?? 10 );
				
				if ( $order_comparison !== 0 ) {
					return $order_comparison;
				}
				
				return strcmp(
					(string) ( $first['title'] ?? '' ),
					(string) ( $second['title'] ?? '' )
				);
			}
		);
	}
	
}
