(() => {
    'use strict';

    const form = document.getElementById('kerp-modules-form');

    if (!form) {
        return;
    }

    form.addEventListener('submit', () => {
        const button = form.querySelector('.kerp-page-hero__submit');
        const label = button?.querySelector('.kerp-submit-label');

        if (!button) {
            return;
        }

        button.disabled = true;

        if (label && window.KERPAdminData?.i18n?.saving) {
            label.textContent = window.KERPAdminData.i18n.saving;
        }
    });
})();
