(function ($) {
    'use strict';
    $(document).on('change', '.kerp-referrals .kr-filters select', function () {
        const $form = $(this).closest('.kr-filters');
        const hasFilters = $form.attr('data-has-filters') === '1' || $form.find('select').toArray().some(function (select) { return !!select.value; });
        $form.find('.kr-reset-filters').prop('hidden', !hasFilters);
    });
    $(document).on('click', function (event) {
        $('.kerp-referrals .kr-filter-dropdown[open]').each(function () {
            if (!this.contains(event.target)) this.open = false;
        });
    });
    $(document).on('keydown', '.kerp-referrals .kr-filter-dropdown', function (event) {
        if (event.key !== 'Escape') return;
        this.open = false;
        $(this).find('summary')[0].focus();
    });
    function loadHistory($history, page, reset) {
        if ($history.data('busy')) return;
        const $form = $history.find('.kr-filters'), $feedback = $history.find('.kr-history-feedback');
        const state = reset ? '' : $form.find('[name="state"]').val();
        const kind = reset ? '' : $form.find('[name="kind"]').val();
        $history.data('busy', true).attr('aria-busy', 'true');
        $form.find('button, select').prop('disabled', true);
        $feedback.removeClass('kr-error').text('در حال دریافت معرفی‌ها…');
        $.ajax({url: KERPReferrals.historyUrl, method: 'POST', dataType: 'json', data: {
            action: 'kerp_referrals_history', nonce: $form.find('[name="nonce"]').val(),
            state: state, kind: kind, ref_page: page
        }}).done(function (response) {
            if (response.status !== 'success' || typeof response.html !== 'string') {
                $feedback.addClass('kr-error').text(response.message || 'دریافت معرفی‌ها انجام نشد؛ دوباره تلاش کنید.'); return;
            }
            if (!$history[0].isConnected) return;
            const $next = $($.parseHTML(response.html, document, false)).filter('.kr-history');
            if ($next.length !== 1) {
                $feedback.addClass('kr-error').text('پاسخ معتبر دریافت نشد؛ دوباره تلاش کنید.'); return;
            }
            $history.replaceWith($next);
            $next.find('.kr-history-feedback').text('فهرست معرفی‌ها به‌روز شد.');
            $next.find('#kr-history-title')[0].focus({preventScroll: true});
        }).fail(function () {
            $feedback.addClass('kr-error').text('ارتباط برقرار نشد. فهرست قبلی حفظ شده؛ دوباره تلاش کنید.');
        }).always(function () {
            $history.removeData('busy').attr('aria-busy', 'false');
            $form.find('button, select').prop('disabled', false);
        });
    }
    $(document).on('submit', '.kerp-referrals .kr-filters', function (event) {
        event.preventDefault();
        loadHistory($(this).closest('.kr-history'), 1, false);
    });
    $(document).on('click', '.kerp-referrals .kr-reset-filters', function () {
        loadHistory($(this).closest('.kr-history'), 1, true);
    });
    $(document).on('click', '.kerp-referrals .kr-history .kr-pagination a', function (event) {
        event.preventDefault();
        loadHistory($(this).closest('.kr-history'), Number($(this).attr('data-ref-page')) || 1, false);
    });
    $(document).on('submit', '.kr-form', function (event) {
        event.preventDefault();
        const $form = $(this), $button = $form.find('[type="submit"]'), $feedback = $form.find('.kr-feedback');
        if ($form.data('busy')) return;
        if ($form.find('.kr-picker input[type="hidden"]').toArray().some(function (input) { return !input.value; })) {
            $feedback.text('حساب شرکت و بازاریاب را از نتیجه جستجو انتخاب کنید.'); return;
        }
        $form.data('busy', true); $button.prop('disabled', true); $feedback.removeClass('kr-error').text('در حال ثبت…');
        const data = $form.serializeArray();
        $form.find('input[type="checkbox"]:not(:checked)').each(function () { data.push({name: this.name, value: '0'}); });
        data.push({name: 'action', value: 'kerp_referrals_' + $form.attr('data-action')});
        $.ajax({url: KERPReferrals.ajaxUrl, method: 'POST', dataType: 'json', data: data})
            .done(function (response) {
                $feedback.toggleClass('kr-error', response.status !== 'success').text(response.message || 'پاسخ معتبر دریافت نشد.');
                if (response.status === 'success' && response.reload) window.location.reload();
            }).fail(function () { $feedback.addClass('kr-error').text('پاسخ سرور دریافت نشد؛ با همین فرم دوباره تلاش کنید.'); })
            .always(function () { $form.removeData('busy'); $button.prop('disabled', false); });
    });
    $(document).on('click', '.kr-copy', async function () {
        const button = this, value = button.getAttribute('data-copy'), original = button.textContent;
        try {
            if (navigator.clipboard && window.isSecureContext) await navigator.clipboard.writeText(value);
            else {
                const input = document.createElement('textarea'); input.value = value; document.body.appendChild(input); input.select();
                const copied = document.execCommand('copy'); input.remove(); if (!copied) throw new Error('copy');
            }
            button.textContent = 'کپی شد'; setTimeout(function () { button.textContent = original; }, 2000);
        } catch (error) { window.prompt('این متن را کپی کنید:', value); }
    });
    $(document).on('input', '.kr-user-search', function () {
        const $input = $(this), $picker = $input.closest('.kr-picker'), term = this.value.trim();
        clearTimeout($input.data('timer'));
        if ($input.data('request')) $input.data('request').abort();
        $picker.find('input[type="hidden"]').val(''); $picker.find('.kr-user-results').empty();
        $picker.find('.kr-user-selected').text('یک حساب کاربری انتخاب کنید.');
        if (term.length < 2) return;
        $input.data('timer', setTimeout(function () {
            $input.data('request', $.ajax({url: KERPReferrals.ajaxUrl, method: 'POST', dataType: 'json', data: {
                action: 'kerp_referrals_users', nonce: $input.closest('form').find('[name="nonce"]').val(), term: term
            }}).done(function (response) {
                if ($input.val().trim() !== term) return;
                const $results = $picker.find('.kr-user-results').empty();
                (response.users || []).forEach(function (user) {
                    $('<button>', {type: 'button', 'class': 'kr-user-result', text: user.label}).on('click', function () {
                        $picker.find('input[type="hidden"]').val(user.id); $input.val(user.label);
                        $picker.find('.kr-user-selected').text(user.label); $results.empty();
                    }).appendTo($results);
                });
                if (!(response.users || []).length) $results.text(response.message || 'حسابی پیدا نشد.');
            }));
        }, 300));
    });
})(jQuery);
