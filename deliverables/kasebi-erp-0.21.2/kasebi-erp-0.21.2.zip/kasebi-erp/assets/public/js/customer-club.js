(function ($) {
    'use strict';
    $(document).on('click', '.kerp-club [data-club-tab]', function () {
        const tab = this.getAttribute('data-club-tab'), $root = $(this).closest('.kerp-club');
        $root.find('[data-club-tab], [data-club-panel]').removeClass('is-active');
        $(this).addClass('is-active'); $root.find('[data-club-panel="' + tab + '"]').addClass('is-active');
    });
    $(document).on('click', '.kerp-club .kc-redeem', function () {
        const button = this, $feedback = $(button).siblings('.kc-feedback');
        if (button.disabled || !window.confirm('پس از دریافت، این هدیه قابل لغو نیست. ادامه می‌دهید؟')) return;
		if (!button.dataset.requestId) button.dataset.requestId = (window.crypto && crypto.randomUUID ? crypto.randomUUID() : String(Date.now()) + '-' + Math.random().toString(36).slice(2));
        button.disabled = true; $feedback.removeClass('is-error').text('در حال ثبت هدیه…');
        $.ajax({url: KERPClub.url, method: 'POST', dataType: 'json', data: {action: 'kerp_club_redeem', reward_id: button.dataset.rewardId, nonce: button.dataset.nonce, request_id: button.dataset.requestId}})
            .done(function (response) { $feedback.toggleClass('is-error', response.status !== 'success').text(response.message || 'پاسخ معتبر دریافت نشد.'); if (response.status === 'success') window.location.reload(); else { delete button.dataset.requestId; button.disabled = false; } })
            .fail(function () { $feedback.addClass('is-error').text('ارتباط برقرار نشد؛ دوباره تلاش کنید.'); button.disabled = false; });
    });
}(jQuery));
