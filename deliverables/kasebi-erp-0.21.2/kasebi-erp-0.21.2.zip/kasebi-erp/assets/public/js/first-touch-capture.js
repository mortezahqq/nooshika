(() => {
	'use strict';

	const cookieName = 'kerp_first_touch_v1';
	if (document.cookie.split('; ').some((item) => item.startsWith(`${cookieName}=`))) {
		return;
	}

	const url = new URL(window.location.href);
	url.hash = '';
	const params = url.searchParams;
	const referrer = document.referrer || '';
	let sourceType = 'direct';

	if (params.get('utm_source')) {
		sourceType = 'campaign';
	} else if (referrer) {
		try {
			sourceType = new URL(referrer).hostname === window.location.hostname ? 'internal' : 'referral';
		} catch (error) {
			sourceType = 'referral';
		}
	}

	const context = {
		source_type: sourceType,
		utm_source: params.get('utm_source') || '',
		utm_medium: params.get('utm_medium') || '',
		utm_campaign: params.get('utm_campaign') || '',
		utm_content: params.get('utm_content') || '',
		utm_term: params.get('utm_term') || '',
		landing_page: url.toString(),
		referrer
	};
	const value = encodeURIComponent(JSON.stringify(context));

	if (value.length <= 3800) {
		document.cookie = `${cookieName}=${value}; Max-Age=15552000; Path=/; SameSite=Lax${window.location.protocol === 'https:' ? '; Secure' : ''}`;
	}
})();
