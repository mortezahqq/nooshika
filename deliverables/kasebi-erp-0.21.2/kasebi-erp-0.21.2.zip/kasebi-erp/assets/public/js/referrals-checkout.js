(function ($) {
    'use strict';
    function errorMessage(message) {
        // Also cover malformed/English responses from middleware or other plugins.
        if (typeof message !== 'string' || !/[\u0600-\u06ff]/.test(message) || /[a-zA-Z&<>]/.test(message)) {
            return 'ثبت کد معرف انجام نشد؛ دوباره تلاش کنید یا با پشتیبانی تماس بگیرید.';
        }
        return message;
    }
    $(document).on('keydown', '#kerp-checkout-referral-code', function (event) {
        if (event.key === 'Enter') {
            event.preventDefault();
            $(this).closest('.kerp-checkout-referral').find('.kerp-checkout-referral-submit').trigger('click');
        }
    });
    $(document).on('click', '.kerp-checkout-referral-submit', function () {
        const $button = $(this), $field = $button.closest('.kerp-checkout-referral');
        const $feedback = $field.find('.kerp-checkout-referral-feedback');
        const mode = $button.attr('data-mode') === 'remove' ? 'remove' : 'apply';
        const code = $field.find('input').val().trim();
        if ($field.data('busy')) return;
        if (mode === 'apply' && !code) { $feedback.text('کد معرف را وارد کنید.'); return; }
        $field.data('busy', true).attr('aria-busy', 'true');$button.prop('disabled', true);
        $feedback.text('در حال بررسی…');
        $.ajax({url: KERPReferralCheckout.url, method: 'POST', dataType: 'json', data: {
            action: 'kerp_referrals_' + mode, referral_code: code, nonce: $field.attr('data-nonce')
        }}).done(function (response) {
            if (!response || response.status !== 'success') { $feedback.text(errorMessage(response && response.msg)); return; }
            if (typeof response.main !== 'string' || typeof response.side !== 'string') { $feedback.text('پاسخ معتبر دریافت نشد؛ دوباره تلاش کنید.'); return; }
            $(document).trigger('nooshika:checkout-response', [response]);
        }).fail(function () { $feedback.text('ارتباط برقرار نشد؛ دوباره تلاش کنید.'); })
            .always(function () { $field.removeData('busy').attr('aria-busy', 'false');$button.prop('disabled', false); });
    });
})(jQuery);
