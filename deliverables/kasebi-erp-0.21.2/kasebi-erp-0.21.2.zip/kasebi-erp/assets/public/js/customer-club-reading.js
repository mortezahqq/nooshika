(function () {
    'use strict';
    if (!window.KERPClubReading || !KERPClubReading.postId) return;
    let elapsed = 0, scrollReached = false, sent = false;
    const timer = window.setInterval(function () { if (!document.hidden) elapsed += 1; attempt(); }, 1000);
    function attempt() {
        if (sent || elapsed < Number(KERPClubReading.seconds) || !scrollReached) return;
        sent = true; window.clearInterval(timer);
        const body = new URLSearchParams({action: 'kerp_club_article_read', nonce: KERPClubReading.nonce, post_id: KERPClubReading.postId});
        window.fetch(KERPClubReading.url, {method: 'POST', credentials: 'same-origin', headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}, body: body.toString()}).catch(function () {});
    }
    function checkScroll() {
		const rawTotal = document.documentElement.scrollHeight - window.innerHeight;
		scrollReached = rawTotal <= 10 || Math.min(100, (window.scrollY / Math.max(1, rawTotal)) * 100) >= Number(KERPClubReading.scroll);
        attempt();
    }
    window.addEventListener('scroll', checkScroll, {passive: true}); checkScroll();
}());
