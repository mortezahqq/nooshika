(function ($) {
    'use strict';
    function panelToast(message, type) {
        if (window.nooshika_panel && typeof window.nooshika_panel.toast === 'function') {
            window.nooshika_panel.toast(message, type || 'error', {position: 'top-right'});
        }
    }
    function refreshWalletPanel() {
        if (window.nooshika_panel && typeof window.nooshika_panel.refresh_page === 'function') {
            return window.nooshika_panel.refresh_page('wallet');
        }
        return null;
    }
    function closeActionModal($modal, restoreFocus) {
        if (!$modal.length) return;
        $modal.removeClass('is-active').attr('aria-hidden', 'true');
        $('body').removeClass('kerp-wallet-modal-open');
        if (restoreFocus !== false) {
            const trigger = $modal.data('wallet-modal-trigger');
            if (trigger && document.contains(trigger)) trigger.focus();
        }
    }
    function parseAmount(value) {
        value = String(value || '').trim().replace(/[۰-۹]/g, function (n) { return '۰۱۲۳۴۵۶۷۸۹'.indexOf(n); })
            .replace(/[٠-٩]/g, function (n) { return '٠١٢٣٤٥٦٧٨٩'.indexOf(n); }).replace(/٬/g, ',').replace(/٫/g, '.');
        return /^(?:[0-9]+|[0-9]{1,3}(?:,[0-9]{3})+)(?:\.[0-9]+)?$/.test(value) ? Number(value.replace(/,/g, '')) : NaN;
    }
    function panelAjaxUrl() {
        return window.nooshika_panel && typeof window.nooshika_panel.ajax_url === 'string'
            ? window.nooshika_panel.ajax_url
            : '';
    }
    $(document).on('click', '[data-wallet-modal-open]', function () {
        const $modal = $('#' + String($(this).attr('data-wallet-modal-open') || ''));
        if (!$modal.length) return;
        $modal.data('wallet-modal-trigger', this).addClass('is-active').attr('aria-hidden', 'false');
        $('body').addClass('kerp-wallet-modal-open');
        window.setTimeout(function () {
            let $focusTarget = $modal.find('input:not([type="hidden"]), textarea, select').filter(':visible').first();
            if (!$focusTarget.length) $focusTarget = $modal.find('[data-wallet-modal-close]').first();
            ($focusTarget.length ? $focusTarget : $modal.find('[role="dialog"]')).trigger('focus');
        }, 30);
    });
    $(document).on('click', '[data-wallet-modal-close]', function () {
        closeActionModal($(this).closest('.kerp-wallet-action-modal'));
    });
    $(document).on('click', '.kerp-wallet-action-modal', function (event) {
        if (event.target === this) closeActionModal($(this));
    });
    $(document).on('keydown', function (event) {
        const $modal = $('.kerp-wallet-action-modal.is-active').last();
        if (!$modal.length) return;
        if (event.key === 'Escape') {
            closeActionModal($modal);
            return;
        }
        if (event.key !== 'Tab') return;
        const $focusable = $modal.find('button:not(:disabled), input:not(:disabled), textarea:not(:disabled), select:not(:disabled), [tabindex]:not([tabindex="-1"])').filter(':visible');
        if (!$focusable.length) return;
        const first = $focusable.get(0), last = $focusable.get($focusable.length - 1);
        if (event.shiftKey && document.activeElement === first) {
            event.preventDefault(); last.focus();
        } else if (!event.shiftKey && document.activeElement === last) {
            event.preventDefault(); first.focus();
        }
    });
    $(document).on('click', '.kerp-wallet-charge-preset', function () {
        const $form = $(this).closest('form');
        $form.find('[name="amount"]').val($(this).attr('data-amount')).trigger('input').trigger('change').trigger('focus');
    });
    $(document).on('input change', '.kerp-wallet-charge-form [name="amount"]', function () {
        const amount = parseAmount(this.value);
        $(this).closest('form').find('.kerp-wallet-charge-preset').each(function () {
            const active = Number($(this).attr('data-amount')) === amount;
            $(this).toggleClass('is-active', active).attr('aria-pressed', String(active));
        });
    });
    $(document).on('submit', '.kerp-wallet-withdrawal-form', function (event) {
        event.preventDefault();
        const $form = $(this), $button = $form.find('[type="submit"]');
        if ($form.data('submitting')) return;
        const amount = parseAmount($form.find('[name="amount"]').val());
        if (!Number.isFinite(amount) || amount <= 0) { panelToast('مبلغ برداشت را به‌درستی وارد کنید.'); return; }
        let invalid = false;
        $form.find('[data-required="1"]').each(function () { if (!String($(this).val() || '').trim()) { invalid = true; $(this).trigger('focus'); return false; } });
        if (invalid) { panelToast('فیلدهای الزامی فرم برداشت را کامل کنید.'); return; }
        const data = $form.serializeArray();
        data.push({name: 'action', value: 'kerp_wallet_submit_withdrawal'}, {name: 'request_id', value: $form.attr('data-request-id')}, {name: 'nonce', value: $form.attr('data-nonce')});
        const requestUrl = panelAjaxUrl();
        if (!requestUrl) { panelToast('سرویس پنل در دسترس نیست؛ صفحه را تازه کنید.'); return; }
        $form.data('submitting', true); $button.prop('disabled', true);
        $.ajax({url: requestUrl, method: 'POST', dataType: 'json', data: $.param(data)}).done(function (response) {
            const message = response.message || response.msg || 'پاسخ نامعتبر دریافت شد.';
            panelToast(message, response.status === 'success' ? 'success' : 'error');
            if (response.status === 'success') {
                closeActionModal($form.closest('.kerp-wallet-action-modal'), false);
                const refreshRequest = refreshWalletPanel();
                if (refreshRequest && typeof refreshRequest.fail === 'function') {
                    refreshRequest.fail(function () {
                        panelToast('درخواست ثبت شد، اما به‌روزرسانی محتوای کیف پول انجام نشد. دوباره وارد بخش کیف پول شوید.');
                    });
                }
            }
        }).fail(function () { panelToast('ارتباط با سرور برقرار نشد.'); }).always(function () { $form.removeData('submitting'); $button.prop('disabled', false); });
    });
    $(document).on('click', '.kerp-wallet-payment-details', function () {
        const data = $(this).data('details') || {}, $modal = $('#kerpWalletPaymentDetailsModal');
        $modal.find('[data-wallet-detail="status"]').text(data.status || '—');
        $modal.find('[data-wallet-detail="bank"]').text(data.bank || '—');
        $modal.find('[data-wallet-detail="reference"]').text(data.reference || '—');
        $modal.find('[data-wallet-detail="paid_at"]').text(data.paid_at || '—');
        $modal.find('[data-wallet-detail="note"]').text(data.note || '—');
        const $receipt = $modal.find('[data-wallet-detail="receipt"]');
        data.receipt ? $receipt.attr('href', data.receipt).closest('.kerp-wallet-payment-receipt').show() : $receipt.removeAttr('href').closest('.kerp-wallet-payment-receipt').hide();
        $modal.addClass('is-active').attr('aria-hidden', 'false');
    });
    $(document).on('click', '.kerp-wallet-payment-modal__close, #kerpWalletPaymentDetailsModal', function (event) {
        if (event.target !== this && !$(event.target).closest('.kerp-wallet-payment-modal__close').length) return;
        $('#kerpWalletPaymentDetailsModal').removeClass('is-active').attr('aria-hidden', 'true');
    });
    $(document).on('submit', '.kerp-wallet-charge-form', function (event) {
        event.preventDefault();
        const $form = $(this);
        if ($form.data('submitting')) return;
        const $input = $form.find('[name="amount"]'), $button = $form.find('[type="submit"]');
        const amount = String($input.val() || '').trim(), number = parseAmount(amount);
        if (!amount) { panelToast('لطفاً مبلغ شارژ کیف پول را وارد کنید.'); $input.trigger('focus'); return; }
        if (!Number.isFinite(number) || number <= 0) { panelToast('مبلغ شارژ باید عددی معتبر و بیشتر از صفر باشد.'); $input.trigger('focus'); return; }
        const min = Number($form.attr('data-minimum') || 1), max = Number($form.attr('data-maximum') || 99999999);
        if (number < min || number > max) {
            panelToast('مبلغ شارژ باید بین ' + min.toLocaleString('fa-IR') + ' و ' + max.toLocaleString('fa-IR') + ' ' + ($form.attr('data-currency') || '') + ' باشد.'); return;
        }
        const requestUrl = panelAjaxUrl();
        if (!requestUrl) { panelToast('سرویس پرداخت در دسترس نیست؛ صفحه را تازه کنید.'); return; }
        $form.data('submitting', true);
        $button.prop('disabled', true).attr('aria-busy', 'true');
        $form.find('.kerp-wallet-charge-preset').prop('disabled', true);
        let redirecting = false;
        $.ajax({url: requestUrl, method: 'POST', dataType: 'json',
            data: {action: 'kerp_wallet_process_charge', amount: amount,
                request_id: $form.attr('data-request-id'), nonce: $form.attr('data-nonce')}
        }).done(function (response) {
            response = response || {};
            if (response.status === 'success' && response.redirect) {
                redirecting = true; window.location.assign(response.redirect);
            } else {
                const message = response.message || response.msg || 'پرداخت ایجاد نشد؛ دوباره تلاش کنید.';
                panelToast(message);
            }
        }).fail(function () {
            const message = 'پاسخ سرور دریافت نشد. با همین فرم دوباره تلاش کنید تا سفارش قبلی پیگیری شود.';
            panelToast(message);
        }).always(function () {
            if (!redirecting) {
                $form.removeData('submitting'); $button.prop('disabled', false).removeAttr('aria-busy');
                $form.find('.kerp-wallet-charge-preset').prop('disabled', false);
            }
        });
    });
})(jQuery);
