(function ($) {
    'use strict';

    function responseMessage(response, fallback) {
        if (!response || !response.data) { return fallback; }
        return typeof response.data === 'string' ? response.data : (response.data.message || fallback);
    }

    function discardToken(token) {
        if (!token) { return; }
        $.post(KERPPractices.ajaxUrl, {
            action: 'kerp_practice_discard_upload',
            nonce: KERPPractices.nonce,
            upload_token: token
        });
    }

    function entriesFor(upload) {
        var entries = $(upload).data('entries');
        if (!entries) {
            entries = [];
            $(upload).data('entries', entries);
        }
        return entries;
    }

    function updateUpload(upload) {
        var entries = entriesFor(upload);
        var pending = entries.filter(function (entry) { return entry.state === 'uploading'; }).length;
        var ready = entries.filter(function (entry) { return entry.state === 'uploaded'; }).length;
        var failed = entries.filter(function (entry) { return entry.state === 'error'; }).length;
        var placeholder = upload.querySelector('.kerp-practice-upload__placeholder');
        var form = upload.closest('.kerp-practice-form');
        if (pending) {
            placeholder.textContent = pending.toLocaleString('fa-IR') + ' فایل در حال آپلود';
        } else if (failed) {
            placeholder.textContent = failed.toLocaleString('fa-IR') + ' فایل ناموفق';
        } else if (ready) {
            placeholder.textContent = ready.toLocaleString('fa-IR') + ' فایل آمادهٔ ارسال';
        } else {
            placeholder.textContent = 'هنوز فایلی انتخاب نشده';
        }
        form.querySelector('button[type="submit"]').disabled = pending > 0 || form.dataset.submitting === '1';
    }

    function createEntry(file, upload) {
        var form = upload.closest('.kerp-practice-form');
        var row = document.createElement('div');
        row.className = 'kerp-practice-upload-file is-uploading';
        var main = document.createElement('div');
        main.className = 'kerp-practice-upload-file__main';
        var icon = document.createElement('span');
        icon.className = 'kerp-practice-upload-file__icon';
        icon.innerHTML = '<em class="hik-r fa-document-align-right-2" aria-hidden="true"></em>';
        var info = document.createElement('span');
        info.className = 'kerp-practice-upload-file__info';
        var name = document.createElement('strong');
        name.className = 'kerp-practice-upload-file__name';
        name.dir = 'auto';
        name.textContent = file.name;
        var status = document.createElement('small');
        status.className = 'kerp-practice-upload-file__status';
        status.textContent = 'در حال آپلود… ۰٪';
        var remove = document.createElement('button');
        remove.type = 'button';
        remove.className = 'kerp-practice-upload-file__remove';
        remove.setAttribute('aria-label', 'حذف فایل ' + file.name);
        remove.innerHTML = '<em class="hik-r fa-close" aria-hidden="true"></em>';
        var progress = document.createElement('div');
        progress.className = 'kerp-practice-upload-file__progress';
        progress.setAttribute('role', 'progressbar');
        progress.setAttribute('aria-label', 'پیشرفت آپلود فایل');
        progress.setAttribute('aria-valuemin', '0');
        progress.setAttribute('aria-valuemax', '100');
        progress.setAttribute('aria-valuenow', '0');
        var progressBar = document.createElement('span');
        progressBar.className = 'kerp-practice-upload-file__progress-bar';
        progress.appendChild(progressBar);
        info.append(name, status);
        main.append(icon, info, remove);
        row.append(main, progress);
        upload.querySelector('.kerp-practice-upload__files').appendChild(row);

        var entry = { row: row, state: 'uploading', token: '', request: null, removed: false };
        entriesFor(upload).push(entry);
        if (file.size < 1 || file.size > 20 * 1024 * 1024) {
            entry.state = 'error';
            row.classList.replace('is-uploading', 'is-error');
            status.textContent = 'حجم هر فایل باید حداکثر ۲۰ مگابایت باشد.';
            updateUpload(upload);
            return;
        }
        updateUpload(upload);

        var data = new FormData();
        data.append('action', 'kerp_practice_upload');
        data.append('nonce', KERPPractices.nonce);
        data.append('item_id', form.querySelector('[name="item_id"]').value);
        data.append('practice_id', form.querySelector('[name="practice_id"]').value);
        data.append('practice_file', file);
        var request = $.ajax({
            url: KERPPractices.ajaxUrl,
            method: 'POST',
            data: data,
            processData: false,
            contentType: false,
            dataType: 'json',
            xhr: function () {
                var xhr = new window.XMLHttpRequest();
                xhr.upload.addEventListener('progress', function (event) {
                    if (entry.removed || !event.lengthComputable) { return; }
                    var percent = Math.round(event.loaded / event.total * 100);
                    progressBar.style.width = percent + '%';
                    progress.setAttribute('aria-valuenow', String(percent));
                    status.textContent = 'در حال آپلود… ' + percent.toLocaleString('fa-IR') + '٪';
                });
                return xhr;
            }
        });
        entry.request = request;
        request.done(function (response) {
            if (entry.removed) {
                if (response && response.success && response.data) { discardToken(response.data.token); }
                return;
            }
            if (!response || !response.success || !response.data || !response.data.token) {
                entry.state = 'error';
                row.classList.replace('is-uploading', 'is-error');
                status.textContent = responseMessage(response, 'آپلود فایل انجام نشد.');
                return;
            }
            entry.token = response.data.token;
            entry.state = 'uploaded';
            row.classList.replace('is-uploading', 'is-uploaded');
            progressBar.style.width = '100%';
            progress.setAttribute('aria-valuenow', '100');
            var size = file.size >= 1024 * 1024
                ? (file.size / (1024 * 1024)).toFixed(1) + ' مگابایت'
                : Math.max(1, Math.round(file.size / 1024)) + ' کیلوبایت';
            status.textContent = 'آپلود شد · ' + size;
        }).fail(function (xhr, textStatus) {
            if (entry.removed || textStatus === 'abort') { return; }
            entry.state = 'error';
            row.classList.replace('is-uploading', 'is-error');
            status.textContent = responseMessage(xhr.responseJSON, 'ارتباط با سرور برقرار نشد.');
        }).always(function () {
            entry.request = null;
            if (!entry.removed) { updateUpload(upload); }
        });
    }

    $(document).on('change', '.kerp-practice-upload__input', function () {
        var form = this.closest('.kerp-practice-form');
        if (!form || form.dataset.submitting === '1') { this.value = ''; return; }
        var files = Array.from(this.files || []);
        var upload = this.closest('.kerp-practice-upload');
        this.value = '';
        var message = form.querySelector('.kerp-practice-message');
        message.textContent = '';
        message.classList.remove('is-error', 'is-success');
        if (entriesFor(upload).length + files.length > 100) {
            message.classList.add('is-error');
            message.textContent = 'حداکثر ۱۰۰ فایل برای هر پاسخ مجاز است.';
            return;
        }
        files.forEach(function (file) { createEntry(file, upload); });
    });

    $(document).on('click', '.kerp-practice-upload-file__remove', function () {
        var upload = this.closest('.kerp-practice-upload');
        var form = upload.closest('.kerp-practice-form');
        if (form.dataset.submitting === '1') { return; }
        var row = this.closest('.kerp-practice-upload-file');
        var entries = entriesFor(upload);
        var index = entries.findIndex(function (item) { return item.row === row; });
        if (index < 0) { return; }
        var entry = entries[index];
        entry.removed = true;
        if (entry.request) { entry.request.abort(); }
        discardToken(entry.token);
        entries.splice(index, 1);
        row.remove();
        updateUpload(upload);
        var message = form.querySelector('.kerp-practice-message');
        message.textContent = '';
        message.classList.remove('is-error', 'is-success');
    });

    $(document).on('submit', '.kerp-practice-form', function (event) {
        event.preventDefault();
        var form = this;
        if (form.dataset.submitting === '1') { return; }
        var upload = form.querySelector('.kerp-practice-upload');
        var entries = entriesFor(upload);
        var button = form.querySelector('button[type="submit"]');
        var buttonLabel = button.querySelector('span');
        var message = form.querySelector('.kerp-practice-message');
        message.classList.remove('is-error', 'is-success');
        if (entries.some(function (entry) { return entry.state === 'uploading'; })) {
            message.classList.add('is-error');
            message.textContent = 'تا پایان آپلود همهٔ فایل‌ها صبر کنید.';
            return;
        }
        if (entries.some(function (entry) { return entry.state === 'error'; })) {
            message.classList.add('is-error');
            message.textContent = 'فایل‌های ناموفق را حذف کنید یا دوباره انتخاب کنید.';
            return;
        }
        var ready = entries.filter(function (entry) { return entry.state === 'uploaded' && entry.token; });
        if (!ready.length) {
            message.classList.add('is-error');
            message.textContent = 'ابتدا فایل‌های تمرین را آپلود کنید.';
            return;
        }
        var data = new FormData();
        data.append('item_id', form.querySelector('[name="item_id"]').value);
        data.append('practice_id', form.querySelector('[name="practice_id"]').value);
        ready.forEach(function (entry) { data.append('upload_tokens[]', entry.token); });
        data.append('action', 'kerp_practice_submit');
        data.append('nonce', KERPPractices.nonce);
        form.dataset.submitting = '1';
        upload.querySelector('.kerp-practice-upload__input').disabled = true;
        upload.querySelectorAll('.kerp-practice-upload-file__remove').forEach(function (remove) { remove.disabled = true; });
        updateUpload(upload);
        var originalLabel = buttonLabel ? buttonLabel.textContent : '';
        if (buttonLabel) { buttonLabel.textContent = 'در حال ارسال…'; }
        message.textContent = 'در حال ثبت پاسخ…';
        var completed = false;
        $.ajax({
            url: KERPPractices.ajaxUrl,
            method: 'POST',
            data: data,
            processData: false,
            contentType: false,
            dataType: 'json'
        }).done(function (response) {
            if (response && response.success) {
                completed = true;
                message.textContent = response.data.message;
                message.classList.add('is-success');
                if (typeof window.location.reload === 'function') { window.location.reload(); }
            } else {
                message.classList.add('is-error');
                message.textContent = responseMessage(response, 'ارسال تمرین انجام نشد.');
            }
        }).fail(function (xhr) {
            message.classList.add('is-error');
            message.textContent = responseMessage(xhr.responseJSON, 'ارتباط با سرور برقرار نشد.');
        }).always(function () {
            if (completed) { return; }
            delete form.dataset.submitting;
            upload.querySelector('.kerp-practice-upload__input').disabled = false;
            upload.querySelectorAll('.kerp-practice-upload-file__remove').forEach(function (remove) { remove.disabled = false; });
            updateUpload(upload);
            if (buttonLabel) { buttonLabel.textContent = originalLabel; }
        });
    });
})(jQuery);
