(function($) {
    'use strict';
    
    const config = window.KERPProgramsPanel || {};
    let uploadIndex = 0;
    
    function showNotice($scope, message, type) {
        const $notice = $scope.find('.kerp-program-panel__notice').first();
        
        if (!$notice.length) {
            return;
        }
        
        $notice.removeClass('is-success is-error').
            addClass(type === 'success' ? 'is-success' : 'is-error').
            text(message || '').
            prop('hidden', false);
        
        if ($notice.offset()) {
            $('html, body').animate({
                scrollTop: Math.max(0, $notice.offset().top - 90),
            }, 250);
        }
    }
    
    function showFormMessage($form, message, type) {
        const $message = $form.find(
            '.kerp-program-panel-result-form__message',
        ).first();
        
        if (!$message.length) {
            return;
        }
        
        $message.removeClass('is-success is-error').
            addClass(type === 'success' ? 'is-success' : 'is-error').
            text(message || '').
            prop('hidden', false);
    }
    
    function hideFormMessage($form) {
        $form.find('.kerp-program-panel-result-form__message').
            first().
            prop('hidden', true).
            text('').
            removeClass('is-success is-error');
    }
    
    function openForm($card) {
        $('.kerp-program-panel-task').not($card).each(function() {
            const $other = $(this);
            
            $other.removeClass('is-form-open');
            
            $other.find('.kerp-program-panel-task__form-wrap').first().stop(true, true).slideUp(180);
        });
        
        $card.addClass('is-form-open');
        
        $card.find('.kerp-program-panel-task__form-wrap').first().stop(true, true).slideDown(180);
    }
    
    function closeForm($card) {
        $card.removeClass('is-form-open');
        
        $card.find('.kerp-program-panel-task__form-wrap').first().stop(true, true).slideUp(180);
    }
    
    /*
     * URL آپلود.
     *
     * نمونه custom_upload_file از nData.ajax_url
     * استفاده می‌کند، پس اولویت با همان است.
     */
    function getUploadUrl() {
        if (
            window.nData &&
            window.nData.ajax_url
        ) {
            return window.nData.ajax_url;
        }
        
        if (config.ajaxUrl) {
            return config.ajaxUrl;
        }
        
        return '';
    }
    
    /*
     * تعداد فایل‌هایی که URL نهایی آن‌ها
     * داخل فرم ذخیره شده.
     */
    function getUploadedCount($upload) {
        return $upload.find(
            '.kerp-program-upload__values ' +
            'input[name="attachments[]"]',
        ).length;
    }
    
    /*
     * تعداد فایل‌هایی که هنوز آپلودشان تمام نشده.
     */
    function getProcessingCount($upload) {
        return $upload.find(
            '.kerp-program-upload-file.is-uploading',
        ).length;
    }
    
    /*
     * فایل آپلودشده + فایل در حال آپلود.
     *
     * برای محدودیت ۵ فایل استفاده می‌شود.
     */
    function getActiveFileCount($upload) {
        return (
            getUploadedCount($upload) +
            getProcessingCount($upload)
        );
    }
    
    function formatProgramFileSize(bytes) {
        bytes = Number(bytes || 0);
        
        if (bytes < 1024) {
            return bytes + ' B';
        }
        
        if (bytes < 1024 * 1024) {
            return (
                bytes / 1024
            ).toFixed(1) + ' KB';
        }
        
        return (
            bytes /
            (
                1024 *
                1024
            )
        ).toFixed(1) + ' MB';
    }
    
    function updateProgramUploadPlaceholder($upload) {
        const $placeholder = $upload.find(
            '.kerp-program-upload__placeholder',
        ).first();
        
        const uploaded = getUploadedCount(
            $upload,
        );
        
        const processing = getProcessingCount(
            $upload,
        );
        
        const errors = $upload.find(
            '.kerp-program-upload-file.is-error',
        ).length;
        
        if (!$placeholder.length) {
            return;
        }
        
        if (processing > 0) {
            $placeholder.text(
                processing +
                ' فایل در حال آپلود',
            );
            
            return;
        }
        
        if (uploaded > 0) {
            $placeholder.text(
                uploaded +
                ' فایل آپلود شده',
            );
            
            return;
        }
        
        if (errors > 0) {
            $placeholder.text(
                'آپلود بعضی فایل‌ها ناموفق بود',
            );
            
            return;
        }
        
        $placeholder.text(
            'هنوز فایلی انتخاب نشده',
        );
    }
    
    function uploadFailed(
        $file,
        message,
    ) {
        const $upload = $file.closest(
            '.kerp-program-upload',
        );
        
        const $status = $file.find(
            '.kerp-program-upload-file__status',
        ).first();
        
        const $progress = $file.find(
            '.kerp-program-upload-file__progress',
        ).first();
        
        const $progressBar = $file.find(
            '.kerp-program-upload-file__progress-bar',
        ).first();
        
        $file.removeClass(
            'is-uploading is-uploaded',
        ).addClass(
            'is-error',
        );
        
        $progress.addClass(
            'is-error',
        );
        
        $progressBar.css(
            'width',
            '100%',
        );
        
        $status.text(
            message ||
            'خطا در آپلود فایل',
        );
        
        updateProgramUploadPlaceholder(
            $upload,
        );
    }
    
    /*
     * آپلود یک فایل.
     *
     * به محض انتخاب اجرا می‌شود.
     */
    function uploadProgramFile(
        file,
        $upload,
        $form,
    ) {
        uploadIndex++;
        
        const uploadId =
                  'program-upload-' +
                  Date.now() +
                  '-' +
                  uploadIndex;
        
        const safeName = $('<div>').text(file.name).html();
        
        const fileSize = formatProgramFileSize(
            file.size,
        );
        
        const $file = $(`
            <div
                class="kerp-program-upload-file is-uploading"
                data-upload-id="${uploadId}"
            >

                <div class="kerp-program-upload-file__main">

                    <div class="kerp-program-upload-file__icon">
                        <em class="uik fa-file-attachment-04 icon"></em>
                    </div>

                    <div class="kerp-program-upload-file__info">

                        <div class="kerp-program-upload-file__name">
                            ${safeName}
                        </div>

                        <div class="kerp-program-upload-file__status">
                            در حال آماده‌سازی...
                        </div>

                        <div class="kerp-program-upload-file__size">
                            ${fileSize}
                        </div>

                    </div>

                    <button
                        type="button"
                        class="kerp-program-upload-file__remove"
                        aria-label="حذف فایل"
                    >
                        <em class="uik fa-cross icon"></em>
                    </button>

                </div>

                <div class="kerp-program-upload-file__progress">
                    <div class="kerp-program-upload-file__progress-bar"></div>
                </div>

            </div>
        `);
        
        const $filesWrap = $upload.find(
            '.kerp-program-upload__files',
        ).first();
        
        const $valuesWrap = $upload.find(
            '.kerp-program-upload__values',
        ).first();
        
        const $status = $file.find(
            '.kerp-program-upload-file__status',
        ).first();
        
        const $progress = $file.find(
            '.kerp-program-upload-file__progress',
        ).first();
        
        const $progressBar = $file.find(
            '.kerp-program-upload-file__progress-bar',
        ).first();
        
        $filesWrap.append(
            $file,
        );
        
        updateProgramUploadPlaceholder(
            $upload,
        );
        
        const formData = new FormData();
        
        formData.append(
            'action',
            'custom_upload_file',
        );
        
        formData.append(
            'file',
            file,
        );
        
        const uploadUrl = getUploadUrl();
        
        if (!uploadUrl) {
            uploadFailed(
                $file,
                'آدرس آپلود فایل در دسترس نیست.',
            );
            
            return;
        }
        
        const request = $.ajax({
            url:  uploadUrl,
            type: 'POST',
            data: formData,
            
            processData: false,
            contentType: false,
            cache:       false,
            dataType:    'json',
            
            /*
             * Progress واقعی Upload.
             */
            xhr: function() {
                const xhr =
                          new window.XMLHttpRequest();
                
                xhr.upload.addEventListener(
                    'progress',
                    function(event) {
                        if (
                            !event.lengthComputable
                        ) {
                            return;
                        }
                        
                        const percent =
                                  Math.round(
                                      (
                                          event.loaded /
                                          event.total
                                      ) *
                                      100,
                                  );
                        
                        $progressBar.css(
                            'width',
                            percent + '%',
                        );
                        
                        $status.text(
                            'در حال آپلود... ' +
                            percent +
                            '٪',
                        );
                    },
                );
                
                return xhr;
            },
            
            success: function(response) {
                if (
                    !response ||
                    response.status !==
                    'success' ||
                    !response.url
                ) {
                    uploadFailed(
                        $file,
                        response &&
                        (
                            response.msg ||
                            response.message
                        )
                        ? (
                            response.msg ||
                            response.message
                        )
                        : 'خطا در آپلود فایل',
                    );
                    
                    return;
                }
                
                $progressBar.css(
                    'width',
                    '100%',
                );
                
                $file.removeClass(
                    'is-uploading is-error',
                ).addClass(
                    'is-uploaded',
                );
                
                $status.text(
                    'آپلود شد',
                );
                
                /*
                 * URL نهایی فایل.
                 *
                 * این input همراه فرم Result
                 * ارسال می‌شود.
                 */
                $('<input>', {
                    type:             'hidden',
                    name:             'attachments[]',
                    value:            response.url,
                    'data-upload-id': uploadId,
                }).appendTo(
                    $valuesWrap,
                );
                
                $file.attr(
                    'data-file-url',
                    response.url,
                );
                
                if (
                    response.attachment_id
                ) {
                    $file.attr(
                        'data-attachment-id',
                        response.attachment_id,
                    );
                }
                
                window.setTimeout(
                    function() {
                        $progress.fadeOut(
                            200,
                        );
                    },
                    300,
                );
                
                hideFormMessage(
                    $form,
                );
                
                updateProgramUploadPlaceholder(
                    $upload,
                );
            },
            
            error: function(xhr) {
                /*
                 * Abort دستی خطا نیست.
                 */
                if (
                    xhr &&
                    xhr.statusText === 'abort'
                ) {
                    return;
                }
                
                let message =
                        'خطا در آپلود فایل';
                
                if (
                    xhr &&
                    xhr.responseJSON &&
                    (
                        xhr.responseJSON.msg ||
                        xhr.responseJSON.message
                    )
                ) {
                    message =
                        xhr.responseJSON.msg ||
                        xhr.responseJSON.message;
                }
                
                uploadFailed(
                    $file,
                    message,
                );
            },
        });
        
        /*
         * نگهداری XHR برای Cancel.
         */
        $file.data(
            'xhr',
            request,
        );
    }
    
    /*
     * باز/بسته شدن فرم Result.
     */
    $(document).on(
        'click',
        '.kerp-program-panel-task__result-toggle',
        function() {
            const $card = $(this).closest(
                '.kerp-program-panel-task',
            );
            
            if (
                $card.hasClass(
                    'is-form-open',
                )
            ) {
                closeForm(
                    $card,
                );
                
                return;
            }
            
            openForm(
                $card,
            );
        },
    );
    
    $(document).on(
        'click',
        '.kerp-program-panel-result-form__close',
        function() {
            closeForm(
                $(this).closest(
                    '.kerp-program-panel-task',
                ),
            );
        },
    );
    
    /*
     * Keyboard برای سلول تقویم.
     *
     * خود Navigation توسط page_activator
     * سیستم پنل انجام می‌شود.
     */
    $(document).on(
        'keydown',
        '.kerp-program-panel__day.page_activator',
        function(event) {
            if (
                event.key !== 'Enter' &&
                event.key !== ' '
            ) {
                return;
            }
            
            event.preventDefault();
            
            $(this).trigger(
                'click',
            );
        },
    );
    
    /*
     * انتخاب فایل.
     *
     * هر فایل بلافاصله جداگانه Upload می‌شود.
     */
    $(document).on(
        'change',
        '.kerp-program-upload__input',
        function() {
            const input = this;
            
            const $input = $(
                input,
            );
            
            const $upload = $input.closest(
                '.kerp-program-upload',
            );
            
            const $form = $input.closest(
                '.kerp-program-panel-result-form',
            );
            
            const files = Array.from(
                input.files || [],
            );
            
            if (!files.length) {
                return;
            }
            
            const maxFiles = Number(
                config.maxFiles || 5,
            );
            
            const activeCount =
                      getActiveFileCount(
                          $upload,
                      );
            
            if (
                activeCount +
                files.length >
                maxFiles
            ) {
                showFormMessage(
                    $form,
                    (
                        config.i18n &&
                        config.i18n.tooManyFiles
                    ) ||
                    'حداکثر ۵ فایل می‌توانید ثبت کنید.',
                    'error',
                );
                
                input.value = '';
                
                return;
            }
            
            files.forEach(
                function(file) {
                    uploadProgramFile(
                        file,
                        $upload,
                        $form,
                    );
                },
            );
            
            /*
             * Reset می‌کنیم تا همان فایل
             * دوباره هم قابل انتخاب باشد.
             */
            input.value = '';
            
            updateProgramUploadPlaceholder(
                $upload,
            );
        },
    );
    
    /*
     * حذف فایل.
     *
     * هم برای فایل قبلی،
     * هم فایل تازه آپلودشده،
     * هم فایل در حال Upload.
     */
    $(document).on(
        'click',
        '.kerp-program-upload-file__remove',
        function(event) {
            event.preventDefault();
            
            const $file = $(this).closest(
                '.kerp-program-upload-file',
            );
            
            const $upload = $file.closest(
                '.kerp-program-upload',
            );
            
            const uploadId = String(
                $file.attr(
                    'data-upload-id',
                ) || '',
            );
            
            const request =
                      $file.data(
                          'xhr',
                      );
            
            /*
             * اگر هنوز Upload تمام نشده
             * Request قطع شود.
             */
            if (
                request &&
                request.readyState !== 4
            ) {
                request.abort();
            }
            
            /*
             * URL مربوط به فایل را از Form حذف می‌کنیم.
             *
             * در نتیجه هنگام Save Result
             * این فایل دیگر ذخیره نمی‌شود.
             */
            if (uploadId) {
                $upload.find(
                    '.kerp-program-upload__values ' +
                    'input[data-upload-id="' +
                    uploadId +
                    '"]',
                ).remove();
            }
            
            $file.stop(
                true,
                true,
            ).slideUp(
                150,
                function() {
                    $(this).remove();
                    
                    updateProgramUploadPlaceholder(
                        $upload,
                    );
                },
            );
        },
    );
    
    /*
     * ثبت نتیجه.
     */
    $(document).on(
        'submit',
        '.kerp-program-panel-result-form',
        function(event) {
            event.preventDefault();
            
            const $form = $(
                this,
            );
            
            const form = this;
            
            const $submit = $form.find(
                '.kerp-program-panel-result-form__submit',
            ).first();
            
            const $scope = $form.closest(
                '.kerp-program-panel',
            );
            
            /*
             * تا وقتی Upload فایل تمام نشده
             * Result نباید ذخیره شود.
             */
            const uploadingFiles = $form.find(
                '.kerp-program-upload-file.is-uploading',
            ).length;
            
            if (
                uploadingFiles > 0
            ) {
                showFormMessage(
                    $form,
                    'لطفاً تا پایان آپلود فایل‌ها منتظر بمانید.',
                    'error',
                );
                
                return;
            }
            
            if (
                !form.checkValidity()
            ) {
                form.reportValidity();
                
                showFormMessage(
                    $form,
                    (
                        config.i18n &&
                        config.i18n.invalidResult
                    ) ||
                    'اطلاعات گزارش را کامل کنید.',
                    'error',
                );
                
                return;
            }
            
            if (
                $submit.prop(
                    'disabled',
                )
            ) {
                return;
            }
            
            /*
             * چون input فایل name ندارد،
             * فایل خام اینجا دوباره ارسال نمی‌شود.
             *
             * فقط hidden attachments[] ارسال می‌شوند.
             */
            const data =
                      new FormData(
                          form,
                      );
            
            data.append(
                'action',
                'programs_public_save_result',
            );
            
            data.append(
                'nonce',
                config.nonce || '',
            );
            
            const originalText =
                      $submit.find('span').text();
            
            $submit.prop(
                'disabled',
                true,
            ).addClass(
                'is-loading',
            );
            
            $submit.find('span').text(
                (
                    config.i18n &&
                    config.i18n.saving
                ) ||
                'در حال ذخیره...',
            );
            
            hideFormMessage(
                $form,
            );
            
            $.ajax({
                url:
                    config.ajaxUrl || '',
                
                method: 'POST',
                data:   data,
                
                processData: false,
                contentType: false,
                
                dataType: 'json',
            }).done(
                function(response) {
                    if (
                        !response ||
                        response.status !==
                        'success'
                    ) {
                        showFormMessage(
                            $form,
                            (
                                response &&
                                (
                                    response.message ||
                                    response.msg
                                )
                            ) ||
                            (
                                config.i18n &&
                                config.i18n.genericError
                            ) ||
                            'خطایی رخ داد.',
                            'error',
                        );
                        
                        return;
                    }
                    
                    const successMessage =
                              response.message ||
                              (
                                  config.i18n &&
                                  config.i18n.saved
                              ) ||
                              'گزارش ذخیره شد.';
                    
                    showNotice(
                        $scope,
                        successMessage,
                        'success',
                    );
                    
                    showFormMessage(
                        $form,
                        successMessage,
                        'success',
                    );
                    
                    /*
                     * Refresh همان روز
                     * با page_activator خود پنل.
                     */
                    window.setTimeout(
                        function() {
                            const $refresh =
                                      $scope.find(
                                          '.kerp-program-panel__refresh.page_activator',
                                      ).first();
                            
                            if (
                                $refresh.length
                            ) {
                                $refresh.trigger(
                                    'click',
                                );
                            }
                        },
                        450,
                    );
                },
            ).fail(
                function(xhr) {
                    let message =
                            (
                                config.i18n &&
                                config.i18n.genericError
                            ) ||
                            'خطایی رخ داد.';
                    
                    if (
                        xhr &&
                        xhr.responseJSON &&
                        (
                            xhr.responseJSON.message ||
                            xhr.responseJSON.msg
                        )
                    ) {
                        message =
                            xhr.responseJSON.message ||
                            xhr.responseJSON.msg;
                    }
                    
                    showFormMessage(
                        $form,
                        message,
                        'error',
                    );
                },
            ).always(
                function() {
                    $submit.prop(
                        'disabled',
                        false,
                    ).removeClass(
                        'is-loading',
                    );
                    
                    $submit.find('span').text(
                        originalText,
                    );
                },
            );
        },
    );

    $(document).on('click', '.kerp-program-learndash-toggle', function() {
        const $button = $(this);
        const $content = $button.next('.kerp-program-learndash-content');
        const resourceId = parseInt($button.attr('data-resource-id') || '0', 10);
        if (!resourceId || !$content.length || $button.hasClass('is-loading')) return;

        if (!$content.prop('hidden')) {
            $content.prop('hidden', true).empty();
            $button.attr('aria-expanded', 'false').removeClass('is-open');
            return;
        }

        $('.kerp-program-learndash-content').not($content).prop('hidden', true).empty();
        $('.kerp-program-learndash-toggle').not($button).attr('aria-expanded', 'false').removeClass('is-open');
        $button.addClass('is-loading').prop('disabled', true);
        $content.html('<div class="kerp-program-learndash-content__status"><span class="kerp-program-learndash-content__spinner"></span><span>در حال دریافت محتوای درس…</span></div>').prop('hidden', false);

        $.post(config.ajaxUrl, {
            action: 'programs_public_learndash_content',
            resource_id: resourceId,
            nonce: config.nonce,
        }).done(function(response) {
            if (!response || response.status !== 'success' || !response.html) {
                const message = response && (response.message || response.msg) ? (response.message || response.msg) : ((config.i18n && config.i18n.genericError) || 'خطایی رخ داد.');
                $content.html($('<div>', {class: 'kerp-program-learndash-content__error'}).text(message));
                return;
            }
            $content.html(response.html);
            $button.attr('aria-expanded', 'true').addClass('is-open');
        }).fail(function(xhr) {
            const response = xhr && xhr.responseJSON ? xhr.responseJSON : {};
            const message = response.message || response.msg || ((config.i18n && config.i18n.genericError) || 'خطایی رخ داد.');
            $content.html($('<div>', {class: 'kerp-program-learndash-content__error'}).text(message));
        }).always(function() {
            $button.removeClass('is-loading').prop('disabled', false);
        });
    });
    
})(jQuery);
