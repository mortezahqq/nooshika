(function ($) {
    'use strict';
    function request(action, data) {
        return new Promise(function (resolve, reject) {
            $.ajax({url: KERPRegistration.url, type: 'POST', dataType: 'json', data: Object.assign({action: 'leads_registration_' + action, nonce: KERPRegistration.nonce}, data)})
                .done(function (result) { if (result && result.status === 'success') resolve(result); else reject(new Error(result.msg || 'ثبت اطلاعات ناموفق بود.')); })
                .fail(function (xhr) { const error = new Error((xhr.responseJSON || {}).msg || 'ارتباط برقرار نشد؛ دوباره تلاش کنید.'); error.restart = !!(xhr.responseJSON || {}).restart; reject(error); });
        });
    }
    function fields($form, definitions) {
        const $target = $form.find('.kerp-registration-inputs').empty();
        definitions.forEach(function (field) {
            // Use a display-only copy; stored titles remain available to ERP filters.
            field = Object.assign({}, field, {label: (field.form_label || '').trim() || field.label});
            const $group = $('<fieldset class="kerp-registration-fieldset"></fieldset>').attr('data-label', field.label).data('registration-field', field);
            $('<legend class="kerp-registration-label"></legend>').text(field.label + (field.required ? ' *' : '')).appendTo($group);
            const key = 'answers[' + field.key + ']';
            if (field.type === 'text') $('<input type="text" maxlength="500">').attr({'name': key, 'aria-label': field.label, placeholder: field.placeholder || ''}).prop('required', field.required).appendTo($group);
            else if (field.type === 'select') {
                const $select = $('<select></select>').attr({'name': key, 'aria-label': field.label}).prop('required', field.required).appendTo($group);
                $('<option value=""></option>').text(field.placeholder || 'انتخاب کنید').appendTo($select);
                field.options.forEach(function (value) { $('<option></option>').val(value).text(value).appendTo($select); });
            } else {
                if (field.placeholder) $('<p class="kerp-registration-hint"></p>').text(field.placeholder).appendTo($group);
                field.options.forEach(function (value) {
                    const $label = $('<label class="kerp-registration-choice"></label>').appendTo($group);
                    $('<input>').attr({type: field.type, name: key + (field.type === 'checkbox' ? '[]' : '')}).val(value).prop('required', field.type === 'radio' && field.required).appendTo($label);
                    $('<span></span>').text(value).appendTo($label);
                });
                if (field.required) $group.attr('data-required-choice', '1');
            }
            $target.append($group);
        });
    }
    $('form.kerp-registration').each(function () {
        const $form = $(this), $submit = $form.find('[type="submit"]');
        let token = '', identity = '', verified = false, busy = false, completed = false, generation = 0;
        const initialFields = JSON.parse($form.attr('data-fields') || '[]');
        const display = Object.assign({first_button: 'ثبت و دریافت کد تأیید', second_button: 'تکمیل ثبت‌نام'}, JSON.parse($form.attr('data-display') || '{}'));
        $form.prop('noValidate', true);
        fields($form, initialFields);
        function recover(error) {
            if (!error.restart) throw error;
            token = ''; identity = ''; verified = false; generation++;
            $form.find('.kerp-registration-identity').show().find('input').prop('disabled', false);
            fields($form, initialFields); $submit.show().text(display.first_button);
            if (window.KasebiUI.activeOtp) window.KasebiUI.activeOtp.close();
            notify(error.message, 'error'); throw error;
        }
        function notify(text, type) {
            // Form notifications use the main plugin's toast.
            if (window.KasebiUI && typeof window.KasebiUI.toast === 'function') window.KasebiUI.toast(text, type || 'info', {escapeHtml: true});
        }
        function validate() {
            let $invalid = null, error = '';
            $form.find('input:not(:disabled), select:not(:disabled)').each(function () {
                if (error || this.type === 'radio' || this.type === 'checkbox') return;
                const $input = $(this), label = $input.attr('aria-label') || 'فیلد', rawValue = String($input.val() || ''), value = rawValue.trim();
                if (this.required && !value) error = 'فیلد «' + label + '» الزامی است.';
                else if (this.maxLength > 0 && Array.from(rawValue).length > this.maxLength) error = 'مقدار «' + label + '» نباید بیشتر از ' + this.maxLength + ' کاراکتر باشد.';
                else if (this.name === 'phone' && value) {
                    // Use the main plugin's validator and send its canonical result.
                    const phone = window.KasebiUI.validatePhone(value, true);
                    if (!phone) error = 'فیلد «' + label + '» را با شماره موبایل معتبر وارد کنید.';
                    else $input.val(phone);
                }
                if (error) $invalid = $input;
            });
            if (!error) $form.find('.kerp-registration-fieldset').each(function () {
                if (error) return;
                const $group = $(this), field = $group.data('registration-field');
                if (!field || field.type === 'text') return;
                const $controls = $group.find('input:not(:disabled), select:not(:disabled)');
                const values = field.type === 'select' ? [$controls.val()].filter(Boolean) : $controls.filter(':checked').map(function () { return this.value; }).get();
                if (field.required && !values.length) error = 'برای «' + field.label + '» حداقل یک گزینه انتخاب کنید.';
                else if (values.some(function (value) { return !field.options.includes(value); })) error = 'گزینه انتخاب‌شده برای «' + field.label + '» معتبر نیست.';
                if (error) $invalid = $controls.first();
            });
            if (!error) return true;
            $invalid.attr('aria-invalid', 'true').trigger('focus');
            notify(error, 'error');
            return false;
        }
        function finish(result) {
            completed = true; generation++;
            $form.find('.kerp-registration-identity').hide().find('input').prop('disabled', true);
            $form.find('.kerp-registration-inputs').empty(); $submit.hide();
            const confirmation = result.confirmation || {};
            const $confirmation = $form.find('.kerp-registration-confirmation').empty().prop('hidden', false);
            if (confirmation.type === 'redirect' && typeof confirmation.url === 'string') {
                let destination;
                try { destination = new URL(confirmation.url); } catch (_) {}
                if (destination && ['http:', 'https:'].includes(destination.protocol)) {
                    $('<p></p>').text('ثبت‌نام تکمیل شد؛ در حال انتقال به صفحه مقصد…').appendTo($confirmation);
                    $('<a></a>').attr('href', destination.href).text('رفتن به صفحه مقصد').appendTo($confirmation);
                    $confirmation.trigger('focus');
                    try { window.location.assign(destination.href); } catch (_) { /* The destination link remains available. */ }
                    return;
                }
            }
            // Rich text is sanitized on the server and returned only after successful completion.
            if (confirmation.type === 'message' && typeof confirmation.html === 'string' && confirmation.html.trim()) $confirmation.html(confirmation.html);
            else $confirmation.text(result.msg || 'ثبت‌نام شما با موفقیت تکمیل شد.');
            $confirmation.trigger('focus');
        }
        function showSecondStep(result) {
            verified = true;
            $form.find('.kerp-registration-identity').hide().find('input').prop('disabled', true);
            fields($form, result.fields || []); $submit.text(display.second_button);
        }
        function otp() {
            const current = ++generation;
            window.KasebiUI.openOtp({phone: $form.find('[name="phone"]').val(), sent: $form.data('sms-sent'),
                verify: function (code) { return request('verify', {token: token, otp: code}).catch(function (error) { if (current === generation) return recover(error); throw error; }); },
                onVerified: function (result) {
                    if (current !== generation) return;
                    showSecondStep(result); notify(result.msg, 'success');
                },
                resend: function () { return request('resend', {token: token}).catch(function (error) { if (current === generation) return recover(error); throw error; }); },
                onResent: function (result) { if (current === generation) notify(result.msg, 'success'); },
                onClose: function () { if (current === generation) generation++; }
            });
        }
        $form.on('change input', '.kerp-registration-identity input', function () { if (!verified) { token = ''; generation++; } });
        $form.on('change input', 'input, select', function () {
            $(this).removeAttr('aria-invalid');
            $(this).closest('.kerp-registration-fieldset').find('[aria-invalid]').removeAttr('aria-invalid');
        });
        $form.on('submit', function (event) {
            event.preventDefault(); if (busy || completed) return;
            if (!window.KasebiUI || typeof window.KasebiUI.validatePhone !== 'function' || ($form.attr('data-otp-required') !== '0' && typeof window.KasebiUI.openOtp !== 'function')) { notify('افزونه اصلی برای تأیید شماره در دسترس نیست.', 'error'); return; }
            if (!validate()) return;
            const serialized = $form.serialize();
            if (!verified && token && identity === serialized) { otp(); return; }
            if (!verified) { token = ''; identity = serialized; }
            const data = {campaign_id: $form.attr('data-campaign'), answers: {}};
            $form.serializeArray().forEach(function (field) {
                const match = field.name.match(/^answers\[([a-z0-9_]+)\](\[\])?$/);
                if (match) { if (match[2]) { data.answers[match[1]] = data.answers[match[1]] || []; data.answers[match[1]].push(field.value); } else data.answers[match[1]] = field.value; }
                else data[field.name] = field.value;
            });
            const params = new URLSearchParams(location.search), touch = {};
            ['utm_source','utm_medium','utm_campaign','utm_term','utm_content','utm_id','utm_source_platform','utm_creative_format','utm_marketing_tactic'].forEach(function (key) { if (params.get(key)) touch[key] = params.get(key); });
            let attribution = touch;
            try { if (Object.keys(touch).length) sessionStorage.setItem('kerp_registration_touch', JSON.stringify(touch)); else attribution = JSON.parse(sessionStorage.getItem('kerp_registration_touch') || '{}'); } catch (_) {}
            Object.assign(data, attribution);
            if (verified) data.token = token;
            busy = true; $submit.prop('disabled', true); $form.attr('aria-busy', 'true');
            request(verified ? 'finish' : 'start', data).then(function (result) {
                notify(result.msg, result.sms_sent === false ? 'warning' : 'success');
                if (verified && result.completed === true) finish(result);
                else if (verified) throw new Error('ثبت نهایی انجام نشد؛ دوباره تلاش کنید.');
                else {
                    token = result.token;
                    if (result.verified === true) showSecondStep(result);
                    else { $form.data('sms-sent', result.sms_sent); otp(); }
                }
            }).catch(function (error) { if (error.restart) { try { recover(error); } catch (_) {} } else notify(error.message, 'error'); })
              .finally(function () { busy = false; $submit.prop('disabled', false); $form.removeAttr('aria-busy'); });
        });
    });
})(jQuery);
