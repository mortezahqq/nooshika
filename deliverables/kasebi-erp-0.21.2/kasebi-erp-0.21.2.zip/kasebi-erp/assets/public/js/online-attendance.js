(function($) {
    'use strict';

    $(document).on('click', '.kerp-skyroom-join', function(event) {
        event.preventDefault();
        const $button = $(this);
        if ($button.data('loading')) return;

        const original = $button.find('.kerp-skyroom-join__label').text();
        const popup = window.open('', '_blank');
        $button.data('loading', true).addClass('is-loading').attr('aria-busy', 'true');
        $button.find('.kerp-skyroom-join__label').text(KERPOnlineAttendance.loading);

        $.post(KERPOnlineAttendance.ajaxUrl, {
            action: 'kerp_skyroom_join',
            nonce: KERPOnlineAttendance.nonce,
            post_id: $button.data('post-id')
        }).done(function(response) {
            if (!response || !response.status || !response.url) {
                if (popup) popup.close();
                window.alert(response && response.message ? response.message : KERPOnlineAttendance.error);
                return;
            }
            $button.attr('href', response.url);
            if (popup) popup.location.href = response.url;
            else window.location.href = response.url;
        }).fail(function(xhr) {
            if (popup) popup.close();
            const response = xhr.responseJSON || {};
            window.alert(response.message || KERPOnlineAttendance.error);
        }).always(function() {
            $button.data('loading', false).removeClass('is-loading').removeAttr('aria-busy');
            $button.find('.kerp-skyroom-join__label').text(original);
        });
    });
})(jQuery);
