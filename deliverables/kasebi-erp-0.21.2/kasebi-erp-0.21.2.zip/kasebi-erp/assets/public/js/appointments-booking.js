(function($) {
    'use strict';
    
    function getBooking() {
        return $('.kerp-booking').first();
    }
    
    function showNotice($booking, message, type) {
        let $notice = $booking.find('.kerp-booking__notice');
        if (!message) {
            $notice.attr('hidden', true).removeClass('is-error is-success').text('');
            return;
        }
        $notice.removeAttr('hidden').
            toggleClass('is-error', type === 'error').
            toggleClass('is-success', type === 'success').
            text(message);
        $('html, body').animate({scrollTop: Math.max(0, $booking.offset().top - 30)}, 180);
    }
    
    function setLoading($booking, active) {
        $booking.toggleClass('is-loading', !!active);
    }
    
    function switchStep($booking, step) {
        step = parseInt(step || '1', 10);
        $booking.find('.kerp-booking__panel').removeClass('is-active');
        $booking.find('.kerp-booking__panel[data-panel="' + step + '"]').addClass('is-active');
        $booking.find('.kerp-booking__step').each(function() {
            let itemStep = parseInt($(this).attr('data-step'), 10);
            $(this).toggleClass('is-active', itemStep === step).toggleClass('is-done', itemStep < step);
        });
        showNotice($booking, '');
        $('html, body').animate({scrollTop: Math.max(0, $booking.offset().top - 24)}, 180);
    }
    
    function filterServices($booking) {
        let selectedEmployee = String($booking.find('.kerp-booking-employee-filter').val() || '0');
        let selectedTerms = [];
        $booking.find('.kerp-booking-tax-filter').each(function() {
            let value = String($(this).val() || '0');
            if (value !== '0') {
                selectedTerms.push(value);
            }
        });
        let visible = 0;
        $booking.find('.kerp-booking-service').each(function() {
            let $service = $(this);
            let terms = String($service.attr('data-term-ids') || '').split(',').filter(Boolean);
            let employees = String($service.attr('data-employee-ids') || '').split(',').filter(Boolean);
            let matchesTerms = selectedTerms.every(function(term) { return terms.indexOf(term) !== -1; });
            let matchesEmployee = selectedEmployee === '0' || employees.length === 0 ||
                employees.indexOf(selectedEmployee) !== -1;
            let show = matchesTerms && matchesEmployee;
            $service.toggle(show);
            if (show) {
                visible++;
            } else if ($service.hasClass('is-selected')) {
                $service.removeClass('is-selected');
                $booking.find('.kerp-booking-service-id').val('');
                $booking.find('.kerp-booking__next[data-next="2"]').prop('disabled', true);
            }
        });
        $booking.find('.kerp-booking__empty-services').prop('hidden', visible > 0);
    }
    
    function selectedService($booking) {
        return $booking.find('.kerp-booking-service.is-selected').first();
    }
    
    function renderCalendar($booking, response) {
        let month = String(response.month || '');
        let monthTitle = String(response.month_title || month);
        let available = response.available_dates || {};
        let dates = response.dates || {};
        let displayDays = response.display_days || {};
        let daysInMonth = parseInt(response.days_in_month || '0', 10);
        let firstWeekday = parseInt(response.first_weekday || '0', 10);
        let today = String(KERPAppointmentsPublic.today || '');
        
        $booking.attr('data-current-month', month);
        $booking.find('.kerp-booking-month-title').text(monthTitle);
        
        /*
         * date('w'):
         * 0 = Sunday
         * 1 = Monday
         * ...
         * 6 = Saturday
         *
         * تقویم ما:
         * 0 = Saturday
         * 1 = Sunday
         * ...
         * 6 = Friday
         */
        let saturdayIndex = (firstWeekday + 1) % 7;
        let html = '';
        
        for (let i = 0; i < saturdayIndex; i++) {
            html += '<span class="kerp-booking-calendar__blank"></span>';
        }
        
        for (let day = 1; day <= daysInMonth; day++) {
            /*
             * date تاریخ واقعی میلادی است:
             * مثلاً روز 31 مرداد => 2026-08-22
             */
            let date = String(
                dates[day] ||
                dates[String(day)] ||
                '',
            );
            
            if (!date) {
                continue;
            }
            
            /*
             * عددی که کاربر می‌بیند، روز شمسی است.
             */
            let displayDay = String(
                displayDays[date] || day,
            );
            
            let count = parseInt(
                available[date] || '0',
                10,
            );
            
            let isPast = today && date < today;
            let isToday = today && date === today;
            let hasSlots = count > 0;
            let disabled = isPast || !hasSlots;
            
            let classes = [
                'kerp-booking-calendar__day',
            ];
            
            if (hasSlots) {
                classes.push('has-slots');
            }
            
            if (isToday) {
                classes.push('is-today');
            }
            
            if (isPast) {
                classes.push('is-past');
            }
            
            html +=
                '<button type="button"' +
                ' class="' + classes.join(' ') + '"' +
                ' data-date="' + date + '"' +
                (disabled ? ' disabled' : '') +
                '>' +
                '<span>' + displayDay + '</span>' +
                (
                    hasSlots
                    ? '<small>' + count + '</small>'
                    : ''
                ) +
                '</button>';
        }
        
        $booking.find('.kerp-booking-calendar__days').html(html);
        
        $booking.find('.kerp-booking-calendar__slot-groups').html(
            '<div class="kerp-booking-calendar__placeholder">' +
            'یک روز را از تقویم انتخاب کنید.' +
            '</div>',
        );
        
        $booking.find('.kerp-booking-selected-date').text('');
        
        $booking.find('.kerp-booking-date, .kerp-booking-time, .kerp-booking-employee-id').val('');
        
        $booking.find('.kerp-booking__next[data-next="3"]').prop('disabled', true);
    }
    
    function loadMonth($booking, month) {
        let serviceId = parseInt($booking.find('.kerp-booking-service-id').val() || '0', 10);
        let employeeId = parseInt($booking.find('.kerp-booking-employee-filter').val() || '0', 10);
        if (!serviceId) {
            return;
        }
        setLoading($booking, true);
        $.post(KERPAppointmentsPublic.ajaxUrl, {
            action:      'appointments_public_month',
            nonce:       KERPAppointmentsPublic.nonce,
            service_id:  serviceId,
            employee_id: employeeId,
            month:       month,
        }).done(function(response) {
            if (!response || response.status !== 'success') {
                showNotice($booking, response && response.msg ? response.msg : KERPAppointmentsPublic.i18n.genericError,
                    'error');
                return;
            }
            renderCalendar($booking, response);
        }).fail(function() {
            showNotice($booking, KERPAppointmentsPublic.i18n.genericError, 'error');
        }).always(function() {
            setLoading($booking, false);
        });
    }
    
    function loadSlots($booking, date, $day) {
        let serviceId = parseInt($booking.find('.kerp-booking-service-id').val() || '0', 10);
        let employeeId = parseInt($booking.find('.kerp-booking-employee-filter').val() || '0', 10);
        setLoading($booking, true);
        $.post(KERPAppointmentsPublic.ajaxUrl, {
            action:      'appointments_public_slots',
            nonce:       KERPAppointmentsPublic.nonce,
            service_id:  serviceId,
            employee_id: employeeId,
            date:        date,
        }).done(function(response) {
            if (!response || response.status !== 'success') {
                showNotice($booking, response && response.msg ? response.msg : KERPAppointmentsPublic.i18n.genericError,
                    'error');
                return;
            }
            $booking.find('.kerp-booking-calendar__day').removeClass('is-selected');
            $day.addClass('is-selected');
            $booking.find('.kerp-booking-date').val(response.date || date);
            $booking.find('.kerp-booking-time').val('');
            $booking.find('.kerp-booking-selected-date').text(response.display_date || date);
            let groups = response.employees || [];
            if (!groups.length) {
                $booking.find('.kerp-booking-calendar__slot-groups').
                    html('<div class="kerp-booking-calendar__placeholder">' + KERPAppointmentsPublic.i18n.noSlots +
                        '</div>');
                $booking.find('.kerp-booking__next[data-next="3"]').prop('disabled', true);
                return;
            }
            let html = '';
            $.each(groups, function(index, group) {
                html += '<div class="kerp-booking-slot-group"><div class="kerp-booking-slot-group__head"><strong>' +
                    $('<div>').text(group.employee_name || '').html() + '</strong><small>' +
                    (group.slots || []).length + ' زمان آزاد</small></div><div class="kerp-booking-slot-group__slots">';
                $.each(group.slots || [], function(i, slot) {
                    html += '<button type="button" class="kerp-booking-slot" data-time="' + slot.time +
                        '" data-employee-id="' + group.employee_id + '" data-employee-name="' +
                        $('<div>').text(group.employee_name || '').html() + '"><strong>' + slot.time + '</strong>' +
                        (parseInt(slot.remaining || '0', 10) > 1 ? '<small>' + slot.remaining + ' ظرفیت</small>' : '') +
                        '</button>';
                });
                html += '</div></div>';
            });
            $booking.find('.kerp-booking-calendar__slot-groups').html(html);
            $booking.find('.kerp-booking__next[data-next="3"]').prop('disabled', true);
            
            const $slotWrapper = $('#slot_wrapper');
            
            if ($slotWrapper.length) {
                $('html, body').animate({
                    scrollTop: $slotWrapper.offset().top - 100,
                }, 400);
            }
        }).fail(function() {
            showNotice($booking, KERPAppointmentsPublic.i18n.genericError, 'error');
        }).always(function() {
            setLoading($booking, false);
        });
    }
    
    function getCustomFields($booking) {
        let data = {};
        $booking.find('.kerp-booking-custom-field').each(function() {
            let $field = $(this);
            let key = String($field.attr('data-field-key') || '');
            if (!key) {
                return;
            }
            if ($field.is(':radio')) {
                if ($field.is(':checked')) {
                    data[key] = $field.val();
                }
                return;
            }
            if ($field.is(':checkbox')) {
                data[key] = $field.is(':checked') ? '1' : '0';
                return;
            }
            data[key] = $field.val();
        });
        return data;
    }
    
    function updateSummary($booking) {
        let $service = selectedService($booking);
        let employeeName = String($booking.find('.kerp-booking-slot.is-selected').attr('data-employee-name') || '');
        let dateText = String($booking.find('.kerp-booking-selected-date').text() || '');
        let firstName = $.trim($booking.find('.kerp-booking-first-name').val() || '');
        let lastName = $.trim($booking.find('.kerp-booking-last-name').val() || '');
        let phone = $.trim($booking.find('.kerp-booking-phone').val() || '');
        let price = parseFloat($service.attr('data-price') || '0');
        let payable = parseFloat($service.attr('data-payable') || '0');
        $booking.find('[data-summary="service"]').text($service.attr('data-title') || '—');
        $booking.find('[data-summary="employee"]').text(employeeName || '—');
        $booking.find('[data-summary="date"]').text(dateText || '—');
        $booking.find('[data-summary="time"]').text($booking.find('.kerp-booking-time').val() || '—');
        $booking.find('[data-summary="customer"]').text($.trim(firstName + ' ' + lastName) || '—');
        $booking.find('[data-summary="phone"]').text(phone || '—');
        $booking.find('[data-summary="price"]').text(new Intl.NumberFormat('fa-IR').format(price));
        $booking.find('[data-summary="payable"]').text(new Intl.NumberFormat('fa-IR').format(payable));
        $booking.find('.kerp-booking-gateways').toggle(payable > 0);
    }
    
    function toEnglishNumber(strNum) {
        if (!strNum) {
            return 0;
        }
        let pn    = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'],
            en    = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'],
            cache = strNum,
            i;
        for (i = 0; i < 10; i++) {
            let regex_fa = new RegExp(pn[i], 'g');
            cache = cache.replace(regex_fa, en[i]);
        }
        return cache;
    }
    
    function validate_phone_number(phone) {
        const p = String(toEnglishNumber(phone)).trim();
        const match = p.match(/^(\+98|0)?(9\d{9})$/);
        
        if (!match) {
            return false;
        }
        
        return match[2];
    }
    
    function validateCustomer($booking) {
        let isValid = true;
        
        $booking.find('.kerp-booking-input').each(function() {
            let $field = $(this);
            
            /*
             * اگر بخش قوانین مخفی است، فیلدهای آن اعتبارسنجی نشوند.
             */
            const $terms = $field.closest('.kerp-booking__terms');
            
            if ($terms.length && !$terms.is(':visible')) {
                $field.removeClass('is-invalid');
                return;
            }
            
            let value = $.trim(String($field.val() || ''));
            let required = String($field.attr('data-req') || '') === '1';
            let validate = String($field.attr('data-validate') || '');
            
            $field.removeClass('is-invalid');
            
            if ($field.is(':checkbox')) {
                if (required && !$field.is(':checked')) {
                    $field.addClass('is-invalid');
                    isValid = false;
                }
                
                return;
            }
            
            if ($field.is(':radio')) {
                let name = $field.attr('name');
                
                if (
                    required &&
                    name &&
                    !$booking.find('input[name="' + name + '"]:checked').length
                ) {
                    $booking.find('input[name="' + name + '"]').addClass('is-invalid');
                    isValid = false;
                }
                
                return;
            }
            
            if (required && !value) {
                $field.addClass('is-invalid');
                isValid = false;
                return;
            }
            
            if (!value || !validate) {
                return;
            }
            
            switch (validate) {
                case 'phone':
                    let phone = validate_phone_number(value);
                    
                    if (!phone) {
                        $field.addClass('is-invalid');
                        isValid = false;
                        return;
                    }
                    
                    $field.val(phone);
                    break;
                
                case 'persian-text':
                    if (!/^[\u0600-\u06FF\s‌]+$/.test(value)) {
                        $field.addClass('is-invalid');
                        isValid = false;
                    }
                    break;
                
                case 'email':
                    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
                        $field.addClass('is-invalid');
                        isValid = false;
                    }
                    break;
                
                case 'number':
                    let number = String(toEnglishNumber(value)).trim();
                    
                    if (number === '' || isNaN(number)) {
                        $field.addClass('is-invalid');
                        isValid = false;
                    } else {
                        $field.val(number);
                    }
                    break;
            }
        });
        
        return isValid;
    }
    
    function startLocalOtpTimer() {
        let $timer = $('#otp_modal .otp_timer');
        if (!$timer.length) {
            return;
        }
        let left = 59;
        $timer.addClass('disabled').html('<span>دریافت مجدد کد:</span><span class="timer_text">00:59</span>');
        let interval = setInterval(function() {
            left--;
            if (left <= 0) {
                clearInterval(interval);
                $timer.removeClass('disabled').text('دریافت مجدد پیامک');
                return;
            }
            $timer.find('.timer_text').text('00:' + String(left).padStart(2, '0'));
        }, 1000);
    }
    
    function openOtp(phone) {
        $('.otp_login_text').text('کد تایید برای شماره ' + phone + ' پیامک شد');
        $('#otp_modal').addClass('active');
        $('.submit_otp_btn').attr('data-action', 'appointments_public_verify_otp').attr('data-phone', phone);
        let $inputs = $('#otp_input_form').find('input');
        $inputs.val('').removeClass('filled');
        if ($inputs.length) {
            $inputs.eq(0).trigger('focus');
        }
        startLocalOtpTimer();
    }
    
    $(document).on('change', '.kerp-booking-tax-filter, .kerp-booking-employee-filter', function() {
        filterServices($(this).closest('.kerp-booking'));
    });
    
    $(document).on('click', '.kerp-booking-service', function() {
        let $booking = $(this).closest('.kerp-booking');
        $booking.find('.kerp-booking-service').removeClass('is-selected');
        $(this).addClass('is-selected');
        $booking.find('.kerp-booking-service-id').val($(this).attr('data-service-id'));
        $booking.find('.kerp-booking__next[data-next="2"]').prop('disabled', false);
    });
    
    $(document).on('click', '.kerp-booking__next', function() {
        let $booking = $(this).closest('.kerp-booking');
        let next = parseInt($(this).attr('data-next'), 10);
        if (next === 2) {
            if (!$booking.find('.kerp-booking-service-id').val()) {
                showNotice($booking, KERPAppointmentsPublic.i18n.chooseService, 'error');
                return;
            }
            let $service = selectedService($booking);
            const serviceData = $service.data('service') || {};
            const isFree = Number(serviceData.payable || 0) <= 0;
            $booking.find('.kerp-booking__selected-service').text($service.attr('data-title') || '');
            $booking.find('.kerp-booking__selection-summary-icon em').attr('class', $service.attr('data-icon') || '');
            $booking.find('.kerp-booking-service-description').html(serviceData.description || '');
            $booking.find('.kerp-booking__terms').toggle(!isFree);
            $booking.find('.kerp-booking__submit').text(
                isFree
                ? 'تایید شماره و ثبت نوبت'
                : 'تایید شماره و رفتن به پرداخت',
            );
            switchStep($booking, 2);
            loadMonth($booking, $booking.attr('data-current-month') || KERPAppointmentsPublic.month);
            return;
        }
        if (next === 3) {
            let time = $booking.find('.kerp-booking-time').val();
            let employeeId = $booking.find('.kerp-booking-employee-id').val();
            
            if (!time || !employeeId) {
                showNotice(
                    $booking,
                    KERPAppointmentsPublic.i18n.chooseSlot,
                    'error',
                );
                
                return;
            }
            
            let selectedDateTime = $.trim(
                $booking.find('.kerp-booking-selected-date').text() || '',
            );
            
            if (time) {
                selectedDateTime += ' - ' + time;
            }
            
            $booking.find('.kerp-booking__selected-date').text(selectedDateTime);
            
            switchStep($booking, 3);
            
            return;
        }
        if (next === 4) {
            if (!validateCustomer($booking)) {
                showNotice($booking, KERPAppointmentsPublic.i18n.invalidCustomer, 'error');
                return;
            }
            updateSummary($booking);
            switchStep($booking, 4);
        }
    });
    
    $(document).on('click', '.kerp-booking__back', function() {
        switchStep($(this).closest('.kerp-booking'), $(this).attr('data-back'));
    });
    
    $(document).on('click', '.kerp-booking-month-prev, .kerp-booking-month-next', function() {
        let $booking = $(this).closest('.kerp-booking');
        let parts = String($booking.attr('data-current-month') || KERPAppointmentsPublic.month).split('-');
        let date = new Date(parseInt(parts[0], 10), parseInt(parts[1], 10) - 1, 1);
        date.setMonth(date.getMonth() + ($(this).hasClass('kerp-booking-month-next') ? 1 : -1));
        let month = date.getFullYear() + '-' + String(date.getMonth() + 1).padStart(2, '0');
        if (month < KERPAppointmentsPublic.month) {
            return;
        }
        loadMonth($booking, month);
    });
    
    $(document).on('click', '.kerp-booking-calendar__day.has-slots', function() {
        if ($(this).prop('disabled')) {
            return;
        }
        loadSlots($(this).closest('.kerp-booking'), $(this).attr('data-date'), $(this));
    });
    
    $(document).on('click', '.kerp-booking-slot', function() {
        let $booking = $(this).closest('.kerp-booking');
        $booking.find('.kerp-booking-slot').removeClass('is-selected');
        $(this).addClass('is-selected');
        $booking.find('.kerp-booking-time').val($(this).attr('data-time'));
        $booking.find('.kerp-booking-employee-id').val($(this).attr('data-employee-id'));
        $booking.find('.kerp-booking__next[data-next="3"]').prop('disabled', false);
    });
    
    $(document).on('click', '.kerp-booking__submit', function() {
        let $booking = $(this).closest('.kerp-booking');
        let $service = selectedService($booking);
        let payable = parseFloat($service.attr('data-payable') || '0');
        let gateway = String($booking.find('input[name="kerp_booking_gateway"]:checked').val() || '');
        if (payable > 0 && !gateway) {
            showNotice($booking, KERPAppointmentsPublic.i18n.chooseGateway, 'error');
            return;
        }
        let phone = $.trim($booking.find('.kerp-booking-phone').val() || '');
        setLoading($booking, true);
        $.post(KERPAppointmentsPublic.ajaxUrl, {
            action:           'appointments_public_submit',
            nonce:            KERPAppointmentsPublic.nonce,
            service_id:       $booking.find('.kerp-booking-service-id').val(),
            employee_id:      $booking.find('.kerp-booking-employee-id').val(),
            date:             $booking.find('.kerp-booking-date').val(),
            time:             $booking.find('.kerp-booking-time').val(),
            first_name:       $booking.find('.kerp-booking-first-name').val(),
            last_name:        $booking.find('.kerp-booking-last-name').val(),
            phone:            phone,
            secondary_phone:  $booking.find('.kerp-booking-secondary-phone').val(),
            payment_method:   gateway,
            receipt_base_url: $booking.find('.kerp-booking-receipt-base-url').val(),
            customer_fields:  getCustomFields($booking),
        }).done(function(response) {
            if (response && response.status === 'need_otp') {
                openOtp(phone);
                return;
            }
            
            if (
                response &&
                response.result === 'success' &&
                response.redirect
            ) {
                window.location.href = response.redirect;
                return;
            }
            
            showNotice(
                $booking,
                response && response.msg
                ? response.msg
                : KERPAppointmentsPublic.i18n.genericError,
                'error',
            );
        }).fail(function() {
            showNotice(
                $booking,
                KERPAppointmentsPublic.i18n.genericError,
                'error',
            );
        }).always(function() {
            setLoading($booking, false);
        });
    });
    
    $(function() {
        $('.kerp-booking').each(function() {
            filterServices($(this));
        });
    });
    $(document).on('click', '.kerp-booking__change-service', function() {
        switchStep($(this).closest('.kerp-booking'), $(this).attr('data-back'));
    });
})(jQuery);
