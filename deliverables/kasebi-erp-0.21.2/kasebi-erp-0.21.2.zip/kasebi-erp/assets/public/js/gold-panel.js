(() => {
    'use strict';
    document.addEventListener('click', event => {
        const action = event.target.closest('[data-kgp-kind]'); if (!action) return;
        const root = action.closest('.kerp-gold'), select = root?.querySelector('[name=kind]');
        if (select && [...select.options].some(option => option.value === action.dataset.kgpKind)) { select.value = action.dataset.kgpKind; select.dispatchEvent(new Event('change',{bubbles:true})); }
    });
    function estimate(root) {
        const target = root.querySelector('[data-kgp-rate]'); if (!target) return;
        const kind = root.querySelector('[name=kind]'), field = root.querySelector('[name=grams]');
        target.hidden = kind.value !== 'buy'; if (target.hidden) return;
        const raw = field.value.trim().replace(/[۰-۹٠١٢٣٤٥٦٧٨٩]/g, c => String('۰۱۲۳۴۵۶۷۸۹'.includes(c) ? '۰۱۲۳۴۵۶۷۸۹'.indexOf(c) : '٠١٢٣٤٥٦٧٨٩'.indexOf(c)));
        const rate = Number(target.dataset.kgpRate);
        if (!rate) { target.textContent = 'برآورد پس از به‌روزرسانی نرخ در دسترس است.'; return; }
        if (!/^\d{1,8}(?:\.\d{1,6})?$/.test(raw) || Number(raw) <= 0) { target.textContent = 'برای برآورد، وزن را با حداکثر شش رقم اعشار وارد کنید.'; return; }
        target.textContent = 'برآورد خرید: ' + new Intl.NumberFormat('fa-IR',{maximumFractionDigits:Number(target.dataset.kgpDecimals)||0}).format(Number(raw)*rate) + ' ' + target.dataset.kgpUnit;
    }
    document.addEventListener('input', event => { const root = event.target.closest('.kerp-gold'); if (root && event.target.matches('[name=grams]')) estimate(root); });
    document.addEventListener('change', event => { const root = event.target.closest('.kerp-gold'); if (root && event.target.matches('[name=kind]')) estimate(root); });
})();
