(function ($) {
    'use strict';
function kerpTicketsRequest(options, retried = false) {
    return $.ajax(options).then(function (response) {
        if (!retried && response && response.code === 'ticket_nonce_expired' && response.tickets_nonce) {
            const nonce = response.tickets_nonce;
            if (options.data instanceof FormData) options.data.set('tickets_nonce', nonce);
            else options.data.tickets_nonce = nonce;
            $('.kerp-ticket-form [name="tickets_nonce"], .kerp-ticket-nonce').val(nonce).attr('value', nonce);
            return kerpTicketsRequest(options, true);
        }
        return response;
    });
}

    function kerpTicketsNotify(message, type = 'error') { nooshika_panel.toast(message, type); }
    $(document).on('click', function (event) {
        $('.kerp-ticket-filter-dropdown[open]').each(function () {
            if (!this.contains(event.target)) this.open = false;
        });
    });
    $(document).on('keydown', '.kerp-ticket-filter-dropdown', function (event) {
        if (event.key === 'Escape') { event.preventDefault(); this.open = false; $(this).children('summary').trigger('focus'); }
    });
    $(document).on('submit', '.kerp-ticket-form[data-public="1"]', async function (event) {
        event.preventDefault(); const form = this, $form = $(form);
        if ($form.data('busy') || !form.reportValidity()) return;
        const data = new FormData(form); data.set('action', 'kerp_tickets_save');
        const $modal = $form.closest('.modal');
        if ($modal.length) closeModal($modal);
        $('#loading_modal').addClass('active');
        const restoreForm = function () { if ($modal.length && document.contains(form)) $modal.addClass('kerp-ticket-modal-open').attr('aria-hidden', 'false'); };
        $form.data('busy', true).attr('aria-busy', 'true').find('[type="submit"], .submit_modal_form').prop('disabled', true);
        $form.find('.quill-basic[data-for]').each(function () { const quill = this.__quill; if (quill) data.set($(this).attr('data-for'), quill.root.innerHTML); });
        try { await kerpTicketsUploadFiles(form, data, $form.attr('data-endpoint'), 'kerp_tickets_save'); }
        catch (error) { $('#loading_modal').removeClass('active'); restoreForm(); kerpTicketsNotify(error.message || 'آپلود ناموفق بود.'); $form.data('busy', false).removeAttr('aria-busy').find('[type="submit"], .submit_modal_form').prop('disabled', false); return; }
        kerpTicketsRequest({url: $form.attr('data-endpoint'), method: 'POST', data: data, processData: false, contentType: false, dataType: 'json'})
            .done(function (response) { if (response.status === 'success' && typeof response.content === 'string') { nooshika_panel.apply_response(response); } else { restoreForm(); kerpTicketsNotify(response.message || 'عملیات ناموفق بود', 'error'); } })
            .fail(function () { restoreForm(); kerpTicketsNotify('ارتباط با سرور برقرار نشد. دوباره تلاش کنید.'); })
            .always(function () { $('#loading_modal').removeClass('active'); $form.data('busy', false).removeAttr('aria-busy').find('[type="submit"], .submit_modal_form').prop('disabled', false); });
    });
    $(document).on('submit', '.kerp-tickets-public .kerp-ticket-filters', function (event) {
        event.preventDefault();
        const query = $(this).serialize();
        const path = 'tickets' + (query ? '?' + query : '');
        // Dispatch through the customer panel's delegated navigation handler.
        const $link = $('<a>', {class: 'page_activator', 'data-url': path, hidden: true}).appendTo(this);
        $link.trigger('click').remove();
    });
    function closeModal($modal) { $modal.removeClass('kerp-ticket-modal-open').attr('aria-hidden', 'true'); const trigger = $modal.data('ticket-trigger'); if (trigger) trigger.focus(); }
    $(document).on('click', '.kerp-tickets [data-bs-toggle="modal"]', function () {
        if (window.bootstrap && window.bootstrap.Modal) return;
        const $modal = $($(this).attr('data-bs-target')); $modal.data('ticket-trigger', this).addClass('kerp-ticket-modal-open').attr({'aria-hidden': 'false', 'role': 'dialog', 'aria-modal': 'true'});
        $modal.find('input:not([type="hidden"]),select,textarea,button').filter(':visible').first().trigger('focus');
    });
    $(document).on('click', '.kerp-tickets [data-bs-dismiss="modal"]', function (event) { event.preventDefault(); closeModal($(this).closest('.modal')); });
    $(document).on('keydown', '.kerp-ticket-modal-open', function (event) {
        const $modal = $(this); if (event.key === 'Escape') { closeModal($modal); return; }
        if (event.key !== 'Tab') return;
        const $items = $modal.find('a,button,input:not([type="hidden"]),select,textarea').filter(':visible:not(:disabled)');
        if (event.shiftKey && document.activeElement === $items[0]) { event.preventDefault(); $items.last().trigger('focus'); }
        else if (!event.shiftKey && document.activeElement === $items[$items.length - 1]) { event.preventDefault(); $items.first().trigger('focus'); }
    });

async function kerpTicketsUploadFiles(form, data, endpoint, action, selectedFiles) {
    const zone = form.querySelector('.upload-zone');
    const dz = zone && zone.dropzone;
    if (!selectedFiles && zone && !dz) throw new Error('بارگذاری بخش پیوست‌ها کامل نشده است؛ صفحه را تازه کنید.');
    if (!selectedFiles && dz && dz.files.some(function (file) { return !file.accepted; })) throw new Error('فایل نامعتبر را از پیوست‌ها حذف کنید.');
    if (!selectedFiles) {
        if (!dz) return [];
        if (dz.getQueuedFiles().length || dz.getUploadingFiles().length) {
            await new Promise(function (resolve) { const done = function () { dz.off('queuecomplete', done); resolve(); }; dz.on('queuecomplete', done); });
        }
        const attachments = dz.getAcceptedFiles();
        if (attachments.some(function (file) { return file.status !== Dropzone.SUCCESS || !file._ticket_token; })) throw new Error('آپلود پیوست کامل نشده است؛ فایل ناموفق را دوباره انتخاب کنید.');
        attachments.forEach(function (file) { data.append('file_tokens[]', file._ticket_token); });
        return attachments.map(function (file) { return file._uploaded_url; });
    }
    const files = selectedFiles || (dz ? dz.getAcceptedFiles().slice() : []);
    if (files.length > 50) throw new Error('حداکثر ۵۰ فایل مجاز است.');
    const cached = $(form).data('ticket-files') || new Map(); $(form).data('ticket-files', cached);
    const urls = $(form).data('ticket-file-urls') || new Map(); $(form).data('ticket-file-urls', urls);
    for (let index = 0; index < files.length; index++) {
        const file = files[index]; const key = file.name + ':' + file.size + ':' + file.lastModified;
        if (!cached.has(key)) {
            const uuid = (window.crypto && crypto.randomUUID) ? crypto.randomUUID() : String(Date.now()) + '-' + Math.random().toString(36).slice(2);
            const chunkSize = 1024 * 1024; const chunks = Math.max(1, Math.ceil(file.size / chunkSize));
            for (let chunk = 0; chunk < chunks; chunk++) {
                const upload = new FormData(); upload.set('action', action); upload.set('operation', 'upload');
                upload.set('ticket_id', data.get('ticket_id') || '0'); upload.set('tickets_nonce', data.get('tickets_nonce'));
                upload.set('file', file.slice(chunk * chunkSize, (chunk + 1) * chunkSize), file.name);
                upload.set('dzuuid', uuid); upload.set('dzchunkindex', chunk); upload.set('dztotalchunkcount', chunks); upload.set('dztotalfilesize', file.size);
                const response = await kerpTicketsRequest({url: endpoint, method: 'POST', data: upload, processData: false, contentType: false, dataType: 'json'});
                if (response.status !== 'success') throw new Error(response.message || 'آپلود ناموفق بود.');
                if (response.token) cached.set(key, response.token);
                if (response.url) urls.set(key, response.url);
                if (dz && dz.files.includes(file)) dz.emit('uploadprogress', file, (chunk + 1) * 100 / chunks, Math.min(file.size, (chunk + 1) * chunkSize));
            }
            if (!cached.has(key)) throw new Error('تکمیل آپلود تأیید نشد.');
        }
        data.append('file_tokens[]', cached.get(key));
    }
    return files.map(function (file) { return urls.get(file.name + ':' + file.size + ':' + file.lastModified); });
}

    function kerpTicketsPanelEditors() {
        if (!window.Quill) return;
        $('.kerp-tickets .quill-basic').each(function () { if (this.__quill) return; const initial = $(this).find('.quill-value').val() || ''; const quill = new Quill(this, {theme: 'snow', modules: {toolbar: [['bold','italic','underline','strike'],['blockquote','code-block'],[{list:'ordered'},{list:'bullet'}],[{color:[]},{background:[]}],[{align:[]}],['clean']]}}); this.__quill = quill; if (initial) quill.clipboard.dangerouslyPasteHTML(initial); });
    }
    $(kerpTicketsPanelEditors);
    new MutationObserver(kerpTicketsPanelEditors).observe(document.body, {childList: true, subtree: true});


async function kerpTicketsUploadInlineImages(form, quill, files, range) {
    const $form = $(form);
    if ($form.data('busy')) { kerpTicketsNotify('تا پایان آپلود فعلی صبر کنید.'); return; }
    if (!files.length) return;
    if (!Quill.imports['formats/kerpTicketUploadingImage']) {
        const Base = Quill.import('blots/block/embed');
        class KerpTicketUploadingImage extends Base {
            static create(value) { const node = super.create(); node.dataset.uploadId = value.id; node.setAttribute('aria-label','در حال آپلود تصویر'); const img = document.createElement('img'); img.src = value.src; img.alt = 'در حال آپلود'; node.appendChild(img); return node; }
            static value(node) { return {id:node.dataset.uploadId,src:node.querySelector('img').src}; }
        }
        KerpTicketUploadingImage.blotName = 'kerpTicketUploadingImage'; KerpTicketUploadingImage.tagName = 'span'; KerpTicketUploadingImage.className = 'image-uploading';
        Quill.register(KerpTicketUploadingImage);
    }
    $form.data('busy', true).attr('aria-busy','true').find('[type="submit"], .submit_modal_form').prop('disabled',true);
    let index = range ? range.index : Math.max(0, quill.getLength()-1);
    try {
        for (const file of files) {
            const id = 'kt-' + Date.now() + '-' + Math.random().toString(36).slice(2), preview = URL.createObjectURL(file);
            quill.insertEmbed(index, 'kerpTicketUploadingImage', {id:id,src:preview}, 'user');
            quill.setSelection(index+1,0,'silent');
            try {
                const data = new FormData(form), isPublic = $form.attr('data-public') === '1';
                const urls = await kerpTicketsUploadFiles(form,data,isPublic ? $form.attr('data-endpoint') : ajax_url,isPublic ? 'kerp_tickets_save' : 'tickets_save',[file]);
                if (!urls[0]) throw new Error('نشانی تصویر دریافت نشد.');
                const node = quill.root.querySelector('[data-upload-id="'+id+'"]');
                if (node) { index = quill.getIndex(Quill.find(node)); quill.deleteText(index,1,'silent'); quill.insertEmbed(index,'image',urls[0],'user'); index++; quill.setSelection(index,0,'silent'); }
            } catch (error) {
                const node = quill.root.querySelector('[data-upload-id="'+id+'"]');
                if (node) quill.deleteText(quill.getIndex(Quill.find(node)),1,'user');
                throw error;
            } finally { URL.revokeObjectURL(preview); }
        }
    } catch (error) { kerpTicketsNotify(error.message || 'آپلود تصویر ناموفق بود؛ دوباره تلاش کنید.'); }
    finally { $form.data('busy',false).removeAttr('aria-busy').find('[type="submit"], .submit_modal_form').prop('disabled',false); }
}

$(document).on('click', '.kerp-ticket-download-all', function () {
    $(this).closest('.kerp-ticket-attachments').find('.kerp-ticket-file').each(function (index) {
        const url = this.href, name = this.textContent;
        setTimeout(function () { const link = document.createElement('a'); link.href = url; link.download = name; link.rel = 'noopener'; link.target = '_blank'; document.body.appendChild(link); link.click(); link.remove(); }, index * 200);
    });
});


function kerpTicketsInitComposer() {
    $('.modal_form[data-action="tickets_save"], .modal_form[data-action="kerp_tickets_save"]').each(function () {
        const form = this, $form = $(form);
        if ($form.data('ticket-modal-ready')) return;
        $form.data('ticket-modal-ready', true).addClass('kerp-ticket-form');
        $form.find('input[data-for], select[data-for], textarea[data-for]').each(function () { this.name = this.getAttribute('data-for'); });
        const isPublic = $form.attr('data-action') === 'kerp_tickets_save';
        $form.attr('data-public', isPublic ? '1' : '0');
        $form.attr('data-endpoint', isPublic ? nooshika_panel.ajax_url : ajax_url);
        $form.find('.submit_modal_form').attr({role: 'button', tabindex: '0'}).on('click', function (event) {
            event.preventDefault(); event.stopPropagation();
            if (!$form.data('busy')) $form.trigger('submit');
        }).on('keydown', function (event) { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); $(this).trigger('click'); } });
    });
    $('.kerp-ticket-form').each(function () {
        const form = this;
        const editor = form.querySelector('.quill-basic[data-for="content"]');
        const quill = editor && (editor.__quill || $(editor).data('quill'));

        if (quill && window.ImageUploader && !editor.dataset.ticketClipboardReady) {
            editor.dataset.ticketClipboardReady = '1';
            const toolbar = quill.getModule('toolbar');
            const uploader = new ImageUploader(quill, {
                upload: function (file) { return kerpTicketsUploadInlineImages(form, quill, file ? [file] : [], uploader.range || quill.getSelection(true)); }
            });
            // Keep the original picker/paste/drop behavior, but replace only our own
            // pending embed: the legacy uploader deletes three characters at a fixed index.
            uploader.readAndUploadFile = function (file) { return this.options.upload(file); };
            quill.theme.modules.imageUploader = uploader;
            if (toolbar && toolbar.container && !toolbar.container.querySelector('.ql-image')) {
                const group = document.createElement('span'); group.className = 'ql-formats';
                const button = document.createElement('button'); button.type = 'button'; button.className = 'ql-image';
                button.title = 'درج تصویر در متن'; button.setAttribute('aria-label', button.title);
                button.innerHTML = Quill.import('ui/icons').image;
                button.addEventListener('mousedown', function (event) { event.preventDefault(); });
                button.addEventListener('click', function () { if ($(form).data('busy')) return; quill.focus(); uploader.selectLocalImage(); });
                group.appendChild(button); toolbar.container.appendChild(group);
            }
        }
        const zone = form.querySelector('.upload-zone');
        if (zone && !zone.dropzone && window.nooshikaPanelInitUploads) window.nooshikaPanelInitUploads();
    });
}
$(kerpTicketsInitComposer);
let kerpTicketsComposerPending = false;
new MutationObserver(function () {
    if (kerpTicketsComposerPending) return;
    kerpTicketsComposerPending = true;
    setTimeout(function () { kerpTicketsComposerPending = false; kerpTicketsInitComposer(); }, 0);
}).observe(document.body, {childList:true, subtree:true});


$(document).on('click', '.kerp-ticket-image-preview, .kerp-ticket-chat .kerp-ticket-message-body img', function (event) {
    event.preventDefault();
    event.stopPropagation();
    const trigger = this, inline = this.tagName === 'IMG';
    const url = inline ? (this.currentSrc || this.src) : this.href;
    const name = inline ? (this.alt || '') : ($(this).attr('data-image-name') || '');
    if (!url) return;
    if ($.magnificPopup && $.magnificPopup.open) {
        $.magnificPopup.open({items:{src:url},type:'image',mainClass:'kerp-ticket-magnifier',closeOnContentClick:false,image:{verticalFit:true,titleSrc:function(){return $('<div>').text(name).html();}}});
        return;
    }
    const dialog = document.createElement('dialog'); dialog.className = 'kerp-ticket-image-dialog'; dialog.setAttribute('aria-label', name || 'نمایش تصویر');
    const close = document.createElement('button'); close.type = 'button'; close.className = 'kerp-ticket-image-close'; close.textContent = 'بستن ×';
    const viewport = document.createElement('div'); viewport.className = 'kerp-ticket-image-viewport';
    const zoom = document.createElement('button'); zoom.type = 'button'; zoom.className = 'kerp-ticket-image-zoom'; zoom.setAttribute('aria-label','بزرگ‌نمایی تصویر'); zoom.setAttribute('aria-pressed','false');
    const img = document.createElement('img'); img.src = url; img.alt = name; zoom.appendChild(img); viewport.appendChild(zoom);
    dialog.append(close, viewport); document.body.appendChild(dialog);
    close.addEventListener('click', function(){dialog.close();});
    zoom.addEventListener('click', function(){const enlarged=viewport.classList.toggle('is-zoomed');zoom.setAttribute('aria-pressed',String(enlarged));});
    dialog.addEventListener('click', function(e){if(e.target===dialog)dialog.close();});
    dialog.addEventListener('close', function(){dialog.remove();if(document.contains(trigger))trigger.focus();},{once:true});
    dialog.showModal(); close.focus();
});


$(document).on('click', '[data-ticket-upload-toggle]', function () { const target = document.getElementById(this.getAttribute('aria-controls')); if (!target) return; target.hidden = !target.hidden; this.setAttribute('aria-expanded', String(!target.hidden)); });
})(jQuery);
