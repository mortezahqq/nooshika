(function() {
    'use strict';
    const selector = 'input[data-kerp-numeric]';
    const normalize = value => value
        .replace(/[۰-۹]/g, digit => String(digit.charCodeAt(0) - 1776))
        .replace(/[٠-٩]/g, digit => String(digit.charCodeAt(0) - 1632))
        .replace(/٫/g, '.').replace(/٬/g, '');

    function validate(input) {
        const probe = document.createElement('input');
        probe.type = 'number';
        ['min', 'max', 'step', 'required', 'value'].forEach(name => {
            if (input.hasAttribute(name)) probe.setAttribute(name, input.getAttribute(name));
        });
        probe.value = input.value;
        const invalidNumber = input.value !== '' && probe.value === '';
        input.setCustomValidity(invalidNumber ? 'لطفاً یک عدد معتبر وارد کنید.' : probe.validationMessage);
    }

    function update(input) {
        const value = normalize(input.value);
        if (value !== input.value) {
            const start = input.selectionStart;
            const end = input.selectionEnd;
            const before = input.value;
            input.value = value;
            if (start !== null) input.setSelectionRange(normalize(before.slice(0, start)).length, normalize(before.slice(0, end)).length);
        }
        validate(input);
    }

    function prepare(root) {
        const inputs = [];
        if (root.matches && root.matches('input[type="number"]')) inputs.push(root);
        if (root.querySelectorAll) inputs.push(...root.querySelectorAll('input[type="number"]'));
        inputs.forEach(input => {
            // Native number inputs discard Persian digits before the input event.
            input.type = 'text';
            input.dataset.kerpNumeric = '1';
            if (!input.hasAttribute('inputmode')) input.inputMode = input.step === 'any' || Number(input.step) % 1 ? 'decimal' : 'numeric';
            update(input);
        });
    }

    ['input', 'change', 'focusout', 'compositionend'].forEach(eventName => {
        document.addEventListener(eventName, event => {
            if (event.target.matches(selector) && !event.isComposing) update(event.target);
        }, true);
    });
    document.addEventListener('submit', event => {
        const inputs = event.target.querySelectorAll(selector);
        inputs.forEach(update);
        if (Array.from(inputs).some(input => !input.checkValidity())) {
            event.preventDefault();
            event.stopImmediatePropagation();
            event.target.reportValidity();
        }
    }, true);
    document.addEventListener('reset', event => {
        setTimeout(() => event.target.querySelectorAll(selector).forEach(update), 0);
    }, true);

    function init() {
        prepare(document);
        new MutationObserver(records => records.forEach(record => {
            if (record.type === 'childList') record.addedNodes.forEach(prepare);
            else if (record.target.matches(selector)) update(record.target);
            else prepare(record.target);
        })).observe(document.body, {
            childList: true, subtree: true, attributes: true,
            attributeFilter: ['type', 'min', 'max', 'step', 'required'],
        });
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
    else init();
})();
