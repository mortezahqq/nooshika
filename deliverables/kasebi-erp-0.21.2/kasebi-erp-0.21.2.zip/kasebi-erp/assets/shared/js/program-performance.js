(function($) {
    'use strict';
    const fa = value => Number(value || 0).toLocaleString('fa-IR', {maximumFractionDigits: 2});
    const el = (tag, cls, text) => { const node = document.createElement(tag); if (cls) node.className = cls; if (text !== undefined) node.textContent = text; return node; };
    const ajaxUrl = () => window.KERPData?.ajaxUrl || '';

    class Performance {
        constructor(root) { this.root = root; this.form = root.querySelector('[data-performance-form]'); this.content = root.querySelector('[data-performance-content]'); this.status = root.querySelector('[data-performance-status]'); this.controller = null; const topic = $(this.form.elements.term_id); if (typeof topic.select2 === 'function' && !topic.hasClass('select2-hidden-accessible')) topic.select2({dir: document.documentElement.dir === 'rtl' ? 'rtl' : 'ltr', width: '100%', minimumResultsForSearch: 0}); this.form.addEventListener('submit', e => { e.preventDefault(); this.load(); }); this.load(); }
        load() {
            if (this.controller) this.controller.abort(); this.controller = new AbortController();
            this.root.classList.add('is-loading'); this.status.hidden = false; this.status.className = 'kerp-performance__status'; this.status.textContent = 'در حال محاسبه گزارش…'; this.content.hidden = true;
            const body = new URLSearchParams(new FormData(this.form)); body.set('action', 'programs_student_performance'); body.set('customer_id', this.root.dataset.customer || '0'); body.set('nonce', this.root.dataset.nonce || '');
            fetch(ajaxUrl(), {method: 'POST', credentials: 'same-origin', body, signal: this.controller.signal}).then(r => r.json()).then(r => { if (!r || r.status !== 'success') throw new Error(r?.message || r?.msg || 'دریافت گزارش انجام نشد.'); this.render(r.data); }).catch(error => { if (error.name === 'AbortError') return; this.status.className = 'kerp-performance__status is-error'; this.status.textContent = error.message; }).finally(() => this.root.classList.remove('is-loading'));
        }
        render(data) {
            const categories = Array.isArray(data.categories) ? data.categories : [];
            if (!categories.length && !(data.current_exams || []).length && !(data.previous_exams || []).length) { this.content.replaceChildren(); this.status.hidden = false; this.status.textContent = 'برای این مبحث و بازه، نتیجه‌ای ثبت نشده است.'; return; }
            const caption = el('div', 'kerp-performance__caption'); caption.append(el('strong', '', data.focus_label || ''), el('span', '', `${data.current_label} در مقایسه با ${data.previous_label}`));
            const grid = el('div', 'kerp-performance__grid');
            grid.append(this.barCard('تعداد تست‌ها', 'تست', categories, 'tests_actual'), this.barCard('ساعات مطالعه', 'ساعت', categories, 'hours_actual'), this.scoreCard(data));
            this.content.replaceChildren(caption, grid); this.status.hidden = true; this.content.hidden = false;
        }
        barCard(title, unit, categories, key) {
            const card = el('section', 'kerp-performance__card'); const head = el('div', 'kerp-performance__card-head'); head.append(el('strong', '', title), el('small', '', unit));
            const max = Math.max(1, ...categories.flatMap(i => [Number(i.current?.[key] || 0), Number(i.previous?.[key] || 0)])); const plot = el('div', 'kerp-performance__bars');
            categories.forEach(item => { const col = el('div', 'kerp-performance__column'); const pair = el('div', 'kerp-performance__pair'); const current = Number(item.current?.[key] || 0), previous = Number(item.previous?.[key] || 0); const a = el('i', 'is-current'), b = el('i', 'is-previous'); a.style.height = `${Math.max(current ? 4 : 0, current / max * 100)}%`; b.style.height = `${Math.max(previous ? 4 : 0, previous / max * 100)}%`; pair.append(a, b); col.append(pair, el('span', '', item.name)); col.tabIndex = 0; col.title = `${item.name}\nبازه انتخابی: ${fa(current)} ${unit}\nدوره قبل: ${fa(previous)} ${unit}`; plot.append(col); });
            card.append(head, plot); return card;
        }
        scoreCard(data) {
            const card = el('section', 'kerp-performance__card is-wide'); const head = el('div', 'kerp-performance__card-head'); head.append(el('strong', '', 'روند نمرات آزمون'), el('small', '', 'نمره'));
            const current = data.current_exams || [], previous = data.previous_exams || []; const all = current.concat(previous); const max = Math.max(20, ...all.map(i => Number(i.score || 0))); const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg'); svg.setAttribute('viewBox', '0 0 600 180'); svg.setAttribute('class', 'kerp-performance__line');
            const draw = (items, cls) => { if (!items.length) return; const points = items.map((item, index) => `${items.length === 1 ? 300 : 25 + index * 550 / (items.length - 1)},${160 - Number(item.score || 0) / max * 135}`); const poly = document.createElementNS(svg.namespaceURI, 'polyline'); poly.setAttribute('points', points.join(' ')); poly.setAttribute('class', cls); svg.append(poly); points.forEach((point, index) => { const [x,y] = point.split(','); const dot = document.createElementNS(svg.namespaceURI, 'circle'); dot.setAttribute('cx', x); dot.setAttribute('cy', y); dot.setAttribute('r', '5'); dot.setAttribute('class', cls); const title = document.createElementNS(svg.namespaceURI, 'title'); title.textContent = `${items[index].date}: ${fa(items[index].score)}`; dot.append(title); svg.append(dot); }); };
            [25, 70, 115, 160].forEach(y => { const line = document.createElementNS(svg.namespaceURI, 'line'); line.setAttribute('x1','20'); line.setAttribute('x2','580'); line.setAttribute('y1',y); line.setAttribute('y2',y); line.setAttribute('class','grid'); svg.append(line); }); draw(previous, 'is-previous'); draw(current, 'is-current');
            card.append(head, svg); return card;
        }
    }
    const boot = scope => (scope || document).querySelectorAll('[data-program-performance]').forEach(root => { if (!root.dataset.performanceReady) { root.dataset.performanceReady = '1'; new Performance(root); } });
    $(document).ready(() => boot(document)); $(document).ajaxComplete(() => boot(document)); new MutationObserver(records => records.forEach(record => record.addedNodes.forEach(node => { if (node.nodeType === 1) boot(node.matches?.('[data-program-performance]') ? node.parentNode : node); }))).observe(document.documentElement, {childList:true, subtree:true});
})(jQuery);
