(function($) {
    'use strict';

    const faNumber = value => Number(value || 0).toLocaleString('fa-IR', {maximumFractionDigits: 2});
    const make = (tag, className, text) => {
        const node = document.createElement(tag);
        if (className) node.className = className;
        if (text !== undefined) node.textContent = text;
        return node;
    };

    function ajaxUrl() {
        return window.KERPData?.ajaxUrl || window.KERPProgramsPanel?.ajaxUrl || '';
    }

    class ProgramOverview {
        constructor(root) {
            this.root = root;
            this.form = root.querySelector('[data-overview-form]');
            this.chart = root.querySelector('[data-overview-chart]');
            this.status = root.querySelector('[data-overview-status]');
            this.summary = root.querySelector('[data-overview-summary]');
            this.taxonomy = root.querySelector('[data-overview-taxonomy]');
            this.level = root.querySelector('[data-overview-level]');
            this.controller = null;
            this.bind();
            this.updateLevels();
            this.load();
        }

        bind() {
            this.form.addEventListener('submit', event => { event.preventDefault(); this.load(); });
            this.taxonomy.addEventListener('change', () => { this.updateLevels(); this.load(); });
            this.level.addEventListener('change', () => this.load());
        }

        updateLevels() {
            const option = this.taxonomy.selectedOptions[0];
            const depth = Math.max(1, Number(option?.dataset.depth || 1));
            const selected = Math.min(depth, Math.max(1, Number(this.level.value || this.level.dataset.selected || 1)));
            this.level.replaceChildren();
            for (let i = 1; i <= depth; i++) {
                const item = document.createElement('option');
                item.value = String(i);
                item.textContent = i === 1 ? 'سطح ۱ — ریشه‌ها' : `سطح ${faNumber(i)}`;
                item.selected = i === selected;
                this.level.appendChild(item);
            }
            delete this.level.dataset.selected;
        }

        load() {
            if (this.controller) this.controller.abort();
            this.controller = new AbortController();
            this.root.classList.add('is-loading');
            this.status.hidden = false;
            this.status.className = 'kerp-program-overview__status';
            this.status.textContent = 'در حال محاسبه نمای کلی…';
            this.chart.hidden = true;
            const body = new URLSearchParams(new FormData(this.form));
            body.set('action', 'programs_overview');
            body.set('nonce', this.root.dataset.nonce || '');
            body.set('context', this.root.dataset.context || 'customer');
            body.set('customer_id', this.root.dataset.customer || '0');
            body.set('template_id', this.root.dataset.template || '0');
            fetch(ajaxUrl(), {method: 'POST', credentials: 'same-origin', body, signal: this.controller.signal})
                .then(response => response.json())
                .then(response => {
                    if (!response || response.status !== 'success' || !response.data) {
                        throw new Error(response?.message || response?.msg || 'دریافت نمودار انجام نشد.');
                    }
                    this.render(response.data);
                })
                .catch(error => {
                    if (error.name === 'AbortError') return;
                    this.status.hidden = false;
                    this.status.className = 'kerp-program-overview__status is-error';
                    this.status.textContent = error.message || 'ارتباط با سرور برقرار نشد.';
                    this.summary.replaceChildren();
                })
                .finally(() => this.root.classList.remove('is-loading'));
        }

        render(data) {
            const groups = Array.isArray(data.groups) ? data.groups : [];
            this.summary.replaceChildren(
                this.summaryItem(faNumber(data.task_count), 'آیتم'),
                this.summaryItem(faNumber(groups.length), `گروه سطح ${faNumber(data.level)}`),
            );
            if (!groups.length) {
                this.chart.replaceChildren();
                this.chart.hidden = true;
                this.status.hidden = false;
                this.status.className = 'kerp-program-overview__status is-empty';
                this.status.textContent = `در ${data.range_label || 'این بازه'} داده‌ای برای نمایش وجود ندارد.`;
                return;
            }
            const fragment = document.createDocumentFragment();
            const caption = make('div', 'kerp-program-overview__caption');
            caption.append(make('strong', '', data.range_label || ''), make('span', '', `${data.taxonomy_label || 'مباحث'} · سطح ${faNumber(data.level)}`));
            fragment.appendChild(caption);
            const series = new Map();
            groups.forEach(group => (group.metrics || []).forEach(metric => {
                if (!series.has(metric.key)) {
                    series.set(metric.key, {key: metric.key, type: metric.type, unit: metric.unit, items: []});
                }
                series.get(metric.key).items.push({name: group.name, metric});
            }));
            const charts = make('div', 'kerp-program-overview__series-list');
            series.forEach((item, seriesIndex) => charts.appendChild(this.series(item, Boolean(data.has_actual), seriesIndex)));
            fragment.appendChild(charts);
            this.chart.replaceChildren(fragment);
            this.status.hidden = true;
            this.chart.hidden = false;
        }

        summaryItem(value, label) {
            const node = make('span');
            node.append(make('strong', '', value), document.createTextNode(' ' + label));
            return node;
        }

        series(series, hasActual, seriesIndex) {
            const section = make('section', 'kerp-program-overview__series color-' + (seriesIndex % 6));
            const head = make('div', 'kerp-program-overview__series-head');
            head.append(make('strong', '', series.type), make('span', '', series.unit));
            const plot = make('div', 'kerp-program-overview__plot');
            series.items.forEach(item => plot.appendChild(this.column(item.name, item.metric, hasActual)));
            section.append(head, plot);
            return section;
        }

        column(name, metric, hasActual) {
            const column = make('div', 'kerp-program-overview__column');
            column.tabIndex = 0;
            const bars = make('div', 'kerp-program-overview__bars');
            const scale = Math.max(0, Number(metric.scale || 0));
            const targetHeight = scale > 0 ? Math.max(2, Math.min(100, Number(metric.target || 0) / scale * 100)) : 0;
            const actualHeight = scale > 0 ? Math.max(Number(metric.actual || 0) > 0 ? 2 : 0, Math.min(100, Number(metric.actual || 0) / scale * 100)) : 0;
            const target = make('span', 'kerp-program-overview__bar is-target');
            target.style.height = targetHeight + '%';
            bars.appendChild(target);
            if (hasActual) {
                const actual = make('span', 'kerp-program-overview__bar is-actual');
                actual.style.height = actualHeight + '%';
                bars.appendChild(actual);
            }
            const label = make('span', 'kerp-program-overview__column-label', name);
            const tooltip = make('span', 'kerp-program-overview__tooltip');
            tooltip.append(make('strong', '', name));
            if (hasActual) {
                tooltip.append(
                    make('span', '', `هدف: ${faNumber(metric.target)} ${metric.unit}`),
                    make('span', 'is-actual', `انجام‌شده: ${faNumber(metric.actual)} ${metric.unit}`),
                    make('small', '', metric.achievement === null ? 'بدون هدف عددی' : `${faNumber(metric.achievement)}٪ تحقق`),
                );
            } else {
                tooltip.append(make('span', '', `${faNumber(metric.target)} ${metric.unit}`));
            }
            column.setAttribute('aria-label', tooltip.textContent);
            column.append(bars, label, tooltip);
            const placeTooltip = () => {
                const rect = column.getBoundingClientRect();
                const width = Math.max(120, tooltip.offsetWidth || 120);
                const half = width / 2;
                const center = Math.min(window.innerWidth - half - 8, Math.max(half + 8, rect.left + rect.width / 2));
                tooltip.style.left = center + 'px';
                tooltip.style.top = Math.max(8, rect.top - tooltip.offsetHeight - 7) + 'px';
            };
            column.addEventListener('pointerenter', placeTooltip);
            column.addEventListener('pointermove', placeTooltip);
            column.addEventListener('focus', placeTooltip);
            return column;
        }
    }

    function boot(scope) {
        (scope || document).querySelectorAll('[data-program-overview]').forEach(root => {
            if (!root.dataset.overviewReady) { root.dataset.overviewReady = '1'; new ProgramOverview(root); }
        });
    }
    $(document).ready(() => boot(document));
    $(document).ajaxComplete(() => boot(document));
    new MutationObserver(records => records.forEach(record => record.addedNodes.forEach(node => {
        if (node.nodeType === 1) boot(node.matches?.('[data-program-overview]') ? node.parentNode : node);
    }))).observe(document.documentElement, {childList: true, subtree: true});
})(jQuery);
