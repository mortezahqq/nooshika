$(document).on('shown.bs.tab', '.kerp-payment-settings-tabs .nav-link', function() {
    const kerpPaymentSettingsTab = ($(this).attr('href') || '').replace('#payment-pane-', '');
    $(this).closest('.modal_form').find('[data-for="active_tab"]').val(kerpPaymentSettingsTab);
});

function kerp_payment_number(value) {
    const raw = String(value ?? '').trim()
        .replace(/[۰-۹]/g, digit => '۰۱۲۳۴۵۶۷۸۹'.indexOf(digit))
        .replace(/[٠-٩]/g, digit => '٠١٢٣٤٥٦٧٨٩'.indexOf(digit)).replace(/[,٬]/g, '');
    return raw && /^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?$/i.test(raw) ? Number(raw) : NaN;
}
$(document).on('click', '.kerp-payment-send-sms', function() {
    const $button = $(this), orderId = $button.attr('data-order-id');
    if ($button.prop('disabled')) return;
    const $buttons = $('.kerp-payment-send-sms').filter(function() { return $(this).attr('data-order-id') === orderId; });
    const $label = $button.find('span'), original = $label.text();
    $buttons.prop('disabled', true).attr('aria-busy', 'true');
    $label.text('در حال ارسال…');
    $.post(ajax_url, {action: 'payments_send_sms', order_id: orderId, payment_nonce: $button.attr('data-payment-nonce')})
        .done(function(response) {
            response = response && typeof response === 'object' ? response : {};
            NioApp.Toast($('<div>').text(response.message || response.msg || 'پاسخ سرویس پیامک معتبر نیست.').html(), response.status === 'success' ? 'success' : 'error', {position: 'top-right'});
        }).fail(function() {
            NioApp.Toast('ارتباط قطع شد؛ گزارش سرویس پیامک را پیش از ارسال دوباره بررسی کنید.', 'error', {position: 'top-right'});
        }).always(function() {
            $buttons.prop('disabled', false).removeAttr('aria-busy');
            $label.text(original);
        });
});
function kerp_payment_update_progress(area) {
    const $area = $(area), payable = kerp_payment_number($area.attr('data-payable'));
    const mixed = $area.closest('.modal_form').find('[data-for="payment_method"]').val() === 'kerp_mixed';
    $area.find('.kerp-payment-receipts').each(function() {
        const $section = $(this), $summary = $section.find('.kerp-payment-progress');
        $summary.toggleClass('d-none', mixed && $section.attr('data-method') === 'kerp_cheque');
        $summary.find('.kerp-payment-progress-label').text(mixed ? 'مجموع رسیدهای کارت و چک‌ها' : 'مجموع مبالغ واریزی');
        const decimals = Number($summary.attr('data-decimals')) || 0, scale = Math.pow(10, decimals);
        const format = value => value.toLocaleString('fa-IR', {maximumFractionDigits: decimals});
        let total = 0, invalid = false;
        const $sources = mixed ? $area.find('.kerp-payment-receipts[data-method="kerp_card"],.kerp-payment-receipts[data-method="kerp_cheque"]') : $section;
        $sources.find('.repeater_rows input[data-for$="[amount]"]').each(function() {
            if (this.disabled || !String($(this).val() || '').trim()) return;
            const amount = kerp_payment_number($(this).val());
            if (!Number.isFinite(amount) || amount <= 0) { invalid = true; return; }
            total += Math.round(amount * scale);
        });
        if (!Number.isSafeInteger(total)) { invalid = true; total = 0; }
        const target = Math.round(payable * scale), ready = Number.isSafeInteger(target) && target > 0;
        const excess = ready && total > target, complete = ready && total === target && !invalid;
        const percent = ready ? Math.min(100, total / target * 100) : 0;
        const currency = $area.attr('data-currency') || '';
        const message = invalid ? 'مبلغ هر ردیف باید عددی معتبر و بیشتر از صفر باشد.'
            : !ready ? ($area.attr('data-progress-message') || 'ابتدا مبلغ قابل پرداخت را مشخص کنید.')
            : excess ? format((total - target) / scale) + ' ' + currency + ' بیشتر از مبلغ قابل پرداخت'
            : complete ? 'مجموع واریزی‌ها با مبلغ قابل پرداخت برابر است.'
            : total === 0 ? 'هنوز مبلغی وارد نشده؛ ' + format(target / scale) + ' ' + currency + ' باقی مانده'
            : format((target - total) / scale) + ' ' + currency + ' باقی مانده';
        const state = invalid || excess ? 'danger' : complete ? 'success' : total && ready ? 'warning' : 'primary';
        $summary.find('.kerp-payment-progress-total').html(kerp_price_html(total / scale, currency) + (ready ? ' از ' + kerp_price_html(target / scale, currency) : ''));
        const $note = $summary.find('.kerp-payment-progress-note');
        const noteAmount = excess ? (total - target) / scale : ready && !complete ? (target - total) / scale : null;
        $note.empty();
        if (!invalid && noteAmount !== null) {
            if (total === 0) $note.append(document.createTextNode('هنوز مبلغی وارد نشده؛ '));
            $note.append($('<span>').html(kerp_price_html(noteAmount, currency)), document.createTextNode(excess ? ' بیشتر از مبلغ قابل پرداخت' : ' باقی مانده'));
        } else $note.text(message);
        $note.toggleClass('text-danger', state === 'danger').toggleClass('text-success', complete).toggleClass('text-soft', state !== 'danger' && !complete);
        $summary.find('[role="progressbar"]').attr({'aria-valuenow': percent, 'aria-valuetext': message});
        $summary.find('.progress-bar').removeClass('bg-primary bg-success bg-warning bg-danger').addClass('bg-' + state).css('width', percent + '%');
    });
}
$(document).on('input change', '.kerp-payment-receipts input[data-for$="[amount]"]', function() {
    kerp_payment_update_progress($(this).closest('.kerp-payment-fields'));
});
function kerp_payment_schedule(schedule, currency) {
    const $section = $('<section class="kerp-payment-schedule" aria-label="برنامه پرداخت اقساط">');
    $section.append($('<div class="kerp-payment-schedule-head">').append($('<strong>').text('برنامه پرداخت'), $('<span>').text(schedule.length.toLocaleString('fa-IR') + ' قسط')));
    const $table = $('<table><thead><tr><th scope="col">مرحله</th><th scope="col">مبلغ قسط</th><th scope="col">سررسید</th></tr></thead><tbody></tbody></table>');
    schedule.forEach((row, index) => {
        const $stage = $('<td class="kerp-schedule-stage">').append($('<span class="kerp-schedule-number">').text(Number(row.stage).toLocaleString('fa-IR')), $('<div>').append($('<strong>').text('قسط ' + Number(row.stage).toLocaleString('fa-IR')), index === 0 ? $('<small>').text('پرداخت این مرحله') : ''));
        const $amount = $('<td class="kerp-schedule-amount" data-label="مبلغ قسط">').append($('<strong>').html(kerp_price_html(row.amount, currency)));
        const $due = $('<td class="kerp-schedule-due" data-label="سررسید">').attr('data-days', row.days).append($('<div class="align-center">').append($('<em class="icon ni ni-calendar" aria-hidden="true">'), $('<span>').text(Number(row.days) === 0 ? 'اکنون' : kerp_payment_date(row.date))));
        $('<tr>').toggleClass('is-first', index === 0).append($stage, $amount, $due).appendTo($table.find('tbody'));
    });
    return $section.append($table, $('<p class="kerp-schedule-note">').text('در این مرحله فقط مبلغ قسط اول دریافت می‌شود. مبالغ و تاریخ‌ها هنگام ثبت سفارش نهایی می‌شوند.'));
}
const kerp_payment_date = value => {
    try { return new Intl.DateTimeFormat('fa-IR-u-ca-persian', {year: 'numeric', month: 'long', day: 'numeric', timeZone: 'Asia/Tehran'}).format(new Date(value)); }
    catch (e) { return value; }
};
function kerp_payment_payload($form) {
    const data = {};
    $form.find('input[data-for],select[data-for],textarea[data-for]').each(function() {
        if (this.disabled || ($(this).is(':checkbox,:radio') && !this.checked)) return;
        setNestedValue(data, $(this).attr('data-for'), $(this).val());
    });
    return data;
}
function kerp_payment_initialize() {
    $('.kerp-payment-date').not('[data-formatted]').each(function() { $(this).text(kerp_payment_date(this.dateTime)).attr('data-formatted', '1'); });
    $('.kerp-payment-fields').each(function() {
        const $area = $(this), $form = $area.closest('.modal_form');
        kerp_payment_update_progress($area);
        if ($area.data('ready')) return;
        $area.data('ready', true);
        const $method = $form.find('[data-for="payment_method"]');
        function methodVisible(section) {
            const selected = $method.val(), part = $(section).attr('data-method');
            return part === selected || (selected === 'kerp_mixed' && ['kerp_card', 'kerp_cheque'].includes(part));
        }
        function method() {
            $area.find('.kerp-payment-mixed-help').toggleClass('d-none', $method.val() !== 'kerp_mixed');
            $area.find('.kerp-payment-receipts').each(function() { $(this).toggleClass('d-none', !methodVisible(this)); });
            kerp_payment_update_progress($area);
        }
        $method.on('change.payments', method); method();
        if ($area.attr('data-new') !== '1') return;
        const $type = $form.find('[data-for="payment_type"]'), $plan = $form.find('[data-for="payment_plan"]');
        const $preview = $area.find('.kerp-payment-preview'), $button = $form.find('.submit_modal_form');
        let version = 0, timer, total = null;
        function withoutPayment() {
            return $form.attr('data-action') === 'payments_create_order'
                && $form.find('[data-for="registration_mode"]').val() !== 'proforma'
                && $method.val() === 'kerp_none';
        }
        function cash() {
            const orderTotal = total ?? kerp_payment_number($form.find('.order_total_final').attr('data-price-value') ?? $form.find('.order_total_final .final_price .price_number').text());
            const deposit = $type.val() === 'deposit';
            const amount = deposit ? kerp_payment_number($form.find('[data-for="deposit_amount"]').val()) : orderTotal;
            $area.attr('data-payable', amount).removeAttr('data-progress-message');
            $preview.empty().append($('<strong>').append(document.createTextNode($form.find('[data-for="registration_mode"]').val() === 'proforma' ? 'مبلغ پیش‌فاکتور: ' : 'مبلغ قابل پرداخت اکنون: '), $('<span>').html(kerp_price_html(amount, $area.attr('data-currency')))));
            if (deposit) {
                const valid = Number.isFinite(amount) && amount > 0 && amount < orderTotal;
                $button.prop('disabled', !valid);
                $preview.append($('<p class="mt-2 mb-0">').toggleClass('text-danger', !valid).html(valid ? 'مانده پس از وصول پیش‌پرداخت: ' + kerp_price_html(orderTotal - amount, $area.attr('data-currency')) : 'پیش‌پرداخت باید بیشتر از صفر و کمتر از مبلغ کل سفارش باشد.'));
            }
            kerp_payment_update_progress($area);
        }
        function refresh() {
            clearTimeout(timer); const current = ++version;
            const noPayment = withoutPayment();
            $type.prop('disabled', noPayment).closest('.meta-field-row').toggleClass('d-none', noPayment);
            $plan.prop('disabled', noPayment);
            $form.find('[data-for="deposit_amount"]').prop('disabled', noPayment);
            const installment = $type.val() === 'installment';
            $area.find('.kerp-payment-deposit').toggleClass('d-none', noPayment || $type.val() !== 'deposit');
            $area.find('.kerp-payment-plan').toggleClass('d-none', noPayment || !installment);
            if (noPayment) {
                $button.prop('disabled', false);
                $area.removeAttr('data-payable data-progress-message');
                $preview.empty().append($('<p class="text-soft mb-0">').text('سفارش بدون ثبت پرداخت، رسید یا قرارداد اقساط مستقیماً تکمیل می‌شود.'));
                return;
            }
            $button.prop('disabled', installment);
            if (!installment) { cash(); return; }
            $area.removeAttr('data-payable').attr('data-progress-message', 'در حال دریافت مبلغ قابل پرداخت…');
            kerp_payment_update_progress($area);
            $preview.text('در حال دریافت برنامه پرداخت…');
            timer = setTimeout(function() {
                const data = kerp_payment_payload($form); data.action = 'payments_preview';
                $.post(ajax_url, data).done(function(response) {
                    if (current !== version || !$area[0].isConnected) return;
                    const selected = String($plan.val() || '');
                    $plan.empty().append(new Option('انتخاب پلن', ''));
                    (response.plans || []).forEach(p => $plan.append(new Option(p.text, p.id)));
                    const found = (response.plans || []).some(p => String(p.id) === selected);
                    $plan.val(found ? selected : '').trigger('change.select2');
                    if (!found && response.plans && response.plans.length) { $plan.val(String(response.plans[0].id)).trigger('change.select2'); refresh(); return; }
                    $preview.empty();
                    if (response.status !== 'success' || response.error) { $preview.append($('<div class="alert alert-warning">').text(response.error || response.message || response.msg || 'دریافت برنامه پرداخت ناموفق بود.')); $area.attr('data-progress-message', 'مبلغ قابل پرداخت مشخص نیست؛ پلن اقساط را بررسی کنید.'); kerp_payment_update_progress($area); return; }
                    $preview.append(kerp_payment_schedule(response.schedule || [], response.currency));
                    proforma();
                    $area.attr('data-payable', response.schedule && response.schedule.length ? response.schedule[0].amount : '').removeAttr('data-progress-message');
                    kerp_payment_update_progress($area);
                    $button.prop('disabled', !(response.schedule || []).length);
                }).fail(function() { if (current === version && $area[0].isConnected) { $preview.text('دریافت برنامه پرداخت ناموفق بود؛ دوباره پلن را انتخاب کنید.'); $area.attr('data-progress-message', 'دریافت مبلغ ناموفق بود؛ دوباره پلن را انتخاب کنید.'); kerp_payment_update_progress($area); } });
            }, 300);
        }
        const $registration = $form.find('[data-for="registration_mode"]');
        function proforma() {
            const draft = $registration.val() === 'proforma';
            $area.find('.kerp-payment-mixed-help').toggleClass('d-none', draft || $method.val() !== 'kerp_mixed');
            $area.find('.kerp-proforma-method').toggleClass('d-none', draft);
            $method.prop('disabled', draft);
            $area.find('.kerp-payment-receipts').each(function() {
                $(this).toggleClass('d-none', draft || !methodVisible(this));
            });
            $area.find('.kerp-schedule-stage small').text(draft ? 'پس از شروع پرداخت' : 'پرداخت این مرحله');
            if (draft) $area.find('.kerp-schedule-due').each(function() { const days = Number($(this).attr('data-days')); $(this).find('span').text(days === 0 ? 'زمان شروع پرداخت' : days.toLocaleString('fa-IR') + ' روز پس از شروع پرداخت'); });
            $button.find('span').text(draft ? 'ذخیره پیش‌فاکتور' : withoutPayment() ? 'ثبت و تکمیل سفارش' : 'ثبت سفارش');
            $area.find('.kerp-schedule-note').text(draft ? 'این برنامه موقت است؛ تا شروع پرداخت، قسط و پیگیری ساخته نمی‌شود. سررسیدها از زمان شروع پرداخت محاسبه می‌شوند.' : 'در این مرحله فقط مبلغ قسط اول دریافت می‌شود. مبالغ و تاریخ‌ها هنگام ثبت سفارش نهایی می‌شوند.');
        }
        $registration.on('change.payments', function() { proforma(); refresh(); });
        $method.on('change.proforma', function() { proforma(); refresh(); });
        proforma();
        $type.on('change.payments', refresh); $plan.on('change.payments', refresh);
        $form.on('input.payments change.payments', '[data-for="deposit_amount"]', refresh);
        $form.on('kerp_order_totals_calculated.payments', function(event, values) { total = Number(values.final_total); refresh(); });
        $form.on('change.payments', '[data-for="customer_id"]', refresh);
        refresh();
    });
}
$(document).on('click', '.kerp-payment-review', function() { $('#payment-review-ids').val($(this).attr('data-payment-id')); });
$(document).on('shown.bs.modal', kerp_payment_initialize);
$(function() {
    kerp_payment_initialize();
    let scheduled = false;
    new MutationObserver(function(changes) {
        if (!changes.some(change => Array.from(change.addedNodes).concat(Array.from(change.removedNodes)).some(node => node.nodeType === 1 && (node.matches('.kerp-payment-fields,.kerp-payment-date,.repeater_row') || node.querySelector('.kerp-payment-fields,.kerp-payment-date,.repeater_row'))))) return;
        if (scheduled) return; scheduled = true;
        setTimeout(function() { scheduled = false; kerp_payment_initialize(); if (NioApp.Dropzone && NioApp.Dropzone.init) NioApp.Dropzone.init(); }, 0);
    }).observe(document.body, {childList: true, subtree: true});
});
