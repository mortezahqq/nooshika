// Modules load independently; blocks sharing one module reuse its request and cache.
var kerpDashboardRequests = new WeakMap();

async function kerpDashboardLoad() {
    var root = document.querySelector('.kerp-dashboard[data-dashboard-nonce]');
    if (!root) return;
    var requests = kerpDashboardRequests.get(root);
    if (!requests) { requests = new Map(); kerpDashboardRequests.set(root, requests); }
    var nodes = Array.from(root.querySelectorAll('[data-dashboard-pending]:not([data-dashboard-error])'));
    var modules = Array.from(new Set(nodes.map(function(node) { return node.closest('[data-dashboard-module]').dataset.dashboardModule; })));
    await Promise.allSettled(modules.map(function(module) {
        if (!requests.has(module)) {
            var request = Promise.resolve().then(function() { return kerpDashboardLoadModule(root, module); });
            requests.set(module, request);
            request.finally(function() { if (requests.get(module) === request) requests.delete(module); }).catch(function() {});
        }
        return requests.get(module);
    }));
}

async function kerpDashboardLoadModule(root, module) {
    var attempts = {};
    var progress = {};
    while (root.isConnected) {
        var targets = Array.from(root.querySelectorAll('[data-dashboard-pending]:not([data-dashboard-error])')).filter(function(node) {
            return node.closest('[data-dashboard-module]').dataset.dashboardModule === module;
        });
        if (!targets.length) return;
        if (document.hidden) { await new Promise(function(resolve) { setTimeout(resolve, 1000); }); continue; }
        var delay;
        try {
            if ((attempts[module] = (attempts[module] || 0) + 1) > 1200) throw new Error('برای ادامهٔ آماده‌سازی اطلاعات دوباره تلاش کنید.');
            var response = await $.ajax({ url: ajax_url, method: 'POST', dataType: 'json', ajax_search: true, timeout: 25000, data: { action: 'dashboard_blocks', nonce: root.dataset.dashboardNonce, module: module } });
            if (!root.isConnected) return;
            if (response.status === 'pending') {
                var detail = response.progress || {};
                var checkpoint = progress[module] || { batches: 0, time: Date.now() };
                var batches = Number(detail.batches) || 0;
                if (batches > checkpoint.batches) checkpoint = { batches: batches, time: Date.now() };
                progress[module] = checkpoint;
                if (Date.now() - checkpoint.time > 180000) throw new Error('آماده‌سازی اطلاعات پیشرفت نکرده است؛ دوباره تلاش کنید.');
                var processed = Number(detail.processed) || 0;
                var prepared = Number(detail.prepared) || 0;
                targets.forEach(function(node) {
                    var caption = node.querySelector('p');
                    if (caption && processed > 0) caption.textContent = 'در حال آماده‌سازی اطلاعات؛ ' + processed.toLocaleString('fa-IR') + ' سفارش بررسی شد…';
                    if (caption && prepared > 0) caption.textContent = 'تکمیل اولیه آمار؛ ' + prepared.toLocaleString('fa-IR') + ' سفارش آماده و ' + processed.toLocaleString('fa-IR') + ' سفارش بررسی شد…';
                });
                delay = detail.phase === 'locked' ? 1500 : 150;
                await new Promise(function(resolve) { setTimeout(resolve, delay); });
                continue;
            }
            if (response.status === 'unavailable') {
                targets.forEach(function(node) { node.closest('.kerp-dashboard-column').remove(); });
                return;
            }
            if (response.status !== 'success' || !response.blocks) throw new Error(response.message || 'دریافت اطلاعات انجام نشد.');
            targets.forEach(function(node) {
                var section = node.closest('[data-dashboard-module]');
                var id = section.id.replace(/^kerp-dashboard-/, '');
                if (!Object.prototype.hasOwnProperty.call(response.blocks, id)) throw new Error('پاسخ این بخش کامل نیست.');
                var html = response.blocks[id];
                if (!html.trim()) { node.closest('.kerp-dashboard-column').remove(); return; }
                $(node).html(html);
                node.removeAttribute('data-dashboard-pending');
                node.setAttribute('aria-busy', 'false');
            });
            activate_charts();
            NioApp.BS.init();
            return;
        } catch (error) {
            if (!root.isConnected) return;
            targets.forEach(function(node) {
                node.setAttribute('data-dashboard-error', '1');
                node.setAttribute('aria-busy', 'false');
                $(node).empty().append($('<p class="sub-text" role="status"></p>').text(error.responseJSON && error.responseJSON.message || error.message || 'دریافت اطلاعات انجام نشد.'))
                    .append($('<button type="button" class="btn btn-sm btn-outline-primary kerp-dashboard-retry">تلاش دوباره</button>'));
            });
            return;
        }
    }
}

$(document).on('click', '.kerp-dashboard-retry', function() {
    var root = this.closest('.kerp-dashboard');
    var module = this.closest('[data-dashboard-module]').dataset.dashboardModule;
    root.querySelectorAll('[data-dashboard-error]').forEach(function(node) {
        if (node.closest('[data-dashboard-module]').dataset.dashboardModule !== module) return;
        node.removeAttribute('data-dashboard-error');
        node.setAttribute('aria-busy', 'true');
        $(node).text('در حال آماده‌سازی اطلاعات…');
    });
    kerpDashboardLoad();
});

// The customer period picker can also encounter an expired snapshot.
function kerpDashboardSeriesRequest(data, element) {
    var deferred = $.Deferred();
    var attempts = 0;
    function run() {
        if (!element.isConnected || ++attempts > 1200) { deferred.reject(); return; }
        $.ajax({ url: ajax_url, method: 'POST', dataType: 'json', ajax_search: true, timeout: 25000, data: data }).done(function(response) {
            if (response.status === 'pending') { setTimeout(run, 500); return; }
            if (response.status !== 'success') { deferred.reject(); return; }
            if (element.isConnected) deferred.resolve(response); else deferred.reject();
        }).fail(function() { deferred.reject(); });
    }
    run();
    return deferred.promise();
}

$(function() { kerpDashboardLoad(); });
