// This nested repeater uses its own controls and template token so adding a button
// or a message never reindexes or removes the other repeater's rows.
function kerpButtonSmsCondition($row) {
    const field = String($row.find('[data-for$="[condition_field]"]').val() || '');
    const $root = $row.closest('.kerp-button-sms');
    let options = {};
    try { options = JSON.parse($root.attr('data-condition-options') || '{}'); } catch (_) {}
    const active = field !== '' && field !== '0' && Object.prototype.hasOwnProperty.call(options, field);
    const values = active && Array.isArray(options[field]) ? options[field] : [];
    const $value = $row.find('[data-for$="[condition_value]"]');
    $value.empty().append(new Option(values.length ? 'انتخاب مقدار شرط' : 'مقداری برای این فیلد ثبت نشده است', ''));
    values.forEach(function (value) { $value.append(new Option(String(value), String(value))); });
    $value.prop('disabled', !active).val('').trigger('change');
    $row.find('.kerp-button-sms-condition-value').toggleClass('d-none', !active);
}
$(document).on('change', '.kerp-button-sms-row [data-for$="[condition_field]"]', function () {
    kerpButtonSmsCondition($(this).closest('.kerp-button-sms-row'));
});
$(document).on('click', '.kerp-button-sms-add', function (event) {
    event.preventDefault();
    const $kerpSms = $(this).closest('.kerp-button-sms');
    const $kerpSmsRows = $kerpSms.children('.kerp-button-sms-rows');
    if ($kerpSmsRows.children().length >= 20) {
        NioApp.Toast('حداکثر ۲۰ پیامک برای هر دکمه تعریف کنید.', 'warning', {position: 'top-right'});
        return;
    }
    const kerpSmsIndex = Number($kerpSms.attr('data-next-index')) || 0;
    const kerpSmsTemplate = $kerpSms.children('template')[0];
    if (!kerpSmsTemplate) return;
    $kerpSmsRows.append(kerpSmsTemplate.innerHTML.replaceAll('__SMS_INDEX__', String(kerpSmsIndex)));
    $kerpSms.attr('data-next-index', kerpSmsIndex + 1);
    NioApp.Select2($kerpSmsRows.children().last().find('.js-select2'));
    $kerpSmsRows.children().last().find('input').first().trigger('focus');
});
$(document).on('click', '.kerp-button-sms-remove', function (event) {
    event.preventDefault();
    if (window.bootstrap && bootstrap.Tooltip) {
        const kerpSmsTooltip = bootstrap.Tooltip.getInstance(this);
        if (kerpSmsTooltip) kerpSmsTooltip.dispose();
    }
    const $kerpSmsRow = $(this).closest('.kerp-button-sms-row');
    if ($kerpSmsRow.siblings().length) $kerpSmsRow.remove();
    else {
        $kerpSmsRow.find('input, textarea, select').val('').trigger('change');
        kerpButtonSmsCondition($kerpSmsRow);
    }
});
