const taxonomyPickerNormalize = value => String(value || '').
    toLowerCase().
    replace(/ي/g, 'ی').
    replace(/ك/g, 'ک').
    replace(/[\u064b-\u065f\u200c]/g, '').
    trim();

function taxonomyPickerSetBranch($node, open) {
    const $toggle = $node.children('.kerp-taxonomy-picker__row').find('.kerp-taxonomy-picker__toggle').first();
    const $branch = $node.children('.kerp-taxonomy-picker__branches');
    if (!$branch.length) {
        return;
    }
    $toggle.attr('aria-expanded', String(open)).find('.icon').
        toggleClass('ni-chevron-down', open).
        toggleClass('ni-chevron-left', !open);
    $branch.prop('hidden', !open);
}

function taxonomyPickerSync(picker) {
    const $picker = $(picker);
    const $select = $picker.find('.kerp-taxonomy-picker__select').first();
    const selected = new Set(($select.val() || []).map(String));
    $picker.find('.kerp-taxonomy-picker__check').each(function() {
        const checked = selected.has(String(this.value));
        $(this).prop('checked', checked).closest('.kerp-taxonomy-picker__row').toggleClass('is-selected', checked);
    });
    const $summary = $picker.find('.kerp-taxonomy-picker__selected').empty();
    $select.find('option:selected').each(function() {
        const $node = $picker.find(`.kerp-taxonomy-picker__node[data-node="${this.value}"]`).first();
        $('<button type="button" class="kerp-taxonomy-picker__chip">').
            attr('data-remove', this.value).
            attr('title', $node.attr('data-path') || this.textContent).
            append($('<span>').text(this.textContent), '<em class="icon ni ni-cross"></em>').
            appendTo($summary);
    });
    if (!selected.size) {
        $('<span class="kerp-taxonomy-picker__placeholder">هنوز مبحثی انتخاب نشده است.</span>').appendTo($summary);
    }
    $picker.find('.kerp-taxonomy-picker__count').text(selected.size.toLocaleString('fa-IR') + ' انتخاب');
}

function taxonomyPickerFilter(picker) {
    const $picker = $(picker);
    const query = taxonomyPickerNormalize($picker.find('.kerp-taxonomy-picker__search').val());
    const $nodes = $picker.find('.kerp-taxonomy-picker__node');
    let matches = 0;
    if (!query) {
        $nodes.prop('hidden', false);
        $nodes.each(function() {
            const $node = $(this);
            const open = $node.children('.kerp-taxonomy-picker__row').find('.kerp-taxonomy-picker__toggle').first().attr('aria-expanded') === 'true';
            $node.children('.kerp-taxonomy-picker__branches').prop('hidden', !open);
        });
    } else {
        $nodes.prop('hidden', true);
        $nodes.each(function() {
            const $node = $(this);
            if (!taxonomyPickerNormalize($node.attr('data-search')).includes(query)) {
                return;
            }
            matches++;
            $node.prop('hidden', false);
            $node.parentsUntil($picker.find('.kerp-taxonomy-picker__tree'), '.kerp-taxonomy-picker__node').each(function() {
                $(this).prop('hidden', false).children('.kerp-taxonomy-picker__branches').prop('hidden', false);
            });
        });
    }
    $picker.find('.kerp-taxonomy-picker__empty').prop('hidden', !query || matches > 0);
}

$(document).on('change', '.kerp-taxonomy-picker__select', function() {
    taxonomyPickerSync($(this).closest('.kerp-taxonomy-picker'));
});

$(document).on('change', '.kerp-taxonomy-picker__check', function() {
    const $picker = $(this).closest('.kerp-taxonomy-picker');
    const $select = $picker.find('.kerp-taxonomy-picker__select').first();
    $select.find('option').filter((_, option) => String(option.value) === String(this.value)).prop('selected', this.checked);
    $select.trigger('change');
});

$(document).on('click', '.kerp-taxonomy-picker__toggle', function() {
    const $node = $(this).closest('.kerp-taxonomy-picker__node');
    taxonomyPickerSetBranch($node, $(this).attr('aria-expanded') !== 'true');
});

$(document).on('input', '.kerp-taxonomy-picker__search', function() {
    taxonomyPickerFilter($(this).closest('.kerp-taxonomy-picker'));
});

$(document).on('click', '.kerp-taxonomy-picker__clear', function() {
    $(this).closest('.kerp-taxonomy-picker').find('.kerp-taxonomy-picker__select').val([]).trigger('change');
});

$(document).on('click', '.kerp-taxonomy-picker__chip', function() {
    const $picker = $(this).closest('.kerp-taxonomy-picker');
    const $select = $picker.find('.kerp-taxonomy-picker__select');
    $select.find('option').filter((_, option) => String(option.value) === String(this.dataset.remove)).prop('selected', false);
    $select.trigger('change');
});

$(document).on('click', '.kerp-taxonomy-picker__expand', function() {
    const $picker = $(this).closest('.kerp-taxonomy-picker');
    const open = this.dataset.open === '1';
    $picker.find('.kerp-taxonomy-picker__node').each(function() { taxonomyPickerSetBranch($(this), open); });
    this.dataset.open = open ? '0' : '1';
    $(this).text(open ? 'بستن همه' : 'بازکردن همه');
});

$(document).on('shown.bs.modal', '.modal', function() {
    $(this).find('.kerp-taxonomy-picker').each(function() {
        taxonomyPickerSync(this);
        taxonomyPickerFilter(this);
    });
});
