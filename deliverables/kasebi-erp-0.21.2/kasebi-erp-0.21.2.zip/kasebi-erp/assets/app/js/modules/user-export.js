// Optional toolbar component. Each module registers its own scoped ID provider.
const kerpUserExportStates = new Map();

function kerpUserExportTooltips(root) {
    const $buttons = $(root).find('[data-bs-toggle="tooltip"]');
    $buttons.tooltip('dispose');
    if (root.isConnected) {
        $buttons.filter(':visible').tooltip({
            trigger: 'hover focus',
            template: '<div class="tooltip" role="tooltip" style="pointer-events:none"><div class="tooltip-arrow"></div><div class="tooltip-inner"></div></div>'
        });
    }
}

function kerpUserExportCell(value) {
    let text = String(value ?? '');
    // Neutralize spreadsheet formulas without embedding executable formulas for phone numbers.
    if (/^[\s\u0000-\u001f]*[=+@-]/.test(text) || /^[\t\r\n]/.test(text)) text = "'" + text;
    return '"' + text.replace(/"/g, '""') + '"';
}

function kerpUserExportReset(root) {
    const state = kerpUserExportStates.get(root);
    kerpUserExportStates.delete(root);
    if (state?.request) state.request.abort();
    if (state?.url) URL.revokeObjectURL(state.url);
    const $root = $(root);
    $root.find('[data-bs-toggle="tooltip"]').tooltip('dispose');
    $root.attr('aria-busy', 'false');
    $root.find('.kerp-user-export-start').prop('hidden', false).removeClass('d-none');
    $root.find('.kerp-user-export-progress, .kerp-user-export-download').prop('hidden', true).addClass('d-none');
    $root.find('.kerp-user-export-download').removeAttr('href download');
    kerpUserExportTooltips(root);
}

async function kerpUserExportRun(root) {
    if (kerpUserExportStates.has(root)) return;
    const $root = $(root);
    const state = {request: null, url: null, chunks: ['\uFEFF"نام و نام خانوادگی","شماره تماس"\r\n'], seen: new Set()};
    const current = () => root.isConnected && kerpUserExportStates.get(root) === state;
    try {
        const $filters = $($root.attr('data-export-filter-selector'));
        if ($filters.length !== 1) throw new Error('محدوده فیلتر خروجی معتبر نیست.');
        // Freeze the filters at click time, including the current search. Never read IDs from the DOM.
        const filters = $.extend(true, {}, JSON.parse($root.attr('data-export-filters') || '{}'), get_current_page_filters($filters));
        const perPage = Number($root.attr('data-export-per-page'));
        kerpUserExportStates.set(root, state);
        $root.find('[data-bs-toggle="tooltip"]').tooltip('dispose');
        $root.attr('aria-busy', 'true');
        $root.find('.kerp-user-export-start').prop('hidden', true).addClass('d-none');
        $root.find('.kerp-user-export-progress').prop('hidden', false).removeClass('d-none');
        $root.find('.progress-bar').css('width', '0%').attr('aria-valuenow', 0);
        $root.find('.kerp-user-export-label').text('در حال دریافت…');
        $root.find('.kerp-user-export-status').text('دریافت خروجی آغاز شد.');
        kerpUserExportTooltips(root);
        let total = null;
        let pages = null;
        for (let page = 1; ; page++) {
            state.request = $.ajax({
                url: ajax_url, type: 'POST', dataType: 'json', timeout: 30000,
                // Progress belongs to this component; do not activate the panel loading overlay.
                global: false,
                data: $.extend(true, {}, filters, {
                    action: $root.attr('data-export-action'), export_nonce: $root.attr('data-export-nonce'),
                    page_number: page, per_page: perPage
                })
            });
            const response = await state.request;
            state.request = null;
            if (!current()) return;
            if (response.status !== 'success') throw new Error(response.message || 'دریافت خروجی ناموفق بود.');
            if (!Number.isSafeInteger(response.total) || response.total < 0 || response.page_number !== page ||
                response.per_page !== perPage || response.total_pages !== Math.ceil(response.total / perPage) ||
                !Array.isArray(response.user_ids) || !Array.isArray(response.rows) || response.rows.length !== response.user_ids.length) {
                throw new Error('پاسخ صفحه‌بندی خروجی معتبر نیست.');
            }
            if (total === null) { total = response.total; pages = response.total_pages; }
            if (response.total !== total || response.total_pages !== pages ||
                response.user_ids.length !== Math.min(perPage, Math.max(0, total - (page - 1) * perPage))) {
                throw new Error('فهرست کاربران تغییر کرده است؛ دوباره خروجی بگیرید.');
            }
            const lines = response.rows.map(function(row, index) {
                const id = response.user_ids[index];
                if (!Number.isSafeInteger(id) || id < 1 || state.seen.has(id) || !Array.isArray(row) || row.length !== 2 || row.some(value => typeof value !== 'string')) {
                    throw new Error('ردیف تکراری یا نامعتبر در خروجی دریافت شد.');
                }
                state.seen.add(id);
                return row.map(kerpUserExportCell).join(',') + '\r\n';
            });
            state.chunks.push(lines.join(''));
            const percent = total ? Math.floor(state.seen.size / total * 100) : 100;
            $root.find('.progress-bar').css('width', percent + '%').attr('aria-valuenow', percent);
            $root.find('.kerp-user-export-label').text(percent.toLocaleString('fa-IR') + '٪ · ' + state.seen.size.toLocaleString('fa-IR') + ' از ' + total.toLocaleString('fa-IR'));
            if (page >= pages) break;
        }
        if (!current()) return;
        state.url = URL.createObjectURL(new Blob(state.chunks, {type: 'text/csv;charset=utf-8;'}));
        state.chunks = [];
        state.seen.clear();
        const moveFocus = $root[0].contains(document.activeElement);
        $root.find('[data-bs-toggle="tooltip"]').tooltip('dispose');
        $root.attr('aria-busy', 'false');
        $root.find('.kerp-user-export-progress').prop('hidden', true).addClass('d-none');
        $root.find('.kerp-user-export-status').text('فایل CSV آماده دانلود است.');
        const $download = $root.find('.kerp-user-export-download').attr({href: state.url, download: $root.attr('data-export-filename')}).prop('hidden', false).removeClass('d-none');
        kerpUserExportTooltips(root);
        if (moveFocus) $download.trigger('focus');
    } catch (error) {
        if (!current() && kerpUserExportStates.has(root)) return;
        const cancelled = error?.statusText === 'abort' || !root.isConnected;
        kerpUserExportReset(root);
        if (!cancelled) NioApp.Toast(error.message || error.responseJSON?.message || 'ارتباط با سرور برقرار نشد؛ دوباره تلاش کنید.', 'danger', {position: 'top-right'});
    }
}

$(document).on('click', '.kerp-user-export-start', function() {
    kerpUserExportRun($(this).closest('.kerp-user-export')[0]);
});
$(document).on('click', '.kerp-user-export-cancel', function() {
    const root = $(this).closest('.kerp-user-export')[0];
    kerpUserExportReset(root);
    $(root).find('.kerp-user-export-status').text('دریافت خروجی لغو شد.');
    $(root).find('.kerp-user-export-start').trigger('focus');
});
// AJAX page replacement, filters and navigation must not leave requests or Blob URLs behind.
const kerpUserExportObserver = new MutationObserver(function() {
    kerpUserExportStates.forEach(function(state, root) {
        if (!root.isConnected) kerpUserExportReset(root);
    });
});
kerpUserExportObserver.observe(document.documentElement, {childList: true, subtree: true});
$(window).on('pagehide', function() {
    kerpUserExportStates.forEach(function(state, root) { kerpUserExportReset(root); });
});
