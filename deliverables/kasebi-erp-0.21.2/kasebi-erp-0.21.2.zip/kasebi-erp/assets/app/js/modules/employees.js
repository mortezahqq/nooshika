let kerpEmployeesTimer = null;
let kerpEmployeesRequest = null;
let kerpEmployeesGeneration = 0;

$(document).on('click', '.kerp-employees-assign-user', function() {
    const $button = $(this);
    if ($button.data('processing')) return;
    const $row = $button.closest('.kerp-employee-candidate');
    const $root = $button.closest('#kerp-employees-list');
    let options;
    try {
        options = JSON.parse($button.attr('data-role-options') || '{}');
    } catch (error) {
        NioApp.Toast('نقش‌ها دریافت نشدند؛ صفحه را دوباره بارگذاری کنید.', 'danger', {position: 'top-right'});
        return;
    }
    kerpEmployeesCancel();
    $root.find('.kerp-employees-results').attr('aria-busy', 'false');
    $button.data('processing', true).prop('disabled', true);
    Swal.fire({
        title: 'افزودن به کارکنان',
        text: 'نقش سازمانی این کاربر را انتخاب کنید.',
        input: 'select',
        inputOptions: options,
        inputPlaceholder: 'انتخاب نقش سازمانی',
        showCancelButton: true,
        confirmButtonText: 'افزودن به کارکنان',
        cancelButtonText: 'لغو',
        showLoaderOnConfirm: true,
        allowOutsideClick: () => !Swal.isLoading(),
        allowEscapeKey: () => !Swal.isLoading(),
        preConfirm: async function(role) {
            if (!role || !Object.prototype.hasOwnProperty.call(options, role)) {
                Swal.showValidationMessage('یک نقش سازمانی را انتخاب کنید.');
                return false;
            }
            const data = {action: 'employees_assign_existing_user', role_key: role};
            $row.find('input[data-for]').each(function() {
                data[$(this).attr('data-for')] = this.value;
            });
            try {
                const response = await $.ajax({url: ajax_url, type: 'POST', dataType: 'json', data: data, timeout: 30000});
                if (response.status !== 'success') {
                    Swal.showValidationMessage(response.message || response.msg || 'افزودن کاربر انجام نشد.');
                    return false;
                }
                return response;
            } catch (error) {
                Swal.showValidationMessage('ارتباط با سرور برقرار نشد؛ وضعیت کاربر را پیش از تلاش دوباره بررسی کنید.');
                return false;
            }
        },
    }).then(function(result) {
        if (result.isConfirmed && result.value) change_panel_html(result.value);
    }).finally(function() {
        $button.data('processing', false).prop('disabled', false);
    });
});

function kerpEmployeesCancel() {
    clearTimeout(kerpEmployeesTimer);
    clearTimeout($('#kerp-employees-list').data('kerp-table-search-timer'));
    kerpEmployeesGeneration++;
    if (kerpEmployeesRequest) {
        kerpEmployeesRequest.abort();
        kerpEmployeesRequest = null;
    }
}

function kerpEmployeesLoad(root, pageNumber = 1, quietSearch = true) {
    if (!root || !root.isConnected) return;
    kerpEmployeesCancel();
    const generation = kerpEmployeesGeneration;
    const $root = $(root);
    const $results = $root.find('.kerp-employees-results');
    const section = $root.attr('data-section');
    const roleKey = section === 'available' ? 'wp_role' : 'role_key';
    const role = String($root.find('[data-for="' + roleKey + '"]').val() || '');
    const data = {
        action: 'erp_request_page_content',
        page: '/erp/employees/',
        section: section,
        search: String($root.find('#kerp-employees-search').val() || '').trim(),
        page_number: pageNumber,
        per_page: parseInt($root.find(".kerp-employees-per-page").val(), 10) || 12,
    };
    if (role && role !== '0') data[roleKey] = role;
    // Preserve an existing status filter supplied by a bookmarked employees URL.
    const status = new URL(window.location.href).searchParams.get('status');
    if (section === 'employees' && status) data.status = status;
    $results.attr('aria-busy', 'true');
    const current = () => generation === kerpEmployeesGeneration && root.isConnected;
    kerpEmployeesRequest = kerpTableSearchAjax({
        url: ajax_url,
        type: 'POST',
        dataType: 'json',
        data: data,
        ajax_search: quietSearch,
        kerpEmployeesFilter: true,
    }).done(function(response) {
        if (!current()) return;
        const $content = $('<div>').append($.parseHTML(response.main || '', document, false));
        const $next = $content.find('#kerp-employees-list');
        if (response.status !== 'success' || !$next.length || $next.attr('data-section') !== section) {
            NioApp.Toast(response.message || response.msg || 'دریافت نتایج ناموفق بود. دوباره تلاش کنید.', 'danger', {position: 'top-right'});
            return;
        }
        // Keep the search field and its cursor in place while replacing cards and pagination.
        $results.find('.kerp-employees-tooltip-active').tooltip('dispose');
        $results.html($next.find('.kerp-employees-results').html());
        $root.find('.kerp-employees-summary').html($next.find('.kerp-employees-summary').html());
        $root.find('.kerp-employees-total').text($next.find('.kerp-employees-total').text());
        const $badge = $root.find('.nav-tabs .badge');
        $badge.text($next.find('.nav-tabs .badge').text());
        const $toggle = $root.find('.filter_form_wrapper').siblings('.dropdown-toggle');
        $toggle.find('.dot').remove();
        if (data[roleKey]) $toggle.append('<span class="dot dot-primary"></span>');
        if (response.url) history.replaceState({}, '', response.url);
        kerpEmployeesSelectionCount();
        // The toolbar survives result updates; avoid binding its search toggles twice.
        $root.find('.toggle-search').off('click');
        NioApp.ajaxInit();
    }).fail(function(xhr, state) {
        if (current() && state !== 'abort') {
            NioApp.Toast('خطا در دریافت نتایج؛ دوباره تلاش کنید.', 'danger', {position: 'top-right'});
        }
    }).always(function() {
        if (current()) {
            $results.attr('aria-busy', 'false');
            kerpEmployeesRequest = null;
        }
    });
}

$(document).on('kerp:table-search', '#kerp-employees-list', function(event) {
    event.preventDefault();
    kerpEmployeesLoad(this);
});
$(document).on('kerp:table-search-cancel', '#kerp-employees-list', function() {
    kerpEmployeesCancel();
    $(this).find('.kerp-employees-results').attr('aria-busy', 'false');
});
$(document).on('click', '#kerp-employees-list .page-item', function(event) {
    event.preventDefault();
    if ($(this).is('.disabled, .active')) return;
    kerpEmployeesLoad($(this).closest('#kerp-employees-list')[0], parseInt($(this).attr('data-page'), 10) || 1, false);
});
// Invalidate a pending search when navigation or assigning a candidate starts.
$(document).ajaxSend(function(event, xhr, settings) {
    if (settings.kerpEmployeesFilter) return;
    const data = typeof settings.data === 'string' ? new URLSearchParams(settings.data) : null;
    const action = data ? data.get('action') : (settings.data || {}).action;
    if (['erp_request_page_content', 'erp_request_back_btn', 'employees_assign_existing_user', 'employees_assign_existing_users'].includes(action)) {
        kerpEmployeesCancel();
        $('#kerp-employees-list .kerp-employees-results').attr('aria-busy', 'false');
    }
});

$(document).on('click', '#kerp-employees-list .change_per_page', function(event) {
    event.preventDefault();
    const $root = $(this).closest('#kerp-employees-list');
    $root.find('.kerp-employees-per-page').val($(this).attr('data-per-page'));
    $root.find('.change_per_page').removeClass('active');
    $(this).addClass('active');
    kerpEmployeesLoad($root[0], 1, false);
});

function kerpEmployeesSelectionCount() {
    const $root = $('#kerp-employees-list');
    kerp_update_select_all_state($root);
    $root.find('.kerp-employee-candidate-select').each(function() {
        $(this).closest('.nk-tb-item').toggleClass('is-selected', this.checked);
    });
    const count = $('#kerp-employees-list .kerp-employee-candidate-select:checked').length;
    $('#kerp-employees-list .kerp-employees-selected-count').text(count ? count + ' کاربر انتخاب شده' : '');
}
$(document).on('change kerp:row-selection-change', '#kerp-employees-list .kerp-employee-candidate-select', kerpEmployeesSelectionCount);
$(document).on('click', '.kerp-employees-open-bulk', function(event) {
    event.preventDefault();
    const $root = $(this).closest('#kerp-employees-list');
    const ids = $root.find('.kerp-employee-candidate-select:checked').map(function() { return this.value; }).get();
    if (!ids.length) {
        NioApp.Toast('حداقل یک کاربر را انتخاب کنید.', 'warning', {position: 'top-right'});
        return;
    }
    kerpEmployeesCancel();
    $root.find('.kerp-employees-results').attr('aria-busy', 'false');
    const $modal = $root.find('#kerpEmployeesBulkAssign');
    if ($modal.data('processing')) return;
    // Reuse the shared modal with a real keyboard-accessible submit button.
    $modal.find('.submit_modal_form').replaceWith($('<button type="button" class="btn btn-primary kerp-employees-bulk-submit">').text('افزودن کاربران انتخاب‌شده'));
    const role = $root.find('.kerp-employees-filters [data-for="wp_role"]').val();
    const data = {
        action: 'employees_assign_existing_users', user_ids: ids,
        search: String($root.find('#kerp-employees-search').val() || '').trim(),
        wp_role: role && role !== '0' ? role : '',
        per_page: parseInt($root.find('.kerp-employees-per-page').val(), 10) || 12,
        page_number: parseInt($root.find('.page-item.active').attr('data-page'), 10) || 1,
    };
    $modal.data('assignment', data);
    $modal.find('.kerp-employees-bulk-count').text(ids.length + ' کاربر انتخاب شده‌اند.');
    $modal.find('.kerp-employees-bulk-feedback').empty();
    $modal.modal('show');
});
$(document).on('click', '.kerp-employees-bulk-submit', function() {
    const $modal = $(this).closest('.modal');
    const $button = $(this);
    if ($modal.data('processing')) return;
    const role = $modal.find('[data-for="role_key"]').val();
    const assignment = $modal.data('assignment');
    const $feedback = $modal.find('.kerp-employees-bulk-feedback');
    if (!assignment || !assignment.user_ids.length || !role || role === '0') {
        $feedback.text('کاربران و یک نقش سازمانی معتبر را انتخاب کنید.');
        return;
    }
    const data = Object.assign({}, assignment, {
        role_key: role, employees_nonce: $modal.find('[data-for="employees_nonce"]').val(),
    });
    $modal.data('processing', true);
    $button.prop('disabled', true).attr('aria-busy', 'true');
    $feedback.empty();
    $.ajax({url: ajax_url, type: 'POST', dataType: 'json', data: data}).done(function(response) {
        if (response.status === 'success') change_panel_html(response);
        else $feedback.text(response.message || response.msg || 'افزودن کاربران انجام نشد.');
    }).fail(function() {
        $feedback.text('ارتباط با سرور برقرار نشد؛ پیش از تلاش دوباره، فهرست کارکنان را بررسی کنید.');
    }).always(function() {
        $modal.data('processing', false);
        $button.prop('disabled', false).attr('aria-busy', 'false');
    });
});
$(document).on('submit', '#kerpEmployeesBulkAssign form', function(event) {
    event.preventDefault();
    $(this).find('.kerp-employees-bulk-submit').trigger('click');
});

$(document).on('keydown', '#kerp-employees-search', function(event) {
    if (event.key === 'Escape') {
        kerpEmployeesCancel();
        const $root = $(this).closest('#kerp-employees-list');
        $root.find('.kerp-employees-results').attr('aria-busy', 'false');
        $root.find('.search-toggle').attr('aria-expanded', 'false').trigger('focus');
    }
});
$(document).on('click', '#kerp-employees-list .toggle-search', function() {
    const $root = $(this).closest('#kerp-employees-list');
    const open = $root.find('[data-search="search_employees"]').hasClass('active');
    $root.find('.search-toggle').attr('aria-expanded', String(open));
    if (!open) {
        kerpEmployeesCancel();
        $root.find('.kerp-employees-results').attr('aria-busy', 'false');
        $root.find('.search-toggle').trigger('focus');
    }
});

// Tooltips are scoped to this list and do not replace dropdown/modal Bootstrap toggles.
const kerpEmployeesTooltipTargets = '#kerp-employees-list button, #kerp-employees-list .btn, #kerp-employees-list .page-link, #kerp-employees-list .reset_page_filter, #kerp-employees-list .change_per_page, #kerp-employees-list .kerp-employees-open-bulk';
function kerpEmployeesShowTooltip() {
    const $button = $(this);
    if ($button.is('[data-kerp-no-tooltip]')) return;
    const pageNumber = $button.closest('.page-item').attr('data-page');
    const perPage = $button.attr('data-per-page');
    const label = (pageNumber ? 'رفتن به صفحه ' + pageNumber : (perPage ? 'نمایش ' + perPage + ' مورد در صفحه' : '')) || $button.attr('aria-label') || $button.attr('data-bs-original-title') || $button.attr('title') || $.trim($button.text());
    if (!label || typeof $.fn.tooltip !== 'function') return;
    if (!$button.hasClass('kerp-employees-tooltip-active')) {
        $button.addClass('kerp-employees-tooltip-active').tooltip({title: label, trigger: 'hover focus', container: 'body'});
    }
    $button.tooltip('show');
}
$(document).on('mouseenter', kerpEmployeesTooltipTargets, kerpEmployeesShowTooltip);
document.addEventListener('focus', function(event) {
    if (event.target.matches(kerpEmployeesTooltipTargets)) kerpEmployeesShowTooltip.call(event.target);
}, true);
$(document).on('click', kerpEmployeesTooltipTargets, function() {
    if ($(this).hasClass('kerp-employees-tooltip-active')) $(this).tooltip('hide');
});
