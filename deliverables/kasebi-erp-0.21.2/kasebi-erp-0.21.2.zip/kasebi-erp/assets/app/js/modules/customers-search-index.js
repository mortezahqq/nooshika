// Progressive index rebuild follows the customer migration controls.
$(document).on('click.kerpCustomerIndex', '[data-index-rebuild]', async function(event) {
    event.preventDefault();
    const button = this;
    const root = button.closest('#kerp-customers-search-index');
    if (!root || root.dataset.running === '1') return;
    const label = button.querySelector('span');
    const message = root.querySelector('[data-index-message]');
    const progress = root.querySelector('[data-index-progress]');
    root.dataset.running = '1';
    root.setAttribute('aria-busy', 'true');
    button.disabled = true;
    label.textContent = 'در حال بازسازی…';
    message.classList.remove('text-danger');
    const controller = new AbortController();
    const observer = new MutationObserver(function() {
        if (!document.documentElement.contains(root)) controller.abort();
    });
    observer.observe(document.body, {childList: true, subtree: true});
    const onPageHide = function() { controller.abort(); };
    window.addEventListener('pagehide', onPageHide, {once: true});
    let idleRequests = 0;
    let previousProcessed = -1;
    try {
        while (document.documentElement.contains(root)) {
            const body = new URLSearchParams({
                action: 'customers_rebuild_search_index',
                index_nonce: root.dataset.nonce || '',
                generation: root.dataset.generation || ''
            });
            const response = await fetch(window.KERPData?.ajaxUrl || '', {
                method: 'POST', credentials: 'same-origin', cache: 'no-store',
                signal: controller.signal,
                headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'},
                body: body.toString()
            });
            const payload = await response.json();
            if (!response.ok || payload?.status !== 'success' || !payload.data) {
                throw new Error(payload?.message || payload?.msg || 'بازسازی ایندکس انجام نشد.');
            }
            if (!document.documentElement.contains(root)) break;
            const data = payload.data;
            root.dataset.generation = data.generation;
            for (const key of ['total', 'processed', 'remaining']) {
                root.querySelector('[data-index-' + key + ']').textContent = Number(data[key] || 0).toLocaleString('fa-IR');
            }
            const percent = Math.max(0, Math.min(100, Number(data.percent || 0)));
            progress.style.width = percent + '%';
            progress.setAttribute('aria-valuenow', String(percent));
            message.textContent = data.complete
                ? 'بازسازی ایندکس کامل شد؛ جستجوی مشتریان آماده است.'
                : 'دسته ' + Number(data.page || 0).toLocaleString('fa-IR') + ' — ' + percent.toLocaleString('fa-IR') + '٪ — ' + Number(data.remaining || 0).toLocaleString('fa-IR') + ' کاربر باقی مانده است…';
            if (data.complete) {
                root.dataset.generation = '';
                label.textContent = 'بازسازی دوباره ایندکس';
                break;
            }
            idleRequests = Number(data.processed) === previousProcessed ? idleRequests + 1 : 0;
            previousProcessed = Number(data.processed);
            if (idleRequests >= 10) throw new Error('بازسازی پیشرفت نکرد؛ کمی بعد ادامه دهید.');
            if (data.busy) await new Promise(resolve => setTimeout(resolve, 1000));
        }
    } catch (error) {
        if (error.name !== 'AbortError') {
            message.classList.add('text-danger');
            message.textContent = error.message || 'بازسازی ایندکس انجام نشد.';
        }
        label.textContent = 'ادامه بازسازی ایندکس';
    } finally {
        observer.disconnect();
        window.removeEventListener('pagehide', onPageHide);
        root.dataset.running = '0';
        root.removeAttribute('aria-busy');
        button.disabled = false;
    }
});
