/* ===== wallet ERP ===== */
(function() {
    function walletToast(message, type) {
        NioApp.Toast(message, type || 'error', {position: 'top-right'});
    }
    
    function walletAmount(value) {
        value = String(value || '').trim().replace(/[۰-۹]/g, function(n) {
            return '۰۱۲۳۴۵۶۷۸۹'.indexOf(n);
        }).replace(/[٠-٩]/g, function(n) {
            return '٠١٢٣٤٥٦٧٨٩'.indexOf(n);
        }).replace(/٬/g, ',').replace(/٫/g, '.');
        return /^(?:[0-9]+|[0-9]{1,3}(?:,[0-9]{3})+)(?:\.[0-9]+)?$/.test(value)
               ? Number(value.replace(/,/g, ''))
               : NaN;
    }
    
    function walletResponse(response) {
        response = response || {};
        change_panel_html(response);
    }
    
    function walletRepeaterRows($form, id, name, keys) {
        const rows = [];
        $form.find('#' + id + ' .repeater_row').each(function() {
            const $row = $(this),
                  row  = {};
            keys.forEach(function(key) {
                const $field = $row.find('[name^="' + name + '["][name$="[' + key + ']"]').first();
                row[key] = $field.is(':checkbox') ? ($field.is(':checked') ? '1' : '0') : String($field.val() || '').
                    trim();
            });
            if (keys.some(function(key) { return key !== 'required' && row[key] !== ''; })) {
                rows.push(row);
            }
        });
        return rows;
    }
    
    $(document).on('click', '.kerp-wallet-repair-product', function() {
        const $button = $(this);
        if ($button.prop('disabled')) {
            return;
        }
        $button.prop('disabled', true);
        $.post(ajax_url, {
            action:       'wallet_repair_product',
            wallet_nonce: $button.attr('data-nonce'),
        }).done(walletResponse).fail(function() {
            walletToast('ارتباط با سرور برقرار نشد؛ دوباره تلاش کنید.');
        }).always(function() {
            $button.prop('disabled', false);
        });
    });
    
    $(document).on('click', '.kerp-wallet-add-preset', function() {
        const $rows = $(this).closest('form').find('.kerp-wallet-preset-rows');
        if ($rows.children().length >= 20) {
            walletToast('حداکثر ۲۰ مبلغ پیشنهادی قابل ثبت است.');
            return;
        }
        const $row = $('<div>', {'class': 'row g-2 mb-3 kerp-wallet-preset-row'});
        $('<div>', {'class': 'col'}).append($('<input>', {
            type:         'text',
            'class':      'form-control price_input',
            name:         'presets[]',
            inputmode:    'numeric',
            'aria-label': 'مبلغ پیشنهادی شارژ',
        })).appendTo($row);
        $('<div>', {'class': 'col-auto'}).append($('<button>', {
            type:         'button',
            'class':      'btn btn-outline-danger btn-icon kerp-wallet-remove-preset',
            'aria-label': 'حذف مبلغ پیشنهادی',
        }).append('<em class="icon ni ni-trash"></em>')).appendTo($row);
        $rows.append($row);
        $row.find('input').trigger('focus');
    });
    
    $(document).on('click', '.kerp-wallet-remove-preset', function() {
        $(this).closest('.kerp-wallet-preset-row').remove();
    });
    
    $(document).on('submit', '.kerp-wallet-settings-form', function(event) {
        event.preventDefault();
        const $form   = $(this),
              $button = $form.find('[type="submit"]');
        if ($form.data('submitting')) {
            return;
        }
        const section = String($form.attr('data-section') || '');
        const formData = new FormData(this);
        formData.set('action', 'wallet_save_settings');
        formData.set('nonce', $form.attr('data-nonce'));
        $form.find('.quill-basic[data-for]').each(function() {
            const $editor  = $(this),
                  instance = this.__quill || $editor.data('quill');
            formData.set(
                $editor.attr('data-for'),
                instance && instance.root ? instance.root.innerHTML : ($editor.find('.quill-value').val() || ''),
            );
        });
        const settingsPayload = {section: section};
        if (section === 'limits') {
            const minimum = walletAmount($form.find('[name="minimum"]').val());
            const percentage = walletAmount($form.find('[name="payment_max_percentage"]').val());
            const maxRaw = String($form.find('[name="payment_max_amount"]').val() || '').trim();
            const maxAmount = maxRaw === '' ? 0 : walletAmount(maxRaw);
            if (!Number.isFinite(percentage) || percentage <= 0 || percentage > 100) {
                walletToast('حداکثر درصد پرداخت با کیف پول باید بین ۱ تا ۱۰۰ باشد.');
                return;
                
            }
            if (!Number.isFinite(maxAmount) || maxAmount < 0) {
                walletToast('حداکثر مبلغ پرداخت با کیف پول را درست وارد کنید؛ برای نامحدود بودن صفر بگذارید.');
                return;
            }
            const invalidPreset = $form.find('[name="presets[]"]').toArray().some(function(input) {
                const value  = String(input.value || '').trim(),
                      amount = walletAmount(value);
                return value !== '' && (!Number.isFinite(amount) || amount < minimum);
            });
            if (invalidPreset) {
                walletToast('مبالغ پیشنهادی باید در محدوده حداقل و حداکثر شارژ باشند.');
                return;
            }
            Object.assign(settingsPayload, {
                enabled:                $form.find('[name="enabled"]').is(':checked') ? '1' : '0',
                minimum:                String($form.find('[name="minimum"]').val() || ''),
                maximum:                String($form.find('[name="maximum"]').val() || ''),
                presets:                $form.find('[name="presets[]"]').map(function() { return this.value; }).get(),
                payment_max_percentage: String($form.find('[name="payment_max_percentage"]').val() || ''),
                payment_max_amount:     String($form.find('[name="payment_max_amount"]').val() || ''),
            });
        } else if (section === 'withdrawal') {
            Object.assign(settingsPayload, {
                withdrawal_enabled:         $form.find('[name="withdrawal_enabled"]').is(':checked') ? '1' : '0',
                withdrawal_minimum_balance: String($form.find('[name="withdrawal_minimum_balance"]').val() || ''),
                withdrawal_debit_timing:    String($form.find('[name="withdrawal_debit_timing"]').val() || ''),
                withdrawal_terms:           String(formData.get('withdrawal_terms') || ''),
                withdrawal_fields:          walletRepeaterRows($form, 'kerp-wallet-withdrawal-fields',
                    'withdrawal_fields', ['key', 'label', 'type', 'required']),
            });
        } else if (section === 'sms') {
            settingsPayload.sms_rules = walletRepeaterRows($form, 'kerp-wallet-sms-rules', 'sms_rules',
                ['event', 'recipient', 'receptor', 'pattern', 'variables']);
        } else {
            walletToast('بخش تنظیمات کیف پول معتبر نیست.');
            return;
        }
        formData.set('settings_payload', JSON.stringify(settingsPayload));
        $form.data('submitting', true);
        $button.prop('disabled', true);
        $.ajax({
            url:         ajax_url,
            method:      'POST',
            dataType:    'json',
            data:        formData,
            processData: false,
            contentType: false,
        }).done(walletResponse).fail(function() {
            walletToast('ذخیره تنظیمات انجام نشد؛ دوباره تلاش کنید.');
        }).always(function() {
            $form.removeData('submitting');
            $button.prop('disabled', false);
        });
    });
    
    $(document).on('submit', '.kerp-wallet-withdrawal-admin-form', function(event) {
        event.preventDefault();
        const form    = this,
              $form   = $(form),
              $button = $form.find('[type="submit"]');
        if ($form.data('submitting')) {
            return;
        }
        const data = new FormData(form);
        data.set('action', 'kerp_wallet_update_withdrawal');
        data.set('receipt_url', String($form.find('[data-for="receipt"]').val() || ''));
        $form.data('submitting', true);
        $button.prop('disabled', true);
        $.ajax({
            url:         ajax_url,
            method:      'POST',
            dataType:    'json',
            data:        data,
            processData: false,
            contentType: false,
        }).done(function(response) {
            if (response.status === 'success') {
                change_panel_html(response);
            } else {
                walletToast(response.message || response.msg || 'ذخیره اطلاعات درخواست انجام نشد.');
            }
        }).fail(function() {
            walletToast('ارتباط با سرور برقرار نشد.');
        }).always(function() {
            $form.removeData('submitting');
            $button.prop('disabled', false);
        });
    });
    
    $(document).on('click', '.kerp-wallet-payment-details', function() {
        const data   = $(this).data('details') || {},
              $modal = $('#kerpWalletPaymentDetailsModal');
        $modal.find('[data-wallet-detail="status"]').text(data.status || '—');
        $modal.find('[data-wallet-detail="bank"]').text(data.bank || '—');
        $modal.find('[data-wallet-detail="reference"]').text(data.reference || '—');
        $modal.find('[data-wallet-detail="paid_at"]').text(data.paid_at || '—');
        $modal.find('[data-wallet-detail="note"]').text(data.note || '—');
        const $receipt = $modal.find('[data-wallet-detail="receipt"]');
        data.receipt
        ? $receipt.attr('href', data.receipt).closest('.kerp-wallet-payment-receipt').show()
        : $receipt.removeAttr('href').closest('.kerp-wallet-payment-receipt').hide();
        $modal.addClass('is-active').attr('aria-hidden', 'false');
    });
    
    $(document).on('click', '.kerp-wallet-payment-modal__close, #kerpWalletPaymentDetailsModal', function(event) {
        if (event.target !== this && !$(event.target).closest('.kerp-wallet-payment-modal__close').length) {
            return;
        }
        $('#kerpWalletPaymentDetailsModal').removeClass('is-active').attr('aria-hidden', 'true');
    });
}());

