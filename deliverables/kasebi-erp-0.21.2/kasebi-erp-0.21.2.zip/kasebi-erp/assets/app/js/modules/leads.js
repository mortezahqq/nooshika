    function kerpLeadsSyncPicker(picker) {
        const pipeline = picker.querySelector('[data-lead-pipeline]');
        const stage = picker.querySelector('[data-lead-stage]');
        if (!pipeline || !stage) return;
        Array.from(stage.options).forEach(function (option) {
            const visible = !option.dataset.pipeline || option.dataset.pipeline === pipeline.value;
            option.hidden = !visible;
            option.disabled = !visible;
        });
        if (!stage.selectedOptions.length || stage.selectedOptions[0].disabled) stage.value = '0';
    }
    document.addEventListener('change', function (event) {
        if (event.target.matches('[data-lead-pipeline]')) kerpLeadsSyncPicker(event.target.closest('.kerp-pipeline-picker'));
        if (event.target.matches('[data-lead-select-all]')) {
            event.target.closest('form').querySelectorAll('[data-for="user_ids"]').forEach(function (input) {
                input.checked = event.target.checked;
            });
        }
    });
    // ERP replaces page fragments without a full page load.
    const kerpLeadsObserver = new MutationObserver(function (records) {
        records.forEach(function (record) {
            record.addedNodes.forEach(function (node) {
                if (node.nodeType !== 1) return;
                if (node.matches('.kerp-pipeline-picker')) kerpLeadsSyncPicker(node);
                node.querySelectorAll('.kerp-pipeline-picker').forEach(kerpLeadsSyncPicker);
            });
        });
    });
    document.querySelectorAll('.kerp-pipeline-picker').forEach(kerpLeadsSyncPicker);
    kerpLeadsObserver.observe(document.body, { childList: true, subtree: true });

// Preserve shared form/bulk behavior and add only the leads CSRF token.
function kerpLeadsFilterStages($root, reset) {
    const $filter = $root.find('.filter_form_wrapper');
    const campaign = String($filter.find('[data-for="campaign_id"]').val() || '');
    const $stage = $filter.find('[data-for="stage_id"]');
    const previous = reset ? '' : String($stage.val() || '');
    let stages = [];
    try { stages = JSON.parse($root.attr('data-lead-filter-stages') || '[]'); } catch (error) { return; }
    $stage.empty().append(new Option('همه مراحل', ''));
    stages.filter(item => String(item.campaign_id) === campaign).forEach(item => $stage.append(new Option(item.name, item.id)));
    $stage.val(previous).prop('disabled', !campaign || campaign === '0');
    if (!$stage.val()) $stage.val('');
    $stage.trigger('change.select2');
}
$(document).on('change', '.kerp-leads-list .filter_form_wrapper [data-for="campaign_id"]', function() {
    kerpLeadsFilterStages($(this).closest('.kerp-leads-list'), true);
});
$(document).on('shown.bs.dropdown', '.kerp-leads-list .dropdown', function() {
    if ($(this).find('.filter_form_wrapper').length) kerpLeadsFilterStages($(this).closest('.kerp-leads-list'), false);
});
$(document).on('click', '.kerp-leads-open-branch', function(event) {
    event.preventDefault();
    const $root = $(this).closest('.kerp-leads-list');
    const ids = $root.find('.kerp-lead-member-select:checked').map(function() { return this.value; }).get();
    if (!ids.length) { NioApp.Toast('حداقل یک عضو را انتخاب کنید.', 'warning', {position: 'top-right'}); return; }
    const $modal = $root.find('#kerpLeadsBranch');
    const $inputs = $modal.find('.kerp-leads-selected-inputs').empty();
    ids.forEach(id => $('<input>', {type: 'checkbox', 'data-for': 'user_ids', value: id, class: 'no_clear', checked: true, hidden: true}).appendTo($inputs));
    $modal.find('.kerp-leads-selection-count').text(ids.length.toLocaleString('fa-IR') + ' عضو انتخاب شده');
    $modal.find('.submit_modal_form').attr({role: 'button', tabindex: '0'});
    $modal.modal('show');
});
$(document).on('keydown', '#kerpLeadsBranch .submit_modal_form', function(event) {
    if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); $(this).trigger('click'); }
});
$(document).on('submit', '#kerpLeadsBranch form', function(event) { event.preventDefault(); $(this).find('.submit_modal_form').trigger('click'); });
$.ajaxPrefilter(function(options) {
    if (typeof options.data === 'string' && /(?:^|&)action=leads_pipeline_bulk(?:&|$)/.test(options.data)) {
        options.data += '&leads_nonce=' + encodeURIComponent($('.kerp-pipelines[data-leads-nonce]').attr('data-leads-nonce') || '');
    }
});
$(document).on('show.bs.modal', '[id^="kerpPipeline"]', function() {
    $(this).find('.submit_modal_form').attr({role: 'button', tabindex: '0'});
    kerpLeadsSyncTrigger($(this).find('.modal_form'));
    const $kerpActionForm = $(this).find('form[data-action="leads_save_stage_actions"]');
    if ($kerpActionForm.length) evaluateAll($kerpActionForm);
});
function kerpLeadsSyncTrigger($form) {
    const trigger = $form.find('[data-for="stage[trigger_type]"]').val();
    [['.kerp-lead-form-field', 'gravity_form'], ['.kerp-lead-product-field', 'product_purchase'], ['.kerp-lead-lesson-field', 'learndash_completed']].forEach(function(entry) {
        const $row = $form.find(entry[0]);
        const visible = trigger === entry[1];
        $row.toggleClass('d-none', !visible);
        $row.find('select,input').prop('disabled', !visible);
        $row.find('[data-for]').attr('data-req', visible ? '1' : '0');
        if (!visible) $row.find('select.select2-hidden-accessible').select2('close');
        if (!visible && $row.hasClass('kerp-lead-product-picker')) kerpLeadsCancelProduct($row);
    });
}
$(document).on('change', '[id^="kerpPipelineStage"] [data-for="stage[trigger_type]"]', function() {
    kerpLeadsSyncTrigger($(this).closest('form'));
});
function kerpLeadsCancelProduct($picker) {
    clearTimeout($picker.data('searchTimer'));
    $picker.data('searchVersion', ($picker.data('searchVersion') || 0) + 1);
    const request = $picker.data('searchRequest');
    if (request) request.abort();
    $picker.removeData('searchRequest');
    $picker.find('.kerp-lead-product-results').empty().prop('hidden', true);
}
$(document).on('input', '.kerp-lead-product-search', function() {
    const $picker = $(this).closest('.kerp-lead-product-picker');
    kerpLeadsCancelProduct($picker);
    $picker.find('[data-for]').val('');
    const term = this.value.trim();
    const $status = $picker.find('.kerp-lead-product-status');
    const resource = $picker.attr('data-resource-label') || 'محصول';
    $status.text(term.length < 2 ? 'برای جستجو حداقل دو حرف بنویسید.' : 'در حال جستجو…');
    if (term.length < 2) return;
    const version = $picker.data('searchVersion');
    const current = () => $picker[0].isConnected && version === $picker.data('searchVersion') && !$picker.hasClass('d-none') && $picker.closest('.modal').hasClass('show');
    $picker.data('searchTimer', setTimeout(function() {
        if (!current()) return;
        const $form = $picker.closest('form');
        $picker.data('searchRequest', $.ajax({url: ajax_url, type: 'POST', dataType: 'json', data: {
            action: $picker.attr('data-search-action') || 'leads_search_products', search: term, leads_nonce: $form.find('[data-for="leads_nonce"]').val()
        }}).done(function(response) {
            if (!current()) return;
            if (!response || response.status === 'error' || !Array.isArray(response.results)) {
                $status.text(response && (response.message || response.msg) || 'جستجو انجام نشد؛ دوباره تلاش کنید.'); return;
            }
            const $results = $picker.find('.kerp-lead-product-results').empty();
            response.results.forEach(function(item) {
                $('<button>', {type: 'button', class: 'list-group-item list-group-item-action kerp-lead-product-result'}).text(item.text).attr('data-product-id', item.id).appendTo($results);
            });
            $results.prop('hidden', !response.results.length);
            $status.text(response.results.length ? resource + ' موردنظر را انتخاب کنید؛ برای نتایج دقیق‌تر نام کامل‌تری بنویسید.' : 'نتیجه‌ای پیدا نشد.');
        }).fail(function(xhr, status) {
            if (current() && status !== 'abort') $status.text(xhr.responseJSON && (xhr.responseJSON.message || xhr.responseJSON.msg) || 'دریافت نتایج ناموفق بود؛ دوباره جستجو کنید.');
        }));
    }, 300));
});
$(document).on('click', '.kerp-lead-product-result', function() {
    const $picker = $(this).closest('.kerp-lead-product-picker');
    const id = $(this).attr('data-product-id'), label = $(this).text();
    kerpLeadsCancelProduct($picker);
    $picker.find('[data-for]').val(id).trigger('change');
    $picker.find('.kerp-lead-product-search').val(label).trigger('focus');
    $picker.find('.kerp-lead-product-status').text(($picker.attr('data-resource-label') || 'محصول') + ' انتخاب شده است.');
});
$(document).on('click', '.kerp-lead-product-clear', function() {
    $(this).closest('.kerp-lead-product-picker').find('.kerp-lead-product-search').val('').trigger('input').trigger('focus');
});
$(document).on('keydown', '.kerp-lead-product-search, .kerp-lead-product-result', function(event) {
    const $picker = $(this).closest('.kerp-lead-product-picker');
    const $results = $picker.find('.kerp-lead-product-result');
    const index = $results.index(this);
    if (event.key === 'Escape') { event.preventDefault(); event.stopPropagation(); kerpLeadsCancelProduct($picker); $picker.find('.kerp-lead-product-search').trigger('focus'); }
    if (event.key === 'Enter' && $(this).hasClass('kerp-lead-product-search')) { event.preventDefault(); $results.first().trigger('focus'); }
    if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
        event.preventDefault();
        const next = event.key === 'ArrowDown' ? Math.min(index + 1, $results.length - 1) : index - 1;
        if (next < 0) $picker.find('.kerp-lead-product-search').trigger('focus'); else $results.eq(next).trigger('focus');
    }
});
$(document).on('hide.bs.modal', '[id^="kerpPipelineStage"]', function() {
    $(this).find('.kerp-lead-product-picker').each(function() { kerpLeadsCancelProduct($(this)); });
});
$(document).on('keydown', '[id^="kerpPipeline"] .submit_modal_form', function(event) {
    if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); $(this).trigger('click'); }
});
$(document).on('submit', '[id^="kerpPipeline"] .modal_form', function(event) {
    event.preventDefault();
    $(this).find('.submit_modal_form').first().trigger('click');
});

$(document).on('click', '.kerp-leads-open-bulk', function(event) {
    event.preventDefault();
    const root = $(this).closest('.kerp-leads-list');
    const operation = $(this).attr('data-operation');
    if (!['owner', 'stage', 'exit', 'course'].includes(operation)) return;
    const ids = root.find('.kerp-lead-member-select:checked').map(function() { return $(this).attr('data-membership-id'); }).get();
    if (!ids.length) { NioApp.Toast('حداقل یک ردیف را انتخاب کنید.', 'warning', {position: 'top-right'}); return; }
    const modal = root.find({owner: '#kerpLeadsBulkOwner', stage: '#kerpLeadsBulkStage', exit: '#kerpLeadsBulkExit', course: '#kerpLeadsBulkCourse'}[operation]);
    modal.find('[data-for="confirm_replace"], [data-for="confirm_exit"], [data-for="confirm_course"]').prop('checked', false);
    const inputs = modal.find('.kerp-leads-selected-inputs').empty();
    ids.forEach(id => $('<input>', {type: 'checkbox', 'data-for': 'membership_ids', value: id, checked: true, hidden: true, class: 'no_clear'}).appendTo(inputs));
    modal.find('.kerp-leads-selection-count').text(ids.length.toLocaleString('fa-IR') + ' ردیف انتخاب شده');
    modal.find('.submit_modal_form').attr({role: 'button', tabindex: '0'});
    modal.modal('show');
});
$(document).on('keydown', '[id^="kerpLeadsBulk"] .submit_modal_form', function(event) {
    if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); $(this).trigger('click'); }
});
