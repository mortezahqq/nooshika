function kerp_installment_sms_recipients(form) {
    $(form).find('.repeater_row').each(function() {
        const $row = $(this);
        const $recipient = $row.find('select[data-for$="[recipient]"]');
        if (!$recipient.length) return;
        const recipient = String($recipient.val() || '');
        [['.kerp-installment-sms-meta', 'user_meta'], ['.kerp-installment-sms-custom', 'custom']].forEach(function(pair) {
            const visible = recipient === pair[1];
            const $field = $row.find(pair[0]);
            $field.toggleClass('d-none', !visible);
            $field.find('input').prop('disabled', !visible).attr('data-req', visible ? '1' : '0').data('req', visible ? 1 : 0);
        });
    });
}

$(document).on('change', '.kerp-installment-plan select[data-for$="[recipient]"]', function() {
    kerp_installment_sms_recipients($(this).closest('.kerp-installment-plan'));
});

function kerp_installment_update_progress(form) {
    kerp_installment_sms_recipients(form);
    const $form = $(form), $summary = $form.find('.kerp-installment-plan-progress');
    if (!$summary.length) return;
    let total = 0, invalid = false;
    $form.find('.kerp-installment-steps .repeater_rows [data-for$="[percent]"]').each(function() {
        const raw = String($(this).val() || '').trim()
            .replace(/[۰-۹]/g, digit => '۰۱۲۳۴۵۶۷۸۹'.indexOf(digit))
            .replace(/[٠-٩]/g, digit => '٠١٢٣٤٥٦٧٨٩'.indexOf(digit))
            .replace(/٫/g, '.');
        if (!raw) return;
        if (!/^\d{1,3}(?:\.\d{1,2})?$/.test(raw) || Number(raw) <= 0 || Number(raw) > 100) {
            invalid = true;
            return;
        }
        total += Math.round(Number(raw) * 100);
    });
    const format = value => (value / 100).toLocaleString('fa-IR', {maximumFractionDigits: 2});
    const excess = total > 10000, complete = total === 10000 && !invalid;
    $summary.toggleClass('is-complete', complete).toggleClass('is-error', excess || invalid);
    $summary.find('.kerp-installment-progress-total').text(format(total) + '٪ از ۱۰۰٪');
    const message = invalid ? 'درصد هر قسط باید عددی مثبت تا ۱۰۰ با حداکثر دو رقم اعشار باشد.'
        : excess ? format(total - 10000) + '٪ بیشتر از مقدار مجاز'
        : complete ? 'مجموع درصدها کامل است.' : format(10000 - total) + '٪ باقی مانده';
    $summary.find('.kerp-installment-progress-note').text(message);
    $summary.find('[role="progressbar"]').attr({'aria-valuenow': Math.min(100, total / 100), 'aria-valuetext': format(total) + '٪؛ ' + message});
    $summary.find('.progress-bar').css('width', Math.min(100, total / 100) + '%');
}

$(document).on('input change', '.kerp-installment-steps [data-for$="[percent]"]', function() {
    kerp_installment_update_progress($(this).closest('.kerp-installment-plan'));
});

$(function() {
    $('.kerp-installment-plan').each(function() { kerp_installment_update_progress(this); });
    let queued = false;
    new MutationObserver(function(changes) {
        const relevant = changes.some(change => Array.from(change.addedNodes).concat(Array.from(change.removedNodes))
            .some(node => node.nodeType === 1 && (node.matches('.repeater_row,.kerp-installment-plan') || node.querySelector('.kerp-installment-plan'))));
        if (!relevant || queued) return;
        queued = true;
        setTimeout(function() {
            queued = false;
            $('.kerp-installment-plan').each(function() { kerp_installment_update_progress(this); });
        }, 0);
    }).observe(document.body, {childList: true, subtree: true});
});
