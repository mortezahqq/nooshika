$(document).on('click', '.login_as_this', function(e) {
    e.preventDefault();
    let user_id = $(this).attr('data-id');
    let data = {
        action:  'login_as_user',
        user_id: user_id,
    };
    $.post(ajax_url, data, function(response) {
        window.location.reload();
    });
});
$(document).on('click', '.change_preferences', function(e) {
    e.preventDefault();
    let data = {
        action: $(this).attr('data-action'),
        value:  $(this).attr('data-value'),
    };
    $.post(ajax_url, data, function(response) {
        window.location.reload();
    });
});
$(document).on('click', '.kerp-restore-admin-session', function(e) {
    e.preventDefault();
    let data = {
        action: 'restore_admin_session',
    };
    $.post(ajax_url, data, function(response) {
        window.location.reload();
    });
});
$(document).on('click', '.reset_password', function(e) {
    e.preventDefault();
    let user_id = $(this).attr('data-id');
    let data = {
        action:  'reset_password',
        user_id: user_id,
    };
    $.post(ajax_url, data, function(response) {
        Swal.fire({
            title:             'رمز عبور تغییر کرد.',
            html:              response.html,
            focusConfirm:      false,
            confirmButtonText: 'باشه',
        });
    });
});

function kerp_get_profile_modal_scope(element) {
    let modal = $(element).closest('.modal');
    
    if (modal.length) {
        return modal;
    }
    
    return $(element).closest('.profile-image-modal-body');
}

function kerp_get_upload_zone_dropzone(scope) {
    let uploadZone = scope.find('.upload-zone').first()[0];
    
    if (!uploadZone) {
        return null;
    }
    
    if (uploadZone.dropzone) {
        return uploadZone.dropzone;
    }
    
    return null;
}

function kerp_stop_profile_webcam(scope) {
    let video = scope.find('.profile_webcam_video').first()[0];
    
    if (!video || !video.srcObject) {
        return;
    }
    
    video.srcObject.getTracks().forEach(function(track) {
        track.stop();
    });
    
    video.srcObject = null;
}

function kerp_canvas_to_file(canvas, filename) {
    return new Promise(function(resolve) {
        canvas.toBlob(function(blob) {
            if (!blob) {
                resolve(null);
                return;
            }
            
            let file = new File([blob], filename, {
                type:         'image/jpeg',
                lastModified: Date.now(),
            });
            
            resolve(file);
        }, 'image/jpeg', 0.92);
    });
}

$(document).on('click', '.start_profile_webcam', async function(e) {
    e.preventDefault();
    
    let scope = kerp_get_profile_modal_scope(this);
    let video = scope.find('.profile_webcam_video').first()[0];
    
    if (!video) {
        NioApp.Toast('بخش نمایش وبکم پیدا نشد', 'error', {
            position: 'top-right',
        });
        return;
    }
    
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        NioApp.Toast('مرورگر شما از وبکم پشتیبانی نمی‌کند', 'error', {
            position: 'top-right',
        });
        return;
    }
    
    try {
        let devices = await navigator.mediaDevices.enumerateDevices();
        
        let hasCamera = devices.some(function(device) {
            return device.kind === 'videoinput';
        });
        
        if (!hasCamera) {
            NioApp.Toast('وبکم متصل نیست', 'error', {
                position: 'top-right',
            });
            return;
        }
        
        /*
         * قبل از ایجاد استریم جدید، استریم قبلی متوقف شود.
         */
        kerp_stop_profile_webcam(scope);
        
        let stream = await navigator.mediaDevices.getUserMedia({
            video: {
                width:      500,
                height:     500,
                facingMode: 'user',
            },
            audio: false,
        });
        
        video.srcObject = stream;
        
        await video.play();
        
        scope.find('.profile_webcam_box').stop(true, true).slideDown(150);
    } catch (error) {
        NioApp.Toast('دسترسی به وبکم ممکن نیست', 'error', {
            position: 'top-right',
        });
    }
});

$(document).on('click', '.take_profile_webcam_screenshot', function(e) {
    e.preventDefault();
    
    let scope = kerp_get_profile_modal_scope(this);
    let video = scope.find('.profile_webcam_video').first()[0];
    let canvas = scope.find('.profile_webcam_canvas').first()[0];
    
    if (!video || !video.srcObject) {
        NioApp.Toast('ابتدا وبکم را فعال کنید', 'warning', {
            position: 'top-right',
        });
        return;
    }
    
    if (!canvas) {
        NioApp.Toast('بخش پیش‌نمایش تصویر پیدا نشد', 'error', {
            position: 'top-right',
        });
        return;
    }
    
    let context = canvas.getContext('2d');
    
    if (!context) {
        NioApp.Toast('ساخت پیش‌نمایش تصویر ممکن نیست', 'error', {
            position: 'top-right',
        });
        return;
    }
    
    context.drawImage(
        video,
        0,
        0,
        canvas.width,
        canvas.height,
    );
    
    canvas.setAttribute('data-has-image', '1');
});

$(document).on('click', '.upload_profile_webcam_to_dropzone', async function(e) {
    e.preventDefault();
    
    let scope = kerp_get_profile_modal_scope(this);
    let canvas = scope.find('.profile_webcam_canvas').first()[0];
    let dropzone = kerp_get_upload_zone_dropzone(scope);
    
    if (!canvas || canvas.getAttribute('data-has-image') !== '1') {
        NioApp.Toast('ابتدا پیش‌نمایش تصویر را بگیرید', 'warning', {
            position: 'top-right',
        });
        return;
    }
    
    if (!dropzone) {
        NioApp.Toast('آپلودزون پیدا نشد', 'error', {
            position: 'top-right',
        });
        return;
    }
    
    let file = await kerp_canvas_to_file(
        canvas,
        'kerp-profile-webcam-' + Date.now() + '.jpg',
    );
    
    if (!file) {
        NioApp.Toast('ساخت تصویر انجام نشد', 'error', {
            position: 'top-right',
        });
        return;
    }
    
    if (typeof dropzone.removeAllFiles === 'function') {
        dropzone.removeAllFiles(true);
    }
    
    dropzone.addFile(file);
    
    NioApp.Toast('تصویر وبکم به آپلودزون اضافه شد', 'success', {
        position: 'top-right',
    });
    
    kerp_stop_profile_webcam(scope);
    
    scope.find('.profile_webcam_box').stop(true, true).slideUp(150);
});

$(document).on('click', '.stop_profile_webcam', function(e) {
    e.preventDefault();
    
    let scope = kerp_get_profile_modal_scope(this);
    
    kerp_stop_profile_webcam(scope);
    
    scope.find('.profile_webcam_box').stop(true, true).slideUp(150);
});

$(document).on('hidden.bs.modal', '.modal', function() {
    kerp_stop_profile_webcam($(this));
});