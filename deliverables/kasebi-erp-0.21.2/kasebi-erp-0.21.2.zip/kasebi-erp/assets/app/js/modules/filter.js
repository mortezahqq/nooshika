function build_filter_hidden_values(context = document) {
    const $context = $(context);
    
    /**
     * =========================
     * Tri-state options
     * =========================
     * state  1  => include => :in
     * state -1  => exclude => :not-in
     * state  0  => ignore
     */
    $context.find('.kasebi-tri-filter-options').each(function() {
        const $wrapper = $(this);
        
        const include = [];
        const exclude = [];
        
        $wrapper.find('.kasebi-tri-filter-checkbox').each(function() {
            const $input = $(this);
            const state = parseInt($input.attr('data-state') || '0', 10);
            const value = String($input.data('value') || '').trim();
            
            if (!value) {
                return;
            }
            
            if (state === 1) {
                include.push(value);
            } else if (state === -1) {
                exclude.push(value);
            }
        });
        
        const parts = [];
        
        if (include.length) {
            parts.push(include.join(',') + ':in');
        }
        
        if (exclude.length) {
            parts.push(exclude.join(',') + ':not-in');
        }
        
        const firstTarget = $wrapper.find('.kasebi-tri-filter-checkbox').first().data('target');
        
        if (firstTarget) {
            $(firstTarget).val(parts.join(';'));
        } else {
            $wrapper.find('.kasebi-tri-filter-value').val(parts.join(';'));
        }
    });
    /**
     * =========================
     * Number / Price
     * =========================
     * output example:
     * 1200000:gte
     */
    $context.find('.kasebi-filter-number-value').each(function() {
        const $hidden = $(this);
        const targetId = $hidden.attr('id');
        
        if (!targetId) {
            return;
        }
        
        const $valueInput = $context.find('[data-target="' + targetId + '"][data-type="value"]');
        const $operatorInput = $context.find('[data-target="' + targetId + '"][data-type="operator"]');
        
        let value = String($valueInput.val() || '').trim();
        const operator = String($operatorInput.val() || 'eq').trim();
        
        value = value.replace(/,/g, '');
        
        if ($valueInput.hasClass('price_input')) {
            value = value.replace(/\D/g, '');
        }
        
        if (!value) {
            $hidden.val('');
            return;
        }
        
        $hidden.val(value + ':' + operator);
    });
    /**
     * =========================
     * Date range
     * =========================
     * output example:
     * 1400-01-01...1402-01-01
     */
    $context.find('.kasebi-filter-date-range-value').each(function() {
        const $hidden = $(this);
        const targetId = $hidden.attr('id');
        
        if (!targetId) {
            return;
        }
        
        const from = String($context.find('[data-target="' + targetId + '"][data-type="from"]').val() || '').trim();
        const to = String($context.find('[data-target="' + targetId + '"][data-type="to"]').val() || '').trim();
        
        if (!from && !to) {
            $hidden.val('');
            return;
        }
        
        if (from && to) {
            $hidden.val(from + '...' + to);
            return;
        }
        
        if (from) {
            $hidden.val(from + ':gte');
            return;
        }
        
        if (to) {
            $hidden.val(to + ':lte');
        }
    });
}

function get_current_page_filters(context = document) {
    build_filter_hidden_values('.filter_form_wrapper');
    
    const data = {};
    
    $(context).find('.filter_form_wrapper .kerp-filter-input, .kerp-table-search[data-for], .kerp-list-context.kerp-filter-input').each(function() {
        const $el = $(this);
        const key = $el.data('for');
        const val = $el.val();
        const type = $el.attr('type');
        
        if (!key || $el.prop('disabled')) {
            return;
        }
        
        if (type === 'radio' && !$el.prop('checked')) {
            return;
        }
        
        if (type === 'checkbox' && !$el.prop('checked')) {
            return;
        }
        
        if (val === '' || val === null || typeof val === 'undefined') {
            return;
        }

        // Select placeholders use "0" for "all". Sending that value turns an
        // empty filter into a real query constraint during AJAX pagination.
        if ($el.is('select') && String(val) === '0') {
            return;
        }
        
        data[key] = val;
    });
    
    return data;
}

$(document).on('change', '.kasebi-tri-filter-checkbox', function(e) {
    const $btn = $(this);
    
    let state = parseInt($btn.attr('data-state') || '0', 10);
    if (state === 0) {
        state = 1;
    } else if (state === 1) {
        state = -1;
    } else {
        state = 0;
    }
    $btn.attr('data-state', state);
    
    $btn.parent().removeClass('is-include is-exclude').find('em.icon').removeClass('ni-square-c ni-check-c ni-cross-c');
    
    if (state === 1) {
        $btn.parent().addClass('is-include');
        $btn.parent().find('em.icon').addClass('ni-check-c');
    } else if (state === -1) {
        $btn.parent().addClass('is-exclude');
        $btn.parent().find('em.icon').addClass('ni-cross-c');
    } else {
        $btn.parent().find('em.icon').addClass('ni-square-c');
    }
    
    build_filter_hidden_values('.filter_form_wrapper');
});
$(document).on('click', '.filter_erp_list', function(event) {
    event.preventDefault();
    ajax_search = false;
    let data = get_current_page_filters();
    data.action = $(this).attr('data-action');
    data.page = $(this).attr('data-page');
    data.page_number = 1;
    kerpRequestPage(data);
});
$(document).on('click', '.user_sort_link', function(e) {
    e.preventDefault();
    
    let orderby = $(this).data('orderby');
    let order = $(this).data('order');
    
    if (!orderby || !order) {
        return;
    }
    
    let data = get_current_page_filters();
    
    data.action = 'erp_request_page_content';
    data.page = 'users';
    data.page_number = 1;
    data.orderby = orderby;
    data.order = order;
    
    kerpRequestPage(data);
});
$(document).on('click', '.change_per_page', function(e) {
    if ($(this).closest('#kerp-employees-list').length) return;
    e.preventDefault();
    let data = {
        ...get_current_page_filters(),
        action:   $(this).attr('data-action'),
        page:     $(this).attr('data-page'),
        per_page: $(this).attr('data-per-page'),
        page_number: 1,
    };
    kerpRequestPage(data);
});
$(document).on('click', '.reset_page_filter', function(e) {
    e.preventDefault();
    let data = {
        action: 'erp_request_page_content',
        page:   $(this).attr('data-page'),
    };
    kerpRequestPage(data);
});
$(document).on('click', '.page-item', function(e) {
    if ($(this).closest('#kerp-employees-list').length) return;
    e.preventDefault();
    if ($(this).hasClass('disabled')) {
        return;
    }
    let page = $(this).attr('data-page');
    let data = get_current_page_filters();
    let currentOrderby = $('#current_orderby').val();
    let currentOrder = $('#current_order').val();
    data.action = $(this).attr('data-action');
    data.page = $(this).attr('data-route');
    data.page_number = page;
    if (currentOrderby) {
        data.orderby = currentOrderby;
    }
    if (currentOrder) {
        data.order = currentOrder;
    }
    kerpRequestPage(data);
});
$(document).on('click', '.kasebi-filter-group-toggle', function(e) {
    e.preventDefault();
    const $toggle = $(this);
    const $target = $toggle.attr('data-target');
    $($target).slideToggle();
});
$(document).on('click', '.open-dropdown', function(e) {
    e.preventDefault();
    const $toggle = $(this);
    const $dropdown = $toggle.closest('.drop-down');
    const $menu = $dropdown.find('.dropdown-menu').first();
    
    $('.filter_form_wrapper.show').not($menu).removeClass('show');
    $('.drop-down.is-open').not($dropdown).removeClass('is-open');
    
    $menu.toggleClass('show');
    $dropdown.toggleClass('is-open', $menu.hasClass('show'));
});
$(document).on('click', function(e) {
    if ($(e.target).closest('.drop-down').length > 0) {
        return; // اگر داخل فرم بود، هیچ کاری انجام نده
    }
    
    $('.drop-down .dropdown-menu.show').removeClass('show');
    $('.drop-down.is-open').removeClass('is-open');
});
$(document).on('change', '.select_all_rows', function() {
    kerp_handle_select_all_rows($(this));
});

$(document).on('change', '.select_item_row', function() {
    kerp_handle_select_item_row($(this));
});
$(document).on('click', '.row_bulk_actions', function(e) {
    e.preventDefault();
    const $actionItem = $(this);
    if ($actionItem.data('processing')) {
        return;
    }
    const ajaxAction = $.trim($actionItem.attr('data-action') || '');
    const operation = $.trim($actionItem.attr('data-operation') || '');
    const operationAction = $.trim($actionItem.attr('data-operation-action') || '');
    const page = $.trim($actionItem.attr('data-page') || $('#current_page').val() || '');
    const itemSelector = $.trim($actionItem.attr('data-item-selector') || '.select_item_row');
    const actionLabel = $.trim($actionItem.find('span').first().text()) || $.trim($actionItem.text()) ||
        $actionItem.attr('title') || 'تایید عملیات';
    if (!ajaxAction || !operation) {
        NioApp.Toast('اطلاعات عملیات گروهی ناقص است.', 'danger', {position: 'top-right'});
        return;
    }
    const customerIds = [];
    $(itemSelector).filter(':checked').each(function() {
        const customerId = parseInt($(this).val() || $(this).attr('data-id') || 0, 10);
        if (customerId > 0 && !customerIds.includes(customerId)) {
            customerIds.push(customerId);
        }
    });
    if (!customerIds.length) {
        NioApp.Toast('حداقل یک مورد را انتخاب کنید.', 'warning', {position: 'top-right'});
        return;
    }
    let needs = $actionItem.attr('data-needs');
    try {
        needs = needs && needs !== 'null' ? JSON.parse(needs) : null;
    } catch (error) {
        needs = null;
    }
    const needFields = needs
                       ? (Array.isArray(needs) ? needs : (Array.isArray(needs.needs) ? needs.needs : null))
                       : null;
    if (needFields && needFields.length === 1 && needFields[0].type === 'modal') {
        const modalField = needFields[0];
        if (modalField.itemsInput) {
            const selector = String(modalField.itemsInput).startsWith('#') ? modalField.itemsInput : '#' +
                modalField.itemsInput;
            $(selector).val(customerIds.join(',')).trigger('change');
        }
        if (modalField.operationInput) {
            const selector = String(modalField.operationInput).startsWith('#') ? modalField.operationInput : '#' +
                modalField.operationInput;
            $(selector).val(operation).trigger('change');
        }
        if (modalField.actionInput) {
            const selector = String(modalField.actionInput).startsWith('#') ? modalField.actionInput : '#' +
                modalField.actionInput;
            $(selector).val(operationAction || ajaxAction).trigger('change');
        }
        if (modalField.pageInput) {
            const selector = String(modalField.pageInput).startsWith('#') ? modalField.pageInput : '#' +
                modalField.pageInput;
            $(selector).val(page).trigger('change');
        }
        if (modalField.modalId) {
            const selector = String(modalField.modalId).startsWith('#') ? modalField.modalId : '#' + modalField.modalId;
            $(selector).modal('show');
        }
        return;
    }
    Swal.fire({
        title:             actionLabel,
        icon:              'warning',
        html:              buildNeedsHtml(needFields, customerIds.length, actionLabel),
        focusConfirm:      false,
        showCancelButton:  true,
        confirmButtonText: 'تایید',
        cancelButtonText:  'لغو',
        preConfirm:        function() {
            const values = collectNeedsValues(needFields);
            const missingField = (needFields || []).find(function(field) {
                if (!field || field.type === 'modal') {
                    return false;
                }
                const key = field.key || field.name;
                if (!key || !field.required) {
                    return false;
                }
                const value = values[key];
                return typeof value === 'undefined' || value === null || String(value).trim() === '';
            });
            if (missingField) {
                Swal.showValidationMessage(
                    `لطفاً «${missingField.label || missingField.key || 'فیلد موردنیاز'}» را تکمیل کنید.`);
                return false;
            }
            return values;
        },
        onRender:          function() {
            if (typeof activate_date_pickers === 'function') {
                activate_date_pickers();
            }
        },
    }).then(function(result) {
        if (!result.isConfirmed) {
            return;
        }
        const payload = result.value || {};
        const data = typeof get_current_page_filters === 'function' ? get_current_page_filters() : {};
        data.action = ajaxAction;
        data.page = page;
        data.bulk_action = operation;
        data.operation = operation;
        data.operation_action = operationAction;
        data.customer_ids = customerIds;
        data.payload = payload;
        $actionItem.data('processing', true);
        $.post(ajax_url, data).done(function(response) {
            if (!response) {
                NioApp.Toast('پاسخ معتبری از سرور دریافت نشد.', 'danger', {position: 'top-right'});
                return;
            }
            change_panel_html(response);
        }).fail(function(xhr) {
            let message = 'اجرای عملیات گروهی با خطا روبه‌رو شد.';
            if (xhr.responseJSON && (xhr.responseJSON.message || xhr.responseJSON.msg)) {
                message = xhr.responseJSON.message || xhr.responseJSON.msg;
            }
            NioApp.Toast(message, 'danger', {position: 'top-right'});
        }).always(function() {
            $actionItem.data('processing', false);
        });
    });
});

// Conditional list filters are cleared as soon as their parent no longer matches.
function kerp_sync_dependent_list_filters($wrapper) {
    $wrapper.find('[data-filter-parent]').each(function() {
        const $row = $(this);
        const parent = $row.attr('data-filter-parent');
        const $parents = $wrapper.find('[data-for]').filter(function() { return $(this).attr('data-for') === parent; });
        const $parent = $parents.first().is(':radio') ? $parents.filter(':checked').first() : $parents.first();
        const parentValue = String($parent.val() || '');
        const visible = $row.attr('data-filter-parent-operator') === 'selected'
            ? parentValue !== '' && parentValue !== '0'
            : $row.attr('data-filter-parent-operator') === 'in'
                ? String($row.attr('data-filter-parent-value') || '').split('|').includes(parentValue)
                : parentValue === $row.attr('data-filter-parent-value');
        $row.toggleClass('d-none', !visible);
        $row.find('input, select, textarea').prop('disabled', !visible).each(function() {
            if (!visible) {
                if ($(this).is(':radio, :checkbox')) {
                    $(this).prop('checked', $(this).is(':radio') && this.value === '');
                } else {
                    $(this).val($(this).is('select') ? '0' : '').trigger('change.select2');
                }
            }
        });
    });
}
$(document).on('change', '.filter_form_wrapper [data-for]', function() {
    kerp_sync_dependent_list_filters($(this).closest('.filter_form_wrapper'));
});
$(document).on('shown.bs.dropdown', '.dropdown', function() {
    $(this).find('.filter_form_wrapper').each(function() { kerp_sync_dependent_list_filters($(this)); });
});
