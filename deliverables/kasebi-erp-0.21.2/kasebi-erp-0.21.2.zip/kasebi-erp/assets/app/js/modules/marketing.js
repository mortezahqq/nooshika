// Marketing uses the shared modal, list, selection and AJAX lifecycle.
function kerpMarketingNumber(value) {
    return Number(String(value || '').replace(/[۰-۹]/g, function(d) { return '۰۱۲۳۴۵۶۷۸۹'.indexOf(d); }).replace(/[٠-٩]/g, function(d) { return '٠١٢٣٤٥٦٧٨٩'.indexOf(d); }).replace(/[,٬\s]/g, ''));
}
function kerpMarketingRoi() {
    const $modal = $('#marketingRequestModal');
    const cost = kerpMarketingNumber($modal.find('[data-for="cost"]').val());
    const sales = kerpMarketingNumber($modal.find('[data-for="expected_sales"]').val());
    $modal.find('[data-marketing-roi]').text(cost > 0 && sales >= 0 && Number.isFinite(sales / cost) ? (sales / cost).toLocaleString('fa-IR', {maximumFractionDigits: 2}) : '—');
}
$(document).on('input', '#marketingRequestModal [data-for="cost"], #marketingRequestModal [data-for="expected_sales"]', kerpMarketingRoi);
$(document).on('shown.bs.modal', '#marketingRequestModal', kerpMarketingRoi);
$(document).on('blur', '#marketingRequestModal [data-for="execution_date"]', function() {
    this.value = this.value.replace(/[۰-۹]/g, function(d) { return '۰۱۲۳۴۵۶۷۸۹'.indexOf(d); }).replace(/[٠-٩]/g, function(d) { return '٠١٢٣٤٥٦٧٨٩'.indexOf(d); }).replace(/\//g, '-');
});
function kerpMarketingDailyEntry() {
    const $modal = $('#marketingMetricModal');
    const source = $modal.find('[data-for="source_id"]').val();
    const rawDate = String($modal.find('[data-for="metric_date"]').val() || '');
    let date = rawDate.replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/\//g, '-');
    date = date.trim().split('-').map((part, index) => index ? part.trim().padStart(2, '0') : part.trim()).join('-');
    const selection = source + ':' + date;
    if ($modal.data('daily-selection') === selection) return;
    $modal.data('daily-selection', selection);
    let entries = [];
    try { entries = JSON.parse($modal.find('[data-marketing-daily]').attr('data-marketing-daily') || '[]'); } catch (error) { return; }
    const entry = entries.find(item => item.source_id === source && item.jalali_date === date);
    $modal.find('[data-for="entry_key"]').val(entry ? entry.entry_key : '');
    ['numbers', 'online', 'pre_reg', 'cost', 'sales'].forEach(key => $modal.find('[data-for="' + key + '"]').val(entry ? entry[key] : '').trigger('input'));
    $modal.find('[data-marketing-daily-hint]').text(entry ? 'آمار این روز قبلاً ثبت شده است؛ در حال ویرایش همان روز هستید.' : 'فقط آمار همین روز را وارد کنید؛ جمع روزها خودکار محاسبه می‌شود.');
}
$(document).on('change blur', '#marketingMetricModal [data-for="source_id"], #marketingMetricModal [data-for="metric_date"]', kerpMarketingDailyEntry);
$(document).on('show.bs.modal', '[id^="marketing"]', function() {
    $(this).find('.submit_modal_form').attr({role: 'button', tabindex: '0'});
    $(this).find('.price_input').attr({'data-decimal': '1', 'data-decimal-places': '2', inputmode: 'decimal'}).data('decimal', 1).data('decimal-places', 2).trigger('input');
});
$(document).on('keydown', '[id^="marketing"] .submit_modal_form', function(event) {
    if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); $(this).trigger('click'); }
});
$(document).on('submit', '.modal_form[data-action^="marketing_"]', function(event) {
    event.preventDefault();
    $(this).find('.submit_modal_form').first().trigger('click');
});
// The shared bulk component sends its own payload; attach this module's CSRF token only.
$.ajaxPrefilter(function(options) {
    if (typeof options.data === 'string' && /(?:^|&)action=marketing_bulk(?:&|$)/.test(options.data)) {
        options.data += '&marketing_nonce=' + encodeURIComponent($('.kerp-marketing[data-marketing-nonce]').attr('data-marketing-nonce') || '');
    }
});
