$(document).on('click', '.kerp-sms-log-delete', function() {
    $('#kerp-sms-log-ids').val($(this).attr('data-id'));
    $('#kerp-sms-log-operation').val('delete');
});
