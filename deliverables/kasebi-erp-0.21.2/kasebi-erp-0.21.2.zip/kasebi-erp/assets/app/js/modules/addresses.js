function kerp_addresses_get_order_form(element) {
    return $(element).closest('.kerp-order-form');
}

function kerp_addresses_reload_order_block(element) {
    console.log(element);
    let form = kerp_addresses_get_order_form(element);
    let block = form.find('.kerp-order-address-section').first();
    let customerId = parseInt($(element).val() || '0', 10);
    let orderId = parseInt(form.find('[data-for="order_id"]').first().val() || '0', 10);
    
    if (!form.length || !block.length) {
        return;
    }
    
    $.post(
        ajax_url,
        {
            action:      'addresses_get_order_block',
            customer_id: customerId,
            order_id:    orderId,
        },
    ).done(function(response) {
        if (response.status !== 'success' || !response.html) {
            NioApp.Toast(
                response.message || 'خطا در دریافت آدرس‌های کاربر',
                response.status || 'error',
                {
                    position: 'top-right',
                },
            );
            return;
        }
        
        block.replaceWith(response.html);
    });
}

function kerp_addresses_select_order_address(element) {
    let block = $(element).closest('.kerp-order-address-section');
    let addressId = $(element).val() || '';
    
    block.find('.kerp-order-address-option').removeClass('border-primary');
    $(element).closest('.kerp-order-address-option').addClass('border-primary');
    block.find('[data-for="address_id"]').first().val(addressId).trigger('change');
}

function kerp_addresses_set_default(element) {
    let button = $(element);
    let data = {
        action:      button.attr('data-action') || 'addresses_set_default',
        page:        button.attr('data-page') || '',
        customer_id: button.attr('data-customer_id') || '',
        address_id:  button.attr('data-address_id') || '',
    };
    
    if (!data.customer_id || !data.address_id) {
        return;
    }
    
    button.addClass('disabled');
    
    $.post(ajax_url, data).done(function(response) {
        if (response.status !== 'success') {
            NioApp.Toast(
                response.message || 'خطا در تغییر آدرس پیش‌فرض',
                response.status || 'error',
                {
                    position: 'top-right',
                },
            );
            return;
        }
        
        change_panel_html(response);
    }).always(function() {
        button.removeClass('disabled');
    });
}

$(document).on('change', '.kerp-order-form [data-for="customer_id"]', function() {
    kerp_addresses_reload_order_block(this);
});

$(document).on('change', '.kerp-order-address-choice', function() {
    kerp_addresses_select_order_address(this);
});

$(document).on('click', '.kerp-address-set-default', function(e) {
    e.preventDefault();
    kerp_addresses_set_default(this);
});

function kerp_addresses_apply_order_block_response(response) {
    if (
        !response ||
        response.status !== 'success' ||
        !response.address_block_html
    ) {
        return;
    }
    
    let block = $('.kerp-order-address-section').first();
    
    if (!block.length) {
        return;
    }
    
    block.replaceWith(response.address_block_html);
}

$(document).ajaxSuccess(function(event, xhr) {
    let response = xhr.responseJSON;
    
    kerp_addresses_apply_order_block_response(response);
});