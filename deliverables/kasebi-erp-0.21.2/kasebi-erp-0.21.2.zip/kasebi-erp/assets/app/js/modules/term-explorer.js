const instances = new WeakMap();
const escape = value => $('<span>').text(String(value ?? '')).html();
const normalize = value => String(value || '').
    toLowerCase().
    replace(/ي/g, 'ی').
    replace(/ك/g, 'ک').
    replace(/[\u064b-\u065f\u200c]/g, '').
    trim();
const number = value => Number(value || 0).toLocaleString('fa-IR');

class Explorer {
    constructor(root) {
        this.root = root;
        this.$root = $(root);
        this.key = 'kerp-explorer-' + root.dataset.user + '-' + root.dataset.taxonomy;
        this.state = {
            open:     {},
            selected: 0,
        };
        try {
            const saved = JSON.parse(localStorage.getItem(this.key));
            if (saved && typeof saved.open === 'object' && saved.open) {
                this.state = saved;
            }
        } catch (_) {}
        this.selected = Number(root.dataset.focus || this.state.selected || 0);
        this.terms = [];
        this.map = new Map();
        this.sequence = 0;
        this.busy = false;
        this.bind();
        this.load();
    }
    
    persist() {
        this.state.selected = this.selected;
        try { localStorage.setItem(this.key, JSON.stringify(this.state)); } catch (_) {}
    }
    
    request(operation, data = {}) {
        return new Promise((resolve, reject) => {
            $.ajax({
                url:      ajax_url,
                method:   'POST',
                dataType: 'json',
                timeout:  30000,
                data:     {
                    action:      'programs_term_explorer',
                    nonce:       this.root.dataset.nonce,
                    taxonomy_id: this.root.dataset.taxonomy,
                    operation, ...data,
                },
            }).done(result => {
                if (result && result.status === 'success' && Array.isArray(result.terms)) {
                    resolve(result.terms);
                } else {
                    reject(new Error(result?.message || result?.msg || 'دریافت اطلاعات انجام نشد.'));
                }
            }).fail(() => reject(new Error('ارتباط با سرور برقرار نشد؛ دوباره تلاش کنید.')));
        });
    }
    
    setTerms(terms) {
        this.terms = terms.map(item => ({
            ...item,
            id:        Number(item.id),
            parent_id: Number(item.parent_id),
        }));
        this.map = new Map(this.terms.map(item => [item.id, item]));
        this.children = new Map();
        this.terms.forEach(item => {
            const parent = this.map.has(item.parent_id) && item.parent_id !== item.id ? item.parent_id : 0;
            if (!this.children.has(parent)) {
                this.children.set(parent, []);
            }
            this.children.get(parent).push(item);
        });
        if (!this.map.has(this.selected)) {
            this.selected = 0;
        }
        this.persist();
    }
    
    path(id) {
        const path    = [],
              visited = new Set();
        while (this.map.has(id) && !visited.has(id)) {
            visited.add(id);
            const item = this.map.get(id);
            path.unshift(item);
            id = item.parent_id;
        }
        return path;
    }
    
    descendants(id) {
        const found = new Set(),
              queue = [id];
        while (queue.length) {
            (this.children.get(queue.pop()) || []).forEach(child => {
                if (child.id !== id && !found.has(child.id)) {
                    found.add(child.id);
                    queue.push(child.id);
                }
            });
        }
        return found;
    }
    
    reveal(id) {
        this.path(id).forEach(item => { this.state.open[item.id] = true; });
        this.persist();
    }
    
    icon(item) {
        const icons = ['ni ni-folder', 'ni ni-book', 'ni ni-tag', 'ni ni-layers', 'ni ni-file-text', 'ni ni-star'];
        const colors = ['blue', 'green', 'purple', 'orange', 'red', 'gray'];
        return `<em aria-hidden="true" class="icon ${icons.includes(item.icon)
                                                     ? item.icon
                                                     : 'ni ni-folder'} ke-color-${colors.includes(item.color)
                                                                                  ? item.color
                                                                                  : 'blue'}"></em>`;
    }
    
    menu(item) {
        return `<details class="ke-menu"><summary aria-label="عملیات ${escape(item.name)}"><em class="icon ni ni-more-h"></em></summary><div class="ke-menu-items">
                <button type="button" data-command="edit" data-id="${item.id}">ویرایش</button>
                <button type="button" data-command="add" data-id="${item.id}">افزودن زیرمجموعه</button>
                <button type="button" data-command="status" data-id="${item.id}">${item.active
                                                                                   ? 'غیرفعال کردن'
                                                                                   : 'فعال کردن'}</button>
                <button type="button" data-command="move" data-id="${item.id}">تغییر والد</button>
                <button type="button" data-command="up" data-id="${item.id}">انتقال به بالا</button>
                <button type="button" data-command="down" data-id="${item.id}">انتقال به پایین</button>
                <button type="button" class="text-danger" data-command="delete" data-id="${item.id}" ${item.can_delete
                                                                                                       ? ''
                                                                                                       : 'disabled title="دارای زیرمجموعه یا استفاده در برنامه است"'}>حذف</button>
            </div></details>`;
    }
    
    renderTree() {
        const query = normalize(this.$root.find('.ke-search').val());
        const visible = new Set();
        if (query) {
            this.terms.forEach(item => {
                if (normalize(item.name + ' ' + item.slug).includes(query)) {
                    this.path(item.id).
                        forEach(parent => visible.add(parent.id));
                }
            });
        }
        const visited = new Set();
        const render = (item, level) => {
            if (visited.has(item.id) || (query && !visible.has(item.id))) {
                return '';
            }
            visited.add(item.id);
            const children = this.children.get(item.id) || [];
            const open = query ? true : (this.state.open[item.id] ?? level === 1);
            const selected = this.selected === item.id;
            return `<div class="ke-node" role="treeitem" aria-level="${level}" aria-selected="${selected}" ${children.length
                                                                                                             ? `aria-expanded="${open}"`
                                                                                                             : ''} data-node="${item.id}">
                    <div class="ke-row ${selected ? 'is-selected' : ''} ${item.active
                                                                          ? ''
                                                                          : 'is-inactive'}" data-row="${item.id}" draggable="${!query &&
            !this.busy}">
                    <button type="button" class="ke-toggle" data-toggle="${item.id}" aria-label="${open
                                                                                                   ? 'بستن'
                                                                                                   : 'بازکردن'} زیرمجموعه‌های ${escape(
                item.name)}" aria-expanded="${open}" ${children.length
                                                       ? ''
                                                       : 'disabled'}><em class="icon ni ${children.length
                                                                                          ? (open
                                                                                             ? 'ni-chevron-down'
                                                                                             : 'ni-chevron-left')
                                                                                          : 'ni-minus'}"></em></button>
                    <button type="button" class="ke-label" data-select="${item.id}">${this.icon(item)}<span>${escape(
                item.name)}</span>${!item.active ? '<small>غیرفعال</small>' : ''}</button>
                    <small class="ke-count" title="زیرمجموعه‌های مستقیم">${number(children.length)}</small>${this.menu(
                item)}</div>
                    ${children.length ? `<div class="ke-branches" role="group" ${open ? '' : 'hidden'}>${children.map(
                child => render(child, level + 1)).join('')}</div>` : ''}</div>`;
        };
        let html = (this.children.get(0) || []).map(item => render(item, 1)).join('');
        // Keep malformed legacy branches discoverable without infinite recursion.
        this.terms.forEach(item => {
            if (!visited.has(item.id)) {
                html += render(item, 1);
            }
        });
        this.$root.find('.ke-tree').
            html(html || `<div class="ke-empty">${query
                                                  ? 'نتیجه‌ای برای جستجو پیدا نشد.'
                                                  : 'دسته‌ای وجود ندارد؛ اولین دسته را اضافه کنید.'}</div>`);
    }
    
    renderDetails() {
        const item = this.map.get(this.selected);
        const panel = this.$root.find('.ke-details');
        if (!item) {
            panel.html(
                '<div class="ke-empty"><em class="icon ni ni-folder"></em><p>یک دسته را از درخت انتخاب کنید.</p></div>');
            return;
        }
        const children = this.children.get(item.id) || [];
        const crumbs = this.path(item.id).
            map(parent => `<button type="button" data-select="${parent.id}" ${parent.id === item.id
                                                                              ? 'aria-current="page"'
                                                                              : ''}>${escape(
                parent.name)}</button>`).
            join('<span aria-hidden="true"> / </span>');
        panel.html(`<nav class="ke-breadcrumb" aria-label="مسیر دسته">${crumbs}</nav>
                <div class="ke-identity">${this.icon(item)}<div><h4>${escape(
            item.name)}</h4><span class="badge ${item.active ? 'bg-success-dim' : 'bg-secondary-dim'}">${item.active
                                                                                                         ? 'فعال'
                                                                                                         : 'غیرفعال'}</span></div>${this.menu(
            item)}</div>
                ${item.active
                  ? ''
                  : '<p class="ke-inactive-message">این دسته غیرفعال است و در انتخاب‌های فعال برنامه نمایش داده نمی‌شود.</p>'}
                <dl class="ke-facts"><div><dt>کلید</dt><dd><bdi>${escape(
            item.slug)}</bdi></dd></div><div><dt>کل زیرمجموعه‌ها</dt><dd>${number(
            this.descendants(item.id).size)}</dd></div><div><dt>فرزندان مستقیم</dt><dd>${number(
            children.length)}</dd></div><div><dt>استفاده در برنامه</dt><dd>${number(item.usage)}</dd></div></dl>
                <p class="ke-description">${escape(item.description || 'توضیحی ثبت نشده است.')}</p>
                <div class="ke-detail-actions"><button type="button" class="btn btn-outline-primary" data-command="edit" data-id="${item.id}">ویرایش</button><button type="button" class="btn btn-primary" data-command="add" data-id="${item.id}">افزودن زیرمجموعه</button></div>
                <h6 class="ke-children-heading">زیرمجموعه‌های مستقیم <small>(${number(children.length)})</small></h6>
                <div class="ke-child-list">${children.length ? children.map(
                child => `<article class="ke-child ${child.active
                                                     ? ''
                                                     : 'is-inactive'}"><div class="ke-child-title">${this.icon(
                    child)}<button type="button" data-select="${child.id}">${escape(child.name)}</button>${this.menu(
                    child)}</div><p>${escape(
                    child.description || 'بدون توضیحات')}</p><div class="ke-child-footer"><span>${child.active
                                                                                                  ? 'فعال'
                                                                                                  : 'غیرفعال'} · ${number(
                    child.children_count)} فرزند</span><button type="button" class="btn btn-sm btn-outline-light" data-select="${child.id}">ورود به دسته <em class="icon ni ni-arrow-right"></em></button></div></article>`).
            join('') : '<div class="ke-empty">این دسته زیرمجموعه‌ای ندارد.</div>'}</div>`);
    }
    
    notice(message, error = false) {
        this.$root.find('.ke-notice').prop('hidden', !message).toggleClass('is-error', error).text(message);
    }
    
    async load(id = this.selected) {
        if (this.busy) {
            return;
        }
        const sequence = ++this.sequence;
        if (id) {
            this.selected = id;
        }
        this.$root.find('.ke-panel').attr('aria-busy', 'true');
        if (id) {
            this.$root.find('.ke-details').
                html('<div class="ke-empty" role="status">در حال بارگذاری اطلاعات…</div>');
        }
        try {
            const terms = await this.request(id ? 'details' : 'list', {term_id: id});
            if (sequence !== this.sequence || !this.root.isConnected) {
                return;
            }
            this.setTerms(terms);
            this.reveal(this.selected);
            this.renderTree();
            this.renderDetails();
            this.notice('');
        } catch (error) {
            if (sequence !== this.sequence || !this.root.isConnected) {
                return;
            }
            this.$root.find('.ke-details').
                html(`<div class="ke-empty" role="alert">${escape(
                    error.message)}<button type="button" class="btn btn-outline-primary ke-retry">تلاش دوباره</button></div>`);
            if (!this.terms.length) {
                this.$root.find('.ke-tree').
                    html(
                        '<div class="ke-empty">بارگذاری دسته‌ها انجام نشد.<button type="button" class="btn ke-retry">تلاش دوباره</button></div>');
            }
            this.notice(error.message, true);
        } finally {
            if (sequence === this.sequence) {
                this.$root.find('.ke-panel').attr('aria-busy', 'false');
            }
        }
    }
    
    select(id, trigger) {
        if (this.busy || !this.map.has(id)) {
            return;
        }
        this.lastTrigger = trigger;
        this.selected = id;
        this.reveal(id);
        this.renderTree();
        this.$root.find(`[data-row="${id}"]`)[0]?.scrollIntoView({block: 'nearest'});
        if (window.matchMedia('(max-width: 767px)').matches) {
            this.$root.addClass('is-sheet-open').find('.ke-backdrop').prop('hidden', false);
            this.$root.find('.ke-panel').
                attr({
                    role:         'dialog',
                    'aria-modal': 'true',
                });
            this.$root.find('.ke-sidebar')[0].inert = true;
            this.$root.find('.ke-close').trigger('focus');
        }
        this.load(id);
    }
    
    closeSheet() {
        this.$root.removeClass('is-sheet-open').find('.ke-backdrop').prop('hidden', true);
        this.$root.find('.ke-panel').removeAttr('role aria-modal');
        this.$root.find('.ke-sidebar')[0].inert = false;
        (this.lastTrigger?.isConnected ? this.lastTrigger : this.$root.find(
            `[data-select="${this.selected}"]`)[0])?.focus();
    }
    
    async mutate(operation, data) {
        if (this.busy) {
            return;
        }
        this.busy = true;
        ++this.sequence;
        this.$root.attr('aria-busy', 'true');
        this.notice('در حال ذخیره…');
        try {
            const terms = await this.request(operation, data);
            if (!this.root.isConnected) {
                return;
            }
            this.setTerms(terms);
            if (operation === 'move') {
                this.selected = Number(data.term_id);
                this.reveal(this.selected);
            }
            this.renderTree();
            this.renderDetails();
            this.notice('تغییرات ذخیره شد.');
        } catch (error) {
            this.notice(error.message + ' برای بررسی وضعیت فعلی، اطلاعات را دوباره بارگذاری کنید.', true);
        } finally {
            this.busy = false;
            this.$root.attr('aria-busy', 'false');
            this.$root.find('.ke-panel').attr('aria-busy', 'false');
        }
    }
    
    form(id, add = false) {
        if (this.busy) {
            return;
        }
        const item = this.map.get(id);
        const taxonomy = this.root.dataset.taxonomy;
        const prefix = '#kerp-program-term-' + taxonomy;
        const fields = {
            term_id:     ['', 'text', 'id'],
            taxonomy_id: [taxonomy, 'text', 'taxonomy-id'],
            return_page: ['/erp/programs/settings/terms/?taxonomy_id=' + taxonomy, 'text', 'return-page'],
            name:        ['', 'text', 'name'],
            slug:        ['', 'text', 'slug'],
            description: ['', 'text', 'description'],
            parent_id:   [add ? id : 0, 'select', 'parent-id'],
            sort_order:  [10, 'text', 'sort-order'],
            active:      [1, 'switch', 'active'],
            icon:        ['ni ni-folder', 'select', 'icon'],
            color:       ['blue', 'select', 'color'],
        };
        if (item && !add) {
            Object.keys(fields).
                forEach(key => {
                    if (key === 'term_id') {
                        fields[key][0] = item.id;
                    } else if (key in item) {
                        fields[key][0] = item[key];
                    }
                });
        }
        const modal = $('#programTermModal' + taxonomy);
        const parent = modal.find('[name="parent_id"]');
        parent.empty().append($('<option>').val(0).text('بدون والد (گزینهٔ اصلی)'));
        const excluded = !add && item ? this.descendants(id).add(id) : new Set();
        this.terms.forEach(term => {
            if (!excluded.has(term.id)) {
                parent.append(
                    $('<option>').val(term.id).text(this.path(term.id).map(node => node.name).join(' / ')));
            }
        });
        const populate = {};
        Object.entries(fields).
            forEach(([key, [value, type, suffix]]) => {
                populate[key] = {
                    id: prefix + '-' + suffix,
                    type,
                    value,
                };
            });
        this.closeSheet();
        const button = $('<button type="button" class="open_populate_modal" hidden>').
            attr('data-modal', '#programTermModal' + taxonomy).
            attr('data-populate', JSON.stringify(populate)).
            appendTo(this.root);
        button.trigger('click').remove();
    }
    
    moveDialog(id) {
        this.moveId = id;
        const excluded = this.descendants(id).add(id);
        const modal = $('#programTermMoveModal' + this.root.dataset.taxonomy);
        const select = modal.find('.ke-destination').empty().append($('<option>').val(0).text('سطح اصلی'));
        this.terms.forEach(item => {
            if (!excluded.has(item.id)) {
                select.append(
                    $('<option>').val(item.id).text(this.path(item.id).map(node => node.name).join(' / ')));
            }
        });
        select.val(this.map.get(id).parent_id);
        select.trigger('change');
        modal.modal('show');
    }
    
    command(command, id) {
        if (this.busy) {
            return;
        }
        this.$root.find('.ke-menu').removeAttr('open');
        const item = this.map.get(id);
        if (!item) {
            return;
        }
        if (command === 'edit' || command === 'add') {
            this.form(id, command === 'add');
        }
        if (command === 'move') {
            this.moveDialog(id);
        }
        if (command === 'status') {
            this.mutate('status', {
                term_id: id,
                active:  item.active ? 0 : 1,
            });
        }
        if (command === 'delete' && item.can_delete &&
            window.confirm('دستهٔ «' + item.name + '» حذف شود؟')) {
            this.mutate('delete', {term_id: id});
        }
        if (command === 'up' || command === 'down') {
            const siblings = this.children.get(item.parent_id) || [];
            const index = siblings.findIndex(node => node.id === id);
            if ((command === 'up' && index <= 0) || (command === 'down' && index === siblings.length - 1)) {
                return;
            }
            this.mutate('move', {
                term_id:   id,
                parent_id: item.parent_id,
                before_id: command === 'up' ? siblings[index - 1].id : (siblings[index + 2]?.id || 0),
            });
        }
    }
    
    dropPlan(event, row) {
        const id     = Number(row.dataset.row),
              source = this.map.get(this.dragId),
              target = this.map.get(id);
        if (!source || !target || id === source.id || this.descendants(source.id).has(id)) {
            return null;
        }
        const box   = row.getBoundingClientRect(),
              ratio = (event.clientY - box.top) / box.height;
        const placement = ratio < .25 ? 'before' : ratio > .75 ? 'after' : 'inside';
        let parent_id = target.id,
            before_id = 0;
        if (placement !== 'inside') {
            parent_id = target.parent_id;
            const siblings = (this.children.get(parent_id) || []).filter(node => node.id !== source.id);
            const index = siblings.findIndex(node => node.id === target.id);
            before_id = placement === 'before' ? target.id : (siblings[index + 1]?.id || 0);
        }
        return {
            placement,
            term_id: source.id,
            parent_id,
            before_id,
        };
    }
    
    bind() {
        const $root = this.$root;
        $root.on('click', '[data-select]',
            event => { this.select(Number(event.currentTarget.dataset.select), event.currentTarget); });
        $root.on('click', '[data-toggle]', event => {
            const id = Number(event.currentTarget.dataset.toggle);
            this.state.open[id] = event.currentTarget.getAttribute('aria-expanded') !== 'true';
            this.persist();
            this.renderTree();
            $root.find(`[data-toggle="${id}"]`).trigger('focus');
        });
        $root.on('click', '[data-command]', event => {
            this.command(event.currentTarget.dataset.command, Number(event.currentTarget.dataset.id));
        });
        $root.on('input', '.ke-search', () => this.renderTree());
        $root.on('click', '.ke-new', () => this.form(0, true));
        $root.on('click', '.ke-retry', () => this.load());
        $root.on('click', '.ke-expand', event => {
            this.terms.forEach(item => { this.state.open[item.id] = event.currentTarget.dataset.open === '1'; });
            this.persist();
            this.renderTree();
        });
        $root.on('click', '.ke-close, .ke-backdrop', () => this.closeSheet());
        $(document).on('click', '#programTermMoveModal' + this.root.dataset.taxonomy + ' .ke-move-confirm', () => {
            const modal = $('#programTermMoveModal' + this.root.dataset.taxonomy);
            const destination = Number(modal.find('.ke-destination').val());
            modal.modal('hide');
            this.mutate('move', {
                term_id:   this.moveId,
                parent_id: destination,
                before_id: 0,
            });
        });
        $root.on('keydown', '.ke-panel', event => {
            if (!$root.hasClass('is-sheet-open')) {
                return;
            }
            if (event.key === 'Escape') {
                event.preventDefault();
                this.closeSheet();
            }
            if (event.key === 'Tab') {
                const focusable = $root.find('.ke-panel button:visible:not(:disabled), .ke-panel summary:visible').
                    toArray();
                const first = focusable[0],
                      last  = focusable[focusable.length - 1];
                if (event.shiftKey && event.target === first) {
                    event.preventDefault();
                    last?.focus();
                }
                if (!event.shiftKey && event.target === last) {
                    event.preventDefault();
                    first?.focus();
                }
            }
        });
        $root.on('keydown', '.ke-label', event => {
            const labels = $root.find('.ke-tree .ke-label:visible').toArray(),
                  index  = labels.indexOf(event.currentTarget);
            if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
                event.preventDefault();
                labels[index + (event.key === 'ArrowDown' ? 1 : -1)]?.focus();
            }
            if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') {
                event.preventDefault();
                const id = Number(event.currentTarget.dataset.select);
                this.state.open[id] = event.key === 'ArrowLeft';
                this.persist();
                this.renderTree();
                $root.find(`[data-select="${id}"]`).first().trigger('focus');
            }
        });
        $root.on('dragstart', '[data-row]', event => {
            if (this.busy || $root.find('.ke-search').val() || window.matchMedia('(max-width: 767px)').matches ||
                $(event.target).closest('.ke-menu').length) {
                event.preventDefault();
                return;
            }
            this.dragId = Number(event.currentTarget.dataset.row);
            event.originalEvent.dataTransfer.effectAllowed = 'move';
            event.originalEvent.dataTransfer.setData('text/plain', String(this.dragId));
        });
        $root.on('dragover', '[data-row], [data-root-drop]', event => {
            if (!this.dragId || this.busy) {
                return;
            }
            const row = event.currentTarget;
            const plan = row.dataset.rootDrop ? {
                placement: 'inside',
                term_id:   this.dragId,
                parent_id: 0,
                before_id: 0,
            } : this.dropPlan(event.originalEvent, row);
            $root.find('[data-drop]').removeAttr('data-drop');
            if (!plan) {
                return;
            }
            event.preventDefault();
            event.stopPropagation();
            row.dataset.drop = plan.placement;
        });
        $root.on('drop', '[data-row], [data-root-drop]', event => {
            event.preventDefault();
            event.stopPropagation();
            const row = event.currentTarget;
            const plan = row.dataset.rootDrop ? {
                term_id:   this.dragId,
                parent_id: 0,
                before_id: 0,
            } : this.dropPlan(event.originalEvent, row);
            $root.find('[data-drop]').removeAttr('data-drop');
            if (this.dragId && plan) {
                this.mutate('move', plan);
            }
            this.dragId = 0;
        });
        $root.on('dragend', () => {
            this.dragId = 0;
            $root.find('[data-drop]').removeAttr('data-drop');
        });
    }
}

function init() {
    document.querySelectorAll('.kerp-explorer').
        forEach(root => {
            if (!instances.has(root)) {
                instances.set(root, new Explorer(root));
            }
        });
}

$(function() {
    init();
    new MutationObserver(records => {
        if (records.some(record => [...record.addedNodes].some(node => node.nodeType === 1 &&
            (node.matches('.kerp-explorer') || node.querySelector('.kerp-explorer'))))) {
            init();
        }
    }).observe(document.body, {
        childList: true,
        subtree:   true,
    });
});
