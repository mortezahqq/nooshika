(function($) {
    'use strict';

    $(document).on('click', '.kerp-customer-history-load-more', function(e) {
        e.preventDefault();

        const $button = $(this);
        const $wrapper = $button.closest('.kerp-customer-history');
        const $list = $wrapper.find('.kerp-customer-history-list').first();

        if ($button.prop('disabled') || !$list.length) {
            return;
        }

        const originalText = $button.find('.kerp-load-more-label').text();
        $button.prop('disabled', true).addClass('disabled');
        $button.find('.kerp-load-more-label').text('در حال بارگذاری...');
        $button.find('.icon').addClass('d-none');
        $button.find('.kerp-load-more-spinner').removeClass('d-none');

        $.post(ajax_url, {
            action:      'customers_history_load_more',
            customer_id: $button.attr('data-customer-id'),
            page_number: $button.attr('data-next-page'),
            per_page:    $button.attr('data-per-page'),
            event_type:  $button.attr('data-event-type') || '',
        }).done(function(response) {
            if (!response || response.status !== 'success') {
                const message = response && response.message
                    ? response.message
                    : 'بارگذاری سوابق انجام نشد.';
                NioApp.Toast(message, 'error', {position: 'top-right'});
                $button.prop('disabled', false).removeClass('disabled');
                return;
            }

            if (response.html) {
                $list.append(response.html);
            }

            if (response.has_more) {
                $button.attr('data-next-page', response.next_page);
                $button.prop('disabled', false).removeClass('disabled');
            } else {
                $button.closest('.kerp-customer-history-load-more-wrap').remove();
            }
        }).fail(function() {
            $button.prop('disabled', false).removeClass('disabled');
            NioApp.Toast('ارتباط با سرور برای بارگذاری سوابق برقرار نشد.', 'error', {
                position: 'top-right',
            });
        }).always(function() {
            if ($button.closest('body').length) {
                $button.find('.kerp-load-more-label').text(originalText);
                $button.find('.icon').removeClass('d-none');
                $button.find('.kerp-load-more-spinner').addClass('d-none');
            }
        });
    });
})(jQuery);
