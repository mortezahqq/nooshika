// Chart.js 2.x presentation for registered home blocks only.
function kerpDashboardStyleChart(config, type) {
    var dark = document.body.classList.contains('dark-mode');
    var ink = dark ? '#b6c5dc' : '#526580';
    var grid = dark ? 'rgba(160,180,210,.13)' : 'rgba(82,101,128,.10)';
    var options = config.options;
    options.animation.duration = window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 0 : 450;
    options.legend.labels.fontColor = ink;
    options.title.fontColor = ink;
    options.tooltips.backgroundColor = dark ? '#26364d' : '#17263c';
    options.tooltips.titleFontColor = '#fff';
    options.tooltips.bodyFontColor = '#e4eaf5';
    options.tooltips.titleAlign = 'right';
    options.tooltips.bodyAlign = 'right';
    options.tooltips.borderWidth = 1;
    options.tooltips.borderColor = grid;
    options.layout = { padding: { top: 8, right: 4, bottom: 0, left: 4 } };
    var horizontal = type === 'horizontalBar';
    if (options.scales) {
        ['xAxes', 'yAxes'].forEach(function(key) {
            var numeric = horizontal ? key === 'xAxes' : key === 'yAxes';
            var axis = options.scales[key][0];
            axis.gridLines = { display: numeric, color: grid, zeroLineColor: grid, drawBorder: false, borderDash: [3, 5], tickMarkLength: 0 };
            axis.ticks.fontColor = ink;
            axis.ticks.fontSize = 10;
            axis.ticks.padding = 10;
            axis.ticks.maxRotation = 0;
            axis.ticks.minRotation = 0;
            axis.ticks.autoSkip = !horizontal || numeric;
            axis.ticks.maxTicksLimit = numeric ? 5 : 6;
            if (numeric) {
                axis.ticks.beginAtZero = true;
                axis.ticks.precision = 0;
                axis.ticks.callback = function(value) { return Number(value).toLocaleString('fa-IR'); };
            } else {
                delete axis.ticks.beginAtZero;
                axis.ticks.callback = function(value) {
                    var label = String(value);
                    if (/^\d{4}[-/]\d{2}[-/]\d{2}$/.test(label)) label = label.slice(5);
                    return label.length > 18 ? label.slice(0, 17) + '…' : label;
                };
            }
            if (key === 'yAxes') axis.position = 'right';
            if (horizontal && numeric) axis.ticks.reverse = true;
        });
    }
    config.data.datasets.forEach(function(dataset) {
        if (['area', 'line', 'bar', 'horizontalBar'].indexOf(type) < 0) {
            dataset.borderWidth = 3;
            dataset.borderColor = dark ? '#172333' : '#fff';
            dataset.hoverBorderColor = dataset.borderColor;
            return;
        }
        var color = dataset.borderColor;
        dataset.pointRadius = 0;
        dataset.pointHitRadius = 14;
        dataset.pointHoverRadius = 4;
        dataset.borderWidth = type === 'area' || type === 'line' ? 2 : 0;
        // Monotone interpolation avoids suggesting negative counts between zero days.
        dataset.cubicInterpolationMode = 'monotone';
        dataset.lineTension = 0.25;
        dataset.maxBarThickness = horizontal ? 16 : 22;
        dataset.categoryPercentage = 0.72;
        dataset.barPercentage = 0.8;
        dataset.kerpDashboardColor = color;
    });
    config.plugins = [{
        beforeDatasetsUpdate: function(chart) {
            var area = chart.chartArea;
            if (!area) return;
            chart.data.datasets.forEach(function(dataset) {
                if (!dataset.kerpDashboardColor) return;
                var color = dataset.kerpDashboardColor;
                var gradient = horizontal
                    ? chart.ctx.createLinearGradient(area.right, 0, area.left, 0)
                    : chart.ctx.createLinearGradient(0, area.top, 0, area.bottom);
                gradient.addColorStop(0, kasebi_hex_to_rgba(color, type === 'area' ? 0.36 : 0.95));
                gradient.addColorStop(1, kasebi_hex_to_rgba(color, type === 'area' ? 0.015 : 0.35));
                dataset.backgroundColor = gradient;
            });
        }
    }];
}

// Recreate only workspace charts when the theme changes, including after AJAX navigation.
var kerpDashboardThemeObserver = new MutationObserver(function(records) {
    var changed = records.some(function(record) {
        return (record.oldValue || '').split(/\s+/).includes('dark-mode') !== document.body.classList.contains('dark-mode');
    });
    if (!changed) return;
    $('.kerp-dashboard .kasebi-chart, .kerp-dashboard .kasebi_chart').each(function() {
        var element = $(this);
        var chart = element.data('chartInstance');
        if (chart) chart.destroy();
        element.removeData('chartInstance').removeData('chartActivated');
    });
    if (document.querySelector('.kerp-dashboard')) activate_charts();
});
kerpDashboardThemeObserver.observe(document.body, { attributes: true, attributeFilter: ['class'], attributeOldValue: true });
