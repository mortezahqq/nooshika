// Local-only walkthrough: these controls never call registration, OTP or navigation APIs.
function kerpRegistrationPreviewStep($preview, step, focus) {
    const current = Math.max(0, Math.min(3, step));
    $preview.data('preview-step', current);
    $preview.find('[data-preview-step]').addClass('d-none');
    const $section = $preview.find('[data-preview-step="' + current + '"]').removeClass('d-none');
    $preview.find('[data-preview-indicator]').removeAttr('aria-current');
    $preview.find('[data-preview-indicator="' + current + '"]').attr('aria-current', 'step');
    $preview.find('[data-preview-back]').toggleClass('d-none', current === 0);
    $preview.find('[data-preview-restart]').toggleClass('d-none', current !== 3);
    $preview.find('[data-preview-next]').toggleClass('d-none', current === 3).text(
        current === 0 ? $preview.attr('data-first-button') : current === 1 ? 'تأیید و ادامه' : $preview.attr('data-second-button')
    );
    if (focus) $section.find('h5').first().trigger('focus');
}

function kerpRegistrationPreviewReset($preview, focus) {
    $preview.find('input').val('').prop('checked', false);
    $preview.find('select').prop('selectedIndex', 0);
    kerpRegistrationPreviewStep($preview, 0, focus);
}

$(document).on('shown.bs.modal', '[id^="kerpRegistrationPreview"]', function () {
    kerpRegistrationPreviewReset($(this).find('.kerp-registration-preview'), true);
});
$(document).on('hidden.bs.modal', '[id^="kerpRegistrationPreview"]', function () {
    kerpRegistrationPreviewReset($(this).find('.kerp-registration-preview'), false);
});
$(document).on('click', '.kerp-registration-preview [data-preview-next], .kerp-registration-preview [data-preview-back], .kerp-registration-preview [data-preview-restart]', function (event) {
    event.preventDefault();
    const $preview = $(this).closest('.kerp-registration-preview');
    if (this.hasAttribute('data-preview-restart')) { kerpRegistrationPreviewReset($preview, true); return; }
    kerpRegistrationPreviewStep($preview, (Number($preview.data('preview-step')) || 0) + (this.hasAttribute('data-preview-back') ? -1 : 1), true);
});
$(document).on('keydown', '.kerp-registration-preview input', function (event) {
    if (event.key === 'Enter') { event.preventDefault(); $(this).closest('.kerp-registration-preview').find('[data-preview-next]').trigger('click'); }
});
// Saved rich-text links stay inert, including middle-click, during the walkthrough.
$(document).on('click auxclick', '.kerp-registration-preview a', function (event) { event.preventDefault(); event.stopImmediatePropagation(); });
