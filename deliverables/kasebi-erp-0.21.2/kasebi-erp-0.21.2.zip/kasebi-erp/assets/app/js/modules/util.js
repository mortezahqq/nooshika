function extend(obj, ext) {
    Object.keys(ext).forEach(function(key) {
        obj[key] = ext[key];
    });
    return obj;
}

function activate_date_pickers() {
    let years = [];
    for (let i = 1321; i <= 1407; i++) {
        years.push(i);
    }
    $('.datepicker').each(function() {
        let _this = $(this);
        if (_this.data('kerp-datepicker-initialized')) {
            return;
        }
        let args = {
            nextArrow:       '<i class="fas fa-chevron-left"></i>',
            prevArrow:       '<i class="fas fa-chevron-right"></i>',
            formatDate:      'YYYY-MM-DD',
            cellWidth:       27,
            cellHeight:      26,
            selectableYears: years,
            onSelect:        function() {
                _this.trigger('change');
            },
        };
        // The picker parses slash-separated dates, while ERP forms submit hyphenated dates.
        const kerpTypedDate = String(_this.val() || '').trim()
            .replace(/[۰-۹]/g, digit => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(digit)))
            .replace(/[٠-٩]/g, digit => String('٠١٢٣٤٥٦٧٨٩'.indexOf(digit)))
            .match(/^(\d{4})[-/](\d{1,2})[-/](\d{1,2})$/);
        if (kerpTypedDate && Number(kerpTypedDate[2]) >= 1 && Number(kerpTypedDate[2]) <= 12 &&
            Number(kerpTypedDate[3]) >= 1 && Number(kerpTypedDate[3]) <= 31) {
            args.selectedDate = kerpTypedDate.slice(1).map(Number).join('/');
        } else if (_this.attr('data-value')) {
            let selectedDate = _this.attr('data-value');
            args['selectedDate'] = new Date(
                selectedDate).toLocaleDateString(
                'fa-IR-u-nu-latn');
            args['selectedBefore'] = !0;
        }
        _this.persianDatepicker(args);
        _this.data('kerp-datepicker-initialized', true);
    });
}

function add_loading_block() {
    let loading_html = '<div class="modal fade" id="loading_modal">'
        + '<div class="modal-dialog">'
        +
        '<div class="loader" style="width: 3rem; height: 3rem; margin: auto" role="status"></div>'
        + '</div></div>';
    $('#loading_modal').remove();
    $('body').append(loading_html);
}

function show_loading_modal() {
    $('#loading_modal').addClass('show').css('display', 'block');
}

function hide_loading_modal() {
    $('#loading_modal').removeClass('show').css('display', 'none');
}

function validate_phone_number(phone) {
    let regex = /^(\+98|0)?9\d{9}$/;
    return regex.test(toEnglishNumber(phone));
}

function validate_slug(slug) {
    let regex = /^[a-zA-Z0-9-_]+$/;
    return regex.test(slug);
}

function number_format(number) {
    return new Intl.NumberFormat('en').format(number);
}

function toEnglishNumber(strNum, element = null) {
    if (strNum === undefined || strNum === null) {
        return '';
    }
    let s = String(strNum);
    
    // تبدیل ارقام فارسی (۰-۹) و عربی (٠-٩) به انگلیسی
    const fa = '۰۱۲۳۴۵۶۷۸۹';
    const ar = '٠١٢٣٤٥٦٧٨٩';
    s = s.replace(/[۰-۹]/g, d => String(fa.indexOf(d))).replace(/[٠-٩]/g, d => String(ar.indexOf(d)));
    
    if (element) {
        $(element).val(s);
        return;
    }
    return s;
}

function sanitizeNumber(number, keepDecimal = false) {
    if (number === undefined || number === null || number === '') {
        return 0;
    }
    
    let s = toEnglishNumber(String(number)).trim();
    
    // − -> -
    s = s.replace(/\u2212/g, '-');
    
    // (123) -> -123
    if (/^\(.*\)$/.test(s)) {
        s = '-' + s.slice(1, -1);
    }
    
    // ممیز عربی/فارسی -> نقطه
    s = s.replace(/\u066B/g, '.'); // ٫ -> .
    
    // جداکننده‌های هزارگان: comma انگلیسی هم باید باشد
    s = s.replace(/[,٬،\u00A0\u202F_]/g, '');
    
    if (keepDecimal) {
        // فقط عدد، منفی و نقطه بماند
        s = s.replace(/[^0-9.\-]/g, '');
        
        // منفی فقط اول رشته مجاز باشد
        s = s.replace(/(?!^)-/g, '');
        
        // اگر چندتا نقطه داشت، فقط اولی ممیز باشد
        const parts = s.split('.');
        if (parts.length > 2) {
            s = parts.shift() + '.' + parts.join('');
        }
    } else {
        // بدون اعشار: نقطه هم حذف شود
        s = s.replace(/\./g, '');
        
        // فقط عدد و منفی بماند
        s = s.replace(/[^0-9\-]/g, '');
        
        // منفی فقط اول رشته مجاز باشد
        s = s.replace(/(?!^)-/g, '');
    }
    
    const n = keepDecimal ? parseFloat(s) : parseInt(s, 10);
    
    return isNaN(n) ? 0 : n;
}

function formatNumber(num) {
    if (num >= 1_000_000_000) {
        return (num / 1_000_000_000).toFixed(2) + ' میلیارد';
    } else if (num >= 1_000_000) {
        return (num / 1_000_000).toFixed(2) + ' میلیون';
    } else if (num >= 1_000) {
        return (num / 1_000).toFixed(2) + ' هزار';
    }
    return num.toFixed(2);
}

// Public integration point for independently enqueued ERP addons.
$(document).on('kerp:page-response', function(event, response) {
    if (response && typeof response === 'object') change_panel_html(response);
});

function change_panel_html(response) {
    if (response.status === 'error' && response.validation_pane) {
        const pane = document.getElementById(response.validation_pane);
        if (pane && pane.classList.contains('tab-pane')) {
            const $pane = $(pane);
            const $form = $pane.closest('.modal_form');
            $form.find('.kerp-tab-validation-error').remove();
            $form.find('[data-bs-toggle="tab"]').filter(function() {
                return this.getAttribute('href') === '#' + pane.id;
            }).first().tab('show');
            const $error = $('<div class="alert alert-danger kerp-tab-validation-error" role="alert" tabindex="-1">')
                .text(response.message || response.msg || 'اطلاعات این بخش را بررسی کنید.');
            $pane.prepend($error);
            $error[0].focus({preventScroll: true});
            $error[0].scrollIntoView({block: 'center', behavior: 'smooth'});
            return;
        }
    }
    $('.modal').modal('hide');
    $('.modal-backdrop').remove();
    $('.tooltip').remove();
    if (response.main) {
        $('#kerp-app').html(response.main);
        NioApp.ajaxInit();
        $('html, body').animate({ scrollTop: 0 }, 500);
    }
    if (response.title) {
        document.title = response.title;
    }
    if (response.url) {
        history.pushState({}, '', response.url);
    }
    const message = response.message || response.msg;
    
    if (message) {
        NioApp.Toast(message, response.status || 'info', {
            position: 'top-right',
        });
    }
}

// Only the newest navigation/filter response may replace the ERP panel.
let kerpPageRequestVersion = 0;
let kerpPageRequestPending = null;
function kerpRequestPage(data) {
    const version = ++kerpPageRequestVersion;
    if (kerpPageRequestPending) kerpPageRequestPending.abort();
    kerpPageRequestPending = $.post(ajax_url, data).done(function(response) {
        if (version === kerpPageRequestVersion) change_panel_html(response);
    }).fail(function(xhr, reason) {
        if (reason !== 'abort' && version === kerpPageRequestVersion) {
            NioApp.Toast('دریافت صفحه انجام نشد؛ دوباره تلاش کنید.', 'danger', {position: 'top-right'});
        }
    });
    return kerpPageRequestPending;
}

function request_panel_page_content($url) {
    show_loading_modal();
    const data = {action: 'erp_request_page_content', page: String($url || '')};
    kerpRequestPage(data);
}

function read_file(data) {
    let workbook,
        rowObject;
    workbook = XLSX.read(data, {
        type: 'binary',
    });
    workbook.SheetNames.forEach(sheet => {
        rowObject = XLSX.utils.sheet_to_row_object_array(
            workbook.Sheets[sheet],
        );
    });
    return rowObject;
}

function chunk(items, size) {
    const chunks = [];
    items = [].concat(...items);
    while (items.length) {
        chunks.push(
            items.splice(0, size),
        );
    }
    return chunks;
}

function sendAjaxData(chunked, counter, progress, action, maxParts, btn) {
    let data = {
        'action': action,
        'data':   chunked[counter],
    };
    $.ajax({
        url:      ajax_url,
        type:     'post',
        dataType: 'json',
        data:     data,
        success:  function() {
            counter++;
            progress.width(counter / maxParts * 100 + '%');
            if (counter >= maxParts) {
                btn.html(
                    '<span>اتمام عملیات</span>');
                NioApp.Toast('ایمپورت به پایان رسید', 'success',
                    {position: 'top-right'});
                ajax_search = false;
            } else {
                btn.html(
                    '<span class="spinner-border spinner-border-sm"></span><span>در حال ایمپورت...</span>');
                sendAjaxData(chunked, counter, progress, action, maxParts,
                    btn);
            }
        },
    });
}

function showRequiredError($field) {
    let $group = $field.closest('.form-group');
    let label = $group.find('.form-label');
    if (!label.length) {
        label = 'این فیلد';
    } else {
        label = label.get(0).innerText.trim();
    }
    const $pane = $field.closest('.tab-pane[id]');
    if ($pane.length) {
        change_panel_html({status: 'error', validation_pane: $pane.attr('id'), message: label + ' ضروری است'});
        return;
    }
    NioApp.Toast(label + ' ضروری است', 'error',
        {position: 'top-right'});
}

function getFieldLabel($field) {
    let $row = $field.closest('.meta-field-row');
    let label = $row.find('.form-label').first().text().trim();
    
    if (label) {
        return label;
    }
    
    label = $field.closest('td').closest('tr').find('th').first().text().trim();
    
    if (label) {
        return label;
    }
    
    return $field.data('for') || $field.attr('name') || 'مورد';
}

function setNestedValue(obj, path, value) {
    let keys = path.replace(/\]/g, '').split('['); // meta[national_id] => ['meta','national_id']
    
    let ref = obj;
    keys.forEach(function(key, index) {
        if (index === keys.length - 1) {
            ref[key] = value;
        } else {
            if (!ref[key] || typeof ref[key] !== 'object') {
                ref[key] = {};
            }
            ref = ref[key];
        }
    });
}

function getNestedValue(obj, path) {
    let keys = path.replace(/\]/g, '').split('[');
    let ref = obj;
    
    for (let i = 0; i < keys.length; i++) {
        if (ref == null || typeof ref !== 'object') {
            return undefined;
        }
        ref = ref[keys[i]];
    }
    return ref;
}

function getFieldValueByMeta(metaKey, $scope) {
    let $el = $scope && $scope.length ? $scope.find('[data-for="' + metaKey + '"]') : $('[data-for="' + metaKey + '"]');
    if (!$el.length) {
        return null;
    }
    
    let tag = ($el.prop('tagName') || '').toLowerCase();
    let type = ($el.attr('type') || '').toLowerCase();
    
    if (tag === 'select') {
        return $el.val();
    }
    if (tag === 'textarea') {
        return $el.val();
    }
    if (type === 'checkbox') {
        return $el.is(':checked') ? '1' : '0';
    }
    return $el.val();
}

function matchCondition(actual, expected, operator) {
    let isArray = Array.isArray(expected);
    let isMatch = isArray ? expected.indexOf(actual) !== -1 : (actual === expected);
    return (operator === '!=') ? !isMatch : isMatch;
}

function parseExpected(jsonStr) {
    try {
        let parsed = JSON.parse(jsonStr);
        if (Array.isArray(parsed)) {
            return parsed.map(function(v) { return (v === null || v === undefined) ? '' : String(v); });
        }
        return (parsed === null || parsed === undefined) ? '' : String(parsed);
    } catch (e) {
        return jsonStr;
    }
}

function evaluateVisibilityForRow($row) {
    let isConditional = $row.data('conditional') === 1 || $row.data('conditional') === '1';
    if (!isConditional) {
        return; // always visible
    }
    let condMeta = $row.data('cond-meta') || '';
    let operator = $row.data('cond-operator') || '==';
    let expectedRaw = $row.attr('data-cond-expected') || '';
    
    let expected = parseExpected(expectedRaw);
    // Stage-button repeaters use the same field names in multiple stage modals.
    let actual = getFieldValueByMeta(condMeta, $row.closest('form[data-action="leads_save_stage_actions"]'));
    if (actual === null || actual === undefined) {
        actual = '';
    } else {
        actual = String(actual);
    }
    
    let ok = matchCondition(actual, expected, operator);
    $row.toggleClass('d-none', !ok);
}

function evaluateAll($scope) {
    let $rows;
    if ($scope && $scope.length) {
        $rows = $scope.closest('form').find('.meta-field-row');
    } else {
        $rows = $('.meta-field-row');
    }
    $rows.each(function() {
        evaluateVisibilityForRow($(this));
    });
}

function buildNeedsHtml(needFields, itemsCount, actionLabel) {
    if (!needFields || !needFields.length) {
        return `<div class="text-center py-2">آیا از اجرای «${actionLabel}» برای ${itemsCount} مورد مطمئن هستید؟</div>`;
    }
    const blocks = needFields.map(f => {
        const id = `swal_need_${f.key || f.name || Math.random().toString(36).slice(2)}`;
        const label = f.label || '';
        const wrapStart = `<div class="form-group"><label class="form-label" for="${id}">${label}</label><div class="form-control-wrap">`;
        const wrapEnd = `</div></div>`;
        if (f.type === 'select') {
            let options = f.options || [];
            if (!Array.isArray(options)) {
                options = Object.entries(options).map(function(entry) {
                    return {
                        value: entry[0],
                        label: entry[1],
                    };
                });
            }
            let opts = '';
            if (f.placeholder) {
                opts += `<option value="">${f.placeholder}</option>`;
            }
            opts += options.map(function(option) {
                const value = typeof option === 'object' ? (option.value ?? option.id ?? option.key ?? '') : option;
                const title = typeof option === 'object'
                              ? (option.label ?? option.text ?? option.title ?? value)
                              : option;
                const selected = typeof f.value !== 'undefined' && f.value !== null && String(f.value) === String(value)
                                 ? ' selected'
                                 : '';
                return `<option value="${String(value).replace(/"/g, '&quot;')}"${selected}>${title}</option>`;
            }).join('');
            return `${wrapStart}<select id="${id}" class="form-select" data-key="${f.key}">${opts}</select>${wrapEnd}`;
        }
        if (f.type === 'textarea') {
            const val = (f.value ?? '');
            return `${wrapStart}<textarea id="${id}" class="form-control" data-key="${f.key}">${String(
                val).replace(/"/g, '&quot;')}</textarea>${wrapEnd}`;
        }
        const extraClass = (f.type === 'date') ? ' datepicker' : (f.type === 'price' ? ' price_input' : '');
        const inputMode = f.type === 'price' ? ' inputmode="numeric"' : '';
        const placeholder = f.placeholder ? ` placeholder="${String(f.placeholder).replace(/"/g, '&quot;')}"` : '';
        const val = (f.value ?? '');
        return `${wrapStart}<input type="text" id="${id}" class="form-control${extraClass}" data-key="${f.key}"${inputMode}${placeholder} value="${String(
            val).replace(/"/g, '&quot;')}">${wrapEnd}`;
    });
    return blocks.join('');
}

function collectNeedsValues(needFields) {
    const vals = {};
    (needFields || []).forEach(f => {
        if (f.type === 'modal') {
            return;
        }
        const $inp = $(`.swal2-container [data-key="${f.key}"]`);
        if ($inp.length) {
            vals[f.key] = $inp.val();
        }
    });
    return vals;
}

function request_city_list(state_id, city_id = 0, target = '') {
    let city = $(target);
    let data = {
        action:   'kasebi_load_city_list',
        state_id: state_id,
        city_id:  city_id,
    };
    $.post(ajax_url, data, function(response) {
        city.html(response.list);
        NioApp.Select2(target);
        if (city_id) {
            $(target).val(city_id).trigger('change');
        }
        request_city = true;
    });
}

function activate_dragula(context = document) {
    if (typeof dragula === 'undefined') {
        return;
    }
    
    $(context).find('.dragula-item').each(function() {
        let $item = $(this);
        let $container = $item.parent();
        
        if ($container.data('dragula-active')) {
            return;
        }
        
        $container.data('dragula-active', true);
        
        let drake = dragula([$container[0]], {
            moves: function(el, container, handle) {
                return $(handle).closest('.dragula-handler').length > 0;
            },
        });
        
        drake.on('drop', function(el, target) {
            let $el = $(el);
            
            let action = $el.data('action');
            let itemTarget = $el.data('target');
            let param = $el.data('param');
            
            if (!action || !itemTarget || !param) {
                return;
            }
            
            let ids = [];
            
            $(target).find(itemTarget).each(function() {
                let id = $(this).data('id');
                
                if (id) {
                    ids.push(id);
                }
            });
            
            let data = {
                action: action,
            };
            
            data[param] = ids;
            
            $.post(ajax_url, data, function(response) {
                NioApp.Toast(response.message, response.status, {position: 'top-right'});
            });
        });
    });
}

function kerp_get_select_scope($element) {
    let $table = $element.closest('table');
    
    if ($table.length) {
        return $table;
    }
    
    let $scope = $element.closest(
        '[data-select-scope], form, .card, .nk-block',
    );
    
    return $scope.length ? $scope : $(document);
}

function kerp_get_select_items($selectAll) {
    let target = $selectAll.data('target') || '.select_item_row';
    let $scope = kerp_get_select_scope($selectAll);
    
    return $scope.find(target).filter(':enabled');
}

function kerp_set_row_selected_state($checkbox) {
    $checkbox.closest('tr').toggleClass(
        'is-selected',
        $checkbox.prop('checked'),
    );
}

function kerp_update_select_all_state($scope) {
    $scope.find('.select_all_rows').each(function() {
        let $selectAll = $(this);
        let $items = kerp_get_select_items($selectAll);
        let total = $items.length;
        let selected = $items.filter(':checked').length;
        
        $selectAll.prop(
            'checked',
            total > 0 && selected === total,
        ).prop(
            'indeterminate',
            selected > 0 && selected < total,
        );
    });
}

function kerp_handle_select_all_rows($selectAll) {
    let $items = kerp_get_select_items($selectAll);
    let checked = $selectAll.prop('checked');
    
    $selectAll.prop('indeterminate', false);
    
    $items.prop('checked', checked);
    
    $items.each(function() {
        kerp_set_row_selected_state(
            $(this),
        );
    });
    
    $items.trigger(
        'kerp:row-selection-change',
        [checked],
    );
}

function kerp_handle_select_item_row($item) {
    let $scope = kerp_get_select_scope($item);
    
    kerp_set_row_selected_state($item);
    kerp_update_select_all_state($scope);
    
    $item.trigger(
        'kerp:row-selection-change',
        [$item.prop('checked')],
    );
}

function normalizeSelectPopulateValue($field, value) {
    if (!$field.prop('multiple')) {
        return value ?? '';
    }
    
    if (Array.isArray(value)) {
        return value.map(String);
    }
    
    if (value === null || value === undefined || value === '') {
        return [];
    }
    
    if (typeof value === 'string') {
        let trimmedValue = value.trim();
        
        if (
            trimmedValue.startsWith('[') &&
            trimmedValue.endsWith(']')
        ) {
            try {
                let parsedValue = JSON.parse(trimmedValue);
                
                if (Array.isArray(parsedValue)) {
                    return parsedValue.map(String);
                }
            } catch (error) {
                // ادامه بده و مقدار را comma-separated در نظر بگیر.
            }
        }
        
        return trimmedValue.split(',').map(function(item) {
            return item.trim();
        }).filter(Boolean).map(String);
    }
    
    if (typeof value === 'object') {
        return Object.values(value).map(String);
    }
    
    return [String(value)];
}

// Clone the server-rendered main-plugin component for live monetary previews.
function kerp_price_html(value, currency) {
    const amount = Number(value);
    if (value === null || value === '' || !Number.isFinite(amount)) return '—';
    const data = window.KERPPriceData || {};
    const $price = $('<span>').html(amount === 0 ? data.zero_template : data.template);
    if (!$price.find('.final_price .price_number').length) {
        return $('<span>').text(amount.toLocaleString('en-US') + ' ' + (currency || data.currency || '')).html();
    }
    $price.find('.final_price .price_number').text(amount === 0 ? '-' : (Math.sign(amount) * Math.round(Math.abs(amount))).toLocaleString('en-US'));
    if (currency) $price.find('.currency').text(currency);
    return $price.html();
}
function kerp_price_update($target, value, currency) {
    $target.attr('data-price-value', value).html(kerp_price_html(value, currency));
}
