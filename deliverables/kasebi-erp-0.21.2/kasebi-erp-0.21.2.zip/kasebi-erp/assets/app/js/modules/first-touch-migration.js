(function() {
    'use strict';

    document.addEventListener('click', async function(event) {
        const button = event.target.closest('[data-ft-migrate]');
        if (!button) return;
        event.preventDefault();

        const root = button.closest('#kerp-first-touch-migration');
        if (!root || root.dataset.running === '1') return;
        root.dataset.running = '1';
        button.disabled = true;
        const label = button.querySelector('span');
        const message = root.querySelector('[data-ft-message]');
        label.textContent = 'در حال انتقال…';

        try {
            let remaining = 1;
            while (remaining > 0 && document.documentElement.contains(root)) {
                const body = new URLSearchParams({
                    action: 'customers_migrate_first_touch',
                    migration_nonce: root.dataset.nonce || ''
                });
                const response = await fetch(window.KERPData?.ajaxUrl || '', {
                    method: 'POST', credentials: 'same-origin', cache: 'no-store',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'},
                    body: body.toString()
                });
                const payload = await response.json();
                if (!response.ok || payload?.status !== 'success' || !payload.data) {
                    throw new Error(payload?.message || payload?.msg || 'انتقال انجام نشد.');
                }
                remaining = Number(payload.data.remaining || 0);
                root.querySelector('[data-ft-total]').textContent = Number(payload.data.total || 0).toLocaleString('fa-IR');
                root.querySelector('[data-ft-remaining]').textContent = remaining.toLocaleString('fa-IR');
                message.textContent = remaining > 0 ? remaining.toLocaleString('fa-IR') + ' رکورد باقی مانده است…' : 'انتقال کامل شد؛ متای قبلی برای بازیابی حفظ شده است.';
                if (remaining > 0 && Number(payload.data.copied || 0) === 0) throw new Error('رکوردی منتقل نشد؛ داده‌های قدیمی را بررسی کنید.');
            }
            label.textContent = 'انتقال کامل است';
        } catch (error) {
            message.classList.add('text-danger');
            message.textContent = error.message || 'انتقال انجام نشد.';
            button.disabled = false;
            label.textContent = 'ادامه انتقال';
        } finally {
            root.dataset.running = '0';
        }
    });
})();
