const rootSelector = '.kerp-order-print-settings';

// Terms are rendered as a readable list; enhance after both initial and AJAX loads.
const termTreeStates = new Map();

function termTreeState(tree) {
    const key = 'kerp-terms-' + tree.dataset.taxonomy;
    if (!termTreeStates.has(key)) {
        let value = {};
        try { value = JSON.parse(sessionStorage.getItem(key) || '{}') || {}; } catch (_) {}
        termTreeStates.set(key, value);
    }
    return termTreeStates.get(key);
}

function setTermOpen(node, open) {
    node.querySelector(':scope > .kerp-term-children').hidden = !open;
    const button = node.querySelector(':scope > .kerp-term-row .kerp-term-toggle');
    button.setAttribute('aria-expanded', String(open));
    button.textContent = open ? '▾' : '◂';
}

function saveTermState(tree) {
    try {
        sessionStorage.setItem('kerp-terms-' + tree.dataset.taxonomy, JSON.stringify(termTreeState(tree)));
    } catch (_) {}
}

function normalizeTermSearch(value) {
    return String(value).
        toLowerCase().
        replace(/ي/g, 'ی').
        replace(/ك/g, 'ک').
        replace(/[\u064b-\u065f\u200c]/g, '').
        trim();
}

function filterTermTree(tree) {
    const query = normalizeTermSearch(tree.querySelector('.kerp-terms-search').value);
    const nodes = [...tree.querySelectorAll('.kerp-term-node')];
    const visible = new Set();
    nodes.forEach(node => {
        const match = !!query && normalizeTermSearch(node.dataset.search).includes(query);
        node.classList.toggle('is-match', match);
        if (match) {
            let current = node;
            while (current) {
                visible.add(current);
                current = current.parentElement.closest('.kerp-term-node');
            }
        }
    });
    nodes.forEach(node => {
        node.hidden = !!query && !visible.has(node);
        setTermOpen(node,
            query ? true : (termTreeState(tree)[node.dataset.id] ?? !node.parentElement.closest('.kerp-term-node')));
    });
    tree.querySelector('.kerp-terms-no-results').hidden = !query || visible.size > 0;
}

function initTermTrees() {
    document.querySelectorAll('.kerp-terms-tree:not([data-ready])').forEach(tree => {
        tree.dataset.ready = '1';
        const nodes = [...tree.querySelectorAll('.kerp-term-node')];
        const byId = new Map(nodes.map(node => [node.dataset.id, node]));
        nodes.forEach(node => {
            const parent = byId.get(node.dataset.parent);
            // Keep malformed or cyclic records visible at the root.
            if (parent && parent !== node && !node.contains(parent)) {
                parent.querySelector(':scope > .kerp-term-children').append(node);
            }
        });
        filterTermTree(tree);
        const focus = byId.get(tree.dataset.focus);
        if (focus) {
            let ancestor = focus.parentElement.closest('.kerp-term-node');
            while (ancestor) {
                termTreeState(tree)[ancestor.dataset.id] = true;
                setTermOpen(ancestor, true);
                ancestor = ancestor.parentElement.closest('.kerp-term-node');
            }
            saveTermState(tree);
            focus.classList.add('is-saved');
            focus.querySelector('.kerp-term-name').setAttribute('tabindex', '-1');
            focus.querySelector('.kerp-term-name').focus({preventScroll: true});
            focus.scrollIntoView({
                block:    'nearest',
                behavior: 'auto',
            });
            setTimeout(() => focus.classList.remove('is-saved'), 3500);
        }
    });
}

$(document).on('click', '.kerp-term-toggle', function() {
    const node = this.closest('.kerp-term-node');
    const tree = this.closest('.kerp-terms-tree');
    const open = this.getAttribute('aria-expanded') !== 'true';
    setTermOpen(node, open);
    if (!tree.querySelector('.kerp-terms-search').value) {
        termTreeState(tree)[node.dataset.id] = open;
        saveTermState(tree);
    }
});
$(document).on('input', '.kerp-terms-search', function() { filterTermTree(this.closest('.kerp-terms-tree')); });
$(document).on('click', '.kerp-terms-expand', function() {
    const tree = this.closest('.kerp-terms-tree');
    tree.querySelector('.kerp-terms-search').value = '';
    tree.querySelectorAll('.kerp-term-node').
        forEach(node => { termTreeState(tree)[node.dataset.id] = this.dataset.open === '1'; });
    saveTermState(tree);
    filterTermTree(tree);
});
$(document).on('shown.bs.modal', '[id^="programTermModal"]', function() {
    const modal = this;
    const select = modal.querySelector('[name="parent_id"]');
    if (!select) {
        return;
    }
    const termId = modal.querySelector('[name="term_id"]').value;
    const taxonomyId = modal.querySelector('[name="taxonomy_id"]').value;
    const tree = [...document.querySelectorAll('.kerp-terms-tree')].find(item => item.dataset.taxonomy === taxonomyId);
    const current = tree && [...tree.querySelectorAll('.kerp-term-node')].find(item => item.dataset.id === termId);
    const excluded = new Set(current
                             ? [
            current.dataset.id,
            ...[...current.querySelectorAll('.kerp-term-node')].map(item => item.dataset.id),
        ]
                             : []);
    [...select.options].forEach(option => { option.disabled = excluded.has(option.value); });
    $(select).trigger('change.select2');
    const title = modal.querySelector('.modal-title');
    if (title) {
        title.textContent = termId ? 'ویرایش گزینه' : (Number(select.value)
                                                       ? 'افزودن زیرمجموعه'
                                                       : 'افزودن گزینهٔ اصلی');
    }
});
$(document).on('hidden.bs.modal', '[id^="programTermModal"]', function() {
    $(this).find('[name="parent_id"] option').prop('disabled', false);
});
$(function() {
    initTermTrees();
    let queued = false;
    new MutationObserver(records => {
        if (queued || !records.some(record => [...record.addedNodes].some(node => node.nodeType === 1 &&
            (node.matches('.kerp-terms-tree') || node.querySelector('.kerp-terms-tree'))))) {
            return;
        }
        queued = true;
        requestAnimationFrame(() => {
            queued = false;
            initTermTrees();
        });
    }).observe(document.body, {
        childList: true,
        subtree:   true,
    });
});

function getCard(element) {
    return $(element).closest('.kerp-order-print-type');
}

function setCardOpen($card, open) {
    const $settings = $card.find('.kerp-order-print-type__settings').first();
    const $button = $card.find('.kerp-order-print-toggle').first();
    
    $card.toggleClass('is-open', open);
    $settings.prop('hidden', !open);
    $button.attr('aria-expanded', open ? 'true' : 'false');
}

function updateEnabledState($input) {
    const $card = getCard($input);
    const enabled = $input.is(':checked');
    const $state = $card.find('.kerp-order-print-type__state').first();
    
    $card.toggleClass('is-enabled', enabled).toggleClass('is-disabled', !enabled);
    $state.toggleClass('is-active', enabled).toggleClass('is-inactive', !enabled);
    $state.text(enabled ? 'فعال' : 'غیرفعال');
    
    setCardOpen($card, enabled);
}

function updateLabel($input) {
    const $card = getCard($input);
    const fallback = $.trim($card.attr('data-print-type') || '');
    const label = $.trim(String($input.val() || '')) || fallback;
    
    $card.find('.kerp-order-print-type__label').first().text(label);
}

function updateOrder($input) {
    const $card = getCard($input);
    const value = $.trim(String($input.val() || '0')) || '0';
    
    $card.find('.kerp-order-print-summary-order').html(
        '<em class="icon ni ni-sort-v"></em>ترتیب ' + value,
    );
}

function updateTextState($textarea) {
    const $card = getCard($textarea);
    const value = String($textarea.val() || '');
    const hasText = $.trim(value) !== '';
    const $count = $textarea.closest('.form-group').find('.kerp-order-print-char-count').first();
    
    $count.text(Array.from(value).length);
    
    if ($textarea.attr('id').endsWith('-header')) {
        $card.find('.kerp-order-print-summary-header span').text(
            hasText ? 'سربرگ دارد' : 'بدون سربرگ',
        );
    } else {
        $card.find('.kerp-order-print-summary-footer span').text(
            hasText ? 'پابرگ دارد' : 'بدون پابرگ',
        );
    }
}

function updateSellerProgress($root) {
    const $fields = $root.find('.kerp-print-seller-field');
    let filled = 0;
    
    $fields.each(function() {
        if ($.trim(String($(this).val() || '')) !== '') {
            filled++;
        }
    });
    
    $root.find('.kerp-order-print-seller-progress').text(
        filled + ' از ' + $fields.length + ' تکمیل',
    );
}

$(document).on('click', rootSelector + ' .kerp-order-print-toggle', function(e) {
    e.preventDefault();
    
    const $card = getCard(this);
    
    setCardOpen($card, !$card.hasClass('is-open'));
});

$(document).on('change', rootSelector + ' .kerp-order-print-enabled', function() {
    updateEnabledState($(this));
});

$(document).on('input', rootSelector + ' .kerp-order-print-label-input', function() {
    updateLabel($(this));
});

$(document).on('input change', rootSelector + ' .kerp-order-print-order-input', function() {
    updateOrder($(this));
});

$(document).on('input', rootSelector + ' .kerp-order-print-textarea', function() {
    updateTextState($(this));
});

$(document).on('input change', rootSelector + ' .kerp-print-seller-field', function() {
    updateSellerProgress($(this).closest(rootSelector));
});

const presetIcons = [
    'ni ni-file-text',
    'ni ni-call',
    'ni ni-calendar',
    'ni ni-flag',
    'ni ni-user-check',
    'kik fa-activity',
    'kik fa-clock',
    'uik-r fa-inbox',
];
const colorClasses = [
    'bg-primary-dim', 'text-primary',
    'bg-info-dim', 'text-info',
    'bg-success-dim', 'text-success',
    'bg-warning-dim', 'text-warning',
    'bg-danger-dim', 'text-danger',
    'bg-secondary-dim', 'text-secondary',
    'bg-purple-dim', 'text-purple',
    'bg-light-dim', 'text-light', 'text-dark',
];

function normalizeKey(value) {
    return String(value || '').
        toLowerCase().
        replace(/\s+/g, '-').
        replace(/[^a-z0-9_-]/g, '').
        replace(/-{2,}/g, '-').
        replace(/^[-_]+|[-_]+$/g, '');
}

function getColor($modal) {
    return String($modal.find('.kerp-settings-color-input').first().val() || 'primary');
}

function ensureIconTools($input) {
    const $group = $input.closest('.form-group');
    let $tools = $group.find('.kerp-settings-icon-tools').first();
    
    if ($tools.length) {
        return $tools;
    }
    
    if ($group.find('.kerp-settings-icon-preview, .kerp-settings-icon-presets').length) {
        return $group;
    }
    
    $tools = $('<div class="kerp-settings-icon-tools"></div>');
    const $preview = $('<span class="kerp-settings-icon-preview bg-primary-dim text-primary"><em></em></span>');
    const $presets = $('<div class="kerp-settings-icon-presets"></div>');
    
    presetIcons.forEach(function(icon) {
        const $button = $(
            '<button type="button" class="kerp-settings-icon-preset" aria-label="انتخاب آیکون"><em></em></button>');
        $button.attr('data-icon', icon);
        $button.find('em').attr('class', icon + ' icon');
        $presets.append($button);
    });
    
    $tools.append($preview, $presets);
    $group.append($tools);
    
    return $tools;
}

function syncIconPreview($input) {
    const $modal = $input.closest('.modal');
    const $tools = ensureIconTools($input);
    const icon = $.trim(String($input.val() || '')) || 'ni ni-file-text';
    const color = getColor($modal);
    const $preview = $tools.find('.kerp-settings-icon-preview').first();
    
    $preview.removeClass(colorClasses.join(' '));
    $preview.addClass('bg-' + color + '-dim text-' + (color === 'light' ? 'dark' : color));
    $preview.find('em').attr('class', icon + ' icon');
    
    const $printCard = $input.closest('.kerp-order-print-type');
    if ($printCard.length) {
        $printCard.find('.kerp-order-print-type__icon em').attr('class', icon);
    }
    
    $tools.find('.kerp-settings-icon-preset').removeClass('is-selected').filter(function() {
        return String($(this).attr('data-icon') || '') === icon;
    }).addClass('is-selected');
}

function syncModalIcon($modal) {
    const $input = $modal.find('.kerp-settings-icon-input').first();
    
    if ($input.length) {
        syncIconPreview($input);
    }
}

function disableCurrentReplacement($modal) {
    const $key = $modal.find('input[id*="delete-type-key"]').first();
    const $select = $modal.find('select[name="replacement_key"]').first();
    
    if (!$key.length || !$select.length) {
        return;
    }
    
    const current = String($key.val() || '');
    $select.find('option').prop('disabled', false);
    
    if (current) {
        $select.find('option[value="' + current.replace(/"/g, '\\"') + '"]').prop('disabled', true);
        if (String($select.val() || '') === current) {
            $select.val('').trigger('change');
        }
    }
}

$(document).on('input', '.kerp-settings-key-input', function() {
    const normalized = normalizeKey($(this).val());
    if ($(this).val() !== normalized) {
        $(this).val(normalized);
    }
});

$(document).on('input', '.kerp-settings-icon-input', function() {
    syncIconPreview($(this));
});

$(document).on('change', '.kerp-settings-color-input', function() {
    syncModalIcon($(this).closest('.modal'));
});

$(document).on('click', '.kerp-settings-icon-preset', function() {
    const icon = String($(this).attr('data-icon') || '');
    const $input = $(this).closest('.form-group').find('.kerp-settings-icon-input').first();
    
    if ($input.length && icon) {
        $input.val(icon).trigger('input');
    }
});

$(document).on('shown.bs.modal', '.modal', function() {
    const $modal = $(this);
    syncModalIcon($modal);
    disableCurrentReplacement($modal);
});

$(document).on('change', '.modal input[id*="delete-type-key"]', function() {
    disableCurrentReplacement($(this).closest('.modal'));
});
