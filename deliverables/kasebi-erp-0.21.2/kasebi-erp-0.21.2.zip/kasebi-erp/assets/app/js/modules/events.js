$(document).ajaxSend(function(event, xhr, settings) {
    if (ajax_search || settings.ajax_search === true) {
        return;
    }
    show_loading_modal();
});
$(document).ajaxStop(function() {
    hide_loading_modal();
});
$(document).on('input', '.price_input', function() {
    toEnglishNumber($(this).val(), this);
    
    let input = $(this);
    let hasDecimal = input.data('decimal') == 1;
    let decimalPlaces = parseInt(input.data('decimal-places') || 0, 10);
    let value = String(this.value || '');
    
    value = value.replace(/\u066B/g, '.').replace(/,/g, '');
    
    if (hasDecimal) {
        value = value.replace(/[^0-9.]/g, '');
        
        let dotIndex = value.indexOf('.');
        
        if (dotIndex !== -1) {
            value =
                value.substring(0, dotIndex + 1) +
                value.substring(dotIndex + 1).replace(/\./g, '');
        }
        
        let parts = value.split('.');
        let intPart = parts[0] || '';
        let decimalPart = parts.length > 1
                          ? parts[1]
                          : null;
        
        if (decimalPlaces > 0 && decimalPart !== null) {
            decimalPart = decimalPart.substring(0, decimalPlaces);
        }
        
        if (intPart === '' && decimalPart === null) {
            input.val('');
            return;
        }
        
        if (intPart === '' && decimalPart !== null) {
            intPart = '0';
        }
        
        let formatted = number_format(intPart);
        
        if (decimalPart !== null) {
            formatted += '.' + decimalPart;
        }
        
        input.val(formatted);
        return;
    }
    
    value = value.replace(/\D/g, '');
    
    if (value === '') {
        input.val('');
        return;
    }
    
    input.val(number_format(value));
});
$(document).on('click', '.page_activator', function(e) {
    e.preventDefault();
    request_panel_page_content($(this).attr('data-url'));
});
$(document).on('click', '.kerp-profile-menu-toggle', function(e) {
    e.preventDefault();

    const $toggle  = $(this),
          $item    = $toggle.closest('.has-sub'),
          willOpen = !$item.hasClass('active');

    $item.siblings('.has-sub')
        .removeClass('active')
        .children('.kerp-profile-menu-toggle')
        .attr('aria-expanded', 'false');

    $item.toggleClass('active', willOpen);
    $toggle.attr('aria-expanded', willOpen ? 'true' : 'false');
});
$(window).on('popstate', function() {
    let data = {
        'action': 'erp_request_back_btn',
        'page':   window.location.href,
    };
    kerpRequestPage(data);
});
$(document).on('change', '.datepicker', function() {
    let val = $(this).val();
    if (val === '') {
        $(this).attr('data-value', '');
        $(this).attr('data-gdate', '');
        $(this).attr('data-jdate', '');
    }
});
$(document).on('click', '.pdp-default', function(e) {
    e.stopPropagation();
});
$(document).on('click', 'a.btn-trigger', function(e) {
    e.preventDefault();
});
$(document).on('click', '.select_current_user_for_modal', function() {
    let input = $(this).attr('data-input');
    $('.hide_on_profile').remove();
    $(input).val($(this).attr('data-id'));
});

$(document).on('click', '.delete_db_item', function(e) {
    e.preventDefault();
    
    const $btn = $(this);
    const element = $btn.get(0);
    const data = {};
    
    if (!element) {
        return;
    }
    
    $.each(element.attributes, function() {
        if (!this.name || this.name.indexOf('data-') !== 0) {
            return;
        }
        
        const key = this.name.substring(5).replace(/-/g, '_');
        
        data[key] = this.value;
    });
    
    if (!data.action) {
        return;
    }
    
    Swal.fire({
        title:             'آیا از حذف این مورد اطمینان دارید؟',
        icon:              'warning',
        text:              'این عملیات غیر قابل بازگشت است',
        focusConfirm:      false,
        showCancelButton:  true,
        confirmButtonText: 'بله',
        cancelButtonText:  'خیر',
    }).then((result) => {
        if (!result.isConfirmed) {
            return;
        }
        
        $btn.addClass('disabled');
        
        $.post(ajax_url, data).done(function(response) {
            change_panel_html(response);
        }).always(function() {
            $btn.removeClass('disabled');
        });
    });
});

function apply_populate_field_data($field, data) {
    if (!data || typeof data !== 'object' || Array.isArray(data)) {
        return;
    }
    
    $.each(data, function(key, value) {
        let dataKey = String(key).replace(/_/g, '-');
        
        if (value === null || typeof value === 'undefined') {
            $field.removeAttr('data-' + dataKey);
            $field.removeData(key);
            return;
        }
        
        if (typeof value === 'object') {
            value = JSON.stringify(value);
        } else if (value === true) {
            value = '1';
        } else if (value === false) {
            value = '0';
        }
        
        $field.attr('data-' + dataKey, value);
        
        /*
         * چون jQuery ممکن است data-* را cache کرده باشد،
         * مقدار cache هم آپدیت می‌شود.
         */
        $field.data(key, value);
    });
}

$(document).on('click', '.edit_row_item,.open_populate_modal', function(e) {
    e.preventDefault();
    
    let $btn = $(this);
    let modalId = $btn.attr('data-modal');
    let populate = $btn.attr('data-populate');
    let $modal = $(modalId);
    
    if (!$modal.length) {
        return;
    }
    
    if (populate) {
        try {
            populate = JSON.parse(populate);
        } catch (err) {
            console.error(
                'Invalid data-populate JSON:',
                err,
                populate,
            );
            
            populate = {};
        }
        
        $.each(populate, function(key, field) {
            if (!field || !field.id) {
                return;
            }
            
            let $field = $modal.find(field.id);
            
            if (!$field.length) {
                $field = $(field.id);
            }
            
            if (!$field.length) {
                return;
            }
            
            /*
             * data باید قبل از change روی فیلد قرار بگیرد.
             */
            apply_populate_field_data(
                $field,
                field.data,
            );
            
            let value = field.value ?? '';
            let type = field.type ?? $field.attr('type') ?? '';
            
            if (
                type === 'switch' ||
                type === 'checkbox'
            ) {
                let isChecked =
                        value === true ||
                        value === 1 ||
                        value === '1' ||
                        value === 'true';
                
                $field.prop('checked', isChecked).trigger('change');
                
                return;
            }
            
            if (type === 'radio') {
                $modal.find(
                    'input[name="' +
                    $field.attr('name') +
                    '"][value="' +
                    value +
                    '"]',
                ).prop('checked', true).trigger('change');
                
                return;
            }
            
            if (type === 'learndash-search') {
                kerp_set_learndash_picker_value($field, value, field.label || '');
                return;
            }
            
            if (
                type === 'select' ||
                type === 'select2' ||
                $field.is('select')
            ) {
                
                let selectValue = normalizeSelectPopulateValue(
                    $field,
                    value,
                );
                
                $field.val(selectValue).trigger('change');
                
                return;
            }
            
            if (type === 'quill') {
                let quillEl = $field.get(0);
                
                if (
                    quillEl &&
                    quillEl.__quill
                ) {
                    quillEl.__quill.root.innerHTML = value || '';
                } else {
                    $field.html(value || '');
                }
                
                return;
            }
            if (type === 'customer-search') {
                let name =
                        $field.attr('data-customer-name') ||
                        $btn.attr('data-customer-name') ||
                        '';
                
                let phone =
                        $field.attr('data-customer-phone') ||
                        $btn.attr('data-customer-phone') ||
                        '';
                
                kerp_set_customer_picker_value(
                    $field,
                    value,
                    name,
                    phone,
                );
                
                return;
            }
            if (type === 'html') {
                $field.html(value);
                
                return;
            }
            
            if (type === 'text') {
                $field.val(value);
                
                return;
            }
            
            if (type === 'no_change') {
                $field.val(value).prop('readonly', true).prop('disabled', false).attr(
                    'data-readonly-on-edit',
                    '1',
                );
                
                return;
            }
            
            if (type === 'upload') {
                let urls = String(value || '').split(',').map(function(url) {
                    return url.trim();
                }).filter(Boolean);
                
                let $uploadZone = $modal.find(
                    '.upload-zone[data-target="' +
                    field.id +
                    '"]',
                );
                
                let uploadZone = $uploadZone.first()[0];
                
                let dropzone =
                        uploadZone &&
                        uploadZone.dropzone
                        ? uploadZone.dropzone
                        : null;
                
                if (dropzone) {
                    dropzone.removeAllFiles(true);
                    
                    urls.forEach(function(url) {
                        let mockFile = {
                            name:          url.split('/').pop(),
                            size:          123456,
                            _uploaded_url: url,
                        };
                        
                        dropzone.emit(
                            'addedfile',
                            mockFile,
                        );
                        
                        dropzone.emit(
                            'thumbnail',
                            mockFile,
                            url,
                        );
                        
                        dropzone.emit(
                            'complete',
                            mockFile,
                        );
                        
                        if (mockFile.previewElement) {
                            mockFile.previewElement.classList.add(
                                'dz-success',
                                'dz-complete',
                            );
                        }
                    });
                }
                
                $field.val(urls.join(',')).trigger('change');
                
                return;
            }
            
            $field.val(value).trigger('change');
        });
    }
    
    const modalTitle = $btn.attr('data-modal-title');
    if (modalTitle) {
        $modal.find('.modal-title').first().text(modalTitle);
    }
    const submitText = $btn.attr('data-submit-text');
    if (submitText) {
        $modal.find('.submit_modal_form').first().text(submitText);
    }
    $modal.modal('show');
});
$(document).on('hidden.bs.modal', '.modal', function() {
    let $modal = $(this);
    
    // Taxonomy trees may contain hundreds of checkboxes. Triggering change on
    // every checkbox makes each event rescan the complete tree. Clear the
    // native select once and let the picker synchronize itself once.
    $modal.find('.kerp-taxonomy-picker').each(function() {
        const select = this.querySelector('.kerp-taxonomy-picker__select');
        const search = this.querySelector('.kerp-taxonomy-picker__search');
        if (!select || select.classList.contains('no_clear')) {
            return;
        }
        if (search && !search.classList.contains('no_clear')) {
            search.value = '';
        }
        select.selectedIndex = -1;
        $(select).trigger('change');
    });
    
    $modal.find(
        'input:not(.kerp-taxonomy-picker__check):not(.kerp-taxonomy-picker__search), textarea, select:not(.kerp-taxonomy-picker__select)',
    ).each(function() {
        let $field = $(this);
        let type = ($field.attr('type') || '').toLowerCase();
        if ($field.hasClass('no_clear')) {
            return;
        }
        if (type === 'checkbox' || type === 'radio') {
            $field.prop('checked', false).trigger('change');
            return;
        }
        
        if ($field.is('select')) {
            $field.val('').trigger('change');
            return;
        }
        
        $field.val('').trigger('change');
    });
    $modal.find('.upload-zone').each(function() {
        if (this.dropzone) {
            this.dropzone.removeAllFiles(true);
        }
    });
    $modal.find('[contenteditable="true"]').each(function() {
        $(this).html('');
    });
    
    $modal.find('.ql-editor').each(function() {
        $(this).html('<p><br></p>');
    });
    
    $modal.find('[data-readonly-on-edit="1"]').each(function() {
        $(this).prop('readonly', false);
        $(this).prop('disabled', false);
    });
});
$(document).on('click', '.add_repeater_row', function(e) {
    e.preventDefault();
    
    let $wrapper = $(this).closest('.repeater_wrapper');
    let $rows = $wrapper.find('.repeater_rows').first();
    let template = $wrapper.find('.repeater_row_template').html();
    if (!template) {
        return;
    }
    
    $rows.find('.add_repeater_row').each(function() {
        let $button = $(this);
        let $row = $button.closest('.repeater_row');
        
        $row.removeClass('repeater_row--new');
        $row.find('.user-avatar .icon').removeClass('ni-plus').addClass('ni-list-check');
        $row.find('.sub-text').text('آیتم ریپیتر');
        
        $button.removeClass('add_repeater_row btn-primary').
            addClass('remove_repeater_row btn-trigger text-danger').
            attr('title', 'حذف ردیف').
            html('<em class="icon ni ni-trash"></em>');
    });
    
    let index = parseInt($wrapper.attr('data-next-index') || '0', 10);
    
    if (!index) {
        index = $rows.find('.repeater_row').length + 1;
    }
    
    template = template.replaceAll('__INDEX__', index);
    $rows.append(template);
    $wrapper.attr('data-next-index', index + 1);
    
    let $newRow = $rows.find('.repeater_row').last();
    
    $newRow.find('input, select, textarea').each(function() {
        let $field = $(this);
        
        if ($field.is(':checkbox') || $field.is(':radio')) {
            $field.prop('checked', false);
            return;
        }
        
        if ($field.attr('type') !== 'hidden') {
            $field.val('');
        }
    });
    NioApp.Select2($newRow.find('.js-select2'));
    kerp_init_ajax_search_selects($newRow);
    evaluateAll($newRow);
});

$(document).on('click', '.remove_repeater_row', function(e) {
    e.preventDefault();
    
    let $row = $(this).closest('.repeater_row');
    let $rows = $row.closest('.repeater_rows');
    
    if ($rows.find('.repeater_row').length <= 1) {
        $row.find('input[type="text"], input[type="number"], input[type="hidden"], input[type="date"], textarea').
            val('');
        $row.find('select').val('').trigger('change');
        $row.find('input[type="checkbox"], input[type="radio"]').prop('checked', false);
        return;
    }
    
    $row.remove();
});

$(document).on('click', '.submit_modal_form', function() {
    let $form = $(this).parents('.modal_form');
    $form.find('.kerp-tab-validation-error').remove();
    let page = $form.attr('data-page') || '';
    
    let data = {
        action: $form.attr('data-action'),
        page:   page,
    };

    if (data.action === 'installments_save_plan') {
        data.active_tab = ($form.find('.kerp-installment-tabs .nav-link.active').attr('href') || '')
            .replace('#installment-pane-', '');
    }
    
    let hasError = false;
    let requiredMap = {}; // key => { fields: [] }
    
    let $inputs = $form.find('input[data-for], select[data-for], textarea[data-for]').filter(function() {
        let $el = $(this);
        if ($form.find('[data-for="registration_mode"]').val() === 'proforma'
            && ($el.attr('data-for') === 'payment_method' || $el.closest('.kerp-payment-receipts').length)) return false;
        if (data.action === 'payments_create_order'
            && $form.find('[data-for="payment_method"]').val() === 'kerp_none'
            && $el.closest('.kerp-payment-receipts').length) return false;
        if (data.action === 'installments_save_plan') {
            const $pane = $el.closest('.tab-pane');
            if ($pane.length && $pane.attr('id') !== 'installment-pane-' + data.active_tab) return false;
        }
        // ❌ hidden via conditional system
        if ($el.closest('.meta-field-row').hasClass('d-none')) {
            return false;
        }
        // hidden fields are included unless their conditional row is hidden.
        if ($el.attr('type') === 'hidden') {
            return true;
        }
        // ❌ disabled fields
        if ($el.is(':disabled')) {
            return false;
        }
        
        return true;
    });
    // ----------------- inputs -----------------
    $inputs.each(function() {
        
        let $field = $(this);
        let key = $field.data('for');
        
        if (!key) {
            return;
        }
        
        if ($field.data('req') == 1) {
            if (!requiredMap[key]) {
                requiredMap[key] = {fields: []};
            }
            requiredMap[key].fields.push($field);
        }
        // checkbox
        if ($field.is(':checkbox')) {
            
            if ($field.is(':checked')) {
                let val = $field.val() || 1;
                
                if (key.includes('[')) {
                    let current = getNestedValue(data, key);
                    if (!Array.isArray(current)) {
                        setNestedValue(data, key, []);
                        current = getNestedValue(data, key);
                    }
                    current.push(val);
                } else {
                    if (!Array.isArray(data[key])) {
                        data[key] = [];
                    }
                    data[key].push(val);
                }
            }
            
            return;
        }
        
        // radio
        if ($field.is(':radio')) {
            
            if ($field.is(':checked')) {
                let val = $field.val();
                
                if (key.includes('[')) {
                    setNestedValue(data, key, val);
                } else {
                    data[key] = val;
                }
            }
            
            return;
        }
        
        let val = $field.val();
        if (key == 'phone') {
            if (!validate_phone_number(val)) {
                NioApp.Toast('شماره تلفن همراه معتبر نیست', 'error',
                    {position: 'top-right'});
                return;
            }
        }
        // ----------------- number validation -----------------
        if ($field.hasClass('number_type')) {
            toEnglishNumber($field.val(), this);
            
            let raw = String(this.value || '').replace(/\D/g, '');
            
            if (raw === '' && String(this.value || '').trim() !== '') {
                NioApp.Toast('مقدار فیلد «' + getFieldLabel($field) + '» باید عددی باشد', 'error', {
                    position: 'top-right',
                });
                
                showRequiredError($field);
                hasError = true;
                return;
            }
            
            val = raw;
        }
        
        // ----------------- date validation -----------------
        if ($field.hasClass('datepicker')) {
            let dateValue = String(val || '').trim();
            
            if (dateValue !== '' && !/^\d{4}-\d{1,2}-\d{1,2}$/.test(dateValue)) {
                NioApp.Toast('فیلد «' + getFieldLabel($field) + '» معتبر نیست', 'error', {
                    position: 'top-right',
                });
                
                showRequiredError($field);
                hasError = true;
                return;
            }
        }
        
        if (key.includes('[')) {
            setNestedValue(data, key, val);
        } else {
            data[key] = val;
        }
        
    });
    
    Object.keys(requiredMap).forEach(function(key) {
        if (hasError) {
            return;
        }
        let value = key.includes('[')
                    ? getNestedValue(data, key)
                    : data[key];
        
        let isEmpty =
                value === undefined ||
                value === null ||
                (Array.isArray(value) && value.length === 0) ||
                (typeof value === 'string' && value.trim() === '');
        
        if (isEmpty) {
            let $firstField = requiredMap[key].fields[0];
            showRequiredError($firstField);
            hasError = true;
        }
    });
    
    // ----------------- quill editors -----------------
    let $quills = $form.find('.quill-basic[data-for]').filter(function() {
        
        let $el = $(this);
        
        // ❌ hidden by conditional system
        if ($el.closest('.meta-field-row').hasClass('d-none')) {
            return false;
        }
        
        return true;
    });
    
    $quills.each(function() {
        
        let $wrapper = $(this);
        let key = $wrapper.data('for');
        
        if (!key) {
            return;
        }
        
        let quillInstance = $wrapper.data('quill');
        let html = '';
        
        if (quillInstance && quillInstance.root) {
            html = quillInstance.root.innerHTML;
        } else {
            html = $wrapper.find('.ql-editor').html() || '';
        }
        
        let textContent = $('<div>').html(html).text().trim();
        
        if ($wrapper.data('req') == 1 && textContent === '') {
            if (!hasError) {
                showRequiredError($wrapper);
            }
            hasError = true;
        }
        
        if (key.includes('[')) {
            setNestedValue(data, key, html);
        } else {
            data[key] = html;
        }
    });
    
    if (hasError) {
        return;
    }
    
    $.post(ajax_url, data, function(response) {
        change_panel_html(response);
    });
});
$(document).on('change input', '[data-for]', function() {
    evaluateAll($(this));
});
$(document).on('select2:select select2:clear', '[data-for]', function() {
    evaluateAll($(this));
});
function kerp_set_header_search(open, restoreFocus) {
    const header = $('.nk-header-search');
    const input = header.find('#header_user_search');
    header.find('.search-wrap').toggleClass('active', open).attr('aria-hidden', String(!open));
    header.find('.search-toggle').toggleClass('active', open).attr('aria-expanded', String(open));
    if (open) {
        input.trigger('focus');
        if ($.trim(input.val())) input.trigger('input');
    } else {
        input.data('search-version', (input.data('search-version') || 0) + 1);
        clearTimeout(input.data('search-timer'));
        if (search_ajax && typeof search_ajax.abort === 'function') search_ajax.abort();
        ajax_search = false;
        input.attr('aria-busy', 'false');
        header.find('.search_result_container').empty().hide();
        if (restoreFocus) header.find('.search-toggle').trigger('focus');
        else input.trigger('blur');
    }
}
$(document).on('click', '.kerp-header-search-toggle', function(e) {
    e.preventDefault();
    const open = !$(this).closest('.nk-header-search').find('.search-wrap').hasClass('active');
    kerp_set_header_search(open, !open);
});
$(document).on('click', '.nk-header-search .search-submit', function() {
    $('#header_user_search').trigger('input');
});
$(document).on('keydown', '#header_user_search', function(e) {
    if (e.key === 'Enter') {
        e.preventDefault();
        $(this).trigger('input');
    }
});
$(document).on('keydown', function(e) {
    if (e.key === 'Escape' && $('.nk-header-search .search-wrap').hasClass('active')) {
        kerp_set_header_search(false, true);
    }
});
$(document).on('click', function(e) {
    if (!$('.nk-header-search .search-wrap').hasClass('active')) return;
    if (!$(e.target).closest('.nk-header-search').length ||
        $(e.target).closest('.nk-header-search .page_activator, .nk-header-search [data-bs-toggle="modal"]').length) {
        kerp_set_header_search(false, false);
    }
});
$(document).on('input', '#header_user_search', function() {
    let input = this;
    let search = $.trim(input.value);
    let result = $(input).closest('.nk-header-search').find('.search_result_container');
    let searchVersion = ($(input).data('search-version') || 0) + 1;
    $(input).data('search-version', searchVersion);
    let isCurrentSearch = function() {
        return $(input).data('search-version') === searchVersion;
    };
    let showSearchError = function() {
        result.html(
            '<div class="card card-stretch m-0"><div class="card-inner p-3 text-danger" role="alert">جستجو انجام نشد. لطفاً دوباره تلاش کنید.</div></div>',
        ).show();
    };
    clearTimeout($(input).data('search-timer'));
    if (search_ajax && typeof search_ajax.abort === 'function') {
        search_ajax.abort();
    }
    ajax_search = false;
    $(input).attr('aria-busy', 'false');
    result.empty().hide();
    if (search === '') {
        return;
    }
    $(input).attr('aria-busy', 'true');
    result.html(
        '<div class="card card-stretch m-0"><div class="card-inner p-3 d-flex align-items-center gap-2" role="status" aria-live="polite">' +
        '<span class="spinner-border spinner-border-sm text-primary" aria-hidden="true"></span>' +
        '<span class="sub-text">در حال جستجو…</span></div></div>',
    ).show();
    $(input).data('search-timer', setTimeout(function() {
        ajax_search = true;
        search_ajax = $.post(ajax_url, {
            action: 'customers_search',
            search: search,
        }, function(response) {
            if (!isCurrentSearch()) {
                return;
            }
            if (response && response.status !== 'error' && typeof response.searchResult === 'string') {
                result.html(response.searchResult).show();
            } else {
                showSearchError();
            }
        }).fail(function(xhr, status) {
            if (status !== 'abort' && isCurrentSearch()) {
                showSearchError();
            }
        }).always(function() {
            if (isCurrentSearch()) {
                ajax_search = false;
                $(input).attr('aria-busy', 'false');
            }
        });
    }, 300));
});

function kerp_get_customer_picker(element) {
    return $(element).closest('.kerp-customer-picker');
}

function kerp_get_customer_picker_placeholder(picker) {
    return '<span class="sub-text">برای انتخاب کاربر، در فیلد روبه‌رو جستجو کنید.</span>';
}

function kerp_build_customer_search_item(customer) {
    let item = $('<div>', {
        class:    'nk-tb-item kerp-customer-picker-result',
        role:     'button',
        tabindex: 0,
    });
    item.attr({
        'data-customer-id':    customer.id || 0,
        'data-customer-name':  customer.name || '',
        'data-customer-phone': customer.phone || '',
    });
    let customerColumn = $('<div>', {
        class: 'nk-tb-col',
    });
    let userCard = $('<div>', {
        class: 'user-card',
    });
    let avatar = $('<div>', {
        class: 'user-avatar xs',
    });
    $('<span>').text((customer.name || '?').substring(0, 1)).appendTo(avatar);
    let userInfo = $('<div>', {
        class: 'user-info',
    });
    $('<span>', {
        class: 'tb-lead',
    }).text(customer.name || '').appendTo(userInfo);
    avatar.appendTo(userCard);
    userInfo.appendTo(userCard);
    userCard.appendTo(customerColumn);
    customerColumn.appendTo(item);
    $('<div>', {
        class: 'nk-tb-col tb-col-md',
    }).append(
        $('<span>').text(customer.phone || ''),
    ).appendTo(item);
    return item;
}

function kerp_render_customer_search_results(picker, customers) {
    let result = picker.find('.kerp-customer-picker-results');
    result.empty();
    if (!customers.length) {
        result.html(
            '<div class="card card-bordered"><div class="card-inner p-3"><span class="sub-text">کاربر پیدا نشد.</span></div></div>',
        ).show();
        return;
    }
    let list = $('<div>', {
        class: 'card card-bordered is-compact nk-tb-list nk-tb-ulist',
    });
    customers.forEach(function(customer) {
        list.append(kerp_build_customer_search_item(customer));
    });
    result.append(list).show();
}

function kerp_search_customer_for_picker(input) {
    let searchInput = $(input);
    let picker = kerp_get_customer_picker(input);
    let result = picker.find('.kerp-customer-picker-results');
    let search = $.trim(searchInput.val());
    let timer = searchInput.data('search-timer');
    let request = picker.data('search-request');
    
    clearTimeout(timer);
    
    if (request && typeof request.abort === 'function') {
        request.abort();
    }
    
    if (search.length < 2) {
        result.empty().hide();
        return;
    }
    
    timer = setTimeout(function() {
        ajax_search = true;
        result.html(
            '<div class="card card-bordered"><div class="card-inner p-3 d-flex align-items-center gap-2" role="status" aria-live="polite"><span class="spinner-border spinner-border-sm text-primary" aria-hidden="true"></span><span class="sub-text">در حال جستجو…</span></div></div>',
        ).show();
        
        request = $.post(ajax_url, {
            action: picker.attr('data-search-action') || 'customers_search',
            search: search,
            limit:  10,
        }, function(response) {
            ajax_search = false;
            let customers = Array.isArray(response.users)
                            ? response.users
                            : [];
            
            kerp_render_customer_search_results(picker, customers);
        }).fail(function(xhr, status) {
            ajax_search = false;
            if (status === 'abort') {
                return;
            }
            
            result.html(
                '<div class="card card-bordered"><div class="card-inner p-3"><span class="text-danger">خطا در جستجوی کاربر.</span></div></div>',
            ).show();
        });
        
        picker.data('search-request', request);
    }, 300);
    
    searchInput.data('search-timer', timer);
}

function kerp_set_customer_picker_value($field, customerId, name, phone) {
    let picker = kerp_get_customer_picker($field);
    let preview = picker.find('.kerp-customer-picker-preview');
    
    customerId = parseInt(customerId || '0', 10);
    name = name || '';
    phone = phone || '';
    
    $field.val(customerId || '').trigger('change');
    
    picker.find('.kerp-customer-picker-search').val('');
    picker.find('.kerp-customer-picker-results').empty().hide();
    
    if (!customerId) {
        preview.html(
            kerp_get_customer_picker_placeholder(picker),
        );
        
        return;
    }
    
    preview.empty();
    
    let wrapper = $('<div>', {
        class: 'd-flex align-center justify-between',
    });
    
    let userCard = $('<div>', {
        class: 'user-card',
    });
    
    let avatar = $('<div>', {
        class: 'user-avatar xs',
    });
    
    $('<span>').text(name.substring(0, 1) || '?').appendTo(avatar);
    
    let userInfo = $('<div>', {
        class: 'user-info',
    });
    
    $('<span>', {
        class: 'tb-lead',
    }).text(name).appendTo(userInfo);
    
    if (phone) {
        $('<span>', {
            class: 'sub-text',
        }).text(phone).appendTo(userInfo);
    }
    
    avatar.appendTo(userCard);
    userInfo.appendTo(userCard);
    userCard.appendTo(wrapper);
    
    if (picker.attr('data-locked') !== '1') {
        $('<button>', {
            type:  'button',
            class: 'btn btn-sm btn-icon btn-trigger kerp-customer-picker-clear',
        }).append(
            $('<em>', {
                class: 'icon ni ni-cross',
            }),
        ).appendTo(wrapper);
    }
    
    preview.append(wrapper);
}

function kerp_select_customer_for_picker(element) {
    let item = $(element);
    let picker = kerp_get_customer_picker(element);
    let field = picker.find('[data-for]').first();
    
    let customerId = parseInt(
        item.attr('data-customer-id') || '0',
        10,
    );
    
    if (!customerId) {
        return;
    }
    
    kerp_set_customer_picker_value(
        field,
        customerId,
        item.attr('data-customer-name') || '',
        item.attr('data-customer-phone') || '',
    );
}

function kerp_clear_customer_picker(element) {
    let picker = kerp_get_customer_picker(element);
    
    if (picker.attr('data-locked') === '1') {
        return;
    }
    
    picker.find('[data-for]').first().val('').trigger('change');
    picker.find('.kerp-customer-picker-search').val('');
    picker.find('.kerp-customer-picker-results').empty().hide();
    picker.find('.kerp-customer-picker-preview').html(
        kerp_get_customer_picker_placeholder(picker),
    );
}

$(document).on('input', '.kerp-customer-picker-search', function() {
    kerp_search_customer_for_picker(this);
});

$(document).on('click', '.kerp-customer-picker-result', function() {
    kerp_select_customer_for_picker(this);
});

$(document).on('keydown', '.kerp-customer-picker-result', function(e) {
    if (e.key !== 'Enter' && e.key !== ' ') {
        return;
    }
    
    e.preventDefault();
    kerp_select_customer_for_picker(this);
});

$(document).on('click', '.kerp-customer-picker-clear', function() {
    kerp_clear_customer_picker(this);
});

$(document).on('click', function(e) {
    if ($(e.target).closest('.kerp-customer-picker').length) {
        return;
    }
    
    $('.kerp-customer-picker-results').empty().hide();
});

function kerp_get_learndash_picker(element) {
    return $(element).closest('.kerp-learndash-picker');
}

function kerp_get_learndash_picker_field(picker, dataFor) {
    dataFor = dataFor || picker.attr('data-for') || '';
    return picker.children('input[type="hidden"][data-for]').filter(function() {
        return $(this).attr('data-for') === dataFor;
    }).first();
}

function kerp_learndash_picker_placeholder() {
    return '<span class="sub-text">برای انتخاب، عنوان را در فیلد روبه‌رو جستجو کنید.</span>';
}

function kerp_set_learndash_picker_value(field, postId, title) {
    let picker = kerp_get_learndash_picker(field);
    let preview = picker.find('.kerp-learndash-picker-preview');
    postId = parseInt(postId || '0', 10);
    field.val(postId || '').trigger('change');
    picker.find('.kerp-learndash-picker-search').val('');
    picker.find('.kerp-learndash-picker-results').empty().hide();
    if (!postId) {
        preview.html(kerp_learndash_picker_placeholder());
        return;
    }
    let wrapper = $('<div>', {class: 'd-flex align-center justify-between'});
    $('<span>', {class: 'tb-lead'}).text(title || ('#' + postId)).appendTo(wrapper);
    $('<button>', {
        type:  'button',
        class: 'btn btn-sm btn-icon btn-trigger kerp-learndash-picker-clear',
        'data-for': field.attr('data-for') || picker.attr('data-for') || '',
    }).
        append($('<em>', {class: 'icon ni ni-cross'})).appendTo(wrapper);
    preview.empty().append(wrapper);
}

function kerp_render_learndash_results(picker, items) {
    let result = picker.find('.kerp-learndash-picker-results').empty();
    if (!items.length) {
        result.html(
                '<div class="card card-bordered"><div class="card-inner p-3"><span class="sub-text">درس یا سرفصلی پیدا نشد.</span></div></div>').
            show();
        return;
    }
    let list = $('<div>', {class: 'card card-bordered is-compact nk-tb-list nk-tb-ulist'});
    items.forEach(function(item) {
        let row = $('<div>', {
            class:    'nk-tb-item kerp-learndash-picker-result',
            role:     'button',
            tabindex: 0,
        });
        row.attr({
            'data-post-id':    item.id || 0,
            'data-post-title': item.text || '',
            'data-for':        picker.attr('data-for') || '',
        });
        $('<div>', {class: 'nk-tb-col'}).append(
            $('<div>', {class: 'user-card'}).append(
                $('<div>', {class: 'user-avatar xs'}).append($('<em>', {class: 'icon ni ni-book-read'})),
                $('<div>', {class: 'user-info'}).append($('<span>', {class: 'tb-lead'}).text(item.text || '')),
            ),
        ).appendTo(row);
        list.append(row);
    });
    result.append(list).show();
}

function kerp_search_learndash_for_picker(input) {
    let searchInput = $(input);
    let picker = kerp_get_learndash_picker(input);
    let result = picker.find('.kerp-learndash-picker-results');
    let search = $.trim(searchInput.val());
    clearTimeout(searchInput.data('search-timer'));
    let previous = picker.data('search-request');
    if (previous && typeof previous.abort === 'function') {
        previous.abort();
    }
    if (search.length < 2) {
        result.empty().hide();
        return;
    }
    searchInput.data('search-timer', setTimeout(function() {
        result.html(
                '<div class="card card-bordered"><div class="card-inner p-3"><span class="spinner-border spinner-border-sm"></span></div></div>').
            show();
        let request = $.post(ajax_url, {
            action: picker.attr('data-search-action') || 'programs_search_learndash_content',
            search: search,
            page:   1,
        });
        picker.data('search-request', request);
        request.done(function(response) {
            let items = response && response.status === 'success' && Array.isArray(response.results)
                        ? response.results
                        : [];
            kerp_render_learndash_results(picker, items);
        }).fail(function(xhr, status) {
            if (status !== 'abort') {
                result.html(
                        '<div class="card card-bordered"><div class="card-inner p-3"><span class="text-danger">خطا در جستجوی محتوای LearnDash.</span></div></div>').
                    show();
            }
        }).always(function() { picker.removeData('search-request'); });
    }, 300));
}

$(document).on('input', '.kerp-learndash-picker-search', function() { kerp_search_learndash_for_picker(this); });
$(document).on('click', '.kerp-learndash-picker-result', function() {
    let item   = $(this),
        picker = kerp_get_learndash_picker(this);
    let field = kerp_get_learndash_picker_field(picker, item.attr('data-for'));
    if (!field.length) return;
    kerp_set_learndash_picker_value(field, item.attr('data-post-id'), item.attr('data-post-title'));
});
$(document).on('keydown', '.kerp-learndash-picker-result', function(e) {
    if (e.key !== 'Enter' && e.key !== ' ') {
        return;
    }
    e.preventDefault();
    $(this).trigger('click');
});
$(document).on('click', '.kerp-learndash-picker-clear', function() {
    let picker = kerp_get_learndash_picker(this);
    let field = kerp_get_learndash_picker_field(picker, $(this).attr('data-for'));
    if (!field.length) return;
    kerp_set_learndash_picker_value(field, 0, '');
});
$(document).on('click', function(e) {
    if (!$(e.target).closest('.kerp-learndash-picker').length) {
        $('.kerp-learndash-picker-results').empty().hide();
    }
});
$(document).on('hidden.bs.modal', '.modal', function() {
    $(this).find('.kerp-learndash-picker').each(function() {
        let picker  = $(this),
            request = picker.data('search-request');
        if (request && typeof request.abort === 'function') {
            request.abort();
        }
        picker.removeData('search-request');
        picker.find('.kerp-learndash-picker-search').val('');
        picker.find('.kerp-learndash-picker-results').empty().hide();
        picker.find('.kerp-learndash-picker-preview').html(kerp_learndash_picker_placeholder());
    });
});
$(document).on('click', '.show_public_content_modal', function(e) {
    e.preventDefault();
    let button = $(this);
    let modal = $('#kerpPublicContentModal');
    let title = button.attr('data-modal-title') || '';
    let contentTarget = button.attr('data-content-target') || '';
    let content = button.attr('data-modal-content') || '';
    
    if (!modal.length) {
        return;
    }
    if (contentTarget && $(contentTarget).length) {
        content = $(contentTarget).html();
    }
    modal.find('.modal-title').text(title);
    modal.find('.kerp-public-modal-content').html(content);
    modal.modal('show');
});

$(document).on('click', '.kerp-review-image-magnify', function(e) {
    e.preventDefault();
    e.stopImmediatePropagation();
    let button = $(this);
    let imageUrl = button.attr('data-image-url') || button.attr('href') || '';
    let imageName = button.attr('data-image-name') || '';
    let isPng = /\.png(?:$|[?#])/i.test(imageUrl) || /\.png$/i.test(imageName);

    if (!imageUrl) {
        return;
    }
    if (!$.magnificPopup || typeof $.magnificPopup.open !== 'function') {
        window.open(imageUrl, '_blank', 'noopener,noreferrer');
        return;
    }

    $.magnificPopup.open({
        items: {src: imageUrl, title: imageName},
        type: 'image',
        mainClass: 'kerp-review-magnifier' + (isPng ? ' kerp-review-magnifier--png' : ''),
        closeOnContentClick: false,
        closeOnBgClick: true,
        image: {
            verticalFit: true,
            titleSrc: function() {
                return imageName;
            }
        },
        callbacks: {
            open: function() {
                $('html, body').addClass('kerp-review-magnifier-open');
            },
            close: function() {
                $('html, body').removeClass('kerp-review-magnifier-open');
            }
        },
        zoom: {
            enabled: true,
            duration: 220,
            opener: function() {
                return button;
            }
        }
    });
});

$(document).on('input', '#kerp-employee-code-prefix', function() {
    let prefix = $('#kerp-employee-code-prefix').val() || '';
    let preview = prefix + '1024';
    
    $('.kerp-employee-code-preview, #kerp-employee-code-preview').text(preview);
});

$(document).on('change', '.load_city', function() {
    let city = $(this).attr('data-city');
    let target = $(this).attr('data-target');
    request_city_list(
        $(this).val(),
        city,
        target,
    );
});

function kerp_normalize_ajax_select_results(response) {
    let items = [];
    
    if (response && Array.isArray(response.results)) {
        items = response.results;
    } else if (response && response.data && Array.isArray(response.data.results)) {
        items = response.data.results;
    } else if (response && Array.isArray(response.data)) {
        items = response.data;
    } else if (response && Array.isArray(response.items)) {
        items = response.items;
    }
    
    return items.map(function(item) {
        if (typeof item !== 'object' || item === null) {
            return {
                id:   item,
                text: item,
            };
        }
        
        return {
            id:   item.id || item.value || '',
            text: item.text || item.label || item.name || item.title || '',
        };
    });
}

function kerp_init_ajax_search_select(element) {
    let select = $(element);
    let action = select.attr('data-action');
    
    if (!action || typeof select.select2 !== 'function') {
        return;
    }
    
    if (select.data('select2')) {
        select.select2('destroy');
    }
    
    let placeholder = select.attr('data-placeholder');
    
    if (!placeholder) {
        placeholder = select.find('option:first').text().trim();
    }
    
    select.select2({
        width:              '100%',
        dir:                'rtl',
        placeholder:        placeholder,
        allowClear:         true,
        minimumInputLength: 2,
        ajax:               {
            url:      ajax_url,
            type:     'POST',
            dataType: 'json',
            delay:    300,
            cache:    true,
            
            beforeSend: function() {
                ajax_search = true;
            },
            
            data: function(params) {
                return {
                    action: action,
                    search: params.term || '',
                    page:   params.page || 1,
                };
            },
            
            processResults: function(response) {
                return {
                    results: kerp_normalize_ajax_select_results(response),
                };
            },
            
            complete: function() {
                ajax_search = false;
            },
        },
    });
}


function kerp_init_installment_plan(scope) {
    let $scope = $(scope);
    let $forms = $scope.find('[data-action="installments_save_plan"]').add($scope.closest('[data-action="installments_save_plan"]'));
    $forms.each(function() {
        const $form = $(this);
        if ($form.data('installmentReady')) {
            $scope.find('.installment-lesson').each(function() { fill($(this), $form.data('installmentLessons'), true); });
            return;
        }
        $form.data('installmentReady', true);
        const $course = $form.find('[data-for="course_id"]');
        const $product = $form.find('[data-for="product_id"]');
        let courseVersion = 0, productVersion = 0;
        let initial = [];
        $form.find('.installment-lesson').first().find('option').each(function() {
            if (this.value !== '') initial.push({id: this.value, text: this.text});
        });
        $form.data('installmentLessons', $course.val() ? initial : null);
        function update(rows, preserve) {
            $form.data('installmentLessons', rows);
            $form.find('.installment-lesson').each(function() { fill($(this), rows, preserve); });
        }
        function request(data) {
            return $.ajax({url: ajax_url, type: 'POST', dataType: 'json', data: Object.assign({
                action: 'installments_plan_options',
                installment_nonce: $form.find('[data-for="installment_nonce"]').val()
            }, data)});
        }
        function failure(message) { NioApp.Toast(message || 'دریافت اطلاعات انجام نشد؛ دوباره انتخاب کنید.', 'error', {position: 'top-right'}); }
        $course.on('change.installments', function(event, automatic) {
            if (!automatic) productVersion++;
            const version = ++courseVersion;
            const id = $course.val();
            update(null, false);
            if (!id) return;
            request({kind: 'course', course_id: id}).done(function(response) {
                if (version !== courseVersion || !$form[0].isConnected) return;
                if (response.status !== 'success') { failure(response.message || response.msg); return; }
                update([{id: '0', text: 'تمام دوره (بدون محدودیت اقساط)'}].concat(response.results || []), false);
            }).fail(function() { if (version === courseVersion && $form[0].isConnected) failure(); });
        });
        $product.on('change.installments', function() {
            const version = ++productVersion;
            const id = $product.val();
            $course.empty().append(new Option('جستجوی نام یا شناسه دوره', '')).val('').trigger('change', [true]);
            if (!id) return;
            request({kind: 'product', product_id: id}).done(function(response) {
                if (version !== productVersion || !$form[0].isConnected) return;
                if (response.status !== 'success') { failure(response.message || response.msg); return; }
                const rows = response.results || [];
                rows.forEach(function(row) { $course.append(new Option(row.text, row.id)); });
                if (rows.length) $course.val(String(rows[0].id)).trigger('change', [true]);
                if (rows.length > 1) NioApp.Toast('محصول چند دوره مرتبط دارد؛ دوره اول انتخاب شد. دوره موردنظر را بررسی کنید.', 'info', {position: 'top-right'});
            }).fail(function() { if (version === productVersion && $form[0].isConnected) failure(); });
        });
    });
    function fill($select, rows, preserve) {
        const previous = preserve ? $select.val() : '';
        $select.empty().append(new Option(rows === null ? 'ابتدا دوره لرن‌دش را انتخاب کنید' : 'انتخاب درس', ''));
        (rows || []).forEach(function(row) { $select.append(new Option(row.text, row.id)); });
        $select.prop('disabled', rows === null).val(previous || '').trigger('change.select2');
    }
}

function kerp_init_ajax_search_selects(scope) {
    kerp_init_installment_plan(scope || document);
    let container = scope ? $(scope) : $(document);
    
    container.find('.select_ajax_search').each(function() {
        kerp_init_ajax_search_select(this);
    });
}

$(document).ready(function() {
    kerp_init_ajax_search_selects(document);
    evaluateAll();
});

function kerp_hide_active_tooltips() {
    const Tooltip = window.bootstrap && window.bootstrap.Tooltip
                    ? window.bootstrap.Tooltip
                    : null;
    const triggers = document.querySelectorAll(
        '[data-bs-toggle="tooltip"], [data-toggle="tooltip"], .nk-tooltip, .btn-tooltip, .tipinfo, .nk-menu-tooltip',
    );
    
    triggers.forEach(function(trigger) {
        if (Tooltip && typeof Tooltip.getInstance === 'function') {
            const instance = Tooltip.getInstance(trigger);
            if (instance && typeof instance.hide === 'function') {
                instance.hide();
            }
        }
        
        trigger.removeAttribute('aria-describedby');
    });
    
    document.querySelectorAll('.tooltip').forEach(function(tooltip) {
        tooltip.remove();
    });
}

$(document).on('show.bs.modal mfpOpen', function() {
    kerp_hide_active_tooltips();
});

$(document).on(
    'click',
    '[data-bs-toggle="tooltip"], [data-toggle="tooltip"], .nk-tooltip, .btn-tooltip, .tipinfo, .nk-menu-tooltip',
    function() {
        kerp_hide_active_tooltips();
    },
);

$(document).on('shown.bs.dropdown shown.bs.modal shown.bs.collapse', function(e) {
    kerp_init_ajax_search_selects(e.target);
});

function kerp_get_load_modal_data(element) {
    let data = {};
    
    $.each(element.attributes, function() {
        if (!this.name || this.name.indexOf('data-') !== 0) {
            return;
        }
        
        if (this.name.indexOf('data-bs-') === 0) {
            return;
        }
        
        let key = this.name.substring(5).replace(/-/g, '_');
        
        if (
            key === 'modal'
            || key === 'target'
            || key === 'modal_title'
            || key === 'response_key'
        ) {
            return;
        }
        
        data[key] = this.value;
    });
    
    return data;
}

function kerp_get_load_modal_target(modal, selector) {
    if (selector) {
        let target = modal.find(selector).first();
        
        if (target.length) {
            return target;
        }
    }
    
    return modal.find('.kerp-dynamic-modal-content').first();
}

function kerp_set_load_modal_loading(target) {
    target.html(
        '<div class="text-center py-5">' +
        '<div class="spinner-border spinner-border-sm" role="status"></div>' +
        '</div>',
    );
}

function kerp_set_load_modal_error(target, message) {
    target.html(
        '<div class="alert alert-danger mb-0">' +
        $('<div>').text(message).html() +
        '</div>',
    );
}

function kerp_show_load_modal(modal) {
    $(modal).modal('show');
}

function kerp_load_data_to_modal(element) {
    let button = $(element);
    let modalSelector = button.attr('data-modal') || '';
    let targetSelector = button.attr('data-target') || '';
    let modalTitle = button.attr('data-modal-title') || '';
    let responseKey = button.attr('data-response-key') || 'html';
    let modal = $(modalSelector);
    
    if (!modal.length) {
        return;
    }
    
    let target = kerp_get_load_modal_target(modal, targetSelector);
    
    if (!target.length) {
        return;
    }
    
    let data = kerp_get_load_modal_data(element);
    
    if (!data.action) {
        return;
    }
    
    let previousRequest = modal.data('kerp-load-request');
    
    if (
        previousRequest
        && previousRequest.readyState !== 4
    ) {
        previousRequest.abort();
    }
    
    modal.find('.modal-title').text(modalTitle);
    
    kerp_set_load_modal_loading(target);
    kerp_show_load_modal(modal);
    
    button.addClass('disabled');
    
    let request = $.ajax({
        url:  ajax_url,
        type: 'POST',
        data: data,
    });
    
    modal.data('kerp-load-request', request);
    
    request.done(function(response) {
        if (
            !response
            || response.status !== 'success'
        ) {
            let message = response && (response.message || response.msg)
                          ? response.message || response.msg
                          : 'خطا در دریافت اطلاعات.';
            
            kerp_set_load_modal_error(target, message);
            
            return;
        }
        
        let content = response[responseKey];
        
        if (typeof content === 'undefined') {
            content = '';
        }
        
        target.html(content);
        if (typeof activate_date_pickers === 'function') {
            activate_date_pickers();
        }
        if (NioApp.Picker && typeof NioApp.Picker.time === 'function') {
            NioApp.Picker.time(target.find('.time-picker'), {timeFormat: 'HH:mm'});
        }
        if (NioApp.Dropzone && typeof NioApp.Dropzone.init === 'function') {
            NioApp.Dropzone.init();
        }
    });
    
    request.fail(function(xhr, status) {
        if (status === 'abort') {
            return;
        }
        
        kerp_set_load_modal_error(
            target,
            'خطا در ارتباط با سرور.',
        );
    });
    
    request.always(function() {
        button.removeClass('disabled');
        modal.removeData('kerp-load-request');
    });
}

$(document).on('click', '.kerp_load_data_to_modal', function(e) {
    e.preventDefault();
    
    kerp_load_data_to_modal(this);
});

$(document).on('hidden.bs.modal', '#kerpDynamicModal', function() {
    let modal = $(this);
    let request = modal.data('kerp-load-request');
    
    if (
        request
        && request.readyState !== 4
    ) {
        request.abort();
    }
    
    modal.removeData('kerp-load-request');
    modal.find('.modal-title').text('');
    modal.find('.kerp-dynamic-modal-content').empty();
});

function parse_row_inline_needs(value) {
    if (!value) {
        return [];
    }
    
    try {
        let parsed = JSON.parse(value);
        
        return parsed && typeof parsed === 'object'
               ? parsed
               : [];
    } catch (error) {
        console.error('Invalid data-needs JSON:', error, value);
        
        return [];
    }
}

function get_row_inline_action_data($element) {
    let data = {
        action:  $element.attr('data-action') || '',
        item_id: $element.attr('data-item-id') || '',
        page:    $element.attr('data-page') || $('#current_page').val() || '',
    };
    
    let ignored = [
        'action',
        'itemId',
        'swalTitle',
        'page',
        'needs',
    ];
    
    Object.entries($element.get(0).dataset).forEach(function([key, value]) {
        if (ignored.includes(key)) {
            return;
        }
        
        data[key] = value;
    });
    
    return data;
}

function limit_row_inline_need_value(element) {
    let $element = $(element);
    let max = parseFloat($element.attr('data-max'));
    
    if (isNaN(max)) {
        return;
    }
    
    let value = parseFloat($element.val());
    
    if (isNaN(value)) {
        return;
    }
    
    if (value > max) {
        $element.val(max);
    }
}

function row_inline_action(element) {
    let $element = $(element);
    let needs = parse_row_inline_needs(
        $element.attr('data-needs'),
    );
    
    let data = get_row_inline_action_data(
        $element,
    );
    
    if (!data.action) {
        return;
    }
    
    Swal.fire({
        title:             $element.attr('data-swal-title') || 'آیا مطمئن هستید؟',
        icon:              'warning',
        html:              needs.length || Object.keys(needs).length
                           ? buildNeedsHtml(needs, 'فرآیند')
                           : '',
        showCancelButton:  true,
        confirmButtonText: 'بله',
        cancelButtonText:  'خیر',
        onRender:          function() {
            $(Swal.getHtmlContainer()).off('input.rowInline change.rowInline', '[data-max]').on(
                'input.rowInline change.rowInline',
                '[data-max]',
                function() {
                    limit_row_inline_need_value(this);
                },
            );
        },
    }).then(function(result) {
        if (!result.isConfirmed) {
            return;
        }
        
        Object.assign(
            data,
            collectNeedsValues(needs),
        );
        
        $element.addClass('disabled');
        
        $.post(
            ajax_url,
            data,
        ).done(function(response) {
            change_panel_html(response);
        }).fail(function() {
            toast_msg(
                'خطایی در انجام عملیات رخ داد.',
                'error',
            );
        }).always(function() {
            $element.removeClass('disabled');
        });
    });
}

$(document).on('click', '.row_inline_action', function(e) {
    e.preventDefault();
    
    row_inline_action(this);
});
