const kerpOrdersBackfillNumber = new Intl.NumberFormat('fa-IR');

async function kerpOrdersRunBackfill(root, button) {
    if (root.dataset.running === '1') return;
    root.dataset.running = '1';
    root.setAttribute('aria-busy', 'true');
    button.disabled = true;
    const label = button.querySelector('span');
    const message = root.querySelector('[data-orders-backfill-message]');
    const bar = root.querySelector('[data-orders-backfill-bar]');
    if (!root.dataset.nextPage) {
        bar.style.width = '0%';
        bar.setAttribute('aria-valuenow', '0');
        root.querySelector('[data-orders-backfill-percent]').textContent = '۰٪';
        root.querySelector('[data-orders-backfill-count]').textContent = 'آماده شروع';
    }
    label.textContent = 'در حال همگام‌سازی…';
    message.classList.remove('text-danger');
    bar.classList.remove('bg-success');
    bar.classList.add('bg-primary', 'progress-bar-striped', 'progress-bar-animated');
    message.textContent = 'سفارش‌ها در دسته‌های ۱۰۰تایی پردازش می‌شوند؛ این صفحه را باز نگه دارید.';
    let completed = false;

    try {
        while (root.isConnected) {
            const page = Number(root.dataset.nextPage) || 1;
            const response = await fetch(window.KERPData?.ajaxUrl || ajax_url, {
                method: 'POST',
                credentials: 'same-origin',
                cache: 'no-store',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
                body: new URLSearchParams({
                    action: 'orders_backfill_index',
                    backfill_nonce: root.dataset.nonce || '',
                    batch_page: String(page)
                }).toString()
            });
            const payload = await response.json();
            if (!root.isConnected) return;
            if (!response.ok || payload?.status !== 'success' || !payload.data) {
                throw new Error(payload?.message || payload?.msg || 'همگام‌سازی انجام نشد. دوباره تلاش کنید.');
            }
            const data = payload.data;
            if (Number(data.current_page) !== page || !Number.isFinite(Number(data.total)) || typeof data.done !== 'boolean') {
                throw new Error('پاسخ سرور نامعتبر است. دوباره تلاش کنید.');
            }
            const total = Math.max(0, Number(data.total));
            const processed = Math.min(total, Math.max(0, Number(data.processed) || 0));
            const percent = data.done ? 100 : total > 0 ? Math.min(99, Math.floor(processed * 100 / total)) : 0;
            bar.style.width = percent + '%';
            bar.setAttribute('aria-valuenow', String(percent));
            root.querySelector('[data-orders-backfill-percent]').textContent = kerpOrdersBackfillNumber.format(percent) + '٪';
            root.querySelector('[data-orders-backfill-count]').textContent = kerpOrdersBackfillNumber.format(processed) + ' از ' + kerpOrdersBackfillNumber.format(total) + ' سفارش';
            if (data.done) {
                completed = true;
                delete root.dataset.nextPage;
                bar.classList.replace('bg-primary', 'bg-success');
                message.textContent = total ? 'همگام‌سازی همه سفارش‌ها کامل شد.' : 'سفارشی برای همگام‌سازی وجود ندارد.';
                break;
            }
            root.dataset.nextPage = String(page + 1);
        }
    } catch (error) {
        if (root.isConnected) {
            message.classList.add('text-danger');
            message.textContent = error.message || 'ارتباط با سرور قطع شد. برای ادامه دوباره تلاش کنید.';
        }
    } finally {
        root.dataset.running = '0';
        root.setAttribute('aria-busy', 'false');
        bar.classList.remove('progress-bar-striped', 'progress-bar-animated');
        if (root.isConnected) {
            button.disabled = false;
            label.textContent = completed ? 'همگام‌سازی مجدد' : 'ادامه همگام‌سازی';
        }
    }
}

document.addEventListener('click', function (event) {
    const button = event.target.closest('[data-orders-backfill-start]');
    if (!button) return;
    const root = button.closest('#kerp-orders-index-backfill');
    if (root) kerpOrdersRunBackfill(root, button);
});
