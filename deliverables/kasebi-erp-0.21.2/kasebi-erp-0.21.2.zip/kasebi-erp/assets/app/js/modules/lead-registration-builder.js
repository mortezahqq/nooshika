// Let the shared repeater handle indexes, controls and conditional fields.
// Enforce this form's limit before its delegated add handler runs.
document.addEventListener('click', function (kerpRegEvent) {
    const kerpRegAdd = kerpRegEvent.target.closest('.kerp-registration-builder .add_repeater_row');
    if (!kerpRegAdd) return;
    const kerpRegRows = kerpRegAdd.closest('.repeater_wrapper').querySelectorAll('.repeater_rows > .repeater_row');
    if (kerpRegRows.length < 24) return;
    kerpRegEvent.preventDefault();
    kerpRegEvent.stopPropagation();
    NioApp.Toast('حداکثر ۲۴ فیلد قابل تعریف است.', 'warning', {position: 'top-right'});
}, true);

$(document).on('shown.bs.modal', '#kerpPipelineRegistration', function () {
    $(this).find('.submit_modal_form').attr({role: 'button', tabindex: '0'});
    evaluateAll($(this).find('form'));
});
// The shared leads modal key handler already covers #kerpPipelineRegistration.
