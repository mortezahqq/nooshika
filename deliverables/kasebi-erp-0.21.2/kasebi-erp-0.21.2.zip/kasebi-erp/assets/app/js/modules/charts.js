$(document).on('click', '.request_dashboard_block_data', function(e) {
    e.preventDefault();
    
    let $btn = $(this);
    let $card = $btn.closest('.card');
    
    if ($card.data('loading')) {
        return;
    }
    
    let action = $btn.attr('data-action') || '';
    
    if (!action) {
        console.warn('Dashboard block action is empty');
        return;
    }
    
    let data = kasebi_parse_dashboard_atts($btn.attr('data-atts') || '');
    data.action = action;
    
    $card.data('loading', true).addClass('is-loading');
    let dashboardUpdated = false;
    let dashboardRequest = action === 'customers_dashboard_memberships'
        ? kerpDashboardSeriesRequest(data, $card[0])
        : $.ajax({ url: ajax_url, method: 'POST', data: data, ajax_search: true });
    dashboardRequest.done(function(response) {
        let payload = kasebi_get_dashboard_payload(response);
        
        if (!payload) {
            console.warn('Invalid dashboard response', response);
            return;
        }
        
        kasebi_apply_dashboard_targets(
            $btn.attr('data-targets') || '',
            payload,
        );
        dashboardUpdated = true;
    }).fail(function() {
        if (action === 'customers_dashboard_memberships' && $card[0].isConnected) {
            toast_msg('دریافت آمار انجام نشد؛ بازه را دوباره انتخاب کنید.', 'error');
        }
    }).always(function() {
        $card.data('loading', false).removeClass('is-loading');
        if (action !== 'customers_dashboard_memberships' || dashboardUpdated) {
            $card.find('.request_dashboard_block_data').removeClass('active');
            $btn.addClass('active');
        }
    });
});

function kasebi_parse_dashboard_atts(raw) {
    let data = {};
    
    if (!raw) {
        return data;
    }
    
    raw.split(';').forEach(function(row) {
        row = row.trim();
        
        if (!row) {
            return;
        }
        
        let parts = row.split(':');
        let key = (parts.shift() || '').trim();
        let value = parts.join(':').trim();
        
        if (!key) {
            return;
        }
        
        data[key] = value;
    });
    
    return data;
}

function kasebi_get_dashboard_payload(response) {
    if (!response) {
        return null;
    }
    
    if (response.data) {
        return response.data;
    }
    
    if (response.result) {
        return response.result;
    }
    
    return response;
}

function kasebi_apply_dashboard_targets(rawTargets, payload) {
    if (!rawTargets) {
        return;
    }
    
    rawTargets.split(';').forEach(function(row) {
        row = row.trim();
        
        if (!row) {
            return;
        }
        
        let parts = row.split(':');
        
        if (parts.length < 3) {
            return;
        }
        
        let responseKey = (parts.shift() || '').trim();
        let selector = (parts.shift() || '').trim();
        let action = parts.join(':').trim();
        
        if (!responseKey || !selector || !action) {
            return;
        }
        
        if (typeof payload[responseKey] === 'undefined') {
            return;
        }
        
        let value = payload[responseKey];
        let $target = $(selector);
        
        if (!$target.length) {
            return;
        }
        
        kasebi_apply_dashboard_target_action($target, action, value);
    });
}

function kasebi_apply_dashboard_target_action($target, action, value) {
    if (action === 'text') {
        $target.text(value);
        return;
    }
    
    if (action === 'html') {
        $target.html(value);
        return;
    }
    
    if (action === 'class') {
        kasebi_apply_dashboard_class($target, value);
        return;
    }
    
    if (action === 'chart') {
        kasebi_apply_dashboard_chart($target, value);
    }
}

function kasebi_apply_dashboard_class($target, value) {
    let baseClass = $target.data('baseClass') || '';
    
    if (Array.isArray(value)) {
        value = value.join(' ');
    }
    
    $target.attr('class', (baseClass + ' ' + value).trim());
}

function kasebi_apply_dashboard_chart($target, value) {
    if (!value || typeof value !== 'object') {
        return;
    }
    
    if (value.labels) {
        $target.attr('data-labels', JSON.stringify(value.labels));
    }
    
    if (value.data) {
        $target.attr('data-data', JSON.stringify(value.data));
    }
    
    if (value.points) {
        $target.attr('data-points', JSON.stringify(value.points));
    }
    
    let chart = $target.data('chartInstance');
    
    if (!chart) {
        $target.removeData('chartActivated');
        
        if (typeof activate_charts === 'function') {
            activate_charts();
        }
        
        return;
    }
    
    if (value.labels) {
        chart.data.labels = value.labels;
    }
    
    if (value.points) {
        if (chart.data.datasets[0]) {
            chart.data.datasets[0].data = value.points;
        }
        
        chart.update();
        return;
    }
    
    if (value.data) {
        let datasetsData = kasebi_normalize_dashboard_chart_datasets(value.data);
        
        if (chart.data.datasets.length !== datasetsData.length) {
            chart.destroy();
            $target.removeData('chartInstance');
            $target.removeData('chartActivated');
            
            if (typeof activate_charts === 'function') {
                activate_charts();
            }
            
            return;
        }
        
        chart.data.datasets.forEach(function(dataset, index) {
            dataset.data = datasetsData[index] || [];
        });
        
        chart.update();
    }
}

function kasebi_normalize_dashboard_chart_datasets(data) {
    if (!Array.isArray(data)) {
        return [[data]];
    }
    
    if (!data.length) {
        return [[]];
    }
    
    if (Array.isArray(data[0])) {
        return data;
    }
    
    return [data];
}

function activate_charts() {
    if (typeof Chart === 'undefined') {
        console.warn('Chart.js not found');
        return;
    }
    
    kasebi_init_chart_defaults();
    register_kasebi_chart_center_text_plugin();
    register_kasebi_doughnut_label_plugin();
    register_kasebi_polar_donut_plugin();
    
    $('.kasebi-chart, .kasebi_chart').each(function() {
        let $chart = $(this);
        
        if ($chart.data('chartActivated')) {
            return;
        }
        
        $chart.data('chartActivated', true);
        
        let type = $chart.attr('data-chart-type') || 'bar';
        let data = kasebi_parse_chart_data($chart);
        
        if (!data) {
            console.warn('Invalid chart data', this);
            return;
        }
        
        let canvas = kasebi_get_chart_canvas($chart);
        let ctx = canvas.getContext('2d');
        
        let config = {
            type:    kasebi_normalize_chart_type(type),
            data:    kasebi_build_chart_data($chart, type, data),
            options: kasebi_build_chart_options($chart, type),
        };
        
        // Home workspace styling is opt-in by ancestry; other reports keep their options.
        if ($chart.closest('.kerp-dashboard').length) {
            kerpDashboardStyleChart(config, type);
        }
        let chart = new Chart(ctx, config);
        
        $chart.data('chartInstance', chart);
    });
}

/**
 * =========================
 * Parse chart data
 * =========================
 */
function kasebi_parse_chart_data($chart) {
    let raw = $chart.attr('data-chart-data');
    
    if (raw) {
        return kasebi_safe_json_parse(raw);
    }
    
    let points = kasebi_safe_json_parse($chart.attr('data-points'));
    
    if (points) {
        return {
            points: points,
        };
    }
    
    let labels = kasebi_safe_json_parse($chart.attr('data-labels'));
    let chartData = kasebi_safe_json_parse($chart.attr('data-data'));
    
    if (labels && chartData) {
        return {
            labels: labels,
            data:   chartData,
        };
    }
    
    let percent = $chart.attr('data-percent');
    let value = $chart.attr('data-value');
    
    if (percent !== undefined || value !== undefined) {
        return {
            title:   $chart.attr('data-title') || '',
            value:   value || 0,
            percent: percent || 0,
        };
    }
    
    return null;
}

/**
 * =========================
 * Build chart data
 * =========================
 */
function kasebi_build_chart_data($chart, type, data) {
    let colors = kasebi_get_chart_colors();
    
    if (type === 'scatter') {
        return {
            datasets: [
                {
                    label: $chart.attr('data-label') || '',
                    data:  data.points || [],
                    
                    backgroundColor: $chart.attr('data-color') || $chart.attr('data-point-color') || colors.teal,
                    borderColor:     $chart.attr('data-color') || $chart.attr('data-point-color') || colors.teal,
                    
                    pointRadius:      parseInt($chart.attr('data-point-radius') || 5),
                    pointHoverRadius: parseInt($chart.attr('data-point-hover-radius') || 7),
                    
                    xLabel: $chart.attr('data-x-label') || $chart.attr('data-x-title') || 'محور X',
                    yLabel: $chart.attr('data-y-label') || $chart.attr('data-y-title') || 'محور Y',
                    
                    xUnit: $chart.attr('data-x-unit') || '',
                    yUnit: $chart.attr('data-y-unit') || $chart.attr('data-unit') || '',
                },
            ],
        };
    }
    
    if (type === 'polar-donut') {
        let rawValues = kasebi_normalize_single_dataset(data.data);
        let minRadius = parseFloat($chart.attr('data-min-radius') || 24);
        let renderedValues = kasebi_build_polar_donut_render_data(rawValues, minRadius);
        
        return {
            labels:   data.labels,
            datasets: [
                {
                    label:           $chart.attr('data-label') || '',
                    data:            renderedValues,
                    rawData:         rawValues,
                    backgroundColor: kasebi_get_chart_dataset_colors($chart, rawValues),
                    borderWidth:     parseInt($chart.attr('data-border-width') || 0),
                    unit:            $chart.attr('data-unit') || '',
                },
            ],
        };
    }
    
    if (type === 'line' || type === 'area') {
        return {
            labels:   data.labels,
            datasets: kasebi_build_multi_datasets($chart, type, data),
        };
    }
    
    if (type === 'bar' || type === 'horizontalBar') {
        return {
            labels:   data.labels,
            datasets: kasebi_build_multi_datasets($chart, type, data),
        };
    }
    
    if (type === 'radar') {
        return {
            labels:   data.labels,
            datasets: kasebi_build_multi_datasets($chart, type, data),
        };
    }
    
    if (type === 'radial') {
        let percent = parseFloat(data.percent || 0);
        let remain = Math.max(100 - percent, 0);
        
        return {
            labels:   [
                data.title || $chart.attr('data-label') || 'مقدار',
                'باقی‌مانده',
            ],
            datasets: [
                {
                    data:            [percent, remain],
                    backgroundColor: [
                        $chart.attr('data-color') || $chart.attr('data-ring-color') || colors.primary,
                        $chart.attr('data-ring-bg') || '#eef0f7',
                    ],
                    borderWidth:     0,
                    unit:            $chart.attr('data-unit') || '',
                },
            ],
        };
    }
    
    /**
     * doughnut / pie / donut
     */
    return {
        labels:   data.labels,
        datasets: [
            {
                label:           $chart.attr('data-label') || '',
                data:            kasebi_normalize_single_dataset(data.data),
                backgroundColor: kasebi_get_chart_dataset_colors($chart, data.data),
                borderWidth:     parseInt($chart.attr('data-border-width') || 0),
                unit:            $chart.attr('data-unit') || '',
            },
        ],
    };
}

/**
 * =========================
 * Multi Dataset Builder
 * data-label / data-data / data-color / data-unit
 * =========================
 */
function kasebi_build_multi_datasets($chart, type, data) {
    let labels = kasebi_to_array(kasebi_safe_json_parse($chart.attr('data-label')) || $chart.attr('data-label') || '');
    let rawData = data.data;
    let datasetsData = kasebi_normalize_datasets_data(rawData);
    
    let colors = kasebi_to_array(kasebi_safe_json_parse($chart.attr('data-color')) || $chart.attr('data-color') || '');
    let units = kasebi_to_array(kasebi_safe_json_parse($chart.attr('data-unit')) || $chart.attr('data-unit') || '');
    let tensions = kasebi_to_array(
        kasebi_safe_json_parse($chart.attr('data-tension')) || $chart.attr('data-tension') || '');
    let fills = kasebi_to_array(kasebi_safe_json_parse($chart.attr('data-fill')) || $chart.attr('data-fill') || '');
    
    let defaultColors = kasebi_get_default_color_list();
    
    return datasetsData.map(function(datasetData, index) {
        let color = kasebi_get_index_value(colors, index, defaultColors[index % defaultColors.length]);
        let label = kasebi_get_index_value(labels, index, '');
        let unit = kasebi_get_index_value(units, index, kasebi_get_index_value(units, 0, ''));
        
        if (type === 'line' || type === 'area') {
            let tension = parseFloat(kasebi_get_index_value(tensions, index, 0.38));
            let fill = kasebi_get_bool_value(kasebi_get_index_value(fills, index, type === 'area'));
            
            return {
                label: label,
                data:  datasetData,
                
                borderColor:     color,
                backgroundColor: kasebi_hex_to_rgba(color, fill ? 0.12 : 0),
                
                borderWidth:      parseInt($chart.attr('data-border-width') || 3),
                pointRadius:      parseInt($chart.attr('data-point-radius') || 3),
                pointHoverRadius: parseInt($chart.attr('data-point-hover-radius') || 5),
                
                fill:        fill,
                lineTension: tension,
                unit:        unit,
            };
        }
        
        if (type === 'radar') {
            return {
                label: label,
                data:  datasetData,
                
                backgroundColor:      kasebi_hex_to_rgba(color, 0.18),
                borderColor:          color,
                pointBackgroundColor: color,
                pointBorderColor:     '#fff',
                
                pointRadius: parseInt($chart.attr('data-point-radius') || 4),
                borderWidth: parseInt($chart.attr('data-border-width') || 2),
                unit:        unit,
            };
        }
        
        return {
            label:           label,
            data:            datasetData,
            backgroundColor: color,
            borderColor:     color,
            borderWidth:     parseInt($chart.attr('data-border-width') || 0),
            unit:            unit,
        };
    });
}

/**
 * =========================
 * Build chart options
 * =========================
 */
function kasebi_build_chart_options($chart, type) {
    let showLegend = $chart.attr('data-legend') !== '0';
    let showGrid = $chart.attr('data-grid') !== '0';
    let title = $chart.attr('data-chart-title') || '';
    let isResponsive = $chart.attr('data-responsive') !== '0';
    let fontFamily = kasebi_get_chart_font_family();
    
    let tooltipColors = $chart.attr('data-tooltip-colors');
    
    if (tooltipColors === '0') {
        tooltipColors = false;
    } else if (tooltipColors === '1') {
        tooltipColors = true;
    } else {
        tooltipColors = type !== 'scatter';
    }
    tooltipColors = false;
    
    let tooltipMode = $chart.attr('data-tooltip-mode') || '';
    
    if (!tooltipMode) {
        tooltipMode = (type === 'line' || type === 'area') ? 'index' : 'nearest';
    }
    
    let tooltipIntersect = $chart.attr('data-tooltip-intersect');
    
    if (tooltipIntersect === '1') {
        tooltipIntersect = true;
    } else if (tooltipIntersect === '0') {
        tooltipIntersect = false;
    } else {
        tooltipIntersect = !(type === 'line' || type === 'area');
    }
    
    let options = {
        responsive:          isResponsive,
        maintainAspectRatio: false,
        
        legend: {
            display:  showLegend,
            position: $chart.attr('data-legend-position') || 'bottom',
            rtl:      true,
            labels:   {
                usePointStyle: true,
                boxWidth:      8,
                fontFamily:    fontFamily,
                padding:       18,
            },
        },
        
        title: {
            display:    title !== '',
            text:       title,
            fontFamily: fontFamily,
            fontSize:   15,
            fontColor:  '#1f2937',
            padding:    18,
        },
        
        tooltips: {
            rtl:             true,
            mode:            tooltipMode,
            intersect:       tooltipIntersect,
            displayColors:   tooltipColors,
            titleFontFamily: fontFamily,
            bodyFontFamily:  fontFamily,
            backgroundColor: '#111827',
            cornerRadius:    8,
            xPadding:        12,
            yPadding:        10,
            callbacks:       {
                title: function(tooltipItems, chartData) {
                    return kasebi_chart_tooltip_title(tooltipItems, chartData, type);
                },
                label: function(tooltipItem, chartData) {
                    return kasebi_chart_tooltip_label(tooltipItem, chartData, type);
                },
            },
        },
        
        hover: {
            mode:      tooltipMode,
            intersect: tooltipIntersect,
        },
        
        animation: {
            duration: parseInt($chart.attr('data-animation-duration') || 700),
        },
    };
    
    if (type === 'polar-donut') {
        options.scale = {
            ticks:       {
                display:     false,
                beginAtZero: true,
            },
            gridLines:   {
                display: false,
            },
            angleLines:  {
                display: false,
            },
            pointLabels: {
                display: false,
            },
        };
        
        options.startAngle = -0.5 * Math.PI;
        
        options.polarDonut = {
            cutoutPercentage: parseInt($chart.attr('data-cutout') || 36),
            centerFill:       $chart.attr('data-center-fill') || '#fff',
        };
        
        return options;
    }
    
    if (type === 'doughnut' || type === 'donut' || type === 'pie' || type === 'radial') {
        options.cutoutPercentage = parseInt($chart.attr('data-cutout') || 68);
        
        if ($chart.attr('data-show-labels') === '1') {
            options.kasebiDoughnutLabels = {
                type:  $chart.attr('data-label-type') || 'percent',
                color: $chart.attr('data-label-color') || '#111827',
            };
        }
        
        if (type === 'radial') {
            options.legend.display = false;
            options.tooltips.enabled = $chart.attr('data-tooltip') === '1';
            options.centerText = {
                title:    $chart.attr('data-center-title') || '',
                value:    $chart.attr('data-center-value') || '',
                subtitle: $chart.attr('data-center-subtitle') || '',
            };
        }
        
        return options;
    }
    
    if (type === 'radar') {
        options.scale = {
            ticks:       {
                display:     false,
                beginAtZero: true,
            },
            gridLines:   {
                display: $chart.attr('data-radar-grid') === '1',
                color:   'rgba(0,0,0,0)',
            },
            angleLines:  {
                display: $chart.attr('data-radar-lines') === '1',
                color:   'rgba(0,0,0,0)',
            },
            pointLabels: {
                fontFamily: fontFamily,
                fontColor:  '#6b7280',
                fontSize:   12,
            },
        };
        
        return options;
    }
    
    if (type === 'scatter') {
        options.scales = {
            xAxes: [
                {
                    type:       'linear',
                    position:   'bottom',
                    gridLines:  {
                        display:    showGrid,
                        color:      '#edf0f5',
                        drawBorder: false,
                    },
                    scaleLabel: {
                        display:     !!$chart.attr('data-x-title'),
                        labelString: $chart.attr('data-x-title') || '',
                        fontFamily:  fontFamily,
                    },
                    ticks:      {
                        fontFamily:  fontFamily,
                        fontColor:   '#6b7280',
                        beginAtZero: $chart.attr('data-begin-zero') !== '0',
                    },
                },
            ],
            yAxes: [
                {
                    gridLines:  {
                        display:    showGrid,
                        color:      '#edf0f5',
                        drawBorder: false,
                    },
                    scaleLabel: {
                        display:     !!$chart.attr('data-y-title'),
                        labelString: $chart.attr('data-y-title') || '',
                        fontFamily:  fontFamily,
                    },
                    ticks:      {
                        fontFamily:  fontFamily,
                        fontColor:   '#6b7280',
                        beginAtZero: $chart.attr('data-begin-zero') !== '0',
                    },
                },
            ],
        };
        
        return options;
    }
    
    if (type === 'line' || type === 'area' || type === 'bar' || type === 'horizontalBar') {
        options.scales = {
            xAxes: [
                {
                    gridLines: {
                        display:    type === 'horizontalBar' ? showGrid : false,
                        color:      '#edf0f5',
                        drawBorder: false,
                    },
                    ticks:     {
                        fontFamily: fontFamily,
                        fontColor:  '#6b7280',
                    },
                },
            ],
            yAxes: [
                {
                    gridLines: {
                        display:    showGrid,
                        color:      '#edf0f5',
                        drawBorder: false,
                    },
                    ticks:     {
                        fontFamily:  fontFamily,
                        fontColor:   '#6b7280',
                        beginAtZero: true,
                    },
                },
            ],
        };
        
        return options;
    }
    
    return options;
}

/**
 * =========================
 * Tooltip
 * =========================
 */
function kasebi_chart_tooltip_title(tooltipItems, chartData, type) {
    if (!tooltipItems || !tooltipItems.length) {
        return '';
    }
    
    if (
        type === 'donut' ||
        type === 'doughnut' ||
        type === 'pie' ||
        type === 'polar-donut' ||
        type === 'radial' ||
        type === 'scatter'
    ) {
        return '';
    }
    
    let item = tooltipItems[0];
    let index = typeof item.index !== 'undefined' ? item.index : item._index;
    
    if (chartData.labels && typeof chartData.labels[index] !== 'undefined') {
        return chartData.labels[index];
    }
    
    return '';
}

function kasebi_chart_tooltip_label(tooltipItem, chartData, type) {
    let datasetIndex = typeof tooltipItem.datasetIndex !== 'undefined'
                       ? tooltipItem.datasetIndex
                       : tooltipItem._datasetIndex;
    
    let index = typeof tooltipItem.index !== 'undefined'
                ? tooltipItem.index
                : tooltipItem._index;
    
    let dataset = chartData.datasets[datasetIndex || 0];
    
    if (!dataset) {
        return '';
    }
    
    let dataItem = null;
    
    if (dataset.data && typeof dataset.data[index] !== 'undefined') {
        dataItem = dataset.data[index];
    }
    
    /**
     * Scatter:
     * labelX:valueX unitX
     * labelY:valueY unitY
     */
    if (type === 'scatter' && typeof dataItem === 'object' && dataItem !== null) {
        let xLabel = dataItem.x_label || dataItem.label || dataItem.labelX || dataItem.xLabel || dataItem.x;
        let yLabel = dataItem.y_label || dataItem.labelY || dataItem.yLabel || dataItem.y;
        
        let xValue = dataItem.x_value || dataItem.valueX || xLabel;
        let yValue = dataItem.y_value || dataItem.valueY || dataItem.y;
        
        let lines = [];
        
        lines.push(
            (dataset.xLabel || 'محور X') + ': ' + kasebi_format_chart_value(xValue, dataset.xUnit || ''),
        );
        
        lines.push(
            (dataset.yLabel || 'محور Y') + ': ' + kasebi_format_chart_value(yValue, dataset.yUnit || ''),
        );
        
        return lines;
    }
    
    /**
     * Donut / Doughnut / Pie / Radial
     */
    if (
        type === 'donut' ||
        type === 'doughnut' ||
        type === 'pie' ||
        type === 'radial' ||
        type === 'polar-donut'
    ) {
        let label = '';
        
        if (chartData.labels && typeof chartData.labels[index] !== 'undefined') {
            label = chartData.labels[index];
        }
        
        let tooltipValue = dataItem;
        
        if (
            type === 'polar-donut' &&
            dataset.rawData &&
            typeof dataset.rawData[index] !== 'undefined'
        ) {
            tooltipValue = dataset.rawData[index];
        }
        
        return label + ': ' + kasebi_format_chart_value(tooltipValue, dataset.unit || '');
    }
    
    /**
     * Normal charts:
     * title
     * label:value unit
     */
    let value = dataItem;
    
    if (typeof tooltipItem.yLabel !== 'undefined') {
        value = tooltipItem.yLabel;
    } else if (typeof tooltipItem.xLabel !== 'undefined') {
        value = tooltipItem.xLabel;
    }
    
    let datasetLabel = dataset.label || '';
    
    if (datasetLabel) {
        return datasetLabel + ': ' + kasebi_format_chart_value(value, dataset.unit || '');
    }
    
    return kasebi_format_chart_value(value, dataset.unit || '');
}

/**
 * =========================
 * Helpers
 * =========================
 */
function kasebi_safe_json_parse(value) {
    if (!value) {
        return null;
    }
    
    if (typeof value !== 'string') {
        return value;
    }
    
    try {
        return JSON.parse(value);
    } catch (e) {
        try {
            return JSON.parse(value.replace(/&quot;/g, '"'));
        } catch (e2) {
            return null;
        }
    }
}

function kasebi_get_chart_canvas($chart) {
    let canvas = $chart.find('canvas').get(0);
    
    if (canvas) {
        return canvas;
    }
    
    let height = parseInt($chart.attr('data-chart-height') || 260);
    
    canvas = document.createElement('canvas');
    canvas.height = height;
    
    $chart.empty().append(canvas);
    
    return canvas;
}

function kasebi_normalize_chart_type(type) {
    if (type === 'donut') {
        return 'doughnut';
    }
    
    if (type === 'area') {
        return 'line';
    }
    
    if (type === 'radial') {
        return 'doughnut';
    }
    
    if (type === 'polar-donut') {
        return 'polarArea';
    }
    
    return type;
}

function kasebi_get_chart_font_family() {
    return $('body').css('font-family') || 'Tahoma, sans-serif';
}

function kasebi_init_chart_defaults() {
    if (typeof Chart === 'undefined') {
        return;
    }
    
    let fontFamily = kasebi_get_chart_font_family();
    
    Chart.defaults.global.defaultFontFamily = fontFamily;
    Chart.defaults.global.defaultFontColor = '#6b7280';
}

function kasebi_normalize_datasets_data(data) {
    if (!Array.isArray(data)) {
        return [[data]];
    }
    
    if (!data.length) {
        return [[]];
    }
    
    if (Array.isArray(data[0])) {
        return data;
    }
    
    return [data];
}

function kasebi_normalize_single_dataset(data) {
    if (!Array.isArray(data)) {
        return [data];
    }
    
    if (Array.isArray(data[0])) {
        return data[0];
    }
    
    return data;
}

function kasebi_to_array(value) {
    if (Array.isArray(value)) {
        return value;
    }
    
    if (value === null || typeof value === 'undefined' || value === '') {
        return [];
    }
    
    return [value];
}

function kasebi_get_index_value(values, index, fallback) {
    if (Array.isArray(values) && typeof values[index] !== 'undefined') {
        return values[index];
    }
    
    if (Array.isArray(values) && typeof values[0] !== 'undefined') {
        return values[0];
    }
    
    return fallback;
}

function kasebi_get_bool_value(value) {
    if (value === true || value === 'true' || value === '1' || value === 1) {
        return true;
    }
    
    if (value === false || value === 'false' || value === '0' || value === 0) {
        return false;
    }
    
    return !!value;
}

function kasebi_format_chart_value(value, unit) {
    if (typeof value === 'undefined' || value === null) {
        value = '';
    }
    
    if (!unit) {
        return value;
    }
    
    if (unit === '٪' || unit === '%') {
        return value + unit;
    }
    
    return value + ' ' + unit;
}

function kasebi_get_chart_colors() {
    return {
        primary: '#635bff',
        blue:    '#3b82f6',
        teal:    '#14b8a6',
        orange:  '#f97316',
        pink:    '#ec4899',
        red:     '#f43f5e',
        yellow:  '#f59e0b',
        gray:    '#9ca3af',
    };
}

function kasebi_get_default_color_list() {
    return [
        '#635bff',
        '#3b82f6',
        '#14b8a6',
        '#f97316',
        '#ec4899',
        '#f43f5e',
        '#f59e0b',
        '#9ca3af',
    ];
}

function kasebi_get_chart_dataset_colors($chart, data) {
    let colors = kasebi_safe_json_parse($chart.attr('data-color'));
    
    if (!colors) {
        colors = kasebi_safe_json_parse($chart.attr('data-colors'));
    }
    
    if (colors && Array.isArray(colors)) {
        return colors;
    }
    
    let singleColor = $chart.attr('data-color');
    
    if (singleColor) {
        return singleColor;
    }
    
    let count = Array.isArray(data) ? data.length : 1;
    let base = kasebi_get_default_color_list();
    let output = [];
    
    for (let i = 0; i < count; i++) {
        output.push(base[i % base.length]);
    }
    
    return output;
}

function kasebi_hex_to_rgba(hex, alpha) {
    if (!hex || hex.indexOf('#') !== 0) {
        return hex || 'rgba(99,91,255,' + alpha + ')';
    }
    
    hex = hex.replace('#', '');
    
    if (hex.length === 3) {
        hex = hex.split('').map(function(char) {
            return char + char;
        }).join('');
    }
    
    let r = parseInt(hex.substring(0, 2), 16);
    let g = parseInt(hex.substring(2, 4), 16);
    let b = parseInt(hex.substring(4, 6), 16);
    
    return 'rgba(' + r + ',' + g + ',' + b + ',' + alpha + ')';
}

/**
 * =========================
 * Center text plugin
 * =========================
 */
function register_kasebi_chart_center_text_plugin() {
    if (window.kasebiChartCenterTextPluginRegistered) {
        return;
    }
    
    window.kasebiChartCenterTextPluginRegistered = true;
    
    Chart.plugins.register({
        beforeDraw: function(chart) {
            if (!chart.config.options.centerText) {
                return;
            }
            
            let ctx = chart.chart.ctx;
            let width = chart.chart.width;
            let height = chart.chart.height;
            let centerText = chart.config.options.centerText;
            let fontFamily = kasebi_get_chart_font_family();
            
            ctx.save();
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.direction = 'rtl';
            
            if (centerText.title) {
                ctx.font = '12px ' + fontFamily;
                ctx.fillStyle = '#6b7280';
                ctx.fillText(centerText.title, width / 2, height / 2 - 24);
            }
            
            if (centerText.value) {
                ctx.font = 'bold 22px ' + fontFamily;
                ctx.fillStyle = '#111827';
                ctx.fillText(centerText.value, width / 2, height / 2);
            }
            
            if (centerText.subtitle) {
                ctx.font = '12px ' + fontFamily;
                ctx.fillStyle = '#6b7280';
                ctx.fillText(centerText.subtitle, width / 2, height / 2 + 24);
            }
            
            ctx.restore();
        },
    });
}

/**
 * =========================
 * Doughnut labels plugin
 * =========================
 */
function register_kasebi_doughnut_label_plugin() {
    if (window.kasebiDoughnutLabelPluginRegistered) {
        return;
    }
    
    window.kasebiDoughnutLabelPluginRegistered = true;
    
    Chart.plugins.register({
        afterDatasetsDraw: function(chart) {
            let options = chart.config.options || {};
            
            if (!options.kasebiDoughnutLabels) {
                return;
            }
            
            if (chart.config.type !== 'doughnut' && chart.config.type !== 'pie') {
                return;
            }
            
            let ctx = chart.chart.ctx;
            let dataset = chart.data.datasets[0];
            
            if (!dataset || !dataset.data) {
                return;
            }
            
            let total = dataset.data.reduce(function(sum, value) {
                return sum + Number(value || 0);
            }, 0);
            
            let fontFamily = kasebi_get_chart_font_family();
            
            ctx.save();
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.direction = 'rtl';
            ctx.font = '12px ' + fontFamily;
            ctx.fillStyle = options.kasebiDoughnutLabels.color || '#111827';
            
            chart.getDatasetMeta(0).data.forEach(function(element, index) {
                let value = Number(dataset.data[index] || 0);
                
                if (!value || total <= 0) {
                    return;
                }
                
                let percent = Math.round((value / total) * 100);
                
                if (percent < 6) {
                    return;
                }
                
                let position = element.tooltipPosition();
                let label = chart.data.labels[index] || '';
                
                let text = options.kasebiDoughnutLabels.type === 'label'
                           ? label
                           : percent + '٪';
                
                ctx.fillText(text, position.x, position.y);
            });
            
            ctx.restore();
        },
    });
}

function kasebi_build_polar_donut_render_data(values, minRadiusPercent) {
    if (!Array.isArray(values)) {
        values = [values];
    }
    
    minRadiusPercent = parseFloat(minRadiusPercent || 25);
    
    if (minRadiusPercent < 0) {
        minRadiusPercent = 0;
    }
    
    if (minRadiusPercent > 95) {
        minRadiusPercent = 95;
    }
    
    let maxValue = Math.max.apply(null, values.map(function(value) {
        return Number(value || 0);
    }));
    
    if (!maxValue || maxValue <= 0) {
        return values.map(function() {
            return minRadiusPercent;
        });
    }
    
    return values.map(function(value) {
        value = Number(value || 0);
        
        return minRadiusPercent + ((value / maxValue) * (100 - minRadiusPercent));
    });
}

function register_kasebi_polar_donut_plugin() {
    if (window.kasebiPolarDonutPluginRegistered) {
        return;
    }
    
    window.kasebiPolarDonutPluginRegistered = true;
    
    Chart.plugins.register({
        afterDatasetsDraw: function(chart) {
            let options = chart.config.options || {};
            
            if (!options.polarDonut) {
                return;
            }
            
            if (chart.config.type !== 'polarArea') {
                return;
            }
            
            let meta = chart.getDatasetMeta(0);
            
            if (!meta || !meta.data || !meta.data.length) {
                return;
            }
            
            let firstArc = meta.data[0];
            
            if (!firstArc || !firstArc._model) {
                return;
            }
            
            let model = firstArc._model;
            let ctx = chart.chart.ctx;
            
            let centerX = model.x;
            let centerY = model.y;
            let outerRadius = model.outerRadius || 0;
            
            let cutoutPercentage = options.polarDonut.cutoutPercentage || 36;
            let innerRadius = outerRadius * (cutoutPercentage / 100);
            
            ctx.save();
            ctx.beginPath();
            ctx.fillStyle = options.polarDonut.centerFill || '#fff';
            ctx.arc(centerX, centerY, innerRadius, 0, Math.PI * 2);
            ctx.closePath();
            ctx.fill();
            ctx.restore();
        },
    });
}
