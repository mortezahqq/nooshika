function appointments_clear_time_options() {
    let $time = $('#kerp-appointment-time');
    
    $time.empty().append(
        $('<option>', {
            value: '',
            text:  'ابتدا خدمت، کارشناس و تاریخ را انتخاب کنید',
        }),
    );
}

function appointments_update_time_options() {
    let $service = $('#kerp-appointment-service');
    let $employee = $('#kerp-appointment-employee');
    let $date = $('#kerp-appointment-date');
    let $time = $('#kerp-appointment-time');
    
    let serviceId = parseInt($service.val() || '0', 10);
    let employeeId = parseInt($employee.val() || '0', 10);
    let date = $.trim($date.val() || '');
    let appointmentId = parseInt($('#kerp-appointment-id').val() || '0', 10);
    let selectedTime = $.trim($date.attr('data-time') || '');
    
    if (!serviceId || !employeeId || !date) {
        appointments_clear_time_options();
        return;
    }
    
    $time.prop('disabled', true).empty().append(
        $('<option>', {
            value: '',
            text:  'در حال دریافت ساعت‌های آزاد...',
        }),
    );
    
    $.post(
        ajax_url,
        {
            action:         'appointments_get_time_options',
            service_id:     serviceId,
            employee_id:    employeeId,
            date:           date,
            appointment_id: appointmentId,
        },
    ).done(function(response) {
        $time.empty();
        
        if (!response || response.status !== 'success') {
            $time.append(
                $('<option>', {
                    value: '',
                    text:  response.message || 'خطا در دریافت ساعت‌ها',
                }),
            );
            
            return;
        }
        
        let options = response.options || {};
        
        if (!Object.keys(options).length) {
            $time.append(
                $('<option>', {
                    value: '',
                    text:  'ساعت آزادی برای این روز وجود ندارد',
                }),
            );
            
            return;
        }
        
        $time.append(
            $('<option>', {
                value: '',
                text:  'انتخاب ساعت',
            }),
        );
        
        $.each(options, function(value, label) {
            $time.append(
                $('<option>', {
                    value: value,
                    text:  label,
                }),
            );
        });
        
        if (
            selectedTime &&
            $time.find('option[value="' + selectedTime + '"]').length
        ) {
            $time.val(selectedTime).trigger('change');
        }
        
        if (selectedTime) {
            $date.removeAttr('data-selected-time');
        }
    }).fail(function() {
        $time.empty().append(
            $('<option>', {
                value: '',
                text:  'خطا در ارتباط با سرور',
            }),
        );
    }).always(function() {
        $time.prop('disabled', false);
    });
}

$(document).on(
    'change',
    '#kerp-appointment-service, #kerp-appointment-employee, #kerp-appointment-date',
    function() {
        appointments_update_time_options();
    },
);