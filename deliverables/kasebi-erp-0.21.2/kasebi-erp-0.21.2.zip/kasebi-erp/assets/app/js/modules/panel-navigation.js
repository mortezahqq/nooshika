// Shared scope is supplied by the ERP builder.
function kerpPanelNavigationPreview(kerpPanelRow) {
    const kerpPanelIcon = String(kerpPanelRow.find('.kerp-panel-navigation-icon').val() || '').trim() || kerpPanelRow.attr('data-default-icon');
    const kerpPanelPreview = kerpPanelRow.find('.kerp-panel-navigation-preview');
    const kerpPanelTitle = String(kerpPanelRow.find('.kerp-panel-navigation-title').val() || '').trim() || kerpPanelRow.attr('data-default-title');
    kerpPanelRow.find('.kerp-panel-navigation-preview-title').text(kerpPanelTitle);
    if (!kerpPanelIcon || /^[a-zA-Z0-9_-]+(?:\s+[a-zA-Z0-9_-]+)*$/.test(kerpPanelIcon)) {
        kerpPanelPreview.attr('class', 'icon kerp-panel-navigation-preview ' + kerpPanelIcon);
    }
}
$(document).on('input', '.kerp-panel-navigation-form input', function() {
    kerpPanelNavigationPreview($(this).closest('.kerp-panel-navigation-row'));
});
$(document).on('click', '.kerp-panel-navigation-reset', function() {
    const kerpPanelRow = $(this).closest('.kerp-panel-navigation-row');
    kerpPanelRow.find('.kerp-panel-navigation-title').val(kerpPanelRow.attr('data-default-title'));
    kerpPanelRow.find('.kerp-panel-navigation-icon').val(kerpPanelRow.attr('data-default-icon'));
    kerpPanelNavigationPreview(kerpPanelRow);
    kerpPanelRow.closest('form').find('.kerp-panel-navigation-feedback').text('مقادیر پیش‌فرض آماده‌اند؛ برای ثبت، ذخیره تغییرات را بزنید.');
});

$(document).on('submit', '.kerp-panel-navigation-form', function(kerpPanelEvent) {
    kerpPanelEvent.preventDefault();
    const kerpPanelForm = $(this);
    if (kerpPanelForm.data('saving')) { return; }
    const kerpPanelPayload = {};
    kerpPanelForm.find('.kerp-panel-navigation-row').each(function() {
        const kerpPanelRow = $(this);
        kerpPanelPayload[kerpPanelRow.attr('data-page')] = {
            title: String(kerpPanelRow.find('.kerp-panel-navigation-title').val() || '').trim(),
            icon: String(kerpPanelRow.find('.kerp-panel-navigation-icon').val() || '').trim(),
        };
    });
    const kerpPanelButton = kerpPanelForm.find('.kerp-panel-navigation-save');
    const kerpPanelFeedback = kerpPanelForm.find('.kerp-panel-navigation-feedback');
    kerpPanelForm.data('saving', true).attr('aria-busy', 'true');
    kerpPanelButton.prop('disabled', true);
    kerpPanelFeedback.text('در حال ذخیره…');
    $.post(ajax_url, {
        action: 'panel_navigation_save',
        nonce: kerpPanelForm.attr('data-nonce'),
        settings_payload: JSON.stringify(kerpPanelPayload),
    }).done(function(kerpPanelResponse) {
        const kerpPanelSuccess = kerpPanelResponse && kerpPanelResponse.status === 'success';
        const kerpPanelMessage = (kerpPanelResponse && kerpPanelResponse.message) || 'پاسخ سرور معتبر نیست؛ دوباره تلاش کنید.';
        kerpPanelFeedback.text(kerpPanelMessage);
        NioApp.Toast(kerpPanelMessage, kerpPanelSuccess ? 'success' : 'error', {position: 'top-right'});
    }).fail(function() {
        const kerpPanelMessage = 'ارتباط با سرور برقرار نشد؛ دوباره تلاش کنید.';
        kerpPanelFeedback.text(kerpPanelMessage);
        NioApp.Toast(kerpPanelMessage, 'error', {position: 'top-right'});
    }).always(function() {
        kerpPanelForm.data('saving', false).removeAttr('aria-busy');
        kerpPanelButton.prop('disabled', false);
    });
});
