function product_search_get_scope(element) {
    return $(element).closest('.product_search');
}

function product_search_get_config(scope) {
    return {
        searchAction: scope.attr('data-search-action') || '',
        loadAction:   scope.attr('data-load-action') || '',
        searchParam:  scope.attr('data-search-param') || 'search',
        itemParam:    scope.attr('data-item-param') || 'product_id',
        minChars:     parseInt(scope.attr('data-min-chars') || '2', 10),
        listTarget:   scope.attr('data-list-target') || '.product_search_list',
        resultTarget: scope.attr('data-result-target') || '.product_search_result',
    };
}

function product_search_abort(scope) {
    let request = scope.data('product-search-request');
    
    if (!request) {
        return;
    }
    
    request.abort();
    scope.removeData('product-search-request');
}

function product_search_clear(scope, clearResult) {
    let config = product_search_get_config(scope);
    
    scope.find(config.listTarget).html('');
    
    if (clearResult) {
        scope.find(config.resultTarget).html('');
    }
}

function product_search_request(input) {
    let element = $(input);
    let scope = product_search_get_scope(element);
    let config = product_search_get_config(scope);
    let search = $.trim(element.val());
    
    if (!scope.length || !config.searchAction) {
        return;
    }
    
    if (search.length < config.minChars) {
        product_search_abort(scope);
        product_search_clear(scope, search.length === 0);
        return;
    }
    
    product_search_abort(scope);
    
    let data = {
        action: config.searchAction,
    };
    
    data[config.searchParam] = search;
    
    ajax_search = true;
    
    let request = $.post(
        ajax_url,
        data,
    );
    
    scope.data(
        'product-search-request',
        request,
    );
    
    request.done(function(response) {
        if (response.status === 'success') {
            scope.find(config.listTarget).html('');
            scope.find(config.resultTarget).html(response.html || '');
            
            NioApp.NumberSpinner();
            
            return;
        }
        
        if (response.status === 'list') {
            scope.find(config.listTarget).html(response.html || '');
            
            return;
        }
        
        NioApp.Toast(
            response.message || 'خطا در جستجوی محصول',
            response.status || 'error',
            {
                position: 'top-right',
            },
        );
        
        element.val('');
        product_search_clear(scope, true);
    });
    
    request.fail(function(xhr, status) {
        if (status === 'abort') {
            return;
        }
        
        NioApp.Toast(
            'خطا در ارتباط با سرور',
            'error',
            {
                position: 'top-right',
            },
        );
    });
    
    request.always(function() {
        if (
            scope.data('product-search-request') === request
        ) {
            scope.removeData('product-search-request');
        }
        
        ajax_search = false;
    });
}

function product_search_load_item(element) {
    let item = $(element);
    let scope = product_search_get_scope(item);
    let config = product_search_get_config(scope);
    let itemId = item.attr('data-id');
    
    if (
        !scope.length
        || !config.loadAction
        || !itemId
    ) {
        return;
    }
    
    product_search_abort(scope);
    
    let data = {
        action: config.loadAction,
    };
    
    data[config.itemParam] = itemId;
    
    ajax_search = true;
    
    let request = $.post(
        ajax_url,
        data,
    );
    
    scope.data(
        'product-search-request',
        request,
    );
    
    request.done(function(response) {
        if (response.status !== 'success') {
            NioApp.Toast(
                response.message || 'خطا در دریافت اطلاعات محصول',
                response.status || 'error',
                {
                    position: 'top-right',
                },
            );
            
            return;
        }
        
        scope.find(config.listTarget).html('');
        scope.find(config.resultTarget).html(response.html || '');
        scope.find('.product_search_input').val('');
        
        NioApp.NumberSpinner();
    });
    
    request.fail(function(xhr, status) {
        if (status === 'abort') {
            return;
        }
        
        NioApp.Toast(
            'خطا در ارتباط با سرور',
            'error',
            {
                position: 'top-right',
            },
        );
    });
    
    request.always(function() {
        if (
            scope.data('product-search-request') === request
        ) {
            scope.removeData('product-search-request');
        }
        
        ajax_search = false;
    });
}

function product_search_schedule(input) {
    let element = $(input);
    let timer = element.data('product-search-timer');
    
    if (timer) {
        clearTimeout(timer);
    }
    
    timer = setTimeout(function() {
        product_search_request(element);
    }, 300);
    
    element.data(
        'product-search-timer',
        timer,
    );
}

$(document).on('input', '.product_search_input', function() {
    product_search_schedule(this);
});

$(document).on('click', '.product_search_item', function(e) {
    e.preventDefault();
    product_search_load_item(this);
});

function order_factor_get_form(element) {
    return $(element).closest('.modal_form');
}

function order_factor_get_items_wrapper(form) {
    return form.find('.kerp-order-items-wrapper').first();
}

function order_factor_get_next_index(wrapper) {
    let index = parseInt(wrapper.attr('data-next-index') || '0', 10);
    
    if (Number.isNaN(index) || index < 0) {
        index = 0;
    }
    
    wrapper.attr('data-next-index', index + 1);
    
    return index;
}

function order_factor_get_product_row(form, productId) {
    let row = $();
    
    form.find('.kerp-order-item-row').each(function() {
        if (String($(this).attr('data-product')) === String(productId)) {
            row = $(this);
            return false;
        }
    });
    
    return row;
}

function order_factor_update_empty_state(form) {
    let hasItems = form.find('.kerp-order-items-body .kerp-order-item-row').length > 0;
    
    form.find('.kerp-order-items-empty').toggleClass(
        'd-none',
        hasItems,
    );
}

function order_factor_add_product(button) {
    let source = $(button).closest('.product_factor_source');
    let form = order_factor_get_form(button);
    let wrapper = order_factor_get_items_wrapper(form);
    let tbody = wrapper.find('.kerp-order-items-body').first();
    let template = source.find('.product_factor_row_template').html();
    
    let productId = parseInt(source.attr('data-product-id') || '0', 10);
    let maxQty = sanitizeNumber(source.attr('data-max-qty'), true);
    let qty = sanitizeNumber(
        source.find('.product_factor_qty').val(),
        true,
    );
    
    if (!productId || !qty || qty <= 0) {
        return;
    }
    
    if (maxQty > 0 && qty > maxQty) {
        qty = maxQty;
    }
    
    let existingRow = order_factor_get_product_row(
        form,
        productId,
    );
    
    if (existingRow.length) {
        let qtyInput = existingRow.find('.line_qty').first();
        let currentQty = sanitizeNumber(
            qtyInput.val(),
            true,
        );
        
        let newQty = currentQty + qty;
        
        if (maxQty > 0 && newQty > maxQty) {
            newQty = maxQty;
        }
        
        qtyInput.val(newQty);
        
        calc_factor_total(form);
        
        form.trigger(
            'kerp_order_item_quantity_updated',
            [
                existingRow,
                productId,
                newQty,
            ],
        );
        
        return;
    }
    
    if (!template) {
        NioApp.Toast(
            'قالب ردیف محصول پیدا نشد.',
            'error',
            {
                position: 'top-right',
            },
        );
        
        return;
    }
    
    let index = order_factor_get_next_index(wrapper);
    
    template = template.replaceAll('__INDEX__', index).replaceAll('__QTY__', qty);
    
    tbody.append(template);
    
    let newRow = tbody.find('.kerp-order-item-row').last();
    
    order_factor_update_empty_state(form);
    calc_factor_total(form);
    
    source.find('.product_factor_qty').val('1');
    
    form.trigger(
        'kerp_order_item_added',
        [
            newRow,
            productId,
        ],
    );
}

$(document).on('click', '.add_product_to_factor', function(e) {
    e.preventDefault();
    
    order_factor_add_product(this);
});

function order_factor_get_summary_row_value(row) {
    let input = row.find('[data-for]').first();
    
    if (input.length) {
        return sanitizeNumber(
            input.val(),
            true
        );
    }
    
    let dataValue = row.attr('data-summary-value');
    
    if (dataValue !== undefined && dataValue !== '') {
        return sanitizeNumber(
            dataValue,
            true
        );
    }
    
    let valueElement = row.find(
        '.kerp-order-summary-value, .kerp-order-fee-value'
    ).first();
    
    if (valueElement.length) {
        return sanitizeNumber(
            valueElement.text(),
            true
        );
    }
    
    return 0;
}

function order_factor_get_summary_row_key(row) {
    let key = row.attr('data-summary-key')
        || row.attr('data-fee-key')
        || '';
    
    if (key) {
        return key;
    }
    
    let input = row.find('[data-for]').first();
    
    if (!input.length) {
        return '';
    }
    
    return input.attr('data-for') || '';
}

function order_factor_get_summary_row_effect(row) {
    let effect = row.attr('data-summary-effect')
        || row.attr('data-fee-effect')
        || 'increase';
    
    return effect === 'decrease'
           ? 'decrease'
           : 'increase';
}

function order_factor_update_summary_row_display(row, value) {
    let display = row.find(
        '.kerp-order-summary-value, .kerp-order-fee-value'
    ).first();
    
    if (display.length) {
        kerp_price_update(display, Math.abs(value));
    }
    
    if (row.attr('data-hide-zero') === '1') {
        row.toggleClass(
            'd-none',
            value === 0
        );
    }
}

function order_factor_calculate_summary_rows(form, baseTotal) {
    let total = baseTotal;
    let increase = 0;
    let decrease = 0;
    let rows = {};
    
    form.find(
        '.kerp-order-summary-row[data-summary-effect], ' +
        '.kerp-order-summary-row[data-fee-effect]'
    ).each(function() {
        let row = $(this);
        let key = order_factor_get_summary_row_key(row);
        let effect = order_factor_get_summary_row_effect(row);
        let value = Math.max(
            0,
            order_factor_get_summary_row_value(row)
        );
        
        order_factor_update_summary_row_display(
            row,
            value
        );
        
        if (key) {
            rows[key] = {
                value:  value,
                effect: effect,
            };
        }
        
        if (!value) {
            return;
        }
        
        if (effect === 'decrease') {
            total -= value;
            decrease += value;
            return;
        }
        
        total += value;
        increase += value;
    });
    
    return {
        total:    total,
        increase: increase,
        decrease: decrease,
        rows:     rows,
    };
}

function order_factor_resolve_form(scope) {
    if (scope && scope.jquery) {
        if (scope.is('.modal_form')) {
            return scope;
        }
        
        let form = scope.closest('.modal_form');
        
        if (form.length) {
            return form;
        }
    }
    
    if (scope) {
        let form = $(scope).closest('.modal_form');
        
        if (form.length) {
            return form;
        }
    }
    
    return $('.modal_form .order_factor_card')
    .first()
    .closest('.modal_form');
}

function calc_factor_total(scope) {
    let form = order_factor_resolve_form(scope);
    
    if (!form.length) {
        return;
    }
    
    let card = form.find('.order_factor_card').first();
    let regularTotal = 0;
    let itemsTotal = 0;
    
    card.find('.kerp-order-item-row').each(function() {
        let row = $(this);
        
        let qty = sanitizeNumber(
            row.find('.line_qty').val(),
            true
        );
        
        let regularPrice = sanitizeNumber(
            row.find('.item_reg_total').val(),
            true
        );
        
        let offPercent = sanitizeNumber(
            row.find('.item_off_percent').val(),
            true
        );
        
        qty = Math.max(0, qty);
        regularPrice = Math.max(0, regularPrice);
        offPercent = Math.max(
            0,
            Math.min(100, offPercent)
        );
        
        let finalUnitPrice = regularPrice * (
            (100 - offPercent) / 100
        );
        
        let regularLineTotal = regularPrice * qty;
        let lineTotal = finalUnitPrice * qty;
        
        row.find('.item_subtotal').val(
            number_format(finalUnitPrice)
        );
        
        row.find('.item_regular_line_total').val(
            regularLineTotal
        );
        
        row.find('.line_total').val(
            number_format(lineTotal)
        );
        
        regularTotal += regularLineTotal;
        itemsTotal += lineTotal;
    });
    
    let itemsDiscount = Math.max(
        0,
        regularTotal - itemsTotal
    );
    
    kerp_price_update(form.find('.order_subtotal'), regularTotal);
    
    kerp_price_update(form.find('.order_discount'), itemsDiscount);
    
    kerp_price_update(form.find('.order_total'), itemsTotal);
    
    let summary = order_factor_calculate_summary_rows(
        form,
        itemsTotal
    );
    
    let finalTotal = Math.max(
        0,
        summary.total
    );
    
    kerp_price_update(form.find('.order_total_final'), finalTotal);
    
    let shippingTotal = 0;
    
    if (
        summary.rows.shipping_total
        && summary.rows.shipping_total.value
    ) {
        shippingTotal = summary.rows.shipping_total.value;
    }
    
    form.trigger(
        'kerp_order_totals_calculated',
        [
            {
                items_regular_total: regularTotal,
                items_discount:      itemsDiscount,
                items_total:         itemsTotal,
                shipping_total:      shippingTotal,
                summary_increase:    summary.increase,
                summary_decrease:    summary.decrease,
                summary_rows:        summary.rows,
                final_total:         finalTotal,
            },
        ]
    );
}

$(document).on(
    'input change',
    '.modal_form .order_factor_card .line_qty, ' +
    '.modal_form .order_factor_card .item_reg_total, ' +
    '.modal_form .order_factor_card .item_off_percent, ' +
    '.modal_form .kerp-order-summary-row[data-summary-effect] [data-for], ' +
    '.modal_form .kerp-order-summary-row[data-fee-effect] [data-for]',
    function() {
        calc_factor_total(
            $(this).closest('.modal_form')
        );
    }
);

$(document).on('click', '.delete_factor_row', function(e) {
    e.preventDefault();
    
    let form = order_factor_get_form(this);
    let row = $(this).closest('.kerp-order-item-row');
    
    if (!form.length || !row.length) {
        return;
    }
    
    row.remove();
    
    order_factor_update_empty_state(form);
    calc_factor_total(form);
    
    form.trigger(
        'kerp_order_item_removed'
    );
});
