(function () {
    'use strict';

    const formatNumber = new Intl.NumberFormat('fa-IR');

    function updateProgress(root, data) {
        const total = Math.max(0, Number(data.total) || 0);
        const migrated = Math.min(total, Math.max(0, Number(data.migrated) || 0));
        const remaining = Math.max(0, Number(data.remaining) || 0);
        const percent = remaining === 0 ? 100 : total > 0 ? Math.min(100, Math.floor(100 * migrated / total)) : 0;
        root.querySelector('[data-migration-total]').textContent = formatNumber.format(total);
        root.querySelector('[data-migration-migrated]').textContent = formatNumber.format(migrated);
        root.querySelector('[data-migration-remaining]').textContent = formatNumber.format(remaining);
        root.querySelector('[data-migration-percent]').textContent = formatNumber.format(percent) + '٪';
        root.querySelector('[data-migration-bar]').style.width = percent + '%';
        root.querySelector('[role="progressbar"]').setAttribute('aria-valuenow', String(percent));
        return remaining;
    }

    async function runMigration(root, button) {
        if (root.dataset.running === '1') return;
        root.dataset.running = '1';
        button.disabled = true;
        const label = button.querySelector('span');
        const message = root.querySelector('[data-migration-message]');
        label.textContent = 'در حال انتقال…';
        message.classList.remove('text-danger');
        message.textContent = 'در حال انتقال پاسخ‌ها، لطفاً این صفحه را باز نگه دارید.';
        let completed = false;

        try {
            while (document.documentElement.contains(root)) {
                const body = new URLSearchParams({
                    action: 'kerp_practice_migrate_legacy',
                    migration_nonce: root.dataset.nonce || ''
                });
                const response = await fetch(window.KERPData?.ajaxUrl || '', {
                    method: 'POST',
                    credentials: 'same-origin',
                    cache: 'no-store',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
                    body: body.toString()
                });
                const payload = await response.json();
                if (!response.ok || payload?.status !== 'success' || !payload.data) {
                    throw new Error(payload?.message || payload?.msg || 'انتقال پاسخ‌ها انجام نشد.');
                }
                if (!document.documentElement.contains(root)) return;
                const remaining = updateProgress(root, payload.data);
                if (remaining === 0) {
                    completed = true;
                    message.textContent = 'انتقال کامل شد. جدول و فایل‌های قدیمی حفظ شده‌اند.';
                    break;
                }
                if (Number(payload.data.copied) < 1) {
                    throw new Error('پاسخی منتقل نشد. وضعیت جدول قدیمی را بررسی کنید و سپس دوباره تلاش کنید.');
                }
                message.textContent = formatNumber.format(remaining) + ' پاسخ باقی مانده است…';
            }
        } catch (error) {
            if (document.documentElement.contains(root)) {
                message.classList.add('text-danger');
                message.textContent = error.message || 'ارتباط با سرور قطع شد. برای ادامه دوباره تلاش کنید.';
            }
        } finally {
            root.dataset.running = '0';
            if (document.documentElement.contains(root)) {
                button.disabled = completed;
                label.textContent = completed ? 'انتقال کامل شد' : 'ادامه انتقال';
            }
        }
    }

    document.addEventListener('click', function (event) {
        const button = event.target.closest('[data-migration-start]');
        if (!button) return;
        const root = button.closest('#kerp-practice-migration');
        if (root) runMigration(root, button);
    });
})();
