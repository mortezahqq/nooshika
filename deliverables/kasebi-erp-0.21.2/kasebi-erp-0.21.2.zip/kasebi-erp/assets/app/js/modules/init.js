NioApp.ClassBody = function() {
    NioApp.AddInBody(_sidebar);
};
NioApp.ClassNavMenu = function() {
    NioApp.BreakClass('.' + _header_menu, _break.lg, {
        timeOut: 0,
    });
    NioApp.BreakClass('.' + _sidebar, _break.lg, {
        timeOut:  0,
        classAdd: _sidebar_mob,
    });
    $win.on('resize', function() {
        NioApp.BreakClass('.' + _header_menu, _break.lg);
        NioApp.BreakClass('.' + _sidebar, _break.lg, {
            classAdd: _sidebar_mob,
        });
    });
};
NioApp.Prettify = function() {
    window.prettyPrint && prettyPrint();
};
NioApp.Copied = function() {
    // This initializer also runs after AJAX navigation; keep one delegated listener.
    if (NioApp.kerpClipboard) NioApp.kerpClipboard.destroy();
    var clip   = '.clipboard-init',
        target = '.clipboard-text',
        sclass = 'clipboard-success',
        eclass = 'clipboard-error';
    
    // Feedback
    function feedback(el, state) {
        var $elm = $(el),
            $elp = $elm.parent(),
            copy = {
                text: 'کپی',
                done: 'کپی شد',
                fail: 'ناموفق',
            },
            data = {
                text: $elm.data('clip-text'),
                done: $elm.data('clip-success'),
                fail: $elm.data('clip-error'),
            };
        copy.text = data.text ? data.text : copy.text;
        copy.done = data.done ? data.done : copy.done;
        copy.fail = data.fail ? data.fail : copy.fail;
        var copytext = state === 'success' ? copy.done : copy.fail,
            addclass = state === 'success' ? sclass : eclass;
        clearTimeout($elm.data('kerp-copy-timer'));
        $elp.removeClass(sclass + ' ' + eclass).addClass(addclass);
        $elm.find(target).text(copytext);
        $elm.data('kerp-copy-timer', setTimeout(function() {
            $elp.removeClass(sclass + ' ' + eclass);
            $elm.find(target).text(copy.text);
        }, 2000));
    }
    
    if (ClipboardJS.isSupported()) {
        var clipboard = new ClipboardJS(clip, {
            action: function(trigger) {
                // Bootstrap keeps focus inside the modal. Its temporary copy field must be there too.
                clipboard.container = trigger.closest('.modal') || document.body;
                return trigger.getAttribute('data-clipboard-action') || 'copy';
            },
        });
        NioApp.kerpClipboard = clipboard;
        clipboard.on('success', function(e) {
            feedback(e.trigger, 'success');
            e.clearSelection();
        }).on('error', function(e) {
            feedback(e.trigger, 'error');
        });
    } else {
        $(clip).css('display', 'none');
    }
};
NioApp.StickyNav = function() {
    var elem = document.querySelectorAll('.' + _header);
    if (elem.length > 0) {
        elem.forEach(function(item) {
            var _item_offset = 30;
            if (window.scrollY > _item_offset) {
                item.classList.add('has-fixed');
            } else {
                item.classList.remove('has-fixed');
            }
        });
    }
};
NioApp.StickyNav.init = function() {
    NioApp.StickyNav();
    window.addEventListener('scroll', function() {
        NioApp.StickyNav();
    });
};
NioApp.CurrentLink = function() {
    var _link       = '.nk-menu-link, .menu-link, .nav-link',
        _currentURL = window.location.href,
        fileName    = _currentURL.substring(0,
            _currentURL.indexOf('#') == -1 ? _currentURL.length : _currentURL.indexOf('#'));
    fileName = fileName.substring(0, fileName.indexOf('?') == -1 ? fileName.length : fileName.indexOf('?'));
    $(_link).each(function() {
        var self       = $(this),
            _self_link = self.attr('href');
        if (fileName.match(_self_link)) {
            self.closest('li').addClass('active current-page').parents().closest('li').addClass('active current-page');
            self.closest('li').children('.nk-menu-sub').css('display', 'block');
            self.parents().closest('li').children('.nk-menu-sub').css('display', 'block');
            this.scrollIntoView({
                block: 'start',
            });
            $('.nk-menu-switch').parent().removeClass('active');
            $('.' + _menu_content).removeClass(_menu_active);
            var _closest_content = self.closest('.' + _menu_content).data('content');
            self.closest('.' + _menu_content).addClass(_menu_active);
            $('[data-target=' + _closest_content + ']').parent().addClass('active');
        } else {
            self.closest('li').
                removeClass('active current-page').
                parents().
                closest('li:not(.current-page)').
                removeClass('active');
        }
    });
};
// PasswordSwitch @v1.0
NioApp.PassSwitch = function() {
    NioApp.Passcode('.passcode-switch');
};

// Toastr Message @v1.0
NioApp.Toast = function(msg, ttype, opt) {
    var ttype = ttype ? ttype : 'info',
        msi   = '',
        ticon = ttype === 'info' ? 'ni ni-info-fill' : ttype ===
                                                       'success'
                                                       ? 'ni ni-check-circle-fill'
                                                       : ttype === 'error'
                                                         ? 'ni ni-cross-circle-fill'
                                                         : ttype === 'warning' ? 'ni ni-alert-fill' : '',
        def   = {
            position: 'bottom-right',
            ui:       '',
            icon:     'auto',
            clear:    false,
        },
        attr  = opt ? extend(def, opt) : def;
    attr.position = attr.position
                    ? 'toast-' + attr.position
                    : 'toast-bottom-right';
    attr.icon = attr.icon === 'auto' ? ticon : attr.icon
                                               ? attr.icon
                                               : '';
    attr.ui = attr.ui ? ' ' + attr.ui : '';
    msi = attr.icon !== ''
          ? '<span class="toastr-icon"><em class="icon ' + attr.icon +
              '"></em></span>'
          : '', msg = msg !== '' ? msi + '<div class="toastr-text">' + msg +
        '</div>' : '';
    if (msg !== '') {
        if (attr.clear === true) {
            toastr.clear();
        }
        var option = {
            'closeButton':       true,
            'debug':             false,
            'newestOnTop':       false,
            'progressBar':       false,
            'positionClass':     attr.position + attr.ui,
            'closeHtml':         '<span class="btn-trigger">Close</span>',
            'preventDuplicates': true,
            'showDuration':      '1500',
            'hideDuration':      '1500',
            'timeOut':           '2000',
            'toastClass':        'toastr',
            'extendedTimeOut':   '3000',
        };
        toastr.options = extend(option, attr);
        toastr[ttype](msg);
    }
};

// Toggle Screen @v1.0
NioApp.TGL.screen = function(elm) {
    if ($(elm).exists()) {
        $(elm).each(function() {
            var ssize = $(this).data('toggle-screen');
            if (ssize) {
                $(this).addClass('toggle-screen-' + ssize);
            }
        });
    }
};

// Toggle Content @v1.0
NioApp.TGL.content = function(elm, opt) {
    var toggle        = elm ? elm : '.toggle',
        $toggle       = $(toggle),
        $contentD     = $('[data-content]'),
        toggleBreak   = true,
        toggleCurrent = false,
        def           = {
            active:  'active',
            content: 'content-active',
            'break': toggleBreak,
        },
        attr          = opt ? extend(def, opt) : def;
    NioApp.TGL.screen($contentD);
    $toggle.on('click', function(e) {
        toggleCurrent = this;
        NioApp.Toggle.trigger($(this).data('target'), attr);
        e.preventDefault();
    });
    $doc.on('mouseup', function(e) {
        if (toggleCurrent) {
            var $toggleCurrent  = $(toggleCurrent),
                currentTarget   = $(toggleCurrent).data('target'),
                $contentCurrent = $(
                    '[data-content="'.concat(currentTarget, '"]')),
                $dpd            = $('.datepicker-dropdown'),
                $tpc            = $('.ui-timepicker-container');
            if (!$toggleCurrent.is(e.target) &&
                $toggleCurrent.has(e.target).length === 0 &&
                !$contentCurrent.is(e.target) &&
                $contentCurrent.has(e.target).length === 0 &&
                $(e.target).closest('.select2-container').length === 0 &&
                !$dpd.is(e.target) &&
                $dpd.has(e.target).length === 0 && !$tpc.is(e.target) &&
                $tpc.has(e.target).length === 0) {
                NioApp.Toggle.removed($toggleCurrent.data('target'), attr);
                toggleCurrent = false;
            }
        }
    });
    $win.on('resize', function() {
        $contentD.each(function() {
            var content     = $(this).data('content'),
                ssize       = $(this).data('toggle-screen'),
                toggleBreak = _break[ssize];
            if (NioApp.Win.width > toggleBreak) {
                NioApp.Toggle.removed(content, attr);
            }
        });
    });
};

// ToggleExpand @v1.0
NioApp.TGL.expand = function(elm, opt) {
    var toggle = elm ? elm : '.expand',
        def    = {
            toggle: true,
        },
        attr   = opt ? extend(def, opt) : def;
    $(toggle).on('click', function(e) {
        NioApp.Toggle.trigger($(this).data('target'), attr);
        e.preventDefault();
    });
};

// Dropdown Menu @v1.0
NioApp.TGL.ddmenu = function(elm, opt) {
    var imenu = elm ? elm : '.nk-menu-toggle',
        def   = {
            active: 'active',
            self:   'nk-menu-toggle',
            child:  'nk-menu-sub',
        },
        attr  = opt ? extend(def, opt) : def;
    $(imenu).on('click', function(e) {
        if (NioApp.Win.width < _break.lg ||
            $(this).parents().hasClass(_sidebar)) {
            NioApp.Toggle.dropMenu($(this), attr);
        }
        e.preventDefault();
    });
};

// Show Menu @v1.0
NioApp.TGL.showmenu = function(elm, opt) {
    var toggle      = elm ? elm : '.nk-nav-toggle',
        $toggle     = $(toggle),
        $contentD   = $('[data-content]'),
        toggleBreak = $contentD.hasClass(_header_menu)
                      ? _break.lg
                      : _break.xl,
        toggleOlay  = _sidebar + '-overlay',
        toggleClose = {
            profile: true,
            menu:    false,
        },
        def         = {
            active:  'toggle-active',
            content: _sidebar + '-active',
            body:    'nav-shown',
            overlay: toggleOlay,
            'break': toggleBreak,
            close:   toggleClose,
        },
        attr        = opt ? extend(def, opt) : def;
    $toggle.on('click', function(e) {
        NioApp.Toggle.trigger($(this).data('target'), attr);
        e.preventDefault();
    });
    $doc.on('mouseup', function(e) {
        
        if ($(e.target).closest('[data-content]').length) {
            return;
        }
        if ($(e.target).closest(toggle).length) {
            return;
        }
        
        if (NioApp.Win.width < toggleBreak) {
            NioApp.Toggle.removed($toggle.data('target'), attr);
        }
    });
    $win.on('resize', function() {
        if (NioApp.Win.width < _break.xl || NioApp.Win.width <
            toggleBreak) {
            NioApp.Toggle.removed($toggle.data('target'), attr);
        }
    });
};
NioApp.menuSwitch = function() {
    var $toggle  = $('.' + _menu_switch),
        $content = $('.' + _menu_content);
    $toggle.on('click', function(e) {
        var $self     = $(this),
            _target   = $self.data('target'),
            $dContent = $('[data-content=' + _target + ']');
        $toggle.parent().removeClass('active');
        $self.parent().addClass('active');
        $content.removeClass(_menu_active);
        $dContent.addClass(_menu_active);
        e.preventDefault();
    });
};
// Animate FormSearch @v1.0
NioApp.Ani.formSearch = function(elm, opt) {
    const attr = Object.assign({active: 'active', target: '[data-search]'}, opt || {});
    const close = function($panel) {
        if (!$panel.hasClass(attr.active)) return;
        const name = $panel.attr('data-search');
        const $toggles = $(elm).filter(function() { return $(this).attr('data-target') === name; });
        $panel.add($toggles).removeClass(attr.active);
        $toggles.attr('aria-expanded', 'false');
        $panel.trigger('kerp:search-closed');
    };
    // AJAX initialization must replace handlers instead of toggling twice on the next click.
    $(elm).off('click.kerpFormSearch').on('click.kerpFormSearch', function(e) {
        e.preventDefault();
        const name = $(this).attr('data-target');
        const $panel = $(attr.target).filter(function() { return $(this).attr('data-search') === name; });
        const $toggles = $(elm).filter(function() { return $(this).attr('data-target') === name; });
        if ($panel.hasClass(attr.active)) {
            close($panel);
            $toggles.filter('.search-toggle').trigger('focus');
        } else {
            $panel.add($toggles).addClass(attr.active);
            $toggles.attr('aria-expanded', 'true');
            $panel.find('input').first().trigger('focus');
        }
    });
    $doc.off('.kerpFormSearch').on('keyup.kerpFormSearch mouseup.kerpFormSearch', function(e) {
        if (e.type === 'keyup' && e.key !== 'Escape') return;
        $(attr.target + '.' + attr.active).each(function() {
            const $panel = $(this);
            const name = $panel.attr('data-search');
            const $toggles = $(elm).filter(function() { return $(this).attr('data-target') === name; });
            if (e.type === 'mouseup' && ($panel.is(e.target) || $panel.has(e.target).length || $toggles.is(e.target) || $toggles.has(e.target).length)) return;
            close($panel);
            if (e.key === 'Escape') $toggles.filter('.search-toggle').trigger('focus');
        });
    });
};

// Animate FormElement @v1.0
NioApp.Ani.formElm = function(elm, opt) {
    var def  = {
            focus: 'focused',
        },
        attr = opt ? extend(def, opt) : def;
    if ($(elm).exists()) {
        $(elm).each(function() {
            var $self = $(this);
            if ($self.val()) {
                $self.parent().addClass(attr.focus);
            }
            $self.on({
                focus: function focus() {
                    $self.parent().addClass(attr.focus);
                },
                blur:  function blur() {
                    if (!$self.val()) {
                        $self.parent().removeClass(attr.focus);
                    }
                },
            });
        });
    }
};

// Form Validate @v1.0
NioApp.Validate = function(elm, opt) {
    if ($(elm).exists()) {
        $(elm).each(function() {
            var def  = {
                    errorElement: 'span',
                },
                attr = opt ? extend(def, opt) : def;
            $(this).validate(attr);
        });
        NioApp.Validate.OnChange('.js-select2');
        NioApp.Validate.OnChange('.date-picker');
        NioApp.Validate.OnChange('.js-tagify');
    }
};

//On change validation for third party plugins
NioApp.Validate.OnChange = function(elm) {
    $(elm).on('change', function() {
        $(this).valid();
    });
};
NioApp.Validate.init = function() {
    NioApp.Validate('.form-validate', {
        errorElement:   'span',
        errorClass:     'invalid',
        errorPlacement: function errorPlacement(error, element) {
            if (element.parents().hasClass('input-group')) {
                error.appendTo(element.parent().parent());
            } else {
                error.appendTo(element.parent());
            }
        },
    });
};

// Dropzone @v1.1
NioApp.Dropzone = function(elm, opt) {
    if ($(elm).exists()) {
        $(elm).each(function() {
            var maxFiles = $(elm).data('max-files'),
                maxFiles = maxFiles ? maxFiles : null;
            var maxFileSize = $(elm).data('max-file-size'),
                maxFileSize = maxFileSize ? maxFileSize : 256;
            var acceptedFiles = $(elm).data('accepted-files'),
                acceptedFiles = acceptedFiles ? acceptedFiles : null;
            var def  = {
                    autoDiscover:  false,
                    maxFiles:      maxFiles,
                    maxFilesize:   maxFileSize,
                    acceptedFiles: acceptedFiles,
                },
                attr = opt ? extend(def, opt) : def;
            $(this).addClass('dropzone').dropzone(attr);
        });
    }
};
/*
 NioApp.Dropzone.init = function () {
 $('.upload-zone').each(function () {
 const el = this
 const $el = $(el)
 const maxFiles = parseInt($el.attr('data-max-files')) || 1
 const target = $el.attr('data-target')
 const urlsStr = ($el.attr('data-urls') || '').trim()
 const idsStr = ($el.attr('data-ids') || '').trim()
 let isInitializing = true
 
 let dz = NioApp.Dropzone(el, {
 url:            ajax_url,
 addRemoveLinks: true,
 maxFiles:       maxFiles,
 accept:         function (file, done) {
 const nameData = $el.attr('data-name')
 if (nameData) {
 let modal = Swal.mixin({
 title:             'عنوان فایل',
 html:              '<div class="form-group">' +
 '<label class="form-label" for="attachment_title">عنوان فایل</label>' +
 '<div class="form-control-wrap">' +
 '<input class="form-control" id="attachment_title">' +
 '</div>' +
 '</div>',
 focusConfirm:      false,
 showCancelButton:  true,
 confirmButtonText: 'آپلود کن',
 cancelButtonText:  `لغو`,
 preConfirm:        () => {
 return $('#attachment_title').val()
 },
 })
 modal.fire().then(function (result) {
 console.log(result.value)
 if (result.isConfirmed && result.value) {
 file.custom_filename = result.value // ذخیره روی فایل
 done()
 } else {
 done('عنوان فایل وارد نشده است')
 }
 })
 } else {
 done()
 }
 },
 sending:        function (file, xhr, formData) {
 formData.append('action', $el.attr('data-action'))
 if (file.custom_filename) {
 formData.append('file_name', file.custom_filename)
 }
 },
 success:        function (file, response) {
 file._uploaded_url = response.attachment
 let $target = $(target)
 let currentVal = $target.val().trim()
 let urls = currentVal ? currentVal.split(',') : []
 urls.push(response.attachment)
 if (urls.length > maxFiles) {
 urls = urls.slice(urls.length - maxFiles)
 }
 
 $target.val(urls.join(','))
 if (!isInitializing) {
 $target.trigger('change')
 }
 },
 removedfile:    function (file) {
 let uploadedUrl = file._uploaded_url
 let $target = $(target)
 let currentVal = $target.val().trim()
 let urls = currentVal ? currentVal.split(',') : []
 
 urls = urls.filter(function (url) {
 return url !== uploadedUrl
 })
 
 $target.val(urls.join(','))
 if (!isInitializing) {
 $target.trigger('change')
 }
 
 // حذف ظاهری فایل از UI
 if (file.previewElement) {
 file.previewElement.remove()
 }
 
 },
 })
 console.log(dz)
 const urls = urlsStr.split(',').map(u => u.trim()).filter(Boolean)
 isInitializing = false // بعد از مقداردهی اولیه
 if (urls.length) {
 urls.forEach((url, index) => {
 const mockFile = {
 name: url.split('/').pop(),
 size: 123456,
 }
 dz.emit('addedfile', mockFile)
 dz.emit('thumbnail', mockFile, url)
 dz.emit('complete', mockFile)
 mockFile.previewElement.classList.add('dz-success', 'dz-complete')
 })
 }
 })
 }
 */
NioApp.Dropzone.init = function() {
    if (window.Dropzone && Dropzone.autoDiscover) {
        Dropzone.autoDiscover = false;
    }
    
    $('.upload-zone').each(function() {
        const el = this;
        const $el = $(el);
        if (el.dropzone || $el.data('kerp-dropzone-initialized')) {
            return;
        }
        const maxFiles = parseInt($el.attr('data-max-files')) || 1;
        const acceptedFiles = $el.attr('data-accepted-files') || null;
        const target = $el.attr('data-target');
        const $target = $(target);
        const urlsStr = ($el.attr('data-urls') || '').trim();
        let isInitializing = true;
        const cropImgEl = document.getElementById('canvas_image');
        let cropModal = $('#cropModal');
        
        $el.addClass('dropzone');
        
        const dz = new Dropzone(el, {
            url:            ajax_url,
            addRemoveLinks: true,
            maxFiles:       maxFiles,
            acceptedFiles:  acceptedFiles,
            transformFile(file, done) {
                const canCrop = $el.attr('data-crop');
                if (!canCrop) {
                    done(file);
                    return;
                }
                if (!file.type || !file.type.startsWith('image/')) {
                    done(file);
                    return;
                }
                let cropper,
                    croppedFile;
                let base = $el.parents('.modal');
                const reader = new FileReader();
                reader.onload = function(e) {
                    cropModal.modal('show');
                    base.modal('hide');
                    cropImgEl.style.maxWidth = '100%';
                    cropImgEl.style.width = '100%';
                    cropImgEl.style.display = 'block';
                    cropImgEl.src = e.target.result;
                    
                    croppedFile = null;
                    if (cropper) {
                        cropper.destroy();
                        cropper = null;
                    }
                    
                    cropper = new Cropper(cropImgEl, {
                        aspectRatio: 1,
                        viewMode:    2,
                    });
                    
                    $('#doCrop').off('click').on('click', function() {
                        const canvas = cropper.getCroppedCanvas({
                            width:                 500,
                            height:                500,
                            imageSmoothingEnabled: true,
                            imageSmoothingQuality: 'high',
                        });
                        
                        canvas.toBlob(function(blob) {
                            croppedFile = new File([blob], file.name, {type: blob.type || file.type});
                            const thumbUrl = URL.createObjectURL(blob);
                            if (file.previewElement) {
                                const img = file.previewElement.querySelector('[data-dz-thumbnail]');
                                if (img) {
                                    img.src = thumbUrl;
                                }
                            }
                            cropModal.modal('hide');
                            base.modal('show');
                            done(croppedFile);
                        }, file.type || 'image/jpeg', 0.92);
                    });
                    
                    cropModal.off('hidden.bs.modal').on('hidden.bs.modal', function() {
                        if (cropper) {
                            cropper.destroy();
                            cropper = null;
                        }
                        if (!croppedFile) {
                            dz.removeFile(file);
                        }
                        base.modal('show');
                    });
                };
                reader.readAsDataURL(file);
            },
            
            accept(file, done) {
                const nameData = $el.attr('data-name');
                if (!nameData) {
                    return done();
                }
                
                const modal = Swal.mixin({
                    title:             'عنوان فایل',
                    html:
                                       '<div class="form-group">' +
                                           '  <label class="form-label" for="attachment_title">عنوان فایل</label>' +
                                           '  <div class="form-control-wrap">' +
                                           '    <input class="form-control" id="attachment_title">' +
                                           '  </div>' +
                                           '</div>',
                    focusConfirm:      false,
                    showCancelButton:  true,
                    confirmButtonText: 'آپلود کن',
                    cancelButtonText:  'لغو',
                    preConfirm:        () => $('#attachment_title').val(),
                });
                
                modal.fire().then(res => {
                    if (res.isConfirmed && res.value) {
                        file.custom_filename = res.value;
                        done();
                    } else {
                        done('عنوان فایل وارد نشده است');
                    }
                });
            },
            
            sending(file, xhr, formData) {
                formData.append('action', $el.attr('data-action'));
                if (['tickets_save', 'kerp_tickets_save'].includes($el.attr('data-action'))) {
                    const form = $el.closest('form');
                    formData.append('operation', 'upload');
                    ['ticket_id', 'tickets_nonce'].forEach(function (key) { formData.append(key, form.find('[name="' + key + '"], [data-for="' + key + '"]').first().val() || ''); });
                }
                if (['payments_upload', 'cheques_upload', 'cheques_upload_sample'].includes($el.attr('data-action'))) { formData.append('payment_nonce', $el.closest('.modal_form').find('[data-for="payment_nonce"]').val() || ''); }
                if ($el.attr('data-action') === 'marketing_upload') { ['marketing_nonce', 'id', 'version'].forEach(function(key) { formData.append(key, $el.closest('.modal_form').find('[data-for="' + key + '"]').val() || ''); }); }
                if (file.custom_filename) {
                    formData.append('file_name', file.custom_filename);
                }
            },
            
            success(file, response) {
                // اگر سرور متن برگرداند، تلاش برای پارس
                let resp = response;
                if (typeof resp === 'string') {
                    try { resp = JSON.parse(resp); } catch (e) {}
                }

                if (['tickets_save', 'kerp_tickets_save'].includes($el.attr('data-action'))) {
                    if (resp && resp.code === 'ticket_nonce_expired' && resp.tickets_nonce && !file._ticketNonceRetried) {
                        file._ticketNonceRetried = true;
                        $el.closest('form').find('[name="tickets_nonce"], [data-for="tickets_nonce"]').val(resp.tickets_nonce).attr('value', resp.tickets_nonce);
                        file.status = Dropzone.ADDED;
                        this.enqueueFile(file);
                        return;
                    }
                    if (!resp || resp.status !== 'success' || !resp.token) {
                        file.status = Dropzone.ERROR;
                        this.emit('error', file, resp && resp.message || 'آپلود ناموفق بود.');
                        return;
                    }
                    file._ticket_token = resp.token;
                }
                const uploadedUrl = (resp && (resp.attachment || resp.url || resp.file_url)) || '';
                
                file._uploaded_url = uploadedUrl;
                
                let urls = ($target.val().trim() ? $target.val().split(',') : []);
                if (uploadedUrl) {
                    urls.push(uploadedUrl);
                }
                
                if (urls.length > maxFiles) {
                    urls = urls.slice(urls.length - maxFiles);
                }
                
                $target.val(urls.join(','));
                if (!isInitializing) {
                    $target.trigger('change');
                }
            },
            
            removedfile(file) {
                const uploadedUrl = file._uploaded_url;
                let urls = ($target.val().trim() ? $target.val().split(',') : []);
                if (uploadedUrl) {
                    urls = urls.filter(u => u !== uploadedUrl);
                }
                
                $target.val(urls.join(','));
                if (!isInitializing) {
                    $target.trigger('change');
                }
                
                if (file.previewElement) {
                    file.previewElement.remove();
                }
            },
        });
        
        $el.data('kerp-dropzone-initialized', true);

        // --- لود اولیه از data-urls + پر کردن target ---
        const urls = urlsStr.split(',').map(u => u.trim()).filter(Boolean);
        if (urls.length) {
            const initial = maxFiles ? urls.slice(-maxFiles) : urls;
            // پر کردن ورودی هدف
            $target.val(initial.join(','));
            // ساخت پیش‌نمایش‌ها
            initial.forEach(url => {
                const mockFile = {
                    name:          url.split('/').pop(),
                    size:          123456,
                    _uploaded_url: url, // برای حذف درست
                };
                dz.emit('addedfile', mockFile);
                dz.emit('thumbnail', mockFile, url);
                dz.emit('complete', mockFile);
                if (mockFile.previewElement) {
                    mockFile.previewElement.classList.add('dz-success', 'dz-complete');
                }
            });
        }
        
        isInitializing = false;
    });
};

// Wizard @v1.0
NioApp.Wizard = function() {
    var $wizard = $('.nk-wizard');
    if ($wizard.exists()) {
        $wizard.each(function() {
            var $self    = $(this),
                _self_id = $self.attr('id'),
                $self_id = $('#' + _self_id).show();
            $self_id.steps({
                headerTag:      '.nk-wizard-head',
                bodyTag:        '.nk-wizard-content',
                labels:         {
                    finish:   'ارسال',
                    next:     'بعدی',
                    previous: 'قبلی',
                    loading:  'در حال بارگذاری ...',
                },
                titleTemplate:  '<span class="number">0#index#</span> #title#',
                onStepChanging: function onStepChanging(
                    event, currentIndex, newIndex) {
                    // Allways allow previous action even if the current
                    // form is not valid!
                    if (currentIndex > newIndex) {
                        return true;
                    }
                    // Needed in some cases if the user went back (clean up)
                    if (currentIndex < newIndex) {
                        // To remove error styles
                        $self_id.find(
                                '.body:eq(' + newIndex + ') label.error').
                            remove();
                        $self_id.find('.body:eq(' + newIndex + ') .error').
                            removeClass('error');
                    }
                    $self_id.validate().settings.ignore = ':disabled,:hidden';
                    return $self_id.valid();
                },
                onFinishing:    function onFinishing(event, currentIndex) {
                    $self_id.validate().settings.ignore = ':disabled';
                    return $self_id.valid();
                },
                onFinished:     function onFinished(event, currentIndex) {
                    window.location.href = '#';
                },
            }).validate({
                errorElement:   'span',
                errorClass:     'invalid',
                errorPlacement: function errorPlacement(error, element) {
                    error.appendTo(element.parent());
                },
            });
        });
    }
};

// DataTable @1.1
NioApp.DataTable = function(elm, opt) {
    if ($(elm).exists()) {
        $(elm).each(function() {
            var auto_responsive = $(this).data('auto-responsive'),
                has_export      = typeof opt.buttons !== 'undefined' &&
                                  opt.buttons
                                  ? true
                                  : false;
            var export_title = $(this).data('export-title') ? $(this).
                data('export-title') : 'Export';
            var btn     = has_export
                          ? '<"dt-export-buttons d-flex align-center"<"dt-export-title d-none d-md-inline-block">B>'
                          : '',
                btn_cls = has_export ? ' with-export' : '';
            var dom_normal = '<"row justify-between g-2' + btn_cls +
                '"<"col-7 col-sm-4 text-start"f><"col-5 col-sm-8 text-end"<"datatable-filter"<"d-flex justify-content-end g-2"' +
                btn +
                'l>>>><"datatable-wrap my-3"t><"row align-items-center"<"col-7 col-sm-12 col-md-9"p><"col-5 col-sm-12 col-md-3 text-start text-md-end"i>>';
            var dom_separate = '<"row justify-between g-2' + btn_cls +
                '"<"col-7 col-sm-4 text-start"f><"col-5 col-sm-8 text-end"<"datatable-filter"<"d-flex justify-content-end g-2"' +
                btn +
                'l>>>><"my-3"t><"row align-items-center"<"col-7 col-sm-12 col-md-9"p><"col-5 col-sm-12 col-md-3 text-start text-md-end"i>>';
            var dom = $(this).hasClass('is-separate')
                      ? dom_separate
                      : dom_normal;
            var def  = {
                    responsive: true,
                    autoWidth:  false,
                    dom:        dom,
                    language:   {
                        search:            '',
                        searchPlaceholder: 'برای جستجو تایپ کنید',
                        lengthMenu:        '<span class=\'d-none d-sm-inline-block\'>نمایش</span><div class=\'form-control-select\'> _MENU_ </div>',
                        info:              '_START_ -_END_ از _TOTAL_',
                        infoEmpty:         '0',
                        infoFiltered:      '( کل _MAX_  )',
                        paginate:          {
                            'first':    'اول',
                            'last':     'آخر',
                            'next':     'بعدی',
                            'previous': 'قبلی',
                        },
                    },
                },
                attr = opt ? extend(def, opt) : def;
            attr = auto_responsive === false ? extend(attr, {
                responsive: false,
            }) : attr;
            $(this).DataTable(attr);
            $('.dt-export-title').text(export_title);
        });
    }
};

// DataTable Init @v1.0
NioApp.DataTable.init = function() {
    NioApp.DataTable('.datatable-init', {
        responsive: {
            details: true,
        },
    });
    NioApp.DataTable('.datatable-init-export', {
        responsive: {
            details: true,
        },
        buttons:    ['copy', 'excel', 'csv', 'pdf'],
    });
    $.fn.DataTable.ext.pager.numbers_length = 7;
};

// BootStrap Extended
NioApp.BS.ddfix = function(elm, exc) {
    var dd = elm ? elm : '.dropdown-menu',
        ex = exc
             ? exc
             : 'a:not(.clickable), button:not(.clickable), a:not(.clickable) *, button:not(.clickable) *';
    $(dd).on('click', function(e) {
        if (!$(e.target).is(ex)) {
            // e.stopPropagation();
            return;
        }
    });
    if (NioApp.State.isRTL) {
        var $dMenu = $('.dropdown-menu');
        $dMenu.each(function() {
            var $self = $(this);
            if ($self.hasClass('dropdown-menu-end') &&
                !$self.hasClass('dropdown-menu-center')) {
                $self.prev('[data-bs-toggle="dropdown"]').dropdown({
                    popperConfig: {
                        placement: 'bottom-start',
                    },
                });
            } else if (!$self.hasClass('dropdown-menu-end') &&
                !$self.hasClass('dropdown-menu-center')) {
                $self.prev('[data-bs-toggle="dropdown"]').dropdown({
                    popperConfig: {
                        placement: 'bottom-end',
                    },
                });
            }
        });
    }
};

// BootStrap Specific Tab Open
NioApp.BS.tabfix = function(elm) {
    var tab = elm ? elm : '[data-bs-toggle="modal"]';
    $(tab).on('click', function() {
        var _this       = $(this),
            target      = _this.data('target'),
            target_href = _this.attr('href'),
            tg_tab      = _this.data('tab-target');
        var modal = target ? $body.find(target) : $body.find(
            target_href);
        if (tg_tab && tg_tab !== '#' && modal) {
            modal.find('[href="' + tg_tab + '"]').tab('show');
        } else if (modal) {
            var tabdef = modal.find('.nk-nav.nav-tabs');
            var link = $(tabdef[0]).find('[data-bs-toggle="tab"]');
            $(link[0]).tab('show');
        }
    });
};

// Dark Mode Switch @since v2.0
NioApp.ModeSwitch = function() {
    var toggle = $('.dark-switch');
    if ($body.hasClass('dark-mode')) {
        toggle.addClass('active');
    } else {
        toggle.removeClass('active');
    }
    toggle.on('click', function(e) {
        e.preventDefault();
        $(this).toggleClass('active');
        $body.toggleClass('dark-mode');
    });
};

// Knob @v1.0
NioApp.Knob = function(elm, opt) {
    if ($(elm).exists() && typeof $.fn.knob === 'function') {
        var def  = {
                min: 0,
            },
            attr = opt ? extend(def, opt) : def;
        $(elm).each(function() {
            $(this).knob(attr);
        });
    }
};
// Knob Init @v1.0
NioApp.Knob.init = function() {
    var knob = {
        'default': {
            readOnly: true,
            lineCap:  'round',
        },
        half:      {
            angleOffset: -90,
            angleArc:    180,
            readOnly:    true,
            lineCap:     'round',
        },
    };
    NioApp.Knob('.knob', knob['default']);
    NioApp.Knob('.knob-half', knob.half);
};

// Range @v1.0.1
NioApp.Range = function(elm, opt) {
    if ($(elm).exists() && typeof noUiSlider !== 'undefined') {
        $(elm).each(function() {
            var $self   = $(this),
                self_id = $self.attr('id');
            var _start        = $self.data('start'),
                _start        = /\s/g.test(_start)
                                ? _start.split(' ')
                                : _start,
                _start        = _start ? _start : 0,
                _connect      = $self.data('connect'),
                _connect      = /\s/g.test(_connect)
                                ? _connect.split(' ')
                                : _connect,
                _connect      = typeof _connect == 'undefined'
                                ? 'lower'
                                : _connect,
                _min          = $self.data('min'),
                _min          = _min ? _min : 0,
                _max          = $self.data('max'),
                _max          = _max ? _max : 100,
                _min_distance = $self.data('min-distance'),
                _min_distance = _min_distance ? _min_distance : null,
                _max_distance = $self.data('max-distance'),
                _max_distance = _max_distance ? _max_distance : null,
                _step         = $self.data('step'),
                _step         = _step ? _step : 1,
                _orientation  = $self.data('orientation'),
                _orientation  = _orientation ? _orientation : 'horizontal',
                _tooltip      = $self.data('tooltip'),
                _tooltip      = _tooltip ? _tooltip : false;
            console.log(_tooltip);
            var target = document.getElementById(self_id);
            var def  = {
                    start:       _start,
                    connect:     _connect,
                    direction:   NioApp.State.isRTL ? 'rtl' : 'ltr',
                    range:       {
                        'min': _min,
                        'max': _max,
                    },
                    margin:      _min_distance,
                    limit:       _max_distance,
                    step:        _step,
                    orientation: _orientation,
                    tooltips:    _tooltip,
                },
                attr = opt ? extend(def, opt) : def;
            noUiSlider.create(target, attr);
        });
    }
};

// Range Init @v1.0
NioApp.Range.init = function() {
    NioApp.Range('.form-control-slider');
    NioApp.Range('.form-range-slider');
};
NioApp.Select2.init = function() {
    NioApp.Select2('.js-select2');
};

// Slick Slider @v1.0.1
NioApp.Slick = function(elm, opt) {
    if ($(elm).exists() && typeof $.fn.slick === 'function') {
        $(elm).each(function() {
            var def  = {
                    'prevArrow': '<div class="slick-arrow-prev"><a href="javascript:void(0);" class="slick-prev"><em class="icon ni ni-chevron-left"></em></a></div>',
                    'nextArrow': '<div class="slick-arrow-next"><a href="javascript:void(0);" class="slick-next"><em class="icon ni ni-chevron-right"></em></a></div>',
                    rtl:         NioApp.State.isRTL,
                },
                attr = opt ? extend(def, opt) : def;
            $(this).slick(attr);
        });
    }
};

// Slick Init @v1.0
NioApp.Slider.init = function() {
    NioApp.Slick('.slider-init');
};

// Magnific Popup @v1.0.0
NioApp.Lightbox = function(elm, type, opt) {
    if ($(elm).exists()) {
        $(elm).each(function() {
            var def = {};
            if (type == 'video' || type == 'iframe') {
                def = {
                    type:            'iframe',
                    removalDelay:    160,
                    preloader:       true,
                    fixedContentPos: false,
                    callbacks:       {
                        beforeOpen: function beforeOpen() {
                            this.st.image.markup = this.st.image.markup.replace(
                                'mfp-figure',
                                'mfp-figure mfp-with-anim');
                            this.st.mainClass = this.st.el.attr(
                                'data-effect');
                        },
                    },
                };
            } else if (type == 'content') {
                def = {
                    type:         'inline',
                    preloader:    true,
                    removalDelay: 400,
                    mainClass:    'mfp-fade content-popup',
                };
            } else {
                def = {
                    type:      'image',
                    mainClass: 'mfp-fade image-popup',
                };
            }
            var attr = opt ? extend(def, opt) : def;
            $(this).magnificPopup(attr);
        });
    }
};

// Controls @v1.0.0
NioApp.Control = function(elm) {
    var control = document.querySelectorAll(elm);
    control.forEach(function(item, index, arr) {
        item.checked ? item.parentNode.classList.add('checked') : null;
        item.addEventListener('change', function() {
            if (item.type == 'checkbox') {
                item.checked
                ? item.parentNode.classList.add('checked')
                : item.parentNode.classList.remove(
                    'checked');
            }
            if (item.type == 'radio') {
                document.querySelectorAll(
                        'input[name="' + item.name + '"]').
                    forEach(function(item, index, arr) {
                        item.parentNode.classList.remove('checked');
                    });
                item.checked
                ? item.parentNode.classList.add('checked')
                : null;
            }
        });
    });
};

// Number Spinner @v1.0
NioApp.NumberSpinner = function(elm, opt) {
    var plus = document.querySelectorAll('[data-number=\'plus\']');
    var minus = document.querySelectorAll('[data-number=\'minus\']');
    plus.forEach(function(item, index, arr) {
        var parent = plus[index].parentNode;
        plus[index].addEventListener('click', function() {
            var child = plus[index].parentNode.children;
            child.forEach(function(item, index, arr) {
                if (child[index].classList.contains('number-spinner')) {
                    var value = !child[index].value == '' ? parseInt(
                        child[index].value) : 0;
                    var step = !child[index].step == ''
                               ? parseInt(child[index].step)
                               : 1;
                    var max = !child[index].max == ''
                              ? parseInt(child[index].max)
                              : Infinity;
                    if (max + 1 > value + step) {
                        child[index].value = value + step;
                    } else {
                        child[index].value = value;
                    }
                }
            });
        });
    });
    minus.forEach(function(item, index, arr) {
        var parent = minus[index].parentNode;
        minus[index].addEventListener('click', function() {
            var child = minus[index].parentNode.children;
            child.forEach(function(item, index, arr) {
                if (child[index].classList.contains('number-spinner')) {
                    var value = !child[index].value == '' ? parseInt(
                        child[index].value) : 0;
                    var step = !child[index].step == ''
                               ? parseInt(child[index].step)
                               : 1;
                    var min = !child[index].min == ''
                              ? parseInt(child[index].min)
                              : 0;
                    if (min - 1 < value - step) {
                        child[index].value = value - step;
                    } else {
                        child[index].value = value;
                    }
                }
            });
        });
    });
};

// Stepper @v1.0
NioApp.Stepper = function(elm, opt) {
    var element = document.querySelectorAll(elm);
    if (element.length > 0) {
        element.forEach(function(item, index) {
            var def  = {
                    selectors:    {
                        nav:      'stepper-nav',
                        progress: 'stepper-progress',
                        content:  'stepper-steps',
                        prev:     'step-prev',
                        next:     'step-next',
                        submit:   'step-submit',
                    },
                    classes:      {
                        nav_current: 'current',
                        nav_done:    'done',
                        step_active: 'active',
                        step_done:   'done',
                        active_step: 'active',
                    },
                    current_step: 1,
                },
                attr = opt ? extend(def, opt) : def;
            NioApp.Custom.Stepper(item, attr);
            NioApp.Validate.OnChange('.js-select2');
            NioApp.Validate.OnChange('.date-picker');
            NioApp.Validate.OnChange('.js-tagify');
        });
    }
};
// Stepper Init @v1.0
NioApp.Stepper.init = function() {
    NioApp.Stepper('.stepper-init');
};

// Tagify @v1.0.1
NioApp.Tagify = function(elm, opt) {
    if ($(elm).exists() && typeof $.fn.tagify === 'function') {
        var def,
            attr = opt ? extend(def, opt) : def;
        $(elm).tagify(attr);
    }
};
// Tagify Init @v1.0
NioApp.Tagify.init = function() {
    NioApp.Tagify('.js-tagify');
};

/* Isotope - Filter @v1.0 */
NioApp.Filter = function(elem, childSelector) {
    var qsRegex;
    var elm = document.querySelectorAll(elem);
    elm.forEach(function(item) {
        if (typeof item != 'undefined' && item != null) {
            var iso = new Isotope(item, {
                itemSelector: childSelector,
                layoutMode:   'fitRows',
                filter:       function filter(itemElem) {
                    return qsRegex
                           ? itemElem.textContent.match(qsRegex)
                           : true;
                },
                hiddenStyle:  {
                    opacity:   0,
                    transform: 'scale(0.001)',
                },
                visibleStyle: {
                    opacity:   1,
                    transform: 'scale(1)',
                },
            });
            var filterBtn = document.querySelectorAll('[data-filter]');
            console.log();
            filterBtn.forEach(function(btnItem) {
                btnItem.addEventListener('click', function(event) {
                    // only work with buttons
                    if (!matchesSelector(event.target, 'button')) {
                        return;
                    }
                    var filterValue = event.target.getAttribute(
                        'data-filter');
                    iso.arrange({
                        filter: filterValue,
                    });
                    filterBtn.forEach(function(allButtons) {
                        allButtons.classList.remove('active');
                    });
                    btnItem.classList.add('active');
                });
            });
        }
    });
};

// Extra @v1.1
NioApp.OtherInit = function() {
    NioApp.ClassBody();
    NioApp.PassSwitch();
    NioApp.LinkOff('.is-disable');
    NioApp.ClassNavMenu();
    NioApp.menuSwitch();
    NioApp.SetHW('[data-height]', 'height');
    NioApp.SetHW('[data-width]', 'width');
    NioApp.NumberSpinner();
    NioApp.Lightbox('.popup-video', 'video');
    NioApp.Lightbox('.popup-iframe', 'iframe');
    NioApp.Lightbox('.popup-image', 'image');
    NioApp.Lightbox('.popup-content', 'content');
    NioApp.Control('.custom-control-input');
    NioApp.Filter('.filter-container', '.filter-item');
};

// Animate Init @v1.0
NioApp.Ani.init = function() {
    NioApp.Ani.formElm('.form-control-outlined');
    NioApp.Ani.formSearch('.toggle-search');
};

// BootstrapExtend Init @v1.0
NioApp.BS.init = function() {
    NioApp.BS.menutip('a.nk-menu-link');
    NioApp.BS.tooltip('.nk-tooltip');
    NioApp.BS.tooltip('.btn-tooltip', {
        placement: 'top',
    });
    NioApp.BS.tooltip('[data-toggle="tooltip"]');
    NioApp.BS.tooltip('[data-bs-toggle="tooltip"]');
    NioApp.BS.tooltip('.tipinfo,.nk-menu-tooltip', {
        placement: 'right',
    });
    NioApp.BS.popover('[data-toggle="popover"]');
    NioApp.BS.popover('[data-bs-toggle="popover"]');
    NioApp.BS.progress('[data-progress]');
    NioApp.BS.fileinput('.form-file-input');
    NioApp.BS.modalfix();
    NioApp.BS.ddfix();
    NioApp.BS.tabfix();
};

// Picker Init @v1.0
NioApp.Picker.init = function() {
    NioApp.Picker.date('.date-picker');
    NioApp.Picker.dob('.date-picker-alt');
    NioApp.Picker.time('.time-picker', {
        timeFormat: 'HH:mm',
    });
    NioApp.Picker.date('.date-picker-range', {
        todayHighlight: false,
        autoclose:      false,
    });
    NioApp.Picker.date('.date-picker-ym', {
        format:      'yy/mm',
        startView:   2,
        autoclose:   true,
        maxViewMode: 2,
        minViewMode: 1,
    });
};

// Addons @v1
NioApp.Addons.Init = function() {
    NioApp.Knob.init();
    NioApp.Range.init();
    NioApp.Select2.init();
    NioApp.Dropzone.init();
    NioApp.Slider.init();
    NioApp.DataTable.init();
    NioApp.Tagify.init();
};

// Toggler @v1
NioApp.TGL.init = function() {
    NioApp.TGL.content('.toggle');
    NioApp.TGL.expand('.toggle-expand');
    NioApp.TGL.expand('.toggle-opt', {
        toggle: false,
    });
    NioApp.TGL.showmenu('.nk-nav-toggle');
    NioApp.TGL.ddmenu('.' + _menu + '-toggle', {
        self:  _menu + '-toggle',
        child: _menu + '-sub',
    });
};
NioApp.BS.modalOnInit = function() {
    $('.modal').on('shown.bs.modal', function() {
        NioApp.Select2.init();
        NioApp.Validate.init();
    });
};
NioApp.Quill = function() {
    
    function initQuill(el, toolbarOptions, isMinimal) {
        
        let $el = $(el);
        if (el.__quill || $el.data('quill') || $el.children('.ql-container').length) {
            return el.__quill || $el.data('quill');
        }
        
        // 🧠 گرفتن مقدار اولیه از hidden textarea
        let initialValue = $el.find('.quill-value').val() || '';
        
        let quill = new Quill(el, {
            modules: {
                toolbar: toolbarOptions,
            },
            theme:   'snow',
        });
        el.__quill = quill;
        $el.data('quill', quill);
        
        // ✅ set initial value
        if (initialValue) {
            quill.root.innerHTML = initialValue;
        }
        
        // 🔥 sync to data-for
        quill.on('text-change', function() {
            let html = quill.root.innerHTML;
            
            // update hidden value
            $el.find('.quill-value').val(html);
            
            // update system bridge
            $el.attr('data-value', html);
        });
        
        return quill;
    }
    
    // FULL
    var _basic = '.quill-basic';
    if ($(_basic).exists()) {
        $(_basic).each(function() {
            
            var toolbarOptions = [
                ['bold', 'italic', 'underline', 'strike'],
                ['blockquote', 'code-block'],
                [{'list': 'ordered'}, {'list': 'bullet'}],
                [{'script': 'sub'}, {'script': 'super'}],
                [{'indent': '-1'}, {'indent': '+1'}],
                [{'header': [1, 2, 3, 4, 5, 6]}],
                [{'color': []}, {'background': []}],
                [{'align': []}],
                ['clean'],
            ];
            
            initQuill(this, toolbarOptions, false);
        });
    }
    
    // MINIMAL
    var _minimal = '.quill-minimal';
    if ($(_minimal).exists()) {
        $(_minimal).each(function() {
            
            var toolbarOptions = [
                ['bold', 'italic', 'underline'],
                ['blockquote', {'list': 'bullet'}],
                [{'align': []}],
                ['clean'],
            ];
            
            initQuill(this, toolbarOptions, true);
        });
    }
};

NioApp.init = function() {
    NioApp.coms.docReady.push(NioApp.OtherInit);
    NioApp.coms.docReady.push(NioApp.Prettify);
    NioApp.coms.docReady.push(NioApp.ColorBG);
    NioApp.coms.docReady.push(NioApp.ColorTXT);
    NioApp.coms.docReady.push(NioApp.Copied);
    NioApp.coms.docReady.push(NioApp.Ani.init);
    NioApp.coms.docReady.push(NioApp.TGL.init);
    NioApp.coms.docReady.push(NioApp.BS.init);
    NioApp.coms.docReady.push(NioApp.Validate.init);
    NioApp.coms.docReady.push(NioApp.Picker.init);
    NioApp.coms.docReady.push(NioApp.Addons.Init);
    NioApp.coms.docReady.push(NioApp.Wizard);
    NioApp.coms.docReady.push(NioApp.Stepper.init);
    NioApp.coms.winLoad.push(NioApp.ModeSwitch);
    NioApp.coms.winLoad.push(NioApp.StickyNav.init);
    NioApp.coms.docReady.push(NioApp.Quill);
    activate_date_pickers();
    add_loading_block();
    activate_dragula();
    activate_charts();
    calc_factor_total($('form.modal_form.kerp-order-form'));
};
NioApp.ajaxInit = function() {
    kerpDashboardLoad();
    NioApp.OtherInit();
    NioApp.Prettify();
    NioApp.ColorBG();
    NioApp.ColorTXT();
    NioApp.Copied();
    NioApp.Ani.init();
    NioApp.TGL.init();
    NioApp.BS.init();
    NioApp.Validate.init();
    NioApp.Picker.init();
    NioApp.Addons.Init();
    kerp_init_ajax_search_selects(document);
    NioApp.Wizard();
    NioApp.ModeSwitch();
    NioApp.Stepper.init();
    NioApp.StickyNav.init();
    NioApp.Quill();
    activate_date_pickers();
    add_loading_block();
    evaluateAll();
    activate_dragula();
    activate_charts();
    calc_factor_total($('form.modal_form.kerp-order-form'));
};

NioApp.init();
