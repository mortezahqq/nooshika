// Opt-in shared table search. Ordinary filter requests retain the ERP loading overlay.
function kerpTableSearchAjax(options) {
    ajax_search = options.ajax_search === true;
    try {
        return $.ajax(options);
    } finally {
        // ajaxSend runs synchronously. Never leave this flag enabled while waiting for a response.
        ajax_search = false;
    }
}

function kerpTableSearchCancel($root) {
    clearTimeout($root.data('kerp-table-search-timer'));
    $root.data('kerp-table-search-version', ($root.data('kerp-table-search-version') || 0) + 1);
    const request = $root.data('kerp-table-search-request');
    $root.removeData('kerp-table-search-request').attr('aria-busy', 'false');
    if (request) request.abort();
    $root.trigger('kerp:table-search-cancel');
}

function kerpTableSearchSchedule(input, delay) {
    const $input = $(input);
    const $root = $input.closest('[data-kerp-table-search]');
    if (!$root.length) return;
    kerpTableSearchCancel($root);
    const version = $root.data('kerp-table-search-version');
    $root.data('kerp-table-search-timer', setTimeout(function() {
        if (!$root[0].isConnected) return;
        const event = $.Event('kerp:table-search');
        $root.trigger(event);
        // Lists may provide a result-only renderer, as the employees list does.
        if (event.isDefaultPrevented()) return;
        const data = get_current_page_filters($root);
        data.search = String($input.val() || '');
        data.action = 'erp_request_page_content';
        data.page = $root.attr('data-search-page');
        data.page_number = 1;
        if (!data.page) return;
        const cursor = input.selectionStart;
        $root.attr('aria-busy', 'true');
        const request = kerpTableSearchAjax({url: ajax_url, type: 'POST', dataType: 'json', timeout: 30000, ajax_search: true, data});
        $root.data('kerp-table-search-request', request);
        request.done(function(response) {
            if (!$root[0].isConnected || $root.data('kerp-table-search-version') !== version) return;
            if (response.status !== 'success') {
                NioApp.Toast(response.message || 'دریافت نتایج ناموفق بود.', 'danger', {position: 'top-right'});
                return;
            }
            if ($root.is('[data-table-results]')) {
                const $content = $('<div>').append($.parseHTML(response.main || '', document, false));
                const $next = $content.find('[data-kerp-table-search]').filter(function() {
                    return this.id === $root[0].id;
                });
                const selector = $root.attr('data-table-results');
                if ($next.length !== 1 || !$next.find(selector).length) {
                    NioApp.Toast('پاسخ فهرست معتبر نیست؛ دوباره تلاش کنید.', 'danger', {position: 'top-right'});
                    return;
                }
                $root.find(selector).find('[data-bs-toggle="tooltip"], .kerp-table-tooltip').tooltip('dispose');
                $root.find(selector).html($next.find(selector).html());
                $root.find('[data-table-count]').text($next.find('[data-table-count]').text());
                if (response.url) history.replaceState(history.state, '', response.url);
                NioApp.ajaxInit();
                return;
            }
            const focused = document.activeElement === input;
            change_panel_html(response);
            const next = document.getElementById(input.id);
            if (focused && next) {
                next.focus({preventScroll: true});
                next.setSelectionRange(cursor, cursor);
            }
        }).fail(function(xhr, reason) {
            if (reason !== 'abort' && $root[0].isConnected && $root.data('kerp-table-search-version') === version) {
                NioApp.Toast('خطا در دریافت نتایج؛ دوباره تلاش کنید.', 'danger', {position: 'top-right'});
            }
        }).always(function() {
            if ($root.data('kerp-table-search-version') === version) $root.attr('aria-busy', 'false');
        });
    }, delay));
}

$(document).on('input compositionend', '.kerp-table-search', function(event) {
    if (event.originalEvent?.isComposing) return;
    kerpTableSearchSchedule(this, 350);
});
$(document).on('keydown', '.kerp-table-search', function(event) {
    if (event.key === 'Enter' && !event.originalEvent?.isComposing) {
        event.preventDefault();
        kerpTableSearchSchedule(this, 0);
    }
});
$(document).on('submit', '[data-kerp-table-search] form[role="search"]', function(event) {
    event.preventDefault();
    const input = $(this).find('.kerp-table-search')[0];
    if (input) kerpTableSearchSchedule(input, 0);
});
$(document).on('click', '.kerp-table-search-submit[type="button"]', function(event) {
    event.preventDefault();
    const input = $(this).closest('[data-kerp-table-search]').find('.kerp-table-search')[0];
    if (input) kerpTableSearchSchedule(input, 0);
});
$(document).ajaxSend(function(event, xhr, settings) {
    if (settings.ajax_search === true || settings.kerpEmployeesFilter) return;
    const data = typeof settings.data === 'string' ? new URLSearchParams(settings.data) : null;
    const action = data ? data.get('action') : settings.data?.action;
    if (!['erp_request_page_content', 'erp_request_back_btn'].includes(action)) return;
    $('[data-kerp-table-search]').each(function() {
        kerpTableSearchCancel($(this));
    });
});

$(document).on('kerp:search-closed show.bs.modal', '[data-kerp-table-search]', function() {
    kerpTableSearchCancel($(this));
});

// Result-only lists share accessible tooltips without replacing Bootstrap modal/dropdown toggles.
const kerpTableTooltipTargets = '[data-table-results] button, [data-table-results] .btn, [data-table-results] .page-link, [data-table-results] .reset_page_filter, [data-table-results] .change_per_page';
function kerpTableShowTooltip() {
    const $button = $(this);
    if ($button.is('[data-kerp-no-tooltip]')) return;
    if ($button.is('[data-bs-toggle="tooltip"]') || $button.parent().is('[data-bs-toggle="tooltip"]')) return;
    const page = $button.closest('.page-item').attr('data-page');
    const per = $button.attr('data-per-page');
    const label = $button.attr('aria-label') || $button.attr('data-bs-original-title') || $button.attr('title') || (page ? 'صفحه ' + page : per ? 'نمایش ' + per + ' مورد' : $.trim($button.text()));
    if (!label || typeof $.fn.tooltip !== 'function') return;
    $button.attr('aria-label', label);
    if (!$button.hasClass('kerp-table-tooltip')) $button.addClass('kerp-table-tooltip').tooltip({title: label, trigger: 'hover focus', container: 'body'});
    $button.tooltip('show');
}
$(document).on('mouseenter focusin', kerpTableTooltipTargets, kerpTableShowTooltip);
$(document).on('click mouseleave focusout', kerpTableTooltipTargets, function() {
    if ($(this).hasClass('kerp-table-tooltip')) $(this).tooltip('hide');
});
