NioApp.Package.name = 'DashLite';
NioApp.Package.version = '3.2';
let $win          = $(window),
    $body         = $('body'),
    $doc          = $(document),
    _menu         = 'nk-menu',
    _menu_switch  = 'nk-menu-switch',
    _menu_content = 'nk-menu-content',
    _menu_active  = 'menu-active',
    _header       = 'nk-header',
    _header_menu  = 'nk-header-menu',
    _sidebar      = 'nk-sidebar',
    _sidebar_mob  = 'nk-sidebar-mobile',
    _break        = NioApp.Break,
    search_ajax,
    time,
    timer_interval,
    ajax_url      = KERPData.ajaxUrl,
    ajax_search   = false,
    request_city  = true;
NioApp.State.isRTL = true;