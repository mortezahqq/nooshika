(function ($) {
    'use strict';
    $(document).on('click', '.kc-media-select', function () {
        const $field = $(this).closest('.kc-media-field');
        const frame = wp.media({title: 'انتخاب تصویر', button: {text: 'انتخاب'}, multiple: false});
        frame.on('select', function () {
            const item = frame.state().get('selection').first().toJSON();
            $field.find('input[type="hidden"]').val(item.id);
            $field.find('.kc-media-preview').html($('<img>', {src: item.sizes && item.sizes.thumbnail ? item.sizes.thumbnail.url : item.url, alt: ''}));
        });
        frame.open();
    });
    $(document).on('click', '.kc-media-remove', function () {
        const $field = $(this).closest('.kc-media-field');
        $field.find('input[type="hidden"]').val('0'); $field.find('.kc-media-preview').empty();
    });
}(jQuery));
