/* =========================
   KASEBI  BUILD START
   ========================= */

!function(NioApp, $) {
'use strict';


/* ===== const.js ===== */
NioApp.Package.name = 'DashLite';
NioApp.Package.version = '3.2';
let $win          = $(window),
    $body         = $('body'),
    $doc          = $(document),
    _menu         = 'nk-menu',
    _menu_switch  = 'nk-menu-switch',
    _menu_content = 'nk-menu-content',
    _menu_active  = 'menu-active',
    _header       = 'nk-header',
    _header_menu  = 'nk-header-menu',
    _sidebar      = 'nk-sidebar',
    _sidebar_mob  = 'nk-sidebar-mobile',
    _break        = NioApp.Break,
    search_ajax,
    time,
    timer_interval,
    ajax_url      = KERPData.ajaxUrl,
    ajax_search   = false,
    request_city  = true;
NioApp.State.isRTL = true;


/* ===== util.js ===== */
function extend(obj, ext) {
    Object.keys(ext).forEach(function(key) {
        obj[key] = ext[key];
    });
    return obj;
}

function activate_date_pickers() {
    let years = [];
    for (let i = 1321; i <= 1407; i++) {
        years.push(i);
    }
    $('.datepicker').each(function() {
        let _this = $(this);
        if (_this.data('kerp-datepicker-initialized')) {
            return;
        }
        let args = {
            nextArrow:       '<i class="fas fa-chevron-left"></i>',
            prevArrow:       '<i class="fas fa-chevron-right"></i>',
            formatDate:      'YYYY-MM-DD',
            cellWidth:       27,
            cellHeight:      26,
            selectableYears: years,
            onSelect:        function() {
                _this.trigger('change');
            },
        };
        // The picker parses slash-separated dates, while ERP forms submit hyphenated dates.
        const kerpTypedDate = String(_this.val() || '').trim()
            .replace(/[۰-۹]/g, digit => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(digit)))
            .replace(/[٠-٩]/g, digit => String('٠١٢٣٤٥٦٧٨٩'.indexOf(digit)))
            .match(/^(\d{4})[-/](\d{1,2})[-/](\d{1,2})$/);
        if (kerpTypedDate && Number(kerpTypedDate[2]) >= 1 && Number(kerpTypedDate[2]) <= 12 &&
            Number(kerpTypedDate[3]) >= 1 && Number(kerpTypedDate[3]) <= 31) {
            args.selectedDate = kerpTypedDate.slice(1).map(Number).join('/');
        } else if (_this.attr('data-value')) {
            let selectedDate = _this.attr('data-value');
            args['selectedDate'] = new Date(
                selectedDate).toLocaleDateString(
                'fa-IR-u-nu-latn');
            args['selectedBefore'] = !0;
        }
        _this.persianDatepicker(args);
        _this.data('kerp-datepicker-initialized', true);
    });
}

function add_loading_block() {
    let loading_html = '<div class="modal fade" id="loading_modal">'
        + '<div class="modal-dialog">'
        +
        '<div class="loader" style="width: 3rem; height: 3rem; margin: auto" role="status"></div>'
        + '</div></div>';
    $('#loading_modal').remove();
    $('body').append(loading_html);
}

function show_loading_modal() {
    $('#loading_modal').addClass('show').css('display', 'block');
}

function hide_loading_modal() {
    $('#loading_modal').removeClass('show').css('display', 'none');
}

function validate_phone_number(phone) {
    let regex = /^(\+98|0)?9\d{9}$/;
    return regex.test(toEnglishNumber(phone));
}

function validate_slug(slug) {
    let regex = /^[a-zA-Z0-9-_]+$/;
    return regex.test(slug);
}

function number_format(number) {
    return new Intl.NumberFormat('en').format(number);
}

function toEnglishNumber(strNum, element = null) {
    if (strNum === undefined || strNum === null) {
        return '';
    }
    let s = String(strNum);
    
    // تبدیل ارقام فارسی (۰-۹) و عربی (٠-٩) به انگلیسی
    const fa = '۰۱۲۳۴۵۶۷۸۹';
    const ar = '٠١٢٣٤٥٦٧٨٩';
    s = s.replace(/[۰-۹]/g, d => String(fa.indexOf(d))).replace(/[٠-٩]/g, d => String(ar.indexOf(d)));
    
    if (element) {
        $(element).val(s);
        return;
    }
    return s;
}

function sanitizeNumber(number, keepDecimal = false) {
    if (number === undefined || number === null || number === '') {
        return 0;
    }
    
    let s = toEnglishNumber(String(number)).trim();
    
    // − -> -
    s = s.replace(/\u2212/g, '-');
    
    // (123) -> -123
    if (/^\(.*\)$/.test(s)) {
        s = '-' + s.slice(1, -1);
    }
    
    // ممیز عربی/فارسی -> نقطه
    s = s.replace(/\u066B/g, '.'); // ٫ -> .
    
    // جداکننده‌های هزارگان: comma انگلیسی هم باید باشد
    s = s.replace(/[,٬،\u00A0\u202F_]/g, '');
    
    if (keepDecimal) {
        // فقط عدد، منفی و نقطه بماند
        s = s.replace(/[^0-9.\-]/g, '');
        
        // منفی فقط اول رشته مجاز باشد
        s = s.replace(/(?!^)-/g, '');
        
        // اگر چندتا نقطه داشت، فقط اولی ممیز باشد
        const parts = s.split('.');
        if (parts.length > 2) {
            s = parts.shift() + '.' + parts.join('');
        }
    } else {
        // بدون اعشار: نقطه هم حذف شود
        s = s.replace(/\./g, '');
        
        // فقط عدد و منفی بماند
        s = s.replace(/[^0-9\-]/g, '');
        
        // منفی فقط اول رشته مجاز باشد
        s = s.replace(/(?!^)-/g, '');
    }
    
    const n = keepDecimal ? parseFloat(s) : parseInt(s, 10);
    
    return isNaN(n) ? 0 : n;
}

function formatNumber(num) {
    if (num >= 1_000_000_000) {
        return (num / 1_000_000_000).toFixed(2) + ' میلیارد';
    } else if (num >= 1_000_000) {
        return (num / 1_000_000).toFixed(2) + ' میلیون';
    } else if (num >= 1_000) {
        return (num / 1_000).toFixed(2) + ' هزار';
    }
    return num.toFixed(2);
}

// Public integration point for independently enqueued ERP addons.
$(document).on('kerp:page-response', function(event, response) {
    if (response && typeof response === 'object') change_panel_html(response);
});

function change_panel_html(response) {
    if (response.status === 'error' && response.validation_pane) {
        const pane = document.getElementById(response.validation_pane);
        if (pane && pane.classList.contains('tab-pane')) {
            const $pane = $(pane);
            const $form = $pane.closest('.modal_form');
            $form.find('.kerp-tab-validation-error').remove();
            $form.find('[data-bs-toggle="tab"]').filter(function() {
                return this.getAttribute('href') === '#' + pane.id;
            }).first().tab('show');
            const $error = $('<div class="alert alert-danger kerp-tab-validation-error" role="alert" tabindex="-1">')
                .text(response.message || response.msg || 'اطلاعات این بخش را بررسی کنید.');
            $pane.prepend($error);
            $error[0].focus({preventScroll: true});
            $error[0].scrollIntoView({block: 'center', behavior: 'smooth'});
            return;
        }
    }
    $('.modal').modal('hide');
    $('.modal-backdrop').remove();
    $('.tooltip').remove();
    if (response.main) {
        $('#kerp-app').html(response.main);
        NioApp.ajaxInit();
        $('html, body').animate({ scrollTop: 0 }, 500);
    }
    if (response.title) {
        document.title = response.title;
    }
    if (response.url) {
        history.pushState({}, '', response.url);
    }
    const message = response.message || response.msg;
    
    if (message) {
        NioApp.Toast(message, response.status || 'info', {
            position: 'top-right',
        });
    }
}

// Only the newest navigation/filter response may replace the ERP panel.
let kerpPageRequestVersion = 0;
let kerpPageRequestPending = null;
function kerpRequestPage(data) {
    const version = ++kerpPageRequestVersion;
    if (kerpPageRequestPending) kerpPageRequestPending.abort();
    kerpPageRequestPending = $.post(ajax_url, data).done(function(response) {
        if (version === kerpPageRequestVersion) change_panel_html(response);
    }).fail(function(xhr, reason) {
        if (reason !== 'abort' && version === kerpPageRequestVersion) {
            NioApp.Toast('دریافت صفحه انجام نشد؛ دوباره تلاش کنید.', 'danger', {position: 'top-right'});
        }
    });
    return kerpPageRequestPending;
}

function request_panel_page_content($url) {
    show_loading_modal();
    const data = {action: 'erp_request_page_content', page: String($url || '')};
    kerpRequestPage(data);
}

function read_file(data) {
    let workbook,
        rowObject;
    workbook = XLSX.read(data, {
        type: 'binary',
    });
    workbook.SheetNames.forEach(sheet => {
        rowObject = XLSX.utils.sheet_to_row_object_array(
            workbook.Sheets[sheet],
        );
    });
    return rowObject;
}

function chunk(items, size) {
    const chunks = [];
    items = [].concat(...items);
    while (items.length) {
        chunks.push(
            items.splice(0, size),
        );
    }
    return chunks;
}

function sendAjaxData(chunked, counter, progress, action, maxParts, btn) {
    let data = {
        'action': action,
        'data':   chunked[counter],
    };
    $.ajax({
        url:      ajax_url,
        type:     'post',
        dataType: 'json',
        data:     data,
        success:  function() {
            counter++;
            progress.width(counter / maxParts * 100 + '%');
            if (counter >= maxParts) {
                btn.html(
                    '<span>اتمام عملیات</span>');
                NioApp.Toast('ایمپورت به پایان رسید', 'success',
                    {position: 'top-right'});
                ajax_search = false;
            } else {
                btn.html(
                    '<span class="spinner-border spinner-border-sm"></span><span>در حال ایمپورت...</span>');
                sendAjaxData(chunked, counter, progress, action, maxParts,
                    btn);
            }
        },
    });
}

function showRequiredError($field) {
    let $group = $field.closest('.form-group');
    let label = $group.find('.form-label');
    if (!label.length) {
        label = 'این فیلد';
    } else {
        label = label.get(0).innerText.trim();
    }
    const $pane = $field.closest('.tab-pane[id]');
    if ($pane.length) {
        change_panel_html({status: 'error', validation_pane: $pane.attr('id'), message: label + ' ضروری است'});
        return;
    }
    NioApp.Toast(label + ' ضروری است', 'error',
        {position: 'top-right'});
}

function getFieldLabel($field) {
    let $row = $field.closest('.meta-field-row');
    let label = $row.find('.form-label').first().text().trim();
    
    if (label) {
        return label;
    }
    
    label = $field.closest('td').closest('tr').find('th').first().text().trim();
    
    if (label) {
        return label;
    }
    
    return $field.data('for') || $field.attr('name') || 'مورد';
}

function setNestedValue(obj, path, value) {
    let keys = path.replace(/\]/g, '').split('['); // meta[national_id] => ['meta','national_id']
    
    let ref = obj;
    keys.forEach(function(key, index) {
        if (index === keys.length - 1) {
            ref[key] = value;
        } else {
            if (!ref[key] || typeof ref[key] !== 'object') {
                ref[key] = {};
            }
            ref = ref[key];
        }
    });
}

function getNestedValue(obj, path) {
    let keys = path.replace(/\]/g, '').split('[');
    let ref = obj;
    
    for (let i = 0; i < keys.length; i++) {
        if (ref == null || typeof ref !== 'object') {
            return undefined;
        }
        ref = ref[keys[i]];
    }
    return ref;
}

function getFieldValueByMeta(metaKey, $scope) {
    let $el = $scope && $scope.length ? $scope.find('[data-for="' + metaKey + '"]') : $('[data-for="' + metaKey + '"]');
    if (!$el.length) {
        return null;
    }
    
    let tag = ($el.prop('tagName') || '').toLowerCase();
    let type = ($el.attr('type') || '').toLowerCase();
    
    if (tag === 'select') {
        return $el.val();
    }
    if (tag === 'textarea') {
        return $el.val();
    }
    if (type === 'checkbox') {
        return $el.is(':checked') ? '1' : '0';
    }
    return $el.val();
}

function matchCondition(actual, expected, operator) {
    let isArray = Array.isArray(expected);
    let isMatch = isArray ? expected.indexOf(actual) !== -1 : (actual === expected);
    return (operator === '!=') ? !isMatch : isMatch;
}

function parseExpected(jsonStr) {
    try {
        let parsed = JSON.parse(jsonStr);
        if (Array.isArray(parsed)) {
            return parsed.map(function(v) { return (v === null || v === undefined) ? '' : String(v); });
        }
        return (parsed === null || parsed === undefined) ? '' : String(parsed);
    } catch (e) {
        return jsonStr;
    }
}

function evaluateVisibilityForRow($row) {
    let isConditional = $row.data('conditional') === 1 || $row.data('conditional') === '1';
    if (!isConditional) {
        return; // always visible
    }
    let condMeta = $row.data('cond-meta') || '';
    let operator = $row.data('cond-operator') || '==';
    let expectedRaw = $row.attr('data-cond-expected') || '';
    
    let expected = parseExpected(expectedRaw);
    // Stage-button repeaters use the same field names in multiple stage modals.
    let actual = getFieldValueByMeta(condMeta, $row.closest('form[data-action="leads_save_stage_actions"]'));
    if (actual === null || actual === undefined) {
        actual = '';
    } else {
        actual = String(actual);
    }
    
    let ok = matchCondition(actual, expected, operator);
    $row.toggleClass('d-none', !ok);
}

function evaluateAll($scope) {
    let $rows;
    if ($scope && $scope.length) {
        $rows = $scope.closest('form').find('.meta-field-row');
    } else {
        $rows = $('.meta-field-row');
    }
    $rows.each(function() {
        evaluateVisibilityForRow($(this));
    });
}

function buildNeedsHtml(needFields, itemsCount, actionLabel) {
    if (!needFields || !needFields.length) {
        return `<div class="text-center py-2">آیا از اجرای «${actionLabel}» برای ${itemsCount} مورد مطمئن هستید؟</div>`;
    }
    const blocks = needFields.map(f => {
        const id = `swal_need_${f.key || f.name || Math.random().toString(36).slice(2)}`;
        const label = f.label || '';
        const wrapStart = `<div class="form-group"><label class="form-label" for="${id}">${label}</label><div class="form-control-wrap">`;
        const wrapEnd = `</div></div>`;
        if (f.type === 'select') {
            let options = f.options || [];
            if (!Array.isArray(options)) {
                options = Object.entries(options).map(function(entry) {
                    return {
                        value: entry[0],
                        label: entry[1],
                    };
                });
            }
            let opts = '';
            if (f.placeholder) {
                opts += `<option value="">${f.placeholder}</option>`;
            }
            opts += options.map(function(option) {
                const value = typeof option === 'object' ? (option.value ?? option.id ?? option.key ?? '') : option;
                const title = typeof option === 'object'
                              ? (option.label ?? option.text ?? option.title ?? value)
                              : option;
                const selected = typeof f.value !== 'undefined' && f.value !== null && String(f.value) === String(value)
                                 ? ' selected'
                                 : '';
                return `<option value="${String(value).replace(/"/g, '&quot;')}"${selected}>${title}</option>`;
            }).join('');
            return `${wrapStart}<select id="${id}" class="form-select" data-key="${f.key}">${opts}</select>${wrapEnd}`;
        }
        if (f.type === 'textarea') {
            const val = (f.value ?? '');
            return `${wrapStart}<textarea id="${id}" class="form-control" data-key="${f.key}">${String(
                val).replace(/"/g, '&quot;')}</textarea>${wrapEnd}`;
        }
        const extraClass = (f.type === 'date') ? ' datepicker' : (f.type === 'price' ? ' price_input' : '');
        const inputMode = f.type === 'price' ? ' inputmode="numeric"' : '';
        const placeholder = f.placeholder ? ` placeholder="${String(f.placeholder).replace(/"/g, '&quot;')}"` : '';
        const val = (f.value ?? '');
        return `${wrapStart}<input type="text" id="${id}" class="form-control${extraClass}" data-key="${f.key}"${inputMode}${placeholder} value="${String(
            val).replace(/"/g, '&quot;')}">${wrapEnd}`;
    });
    return blocks.join('');
}

function collectNeedsValues(needFields) {
    const vals = {};
    (needFields || []).forEach(f => {
        if (f.type === 'modal') {
            return;
        }
        const $inp = $(`.swal2-container [data-key="${f.key}"]`);
        if ($inp.length) {
            vals[f.key] = $inp.val();
        }
    });
    return vals;
}

function request_city_list(state_id, city_id = 0, target = '') {
    let city = $(target);
    let data = {
        action:   'kasebi_load_city_list',
        state_id: state_id,
        city_id:  city_id,
    };
    $.post(ajax_url, data, function(response) {
        city.html(response.list);
        NioApp.Select2(target);
        if (city_id) {
            $(target).val(city_id).trigger('change');
        }
        request_city = true;
    });
}

function activate_dragula(context = document) {
    if (typeof dragula === 'undefined') {
        return;
    }
    
    $(context).find('.dragula-item').each(function() {
        let $item = $(this);
        let $container = $item.parent();
        
        if ($container.data('dragula-active')) {
            return;
        }
        
        $container.data('dragula-active', true);
        
        let drake = dragula([$container[0]], {
            moves: function(el, container, handle) {
                return $(handle).closest('.dragula-handler').length > 0;
            },
        });
        
        drake.on('drop', function(el, target) {
            let $el = $(el);
            
            let action = $el.data('action');
            let itemTarget = $el.data('target');
            let param = $el.data('param');
            
            if (!action || !itemTarget || !param) {
                return;
            }
            
            let ids = [];
            
            $(target).find(itemTarget).each(function() {
                let id = $(this).data('id');
                
                if (id) {
                    ids.push(id);
                }
            });
            
            let data = {
                action: action,
            };
            
            data[param] = ids;
            
            $.post(ajax_url, data, function(response) {
                NioApp.Toast(response.message, response.status, {position: 'top-right'});
            });
        });
    });
}

function kerp_get_select_scope($element) {
    let $table = $element.closest('table');
    
    if ($table.length) {
        return $table;
    }
    
    let $scope = $element.closest(
        '[data-select-scope], form, .card, .nk-block',
    );
    
    return $scope.length ? $scope : $(document);
}

function kerp_get_select_items($selectAll) {
    let target = $selectAll.data('target') || '.select_item_row';
    let $scope = kerp_get_select_scope($selectAll);
    
    return $scope.find(target).filter(':enabled');
}

function kerp_set_row_selected_state($checkbox) {
    $checkbox.closest('tr').toggleClass(
        'is-selected',
        $checkbox.prop('checked'),
    );
}

function kerp_update_select_all_state($scope) {
    $scope.find('.select_all_rows').each(function() {
        let $selectAll = $(this);
        let $items = kerp_get_select_items($selectAll);
        let total = $items.length;
        let selected = $items.filter(':checked').length;
        
        $selectAll.prop(
            'checked',
            total > 0 && selected === total,
        ).prop(
            'indeterminate',
            selected > 0 && selected < total,
        );
    });
}

function kerp_handle_select_all_rows($selectAll) {
    let $items = kerp_get_select_items($selectAll);
    let checked = $selectAll.prop('checked');
    
    $selectAll.prop('indeterminate', false);
    
    $items.prop('checked', checked);
    
    $items.each(function() {
        kerp_set_row_selected_state(
            $(this),
        );
    });
    
    $items.trigger(
        'kerp:row-selection-change',
        [checked],
    );
}

function kerp_handle_select_item_row($item) {
    let $scope = kerp_get_select_scope($item);
    
    kerp_set_row_selected_state($item);
    kerp_update_select_all_state($scope);
    
    $item.trigger(
        'kerp:row-selection-change',
        [$item.prop('checked')],
    );
}

function normalizeSelectPopulateValue($field, value) {
    if (!$field.prop('multiple')) {
        return value ?? '';
    }
    
    if (Array.isArray(value)) {
        return value.map(String);
    }
    
    if (value === null || value === undefined || value === '') {
        return [];
    }
    
    if (typeof value === 'string') {
        let trimmedValue = value.trim();
        
        if (
            trimmedValue.startsWith('[') &&
            trimmedValue.endsWith(']')
        ) {
            try {
                let parsedValue = JSON.parse(trimmedValue);
                
                if (Array.isArray(parsedValue)) {
                    return parsedValue.map(String);
                }
            } catch (error) {
                // ادامه بده و مقدار را comma-separated در نظر بگیر.
            }
        }
        
        return trimmedValue.split(',').map(function(item) {
            return item.trim();
        }).filter(Boolean).map(String);
    }
    
    if (typeof value === 'object') {
        return Object.values(value).map(String);
    }
    
    return [String(value)];
}

// Clone the server-rendered main-plugin component for live monetary previews.
function kerp_price_html(value, currency) {
    const amount = Number(value);
    if (value === null || value === '' || !Number.isFinite(amount)) return '—';
    const data = window.KERPPriceData || {};
    const $price = $('<span>').html(amount === 0 ? data.zero_template : data.template);
    if (!$price.find('.final_price .price_number').length) {
        return $('<span>').text(amount.toLocaleString('en-US') + ' ' + (currency || data.currency || '')).html();
    }
    $price.find('.final_price .price_number').text(amount === 0 ? '-' : (Math.sign(amount) * Math.round(Math.abs(amount))).toLocaleString('en-US'));
    if (currency) $price.find('.currency').text(currency);
    return $price.html();
}
function kerp_price_update($target, value, currency) {
    $target.attr('data-price-value', value).html(kerp_price_html(value, currency));
}



/* ===== init.js ===== */
NioApp.ClassBody = function() {
    NioApp.AddInBody(_sidebar);
};
NioApp.ClassNavMenu = function() {
    NioApp.BreakClass('.' + _header_menu, _break.lg, {
        timeOut: 0,
    });
    NioApp.BreakClass('.' + _sidebar, _break.lg, {
        timeOut:  0,
        classAdd: _sidebar_mob,
    });
    $win.on('resize', function() {
        NioApp.BreakClass('.' + _header_menu, _break.lg);
        NioApp.BreakClass('.' + _sidebar, _break.lg, {
            classAdd: _sidebar_mob,
        });
    });
};
NioApp.Prettify = function() {
    window.prettyPrint && prettyPrint();
};
NioApp.Copied = function() {
    // This initializer also runs after AJAX navigation; keep one delegated listener.
    if (NioApp.kerpClipboard) NioApp.kerpClipboard.destroy();
    var clip   = '.clipboard-init',
        target = '.clipboard-text',
        sclass = 'clipboard-success',
        eclass = 'clipboard-error';
    
    // Feedback
    function feedback(el, state) {
        var $elm = $(el),
            $elp = $elm.parent(),
            copy = {
                text: 'کپی',
                done: 'کپی شد',
                fail: 'ناموفق',
            },
            data = {
                text: $elm.data('clip-text'),
                done: $elm.data('clip-success'),
                fail: $elm.data('clip-error'),
            };
        copy.text = data.text ? data.text : copy.text;
        copy.done = data.done ? data.done : copy.done;
        copy.fail = data.fail ? data.fail : copy.fail;
        var copytext = state === 'success' ? copy.done : copy.fail,
            addclass = state === 'success' ? sclass : eclass;
        clearTimeout($elm.data('kerp-copy-timer'));
        $elp.removeClass(sclass + ' ' + eclass).addClass(addclass);
        $elm.find(target).text(copytext);
        $elm.data('kerp-copy-timer', setTimeout(function() {
            $elp.removeClass(sclass + ' ' + eclass);
            $elm.find(target).text(copy.text);
        }, 2000));
    }
    
    if (ClipboardJS.isSupported()) {
        var clipboard = new ClipboardJS(clip, {
            action: function(trigger) {
                // Bootstrap keeps focus inside the modal. Its temporary copy field must be there too.
                clipboard.container = trigger.closest('.modal') || document.body;
                return trigger.getAttribute('data-clipboard-action') || 'copy';
            },
        });
        NioApp.kerpClipboard = clipboard;
        clipboard.on('success', function(e) {
            feedback(e.trigger, 'success');
            e.clearSelection();
        }).on('error', function(e) {
            feedback(e.trigger, 'error');
        });
    } else {
        $(clip).css('display', 'none');
    }
};
NioApp.StickyNav = function() {
    var elem = document.querySelectorAll('.' + _header);
    if (elem.length > 0) {
        elem.forEach(function(item) {
            var _item_offset = 30;
            if (window.scrollY > _item_offset) {
                item.classList.add('has-fixed');
            } else {
                item.classList.remove('has-fixed');
            }
        });
    }
};
NioApp.StickyNav.init = function() {
    NioApp.StickyNav();
    window.addEventListener('scroll', function() {
        NioApp.StickyNav();
    });
};
NioApp.CurrentLink = function() {
    var _link       = '.nk-menu-link, .menu-link, .nav-link',
        _currentURL = window.location.href,
        fileName    = _currentURL.substring(0,
            _currentURL.indexOf('#') == -1 ? _currentURL.length : _currentURL.indexOf('#'));
    fileName = fileName.substring(0, fileName.indexOf('?') == -1 ? fileName.length : fileName.indexOf('?'));
    $(_link).each(function() {
        var self       = $(this),
            _self_link = self.attr('href');
        if (fileName.match(_self_link)) {
            self.closest('li').addClass('active current-page').parents().closest('li').addClass('active current-page');
            self.closest('li').children('.nk-menu-sub').css('display', 'block');
            self.parents().closest('li').children('.nk-menu-sub').css('display', 'block');
            this.scrollIntoView({
                block: 'start',
            });
            $('.nk-menu-switch').parent().removeClass('active');
            $('.' + _menu_content).removeClass(_menu_active);
            var _closest_content = self.closest('.' + _menu_content).data('content');
            self.closest('.' + _menu_content).addClass(_menu_active);
            $('[data-target=' + _closest_content + ']').parent().addClass('active');
        } else {
            self.closest('li').
                removeClass('active current-page').
                parents().
                closest('li:not(.current-page)').
                removeClass('active');
        }
    });
};
// PasswordSwitch @v1.0
NioApp.PassSwitch = function() {
    NioApp.Passcode('.passcode-switch');
};

// Toastr Message @v1.0
NioApp.Toast = function(msg, ttype, opt) {
    var ttype = ttype ? ttype : 'info',
        msi   = '',
        ticon = ttype === 'info' ? 'ni ni-info-fill' : ttype ===
                                                       'success'
                                                       ? 'ni ni-check-circle-fill'
                                                       : ttype === 'error'
                                                         ? 'ni ni-cross-circle-fill'
                                                         : ttype === 'warning' ? 'ni ni-alert-fill' : '',
        def   = {
            position: 'bottom-right',
            ui:       '',
            icon:     'auto',
            clear:    false,
        },
        attr  = opt ? extend(def, opt) : def;
    attr.position = attr.position
                    ? 'toast-' + attr.position
                    : 'toast-bottom-right';
    attr.icon = attr.icon === 'auto' ? ticon : attr.icon
                                               ? attr.icon
                                               : '';
    attr.ui = attr.ui ? ' ' + attr.ui : '';
    msi = attr.icon !== ''
          ? '<span class="toastr-icon"><em class="icon ' + attr.icon +
              '"></em></span>'
          : '', msg = msg !== '' ? msi + '<div class="toastr-text">' + msg +
        '</div>' : '';
    if (msg !== '') {
        if (attr.clear === true) {
            toastr.clear();
        }
        var option = {
            'closeButton':       true,
            'debug':             false,
            'newestOnTop':       false,
            'progressBar':       false,
            'positionClass':     attr.position + attr.ui,
            'closeHtml':         '<span class="btn-trigger">Close</span>',
            'preventDuplicates': true,
            'showDuration':      '1500',
            'hideDuration':      '1500',
            'timeOut':           '2000',
            'toastClass':        'toastr',
            'extendedTimeOut':   '3000',
        };
        toastr.options = extend(option, attr);
        toastr[ttype](msg);
    }
};

// Toggle Screen @v1.0
NioApp.TGL.screen = function(elm) {
    if ($(elm).exists()) {
        $(elm).each(function() {
            var ssize = $(this).data('toggle-screen');
            if (ssize) {
                $(this).addClass('toggle-screen-' + ssize);
            }
        });
    }
};

// Toggle Content @v1.0
NioApp.TGL.content = function(elm, opt) {
    var toggle        = elm ? elm : '.toggle',
        $toggle       = $(toggle),
        $contentD     = $('[data-content]'),
        toggleBreak   = true,
        toggleCurrent = false,
        def           = {
            active:  'active',
            content: 'content-active',
            'break': toggleBreak,
        },
        attr          = opt ? extend(def, opt) : def;
    NioApp.TGL.screen($contentD);
    $toggle.on('click', function(e) {
        toggleCurrent = this;
        NioApp.Toggle.trigger($(this).data('target'), attr);
        e.preventDefault();
    });
    $doc.on('mouseup', function(e) {
        if (toggleCurrent) {
            var $toggleCurrent  = $(toggleCurrent),
                currentTarget   = $(toggleCurrent).data('target'),
                $contentCurrent = $(
                    '[data-content="'.concat(currentTarget, '"]')),
                $dpd            = $('.datepicker-dropdown'),
                $tpc            = $('.ui-timepicker-container');
            if (!$toggleCurrent.is(e.target) &&
                $toggleCurrent.has(e.target).length === 0 &&
                !$contentCurrent.is(e.target) &&
                $contentCurrent.has(e.target).length === 0 &&
                $(e.target).closest('.select2-container').length === 0 &&
                !$dpd.is(e.target) &&
                $dpd.has(e.target).length === 0 && !$tpc.is(e.target) &&
                $tpc.has(e.target).length === 0) {
                NioApp.Toggle.removed($toggleCurrent.data('target'), attr);
                toggleCurrent = false;
            }
        }
    });
    $win.on('resize', function() {
        $contentD.each(function() {
            var content     = $(this).data('content'),
                ssize       = $(this).data('toggle-screen'),
                toggleBreak = _break[ssize];
            if (NioApp.Win.width > toggleBreak) {
                NioApp.Toggle.removed(content, attr);
            }
        });
    });
};

// ToggleExpand @v1.0
NioApp.TGL.expand = function(elm, opt) {
    var toggle = elm ? elm : '.expand',
        def    = {
            toggle: true,
        },
        attr   = opt ? extend(def, opt) : def;
    $(toggle).on('click', function(e) {
        NioApp.Toggle.trigger($(this).data('target'), attr);
        e.preventDefault();
    });
};

// Dropdown Menu @v1.0
NioApp.TGL.ddmenu = function(elm, opt) {
    var imenu = elm ? elm : '.nk-menu-toggle',
        def   = {
            active: 'active',
            self:   'nk-menu-toggle',
            child:  'nk-menu-sub',
        },
        attr  = opt ? extend(def, opt) : def;
    $(imenu).on('click', function(e) {
        if (NioApp.Win.width < _break.lg ||
            $(this).parents().hasClass(_sidebar)) {
            NioApp.Toggle.dropMenu($(this), attr);
        }
        e.preventDefault();
    });
};

// Show Menu @v1.0
NioApp.TGL.showmenu = function(elm, opt) {
    var toggle      = elm ? elm : '.nk-nav-toggle',
        $toggle     = $(toggle),
        $contentD   = $('[data-content]'),
        toggleBreak = $contentD.hasClass(_header_menu)
                      ? _break.lg
                      : _break.xl,
        toggleOlay  = _sidebar + '-overlay',
        toggleClose = {
            profile: true,
            menu:    false,
        },
        def         = {
            active:  'toggle-active',
            content: _sidebar + '-active',
            body:    'nav-shown',
            overlay: toggleOlay,
            'break': toggleBreak,
            close:   toggleClose,
        },
        attr        = opt ? extend(def, opt) : def;
    $toggle.on('click', function(e) {
        NioApp.Toggle.trigger($(this).data('target'), attr);
        e.preventDefault();
    });
    $doc.on('mouseup', function(e) {
        
        if ($(e.target).closest('[data-content]').length) {
            return;
        }
        if ($(e.target).closest(toggle).length) {
            return;
        }
        
        if (NioApp.Win.width < toggleBreak) {
            NioApp.Toggle.removed($toggle.data('target'), attr);
        }
    });
    $win.on('resize', function() {
        if (NioApp.Win.width < _break.xl || NioApp.Win.width <
            toggleBreak) {
            NioApp.Toggle.removed($toggle.data('target'), attr);
        }
    });
};
NioApp.menuSwitch = function() {
    var $toggle  = $('.' + _menu_switch),
        $content = $('.' + _menu_content);
    $toggle.on('click', function(e) {
        var $self     = $(this),
            _target   = $self.data('target'),
            $dContent = $('[data-content=' + _target + ']');
        $toggle.parent().removeClass('active');
        $self.parent().addClass('active');
        $content.removeClass(_menu_active);
        $dContent.addClass(_menu_active);
        e.preventDefault();
    });
};
// Animate FormSearch @v1.0
NioApp.Ani.formSearch = function(elm, opt) {
    const attr = Object.assign({active: 'active', target: '[data-search]'}, opt || {});
    const close = function($panel) {
        if (!$panel.hasClass(attr.active)) return;
        const name = $panel.attr('data-search');
        const $toggles = $(elm).filter(function() { return $(this).attr('data-target') === name; });
        $panel.add($toggles).removeClass(attr.active);
        $toggles.attr('aria-expanded', 'false');
        $panel.trigger('kerp:search-closed');
    };
    // AJAX initialization must replace handlers instead of toggling twice on the next click.
    $(elm).off('click.kerpFormSearch').on('click.kerpFormSearch', function(e) {
        e.preventDefault();
        const name = $(this).attr('data-target');
        const $panel = $(attr.target).filter(function() { return $(this).attr('data-search') === name; });
        const $toggles = $(elm).filter(function() { return $(this).attr('data-target') === name; });
        if ($panel.hasClass(attr.active)) {
            close($panel);
            $toggles.filter('.search-toggle').trigger('focus');
        } else {
            $panel.add($toggles).addClass(attr.active);
            $toggles.attr('aria-expanded', 'true');
            $panel.find('input').first().trigger('focus');
        }
    });
    $doc.off('.kerpFormSearch').on('keyup.kerpFormSearch mouseup.kerpFormSearch', function(e) {
        if (e.type === 'keyup' && e.key !== 'Escape') return;
        $(attr.target + '.' + attr.active).each(function() {
            const $panel = $(this);
            const name = $panel.attr('data-search');
            const $toggles = $(elm).filter(function() { return $(this).attr('data-target') === name; });
            if (e.type === 'mouseup' && ($panel.is(e.target) || $panel.has(e.target).length || $toggles.is(e.target) || $toggles.has(e.target).length)) return;
            close($panel);
            if (e.key === 'Escape') $toggles.filter('.search-toggle').trigger('focus');
        });
    });
};

// Animate FormElement @v1.0
NioApp.Ani.formElm = function(elm, opt) {
    var def  = {
            focus: 'focused',
        },
        attr = opt ? extend(def, opt) : def;
    if ($(elm).exists()) {
        $(elm).each(function() {
            var $self = $(this);
            if ($self.val()) {
                $self.parent().addClass(attr.focus);
            }
            $self.on({
                focus: function focus() {
                    $self.parent().addClass(attr.focus);
                },
                blur:  function blur() {
                    if (!$self.val()) {
                        $self.parent().removeClass(attr.focus);
                    }
                },
            });
        });
    }
};

// Form Validate @v1.0
NioApp.Validate = function(elm, opt) {
    if ($(elm).exists()) {
        $(elm).each(function() {
            var def  = {
                    errorElement: 'span',
                },
                attr = opt ? extend(def, opt) : def;
            $(this).validate(attr);
        });
        NioApp.Validate.OnChange('.js-select2');
        NioApp.Validate.OnChange('.date-picker');
        NioApp.Validate.OnChange('.js-tagify');
    }
};

//On change validation for third party plugins
NioApp.Validate.OnChange = function(elm) {
    $(elm).on('change', function() {
        $(this).valid();
    });
};
NioApp.Validate.init = function() {
    NioApp.Validate('.form-validate', {
        errorElement:   'span',
        errorClass:     'invalid',
        errorPlacement: function errorPlacement(error, element) {
            if (element.parents().hasClass('input-group')) {
                error.appendTo(element.parent().parent());
            } else {
                error.appendTo(element.parent());
            }
        },
    });
};

// Dropzone @v1.1
NioApp.Dropzone = function(elm, opt) {
    if ($(elm).exists()) {
        $(elm).each(function() {
            var maxFiles = $(elm).data('max-files'),
                maxFiles = maxFiles ? maxFiles : null;
            var maxFileSize = $(elm).data('max-file-size'),
                maxFileSize = maxFileSize ? maxFileSize : 256;
            var acceptedFiles = $(elm).data('accepted-files'),
                acceptedFiles = acceptedFiles ? acceptedFiles : null;
            var def  = {
                    autoDiscover:  false,
                    maxFiles:      maxFiles,
                    maxFilesize:   maxFileSize,
                    acceptedFiles: acceptedFiles,
                },
                attr = opt ? extend(def, opt) : def;
            $(this).addClass('dropzone').dropzone(attr);
        });
    }
};
/*
 NioApp.Dropzone.init = function () {
 $('.upload-zone').each(function () {
 const el = this
 const $el = $(el)
 const maxFiles = parseInt($el.attr('data-max-files')) || 1
 const target = $el.attr('data-target')
 const urlsStr = ($el.attr('data-urls') || '').trim()
 const idsStr = ($el.attr('data-ids') || '').trim()
 let isInitializing = true
 
 let dz = NioApp.Dropzone(el, {
 url:            ajax_url,
 addRemoveLinks: true,
 maxFiles:       maxFiles,
 accept:         function (file, done) {
 const nameData = $el.attr('data-name')
 if (nameData) {
 let modal = Swal.mixin({
 title:             'عنوان فایل',
 html:              '<div class="form-group">' +
 '<label class="form-label" for="attachment_title">عنوان فایل</label>' +
 '<div class="form-control-wrap">' +
 '<input class="form-control" id="attachment_title">' +
 '</div>' +
 '</div>',
 focusConfirm:      false,
 showCancelButton:  true,
 confirmButtonText: 'آپلود کن',
 cancelButtonText:  `لغو`,
 preConfirm:        () => {
 return $('#attachment_title').val()
 },
 })
 modal.fire().then(function (result) {
 console.log(result.value)
 if (result.isConfirmed && result.value) {
 file.custom_filename = result.value // ذخیره روی فایل
 done()
 } else {
 done('عنوان فایل وارد نشده است')
 }
 })
 } else {
 done()
 }
 },
 sending:        function (file, xhr, formData) {
 formData.append('action', $el.attr('data-action'))
 if (file.custom_filename) {
 formData.append('file_name', file.custom_filename)
 }
 },
 success:        function (file, response) {
 file._uploaded_url = response.attachment
 let $target = $(target)
 let currentVal = $target.val().trim()
 let urls = currentVal ? currentVal.split(',') : []
 urls.push(response.attachment)
 if (urls.length > maxFiles) {
 urls = urls.slice(urls.length - maxFiles)
 }
 
 $target.val(urls.join(','))
 if (!isInitializing) {
 $target.trigger('change')
 }
 },
 removedfile:    function (file) {
 let uploadedUrl = file._uploaded_url
 let $target = $(target)
 let currentVal = $target.val().trim()
 let urls = currentVal ? currentVal.split(',') : []
 
 urls = urls.filter(function (url) {
 return url !== uploadedUrl
 })
 
 $target.val(urls.join(','))
 if (!isInitializing) {
 $target.trigger('change')
 }
 
 // حذف ظاهری فایل از UI
 if (file.previewElement) {
 file.previewElement.remove()
 }
 
 },
 })
 console.log(dz)
 const urls = urlsStr.split(',').map(u => u.trim()).filter(Boolean)
 isInitializing = false // بعد از مقداردهی اولیه
 if (urls.length) {
 urls.forEach((url, index) => {
 const mockFile = {
 name: url.split('/').pop(),
 size: 123456,
 }
 dz.emit('addedfile', mockFile)
 dz.emit('thumbnail', mockFile, url)
 dz.emit('complete', mockFile)
 mockFile.previewElement.classList.add('dz-success', 'dz-complete')
 })
 }
 })
 }
 */
NioApp.Dropzone.init = function() {
    if (window.Dropzone && Dropzone.autoDiscover) {
        Dropzone.autoDiscover = false;
    }
    
    $('.upload-zone').each(function() {
        const el = this;
        const $el = $(el);
        if (el.dropzone || $el.data('kerp-dropzone-initialized')) {
            return;
        }
        const maxFiles = parseInt($el.attr('data-max-files')) || 1;
        const acceptedFiles = $el.attr('data-accepted-files') || null;
        const target = $el.attr('data-target');
        const $target = $(target);
        const urlsStr = ($el.attr('data-urls') || '').trim();
        let isInitializing = true;
        const cropImgEl = document.getElementById('canvas_image');
        let cropModal = $('#cropModal');
        
        $el.addClass('dropzone');
        
        const dz = new Dropzone(el, {
            url:            ajax_url,
            addRemoveLinks: true,
            maxFiles:       maxFiles,
            acceptedFiles:  acceptedFiles,
            transformFile(file, done) {
                const canCrop = $el.attr('data-crop');
                if (!canCrop) {
                    done(file);
                    return;
                }
                if (!file.type || !file.type.startsWith('image/')) {
                    done(file);
                    return;
                }
                let cropper,
                    croppedFile;
                let base = $el.parents('.modal');
                const reader = new FileReader();
                reader.onload = function(e) {
                    cropModal.modal('show');
                    base.modal('hide');
                    cropImgEl.style.maxWidth = '100%';
                    cropImgEl.style.width = '100%';
                    cropImgEl.style.display = 'block';
                    cropImgEl.src = e.target.result;
                    
                    croppedFile = null;
                    if (cropper) {
                        cropper.destroy();
                        cropper = null;
                    }
                    
                    cropper = new Cropper(cropImgEl, {
                        aspectRatio: 1,
                        viewMode:    2,
                    });
                    
                    $('#doCrop').off('click').on('click', function() {
                        const canvas = cropper.getCroppedCanvas({
                            width:                 500,
                            height:                500,
                            imageSmoothingEnabled: true,
                            imageSmoothingQuality: 'high',
                        });
                        
                        canvas.toBlob(function(blob) {
                            croppedFile = new File([blob], file.name, {type: blob.type || file.type});
                            const thumbUrl = URL.createObjectURL(blob);
                            if (file.previewElement) {
                                const img = file.previewElement.querySelector('[data-dz-thumbnail]');
                                if (img) {
                                    img.src = thumbUrl;
                                }
                            }
                            cropModal.modal('hide');
                            base.modal('show');
                            done(croppedFile);
                        }, file.type || 'image/jpeg', 0.92);
                    });
                    
                    cropModal.off('hidden.bs.modal').on('hidden.bs.modal', function() {
                        if (cropper) {
                            cropper.destroy();
                            cropper = null;
                        }
                        if (!croppedFile) {
                            dz.removeFile(file);
                        }
                        base.modal('show');
                    });
                };
                reader.readAsDataURL(file);
            },
            
            accept(file, done) {
                const nameData = $el.attr('data-name');
                if (!nameData) {
                    return done();
                }
                
                const modal = Swal.mixin({
                    title:             'عنوان فایل',
                    html:
                                       '<div class="form-group">' +
                                           '  <label class="form-label" for="attachment_title">عنوان فایل</label>' +
                                           '  <div class="form-control-wrap">' +
                                           '    <input class="form-control" id="attachment_title">' +
                                           '  </div>' +
                                           '</div>',
                    focusConfirm:      false,
                    showCancelButton:  true,
                    confirmButtonText: 'آپلود کن',
                    cancelButtonText:  'لغو',
                    preConfirm:        () => $('#attachment_title').val(),
                });
                
                modal.fire().then(res => {
                    if (res.isConfirmed && res.value) {
                        file.custom_filename = res.value;
                        done();
                    } else {
                        done('عنوان فایل وارد نشده است');
                    }
                });
            },
            
            sending(file, xhr, formData) {
                formData.append('action', $el.attr('data-action'));
                if (['tickets_save', 'kerp_tickets_save'].includes($el.attr('data-action'))) {
                    const form = $el.closest('form');
                    formData.append('operation', 'upload');
                    ['ticket_id', 'tickets_nonce'].forEach(function (key) { formData.append(key, form.find('[name="' + key + '"], [data-for="' + key + '"]').first().val() || ''); });
                }
                if (['payments_upload', 'cheques_upload', 'cheques_upload_sample'].includes($el.attr('data-action'))) { formData.append('payment_nonce', $el.closest('.modal_form').find('[data-for="payment_nonce"]').val() || ''); }
                if ($el.attr('data-action') === 'marketing_upload') { ['marketing_nonce', 'id', 'version'].forEach(function(key) { formData.append(key, $el.closest('.modal_form').find('[data-for="' + key + '"]').val() || ''); }); }
                if (file.custom_filename) {
                    formData.append('file_name', file.custom_filename);
                }
            },
            
            success(file, response) {
                // اگر سرور متن برگرداند، تلاش برای پارس
                let resp = response;
                if (typeof resp === 'string') {
                    try { resp = JSON.parse(resp); } catch (e) {}
                }

                if (['tickets_save', 'kerp_tickets_save'].includes($el.attr('data-action'))) {
                    if (resp && resp.code === 'ticket_nonce_expired' && resp.tickets_nonce && !file._ticketNonceRetried) {
                        file._ticketNonceRetried = true;
                        $el.closest('form').find('[name="tickets_nonce"], [data-for="tickets_nonce"]').val(resp.tickets_nonce).attr('value', resp.tickets_nonce);
                        file.status = Dropzone.ADDED;
                        this.enqueueFile(file);
                        return;
                    }
                    if (!resp || resp.status !== 'success' || !resp.token) {
                        file.status = Dropzone.ERROR;
                        this.emit('error', file, resp && resp.message || 'آپلود ناموفق بود.');
                        return;
                    }
                    file._ticket_token = resp.token;
                }
                const uploadedUrl = (resp && (resp.attachment || resp.url || resp.file_url)) || '';
                
                file._uploaded_url = uploadedUrl;
                
                let urls = ($target.val().trim() ? $target.val().split(',') : []);
                if (uploadedUrl) {
                    urls.push(uploadedUrl);
                }
                
                if (urls.length > maxFiles) {
                    urls = urls.slice(urls.length - maxFiles);
                }
                
                $target.val(urls.join(','));
                if (!isInitializing) {
                    $target.trigger('change');
                }
            },
            
            removedfile(file) {
                const uploadedUrl = file._uploaded_url;
                let urls = ($target.val().trim() ? $target.val().split(',') : []);
                if (uploadedUrl) {
                    urls = urls.filter(u => u !== uploadedUrl);
                }
                
                $target.val(urls.join(','));
                if (!isInitializing) {
                    $target.trigger('change');
                }
                
                if (file.previewElement) {
                    file.previewElement.remove();
                }
            },
        });
        
        $el.data('kerp-dropzone-initialized', true);

        // --- لود اولیه از data-urls + پر کردن target ---
        const urls = urlsStr.split(',').map(u => u.trim()).filter(Boolean);
        if (urls.length) {
            const initial = maxFiles ? urls.slice(-maxFiles) : urls;
            // پر کردن ورودی هدف
            $target.val(initial.join(','));
            // ساخت پیش‌نمایش‌ها
            initial.forEach(url => {
                const mockFile = {
                    name:          url.split('/').pop(),
                    size:          123456,
                    _uploaded_url: url, // برای حذف درست
                };
                dz.emit('addedfile', mockFile);
                dz.emit('thumbnail', mockFile, url);
                dz.emit('complete', mockFile);
                if (mockFile.previewElement) {
                    mockFile.previewElement.classList.add('dz-success', 'dz-complete');
                }
            });
        }
        
        isInitializing = false;
    });
};

// Wizard @v1.0
NioApp.Wizard = function() {
    var $wizard = $('.nk-wizard');
    if ($wizard.exists()) {
        $wizard.each(function() {
            var $self    = $(this),
                _self_id = $self.attr('id'),
                $self_id = $('#' + _self_id).show();
            $self_id.steps({
                headerTag:      '.nk-wizard-head',
                bodyTag:        '.nk-wizard-content',
                labels:         {
                    finish:   'ارسال',
                    next:     'بعدی',
                    previous: 'قبلی',
                    loading:  'در حال بارگذاری ...',
                },
                titleTemplate:  '<span class="number">0#index#</span> #title#',
                onStepChanging: function onStepChanging(
                    event, currentIndex, newIndex) {
                    // Allways allow previous action even if the current
                    // form is not valid!
                    if (currentIndex > newIndex) {
                        return true;
                    }
                    // Needed in some cases if the user went back (clean up)
                    if (currentIndex < newIndex) {
                        // To remove error styles
                        $self_id.find(
                                '.body:eq(' + newIndex + ') label.error').
                            remove();
                        $self_id.find('.body:eq(' + newIndex + ') .error').
                            removeClass('error');
                    }
                    $self_id.validate().settings.ignore = ':disabled,:hidden';
                    return $self_id.valid();
                },
                onFinishing:    function onFinishing(event, currentIndex) {
                    $self_id.validate().settings.ignore = ':disabled';
                    return $self_id.valid();
                },
                onFinished:     function onFinished(event, currentIndex) {
                    window.location.href = '#';
                },
            }).validate({
                errorElement:   'span',
                errorClass:     'invalid',
                errorPlacement: function errorPlacement(error, element) {
                    error.appendTo(element.parent());
                },
            });
        });
    }
};

// DataTable @1.1
NioApp.DataTable = function(elm, opt) {
    if ($(elm).exists()) {
        $(elm).each(function() {
            var auto_responsive = $(this).data('auto-responsive'),
                has_export      = typeof opt.buttons !== 'undefined' &&
                                  opt.buttons
                                  ? true
                                  : false;
            var export_title = $(this).data('export-title') ? $(this).
                data('export-title') : 'Export';
            var btn     = has_export
                          ? '<"dt-export-buttons d-flex align-center"<"dt-export-title d-none d-md-inline-block">B>'
                          : '',
                btn_cls = has_export ? ' with-export' : '';
            var dom_normal = '<"row justify-between g-2' + btn_cls +
                '"<"col-7 col-sm-4 text-start"f><"col-5 col-sm-8 text-end"<"datatable-filter"<"d-flex justify-content-end g-2"' +
                btn +
                'l>>>><"datatable-wrap my-3"t><"row align-items-center"<"col-7 col-sm-12 col-md-9"p><"col-5 col-sm-12 col-md-3 text-start text-md-end"i>>';
            var dom_separate = '<"row justify-between g-2' + btn_cls +
                '"<"col-7 col-sm-4 text-start"f><"col-5 col-sm-8 text-end"<"datatable-filter"<"d-flex justify-content-end g-2"' +
                btn +
                'l>>>><"my-3"t><"row align-items-center"<"col-7 col-sm-12 col-md-9"p><"col-5 col-sm-12 col-md-3 text-start text-md-end"i>>';
            var dom = $(this).hasClass('is-separate')
                      ? dom_separate
                      : dom_normal;
            var def  = {
                    responsive: true,
                    autoWidth:  false,
                    dom:        dom,
                    language:   {
                        search:            '',
                        searchPlaceholder: 'برای جستجو تایپ کنید',
                        lengthMenu:        '<span class=\'d-none d-sm-inline-block\'>نمایش</span><div class=\'form-control-select\'> _MENU_ </div>',
                        info:              '_START_ -_END_ از _TOTAL_',
                        infoEmpty:         '0',
                        infoFiltered:      '( کل _MAX_  )',
                        paginate:          {
                            'first':    'اول',
                            'last':     'آخر',
                            'next':     'بعدی',
                            'previous': 'قبلی',
                        },
                    },
                },
                attr = opt ? extend(def, opt) : def;
            attr = auto_responsive === false ? extend(attr, {
                responsive: false,
            }) : attr;
            $(this).DataTable(attr);
            $('.dt-export-title').text(export_title);
        });
    }
};

// DataTable Init @v1.0
NioApp.DataTable.init = function() {
    NioApp.DataTable('.datatable-init', {
        responsive: {
            details: true,
        },
    });
    NioApp.DataTable('.datatable-init-export', {
        responsive: {
            details: true,
        },
        buttons:    ['copy', 'excel', 'csv', 'pdf'],
    });
    $.fn.DataTable.ext.pager.numbers_length = 7;
};

// BootStrap Extended
NioApp.BS.ddfix = function(elm, exc) {
    var dd = elm ? elm : '.dropdown-menu',
        ex = exc
             ? exc
             : 'a:not(.clickable), button:not(.clickable), a:not(.clickable) *, button:not(.clickable) *';
    $(dd).on('click', function(e) {
        if (!$(e.target).is(ex)) {
            // e.stopPropagation();
            return;
        }
    });
    if (NioApp.State.isRTL) {
        var $dMenu = $('.dropdown-menu');
        $dMenu.each(function() {
            var $self = $(this);
            if ($self.hasClass('dropdown-menu-end') &&
                !$self.hasClass('dropdown-menu-center')) {
                $self.prev('[data-bs-toggle="dropdown"]').dropdown({
                    popperConfig: {
                        placement: 'bottom-start',
                    },
                });
            } else if (!$self.hasClass('dropdown-menu-end') &&
                !$self.hasClass('dropdown-menu-center')) {
                $self.prev('[data-bs-toggle="dropdown"]').dropdown({
                    popperConfig: {
                        placement: 'bottom-end',
                    },
                });
            }
        });
    }
};

// BootStrap Specific Tab Open
NioApp.BS.tabfix = function(elm) {
    var tab = elm ? elm : '[data-bs-toggle="modal"]';
    $(tab).on('click', function() {
        var _this       = $(this),
            target      = _this.data('target'),
            target_href = _this.attr('href'),
            tg_tab      = _this.data('tab-target');
        var modal = target ? $body.find(target) : $body.find(
            target_href);
        if (tg_tab && tg_tab !== '#' && modal) {
            modal.find('[href="' + tg_tab + '"]').tab('show');
        } else if (modal) {
            var tabdef = modal.find('.nk-nav.nav-tabs');
            var link = $(tabdef[0]).find('[data-bs-toggle="tab"]');
            $(link[0]).tab('show');
        }
    });
};

// Dark Mode Switch @since v2.0
NioApp.ModeSwitch = function() {
    var toggle = $('.dark-switch');
    if ($body.hasClass('dark-mode')) {
        toggle.addClass('active');
    } else {
        toggle.removeClass('active');
    }
    toggle.on('click', function(e) {
        e.preventDefault();
        $(this).toggleClass('active');
        $body.toggleClass('dark-mode');
    });
};

// Knob @v1.0
NioApp.Knob = function(elm, opt) {
    if ($(elm).exists() && typeof $.fn.knob === 'function') {
        var def  = {
                min: 0,
            },
            attr = opt ? extend(def, opt) : def;
        $(elm).each(function() {
            $(this).knob(attr);
        });
    }
};
// Knob Init @v1.0
NioApp.Knob.init = function() {
    var knob = {
        'default': {
            readOnly: true,
            lineCap:  'round',
        },
        half:      {
            angleOffset: -90,
            angleArc:    180,
            readOnly:    true,
            lineCap:     'round',
        },
    };
    NioApp.Knob('.knob', knob['default']);
    NioApp.Knob('.knob-half', knob.half);
};

// Range @v1.0.1
NioApp.Range = function(elm, opt) {
    if ($(elm).exists() && typeof noUiSlider !== 'undefined') {
        $(elm).each(function() {
            var $self   = $(this),
                self_id = $self.attr('id');
            var _start        = $self.data('start'),
                _start        = /\s/g.test(_start)
                                ? _start.split(' ')
                                : _start,
                _start        = _start ? _start : 0,
                _connect      = $self.data('connect'),
                _connect      = /\s/g.test(_connect)
                                ? _connect.split(' ')
                                : _connect,
                _connect      = typeof _connect == 'undefined'
                                ? 'lower'
                                : _connect,
                _min          = $self.data('min'),
                _min          = _min ? _min : 0,
                _max          = $self.data('max'),
                _max          = _max ? _max : 100,
                _min_distance = $self.data('min-distance'),
                _min_distance = _min_distance ? _min_distance : null,
                _max_distance = $self.data('max-distance'),
                _max_distance = _max_distance ? _max_distance : null,
                _step         = $self.data('step'),
                _step         = _step ? _step : 1,
                _orientation  = $self.data('orientation'),
                _orientation  = _orientation ? _orientation : 'horizontal',
                _tooltip      = $self.data('tooltip'),
                _tooltip      = _tooltip ? _tooltip : false;
            console.log(_tooltip);
            var target = document.getElementById(self_id);
            var def  = {
                    start:       _start,
                    connect:     _connect,
                    direction:   NioApp.State.isRTL ? 'rtl' : 'ltr',
                    range:       {
                        'min': _min,
                        'max': _max,
                    },
                    margin:      _min_distance,
                    limit:       _max_distance,
                    step:        _step,
                    orientation: _orientation,
                    tooltips:    _tooltip,
                },
                attr = opt ? extend(def, opt) : def;
            noUiSlider.create(target, attr);
        });
    }
};

// Range Init @v1.0
NioApp.Range.init = function() {
    NioApp.Range('.form-control-slider');
    NioApp.Range('.form-range-slider');
};
NioApp.Select2.init = function() {
    NioApp.Select2('.js-select2');
};

// Slick Slider @v1.0.1
NioApp.Slick = function(elm, opt) {
    if ($(elm).exists() && typeof $.fn.slick === 'function') {
        $(elm).each(function() {
            var def  = {
                    'prevArrow': '<div class="slick-arrow-prev"><a href="javascript:void(0);" class="slick-prev"><em class="icon ni ni-chevron-left"></em></a></div>',
                    'nextArrow': '<div class="slick-arrow-next"><a href="javascript:void(0);" class="slick-next"><em class="icon ni ni-chevron-right"></em></a></div>',
                    rtl:         NioApp.State.isRTL,
                },
                attr = opt ? extend(def, opt) : def;
            $(this).slick(attr);
        });
    }
};

// Slick Init @v1.0
NioApp.Slider.init = function() {
    NioApp.Slick('.slider-init');
};

// Magnific Popup @v1.0.0
NioApp.Lightbox = function(elm, type, opt) {
    if ($(elm).exists()) {
        $(elm).each(function() {
            var def = {};
            if (type == 'video' || type == 'iframe') {
                def = {
                    type:            'iframe',
                    removalDelay:    160,
                    preloader:       true,
                    fixedContentPos: false,
                    callbacks:       {
                        beforeOpen: function beforeOpen() {
                            this.st.image.markup = this.st.image.markup.replace(
                                'mfp-figure',
                                'mfp-figure mfp-with-anim');
                            this.st.mainClass = this.st.el.attr(
                                'data-effect');
                        },
                    },
                };
            } else if (type == 'content') {
                def = {
                    type:         'inline',
                    preloader:    true,
                    removalDelay: 400,
                    mainClass:    'mfp-fade content-popup',
                };
            } else {
                def = {
                    type:      'image',
                    mainClass: 'mfp-fade image-popup',
                };
            }
            var attr = opt ? extend(def, opt) : def;
            $(this).magnificPopup(attr);
        });
    }
};

// Controls @v1.0.0
NioApp.Control = function(elm) {
    var control = document.querySelectorAll(elm);
    control.forEach(function(item, index, arr) {
        item.checked ? item.parentNode.classList.add('checked') : null;
        item.addEventListener('change', function() {
            if (item.type == 'checkbox') {
                item.checked
                ? item.parentNode.classList.add('checked')
                : item.parentNode.classList.remove(
                    'checked');
            }
            if (item.type == 'radio') {
                document.querySelectorAll(
                        'input[name="' + item.name + '"]').
                    forEach(function(item, index, arr) {
                        item.parentNode.classList.remove('checked');
                    });
                item.checked
                ? item.parentNode.classList.add('checked')
                : null;
            }
        });
    });
};

// Number Spinner @v1.0
NioApp.NumberSpinner = function(elm, opt) {
    var plus = document.querySelectorAll('[data-number=\'plus\']');
    var minus = document.querySelectorAll('[data-number=\'minus\']');
    plus.forEach(function(item, index, arr) {
        var parent = plus[index].parentNode;
        plus[index].addEventListener('click', function() {
            var child = plus[index].parentNode.children;
            child.forEach(function(item, index, arr) {
                if (child[index].classList.contains('number-spinner')) {
                    var value = !child[index].value == '' ? parseInt(
                        child[index].value) : 0;
                    var step = !child[index].step == ''
                               ? parseInt(child[index].step)
                               : 1;
                    var max = !child[index].max == ''
                              ? parseInt(child[index].max)
                              : Infinity;
                    if (max + 1 > value + step) {
                        child[index].value = value + step;
                    } else {
                        child[index].value = value;
                    }
                }
            });
        });
    });
    minus.forEach(function(item, index, arr) {
        var parent = minus[index].parentNode;
        minus[index].addEventListener('click', function() {
            var child = minus[index].parentNode.children;
            child.forEach(function(item, index, arr) {
                if (child[index].classList.contains('number-spinner')) {
                    var value = !child[index].value == '' ? parseInt(
                        child[index].value) : 0;
                    var step = !child[index].step == ''
                               ? parseInt(child[index].step)
                               : 1;
                    var min = !child[index].min == ''
                              ? parseInt(child[index].min)
                              : 0;
                    if (min - 1 < value - step) {
                        child[index].value = value - step;
                    } else {
                        child[index].value = value;
                    }
                }
            });
        });
    });
};

// Stepper @v1.0
NioApp.Stepper = function(elm, opt) {
    var element = document.querySelectorAll(elm);
    if (element.length > 0) {
        element.forEach(function(item, index) {
            var def  = {
                    selectors:    {
                        nav:      'stepper-nav',
                        progress: 'stepper-progress',
                        content:  'stepper-steps',
                        prev:     'step-prev',
                        next:     'step-next',
                        submit:   'step-submit',
                    },
                    classes:      {
                        nav_current: 'current',
                        nav_done:    'done',
                        step_active: 'active',
                        step_done:   'done',
                        active_step: 'active',
                    },
                    current_step: 1,
                },
                attr = opt ? extend(def, opt) : def;
            NioApp.Custom.Stepper(item, attr);
            NioApp.Validate.OnChange('.js-select2');
            NioApp.Validate.OnChange('.date-picker');
            NioApp.Validate.OnChange('.js-tagify');
        });
    }
};
// Stepper Init @v1.0
NioApp.Stepper.init = function() {
    NioApp.Stepper('.stepper-init');
};

// Tagify @v1.0.1
NioApp.Tagify = function(elm, opt) {
    if ($(elm).exists() && typeof $.fn.tagify === 'function') {
        var def,
            attr = opt ? extend(def, opt) : def;
        $(elm).tagify(attr);
    }
};
// Tagify Init @v1.0
NioApp.Tagify.init = function() {
    NioApp.Tagify('.js-tagify');
};

/* Isotope - Filter @v1.0 */
NioApp.Filter = function(elem, childSelector) {
    var qsRegex;
    var elm = document.querySelectorAll(elem);
    elm.forEach(function(item) {
        if (typeof item != 'undefined' && item != null) {
            var iso = new Isotope(item, {
                itemSelector: childSelector,
                layoutMode:   'fitRows',
                filter:       function filter(itemElem) {
                    return qsRegex
                           ? itemElem.textContent.match(qsRegex)
                           : true;
                },
                hiddenStyle:  {
                    opacity:   0,
                    transform: 'scale(0.001)',
                },
                visibleStyle: {
                    opacity:   1,
                    transform: 'scale(1)',
                },
            });
            var filterBtn = document.querySelectorAll('[data-filter]');
            console.log();
            filterBtn.forEach(function(btnItem) {
                btnItem.addEventListener('click', function(event) {
                    // only work with buttons
                    if (!matchesSelector(event.target, 'button')) {
                        return;
                    }
                    var filterValue = event.target.getAttribute(
                        'data-filter');
                    iso.arrange({
                        filter: filterValue,
                    });
                    filterBtn.forEach(function(allButtons) {
                        allButtons.classList.remove('active');
                    });
                    btnItem.classList.add('active');
                });
            });
        }
    });
};

// Extra @v1.1
NioApp.OtherInit = function() {
    NioApp.ClassBody();
    NioApp.PassSwitch();
    NioApp.LinkOff('.is-disable');
    NioApp.ClassNavMenu();
    NioApp.menuSwitch();
    NioApp.SetHW('[data-height]', 'height');
    NioApp.SetHW('[data-width]', 'width');
    NioApp.NumberSpinner();
    NioApp.Lightbox('.popup-video', 'video');
    NioApp.Lightbox('.popup-iframe', 'iframe');
    NioApp.Lightbox('.popup-image', 'image');
    NioApp.Lightbox('.popup-content', 'content');
    NioApp.Control('.custom-control-input');
    NioApp.Filter('.filter-container', '.filter-item');
};

// Animate Init @v1.0
NioApp.Ani.init = function() {
    NioApp.Ani.formElm('.form-control-outlined');
    NioApp.Ani.formSearch('.toggle-search');
};

// BootstrapExtend Init @v1.0
NioApp.BS.init = function() {
    NioApp.BS.menutip('a.nk-menu-link');
    NioApp.BS.tooltip('.nk-tooltip');
    NioApp.BS.tooltip('.btn-tooltip', {
        placement: 'top',
    });
    NioApp.BS.tooltip('[data-toggle="tooltip"]');
    NioApp.BS.tooltip('[data-bs-toggle="tooltip"]');
    NioApp.BS.tooltip('.tipinfo,.nk-menu-tooltip', {
        placement: 'right',
    });
    NioApp.BS.popover('[data-toggle="popover"]');
    NioApp.BS.popover('[data-bs-toggle="popover"]');
    NioApp.BS.progress('[data-progress]');
    NioApp.BS.fileinput('.form-file-input');
    NioApp.BS.modalfix();
    NioApp.BS.ddfix();
    NioApp.BS.tabfix();
};

// Picker Init @v1.0
NioApp.Picker.init = function() {
    NioApp.Picker.date('.date-picker');
    NioApp.Picker.dob('.date-picker-alt');
    NioApp.Picker.time('.time-picker', {
        timeFormat: 'HH:mm',
    });
    NioApp.Picker.date('.date-picker-range', {
        todayHighlight: false,
        autoclose:      false,
    });
    NioApp.Picker.date('.date-picker-ym', {
        format:      'yy/mm',
        startView:   2,
        autoclose:   true,
        maxViewMode: 2,
        minViewMode: 1,
    });
};

// Addons @v1
NioApp.Addons.Init = function() {
    NioApp.Knob.init();
    NioApp.Range.init();
    NioApp.Select2.init();
    NioApp.Dropzone.init();
    NioApp.Slider.init();
    NioApp.DataTable.init();
    NioApp.Tagify.init();
};

// Toggler @v1
NioApp.TGL.init = function() {
    NioApp.TGL.content('.toggle');
    NioApp.TGL.expand('.toggle-expand');
    NioApp.TGL.expand('.toggle-opt', {
        toggle: false,
    });
    NioApp.TGL.showmenu('.nk-nav-toggle');
    NioApp.TGL.ddmenu('.' + _menu + '-toggle', {
        self:  _menu + '-toggle',
        child: _menu + '-sub',
    });
};
NioApp.BS.modalOnInit = function() {
    $('.modal').on('shown.bs.modal', function() {
        NioApp.Select2.init();
        NioApp.Validate.init();
    });
};
NioApp.Quill = function() {
    
    function initQuill(el, toolbarOptions, isMinimal) {
        
        let $el = $(el);
        if (el.__quill || $el.data('quill') || $el.children('.ql-container').length) {
            return el.__quill || $el.data('quill');
        }
        
        // 🧠 گرفتن مقدار اولیه از hidden textarea
        let initialValue = $el.find('.quill-value').val() || '';
        
        let quill = new Quill(el, {
            modules: {
                toolbar: toolbarOptions,
            },
            theme:   'snow',
        });
        el.__quill = quill;
        $el.data('quill', quill);
        
        // ✅ set initial value
        if (initialValue) {
            quill.root.innerHTML = initialValue;
        }
        
        // 🔥 sync to data-for
        quill.on('text-change', function() {
            let html = quill.root.innerHTML;
            
            // update hidden value
            $el.find('.quill-value').val(html);
            
            // update system bridge
            $el.attr('data-value', html);
        });
        
        return quill;
    }
    
    // FULL
    var _basic = '.quill-basic';
    if ($(_basic).exists()) {
        $(_basic).each(function() {
            
            var toolbarOptions = [
                ['bold', 'italic', 'underline', 'strike'],
                ['blockquote', 'code-block'],
                [{'list': 'ordered'}, {'list': 'bullet'}],
                [{'script': 'sub'}, {'script': 'super'}],
                [{'indent': '-1'}, {'indent': '+1'}],
                [{'header': [1, 2, 3, 4, 5, 6]}],
                [{'color': []}, {'background': []}],
                [{'align': []}],
                ['clean'],
            ];
            
            initQuill(this, toolbarOptions, false);
        });
    }
    
    // MINIMAL
    var _minimal = '.quill-minimal';
    if ($(_minimal).exists()) {
        $(_minimal).each(function() {
            
            var toolbarOptions = [
                ['bold', 'italic', 'underline'],
                ['blockquote', {'list': 'bullet'}],
                [{'align': []}],
                ['clean'],
            ];
            
            initQuill(this, toolbarOptions, true);
        });
    }
};

NioApp.init = function() {
    NioApp.coms.docReady.push(NioApp.OtherInit);
    NioApp.coms.docReady.push(NioApp.Prettify);
    NioApp.coms.docReady.push(NioApp.ColorBG);
    NioApp.coms.docReady.push(NioApp.ColorTXT);
    NioApp.coms.docReady.push(NioApp.Copied);
    NioApp.coms.docReady.push(NioApp.Ani.init);
    NioApp.coms.docReady.push(NioApp.TGL.init);
    NioApp.coms.docReady.push(NioApp.BS.init);
    NioApp.coms.docReady.push(NioApp.Validate.init);
    NioApp.coms.docReady.push(NioApp.Picker.init);
    NioApp.coms.docReady.push(NioApp.Addons.Init);
    NioApp.coms.docReady.push(NioApp.Wizard);
    NioApp.coms.docReady.push(NioApp.Stepper.init);
    NioApp.coms.winLoad.push(NioApp.ModeSwitch);
    NioApp.coms.winLoad.push(NioApp.StickyNav.init);
    NioApp.coms.docReady.push(NioApp.Quill);
    activate_date_pickers();
    add_loading_block();
    activate_dragula();
    activate_charts();
    calc_factor_total($('form.modal_form.kerp-order-form'));
};
NioApp.ajaxInit = function() {
    kerpDashboardLoad();
    NioApp.OtherInit();
    NioApp.Prettify();
    NioApp.ColorBG();
    NioApp.ColorTXT();
    NioApp.Copied();
    NioApp.Ani.init();
    NioApp.TGL.init();
    NioApp.BS.init();
    NioApp.Validate.init();
    NioApp.Picker.init();
    NioApp.Addons.Init();
    kerp_init_ajax_search_selects(document);
    NioApp.Wizard();
    NioApp.ModeSwitch();
    NioApp.Stepper.init();
    NioApp.StickyNav.init();
    NioApp.Quill();
    activate_date_pickers();
    add_loading_block();
    evaluateAll();
    activate_dragula();
    activate_charts();
    calc_factor_total($('form.modal_form.kerp-order-form'));
};

NioApp.init();



/* ===== events.js ===== */
$(document).ajaxSend(function(event, xhr, settings) {
    if (ajax_search || settings.ajax_search === true) {
        return;
    }
    show_loading_modal();
});
$(document).ajaxStop(function() {
    hide_loading_modal();
});
$(document).on('input', '.price_input', function() {
    toEnglishNumber($(this).val(), this);
    
    let input = $(this);
    let hasDecimal = input.data('decimal') == 1;
    let decimalPlaces = parseInt(input.data('decimal-places') || 0, 10);
    let value = String(this.value || '');
    
    value = value.replace(/\u066B/g, '.').replace(/,/g, '');
    
    if (hasDecimal) {
        value = value.replace(/[^0-9.]/g, '');
        
        let dotIndex = value.indexOf('.');
        
        if (dotIndex !== -1) {
            value =
                value.substring(0, dotIndex + 1) +
                value.substring(dotIndex + 1).replace(/\./g, '');
        }
        
        let parts = value.split('.');
        let intPart = parts[0] || '';
        let decimalPart = parts.length > 1
                          ? parts[1]
                          : null;
        
        if (decimalPlaces > 0 && decimalPart !== null) {
            decimalPart = decimalPart.substring(0, decimalPlaces);
        }
        
        if (intPart === '' && decimalPart === null) {
            input.val('');
            return;
        }
        
        if (intPart === '' && decimalPart !== null) {
            intPart = '0';
        }
        
        let formatted = number_format(intPart);
        
        if (decimalPart !== null) {
            formatted += '.' + decimalPart;
        }
        
        input.val(formatted);
        return;
    }
    
    value = value.replace(/\D/g, '');
    
    if (value === '') {
        input.val('');
        return;
    }
    
    input.val(number_format(value));
});
$(document).on('click', '.page_activator', function(e) {
    e.preventDefault();
    request_panel_page_content($(this).attr('data-url'));
});
$(document).on('click', '.kerp-profile-menu-toggle', function(e) {
    e.preventDefault();

    const $toggle  = $(this),
          $item    = $toggle.closest('.has-sub'),
          willOpen = !$item.hasClass('active');

    $item.siblings('.has-sub')
        .removeClass('active')
        .children('.kerp-profile-menu-toggle')
        .attr('aria-expanded', 'false');

    $item.toggleClass('active', willOpen);
    $toggle.attr('aria-expanded', willOpen ? 'true' : 'false');
});
$(window).on('popstate', function() {
    let data = {
        'action': 'erp_request_back_btn',
        'page':   window.location.href,
    };
    kerpRequestPage(data);
});
$(document).on('change', '.datepicker', function() {
    let val = $(this).val();
    if (val === '') {
        $(this).attr('data-value', '');
        $(this).attr('data-gdate', '');
        $(this).attr('data-jdate', '');
    }
});
$(document).on('click', '.pdp-default', function(e) {
    e.stopPropagation();
});
$(document).on('click', 'a.btn-trigger', function(e) {
    e.preventDefault();
});
$(document).on('click', '.select_current_user_for_modal', function() {
    let input = $(this).attr('data-input');
    $('.hide_on_profile').remove();
    $(input).val($(this).attr('data-id'));
});

$(document).on('click', '.delete_db_item', function(e) {
    e.preventDefault();
    
    const $btn = $(this);
    const element = $btn.get(0);
    const data = {};
    
    if (!element) {
        return;
    }
    
    $.each(element.attributes, function() {
        if (!this.name || this.name.indexOf('data-') !== 0) {
            return;
        }
        
        const key = this.name.substring(5).replace(/-/g, '_');
        
        data[key] = this.value;
    });
    
    if (!data.action) {
        return;
    }
    
    Swal.fire({
        title:             'آیا از حذف این مورد اطمینان دارید؟',
        icon:              'warning',
        text:              'این عملیات غیر قابل بازگشت است',
        focusConfirm:      false,
        showCancelButton:  true,
        confirmButtonText: 'بله',
        cancelButtonText:  'خیر',
    }).then((result) => {
        if (!result.isConfirmed) {
            return;
        }
        
        $btn.addClass('disabled');
        
        $.post(ajax_url, data).done(function(response) {
            change_panel_html(response);
        }).always(function() {
            $btn.removeClass('disabled');
        });
    });
});

function apply_populate_field_data($field, data) {
    if (!data || typeof data !== 'object' || Array.isArray(data)) {
        return;
    }
    
    $.each(data, function(key, value) {
        let dataKey = String(key).replace(/_/g, '-');
        
        if (value === null || typeof value === 'undefined') {
            $field.removeAttr('data-' + dataKey);
            $field.removeData(key);
            return;
        }
        
        if (typeof value === 'object') {
            value = JSON.stringify(value);
        } else if (value === true) {
            value = '1';
        } else if (value === false) {
            value = '0';
        }
        
        $field.attr('data-' + dataKey, value);
        
        /*
         * چون jQuery ممکن است data-* را cache کرده باشد،
         * مقدار cache هم آپدیت می‌شود.
         */
        $field.data(key, value);
    });
}

$(document).on('click', '.edit_row_item,.open_populate_modal', function(e) {
    e.preventDefault();
    
    let $btn = $(this);
    let modalId = $btn.attr('data-modal');
    let populate = $btn.attr('data-populate');
    let $modal = $(modalId);
    
    if (!$modal.length) {
        return;
    }
    
    if (populate) {
        try {
            populate = JSON.parse(populate);
        } catch (err) {
            console.error(
                'Invalid data-populate JSON:',
                err,
                populate,
            );
            
            populate = {};
        }
        
        $.each(populate, function(key, field) {
            if (!field || !field.id) {
                return;
            }
            
            let $field = $modal.find(field.id);
            
            if (!$field.length) {
                $field = $(field.id);
            }
            
            if (!$field.length) {
                return;
            }
            
            /*
             * data باید قبل از change روی فیلد قرار بگیرد.
             */
            apply_populate_field_data(
                $field,
                field.data,
            );
            
            let value = field.value ?? '';
            let type = field.type ?? $field.attr('type') ?? '';
            
            if (
                type === 'switch' ||
                type === 'checkbox'
            ) {
                let isChecked =
                        value === true ||
                        value === 1 ||
                        value === '1' ||
                        value === 'true';
                
                $field.prop('checked', isChecked).trigger('change');
                
                return;
            }
            
            if (type === 'radio') {
                $modal.find(
                    'input[name="' +
                    $field.attr('name') +
                    '"][value="' +
                    value +
                    '"]',
                ).prop('checked', true).trigger('change');
                
                return;
            }
            
            if (type === 'learndash-search') {
                kerp_set_learndash_picker_value($field, value, field.label || '');
                return;
            }
            
            if (
                type === 'select' ||
                type === 'select2' ||
                $field.is('select')
            ) {
                
                let selectValue = normalizeSelectPopulateValue(
                    $field,
                    value,
                );
                
                $field.val(selectValue).trigger('change');
                
                return;
            }
            
            if (type === 'quill') {
                let quillEl = $field.get(0);
                
                if (
                    quillEl &&
                    quillEl.__quill
                ) {
                    quillEl.__quill.root.innerHTML = value || '';
                } else {
                    $field.html(value || '');
                }
                
                return;
            }
            if (type === 'customer-search') {
                let name =
                        $field.attr('data-customer-name') ||
                        $btn.attr('data-customer-name') ||
                        '';
                
                let phone =
                        $field.attr('data-customer-phone') ||
                        $btn.attr('data-customer-phone') ||
                        '';
                
                kerp_set_customer_picker_value(
                    $field,
                    value,
                    name,
                    phone,
                );
                
                return;
            }
            if (type === 'html') {
                $field.html(value);
                
                return;
            }
            
            if (type === 'text') {
                $field.val(value);
                
                return;
            }
            
            if (type === 'no_change') {
                $field.val(value).prop('readonly', true).prop('disabled', false).attr(
                    'data-readonly-on-edit',
                    '1',
                );
                
                return;
            }
            
            if (type === 'upload') {
                let urls = String(value || '').split(',').map(function(url) {
                    return url.trim();
                }).filter(Boolean);
                
                let $uploadZone = $modal.find(
                    '.upload-zone[data-target="' +
                    field.id +
                    '"]',
                );
                
                let uploadZone = $uploadZone.first()[0];
                
                let dropzone =
                        uploadZone &&
                        uploadZone.dropzone
                        ? uploadZone.dropzone
                        : null;
                
                if (dropzone) {
                    dropzone.removeAllFiles(true);
                    
                    urls.forEach(function(url) {
                        let mockFile = {
                            name:          url.split('/').pop(),
                            size:          123456,
                            _uploaded_url: url,
                        };
                        
                        dropzone.emit(
                            'addedfile',
                            mockFile,
                        );
                        
                        dropzone.emit(
                            'thumbnail',
                            mockFile,
                            url,
                        );
                        
                        dropzone.emit(
                            'complete',
                            mockFile,
                        );
                        
                        if (mockFile.previewElement) {
                            mockFile.previewElement.classList.add(
                                'dz-success',
                                'dz-complete',
                            );
                        }
                    });
                }
                
                $field.val(urls.join(',')).trigger('change');
                
                return;
            }
            
            $field.val(value).trigger('change');
        });
    }
    
    const modalTitle = $btn.attr('data-modal-title');
    if (modalTitle) {
        $modal.find('.modal-title').first().text(modalTitle);
    }
    const submitText = $btn.attr('data-submit-text');
    if (submitText) {
        $modal.find('.submit_modal_form').first().text(submitText);
    }
    $modal.modal('show');
});
$(document).on('hidden.bs.modal', '.modal', function() {
    let $modal = $(this);
    
    // Taxonomy trees may contain hundreds of checkboxes. Triggering change on
    // every checkbox makes each event rescan the complete tree. Clear the
    // native select once and let the picker synchronize itself once.
    $modal.find('.kerp-taxonomy-picker').each(function() {
        const select = this.querySelector('.kerp-taxonomy-picker__select');
        const search = this.querySelector('.kerp-taxonomy-picker__search');
        if (!select || select.classList.contains('no_clear')) {
            return;
        }
        if (search && !search.classList.contains('no_clear')) {
            search.value = '';
        }
        select.selectedIndex = -1;
        $(select).trigger('change');
    });
    
    $modal.find(
        'input:not(.kerp-taxonomy-picker__check):not(.kerp-taxonomy-picker__search), textarea, select:not(.kerp-taxonomy-picker__select)',
    ).each(function() {
        let $field = $(this);
        let type = ($field.attr('type') || '').toLowerCase();
        if ($field.hasClass('no_clear')) {
            return;
        }
        if (type === 'checkbox' || type === 'radio') {
            $field.prop('checked', false).trigger('change');
            return;
        }
        
        if ($field.is('select')) {
            $field.val('').trigger('change');
            return;
        }
        
        $field.val('').trigger('change');
    });
    $modal.find('.upload-zone').each(function() {
        if (this.dropzone) {
            this.dropzone.removeAllFiles(true);
        }
    });
    $modal.find('[contenteditable="true"]').each(function() {
        $(this).html('');
    });
    
    $modal.find('.ql-editor').each(function() {
        $(this).html('<p><br></p>');
    });
    
    $modal.find('[data-readonly-on-edit="1"]').each(function() {
        $(this).prop('readonly', false);
        $(this).prop('disabled', false);
    });
});
$(document).on('click', '.add_repeater_row', function(e) {
    e.preventDefault();
    
    let $wrapper = $(this).closest('.repeater_wrapper');
    let $rows = $wrapper.find('.repeater_rows').first();
    let template = $wrapper.find('.repeater_row_template').html();
    if (!template) {
        return;
    }
    
    $rows.find('.add_repeater_row').each(function() {
        let $button = $(this);
        let $row = $button.closest('.repeater_row');
        
        $row.removeClass('repeater_row--new');
        $row.find('.user-avatar .icon').removeClass('ni-plus').addClass('ni-list-check');
        $row.find('.sub-text').text('آیتم ریپیتر');
        
        $button.removeClass('add_repeater_row btn-primary').
            addClass('remove_repeater_row btn-trigger text-danger').
            attr('title', 'حذف ردیف').
            html('<em class="icon ni ni-trash"></em>');
    });
    
    let index = parseInt($wrapper.attr('data-next-index') || '0', 10);
    
    if (!index) {
        index = $rows.find('.repeater_row').length + 1;
    }
    
    template = template.replaceAll('__INDEX__', index);
    $rows.append(template);
    $wrapper.attr('data-next-index', index + 1);
    
    let $newRow = $rows.find('.repeater_row').last();
    
    $newRow.find('input, select, textarea').each(function() {
        let $field = $(this);
        
        if ($field.is(':checkbox') || $field.is(':radio')) {
            $field.prop('checked', false);
            return;
        }
        
        if ($field.attr('type') !== 'hidden') {
            $field.val('');
        }
    });
    NioApp.Select2($newRow.find('.js-select2'));
    kerp_init_ajax_search_selects($newRow);
    evaluateAll($newRow);
});

$(document).on('click', '.remove_repeater_row', function(e) {
    e.preventDefault();
    
    let $row = $(this).closest('.repeater_row');
    let $rows = $row.closest('.repeater_rows');
    
    if ($rows.find('.repeater_row').length <= 1) {
        $row.find('input[type="text"], input[type="number"], input[type="hidden"], input[type="date"], textarea').
            val('');
        $row.find('select').val('').trigger('change');
        $row.find('input[type="checkbox"], input[type="radio"]').prop('checked', false);
        return;
    }
    
    $row.remove();
});

$(document).on('click', '.submit_modal_form', function() {
    let $form = $(this).parents('.modal_form');
    $form.find('.kerp-tab-validation-error').remove();
    let page = $form.attr('data-page') || '';
    
    let data = {
        action: $form.attr('data-action'),
        page:   page,
    };

    if (data.action === 'installments_save_plan') {
        data.active_tab = ($form.find('.kerp-installment-tabs .nav-link.active').attr('href') || '')
            .replace('#installment-pane-', '');
    }
    
    let hasError = false;
    let requiredMap = {}; // key => { fields: [] }
    
    let $inputs = $form.find('input[data-for], select[data-for], textarea[data-for]').filter(function() {
        let $el = $(this);
        if ($form.find('[data-for="registration_mode"]').val() === 'proforma'
            && ($el.attr('data-for') === 'payment_method' || $el.closest('.kerp-payment-receipts').length)) return false;
        if (data.action === 'payments_create_order'
            && $form.find('[data-for="payment_method"]').val() === 'kerp_none'
            && $el.closest('.kerp-payment-receipts').length) return false;
        if (data.action === 'installments_save_plan') {
            const $pane = $el.closest('.tab-pane');
            if ($pane.length && $pane.attr('id') !== 'installment-pane-' + data.active_tab) return false;
        }
        // ❌ hidden via conditional system
        if ($el.closest('.meta-field-row').hasClass('d-none')) {
            return false;
        }
        // hidden fields are included unless their conditional row is hidden.
        if ($el.attr('type') === 'hidden') {
            return true;
        }
        // ❌ disabled fields
        if ($el.is(':disabled')) {
            return false;
        }
        
        return true;
    });
    // ----------------- inputs -----------------
    $inputs.each(function() {
        
        let $field = $(this);
        let key = $field.data('for');
        
        if (!key) {
            return;
        }
        
        if ($field.data('req') == 1) {
            if (!requiredMap[key]) {
                requiredMap[key] = {fields: []};
            }
            requiredMap[key].fields.push($field);
        }
        // checkbox
        if ($field.is(':checkbox')) {
            
            if ($field.is(':checked')) {
                let val = $field.val() || 1;
                
                if (key.includes('[')) {
                    let current = getNestedValue(data, key);
                    if (!Array.isArray(current)) {
                        setNestedValue(data, key, []);
                        current = getNestedValue(data, key);
                    }
                    current.push(val);
                } else {
                    if (!Array.isArray(data[key])) {
                        data[key] = [];
                    }
                    data[key].push(val);
                }
            }
            
            return;
        }
        
        // radio
        if ($field.is(':radio')) {
            
            if ($field.is(':checked')) {
                let val = $field.val();
                
                if (key.includes('[')) {
                    setNestedValue(data, key, val);
                } else {
                    data[key] = val;
                }
            }
            
            return;
        }
        
        let val = $field.val();
        if (key == 'phone') {
            if (!validate_phone_number(val)) {
                NioApp.Toast('شماره تلفن همراه معتبر نیست', 'error',
                    {position: 'top-right'});
                return;
            }
        }
        // ----------------- number validation -----------------
        if ($field.hasClass('number_type')) {
            toEnglishNumber($field.val(), this);
            
            let raw = String(this.value || '').replace(/\D/g, '');
            
            if (raw === '' && String(this.value || '').trim() !== '') {
                NioApp.Toast('مقدار فیلد «' + getFieldLabel($field) + '» باید عددی باشد', 'error', {
                    position: 'top-right',
                });
                
                showRequiredError($field);
                hasError = true;
                return;
            }
            
            val = raw;
        }
        
        // ----------------- date validation -----------------
        if ($field.hasClass('datepicker')) {
            let dateValue = String(val || '').trim();
            
            if (dateValue !== '' && !/^\d{4}-\d{1,2}-\d{1,2}$/.test(dateValue)) {
                NioApp.Toast('فیلد «' + getFieldLabel($field) + '» معتبر نیست', 'error', {
                    position: 'top-right',
                });
                
                showRequiredError($field);
                hasError = true;
                return;
            }
        }
        
        if (key.includes('[')) {
            setNestedValue(data, key, val);
        } else {
            data[key] = val;
        }
        
    });
    
    Object.keys(requiredMap).forEach(function(key) {
        if (hasError) {
            return;
        }
        let value = key.includes('[')
                    ? getNestedValue(data, key)
                    : data[key];
        
        let isEmpty =
                value === undefined ||
                value === null ||
                (Array.isArray(value) && value.length === 0) ||
                (typeof value === 'string' && value.trim() === '');
        
        if (isEmpty) {
            let $firstField = requiredMap[key].fields[0];
            showRequiredError($firstField);
            hasError = true;
        }
    });
    
    // ----------------- quill editors -----------------
    let $quills = $form.find('.quill-basic[data-for]').filter(function() {
        
        let $el = $(this);
        
        // ❌ hidden by conditional system
        if ($el.closest('.meta-field-row').hasClass('d-none')) {
            return false;
        }
        
        return true;
    });
    
    $quills.each(function() {
        
        let $wrapper = $(this);
        let key = $wrapper.data('for');
        
        if (!key) {
            return;
        }
        
        let quillInstance = $wrapper.data('quill');
        let html = '';
        
        if (quillInstance && quillInstance.root) {
            html = quillInstance.root.innerHTML;
        } else {
            html = $wrapper.find('.ql-editor').html() || '';
        }
        
        let textContent = $('<div>').html(html).text().trim();
        
        if ($wrapper.data('req') == 1 && textContent === '') {
            if (!hasError) {
                showRequiredError($wrapper);
            }
            hasError = true;
        }
        
        if (key.includes('[')) {
            setNestedValue(data, key, html);
        } else {
            data[key] = html;
        }
    });
    
    if (hasError) {
        return;
    }
    
    $.post(ajax_url, data, function(response) {
        change_panel_html(response);
    });
});
$(document).on('change input', '[data-for]', function() {
    evaluateAll($(this));
});
$(document).on('select2:select select2:clear', '[data-for]', function() {
    evaluateAll($(this));
});
function kerp_set_header_search(open, restoreFocus) {
    const header = $('.nk-header-search');
    const input = header.find('#header_user_search');
    header.find('.search-wrap').toggleClass('active', open).attr('aria-hidden', String(!open));
    header.find('.search-toggle').toggleClass('active', open).attr('aria-expanded', String(open));
    if (open) {
        input.trigger('focus');
        if ($.trim(input.val())) input.trigger('input');
    } else {
        input.data('search-version', (input.data('search-version') || 0) + 1);
        clearTimeout(input.data('search-timer'));
        if (search_ajax && typeof search_ajax.abort === 'function') search_ajax.abort();
        ajax_search = false;
        input.attr('aria-busy', 'false');
        header.find('.search_result_container').empty().hide();
        if (restoreFocus) header.find('.search-toggle').trigger('focus');
        else input.trigger('blur');
    }
}
$(document).on('click', '.kerp-header-search-toggle', function(e) {
    e.preventDefault();
    const open = !$(this).closest('.nk-header-search').find('.search-wrap').hasClass('active');
    kerp_set_header_search(open, !open);
});
$(document).on('click', '.nk-header-search .search-submit', function() {
    $('#header_user_search').trigger('input');
});
$(document).on('keydown', '#header_user_search', function(e) {
    if (e.key === 'Enter') {
        e.preventDefault();
        $(this).trigger('input');
    }
});
$(document).on('keydown', function(e) {
    if (e.key === 'Escape' && $('.nk-header-search .search-wrap').hasClass('active')) {
        kerp_set_header_search(false, true);
    }
});
$(document).on('click', function(e) {
    if (!$('.nk-header-search .search-wrap').hasClass('active')) return;
    if (!$(e.target).closest('.nk-header-search').length ||
        $(e.target).closest('.nk-header-search .page_activator, .nk-header-search [data-bs-toggle="modal"]').length) {
        kerp_set_header_search(false, false);
    }
});
$(document).on('input', '#header_user_search', function() {
    let input = this;
    let search = $.trim(input.value);
    let result = $(input).closest('.nk-header-search').find('.search_result_container');
    let searchVersion = ($(input).data('search-version') || 0) + 1;
    $(input).data('search-version', searchVersion);
    let isCurrentSearch = function() {
        return $(input).data('search-version') === searchVersion;
    };
    let showSearchError = function() {
        result.html(
            '<div class="card card-stretch m-0"><div class="card-inner p-3 text-danger" role="alert">جستجو انجام نشد. لطفاً دوباره تلاش کنید.</div></div>',
        ).show();
    };
    clearTimeout($(input).data('search-timer'));
    if (search_ajax && typeof search_ajax.abort === 'function') {
        search_ajax.abort();
    }
    ajax_search = false;
    $(input).attr('aria-busy', 'false');
    result.empty().hide();
    if (search === '') {
        return;
    }
    $(input).attr('aria-busy', 'true');
    result.html(
        '<div class="card card-stretch m-0"><div class="card-inner p-3 d-flex align-items-center gap-2" role="status" aria-live="polite">' +
        '<span class="spinner-border spinner-border-sm text-primary" aria-hidden="true"></span>' +
        '<span class="sub-text">در حال جستجو…</span></div></div>',
    ).show();
    $(input).data('search-timer', setTimeout(function() {
        ajax_search = true;
        search_ajax = $.post(ajax_url, {
            action: 'customers_search',
            search: search,
        }, function(response) {
            if (!isCurrentSearch()) {
                return;
            }
            if (response && response.status !== 'error' && typeof response.searchResult === 'string') {
                result.html(response.searchResult).show();
            } else {
                showSearchError();
            }
        }).fail(function(xhr, status) {
            if (status !== 'abort' && isCurrentSearch()) {
                showSearchError();
            }
        }).always(function() {
            if (isCurrentSearch()) {
                ajax_search = false;
                $(input).attr('aria-busy', 'false');
            }
        });
    }, 300));
});

function kerp_get_customer_picker(element) {
    return $(element).closest('.kerp-customer-picker');
}

function kerp_get_customer_picker_placeholder(picker) {
    return '<span class="sub-text">برای انتخاب کاربر، در فیلد روبه‌رو جستجو کنید.</span>';
}

function kerp_build_customer_search_item(customer) {
    let item = $('<div>', {
        class:    'nk-tb-item kerp-customer-picker-result',
        role:     'button',
        tabindex: 0,
    });
    item.attr({
        'data-customer-id':    customer.id || 0,
        'data-customer-name':  customer.name || '',
        'data-customer-phone': customer.phone || '',
    });
    let customerColumn = $('<div>', {
        class: 'nk-tb-col',
    });
    let userCard = $('<div>', {
        class: 'user-card',
    });
    let avatar = $('<div>', {
        class: 'user-avatar xs',
    });
    $('<span>').text((customer.name || '?').substring(0, 1)).appendTo(avatar);
    let userInfo = $('<div>', {
        class: 'user-info',
    });
    $('<span>', {
        class: 'tb-lead',
    }).text(customer.name || '').appendTo(userInfo);
    avatar.appendTo(userCard);
    userInfo.appendTo(userCard);
    userCard.appendTo(customerColumn);
    customerColumn.appendTo(item);
    $('<div>', {
        class: 'nk-tb-col tb-col-md',
    }).append(
        $('<span>').text(customer.phone || ''),
    ).appendTo(item);
    return item;
}

function kerp_render_customer_search_results(picker, customers) {
    let result = picker.find('.kerp-customer-picker-results');
    result.empty();
    if (!customers.length) {
        result.html(
            '<div class="card card-bordered"><div class="card-inner p-3"><span class="sub-text">کاربر پیدا نشد.</span></div></div>',
        ).show();
        return;
    }
    let list = $('<div>', {
        class: 'card card-bordered is-compact nk-tb-list nk-tb-ulist',
    });
    customers.forEach(function(customer) {
        list.append(kerp_build_customer_search_item(customer));
    });
    result.append(list).show();
}

function kerp_search_customer_for_picker(input) {
    let searchInput = $(input);
    let picker = kerp_get_customer_picker(input);
    let result = picker.find('.kerp-customer-picker-results');
    let search = $.trim(searchInput.val());
    let timer = searchInput.data('search-timer');
    let request = picker.data('search-request');
    
    clearTimeout(timer);
    
    if (request && typeof request.abort === 'function') {
        request.abort();
    }
    
    if (search.length < 2) {
        result.empty().hide();
        return;
    }
    
    timer = setTimeout(function() {
        ajax_search = true;
        result.html(
            '<div class="card card-bordered"><div class="card-inner p-3 d-flex align-items-center gap-2" role="status" aria-live="polite"><span class="spinner-border spinner-border-sm text-primary" aria-hidden="true"></span><span class="sub-text">در حال جستجو…</span></div></div>',
        ).show();
        
        request = $.post(ajax_url, {
            action: picker.attr('data-search-action') || 'customers_search',
            search: search,
            limit:  10,
        }, function(response) {
            ajax_search = false;
            let customers = Array.isArray(response.users)
                            ? response.users
                            : [];
            
            kerp_render_customer_search_results(picker, customers);
        }).fail(function(xhr, status) {
            ajax_search = false;
            if (status === 'abort') {
                return;
            }
            
            result.html(
                '<div class="card card-bordered"><div class="card-inner p-3"><span class="text-danger">خطا در جستجوی کاربر.</span></div></div>',
            ).show();
        });
        
        picker.data('search-request', request);
    }, 300);
    
    searchInput.data('search-timer', timer);
}

function kerp_set_customer_picker_value($field, customerId, name, phone) {
    let picker = kerp_get_customer_picker($field);
    let preview = picker.find('.kerp-customer-picker-preview');
    
    customerId = parseInt(customerId || '0', 10);
    name = name || '';
    phone = phone || '';
    
    $field.val(customerId || '').trigger('change');
    
    picker.find('.kerp-customer-picker-search').val('');
    picker.find('.kerp-customer-picker-results').empty().hide();
    
    if (!customerId) {
        preview.html(
            kerp_get_customer_picker_placeholder(picker),
        );
        
        return;
    }
    
    preview.empty();
    
    let wrapper = $('<div>', {
        class: 'd-flex align-center justify-between',
    });
    
    let userCard = $('<div>', {
        class: 'user-card',
    });
    
    let avatar = $('<div>', {
        class: 'user-avatar xs',
    });
    
    $('<span>').text(name.substring(0, 1) || '?').appendTo(avatar);
    
    let userInfo = $('<div>', {
        class: 'user-info',
    });
    
    $('<span>', {
        class: 'tb-lead',
    }).text(name).appendTo(userInfo);
    
    if (phone) {
        $('<span>', {
            class: 'sub-text',
        }).text(phone).appendTo(userInfo);
    }
    
    avatar.appendTo(userCard);
    userInfo.appendTo(userCard);
    userCard.appendTo(wrapper);
    
    if (picker.attr('data-locked') !== '1') {
        $('<button>', {
            type:  'button',
            class: 'btn btn-sm btn-icon btn-trigger kerp-customer-picker-clear',
        }).append(
            $('<em>', {
                class: 'icon ni ni-cross',
            }),
        ).appendTo(wrapper);
    }
    
    preview.append(wrapper);
}

function kerp_select_customer_for_picker(element) {
    let item = $(element);
    let picker = kerp_get_customer_picker(element);
    let field = picker.find('[data-for]').first();
    
    let customerId = parseInt(
        item.attr('data-customer-id') || '0',
        10,
    );
    
    if (!customerId) {
        return;
    }
    
    kerp_set_customer_picker_value(
        field,
        customerId,
        item.attr('data-customer-name') || '',
        item.attr('data-customer-phone') || '',
    );
}

function kerp_clear_customer_picker(element) {
    let picker = kerp_get_customer_picker(element);
    
    if (picker.attr('data-locked') === '1') {
        return;
    }
    
    picker.find('[data-for]').first().val('').trigger('change');
    picker.find('.kerp-customer-picker-search').val('');
    picker.find('.kerp-customer-picker-results').empty().hide();
    picker.find('.kerp-customer-picker-preview').html(
        kerp_get_customer_picker_placeholder(picker),
    );
}

$(document).on('input', '.kerp-customer-picker-search', function() {
    kerp_search_customer_for_picker(this);
});

$(document).on('click', '.kerp-customer-picker-result', function() {
    kerp_select_customer_for_picker(this);
});

$(document).on('keydown', '.kerp-customer-picker-result', function(e) {
    if (e.key !== 'Enter' && e.key !== ' ') {
        return;
    }
    
    e.preventDefault();
    kerp_select_customer_for_picker(this);
});

$(document).on('click', '.kerp-customer-picker-clear', function() {
    kerp_clear_customer_picker(this);
});

$(document).on('click', function(e) {
    if ($(e.target).closest('.kerp-customer-picker').length) {
        return;
    }
    
    $('.kerp-customer-picker-results').empty().hide();
});

function kerp_get_learndash_picker(element) {
    return $(element).closest('.kerp-learndash-picker');
}

function kerp_get_learndash_picker_field(picker, dataFor) {
    dataFor = dataFor || picker.attr('data-for') || '';
    return picker.children('input[type="hidden"][data-for]').filter(function() {
        return $(this).attr('data-for') === dataFor;
    }).first();
}

function kerp_learndash_picker_placeholder() {
    return '<span class="sub-text">برای انتخاب، عنوان را در فیلد روبه‌رو جستجو کنید.</span>';
}

function kerp_set_learndash_picker_value(field, postId, title) {
    let picker = kerp_get_learndash_picker(field);
    let preview = picker.find('.kerp-learndash-picker-preview');
    postId = parseInt(postId || '0', 10);
    field.val(postId || '').trigger('change');
    picker.find('.kerp-learndash-picker-search').val('');
    picker.find('.kerp-learndash-picker-results').empty().hide();
    if (!postId) {
        preview.html(kerp_learndash_picker_placeholder());
        return;
    }
    let wrapper = $('<div>', {class: 'd-flex align-center justify-between'});
    $('<span>', {class: 'tb-lead'}).text(title || ('#' + postId)).appendTo(wrapper);
    $('<button>', {
        type:  'button',
        class: 'btn btn-sm btn-icon btn-trigger kerp-learndash-picker-clear',
        'data-for': field.attr('data-for') || picker.attr('data-for') || '',
    }).
        append($('<em>', {class: 'icon ni ni-cross'})).appendTo(wrapper);
    preview.empty().append(wrapper);
}

function kerp_render_learndash_results(picker, items) {
    let result = picker.find('.kerp-learndash-picker-results').empty();
    if (!items.length) {
        result.html(
                '<div class="card card-bordered"><div class="card-inner p-3"><span class="sub-text">درس یا سرفصلی پیدا نشد.</span></div></div>').
            show();
        return;
    }
    let list = $('<div>', {class: 'card card-bordered is-compact nk-tb-list nk-tb-ulist'});
    items.forEach(function(item) {
        let row = $('<div>', {
            class:    'nk-tb-item kerp-learndash-picker-result',
            role:     'button',
            tabindex: 0,
        });
        row.attr({
            'data-post-id':    item.id || 0,
            'data-post-title': item.text || '',
            'data-for':        picker.attr('data-for') || '',
        });
        $('<div>', {class: 'nk-tb-col'}).append(
            $('<div>', {class: 'user-card'}).append(
                $('<div>', {class: 'user-avatar xs'}).append($('<em>', {class: 'icon ni ni-book-read'})),
                $('<div>', {class: 'user-info'}).append($('<span>', {class: 'tb-lead'}).text(item.text || '')),
            ),
        ).appendTo(row);
        list.append(row);
    });
    result.append(list).show();
}

function kerp_search_learndash_for_picker(input) {
    let searchInput = $(input);
    let picker = kerp_get_learndash_picker(input);
    let result = picker.find('.kerp-learndash-picker-results');
    let search = $.trim(searchInput.val());
    clearTimeout(searchInput.data('search-timer'));
    let previous = picker.data('search-request');
    if (previous && typeof previous.abort === 'function') {
        previous.abort();
    }
    if (search.length < 2) {
        result.empty().hide();
        return;
    }
    searchInput.data('search-timer', setTimeout(function() {
        result.html(
                '<div class="card card-bordered"><div class="card-inner p-3"><span class="spinner-border spinner-border-sm"></span></div></div>').
            show();
        let request = $.post(ajax_url, {
            action: picker.attr('data-search-action') || 'programs_search_learndash_content',
            search: search,
            page:   1,
        });
        picker.data('search-request', request);
        request.done(function(response) {
            let items = response && response.status === 'success' && Array.isArray(response.results)
                        ? response.results
                        : [];
            kerp_render_learndash_results(picker, items);
        }).fail(function(xhr, status) {
            if (status !== 'abort') {
                result.html(
                        '<div class="card card-bordered"><div class="card-inner p-3"><span class="text-danger">خطا در جستجوی محتوای LearnDash.</span></div></div>').
                    show();
            }
        }).always(function() { picker.removeData('search-request'); });
    }, 300));
}

$(document).on('input', '.kerp-learndash-picker-search', function() { kerp_search_learndash_for_picker(this); });
$(document).on('click', '.kerp-learndash-picker-result', function() {
    let item   = $(this),
        picker = kerp_get_learndash_picker(this);
    let field = kerp_get_learndash_picker_field(picker, item.attr('data-for'));
    if (!field.length) return;
    kerp_set_learndash_picker_value(field, item.attr('data-post-id'), item.attr('data-post-title'));
});
$(document).on('keydown', '.kerp-learndash-picker-result', function(e) {
    if (e.key !== 'Enter' && e.key !== ' ') {
        return;
    }
    e.preventDefault();
    $(this).trigger('click');
});
$(document).on('click', '.kerp-learndash-picker-clear', function() {
    let picker = kerp_get_learndash_picker(this);
    let field = kerp_get_learndash_picker_field(picker, $(this).attr('data-for'));
    if (!field.length) return;
    kerp_set_learndash_picker_value(field, 0, '');
});
$(document).on('click', function(e) {
    if (!$(e.target).closest('.kerp-learndash-picker').length) {
        $('.kerp-learndash-picker-results').empty().hide();
    }
});
$(document).on('hidden.bs.modal', '.modal', function() {
    $(this).find('.kerp-learndash-picker').each(function() {
        let picker  = $(this),
            request = picker.data('search-request');
        if (request && typeof request.abort === 'function') {
            request.abort();
        }
        picker.removeData('search-request');
        picker.find('.kerp-learndash-picker-search').val('');
        picker.find('.kerp-learndash-picker-results').empty().hide();
        picker.find('.kerp-learndash-picker-preview').html(kerp_learndash_picker_placeholder());
    });
});
$(document).on('click', '.show_public_content_modal', function(e) {
    e.preventDefault();
    let button = $(this);
    let modal = $('#kerpPublicContentModal');
    let title = button.attr('data-modal-title') || '';
    let contentTarget = button.attr('data-content-target') || '';
    let content = button.attr('data-modal-content') || '';
    
    if (!modal.length) {
        return;
    }
    if (contentTarget && $(contentTarget).length) {
        content = $(contentTarget).html();
    }
    modal.find('.modal-title').text(title);
    modal.find('.kerp-public-modal-content').html(content);
    modal.modal('show');
});

$(document).on('click', '.kerp-review-image-magnify', function(e) {
    e.preventDefault();
    e.stopImmediatePropagation();
    let button = $(this);
    let imageUrl = button.attr('data-image-url') || button.attr('href') || '';
    let imageName = button.attr('data-image-name') || '';
    let isPng = /\.png(?:$|[?#])/i.test(imageUrl) || /\.png$/i.test(imageName);

    if (!imageUrl) {
        return;
    }
    if (!$.magnificPopup || typeof $.magnificPopup.open !== 'function') {
        window.open(imageUrl, '_blank', 'noopener,noreferrer');
        return;
    }

    $.magnificPopup.open({
        items: {src: imageUrl, title: imageName},
        type: 'image',
        mainClass: 'kerp-review-magnifier' + (isPng ? ' kerp-review-magnifier--png' : ''),
        closeOnContentClick: false,
        closeOnBgClick: true,
        image: {
            verticalFit: true,
            titleSrc: function() {
                return imageName;
            }
        },
        callbacks: {
            open: function() {
                $('html, body').addClass('kerp-review-magnifier-open');
            },
            close: function() {
                $('html, body').removeClass('kerp-review-magnifier-open');
            }
        },
        zoom: {
            enabled: true,
            duration: 220,
            opener: function() {
                return button;
            }
        }
    });
});

$(document).on('input', '#kerp-employee-code-prefix', function() {
    let prefix = $('#kerp-employee-code-prefix').val() || '';
    let preview = prefix + '1024';
    
    $('.kerp-employee-code-preview, #kerp-employee-code-preview').text(preview);
});

$(document).on('change', '.load_city', function() {
    let city = $(this).attr('data-city');
    let target = $(this).attr('data-target');
    request_city_list(
        $(this).val(),
        city,
        target,
    );
});

function kerp_normalize_ajax_select_results(response) {
    let items = [];
    
    if (response && Array.isArray(response.results)) {
        items = response.results;
    } else if (response && response.data && Array.isArray(response.data.results)) {
        items = response.data.results;
    } else if (response && Array.isArray(response.data)) {
        items = response.data;
    } else if (response && Array.isArray(response.items)) {
        items = response.items;
    }
    
    return items.map(function(item) {
        if (typeof item !== 'object' || item === null) {
            return {
                id:   item,
                text: item,
            };
        }
        
        return {
            id:   item.id || item.value || '',
            text: item.text || item.label || item.name || item.title || '',
        };
    });
}

function kerp_init_ajax_search_select(element) {
    let select = $(element);
    let action = select.attr('data-action');
    
    if (!action || typeof select.select2 !== 'function') {
        return;
    }
    
    if (select.data('select2')) {
        select.select2('destroy');
    }
    
    let placeholder = select.attr('data-placeholder');
    
    if (!placeholder) {
        placeholder = select.find('option:first').text().trim();
    }
    
    select.select2({
        width:              '100%',
        dir:                'rtl',
        placeholder:        placeholder,
        allowClear:         true,
        minimumInputLength: 2,
        ajax:               {
            url:      ajax_url,
            type:     'POST',
            dataType: 'json',
            delay:    300,
            cache:    true,
            
            beforeSend: function() {
                ajax_search = true;
            },
            
            data: function(params) {
                return {
                    action: action,
                    search: params.term || '',
                    page:   params.page || 1,
                };
            },
            
            processResults: function(response) {
                return {
                    results: kerp_normalize_ajax_select_results(response),
                };
            },
            
            complete: function() {
                ajax_search = false;
            },
        },
    });
}


function kerp_init_installment_plan(scope) {
    let $scope = $(scope);
    let $forms = $scope.find('[data-action="installments_save_plan"]').add($scope.closest('[data-action="installments_save_plan"]'));
    $forms.each(function() {
        const $form = $(this);
        if ($form.data('installmentReady')) {
            $scope.find('.installment-lesson').each(function() { fill($(this), $form.data('installmentLessons'), true); });
            return;
        }
        $form.data('installmentReady', true);
        const $course = $form.find('[data-for="course_id"]');
        const $product = $form.find('[data-for="product_id"]');
        let courseVersion = 0, productVersion = 0;
        let initial = [];
        $form.find('.installment-lesson').first().find('option').each(function() {
            if (this.value !== '') initial.push({id: this.value, text: this.text});
        });
        $form.data('installmentLessons', $course.val() ? initial : null);
        function update(rows, preserve) {
            $form.data('installmentLessons', rows);
            $form.find('.installment-lesson').each(function() { fill($(this), rows, preserve); });
        }
        function request(data) {
            return $.ajax({url: ajax_url, type: 'POST', dataType: 'json', data: Object.assign({
                action: 'installments_plan_options',
                installment_nonce: $form.find('[data-for="installment_nonce"]').val()
            }, data)});
        }
        function failure(message) { NioApp.Toast(message || 'دریافت اطلاعات انجام نشد؛ دوباره انتخاب کنید.', 'error', {position: 'top-right'}); }
        $course.on('change.installments', function(event, automatic) {
            if (!automatic) productVersion++;
            const version = ++courseVersion;
            const id = $course.val();
            update(null, false);
            if (!id) return;
            request({kind: 'course', course_id: id}).done(function(response) {
                if (version !== courseVersion || !$form[0].isConnected) return;
                if (response.status !== 'success') { failure(response.message || response.msg); return; }
                update([{id: '0', text: 'تمام دوره (بدون محدودیت اقساط)'}].concat(response.results || []), false);
            }).fail(function() { if (version === courseVersion && $form[0].isConnected) failure(); });
        });
        $product.on('change.installments', function() {
            const version = ++productVersion;
            const id = $product.val();
            $course.empty().append(new Option('جستجوی نام یا شناسه دوره', '')).val('').trigger('change', [true]);
            if (!id) return;
            request({kind: 'product', product_id: id}).done(function(response) {
                if (version !== productVersion || !$form[0].isConnected) return;
                if (response.status !== 'success') { failure(response.message || response.msg); return; }
                const rows = response.results || [];
                rows.forEach(function(row) { $course.append(new Option(row.text, row.id)); });
                if (rows.length) $course.val(String(rows[0].id)).trigger('change', [true]);
                if (rows.length > 1) NioApp.Toast('محصول چند دوره مرتبط دارد؛ دوره اول انتخاب شد. دوره موردنظر را بررسی کنید.', 'info', {position: 'top-right'});
            }).fail(function() { if (version === productVersion && $form[0].isConnected) failure(); });
        });
    });
    function fill($select, rows, preserve) {
        const previous = preserve ? $select.val() : '';
        $select.empty().append(new Option(rows === null ? 'ابتدا دوره لرن‌دش را انتخاب کنید' : 'انتخاب درس', ''));
        (rows || []).forEach(function(row) { $select.append(new Option(row.text, row.id)); });
        $select.prop('disabled', rows === null).val(previous || '').trigger('change.select2');
    }
}

function kerp_init_ajax_search_selects(scope) {
    kerp_init_installment_plan(scope || document);
    let container = scope ? $(scope) : $(document);
    
    container.find('.select_ajax_search').each(function() {
        kerp_init_ajax_search_select(this);
    });
}

$(document).ready(function() {
    kerp_init_ajax_search_selects(document);
    evaluateAll();
});

function kerp_hide_active_tooltips() {
    const Tooltip = window.bootstrap && window.bootstrap.Tooltip
                    ? window.bootstrap.Tooltip
                    : null;
    const triggers = document.querySelectorAll(
        '[data-bs-toggle="tooltip"], [data-toggle="tooltip"], .nk-tooltip, .btn-tooltip, .tipinfo, .nk-menu-tooltip',
    );
    
    triggers.forEach(function(trigger) {
        if (Tooltip && typeof Tooltip.getInstance === 'function') {
            const instance = Tooltip.getInstance(trigger);
            if (instance && typeof instance.hide === 'function') {
                instance.hide();
            }
        }
        
        trigger.removeAttribute('aria-describedby');
    });
    
    document.querySelectorAll('.tooltip').forEach(function(tooltip) {
        tooltip.remove();
    });
}

$(document).on('show.bs.modal mfpOpen', function() {
    kerp_hide_active_tooltips();
});

$(document).on(
    'click',
    '[data-bs-toggle="tooltip"], [data-toggle="tooltip"], .nk-tooltip, .btn-tooltip, .tipinfo, .nk-menu-tooltip',
    function() {
        kerp_hide_active_tooltips();
    },
);

$(document).on('shown.bs.dropdown shown.bs.modal shown.bs.collapse', function(e) {
    kerp_init_ajax_search_selects(e.target);
});

function kerp_get_load_modal_data(element) {
    let data = {};
    
    $.each(element.attributes, function() {
        if (!this.name || this.name.indexOf('data-') !== 0) {
            return;
        }
        
        if (this.name.indexOf('data-bs-') === 0) {
            return;
        }
        
        let key = this.name.substring(5).replace(/-/g, '_');
        
        if (
            key === 'modal'
            || key === 'target'
            || key === 'modal_title'
            || key === 'response_key'
        ) {
            return;
        }
        
        data[key] = this.value;
    });
    
    return data;
}

function kerp_get_load_modal_target(modal, selector) {
    if (selector) {
        let target = modal.find(selector).first();
        
        if (target.length) {
            return target;
        }
    }
    
    return modal.find('.kerp-dynamic-modal-content').first();
}

function kerp_set_load_modal_loading(target) {
    target.html(
        '<div class="text-center py-5">' +
        '<div class="spinner-border spinner-border-sm" role="status"></div>' +
        '</div>',
    );
}

function kerp_set_load_modal_error(target, message) {
    target.html(
        '<div class="alert alert-danger mb-0">' +
        $('<div>').text(message).html() +
        '</div>',
    );
}

function kerp_show_load_modal(modal) {
    $(modal).modal('show');
}

function kerp_load_data_to_modal(element) {
    let button = $(element);
    let modalSelector = button.attr('data-modal') || '';
    let targetSelector = button.attr('data-target') || '';
    let modalTitle = button.attr('data-modal-title') || '';
    let responseKey = button.attr('data-response-key') || 'html';
    let modal = $(modalSelector);
    
    if (!modal.length) {
        return;
    }
    
    let target = kerp_get_load_modal_target(modal, targetSelector);
    
    if (!target.length) {
        return;
    }
    
    let data = kerp_get_load_modal_data(element);
    
    if (!data.action) {
        return;
    }
    
    let previousRequest = modal.data('kerp-load-request');
    
    if (
        previousRequest
        && previousRequest.readyState !== 4
    ) {
        previousRequest.abort();
    }
    
    modal.find('.modal-title').text(modalTitle);
    
    kerp_set_load_modal_loading(target);
    kerp_show_load_modal(modal);
    
    button.addClass('disabled');
    
    let request = $.ajax({
        url:  ajax_url,
        type: 'POST',
        data: data,
    });
    
    modal.data('kerp-load-request', request);
    
    request.done(function(response) {
        if (
            !response
            || response.status !== 'success'
        ) {
            let message = response && (response.message || response.msg)
                          ? response.message || response.msg
                          : 'خطا در دریافت اطلاعات.';
            
            kerp_set_load_modal_error(target, message);
            
            return;
        }
        
        let content = response[responseKey];
        
        if (typeof content === 'undefined') {
            content = '';
        }
        
        target.html(content);
        if (typeof activate_date_pickers === 'function') {
            activate_date_pickers();
        }
        if (NioApp.Picker && typeof NioApp.Picker.time === 'function') {
            NioApp.Picker.time(target.find('.time-picker'), {timeFormat: 'HH:mm'});
        }
        if (NioApp.Dropzone && typeof NioApp.Dropzone.init === 'function') {
            NioApp.Dropzone.init();
        }
    });
    
    request.fail(function(xhr, status) {
        if (status === 'abort') {
            return;
        }
        
        kerp_set_load_modal_error(
            target,
            'خطا در ارتباط با سرور.',
        );
    });
    
    request.always(function() {
        button.removeClass('disabled');
        modal.removeData('kerp-load-request');
    });
}

$(document).on('click', '.kerp_load_data_to_modal', function(e) {
    e.preventDefault();
    
    kerp_load_data_to_modal(this);
});

$(document).on('hidden.bs.modal', '#kerpDynamicModal', function() {
    let modal = $(this);
    let request = modal.data('kerp-load-request');
    
    if (
        request
        && request.readyState !== 4
    ) {
        request.abort();
    }
    
    modal.removeData('kerp-load-request');
    modal.find('.modal-title').text('');
    modal.find('.kerp-dynamic-modal-content').empty();
});

function parse_row_inline_needs(value) {
    if (!value) {
        return [];
    }
    
    try {
        let parsed = JSON.parse(value);
        
        return parsed && typeof parsed === 'object'
               ? parsed
               : [];
    } catch (error) {
        console.error('Invalid data-needs JSON:', error, value);
        
        return [];
    }
}

function get_row_inline_action_data($element) {
    let data = {
        action:  $element.attr('data-action') || '',
        item_id: $element.attr('data-item-id') || '',
        page:    $element.attr('data-page') || $('#current_page').val() || '',
    };
    
    let ignored = [
        'action',
        'itemId',
        'swalTitle',
        'page',
        'needs',
    ];
    
    Object.entries($element.get(0).dataset).forEach(function([key, value]) {
        if (ignored.includes(key)) {
            return;
        }
        
        data[key] = value;
    });
    
    return data;
}

function limit_row_inline_need_value(element) {
    let $element = $(element);
    let max = parseFloat($element.attr('data-max'));
    
    if (isNaN(max)) {
        return;
    }
    
    let value = parseFloat($element.val());
    
    if (isNaN(value)) {
        return;
    }
    
    if (value > max) {
        $element.val(max);
    }
}

function row_inline_action(element) {
    let $element = $(element);
    let needs = parse_row_inline_needs(
        $element.attr('data-needs'),
    );
    
    let data = get_row_inline_action_data(
        $element,
    );
    
    if (!data.action) {
        return;
    }
    
    Swal.fire({
        title:             $element.attr('data-swal-title') || 'آیا مطمئن هستید؟',
        icon:              'warning',
        html:              needs.length || Object.keys(needs).length
                           ? buildNeedsHtml(needs, 'فرآیند')
                           : '',
        showCancelButton:  true,
        confirmButtonText: 'بله',
        cancelButtonText:  'خیر',
        onRender:          function() {
            $(Swal.getHtmlContainer()).off('input.rowInline change.rowInline', '[data-max]').on(
                'input.rowInline change.rowInline',
                '[data-max]',
                function() {
                    limit_row_inline_need_value(this);
                },
            );
        },
    }).then(function(result) {
        if (!result.isConfirmed) {
            return;
        }
        
        Object.assign(
            data,
            collectNeedsValues(needs),
        );
        
        $element.addClass('disabled');
        
        $.post(
            ajax_url,
            data,
        ).done(function(response) {
            change_panel_html(response);
        }).fail(function() {
            toast_msg(
                'خطایی در انجام عملیات رخ داد.',
                'error',
            );
        }).always(function() {
            $element.removeClass('disabled');
        });
    });
}

$(document).on('click', '.row_inline_action', function(e) {
    e.preventDefault();
    
    row_inline_action(this);
});



/* ===== filter.js ===== */
function build_filter_hidden_values(context = document) {
    const $context = $(context);
    
    /**
     * =========================
     * Tri-state options
     * =========================
     * state  1  => include => :in
     * state -1  => exclude => :not-in
     * state  0  => ignore
     */
    $context.find('.kasebi-tri-filter-options').each(function() {
        const $wrapper = $(this);
        
        const include = [];
        const exclude = [];
        
        $wrapper.find('.kasebi-tri-filter-checkbox').each(function() {
            const $input = $(this);
            const state = parseInt($input.attr('data-state') || '0', 10);
            const value = String($input.data('value') || '').trim();
            
            if (!value) {
                return;
            }
            
            if (state === 1) {
                include.push(value);
            } else if (state === -1) {
                exclude.push(value);
            }
        });
        
        const parts = [];
        
        if (include.length) {
            parts.push(include.join(',') + ':in');
        }
        
        if (exclude.length) {
            parts.push(exclude.join(',') + ':not-in');
        }
        
        const firstTarget = $wrapper.find('.kasebi-tri-filter-checkbox').first().data('target');
        
        if (firstTarget) {
            $(firstTarget).val(parts.join(';'));
        } else {
            $wrapper.find('.kasebi-tri-filter-value').val(parts.join(';'));
        }
    });
    /**
     * =========================
     * Number / Price
     * =========================
     * output example:
     * 1200000:gte
     */
    $context.find('.kasebi-filter-number-value').each(function() {
        const $hidden = $(this);
        const targetId = $hidden.attr('id');
        
        if (!targetId) {
            return;
        }
        
        const $valueInput = $context.find('[data-target="' + targetId + '"][data-type="value"]');
        const $operatorInput = $context.find('[data-target="' + targetId + '"][data-type="operator"]');
        
        let value = String($valueInput.val() || '').trim();
        const operator = String($operatorInput.val() || 'eq').trim();
        
        value = value.replace(/,/g, '');
        
        if ($valueInput.hasClass('price_input')) {
            value = value.replace(/\D/g, '');
        }
        
        if (!value) {
            $hidden.val('');
            return;
        }
        
        $hidden.val(value + ':' + operator);
    });
    /**
     * =========================
     * Date range
     * =========================
     * output example:
     * 1400-01-01...1402-01-01
     */
    $context.find('.kasebi-filter-date-range-value').each(function() {
        const $hidden = $(this);
        const targetId = $hidden.attr('id');
        
        if (!targetId) {
            return;
        }
        
        const from = String($context.find('[data-target="' + targetId + '"][data-type="from"]').val() || '').trim();
        const to = String($context.find('[data-target="' + targetId + '"][data-type="to"]').val() || '').trim();
        
        if (!from && !to) {
            $hidden.val('');
            return;
        }
        
        if (from && to) {
            $hidden.val(from + '...' + to);
            return;
        }
        
        if (from) {
            $hidden.val(from + ':gte');
            return;
        }
        
        if (to) {
            $hidden.val(to + ':lte');
        }
    });
}

function get_current_page_filters(context = document) {
    build_filter_hidden_values('.filter_form_wrapper');
    
    const data = {};
    
    $(context).find('.filter_form_wrapper .kerp-filter-input, .kerp-table-search[data-for], .kerp-list-context.kerp-filter-input').each(function() {
        const $el = $(this);
        const key = $el.data('for');
        const val = $el.val();
        const type = $el.attr('type');
        
        if (!key || $el.prop('disabled')) {
            return;
        }
        
        if (type === 'radio' && !$el.prop('checked')) {
            return;
        }
        
        if (type === 'checkbox' && !$el.prop('checked')) {
            return;
        }
        
        if (val === '' || val === null || typeof val === 'undefined') {
            return;
        }

        // Select placeholders use "0" for "all". Sending that value turns an
        // empty filter into a real query constraint during AJAX pagination.
        if ($el.is('select') && String(val) === '0') {
            return;
        }
        
        data[key] = val;
    });
    
    return data;
}

$(document).on('change', '.kasebi-tri-filter-checkbox', function(e) {
    const $btn = $(this);
    
    let state = parseInt($btn.attr('data-state') || '0', 10);
    if (state === 0) {
        state = 1;
    } else if (state === 1) {
        state = -1;
    } else {
        state = 0;
    }
    $btn.attr('data-state', state);
    
    $btn.parent().removeClass('is-include is-exclude').find('em.icon').removeClass('ni-square-c ni-check-c ni-cross-c');
    
    if (state === 1) {
        $btn.parent().addClass('is-include');
        $btn.parent().find('em.icon').addClass('ni-check-c');
    } else if (state === -1) {
        $btn.parent().addClass('is-exclude');
        $btn.parent().find('em.icon').addClass('ni-cross-c');
    } else {
        $btn.parent().find('em.icon').addClass('ni-square-c');
    }
    
    build_filter_hidden_values('.filter_form_wrapper');
});
$(document).on('click', '.filter_erp_list', function(event) {
    event.preventDefault();
    ajax_search = false;
    let data = get_current_page_filters();
    data.action = $(this).attr('data-action');
    data.page = $(this).attr('data-page');
    data.page_number = 1;
    kerpRequestPage(data);
});
$(document).on('click', '.user_sort_link', function(e) {
    e.preventDefault();
    
    let orderby = $(this).data('orderby');
    let order = $(this).data('order');
    
    if (!orderby || !order) {
        return;
    }
    
    let data = get_current_page_filters();
    
    data.action = 'erp_request_page_content';
    data.page = 'users';
    data.page_number = 1;
    data.orderby = orderby;
    data.order = order;
    
    kerpRequestPage(data);
});
$(document).on('click', '.change_per_page', function(e) {
    if ($(this).closest('#kerp-employees-list').length) return;
    e.preventDefault();
    let data = {
        ...get_current_page_filters(),
        action:   $(this).attr('data-action'),
        page:     $(this).attr('data-page'),
        per_page: $(this).attr('data-per-page'),
        page_number: 1,
    };
    kerpRequestPage(data);
});
$(document).on('click', '.reset_page_filter', function(e) {
    e.preventDefault();
    let data = {
        action: 'erp_request_page_content',
        page:   $(this).attr('data-page'),
    };
    kerpRequestPage(data);
});
$(document).on('click', '.page-item', function(e) {
    if ($(this).closest('#kerp-employees-list').length) return;
    e.preventDefault();
    if ($(this).hasClass('disabled')) {
        return;
    }
    let page = $(this).attr('data-page');
    let data = get_current_page_filters();
    let currentOrderby = $('#current_orderby').val();
    let currentOrder = $('#current_order').val();
    data.action = $(this).attr('data-action');
    data.page = $(this).attr('data-route');
    data.page_number = page;
    if (currentOrderby) {
        data.orderby = currentOrderby;
    }
    if (currentOrder) {
        data.order = currentOrder;
    }
    kerpRequestPage(data);
});
$(document).on('click', '.kasebi-filter-group-toggle', function(e) {
    e.preventDefault();
    const $toggle = $(this);
    const $target = $toggle.attr('data-target');
    $($target).slideToggle();
});
$(document).on('click', '.open-dropdown', function(e) {
    e.preventDefault();
    const $toggle = $(this);
    const $dropdown = $toggle.closest('.drop-down');
    const $menu = $dropdown.find('.dropdown-menu').first();
    
    $('.filter_form_wrapper.show').not($menu).removeClass('show');
    $('.drop-down.is-open').not($dropdown).removeClass('is-open');
    
    $menu.toggleClass('show');
    $dropdown.toggleClass('is-open', $menu.hasClass('show'));
});
$(document).on('click', function(e) {
    if ($(e.target).closest('.drop-down').length > 0) {
        return; // اگر داخل فرم بود، هیچ کاری انجام نده
    }
    
    $('.drop-down .dropdown-menu.show').removeClass('show');
    $('.drop-down.is-open').removeClass('is-open');
});
$(document).on('change', '.select_all_rows', function() {
    kerp_handle_select_all_rows($(this));
});

$(document).on('change', '.select_item_row', function() {
    kerp_handle_select_item_row($(this));
});
$(document).on('click', '.row_bulk_actions', function(e) {
    e.preventDefault();
    const $actionItem = $(this);
    if ($actionItem.data('processing')) {
        return;
    }
    const ajaxAction = $.trim($actionItem.attr('data-action') || '');
    const operation = $.trim($actionItem.attr('data-operation') || '');
    const operationAction = $.trim($actionItem.attr('data-operation-action') || '');
    const page = $.trim($actionItem.attr('data-page') || $('#current_page').val() || '');
    const itemSelector = $.trim($actionItem.attr('data-item-selector') || '.select_item_row');
    const actionLabel = $.trim($actionItem.find('span').first().text()) || $.trim($actionItem.text()) ||
        $actionItem.attr('title') || 'تایید عملیات';
    if (!ajaxAction || !operation) {
        NioApp.Toast('اطلاعات عملیات گروهی ناقص است.', 'danger', {position: 'top-right'});
        return;
    }
    const customerIds = [];
    $(itemSelector).filter(':checked').each(function() {
        const customerId = parseInt($(this).val() || $(this).attr('data-id') || 0, 10);
        if (customerId > 0 && !customerIds.includes(customerId)) {
            customerIds.push(customerId);
        }
    });
    if (!customerIds.length) {
        NioApp.Toast('حداقل یک مورد را انتخاب کنید.', 'warning', {position: 'top-right'});
        return;
    }
    let needs = $actionItem.attr('data-needs');
    try {
        needs = needs && needs !== 'null' ? JSON.parse(needs) : null;
    } catch (error) {
        needs = null;
    }
    const needFields = needs
                       ? (Array.isArray(needs) ? needs : (Array.isArray(needs.needs) ? needs.needs : null))
                       : null;
    if (needFields && needFields.length === 1 && needFields[0].type === 'modal') {
        const modalField = needFields[0];
        if (modalField.itemsInput) {
            const selector = String(modalField.itemsInput).startsWith('#') ? modalField.itemsInput : '#' +
                modalField.itemsInput;
            $(selector).val(customerIds.join(',')).trigger('change');
        }
        if (modalField.operationInput) {
            const selector = String(modalField.operationInput).startsWith('#') ? modalField.operationInput : '#' +
                modalField.operationInput;
            $(selector).val(operation).trigger('change');
        }
        if (modalField.actionInput) {
            const selector = String(modalField.actionInput).startsWith('#') ? modalField.actionInput : '#' +
                modalField.actionInput;
            $(selector).val(operationAction || ajaxAction).trigger('change');
        }
        if (modalField.pageInput) {
            const selector = String(modalField.pageInput).startsWith('#') ? modalField.pageInput : '#' +
                modalField.pageInput;
            $(selector).val(page).trigger('change');
        }
        if (modalField.modalId) {
            const selector = String(modalField.modalId).startsWith('#') ? modalField.modalId : '#' + modalField.modalId;
            $(selector).modal('show');
        }
        return;
    }
    Swal.fire({
        title:             actionLabel,
        icon:              'warning',
        html:              buildNeedsHtml(needFields, customerIds.length, actionLabel),
        focusConfirm:      false,
        showCancelButton:  true,
        confirmButtonText: 'تایید',
        cancelButtonText:  'لغو',
        preConfirm:        function() {
            const values = collectNeedsValues(needFields);
            const missingField = (needFields || []).find(function(field) {
                if (!field || field.type === 'modal') {
                    return false;
                }
                const key = field.key || field.name;
                if (!key || !field.required) {
                    return false;
                }
                const value = values[key];
                return typeof value === 'undefined' || value === null || String(value).trim() === '';
            });
            if (missingField) {
                Swal.showValidationMessage(
                    `لطفاً «${missingField.label || missingField.key || 'فیلد موردنیاز'}» را تکمیل کنید.`);
                return false;
            }
            return values;
        },
        onRender:          function() {
            if (typeof activate_date_pickers === 'function') {
                activate_date_pickers();
            }
        },
    }).then(function(result) {
        if (!result.isConfirmed) {
            return;
        }
        const payload = result.value || {};
        const data = typeof get_current_page_filters === 'function' ? get_current_page_filters() : {};
        data.action = ajaxAction;
        data.page = page;
        data.bulk_action = operation;
        data.operation = operation;
        data.operation_action = operationAction;
        data.customer_ids = customerIds;
        data.payload = payload;
        $actionItem.data('processing', true);
        $.post(ajax_url, data).done(function(response) {
            if (!response) {
                NioApp.Toast('پاسخ معتبری از سرور دریافت نشد.', 'danger', {position: 'top-right'});
                return;
            }
            change_panel_html(response);
        }).fail(function(xhr) {
            let message = 'اجرای عملیات گروهی با خطا روبه‌رو شد.';
            if (xhr.responseJSON && (xhr.responseJSON.message || xhr.responseJSON.msg)) {
                message = xhr.responseJSON.message || xhr.responseJSON.msg;
            }
            NioApp.Toast(message, 'danger', {position: 'top-right'});
        }).always(function() {
            $actionItem.data('processing', false);
        });
    });
});

// Conditional list filters are cleared as soon as their parent no longer matches.
function kerp_sync_dependent_list_filters($wrapper) {
    $wrapper.find('[data-filter-parent]').each(function() {
        const $row = $(this);
        const parent = $row.attr('data-filter-parent');
        const $parents = $wrapper.find('[data-for]').filter(function() { return $(this).attr('data-for') === parent; });
        const $parent = $parents.first().is(':radio') ? $parents.filter(':checked').first() : $parents.first();
        const parentValue = String($parent.val() || '');
        const visible = $row.attr('data-filter-parent-operator') === 'selected'
            ? parentValue !== '' && parentValue !== '0'
            : $row.attr('data-filter-parent-operator') === 'in'
                ? String($row.attr('data-filter-parent-value') || '').split('|').includes(parentValue)
                : parentValue === $row.attr('data-filter-parent-value');
        $row.toggleClass('d-none', !visible);
        $row.find('input, select, textarea').prop('disabled', !visible).each(function() {
            if (!visible) {
                if ($(this).is(':radio, :checkbox')) {
                    $(this).prop('checked', $(this).is(':radio') && this.value === '');
                } else {
                    $(this).val($(this).is('select') ? '0' : '').trigger('change.select2');
                }
            }
        });
    });
}
$(document).on('change', '.filter_form_wrapper [data-for]', function() {
    kerp_sync_dependent_list_filters($(this).closest('.filter_form_wrapper'));
});
$(document).on('shown.bs.dropdown', '.dropdown', function() {
    $(this).find('.filter_form_wrapper').each(function() { kerp_sync_dependent_list_filters($(this)); });
});



/* ===== charts.js ===== */
$(document).on('click', '.request_dashboard_block_data', function(e) {
    e.preventDefault();
    
    let $btn = $(this);
    let $card = $btn.closest('.card');
    
    if ($card.data('loading')) {
        return;
    }
    
    let action = $btn.attr('data-action') || '';
    
    if (!action) {
        console.warn('Dashboard block action is empty');
        return;
    }
    
    let data = kasebi_parse_dashboard_atts($btn.attr('data-atts') || '');
    data.action = action;
    
    $card.data('loading', true).addClass('is-loading');
    let dashboardUpdated = false;
    let dashboardRequest = action === 'customers_dashboard_memberships'
        ? kerpDashboardSeriesRequest(data, $card[0])
        : $.ajax({ url: ajax_url, method: 'POST', data: data, ajax_search: true });
    dashboardRequest.done(function(response) {
        let payload = kasebi_get_dashboard_payload(response);
        
        if (!payload) {
            console.warn('Invalid dashboard response', response);
            return;
        }
        
        kasebi_apply_dashboard_targets(
            $btn.attr('data-targets') || '',
            payload,
        );
        dashboardUpdated = true;
    }).fail(function() {
        if (action === 'customers_dashboard_memberships' && $card[0].isConnected) {
            toast_msg('دریافت آمار انجام نشد؛ بازه را دوباره انتخاب کنید.', 'error');
        }
    }).always(function() {
        $card.data('loading', false).removeClass('is-loading');
        if (action !== 'customers_dashboard_memberships' || dashboardUpdated) {
            $card.find('.request_dashboard_block_data').removeClass('active');
            $btn.addClass('active');
        }
    });
});

function kasebi_parse_dashboard_atts(raw) {
    let data = {};
    
    if (!raw) {
        return data;
    }
    
    raw.split(';').forEach(function(row) {
        row = row.trim();
        
        if (!row) {
            return;
        }
        
        let parts = row.split(':');
        let key = (parts.shift() || '').trim();
        let value = parts.join(':').trim();
        
        if (!key) {
            return;
        }
        
        data[key] = value;
    });
    
    return data;
}

function kasebi_get_dashboard_payload(response) {
    if (!response) {
        return null;
    }
    
    if (response.data) {
        return response.data;
    }
    
    if (response.result) {
        return response.result;
    }
    
    return response;
}

function kasebi_apply_dashboard_targets(rawTargets, payload) {
    if (!rawTargets) {
        return;
    }
    
    rawTargets.split(';').forEach(function(row) {
        row = row.trim();
        
        if (!row) {
            return;
        }
        
        let parts = row.split(':');
        
        if (parts.length < 3) {
            return;
        }
        
        let responseKey = (parts.shift() || '').trim();
        let selector = (parts.shift() || '').trim();
        let action = parts.join(':').trim();
        
        if (!responseKey || !selector || !action) {
            return;
        }
        
        if (typeof payload[responseKey] === 'undefined') {
            return;
        }
        
        let value = payload[responseKey];
        let $target = $(selector);
        
        if (!$target.length) {
            return;
        }
        
        kasebi_apply_dashboard_target_action($target, action, value);
    });
}

function kasebi_apply_dashboard_target_action($target, action, value) {
    if (action === 'text') {
        $target.text(value);
        return;
    }
    
    if (action === 'html') {
        $target.html(value);
        return;
    }
    
    if (action === 'class') {
        kasebi_apply_dashboard_class($target, value);
        return;
    }
    
    if (action === 'chart') {
        kasebi_apply_dashboard_chart($target, value);
    }
}

function kasebi_apply_dashboard_class($target, value) {
    let baseClass = $target.data('baseClass') || '';
    
    if (Array.isArray(value)) {
        value = value.join(' ');
    }
    
    $target.attr('class', (baseClass + ' ' + value).trim());
}

function kasebi_apply_dashboard_chart($target, value) {
    if (!value || typeof value !== 'object') {
        return;
    }
    
    if (value.labels) {
        $target.attr('data-labels', JSON.stringify(value.labels));
    }
    
    if (value.data) {
        $target.attr('data-data', JSON.stringify(value.data));
    }
    
    if (value.points) {
        $target.attr('data-points', JSON.stringify(value.points));
    }
    
    let chart = $target.data('chartInstance');
    
    if (!chart) {
        $target.removeData('chartActivated');
        
        if (typeof activate_charts === 'function') {
            activate_charts();
        }
        
        return;
    }
    
    if (value.labels) {
        chart.data.labels = value.labels;
    }
    
    if (value.points) {
        if (chart.data.datasets[0]) {
            chart.data.datasets[0].data = value.points;
        }
        
        chart.update();
        return;
    }
    
    if (value.data) {
        let datasetsData = kasebi_normalize_dashboard_chart_datasets(value.data);
        
        if (chart.data.datasets.length !== datasetsData.length) {
            chart.destroy();
            $target.removeData('chartInstance');
            $target.removeData('chartActivated');
            
            if (typeof activate_charts === 'function') {
                activate_charts();
            }
            
            return;
        }
        
        chart.data.datasets.forEach(function(dataset, index) {
            dataset.data = datasetsData[index] || [];
        });
        
        chart.update();
    }
}

function kasebi_normalize_dashboard_chart_datasets(data) {
    if (!Array.isArray(data)) {
        return [[data]];
    }
    
    if (!data.length) {
        return [[]];
    }
    
    if (Array.isArray(data[0])) {
        return data;
    }
    
    return [data];
}

function activate_charts() {
    if (typeof Chart === 'undefined') {
        console.warn('Chart.js not found');
        return;
    }
    
    kasebi_init_chart_defaults();
    register_kasebi_chart_center_text_plugin();
    register_kasebi_doughnut_label_plugin();
    register_kasebi_polar_donut_plugin();
    
    $('.kasebi-chart, .kasebi_chart').each(function() {
        let $chart = $(this);
        
        if ($chart.data('chartActivated')) {
            return;
        }
        
        $chart.data('chartActivated', true);
        
        let type = $chart.attr('data-chart-type') || 'bar';
        let data = kasebi_parse_chart_data($chart);
        
        if (!data) {
            console.warn('Invalid chart data', this);
            return;
        }
        
        let canvas = kasebi_get_chart_canvas($chart);
        let ctx = canvas.getContext('2d');
        
        let config = {
            type:    kasebi_normalize_chart_type(type),
            data:    kasebi_build_chart_data($chart, type, data),
            options: kasebi_build_chart_options($chart, type),
        };
        
        // Home workspace styling is opt-in by ancestry; other reports keep their options.
        if ($chart.closest('.kerp-dashboard').length) {
            kerpDashboardStyleChart(config, type);
        }
        let chart = new Chart(ctx, config);
        
        $chart.data('chartInstance', chart);
    });
}

/**
 * =========================
 * Parse chart data
 * =========================
 */
function kasebi_parse_chart_data($chart) {
    let raw = $chart.attr('data-chart-data');
    
    if (raw) {
        return kasebi_safe_json_parse(raw);
    }
    
    let points = kasebi_safe_json_parse($chart.attr('data-points'));
    
    if (points) {
        return {
            points: points,
        };
    }
    
    let labels = kasebi_safe_json_parse($chart.attr('data-labels'));
    let chartData = kasebi_safe_json_parse($chart.attr('data-data'));
    
    if (labels && chartData) {
        return {
            labels: labels,
            data:   chartData,
        };
    }
    
    let percent = $chart.attr('data-percent');
    let value = $chart.attr('data-value');
    
    if (percent !== undefined || value !== undefined) {
        return {
            title:   $chart.attr('data-title') || '',
            value:   value || 0,
            percent: percent || 0,
        };
    }
    
    return null;
}

/**
 * =========================
 * Build chart data
 * =========================
 */
function kasebi_build_chart_data($chart, type, data) {
    let colors = kasebi_get_chart_colors();
    
    if (type === 'scatter') {
        return {
            datasets: [
                {
                    label: $chart.attr('data-label') || '',
                    data:  data.points || [],
                    
                    backgroundColor: $chart.attr('data-color') || $chart.attr('data-point-color') || colors.teal,
                    borderColor:     $chart.attr('data-color') || $chart.attr('data-point-color') || colors.teal,
                    
                    pointRadius:      parseInt($chart.attr('data-point-radius') || 5),
                    pointHoverRadius: parseInt($chart.attr('data-point-hover-radius') || 7),
                    
                    xLabel: $chart.attr('data-x-label') || $chart.attr('data-x-title') || 'محور X',
                    yLabel: $chart.attr('data-y-label') || $chart.attr('data-y-title') || 'محور Y',
                    
                    xUnit: $chart.attr('data-x-unit') || '',
                    yUnit: $chart.attr('data-y-unit') || $chart.attr('data-unit') || '',
                },
            ],
        };
    }
    
    if (type === 'polar-donut') {
        let rawValues = kasebi_normalize_single_dataset(data.data);
        let minRadius = parseFloat($chart.attr('data-min-radius') || 24);
        let renderedValues = kasebi_build_polar_donut_render_data(rawValues, minRadius);
        
        return {
            labels:   data.labels,
            datasets: [
                {
                    label:           $chart.attr('data-label') || '',
                    data:            renderedValues,
                    rawData:         rawValues,
                    backgroundColor: kasebi_get_chart_dataset_colors($chart, rawValues),
                    borderWidth:     parseInt($chart.attr('data-border-width') || 0),
                    unit:            $chart.attr('data-unit') || '',
                },
            ],
        };
    }
    
    if (type === 'line' || type === 'area') {
        return {
            labels:   data.labels,
            datasets: kasebi_build_multi_datasets($chart, type, data),
        };
    }
    
    if (type === 'bar' || type === 'horizontalBar') {
        return {
            labels:   data.labels,
            datasets: kasebi_build_multi_datasets($chart, type, data),
        };
    }
    
    if (type === 'radar') {
        return {
            labels:   data.labels,
            datasets: kasebi_build_multi_datasets($chart, type, data),
        };
    }
    
    if (type === 'radial') {
        let percent = parseFloat(data.percent || 0);
        let remain = Math.max(100 - percent, 0);
        
        return {
            labels:   [
                data.title || $chart.attr('data-label') || 'مقدار',
                'باقی‌مانده',
            ],
            datasets: [
                {
                    data:            [percent, remain],
                    backgroundColor: [
                        $chart.attr('data-color') || $chart.attr('data-ring-color') || colors.primary,
                        $chart.attr('data-ring-bg') || '#eef0f7',
                    ],
                    borderWidth:     0,
                    unit:            $chart.attr('data-unit') || '',
                },
            ],
        };
    }
    
    /**
     * doughnut / pie / donut
     */
    return {
        labels:   data.labels,
        datasets: [
            {
                label:           $chart.attr('data-label') || '',
                data:            kasebi_normalize_single_dataset(data.data),
                backgroundColor: kasebi_get_chart_dataset_colors($chart, data.data),
                borderWidth:     parseInt($chart.attr('data-border-width') || 0),
                unit:            $chart.attr('data-unit') || '',
            },
        ],
    };
}

/**
 * =========================
 * Multi Dataset Builder
 * data-label / data-data / data-color / data-unit
 * =========================
 */
function kasebi_build_multi_datasets($chart, type, data) {
    let labels = kasebi_to_array(kasebi_safe_json_parse($chart.attr('data-label')) || $chart.attr('data-label') || '');
    let rawData = data.data;
    let datasetsData = kasebi_normalize_datasets_data(rawData);
    
    let colors = kasebi_to_array(kasebi_safe_json_parse($chart.attr('data-color')) || $chart.attr('data-color') || '');
    let units = kasebi_to_array(kasebi_safe_json_parse($chart.attr('data-unit')) || $chart.attr('data-unit') || '');
    let tensions = kasebi_to_array(
        kasebi_safe_json_parse($chart.attr('data-tension')) || $chart.attr('data-tension') || '');
    let fills = kasebi_to_array(kasebi_safe_json_parse($chart.attr('data-fill')) || $chart.attr('data-fill') || '');
    
    let defaultColors = kasebi_get_default_color_list();
    
    return datasetsData.map(function(datasetData, index) {
        let color = kasebi_get_index_value(colors, index, defaultColors[index % defaultColors.length]);
        let label = kasebi_get_index_value(labels, index, '');
        let unit = kasebi_get_index_value(units, index, kasebi_get_index_value(units, 0, ''));
        
        if (type === 'line' || type === 'area') {
            let tension = parseFloat(kasebi_get_index_value(tensions, index, 0.38));
            let fill = kasebi_get_bool_value(kasebi_get_index_value(fills, index, type === 'area'));
            
            return {
                label: label,
                data:  datasetData,
                
                borderColor:     color,
                backgroundColor: kasebi_hex_to_rgba(color, fill ? 0.12 : 0),
                
                borderWidth:      parseInt($chart.attr('data-border-width') || 3),
                pointRadius:      parseInt($chart.attr('data-point-radius') || 3),
                pointHoverRadius: parseInt($chart.attr('data-point-hover-radius') || 5),
                
                fill:        fill,
                lineTension: tension,
                unit:        unit,
            };
        }
        
        if (type === 'radar') {
            return {
                label: label,
                data:  datasetData,
                
                backgroundColor:      kasebi_hex_to_rgba(color, 0.18),
                borderColor:          color,
                pointBackgroundColor: color,
                pointBorderColor:     '#fff',
                
                pointRadius: parseInt($chart.attr('data-point-radius') || 4),
                borderWidth: parseInt($chart.attr('data-border-width') || 2),
                unit:        unit,
            };
        }
        
        return {
            label:           label,
            data:            datasetData,
            backgroundColor: color,
            borderColor:     color,
            borderWidth:     parseInt($chart.attr('data-border-width') || 0),
            unit:            unit,
        };
    });
}

/**
 * =========================
 * Build chart options
 * =========================
 */
function kasebi_build_chart_options($chart, type) {
    let showLegend = $chart.attr('data-legend') !== '0';
    let showGrid = $chart.attr('data-grid') !== '0';
    let title = $chart.attr('data-chart-title') || '';
    let isResponsive = $chart.attr('data-responsive') !== '0';
    let fontFamily = kasebi_get_chart_font_family();
    
    let tooltipColors = $chart.attr('data-tooltip-colors');
    
    if (tooltipColors === '0') {
        tooltipColors = false;
    } else if (tooltipColors === '1') {
        tooltipColors = true;
    } else {
        tooltipColors = type !== 'scatter';
    }
    tooltipColors = false;
    
    let tooltipMode = $chart.attr('data-tooltip-mode') || '';
    
    if (!tooltipMode) {
        tooltipMode = (type === 'line' || type === 'area') ? 'index' : 'nearest';
    }
    
    let tooltipIntersect = $chart.attr('data-tooltip-intersect');
    
    if (tooltipIntersect === '1') {
        tooltipIntersect = true;
    } else if (tooltipIntersect === '0') {
        tooltipIntersect = false;
    } else {
        tooltipIntersect = !(type === 'line' || type === 'area');
    }
    
    let options = {
        responsive:          isResponsive,
        maintainAspectRatio: false,
        
        legend: {
            display:  showLegend,
            position: $chart.attr('data-legend-position') || 'bottom',
            rtl:      true,
            labels:   {
                usePointStyle: true,
                boxWidth:      8,
                fontFamily:    fontFamily,
                padding:       18,
            },
        },
        
        title: {
            display:    title !== '',
            text:       title,
            fontFamily: fontFamily,
            fontSize:   15,
            fontColor:  '#1f2937',
            padding:    18,
        },
        
        tooltips: {
            rtl:             true,
            mode:            tooltipMode,
            intersect:       tooltipIntersect,
            displayColors:   tooltipColors,
            titleFontFamily: fontFamily,
            bodyFontFamily:  fontFamily,
            backgroundColor: '#111827',
            cornerRadius:    8,
            xPadding:        12,
            yPadding:        10,
            callbacks:       {
                title: function(tooltipItems, chartData) {
                    return kasebi_chart_tooltip_title(tooltipItems, chartData, type);
                },
                label: function(tooltipItem, chartData) {
                    return kasebi_chart_tooltip_label(tooltipItem, chartData, type);
                },
            },
        },
        
        hover: {
            mode:      tooltipMode,
            intersect: tooltipIntersect,
        },
        
        animation: {
            duration: parseInt($chart.attr('data-animation-duration') || 700),
        },
    };
    
    if (type === 'polar-donut') {
        options.scale = {
            ticks:       {
                display:     false,
                beginAtZero: true,
            },
            gridLines:   {
                display: false,
            },
            angleLines:  {
                display: false,
            },
            pointLabels: {
                display: false,
            },
        };
        
        options.startAngle = -0.5 * Math.PI;
        
        options.polarDonut = {
            cutoutPercentage: parseInt($chart.attr('data-cutout') || 36),
            centerFill:       $chart.attr('data-center-fill') || '#fff',
        };
        
        return options;
    }
    
    if (type === 'doughnut' || type === 'donut' || type === 'pie' || type === 'radial') {
        options.cutoutPercentage = parseInt($chart.attr('data-cutout') || 68);
        
        if ($chart.attr('data-show-labels') === '1') {
            options.kasebiDoughnutLabels = {
                type:  $chart.attr('data-label-type') || 'percent',
                color: $chart.attr('data-label-color') || '#111827',
            };
        }
        
        if (type === 'radial') {
            options.legend.display = false;
            options.tooltips.enabled = $chart.attr('data-tooltip') === '1';
            options.centerText = {
                title:    $chart.attr('data-center-title') || '',
                value:    $chart.attr('data-center-value') || '',
                subtitle: $chart.attr('data-center-subtitle') || '',
            };
        }
        
        return options;
    }
    
    if (type === 'radar') {
        options.scale = {
            ticks:       {
                display:     false,
                beginAtZero: true,
            },
            gridLines:   {
                display: $chart.attr('data-radar-grid') === '1',
                color:   'rgba(0,0,0,0)',
            },
            angleLines:  {
                display: $chart.attr('data-radar-lines') === '1',
                color:   'rgba(0,0,0,0)',
            },
            pointLabels: {
                fontFamily: fontFamily,
                fontColor:  '#6b7280',
                fontSize:   12,
            },
        };
        
        return options;
    }
    
    if (type === 'scatter') {
        options.scales = {
            xAxes: [
                {
                    type:       'linear',
                    position:   'bottom',
                    gridLines:  {
                        display:    showGrid,
                        color:      '#edf0f5',
                        drawBorder: false,
                    },
                    scaleLabel: {
                        display:     !!$chart.attr('data-x-title'),
                        labelString: $chart.attr('data-x-title') || '',
                        fontFamily:  fontFamily,
                    },
                    ticks:      {
                        fontFamily:  fontFamily,
                        fontColor:   '#6b7280',
                        beginAtZero: $chart.attr('data-begin-zero') !== '0',
                    },
                },
            ],
            yAxes: [
                {
                    gridLines:  {
                        display:    showGrid,
                        color:      '#edf0f5',
                        drawBorder: false,
                    },
                    scaleLabel: {
                        display:     !!$chart.attr('data-y-title'),
                        labelString: $chart.attr('data-y-title') || '',
                        fontFamily:  fontFamily,
                    },
                    ticks:      {
                        fontFamily:  fontFamily,
                        fontColor:   '#6b7280',
                        beginAtZero: $chart.attr('data-begin-zero') !== '0',
                    },
                },
            ],
        };
        
        return options;
    }
    
    if (type === 'line' || type === 'area' || type === 'bar' || type === 'horizontalBar') {
        options.scales = {
            xAxes: [
                {
                    gridLines: {
                        display:    type === 'horizontalBar' ? showGrid : false,
                        color:      '#edf0f5',
                        drawBorder: false,
                    },
                    ticks:     {
                        fontFamily: fontFamily,
                        fontColor:  '#6b7280',
                    },
                },
            ],
            yAxes: [
                {
                    gridLines: {
                        display:    showGrid,
                        color:      '#edf0f5',
                        drawBorder: false,
                    },
                    ticks:     {
                        fontFamily:  fontFamily,
                        fontColor:   '#6b7280',
                        beginAtZero: true,
                    },
                },
            ],
        };
        
        return options;
    }
    
    return options;
}

/**
 * =========================
 * Tooltip
 * =========================
 */
function kasebi_chart_tooltip_title(tooltipItems, chartData, type) {
    if (!tooltipItems || !tooltipItems.length) {
        return '';
    }
    
    if (
        type === 'donut' ||
        type === 'doughnut' ||
        type === 'pie' ||
        type === 'polar-donut' ||
        type === 'radial' ||
        type === 'scatter'
    ) {
        return '';
    }
    
    let item = tooltipItems[0];
    let index = typeof item.index !== 'undefined' ? item.index : item._index;
    
    if (chartData.labels && typeof chartData.labels[index] !== 'undefined') {
        return chartData.labels[index];
    }
    
    return '';
}

function kasebi_chart_tooltip_label(tooltipItem, chartData, type) {
    let datasetIndex = typeof tooltipItem.datasetIndex !== 'undefined'
                       ? tooltipItem.datasetIndex
                       : tooltipItem._datasetIndex;
    
    let index = typeof tooltipItem.index !== 'undefined'
                ? tooltipItem.index
                : tooltipItem._index;
    
    let dataset = chartData.datasets[datasetIndex || 0];
    
    if (!dataset) {
        return '';
    }
    
    let dataItem = null;
    
    if (dataset.data && typeof dataset.data[index] !== 'undefined') {
        dataItem = dataset.data[index];
    }
    
    /**
     * Scatter:
     * labelX:valueX unitX
     * labelY:valueY unitY
     */
    if (type === 'scatter' && typeof dataItem === 'object' && dataItem !== null) {
        let xLabel = dataItem.x_label || dataItem.label || dataItem.labelX || dataItem.xLabel || dataItem.x;
        let yLabel = dataItem.y_label || dataItem.labelY || dataItem.yLabel || dataItem.y;
        
        let xValue = dataItem.x_value || dataItem.valueX || xLabel;
        let yValue = dataItem.y_value || dataItem.valueY || dataItem.y;
        
        let lines = [];
        
        lines.push(
            (dataset.xLabel || 'محور X') + ': ' + kasebi_format_chart_value(xValue, dataset.xUnit || ''),
        );
        
        lines.push(
            (dataset.yLabel || 'محور Y') + ': ' + kasebi_format_chart_value(yValue, dataset.yUnit || ''),
        );
        
        return lines;
    }
    
    /**
     * Donut / Doughnut / Pie / Radial
     */
    if (
        type === 'donut' ||
        type === 'doughnut' ||
        type === 'pie' ||
        type === 'radial' ||
        type === 'polar-donut'
    ) {
        let label = '';
        
        if (chartData.labels && typeof chartData.labels[index] !== 'undefined') {
            label = chartData.labels[index];
        }
        
        let tooltipValue = dataItem;
        
        if (
            type === 'polar-donut' &&
            dataset.rawData &&
            typeof dataset.rawData[index] !== 'undefined'
        ) {
            tooltipValue = dataset.rawData[index];
        }
        
        return label + ': ' + kasebi_format_chart_value(tooltipValue, dataset.unit || '');
    }
    
    /**
     * Normal charts:
     * title
     * label:value unit
     */
    let value = dataItem;
    
    if (typeof tooltipItem.yLabel !== 'undefined') {
        value = tooltipItem.yLabel;
    } else if (typeof tooltipItem.xLabel !== 'undefined') {
        value = tooltipItem.xLabel;
    }
    
    let datasetLabel = dataset.label || '';
    
    if (datasetLabel) {
        return datasetLabel + ': ' + kasebi_format_chart_value(value, dataset.unit || '');
    }
    
    return kasebi_format_chart_value(value, dataset.unit || '');
}

/**
 * =========================
 * Helpers
 * =========================
 */
function kasebi_safe_json_parse(value) {
    if (!value) {
        return null;
    }
    
    if (typeof value !== 'string') {
        return value;
    }
    
    try {
        return JSON.parse(value);
    } catch (e) {
        try {
            return JSON.parse(value.replace(/&quot;/g, '"'));
        } catch (e2) {
            return null;
        }
    }
}

function kasebi_get_chart_canvas($chart) {
    let canvas = $chart.find('canvas').get(0);
    
    if (canvas) {
        return canvas;
    }
    
    let height = parseInt($chart.attr('data-chart-height') || 260);
    
    canvas = document.createElement('canvas');
    canvas.height = height;
    
    $chart.empty().append(canvas);
    
    return canvas;
}

function kasebi_normalize_chart_type(type) {
    if (type === 'donut') {
        return 'doughnut';
    }
    
    if (type === 'area') {
        return 'line';
    }
    
    if (type === 'radial') {
        return 'doughnut';
    }
    
    if (type === 'polar-donut') {
        return 'polarArea';
    }
    
    return type;
}

function kasebi_get_chart_font_family() {
    return $('body').css('font-family') || 'Tahoma, sans-serif';
}

function kasebi_init_chart_defaults() {
    if (typeof Chart === 'undefined') {
        return;
    }
    
    let fontFamily = kasebi_get_chart_font_family();
    
    Chart.defaults.global.defaultFontFamily = fontFamily;
    Chart.defaults.global.defaultFontColor = '#6b7280';
}

function kasebi_normalize_datasets_data(data) {
    if (!Array.isArray(data)) {
        return [[data]];
    }
    
    if (!data.length) {
        return [[]];
    }
    
    if (Array.isArray(data[0])) {
        return data;
    }
    
    return [data];
}

function kasebi_normalize_single_dataset(data) {
    if (!Array.isArray(data)) {
        return [data];
    }
    
    if (Array.isArray(data[0])) {
        return data[0];
    }
    
    return data;
}

function kasebi_to_array(value) {
    if (Array.isArray(value)) {
        return value;
    }
    
    if (value === null || typeof value === 'undefined' || value === '') {
        return [];
    }
    
    return [value];
}

function kasebi_get_index_value(values, index, fallback) {
    if (Array.isArray(values) && typeof values[index] !== 'undefined') {
        return values[index];
    }
    
    if (Array.isArray(values) && typeof values[0] !== 'undefined') {
        return values[0];
    }
    
    return fallback;
}

function kasebi_get_bool_value(value) {
    if (value === true || value === 'true' || value === '1' || value === 1) {
        return true;
    }
    
    if (value === false || value === 'false' || value === '0' || value === 0) {
        return false;
    }
    
    return !!value;
}

function kasebi_format_chart_value(value, unit) {
    if (typeof value === 'undefined' || value === null) {
        value = '';
    }
    
    if (!unit) {
        return value;
    }
    
    if (unit === '٪' || unit === '%') {
        return value + unit;
    }
    
    return value + ' ' + unit;
}

function kasebi_get_chart_colors() {
    return {
        primary: '#635bff',
        blue:    '#3b82f6',
        teal:    '#14b8a6',
        orange:  '#f97316',
        pink:    '#ec4899',
        red:     '#f43f5e',
        yellow:  '#f59e0b',
        gray:    '#9ca3af',
    };
}

function kasebi_get_default_color_list() {
    return [
        '#635bff',
        '#3b82f6',
        '#14b8a6',
        '#f97316',
        '#ec4899',
        '#f43f5e',
        '#f59e0b',
        '#9ca3af',
    ];
}

function kasebi_get_chart_dataset_colors($chart, data) {
    let colors = kasebi_safe_json_parse($chart.attr('data-color'));
    
    if (!colors) {
        colors = kasebi_safe_json_parse($chart.attr('data-colors'));
    }
    
    if (colors && Array.isArray(colors)) {
        return colors;
    }
    
    let singleColor = $chart.attr('data-color');
    
    if (singleColor) {
        return singleColor;
    }
    
    let count = Array.isArray(data) ? data.length : 1;
    let base = kasebi_get_default_color_list();
    let output = [];
    
    for (let i = 0; i < count; i++) {
        output.push(base[i % base.length]);
    }
    
    return output;
}

function kasebi_hex_to_rgba(hex, alpha) {
    if (!hex || hex.indexOf('#') !== 0) {
        return hex || 'rgba(99,91,255,' + alpha + ')';
    }
    
    hex = hex.replace('#', '');
    
    if (hex.length === 3) {
        hex = hex.split('').map(function(char) {
            return char + char;
        }).join('');
    }
    
    let r = parseInt(hex.substring(0, 2), 16);
    let g = parseInt(hex.substring(2, 4), 16);
    let b = parseInt(hex.substring(4, 6), 16);
    
    return 'rgba(' + r + ',' + g + ',' + b + ',' + alpha + ')';
}

/**
 * =========================
 * Center text plugin
 * =========================
 */
function register_kasebi_chart_center_text_plugin() {
    if (window.kasebiChartCenterTextPluginRegistered) {
        return;
    }
    
    window.kasebiChartCenterTextPluginRegistered = true;
    
    Chart.plugins.register({
        beforeDraw: function(chart) {
            if (!chart.config.options.centerText) {
                return;
            }
            
            let ctx = chart.chart.ctx;
            let width = chart.chart.width;
            let height = chart.chart.height;
            let centerText = chart.config.options.centerText;
            let fontFamily = kasebi_get_chart_font_family();
            
            ctx.save();
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.direction = 'rtl';
            
            if (centerText.title) {
                ctx.font = '12px ' + fontFamily;
                ctx.fillStyle = '#6b7280';
                ctx.fillText(centerText.title, width / 2, height / 2 - 24);
            }
            
            if (centerText.value) {
                ctx.font = 'bold 22px ' + fontFamily;
                ctx.fillStyle = '#111827';
                ctx.fillText(centerText.value, width / 2, height / 2);
            }
            
            if (centerText.subtitle) {
                ctx.font = '12px ' + fontFamily;
                ctx.fillStyle = '#6b7280';
                ctx.fillText(centerText.subtitle, width / 2, height / 2 + 24);
            }
            
            ctx.restore();
        },
    });
}

/**
 * =========================
 * Doughnut labels plugin
 * =========================
 */
function register_kasebi_doughnut_label_plugin() {
    if (window.kasebiDoughnutLabelPluginRegistered) {
        return;
    }
    
    window.kasebiDoughnutLabelPluginRegistered = true;
    
    Chart.plugins.register({
        afterDatasetsDraw: function(chart) {
            let options = chart.config.options || {};
            
            if (!options.kasebiDoughnutLabels) {
                return;
            }
            
            if (chart.config.type !== 'doughnut' && chart.config.type !== 'pie') {
                return;
            }
            
            let ctx = chart.chart.ctx;
            let dataset = chart.data.datasets[0];
            
            if (!dataset || !dataset.data) {
                return;
            }
            
            let total = dataset.data.reduce(function(sum, value) {
                return sum + Number(value || 0);
            }, 0);
            
            let fontFamily = kasebi_get_chart_font_family();
            
            ctx.save();
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.direction = 'rtl';
            ctx.font = '12px ' + fontFamily;
            ctx.fillStyle = options.kasebiDoughnutLabels.color || '#111827';
            
            chart.getDatasetMeta(0).data.forEach(function(element, index) {
                let value = Number(dataset.data[index] || 0);
                
                if (!value || total <= 0) {
                    return;
                }
                
                let percent = Math.round((value / total) * 100);
                
                if (percent < 6) {
                    return;
                }
                
                let position = element.tooltipPosition();
                let label = chart.data.labels[index] || '';
                
                let text = options.kasebiDoughnutLabels.type === 'label'
                           ? label
                           : percent + '٪';
                
                ctx.fillText(text, position.x, position.y);
            });
            
            ctx.restore();
        },
    });
}

function kasebi_build_polar_donut_render_data(values, minRadiusPercent) {
    if (!Array.isArray(values)) {
        values = [values];
    }
    
    minRadiusPercent = parseFloat(minRadiusPercent || 25);
    
    if (minRadiusPercent < 0) {
        minRadiusPercent = 0;
    }
    
    if (minRadiusPercent > 95) {
        minRadiusPercent = 95;
    }
    
    let maxValue = Math.max.apply(null, values.map(function(value) {
        return Number(value || 0);
    }));
    
    if (!maxValue || maxValue <= 0) {
        return values.map(function() {
            return minRadiusPercent;
        });
    }
    
    return values.map(function(value) {
        value = Number(value || 0);
        
        return minRadiusPercent + ((value / maxValue) * (100 - minRadiusPercent));
    });
}

function register_kasebi_polar_donut_plugin() {
    if (window.kasebiPolarDonutPluginRegistered) {
        return;
    }
    
    window.kasebiPolarDonutPluginRegistered = true;
    
    Chart.plugins.register({
        afterDatasetsDraw: function(chart) {
            let options = chart.config.options || {};
            
            if (!options.polarDonut) {
                return;
            }
            
            if (chart.config.type !== 'polarArea') {
                return;
            }
            
            let meta = chart.getDatasetMeta(0);
            
            if (!meta || !meta.data || !meta.data.length) {
                return;
            }
            
            let firstArc = meta.data[0];
            
            if (!firstArc || !firstArc._model) {
                return;
            }
            
            let model = firstArc._model;
            let ctx = chart.chart.ctx;
            
            let centerX = model.x;
            let centerY = model.y;
            let outerRadius = model.outerRadius || 0;
            
            let cutoutPercentage = options.polarDonut.cutoutPercentage || 36;
            let innerRadius = outerRadius * (cutoutPercentage / 100);
            
            ctx.save();
            ctx.beginPath();
            ctx.fillStyle = options.polarDonut.centerFill || '#fff';
            ctx.arc(centerX, centerY, innerRadius, 0, Math.PI * 2);
            ctx.closePath();
            ctx.fill();
            ctx.restore();
        },
    });
}



/* ===== profile.js ===== */
$(document).on('click', '.login_as_this', function(e) {
    e.preventDefault();
    let user_id = $(this).attr('data-id');
    let data = {
        action:  'login_as_user',
        user_id: user_id,
    };
    $.post(ajax_url, data, function(response) {
        window.location.reload();
    });
});
$(document).on('click', '.change_preferences', function(e) {
    e.preventDefault();
    let data = {
        action: $(this).attr('data-action'),
        value:  $(this).attr('data-value'),
    };
    $.post(ajax_url, data, function(response) {
        window.location.reload();
    });
});
$(document).on('click', '.kerp-restore-admin-session', function(e) {
    e.preventDefault();
    let data = {
        action: 'restore_admin_session',
    };
    $.post(ajax_url, data, function(response) {
        window.location.reload();
    });
});
$(document).on('click', '.reset_password', function(e) {
    e.preventDefault();
    let user_id = $(this).attr('data-id');
    let data = {
        action:  'reset_password',
        user_id: user_id,
    };
    $.post(ajax_url, data, function(response) {
        Swal.fire({
            title:             'رمز عبور تغییر کرد.',
            html:              response.html,
            focusConfirm:      false,
            confirmButtonText: 'باشه',
        });
    });
});

function kerp_get_profile_modal_scope(element) {
    let modal = $(element).closest('.modal');
    
    if (modal.length) {
        return modal;
    }
    
    return $(element).closest('.profile-image-modal-body');
}

function kerp_get_upload_zone_dropzone(scope) {
    let uploadZone = scope.find('.upload-zone').first()[0];
    
    if (!uploadZone) {
        return null;
    }
    
    if (uploadZone.dropzone) {
        return uploadZone.dropzone;
    }
    
    return null;
}

function kerp_stop_profile_webcam(scope) {
    let video = scope.find('.profile_webcam_video').first()[0];
    
    if (!video || !video.srcObject) {
        return;
    }
    
    video.srcObject.getTracks().forEach(function(track) {
        track.stop();
    });
    
    video.srcObject = null;
}

function kerp_canvas_to_file(canvas, filename) {
    return new Promise(function(resolve) {
        canvas.toBlob(function(blob) {
            if (!blob) {
                resolve(null);
                return;
            }
            
            let file = new File([blob], filename, {
                type:         'image/jpeg',
                lastModified: Date.now(),
            });
            
            resolve(file);
        }, 'image/jpeg', 0.92);
    });
}

$(document).on('click', '.start_profile_webcam', async function(e) {
    e.preventDefault();
    
    let scope = kerp_get_profile_modal_scope(this);
    let video = scope.find('.profile_webcam_video').first()[0];
    
    if (!video) {
        NioApp.Toast('بخش نمایش وبکم پیدا نشد', 'error', {
            position: 'top-right',
        });
        return;
    }
    
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        NioApp.Toast('مرورگر شما از وبکم پشتیبانی نمی‌کند', 'error', {
            position: 'top-right',
        });
        return;
    }
    
    try {
        let devices = await navigator.mediaDevices.enumerateDevices();
        
        let hasCamera = devices.some(function(device) {
            return device.kind === 'videoinput';
        });
        
        if (!hasCamera) {
            NioApp.Toast('وبکم متصل نیست', 'error', {
                position: 'top-right',
            });
            return;
        }
        
        /*
         * قبل از ایجاد استریم جدید، استریم قبلی متوقف شود.
         */
        kerp_stop_profile_webcam(scope);
        
        let stream = await navigator.mediaDevices.getUserMedia({
            video: {
                width:      500,
                height:     500,
                facingMode: 'user',
            },
            audio: false,
        });
        
        video.srcObject = stream;
        
        await video.play();
        
        scope.find('.profile_webcam_box').stop(true, true).slideDown(150);
    } catch (error) {
        NioApp.Toast('دسترسی به وبکم ممکن نیست', 'error', {
            position: 'top-right',
        });
    }
});

$(document).on('click', '.take_profile_webcam_screenshot', function(e) {
    e.preventDefault();
    
    let scope = kerp_get_profile_modal_scope(this);
    let video = scope.find('.profile_webcam_video').first()[0];
    let canvas = scope.find('.profile_webcam_canvas').first()[0];
    
    if (!video || !video.srcObject) {
        NioApp.Toast('ابتدا وبکم را فعال کنید', 'warning', {
            position: 'top-right',
        });
        return;
    }
    
    if (!canvas) {
        NioApp.Toast('بخش پیش‌نمایش تصویر پیدا نشد', 'error', {
            position: 'top-right',
        });
        return;
    }
    
    let context = canvas.getContext('2d');
    
    if (!context) {
        NioApp.Toast('ساخت پیش‌نمایش تصویر ممکن نیست', 'error', {
            position: 'top-right',
        });
        return;
    }
    
    context.drawImage(
        video,
        0,
        0,
        canvas.width,
        canvas.height,
    );
    
    canvas.setAttribute('data-has-image', '1');
});

$(document).on('click', '.upload_profile_webcam_to_dropzone', async function(e) {
    e.preventDefault();
    
    let scope = kerp_get_profile_modal_scope(this);
    let canvas = scope.find('.profile_webcam_canvas').first()[0];
    let dropzone = kerp_get_upload_zone_dropzone(scope);
    
    if (!canvas || canvas.getAttribute('data-has-image') !== '1') {
        NioApp.Toast('ابتدا پیش‌نمایش تصویر را بگیرید', 'warning', {
            position: 'top-right',
        });
        return;
    }
    
    if (!dropzone) {
        NioApp.Toast('آپلودزون پیدا نشد', 'error', {
            position: 'top-right',
        });
        return;
    }
    
    let file = await kerp_canvas_to_file(
        canvas,
        'kerp-profile-webcam-' + Date.now() + '.jpg',
    );
    
    if (!file) {
        NioApp.Toast('ساخت تصویر انجام نشد', 'error', {
            position: 'top-right',
        });
        return;
    }
    
    if (typeof dropzone.removeAllFiles === 'function') {
        dropzone.removeAllFiles(true);
    }
    
    dropzone.addFile(file);
    
    NioApp.Toast('تصویر وبکم به آپلودزون اضافه شد', 'success', {
        position: 'top-right',
    });
    
    kerp_stop_profile_webcam(scope);
    
    scope.find('.profile_webcam_box').stop(true, true).slideUp(150);
});

$(document).on('click', '.stop_profile_webcam', function(e) {
    e.preventDefault();
    
    let scope = kerp_get_profile_modal_scope(this);
    
    kerp_stop_profile_webcam(scope);
    
    scope.find('.profile_webcam_box').stop(true, true).slideUp(150);
});

$(document).on('hidden.bs.modal', '.modal', function() {
    kerp_stop_profile_webcam($(this));
});


/* ===== addresses.js ===== */
function kerp_addresses_get_order_form(element) {
    return $(element).closest('.kerp-order-form');
}

function kerp_addresses_reload_order_block(element) {
    console.log(element);
    let form = kerp_addresses_get_order_form(element);
    let block = form.find('.kerp-order-address-section').first();
    let customerId = parseInt($(element).val() || '0', 10);
    let orderId = parseInt(form.find('[data-for="order_id"]').first().val() || '0', 10);
    
    if (!form.length || !block.length) {
        return;
    }
    
    $.post(
        ajax_url,
        {
            action:      'addresses_get_order_block',
            customer_id: customerId,
            order_id:    orderId,
        },
    ).done(function(response) {
        if (response.status !== 'success' || !response.html) {
            NioApp.Toast(
                response.message || 'خطا در دریافت آدرس‌های کاربر',
                response.status || 'error',
                {
                    position: 'top-right',
                },
            );
            return;
        }
        
        block.replaceWith(response.html);
    });
}

function kerp_addresses_select_order_address(element) {
    let block = $(element).closest('.kerp-order-address-section');
    let addressId = $(element).val() || '';
    
    block.find('.kerp-order-address-option').removeClass('border-primary');
    $(element).closest('.kerp-order-address-option').addClass('border-primary');
    block.find('[data-for="address_id"]').first().val(addressId).trigger('change');
}

function kerp_addresses_set_default(element) {
    let button = $(element);
    let data = {
        action:      button.attr('data-action') || 'addresses_set_default',
        page:        button.attr('data-page') || '',
        customer_id: button.attr('data-customer_id') || '',
        address_id:  button.attr('data-address_id') || '',
    };
    
    if (!data.customer_id || !data.address_id) {
        return;
    }
    
    button.addClass('disabled');
    
    $.post(ajax_url, data).done(function(response) {
        if (response.status !== 'success') {
            NioApp.Toast(
                response.message || 'خطا در تغییر آدرس پیش‌فرض',
                response.status || 'error',
                {
                    position: 'top-right',
                },
            );
            return;
        }
        
        change_panel_html(response);
    }).always(function() {
        button.removeClass('disabled');
    });
}

$(document).on('change', '.kerp-order-form [data-for="customer_id"]', function() {
    kerp_addresses_reload_order_block(this);
});

$(document).on('change', '.kerp-order-address-choice', function() {
    kerp_addresses_select_order_address(this);
});

$(document).on('click', '.kerp-address-set-default', function(e) {
    e.preventDefault();
    kerp_addresses_set_default(this);
});

function kerp_addresses_apply_order_block_response(response) {
    if (
        !response ||
        response.status !== 'success' ||
        !response.address_block_html
    ) {
        return;
    }
    
    let block = $('.kerp-order-address-section').first();
    
    if (!block.length) {
        return;
    }
    
    block.replaceWith(response.address_block_html);
}

$(document).ajaxSuccess(function(event, xhr) {
    let response = xhr.responseJSON;
    
    kerp_addresses_apply_order_block_response(response);
});


/* ===== appointments.js ===== */
function appointments_clear_time_options() {
    let $time = $('#kerp-appointment-time');
    
    $time.empty().append(
        $('<option>', {
            value: '',
            text:  'ابتدا خدمت، کارشناس و تاریخ را انتخاب کنید',
        }),
    );
}

function appointments_update_time_options() {
    let $service = $('#kerp-appointment-service');
    let $employee = $('#kerp-appointment-employee');
    let $date = $('#kerp-appointment-date');
    let $time = $('#kerp-appointment-time');
    
    let serviceId = parseInt($service.val() || '0', 10);
    let employeeId = parseInt($employee.val() || '0', 10);
    let date = $.trim($date.val() || '');
    let appointmentId = parseInt($('#kerp-appointment-id').val() || '0', 10);
    let selectedTime = $.trim($date.attr('data-time') || '');
    
    if (!serviceId || !employeeId || !date) {
        appointments_clear_time_options();
        return;
    }
    
    $time.prop('disabled', true).empty().append(
        $('<option>', {
            value: '',
            text:  'در حال دریافت ساعت‌های آزاد...',
        }),
    );
    
    $.post(
        ajax_url,
        {
            action:         'appointments_get_time_options',
            service_id:     serviceId,
            employee_id:    employeeId,
            date:           date,
            appointment_id: appointmentId,
        },
    ).done(function(response) {
        $time.empty();
        
        if (!response || response.status !== 'success') {
            $time.append(
                $('<option>', {
                    value: '',
                    text:  response.message || 'خطا در دریافت ساعت‌ها',
                }),
            );
            
            return;
        }
        
        let options = response.options || {};
        
        if (!Object.keys(options).length) {
            $time.append(
                $('<option>', {
                    value: '',
                    text:  'ساعت آزادی برای این روز وجود ندارد',
                }),
            );
            
            return;
        }
        
        $time.append(
            $('<option>', {
                value: '',
                text:  'انتخاب ساعت',
            }),
        );
        
        $.each(options, function(value, label) {
            $time.append(
                $('<option>', {
                    value: value,
                    text:  label,
                }),
            );
        });
        
        if (
            selectedTime &&
            $time.find('option[value="' + selectedTime + '"]').length
        ) {
            $time.val(selectedTime).trigger('change');
        }
        
        if (selectedTime) {
            $date.removeAttr('data-selected-time');
        }
    }).fail(function() {
        $time.empty().append(
            $('<option>', {
                value: '',
                text:  'خطا در ارتباط با سرور',
            }),
        );
    }).always(function() {
        $time.prop('disabled', false);
    });
}

$(document).on(
    'change',
    '#kerp-appointment-service, #kerp-appointment-employee, #kerp-appointment-date',
    function() {
        appointments_update_time_options();
    },
);


/* ===== customer-history.js ===== */
(function($) {
    'use strict';

    $(document).on('click', '.kerp-customer-history-load-more', function(e) {
        e.preventDefault();

        const $button = $(this);
        const $wrapper = $button.closest('.kerp-customer-history');
        const $list = $wrapper.find('.kerp-customer-history-list').first();

        if ($button.prop('disabled') || !$list.length) {
            return;
        }

        const originalText = $button.find('.kerp-load-more-label').text();
        $button.prop('disabled', true).addClass('disabled');
        $button.find('.kerp-load-more-label').text('در حال بارگذاری...');
        $button.find('.icon').addClass('d-none');
        $button.find('.kerp-load-more-spinner').removeClass('d-none');

        $.post(ajax_url, {
            action:      'customers_history_load_more',
            customer_id: $button.attr('data-customer-id'),
            page_number: $button.attr('data-next-page'),
            per_page:    $button.attr('data-per-page'),
            event_type:  $button.attr('data-event-type') || '',
        }).done(function(response) {
            if (!response || response.status !== 'success') {
                const message = response && response.message
                    ? response.message
                    : 'بارگذاری سوابق انجام نشد.';
                NioApp.Toast(message, 'error', {position: 'top-right'});
                $button.prop('disabled', false).removeClass('disabled');
                return;
            }

            if (response.html) {
                $list.append(response.html);
            }

            if (response.has_more) {
                $button.attr('data-next-page', response.next_page);
                $button.prop('disabled', false).removeClass('disabled');
            } else {
                $button.closest('.kerp-customer-history-load-more-wrap').remove();
            }
        }).fail(function() {
            $button.prop('disabled', false).removeClass('disabled');
            NioApp.Toast('ارتباط با سرور برای بارگذاری سوابق برقرار نشد.', 'error', {
                position: 'top-right',
            });
        }).always(function() {
            if ($button.closest('body').length) {
                $button.find('.kerp-load-more-label').text(originalText);
                $button.find('.icon').removeClass('d-none');
                $button.find('.kerp-load-more-spinner').addClass('d-none');
            }
        });
    });
})(jQuery);



/* ===== customers-search-index.js ===== */
// Progressive index rebuild follows the customer migration controls.
$(document).on('click.kerpCustomerIndex', '[data-index-rebuild]', async function(event) {
    event.preventDefault();
    const button = this;
    const root = button.closest('#kerp-customers-search-index');
    if (!root || root.dataset.running === '1') return;
    const label = button.querySelector('span');
    const message = root.querySelector('[data-index-message]');
    const progress = root.querySelector('[data-index-progress]');
    root.dataset.running = '1';
    root.setAttribute('aria-busy', 'true');
    button.disabled = true;
    label.textContent = 'در حال بازسازی…';
    message.classList.remove('text-danger');
    const controller = new AbortController();
    const observer = new MutationObserver(function() {
        if (!document.documentElement.contains(root)) controller.abort();
    });
    observer.observe(document.body, {childList: true, subtree: true});
    const onPageHide = function() { controller.abort(); };
    window.addEventListener('pagehide', onPageHide, {once: true});
    let idleRequests = 0;
    let previousProcessed = -1;
    try {
        while (document.documentElement.contains(root)) {
            const body = new URLSearchParams({
                action: 'customers_rebuild_search_index',
                index_nonce: root.dataset.nonce || '',
                generation: root.dataset.generation || ''
            });
            const response = await fetch(window.KERPData?.ajaxUrl || '', {
                method: 'POST', credentials: 'same-origin', cache: 'no-store',
                signal: controller.signal,
                headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'},
                body: body.toString()
            });
            const payload = await response.json();
            if (!response.ok || payload?.status !== 'success' || !payload.data) {
                throw new Error(payload?.message || payload?.msg || 'بازسازی ایندکس انجام نشد.');
            }
            if (!document.documentElement.contains(root)) break;
            const data = payload.data;
            root.dataset.generation = data.generation;
            for (const key of ['total', 'processed', 'remaining']) {
                root.querySelector('[data-index-' + key + ']').textContent = Number(data[key] || 0).toLocaleString('fa-IR');
            }
            const percent = Math.max(0, Math.min(100, Number(data.percent || 0)));
            progress.style.width = percent + '%';
            progress.setAttribute('aria-valuenow', String(percent));
            message.textContent = data.complete
                ? 'بازسازی ایندکس کامل شد؛ جستجوی مشتریان آماده است.'
                : 'دسته ' + Number(data.page || 0).toLocaleString('fa-IR') + ' — ' + percent.toLocaleString('fa-IR') + '٪ — ' + Number(data.remaining || 0).toLocaleString('fa-IR') + ' کاربر باقی مانده است…';
            if (data.complete) {
                root.dataset.generation = '';
                label.textContent = 'بازسازی دوباره ایندکس';
                break;
            }
            idleRequests = Number(data.processed) === previousProcessed ? idleRequests + 1 : 0;
            previousProcessed = Number(data.processed);
            if (idleRequests >= 10) throw new Error('بازسازی پیشرفت نکرد؛ کمی بعد ادامه دهید.');
            if (data.busy) await new Promise(resolve => setTimeout(resolve, 1000));
        }
    } catch (error) {
        if (error.name !== 'AbortError') {
            message.classList.add('text-danger');
            message.textContent = error.message || 'بازسازی ایندکس انجام نشد.';
        }
        label.textContent = 'ادامه بازسازی ایندکس';
    } finally {
        observer.disconnect();
        window.removeEventListener('pagehide', onPageHide);
        root.dataset.running = '0';
        root.removeAttribute('aria-busy');
        button.disabled = false;
    }
});



/* ===== dashboard-loading.js ===== */
// Modules load independently; blocks sharing one module reuse its request and cache.
var kerpDashboardRequests = new WeakMap();

async function kerpDashboardLoad() {
    var root = document.querySelector('.kerp-dashboard[data-dashboard-nonce]');
    if (!root) return;
    var requests = kerpDashboardRequests.get(root);
    if (!requests) { requests = new Map(); kerpDashboardRequests.set(root, requests); }
    var nodes = Array.from(root.querySelectorAll('[data-dashboard-pending]:not([data-dashboard-error])'));
    var modules = Array.from(new Set(nodes.map(function(node) { return node.closest('[data-dashboard-module]').dataset.dashboardModule; })));
    await Promise.allSettled(modules.map(function(module) {
        if (!requests.has(module)) {
            var request = Promise.resolve().then(function() { return kerpDashboardLoadModule(root, module); });
            requests.set(module, request);
            request.finally(function() { if (requests.get(module) === request) requests.delete(module); }).catch(function() {});
        }
        return requests.get(module);
    }));
}

async function kerpDashboardLoadModule(root, module) {
    var attempts = {};
    var progress = {};
    while (root.isConnected) {
        var targets = Array.from(root.querySelectorAll('[data-dashboard-pending]:not([data-dashboard-error])')).filter(function(node) {
            return node.closest('[data-dashboard-module]').dataset.dashboardModule === module;
        });
        if (!targets.length) return;
        if (document.hidden) { await new Promise(function(resolve) { setTimeout(resolve, 1000); }); continue; }
        var delay;
        try {
            if ((attempts[module] = (attempts[module] || 0) + 1) > 1200) throw new Error('برای ادامهٔ آماده‌سازی اطلاعات دوباره تلاش کنید.');
            var response = await $.ajax({ url: ajax_url, method: 'POST', dataType: 'json', ajax_search: true, timeout: 25000, data: { action: 'dashboard_blocks', nonce: root.dataset.dashboardNonce, module: module } });
            if (!root.isConnected) return;
            if (response.status === 'pending') {
                var detail = response.progress || {};
                var checkpoint = progress[module] || { batches: 0, time: Date.now() };
                var batches = Number(detail.batches) || 0;
                if (batches > checkpoint.batches) checkpoint = { batches: batches, time: Date.now() };
                progress[module] = checkpoint;
                if (Date.now() - checkpoint.time > 180000) throw new Error('آماده‌سازی اطلاعات پیشرفت نکرده است؛ دوباره تلاش کنید.');
                var processed = Number(detail.processed) || 0;
                var prepared = Number(detail.prepared) || 0;
                targets.forEach(function(node) {
                    var caption = node.querySelector('p');
                    if (caption && processed > 0) caption.textContent = 'در حال آماده‌سازی اطلاعات؛ ' + processed.toLocaleString('fa-IR') + ' سفارش بررسی شد…';
                    if (caption && prepared > 0) caption.textContent = 'تکمیل اولیه آمار؛ ' + prepared.toLocaleString('fa-IR') + ' سفارش آماده و ' + processed.toLocaleString('fa-IR') + ' سفارش بررسی شد…';
                });
                delay = detail.phase === 'locked' ? 1500 : 150;
                await new Promise(function(resolve) { setTimeout(resolve, delay); });
                continue;
            }
            if (response.status === 'unavailable') {
                targets.forEach(function(node) { node.closest('.kerp-dashboard-column').remove(); });
                return;
            }
            if (response.status !== 'success' || !response.blocks) throw new Error(response.message || 'دریافت اطلاعات انجام نشد.');
            targets.forEach(function(node) {
                var section = node.closest('[data-dashboard-module]');
                var id = section.id.replace(/^kerp-dashboard-/, '');
                if (!Object.prototype.hasOwnProperty.call(response.blocks, id)) throw new Error('پاسخ این بخش کامل نیست.');
                var html = response.blocks[id];
                if (!html.trim()) { node.closest('.kerp-dashboard-column').remove(); return; }
                $(node).html(html);
                node.removeAttribute('data-dashboard-pending');
                node.setAttribute('aria-busy', 'false');
            });
            activate_charts();
            NioApp.BS.init();
            return;
        } catch (error) {
            if (!root.isConnected) return;
            targets.forEach(function(node) {
                node.setAttribute('data-dashboard-error', '1');
                node.setAttribute('aria-busy', 'false');
                $(node).empty().append($('<p class="sub-text" role="status"></p>').text(error.responseJSON && error.responseJSON.message || error.message || 'دریافت اطلاعات انجام نشد.'))
                    .append($('<button type="button" class="btn btn-sm btn-outline-primary kerp-dashboard-retry">تلاش دوباره</button>'));
            });
            return;
        }
    }
}

$(document).on('click', '.kerp-dashboard-retry', function() {
    var root = this.closest('.kerp-dashboard');
    var module = this.closest('[data-dashboard-module]').dataset.dashboardModule;
    root.querySelectorAll('[data-dashboard-error]').forEach(function(node) {
        if (node.closest('[data-dashboard-module]').dataset.dashboardModule !== module) return;
        node.removeAttribute('data-dashboard-error');
        node.setAttribute('aria-busy', 'true');
        $(node).text('در حال آماده‌سازی اطلاعات…');
    });
    kerpDashboardLoad();
});

// The customer period picker can also encounter an expired snapshot.
function kerpDashboardSeriesRequest(data, element) {
    var deferred = $.Deferred();
    var attempts = 0;
    function run() {
        if (!element.isConnected || ++attempts > 1200) { deferred.reject(); return; }
        $.ajax({ url: ajax_url, method: 'POST', dataType: 'json', ajax_search: true, timeout: 25000, data: data }).done(function(response) {
            if (response.status === 'pending') { setTimeout(run, 500); return; }
            if (response.status !== 'success') { deferred.reject(); return; }
            if (element.isConnected) deferred.resolve(response); else deferred.reject();
        }).fail(function() { deferred.reject(); });
    }
    run();
    return deferred.promise();
}

$(function() { kerpDashboardLoad(); });



/* ===== dashboard-workspace.js ===== */
// Chart.js 2.x presentation for registered home blocks only.
function kerpDashboardStyleChart(config, type) {
    var dark = document.body.classList.contains('dark-mode');
    var ink = dark ? '#b6c5dc' : '#526580';
    var grid = dark ? 'rgba(160,180,210,.13)' : 'rgba(82,101,128,.10)';
    var options = config.options;
    options.animation.duration = window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 0 : 450;
    options.legend.labels.fontColor = ink;
    options.title.fontColor = ink;
    options.tooltips.backgroundColor = dark ? '#26364d' : '#17263c';
    options.tooltips.titleFontColor = '#fff';
    options.tooltips.bodyFontColor = '#e4eaf5';
    options.tooltips.titleAlign = 'right';
    options.tooltips.bodyAlign = 'right';
    options.tooltips.borderWidth = 1;
    options.tooltips.borderColor = grid;
    options.layout = { padding: { top: 8, right: 4, bottom: 0, left: 4 } };
    var horizontal = type === 'horizontalBar';
    if (options.scales) {
        ['xAxes', 'yAxes'].forEach(function(key) {
            var numeric = horizontal ? key === 'xAxes' : key === 'yAxes';
            var axis = options.scales[key][0];
            axis.gridLines = { display: numeric, color: grid, zeroLineColor: grid, drawBorder: false, borderDash: [3, 5], tickMarkLength: 0 };
            axis.ticks.fontColor = ink;
            axis.ticks.fontSize = 10;
            axis.ticks.padding = 10;
            axis.ticks.maxRotation = 0;
            axis.ticks.minRotation = 0;
            axis.ticks.autoSkip = !horizontal || numeric;
            axis.ticks.maxTicksLimit = numeric ? 5 : 6;
            if (numeric) {
                axis.ticks.beginAtZero = true;
                axis.ticks.precision = 0;
                axis.ticks.callback = function(value) { return Number(value).toLocaleString('fa-IR'); };
            } else {
                delete axis.ticks.beginAtZero;
                axis.ticks.callback = function(value) {
                    var label = String(value);
                    if (/^\d{4}[-/]\d{2}[-/]\d{2}$/.test(label)) label = label.slice(5);
                    return label.length > 18 ? label.slice(0, 17) + '…' : label;
                };
            }
            if (key === 'yAxes') axis.position = 'right';
            if (horizontal && numeric) axis.ticks.reverse = true;
        });
    }
    config.data.datasets.forEach(function(dataset) {
        if (['area', 'line', 'bar', 'horizontalBar'].indexOf(type) < 0) {
            dataset.borderWidth = 3;
            dataset.borderColor = dark ? '#172333' : '#fff';
            dataset.hoverBorderColor = dataset.borderColor;
            return;
        }
        var color = dataset.borderColor;
        dataset.pointRadius = 0;
        dataset.pointHitRadius = 14;
        dataset.pointHoverRadius = 4;
        dataset.borderWidth = type === 'area' || type === 'line' ? 2 : 0;
        // Monotone interpolation avoids suggesting negative counts between zero days.
        dataset.cubicInterpolationMode = 'monotone';
        dataset.lineTension = 0.25;
        dataset.maxBarThickness = horizontal ? 16 : 22;
        dataset.categoryPercentage = 0.72;
        dataset.barPercentage = 0.8;
        dataset.kerpDashboardColor = color;
    });
    config.plugins = [{
        beforeDatasetsUpdate: function(chart) {
            var area = chart.chartArea;
            if (!area) return;
            chart.data.datasets.forEach(function(dataset) {
                if (!dataset.kerpDashboardColor) return;
                var color = dataset.kerpDashboardColor;
                var gradient = horizontal
                    ? chart.ctx.createLinearGradient(area.right, 0, area.left, 0)
                    : chart.ctx.createLinearGradient(0, area.top, 0, area.bottom);
                gradient.addColorStop(0, kasebi_hex_to_rgba(color, type === 'area' ? 0.36 : 0.95));
                gradient.addColorStop(1, kasebi_hex_to_rgba(color, type === 'area' ? 0.015 : 0.35));
                dataset.backgroundColor = gradient;
            });
        }
    }];
}

// Recreate only workspace charts when the theme changes, including after AJAX navigation.
var kerpDashboardThemeObserver = new MutationObserver(function(records) {
    var changed = records.some(function(record) {
        return (record.oldValue || '').split(/\s+/).includes('dark-mode') !== document.body.classList.contains('dark-mode');
    });
    if (!changed) return;
    $('.kerp-dashboard .kasebi-chart, .kerp-dashboard .kasebi_chart').each(function() {
        var element = $(this);
        var chart = element.data('chartInstance');
        if (chart) chart.destroy();
        element.removeData('chartInstance').removeData('chartActivated');
    });
    if (document.querySelector('.kerp-dashboard')) activate_charts();
});
kerpDashboardThemeObserver.observe(document.body, { attributes: true, attributeFilter: ['class'], attributeOldValue: true });



/* ===== employees.js ===== */
let kerpEmployeesTimer = null;
let kerpEmployeesRequest = null;
let kerpEmployeesGeneration = 0;

$(document).on('click', '.kerp-employees-assign-user', function() {
    const $button = $(this);
    if ($button.data('processing')) return;
    const $row = $button.closest('.kerp-employee-candidate');
    const $root = $button.closest('#kerp-employees-list');
    let options;
    try {
        options = JSON.parse($button.attr('data-role-options') || '{}');
    } catch (error) {
        NioApp.Toast('نقش‌ها دریافت نشدند؛ صفحه را دوباره بارگذاری کنید.', 'danger', {position: 'top-right'});
        return;
    }
    kerpEmployeesCancel();
    $root.find('.kerp-employees-results').attr('aria-busy', 'false');
    $button.data('processing', true).prop('disabled', true);
    Swal.fire({
        title: 'افزودن به کارکنان',
        text: 'نقش سازمانی این کاربر را انتخاب کنید.',
        input: 'select',
        inputOptions: options,
        inputPlaceholder: 'انتخاب نقش سازمانی',
        showCancelButton: true,
        confirmButtonText: 'افزودن به کارکنان',
        cancelButtonText: 'لغو',
        showLoaderOnConfirm: true,
        allowOutsideClick: () => !Swal.isLoading(),
        allowEscapeKey: () => !Swal.isLoading(),
        preConfirm: async function(role) {
            if (!role || !Object.prototype.hasOwnProperty.call(options, role)) {
                Swal.showValidationMessage('یک نقش سازمانی را انتخاب کنید.');
                return false;
            }
            const data = {action: 'employees_assign_existing_user', role_key: role};
            $row.find('input[data-for]').each(function() {
                data[$(this).attr('data-for')] = this.value;
            });
            try {
                const response = await $.ajax({url: ajax_url, type: 'POST', dataType: 'json', data: data, timeout: 30000});
                if (response.status !== 'success') {
                    Swal.showValidationMessage(response.message || response.msg || 'افزودن کاربر انجام نشد.');
                    return false;
                }
                return response;
            } catch (error) {
                Swal.showValidationMessage('ارتباط با سرور برقرار نشد؛ وضعیت کاربر را پیش از تلاش دوباره بررسی کنید.');
                return false;
            }
        },
    }).then(function(result) {
        if (result.isConfirmed && result.value) change_panel_html(result.value);
    }).finally(function() {
        $button.data('processing', false).prop('disabled', false);
    });
});

function kerpEmployeesCancel() {
    clearTimeout(kerpEmployeesTimer);
    clearTimeout($('#kerp-employees-list').data('kerp-table-search-timer'));
    kerpEmployeesGeneration++;
    if (kerpEmployeesRequest) {
        kerpEmployeesRequest.abort();
        kerpEmployeesRequest = null;
    }
}

function kerpEmployeesLoad(root, pageNumber = 1, quietSearch = true) {
    if (!root || !root.isConnected) return;
    kerpEmployeesCancel();
    const generation = kerpEmployeesGeneration;
    const $root = $(root);
    const $results = $root.find('.kerp-employees-results');
    const section = $root.attr('data-section');
    const roleKey = section === 'available' ? 'wp_role' : 'role_key';
    const role = String($root.find('[data-for="' + roleKey + '"]').val() || '');
    const data = {
        action: 'erp_request_page_content',
        page: '/erp/employees/',
        section: section,
        search: String($root.find('#kerp-employees-search').val() || '').trim(),
        page_number: pageNumber,
        per_page: parseInt($root.find(".kerp-employees-per-page").val(), 10) || 12,
    };
    if (role && role !== '0') data[roleKey] = role;
    // Preserve an existing status filter supplied by a bookmarked employees URL.
    const status = new URL(window.location.href).searchParams.get('status');
    if (section === 'employees' && status) data.status = status;
    $results.attr('aria-busy', 'true');
    const current = () => generation === kerpEmployeesGeneration && root.isConnected;
    kerpEmployeesRequest = kerpTableSearchAjax({
        url: ajax_url,
        type: 'POST',
        dataType: 'json',
        data: data,
        ajax_search: quietSearch,
        kerpEmployeesFilter: true,
    }).done(function(response) {
        if (!current()) return;
        const $content = $('<div>').append($.parseHTML(response.main || '', document, false));
        const $next = $content.find('#kerp-employees-list');
        if (response.status !== 'success' || !$next.length || $next.attr('data-section') !== section) {
            NioApp.Toast(response.message || response.msg || 'دریافت نتایج ناموفق بود. دوباره تلاش کنید.', 'danger', {position: 'top-right'});
            return;
        }
        // Keep the search field and its cursor in place while replacing cards and pagination.
        $results.find('.kerp-employees-tooltip-active').tooltip('dispose');
        $results.html($next.find('.kerp-employees-results').html());
        $root.find('.kerp-employees-summary').html($next.find('.kerp-employees-summary').html());
        $root.find('.kerp-employees-total').text($next.find('.kerp-employees-total').text());
        const $badge = $root.find('.nav-tabs .badge');
        $badge.text($next.find('.nav-tabs .badge').text());
        const $toggle = $root.find('.filter_form_wrapper').siblings('.dropdown-toggle');
        $toggle.find('.dot').remove();
        if (data[roleKey]) $toggle.append('<span class="dot dot-primary"></span>');
        if (response.url) history.replaceState({}, '', response.url);
        kerpEmployeesSelectionCount();
        // The toolbar survives result updates; avoid binding its search toggles twice.
        $root.find('.toggle-search').off('click');
        NioApp.ajaxInit();
    }).fail(function(xhr, state) {
        if (current() && state !== 'abort') {
            NioApp.Toast('خطا در دریافت نتایج؛ دوباره تلاش کنید.', 'danger', {position: 'top-right'});
        }
    }).always(function() {
        if (current()) {
            $results.attr('aria-busy', 'false');
            kerpEmployeesRequest = null;
        }
    });
}

$(document).on('kerp:table-search', '#kerp-employees-list', function(event) {
    event.preventDefault();
    kerpEmployeesLoad(this);
});
$(document).on('kerp:table-search-cancel', '#kerp-employees-list', function() {
    kerpEmployeesCancel();
    $(this).find('.kerp-employees-results').attr('aria-busy', 'false');
});
$(document).on('click', '#kerp-employees-list .page-item', function(event) {
    event.preventDefault();
    if ($(this).is('.disabled, .active')) return;
    kerpEmployeesLoad($(this).closest('#kerp-employees-list')[0], parseInt($(this).attr('data-page'), 10) || 1, false);
});
// Invalidate a pending search when navigation or assigning a candidate starts.
$(document).ajaxSend(function(event, xhr, settings) {
    if (settings.kerpEmployeesFilter) return;
    const data = typeof settings.data === 'string' ? new URLSearchParams(settings.data) : null;
    const action = data ? data.get('action') : (settings.data || {}).action;
    if (['erp_request_page_content', 'erp_request_back_btn', 'employees_assign_existing_user', 'employees_assign_existing_users'].includes(action)) {
        kerpEmployeesCancel();
        $('#kerp-employees-list .kerp-employees-results').attr('aria-busy', 'false');
    }
});

$(document).on('click', '#kerp-employees-list .change_per_page', function(event) {
    event.preventDefault();
    const $root = $(this).closest('#kerp-employees-list');
    $root.find('.kerp-employees-per-page').val($(this).attr('data-per-page'));
    $root.find('.change_per_page').removeClass('active');
    $(this).addClass('active');
    kerpEmployeesLoad($root[0], 1, false);
});

function kerpEmployeesSelectionCount() {
    const $root = $('#kerp-employees-list');
    kerp_update_select_all_state($root);
    $root.find('.kerp-employee-candidate-select').each(function() {
        $(this).closest('.nk-tb-item').toggleClass('is-selected', this.checked);
    });
    const count = $('#kerp-employees-list .kerp-employee-candidate-select:checked').length;
    $('#kerp-employees-list .kerp-employees-selected-count').text(count ? count + ' کاربر انتخاب شده' : '');
}
$(document).on('change kerp:row-selection-change', '#kerp-employees-list .kerp-employee-candidate-select', kerpEmployeesSelectionCount);
$(document).on('click', '.kerp-employees-open-bulk', function(event) {
    event.preventDefault();
    const $root = $(this).closest('#kerp-employees-list');
    const ids = $root.find('.kerp-employee-candidate-select:checked').map(function() { return this.value; }).get();
    if (!ids.length) {
        NioApp.Toast('حداقل یک کاربر را انتخاب کنید.', 'warning', {position: 'top-right'});
        return;
    }
    kerpEmployeesCancel();
    $root.find('.kerp-employees-results').attr('aria-busy', 'false');
    const $modal = $root.find('#kerpEmployeesBulkAssign');
    if ($modal.data('processing')) return;
    // Reuse the shared modal with a real keyboard-accessible submit button.
    $modal.find('.submit_modal_form').replaceWith($('<button type="button" class="btn btn-primary kerp-employees-bulk-submit">').text('افزودن کاربران انتخاب‌شده'));
    const role = $root.find('.kerp-employees-filters [data-for="wp_role"]').val();
    const data = {
        action: 'employees_assign_existing_users', user_ids: ids,
        search: String($root.find('#kerp-employees-search').val() || '').trim(),
        wp_role: role && role !== '0' ? role : '',
        per_page: parseInt($root.find('.kerp-employees-per-page').val(), 10) || 12,
        page_number: parseInt($root.find('.page-item.active').attr('data-page'), 10) || 1,
    };
    $modal.data('assignment', data);
    $modal.find('.kerp-employees-bulk-count').text(ids.length + ' کاربر انتخاب شده‌اند.');
    $modal.find('.kerp-employees-bulk-feedback').empty();
    $modal.modal('show');
});
$(document).on('click', '.kerp-employees-bulk-submit', function() {
    const $modal = $(this).closest('.modal');
    const $button = $(this);
    if ($modal.data('processing')) return;
    const role = $modal.find('[data-for="role_key"]').val();
    const assignment = $modal.data('assignment');
    const $feedback = $modal.find('.kerp-employees-bulk-feedback');
    if (!assignment || !assignment.user_ids.length || !role || role === '0') {
        $feedback.text('کاربران و یک نقش سازمانی معتبر را انتخاب کنید.');
        return;
    }
    const data = Object.assign({}, assignment, {
        role_key: role, employees_nonce: $modal.find('[data-for="employees_nonce"]').val(),
    });
    $modal.data('processing', true);
    $button.prop('disabled', true).attr('aria-busy', 'true');
    $feedback.empty();
    $.ajax({url: ajax_url, type: 'POST', dataType: 'json', data: data}).done(function(response) {
        if (response.status === 'success') change_panel_html(response);
        else $feedback.text(response.message || response.msg || 'افزودن کاربران انجام نشد.');
    }).fail(function() {
        $feedback.text('ارتباط با سرور برقرار نشد؛ پیش از تلاش دوباره، فهرست کارکنان را بررسی کنید.');
    }).always(function() {
        $modal.data('processing', false);
        $button.prop('disabled', false).attr('aria-busy', 'false');
    });
});
$(document).on('submit', '#kerpEmployeesBulkAssign form', function(event) {
    event.preventDefault();
    $(this).find('.kerp-employees-bulk-submit').trigger('click');
});

$(document).on('keydown', '#kerp-employees-search', function(event) {
    if (event.key === 'Escape') {
        kerpEmployeesCancel();
        const $root = $(this).closest('#kerp-employees-list');
        $root.find('.kerp-employees-results').attr('aria-busy', 'false');
        $root.find('.search-toggle').attr('aria-expanded', 'false').trigger('focus');
    }
});
$(document).on('click', '#kerp-employees-list .toggle-search', function() {
    const $root = $(this).closest('#kerp-employees-list');
    const open = $root.find('[data-search="search_employees"]').hasClass('active');
    $root.find('.search-toggle').attr('aria-expanded', String(open));
    if (!open) {
        kerpEmployeesCancel();
        $root.find('.kerp-employees-results').attr('aria-busy', 'false');
        $root.find('.search-toggle').trigger('focus');
    }
});

// Tooltips are scoped to this list and do not replace dropdown/modal Bootstrap toggles.
const kerpEmployeesTooltipTargets = '#kerp-employees-list button, #kerp-employees-list .btn, #kerp-employees-list .page-link, #kerp-employees-list .reset_page_filter, #kerp-employees-list .change_per_page, #kerp-employees-list .kerp-employees-open-bulk';
function kerpEmployeesShowTooltip() {
    const $button = $(this);
    if ($button.is('[data-kerp-no-tooltip]')) return;
    const pageNumber = $button.closest('.page-item').attr('data-page');
    const perPage = $button.attr('data-per-page');
    const label = (pageNumber ? 'رفتن به صفحه ' + pageNumber : (perPage ? 'نمایش ' + perPage + ' مورد در صفحه' : '')) || $button.attr('aria-label') || $button.attr('data-bs-original-title') || $button.attr('title') || $.trim($button.text());
    if (!label || typeof $.fn.tooltip !== 'function') return;
    if (!$button.hasClass('kerp-employees-tooltip-active')) {
        $button.addClass('kerp-employees-tooltip-active').tooltip({title: label, trigger: 'hover focus', container: 'body'});
    }
    $button.tooltip('show');
}
$(document).on('mouseenter', kerpEmployeesTooltipTargets, kerpEmployeesShowTooltip);
document.addEventListener('focus', function(event) {
    if (event.target.matches(kerpEmployeesTooltipTargets)) kerpEmployeesShowTooltip.call(event.target);
}, true);
$(document).on('click', kerpEmployeesTooltipTargets, function() {
    if ($(this).hasClass('kerp-employees-tooltip-active')) $(this).tooltip('hide');
});



/* ===== first-touch-migration.js ===== */
(function() {
    'use strict';

    document.addEventListener('click', async function(event) {
        const button = event.target.closest('[data-ft-migrate]');
        if (!button) return;
        event.preventDefault();

        const root = button.closest('#kerp-first-touch-migration');
        if (!root || root.dataset.running === '1') return;
        root.dataset.running = '1';
        button.disabled = true;
        const label = button.querySelector('span');
        const message = root.querySelector('[data-ft-message]');
        label.textContent = 'در حال انتقال…';

        try {
            let remaining = 1;
            while (remaining > 0 && document.documentElement.contains(root)) {
                const body = new URLSearchParams({
                    action: 'customers_migrate_first_touch',
                    migration_nonce: root.dataset.nonce || ''
                });
                const response = await fetch(window.KERPData?.ajaxUrl || '', {
                    method: 'POST', credentials: 'same-origin', cache: 'no-store',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'},
                    body: body.toString()
                });
                const payload = await response.json();
                if (!response.ok || payload?.status !== 'success' || !payload.data) {
                    throw new Error(payload?.message || payload?.msg || 'انتقال انجام نشد.');
                }
                remaining = Number(payload.data.remaining || 0);
                root.querySelector('[data-ft-total]').textContent = Number(payload.data.total || 0).toLocaleString('fa-IR');
                root.querySelector('[data-ft-remaining]').textContent = remaining.toLocaleString('fa-IR');
                message.textContent = remaining > 0 ? remaining.toLocaleString('fa-IR') + ' رکورد باقی مانده است…' : 'انتقال کامل شد؛ متای قبلی برای بازیابی حفظ شده است.';
                if (remaining > 0 && Number(payload.data.copied || 0) === 0) throw new Error('رکوردی منتقل نشد؛ داده‌های قدیمی را بررسی کنید.');
            }
            label.textContent = 'انتقال کامل است';
        } catch (error) {
            message.classList.add('text-danger');
            message.textContent = error.message || 'انتقال انجام نشد.';
            button.disabled = false;
            label.textContent = 'ادامه انتقال';
        } finally {
            root.dataset.running = '0';
        }
    });
})();



/* ===== installments.js ===== */
function kerp_installment_sms_recipients(form) {
    $(form).find('.repeater_row').each(function() {
        const $row = $(this);
        const $recipient = $row.find('select[data-for$="[recipient]"]');
        if (!$recipient.length) return;
        const recipient = String($recipient.val() || '');
        [['.kerp-installment-sms-meta', 'user_meta'], ['.kerp-installment-sms-custom', 'custom']].forEach(function(pair) {
            const visible = recipient === pair[1];
            const $field = $row.find(pair[0]);
            $field.toggleClass('d-none', !visible);
            $field.find('input').prop('disabled', !visible).attr('data-req', visible ? '1' : '0').data('req', visible ? 1 : 0);
        });
    });
}

$(document).on('change', '.kerp-installment-plan select[data-for$="[recipient]"]', function() {
    kerp_installment_sms_recipients($(this).closest('.kerp-installment-plan'));
});

function kerp_installment_update_progress(form) {
    kerp_installment_sms_recipients(form);
    const $form = $(form), $summary = $form.find('.kerp-installment-plan-progress');
    if (!$summary.length) return;
    let total = 0, invalid = false;
    $form.find('.kerp-installment-steps .repeater_rows [data-for$="[percent]"]').each(function() {
        const raw = String($(this).val() || '').trim()
            .replace(/[۰-۹]/g, digit => '۰۱۲۳۴۵۶۷۸۹'.indexOf(digit))
            .replace(/[٠-٩]/g, digit => '٠١٢٣٤٥٦٧٨٩'.indexOf(digit))
            .replace(/٫/g, '.');
        if (!raw) return;
        if (!/^\d{1,3}(?:\.\d{1,2})?$/.test(raw) || Number(raw) <= 0 || Number(raw) > 100) {
            invalid = true;
            return;
        }
        total += Math.round(Number(raw) * 100);
    });
    const format = value => (value / 100).toLocaleString('fa-IR', {maximumFractionDigits: 2});
    const excess = total > 10000, complete = total === 10000 && !invalid;
    $summary.toggleClass('is-complete', complete).toggleClass('is-error', excess || invalid);
    $summary.find('.kerp-installment-progress-total').text(format(total) + '٪ از ۱۰۰٪');
    const message = invalid ? 'درصد هر قسط باید عددی مثبت تا ۱۰۰ با حداکثر دو رقم اعشار باشد.'
        : excess ? format(total - 10000) + '٪ بیشتر از مقدار مجاز'
        : complete ? 'مجموع درصدها کامل است.' : format(10000 - total) + '٪ باقی مانده';
    $summary.find('.kerp-installment-progress-note').text(message);
    $summary.find('[role="progressbar"]').attr({'aria-valuenow': Math.min(100, total / 100), 'aria-valuetext': format(total) + '٪؛ ' + message});
    $summary.find('.progress-bar').css('width', Math.min(100, total / 100) + '%');
}

$(document).on('input change', '.kerp-installment-steps [data-for$="[percent]"]', function() {
    kerp_installment_update_progress($(this).closest('.kerp-installment-plan'));
});

$(function() {
    $('.kerp-installment-plan').each(function() { kerp_installment_update_progress(this); });
    let queued = false;
    new MutationObserver(function(changes) {
        const relevant = changes.some(change => Array.from(change.addedNodes).concat(Array.from(change.removedNodes))
            .some(node => node.nodeType === 1 && (node.matches('.repeater_row,.kerp-installment-plan') || node.querySelector('.kerp-installment-plan'))));
        if (!relevant || queued) return;
        queued = true;
        setTimeout(function() {
            queued = false;
            $('.kerp-installment-plan').each(function() { kerp_installment_update_progress(this); });
        }, 0);
    }).observe(document.body, {childList: true, subtree: true});
});



/* ===== lead-registration-builder.js ===== */
// Let the shared repeater handle indexes, controls and conditional fields.
// Enforce this form's limit before its delegated add handler runs.
document.addEventListener('click', function (kerpRegEvent) {
    const kerpRegAdd = kerpRegEvent.target.closest('.kerp-registration-builder .add_repeater_row');
    if (!kerpRegAdd) return;
    const kerpRegRows = kerpRegAdd.closest('.repeater_wrapper').querySelectorAll('.repeater_rows > .repeater_row');
    if (kerpRegRows.length < 24) return;
    kerpRegEvent.preventDefault();
    kerpRegEvent.stopPropagation();
    NioApp.Toast('حداکثر ۲۴ فیلد قابل تعریف است.', 'warning', {position: 'top-right'});
}, true);

$(document).on('shown.bs.modal', '#kerpPipelineRegistration', function () {
    $(this).find('.submit_modal_form').attr({role: 'button', tabindex: '0'});
    evaluateAll($(this).find('form'));
});
// The shared leads modal key handler already covers #kerpPipelineRegistration.



/* ===== lead-registration-preview.js ===== */
// Local-only walkthrough: these controls never call registration, OTP or navigation APIs.
function kerpRegistrationPreviewStep($preview, step, focus) {
    const current = Math.max(0, Math.min(3, step));
    $preview.data('preview-step', current);
    $preview.find('[data-preview-step]').addClass('d-none');
    const $section = $preview.find('[data-preview-step="' + current + '"]').removeClass('d-none');
    $preview.find('[data-preview-indicator]').removeAttr('aria-current');
    $preview.find('[data-preview-indicator="' + current + '"]').attr('aria-current', 'step');
    $preview.find('[data-preview-back]').toggleClass('d-none', current === 0);
    $preview.find('[data-preview-restart]').toggleClass('d-none', current !== 3);
    $preview.find('[data-preview-next]').toggleClass('d-none', current === 3).text(
        current === 0 ? $preview.attr('data-first-button') : current === 1 ? 'تأیید و ادامه' : $preview.attr('data-second-button')
    );
    if (focus) $section.find('h5').first().trigger('focus');
}

function kerpRegistrationPreviewReset($preview, focus) {
    $preview.find('input').val('').prop('checked', false);
    $preview.find('select').prop('selectedIndex', 0);
    kerpRegistrationPreviewStep($preview, 0, focus);
}

$(document).on('shown.bs.modal', '[id^="kerpRegistrationPreview"]', function () {
    kerpRegistrationPreviewReset($(this).find('.kerp-registration-preview'), true);
});
$(document).on('hidden.bs.modal', '[id^="kerpRegistrationPreview"]', function () {
    kerpRegistrationPreviewReset($(this).find('.kerp-registration-preview'), false);
});
$(document).on('click', '.kerp-registration-preview [data-preview-next], .kerp-registration-preview [data-preview-back], .kerp-registration-preview [data-preview-restart]', function (event) {
    event.preventDefault();
    const $preview = $(this).closest('.kerp-registration-preview');
    if (this.hasAttribute('data-preview-restart')) { kerpRegistrationPreviewReset($preview, true); return; }
    kerpRegistrationPreviewStep($preview, (Number($preview.data('preview-step')) || 0) + (this.hasAttribute('data-preview-back') ? -1 : 1), true);
});
$(document).on('keydown', '.kerp-registration-preview input', function (event) {
    if (event.key === 'Enter') { event.preventDefault(); $(this).closest('.kerp-registration-preview').find('[data-preview-next]').trigger('click'); }
});
// Saved rich-text links stay inert, including middle-click, during the walkthrough.
$(document).on('click auxclick', '.kerp-registration-preview a', function (event) { event.preventDefault(); event.stopImmediatePropagation(); });



/* ===== leads-button-sms.js ===== */
// This nested repeater uses its own controls and template token so adding a button
// or a message never reindexes or removes the other repeater's rows.
function kerpButtonSmsCondition($row) {
    const field = String($row.find('[data-for$="[condition_field]"]').val() || '');
    const $root = $row.closest('.kerp-button-sms');
    let options = {};
    try { options = JSON.parse($root.attr('data-condition-options') || '{}'); } catch (_) {}
    const active = field !== '' && field !== '0' && Object.prototype.hasOwnProperty.call(options, field);
    const values = active && Array.isArray(options[field]) ? options[field] : [];
    const $value = $row.find('[data-for$="[condition_value]"]');
    $value.empty().append(new Option(values.length ? 'انتخاب مقدار شرط' : 'مقداری برای این فیلد ثبت نشده است', ''));
    values.forEach(function (value) { $value.append(new Option(String(value), String(value))); });
    $value.prop('disabled', !active).val('').trigger('change');
    $row.find('.kerp-button-sms-condition-value').toggleClass('d-none', !active);
}
$(document).on('change', '.kerp-button-sms-row [data-for$="[condition_field]"]', function () {
    kerpButtonSmsCondition($(this).closest('.kerp-button-sms-row'));
});
$(document).on('click', '.kerp-button-sms-add', function (event) {
    event.preventDefault();
    const $kerpSms = $(this).closest('.kerp-button-sms');
    const $kerpSmsRows = $kerpSms.children('.kerp-button-sms-rows');
    if ($kerpSmsRows.children().length >= 20) {
        NioApp.Toast('حداکثر ۲۰ پیامک برای هر دکمه تعریف کنید.', 'warning', {position: 'top-right'});
        return;
    }
    const kerpSmsIndex = Number($kerpSms.attr('data-next-index')) || 0;
    const kerpSmsTemplate = $kerpSms.children('template')[0];
    if (!kerpSmsTemplate) return;
    $kerpSmsRows.append(kerpSmsTemplate.innerHTML.replaceAll('__SMS_INDEX__', String(kerpSmsIndex)));
    $kerpSms.attr('data-next-index', kerpSmsIndex + 1);
    NioApp.Select2($kerpSmsRows.children().last().find('.js-select2'));
    $kerpSmsRows.children().last().find('input').first().trigger('focus');
});
$(document).on('click', '.kerp-button-sms-remove', function (event) {
    event.preventDefault();
    if (window.bootstrap && bootstrap.Tooltip) {
        const kerpSmsTooltip = bootstrap.Tooltip.getInstance(this);
        if (kerpSmsTooltip) kerpSmsTooltip.dispose();
    }
    const $kerpSmsRow = $(this).closest('.kerp-button-sms-row');
    if ($kerpSmsRow.siblings().length) $kerpSmsRow.remove();
    else {
        $kerpSmsRow.find('input, textarea, select').val('').trigger('change');
        kerpButtonSmsCondition($kerpSmsRow);
    }
});



/* ===== leads.js ===== */
    function kerpLeadsSyncPicker(picker) {
        const pipeline = picker.querySelector('[data-lead-pipeline]');
        const stage = picker.querySelector('[data-lead-stage]');
        if (!pipeline || !stage) return;
        Array.from(stage.options).forEach(function (option) {
            const visible = !option.dataset.pipeline || option.dataset.pipeline === pipeline.value;
            option.hidden = !visible;
            option.disabled = !visible;
        });
        if (!stage.selectedOptions.length || stage.selectedOptions[0].disabled) stage.value = '0';
    }
    document.addEventListener('change', function (event) {
        if (event.target.matches('[data-lead-pipeline]')) kerpLeadsSyncPicker(event.target.closest('.kerp-pipeline-picker'));
        if (event.target.matches('[data-lead-select-all]')) {
            event.target.closest('form').querySelectorAll('[data-for="user_ids"]').forEach(function (input) {
                input.checked = event.target.checked;
            });
        }
    });
    // ERP replaces page fragments without a full page load.
    const kerpLeadsObserver = new MutationObserver(function (records) {
        records.forEach(function (record) {
            record.addedNodes.forEach(function (node) {
                if (node.nodeType !== 1) return;
                if (node.matches('.kerp-pipeline-picker')) kerpLeadsSyncPicker(node);
                node.querySelectorAll('.kerp-pipeline-picker').forEach(kerpLeadsSyncPicker);
            });
        });
    });
    document.querySelectorAll('.kerp-pipeline-picker').forEach(kerpLeadsSyncPicker);
    kerpLeadsObserver.observe(document.body, { childList: true, subtree: true });

// Preserve shared form/bulk behavior and add only the leads CSRF token.
function kerpLeadsFilterStages($root, reset) {
    const $filter = $root.find('.filter_form_wrapper');
    const campaign = String($filter.find('[data-for="campaign_id"]').val() || '');
    const $stage = $filter.find('[data-for="stage_id"]');
    const previous = reset ? '' : String($stage.val() || '');
    let stages = [];
    try { stages = JSON.parse($root.attr('data-lead-filter-stages') || '[]'); } catch (error) { return; }
    $stage.empty().append(new Option('همه مراحل', ''));
    stages.filter(item => String(item.campaign_id) === campaign).forEach(item => $stage.append(new Option(item.name, item.id)));
    $stage.val(previous).prop('disabled', !campaign || campaign === '0');
    if (!$stage.val()) $stage.val('');
    $stage.trigger('change.select2');
}
$(document).on('change', '.kerp-leads-list .filter_form_wrapper [data-for="campaign_id"]', function() {
    kerpLeadsFilterStages($(this).closest('.kerp-leads-list'), true);
});
$(document).on('shown.bs.dropdown', '.kerp-leads-list .dropdown', function() {
    if ($(this).find('.filter_form_wrapper').length) kerpLeadsFilterStages($(this).closest('.kerp-leads-list'), false);
});
$(document).on('click', '.kerp-leads-open-branch', function(event) {
    event.preventDefault();
    const $root = $(this).closest('.kerp-leads-list');
    const ids = $root.find('.kerp-lead-member-select:checked').map(function() { return this.value; }).get();
    if (!ids.length) { NioApp.Toast('حداقل یک عضو را انتخاب کنید.', 'warning', {position: 'top-right'}); return; }
    const $modal = $root.find('#kerpLeadsBranch');
    const $inputs = $modal.find('.kerp-leads-selected-inputs').empty();
    ids.forEach(id => $('<input>', {type: 'checkbox', 'data-for': 'user_ids', value: id, class: 'no_clear', checked: true, hidden: true}).appendTo($inputs));
    $modal.find('.kerp-leads-selection-count').text(ids.length.toLocaleString('fa-IR') + ' عضو انتخاب شده');
    $modal.find('.submit_modal_form').attr({role: 'button', tabindex: '0'});
    $modal.modal('show');
});
$(document).on('keydown', '#kerpLeadsBranch .submit_modal_form', function(event) {
    if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); $(this).trigger('click'); }
});
$(document).on('submit', '#kerpLeadsBranch form', function(event) { event.preventDefault(); $(this).find('.submit_modal_form').trigger('click'); });
$.ajaxPrefilter(function(options) {
    if (typeof options.data === 'string' && /(?:^|&)action=leads_pipeline_bulk(?:&|$)/.test(options.data)) {
        options.data += '&leads_nonce=' + encodeURIComponent($('.kerp-pipelines[data-leads-nonce]').attr('data-leads-nonce') || '');
    }
});
$(document).on('show.bs.modal', '[id^="kerpPipeline"]', function() {
    $(this).find('.submit_modal_form').attr({role: 'button', tabindex: '0'});
    kerpLeadsSyncTrigger($(this).find('.modal_form'));
    const $kerpActionForm = $(this).find('form[data-action="leads_save_stage_actions"]');
    if ($kerpActionForm.length) evaluateAll($kerpActionForm);
});
function kerpLeadsSyncTrigger($form) {
    const trigger = $form.find('[data-for="stage[trigger_type]"]').val();
    [['.kerp-lead-form-field', 'gravity_form'], ['.kerp-lead-product-field', 'product_purchase'], ['.kerp-lead-lesson-field', 'learndash_completed']].forEach(function(entry) {
        const $row = $form.find(entry[0]);
        const visible = trigger === entry[1];
        $row.toggleClass('d-none', !visible);
        $row.find('select,input').prop('disabled', !visible);
        $row.find('[data-for]').attr('data-req', visible ? '1' : '0');
        if (!visible) $row.find('select.select2-hidden-accessible').select2('close');
        if (!visible && $row.hasClass('kerp-lead-product-picker')) kerpLeadsCancelProduct($row);
    });
}
$(document).on('change', '[id^="kerpPipelineStage"] [data-for="stage[trigger_type]"]', function() {
    kerpLeadsSyncTrigger($(this).closest('form'));
});
function kerpLeadsCancelProduct($picker) {
    clearTimeout($picker.data('searchTimer'));
    $picker.data('searchVersion', ($picker.data('searchVersion') || 0) + 1);
    const request = $picker.data('searchRequest');
    if (request) request.abort();
    $picker.removeData('searchRequest');
    $picker.find('.kerp-lead-product-results').empty().prop('hidden', true);
}
$(document).on('input', '.kerp-lead-product-search', function() {
    const $picker = $(this).closest('.kerp-lead-product-picker');
    kerpLeadsCancelProduct($picker);
    $picker.find('[data-for]').val('');
    const term = this.value.trim();
    const $status = $picker.find('.kerp-lead-product-status');
    const resource = $picker.attr('data-resource-label') || 'محصول';
    $status.text(term.length < 2 ? 'برای جستجو حداقل دو حرف بنویسید.' : 'در حال جستجو…');
    if (term.length < 2) return;
    const version = $picker.data('searchVersion');
    const current = () => $picker[0].isConnected && version === $picker.data('searchVersion') && !$picker.hasClass('d-none') && $picker.closest('.modal').hasClass('show');
    $picker.data('searchTimer', setTimeout(function() {
        if (!current()) return;
        const $form = $picker.closest('form');
        $picker.data('searchRequest', $.ajax({url: ajax_url, type: 'POST', dataType: 'json', data: {
            action: $picker.attr('data-search-action') || 'leads_search_products', search: term, leads_nonce: $form.find('[data-for="leads_nonce"]').val()
        }}).done(function(response) {
            if (!current()) return;
            if (!response || response.status === 'error' || !Array.isArray(response.results)) {
                $status.text(response && (response.message || response.msg) || 'جستجو انجام نشد؛ دوباره تلاش کنید.'); return;
            }
            const $results = $picker.find('.kerp-lead-product-results').empty();
            response.results.forEach(function(item) {
                $('<button>', {type: 'button', class: 'list-group-item list-group-item-action kerp-lead-product-result'}).text(item.text).attr('data-product-id', item.id).appendTo($results);
            });
            $results.prop('hidden', !response.results.length);
            $status.text(response.results.length ? resource + ' موردنظر را انتخاب کنید؛ برای نتایج دقیق‌تر نام کامل‌تری بنویسید.' : 'نتیجه‌ای پیدا نشد.');
        }).fail(function(xhr, status) {
            if (current() && status !== 'abort') $status.text(xhr.responseJSON && (xhr.responseJSON.message || xhr.responseJSON.msg) || 'دریافت نتایج ناموفق بود؛ دوباره جستجو کنید.');
        }));
    }, 300));
});
$(document).on('click', '.kerp-lead-product-result', function() {
    const $picker = $(this).closest('.kerp-lead-product-picker');
    const id = $(this).attr('data-product-id'), label = $(this).text();
    kerpLeadsCancelProduct($picker);
    $picker.find('[data-for]').val(id).trigger('change');
    $picker.find('.kerp-lead-product-search').val(label).trigger('focus');
    $picker.find('.kerp-lead-product-status').text(($picker.attr('data-resource-label') || 'محصول') + ' انتخاب شده است.');
});
$(document).on('click', '.kerp-lead-product-clear', function() {
    $(this).closest('.kerp-lead-product-picker').find('.kerp-lead-product-search').val('').trigger('input').trigger('focus');
});
$(document).on('keydown', '.kerp-lead-product-search, .kerp-lead-product-result', function(event) {
    const $picker = $(this).closest('.kerp-lead-product-picker');
    const $results = $picker.find('.kerp-lead-product-result');
    const index = $results.index(this);
    if (event.key === 'Escape') { event.preventDefault(); event.stopPropagation(); kerpLeadsCancelProduct($picker); $picker.find('.kerp-lead-product-search').trigger('focus'); }
    if (event.key === 'Enter' && $(this).hasClass('kerp-lead-product-search')) { event.preventDefault(); $results.first().trigger('focus'); }
    if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
        event.preventDefault();
        const next = event.key === 'ArrowDown' ? Math.min(index + 1, $results.length - 1) : index - 1;
        if (next < 0) $picker.find('.kerp-lead-product-search').trigger('focus'); else $results.eq(next).trigger('focus');
    }
});
$(document).on('hide.bs.modal', '[id^="kerpPipelineStage"]', function() {
    $(this).find('.kerp-lead-product-picker').each(function() { kerpLeadsCancelProduct($(this)); });
});
$(document).on('keydown', '[id^="kerpPipeline"] .submit_modal_form', function(event) {
    if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); $(this).trigger('click'); }
});
$(document).on('submit', '[id^="kerpPipeline"] .modal_form', function(event) {
    event.preventDefault();
    $(this).find('.submit_modal_form').first().trigger('click');
});

$(document).on('click', '.kerp-leads-open-bulk', function(event) {
    event.preventDefault();
    const root = $(this).closest('.kerp-leads-list');
    const operation = $(this).attr('data-operation');
    if (!['owner', 'stage', 'exit', 'course'].includes(operation)) return;
    const ids = root.find('.kerp-lead-member-select:checked').map(function() { return $(this).attr('data-membership-id'); }).get();
    if (!ids.length) { NioApp.Toast('حداقل یک ردیف را انتخاب کنید.', 'warning', {position: 'top-right'}); return; }
    const modal = root.find({owner: '#kerpLeadsBulkOwner', stage: '#kerpLeadsBulkStage', exit: '#kerpLeadsBulkExit', course: '#kerpLeadsBulkCourse'}[operation]);
    modal.find('[data-for="confirm_replace"], [data-for="confirm_exit"], [data-for="confirm_course"]').prop('checked', false);
    const inputs = modal.find('.kerp-leads-selected-inputs').empty();
    ids.forEach(id => $('<input>', {type: 'checkbox', 'data-for': 'membership_ids', value: id, checked: true, hidden: true, class: 'no_clear'}).appendTo(inputs));
    modal.find('.kerp-leads-selection-count').text(ids.length.toLocaleString('fa-IR') + ' ردیف انتخاب شده');
    modal.find('.submit_modal_form').attr({role: 'button', tabindex: '0'});
    modal.modal('show');
});
$(document).on('keydown', '[id^="kerpLeadsBulk"] .submit_modal_form', function(event) {
    if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); $(this).trigger('click'); }
});



/* ===== legacy-taxonomy-migration.js ===== */
(function() {
    'use strict';

    document.addEventListener('click', async function(event) {
        const button = event.target.closest('[data-tax-migrate]');
        if (!button) return;
        event.preventDefault();

        const root = button.closest('#kerp-legacy-taxonomy-migration');
        if (!root || root.dataset.running === '1') return;

        root.dataset.running = '1';
        button.disabled = true;
        const label = button.querySelector('span');
        const message = root.querySelector('[data-tax-message]');
        label.textContent = 'در حال انتقال…';
        message.classList.remove('text-danger');

        try {
            let workRemaining = 1;

            while (workRemaining > 0 && document.documentElement.contains(root)) {
                const body = new URLSearchParams({
                    action: 'customers_migrate_legacy_taxonomies',
                    migration_nonce: root.dataset.nonce || ''
                });
                const response = await fetch(window.KERPData?.ajaxUrl || '', {
                    method: 'POST',
                    credentials: 'same-origin',
                    cache: 'no-store',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'},
                    body: body.toString()
                });
                const payload = await response.json();

                if (!response.ok || payload?.status !== 'success' || !payload.data) {
                    throw new Error(payload?.message || payload?.msg || 'انتقال انجام نشد.');
                }

                const remaining = Number(payload.data.remaining || 0);
                workRemaining = Number(payload.data.work_remaining || 0);
                root.querySelector('[data-tax-term-total]').textContent = Number(payload.data.term_total || 0).toLocaleString('fa-IR');
                root.querySelector('[data-tax-owner-total]').textContent = Number(payload.data.owner_total || 0).toLocaleString('fa-IR');
                root.querySelector('[data-tax-total]').textContent = Number(payload.data.total || 0).toLocaleString('fa-IR');
                root.querySelector('[data-tax-remaining]').textContent = remaining.toLocaleString('fa-IR');
                message.textContent = remaining > 0
                    ? remaining.toLocaleString('fa-IR') + ' کاربر باقی مانده است…'
                    : 'انتقال گزینه‌ها و مقادیر کاربران کامل شد؛ اطلاعات قدیمی حفظ شده است.';

                if (remaining > 0 && Number(payload.data.copied || 0) === 0) {
                    throw new Error('کاربری منتقل نشد؛ ارتباط‌های taxonomy قدیمی را بررسی کنید.');
                }
            }

            label.textContent = 'انتقال کامل است';
        } catch (error) {
            message.classList.add('text-danger');
            message.textContent = error.message || 'انتقال انجام نشد.';
            button.disabled = false;
            label.textContent = 'ادامه انتقال';
        } finally {
            root.dataset.running = '0';
        }
    });
})();



/* ===== marketing.js ===== */
// Marketing uses the shared modal, list, selection and AJAX lifecycle.
function kerpMarketingNumber(value) {
    return Number(String(value || '').replace(/[۰-۹]/g, function(d) { return '۰۱۲۳۴۵۶۷۸۹'.indexOf(d); }).replace(/[٠-٩]/g, function(d) { return '٠١٢٣٤٥٦٧٨٩'.indexOf(d); }).replace(/[,٬\s]/g, ''));
}
function kerpMarketingRoi() {
    const $modal = $('#marketingRequestModal');
    const cost = kerpMarketingNumber($modal.find('[data-for="cost"]').val());
    const sales = kerpMarketingNumber($modal.find('[data-for="expected_sales"]').val());
    $modal.find('[data-marketing-roi]').text(cost > 0 && sales >= 0 && Number.isFinite(sales / cost) ? (sales / cost).toLocaleString('fa-IR', {maximumFractionDigits: 2}) : '—');
}
$(document).on('input', '#marketingRequestModal [data-for="cost"], #marketingRequestModal [data-for="expected_sales"]', kerpMarketingRoi);
$(document).on('shown.bs.modal', '#marketingRequestModal', kerpMarketingRoi);
$(document).on('blur', '#marketingRequestModal [data-for="execution_date"]', function() {
    this.value = this.value.replace(/[۰-۹]/g, function(d) { return '۰۱۲۳۴۵۶۷۸۹'.indexOf(d); }).replace(/[٠-٩]/g, function(d) { return '٠١٢٣٤٥٦٧٨٩'.indexOf(d); }).replace(/\//g, '-');
});
function kerpMarketingDailyEntry() {
    const $modal = $('#marketingMetricModal');
    const source = $modal.find('[data-for="source_id"]').val();
    const rawDate = String($modal.find('[data-for="metric_date"]').val() || '');
    let date = rawDate.replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/\//g, '-');
    date = date.trim().split('-').map((part, index) => index ? part.trim().padStart(2, '0') : part.trim()).join('-');
    const selection = source + ':' + date;
    if ($modal.data('daily-selection') === selection) return;
    $modal.data('daily-selection', selection);
    let entries = [];
    try { entries = JSON.parse($modal.find('[data-marketing-daily]').attr('data-marketing-daily') || '[]'); } catch (error) { return; }
    const entry = entries.find(item => item.source_id === source && item.jalali_date === date);
    $modal.find('[data-for="entry_key"]').val(entry ? entry.entry_key : '');
    ['numbers', 'online', 'pre_reg', 'cost', 'sales'].forEach(key => $modal.find('[data-for="' + key + '"]').val(entry ? entry[key] : '').trigger('input'));
    $modal.find('[data-marketing-daily-hint]').text(entry ? 'آمار این روز قبلاً ثبت شده است؛ در حال ویرایش همان روز هستید.' : 'فقط آمار همین روز را وارد کنید؛ جمع روزها خودکار محاسبه می‌شود.');
}
$(document).on('change blur', '#marketingMetricModal [data-for="source_id"], #marketingMetricModal [data-for="metric_date"]', kerpMarketingDailyEntry);
$(document).on('show.bs.modal', '[id^="marketing"]', function() {
    $(this).find('.submit_modal_form').attr({role: 'button', tabindex: '0'});
    $(this).find('.price_input').attr({'data-decimal': '1', 'data-decimal-places': '2', inputmode: 'decimal'}).data('decimal', 1).data('decimal-places', 2).trigger('input');
});
$(document).on('keydown', '[id^="marketing"] .submit_modal_form', function(event) {
    if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); $(this).trigger('click'); }
});
$(document).on('submit', '.modal_form[data-action^="marketing_"]', function(event) {
    event.preventDefault();
    $(this).find('.submit_modal_form').first().trigger('click');
});
// The shared bulk component sends its own payload; attach this module's CSRF token only.
$.ajaxPrefilter(function(options) {
    if (typeof options.data === 'string' && /(?:^|&)action=marketing_bulk(?:&|$)/.test(options.data)) {
        options.data += '&marketing_nonce=' + encodeURIComponent($('.kerp-marketing[data-marketing-nonce]').attr('data-marketing-nonce') || '');
    }
});



/* ===== orders-index-backfill.js ===== */
const kerpOrdersBackfillNumber = new Intl.NumberFormat('fa-IR');

async function kerpOrdersRunBackfill(root, button) {
    if (root.dataset.running === '1') return;
    root.dataset.running = '1';
    root.setAttribute('aria-busy', 'true');
    button.disabled = true;
    const label = button.querySelector('span');
    const message = root.querySelector('[data-orders-backfill-message]');
    const bar = root.querySelector('[data-orders-backfill-bar]');
    if (!root.dataset.nextPage) {
        bar.style.width = '0%';
        bar.setAttribute('aria-valuenow', '0');
        root.querySelector('[data-orders-backfill-percent]').textContent = '۰٪';
        root.querySelector('[data-orders-backfill-count]').textContent = 'آماده شروع';
    }
    label.textContent = 'در حال همگام‌سازی…';
    message.classList.remove('text-danger');
    bar.classList.remove('bg-success');
    bar.classList.add('bg-primary', 'progress-bar-striped', 'progress-bar-animated');
    message.textContent = 'سفارش‌ها در دسته‌های ۱۰۰تایی پردازش می‌شوند؛ این صفحه را باز نگه دارید.';
    let completed = false;

    try {
        while (root.isConnected) {
            const page = Number(root.dataset.nextPage) || 1;
            const response = await fetch(window.KERPData?.ajaxUrl || ajax_url, {
                method: 'POST',
                credentials: 'same-origin',
                cache: 'no-store',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
                body: new URLSearchParams({
                    action: 'orders_backfill_index',
                    backfill_nonce: root.dataset.nonce || '',
                    batch_page: String(page)
                }).toString()
            });
            const payload = await response.json();
            if (!root.isConnected) return;
            if (!response.ok || payload?.status !== 'success' || !payload.data) {
                throw new Error(payload?.message || payload?.msg || 'همگام‌سازی انجام نشد. دوباره تلاش کنید.');
            }
            const data = payload.data;
            if (Number(data.current_page) !== page || !Number.isFinite(Number(data.total)) || typeof data.done !== 'boolean') {
                throw new Error('پاسخ سرور نامعتبر است. دوباره تلاش کنید.');
            }
            const total = Math.max(0, Number(data.total));
            const processed = Math.min(total, Math.max(0, Number(data.processed) || 0));
            const percent = data.done ? 100 : total > 0 ? Math.min(99, Math.floor(processed * 100 / total)) : 0;
            bar.style.width = percent + '%';
            bar.setAttribute('aria-valuenow', String(percent));
            root.querySelector('[data-orders-backfill-percent]').textContent = kerpOrdersBackfillNumber.format(percent) + '٪';
            root.querySelector('[data-orders-backfill-count]').textContent = kerpOrdersBackfillNumber.format(processed) + ' از ' + kerpOrdersBackfillNumber.format(total) + ' سفارش';
            if (data.done) {
                completed = true;
                delete root.dataset.nextPage;
                bar.classList.replace('bg-primary', 'bg-success');
                message.textContent = total ? 'همگام‌سازی همه سفارش‌ها کامل شد.' : 'سفارشی برای همگام‌سازی وجود ندارد.';
                break;
            }
            root.dataset.nextPage = String(page + 1);
        }
    } catch (error) {
        if (root.isConnected) {
            message.classList.add('text-danger');
            message.textContent = error.message || 'ارتباط با سرور قطع شد. برای ادامه دوباره تلاش کنید.';
        }
    } finally {
        root.dataset.running = '0';
        root.setAttribute('aria-busy', 'false');
        bar.classList.remove('progress-bar-striped', 'progress-bar-animated');
        if (root.isConnected) {
            button.disabled = false;
            label.textContent = completed ? 'همگام‌سازی مجدد' : 'ادامه همگام‌سازی';
        }
    }
}

document.addEventListener('click', function (event) {
    const button = event.target.closest('[data-orders-backfill-start]');
    if (!button) return;
    const root = button.closest('#kerp-orders-index-backfill');
    if (root) kerpOrdersRunBackfill(root, button);
});



/* ===== orders.js ===== */
function product_search_get_scope(element) {
    return $(element).closest('.product_search');
}

function product_search_get_config(scope) {
    return {
        searchAction: scope.attr('data-search-action') || '',
        loadAction:   scope.attr('data-load-action') || '',
        searchParam:  scope.attr('data-search-param') || 'search',
        itemParam:    scope.attr('data-item-param') || 'product_id',
        minChars:     parseInt(scope.attr('data-min-chars') || '2', 10),
        listTarget:   scope.attr('data-list-target') || '.product_search_list',
        resultTarget: scope.attr('data-result-target') || '.product_search_result',
    };
}

function product_search_abort(scope) {
    let request = scope.data('product-search-request');
    
    if (!request) {
        return;
    }
    
    request.abort();
    scope.removeData('product-search-request');
}

function product_search_clear(scope, clearResult) {
    let config = product_search_get_config(scope);
    
    scope.find(config.listTarget).html('');
    
    if (clearResult) {
        scope.find(config.resultTarget).html('');
    }
}

function product_search_request(input) {
    let element = $(input);
    let scope = product_search_get_scope(element);
    let config = product_search_get_config(scope);
    let search = $.trim(element.val());
    
    if (!scope.length || !config.searchAction) {
        return;
    }
    
    if (search.length < config.minChars) {
        product_search_abort(scope);
        product_search_clear(scope, search.length === 0);
        return;
    }
    
    product_search_abort(scope);
    
    let data = {
        action: config.searchAction,
    };
    
    data[config.searchParam] = search;
    
    ajax_search = true;
    
    let request = $.post(
        ajax_url,
        data,
    );
    
    scope.data(
        'product-search-request',
        request,
    );
    
    request.done(function(response) {
        if (response.status === 'success') {
            scope.find(config.listTarget).html('');
            scope.find(config.resultTarget).html(response.html || '');
            
            NioApp.NumberSpinner();
            
            return;
        }
        
        if (response.status === 'list') {
            scope.find(config.listTarget).html(response.html || '');
            
            return;
        }
        
        NioApp.Toast(
            response.message || 'خطا در جستجوی محصول',
            response.status || 'error',
            {
                position: 'top-right',
            },
        );
        
        element.val('');
        product_search_clear(scope, true);
    });
    
    request.fail(function(xhr, status) {
        if (status === 'abort') {
            return;
        }
        
        NioApp.Toast(
            'خطا در ارتباط با سرور',
            'error',
            {
                position: 'top-right',
            },
        );
    });
    
    request.always(function() {
        if (
            scope.data('product-search-request') === request
        ) {
            scope.removeData('product-search-request');
        }
        
        ajax_search = false;
    });
}

function product_search_load_item(element) {
    let item = $(element);
    let scope = product_search_get_scope(item);
    let config = product_search_get_config(scope);
    let itemId = item.attr('data-id');
    
    if (
        !scope.length
        || !config.loadAction
        || !itemId
    ) {
        return;
    }
    
    product_search_abort(scope);
    
    let data = {
        action: config.loadAction,
    };
    
    data[config.itemParam] = itemId;
    
    ajax_search = true;
    
    let request = $.post(
        ajax_url,
        data,
    );
    
    scope.data(
        'product-search-request',
        request,
    );
    
    request.done(function(response) {
        if (response.status !== 'success') {
            NioApp.Toast(
                response.message || 'خطا در دریافت اطلاعات محصول',
                response.status || 'error',
                {
                    position: 'top-right',
                },
            );
            
            return;
        }
        
        scope.find(config.listTarget).html('');
        scope.find(config.resultTarget).html(response.html || '');
        scope.find('.product_search_input').val('');
        
        NioApp.NumberSpinner();
    });
    
    request.fail(function(xhr, status) {
        if (status === 'abort') {
            return;
        }
        
        NioApp.Toast(
            'خطا در ارتباط با سرور',
            'error',
            {
                position: 'top-right',
            },
        );
    });
    
    request.always(function() {
        if (
            scope.data('product-search-request') === request
        ) {
            scope.removeData('product-search-request');
        }
        
        ajax_search = false;
    });
}

function product_search_schedule(input) {
    let element = $(input);
    let timer = element.data('product-search-timer');
    
    if (timer) {
        clearTimeout(timer);
    }
    
    timer = setTimeout(function() {
        product_search_request(element);
    }, 300);
    
    element.data(
        'product-search-timer',
        timer,
    );
}

$(document).on('input', '.product_search_input', function() {
    product_search_schedule(this);
});

$(document).on('click', '.product_search_item', function(e) {
    e.preventDefault();
    product_search_load_item(this);
});

function order_factor_get_form(element) {
    return $(element).closest('.modal_form');
}

function order_factor_get_items_wrapper(form) {
    return form.find('.kerp-order-items-wrapper').first();
}

function order_factor_get_next_index(wrapper) {
    let index = parseInt(wrapper.attr('data-next-index') || '0', 10);
    
    if (Number.isNaN(index) || index < 0) {
        index = 0;
    }
    
    wrapper.attr('data-next-index', index + 1);
    
    return index;
}

function order_factor_get_product_row(form, productId) {
    let row = $();
    
    form.find('.kerp-order-item-row').each(function() {
        if (String($(this).attr('data-product')) === String(productId)) {
            row = $(this);
            return false;
        }
    });
    
    return row;
}

function order_factor_update_empty_state(form) {
    let hasItems = form.find('.kerp-order-items-body .kerp-order-item-row').length > 0;
    
    form.find('.kerp-order-items-empty').toggleClass(
        'd-none',
        hasItems,
    );
}

function order_factor_add_product(button) {
    let source = $(button).closest('.product_factor_source');
    let form = order_factor_get_form(button);
    let wrapper = order_factor_get_items_wrapper(form);
    let tbody = wrapper.find('.kerp-order-items-body').first();
    let template = source.find('.product_factor_row_template').html();
    
    let productId = parseInt(source.attr('data-product-id') || '0', 10);
    let maxQty = sanitizeNumber(source.attr('data-max-qty'), true);
    let qty = sanitizeNumber(
        source.find('.product_factor_qty').val(),
        true,
    );
    
    if (!productId || !qty || qty <= 0) {
        return;
    }
    
    if (maxQty > 0 && qty > maxQty) {
        qty = maxQty;
    }
    
    let existingRow = order_factor_get_product_row(
        form,
        productId,
    );
    
    if (existingRow.length) {
        let qtyInput = existingRow.find('.line_qty').first();
        let currentQty = sanitizeNumber(
            qtyInput.val(),
            true,
        );
        
        let newQty = currentQty + qty;
        
        if (maxQty > 0 && newQty > maxQty) {
            newQty = maxQty;
        }
        
        qtyInput.val(newQty);
        
        calc_factor_total(form);
        
        form.trigger(
            'kerp_order_item_quantity_updated',
            [
                existingRow,
                productId,
                newQty,
            ],
        );
        
        return;
    }
    
    if (!template) {
        NioApp.Toast(
            'قالب ردیف محصول پیدا نشد.',
            'error',
            {
                position: 'top-right',
            },
        );
        
        return;
    }
    
    let index = order_factor_get_next_index(wrapper);
    
    template = template.replaceAll('__INDEX__', index).replaceAll('__QTY__', qty);
    
    tbody.append(template);
    
    let newRow = tbody.find('.kerp-order-item-row').last();
    
    order_factor_update_empty_state(form);
    calc_factor_total(form);
    
    source.find('.product_factor_qty').val('1');
    
    form.trigger(
        'kerp_order_item_added',
        [
            newRow,
            productId,
        ],
    );
}

$(document).on('click', '.add_product_to_factor', function(e) {
    e.preventDefault();
    
    order_factor_add_product(this);
});

function order_factor_get_summary_row_value(row) {
    let input = row.find('[data-for]').first();
    
    if (input.length) {
        return sanitizeNumber(
            input.val(),
            true
        );
    }
    
    let dataValue = row.attr('data-summary-value');
    
    if (dataValue !== undefined && dataValue !== '') {
        return sanitizeNumber(
            dataValue,
            true
        );
    }
    
    let valueElement = row.find(
        '.kerp-order-summary-value, .kerp-order-fee-value'
    ).first();
    
    if (valueElement.length) {
        return sanitizeNumber(
            valueElement.text(),
            true
        );
    }
    
    return 0;
}

function order_factor_get_summary_row_key(row) {
    let key = row.attr('data-summary-key')
        || row.attr('data-fee-key')
        || '';
    
    if (key) {
        return key;
    }
    
    let input = row.find('[data-for]').first();
    
    if (!input.length) {
        return '';
    }
    
    return input.attr('data-for') || '';
}

function order_factor_get_summary_row_effect(row) {
    let effect = row.attr('data-summary-effect')
        || row.attr('data-fee-effect')
        || 'increase';
    
    return effect === 'decrease'
           ? 'decrease'
           : 'increase';
}

function order_factor_update_summary_row_display(row, value) {
    let display = row.find(
        '.kerp-order-summary-value, .kerp-order-fee-value'
    ).first();
    
    if (display.length) {
        kerp_price_update(display, Math.abs(value));
    }
    
    if (row.attr('data-hide-zero') === '1') {
        row.toggleClass(
            'd-none',
            value === 0
        );
    }
}

function order_factor_calculate_summary_rows(form, baseTotal) {
    let total = baseTotal;
    let increase = 0;
    let decrease = 0;
    let rows = {};
    
    form.find(
        '.kerp-order-summary-row[data-summary-effect], ' +
        '.kerp-order-summary-row[data-fee-effect]'
    ).each(function() {
        let row = $(this);
        let key = order_factor_get_summary_row_key(row);
        let effect = order_factor_get_summary_row_effect(row);
        let value = Math.max(
            0,
            order_factor_get_summary_row_value(row)
        );
        
        order_factor_update_summary_row_display(
            row,
            value
        );
        
        if (key) {
            rows[key] = {
                value:  value,
                effect: effect,
            };
        }
        
        if (!value) {
            return;
        }
        
        if (effect === 'decrease') {
            total -= value;
            decrease += value;
            return;
        }
        
        total += value;
        increase += value;
    });
    
    return {
        total:    total,
        increase: increase,
        decrease: decrease,
        rows:     rows,
    };
}

function order_factor_resolve_form(scope) {
    if (scope && scope.jquery) {
        if (scope.is('.modal_form')) {
            return scope;
        }
        
        let form = scope.closest('.modal_form');
        
        if (form.length) {
            return form;
        }
    }
    
    if (scope) {
        let form = $(scope).closest('.modal_form');
        
        if (form.length) {
            return form;
        }
    }
    
    return $('.modal_form .order_factor_card')
    .first()
    .closest('.modal_form');
}

function calc_factor_total(scope) {
    let form = order_factor_resolve_form(scope);
    
    if (!form.length) {
        return;
    }
    
    let card = form.find('.order_factor_card').first();
    let regularTotal = 0;
    let itemsTotal = 0;
    
    card.find('.kerp-order-item-row').each(function() {
        let row = $(this);
        
        let qty = sanitizeNumber(
            row.find('.line_qty').val(),
            true
        );
        
        let regularPrice = sanitizeNumber(
            row.find('.item_reg_total').val(),
            true
        );
        
        let offPercent = sanitizeNumber(
            row.find('.item_off_percent').val(),
            true
        );
        
        qty = Math.max(0, qty);
        regularPrice = Math.max(0, regularPrice);
        offPercent = Math.max(
            0,
            Math.min(100, offPercent)
        );
        
        let finalUnitPrice = regularPrice * (
            (100 - offPercent) / 100
        );
        
        let regularLineTotal = regularPrice * qty;
        let lineTotal = finalUnitPrice * qty;
        
        row.find('.item_subtotal').val(
            number_format(finalUnitPrice)
        );
        
        row.find('.item_regular_line_total').val(
            regularLineTotal
        );
        
        row.find('.line_total').val(
            number_format(lineTotal)
        );
        
        regularTotal += regularLineTotal;
        itemsTotal += lineTotal;
    });
    
    let itemsDiscount = Math.max(
        0,
        regularTotal - itemsTotal
    );
    
    kerp_price_update(form.find('.order_subtotal'), regularTotal);
    
    kerp_price_update(form.find('.order_discount'), itemsDiscount);
    
    kerp_price_update(form.find('.order_total'), itemsTotal);
    
    let summary = order_factor_calculate_summary_rows(
        form,
        itemsTotal
    );
    
    let finalTotal = Math.max(
        0,
        summary.total
    );
    
    kerp_price_update(form.find('.order_total_final'), finalTotal);
    
    let shippingTotal = 0;
    
    if (
        summary.rows.shipping_total
        && summary.rows.shipping_total.value
    ) {
        shippingTotal = summary.rows.shipping_total.value;
    }
    
    form.trigger(
        'kerp_order_totals_calculated',
        [
            {
                items_regular_total: regularTotal,
                items_discount:      itemsDiscount,
                items_total:         itemsTotal,
                shipping_total:      shippingTotal,
                summary_increase:    summary.increase,
                summary_decrease:    summary.decrease,
                summary_rows:        summary.rows,
                final_total:         finalTotal,
            },
        ]
    );
}

$(document).on(
    'input change',
    '.modal_form .order_factor_card .line_qty, ' +
    '.modal_form .order_factor_card .item_reg_total, ' +
    '.modal_form .order_factor_card .item_off_percent, ' +
    '.modal_form .kerp-order-summary-row[data-summary-effect] [data-for], ' +
    '.modal_form .kerp-order-summary-row[data-fee-effect] [data-for]',
    function() {
        calc_factor_total(
            $(this).closest('.modal_form')
        );
    }
);

$(document).on('click', '.delete_factor_row', function(e) {
    e.preventDefault();
    
    let form = order_factor_get_form(this);
    let row = $(this).closest('.kerp-order-item-row');
    
    if (!form.length || !row.length) {
        return;
    }
    
    row.remove();
    
    order_factor_update_empty_state(form);
    calc_factor_total(form);
    
    form.trigger(
        'kerp_order_item_removed'
    );
});



/* ===== panel-navigation.js ===== */
// Shared scope is supplied by the ERP builder.
function kerpPanelNavigationPreview(kerpPanelRow) {
    const kerpPanelIcon = String(kerpPanelRow.find('.kerp-panel-navigation-icon').val() || '').trim() || kerpPanelRow.attr('data-default-icon');
    const kerpPanelPreview = kerpPanelRow.find('.kerp-panel-navigation-preview');
    const kerpPanelTitle = String(kerpPanelRow.find('.kerp-panel-navigation-title').val() || '').trim() || kerpPanelRow.attr('data-default-title');
    kerpPanelRow.find('.kerp-panel-navigation-preview-title').text(kerpPanelTitle);
    if (!kerpPanelIcon || /^[a-zA-Z0-9_-]+(?:\s+[a-zA-Z0-9_-]+)*$/.test(kerpPanelIcon)) {
        kerpPanelPreview.attr('class', 'icon kerp-panel-navigation-preview ' + kerpPanelIcon);
    }
}
$(document).on('input', '.kerp-panel-navigation-form input', function() {
    kerpPanelNavigationPreview($(this).closest('.kerp-panel-navigation-row'));
});
$(document).on('click', '.kerp-panel-navigation-reset', function() {
    const kerpPanelRow = $(this).closest('.kerp-panel-navigation-row');
    kerpPanelRow.find('.kerp-panel-navigation-title').val(kerpPanelRow.attr('data-default-title'));
    kerpPanelRow.find('.kerp-panel-navigation-icon').val(kerpPanelRow.attr('data-default-icon'));
    kerpPanelNavigationPreview(kerpPanelRow);
    kerpPanelRow.closest('form').find('.kerp-panel-navigation-feedback').text('مقادیر پیش‌فرض آماده‌اند؛ برای ثبت، ذخیره تغییرات را بزنید.');
});

$(document).on('submit', '.kerp-panel-navigation-form', function(kerpPanelEvent) {
    kerpPanelEvent.preventDefault();
    const kerpPanelForm = $(this);
    if (kerpPanelForm.data('saving')) { return; }
    const kerpPanelPayload = {};
    kerpPanelForm.find('.kerp-panel-navigation-row').each(function() {
        const kerpPanelRow = $(this);
        kerpPanelPayload[kerpPanelRow.attr('data-page')] = {
            title: String(kerpPanelRow.find('.kerp-panel-navigation-title').val() || '').trim(),
            icon: String(kerpPanelRow.find('.kerp-panel-navigation-icon').val() || '').trim(),
        };
    });
    const kerpPanelButton = kerpPanelForm.find('.kerp-panel-navigation-save');
    const kerpPanelFeedback = kerpPanelForm.find('.kerp-panel-navigation-feedback');
    kerpPanelForm.data('saving', true).attr('aria-busy', 'true');
    kerpPanelButton.prop('disabled', true);
    kerpPanelFeedback.text('در حال ذخیره…');
    $.post(ajax_url, {
        action: 'panel_navigation_save',
        nonce: kerpPanelForm.attr('data-nonce'),
        settings_payload: JSON.stringify(kerpPanelPayload),
    }).done(function(kerpPanelResponse) {
        const kerpPanelSuccess = kerpPanelResponse && kerpPanelResponse.status === 'success';
        const kerpPanelMessage = (kerpPanelResponse && kerpPanelResponse.message) || 'پاسخ سرور معتبر نیست؛ دوباره تلاش کنید.';
        kerpPanelFeedback.text(kerpPanelMessage);
        NioApp.Toast(kerpPanelMessage, kerpPanelSuccess ? 'success' : 'error', {position: 'top-right'});
    }).fail(function() {
        const kerpPanelMessage = 'ارتباط با سرور برقرار نشد؛ دوباره تلاش کنید.';
        kerpPanelFeedback.text(kerpPanelMessage);
        NioApp.Toast(kerpPanelMessage, 'error', {position: 'top-right'});
    }).always(function() {
        kerpPanelForm.data('saving', false).removeAttr('aria-busy');
        kerpPanelButton.prop('disabled', false);
    });
});



/* ===== payments.js ===== */
$(document).on('shown.bs.tab', '.kerp-payment-settings-tabs .nav-link', function() {
    const kerpPaymentSettingsTab = ($(this).attr('href') || '').replace('#payment-pane-', '');
    $(this).closest('.modal_form').find('[data-for="active_tab"]').val(kerpPaymentSettingsTab);
});

function kerp_payment_number(value) {
    const raw = String(value ?? '').trim()
        .replace(/[۰-۹]/g, digit => '۰۱۲۳۴۵۶۷۸۹'.indexOf(digit))
        .replace(/[٠-٩]/g, digit => '٠١٢٣٤٥٦٧٨٩'.indexOf(digit)).replace(/[,٬]/g, '');
    return raw && /^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?$/i.test(raw) ? Number(raw) : NaN;
}
$(document).on('click', '.kerp-payment-send-sms', function() {
    const $button = $(this), orderId = $button.attr('data-order-id');
    if ($button.prop('disabled')) return;
    const $buttons = $('.kerp-payment-send-sms').filter(function() { return $(this).attr('data-order-id') === orderId; });
    const $label = $button.find('span'), original = $label.text();
    $buttons.prop('disabled', true).attr('aria-busy', 'true');
    $label.text('در حال ارسال…');
    $.post(ajax_url, {action: 'payments_send_sms', order_id: orderId, payment_nonce: $button.attr('data-payment-nonce')})
        .done(function(response) {
            response = response && typeof response === 'object' ? response : {};
            NioApp.Toast($('<div>').text(response.message || response.msg || 'پاسخ سرویس پیامک معتبر نیست.').html(), response.status === 'success' ? 'success' : 'error', {position: 'top-right'});
        }).fail(function() {
            NioApp.Toast('ارتباط قطع شد؛ گزارش سرویس پیامک را پیش از ارسال دوباره بررسی کنید.', 'error', {position: 'top-right'});
        }).always(function() {
            $buttons.prop('disabled', false).removeAttr('aria-busy');
            $label.text(original);
        });
});
function kerp_payment_update_progress(area) {
    const $area = $(area), payable = kerp_payment_number($area.attr('data-payable'));
    const mixed = $area.closest('.modal_form').find('[data-for="payment_method"]').val() === 'kerp_mixed';
    $area.find('.kerp-payment-receipts').each(function() {
        const $section = $(this), $summary = $section.find('.kerp-payment-progress');
        $summary.toggleClass('d-none', mixed && $section.attr('data-method') === 'kerp_cheque');
        $summary.find('.kerp-payment-progress-label').text(mixed ? 'مجموع رسیدهای کارت و چک‌ها' : 'مجموع مبالغ واریزی');
        const decimals = Number($summary.attr('data-decimals')) || 0, scale = Math.pow(10, decimals);
        const format = value => value.toLocaleString('fa-IR', {maximumFractionDigits: decimals});
        let total = 0, invalid = false;
        const $sources = mixed ? $area.find('.kerp-payment-receipts[data-method="kerp_card"],.kerp-payment-receipts[data-method="kerp_cheque"]') : $section;
        $sources.find('.repeater_rows input[data-for$="[amount]"]').each(function() {
            if (this.disabled || !String($(this).val() || '').trim()) return;
            const amount = kerp_payment_number($(this).val());
            if (!Number.isFinite(amount) || amount <= 0) { invalid = true; return; }
            total += Math.round(amount * scale);
        });
        if (!Number.isSafeInteger(total)) { invalid = true; total = 0; }
        const target = Math.round(payable * scale), ready = Number.isSafeInteger(target) && target > 0;
        const excess = ready && total > target, complete = ready && total === target && !invalid;
        const percent = ready ? Math.min(100, total / target * 100) : 0;
        const currency = $area.attr('data-currency') || '';
        const message = invalid ? 'مبلغ هر ردیف باید عددی معتبر و بیشتر از صفر باشد.'
            : !ready ? ($area.attr('data-progress-message') || 'ابتدا مبلغ قابل پرداخت را مشخص کنید.')
            : excess ? format((total - target) / scale) + ' ' + currency + ' بیشتر از مبلغ قابل پرداخت'
            : complete ? 'مجموع واریزی‌ها با مبلغ قابل پرداخت برابر است.'
            : total === 0 ? 'هنوز مبلغی وارد نشده؛ ' + format(target / scale) + ' ' + currency + ' باقی مانده'
            : format((target - total) / scale) + ' ' + currency + ' باقی مانده';
        const state = invalid || excess ? 'danger' : complete ? 'success' : total && ready ? 'warning' : 'primary';
        $summary.find('.kerp-payment-progress-total').html(kerp_price_html(total / scale, currency) + (ready ? ' از ' + kerp_price_html(target / scale, currency) : ''));
        const $note = $summary.find('.kerp-payment-progress-note');
        const noteAmount = excess ? (total - target) / scale : ready && !complete ? (target - total) / scale : null;
        $note.empty();
        if (!invalid && noteAmount !== null) {
            if (total === 0) $note.append(document.createTextNode('هنوز مبلغی وارد نشده؛ '));
            $note.append($('<span>').html(kerp_price_html(noteAmount, currency)), document.createTextNode(excess ? ' بیشتر از مبلغ قابل پرداخت' : ' باقی مانده'));
        } else $note.text(message);
        $note.toggleClass('text-danger', state === 'danger').toggleClass('text-success', complete).toggleClass('text-soft', state !== 'danger' && !complete);
        $summary.find('[role="progressbar"]').attr({'aria-valuenow': percent, 'aria-valuetext': message});
        $summary.find('.progress-bar').removeClass('bg-primary bg-success bg-warning bg-danger').addClass('bg-' + state).css('width', percent + '%');
    });
}
$(document).on('input change', '.kerp-payment-receipts input[data-for$="[amount]"]', function() {
    kerp_payment_update_progress($(this).closest('.kerp-payment-fields'));
});
function kerp_payment_schedule(schedule, currency) {
    const $section = $('<section class="kerp-payment-schedule" aria-label="برنامه پرداخت اقساط">');
    $section.append($('<div class="kerp-payment-schedule-head">').append($('<strong>').text('برنامه پرداخت'), $('<span>').text(schedule.length.toLocaleString('fa-IR') + ' قسط')));
    const $table = $('<table><thead><tr><th scope="col">مرحله</th><th scope="col">مبلغ قسط</th><th scope="col">سررسید</th></tr></thead><tbody></tbody></table>');
    schedule.forEach((row, index) => {
        const $stage = $('<td class="kerp-schedule-stage">').append($('<span class="kerp-schedule-number">').text(Number(row.stage).toLocaleString('fa-IR')), $('<div>').append($('<strong>').text('قسط ' + Number(row.stage).toLocaleString('fa-IR')), index === 0 ? $('<small>').text('پرداخت این مرحله') : ''));
        const $amount = $('<td class="kerp-schedule-amount" data-label="مبلغ قسط">').append($('<strong>').html(kerp_price_html(row.amount, currency)));
        const $due = $('<td class="kerp-schedule-due" data-label="سررسید">').attr('data-days', row.days).append($('<div class="align-center">').append($('<em class="icon ni ni-calendar" aria-hidden="true">'), $('<span>').text(Number(row.days) === 0 ? 'اکنون' : kerp_payment_date(row.date))));
        $('<tr>').toggleClass('is-first', index === 0).append($stage, $amount, $due).appendTo($table.find('tbody'));
    });
    return $section.append($table, $('<p class="kerp-schedule-note">').text('در این مرحله فقط مبلغ قسط اول دریافت می‌شود. مبالغ و تاریخ‌ها هنگام ثبت سفارش نهایی می‌شوند.'));
}
const kerp_payment_date = value => {
    try { return new Intl.DateTimeFormat('fa-IR-u-ca-persian', {year: 'numeric', month: 'long', day: 'numeric', timeZone: 'Asia/Tehran'}).format(new Date(value)); }
    catch (e) { return value; }
};
function kerp_payment_payload($form) {
    const data = {};
    $form.find('input[data-for],select[data-for],textarea[data-for]').each(function() {
        if (this.disabled || ($(this).is(':checkbox,:radio') && !this.checked)) return;
        setNestedValue(data, $(this).attr('data-for'), $(this).val());
    });
    return data;
}
function kerp_payment_initialize() {
    $('.kerp-payment-date').not('[data-formatted]').each(function() { $(this).text(kerp_payment_date(this.dateTime)).attr('data-formatted', '1'); });
    $('.kerp-payment-fields').each(function() {
        const $area = $(this), $form = $area.closest('.modal_form');
        kerp_payment_update_progress($area);
        if ($area.data('ready')) return;
        $area.data('ready', true);
        const $method = $form.find('[data-for="payment_method"]');
        function methodVisible(section) {
            const selected = $method.val(), part = $(section).attr('data-method');
            return part === selected || (selected === 'kerp_mixed' && ['kerp_card', 'kerp_cheque'].includes(part));
        }
        function method() {
            $area.find('.kerp-payment-mixed-help').toggleClass('d-none', $method.val() !== 'kerp_mixed');
            $area.find('.kerp-payment-receipts').each(function() { $(this).toggleClass('d-none', !methodVisible(this)); });
            kerp_payment_update_progress($area);
        }
        $method.on('change.payments', method); method();
        if ($area.attr('data-new') !== '1') return;
        const $type = $form.find('[data-for="payment_type"]'), $plan = $form.find('[data-for="payment_plan"]');
        const $preview = $area.find('.kerp-payment-preview'), $button = $form.find('.submit_modal_form');
        let version = 0, timer, total = null;
        function withoutPayment() {
            return $form.attr('data-action') === 'payments_create_order'
                && $form.find('[data-for="registration_mode"]').val() !== 'proforma'
                && $method.val() === 'kerp_none';
        }
        function cash() {
            const orderTotal = total ?? kerp_payment_number($form.find('.order_total_final').attr('data-price-value') ?? $form.find('.order_total_final .final_price .price_number').text());
            const deposit = $type.val() === 'deposit';
            const amount = deposit ? kerp_payment_number($form.find('[data-for="deposit_amount"]').val()) : orderTotal;
            $area.attr('data-payable', amount).removeAttr('data-progress-message');
            $preview.empty().append($('<strong>').append(document.createTextNode($form.find('[data-for="registration_mode"]').val() === 'proforma' ? 'مبلغ پیش‌فاکتور: ' : 'مبلغ قابل پرداخت اکنون: '), $('<span>').html(kerp_price_html(amount, $area.attr('data-currency')))));
            if (deposit) {
                const valid = Number.isFinite(amount) && amount > 0 && amount < orderTotal;
                $button.prop('disabled', !valid);
                $preview.append($('<p class="mt-2 mb-0">').toggleClass('text-danger', !valid).html(valid ? 'مانده پس از وصول پیش‌پرداخت: ' + kerp_price_html(orderTotal - amount, $area.attr('data-currency')) : 'پیش‌پرداخت باید بیشتر از صفر و کمتر از مبلغ کل سفارش باشد.'));
            }
            kerp_payment_update_progress($area);
        }
        function refresh() {
            clearTimeout(timer); const current = ++version;
            const noPayment = withoutPayment();
            $type.prop('disabled', noPayment).closest('.meta-field-row').toggleClass('d-none', noPayment);
            $plan.prop('disabled', noPayment);
            $form.find('[data-for="deposit_amount"]').prop('disabled', noPayment);
            const installment = $type.val() === 'installment';
            $area.find('.kerp-payment-deposit').toggleClass('d-none', noPayment || $type.val() !== 'deposit');
            $area.find('.kerp-payment-plan').toggleClass('d-none', noPayment || !installment);
            if (noPayment) {
                $button.prop('disabled', false);
                $area.removeAttr('data-payable data-progress-message');
                $preview.empty().append($('<p class="text-soft mb-0">').text('سفارش بدون ثبت پرداخت، رسید یا قرارداد اقساط مستقیماً تکمیل می‌شود.'));
                return;
            }
            $button.prop('disabled', installment);
            if (!installment) { cash(); return; }
            $area.removeAttr('data-payable').attr('data-progress-message', 'در حال دریافت مبلغ قابل پرداخت…');
            kerp_payment_update_progress($area);
            $preview.text('در حال دریافت برنامه پرداخت…');
            timer = setTimeout(function() {
                const data = kerp_payment_payload($form); data.action = 'payments_preview';
                $.post(ajax_url, data).done(function(response) {
                    if (current !== version || !$area[0].isConnected) return;
                    const selected = String($plan.val() || '');
                    $plan.empty().append(new Option('انتخاب پلن', ''));
                    (response.plans || []).forEach(p => $plan.append(new Option(p.text, p.id)));
                    const found = (response.plans || []).some(p => String(p.id) === selected);
                    $plan.val(found ? selected : '').trigger('change.select2');
                    if (!found && response.plans && response.plans.length) { $plan.val(String(response.plans[0].id)).trigger('change.select2'); refresh(); return; }
                    $preview.empty();
                    if (response.status !== 'success' || response.error) { $preview.append($('<div class="alert alert-warning">').text(response.error || response.message || response.msg || 'دریافت برنامه پرداخت ناموفق بود.')); $area.attr('data-progress-message', 'مبلغ قابل پرداخت مشخص نیست؛ پلن اقساط را بررسی کنید.'); kerp_payment_update_progress($area); return; }
                    $preview.append(kerp_payment_schedule(response.schedule || [], response.currency));
                    proforma();
                    $area.attr('data-payable', response.schedule && response.schedule.length ? response.schedule[0].amount : '').removeAttr('data-progress-message');
                    kerp_payment_update_progress($area);
                    $button.prop('disabled', !(response.schedule || []).length);
                }).fail(function() { if (current === version && $area[0].isConnected) { $preview.text('دریافت برنامه پرداخت ناموفق بود؛ دوباره پلن را انتخاب کنید.'); $area.attr('data-progress-message', 'دریافت مبلغ ناموفق بود؛ دوباره پلن را انتخاب کنید.'); kerp_payment_update_progress($area); } });
            }, 300);
        }
        const $registration = $form.find('[data-for="registration_mode"]');
        function proforma() {
            const draft = $registration.val() === 'proforma';
            $area.find('.kerp-payment-mixed-help').toggleClass('d-none', draft || $method.val() !== 'kerp_mixed');
            $area.find('.kerp-proforma-method').toggleClass('d-none', draft);
            $method.prop('disabled', draft);
            $area.find('.kerp-payment-receipts').each(function() {
                $(this).toggleClass('d-none', draft || !methodVisible(this));
            });
            $area.find('.kerp-schedule-stage small').text(draft ? 'پس از شروع پرداخت' : 'پرداخت این مرحله');
            if (draft) $area.find('.kerp-schedule-due').each(function() { const days = Number($(this).attr('data-days')); $(this).find('span').text(days === 0 ? 'زمان شروع پرداخت' : days.toLocaleString('fa-IR') + ' روز پس از شروع پرداخت'); });
            $button.find('span').text(draft ? 'ذخیره پیش‌فاکتور' : withoutPayment() ? 'ثبت و تکمیل سفارش' : 'ثبت سفارش');
            $area.find('.kerp-schedule-note').text(draft ? 'این برنامه موقت است؛ تا شروع پرداخت، قسط و پیگیری ساخته نمی‌شود. سررسیدها از زمان شروع پرداخت محاسبه می‌شوند.' : 'در این مرحله فقط مبلغ قسط اول دریافت می‌شود. مبالغ و تاریخ‌ها هنگام ثبت سفارش نهایی می‌شوند.');
        }
        $registration.on('change.payments', function() { proforma(); refresh(); });
        $method.on('change.proforma', function() { proforma(); refresh(); });
        proforma();
        $type.on('change.payments', refresh); $plan.on('change.payments', refresh);
        $form.on('input.payments change.payments', '[data-for="deposit_amount"]', refresh);
        $form.on('kerp_order_totals_calculated.payments', function(event, values) { total = Number(values.final_total); refresh(); });
        $form.on('change.payments', '[data-for="customer_id"]', refresh);
        refresh();
    });
}
$(document).on('click', '.kerp-payment-review', function() { $('#payment-review-ids').val($(this).attr('data-payment-id')); });
$(document).on('shown.bs.modal', kerp_payment_initialize);
$(function() {
    kerp_payment_initialize();
    let scheduled = false;
    new MutationObserver(function(changes) {
        if (!changes.some(change => Array.from(change.addedNodes).concat(Array.from(change.removedNodes)).some(node => node.nodeType === 1 && (node.matches('.kerp-payment-fields,.kerp-payment-date,.repeater_row') || node.querySelector('.kerp-payment-fields,.kerp-payment-date,.repeater_row'))))) return;
        if (scheduled) return; scheduled = true;
        setTimeout(function() { scheduled = false; kerp_payment_initialize(); if (NioApp.Dropzone && NioApp.Dropzone.init) NioApp.Dropzone.init(); }, 0);
    }).observe(document.body, {childList: true, subtree: true});
});



/* ===== practice-migration.js ===== */
(function () {
    'use strict';

    const formatNumber = new Intl.NumberFormat('fa-IR');

    function updateProgress(root, data) {
        const total = Math.max(0, Number(data.total) || 0);
        const migrated = Math.min(total, Math.max(0, Number(data.migrated) || 0));
        const remaining = Math.max(0, Number(data.remaining) || 0);
        const percent = remaining === 0 ? 100 : total > 0 ? Math.min(100, Math.floor(100 * migrated / total)) : 0;
        root.querySelector('[data-migration-total]').textContent = formatNumber.format(total);
        root.querySelector('[data-migration-migrated]').textContent = formatNumber.format(migrated);
        root.querySelector('[data-migration-remaining]').textContent = formatNumber.format(remaining);
        root.querySelector('[data-migration-percent]').textContent = formatNumber.format(percent) + '٪';
        root.querySelector('[data-migration-bar]').style.width = percent + '%';
        root.querySelector('[role="progressbar"]').setAttribute('aria-valuenow', String(percent));
        return remaining;
    }

    async function runMigration(root, button) {
        if (root.dataset.running === '1') return;
        root.dataset.running = '1';
        button.disabled = true;
        const label = button.querySelector('span');
        const message = root.querySelector('[data-migration-message]');
        label.textContent = 'در حال انتقال…';
        message.classList.remove('text-danger');
        message.textContent = 'در حال انتقال پاسخ‌ها، لطفاً این صفحه را باز نگه دارید.';
        let completed = false;

        try {
            while (document.documentElement.contains(root)) {
                const body = new URLSearchParams({
                    action: 'kerp_practice_migrate_legacy',
                    migration_nonce: root.dataset.nonce || ''
                });
                const response = await fetch(window.KERPData?.ajaxUrl || '', {
                    method: 'POST',
                    credentials: 'same-origin',
                    cache: 'no-store',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
                    body: body.toString()
                });
                const payload = await response.json();
                if (!response.ok || payload?.status !== 'success' || !payload.data) {
                    throw new Error(payload?.message || payload?.msg || 'انتقال پاسخ‌ها انجام نشد.');
                }
                if (!document.documentElement.contains(root)) return;
                const remaining = updateProgress(root, payload.data);
                if (remaining === 0) {
                    completed = true;
                    message.textContent = 'انتقال کامل شد. جدول و فایل‌های قدیمی حفظ شده‌اند.';
                    break;
                }
                if (Number(payload.data.copied) < 1) {
                    throw new Error('پاسخی منتقل نشد. وضعیت جدول قدیمی را بررسی کنید و سپس دوباره تلاش کنید.');
                }
                message.textContent = formatNumber.format(remaining) + ' پاسخ باقی مانده است…';
            }
        } catch (error) {
            if (document.documentElement.contains(root)) {
                message.classList.add('text-danger');
                message.textContent = error.message || 'ارتباط با سرور قطع شد. برای ادامه دوباره تلاش کنید.';
            }
        } finally {
            root.dataset.running = '0';
            if (document.documentElement.contains(root)) {
                button.disabled = completed;
                label.textContent = completed ? 'انتقال کامل شد' : 'ادامه انتقال';
            }
        }
    }

    document.addEventListener('click', function (event) {
        const button = event.target.closest('[data-migration-start]');
        if (!button) return;
        const root = button.closest('#kerp-practice-migration');
        if (root) runMigration(root, button);
    });
})();



/* ===== settings.js ===== */
const rootSelector = '.kerp-order-print-settings';

// Terms are rendered as a readable list; enhance after both initial and AJAX loads.
const termTreeStates = new Map();

function termTreeState(tree) {
    const key = 'kerp-terms-' + tree.dataset.taxonomy;
    if (!termTreeStates.has(key)) {
        let value = {};
        try { value = JSON.parse(sessionStorage.getItem(key) || '{}') || {}; } catch (_) {}
        termTreeStates.set(key, value);
    }
    return termTreeStates.get(key);
}

function setTermOpen(node, open) {
    node.querySelector(':scope > .kerp-term-children').hidden = !open;
    const button = node.querySelector(':scope > .kerp-term-row .kerp-term-toggle');
    button.setAttribute('aria-expanded', String(open));
    button.textContent = open ? '▾' : '◂';
}

function saveTermState(tree) {
    try {
        sessionStorage.setItem('kerp-terms-' + tree.dataset.taxonomy, JSON.stringify(termTreeState(tree)));
    } catch (_) {}
}

function normalizeTermSearch(value) {
    return String(value).
        toLowerCase().
        replace(/ي/g, 'ی').
        replace(/ك/g, 'ک').
        replace(/[\u064b-\u065f\u200c]/g, '').
        trim();
}

function filterTermTree(tree) {
    const query = normalizeTermSearch(tree.querySelector('.kerp-terms-search').value);
    const nodes = [...tree.querySelectorAll('.kerp-term-node')];
    const visible = new Set();
    nodes.forEach(node => {
        const match = !!query && normalizeTermSearch(node.dataset.search).includes(query);
        node.classList.toggle('is-match', match);
        if (match) {
            let current = node;
            while (current) {
                visible.add(current);
                current = current.parentElement.closest('.kerp-term-node');
            }
        }
    });
    nodes.forEach(node => {
        node.hidden = !!query && !visible.has(node);
        setTermOpen(node,
            query ? true : (termTreeState(tree)[node.dataset.id] ?? !node.parentElement.closest('.kerp-term-node')));
    });
    tree.querySelector('.kerp-terms-no-results').hidden = !query || visible.size > 0;
}

function initTermTrees() {
    document.querySelectorAll('.kerp-terms-tree:not([data-ready])').forEach(tree => {
        tree.dataset.ready = '1';
        const nodes = [...tree.querySelectorAll('.kerp-term-node')];
        const byId = new Map(nodes.map(node => [node.dataset.id, node]));
        nodes.forEach(node => {
            const parent = byId.get(node.dataset.parent);
            // Keep malformed or cyclic records visible at the root.
            if (parent && parent !== node && !node.contains(parent)) {
                parent.querySelector(':scope > .kerp-term-children').append(node);
            }
        });
        filterTermTree(tree);
        const focus = byId.get(tree.dataset.focus);
        if (focus) {
            let ancestor = focus.parentElement.closest('.kerp-term-node');
            while (ancestor) {
                termTreeState(tree)[ancestor.dataset.id] = true;
                setTermOpen(ancestor, true);
                ancestor = ancestor.parentElement.closest('.kerp-term-node');
            }
            saveTermState(tree);
            focus.classList.add('is-saved');
            focus.querySelector('.kerp-term-name').setAttribute('tabindex', '-1');
            focus.querySelector('.kerp-term-name').focus({preventScroll: true});
            focus.scrollIntoView({
                block:    'nearest',
                behavior: 'auto',
            });
            setTimeout(() => focus.classList.remove('is-saved'), 3500);
        }
    });
}

$(document).on('click', '.kerp-term-toggle', function() {
    const node = this.closest('.kerp-term-node');
    const tree = this.closest('.kerp-terms-tree');
    const open = this.getAttribute('aria-expanded') !== 'true';
    setTermOpen(node, open);
    if (!tree.querySelector('.kerp-terms-search').value) {
        termTreeState(tree)[node.dataset.id] = open;
        saveTermState(tree);
    }
});
$(document).on('input', '.kerp-terms-search', function() { filterTermTree(this.closest('.kerp-terms-tree')); });
$(document).on('click', '.kerp-terms-expand', function() {
    const tree = this.closest('.kerp-terms-tree');
    tree.querySelector('.kerp-terms-search').value = '';
    tree.querySelectorAll('.kerp-term-node').
        forEach(node => { termTreeState(tree)[node.dataset.id] = this.dataset.open === '1'; });
    saveTermState(tree);
    filterTermTree(tree);
});
$(document).on('shown.bs.modal', '[id^="programTermModal"]', function() {
    const modal = this;
    const select = modal.querySelector('[name="parent_id"]');
    if (!select) {
        return;
    }
    const termId = modal.querySelector('[name="term_id"]').value;
    const taxonomyId = modal.querySelector('[name="taxonomy_id"]').value;
    const tree = [...document.querySelectorAll('.kerp-terms-tree')].find(item => item.dataset.taxonomy === taxonomyId);
    const current = tree && [...tree.querySelectorAll('.kerp-term-node')].find(item => item.dataset.id === termId);
    const excluded = new Set(current
                             ? [
            current.dataset.id,
            ...[...current.querySelectorAll('.kerp-term-node')].map(item => item.dataset.id),
        ]
                             : []);
    [...select.options].forEach(option => { option.disabled = excluded.has(option.value); });
    $(select).trigger('change.select2');
    const title = modal.querySelector('.modal-title');
    if (title) {
        title.textContent = termId ? 'ویرایش گزینه' : (Number(select.value)
                                                       ? 'افزودن زیرمجموعه'
                                                       : 'افزودن گزینهٔ اصلی');
    }
});
$(document).on('hidden.bs.modal', '[id^="programTermModal"]', function() {
    $(this).find('[name="parent_id"] option').prop('disabled', false);
});
$(function() {
    initTermTrees();
    let queued = false;
    new MutationObserver(records => {
        if (queued || !records.some(record => [...record.addedNodes].some(node => node.nodeType === 1 &&
            (node.matches('.kerp-terms-tree') || node.querySelector('.kerp-terms-tree'))))) {
            return;
        }
        queued = true;
        requestAnimationFrame(() => {
            queued = false;
            initTermTrees();
        });
    }).observe(document.body, {
        childList: true,
        subtree:   true,
    });
});

function getCard(element) {
    return $(element).closest('.kerp-order-print-type');
}

function setCardOpen($card, open) {
    const $settings = $card.find('.kerp-order-print-type__settings').first();
    const $button = $card.find('.kerp-order-print-toggle').first();
    
    $card.toggleClass('is-open', open);
    $settings.prop('hidden', !open);
    $button.attr('aria-expanded', open ? 'true' : 'false');
}

function updateEnabledState($input) {
    const $card = getCard($input);
    const enabled = $input.is(':checked');
    const $state = $card.find('.kerp-order-print-type__state').first();
    
    $card.toggleClass('is-enabled', enabled).toggleClass('is-disabled', !enabled);
    $state.toggleClass('is-active', enabled).toggleClass('is-inactive', !enabled);
    $state.text(enabled ? 'فعال' : 'غیرفعال');
    
    setCardOpen($card, enabled);
}

function updateLabel($input) {
    const $card = getCard($input);
    const fallback = $.trim($card.attr('data-print-type') || '');
    const label = $.trim(String($input.val() || '')) || fallback;
    
    $card.find('.kerp-order-print-type__label').first().text(label);
}

function updateOrder($input) {
    const $card = getCard($input);
    const value = $.trim(String($input.val() || '0')) || '0';
    
    $card.find('.kerp-order-print-summary-order').html(
        '<em class="icon ni ni-sort-v"></em>ترتیب ' + value,
    );
}

function updateTextState($textarea) {
    const $card = getCard($textarea);
    const value = String($textarea.val() || '');
    const hasText = $.trim(value) !== '';
    const $count = $textarea.closest('.form-group').find('.kerp-order-print-char-count').first();
    
    $count.text(Array.from(value).length);
    
    if ($textarea.attr('id').endsWith('-header')) {
        $card.find('.kerp-order-print-summary-header span').text(
            hasText ? 'سربرگ دارد' : 'بدون سربرگ',
        );
    } else {
        $card.find('.kerp-order-print-summary-footer span').text(
            hasText ? 'پابرگ دارد' : 'بدون پابرگ',
        );
    }
}

function updateSellerProgress($root) {
    const $fields = $root.find('.kerp-print-seller-field');
    let filled = 0;
    
    $fields.each(function() {
        if ($.trim(String($(this).val() || '')) !== '') {
            filled++;
        }
    });
    
    $root.find('.kerp-order-print-seller-progress').text(
        filled + ' از ' + $fields.length + ' تکمیل',
    );
}

$(document).on('click', rootSelector + ' .kerp-order-print-toggle', function(e) {
    e.preventDefault();
    
    const $card = getCard(this);
    
    setCardOpen($card, !$card.hasClass('is-open'));
});

$(document).on('change', rootSelector + ' .kerp-order-print-enabled', function() {
    updateEnabledState($(this));
});

$(document).on('input', rootSelector + ' .kerp-order-print-label-input', function() {
    updateLabel($(this));
});

$(document).on('input change', rootSelector + ' .kerp-order-print-order-input', function() {
    updateOrder($(this));
});

$(document).on('input', rootSelector + ' .kerp-order-print-textarea', function() {
    updateTextState($(this));
});

$(document).on('input change', rootSelector + ' .kerp-print-seller-field', function() {
    updateSellerProgress($(this).closest(rootSelector));
});

const presetIcons = [
    'ni ni-file-text',
    'ni ni-call',
    'ni ni-calendar',
    'ni ni-flag',
    'ni ni-user-check',
    'kik fa-activity',
    'kik fa-clock',
    'uik-r fa-inbox',
];
const colorClasses = [
    'bg-primary-dim', 'text-primary',
    'bg-info-dim', 'text-info',
    'bg-success-dim', 'text-success',
    'bg-warning-dim', 'text-warning',
    'bg-danger-dim', 'text-danger',
    'bg-secondary-dim', 'text-secondary',
    'bg-purple-dim', 'text-purple',
    'bg-light-dim', 'text-light', 'text-dark',
];

function normalizeKey(value) {
    return String(value || '').
        toLowerCase().
        replace(/\s+/g, '-').
        replace(/[^a-z0-9_-]/g, '').
        replace(/-{2,}/g, '-').
        replace(/^[-_]+|[-_]+$/g, '');
}

function getColor($modal) {
    return String($modal.find('.kerp-settings-color-input').first().val() || 'primary');
}

function ensureIconTools($input) {
    const $group = $input.closest('.form-group');
    let $tools = $group.find('.kerp-settings-icon-tools').first();
    
    if ($tools.length) {
        return $tools;
    }
    
    if ($group.find('.kerp-settings-icon-preview, .kerp-settings-icon-presets').length) {
        return $group;
    }
    
    $tools = $('<div class="kerp-settings-icon-tools"></div>');
    const $preview = $('<span class="kerp-settings-icon-preview bg-primary-dim text-primary"><em></em></span>');
    const $presets = $('<div class="kerp-settings-icon-presets"></div>');
    
    presetIcons.forEach(function(icon) {
        const $button = $(
            '<button type="button" class="kerp-settings-icon-preset" aria-label="انتخاب آیکون"><em></em></button>');
        $button.attr('data-icon', icon);
        $button.find('em').attr('class', icon + ' icon');
        $presets.append($button);
    });
    
    $tools.append($preview, $presets);
    $group.append($tools);
    
    return $tools;
}

function syncIconPreview($input) {
    const $modal = $input.closest('.modal');
    const $tools = ensureIconTools($input);
    const icon = $.trim(String($input.val() || '')) || 'ni ni-file-text';
    const color = getColor($modal);
    const $preview = $tools.find('.kerp-settings-icon-preview').first();
    
    $preview.removeClass(colorClasses.join(' '));
    $preview.addClass('bg-' + color + '-dim text-' + (color === 'light' ? 'dark' : color));
    $preview.find('em').attr('class', icon + ' icon');
    
    const $printCard = $input.closest('.kerp-order-print-type');
    if ($printCard.length) {
        $printCard.find('.kerp-order-print-type__icon em').attr('class', icon);
    }
    
    $tools.find('.kerp-settings-icon-preset').removeClass('is-selected').filter(function() {
        return String($(this).attr('data-icon') || '') === icon;
    }).addClass('is-selected');
}

function syncModalIcon($modal) {
    const $input = $modal.find('.kerp-settings-icon-input').first();
    
    if ($input.length) {
        syncIconPreview($input);
    }
}

function disableCurrentReplacement($modal) {
    const $key = $modal.find('input[id*="delete-type-key"]').first();
    const $select = $modal.find('select[name="replacement_key"]').first();
    
    if (!$key.length || !$select.length) {
        return;
    }
    
    const current = String($key.val() || '');
    $select.find('option').prop('disabled', false);
    
    if (current) {
        $select.find('option[value="' + current.replace(/"/g, '\\"') + '"]').prop('disabled', true);
        if (String($select.val() || '') === current) {
            $select.val('').trigger('change');
        }
    }
}

$(document).on('input', '.kerp-settings-key-input', function() {
    const normalized = normalizeKey($(this).val());
    if ($(this).val() !== normalized) {
        $(this).val(normalized);
    }
});

$(document).on('input', '.kerp-settings-icon-input', function() {
    syncIconPreview($(this));
});

$(document).on('change', '.kerp-settings-color-input', function() {
    syncModalIcon($(this).closest('.modal'));
});

$(document).on('click', '.kerp-settings-icon-preset', function() {
    const icon = String($(this).attr('data-icon') || '');
    const $input = $(this).closest('.form-group').find('.kerp-settings-icon-input').first();
    
    if ($input.length && icon) {
        $input.val(icon).trigger('input');
    }
});

$(document).on('shown.bs.modal', '.modal', function() {
    const $modal = $(this);
    syncModalIcon($modal);
    disableCurrentReplacement($modal);
});

$(document).on('change', '.modal input[id*="delete-type-key"]', function() {
    disableCurrentReplacement($(this).closest('.modal'));
});



/* ===== sms-logs.js ===== */
$(document).on('click', '.kerp-sms-log-delete', function() {
    $('#kerp-sms-log-ids').val($(this).attr('data-id'));
    $('#kerp-sms-log-operation').val('delete');
});



/* ===== table-search.js ===== */
// Opt-in shared table search. Ordinary filter requests retain the ERP loading overlay.
function kerpTableSearchAjax(options) {
    ajax_search = options.ajax_search === true;
    try {
        return $.ajax(options);
    } finally {
        // ajaxSend runs synchronously. Never leave this flag enabled while waiting for a response.
        ajax_search = false;
    }
}

function kerpTableSearchCancel($root) {
    clearTimeout($root.data('kerp-table-search-timer'));
    $root.data('kerp-table-search-version', ($root.data('kerp-table-search-version') || 0) + 1);
    const request = $root.data('kerp-table-search-request');
    $root.removeData('kerp-table-search-request').attr('aria-busy', 'false');
    if (request) request.abort();
    $root.trigger('kerp:table-search-cancel');
}

function kerpTableSearchSchedule(input, delay) {
    const $input = $(input);
    const $root = $input.closest('[data-kerp-table-search]');
    if (!$root.length) return;
    kerpTableSearchCancel($root);
    const version = $root.data('kerp-table-search-version');
    $root.data('kerp-table-search-timer', setTimeout(function() {
        if (!$root[0].isConnected) return;
        const event = $.Event('kerp:table-search');
        $root.trigger(event);
        // Lists may provide a result-only renderer, as the employees list does.
        if (event.isDefaultPrevented()) return;
        const data = get_current_page_filters($root);
        data.search = String($input.val() || '');
        data.action = 'erp_request_page_content';
        data.page = $root.attr('data-search-page');
        data.page_number = 1;
        if (!data.page) return;
        const cursor = input.selectionStart;
        $root.attr('aria-busy', 'true');
        const request = kerpTableSearchAjax({url: ajax_url, type: 'POST', dataType: 'json', timeout: 30000, ajax_search: true, data});
        $root.data('kerp-table-search-request', request);
        request.done(function(response) {
            if (!$root[0].isConnected || $root.data('kerp-table-search-version') !== version) return;
            if (response.status !== 'success') {
                NioApp.Toast(response.message || 'دریافت نتایج ناموفق بود.', 'danger', {position: 'top-right'});
                return;
            }
            if ($root.is('[data-table-results]')) {
                const $content = $('<div>').append($.parseHTML(response.main || '', document, false));
                const $next = $content.find('[data-kerp-table-search]').filter(function() {
                    return this.id === $root[0].id;
                });
                const selector = $root.attr('data-table-results');
                if ($next.length !== 1 || !$next.find(selector).length) {
                    NioApp.Toast('پاسخ فهرست معتبر نیست؛ دوباره تلاش کنید.', 'danger', {position: 'top-right'});
                    return;
                }
                $root.find(selector).find('[data-bs-toggle="tooltip"], .kerp-table-tooltip').tooltip('dispose');
                $root.find(selector).html($next.find(selector).html());
                $root.find('[data-table-count]').text($next.find('[data-table-count]').text());
                if (response.url) history.replaceState(history.state, '', response.url);
                NioApp.ajaxInit();
                return;
            }
            const focused = document.activeElement === input;
            change_panel_html(response);
            const next = document.getElementById(input.id);
            if (focused && next) {
                next.focus({preventScroll: true});
                next.setSelectionRange(cursor, cursor);
            }
        }).fail(function(xhr, reason) {
            if (reason !== 'abort' && $root[0].isConnected && $root.data('kerp-table-search-version') === version) {
                NioApp.Toast('خطا در دریافت نتایج؛ دوباره تلاش کنید.', 'danger', {position: 'top-right'});
            }
        }).always(function() {
            if ($root.data('kerp-table-search-version') === version) $root.attr('aria-busy', 'false');
        });
    }, delay));
}

$(document).on('input compositionend', '.kerp-table-search', function(event) {
    if (event.originalEvent?.isComposing) return;
    kerpTableSearchSchedule(this, 350);
});
$(document).on('keydown', '.kerp-table-search', function(event) {
    if (event.key === 'Enter' && !event.originalEvent?.isComposing) {
        event.preventDefault();
        kerpTableSearchSchedule(this, 0);
    }
});
$(document).on('submit', '[data-kerp-table-search] form[role="search"]', function(event) {
    event.preventDefault();
    const input = $(this).find('.kerp-table-search')[0];
    if (input) kerpTableSearchSchedule(input, 0);
});
$(document).on('click', '.kerp-table-search-submit[type="button"]', function(event) {
    event.preventDefault();
    const input = $(this).closest('[data-kerp-table-search]').find('.kerp-table-search')[0];
    if (input) kerpTableSearchSchedule(input, 0);
});
$(document).ajaxSend(function(event, xhr, settings) {
    if (settings.ajax_search === true || settings.kerpEmployeesFilter) return;
    const data = typeof settings.data === 'string' ? new URLSearchParams(settings.data) : null;
    const action = data ? data.get('action') : settings.data?.action;
    if (!['erp_request_page_content', 'erp_request_back_btn'].includes(action)) return;
    $('[data-kerp-table-search]').each(function() {
        kerpTableSearchCancel($(this));
    });
});

$(document).on('kerp:search-closed show.bs.modal', '[data-kerp-table-search]', function() {
    kerpTableSearchCancel($(this));
});

// Result-only lists share accessible tooltips without replacing Bootstrap modal/dropdown toggles.
const kerpTableTooltipTargets = '[data-table-results] button, [data-table-results] .btn, [data-table-results] .page-link, [data-table-results] .reset_page_filter, [data-table-results] .change_per_page';
function kerpTableShowTooltip() {
    const $button = $(this);
    if ($button.is('[data-kerp-no-tooltip]')) return;
    if ($button.is('[data-bs-toggle="tooltip"]') || $button.parent().is('[data-bs-toggle="tooltip"]')) return;
    const page = $button.closest('.page-item').attr('data-page');
    const per = $button.attr('data-per-page');
    const label = $button.attr('aria-label') || $button.attr('data-bs-original-title') || $button.attr('title') || (page ? 'صفحه ' + page : per ? 'نمایش ' + per + ' مورد' : $.trim($button.text()));
    if (!label || typeof $.fn.tooltip !== 'function') return;
    $button.attr('aria-label', label);
    if (!$button.hasClass('kerp-table-tooltip')) $button.addClass('kerp-table-tooltip').tooltip({title: label, trigger: 'hover focus', container: 'body'});
    $button.tooltip('show');
}
$(document).on('mouseenter focusin', kerpTableTooltipTargets, kerpTableShowTooltip);
$(document).on('click mouseleave focusout', kerpTableTooltipTargets, function() {
    if ($(this).hasClass('kerp-table-tooltip')) $(this).tooltip('hide');
});



/* ===== taxonomy-picker.js ===== */
const taxonomyPickerNormalize = value => String(value || '').
    toLowerCase().
    replace(/ي/g, 'ی').
    replace(/ك/g, 'ک').
    replace(/[\u064b-\u065f\u200c]/g, '').
    trim();

function taxonomyPickerSetBranch($node, open) {
    const $toggle = $node.children('.kerp-taxonomy-picker__row').find('.kerp-taxonomy-picker__toggle').first();
    const $branch = $node.children('.kerp-taxonomy-picker__branches');
    if (!$branch.length) {
        return;
    }
    $toggle.attr('aria-expanded', String(open)).find('.icon').
        toggleClass('ni-chevron-down', open).
        toggleClass('ni-chevron-left', !open);
    $branch.prop('hidden', !open);
}

function taxonomyPickerSync(picker) {
    const $picker = $(picker);
    const $select = $picker.find('.kerp-taxonomy-picker__select').first();
    const selected = new Set(($select.val() || []).map(String));
    $picker.find('.kerp-taxonomy-picker__check').each(function() {
        const checked = selected.has(String(this.value));
        $(this).prop('checked', checked).closest('.kerp-taxonomy-picker__row').toggleClass('is-selected', checked);
    });
    const $summary = $picker.find('.kerp-taxonomy-picker__selected').empty();
    $select.find('option:selected').each(function() {
        const $node = $picker.find(`.kerp-taxonomy-picker__node[data-node="${this.value}"]`).first();
        $('<button type="button" class="kerp-taxonomy-picker__chip">').
            attr('data-remove', this.value).
            attr('title', $node.attr('data-path') || this.textContent).
            append($('<span>').text(this.textContent), '<em class="icon ni ni-cross"></em>').
            appendTo($summary);
    });
    if (!selected.size) {
        $('<span class="kerp-taxonomy-picker__placeholder">هنوز مبحثی انتخاب نشده است.</span>').appendTo($summary);
    }
    $picker.find('.kerp-taxonomy-picker__count').text(selected.size.toLocaleString('fa-IR') + ' انتخاب');
}

function taxonomyPickerFilter(picker) {
    const $picker = $(picker);
    const query = taxonomyPickerNormalize($picker.find('.kerp-taxonomy-picker__search').val());
    const $nodes = $picker.find('.kerp-taxonomy-picker__node');
    let matches = 0;
    if (!query) {
        $nodes.prop('hidden', false);
        $nodes.each(function() {
            const $node = $(this);
            const open = $node.children('.kerp-taxonomy-picker__row').find('.kerp-taxonomy-picker__toggle').first().attr('aria-expanded') === 'true';
            $node.children('.kerp-taxonomy-picker__branches').prop('hidden', !open);
        });
    } else {
        $nodes.prop('hidden', true);
        $nodes.each(function() {
            const $node = $(this);
            if (!taxonomyPickerNormalize($node.attr('data-search')).includes(query)) {
                return;
            }
            matches++;
            $node.prop('hidden', false);
            $node.parentsUntil($picker.find('.kerp-taxonomy-picker__tree'), '.kerp-taxonomy-picker__node').each(function() {
                $(this).prop('hidden', false).children('.kerp-taxonomy-picker__branches').prop('hidden', false);
            });
        });
    }
    $picker.find('.kerp-taxonomy-picker__empty').prop('hidden', !query || matches > 0);
}

$(document).on('change', '.kerp-taxonomy-picker__select', function() {
    taxonomyPickerSync($(this).closest('.kerp-taxonomy-picker'));
});

$(document).on('change', '.kerp-taxonomy-picker__check', function() {
    const $picker = $(this).closest('.kerp-taxonomy-picker');
    const $select = $picker.find('.kerp-taxonomy-picker__select').first();
    $select.find('option').filter((_, option) => String(option.value) === String(this.value)).prop('selected', this.checked);
    $select.trigger('change');
});

$(document).on('click', '.kerp-taxonomy-picker__toggle', function() {
    const $node = $(this).closest('.kerp-taxonomy-picker__node');
    taxonomyPickerSetBranch($node, $(this).attr('aria-expanded') !== 'true');
});

$(document).on('input', '.kerp-taxonomy-picker__search', function() {
    taxonomyPickerFilter($(this).closest('.kerp-taxonomy-picker'));
});

$(document).on('click', '.kerp-taxonomy-picker__clear', function() {
    $(this).closest('.kerp-taxonomy-picker').find('.kerp-taxonomy-picker__select').val([]).trigger('change');
});

$(document).on('click', '.kerp-taxonomy-picker__chip', function() {
    const $picker = $(this).closest('.kerp-taxonomy-picker');
    const $select = $picker.find('.kerp-taxonomy-picker__select');
    $select.find('option').filter((_, option) => String(option.value) === String(this.dataset.remove)).prop('selected', false);
    $select.trigger('change');
});

$(document).on('click', '.kerp-taxonomy-picker__expand', function() {
    const $picker = $(this).closest('.kerp-taxonomy-picker');
    const open = this.dataset.open === '1';
    $picker.find('.kerp-taxonomy-picker__node').each(function() { taxonomyPickerSetBranch($(this), open); });
    this.dataset.open = open ? '0' : '1';
    $(this).text(open ? 'بستن همه' : 'بازکردن همه');
});

$(document).on('shown.bs.modal', '.modal', function() {
    $(this).find('.kerp-taxonomy-picker').each(function() {
        taxonomyPickerSync(this);
        taxonomyPickerFilter(this);
    });
});



/* ===== term-explorer.js ===== */
const instances = new WeakMap();
const escape = value => $('<span>').text(String(value ?? '')).html();
const normalize = value => String(value || '').
    toLowerCase().
    replace(/ي/g, 'ی').
    replace(/ك/g, 'ک').
    replace(/[\u064b-\u065f\u200c]/g, '').
    trim();
const number = value => Number(value || 0).toLocaleString('fa-IR');

class Explorer {
    constructor(root) {
        this.root = root;
        this.$root = $(root);
        this.key = 'kerp-explorer-' + root.dataset.user + '-' + root.dataset.taxonomy;
        this.state = {
            open:     {},
            selected: 0,
        };
        try {
            const saved = JSON.parse(localStorage.getItem(this.key));
            if (saved && typeof saved.open === 'object' && saved.open) {
                this.state = saved;
            }
        } catch (_) {}
        this.selected = Number(root.dataset.focus || this.state.selected || 0);
        this.terms = [];
        this.map = new Map();
        this.sequence = 0;
        this.busy = false;
        this.bind();
        this.load();
    }
    
    persist() {
        this.state.selected = this.selected;
        try { localStorage.setItem(this.key, JSON.stringify(this.state)); } catch (_) {}
    }
    
    request(operation, data = {}) {
        return new Promise((resolve, reject) => {
            $.ajax({
                url:      ajax_url,
                method:   'POST',
                dataType: 'json',
                timeout:  30000,
                data:     {
                    action:      'programs_term_explorer',
                    nonce:       this.root.dataset.nonce,
                    taxonomy_id: this.root.dataset.taxonomy,
                    operation, ...data,
                },
            }).done(result => {
                if (result && result.status === 'success' && Array.isArray(result.terms)) {
                    resolve(result.terms);
                } else {
                    reject(new Error(result?.message || result?.msg || 'دریافت اطلاعات انجام نشد.'));
                }
            }).fail(() => reject(new Error('ارتباط با سرور برقرار نشد؛ دوباره تلاش کنید.')));
        });
    }
    
    setTerms(terms) {
        this.terms = terms.map(item => ({
            ...item,
            id:        Number(item.id),
            parent_id: Number(item.parent_id),
        }));
        this.map = new Map(this.terms.map(item => [item.id, item]));
        this.children = new Map();
        this.terms.forEach(item => {
            const parent = this.map.has(item.parent_id) && item.parent_id !== item.id ? item.parent_id : 0;
            if (!this.children.has(parent)) {
                this.children.set(parent, []);
            }
            this.children.get(parent).push(item);
        });
        if (!this.map.has(this.selected)) {
            this.selected = 0;
        }
        this.persist();
    }
    
    path(id) {
        const path    = [],
              visited = new Set();
        while (this.map.has(id) && !visited.has(id)) {
            visited.add(id);
            const item = this.map.get(id);
            path.unshift(item);
            id = item.parent_id;
        }
        return path;
    }
    
    descendants(id) {
        const found = new Set(),
              queue = [id];
        while (queue.length) {
            (this.children.get(queue.pop()) || []).forEach(child => {
                if (child.id !== id && !found.has(child.id)) {
                    found.add(child.id);
                    queue.push(child.id);
                }
            });
        }
        return found;
    }
    
    reveal(id) {
        this.path(id).forEach(item => { this.state.open[item.id] = true; });
        this.persist();
    }
    
    icon(item) {
        const icons = ['ni ni-folder', 'ni ni-book', 'ni ni-tag', 'ni ni-layers', 'ni ni-file-text', 'ni ni-star'];
        const colors = ['blue', 'green', 'purple', 'orange', 'red', 'gray'];
        return `<em aria-hidden="true" class="icon ${icons.includes(item.icon)
                                                     ? item.icon
                                                     : 'ni ni-folder'} ke-color-${colors.includes(item.color)
                                                                                  ? item.color
                                                                                  : 'blue'}"></em>`;
    }
    
    menu(item) {
        return `<details class="ke-menu"><summary aria-label="عملیات ${escape(item.name)}"><em class="icon ni ni-more-h"></em></summary><div class="ke-menu-items">
                <button type="button" data-command="edit" data-id="${item.id}">ویرایش</button>
                <button type="button" data-command="add" data-id="${item.id}">افزودن زیرمجموعه</button>
                <button type="button" data-command="status" data-id="${item.id}">${item.active
                                                                                   ? 'غیرفعال کردن'
                                                                                   : 'فعال کردن'}</button>
                <button type="button" data-command="move" data-id="${item.id}">تغییر والد</button>
                <button type="button" data-command="up" data-id="${item.id}">انتقال به بالا</button>
                <button type="button" data-command="down" data-id="${item.id}">انتقال به پایین</button>
                <button type="button" class="text-danger" data-command="delete" data-id="${item.id}" ${item.can_delete
                                                                                                       ? ''
                                                                                                       : 'disabled title="دارای زیرمجموعه یا استفاده در برنامه است"'}>حذف</button>
            </div></details>`;
    }
    
    renderTree() {
        const query = normalize(this.$root.find('.ke-search').val());
        const visible = new Set();
        if (query) {
            this.terms.forEach(item => {
                if (normalize(item.name + ' ' + item.slug).includes(query)) {
                    this.path(item.id).
                        forEach(parent => visible.add(parent.id));
                }
            });
        }
        const visited = new Set();
        const render = (item, level) => {
            if (visited.has(item.id) || (query && !visible.has(item.id))) {
                return '';
            }
            visited.add(item.id);
            const children = this.children.get(item.id) || [];
            const open = query ? true : (this.state.open[item.id] ?? level === 1);
            const selected = this.selected === item.id;
            return `<div class="ke-node" role="treeitem" aria-level="${level}" aria-selected="${selected}" ${children.length
                                                                                                             ? `aria-expanded="${open}"`
                                                                                                             : ''} data-node="${item.id}">
                    <div class="ke-row ${selected ? 'is-selected' : ''} ${item.active
                                                                          ? ''
                                                                          : 'is-inactive'}" data-row="${item.id}" draggable="${!query &&
            !this.busy}">
                    <button type="button" class="ke-toggle" data-toggle="${item.id}" aria-label="${open
                                                                                                   ? 'بستن'
                                                                                                   : 'بازکردن'} زیرمجموعه‌های ${escape(
                item.name)}" aria-expanded="${open}" ${children.length
                                                       ? ''
                                                       : 'disabled'}><em class="icon ni ${children.length
                                                                                          ? (open
                                                                                             ? 'ni-chevron-down'
                                                                                             : 'ni-chevron-left')
                                                                                          : 'ni-minus'}"></em></button>
                    <button type="button" class="ke-label" data-select="${item.id}">${this.icon(item)}<span>${escape(
                item.name)}</span>${!item.active ? '<small>غیرفعال</small>' : ''}</button>
                    <small class="ke-count" title="زیرمجموعه‌های مستقیم">${number(children.length)}</small>${this.menu(
                item)}</div>
                    ${children.length ? `<div class="ke-branches" role="group" ${open ? '' : 'hidden'}>${children.map(
                child => render(child, level + 1)).join('')}</div>` : ''}</div>`;
        };
        let html = (this.children.get(0) || []).map(item => render(item, 1)).join('');
        // Keep malformed legacy branches discoverable without infinite recursion.
        this.terms.forEach(item => {
            if (!visited.has(item.id)) {
                html += render(item, 1);
            }
        });
        this.$root.find('.ke-tree').
            html(html || `<div class="ke-empty">${query
                                                  ? 'نتیجه‌ای برای جستجو پیدا نشد.'
                                                  : 'دسته‌ای وجود ندارد؛ اولین دسته را اضافه کنید.'}</div>`);
    }
    
    renderDetails() {
        const item = this.map.get(this.selected);
        const panel = this.$root.find('.ke-details');
        if (!item) {
            panel.html(
                '<div class="ke-empty"><em class="icon ni ni-folder"></em><p>یک دسته را از درخت انتخاب کنید.</p></div>');
            return;
        }
        const children = this.children.get(item.id) || [];
        const crumbs = this.path(item.id).
            map(parent => `<button type="button" data-select="${parent.id}" ${parent.id === item.id
                                                                              ? 'aria-current="page"'
                                                                              : ''}>${escape(
                parent.name)}</button>`).
            join('<span aria-hidden="true"> / </span>');
        panel.html(`<nav class="ke-breadcrumb" aria-label="مسیر دسته">${crumbs}</nav>
                <div class="ke-identity">${this.icon(item)}<div><h4>${escape(
            item.name)}</h4><span class="badge ${item.active ? 'bg-success-dim' : 'bg-secondary-dim'}">${item.active
                                                                                                         ? 'فعال'
                                                                                                         : 'غیرفعال'}</span></div>${this.menu(
            item)}</div>
                ${item.active
                  ? ''
                  : '<p class="ke-inactive-message">این دسته غیرفعال است و در انتخاب‌های فعال برنامه نمایش داده نمی‌شود.</p>'}
                <dl class="ke-facts"><div><dt>کلید</dt><dd><bdi>${escape(
            item.slug)}</bdi></dd></div><div><dt>کل زیرمجموعه‌ها</dt><dd>${number(
            this.descendants(item.id).size)}</dd></div><div><dt>فرزندان مستقیم</dt><dd>${number(
            children.length)}</dd></div><div><dt>استفاده در برنامه</dt><dd>${number(item.usage)}</dd></div></dl>
                <p class="ke-description">${escape(item.description || 'توضیحی ثبت نشده است.')}</p>
                <div class="ke-detail-actions"><button type="button" class="btn btn-outline-primary" data-command="edit" data-id="${item.id}">ویرایش</button><button type="button" class="btn btn-primary" data-command="add" data-id="${item.id}">افزودن زیرمجموعه</button></div>
                <h6 class="ke-children-heading">زیرمجموعه‌های مستقیم <small>(${number(children.length)})</small></h6>
                <div class="ke-child-list">${children.length ? children.map(
                child => `<article class="ke-child ${child.active
                                                     ? ''
                                                     : 'is-inactive'}"><div class="ke-child-title">${this.icon(
                    child)}<button type="button" data-select="${child.id}">${escape(child.name)}</button>${this.menu(
                    child)}</div><p>${escape(
                    child.description || 'بدون توضیحات')}</p><div class="ke-child-footer"><span>${child.active
                                                                                                  ? 'فعال'
                                                                                                  : 'غیرفعال'} · ${number(
                    child.children_count)} فرزند</span><button type="button" class="btn btn-sm btn-outline-light" data-select="${child.id}">ورود به دسته <em class="icon ni ni-arrow-right"></em></button></div></article>`).
            join('') : '<div class="ke-empty">این دسته زیرمجموعه‌ای ندارد.</div>'}</div>`);
    }
    
    notice(message, error = false) {
        this.$root.find('.ke-notice').prop('hidden', !message).toggleClass('is-error', error).text(message);
    }
    
    async load(id = this.selected) {
        if (this.busy) {
            return;
        }
        const sequence = ++this.sequence;
        if (id) {
            this.selected = id;
        }
        this.$root.find('.ke-panel').attr('aria-busy', 'true');
        if (id) {
            this.$root.find('.ke-details').
                html('<div class="ke-empty" role="status">در حال بارگذاری اطلاعات…</div>');
        }
        try {
            const terms = await this.request(id ? 'details' : 'list', {term_id: id});
            if (sequence !== this.sequence || !this.root.isConnected) {
                return;
            }
            this.setTerms(terms);
            this.reveal(this.selected);
            this.renderTree();
            this.renderDetails();
            this.notice('');
        } catch (error) {
            if (sequence !== this.sequence || !this.root.isConnected) {
                return;
            }
            this.$root.find('.ke-details').
                html(`<div class="ke-empty" role="alert">${escape(
                    error.message)}<button type="button" class="btn btn-outline-primary ke-retry">تلاش دوباره</button></div>`);
            if (!this.terms.length) {
                this.$root.find('.ke-tree').
                    html(
                        '<div class="ke-empty">بارگذاری دسته‌ها انجام نشد.<button type="button" class="btn ke-retry">تلاش دوباره</button></div>');
            }
            this.notice(error.message, true);
        } finally {
            if (sequence === this.sequence) {
                this.$root.find('.ke-panel').attr('aria-busy', 'false');
            }
        }
    }
    
    select(id, trigger) {
        if (this.busy || !this.map.has(id)) {
            return;
        }
        this.lastTrigger = trigger;
        this.selected = id;
        this.reveal(id);
        this.renderTree();
        this.$root.find(`[data-row="${id}"]`)[0]?.scrollIntoView({block: 'nearest'});
        if (window.matchMedia('(max-width: 767px)').matches) {
            this.$root.addClass('is-sheet-open').find('.ke-backdrop').prop('hidden', false);
            this.$root.find('.ke-panel').
                attr({
                    role:         'dialog',
                    'aria-modal': 'true',
                });
            this.$root.find('.ke-sidebar')[0].inert = true;
            this.$root.find('.ke-close').trigger('focus');
        }
        this.load(id);
    }
    
    closeSheet() {
        this.$root.removeClass('is-sheet-open').find('.ke-backdrop').prop('hidden', true);
        this.$root.find('.ke-panel').removeAttr('role aria-modal');
        this.$root.find('.ke-sidebar')[0].inert = false;
        (this.lastTrigger?.isConnected ? this.lastTrigger : this.$root.find(
            `[data-select="${this.selected}"]`)[0])?.focus();
    }
    
    async mutate(operation, data) {
        if (this.busy) {
            return;
        }
        this.busy = true;
        ++this.sequence;
        this.$root.attr('aria-busy', 'true');
        this.notice('در حال ذخیره…');
        try {
            const terms = await this.request(operation, data);
            if (!this.root.isConnected) {
                return;
            }
            this.setTerms(terms);
            if (operation === 'move') {
                this.selected = Number(data.term_id);
                this.reveal(this.selected);
            }
            this.renderTree();
            this.renderDetails();
            this.notice('تغییرات ذخیره شد.');
        } catch (error) {
            this.notice(error.message + ' برای بررسی وضعیت فعلی، اطلاعات را دوباره بارگذاری کنید.', true);
        } finally {
            this.busy = false;
            this.$root.attr('aria-busy', 'false');
            this.$root.find('.ke-panel').attr('aria-busy', 'false');
        }
    }
    
    form(id, add = false) {
        if (this.busy) {
            return;
        }
        const item = this.map.get(id);
        const taxonomy = this.root.dataset.taxonomy;
        const prefix = '#kerp-program-term-' + taxonomy;
        const fields = {
            term_id:     ['', 'text', 'id'],
            taxonomy_id: [taxonomy, 'text', 'taxonomy-id'],
            return_page: ['/erp/programs/settings/terms/?taxonomy_id=' + taxonomy, 'text', 'return-page'],
            name:        ['', 'text', 'name'],
            slug:        ['', 'text', 'slug'],
            description: ['', 'text', 'description'],
            parent_id:   [add ? id : 0, 'select', 'parent-id'],
            sort_order:  [10, 'text', 'sort-order'],
            active:      [1, 'switch', 'active'],
            icon:        ['ni ni-folder', 'select', 'icon'],
            color:       ['blue', 'select', 'color'],
        };
        if (item && !add) {
            Object.keys(fields).
                forEach(key => {
                    if (key === 'term_id') {
                        fields[key][0] = item.id;
                    } else if (key in item) {
                        fields[key][0] = item[key];
                    }
                });
        }
        const modal = $('#programTermModal' + taxonomy);
        const parent = modal.find('[name="parent_id"]');
        parent.empty().append($('<option>').val(0).text('بدون والد (گزینهٔ اصلی)'));
        const excluded = !add && item ? this.descendants(id).add(id) : new Set();
        this.terms.forEach(term => {
            if (!excluded.has(term.id)) {
                parent.append(
                    $('<option>').val(term.id).text(this.path(term.id).map(node => node.name).join(' / ')));
            }
        });
        const populate = {};
        Object.entries(fields).
            forEach(([key, [value, type, suffix]]) => {
                populate[key] = {
                    id: prefix + '-' + suffix,
                    type,
                    value,
                };
            });
        this.closeSheet();
        const button = $('<button type="button" class="open_populate_modal" hidden>').
            attr('data-modal', '#programTermModal' + taxonomy).
            attr('data-populate', JSON.stringify(populate)).
            appendTo(this.root);
        button.trigger('click').remove();
    }
    
    moveDialog(id) {
        this.moveId = id;
        const excluded = this.descendants(id).add(id);
        const modal = $('#programTermMoveModal' + this.root.dataset.taxonomy);
        const select = modal.find('.ke-destination').empty().append($('<option>').val(0).text('سطح اصلی'));
        this.terms.forEach(item => {
            if (!excluded.has(item.id)) {
                select.append(
                    $('<option>').val(item.id).text(this.path(item.id).map(node => node.name).join(' / ')));
            }
        });
        select.val(this.map.get(id).parent_id);
        select.trigger('change');
        modal.modal('show');
    }
    
    command(command, id) {
        if (this.busy) {
            return;
        }
        this.$root.find('.ke-menu').removeAttr('open');
        const item = this.map.get(id);
        if (!item) {
            return;
        }
        if (command === 'edit' || command === 'add') {
            this.form(id, command === 'add');
        }
        if (command === 'move') {
            this.moveDialog(id);
        }
        if (command === 'status') {
            this.mutate('status', {
                term_id: id,
                active:  item.active ? 0 : 1,
            });
        }
        if (command === 'delete' && item.can_delete &&
            window.confirm('دستهٔ «' + item.name + '» حذف شود؟')) {
            this.mutate('delete', {term_id: id});
        }
        if (command === 'up' || command === 'down') {
            const siblings = this.children.get(item.parent_id) || [];
            const index = siblings.findIndex(node => node.id === id);
            if ((command === 'up' && index <= 0) || (command === 'down' && index === siblings.length - 1)) {
                return;
            }
            this.mutate('move', {
                term_id:   id,
                parent_id: item.parent_id,
                before_id: command === 'up' ? siblings[index - 1].id : (siblings[index + 2]?.id || 0),
            });
        }
    }
    
    dropPlan(event, row) {
        const id     = Number(row.dataset.row),
              source = this.map.get(this.dragId),
              target = this.map.get(id);
        if (!source || !target || id === source.id || this.descendants(source.id).has(id)) {
            return null;
        }
        const box   = row.getBoundingClientRect(),
              ratio = (event.clientY - box.top) / box.height;
        const placement = ratio < .25 ? 'before' : ratio > .75 ? 'after' : 'inside';
        let parent_id = target.id,
            before_id = 0;
        if (placement !== 'inside') {
            parent_id = target.parent_id;
            const siblings = (this.children.get(parent_id) || []).filter(node => node.id !== source.id);
            const index = siblings.findIndex(node => node.id === target.id);
            before_id = placement === 'before' ? target.id : (siblings[index + 1]?.id || 0);
        }
        return {
            placement,
            term_id: source.id,
            parent_id,
            before_id,
        };
    }
    
    bind() {
        const $root = this.$root;
        $root.on('click', '[data-select]',
            event => { this.select(Number(event.currentTarget.dataset.select), event.currentTarget); });
        $root.on('click', '[data-toggle]', event => {
            const id = Number(event.currentTarget.dataset.toggle);
            this.state.open[id] = event.currentTarget.getAttribute('aria-expanded') !== 'true';
            this.persist();
            this.renderTree();
            $root.find(`[data-toggle="${id}"]`).trigger('focus');
        });
        $root.on('click', '[data-command]', event => {
            this.command(event.currentTarget.dataset.command, Number(event.currentTarget.dataset.id));
        });
        $root.on('input', '.ke-search', () => this.renderTree());
        $root.on('click', '.ke-new', () => this.form(0, true));
        $root.on('click', '.ke-retry', () => this.load());
        $root.on('click', '.ke-expand', event => {
            this.terms.forEach(item => { this.state.open[item.id] = event.currentTarget.dataset.open === '1'; });
            this.persist();
            this.renderTree();
        });
        $root.on('click', '.ke-close, .ke-backdrop', () => this.closeSheet());
        $(document).on('click', '#programTermMoveModal' + this.root.dataset.taxonomy + ' .ke-move-confirm', () => {
            const modal = $('#programTermMoveModal' + this.root.dataset.taxonomy);
            const destination = Number(modal.find('.ke-destination').val());
            modal.modal('hide');
            this.mutate('move', {
                term_id:   this.moveId,
                parent_id: destination,
                before_id: 0,
            });
        });
        $root.on('keydown', '.ke-panel', event => {
            if (!$root.hasClass('is-sheet-open')) {
                return;
            }
            if (event.key === 'Escape') {
                event.preventDefault();
                this.closeSheet();
            }
            if (event.key === 'Tab') {
                const focusable = $root.find('.ke-panel button:visible:not(:disabled), .ke-panel summary:visible').
                    toArray();
                const first = focusable[0],
                      last  = focusable[focusable.length - 1];
                if (event.shiftKey && event.target === first) {
                    event.preventDefault();
                    last?.focus();
                }
                if (!event.shiftKey && event.target === last) {
                    event.preventDefault();
                    first?.focus();
                }
            }
        });
        $root.on('keydown', '.ke-label', event => {
            const labels = $root.find('.ke-tree .ke-label:visible').toArray(),
                  index  = labels.indexOf(event.currentTarget);
            if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
                event.preventDefault();
                labels[index + (event.key === 'ArrowDown' ? 1 : -1)]?.focus();
            }
            if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') {
                event.preventDefault();
                const id = Number(event.currentTarget.dataset.select);
                this.state.open[id] = event.key === 'ArrowLeft';
                this.persist();
                this.renderTree();
                $root.find(`[data-select="${id}"]`).first().trigger('focus');
            }
        });
        $root.on('dragstart', '[data-row]', event => {
            if (this.busy || $root.find('.ke-search').val() || window.matchMedia('(max-width: 767px)').matches ||
                $(event.target).closest('.ke-menu').length) {
                event.preventDefault();
                return;
            }
            this.dragId = Number(event.currentTarget.dataset.row);
            event.originalEvent.dataTransfer.effectAllowed = 'move';
            event.originalEvent.dataTransfer.setData('text/plain', String(this.dragId));
        });
        $root.on('dragover', '[data-row], [data-root-drop]', event => {
            if (!this.dragId || this.busy) {
                return;
            }
            const row = event.currentTarget;
            const plan = row.dataset.rootDrop ? {
                placement: 'inside',
                term_id:   this.dragId,
                parent_id: 0,
                before_id: 0,
            } : this.dropPlan(event.originalEvent, row);
            $root.find('[data-drop]').removeAttr('data-drop');
            if (!plan) {
                return;
            }
            event.preventDefault();
            event.stopPropagation();
            row.dataset.drop = plan.placement;
        });
        $root.on('drop', '[data-row], [data-root-drop]', event => {
            event.preventDefault();
            event.stopPropagation();
            const row = event.currentTarget;
            const plan = row.dataset.rootDrop ? {
                term_id:   this.dragId,
                parent_id: 0,
                before_id: 0,
            } : this.dropPlan(event.originalEvent, row);
            $root.find('[data-drop]').removeAttr('data-drop');
            if (this.dragId && plan) {
                this.mutate('move', plan);
            }
            this.dragId = 0;
        });
        $root.on('dragend', () => {
            this.dragId = 0;
            $root.find('[data-drop]').removeAttr('data-drop');
        });
    }
}

function init() {
    document.querySelectorAll('.kerp-explorer').
        forEach(root => {
            if (!instances.has(root)) {
                instances.set(root, new Explorer(root));
            }
        });
}

$(function() {
    init();
    new MutationObserver(records => {
        if (records.some(record => [...record.addedNodes].some(node => node.nodeType === 1 &&
            (node.matches('.kerp-explorer') || node.querySelector('.kerp-explorer'))))) {
            init();
        }
    }).observe(document.body, {
        childList: true,
        subtree:   true,
    });
});



/* ===== tickets.js ===== */
function kerpTicketsRequest(options, retried = false) {
    return $.ajax(options).then(function (response) {
        if (!retried && response && response.code === 'ticket_nonce_expired' && response.tickets_nonce) {
            const nonce = response.tickets_nonce;
            if (options.data instanceof FormData) options.data.set('tickets_nonce', nonce);
            else options.data.tickets_nonce = nonce;
            $('.kerp-ticket-form [name="tickets_nonce"], .kerp-ticket-nonce').val(nonce).attr('value', nonce);
            return kerpTicketsRequest(options, true);
        }
        return response;
    });
}
function kerpTicketsNotify(message, type = 'error') { NioApp.Toast($('<div>').text(message == null ? '' : String(message)).html(), type, {position: 'top-right'}); }
// Ticket forms use the shared ERP endpoint and components; this source is bundled by watcher.js.
async function kerpTicketsSubmit(form) {
    const $form = $(form);
    if ($form.data('busy') || !form.reportValidity()) return;
    const data = new FormData(form);
    $form.find('[data-for]').each(function () {
        const key = $(this).attr('data-for');
        if (this.matches('input,select,textarea') && !this.name) data.set(key, $(this).val() || '');
        if ($(this).hasClass('quill-basic')) { const quill = this.__quill || $(this).data('quill'); data.set(key, quill ? quill.root.innerHTML : $(this).find('.quill-value').val() || ''); }
    });
    const migration = data.get('operation') === 'migrate';
    data.set('action', 'tickets_save');
    $form.data('busy', true).attr('aria-busy', 'true').find('[type="submit"], .submit_modal_form').prop('disabled', true);
    try { await kerpTicketsUploadFiles(form, data, ajax_url, 'tickets_save'); }
    catch (error) { kerpTicketsNotify(error.message || 'آپلود ناموفق بود.'); $form.data('busy', false).removeAttr('aria-busy').find('[type="submit"], .submit_modal_form').prop('disabled', false); return; }
    kerpTicketsRequest({url: ajax_url, method: 'POST', data: data, processData: false, contentType: false, dataType: 'json'})
        .done(function (response) {
            if ((!response.main || response.status !== 'success') && (!migration || response.done || response.status !== 'success')) kerpTicketsNotify(response.message || 'پاسخ نامعتبر از سرور', response.status === 'success' ? 'success' : 'error');
            if (response.status !== 'success') return;
            if (response.ready_rows) {
                $('.kerp-ticket-ready-items').each(function () { const list = $(this).empty(); response.ready_rows.forEach(function (row) { $('<button>', {type:'button',class:'dropdown-item kerp-ticket-ready-insert',text:row.label}).attr({'data-content':row.content,'data-department':row.department || ''}).appendTo(list); }); });
                $('#kerp-ticket-quick-ready').modal('hide');
            } else if (migration) {
                if (!response.done) {
                    NioApp.Toast('موارد باقی‌مانده: ' + response.remaining, 'info', {position: 'top-right', clear: true});
                    setTimeout(function () { if (document.contains(form)) kerpTicketsSubmit(form); }, 150);
                }
            } else if (response.main) { change_panel_html(response); } else if (response.url) { window.location.assign(response.url); }
        }).fail(function () { kerpTicketsNotify('ارتباط با سرور برقرار نشد. دوباره تلاش کنید؛ انتقال از محل توقف ادامه می‌یابد.'); })
        .always(function () { $form.data('busy', false).removeAttr('aria-busy').find('[type="submit"], .submit_modal_form').prop('disabled', false); });
}
$(document).on('submit', '.kerp-ticket-form', function (event) { event.preventDefault(); kerpTicketsSubmit(this); });
$(document).on('show.bs.modal', '[id^="kerp-ticket-taxonomy-"], #kerp-ticket-ready-modal', function (event) {
    const record = $(event.relatedTarget).data('record') || {}; const form = $(this).find('form')[0]; if (!form) return;
    form.reset();
    ['index', 'slug', 'label', 'content', 'department', 'employee_id'].forEach(function (key) { $(form).find('[name="' + key + '"]').val(record[key] == null ? '' : record[key]).trigger('change'); });
    $(form).find('[name="slug"]').prop('readonly', record.slug != null);
});
$(document).on('change', '.kerp-ticket-select-all', function () { $(this).closest('.kerp-tickets').find('.kerp-ticket-check').prop('checked', this.checked); });
$(document).on('show.bs.modal', '#kerp-ticket-access', function (event) {
    const $trigger = $(event.relatedTarget);
    $(this).find('[name="employee_id"]').val($trigger.attr('data-employee'));
    $(this).find('[name="tags[]"]').val($trigger.data('tags') || []).trigger('change');
});
$(document).on('click', '.kerp-ticket-bulk', function (event) {
    event.preventDefault();
    const $section = $(this).closest('.kerp-tickets');
    const ids = $section.find('.kerp-ticket-check:checked').map(function () { return this.value; }).get();
    if (!ids.length) { kerpTicketsNotify('ابتدا تیکت‌ها را انتخاب کنید.'); return; }
    const status = $(this).attr('data-value') || $(this).attr('data-operation') || $(this).attr('data-key');
    if (!status) return;
    const $button = $(this); if ($button.data('busy')) return; $button.data('busy', true);
    kerpTicketsRequest({url: ajax_url, method: 'POST', dataType: 'json', data: { action: 'tickets_save', operation: 'bulk', status: status, ids: ids, tickets_nonce: $section.find('.kerp-ticket-nonce').val() }}).done(function (response) {
        if (response.status === 'success') window.location.reload();
        else kerpTicketsNotify(response.message || 'عملیات انجام نشد.');
    }).fail(function () { kerpTicketsNotify('خطای ارتباط با سرور'); }).always(function () { $button.data('busy', false); });
});

async function kerpTicketsUploadFiles(form, data, endpoint, action, selectedFiles) {
    const zone = form.querySelector('.upload-zone');
    const dz = zone && zone.dropzone;
    if (!selectedFiles && zone && !dz) throw new Error('بارگذاری بخش پیوست‌ها کامل نشده است؛ صفحه را تازه کنید.');
    if (!selectedFiles && dz && dz.files.some(function (file) { return !file.accepted; })) throw new Error('فایل نامعتبر را از پیوست‌ها حذف کنید.');
    if (!selectedFiles) {
        if (!dz) return [];
        if (dz.getQueuedFiles().length || dz.getUploadingFiles().length) {
            await new Promise(function (resolve) { const done = function () { dz.off('queuecomplete', done); resolve(); }; dz.on('queuecomplete', done); });
        }
        const attachments = dz.getAcceptedFiles();
        if (attachments.some(function (file) { return file.status !== Dropzone.SUCCESS || !file._ticket_token; })) throw new Error('آپلود پیوست کامل نشده است؛ فایل ناموفق را دوباره انتخاب کنید.');
        attachments.forEach(function (file) { data.append('file_tokens[]', file._ticket_token); });
        return attachments.map(function (file) { return file._uploaded_url; });
    }
    const files = selectedFiles || (dz ? dz.getAcceptedFiles().slice() : []);
    if (files.length > 50) throw new Error('حداکثر ۵۰ فایل مجاز است.');
    const cached = $(form).data('ticket-files') || new Map(); $(form).data('ticket-files', cached);
    const urls = $(form).data('ticket-file-urls') || new Map(); $(form).data('ticket-file-urls', urls);
    for (let index = 0; index < files.length; index++) {
        const file = files[index]; const key = file.name + ':' + file.size + ':' + file.lastModified;
        if (!cached.has(key)) {
            const uuid = (window.crypto && crypto.randomUUID) ? crypto.randomUUID() : String(Date.now()) + '-' + Math.random().toString(36).slice(2);
            const chunkSize = 1024 * 1024; const chunks = Math.max(1, Math.ceil(file.size / chunkSize));
            for (let chunk = 0; chunk < chunks; chunk++) {
                const upload = new FormData(); upload.set('action', action); upload.set('operation', 'upload');
                upload.set('ticket_id', data.get('ticket_id') || '0'); upload.set('tickets_nonce', data.get('tickets_nonce'));
                upload.set('file', file.slice(chunk * chunkSize, (chunk + 1) * chunkSize), file.name);
                upload.set('dzuuid', uuid); upload.set('dzchunkindex', chunk); upload.set('dztotalchunkcount', chunks); upload.set('dztotalfilesize', file.size);
                const response = await kerpTicketsRequest({url: endpoint, method: 'POST', data: upload, processData: false, contentType: false, dataType: 'json'});
                if (response.status !== 'success') throw new Error(response.message || 'آپلود ناموفق بود.');
                if (response.token) cached.set(key, response.token);
                if (response.url) urls.set(key, response.url);
                if (dz && dz.files.includes(file)) dz.emit('uploadprogress', file, (chunk + 1) * 100 / chunks, Math.min(file.size, (chunk + 1) * chunkSize));
            }
            if (!cached.has(key)) throw new Error('تکمیل آپلود تأیید نشد.');
        }
        data.append('file_tokens[]', cached.get(key));
    }
    return files.map(function (file) { return urls.get(file.name + ':' + file.size + ':' + file.lastModified); });
}


async function kerpTicketsUploadInlineImages(form, quill, files, range) {
    const $form = $(form);
    if ($form.data('busy')) { kerpTicketsNotify('تا پایان آپلود فعلی صبر کنید.'); return; }
    if (!files.length) return;
    if (!Quill.imports['formats/kerpTicketUploadingImage']) {
        const Base = Quill.import('blots/block/embed');
        class KerpTicketUploadingImage extends Base {
            static create(value) { const node = super.create(); node.dataset.uploadId = value.id; node.setAttribute('aria-label','در حال آپلود تصویر'); const img = document.createElement('img'); img.src = value.src; img.alt = 'در حال آپلود'; node.appendChild(img); return node; }
            static value(node) { return {id:node.dataset.uploadId,src:node.querySelector('img').src}; }
        }
        KerpTicketUploadingImage.blotName = 'kerpTicketUploadingImage'; KerpTicketUploadingImage.tagName = 'span'; KerpTicketUploadingImage.className = 'image-uploading';
        Quill.register(KerpTicketUploadingImage);
    }
    $form.data('busy', true).attr('aria-busy','true').find('[type="submit"], .submit_modal_form').prop('disabled',true);
    let index = range ? range.index : Math.max(0, quill.getLength()-1);
    try {
        for (const file of files) {
            const id = 'kt-' + Date.now() + '-' + Math.random().toString(36).slice(2), preview = URL.createObjectURL(file);
            quill.insertEmbed(index, 'kerpTicketUploadingImage', {id:id,src:preview}, 'user');
            quill.setSelection(index+1,0,'silent');
            try {
                const data = new FormData(form), isPublic = $form.attr('data-public') === '1';
                const urls = await kerpTicketsUploadFiles(form,data,isPublic ? $form.attr('data-endpoint') : ajax_url,isPublic ? 'kerp_tickets_save' : 'tickets_save',[file]);
                if (!urls[0]) throw new Error('نشانی تصویر دریافت نشد.');
                const node = quill.root.querySelector('[data-upload-id="'+id+'"]');
                if (node) { index = quill.getIndex(Quill.find(node)); quill.deleteText(index,1,'silent'); quill.insertEmbed(index,'image',urls[0],'user'); index++; quill.setSelection(index,0,'silent'); }
            } catch (error) {
                const node = quill.root.querySelector('[data-upload-id="'+id+'"]');
                if (node) quill.deleteText(quill.getIndex(Quill.find(node)),1,'user');
                throw error;
            } finally { URL.revokeObjectURL(preview); }
        }
    } catch (error) { kerpTicketsNotify(error.message || 'آپلود تصویر ناموفق بود؛ دوباره تلاش کنید.'); }
    finally { $form.data('busy',false).removeAttr('aria-busy').find('[type="submit"], .submit_modal_form').prop('disabled',false); }
}

$(document).on('click', '.kerp-ticket-download-all', function () {
    $(this).closest('.kerp-ticket-attachments').find('.kerp-ticket-file').each(function (index) {
        const url = this.href, name = this.textContent;
        setTimeout(function () { const link = document.createElement('a'); link.href = url; link.download = name; link.rel = 'noopener'; link.target = '_blank'; document.body.appendChild(link); link.click(); link.remove(); }, index * 200);
    });
});

function kerpTicketsInitComposer() {
    $('.modal_form[data-action="tickets_save"], .modal_form[data-action="kerp_tickets_save"]').each(function () {
        const form = this, $form = $(form);
        if ($form.data('ticket-modal-ready')) return;
        $form.data('ticket-modal-ready', true).addClass('kerp-ticket-form');
        $form.find('input[data-for], select[data-for], textarea[data-for]').each(function () { this.name = this.getAttribute('data-for'); });
        const isPublic = $form.attr('data-action') === 'kerp_tickets_save';
        $form.attr('data-public', isPublic ? '1' : '0');
        $form.attr('data-endpoint', isPublic ? nooshika_panel.ajax_url : ajax_url);
        $form.find('.submit_modal_form').attr({role: 'button', tabindex: '0'}).on('click', function (event) {
            event.preventDefault(); event.stopPropagation();
            if (!$form.data('busy')) $form.trigger('submit');
        }).on('keydown', function (event) { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); $(this).trigger('click'); } });
    });
    $('.kerp-ticket-form').each(function () {
        const form = this;
        const editor = form.querySelector('.quill-basic[data-for="content"]');
        const quill = editor && (editor.__quill || $(editor).data('quill'));

        if (quill && window.ImageUploader && !editor.dataset.ticketClipboardReady) {
            editor.dataset.ticketClipboardReady = '1';
            const toolbar = quill.getModule('toolbar');
            const uploader = new ImageUploader(quill, {
                upload: function (file) { return kerpTicketsUploadInlineImages(form, quill, file ? [file] : [], uploader.range || quill.getSelection(true)); }
            });
            // Keep the original picker/paste/drop behavior, but replace only our own
            // pending embed: the legacy uploader deletes three characters at a fixed index.
            uploader.readAndUploadFile = function (file) { return this.options.upload(file); };
            quill.theme.modules.imageUploader = uploader;
            if (toolbar && toolbar.container && !toolbar.container.querySelector('.ql-image')) {
                const group = document.createElement('span'); group.className = 'ql-formats';
                const button = document.createElement('button'); button.type = 'button'; button.className = 'ql-image';
                button.title = 'درج تصویر در متن'; button.setAttribute('aria-label', button.title);
                button.innerHTML = Quill.import('ui/icons').image;
                button.addEventListener('mousedown', function (event) { event.preventDefault(); });
                button.addEventListener('click', function () { if ($(form).data('busy')) return; quill.focus(); uploader.selectLocalImage(); });
                group.appendChild(button); toolbar.container.appendChild(group);
            }
        }
        const zone = form.querySelector('.upload-zone');
        if (zone && !zone.dropzone) NioApp.Dropzone.init();
    });
}
$(kerpTicketsInitComposer);
let kerpTicketsComposerPending = false;
new MutationObserver(function () {
    if (kerpTicketsComposerPending) return;
    kerpTicketsComposerPending = true;
    setTimeout(function () { kerpTicketsComposerPending = false; kerpTicketsInitComposer(); }, 0);
}).observe(document.body, {childList:true, subtree:true});

$(document).on('click', '.kerp-ticket-image-preview, .kerp-ticket-chat .kerp-ticket-message-body img', function (event) {
    event.preventDefault();
    event.stopPropagation();
    const trigger = this, inline = this.tagName === 'IMG';
    const url = inline ? (this.currentSrc || this.src) : this.href;
    const name = inline ? (this.alt || '') : ($(this).attr('data-image-name') || '');
    if (!url) return;
    if ($.magnificPopup && $.magnificPopup.open) {
        $.magnificPopup.open({items:{src:url},type:'image',mainClass:'kerp-ticket-magnifier',closeOnContentClick:false,image:{verticalFit:true,titleSrc:function(){return $('<div>').text(name).html();}}});
        return;
    }
    const dialog = document.createElement('dialog'); dialog.className = 'kerp-ticket-image-dialog'; dialog.setAttribute('aria-label', name || 'نمایش تصویر');
    const close = document.createElement('button'); close.type = 'button'; close.className = 'kerp-ticket-image-close'; close.textContent = 'بستن ×';
    const viewport = document.createElement('div'); viewport.className = 'kerp-ticket-image-viewport';
    const zoom = document.createElement('button'); zoom.type = 'button'; zoom.className = 'kerp-ticket-image-zoom'; zoom.setAttribute('aria-label','بزرگ‌نمایی تصویر'); zoom.setAttribute('aria-pressed','false');
    const img = document.createElement('img'); img.src = url; img.alt = name; zoom.appendChild(img); viewport.appendChild(zoom);
    dialog.append(close, viewport); document.body.appendChild(dialog);
    close.addEventListener('click', function(){dialog.close();});
    zoom.addEventListener('click', function(){const enlarged=viewport.classList.toggle('is-zoomed');zoom.setAttribute('aria-pressed',String(enlarged));});
    dialog.addEventListener('click', function(e){if(e.target===dialog)dialog.close();});
    dialog.addEventListener('close', function(){dialog.remove();if(document.contains(trigger))trigger.focus();},{once:true});
    dialog.showModal(); close.focus();
});

function kerpTicketsReadyFilter(menu) {
    const $menu = $(menu), form = $menu.closest('form');
    const department = form.find('[name="department"]').val() || $menu.attr('data-department') || '';
    let count = 0;
    $menu.find('.kerp-ticket-ready-insert').each(function () { const value = $(this).attr('data-department'); const visible = !department || !value || value === department; $(this).toggleClass('d-none', !visible); if (visible) count++; });
    $menu.find('.kerp-ticket-ready-empty').toggleClass('d-none', count > 0);
}
$(document).on('show.bs.dropdown', '.kerp-ticket-ready-menu', function () { kerpTicketsReadyFilter(this); });
$(document).on('click', '.kerp-ticket-ready-insert', function () {
    const editor = $(this).closest('form').find('.quill-basic[data-for="content"]')[0];
    const quill = editor && (editor.__quill || $(editor).data('quill')); if (!quill) return;
    const range = quill.getSelection(); const index = range ? range.index : Math.max(0, quill.getLength() - 1);
    quill.clipboard.dangerouslyPasteHTML(index, $(this).attr('data-content') || '', 'user'); quill.focus();
});
$(document).on('show.bs.modal', '#kerp-ticket-quick-ready', function (event) {
    const source = $(event.relatedTarget).closest('form'), editor = source.find('.quill-basic[data-for="content"]')[0];
    const quill = editor && (editor.__quill || $(editor).data('quill'));
    $(this).data('ticket-parent-modal', source.closest('.modal')[0] || null);
    const form = $(this).find('form')[0]; form.reset();
    $(form).find('[name="department"]').val(source.find('[name="department"]').val() || source.find('.kerp-ticket-ready-menu').attr('data-department') || '').trigger('change');
    $(form).find('[name="content"]').val(quill ? quill.root.innerHTML : '');
});
$(document).on('hidden.bs.modal', '#kerp-ticket-quick-ready', function () {
    const parent = $(this).data('ticket-parent-modal'); if (parent && document.contains(parent)) $(parent).modal('show');
    $(this).removeData('ticket-parent-modal');
});

$(document).on('click', '[data-ticket-upload-toggle]', function () { const target = document.getElementById(this.getAttribute('aria-controls')); if (!target) return; target.hidden = !target.hidden; this.setAttribute('aria-expanded', String(!target.hidden)); });

$(document).on('click', '.kerp-ticket-chat [data-ticket-menu-submit]', function (event) { event.preventDefault(); const form = this.closest('form'); if (form) form.requestSubmit(); });



/* ===== user-export.js ===== */
// Optional toolbar component. Each module registers its own scoped ID provider.
const kerpUserExportStates = new Map();

function kerpUserExportTooltips(root) {
    const $buttons = $(root).find('[data-bs-toggle="tooltip"]');
    $buttons.tooltip('dispose');
    if (root.isConnected) {
        $buttons.filter(':visible').tooltip({
            trigger: 'hover focus',
            template: '<div class="tooltip" role="tooltip" style="pointer-events:none"><div class="tooltip-arrow"></div><div class="tooltip-inner"></div></div>'
        });
    }
}

function kerpUserExportCell(value) {
    let text = String(value ?? '');
    // Neutralize spreadsheet formulas without embedding executable formulas for phone numbers.
    if (/^[\s\u0000-\u001f]*[=+@-]/.test(text) || /^[\t\r\n]/.test(text)) text = "'" + text;
    return '"' + text.replace(/"/g, '""') + '"';
}

function kerpUserExportReset(root) {
    const state = kerpUserExportStates.get(root);
    kerpUserExportStates.delete(root);
    if (state?.request) state.request.abort();
    if (state?.url) URL.revokeObjectURL(state.url);
    const $root = $(root);
    $root.find('[data-bs-toggle="tooltip"]').tooltip('dispose');
    $root.attr('aria-busy', 'false');
    $root.find('.kerp-user-export-start').prop('hidden', false).removeClass('d-none');
    $root.find('.kerp-user-export-progress, .kerp-user-export-download').prop('hidden', true).addClass('d-none');
    $root.find('.kerp-user-export-download').removeAttr('href download');
    kerpUserExportTooltips(root);
}

async function kerpUserExportRun(root) {
    if (kerpUserExportStates.has(root)) return;
    const $root = $(root);
    const state = {request: null, url: null, chunks: ['\uFEFF"نام و نام خانوادگی","شماره تماس"\r\n'], seen: new Set()};
    const current = () => root.isConnected && kerpUserExportStates.get(root) === state;
    try {
        const $filters = $($root.attr('data-export-filter-selector'));
        if ($filters.length !== 1) throw new Error('محدوده فیلتر خروجی معتبر نیست.');
        // Freeze the filters at click time, including the current search. Never read IDs from the DOM.
        const filters = $.extend(true, {}, JSON.parse($root.attr('data-export-filters') || '{}'), get_current_page_filters($filters));
        const perPage = Number($root.attr('data-export-per-page'));
        kerpUserExportStates.set(root, state);
        $root.find('[data-bs-toggle="tooltip"]').tooltip('dispose');
        $root.attr('aria-busy', 'true');
        $root.find('.kerp-user-export-start').prop('hidden', true).addClass('d-none');
        $root.find('.kerp-user-export-progress').prop('hidden', false).removeClass('d-none');
        $root.find('.progress-bar').css('width', '0%').attr('aria-valuenow', 0);
        $root.find('.kerp-user-export-label').text('در حال دریافت…');
        $root.find('.kerp-user-export-status').text('دریافت خروجی آغاز شد.');
        kerpUserExportTooltips(root);
        let total = null;
        let pages = null;
        for (let page = 1; ; page++) {
            state.request = $.ajax({
                url: ajax_url, type: 'POST', dataType: 'json', timeout: 30000,
                // Progress belongs to this component; do not activate the panel loading overlay.
                global: false,
                data: $.extend(true, {}, filters, {
                    action: $root.attr('data-export-action'), export_nonce: $root.attr('data-export-nonce'),
                    page_number: page, per_page: perPage
                })
            });
            const response = await state.request;
            state.request = null;
            if (!current()) return;
            if (response.status !== 'success') throw new Error(response.message || 'دریافت خروجی ناموفق بود.');
            if (!Number.isSafeInteger(response.total) || response.total < 0 || response.page_number !== page ||
                response.per_page !== perPage || response.total_pages !== Math.ceil(response.total / perPage) ||
                !Array.isArray(response.user_ids) || !Array.isArray(response.rows) || response.rows.length !== response.user_ids.length) {
                throw new Error('پاسخ صفحه‌بندی خروجی معتبر نیست.');
            }
            if (total === null) { total = response.total; pages = response.total_pages; }
            if (response.total !== total || response.total_pages !== pages ||
                response.user_ids.length !== Math.min(perPage, Math.max(0, total - (page - 1) * perPage))) {
                throw new Error('فهرست کاربران تغییر کرده است؛ دوباره خروجی بگیرید.');
            }
            const lines = response.rows.map(function(row, index) {
                const id = response.user_ids[index];
                if (!Number.isSafeInteger(id) || id < 1 || state.seen.has(id) || !Array.isArray(row) || row.length !== 2 || row.some(value => typeof value !== 'string')) {
                    throw new Error('ردیف تکراری یا نامعتبر در خروجی دریافت شد.');
                }
                state.seen.add(id);
                return row.map(kerpUserExportCell).join(',') + '\r\n';
            });
            state.chunks.push(lines.join(''));
            const percent = total ? Math.floor(state.seen.size / total * 100) : 100;
            $root.find('.progress-bar').css('width', percent + '%').attr('aria-valuenow', percent);
            $root.find('.kerp-user-export-label').text(percent.toLocaleString('fa-IR') + '٪ · ' + state.seen.size.toLocaleString('fa-IR') + ' از ' + total.toLocaleString('fa-IR'));
            if (page >= pages) break;
        }
        if (!current()) return;
        state.url = URL.createObjectURL(new Blob(state.chunks, {type: 'text/csv;charset=utf-8;'}));
        state.chunks = [];
        state.seen.clear();
        const moveFocus = $root[0].contains(document.activeElement);
        $root.find('[data-bs-toggle="tooltip"]').tooltip('dispose');
        $root.attr('aria-busy', 'false');
        $root.find('.kerp-user-export-progress').prop('hidden', true).addClass('d-none');
        $root.find('.kerp-user-export-status').text('فایل CSV آماده دانلود است.');
        const $download = $root.find('.kerp-user-export-download').attr({href: state.url, download: $root.attr('data-export-filename')}).prop('hidden', false).removeClass('d-none');
        kerpUserExportTooltips(root);
        if (moveFocus) $download.trigger('focus');
    } catch (error) {
        if (!current() && kerpUserExportStates.has(root)) return;
        const cancelled = error?.statusText === 'abort' || !root.isConnected;
        kerpUserExportReset(root);
        if (!cancelled) NioApp.Toast(error.message || error.responseJSON?.message || 'ارتباط با سرور برقرار نشد؛ دوباره تلاش کنید.', 'danger', {position: 'top-right'});
    }
}

$(document).on('click', '.kerp-user-export-start', function() {
    kerpUserExportRun($(this).closest('.kerp-user-export')[0]);
});
$(document).on('click', '.kerp-user-export-cancel', function() {
    const root = $(this).closest('.kerp-user-export')[0];
    kerpUserExportReset(root);
    $(root).find('.kerp-user-export-status').text('دریافت خروجی لغو شد.');
    $(root).find('.kerp-user-export-start').trigger('focus');
});
// AJAX page replacement, filters and navigation must not leave requests or Blob URLs behind.
const kerpUserExportObserver = new MutationObserver(function() {
    kerpUserExportStates.forEach(function(state, root) {
        if (!root.isConnected) kerpUserExportReset(root);
    });
});
kerpUserExportObserver.observe(document.documentElement, {childList: true, subtree: true});
$(window).on('pagehide', function() {
    kerpUserExportStates.forEach(function(state, root) { kerpUserExportReset(root); });
});



/* ===== wallet.js ===== */
/* ===== wallet ERP ===== */
(function() {
    function walletToast(message, type) {
        NioApp.Toast(message, type || 'error', {position: 'top-right'});
    }
    
    function walletAmount(value) {
        value = String(value || '').trim().replace(/[۰-۹]/g, function(n) {
            return '۰۱۲۳۴۵۶۷۸۹'.indexOf(n);
        }).replace(/[٠-٩]/g, function(n) {
            return '٠١٢٣٤٥٦٧٨٩'.indexOf(n);
        }).replace(/٬/g, ',').replace(/٫/g, '.');
        return /^(?:[0-9]+|[0-9]{1,3}(?:,[0-9]{3})+)(?:\.[0-9]+)?$/.test(value)
               ? Number(value.replace(/,/g, ''))
               : NaN;
    }
    
    function walletResponse(response) {
        response = response || {};
        change_panel_html(response);
    }
    
    function walletRepeaterRows($form, id, name, keys) {
        const rows = [];
        $form.find('#' + id + ' .repeater_row').each(function() {
            const $row = $(this),
                  row  = {};
            keys.forEach(function(key) {
                const $field = $row.find('[name^="' + name + '["][name$="[' + key + ']"]').first();
                row[key] = $field.is(':checkbox') ? ($field.is(':checked') ? '1' : '0') : String($field.val() || '').
                    trim();
            });
            if (keys.some(function(key) { return key !== 'required' && row[key] !== ''; })) {
                rows.push(row);
            }
        });
        return rows;
    }
    
    $(document).on('click', '.kerp-wallet-repair-product', function() {
        const $button = $(this);
        if ($button.prop('disabled')) {
            return;
        }
        $button.prop('disabled', true);
        $.post(ajax_url, {
            action:       'wallet_repair_product',
            wallet_nonce: $button.attr('data-nonce'),
        }).done(walletResponse).fail(function() {
            walletToast('ارتباط با سرور برقرار نشد؛ دوباره تلاش کنید.');
        }).always(function() {
            $button.prop('disabled', false);
        });
    });
    
    $(document).on('click', '.kerp-wallet-add-preset', function() {
        const $rows = $(this).closest('form').find('.kerp-wallet-preset-rows');
        if ($rows.children().length >= 20) {
            walletToast('حداکثر ۲۰ مبلغ پیشنهادی قابل ثبت است.');
            return;
        }
        const $row = $('<div>', {'class': 'row g-2 mb-3 kerp-wallet-preset-row'});
        $('<div>', {'class': 'col'}).append($('<input>', {
            type:         'text',
            'class':      'form-control price_input',
            name:         'presets[]',
            inputmode:    'numeric',
            'aria-label': 'مبلغ پیشنهادی شارژ',
        })).appendTo($row);
        $('<div>', {'class': 'col-auto'}).append($('<button>', {
            type:         'button',
            'class':      'btn btn-outline-danger btn-icon kerp-wallet-remove-preset',
            'aria-label': 'حذف مبلغ پیشنهادی',
        }).append('<em class="icon ni ni-trash"></em>')).appendTo($row);
        $rows.append($row);
        $row.find('input').trigger('focus');
    });
    
    $(document).on('click', '.kerp-wallet-remove-preset', function() {
        $(this).closest('.kerp-wallet-preset-row').remove();
    });
    
    $(document).on('submit', '.kerp-wallet-settings-form', function(event) {
        event.preventDefault();
        const $form   = $(this),
              $button = $form.find('[type="submit"]');
        if ($form.data('submitting')) {
            return;
        }
        const section = String($form.attr('data-section') || '');
        const formData = new FormData(this);
        formData.set('action', 'wallet_save_settings');
        formData.set('nonce', $form.attr('data-nonce'));
        $form.find('.quill-basic[data-for]').each(function() {
            const $editor  = $(this),
                  instance = this.__quill || $editor.data('quill');
            formData.set(
                $editor.attr('data-for'),
                instance && instance.root ? instance.root.innerHTML : ($editor.find('.quill-value').val() || ''),
            );
        });
        const settingsPayload = {section: section};
        if (section === 'limits') {
            const minimum = walletAmount($form.find('[name="minimum"]').val());
            const percentage = walletAmount($form.find('[name="payment_max_percentage"]').val());
            const maxRaw = String($form.find('[name="payment_max_amount"]').val() || '').trim();
            const maxAmount = maxRaw === '' ? 0 : walletAmount(maxRaw);
            if (!Number.isFinite(percentage) || percentage <= 0 || percentage > 100) {
                walletToast('حداکثر درصد پرداخت با کیف پول باید بین ۱ تا ۱۰۰ باشد.');
                return;
                
            }
            if (!Number.isFinite(maxAmount) || maxAmount < 0) {
                walletToast('حداکثر مبلغ پرداخت با کیف پول را درست وارد کنید؛ برای نامحدود بودن صفر بگذارید.');
                return;
            }
            const invalidPreset = $form.find('[name="presets[]"]').toArray().some(function(input) {
                const value  = String(input.value || '').trim(),
                      amount = walletAmount(value);
                return value !== '' && (!Number.isFinite(amount) || amount < minimum);
            });
            if (invalidPreset) {
                walletToast('مبالغ پیشنهادی باید در محدوده حداقل و حداکثر شارژ باشند.');
                return;
            }
            Object.assign(settingsPayload, {
                enabled:                $form.find('[name="enabled"]').is(':checked') ? '1' : '0',
                minimum:                String($form.find('[name="minimum"]').val() || ''),
                maximum:                String($form.find('[name="maximum"]').val() || ''),
                presets:                $form.find('[name="presets[]"]').map(function() { return this.value; }).get(),
                payment_max_percentage: String($form.find('[name="payment_max_percentage"]').val() || ''),
                payment_max_amount:     String($form.find('[name="payment_max_amount"]').val() || ''),
            });
        } else if (section === 'withdrawal') {
            Object.assign(settingsPayload, {
                withdrawal_enabled:         $form.find('[name="withdrawal_enabled"]').is(':checked') ? '1' : '0',
                withdrawal_minimum_balance: String($form.find('[name="withdrawal_minimum_balance"]').val() || ''),
                withdrawal_debit_timing:    String($form.find('[name="withdrawal_debit_timing"]').val() || ''),
                withdrawal_terms:           String(formData.get('withdrawal_terms') || ''),
                withdrawal_fields:          walletRepeaterRows($form, 'kerp-wallet-withdrawal-fields',
                    'withdrawal_fields', ['key', 'label', 'type', 'required']),
            });
        } else if (section === 'sms') {
            settingsPayload.sms_rules = walletRepeaterRows($form, 'kerp-wallet-sms-rules', 'sms_rules',
                ['event', 'recipient', 'receptor', 'pattern', 'variables']);
        } else {
            walletToast('بخش تنظیمات کیف پول معتبر نیست.');
            return;
        }
        formData.set('settings_payload', JSON.stringify(settingsPayload));
        $form.data('submitting', true);
        $button.prop('disabled', true);
        $.ajax({
            url:         ajax_url,
            method:      'POST',
            dataType:    'json',
            data:        formData,
            processData: false,
            contentType: false,
        }).done(walletResponse).fail(function() {
            walletToast('ذخیره تنظیمات انجام نشد؛ دوباره تلاش کنید.');
        }).always(function() {
            $form.removeData('submitting');
            $button.prop('disabled', false);
        });
    });
    
    $(document).on('submit', '.kerp-wallet-withdrawal-admin-form', function(event) {
        event.preventDefault();
        const form    = this,
              $form   = $(form),
              $button = $form.find('[type="submit"]');
        if ($form.data('submitting')) {
            return;
        }
        const data = new FormData(form);
        data.set('action', 'kerp_wallet_update_withdrawal');
        data.set('receipt_url', String($form.find('[data-for="receipt"]').val() || ''));
        $form.data('submitting', true);
        $button.prop('disabled', true);
        $.ajax({
            url:         ajax_url,
            method:      'POST',
            dataType:    'json',
            data:        data,
            processData: false,
            contentType: false,
        }).done(function(response) {
            if (response.status === 'success') {
                change_panel_html(response);
            } else {
                walletToast(response.message || response.msg || 'ذخیره اطلاعات درخواست انجام نشد.');
            }
        }).fail(function() {
            walletToast('ارتباط با سرور برقرار نشد.');
        }).always(function() {
            $form.removeData('submitting');
            $button.prop('disabled', false);
        });
    });
    
    $(document).on('click', '.kerp-wallet-payment-details', function() {
        const data   = $(this).data('details') || {},
              $modal = $('#kerpWalletPaymentDetailsModal');
        $modal.find('[data-wallet-detail="status"]').text(data.status || '—');
        $modal.find('[data-wallet-detail="bank"]').text(data.bank || '—');
        $modal.find('[data-wallet-detail="reference"]').text(data.reference || '—');
        $modal.find('[data-wallet-detail="paid_at"]').text(data.paid_at || '—');
        $modal.find('[data-wallet-detail="note"]').text(data.note || '—');
        const $receipt = $modal.find('[data-wallet-detail="receipt"]');
        data.receipt
        ? $receipt.attr('href', data.receipt).closest('.kerp-wallet-payment-receipt').show()
        : $receipt.removeAttr('href').closest('.kerp-wallet-payment-receipt').hide();
        $modal.addClass('is-active').attr('aria-hidden', 'false');
    });
    
    $(document).on('click', '.kerp-wallet-payment-modal__close, #kerpWalletPaymentDetailsModal', function(event) {
        if (event.target !== this && !$(event.target).closest('.kerp-wallet-payment-modal__close').length) {
            return;
        }
        $('#kerpWalletPaymentDetailsModal').removeClass('is-active').attr('aria-hidden', 'true');
    });
}());




/* =======================
   KASEBI  BUILD END
   ======================= */

}(NioApp, jQuery);
