<?php
defined( 'ABSPATH' ) || exit;
final class KERP_Modules_Gold_Admin {
    public static string $return_url = '';
    public static function start_form( string $operation ): void {
        echo '<form class="kg-post-form" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
        wp_nonce_field( 'kerp_gold' );
        if ( $operation !== 'request' ) { echo '<input type="hidden" name="return_url" value="' . esc_url( self::$return_url ?: KERP_Modules_Gold_Ui::url() ) . '">'; }
        echo '<input type="hidden" name="action" value="kerp_gold"><input type="hidden" name="operation" value="' . esc_attr( $operation ) . '">';
    }
    public static function field( string $name, string $label, $value = '', string $type = 'text', bool $required = false ): void {
        $id = wp_unique_id( 'kg-input-' );
        echo '<div class="form-group kg-field"><label class="form-label" for="' . esc_attr( $id ) . '">' . esc_html( $label ) . '</label><input class="form-control" id="' . esc_attr( $id ) . '" type="' . esc_attr( $type ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '" ' . ( $required ? 'required' : '' ) . '></div>';
    }
    public static function submit( string $label, string $type = 'primary', string $name = 'submit', bool $wrap = true ): void {
        if ( $wrap ) { echo '<div class="mt-3">'; } echo '<button type="submit" name="' . esc_attr( $name ) . '" class="btn ' . ( $type === 'primary' ? 'btn-primary' : 'btn-white btn-outline-light' ) . '">' . esc_html( $label ) . '</button>'; if ( $wrap ) { echo '</div>'; }
    }
    public static function messages(): void {
        foreach ( [ 'error', 'success' ] as $kind ) { $key = 'kerp_gold_' . $kind . '_' . get_current_user_id(); $message = get_transient( $key );
            if ( $message ) { $classes = is_admin() ? 'notice notice-' . $kind : 'alert alert-' . ( $kind === 'error' ? 'danger' : 'success' ) . ' alert-icon'; echo '<div role="status" class="' . esc_attr( $classes ) . '">' . ( is_admin() ? '' : KERP_Modules_Gold_Ui::icon( $kind === 'error' ? 'alert-circle' : 'check-circle' ) ) . '<span>' . esc_html( $message ) . '</span></div>'; delete_transient( $key ); }
        }
    }
    public static function render(): void { KERP_Modules_Gold_Ui::render(); }
    public static function save_settings(): void {
        $old = KERP_Modules_Gold_Module::settings();
        $s = $old;
        foreach ( [ 'cash', 'physical', 'jewelry' ] as $kind ) { $s[ 'allow_' . $kind ] = KERP_Modules_Gold_Module::input( 'allow_' . $kind ) === '1' ? 1 : 0; }
        $s['physical_min'] = KERP_Modules_Gold_Math::grams( KERP_Modules_Gold_Math::units( KERP_Modules_Gold_Module::input( 'physical_min' ) ) );
        foreach ( [ 'rate' ] as $key ) {
            $raw = KERP_Modules_Gold_Module::input( $key );
            if ( ! preg_match( '/^\d{1,14}(?:\.\d{1,6})?$/D', $raw ) ) { throw new InvalidArgumentException( 'نرخ پایه باید عدد نامنفی با ممیز نقطه باشد.' ); }
            $s[ $key ] = $raw;
        }
        $premium = KERP_Modules_Gold_Module::input( 'premium' );
        if ( ! preg_match( '/^[+-]?\d{1,6}(?:\.\d{1,6})?$/D', $premium ) || abs( (float) $premium ) > 200000 ) { throw new InvalidArgumentException( 'اختلاف نرخ باید از منفی ۲۰۰۰۰۰ تا مثبت ۲۰۰۰۰۰ باشد.' ); }
        $s['premium'] = $premium;
        $basis = KERP_Modules_Gold_Module::input( 'quote_basis' );
        if ( ! in_array( $basis, [ 'gram', 'mesghal' ], true ) ) { throw new InvalidArgumentException( 'مبنای نرخ نامعتبر است.' ); }
        $factor = KERP_Modules_Gold_Module::input( 'mesghal_factor' );
        KERP_Modules_Gold_Math::units( $factor );
        $s['quote_basis'] = $basis; $s['mesghal_factor'] = $factor;
        foreach ( [ 'max_age' => [30,86400], 'plus_days' => [1,3650], 'plus_product' => [0,PHP_INT_MAX] ] as $key => $bounds ) {
            $raw = KERP_Modules_Gold_Module::input( $key );
            if ( ! ctype_digit( $raw ) || (float) $raw < $bounds[0] || (float) $raw > $bounds[1] ) { throw new InvalidArgumentException( 'محدوده زمان یا شناسه محصول نامعتبر است.' ); }
            $s[ $key ] = (int) $raw;
        }
        if ( $s['plus_product'] ) {
            $product = wc_get_product( $s['plus_product'] );
            if ( ! $product || ! $product->is_type( 'simple' ) || ! $product->is_virtual() ) { throw new InvalidArgumentException( 'محصول اشتراک باید ساده و مجازی باشد.' ); }
        }
        $s['landing'] = KERP_Modules_Gold_Module::input( 'landing' );
        foreach ( KERP_Modules_Gold_Module::links() as $key => $label ) {
            $raw = KERP_Modules_Gold_Module::input( 'link_' . $key );
            $url = esc_url_raw( $raw, [ 'http', 'https' ] );
            if ( $raw !== '' && ( ! $url || ! filter_var( $url, FILTER_VALIDATE_URL ) ) ) { throw new InvalidArgumentException( 'نشانی خدمات باید کامل و معتبر باشد.' ); }
            $s[ 'link_' . $key ] = $url;
        }
        if ( $old['rate'] !== $s['rate'] || KERP_Modules_Gold_Module::input( 'refresh_rate' ) === '1' ) { $s['rate_at'] = time(); }
        update_option( 'kerp_gold_settings', $s, false );
    }

    public static function label( string $value ): string {
        return [ 'buy' => 'خرید', 'cash' => 'تسویه نقدی', 'physical' => 'تحویل فیزیکی', 'jewelry' => 'مصرف زیورآلات', 'pending' => 'در انتظار بررسی', 'completed' => 'انجام شد', 'rejected' => 'رد شد', 'review' => 'نیازمند بررسی', 'review_bought' => 'خرید شده؛ نیازمند بررسی', 'local' => 'داخلی', 'queued' => 'در صف ارسال', 'sending' => 'در حال ارسال', 'sent' => 'ارسال شد', 'failed' => 'ارسال ناموفق', 'wallet_adjusted' => 'تغییر موجودی طلایی', 'request_pending' => 'درخواست جدید', 'request_completed' => 'درخواست انجام شد', 'request_rejected' => 'درخواست رد شد', 'replacement_pending' => 'خرید جایگزین لازم است', 'replacement_completed' => 'خرید جایگزین انجام شد', 'replacement_review' => 'خرید جایگزین نیازمند بررسی', 'plus_activated' => 'اشتراک پلاس فعال شد', 'paid_error' => 'خطای عملیات سفارش', 'business_posted' => 'سند بنکداری ثبت شد', 'offline_sale' => 'فروش حضوری یا سوشال ثبت شد', 'inventory_status' => 'وضعیت کالا تغییر کرد', 'packaging_pending' => 'سفارش در صف بسته‌بندی', 'packaging_packing' => 'شروع بسته‌بندی', 'packaging_packed' => 'بسته‌بندی انجام شد', 'packaging_shipped' => 'مرسوله ارسال شد', 'packaging_error' => 'خطای بسته‌بندی', 'packaging_review' => 'بسته‌بندی نیازمند بررسی' ][$value] ?? $value;
    }

}
