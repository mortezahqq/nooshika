<?php
defined( 'ABSPATH' ) || exit;
$u = KERP_Modules_Gold_Ui::class;
$tables = [ 'requests' => 'requests', 'replacement' => 'replacement', 'packaging' => 'packaging', 'ledger' => 'ledger', 'events' => 'events' ];
$statuses = [ 'requests' => [ 'pending' => 'در انتظار بررسی', 'completed' => 'انجام‌شده', 'rejected' => 'ردشده' ], 'replacement' => [ 'pending' => 'در انتظار خرید', 'completed' => 'خرید انجام‌شده', 'review' => 'نیازمند بررسی', 'review_bought' => 'خریدشده؛ نیازمند بررسی' ], 'packaging' => [ 'pending' => 'در انتظار', 'packing' => 'در حال بسته‌بندی', 'packed' => 'بسته‌بندی شد', 'shipped' => 'ارسال شد', 'error' => 'خطا', 'review' => 'نیازمند بررسی' ], 'ledger' => [], 'events' => [ 'local' => 'ثبت داخلی', 'queued' => 'در صف ارسال', 'sending' => 'در حال ارسال', 'sent' => 'ارسال‌شده', 'failed' => 'ناموفق' ] ];
$data = $u::query( $tables[ $section ] ); $rows = []; $modals = [];
$labels = [ 'requests' => [ 'شماره', 'کاربر', 'درخواست', 'وزن', 'وضعیت', 'تاریخ', 'عملیات' ], 'replacement' => [ 'سفارش', 'وزن موردنیاز', 'وضعیت', 'شماره معامله', 'تاریخ', 'عملیات' ], 'packaging' => [ 'سفارش', 'وضعیت', 'کد پیگیری', 'آخرین تغییر', 'عملیات' ], 'ledger' => [ 'شماره', 'کاربر', 'تغییر موجودی', 'موجودی پس از ثبت', 'شرح', 'تاریخ' ], 'events' => [ 'رویداد', 'پیگیری', 'ارسال', 'تعداد تلاش', 'زمان', 'عملیات' ] ];
if ( $section === 'requests' ) { $u::note( 'تأیید خرید یعنی وجه را دریافت و بررسی کرده‌اید. رد برداشت، وزن رزروشده را به موجودی آزاد کاربر برمی‌گرداند.' ); }
if ( $section === 'events' && ! KERP_Modules_Gold_Notifications::configured() ) { $u::note( 'رویدادها در این صفحه ثبت می‌شوند. برای ارسال به تلگرام یا بله، اتصال ربات هنوز تنظیم نشده است.' ); }
$u::card( $u::sections()[ $section ]['title'], number_format_i18n( $data['total'] ) . ' مورد ثبت‌شده' ); $u::table_filter( $statuses[ $section ] );
foreach ( $data['rows'] as $row ) {
    $action = '<span class="text-soft">—</span>'; $id = (int) ( $row->id ?? $row->order_id );
    if ( $section === 'requests' && $row->status === 'pending' ) {
        ob_start(); $u::action( 'kg-request-' . $id, 'بررسی', 'eye' ); $action = ob_get_clean();
        $modals[] = function () use ( $u, $row, $id ) { $u::modal( 'kg-request-' . $id, 'بررسی درخواست #' . $id, function () use ( $u, $row, $id ) {
            echo '<div class="kg-review-summary"><span>' . esc_html( $u::user( (int) $row->user_id ) ) . '</span><strong><bdi>' . esc_html( $u::weight( (int) $row->units ) ) . '</bdi> گرم</strong><span>' . esc_html( KERP_Modules_Gold_Admin::label( $row->kind ) ) . '</span></div><p class="text-soft kg-preserve">' . esc_html( $row->note ) . '</p>';
            $u::open_form( 'resolve' ); $u::hidden( 'id', $id ); echo '<div class="row g-3">'; $u::select( 'status', 'نتیجه بررسی', [ 'completed' => 'انجام شد', 'rejected' => 'رد شد' ], 'completed', 'col-12' );
            $u::field( 'reference', 'شماره سند و توضیح نتیجه', '', 'textarea', true, $row->kind === 'buy' ? 'مبلغ دریافت‌شده و نرخ توافقی خرید را هم بنویسید.' : 'شماره رسید تسویه، تحویل یا دلیل رد درخواست را بنویسید.', 'col-12' ); echo '</div>'; $u::confirm( 'سند و نتیجه عملیات را بررسی کرده‌ام.' ); $u::form_footer( 'ثبت نتیجه بررسی' );
        }, 'ثبت نتیجه، روی موجودی طلایی کاربر اثر می‌گذارد.' ); };
    }
    if ( $section === 'replacement' && $row->status === 'pending' ) {
        ob_start(); $u::action( 'kg-replacement-' . $id, 'ثبت خرید', 'check' ); $action = ob_get_clean();
        $modals[] = function () use ( $u, $row, $id ) { $u::modal( 'kg-replacement-' . $id, 'ثبت خرید جایگزین', function () use ( $u, $row, $id ) {
            echo '<div class="kg-review-summary"><span>سفارش #' . (int) $row->order_id . '</span><strong><bdi>' . esc_html( $u::weight( (int) $row->units ) ) . '</bdi> گرم</strong><span>معادل عیار ۷۵۰</span></div>';
            $u::note( 'خرید واقعی را ابتدا از فروشنده انجام دهید؛ این فرم فقط نتیجه آن را ثبت می‌کند.' ); $u::open_form( 'replacement' ); $u::hidden( 'id', $id ); echo '<div class="row g-3">'; $u::field( 'reference', 'شماره معامله فروشنده', '', 'text', true, '', 'col-12' ); echo '</div>'; $u::confirm( 'خرید انجام شده و شماره معامله را بررسی کرده‌ام.' ); $u::form_footer( 'ثبت خرید انجام‌شده' );
        } ); };
    }
    if ( $section === 'packaging' && in_array( $row->status, [ 'pending', 'packing', 'packed', 'error' ], true ) ) {
        ob_start(); $u::action( 'kg-pack-' . $id, 'ثبت مرحله', 'package' ); $action = ob_get_clean();
        $modals[] = function () use ( $u, $row, $id ) { $u::modal( 'kg-pack-' . $id, 'بسته‌بندی سفارش #' . $id, function () use ( $u, $row, $id ) {
            $options = [ 'pending' => [ 'packing' => 'شروع بسته‌بندی', 'error' => 'ثبت خطا' ], 'packing' => [ 'packed' => 'بسته‌بندی انجام شد', 'error' => 'ثبت خطا' ], 'packed' => [ 'shipped' => 'مرسوله ارسال شد', 'error' => 'ثبت خطا' ], 'error' => [ 'packing' => 'شروع دوباره بسته‌بندی' ] ];
            $u::open_form( 'packaging_status' ); $u::hidden( 'order_id', $id ); $u::hidden( 'version', $row->version ); echo '<div class="row g-3">'; $u::select( 'status', 'مرحله بعدی', $options[ $row->status ], '', 'col-12' ); $u::field( 'note', 'توضیحات یا کد مرسوله', '', 'textarea', false, '', 'col-12' ); echo '</div>'; $u::form_footer( 'ثبت مرحله' );
        }, 'مرحله فعلی: ' . ( $statuses['packaging'][ $row->status ] ?? $row->status ) ); };
    }
    if ( $section === 'events' && $row->delivery !== 'sent' && (int) $row->attempts < 5 && KERP_Modules_Gold_Notifications::configured() ) {
        ob_start(); $u::open_form( 'retry_event' ); $u::hidden( 'id', $id ); echo '<button type="submit" class="btn btn-sm btn-white btn-outline-light">' . $u::icon( 'reload' ) . '<span>ارسال دوباره</span></button></form>'; $action = ob_get_clean();
    }
    $when = $u::date( (string) ( $row->created_at ?? $row->updated_at ?? '' ) );
    if ( $section === 'requests' ) { $rows[] = [ '#' . $id, $u::html( '<strong>' . esc_html( $u::user( (int) $row->user_id ) ) . '</strong><span class="sub-text">' . esc_html( wp_html_excerpt( $row->note, 70, '…' ) ) . '</span>' ), KERP_Modules_Gold_Admin::label( $row->kind ), $u::html( '<strong><bdi>' . esc_html( $u::weight( (int) $row->units ) ) . '</bdi></strong><span class="sub-text">گرم ۷۵۰</span>' ), $u::html( $u::badge( $row->status ) ), $u::html( '<bdi>' . esc_html( $when ) . '</bdi>' ), $u::html( $action ) ]; }
    elseif ( $section === 'replacement' ) { $rows[] = [ '#' . $row->order_id, $u::html( '<strong><bdi>' . esc_html( $u::weight( (int) $row->units ) ) . '</bdi></strong><span class="sub-text">گرم ۷۵۰</span>' ), $u::html( $u::badge( $row->status ) ), $row->reference ?: '—', $u::html( '<bdi>' . esc_html( $when ) . '</bdi>' ), $u::html( $action ) ]; }
    elseif ( $section === 'packaging' ) { $rows[] = [ '#' . $row->order_id, $u::html( $u::badge( $row->status ) ), $row->note ?: '—', $u::html( '<bdi>' . esc_html( $when ) . '</bdi>' ), $u::html( $action ) ]; }
    elseif ( $section === 'ledger' ) { $rows[] = [ '#' . $id, $u::user( (int) $row->user_id ), $u::html( '<strong class="text-' . ( $row->delta > 0 ? 'success' : 'danger' ) . '"><bdi>' . ( $row->delta > 0 ? '+' : '' ) . esc_html( $u::weight( (int) $row->delta ) ) . '</bdi></strong><span class="sub-text">گرم</span>' ), $u::html( '<bdi>' . esc_html( $u::weight( (int) $row->balance ) ) . '</bdi> گرم' ), $u::html( '<details class="kg-row-note"><summary>' . esc_html( wp_html_excerpt( $row->note, 55, '…' ) ) . '</summary><p>' . esc_html( $row->note ) . '</p><small>ثبت‌کننده: ' . esc_html( $u::user( (int) $row->actor_id ) ) . '</small></details>' ), $u::html( '<bdi>' . esc_html( $when ) . '</bdi>' ) ]; }
    else { $rows[] = [ $u::html( '<strong>' . esc_html( KERP_Modules_Gold_Admin::label( $row->event ) ) . '</strong><code dir="ltr" class="sub-text">' . esc_html( $row->hashtag ) . '</code>' ), $row->reference, $u::html( $u::badge( $row->delivery ) ), number_format_i18n( $row->attempts ), $u::html( '<bdi>' . esc_html( $when ) . '</bdi>' ), $u::html( $action ) ]; }
}
$u::table( $labels[ $section ], $rows, $u::get( 'q' ) || $u::get( 'status' ) ? 'نتیجه‌ای برای این فیلتر پیدا نشد.' : 'صف شما خالی است.', 'موارد جدید در این فهرست نمایش داده می‌شوند.' ); $u::pagination( $data['total'] ); $u::end_card(); foreach ( $modals as $render ) { $render(); }
if ( $section === 'ledger' ) {
    $u::modal( 'gold-create', 'ثبت تراکنش کیف طلایی', function () use ( $u ) { $u::note( 'افزایش موجودی فقط پس از بررسی دریافت وجه یا سند معتبر انجام شود.' ); $u::open_form( 'adjust' ); echo '<div class="row g-3">'; $u::lookup( 'user_id', 'کاربر', 'users', 0, true, 'col-12' ); $u::select( 'direction', 'نوع تراکنش', [ 'credit' => 'افزایش موجودی', 'debit' => 'کاهش موجودی' ], 'credit' ); $u::field( 'grams', 'وزن به گرم ۷۵۰', '', 'text', true, 'تا شش رقم اعشار؛ مثال: 1.250000', 'col-md-6', 'inputmode="decimal" dir="ltr"' ); $u::field( 'note', 'شرح و شماره سند', '', 'textarea', true, '', 'col-12' ); echo '</div>'; $u::confirm( 'سند این تراکنش را بررسی کرده‌ام.' ); $u::form_footer( 'ثبت تراکنش' ); } );
}
if ( $section === 'replacement' ) { echo '<details class="card card-bordered kg-help mt-4"><summary>' . $u::icon( 'help-circle' ) . ' ثبت دوباره عملیات یک سفارش</summary><div class="card-inner">'; $u::note( 'فقط پس از رفع خطای ثبت عملیات و بررسی یادداشت سفارش استفاده کنید. سفارش جدید یا خرید واقعی ایجاد نمی‌شود.' ); $u::open_form( 'retry_order' ); echo '<div class="row g-3 align-items-end">'; $u::field( 'order_id', 'شماره سفارش پرداخت‌شده', '', 'number', true ); echo '<div class="col-md-6"><button class="btn btn-white btn-outline-light" type="submit">بررسی دوباره سفارش</button></div></div></form></div></details>'; }
