<?php
defined( 'ABSPATH' ) || exit;
global $wpdb; $u = KERP_Modules_Gold_Ui::class;
$d = KERP_Modules_Gold_Store::table( 'documents' ); $p = KERP_Modules_Gold_Store::table( 'postings' ); $b = KERP_Modules_Gold_Store::table( 'books' );
$where = '1=1'; $q = $u::get( 'q' ); if ( $q !== '' ) { $s = '%' . $wpdb->esc_like( mb_substr( $q, 0, 100, 'UTF-8' ) ) . '%'; $where .= $wpdb->prepare( ' AND (d.note LIKE %s OR d.reference LIKE %s OR CAST(d.id AS CHAR) LIKE %s)', $s, $s, $s ); }
$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $d d WHERE $where" ); $page = min( max( 1, (int) $u::get( 'gold_page', '1' ) ), max( 1, (int) ceil( $total / 15 ) ) );
$docs = $wpdb->get_results( $wpdb->prepare( "SELECT d.*,correction.id reversed_by FROM $d d LEFT JOIN $d correction ON correction.reverses_id=d.id WHERE $where ORDER BY d.id DESC LIMIT 15 OFFSET %d", ( $page - 1 ) * 15 ) ); $rows = []; $modals = [];
$u::card( 'اسناد انتقال و تبادل', number_format_i18n( $total ) . ' سند ثبت‌شده' ); $u::table_filter();
foreach ( $docs as $doc ) {
    $legs = $wpdb->get_results( $wpdb->prepare( "SELECT p.*,src.label src,dst.label dst FROM $p p JOIN $b src ON src.id=p.from_book JOIN $b dst ON dst.id=p.to_book WHERE p.document_id=%d ORDER BY p.id", $doc->id ) ); $directions = ''; $amounts = '';
    foreach ( $legs as $leg ) { $directions .= '<div class="kg-transfer-path"><span>' . esc_html( $leg->src ) . '</span>' . $u::icon( 'arrow-left' ) . '<span>' . esc_html( $leg->dst ) . '</span></div>'; $amounts .= '<div class="kg-transfer-amount"><bdi>' . esc_html( KERP_Modules_Gold_Business::amount_label( $leg->asset, (int) $leg->amount ) ) . '</bdi></div>'; }
    $action = '<span class="text-soft">—</span>'; if ( ! $doc->reverses_id && ! $doc->reversed_by ) {
        ob_start(); $u::action( 'kg-reverse-' . $doc->id, 'اصلاح سند', 'undo', 'btn-white btn-outline-light' ); $action = ob_get_clean();
        $modals[] = function () use ( $u, $doc ) { $u::modal( 'kg-reverse-' . $doc->id, 'ثبت معکوس سند #' . $doc->id, function () use ( $u, $doc ) {
            $u::note( 'سند اصلی حفظ می‌شود و انتقال معکوس، مانده حساب‌ها را تغییر می‌دهد. موجودی کافی برای اصلاح لازم است.', 'warning' ); $u::open_form( 'reverse_document' ); $u::hidden( 'id', $doc->id ); echo '<div class="row g-3">'; $u::field( 'note', 'دلیل اصلاح', '', 'textarea', true, '', 'col-12' ); echo '</div>'; $u::confirm( 'سند اصلی و اثر اصلاح روی حساب‌ها را بررسی کرده‌ام.' ); $u::form_footer( 'ثبت سند معکوس' );
        } ); };
    }
    $flag = $doc->reverses_id ? '<span class="badge badge-dim bg-info">اصلاحی</span>' : ( $doc->reversed_by ? '<span class="badge badge-dim bg-light">اصلاح‌شده</span>' : '<span class="badge badge-dim bg-success">ثبت‌شده</span>' );
    $rows[] = [ $u::html( '<strong>#' . (int) $doc->id . '</strong><div class="mt-1">' . $flag . '</div>' ), $u::html( $directions ), $u::html( $amounts ), $doc->note, $u::user( (int) $doc->actor_id ), $u::html( '<bdi>' . esc_html( $u::date( $doc->created_at ) ) . '</bdi>' ), $u::html( $action ) ];
}
$u::table( [ 'سند', 'مسیر انتقال', 'مقدار', 'شرح', 'ثبت‌کننده', 'زمان', 'عملیات' ], $rows, 'هنوز سندی ثبت نشده است.', 'حساب‌ها را تعریف کنید و اولین حواله یا تبادل را ثبت کنید.' ); $u::pagination( $total ); $u::end_card(); foreach ( $modals as $render ) { $render(); }
$u::modal( 'gold-create', 'ثبت حواله یا تبادل', function () use ( $u ) {
    $books = KERP_Modules_Gold_Ui_Data::book_options(); if ( count( $books ) < 3 ) { $u::empty( 'حداقل دو حساب لازم است.', 'مبدأ و مقصد انتقال را ابتدا در طرف‌حساب‌ها بسازید.', 'users' ); $u::link( 'books', 'تعریف حساب', 'btn btn-primary', 'plus' ); return; }
    $u::open_form( 'transfer' ); echo '<div class="row g-3">'; $u::select( 'asset', 'نوع عملیات', [ 'gold' => 'حواله طلایی', 'money' => 'حواله وجه', 'exchange' => 'تبادل طلا و وجه' ], 'gold', 'col-12' ); $u::select( 'from_book', 'حساب مبدأ', $books ); $u::select( 'to_book', 'حساب مقصد', $books ); echo '<div class="col-md-6" data-kg-if="asset:gold,exchange"><div class="row">'; $u::field( 'grams', 'وزن به گرم ۷۵۰', '', 'text', true, '', 'col-12', 'inputmode="decimal" dir="ltr"' ); echo '</div></div><div class="col-md-6" data-kg-if="asset:money,exchange"><div class="row">'; $u::field( 'money', 'مبلغ وجه', '', 'text', true, 'واحد پول: ' . html_entity_decode( wp_strip_all_tags( get_woocommerce_currency_symbol() ) ), 'col-12', 'inputmode="decimal" dir="ltr"' ); echo '</div></div>'; $u::field( 'note', 'شرح و شماره رسید', '', 'textarea', true, '', 'col-12' ); echo '</div><div class="form-note mt-3">در تبادل، طلا از مبدأ به مقصد و وجه در جهت عکس ثبت می‌شود. هر دو ردیف یکجا ثبت می‌شوند.</div>'; $u::form_footer( 'ثبت سند' );
} );
