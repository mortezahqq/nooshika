## 0.21.1 — رابط بومی بنکداری

- بازطراحی دوازده صفحه بنکداری داخل پوسته اصلی ERP؛ داشبورد واقعی، فیلتر و صفحه‌بندی، فرم‌های پنجره‌ای و نمایش موبایل.
- جست‌وجوی امن مشتری و محصول و پیش‌نمایش فقط‌خواندنی فروش با قیمت مشتری انتخاب‌شده.
- بازطراحی صفحات پلاس و کیف، تاریخ شمسی گزارش و پشتیبانی حالت تاریک.
- اصلاح بارگذاری دارایی‌ها پس از پاک‌سازی ERP و الزام ووکامرس در بارگذار سبک برای جابه‌جایی صفحات بنکداری.
- استفاده از نام نمایشی وردپرس در نبود تابع نام کاربر سامانه میزبان؛ منطق مالی و نسخه ساختار داده تغییر نکرده‌اند.

# Changelog

## 0.21.0 — 2026-10-15

### Added

- Optional WooCommerce gold wholesale module with integer-microgram 750-fineness wallet, atomic reservations, manual settlement and physical/jewelry request policies.
- Signed per-gram price adjustment within ±200000 store currency, quote expiry, configurable mesghal conversion and request-consistent supplier quote filter.
- Opt-in simple-product gold pricing with fixed/percentage labor, separate Plus labor, pack metadata and immutable order snapshots of physical gold and replacement weight.
- Gold product categories, melt-piece purity conversion, consignment/reservation/return states and audited state changes.
- Counterparty, bank, gateway, cash and inventory account registers; balanced gold/money transfers, atomic exchanges, non-overdraft asset accounts and immutable single-reversal documents.
- Idempotent physical/social WooCommerce sales with customer-specific pricing, aggregated SKU stock checks and native stock reservation.
- Date-range trial balances, current asset holdings, sales indexed by source and Plus status at purchase, and separate wallet/inventory summaries.
- Authenticated packaging queue/status REST API with ordered transitions, version checks, idempotency and a dedicated packaging-only role. Financial margin data is not sent to packaging.
- Expiring Plus membership product, nine-link service hub, RTL wallet/landing shortcodes, ERP administrator page and WordPress management UI.
- Persisted event stream with optional Telegram/Bale transport, bounded retries and configuration-only bot secrets.
- Disabled-module guards on managed gold/Plus purchases and outstanding managed-order payments.

### Scope and validation

- Live supplier trading and live packaging-vendor integration await their API contracts. Gold-wallet purchases/redemptions remain manual requests. Business journal postings are separate from wallet, WooCommerce orders and melt-piece movements; automatic reconciliation is not implemented.
- Gold/Plus commerce requires simple products and classic checkout. Pack components are not auto-decremented; each pack is a separate SKU. The opt-in wage formula is documented and does not guess undeclared commercial rules.
- Local checks use real WordPress/WooCommerce/MariaDB with standard and HPOS order storage, concurrent withdrawals/transfers, permissions, pricing, refunds, packaging API and mocked bot delivery. See `docs/gold-wholesale.md`.

## 0.20.0 — 2026-10-14

### Added

- Added configurable booking start/end dates, enforced for new public appointments while preserving edits to an existing booking.
- Added appointment-list filters for active public-form fields and their stored response metadata.
- Added role and employee default ERP landing-page choices, limited to active permitted routes.
- Added configurable lead-stage action buttons for course access, product orders, follow-ups, transitions, and SMS.
- Added no-answer follow-ups and event-specific SMS, plus conditional SMS variables from registration answers.

### Improved

- Separated public registration field labels from their technical keys and updated the form preview.


## 0.19.0 — 2026-10-13

### Added

- Added a customer search index with background synchronization, a manual batched rebuild, and an independent schema version.
- Added name search, role filtering, per-page selection, mobile rows, and bulk assignment for the employees and eligible-site-users lists.
- Added a separate preview of the current Gravity Forms confirmation for customer entries without following its redirect.
- Added an opt-in shared user CSV export provider and toolbar component; no list enables it by default.

### Improved

- Limited employee and eligible-user search to first and last name, including multi-word matching; prior ID, email, login, phone, display-name, and employee-code search is no longer supported in these lists.
- Kept ERP table-search state and filters across AJAX updates, guarded against stale page responses, and accepted registered page keys in routing.
- Restored a typed Jalali date in the shared date picker and normalized page input without losing its query string.

### Removed

- Removed the bundled Ostore addon form script; its ERP modal submit, migration, and delete controls are no longer handled by this bundle.

## 0.18.0 — 2026-10-12

### Added

- Added an optional, disabled-by-default two-step public pipeline registration form with configurable fields and display, reserved stages, SMS verification, captured UTM data, completion message/redirect, response views, and registration filters.
- Added lead-stage course access actions, bulk course grants, a verified LearnDash completion trigger from Panel, bulk pipeline exit, and a configurable exit SMS pattern.
- Added an optional, disabled-by-default cheque workflow with customer completion and shipping, finance review and collection, per-cheque history, follow-up tasks, configurable stage SMS, and a customer-panel page.
- Added deposit orders with separate advance and balance payment invoices, status and balance tracking, and mixed card/cheque plus cash-in-hand receipt methods.
- Added a shared ERP modal/AJAX adapter for Ostore addon forms and a post-save ticket integration hook.

### Improved

- Rendered ERP monetary values through the Main shared price component across lists, cards, dashboards, modals, customer views and print templates, with live preview helpers for order editing.
- Excluded draft and trashed WooCommerce orders from the ERP order index and related order queries.
- Protected orders with deposits, payment records or installment contracts from conflicting general edits, status changes and refunds.


## 0.17.2 — 2026-10-11

### Added

- Added guarded lead-pipeline join, stage advance and exit services plus integration hooks; exiting preserves history and last stage while cancelling pending stage SMS.
- Added active/exited membership filtering, exit actions in customer journeys, and copyable pipeline/stage identifiers.
- Added an employee wallet tab and shared transaction modal with scope and permission checks.
- Added manual, paged Order Index backfill with progress, resume feedback and server-side validation; retired the old scheduled backfill.

### Improved

- Added an idempotent `exited_at` migration for existing lead memberships; the Leads schema is now 1.2.1, independent of core database version 0.5.2.


## 0.17.0 — 2026-10-08

### Added

- Added an optional, disabled-by-default SMS log module with scoped permissions, searchable/filterable records, redacted request/response details, and controlled deletion. Fixed its capture gate to honor the disabled default and avoid storing OTP/password exchanges.
- Added ERP settings to customize the customer-panel title and icon for module pages while preserving routes and access.
- Added pipeline duplication with stages, configuration, and automation links, without copying customers or history.
- Added per-stage scheduled SMS rules, an independent queue/schema, revision-based cancellation, and outcome history for lead transitions.
- Added cash-payment link SMS settings and a guarded send action for eligible customer orders.
- Added installment-plan SMS configuration by saved step, event, recipient, timing, and copyable template variables.
- Added an authenticated ticket integration service for create/reply and a usage guide.

### Improved

- Preserved lead list and practice-review filters during pagination and form submissions.
- Blocked practice submission when the customer profile is incomplete and refined public ticket conversation/navigation presentation.
- Restored Main's public stylesheet after ERP asset filtering and refreshed mobile/payment/ticket display details.

## 0.16.0 — 2026-10-07

### Added

- Added the modular ERP home dashboard with permission-aware, independently loaded customer, pipeline, order, payment and installment blocks, responsive layouts and isolated loading/error/retry states.
- Added customer acquisition and membership trends, pipeline workload and stage-entry analytics, order revenue/status/bestseller cards, payment review summaries and upcoming installment dues.
- Added resumable dashboard calculations with scoped data caching, checkpoints, concurrency locks and progress feedback; incomplete results are not displayed as final totals.
- Added scoped First Touch and order UTM option filters, product-specific sales filtering, lead entry/owner/date filters and a dedicated pipeline analytics page.
- Added single and bulk lead stage/owner updates with confirmation and history, guarded pipeline/stage deletion, and permission-gated marketing-request deletion with version checks.

### Improved

- Extended Order Index for dashboard totals, products, refunds and cursor-based batches; core database schema is now 0.5.2 and payment schema is 2.
- Clarified attribution labels and original values, shared filter controls and compact order cards.
- Aligned the plugin header and `KERP_VERSION` to the same release number.


## 0.15.0 — 2026-10-06

### Added

- Added the optional, disabled-by-default Tickets module: all-ticket ERP list, customer-profile list and separate conversations, plus customer panel routes.
- Added department/tag, SMS-rule and personal canned-response settings; preserved assignment, message referrals, tag-based scope, priorities, six statuses, pinning, ratings, rich messages and chunked attachments.
- Added resumable, non-destructive legacy migration with unique source identifiers, transactional ticket/message copying, reply-ID mapping and preserved attachment URLs and user preferences. Deleted migrated tickets cannot be resurrected by rerunning migration.
- Enabling Tickets retires the panel-manager routes and legacy ticket writes. The user panel switches to ERP-owned storage; existing legacy tables and files remain intact.
- Added independent pipeline list, detail and settings routes with create/edit modals, stage management, archive/reactivate bulk actions and responsive standard lists.
- Added round-robin lead ownership from active ERP employees, server-validated Gravity Forms/product triggers, asynchronous product search and multi-pipeline customer journeys.
- Added campaign sources and daily source/date metric entries for leads, clicks, forms, cost and sales, with edit-in-place history and calculated KPIs.
- Added payment notes with up to three ownership-checked attachments and a reusable marketing upload flow.

### Improved

- Reworked Marketing pages into compact responsive views with gradient context, status bars and dark-mode support.
- Centralized Jalali conversion and validation in `KERP_Helpers_Date`, including leap-year validation and consistent local datetime display.
- Removed the recursive leap-year validation path so valid leap Esfand dates convert without re-entering the converter.
- Hardened payment-gateway filtering so ERP-selected gateways survive early WooCommerce startup and late plugin filters.
- Extended shared filter, modal, user-card and customer-tab components for dependent values, footer notes, avatars and trusted tab content.

### Database

- Core database version remains `0.5.0`; Tickets uses four independent `kerp_support_*` tables at schema `2`, and Marketing advances from schema `1.0.0` to `1.1.0` for sources and daily metric entries.

### Validation

- Targeted PHP/JavaScript syntax, shared bundle, date round trips, version consistency and Summary checks were run locally. Production MySQL migration, real uploads, notifications and full browser interaction still require deployment verification.

## 0.14.0 — 2026-10-05

### Added

- Added a dedicated Marketing dashboard with status KPIs, a 14-day request trend, status-share bars, approved budget/sales estimates and recent campaign links.
- Added separate ERP routes for all requests, the current user's inbox, marketing review, finance review, request details and each campaign dashboard.
- Added independent `marketing.complete` permission and permission-aware navigation for the marketing and finance queues.

### Changed

- Replaced fixed marketing-manager and finance recipients with ERP permission-based work queues; removed the obsolete recipient settings page and settings AJAX action.
- Split request details from campaign analytics while keeping shared modal forms, list filters, per-page selection, row/bulk actions, standard empty state and conditional pagination.
- Limited installment payment choices to cash when the installment module is unavailable, instead of exposing an unusable installment option.

### Improved

- Expanded responsive Marketing styling and keyboard submission behavior for dashboards, lists, forms and campaign metrics.
- Kept campaign currency on new requests while removing recipient validation that belonged to the retired fixed-assignment workflow.

### Database

- Core database version remains `0.5.0`; the Marketing schema remains `1.0.0` with no schema migration.

## 0.13.0 — 2026-10-04

### Added

- Added the disabled-by-default Marketing Requests module with submitter, marketing-manager and finance stages, configurable recipients and currency, completion and archival.
- Added source-level campaign metrics for leads, clicks, form completions, cost and sales with CTR, conversion, CPL, CAC and ROI calculations and history.
- Added the independent `kerp_marketing_requests` schema at version `1.0.0`, UUID idempotency, optimistic version checks and scoped permissions.
- Added draft proformas that preserve the order without payment side effects and can later start a server-authoritative cash or installment flow.
- Added a distinct installment parent sales order, child payment orders, the `await-install` status, parent balance/progress and a customer-facing installment schedule.
- Added automatic follow-up records for future installments, completion on payment and cancellation on failed contracts.
- Added order payment popups, receipt cards, image preview, copied payment links, rejected-payment retry and conditional pagination.
- Added First Touch and UTM summaries plus filters for source, UTM values, destination/referrer and dependent Gravity/product choices.
- Added mobile-safe header customer search with explicit open/close/focus handling, Enter/submit, loading, empty/error states, request cancellation and late-response protection.

### Improved

- Reworked order creation into payment or proforma modes and a checkout-style form with a sticky authoritative summary.
- Reworked installments so product selection accepts any valid WooCommerce product, general and stage tabs save independently, and validation errors activate the affected tab.
- Preserved exact parent totals, taxes and rounding while splitting installment payment orders and prevented child payment orders from appearing in the main order index.
- Synchronized parent installment status, LearnDash access, stage tags and follow-ups after payment, refund, cancellation and retry events.
- Converted payment records and mobile ERP order lists to compact cards while preserving selection, filters, bulk actions, row actions and desktop order tables.
- Unified the customer-profile order card across desktop and mobile with source, total, item count, installment balance and payment actions.
- Added shared receipt details and method-specific identities to payment review; reorganized payment settings into method tabs and field repeaters.
- Added a shared First Touch/UTM detail component with constrained long URLs and legacy-data fallback.
- Improved practice attachment previews and compact review metadata without leaving tooltips or scroll locks behind.

### Fixed

- Prevented generic status, delete and refund actions from corrupting parent installment sales or internal payment orders.
- Prevented customer-club rewards and order counts from double-counting installment parent/child records.
- Redirected internal payment-order edit links to the parent order workspace and kept offline gateways out of installment checkout.
- Kept header-search results inside the mobile viewport and stopped closed or cleared searches from being reopened by pending responses.
- Preserved dependent filter values only while their controlling field remains active and excluded hidden disabled filters from requests.

### Database

- Core database version remains `0.5.0`; Marketing uses its independent schema version `1.0.0` and existing Payments/Installments schemas are unchanged.

## 0.12.0 — 2026-10-03

### Added

- Added an optional, disabled-by-default ERP payments module: cash/installment selection in new orders, product-scoped installment plans and due-date previews, installed gateway payment links, configurable card/cheque/USDT receipt repeaters, scoped payment records and financial review. Added the financial-review and installment-progress order statuses, request deduplication, upload ownership checks, and shared order context for generated installments.
- Added a dedicated `kerp_payments` table at module schema version 1, independent permissions, filtered/paginated payment records, bulk financial review, receipt details, refund synchronization and per-order payment tracking.

### Changed

- Temporarily disabled installment SMS sending and its settings tab, preserving saved rules and delivery history while keeping installment/access synchronization active.
- Added automatic product-linked course selection and course-scoped lesson loading to installment plans, with disabled lesson fields until a course is selected. Added confirmed plan deletion while preserving contract snapshots and preventing plan ID reuse.
- Moved installment plan creation and editing to dedicated ERP pages with grouped general, installment/access/tag, and SMS tabs. The plan list links to each page, and saving validates and stores all tabs together.
- Restricted personal affiliate history to referrer/marketer activity while retaining buyer purchases in the permission-checked customer report.
- Fired the shared wallet-credit event once after a referral commission is confirmed in the wallet ledger, without rolling back a successful settlement when notification delivery fails.

### Fixed

- Preserved coupon-discounted order totals, blocked generic customer/amount/status edits for orders tied to payment documents, and prevented manual installment approval after a payment document exists.
- Preserved referral settings section identifiers across shared form clearing and prevented duplicate referral wallet notifications during reconciliation.

## 0.11.0 — 2026-10-01

### Added

- Added scoped, source-first customer lookup with Persian/Arabic digit normalization, cached user metadata and opt-in stage timing plus slow-query execution plans.
- Added customer impersonation actions to customer rows and profiles, guarded by the existing target-user permission checks.
- Added a shared numeric-input controller for Persian/Arabic digits and dynamic forms while retaining native min, max, step and required validation.
- Added rich program comments with optional customer visibility, author avatar/name/badge metadata and customer-panel conversation rendering.
- Added a profile setting for the program-comment author badge and a direct panel link on the ERP access-denied screen.

### Improved

- Debounced global customer search, cancelled stale requests and added accessible loading and failure states.
- Enforced non-negative numeric results, integer test counts and minutes, ordered study ranges and native time/page inputs while preserving legacy descriptive ranges.
- Hid the public referral field after the first purchase and repeated first-purchase, code-length, coupon-conflict and coupon-validity checks on the server.
- Standardized customer-facing product and program-advisor terminology across affected order, referral, club and planning views.

### Database

- Advanced the independent programs schema to `1.6.0` for comment visibility and content format; the core ERP database version remains `0.5.0`.

## 0.10.0 — 2026-09-29

- Implemented the disabled-by-default installment management module with ERP plan settings, shared record modals and scoped customer contracts.
- Added percentage-based WooCommerce payment orders, manual payment approval, immutable contract snapshots and cumulative LearnDash lesson/topic access.
- Added per-stage ERP tags with append/replace behavior, shared-tag ownership protection and refund reconciliation.
- Added conditional, scheduled per-stage SMS with recipient selection, deduplication, retry backoff and delivery-state summaries.
- Added the independent `kerp_installment_contracts` table; existing tables and integrations are retained.

## 0.9.2 — 2026-09-28

- Added a shared responsive hero for customer-profile tabs and applied it across customer, activity, address, appointment, club, history, notes, follow-up, Gravity Forms, lead journey, assignment, attendance, order, program, referral, request and wallet views.
- Added a dedicated mobile order-card layout with row selection, customer context and the existing view, refund and delete actions while retaining the desktop table.
- Moved order and withdrawal empty states outside their table containers and kept pagination conditional on multiple pages.
- Added inline image previews with zoom for assignment attachments, limited the row preview to three files and exposed remaining files in a modal.
- Improved review-table column classes and removed stale tooltips before modals and image previews open.
- Kept the core database schema unchanged at `0.5.0` because this release contains no schema migration.

## 0.9.1 — 2026-09-27

- Added scoped customer profile history with field/taxonomy snapshots, event filtering, load-more navigation and the `kerp_customer_meta_history` table; advanced the core database schema to `0.5.0`.
- Added an explicit, idempotent and non-destructive batch migration for legacy customer categories, tags and owner assignments.
- Added multi-select customer taxonomies and formatted custom-field columns in the customer list.
- Added employee profile-image upload and camera selection through the shared ERP modal and file helper.
- Added local/remote attachment availability checks for assignment responses and enforced customer scope in review queries.
- Added complete, item-level and bulk paid-order refunds to customer wallets with concurrency protection, WooCommerce refund links and compensation on failure.
- Added permission-aware bulk order status changes and deletion, with prevalidation of every selected order and preserved list return state.
- Redesigned the online-attendance tables into compact responsive rows with combined class/course and attendance details, direct profile/content links, date-first filtering and a single-time state.
- Improved employee-candidate discovery with duplicate-safe role exclusions, scalable meta search and a count-only query path.
- Replaced eager requester option loading with the shared searchable customer/employee selector in request forms.
- Added rich-text practice descriptions, assignment links in the ERP admin bar, scoped review filter options, unavailable-file handling and responsive review columns.
- Corrected next-step assignment SMS so it is emitted only when the current step has just completed and a next step exists.
- Removed the broad administrator recipient from wallet SMS rules; rules now target the customer or explicit custom numbers.
- Moved database upgrades to the public `init` lifecycle, made the ERP dashboard explicitly unrestricted for authenticated ERP users and added nested admin-bar parents.
- Standardized user display names across ERP cards, lists, searches and operational messages.
- Added unrestricted access metadata for the ERP dashboard and parent-aware nested admin-bar entries.

## 0.9.0 — 2026-09-26

- Added immutable First Touch attribution for site registration, landing orders and Gravity Forms, including landing/referrer URLs, redirect targets, UTM values and product/cart context.
- Added `kerp_first_touches` and `kerp_first_touch_items` with an independent `1.0.0` schema and an explicit, idempotent, non-destructive legacy-meta migration in customer settings.
- Added an optional Gravity Forms entries module that maps a designated phone field to an existing or newly created customer and exposes scoped customer entries in ERP.
- Added form filtering, per-page selection, pagination, standard empty state and shared detail modals for customer Gravity Forms entries.
- Registered Gravity Forms AJAX dependencies and a dedicated employee permission; advanced the core ERP database version to `0.4.0` for this installer release.
- Updated the public programs calendar week icon and retained the existing wallet behavior while formatting its module registration consistently.

## 0.8.0 — 2026-09-25

- Moved learning-assignment responses to the `kerp_practice_answers` table and added an explicit, idempotent, non-destructive batch migration from legacy response and SMS-log tables.
- Added staged multi-file learner uploads, discard handling, upload metadata and validated RAR support through the shared file helper.
- Added reviewer identity/time metadata, a detailed metadata viewer and documented filters/actions for review columns, customer content and row icons.
- Added per-practice and global-default SMS patterns for rejected responses and newly unlocked LearnDash steps, including provider-response logs and failure hooks.
- Added a settings permission, post-type switch and dedicated migration/default-SMS settings while preserving existing assignment data.
- Added the post-transaction wallet balance to wallet SMS variables; kept the independent ERP core schema at `0.3.0` and advanced only the assignment schema to `2.0.0`.

## 0.7.0 — 2026-09-24

- Added LearnDash learning assignments for lessons/topics, learner file submissions, customer-profile history and ERP review queues.
- Added individual and bulk approve/reject flows, required rejection comments, reviewer attachments and resubmission tracking.
- Blocked lesson/topic completion until all linked practices are approved and completed LearnDash content automatically after the final approval.
- Split referral settings into general, private and product/variation commission pages while preserving untouched settings on section saves.
- Kept the core database schema version unchanged; assignments use their independent `1.0.0` schema and leads retain `1.1.0`.

## 0.6.1 — 2026-09-24

- Replaced campaign/webinar types with pipelines and editable, pipeline-owned stages, including post-purchase steps.
- Added individual and selected-user branching from a source stage into another pipeline, preserving source membership and existing destination progress, with history in both paths.
- Added pipeline/stage filters, pagination, scoped stage selectors and grouped profile timelines.
- Migrated used legacy shared stages without deleting historical rows; added validation, nonce checks and the ERP-compatible AJAX response format.

## 0.5.4 — 2026-09-23

- Accepted native numeric wallet amounts in addition to localized numeric strings during server-side parsing.
- Removed the duplicate browser-side minimum/maximum comparison and retained the server as the authoritative validator for charge limits.
- Kept the independent ERP database schema version unchanged because this release adds no migration.

## 0.5.3 — 2026-09-22

- Split wallet administration into dedicated limits/charge, withdrawal, SMS, and system-product settings pages under one nested menu.
- Preserved settings from untouched wallet sections when saving an individual page and returned each action to its originating route.
- Kept the independent ERP database schema version unchanged because this release adds no migration.

## 0.5.2 — 2026-09-22

- Added the optional online-class attendance module, available only with Nooshika Panel and LearnDash, with Skyroom API settings and AJAX login-link generation.
- Added LearnDash lesson/topic Skyroom room and start-time fields through the Panel metabox extension hook, attendance logging, and an ERP attendance report.
- Added delayed absence SMS rules with configurable user phone-meta keys and duplicate-send protection.

## 0.5.1 — 2026-09-22

- Added the optional customer-club module with purchase and activity coins, expiring balances, transaction-safe consumption, and customer history.
- Added physical, course, wallet-credit, and personal-coupon rewards with inventory, per-user limits, redemption, and delivery tracking.
- Added customer-panel rewards/history and the CRM customer coin-ledger tab.

## 0.5.0 — 2026-09-21

- Merged the upgraded Programs system: planning dashboard, weekly customer calendar, overview/performance reports, plan comments, scheduled tasks, attached resources and LearnDash content.
- Added previous-week copying, the experimental exam template, subject-topic imports, and the hierarchical term explorer while preserving shared form, modal, filter and table components.
- Routed all merged Programs requests through the ERP/Nooshika custom AJAX endpoints and removed `admin-ajax.php` fallbacks from the Programs UI.
- Added a first-purchase public referral-code field to Nooshika checkout with AJAX apply/remove and refreshed totals.
- Separated public referral codes from discount/private coupon entry, including contextual labels and Persian eligibility errors.
- Added dedicated wallet charge, withdrawal, admin review, and payment-detail modals with keyboard and panel-refresh integration.
- Added withdrawal filters for status, request date, and amount, plus result counts and reset behavior.
- Added Jalali payment date/time input, validated receipt uploads, and complete-payment guards before exposing settlement details.
- Expanded referral and withdrawal regression coverage without changing the independent ERP database schema version.

## 0.4.0 — 2026-09-20

- Added the optional referrals module, requiring WooCommerce, TeraWallet, and the ERP wallet/customers modules.
- Added first-purchase public codes with a configurable referral cap and customer discount or wallet cashback; added private company coupons with separate company/marketer commissions.
- Added ERP reports/settings, marketer permissions, customer profile history, and the customer panel with shareable codes/links.
- Added immutable order attribution, connection-owned reservation locks, receipt-based wallet reconciliation, proportional refunds, and explicit review states for uncertain or insufficient-balance transactions.
- Preserved legacy public codes/links and optional product/variation commission rules without automatically migrating or paying historical referrals.
- Integrated referral validation into Nooshika's direct checkout and coupon preview; discounts now precede its wallet allocation.
- Added standalone referral and Nooshika checkout regression suites. See `docs/referrals.md` for setup and runtime verification.
- Added configurable wallet withdrawal requests with custom fields, minimum balance, debit timing, review states, payment receipt and idempotent debit/refund handling.
- Added wallet SMS rules for credits, withdrawal creation and paid withdrawals.
- Routed customer-panel wallet and referral operations through Nooshika's `/n-ajax` endpoint and ERP operations through the ERP AJAX endpoint.

## 0.3.4 — 2026-09-19

- Fixed the customer creation permission check to use the shared `kerp_can()` action gate.
- Removed the module-local permission fallback so access decisions follow the ERP permission service consistently.

## 0.3.3 — 2026-09-18

- Removed the duplicate ERP version reporter and its independent schedule.
- Delegated ERP version discovery and reporting to the Main plugin's central reporter.

## 0.1.0 — 2026-08-01

- Added the Kasebi ERP bootstrap, prefixed autoloader, installer, and plugin lifecycle.
- Added the module registry, dependency resolver, module loader, and secure admin module settings screen.
- Added a single-organization access model with session hydration, permission versioning, UI gates, and `own/team/all` scopes.
- Added external `/login` authentication redirects without duplicating the Kasebi Platform login flow.
- Added the `/erp` SPA shell with route rewriting and scoped WordPress asset dequeuing.
- Added the HPOS-compatible core Order Index with synchronization, paginated search, and batch reindexing.
