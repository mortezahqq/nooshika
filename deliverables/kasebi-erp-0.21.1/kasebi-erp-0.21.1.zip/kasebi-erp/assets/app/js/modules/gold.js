/* Native ERP addon. Delegated events survive ERP page replacement. */
(() => {
    'use strict';
    const config = window.KerpGoldUI || {};
    const lookups = new WeakMap();
    const previews = new WeakMap();
    let serial = 0;
    const normalize = value => String(value).replace(/[۰-۹٠-٩]/g, c => String('۰۱۲۳۴۵۶۷۸۹'.includes(c) ? '۰۱۲۳۴۵۶۷۸۹'.indexOf(c) : '٠١٢٣٤٥٦٧٨٩'.indexOf(c)));
    const stateFor = field => {
        if (!lookups.has(field)) lookups.set(field, {items: [], index: -1, timer: null, controller: null});
        return lookups.get(field);
    };
    function close(field) {
        const input = field.querySelector('.kg-lookup-input');
        field.querySelector('[role=listbox]').hidden = true;
        input.setAttribute('aria-expanded', 'false');
        input.removeAttribute('aria-activedescendant');
    }
    function choose(field, item) {
        const input = field.querySelector('.kg-lookup-input');
        input.value = item.label;
        input.setCustomValidity('');
        field.querySelector('[data-kg-id]').value = item.id;
        field.querySelector('.kg-lookup-status').textContent = item.meta || 'انتخاب شد';
        close(field);
        field.dispatchEvent(new CustomEvent('kg:selection', {bubbles: true}));
    }
    async function json(url, options = {}) {
        const response = await fetch(url, {...options, credentials: 'same-origin', headers: {'X-WP-Nonce': config.nonce || '', ...options.headers}});
        let data;
        try { data = await response.json(); } catch (_) { throw new Error('پاسخ سرور خوانا نیست؛ دوباره تلاش کنید.'); }
        if (!response.ok) throw new Error(response.status === 401 || response.status === 403 ? 'دسترسی این نشست معتبر نیست؛ صفحه را تازه کنید.' : (data.message || 'دریافت اطلاعات انجام نشد.'));
        return data;
    }
    function search(field) {
        const input = field.querySelector('.kg-lookup-input');
        const state = stateFor(field);
        clearTimeout(state.timer);
        state.controller?.abort();
        field.querySelector('[data-kg-id]').value = field.dataset.empty || '';
        input.setCustomValidity(input.required ? 'از نتایج جستجو یک گزینه انتخاب کنید.' : '');
        close(field);
        const q = normalize(input.value.trim());
        if (q.length < 2 && !/^\d+$/.test(q)) { field.querySelector('.kg-lookup-status').textContent = 'حداقل دو حرف از نام را بنویسید.'; return; }
        state.timer = setTimeout(async () => {
            state.controller = new AbortController();
            field.querySelector('.kg-lookup-status').textContent = 'در حال جستجو…';
            try {
                const url = new URL(config.api + 'lookup', location.href);
                url.searchParams.set('kind', field.dataset.kgLookup);
                url.searchParams.set('q', q);
                const data = await json(url, {signal: state.controller.signal});
                if (!field.isConnected || input.disabled || normalize(input.value.trim()) !== q) return;
                state.items = data.items || []; state.index = -1;
                const list = field.querySelector('[role=listbox]'); list.replaceChildren();
                state.items.forEach((item, index) => {
                    const button = document.createElement('button');
                    button.type = 'button'; button.className = 'kg-lookup-option'; button.setAttribute('role', 'option');
                    button.setAttribute('aria-selected', 'false'); button.tabIndex = -1;
                    button.id = input.id + '-option-' + index; button.dataset.index = index;
                    const title = document.createElement('span'); title.textContent = item.label;
                    const meta = document.createElement('small'); meta.textContent = item.meta || '';
                    button.append(title, meta); list.append(button);
                });
                list.hidden = !state.items.length;
                input.setAttribute('aria-expanded', state.items.length ? 'true' : 'false');
                field.querySelector('.kg-lookup-status').textContent = state.items.length ? state.items.length + ' نتیجه؛ برای انتخاب از کلیدهای جهت استفاده کنید.' : 'نتیجه‌ای پیدا نشد.';
            } catch (error) { if (error.name !== 'AbortError' && field.isConnected) field.querySelector('.kg-lookup-status').textContent = error.message; }
        }, 250);
    }
    function conditionals(form) {
        form.querySelectorAll('[data-kg-if]').forEach(box => {
            const [name, values] = box.dataset.kgIf.split(':');
            const control = form.elements.namedItem(name);
            const visible = !!control && values.split(',').includes(control.value);
            box.hidden = !visible;
            box.querySelectorAll('input,select,textarea,button').forEach(input => {
                if (!('kgOriginalDisabled' in input.dataset)) input.dataset.kgOriginalDisabled = input.disabled ? '1' : '0';
                input.disabled = !visible || input.dataset.kgOriginalDisabled === '1';
            });
        });
    }
    function updateRows(form) {
        const rows = form.querySelectorAll('.kg-sale-row');
        rows.forEach(row => row.querySelector('.kg-remove-line').disabled = rows.length <= 1);
        const add = form.querySelector('[data-kg-add-line]'); if (add) add.disabled = rows.length >= 30;
    }
    function preview(form) {
        const target = form.querySelector('[data-kg-sale-total]'); if (!target) return;
        if (!previews.has(form)) previews.set(form, {timer: null, controller: null});
        const state = previews.get(form); clearTimeout(state.timer); state.controller?.abort();
        const user = Number(form.querySelector('[name=user_id]').value);
        const items = [...form.querySelectorAll('.kg-sale-row')].map(row => ({product_id: Number(row.querySelector('[data-kg-id]').value), quantity: Number(normalize(row.querySelector('[name="quantities[]"]').value))}));
        const note = form.querySelector('[data-kg-sale-note]');
        if (!user || items.some(i => !i.product_id || !Number.isInteger(i.quantity) || i.quantity < 1 || i.quantity > 10000)) { target.textContent = 'مشتری و محصولات را کامل کنید'; note.textContent = 'قیمت بر اساس شرایط همین مشتری محاسبه می‌شود.'; return; }
        state.timer = setTimeout(async () => {
            state.controller = new AbortController(); target.textContent = 'در حال محاسبه…';
            try {
                const data = await json(config.api + 'sale-preview', {method: 'POST', signal: state.controller.signal, headers: {'Content-Type': 'application/json'}, body: JSON.stringify({user_id: user, items})});
                if (!form.isConnected) return;
                target.innerHTML = data.total_html; // Trusted, server-sanitized WooCommerce price markup.
                note.textContent = (data.is_plus ? 'اجرت پلاس مشتری لحاظ شده است. ' : '') + data.note;
            } catch (error) { if (error.name !== 'AbortError' && form.isConnected) { target.textContent = 'برآورد در دسترس نیست'; note.textContent = error.message; } }
        }, 300);
    }
    function init() {
        document.querySelectorAll('.kg-ui,.kg-modal').forEach(root => {
            root.querySelectorAll('form.kg-post-form').forEach(form => {
                if (form.dataset.kgReady) return;
                form.dataset.kgReady = '1'; conditionals(form); updateRows(form);
            });
        });
    }
    document.addEventListener('input', event => {
        const input = event.target.closest('.kg-lookup-input'); if (input) search(input.closest('.kg-lookup'));
        const form = event.target.closest('.kg-post-form'); if (form && (input || event.target.matches('[name="quantities[]"]'))) preview(form);
    });
    document.addEventListener('kg:selection', event => { const form = event.target.closest('.kg-post-form'); if (form) { const row = event.target.closest('.kg-sale-row'); if (row && !row.querySelector('[name="quantities[]"]').value) row.querySelector('[name="quantities[]"]').value = '1'; preview(form); } });
    document.addEventListener('change', event => { const form = event.target.closest('.kg-post-form'); if (form) { conditionals(form); preview(form); } });
    document.addEventListener('keydown', event => {
        const input = event.target.closest('.kg-lookup-input'); if (!input) return;
        const field = input.closest('.kg-lookup'), state = stateFor(field), list = field.querySelector('[role=listbox]');
        if (event.key === 'Escape') { close(field); return; }
        if (list.hidden || !state.items.length) return;
        if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
            event.preventDefault(); state.index = state.index < 0 ? (event.key === 'ArrowDown' ? 0 : state.items.length - 1) : (state.index + (event.key === 'ArrowDown' ? 1 : -1) + state.items.length) % state.items.length;
            list.querySelectorAll('[role=option]').forEach((option, index) => option.setAttribute('aria-selected', index === state.index ? 'true' : 'false'));
            const active = list.children[state.index]; input.setAttribute('aria-activedescendant', active.id); active.scrollIntoView({block: 'nearest'});
        } else if (event.key === 'Enter' && state.index >= 0) { event.preventDefault(); choose(field, state.items[state.index]); }
    });
    document.addEventListener('mousedown', event => { if (event.target.closest('.kg-lookup-option')) event.preventDefault(); });
    document.addEventListener('click', async event => {
        const option = event.target.closest('.kg-lookup-option');
        if (option) { const field = option.closest('.kg-lookup'); choose(field, stateFor(field).items[Number(option.dataset.index)]); field.querySelector('.kg-lookup-input').focus(); return; }
        document.querySelectorAll('.kg-lookup').forEach(field => { if (!field.contains(event.target)) close(field); });
        const add = event.target.closest('[data-kg-add-line]');
        if (add) {
            const form = add.closest('form'), list = form.querySelector('[data-kg-sale-lines]'); if (list.children.length >= 30) return;
            const row = list.firstElementChild.cloneNode(true), ids = new Map();
            row.querySelectorAll('[id]').forEach(node => { const old = node.id; node.id += '-clone-' + (++serial); ids.set(old, node.id); });
            row.querySelectorAll('[for],[aria-controls]').forEach(node => ['for','aria-controls'].forEach(attr => { const value = node.getAttribute(attr); if (ids.has(value)) node.setAttribute(attr, ids.get(value)); }));
            row.querySelector('.kg-lookup-input').value = ''; row.querySelector('.kg-lookup-input').setAttribute('aria-expanded','false'); row.querySelector('.kg-lookup-input').removeAttribute('aria-activedescendant'); row.querySelector('[data-kg-id]').value = ''; row.querySelector('[role=listbox]').replaceChildren(); row.querySelector('[role=listbox]').hidden = true; row.querySelector('.kg-lookup-status').textContent = 'نام محصول را جستجو کنید.'; row.querySelector('[name="quantities[]"]').value = '1';
            list.append(row); updateRows(form); preview(form); row.querySelector('.kg-lookup-input').focus();
        }
        const remove = event.target.closest('.kg-remove-line'); if (remove) { const form = remove.closest('form'); if (form.querySelectorAll('.kg-sale-row').length > 1) { const next = remove.closest('.kg-sale-row').previousElementSibling || remove.closest('.kg-sale-row').nextElementSibling; remove.closest('.kg-sale-row').remove(); updateRows(form); preview(form); next?.querySelector('.kg-lookup-input').focus(); } }
        const copy = event.target.closest('[data-kg-copy]'); if (copy) { try { await navigator.clipboard.writeText(copy.dataset.kgCopy); copy.setAttribute('aria-label','کد کپی شد'); if (window.NioApp?.Toast) window.NioApp.Toast('کد کپی شد','success',{position:'top-right'}); } catch (_) { copy.title = 'کد را انتخاب و کپی کنید.'; } }
    });
    document.addEventListener('submit', event => {
        const form = event.target.closest('.kg-ui .kg-post-form,.kg-modal .kg-post-form'); if (!form) return;
        let valid = true;
        form.querySelectorAll('.kg-lookup').forEach(field => { const input = field.querySelector('.kg-lookup-input'); if (input.required && !input.disabled && !field.querySelector('[data-kg-id]').value) { input.setCustomValidity('از نتایج یک گزینه انتخاب کنید.'); input.reportValidity(); valid = false; } });
        if (!valid || form.dataset.kgSubmitting) { event.preventDefault(); return; }
        form.dataset.kgSubmitting = '1';
        form.querySelectorAll('[type=submit]').forEach(button => { button.dataset.kgOriginalText = button.innerHTML; button.disabled = true; button.setAttribute('aria-busy','true'); button.textContent = 'در حال ثبت…'; });
    });
    window.addEventListener('pageshow', () => document.querySelectorAll('[data-kg-submitting]').forEach(form => { delete form.dataset.kgSubmitting; form.querySelectorAll('[data-kg-original-text]').forEach(button => { button.innerHTML = button.dataset.kgOriginalText; button.disabled = false; button.removeAttribute('aria-busy'); }); }));
    document.addEventListener('DOMContentLoaded', init);
    const observer = new MutationObserver(records => { if (records.some(record => [...record.addedNodes].some(node => node.nodeType === 1 && (node.matches('.kg-ui,.kg-modal') || node.querySelector?.('.kg-ui,.kg-modal'))))) init(); });
    observer.observe(document.documentElement,{childList:true,subtree:true});
    init();
})();
