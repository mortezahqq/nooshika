<?php
/**
 * Plugin Name: به‌روزرسانی قهوه ساحل
 * Description: Restores frontend styles, installs the branded theme and connects native product categories, menus and WooCommerce products.
 * Version: 1.3.0
 * Requires PHP: 7.4
 */
defined( 'ABSPATH' ) || exit;
function sahel_store_update_copy( $from, $to ) {
    if ( ! wp_mkdir_p( $to ) || ! is_writable( $to ) ) { return new WP_Error( 'sahel_write', 'نوشتن در مسیر مقصد ممکن نیست: ' . $to ); }
    $it = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $from, FilesystemIterator::SKIP_DOTS ), RecursiveIteratorIterator::SELF_FIRST );
    foreach ( $it as $file ) {
        if ( $file->isLink() ) { continue; }
        $relative = substr( $file->getPathname(), strlen( $from ) + 1 ); $dest = $to . '/' . $relative;
        if ( $file->isDir() ) { if ( ! wp_mkdir_p( $dest ) ) { return new WP_Error( 'sahel_directory', 'ایجاد پوشه ممکن نشد.' ); } continue; }
        $data = file_get_contents( $file->getPathname() ); $temp = tempnam( dirname( $dest ), 'sahel-' );
        if ( false === $data || false === $temp || false === file_put_contents( $temp, $data ) ) { return new WP_Error( 'sahel_copy', 'کپی فایل به‌روزرسانی کامل نشد.' ); }
        @chmod( $temp, 0644 );
        if ( ! rename( $temp, $dest ) ) { @unlink( $temp ); return new WP_Error( 'sahel_replace', 'جایگزینی فایل ممکن نشد.' ); }
    }
    return true;
}
register_activation_hook( __FILE__, function() {
    if ( ! current_user_can( 'activate_plugins' ) ) { wp_die( esc_html( 'دسترسی فعال‌سازی ندارید.' ) ); }
    if ( ! file_exists( WP_PLUGIN_DIR . '/woocommerce/woocommerce.php' ) ) { wp_die( esc_html( 'ووکامرس نصب نیست. ابتدا ووکامرس یا بستهٔ کامل قهوه ساحل را نصب کنید.' ) ); }
    foreach ( array( array( __DIR__ . '/payload/theme', WP_CONTENT_DIR . '/themes/sahel-coffee' ), array( __DIR__ . '/payload/mu-plugins', WPMU_PLUGIN_DIR ) ) as $pair ) {
        $result = sahel_store_update_copy( $pair[0], $pair[1] ); if ( is_wp_error( $result ) ) { wp_die( esc_html( $result->get_error_message() ) ); }
    }
    $active = activate_plugin( 'woocommerce/woocommerce.php' ); if ( is_wp_error( $active ) ) { wp_die( esc_html( $active->get_error_message() ) ); }
    if ( 'sahel-coffee' !== get_stylesheet() ) {
        $mods = get_theme_mods(); update_option( 'sahel_previous_theme', get_stylesheet(), false );
        switch_theme( 'sahel-coffee' ); if ( is_array( $mods ) ) { update_option( 'theme_mods_sahel-coffee', $mods ); }
    }
    update_option( 'sahel_bundle_state', array( 'phase' => 'brand', 'index' => 0, 'created' => 0, 'notes' => array(), 'mode' => 'upgrade' ), false );
    delete_transient( '_wc_activation_redirect' );
} );
add_action( 'admin_notices', function() {
    if ( ! current_user_can( 'manage_options' ) ) { return; }
    echo '<div class="notice notice-success"><p>به‌روزرسانی قهوه ساحل نصب شد. <a href="' . esc_url( admin_url( 'admin.php?page=sahel-bundle' ) ) . '">ادامهٔ تکمیل دسته‌بندی‌ها، فهرست‌ها و محصولات</a></p></div>';
} );
