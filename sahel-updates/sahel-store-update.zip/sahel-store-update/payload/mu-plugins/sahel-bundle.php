<?php
/**
 * Plugin Name: Sahel Bundle Setup
 * Description: Configures a fresh Sahel WordPress/WooCommerce install and imports its bundled catalog.
 * Version: 1.1.0
 */
defined( 'ABSPATH' ) || exit;

add_filter( 'woocommerce_currencies', function ( $currencies ) { $currencies['IRT'] = 'تومان'; return $currencies; } );
add_filter( 'woocommerce_currency_symbol', function ( $symbol, $currency ) { return 'IRT' === $currency ? 'تومان' : $symbol; }, 10, 2 );

// Existing WordPress databases are never initialized or overwritten by the bundle.
add_action( 'wp_install', function () {
    add_option( 'sahel_bundle_state', array( 'phase' => 'activate', 'index' => 0, 'created' => 0, 'notes' => array() ), '', false );
} );

function sahel_bundle_pending() {
    $state = get_option( 'sahel_bundle_state', array() );
    return $state && 'done' !== $state['phase'];
}

add_action( 'admin_menu', function () {
    add_menu_page( 'راه‌اندازی ساحل', 'راه‌اندازی ساحل', 'manage_options', 'sahel-bundle', 'sahel_bundle_page', 'dashicons-store', 3 );
} );

add_action( 'admin_init', function () {
    if ( ! sahel_bundle_pending() || ! current_user_can( 'manage_options' ) || wp_doing_ajax() || wp_doing_cron() || ( defined( 'WP_CLI' ) && WP_CLI ) ) { return; }
    if ( isset( $_GET['page'] ) && 'sahel-bundle' === $_GET['page'] ) { return; }
    wp_safe_redirect( admin_url( 'admin.php?page=sahel-bundle' ) );
    exit;
} );

/** One bounded, repeatable setup step. No credentials or external SQL dump are stored. */
function sahel_bundle_perform_step() {
    $state = get_option( 'sahel_bundle_state', array() );
    if ( ! $state ) { return new WP_Error( 'not_fresh', 'این بسته فقط روی نصب تازهٔ وردپرس به‌صورت خودکار راه‌اندازی می‌شود.' ); }
    if ( 'done' === $state['phase'] ) { return $state; }
    if ( ! add_option( 'sahel_bundle_step_lock', time(), '', false ) ) {
        if ( (int) get_option( 'sahel_bundle_step_lock' ) < time() - 180 ) { delete_option( 'sahel_bundle_step_lock' ); }
        return new WP_Error( 'busy', 'مرحلهٔ قبلی هنوز در حال اجراست؛ چند ثانیه دیگر ادامه دهید.' );
    }
    try {
        if ( 'activate' === $state['phase'] ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
            if ( ! file_exists( WP_PLUGIN_DIR . '/woocommerce/woocommerce.php' ) || ! wp_get_theme( 'sahel-coffee' )->exists() ) {
                return new WP_Error( 'missing_files', 'فایل‌های ووکامرس یا قالب ناقص‌اند. ZIP را به‌طور کامل استخراج کنید.' );
            }
            $result = activate_plugin( 'woocommerce/woocommerce.php' );
            if ( is_wp_error( $result ) ) { return $result; }
            switch_theme( 'sahel-coffee' );
            delete_transient( '_wc_activation_redirect' );
            $state['phase'] = 'configure';
        } elseif ( 'configure' === $state['phase'] ) {
            if ( ! class_exists( 'WC_Install' ) || ! function_exists( 'sahel_catalog' ) ) { return new WP_Error( 'not_loaded', 'بارگذاری ووکامرس یا قالب کامل نشده است؛ ادامه را دوباره بزنید.' ); }
            update_option( 'timezone_string', 'Asia/Tehran' );
            update_option( 'WPLANG', 'fa_IR' );
            update_option( 'woocommerce_currency', 'IRT' );
            update_option( 'woocommerce_price_num_decimals', 0 );
            update_option( 'woocommerce_default_country', 'IR' );
            update_option( 'woocommerce_weight_unit', 'kg' );
            update_option( 'woocommerce_dimension_unit', 'cm' );
            update_option( 'woocommerce_hide_out_of_stock_items', 'no' );
            update_option( 'woocommerce_allow_tracking', 'no' );
            update_option( 'woocommerce_coming_soon', 'no' );
            update_option( 'woocommerce_store_pages_only', 'no' );
            update_option( 'woocommerce_onboarding_profile', array( 'completed' => true, 'skipped' => true ) );
            update_option( 'woocommerce_task_list_hidden', true );
            foreach ( array( 'bacs', 'cod', 'cheque' ) as $gateway ) {
                $settings = get_option( 'woocommerce_' . $gateway . '_settings', array() ); $settings['enabled'] = 'no';
                update_option( 'woocommerce_' . $gateway . '_settings', $settings );
            }
            WC_Install::create_pages();
            $pages = array( 'shop' => 'فروشگاه', 'cart' => 'سبد خرید', 'checkout' => 'تسویه حساب', 'myaccount' => 'حساب کاربری' );
            foreach ( $pages as $key => $title ) {
                $id = (int) get_option( 'woocommerce_' . $key . '_page_id' );
                if ( $id > 0 ) {
                    $post = array( 'ID' => $id, 'post_title' => $title );
                    $shortcodes = array( 'cart' => '[woocommerce_cart]', 'checkout' => '[woocommerce_checkout]', 'myaccount' => '[woocommerce_my_account]' );
                    if ( isset( $shortcodes[$key] ) ) { $post['post_content'] = $shortcodes[$key]; }
                    wp_update_post( $post );
                }
            }
            $home = get_page_by_path( 'sahel-home' );
            $home_id = $home ? $home->ID : wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_title' => 'صفحهٔ اصلی', 'post_name' => 'sahel-home', 'post_content' => '' ), true );
            if ( is_wp_error( $home_id ) ) { return $home_id; }
            update_option( 'show_on_front', 'page' ); update_option( 'page_on_front', (int) $home_id );
            update_option( 'permalink_structure', '/%postname%/' );
            delete_transient( '_wc_activation_redirect' );
            $structure = sahel_apply_store_structure();
            if ( is_wp_error( $structure ) ) { return $structure; }
            $state['structure'] = $structure;
            $state['phase'] = 'products';
        } elseif ( 'brand' === $state['phase'] ) {
            if ( ! function_exists( 'sahel_apply_store_structure' ) ) { return new WP_Error( 'missing_theme', 'قالب قهوه ساحل بارگذاری نشده است.' ); }
            $result = sahel_apply_store_structure();
            if ( is_wp_error( $result ) ) { return $result; }
            $state['structure'] = $result;
            update_option( 'woocommerce_coming_soon', 'no' );
            $state['index'] = 0; $state['phase'] = 'products';
        } elseif ( 'products' === $state['phase'] ) {
            if ( ! function_exists( 'sahel_import_one_product' ) ) { return new WP_Error( 'missing_importer', 'ماژول ورود محصولات بارگذاری نشده است.' ); }
            $catalog = sahel_catalog();
            if ( isset( $catalog[ $state['index'] ] ) ) {
                $result = sahel_import_one_product( $catalog[ $state['index'] ] );
                if ( is_wp_error( $result ) ) { return $result; }
                $state['created']++; $state['index']++;
            }
            if ( $state['index'] >= count( $catalog ) ) { sahel_link_catalog_categories(); update_option( 'sahel_catalog_imported', 1, false ); $state['phase'] = 'language'; }
        } elseif ( 'language' === $state['phase'] ) {
            // Locale downloads are optional: the core, shop, theme and images are already local.
            require_once ABSPATH . 'wp-admin/includes/translation-install.php';
            $timeout = function () { return 8; };
            add_filter( 'http_request_timeout', $timeout );
            $installed = wp_get_installed_translations( 'core' );
            if ( ! isset( $installed['default']['fa_IR'] ) ) {
                $language = wp_download_language_pack( 'fa_IR' );
                if ( ! $language || is_wp_error( $language ) ) { $state['notes'][] = 'دانلود ترجمهٔ فارسی در این هاست ممکن نشد؛ فروشگاه آماده است و ترجمه بعداً از بخش به‌روزرسانی‌ها قابل دریافت است.'; }
            }
            remove_filter( 'http_request_timeout', $timeout );
            $state['phase'] = 'finish';
        } elseif ( 'finish' === $state['phase'] ) {
            flush_rewrite_rules();
            $ids = array(); $images = array();
            foreach ( sahel_catalog() as $item ) {
                $id = wc_get_product_id_by_sku( $item['sku'] );
                $product = $id ? wc_get_product( $id ) : false;
                if ( ! $product || ! $product->get_image_id() ) { return new WP_Error( 'incomplete', 'ثبت محصولات کامل نیست. ورود محصولات را از نمایش ← محصولات ساحل ادامه دهید.' ); }
                $ids[] = $id;
                $images = array_merge( $images, array( $product->get_image_id() ), $product->get_gallery_image_ids() );
            }
            $state['verified_products'] = count( array_unique( $ids ) );
            $state['verified_images'] = count( array_unique( array_filter( $images ) ) );
            $state['phase'] = 'done'; $state['completed_at'] = gmdate( 'c' );
        }
        update_option( 'sahel_bundle_state', $state, false );
        return $state;
    } catch ( Throwable $e ) {
        return new WP_Error( 'setup_failed', 'این مرحله کامل نشد: ' . $e->getMessage() );
    } finally {
        delete_option( 'sahel_bundle_step_lock' );
    }
}

add_action( 'wp_ajax_sahel_bundle_start', function () {
    if ( ! current_user_can( 'manage_options' ) ) { wp_send_json_error( array( 'message' => 'دسترسی مجاز نیست.' ), 403 ); }
    check_ajax_referer( 'sahel_bundle_setup' );
    if ( ! file_exists( WP_PLUGIN_DIR . '/woocommerce/woocommerce.php' ) || ! wp_get_theme( 'sahel-coffee' )->exists() ) {
        wp_send_json_error( array( 'message' => 'فایل‌های قالب قهوه ساحل و ووکامرس روی این وردپرس پیدا نشدند. ابتدا بستهٔ کامل را استخراج کنید.' ), 400 );
    }
    if ( ! get_option( 'sahel_bundle_state' ) ) {
        add_option( 'sahel_bundle_state', array( 'phase' => 'activate', 'index' => 0, 'created' => 0, 'notes' => array() ), '', false );
    }
    wp_send_json_success( get_option( 'sahel_bundle_state' ) );
} );

add_action( 'wp_ajax_sahel_bundle_step', function () {
    if ( ! current_user_can( 'manage_options' ) ) { wp_send_json_error( array( 'message' => 'دسترسی مجاز نیست.' ), 403 ); }
    check_ajax_referer( 'sahel_bundle_setup' );
    $result = sahel_bundle_perform_step();
    if ( is_wp_error( $result ) ) { wp_send_json_error( array( 'message' => $result->get_error_message() ), 400 ); }
    wp_send_json_success( $result );
} );

function sahel_bundle_page() {
    if ( ! current_user_can( 'manage_options' ) ) { return; }
    $has_state = (bool) get_option( 'sahel_bundle_state' );
    ?>
    <div class="wrap" dir="rtl" style="max-width:760px;margin:35px auto;font-size:16px;line-height:2">
      <h1>آماده‌سازی فروشگاه ساحل</h1>
      <p>فعال‌سازی ووکامرس و قالب، ساخت برگه‌ها و ثبت ۱۴ محصول و ۱۵ تصویر به‌صورت خودکار انجام می‌شود.</p>
      <progress id="sahel-progress" max="100" value="0" style="width:100%;height:24px"></progress>
      <p id="sahel-status" role="status">در حال بررسی…</p>
      <?php if ( ! $has_state ) : ?><p>راه‌اندازی خودکار در این نصب شروع نشده است. دکمهٔ زیر قالب و تنظیمات فروشگاه را اعمال می‌کند و محصولات همراه بسته را وارد می‌کند؛ محصول موجود با SKU یکسان بازنویسی نمی‌شود.</p><button id="sahel-start" class="button button-primary">شروع راه‌اندازی ساحل</button><?php endif; ?>
      <button id="sahel-retry" class="button button-primary" hidden>ادامهٔ راه‌اندازی</button>
      <div id="sahel-done" hidden>
        <p>قالب فعال شد و محصولات واقعی در ووکامرس ثبت شدند. قیمت و موجودی را پیش از فروش تنظیم کنید؛ اطلاعات درگاه و ارسال به سرویس فروشگاه شما بستگی دارد.</p>
        <p><a class="button button-primary" href="<?php echo esc_url( admin_url( 'edit.php?post_type=product' ) ); ?>">مدیریت محصولات</a> <a class="button" href="<?php echo esc_url( home_url( '/' ) ); ?>">مشاهدهٔ فروشگاه</a></p>
      </div>
    </div>
    <script>
    (()=>{
      const status=document.getElementById('sahel-status'), progress=document.getElementById('sahel-progress'), retry=document.getElementById('sahel-retry');
      const labels={brand:'اصلاح نام، دسته‌بندی‌ها و فهرست‌ها',activate:'فعال‌سازی قالب و ووکامرس',configure:'تنظیم فروشگاه و ساخت برگه‌ها',products:'ثبت محصولات و تصاویر',language:'بررسی زبان فارسی',finish:'بررسی نهایی',done:'راه‌اندازی کامل شد'};
      const nonce=<?php echo wp_json_encode( wp_create_nonce( 'sahel_bundle_setup' ) ); ?>;
      async function step(){
        retry.hidden=true;
        try{
          const body=new URLSearchParams({action:'sahel_bundle_step',_ajax_nonce:nonce});
          const r=await fetch(<?php echo wp_json_encode( admin_url( 'admin-ajax.php' ) ); ?>,{method:'POST',credentials:'same-origin',body});
          const data=await r.json();if(!data.success)throw Error(data.data?.message||'مرحله کامل نشد؛ دوباره ادامه دهید.');
          const state=data.data;status.textContent=labels[state.phase]+(state.phase==='products'?' — '+state.index+' از ۱۴':'');
          progress.value=state.phase==='done'?100:state.phase==='products'?10+state.index*5:state.phase==='language'?85:state.phase==='finish'?95:5;
          if(state.phase==='done'){
            document.getElementById('sahel-done').hidden=false;
            status.textContent+='؛ '+state.verified_products+' محصول و '+state.verified_images+' تصویر ثبت شد.';
            if(state.structure) status.textContent+=' '+state.structure.categories+' دسته و '+state.structure.menus+' فهرست آماده‌اند.';
            (state.notes||[]).forEach(note=>{const p=document.createElement('p');p.textContent=note;document.getElementById('sahel-done').append(p);});
          }else setTimeout(step,200);
        }catch(e){status.textContent=e.message;retry.hidden=false;}
      }
      retry.onclick=step;
      const hasState=<?php echo wp_json_encode( $has_state ); ?>;
      if(hasState){step();}else{
        status.textContent='برای شروع، دکمهٔ «شروع راه‌اندازی ساحل» را بزنید.';
        document.getElementById('sahel-start').onclick=async function(){
          this.disabled=true;
          try{
            const body=new URLSearchParams({action:'sahel_bundle_start',_ajax_nonce:nonce});
            const response=await fetch(<?php echo wp_json_encode( admin_url( 'admin-ajax.php' ) ); ?>,{method:'POST',credentials:'same-origin',body});
            const data=await response.json();if(!data.success)throw Error(data.data?.message||'شروع راه‌اندازی ممکن نشد.');
            this.hidden=true;step();
          }catch(e){status.textContent=e.message;this.disabled=false;}
        };
      }
    })();
    </script>
    <?php
}

// Connect the preserved header controls to the local store without changing its layout.
add_action( 'wp_enqueue_scripts', function () {
    if ( ! function_exists( 'wc_get_page_permalink' ) || 'sahel-coffee' !== get_template() ) { return; }
    wp_enqueue_script( 'sahel-bundle-navigation', WPMU_PLUGIN_URL . '/sahel-nav.js', array(), '1.0.0', true );
    $nav = array( 'home' => home_url( '/' ), 'shop' => wc_get_page_permalink( 'shop' ), 'cart' => wc_get_page_permalink( 'cart' ), 'account' => wc_get_page_permalink( 'myaccount' ), 'count' => WC()->cart ? WC()->cart->get_cart_contents_count() : 0 );
    wp_add_inline_script( 'sahel-bundle-navigation', 'window.sahelBundleNavigation=' . wp_json_encode( $nav ) . ';', 'before' );
} );
