(() => {
  'use strict';
  const config = window.sahelBundleNavigation;
  if (!config) return;
  document.querySelectorAll('.btn-open-wc-cart').forEach(a => { a.href = config.cart; a.onclick = null; });
  document.querySelectorAll('.cart-badge').forEach(a => { a.textContent = Number(config.count || 0).toLocaleString('fa-IR'); });
  document.querySelectorAll('.header-search-btn').forEach(a => {
    a.onclick = e => {
      e.preventDefault();
      let dialog = document.getElementById('sahel-search-dialog');
      if (!dialog) {
        dialog = document.createElement('dialog'); dialog.id = 'sahel-search-dialog'; dialog.className = 'sahel-product-dialog';
        dialog.innerHTML = '<button type="button" class="sahel-close" aria-label="بستن">×</button><h2>جست‌وجوی محصولات</h2><form method="get"><input type="hidden" name="post_type" value="product"><label for="sahel-product-search">نام محصول</label><input id="sahel-product-search" name="s" type="search" required class="form-control"><button class="btn btn-primary" style="margin-top:16px">جست‌وجو</button></form>';
        dialog.querySelector('form').action = config.home;
        dialog.querySelector('.sahel-close').onclick = () => dialog.close();
        dialog.onclick = event => { if (event.target === dialog) dialog.close(); };
        document.body.append(dialog);
      }
      dialog.showModal(); dialog.querySelector('input[type="search"]').focus();
    };
  });
})();
