<?php
defined( 'ABSPATH' ) || exit;
global $product;
if ( ! is_a( $product, 'WC_Product' ) || ! $product->is_visible() ) { return; }
?>
<li <?php wc_product_class( 'sahel-wc-card', $product ); ?>>
<?php do_action( 'woocommerce_before_shop_loop_item' ); ?>
<div class="sahel-wc-card-image"><?php do_action( 'woocommerce_before_shop_loop_item_title' ); ?></div>
<div class="sahel-wc-card-content">
<?php do_action( 'woocommerce_shop_loop_item_title' ); ?>
<?php do_action( 'woocommerce_after_shop_loop_item_title' ); ?>
<?php if ( '' === $product->get_price() ) : ?><span class="price">استعلام قیمت</span><?php endif; ?>
</div>
<?php do_action( 'woocommerce_after_shop_loop_item' ); ?>
</li>
