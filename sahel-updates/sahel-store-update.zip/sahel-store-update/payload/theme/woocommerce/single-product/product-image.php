<?php
defined( 'ABSPATH' ) || exit;
global $product;
$ids = array_values( array_unique( array_filter( array_merge( array( $product->get_image_id() ), $product->get_gallery_image_ids() ) ) ) );
$full = $ids ? wp_get_attachment_image_url( $ids[0], 'full' ) : wc_placeholder_img_src();
?>
<div class="sahel-native-gallery">
  <a class="sahel-full-image" href="<?php echo esc_url( $full ); ?>" target="_blank" rel="noopener noreferrer" aria-label="نمایش تصویر کامل محصول">
  <?php if ( $ids ) { echo wp_get_attachment_image( $ids[0], 'full', false, array( 'class' => 'sahel-main-product-image', 'alt' => $product->get_name(), 'loading' => 'eager' ) ); } else { echo '<img class="sahel-main-product-image" src="' . esc_url( $full ) . '" alt="' . esc_attr( $product->get_name() ) . '">'; } ?>
  </a>
  <?php if ( count( $ids ) > 1 ) : ?><div class="sahel-native-thumbs">
    <?php foreach ( $ids as $i => $id ) : $url = wp_get_attachment_image_url( $id, 'full' ); ?>
      <button type="button" class="sahel-gallery-thumb<?php echo 0 === $i ? ' active' : ''; ?>" data-image="<?php echo esc_url( $url ); ?>" aria-label="<?php echo esc_attr( 'تصویر ' . ( $i + 1 ) . ' از ' . $product->get_name() ); ?>"><?php echo wp_get_attachment_image( $id, 'thumbnail', false, array( 'alt' => '' ) ); ?></button>
    <?php endforeach; ?>
  </div><?php endif; ?>
</div>
