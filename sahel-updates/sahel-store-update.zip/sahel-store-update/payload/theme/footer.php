<?php
defined( 'ABSPATH' ) || exit;
sahel_coffee_fragment( 'footer' );
wp_footer();
?>
</body>
</html>
