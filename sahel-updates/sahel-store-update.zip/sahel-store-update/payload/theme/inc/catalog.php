<?php
defined( 'ABSPATH' ) || exit;
/** Bundled seed data is used only by the importer, never as storefront products. */
function sahel_catalog() {
    static $items;
    if ( null === $items ) { $items = json_decode( file_get_contents( get_template_directory() . '/catalog/products.json' ), true ); }
    return is_array( $items ) ? $items : array();
}
function sahel_product_slides( $type, $index = null ) {
    if ( ! function_exists( 'wc_get_products' ) ) { return ''; }
    $args = array( 'status' => 'publish', 'visibility' => 'visible', 'limit' => '3' === $type ? 4 : 24, 'orderby' => 'date', 'order' => 'DESC' );
    if ( '3' === $type ) { $args['featured'] = true; }
    $products = wc_get_products( $args );
    if ( ! $products && '3' === $type ) { unset( $args['featured'] ); $products = wc_get_products( $args ); }
    if ( null !== $index ) { $products = isset( $products[$index] ) ? array( $products[$index] ) : array(); }
    if ( ! $products ) { return '2' === $type ? '<p class="sahel-empty-products">هنوز محصولی منتشر نشده است.</p>' : ''; }
    ob_start();
    foreach ( $products as $product ) {
        $name = $product->get_name(); $url = $product->get_permalink();
        $ids = array_filter( array_merge( array( $product->get_image_id() ), $product->get_gallery_image_ids() ) );
        $images = array_values( array_filter( array_map( function ( $id ) { return wp_get_attachment_image_url( $id, 'full' ); }, $ids ) ) );
        if ( ! $images ) { $images = array( wc_placeholder_img_src( 'woocommerce_single' ) ); }
        $price = '' !== $product->get_price() ? $product->get_price_html() : 'استعلام قیمت';
        $payload = array( 'name' => $name, 'description' => wp_strip_all_tags( $product->get_description() ), 'images' => $images, 'price' => wp_strip_all_tags( $price ), 'url' => $url, 'blend' => $product->get_attribute( 'ترکیب قهوه' ) );
        $buy = $product->is_purchasable() && $product->is_in_stock();
        $button_url = $buy ? $product->add_to_cart_url() : $url;
        ?>
        <?php if ( null === $index ) : ?><div class="swiper-slide" role="group"><?php endif; ?>
          <div class="product-card product-card-<?php echo esc_attr( $type ); ?>" data-product-id="<?php echo esc_attr( $product->get_id() ); ?>" data-sahel-product="<?php echo esc_attr( wp_json_encode( $payload ) ); ?>">
            <div class="product-card-image">
              <a href="<?php echo esc_url( $url ); ?>" class="sahel-product-image-link"><img loading="lazy" decoding="async" width="300" height="300" src="<?php echo esc_url( $images[0] ); ?>" alt="<?php echo esc_attr( $name ); ?>" style="width:100%;aspect-ratio:1;object-fit:contain"></a>
              <div class="product-card-image-overly"><button type="button" class="product-card-overly-btn sahel-preview" aria-label="<?php echo esc_attr( 'مشاهدهٔ ' . $name ); ?>"><i class="iconly-Show" aria-hidden="true"></i></button></div>
            </div>
            <div class="product-card-content<?php echo '3' === $type ? ' card-content-right' : ''; ?>">
              <a href="<?php echo esc_url( $url ); ?>" class="sahel-product-title-link"><h3 class="title"><?php echo esc_html( $name ); ?></h3></a>
              <div class="product-price-container"><div class="product-price"><div class="current-price"><?php echo wp_kses_post( $price ); ?></div></div></div>
              <?php if ( '2' === $type ) : ?><a href="<?php echo esc_url( $button_url ); ?>" class="product-card-2-cart" aria-label="<?php echo esc_attr( $buy ? $product->add_to_cart_text() : 'جزئیات محصول' ); ?>"><i class="icon-plus" aria-hidden="true"></i></a><?php endif; ?>
              <?php if ( '3' === $type ) : ?><div class="product-card-3-buttons"><a href="<?php echo esc_url( $button_url ); ?>" class="product-card-3-cart"><span class="product-card-3-cart-icon"><i class="icon-plus" aria-hidden="true"></i></span><span><?php echo esc_html( $buy ? $product->add_to_cart_text() : 'مشاهدهٔ محصول' ); ?></span></a></div><?php endif; ?>
            </div>
          </div>
        <?php if ( null === $index ) : ?></div><?php endif; ?>
        <?php
    }
    return ob_get_clean();
}
