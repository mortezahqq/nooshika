<?php
defined( 'ABSPATH' ) || exit;

function sahel_apply_store_structure() {
    $previous_pages = array();
    foreach ( array( 'shop', 'cart', 'checkout', 'myaccount' ) as $key ) { $previous_pages[$key] = (int) get_option( 'woocommerce_' . $key . '_page_id' ); }
    WC_Install::create_pages();
    $defaults = array( 'shop' => array( 'فروشگاه', '' ), 'cart' => array( 'سبد خرید', '[woocommerce_cart]' ), 'checkout' => array( 'تسویه حساب', '[woocommerce_checkout]' ), 'myaccount' => array( 'حساب کاربری', '[woocommerce_my_account]' ) );
    foreach ( $defaults as $key => $spec ) {
        $id = (int) get_option( 'woocommerce_' . $key . '_page_id' );
        if ( $previous_pages[$key] <= 0 && $id > 0 ) { wp_update_post( array( 'ID' => $id, 'post_title' => $spec[0], 'post_content' => $spec[1] ) ); }
    }
    $categories = json_decode( file_get_contents( get_template_directory() . '/catalog/categories.json' ), true );
    $map = get_option( 'sahel_category_map', array() ); $used = array();
    $roots = array(); foreach ( $categories as $path => $name ) { if ( 1 === substr_count( $path, '/' ) ) { $roots[] = $name; } }
    foreach ( $categories as $path => $name ) {
        $segments = explode( '/', $path ); array_shift( $segments );
        $parent_path = 'product-category/' . implode( '/', array_slice( $segments, 0, -1 ) );
        $parent = count( $segments ) > 1 ? (int) ( $map[$parent_path] ?? 0 ) : 0;
        $term = isset( $map[$path] ) ? get_term( $map[$path], 'product_cat' ) : false;
        if ( ! $term || is_wp_error( $term ) ) {
            $matches = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false, 'name' => $name, 'parent' => $parent ) );
            $term = ! is_wp_error( $matches ) && $matches ? $matches[0] : false;
        }
        if ( ! $term && $parent && ! in_array( $name, $roots, true ) ) {
            $candidate = get_term_by( 'name', $name, 'product_cat' );
            if ( $candidate && ! in_array( $candidate->term_id, $used, true ) && 0 === (int) $candidate->parent ) {
                $result = wp_update_term( $candidate->term_id, 'product_cat', array( 'parent' => $parent ) );
                if ( ! is_wp_error( $result ) ) { $term = get_term( $candidate->term_id, 'product_cat' ); }
            }
        }
        if ( ! $term ) {
            $result = wp_insert_term( $name, 'product_cat', array( 'parent' => $parent, 'slug' => sanitize_title( end( $segments ) ) ) );
            if ( is_wp_error( $result ) ) { return $result; }
            $term = get_term( $result['term_id'], 'product_cat' );
        }
        $map[$path] = (int) $term->term_id; $used[] = (int) $term->term_id;
    }
    update_option( 'sahel_category_map', $map, false );
    $pages = get_option( 'sahel_brand_pages', array() );
    $specs = array( 'about' => 'درباره قهوه ساحل', 'contact' => 'تماس با ما', 'faq' => 'سوالات متداول', 'blog' => 'وبلاگ قهوه ساحل' );
    foreach ( $specs as $key => $title ) {
        $post = isset( $pages[$key] ) ? get_post( $pages[$key] ) : get_page_by_path( $key );
        if ( ! $post ) {
            $content = 'about' === $key ? 'قهوه ساحل؛ مجموعه‌ای از قهوه‌های ترکیبی، قهوه فوری و نوشیدنی‌های گرم.' : '';
            $id = wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_name' => $key, 'post_title' => $title, 'post_content' => $content ), true );
            if ( is_wp_error( $id ) ) { return $id; }
            $pages[$key] = $id;
        } else { $pages[$key] = $post->ID; }
    }
    $legacy = get_option( 'sahel_previous_theme', '' );
    if ( $legacy && 'sahel-coffee' !== $legacy ) {
        $old_template = 'page-' . strtok( $legacy, '-' ) . '.php';
        $old_pages = get_posts( array( 'post_type' => 'page', 'posts_per_page' => -1, 'fields' => 'ids', 'meta_key' => '_wp_page_template', 'meta_value' => $old_template ) );
        foreach ( $old_pages as $id ) { update_post_meta( $id, '_wp_page_template', 'page-sahel.php' ); }
    }
    update_option( 'sahel_brand_pages', $pages, false );
    update_option( 'page_for_posts', $pages['blog'] );
    update_option( 'blogname', 'قهوه ساحل' );
    update_option( 'blogdescription', 'قهوه و نوشیدنی‌های گرم ساحل' );
    $menu_ids = get_option( 'sahel_managed_menus', array() );
    $locations = get_theme_mod( 'nav_menu_locations', array() );
    foreach ( array( 'primary' => 'فهرست اصلی قهوه ساحل', 'top' => 'پیوندهای بالای قهوه ساحل', 'footer1' => 'دسترسی سریع قهوه ساحل', 'footer2' => 'محصولات قهوه ساحل', 'footer3' => 'حساب و ارتباط قهوه ساحل' ) as $key => $title ) {
        // Keep menu edits made by the owner on subsequent runs.
        $existing = isset( $menu_ids[$key] ) ? wp_get_nav_menu_object( $menu_ids[$key] ) : false;
        if ( $existing ) { $locations['sahel_' . $key] = $existing->term_id; continue; }
        $menu = wp_create_nav_menu( $title ); if ( is_wp_error( $menu ) ) { return $menu; }
        $menu_ids[$key] = $menu; $locations['sahel_' . $key] = $menu;
        $add_link = function( $label, $url ) use ( $menu ) { return wp_update_nav_menu_item( $menu, 0, array( 'menu-item-title' => $label, 'menu-item-url' => $url, 'menu-item-type' => 'custom', 'menu-item-status' => 'publish' ) ); };
        $add_page = function( $page_id, $label = '' ) use ( $menu ) { return wp_update_nav_menu_item( $menu, 0, array( 'menu-item-title' => $label, 'menu-item-object-id' => $page_id, 'menu-item-object' => 'page', 'menu-item-type' => 'post_type', 'menu-item-status' => 'publish' ) ); };
        if ( 'primary' === $key ) {
            $add_link( 'خانه', home_url( '/' ) ); $parents = array();
            foreach ( $categories as $path => $name ) {
                $segments = explode( '/', $path ); $parent_path = implode( '/', array_slice( $segments, 0, -1 ) );
                $parent_item = $parents[$parent_path] ?? 0;
                $id = wp_update_nav_menu_item( $menu, 0, array( 'menu-item-title' => $name, 'menu-item-object-id' => $map[$path], 'menu-item-object' => 'product_cat', 'menu-item-type' => 'taxonomy', 'menu-item-parent-id' => $parent_item, 'menu-item-status' => 'publish' ) );
                if ( is_wp_error( $id ) ) { return $id; } $parents[$path] = $id;
            }
            $add_page( $pages['blog'], 'وبلاگ' );
        } elseif ( 'top' === $key ) {
            $add_page( $pages['contact'] ); $add_page( $pages['faq'] ); $add_page( $pages['blog'] );
        } elseif ( 'footer1' === $key ) {
            $add_page( $pages['about'] ); $add_page( $pages['contact'] ); $add_page( $pages['faq'] ); $add_page( $pages['blog'] );
        } elseif ( 'footer2' === $key ) {
            foreach ( $categories as $path => $name ) { if ( 1 === substr_count( $path, '/' ) ) { wp_update_nav_menu_item( $menu, 0, array( 'menu-item-title' => $name, 'menu-item-object-id' => $map[$path], 'menu-item-object' => 'product_cat', 'menu-item-type' => 'taxonomy', 'menu-item-status' => 'publish' ) ); } }
        } else {
            foreach ( array( 'myaccount' => 'حساب کاربری', 'cart' => 'سبد خرید', 'shop' => 'همه محصولات' ) as $slug => $label ) { $add_link( $label, wc_get_page_permalink( $slug ) ); }
            $add_page( $pages['contact'] );
        }
    }
    update_option( 'sahel_managed_menus', $menu_ids, false ); set_theme_mod( 'nav_menu_locations', $locations );
    return array( 'categories' => count( $categories ), 'menus' => count( $menu_ids ) );
}
function sahel_render_menus( $markup ) {
    foreach ( array( 'PRIMARY', 'TOP', 'FOOTER1', 'FOOTER2', 'FOOTER3' ) as $slot ) {
        $location = 'sahel_' . strtolower( $slot );
        $html = wp_nav_menu( array( 'theme_location' => $location, 'container' => false, 'echo' => false, 'fallback_cb' => false, 'menu_class' => 'PRIMARY' === $slot ? 'menu-items' : 'menu', 'menu_id' => 'sahel-' . strtolower( $slot ) ) );
        $markup = str_replace( '<!--SAHEL_MENU_' . $slot . '-->', $html ?: '', $markup );
    }
    return $markup;
}
function sahel_render_local_links( $markup ) {
    $pattern = <<<'REGEX'
~\{\{SAHEL_LOCAL\}\}([^\s"'<>]*)~u
REGEX;
    return preg_replace_callback( $pattern, function ( $m ) {
        $path = trim( rawurldecode( (string) wp_parse_url( $m[1], PHP_URL_PATH ) ), '/' );
        if ( ! $path ) { return esc_url( home_url( '/' ) ); }
        if ( 0 === strpos( $path, 'product-category/' ) ) {
            $map = get_option( 'sahel_category_map', array() ); $id = $map[$path] ?? 0;
            $url = $id ? get_term_link( (int) $id, 'product_cat' ) : false;
            return esc_url( $url && ! is_wp_error( $url ) ? $url : wc_get_page_permalink( 'shop' ) );
        }
        foreach ( array( 'shop', 'cart', 'checkout', 'my-account' ) as $key ) { if ( $path === $key ) { return esc_url( wc_get_page_permalink( 'my-account' === $key ? 'myaccount' : $key ) ); } }
        $pages = get_option( 'sahel_brand_pages', array() );
        foreach ( array( 'contact-us' => 'contact', 'contact' => 'contact', 'about-us' => 'about', 'blog' => 'blog', 'سوالات-متداول' => 'faq' ) as $old => $key ) { if ( $path === $old && isset( $pages[$key] ) ) { return esc_url( get_permalink( $pages[$key] ) ); } }
        return esc_url( wc_get_page_permalink( 'shop' ) );
    }, $markup );
}

function sahel_link_catalog_categories() {
    $map = get_option( 'sahel_category_map', array() );
    $wanted = array( 'masala' => 'چای ماسالا', 'hot-chocolate' => 'هات شکلات', 'cappuccino' => 'کاپوچینو', 'vanilla-cappuccino' => 'کاپوچینو', 'gold-instant' => 'قهوه فوری', 'classic-instant' => 'قهوه فوری', 'instant-espresso' => 'قهوه فوری' );
    foreach ( sahel_catalog() as $item ) {
        if ( ! isset( $wanted[$item['slug']] ) ) { continue; }
        $product = wc_get_product( wc_get_product_id_by_sku( $item['sku'] ) ); if ( ! $product ) { continue; }
        $target = get_term_by( 'name', $wanted[$item['slug']], 'product_cat' ); if ( ! $target ) { continue; }
        $ids = $product->get_category_ids();
        if ( 'نوشیدنی پودری' === $item['category'] ) {
            $old = get_term_by( 'name', $item['category'], 'product_cat' );
            if ( $old && $ids === array( (int) $old->term_id ) ) { $ids = array(); }
        }
        $ids[] = (int) $target->term_id; $product->set_category_ids( array_values( array_unique( $ids ) ) ); $product->save();
    }
}
