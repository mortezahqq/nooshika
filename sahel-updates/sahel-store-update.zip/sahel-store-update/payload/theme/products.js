(() => {
  'use strict';
  const cards = [...document.querySelectorAll('[data-sahel-product]')];
  if (!cards.length) return;
  const dialog = document.createElement('dialog');
  dialog.className = 'sahel-product-dialog';
  dialog.innerHTML = '<button type="button" class="sahel-close" aria-label="بستن">×</button><h2></h2><img class="sahel-product-photo" alt=""><div class="sahel-gallery"></div><p class="sahel-description"></p><p class="sahel-blend"></p><strong class="sahel-price"></strong><a class="btn btn-primary sahel-product-link">جزئیات محصول</a>';
  document.body.append(dialog);
  dialog.querySelector('.sahel-close').onclick = () => dialog.close();
  dialog.addEventListener('click', e => { if (e.target === dialog) dialog.close(); });
  function show(product) {
    dialog.querySelector('h2').textContent = product.name;
    const main = dialog.querySelector('.sahel-product-photo');
    main.src = product.images[0]; main.alt = product.name;
    const gallery = dialog.querySelector('.sahel-gallery'); gallery.replaceChildren();
    if (product.images.length > 1) product.images.forEach((url, i) => {
      const button = document.createElement('button'); button.type = 'button';
      button.setAttribute('aria-label', 'تصویر ' + (i + 1) + ' از ' + product.name);
      const img = new Image(); img.src = url; img.alt = ''; button.append(img);
      button.onclick = () => { main.src = url; }; gallery.append(button);
    });
    dialog.querySelector('.sahel-description').textContent = product.description;
    dialog.querySelector('.sahel-blend').textContent = product.blend;
    dialog.querySelector('.sahel-price').textContent = product.price;
    const link = dialog.querySelector('.sahel-product-link');
    link.hidden = !product.url || product.url.startsWith('#');
    if (!link.hidden) link.href = product.url;
    if (!dialog.open) dialog.showModal();
  }
  cards.forEach(card => {
    let product; try { product = JSON.parse(card.dataset.sahelProduct); } catch { return; }
    card.querySelectorAll('.sahel-preview').forEach(button => button.addEventListener('click', e => { e.preventDefault(); show(product); }));
  });
})();

document.querySelectorAll('.sahel-native-gallery').forEach(gallery=>{
  gallery.querySelectorAll('.sahel-gallery-thumb').forEach(button=>button.addEventListener('click',()=>{
    const image=gallery.querySelector('.sahel-main-product-image');image.removeAttribute('srcset');image.removeAttribute('sizes');image.src=button.dataset.image;
    gallery.querySelector('.sahel-full-image').href=button.dataset.image;
    gallery.querySelectorAll('.sahel-gallery-thumb').forEach(other=>other.classList.toggle('active',other===button));
  }));
});
