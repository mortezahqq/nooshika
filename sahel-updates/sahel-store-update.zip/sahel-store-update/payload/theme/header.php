<?php
defined( 'ABSPATH' ) || exit;
sahel_coffee_fragment( 'head' );
wp_head();
?>
</head>
<?php
sahel_coffee_fragment( 'body-open' );
wp_body_open();
sahel_coffee_fragment( 'header' );
