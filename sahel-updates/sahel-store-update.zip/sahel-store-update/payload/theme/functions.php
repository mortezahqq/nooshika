<?php
/** Theme integration; original presentation is kept in template-parts. */
defined( 'ABSPATH' ) || exit;

function sahel_coffee_setup() {
    load_theme_textdomain( 'sahel-coffee', get_template_directory() . '/languages' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'title-tag' );
    register_nav_menus( array( 'sahel_primary' => 'فهرست اصلی', 'sahel_top' => 'پیوندهای بالای سایت', 'sahel_footer1' => 'فهرست فوتر ۱', 'sahel_footer2' => 'فهرست فوتر ۲', 'sahel_footer3' => 'فهرست فوتر ۳' ) );
    add_theme_support( 'woocommerce' );
    add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption' ) );
}
add_action( 'after_setup_theme', 'sahel_coffee_setup' );

/** Output only known, bundled markup, with asset paths adapted to this installation. */
function sahel_coffee_fragment( $name ) {
    $allowed = array( 'head', 'body-open', 'header', 'home', 'footer' );
    if ( ! in_array( $name, $allowed, true ) ) {
        return;
    }
    $path = get_template_directory() . '/template-parts/' . $name . '.html';
    if ( ! is_readable( $path ) ) {
        return;
    }
    $markup = file_get_contents( $path );
    if ( false === $markup ) {
        return;
    }
    $markup = sahel_render_local_links( $markup );
    $markup = sahel_render_menus( $markup );
    if ( 'body-open' === $name ) {
        $markup = preg_replace_callback( '/class="([^"]*)"/', function( $m ) { return 'class="' . esc_attr( implode( ' ', array_unique( array_merge( explode( ' ', $m[1] ), get_body_class() ) ) ) ) . '"'; }, $markup, 1 );
    }
    $base = trailingslashit( get_template_directory_uri() );
    $markup = str_replace( 'assets/', esc_url( $base . 'assets/' ), $markup );
    $markup = str_replace( 'src="design.js"', 'src="' . esc_url( $base . 'design.js' ) . '"', $markup );
    if ( 'home' === $name ) {
        $markup = str_replace( '<!--SAHEL_PRODUCTS_2-->', sahel_product_slides( '2' ), $markup );
        for ( $i = 0; $i < 4; $i++ ) {
            $markup = str_replace( '<!--SAHEL_FEATURED_' . $i . '-->', sahel_product_slides( '3', $i ), $markup );
        }
    }
    // This is trusted, immutable theme markup, not user-provided database content.
    echo $markup; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
}

require_once get_template_directory() . '/inc/catalog.php';
require_once get_template_directory() . '/inc/import-products.php';

add_action( 'wp_enqueue_scripts', function () {
    wp_enqueue_style( 'sahel-products', get_template_directory_uri() . '/products.css', array(), '1.3.0' );
    wp_enqueue_script( 'sahel-products', get_template_directory_uri() . '/products.js', array(), '1.3.0', true );
} );

require_once get_template_directory() . '/inc/store-structure.php';

add_action( 'wp_enqueue_scripts', function() { wp_enqueue_style( 'sahel-store', get_template_directory_uri() . '/store.css', array(), '1.3.0' ); }, 20 );
add_filter( 'woocommerce_product_description_heading', function() { return false; } );
add_filter( 'woocommerce_product_additional_information_heading', function() { return 'مشخصات محصول'; } );
add_filter( 'woocommerce_product_tabs', function( $tabs ) {
    if ( isset( $tabs['description'] ) ) { $tabs['description']['title'] = 'توضیحات محصول'; }
    if ( isset( $tabs['additional_information'] ) ) { $tabs['additional_information']['title'] = 'مشخصات محصول'; }
    if ( isset( $tabs['reviews'] ) ) { $tabs['reviews']['title'] = 'دیدگاه‌ها'; }
    return $tabs;
} );
add_action( 'woocommerce_single_product_summary', function() {
    global $product;
    if ( $product && '' === $product->get_price() ) {
        $pages = get_option( 'sahel_brand_pages', array() );
        $url = isset( $pages['contact'] ) ? get_permalink( $pages['contact'] ) : home_url( '/contact/' );
        echo '<a class="sahel-stock-contact" href="' . esc_url( $url ) . '">استعلام قیمت</a>';
    }
}, 12 );
add_filter( 'gettext', function( $translation, $text, $domain ) {
    if ( 'woocommerce' !== $domain ) { return $translation; }
    $labels = array( 'Home' => 'خانه', 'Shop' => 'فروشگاه', 'Select options' => 'انتخاب گزینه‌ها', 'Related products' => 'محصولات مرتبط', 'Add to cart' => 'افزودن به سبد خرید', 'Read more' => 'مشاهده محصول', 'Description' => 'توضیحات محصول', 'Additional information' => 'مشخصات محصول', 'Out of stock' => 'ناموجود', 'In stock' => 'موجود', 'SKU:' => 'شناسه محصول:', 'Category:' => 'دسته‌بندی:', 'Categories:' => 'دسته‌بندی‌ها:', 'Weight' => 'وزن', 'Dimensions' => 'ابعاد', 'View cart' => 'مشاهده سبد خرید', 'Your cart is currently empty.' => 'سبد خرید شما خالی است.', 'Return to shop' => 'بازگشت به فروشگاه' );
    return $labels[$text] ?? $translation;
}, 20, 3 );

add_filter( 'woocommerce_breadcrumb_defaults', function( $defaults ) { $defaults['home'] = 'خانه'; return $defaults; } );
add_filter( 'ngettext', function( $translation, $single, $plural, $number, $domain ) {
    if ( 'woocommerce' === $domain && ( 'Category:' === $single || 'Categories:' === $plural ) ) { return $number > 1 ? 'دسته‌بندی‌ها:' : 'دسته‌بندی:'; }
    return $translation;
}, 20, 5 );
