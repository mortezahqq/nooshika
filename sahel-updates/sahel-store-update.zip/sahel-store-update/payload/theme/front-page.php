<?php
defined( 'ABSPATH' ) || exit;
get_header();
sahel_coffee_fragment( 'home' );
get_footer();
