<?php
/**
 * Template Name: قهوه ساحل — طراحی کامل اصلی
 * Template Post Type: page
 */
defined( 'ABSPATH' ) || exit;
get_header();
sahel_coffee_fragment( 'home' );
get_footer();
