<?php
require __DIR__.'/bootstrap.php';
function selected($a,$b=true,$echo=true){$h=(string)$a===(string)$b?' selected="selected"':'';if($echo)echo$h;return$h;}
function method_rows(){return[['settlementPolicyID'=>45,'settlementPolicyName'=>'اسنپ پی (قسط)','settlementMethodGroups'=>[['settlementMethodGroupID'=>5,'settlementMethods'=>[['settlementMethodID'=>11,'settlementNatureKey'=>'EReceipt','settlementMethodName'=>'دریافت بانکی سایت'],['settlementMethodID'=>8,'settlementNatureKey'=>'ThirdPartyCoupon','settlementMethodName'=>'بن سازمانی اسنپ پی'],['settlementMethodID'=>10,'settlementNatureKey'=>'Cash','settlementMethodName'=>'نقدی']]]]]];}
function method_catalog(){ $fn=new ReflectionMethod(RKW_Policy_Catalog::class,'policies');$fn->setAccessible(true);return$fn->invoke(null,method_rows());}
function method_reset(){reset_case();$s=rkw_settings();$s['document_contract']='legacy_esales';$s['invoice_settlement_id']=45;$s['inventory_id']=2;$s['loyalty_id']=3;$s['payment_rules']=[['gateway'=>'WC_Gateway_SnappPay','settlement_id'=>45,'receipt_key'=>'ThirdPartyCoupon','coupon_type_id'=>5]];$GLOBALS['options'][RKW_OPT]=$s;set_transient(RKW_Client::COOKIE_TRANSIENT,['name'=>'sg-auth-sg','value'=>'synthetic-cookie','signature'=>RKW_Policy_Catalog::signature($s)],60);$GLOBALS['options'][RKW_Policy_Catalog::OPTION]=['signature'=>RKW_Policy_Catalog::signature($s),'schema_version'=>2,'updated_at'=>time(),'invoice'=>method_catalog(),'order'=>[]];$GLOBALS['posted']=[];$GLOBALS['events']=[];$GLOBALS['upstream_failure']=false;$GLOBALS['filters']['rkw_order_payload']=[20=>[[RKW_Extensions::class,'extend_payload']],30=>[[RKW_Loyalty::class,'extend_payload']]];
 $GLOBALS['http_handler']=function($u,$a){$GLOBALS['events'][]=[$u,$a['method']];if(strpos($u,'/thirdPartyCouponTypes')!==false){check($a['method']==='GET');return response([['Id'=>5,'title'=>'قرارداد اسنپ']]);}if(strpos($u,'/CashierLogin')!==false){check($a['method']==='POST');return['code'=>200,'body'=>'[]'];}if(strpos($u,'/ESales.svc/invoice')!==false||strpos($u,'/InvoiceService.svc/SaveInvoice')!==false){$body=json_decode($a['body'],true);$GLOBALS['posted'][]=$body;return$GLOBALS['upstream_failure']?response([],false,'Sequence contains no elements'):response(['id'=>123321]);}throw new RuntimeException('Unexpected endpoint '.$u);};
}
function method_order(){ $o=order(3695000);$o->id=238312;$o->gateway='WC_Gateway_SnappPay';$o->items[0]->product->meta['_rahkaran_product_id']=263152;return$o;}
function method_wire($contract='legacy_esales'){$GLOBALS['options'][RKW_OPT]['document_contract']=$contract;$s=rkw_settings();set_transient(RKW_Client::COOKIE_TRANSIENT,['name'=>'sg-auth-sg','value'=>'synthetic-cookie','signature'=>RKW_Policy_Catalog::signature($s)],60);$GLOBALS['options'][RKW_Policy_Catalog::OPTION]['signature']=RKW_Policy_Catalog::signature($s);return RKW_Orders::send(method_order());}
function metadata_handler($u,$a){check($a['method']==='GET'&&!isset($a['body']));if(strpos($u,'getSettlementPolicies')!==false)return response(strpos($u,'applicabilityType=1')!==false?method_rows():[['settlementPolicyID'=>72,'settlementPolicyName'=>'سفارش','settlementMethodGroups'=>[['settlementMethods'=>[['settlementNatureKey'=>'Cash','settlementMethodName'=>'نقد سفارش']]]]]]);if(strpos($u,'getDefaultMobileDocumentPatternByType')!==false)return response(['id'=>7,'title'=>'الگو']);return response([]);}
$tests=[];
$tests['actual HTTP body matches supplied coupon document including null and false fields']=function(){
 method_reset();$s=rkw_settings();$s['inventory_id']=2;$s['invoice_doc_pattern_id']=1;$s['sales_area_ord']=0;$s['currency_id']=1;$s['coupon_sales_agent_id']=31;$GLOBALS['options'][RKW_OPT]=$s;
 set_transient(RKW_Client::COOKIE_TRANSIENT,['name'=>'sg-auth-sg','value'=>'synthetic-cookie','signature'=>RKW_Policy_Catalog::signature($s)],60);$GLOBALS['options'][RKW_Policy_Catalog::OPTION]['signature']=RKW_Policy_Catalog::signature($s);
 $o=order(5900000);$o->gateway='WC_Gateway_SnappPay';$o->meta['_rkw_customer_id']=55260;$o->items[0]->product->meta['_rahkaran_product_id']=229547;
 check(RKW_Orders::send($o)===true);$p=$GLOBALS['posted'][0];
 $item=['Id'=>0,'inventoryId'=>2,'settlementPolicyId'=>45,'productId'=>229547,'quantity'=>1,'unitId'=>1,'fee'=>59000000,'price'=>59000000,'policies'=>[],'toppings'=>[],'returnInvoicePermitItemId'=>null,'referenceId'=>null];
 for($i=1;$i<=5;$i++){foreach(['trackingFactor','partTrackingFactorRef','isTrackingFactorInputModeManual']as$prefix)$item[$prefix.$i]=null;$item[($i===3?'TrackingFactorHasQuantity':'trackingFactorHasQuantity').$i]=false;}
 $expected=['document'=>['description'=>RKW_Orders::invoice_description($o),'inventoryId'=>2,'salesAreaId'=>null,'salesAgentId'=>31,'documentPatternId'=>1,'documentType'=>1,'customerId'=>55260,'status'=>0,'currencyId'=>1,'items'=>[$item],'policies'=>[],'settlementPolicyId'=>45,'id'=>0,'data'=>['discountCards'=>[],'loyaltyProgramID'=>3]],'receipts'=>[['key'=>'ThirdPartyCoupon','amount'=>59000000,'attr'=>['ID'=>5,'CouponType'=>5,'Count'=>1]]],'payments'=>[]];
 check($p==$expected,'HTTP JSON differs from supplied sample');
 file_put_contents(__DIR__.'/../docs/exact-coupon-http-request.json',json_encode($p,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
};
$tests['coupon keeps full line price quantity and configurable agent without legacy projection']=function(){
 method_reset();$s=rkw_settings();$s['coupon_sales_agent_id']=44;$GLOBALS['options'][RKW_OPT]=$s;$o=method_order();$o->total=250;$o->items=[new TestItem(250,0,2,300)];
 check(RKW_Orders::send($o)===true);$p=$GLOBALS['posted'][0];check($p['document']['salesAgentId']===44);check($p['document']['items'][0]['quantity']===2);check($p['document']['items'][0]['price']===2500);check($p['receipts'][0]['amount']===2500);check($p['document']['data']['loyaltyProgramID']===3);check(!isset($p['document']['storeId'],$p['document']['loyaltyProgramId']));
};
$tests['Snapp sale policies use native condition data and verify the paid amount before saving']=function(){
 foreach ( [ true, false ] as $accepted ) {
  method_reset();
  $GLOBALS['options'][RKW_OPT]['item_discount_policy_id'] = 202;
  $GLOBALS['options'][RKW_OPT]['invoice_preflight'] = 0;
  $next = $GLOBALS['http_handler'];
  $preflight_calls = 0;
  $GLOBALS['http_handler'] = function ( $url, $args ) use ( $next, $accepted, &$preflight_calls ) {
   if ( ! str_ends_with( $url, '/calculateAmount' ) ) {
    if ( str_ends_with( $url, '/SaveInvoice' ) ) { check( $preflight_calls === 1 ); }
    return $next( $url, $args );
   }
   $doc = json_decode( $args['body'], true );
   if ( 0 === $doc['customerId'] ) {
    $id = $doc['items'][0]['productId'];
    $first = 174570 === $id;
    $discount = $first ? 15730000 : 12580000;
    return response( [ 'items' => [ [
     'productId' => $id, 'unitId' => 1, 'quantity' => 2, 'price' => $first ? 89900000 : 71900000,
     'netPrice' => $first ? 74170000 : 59320000,
     'policies' => [
      [ 'policyId' => 202, 'policyConditionId' => 207, 'policyConditionRowId' => 1179,
        'type' => 'Discount', 'effect' => 3, 'isReadOnly' => false, 'isIncluded' => false,
        'price' => 0, 'enforcement' => 2, 'definitiveness' => 2,
        'outputs' => [ [ 'type' => 3, 'numericValue' => [ 'isPercentageBased' => false,
          'value' => 0, 'canChangeValue' => true, 'valueChanged' => false ] ] ] ],
      [ 'policyId' => 507, 'type' => 'Discount', 'effect' => 3, 'isIncluded' => true, 'price' => $discount ],
     ],
    ] ] ] );
   }
   $preflight_calls++;
   check( $doc['status'] === 0 && $doc['settlementPolicyId'] === 45 && ! isset( $doc['storeId'] ) );
   foreach ( $doc['items'] as $index => $item ) {
    $manual = $item['policies'][1];
    check( $manual['policyId'] === 202 && $manual['effect'] === 3 && $manual['type'] === 'Discount' );
    check( $manual['policyConditionId'] === 207 && $manual['policyConditionRowId'] === 1179 && $manual['isIncluded'] );
    check( $manual['price'] === ( $index === 0 ? 15730000 : 12580000 ) );
    check( $manual['outputs'][0]['numericValue']['value'] === $manual['price'] );
    check( $manual['outputs'][0]['numericValue']['valueChanged'] === true );
   }
   return response( [ 'netPrice' => $accepted ? 105180000 : 133490000 ] );
  };
  $order = method_order();
  $order->total = 10518000;
  $order->items = [ new TestItem( 5844000, 0, 2 ), new TestItem( 4674000, 0, 2 ) ];
  foreach ( $order->items as $i => $line ) {
   $line->product = new class extends TestProduct {
    public function get_sale_price( $context = 'view' ) { return $this->meta['_rahkaran_product_id'] === 174570 ? '2922000' : '2337000'; }
    public function get_regular_price( $context = 'view' ) { return '4495000'; }
   };
   $line->product->meta['_rahkaran_product_id'] = $i === 0 ? 174570 : 174565;
  }
  $result = RKW_Orders::send( $order );
  if ( ! $accepted ) {
   expect_error( $result, 'rkw_server_total' );
   check( ! $GLOBALS['posted'] );
   continue;
  }
  check( $result === true && count( $GLOBALS['posted'] ) === 1 );
  check( $GLOBALS['posted'][0]['receipts'] === [ [ 'key' => 'ThirdPartyCoupon', 'amount' => 105180000,
   'attr' => [ 'ID' => 5, 'CouponType' => 5, 'Count' => 1 ] ] ] );
 }
};
$fail=0;foreach($tests as$name=>$test){try{$test();echo"PASS $name\n";}catch(Throwable $e){$fail++;echo"FAIL $name: ".$e->getMessage()." at ".$e->getLine()."\n";}}echo count($tests)." tests, $fail failed\n";exit($fail?1:0);
