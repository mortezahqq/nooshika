<?php
// WooCommerce/WordPress and HTTP boundary fixtures; no real orders or ERP access.
define('RKW_INVOICE_LAYOUT_FIXTURES_ONLY',true);require __DIR__.'/invoice-layout.php';
function get_current_user_id(){return $GLOBALS['manual_user']??1;}
class ManualDB extends FilterDB{function esc_like($v){return addcslashes($v,'_%\\');}}
class ManualDate extends DateTimeImmutable{function date($f){return$this->format($f);}}
class ManualOrder extends FilterOrder{
 public $billing=['first_name'=>'مشتری','last_name'=>'نمونه','phone'=>'09120000000','city'=>'تهران','address_1'=>'نشانی آزمایشی','postcode'=>'1111111111'],$shipping_address=[];
 function get_currency(){return'IRT';}function get_billing_first_name(){return$this->billing['first_name']??'';}function get_billing_last_name(){return$this->billing['last_name']??'';}function get_billing_phone(){return$this->billing['phone']??'';}function get_address($type='billing'){return$type==='shipping'?$this->shipping_address:$this->billing;}
}
function manual_reset(){layout_reset();$GLOBALS['wpdb']=new ManualDB;$GLOBALS['test_capability']=true;$GLOBALS['test_nonce']=true;$GLOBALS['manual_user']=1;$o=new ManualOrder;$o->id=237743;$o->total=100;$o->items=[new TestItem(100)];$o->created=new ManualDate('2026-10-25 12:00:00',wp_timezone());$GLOBALS['test_orders']=[$o->id=>$o];$GLOBALS['local_orders']=[$o];$GLOBALS['options'][RKW_OPT]['document_contract']='legacy_esales';set_transient(RKW_Client::COOKIE_TRANSIENT,['name'=>'sg-auth-sg','value'=>'synthetic','signature'=>RKW_Policy_Catalog::signature()],60);$GLOBALS['http_handler']=function($u,$a){if(strpos($u,'/CashierLogin')!==false)return['code'=>200,'body'=>'[]'];if(strpos($u,'calculateAmount')!==false)return response(['netPrice'=>1000]);check(strpos($u,'/ESales.svc/invoice')!==false);return response(['id'=>123300]);};$_POST=[];return$o;}
function manual_json($fn){try{$fn();}catch(TestJSON$r){return$r;}throw new RuntimeException('JSON response expected');}
function manual_writes(){return array_values(array_filter($GLOBALS['http_calls'],fn($c)=>strpos($c[0],'/ESales.svc/invoice')!==false||strpos($c[0],'/SaveInvoice')!==false));}
if(($argv[1]??'')==='html-invoice'){manual_reset();RKW_Modules::page();exit;}
if(($argv[1]??'')==='html'){manual_reset();RKW_Manual_Orders::page();exit;}
if(($argv[1]??'')==='fixture'){$o=manual_reset();echo json_encode(['row'=>RKW_Manual_Orders::row($o),'preview'=>RKW_Manual_Orders::preview($o)]);exit;}
if(($argv[1]??'')==='sql'){manual_reset();$GLOBALS['registered_statuses']['wc-packed']='بسته بندی شده';TestOrderUtil::$hpos=($argv[2]??'')==='hpos';$GLOBALS['wpdb']->total=100;$GLOBALS['wpdb']->ids=[1];RKW_Manual_Orders::search($argv[3]??'',$argv[4]??'any',$argv[5]??'all',(int)($argv[6]??1));echo json_encode($GLOBALS['wpdb']->queries);exit;}
$tests=[];
$tests['manual preview displays the complete current order without saving an order customer or invoice']=function(){
 $o=$GLOBALS['test_orders'][237743];$before=$o->meta;$r=RKW_Manual_Orders::preview($o);check($r['can_submit']&&$r['token']);check($r['buyer']==='مشتری نمونه'&&$r['address']['postcode']==='1111111111');check($r['items'][0]['product_id']===30&&$r['items'][0]['quantity']===1.0);check($r['amounts']['woo_order_total']===1000.0);check($r['payment']['key']==='EReceipt');check($o->meta===$before);check(!$GLOBALS['http_calls']);
};
$tests['explicitly reviewed submission uses the shared legacy sender and records the software ID once']=function(){
 $o=$GLOBALS['test_orders'][237743];$p=RKW_Manual_Orders::preview($o);$r=RKW_Manual_Orders::submit($o,$p['token']);check($r['status']==='sent');check($o->get_meta('_rkw_doc_id')==='123300');check(count(manual_writes())===1);$again=RKW_Manual_Orders::submit($o,$p['token']);check($again['status']==='already_sent');check(count(manual_writes())===1);check(strpos($r['document'],'123300')!==false);
};
$tests['a first customer can be previewed with no invented customer ID and is created only after submit']=function(){
 $o=$GLOBALS['test_orders'][237743];$o->meta=[];$GLOBALS['options'][RKW_OPT]['fida_fallback']=1;$p=RKW_Manual_Orders::preview($o);check($p['can_submit']&&$p['customer_id']===0);check($p['warnings']);check(!$GLOBALS['http_calls']);$draft=RKW_Orders::preview_manual_payload($o);check(!isset($draft['document']['customerId']));check(!$GLOBALS['http_calls']);
 $GLOBALS['http_handler']=function($u,$a){if(strpos($u,'/CashierLogin')!==false)return['code'=>200,'body'=>'[]'];if(strpos($u,'CustomerService.svc/customer')!==false)return$a['method']==='GET'?response([]):response(['Id'=>88]);check(json_decode($a['body'],true)['document']['customerId']===88);return response(['id'=>123301]);};$r=RKW_Manual_Orders::submit($o,$p['token']);check($r['status']==='sent');check($o->get_meta('_rkw_customer_id')===88);check(count(manual_writes())===1);
};
$tests['all previous financial strict validation still rejects an absent customer ID outside manual preview']=function(){
 $o=$GLOBALS['test_orders'][237743];$o->meta=[];expect_error(RKW_Orders::preview_invoice_payload($o),'rkw_probe_customer');$draft=RKW_Orders::preview_manual_payload($o);expect_error(RKW_Orders::validate_invoice_payload($draft),'rkw_invoice_payload');check(!$GLOBALS['http_calls']);
};
$tests['sent pending cancelled failed unpaid custom and zero orders cannot receive a submit token']=function(){
 foreach(['sent','pending','cancelled','failed','packed','zero']as$type){$o=manual_reset();if($type==='sent')$o->meta['_rkw_doc_id']='77';elseif($type==='pending')$o->meta['_rkw_reconcile_required']=1;elseif($type==='zero')$o->total=0;else$o->status=$type;$p=RKW_Manual_Orders::preview($o);check(!$p['can_submit']&&$p['token']==='');check($p['issues']);check(!$GLOBALS['http_calls']);}
};
$tests['missing product and invalid payment mappings return actionable issues and no writes']=function(){
 $o=$GLOBALS['test_orders'][237743];$o->items[0]->product->meta=[];$p=RKW_Manual_Orders::preview($o);check(!$p['can_submit']);check(strpos(implode(' ',$p['issues']),'شناسه')!==false);check(!$GLOBALS['http_calls']);
 $o=manual_reset();$GLOBALS['options'][RKW_OPT]['payment_rules']=[['gateway'=>'test_bank','settlement_id'=>5],['gateway'=>'test_bank','settlement_id'=>6]];$p=RKW_Manual_Orders::preview($o);check(!$p['can_submit']);check(!$GLOBALS['http_calls']);
};
$tests['order product address gateway national code and settings changes require a new preview']=function(){
 foreach(['total','product','address','gateway','national','settings','shipping']as$change){$o=manual_reset();$GLOBALS['options'][RKW_OPT]['national_key']='_national';$o->meta['_national']='1111111111';$p=RKW_Manual_Orders::preview($o);if($change==='total')$o->total=101;elseif($change==='product')$o->items[0]->product->meta['_rahkaran_product_id']=31;elseif($change==='address')$o->billing['address_1']='نشانی تغییرکرده';elseif($change==='gateway')$o->gateway='different';elseif($change==='national')$o->meta['_national']='2222222222';elseif($change==='shipping')$GLOBALS['options'][RKW_Extensions::OPTION]['shipping_policy_id']=99;else$GLOBALS['options'][RKW_OPT]['bank_account_ref']=80;$r=RKW_Manual_Orders::submit($o,$p['token']);check($r['status']==='error');check(strpos($r['message'],'تغییر')!==false);check(!manual_writes());check(get_option('rkw_order_lock_'.$o->id,false)===false);}
};
$tests['preview tokens belong to the reviewing user and expire without an invoice POST']=function(){
 $o=$GLOBALS['test_orders'][237743];$p=RKW_Manual_Orders::preview($o);$GLOBALS['manual_user']=2;$r=RKW_Manual_Orders::submit($o,$p['token']);check($r['status']==='error');check(!manual_writes());$GLOBALS['manual_user']=1;delete_transient('rkw_manual_1_'.$o->id);$r=RKW_Manual_Orders::submit($o,$p['token']);check($r['status']==='error');check(!manual_writes());
};
$tests['a failed financial attempt consumes its preview and cannot silently retry']=function(){
 $o=$GLOBALS['test_orders'][237743];$GLOBALS['http_handler']=with_legacy_cashier(fn($u,$a)=>response([],false,'Sequence contains no elements'));$p=RKW_Manual_Orders::preview($o);$r=RKW_Manual_Orders::submit($o,$p['token']);check($r['status']==='error');check(count(manual_writes())===1);$again=RKW_Manual_Orders::submit($o,$p['token']);check($again['status']==='error');check(count(manual_writes())===1);
};
$tests['a timeout remains pending and cannot be sent a second time']=function(){
 $o=$GLOBALS['test_orders'][237743];$GLOBALS['http_handler']=with_legacy_cashier(fn($u,$a)=>new WP_Error('http_request_failed','synthetic timeout'));$p=RKW_Manual_Orders::preview($o);$r=RKW_Manual_Orders::submit($o,$p['token']);check($r['status']==='pending');check($o->get_meta('_rkw_reconcile_required')===1);RKW_Manual_Orders::submit($o,$p['token']);check(count(manual_writes())===1);
};
$tests['automatic confirmation or a new legacy queue after preview prevents a manual duplicate']=function(){
 foreach(['automatic','legacy']as$source){$o=manual_reset();$p=RKW_Manual_Orders::preview($o);if($source==='automatic')$o->meta['_rkw_doc_id']='900';else$GLOBALS['wpdb']->records=[['ID'=>9,'invoice_id'=>'']];$r=RKW_Manual_Orders::submit($o,$p['token']);check($r['status']===($source==='automatic'?'already_sent':'pending'));check(!manual_writes());}
};
$tests['the shared per-order lock protects submit without consuming a preview owned by a running request']=function(){
 $o=$GLOBALS['test_orders'][237743];$p=RKW_Manual_Orders::preview($o);add_option('rkw_order_lock_'.$o->id,['started'=>time()]);$r=RKW_Manual_Orders::submit($o,$p['token']);check($r['status']==='error');check(get_option('rkw_order_lock_'.$o->id)['started']);check(get_transient('rkw_manual_1_'.$o->id)['token']===$p['token']);check(!manual_writes());
};
$tests['capability nonce and reviewed confirmation are enforced by the real AJAX endpoints']=function(){
 foreach(['test_nonce','test_capability']as$flag){manual_reset();$GLOBALS[$flag]=false;$_POST=['order_id'=>237743];check(!manual_json(fn()=>RKW_Manual_Orders::ajax_search())->success);check(!manual_json(fn()=>RKW_Manual_Orders::ajax_preview())->success);check(!manual_json(fn()=>RKW_Manual_Orders::ajax_submit())->success);check(!$GLOBALS['http_calls']);}
 manual_reset();$_POST=['order_id'=>237743];check(!manual_json(fn()=>RKW_Manual_Orders::ajax_submit())->success);check(!$GLOBALS['http_calls']);
};
$tests['search accepts Persian numbers and normalizes Arabic letters without accepting malformed input']=function(){
 check(RKW_Manual_Orders::normalize_search(' #۲۳۷۷۴۳ ')==='237743');check(RKW_Manual_Orders::normalize_search('علي  كريمي')==='علی کریمی');expect_error(RKW_Manual_Orders::normalize_search(['x']),'rkw_manual_search');expect_error(RKW_Manual_Orders::normalize_search(str_repeat('a',81)),'rkw_manual_search');expect_error(RKW_Manual_Orders::normalize_search('ع'),'rkw_manual_search');check(!$GLOBALS['http_calls']);
};
$tests['classic and HPOS searches constrain count and page before hydration and never use shipping addresses']=function(){
 foreach([false,true]as$hpos){manual_reset();TestOrderUtil::$hpos=$hpos;$GLOBALS['wpdb']->total=26;$GLOBALS['wpdb']->ids=[237743];$r=RKW_Manual_Orders::search('مشتری نمونه','buyer','all',2);check($r['total']===26&&$r['page']===2&&$r['pages']===2);$sql=implode(' ',$GLOBALS['wpdb']->queries);check(strpos($sql,'LIMIT 25 OFFSET 25')!==false);check(strpos($sql,$hpos?'wc_order_addresses':'_billing_first_name')!==false);if($hpos)check(strpos($sql,"address_type='billing'")!==false);check(strpos($GLOBALS['order_queries'][0]['include'][0]??'', '237743')!==false);check(!$GLOBALS['http_calls']);}
};
$tests['order number search includes internal IDs and formatted numbers without approximate ID matching']=function(){
 $sql=RKW_Manual_Orders::search_where('237743','number',false);check(strpos($sql,'o.ID=237743')!==false);check(strpos($sql,"sn.meta_value='237743'")!==false);check(strpos($sql,'LIKE')===false);check(strpos($sql,'_order_number_formatted')!==false);
};
$tests['a valid locally mapped customer is resolved in preview without creating a party']=function(){
 $o=$GLOBALS['test_orders'][237743];$o->meta=[];$o->uid=9;$GLOBALS['usermeta'][9]['_rahkaran_customer_id']=88;$p=RKW_Manual_Orders::preview($o);check($p['can_submit']&&$p['customer_id']===88);check(!$GLOBALS['http_calls']);check(!$o->get_meta('_rkw_customer_id'));
};
$tests['incomplete default customer settings and missing buyer name remain review-only']=function(){
 $o=$GLOBALS['test_orders'][237743];$GLOBALS['options'][RKW_OPT]['customer_mode']='default';$GLOBALS['options'][RKW_OPT]['fallback_cust']=0;$p=RKW_Manual_Orders::preview($o);check(!$p['can_submit']);$o=manual_reset();$o->meta=[];$o->billing['first_name']='';$o->billing['last_name']='';$p=RKW_Manual_Orders::preview($o);check(!$p['can_submit']);check(!$GLOBALS['http_calls']);
};
$tests['manual flow still supports native invoice calculations and the configured sales order mode']=function(){
 foreach(['v21','legacy_esales']as$contract){$o=manual_reset();$GLOBALS['options'][RKW_OPT]['document_contract']=$contract;$GLOBALS['options'][RKW_OPT]['order_mode']=$contract==='v21'?'invoice':'salesorder';set_transient(RKW_Client::COOKIE_TRANSIENT,['name'=>'sg-auth-sg','value'=>'synthetic','signature'=>RKW_Policy_Catalog::signature()],60);$GLOBALS['http_handler']=with_legacy_cashier(function($u,$a)use($contract){if(strpos($u,'calculateAmount')!==false)return response(['netPrice'=>1000]);check(strpos($u,$contract==='v21'?'/SaveInvoice':'/salesOrder')!==false);return response(['id'=>901]);});$p=RKW_Manual_Orders::preview($o);check($p['can_submit']);$r=RKW_Manual_Orders::submit($o,$p['token']);check($r['status']==='sent');}
};
$tests['default-customer preview and the final invoice use the same configured customer instead of stale order metadata']=function(){
 $o=$GLOBALS['test_orders'][237743];$GLOBALS['options'][RKW_OPT]['customer_mode']='default';$GLOBALS['options'][RKW_OPT]['fallback_cust']=99;$p=RKW_Manual_Orders::preview($o);check($p['can_submit']&&$p['customer_id']===99);$GLOBALS['http_handler']=with_legacy_cashier(function($u,$a){check(json_decode($a['body'],true)['document']['customerId']===99);return response(['id'=>900]);});$r=RKW_Manual_Orders::submit($o,$p['token']);check($r['status']==='sent');
};
$tests['the submit endpoint ignores forged amounts customer IDs and gateway overrides']=function(){
 $o=$GLOBALS['test_orders'][237743];$p=RKW_Manual_Orders::preview($o);$GLOBALS['http_handler']=with_legacy_cashier(function($u,$a){$w=json_decode($a['body'],true);check($w['document']['customerId']===45);check($w['payments'][0]['amount']===1000);check($w['payments'][0]['key']==='EReceipt');return response(['id'=>905]);});$_POST=['order_id'=>237743,'token'=>$p['token'],'confirm'=>'1','amount'=>0,'customer_id'=>999,'gateway'=>'cod'];$r=manual_json(fn()=>RKW_Manual_Orders::ajax_submit());check($r->success&&$r->data['status']==='sent');check(count(manual_writes())===1);
};
$tests['direct code accepts Persian digits and hash but resolves only the exact internal Woo ID']=function(){
 $o=RKW_Manual_Orders::order_by_code(' #۲۳۷۷۴۳ ');check($o===$GLOBALS['test_orders'][237743]);check(!$GLOBALS['http_calls']);
};
$tests['invalid zero negative malformed and missing direct codes never post a document']=function(){
 foreach(['', '0','-237743','237743.0','237743 or 1=1',[],str_repeat('9',30)]as$code)check(is_wp_error(RKW_Manual_Orders::register_code($code)));expect_error(RKW_Manual_Orders::order_by_code('999999'),'rkw_manual_code_missing');check(!$GLOBALS['http_calls']);
};
$tests['direct registration needs no prior browser lookup and returns the document ID in one operation']=function(){
 $r=RKW_Manual_Orders::register_code('۲۳۷۷۴۳');check($r['status']==='sent');check(strpos($r['document'],'123300')!==false);check(count(manual_writes())===1);check($r['details']['id']===237743);check(!isset($r['details']['token']));
};
$tests['the optional code lookup creates no party invoice or submit token']=function(){
 $o=$GLOBALS['test_orders'][237743];$o->meta=[];$GLOBALS['options'][RKW_OPT]['fida_fallback']=1;$p=RKW_Manual_Orders::lookup_code('237743');check($p['can_submit']);check(!isset($p['token']));check(!$GLOBALS['http_calls']);check(get_transient('rkw_manual_1_237743')===false);
};
$tests['sent uncertain failed and cancelled codes cannot bypass existing submission safeguards']=function(){
 foreach(['sent','pending','failed','cancelled']as$state){$o=manual_reset();if($state==='sent')$o->meta['_rkw_doc_id']='900';elseif($state==='pending')$o->meta['_rkw_reconcile_required']=1;else$o->status=$state;$r=RKW_Manual_Orders::register_code('237743');check($r['status']===$state||$r['status']==='already_sent'||$r['status']==='error');check(!manual_writes());}
};
$tests['direct AJAX enforces permission nonce and the explicit register button flag']=function(){
 foreach(['test_nonce','test_capability']as$flag){manual_reset();$GLOBALS[$flag]=false;$_POST=['code'=>'237743','confirm'=>'1'];check(!manual_json(fn()=>RKW_Manual_Orders::ajax_lookup_code())->success);check(!manual_json(fn()=>RKW_Manual_Orders::ajax_register_code())->success);check(!$GLOBALS['http_calls']);}
 manual_reset();$_POST=['code'=>'237743'];check(!manual_json(fn()=>RKW_Manual_Orders::ajax_register_code())->success);check(!$GLOBALS['http_calls']);
};
$tests['direct AJAX uses the code and authoritative order data rather than forged financial fields']=function(){
 $GLOBALS['http_handler']=with_legacy_cashier(function($u,$a){$w=json_decode($a['body'],true);check($w['document']['customerId']===45);check($w['payments'][0]['amount']===1000);return response(['id'=>906]);});$_POST=['code'=>'237743','confirm'=>'1','order_id'=>999,'customer_id'=>999,'amount'=>0];$r=manual_json(fn()=>RKW_Manual_Orders::ajax_register_code());check($r->success&&$r->data['status']==='sent'&&$r->data['id']===237743);check(count(manual_writes())===1);
};
$tests['a lost direct-registration response preserves the block against a second invoice']=function(){
 $GLOBALS['http_handler']=with_legacy_cashier(fn($u,$a)=>new WP_Error('http_request_failed','synthetic timeout'));$r=RKW_Manual_Orders::register_code('237743');check($r['status']==='pending');$again=RKW_Manual_Orders::register_code('237743');check($again['status']==='pending');check(count(manual_writes())===1);
};
$tests['the direct code form is embedded once above the existing sales-invoice order list']=function(){
 $h=layout_html();check(substr_count($h,'id="rkw-manual-code-form"')===1);check(strpos($h,'id="rkw-manual-code-form"')<strpos($h,'rkwm-local-orders'));check(strpos($h,'rkwm-local-orders')<strpos($h,'id="rkwm-remote-invoices"'));check(strpos($h,'id="rkw-manual-rows"')===false);check(!$GLOBALS['http_calls']);
};
$fail=0;foreach($tests as$name=>$test){manual_reset();try{$test();echo 'PASS '.$name."\n";}catch(Throwable$e){$fail++;echo 'FAIL '.$name.': '.$e->getMessage().' at '.$e->getLine()."\n";}}
echo count($tests).' tests, '.$fail." failed\n";exit($fail?1:0);
