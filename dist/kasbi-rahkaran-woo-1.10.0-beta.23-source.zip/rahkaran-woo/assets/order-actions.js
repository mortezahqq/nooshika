/* global rkwOrderActions */
(function () {
  'use strict';
  if (typeof rkwOrderActions === 'undefined') return;
  const feedback = document.getElementById('rkw-local-send-status');
  const busy = new Set();
  function message(text, error, warning) {
    if (feedback) { feedback.textContent = text; feedback.className = 'rkw-send-feedback ' + (error ? 'rkw-send-error' : (warning ? 'rkw-send-warning' : 'rkw-send-ok')); }
    else {
      let top = document.getElementById('rkw-send-result-top');
      if (!top) {
        top = document.createElement('div'); top.id = 'rkw-send-result-top';
        top.setAttribute('role', 'status');
        const wrap = document.querySelector('.wrap') || document.body;
        wrap.prepend(top);
      }
      top.textContent = text;
      top.className = 'notice ' + (error ? 'notice-error' : (warning ? 'notice-warning' : 'notice-info'));
    }
  }
  function updateRow(item) {
    const id = String(item.id);
    const row = document.querySelector('.rkw-bulk-table tr[data-order-id="' + id + '"]');
    const doc = document.querySelectorAll('.rkw-order-doc[data-order="' + id + '"]');
    const actions = document.querySelectorAll('.rkw-order-actions[data-order="' + id + '"]');
    const confirmed = item.status === 'sent' || (item.status === 'skipped' && !!item.document);
    if (confirmed || item.status === 'blocked') {
      doc.forEach(el => { el.textContent = confirmed ? (item.document || 'ثبت‌شده') : 'نیازمند تطبیق'; });
      actions.forEach(el => {
        el.textContent = confirmed ? (item.document || 'ثبت‌شده') : 'نیازمند بررسی در راهکاران';
        el.classList.add(confirmed ? 'rkw-order-sent' : 'rkw-order-pending');
        if (!confirmed) {
          const button = document.createElement('button'); button.type = 'button';
          button.className = 'button button-small rkw-check-one'; button.dataset.order = id;
          button.textContent = 'بررسی وضعیت در راهکاران'; el.appendChild(button);
          const existing = document.createElement('button'); existing.type = 'button'; existing.className = 'button button-small rkw-existing-open'; existing.dataset.order = id; existing.textContent = 'انتخاب فاکتور موجود'; el.appendChild(existing);
        }
      });
      if (row && confirmed) { const checkbox = row.querySelector('.rkw-order-check'); if (checkbox) checkbox.remove(); }
      if (row && confirmed && row.closest('.rkwm-local-orders[data-rkw-order-filter="unsent"]')) {
        const body = row.parentElement;
        row.remove();
        if (!body.querySelector('tr')) {
          const empty = document.createElement('tr'); const cell = document.createElement('td');
          cell.colSpan = 9; cell.textContent = 'سفارش دیگری در این صفحه باقی نمانده است؛ فهرست را به‌روزرسانی کنید.';
          empty.appendChild(cell); body.appendChild(empty);
        }
      }
    }
    if (row) {
      const result = row.querySelector('.rkw-last-result');
      if (result) { result.textContent = item.message; result.classList.toggle('rkw-row-error', item.status !== 'sent' && item.status !== 'skipped'); }
    }
  }
  async function send(ids) {
    const selected = [...new Set(ids.map(Number).filter(v => Number.isSafeInteger(v) && v > 0))];
    if (!selected.length) { message('ابتدا سفارش‌های قابل ارسال را انتخاب کنید.', true); return; }
    if (selected.length > 25) { message('در هر نوبت حداکثر ۲۵ سفارش قابل ارسال است.', true); return; }
    const label = selected.length === 1 ? 'سفارش #' + selected[0] : selected.length + ' سفارش';
    if (!window.confirm('ارسال ' + label + ' به راهکاران؟ اسناد ثبت‌شده و نتایج نامشخص دوباره ارسال نمی‌شوند. تا پایان عملیات صفحه را باز نگه دارید.')) return;
    if (busy.size) return;
    selected.forEach(id => busy.add(id));
    const controls = document.querySelectorAll('.rkw-send-one, .rkw-send-bulk, .rkw-check-one, .rkw-check-bulk');
    controls.forEach(button => button.disabled = true);
    let sent = 0; let finished = 0; let interrupted = false;
    const issues = [];
    // One request per invoice prevents a long PHP timeout and preserves the
    // result of earlier orders even if a later call is interrupted.
    for (const id of selected) {
      message('در حال ارسال سفارش ' + (finished + 1) + ' از ' + selected.length + ' (شناسه ' + id + ')…', false);
      try {
        const data = new URLSearchParams({ action: 'rkw_send_selected_orders', nonce: rkwOrderActions.nonce });
        data.append('order_ids[]', String(id));
        const response = await fetch(rkwOrderActions.ajax, {
          method: 'POST', credentials: 'same-origin',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
          body: data.toString()
        });
        const json = await response.json();
        if (!response.ok || !json.success) throw new Error(json && json.data && json.data.message ? json.data.message : 'خطا در درخواست.');
        const report = json.data.items || [];
        report.forEach(item => {
          updateRow(item);
          if (item.status === 'sent') sent++;
          else issues.push('#' + item.id + ': ' + item.message);
        });
        finished++;
      } catch (error) {
        issues.push('#' + id + ': نتیجه درخواست نامشخص است (' + error.message + ')');
        interrupted = true;
        break; // Never retry an uncertain POST without verifying Rahkaran.
      }
    }
    const summary = 'ارسال ' + finished + ' از ' + selected.length + ' سفارش بررسی شد؛ ' + sent + ' مورد ثبت شد.';
    message(summary + (interrupted ? ' ارسال گروه متوقف شد؛ نتیجه سفارش بعدی را در راهکاران بررسی کنید.' : '') + (issues.length ? ' ' + issues.slice(0, 5).join(' | ') : ''), interrupted || issues.length > 0);
    selected.forEach(id => busy.delete(id));
    controls.forEach(button => { if (button.isConnected) button.disabled = false; });
  }
  async function request(action, fields) {
    const data = new URLSearchParams({action, nonce: rkwOrderActions.nonce, ...fields});
    const response = await fetch(rkwOrderActions.ajax, {
      method: 'POST', credentials: 'same-origin',
      headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}, body: data.toString()
    });
    const json = await response.json();
    if (!response.ok || !json.success) {
      const error = new Error(json && json.data && json.data.message ? json.data.message : 'نتیجه درخواست قابل خواندن نیست.');
      error.report = json && json.data && typeof json.data.report === 'string' ? json.data.report : '';
      throw error;
    }
    return json.data;
  }
  async function existingInvoice(orderId) {
    if (busy.size) return;
    const id = Number(orderId); if (!Number.isSafeInteger(id) || id <= 0) return;
    busy.add(id);
    const dialog = document.createElement('dialog'); dialog.className = 'rkw-existing-modal'; dialog.dir = 'rtl';
    const heading = document.createElement('h2'); heading.textContent = 'اتصال فاکتور موجود به سفارش #' + id;
    const help = document.createElement('p'); help.textContent = 'فاکتور ثبت‌شده را از فهرست همین پنجره انتخاب کنید. اتصال فقط پس از بررسی مشتری، مبلغ، ارز، کالاها و تعداد انجام می‌شود؛ سند تازه‌ای صادر نمی‌شود.';
    const close = document.createElement('button'); close.type = 'button'; close.className = 'button'; close.textContent = 'بستن'; close.onclick = () => dialog.close();
    const status = document.createElement('p'); status.setAttribute('role', 'status');
    const input = document.createElement('input'); input.type = 'number'; input.min = '1'; input.placeholder = 'شناسه داخلی فاکتور راهکاران'; input.setAttribute('aria-label', 'شناسه داخلی فاکتور راهکاران');
    const prepareButton = document.createElement('button'); prepareButton.type = 'button'; prepareButton.className = 'button'; prepareButton.textContent = 'بررسی این شناسه';
    const list = document.createElement('div'); list.className = 'rkw-existing-list';
    const previous = document.createElement('button'), next = document.createElement('button');
    [previous, next].forEach(b => { b.type = 'button'; b.className = 'button'; }); previous.textContent = 'صفحه قبل'; next.textContent = 'صفحه بعد';
    const preview = document.createElement('p'); preview.className = 'rkw-existing-preview'; preview.hidden = true;
    const attach = document.createElement('button'); attach.type = 'button'; attach.className = 'button button-primary'; attach.textContent = 'تأیید اتصال همین فاکتور'; attach.hidden = true;
    dialog.append(heading, close, help, input, prepareButton, status, list, previous, next, preview, attach); document.body.appendChild(dialog);
    let page = 1, token = '', working = false;
    function resetPreview() { token = ''; preview.hidden = true; attach.hidden = true; }
    input.addEventListener('input', resetPreview);
    dialog.addEventListener('close', () => { busy.delete(id); dialog.remove(); });
    async function load(target) {
      if (working) return; working = true; resetPreview(); status.textContent = 'دریافت فهرست راهکاران…'; previous.disabled = next.disabled = true;
      try {
        const data = await request('rkw_existing_invoice_list', {order_id: String(id), page: String(target)});
        page = data.page; list.replaceChildren();
        (data.rows || []).forEach(row => {
          const line = document.createElement('p'); const label = document.createElement('span');
          label.textContent = 'شناسه #' + row.id + ' | شماره سند: ' + (row.number || '—') + ' | مبلغ: ' + (row.amount === null ? 'نامشخص' : row.amount) + ' | تاریخ: ' + (row.date || '—') + ' ';
          const choose = document.createElement('button'); choose.type = 'button'; choose.className = 'button'; choose.textContent = 'بررسی و انتخاب';
          choose.onclick = () => { input.value = String(row.id); prepare(); }; line.append(label, choose); list.appendChild(line);
        });
        status.textContent = 'صفحه ' + page + '؛ ' + data.scanned + ' سرآیند خوانده شد. موارد سازگار با مبلغ و مشتری سفارش نمایش داده می‌شوند.' + ((data.rows || []).length ? '' : ' موردی در این صفحه نیست؛ در صورت وجود، صفحه بعد را بررسی کنید.');
        previous.disabled = page <= 1; next.disabled = !data.has_next;
      } catch (error) { status.textContent = error.message; }
      finally { working = false; }
    }
    async function prepare() {
      if (working || !/^[1-9][0-9]*$/.test(input.value)) return;
      working = true; resetPreview(); prepareButton.disabled = true; status.textContent = 'بررسی جزئیات فاکتور موجود…';
      try {
        const p = await request('rkw_existing_invoice_prepare', {order_id: String(id), invoice_id: input.value});
        token = p.token;
        preview.textContent = 'فاکتور #' + p.invoice_id + ' | شماره سند: ' + (p.number || '—') + ' | تاریخ: ' + (p.date || '—') + ' | مبلغ: ' + p.amount + ' | تعداد ردیف‌ها: ' + p.item_count + '. مشتری، مبلغ، ارز، کالاها و تعداد برابرند. ' + (p.has_order_reference ? 'شماره سفارش در توضیحات هم تأیید شد.' : 'شماره سفارش در توضیحات تأیید نشده؛ برای سفارش‌های مشابه، شماره و تاریخ فاکتور را پیش از تأیید انتخاب بررسی کنید.');
        preview.hidden = false; attach.hidden = false; status.textContent = 'پیش‌نمایش آماده است؛ هنوز اتصال ذخیره نشده است.';
      } catch (error) { status.textContent = error.message; }
      finally { working = false; prepareButton.disabled = false; }
    }
    prepareButton.onclick = prepare; previous.onclick = () => load(page - 1); next.onclick = () => load(page + 1);
    attach.onclick = async () => {
      if (working || !token) return; working = true; attach.disabled = true;
      try {
        const result = await request('rkw_existing_invoice_attach', {order_id: String(id), token, confirm: '1'});
        updateRow({id, status: 'skipped', document: result.document, message: result.message}); message(result.message, false); dialog.close();
      } catch (error) { status.textContent = error.message; resetPreview(); }
      finally { working = false; attach.disabled = false; }
    };
    dialog.showModal(); await load(1);
  }
  function showReport(id, text, open) {
    if (!text) return;
    let details = document.querySelector('details[data-rkw-report-order="' + id + '"]');
    if (!details) {
      details = document.createElement('details'); details.className = 'rkw-check-report'; details.dataset.rkwReportOrder = String(id);
      const summary = document.createElement('summary'); summary.textContent = 'گزارش بررسی سفارش #' + id;
      const copy = document.createElement('button'); copy.type = 'button'; copy.className = 'button rkw-copy-check-report'; copy.textContent = 'کپی گزارش';
      const pre = document.createElement('pre'); pre.dir = 'rtl';
      details.append(summary, copy, pre);
      const row = document.querySelector('.rkw-bulk-table tr[data-order-id="' + id + '"]');
      if (row) {
        const reportRow = document.createElement('tr'); reportRow.className = 'rkw-check-report-row';
        const cell = document.createElement('td'); cell.colSpan = row.cells.length; cell.appendChild(details); reportRow.appendChild(cell); row.after(reportRow);
      } else {
        let holder = document.getElementById('rkw-check-reports');
        if (!holder) { holder = document.createElement('div'); holder.id = 'rkw-check-reports'; (document.querySelector('.wrap') || document.body).appendChild(holder); }
        holder.appendChild(details);
      }
    }
    details.querySelector('pre').textContent = text; details.open = !!open;
  }
  async function checkOrders(ids, allowSend) {
    if (busy.size) return;
    const selected = [...new Set(ids.map(Number).filter(v => Number.isSafeInteger(v) && v > 0))];
    if (!selected.length || selected.length > 25) { message('بین یک تا ۲۵ سفارش را برای بررسی انتخاب کنید.', true); return; }
    if (allowSend && !window.confirm('ابتدا وضعیت سفارش‌های انتخاب‌شده در راهکاران بررسی می‌شود. فاکتور پیدا‌شده به سفارش وصل می‌شود؛ فقط موارد بدون سابقه ارسال نامشخص از مسیر معمول ارسال می‌شوند. سفارش نیازمند بررسی با جست‌وجوی ناموفق دوباره ارسال نمی‌شود. ادامه می‌دهید؟')) return;
    selected.forEach(id => busy.add(id));
    const controls = document.querySelectorAll('.rkw-send-one, .rkw-send-bulk, .rkw-check-one, .rkw-check-bulk');
    controls.forEach(button => button.disabled = true);
    let confirmed = 0, sent = 0, unresolved = 0, checked = 0, failed = 0;
    const issues = [];
    for (const id of selected) {
      let submitting = false;
      let checkReport = '';
      try {
        let token = '', result;
        do {
          result = await request('rkw_check_order', {order_id: String(id), token, allow_send: allowSend ? '1' : '0'});
          message('سفارش #' + id + ' — ' + result.message, false);
          if (!result.done) {
            if (!result.token) throw new Error('شناسه ادامه بررسی در پاسخ موجود نیست.');
            token = result.token;
          }
        } while (!result.done);
        checkReport = typeof result.report === 'string' ? result.report : '';
        checked++;
        if (result.status === 'confirmed' && result.document) {
          confirmed++; updateRow({id, status: 'skipped', document: result.document, message: result.message});
        } else if (result.status === 'ready' && allowSend) {
          submitting = true;
          const report = await request('rkw_send_selected_orders', {'order_ids[]': String(id)});
          if (!Array.isArray(report.items) || report.items.length !== 1 || Number(report.items[0].id) !== id) throw new Error('پاسخ ارسال با سفارش تطابق ندارد.');
          const item = report.items[0]; updateRow(item);
          if (item.status === 'sent') sent++;
          else if (item.status === 'skipped' && item.document) confirmed++;
          else { unresolved++; if (item.status === 'error') failed++; issues.push('#' + id + ': ' + item.message); }
        } else {
          unresolved++; issues.push('#' + id + ': ' + result.message);
          updateRow({id, status: 'blocked', message: result.message});
        }
        showReport(id, checkReport, result.status !== 'confirmed');
      } catch (error) {
        unresolved++; failed++; issues.push('#' + id + ': ' + error.message);
        showReport(id, error.report || (checkReport ? checkReport + '\nنتیجه مرحله ارسال: ' + error.message : ''), true);
        if (submitting) {
          updateRow({id, status: 'blocked', message: 'نتیجه ارسال نامشخص است؛ پیش از تلاش دوباره تطبیق دهید.'});
          issues.push('ادامه گروه متوقف شد؛ ارسال نامشخص خودکار تکرار نمی‌شود.'); break;
        }
        const row = document.querySelector('.rkw-bulk-table tr[data-order-id="' + id + '"] .rkw-last-result');
        if (row) row.textContent = error.message;
      }
    }
    const summary = allowSend
      ? checked + ' سفارش بررسی شد؛ ' + confirmed + ' شناسه تأیید شد؛ ' + sent + ' سند جدید ثبت شد؛ ' + unresolved + ' مورد حل‌نشده.'
      : 'بررسی ' + checked + ' سفارش انجام شد؛ ' + confirmed + ' شناسه تأیید شد؛ ' + unresolved + ' مورد به بررسی بیشتر نیاز دارد.';
    message(summary + (issues.length ? ' ' + issues.slice(0, 5).join(' | ') : ''), failed > 0, unresolved > 0 && failed === 0);
    selected.forEach(id => busy.delete(id));
    controls.forEach(button => { if (button.isConnected) button.disabled = false; });
  }
  document.addEventListener('click', event => {
    const existing = event.target.closest('.rkw-existing-open');
    if (existing) { event.preventDefault(); existingInvoice(existing.dataset.order); return; }
    const copyReport = event.target.closest('.rkw-copy-check-report');
    if (copyReport) {
      event.preventDefault(); const pre = copyReport.closest('.rkw-check-report').querySelector('pre');
      if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(pre.textContent).then(() => { copyReport.textContent = 'گزارش کپی شد'; }).catch(() => { const selection = window.getSelection(); const range = document.createRange(); range.selectNodeContents(pre); selection.removeAllRanges(); selection.addRange(range); copyReport.textContent = 'متن انتخاب شد؛ کپی کنید'; });
      } else { const selection = window.getSelection(); const range = document.createRange(); range.selectNodeContents(pre); selection.removeAllRanges(); selection.addRange(range); copyReport.textContent = 'متن انتخاب شد؛ کپی کنید'; }
      return;
    }
    const checkOne = event.target.closest('.rkw-check-one');
    if (checkOne) { event.preventDefault(); checkOrders([checkOne.dataset.order], false); return; }
    const checkBulk = event.target.closest('.rkw-check-bulk');
    if (checkBulk) {
      event.preventDefault(); const table = checkBulk.closest('.rkwm-local-orders');
      if (table) checkOrders([...table.querySelectorAll('.rkw-order-check:checked')].map(el => el.value), true);
      return;
    }
    const single = event.target.closest('.rkw-send-one');
    if (single) { event.preventDefault(); send([single.dataset.order]); return; }
    const bulk = event.target.closest('.rkw-send-bulk');
    if (bulk) {
      event.preventDefault();
      const table = bulk.closest('.rkwm-local-orders');
      if (!table) return;
      send([...table.querySelectorAll('.rkw-order-check:checked')].map(el => el.value));
    }
  });
  document.addEventListener('change', event => {
    if (!event.target.matches('.rkw-order-check-all')) return;
    const table = event.target.closest('table');
    if (table) table.querySelectorAll('.rkw-order-check:not(:disabled)').forEach(box => { box.checked = event.target.checked; });
  });
})();
