(() => {
 'use strict';
 const root = document.querySelector('.rkw-manual'); if (!root) return;
 const cfg = window.rkwManualOrders || {}, el = id => document.getElementById('rkw-manual-' + id);
 let page = 1, pages = 1, busy = false, selected = 0, token = '', query = '', kind = 'any', filter = 'unsent';
 const fa = new Intl.NumberFormat('fa-IR', {maximumFractionDigits: 2});
 const amount = (v, currency) => fa.format(Number(v) || 0) + ' ' + ({IRT:'تومان',IRR:'ریال',IRHT:'هزار تومان',IRHR:'هزار ریال'}[currency] || currency || '');
 const date = value => { if (!value) return '—'; try { return new Intl.DateTimeFormat('fa-IR-u-ca-persian', {year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',timeZone:'Asia/Tehran'}).format(new Date(value)); } catch (_) { return '—'; } };
 function node(tag, text, className) { const n = document.createElement(tag); if (text !== undefined) n.textContent = String(text); if (className) n.className = className; return n; }
 function feedback(target, text, error = false) { target.textContent = text; target.classList.toggle('is-error', error); }
 async function request(action, fields) {
  const response = await fetch(cfg.ajax, {method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams(Object.assign({action,nonce:cfg.nonce || ''},fields))});
  const result = await response.json(); if (!result.success) throw new Error(result.data?.message || 'عملیات انجام نشد.'); return result.data;
 }
 function controls(value) {
  busy = value;
  root.querySelectorAll('input,select,button').forEach(n => { n.disabled = value; });
  if (!value) { el('prev').disabled = page <= 1; el('next').disabled = page >= pages; el('submit').disabled = !token; }
 }
 function hidePreview() { token = ''; selected = 0; el('preview').hidden = true; el('submit').disabled = true; }
 async function search(target = 1) {
  if (busy) return; hidePreview(); controls(true); el('rows').replaceChildren(); el('count').textContent=''; feedback(el('status'),'در حال دریافت سفارش‌ها…');
  try {
   const data = await request('rkw_manual_search',{query,kind,filter,page:String(target)});
   page = data.page; pages = data.pages; el('rows').replaceChildren();
   for (const row of data.rows || []) {
    const tr = node('tr'); tr.dataset.order = row.id;
    [('#' + row.number),row.buyer || '—',date(row.date),row.status,amount(row.total,row.currency),row.document || '—'].forEach(text => tr.append(node('td',text)));
    const td = node('td'), button = node('button',row.state === 'sent' ? 'مشاهده جزئیات' : 'انتخاب و پیش‌نمایش','button'); button.type = 'button'; button.dataset.order = row.id;
    button.addEventListener('click',()=>preview(row.id));td.append(button);tr.append(td);el('rows').append(tr);
   }
   if (!(data.rows || []).length) { const tr = node('tr'), td = node('td','سفارشی با این جست‌وجو یافت نشد.');td.colSpan = 7;tr.append(td);el('rows').append(tr); }
   el('count').textContent = fa.format(data.total) + ' نتیجه — صفحه ' + fa.format(page) + ' از ' + fa.format(pages);
   feedback(el('status'),'سفارش را از فهرست انتخاب کنید؛ جست‌وجو و پیش‌نمایش سندی صادر نمی‌کنند.');
  } catch (error) { page=1;pages=1;feedback(el('status'),error.message || 'دریافت فهرست انجام نشد.',true); }
  finally { controls(false); }
 }
 function pair(dl, label, value) { dl.append(node('dt',label),node('dd',value === null || value === undefined || value === '' ? '—' : value)); }
 function listMessages(messages, className) { const list = node('ul',undefined,className);for(const msg of messages || []) list.append(node('li',msg));return list; }
 function render(p) {
  const target = el('detail');target.replaceChildren();el('title').textContent = 'بررسی سفارش #' + p.number;
  target.append(listMessages(p.issues,'rkw-manual-issues'),listMessages(p.warnings,'rkw-manual-warnings'));
  const dl = node('dl',undefined,'rkwm-detail-grid');
  pair(dl,'نوع سند',p.document_type);pair(dl,'خریدار',p.buyer);pair(dl,'شماره همراه',p.phone);pair(dl,'کد ملی در اطلاعات سفارش',p.national_code_present ? 'ثبت شده' : 'ثبت نشده');pair(dl,'کد پستی',p.address?.postcode);
  pair(dl,'نشانی',Object.entries(p.address || {}).filter(([key])=>key !== 'postcode').map(([,value])=>value).filter(Boolean).join('، '));
  pair(dl,'تاریخ سفارش',date(p.date));pair(dl,'وضعیت سفارش',p.status);pair(dl,'شناسه مشتری راهکاران',p.customer_id || 'هنگام ثبت جست‌وجو و در صورت نیاز ایجاد می‌شود');
  pair(dl,'روش پرداخت',p.payment_title);pair(dl,'شناسه درگاه',p.gateway);pair(dl,'روش حمل',(p.shipping_methods || []).join('، '));
  pair(dl,'سیاست تسویه',p.payment?.policy_id);pair(dl,'نوع دریافت',p.payment?.key);if(p.payment?.coupon_type_id)pair(dl,'نوع بن سازمانی',p.payment.coupon_type_id);if(p.payment?.bank_ref)pair(dl,'شناسه حساب بانک',p.payment.bank_ref);
  target.append(dl);
  const wrap = node('div',undefined,'rkwm-table-wrap'), table = node('table',undefined,'widefat striped rkwm-table'), head = node('thead'), hr = node('tr');
  ['کالا','SKU','تعداد','قیمت واحد قبل از تخفیف','تخفیف ردیف','مبلغ ردیف','مالیات','کد کالا / واحد راهکاران'].forEach(v=>hr.append(node('th',v)));head.append(hr);table.append(head);const body = node('tbody');
  for(const item of p.items || []) { const tr = node('tr');[item.name,item.sku || '—',fa.format(item.quantity),amount(item.quantity > 0 ? item.subtotal / item.quantity : 0,p.currency),amount(item.subtotal-item.total,p.currency),amount(item.total,p.currency),amount(item.tax,p.currency),(item.product_id || 'نامشخص') + ' / ' + (item.unit_id || 'نامشخص')].forEach(v=>tr.append(node('td',v)));body.append(tr); }
  table.append(body);wrap.append(table);target.append(node('h3','اقلام سفارش'),wrap);
  const totals = node('dl',undefined,'rkwm-detail-grid');pair(totals,'حمل با مالیات',amount(Number(p.shipping_total)+Number(p.shipping_tax),p.currency));
  for(const fee of p.fees || []) pair(totals,fee.name,amount(Number(fee.amount)+Number(fee.tax),p.currency));
  pair(totals,'مجموع سفارش ووکامرس',amount(p.total,p.currency));pair(totals,'مبلغ سفارش به واحد راهکاران',fa.format(p.amounts.woo_order_total));target.append(totals);
  const description = node('details'), summary = node('summary','توضیحات ارسالی فاکتور');description.append(summary,node('p',p.description));target.append(description);
  el('edit').href = p.edit_url;
  if (!p.can_submit && p.state === 'pending') { const link = node('a','رفتن به فاکتورهای فروش برای بررسی وضعیت','button');link.href = 'admin.php?page=rkw-invoices';target.append(link); }
 }
 async function preview(id) {
  if (busy) return; token = '';selected = Number(id);controls(true);el('preview').hidden = false;feedback(el('result'),'در حال بررسی اطلاعات سفارش…');el('detail').replaceChildren();
  try { const p = await request('rkw_manual_preview',{order_id:String(id)});render(p);token = p.can_submit ? p.token : '';feedback(el('result'),p.can_submit ? 'پیش‌نمایش آماده است. با تأیید، همین سفارش با اطلاعات بالا در راهکاران ثبت می‌شود.' : 'اطلاعات مشخص‌شده را بررسی کنید؛ امکان ثبت فعلاً فعال نیست.',!p.can_submit);el('preview').scrollIntoView({block:'start',behavior:'smooth'}); }
  catch(error) { feedback(el('result'),error.message || 'پیش‌نمایش دریافت نشد.',true); }
  finally { controls(false); }
 }
 el('search').addEventListener('submit',event=>{event.preventDefault();query=el('query').value;kind=el('kind').value;filter=el('filter').value;search(1);});
 el('reset').addEventListener('click',()=>{el('query').value='';query='';kind=el('kind').value;filter=el('filter').value;search(1);});
 el('prev').addEventListener('click',()=>search(page-1));el('next').addEventListener('click',()=>search(page+1));
 el('close').addEventListener('click',hidePreview);el('refresh').addEventListener('click',()=>preview(selected));
 el('submit').addEventListener('click',async()=>{
  if(busy || !token || !selected)return;const proof = token;token='';controls(true);feedback(el('result'),'در حال ثبت سفارش در راهکاران…');
  try { const r = await request('rkw_manual_submit',{order_id:String(selected),token:proof,confirm:'1'});const done = r.status === 'sent' || r.status === 'already_sent';feedback(el('result'),r.message + (done ? ' ' + r.document : ''),!done);const row = el('rows').querySelector('tr[data-order="'+ selected +'"]');if(row && done){row.children[5].textContent=r.document;row.children[6].replaceChildren(node('span','ثبت‌شده'));}if(r.status==='pending')feedback(el('result'),r.message+' ابتدا وضعیت همین سفارش را در فاکتورهای فروش بررسی کنید.',true); }
  catch(error) { feedback(el('result'),'نتیجه ثبت دریافت نشد: '+(error.message || '')+' پیش از تلاش مجدد وضعیت سفارش را در فاکتورهای فروش بررسی کنید.',true); }
  finally { controls(false); }
 });
 search();
})();
