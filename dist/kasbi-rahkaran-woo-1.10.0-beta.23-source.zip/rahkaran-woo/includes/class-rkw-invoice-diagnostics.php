<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Explicit calculation-only comparison. No invoice, customer or product is saved. */
class RKW_Invoice_Diagnostics {
	public static function init() { add_action( 'wp_ajax_rkw_invoice_calculation', array( __CLASS__, 'ajax' ) ); }

	private static function number( $row, $key ) {
		return isset( $row[ $key ] ) && is_numeric( $row[ $key ] ) && is_finite( (float) $row[ $key ] ) ? (float) $row[ $key ] : null;
	}

	/** Short business-error text for the authorized admin only; never persist it in the shared log. */
	private static function error_text( $value ) {
		if ( ! is_string( $value ) ) { return ''; }
		$text = sanitize_text_field( $value );
		$text = strtr( $text, array( '۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9','٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9' ) );
		$text = preg_replace( '/\p{Cf}/u', '', $text );
		$text = preg_replace( '~((?:password|token|cookie|authorization|رمز)[\s"\x27:=]+)[^\s,;"\x27]+~iu', '$1[پنهان]', $text );
		$text = preg_replace( '/[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}/iu', '[ایمیل پوشانده شد]', $text );
		$text = preg_replace( '/\b(?:[0-9a-f]{24,}|[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,})\b/i', '[شناسه پوشانده شد]', $text );
		$text = preg_replace( '/\+?[0-9][0-9 ()\-]{8,}[0-9]/u', '[عدد پوشانده شد]', $text );
		return rkw_text_slice( $text, 0, 1500 );
	}

	private static function policies( $rows ) {
		$out = array();
		foreach ( is_array( $rows ) ? array_slice( $rows, 0, 30 ) : array() as $p ) {
			if ( ! is_array( $p ) ) { continue; }
			$effect = isset( $p['effect'] ) && in_array( $p['effect'], array( 0, 1, 2, 'Decrease', 'Increase' ), true ) ? $p['effect'] : null;
			$out[] = array( 'id' => isset( $p['policyId'] ) ? absint( $p['policyId'] ) : 0, 'price' => self::number( $p, 'price' ), 'effect' => $effect,
				'type' => isset( $p['type'] ) && is_string( $p['type'] ) && preg_match( '/^[A-Za-z0-9_]{1,80}$/D', $p['type'] ) ? $p['type'] : null,
				'is_included' => isset( $p['isIncluded'] ) && is_bool( $p['isIncluded'] ) ? $p['isIncluded'] : null,
				'is_read_only' => isset( $p['isReadOnly'] ) && is_bool( $p['isReadOnly'] ) ? $p['isReadOnly'] : null,
				'enforcement' => self::number( $p, 'enforcement' ), 'definitiveness' => self::number( $p, 'definitiveness' ) );
		}
		return $out;
	}

	private static function delta( $rows ) {
		$sum = 0.0;
		foreach ( is_array( $rows ) ? $rows : array() as $p ) {
			$n = is_array( $p ) ? self::number( $p, 'price' ) : null;
			if ( null === $n ) { return null; }
			$sum += isset( $p['effect'] ) && in_array( $p['effect'], array( 1, 'Decrease' ), true ) ? -$n : $n;
		}
		return $sum;
	}

	/** ESales price is per unit; native v21 price is a line amount. Excludes all personal/payment attributes. */
	public static function wire_summary( $wire, $contract ) {
		$d = isset( $wire['document'] ) && is_array( $wire['document'] ) ? $wire['document'] : array();
		$legacy = 'v21' !== $contract; $rows = array(); $base_total = 0.0; $net_total = 0.0; $valid = true;
		$all = isset( $d['items'] ) && is_array( $d['items'] ) ? $d['items'] : array();
		foreach ( $all as $i => $item ) {
			if ( ! is_array( $item ) ) { $valid = false; continue; }
			$q = self::number( $item, 'quantity' ); $price = self::number( $item, 'price' ); $fee = self::number( $item, 'fee' );
			$base = null !== $price ? ( $legacy && null !== $q ? $price * $q : $price ) : ( null !== $q && null !== $fee ? $q * $fee : null );
			$delta = self::delta( isset( $item['policies'] ) ? $item['policies'] : array() );
			$net = null !== $base && null !== $delta ? $base + $delta : null;
			if ( null === $base || null === $net || null === $q || $q <= 0 ) { $valid = false; }
			else { $base_total += $base; $net_total += $net; }
			if ( count( $rows ) < 30 ) { $rows[] = array( 'row' => $i + 1, 'product_id' => isset( $item['productId'] ) ? absint( $item['productId'] ) : 0,
				'unit_id' => isset( $item['unitId'] ) ? absint( $item['unitId'] ) : 0, 'quantity' => $q, 'fee' => $fee, 'price' => $price,
				'base_total' => $base, 'net_total_estimate' => $net, 'policies' => self::policies( isset( $item['policies'] ) ? $item['policies'] : array() ) ); }
		}
		$header = self::delta( isset( $d['policies'] ) ? $d['policies'] : array() );
		$tenders = array(); $tender_total = 0.0;
		foreach ( array( 'receipts', 'payments' ) as $container ) {
			foreach ( isset( $wire[ $container ] ) && is_array( $wire[ $container ] ) ? $wire[ $container ] : array() as $r ) {
				if ( ! is_array( $r ) ) { continue; }
				$amount = self::number( $r, 'amount' );
				if ( null !== $amount ) { $tender_total += $amount; }
				$tenders[] = array( 'container' => $container, 'key' => isset( $r['key'] ) ? preg_replace( '/[^A-Za-z0-9_]/', '', $r['key'] ) : '', 'amount' => $amount,
					'coupon_type' => isset( $r['attr']['couponType'] ) ? absint( $r['attr']['couponType'] ) : 0 );
			}
		}
		return array( 'contract' => $contract, 'price_basis' => $legacy ? 'unit' : 'line', 'item_count' => count( $all ), 'rows' => $rows,
			'item_base_total' => $valid ? round( $base_total, 6 ) : null, 'item_net_total_estimate' => $valid ? round( $net_total, 6 ) : null,
			'header_policies' => self::policies( isset( $d['policies'] ) ? $d['policies'] : array() ),
			'document_total_estimate' => $valid && null !== $header ? round( $net_total + $header, 6 ) : null,
			'tender_total' => round( $tender_total, 6 ), 'tenders' => $tenders,
			'loyalty_program_id' => isset( $d['loyaltyProgramId'] ) ? absint( $d['loyaltyProgramId'] ) : ( isset( $d['data']['loyaltyProgramID'] ) ? absint( $d['data']['loyaltyProgramID'] ) : 0 ) );
	}

	public static function inspect( WC_Order $order ) {
		if ( 'shop_order' !== $order->get_type() ) { return new WP_Error( 'rkw_probe_order', 'سفارش فروش معتبر نیست.' ); }
		$payload = RKW_Orders::preview_invoice_payload( $order );
		if ( is_wp_error( $payload ) ) { return $payload; }
		$s = rkw_settings(); $wire = RKW_Client::document_payload( $payload, $s );
		$report = array( 'order_id' => (int) $order->get_id(), 'plugin_version' => RKW_VER, 'snapshot' => 'current_order_and_settings',
			'financial_document_sent' => false, 'wire' => self::wire_summary( $wire, $s['document_contract'] ),
			'woo' => RKW_Orders::order_amount_breakdown( $order, $s ), 'canonical' => self::wire_summary( $payload, 'v21' ) );
		$shipping_route = $report['woo']['shipping_total'] > 0 ? RKW_Accounting::shipping_mapping( $order, RKW_Extensions::settings() ) : array( 'source' => 'no_shipping_charge' );
		$report['shipping_mapping_settings'] = is_wp_error( $shipping_route ) ? array( 'error_code' => $shipping_route->get_error_code() ) : $shipping_route;
		$report['woo_lines'] = array();
		foreach ( $order->get_items() as $it ) {
			$q = (float) $it->get_quantity(); if ( $q <= 0 || count( $report['woo_lines'] ) >= 30 ) { continue; }
			$gross = ( (float) $it->get_subtotal() + (float) $it->get_subtotal_tax() ) * rkw_price_multiplier( $s );
			$net = ( (float) $it->get_total() + (float) $it->get_total_tax() ) * rkw_price_multiplier( $s );
			$report['woo_lines'][] = array( 'quantity' => $q, 'gross_unit' => round( $gross / $q, 6 ), 'net_unit' => round( $net / $q, 6 ), 'gross_total' => round( $gross, 6 ), 'net_total' => round( $net, 6 ), 'discount_total' => round( $gross - $net, 6 ), 'line_tax' => round( (float) $it->get_total_tax() * rkw_price_multiplier( $s ), 6 ), 'subtotal_tax' => round( (float) $it->get_subtotal_tax() * rkw_price_multiplier( $s ), 6 ) );
		}
		$document = $payload['document'];
		unset( $document['description'] ); // Calculation needs no name, address or order description.
		$document['status'] = 0; // The supplied calculateAmount example uses a draft document.
		$client = new RKW_Client(); $calculated = $client->calculate_invoice21( $document );
		if ( is_wp_error( $calculated ) ) {
			$data = $calculated->get_error_data();
			$report['calculation'] = array( 'available' => false, 'total_available' => false, 'error_code' => $calculated->get_error_code(), 'http_status' => is_array( $data ) && isset( $data['http_status'] ) ? (int) $data['http_status'] : 0 );
		} else {
			$net = is_array( $calculated ) ? self::number( $calculated, 'netPrice' ) : null;
			$server_items = array(); $item_errors = 0; $malformed_items = 0;
			$items_schema_valid = is_array( $calculated ) && isset( $calculated['items'] ) && is_array( $calculated['items'] );
			foreach ( is_array( $calculated ) && isset( $calculated['items'] ) && is_array( $calculated['items'] ) ? $calculated['items'] : array() as $row ) {
				if ( ! is_array( $row ) ) { $malformed_items++; continue; }
				if ( ! empty( $row['hasError'] ) ) { $item_errors++; }
				if ( count( $server_items ) >= 30 ) { continue; }
				$server_items[] = array( 'product_id' => isset( $row['productId'] ) ? absint( $row['productId'] ) : 0,
					'unit_id' => isset( $row['unitId'] ) ? absint( $row['unitId'] ) : null,
					'quantity' => self::number( $row, 'quantity' ), 'fee' => self::number( $row, 'fee' ), 'price' => self::number( $row, 'price' ), 'net_price' => self::number( $row, 'netPrice' ),
					'has_error' => ! empty( $row['hasError'] ), 'error_message' => self::error_text( isset( $row['errorMessage'] ) ? $row['errorMessage'] : '' ),
					'policies' => self::policies( isset( $row['policies'] ) ? $row['policies'] : array() ) );
			}
			$document_error = is_array( $calculated ) && ! empty( $calculated['hasError'] );
			$report['calculation'] = array( 'available' => null !== $net && $items_schema_valid && ! $item_errors && ! $malformed_items && ! $document_error,
				'total_available' => null !== $net, 'item_error_count' => $item_errors, 'malformed_item_count' => $malformed_items,
				'items_schema_valid' => $items_schema_valid,
				'document_has_error' => $document_error, 'error_message' => self::error_text( is_array( $calculated ) && isset( $calculated['errorMessage'] ) ? $calculated['errorMessage'] : '' ), 'net_price' => $net,
				'gap_from_tenders' => null !== $net ? round( $net - $report['wire']['tender_total'], 6 ) : null,
				'policies' => self::policies( is_array( $calculated ) && isset( $calculated['policies'] ) ? $calculated['policies'] : array() ), 'items' => $server_items );
		}
		$lines = array( 'گزارش مالی بدون ثبت — سفارش #' . $report['order_id'],
			'مبنای گزارش: سفارش و تنظیمات فعلی؛ داده درخواست قدیمی بازسازی قطعی نشده است.',
			'قرارداد ثبت انتخاب‌شده: ' . $s['document_contract'] . ' | مبنای price: ' . ( 'unit' === $report['wire']['price_basis'] ? 'قیمت واحد' : 'جمع ردیف' ),
			'جمع دریافت ارسالی: ' . $report['wire']['tender_total'] . ' | جمع محلی برآوردشده سند: ' . $report['wire']['document_total_estimate'],
			'محاسبه سرور از calculateAmount نسخه ۲۱ برای مقایسه انجام شد؛ هم‌ارزی آن با جمع داخلی ESales تأیید نشده است.',
			'جمع عددی از سرور دریافت شد: ' . ( $report['calculation']['total_available'] ? 'بله' : 'خیر' ),
			'محاسبه بدون خطای سند یا ردیف: ' . ( $report['calculation']['available'] ? 'بله' : 'خیر؛ این پاسخ تأیید سلامت فاکتور نیست' ) );
		if ( $report['calculation']['total_available'] ) {
			$lines[] = 'جمع محاسبه‌شده در مسیر ۲۱: ' . $report['calculation']['net_price'] . ' | اختلاف با دریافت: ' . $report['calculation']['gap_from_tenders'];
		} else { $lines[] = 'این بررسی جمع نهایی سرور را تأیید نکرده است؛ ارسال فاکتور آزمایشی انجام نشد.'; }
		foreach ( isset( $report['calculation']['items'] ) ? $report['calculation']['items'] : array() as $item ) {
			if ( $item['has_error'] ) { $lines[] = 'خطای کالا #' . $item['product_id'] . ': ' . ( '' !== $item['error_message'] ? $item['error_message'] : 'سرویس متن خطای این ردیف را برنگرداند' ); }
		}
		$lines[] = 'جزئیات عددی، سیاست‌ها و پیام خطای سرویس؛ بدنه خام پاسخ و فیلدهای هویتی نمایش داده نمی‌شوند:';
		$lines[] = wp_json_encode( $report, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT );
		$lines[] = 'هیچ فاکتور، مشتری یا محصولی ساخته یا ذخیره نشد؛ مبلغ سفارش و دریافت تغییر نکرد.';
		$report['text'] = implode( "\n", $lines );
		// Error text can contain names supplied by the server. Show its masked form only to this admin.
		$log_report = $report; unset( $log_report['text'], $log_report['calculation']['error_message'] );
		foreach ( isset( $log_report['calculation']['items'] ) ? $log_report['calculation']['items'] : array() as $i => $item ) { unset( $log_report['calculation']['items'][ $i ]['error_message'] ); }
		RKW_Log::add( 'info', 'گزارش مالی بدون ثبت سفارش #' . $report['order_id'] . '؛ متن خطای ردیف فقط در صفحه مدیریت نمایش داده می‌شود. ' . wp_json_encode( $log_report, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) );
		return $report;
	}

	public static function ajax() {
		if ( ! current_user_can( 'manage_woocommerce' ) || ! check_ajax_referer( 'rkw_ajax', '_ajax_nonce', false ) ) { wp_send_json_error( array( 'message' => 'دسترسی یا نشست نامعتبر است.' ), 403 ); }
		$id = isset( $_POST['order_id'] ) && is_scalar( $_POST['order_id'] ) ? absint( $_POST['order_id'] ) : 0;
		$order = $id ? wc_get_order( $id ) : false;
		if ( ! $order instanceof WC_Order ) { wp_send_json_error( array( 'message' => 'سفارش یافت نشد.' ), 404 ); }
		$r = self::inspect( $order );
		if ( is_wp_error( $r ) ) { wp_send_json_error( array( 'message' => $r->get_error_message() ), 409 ); }
		wp_send_json_success( $r );
	}
}
