<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Find existing WooCommerce orders, review their data, then use the shared financial sender. */
class RKW_Manual_Orders {
 const CAP = 'manage_woocommerce';
 const NONCE = 'rkw_manual_orders';
 public static function init() {
  add_action('admin_menu',array(__CLASS__,'menu'),11);
  add_action('admin_enqueue_scripts',array(__CLASS__,'assets'));
  foreach(array('search','preview','submit')as$action){add_action('wp_ajax_rkw_manual_'.$action,array(__CLASS__,'ajax_'.$action));}
 }
 public static function menu(){add_submenu_page('rkw','ثبت دستی سفارش | کاسبی راهکاران','ثبت دستی سفارش',self::CAP,'rkw-manual-orders',array(__CLASS__,'page'));}
 public static function assets($hook){
  if(!current_user_can(self::CAP)||!isset($_GET['page'])||'rkw-manual-orders'!==$_GET['page'])return;
  wp_enqueue_style('rkw-manual-base',plugins_url('assets/admin.css',RKW_FILE),array(),RKW_VER);
  wp_enqueue_style('rkw-manual-orders',plugins_url('assets/manual-orders.css',RKW_FILE),array('rkw-manual-base'),RKW_VER);
  wp_enqueue_script('rkw-manual-orders',plugins_url('assets/manual-orders.js',RKW_FILE),array(),RKW_VER,true);
  wp_localize_script('rkw-manual-orders','rkwManualOrders',array('ajax'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce(self::NONCE)));
 }
 public static function page(){
  if(!current_user_can(self::CAP)){wp_die('عدم دسترسی');}
  echo '<div class="wrap rkwm-wrap rkw-manual" dir="rtl"><header class="rkwm-header"><div><div class="rkwm-eyebrow">RAHKARAN × WOOCOMMERCE</div><h1>ثبت دستی سفارش در راهکاران</h1><p>سفارش ووکامرس را پیدا کنید، اطلاعات آن را بررسی کنید و برای ثبت انتخاب کنید.</p></div><a class="button" href="'.esc_url(admin_url('admin.php?page=rkw-invoices')).'">فاکتورهای فروش</a></header>';
  echo '<section class="rkwm-box"><form id="rkw-manual-search" class="rkwm-toolbar"><label for="rkw-manual-query"><span>شماره سفارش یا نام خریدار</span><input id="rkw-manual-query" type="search" maxlength="80" placeholder="مثلاً 237743 یا نام و نام خانوادگی"></label><label for="rkw-manual-kind"><span>جست‌وجو در</span><select id="rkw-manual-kind"><option value="any">شماره سفارش و نام خریدار</option><option value="number">شماره سفارش</option><option value="buyer">نام خریدار</option></select></label><label for="rkw-manual-filter"><span>وضعیت ارسال</span><select id="rkw-manual-filter"><option value="unsent">ارسال‌نشده، خطادار و نیازمند بررسی</option><option value="all">همه سفارش‌های واجد شرایط</option></select></label><button class="button button-primary" type="submit">جست‌وجو</button><button class="button" id="rkw-manual-reset" type="button">پاک‌کردن جست‌وجو</button></form><p class="description">سفارش‌های در حال انجام، تکمیل‌شده و وضعیت‌های سفارشی دارای تاریخ پرداخت با مبلغ غیرصفر نمایش داده می‌شوند. اطلاعات ثبت از خود سفارش خوانده می‌شود.</p><p id="rkw-manual-status" role="status" aria-live="polite"></p><div class="rkwm-table-wrap"><table class="widefat striped rkwm-table"><thead><tr><th>شماره سفارش</th><th>خریدار</th><th>تاریخ سفارش</th><th>وضعیت</th><th>مبلغ</th><th>راهکاران</th><th>انتخاب</th></tr></thead><tbody id="rkw-manual-rows"></tbody></table></div><nav class="rkwm-footer" aria-label="صفحه‌بندی جست‌وجوی سفارش"><button type="button" class="button" id="rkw-manual-prev" disabled>قبلی</button><span id="rkw-manual-count"></span><button type="button" class="button" id="rkw-manual-next" disabled>بعدی</button></nav></section>';
  echo '<section id="rkw-manual-preview" class="rkwm-box" hidden aria-labelledby="rkw-manual-title"><div class="rkw-manual-head"><h2 id="rkw-manual-title">بررسی سفارش</h2><button class="button" id="rkw-manual-close" type="button">بستن پیش‌نمایش</button></div><p>اطلاعات زیر از ووکامرس تکمیل شده است. برای اصلاح، «ویرایش سفارش در ووکامرس» را باز کنید و سپس پیش‌نمایش را دوباره دریافت کنید.</p><div id="rkw-manual-detail"></div><p id="rkw-manual-result" role="status" aria-live="polite"></p><div class="rkw-manual-buttons"><a id="rkw-manual-edit" class="button" target="_blank" rel="noopener">ویرایش سفارش در ووکامرس</a><button id="rkw-manual-refresh" class="button" type="button">دریافت دوباره پیش‌نمایش</button><button id="rkw-manual-submit" class="button button-primary" type="button" disabled>تأیید و ثبت در راهکاران</button></div></section></div>';
 }
 public static function normalize_search($value){
  if(!is_string($value))return new WP_Error('rkw_manual_search','عبارت جست‌وجو معتبر نیست.');
  $value=strtr(sanitize_text_field($value),array('۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9','٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9','ي'=>'ی','ى'=>'ی','ك'=>'ک',"\u{200C}"=>'',"\u{200B}"=>''));
  $value=trim(preg_replace('/\s+/u',' ',preg_replace('/^\s*#\s*/u','',$value)));
  if(rkw_text_slice($value,0,80)!==$value)return new WP_Error('rkw_manual_search','عبارت جست‌وجو حداکثر ۸۰ کاراکتر باشد.');
  if(''!==$value&&!preg_match('/^[0-9]+$/D',$value)&&rkw_text_slice($value,0,1)===$value)return new WP_Error('rkw_manual_search','برای جست‌وجوی نام حداقل دو حرف وارد کنید.');
  return$value;
 }
 private static function sql_name($column){return "REPLACE(REPLACE(REPLACE(REPLACE({$column},'ي','ی'),'ى','ی'),'ك','ک'),'‌','')";}
 public static function search_where($query,$kind,$hpos){
  global$wpdb;$id=$hpos?'id':'ID';$meta=$hpos?$wpdb->prefix.'wc_orders_meta':$wpdb->postmeta;$mid=$hpos?'order_id':'post_id';
  $numbers=array();if(preg_match('/^[1-9][0-9]*$/D',$query))$numbers[]=$wpdb->prepare("o.{$id}=%d",(int)$query);
  $numbers[]=$wpdb->prepare("EXISTS (SELECT 1 FROM {$meta} sn WHERE sn.{$mid}=o.{$id} AND sn.meta_key IN ('_order_number','_order_number_formatted','_alg_wc_custom_order_number','_alg_wc_full_custom_order_number') AND sn.meta_value=%s)",$query);
  $terms=array_values(array_unique(array_filter(explode(' ',$query))));$names=array();
  foreach($terms as$term){$like='%'.$wpdb->esc_like($term).'%';
   if($hpos){$names[]=$wpdb->prepare('('.self::sql_name('ba.first_name').' LIKE %s OR '.self::sql_name('ba.last_name').' LIKE %s)',$like,$like);}
   else{$names[]=$wpdb->prepare("EXISTS (SELECT 1 FROM {$meta} bn WHERE bn.{$mid}=o.{$id} AND bn.meta_key IN ('_billing_first_name','_billing_last_name') AND ".self::sql_name('bn.meta_value').' LIKE %s)',$like);}
  }
  $buyer=$hpos?"EXISTS (SELECT 1 FROM {$wpdb->prefix}wc_order_addresses ba WHERE ba.order_id=o.id AND ba.address_type='billing' AND ".implode(' AND ',$names).')':'('.implode(' AND ',$names).')';
  if('number'===$kind)return'('.implode(' OR ',$numbers).')';if('buyer'===$kind)return$buyer;
  return'('.implode(' OR ',$numbers).' OR '.$buyer.')';
 }
 private static function guard(){
  if(!current_user_can(self::CAP)||!check_ajax_referer(self::NONCE,'nonce',false)){wp_send_json_error(array('message'=>'دسترسی یا نشست نامعتبر است.'),403);}
 }
 private static function order(){
  $id=isset($_POST['order_id'])&&is_scalar($_POST['order_id'])?absint($_POST['order_id']):0;$o=$id?wc_get_order($id):false;
  if(!$o instanceof WC_Order||'shop_order'!==$o->get_type()){wp_send_json_error(array('message'=>'سفارش ووکامرس معتبر پیدا نشد.'),404);}return$o;
 }
 private static function reply($result){if(is_wp_error($result)){wp_send_json_error(array('message'=>$result->get_error_message()),409);}wp_send_json_success($result);}
 private static function edit_url($o){return method_exists($o,'get_edit_order_url')?$o->get_edit_order_url():admin_url('post.php?post='.$o->get_id().'&action=edit');}
 private static function buyer($o){return trim($o->get_billing_first_name().' '.$o->get_billing_last_name());}
 public static function row($o){
  return array('id'=>(int)$o->get_id(),'number'=>(string)$o->get_order_number(),'buyer'=>self::buyer($o),'date'=>$o->get_date_created()?$o->get_date_created()->date('c'):'','status'=>wc_get_order_status_name($o->get_status()),'total'=>(float)$o->get_total(),'currency'=>method_exists($o,'get_currency')?$o->get_currency():'','state'=>RKW_Order_List_UI::state($o),'document'=>RKW_Order_List_UI::document_label($o),'edit_url'=>self::edit_url($o));
 }
 public static function search($query,$kind='any',$filter='unsent',$page=1){
  $q=self::normalize_search($query);if(is_wp_error($q))return$q;
  $result=RKW_Modules::local_order_page($page,'all'===$filter?'all':'unsent','','',$q,in_array($kind,array('number','buyer'),true)?$kind:'any');
  if(is_wp_error($result))return$result;$rows=array();foreach($result->orders as$o){if($o instanceof WC_Order&&RKW_Modules::invoice_order_eligible($o)&&(float)$o->get_total()!==0.0)$rows[]=self::row($o);}
  return array('rows'=>$rows,'page'=>$result->page,'pages'=>$result->max_num_pages,'total'=>$result->total);
 }
 private static function key($o){return'rkw_manual_'.get_current_user_id().'_'.$o->get_id();}
 private static function data($o){
  RKW_Order_List_UI::clear_document_cache();$s=rkw_settings();$state=RKW_Order_List_UI::state($o);$issues=array();$warnings=array();
  if('v21'!==$s['api'])$issues[]='ثبت سفارش به اتصال API نسخه ۲۱ نیاز دارد.';
  if('default'===$s['customer_mode']&&empty($s['fallback_cust']))$issues[]='شناسه مشتری پیش‌فرض را در تنظیمات سفارش‌ها تکمیل کنید.';
  if(!RKW_Modules::invoice_order_eligible($o)||(float)$o->get_total()<=0)$issues[]='این سفارش با وضعیت یا مبلغ فعلی واجد شرایط ثبت نیست.';
  if('sent'===$state)$issues[]='این سفارش قبلاً ثبت شده است: '.RKW_Order_List_UI::document_label($o);
  if('pending'===$state)$issues[]='نتیجه ارسال قبلی نیازمند بررسی است؛ ابتدا در فاکتورهای فروش تطبیق دهید.';
  $draft=$issues?null:RKW_Orders::preview_manual_payload($o);
  if(is_wp_error($draft))$issues[]=$draft->get_error_message();
  $customer=is_array($draft)&&isset($draft['document']['customerId'])?(int)$draft['document']['customerId']:0;
  if(!$customer&&!$issues){$warnings[]='هنگام ثبت، مشتری با اطلاعات سفارش در راهکاران جست‌وجو می‌شود و اگر وجود نداشته باشد طبق تنظیمات مشتری ساخته می‌شود.';if(''===RKW_Extensions::customer_mobile_for_order($o))$warnings[]='شماره همراه مشتری برای جست‌وجو ثبت نشده است.';if(''===self::buyer($o))$issues[]='نام خریدار را در سفارش ووکامرس تکمیل کنید.';}
  $billing=$o->get_address('billing');$shipping=$o->get_address('shipping');$billing=is_array($billing)?$billing:array();$shipping=is_array($shipping)?$shipping:array();
  $address=array();foreach(array('country','state','city','address_1','address_2','postcode')as$k){$address[$k]=isset($billing[$k])&&''!==(string)$billing[$k]?(string)$billing[$k]:(isset($shipping[$k])?(string)$shipping[$k]:'');}
  if(empty($address['postcode']))$warnings[]='کد پستی در نشانی سفارش وارد نشده است.';
  $items=array();$map=array();foreach($o->get_items()as$it){$p=$it->get_product();$rid=$p?(int)$p->get_meta('_rahkaran_product_id'):0;$unit=$p?(int)$p->get_meta('_rahkaran_unit_id'):0;$unit=$unit?:((int)$s['default_unit_id']);$items[]=array('name'=>$it->get_name(),'sku'=>$p?$p->get_sku():'','quantity'=>(float)$it->get_quantity(),'subtotal'=>(float)$it->get_subtotal(),'total'=>(float)$it->get_total(),'tax'=>(float)$it->get_total_tax(),'product_id'=>$rid,'unit_id'=>$unit);$map[]=array($rid,$unit,$it->get_quantity(),$it->get_subtotal(),$it->get_total(),$it->get_subtotal_tax(),$it->get_total_tax());}
  $nat='';if(!empty($s['national_key'])){$nat=(string)$o->get_meta($s['national_key']);if(''===$nat&&$o->get_user_id())$nat=(string)get_user_meta($o->get_user_id(),$s['national_key'],true);}
  if(!$customer&&''===$nat&&empty($s['fida_fallback'])&&empty($s['fallback_cust']))$warnings[]='اگر مشتری در راهکاران پیدا نشود، ساخت مشتری به کد ملی نیاز دارد؛ کد ملی سفارش و نام فیلد آن در تنظیمات را بررسی کنید.';
  $payment=RKW_Payment::resolve($o,$s);$fees=array();foreach($o->get_fees()as$fee)$fees[]=array('name'=>$fee->get_name(),'amount'=>(float)$fee->get_total(),'tax'=>(float)$fee->get_total_tax());
  $methods=array();foreach($o->get_shipping_methods()as$m)$methods[]=$m->get_name();
  $details=array_merge(self::row($o),array('document_type'=>'invoice'===$s['order_mode']?'فاکتور فروش':'سفارش فروش','phone'=>(string)$o->get_billing_phone(),'national_code_present'=>''!==$nat,'address'=>$address,'description'=>RKW_Orders::invoice_description($o),'payment_title'=>$o->get_payment_method_title(),'gateway'=>$o->get_payment_method(),'customer_id'=>$customer,'items'=>$items,'fees'=>$fees,'shipping_methods'=>$methods,'shipping_total'=>(float)$o->get_shipping_total(),'shipping_tax'=>(float)$o->get_shipping_tax(),'amounts'=>RKW_Orders::order_amount_breakdown($o,$s),'payment'=>is_wp_error($payment)?null:array('policy_id'=>$payment['settlement_id'],'key'=>$payment['receipt_key'],'coupon_type_id'=>$payment['coupon_type_id']??0,'bank_ref'=>$payment['bank_account_ref']),'issues'=>array_values(array_unique($issues)),'warnings'=>$warnings,'can_submit'=>!$issues));
  $legacy=RKW_Reconciliation::order_fingerprint($o);if(is_wp_error($legacy))return$legacy;
  $hash=hash('sha256',wp_json_encode(array($legacy,RKW_Extensions::settings(),$details,$billing,$shipping,$map,$draft,is_wp_error($draft)?$draft->get_error_code():'',$o->get_transaction_id(),$nat)));
  return array('details'=>$details,'hash'=>$hash);
 }
 public static function preview($o){
  $snapshot=self::data($o);if(is_wp_error($snapshot))return$snapshot;$result=$snapshot['details'];$result['token']='';
  if($result['can_submit']){$token=wp_generate_uuid4();set_transient(self::key($o),array('token'=>$token,'hash'=>$snapshot['hash']),10*MINUTE_IN_SECONDS);$result['token']=$token;}else{delete_transient(self::key($o));}
  return$result;
 }
 public static function submit($o,$token){
  $result=RKW_Orders::send($o,true,static function($fresh)use($token){
   $saved=get_transient(self::key($fresh));if(!is_array($saved)||!isset($saved['token'],$saved['hash'])||!hash_equals($saved['token'],$token))return new WP_Error('rkw_manual_expired','پیش‌نمایش منقضی شده است؛ سفارش را دوباره بررسی کنید.');
   $snapshot=self::data($fresh);if(is_wp_error($snapshot))return$snapshot;
   if(!$snapshot['details']['can_submit']||!hash_equals($saved['hash'],$snapshot['hash']))return new WP_Error('rkw_manual_changed','سفارش، اتصال کالا یا تنظیمات پس از پیش‌نمایش تغییر کرده است؛ پیش‌نمایش را دوباره دریافت کنید.');
   delete_transient(self::key($fresh));return true;
  });
  RKW_Order_List_UI::clear_document_cache();$fresh=wc_get_order($o->get_id());if($fresh instanceof WC_Order)$o=$fresh;$state=RKW_Order_List_UI::state($o);
  if(is_wp_error($result)){return array('status'=>'sent'===$state?'already_sent':('pending'===$state?'pending':'error'),'message'=>$result->get_error_message(),'document'=>RKW_Order_List_UI::document_label($o),'id'=>$o->get_id());}
  return array('status'=>'sent','message'=>'سفارش با موفقیت در راهکاران ثبت شد.','document'=>RKW_Order_List_UI::document_label($o),'id'=>$o->get_id());
 }
 public static function ajax_search(){self::guard();$q=isset($_POST['query'])?wp_unslash($_POST['query']):'';$kind=isset($_POST['kind'])&&is_string($_POST['kind'])?$_POST['kind']:'any';$filter=isset($_POST['filter'])&&is_string($_POST['filter'])?$_POST['filter']:'unsent';$page=isset($_POST['page'])&&is_scalar($_POST['page'])?max(1,absint($_POST['page'])):1;self::reply(self::search($q,$kind,$filter,$page));}
 public static function ajax_preview(){self::guard();self::reply(self::preview(self::order()));}
 public static function ajax_submit(){self::guard();$o=self::order();if(!isset($_POST['confirm'])||'1'!==$_POST['confirm']||!isset($_POST['token'])||!is_string($_POST['token'])||''===$_POST['token'])self::reply(new WP_Error('rkw_manual_confirm','ابتدا پیش‌نمایش سفارش را بررسی و ثبت را تأیید کنید.'));self::reply(self::submit($o,sanitize_text_field($_POST['token'])));}
}
