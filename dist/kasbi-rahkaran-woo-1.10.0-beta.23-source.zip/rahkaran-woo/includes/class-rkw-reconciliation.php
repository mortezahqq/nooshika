<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Resumable remote reads. An unsuccessful search never authorizes a financial retry. */
class RKW_Reconciliation {
	const PAGE_SIZE = 50;
	const MAX_PAGES = 200;
	const TTL = 900;
	const MAX_REPORT_ROWS = 25;
	private static $diagnostics = array();

	public static function init() {
		add_action( 'wp_ajax_rkw_check_order', array( __CLASS__, 'ajax_check' ) );
	}

	/** Normalize only typography; require complete, nonconflicting explicit order-reference fields. */
	public static function normalized_text( $text ) {
		$text = strtr( (string) $text, array( '۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9','٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9','ي'=>'ی','ك'=>'ک','：'=>':','＃'=>'#',"\xc2\xa0"=>' ' ) );
		$text = preg_replace( '/\p{Cf}/u', '', $text );
		$text = str_replace( array( "\r\n", "\r", "\n" ), ' | ', $text );
		return trim( preg_replace( '/[	 ]+/u', ' ', $text ) );
	}

	/** none/match/conflict; a conflicting explicit reference is never overridden by manual selection. */
	public static function reference_status( $invoice, WC_Order $order ) {
		if ( ! is_array( $invoice ) || ! isset( $invoice['description'] ) || ! is_string( $invoice['description'] ) ) { return 'none'; }
		$matched = false;
		foreach ( explode( '|', self::normalized_text( $invoice['description'] ) ) as $field ) {
			$field = trim( $field );
			if ( preg_match( '/^ووکامرس\s*:\s*#?\s*([0-9]+)\s*$/uD', $field, $m ) ) {
				if ( $m[1] !== (string) $order->get_id() ) { return 'conflict'; }
				$matched = true;
			} elseif ( preg_match( '/^سفارش\s+سایت\s*#\s*(.+?)\s*$/uD', $field, $m ) ) {
				if ( $m[1] !== self::normalized_text( $order->get_order_number() ) ) { return 'conflict'; }
				$matched = true;
			}
		}
		return $matched ? 'match' : 'none';
	}

	public static function matches( $invoice, WC_Order $order ) {
		if ( 'match' !== self::reference_status( $invoice, $order ) ) { return false; }
		$customer = (int) $order->get_meta( '_rkw_customer_id' );
		return ! $customer || ( isset( $invoice['customerId'] ) && (int) $invoice['customerId'] === $customer );
	}

	private static function key( $order_id ) { return 'rkw_check_' . get_current_user_id() . '_' . $order_id; }

	public static function invoice_id( $row ) {
		if ( ! is_array( $row ) ) { return 0; }
		$id = 0;
		foreach ( array( 'id', 'Id', 'invoiceId', 'InvoiceId' ) as $key ) {
			if ( ! array_key_exists( $key, $row ) ) { continue; }
			$value = $row[ $key ];
			if ( ( ! is_int( $value ) && ! is_string( $value ) ) || ! preg_match( '/^[1-9][0-9]*$/D', (string) $value ) || (string) (int) $value !== (string) $value ) { return 0; }
			if ( $id && $id !== (int) $value ) { return 0; }
			$id = (int) $value;
		}
		return $id;
	}

	private static function fingerprint( WC_Order $order, $legacy ) {
		$records = array_map( 'wp_json_encode', $legacy ); sort( $records, SORT_STRING );
		$items = array();
		foreach ( $order->get_items() as $item ) { $items[] = array( $item->get_quantity(), $item->get_total(), $item->get_total_tax() ); }
		return hash( 'sha256', wp_json_encode( array( rkw_settings(), $records, $items,
			$order->get_id(), $order->get_order_number(), $order->get_total(), RKW_Extensions::customer_mobile_for_order( $order ),
			$order->get_meta( '_rkw_customer_id' ), $order->get_meta( '_rkw_doc_id' ), $order->get_meta( '_rkw_doc_type' ), $order->get_meta( '_rkw_reconcile_required' ) ) ) );
	}

	public static function order_fingerprint( WC_Order $order ) {
		$records = RKW_Migration::legacy_order_records( $order->get_id() );
		return is_wp_error( $records ) ? $records : self::fingerprint( $order, $records );
	}

	private static function result( $status, $message, $extra = array() ) {
		return array_merge( array( 'done' => true, 'status' => $status, 'message' => $message ), $extra );
	}

	private static function progress( $key, $job ) {
		self::job_diagnostics( $job );
		set_transient( $key, $job, self::TTL );
		return array( 'done' => false, 'token' => $job['token'], 'status' => 'checking', 'message' => 'بررسی راهکاران: ' . $job['checked'] . ' فاکتور خوانده شد؛ ' . ( 'global' === $job['scope'] ? 'جست‌وجوی فهرست عمومی' : 'جست‌وجوی شماره همراه' ) . '، صفحه ' . max( 1, $job['page'] ) . '.' );
	}

	/** One list page OR one detail per request; no SaveInvoice or other financial POST here. */
	public static function step( WC_Order $order, $token = '', $allow_send = false ) {
		self::$diagnostics = self::local_diagnostics( $order, $allow_send );
		$result = self::step_core( $order, $token, $allow_send );
		if ( ! is_wp_error( $result ) && empty( $result['done'] ) ) { return $result; }
		self::$diagnostics['outcome'] = is_wp_error( $result ) ? $result->get_error_code() : $result['status'];
		$report = self::report_text( self::$diagnostics );
		if ( is_wp_error( $result ) || 'unresolved' === $result['status'] ) { RKW_Log::add( 'warn', $report ); }
		if ( is_wp_error( $result ) ) {
			$data = $result->get_error_data(); $data = is_array( $data ) ? $data : array();
			$data['diagnostics'] = self::$diagnostics; $data['report'] = $report;
			return new WP_Error( $result->get_error_code(), $result->get_error_message(), $data );
		}
		$result['diagnostics'] = self::$diagnostics; $result['report'] = $report;
		return $result;
	}

	private static function step_core( WC_Order $order, $token, $allow_send ) {
		if ( 'v21' !== rkw_settings()['api'] ) { return new WP_Error( 'rkw_check_api', 'بررسی فاکتور فقط برای API نسخه ۲۱ پشتیبانی می‌شود.' ); }
		if ( 'shop_order' !== $order->get_type() ) { return new WP_Error( 'rkw_check_order', 'سفارش فروش معتبر نیست.' ); }
		$lock = 'rkw_order_lock_' . $order->get_id();
		if ( ! add_option( $lock, array( 'started' => time(), 'operation' => 'check' ), '', false ) ) { return new WP_Error( 'rkw_check_busy', 'عملیات دیگری روی این سفارش در جریان است؛ بررسی دوباره را پس از پایان آن انجام دهید.' ); }
		try {
			// Acquire the same lock as the sender before reading local submission state.
			$fresh = wc_get_order( $order->get_id() );
			if ( $fresh instanceof WC_Order ) { $order = $fresh; }
			if ( method_exists( $order, 'read_meta_data' ) ) { $order->read_meta_data( true ); }
			return self::locked_step( $order, $token, $allow_send );
		} finally { delete_option( $lock ); }
	}

	private static function locked_step( WC_Order $order, $token, $allow_send ) {
		self::$diagnostics = self::local_diagnostics( $order, $allow_send );
		$key = self::key( $order->get_id() );
		$existing = trim( (string) $order->get_meta( '_rkw_doc_id' ) );
		if ( preg_match( '/^[1-9][0-9]*$/D', $existing ) && ! $order->get_meta( '_rkw_reconcile_required' ) ) {
			delete_transient( $key );
			return self::result( 'confirmed', 'شناسه سند از قبل ثبت شده است؛ ارسال مجدد انجام نشد.', array( 'document' => RKW_Order_List_UI::document_label( $order ) ) );
		}
		if ( 'salesorder' === $order->get_meta( '_rkw_doc_type' ) ) { return new WP_Error( 'rkw_check_type', 'سند قبلی سفارش فروش است؛ جست‌وجوی فاکتور نمی‌تواند نتیجه آن را تعیین کند. هیچ سند جدیدی ارسال نشد.' ); }
		$legacy = RKW_Migration::legacy_order_records( $order->get_id() );
		self::$diagnostics['legacy_read_ok'] = ! is_wp_error( $legacy );
		if ( is_wp_error( $legacy ) ) { return $legacy; }
		self::$diagnostics['legacy_records'] = RKW_Migration::legacy_order_summary( $legacy );
		$fingerprint = self::fingerprint( $order, $legacy );
		if ( '' === $token ) {
			$mobile = RKW_Extensions::customer_mobile_for_order( $order );
			$mobile = preg_match( '/^09[0-9]{9}$/D', $mobile ) ? $mobile : '';
			$ids = array();
			if ( preg_match( '/^[1-9][0-9]*$/D', $existing ) ) { $ids[ $existing ] = (int) $existing; }
			foreach ( $legacy as $row ) {
				$id = isset( $row['invoice_id'] ) && is_scalar( $row['invoice_id'] ) ? trim( (string) $row['invoice_id'] ) : '';
				if ( preg_match( '/^[1-9][0-9]*$/D', $id ) ) { $ids[ $id ] = (int) $id; }
			}
			$customer = (int) $order->get_meta( '_rkw_customer_id' );
			if ( ! $mobile && ! $ids && ! $customer ) { return new WP_Error( 'rkw_check_mobile', 'موبایل معتبر، شناسه مشتری یا شناسه فاکتور قبلی برای جست‌وجو موجود نیست؛ سفارش همچنان نیازمند بررسی است.' ); }
			$job = array( 'token' => wp_generate_uuid4(), 'fingerprint' => $fingerprint, 'send' => (bool) $allow_send,
				'mobile' => $mobile, 'scope' => $mobile ? 'mobile' : 'global', 'customer' => $customer, 'headers_skipped' => 0,
				'page' => 0, 'more' => '' !== $mobile || $customer > 0, 'queue' => array_values( $ids ), 'references' => $ids,
				'seen' => array(), 'pages' => array(), 'matches' => array(), 'checked' => 0, 'checks' => array() );
			return self::progress( $key, $job );
		}
		$job = get_transient( $key );
		if ( ! is_array( $job ) || ! isset( $job['token'] ) || ! hash_equals( $job['token'], $token ) ) { return new WP_Error( 'rkw_check_expired', 'بررسی منقضی شده یا در پنجره دیگری آغاز شده است؛ بررسی را از ابتدا شروع کنید.' ); }
		if ( ! isset( $job['scope'] ) ) { delete_transient( $key ); return new WP_Error( 'rkw_check_expired', 'روش جست‌وجو به‌روزرسانی شده است؛ بررسی را از ابتدا شروع کنید.' ); }
		if ( ! hash_equals( $job['fingerprint'], $fingerprint ) || $job['send'] !== (bool) $allow_send ) {
			delete_transient( $key ); return new WP_Error( 'rkw_check_changed', 'سفارش، سوابق قدیمی یا تنظیمات تغییر کرده است؛ بررسی را از ابتدا شروع کنید. هیچ سندی ارسال نشد.' );
		}
		self::job_diagnostics( $job );
		$client = new RKW_Client();
		if ( $job['queue'] ) {
			$id = array_shift( $job['queue'] );
			if ( ! isset( $job['seen'][ $id ] ) ) {
				$detail = $client->invoice21( $id );
				if ( is_wp_error( $detail ) ) { delete_transient( $key ); return $detail; }
				if ( self::invoice_id( $detail ) !== $id ) { delete_transient( $key ); return new WP_Error( 'rkw_check_detail', 'پاسخ جزئیات فاکتور با شناسه درخواست مطابقت ندارد؛ هیچ نتیجه‌ای تأیید نشد.' ); }
				$job['seen'][ $id ] = true; $job['checked']++;
				if ( count( isset( $job['checks'] ) ? $job['checks'] : array() ) < self::MAX_REPORT_ROWS ) { $job['checks'][] = self::inspect_invoice( $detail, $order ); }
				self::job_diagnostics( $job );
				if ( isset( $job['references'][ $id ] ) && ! self::matches( $detail, $order ) ) { delete_transient( $key ); return self::result( 'unresolved', 'شناسه فاکتور موجود در سوابق قبلی با این سفارش مطابقت ندارد؛ سوابق حفظ شد و ارسال جدید انجام نشد.' ); }
				if ( self::matches( $detail, $order ) ) { $job['matches'][ $id ] = $id; }
				self::job_diagnostics( $job );
				if ( count( $job['matches'] ) > 1 ) { delete_transient( $key ); return self::result( 'unresolved', 'بیش از یک فاکتور با شماره این سفارش پیدا شد؛ برای بررسی فاکتور تکراری اقدام کنید. هیچ سند جدیدی ارسال نشد.' ); }
			}
			return self::progress( $key, $job );
		}
		if ( $job['more'] ) {
			if ( $job['page'] >= self::MAX_PAGES ) { delete_transient( $key ); return self::result( 'unresolved', 'جست‌وجو به سقف ۲۰۰ صفحه رسید و کامل نشد؛ هیچ سندی ارسال یا تأیید نشد.' ); }
			$job['page']++;
			self::job_diagnostics( $job );
			$response = $client->invoices21( $job['page'], self::PAGE_SIZE, '', 'mobile' === $job['scope'] ? $job['mobile'] : '' );
			if ( is_wp_error( $response ) ) { delete_transient( $key ); return $response; }
			$rows = is_array( $response ) && isset( $response['items'] ) ? $response['items'] : $response;
			if ( ! is_array( $rows ) || array_values( $rows ) !== $rows ) { delete_transient( $key ); return new WP_Error( 'rkw_check_list', 'قالب فهرست فاکتورها معتبر نیست؛ خالی‌بودن جست‌وجو تأیید نشد.' ); }
			$ids = array();
			foreach ( $rows as $row ) {
				$id = self::invoice_id( $row );
				if ( ! $id ) { delete_transient( $key ); return new WP_Error( 'rkw_check_list', 'شناسه معتبر فاکتور در فهرست موجود نیست؛ بررسی متوقف شد.' ); }
				$ids[] = $id;
			}
			$signature_ids = $ids; sort( $signature_ids, SORT_NUMERIC ); $page_hash = hash( 'sha256', wp_json_encode( $signature_ids ) );
			if ( $ids && isset( $job['pages'][ $page_hash ] ) ) { delete_transient( $key ); return new WP_Error( 'rkw_check_repeat', 'راهکاران صفحه تکراری برگرداند؛ پایان جست‌وجو قابل تأیید نیست و هیچ سندی ارسال نشد.' ); }
			$job['pages'][ $page_hash ] = true;
			// The documented list contains headers, usually without description. Read GetInvoice for each ID.
			$eligible_ids = array();
			foreach ( $rows as $row ) {
				$id = self::invoice_id( $row );
				if ( 'global' === $job['scope'] ) {
					$s = rkw_settings(); $amount = round( (float) $order->get_total() * rkw_price_multiplier( $s ), 2 );
					$wrong = ( isset( $row['netPrice'] ) && is_numeric( $row['netPrice'] ) && abs( (float) $row['netPrice'] - $amount ) > 0.01 ) ||
						( $job['customer'] && isset( $row['customerId'] ) && (int) $row['customerId'] !== $job['customer'] ) ||
						( isset( $row['currencyId'] ) && (int) $row['currencyId'] !== (int) $s['currency_id'] );
					if ( ! $job['customer'] && ( ! isset( $row['customerMobile'] ) || RKW_Orders::normalize_mobile( $row['customerMobile'] ) !== $job['mobile'] ) ) { $wrong = true; }
					if ( $wrong ) { $job['headers_skipped']++; continue; }
				}
				if ( ! isset( $job['seen'][ $id ] ) ) { $eligible_ids[ $id ] = $id; }
			}
			$job['queue'] = array_values( $eligible_ids );
			$job['more'] = count( $rows ) >= self::PAGE_SIZE;
			return self::progress( $key, $job );
		}
		if ( ! $job['matches'] ) {
			if ( 'mobile' === $job['scope'] ) {
				$job['scope'] = 'global'; $job['page'] = 0; $job['pages'] = array(); $job['more'] = true;
				return self::progress( $key, $job );
			}
			delete_transient( $key );
			$uncertain = '' !== $existing || $order->get_meta( '_rkw_reconcile_required' ) || $legacy;
			if ( $job['send'] && ! $uncertain ) {
				return self::result( 'ready', 'فاکتور منطبقی در جست‌وجو پیدا نشد و سابقه ارسال نامشخصی وجود ندارد؛ ارسال از مسیر معمول افزونه بررسی می‌شود.' );
			}
			return self::result( 'unresolved', 'در ' . $job['checked'] . ' فاکتور قابل مشاهده، فاکتور منطبق پیدا نشد. علت توقف: ' . self::blocker_text( self::$diagnostics ) . '؛ گزارش جزئیات بررسی زیر همین سفارش و در بخش گزارش‌ها ثبت شد. هیچ سند جدیدی ارسال نشد.' );
		}
		$id = (int) reset( $job['matches'] );
		$detail = $client->invoice21( $id );
		if ( is_wp_error( $detail ) ) { delete_transient( $key ); return $detail; }
		self::$diagnostics['final_validation'] = self::inspect_invoice( $detail, $order );
		$s = rkw_settings(); $expected = round( (float) $order->get_total() * rkw_price_multiplier( $s ), 2 );
		if ( self::invoice_id( $detail ) !== $id || ! self::matches( $detail, $order ) ||
			! isset( $detail['netPrice'] ) || ! is_numeric( $detail['netPrice'] ) || abs( (float) $detail['netPrice'] - $expected ) > 0.01 ||
			( isset( $detail['currencyId'] ) && (int) $detail['currencyId'] !== (int) $s['currency_id'] ) ||
			( preg_match( '/^[1-9][0-9]*$/D', $existing ) && (int) $existing !== $id ) ) {
			delete_transient( $key ); return self::result( 'unresolved', 'فاکتور پیدا شد، اما شناسه، مشتری، توضیحات، مبلغ یا ارز آن با سفارش سازگار نیست؛ اتصال و ارسال جدید انجام نشد.' );
		}
		$fresh = wc_get_order( $order->get_id() );
		if ( $fresh instanceof WC_Order ) { $order = $fresh; }
		if ( method_exists( $order, 'read_meta_data' ) ) { $order->read_meta_data( true ); }
		$legacy = RKW_Migration::legacy_order_records( $order->get_id() );
		if ( is_wp_error( $legacy ) || ! hash_equals( $job['fingerprint'], self::fingerprint( $order, $legacy ) ) ) {
			delete_transient( $key ); return new WP_Error( 'rkw_check_changed', 'اطلاعات سفارش هنگام خواندن راهکاران تغییر کرد؛ تطبیق ذخیره نشد. دوباره بررسی کنید.' );
		}
		$order->update_meta_data( '_rkw_doc_id', (string) $id );
		$order->update_meta_data( '_rkw_doc_type', 'invoice' );
		$order->delete_meta_data( '_rkw_reconcile_required' ); $order->delete_meta_data( '_rkw_error' ); $order->save();
		wp_clear_scheduled_hook( 'rkw_send_order', array( (int) $order->get_id() ) );
		RKW_Order_List_UI::clear_document_cache(); RKW_Snapshot::invalidate_section( 'invoices' ); delete_transient( $key );
		$message = 'فاکتور #' . $id . ' در راهکاران تأیید و به سفارش متصل شد؛ ارسال مجدد انجام نشد.';
		$order->add_order_note( $message ); RKW_Log::add( 'info', 'تطبیق سفارش #' . $order->get_id() . ': ' . $message );
		return self::result( 'confirmed', $message, array( 'document' => RKW_Order_List_UI::document_label( $order ) ) );
	}

	private static function local_diagnostics( WC_Order $order, $allow_send ) {
		$id = trim( (string) $order->get_meta( '_rkw_doc_id' ) );
		$valid = (bool) preg_match( '/^[1-9][0-9]*$/D', $id );
		$s = rkw_settings(); $sender = RKW_Migration::legacy_sender_status();
		return array( 'order_id' => (int) $order->get_id(), 'read_only' => ! $allow_send,
			'local_document_id' => $valid ? (int) $id : null, 'invalid_local_id' => '' !== $id && ! $valid,
			'uncertain_submission' => (bool) $order->get_meta( '_rkw_reconcile_required' ),
			'attempts' => (int) $order->get_meta( '_rkw_attempts' ), 'previous_error_recorded' => '' !== (string) $order->get_meta( '_rkw_error' ),
			'legacy_read_ok' => null, 'legacy_records' => array(), 'legacy_sender_active' => (bool) $sender['automatic_sender_active'],
			'expected_amount' => round( (float) $order->get_total() * rkw_price_multiplier( $s ), 2 ),
			'expected_currency_id' => (int) $s['currency_id'], 'local_customer_id_recorded' => (bool) $order->get_meta( '_rkw_customer_id' ),
			'pages_requested' => 0, 'checked' => 0, 'matches' => 0, 'visible_search_finished' => false, 'checks' => array() );
	}

	private static function job_diagnostics( $job ) {
		self::$diagnostics['pages_requested'] = (int) $job['page'];
		self::$diagnostics['checked'] = (int) $job['checked'];
		self::$diagnostics['matches'] = count( $job['matches'] );
		self::$diagnostics['visible_search_finished'] = ! $job['more'] && ! $job['queue'];
		self::$diagnostics['mobile_search_used'] = '' !== $job['mobile'];
		self::$diagnostics['search_scope'] = $job['scope'];
		self::$diagnostics['global_headers_skipped'] = $job['headers_skipped'];
		self::$diagnostics['checks'] = isset( $job['checks'] ) ? $job['checks'] : array();
	}

	/** Store comparison facts only: never the description, phone, name, address or raw response. */
	private static function inspect_invoice( $invoice, WC_Order $order ) {
		$s = rkw_settings(); $invoice = is_array( $invoice ) ? $invoice : array();
		$location = 'missing';
		if ( isset( $invoice['description'] ) && is_string( $invoice['description'] ) && '' !== trim( $invoice['description'] ) ) { $location = 'description'; }
		elseif ( isset( $invoice['Description'] ) && is_string( $invoice['Description'] ) && '' !== trim( $invoice['Description'] ) ) { $location = 'Description'; }
		else {
			foreach ( array( 'document', 'invoice' ) as $key ) {
				if ( isset( $invoice[ $key ]['description'] ) && is_string( $invoice[ $key ]['description'] ) && '' !== trim( $invoice[ $key ]['description'] ) ) { $location = $key . '.description'; break; }
			}
		}
		$customer = (int) $order->get_meta( '_rkw_customer_id' );
		$for_marker = $invoice; $for_marker['customerId'] = $customer;
		$marker = self::matches( $for_marker, $order );
		$has_marker = 'description' === $location && (bool) preg_match( '/ووکامرس\s*:|سفارش سایت\s*#/u', self::normalized_text( $invoice['description'] ) );
		$customer_match = $customer ? ( isset( $invoice['customerId'] ) && (int) $invoice['customerId'] === $customer ) : null;
		$amount = isset( $invoice['netPrice'] ) && is_numeric( $invoice['netPrice'] ) ? (float) $invoice['netPrice'] : null;
		$amount_match = null === $amount ? null : abs( $amount - round( (float) $order->get_total() * rkw_price_multiplier( $s ), 2 ) ) <= 0.01;
		$currency_match = isset( $invoice['currencyId'] ) ? (int) $invoice['currencyId'] === (int) $s['currency_id'] : null;
		if ( 'missing' === $location ) { $reason = 'description_missing'; }
		elseif ( 'description' !== $location ) { $reason = 'description_location'; }
		elseif ( ! $has_marker ) { $reason = 'order_marker_missing'; }
		elseif ( ! $marker ) { $reason = 'order_marker_mismatch'; }
		elseif ( false === $customer_match ) { $reason = 'customer_mismatch'; }
		elseif ( null === $amount_match ) { $reason = 'amount_missing'; }
		elseif ( ! $amount_match ) { $reason = 'amount_mismatch'; }
		elseif ( false === $currency_match ) { $reason = 'currency_mismatch'; }
		else { $reason = 'identity_matches'; }
		return array( 'invoice_id' => self::invoice_id( $invoice ), 'description_location' => $location,
			'order_marker_present' => $has_marker, 'order_marker_matches' => $marker, 'customer_matches' => $customer_match,
			'net_amount' => $amount, 'amount_matches' => $amount_match, 'currency_matches' => $currency_match, 'reason' => $reason );
	}

	private static function blocker_text( $d ) {
		$parts = array();
		if ( $d['uncertain_submission'] ) { $parts[] = 'علامت نتیجه نامعلومِ درخواست ثبت قبلی در سایت فعال است'; }
		if ( $d['invalid_local_id'] ) { $parts[] = 'شناسه ذخیره‌شده قبلی معتبر نیست'; }
		if ( $d['local_document_id'] && $d['uncertain_submission'] ) { $parts[] = 'شناسه قبلی هنوز تأیید نشده است'; }
		if ( $d['legacy_records'] ) { $parts[] = count( $d['legacy_records'] ) . ' رکورد صف/فاکتور در افزونه قدیمی موجود است'; }
		if ( false === $d['legacy_read_ok'] ) { $parts[] = 'خواندن سوابق افزونه قدیمی از پایگاه داده ناموفق بود'; }
		if ( $d['legacy_sender_active'] ) { $parts[] = 'ارسال خودکار افزونه قدیمی فعال است'; }
		if ( ! $parts ) { $parts[] = $d['read_only'] ? 'عملیات انتخاب‌شده فقط بررسی است و مجوز ارسال ندارد' : 'ثبت‌نشدن قطعی از این جست‌وجو مشخص نیست'; }
		return implode( '؛ ', $parts );
	}

	private static function report_text( $d ) {
		$yes = static function ( $v ) { return $v ? 'بله' : 'خیر'; };
		$comparison = static function ( $v ) { return null === $v ? 'اطلاعات کافی نیست' : ( $v ? 'منطبق' : 'نامنطبق' ); };
		$reasons = array( 'description_missing' => 'توضیحات فاکتور در پاسخ جزئیات موجود نیست یا خالی است',
			'description_location' => 'توضیحات در فیلدی متفاوت از قالب مورد انتظار قرار دارد',
			'order_marker_missing' => 'عبارت شماره سفارش ووکامرس در توضیحات وجود ندارد',
			'order_marker_mismatch' => 'شماره یا قالب عبارت سفارش با این سفارش مطابقت ندارد',
			'customer_mismatch' => 'شناسه مشتری با شناسه ثبت‌شده سفارش متفاوت است',
			'amount_missing' => 'مبلغ خالص معتبر در پاسخ نیست', 'amount_mismatch' => 'مبلغ خالص با مبلغ سفارش پس از تبدیل واحد برابر نیست',
			'currency_mismatch' => 'شناسه ارز متفاوت است', 'identity_matches' => 'مشخصات بررسی‌شده منطبق‌اند؛ یکتایی و تأیید نهایی جداگانه بررسی می‌شوند' );
		$lines = array( 'گزارش بررسی سفارش ووکامرس #' . $d['order_id'], 'کد نتیجه: ' . $d['outcome'],
			'نوع عملیات: ' . ( $d['read_only'] ? 'بررسی و تطبیق بدون صدور سند جدید' : 'بررسی پیش از ارسال موارد مجاز' ),
			'وضعیت سوابق پیش از بررسی: ' . self::blocker_text( $d ),
			'اطلاعات محلی زیر وضعیت پیش از ثبت نتیجه نهایی را نشان می‌دهد.',
			'علامت نتیجه نامعلوم ارسال قبلی: ' . $yes( $d['uncertain_submission'] ),
			'شناسه محلی سند: ' . ( $d['local_document_id'] ? '#' . $d['local_document_id'] : ( $d['invalid_local_id'] ? 'نامعتبر' : 'ثبت نشده' ) ),
			'تعداد تلاش‌های ثبت‌شده افزونه: ' . $d['attempts'], 'خطای قبلی ثبت شده است: ' . $yes( $d['previous_error_recorded'] ),
			'خواندن سوابق قدیمی: ' . ( null === $d['legacy_read_ok'] ? 'انجام نشده' : ( $d['legacy_read_ok'] ? 'موفق' : 'ناموفق' ) ) );
		foreach ( array_slice( $d['legacy_records'], 0, self::MAX_REPORT_ROWS ) as $r ) {
			$lines[] = 'رکورد قدیمی #' . $r['record_id'] . ' | وضعیت: ' . $r['post_status'] . ' | شناسه فاکتور: ' . ( $r['invoice_id'] ? '#' . $r['invoice_id'] : ( $r['invoice_id_recorded'] ? 'نامعتبر' : 'ذخیره نشده' ) );
		}
		$lines[] = 'تعداد رکوردهای قدیمی: ' . count( $d['legacy_records'] );
		$lines[] = 'دامنه جست‌وجو: ' . ( isset( $d['search_scope'] ) && 'global' === $d['search_scope'] ? 'فهرست عمومی راهکاران؛ جزئیات با شناسه مشتری/مبلغ/ارز سازگار بررسی می‌شوند' : ( ! empty( $d['mobile_search_used'] ) ? 'فاکتورهای شماره همراه همین سفارش و شناسه‌های قبلی' : 'شناسه‌های قبلی یا جست‌وجو هنوز آغاز نشده است' ) );
		if ( isset( $d['global_headers_skipped'] ) ) { $lines[] = 'سرآیندهای نامرتبط کنارگذاشته‌شده در جست‌وجوی عمومی: ' . $d['global_headers_skipped']; }
		$lines[] = 'آخرین صفحه درخواست‌شده: ' . $d['pages_requested'] . ' | جزئیات خوانده‌شده: ' . $d['checked'] . ' | شماره سفارش و مشتری منطبق: ' . $d['matches'];
		$lines[] = 'پایان فهرست قابل مشاهده: ' . $yes( $d['visible_search_finished'] );
		$lines[] = 'شناسه مشتری محلی موجود است: ' . $yes( $d['local_customer_id_recorded'] );
		$lines[] = 'مبلغ مورد انتظار به واحد راهکاران: ' . $d['expected_amount'] . ' | شناسه ارز تنظیم‌شده: ' . $d['expected_currency_id'];
		$rows = $d['checks'];
		if ( isset( $d['final_validation'] ) ) { $lines[] = 'تأیید نهایی دوباره خوانده شد:'; $rows[] = $d['final_validation']; }
		foreach ( $rows as $r ) {
			$lines[] = 'فاکتور #' . $r['invoice_id'] . ': ' . $reasons[ $r['reason'] ];
			$lines[] = '  محل توضیحات: ' . $r['description_location'] . ' | شماره سفارش: ' . $comparison( $r['order_marker_matches'] ) . ' | مشتری: ' . $comparison( $r['customer_matches'] );
			$lines[] = '  مبلغ خالص: ' . ( null === $r['net_amount'] ? 'ارائه نشده' : $r['net_amount'] ) . ' | مبلغ: ' . $comparison( $r['amount_matches'] ) . ' | ارز: ' . $comparison( $r['currency_matches'] );
		}
		if ( $d['checked'] > count( $d['checks'] ) ) { $lines[] = 'جزئیات نمونه برای ' . count( $d['checks'] ) . ' فاکتور از ' . $d['checked'] . ' فاکتور خوانده‌شده نگه داشته شده است.'; }
		$lines[] = 'فهرست خالی یا بدون تطبیق، نبودن قطعی فاکتور را ثابت نمی‌کند. این گزارش شامل متن توضیحات یا اطلاعات تماس مشتری نیست.';
		return implode( "\n", $lines );
	}

	public static function ajax_check( $legacy_nonce = false ) {
		if ( ! current_user_can( 'manage_woocommerce' ) || ! check_ajax_referer( $legacy_nonce ? 'rkw_module' : 'rkw_order_send', 'nonce', false ) ) {
			wp_send_json_error( array( 'message' => 'دسترسی یا نشست نامعتبر است.' ), 403 );
		}
		$id = isset( $_POST['order_id'] ) && is_scalar( $_POST['order_id'] ) ? absint( $_POST['order_id'] ) : 0;
		$token = isset( $_POST['token'] ) && is_string( $_POST['token'] ) ? sanitize_text_field( wp_unslash( $_POST['token'] ) ) : '';
		$order = $id ? wc_get_order( $id ) : false;
		if ( ! $order instanceof WC_Order ) { wp_send_json_error( array( 'message' => 'سفارش ووکامرس یافت نشد.' ), 404 ); }
		$send = ! $legacy_nonce && isset( $_POST['allow_send'] ) && '1' === $_POST['allow_send'];
		$result = self::step( $order, $token, $send );
		if ( is_wp_error( $result ) ) {
			$data = $result->get_error_data(); $data = is_array( $data ) ? $data : array();
			wp_send_json_error( array( 'message' => $result->get_error_message(), 'code' => $result->get_error_code(), 'report' => isset( $data['report'] ) ? $data['report'] : '', 'diagnostics' => isset( $data['diagnostics'] ) ? $data['diagnostics'] : array() ), 409 );
		}
		$result['id'] = $id; wp_send_json_success( $result );
	}
}
