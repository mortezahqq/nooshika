/* Run with Playwright and a local Chromium. All AJAX traffic is intercepted; no live documents. */
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const {execFileSync} = require('node:child_process');
const {chromium} = require('playwright');
const root = path.resolve(__dirname, '..');
const php = process.env.RKW_TEST_PHP || 'php';
const ajax = 'https://wordpress.example.invalid/wp-admin/admin-ajax.php';
const asset = file => path.join(root, 'rahkaran-woo/assets', file);
function phpHTML() {
  const bootstrap = path.join(__dirname, 'bootstrap.php').replace(/'/g, "\\'");
  return execFileSync(php, ['-n', '-r', `require '${bootstrap}';function esc_url($v){return esc_attr($v);}$_GET['page']='rkw-invoices';RKW_Modules::page();RKW_Returns::modal();`], {encoding: 'utf8'});
}
async function intercept(page, handler) {
  await page.route('https://wordpress.example.invalid/**', async route => {
    const data = Object.fromEntries(new URLSearchParams(route.request().postData() || ''));
    const result = await handler(data);
    if (result === 'abort') return route.abort('failed');
    return route.fulfill({status: 200, contentType: 'application/json', headers: {'Access-Control-Allow-Origin': '*'}, body: JSON.stringify(result)});
  });
}
const success = data => ({success: true, data});
async function invoicePage(browser, submitResult) {
  const page = await browser.newPage();
  const errors = []; page.on('pageerror', e => errors.push(e.message));
  let writes = 0;
  await intercept(page, data => {
    if (data.action === 'rkw_module_list') return success({headers: ['شناسه'], rows: [
      {id: 55, cells: ['55'], detail: true, return_status: {state: 'available'}},
      {id: 56, cells: ['56'], detail: true, return_status: {state: 'returned', id: 502}},
      {id: 57, cells: ['57'], detail: true, return_status: {state: 'pending'}}
    ], total: 3, count: 3, has_next: false, saved_at: Math.floor(Date.now() / 1000), persisted: true});
    if (data.action === 'rkw_return_prepare') return success({invoice_id: 55, amount: 1000, currency: 'ریال', item_count: 1, pattern_id: 7, policy_id: 77, fingerprint: 'synthetic-preview', policies: [{id: 77, title: 'Synthetic return', keys: ['Cash', 'BankReceipt', 'ThirdPartyCoupon']}]});
    if (data.action === 'rkw_return_submit') {
      writes++; assert.equal(data.confirm, '1'); assert.equal(data.receipt_key, 'Cash');
      assert.equal(data.policy_id, '77'); assert.equal(data.fingerprint, 'synthetic-preview');
      assert(!('document' in data)); return submitResult;
    }
    throw Error('Unexpected browser action: ' + data.action);
  });
  await page.setContent(phpHTML());
  await page.addStyleTag({path: asset('admin.css')});
  await page.evaluate(url => {
    window.rkwModules = {ajax: url, nonce: 'synthetic', section: 'invoices', initial: {}};
    window.rkwReturns = {ajax: url, nonce: 'synthetic'};
  }, ajax);
  await page.addScriptTag({path: asset('admin.js')});
  await page.addScriptTag({path: asset('returns.js')});
  await page.locator('#rkwm-remote-invoices > summary').click();
  await page.waitForSelector('.rkw-return-invoice[data-invoice="55"]');
  assert(await page.locator('.rkw-return-invoice[data-invoice="56"]').isDisabled());
  assert.match(await page.locator('.rkw-return-invoice[data-invoice="56"]').textContent(), /502/);
  assert(await page.locator('.rkw-return-invoice[data-invoice="57"]').isDisabled());
  return {page, errors, writes: () => writes};
}
(async () => {
  const browser = await chromium.launch({headless: true, executablePath: process.env.RKW_TEST_CHROMIUM || '/usr/bin/chromium', args: ['--no-sandbox']});
  try {
    const page = await browser.newPage();
    const errors = []; page.on('pageerror', e => errors.push(e.message));
    page.on('dialog', dialog => dialog.accept());
    await intercept(page, data => {
      const id = Number(data['order_ids[]']);
      return success({items: [{id, status: id === 102 ? 'skipped' : (id === 103 ? 'blocked' : 'sent'), document: id === 103 ? undefined : 'فاکتور #' + (id === 102 ? '701' : '501'), message: 'synthetic result'}]});
    });
    await page.setContent('<div class="wrap"><div id="rkw-local-send-status"></div>' + [101, 102, 103].map(id => `<span class="rkw-order-doc" data-order="${id}">—</span><span class="rkw-order-actions" data-order="${id}"><button class="rkw-send-one" data-order="${id}">ارسال</button></span>`).join('') + '</div>');
    await page.evaluate(url => { window.rkwOrderActions = {ajax: url, nonce: 'synthetic'}; }, ajax);
    await page.addScriptTag({path: asset('order-actions.js')});
    for (const id of [101, 102, 103]) {
      await page.locator('.rkw-send-one[data-order="' + id + '"]').click();
      await page.waitForFunction(id => !document.querySelector('.rkw-order-actions[data-order="' + id + '"] .rkw-send-one'), id);
    }
    assert.match(await page.locator('.rkw-order-doc[data-order="101"]').textContent(), /501/);
    assert.match(await page.locator('.rkw-order-actions[data-order="101"]').textContent(), /501/);
    assert.match(await page.locator('.rkw-order-actions[data-order="102"]').textContent(), /701/);
    assert.match(await page.locator('.rkw-order-actions[data-order="103"]').textContent(), /بررسی/);
    assert.deepEqual(errors, []); await page.close();
    console.log('PASS browser: sent, already-sent and pending order rows replace send buttons correctly');

    const flow = await invoicePage(browser, success({message: 'برگشت ثبت شد #501', return_status: {state: 'returned', id: 501}}));
    await flow.page.locator('.rkw-return-invoice[data-invoice="55"]').click();
    await flow.page.waitForSelector('#rkw-return-form:not([hidden])');
    assert.equal(flow.writes(), 0);
    await flow.page.locator('#rkw-return-method').selectOption('BankReceipt');
    assert(await flow.page.locator('#rkw-return-bank-fields').isVisible());
    assert(await flow.page.locator('#rkw-return-bank').evaluate(el => el.required));
    await flow.page.locator('#rkw-return-method').selectOption('Cash');
    assert(!await flow.page.locator('#rkw-return-bank').evaluate(el => el.required));
    await flow.page.locator('#rkw-return-confirm').check();
    await flow.page.locator('#rkw-return-submit').click();
    await flow.page.waitForFunction(() => document.querySelector('.rkw-return-invoice[data-invoice="55"]').disabled);
    assert.equal(flow.writes(), 1);
    assert.match(await flow.page.locator('.rkw-return-invoice[data-invoice="55"]').textContent(), /501/);
    assert(!await flow.page.locator('#rkw-return-form').isVisible());
    await flow.page.locator('#rkw-return-close').click();
    assert(!await flow.page.locator('#rkw-return-modal').isVisible());
    assert.deepEqual(flow.errors, []); await flow.page.close();
    console.log('PASS browser: live invoice-table return button, preview, payment fields, confirmation and saved-id display');

    const timeout = await invoicePage(browser, 'abort');
    await timeout.page.locator('.rkw-return-invoice[data-invoice="55"]').click();
    await timeout.page.waitForSelector('#rkw-return-form:not([hidden])');
    await timeout.page.locator('#rkw-return-method').selectOption('Cash');
    await timeout.page.locator('#rkw-return-confirm').check();
    await timeout.page.locator('#rkw-return-submit').click();
    await timeout.page.waitForFunction(() => document.querySelector('.rkw-return-invoice[data-invoice="55"]').disabled);
    assert.equal(timeout.writes(), 1); assert.match(await timeout.page.locator('#rkw-return-feedback').textContent(), /نتیجه نامشخص/);
    assert(!await timeout.page.locator('#rkw-return-form').isVisible());
    assert.deepEqual(timeout.errors, []); await timeout.page.close();
    console.log('PASS browser: interrupted return request disables resubmission and reports unknown outcome');
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exitCode = 1; });
