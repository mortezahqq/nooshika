<?php
define('RKW_CATALOG_FIXTURES_ONLY',true);define('RKW_TEST_NO_AS',true);define('DISABLE_WP_CRON',true);
require __DIR__.'/catalog-runner.php';
function spawn_cron(){$GLOBALS['spawn_calls']=($GLOBALS['spawn_calls']??0)+1;return true;}
catalog_reset();
RKW_Sync_Runner::kick();check(wp_next_scheduled(RKW_Sync_Runner::HOOK)<=time());check($GLOBALS['spawn_calls']===1);RKW_Sync_Runner::kick();check($GLOBALS['spawn_calls']===1);
wp_clear_scheduled_hook(RKW_Sync_Runner::HOOK);RKW_Sync_Runner::work();check(get_option(RKW_Sync::CURSOR)['processed']===5);check(wp_next_scheduled(RKW_Sync_Runner::HOOK)<=time());check($GLOBALS['spawn_calls']===2);
$text=RKW_Sync_Runner::status();check(strpos($text,'WP-Cron غیرفعال است')!==false);check(strpos($text,'صف ووکامرس در دسترس نیست')!==false);
RKW_Sync_Runner::cancel_pending();check(!wp_next_scheduled(RKW_Sync_Runner::HOOK));
echo "PASS fallback: due-now continuation, deduplication, persisted progress and explicit host-cron requirement\n";
