<?php
define('RKW_AUTO_PRODUCT_FIXTURES_ONLY',true);
require __DIR__.'/auto-product.php';

class CatalogDB extends TestDB {
 public $options='wp_options';
 function query($sql){$key=$this->last_args[0];$value=$this->last_args[1];if(isset($GLOBALS['options'][$key])&&$GLOBALS['options'][$key]===$value){unset($GLOBALS['options'][$key]);return 1;}return 0;}
}
function wp_cache_delete($key,$group=''){}
function wc_get_product_id_by_sku($sku){foreach($GLOBALS['products']as$p)if($p->sku===$sku)return $p->id;return 0;}
function wp_schedule_event($time,$interval,$hook){$GLOBALS['cron'][$hook]=['time'=>$time,'interval'=>$interval];return true;}
function wp_schedule_single_event($time,$hook){$GLOBALS['cron'][$hook]=['time'=>$time,'interval'=>''];return true;}
function wp_clear_scheduled_hook($hook){unset($GLOBALS['cron'][$hook]);}
function wp_next_scheduled($hook){return $GLOBALS['cron'][$hook]['time']??false;}
function wp_get_schedule($hook){return $GLOBALS['cron'][$hook]['interval']??false;}
function wp_date($format,$time){return date($format,$time);}
if(!defined('RKW_TEST_NO_AS')){
 function as_get_scheduled_actions($args,$format='OBJECT'){$found=[];foreach($GLOBALS['actions']as$id=>$a)if($a['hook']===$args['hook']&&$a['group']===$args['group']&&$a['status']===$args['status'])$found[]=$id;return array_slice($found,0,$args['per_page']??100);}
 function as_enqueue_async_action($hook,$args=[],$group='',$unique=false){if(!empty($GLOBALS['queue_fail']))return 0;$id=count($GLOBALS['actions'])+1;$GLOBALS['actions'][$id]=['hook'=>$hook,'args'=>$args,'group'=>$group,'status'=>'pending'];return $id;}
 function as_unschedule_all_actions($hook,$args=[],$group=''){foreach($GLOBALS['actions']as$id=>$a)if($a['hook']===$hook&&$a['group']===$group&&$a['status']==='pending')unset($GLOBALS['actions'][$id]);}
}
function catalog_reset(){
 auto_reset();$GLOBALS['wpdb']=new CatalogDB;$GLOBALS['products']=[];$GLOBALS['cron']=[];$GLOBALS['actions']=[];$GLOBALS['queue_fail']=false;$GLOBALS['options'][RKW_OPT]['batch_size']=10;
 for($id=1;$id<=7;$id++){$p=new SyncProduct(100+$id,$id);$p->sku='SKU-'.$id;$GLOBALS['products'][$p->id]=$p;}
 $GLOBALS['http_handler']=function($url,$args){check($args['method']==='GET');if(strpos($url,'/GetProducts?')!==false)return response(catalog_rows());if(strpos($url,'GetRemainingQuantityInfo')!==false)return response([['StoreID'=>2,'RemainingQuantity'=>4]]);throw new RuntimeException('unexpected endpoint '.$url);};
}
function catalog_rows($fee=9000){$rows=[];for($id=1;$id<=7;$id++)$rows[]=['productId'=>$id,'productNumber'=>'SKU-'.$id,'fee'=>$fee,'RetailUnitRef'=>1];return $rows;}
function run_pending(){foreach($GLOBALS['actions']as$id=>$action)if($action['status']==='pending'&&$action['hook']===RKW_Sync_Runner::HOOK){$GLOBALS['actions'][$id]['status']='in-progress';RKW_Sync_Runner::work();$GLOBALS['actions'][$id]['status']='complete';return true;}return false;}
function pending_count(){return count(as_get_scheduled_actions(['hook'=>RKW_Sync_Runner::HOOK,'group'=>RKW_Sync_Runner::GROUP,'status'=>'pending','per_page'=>100],'ids'));}
if(defined('RKW_CATALOG_FIXTURES_ONLY'))return;
$tests=[];
$tests['five-item slices checkpoint each product and resume remaining page without refetch']=function(){
 $r=RKW_Sync::step();check(!$r['done']&&$r['processed']===5&&$r['updated']===5);check(count(get_option(RKW_Sync::CURSOR)['pending_items'])===2);check(count($GLOBALS['http_calls'])===6);check(!get_option(RKW_Sync::LOCK));
 $r=RKW_Sync::step();check($r['done']&&$r['processed']===7&&$r['updated']===7);check(count($GLOBALS['http_calls'])===8);check(!get_option(RKW_Sync::CURSOR));foreach($GLOBALS['products']as$p)check($p->saves===1&&$p->regular==='900'&&$p->qty===4);
};
$tests['elapsed budget is tested after each item instead of waiting for a complete page']=function(){
 $r=RKW_Sync::step(false,20,0);check(!$r['done']&&$r['processed']===1);check(count(get_option(RKW_Sync::CURSOR)['pending_items'])===6);$r=RKW_Sync::step(false,20,0);check($r['processed']===2);check(count($GLOBALS['http_calls'])===3);
};
$tests['interrupted item resumes from persisted progress without repeating completed products']=function(){
 $stock_calls=0;$GLOBALS['http_handler']=function($url)use(&$stock_calls){if(strpos($url,'/GetProducts?')!==false)return response(catalog_rows());$stock_calls++;check(get_option(RKW_Sync::CURSOR)['processed']===$stock_calls-1);if($stock_calls===3)throw new RuntimeException('synthetic interruption');return response([['StoreID'=>2,'RemainingQuantity'=>4]]);};
 try{RKW_Sync::step();check(false);}catch(RuntimeException$e){check($e->getMessage()==='synthetic interruption');}check(!get_option(RKW_Sync::LOCK));check(get_option(RKW_Sync::CURSOR)['processed']===2);check($GLOBALS['products'][101]->saves===1&&$GLOBALS['products'][102]->saves===1&&$GLOBALS['products'][103]->saves===0);
 $GLOBALS['http_handler']=fn($url)=>response([['StoreID'=>2,'RemainingQuantity'=>4]]);$r=RKW_Sync::step();check($r['done']&&$r['updated']===7);foreach($GLOBALS['products']as$p)check($p->saves===1);
};
$tests['active atomic lock prevents a manual reset from losing worker progress']=function(){
 $lease=json_encode(['token'=>'other','expires'=>time()+200]);$GLOBALS['options'][RKW_Sync::LOCK]=$lease;$GLOBALS['options'][RKW_Sync::CURSOR]=['processed'=>99];expect_error(RKW_Sync::step(true),'rkw_sync_busy');check(get_option(RKW_Sync::CURSOR)===['processed'=>99]);check(!$GLOBALS['http_calls']);check(get_option(RKW_Sync::LOCK)===$lease);
};
$tests['expired lease can be reclaimed and old worker cannot remove a replacement lease']=function(){
 $GLOBALS['options'][RKW_Sync::LOCK]=json_encode(['token'=>'expired','expires'=>time()-1]);RKW_Sync::step(false,1);check(!get_option(RKW_Sync::LOCK));$replacement=json_encode(['token'=>'new-owner','expires'=>time()+500]);$GLOBALS['http_handler']=function()use($replacement){$GLOBALS['options'][RKW_Sync::LOCK]=$replacement;return response([['StoreID'=>2,'RemainingQuantity'=>4]]);};RKW_Sync::step(false,1);check(get_option(RKW_Sync::LOCK)===$replacement);
};
$tests['connection/settings changes discard old pending values and refetch from the new source']=function(){
 RKW_Sync::step(false,1);$GLOBALS['options'][RKW_OPT]['store_ids']='3';$GLOBALS['http_handler']=fn($url)=>strpos($url,'/GetProducts?')!==false?response(catalog_rows(7000)):response([['StoreID'=>3,'RemainingQuantity'=>2]]);$r=RKW_Sync::step(false,1);check($r['processed']===1);check($GLOBALS['products'][101]->regular==='700'&&$GLOBALS['products'][101]->qty===2);check(count(array_filter($GLOBALS['http_calls'],fn($c)=>strpos($c[0],'/GetProducts?')!==false))===2);
};
$tests['stock errors are counted as errors rather than successful product updates']=function(){
 $GLOBALS['http_handler']=fn($url)=>strpos($url,'/GetProducts?')!==false?response(catalog_rows()):new WP_Error('http_request_failed','synthetic stock error');$r=RKW_Sync::step(false,1);check($r['errors']===1&&$r['updated']===0);check($GLOBALS['products'][101]->saves===0&&$GLOBALS['products'][101]->regular==='100');
};
$tests['repeated API page is an explicit error and never a false complete cycle']=function(){
 $GLOBALS['options'][RKW_OPT]['batch_size']=5;$GLOBALS['http_handler']=fn($url)=>strpos($url,'/GetProducts?')!==false?response(array_slice(catalog_rows(),0,5)):response([['StoreID'=>2,'RemainingQuantity'=>1]]);$r=RKW_Sync::step();check(!$r['done']);expect_error(RKW_Sync::step(),'rkw_sync_pagination');check(!get_option(RKW_Sync::STATS));check(get_option(RKW_Sync::CURSOR)['processed']===5);
};
$tests['background worker queues the next slice immediately despite current action being in progress']=function(){
 RKW_Sync_Runner::kick();RKW_Sync_Runner::kick();check(pending_count()===1);check(run_pending());check(pending_count()===1);check(get_option(RKW_Sync::CURSOR)['processed']===5);check(run_pending());check(pending_count()===0);check(get_option(RKW_Sync::STATS)['updated']===7);
};
$tests['failed source has a visible backoff and keeps its cursor for the next minute']=function(){
 $GLOBALS['http_handler']=fn()=>new WP_Error('http_request_failed','synthetic source timeout');RKW_Sync_Runner::kick();run_pending();check(!get_option(RKW_Sync::LOCK));check(get_option(RKW_Sync_Runner::STATE)['error']==='synthetic source timeout');RKW_Sync_Runner::kick();check(pending_count()===0);check(get_option(RKW_Sync::CURSOR)['processed']===0);check(strpos(RKW_Sync_Runner::status(),'synthetic source timeout')!==false);
};
$tests['enabled slow schedules migrate once to one minute and dispatch immediately']=function(){
 $GLOBALS['options'][RKW_OPT]['cron_interval']='hourly';wp_schedule_event(time()+3500,'hourly','rkw_cron_sync');RKW_Sync_Runner::ensure_schedule();check(rkw_settings()['cron_interval']==='rkw_1min');check(wp_get_schedule('rkw_cron_sync')==='rkw_1min');check(pending_count()===1);$GLOBALS['options'][RKW_OPT]['cron_interval']='hourly';RKW_Sync_Runner::ensure_schedule();check(rkw_settings()['cron_interval']==='hourly');
};
$tests['disabled automatic mode is preserved and pending workers do not update products']=function(){
 $GLOBALS['options'][RKW_OPT]['cron_interval']='off';RKW_Sync_Runner::ensure_schedule();RKW_Sync_Runner::kick();RKW_Sync_Runner::work();check(rkw_settings()['cron_interval']==='off');check(pending_count()===0);check(!$GLOBALS['http_calls']);
};
$tests['reschedule only cancels this catalog queue and preserves unrelated scheduled tasks']=function(){
 as_enqueue_async_action('foreign_action',[],'foreign');as_enqueue_async_action(RKW_Sync_Runner::HOOK,[],RKW_Sync_Runner::GROUP);RKW_Sync::reschedule();check(pending_count()===0);check($GLOBALS['actions'][1]['hook']==='foreign_action');check(wp_next_scheduled('rkw_cron_sync')<=time()+5);
};
$tests['queue-enqueue failure is reported and status exposes counts without credentials']=function(){
 $GLOBALS['queue_fail']=true;RKW_Sync_Runner::kick();check(strpos(RKW_Sync_Runner::status(),'ساخت کار پس‌زمینه ناموفق')!==false);$GLOBALS['queue_fail']=false;delete_option(RKW_Sync_Runner::STATE);RKW_Sync::step(false,1);$status=RKW_Sync_Runner::status();check(strpos($status,'1 بررسی')!==false);check(strpos($status,'synthetic-test-password')===false);
};
$tests['unmapped products do not consume the five expensive updates per slice']=function(){
 $GLOBALS['products']=[];$r=RKW_Sync::step();check($r['done']&&$r['skipped']===7&&$r['processed']===7);check(count($GLOBALS['http_calls'])===1);
};
$tests['status endpoint enforces capability and nonce and reports real cursor progress']=function(){
 foreach([[false,true],[true,false]]as$access){$GLOBALS['test_capability']=$access[0];$GLOBALS['test_nonce']=$access[1];try{RKW_Sync_Runner::ajax_status();check(false);}catch(TestJSON$r){check(!$r->success);}}
 $GLOBALS['test_capability']=true;$GLOBALS['test_nonce']=true;RKW_Sync::step(false,1);try{RKW_Sync_Runner::ajax_status();check(false);}catch(TestJSON$r){check($r->success);check(strpos($r->data['text'],'1 بررسی')!==false);}
};
$tests['malformed product pages cannot be reported as a completed empty catalog']=function(){
 foreach([false,['items'=>[]],[['wrongId'=>1]],[['productId'=>-1]]]as$reply){catalog_reset();$GLOBALS['http_handler']=fn()=>response($reply);expect_error(RKW_Sync::step(),'rkw_product_page');check(!get_option(RKW_Sync::STATS));check(get_option(RKW_Sync::CURSOR)['processed']===0);check(!get_option(RKW_Sync::LOCK));}
};
$tests['v19 catalog slices preserve batched prices and stock without per-product API calls']=function(){
 $GLOBALS['options'][RKW_OPT]['api']='v19';set_transient(RKW_Client::COOKIE_TRANSIENT,['name'=>'sg-auth-sg','value'=>'synthetic-cookie','signature'=>RKW_Policy_Catalog::signature(rkw_settings())],60);
 $GLOBALS['http_handler']=function($url,$args){if(strpos($url,'/Products?')!==false){$rows=[];for($id=1;$id<=7;$id++)$rows[]=['id'=>$id,'code'=>'SKU-'.$id,'RetailUnitRef'=>1,'remaining'=>6];return response($rows);}$body=json_decode($args['body'],true);check(count($body['items'])===7);$rows=[];for($id=1;$id<=7;$id++)$rows[]=['itemId'=>$id,'fee'=>3000];return response($rows);};
 $r=RKW_Sync::step();check(!$r['done']&&$r['processed']===5);$r=RKW_Sync::step();check($r['done']&&$r['updated']===7);check(count($GLOBALS['http_calls'])===2);foreach($GLOBALS['products']as$p)check($p->regular==='300'&&$p->qty===6&&$p->saves===1);
};
$tests['missing bulk price is visible as an error while valid stock is still updated']=function(){
 $GLOBALS['http_handler']=fn($url)=>strpos($url,'/GetProducts?')!==false?response(catalog_rows(0)):response([['StoreID'=>2,'RemainingQuantity'=>0]]);$r=RKW_Sync::step(false,1);$p=$GLOBALS['products'][101];check($r['errors']===1&&$r['updated']===0);check($p->saves===1&&$p->regular==='100'&&$p->qty===0&&$p->stock_status==='outofstock');
};
$tests['status detects a stall even before the first product completes']=function(){
 RKW_Sync::reset();$cursor=get_option(RKW_Sync::CURSOR);check(isset($cursor['heartbeat']));$cursor['heartbeat']=time()-180;update_option(RKW_Sync::CURSOR,$cursor);wp_schedule_event(time()-180,'rkw_1min','rkw_cron_sync');$text=RKW_Sync_Runner::status();check(strpos($text,'پیشرفت صف بیش از دو دقیقه')!==false);check(strpos($text,'اجرای زمان‌بندی بیش از دو دقیقه')!==false);
};
$fail=0;foreach($tests as$name=>$test){catalog_reset();try{$test();echo 'PASS '.$name."\n";}catch(Throwable$e){$fail++;echo 'FAIL '.$name.': '.$e->getMessage().' at '.$e->getFile().':'.$e->getLine()."\n";}}
echo count($tests).' tests, '.$fail." failed\n";exit($fail?1:0);
