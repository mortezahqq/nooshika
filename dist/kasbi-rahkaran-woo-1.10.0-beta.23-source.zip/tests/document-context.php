<?php
require __DIR__.'/bootstrap.php';
function context_reset(){reset_case();$GLOBALS['options'][RKW_OPT]['document_contract']='legacy_esales';context_cookie('synthetic-A');}
function context_cookie($value){set_transient(RKW_Client::COOKIE_TRANSIENT,['name'=>'sg-auth-sg','value'=>$value,'signature'=>RKW_Policy_Catalog::signature()],60);}
function context_payload(){return ['document'=>['customerId'=>45,'documentPatternId'=>9,'settlementPolicyId'=>27,'storeId'=>1,'currencyId'=>1,'items'=>[['productId'=>30,'quantity'=>1,'unitId'=>1,'storeId'=>1,'fee'=>1000,'price'=>1000]]],'receipts'=>[['key'=>'Cash','amount'=>1000]]];}
function context_invoice_calls(){return array_values(array_filter($GLOBALS['http_calls'],fn($c)=>strpos($c[0],'/ESales.svc/invoice')!==false));}
$tests=[];
$tests['cached general authentication does not skip register entry immediately before legacy issuance']=function(){
 $ready=false;$GLOBALS['http_handler']=function($u,$a)use(&$ready){if(strpos($u,'/CashierLogin')!==false){check($a['method']==='POST'&&json_decode($a['body'],true)===['machineName'=>'TEST-REGISTER']);$ready=true;return ['code'=>200,'body'=>'[]'];}check(strpos($u,'/ESales.svc/invoice')!==false);return $ready?response(['id'=>111]):response([],false,'Sequence contains no elements');};$c=new RKW_Client;check($c->save_invoice21(context_payload())===['id'=>111]);check(count($GLOBALS['http_calls'])===2);check($c->login_status()['cashier_accepted']===true);check($c->login_status()['legacy_empty_ack']===true);
};
$tests['cashier refresh precedes the pending marker and rotates the cookie used by the final write']=function(){
 $o=order();$GLOBALS['http_handler']=function($u,$a)use($o){if(strpos($u,'/CashierLogin')!==false){check(!$o->get_meta('_rkw_reconcile_required'));check($a['cookies'][0]->value==='synthetic-A');return ['code'=>200,'body'=>'[]','cookies'=>[new WP_Http_Cookie(['name'=>'sg-auth-sg','value'=>'synthetic-B'])]];}check(strpos($u,'/ESales.svc/invoice')!==false);check($o->get_meta('_rkw_reconcile_required')===1);check($a['cookies'][0]->value==='synthetic-B');return response(['id'=>112]);};check(RKW_Orders::send($o)===true);check(count($GLOBALS['http_calls'])===2);check($o->get_meta('_rkw_doc_id')==='112'&&!$o->get_meta('_rkw_reconcile_required'));
};
$tests['register rejection network failure and unknown shape prevent every financial POST']=function(){
 foreach([response([],false,'register rejected'),new WP_Error('http_request_failed','synthetic timeout'),['code'=>200,'body'=>'{"unrecognized":1}']]as$reply){context_reset();$o=order();$GLOBALS['http_handler']=function($u,$a)use($reply){check(strpos($u,'/CashierLogin')!==false);return$reply;};$r=RKW_Orders::send($o);check(is_wp_error($r));check(!context_invoice_calls());check(!$o->get_meta('_rkw_reconcile_required'));check(!$o->get_meta('_rkw_doc_id'));check(get_transient(RKW_Client::COOKIE_TRANSIENT)===false);check(strpos($o->get_meta('_rkw_error'),'ورود به صندوق پیش از ثبت سند')!==false);}
};
$tests['shared cache replacement cannot move an in-progress client onto a different session']=function(){
 $GLOBALS['http_handler']=function($u,$a){check($a['cookies'][0]->value==='synthetic-A');if(strpos($u,'/GetProduct')!==false)return response(['productId'=>30]);if(strpos($u,'/CashierLogin')!==false)return ['code'=>200,'body'=>'[]'];return response(['id'=>113]);};$c=new RKW_Client;check($c->product_by_id(30)===['productId'=>30]);context_cookie('synthetic-concurrent');check($c->save_invoice21(context_payload())===['id'=>113]);check(count(context_invoice_calls())===1);
};
$tests['each additional document enters the register again on the same client']=function(){
 $ready=false;$count=0;$GLOBALS['http_handler']=function($u,$a)use(&$ready,&$count){if(strpos($u,'/CashierLogin')!==false){check(!$ready);$ready=true;$count++;return ['code'=>200,'body'=>'[]'];}check($ready);$ready=false;return response(['id'=>200+$count]);};$c=new RKW_Client;check($c->save_invoice21(context_payload())===['id'=>201]);check($c->save_invoice21(context_payload())===['id'=>202]);check($count===2&&count(context_invoice_calls())===2);
};
$tests['missing register name stops the legacy financial write even with a cached authenticated session']=function(){
 $GLOBALS['options'][RKW_OPT]['machine_name']='';context_cookie('synthetic-A');$c=new RKW_Client;expect_error($c->save_invoice21(context_payload()),'rkw_cashier_machine');check(!$GLOBALS['http_calls']);
};
$tests['a read-only calculation and native v21 write keep their existing request contract']=function(){
 $GLOBALS['http_handler']=function($u,$a){check(strpos($u,'/calculateAmount')!==false);return response(['netPrice'=>1000]);};check((new RKW_Client)->calculate_invoice21(context_payload()['document'])===['netPrice'=>1000]);check(count($GLOBALS['http_calls'])===1);
 reset_case();$GLOBALS['http_handler']=function($u,$a){check(strpos($u,'/SaveInvoice')!==false);check(json_decode($a['body'],true)['receipts'][0]['key']==='Cash');return response(['id'=>114]);};check((new RKW_Client)->save_invoice21(context_payload())===['id'=>114]);check(count($GLOBALS['http_calls'])===1);
};
$tests['business rejection after successful register entry never retries or alters the invoice']=function(){
 $before=context_payload();$GLOBALS['http_handler']=function($u,$a)use($before){if(strpos($u,'/CashierLogin')!==false)return ['code'=>200,'body'=>'[]'];check(json_decode($a['body'],true)===json_decode(json_encode(RKW_Client::document_payload($before,rkw_settings())),true));return response([],false,'Sequence contains no elements');};$c=new RKW_Client;expect_error($c->save_invoice21($before),'rkw_api');check(count(context_invoice_calls())===1);check(count($GLOBALS['http_calls'])===2);check($c->login_status()['document_context_prepared']===true);
};
$tests['a transport timeout after the financial POST preserves the unknown-result block']=function(){
 $o=order();$GLOBALS['http_handler']=fn($u,$a)=>strpos($u,'/CashierLogin')!==false?['code'=>200,'body'=>'[]']:new WP_Error('http_request_failed','synthetic invoice timeout');expect_error(RKW_Orders::send($o),'http_request_failed');check($o->get_meta('_rkw_reconcile_required')===1);check(count(context_invoice_calls())===1);expect_error(RKW_Orders::send($o),'rkw_reconcile');check(count(context_invoice_calls())===1);
};
$tests['401 discards the pinned cookie and fully authenticates once instead of reusing a concurrent cache entry']=function(){
 $key=openssl_pkey_new(['private_key_bits'=>2048]);$d=openssl_pkey_get_details($key);$gets=0;
 $GLOBALS['http_handler']=function($u,$a)use($d,&$gets){if(strpos($u,'/GetProduct')!==false){$gets++;if($gets===1){check($a['cookies'][0]->value==='synthetic-A');return ['code'=>401,'body'=>'{}'];}check($a['cookies'][0]->value==='synthetic-new-login');return response(['productId'=>30]);}if(strpos($u,'/Session')!==false)return ['code'=>200,'body'=>json_encode(['id'=>'synthetic-session','rsa'=>['M'=>bin2hex($d['rsa']['n']),'E'=>bin2hex($d['rsa']['e'])]])];if(strpos($u,'/login')!==false)return ['code'=>200,'body'=>'{}','cookies'=>[new WP_Http_Cookie(['name'=>'sg-auth-sg','value'=>'synthetic-new-login'])]];check(strpos($u,'/CashierLogin')!==false);check($a['cookies'][0]->value==='synthetic-new-login');return ['code'=>200,'body'=>'[]'];};check((new RKW_Client)->product_by_id(30)===['productId'=>30]);check($gets===2&&count($GLOBALS['http_calls'])===5);
};
$fail=0;foreach($tests as$name=>$test){context_reset();try{$test();echo 'PASS '.$name."\n";}catch(Throwable$e){$fail++;echo 'FAIL '.$name.': '.$e->getMessage().' at '.$e->getLine()."\n";}}
echo count($tests).' tests, '.$fail." failed\n";exit($fail?1:0);
