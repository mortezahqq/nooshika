<?php
require __DIR__.'/bootstrap.php';
function get_current_user_id(){return $GLOBALS['check_user']??7;}
function wp_clear_scheduled_hook($hook,$args=[]){$GLOBALS['cleared'][]=[$hook,$args];}
function ajax_check_result($callback){try{$callback();}catch(TestJSON$r){return $r;}throw new RuntimeException('missing JSON');}
function check_reset(){
 reset_case();RKW_Order_List_UI::clear_document_cache();$GLOBALS['test_orders']=[];$GLOBALS['check_user']=7;$GLOBALS['cleared']=[];$GLOBALS['test_nonce']=true;$GLOBALS['test_capability']=true;$_POST=[];
 $o=order();$o->meta['_rkw_reconcile_required']=1;$o->meta['_rkw_error']='unknown original';$GLOBALS['test_orders'][$o->id]=$o;
 $GLOBALS['list_pages']=[1=>[['id'=>901]]];$GLOBALS['details']=[901=>['id'=>901,'description'=>'آدرس نمونه | ووکامرس: '.$o->id,'customerId'=>45,'netPrice'=>1000,'currencyId'=>1]];
 $GLOBALS['http_handler']=function($url,$args){check($args['method']==='GET','checker must issue only remote GET');parse_str(parse_url($url,PHP_URL_QUERY),$q);if(strpos($url,'GetInvoicesList')!==false)return response($GLOBALS['list_pages'][(int)$q['page']]??[]);if(strpos($url,'/GetInvoice?')!==false)return response($GLOBALS['details'][(int)$q['invoiceId']]??['id'=>(int)$q['invoiceId'],'description'=>'دیگر','netPrice'=>1000,'customerId'=>45]);throw new RuntimeException('unexpected endpoint');};
 return $o;
}
function check_finish($o,$send=false,$token=''){
 for($i=0;$i<11000;$i++){$r=RKW_Reconciliation::step($o,$token,$send);if(is_wp_error($r)||$r['done'])return $r;$token=$r['token'];}throw new RuntimeException('check failed to terminate');
}
$tests=[];
$tests['legacy internal order marker matches while display numbers may be customized']=function(){
 $o=new class extends WC_Order {function get_order_number(){return 'WEB-'.$this->id;}};
 check(RKW_Reconciliation::matches(['description'=>'مشتری | ووکامرس: '.$o->id,'customerId'=>45],$o));
 foreach(['ووکامرس: '.$o->id.'0','متن ووکامرس: '.$o->id,'ووکامرس: 1 | سفارش سایت #WEB-'.$o->id]as$d)check(!RKW_Reconciliation::matches(['description'=>$d,'customerId'=>45],$o),$d);
 check(!RKW_Reconciliation::matches(['description'=>'ووکامرس: '.$o->id,'customerId'=>46],$o));
};
$tests['header-only list is followed by detail reads and confirmed local attachment']=function(){$o=$GLOBALS['test_orders'][236464];$r=check_finish($o);check($r['status']==='confirmed');check($o->meta['_rkw_doc_id']==='901');check(!$o->get_meta('_rkw_reconcile_required'));check(!$o->get_meta('_rkw_error'));check(RKW_Order_List_UI::state($o)==='sent');check(count($GLOBALS['http_calls'])===3);check(count($GLOBALS['cleared'])===1);};
$tests['legacy queue without invoice ID is resolved without editing or resending the old record']=function(){$o=$GLOBALS['test_orders'][236464];$rows=[['ID'=>30,'post_status'=>'draft','invoice_id'=>'']];$GLOBALS['wpdb']->records=$rows;check(RKW_Order_List_UI::state($o)==='pending');check(check_finish($o)['status']==='confirmed');check($GLOBALS['wpdb']->records===$rows);};
$tests['unknown OK and arbitrary invalid own IDs can be reconciled']=function(){foreach(['OK','invalid']as$id){$o=check_reset();$o->meta['_rkw_doc_id']=$id;check(check_finish($o)['status']==='confirmed');check($o->meta['_rkw_doc_id']==='901');}};
$tests['no remote match never clears pending or old queue even when send was requested']=function(){foreach(['pending','queue','OK']as$mode){$o=check_reset();if($mode!=='pending')unset($o->meta['_rkw_reconcile_required']);if($mode==='queue')$GLOBALS['wpdb']->records=[['ID'=>30,'invoice_id'=>'']];if($mode==='OK')$o->meta['_rkw_doc_id']='OK';$GLOBALS['list_pages']=[1=>[]];$before=$o->meta;$r=check_finish($o,true);check($r['status']==='unresolved');check($o->meta===$before);check(count($GLOBALS['http_calls'])===2);}};
$tests['only an order with no prior uncertainty can become ready for the ordinary sender']=function(){$o=$GLOBALS['test_orders'][236464];unset($o->meta['_rkw_reconcile_required']);$GLOBALS['list_pages']=[1=>[]];$r=check_finish($o,true);check($r['status']==='ready');check(!$o->get_meta('_rkw_doc_id'));check(count($GLOBALS['http_calls'])===2);};
$tests['read-only mode cannot authorize sending an unsent order']=function(){$o=$GLOBALS['test_orders'][236464];unset($o->meta['_rkw_reconcile_required']);$GLOBALS['list_pages']=[1=>[]];check(check_finish($o,false)['status']==='unresolved');};
$tests['search continues beyond the former three-page limit with no descriptions in headers']=function(){
 $o=$GLOBALS['test_orders'][236464];$GLOBALS['list_pages']=[];for($p=1;$p<=4;$p++)for($i=1;$i<=50;$i++)$GLOBALS['list_pages'][$p][]=['id'=>($p-1)*50+$i];$GLOBALS['list_pages'][5]=[['id'=>901]];
 check(check_finish($o)['status']==='confirmed');check(count(array_filter($GLOBALS['http_calls'],fn($r)=>strpos($r[0],'GetInvoicesList')!==false))===5);check(count($GLOBALS['http_calls'])===207);
};
$tests['each step is bounded to one remote list or detail request']=function(){$o=$GLOBALS['test_orders'][236464];$token='';do{$before=count($GLOBALS['http_calls']);$r=RKW_Reconciliation::step($o,$token);check(!is_wp_error($r));check(count($GLOBALS['http_calls'])-$before<=1);$token=$r['token']??'';}while(!$r['done']);};
$tests['two matching remote invoices keep the original state and never attach either']=function(){$o=$GLOBALS['test_orders'][236464];$GLOBALS['list_pages'][1][]=['id'=>902];$GLOBALS['details'][902]=$GLOBALS['details'][901];$GLOBALS['details'][902]['id']=902;$before=$o->meta;check(check_finish($o,true)['status']==='unresolved');check($o->meta===$before);};
$tests['a matching list description cannot override a different detail description']=function(){$o=$GLOBALS['test_orders'][236464];$GLOBALS['list_pages'][1][0]['description']='سفارش سایت #'.$o->id;$GLOBALS['details'][901]['description']='سفارش سایت #OTHER';check(check_finish($o)['status']==='unresolved');check(!$o->get_meta('_rkw_doc_id'));};
$tests['amount currency and customer mismatches never attach or authorize a resend']=function(){foreach([['netPrice'=>1001],['currencyId'=>2],['customerId'=>46],['netPrice'=>null]]as$change){$o=check_reset();$GLOBALS['details'][901]=array_merge($GLOBALS['details'][901],$change);check(check_finish($o,true)['status']==='unresolved');check($o->get_meta('_rkw_reconcile_required')===1);check(!$o->get_meta('_rkw_doc_id'));}};
$tests['direct old ID can be verified without a mobile and without changing legacy data']=function(){
 $o=new class extends WC_Order{function get_billing_phone(){return '';}};$o->items=[new TestItem(100)];$o->total=100;$o->meta['_rkw_reconcile_required']=1;$GLOBALS['test_orders'][$o->id]=$o;$GLOBALS['wpdb']->records=[['ID'=>30,'invoice_id'=>'901']];check(check_finish($o)['status']==='confirmed');check(count($GLOBALS['http_calls'])===3);
};
$tests['an old reference to a different order remains blocked']=function(){$o=$GLOBALS['test_orders'][236464];$GLOBALS['wpdb']->records=[['ID'=>30,'invoice_id'=>'903']];check(check_finish($o)['status']==='unresolved');check(!$o->get_meta('_rkw_doc_id'));};
$tests['database read error never triggers remote lookups or changes local state']=function(){$o=$GLOBALS['test_orders'][236464];$GLOBALS['wpdb']->last_error='synthetic DB error';expect_error(RKW_Reconciliation::step($o),'rkw_legacy_read');check(!$GLOBALS['http_calls']);$GLOBALS['wpdb']->last_error='';};
$tests['a concurrent sender lock prevents checking and cannot be removed by the checker']=function(){$o=$GLOBALS['test_orders'][236464];$key='rkw_order_lock_'.$o->id;add_option($key,['started'=>1]);expect_error(RKW_Reconciliation::step($o),'rkw_check_busy');check(get_option($key)['started']===1);check(!$GLOBALS['http_calls']);};
$tests['transient ownership is per user and concurrent tabs invalidate previous tokens']=function(){
 $o=$GLOBALS['test_orders'][236464];$a=RKW_Reconciliation::step($o);$GLOBALS['check_user']=8;expect_error(RKW_Reconciliation::step($o,$a['token']),'rkw_check_expired');$GLOBALS['check_user']=7;$b=RKW_Reconciliation::step($o);check($a['token']!==$b['token']);expect_error(RKW_Reconciliation::step($o,$a['token']),'rkw_check_expired');
};
$tests['modified order or settings cannot reuse a previous lookup']=function(){foreach(['order','settings','legacy','mode']as$mode){$o=check_reset();$a=RKW_Reconciliation::step($o);if($mode==='order')$o->total=200;if($mode==='settings')$GLOBALS['options'][RKW_OPT]['price_divisor']=1;if($mode==='legacy')$GLOBALS['wpdb']->records=[['ID'=>30,'invoice_id'=>'']];expect_error(RKW_Reconciliation::step($o,$a['token'],$mode==='mode'),'rkw_check_changed');}};
$tests['order changed during the final remote read cannot be overwritten']=function(){
 $o=$GLOBALS['test_orders'][236464];$handler=$GLOBALS['http_handler'];$reads=0;$GLOBALS['http_handler']=function($url,$args)use($handler,$o,&$reads){if(strpos($url,'/GetInvoice?')!==false&&++$reads===2)$o->meta['_rkw_doc_id']='999';return $handler($url,$args);};expect_error(check_finish($o),'rkw_check_changed');check($o->get_meta('_rkw_doc_id')==='999');
};
$tests['remote errors and malformed lists cannot become an empty search result']=function(){foreach([new WP_Error('http_request_failed','timeout'),response(['unknown'=>[]]),response([['id'=>true]]),response([['id'=>1.5]]),response([['id'=>1,'invoiceId'=>2]])]as$reply){$o=check_reset();$GLOBALS['http_handler']=fn()=>$reply;$r=check_finish($o,true);check(is_wp_error($r));check($o->get_meta('_rkw_reconcile_required')===1);check(!$o->get_meta('_rkw_doc_id'));}};
$tests['wrong or boolean IDs in GetInvoice never attach']=function(){foreach([true,902]as$id){$o=check_reset();$GLOBALS['details'][901]['id']=$id;expect_error(check_finish($o),'rkw_check_detail');check(!$o->get_meta('_rkw_doc_id'));}};
$tests['repeated pages stop the search even if a candidate appeared earlier']=function(){
 $o=$GLOBALS['test_orders'][236464];$GLOBALS['list_pages'][1]=[];for($i=1;$i<=50;$i++)$GLOBALS['list_pages'][1][]=['id'=>$i];$GLOBALS['list_pages'][2]=$GLOBALS['list_pages'][1];expect_error(check_finish($o),'rkw_check_repeat');check(!$o->get_meta('_rkw_doc_id'));
};
$tests['confirmed documents are skipped without any remote write or extra lookup']=function(){$o=$GLOBALS['test_orders'][236464];unset($o->meta['_rkw_reconcile_required']);$o->meta['_rkw_doc_id']='901';$r=RKW_Reconciliation::step($o);check($r['status']==='confirmed');check(!$GLOBALS['http_calls']);};
$tests['capability and nonce are required before starting or resuming a lookup']=function(){foreach(['test_capability','test_nonce']as$flag){check_reset();$GLOBALS[$flag]=false;$_POST=['order_id'=>236464];$r=ajax_check_result(fn()=>RKW_Reconciliation::ajax_check());check(!$r->success);check(!$GLOBALS['http_calls']);}};
$tests['AJAX returns progress tokens and final confirmed ID without financial POSTs']=function(){
 $_POST=['order_id'=>236464];for($i=0;$i<10;$i++){$r=ajax_check_result(fn()=>RKW_Reconciliation::ajax_check());check($r->success);if($r->data['done'])break;$_POST['token']=$r->data['token'];}check($r->data['status']==='confirmed');check($r->data['document']==='فاکتور #901');
};
$tests['legacy endpoint uses the same resumable read-only path']=function(){$_POST=['order_id'=>236464,'allow_send'=>'1'];$r=ajax_check_result(fn()=>RKW_Orders::ajax_reconcile_invoice());check($r->success&&!$r->data['done']);$key='rkw_check_7_236464';check(get_transient($key)['send']===false);};
$tests['unresolved orders remain selectable for checking with no send button']=function(){$o=$GLOBALS['test_orders'][236464];$h=RKW_Order_List_UI::send_button($o);check(strpos($h,'rkw-check-one')!==false);check(strpos($h,'rkw-send-one')===false);};
$tests['five nonmatching invoices produce five explicit safe comparison reasons and preserve pending']=function(){
 $o=$GLOBALS['test_orders'][236464];$marker='ووکامرس: '.$o->id;$base=['customerId'=>45,'netPrice'=>1000,'currencyId'=>1];
 $GLOBALS['list_pages']=[1=>array_map(fn($id)=>['id'=>$id],range(901,905))];
 $GLOBALS['details']=[901=>['id'=>901]+$base,902=>['id'=>902,'description'=>'PRIVATE ADDRESS 09129999999']+$base,903=>['id'=>903,'description'=>'ووکامرس: 1']+$base,904=>['id'=>904,'description'=>$marker,'customerId'=>46,'netPrice'=>1000,'currencyId'=>1],905=>['id'=>905,'document'=>['description'=>$marker]]+$base];
 $GLOBALS['wpdb']->records=[['ID'=>99,'post_status'=>'publish','invoice_id'=>'']];$before=$o->meta;$r=check_finish($o,true);
 check($r['status']==='unresolved');check($o->meta===$before);check($r['diagnostics']['checked']===5);check($r['diagnostics']['visible_search_finished']===true);
 check(array_column($r['diagnostics']['checks'],'reason')===['description_missing','order_marker_missing','order_marker_mismatch','customer_mismatch','description_location']);
 check(strpos($r['report'],'رکورد قدیمی #99')!==false);check(strpos($r['report'],'document.description')!==false);check(strpos($r['report'],'علامت نتیجه نامعلوم ارسال قبلی: بله')!==false);
 check(strpos($r['report'],'PRIVATE ADDRESS')===false&&strpos($r['report'],'09129999999')===false);$encoded=json_encode($r['diagnostics']);check(strpos($encoded,'09129999999')===false);check(count(RKW_Log::all())===1);check(RKW_Log::all()[0]['message']===$r['report']);
};
$tests['diagnostic reports distinguish a legacy-only queue from our own uncertain submission']=function(){
 $o=$GLOBALS['test_orders'][236464];unset($o->meta['_rkw_reconcile_required']);$GLOBALS['wpdb']->records=[['ID'=>77,'post_status'=>'draft','invoice_id'=>'']];$GLOBALS['list_pages']=[1=>[]];$r=check_finish($o,true);
 check($r['diagnostics']['uncertain_submission']===false);check($r['diagnostics']['legacy_records'][0]['record_id']===77);check(strpos($r['report'],'وضعیت: draft')!==false);check(strpos($r['message'],'1 رکورد صف/فاکتور')!==false);
};
$tests['comparison facts report amount mismatch and final validation without clearing uncertainty']=function(){
 $o=$GLOBALS['test_orders'][236464];$GLOBALS['details'][901]['netPrice']=1100;$r=check_finish($o);check($r['status']==='unresolved');check($r['diagnostics']['checks'][0]['reason']==='amount_mismatch');check($r['diagnostics']['final_validation']['amount_matches']===false);check($r['diagnostics']['expected_amount']===1000.0);check(strpos($r['report'],'مبلغ خالص: 1100')!==false);check($o->get_meta('_rkw_reconcile_required')===1);
};
$tests['read error returns a report including local blockers without leaking the service response']=function(){
 $o=$GLOBALS['test_orders'][236464];$GLOBALS['http_handler']=fn()=>new WP_Error('http_request_failed','synthetic transport failure');$r=check_finish($o);expect_error($r,'http_request_failed');check(strpos($r->get_error_data()['report'],'کد نتیجه: http_request_failed')!==false);check($r->get_error_data()['diagnostics']['checked']===0);check(RKW_Log::all()[0]['level']==='warn');
};
$tests['AJAX failures deliver diagnostics to the browser and persist the same log']=function(){
 $GLOBALS['wpdb']->last_error='synthetic private SQL detail';$_POST=['order_id'=>236464];$r=ajax_check_result(fn()=>RKW_Reconciliation::ajax_check());check(!$r->success);check($r->data['code']==='rkw_legacy_read');check($r->data['diagnostics']['legacy_read_ok']===false);check(strpos($r->data['report'],'synthetic private SQL')===false);check(RKW_Log::all()[0]['message']===$r->data['report']);$GLOBALS['wpdb']->last_error='';
};
$tests['report rows are bounded while checked totals still include the full visible search']=function(){
 $o=$GLOBALS['test_orders'][236464];$GLOBALS['list_pages']=[1=>array_map(fn($id)=>['id'=>$id],range(1,30))];$r=check_finish($o);check($r['diagnostics']['checked']===30);check(count($r['diagnostics']['checks'])===25);check(strpos($r['report'],'25 فاکتور از 30')!==false);
};
$tests['successful reconciliation reports are returned without warning-log pollution']=function(){
 $o=$GLOBALS['test_orders'][236464];$r=check_finish($o);check($r['status']==='confirmed');check($r['diagnostics']['matches']===1);check($r['diagnostics']['final_validation']['reason']==='identity_matches');check(count(array_filter(RKW_Log::all(),fn($x)=>$x['level']==='warn'))===0);
};
$tests['Persian digits whitespace and trailing notes do not hide an explicit order reference']=function(){
 $o=$GLOBALS['test_orders'][236464];foreach(['ووکامرس: ۲۳۶۴۶۴ | یادداشت صندوق','آدرس | سفارش سایت #۲۳۶۴۶۴ | تحویل','ووکامرس : #٢٣٦٤٦٤']as$d)check(RKW_Reconciliation::matches(['description'=>$d,'customerId'=>45],$o));
 check(!RKW_Reconciliation::matches(['description'=>'ووکامرس: ۲۳۶۴۶۴ | سفارش سایت #999','customerId'=>45],$o));
};
$tests['a document excluded by mobile search is found in the global catalog and attached']=function(){
 $o=$GLOBALS['test_orders'][236464];$normal=$GLOBALS['http_handler'];$GLOBALS['http_handler']=function($url,$args)use($normal){if(strpos($url,'GetInvoicesList')!==false){parse_str(parse_url($url,PHP_URL_QUERY),$q);return response(isset($q['customerMobile'])?[]:[['id'=>901,'customerId'=>45,'netPrice'=>1000,'currencyId'=>1]]);}return $normal($url,$args);};
 $r=check_finish($o);check($r['status']==='confirmed');check($o->get_meta('_rkw_doc_id')==='901');check($r['diagnostics']['search_scope']==='global');check(count($GLOBALS['http_calls'])===4);
};
$tests['global header filtering avoids detail reads for wrong customers and amounts']=function(){
 $o=$GLOBALS['test_orders'][236464];$normal=$GLOBALS['http_handler'];$GLOBALS['http_handler']=function($url,$args)use($normal){if(strpos($url,'GetInvoicesList')!==false){parse_str(parse_url($url,PHP_URL_QUERY),$q);return response(isset($q['customerMobile'])?[]:[['id'=>901,'customerId'=>46,'netPrice'=>1000],['id'=>902,'customerId'=>45,'netPrice'=>2000]]);}return $normal($url,$args);};
 $r=check_finish($o);check($r['status']==='unresolved');check($r['diagnostics']['global_headers_skipped']===2);check(count($GLOBALS['http_calls'])===2);check($o->get_meta('_rkw_reconcile_required')===1);
};
if(defined('RKW_RECONCILIATION_FIXTURES_ONLY'))return;
$fail=0;foreach($tests as$name=>$test){check_reset();try{$test();echo 'PASS '.$name."\n";}catch(Throwable$e){$fail++;echo 'FAIL '.$name.': '.$e->getMessage().' at '.$e->getFile().':'.$e->getLine()."\n";}}
echo count($tests).' tests, '.$fail." failed\n";exit($fail?1:0);
