const assert = require('node:assert/strict');
const {execFileSync} = require('node:child_process');
const path = require('node:path');
const {chromium} = require('playwright');
(async () => {
  const browser = await chromium.launch({headless:true,executablePath:process.env.RKW_TEST_CHROMIUM || '/usr/bin/chromium',args:['--no-sandbox']});
  try {
    const page = await browser.newPage(); const errors=[];page.on('pageerror',e=>errors.push(e.message));
    let statusReads=0;const manual=[];
    await page.route('https://wordpress.example.invalid/**',route=>{
      const params=Object.fromEntries(new URLSearchParams(route.request().postData() || ''));assert.equal(params._ajax_nonce,'synthetic-catalog-nonce');
      let data;
      if(params.action==='rkw_catalog_status'){statusReads++;data={text:'پیشرفت دور جاری: 7 بررسی، 7 به‌روزرسانی؛ <b>متن ساده</b>'};}
      else {assert.equal(params.action,'rkw_step');manual.push(params.reset);data={done:manual.length===2,processed:manual.length===2?7:5,created:0,updated:manual.length===2?7:5,skipped:0,errors:0};}
      return route.fulfill({status:200,contentType:'application/json',headers:{'Access-Control-Allow-Origin':'*'},body:JSON.stringify({success:true,data})});
    });
    await page.evaluate(()=>{const original=window.setInterval;window.setInterval=(fn,delay)=>original(fn,delay===5000?30:delay);});
    const html=execFileSync(process.env.RKW_TEST_PHP||'php',['-n',path.join(__dirname,'catalog-status-html.php')],{encoding:'utf8'});
    await page.setContent(html);
    assert.equal(await page.locator('select[name="rkw[cron_interval]"]').inputValue(),'rkw_1min');
    await page.waitForFunction(()=>document.getElementById('rkw-catalog-status').textContent.includes('7 به‌روزرسانی'));
    assert(statusReads>0);assert.equal(await page.locator('#rkw-catalog-status b').count(),0);
    await page.locator('#rkw-sync').click();await page.waitForFunction(()=>document.getElementById('rkw-sync-out').textContent.includes('✔ پایان'));
    assert.deepEqual(manual,['1','']);assert.match(await page.locator('#rkw-sync-out').textContent(),/بروزرسانی: 7/);assert.equal(await page.locator('#rkw-sync').isDisabled(),false);assert.deepEqual(errors,[]);
    console.log('PASS browser: real catalog settings select fast cadence, poll actual status safely and retain manual chunk continuation');
  } finally {await browser.close();}
})().catch(error=>{console.error(error);process.exitCode=1;});
