<?php
require __DIR__ . '/bootstrap.php';
function get_current_user_id(){return 7;}
class SyncProduct extends TestProduct {
 public $id,$type='simple',$parent=0,$regular='100',$sale='',$price='100',$qty=9,$stock_status='instock',$manage_stock=true,$saves=0,$name='محصول آزمایشی',$on_save=null;
 function __construct($id,$rahkaran=30){$this->id=$id;$this->meta['_rahkaran_product_id']=$rahkaran;}
 function get_id(){return $this->id;}function is_type($type){return $this->type===$type;}function get_parent_id(){return $this->parent;}
 function set_manage_stock($v){$this->manage_stock=$v;}function set_stock_quantity($v){$this->qty=$v;}function set_stock_status($v){$this->stock_status=$v;}
 function set_regular_price($v){$this->regular=$v;}function get_regular_price($context='view'){return $this->regular;}
 function set_sale_price($v){$this->sale=$v;}function get_sale_price($context='view'){return $this->sale;}function set_price($v){$this->price=$v;}
 function set_name($v){$this->name=$v;}function save_meta_data(){}
 function save(){$this->saves++;if($this->on_save)($this->on_save)();return $this->id;}
}
function auto_reset(){
 reset_case();$GLOBALS['products']=[101=>new SyncProduct(101)];$GLOBALS['options'][RKW_OPT]['store_ids']='2';$_POST=[];
 foreach(['running','completed']as$name){$property=new ReflectionProperty(RKW_Auto_Product::class,$name);$property->setAccessible(true);$property->setValue(null,[]);}
 $GLOBALS['http_handler']=function($url,$args){check($args['method']==='GET');if(strpos($url,'/GetProduct?')!==false)return response(['productId'=>30,'productNumber'=>'SKU-30','productName'=>'تازه','fee'=>5000,'RetailUnitRef'=>1]);if(strpos($url,'GetRemainingQuantityInfo')!==false)return response([['StoreID'=>2,'RemainingQuantity'=>5],['StoreID'=>3,'RemainingQuantity'=>100]]);throw new RuntimeException('unexpected endpoint '.$url);};
}
function product_snapshot($price){
 $key=RKW_Snapshot::key('products',1,20,'','',0,1);check(RKW_Snapshot::save($key,['section'=>'products','headers'=>[],'rows'=>[],'snapshot_params'=>['page'=>1,'size'=>20,'search'=>''],'catalog_items'=>[30=>['id'=>30,'code'=>'SKU-30','name'=>'cached','unit'=>1,'stock'=>null,'price'=>$price,'sale'=>null]]]));
}
function auto_failure(){return get_transient(RKW_Auto_Product::NOTICE_KEY.get_current_user_id());}
if(defined('RKW_AUTO_PRODUCT_FIXTURES_ONLY'))return;
$tests=[];
$tests['publish refresh always reads live price even with a recent cached product list']=function(){
 product_snapshot(1200);RKW_Auto_Product::after_parent_save(101);$p=$GLOBALS['products'][101];check($p->regular==='500');check($p->price==='500');check($p->qty===5);check($p->saves===1);check(count($GLOBALS['http_calls'])===2);check(strpos($GLOBALS['http_calls'][0][0],'/GetProduct?')!==false);check(auto_failure()['success']===true);
};
$tests['fresh product read failure cannot apply stale snapshot data']=function(){
 product_snapshot(1200);$GLOBALS['http_handler']=fn()=>new WP_Error('http_request_failed','synthetic timeout');RKW_Auto_Product::update(101);$p=$GLOBALS['products'][101];check($p->regular==='100'&&$p->qty===9&&$p->saves===0);check(is_string(auto_failure()));check(strpos(auto_failure(),'synthetic timeout')!==false);
};
$tests['stock API failure blocks a false success and preserves both stock and price']=function(){
 $GLOBALS['http_handler']=function($url){return strpos($url,'/GetProduct?')!==false?response(['productId'=>30,'fee'=>8000]):new WP_Error('http_request_failed','synthetic stock timeout');};RKW_Auto_Product::update(101);$p=$GLOBALS['products'][101];check($p->saves===0&&$p->qty===9&&$p->regular==='100');check(strpos(auto_failure(),'synthetic stock timeout')!==false);
};
$tests['malformed stock responses never zero the product or report completion']=function(){
 foreach([null,false,['unexpected'=>1],[['StoreID'=>2]],[['RemainingQuantity'=>0]],[['StoreID'=>'invalid','RemainingQuantity'=>1]]]as$rows){auto_reset();$GLOBALS['http_handler']=fn($url)=>strpos($url,'/GetProduct?')!==false?response(['productId'=>30,'fee'=>8000]):response($rows);RKW_Auto_Product::update(101);check($GLOBALS['products'][101]->saves===0);check($GLOBALS['products'][101]->qty===9);check(is_string(auto_failure()));}
};
$tests['valid empty stock list and explicit zero stock are applied as out of stock']=function(){
 foreach([[],[['StoreID'=>2,'RemainingQuantity'=>0]]]as$rows){auto_reset();$GLOBALS['http_handler']=fn($url)=>strpos($url,'/GetProduct?')!==false?response(['productId'=>30,'fee'=>8000]):response($rows);RKW_Auto_Product::update(101);$p=$GLOBALS['products'][101];check($p->saves===1&&$p->qty===0&&$p->stock_status==='outofstock'&&$p->regular==='800');}
};
$tests['missing or zero price is not mislabeled as a complete fresh update']=function(){
 foreach([null,0]as$fee){auto_reset();$GLOBALS['http_handler']=fn()=>response(['productId'=>30,'fee'=>$fee]);RKW_Auto_Product::update(101);check($GLOBALS['products'][101]->saves===0);check(is_string(auto_failure()));check(count($GLOBALS['http_calls'])===1);}
};
$tests['wrong product id never overwrites the linked product']=function(){
 $GLOBALS['http_handler']=fn()=>response(['productId'=>99,'fee'=>5000]);RKW_Auto_Product::update(101);check($GLOBALS['products'][101]->saves===0);check(count($GLOBALS['http_calls'])===1);check(is_string(auto_failure()));
};
$tests['recursive save and repeated hooks do not duplicate remote reads in the same request']=function(){
 $GLOBALS['products'][101]->on_save=fn()=>RKW_Auto_Product::after_parent_save(101);RKW_Auto_Product::after_parent_save(101);RKW_Auto_Product::after_parent_save(101);check(count($GLOBALS['http_calls'])===2);check($GLOBALS['products'][101]->saves===1);
};
$tests['variation save updates only its own Rahkaran id and preserves the parent fields']=function(){
 $parent=new SyncProduct(200,88);$parent->type='variable';$variant=new SyncProduct(102,31);$variant->type='variation';$variant->parent=200;$GLOBALS['products'][200]=$parent;$GLOBALS['products'][102]=$variant;
 $GLOBALS['http_handler']=function($url){parse_str(parse_url($url,PHP_URL_QUERY),$query);if(strpos($url,'/GetProduct?')!==false){check((int)$query['id']===31);return response(['productId'=>31,'fee'=>7000]);}check((int)$query['productId']===31);return response([['StoreID'=>2,'RemainingQuantity'=>3]]);};
 RKW_Auto_Product::after_variation_save(102,0);check($variant->regular==='700'&&$variant->qty===3&&$variant->saves===1);check($parent->saves===0&&$parent->regular==='100');
};
$tests['disabled auto refresh and missing mapping make no API requests']=function(){
 $GLOBALS['options'][RKW_OPT]['auto_product_on_save']=0;RKW_Auto_Product::update(101);check(!$GLOBALS['http_calls']);$GLOBALS['options'][RKW_OPT]['auto_product_on_save']=1;$GLOBALS['products'][101]->meta=[];RKW_Auto_Product::update(101);check(!$GLOBALS['http_calls']);
};
$tests['stock-only and price-only settings request only enabled data and keep disabled fields']=function(){
 $GLOBALS['options'][RKW_OPT]['sync_price']=0;$GLOBALS['http_handler']=fn($url)=>strpos($url,'/GetProduct?')!==false?response(['productId'=>30]):response([['StoreID'=>2,'RemainingQuantity'=>3]]);RKW_Auto_Product::update(101);check($GLOBALS['products'][101]->regular==='100'&&$GLOBALS['products'][101]->qty===3);
 auto_reset();$GLOBALS['options'][RKW_OPT]['sync_stock']=0;RKW_Auto_Product::update(101);check(count($GLOBALS['http_calls'])===1);check($GLOBALS['products'][101]->regular==='500'&&$GLOBALS['products'][101]->qty===9);
};
$tests['existing sale price and configured currency conversion remain unchanged']=function(){
 $GLOBALS['products'][101]->sale='400';RKW_Auto_Product::update(101);check($GLOBALS['products'][101]->regular==='500'&&$GLOBALS['products'][101]->price==='400');
 auto_reset();$GLOBALS['options'][RKW_OPT]['price_divisor']=0.1;RKW_Auto_Product::update(101);check($GLOBALS['products'][101]->regular==='50000');
};
$tests['fresh reads are repeated in a new request rather than reusing a product-list snapshot']=function(){
 product_snapshot(1200);RKW_Auto_Product::update(101);$property=new ReflectionProperty(RKW_Auto_Product::class,'completed');$property->setAccessible(true);$property->setValue(null,[]);RKW_Auto_Product::update(101);check(count($GLOBALS['http_calls'])===4);
};
$tests['success notice reports direct completion with duration and old warning notices stay compatible']=function(){
 RKW_Auto_Product::update(101);ob_start();RKW_Auto_Product::notice();$html=ob_get_clean();check(strpos($html,'notice-success')!==false);check(strpos($html,'مدت پردازش')!==false);check(!auto_failure());set_transient(RKW_Auto_Product::NOTICE_KEY.get_current_user_id(),'old warning',600);ob_start();RKW_Auto_Product::notice();$html=ob_get_clean();check(strpos($html,'notice-warning')!==false&&strpos($html,'old warning')!==false);
};
$tests['v19 direct refresh preserves per-product price request sale and remaining stock']=function(){
 $GLOBALS['options'][RKW_OPT]['api']='v19';set_transient(RKW_Client::COOKIE_TRANSIENT,['name'=>'sg-auth-sg','value'=>'synthetic-cookie','signature'=>RKW_Policy_Catalog::signature(rkw_settings())],60);
 $GLOBALS['http_handler']=function($url,$args){if(strpos($url,'/product?')!==false)return response(['id'=>30,'code'=>'SKU-30','RetailUnitRef'=>1,'remaining'=>7]);check(strpos($url,'/Price')!==false&&$args['method']==='POST');$body=json_decode($args['body'],true);check($body['items'][0]['productId']===30&&$body['items'][0]['unitId']===1);return response([['itemId'=>1,'fee'=>7000,'discount'=>500,'netOfFee'=>6500]]);};
 RKW_Auto_Product::update(101);$p=$GLOBALS['products'][101];check($p->saves===1&&$p->qty===7&&$p->regular==='700'&&$p->sale==='650'&&$p->price==='650');check(count($GLOBALS['http_calls'])===2);
};
$fail=0;foreach($tests as$name=>$test){auto_reset();try{$test();echo 'PASS '.$name."\n";}catch(Throwable$e){$fail++;echo 'FAIL '.$name.': '.$e->getMessage().' at '.$e->getFile().':'.$e->getLine()."\n";}}
echo count($tests).' tests, '.$fail." failed\n";exit($fail?1:0);
