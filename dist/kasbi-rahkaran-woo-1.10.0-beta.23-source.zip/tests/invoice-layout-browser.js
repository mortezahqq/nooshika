const assert = require('node:assert/strict');
const path = require('node:path');
const {execFileSync} = require('node:child_process');
const {chromium} = require('playwright');
const root = path.resolve(__dirname, '..');
const php = process.env.RKW_TEST_PHP || 'php';
const ajax = 'https://wordpress.example.invalid/wp-admin/admin-ajax.php';
const asset = name => path.join(root, 'rahkaran-woo/assets', name);
const html = mode => execFileSync(php, ['-n', path.join(__dirname, 'invoice-layout.php'), 'html', mode || 'all'], {encoding: 'utf8'});

(async () => {
  const browser = await chromium.launch({headless: true, executablePath: process.env.RKW_TEST_CHROMIUM || '/usr/bin/chromium', args: ['--no-sandbox']});
  try {
    const page = await browser.newPage();
    const errors = []; page.on('pageerror', error => errors.push(error.message));
    let reads = 0;
    await page.route('https://wordpress.example.invalid/**', route => {
      const data = Object.fromEntries(new URLSearchParams(route.request().postData() || ''));
      assert.equal(data.action, 'rkw_module_list'); reads++;
      return route.fulfill({status: 200, contentType: 'application/json', headers: {'Access-Control-Allow-Origin': '*'}, body: JSON.stringify({success: true, data: {headers: [], rows: [], total: 0, count: 0, has_next: false, saved_at: Math.floor(Date.now()/1000), persisted: true}})});
    });
    await page.setContent(html());
    await page.addStyleTag({path: asset('admin.css')});
    await page.evaluate(url => { window.rkwModules = {ajax: url, nonce: 'synthetic', section: 'invoices', initial: {}}; }, ajax);
    await page.addScriptTag({path: asset('admin.js')});
    await page.addScriptTag({path: asset('persian-dates.js')});
    await page.waitForTimeout(100);
    assert.equal(reads, 0);
    assert.equal(await page.locator('#rkwm-remote-invoices').evaluate(el => el.open), false);
    assert(await page.locator('.rkwm-local-orders').isVisible());
    assert.equal(await page.locator('.rkwm-local-orders').evaluate(el => !!(el.compareDocumentPosition(document.getElementById('rkwm-remote-invoices')) & Node.DOCUMENT_POSITION_FOLLOWING)), true);
    const params = await page.locator('.rkwm-local-filter').evaluate(form => Object.fromEntries(new FormData(form)));
    assert.deepEqual(params, {page: 'rkw-invoices', rkw_order_filter: 'all', rkw_order_from: '', rkw_order_to: ''});
    assert.match(await page.locator('[data-rkw-persian-date]').textContent(), /۱۴۰۵\/۰۷\/۲۹.*۱۲:۳۴/);
    async function pick(id, year, month, day) {
      assert.equal(await page.locator('#rkw-local-order-'+id).getAttribute('type'), 'hidden');
      await page.locator('#rkw-local-order-'+id+'-button').click();
      const calendar = page.locator('#rkw-jalali-picker'); assert(await calendar.isVisible());
      await calendar.getByLabel('سال شمسی', {exact:true}).selectOption(String(year));
      await calendar.getByLabel('ماه شمسی', {exact:true}).selectOption(String(month));
      await calendar.locator('.rkw-jalali-day').filter({hasText: new RegExp('^'+String(day).replace(/[0-9]/g,n=>'۰۱۲۳۴۵۶۷۸۹'[Number(n)])+'$')}).click();
      assert.equal(await calendar.isVisible(), false);
    }
    await pick('from', 1405, 7, 28); await pick('to', 1405, 7, 29);
    assert.equal(await page.locator('#rkw-local-order-from-button').textContent(), '۱۴۰۵/۰۷/۲۸');
    const dated = await page.locator('.rkwm-local-filter').evaluate(form => Object.fromEntries(new FormData(form)));
    assert.equal(dated.rkw_order_from, '2026-10-20');assert.equal(dated.rkw_order_to, '2026-10-21');
    await pick('from', 1399, 12, 30);assert.equal(await page.locator('#rkw-local-order-from').inputValue(), '2021-03-20');
    await pick('from', 1400, 1, 1);assert.equal(await page.locator('#rkw-local-order-from').inputValue(), '2021-03-21');
    await pick('from', 1403, 12, 30);assert.equal(await page.locator('#rkw-local-order-from').inputValue(), '2025-03-20');
    await page.locator('#rkw-local-order-from-button').click();
    await page.getByLabel('سال شمسی', {exact:true}).selectOption('1404');
    assert.equal(await page.locator('.rkw-jalali-day').count(), 29);
    await page.locator('.rkw-jalali-day').last().focus();await page.keyboard.press('ArrowLeft');
    assert.equal(await page.getByLabel('سال شمسی', {exact:true}).inputValue(), '1405');
    assert.equal(await page.getByLabel('ماه شمسی', {exact:true}).inputValue(), '1');
    assert.equal(await page.locator(':focus').getAttribute('data-date'), '2026-03-21');
    await page.getByRole('button', {name:'پاک کردن تاریخ',exact:true}).click();
    assert.equal(await page.locator('#rkw-local-order-from').inputValue(), '');
    assert.equal(await page.locator('#rkw-local-order-to').inputValue(), '2026-10-21');
    await page.locator('#rkw-local-order-from-button').click();await page.keyboard.press('Escape');
    await page.waitForFunction(() => !document.getElementById('rkw-jalali-picker').open && document.getElementById('rkw-local-order-from-button').getAttribute('aria-expanded') === 'false');
    assert.equal(await page.locator('#rkw-local-order-from-button').getAttribute('aria-expanded'), 'false');
    console.log('PASS browser: Persian table dates and calendar selection, leap Esfand, Nowruz, clear and Escape');
    await page.locator('#rkwm-remote-invoices > summary').focus();
    await page.keyboard.press('Enter');
    await page.waitForFunction(() => document.getElementById('rkwm-results').textContent.includes('داده‌ای برای این فیلتر یافت نشد.'));
    assert.equal(reads, 1);
    await page.locator('#rkwm-remote-invoices > summary').click();
    await page.locator('#rkwm-remote-invoices > summary').click();
    await page.waitForTimeout(50); assert.equal(reads, 1);
    assert.deepEqual(errors, []); await page.close();
    console.log('PASS browser: WooCommerce list first, collapsed keyboard-accessible accordion and lazy single remote load');

    const filtered = await browser.newPage();
    filtered.on('dialog', dialog => dialog.accept());
    await filtered.route('https://wordpress.example.invalid/**', route => {
      const data = Object.fromEntries(new URLSearchParams(route.request().postData() || ''));
      assert.equal(data.action, 'rkw_send_selected_orders');const id = Number(data['order_ids[]']);
      return route.fulfill({status: 200, contentType: 'application/json', headers: {'Access-Control-Allow-Origin': '*'}, body: JSON.stringify({success:true,data:{items:[{id,status:id===1?'sent':'blocked',document:'فاکتور #501',message:'synthetic result'}]}})});
    });
    await filtered.setContent(html('unsent'));
    await filtered.evaluate(url => { window.rkwOrderActions = {ajax: url, nonce: 'synthetic'}; }, ajax);
    await filtered.addScriptTag({path: asset('order-actions.js')});
    assert.equal(await filtered.locator('#rkw-local-order-filter').inputValue(), 'unsent');
    await filtered.locator('.rkw-send-one[data-order="1"]').click();
    await filtered.waitForFunction(() => !document.querySelector('tr[data-order-id="1"]'));
    await filtered.locator('.rkw-send-one[data-order="2"]').click();
    await filtered.waitForSelector('.rkw-check-one[data-order="2"]');
    assert.equal(await filtered.locator('tr[data-order-id="2"]').count(), 1);
    assert.equal(await filtered.locator('.rkw-order-check').count(), 1);
    assert.match(await filtered.locator('.rkw-order-actions[data-order="2"]').textContent(), /نیازمند بررسی/);
    await filtered.close();
    console.log('PASS browser: filtered confirmed row disappears while an uncertain row and its review button stay visible');

    const pending = await browser.newPage();
    let pendingChecks = 0;
    await pending.route('https://wordpress.example.invalid/**', route => {
      const data = Object.fromEntries(new URLSearchParams(route.request().postData() || ''));
      assert.equal(data.action, 'rkw_check_order'); assert.equal(data.allow_send, '0'); pendingChecks++;
      return route.fulfill({status:200,contentType:'application/json',headers:{'Access-Control-Allow-Origin':'*'},body:JSON.stringify({success:true,data:{done:true,status:'unresolved',message:'سابقه نامشخص حفظ شد'}})});
    });
    await pending.setContent(html('unsent-review'));
    await pending.evaluate(url => { window.rkwOrderActions={ajax:url,nonce:'synthetic'}; },ajax);
    await pending.addScriptTag({path:asset('order-actions.js')});
    assert.equal(await pending.locator('#rkw-local-order-filter').inputValue(),'unsent');
    assert.match(await pending.locator('#rkw-local-order-filter option:checked').textContent(),/نیازمند بررسی/);
    assert.equal(await pending.locator('tr[data-order-id="1"] .rkw-send-one').count(),0);
    await pending.locator('.rkw-check-one[data-order="1"]').click();
    await pending.waitForFunction(()=>document.getElementById('rkw-local-send-status').textContent.includes('مورد به بررسی بیشتر نیاز دارد.'));
    assert.equal(pendingChecks,1);assert.equal(await pending.locator('tr[data-order-id="1"]').count(),1);assert.equal(await pending.locator('.rkw-check-one[data-order="1"]').count(),1);
    await pending.close();
    console.log('PASS browser: a pending order is visible on initial filtered load and remains available after an unresolved read-only check');

    const products = await browser.newPage(); let productReads = 0;
    await products.route('https://wordpress.example.invalid/**', route => {
      productReads++; return route.fulfill({status:200,contentType:'application/json',headers:{'Access-Control-Allow-Origin':'*'},body:JSON.stringify({success:true,data:{headers:[],rows:[],total:0,count:0,has_next:false,saved_at:Math.floor(Date.now()/1000),persisted:true}})});
    });
    await products.setContent(html('products'));
    await products.evaluate(url => { window.rkwModules = {ajax:url,nonce:'synthetic',section:'products',initial:{}}; },ajax);
    await products.addScriptTag({path:asset('admin.js')});
    await products.waitForFunction(() => document.getElementById('rkwm-results').textContent.includes('داده‌ای برای این فیلتر یافت نشد.'));
    assert.equal(productReads,1);await products.close();
    console.log('PASS browser: other resource screens still load normally without an accordion');
  } finally { await browser.close(); }
})().catch(error => { console.error(error);process.exitCode=1; });
