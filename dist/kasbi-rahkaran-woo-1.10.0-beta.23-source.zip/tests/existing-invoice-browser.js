const assert = require('node:assert/strict');
const path = require('node:path');
const {execFileSync} = require('node:child_process');
const {chromium} = require('playwright');
const root = path.resolve(__dirname, '..'), php = process.env.RKW_TEST_PHP || 'php';
const html = () => execFileSync(php, ['-n', path.join(__dirname, 'invoice-layout.php'), 'html', 'review'], {encoding:'utf8'});
(async()=>{
 const browser=await chromium.launch({headless:true,executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
 async function fixture(handler){
  const page=await browser.newPage(), errors=[];page.on('pageerror',e=>errors.push(e.message));
  await page.route('https://wordpress.example.invalid/**',async route=>{const d=Object.fromEntries(new URLSearchParams(route.request().postData()||''));const r=await handler(d);await route.fulfill({status:200,contentType:'application/json',headers:{'Access-Control-Allow-Origin':'*'},body:JSON.stringify(r)});});
  await page.setContent(html());await page.evaluate(()=>{window.rkwOrderActions={ajax:'https://wordpress.example.invalid/wp-admin/admin-ajax.php',nonce:'synthetic'};});
  await page.addScriptTag({path:path.join(root,'rahkaran-woo/assets/order-actions.js')});return{page,errors};
 }
 const ok=data=>({success:true,data});
 const list=()=>ok({page:1,scanned:1,has_next:false,rows:[{id:901,number:'F-901',amount:1000,date:'2026-10-24'}]});
 const preview=()=>ok({token:'reviewed',invoice_id:901,number:'F-901',amount:1000,date:'2026-10-24',item_count:1,has_order_reference:false});
 try{
  const calls=[];const one=await fixture(d=>{calls.push(d);assert.equal(d.nonce,'synthetic');assert.equal(d.order_id,'1');if(d.action==='rkw_existing_invoice_list')return list();if(d.action==='rkw_existing_invoice_prepare'){assert.equal(d.invoice_id,'901');return preview();}assert.equal(d.action,'rkw_existing_invoice_attach');assert.equal(d.token,'reviewed');assert.equal(d.confirm,'1');return ok({document:'فاکتور #901',message:'متصل شد'});});
  await one.page.locator('.rkw-existing-open[data-order="1"]').click();await one.page.getByRole('button',{name:'بررسی و انتخاب',exact:true}).click();await one.page.getByRole('button',{name:'تأیید اتصال همین فاکتور',exact:true}).waitFor();assert.equal(calls.length,2);assert.match(await one.page.locator('.rkw-existing-preview').textContent(),/شماره سفارش در توضیحات تأیید نشده/);
  await one.page.getByRole('button',{name:'تأیید اتصال همین فاکتور',exact:true}).click();await one.page.waitForFunction(()=>document.querySelector('.rkw-order-doc[data-order="1"]').textContent.includes('901'));assert.equal(calls.length,3);assert.equal(await one.page.locator('dialog').count(),0);assert.equal(await one.page.locator('.rkw-order-actions[data-order="1"] button').count(),0);assert.deepEqual(one.errors,[]);await one.page.close();console.log('PASS browser: preview is read only, explicit reviewed selection attaches existing ID and clears retry controls');

  let writes=0;const two=await fixture(d=>{if(d.action==='rkw_existing_invoice_list')return list();if(d.action==='rkw_existing_invoice_prepare')return preview();writes++;throw Error('unexpected attachment');});
  await two.page.locator('.rkw-existing-open[data-order="1"]').click();await two.page.getByRole('button',{name:'بررسی و انتخاب',exact:true}).click();await two.page.getByRole('button',{name:'تأیید اتصال همین فاکتور',exact:true}).waitFor();await two.page.getByRole('spinbutton',{name:'شناسه داخلی فاکتور راهکاران'}).fill('902');assert.equal(await two.page.getByRole('button',{name:'تأیید اتصال همین فاکتور',exact:true}).isVisible(),false);await two.page.getByRole('button',{name:'بستن',exact:true}).click();assert.equal(writes,0);assert.equal(await two.page.locator('.rkw-existing-open[data-order="1"]').isEnabled(),true);assert.deepEqual(two.errors,[]);await two.page.close();console.log('PASS browser: changing the selected ID invalidates the preview; closing never attaches a document');

  const three=await fixture(d=>d.action==='rkw_existing_invoice_list'?list():{success:false,data:{message:'مشتری متفاوت است <script>unsafe</script>'}});
  await three.page.locator('.rkw-existing-open[data-order="1"]').click();await three.page.getByRole('button',{name:'بررسی و انتخاب',exact:true}).click();await three.page.waitForFunction(()=>document.querySelector('dialog [role="status"]').textContent.includes('مشتری متفاوت'));assert.equal(await three.page.locator('dialog script').count(),0);assert.equal(await three.page.getByRole('button',{name:'تأیید اتصال همین فاکتور',exact:true}).isVisible(),false);assert.deepEqual(three.errors,[]);await three.page.close();console.log('PASS browser: rejected identity has no attach control and service messages render as text');
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
