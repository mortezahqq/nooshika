<?php
require __DIR__.'/bootstrap.php';
class RoutingShipping extends TestShipping {
 public $title='ارسال پست', $method='flat_rate', $instance=2;
 function get_name(){return $this->title;}function get_method_id(){return $this->method;}function get_instance_id(){return $this->instance;}
}
class RoutingOrder extends WC_Order{public $methods=[];function get_shipping_methods(){return $this->methods;}}
function routing_order($title='ارسال پست'){$o=new RoutingOrder;$m=new RoutingShipping;$m->title=$title;$o->methods=[$m];$o->items=[new TestItem(4245000)];$o->shipping=150000;$o->total=4395000;$o->gateway='WC_Gateway_SnappPay';$o->id=237743;return$o;}
function routing_ext($rules){return array_merge(RKW_Extensions::defaults(),['shipping_enabled'=>1,'shipping_policy_id'=>371,'shipping_rules'=>$rules]);}
function routing_settings($o,$ext){$s=rkw_settings();$s['document_contract']='legacy_esales';$s['inventory_id']=2;$s['payment_rules']=[['gateway'=>'WC_Gateway_SnappPay','settlement_id'=>45,'receipt_key'=>'ThirdPartyCoupon','coupon_type_id'=>5]];$GLOBALS['options'][RKW_OPT]=$s;$GLOBALS['options'][RKW_Extensions::OPTION]=$ext;$GLOBALS['http_handler']=function($u,$a){check($a['method']==='GET'&&strpos($u,'thirdPartyCouponTypes')!==false);return response([['Id'=>5]]);};set_transient(RKW_Client::COOKIE_TRANSIENT,['name'=>'sg-auth-sg','value'=>'synthetic','signature'=>RKW_Policy_Catalog::signature($s)],60);}
$tests=[];
$tests['legacy-normalized title overrides default371 for a decorated live shipping name']=function(){
 $o=routing_order('ارسال پست (150,000 تومان) [سرویس]');$ext=routing_ext([['method'=>'ارسال پست','id'=>330]]);$m=RKW_Accounting::shipping_mapping($o,$ext);check($m['id']===330&&$m['source']==='legacy_title_rule');check($m['default_id']===371&&$m['matching_rules']===1);check(!$GLOBALS['http_calls']);
};
$tests['legacy cleanup matches parentheses brackets dashes ascii amounts and punctuation']=function(){
 check(RKW_Accounting::legacy_shipping_title(' ارسال - پست [بسته] (پرداخت) : 150,000 تومان / ')==='ارسال پست');check(RKW_Accounting::legacy_shipping_title('پیک_تهران 100 ریال')==='پیکتهران');check(RKW_Accounting::legacy_shipping_title('ارسال ۴۵ میلیون')==='ارسال ۴۵ میلیون');
};
$tests['instance-specific rule wins over a generic method without using row order']=function(){
 $o=routing_order();$ext=routing_ext([['method'=>'flat_rate','id'=>371],['method'=>'flat_rate:2','id'=>331],['method'=>'ارسال پست','id'=>330]]);$m=RKW_Accounting::shipping_mapping($o,$ext);check($m['id']===331&&$m['source']==='instance_rule');
};
$tests['a conflicting normalized title refuses routing instead of selecting an arbitrary policy']=function(){
 $o=routing_order('ارسال پست [بسته]');$ext=routing_ext([['method'=>'ارسال پست (اول)','id'=>330],['method'=>'ارسال پست (دوم)','id'=>331]]);expect_error(RKW_Accounting::shipping_mapping($o,$ext),'rkw_shipping_ambiguous');routing_settings($o,$ext);expect_error(RKW_Orders::send($o),'rkw_shipping_ambiguous');foreach($GLOBALS['http_calls']as$c)check($c[1]['method']==='GET');
};
$tests['duplicate matches with the same target remain deterministic']=function(){
 $m=RKW_Accounting::shipping_mapping(routing_order('ارسال پست [بسته]'),routing_ext([['method'=>'ارسال پست (اول)','id'=>330],['method'=>'ارسال پست (دوم)','id'=>330]]));check($m['id']===330&&$m['matching_rules']===2);
};
$tests['no matching title preserves the configured default and reports that fact']=function(){
 $m=RKW_Accounting::shipping_mapping(routing_order('پیک'),routing_ext([['method'=>'تیپاکس','id'=>330]]));check($m['id']===371&&$m['source']==='default'&&$m['matching_rules']===0);
};
$tests['a rule for another instance cannot become a normalized title rule']=function(){
 $m=RKW_Accounting::shipping_mapping(routing_order('flatrate'),routing_ext([['method'=>'flat_rate:3','id'=>330]]));check($m['id']===371&&$m['source']==='default');
};
$tests['reported totals are preserved while a matched shipping policy replaces the default in ESales']=function(){
 $o=routing_order('ارسال پست (150,000 تومان)');routing_settings($o,routing_ext([['method'=>'ارسال پست','id'=>330]]));$writes=0;
 $GLOBALS['http_handler']=function($u,$a)use(&$writes){if(strpos($u,'thirdPartyCouponTypes')!==false)return response([['Id'=>5]]);$writes++;check(strpos($u,'/ESales.svc/invoice')!==false);$w=json_decode($a['body'],true);check($w['document']['policies']===[['policyId'=>330,'price'=>1500000,'isIncluded'=>true]]);check($w['document']['items'][0]['price']===42450000);check($w['payments'][0]['amount']===43950000);check($w['payments'][0]['attr']['couponType']===5);return response(['id'=>123300]);};
 $GLOBALS['http_handler']=with_legacy_cashier($GLOBALS['http_handler']);check(RKW_Orders::send($o)===true);check($writes===1);check($o->get_meta('_rkw_doc_id')==='123300');
};
$tests['product-mode shipping keeps a separate service item with matching unit and amount']=function(){
 $o=routing_order('ارسال پست (150,000 تومان)');$ext=routing_ext([['method'=>'ارسال پست','id'=>330]]);$ext['shipping_mode']='product';$ext['shipping_product_id']=371;$ext['shipping_unit_id']=4;routing_settings($o,$ext);$p=RKW_Orders::preview_invoice_payload($o);check(!is_wp_error($p));check($p['document']['items'][1]['productId']===330&&$p['document']['items'][1]['unitId']===4);check($p['document']['items'][1]['price']===1500000.0);foreach($GLOBALS['http_calls']as$c)check($c[1]['method']==='GET');
};
$tests['diagnostic explains normalized matching without logging the shipping title or writing a document']=function(){
 $o=routing_order('ارسال پست (150,000 تومان) [private-label]');routing_settings($o,routing_ext([['method'=>'ارسال پست','id'=>330]]));$d=RKW_Payment::diagnose_order($o,rkw_settings());check($d['shipping_mapping']['source']==='legacy_title_rule'&&$d['shipping_mapping']['id']===330);check(strpos(json_encode($d['shipping_mapping']),'private-label')===false);check(!$GLOBALS['http_calls']);
};
$tests['failed invoice logs the selected shipping mapping separately from the final wire policies']=function(){
 $o=routing_order('ارسال پست (150,000 تومان)');routing_settings($o,routing_ext([['method'=>'ارسال پست','id'=>330]]));$GLOBALS['http_handler']=fn($u,$a)=>$a['method']==='GET'?response([['Id'=>5]]):response([],false,'Sequence contains no elements');$GLOBALS['http_handler']=with_legacy_cashier($GLOBALS['http_handler']);expect_error(RKW_Orders::send($o),'rkw_api');$log=implode('\n',array_column(RKW_Log::all(),'message'));check(strpos($log,'"shipping_mapping_settings"')!==false&&strpos($log,'"source":"legacy_title_rule"')!==false);check(!$o->get_meta('_rkw_doc_id'));
};
$tests['a deliberately configured default371 remains in the final invoice if no rule matches']=function(){
 $o=routing_order('پیک مستقل');routing_settings($o,routing_ext([['method'=>'ارسال پست','id'=>330]]));$p=RKW_Orders::preview_invoice_payload($o);check(!is_wp_error($p));check($p['document']['policies'][0]['policyId']===371);check($p['receipts'][0]['amount']===43950000.0);foreach($GLOBALS['http_calls']as$c)check($c[1]['method']==='GET');
};
$tests['free shipping does not evaluate ambiguous charged-shipping routes']=function(){
 $o=routing_order('ارسال پست [بسته]');$o->shipping=0;$o->total=4245000;routing_settings($o,routing_ext([['method'=>'ارسال پست (اول)','id'=>330],['method'=>'ارسال پست (دوم)','id'=>331]]));$p=RKW_Orders::preview_invoice_payload($o);check(!is_wp_error($p));check(empty($p['document']['policies']));$d=RKW_Payment::diagnose_order($o,rkw_settings());check($d['shipping_mapping']['source']==='no_shipping_charge');
};
$tests['the actual postal title does not get falsely assigned to Tipax330 or courier331']=function(){
 $o=routing_order('ارسال با پست (۷ الی ۱۰ روز کاری)- ارسال سفاراشات بالای ۵/۵ میلیون تومان رایگان می باشد.');$ext=routing_ext([['method'=>'ارسال سریع با تیپاکس هزینه ارسال پس کرایه','id'=>330],['method'=>'پیک تهران ارسال سفارشات','id'=>331]]);$m=RKW_Accounting::shipping_mapping($o,$ext);check($m['id']===371&&$m['source']==='default'&&$m['matching_rules']===0);check(!$GLOBALS['http_calls']);
};
$tests['legacy shipping_product_id is a policy ID when the legacy mode is policy']=function(){
 $ext=RKW_Migration::extensions_map(['shipping_type'=>'policy','shipping_product_id'=>371,'unitId'=>1]);check($ext['shipping_mode']==='policy'&&$ext['shipping_policy_id']===371);check(!isset($ext['shipping_product_id']));check(!$GLOBALS['http_calls']);
};
$fail=0;foreach($tests as$name=>$test){reset_case();try{$test();echo 'PASS '.$name."\n";}catch(Throwable$e){$fail++;echo 'FAIL '.$name.': '.$e->getMessage().' at '.$e->getLine()."\n";}}
echo count($tests).' tests, '.$fail." failed\n";exit($fail?1:0);
