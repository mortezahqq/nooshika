const assert = require('node:assert/strict');
const path = require('node:path');
const {execFileSync} = require('node:child_process');
const {chromium} = require('playwright');
const root = path.resolve(__dirname, '..'), php = process.env.RKW_TEST_PHP || 'php';
const ajax = 'https://wordpress.example.invalid/wp-admin/admin-ajax.php';
const html = () => execFileSync(php, ['-n', path.join(__dirname, 'invoice-layout.php'), 'html', 'review'], {encoding:'utf8'});
const success = data => ({success:true,data});
const completed = () => { const text = document.getElementById('rkw-local-send-status').textContent; return text.includes('مورد حل‌نشده.') || text.includes('مورد به بررسی بیشتر نیاز دارد.'); };
(async()=>{
 const browser=await chromium.launch({headless:true,executablePath:process.env.RKW_TEST_CHROMIUM||'/usr/bin/chromium',args:['--no-sandbox']});
 async function fixture(handler){
  const page=await browser.newPage();const errors=[];page.on('pageerror',e=>errors.push(e.message));page.on('dialog',d=>d.accept());
  await page.route('https://wordpress.example.invalid/**',async route=>{const data=Object.fromEntries(new URLSearchParams(route.request().postData()||''));const result=await handler(data);if(result==='abort')return route.abort('failed');return route.fulfill({status:200,contentType:'application/json',headers:{'Access-Control-Allow-Origin':'*'},body:JSON.stringify(result)});});
  await page.setContent(html());await page.evaluate(url=>{window.rkwOrderActions={ajax:url,nonce:'synthetic'};},ajax);
  await page.addScriptTag({path:path.join(root,'rahkaran-woo/assets/order-actions.js')});return{page,errors};
 }
 try{
  let reads=0;
  const one=await fixture(data=>{assert.equal(data.action,'rkw_check_order');assert.equal(data.allow_send,'0');assert.equal(data.order_id,'1');reads++;if(reads===1){assert.equal(data.token,'');return success({done:false,token:'synthetic-token',status:'checking',message:'در حال بررسی'});}assert.equal(data.token,'synthetic-token');return success({done:true,status:'confirmed',document:'فاکتور #901',message:'متصل شد'});});
  assert.equal(await one.page.locator('.rkw-check-one[data-order="1"]').count(),1);
  await one.page.locator('.rkw-check-one[data-order="1"]').click();await one.page.waitForFunction(()=>document.querySelector('.rkw-order-doc[data-order="1"]').textContent.includes('901'));
  assert.equal(reads,2);assert.equal(await one.page.locator('tr[data-order-id="1"] .rkw-order-check').count(),0);assert.equal(await one.page.locator('.rkw-order-actions[data-order="1"] button').count(),0);assert.deepEqual(one.errors,[]);await one.page.close();
  console.log('PASS browser: real invoice-table pending row, continuation token, confirmed ID and removal of retry controls');

  const writes=[];const bulk=await fixture(data=>{
   if(data.action==='rkw_check_order'){assert.equal(data.allow_send,'1');return success({done:true,status:data.order_id==='1'?'unresolved':'ready',message:data.order_id==='1'?'ثبت‌نشدن قطعی ثابت نشده':'قابل ارسال'});}
   assert.equal(data.action,'rkw_send_selected_orders');writes.push(data['order_ids[]']);return success({items:[{id:2,status:'sent',document:'فاکتور #902',message:'ثبت شد'}]});
  });
  await bulk.page.locator('.rkw-order-check-all').check();await bulk.page.locator('.rkw-check-bulk').click();await bulk.page.waitForFunction(completed);
  assert.deepEqual(writes,['2']);assert.equal(await bulk.page.locator('tr[data-order-id="1"] .rkw-order-check').count(),1);assert.equal(await bulk.page.locator('.rkw-check-one[data-order="1"]').count(),1);assert.match(await bulk.page.locator('.rkw-order-doc[data-order="2"]').textContent(),/902/);assert.deepEqual(bulk.errors,[]);await bulk.page.close();
  console.log('PASS browser: mixed selection attaches/checks separately and submits only the explicitly ready order');

  let sent=0,checks=0;const failed=await fixture(data=>{if(data.action==='rkw_check_order'){checks++;return success({done:true,status:'ready',message:'قابل ارسال'});}sent++;return'abort';});
  await failed.page.locator('.rkw-order-check-all').check();await failed.page.locator('.rkw-check-bulk').click();await failed.page.waitForFunction(()=>document.getElementById('rkw-local-send-status').textContent.includes('ادامه گروه متوقف شد'));
  assert.equal(sent,1);assert.equal(checks,1);assert.equal(await failed.page.locator('.rkw-check-one[data-order="1"]').count(),1);assert.deepEqual(failed.errors,[]);await failed.page.close();
  console.log('PASS browser: interrupted financial request stops the group and never retries the POST');

  let calls=0;const readError=await fixture(data=>{assert.equal(data.action,'rkw_check_order');calls++;return{success:false,data:{message:'خطای خواندن <script>unsafe</script>'}};});
  await readError.page.locator('.rkw-check-one[data-order="1"]').click();await readError.page.waitForFunction(completed);
  assert.equal(calls,1);assert.equal(await readError.page.locator('.rkw-check-one[data-order="1"]').isEnabled(),true);assert.equal(await readError.page.locator('.rkw-last-result script').count(),0);assert.equal(await readError.page.locator('tr[data-order-id="1"] .rkw-order-check').count(),1);assert.deepEqual(readError.errors,[]);await readError.page.close();
  console.log('PASS browser: failed read preserves review controls and renders service messages as text');

  const reportText='گزارش بررسی سفارش ووکامرس #1\nرکورد قدیمی #77 | شناسه فاکتور: ذخیره نشده\nفاکتور #901: عبارت شماره سفارش ووکامرس در توضیحات وجود ندارد\n<script>unsafe</script>';
  const report=await fixture(data=>{assert.equal(data.action,'rkw_check_order');return success({done:true,status:'unresolved',message:'تطبیق پیدا نشد؛ رکورد قدیمی موجود است',report:reportText});});
  await report.page.locator('.rkw-check-one[data-order="1"]').click();await report.page.waitForSelector('details[data-rkw-report-order="1"][open]');await report.page.waitForFunction(completed);
  const details=report.page.locator('details[data-rkw-report-order="1"]');assert.equal(await details.locator('pre').textContent(),reportText);assert.equal(await details.locator('script').count(),0);assert.equal(await report.page.locator('.rkw-check-report-row td').getAttribute('colspan'),'9');
  assert.equal(await report.page.locator('#rkw-local-send-status').evaluate(el=>el.classList.contains('rkw-send-warning')),true);assert(!((await report.page.locator('#rkw-local-send-status').textContent()).includes('سند جدید')));
  await details.locator('.rkw-copy-check-report').click();await report.page.waitForFunction(()=>document.querySelector('.rkw-copy-check-report').textContent.includes('انتخاب شد')||document.querySelector('.rkw-copy-check-report').textContent.includes('کپی شد'));
  await report.page.locator('.rkw-check-one[data-order="1"]').click();await report.page.waitForFunction(completed);assert.equal(await report.page.locator('details[data-rkw-report-order="1"]').count(),1);assert.deepEqual(report.errors,[]);await report.page.close();
  console.log('PASS browser: readable five-invoice diagnosis, copy/select control, warning instead of report error and no new-document counter for read-only checks');

  const serverError=await fixture(data=>{assert.equal(data.action,'rkw_check_order');return{success:false,data:{message:'خواندن فهرست ناموفق بود',report:'گزارش بررسی سفارش #1\nکد نتیجه: http_request_failed'}};});
  await serverError.page.locator('.rkw-check-one[data-order="1"]').click();await serverError.page.waitForSelector('details[data-rkw-report-order="1"][open]');await serverError.page.waitForFunction(completed);
  assert.match(await serverError.page.locator('.rkw-check-report pre').textContent(),/http_request_failed/);assert.equal(await serverError.page.locator('#rkw-local-send-status').evaluate(el=>el.classList.contains('rkw-send-error')),true);assert.deepEqual(serverError.errors,[]);await serverError.page.close();
  console.log('PASS browser: actual read failure retains error severity and exposes the server diagnostic report');

  const sendError=await fixture(data=>{if(data.action==='rkw_check_order')return success({done:true,status:'ready',message:'قابل ارسال'});assert.equal(data.action,'rkw_send_selected_orders');return success({items:[{id:2,status:'error',message:'سیاست تسویه معتبر نیست'}]});});
  await sendError.page.locator('.rkw-order-check[value="2"]').check();await sendError.page.locator('.rkw-check-bulk').click();await sendError.page.waitForFunction(completed);
  assert.equal(await sendError.page.locator('#rkw-local-send-status').evaluate(el=>el.classList.contains('rkw-send-error')),true);assert.match(await sendError.page.locator('#rkw-local-send-status').textContent(),/سیاست تسویه معتبر نیست/);assert.deepEqual(sendError.errors,[]);await sendError.page.close();
  console.log('PASS browser: rejected financial submission remains an error rather than an unmatched-search warning');
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
