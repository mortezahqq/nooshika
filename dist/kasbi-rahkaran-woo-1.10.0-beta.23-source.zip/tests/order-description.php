<?php
require __DIR__ . '/bootstrap.php';

class DescriptionCountries {function get_states($country){return $country==='IR'?['THR'=>'تهران']:[];}}
function WC(){return (object)['countries'=>new DescriptionCountries];}
class DescriptionOrder extends WC_Order {
 public $billing=[],$shipping_address=[],$payment_title='پرداخت سامان';
 function get_address($type='billing'){return $type==='shipping'?$this->shipping_address:$this->billing;}
 function get_payment_method_title(){return $this->payment_title;}
 function get_order_number(){return 'WEB-'.$this->id;}
}
function description_order(){
 $o=new DescriptionOrder;$o->items=[new TestItem(100)];$o->total=100;
 $o->billing=['first_name'=>'مشتری','last_name'=>'آزمایشی','country'=>'IR','state'=>'THR','city'=>'تهران','address_1'=>'خیابان نمونه پلاک ۱','address_2'=>'واحد ۲','phone'=>'09120000000','postcode'=>'1111111111'];
 return $o;
}
$tests=[];
$tests['full description includes order snapshot contact data and both internal and displayed numbers']=function(){
 $o=description_order();$d=RKW_Orders::invoice_description($o);
 check($d==='مشتری آزمایشی | تهران، تهران، خیابان نمونه پلاک ۱، واحد ۲ | 09120000000 | 1111111111 | روش پرداخت پرداخت سامان | ووکامرس: 236464 | سفارش سایت #WEB-236464');
};
$tests['empty billing address fields fall back to shipping without fetching customer profile']=function(){
 $o=description_order();$o->shipping_address=$o->billing;$o->billing=[];check(strpos(RKW_Orders::invoice_description($o),'مشتری آزمایشی | تهران، تهران، خیابان نمونه پلاک ۱، واحد ۲ | 09120000000 | 1111111111')===0);
 $o->billing=['phone'=>'02100000000'];check(strpos(RKW_Orders::invoice_description($o),'02100000000')!==false);
};
$tests['missing optional customer fields never block a valid invoice']=function(){
 $o=description_order();$o->billing=[];$o->payment_title='';check(RKW_Orders::invoice_description($o)==='ووکامرس: 236464 | سفارش سایت #WEB-236464');
};
$tests['description is plain text and customer fields cannot inject a standalone order marker']=function(){
 $o=description_order();$o->billing['address_1']='<b>آدرس</b> | سفارش سایت #OTHER';$d=RKW_Orders::invoice_description($o);check(strpos($d,'<b>')===false);check(strpos($d,'| سفارش سایت #OTHER')===false);check(strpos($d,'آدرس')!==false);
};
$tests['reconciliation accepts old and extended descriptions but rejects prefix ids and wrong customers']=function(){
 $o=description_order();foreach(['سفارش سایت #WEB-236464',RKW_Orders::invoice_description($o)]as$d)check(RKW_Orders::invoice_matches_order(['description'=>$d,'customerId'=>45],$o));
 $d=RKW_Orders::invoice_description($o);check(!RKW_Orders::invoice_matches_order(['description'=>$d.'0','customerId'=>45],$o));check(!RKW_Orders::invoice_matches_order(['description'=>$d,'customerId'=>46],$o));check(!RKW_Orders::invoice_matches_order(['description'=>'سفارش سایت #WEB-23646','customerId'=>45],$o));
};
$tests['actual legacy and v21 payloads carry the full description with the same invoice amounts']=function(){
 foreach(['legacy_esales','v21']as$contract){reset_case();$GLOBALS['options'][RKW_OPT]['document_contract']=$contract;set_transient(RKW_Client::COOKIE_TRANSIENT,['name'=>'sg-auth-sg','value'=>'synthetic-cookie','signature'=>RKW_Policy_Catalog::signature(rkw_settings())],60);$o=description_order();$seen=0;
  $GLOBALS['http_handler']=function($u,$a)use($o,&$seen,$contract){$p=json_decode($a['body'],true);if(strpos($u,'calculateAmount')!==false)return response(['netPrice'=>1000]);$seen++;check($p['document']['description']===RKW_Orders::invoice_description($o));check($p['document']['customerId']===45);$entries=$contract==='legacy_esales'?$p['payments']:$p['receipts'];check($entries[0]['amount']===1000);check($p['document']['items'][0]['quantity']===1);return response(['id'=>887]);};
  $GLOBALS['http_handler']=with_legacy_cashier($GLOBALS['http_handler']);check(RKW_Orders::send($o)===true);check($seen===1);check($o->get_meta('_rkw_doc_id')==='887');
 }
};
$fail=0;foreach($tests as$name=>$test){reset_case();try{$test();echo 'PASS '.$name."\n";}catch(Throwable$e){$fail++;echo 'FAIL '.$name.': '.$e->getMessage().' at '.$e->getFile().':'.$e->getLine()."\n";}}
echo count($tests).' tests, '.$fail." failed\n";exit($fail?1:0);
