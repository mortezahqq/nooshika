const assert=require('node:assert/strict');const path=require('node:path');const {execFileSync}=require('node:child_process');const{chromium}=require('playwright');
(async()=>{const browser=await chromium.launch({headless:true,executablePath:'/usr/bin/chromium',args:['--no-sandbox']});try{
 const page=await browser.newPage();const errors=[];page.on('pageerror',e=>errors.push(e.message));let calls=0,fail=false;
 await page.route('https://wordpress.example.invalid/**',route=>{const d=Object.fromEntries(new URLSearchParams(route.request().postData()||''));assert.equal(d.action,'rkw_invoice_calculation');assert.equal(d.order_id,'214783');assert.equal(d._ajax_nonce,'synthetic-catalog-nonce');calls++;return route.fulfill({status:200,contentType:'application/json',headers:{'Access-Control-Allow-Origin':'*'},body:JSON.stringify(fail?{success:false,data:{message:'شناسه مشتری ذخیره نشده'}}:{success:true,data:{text:'گزارش مالی بدون ثبت\nاختلاف با دریافت: -100\n<script>unsafe</script>'}})});});
 const html=execFileSync(process.env.RKW_TEST_PHP||'php',['-n',path.join(__dirname,'catalog-status-html.php'),'orders'],{encoding:'utf8'});await page.setContent(html);
 await page.locator('#rkw-invoice-calculate').click();assert.equal(calls,0);assert.match(await page.locator('#rkw-payment-diagnose-output').textContent(),/شناسه سفارش معتبر/);
 console.log('PASS browser: invalid order does not start any remote financial calculation');
 await page.locator('#rkw-payment-order-id').fill('214783');await page.locator('#rkw-invoice-calculate').click();await page.waitForFunction(()=>document.getElementById('rkw-payment-diagnose-output').textContent.includes('اختلاف با دریافت'));
 assert.equal(calls,1);assert.equal(await page.locator('#rkw-payment-diagnose-output script').count(),0);assert.equal(await page.locator('#rkw-invoice-calculate').isEnabled(),true);
 console.log('PASS browser: actual admin order panel runs only explicit calculate action and renders numeric report as text');
 fail=true;await page.locator('#rkw-invoice-calculate').click();await page.waitForFunction(()=>document.getElementById('rkw-payment-diagnose-output').textContent.includes('شناسه مشتری ذخیره نشده'));assert.equal(calls,2);assert.equal(await page.locator('#rkw-invoice-calculate').isEnabled(),true);assert.deepEqual(errors,[]);
 console.log('PASS browser: calculation validation error is displayed without invoking any invoice action');
}finally{await browser.close();}})().catch(e=>{console.error(e);process.exitCode=1;});
