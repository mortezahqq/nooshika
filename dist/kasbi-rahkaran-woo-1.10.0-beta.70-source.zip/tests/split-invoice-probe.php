<?php
require __DIR__ . '/bootstrap.php';
$policy = ['policyId'=>507,'policyConditionId'=>530,'policyConditionRowId'=>1,'effect'=>3,'price'=>20,'isIncluded'=>true,'type'=>'Discount'];
$full = ['productId'=>1,'unitId'=>1,'quantity'=>1,'price'=>100,'policies'=>[]];
$sale = ['productId'=>2,'unitId'=>1,'quantity'=>1,'price'=>100,'policies'=>[$policy]];
$shipping = ['policyId'=>427,'price'=>10,'isIncluded'=>true];
$document = ['items'=>[$full,$sale],'policies'=>[$shipping]];
$result = ['netPrice'=>170,'items'=>[
 array_replace($full,['netPrice'=>90,'policies'=>[$policy,array_replace($shipping,['type'=>'MiscellaneousAdditions','effect'=>2])]]),
 $sale+['netPrice'=>80],
]];
$client = new class {
 public $calls = [];
 function calculate_invoice21($doc) {
  $this->calls[]=$doc;
  $row=$doc['items'][0];
  if ($row['productId']===2) return ['netPrice'=>80,'items'=>[$row+['netPrice'=>80]]];
  $row['netPrice']=110;
  $row['policies'][]=['policyId'=>427,'type'=>'MiscellaneousAdditions','effect'=>2,'isIncluded'=>true,'price'=>10];
  return ['netPrice'=>110,'items'=>[$row]];
 }
};
$probe = new ReflectionMethod(RKW_Invoice_Diagnostics::class,'inspect_snapp_groups');
$probe->setAccessible(true);
$report = $probe->invoke(null,$client,$document,$result,190);
check($report['combined_matches']&&count($client->calls)===2);
check($client->calls[0]['policies']===[]&&$client->calls[1]['policies']===[$shipping]);
check($client->calls[1]['items'][0]['policies'][0]['isIncluded']===false);
echo "PASS two separate draft calculations preserve total and charge shipping once\n";
