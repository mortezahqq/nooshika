<?php
require __DIR__ . '/bootstrap.php';
function get_current_user_id(){return 7;}
if(!function_exists('wp_date')){function wp_date($format,$timestamp){return date($format,$timestamp);}}
class SyncProduct extends TestProduct {
 public $id,$type='simple',$parent=0,$status='publish',$children=[],$regular='100',$sale='',$price='100',$qty=9,$stock_status='instock',$manage_stock=true,$saves=0,$name='محصول آزمایشی',$on_save=null;
 function __construct($id,$rahkaran=30){$this->id=$id;$this->meta['_rahkaran_product_id']=$rahkaran;}
 function get_id(){return $this->id;}function is_type($type){return $this->type===$type;}function get_parent_id(){return $this->parent;}
 function get_status(){return $this->status;}function get_children(){return $this->children;}
 function set_manage_stock($v){$this->manage_stock=$v;}function set_stock_quantity($v){$this->qty=$v;}function set_stock_status($v){$this->stock_status=$v;}
 function set_regular_price($v){$this->regular=$v;}function get_regular_price($context='view'){return $this->regular;}
 function set_sale_price($v){$this->sale=$v;}function get_sale_price($context='view'){return $this->sale;}function set_price($v){$this->price=$v;}
 function set_name($v){$this->name=$v;}function save_meta_data(){}
 function save(){$this->saves++;if($this->on_save)($this->on_save)();return $this->id;}
}
function auto_reset(){
 reset_case();$GLOBALS['products']=[101=>new SyncProduct(101)];$GLOBALS['options'][RKW_OPT]['store_ids']='2';$_POST=[];
 foreach(['running','completed','pending']as$name){$property=new ReflectionProperty(RKW_Auto_Product::class,$name);$property->setAccessible(true);$property->setValue(null,[]);}
 $GLOBALS['http_handler']=function($url,$args){check($args['method']==='GET');if(strpos($url,'/GetProduct?')!==false)return response(['productId'=>30,'productNumber'=>'SKU-30','productName'=>'تازه','fee'=>5000,'RetailUnitRef'=>1]);if(strpos($url,'GetRemainingQuantityInfo')!==false)return response([['StoreID'=>2,'RemainingQuantity'=>5],['StoreID'=>3,'RemainingQuantity'=>100]]);throw new RuntimeException('unexpected endpoint '.$url);};
}
function product_snapshot($price){
 $key=RKW_Snapshot::key('products',1,20,'','',0,1);check(RKW_Snapshot::save($key,['section'=>'products','headers'=>[],'rows'=>[],'snapshot_params'=>['page'=>1,'size'=>20,'search'=>''],'catalog_items'=>[30=>['id'=>30,'code'=>'SKU-30','name'=>'cached','unit'=>1,'stock'=>null,'price'=>$price,'sale'=>null]]]));
}
function auto_failure(){return get_transient(RKW_Auto_Product::NOTICE_KEY.get_current_user_id());}
function auto_event($name,...$args){$priorities=$GLOBALS['action_hooks'][$name]??[];ksort($priorities);foreach($priorities as$list)foreach($list as[$callback,$accepted])$callback(...array_slice($args,0,$accepted));}
function auto_family($count=20){
 $parent=new SyncProduct(200,999);$parent->type='variable';$GLOBALS['products'][200]=$parent;
 for($i=0;$i<$count;$i++){$id=300+$i;$child=new SyncProduct($id,1000+$i);$child->type='variation';$child->parent=200;$parent->children[]=$id;$GLOBALS['products'][$id]=$child;}
 $GLOBALS['http_handler']=function($url,$args){check($args['method']==='GET');parse_str(parse_url($url,PHP_URL_QUERY),$q);if(strpos($url,'/GetProduct?')!==false){$id=(int)$q['id'];return response(['productId'=>$id,'fee'=>34500000,'RetailUnitRef'=>1]);}return response([['StoreID'=>2,'RemainingQuantity'=>(int)$q['productId']-999]]);};
 return $parent;
}
if(defined('RKW_AUTO_PRODUCT_FIXTURES_ONLY'))return;
RKW_Auto_Product::init();
$tests=[];
$tests['publish refresh always reads live price even with a recent cached product list']=function(){
 product_snapshot(1200);RKW_Auto_Product::after_parent_save(101);$p=$GLOBALS['products'][101];check($p->regular==='500');check($p->price==='500');check($p->qty===5);check($p->saves===1);check(count($GLOBALS['http_calls'])===2);check(strpos($GLOBALS['http_calls'][0][0],'/GetProduct?')!==false);check(auto_failure()['success']===true);
};
$tests['fresh product read failure cannot apply stale snapshot data']=function(){
 product_snapshot(1200);$GLOBALS['http_handler']=fn()=>new WP_Error('http_request_failed','synthetic timeout');RKW_Auto_Product::update(101);$p=$GLOBALS['products'][101];check($p->regular==='100'&&$p->qty===9&&$p->saves===0);check(is_string(auto_failure()));check(strpos(auto_failure(),'synthetic timeout')!==false);
};
$tests['stock API failure preserves stock while saving a valid price and reporting partial completion']=function(){
 $GLOBALS['http_handler']=function($url){return strpos($url,'/GetProduct?')!==false?response(['productId'=>30,'fee'=>8000]):new WP_Error('http_request_failed','synthetic stock timeout');};RKW_Auto_Product::update(101);$p=$GLOBALS['products'][101];check($p->saves===1&&$p->qty===9&&$p->regular==='800');check(strpos(auto_failure(),'قیمت به‌روز شد')!==false);check(!isset($p->meta[RKW_Product_View::FRESH]));
};
$tests['malformed stock responses never zero the product or report completion']=function(){
 foreach([null,false,['unexpected'=>1],[['StoreID'=>2]],[['RemainingQuantity'=>0]],[['StoreID'=>'invalid','RemainingQuantity'=>1]]]as$rows){auto_reset();$GLOBALS['http_handler']=fn($url)=>strpos($url,'/GetProduct?')!==false?response(['productId'=>30,'fee'=>8000]):response($rows);RKW_Auto_Product::update(101);check($GLOBALS['products'][101]->saves===1);check($GLOBALS['products'][101]->regular==='800');check($GLOBALS['products'][101]->qty===9);check(is_string(auto_failure()));}
};
$tests['stock response accepts camel-case store ID and explains null for configured warehouse']=function(){
 foreach ([7, null] as $quantity) {
  auto_reset();
  $GLOBALS['http_handler']=fn($url)=>strpos($url,'/GetProduct?')!==false
   ? response(['productId'=>30,'fee'=>8000])
   : response([['storeId'=>2,'remainingQuantity'=>$quantity],['StoreID'=>3,'RemainingQuantity'=>null]]);
  RKW_Auto_Product::update(101);
  $product=$GLOBALS['products'][101];
  check($product->regular==='800' && $product->qty===($quantity ?? 9));
  if (null===$quantity) check(str_contains(auto_failure(),'انبار 2'));
 }
};
$tests['valid empty stock list and explicit zero stock are applied as out of stock']=function(){
 foreach([[],[['StoreID'=>2,'RemainingQuantity'=>0]]]as$rows){auto_reset();$GLOBALS['http_handler']=fn($url)=>strpos($url,'/GetProduct?')!==false?response(['productId'=>30,'fee'=>8000]):response($rows);RKW_Auto_Product::update(101);$p=$GLOBALS['products'][101];check($p->saves===1&&$p->qty===0&&$p->stock_status==='outofstock'&&$p->regular==='800');}
};
$tests['missing or zero price is not mislabeled as a complete fresh update']=function(){
 foreach([null,0]as$fee){auto_reset();$GLOBALS['http_handler']=fn()=>response(['productId'=>30,'fee'=>$fee]);RKW_Auto_Product::update(101);check($GLOBALS['products'][101]->saves===0);check(is_string(auto_failure()));check(count($GLOBALS['http_calls'])===1);}
};
$tests['wrong product id never overwrites the linked product']=function(){
 $GLOBALS['http_handler']=fn()=>response(['productId'=>99,'fee'=>5000]);RKW_Auto_Product::update(101);check($GLOBALS['products'][101]->saves===0);check(count($GLOBALS['http_calls'])===1);check(is_string(auto_failure()));
};
$tests['recursive save and repeated hooks do not duplicate remote reads in the same request']=function(){
 $GLOBALS['products'][101]->on_save=fn()=>RKW_Auto_Product::after_parent_save(101);RKW_Auto_Product::after_parent_save(101);RKW_Auto_Product::after_parent_save(101);check(count($GLOBALS['http_calls'])===2);check($GLOBALS['products'][101]->saves===1);
};
$tests['variation save updates only its own Rahkaran id and preserves the parent fields']=function(){
 $parent=new SyncProduct(200,88);$parent->type='variable';$variant=new SyncProduct(102,31);$variant->type='variation';$variant->parent=200;$GLOBALS['products'][200]=$parent;$GLOBALS['products'][102]=$variant;
 $GLOBALS['http_handler']=function($url){parse_str(parse_url($url,PHP_URL_QUERY),$query);if(strpos($url,'/GetProduct?')!==false){check((int)$query['id']===31);return response(['productId'=>31,'fee'=>7000]);}check((int)$query['productId']===31);return response([['StoreID'=>2,'RemainingQuantity'=>3]]);};
 RKW_Auto_Product::after_variation_save(102,0);check($variant->regular==='700'&&$variant->qty===3&&$variant->saves===1);check($parent->saves===0&&$parent->regular==='100');
};
$tests['disabled auto refresh and missing mapping make no API requests']=function(){
 $GLOBALS['options'][RKW_OPT]['auto_product_on_save']=0;RKW_Auto_Product::update(101);check(!$GLOBALS['http_calls']);$GLOBALS['options'][RKW_OPT]['auto_product_on_save']=1;$GLOBALS['products'][101]->meta=[];RKW_Auto_Product::update(101);check(!$GLOBALS['http_calls']);
};
$tests['stock-only and price-only settings request only enabled data and keep disabled fields']=function(){
 $GLOBALS['options'][RKW_OPT]['sync_price']=0;$GLOBALS['http_handler']=fn($url)=>strpos($url,'/GetProduct?')!==false?response(['productId'=>30]):response([['StoreID'=>2,'RemainingQuantity'=>3]]);RKW_Auto_Product::update(101);check($GLOBALS['products'][101]->regular==='100'&&$GLOBALS['products'][101]->qty===3);
 auto_reset();$GLOBALS['options'][RKW_OPT]['sync_stock']=0;RKW_Auto_Product::update(101);check(count($GLOBALS['http_calls'])===1);check($GLOBALS['products'][101]->regular==='500'&&$GLOBALS['products'][101]->qty===9);
};
$tests['existing sale price and configured currency conversion remain unchanged']=function(){
 $GLOBALS['products'][101]->sale='400';RKW_Auto_Product::update(101);check($GLOBALS['products'][101]->regular==='500'&&$GLOBALS['products'][101]->price==='400');
 auto_reset();$GLOBALS['options'][RKW_OPT]['price_divisor']=0.1;RKW_Auto_Product::update(101);check($GLOBALS['products'][101]->regular==='50000');
};
$tests['fresh reads are repeated in a new request rather than reusing a product-list snapshot']=function(){
 product_snapshot(1200);RKW_Auto_Product::update(101);$property=new ReflectionProperty(RKW_Auto_Product::class,'completed');$property->setAccessible(true);$property->setValue(null,[]);RKW_Auto_Product::update(101);check(count($GLOBALS['http_calls'])===4);
};
$tests['success notice reports direct completion with duration and old warning notices stay compatible']=function(){
 RKW_Auto_Product::update(101);ob_start();RKW_Auto_Product::notice();$html=ob_get_clean();check(strpos($html,'notice-success')!==false);check(strpos($html,'مدت پردازش')!==false);check(!auto_failure());set_transient(RKW_Auto_Product::NOTICE_KEY.get_current_user_id(),'old warning',600);ob_start();RKW_Auto_Product::notice();$html=ob_get_clean();check(strpos($html,'notice-warning')!==false&&strpos($html,'old warning')!==false);
};
$tests['v19 direct refresh preserves per-product price request sale and remaining stock']=function(){
 $GLOBALS['options'][RKW_OPT]['sync_sale']=1;
 $GLOBALS['options'][RKW_OPT]['api']='v19';set_transient(RKW_Client::COOKIE_TRANSIENT,['name'=>'sg-auth-sg','value'=>'synthetic-cookie','signature'=>RKW_Policy_Catalog::signature(rkw_settings())],60);
 $GLOBALS['http_handler']=function($url,$args){if(strpos($url,'/product?')!==false)return response(['id'=>30,'code'=>'SKU-30','RetailUnitRef'=>1,'remaining'=>7]);check(strpos($url,'/Price')!==false&&$args['method']==='POST');$body=json_decode($args['body'],true);check($body['items'][0]['productId']===30&&$body['items'][0]['unitId']===1);return response([['itemId'=>1,'fee'=>7000,'discount'=>500,'netOfFee'=>6500]]);};
 RKW_Auto_Product::update(101);$p=$GLOBALS['products'][101];check($p->saves===1&&$p->qty===7&&$p->regular==='700'&&$p->sale==='650'&&$p->price==='650');check(count($GLOBALS['http_calls'])===2);
};
$tests['updating a variable parent refreshes all twenty independently linked variants']=function(){
 $parent=auto_family();auto_event('woocommerce_process_product_meta',200,null);
 check(count($GLOBALS['http_calls'])===40);check($parent->saves===0&&$parent->regular==='100'&&$parent->qty===9);
 foreach($parent->children as$i=>$id){$child=$GLOBALS['products'][$id];check($child->regular==='3450000'&&$child->qty===$i+1&&$child->saves===1);check($child->meta[RKW_Auto_Product::STATUS_KEY]['success']);}
 auto_event('woocommerce_save_product_variation',300,0);check(count($GLOBALS['http_calls'])===40);
};
$tests['scheduled publication runs after final mappings are saved without cron scheduling']=function(){
 $p=$GLOBALS['products'][101];$p->meta=[];$p->status='future';auto_event('transition_post_status','publish','future',(object)['ID'=>101,'post_type'=>'product']);check(!$GLOBALS['http_calls']);
 $p->status='publish';$p->meta['_rahkaran_product_id']=30;auto_event('shutdown');check($p->regular==='500'&&$p->qty===5&&count($GLOBALS['http_calls'])===2);
};
$tests['REST parent and variation saves share a deduplicated end of request refresh']=function(){
 $parent=auto_family(2);auto_event('woocommerce_rest_insert_product_object',$parent);auto_event('woocommerce_rest_insert_product_variation_object',$GLOBALS['products'][300]);check(!$GLOBALS['http_calls']);auto_event('shutdown');check(count($GLOBALS['http_calls'])===4);auto_event('shutdown');check(count($GLOBALS['http_calls'])===4);
};
$tests['CSV import and CRUD creation read final per-variation mappings']=function(){
 $parent=auto_family(1);$child=$GLOBALS['products'][300];$child->meta=[];auto_event('woocommerce_new_product',200);auto_event('woocommerce_new_product_variation',300);auto_event('woocommerce_product_import_inserted_product_object',$child);$child->meta['_rahkaran_product_id']=1000;auto_event('shutdown');check(count($GLOBALS['http_calls'])===2&&$child->regular==='3450000');check($parent->saves===0);
};
$tests['draft products and variants under unpublished parents never trigger publication reads']=function(){
 $parent=auto_family(1);$parent->status='draft';$GLOBALS['products'][101]->status='draft';auto_event('woocommerce_new_product',101);auto_event('woocommerce_new_product_variation',300);auto_event('shutdown');check(!$GLOBALS['http_calls']);
 auto_event('transition_post_status','publish','publish',(object)['ID'=>101,'post_type'=>'product']);auto_event('transition_post_status','publish','draft',(object)['ID'=>101,'post_type'=>'post']);$GLOBALS['products'][101]->status='publish';auto_event('shutdown');check(!$GLOBALS['http_calls']);
};
$tests['a missing child mapping is reported and cannot inherit parent or sibling identifiers']=function(){
 $parent=auto_family(2);$GLOBALS['products'][300]->meta=[];auto_event('woocommerce_process_product_meta',200);check($GLOBALS['products'][300]->saves===0&&$GLOBALS['products'][301]->saves===1);check(count($GLOBALS['http_calls'])===2);$status=$GLOBALS['products'][300]->meta[RKW_Auto_Product::STATUS_KEY];check(!$status['success']&&$status['rahkaran_id']===0&&strpos($status['message'],'خالی')!==false);check($parent->saves===0);
};
$tests['one failed variant is recorded without preventing the other variants from refreshing']=function(){
 $parent=auto_family(2);$handler=$GLOBALS['http_handler'];$GLOBALS['http_handler']=function($url,$args)use($handler){return strpos($url,'id=1000')!==false?new WP_Error('http_request_failed','synthetic variant timeout'):$handler($url,$args);};auto_event('woocommerce_process_product_meta',200);check(!$GLOBALS['products'][300]->meta[RKW_Auto_Product::STATUS_KEY]['success']);check($GLOBALS['products'][300]->regular==='100'&&$GLOBALS['products'][300]->qty===9);check($GLOBALS['products'][301]->saves===1&&$GLOBALS['products'][301]->regular==='3450000');
};
$tests['last refresh status survives transient notices and escapes external error text']=function(){
 RKW_Auto_Product::update(101);$p=$GLOBALS['products'][101];$status=$p->meta[RKW_Auto_Product::STATUS_KEY];check($status['rahkaran_id']===30&&$status['success']&&$status['time']>0);delete_transient(RKW_Auto_Product::NOTICE_KEY.get_current_user_id());check(strpos(RKW_Auto_Product::status_html($p),'rkw-product-refresh-status')!==false);$p->meta[RKW_Auto_Product::STATUS_KEY]['message']='<img src=x onerror=alert(1)>';check(strpos(RKW_Auto_Product::status_html($p),'<img')===false);check($p->saves===1);
};
$tests['disabled refresh and disabled variants are preserved when saving a variable parent']=function(){
 $parent=auto_family(2);$GLOBALS['products'][300]->status='private';auto_event('woocommerce_process_product_meta',200);check($GLOBALS['products'][300]->saves===0&&$GLOBALS['products'][301]->saves===1);
 auto_reset();$parent=auto_family(2);$GLOBALS['options'][RKW_OPT]['auto_product_on_save']=0;auto_event('woocommerce_process_product_meta',200);auto_event('woocommerce_rest_insert_product_object',$parent);auto_event('shutdown');check(!$GLOBALS['http_calls']);
};
$tests['a variable parent without children explains why there was no read']=function(){
 $parent=auto_family(0);auto_event('woocommerce_process_product_meta',200);check(!$GLOBALS['http_calls']&&$parent->saves===0);check(!$parent->meta[RKW_Auto_Product::STATUS_KEY]['success']);check(strpos($parent->meta[RKW_Auto_Product::STATUS_KEY]['message'],'متغیری ندارد')!==false);
};
$tests['configured legacy ID SKU mode links only after a successful fresh response']=function(){
 $p=$GLOBALS['products'][101];$p->meta=[];$p->sku='30';$GLOBALS['options'][RKW_OPT]['key_field']='id';auto_event('woocommerce_process_product_meta',101);check($p->regular==='500'&&$p->qty===5&&$p->meta['_rahkaran_product_id']===30);
 auto_reset();$p=$GLOBALS['products'][101];$p->meta=[];$p->sku='30';$GLOBALS['options'][RKW_OPT]['key_field']='id';$GLOBALS['http_handler']=fn()=>response(['productId'=>99,'fee'=>5000]);auto_event('woocommerce_process_product_meta',101);check($p->saves===0&&!isset($p->meta['_rahkaran_product_id']));check(!$p->meta[RKW_Auto_Product::STATUS_KEY]['success']);
};
$tests['explicit ID overrides a different SKU and code mode never guesses a numeric SKU as an ID']=function(){
 $GLOBALS['products'][101]->sku='999';$GLOBALS['options'][RKW_OPT]['key_field']='id';RKW_Auto_Product::update(101);check(strpos($GLOBALS['http_calls'][0][0],'id=30')!==false);
 auto_reset();$GLOBALS['products'][101]->meta=[];$GLOBALS['products'][101]->sku='30';RKW_Auto_Product::update(101);check(!$GLOBALS['http_calls']);check(!$GLOBALS['products'][101]->meta[RKW_Auto_Product::STATUS_KEY]['success']);
};
$tests['a failed refresh is not automatically repeated by a second publication hook']=function(){
 $GLOBALS['http_handler']=fn()=>new WP_Error('http_request_failed','synthetic read failed');auto_event('woocommerce_new_product',101);auto_event('woocommerce_process_product_meta',101);auto_event('shutdown');check(count($GLOBALS['http_calls'])===1);
};
$tests['deferred reads precede WooCommerce parent synchronization at shutdown']=function(){
 check(in_array([ [RKW_Auto_Product::class,'flush'],1 ],$GLOBALS['action_hooks']['shutdown'][5],true));
 auto_family(1);auto_event('woocommerce_new_product',200);$seen=false;add_action('shutdown',function()use(&$seen){$seen=$GLOBALS['products'][300]->regular==='3450000';},10);auto_event('shutdown');check($seen);
};
$fail=0;foreach($tests as$name=>$test){auto_reset();try{$test();echo 'PASS '.$name."\n";}catch(Throwable$e){$fail++;echo 'FAIL '.$name.': '.$e->getMessage().' at '.$e->getFile().':'.$e->getLine()."\n";}}
echo count($tests).' tests, '.$fail." failed\n";exit($fail?1:0);
