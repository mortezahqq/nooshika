<?php
define( 'RKW_AUTO_PRODUCT_FIXTURES_ONLY', true );
require __DIR__ . '/auto-product.php';

auto_reset();
$parent = auto_family( 2 );
$GLOBALS['options'][RKW_OPT]['sync_sale'] = 1;
$s = rkw_settings();
set_transient( RKW_Client::COOKIE_TRANSIENT, [
 'name' => 'sg-auth-sg', 'value' => 'synthetic-cookie', 'signature' => RKW_Policy_Catalog::signature( $s ),
], 60 );
$GLOBALS['products'][300]->meta['_rahkaran_product_id'] = 174541;
$GLOBALS['products'][301]->meta['_rahkaran_product_id'] = 174537;
$GLOBALS['http_handler'] = function ( $url, $args ) {
 parse_str( parse_url( $url, PHP_URL_QUERY ) ?? '', $query );
 if ( str_contains( $url, '/GetProduct?' ) ) {
  return response( [ 'productId' => (int) $query['id'], 'fee' => 5950000, 'RetailUnitRef' => 1 ] );
 }
 if ( str_contains( $url, '/GetRemainingQuantityInfo?' ) ) {
  return response( [ [ 'StoreID' => 2, 'RemainingQuantity' => (int) $query['productId'] === 174537 ? 0 : 4 ] ] );
 }
 check( str_ends_with( $url, '/InvoiceService.svc/calculateAmount' ) );
 $document = json_decode( $args['body'], true );
 check( $document['customerId'] === 0 && count( $document['items'] ) === 1 );
 $item = $document['items'][0];
 check( $item['unitId'] === 1 && $item['quantity'] === 1 );
 $white = $item['productId'] === 174537;
 return response( [ 'hasError' => false, 'netPrice' => 2975000, 'items' => [ [
  'productId' => $item['productId'], 'unitId' => 1, 'quantity' => 1,
  'price' => 5950000, 'netPrice' => 2975000, 'hasError' => $white,
  'errorMessage' => $white ? 'موجودی محصول در انبار کافی نیست. (1 واحد کسری دارد) ' : null,
  'policies' => [ [ 'type' => 'CustomRetailMeasurementUnitDiscount', 'policyId' => 439,
   'isIncluded' => true, 'effect' => 3, 'price' => 2975000 ] ],
 ] ] ] );
};
RKW_Auto_Product::after_parent_save( 200 );
check( $GLOBALS['products'][300]->sale === '297500' && $GLOBALS['products'][300]->qty === 4 );
check( $GLOBALS['products'][301]->sale === '297500' && $GLOBALS['products'][301]->qty === 0 );
check( count( $GLOBALS['http_calls'] ) === 6 );
echo "PASS per-color public discount saves even with documented stock shortage\n";

$item = [ 'id' => 174541, 'unit' => 1, 'price' => 5950000, 'sale' => null ];
$client = new RKW_Client();
foreach ( [ 'wrong product', 'wrong total', 'arbitrary error' ] as $failure ) {
 $definition = [
  'productId' => $failure === 'wrong product' ? 174537 : 174541,
  'unitId' => 1, 'quantity' => 1, 'price' => 5950000, 'netPrice' => 2975000,
  'hasError' => $failure === 'arbitrary error', 'errorMessage' => 'خطا در قیمت',
  'policies' => [ [ 'type' => 'Discount', 'isIncluded' => true, 'effect' => 3, 'price' => 2975000 ] ],
 ];
 $GLOBALS['http_handler'] = fn() => response( [
  'netPrice' => $failure === 'wrong total' ? 3100000 : 2975000, 'items' => [ $definition ],
 ] );
 check( RKW_Sync::calculate_sale( $item, $s, $client )['sale'] === null );
}
echo "PASS unverified calculation cannot set a sale price\n";
