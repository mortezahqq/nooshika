<?php
require __DIR__ . '/bootstrap.php';
reset_case();
$GLOBALS['http_handler'] = function ( $url, $args ) {
 check( str_ends_with( $url, '/InvoiceService.svc/calculateAmount' ) );
 check( $args['method'] === 'POST' );
 $document = json_decode( $args['body'], true );
 check( $document['customerId'] === 0 && $document['status'] === 0 );
 check( $document['policies'] === [] && ! isset( $document['receipts'] ) );
 $item = $document['items'][0];
 check( $item['productId'] === 174541 && $item['quantity'] === 1 && $item['unitId'] === 2 );
 return response( [ 'netPrice' => 5000000, 'items' => [
  [ 'productId' => 174541, 'netPrice' => 5000000, 'policies' => [
   [ 'policyId' => 42, 'policyConditionRowId' => 7, 'isIncluded' => true, 'price' => 950000 ],
  ] ],
 ] ] );
};
$method = new ReflectionMethod( RKW_Modules::class, 'public_price_calculation' );
$method->setAccessible( true );
$result = $method->invoke( null, new RKW_Client(), [ 'id' => 174541, 'unit' => 2 ], rkw_settings() );
check( (float) $result['netPrice'] === 5000000.0 );
check( $result['ردیف‌های کالا'][0]['policies'][0]['policyId'] === 42 );
check( count( $GLOBALS['http_calls'] ) === 1 );
echo "PASS calculateAmount public customer, quantity one, policy summary and no SaveInvoice\n";
