/* global rkwDocumentProbe */
(() => {
 'use strict';
 const button=document.getElementById('rkw-document-probe');if(!button)return;
 const input=document.getElementById('rkw-payment-order-id'),out=document.getElementById('rkw-payment-diagnose-output'),cfg=window.rkwDocumentProbe||{};
 let busy=false;
 async function request(action,fields){
  const response=await fetch(cfg.ajax,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({action,nonce:cfg.nonce||'',...fields})});
  const data=await response.json();if(!response.ok||!data.success)throw new Error(data.data?.message||'پاسخ بررسی خوانده نشد.');return data.data;
 }
 button.addEventListener('click',async()=>{
  if(busy)return;out.style.display='block';out.dir='rtl';
  const id=input.value.trim();if(!/^[1-9][0-9]*$/.test(id)){out.textContent='شناسه سفارش معتبر وارد کنید.';return;}
  const controls=[input,button,document.getElementById('rkw-payment-diagnose'),document.getElementById('rkw-invoice-calculate')].filter(Boolean);
  if(controls.some(n=>n.disabled)){out.textContent='بررسی قبلی هنوز در حال اجراست؛ پس از پایان آن ادامه دهید.';return;}
  busy=true;controls.forEach(n=>{n.disabled=true;});out.textContent='در حال دریافت تعریف‌های زنده؛ هیچ فاکتوری صادر نمی‌شود…';
  try{
   let r=await request('rkw_document_probe_start',{order_id:id}),previous=-1,steps=0;
   out.textContent=r.text;
   while(!r.done){
    if(!r.token||!Number.isInteger(r.completed)||r.completed<=previous||++steps>20)throw new Error('پیشرفت بررسی تأیید نشد؛ هیچ درخواستی برای ثبت سند انجام نشد.');
    previous=r.completed;r=await request('rkw_document_probe_step',{order_id:id,token:r.token});out.textContent=r.text;
   }
  }catch(error){out.textContent+='\nبررسی کامل نشد: '+(error.message||'پاسخ دریافت نشد.')+'\nاین دکمه برای ثبت فاکتور نیست؛ تلاش مجدد خودکار انجام نشد.';}
  finally{busy=false;controls.forEach(n=>{n.disabled=false;});}
 });
})();
