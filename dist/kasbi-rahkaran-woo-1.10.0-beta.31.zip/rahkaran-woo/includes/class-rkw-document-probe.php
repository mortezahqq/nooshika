<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Explicit, resumable GET-only inspection. Never calls a document/customer/product writer. */
class RKW_Document_Probe {
 const NONCE = 'rkw_document_probe';
 const LIMIT = 5;
 public static function init() {
  add_action('wp_ajax_rkw_document_probe_start',array(__CLASS__,'ajax_start'));
  add_action('wp_ajax_rkw_document_probe_step',array(__CLASS__,'ajax_step'));
  add_action('wp_ajax_rkw_receipt_reference',array(__CLASS__,'ajax_reference'));
  add_action('admin_enqueue_scripts',array(__CLASS__,'assets'));
 }
 public static function assets($hook) {
  if(!current_user_can('manage_woocommerce')||($_GET['page']??'')!=='rkw'||($_GET['tab']??'')!=='orders')return;
  wp_enqueue_script('rkw-document-probe',plugins_url('assets/document-probe.js',RKW_FILE),array(),RKW_VER,true);
  wp_localize_script('rkw-document-probe','rkwDocumentProbe',array('ajax'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce(self::NONCE)));
 }
 private static function context($o) {
  if(!$o instanceof WC_Order||'shop_order'!==$o->get_type())return new WP_Error('rkw_probe_order','سفارش ووکامرس معتبر پیدا نشد.');
  $s=rkw_settings();if('v21'!==$s['api']||'invoice'!==$s['order_mode'])return new WP_Error('rkw_probe_mode','این بررسی برای فاکتور فروش با API نسخه ۲۱ است.');
  $p=RKW_Payment::resolve($o,$s);if(is_wp_error($p))return$p;
  $items=array();$missing=0;
  foreach($o->get_items()as$item){$product=$item->get_product();$id=$product?absint($product->get_meta('_rahkaran_product_id')):0;$unit=$product?absint($product->get_meta('_rahkaran_unit_id')):0;$unit=$unit?:absint($s['default_unit_id']);if(!$id){$missing++;continue;}
   if(!isset($items[$id]))$items[$id]=array('product_id'=>$id,'units'=>array(),'quantity'=>0.0);
   $items[$id]['units'][$unit]=$unit;$items[$id]['quantity']+=(float)$item->get_quantity();
  }
  foreach($items as&$item)$item['units']=array_values($item['units']);unset($item);
  $attrs=RKW_Payment::receipts($o,(float)$o->get_total()*rkw_price_multiplier($s),$p);
  $source=array('order_id'=>(int)$o->get_id(),'plugin_version'=>RKW_VER,'contract'=>$s['document_contract'],'gateway'=>$p['gateway'],'mapping_source'=>$p['mapping_source'],'policy_id'=>(int)$p['settlement_id'],'receipt_key'=>$p['receipt_key'],'coupon_type_id'=>(int)($p['coupon_type_id']??0),'bank_ref'=>(int)$p['bank_account_ref'],'store_id'=>(int)$s['inventory_id'],'pattern_id'=>(int)($s['invoice_doc_pattern_id']?:$s['doc_pattern_id']),'loyalty_program_id'=>(int)$s['loyalty_id'],'amount'=>round((float)$o->get_total()*rkw_price_multiplier($s),2),'payment_attr_keys'=>array_keys($attrs[0]['attr']??array()),'products'=>array_values($items),'missing_product_mappings'=>$missing);
  return array('source'=>$source,'signature'=>hash('sha256',wp_json_encode(array(RKW_Policy_Catalog::signature($s),$source,$o->get_status(),$o->get_meta('_rkw_customer_id')))));
 }
 private static function key($token){return 'rkw_document_probe_'.get_current_user_id().'_'.hash('sha256',$token);}
 public static function start($o) {
  $c=self::context($o);if(is_wp_error($c))return$c;$s=$c['source'];
  $tasks=array(array('kind'=>'policy','id'=>$s['policy_id']));
  if('ThirdPartyCoupon'===$s['receipt_key'])$tasks[]=array('kind'=>'coupon','id'=>$s['coupon_type_id']);
  foreach(array_slice($s['products'],0,self::LIMIT)as$item){$tasks[]=array('kind'=>'product','id'=>$item['product_id']);$tasks[]=array('kind'=>'stock','id'=>$item['product_id']);}
  if($s['loyalty_program_id'])$tasks[]=array('kind'=>'loyalty','id'=>$s['loyalty_program_id']);
  $token=wp_generate_uuid4();$state=array('signature'=>$c['signature'],'tasks'=>$tasks,'index'=>0,'report'=>array('source'=>$s,'scope'=>'current_order_and_settings','financial_document_sent'=>false,'definition_checks'=>array(),'products_not_inspected'=>max(0,count($s['products'])-self::LIMIT),'notes'=>array('تعریف‌ها از سرویس‌های نسخه ۲۱ خوانده می‌شوند؛ موفقیت این بررسی، تأیید ثبت ESales یا دریافت وجه نیست.','موجودی این سرویس جایگزین کنترل کاردکس، رزرو و سال مالی هنگام ثبت نیست.','ویژگی‌های روش تسویه توصیفی‌اند؛ مقدار True یا False به‌تنهایی نام فیلد JSON، مقدار لازم یا الزام آن را تعیین نمی‌کند.','شناسه‌های تنظیم ThirdPartyCouponType فقط برای مقایسه نمایش داده می‌شوند؛ تطبیق یا عدم تطبیق، به‌تنهایی فهرست بن‌های مجاز را اثبات نمی‌کند.','هویت مشتری و عضویت او در برنامه وفاداری با این گزارش تأیید نمی‌شود؛ واحد پیش‌فرض کالا هم فهرست همه واحدهای مجاز آن نیست.')));
  set_transient(self::key($token),$state,15*MINUTE_IN_SECONDS);
  return array('token'=>$token,'done'=>false,'completed'=>0,'total'=>count($tasks),'text'=>'بررسی تعریف‌های زنده آغاز شد؛ هیچ سندی صادر نمی‌شود.');
 }
 private static function num($row,$key){$v=$row[$key]??null;return is_numeric($v)&&is_finite((float)$v)?(float)$v:null;}
 private static function identifier($row,$fields){foreach($fields as$key){$v=$row[$key]??null;if((is_int($v)||is_string($v))&&preg_match('/^[1-9][0-9]*$/D',(string)$v)&&(string)(int)$v===(string)$v)return(int)$v;}return 0;}
 private static function list_rows($v){if(!is_array($v))return null;if(isset($v['items'])&&is_array($v['items']))$v=$v['items'];return array_values($v)===$v?$v:null;}
 private static function flag($row,$key){return isset($row[$key])&&is_bool($row[$key])?$row[$key]:null;}
 private static function symbol($v){return is_string($v)&&preg_match('/^[A-Za-z][A-Za-z0-9_]{0,79}$/D',$v)?$v:null;}
 /** Display only bounded identifiers from this named configuration field; never arbitrary text. */
 private static function reference_configuration($value) {
  if(null===$value||''===$value)return array('format'=>'empty','ids'=>array());
  $format='identifier';$values=array($value);
  if(is_string($value)){
   if(strlen($value)>2000)return array('format'=>'unrecognized','ids'=>null);
   $text=trim($value);
   if(''===$text)return array('format'=>'empty','ids'=>array());
   if('['===substr($text,0,1)){$values=json_decode($text,true);$format='json_list';}
   elseif(false!==strpos($text,',')){$values=explode(',',$text);$format='csv';}
   else{$values=array($text);}
  }elseif(is_array($value)){$values=$value;$format='list';}
  if(!is_array($values)||array_values($values)!==$values||count($values)>100)return array('format'=>'unrecognized','ids'=>null);
  $ids=array();foreach($values as$id){if(is_string($id))$id=trim($id);if(!(is_int($id)||is_string($id))||!preg_match('/^[1-9][0-9]{0,9}$/D',(string)$id)||(float)$id>1000000000)return array('format'=>'unrecognized','ids'=>null);$ids[(int)$id]=(int)$id;}
  return array('format'=>$format,'ids'=>array_values($ids));
 }
 private static function attributes($attrs) {
  $out=array();foreach(is_array($attrs)?array_slice($attrs,0,30):array()as$a){if(!is_array($a))continue;$key=self::symbol($a['attributeKey']??null);if(!$key)continue;$v=$a['value']??null;
   // Values can contain bank/customer/session data. Only small numeric/boolean
   // configuration values are shown; text descriptions and opaque text never are.
   $sensitive=preg_match('/password|token|cookie|secret|session|mobile|phone|email|national|address|iban|cardnumber|accountnumber|transaction|^pin$|^cvv/iu',$key);
   $reference=in_array(strtolower($key),array('coupontype','coupontyperef','thirdpartycoupontype','thirdpartycoupontyperef','thirdpartyref','thirdpartyorganizationref','bankaccountref','ereceipttype','currencyref','currencyid','unitref','unitid'),true);
   $safe=$sensitive?null:(is_bool($v)||null===$v?$v:($reference&&is_numeric($v)&&is_finite((float)$v)&&abs((float)$v)<=1000000000?(float)$v:(in_array($v,array('True','False','true','false'),true)?$v:null)));
   $entry=array('key'=>$key,'value_type'=>gettype($v),'configuration_value'=>$safe,'opaque_value_omitted'=>null!==$v&&null===$safe);
   if('thirdpartycoupontype'===strtolower($key))$entry['reference_configuration']=self::reference_configuration($v);
   $out[]=$entry;
  }return$out;
 }
 private static function policy($raw,$id,$key,$coupon_type=0) {
  $actual=is_array($raw)?self::identifier($raw,array('settlementPolicyID','settlementPolicyId','id','ID')):0;
  if($actual!==$id)return array('status'=>'unverified','requested_id'=>$id,'response_id'=>$actual,'reason'=>'missing_or_different_policy_id');
  $groups=array();$found=false;$complete=true;$methods=0;$seen=0;$reported=0;
  $rows=isset($raw['settlementMethodGroups'])?self::list_rows($raw['settlementMethodGroups']):null;if(null===$rows)$complete=false;
  foreach(array_slice($rows??array(),0,30)as$g){if(!is_array($g)){$complete=false;continue;}$group=array('id'=>self::identifier($g,array('settlementMethodGroupID','id')),'methods'=>array());
   foreach(array('minPercent','maxPercent','minAmount','maxAmount','priority')as$f)$group[$f]=self::num($g,$f);$group['morePaymentAllowed']=self::flag($g,'morePaymentAllowed');
   $list=isset($g['settlementMethods'])?self::list_rows($g['settlementMethods']):null;if(null===$list){$complete=false;$list=array();}
   foreach(array_slice($list,0,100)as$m){if(!is_array($m)){$complete=false;continue;}$nature=self::symbol($m['settlementNatureKey']??null);if(!$nature){$complete=false;continue;}$methods++;$matches=$nature===$key;if($matches)$found=true;
    // Count all matching methods; do not choose one or inject its attributes.
    if($matches)$seen++;
    if($reported<40){$reported++;$entry=array('id'=>self::identifier($m,array('settlementMethodID','id')),'key'=>$nature,'selected_key'=>$matches,'is_internal'=>self::flag($m,'isInternal'),'system_defined'=>self::flag($m,'systemDefined'),'attributes'=>self::attributes($m['attributes']??array()),'attributes_schema_valid'=>is_array($m['attributes']??null)&&array_values($m['attributes'])===$m['attributes'],'attributes_truncated'=>is_array($m['attributes']??null)&&count($m['attributes'])>30);
     foreach(array('thirdPartyRef','thirdPartyOrganizationRef','thirdPartyCouponTypeRef','couponType','bankAccountRef')as$f)if(isset($m[$f]))$entry[$f]=self::num($m,$f);
     if($matches&&'ThirdPartyCoupon'===$nature){
      $entry['selected_coupon_type_id']=(int)$coupon_type;$entry['selected_type_matches_reference_ids']=null;
      foreach($entry['attributes']as$attribute){if('thirdpartycoupontype'!==strtolower($attribute['key']))continue;$refs=$attribute['reference_configuration']['ids']??null;if(is_array($refs)&&$refs)$entry['selected_type_matches_reference_ids']=in_array((int)$coupon_type,$refs,true);}
      $entry['reference_semantics']='Configuration identifiers only; a match does not prove the allowed set or the ESales wire contract.';
     }
     $group['methods'][]=$entry;
    }
   }
   if(count($list)>100)$complete=false;
   $group['available_keys']=array_values(array_unique(array_filter(array_map(static function($m){return is_array($m)?self::symbol($m['settlementNatureKey']??null):null;},array_slice($list,0,100)))));
   $groups[]=$group;
  }
  if(count($rows??array())>30)$complete=false;
  return array('status'=>'read','id'=>$actual,'selected_key'=>$key,'selected_key_found'=>$found?true:(''!==$key&&$complete&&$methods?false:null),'matching_method_count'=>$seen,'schema_complete'=>$complete,'methods_not_displayed'=>max(0,$methods-$reported),'groups'=>$groups);
 }
 private static function read($task,$source) {
  $c=new RKW_Client();$id=(int)$task['id'];
  switch($task['kind']){
   case'policy':$r=$c->call('GET','Retail/Api/DocumentStructure/SettlementPolicyService.svc/getSettlementPolicy',array('settlementPolicyId'=>$id),null,false);break;
   case'coupon':$r=$c->call('GET','Retail/Api/Promotions/RetailPromotionService.svc/thirdPartyCouponType',array('id'=>$id),null,false);break;
   case'product':$r=$c->call('GET','Retail/Api/Structure/ProductService.svc/GetProduct',array('id'=>$id),null,false);break;
   case'stock':$r=$c->call('GET','Retail/Api/DocumentStructure/StoreService.svc/GetRemainingQuantityInfo',array('productId'=>$id),null,false);break;
   case'loyalty':$r=$c->call('GET','Retail/LoyaltyApi/RetailLoyaltyProgramService.svc/loyaltyProgram',array('page'=>1,'count'=>50),null,false);break;
   default:return array('status'=>'unverified','reason'=>'unknown_task');
  }
  if(is_wp_error($r)){$d=$r->get_error_data();return array('status'=>'read_error','error_code'=>sanitize_key($r->get_error_code()),'http_status'=>is_array($d)?(int)($d['http_status']??0):0,'sequence_empty'=>false!==stripos($r->get_error_message(),'Sequence contains no elements'));}
  if('policy'===$task['kind'])return self::policy($r,$id,$source['receipt_key'],(int)$source['coupon_type_id']);
  if('coupon'===$task['kind']){$actual=is_array($r)?self::identifier($r,array('Id','id')):0;return array('status'=>$actual===$id?'read':'unverified','requested_id'=>$id,'response_id'=>$actual,'is_default'=>is_array($r)?self::flag($r,'isDefault'):null,'third_party_name_present'=>is_array($r)&&!empty($r['thirdPartyName']));}
  if('product'===$task['kind']){$it=RKW_Sync::normalize_single($r,'v21');return array('status'=>$it&&(int)$it['id']===$id?'read':'unverified','requested_id'=>$id,'response_id'=>$it?(int)$it['id']:0,'default_unit_id'=>$it?$it['unit']:null,'fee'=>$it?$it['price']:null);}
  if('stock'===$task['kind']){$rows=self::list_rows($r);$found=array();foreach($rows??array()as$row){if(!is_array($row))continue;$sid=self::identifier($row,array('StoreID','storeID'));if($sid===$source['store_id'])$found[]=array('store_id'=>$sid,'remaining_quantity'=>self::num($row,'RemainingQuantity')??self::num($row,'remainingQuantity'));}return array('status'=>null===$rows?'unverified':'read','store_id'=>$source['store_id'],'store_rows'=>$found,'store_found'=>(bool)$found,'returned_row_count'=>null===$rows?null:count($rows));}
  $rows=self::list_rows($r);$found=false;foreach($rows??array()as$row){if(is_array($row)&&self::identifier($row,array('Id','id','programId'))===$id)$found=true;}return array('status'=>null===$rows?'unverified':'read','requested_id'=>$id,'found_on_first_page'=>$found,'page'=>1,'page_size'=>50,'membership_verified'=>false);
 }
 public static function step($o,$token) {
  if(!is_string($token)||!preg_match('/^[a-f0-9-]{16,64}$/D',$token))return new WP_Error('rkw_probe_token','شناسه بررسی معتبر نیست؛ بررسی را دوباره شروع کنید.');
  $key=self::key($token);$state=get_transient($key);if(!is_array($state))return new WP_Error('rkw_probe_expired','بررسی منقضی شده یا متعلق به کاربر دیگری است؛ دوباره شروع کنید.');
  $lock='rkw_probe_lock_'.hash('sha256',$token);if(!add_option($lock,'1','',false))return new WP_Error('rkw_probe_busy','همین بررسی در حال اجراست.');
  try{
   // Re-read after acquiring the probe lock so overlapping GET requests cannot lose progress.
   $state=get_transient($key);if(!is_array($state))return new WP_Error('rkw_probe_expired','بررسی منقضی شده است.');
   $context=self::context($o);if(is_wp_error($context))return$context;if(!hash_equals($state['signature'],$context['signature']))return new WP_Error('rkw_probe_changed','سفارش یا تنظیمات در حین بررسی تغییر کرد؛ بررسی را دوباره شروع کنید.');
   $index=$state['index'];if($index<count($state['tasks'])){$task=$state['tasks'][$index];$result=self::read($task,$context['source']);$after=self::context(wc_get_order($o->get_id()));if(is_wp_error($after)||!hash_equals($state['signature'],$after['signature']))return new WP_Error('rkw_probe_changed','سفارش یا تنظیمات هنگام دریافت تغییر کرد؛ نتیجه با داده‌های قبلی ترکیب نشد.');$state['report']['definition_checks'][]=array('kind'=>$task['kind'],'id'=>$task['id'],'result'=>$result);$state['index']++;set_transient($key,$state,15*MINUTE_IN_SECONDS);}
   $done=$state['index']>=count($state['tasks']);$text='بررسی تعریف‌های زنده سفارش #'.$o->get_id().' — '.$state['index'].' از '.count($state['tasks'])."\n";
   if($done)$text.="این گزارش محل قطعی استثنای داخلی ESales را تعیین نمی‌کند؛ تعریف‌های قابل مشاهده را برای بررسی تسویه و کالا جمع‌آوری می‌کند.\n";
   $text.=wp_json_encode($state['report'],JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES)."\nهیچ فاکتور، مشتری یا محصولی ذخیره نشد؛ مبلغ و روش پرداخت تغییر نکرد.";
   return array('token'=>$token,'done'=>$done,'completed'=>$state['index'],'total'=>count($state['tasks']),'report'=>$state['report'],'text'=>$text);
  }finally{delete_option($lock);}
 }
 private static function order(){
  if(!current_user_can('manage_woocommerce')||!check_ajax_referer(self::NONCE,'nonce',false))wp_send_json_error(array('message'=>'دسترسی یا نشست نامعتبر است.'),403);
  $raw=$_POST['order_id']??'';if(!is_scalar($raw)||!preg_match('/^[1-9][0-9]*$/D',(string)$raw)||(string)(int)$raw!==(string)$raw)wp_send_json_error(array('message'=>'شناسه سفارش معتبر وارد کنید.'),400);
  $o=wc_get_order((int)$raw);if(!$o instanceof WC_Order||'shop_order'!==$o->get_type())wp_send_json_error(array('message'=>'سفارش ووکامرس پیدا نشد.'),404);return$o;
 }
 private static function reply($r){if(is_wp_error($r))wp_send_json_error(array('message'=>$r->get_error_message()),409);wp_send_json_success($r);}
 /** A response DTO is evidence about a saved receipt, never a template to POST. */
 private static function reference_fields($row,$depth=0) {
  if(!is_array($row))return array('type'=>gettype($row));
  $out=array('type'=>'array','field_count'=>count($row),'fields'=>array(),'truncated'=>count($row)>40);
  if($depth<=1&&array_values($row)===$row){
   foreach(array_slice($row,0,40)as$attribute){if(!is_array($attribute))continue;$name=self::symbol($attribute['attributeKey']??($attribute['key']??null));if(!$name)continue;
    $profile=self::reference_fields(array($name=>$attribute['value']??null),2);$out['fields']=array_merge($out['fields'],$profile['fields']);
   }return$out;
  }
  foreach(array_slice($row,0,40,true)as$key=>$value){
   $name=self::symbol($key);if(!$name)continue;$entry=array('key'=>$name,'type'=>gettype($value));
   $normalized=strtolower(str_replace('_','',$name));
   // Show values only for named voucher configuration, never serials, dates,
   // descriptions, account numbers, authentication or customer fields.
   if(in_array($normalized,array('count','couponcount','thirdpartycouponcount','quantity','coupontype','coupontypeid','coupontyperef','thirdpartycoupontype','thirdpartycoupontypeid','thirdpartycoupontyperef'),true)){
    if((is_int($value)||is_float($value)||is_string($value))&&is_numeric($value)&&is_finite((float)$value)&&abs((float)$value)<=1000000000)$entry['numeric_value']=(float)$value;
    elseif(is_array($value)){$entry['reference_id']=self::identifier($value,array('id','Id','ID'));}
   }
   if($depth<1&&in_array($normalized,array('attr','details','attributes'),true))$entry['shape']=self::reference_fields($value,$depth+1);
   $out['fields'][]=$entry;
  }return$out;
 }
 private static function reference_report($raw,$id,$contract) {
  if(!is_array($raw)||array_values($raw)===$raw)return array('status'=>'unverified','reason'=>'missing_document_object');
  $document=isset($raw['document'])&&is_array($raw['document'])?$raw['document']:$raw;
  $actual=self::identifier($document,array('id','Id','ID','invoiceId','invoiceID','documentId','documentID'));
  if(!$actual&&$document!==$raw)$actual=self::identifier($raw,array('id','Id','ID','invoiceId','invoiceID','documentId','documentID'));
  $out=array('status'=>$actual===$id?'read':'unverified','requested_id'=>$id,'response_id'=>$actual,'identity_verified'=>$actual===$id,'contract'=>$contract,'number_is_not_id'=>true);
  if($actual!==$id){$out['reason']='missing_or_different_invoice_id';$out['document_shape']=self::reference_fields($document,2);return$out;}
  $out['document_number']=self::identifier($document,array('number','Number','documentNumber','invoiceNumber'))?:null;
  $out['settlement_policy_id']=self::identifier($document,array('settlementPolicyId','settlementPolicyID'));
  $out['receipts']=array();$out['third_party_coupon_found']=false;
  foreach(array('payments','receipts')as$container){
   $rows=$raw[$container]??($document[$container]??null);$list=self::list_rows($rows);
   $out[$container.'_schema']=array('present'=>null!==$rows,'valid_list'=>null!==$list,'count'=>null!==$list?count($list):null,'truncated'=>count($list??array())>20);
   foreach(array_slice($list??array(),0,20)as$row){if(!is_array($row))continue;
    $key=self::symbol($row['key']??($row['settlementNature']??($row['settlementNatureKey']??($row['natureKey']??null))));
    if('ThirdPartyCoupon'===$key)$out['third_party_coupon_found']=true;
    $out['receipts'][]=array('container'=>$container,'key'=>$key,'amount'=>self::num($row,'amount'),'shape'=>self::reference_fields($row));
   }
  }
  $out['response_is_post_contract']=false;return$out;
 }
 public static function ajax_reference(){
  if(!current_user_can('manage_woocommerce')||!check_ajax_referer(self::NONCE,'nonce',false))wp_send_json_error(array('message'=>'دسترسی یا نشست نامعتبر است.'),403);
  $id=$_POST['invoice_id']??'';$contract=$_POST['contract']??'';
  if(!is_string($id)||!preg_match('/^[1-9][0-9]*$/D',$id)||(string)(int)$id!==$id||!in_array($contract,array('legacy_esales','v21'),true))wp_send_json_error(array('message'=>'شناسه داخلی فاکتور و مسیر خواندن معتبر نیست.'),400);
  $s=rkw_settings();if('v21'!==$s['api'])self::reply(new WP_Error('rkw_reference_version','این بررسی برای اتصال API ۲۱ است.'));
  $signature=RKW_Policy_Catalog::signature($s);$c=new RKW_Client();
  $r='legacy_esales'===$contract?$c->call('GET','Services/Retail/ESales.svc/invoice',array('id'=>(int)$id),null,false):$c->call('GET','Retail/Api/RetailDocuments/InvoiceService.svc/GetInvoice',array('invoiceId'=>(int)$id),null,false);
  if(!hash_equals($signature,RKW_Policy_Catalog::signature()))self::reply(new WP_Error('rkw_reference_changed','اتصال هنگام بررسی تغییر کرد؛ نتیجه کنار گذاشته شد.'));
  $error_data=is_wp_error($r)?$r->get_error_data():null;
  $report=is_wp_error($r)?array('status'=>'read_error','requested_id'=>(int)$id,'contract'=>$contract,'error_code'=>sanitize_key($r->get_error_code()),'http_status'=>is_array($error_data)?(int)($error_data['http_status']??0):0):self::reference_report($r,(int)$id,$contract);
  self::reply(array('report'=>$report,'text'=>wp_json_encode($report,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES)));
 }
 public static function ajax_start(){self::reply(self::start(self::order()));}
 public static function ajax_step(){$o=self::order();self::reply(self::step($o,isset($_POST['token'])?wp_unslash($_POST['token']):''));}
}
