<?php
require __DIR__.'/bootstrap.php';
function probe_order(){
 reset_case();$o=order(2495000);$o->id=214783;$o->gateway='WC_Gateway_SnappPay';$s=rkw_settings();$s['document_contract']='legacy_esales';$s['inventory_id']=2;$s['payment_rules']=[['gateway'=>$o->gateway,'settlement_id'=>45,'receipt_key'=>'ThirdPartyCoupon','coupon_type_id'=>5]];$GLOBALS['options'][RKW_OPT]=$s;
 set_transient(RKW_Client::COOKIE_TRANSIENT,['name'=>'sg-auth-sg','value'=>'synthetic','signature'=>RKW_Policy_Catalog::signature($s)],60);$GLOBALS['test_orders']=[$o->id=>$o];$GLOBALS['probe_response']=['netPrice'=>24950000,'items'=>[],'policies'=>[]];
 $GLOBALS['http_handler']=function($url,$args){if(strpos($url,'thirdPartyCouponTypes')!==false){check($args['method']==='GET');return response([['Id'=>5]]);}check($args['method']==='POST'&&strpos($url,'/calculateAmount')!==false,'unexpected potentially financial request: '.$url);$d=json_decode($args['body'],true);check(!isset($d['description']));check($d['id']===0&&$d['status']===0);return $GLOBALS['probe_response'] instanceof WP_Error?$GLOBALS['probe_response']:response($GLOBALS['probe_response']);};return $o;
}
$tests=[];
$tests['reported Snapp case calculates without saving a document or mutating order and settings']=function(){
 $o=$GLOBALS['test_orders'][214783];$before=$o->meta;$settings=get_option(RKW_OPT);$r=RKW_Invoice_Diagnostics::inspect($o);check(!is_wp_error($r));check($r['financial_document_sent']===false);check($r['wire']['tender_total']===24950000.0);check($r['calculation']['gap_from_tenders']===0.0);check($o->meta===$before);check(get_option(RKW_OPT)===$settings);check(count($GLOBALS['http_calls'])===2);check(!save_calls());check(!$o->get_meta('_rkw_doc_id'));
};
$tests['server automatic discount is reported and never balanced by modifying a receipt']=function(){
 $o=$GLOBALS['test_orders'][214783];$GLOBALS['probe_response']=['netPrice'=>22455000,'policies'=>[['policyId'=>90,'price'=>2495000,'effect'=>1]],'items'=>[]];$r=RKW_Invoice_Diagnostics::inspect($o);check($r['calculation']['gap_from_tenders']===-2495000.0);check($r['calculation']['policies'][0]['id']===90);check($r['wire']['tender_total']===24950000.0);check(!$o->get_meta('_rkw_reconcile_required'));
};
$tests['legacy price unit totals multiply quantity while native totals are already line amounts']=function(){
 $wire=['document'=>['items'=>[['productId'=>30,'unitId'=>1,'quantity'=>3,'fee'=>100,'price'=>80]],'policies'=>[['policyId'=>5,'price'=>10,'effect'=>'Decrease']]],'payments'=>[['key'=>'Cash','amount'=>230]]];$r=RKW_Invoice_Diagnostics::wire_summary($wire,'legacy_esales');check($r['item_base_total']===240.0);check($r['document_total_estimate']===230.0);$wire['document']['items'][0]['price']=240;$r=RKW_Invoice_Diagnostics::wire_summary($wire,'v21');check($r['item_base_total']===240.0);
};
$tests['policy-only rows estimate from unit fee and apply a whole-line discount once']=function(){
 $w=['document'=>['items'=>[['quantity'=>2,'fee'=>100,'policies'=>[['policyId'=>80,'price'=>20,'effect'=>'Decrease']]]]]];$r=RKW_Invoice_Diagnostics::wire_summary($w,'legacy_esales');check($r['item_base_total']===200.0);check($r['item_net_total_estimate']===180.0);
};
$tests['legacy fee preserves original unit subtotal while price stays discounted without a policy']=function(){
 $o=$GLOBALS['test_orders'][214783];$o->total=250;$o->items=[new TestItem(250,0,2,300)];$p=RKW_Orders::preview_invoice_payload($o);check(!is_wp_error($p));$w=RKW_Client::document_payload($p,rkw_settings());check($w['document']['items'][0]['fee']===1500.0);check($w['document']['items'][0]['price']===1250.0);check($w['payments'][0]['amount']===2500.0);
};
$tests['native discounted fee behavior is preserved by the legacy-only correction']=function(){
 $o=$GLOBALS['test_orders'][214783];$GLOBALS['options'][RKW_OPT]['document_contract']='v21';$o->total=250;$o->items=[new TestItem(250,0,2,300)];$s=rkw_settings();set_transient(RKW_Client::COOKIE_TRANSIENT,['name'=>'sg-auth-sg','value'=>'synthetic','signature'=>RKW_Policy_Catalog::signature($s)],60);$p=RKW_Orders::preview_invoice_payload($o);check($p['document']['items'][0]['fee']===1250.0);
};
$tests['missing mapped product cannot trigger discovery or product writes']=function(){
 $o=$GLOBALS['test_orders'][214783];$o->items[0]->product->meta=[];$r=RKW_Invoice_Diagnostics::inspect($o);expect_error($r,'rkw_probe_mapping');check(count($GLOBALS['http_calls'])===1);
};
$tests['missing customer cannot create or map a new customer']=function(){
 $o=$GLOBALS['test_orders'][214783];$o->meta=[];expect_error(RKW_Invoice_Diagnostics::inspect($o),'rkw_probe_customer');check(count($GLOBALS['http_calls'])===1);check($o->meta===[]);
};
$tests['pending financial state is preserved while a read-only calculation is allowed']=function(){
 $o=$GLOBALS['test_orders'][214783];$o->meta['_rkw_reconcile_required']=1;$o->meta['_rkw_attempts']=3;$o->meta['_rkw_error']='old';$before=$o->meta;check(!is_wp_error(RKW_Invoice_Diagnostics::inspect($o)));check($o->meta===$before);
};
$tests['calculation error or malformed totals never fall back to registering a document']=function(){
 foreach([new WP_Error('http_request_failed','SENSITIVE RAW FAILURE'),[],['netPrice'=>'invalid']]as$reply){$o=probe_order();$GLOBALS['probe_response']=$reply;$r=RKW_Invoice_Diagnostics::inspect($o);check(!$r['calculation']['available']);check(strpos($r['text'],'SENSITIVE')===false);check(!$o->get_meta('_rkw_doc_id'));}
};
$tests['raw server names description and transaction fields never reach report or stored log']=function(){
 $o=$GLOBALS['test_orders'][214783];$GLOBALS['probe_response']=['netPrice'=>24950000,'customerName'=>'PRIVATE PERSON','description'=>'PRIVATE ADDRESS','items'=>[['productId'=>30,'price'=>24950000,'description'=>'PRIVATE ITEM','policies'=>[['policyId'=>1,'title'=>'PRIVATE POLICY','price'=>0,'effect'=>2]]]]];$r=RKW_Invoice_Diagnostics::inspect($o);$text=json_encode($r);check(strpos($text,'PRIVATE')===false);check(strpos($text,'test-transaction')===false);check(strpos(implode('',array_column(RKW_Log::all(),'message')),'PRIVATE')===false);
};
$tests['probe requires invoice API21 and preserves a regular sales order setup']=function(){
 $o=$GLOBALS['test_orders'][214783];$GLOBALS['options'][RKW_OPT]['order_mode']='salesorder';expect_error(RKW_Invoice_Diagnostics::inspect($o),'rkw_probe_mode');check(!$GLOBALS['http_calls']);
};
$tests['AJAX calculation requires capability and nonce before any remote call']=function(){
 foreach(['test_capability','test_nonce']as$flag){probe_order();$GLOBALS[$flag]=false;$_POST=['order_id'=>214783];try{RKW_Invoice_Diagnostics::ajax();}catch(TestJSON$r){check(!$r->success);check(!$GLOBALS['http_calls']);}$GLOBALS[$flag]=true;}
};
$tests['financial error logs now include order ID quantity and correct extended totals']=function(){
 $o=$GLOBALS['test_orders'][214783];$o->total=200;$o->items=[new TestItem(200,0,2)];$GLOBALS['http_handler']=function($u,$a){return $a['method']==='GET'?response([['Id'=>5]]):response([],false,'مبلغ دریافتی فاکتور با سرجمع یکسان نیست');};expect_error(RKW_Orders::send($o),'rkw_api');$logs=implode('\n',array_column(RKW_Log::all(),'message'));check(strpos($logs,'"order_id":214783')!==false);check(strpos($logs,'"sent_items_total":2000')!==false);check(strpos($logs,'"quantity":2')!==false);
};
$tests['actual legacy send retains gross fee discounted price and receipt amount']=function(){
 $o=$GLOBALS['test_orders'][214783];$o->total=250;$o->items=[new TestItem(250,0,2,300)];$GLOBALS['http_handler']=function($u,$a){if($a['method']==='GET')return response([['Id'=>5]]);check(strpos($u,'/ESales.svc/invoice')!==false);$w=json_decode($a['body'],true);check($w['document']['items'][0]['fee']===1500);check($w['document']['items'][0]['price']===1250);check($w['payments'][0]['amount']===2500);return response(['id'=>888]);};check(RKW_Orders::send($o)===true);check($o->get_meta('_rkw_doc_id')==='888');
};
$fail=0;foreach($tests as$name=>$test){probe_order();$GLOBALS['test_capability']=true;$GLOBALS['test_nonce']=true;try{$test();echo 'PASS '.$name."\n";}catch(Throwable$e){$fail++;echo 'FAIL '.$name.': '.$e->getMessage().' at '.$e->getLine()."\n";}}
echo count($tests).' tests, '.$fail." failed\n";exit($fail?1:0);
