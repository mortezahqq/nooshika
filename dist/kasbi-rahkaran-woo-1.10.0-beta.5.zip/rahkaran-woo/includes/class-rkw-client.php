<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * کلاینت وب‌سرویس‌های راهکاران.
 * v21 = سرویس‌های Retail/Api/...  |  v19 = Services/Retail/ESales.svc
 * همه‌ی پاسخ‌ها: { result, metadata:{ isSuccessfull, errorMessage } }
 */
class RKW_Client {
	const COOKIE_TRANSIENT = 'rkw_session_cookies';
	private $s;
	private $login_status = array();
	public function login_status() { return $this->login_status; }

	public function __construct() { $this->s = rkw_settings(); }

	public function uses_legacy_documents() { return ! $this->is_v21() || 'legacy_esales' === ( isset( $this->s['document_contract'] ) ? $this->s['document_contract'] : 'legacy_esales' ); }

	public function is_v21() { return 'v21' === $this->s['api']; }

	/* ---------- آدرس و درخواست ---------- */

	private function base() {
		$s = $this->s;
		$u = $s['protocol'] . '://' . trim( $s['ip'] );
		if ( $s['port'] ) { $u .= ':' . (int) $s['port']; }
		if ( $s['cluster'] ) { $u .= '/' . trim( $s['cluster'], '/' ); }
		return $u . '/';
	}

	private function url( $path ) { return $this->base() . ltrim( $path, '/' ); }

	private function cookie_name() { return 'sg-auth-' . ( $this->s['cluster'] ? $this->s['cluster'] : 'sg' ); }

	private function cookies() {
		$c = get_transient( self::COOKIE_TRANSIENT );
		if ( is_array( $c ) && ! empty( $c['value'] ) && isset( $c['signature'] ) && hash_equals( RKW_Policy_Catalog::signature( $this->s ), $c['signature'] ) ) {
			return array( new WP_Http_Cookie( array( 'name' => $c['name'], 'value' => $c['value'] ) ) );
		}
		return array();
	}

	private function args( $method, $body = null, $with_cookies = true ) {
		$a = array(
			'method'    => $method,
			'timeout'   => (int) $this->s['timeout'],
			'sslverify' => (bool) $this->s['verify_ssl'],
			'headers'   => array( 'Content-Type' => 'application/json; charset=utf-8', 'Accept' => 'application/json' ),
		);
		if ( $with_cookies ) { $a['cookies'] = $this->cookies(); }
		if ( null !== $body ) { $a['body'] = is_string( $body ) ? $body : wp_json_encode( $body, JSON_UNESCAPED_UNICODE ); }
		return $a;
	}

	/** پنهان‌کردن کلیدهای حساس بدون تغییر درخواست ارسالی به راهکاران. */
	private static function redact_log_data( $data ) {
		if ( is_array( $data ) ) {
			foreach ( $data as $key => $value ) {
				if ( preg_match( '/password|token|secret|authorization|cookie|sessionid|nationalcode|mobile|phone|email|cardnumber|iban/iu', (string) $key ) ) {
					$data[ $key ] = '[پنهان‌شده]';
				} else {
					$data[ $key ] = self::redact_log_data( $value );
				}
			}
			return $data;
		}
		if ( is_string( $data ) ) {
			return preg_replace( '/((?:password|token|authorization|cookie|sessionid|nationalcode|mobile|phone|email|cardnumber|iban)\s*[=:]\s*)[^&\s,}]+/iu', '$1[پنهان‌شده]', $data );
		}
		return $data;
	}

	private static function log_safe( $data ) {
		if ( is_string( $data ) ) {
			$json = json_decode( $data, true );
			if ( JSON_ERROR_NONE === json_last_error() && is_array( $json ) ) { $data = $json; }
		}
		$clean = self::redact_log_data( $data );
		return is_array( $clean ) ? wp_json_encode( $clean, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ) : (string) $clean;
	}

	private function debug( $title, $url, $body, $res ) {
		if ( empty( $this->s['debug'] ) ) { return; }
		$code = is_wp_error( $res ) ? 'NETWORK ERROR' : 'HTTP ' . wp_remote_retrieve_response_code( $res );
		// Queries, payloads and replies can contain customer, session, bank or report data.
		$operation = basename( (string) parse_url( $url, PHP_URL_PATH ) );
		RKW_Log::add( 'debug', 'عملیات: ' . sanitize_text_field( $operation ) . ' | وضعیت: ' . $code . ' | اطلاعات درخواست/پاسخ ذخیره نشد.' );
	}

	/* ---------- ورود ---------- */

	private static function rsa_pem( $m_hex, $e_hex ) {
		$len = function ( $n ) {
			if ( $n < 128 ) { return chr( $n ); }
			$b = ltrim( pack( 'N', $n ), "\0" );
			return chr( 0x80 | strlen( $b ) ) . $b;
		};
		$int = function ( $hex ) use ( $len ) {
			$hex = preg_replace( '/[^0-9a-fA-F]/', '', $hex );
			if ( strlen( $hex ) % 2 ) { $hex = '0' . $hex; }
			$b = ltrim( hex2bin( $hex ), "\0" );
			if ( '' === $b ) { $b = "\0"; }
			if ( ord( $b[0] ) & 0x80 ) { $b = "\0" . $b; }
			return "\x02" . $len( strlen( $b ) ) . $b;
		};
		$seq   = function ( $x ) use ( $len ) { return "\x30" . $len( strlen( $x ) ) . $x; };
		$rsa   = $seq( $int( $m_hex ) . $int( $e_hex ) );
		$bits  = "\x03" . $len( strlen( $rsa ) + 1 ) . "\0" . $rsa;
		$algid = hex2bin( '300d06092a864886f70d0101010500' );
		$der   = $seq( $algid . $bits );
		return "-----BEGIN PUBLIC KEY-----\n" . chunk_split( base64_encode( $der ), 64, "\n" ) . "-----END PUBLIC KEY-----\n";
	}

	/** Only types and known boolean acknowledgments; never retain response values or arbitrary keys. */
	public static function cashier_response_summary( $http_status, $raw ) {
		$value = json_decode( (string) $raw, true );
		$valid = JSON_ERROR_NONE === json_last_error();
		$result_present = is_array( $value ) && array_key_exists( 'result', $value );
		$metadata = is_array( $value ) && isset( $value['metadata'] ) && is_array( $value['metadata'] ) ? $value['metadata'] : array();
		$success = array_key_exists( 'isSuccessfull', $metadata ) ? $metadata['isSuccessfull'] : null;
		return array(
			'http_status' => (int) $http_status,
			'body_bytes' => strlen( (string) $raw ),
			'body_empty' => '' === trim( (string) $raw ),
			'valid_json' => $valid,
			'json_type' => $valid ? gettype( $value ) : 'invalid',
			'top_level_field_count' => is_array( $value ) ? count( $value ) : 0,
			'top_level_boolean' => is_bool( $value ) ? $value : null,
			'known_top_level_fields' => is_array( $value ) ? array_values( array_intersect( array( 'result', 'Result', 'metadata', 'Metadata', 'd', 'success', 'Success', 'isSuccessfull', 'IsSuccessfull', 'cashRegister', 'CashRegister' ), array_keys( $value ) ) ) : array(),
			'has_result' => $result_present,
			'result_type' => $result_present ? gettype( $value['result'] ) : 'missing',
			'result_boolean' => $result_present && is_bool( $value['result'] ) ? $value['result'] : null,
			'has_metadata' => is_array( $value ) && array_key_exists( 'metadata', $value ),
			'metadata_success' => is_bool( $success ) ? $success : ( null === $success ? 'missing' : 'non_boolean' ),
			'has_register_details' => is_array( $value ) && isset( $value['result']['cashRegister'] ),
		);
	}

	/** ورود به راهکاران (Session ← RSA ← login ← کوکی sg-auth) و در صورت تنظیم، ورود به صندوق */
	public function login() {
		delete_transient( self::COOKIE_TRANSIENT );
		delete_transient( 'rkw_cash_register' );
		$s = $this->s;
		$this->login_status = array( 'machine_name' => trim( (string) $s['machine_name'] ), 'authenticated' => false, 'cashier_requested' => false, 'cashier_accepted' => false, 'legacy' => $this->uses_legacy_documents() );
		if ( '' === trim( (string) $s['ip'] ) || '' === $s['username'] || '' === $s['password'] ) {
			return new WP_Error( 'rkw_cfg', 'آی‌پی سرور، نام کاربری و رمز عبور را وارد کنید.' );
		}
		if ( ! function_exists( 'openssl_public_encrypt' ) ) {
			return new WP_Error( 'rkw_openssl', 'اکستنشن openssl در PHP فعال نیست.' );
		}
		$common = array( 'timeout' => (int) $s['timeout'], 'sslverify' => (bool) $s['verify_ssl'] );

		$u1 = $this->url( 'Services/Framework/AuthenticationService.svc/Session' );
		$r  = wp_remote_get( $u1, $common + array( 'headers' => array( 'Accept' => 'application/json' ) ) );
		$this->debug( 'SESSION', $u1, '', $r );
		if ( is_wp_error( $r ) ) { return $r; }
		$sess = json_decode( wp_remote_retrieve_body( $r ), true );
		if ( ! is_array( $sess ) || empty( $sess['id'] ) || empty( $sess['rsa']['M'] ) || empty( $sess['rsa']['E'] ) ) {
			return new WP_Error( 'rkw_session', 'دریافت Session ناموفق بود (HTTP ' . wp_remote_retrieve_response_code( $r ) . '). آدرس، پورت و کلاستر را بررسی کنید.' );
		}

		$enc = '';
		$ok  = @openssl_public_encrypt( $sess['id'] . '**' . $s['password'], $enc, self::rsa_pem( $sess['rsa']['M'], $sess['rsa']['E'] ), OPENSSL_PKCS1_PADDING );
		if ( ! $ok ) { return new WP_Error( 'rkw_rsa', 'رمزنگاری رمز عبور ناموفق بود.' ); }

		$u2   = $this->url( 'Services/Framework/AuthenticationService.svc/login' );
		$body = wp_json_encode( array( 'sessionId' => $sess['id'], 'username' => $s['username'], 'password' => strtoupper( bin2hex( $enc ) ) ) );
		$res  = wp_remote_post( $u2, $common + array( 'headers' => array( 'Content-Type' => 'application/json' ), 'body' => $body ) );
		if ( is_wp_error( $res ) ) { return $res; }
		$code = (int) wp_remote_retrieve_response_code( $res );
		if ( 401 === $code ) { return new WP_Error( 'rkw_auth', 'نام کاربری یا رمز عبور اشتباه است.' ); }
		if ( $code < 200 || $code >= 300 ) { return new WP_Error( 'rkw_login', 'ورود ناموفق (HTTP ' . $code . ').' ); }

		$cookie = wp_remote_retrieve_cookie( $res, $this->cookie_name() );
		if ( empty( $cookie ) || empty( $cookie->value ) ) {
			$cookie = null;
			foreach ( (array) wp_remote_retrieve_cookies( $res ) as $c ) {
				if ( isset( $c->name ) && false !== strpos( $c->name, '-auth' ) ) { $cookie = $c; break; }
			}
		}
		if ( empty( $cookie ) || empty( $cookie->value ) ) {
			return new WP_Error( 'rkw_cookie', 'ورود انجام نشد؛ کوکی نشست دریافت نشد.' );
		}
		set_transient( self::COOKIE_TRANSIENT, array( 'name' => $cookie->name, 'value' => $cookie->value, 'signature' => RKW_Policy_Catalog::signature( $s ) ), 25 * MINUTE_IN_SECONDS );

		$this->login_status['authenticated'] = true;
		if ( '' !== trim( (string) $s['machine_name'] ) ) {
			$this->login_status['cashier_requested'] = true;
			$path = ! $this->uses_legacy_documents()
				? 'Retail/Api/CashRegisterManagement/RetailDesktopAuthenticationService.svc/DesktopCashierLogin'
				: 'Retail/CashRegisterManagement/Services/RetailAuthenticationServices.svc/CashierLogin';
			$u3 = $this->url( $path );
			// API v21 expects a JSON string (e.g. "POS-01"), not {"machineName":"POS-01"}.
			// The legacy v19 CashierLogin endpoint expects the object form; preserve it.
			$b3 = ! $this->uses_legacy_documents()
				? trim( (string) $s['machine_name'] )
				: array( 'machineName' => trim( (string) $s['machine_name'] ) );
			$payload = wp_json_encode( $b3, JSON_UNESCAPED_UNICODE );
			$r3 = wp_remote_post( $u3, $this->args( 'POST', $payload ) );
			$this->debug( 'CASHIER', $u3, $b3, $r3 );
			if ( is_wp_error( $r3 ) ) { delete_transient( self::COOKIE_TRANSIENT ); return $r3; }
			if ( 200 !== (int) wp_remote_retrieve_response_code( $r3 ) ) {
				$j = json_decode( wp_remote_retrieve_body( $r3 ), true );
				$m = '';
				foreach ( array( array( 'metadata', 'errorMessage' ), array( 'errorMessage' ), array( 'message' ), array( 'Message' ), array( 'error', 'message' ) ) as $keys ) {
					$value = $j;
					foreach ( $keys as $key ) { $value = is_array( $value ) && isset( $value[ $key ] ) ? $value[ $key ] : null; }
					if ( is_string( $value ) && '' !== trim( $value ) ) {
						$clean = sanitize_text_field( $value );
						$m = function_exists( 'mb_substr' ) ? mb_substr( $clean, 0, 400 ) : substr( $clean, 0, 400 );
						break;
					}
				}
				$hint = 400 === (int) wp_remote_retrieve_response_code( $r3 )
					? ' نام ماشین را با نام صندوق تعریف‌شده در راهکاران تطبیق دهید؛ همچنین نقش صندوقدار و مجوز ورود به صندوق را بررسی کنید.'
					: '';
				delete_transient( self::COOKIE_TRANSIENT );
				return new WP_Error( 'rkw_cashier', 'ورود به صندوق ناموفق (HTTP ' . wp_remote_retrieve_response_code( $r3 ) . '). ' . $m . $hint );
			}
			$j3 = json_decode( wp_remote_retrieve_body( $r3 ), true );
			if ( isset( $j3['metadata']['isSuccessfull'] ) && false === $j3['metadata']['isSuccessfull'] ) {
				delete_transient( self::COOKIE_TRANSIENT );
				return new WP_Error( 'rkw_cashier', 'ورود به صندوق ناموفق: ' . ( isset( $j3['metadata']['errorMessage'] ) ? $j3['metadata']['errorMessage'] : '' ) );
			}
			if ( ! $this->uses_legacy_documents() && ( ! is_array( $j3 ) || empty( $j3['result']['cashRegister']['cashRegisterId'] ) ) ) {
				delete_transient( self::COOKIE_TRANSIENT );
				return new WP_Error( 'rkw_cashier_unconfirmed', 'ورود به صندوق شناسه cashRegisterId معتبر برنگرداند؛ نشست برای ارسال سند قابل استفاده نیست.' );
			}
			if ( $this->uses_legacy_documents() ) {
				$legacy_empty_ack = JSON_ERROR_NONE === json_last_error() && is_array( $j3 ) && array() === $j3;
				$this->login_status['legacy_empty_ack'] = $legacy_empty_ack;
				$accepted = $legacy_empty_ack || true === $j3 || ( is_array( $j3 ) && ( ( isset( $j3['result'] ) && ( true === $j3['result'] || is_array( $j3['result'] ) ) ) || ( isset( $j3['metadata']['isSuccessfull'] ) && true === $j3['metadata']['isSuccessfull'] ) ) );
				if ( ! $accepted || ( is_array( $j3 ) && array_key_exists( 'result', $j3 ) && false === $j3['result'] ) ) { delete_transient( self::COOKIE_TRANSIENT ); return new WP_Error( 'rkw_cashier_unconfirmed', 'قالب پاسخ سرویس قدیمی برای تأیید ورود صندوق شناخته نشد؛ این به‌تنهایی رد ورود را ثابت نمی‌کند. تشخیص امن پاسخ: ' . wp_json_encode( self::cashier_response_summary( wp_remote_retrieve_response_code( $r3 ), wp_remote_retrieve_body( $r3 ) ), JSON_UNESCAPED_UNICODE ) ); }
			}
			$this->login_status['cashier_accepted'] = true;
			$extra = wp_remote_retrieve_cookie( $r3, $this->cookie_name() );
			if ( ! empty( $extra ) && ! empty( $extra->value ) ) {
				set_transient( self::COOKIE_TRANSIENT, array( 'name' => $extra->name, 'value' => $extra->value, 'signature' => RKW_Policy_Catalog::signature( $s ) ), 25 * MINUTE_IN_SECONDS );
			}
			if ( isset( $j3['result']['cashRegister'] ) ) { set_transient( 'rkw_cash_register', $j3['result']['cashRegister'], HOUR_IN_SECONDS ); }
		}
		return true;
	}

	/**
	 * Non-personal metadata for malformed upstream responses. Never store the
	 * response body, headers with credentials, or a sample of arbitrary HTML.
	 * Distinguishes a WCF/HTML 400 from a genuine JSON business error.
	 */
	private static function invalid_response_details( $res, $raw, $status ) {
		$content_type = (string) wp_remote_retrieve_header( $res, 'content-type' );
		$content_type = strtolower( trim( explode( ';', $content_type )[0] ) );
		if ( ! preg_match( '~^[a-z0-9.+_-]+/[a-z0-9.+_-]+$~', $content_type ) ) { $content_type = 'unknown'; }
		$trim = ltrim( (string) $raw );
		$kind = '' === $trim ? 'empty' : ( preg_match( '~^<(?:!doctype|html|head|body|\?xml|s:envelope|soap:envelope)~i', $trim ) ? 'html_or_xml' : ( false !== strpos( $content_type, 'json' ) ? 'invalid_json' : 'text_or_other' ) );
		$hint = 'unknown';
		if ( preg_match( '/serializationexception|deserialize|deserializ|unexpected character|invalid enum|enum value|cannot convert|could not convert/i', (string) $raw ) ) {
			$hint = 'possible_serialization_or_enum_error';
		} elseif ( preg_match( '/request entity too large|request length|request size|maximum request length|413 /i', (string) $raw ) ) {
			$hint = 'request_size_rejected';
		} elseif ( preg_match( '/login|sign in|authentication required/i', (string) $raw ) && 'html_or_xml' === $kind ) {
			$hint = 'possible_login_page';
		} elseif ( preg_match( '/request validation|request filtering|modsecurity|access denied/i', (string) $raw ) ) {
			$hint = 'possible_security_filter';
		}
		return array(
			'http_status' => (int) $status,
			'response_content_type' => $content_type,
			'response_kind' => $kind,
			'response_length' => strlen( (string) $raw ),
			'response_fingerprint' => substr( hash( 'sha256', (string) $raw ), 0, 16 ),
			'response_hint' => $hint,
		);
	}

	/** فراخوانی یک سرویس؛ خروجی: مقدار result یا WP_Error. با 401 یک‌بار لاگین مجدد. */
	public function call( $method, $path, $query = array(), $body = null, $retry = true ) {
		if ( ! $this->cookies() ) {
			$l = $this->login();
			if ( is_wp_error( $l ) ) { return $l; }
		}
		$url = $this->url( $path );
		if ( $query ) { $url = add_query_arg( $query, $url ); }
		$res = wp_remote_request( $url, $this->args( $method, $body ) );
		$this->debug( $method, $url, $body === null ? '' : $body, $res );
		if ( is_wp_error( $res ) ) { return $res; }
		$code = (int) wp_remote_retrieve_response_code( $res );
		if ( 401 === $code && $retry ) {
			delete_transient( self::COOKIE_TRANSIENT );
			return $this->call( $method, $path, $query, $body, false );
		}
		$raw  = wp_remote_retrieve_body( $res );
		$json = json_decode( $raw, true );
		if ( ! is_array( $json ) ) {
			$json = json_decode( trim( preg_replace( '/[\x{200B}-\x{200D}\x{FEFF}]/u', '', str_replace( array( "\r", "\n" ), '', $raw ) ) ), true );
		}
		if ( ! is_array( $json ) ) {
			// Even non-JSON responses must retain their HTTP failure classification.
			$diag = self::invalid_response_details( $res, $raw, $code );
			if ( $code < 200 || $code >= 300 ) {
				return new WP_Error( 'rkw_http_status', 'خطای سرویس راهکاران (HTTP ' . $code . ') در ' . basename( $path ) . '؛ پاسخ JSON معتبر نبود. نوع پاسخ: ' . $diag['response_kind'] . '؛ جزئیات امن در گزارش فنی ذخیره شد.', $diag );
			}
			return new WP_Error( 'rkw_http', 'پاسخ نامعتبر (HTTP ' . $code . ') از ' . basename( $path ), $diag );
		}
		$meta = isset( $json['metadata'] ) && is_array( $json['metadata'] ) ? $json['metadata'] : array();
		// HTTP failures must never masquerade as a successful empty API result.
		// Keep the upstream error string short and do not expose raw responses / credentials.
		if ( $code < 200 || $code >= 300 ) {
			$message = '';
			foreach ( array( 'errorMessage', 'message', 'Message' ) as $key ) {
				if ( isset( $meta[ $key ] ) && is_scalar( $meta[ $key ] ) ) { $message = (string) $meta[ $key ]; break; }
				if ( isset( $json[ $key ] ) && is_scalar( $json[ $key ] ) ) { $message = (string) $json[ $key ]; break; }
			}
			$message = sanitize_text_field( $message );
			$message = function_exists( 'mb_substr' ) ? mb_substr( $message, 0, 250 ) : substr( $message, 0, 250 );
			return new WP_Error( 'rkw_http_status', 'خطای سرویس راهکاران (HTTP ' . $code . ') در ' . basename( $path ) . ( $message ? ': ' . $message : '' ), array( 'http_status' => $code ) );
		}
		if ( isset( $meta['isSuccessfull'] ) && false === $meta['isSuccessfull'] ) {
			return new WP_Error( 'rkw_api', ! empty( $meta['errorMessage'] ) ? sanitize_text_field( $meta['errorMessage'] ) : 'خطای ناشناخته از راهکاران', array( 'http_status' => $code, 'service' => basename( $path ) ) );
		}
		if ( false !== strpos( $path, 'ReportExecutionService.svc/ExportReportToJson' ) && ! array_key_exists( 'result', $json ) ) { return $json; }
		return array_key_exists( 'result', $json ) ? $json['result'] : array();
	}

	private function v19( $endpoint ) { return 'Services/Retail/ESales.svc/' . ltrim( $endpoint, '/' ); }

	/* ---------- v21 ---------- */

	public function products21( $page, $count, $input = '' ) {
		return $this->call( 'GET', 'Retail/Api/Structure/ProductService.svc/GetProducts', array( 'input' => $input, 'page' => (int) $page, 'count' => (int) $count ) );
	}

	/** دریافت مستقیم یک کالا (بدون پیمایش فهرست) بر اساس شناسه داخلی راهکاران. */
	public function product_by_id( $product_id ) {
		$product_id = absint( $product_id );
		if ( ! $product_id ) { return new WP_Error( 'rkw_product_id', 'شناسه محصول راهکاران نامعتبر است.' ); }
		if ( $this->is_v21() ) {
			return $this->call( 'GET', 'Retail/Api/Structure/ProductService.svc/GetProduct', array( 'id' => $product_id ) );
		}
		return $this->call( 'GET', $this->v19( 'product' ), array( 'id' => $product_id ) );
	}

	/** موجودی هر کالا به تفکیک انبار */
	public function remaining21( $product_id ) {
		return $this->call( 'GET', 'Retail/Api/DocumentStructure/StoreService.svc/GetRemainingQuantityInfo', array( 'productId' => (int) $product_id ) );
	}

	/** searchMode: 1 عنوان، 2 موبایل، 3 کد ملی */
	public function find_customer21( $input, $mode ) {
		return $this->call( 'GET', 'Retail/Api/Structure/CustomerService.svc/customer', array( 'input' => $input, 'searchMode' => (int) $mode, 'page' => 1, 'count' => 10 ) );
	}

	public function save_customer21( array $payload ) {
		return $this->call( 'POST', 'Retail/Api/Structure/CustomerService.svc/customer', array(), $payload );
	}

	/** Serialize the canonical ledger using exactly one selected wire contract. */
	public static function document_payload( array $payload, array $settings ) {
		if ( isset( $settings['document_contract'] ) && 'v21' === $settings['document_contract'] ) { return $payload; }
		$source = $payload['document']; $document = array();
		foreach ( array( 'customerId', 'description', 'currencyId', 'storeId', 'settlementPolicyId', 'documentPatternId' ) as $field ) { if ( isset( $source[ $field ] ) ) { $document[ $field ] = $source[ $field ]; } }
		$document['items'] = array();
		foreach ( $source['items'] as $item ) {
			$row = array();
			foreach ( array( 'productId', 'quantity', 'fee', 'unitId', 'storeId' ) as $field ) { $row[ $field ] = $item[ $field ]; }
			// ESales expects unit price; v21 price is the whole line, not unit price.
			$row['price'] = round( $item['price'] / $item['quantity'], 6 );
			if ( ! empty( $item['policies'] ) ) { $row['policies'] = self::legacy_policies( $item['policies'] ); unset( $row['price'] ); }
			for ( $i = 1; $i <= 5; $i++ ) { foreach ( array( 'trackingFactor', 'partTrackingFactorRef' ) as $prefix ) { if ( isset( $item[ $prefix . $i ] ) ) { $row[ $prefix . $i ] = $item[ $prefix . $i ]; } } }
			$document['items'][] = $row;
		}
		if ( ! empty( $source['policies'] ) ) { $document['policies'] = self::legacy_policies( $source['policies'] ); }
		if ( ! empty( $source['data']['loyaltyProgramID'] ) ) { $document['loyaltyProgramId'] = (int) $source['data']['loyaltyProgramID']; }
		$payments = isset( $payload['receipts'] ) ? $payload['receipts'] : array();
		if ( ! $payments && ! empty( $settings['credit_receipt_key'] ) ) {
			$amount = 0.0;
			foreach ( $source['items'] as $item ) {
				$amount += (float) $item['price'];
				foreach ( isset( $item['policies'] ) ? $item['policies'] : array() as $p ) { $amount += ( isset( $p['effect'] ) && ( 1 === $p['effect'] || 'Decrease' === $p['effect'] ) ? -1 : 1 ) * (float) $p['price']; }
			}
			foreach ( isset( $source['policies'] ) ? $source['policies'] : array() as $p ) { $amount += ( isset( $p['effect'] ) && ( 1 === $p['effect'] || 'Decrease' === $p['effect'] ) ? -1 : 1 ) * (float) $p['price']; }
			$payments[] = array( 'key' => $settings['credit_receipt_key'], 'amount' => round( $amount, 2 ) );
		}
		foreach ( $payments as &$payment ) {
			if ( isset( $payment['attr']['eReceiptType'] ) ) { unset( $payment['attr']['eReceiptType'] ); }
			if ( in_array( $payment['key'], array( 'EReceipt', 'BankReceipt' ), true ) ) { unset( $payment['attr']['DESCRIPTION'] ); }
		} unset( $payment );
		return array( 'document' => $document, 'payments' => $payments );
	}
	private static function legacy_policies( $policies ) {
		foreach ( $policies as &$policy ) { if ( isset( $policy['effect'] ) && 1 === $policy['effect'] ) { $policy['effect'] = 'Decrease'; } elseif ( isset( $policy['effect'] ) && 2 === $policy['effect'] ) { $policy['effect'] = 'Increase'; } } unset( $policy );
		return $policies;
	}

	public function save_sales_order21( array $payload ) {
		return $this->call( 'POST', $this->uses_legacy_documents() ? $this->v19( 'salesOrder' ) : 'Retail/Api/RetailDocuments/SalesOrderService.svc/saveSalesOrder', array(), self::document_payload( $payload, $this->s ) );
	}

	public function calculate_invoice21( array $document ) {
		return $this->call( 'POST', 'Retail/Api/RetailDocuments/InvoiceService.svc/calculateAmount', array(), $document );
	}

	/** Documented reporting API; path is relative to the configured server only. */
	public function export_report( $path, array $parameters = array() ) {
		if ( ! is_string( $path ) || ! preg_match( '#^[A-Za-z0-9_\-/ .\x{0600}-\x{06FF}]+$#u', $path ) || false !== strpos( $path, '..' ) ) { return new WP_Error( 'rkw_report_path', 'مسیر نسبی گزارش نامعتبر است.' ); }
		foreach ( $parameters as $key => $value ) {
			if ( 'reportPath' === $key || ! is_scalar( $value ) || ! preg_match( '/^[A-Za-z_][A-Za-z0-9_]*$/', $key ) ) { return new WP_Error( 'rkw_report_parameter', 'نام یا مقدار پارامتر گزارش نامعتبر است؛ انتخاب چندگانه پشتیبانی نمی‌شود.' ); }
		}
		return $this->call( 'POST', 'System/ReportingServices/Services/ReportExecutionService.svc/ExportReportToJson', array(), array( 'reportPath' => $path ) + $parameters );
	}

	public function save_invoice21( array $payload ) {
		return $this->call( 'POST', $this->uses_legacy_documents() ? $this->v19( 'invoice' ) : 'Retail/Api/RetailDocuments/InvoiceService.svc/SaveInvoice', array(), self::document_payload( $payload, $this->s ) );
	}

	public function sales_areas21() { return $this->call( 'GET', 'Retail/Api/DocumentStructure/SalesAreaService.svc/getSalesAreas' ); }

	/** Read-only list of POS devices for the currently authenticated retail shop. */
	public function poses_info21() {
		if ( ! $this->is_v21() ) { return new WP_Error( 'rkw_pos_api', 'این بررسی فقط برای API نسخه ۲۱ در دسترس است.' ); }
		return $this->call( 'GET', 'Retail/Api/DocumentStructure/DeviceInfoService.svc/getPosesInfo' );
	}

	public function coupon_types21() { return $this->call( 'GET', 'Retail/Api/Promotions/RetailPromotionService.svc/thirdPartyCouponTypes' ); }

	public function settlement_policies21( $type ) {
		return $this->call( 'GET', 'Retail/Api/DocumentStructure/SettlementPolicyService.svc/getSettlementPolicies', array( 'applicabilityType' => (int) $type ) );
	}

	public function default_pattern21( $type ) {
		return $this->call( 'GET', 'Retail/Api/DocumentStructure/DocumentPatternService.svc/getDefaultMobileDocumentPatternByType', array( 'retailDocumentType' => (int) $type ) );
	}

	/** v21: list stores; filter only deliverable stores per documented endpoint. */
	public function stores21() {
		return $this->call( 'GET', 'Retail/Api/DocumentStructure/StoreService.svc/getStores', array( 'immediateDelivery' => 'true', 'reservedDelivery' => 'true' ) );
	}

	/** Search with pagination; 1=title, 2=mobile, 3=national ID. */
	public function search_customers21( $input, $mode, $page, $count ) {
		return $this->call( 'GET', 'Retail/Api/Structure/CustomerService.svc/customer', array( 'input' => $input, 'searchMode' => (int) $mode, 'page' => (int) $page, 'count' => (int) $count ) );
	}

	/** v21: paginated customer listing. */
	public function customers21( $page, $count ) {
		return $this->call( 'GET', 'Retail/Api/Structure/CustomerService.svc/customers', array( 'page' => (int) $page, 'count' => (int) $count ) );
	}

	/** v21: list invoices, optionally filtered by customer and store. */
	public function invoices21( $page, $count, $customer_name = '', $customer_mobile = '', $shop_id = 0 ) {
		$query = array( 'page' => (int) $page, 'count' => (int) $count );
		if ( '' !== $customer_name ) { $query['customerName'] = $customer_name; }
		if ( '' !== $customer_mobile ) { $query['customerMobile'] = $customer_mobile; }
		if ( $shop_id ) { $query['retailInteriorShopId'] = (int) $shop_id; }
		return $this->call( 'GET', 'Retail/Api/RetailDocuments/InvoiceService.svc/GetInvoicesList', $query );
	}

	/** مستند نسخه ۲۱: عضو وفاداری به تفکیک شناسه مشتری. */
	public function loyalty_member_by_customer21( $customer_id ) {
		return $this->call( 'GET', 'Retail/LoyaltyApi/RetailLoyaltyMemberService.svc/loyaltyMemberByMappedId', array( 'mappedId' => (int) $customer_id, 'type' => 1 ) );
	}

	public function loyalty_member_by_id21( $member_id ) {
		return $this->call( 'GET', 'Retail/LoyaltyApi/RetailLoyaltyMemberService.svc/loyaltyMemberById', array( 'memberId' => (int) $member_id ) );
	}

	public function create_loyalty_member21( $customer_id, $pattern_id ) {
		return $this->call( 'POST', 'Retail/LoyaltyApi/RetailLoyaltyMemberService.svc/loyaltyMember', array(), array(
			'customerId' => (int) $customer_id,
			'loyaltyMemberPatternId' => (int) $pattern_id,
		) );
	}

	public function loyalty_programs21( $page = 1, $count = 50 ) {
		return $this->call( 'GET', 'Retail/LoyaltyApi/RetailLoyaltyProgramService.svc/loyaltyProgram', array( 'page' => (int) $page, 'count' => (int) $count ) );
	}

	public function loyalty_remaining_credit21( $program_id, $member_id ) {
		return $this->call( 'GET', 'Retail/LoyaltyApi/RetailLoyaltyPointCreditService.svc/loyaltyRemainingCredit', array( 'programId' => (int) $program_id, 'memberId' => (int) $member_id, 'loyaltyDiscountAmount' => 0 ) );
	}

	public function invoice21( $invoice_id ) {
		return $this->call( 'GET', 'Retail/Api/RetailDocuments/InvoiceService.svc/GetInvoice', array( 'invoiceId' => (int) $invoice_id ) );
	}

	/* ---------- v19 ---------- */

	public function shops19() { return $this->call( 'GET', $this->v19( 'shops' ), array( 'withStores' => 'true' ) ); }

	public function products19( $from, $count ) {
		$stores = array_filter( array_map( 'intval', explode( ',', (string) $this->s['store_ids'] ) ) );
		return $this->call( 'GET', $this->v19( 'Products' ), array(
			'shopId'          => (int) $this->s['shop_id'],
			'storeId'         => $stores ? (int) reset( $stores ) : 1,
			'from'            => (int) $from,
			'numberOfRecords' => (int) $count,
		) );
	}

	/** $items = [productId => unitId] */
	public function prices19( array $items ) {
		$rows = array();
		$i    = 1;
		foreach ( $items as $pid => $unit ) {
			$rows[] = array( 'itemId' => $i++, 'productId' => (int) $pid, 'trackingFactors' => array(), 'unitId' => (int) $unit, 'quantity' => 1 );
		}
		return $this->call( 'POST', $this->v19( 'Price' ), array(), array(
			'customerId'   => (int) $this->s['customer_id'],
			'currencyId'   => (int) $this->s['currency_id'],
			'retailShopId' => (int) $this->s['shop_id'],
			'date'         => gmdate( 'Y/m/d' ),
			'salesAreaId'  => (int) $this->s['sales_area_id'],
			'items'        => $rows,
		) );
	}
}
