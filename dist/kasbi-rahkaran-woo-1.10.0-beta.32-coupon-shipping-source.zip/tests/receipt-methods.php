<?php
require __DIR__.'/bootstrap.php';
function selected($a,$b=true,$echo=true){$h=(string)$a===(string)$b?' selected="selected"':'';if($echo)echo$h;return$h;}
function method_rows(){return[['settlementPolicyID'=>45,'settlementPolicyName'=>'اسنپ پی (قسط)','settlementMethodGroups'=>[['settlementMethodGroupID'=>5,'settlementMethods'=>[['settlementMethodID'=>11,'settlementNatureKey'=>'EReceipt','settlementMethodName'=>'دریافت بانکی سایت'],['settlementMethodID'=>8,'settlementNatureKey'=>'ThirdPartyCoupon','settlementMethodName'=>'بن سازمانی اسنپ پی'],['settlementMethodID'=>10,'settlementNatureKey'=>'Cash','settlementMethodName'=>'نقدی']]]]]];}
function method_catalog(){ $fn=new ReflectionMethod(RKW_Policy_Catalog::class,'policies');$fn->setAccessible(true);return$fn->invoke(null,method_rows());}
function method_reset(){reset_case();$s=rkw_settings();$s['document_contract']='legacy_esales';$s['invoice_settlement_id']=45;$s['inventory_id']=2;$s['loyalty_id']=3;$s['payment_rules']=[['gateway'=>'WC_Gateway_SnappPay','settlement_id'=>45,'receipt_key'=>'ThirdPartyCoupon','coupon_type_id'=>5]];$GLOBALS['options'][RKW_OPT]=$s;set_transient(RKW_Client::COOKIE_TRANSIENT,['name'=>'sg-auth-sg','value'=>'synthetic-cookie','signature'=>RKW_Policy_Catalog::signature($s)],60);$GLOBALS['options'][RKW_Policy_Catalog::OPTION]=['signature'=>RKW_Policy_Catalog::signature($s),'schema_version'=>2,'updated_at'=>time(),'invoice'=>method_catalog(),'order'=>[]];$GLOBALS['posted']=[];$GLOBALS['events']=[];$GLOBALS['upstream_failure']=false;$GLOBALS['filters']['rkw_order_payload']=[20=>[[RKW_Extensions::class,'extend_payload']],30=>[[RKW_Loyalty::class,'extend_payload']]];
 $GLOBALS['http_handler']=function($u,$a){$GLOBALS['events'][]=[$u,$a['method']];if(strpos($u,'/thirdPartyCouponTypes')!==false){check($a['method']==='GET');return response([['Id'=>5,'title'=>'قرارداد اسنپ']]);}if(strpos($u,'/CashierLogin')!==false){check($a['method']==='POST');return['code'=>200,'body'=>'[]'];}if(strpos($u,'/ESales.svc/invoice')!==false||strpos($u,'/InvoiceService.svc/SaveInvoice')!==false){$body=json_decode($a['body'],true);$GLOBALS['posted'][]=$body;return$GLOBALS['upstream_failure']?response([],false,'Sequence contains no elements'):response(['id'=>123321]);}throw new RuntimeException('Unexpected endpoint '.$u);};
}
function method_order(){ $o=order(3695000);$o->id=238312;$o->gateway='WC_Gateway_SnappPay';$o->items[0]->product->meta['_rahkaran_product_id']=263152;return$o;}
function method_wire($contract='legacy_esales'){$GLOBALS['options'][RKW_OPT]['document_contract']=$contract;$s=rkw_settings();set_transient(RKW_Client::COOKIE_TRANSIENT,['name'=>'sg-auth-sg','value'=>'synthetic-cookie','signature'=>RKW_Policy_Catalog::signature($s)],60);$GLOBALS['options'][RKW_Policy_Catalog::OPTION]['signature']=RKW_Policy_Catalog::signature($s);return RKW_Orders::send(method_order());}
function metadata_handler($u,$a){check($a['method']==='GET'&&!isset($a['body']));if(strpos($u,'getSettlementPolicies')!==false)return response(strpos($u,'applicabilityType=1')!==false?method_rows():[['settlementPolicyID'=>72,'settlementPolicyName'=>'سفارش','settlementMethodGroups'=>[['settlementMethods'=>[['settlementNatureKey'=>'Cash','settlementMethodName'=>'نقد سفارش']]]]]]);if(strpos($u,'getDefaultMobileDocumentPatternByType')!==false)return response(['id'=>7,'title'=>'الگو']);return response([]);}
$tests=[];
$tests['live policy keys and Persian method titles are retained without attributes or invented keys']=function(){
 $rows=method_catalog();check($rows[0]['keys']===['EReceipt','ThirdPartyCoupon','Cash']);check($rows[0]['methods'][1]===['key'=>'ThirdPartyCoupon','name'=>'بن سازمانی اسنپ پی','method_id'=>8,'group_id'=>5]);check(!isset($rows[0]['methods'][1]['attributes']));check(!in_array('Wallet',$rows[0]['keys'],true));
};
$tests['server Persian titles take priority and old key-only catalogs use translations without inventing choices']=function(){
 $c=RKW_Policy_Catalog::receipt_choices(45,'invoice','ThirdPartyCoupon');check($c['ThirdPartyCoupon']==='بن سازمانی اسنپ پی (ThirdPartyCoupon)');$GLOBALS['options'][RKW_Policy_Catalog::OPTION]['invoice']=[['id'=>45,'keys'=>['ThirdPartyCoupon']]];$c=RKW_Policy_Catalog::receipt_choices(45,'invoice');check($c===['ThirdPartyCoupon'=>'بن سازمانی (ThirdPartyCoupon)']);
};
$tests['unavailable saved key remains selected and is not replaced with the first EReceipt']=function(){
 $html=RKW_Payment::receipt_picker('rkw[payment_rules][0][receipt_key]','CustomSavedKey',45,'invoice');check(strpos($html,'value="CustomSavedKey" selected="selected"')!==false);check(strpos($html,'value="EReceipt" selected')===false);check(strpos($html,'type="text"')===false);
};
$tests['the named Persian selector submits only the exact English key']=function(){
 $h=RKW_Payment::receipt_picker('rkw[payment_rules][0][receipt_key]','ThirdPartyCoupon',45,'invoice');check(strpos($h,'name="rkw[payment_rules][0][receipt_key]"')!==false);check(strpos($h,'value="ThirdPartyCoupon" selected="selected"')!==false);check(strpos($h,'بن سازمانی اسنپ پی')!==false);$rules=RKW_Payment::sanitize_rules([['gateway'=>'WC_Gateway_SnappPay','settlement_id'=>45,'receipt_key'=>'ThirdPartyCoupon','coupon_type_id'=>5]]);check($rules[0]['receipt_key']==='ThirdPartyCoupon');
};
$tests['missing policy does not borrow keys from other policies']=function(){
 check(RKW_Policy_Catalog::receipt_choices(777,'invoice')===[]);$c=RKW_Policy_Catalog::receipt_choices(777,'invoice','ThirdPartyCoupon');check(array_keys($c)===['ThirdPartyCoupon']);check(!isset($c['EReceipt']));
};
$tests['a fully configured Snapp voucher passes all local guards and reaches the legacy HTTP body unchanged']=function(){
 check(method_wire()===true);check(count($GLOBALS['posted'])===1);$p=$GLOBALS['posted'][0];check($p['payments']===[]&&count($p['receipts'])===1);$r=$p['receipts'][0];check($p['document']['settlementPolicyId']===45);check($r['key']==='ThirdPartyCoupon'&&$r['attr']['CouponType']===5&&$r['attr']['ID']===1&&$r['attr']['Count']===1&&!isset($r['attr']['couponType'])&&$r['amount']===36950000);check(!isset($r['attr']['bankAccountRef'],$r['attr']['eReceiptType']));check(count($GLOBALS['events'])===3);check($GLOBALS['events'][0][1]==='GET'&&strpos($GLOBALS['events'][1][0],'CashierLogin')!==false);
};
$tests['a voucher also reaches the new v21 receipt container without being converted to electronic receipt']=function(){
 $GLOBALS['options'][RKW_OPT]['invoice_preflight']=0;check(method_wire('v21')===true);$p=$GLOBALS['posted'][0];check($p['payments']===[]);check($p['receipts'][0]['key']==='ThirdPartyCoupon'&&$p['receipts'][0]['attr']['CouponType']===5);
};
$tests['coupon amount uses order total in both contracts']=function(){
 foreach(['legacy_esales','v21'] as $contract){method_reset();$GLOBALS['options'][RKW_OPT]['document_contract']=$contract;$GLOBALS['options'][RKW_OPT]['invoice_preflight']=0;$o=method_order();$o->total+=100;$o->shipping=100;$GLOBALS['options'][RKW_Extensions::OPTION]=array_merge(RKW_Extensions::defaults(),['shipping_enabled'=>1,'shipping_policy_id'=>211]);$s=rkw_settings();set_transient(RKW_Client::COOKIE_TRANSIENT,['name'=>'sg-auth-sg','value'=>'synthetic-cookie','signature'=>RKW_Policy_Catalog::signature($s)],60);$GLOBALS['options'][RKW_Policy_Catalog::OPTION]['signature']=RKW_Policy_Catalog::signature($s);$result=RKW_Orders::send($o);if(is_wp_error($result))throw new RuntimeException($contract.': '.$result->get_error_message());check($result===true);$p=$GLOBALS['posted'][0];check((float)$p['receipts'][0]['amount']===round($o->get_total()*rkw_price_multiplier($s),2));check($p['receipts'][0]['amount']!==36950000);file_put_contents(__DIR__.'/../docs/thirdparty-coupon-'.$contract.'-request.json',json_encode($p,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));}
};
$tests['reported order 238790 sends explicit legacy shipping Increase and unchanged coupon total']=function(){
 $o=method_order();$o->id=238790;$o->total=2045000;$o->items=[new TestItem(1895000)];$o->items[0]->product->meta['_rahkaran_product_id']=148521;$o->shipping=150000;
 $GLOBALS['options'][RKW_Extensions::OPTION]=array_merge(RKW_Extensions::defaults(),['shipping_enabled'=>1,'shipping_policy_id'=>371]);
 check(RKW_Orders::send($o)===true);$p=$GLOBALS['posted'][0];check($p['payments']===[]);check($p['receipts'][0]['amount']===20450000);check($p['receipts'][0]['attr']['CouponType']===5&&$p['receipts'][0]['attr']['Count']===1&&$p['receipts'][0]['attr']['ID']===1);
 check($p['document']['policies'][0]===['policyId'=>371,'price'=>1500000,'isIncluded'=>true,'effect'=>'Increase']);check($p['document']['items'][0]['price']===18950000);
 $d=RKW_Invoice_Diagnostics::wire_summary($p,'legacy_esales');check($d['tenders'][0]['coupon_type']===5);check($d['document_total_estimate']===20450000.0);
 file_put_contents(__DIR__.'/../docs/order-238790-synthetic-request.json',json_encode($p,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));
};
$tests['upstream Sequence remains an upstream voucher error with no automatic EReceipt fallback']=function(){
 $GLOBALS['upstream_failure']=true;expect_error(method_wire(),'rkw_api');check(count($GLOBALS['posted'])===1&&$GLOBALS['posted'][0]['receipts'][0]['key']==='ThirdPartyCoupon');check(rkw_settings()['payment_rules'][0]['receipt_key']==='ThirdPartyCoupon');
};
$tests['the electronic-only amount guard deliberately skips vouchers rather than rejecting them']=function(){
 $p=RKW_Payment::resolve(method_order(),rkw_settings());check($p['receipt_key']==='ThirdPartyCoupon');check(RKW_Orders::validate_electronic_receipt_amount(['receipts'=>[['key'=>'ThirdPartyCoupon','amount'=>36950000]]],method_order(),rkw_settings(),$p)===true);
};
$tests['an actual policy mismatch still blocks locally and is distinct from an upstream rkw_api']=function(){
 $GLOBALS['options'][RKW_Policy_Catalog::OPTION]['invoice'][0]['keys']=['EReceipt'];expect_error(method_wire(),'rkw_policy_receipt_mismatch');check(!$GLOBALS['posted']&&!$GLOBALS['http_calls']);
};
$tests['payload hooks for shipping and loyalty do not change the selected voucher key']=function(){
 add_filter('rkw_order_payload',function($p){check($p['receipts'][0]['key']==='ThirdPartyCoupon');$p['receipts'][0]['attr']['syntheticVoucherAttribute']=1;return$p;},40,3);check(method_wire()===true);check($GLOBALS['posted'][0]['receipts'][0]['key']==='ThirdPartyCoupon'&&$GLOBALS['posted'][0]['receipts'][0]['attr']['syntheticVoucherAttribute']===1);
};
$tests['invalid coupon types are still rejected before a document write']=function(){
 $GLOBALS['http_handler']=fn()=>response([['Id'=>6]]);expect_error(method_wire(),'rkw_coupon_type_not_found');check(!$GLOBALS['posted']);
};
$tests['metadata refresh reads real policy method names using six GETs without changing payment settings']=function(){
 $before=rkw_settings();$GLOBALS['http_handler']='metadata_handler';$r=RKW_Policy_Catalog::refresh();check(!is_wp_error($r)&&$r['schema_version']===2&&$r['updated_at']<=time());check($r['invoice'][0]['methods'][1]['name']==='بن سازمانی اسنپ پی');check(rkw_settings()===$before&&count($GLOBALS['http_calls'])===6&&!$GLOBALS['posted']);
};
$tests['a partial policy read failure preserves its previous cached list and saved selection']=function(){
 $before=RKW_Policy_Catalog::stored()['invoice'];$GLOBALS['http_handler']=function($u,$a){if(strpos($u,'getSettlementPolicies?applicabilityType=1')!==false)return new WP_Error('timeout','synthetic');return metadata_handler($u,$a);};$r=RKW_Policy_Catalog::refresh();check(!is_wp_error($r)&&$r['invoice']===$before&&isset($r['errors']['invoice']));check(rkw_settings()['payment_rules'][0]['receipt_key']==='ThirdPartyCoupon');
};
$tests['a connection change during metadata GETs cannot overwrite a previous connection catalog']=function(){
 $before=get_option(RKW_Policy_Catalog::OPTION);$GLOBALS['http_handler']=function($u,$a){$r=metadata_handler($u,$a);$GLOBALS['options'][RKW_OPT]['ip']='other.example.invalid';return$r;};expect_error(RKW_Policy_Catalog::refresh(),'rkw_catalog_changed');check(get_option(RKW_Policy_Catalog::OPTION)===$before);
};
$fail=0;foreach($tests as$name=>$test){method_reset();try{$test();echo'PASS '.$name."\n";}catch(Throwable$e){$fail++;echo'FAIL '.$name.': '.$e->getMessage().' at '.$e->getLine()."\n";}}echo count($tests).' tests, '.$fail." failed\n";exit($fail?1:0);
