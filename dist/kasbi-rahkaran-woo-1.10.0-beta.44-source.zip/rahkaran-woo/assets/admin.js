/* global rkwModules */
(function () {
  'use strict';
  if (typeof rkwModules === 'undefined') return;
  const $ = (id) => document.getElementById(id);
  const form = $('rkwm-filter');
  if (!form) return;
  const section = rkwModules.section;
  const state = { page: 1, size: 20, search: '', mobile: '', shop: 0, docType: 1, loading: false, hasNext: false, total: null, pages: null, countRun: 0, countFailed: false };
  const alert = $('rkwm-alert');
  const results = $('rkwm-results');
  const next = $('rkwm-next');
  const prev = $('rkwm-prev');
  const detail = $('rkwm-detail');
  const numbers = $('rkwm-numbers');
  const jump = $('rkwm-jump');
  const jumpInput = $('rkwm-jump-num');
  const countStatus = $('rkwm-page');
  const snapshotStatus = $('rkwm-snapshot-status');
  const digits = value => value.replace(/[۰-۹]/g, c => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(c))).replace(/[٠-٩]/g, c => String('٠١٢٣٤٥٦٧٨٩'.indexOf(c)));
  const searchMode = $('rkwm-search-mode');
  let codeStopped = false;
  const codeStop = node('button', 'توقف جست‌وجوی کد', 'button');
  codeStop.type = 'button'; codeStop.hidden = true;
  if (section === 'products') form.insertAdjacentElement('afterend', codeStop);
  codeStop.addEventListener('click', () => { codeStopped = true; codeStop.disabled = true; codeStop.textContent = 'توقف پس از پاسخ فعلی…'; });
  let renderedOnce = false;
  let lastRenderedPage = 1;
  let activeInvoiceId = null;
  let modalPreviousFocus = null;
  let settlementRequestId = 0;
  const settlementModal = $('rkwm-settlement-modal');

  function node(tag, text, cls) {
    const x = document.createElement(tag);
    if (text !== undefined && text !== null) x.textContent = String(text);
    if (cls) x.className = cls;
    return x;
  }
  function notice(message, type) {
    alert.textContent = message || '';
    alert.className = 'rkwm-alert' + (type ? ' rkwm-' + type : '');
  }
  function setBusy(value) {
    state.loading = value;
    form.querySelectorAll('button,input,select').forEach(el => el.disabled = value);
    next.disabled = value || !state.hasNext;
    prev.disabled = value || state.page <= 1;
    numbers.querySelectorAll('button').forEach(el => { el.disabled = value; });
    jump.querySelectorAll('button,input').forEach(el => { el.disabled = value; });
  }
  async function request(action, values) {
    const data = new URLSearchParams(Object.assign({action, nonce: rkwModules.nonce, section}, values || {}));
    const response = await fetch(rkwModules.ajax, {
      method: 'POST', credentials: 'same-origin',
      headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'},
      body: data.toString()
    });
    const json = await response.json();
    if (!response.ok || !json.success) {
      const message = json && json.data && json.data.message ? json.data.message : rkwModules.error;
      throw new Error(message);
    }
    return json.data;
  }
  function collect() {
    state.size = Number($('rkwm-size').value) || 20;
    state.search = $('rkwm-search') ? $('rkwm-search').value.trim() : '';
    if (section === 'products') state.search = digits(state.search);
    state.mobile = $('rkwm-mobile') ? $('rkwm-mobile').value.trim() : '';
    state.shop = $('rkwm-shop') ? Number($('rkwm-shop').value) || 0 : 0;
    state.docType = $('rkwm-doc-type') ? Number($('rkwm-doc-type').value) || 1 : 1;
  }
  function toggleDetail(title, data) {
    $('rkwm-detail-title').textContent = title;
    const container = $('rkwm-detail-content');
    container.replaceChildren();
    if (!data || !data.length) {
      container.appendChild(node('p', 'اطلاعات بیشتری برنگشت.'));
    } else {
      data.forEach(item => {
        const dl = node('dl', null, 'rkwm-detail-grid');
        Object.entries(item).forEach(([key, value]) => {
          dl.appendChild(node('dt', key));
          dl.appendChild(node('dd', value));
        });
        container.appendChild(dl);
      });
    }
    if ($('rkwm-detail-settlement')) {
      $('rkwm-detail-settlement').hidden = section !== 'invoices' || !activeInvoiceId;
    }
    detail.hidden = false;
    detail.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }
  async function showDetail(id) {
    if (!/^\d+$/.test(id)) return;
    notice('در حال دریافت جزئیات…');
    try {
      const response = await request('rkw_module_detail', { id });
      activeInvoiceId = section === 'invoices' ? Number(id) : null;
      toggleDetail((section === 'products' ? 'موجودی محصول #' : 'جزئیات فاکتور #') + id, response.items);
      notice('');
    } catch (e) { notice(e.message, 'error'); }
  }

  function openProductQuote(id, tr) {
    activeInvoiceId = null;
    toggleDetail('محاسبه قیمت راهکاران — بدون ثبت فاکتور', []);
    const box = $('rkwm-detail-content'); box.replaceChildren();
    box.appendChild(node('p', 'تخفیف ممکن است به مشتری، سیاست و تعداد وابسته باشد. مبلغ‌ها در واحد خام راهکاران هستند؛ این محاسبه هیچ سندی ثبت نمی‌کند.'));
    const quoteForm = node('form', null, 'rkw-product-quote-form'); const inputs = {};
    [['customer_id', 'شناسه مشتری راهکاران', rkwModules.priceContext?.customer_id || ''], ['settlement_id', 'شناسه سیاست تسویه', rkwModules.priceContext?.settlement_id || ''], ['quantity', 'تعداد', 1]].forEach(([key, label, value]) => {
      const wrap = node('label', label + ' '); const input = node('input'); input.type = 'number'; input.min = key === 'quantity' ? '0.000001' : '1'; input.step = key === 'quantity' ? 'any' : '1'; input.required = true; input.value = value; wrap.appendChild(input); quoteForm.appendChild(wrap); inputs[key] = input;
    });
    const submit = node('button', 'محاسبه از راهکاران', 'button button-primary'); submit.type = 'submit'; quoteForm.appendChild(submit); box.appendChild(quoteForm);
    quoteForm.addEventListener('submit', async e => {
      e.preventDefault(); if (submit.disabled) return; submit.disabled = true; notice('در حال محاسبه قیمت؛ هیچ فاکتوری ثبت نمی‌شود…');
      try {
        const response = await request('rkw_product_price_quote', { id, customer_id: digits(inputs.customer_id.value), settlement_id: digits(inputs.settlement_id.value), quantity: digits(inputs.quantity.value) });
        toggleDetail('نتیجه محاسبه قیمت — بدون ثبت', response.items);
        if (tr.children[5]) { tr.children[5].textContent = response.sale_price; tr.children[5].title = 'برای مشتری ' + response.customer_id + '، سیاست ' + response.settlement_id + ' و تعداد ' + response.quantity; }
        notice('قیمت محاسبه‌شده فقط برای شرایط انتخاب‌شده است؛ هیچ فاکتور یا محصولی ذخیره نشد.', 'success');
      } catch (err) { notice(err.message, 'error'); } finally { submit.disabled = false; }
    });
  }
  function settlementTable(data, label) {
    const box = node('section', null, 'rkwm-settlement-section');
    box.appendChild(node('h3', label));
    const table = node('table', null, 'widefat striped rkwm-settlement-table');
    const body = node('tbody');
    Object.entries(data).forEach(([heading, value]) => {
      const tr = node('tr');
      tr.appendChild(node('th', heading));
      tr.appendChild(node('td', value === undefined || value === null ? '—' : String(value)));
      body.appendChild(tr);
    });
    table.appendChild(body);
    box.appendChild(table);
    return box;
  }
  function renderSettlement(info) {
    const content = $('rkwm-settlement-content');
    content.replaceChildren();
    const overview = {
      'شناسه فاکتور راهکاران': info.invoice_id,
      'شماره فاکتور': info.invoice_number,
      'شناسه سیاست تسویه': info.policy_id,
      'عنوان سیاست': info.policy_title,
      'مبلغ خالص': info.net_price,
      'واحد مبلغ': info.currency,
      'تعداد دریافت‌ها': info.receipt_count,
      'تعداد پرداخت‌های خروجی': info.payment_count
    };
    content.appendChild(settlementTable(overview, 'مشخصات فاکتور'));
    const receipts = Array.isArray(info.receipts) ? info.receipts : [];
    if (!receipts.length) content.appendChild(node('p', 'در پاسخ GetInvoice دریافت وجهی وجود ندارد.', 'rkwm-settlement-empty'));
    receipts.forEach((item, i) => content.appendChild(settlementTable(item, 'دریافت شماره ' + (i + 1))));
    const payments = Array.isArray(info.payments) ? info.payments : [];
    payments.forEach((item, i) => content.appendChild(settlementTable(item, 'پرداخت خروجی شماره ' + (i + 1))));
    if (Array.isArray(info.safe_receipts_json) && info.safe_receipts_json.length) {
      const technical = node('details', null, 'rkwm-settlement-technical');
      technical.appendChild(node('summary', 'نمایش ساختار فنی امن receipts (خروجی GetInvoice)'));
      const pre = node('pre', JSON.stringify({receipts: info.safe_receipts_json}, null, 2));
      pre.dir = 'ltr';
      technical.appendChild(pre);
      const copy = node('button', 'کپی ساختار امن', 'button button-secondary');
      copy.type = 'button';
      copy.addEventListener('click', async () => {
        try { await navigator.clipboard.writeText(pre.textContent); copy.textContent = 'کپی شد'; }
        catch (e) { copy.textContent = 'کپی خودکار ممکن نشد؛ متن را دستی انتخاب کنید'; }
      });
      technical.appendChild(copy);
      content.appendChild(technical);
    }
    if (info.comparison) {
      if (info.comparison.error) content.appendChild(node('p', info.comparison.error, 'rkwm-settlement-error'));
      else content.appendChild(settlementTable(info.comparison, 'مقایسه با تنظیمات سفارش ووکامرس'));
    }
    content.appendChild(node('p', info.note || '', 'rkwm-settlement-note'));
  }
  function closeSettlement() {
    if (!settlementModal) return;
    ++settlementRequestId;
    settlementModal.hidden = true;
    document.body.classList.remove('rkwm-settlement-open');
    if (modalPreviousFocus && typeof modalPreviousFocus.focus === 'function') modalPreviousFocus.focus();
  }
  async function openSettlement(id, orderId) {
    if (!settlementModal || !Number.isSafeInteger(Number(id)) || Number(id) < 1) return;
    if (settlementModal.hidden) modalPreviousFocus = document.activeElement;
    const requestId = ++settlementRequestId;
    activeInvoiceId = Number(id);
    settlementModal.hidden = false;
    document.body.classList.add('rkwm-settlement-open');
    settlementModal.querySelector('.rkwm-settlement-modal').focus();
    const content = $('rkwm-settlement-content');
    content.replaceChildren(node('p', 'در حال دریافت اطلاعات تسویه فاکتور #' + id + ' از راهکاران…'));
    try {
      const values = {invoice_id: id};
      if (orderId) values.order_id = orderId;
      const result = await request('rkw_invoice_settlement', values);
      if (requestId === settlementRequestId && !settlementModal.hidden) renderSettlement(result);
    } catch (e) { if (requestId === settlementRequestId && !settlementModal.hidden) content.replaceChildren(node('p', e.message, 'rkwm-settlement-error')); }
  }
  if (settlementModal) {
    const lookup = $('rkwm-settlement-lookup');
    lookup.addEventListener('submit', e => {
      e.preventDefault();
      const id = Number($('rkwm-settlement-invoice-id').value);
      if (!Number.isSafeInteger(id) || id < 1) return notice('شناسه فاکتور معتبر نیست.', 'error');
      $('rkwm-settlement-order-id').value = '';
      openSettlement(id);
    });
    $('rkwm-detail-settlement-btn').addEventListener('click', () => {
      if (activeInvoiceId) { $('rkwm-settlement-order-id').value = ''; openSettlement(activeInvoiceId); }
    });
    $('rkwm-settlement-close').addEventListener('click', closeSettlement);
    settlementModal.addEventListener('click', e => { if (e.target === settlementModal) closeSettlement(); });
    document.addEventListener('keydown', e => { if (e.key === 'Escape' && !settlementModal.hidden) closeSettlement(); });
    $('rkwm-settlement-compare').addEventListener('submit', e => {
      e.preventDefault();
      const order = Number($('rkwm-settlement-order-id').value);
      if (!Number.isSafeInteger(order) || order < 1) return notice('شناسه سفارش ووکامرس معتبر نیست.', 'error');
      if (activeInvoiceId) openSettlement(activeInvoiceId, order);
    });
  }
  async function selectPolicy(id, button) {
    if (!/^\d+$/.test(id)) return;
    if (!window.confirm('سیاست تسویه #' + id + ' به‌عنوان سیاست پیش‌فرض ارسال سفارش/فاکتور ذخیره شود؟')) return;
    button.disabled = true;
    notice('در حال اعتبارسنجی سیاست در راهکاران…');
    try {
      const response = await request('rkw_policy_select', { id, doc_type: state.docType });
      $('rkwm-current-policy').textContent = String(response.id);
      notice(response.message, 'success');
    } catch (e) { notice(e.message, 'error'); }
    finally { button.disabled = false; }
  }
  const fmt = value => new Intl.NumberFormat('fa-IR').format(value);
  function addPageButton(page, caption) {
    const b = node('button', caption || fmt(page), 'button rkwm-page-button' + (page === state.page ? ' is-current' : ''));
    b.type = 'button';
    if (page === state.page) { b.setAttribute('aria-current', 'page'); b.disabled = true; }
    b.setAttribute('aria-label', 'صفحه ' + fmt(page));
    b.addEventListener('click', () => goPage(page));
    numbers.appendChild(b);
  }
  function pagination() {
    numbers.replaceChildren();
    const page = state.page;
    const totalPages = state.pages;
    if (totalPages !== null) {
      const pages = new Set([1, totalPages]);
      for (let n = Math.max(1, page - 2); n <= Math.min(totalPages, page + 2); n++) pages.add(n);
      let last = 0;
      [...pages].sort((a,b) => a-b).forEach(n => {
        if (n - last > 1) numbers.appendChild(node('span', '…', 'rkwm-ellipsis'));
        addPageButton(n);
        last = n;
      });
      countStatus.textContent = 'صفحه ' + fmt(page) + ' از ' + fmt(totalPages) + ' صفحه';
      jumpInput.max = String(totalPages);
    } else {
      const pages = new Set([1]);
      for (let n = Math.max(1, page - 2); n <= page; n++) pages.add(n);
      if (state.hasNext) pages.add(page + 1);
      let last = 0;
      [...pages].sort((a,b) => a-b).forEach(n => {
        if (n - last > 1) numbers.appendChild(node('span', '…', 'rkwm-ellipsis'));
        addPageButton(n);
        last = n;
      });
      countStatus.textContent = 'صفحه ' + fmt(page) + ' | ' + (state.countFailed ? 'تعداد کل صفحات از سرور قابل تعیین نیست' : 'در حال محاسبه تعداد کل صفحات…');
      jumpInput.max = '100000';
    }
    jumpInput.value = String(page);
    next.disabled = state.loading || !state.hasNext;
    prev.disabled = state.loading || page <= 1;
  }
  function goPage(number) {
    const page = Number(number);
    if (state.loading || !Number.isSafeInteger(page) || page < 1 || page > 100000) {
      notice('شماره صفحه معتبر وارد کنید.', 'error');
      return;
    }
    if (state.pages !== null && page > state.pages) {
      notice('حداکثر شماره صفحه ' + fmt(state.pages) + ' است.', 'error');
      jumpInput.value = String(state.page);
      return;
    }
    if (page === state.page) return;
    state.page = page;
    state.countRun++;
    load();
  }
  // Remote APIs do not necessarily expose a total count. Find the last page
  // asynchronously, in small server-side batches, without making up a total.
  async function discoverCount() {
    if (state.pages !== null || !['products', 'customers', 'invoices'].includes(section)) return;
    const token = ++state.countRun;
    const params = {
      size: state.size, search: state.search, mobile: state.mobile,
      shop: state.shop, phase: 'expand', low: 1, high: 2
    };
    for (let i = 0; i < 24 && token === state.countRun; i++) {
      try {
        const result = await request('rkw_module_count', params);
        if (token !== state.countRun) return;
        if (result.done) {
          state.total = Math.max(0, Number(result.total) || 0);
          state.pages = Math.max(1, Math.ceil(state.total / state.size));
          state.hasNext = state.page < state.pages;
          $('rkwm-count').textContent = 'مجموع: ' + fmt(state.total) + ' رکورد';
          pagination();
          return;
        }
        if (result.unavailable) {
          state.countFailed = true;
          pagination();
          return;
        }
        params.phase = result.phase;
        params.low = result.low;
        params.high = result.high;
      } catch (error) {
        if (token === state.countRun) { state.countFailed = true; pagination(); }
        return;
      }
    }
    if (token === state.countRun) { state.countFailed = true; pagination(); }
  }
  function showSnapshot(data) {
    snapshotStatus.replaceChildren();
    snapshotStatus.classList.remove('is-stale');
    const savedAt = Number(data.saved_at);
    if (!Number.isFinite(savedAt) || savedAt <= 0) {
      snapshotStatus.textContent = 'زمان آخرین دریافت مشخص نیست.';
      return;
    }
    const date = new Date(savedAt * 1000);
    const time = new Intl.DateTimeFormat('fa-IR', { dateStyle: 'medium', timeStyle: 'short' }).format(date);
    const old = (Date.now() / 1000 - savedAt) > 86400;
    if (old) snapshotStatus.classList.add('is-stale');
    const prefix = data.source === 'saved' ? 'اطلاعات ذخیره‌شده' : 'دریافت جدید از راهکاران';
    snapshotStatus.appendChild(node('span', prefix + ' | آخرین دریافت: ' + time));
    if (!data.persisted) snapshotStatus.appendChild(node('strong', ' | ذخیره دائمی این صفحه ممکن نشد؛ فضای پایگاه داده را بررسی کنید.'));
    else if (old) snapshotStatus.appendChild(node('strong', ' | ممکن است قیمت، موجودی یا فاکتورها تغییر کرده باشند؛ برای به‌روزرسانی دکمه بالا را بزنید.'));
  }
  function render(data) {
    results.replaceChildren();
    renderedOnce = true;
    lastRenderedPage = state.page;
    showSnapshot(data);
    const rows = Array.isArray(data.rows) ? data.rows : [];
    state.total = data.total === null || typeof data.total === 'undefined' ? null : Number(data.total);
    state.pages = state.total === null ? null : Math.max(1, Math.ceil(state.total / state.size));
    state.hasNext = !!data.has_next;
    $('rkwm-count').textContent = state.total === null
      ? 'نمایش ' + fmt(data.count) + ' رکورد در این صفحه'
      : 'مجموع: ' + fmt(state.total) + ' رکورد | این صفحه: ' + fmt(data.count);
    pagination();
    if (!rows.length) { results.appendChild(node('p', 'داده‌ای برای این فیلتر یافت نشد.', 'rkwm-empty')); return; }
    const table = node('table', null, 'widefat striped rkwm-table');
    const thead = node('thead');
    const header = node('tr');
    data.headers.forEach(label => header.appendChild(node('th', label)));
    const actions = rows.some(r => r.detail || r.selectable);
    if (actions) header.appendChild(node('th', 'عملیات'));
    thead.appendChild(header);
    table.appendChild(thead);
    const tbody = node('tbody');
    rows.forEach(row => {
      const tr = node('tr');
      (row.cells || []).forEach(value => tr.appendChild(node('td', value)));
      if (actions) {
        const td = node('td');
        if (row.detail || row.selectable) {
          const button = node('button', row.selectable ? 'انتخاب سیاست' : (section === 'products' ? 'موجودی' : 'جزئیات'), 'button button-secondary');
          button.type = 'button';
          button.addEventListener('click', () => row.selectable ? selectPolicy(String(row.id), button) : showDetail(String(row.id)));
          td.appendChild(button);
        }
        if (section === 'products' && row.detail && /^[1-9][0-9]*$/.test(String(row.id))) {
          const priceButton = node('button', 'بررسی قیمت', 'button button-secondary');
          priceButton.type = 'button';
          priceButton.addEventListener('click', async () => {
            priceButton.disabled = true;
            notice('در حال خواندن قیمت همان محصول از راهکاران…');
            try {
              const response = await request('rkw_product_price_detail', { id: String(row.id) });
              activeInvoiceId = null;
              toggleDetail('بررسی قیمت محصول #' + row.id, response.items);
              if (response.sale_price && response.sale_price !== '—' && tr.children[5]) tr.children[5].textContent = response.sale_price;
              notice('بررسی فقط خواندنی انجام شد؛ قیمت و موجودی تغییر نکرد.');
            } catch (e) { notice(e.message, 'error'); }
            finally { priceButton.disabled = false; }
          });
          td.appendChild(priceButton);
          if (rkwModules.api !== 'v19') { const quoteButton = node('button', 'محاسبه تخفیف', 'button button-secondary'); quoteButton.type = 'button'; quoteButton.addEventListener('click', () => openProductQuote(String(row.id), tr)); td.appendChild(quoteButton); }
        }
        if (section === 'invoices' && row.detail && /^\d+$/.test(String(row.id))) {
          const settlementButton = node('button', 'جزئیات تسویه و پرداخت', 'button rkwm-settlement-row-button');
          settlementButton.type = 'button';
          settlementButton.addEventListener('click', () => { $('rkwm-settlement-order-id').value = ''; openSettlement(Number(row.id)); });
          td.appendChild(settlementButton);
          const returnState = row.return_status || {state: 'available'};
          const returnButton = node('button', returnState.state === 'returned' ? 'برگشت از فروش #' + returnState.id : (returnState.state === 'pending' ? 'برگشت نیازمند بررسی' : 'برگشت از فروش'), 'button rkw-return-invoice');
          returnButton.type = 'button';
          returnButton.dataset.invoice = String(row.id);
          returnButton.disabled = returnState.state !== 'available';
          td.appendChild(returnButton);
        }
        tr.appendChild(td);
      }
      tbody.appendChild(tr);
    });
    table.appendChild(tbody);
    results.appendChild(table);
  }
  async function load(force = false) {
    if (state.loading) return;
    setBusy(true);
    detail.hidden = true;
    notice(force ? 'در حال به‌روزرسانی اطلاعات از راهکاران…' : 'در حال نمایش اطلاعات ذخیره‌شده یا دریافت اولیه…');
    try {
      let data;
      const mode = searchMode?.value || 'auto';
      const exact = section === 'products' && searchMode && state.search && (mode === 'code' || mode === 'id' || (mode === 'auto' && /^[0-9]+$/.test(digits(state.search))));
      if (exact) {
        codeStopped = false; codeStop.hidden = false; codeStop.disabled = false; codeStop.textContent = 'توقف جست‌وجوی کد';
        let scan = { scan_page: 1, scanned: 0, fingerprint: '', connection: '' };
        do {
          data = await request('rkw_product_code_search', Object.assign({ search: digits(state.search), search_mode: mode === 'id' ? 'id' : 'code', size: state.size, force: force ? '1' : '0' }, scan));
          if (codeStopped) { notice('جست‌وجو متوقف شد؛ یافت‌نشدن محصول نتیجه‌گیری نشد.'); return; }
          if (data.code_search_pending) { scan = data; notice('جست‌وجوی دقیق کد؛ ' + data.scanned + ' محصول بررسی شد…'); }
        } while (data.code_search_pending);
      } else {
        data = await request('rkw_module_list', { page_num: state.page, size: state.size, search: state.search, mobile: state.mobile, shop: state.shop, doc_type: state.docType, force: force ? '1' : '0' });
      }
      render(data);
      notice(data.source === 'saved' ? 'آخرین اطلاعات ذخیره‌شده نمایش داده شد.' : 'اطلاعات جدید دریافت شد.', 'success');
      if (state.pages === null && !state.countFailed) discoverCount();
    } catch (e) {
      if (!renderedOnce) {
        results.replaceChildren(node('p', 'داده ذخیره‌شده‌ای برای این فهرست در دسترس نیست و دریافت از راهکاران ناموفق بود.', 'rkwm-empty'));
        state.hasNext = false;
      } else {
        state.page = lastRenderedPage; // Do not show a different page number over previously rendered rows.
      }
      state.countRun++;
      notice(e.message + (renderedOnce ? ' | اطلاعات قبلی حفظ شده‌اند.' : ''), 'error');
      pagination();
    } finally { codeStop.hidden = true; setBusy(false); }
  }
  form.addEventListener('submit', e => { e.preventDefault(); collect(); state.page = 1; state.pages = null; state.total = null; state.countFailed = false; state.countRun++; load(true); });
  next.addEventListener('click', () => { if (state.hasNext && !state.loading) goPage(state.page + 1); });
  prev.addEventListener('click', () => { if (state.page > 1 && !state.loading) goPage(state.page - 1); });
  jump.addEventListener('submit', e => { e.preventDefault(); goPage(Number(jumpInput.value)); });
  // Restore the administrator's most recently viewed page and filters after a refresh.
  // Stored rows live in WordPress options, not in browser memory.
  const previous = rkwModules.initial || {};
  if (previous && typeof previous === 'object') {
    if (searchMode && ['auto','name','code','id'].includes(previous.search_mode)) searchMode.value = previous.search_mode;
    if ([20, 50, 100].includes(Number(previous.size))) $('rkwm-size').value = String(previous.size);
    if ($('rkwm-search')) $('rkwm-search').value = String(previous.search || '').slice(0, 100);
    if ($('rkwm-mobile')) $('rkwm-mobile').value = String(previous.mobile || '').slice(0, 20);
    if ($('rkwm-shop')) $('rkwm-shop').value = String(Math.max(0, Number(previous.shop) || 0));
    if ($('rkwm-doc-type') && [1, 2].includes(Number(previous.docType))) $('rkwm-doc-type').value = String(previous.docType);
    collect();
    state.page = Math.max(1, Math.min(100000, Number(previous.page) || 1));
  }
  pagination();
  $('rkwm-detail-close').addEventListener('click', () => { detail.hidden = true; });
  const remoteAccordion = $('rkwm-remote-invoices');
  if (section === 'invoices' && remoteAccordion) {
    remoteAccordion.addEventListener('toggle', () => {
      if (remoteAccordion.open && !renderedOnce && !state.loading) load(false);
    });
    if (remoteAccordion.open) load(false);
  } else { load(false); }
})();
