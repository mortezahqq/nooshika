<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Explicit administrative product lookups and calculation-only price quotes. */
class RKW_Product_Tools {
 public static function init() {
  add_action('wp_ajax_rkw_product_code_search',array(__CLASS__,'ajax_search'));
  add_action('wp_ajax_rkw_product_price_quote',array(__CLASS__,'ajax_quote'));
 }
 public static function normalize($value) {
  return trim(strtr((string)$value,array('۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9','٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9')));
 }
 private static function guard() {
  if(!current_user_can('manage_woocommerce')||!check_ajax_referer('rkw_module','nonce',false))wp_send_json_error(array('message'=>'دسترسی یا نشست معتبر نیست.'),403);
  if(rkw_settings()['api']!=='v21')wp_send_json_error(array('message'=>'این ابزار برای API نسخه ۲۱ است.'),400);
 }
 private static function fail($message,$status=409){wp_send_json_error(array('message'=>$message),$status);}
 private static function rows($raw) {
  if(!is_array($raw))return null;
  if(isset($raw['items'])&&is_array($raw['items']))return $raw['items'];
  if(isset($raw['data'])&&is_array($raw['data']))return $raw['data'];
  if(array_values($raw)===$raw)return $raw;
  return isset($raw['productId'])?array($raw):null;
 }
 private static function matches($rows,$code){
  $found=array();foreach($rows as$row){if(!is_array($row)||empty($row['productId']))continue;
   if(self::normalize($row['productNumber']??($row['code']??''))===$code)$found[(int)$row['productId']]=$row;
  }return array_values($found);
 }
 private static function text($row,$keys){foreach($keys as$key)if(isset($row[$key])&&is_scalar($row[$key])&&(string)$row[$key]!=='')return(string)$row[$key];return '—';}
 private static function search_result($rows,$query,$mode,$size){
  $table=array();$catalog=array();foreach($rows as$row){
   $table[]=array('id'=>$row['productId'],'detail'=>true,'cells'=>array((string)$row['productId'],self::text($row,array('productNumber','code')),self::text($row,array('productName','name')),self::text($row,array('unitName','retailUnitName')),self::text($row,array('fee','price')),RKW_Modules::product_sale_price($row)));
   $item=RKW_Sync::normalize_single($row,'v21');if($item)$catalog[$item['id']]=$item;
  }
  $result=array('headers'=>array('شناسه','کد کالا','عنوان محصول','واحد','قیمت پایه','قیمت تخفیفی'),'rows'=>$table,'count'=>count($table),'total'=>count($table),'has_next'=>false,'page'=>1,'pages'=>1,'section'=>'products','catalog_items'=>$catalog,'snapshot_params'=>array('page'=>1,'size'=>$size,'search'=>$query),'source'=>'fresh','saved_at'=>time());
  $key=RKW_Snapshot::key('products',1,$size,$mode.':'.$query,'',0,1);$result['persisted']=RKW_Snapshot::save($key,$result);
  RKW_Snapshot::remember_view('products',array('page'=>1,'size'=>$size,'search'=>$query,'search_mode'=>$mode));
  wp_send_json_success($result);
 }
 public static function ajax_search(){
  self::guard();$code=isset($_POST['search'])&&is_scalar($_POST['search'])?self::normalize(wp_unslash($_POST['search'])):'';
  if($code===''||rkw_text_length($code)>100)self::fail('کد محصول معتبر وارد کنید.',400);
  $mode=($_POST['search_mode']??'code')==='id'?'id':'code';$size=max(5,min(100,(int)($_POST['size']??20)));
  $page=max(1,(int)($_POST['scan_page']??1));if($page>1000)self::fail('جست‌وجو به سقف مجاز رسید؛ یافت‌نشدن محصول تأیید نشده است.');
  $signature=RKW_Policy_Catalog::signature();
  if($page===1&&($_POST['force']??'0')!=='1'){
   $saved=RKW_Snapshot::read(RKW_Snapshot::key('products',1,$size,$mode.':'.$code,'',0,1));
   if($saved){$data=$saved['data'];$data['source']='saved';$data['saved_at']=$saved['saved_at'];$data['persisted']=true;wp_send_json_success($data);}
  }
  $client=new RKW_Client(5);
  if($mode==='id'){
   if(!preg_match('/^[1-9][0-9]*$/D',$code))self::fail('شناسه داخلی باید عدد صحیح مثبت باشد.',400);
   $raw=$client->product_by_id((int)$code);if(is_wp_error($raw))self::fail($raw->get_error_message(),502);
   if(!is_array($raw)||(string)($raw['productId']??'')!==$code)self::fail('شناسه پاسخ با شناسه درخواستی برابر نیست.');
   if($signature!==RKW_Policy_Catalog::signature())self::fail('اتصال تغییر کرد؛ جست‌وجو را دوباره شروع کنید.');
   self::search_result(array($raw),$code,$mode,$size);
  }
  if($page===1){
   $raw=$client->products21(1,100,$code);if(is_wp_error($raw))self::fail($raw->get_error_message(),502);
   $rows=self::rows($raw);if(null===$rows)self::fail('قالب پاسخ جست‌وجوی محصولات معتبر نیست.');
   $found=self::matches($rows,$code);if($found){if($signature!==RKW_Policy_Catalog::signature())self::fail('اتصال تغییر کرد.');self::search_result($found,$code,$mode,$size);}
  }else if(!isset($_POST['connection'])||!hash_equals($signature,(string)$_POST['connection']))self::fail('اتصال تغییر کرد؛ جست‌وجو را از ابتدا شروع کنید.');
  $previous=isset($_POST['fingerprint'])&&is_string($_POST['fingerprint'])?$_POST['fingerprint']:'';$scanned=max(0,(int)($_POST['scanned']??0));
  for($i=0;$i<2;$i++,$page++){
   $raw=$client->products21($page,100,'');if(is_wp_error($raw))self::fail($raw->get_error_message(),502);
   if($signature!==RKW_Policy_Catalog::signature())self::fail('اتصال تغییر کرد؛ جست‌وجو را از ابتدا شروع کنید.');
   $rows=self::rows($raw);if(null===$rows)self::fail('قالب فهرست محصولات معتبر نیست.');
   $ids=array();foreach($rows as$row){if(!is_array($row)||empty($row['productId']))self::fail('فهرست محصول دارای ردیف نامعتبر است.');$ids[]=(int)$row['productId'];}
   $fingerprint=hash('sha256',wp_json_encode($ids));if(count($rows)&&$fingerprint===$previous)self::fail('سرور صفحه تکراری برگرداند؛ یافت‌نشدن محصول تأیید نشده است.');
   $scanned+=count($rows);$found=self::matches($rows,$code);if($found)self::search_result($found,$code,$mode,$size);
   if(count($rows)<100)self::search_result(array(),$code,$mode,$size);
   $previous=$fingerprint;
  }
  wp_send_json_success(array('code_search_pending'=>true,'scan_page'=>$page,'scanned'=>$scanned,'fingerprint'=>$previous,'connection'=>$signature));
 }
 public static function ajax_quote(){
  self::guard();$s=rkw_settings();$signature=RKW_Policy_Catalog::signature();$values=array();
  foreach(array('id','customer_id','settlement_id')as$key){$v=isset($_POST[$key])&&is_scalar($_POST[$key])?self::normalize($_POST[$key]):'';if(!preg_match('/^[1-9][0-9]*$/D',$v))self::fail('شناسه محصول، مشتری و سیاست تسویه باید معتبر باشند.',400);$values[$key]=(int)$v;}
  $quantity=isset($_POST['quantity'])&&is_scalar($_POST['quantity'])?self::normalize($_POST['quantity']):'1';if(!is_numeric($quantity)||!is_finite((float)$quantity)||(float)$quantity<=0||(float)$quantity>10000)self::fail('تعداد معتبر وارد کنید.',400);$quantity=(float)$quantity;
  $pattern=(int)($s['invoice_doc_pattern_id']?:$s['doc_pattern_id']);if(!$pattern||!(int)$s['inventory_id'])self::fail('انبار و الگوی فاکتور در تنظیمات مشخص نشده‌اند.');
  $client=new RKW_Client(15);$client->use_coupon_invoice_context(); // Preserve the cashier method that works on this installation; no document is saved.
  $raw=$client->product_by_id($values['id']);if(is_wp_error($raw))self::fail($raw->get_error_message(),502);
  $item=RKW_Sync::normalize_single($raw,'v21');if(!$item||$item['id']!==$values['id'])self::fail('محصول برگشتی با درخواست یکسان نیست.');
  $fee=$item['price'];$unit=$item['unit']?:$s['default_unit_id'];if(!is_numeric($fee)||!is_finite((float)$fee)||(float)$fee<=0||!$unit)self::fail('قیمت پایه یا واحد معتبر برای محاسبه دریافت نشد.');
  $base=round((float)$fee*$quantity,2);
  $document=array('id'=>0,'inventoryId'=>(int)$s['inventory_id'],'storeId'=>(int)$s['inventory_id'],'salesAreaId'=>(int)$s['sales_area_ord']?:null,'documentPatternId'=>$pattern,'documentType'=>1,'customerId'=>$values['customer_id'],'status'=>0,'currencyId'=>(int)$s['currency_id'],'date'=>gmdate('Y-m-d\TH:i:s'),'settlementPolicyId'=>$values['settlement_id'],'policies'=>array(),'data'=>array('discountCards'=>array(),'loyaltyProgramID'=>(int)$s['loyalty_id']?:null),'items'=>array(array('Id'=>0,'inventoryId'=>(int)$s['inventory_id'],'storeId'=>(int)$s['inventory_id'],'settlementPolicyId'=>$values['settlement_id'],'productId'=>$values['id'],'quantity'=>$quantity,'unitId'=>(int)$unit,'fee'=>(float)$fee,'price'=>$base,'policies'=>array(),'toppings'=>array())));
  $r=$client->calculate_invoice21($document);if(is_wp_error($r))self::fail($r->get_error_message(),502);
  if($signature!==RKW_Policy_Catalog::signature()||$s!==rkw_settings())self::fail('اتصال یا تنظیمات هنگام محاسبه تغییر کرد؛ نتیجه کنار گذاشته شد.');
  if(!is_array($r)||!empty($r['hasError'])||!isset($r['netPrice'])||!is_numeric($r['netPrice'])||!is_finite((float)$r['netPrice'])||(float)$r['netPrice']<0||!isset($r['items'])||!is_array($r['items'])||count($r['items'])!==1)self::fail('پاسخ محاسبه مبلغ نهایی معتبر و بدون خطا نبود.');
  $line=reset($r['items']);if(!is_array($line)||!empty($line['hasError'])||isset($line['productId'])&&(int)$line['productId']!==$values['id'])self::fail('راهکاران ردیف محصول را تأیید نکرد؛ قیمت تخفیفی نمایش داده نشد.');
  $net=(float)$r['netPrice'];$per_unit=round($net/$quantity,6);$sale=$net<$base?(string)$per_unit:'—';
  wp_send_json_success(array('sale_price'=>$sale,'customer_id'=>$values['customer_id'],'settlement_id'=>$values['settlement_id'],'quantity'=>$quantity,'items'=>array(array('شناسه محصول'=>$values['id'],'شناسه مشتری'=>$values['customer_id'],'سیاست تسویه'=>$values['settlement_id'],'تعداد'=>$quantity,'قیمت پایه واحد'=>(float)$fee,'جمع پایه'=>$base,'جمع نهایی محاسبه راهکاران'=>$net,'قیمت نهایی واحد'=>$per_unit,'قیمت تخفیفی محاسبه‌شده'=>$sale,'توضیح'=>'این قیمت برای همین مشتری، سیاست، تعداد و زمان محاسبه است؛ ممکن است مالیات و سیاست‌های خودکار را دربر بگیرد. مبلغ‌ها در واحد خام راهکاران هستند. هیچ فاکتور، مشتری یا محصولی ثبت یا تغییر داده نشد.'))));
 }
}
