"""Run the actual generated name/number predicates before COUNT and LIMIT in both datastores."""
import os,json,re,sqlite3,subprocess
from pathlib import Path
root=Path(__file__).resolve().parent.parent
php=os.environ.get('RKW_TEST_PHP','php')
def sql_like(pattern,value):
    expression='';i=0
    while i<len(pattern):
        c=pattern[i]
        if c=='\\' and i+1<len(pattern):i+=1;expression+=re.escape(pattern[i])
        elif c=='%':expression+='.*'
        elif c=='_':expression+='.'
        else:expression+=re.escape(c)
        i+=1
    return re.fullmatch(expression,str(value or ''),re.S|re.I) is not None
for mode in ('classic','hpos'):
    db=sqlite3.connect(':memory:');db.create_function('regexp',2,lambda p,v:v is not None and re.search(p,str(v))is not None);db.create_function('like',2,sql_like)
    db.executescript('''CREATE TABLE wp_posts (ID INTEGER PRIMARY KEY,post_type TEXT,post_status TEXT,post_date TEXT);
    CREATE TABLE wp_postmeta (post_id INTEGER,meta_key TEXT,meta_value TEXT);
    CREATE TABLE wp_wc_orders (id INTEGER PRIMARY KEY,type TEXT,status TEXT,date_created_gmt TEXT,total_amount NUMERIC);
    CREATE TABLE wp_wc_orders_meta(order_id INTEGER,meta_key TEXT,meta_value TEXT);
    CREATE TABLE wp_wc_order_addresses(order_id INTEGER,address_type TEXT,first_name TEXT,last_name TEXT);
    CREATE TABLE wp_wc_order_operational_data(order_id INTEGER,date_paid_gmt TEXT);''')
    meta='wp_postmeta' if mode=='classic' else 'wp_wc_orders_meta'
    expected=[];unsent=[]
    for i in range(1,76):
        oid=1000+i;status='wc-processing';total=100;paid=True
        if i==61:status='wc-packed'
        if i==62:status='wc-packed';paid=False
        if i==63:status='wc-failed'
        if i==64:total=0
        if i==65:status='wc-cancelled'
        first,last=('علي','كريمي')if i==20 else ('نام%خاص','شماره_یک')if i==30 else ('مشتری','نمونه')
        db.execute('INSERT INTO wp_posts VALUES (?,?,?,?)',(oid,'shop_order',status if mode=='classic' else 'wc-failed','2026-10-25 10:00:00'))
        db.execute('INSERT INTO wp_wc_orders VALUES (?,?,?,?,?)',(oid,'shop_order',status if mode=='hpos' else 'wc-failed','2026-10-25 06:30:00',total))
        db.execute('INSERT INTO wp_postmeta VALUES (?,?,?)',(oid,'_order_total',str(total)if mode=='classic'else'0'))
        if paid:
            db.execute('INSERT INTO wp_postmeta VALUES (?,?,?)',(oid,'_date_paid','1792915200'));db.execute('INSERT INTO wp_wc_order_operational_data VALUES (?,?)',(oid,'2026-10-25 06:30:00'))
        for key,value in [('_billing_first_name',first),('_billing_last_name',last),('_order_number_formatted','WEB-'+str(oid))]:db.execute(f'INSERT INTO {meta} VALUES (?,?,?)',(oid,key,value))
        db.execute('INSERT INTO wp_wc_order_addresses VALUES (?,?,?,?)',(oid,'billing',first,last));db.execute('INSERT INTO wp_wc_order_addresses VALUES (?,?,?,?)',(oid,'shipping','گیرنده','فقط'))
        sent=i%7==0
        if sent:db.execute(f'INSERT INTO {meta} VALUES (?,?,?)',(oid,'_rkw_doc_id',str(7000+i)))
        if i==7:db.execute(f'INSERT INTO {meta} VALUES (?,?,?)',(oid,'_rkw_reconcile_required','1'));sent=False
        marked=i in (1,7,8)
        if marked:db.execute(f'INSERT INTO {meta} VALUES (?,?,?)',(oid,'_rkw_manual_recorded','1'))
        if first=='مشتری' and status in ('wc-processing','wc-packed') and paid and total:
            expected.append(oid)
            if not sent and not marked:unsent.append(oid)
    expected.sort(reverse=True);unsent.sort(reverse=True)
    def execute(query,kind='buyer',filter='all',page=1):
        raw=subprocess.check_output([php,'-n',str(root/'tests/manual-orders.php'),'sql',mode,query,kind,filter,str(page)],text=True)
        generated=json.loads(raw);return db.execute(generated[0]).fetchone()[0],[r[0]for r in db.execute(generated[1])]
    for filter,ids in [('all',expected),('unsent',unsent)]:
        pages=(len(ids)+24)//25;combined=[]
        for page in range(1,pages+1):
            count,actual=execute('مشتری نمونه',filter=filter,page=page)
            assert count==len(ids),(mode,filter,'count',count,len(ids));assert actual==ids[(page-1)*25:page*25];combined+=actual
        assert combined==ids
    print('PASS',mode,': buyer name and unsent filters apply to the entire dataset before count and pagination')
    for q,kind,want in [('علی کریمی','buyer',[1020]),('نام%خاص','buyer',[1030]),('شماره_یک','buyer',[1030]),('WEB-1003','number',[1003]),('#۱۰۰۳','number',[1003]),('100','number',[]),('گیرنده فقط','buyer',[]),('مشتری نمونه مشتری نمونه مشتری نمونه مشتری نمونه ناموجود','buyer',[]),("x%' OR 1=1 --",'buyer',[])]:
        count,actual=execute(q,kind);assert actual==want and count==len(want),(mode,q,count,actual,want)
    print('PASS',mode,': Arabic/Persian names, literal wildcards, exact numeric/formatted order numbers, billing-only matching and escaped injection')
