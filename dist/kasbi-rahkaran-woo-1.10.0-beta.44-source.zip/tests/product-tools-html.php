<?php
require __DIR__.'/bootstrap.php';
function get_current_user_id(){return 7;}function esc_url($s){return esc_attr($s);}function selected($a,$b,$echo=true){$v=(string)$a===(string)$b?'selected="selected"':'';if($echo)echo$v;return$v;}
reset_case();$_GET=['page'=>'rkw-products'];RKW_Modules::page();
