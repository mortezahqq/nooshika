const assert = require('node:assert/strict');
const path = require('node:path');
const fs = require('node:fs');
const { chromium } = require('playwright');
// Use an installed WooCommerce source file for the native variation integration.
const native = process.env.RKW_WC_VARIATION_SCRIPT || '/tmp/rkw-upstream-variation.js';
assert(fs.existsSync(native), 'Set RKW_WC_VARIATION_SCRIPT to WooCommerce add-to-cart-variation.js');
const script = path.join(__dirname, '../rahkaran-woo/assets/product-view.js');
const ok = data => ({ success: true, data });
const simple = extra => ({ price_html: '<span>500</span>', stock_html: '<p class="stock out-of-stock">ناموجود</p>', in_stock: false, purchasable: true, variable: false, variations: [], cart_html: '', ...extra });
const html = form => `<div class="product"><div class="summary entry-summary"><p class="price"><span>100</span></p><p class="stock in-stock">3</p>${form}</div></div>`;
const cart = '<form class="cart"><input class="qty" name="quantity" value="1"><button class="single_add_to_cart_button">خرید</button></form>';
const variation = (stock, price) => ({ variation_id: 300, attributes: {attribute_color: 'blue'}, variation_is_active: true, variation_is_visible: true, is_in_stock: stock, is_purchasable: true, min_qty: 1, max_qty: stock ? 3 : 0, is_sold_individually: 'no', price_html: `<span>${price}</span>`, availability_html: `<p class="stock">${stock ? 'موجود' : 'ناموجود'}</p>`, image: false, sku: '', weight: '', dimensions: '' });
const variableHTML = () => `<div class="product"><div class="summary entry-summary"><p class="price">100</p>
<form class="cart variations_form" data-product_id="200" data-product_variations='${JSON.stringify([variation(true, 100)])}'>
<table class="variations"><tr><td><select name="attribute_color" data-attribute_name="attribute_color"><option value="">انتخاب</option><option value="blue" selected>آبی</option></select><a class="reset_variations">پاک کردن</a></td></tr></table>
<div class="single_variation_wrap"><div class="single_variation"></div><div class="woocommerce-variation-add-to-cart variations_button"><div class="quantity"><input class="qty" name="quantity" value="1"></div><button class="single_add_to_cart_button">خرید</button><input class="variation_id" name="variation_id"></div></div></form></div></div>
<script type="text/template" id="tmpl-variation-template"><div class="woocommerce-variation-price">{{{ data.variation.price_html }}}</div><div class="woocommerce-variation-availability">{{{ data.variation.availability_html }}}</div></script>
<script type="text/template" id="tmpl-unavailable-variation-template">ناموجود</script>`;

(async () => {
    const browser = await chromium.launch({headless: true, executablePath: '/usr/bin/chromium', args: ['--no-sandbox']});
    async function fixture(markup, handler, variable = false) {
        const page = await browser.newPage(), errors = [], calls = [];
        let active = 0, maximum = 0;
        page.on('pageerror', error => errors.push(error.message));
        await page.route('https://wordpress.example.invalid/**', async route => {
            const data = Object.fromEntries(new URLSearchParams(route.request().postData() || ''));
            assert.equal(data.action, 'rkw_product_view');
            assert.equal(route.request().method(), 'POST');
            calls.push(data); active++; maximum = Math.max(maximum, active);
            try {
                const result = await handler(data, calls.length);
                if (result === 'abort') { return await route.abort('failed'); }
                await route.fulfill({status: 200, contentType: 'application/json', headers: {'Access-Control-Allow-Origin': '*', 'Cache-Control': 'no-store'}, body: JSON.stringify(result)});
            } finally { active--; }
        });
        await page.setContent(markup);
        await page.addScriptTag({path: '/usr/share/javascript/jquery/jquery.js'});
        if (variable) {
            await page.evaluate(() => {
                // WordPress template boundary double; the variation selection,
                // reload and purchase-state logic below is the real Woo source.
                window.wp = {template: id => data => document.getElementById('tmpl-'+id).textContent.replace(/\{\{\{\s*data\.variation\.([a-z_]+)\s*\}\}\}/g, (_,key) => data.variation[key] || '')};
                window.wc_add_to_cart_variation_params = {i18n_no_matching_variations_text:'ناموجود',i18n_unavailable_text:'ناموجود',i18n_make_a_selection_text:'انتخاب کنید',i18n_reset_alert_text:'پاک شد'};
            });
            await page.addScriptTag({path: native});
            await page.waitForFunction(() => document.querySelector('input.variation_id').value === '300', null, {timeout: 3000}).catch(async error => {
                console.error('Native variation fixture', errors, await page.evaluate(() => ({selected:jQuery('select').val(),data:jQuery('form').data('product_variations')})));
                throw error;
            });
        }
        await page.evaluate(id => { window.rkwProductView = {product: id, ajax: 'https://wordpress.example.invalid/wp-admin/admin-ajax.php'}; }, variable ? 200 : 101);
        await page.addScriptTag({path: script});
        return {page, calls, errors, maximum: () => maximum};
    }
    try {
        const one = await fixture(html(cart), () => ok({done:true,cursor:1,status:'updated',display:simple()}));
        await one.page.waitForFunction(() => document.querySelector('.summary > .price').textContent === '500');
        assert.equal(await one.page.locator('form.cart').isVisible(), false);
        assert.equal(await one.page.locator('button').isDisabled(), true);
        assert.match(await one.page.locator('.summary > .stock').textContent(), /ناموجود/);
        assert.equal(one.calls.length, 1); assert.deepEqual(one.errors, []);
        await one.page.addScriptTag({path:script}); await one.page.waitForTimeout(50); assert.equal(one.calls.length,1);
        await one.page.close(); console.log('PASS browser: a cached stale simple page updates its price and stock and disables buying without duplicate requests');

        const two = await fixture(html(cart.replace('value="1"','value="3"')), () => ok({done:true,cursor:1,status:'fresh',updated:false,display:simple({in_stock:true,quantity_min:1,quantity_max:2,stock_html:'<p class="stock">2</p>'})}));
        await two.page.waitForFunction(() => document.querySelector('.summary > .price').textContent === '500');
        assert.equal(await two.page.locator('form.cart').isVisible(),true); assert.equal(await two.page.locator('button').isEnabled(),true);
        assert.equal(await two.page.locator('input.qty').getAttribute('max'),'2'); assert.equal(await two.page.locator('input.qty').inputValue(),'2');
        assert.deepEqual(two.errors,[]); await two.page.close(); console.log('PASS browser: a fresh server timestamp still repairs old cached HTML without requiring an ERP update');

        const three = await fixture(html(''), data => { assert.equal(data.include_cart,'1'); return ok({done:true,cursor:1,status:'updated',display:simple({in_stock:true,stock_html:'<p class="stock">5</p>',cart_html:cart})}); });
        await three.page.waitForSelector('form.cart'); assert.equal(await three.page.locator('button').isEnabled(),true); assert.deepEqual(three.errors,[]);
        await three.page.close(); console.log('PASS browser: an initially unavailable simple product receives a native buy form after restocking');

        const four = await fixture(variableHTML(), () => ok({done:true,cursor:1,status:'updated',display:{...simple(),variable:true,in_stock:true,price_html:'<span>700</span>',variations:[variation(false,700)]}}), true);
        await four.page.waitForFunction(() => document.querySelector('.woocommerce-variation-price')?.textContent === '700');
        assert.equal(await four.page.locator('select').inputValue(),'blue');
        assert.match(await four.page.locator('.single_add_to_cart_button').getAttribute('class'),/wc-variation-is-unavailable/);
        assert.match(await four.page.locator('.woocommerce-variation-availability').textContent(),/ناموجود/);
        assert.deepEqual(four.errors,[]); await four.page.close(); console.log('PASS browser: the real native WooCommerce variation engine reloads its data, preserves selection and prevents purchase of the now-unavailable size');

        const five = await fixture(html(cart), (data,n) => { assert.equal(data.cursor,String(n-1)); return ok({done:n===3,cursor:n,status:'updated',display:simple({in_stock:true,price_html:`<span>${100*n}</span>`})}); });
        await five.page.waitForFunction(() => document.querySelector('.summary > .price').textContent === '300');
        assert.equal(five.calls.length,3); assert.equal(five.maximum(),1); assert.deepEqual(five.errors,[]); await five.page.close(); console.log('PASS browser: stale variants are refreshed in sequential bounded requests');

        const six = await fixture(html(cart), () => 'abort');
        await six.page.waitForTimeout(200); assert.equal(await six.page.locator('.price').textContent(),'100'); assert.equal(await six.page.locator('button').isEnabled(),true);
        assert.deepEqual(six.errors,[]); await six.page.close(); console.log('PASS browser: failed background refresh preserves the existing page without an unhandled error');

        const seven = await fixture(html(cart.replace('value="1"','value="0"')), (data,n) => { assert.equal(data.cursor,'0'); return ok(n===1?{done:true,cursor:1,status:'busy',retry_cursor:0}:{done:true,cursor:1,status:'fresh',display:simple({in_stock:true,quantity_min:1,quantity_max:5,stock_html:'<p class="stock">5</p>'})}); });
        await seven.page.waitForFunction(() => document.querySelector('.price').textContent === '500');
        assert.equal(seven.calls.length,2); assert.equal(await seven.page.locator('input.qty').inputValue(),'1'); assert.deepEqual(seven.errors,[]); await seven.page.close(); console.log('PASS browser: a simultaneous viewer waits for the owning refresh and reads its updated result');
    } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exit(1); });
