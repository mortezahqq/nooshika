"""Execute the actual production ID-mapping query against mixed product metadata."""
import os,sqlite3,subprocess
from pathlib import Path
query=subprocess.check_output([os.environ.get('RKW_TEST_PHP','php'),'-n',str(Path(__file__).with_suffix('.php'))],text=True)
db=sqlite3.connect(':memory:')
db.executescript('CREATE TABLE wp_posts (ID INTEGER PRIMARY KEY,post_type TEXT,post_status TEXT); CREATE TABLE wp_postmeta(post_id INTEGER,meta_key TEXT,meta_value TEXT);')
fixtures=[
 (10,'product_variation','publish','_rahkaran_product_id','271130'),
 (11,'product','publish','_rahkaran_product_id','271130'),
 (12,'product','draft','_rahkaran_product_id','271130'),
 (13,'product','trash','_rahkaran_product_id','271130'),
 (14,'product','auto-draft','_rahkaran_product_id','271130'),
 (15,'shop_order','wc-processing','_rahkaran_product_id','271130'),
 (16,'product_variation','publish','_rahkaran_product_id','271131'),
 (17,'product_variation','publish','_sku','271130'),
 (271130,'product_variation','publish','_rahkaran_product_id','999'),
]
for oid,kind,status,key,value in fixtures:
 db.execute('INSERT INTO wp_posts VALUES (?,?,?)',(oid,kind,status));db.execute('INSERT INTO wp_postmeta VALUES (?,?,?)',(oid,key,value))
db.execute('INSERT INTO wp_postmeta VALUES (?,?,?)',(10,'_rahkaran_product_id','271130'))
assert sorted(r[0]for r in db.execute(query))==[10,11,12]
print('PASS SQL: exact Rahkaran metadata, distinct IDs, eligible post types/statuses; no SKU or coincidental Woo-ID substitution')
