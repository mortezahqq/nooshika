<?php
require __DIR__.'/bootstrap.php';
function route_order($contract){reset_case();$s=rkw_settings();$s['document_contract']=$contract;$s['invoice_preflight']=0;$s['invoice_settlement_id']=45;$s['inventory_id']=2;$s['payment_rules']=[['gateway'=>'WC_Gateway_SnappPay','settlement_id'=>45,'receipt_key'=>'ThirdPartyCoupon','coupon_type_id'=>5]];$GLOBALS['options'][RKW_OPT]=$s;delete_transient(RKW_Client::COOKIE_TRANSIENT);$o=order(5900000);$o->gateway='WC_Gateway_SnappPay';$o->meta['_rkw_customer_id']=55260;return$o;}
$key=openssl_pkey_new(['private_key_bits'=>2048]);$details=openssl_pkey_get_details($key);
$tests=[];
$tests['both saved contracts authenticate with old cashier and post exactly once to native SaveInvoice']=function()use($details){
 foreach(['legacy_esales','v21']as$contract){$o=route_order($contract);$posts=0;$cashier=0;
 $GLOBALS['http_handler']=function($u,$a)use($details,&$posts,&$cashier){
  check(strpos($u,'DesktopCashierLogin')===false);check(strpos($u,'ESales.svc/invoice')===false);
  if(strpos($u,'/Session')!==false)return ['code'=>200,'body'=>json_encode(['id'=>'synthetic','rsa'=>['M'=>bin2hex($details['rsa']['n']),'E'=>bin2hex($details['rsa']['e'])]])];
  if(strpos($u,'/login')!==false)return ['code'=>200,'body'=>'{}','cookies'=>[new WP_Http_Cookie(['name'=>'sg-auth-sg','value'=>'synthetic-cookie'])]];
  if(strpos($u,'/CashierLogin')!==false){$cashier++;check(json_decode($a['body'],true)===['machineName'=>'TEST-REGISTER']);return ['code'=>200,'body'=>'{}'];}
  if(strpos($u,'thirdPartyCouponTypes')!==false){check($cashier>0);return response([['Id'=>5]]);}
  check(strpos($u,'/InvoiceService.svc/SaveInvoice')!==false);$posts++;$p=json_decode($a['body'],true);check($p['document']['status']===0);check($p['document']['inventoryId']===2);check($p['document']['salesAgentId']===31);check($p['receipts'][0]['attr']===['ID'=>5,'CouponType'=>5,'Count'=>1]);check($p['receipts'][0]['amount']===59000000);check($p['payments']===[]);return response(['id'=>8234]);
 };check(RKW_Orders::send($o)===true);check($posts===1&&$cashier>0);check($o->get_meta('_rkw_doc_id')==='8234');check($GLOBALS['options'][RKW_OPT]['document_contract']===$contract);check(strpos(json_encode(RKW_Log::all()),'COUPON_INVOICE_DISPATCH')!==false);
 }
};
$tests['cashier rejection blocks all document writes']=function()use($details){$o=route_order('v21');$GLOBALS['http_handler']=function($u,$a)use($details){if(strpos($u,'/Session')!==false)return ['code'=>200,'body'=>json_encode(['id'=>'synthetic','rsa'=>['M'=>bin2hex($details['rsa']['n']),'E'=>bin2hex($details['rsa']['e'])]])];if(strpos($u,'/login')!==false)return ['code'=>200,'body'=>'{}','cookies'=>[new WP_Http_Cookie(['name'=>'sg-auth-sg','value'=>'synthetic-cookie'])]];check(strpos($u,'/CashierLogin')!==false);return ['code'=>500,'body'=>'{}'];};expect_error(RKW_Orders::send($o),'rkw_coupon_type_lookup');check(!$o->get_meta('_rkw_doc_id'));};
$tests['unknown native save result blocks a second financial POST']=function(){ $o=route_order('legacy_esales');$s=rkw_settings();set_transient(RKW_Client::COOKIE_TRANSIENT,['name'=>'sg-auth-sg','value'=>'synthetic-cookie','signature'=>RKW_Policy_Catalog::signature($s)],60);$posts=0;$GLOBALS['http_handler']=function($u,$a)use(&$posts){if(strpos($u,'thirdPartyCouponTypes')!==false)return response([['Id'=>5]]);if(strpos($u,'/CashierLogin')!==false)return ['code'=>200,'body'=>'{}'];check(strpos($u,'/InvoiceService.svc/SaveInvoice')!==false);$posts++;return new WP_Error('http_request_failed','timeout');};expect_error(RKW_Orders::send($o),'http_request_failed');expect_error(RKW_Orders::send($o),'rkw_reconcile');check($posts===1);};
$fail=0;foreach($tests as$n=>$test){try{$test();echo"PASS $n\n";}catch(Throwable$e){$fail++;echo"FAIL $n: ".$e->getMessage().' at '.$e->getLine()."\n";}}echo count($tests)." tests, $fail failed\n";exit($fail?1:0);
