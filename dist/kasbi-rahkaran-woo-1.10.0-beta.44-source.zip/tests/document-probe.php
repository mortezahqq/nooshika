<?php
require __DIR__.'/bootstrap.php';
function get_current_user_id(){return $GLOBALS['probe_user']??1;}
function dependency_reset(){
 reset_case();$GLOBALS['probe_user']=1;$GLOBALS['test_capability']=true;$GLOBALS['test_nonce']=true;$o=order(2495000);$o->id=237850;$o->gateway='cod';$o->items[0]->product->meta['_rahkaran_product_id']=100402;$GLOBALS['test_orders']=[$o->id=>$o];
 $s=rkw_settings();$s['document_contract']='legacy_esales';$s['inventory_id']=2;$s['invoice_settlement_id']=46;$s['loyalty_id']=3;$s['payment_rules']=[['gateway'=>'cod','settlement_id'=>46,'receipt_key'=>'ThirdPartyCoupon','coupon_type_id'=>6]];$GLOBALS['options'][RKW_OPT]=$s;set_transient(RKW_Client::COOKIE_TRANSIENT,['name'=>'sg-auth-sg','value'=>'synthetic','signature'=>RKW_Policy_Catalog::signature($s)],60);$_POST=[];
 $GLOBALS['dependency_policy']=['settlementPolicyID'=>46,'settlementPolicyName'=>'PRIVATE POLICY','settlementMethodGroups'=>[['settlementMethodGroupID'=>10,'minPercent'=>0,'maxPercent'=>100,'morePaymentAllowed'=>false,'settlementMethods'=>[['settlementMethodID'=>101,'settlementNatureKey'=>'ThirdPartyCoupon','isInternal'=>false,'attributes'=>[['attributeKey'=>'couponType','value'=>'6'],['attributeKey'=>'Description','value'=>'PRIVATE DESCRIPTION'],['attributeKey'=>'password','value'=>123456],['attributeKey'=>'BankAccountRef','value'=>30]]],['settlementMethodID'=>102,'settlementNatureKey'=>'EReceipt','attributes'=>[['attributeKey'=>'token','value'=>'PRIVATE TOKEN']]]]]]];
 $GLOBALS['dependency_handler']=function($url,$a){
  check($a['method']==='GET','Any business POST is forbidden for the dependency probe');check(!isset($a['body']));
  if(strpos($url,'/getSettlementPolicy?')!==false){check(strpos($url,'settlementPolicyId=46')!==false);return response($GLOBALS['dependency_policy']);}
  if(strpos($url,'/thirdPartyCouponType?')!==false){check(strpos($url,'id=6')!==false);return response(['Id'=>6,'title'=>'PRIVATE COUPON','thirdPartyName'=>'PRIVATE ORGANIZATION','isDefault'=>false]);}
  if(strpos($url,'/GetProduct?')!==false)return response(['productId'=>100402,'productName'=>'PRIVATE PRODUCT','RetailUnitRef'=>1,'fee'=>24950000]);
  if(strpos($url,'/GetRemainingQuantityInfo?')!==false)return response([['StoreID'=>2,'RemainingQuantity'=>0],['StoreID'=>3,'RemainingQuantity'=>100]]);
  if(strpos($url,'/loyaltyProgram?')!==false)return response([['Id'=>3,'name'=>'PRIVATE PROGRAM']]);
  throw new RuntimeException('Unexpected service '.$url);
 };$GLOBALS['http_handler']=$GLOBALS['dependency_handler'];return$o;
}
function dependency_done($o){$r=RKW_Document_Probe::start($o);check(!is_wp_error($r));while(!$r['done']){$before=count($GLOBALS['http_calls']);$r=RKW_Document_Probe::step($o,$r['token']);check(!is_wp_error($r));check(count($GLOBALS['http_calls'])===$before+1);}return$r;}
function dependency_state_key(){foreach(array_keys($GLOBALS['transients'])as$key)if(strpos($key,'rkw_document_probe_')===0)return$key;throw new RuntimeException('state missing');}
$tests=[];
$tests['reported COD shape reads definitions one GET per step without changing order money settings or mappings']=function(){
 $o=$GLOBALS['test_orders'][237850];$meta=$o->meta;$opts=$GLOBALS['options'];$r=RKW_Document_Probe::start($o);check(!$GLOBALS['http_calls']&&$r['total']===5);while(!$r['done']){$n=count($GLOBALS['http_calls']);$r=RKW_Document_Probe::step($o,$r['token']);check(!is_wp_error($r));check(count($GLOBALS['http_calls'])===$n+1);}
 check($r['report']['source']['amount']===24950000.0);check($r['report']['source']['receipt_key']==='ThirdPartyCoupon');check($r['report']['source']['coupon_type_id']===6);check($r['report']['definition_checks'][0]['result']['selected_key_found']===true);check($r['report']['financial_document_sent']===false);check($meta===$o->meta&&$opts===$GLOBALS['options']);check(count($GLOBALS['http_calls'])===5);
};
$tests['matching settlement methods and configuration attributes are retained without descriptions or secrets']=function(){
 $o=$GLOBALS['test_orders'][237850];$GLOBALS['dependency_policy']['settlementMethodGroups'][0]['settlementMethods'][]=['settlementMethodID'=>103,'settlementNatureKey'=>'ThirdPartyCoupon','attributes'=>[['attributeKey'=>'couponType','value'=>5]]];$r=dependency_done($o);$p=$r['report']['definition_checks'][0]['result'];check($p['matching_method_count']===2);check(count($p['groups'][0]['methods'])===3);check($p['groups'][0]['methods'][0]['attributes'][0]['configuration_value']===6.0);check($p['groups'][0]['methods'][0]['attributes'][2]['configuration_value']===null);check(strpos(json_encode($r),'PRIVATE')===false);check(strpos(json_encode($r),'123456')===false);check($p['groups'][0]['maxPercent']===100.0);
};
$tests['only a complete method schema can prove a selected nature is absent']=function(){
 $o=$GLOBALS['test_orders'][237850];$GLOBALS['dependency_policy']['settlementMethodGroups'][0]['settlementMethods']=array_slice($GLOBALS['dependency_policy']['settlementMethodGroups'][0]['settlementMethods'],1);$r=dependency_done($o);check($r['report']['definition_checks'][0]['result']['selected_key_found']===false);
 dependency_reset();$GLOBALS['dependency_policy']['settlementMethodGroups']=[['settlementMethodGroupID'=>10]];$r=dependency_done($GLOBALS['test_orders'][237850]);check($r['report']['definition_checks'][0]['result']['selected_key_found']===null);check(!$r['report']['definition_checks'][0]['result']['schema_complete']);
};
$tests['wrong policy and coupon IDs remain unverified instead of authorizing a different receipt']=function(){
 $o=$GLOBALS['test_orders'][237850];$GLOBALS['dependency_policy']['settlementPolicyID']=47;$handler=$GLOBALS['http_handler'];$GLOBALS['http_handler']=fn($u,$a)=>strpos($u,'/thirdPartyCouponType?')!==false?response(['Id'=>7]):$handler($u,$a);$r=dependency_done($o);check($r['report']['definition_checks'][0]['result']['status']==='unverified');check($r['report']['definition_checks'][1]['result']['status']==='unverified');check($r['report']['source']['coupon_type_id']===6);
};
$tests['selected-store stock is separated from other stores and null remains unknown']=function(){
 $o=$GLOBALS['test_orders'][237850];$r=dependency_done($o);$stock=$r['report']['definition_checks'][3]['result'];check($stock['store_rows']===[['store_id'=>2,'remaining_quantity'=>0.0]]);
 dependency_reset();$handler=$GLOBALS['http_handler'];$GLOBALS['http_handler']=fn($u,$a)=>strpos($u,'RemainingQuantityInfo')!==false?response([['StoreID'=>2,'RemainingQuantity'=>null]]):$handler($u,$a);$r=dependency_done($GLOBALS['test_orders'][237850]);check($r['report']['definition_checks'][3]['result']['store_rows'][0]['remaining_quantity']===null);
};
$tests['read errors preserve structural diagnostics without storing raw service messages']=function(){
 $o=$GLOBALS['test_orders'][237850];$handler=$GLOBALS['http_handler'];$GLOBALS['http_handler']=fn($u,$a)=>strpos($u,'getSettlementPolicy')!==false?new WP_Error('rkw_api','Sequence contains no elements PRIVATE TOKEN',['http_status'=>200]):$handler($u,$a);$r=dependency_done($o);$p=$r['report']['definition_checks'][0]['result'];check($p['status']==='read_error'&&$p['sequence_empty']&&$p['http_status']===200);check(strpos(json_encode($r),'PRIVATE')===false);check(strpos(json_encode($GLOBALS['transients']),'PRIVATE')===false);
};
$tests['probe tokens belong to the initiating user order and settings snapshot']=function(){
 $o=$GLOBALS['test_orders'][237850];$r=RKW_Document_Probe::start($o);$GLOBALS['probe_user']=2;expect_error(RKW_Document_Probe::step($o,$r['token']),'rkw_probe_expired');$GLOBALS['probe_user']=1;$o->total++;expect_error(RKW_Document_Probe::step($o,$r['token']),'rkw_probe_changed');check(!$GLOBALS['http_calls']);
};
$tests['expiry malformed tokens and a held probe lock do not issue a business request']=function(){
 $o=$GLOBALS['test_orders'][237850];foreach(['',[],str_repeat('x',100)]as$t)expect_error(RKW_Document_Probe::step($o,$t),'rkw_probe_token');$r=RKW_Document_Probe::start($o);$lock='rkw_probe_lock_'.hash('sha256',$r['token']);add_option($lock,'1');expect_error(RKW_Document_Probe::step($o,$r['token']),'rkw_probe_busy');check(get_option($lock)==='1');delete_option($lock);delete_transient(dependency_state_key());expect_error(RKW_Document_Probe::step($o,$r['token']),'rkw_probe_expired');check(!$GLOBALS['http_calls']);
};
$tests['settings changed during a GET cannot be blended into the previous report']=function(){
 $o=$GLOBALS['test_orders'][237850];$r=RKW_Document_Probe::start($o);$handler=$GLOBALS['http_handler'];$GLOBALS['http_handler']=function($u,$a)use($handler){$result=$handler($u,$a);$GLOBALS['options'][RKW_OPT]['inventory_id']=3;return$result;};expect_error(RKW_Document_Probe::step($o,$r['token']),'rkw_probe_changed');check(count($GLOBALS['http_calls'])===1);check($GLOBALS['transients'][dependency_state_key()]['index']===0);
};
$tests['pending and manually acknowledged orders retain their local state during inspection']=function(){
 $o=$GLOBALS['test_orders'][237850];$o->meta['_rkw_reconcile_required']=1;$o->meta['_rkw_error']='old';$o->meta[RKW_Manual_Orders::MARK]='1';$before=$o->meta;dependency_done($o);check($o->meta===$before);
};
$tests['missing product mappings never trigger fuzzy searches or customer creation']=function(){
 $o=$GLOBALS['test_orders'][237850];$o->items[0]->product->meta=[];$o->meta=[];$r=dependency_done($o);check($r['report']['source']['missing_product_mappings']===1);check(count($GLOBALS['http_calls'])===3);check($o->meta===[]);
};
$tests['at most five distinct products are inspected and skipped products are disclosed']=function(){
 $o=$GLOBALS['test_orders'][237850];$o->items=[];for($i=1;$i<=8;$i++){$item=new TestItem(10);$item->product->meta['_rahkaran_product_id']=$i;$o->items[]=$item;}$r=RKW_Document_Probe::start($o);check($r['total']===13);$state=$GLOBALS['transients'][dependency_state_key()];check($state['report']['products_not_inspected']===3);check(!$GLOBALS['http_calls']);
};
$tests['completed reports can be read again without duplicating a remote request']=function(){
 $o=$GLOBALS['test_orders'][237850];$r=dependency_done($o);$count=count($GLOBALS['http_calls']);$again=RKW_Document_Probe::step($o,$r['token']);check($again['done']&&$again['report']===$r['report']);check(count($GLOBALS['http_calls'])===$count);
};
$tests['endpoints require permission nonce and a strict internal order ID before starting']=function(){
 foreach(['test_capability','test_nonce']as$flag){dependency_reset();$GLOBALS[$flag]=false;$_POST=['order_id'=>'237850'];foreach(['ajax_start','ajax_step']as$m){try{RKW_Document_Probe::$m();check(false);}catch(TestJSON$r){check(!$r->success);}}check(!$GLOBALS['http_calls']);}
 foreach(['0','-1','237850.0',[],str_repeat('9',30)]as$id){dependency_reset();$_POST=['order_id'=>$id];try{RKW_Document_Probe::ajax_start();check(false);}catch(TestJSON$r){check(!$r->success);}check(!$GLOBALS['http_calls']);}
};
$tests['native sales orders and refunds cannot enter this invoice probe']=function(){
 $o=$GLOBALS['test_orders'][237850];$GLOBALS['options'][RKW_OPT]['order_mode']='salesorder';expect_error(RKW_Document_Probe::start($o),'rkw_probe_mode');$refund=new class extends WC_Order{function get_type(){return'shop_order_refund';}};expect_error(RKW_Document_Probe::start($refund),'rkw_probe_order');check(!$GLOBALS['http_calls']);
};
$tests['a service 401 is recorded without an automatic business retry']=function(){
 $o=$GLOBALS['test_orders'][237850];$r=RKW_Document_Probe::start($o);$GLOBALS['http_handler']=fn()=>response([],false,'private authentication error',401);$r=RKW_Document_Probe::step($o,$r['token']);check(!is_wp_error($r));check($r['completed']===1&&count($GLOBALS['http_calls'])===1);check($r['report']['definition_checks'][0]['result']['http_status']===401);
};
$tests['large method lists disclose truncation and cannot prove an absent nature']=function(){
 $o=$GLOBALS['test_orders'][237850];$methods=array_fill(0,101,['settlementMethodID'=>101,'settlementNatureKey'=>'Cash']);$methods[100]['settlementNatureKey']='ThirdPartyCoupon';$GLOBALS['dependency_policy']['settlementMethodGroups'][0]['settlementMethods']=$methods;$r=dependency_done($o);$p=$r['report']['definition_checks'][0]['result'];check($p['selected_key_found']===null&&!$p['schema_complete']);check(count($p['groups'][0]['methods'])===40&&$p['methods_not_displayed']===60);
};
$tests['named third party coupon reference IDs are visible without revealing unrelated text']=function(){
 $GLOBALS['dependency_policy']['settlementMethodGroups'][0]['settlementMethods'][0]['attributes'][]=['attributeKey'=>'ThirdPartyCouponType','value'=>'6'];
 $r=dependency_done($GLOBALS['test_orders'][237850]);$method=$r['report']['definition_checks'][0]['result']['groups'][0]['methods'][0];$attr=end($method['attributes']);check($attr['configuration_value']===6.0);check($attr['reference_configuration']===['format'=>'identifier','ids'=>[6]]);check($method['selected_type_matches_reference_ids']===true);check(strpos(json_encode($r),'PRIVATE')===false);
};
$tests['CSV JSON and array reference lists are parsed completely without choosing a replacement type']=function(){
 foreach(['1, 5,6','[1,"5",6]',[1,5,6]]as$value){dependency_reset();$GLOBALS['dependency_policy']['settlementMethodGroups'][0]['settlementMethods'][0]['attributes'][]=['attributeKey'=>'ThirdPartyCouponType','value'=>$value];$before=$GLOBALS['options'];$r=dependency_done($GLOBALS['test_orders'][237850]);$m=$r['report']['definition_checks'][0]['result']['groups'][0]['methods'][0];check(end($m['attributes'])['reference_configuration']['ids']===[1,5,6]);check($m['selected_coupon_type_id']===6&&$m['selected_type_matches_reference_ids']===true);check($GLOBALS['options']===$before);check($r['report']['source']['payment_attr_keys']===['DESCRIPTION','couponType']);}
};
$tests['a nonmatching reference is reported as a comparison and never proves a forbidden coupon']=function(){
 $GLOBALS['dependency_policy']['settlementMethodGroups'][0]['settlementMethods'][0]['attributes'][]=['attributeKey'=>'ThirdPartyCouponType','value'=>'[1,5]'];$r=dependency_done($GLOBALS['test_orders'][237850]);$m=$r['report']['definition_checks'][0]['result']['groups'][0]['methods'][0];check($m['selected_type_matches_reference_ids']===false);check(strpos($m['reference_semantics'],'does not prove')!==false);check($r['report']['source']['coupon_type_id']===6);
};
$tests['empty boolean malformed oversized and private reference definitions stay unverified']=function(){
 foreach(['',null,'True','False','PRIVATE TOKEN','5,PRIVATE','[5,{"token":"PRIVATE"}]','[5,99999999999]',str_repeat('5,',101).'6',str_repeat('5',2001)]as$value){dependency_reset();$GLOBALS['dependency_policy']['settlementMethodGroups'][0]['settlementMethods'][0]['attributes'][]=['attributeKey'=>'ThirdPartyCouponType','value'=>$value];$r=dependency_done($GLOBALS['test_orders'][237850]);$m=$r['report']['definition_checks'][0]['result']['groups'][0]['methods'][0];check($m['selected_type_matches_reference_ids']===null);check(strpos(json_encode($r),'PRIVATE')===false);}
};
$tests['the reported policy45 count flag is retained but never injected into a financial request']=function(){
 $raw=['settlementPolicyID'=>45,'settlementMethodGroups'=>[['settlementMethodGroupID'=>5,'settlementMethods'=>[['settlementMethodID'=>8,'settlementNatureKey'=>'ThirdPartyCoupon','attributes'=>[['attributeKey'=>'ThirdPartyCouponType','value'=>'5'],['attributeKey'=>'Count','value'=>'True']]]]]]];
 $fn=new ReflectionMethod(RKW_Document_Probe::class,'policy');$fn->setAccessible(true);$result=$fn->invoke(null,$raw,45,'ThirdPartyCoupon',5);$m=$result['groups'][0]['methods'][0];check($m['selected_type_matches_reference_ids']===true&&$m['attributes'][1]['configuration_value']==='True');check(!$GLOBALS['http_calls']);$o=$GLOBALS['test_orders'][237850];$p=RKW_Payment::resolve($o,rkw_settings());$entries=RKW_Payment::receipts($o,24950000,$p);check(array_keys($entries[0]['attr'])===['DESCRIPTION','couponType']);
};
$fail=0;foreach($tests as$name=>$test){dependency_reset();try{$test();echo 'PASS '.$name."\n";}catch(Throwable$e){$fail++;echo 'FAIL '.$name.': '.$e->getMessage().' at '.$e->getLine()."\n";}}echo count($tests).' tests, '.$fail." failed\n";exit($fail?1:0);
