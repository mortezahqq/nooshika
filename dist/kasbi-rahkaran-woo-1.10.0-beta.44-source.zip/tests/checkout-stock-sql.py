"""Exercise the production hold query on CPT and HPOS data, including stale compatibility meta."""
import os
import re
import sqlite3
import subprocess
from pathlib import Path

root = Path(__file__).resolve().parents[1]
php = os.environ.get('RKW_TEST_PHP', 'php')
for mode in ('classic', 'hpos'):
    db = sqlite3.connect(':memory:')
    db.create_function('REGEXP', 2, lambda pattern, value: bool(re.search(pattern, str(value or ''))))
    db.executescript('''
        CREATE TABLE wp_posts (ID INTEGER, post_type TEXT, post_status TEXT);
        CREATE TABLE wp_postmeta (post_id INTEGER, meta_key TEXT, meta_value TEXT);
        CREATE TABLE wp_wc_orders (id INTEGER, type TEXT, status TEXT);
        CREATE TABLE wp_wc_orders_meta (order_id INTEGER, meta_key TEXT, meta_value TEXT);
        CREATE TABLE wp_woocommerce_order_items (order_item_id INTEGER, order_id INTEGER, order_item_type TEXT);
        CREATE TABLE wp_woocommerce_order_itemmeta (order_item_id INTEGER, meta_key TEXT, meta_value TEXT);
    ''')
    meta = 'wp_postmeta' if mode == 'classic' else 'wp_wc_orders_meta'
    for order_id in range(1, 16):
        kind = 'shop_order_refund' if order_id == 7 else 'shop_order'
        status = 'trash' if order_id == 8 else 'wc-processing'
        db.execute('INSERT INTO wp_posts VALUES (?,?,?)', (order_id, kind, status))
        db.execute('INSERT INTO wp_wc_orders VALUES (?,?,?)', (order_id, kind, status))
        db.execute('INSERT INTO wp_woocommerce_order_items VALUES (?,?,?)', (order_id, order_id, 'line_item'))
        variation = '227225' if order_id == 10 else ('0' if order_id == 11 else '227224')
        product = '227224' if order_id == 11 else '900'
        reduced = '0' if order_id == 9 else '1'
        for key, value in [('_variation_id', variation), ('_product_id', product), ('_reduced_stock', reduced)]:
            db.execute('INSERT INTO wp_woocommerce_order_itemmeta VALUES (?,?,?)', (order_id, key, value))
    for row in [
        (2, '_rkw_doc_id', '123'),
        (3, '_rkw_manual_recorded', '1'),
        (4, '_rkw_doc_id', '124'), (4, '_rkw_reconcile_required', '1'),
        (5, '_rkw_doc_id', 'OK'),
        (13, '_rkw_doc_id', '0'),
        (14, '_rkw_doc_id', '125'), (14, '_rkw_reconcile_required', '0'),
        (15, '_rkw_doc_id', '126'), (15, '_rkw_doc_id', 'OK'),
    ]:
        db.execute(f'INSERT INTO {meta} VALUES (?,?,?)', row)
    if mode == 'hpos':
        # CPT compatibility metadata is stale; it must never release an HPOS hold.
        db.execute("INSERT INTO wp_postmeta VALUES (1,'_rkw_doc_id','999')")
        db.execute("INSERT INTO wp_postmeta VALUES (12,'_rkw_manual_recorded','1')")
    sql = subprocess.check_output([php, '-n', str(root / 'tests/checkout-stock-sql.php'), mode], text=True)
    result = list(db.execute(sql))
    ids = {row[0] for row in result}
    assert ids == {1, 4, 5, 11, 12, 13, 15}, (mode, result)
    assert {row[0] for row in result if row[3]} == {4, 5, 13, 15}
    print(f'PASS {mode}: only actual reductions for this variation/simple product; confirmed/manual/self/refund/trash/zero/other-size excluded; uncertain holds retained')
