<?php
require __DIR__.'/bootstrap.php';
function reference_reset(){reset_case();$GLOBALS['test_nonce']=true;$GLOBALS['test_capability']=true;$_POST=['invoice_id'=>'30577','contract'=>'legacy_esales'];}
function reference_ajax(){try{RKW_Document_Probe::ajax_reference();throw new RuntimeException('missing JSON');}catch(TestJSON $r){return$r;}}
function reference_invoice(){return['id'=>30577,'number'=>917,'settlementPolicyId'=>45,'customerName'=>'PRIVATE CUSTOMER','description'=>'PRIVATE ADDRESS','receipts'=>[['settlementNature'=>'ThirdPartyCoupon','amount'=>36950000,'details'=>['count'=>1,'couponType'=>5,'number'=>'PRIVATE SERIAL','cardNumber'=>'PRIVATE CARD','description'=>'PRIVATE DESCRIPTION','token'=>'PRIVATE TOKEN','customerId'=>45678]]],'payments'=>[]];}
$tests=[];
$tests['both readers use exactly one fixed GET and preserve all local financial state']=function(){
 foreach(['legacy_esales','v21']as$contract){reference_reset();$_POST['contract']=$contract;$before=$GLOBALS['options'];$GLOBALS['http_handler']=function($u,$a)use($contract){check($a['method']==='GET'&&!isset($a['body']));check(strpos($u,$contract==='legacy_esales'?'/Services/Retail/ESales.svc/invoice?id=30577':'/Retail/Api/RetailDocuments/InvoiceService.svc/GetInvoice?invoiceId=30577')!==false);return response(reference_invoice());};$r=reference_ajax();check($r->success&&$r->data['report']['identity_verified']);check($r->data['report']['third_party_coupon_found']);check($r->data['report']['response_is_post_contract']===false);check(count($GLOBALS['http_calls'])===1&&$before===$GLOBALS['options']);}
};
$tests['only voucher type and count values are shown while serials customer and bank data are omitted']=function(){
 $GLOBALS['http_handler']=fn()=>response(reference_invoice());$r=reference_ajax();$text=json_encode($r->data);check(strpos($text,'PRIVATE')===false&&strpos($text,'45678')===false);$fields=$r->data['report']['receipts'][0]['shape']['fields'];$details=array_values(array_filter($fields,fn($f)=>$f['key']==='details'))[0]['shape']['fields'];check($details[0]['numeric_value']===1.0&&$details[1]['numeric_value']===5.0);check(!isset($details[2]['numeric_value']));
};
$tests['legacy envelopes and attribute lists retain shape without turning response fields into a write']=function(){
 $raw=['document'=>['id'=>30577,'settlementPolicyId'=>45],'payments'=>[['key'=>'ThirdPartyCoupon','amount'=>100,'attr'=>[['attributeKey'=>'Count','value'=>'2'],['attributeKey'=>'ThirdPartyCouponType','value'=>['Id'=>5,'title'=>'PRIVATE TYPE']],['attributeKey'=>'Description','value'=>'PRIVATE DESCRIPTION']]]]];$GLOBALS['http_handler']=fn()=>response($raw);$r=reference_ajax();$fields=$r->data['report']['receipts'][0]['shape']['fields'];$attrs=end($fields)['shape']['fields'];check($attrs[0]['numeric_value']===2.0&&$attrs[1]['reference_id']===5);check(strpos(json_encode($r->data),'PRIVATE')===false);check(count($GLOBALS['http_calls'])===1);
};
$tests['a mismatched or missing document ID never confirms a receipt or imports a mapping']=function(){
 foreach([123,null]as$id){$GLOBALS['http_handler']=function()use($id){$r=reference_invoice();$r['id']=$id;return response($r);};$r=reference_ajax();check(!$r->data['report']['identity_verified']);check($r->data['report']['status']==='unverified'&&!isset($r->data['report']['receipts']));check(strpos(json_encode($r->data),'PRIVATE')===false);}
};
$tests['invalid permissions nonce identifiers paths and API versions cannot perform any read']=function(){
 foreach(['test_nonce','test_capability']as$flag){reference_reset();$GLOBALS[$flag]=false;check(!reference_ajax()->success&&!$GLOBALS['http_calls']);}
 foreach(['',[],0,'0','-1','30577.0',str_repeat('9',30),'30577&customerId=1']as$id){reference_reset();$_POST['invoice_id']=$id;check(!reference_ajax()->success&&!$GLOBALS['http_calls']);}
 reference_reset();$_POST['contract']='https://attacker.invalid/';check(!reference_ajax()->success&&!$GLOBALS['http_calls']);reference_reset();$GLOBALS['options'][RKW_OPT]['api']='v19';check(!reference_ajax()->success&&!$GLOBALS['http_calls']);
};
$tests['HTTP and business errors are sanitized and never trigger a financial or authentication retry']=function(){
 foreach([401,500,200]as$code){reference_reset();$GLOBALS['http_handler']=fn()=>response([],false,'PRIVATE ERROR',$code);$r=reference_ajax();check($r->success&&$r->data['report']['status']==='read_error');check(count($GLOBALS['http_calls'])===1);check(strpos(json_encode($r->data),'PRIVATE')===false);}
};
$tests['changed connections cannot blend receipts from a previous server into a result']=function(){
 $GLOBALS['http_handler']=function(){$GLOBALS['options'][RKW_OPT]['ip']='changed.example.invalid';return response(reference_invoice());};$r=reference_ajax();check(!$r->success&&count($GLOBALS['http_calls'])===1);check(strpos(json_encode($r->data),'36950000')===false);
};
$tests['malformed and oversized receipt lists remain bounded and never imply voucher success']=function(){
 $raw=reference_invoice();$raw['receipts']=array_fill(0,25,['key'=>'EReceipt','amount'=>10,'details'=>array_fill_keys(array_map(fn($i)=>'field'.$i,range(1,50)),'PRIVATE')]);$GLOBALS['http_handler']=fn()=>response($raw);$r=reference_ajax();$p=$r->data['report'];check(count($p['receipts'])===20&&$p['receipts_schema']['truncated']&&!$p['third_party_coupon_found']);check(strpos(json_encode($r->data),'PRIVATE')===false);
};
function number_ajax(){try{RKW_Document_Probe::ajax_reference_number();throw new RuntimeException('missing JSON');}catch(TestJSON $r){return$r;}}
$tests['null empty array empty object and missing result are distinguished without exposing payloads']=function(){
 $cases=[['result'=>null,'reason'=>'null_result','type'=>'null'],['result'=>[],'reason'=>'empty_result','type'=>'array'],['result'=>(object)[],'reason'=>'empty_document_object','type'=>'object']];
 foreach($cases as$c){$GLOBALS['http_handler']=fn()=>response($c['result']);$r=reference_ajax();check($r->data['report']['reason']===$c['reason']);check($r->data['report']['response_shape']['result_type']===$c['type']);check($r->data['report']['requested_id']===30577);}
 $GLOBALS['http_handler']=fn()=>['code'=>200,'body'=>'{"private":"PRIVATE","metadata":{"isSuccessfull":true}}'];$r=reference_ajax();check($r->data['report']['reason']==='missing_result_envelope');check(!$r->data['report']['response_shape']['has_result']);check(strpos(json_encode($r->data),'PRIVATE')===false);
};
$tests['a singleton result still needs matching ID while multi-document lists never pick the first']=function(){
 $GLOBALS['http_handler']=fn()=>response([reference_invoice()]);$r=reference_ajax();check($r->data['report']['identity_verified']);
 $GLOBALS['http_handler']=fn()=>response([reference_invoice(),reference_invoice()]);$r=reference_ajax();check($r->data['report']['reason']==='unexpected_document_list'&&!$r->data['report']['identity_verified']);
};
$tests['invalid JSON false metadata and HTTP errors retain safe envelope diagnostics only']=function(){
 foreach([['code'=>200,'body'=>'<html>PRIVATE</html>'],response(null,false,'PRIVATE'),response(null,true,'',500)]as$response){$GLOBALS['http_handler']=fn()=>$response;$r=reference_ajax();check($r->data['report']['status']==='read_error');check(isset($r->data['report']['response_shape']['http_status']));check(strpos(json_encode($r->data),'PRIVATE')===false);}
};
$tests['number lookup uses documented pagination and matches number rather than ID']=function(){
 $_POST=['invoice_number'=>'۳۰۵۷۷','page'=>'1'];$before=$GLOBALS['options'];$GLOBALS['http_handler']=function($u,$a){check($a['method']==='GET'&&!isset($a['body']));check(strpos($u,'GetInvoicesList?page=1&count=100')!==false);return response([['id'=>30577,'number'=>'20'],['id'=>123006,'number'=>'30577','netPrice'=>15000000,'customerName'=>'PRIVATE','documentDate'=>'2026-10-20T00:00:00','settlementPolicyId'=>45],['id'=>101007,'number'=>'030577','netPrice'=>10000000]]);};$r=number_ajax();check($r->success&&count($r->data['matches'])===2);check($r->data['matches'][0]['id']===123006&&$r->data['matches'][1]['id']===101007);check($r->data['scanned']===3&&$r->data['has_more']);check(strpos(json_encode($r->data),'PRIVATE')===false);check($before===$GLOBALS['options']&&count($GLOBALS['http_calls'])===1);
};
$tests['short pages are not proof of exhaustion and repeated ID pages have stable fingerprints']=function(){
 $_POST=['invoice_number'=>'30577','page'=>'1'];$GLOBALS['http_handler']=fn()=>response([['id'=>123006,'number'=>'1'],['id'=>123007,'number'=>'2']]);$a=number_ajax();check($a->data['has_more']);$_POST['page']='2';$_POST['connection']=$a->data['connection'];$GLOBALS['http_handler']=fn()=>response([['id'=>123007,'number'=>'2'],['id'=>123006,'number'=>'1']]);$b=number_ajax();check($a->data['page_fingerprint']===$b->data['page_fingerprint']);$GLOBALS['http_handler']=fn()=>response([]);$c=number_ajax();check(!$c->data['has_more']&&$c->data['scope']==='visible_invoices_only');
};
$tests['missing malformed and null list responses never masquerade as an empty invoice list']=function(){
 $_POST=['invoice_number'=>'30577','page'=>'1'];foreach([null,(object)[],true,['items'=>'PRIVATE']]as$result){$GLOBALS['http_handler']=fn()=>response($result);check(!number_ajax()->success);} $GLOBALS['http_handler']=fn()=>['code'=>200,'body'=>'{"metadata":{"isSuccessfull":true}}'];check(!number_ajax()->success);
};
$tests['number reader requires access and valid pagination before reading']=function(){
 foreach(['test_nonce','test_capability']as$flag){reference_reset();$_POST=['invoice_number'=>'30577','page'=>'1'];$GLOBALS[$flag]=false;check(!number_ajax()->success&&!$GLOBALS['http_calls']);}
 foreach([[],null,'','1&x=2','0']as$n){reference_reset();$_POST=['invoice_number'=>$n,'page'=>'1'];check(!number_ajax()->success&&!$GLOBALS['http_calls']);}
 foreach(['0','1001','-1',[], '2']as$page){reference_reset();$_POST=['invoice_number'=>'30577','page'=>$page];check(!number_ajax()->success&&!$GLOBALS['http_calls']);}
};
$tests['connection changes and read errors never continue a number search with unrelated data']=function(){
 $_POST=['invoice_number'=>'30577','page'=>'1'];$GLOBALS['http_handler']=function(){$GLOBALS['options'][RKW_OPT]['ip']='changed.example.invalid';return response([]);};check(!number_ajax()->success);
 reference_reset();$_POST=['invoice_number'=>'30577','page'=>'1'];$GLOBALS['http_handler']=fn()=>response(null,false,'PRIVATE',401);check(!number_ajax()->success&&count($GLOBALS['http_calls'])===1);
};
$fail=0;foreach($tests as$name=>$test){reference_reset();try{$test();echo'PASS '.$name."\n";}catch(Throwable$e){$fail++;echo'FAIL '.$name.': '.$e->getMessage().' at '.$e->getLine()."\n";}}echo count($tests).' tests, '.$fail." failed\n";exit($fail?1:0);
