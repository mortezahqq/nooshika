<?php
define('RKW_CHECKOUT_STOCK_FIXTURES_ONLY',true);
require __DIR__.'/checkout-stock.php';
guard_reset();
echo RKW_Checkout_Stock::reductions_sql(array(227224),6,'hpos'===($argv[1]??''));
