<?php
/** Export the production mapping query for SQLite fixture validation. */
define( 'RKW_CATALOG_FIXTURES_ONLY', true );
require __DIR__ . '/catalog-runner.php';
class MappingSqlDB extends CatalogDB {
 public $generated='';
 function prepare($sql,...$args){$i=0;return preg_replace_callback('/%s/',function()use(&$i,$args){return "'".str_replace("'","''",(string)$args[$i++])."'";},$sql);}
 function get_col($sql){$this->generated=$sql;return [];}
}
$GLOBALS['wpdb']=new MappingSqlDB;$GLOBALS['products']=[];
$method=new ReflectionMethod(RKW_Sync::class,'find_product_id');$method->setAccessible(true);
$method->invoke(null,['id'=>271130,'code'=>'BARCODE'],rkw_settings());
echo $GLOBALS['wpdb']->generated;
