<?php
require __DIR__ . '/bootstrap.php';
class StockOrderUtil { public static $hpos=false; static function custom_orders_table_usage_is_enabled(){return self::$hpos;} }
class_alias(StockOrderUtil::class,'Automattic\WooCommerce\Utilities\OrderUtil');
class StockRouteException extends Exception { public $error; function __construct($error,$message,$code){$this->error=$error;parent::__construct($message,$code);} }
class_alias(StockRouteException::class,'Automattic\WooCommerce\StoreApi\Exceptions\RouteException');
class CheckoutStockDB extends TestDB {
 public $prefix='wp_',$snapshots=[],$legacy=[],$calls=0,$fail=false,$queries=[];
 function prepare($sql,...$args){if(count($args)===1&&is_array($args[0]))$args=$args[0];$i=0;return preg_replace_callback('/%[sd]/',function($m)use(&$i,$args){$v=$args[$i++];return$m[0]==='%d'?(string)(int)$v:"'".str_replace("'","''",(string)$v)."'";},$sql);}
 function get_results($sql,$format){$this->queries[]=$sql;if(strpos($sql,'woocommerce_order_items')!==false){$this->calls++;if($this->fail){$this->last_error='synthetic';return null;}return$this->snapshots?array_shift($this->snapshots):[];}preg_match("/o.meta_value='([0-9]+)'/",$sql,$m);return$this->legacy[(int)($m[1]??0)]??[];}
}
class CheckoutStockProduct extends TestProduct {
 public $id=227224,$owner=227224,$qty=3,$backorders=false,$managed=true,$name='LUMA مشکی M';
 function get_id(){return$this->id;}function get_stock_managed_by_id(){return$this->owner;}function managing_stock(){return$this->managed;}function backorders_allowed(){return$this->backorders;}function get_name(){return$this->name;}
}
class CheckoutStockOrder extends WC_Order { public $meta_saves=0;function save_meta_data(){$this->meta_saves++;} }
function wc_get_held_stock_quantity($p,$exclude=0){$total=0;foreach($GLOBALS['held']as$id=>$products)if((int)$id!==(int)$exclude)$total+=$products[$p->get_stock_managed_by_id()]??0;return$total;}
function wc_reserve_stock_for_order($o){$GLOBALS['native_reservations']++;if($GLOBALS['reserve_error'])throw new Exception('private');$rows=[];foreach($o->get_items()as$i){$p=$i->get_product();if($p&&$p->managing_stock()&&!$p->backorders_allowed())$rows[$p->get_stock_managed_by_id()]=($rows[$p->get_stock_managed_by_id()]??0)+$i->get_quantity();}$GLOBALS['held'][$o->get_id()]=$rows;}
function wc_release_stock_for_order($o){unset($GLOBALS['held'][$o->get_id()]);$GLOBALS['released'][]=$o->get_id();}
function wc_add_notice($message,$type='success'){$GLOBALS['notices'][$type][]=$message;}
function guard_reset(){reset_case();$GLOBALS['wpdb']=new CheckoutStockDB;StockOrderUtil::$hpos=false;$GLOBALS['held']=[];$GLOBALS['released']=[];$GLOBALS['native_reservations']=0;$GLOBALS['reserve_error']=false;$GLOBALS['notices']=[];$o=new CheckoutStockOrder;$o->id=237854;$p=new CheckoutStockProduct;$p->meta['_rahkaran_product_id']=262807;$i=new TestItem(2890000);$i->product=$p;$o->items=[$i];$o->total=2890000;$GLOBALS['stock_order']=$o;$GLOBALS['options'][RKW_OPT]['inventory_id']=2;$GLOBALS['http_handler']=function($url,$args){check($args['method']==='GET');check(strpos($url,'GetRemainingQuantityInfo')!==false);check($args['timeout']===5);return response([['StoreID'=>2,'RemainingQuantity'=>3]]);};}
function reduction($iid=1,$oid=777,$qty=1,$uncertain=0){return['item_id'=>$iid,'order_id'=>$oid,'quantity'=>$qty,'uncertain'=>$uncertain];}
function guard_rows($rows){$GLOBALS['http_handler']=fn($u,$a)=>response($rows);}
if(defined('RKW_CHECKOUT_STOCK_FIXTURES_ONLY'))return;
$tests=[];
$tests['reported transfer rejects stale Woo stock three against live central stock zero before any gateway call']=function(){
 $o=$GLOBALS['stock_order'];$p=$o->items[0]->product;guard_rows([['StoreID'=>2,'RemainingQuantity'=>0],['StoreID'=>6,'RemainingQuantity'=>3]]);wc_reserve_stock_for_order($o);$gateway=0;try{RKW_Checkout_Stock::classic($o);$gateway++;check(false);}catch(Exception$e){check(strpos($e->getMessage(),'موجودی کافی')!==false);}check($gateway===0&&$p->qty===3&&!$p->backorders);check($GLOBALS['released']===[237854]);check((float)$o->meta[RKW_Checkout_Stock::EVIDENCE]['checks'][0]['erp_remaining']===0.0);check(count($GLOBALS['http_calls'])===1);
};
$tests['available live stock passes with unchanged quantities prices payment and document state']=function(){
 $o=$GLOBALS['stock_order'];$before=serialize($o->items);$meta=$o->meta;check(RKW_Checkout_Stock::check($o)===true);check(serialize($o->items)===$before&&$o->total===2890000&&$o->gateway==='test_bank');unset($o->meta[RKW_Checkout_Stock::EVIDENCE]);check($o->meta===$meta);check($o->meta_saves===1&&count($GLOBALS['http_calls'])===1);
};
$tests['warehouse from document overrides catalog warehouse pool']=function(){
 $GLOBALS['options'][RKW_OPT]['store_ids']='2,6';guard_rows([['StoreID'=>2,'RemainingQuantity'=>0],['StoreID'=>6,'RemainingQuantity'=>50]]);expect_error(RKW_Checkout_Stock::check($GLOBALS['stock_order']),'rkw_checkout_stock_shortage');
};
$tests['one explicit catalog warehouse is allowed only when document warehouse is unset']=function(){
 $GLOBALS['options'][RKW_OPT]['inventory_id']=0;$GLOBALS['options'][RKW_OPT]['store_ids']='2';check(RKW_Checkout_Stock::check($GLOBALS['stock_order'])===true);$GLOBALS['options'][RKW_OPT]['store_ids']='2,6';expect_error(RKW_Checkout_Stock::check($GLOBALS['stock_order']),'rkw_checkout_stock_config');check(count($GLOBALS['http_calls'])===1);
};
$tests['missing duplicate malformed null empty and nonfinite warehouse quantities never authorize payment']=function(){
 foreach([[],null,false,['unexpected'=>1],[['StoreID'=>6,'RemainingQuantity'=>8]],[['StoreID'=>2,'RemainingQuantity'=>null]],[['StoreID'=>'bad','RemainingQuantity'=>3]],[['StoreID'=>2,'RemainingQuantity'=>3],['StoreID'=>2,'RemainingQuantity'=>3]],[['StoreID'=>2,'RemainingQuantity'=>'1e999']]]as$rows){guard_reset();guard_rows($rows);check(is_wp_error(RKW_Checkout_Stock::check($GLOBALS['stock_order'])));check($GLOBALS['stock_order']->items[0]->product->qty===3);}
};
$tests['timeout or upstream private error fails closed without exposing credentials or raw message']=function(){
 $GLOBALS['http_handler']=fn()=>new WP_Error('http_request_failed','PRIVATE PASSWORD TOKEN');$r=RKW_Checkout_Stock::check($GLOBALS['stock_order']);expect_error($r,'rkw_checkout_stock_service');check(strpos($r->get_error_message(),'PRIVATE')===false);check(strpos(json_encode(RKW_Log::all()),'PRIVATE')===false);
};
$tests['new requests always read live stock and never reuse a recent success']=function(){
 $o=$GLOBALS['stock_order'];check(RKW_Checkout_Stock::check($o)===true);guard_rows([['StoreID'=>2,'RemainingQuantity'=>0]]);expect_error(RKW_Checkout_Stock::check($o),'rkw_checkout_stock_shortage');check(count($GLOBALS['http_calls'])===2);
};
$tests['other native reservations count while the current order hold is excluded']=function(){
 $o=$GLOBALS['stock_order'];$GLOBALS['held']=[237854=>[227224=>1],777=>[227224=>3]];expect_error(RKW_Checkout_Stock::check($o),'rkw_checkout_stock_shortage');$GLOBALS['held'][777][227224]=2;check(RKW_Checkout_Stock::check($o)===true);
};
$tests['unexported paid reductions protect stock even if a sync has replenished the Woo value']=function(){
 $o=$GLOBALS['stock_order'];$GLOBALS['wpdb']->snapshots=[[reduction(1,777,3)],[reduction(1,777,3)]];expect_error(RKW_Checkout_Stock::check($o),'rkw_checkout_stock_shortage');check($o->meta[RKW_Checkout_Stock::EVIDENCE]['checks'][0]['other_unexported_reductions']===3.0);
};
$tests['distinct old and new holds are merged per item across the ERP read']=function(){
 $o=$GLOBALS['stock_order'];$GLOBALS['wpdb']->snapshots=[[reduction(1,777,2)],[reduction(2,888,1)]];expect_error(RKW_Checkout_Stock::check($o),'rkw_checkout_stock_shortage');check($o->meta[RKW_Checkout_Stock::EVIDENCE]['checks'][0]['other_unexported_reductions']===3.0);
};
$tests['same item snapshots do not double subtract and partial refunds use remaining reduced quantity']=function(){
 $o=$GLOBALS['stock_order'];$GLOBALS['wpdb']->snapshots=[[reduction(1,777,2)],[reduction(1,777,1)]];check(RKW_Checkout_Stock::check($o)===true);check($o->meta[RKW_Checkout_Stock::EVIDENCE]['checks'][0]['other_unexported_reductions']===2.0);
};
$tests['only a single confirmed legacy invoice releases its local paid hold']=function(){
 $o=$GLOBALS['stock_order'];$db=$GLOBALS['wpdb'];$db->snapshots=[[reduction(1,777,3)],[reduction(1,777,3)]];$db->legacy[777]=[['invoice_id'=>'123']];check(RKW_Checkout_Stock::check($o)===true);
 foreach([[['invoice_id'=>'']],[['invoice_id'=>'OK']],[['invoice_id'=>'123'],['invoice_id'=>'124']]]as$legacy){guard_reset();$db=$GLOBALS['wpdb'];$db->snapshots=[[reduction(1,777,3)],[reduction(1,777,3)]];$db->legacy[777]=$legacy;expect_error(RKW_Checkout_Stock::check($GLOBALS['stock_order']),'rkw_checkout_stock_shortage');}
};
$tests['unresolved own writes retain reductions even when an old confirmed legacy record exists']=function(){
 $db=$GLOBALS['wpdb'];$db->snapshots=[[reduction(1,777,3,1)],[reduction(1,777,3,1)]];$db->legacy[777]=[['invoice_id'=>'123']];expect_error(RKW_Checkout_Stock::check($GLOBALS['stock_order']),'rkw_checkout_stock_shortage');
};
$tests['DB failures malformed reductions and overflow cannot silently remove holds']=function(){
 foreach(['db','invalid','overflow']as$kind){guard_reset();$db=$GLOBALS['wpdb'];if($kind==='db')$db->fail=true;else$db->snapshots=[$kind==='invalid'?[reduction(1,777,'bad')]:array_fill(0,501,reduction())];expect_error(RKW_Checkout_Stock::check($GLOBALS['stock_order']),'rkw_checkout_local_stock');check(!$GLOBALS['http_calls']);}
};
$tests['quantities aggregate repeated ERP lines into one live request']=function(){
 $o=$GLOBALS['stock_order'];$o->items[0]->qty=2;$o->items[]=clone$o->items[0];expect_error(RKW_Checkout_Stock::check($o),'rkw_checkout_stock_shortage');check(count($GLOBALS['http_calls'])===1);check($o->meta[RKW_Checkout_Stock::EVIDENCE]['checks'][0]['requested']===4.0);
};
$tests['three variants use independent own mappings and a parent identifier is never inherited']=function(){
 $o=$GLOBALS['stock_order'];$o->items=[];for($i=0;$i<3;$i++){$item=new TestItem(10);$p=new CheckoutStockProduct;$p->id=$p->owner=227224+$i;$p->meta['_rahkaran_product_id']=262807+$i;$item->product=$p;$o->items[]=$item;}check(RKW_Checkout_Stock::check($o)===true);check(count($GLOBALS['http_calls'])===3);check(strpos($GLOBALS['http_calls'][2][0],'productId=262809')!==false);
};
$tests['legacy numeric SKU is accepted only in explicit ID mode']=function(){
 $p=$GLOBALS['stock_order']->items[0]->product;$p->meta=[];$p->sku='262807';check(RKW_Checkout_Stock::check($GLOBALS['stock_order'])===true);check(!$GLOBALS['http_calls']);$GLOBALS['options'][RKW_OPT]['key_field']='id';check(RKW_Checkout_Stock::check($GLOBALS['stock_order'])===true);check(count($GLOBALS['http_calls'])===1);
};
$tests['disabled guard API19 unmapped unmanaged and intentional backorders retain their behavior']=function(){
 foreach(['disabled','v19','unmapped','unmanaged','backorders']as$kind){guard_reset();$p=$GLOBALS['stock_order']->items[0]->product;if($kind==='disabled')$GLOBALS['options'][RKW_OPT]['checkout_stock_guard']=0;if($kind==='v19')$GLOBALS['options'][RKW_OPT]['api']='v19';if($kind==='unmapped')$p->meta=[];if($kind==='unmanaged')$p->managed=false;if($kind==='backorders')$p->backorders=true;check(RKW_Checkout_Stock::check($GLOBALS['stock_order'])===true);RKW_Checkout_Stock::pay_again($GLOBALS['stock_order']);check(!$GLOBALS['http_calls']&&$GLOBALS['native_reservations']===0);}
};
$tests['Blocks produces a conflict error before payment and releases only its own reservation']=function(){
 $o=$GLOBALS['stock_order'];$GLOBALS['held']=[237854=>[227224=>1],777=>[227224=>1]];guard_rows([['StoreID'=>2,'RemainingQuantity'=>0]]);try{RKW_Checkout_Stock::blocks($o);check(false);}catch(StockRouteException$e){check($e->getCode()===409&&$e->error==='rkw_checkout_stock_shortage');}check(!isset($GLOBALS['held'][237854])&&isset($GLOBALS['held'][777]));
};
$tests['order pay adds an error notice outside the native exception handler and never calls the gateway']=function(){
 $o=$GLOBALS['stock_order'];guard_rows([['StoreID'=>2,'RemainingQuantity'=>0]]);RKW_Checkout_Stock::pay_again($o);check($GLOBALS['native_reservations']===1);check(count($GLOBALS['notices']['error'])===1);check(!isset($GLOBALS['held'][237854]));$gateway=0;if(empty($GLOBALS['notices']['error']))$gateway++;check($gateway===0);
};
$tests['order pay renews its reservation before checking other holds and allows valid stock']=function(){
 $o=$GLOBALS['stock_order'];RKW_Checkout_Stock::pay_again($o);check($GLOBALS['native_reservations']===1&&!$GLOBALS['notices']);check($GLOBALS['held'][237854][227224]===1);
};
$tests['native reservation exceptions on order pay become safe error notices']=function(){
 $GLOBALS['reserve_error']=true;RKW_Checkout_Stock::pay_again($GLOBALS['stock_order']);check(count($GLOBALS['notices']['error'])===1);check(strpos($GLOBALS['notices']['error'][0],'private')===false);check(!$GLOBALS['http_calls']);
};
$tests['settings changed during the read cannot authorize the previous warehouse']=function(){
 $handler=$GLOBALS['http_handler'];$GLOBALS['http_handler']=function($u,$a)use($handler){$r=$handler($u,$a);$GLOBALS['options'][RKW_OPT]['inventory_id']=6;return$r;};expect_error(RKW_Checkout_Stock::check($GLOBALS['stock_order']),'rkw_checkout_stock_changed');
};
$tests['invalid explicit mapping and nonnumeric filtered quantities cannot bypass the check']=function(){
 $o=$GLOBALS['stock_order'];$o->items[0]->product->meta['_rahkaran_product_id']='bad';expect_error(RKW_Checkout_Stock::check($o),'rkw_checkout_product_mapping');$o->items[0]->product->meta['_rahkaran_product_id']=262807;$GLOBALS['filters']['woocommerce_order_item_quantity']=[10=>[fn()=>'1oops']];expect_error(RKW_Checkout_Stock::check($o),'rkw_checkout_quantity');unset($GLOBALS['filters']['woocommerce_order_item_quantity']);check(!$GLOBALS['http_calls']);
};
$tests['Blocks existing-order payment renews a native hold without doubling an existing one']=function(){
 $o=$GLOBALS['stock_order'];RKW_Checkout_Stock::blocks($o);check($GLOBALS['held'][237854][227224]===1);RKW_Checkout_Stock::blocks($o);check($GLOBALS['held'][237854][227224]===1&&$GLOBALS['native_reservations']===2);check(count($GLOBALS['http_calls'])===2);
};
$tests['a second simultaneous shopper sees the first accepted native hold despite stale Woo stock']=function(){
 $a=$GLOBALS['stock_order'];$b=clone$a;$b->id=237855;guard_rows([['StoreID'=>2,'RemainingQuantity'=>1]]);wc_reserve_stock_for_order($a);RKW_Checkout_Stock::classic($a);wc_reserve_stock_for_order($b);try{RKW_Checkout_Stock::classic($b);check(false);}catch(Exception$e){check(strpos($e->getMessage(),'موجودی کافی')!==false);}check(isset($GLOBALS['held'][237854])&&!isset($GLOBALS['held'][237855]));
};
$tests['guard is independent of cron publication setting and automatic invoice queue']=function(){
 $GLOBALS['options'][RKW_OPT]['cron_interval']='off';$GLOBALS['options'][RKW_OPT]['auto_product_on_save']=0;$GLOBALS['options'][RKW_OPT]['order_enabled']=0;check(RKW_Checkout_Stock::check($GLOBALS['stock_order'])===true);check(count($GLOBALS['http_calls'])===1);
};
$tests['all payment hooks register after the standard reservation without registering payment callbacks']=function(){
 RKW_Checkout_Stock::init();foreach(['woocommerce_checkout_order_created'=>'classic','woocommerce_store_api_checkout_order_processed'=>'blocks','woocommerce_before_pay_action'=>'pay_again']as$hook=>$method)check(in_array([[RKW_Checkout_Stock::class,$method],1],$GLOBALS['action_hooks'][$hook][20],true));
};
$fail=0;foreach($tests as$name=>$test){guard_reset();try{$test();echo'PASS '.$name."\n";}catch(Throwable$e){$fail++;echo'FAIL '.$name.': '.$e->getMessage().' at '.$e->getLine()."\n";}}echo count($tests).' tests, '.$fail." failed\n";exit($fail?1:0);
