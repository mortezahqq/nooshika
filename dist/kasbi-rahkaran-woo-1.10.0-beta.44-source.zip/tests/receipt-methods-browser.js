const assert=require('node:assert/strict'),path=require('node:path'),{execFileSync}=require('node:child_process'),{chromium}=require('playwright');
(async()=>{
 const browser=await chromium.launch({headless:true,executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
 async function fixture(stale=false,handler){
  const page=await browser.newPage({viewport:{width:2560,height:1400}}),errors=[],calls=[];
  page.on('pageerror',e=>errors.push(e.message));
  const data=JSON.parse(execFileSync(process.env.RKW_TEST_PHP||'php',['-n',path.join(__dirname,'receipt-methods-html.php'),stale?'stale':'fresh'],{encoding:'utf8'}));
  await page.route('https://wordpress.example.invalid/**',async route=>{
   const body=Object.fromEntries(new URLSearchParams(route.request().postData()||''));
   assert.equal(body.action,'rkw_policy_catalog','Only read-only metadata is allowed');assert.equal(body._ajax_nonce,'synthetic-policy-nonce');calls.push(body);
   const response=handler?await handler(data.config,calls.length):{success:true,data:data.config.catalog};
   await route.fulfill({status:200,contentType:'application/json',headers:{'Access-Control-Allow-Origin':'*'},body:JSON.stringify(response)});
  });
  await page.setContent(data.html);await page.addStyleTag({path:path.join(__dirname,'../rahkaran-woo/assets/config-policies.css')});await page.evaluate(cfg=>window.rkwPolicyConfig=cfg,data.config);
  await page.addScriptTag({path:path.join(__dirname,'../rahkaran-woo/assets/config-policies.js')});
  const key=page.locator('.rkw-gateway-rule').first().locator('[name$="[receipt_key]"]');
  return{page,errors,calls,key,config:data.config};
 }
 async function valueSubmitted(f){return f.key.evaluate(node=>new FormData(node.form).get(node.name));}
 try{
  const one=await fixture();assert.equal(await one.key.getAttribute('tagName'),null);assert.equal(await one.key.evaluate(n=>n.tagName),'SELECT');assert.equal(await one.key.inputValue(),'ThirdPartyCoupon');assert.match(await one.key.locator('option:checked').textContent(),/بن سازمانی اسنپ پی/);assert.equal(await valueSubmitted(one),'ThirdPartyCoupon');assert.equal(one.calls.length,0);assert.deepEqual(one.errors,[]);await one.page.close();console.log('PASS browser: actual settings HTML shows the server Persian name while submitting ThirdPartyCoupon exactly');

  const two=await fixture();const policy=two.page.locator('.rkw-gateway-rule').first().locator('[name$="[settlement_id]"]');await policy.fill('1');await policy.dispatchEvent('change');assert.equal(await two.key.inputValue(),'ThirdPartyCoupon');assert.match(await two.key.locator('option:checked').textContent(),/ذخیره‌شده/);assert.match(await two.page.locator('.rkw-rule-key-warning').first().textContent(),/خودکار عوض نشده/);assert.equal(await valueSubmitted(two),'ThirdPartyCoupon');await two.key.selectOption('EReceipt');assert.equal(await valueSubmitted(two),'EReceipt');await policy.fill('45');await policy.dispatchEvent('change');await two.key.selectOption('ThirdPartyCoupon');assert.equal(await valueSubmitted(two),'ThirdPartyCoupon');assert.deepEqual(two.errors,[]);await two.page.close();console.log('PASS browser: policy changes preserve a saved voucher rather than silently replacing it with EReceipt');

  const three=await fixture(true,async(cfg)=>{await new Promise(r=>setTimeout(r,50));const catalog=JSON.parse(JSON.stringify(cfg.catalog));catalog.schema_version=2;catalog.updated_at=Math.floor(Date.now()/1000);catalog.invoice[1].methods[0].name='بن سازمانی با عنوان تازه سرور';return{success:true,data:catalog};});await three.page.waitForFunction(()=>document.querySelector('.rkw-gateway-rule [name$="[receipt_key]"] option:checked').textContent.includes('عنوان تازه'));assert.equal(three.calls.length,1);assert.equal(await valueSubmitted(three),'ThirdPartyCoupon');assert.deepEqual(three.errors,[]);await three.page.close();console.log('PASS browser: stale metadata is fetched automatically without submitting or changing any payment setting');

  const four=await fixture();await four.page.locator('#rkw-add-rule').click();const rows=four.page.locator('.rkw-gateway-rule');assert.equal(await rows.count(),3);const added=rows.nth(2).locator('[name$="[receipt_key]"]');assert.equal(await added.inputValue(),'');assert.equal(await added.getAttribute('name'),'rkw[payment_rules][2][receipt_key]');await added.selectOption('ThirdPartyCoupon');assert.equal(await added.inputValue(),'ThirdPartyCoupon');await rows.first().locator('.rkw-rule-remove').click();await four.page.locator('#rkw-add-rule').click();assert.equal(await four.page.locator('.rkw-gateway-rule').last().locator('[name$="[receipt_key]"]').getAttribute('name'),'rkw[payment_rules][3][receipt_key]');assert.deepEqual(four.errors,[]);await four.page.close();console.log('PASS browser: newly added gateway rows have unique field names and no automatic EReceipt selection');

  const five=await fixture(true,(cfg,n)=>n===1?{success:false,data:'synthetic unavailable'}:{success:true,data:{...cfg.catalog,schema_version:2,updated_at:Math.floor(Date.now()/1000)}});await five.page.waitForFunction(()=>document.getElementById('rkw-policy-feedback').textContent.includes('خطا'));assert.equal(await valueSubmitted(five),'ThirdPartyCoupon');assert.equal(five.calls.length,1);await five.page.locator('#rkw-load-policy-catalog').click();await five.page.waitForFunction(()=>document.getElementById('rkw-policy-feedback').textContent.includes('عنوان روش'));assert.equal(five.calls.length,2);assert.equal(await valueSubmitted(five),'ThirdPartyCoupon');assert.deepEqual(five.errors,[]);await five.page.close();console.log('PASS browser: failed metadata reads preserve the configured voucher and only explicit retry starts another read');

  const six=await fixture();await six.page.locator('select[name="rkw[order_mode]"]').selectOption('salesorder');assert.equal(await six.key.inputValue(),'ThirdPartyCoupon');const options=await six.key.locator('option').evaluateAll(nodes=>nodes.map(n=>n.value));assert.deepEqual(options,['','ThirdPartyCoupon']);assert.equal(await valueSubmitted(six),'ThirdPartyCoupon');assert.deepEqual(six.errors,[]);await six.page.close();console.log('PASS browser: invoice methods are never borrowed as authorized order methods');

  const seven=await fixture();await seven.key.selectOption('');assert.equal(await valueSubmitted(seven),'');assert.equal(await seven.page.locator('select[name="rkw[receipt_key]"]').inputValue(),'EReceipt');assert.deepEqual(seven.errors,[]);await seven.page.close();console.log('PASS browser: choosing default inheritance is explicit and does not overwrite the global receipt key');
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exit(1);});
