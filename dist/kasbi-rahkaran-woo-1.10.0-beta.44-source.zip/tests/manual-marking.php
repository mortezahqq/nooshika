<?php
/** Local manual acknowledgement; all network calls are forbidden in these tests. */
define('RKW_MANUAL_ORDER_FIXTURES_ONLY',true);$mark_argv=$argv;$argv=array('marking-bootstrap');require __DIR__.'/manual-orders.php';$argv=$mark_argv;
class MarkingOrder extends ManualOrder {
 public $meta_saves=0,$notes=[];
 function save_meta_data(){$this->meta_saves++;}
 function add_order_note($note){$this->notes[]=$note;}
}
function wp_clear_scheduled_hook($hook,$args=[]){$GLOBALS['mark_cancelled'][]=[$hook,$args];}
function as_unschedule_all_actions($hook,$args=[],$group=''){$GLOBALS['mark_as_cancelled'][]=[$hook,$args,$group];}
function marking_reset(){
 $base=manual_reset();$o=new MarkingOrder;foreach(get_object_vars($base)as$key=>$value)$o->$key=$value;$GLOBALS['test_orders']=[$o->id=>$o];$GLOBALS['local_orders']=[$o];$GLOBALS['mark_cancelled']=[];$GLOBALS['mark_as_cancelled']=[];$GLOBALS['http_handler']=function(){throw new RuntimeException('Manual marking must never call Rahkaran');};return $o;
}
if(($argv[1]??'')==='html'){$o=marking_reset();if(($argv[2]??'')==='marked')$o->meta[RKW_Manual_Orders::MARK]='1';RKW_Modules::page();exit;}
if(($argv[1]??'')==='fixture'){$o=marking_reset();echo json_encode(RKW_Manual_Orders::mark_details($o));exit;}
$tests=[];
$tests['Persian order code saves a local manual mark with no invoice ID or network call']=function(){
 $o=$GLOBALS['test_orders'][237743];$before=$o->meta;$r=RKW_Manual_Orders::mark_code('#۲۳۷۷۴۳');check($r['status']==='manual_recorded'&&$r['details']['manual_recorded']);check($o->meta[RKW_Manual_Orders::MARK]==='1');check(!$o->get_meta('_rkw_doc_id'));check($o->meta_saves===1&&count($o->notes)===1);check($o->meta['_rkw_manual_recorded_audit']['user_id']===1);check($o->total===100&&$o->status==='processing');foreach($before as$k=>$v)check($o->meta[$k]===$v);check(!$GLOBALS['http_calls']);
};
$tests['repeating a mark is idempotent and does not rewrite audit or append notes']=function(){
 $o=$GLOBALS['test_orders'][237743];RKW_Manual_Orders::mark_code('237743');$audit=$o->meta['_rkw_manual_recorded_audit'];$r=RKW_Manual_Orders::mark_code('237743');check($r['manual_recorded']);check($o->meta_saves===1&&count($o->notes)===1&&$audit===$o->meta['_rkw_manual_recorded_audit']);check(!$GLOBALS['http_calls']);
};
$tests['lookup and marking work without connection payment or customer settings']=function(){
 $o=$GLOBALS['test_orders'][237743];$o->meta=[];$GLOBALS['options'][RKW_OPT]=['api'=>'v19','machine_name'=>'','password_enc'=>'','invoice_settlement_id'=>0];$d=RKW_Manual_Orders::lookup_mark('237743');check(!$d['manual_recorded']&&$o->meta_saves===0);RKW_Manual_Orders::mark_code('237743');check(RKW_Manual_Orders::is_marked($o));check(!$GLOBALS['http_calls']);
};
$tests['unknown and malformed codes cannot change metadata']=function(){
 $o=$GLOBALS['test_orders'][237743];foreach(['','0','-237743','237743.0','237743x',[],str_repeat('9',30),'999999']as$code)check(is_wp_error(RKW_Manual_Orders::mark_code($code)));check($o->meta_saves===0&&count($o->notes)===0);check(!$GLOBALS['http_calls']);
};
$tests['mark and unmark use the shared order lock and never remove someone elses lock']=function(){
 $o=$GLOBALS['test_orders'][237743];$lock='rkw_order_lock_237743';add_option($lock,['started'=>123]);expect_error(RKW_Manual_Orders::mark_code('237743'),'rkw_manual_mark_busy');expect_error(RKW_Manual_Orders::mark_code('237743',false),'rkw_manual_mark_busy');check(get_option($lock)===['started'=>123]&&$o->meta_saves===0);check(!$GLOBALS['http_calls']);
};
$tests['unmark preserves previous errors uncertainty and verified document IDs without sending']=function(){
 foreach(['unsent','pending','sent']as$state){$o=marking_reset();if($state==='pending'){$o->meta['_rkw_reconcile_required']=1;$o->meta['_rkw_error']='synthetic uncertainty';}if($state==='sent'){$o->meta['_rkw_doc_id']='901';$o->meta['_rkw_doc_type']='invoice';}$before=$o->meta;RKW_Manual_Orders::mark_code('237743');check(RKW_Order_List_UI::state($o)==='manual_recorded');$r=RKW_Manual_Orders::mark_code('237743',false);check(!$r['manual_recorded']&&$r['details']['state']===$state);foreach($before as$k=>$v)check($o->meta[$k]===$v);check(count($o->notes)===2);check(!$GLOBALS['http_calls']);}
};
$tests['manual mark cancels only this orders pending jobs and never enqueues on removal']=function(){
 RKW_Manual_Orders::mark_code('237743');check($GLOBALS['mark_cancelled']===[['rkw_send_order',[237743]]]);check($GLOBALS['mark_as_cancelled']===[['rkw_send_order',[237743],'rkw-orders']]);RKW_Manual_Orders::mark_code('237743',false);check(count($GLOBALS['mark_cancelled'])===1&&count($GLOBALS['mark_as_cancelled'])===1);check(!$GLOBALS['http_calls']);
};
$tests['marked row stays struck in all list with no send or selection control after reload']=function(){
 RKW_Manual_Orders::mark_code('237743');$h=layout_html();check(strpos($h,'data-order-id="237743" class="rkw-manually-recorded"')!==false);check(strpos($h,'ثبت دستی در راهکاران')!==false);check(strpos($h,'value="237743"')===false);check(strpos($h,'class="button button-small rkw-send-one"')===false);check(!$GLOBALS['http_calls']);
};
$tests['classic and HPOS unsent filters exclude marked rows before count and pagination']=function(){
 foreach([false,true]as$hpos){$o=marking_reset();TestOrderUtil::$hpos=$hpos;RKW_Manual_Orders::mark_code('237743');$p=RKW_Modules::local_order_page(1,'unsent');check($p->total===0&&$p->orders===[]);$q=$GLOBALS['wpdb']->queries[0];check(strpos($q,"mm.meta_key='_rkw_manual_recorded' AND mm.meta_value='1'")!==false);check(strpos($q,$hpos?'wp_wc_orders_meta mm':'wp_postmeta mm')!==false);check(RKW_Modules::local_order_page(1,'all')->total===1);}
};
$tests['manual and queued financial senders stop before any customer or financial HTTP call']=function(){
 $o=$GLOBALS['test_orders'][237743];$GLOBALS['options'][RKW_OPT]['order_enabled']=1;RKW_Manual_Orders::mark_code('237743');expect_error(RKW_Orders::send($o,true),'rkw_manual_recorded');RKW_Orders::cron_send($o->id);check(!RKW_Order_Runner::allowed($o));RKW_Order_Runner::enqueue($o->id);check(!$GLOBALS['http_calls']);check(!$o->get_meta('_rkw_attempts'));
};
$tests['a stale sender rechecks the mark under its lock before sending']=function(){
 $o=$GLOBALS['test_orders'][237743];$stale=clone$o;RKW_Manual_Orders::mark_code('237743');expect_error(RKW_Orders::send($stale,true),'rkw_manual_recorded');check(get_option('rkw_order_lock_237743',false)===false);check(!$GLOBALS['http_calls']);
};
$tests['cached bulk send and reconciliation controls return the manual mark without issuing documents']=function(){
 $o=$GLOBALS['test_orders'][237743];RKW_Manual_Orders::mark_code('237743');$_POST=['order_ids'=>[237743]];$r=manual_json(fn()=>RKW_Order_List_UI::ajax_send());check($r->success&&$r->data['sent']===0&&$r->data['items'][0]['status']==='manual_recorded');$r=RKW_Reconciliation::step($o,'',true);check($r['status']==='manual_recorded'&&$r['done']);check(!$GLOBALS['http_calls']);
};
$tests['actual endpoints require capability nonce and explicit mark or unmark flag']=function(){
 foreach(['test_nonce','test_capability']as$flag){marking_reset();$GLOBALS[$flag]=false;$_POST=['code'=>'237743','confirm'=>'1'];foreach(['ajax_lookup_mark','ajax_mark_code','ajax_unmark_code']as$method)check(!manual_json(fn()=>RKW_Manual_Orders::$method())->success);check(!$GLOBALS['http_calls']);}
 foreach(['ajax_mark_code','ajax_unmark_code']as$method){$o=marking_reset();$_POST=['code'=>'237743'];check(!manual_json(fn()=>RKW_Manual_Orders::$method())->success);check($o->meta_saves===0);}
};
$tests['only the submitted code affects the order and forged document or financial fields are ignored']=function(){
 $o=$GLOBALS['test_orders'][237743];$_POST=['code'=>'۲۳۷۷۴۳','confirm'=>'1','order_id'=>'999','document_id'=>'123','amount'=>0,'status'=>'completed'];$r=manual_json(fn()=>RKW_Manual_Orders::ajax_mark_code());check($r->success&&$r->data['id']===237743&&RKW_Manual_Orders::is_marked($o));check(!$o->get_meta('_rkw_doc_id')&&$o->total===100&&$o->status==='processing');check(!$GLOBALS['http_calls']);
};
$tests['stale financial forms are registered to a retired endpoint rather than the sender']=function(){
 RKW_Manual_Orders::init();foreach(['submit','register_code']as$action){$callbacks=$GLOBALS['action_hooks']['wp_ajax_rkw_manual_'.$action][10];check(end($callbacks)[0]===[RKW_Manual_Orders::class,'ajax_retired_sender']);}$_POST=['code'=>'237743','confirm'=>'1'];check(!manual_json(fn()=>RKW_Manual_Orders::ajax_register_code())->success);check(!$GLOBALS['http_calls']);
};
$fail=0;foreach($tests as$name=>$test){marking_reset();try{$test();echo 'PASS '.$name."\n";}catch(Throwable$e){$fail++;echo 'FAIL '.$name.': '.$e->getMessage().' at '.$e->getLine()."\n";}}echo count($tests).' tests, '.$fail." failed\n";exit($fail?1:0);
