<?php
require __DIR__.'/bootstrap.php';
function failure_log($raw,$debug=0){
 reset_case();$s=rkw_settings();$s['debug']=$debug;$s['username']='private-user';$s['password_enc']=RKW_Crypto::encrypt('private-password');$s['document_contract']='legacy_esales';$GLOBALS['options'][RKW_OPT]=$s;
 set_transient(RKW_Client::COOKIE_TRANSIENT,['name'=>'sg-auth-sg','value'=>'private-cookie','signature'=>RKW_Policy_Catalog::signature($s)],60);
 $c=new RKW_Client;$m=new ReflectionMethod($c,'debug');$m->invoke($c,'CASHIER','https://example.invalid/Services/CashierLogin',['machineName'=>'TEST'],['code'=>500,'body'=>$raw]);
 $rows=RKW_Log::all();check(count($rows)===1);check(strpos($rows[0]['message'],'CASHIER_FAILURE | ')===0);return json_decode(substr($rows[0]['message'],strlen('CASHIER_FAILURE | ')),true);
}
$tests=[];
$tests['HTTP 500 JSON message is retained with debug disabled and credentials removed']=function(){
 $r=failure_log(json_encode(['metadata'=>['errorMessage'=>'Register unavailable private-user private-password private-cookie token=secret-token phone=09121112233 email=a@example.invalid'],'cookie'=>'unrelated-private-data']));
 check($r['http_status']===500&&$r['document_contract']==='legacy_esales'&&$r['request_shape']==='machineName object');check(strpos($r['server_message'],'Register unavailable')!==false);
 foreach(['private-user','private-password','private-cookie','secret-token','09121112233','a@example.invalid','unrelated-private-data'] as $secret)check(strpos(json_encode($r),$secret)===false);
};
$tests['HTML error text is readable without scripts tags or credential-bearing URLs']=function(){
 $r=failure_log('<html><script>private-script</script><style>private-style</style><body><h1>Server Error</h1><p>Cash register is closed &amp; unavailable https://user:pass@example.invalid/?token=abc</p></body></html>',1);
 check($r['response_format']==='html_or_xml');check(strpos($r['server_message'],'Cash register is closed & unavailable')!==false);foreach(['private-script','private-style','<html>','user:pass','token=abc']as$v)check(strpos($r['server_message'],$v)===false);
};
$tests['SOAP fault and plain text errors remain readable']=function(){foreach(['<Fault><faultstring>Machine not found</faultstring></Fault>','Machine not found']as$body){$r=failure_log($body);check($r['server_message']==='Machine not found');}};
$tests['empty and unrecognized JSON responses are explicit']=function(){ $r=failure_log('');check($r['body_empty']&&$r['response_format']==='empty');$r=failure_log('{"secret":"never-log-this"}');check($r['response_format']==='json');check(strpos(json_encode($r),'never-log-this')===false);check($r['server_message']==='[no readable server error message]');};
$tests['long error messages are bounded']=function(){$r=failure_log(str_repeat('خطا ',1000));check($r['message_truncated']);check(rkw_text_length($r['server_message'])===2000);};
$tests['failed cashier stops before any invoice POST and clears session']=function(){reset_case();$s=rkw_settings();$s['debug']=0;$s['document_contract']='legacy_esales';$GLOBALS['options'][RKW_OPT]=$s;set_transient(RKW_Client::COOKIE_TRANSIENT,['name'=>'sg-auth-sg','value'=>'synthetic-cookie','signature'=>RKW_Policy_Catalog::signature($s)],60);$GLOBALS['http_handler']=function($url,$args){check(strpos($url,'/CashierLogin')!==false);return ['code'=>500,'body'=>'<h1>Register unavailable</h1>'];};expect_error(RKW_Orders::send(order()),'rkw_cashier');check(count($GLOBALS['http_calls'])===1);check(get_transient(RKW_Client::COOKIE_TRANSIENT)===false);check(strpos(json_encode(RKW_Log::all()),'CASHIER_FAILURE')!==false);};
$fail=0;foreach($tests as$name=>$test){try{$test();echo"PASS $name\n";}catch(Throwable $e){$fail++;echo"FAIL $name: ".$e->getMessage()." at ".$e->getLine()."\n";}}echo count($tests)." tests, $fail failed\n";exit($fail?1:0);
