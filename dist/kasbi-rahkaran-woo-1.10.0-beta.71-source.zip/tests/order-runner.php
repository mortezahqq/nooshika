<?php
require __DIR__.'/bootstrap.php';
define('DISABLE_WP_CRON',true);
$GLOBALS['order_jobs']=[];$GLOBALS['wp_jobs']=[];
function wp_next_scheduled($hook,$args=[]){foreach($GLOBALS['wp_jobs']as$t=>$events)foreach($events[$hook]??[]as$e)if($e['args']===$args)return$t;return false;}
function wp_schedule_single_event($time,$hook,$args=[]){$GLOBALS['wp_jobs'][$time][$hook][md5(serialize($args))]=['args'=>$args];return true;}
function wp_unschedule_event($time,$hook,$args){unset($GLOBALS['wp_jobs'][$time][$hook][md5(serialize($args))]);return true;}
function wp_clear_scheduled_hook($hook,$args=[]){foreach($GLOBALS['wp_jobs']as$t=>$events)foreach($events[$hook]??[]as$k=>$e)if($e['args']===$args)unset($GLOBALS['wp_jobs'][$t][$hook][$k]);}
function _get_cron_array(){return$GLOBALS['wp_jobs'];}
function as_get_scheduled_actions($query,$format){$out=[];foreach($GLOBALS['order_jobs']as$id=>$job)if($job['hook']===$query['hook']&&$job['args']===$query['args']&&$job['group']===$query['group']&&$job['status']===$query['status'])$out[]=$id;return array_slice($out,0,$query['per_page']);}
function as_enqueue_async_action($hook,$args=[],$group='',$unique=false){$id=count($GLOBALS['order_jobs'])+1;$GLOBALS['order_jobs'][$id]=compact('hook','args','group')+['status'=>'pending','time'=>time()];return$id;}
function as_schedule_single_action($time,$hook,$args=[],$group='',$unique=false){$id=as_enqueue_async_action($hook,$args,$group,$unique);$GLOBALS['order_jobs'][$id]['time']=$time;return$id;}
function wc_get_order_statuses(){return ['wc-processing'=>'processing','wc-completed'=>'completed','wc-packed'=>'بسته بندی شده'];}
class QueueDate extends DateTimeImmutable{function date($format){return $this->format($format);}}
class TestQueueOrder extends WC_Order{public $paid=false;function save_meta_data(){}function get_date_paid(){return $this->paid?new QueueDate('2026-10-24'):null;}}
class TestOrderAsyncRunner{function maybe_dispatch_async_request(){$GLOBALS['order_wakes']=($GLOBALS['order_wakes']??0)+1;}}
class ActionScheduler{static function runner(){return new TestOrderAsyncRunner;}}
function queue_reset(){reset_case();$GLOBALS['order_jobs']=[];$GLOBALS['wp_jobs']=[];$GLOBALS['order_wakes']=0;$GLOBALS['options'][RKW_OPT]['order_enabled']=1;$o=new TestQueueOrder;$o->items=[new TestItem(100)];$o->total=100;$GLOBALS['test_orders']=[$o->id=>$o];$p=new ReflectionProperty(RKW_Order_Runner::class,'wake');$p->setAccessible(true);$p->setValue(null,false);return$o;}
$tests=[];
$tests['checkout queues immediately in WooCommerce even with DISABLE_WP_CRON']=function(){$o=$GLOBALS['test_orders'][236464];RKW_Orders::on_status($o->id,'pending','processing',$o);check(count($GLOBALS['order_jobs'])===1);check(!$GLOBALS['wp_jobs']);check(!$GLOBALS['http_calls']);RKW_Order_Runner::wake();check($GLOBALS['order_wakes']===1);};
$tests['repeated status hooks do not duplicate a pending order action']=function(){$o=$GLOBALS['test_orders'][236464];RKW_Orders::on_status($o->id,'pending','processing',$o);RKW_Orders::on_status($o->id,'on-hold','processing',$o);check(count($GLOBALS['order_jobs'])===1);};
$tests['a first customer is looked up created and invoiced once when the worker runs']=function(){
 $o=$GLOBALS['test_orders'][236464];$o->meta=[];$GLOBALS['options'][RKW_OPT]['fida_fallback']=1;$created=0;$saved=0;
 $GLOBALS['http_handler']=function($u,$a)use(&$created,&$saved){if($a['method']==='GET')return response([]);if(strpos($u,'CustomerService.svc/customer')!==false){$created++;return response(['Id'=>88]);}if(strpos($u,'calculateAmount')!==false)return response(['netPrice'=>1000]);$saved++;check(strpos($u,'/SaveInvoice')!==false);$p=json_decode($a['body'],true);check($p['document']['customerId']===88);return response(['id'=>909]);};
 RKW_Orders::on_status($o->id,'pending','processing',$o);$GLOBALS['order_jobs'][1]['status']='in-progress';RKW_Orders::cron_send($o->id);check($created===1&&$saved===1);check($o->get_meta('_rkw_doc_id')==='909');check($o->get_meta('_rkw_customer_id')===88);RKW_Orders::cron_send($o->id);check($created===1&&$saved===1);
};
$tests['old waiting WP events move into the Woo queue without deleting other hooks']=function(){
 $o=$GLOBALS['test_orders'][236464];wp_schedule_single_event(time()-600,'rkw_send_order',[$o->id]);wp_schedule_single_event(time()-600,'other_plugin_job',[55]);RKW_Order_Runner::migrate_pending();check(count($GLOBALS['order_jobs'])===1);check(!wp_next_scheduled('rkw_send_order',[$o->id]));check(wp_next_scheduled('other_plugin_job',[55])!==false);check(!$GLOBALS['http_calls']);
};
$tests['unknown prior results do not get migrated into a new financial write']=function(){$o=$GLOBALS['test_orders'][236464];$o->meta['_rkw_reconcile_required']=1;wp_schedule_single_event(time()-10,'rkw_send_order',[$o->id]);RKW_Order_Runner::migrate_pending();check(!$GLOBALS['order_jobs']);RKW_Orders::cron_send($o->id);check(!$GLOBALS['http_calls']);check($o->get_meta('_rkw_reconcile_required')===1);};
$tests['disabled automatic sending and cancelled status are checked again at execution']=function(){
 foreach(['off','cancelled']as$mode){$o=queue_reset();if($mode==='off')$GLOBALS['options'][RKW_OPT]['order_enabled']=0;else$o->status='cancelled';RKW_Orders::cron_send($o->id);check(!$GLOBALS['http_calls']);}
};
$tests['a held lock schedules only bounded delayed retries without contacting Rahkaran']=function(){
 $o=$GLOBALS['test_orders'][236464];add_option('rkw_order_lock_'.$o->id,['started'=>time()]);RKW_Orders::cron_send($o->id);check($o->get_meta('_rkw_queue_lock_retries')===1);check($GLOBALS['order_jobs'][1]['time']>=time()+59);check(!$GLOBALS['http_calls']);$o->meta['_rkw_queue_lock_retries']=5;$GLOBALS['order_jobs']=[];RKW_Orders::cron_send($o->id);check(!$GLOBALS['order_jobs']);
};
$tests['an uncertain invoice result never receives an automatic retry']=function(){
 $o=$GLOBALS['test_orders'][236464];$GLOBALS['http_handler']=fn($u,$a)=>strpos($u,'calculateAmount')!==false?response(['netPrice'=>1000]):new WP_Error('http_request_failed','timeout');RKW_Orders::cron_send($o->id);check($o->get_meta('_rkw_reconcile_required')===1);check(!$GLOBALS['order_jobs']);
};
$tests['a rejected new customer is logged and does not loop or issue an invoice']=function(){
 $o=$GLOBALS['test_orders'][236464];$o->meta=[];$GLOBALS['options'][RKW_OPT]['fida_fallback']=1;$GLOBALS['http_handler']=fn($u,$a)=>$a['method']==='GET'?response([]):response([],false,'synthetic customer rejection');RKW_Orders::cron_send($o->id);check(!$o->get_meta('_rkw_doc_id'));check(!$GLOBALS['order_jobs']);check(strpos($o->get_meta('_rkw_error'),'ایجاد مشتری')!==false);
};
$tests['paid custom fulfillment can enter the queue directly without processing']=function(){
 $o=$GLOBALS['test_orders'][236464];
 $o->status='packed';
 RKW_Orders::on_status($o->id,'pending','packed',$o);
 check(!$GLOBALS['order_jobs']);
 $o->paid=true;
 RKW_Orders::on_payment_complete($o->id);
 check(count($GLOBALS['order_jobs'])===1);
 RKW_Orders::on_status($o->id,'on-hold','packed',$o);
 check(count($GLOBALS['order_jobs'])===1&& !$GLOBALS['http_calls']);
};
$tests['manual or incomplete split orders do not enter the automatic queue']=function(){
 $o=$GLOBALS['test_orders'][236464];
 $o->status='packed';$o->paid=true;
 $o->meta[RKW_Orders::SPLIT_PLAN]=['parts'=>[['id'=>101],['id'=>0]]];
 RKW_Orders::on_status($o->id,'pending','packed',$o);
 RKW_Orders::on_payment_complete($o->id);
 check(!$GLOBALS['order_jobs']&&!$GLOBALS['http_calls']);
};
$tests['a job queued at processing still executes after a paid packed transition']=function(){
 $o=$GLOBALS['test_orders'][236464];RKW_Orders::on_status($o->id,'pending','processing',$o);$o->status='packed';$o->paid=true;$saved=0;$GLOBALS['http_handler']=function($u,$a)use(&$saved){if(strpos($u,'calculateAmount')!==false)return response(['netPrice'=>1000]);$saved++;return response(['id'=>910]);};$GLOBALS['order_jobs'][1]['status']='in-progress';RKW_Orders::cron_send($o->id);check($saved===1&&$o->get_meta('_rkw_doc_id')==='910');
};
$fail=0;foreach($tests as$name=>$test){queue_reset();try{$test();echo 'PASS '.$name."\n";}catch(Throwable$e){$fail++;echo 'FAIL '.$name.': '.$e->getMessage().' at '.$e->getLine()."\n";}}
echo count($tests).' tests, '.$fail." failed\n";exit($fail?1:0);
