<?php
/** Isolated WordPress/WooCommerce boundary doubles; no real invoices or credentials. */
error_reporting(E_ALL);
set_error_handler(function($severity,$message,$file,$line){ if(error_reporting() & $severity){throw new ErrorException($message,0,$severity,$file,$line);} return false; });
define('ABSPATH',__DIR__.'/'); define('MINUTE_IN_SECONDS',60); define('HOUR_IN_SECONDS',3600); define('DAY_IN_SECONDS',86400); define('ARRAY_A','ARRAY_A');
$GLOBALS['options']=[];$GLOBALS['transients']=[];$GLOBALS['filters']=[];$GLOBALS['usermeta']=[];$GLOBALS['http_calls']=[];
class WP_Error { private $code,$message,$data; function __construct($c,$m,$d=null){$this->code=$c;$this->message=$m;$this->data=$d;} function get_error_code(){return $this->code;}function get_error_message(){return $this->message;}function get_error_data(){return $this->data;} }
class WP_Http_Cookie {public $name,$value;function __construct($a){$this->name=$a['name'];$this->value=$a['value'];}}
function is_wp_error($v){return $v instanceof WP_Error;}
function get_option($k,$d=false){return $GLOBALS['options'][$k]??$d;}function update_option($k,$v,$a=null){$GLOBALS['options'][$k]=$v;return true;}function delete_option($k){unset($GLOBALS['options'][$k]);}
function add_option($k,$v,$deprecated='',$autoload=null){if(array_key_exists($k,$GLOBALS['options']))return false;$GLOBALS['options'][$k]=$v;return true;}
function get_transient($k){return $GLOBALS['transients'][$k]??false;}function set_transient($k,$v,$ttl){$GLOBALS['transients'][$k]=$v;return true;}function delete_transient($k){unset($GLOBALS['transients'][$k]);}
function wp_parse_args($a,$b){return array_merge($b,$a);}function wp_json_encode($v,$flags=0){return json_encode($v,$flags);}function wp_salt($x){return 'synthetic-test-salt';}
function plugin_dir_path($p){return dirname($p).'/';}function register_activation_hook($a,$b){}function register_deactivation_hook($a,$b){}
function add_action($name,$callback,$p=10,$n=1){$GLOBALS['action_hooks'][$name][$p][]=[$callback,$n];}function add_filter($name,$callback,$p=10,$n=1){$GLOBALS['filters'][$name][$p][]=$callback;}
function apply_filters($name,$v,...$args){$callbacks=$GLOBALS['filters'][$name]??[];ksort($callbacks);foreach($callbacks as $list)foreach($list as $fn)$v=$fn($v,...$args);return $v;}
function absint($v){return abs((int)$v);}function sanitize_text_field($v){return strip_tags((string)$v);}function sanitize_key($v){return preg_replace('/[^a-z0-9_-]/','',strtolower($v));}
function current_time($format){return $format==='timestamp'?time():date($format==='mysql'?'Y-m-d H:i:s':$format);}function wp_generate_uuid4(){return bin2hex(random_bytes(16));}
function get_user_meta($id,$key,$single){return $GLOBALS['usermeta'][$id][$key]??'';}function update_user_meta($id,$key,$v){$GLOBALS['usermeta'][$id][$key]=$v;}
function add_query_arg($args,$url){return $url.'?'.http_build_query($args);}function wp_remote_get($u,$a){return wp_remote_request($u,$a+['method'=>'GET']);}function wp_remote_post($u,$a){return wp_remote_request($u,$a+['method'=>'POST']);}
function wp_remote_request($u,$a){$GLOBALS['http_calls'][]=[$u,$a];return ($GLOBALS['http_handler'])($u,$a);}
function wp_remote_retrieve_response_code($r){return $r['code'];}function wp_remote_retrieve_body($r){return $r['body'];}function wp_remote_retrieve_cookie($r,$n){foreach($r['cookies']??[] as $c)if($c->name===$n)return $c;return null;}function wp_remote_retrieve_cookies($r){return $r['cookies']??[];}function wp_remote_retrieve_header($r,$key){return $r['headers'][$key]??'';}
function wc_get_product($id){return $GLOBALS['products'][$id]??null;}
class TestDB { public $posts='wp_posts',$postmeta='wp_postmeta',$last_error='',$records=[],$last_sql='',$last_args=[];function prepare($sql,...$args){$this->last_sql=$sql;$this->last_args=$args;return $sql;}function get_results($sql,$format){return $this->records;} } $GLOBALS['wpdb']=new TestDB;
class TestProduct {public $meta=['_rahkaran_product_id'=>30,'_rahkaran_unit_id'=>1],$sku='SKU-30';function get_meta($k){return $this->meta[$k]??'';}function get_parent_id(){return 0;}function get_sku(){return $this->sku;}function update_meta_data($k,$v){$this->meta[$k]=$v;}function save(){} }
class TestItem {public $total,$tax,$subtotal,$subtotal_tax,$qty,$product;function __construct($t,$tax=0,$qty=1,$sub=null){$this->total=$t;$this->tax=$tax;$this->qty=$qty;$this->subtotal=$sub??$t;$this->subtotal_tax=$tax;$this->product=new TestProduct;}function get_product(){return $this->product;}function get_name(){return 'test-item';}function get_total(){return $this->total;}function get_total_tax(){return $this->tax;}function get_subtotal(){return $this->subtotal;}function get_subtotal_tax(){return $this->subtotal_tax;}function get_quantity(){return $this->qty;} }
class TestFee {public $total,$tax,$name;function __construct($t,$name='fee',$tax=0){$this->total=$t;$this->tax=$tax;$this->name=$name;}function get_total(){return $this->total;}function get_total_tax(){return $this->tax;}function get_name(){return $this->name;} }
class TestShipping {function get_method_id(){return 'flat_rate';}function get_instance_id(){return 2;}function get_name(){return 'پست';}}
class WC_Order { public $status='processing';function get_status(){return $this->status;}public $items=[],$fees=[],$shipping=0,$shipping_tax=0,$total=0,$gateway='test_bank',$meta=['_rkw_customer_id'=>45],$uid=0,$id=236464;function get_type(){return 'shop_order';}function get_meta($k){return $this->meta[$k]??'';}function update_meta_data($k,$v){$this->meta[$k]=$v;}function delete_meta_data($k){unset($this->meta[$k]);}function save(){}function get_items(){return $this->items;}function get_fees(){return $this->fees;}function get_shipping_methods(){return [new TestShipping];}function get_shipping_total(){return $this->shipping;}function get_shipping_tax(){return $this->shipping_tax;}function get_total(){return $this->total;}function get_payment_method(){return $this->gateway;}function get_user_id(){return $this->uid;}function get_id(){return $this->id;}function get_order_number(){return (string)$this->id;}function get_date_paid(){return null;}function get_date_created(){return null;}function get_transaction_id(){return 'test-transaction';}function add_order_note($n){}function get_billing_phone(){return '09120000000';}function get_billing_first_name(){return 'test';}function get_billing_last_name(){return 'test';}function get_billing_email(){return 'test@example.invalid';} function get_address($type='billing'){return $type==='billing'?['first_name'=>$this->get_billing_first_name(),'last_name'=>$this->get_billing_last_name(),'phone'=>$this->get_billing_phone()]:[];}function get_payment_method_title(){return 'درگاه آزمایشی';} }
require dirname(__DIR__).'/rahkaran-woo/rahkaran-woo.php';
function response($result,$success=true,$message='',$code=200){return ['code'=>$code,'body'=>json_encode(['result'=>$result,'metadata'=>['isSuccessfull'=>$success,'errorMessage'=>$message]])];}
function settings(){return array_merge(rkw_defaults(),['document_contract'=>'v21','api'=>'v21','ip'=>'rahkaran.example.invalid','username'=>'synthetic','password_enc'=>RKW_Crypto::encrypt('synthetic-test-password'),'machine_name'=>'TEST-REGISTER','inventory_id'=>1,'invoice_doc_pattern_id'=>9,'invoice_settlement_id'=>27,'order_settlement_id'=>27,'order_doc_pattern_id'=>9,'order_mode'=>'invoice','receipt_key'=>'EReceipt','bank_account_ref'=>42,'invoice_preflight'=>1]);}
function reset_case(){ $GLOBALS['siteoptions']=[];$GLOBALS['options']=[RKW_OPT=>settings(),RKW_Extensions::OPTION=>RKW_Extensions::defaults()];$GLOBALS['transients']=[];$GLOBALS['http_calls']=[];$GLOBALS['wpdb']->records=[];$GLOBALS['filters']['rkw_order_payload']=[20=>[[RKW_Extensions::class,'extend_payload']],30=>[[RKW_Loyalty::class,'extend_payload']]];$s=rkw_settings();set_transient(RKW_Client::COOKIE_TRANSIENT,['name'=>'sg-auth-sg','value'=>'synthetic-cookie','signature'=>RKW_Policy_Catalog::signature($s)],60); }
function order($total=100,$shipping=0){$o=new WC_Order;$o->items=[new TestItem($total-$shipping)];$o->total=$total;$o->shipping=$shipping;return $o;}
function check($condition,$message='assertion failed'){if(!$condition)throw new RuntimeException($message);}
function expect_error($v,$code){check(is_wp_error($v),'expected '.$code.' error, got success');check($v->get_error_code()===$code,'expected '.$code.', got '.$v->get_error_code().': '.$v->get_error_message());}
function save_calls(){return array_values(array_filter($GLOBALS['http_calls'],fn($c)=>strpos($c[0],'/SaveInvoice')!==false));}

class TestRedirect extends RuntimeException {}
function current_user_can($cap){return $GLOBALS['test_capability']??true;}
function check_admin_referer($action){return true;}
function wp_unslash($v){return is_array($v)?array_map('wp_unslash',$v):(is_string($v)?stripslashes($v):$v);}
function wp_safe_redirect($url){throw new TestRedirect($url);}
function admin_url($path=''){return 'https://wordpress.example.invalid/wp-admin/'.$path;}
function esc_attr($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
function esc_html($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
function checked($a,$b=true,$echo=true){$v=(string)$a===(string)$b?' checked="checked"':'';if($echo)echo $v;return $v;}
function get_site_option($key,$default=false){return $GLOBALS['siteoptions'][$key]??$default;}

class TestJSON extends RuntimeException {public $data,$success;function __construct($d,$ok){$this->data=$d;$this->success=$ok;parent::__construct('json response');}}
function wc_get_order($id){return $GLOBALS['test_orders'][$id]??false;}
function check_ajax_referer($action,$key,$die=true){return $GLOBALS['test_nonce']??true;}
function wp_send_json_success($data){throw new TestJSON($data,true);}
function wp_send_json_error($data,$status=null){throw new TestJSON($data,false);}

/** Explicit fixture for legacy financial tests: the cashier POST succeeds before the document POST. */
function with_legacy_cashier($handler){return function($u,$a)use($handler){if(strpos($u,'/CashierLogin')!==false){check($a['method']==='POST');check(json_decode($a['body'],true)===['machineName'=>rkw_settings()['machine_name']]);return ['code'=>200,'body'=>'[]'];}return$handler($u,$a);};}
