(() => {
 'use strict';
 const root=document.querySelector('.rkw-manual');if(!root)return;
 const cfg=window.rkwManualOrders||{},el=id=>document.getElementById('rkw-manual-'+id);
 let busy=false,marked=false;
 const fa=new Intl.NumberFormat('fa-IR',{maximumFractionDigits:2});
 const date=value=>{if(!value)return '—';try{return new Intl.DateTimeFormat('fa-IR-u-ca-persian',{year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',timeZone:'Asia/Tehran'}).format(new Date(value));}catch(_){return '—';}};
 function node(tag,text,className){const n=document.createElement(tag);if(text!==undefined)n.textContent=String(text);if(className)n.className=className;return n;}
 function feedback(text,error=false){el('status').textContent=text;el('status').classList.toggle('is-error',error);}
 function controls(value){busy=value;root.querySelectorAll('input,button').forEach(n=>{n.disabled=value;});el('register').disabled=value||marked;el('unmark').hidden=!marked;}
 function hide(){el('preview').hidden=true;el('detail').replaceChildren();}
 function render(p){
  marked=!!p.manual_recorded;const target=el('detail');target.replaceChildren();el('title').textContent='وضعیت سفارش #'+p.number;
  const dl=node('dl',undefined,'rkwm-detail-grid');
  for(const [label,value]of[['شماره سفارش',p.number],['خریدار',p.buyer],['وضعیت ووکامرس',p.status],['تاریخ سفارش',date(p.date)],['مبلغ سفارش',fa.format(Number(p.total)||0)+' '+({IRT:'تومان',IRR:'ریال'}[p.currency]||p.currency||'')],['وضعیت علامت دستی',marked?'در راهکاران ثبت شد — علامت مدیر':'بدون علامت دستی'],['شناسه راهکاران',p.document]]){dl.append(node('dt',label),node('dd',value||'—'));}
  if(p.mark_audit?.time)dl.append(node('dt','آخرین تغییر علامت'),node('dd',date(Number(p.mark_audit.time)*1000)));
  target.append(dl);el('edit').href=p.edit_url;el('preview').hidden=false;
  el('result').textContent=marked?'این علامت با اعلام مدیر ذخیره شده است؛ سند تازه‌ای صادر نشده و تأیید سرویس دریافت نشده است.':'از این بخش هیچ سفارشی به راهکاران ارسال نمی‌شود.';
 }
 async function run(mode){
  if(busy)return;const code=el('code').value.trim();if(!code){feedback('شماره سفارش ووکامرس را وارد کنید.',true);return;}
  if(mode==='mark'&&marked)return;
  controls(true);hide();feedback(mode==='lookup'?'در حال دریافت وضعیت سفارش…':mode==='mark'?'در حال ذخیره علامت ثبت دستی…':'در حال برداشتن علامت دستی…');
  try{
   const action={lookup:'rkw_manual_lookup_mark',mark:'rkw_manual_mark_code',unmark:'rkw_manual_unmark_code'}[mode];
   const response=await fetch(cfg.ajax,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({action,nonce:cfg.nonce||'',code,confirm:mode==='lookup'?'0':'1'})});
   const json=await response.json();if(!response.ok||!json.success)throw new Error(json.data?.message||'وضعیت سفارش دریافت نشد.');
   const result=json.data,p=mode==='lookup'?result:result.details;render(p);
   document.dispatchEvent(new CustomEvent('rkw-order-result',{detail:{id:p.id,status:p.manual_recorded?'manual_recorded':'manual_unmarked',manual_recorded:!!p.manual_recorded,state:p.state,document:p.document,message:mode==='lookup'?(p.manual_recorded?'این سفارش قبلاً با اعلام مدیر علامت ثبت دستی خورده است.':'وضعیت سفارش دریافت شد.'):result.message,details:p}}));
   feedback(mode==='lookup'?(marked?'این سفارش علامت ثبت دستی دارد؛ برای اصلاح می‌توانید علامت را بردارید.':'وضعیت دریافت شد؛ اگر سفارش را قبلاً دستی در راهکاران ثبت کرده‌اید، دکمه علامت را بزنید.'):result.message);
  }catch(error){feedback((mode==='lookup'?'دریافت وضعیت انجام نشد: ':'نتیجه تغییر علامت تأیید نشد؛ با «نمایش وضعیت سفارش» بررسی کنید: ')+(error.message||'پاسخ دریافت نشد.'),true);}
  finally{controls(false);}
 }
 el('code-form').addEventListener('submit',event=>{event.preventDefault();run('mark');});
 el('lookup').addEventListener('click',()=>run('lookup'));el('refresh').addEventListener('click',()=>run('lookup'));el('unmark').addEventListener('click',()=>run('unmark'));el('close').addEventListener('click',hide);
 el('code').addEventListener('input',()=>{if(busy)return;marked=false;hide();controls(false);feedback('شماره سفارش ثبت‌شده به‌صورت دستی را وارد کنید.');});
})();
