(function ($) {
    'use strict';
    $(function () {
        var config = window.rkwProductView;
        if (!config || !config.product || window.rkwProductViewStarted) { return; }
        window.rkwProductViewStarted = true;
        var $summary = $('.product .summary').first();
        if (!$summary.length) { return; }

        function display(data) {
            if (!data) { return; }
            var $price = $summary.children('.price').first();
            if ($price.length && typeof data.price_html === 'string') { $price.html(data.price_html); }
            var $form = $summary.find('form.cart').first();
            if (!$form.length && data.cart_html) {
                $summary.append(data.cart_html);
                $form = $summary.find('form.cart').first();
                if ($form.is('.variations_form') && $.fn.wc_variation_form) { $form.wc_variation_form(); }
            }
            if (data.variable) {
                if ($form.is('.variations_form')) {
                    // Native WooCommerce holds its own copy of variationData;
                    // changing only the HTML attribute or jQuery cache is insufficient.
                    if (Array.isArray(data.variations) || data.variations === false) {
                        $form.data('product_variations', data.variations);
                        $form.trigger('reload_product_variations');
                    }
                }
                return;
            }
            var $stock = $summary.children('.stock').first();
            if ($stock.length) { $stock.replaceWith(data.stock_html || ''); }
            else if (data.stock_html) {
                if ($form.length) { $form.before(data.stock_html); }
                else { $summary.append(data.stock_html); }
            }
            if ($form.length) {
                $form.toggle(!!data.in_stock && !!data.purchasable);
                $form.find('.single_add_to_cart_button').prop('disabled', !data.in_stock || !data.purchasable);
                var $quantity = $form.find('input.qty').first();
                if (typeof data.quantity_max === 'number') {
                    if (data.quantity_max >= 0) {
                        $quantity.attr('max', data.quantity_max);
                        if (Number($quantity.val()) > data.quantity_max) { $quantity.val(data.quantity_max).trigger('change'); }
                    } else { $quantity.removeAttr('max'); }
                }
                if (typeof data.quantity_min === 'number') {
                    $quantity.attr('min', data.quantity_min);
                    if (data.in_stock && (!Number.isFinite(Number($quantity.val())) || Number($quantity.val()) < data.quantity_min)) {
                        $quantity.val(data.quantity_min).trigger('change');
                    }
                }
            }
        }

        async function run() {
            var cursor = 0, retries = 0;
            for (var steps = 0; steps < 1000; steps++) {
                var controller = new AbortController();
                var timer = setTimeout(function () { controller.abort(); }, 45000);
                try {
                    var body = new URLSearchParams({
                        action: 'rkw_product_view', product_id: String(config.product), cursor: String(cursor),
                        include_cart: $summary.find('form.cart').length ? '0' : '1'
                    });
                    var response = await fetch(config.ajax, {
                        method: 'POST', credentials: 'same-origin', cache: 'no-store',
                        headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'},
                        body: body.toString(), signal: controller.signal
                    });
                    var json = await response.json();
                    if (!response.ok || !json.success || !json.data) { return; }
                    var data = json.data;
                    display(data.display);
                    if (data.status === 'busy' && Number.isInteger(data.retry_cursor) && retries++ < 10) {
                        cursor = data.retry_cursor;
                        await new Promise(function (resolve) { setTimeout(resolve, 2000); });
                        continue;
                    }
                    retries = 0;
                    if (data.done) { return; }
                    if (!Number.isInteger(data.cursor) || data.cursor <= cursor) { return; }
                    cursor = data.cursor;
                } catch (error) {
                    // Preserve the existing page on a failed refresh; the checkout
                    // stock guard remains responsible for authorizing payment.
                    return;
                } finally { clearTimeout(timer); }
            }
        }
        run();
    });
}(jQuery));
