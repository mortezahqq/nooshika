/* global rkwDocumentProbe */
(() => {
 'use strict';
 const button=document.getElementById('rkw-document-probe');if(!button)return;
 const input=document.getElementById('rkw-payment-order-id'),out=document.getElementById('rkw-payment-diagnose-output'),cfg=window.rkwDocumentProbe||{};
 const reference=document.getElementById('rkw-receipt-reference'),referenceId=document.getElementById('rkw-reference-invoice-id');
 const numberInput=document.getElementById('rkw-reference-invoice-number'),search=document.getElementById('rkw-reference-number-search'),stop=document.getElementById('rkw-reference-number-stop'),results=document.getElementById('rkw-reference-number-results');
 const controls=[input,button,reference,referenceId,numberInput,search,document.getElementById('rkw-payment-diagnose'),document.getElementById('rkw-invoice-calculate')].filter(Boolean);
 let busy=false;
 let searchState=null,stopped=false;
 async function request(action,fields){
  const response=await fetch(cfg.ajax,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({action,nonce:cfg.nonce||'',...fields})});
  const data=await response.json();if(!response.ok||!data.success)throw new Error(data.data?.message||'پاسخ بررسی خوانده نشد.');return data.data;
 }
 button.addEventListener('click',async()=>{
  if(busy)return;out.style.display='block';out.dir='rtl';
  const id=input.value.trim();if(!/^[1-9][0-9]*$/.test(id)){out.textContent='شناسه سفارش معتبر وارد کنید.';return;}
  if(controls.some(n=>n.disabled)){out.textContent='بررسی قبلی هنوز در حال اجراست؛ پس از پایان آن ادامه دهید.';return;}
  busy=true;controls.forEach(n=>{n.disabled=true;});out.textContent='در حال دریافت تعریف‌های زنده؛ هیچ فاکتوری صادر نمی‌شود…';
  try{
   let r=await request('rkw_document_probe_start',{order_id:id}),previous=-1,steps=0;
   out.textContent=r.text;
   while(!r.done){
    if(!r.token||!Number.isInteger(r.completed)||r.completed<=previous||++steps>20)throw new Error('پیشرفت بررسی تأیید نشد؛ هیچ درخواستی برای ثبت سند انجام نشد.');
    previous=r.completed;r=await request('rkw_document_probe_step',{order_id:id,token:r.token});out.textContent=r.text;
   }
  }catch(error){out.textContent+='\nبررسی کامل نشد: '+(error.message||'پاسخ دریافت نشد.')+'\nاین دکمه برای ثبت فاکتور نیست؛ تلاش مجدد خودکار انجام نشد.';}
  finally{busy=false;controls.forEach(n=>{n.disabled=false;});}
 });
 reference?.addEventListener('click',async()=>{
  if(busy)return;out.style.display='block';out.dir='rtl';
  const id=referenceId.value.trim();if(!/^[1-9][0-9]*$/.test(id)){out.textContent='شناسه داخلی فاکتور راهکاران را وارد کنید؛ این فیلد شماره سفارش ووکامرس نیست.';return;}
  if(controls.some(n=>n.disabled)){out.textContent='بررسی قبلی هنوز در حال اجراست؛ پس از پایان آن ادامه دهید.';return;}
  busy=true;controls.forEach(n=>{n.disabled=true;});out.textContent='خواندن دریافت فاکتور موجود #'+id+'؛ بدون ثبت یا تغییر سند…\n';
  try{
   let verified=false;
   for(const contract of ['legacy_esales','v21']){
    const r=await request('rkw_receipt_reference',{invoice_id:id,contract});out.textContent+='\n'+contract+'\n'+r.text+'\n';
    verified=verified||(r.report?.status==='read'&&r.report.identity_verified===true);
   }
   out.textContent+='\n'+(verified?'مشخصات یک سند با شناسه داخلی منطبق خوانده شد.':'خواندن فاکتور تأیید نشد؛ خطای پاسخ سرویس به‌تنهایی به معنی اشتباه‌بودن شناسه یا نبود فاکتور نیست. جزئیات response_shape را بررسی کنید.')+' ساختار پاسخ، قرارداد JSON ثبت نیست. هیچ فاکتوری صادر یا تغییر داده نشد.';
  }catch(error){out.textContent+='\nخواندن کامل نشد: '+(error.message||'پاسخ دریافت نشد.')+'\nثبت سند یا تلاش مجدد خودکار انجام نشد.';}
  finally{busy=false;controls.forEach(n=>{n.disabled=false;});}
 });
 const digits=value=>value.replace(/[۰-۹]/g,c=>String('۰۱۲۳۴۵۶۷۸۹'.indexOf(c))).replace(/[٠-٩]/g,c=>String('٠١٢٣٤٥٦٧٨٩'.indexOf(c)));
 numberInput?.addEventListener('input',()=>{searchState=null;search.textContent='یافتن شناسه از شماره فاکتور';results.replaceChildren();});
 stop?.addEventListener('click',()=>{stopped=true;stop.textContent='توقف پس از پاسخ فعلی…';});
 search?.addEventListener('click',async()=>{
  if(busy)return;
  const number=digits(numberInput.value.trim()).replace(/^0+/,'');
  if(!/^[1-9][0-9]{0,19}$/.test(number)){results.textContent='شماره عددی فاکتور داخل راهکاران را وارد کنید.';return;}
  if(controls.some(n=>n.disabled)){results.textContent='بررسی قبلی هنوز در حال اجراست.';return;}
  if(!searchState||searchState.number!==number||searchState.done){searchState={number,page:1,scanned:0,connection:'',fingerprints:new Set(),matches:new Map(),done:false};results.replaceChildren();}
  const state=searchState;busy=true;stopped=false;controls.forEach(n=>{n.disabled=true;});stop.hidden=false;stop.textContent='توقف جست‌وجو';
  const status=document.createElement('p');results.append(status);
  try{
   for(let i=0;i<10&&!stopped&&!state.done;i++){
    status.textContent='در حال خواندن صفحه '+state.page+'؛ '+state.scanned+' فاکتور بررسی شده…';
    const r=await request('rkw_reference_number',{invoice_number:number,page:String(state.page),connection:state.connection});
    if(r.page!==state.page||!Array.isArray(r.matches)||!Number.isInteger(r.scanned)||typeof r.connection!=='string'||typeof r.page_fingerprint!=='string')throw new Error('قالب نتیجه جست‌وجو معتبر نیست.');
    if(state.fingerprints.has(r.page_fingerprint)&&r.scanned>0){state.done=true;status.textContent='سرویس صفحه تکراری برگرداند؛ جست‌وجو متوقف شد. نبود فاکتور ثابت نشده است.';break;}
    state.fingerprints.add(r.page_fingerprint);state.connection=r.connection;state.scanned+=r.scanned;state.page++;state.done=!r.has_more;
    for(const m of r.matches){
     if(!Number.isSafeInteger(m.id)||m.id<=0||state.matches.has(m.id))continue;state.matches.set(m.id,m);
     const row=document.createElement('p'),choose=document.createElement('button');choose.type='button';choose.className='button';choose.textContent='خواندن دریافتِ شناسه '+m.id;
     row.append(document.createTextNode('شماره '+m.number+' | شناسه داخلی '+m.id+' | تاریخ '+(m.date||'نامشخص')+' | مبلغ '+(m.amount??'نامشخص')+' | سیاست '+(m.policy_id||'نامشخص')+' '));
     choose.addEventListener('click',()=>{if(busy)return;referenceId.value=String(m.id);reference.click();});row.append(choose);results.append(row);
    }
    status.textContent=state.scanned+' فاکتور قابل مشاهده بررسی شد؛ '+state.matches.size+' مورد منطبق. '+(state.done?'پایان فهرست یا توقف بررسی؛ نبود فاکتور در کل راهکاران ثابت نشده است.':'برای صفحات بعد، «ادامه جست‌وجو» را بزنید.');
    if(r.matches.length)break;
   }
   if(state.matches.size)status.textContent+=' شماره ممکن است تکراری باشد؛ تاریخ و مشخصات نتیجه را تطبیق دهید و مورد درست را برای خواندن انتخاب کنید.';
  }catch(error){status.textContent='جست‌وجو کامل نشد: '+(error.message||'پاسخ دریافت نشد.')+'؛ '+state.scanned+' فاکتور بررسی شده. ارسال سندی انجام نشد.';}
  finally{busy=false;stop.hidden=true;controls.forEach(n=>{n.disabled=false;});search.textContent=state.done?'جست‌وجو از ابتدا':'ادامه جست‌وجو';}
 });
})();
