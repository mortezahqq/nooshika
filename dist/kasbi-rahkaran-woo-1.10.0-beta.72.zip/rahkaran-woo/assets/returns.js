/* global rkwReturns */
(function () {
  'use strict';
  if (typeof rkwReturns === 'undefined') return;
  const modal = document.getElementById('rkw-return-modal');
  if (!modal) return;
  const form = document.getElementById('rkw-return-form');
  const feedback = document.getElementById('rkw-return-feedback');
  const policy = document.getElementById('rkw-return-policy');
  const method = document.getElementById('rkw-return-method');
  const submit = document.getElementById('rkw-return-submit');
  const close = document.getElementById('rkw-return-close');
  const consent = document.getElementById('rkw-return-confirm');
  let prepared = null;
  let previousFocus = null;
  let busy = false;
  let requestId = 0;

  function options(select, values, placeholder) {
    select.replaceChildren();
    const blank = document.createElement('option');
    blank.value = ''; blank.textContent = placeholder; select.appendChild(blank);
    values.forEach(item => {
      const option = document.createElement('option');
      option.value = String(item.id); option.textContent = item.label;
      select.appendChild(option);
    });
  }
  function methodFields() {
    const banking = ['EReceipt', 'BankReceipt'].includes(method.value);
    const coupon = method.value === 'ThirdPartyCoupon';
    document.getElementById('rkw-return-bank-fields').hidden = !banking;
    document.getElementById('rkw-return-coupon-field').hidden = !coupon;
    ['rkw-return-bank', 'rkw-return-transaction'].forEach(id => { document.getElementById(id).required = banking; });
    document.getElementById('rkw-return-coupon').required = coupon;
  }
  policy.addEventListener('change', () => {
    const selected = prepared && prepared.policies.find(item => String(item.id) === policy.value);
    const labels = {Cash: 'نقد (Cash)', BankReceipt: 'بانکی (BankReceipt)', EReceipt: 'الکترونیک (EReceipt)', ThirdPartyCoupon: 'بن سازمانی (ThirdPartyCoupon)'};
    options(method, selected ? selected.keys.map(key => ({id: key, label: labels[key] || key})) : [], 'انتخاب روش پرداخت برگشت');
    // The method is deliberately selected by the manager, including single-method policies.
    methodFields();
  });
  method.addEventListener('change', methodFields);

  async function request(action, values) {
    const response = await fetch(rkwReturns.ajax, {
      method: 'POST', credentials: 'same-origin',
      headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'},
      body: new URLSearchParams(Object.assign({action: action, nonce: rkwReturns.nonce}, values)).toString()
    });
    const json = await response.json();
    if (!response.ok || !json.success) {
      const error = new Error(json && json.data && json.data.message ? json.data.message : 'پاسخ ثبت برگشت قابل تأیید نیست؛ نتیجه را در راهکاران بررسی کنید.');
      error.returnStatus = json && json.data && json.data.return_status;
      throw error;
    }
    return json.data;
  }
  function updateButtons(invoiceId, status) {
    document.querySelectorAll('.rkw-return-invoice[data-invoice="' + invoiceId + '"]').forEach(button => {
      button.textContent = status.state === 'returned' ? 'برگشت از فروش #' + status.id : 'برگشت نیازمند بررسی';
      button.disabled = true;
    });
  }
  function dismiss() {
    if (busy) return;
    ++requestId; modal.hidden = true;
    if (previousFocus && previousFocus.isConnected) previousFocus.focus();
  }
  close.addEventListener('click', dismiss);
  modal.addEventListener('click', event => { if (event.target === modal) dismiss(); });
  document.addEventListener('keydown', event => {
    if (modal.hidden) return;
    if (event.key === 'Escape') dismiss();
    if (event.key === 'Tab') {
      const focusable = [...modal.querySelectorAll('button,input,select')].filter(el => !el.disabled && !el.closest('[hidden]'));
      const first = focusable[0], last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    }
  });
  document.addEventListener('click', async event => {
    const button = event.target.closest('.rkw-return-invoice');
    if (!button || button.disabled || busy) return;
    const id = Number(button.dataset.invoice);
    if (!Number.isSafeInteger(id) || id < 1) return;
    event.preventDefault(); previousFocus = button;
    const token = ++requestId;
    prepared = null; form.reset(); form.hidden = true; modal.hidden = false;
    close.focus(); feedback.textContent = 'در حال دریافت فاکتور اصلی و الگوی برگشت از راهکاران…';
    try {
      const data = await request('rkw_return_prepare', {invoice_id: id});
      if (token !== requestId || modal.hidden) return;
      prepared = data;
      document.getElementById('rkw-return-summary').textContent = 'فاکتور #' + id + ' | تعداد ردیف: ' + data.item_count + ' | مبلغ برگشت کامل: ' + new Intl.NumberFormat('fa-IR').format(data.amount) + ' ' + data.currency;
      options(policy, data.policies.map(item => ({id: item.id, label: item.id + ' — ' + item.title})), 'انتخاب سیاست تسویه برگشت');
      policy.value = data.policies.some(item => Number(item.id) === Number(data.policy_id)) ? String(data.policy_id) : '';
      policy.dispatchEvent(new Event('change'));
      feedback.textContent = 'روش تسویه را انتخاب و ثبت برگشت کامل را تأیید کنید.';
      submit.disabled = false; form.hidden = false;
    } catch (error) {
      if (token === requestId && !modal.hidden) {
        feedback.textContent = error.message;
        if (error.returnStatus && ['pending', 'returned'].includes(error.returnStatus.state)) updateButtons(id, error.returnStatus);
      }
    }
  });
  form.addEventListener('submit', async event => {
    event.preventDefault();
    if (busy || !prepared || !consent.checked || !form.reportValidity()) return;
    const id = prepared.invoice_id;
    busy = true; submit.disabled = true; close.disabled = true;
    feedback.textContent = 'در حال ثبت برگشت از فروش؛ تا پایان عملیات صفحه را باز نگه دارید…';
    try {
      const result = await request('rkw_return_submit', {
        invoice_id: id, fingerprint: prepared.fingerprint, confirm: '1',
        policy_id: policy.value, receipt_key: method.value,
        bank_account_ref: document.getElementById('rkw-return-bank').value,
        transaction_number: document.getElementById('rkw-return-transaction').value,
        coupon_type_id: document.getElementById('rkw-return-coupon').value
      });
      feedback.textContent = result.message;
      updateButtons(id, result.return_status); form.hidden = true;
    } catch (error) {
      feedback.textContent = error.message;
      if (error.returnStatus && ['pending', 'returned'].includes(error.returnStatus.state)) {
        updateButtons(id, error.returnStatus); form.hidden = true;
      } else if (!error.returnStatus) {
        // Network interruption cannot prove that the financial POST failed.
        updateButtons(id, {state: 'pending'}); form.hidden = true;
        feedback.textContent += ' نتیجه نامشخص است؛ قبل از ثبت دوباره، راهکاران را بررسی کنید.';
      } else { submit.disabled = false; }
    } finally { busy = false; close.disabled = false; }
  });
})();
