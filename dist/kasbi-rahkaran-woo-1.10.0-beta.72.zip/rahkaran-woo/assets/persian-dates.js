/* Local sales-invoice dates only. ISO values are submitted; all visible dates use the Persian calendar. */
(function () {
  'use strict';
  const section = document.querySelector('.rkwm-local-orders');
  if (!section) return;
  const triggers = [...section.querySelectorAll('.rkw-jalali-trigger')];
  const digits = value => String(value).replace(/[0-9]/g, n => '۰۱۲۳۴۵۶۷۸۹'[Number(n)]);
  const dayMs = 86400000;
  let partsFormat, displayFormat;
  try {
    partsFormat = new Intl.DateTimeFormat('en-u-ca-persian-nu-latn', {year: 'numeric', month: 'numeric', day: 'numeric', timeZone: 'UTC'});
    displayFormat = new Intl.DateTimeFormat('fa-IR-u-ca-persian', {year: 'numeric', month: '2-digit', day: '2-digit', timeZone: 'UTC'});
    if (partsFormat.resolvedOptions().calendar !== 'persian') throw new Error('unsupported');
  } catch (error) {
    triggers.forEach(button => { button.textContent = 'تقویم شمسی در این مرورگر پشتیبانی نمی‌شود'; button.disabled = true; });
    return;
  }
  function parse(value) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return null;
    const date = new Date(value + 'T00:00:00Z');
    return Number.isFinite(date.getTime()) && iso(date) === value ? date : null;
  }
  function iso(date) { return date.getUTCFullYear().toString().padStart(4, '0') + '-' + String(date.getUTCMonth() + 1).padStart(2, '0') + '-' + String(date.getUTCDate()).padStart(2, '0'); }
  function parts(date) {
    const result = {};
    partsFormat.formatToParts(date).forEach(part => { if (['year', 'month', 'day'].includes(part.type)) result[part.type] = Number(part.value); });
    return result;
  }
  function monthStart(date) { return new Date(date.getTime() - (parts(date).day - 1) * dayMs); }
  function nextMonth(date) { return monthStart(new Date(date.getTime() + 32 * dayMs)); }
  function findMonth(year, month) {
    // Search the native Persian calendar rather than approximate a leap-year cycle.
    let low = Math.floor(Date.UTC(year + 620, 0, 1) / dayMs);
    let high = Math.floor(Date.UTC(year + 623, 0, 1) / dayMs);
    const wanted = year * 10000 + month * 100 + 1;
    while (low <= high) {
      const middle = Math.floor((low + high) / 2), date = new Date(middle * dayMs), p = parts(date);
      const value = p.year * 10000 + p.month * 100 + p.day;
      if (value === wanted) return date;
      if (value < wanted) low = middle + 1; else high = middle - 1;
    }
    return null;
  }
  function node(tag, text, cls) {
    const element = document.createElement(tag);
    if (text !== undefined) element.textContent = text;
    if (cls) element.className = cls;
    return element;
  }
  function button(text, action, cls) {
    const element = node('button', text, cls || 'button'); element.type = 'button'; element.addEventListener('click', action); return element;
  }
  const today = parse(section.dataset.rkwToday) || new Date(new Date().toISOString().slice(0, 10) + 'T00:00:00Z');
  section.querySelectorAll('[data-rkw-persian-date]').forEach(element => {
    const date = parse(element.dataset.rkwPersianDate);
    if (date) element.textContent = displayFormat.format(date) + (element.dataset.rkwTime ? ' — ' + digits(element.dataset.rkwTime) : '');
  });
  const dialog = node('dialog', undefined, 'rkw-jalali-picker'); dialog.id = 'rkw-jalali-picker'; dialog.dir = 'rtl'; dialog.setAttribute('aria-labelledby', 'rkw-jalali-title');
  const title = node('h3', 'انتخاب تاریخ شمسی'); title.id = 'rkw-jalali-title'; dialog.appendChild(title);
  const header = node('div', undefined, 'rkw-jalali-header');
  const month = node('select'); month.setAttribute('aria-label', 'ماه شمسی');
  const monthNames = ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];
  monthNames.forEach((name, index) => { const option = node('option', name); option.value = String(index + 1); month.appendChild(option); });
  const year = node('select'); year.setAttribute('aria-label', 'سال شمسی');
  let active = null, input = null, view = monthStart(today);
  const previous = button('‹', () => { view = monthStart(new Date(view.getTime() - dayMs)); render(); }); previous.setAttribute('aria-label', 'ماه قبل');
  const next = button('›', () => { view = nextMonth(view); render(); }); next.setAttribute('aria-label', 'ماه بعد');
  header.append(previous, month, year, next); dialog.appendChild(header);
  const table = node('table', undefined, 'rkw-jalali-grid'); table.setAttribute('aria-label', 'روزهای ماه شمسی');
  const head = node('thead'), headings = node('tr');
  ['شنبه', 'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه'].forEach(name => { const cell = node('th', name.slice(0, 1)); cell.scope = 'col'; cell.title = name; headings.appendChild(cell); });
  head.appendChild(headings); table.appendChild(head);
  const body = node('tbody'); table.appendChild(body); dialog.appendChild(table);
  const footer = node('div', undefined, 'rkw-jalali-footer');
  function refreshTrigger(trigger) {
    const date = parse(document.getElementById(trigger.dataset.rkwDateInput).value);
    trigger.textContent = date ? displayFormat.format(date) : 'انتخاب تاریخ شمسی';
  }
  function choose(date) {
    input.value = date ? iso(date) : '';
    input.dispatchEvent(new Event('change', {bubbles: true})); refreshTrigger(active); dialog.close();
  }
  footer.append(button('امروز', () => choose(today)), button('پاک کردن تاریخ', () => choose(null)), button('بستن', () => dialog.close()));
  dialog.appendChild(footer); section.appendChild(dialog);
  function render(focusDate) {
    const p = parts(view), currentYear = parts(today).year;
    year.replaceChildren();
    for (let value = Math.min(currentYear - 100, p.year); value <= Math.max(currentYear + 20, p.year); value++) { const option = node('option', digits(value)); option.value = String(value); year.appendChild(option); }
    month.value = String(p.month); year.value = String(p.year);
    table.setAttribute('aria-label', monthNames[p.month - 1] + ' ' + digits(p.year));
    const length = Math.round((nextMonth(view) - view) / dayMs), offset = (view.getUTCDay() + 1) % 7;
    body.replaceChildren();
    let row;
    for (let index = 0; index < Math.ceil((length + offset) / 7) * 7; index++) {
      if (index % 7 === 0) { row = node('tr'); body.appendChild(row); }
      const cell = node('td'), day = index - offset + 1; row.appendChild(cell);
      if (day < 1 || day > length) continue;
      const date = new Date(view.getTime() + (day - 1) * dayMs), value = iso(date);
      const pick = button(digits(day), () => choose(date), 'rkw-jalali-day'); pick.dataset.date = value;
      pick.setAttribute('aria-label', digits(day) + ' ' + monthNames[p.month - 1] + ' ' + digits(p.year));
      if (input.value === value) { pick.classList.add('is-selected'); pick.setAttribute('aria-pressed', 'true'); }
      if (iso(today) === value) pick.setAttribute('aria-current', 'date');
      pick.addEventListener('keydown', event => {
        const movement = {ArrowLeft: 1, ArrowRight: -1, ArrowDown: 7, ArrowUp: -7}[event.key];
        if (!movement) return;
        event.preventDefault(); const target = new Date(date.getTime() + movement * dayMs); view = monthStart(target); render(iso(target));
      });
      cell.appendChild(pick);
    }
    if (focusDate) { const target = body.querySelector('[data-date="' + focusDate + '"]'); if (target) target.focus(); }
  }
  [month, year].forEach(select => select.addEventListener('change', () => { const target = findMonth(Number(year.value), Number(month.value)); if (target) { view = target; render(); } }));
  dialog.addEventListener('close', () => { if (active) { active.setAttribute('aria-expanded', 'false'); active.focus(); } });
  dialog.addEventListener('click', event => { if (event.target !== dialog) return; const rect = dialog.getBoundingClientRect(); if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) dialog.close(); });
  triggers.forEach(trigger => {
    refreshTrigger(trigger);
    trigger.addEventListener('click', () => {
      active = trigger; input = document.getElementById(trigger.dataset.rkwDateInput); view = monthStart(parse(input.value) || today); render();
      trigger.setAttribute('aria-expanded', 'true'); dialog.showModal();
      const selected = body.querySelector('.is-selected') || body.querySelector('[aria-current="date"]') || body.querySelector('button'); if (selected) selected.focus();
    });
  });
})();
