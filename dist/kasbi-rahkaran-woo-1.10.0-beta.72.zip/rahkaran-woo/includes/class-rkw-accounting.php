<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Build every order component explicitly; never balance an invoice by inventing money. */
class RKW_Accounting {
	public static function sanitize_shipping_rules( $input ) {
		$out = array();
		foreach ( is_array( $input ) ? array_slice( $input, 0, 40 ) : array() as $rule ) {
			if ( ! is_array( $rule ) || empty( $rule['method'] ) || empty( $rule['id'] ) ) { continue; }
			if ( ! is_scalar( $rule['method'] ) || ! is_scalar( $rule['id'] ) ) { continue; }
			$method = sanitize_text_field( $rule['method'] );
			$id = absint( $rule['id'] );
			if ( '' === $method || ! $id ) { continue; }
			$out[] = array( 'method' => $method, 'id' => $id );
		}
		return $out;
	}
	public static function render_shipping_rules( $s ) {
		echo '<p class="rkwe-hint">قانون حمل: شناسه روش ووکامرس (مثل flat_rate یا flat_rate:2)، یا عنوان روش قدیمی. شناسه مقصد مطابق روش انتقال، سیاست یا کالا است.</p>';
		$rules = array_merge( (array) $s['shipping_rules'], array( array() ) );
		foreach ( $rules as $i => $rule ) {
			echo '<div class="rkwe-field"><input name="ext[shipping_rules][' . (int) $i . '][method]" placeholder="روش حمل" value="' . esc_attr( isset( $rule['method'] ) ? $rule['method'] : '' ) . '"><input type="number" min="0" name="ext[shipping_rules][' . (int) $i . '][id]" placeholder="شناسه مقصد" value="' . esc_attr( isset( $rule['id'] ) ? $rule['id'] : 0 ) . '"></div>';
		}
	}
	/** Match the legacy WC_Utility::normalizeShippingTitle convention, without fuzzy search. */
	public static function legacy_shipping_title( $title ) {
		$title = (string) $title;
		$title = preg_replace( '/\([^)]*\)|\[[^\]]*\]/u', '', $title );
		$title = str_replace( array( '-', '–', '—', '_' ), '', $title );
		$title = preg_replace( '/[0-9,]+\s*(?:تومان|ریال)|[0-9,]+/u', '', $title );
		$title = str_replace( array( ':', '.', ',', '/', '\\' ), '', $title );
		return trim( preg_replace( '/\s+/u', ' ', $title ) );
	}
	/** Numeric routing evidence only; no customer address, shipping title or remote writes. */
	public static function shipping_mapping( $order, $ext ) {
		$kind = 'product' === $ext['shipping_mode'] ? 'product' : 'policy';
		$default = (int) $ext[ 'product' === $kind ? 'shipping_product_id' : 'shipping_policy_id' ];
		$methods = $order->get_shipping_methods();
		$base = array( 'enabled' => ! empty( $ext['shipping_enabled'] ), 'kind' => $kind, 'id' => $default, 'source' => 'default', 'default_id' => $default, 'rule_count' => count( (array) $ext['shipping_rules'] ), 'method_count' => count( $methods ), 'matching_rules' => 0 );
		foreach ( $methods as $method ) {
			$title = (string) $method->get_name();
			$normal = self::legacy_shipping_title( $title );
			$levels = array(
				'instance_rule' => $method->get_method_id() . ':' . $method->get_instance_id(),
				'method_rule' => $method->get_method_id(),
				'title_rule' => $title,
				'legacy_title_rule' => $normal,
			);
			foreach ( $levels as $source => $key ) {
				if ( '' === $key ) { continue; }
				$ids = array(); $matched = 0;
				foreach ( (array) $ext['shipping_rules'] as $rule ) {
					if ( ! is_array( $rule ) || empty( $rule['method'] ) || empty( $rule['id'] ) ) { continue; }
					if ( 'legacy_title_rule' === $source && preg_match( '/^[A-Za-z0-9_-]+:[0-9]+$/D', (string) $rule['method'] ) ) { continue; }
					$rule_key = 'legacy_title_rule' === $source ? self::legacy_shipping_title( $rule['method'] ) : (string) $rule['method'];
					if ( $rule_key === $key && (int) $rule['id'] > 0 ) { $ids[ (int) $rule['id'] ] = true; $matched++; }
				}
				if ( count( $ids ) > 1 ) { return new WP_Error( 'rkw_shipping_ambiguous', 'چند قانون حمل با شناسه‌های مقصد متفاوت به روش حمل سفارش منطبق است؛ قوانین را با شناسه روش و نمونهٔ آن مشخص کنید. هیچ سیاستی به‌صورت حدسی انتخاب نشد.' ); }
				if ( $ids ) { $base['id'] = (int) key( $ids ); $base['source'] = $source; $base['matching_rules'] = $matched; return $base; }
			}
		}
		return $base;
	}
	private static function policy( &$payload, $id, $amount, $decrease = false ) {
		$row = array( 'policyId' => (int) $id, 'price' => round( $amount, 2 ), 'isIncluded' => true );
		if ( $decrease ) { $row['effect'] = 1; }
		$payload['document']['policies'][] = $row;
	}
	private static function adjust_receipt( &$payload, $delta ) {
		if ( isset( $payload['receipts'][0]['amount'] ) ) {
			$payload['receipts'][0]['amount'] = round( (float) $payload['receipts'][0]['amount'] + $delta, 2 );
		}
	}
	public static function extend_payload( $payload, $order, $s, $ext ) {
		if ( is_wp_error( $payload ) || 'v21' !== $s['api'] ) { return $payload; }
		if ( ! isset( $payload['document']['policies'] ) ) { $payload['document']['policies'] = array(); }
		$mult = rkw_price_multiplier( $s );
		$shipping = round( ( $order->get_shipping_total() + $order->get_shipping_tax() ) * $mult, 2 );
		if ( $shipping > 0 ) {
			$mapping = self::shipping_mapping( $order, $ext );
			if ( is_wp_error( $mapping ) ) { return $mapping; }
			$id = $mapping['id'];
			if ( empty( $ext['shipping_enabled'] ) ) {
				return new WP_Error( 'rkw_shipping_missing', sprintf( 'هزینه حمل %s است و گزینهٔ انتقال هزینه حمل غیرفعال است. در امکانات تکمیلی آن را فعال و تنظیمات را ذخیره کنید.', $shipping ) );
			}
			if ( ! $id ) {
				$methods = array();
				foreach ( $order->get_shipping_methods() as $method ) {
					$methods[] = sanitize_text_field( $method->get_method_id() . ':' . $method->get_instance_id() );
				}
				return new WP_Error( 'rkw_shipping_missing', sprintf( 'هزینه حمل %s است. قانون حملی برای روش %s منطبق نشد و شناسه پیش‌فرض حمل هم خالی است. قانون روش ارسال یا پیش‌فرض را در امکانات تکمیلی تنظیم کنید.', $shipping, $methods ? implode( '، ', $methods ) : 'ثبت‌نشده' ) );
			}
			if ( 'product' === $ext['shipping_mode'] ) {
				$unit = ! empty( $ext['shipping_unit_id'] ) ? (int) $ext['shipping_unit_id'] : (int) $s['default_unit_id'];
				if ( ! $unit ) { return new WP_Error( 'rkw_shipping_unit', 'شناسه واحد کالای خدمات حمل مشخص نیست.' ); }
				$payload['document']['items'][] = array( 'Id' => 0, 'inventoryId' => (int) $s['inventory_id'], 'storeId' => (int) $s['inventory_id'], 'productId' => $id, 'unitId' => $unit, 'quantity' => 1, 'fee' => $shipping, 'price' => $shipping, 'settlementPolicyId' => (int) $payload['document']['settlementPolicyId'], 'policies' => array(), 'toppings' => array() );
			} else {
				self::policy( $payload, $id, $shipping );
			}
			self::adjust_receipt( $payload, $shipping );
		}
		$loyalty_label = $order->get_meta( '_rkw_loyalty_fee_label' ) ?: $ext['loyalty_fee_label'];
		foreach ( $order->get_fees() as $fee ) {
			$amount = round( ( $fee->get_total() + $fee->get_total_tax() ) * $mult, 2 );
			if ( 0.0 === $amount ) { continue; }
			// Loyalty is a tender, not a sales discount; its module adds the separate receipt.
			if ( $fee->get_name() === $loyalty_label && $amount < 0 ) { continue; }
			if ( $amount > 0 ) {
				if ( empty( $ext['extra_fee_policy_id'] ) ) { return new WP_Error( 'rkw_fee_policy', 'هزینه جانبی مثبت در سفارش وجود دارد؛ شناسه سیاست هزینه جانبی را وارد کنید.' ); }
				self::policy( $payload, $ext['extra_fee_policy_id'], $amount );
			} else {
				$is_first = $fee->get_name() === $ext['first_fee_label'];
				$id = $is_first ? $ext['first_policy_id'] : $ext['negative_fee_policy_id'];
				if ( ! $id || ( $is_first && empty( $ext['first_enabled'] ) ) ) { return new WP_Error( 'rkw_negative_fee_policy', 'هزینه منفی سفارش سیاست تخفیف معتبر ندارد؛ سیاست خرید اول یا هزینه منفی را تنظیم کنید.' ); }
				if ( $is_first ) {
					if ( ! $order->get_user_id() || true !== RKW_Extensions::is_first_purchase( $order->get_user_id() ) ) { return new WP_Error( 'rkw_first_not_verified', 'استحقاق تخفیف خرید اول از راهکاران تأیید نشد.' ); }
					if ( $ext['first_policy_price'] > 0 && abs( $ext['first_policy_price'] + $amount ) > 0.01 ) { return new WP_Error( 'rkw_first_amount', 'مبلغ ثابت سیاست خرید اول با تخفیف ثبت‌شده سفارش برابر نیست.' ); }
				}
				self::policy( $payload, $id, abs( $amount ), true );
			}
			self::adjust_receipt( $payload, $amount );
		}
		return $payload;
	}
	/** Validate all tenders and the document ledger, including fully-paid-by-credit orders. */
	public static function validate( $payload, $order, $s, $payment ) {
		if ( ! is_array( $payload ) || ! isset( $payload['document']['items'] ) ) { return new WP_Error( 'rkw_ledger', 'ساختار سند مالی معتبر نیست.' ); }
		if ( ! empty( $payload['payments'] ) ) { return new WP_Error( 'rkw_outbound', 'فاکتور فروش دریافت مشتری را در receipts ثبت می‌کند؛ payments باید خالی باشد.' ); }
		$woo = round( $order->get_total() * rkw_price_multiplier( $s ), 2 );
		$loyalty = round( (float) $order->get_meta( '_rkw_loyalty_credit_amount' ) * rkw_price_multiplier( $s ), 2 );
		$expected_document = round( $woo + $loyalty, 2 );
		$document_total = 0.0;
		foreach ( $payload['document']['items'] as $item ) {
			if ( ! isset( $item['price'], $item['fee'] ) || ! is_numeric( $item['price'] ) || ! is_numeric( $item['fee'] ) || $item['price'] < 0 || $item['fee'] < 0 ) { return new WP_Error( 'rkw_item_amount', 'مبلغ ردیف کالا نامعتبر است.' ); }
			$line = (float) $item['price'];
			foreach ( isset( $item['policies'] ) ? $item['policies'] : array() as $policy ) { $line += self::policy_delta( $policy ); }
			$document_total += $line;
		}
		foreach ( isset( $payload['document']['policies'] ) ? $payload['document']['policies'] : array() as $policy ) { $document_total += self::policy_delta( $policy ); }
		if ( ! is_finite( $document_total ) || abs( $document_total - $expected_document ) > 0.01 ) { return new WP_Error( 'rkw_document_amount', 'جمع سند ' . round( $document_total, 2 ) . ' با مبلغ مورد انتظار ' . $expected_document . ' برابر نیست؛ اقلام، مالیات، حمل و سیاست‌ها بررسی شوند.' ); }
		$cash = 0.0; $credit = 0.0;
		foreach ( isset( $payload['receipts'] ) ? $payload['receipts'] : array() as $row ) {
			if ( ! isset( $row['key'], $row['amount'] ) || ! is_numeric( $row['amount'] ) || ! is_finite( (float) $row['amount'] ) || $row['amount'] < 0 ) { return new WP_Error( 'rkw_receipt_amount', 'مبلغ یا نوع دریافت معتبر نیست.' ); }
			if ( 'LoyaltyCredit' === $row['key'] ) { $credit += (float) $row['amount']; } else { $cash += (float) $row['amount']; }
		}
		if ( 'credit' === $payment['mode'] ) {
			return empty( $payload['receipts'] ) && 0.0 === $loyalty ? true : new WP_Error( 'rkw_credit_receipts', 'فاکتور نسیه نباید دریافت وجه داشته باشد.' );
		}
		if ( abs( $cash - $woo ) > 0.01 || abs( $credit - $loyalty ) > 0.01 ) { return new WP_Error( 'rkw_receipt_amount_mismatch', 'دریافت غیر وفاداری ' . round( $cash, 2 ) . ' باید برابر مبلغ سفارش ' . $woo . ' و دریافت وفاداری ' . round( $credit, 2 ) . ' باید برابر اعتبار ' . $loyalty . ' باشد.' ); }
		return true;
	}
	public static function is_calculated_discount( $policy ) {
		return in_array( $policy['effect'] ?? null, array( 3, '3' ), true )
			&& in_array( $policy['type'] ?? '', array( 'Discount', 'CustomRetailMeasurementUnitDiscount' ), true );
	}
	private static function policy_delta( $policy ) {
		if ( ! isset( $policy['price'] ) || ! is_numeric( $policy['price'] ) || ! is_finite( (float) $policy['price'] ) || $policy['price'] < 0 ) { return NAN; }
		return isset( $policy['effect'] ) && ( 'Decrease' === $policy['effect'] || 1 === $policy['effect'] || self::is_calculated_discount( $policy ) ) ? -(float) $policy['price'] : (float) $policy['price'];
	}
	/** Match an invoice calculation to its original lines in order, including split units. */
	private static function matched_snapp_lines( $document, $calculated ) {
		$expected = $document['items'] ?? null;
		$actual = $calculated['items'] ?? null;
		if ( ! is_array( $expected ) || ! is_array( $actual ) || ! $expected || count( $expected ) !== count( $actual ) ) { return array(); }
		$header_additions = array();
		foreach ( $document['policies'] ?? array() as $policy ) {
			$id = (int) ( $policy['policyId'] ?? 0 );
			$amount = self::policy_delta( $policy );
			$effect = $policy['effect'] ?? null;
			if ( $id && is_finite( $amount ) && $amount > 0 && true === ( $policy['isIncluded'] ?? null )
				&& in_array( $effect, array( null, 2, '2', 'Increase' ), true ) ) {
				$header_additions[ $id ] = ( $header_additions[ $id ] ?? 0 ) + $amount;
			}
		}
		$distributed_totals = array();
		$lines = array();
		$actual = array_values( $actual );
		foreach ( array_values( $expected ) as $i => $item ) {
			$row = $actual[ $i ];
			if ( ! is_array( $row ) || ! empty( $row['hasError'] ) ) { return array(); }
			foreach ( array( 'productId', 'unitId', 'quantity' ) as $key ) {
				if ( ! is_numeric( $row[ $key ] ?? null ) || (float) $row[ $key ] !== (float) $item[ $key ] ) { return array(); }
			}
			if ( ! is_numeric( $row['price'] ?? null ) || ! is_finite( (float) $row['price'] )
				|| abs( (float) $row['price'] - (float) $item['price'] ) > 0.01
				|| ! is_numeric( $row['netPrice'] ?? null ) || ! is_finite( (float) $row['netPrice'] ) ) { return array(); }
			$line_total = (float) $item['price'];
			foreach ( $item['policies'] ?? array() as $policy ) {
				$line_total += self::policy_delta( $policy );
			}
			if ( ! is_finite( $line_total ) ) { return array(); }
			// A header addition can be spread across returned rows. Verify each sum against the document.
			$distributed = array();
			foreach ( (array) ( $row['policies'] ?? array() ) as $policy ) {
				if ( ! is_array( $policy ) || true !== ( $policy['isIncluded'] ?? null ) ) { continue; }
				$id = (int) ( $policy['policyId'] ?? 0 );
				if ( ! isset( $header_additions[ $id ] ) || 'MiscellaneousAdditions' !== ( $policy['type'] ?? null )
					|| ! in_array( $policy['effect'] ?? null, array( 2, '2', 'Increase' ), true ) ) { continue; }
				$amount = self::policy_delta( $policy );
				if ( ! is_finite( $amount ) || isset( $distributed[ $id ] ) ) { return array(); }
				$distributed[ $id ] = $amount;
				$distributed_totals[ $id ] = ( $distributed_totals[ $id ] ?? 0 ) + $amount;
				$line_total += $amount;
			}
			$lines[] = array( 'expected' => $line_total, 'returned' => $row, 'distributed' => $distributed );
		}
		foreach ( $distributed_totals as $id => $amount ) {
			if ( abs( $amount - $header_additions[ $id ] ) > 0.01 ) { return array(); }
		}
		return $lines;
	}

	/** Ask to exclude 507 only when it accounts for the entire discrepancy on otherwise full-price lines. */
	public static function snapp_policy_exclusions( $document, $calculated, $expected_total ) {
		$lines = self::matched_snapp_lines( $document, $calculated );
		$gap = $expected_total - (float) $calculated['netPrice'];
		if ( ! $lines || $gap <= 0.01 ) { return array(); }
		$exclusions = array();
		$excluded_total = 0.0;
		foreach ( $lines as $i => $line ) {
			$row = $line['returned'];
			$row_gap = $line['expected'] - (float) $row['netPrice'];
			if ( abs( $row_gap ) <= 0.01 ) { continue; }
			if ( $row_gap < 0 || ! empty( $document['items'][ $i ]['policies'] ) || ! is_array( $row['policies'] ?? null ) ) { return array(); }
			$excluded = null;
			foreach ( $row['policies'] as $policy ) {
				if ( ! is_array( $policy ) || true !== ( $policy['isIncluded'] ?? null ) ) { continue; }
				$id = (int) ( $policy['policyId'] ?? 0 );
				if ( isset( $line['distributed'][ $id ] ) && 'MiscellaneousAdditions' === ( $policy['type'] ?? null )
					&& in_array( $policy['effect'] ?? null, array( 2, '2', 'Increase' ), true ) ) { continue; }
				$price = $policy['price'] ?? null;
				if ( is_numeric( $price ) && (float) $price === 0.0 ) { continue; }
				if ( $excluded || 507 !== (int) ( $policy['policyId'] ?? 0 ) || ! self::is_calculated_discount( $policy )
					|| ! is_numeric( $price ) || ! is_finite( (float) $price ) || abs( (float) $price - $row_gap ) > 0.01
					|| empty( $policy['policyConditionId'] ) || empty( $policy['policyConditionRowId'] ) ) { return array(); }
				$excluded = array_intersect_key( $policy, array_flip( array(
					'policyId', 'policyConditionId', 'policyConditionRowId', 'type', 'effect', 'definitiveness', 'enforcement', 'isReadOnly',
				) ) );
			}
			if ( null === $excluded ) { return array(); }
			$exclusions[ $i ] = $excluded + array( 'price' => 0, 'isIncluded' => false );
			$excluded_total += $row_gap;
		}
		return abs( $excluded_total - $gap ) <= 0.01 ? $exclusions : array();
	}

	public static function snapp_line_check( $document, $calculated ) {
		$lines = self::matched_snapp_lines( $document, $calculated );
		if ( ! $lines ) {
			return array( 'matched' => false, 'differences' => array(), 'returned_rows' => is_array( $calculated['items'] ?? null ) ? count( $calculated['items'] ) : null );
		}
		$differences = array();
		foreach ( $lines as $line ) {
			$row = $line['returned'];
			if ( abs( $line['expected'] - (float) $row['netPrice'] ) <= 0.01 ) { continue; }
			$policy_prices = array();
			foreach ( (array) ( $row['policies'] ?? array() ) as $policy ) {
				if ( is_array( $policy ) && 507 === (int) ( $policy['policyId'] ?? 0 ) && true === ( $policy['isIncluded'] ?? null )
					&& is_numeric( $policy['price'] ?? null ) && is_finite( (float) $policy['price'] ) ) {
					$policy_prices[] = (float) $policy['price'];
				}
			}
			$differences[] = array( 'product' => (int) $row['productId'], 'expected' => $line['expected'],
				'net' => (float) $row['netPrice'], 'applied_507' => $policy_prices );
		}
		return array( 'matched' => true, 'differences' => $differences );
	}

	public static function has_excluded_snapp_discount( $calculated, $exclusions ) {
		$rows = array_values( $calculated['items'] );
		foreach ( $exclusions as $i => $excluded ) {
			$policies = $rows[ $i ]['policies'] ?? null;
			if ( ! is_array( $policies ) ) { return true; }
			foreach ( $policies as $policy ) {
				if ( ! is_array( $policy ) ) { return true; }
				if ( 507 === (int) ( $policy['policyId'] ?? 0 ) && true === ( $policy['isIncluded'] ?? null ) ) { return true; }
			}
		}
		return false;
	}

	/** Express a verified 507 discount as the original selling price rather than an additional reduction. */
	public static function snapp_paid_price_document( $document ) {
		$changed = false;
		foreach ( $document['items'] as &$item ) {
			$discount = 0.0;
			foreach ( $item['policies'] ?? array() as $index => $policy ) {
				if ( false === ( $policy['isIncluded'] ?? null ) && 0.0 === (float) ( $policy['price'] ?? NAN ) ) { continue; }
				if ( 507 !== (int) ( $policy['policyId'] ?? 0 ) || ! self::is_calculated_discount( $policy )
					|| true !== ( $policy['isIncluded'] ?? null ) || ! is_numeric( $policy['price'] ?? null )
					|| ! is_finite( (float) $policy['price'] ) || $policy['price'] <= 0 ) { return null; }
				$discount += (float) $policy['price'];
				$item['policies'][ $index ]['isIncluded'] = false;
				$item['policies'][ $index ]['price'] = 0;
			}
			if ( $discount <= 0 ) { continue; }
			$sale_price = round( (float) $item['price'] - $discount, 2 );
			if ( ! is_finite( $sale_price ) || $sale_price <= 0 || $item['quantity'] <= 0 ) { return null; }
			$item['fee'] = round( $sale_price / $item['quantity'], 6 );
			$item['price'] = $sale_price;
			$changed = true;
		}
		unset( $item );
		return $changed ? $document : null;
	}

	/** calculateAmount is not a save. Compare its netPrice without altering the WC sale. */
	public static function validate_calculated( $calculated, $payload, $order, $s ) {
		if ( ! is_array( $calculated ) || ! isset( $calculated['netPrice'] ) || ! is_numeric( $calculated['netPrice'] ) || ! is_finite( (float) $calculated['netPrice'] ) ) { return new WP_Error( 'rkw_calculate_response', 'calculateAmount جمع نهایی معتبر برنگرداند؛ فاکتور ثبت نشد.' ); }
		if ( ! empty( $calculated['hasError'] ) ) { return new WP_Error( 'rkw_calculate_response', 'راهکاران در محاسبه سند خطا گزارش کرد؛ فاکتور ثبت نشد.' ); }
		foreach ( isset( $calculated['items'] ) && is_array( $calculated['items'] ) ? $calculated['items'] : array() as $item ) {
			if ( ! empty( $item['hasError'] ) ) { return new WP_Error( 'rkw_calculate_item', 'محاسبه راهکاران یک ردیف کالا را رد کرد: ' . sanitize_text_field( isset( $item['errorMessage'] ) ? $item['errorMessage'] : 'خطای ردیف' ) ); }
		}
		$expected = round( ( $order->get_total() + (float) $order->get_meta( '_rkw_loyalty_credit_amount' ) ) * rkw_price_multiplier( $s ), 2 );
		if ( abs( $expected - (float) $calculated['netPrice'] ) > 0.01 ) { return new WP_Error( 'rkw_server_total', 'جمع محاسبه‌شده راهکاران ' . $calculated['netPrice'] . ' با مبلغ سند ووکامرس ' . $expected . ' برابر نیست؛ سیاست خودکار، مالیات یا تخفیف راهکاران باید تطبیق داده شود. فاکتور ثبت نشد.' ); }
		return true;
	}
}
