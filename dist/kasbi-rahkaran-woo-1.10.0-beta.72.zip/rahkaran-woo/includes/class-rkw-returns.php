<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Explicit full-invoice returns. This class never hooks WooCommerce refunds or order sending. */
class RKW_Returns {
    private static $legacy = array();

    public static function init() {
        add_action( 'wp_ajax_rkw_return_prepare', array( __CLASS__, 'ajax_prepare' ) );
        add_action( 'wp_ajax_rkw_return_submit', array( __CLASS__, 'ajax_submit' ) );
        add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
        add_action( 'admin_footer', array( __CLASS__, 'modal' ) );
    }

    public static function clear_cache() { self::$legacy = array(); }

    private static function page() { return isset( $_GET['page'] ) && 'rkw-invoices' === (string) $_GET['page']; }

    /** Document identity survives password, cashier, API-contract and user changes. */
    public static function key( $invoice_id ) {
        $s = rkw_settings();
        return 'rkw_return_invoice_' . substr( hash( 'sha256', strtolower( $s['protocol'] . '://' . trim( $s['ip'], '/' ) ) . ':' . $s['port'] . '/' . trim( $s['cluster'], '/' ) . ':' . (int) $invoice_id ), 0, 40 );
    }

    private static function positive( $value ) { return ( is_int( $value ) || is_string( $value ) ) && preg_match( '/^[1-9][0-9]*$/D', (string) $value ) ? (int) $value : 0; }

    private static function document_id( $value ) {
        if ( ! is_array( $value ) ) { return 0; }
        foreach ( array( 'id', 'Id', 'invoiceId', 'InvoiceId', 'returnInvoiceId', 'ReturnInvoiceId', 'documentId', 'DocumentId' ) as $key ) { if ( isset( $value[ $key ] ) && self::positive( $value[ $key ] ) ) { return self::positive( $value[ $key ] ); } }
        foreach ( array( 'document', 'returnInvoice' ) as $key ) { if ( isset( $value[ $key ] ) && is_array( $value[ $key ] ) ) { $id = self::document_id( $value[ $key ] ); if ( $id ) { return $id; } } }
        return 0;
    }

    public static function status( $invoice_id ) {
        $stored = get_option( self::key( $invoice_id ), array() );
        if ( is_array( $stored ) && ! empty( $stored['state'] ) ) {
            if ( 'returned' === $stored['state'] && isset( $stored['id'] ) && self::positive( $stored['id'] ) ) { return array( 'state' => 'returned', 'id' => self::positive( $stored['id'] ) ); }
            return array( 'state' => 'pending' );
        }
        $id = (int) $invoice_id;
        if ( ! array_key_exists( $id, self::$legacy ) ) {
            global $wpdb;
            $rows = $wpdb->get_results( $wpdb->prepare( "SELECT p.ID, r.meta_value AS return_id FROM {$wpdb->posts} p INNER JOIN {$wpdb->postmeta} i ON i.post_id=p.ID AND i.meta_key='invoice_id' INNER JOIN {$wpdb->postmeta} r ON r.post_id=p.ID AND r.meta_key='return_invoice_id' WHERE p.post_type=%s AND i.meta_value=%s", 'rahkaran-invoice', (string) $id ), ARRAY_A );
            $ids = array(); $unknown = ! empty( $wpdb->last_error ) || ! is_array( $rows );
            foreach ( is_array( $rows ) ? $rows : array() as $row ) {
                $value = isset( $row['return_id'] ) ? trim( (string) $row['return_id'] ) : '';
                if ( '' === $value || '0' === $value ) { continue; } // Legacy uses empty(return_invoice_id) for an unreturned invoice.
                $rid = self::positive( $value );
                if ( $rid ) { $ids[ $rid ] = $rid; } else { $unknown = true; }
            }
            self::$legacy[ $id ] = $unknown || count( $ids ) > 1 ? array( 'state' => 'pending' ) : ( $ids ? array( 'state' => 'returned', 'id' => (int) reset( $ids ) ) : array( 'state' => 'available' ) );
        }
        return self::$legacy[ $id ];
    }

    private static function rows( $value ) {
        if ( ! is_array( $value ) ) { return array(); }
        return isset( $value['items'] ) && is_array( $value['items'] ) ? $value['items'] : $value;
    }

    public static function policies( $value ) {
        $out = array();
        foreach ( self::rows( $value ) as $row ) {
            if ( ! is_array( $row ) ) { continue; }
            $id = self::positive( isset( $row['settlementPolicyID'] ) ? $row['settlementPolicyID'] : ( isset( $row['id'] ) ? $row['id'] : 0 ) );
            if ( ! $id ) { continue; }
            $keys = array();
            foreach ( isset( $row['settlementMethodGroups'] ) && is_array( $row['settlementMethodGroups'] ) ? $row['settlementMethodGroups'] : array() as $group ) {
                foreach ( isset( $group['settlementMethods'] ) && is_array( $group['settlementMethods'] ) ? $group['settlementMethods'] : array() as $method ) {
                    $key = isset( $method['settlementNatureKey'] ) ? $method['settlementNatureKey'] : ( isset( $method['natureKey'] ) ? $method['natureKey'] : ( isset( $method['key'] ) ? $method['key'] : '' ) );
                    if ( is_string( $key ) && preg_match( '/^[A-Za-z0-9_]{1,80}$/D', $key ) ) { $keys[ $key ] = $key; }
                }
            }
            if ( $keys ) { $out[] = array( 'id' => $id, 'title' => sanitize_text_field( isset( $row['settlementPolicyName'] ) ? $row['settlementPolicyName'] : '' ), 'keys' => array_values( $keys ) ); }
        }
        return $out;
    }

    private static function quantities( $items ) {
        $out = array();
        foreach ( $items as $item ) {
            if ( ! is_array( $item ) || ! isset( $item['productId'], $item['unitId'], $item['quantity'] ) || ! self::positive( $item['productId'] ) || ! self::positive( $item['unitId'] ) || ! is_numeric( $item['quantity'] ) || ! is_finite( (float) $item['quantity'] ) || (float) $item['quantity'] <= 0 || ! empty( $item['hasError'] ) ) { return false; }
            $key = (int) $item['productId'] . ':' . (int) $item['unitId'];
            $out[ $key ] = round( ( isset( $out[ $key ] ) ? $out[ $key ] : 0 ) + (float) $item['quantity'], 6 );
        }
        ksort( $out ); return $out;
    }

    /** Reads the original invoice and server-produced return draft; does not issue a document. */
    public static function prepare( $invoice_id, RKW_Client $client ) {
        if ( ! $client->is_v21() || ! self::positive( $invoice_id ) ) { return new WP_Error( 'rkw_return_invoice', 'شناسه فاکتور و اتصال API ۲۱ لازم است.' ); }
        $state = self::status( $invoice_id );
        if ( 'available' !== $state['state'] ) { return new WP_Error( 'rkw_return_existing', 'returned' === $state['state'] ? 'این فاکتور قبلاً برگشت خورده است؛ شناسه برگشت #' . $state['id'] : 'نتیجه برگشت قبلی نامشخص است؛ قبل از ثبت دوباره، راهکاران را بررسی کنید.' ); }
        $invoice = $client->invoice21( $invoice_id );
        if ( is_wp_error( $invoice ) ) { return $invoice; }
        if ( self::document_id( $invoice ) !== (int) $invoice_id || empty( $invoice['items'] ) || ! isset( $invoice['netPrice'] ) || ! is_numeric( $invoice['netPrice'] ) || ! is_finite( (float) $invoice['netPrice'] ) || (float) $invoice['netPrice'] <= 0 ) { return new WP_Error( 'rkw_return_source', 'فاکتور اصلی، اقلام یا مبلغ خالص معتبر از راهکاران دریافت نشد.' ); }
        $pattern = $client->default_pattern21( 3 ); // PDF: ReturnInvoice = 3.
        if ( is_wp_error( $pattern ) ) { return $pattern; }
        $pattern_id = self::document_id( $pattern );
        if ( ! $pattern_id ) { $pattern_id = self::positive( isset( $pattern['documentPatternId'] ) ? $pattern['documentPatternId'] : ( isset( $pattern['documentPatternID'] ) ? $pattern['documentPatternID'] : 0 ) ); }
        if ( ! $pattern_id ) { return new WP_Error( 'rkw_return_pattern', 'الگوی پیش‌فرض برگشت از فروش در راهکاران شناسه معتبر ندارد.' ); }
        $copy = $client->call( 'GET', 'Retail/Api/RetailDocuments/InvoiceService.svc/copyToReturnInvoice', array( 'invoiceId' => (int) $invoice_id, 'returnInvoicePatternId' => $pattern_id ) );
        if ( is_wp_error( $copy ) ) { return $copy; }
        $draft = isset( $copy['document'] ) && is_array( $copy['document'] ) ? $copy['document'] : $copy;
        if ( ! is_array( $draft ) || empty( $draft['items'] ) || ! is_array( $draft['items'] ) ) { return new WP_Error( 'rkw_return_copy', 'سرویس کپی فاکتور، سند برگشت با اقلام معتبر برنگرداند.' ); }
        $original_quantities = self::quantities( $invoice['items'] );
        if ( false === $original_quantities || $original_quantities !== self::quantities( $draft['items'] ) ) { return new WP_Error( 'rkw_return_partial', 'تمام اقلام فاکتور برای برگشت کامل در دسترس نیستند؛ وضعیت برگشت‌های قبلی یا خطای اقلام را در راهکاران بررسی کنید.' ); }
        $amount = round( (float) $invoice['netPrice'], 2 );
        if ( isset( $draft['netPrice'] ) && ( ! is_numeric( $draft['netPrice'] ) || abs( (float) $draft['netPrice'] - $amount ) > 0.01 ) ) { return new WP_Error( 'rkw_return_amount', 'مبلغ سند برگشت با فاکتور اصلی برابر نیست؛ ثبت خودکار برگشت کامل متوقف شد.' ); }
        foreach ( array( 'customerId', 'currencyId' ) as $field ) {
            if ( empty( $invoice[ $field ] ) || empty( $draft[ $field ] ) || (int) $invoice[ $field ] !== (int) $draft[ $field ] ) { return new WP_Error( 'rkw_return_identity', 'مشتری یا ارز سند برگشت با فاکتور اصلی تطبیق ندارد.' ); }
        }
        $policies = $client->settlement_policies21( 3 );
        if ( is_wp_error( $policies ) ) { return $policies; }
        $policies = self::policies( $policies );
        if ( ! $policies ) { return new WP_Error( 'rkw_return_policies', 'فهرست سیاست‌های تسویه برگشت با روش‌های دریافت/پرداخت معتبر در راهکاران یافت نشد.' ); }
        $draft['id'] = 0; $draft['documentType'] = 3; $draft['status'] = 1;
        $draft['documentPatternId'] = $pattern_id; $draft['netPrice'] = $amount;
        $draft['description'] = 'برگشت کامل فاکتور راهکاران #' . (int) $invoice_id;
        $fingerprint = hash_hmac( 'sha256', wp_json_encode( array( self::key( $invoice_id ), $pattern_id, (int) $invoice['customerId'], (int) $invoice['currencyId'], $amount, $original_quantities ) ), wp_salt( 'auth' ) );
        $default_policy = isset( $draft['settlementPolicyId'] ) ? (int) $draft['settlementPolicyId'] : 0;
        if ( ! $default_policy && isset( $pattern['defaults']['defaultSettlementPolicyId'] ) ) { $default_policy = (int) $pattern['defaults']['defaultSettlementPolicyId']; }
        return array( 'invoice_id' => (int) $invoice_id, 'number' => isset( $invoice['number'] ) ? sanitize_text_field( $invoice['number'] ) : '', 'amount' => $amount, 'currency' => isset( $invoice['currencyTitle'] ) ? sanitize_text_field( $invoice['currencyTitle'] ) : (string) $invoice['currencyId'], 'item_count' => count( $draft['items'] ), 'pattern_id' => $pattern_id, 'policy_id' => $default_policy, 'policies' => $policies, 'fingerprint' => $fingerprint, 'document' => $draft );
    }

    public static function payload( $prepared, $selection, RKW_Client $client ) {
        $policy_id = isset( $selection['policy_id'] ) ? self::positive( $selection['policy_id'] ) : 0;
        $key = isset( $selection['receipt_key'] ) ? (string) $selection['receipt_key'] : '';
        $allowed = false;
        foreach ( $prepared['policies'] as $policy ) { if ( $policy['id'] === $policy_id && in_array( $key, $policy['keys'], true ) ) { $allowed = true; break; } }
        if ( ! $allowed ) { return new WP_Error( 'rkw_return_payment', 'سیاست و روش تسویه برگشت را از فهرست واقعی راهکاران انتخاب کنید.' ); }
        $attr = array();
        if ( in_array( $key, array( 'EReceipt', 'BankReceipt' ), true ) ) {
            $bank = isset( $selection['bank_account_ref'] ) ? self::positive( $selection['bank_account_ref'] ) : 0;
            $transaction = isset( $selection['transaction_number'] ) && is_scalar( $selection['transaction_number'] ) ? sanitize_text_field( $selection['transaction_number'] ) : '';
            if ( ! $bank || '' === $transaction ) { return new WP_Error( 'rkw_return_bank', 'برای روش بانکی، شناسه حساب بانک و شماره پیگیری برگشت را وارد کنید.' ); }
            $attr = array( 'bankAccountRef' => $bank, 'transactionNumber' => $transaction, 'date' => current_time( 'Y-m-d' ) );
        }
        if ( 'ThirdPartyCoupon' === $key ) {
            $coupon_id = isset( $selection['coupon_type_id'] ) ? self::positive( $selection['coupon_type_id'] ) : 0;
            $verified = $client->validate_coupon_type21( $coupon_id );
            if ( is_wp_error( $verified ) ) { return $verified; }
            $attr['couponType'] = $coupon_id;
        }
        $payment = array( 'key' => $key, 'amount' => $prepared['amount'] );
        if ( $attr ) { $payment['attr'] = $attr; }
        $document = $prepared['document']; $document['settlementPolicyId'] = $policy_id;
        foreach ( $document['items'] as $item ) {
            foreach ( array( 'fee', 'price' ) as $field ) {
                if ( ! isset( $item[ $field ] ) || ! is_numeric( $item[ $field ] ) || ! is_finite( (float) $item[ $field ] ) || (float) $item[ $field ] < 0 ) { return new WP_Error( 'rkw_return_line', 'نرخ یا مبلغ اقلام برگشت از راهکاران کامل دریافت نشده است.' ); }
            }
        }
        if ( $client->uses_legacy_documents() ) {
            foreach ( $document['items'] as &$item ) {
                if ( empty( $item['storeId'] ) ) { $item['storeId'] = ! empty( $item['inventoryId'] ) ? $item['inventoryId'] : ( isset( $document['inventoryId'] ) ? $document['inventoryId'] : 0 ); }
                if ( empty( $item['storeId'] ) || ! isset( $item['fee'], $item['price'] ) ) { return new WP_Error( 'rkw_return_line', 'انبار، نرخ یا مبلغ اقلام برگشت از راهکاران کامل دریافت نشده است.' ); }
                if ( isset( $item['policies'] ) ) { $item['policies'] = self::legacy_policies( $item['policies'] ); }
            } unset( $item );
            if ( isset( $document['policies'] ) ) { $document['policies'] = self::legacy_policies( $document['policies'] ); }
            if ( empty( $document['storeId'] ) && ! empty( $document['inventoryId'] ) ) { $document['storeId'] = $document['inventoryId']; }
            return RKW_Client::document_payload( array( 'document' => $document, 'receipts' => array( $payment ) ), rkw_settings() );
        }
        return array( 'document' => $document, 'receipts' => array(), 'payments' => array( $payment ) );
    }

    private static function legacy_policies( $policies ) {
        $out = array();
        foreach ( is_array( $policies ) ? $policies : array() as $policy ) {
            if ( ! is_array( $policy ) ) { continue; }
            $row = array_intersect_key( $policy, array_fill_keys( array( 'policyId', 'price', 'effect', 'lookupValue', 'booleanValue', 'dateTimeValue', 'stringValue', 'isIncluded' ), true ) );
            // Neutral/read-only v21 policies have no explicit legacy direction; the policy defines it.
            if ( isset( $row['effect'] ) && 0 === $row['effect'] ) { unset( $row['effect'] ); }
            $out[] = $row;
        }
        return $out;
    }

    private static function uncertain( $error ) {
        if ( in_array( $error->get_error_code(), array( 'rkw_http', 'http_request_failed' ), true ) ) { return true; }
        if ( 'rkw_api' === $error->get_error_code() ) { return false; }
        if ( 'rkw_http_status' === $error->get_error_code() ) {
            $data = $error->get_error_data(); $status = isset( $data['http_status'] ) ? (int) $data['http_status'] : 0;
            return ! $status || $status >= 500 || in_array( $status, array( 408, 429 ), true );
        }
        return true;
    }

    public static function submit( $invoice_id, $selection, $fingerprint ) {
        $key = self::key( $invoice_id ); $lock = str_replace( 'rkw_return_invoice_', 'rkw_return_lock_', $key );
        if ( ! add_option( $lock, time(), '', false ) ) { return new WP_Error( 'rkw_return_lock', 'برگشت این فاکتور در حال پردازش است.' ); }
        try {
            self::clear_cache();
            $client = new RKW_Client();
            $prepared = self::prepare( $invoice_id, $client );
            if ( is_wp_error( $prepared ) ) { return $prepared; }
            if ( ! is_string( $fingerprint ) || ! hash_equals( $prepared['fingerprint'], $fingerprint ) ) { return new WP_Error( 'rkw_return_changed', 'اطلاعات فاکتور یا الگوی برگشت تغییر کرده است؛ پیش‌نمایش را دوباره باز کنید.' ); }
            $payload = self::payload( $prepared, $selection, $client );
            if ( is_wp_error( $payload ) ) { return $payload; }
            self::clear_cache();
            $current_state = self::status( $invoice_id );
            if ( 'available' !== $current_state['state'] ) { return new WP_Error( 'rkw_return_existing', 'سابقه برگشت این فاکتور هنگام بررسی تغییر کرد؛ ابتدا نتیجه ثبت قبلی را بررسی کنید.' ); }
            if ( ! add_option( $key, array( 'state' => 'pending', 'invoice_id' => (int) $invoice_id, 'started' => time() ), '', false ) ) { return new WP_Error( 'rkw_return_existing', 'برای این فاکتور سابقه برگشت وجود دارد؛ ابتدا نتیجه قبلی را بررسی کنید.' ); }
            // This marker is durable BEFORE the financial POST, even if PHP is killed.
            $path = $client->uses_legacy_documents() ? 'Services/Retail/ESales.svc/returninvoice' : 'Retail/Api/RetailDocuments/ReturnInvoiceService.svc/SaveReturnInvoice';
            $result = $client->call( 'POST', $path, array(), $payload, false );
            if ( is_wp_error( $result ) ) {
                if ( ! self::uncertain( $result ) ) { delete_option( $key ); }
                return $result;
            }
            $id = self::document_id( $result );
            if ( ! $id ) { return new WP_Error( 'rkw_return_unconfirmed', 'شناسه برگشت از فروش تأیید نشد؛ نتیجه نامشخص است. پیش از هر اقدام بعدی در راهکاران بررسی کنید.' ); }
            $saved = array( 'state' => 'returned', 'id' => $id, 'invoice_id' => (int) $invoice_id );
            update_option( $key, $saved, false );
            if ( get_option( $key ) !== $saved ) { return new WP_Error( 'rkw_return_unconfirmed', 'سند برگشت ثبت شد ولی ذخیره شناسه در سایت تأیید نشد؛ پیش از هر اقدام دیگر در راهکاران بررسی کنید.' ); }
            self::remember_legacy_return( $invoice_id, $id );
            RKW_Snapshot::invalidate_section( 'invoices' );
            return $saved;
        } finally { delete_option( $lock ); }
    }

    private static function remember_legacy_return( $invoice_id, $return_id ) {
        global $wpdb;
        $rows = $wpdb->get_results( $wpdb->prepare( "SELECT p.ID FROM {$wpdb->posts} p INNER JOIN {$wpdb->postmeta} i ON i.post_id=p.ID AND i.meta_key='invoice_id' WHERE p.post_type=%s AND i.meta_value=%s", 'rahkaran-invoice', (string) $invoice_id ), ARRAY_A );
        if ( ! empty( $wpdb->last_error ) || ! is_array( $rows ) ) { return; }
        foreach ( $rows as $row ) { if ( ! empty( $row['ID'] ) ) { update_post_meta( (int) $row['ID'], 'return_invoice_id', (int) $return_id ); } }
    }

    private static function guard() {
        if ( ! current_user_can( 'manage_woocommerce' ) || ! check_ajax_referer( 'rkw_return_invoice', 'nonce', false ) ) { wp_send_json_error( array( 'message' => 'دسترسی یا نشست نامعتبر است.' ), 403 ); }
        if ( ! isset( $_SERVER['REQUEST_METHOD'] ) || 'POST' !== $_SERVER['REQUEST_METHOD'] ) { wp_send_json_error( array( 'message' => 'ثبت برگشت فقط از فرم مدیریت انجام می‌شود.' ), 405 ); }
    }

    public static function ajax_prepare() {
        self::guard(); $client = new RKW_Client();
        $id = isset( $_POST['invoice_id'] ) ? self::positive( $_POST['invoice_id'] ) : 0;
        $result = self::prepare( $id, $client );
        if ( is_wp_error( $result ) ) { wp_send_json_error( array( 'message' => $result->get_error_message(), 'return_status' => self::status( $id ) ), 409 ); }
        unset( $result['document'] ); // Only the server may construct the financial payload.
        wp_send_json_success( $result );
    }

    public static function ajax_submit() {
        self::guard();
        if ( ! isset( $_POST['confirm'] ) || '1' !== (string) $_POST['confirm'] ) { wp_send_json_error( array( 'message' => 'تأیید ثبت برگشت کامل لازم است.' ), 400 ); }
        $id = isset( $_POST['invoice_id'] ) ? self::positive( $_POST['invoice_id'] ) : 0;
        $selection = array();
        foreach ( array( 'policy_id', 'receipt_key', 'bank_account_ref', 'transaction_number', 'coupon_type_id' ) as $field ) { $selection[ $field ] = isset( $_POST[ $field ] ) && is_scalar( $_POST[ $field ] ) ? sanitize_text_field( wp_unslash( (string) $_POST[ $field ] ) ) : ''; }
        $fingerprint = isset( $_POST['fingerprint'] ) && is_string( $_POST['fingerprint'] ) ? wp_unslash( $_POST['fingerprint'] ) : '';
        $result = self::submit( $id, $selection, $fingerprint );
        if ( is_wp_error( $result ) ) { wp_send_json_error( array( 'message' => $result->get_error_message(), 'return_status' => self::status( $id ) ), 409 ); }
        wp_send_json_success( array( 'message' => 'برگشت از فروش ثبت شد؛ شناسه نرم‌افزار #' . $result['id'], 'return_status' => $result ) );
    }

    public static function assets() {
        if ( ! self::page() || ! current_user_can( 'manage_woocommerce' ) ) { return; }
        wp_enqueue_script( 'rkw-returns', plugins_url( 'assets/returns.js', RKW_FILE ), array(), RKW_VER, true );
        wp_localize_script( 'rkw-returns', 'rkwReturns', array( 'ajax' => admin_url( 'admin-ajax.php' ), 'nonce' => wp_create_nonce( 'rkw_return_invoice' ) ) );
    }

    public static function modal() {
        if ( ! self::page() || ! current_user_can( 'manage_woocommerce' ) ) { return; }
        echo '<div id="rkw-return-modal" class="rkwm-settlement-overlay" hidden><section class="rkwm-settlement-modal" role="dialog" aria-modal="true" aria-labelledby="rkw-return-title" tabindex="-1"><header><h2 id="rkw-return-title">برگشت از فروش</h2><button type="button" class="button" id="rkw-return-close">بستن</button></header><p>این اقدام برگشت کامل اقلام فاکتور را در راهکاران ثبت می‌کند. بازپرداخت درگاه باید جداگانه انجام شود.</p><p id="rkw-return-feedback" role="status" aria-live="polite"></p><form id="rkw-return-form" hidden><p id="rkw-return-summary"></p><p><label>سیاست تسویه برگشت <select id="rkw-return-policy" required></select></label></p><p><label>روش پرداخت برگشت <select id="rkw-return-method" required></select></label></p><p id="rkw-return-bank-fields" hidden><label>شناسه حساب بانک <input id="rkw-return-bank" type="number" min="1"></label> <label>شماره پیگیری برگشت <input id="rkw-return-transaction" type="text" maxlength="100"></label></p><p id="rkw-return-coupon-field" hidden><label>شناسه نوع بن سازمانی couponType <input id="rkw-return-coupon" type="number" min="1"></label></p><p><label><input id="rkw-return-confirm" type="checkbox" required> ثبت برگشت کامل این فاکتور در راهکاران را تأیید می‌کنم.</label></p><button id="rkw-return-submit" class="button button-primary" type="submit">ثبت برگشت از فروش</button></form></section></div>';
    }
}
