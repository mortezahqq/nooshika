<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Small catalog jobs, dispatched through WooCommerce's background queue where available. */
class RKW_Sync_Runner {
	const HOOK = 'rkw_catalog_worker';
	const GROUP = 'rkw-catalog';
	const STATE = 'rkw_catalog_worker_state';

	public static function init() {
		add_action( self::HOOK, array( __CLASS__, 'work' ) );
		add_action( 'init', array( __CLASS__, 'ensure_schedule' ), 30 );
		add_action( 'wp_ajax_rkw_catalog_status', array( __CLASS__, 'ajax_status' ) );
	}

	public static function ensure_schedule() {
		$s = rkw_settings();
		if ( '' === trim( (string) $s['ip'] ) ) { return; }
		if ( 'off' === $s['cron_interval'] ) { if ( wp_next_scheduled( 'rkw_cron_sync' ) ) { RKW_Sync::reschedule(); } return; }
		if ( wp_get_schedule( 'rkw_cron_sync' ) !== $s['cron_interval'] ) { RKW_Sync::reschedule(); }
	}

	public static function cancel_pending() {
		wp_clear_scheduled_hook( 'rkw_cron_continue' );
		wp_clear_scheduled_hook( self::HOOK );
		if ( function_exists( 'as_unschedule_all_actions' ) ) {
			try { as_unschedule_all_actions( self::HOOK, array(), self::GROUP ); }
			catch ( Throwable $error ) { RKW_Log::add( 'warn', 'صف پس‌زمینه کالا هنگام تغییر زمان‌بندی در دسترس نبود؛ کارها در زمان اجرا تنظیم فعال/غیرفعال را بررسی می‌کنند.' ); }
		}
	}

	private static function pending() {
		if ( function_exists( 'as_get_scheduled_actions' ) && function_exists( 'as_enqueue_async_action' ) ) {
			return (bool) as_get_scheduled_actions( array( 'hook' => self::HOOK, 'group' => self::GROUP, 'status' => 'pending', 'per_page' => 1 ), 'ids' );
		}
		return (bool) wp_next_scheduled( self::HOOK );
	}

	private static function enqueue() {
		try {
			if ( self::pending() ) { return true; }
			if ( function_exists( 'as_enqueue_async_action' ) && function_exists( 'as_get_scheduled_actions' ) ) {
				return (bool) as_enqueue_async_action( self::HOOK, array(), self::GROUP, false );
			}
			$result = wp_schedule_single_event( time(), self::HOOK );
			if ( ! is_wp_error( $result ) && $result && function_exists( 'spawn_cron' ) ) { spawn_cron(); }
			return ! is_wp_error( $result ) && (bool) $result;
		} catch ( Throwable $error ) { return false; }
	}

	public static function kick() {
		$s = rkw_settings();
		if ( 'off' === $s['cron_interval'] || '' === trim( (string) $s['ip'] ) ) { return; }
		$state = get_option( self::STATE, array() );
		if ( ! empty( $state['error_at'] ) && time() - (int) $state['error_at'] < MINUTE_IN_SECONDS ) { return; }
		if ( ! self::enqueue() ) { update_option( self::STATE, array( 'error' => 'ساخت کار پس‌زمینه ناموفق بود؛ صف و زمان‌بندی وردپرس را بررسی کنید.', 'error_at' => time() ), false ); }
	}

	public static function work() {
		$s = rkw_settings();
		if ( 'off' === $s['cron_interval'] || '' === trim( (string) $s['ip'] ) ) { return; }
		$previous = get_option( self::STATE, array() );
		if ( ! get_option( RKW_Sync::CURSOR ) && ! empty( $previous['done'] ) && isset( $previous['last_run'] ) && time() - (int) $previous['last_run'] < 5 ) { return; }
		$started = microtime( true );
		try { $result = RKW_Sync::step(); }
		catch ( Throwable $error ) { $result = new WP_Error( 'rkw_catalog_exception', 'اجرای همگام‌سازی قطع شد؛ پیشرفت ذخیره‌شده در تلاش بعد ادامه می‌یابد. ' . sanitize_text_field( $error->getMessage() ) ); }
		if ( is_wp_error( $result ) ) {
			if ( 'rkw_sync_busy' !== $result->get_error_code() ) {
				update_option( self::STATE, array( 'error' => $result->get_error_message(), 'error_at' => time(), 'last_run' => time() ), false );
				RKW_Log::add( 'error', 'اجرای خودکار کالا: ' . $result->get_error_message() );
			}
			return;
		}
		update_option( self::STATE, array( 'last_run' => time(), 'duration' => round( microtime( true ) - $started, 2 ), 'done' => $result['done'] ), false );
		// The currently running action is excluded from pending(), so the next slice is queued immediately.
		if ( ! $result['done'] && ! self::enqueue() ) { update_option( self::STATE, array( 'error' => 'ادامه صف ساخته نشد؛ زمان‌بندی بعدی از پیشرفت ذخیره‌شده ادامه می‌دهد.', 'error_at' => time(), 'last_run' => time() ), false ); }
	}

	public static function status() {
		$s = rkw_settings(); $state = get_option( self::STATE, array() ); $cursor = get_option( RKW_Sync::CURSOR ); $last = get_option( RKW_Sync::STATS, array() );
		$next = wp_next_scheduled( 'rkw_cron_sync' );
		$lines = array( 'روش اجرا: ' . ( function_exists( 'as_enqueue_async_action' ) ? 'صف پس‌زمینه ووکامرس' : 'زمان‌بندی وردپرس' ) );
		if ( ! function_exists( 'as_enqueue_async_action' ) ) { $lines[] = 'صف ووکامرس در دسترس نیست؛ ادامه به اجرای کرون وردپرس/هاست وابسته است.'; }
		$lines[] = 'وضعیت خودکار: ' . ( 'off' === $s['cron_interval'] ? 'غیرفعال' : ( 'rkw_1min' === $s['cron_interval'] ? 'هر یک دقیقه' : ( 'twicedaily' === $s['cron_interval'] ? 'دو بار در روز (هر ۱۲ ساعت)' : $s['cron_interval'] ) ) );
		if ( is_array( $cursor ) ) { $lines[] = 'پیشرفت دور جاری: ' . (int) $cursor['processed'] . ' بررسی، ' . (int) $cursor['updated'] . ' به‌روزرسانی، ' . (int) $cursor['errors'] . ' خطا؛ ' . count( isset( $cursor['pending_items'] ) ? $cursor['pending_items'] : array() ) . ' کالا در دسته فعلی باقی است.'; }
		if ( $next ) { $lines[] = 'شروع زمان‌بندی‌شده بعدی: ' . wp_date( 'Y/m/d H:i:s', (int) $next ); }
		if ( ! empty( $state['last_run'] ) ) { $lines[] = 'آخرین اجرای صف: ' . wp_date( 'Y/m/d H:i:s', (int) $state['last_run'] ); }
		if ( ! empty( $last['finished'] ) ) { $lines[] = 'آخرین دور کامل: ' . $last['finished'] . ' — ' . (int) $last['updated'] . ' به‌روزرسانی، ' . (int) $last['errors'] . ' خطا'; }
		if ( is_array( $cursor ) && ! empty( $cursor['heartbeat'] ) && (int) $cursor['heartbeat'] < time() - 120 ) { $lines[] = 'پیشرفت صف بیش از دو دقیقه متوقف بوده؛ اجرای صف پس‌زمینه و درخواست‌های داخلی هاست بررسی شوند.'; }
		if ( ! empty( $state['error'] ) ) { $lines[] = 'خطای صف: ' . $state['error']; }
		if ( $next && $next < time() - 120 && 'off' !== $s['cron_interval'] ) { $lines[] = 'اجرای زمان‌بندی بیش از دو دقیقه عقب افتاده؛ کرون و درخواست‌های داخلی هاست بررسی شوند.'; }
		if ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ) { $lines[] = 'WP-Cron غیرفعال است؛ برای شروع دورهای خودکار، کرون هاست باید wp-cron.php را اجرا کند.'; }
		$lines[] = 'زمان پایان هر دور به تعداد کالاها و سرعت پاسخ راهکاران بستگی دارد.';
		return implode( "\n", $lines );
	}

	public static function ajax_status() {
		if ( ! current_user_can( 'manage_woocommerce' ) || ! check_ajax_referer( 'rkw_ajax', '_ajax_nonce', false ) ) { wp_send_json_error( array( 'message' => 'دسترسی یا نشست نامعتبر است.' ), 403 ); }
		wp_send_json_success( array( 'text' => self::status() ) );
	}
}
