<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Read legacy data without loading ionCube code or activating duplicate send hooks. */
class RKW_Migration {
	public static function init() { add_action( 'admin_post_rkw_migrate_legacy', array( __CLASS__, 'save' ) ); }
	public static function menu() { add_submenu_page( 'rkw', 'مهاجرت از wp-rahkaran', 'مهاجرت از نسخه قدیمی', 'manage_options', 'rkw-migration', array( __CLASS__, 'page' ) ); }
	public static function settings_map( $old ) {
		$out = array( 'document_contract' => 'legacy_esales' );
		foreach ( array( 'protocol' => 'protocol', 'ip' => 'ip', 'port' => 'port', 'cluster' => 'cluster', 'username' => 'username', 'machineName' => 'machine_name', 'currencyId' => 'currency_id', 'documentPatternId' => 'doc_pattern_id', 'unitId' => 'default_unit_id', 'bankAccountRef' => 'bank_account_ref', 'loyaltyProgramId' => 'loyalty_id', 'invoice_per_item_policy_id' => 'item_discount_policy_id', 'customer_code' => 'fallback_cust', 'store_ids' => 'store_ids', 'salesAreaId' => 'sales_area_ord', 'wc_national_code_order_meta' => 'national_key' ) as $from => $to ) {
			if ( isset( $old[ $from ] ) && is_scalar( $old[ $from ] ) && '' !== (string) $old[ $from ] ) { $out[ $to ] = sanitize_text_field( (string) $old[ $from ] ); }
		}
		if ( isset( $old['basis_product_key'] ) ) { $out['key_field'] = 'ID' === $old['basis_product_key'] ? 'id' : 'code'; }
		if ( isset( $old['sale_price'] ) ) { $out['sync_sale'] = '2' === (string) $old['sale_price'] ? 0 : 1; }
		if ( isset( $old['order_type'] ) ) { $out['order_mode'] = '2' === (string) $old['order_type'] ? 'salesorder' : 'invoice'; }
		if ( isset( $old['order_customer_code_type'] ) ) { $out['customer_mode'] = '1' === (string) $old['order_customer_code_type'] ? 'default' : 'individual'; }
		if ( isset( $old['no_gateway_order'] ) ) { $m = array( '1' => 'cash', '2' => 'credit', '3' => 'block' ); $out['no_gateway_order'] = isset( $m[ $old['no_gateway_order'] ] ) ? $m[ $old['no_gateway_order'] ] : 'block'; }
		if ( isset( $old['price_symbol'], $old['price_symbol_rahkaran'] ) ) {
			$wc = (string) $old['price_symbol']; $rk = (string) $old['price_symbol_rahkaran'];
			if ( in_array( $wc, array( '1', '2' ), true ) && in_array( $rk, array( '1', '2' ), true ) ) { $out['price_divisor'] = $wc === $rk ? 1 : ( '1' === $wc ? 10 : 0.1 ); }
		}
		foreach ( array( 'update_stock' => 'sync_stock', 'update_price' => 'sync_price' ) as $from => $to ) { if ( isset( $old[ $from ] ) ) { $out[ $to ] = '1' === (string) $old[ $from ] ? 1 : 0; } }
		$rules = array();
		for ( $i = 1; $i <= 40; $i++ ) {
			if ( empty( $old[ 'law_woo_getaway_bank_' . $i ] ) || 'none' === $old[ 'law_woo_getaway_bank_' . $i ] ) { continue; }
			$rules[] = array( 'gateway' => $old[ 'law_woo_getaway_bank_' . $i ], 'settlement_id' => isset( $old[ 'law_policy_id_' . $i ] ) ? $old[ 'law_policy_id_' . $i ] : 0, 'receipt_key' => isset( $old[ 'law_policy_key_' . $i ] ) ? $old[ 'law_policy_key_' . $i ] : '', 'bank_account_ref' => isset( $old[ 'law_policy_bankAccountRef_' . $i ] ) ? $old[ 'law_policy_bankAccountRef_' . $i ] : 0, 'e_receipt_mode' => 'omit' );
		}
		if ( $rules ) { $out['payment_rules'] = RKW_Payment::sanitize_rules( $rules ); }
		if ( array_key_exists( 'loan_payment_method', $old ) && empty( $old['loan_payment_method'] ) ) { $out['credit_gateways'] = array(); }
		elseif ( ! empty( $old['loan_payment_method'] ) && is_array( $old['loan_payment_method'] ) ) {
			$list = array(); foreach ( $old['loan_payment_method'] as $key => $value ) { if ( is_string( $key ) && '1' === (string) $value ) { $list[] = $key; } elseif ( is_int( $key ) ) { $list[] = $value; } }
			$out['credit_gateways'] = RKW_Payment::sanitize_gateways( $list );
		}
		// Never enable automatic sending or choose an API version during migration.
		return $out;
	}
	public static function extensions_map( $old ) {
		$out = array();
		if ( ! empty( $old['shipping_product_id'] ) ) {
			$mode = isset( $old['shipping_type'] ) && 'policy' === $old['shipping_type'] ? 'policy' : 'product';
			$out['shipping_mode'] = $mode; $out['shipping_enabled'] = 1;
			$out[ 'product' === $mode ? 'shipping_product_id' : 'shipping_policy_id' ] = absint( $old['shipping_product_id'] );
			$out['shipping_unit_id'] = isset( $old['unitId'] ) ? absint( $old['unitId'] ) : 0;
		}
		$rules = array();
		for ( $i = 1; $i <= 40; $i++ ) { if ( ! empty( $old[ 'law_woo_shipping_' . $i ] ) && 'none' !== $old[ 'law_woo_shipping_' . $i ] ) { $rules[] = array( 'method' => $old[ 'law_woo_shipping_' . $i ], 'id' => isset( $old[ 'law_shipping_policy_' . $i ] ) ? $old[ 'law_shipping_policy_' . $i ] : 0 ); } }
		if ( $rules ) { $out['shipping_rules'] = RKW_Accounting::sanitize_shipping_rules( $rules ); }
		return $out;
	}
	/** Exact SKU match only; never use the first fuzzy search result or parent variation. */
	public static function product_mapping( $product, $client, $s ) {
		$sku = trim( (string) $product->get_sku() );
		if ( '' === $sku ) { return new WP_Error( 'rkw_legacy_sku', 'کالا بدون شناسه راهکاران و بدون SKU است؛ اتصال کالا را تکمیل کنید.' ); }
		$rows = $client->products21( 1, 200, $sku );
		if ( is_wp_error( $rows ) ) { return $rows; }
		if ( isset( $rows['items'] ) ) { $rows = $rows['items']; }
		$matches = array();
		foreach ( is_array( $rows ) ? $rows : array() as $row ) {
			if ( ! is_array( $row ) || ! isset( $row['productId'] ) ) { continue; }
			if ( isset( $row['productNumber'] ) && (string) $row['productNumber'] === $sku ) { $matches[ (int) $row['productId'] ] = $row; }
			elseif ( 'id' === $s['key_field'] && (string) $row['productId'] === $sku ) { $matches[ (int) $row['productId'] ] = $row; }
		}
		if ( 1 !== count( $matches ) ) { return new WP_Error( 'rkw_legacy_product', 'برای SKU «' . sanitize_text_field( $sku ) . '» یک کالای یکتای راهکاران پیدا نشد؛ همگام‌سازی و شناسه داخلی کالا را بررسی کنید.' ); }
		$row = reset( $matches );
		$unit = 0; foreach ( array( 'RetailUnitRef', 'retailUnitRef', 'unitRef', 'unitId' ) as $key ) { if ( ! empty( $row[ $key ] ) ) { $unit = (int) $row[ $key ]; break; } }
		if ( ! $unit && ! empty( $row['units'] ) ) { foreach ( $row['units'] as $u ) { if ( ! empty( $u['isDefault'] ) ) { $unit = (int) $u['id']; break; } } }
		if ( ! $unit ) { $unit = (int) $s['default_unit_id']; }
		if ( ! $unit || (int) $row['productId'] <= 0 ) { return new WP_Error( 'rkw_legacy_unit', 'شناسه کالا یا واحد فروش معتبر دریافت نشد.' ); }
		$product->update_meta_data( '_rahkaran_product_id', (int) $row['productId'] );
		$product->update_meta_data( '_rahkaran_unit_id', $unit ); $product->save();
		return array( 'id' => (int) $row['productId'], 'unit' => $unit );
	}
	/** Whether the supplied legacy plugin can automatically issue the same orders. */
	public static function legacy_sender_status() {
		$paths = get_option( 'active_plugins', array() ); $paths = is_array( $paths ) ? $paths : array();
		if ( function_exists( 'get_site_option' ) ) { $network = get_site_option( 'active_sitewide_plugins', array() ); if ( is_array( $network ) ) { $paths = array_merge( $paths, array_keys( $network ) ); } }
		$active = false;
		foreach ( $paths as $path ) { if ( is_string( $path ) && preg_match( '#(?:^|/)wp-rahkaran\.php$#D', $path ) ) { $active = true; break; } }
		$old = get_option( 'wp_rahkaran_setting', array() ); $old = is_array( $old ) ? $old : array();
		$orders = ( isset( $old['order_system'] ) && '1' === (string) $old['order_system'] ) || ( isset( $old['send_order'] ) && '1' === (string) $old['send_order'] );
		$automatic = isset( $old['send_automatic_order'] ) && '1' === (string) $old['send_automatic_order'];
		return array( 'plugin_active' => $active, 'order_system_enabled' => $orders, 'automatic_setting_enabled' => $automatic, 'automatic_sender_active' => $active && $orders && $automatic );
	}
	/** Legacy order records must block a new invoice even after the old plugin is deactivated. */
	public static function legacy_order_records( $order_id ) {
		global $wpdb;
		// ReserveStock::invoice_post_types() in the supplied legacy plugin defines this slug.
		// Other plugins also store order_id; their records must not prevent an invoice.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT p.ID, p.post_type, p.post_status, i.meta_value AS invoice_id FROM {$wpdb->posts} p INNER JOIN {$wpdb->postmeta} o ON o.post_id=p.ID AND o.meta_key='order_id' LEFT JOIN {$wpdb->postmeta} i ON i.post_id=p.ID AND i.meta_key='invoice_id' WHERE o.meta_value=%s AND p.post_type=%s", (string) $order_id, 'rahkaran-invoice' ), ARRAY_A );
		if ( ! empty( $wpdb->last_error ) || ! is_array( $rows ) ) { return new WP_Error( 'rkw_legacy_read', 'بررسی سوابق ارسال قدیمی از دیتابیس ناموفق بود؛ برای جلوگیری از سند تکراری ارسال متوقف شد.' ); }
		return $rows;
	}
	/** Identifiers and state only; no legacy post titles, customer or arbitrary meta values. */
	public static function legacy_order_summary( $rows ) {
		$out = array();
		foreach ( $rows as $row ) {
			$raw = isset( $row['invoice_id'] ) && is_scalar( $row['invoice_id'] ) ? trim( (string) $row['invoice_id'] ) : '';
			$out[] = array( 'record_id' => isset( $row['ID'] ) ? absint( $row['ID'] ) : 0, 'post_status' => isset( $row['post_status'] ) ? sanitize_key( $row['post_status'] ) : 'unknown', 'invoice_id_recorded' => '' !== $raw, 'invoice_id' => preg_match( '/^[1-9][0-9]*$/D', $raw ) ? (int) $raw : null );
		}
		return $out;
	}
	public static function legacy_order_error( $rows ) {
		$summary = self::legacy_order_summary( $rows ); $parts = array();
		foreach ( array_slice( $summary, 0, 5 ) as $row ) {
			$parts[] = 'رکورد #' . $row['record_id'] . '، وضعیت ' . $row['post_status'] . '، ' . ( $row['invoice_id'] ? 'شناسه فاکتور ' . $row['invoice_id'] : ( $row['invoice_id_recorded'] ? 'شناسه فاکتور ذخیره‌شده قابل تأیید نیست' : 'شناسه فاکتور ذخیره نشده است' ) );
		}
		return new WP_Error( 'rkw_legacy_order', 'این سفارش رکورد فاکتور/صف در افزونه قدیمی دارد: ' . implode( '؛ ', $parts ) . '. وجود رکورد صف به‌تنهایی ثبت فاکتور را ثابت نمی‌کند. ابتدا نتیجه ثبت و صف قدیمی را بررسی کنید؛ سند جدید ارسال نشد.', array( 'legacy_records' => $summary ) );
	}
	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'عدم دسترسی' ); }
		$old = get_option( 'wp_rahkaran_setting', array() );
		echo '<div class="wrap rkwe" dir="rtl"><header class="rkwe-header"><h1>مهاجرت از wp-rahkaran</h1></header><section class="rkwe-card"><p>داده‌های قدیمی حذف نمی‌شوند. شناسه مشتری rahkaran-code و جدول اعضای وفاداری مستقیماً خوانده می‌شوند. ارسال خودکار و نسخه API تغییر نمی‌کنند؛ نسخه را در تنظیمات اتصال خودتان تطبیق دهید.</p>';
		if ( ! is_array( $old ) || ! $old ) { echo '<p>تنظیمات wp_rahkaran_setting در این سایت یافت نشد.</p></section></div>'; return; }
		$map = self::settings_map( $old );
		echo '<p>فیلدهای قابل انتقال: ' . esc_html( implode( '، ', array_keys( $map ) ) ) . '</p><p>تنظیمات API قدیمی ESales با نسخه ۲۱ یکسان نیست. سیاست پیش‌فرض نقدی/نسیه، انبار و رفتار ماژول‌های رمزگذاری‌شده باید پس از مهاجرت بررسی شوند.</p>';
		if ( isset( $_GET['saved'] ) ) { echo '<div class="notice notice-success inline"><p>فیلدهای انتخاب‌شده منتقل شدند؛ قبل از ارسال، اتصال و پیش‌نمایش پرداخت یک سفارش را بررسی کنید.</p></div>'; }
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="rkw_migrate_legacy">'; wp_nonce_field( 'rkw_migrate_legacy' );
		echo '<p><label><input type="checkbox" name="overwrite" value="1"> جایگزینی فیلدهای متناظر تنظیمات فعلی با مقادیر قدیمی</label></p><p><label><input type="checkbox" name="connection" value="1"> انتقال تنظیمات اتصال و رمز موجود به ذخیره رمزگذاری‌شده کاسبی (رمز نمایش داده نمی‌شود)</label></p><button class="button button-primary">انتقال تنظیمات</button></form></section></div>';
	}
	public static function save() {
		if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'عدم دسترسی' ); }
		check_admin_referer( 'rkw_migrate_legacy' );
		$old = get_option( 'wp_rahkaran_setting', array() ); if ( ! is_array( $old ) ) { wp_die( 'تنظیمات قدیمی معتبر نیست.' ); }
		$current = get_option( RKW_OPT, array() ); $current = is_array( $current ) ? $current : array();
		$map = self::settings_map( $old );
		$connection = array( 'protocol', 'ip', 'port', 'cluster', 'username', 'machine_name' );
		foreach ( $map as $key => $value ) {
			if ( in_array( $key, $connection, true ) && empty( $_POST['connection'] ) ) { continue; }
			if ( ! array_key_exists( $key, $current ) || ! empty( $_POST['overwrite'] ) ) { $current[ $key ] = $value; }
		}
		if ( ! empty( $_POST['connection'] ) && ! empty( $old['password'] ) && ( empty( $current['password_enc'] ) || ! empty( $_POST['overwrite'] ) ) ) {
			if ( ! function_exists( 'openssl_encrypt' ) ) { wp_die( 'OpenSSL برای انتقال امن رمز لازم است.' ); }
			$encrypted = RKW_Crypto::encrypt( $old['password'] ); if ( 0 !== strpos( $encrypted, 'e:' ) ) { wp_die( 'رمزنگاری رمز ناموفق بود؛ تنظیمات تغییر نکرد.' ); }
			$current['password_enc'] = $encrypted;
		}
		$ext = get_option( RKW_Extensions::OPTION, array() ); $ext = is_array( $ext ) ? $ext : array();
		foreach ( self::extensions_map( $old ) as $key => $value ) { if ( ! array_key_exists( $key, $ext ) || ! empty( $_POST['overwrite'] ) ) { $ext[ $key ] = $value; } }
		update_option( RKW_OPT, $current, false ); update_option( RKW_Extensions::OPTION, $ext, false );
		delete_transient( RKW_Client::COOKIE_TRANSIENT ); delete_transient( 'rkw_cash_register' );
		wp_safe_redirect( admin_url( 'admin.php?page=rkw-migration&saved=1' ) ); exit;
	}
}
