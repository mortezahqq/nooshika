<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Public product views refresh stale linked products, one variant per uncached request. */
class RKW_Product_View {
	const FRESH = '_rkw_catalog_fresh';
	const AGE = 300;
	const RETRY = 60;

	public static function init() {
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'wp_ajax_rkw_product_view', array( __CLASS__, 'ajax' ) );
		add_action( 'wp_ajax_nopriv_rkw_product_view', array( __CLASS__, 'ajax' ) );
	}
	private static function enabled() {
		$s = rkw_settings();
		return ! empty( $s['product_view_refresh'] ) && 'v21' === $s['api'] && ( ! empty( $s['sync_price'] ) || ! empty( $s['sync_stock'] ) );
	}
	public static function signature( $id, $s ) {
		$fields = array( 'shop_id', 'store_ids', 'currency_id', 'customer_id', 'sales_area_id', 'price_field', 'price_divisor', 'key_field', 'sync_price', 'sync_stock', 'sync_sale', 'sync_name' );
		return hash( 'sha256', wp_json_encode( array( (int) $id, RKW_Policy_Catalog::signature( $s ), array_intersect_key( $s, array_flip( $fields ) ) ) ) );
	}
	public static function stamp( $product, $id, $s ) {
		$product->update_meta_data( self::FRESH, array( 'time' => time(), 'signature' => self::signature( $id, $s ) ) );
	}
	private static function identifier( $product, $s ) {
		$id = trim( (string) $product->get_meta( '_rahkaran_product_id', true ) );
		if ( '' === $id && 'id' === $s['key_field'] ) { $id = trim( (string) $product->get_sku( 'edit' ) ); }
		return preg_match( '/^[1-9][0-9]*$/D', $id ) && (string) (int) $id === $id ? (int) $id : 0;
	}
	public static function fresh( $product, $s = null ) {
		if ( ! $product ) { return false; }
		$s = $s ?: rkw_settings(); $id = self::identifier( $product, $s ); $stamp = $product->get_meta( self::FRESH, true );
		return $id && is_array( $stamp ) && isset( $stamp['time'], $stamp['signature'] ) && is_numeric( $stamp['time'] ) && is_string( $stamp['signature'] ) && (int) $stamp['time'] <= time() && (int) $stamp['time'] > time() - self::AGE && hash_equals( self::signature( $id, $s ), $stamp['signature'] );
	}
	private static function parent_product( $id ) {
		$p = wc_get_product( $id );
		return $p && 'publish' === $p->get_status() && ! post_password_required( $id ) && ( $p->is_type( 'simple' ) || $p->is_type( 'variable' ) ) ? $p : false;
	}
	public static function assets() {
		if ( ! self::enabled() || ! is_product() ) { return; }
		$id = get_queried_object_id(); $p = self::parent_product( $id ); if ( ! $p ) { return; }
		$deps = $p->is_type( 'variable' ) ? array( 'jquery', 'wc-add-to-cart-variation' ) : array( 'jquery' );
		wp_enqueue_script( 'rkw-product-view', plugins_url( 'assets/product-view.js', RKW_FILE ), $deps, RKW_VER, true );
		wp_localize_script( 'rkw-product-view', 'rkwProductView', array( 'ajax' => admin_url( 'admin-ajax.php' ), 'product' => (int) $id ) );
	}
	private static function targets( $p, $s ) {
		$ids = $p->is_type( 'variable' ) ? $p->get_children() : array( $p->get_id() ); $out = array();
		foreach ( $ids as $id ) {
			$child = wc_get_product( $id );
			if ( ! $child || 'publish' !== $child->get_status() || ( $p->is_type( 'variable' ) && ( ! $child->is_type( 'variation' ) || (int) $child->get_parent_id() !== (int) $p->get_id() ) ) || ! self::identifier( $child, $s ) ) { continue; }
			$out[] = $child;
		}
		return $out;
	}
	private static function unlock( $key, $lease ) {
		global $wpdb;
		if ( $wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name=%s AND option_value=%s", $key, $lease ) ) ) { wp_cache_delete( $key, 'options' ); }
	}
	private static function refresh( $product, $s ) {
		$id = $product->get_id(); $rid = self::identifier( $product, $s ); $signature = self::signature( $rid, $s );
		$retry = get_transient( 'rkw_view_retry_' . $id );
		if ( is_array( $retry ) && ( $retry['signature'] ?? '' ) === $signature ) { return 'cooldown'; }
		$key = 'rkw_view_lock_' . $id; $lease = wp_json_encode( array( 'token' => wp_generate_uuid4(), 'expires' => time() + 120 ) );
		if ( ! add_option( $key, $lease, '', false ) ) {
			$previous = get_option( $key ); $data = is_string( $previous ) ? json_decode( $previous, true ) : null;
			if ( ! is_array( $data ) || empty( $data['expires'] ) || (int) $data['expires'] >= time() ) { return 'busy'; }
			self::unlock( $key, $previous ); if ( ! add_option( $key, $lease, '', false ) ) { return 'busy'; }
		}
		try {
			// Another visitor may have refreshed it immediately before this lease.
			if ( self::fresh( wc_get_product( $id ), $s ) ) { return 'fresh'; }
			$before = ! empty( $s['sync_stock'] ) ? RKW_Checkout_Stock::outstanding( array( $id ) ) : array();
			$stock_failure = is_wp_error( $before ) ? $before : null;
			$client = new RKW_Client( 5 ); $raw = $client->product_by_id( $rid );
			if ( is_wp_error( $raw ) ) { throw new Exception( 'product_read' ); }
			$item = RKW_Sync::normalize_single( $raw, 'v21' );
			if ( ! $item || (int) $item['id'] !== $rid ) { throw new Exception( 'product_id' ); }
			if ( ! empty( $s['sync_stock'] ) ) {
				$qty = RKW_Sync::quantity_for_product( $client, $rid, $s );
				$after = RKW_Checkout_Stock::outstanding( array( $id ) );
				if ( is_wp_error( $stock_failure ) || is_wp_error( $qty ) || is_wp_error( $after ) ) {
					$stock_failure = is_wp_error( $stock_failure ) ? $stock_failure : ( is_wp_error( $qty ) ? $qty : $after );
				} else {
					foreach ( $after as $iid => $held ) { $before[ $iid ] = max( $before[ $iid ] ?? 0, $held ); }
					$item['stock'] = max( 0, $qty - array_sum( $before ) );
				}
			}
			$current = wc_get_product( $id );
			if ( $s !== rkw_settings() || ! $current || 'publish' !== $current->get_status() || self::identifier( $current, $s ) !== $rid ) { throw new Exception( 'context_changed' ); }
			$result = RKW_Sync::update_target( $id, $item, $client, $stock_failure );
			if ( is_wp_error( $result ) && 'rkw_target_price_only' === $result->get_error_code() ) { throw new Exception( 'price_only' ); }
			if ( is_wp_error( $result ) ) { throw new Exception( 'product_update' ); }
			delete_transient( 'rkw_view_retry_' . $id );
			RKW_Log::add( 'info', 'به‌روزرسانی هنگام مشاهده محصول ووکامرس #' . $id . ' از راهکاران #' . $rid . ' انجام شد.' );
			return 'updated';
		} catch ( Exception $error ) {
			set_transient( 'rkw_view_retry_' . $id, array( 'signature' => $signature ), self::RETRY );
			$reason = in_array( $error->getMessage(), array( 'local_stock', 'product_read', 'product_id', 'stock_read', 'context_changed', 'product_update', 'price_only' ), true ) ? $error->getMessage() : 'unexpected';
			if ( 'price_only' === $reason ) { RKW_Log::add( 'warn', 'قیمت محصول #' . $id . ' به‌روز شد؛ موجودی قبلی حفظ شد و دریافت کامل موفق اعلام نشد.' ); return 'price_updated'; }
			RKW_Log::add( 'warn', 'دریافت هنگام مشاهده محصول #' . $id . ' ناموفق بود؛ آخرین دریافت موفق جلو نرفت. مرحله: ' . $reason );
			return 'failed';
		} finally { self::unlock( $key, $lease ); }
	}
	/** One bounded step. Fresh variants are skipped without ERP requests. */
	public static function step( $parent_id, $cursor = 0 ) {
		if ( ! self::enabled() ) { return array( 'done' => true, 'cursor' => 0, 'updated' => false, 'status' => 'disabled' ); }
		$p = self::parent_product( $parent_id ); if ( ! $p ) { return new WP_Error( 'rkw_view_product', 'محصول عمومی معتبر پیدا نشد.' ); }
		$s = rkw_settings(); $targets = self::targets( $p, $s );
		if ( $cursor < 0 || $cursor > count( $targets ) ) { return new WP_Error( 'rkw_view_cursor', 'درخواست معتبر نیست.' ); }
		$status = 'fresh'; $updated = false; $retry_cursor = null;
		while ( $cursor < count( $targets ) ) {
			$target = $targets[ $cursor++ ];
			if ( self::fresh( $target, $s ) ) { continue; }
			$status = self::refresh( $target, $s ); $updated = in_array( $status, array( 'updated', 'price_updated' ), true ); $retry_cursor = 'busy' === $status ? $cursor - 1 : null; break;
		}
		while ( $cursor < count( $targets ) && self::fresh( $targets[ $cursor ], $s ) ) { $cursor++; }
		if ( $updated && $p->is_type( 'variable' ) ) { WC_Product_Variable::sync( $p->get_id() ); }
		return array( 'done' => $cursor >= count( $targets ), 'cursor' => $cursor, 'updated' => $updated, 'status' => $status, 'retry_cursor' => $retry_cursor );
	}
	/** Native public display data, including when the page HTML itself came from cache. */
	public static function display( $id, $include_cart = false ) {
		$p = self::parent_product( $id ); if ( ! $p ) { return array(); }
		$variations = $p->is_type( 'variable' ) && count( $p->get_children() ) > 30 ? false : array();
		if ( $p->is_type( 'variable' ) && count( $p->get_children() ) <= 30 ) {
			$variations = $p->get_available_variations();
		}
		$html = '';
		if ( $include_cart && $p->is_purchasable() && $p->is_in_stock() ) {
			$previous = $GLOBALS['product'] ?? null; $GLOBALS['product'] = $p;
			ob_start();
			try { woocommerce_template_single_add_to_cart(); $html = ob_get_contents(); }
			catch ( Exception $error ) { $html = ''; }
			finally { ob_end_clean(); $GLOBALS['product'] = $previous; }
		}
		return array( 'price_html' => $p->get_price_html(), 'stock_html' => wc_get_stock_html( $p ), 'in_stock' => $p->is_in_stock(), 'purchasable' => $p->is_purchasable(), 'quantity_min' => $p->get_min_purchase_quantity(), 'quantity_max' => $p->get_max_purchase_quantity(), 'variable' => $p->is_type( 'variable' ), 'variations' => $variations, 'cart_html' => $html );
	}
	public static function ajax() {
		// This is a public product-view operation. No expiring nonce is embedded in
		// cached pages; publication checks, freshness leases and retries bound the work.
		nocache_headers();
		$id = isset( $_POST['product_id'] ) ? wp_unslash( $_POST['product_id'] ) : '';
		$cursor = isset( $_POST['cursor'] ) ? wp_unslash( $_POST['cursor'] ) : '0';
		if ( ! is_string( $id ) || ! preg_match( '/^[1-9][0-9]{0,9}$/D', $id ) || ! is_string( $cursor ) || ! preg_match( '/^[0-9]{1,6}$/D', $cursor ) ) { wp_send_json_error( array( 'message' => 'درخواست معتبر نیست.' ), 400 ); }
		$result = self::step( (int) $id, (int) $cursor );
		if ( is_wp_error( $result ) ) { wp_send_json_error( array( 'message' => $result->get_error_message() ), 400 ); }
		if ( 'disabled' !== $result['status'] ) { $result['display'] = self::display( (int) $id, isset( $_POST['include_cart'] ) && '1' === $_POST['include_cart'] ); }
		wp_send_json_success( $result );
	}
}
