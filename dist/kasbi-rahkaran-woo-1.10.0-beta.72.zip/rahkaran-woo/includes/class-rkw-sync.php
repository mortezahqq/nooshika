<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * همگام‌سازی راهکاران -> ووکامرس (کالا، موجودی، قیمت).
 * هر دو نسخه‌ی API به یک ساختار یکسان نرمال می‌شوند:
 *  [ id, key, name, unit, stock(float|null), price(float|null), sale(float|null) ]
 */
class RKW_Sync {
	const CURSOR = 'rkw_cursor';
	const STATS  = 'rkw_last_run';
	const LOCK   = 'rkw_sync_lock';

	public static function init() {
		add_action( 'rkw_cron_sync', array( __CLASS__, 'cron_run' ) );
		add_action( 'rkw_cron_continue', array( __CLASS__, 'cron_run' ) );
	}

	public static function reschedule() {
		wp_clear_scheduled_hook( 'rkw_cron_sync' );
		$s = rkw_settings();
		if ( 'off' !== $s['cron_interval'] ) {
			wp_schedule_event( time() + 5, $s['cron_interval'], 'rkw_cron_sync' );
		}
		if ( class_exists( 'RKW_Sync_Runner' ) ) { RKW_Sync_Runner::cancel_pending(); }
	}

	public static function cron_run() { RKW_Sync_Runner::kick(); }

	public static function reset() {
		$s = rkw_settings();
		update_option( self::CURSOR, array(
			'pos' => ( 'v21' === $s['api'] ) ? (int) $s['page_start'] : 0,
			'processed' => 0, 'created' => 0, 'updated' => 0, 'skipped' => 0, 'errors' => 0,
			'last_first' => '', 'started' => current_time( 'mysql' ),
			'heartbeat' => time(),
			'signature' => self::sync_signature( $s ),
		), false );
	}

	private static function sync_signature( $s ) {
		$keys = array_flip( array( 'api', 'protocol', 'ip', 'port', 'cluster', 'username', 'password_enc', 'store_ids', 'shop_id', 'currency_id', 'customer_id', 'sales_area_id', 'price_field', 'price_divisor', 'key_field', 'sync_price', 'sync_stock', 'sync_sale', 'sync_sale_authoritative', 'sync_name', 'create_missing', 'page_start', 'batch_size' ) );
		return md5( wp_json_encode( array_intersect_key( $s, $keys ) ) );
	}

	private static function store_filter( $s ) {
		return array_values( array_filter( array_map( 'intval', explode( ',', (string) $s['store_ids'] ) ) ) );
	}
	public static function quantity_for_product( $client, $id, $s ) { return self::stock21( $client, $id, self::store_filter( $s ), true ); }

	private static function norm_unit( $it ) {
		if ( isset( $it['RetailUnitRef'] ) && $it['RetailUnitRef'] ) { return (int) $it['RetailUnitRef']; }
		if ( isset( $it['retailUnitRef'] ) && $it['retailUnitRef'] ) { return (int) $it['retailUnitRef']; }
		if ( isset( $it['unitRef'] ) ) { return (int) $it['unitRef']; }
		if ( ! empty( $it['units'] ) && is_array( $it['units'] ) ) {
			foreach ( $it['units'] as $u ) { if ( ! empty( $u['isDefault'] ) ) { return (int) $u['id']; } }
			return (int) $it['units'][0]['id'];
		}
		return 0;
	}

	/** Only a public sale amount explicitly present on this exact ERP product may be synced. */
	private static function sale_price21( $raw ) {
		$base = isset( $raw['fee'] ) && is_numeric( $raw['fee'] ) ? (float) $raw['fee'] : null;
		if ( null === $base || ! is_finite( $base ) || $base <= 0 ) { return null; }
		foreach ( array( 'discountedPrice', 'discountPrice', 'salePrice', 'discountedFee', 'netOfFee', 'DiscountedPrice', 'DiscountPrice', 'SalePrice', 'DiscountedFee', 'NetOfFee' ) as $key ) {
			$value = $raw[ $key ] ?? null;
			if ( ! is_bool( $value ) && is_numeric( $value ) && is_finite( (float) $value ) && (float) $value > 0 && (float) $value < $base ) { return (float) $value; }
		}
		return null;
	}

	/** Apply only a verified, public one-unit line discount. */
	public static function calculate_sale( $item, $settings, $client ) {
		if ( 'v21' !== $settings['api'] || empty( $settings['sync_price'] ) || empty( $settings['sync_sale'] ) || ( empty( $settings['sync_sale_authoritative'] ) && null !== ( $item['sale'] ?? null ) ) ) {
			return $item;
		}
		$item['sale'] = null;
		$result = $client->calculate_public_product_price( $item, $settings );
		$item['sale_notice'] = 'قیمت ویژه قبلی حفظ شد؛ مبلغ تخفیف معتبر از محاسبه راهکاران دریافت نشد.';
		if ( is_wp_error( $result ) ) {
			$item['sale_notice'] .= ' ' . $result->get_error_message();
			return $item;
		}
		if ( ! is_array( $result ) || ! empty( $result['hasError'] ) || ! is_array( $result['items'] ?? null ) || count( $result['items'] ) !== 1 ) {
			return $item;
		}
		$row = reset( $result['items'] );
		if ( ! is_array( $row ) || ! is_numeric( $row['productId'] ?? null ) || ! is_numeric( $row['unitId'] ?? null )
			|| (float) $row['productId'] !== (float) $item['id'] || (float) $row['unitId'] !== (float) $item['unit']
			|| ! is_numeric( $row['quantity'] ?? null ) || (float) $row['quantity'] !== 1.0 ) {
			return $item;
		}
		$message = $row['errorMessage'] ?? '';
		$stock_shortage = is_string( $message ) && preg_match( '/^موجودی محصول در انبار کافی نیست[.؟]?(?:\s*\([^()]* واحد کسری دارد\))?\s*$/uD', trim( $message ) );
		if ( ! empty( $row['hasError'] ) && ! $stock_shortage ) { return $item; }
		foreach ( array( $item['price'] ?? null, $row['price'] ?? null, $row['netPrice'] ?? null, $result['netPrice'] ?? null ) as $amount ) {
			if ( ! is_numeric( $amount ) || ! is_finite( (float) $amount ) || $amount <= 0 ) { return $item; }
		}
		$base = (float) $row['price'];
		$net = (float) $row['netPrice'];
		if ( abs( $base - $item['price'] ) > 0.01 || abs( $net - (float) $result['netPrice'] ) > 0.01 || $net > $base ) { return $item; }
		if ( ! is_array( $row['policies'] ?? null ) ) { return $item; }
		$discount = 0.0;
		foreach ( $row['policies'] as $policy ) {
			if ( ! is_array( $policy ) ) { return $item; }
			if ( true !== ( $policy['isIncluded'] ?? false ) ) { continue; }
			$amount = $policy['price'] ?? null;
			if ( ! is_numeric( $amount ) || ! is_finite( (float) $amount ) || $amount < 0 ) { return $item; }
			if ( (float) $amount === 0.0 ) { continue; }
			if ( ! in_array( $policy['type'] ?? '', array( 'Discount', 'CustomRetailMeasurementUnitDiscount' ), true ) || ! in_array( $policy['effect'] ?? null, array( 3, '3' ), true ) ) { return $item; }
			$discount += (float) $amount;
		}
		if ( ! is_finite( $discount ) || abs( ( $base - $net ) - $discount ) > 0.01 ) { return $item; }
		if ( $discount <= 0 || $net >= $base ) {
			$item['sale_absent'] = true;
			$item['sale_notice'] = 'محاسبه راهکاران برای این کالا تخفیفی برنگرداند.';
			return $item;
		}
		$item['sale'] = $net;
		$item['sale_confirmed'] = true;
		$item['sale_notice'] = 'قیمت ویژه از سیاست تخفیف عمومی راهکاران دریافت شد.';
		if ( $stock_shortage ) { $item['sale_notice'] .= ' محاسبه برای این انبار کسری موجودی گزارش کرد.'; }
		return $item;
	}

	/** نرمال‌سازی داده تک‌محصول. مقدار null به معنی «اطلاعات ارائه نشده» است. */
	public static function normalize_single( $raw, $api ) {
		if ( ! is_array( $raw ) ) { return null; }
		$id = isset( $raw['productId'] ) ? absint( $raw['productId'] ) : ( isset( $raw['id'] ) ? absint( $raw['id'] ) : 0 );
		if ( ! $id ) { return null; }
		$v21 = 'v21' === $api;
		return array(
			'id'    => $id,
			'code'  => isset( $raw['productNumber'] ) ? trim( (string) $raw['productNumber'] ) : ( isset( $raw['code'] ) ? trim( (string) $raw['code'] ) : '' ),
			'name'  => isset( $raw['productName'] ) ? trim( (string) $raw['productName'] ) : ( isset( $raw['name'] ) ? trim( (string) $raw['name'] ) : '' ),
			'unit'  => self::norm_unit( $raw ) ?: null,
			'stock' => ! $v21 && isset( $raw['remaining'] ) && is_numeric( $raw['remaining'] ) ? (float) $raw['remaining'] : null,
			'price' => $v21 && isset( $raw['fee'] ) && is_numeric( $raw['fee'] ) ? (float) $raw['fee'] : null,
			'sale'  => $v21 ? self::sale_price21( $raw ) : null,
		);
	}

	/** بروزرسانی یک محصول/متغیر موجود بدون ساخت هیچ محصول جدیدی. */
	public static function update_target( $woocommerce_id, $item, $client = null, $stock_failure = null ) {
		$woocommerce_id = absint( $woocommerce_id );
		$product = $woocommerce_id ? wc_get_product( $woocommerce_id ) : false;
		if ( ! $product || ! is_array( $item ) || empty( $item['id'] ) ) { return new WP_Error( 'rkw_target', 'محصول یا شناسه راهکاران معتبر نیست.' ); }
		$client = $client ? $client : new RKW_Client();
		$s = rkw_settings();
		// A targeted refresh must not report success while retaining an enabled field after an API failure.
		if ( ! empty( $s['sync_price'] ) && ( ! isset( $item['price'] ) || ! is_numeric( $item['price'] ) || ! is_finite( (float) $item['price'] ) || (float) $item['price'] <= 0 ) ) {
			return new WP_Error( 'rkw_target_price', 'راهکاران قیمت معتبر و مثبت برای این محصول برنگرداند؛ قیمت و موجودی محصول تغییر نکرد.' );
		}
		if ( $s !== rkw_settings() ) { return new WP_Error( 'rkw_target_changed', 'تنظیمات هنگام دریافت تغییر کرد؛ محصول تغییر نکرد.' ); }
		$price_saved = false;
		$result = self::apply( $item, $s, $client, self::store_filter( $s ), $woocommerce_id, $stock_failure, $price_saved );
		if ( $price_saved && is_wp_error( $stock_failure ) ) { return new WP_Error( 'rkw_target_price_only', 'قیمت به‌روز شد؛ دریافت موجودی ناموفق بود و موجودی قبلی حفظ شد. علت: ' . $stock_failure->get_error_message() . ( empty( $item['sale_notice'] ) ? '' : ' ' . $item['sale_notice'] ), array( 'price_updated' => true, 'stock_updated' => false ) ); }
		return 'updated' === $result ? true : new WP_Error( 'rkw_apply', 'بروزرسانی محصول در ووکامرس ناموفق بود.' );
	}

	/** دریافت یک صفحه و نرمال‌سازی. خروجی: [items, raw_count] یا WP_Error */
	private static function fetch( $cur, $s, $client ) {
		$size = max( 5, min( 200, (int) $s['batch_size'] ) );

		if ( 'v21' === $s['api'] ) {
			$raw = $client->products21( $cur['pos'], $size );
			if ( is_wp_error( $raw ) ) { return $raw; }
			if ( ! is_array( $raw ) || array_values( $raw ) !== $raw ) { return new WP_Error( 'rkw_product_page', 'قالب فهرست محصولات راهکاران معتبر نیست؛ پیشرفت حفظ شد.' ); }
			$items = array();
			foreach ( $raw as $it ) {
				if ( ! is_array( $it ) || ! isset( $it['productId'] ) || ! preg_match( '/^[1-9][0-9]*$/D', (string) $it['productId'] ) ) { return new WP_Error( 'rkw_product_page', 'شناسه معتبر کالا در فهرست راهکاران وجود ندارد؛ پیشرفت حفظ شد.' ); }
				$items[] = array(
					'id'    => (int) $it['productId'],
					'code'  => isset( $it['productNumber'] ) ? trim( (string) $it['productNumber'] ) : '',
					'name'  => isset( $it['productName'] ) ? trim( (string) $it['productName'] ) : '',
					'unit'  => self::norm_unit( $it ),
					'stock' => null,
					'price' => isset( $it['fee'] ) ? (float) $it['fee'] : null,
					'sale'  => self::sale_price21( $it ),
				);
			}
			return array( $items, count( $raw ), $size );
		}

		$raw = $client->products19( $cur['pos'], $size );
		if ( is_wp_error( $raw ) ) { return $raw; }
		if ( ! is_array( $raw ) || array_values( $raw ) !== $raw ) { return new WP_Error( 'rkw_product_page', 'قالب فهرست محصولات راهکاران معتبر نیست؛ پیشرفت حفظ شد.' ); }
		$items = array();
		$units = array();
		foreach ( $raw as $it ) {
			if ( ! is_array( $it ) || ! isset( $it['id'] ) || ! preg_match( '/^[1-9][0-9]*$/D', (string) $it['id'] ) ) { return new WP_Error( 'rkw_product_page', 'شناسه معتبر کالا در فهرست راهکاران وجود ندارد؛ پیشرفت حفظ شد.' ); }
			$unit  = self::norm_unit( $it );
			$units[ (int) $it['id'] ] = $unit;
			$items[ (int) $it['id'] ] = array(
				'id'    => (int) $it['id'],
				'code'  => isset( $it['code'] ) ? trim( (string) $it['code'] ) : '',
				'name'  => isset( $it['name'] ) ? trim( (string) $it['name'] ) : '',
				'unit'  => $unit,
				'stock' => isset( $it['remaining'] ) ? (float) $it['remaining'] : null,
				'price' => null,
				'sale'  => null,
			);
		}
		if ( $s['sync_price'] && $units ) {
			$pr = $client->prices19( $units );
			if ( is_wp_error( $pr ) ) {
				RKW_Log::add( 'error', 'دریافت قیمت: ' . $pr->get_error_message() );
			} else {
				$ids = array_keys( $units );
				foreach ( (array) $pr as $row ) {
					$idx = isset( $row['itemId'] ) ? (int) $row['itemId'] - 1 : -1;
					if ( ! isset( $ids[ $idx ] ) ) { continue; }
					$pid   = $ids[ $idx ];
					$field = $s['price_field'];
					$val   = isset( $row[ $field ] ) ? (float) $row[ $field ] : 0;
					$items[ $pid ]['price'] = $val > 0 ? $val : null;
					$disc = isset( $row['discount'] ) ? (float) $row['discount'] : 0;
					if ( $disc > 0 && ! empty( $row['netOfFee'] ) ) { $items[ $pid ]['sale'] = (float) $row['netOfFee']; }
				}
			}
		}
		return array( array_values( $items ), count( $raw ), $size );
	}

	/** Release only the lease owned by this worker, including after expiry/replacement. */
	private static function release_lock( $lease ) {
		global $wpdb;
		$deleted = $wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name=%s AND option_value=%s", self::LOCK, $lease ) );
		if ( $deleted ) { wp_cache_delete( self::LOCK, 'options' ); }
	}

	/** One bounded work slice. Every item is checkpointed before the next network call. */
	public static function step( $reset = false, $limit = 5, $budget = 15 ) {
		$s = rkw_settings();
		$lease = wp_json_encode( array( 'token' => wp_generate_uuid4(), 'expires' => time() + max( 120, (int) $s['timeout'] * 6 + 30 ) ) );
		if ( ! add_option( self::LOCK, $lease, '', false ) ) {
			$previous = get_option( self::LOCK ); $decoded = is_string( $previous ) ? json_decode( $previous, true ) : null;
			if ( ! is_array( $decoded ) || empty( $decoded['expires'] ) || (int) $decoded['expires'] >= time() ) { return new WP_Error( 'rkw_sync_busy', 'همگام‌سازی دیگری در حال اجراست؛ پیشرفت آن حفظ شده است.' ); }
			self::release_lock( $previous );
			if ( ! add_option( self::LOCK, $lease, '', false ) ) { return new WP_Error( 'rkw_sync_busy', 'همگام‌سازی دیگری در حال اجراست.' ); }
		}
		try {
			if ( $reset ) { self::reset(); }
			return self::work_slice( $s, max( 1, min( 20, (int) $limit ) ), max( 0, (float) $budget ) );
		} finally { self::release_lock( $lease ); }
	}

	private static function work_slice( $s, $limit, $budget ) {
		$started = microtime( true );
		$cur = get_option( self::CURSOR );
		if ( ! is_array( $cur ) || empty( $cur['signature'] ) || self::sync_signature( $s ) !== $cur['signature'] ) { self::reset(); $cur = get_option( self::CURSOR ); }
		$client = new RKW_Client();
		if ( empty( $cur['pending_items'] ) && empty( $cur['page_done'] ) ) {
			$res = self::fetch( $cur, $s, $client );
			if ( is_wp_error( $res ) ) { RKW_Log::add( 'error', 'دریافت محصولات: ' . $res->get_error_message() ); return $res; }
			list( $items, $raw_count, $size ) = $res;
			$first = $items ? $items[0]['id'] : '';
			if ( '' !== $first && (string) $first === (string) $cur['last_first'] && $cur['processed'] > 0 ) {
				return new WP_Error( 'rkw_sync_pagination', 'راهکاران صفحه قبلی را تکرار کرد؛ پیشرفت حفظ شد. تنظیم شماره صفحه اول و تعداد دسته را بررسی کنید.' );
			}
			$cur['last_first'] = $first;
			$cur['pending_items'] = array_values( $items );
			$cur['page_done'] = $raw_count < $size;
			$cur['pos'] = 'v21' === $s['api'] ? $cur['pos'] + 1 : $cur['pos'] + $raw_count;
			update_option( self::CURSOR, $cur, false );
		}
		$stores = self::store_filter( $s ); $handled = 0;
		while ( ! empty( $cur['pending_items'] ) ) {
			$it = reset( $cur['pending_items'] );
			$result = self::apply( $it, $s, $client, $stores );
			if ( isset( $cur[ $result ] ) ) { $cur[ $result ]++; }
			array_shift( $cur['pending_items'] ); $cur['processed']++;
			if ( 'skipped' !== $result ) { $handled++; }
			$cur['heartbeat'] = time();
			update_option( self::CURSOR, $cur, false );
			if ( $handled >= $limit || microtime( true ) - $started >= $budget ) { break; }
		}
		$done = empty( $cur['pending_items'] ) && ! empty( $cur['page_done'] );
		if ( $done ) {
			$cur['finished'] = current_time( 'mysql' ); $cur['finished_at'] = time(); unset( $cur['pending_items'], $cur['page_done'] );
			update_option( self::STATS, $cur, false ); delete_option( self::CURSOR );
			RKW_Log::add( 'info', sprintf( 'همگام‌سازی کامل شد: %d بررسی، %d ایجاد، %d بروزرسانی، %d نادیده، %d خطا', $cur['processed'], $cur['created'], $cur['updated'], $cur['skipped'], $cur['errors'] ) );
		}
		return array( 'done' => $done, 'processed' => $cur['processed'], 'created' => $cur['created'], 'updated' => $cur['updated'], 'skipped' => $cur['skipped'], 'errors' => $cur['errors'] );
	}

	/** Explicit per-product/variation ID takes precedence over the configured SKU fallback. */
	private static function find_product_id( $it, $s ) {
		global $wpdb;
		$ids = $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT p.ID FROM {$wpdb->posts} p INNER JOIN {$wpdb->postmeta} m ON m.post_id=p.ID WHERE m.meta_key=%s AND m.meta_value=%s AND p.post_type IN ('product','product_variation') AND p.post_status NOT IN ('trash','auto-draft')", '_rahkaran_product_id', (string) $it['id'] ) );
		if ( ! empty( $wpdb->last_error ) || ! is_array( $ids ) ) { return new WP_Error( 'rkw_product_mapping_read', 'خواندن اتصال کالاهای ووکامرس ناموفق بود؛ هیچ SKU جایگزینی انتخاب نشد.' ); }
		$matches = array();
		foreach ( $ids as $id ) {
			$product = wc_get_product( (int) $id );
			if ( $product && ( $product->is_type( 'simple' ) || $product->is_type( 'variation' ) ) ) { $matches[] = (int) $id; }
		}
		if ( count( $matches ) > 1 ) { return new WP_Error( 'rkw_product_mapping_duplicate', 'شناسه راهکاران ' . (int) $it['id'] . ' به بیش از یک محصول/متغیر ووکامرس متصل است؛ اتصال تکراری را اصلاح کنید.' ); }
		if ( $matches ) { return $matches[0]; }
		$sku = ( 'id' === $s['key_field'] ) ? (string) $it['id'] : $it['code'];
		if ( '' === $sku ) { return 0; }
		$pid = wc_get_product_id_by_sku( $sku );
		$product = $pid ? wc_get_product( $pid ) : false;
		if ( $product && ! $product->is_type( 'simple' ) && ! $product->is_type( 'variation' ) ) { return new WP_Error( 'rkw_product_mapping_parent', 'SKU کالای راهکاران به محصول والد متغیر یا نوع پشتیبانی‌نشده وصل است؛ شناسه را روی متغیر مستقل وارد کنید.' ); }
		if ( $product && absint( $product->get_meta( '_rahkaran_product_id', true ) ) && (int) $product->get_meta( '_rahkaran_product_id', true ) !== (int) $it['id'] ) { return new WP_Error( 'rkw_product_mapping_conflict', 'SKU با یک کالای راهکاران منطبق است ولی شناسه مستقل ذخیره‌شده ووکامرس متفاوت است؛ اتصال موجود بازنویسی نشد.' ); }
		return $pid ? (int) $pid : 0;
	}

	/** موجودی v21: جمع RemainingQuantity انبارهای انتخابی (یا همه). null یعنی خطا/نامشخص */
	private static function stock21( $client, $pid, $stores, $strict = false ) {
		$rows = $client->remaining21( $pid );
		if ( is_wp_error( $rows ) ) {
			RKW_Log::add( 'error', 'موجودی کالا ' . $pid . ': ' . $rows->get_error_message() );
			return $strict ? $rows : null;
		}
		if ( $strict && ( ! is_array( $rows ) || array_values( $rows ) !== $rows ) ) { return new WP_Error( 'rkw_target_stock', 'قالب پاسخ موجودی راهکاران معتبر نیست؛ محصول تغییر نکرد.' ); }
		$sum = 0.0;
		$seen = array();
		foreach ( (array) $rows as $row ) {
			$store = is_array( $row ) ? ( $row['StoreID'] ?? $row['storeID'] ?? $row['storeId'] ?? null ) : null;
			if ( $strict && ( ! is_scalar( $store ) || ! preg_match( '/^[1-9][0-9]*$/D', (string) $store ) ) ) {
				return new WP_Error( 'rkw_target_stock', sprintf( 'شناسه انبار در پاسخ موجودی کالای %d معتبر نیست.', $pid ) );
			}
			$store_id = (int) $store;
			if ( $stores && ! in_array( $store_id, $stores, true ) ) { continue; }
			$seen[] = $store_id;
			$quantity = $row['RemainingQuantity'] ?? $row['remainingQuantity'] ?? null;
			if ( $strict && ( ! is_numeric( $quantity ) || ! is_finite( (float) $quantity ) ) ) {
				return new WP_Error(
					'rkw_target_stock',
					sprintf( 'راهکاران برای کالای %d در انبار %d موجودی قابل فروش عددی برنگرداند.', $pid, $store_id )
				);
			}
			$sum += (float) $quantity;
		}
		if ( $strict && $rows && $stores ) {
			$missing = array_diff( $stores, $seen );
			if ( $missing ) {
				return new WP_Error( 'rkw_target_stock', sprintf( 'پاسخ موجودی کالای %d ردیف انبارهای تنظیم‌شدهٔ %s را ندارد.', $pid, implode( ', ', $missing ) ) );
			}
		}
		return $sum;
	}

	/** اعمال یک کالا روی ووکامرس. خروجی: created|updated|skipped|errors */
	private static function apply( $it, $s, $client, $stores, $target_id = 0, &$stock_failure = null, &$price_saved = null ) {
		$price_saved = false;
		if ( empty( $it['id'] ) ) { return 'skipped'; }

		$wid = $target_id ? absint( $target_id ) : self::find_product_id( $it, $s );
		if ( is_wp_error( $wid ) ) { RKW_Log::add( 'error', $wid->get_error_message() ); return 'errors'; }
		$new = false;
		if ( ! $wid ) {
			if ( ! $s['create_missing'] || ( 'id' !== $s['key_field'] && '' === $it['code'] ) ) { return 'skipped'; }
			$p = new WC_Product_Simple();
			$p->set_sku( ( 'id' === $s['key_field'] ) ? (string) $it['id'] : $it['code'] );
			$p->set_name( '' !== $it['name'] ? $it['name'] : $it['code'] );
			$p->set_status( 'draft' );
			$new = true;
		} else {
			$p = wc_get_product( $wid );
			if ( ! $p ) { return 'errors'; }
			if ( $s['sync_name'] && '' !== $it['name'] && ! $p->is_type( 'variation' ) ) { $p->set_name( $it['name'] ); }
		}

		$p->update_meta_data( '_rahkaran_product_id', (int) $it['id'] );
		if ( ! empty( $it['unit'] ) ) { $p->update_meta_data( '_rahkaran_unit_id', (int) $it['unit'] ); }
		$price_missing = ! empty( $s['sync_price'] ) && ( ! isset( $it['price'] ) || ! is_numeric( $it['price'] ) || ! is_finite( (float) $it['price'] ) || (float) $it['price'] <= 0 );
		if ( ! $target_id && ! $price_missing ) {
			$it = self::calculate_sale( $it, $s, $client );
			if ( $s !== rkw_settings() ) { return 'errors'; }
		}
		if ( ! empty( $it['sale_notice'] ) ) { RKW_Log::add( empty( $it['sale_confirmed'] ) && empty( $it['sale_absent'] ) ? 'warn' : 'info', 'کالا #' . (int) $it['id'] . ': ' . $it['sale_notice'] ); }
		$stock_fresh = empty( $s['sync_stock'] );

		if ( $s['sync_stock'] ) {
			$qty = is_wp_error( $stock_failure ) ? $stock_failure : ( $it['stock'] ?? null );
			if ( null === $qty && 'v21' === $s['api'] ) { $qty = self::stock21( $client, $it['id'], $stores, true ); }
			if ( $s !== rkw_settings() ) { return 'errors'; }
			if ( ! is_wp_error( $qty ) && ( ! is_numeric( $qty ) || ! is_finite( (float) $qty ) ) ) { $qty = new WP_Error( 'rkw_target_stock', 'موجودی معتبر دریافت نشد.' ); }
			if ( is_wp_error( $qty ) ) {
				$stock_failure = $qty;
				if ( $new || empty( $s['sync_price'] ) || $price_missing ) { RKW_Log::add( 'error', 'موجودی کالا ' . $it['id'] . ': دریافت موجودی معتبر ناموفق بود؛ محصول ذخیره نشد.' ); return 'errors'; }
			} else {
				$stock_fresh = true;
				$qty = max( 0, (float) $qty );
				$p->set_manage_stock( true );
				$p->set_stock_quantity( (int) floor( $qty ) );
				$p->set_stock_status( $qty >= 1 ? 'instock' : 'outofstock' );
			}
		}

		if ( $s['sync_price'] && ! $price_missing ) {
			$div = rkw_price_multiplier( $s );
			$p->set_regular_price( (string) round( $it['price'] / $div ) );
			if ( $s['sync_sale'] && ( 'v19' === $s['api'] || ! empty( $it['sale_confirmed'] ) || ( empty( $s['sync_sale_authoritative'] ) && isset( $it['sale'] ) && is_numeric( $it['sale'] ) && is_finite( (float) $it['sale'] ) && (float) $it['sale'] > 0 && (float) $it['sale'] < (float) $it['price'] ) ) ) {
				if ( null !== $it['sale'] ) {
					$sale_price = (string) round( $it['sale'] / $div );
					if ( empty( $it['sale_confirmed'] ) || ( (float) $sale_price > 0 && (float) $sale_price < (float) $p->get_regular_price( 'edit' ) ) ) {
						if ( 'v21' === $s['api'] && (float) $sale_price !== (float) $p->get_sale_price( 'edit' ) ) {
							$p->update_meta_data( '_rkw_calculated_sale', $sale_price );
						}
						$p->set_sale_price( $sale_price );
					}
				}
				else { $p->set_sale_price( '' ); }
			}
			if ( $s['sync_sale'] && ! empty( $it['sale_absent'] ) ) {
				$managed_sale = $p->get_meta( '_rkw_calculated_sale', true );
				if ( ! empty( $s['sync_sale_authoritative'] ) || ( '' !== (string) $managed_sale && (float) $managed_sale === (float) $p->get_sale_price( 'edit' ) ) ) {
					$p->set_sale_price( '' );
				}
				$p->update_meta_data( '_rkw_calculated_sale', '' );
			}
			// WooCommerce also stores the active price separately from the regular price.
			// Preserve an existing sale when sale synchronization is disabled.
			$regular = (float) $p->get_regular_price( 'edit' );
			$sale = $p->get_sale_price( 'edit' );
			$p->set_price( '' !== (string) $sale && (float) $sale < $regular ? (string) $sale : (string) $regular );
		}

		try {
			$p->save();
			if ( ! $target_id && $p->is_type( 'variation' ) && $p->get_parent_id() ) {
				WC_Product_Variable::sync( $p->get_parent_id() );
			}
			$price_saved = ! empty( $s['sync_price'] ) && ! $price_missing;
			if ( ! $price_missing && $stock_fresh && ( ! empty( $s['sync_stock'] ) || ! empty( $s['sync_price'] ) ) ) {
				RKW_Product_View::stamp( $p, $it['id'], $s ); $p->save_meta_data();
			}
		} catch ( Exception $e ) {
			RKW_Log::add( 'error', 'ذخیره محصول ' . $it['code'] . ': ' . $e->getMessage() );
			return 'errors';
		}
		if ( $price_saved && is_wp_error( $stock_failure ) ) { RKW_Log::add( 'warn', 'کالای راهکاران ' . $it['id'] . ': قیمت به‌روز شد؛ موجودی قبلی به علت خطای دریافت موجودی حفظ شد.' ); return 'errors'; }
		if ( $price_missing ) { RKW_Log::add( 'error', 'کالای راهکاران ' . $it['id'] . ': قیمت معتبر ارائه نشد و قیمت قبلی حفظ شد؛ سایر فیلدهای فعال ذخیره شدند.' ); return 'errors'; }
		return $new ? 'created' : 'updated';
	}
}
