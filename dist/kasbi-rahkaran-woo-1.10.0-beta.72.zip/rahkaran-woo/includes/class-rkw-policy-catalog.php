<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Configurable Rahkaran identifiers, sourced from the active connection only. */
class RKW_Policy_Catalog {
	const OPTION = 'rkw_policy_catalog';
	const SCHEMA = 2;

	/** Labels are translations only; they never authorize a key absent from the server list. */
	public static function receipt_labels() {
		return array( 'Cash' => 'نقدی', 'EReceipt' => 'دریافت الکترونیکی', 'BankReceipt' => 'فیش بانکی', 'CreditNote' => 'یادداشت اعتباری', 'LoyaltyCredit' => 'اعتبار وفاداری', 'ThirdPartyCredit' => 'اعتبار طرف قرارداد', 'Coupon' => 'بن / کوپن', 'ThirdPartyCoupon' => 'بن سازمانی', 'PersonnelCredit' => 'اعتبار پرسنلی', 'Wallet' => 'کیف پول' );
	}
	public static function receipt_label( $key, $names = array() ) {
		$titles = array();
		foreach ( $names as $name ) {
			$name = sanitize_text_field( (string) $name );
			if ( '' !== $name && preg_match( '/[\x{0600}-\x{06FF}]/u', $name ) ) { $titles[ $name ] = $name; }
		}
		$labels = self::receipt_labels();
		$title = $titles ? implode( ' / ', $titles ) : ( $labels[ $key ] ?? ( $names ? sanitize_text_field( (string) reset( $names ) ) : 'نوع دریافت' ) );
		return $title . ' (' . $key . ')';
	}
	public static function receipt_choices( $policy_id, $type, $selected = '' ) {
		$catalog = self::stored(); $choices = array();
		foreach ( isset( $catalog[ $type ] ) ? (array) $catalog[ $type ] : array() as $policy ) {
			if ( ! is_array( $policy ) || ! isset( $policy['id'] ) || (int) $policy['id'] !== (int) $policy_id ) { continue; }
			foreach ( isset( $policy['keys'] ) ? (array) $policy['keys'] : array() as $key ) {
				$names = array();
				foreach ( isset( $policy['methods'] ) ? (array) $policy['methods'] : array() as $method ) { if ( ( $method['key'] ?? '' ) === $key && ! empty( $method['name'] ) ) { $names[] = $method['name']; } }
				$choices[ $key ] = self::receipt_label( $key, $names );
			}
			break;
		}
		if ( '' !== $selected && ! isset( $choices[ $selected ] ) ) { $choices[ $selected ] = self::receipt_label( $selected ) . ' — مقدار ذخیره‌شده؛ در فهرست فعلی نیست'; }
		return $choices;
	}

	public static function signature( $settings = null ) {
		$s = is_array( $settings ) ? $settings : rkw_settings();
		$parts = array();
		foreach ( array( 'api', 'protocol', 'ip', 'port', 'cluster', 'username', 'machine_name', 'password_enc', 'document_contract' ) as $field ) {
			$parts[] = isset( $s[ $field ] ) ? (string) $s[ $field ] : '';
		}
		return hash( 'sha256', implode( "\x00", $parts ) );
	}

	public static function stored() {
		$v = get_option( self::OPTION, array() );
		return is_array( $v ) && isset( $v['signature'] ) && hash_equals( self::signature(), (string) $v['signature'] ) ? $v : array();
	}

	private static function rows( $data ) {
		if ( ! is_array( $data ) ) { return array(); }
		foreach ( array( 'items', 'data', 'Items', 'Data' ) as $field ) {
			if ( isset( $data[ $field ] ) && is_array( $data[ $field ] ) ) { $data = $data[ $field ]; break; }
		}
		return array_values( $data ) === $data ? $data : array( $data );
	}

	private static function number( $row, $keys ) {
		foreach ( $keys as $k ) {
			if ( isset( $row[ $k ] ) && is_numeric( $row[ $k ] ) ) { return absint( $row[ $k ] ); }
		}
		return 0;
	}

	private static function title( $row, $keys ) {
		foreach ( $keys as $k ) {
			if ( isset( $row[ $k ] ) && is_scalar( $row[ $k ] ) ) { return sanitize_text_field( (string) $row[ $k ] ); }
		}
		return '';
	}

	private static function policies( $data ) {
		$out = array();
		foreach ( array_slice( self::rows( $data ), 0, 500 ) as $row ) {
			if ( ! is_array( $row ) ) { continue; }
			$id = self::number( $row, array( 'settlementPolicyID', 'settlementPolicyId', 'id', 'ID' ) );
			if ( ! $id ) { continue; }
			$keys = array(); $methods = array();
			foreach ( (array) ( isset( $row['settlementMethodGroups'] ) ? $row['settlementMethodGroups'] : array() ) as $g ) {
				if ( ! is_array( $g ) ) { continue; }
				foreach ( (array) ( isset( $g['settlementMethods'] ) ? $g['settlementMethods'] : array() ) as $m ) {
					if ( ! is_array( $m ) ) { continue; }
					$key = self::title( $m, array( 'settlementNatureKey', 'natureKey', 'key' ) );
					if ( '' !== $key && preg_match( '/^[A-Za-z0-9_]{1,80}$/', $key ) ) {
						$keys[ $key ] = $key;
						$methods[] = array( 'key' => $key, 'name' => rkw_text_slice( self::title( $m, array( 'settlementMethodName', 'settlementNatureName', 'name', 'title' ) ), 0, 160 ), 'method_id' => self::number( $m, array( 'settlementMethodID', 'settlementMethodId', 'id' ) ), 'group_id' => self::number( $g, array( 'settlementMethodGroupID', 'settlementMethodGroupId', 'id' ) ) );
					}
				}
			}
			$out[ $id ] = array( 'id' => $id, 'name' => self::title( $row, array( 'settlementPolicyName', 'name', 'title' ) ), 'keys' => array_values( $keys ), 'methods' => $methods );
		}
		return array_values( $out );
	}

	private static function locations( $data, $type ) {
		$out = array();
		foreach ( array_slice( self::rows( $data ), 0, 500 ) as $row ) {
			if ( ! is_array( $row ) ) { continue; }
			if ( 'areas' === $type ) {
				$id = self::number( $row, array( 'salesAreaID', 'salesAreaId', 'id' ) );
				$name = self::title( $row, array( 'salesAreaName', 'name', 'title' ) );
			} else {
				$id = self::number( $row, array( 'storeID', 'storeId', 'id', 'inventoryId', 'inventoryID' ) );
				$name = self::title( $row, array( 'storeName', 'name', 'title', 'inventoryName' ) );
			}
			if ( $id ) { $out[ $id ] = array( 'id' => $id, 'name' => $name ); }
		}
		return array_values( $out );
	}

	/** Read metadata for the settings UI; no fixed Rahkaran ID or policy list. */
	public static function refresh() {
		$c = new RKW_Client();
		if ( ! $c->is_v21() ) { return new WP_Error( 'rkw_catalog_version', 'فهرست شناسه‌ها برای API نسخه ۲۱ در دسترس است.' ); }
		$old = self::stored();
		$out = array(
			'signature' => self::signature(),
			'schema_version' => self::SCHEMA,
			'updated_at' => time(),
			'updated' => current_time( 'mysql' ),
			'invoice' => isset( $old['invoice'] ) ? $old['invoice'] : array(),
			'order' => isset( $old['order'] ) ? $old['order'] : array(),
			'areas' => isset( $old['areas'] ) ? $old['areas'] : array(),
			'stores' => isset( $old['stores'] ) ? $old['stores'] : array(),
			'patterns' => isset( $old['patterns'] ) ? $old['patterns'] : array(),
			'errors' => array(),
		);
		$tasks = array(
			'invoice' => $c->settlement_policies21( 1 ),
			'order'   => $c->settlement_policies21( 2 ),
			'areas'   => $c->sales_areas21(),
			'stores'  => $c->stores21(),
		);
		$successes = 0;
		foreach ( $tasks as $name => $response ) {
			if ( is_wp_error( $response ) ) { $out['errors'][ $name ] = $response->get_error_message(); continue; }
			$out[ $name ] = in_array( $name, array( 'invoice', 'order' ), true ) ? self::policies( $response ) : self::locations( $response, $name );
			$successes++;
		}
		foreach ( array( 1 => 'invoice', 2 => 'order' ) as $id => $type ) {
			$response = $c->default_pattern21( $id );
			if ( is_wp_error( $response ) ) { $out['errors'][ 'pattern_' . $type ] = $response->get_error_message(); continue; }
			$pattern = is_array( $response ) ? $response : array();
			$pattern_id = self::number( $pattern, array( 'id', 'documentPatternID', 'documentPatternId' ) );
			$out['patterns'][ $type ] = $pattern_id ? array( 'id' => $pattern_id, 'name' => self::title( $pattern, array( 'title', 'name', 'documentPatternName' ) ) ) : array();
		}
		if ( ! $successes ) { return new WP_Error( 'rkw_catalog_empty', 'هیچ شناسه‌ای دریافت نشد: ' . implode( ' | ', array_map( 'sanitize_text_field', $out['errors'] ) ) ); }
		if ( $out['signature'] !== self::signature() ) { return new WP_Error( 'rkw_catalog_changed', 'اتصال هنگام دریافت فهرست تغییر کرد؛ فهرست قبلی حفظ شد.' ); }
		update_option( self::OPTION, $out, false );
		return $out;
	}
}
