<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** WooCommerce gateway -> Rahkaran settlement mapping, adapted from wp-rahkaran. */
class RKW_Payment {
	/** Values are kept in rkw_settings so existing connection and orders are unaffected. */
	public static function sanitize_gateways( $input ) {
		if ( ! is_array( $input ) ) { return array(); }
		$gateways = array();
		foreach ( $input as $key ) {
			$key = (string) $key;
			if ( preg_match( '/^[a-zA-Z0-9_\-]{1,80}$/', $key ) ) { $gateways[ $key ] = $key; }
		}
		return array_values( $gateways );
	}

	public static function sanitize_rules( $input ) {
		if ( ! is_array( $input ) ) { return array(); }
		$rules = array();
		foreach ( array_slice( $input, 0, 40 ) as $item ) {
			if ( ! is_array( $item ) ) { continue; }
			$gateway = isset( $item['gateway'] ) ? (string) $item['gateway'] : '';
			if ( ! preg_match( '/^[a-zA-Z0-9_\-]{1,80}$/', $gateway ) ) { continue; }
			$rules[] = array(
				'gateway' => $gateway,
				'settlement_id' => max( 0, (int) ( isset( $item['settlement_id'] ) ? $item['settlement_id'] : 0 ) ),
				'receipt_key' => preg_replace( '/[^A-Za-z0-9_]/', '', (string) ( isset( $item['receipt_key'] ) ? $item['receipt_key'] : '' ) ),
				'coupon_type_id' => max( 0, (int) ( isset( $item['coupon_type_id'] ) ? $item['coupon_type_id'] : 0 ) ),
				'bank_account_ref' => max( 0, (int) ( isset( $item['bank_account_ref'] ) ? $item['bank_account_ref'] : 0 ) ),
				'e_receipt_type' => preg_replace( '/[^A-Za-z0-9_-]/', '', (string) ( isset( $item['e_receipt_type'] ) ? $item['e_receipt_type'] : '' ) ),
				'e_receipt_mode' => in_array( isset( $item['e_receipt_mode'] ) ? $item['e_receipt_mode'] : '', array( 'inherit', 'omit', 'explicit' ), true ) ? $item['e_receipt_mode'] : 'inherit',
				'electronic_route' => 'receipts', // Legacy saved route is ignored for v21 sales invoices.
			);
		}
		return $rules;
	}

	/** WC_Order object is used only for its public payment identifiers. */
	public static function resolve( $order, $settings ) {
		$gateway = trim( (string) $order->get_payment_method() );
		$matching_rules = self::matching_rules( $gateway, $settings );
		$matched_rules = count( $matching_rules );
		if ( $matched_rules > 1 ) { return new WP_Error( 'rkw_duplicate_gateway_rule', 'بیش از یک قانون برای شناسه درگاه این سفارش وجود دارد؛ قانون تکراری را حذف کنید.' ); }
		$method = 'cash';
		$no_gateway = isset( $settings['no_gateway_order'] ) ? $settings['no_gateway_order'] : 'cash';
		if ( '' === $gateway ) {
			if ( 'block' === $no_gateway ) { return new WP_Error( 'rkw_no_gateway', 'این سفارش روش پرداخت مشخص ندارد؛ ارسال طبق تنظیمات متوقف شد.' ); }
			if ( 'credit' === $no_gateway ) { $method = 'credit'; }
		} elseif ( in_array( $gateway, (array) ( isset( $settings['credit_gateways'] ) ? $settings['credit_gateways'] : array() ), true ) ) {
			$method = 'credit';
		}
		if ( 'credit' === $method ) {
			if ( $matched_rules && ( ! empty( $matching_rules[0]['receipt_key'] ) || ! empty( $matching_rules[0]['settlement_id'] ) ) ) {
				return new WP_Error( 'rkw_payment_mode_conflict', 'درگاه «' . $gateway . '» هم در «روش‌های پرداخت نسیه ووکامرس» انتخاب شده و هم قانون اختصاصی دریافت دارد. برای اجرای قانون درگاه، آن را از فهرست نسیه خارج و تنظیمات را ذخیره کنید؛ اگر واقعاً باید نسیه باشد، قانون دریافت آن را حذف و سیاست نسیه را تکمیل کنید. هیچ سندی ارسال نشد.' );
			}
			$policy = absint( isset( $settings['credit_policy_id'] ) ? $settings['credit_policy_id'] : 0 );
			if ( ! $policy ) { return new WP_Error( 'rkw_credit_policy', 'این روش پرداخت برای فاکتور نسیه تنظیم شده، ولی شناسه سیاست تسویه نسیه راهکاران وارد نشده است.' ); }
			if ( ( ! isset( $settings['document_contract'] ) || 'legacy_esales' === $settings['document_contract'] ) && empty( $settings['credit_receipt_key'] ) ) { return new WP_Error( 'rkw_legacy_credit_key', 'در حالت سازگار قدیمی، کلید تسویه نسیه را دقیقاً از سیاست پیش‌فرض افزونه قبلی وارد کنید.' ); }
			if ( (float) $order->get_meta( '_rkw_loyalty_credit_amount' ) > 0 ) {
				return new WP_Error( 'rkw_credit_loyalty', 'پرداخت نسیه همراه با اعتبار وفاداری در این نسخه پشتیبانی نشده است؛ برای جلوگیری از مغایرت سند ارسال نشد.' );
			}
			return array( 'mode' => 'credit', 'settlement_id' => $policy, 'receipt_key' => '', 'bank_account_ref' => 0, 'e_receipt_type' => '', 'e_receipt_mode' => 'omit', 'gateway' => $gateway, 'mapping_source' => 'credit_policy', 'matched_rules' => 0 );
		}

		$typed_key = isset( $settings['order_mode'] ) && 'invoice' === $settings['order_mode'] ? 'invoice_settlement_id' : 'order_settlement_id';
		$settlement = absint( ! empty( $settings[ $typed_key ] ) ? $settings[ $typed_key ] : $settings['settlement_id'] );
		$key = isset( $settings['receipt_key'] ) ? (string) $settings['receipt_key'] : 'Cash';
		$coupon_type = isset( $settings['coupon_type_id'] ) ? absint( $settings['coupon_type_id'] ) : 0;
		$bank = absint( isset( $settings['bank_account_ref'] ) ? $settings['bank_account_ref'] : 0 );
		$electronic_type = preg_replace( '/[^A-Za-z0-9_-]/', '', (string) ( isset( $settings['e_receipt_type'] ) ? $settings['e_receipt_type'] : '' ) );
		// The older wp-rahkaran SaveInvoice integration did not transmit eReceiptType.
		// The v21 PDF only illustrates it for saveKioskInvoice, which is a different endpoint.
		// Keep the field optional unless an administrator explicitly enables its transmission.
		$electronic_mode = isset( $settings['e_receipt_mode'] ) && 'explicit' === $settings['e_receipt_mode'] ? 'explicit' : 'omit';
		// Incoming settlement for a v21 sales invoice is always a receipt.
		$electronic_route = 'receipts';
		$mapping_source = 'default';
		foreach ( $matching_rules as $rule ) {
			$mapping_source = 'gateway_rule';
			if ( ! empty( $rule['settlement_id'] ) ) { $settlement = absint( $rule['settlement_id'] ); }
			if ( ! empty( $rule['receipt_key'] ) ) { $key = $rule['receipt_key']; }
			if ( ! empty( $rule['coupon_type_id'] ) ) { $coupon_type = absint( $rule['coupon_type_id'] ); }
			if ( ! empty( $rule['bank_account_ref'] ) ) { $bank = absint( $rule['bank_account_ref'] ); }
			if ( ! empty( $rule['e_receipt_type'] ) ) { $electronic_type = preg_replace( '/[^A-Za-z0-9_-]/', '', (string) $rule['e_receipt_type'] ); }
			if ( isset( $rule['e_receipt_mode'] ) && in_array( $rule['e_receipt_mode'], array( 'omit', 'explicit' ), true ) ) { $electronic_mode = $rule['e_receipt_mode']; }
			// Ignore old per-gateway payment-container overrides (v21 SaveInvoice).
			break;
		}
		// A provider-specific voucher must never be inherited by an unrelated gateway.
		// Do not infer provider identity from order attribution, titles or hard-coded IDs.
		$own_rule = $matched_rules ? $matching_rules[0] : array();
		if ( '' !== $gateway && 'ThirdPartyCoupon' === $key ) {
			if ( ! $matched_rules || empty( $own_rule['settlement_id'] ) || empty( $own_rule['receipt_key'] ) ) {
				return new WP_Error( 'rkw_gateway_coupon_rule', 'درگاه «' . $gateway . '» قانون کامل مخصوص خود ندارد و نمی‌تواند سیاست بن سازمانی را از پیش‌فرض بگیرد. برای همین شناسه درگاه، سیاست تسویه، نوع دریافت و نوع بن صحیح را جداگانه ذخیره کنید؛ سندی ارسال نشد.' );
			}
			// Missing coupon IDs get the existing actionable validation message below.
			$coupon_type = isset( $own_rule['coupon_type_id'] ) ? absint( $own_rule['coupon_type_id'] ) : 0;
		}
		if ( '' !== $gateway && empty( $own_rule['settlement_id'] ) ) {
			foreach ( isset( $settings['payment_rules'] ) ? (array) $settings['payment_rules'] : array() as $other_rule ) {
				if ( is_array( $other_rule ) && isset( $other_rule['gateway'], $other_rule['receipt_key'], $other_rule['settlement_id'] ) && $other_rule['gateway'] !== $gateway && 'ThirdPartyCoupon' === $other_rule['receipt_key'] && (int) $other_rule['settlement_id'] === $settlement ) {
					return new WP_Error( 'rkw_gateway_policy_inherited', 'درگاه «' . $gateway . '» سیاست تسویه پیش‌فرض #' . $settlement . ' را می‌گیرد که در قانون درگاه «' . $other_rule['gateway'] . '» برای بن سازمانی تنظیم شده است. سیاست صحیح پرداخت مستقیم را در قانون همین درگاه وارد کنید؛ سندی ارسال نشد.' );
				}
			}
		}
		if ( ! $settlement || ! preg_match( '/^[A-Za-z0-9_]+$/', $key ) ) {
			return new WP_Error( 'rkw_payment_config', 'سیاست تسویه یا کلید نوع پرداخت برای این درگاه ووکامرس معتبر نیست.' );
		}
		// Validate against the currently stored policies only when the server supplied a list
		// of allowed settlement method keys; never assume a hard-coded policy ID.
		if ( class_exists( 'RKW_Policy_Catalog' ) ) {
			$catalog = RKW_Policy_Catalog::stored();
			$type = isset( $settings['order_mode'] ) && 'invoice' === $settings['order_mode'] ? 'invoice' : 'order';
			foreach ( isset( $catalog[ $type ] ) && is_array( $catalog[ $type ] ) ? $catalog[ $type ] : array() as $policy ) {
				if ( ! is_array( $policy ) || ! isset( $policy['id'] ) || (int) $policy['id'] !== $settlement ) { continue; }
				if ( ! empty( $policy['keys'] ) && is_array( $policy['keys'] ) && ! in_array( $key, $policy['keys'], true ) ) {
					return new WP_Error( 'rkw_policy_receipt_mismatch', 'نوع دریافت «' . $key . '» در سیاست تسویه #' . $settlement . ' مجاز نیست. روش‌های مجاز: ' . implode( '، ', array_map( 'sanitize_text_field', $policy['keys'] ) ) . '. تنظیمات هر درگاه را اصلاح کنید.' );
				}
				break;
			}
		}
		if ( ! isset( $settings['document_contract'] ) || 'legacy_esales' === $settings['document_contract'] ) { $electronic_mode = 'omit'; }
		// Only require a type if the admin explicitly chose to send it.
		// In compatibility mode omit the optional attr instead of sending arbitrary IDs.
		if ( 'EReceipt' === $key && 'explicit' === $electronic_mode && '' === $electronic_type ) {
			return new WP_Error( 'rkw_e_receipt_type', 'ارسال eReceiptType برای این درگاه فعال شده، اما شناسه معتبر آن وارد نشده است. مقدار را از راهکاران تأیید کنید یا حالت سازگار (ارسال نشود) را انتخاب کنید.' );
		}
		if ( 'ThirdPartyCoupon' === $key && ! $coupon_type ) { return new WP_Error( 'rkw_coupon_type_missing', 'نوع دریافت این سفارش ThirdPartyCoupon است، اما شناسه نوع بن سازمانی couponType وارد نشده است. از «کاسبی راهکاران ← انواع بن سازمانی» فهرست واقعی را دریافت و شناسه مرتبط با cod یا اسنپ‌پی را در قانون همان درگاه ذخیره کنید؛ شناسه سیاست تسویه جایگزین نوع بن نیست.' ); }
		return array( 'coupon_type_id' => $coupon_type, 'mode' => 'cash', 'settlement_id' => $settlement, 'receipt_key' => $key, 'bank_account_ref' => in_array( $key, array( 'EReceipt', 'BankReceipt' ), true ) ? $bank : 0, 'e_receipt_type' => $electronic_type, 'e_receipt_mode' => $electronic_mode, 'gateway' => $gateway, 'mapping_source' => $mapping_source, 'matched_rules' => $matched_rules, 'electronic_route' => $electronic_route );
	}

	private static function matching_rules( $gateway, $settings ) {
		$out = array();
		if ( '' === $gateway ) { return $out; }
		foreach ( (array) ( isset( $settings['payment_rules'] ) ? $settings['payment_rules'] : array() ) as $rule ) {
			if ( is_array( $rule ) && isset( $rule['gateway'] ) && (string) $rule['gateway'] === $gateway ) { $out[] = $rule; }
		}
		return $out;
	}

	/** Do not send bankAccountRef for Cash or non-bank types. */
	public static function receipts( $order, $amount, $payment ) {
		if ( 'credit' === $payment['mode'] ) { return array(); }
		$attr = array( 'DESCRIPTION' => 'سفارش سایت #' . $order->get_order_number() );
		if ( in_array( $payment['receipt_key'], array( 'EReceipt', 'BankReceipt' ), true ) ) {
			$created = $order->get_date_paid();
			$attr['date'] = $created ? $created->date( 'Y-m-d' ) : current_time( 'Y-m-d' );
			$transaction_id = $order->get_transaction_id();
			$attr['transactionNumber'] = '' !== (string) $transaction_id ? (string) $transaction_id : (string) $order->get_id();
			if ( 'EReceipt' === $payment['receipt_key'] && isset( $payment['e_receipt_mode'] ) && 'explicit' === $payment['e_receipt_mode'] && '' !== (string) $payment['e_receipt_type'] ) {
				$attr['eReceiptType'] = (string) $payment['e_receipt_type'];
			}
			if ( $payment['bank_account_ref'] > 0 ) { $attr['bankAccountRef'] = (int) $payment['bank_account_ref']; }
		}
		if ( 'ThirdPartyCoupon' === $payment['receipt_key'] ) { $attr = array( 'ID' => (int) $payment['coupon_type_id'], 'CouponType' => (int) $payment['coupon_type_id'], 'Count' => 1 ); }
		return array( array( 'key' => $payment['receipt_key'], 'amount' => round( (float) $amount, 2 ), 'attr' => $attr ) );
	}

	/**
	 * v21 SaveInvoice and saveSalesOrder: money received from a customer goes to
	 * receipts. payments is used for outgoing money / return documents in v21.
	 * The old wp-rahkaran plugin used a different request contract; mirroring its
	 * payments property here provoked "repayment is not supported" on v21.
	 * Never silently promote electronic receipts to outgoing payments, even if
	 * legacy settings still say payments. This method never contacts Rahkaran.
	 */
	public static function settlement_entries( $order, $amount, $payment, $is_invoice = true ) {
		$containers = array( 'receipts' => array(), 'payments' => array() );
		$containers['receipts'] = self::receipts( $order, $amount, $payment );
		return $containers;
	}

	/**
	 * Read-only payment preview for an existing WooCommerce order.
	 * Does not contact Rahkaran, create a customer, or issue an invoice.
	 * Never exposes credentials or the customer's transaction number.
	 */
	public static function diagnose_order( $order, $settings ) {
		$gateway = trim( (string) $order->get_payment_method() );
		$rules = (array) ( isset( $settings['payment_rules'] ) ? $settings['payment_rules'] : array() );
		$configured = array();
		foreach ( $rules as $rule ) {
			if ( is_array( $rule ) && ! empty( $rule['gateway'] ) ) { $configured[] = (string) $rule['gateway']; }
		}
		$payment = self::resolve( $order, $settings );
		$shipping_route = (float) $order->get_shipping_total() + (float) $order->get_shipping_tax() > 0 ? RKW_Accounting::shipping_mapping( $order, RKW_Extensions::settings() ) : array( 'source' => 'no_shipping_charge' );
		$base = array(
			'plugin_version' => RKW_VER,
			'order_id' => (int) $order->get_id(),
			'woo_order_status' => $order->get_status(),
			'invoice_list_eligible' => RKW_Modules::invoice_order_eligible( $order ),
			'order_queue_engine' => RKW_Order_Runner::available() ? 'woocommerce' : 'wordpress',
			'order_queue_pending' => RKW_Order_Runner::pending( $order->get_id() ),
			'payment_gateway_id' => $gateway,
			'payment_gateway_title' => method_exists( $order, 'get_payment_method_title' ) ? sanitize_text_field( (string) $order->get_payment_method_title() ) : '',
			'shipping_mapping' => is_wp_error( $shipping_route ) ? array( 'error' => $shipping_route->get_error_message(), 'error_code' => $shipping_route->get_error_code() ) : $shipping_route,
			'configured_gateway_ids' => array_values( array_unique( $configured ) ),
			'gateway_rule_configured' => count( self::matching_rules( $gateway, $settings ) ) > 0,
			'gateway_rule_matched' => false,
			'matching_rules_count' => count( self::matching_rules( $gateway, $settings ) ),
			'credit_gateway_configured' => '' !== $gateway && in_array( $gateway, (array) ( isset( $settings['credit_gateways'] ) ? $settings['credit_gateways'] : array() ), true ),
			'mapping_source' => 'unresolved',
			'payment_mode' => 'unresolved',
			'settlement_policy_id' => null,
			'receipt_key' => null,
			'coupon_type_id' => null,
			'coupon_type_catalog_status' => 'not_checked',
			'bank_account_ref' => null,
			'e_receipt_type_value_sent' => null,
			'payment_container' => null,
			'receipt_attr_keys' => array(),
			'transaction_id_present' => '' !== trim( (string) $order->get_transaction_id() ),
			'woo_order_total_in_rahkaran_units' => method_exists( $order, 'get_total' ) ? round( (float) $order->get_total() * rkw_price_multiplier( $settings ), 2 ) : null,
			'amount_breakdown' => class_exists( 'RKW_Orders' ) ? RKW_Orders::order_amount_breakdown( $order, $settings ) : array(),
			'remote_request_sent' => false,
		);
		$legacy = RKW_Migration::legacy_order_records( $order->get_id() );
		$base['legacy_records'] = is_wp_error( $legacy ) ? array() : RKW_Migration::legacy_order_summary( $legacy );
		$base['legacy_sender_status'] = RKW_Migration::legacy_sender_status();
		if ( is_wp_error( $legacy ) ) { $base['legacy_record_check_error'] = $legacy->get_error_message(); }
		if ( is_wp_error( $payment ) ) {
			$base['configuration_error'] = $payment->get_error_message();
			return $base;
		}
		$amount = 1; // for looking up attr names only; not an invoice amount.
		$receipts = self::receipts( $order, $amount, $payment );
		$attr = isset( $receipts[0]['attr'] ) && is_array( $receipts[0]['attr'] ) ? $receipts[0]['attr'] : array();
		$base['mapping_source'] = isset( $payment['mapping_source'] ) ? $payment['mapping_source'] : 'default';
		$base['gateway_rule_matched'] = 'gateway_rule' === $base['mapping_source'];
		$base['payment_mode'] = $payment['mode'];
		$base['settlement_policy_id'] = (int) $payment['settlement_id'];
		$base['receipt_key'] = (string) $payment['receipt_key'];
		$base['coupon_type_id'] = 'ThirdPartyCoupon' === $payment['receipt_key'] ? (int) $payment['coupon_type_id'] : 0;
		$base['coupon_type_catalog_status'] = 'not_applicable';
		if ( 'ThirdPartyCoupon' === $payment['receipt_key'] ) {
			$stored_types = RKW_Coupon_Types::stored( $settings );
			$base['coupon_type_catalog_status'] = $stored_types ? 'not_found_in_last_fetch' : 'not_fetched';
			foreach ( $stored_types ? $stored_types['rows'] : array() as $type ) {
				if ( $type['id'] === $base['coupon_type_id'] ) { $base['coupon_type_catalog_status'] = 'found_in_last_fetch'; break; }
			}
		}
		$base['bank_account_ref'] = (int) $payment['bank_account_ref'];
		$base['e_receipt_mode'] = isset( $payment['e_receipt_mode'] ) ? $payment['e_receipt_mode'] : 'omit';
		$base['e_receipt_type_value_sent'] = array_key_exists( 'eReceiptType', $attr ) ? (string) $attr['eReceiptType'] : 'NOT_SENT';
		$base['receipt_attr_keys'] = array_keys( $attr );
		$base['estimated_receipt_amount'] = null !== $base['woo_order_total_in_rahkaran_units'] ? $base['woo_order_total_in_rahkaran_units'] : null;
		$containers = self::settlement_entries( $order, $amount, $payment, isset( $settings['order_mode'] ) && 'invoice' === $settings['order_mode'] );
		$base['document_contract'] = isset( $settings['document_contract'] ) ? $settings['document_contract'] : 'legacy_esales';
		$containers = RKW_Client::document_payload( array( 'document' => array( 'items' => array() ), 'receipts' => $containers['receipts'], 'payments' => $containers['payments'] ), $settings );
		$base['payment_container'] = ! empty( $containers['payments'] ) ? 'payments' : ( ! empty( $containers['receipts'] ) ? 'receipts' : 'none' );
		$base['transaction_id_present'] = '' !== trim( (string) $order->get_transaction_id() );
		$base['warnings'] = array();
		if ( 0 === (int) $base['matching_rules_count'] && '' !== $gateway ) {
			$base['warnings'][] = 'برای شناسه واقعی درگاه این سفارش قانون اختصاصی یافت نشد و مقادیر پیش‌فرض استفاده می‌شوند.';
		}
		if ( (int) $base['matching_rules_count'] > 1 ) {
			$base['warnings'][] = 'چند قانون برای این درگاه وجود دارد؛ فعلاً فقط اولین قانون اجرا می‌شود.';
		}
		if ( 'EReceipt' === $payment['receipt_key'] ) {
			$base['warnings'][] = 'این پیش‌نمایش مبلغ ارسالی را تخمین می‌زند؛ مبلغ نهایی پس از فیلترهای فروش در گزارش فنی SaveInvoice ثبت خواهد شد.';
			if ( 'NOT_SENT' === $base['e_receipt_type_value_sent'] ) {
				$base['warnings'][] = 'eReceiptType ارسال نمی‌شود؛ اگر راهکاران آن را الزامی بداند باید مقدار معتبر آن را از تنظیمات خود راهکاران دریافت کنید.';
			} else {
				$base['warnings'][] = 'مقدار eReceiptType واردشده فقط از تنظیمات خوانده شده است و اعتبار آن نزد سرور راهکاران تأیید نشده است.';
			}
			if ( ! $base['transaction_id_present'] ) {
				$base['warnings'][] = 'شناسه تراکنش در ووکامرس خالی است؛ آن را با درگاه بانک تطبیق دهید.';
			}
		}
		return $base;
	}

	private static function gateways() {
		$options = array( '' => '— انتخاب روش پرداخت —' );
		if ( ! function_exists( 'WC' ) || ! WC() || ! WC()->payment_gateways() ) { return $options; }
		foreach ( (array) WC()->payment_gateways()->payment_gateways() as $id => $gateway ) {
			$options[ $id ] = ( $gateway->get_title() ? $gateway->get_title() : $id ) . ' (' . $id . ')';
		}
		return $options;
	}

	private static function select( $name, $value, $options, $multiple = false ) {
		$h = '<select name="' . esc_attr( $name ) . '"' . ( $multiple ? ' multiple size="4"' : '' ) . '>';
		foreach ( $options as $key => $label ) {
			$selected = $multiple ? in_array( (string) $key, (array) $value, true ) : ( (string) $value === (string) $key );
			$h .= '<option value="' . esc_attr( $key ) . '"' . selected( $selected, true, false ) . '>' . esc_html( $label ) . '</option>';
		}
		return $h . '</select>';
	}
	/** Persian display labels; the submitted value remains the exact Rahkaran key. */
	public static function receipt_picker( $name, $value, $policy_id, $type, $rule = true ) {
		$attributes = $rule ? 'class="rkw-rule-picker rkw-receipt-select" data-rkw-rule-for="receipt_key"' : 'class="rkw-catalog-choice rkw-receipt-select" data-rkw-for="receipt_key" data-rkw-type="methods"';
		$html = '<select name="' . esc_attr( $name ) . '" ' . $attributes . ' aria-label="نوع دریافت">';
		$html .= '<option value="">' . ( $rule ? 'از تنظیم پیش‌فرض' : 'انتخاب نوع دریافت از راهکاران…' ) . '</option>';
		foreach ( RKW_Policy_Catalog::receipt_choices( $policy_id, $type, (string) $value ) as $key => $label ) { $html .= '<option value="' . esc_attr( $key ) . '"' . selected( (string) $key, (string) $value, false ) . '>' . esc_html( $label ) . '</option>'; }
		return $html . '</select>';
	}
	public static function render_credit_gateways( $selected, $options ) {
		// Keep selected gateways that are temporarily unavailable visible and removable.
		foreach ( (array) $selected as $id ) { if ( ! isset( $options[ $id ] ) ) { $options[ $id ] = $id . ' (درگاه فعلاً در ووکامرس در دسترس نیست)'; } }
		echo '<fieldset><legend class="screen-reader-text">روش‌های پرداخت نسیه ووکامرس</legend><input type="hidden" name="rkw[credit_gateways][]" value="">';
		foreach ( $options as $id => $title ) {
			echo '<label style="display:block;margin-bottom:6px"><input type="checkbox" name="rkw[credit_gateways][]" value="' . esc_attr( $id ) . '" ' . checked( in_array( (string) $id, (array) $selected, true ), true, false ) . '> ' . esc_html( $title ) . '</label>';
		}
		echo '</fieldset><p class="description">برای خارج‌کردن اسنپ‌پی از مسیر نسیه، تیک آن را بردارید و ذخیره تنظیمات را بزنید. درگاه دارای قانون ThirdPartyCoupon نباید هم‌زمان برای نسیه انتخاب شود. برداشتن همه تیک‌ها، فهرست نسیه را خالی ذخیره می‌کند.</p>';
	}

	public static function render_settings( $s ) {
		$gateway_options = self::gateways();
		foreach ( (array) $s['payment_rules'] as $rule ) {
			if ( is_array( $rule ) && ! empty( $rule['gateway'] ) && ! isset( $gateway_options[ $rule['gateway'] ] ) ) { $gateway_options[ $rule['gateway'] ] = $rule['gateway'] . ' (درگاه ذخیره‌شده؛ فعلاً در فهرست ووکامرس در دسترس نیست)'; }
		}
		echo '<tr><th scope="row">سفارش بدون روش پرداخت</th><td>' . self::select( 'rkw[no_gateway_order]', $s['no_gateway_order'], array( 'cash' => 'ارسال با دریافت پیش‌فرض (رفتار قبلی)', 'credit' => 'ثبت نسیه (نیازمند سیاست نسیه)', 'block' => 'ارسال نشود' ) ) . '<p class="description">انتخاب پیش‌فرض، عملکرد نسخه قبلی را حفظ می‌کند.</p></td></tr>';
		echo '<tr><th scope="row">روش‌های پرداخت نسیه ووکامرس</th><td>';
		self::render_credit_gateways( $s['credit_gateways'], array_diff_key( $gateway_options, array( '' => true ) ) );
		echo '</td></tr>';
		echo '<tr><th scope="row"><label>شناسه سیاست تسویه نسیه</label></th><td><div class="rkw-choice"><input class="small-text" type="number" min="0" name="rkw[credit_policy_id]" value="' . esc_attr( $s['credit_policy_id'] ) . '"><select class="rkw-catalog-choice" data-rkw-for="credit_policy_id" data-rkw-type="current"><option value="">انتخاب سیاست نسیه از راهکاران…</option></select></div><p class="description">سیاست مورد تأیید راهکاران برای فروش نسیه. در این حالت مبلغ دریافتی صفر ارسال می‌شود؛ قبل از استفاده در سفارش واقعی تست کنید.</p></td></tr>';
		echo '<tr><th scope="row">قوانین درگاه‌های پرداخت</th><td><p class="description">برای هر شناسه درگاه ووکامرس، سیاست تسویه، نوع دریافت و بانک مستقل تعریف کنید. فیلدهای خالی از تنظیم پیش‌فرض استفاده می‌کنند؛ برای بن سازمانی، سیاست، نوع دریافت و couponType باید در قانون همان درگاه کامل باشند. پرداخت مستقیم نباید سیاست بن درگاه دیگری را از پیش‌فرض بگیرد. این قوانین فقط برای روش‌های غیرنسیه اجرا می‌شوند.</p>';
		echo '<div class="rkw-rule-table-wrap"><table class="widefat striped" style="max-width:850px;direction:rtl"><thead><tr><th>درگاه ووکامرس</th><th>شناسه سیاست</th><th>نوع دریافت</th><th>شناسه بانک</th><th>نوع بن سازمانی couponType</th><th>نوع دریافت الکترونیک</th><th>ارسال eReceiptType</th><th>محل دریافت بانکی (نسخه ۲۱)</th><th>حذف</th></tr></thead><tbody>';
		$rules = (array) $s['payment_rules'];
		$document_type = 'invoice' === $s['order_mode'] ? 'invoice' : 'order';
		$default_policy = (int) ( $s[ $document_type . '_settlement_id' ] ?: $s['settlement_id'] );
		$coupon_choices = RKW_Coupon_Types::choices( $s );
		$count = max( 1, count( $rules ) );
		for ( $i = 0; $i < $count; $i++ ) {
			$rule = isset( $rules[ $i ] ) && is_array( $rules[ $i ] ) ? $rules[ $i ] : array();
			$base = 'rkw[payment_rules][' . $i . ']';
			echo '<tr class="rkw-gateway-rule"><td>' . self::select( $base . '[gateway]', isset( $rule['gateway'] ) ? $rule['gateway'] : '', $gateway_options ) . '</td>';
			foreach ( array( 'settlement_id' => 'number', 'receipt_key' => 'text', 'bank_account_ref' => 'number', 'coupon_type_id' => 'number', 'e_receipt_type' => 'text' ) as $key => $type ) {
				$val = isset( $rule[ $key ] ) ? $rule[ $key ] : '';
				if ( 'receipt_key' === $key && 'v21' === $s['api'] ) {
					$policy_id = ! empty( $rule['settlement_id'] ) ? (int) $rule['settlement_id'] : $default_policy;
					echo '<td>' . self::receipt_picker( $base . '[receipt_key]', $val, $policy_id, $document_type ) . '<small class="rkw-rule-key-warning" role="status"></small></td>';
					continue;
				}
				echo '<td><input class="rkw-rule-input" style="width:115px;max-width:100%;direction:ltr" type="' . $type . '"' . ( 'number' === $type ? ' min="0"' : '' ) . ' name="' . esc_attr( $base . '[' . $key . ']' ) . '" value="' . esc_attr( $val ) . '" placeholder="پیش‌فرض">';
				if ( 'settlement_id' === $key || 'receipt_key' === $key ) {
					echo '<select class="rkw-rule-picker" data-rkw-rule-for="' . esc_attr( $key ) . '"><option value="">انتخاب از راهکاران…</option></select>';
				}
				if ( 'coupon_type_id' === $key ) {
					echo '<select class="rkw-rule-picker" data-rkw-rule-for="coupon_type_id">';
					foreach ( $coupon_choices as $choice_id => $label ) { echo '<option value="' . esc_attr( $choice_id ) . '"' . selected( (string) $choice_id, (string) $val, false ) . '>' . esc_html( $label ) . '</option>'; }
					echo '</select><small>پیش از ثبت، وجود شناسه در راهکاران بررسی می‌شود.</small>';
				}
				echo '</td>';
			}
			$receipt_mode = isset( $rule['e_receipt_mode'] ) ? $rule['e_receipt_mode'] : 'inherit';
			echo '<td>' . self::select( $base . '[e_receipt_mode]', $receipt_mode, array( 'inherit' => 'از تنظیم اصلی', 'omit' => 'ارسال نشود (سازگار)', 'explicit' => 'ارسال مقدار واردشده' ) ) . '</td>';
			echo '<td><input type="hidden" name="' . esc_attr( $base . '[electronic_route]' ) . '" value="receipts"><span>' . ( 'legacy_esales' === $s['document_contract'] ? 'payments (ESales)' : 'receipts (SaveInvoice)' ) . '</span></td>';
			echo '<td><button type="button" class="button rkw-rule-remove" aria-label="حذف این قانون">حذف</button></td></tr>';
		}
		echo '</tbody></table></div><p><button type="button" class="button" id="rkw-add-rule">افزودن قانون درگاه</button></p><p class="description">شناسه بانک فقط برای EReceipt/BankReceipt ارسال می‌شود؛ در حالت سازگار، eReceiptType به فاکتور ارسال نمی‌شود (رفتار افزونه قدیمی). فقط اگر سرور شما این فیلد را الزام کرده باشد، حالت «ارسال مقدار واردشده» را انتخاب کنید. شناسه بانک و eReceiptType لزوماً یکسان نیستند. در قرارداد ESales دریافت در payments و در SaveInvoice جدید در receipts است. برای ThirdPartyCoupon شناسه نوع بن را برای هر درگاه وارد کنید؛ فهرست واقعی در صفحه «انواع بن سازمانی» در دسترس است.</p></td></tr>';
	}
}
