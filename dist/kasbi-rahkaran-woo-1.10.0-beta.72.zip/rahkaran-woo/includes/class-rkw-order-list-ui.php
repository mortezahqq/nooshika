<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** HPOS/legacy WooCommerce order list columns and safe single/batch send controls. */
class RKW_Order_List_UI {
    const CAP = 'manage_woocommerce';
    private static $legacy_documents = array();

    public static function init() {
        add_filter( 'manage_edit-shop_order_columns', array( __CLASS__, 'columns' ), 25 );
        add_action( 'manage_shop_order_posts_custom_column', array( __CLASS__, 'classic_column' ), 25, 2 );
        add_filter( 'manage_woocommerce_page_wc-orders_columns', array( __CLASS__, 'columns' ), 25 );
        add_action( 'manage_woocommerce_page_wc-orders_custom_column', array( __CLASS__, 'hpos_column' ), 25, 2 );
        add_action( 'wp_ajax_rkw_send_selected_orders', array( __CLASS__, 'ajax_send' ) );
        add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
    }

    public static function columns( $columns ) {
        if ( ! current_user_can( self::CAP ) ) { return $columns; }
        $columns['rkw_document_id'] = 'شناسه راهکاران';
        $columns['rkw_send'] = 'ارسال برای راهکاران';
        return $columns;
    }

    public static function classic_column( $column, $post_id ) {
        if ( ! in_array( $column, array( 'rkw_document_id', 'rkw_send' ), true ) ) { return; }
        self::cell( $column, wc_get_order( $post_id ) );
    }

    public static function hpos_column( $column, $order ) {
        if ( ! in_array( $column, array( 'rkw_document_id', 'rkw_send' ), true ) ) { return; }
        self::cell( $column, $order );
    }

    public static function clear_document_cache() { self::$legacy_documents = array(); }

    /** Resolve the document displayed by both classic and HPOS order tables. */
    public static function document( $order ) {
        if ( ! $order instanceof WC_Order ) { return array( 'state' => 'missing', 'id' => 0, 'type' => '' ); }
        $id = trim( (string) $order->get_meta( '_rkw_doc_id' ) );
        $type = (string) $order->get_meta( '_rkw_doc_type' );
        if ( RKW_Manual_Orders::is_marked( $order ) ) { return array( 'state' => 'manual_recorded', 'id' => preg_match( '/^[1-9][0-9]*$/D', $id ) ? (int) $id : 0, 'type' => $type ); }
        if ( $order->get_meta( '_rkw_reconcile_required' ) || ( '' !== $id && ! preg_match( '/^[1-9][0-9]*$/D', $id ) ) ) { return array( 'state' => 'pending', 'id' => 0, 'type' => $type ); }
        if ( '' !== $id ) { return array( 'state' => 'sent', 'id' => (int) $id, 'type' => $type ); }
        $order_id = (int) $order->get_id();
        if ( ! array_key_exists( $order_id, self::$legacy_documents ) ) {
            $rows = RKW_Migration::legacy_order_records( $order_id );
            $ids = array(); $ambiguous = false;
            if ( ! is_wp_error( $rows ) ) {
                foreach ( $rows as $row ) {
                    $value = isset( $row['invoice_id'] ) ? trim( (string) $row['invoice_id'] ) : '';
                    if ( preg_match( '/^[1-9][0-9]*$/D', $value ) ) { $ids[ $value ] = (int) $value; }
                    elseif ( '' !== $value ) { $ambiguous = true; }
                }
            }
            self::$legacy_documents[ $order_id ] = is_wp_error( $rows ) || $ambiguous || count( $ids ) > 1
                ? array( 'state' => 'pending', 'id' => 0, 'type' => '' )
                : ( $ids ? array( 'state' => 'sent', 'id' => (int) reset( $ids ), 'type' => '' ) : array( 'state' => $rows ? 'pending' : 'unsent', 'id' => 0, 'type' => '' ) );
        }
        $document = self::$legacy_documents[ $order_id ];
        if ( 'unsent' === $document['state'] && $order->get_meta( '_rkw_error' ) ) { $document['state'] = 'error'; }
        return $document;
    }

    public static function state( $order ) {
        return self::document( $order )['state'];
    }

    public static function document_label( $order ) {
        if ( ! $order instanceof WC_Order ) { return '—'; }
        $document = self::document( $order );
        if ( 'manual_recorded' === $document['state'] ) { return 'ثبت دستی در راهکاران' . ( $document['id'] ? ' — شناسه ذخیره‌شده #' . $document['id'] : '' ); }
        if ( 'pending' === $document['state'] ) { return 'نیازمند تطبیق'; }
        if ( 'sent' === $document['state'] ) {
            $split_ids = $order->get_meta( '_rkw_split_invoice_ids' );
            if ( is_array( $split_ids ) && count( $split_ids ) === 2 ) { return 'دو فاکتور #' . implode( ' و #', array_map( 'intval', $split_ids ) ); }

            return ( 'invoice' === $document['type'] ? 'فاکتور #' : ( 'salesorder' === $document['type'] ? 'سفارش #' : 'شناسه نرم‌افزار #' ) ) . $document['id'];
        }
        return '—';
    }

    public static function send_button( $order, $label = 'ارسال برای راهکاران' ) {
        if ( ! current_user_can( self::CAP ) || ! $order instanceof WC_Order ) { return ''; }
        $state = self::state( $order );
        if ( 'manual_recorded' === $state ) { return '<span class="rkw-order-status rkw-order-manual" title="علامت مدیر؛ از این مسیر تأیید سرویس یا شناسه جدیدی دریافت نشده است.">ثبت دستی در راهکاران</span>'; }
        if ( 'sent' === $state ) { return '<span class="rkw-order-status rkw-order-sent">' . esc_html( self::document_label( $order ) ) . '</span>'; }
        if ( 'pending' === $state ) { return '<span class="rkw-order-status rkw-order-pending" title="ابتدا با راهکاران تطبیق دهید؛ ارسال دوباره ممکن است سند تکراری بسازد.">نیازمند بررسی</span> <button type="button" class="button button-small rkw-check-one" data-order="' . esc_attr( $order->get_id() ) . '">بررسی وضعیت در راهکاران</button> <button type="button" class="button button-small rkw-existing-open" data-order="' . esc_attr( $order->get_id() ) . '">انتخاب فاکتور موجود</button>'; }
        if ( in_array( $order->get_status(), array( 'failed', 'cancelled' ), true ) ) { return '<span class="rkw-order-status" title="سفارش ناموفق یا لغوشده قابل ارسال نیست.">—</span>'; }
        return '<button type="button" class="button button-small rkw-send-one" data-order="' . esc_attr( $order->get_id() ) . '">' . esc_html( $label ) . '</button>';
    }

    private static function cell( $column, $order ) {
        if ( ! current_user_can( self::CAP ) || ! $order instanceof WC_Order ) { echo '—'; return; }
        if ( 'rkw_document_id' === $column ) {
            echo '<span class="rkw-order-doc" data-order="' . esc_attr( $order->get_id() ) . '">' . esc_html( self::document_label( $order ) ) . '</span>';
        } else {
            echo '<span class="rkw-order-actions" data-order="' . esc_attr( $order->get_id() ) . '">' . self::send_button( $order ) . '</span>';
        }
    }

    public static function assets( $hook ) {
        if ( ! current_user_can( self::CAP ) ) { return; }
        $screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
        $screen_id = $screen ? $screen->id : '';
        $is_orders = in_array( $screen_id, array( 'edit-shop_order', 'woocommerce_page_wc-orders' ), true );
        $is_invoice = isset( $_GET['page'] ) && 'rkw-invoices' === sanitize_key( wp_unslash( $_GET['page'] ) );
        if ( ! $is_orders && ! $is_invoice ) { return; }
        wp_enqueue_style( 'rkw-order-actions', plugins_url( 'assets/order-actions.css', RKW_FILE ), array(), RKW_VER );
        wp_enqueue_script( 'rkw-order-actions', plugins_url( 'assets/order-actions.js', RKW_FILE ), array(), RKW_VER, true );
        wp_localize_script( 'rkw-order-actions', 'rkwOrderActions', array(
            'ajax' => admin_url( 'admin-ajax.php' ),
            'nonce' => wp_create_nonce( 'rkw_order_send' ),
        ) );
    }

    /** Never bypass uncertain submission safeguards or resend confirmed invoices. */
    public static function ajax_send() {
        if ( ! current_user_can( self::CAP ) || ! check_ajax_referer( 'rkw_order_send', 'nonce', false ) ) {
            wp_send_json_error( array( 'message' => 'دسترسی یا نشست نامعتبر است.' ), 403 );
        }
        $raw = isset( $_POST['order_ids'] ) ? wp_unslash( $_POST['order_ids'] ) : array();
        if ( ! is_array( $raw ) || 1 !== count( $raw ) ) {
            wp_send_json_error( array( 'message' => 'برای جلوگیری از وقفه، هر درخواست سرور فقط یک سفارش پردازش می‌کند.' ), 400 );
        }
        $ids = array_values( array_unique( array_filter( array_map( 'absint', $raw ) ) ) );
        if ( ! $ids ) { wp_send_json_error( array( 'message' => 'شناسه سفارش معتبر نیست.' ), 400 ); }
        $items = array();
        $sent = 0;
        foreach ( $ids as $id ) {
            $order = wc_get_order( $id );
            if ( ! $order instanceof WC_Order || 'shop_order' !== $order->get_type() ) {
                $items[] = array( 'id' => $id, 'status' => 'error', 'message' => 'سفارش فروش معتبر یافت نشد.' );
                continue;
            }
            $state = self::state( $order );
            if ( 'manual_recorded' === $state ) {
                $items[] = array( 'id' => $id, 'status' => 'manual_recorded', 'manual_recorded' => true, 'message' => 'مدیر این سفارش را ثبت دستی در راهکاران علامت زده است؛ ارسال دوباره انجام نشد.', 'document' => self::document_label( $order ) );
                continue;
            }
            if ( 'sent' === $state ) {
                $items[] = array( 'id' => $id, 'status' => 'skipped', 'message' => 'سند از قبل ثبت شده؛ ارسال مجدد انجام نشد.', 'document' => self::document_label( $order ) );
                continue;
            }
            if ( 'pending' === $state ) {
                $items[] = array( 'id' => $id, 'status' => 'blocked', 'message' => 'نتیجه قبلی نامشخص است؛ ابتدا فاکتور را با راهکاران تطبیق دهید.' );
                continue;
            }
            if ( in_array( $order->get_status(), array( 'failed', 'cancelled' ), true ) ) {
                $items[] = array( 'id' => $id, 'status' => 'error', 'message' => 'سفارش ناموفق یا لغوشده قابل ارسال به راهکاران نیست؛ هیچ سندی ارسال نشد.' );
                continue;
            }
            // Manual send works for previously failed/unsent orders, even if automatic sending is disabled.
            $result = RKW_Orders::send( $order, true );
            if ( is_wp_error( $result ) ) {
                $order = wc_get_order( $id ); // Refresh state: the POST may have become indeterminate.
                $new_state = self::state( $order );
                $items[] = array( 'id' => $id, 'status' => 'pending' === $new_state ? 'blocked' : 'error', 'message' => $result->get_error_message() );
            } else {
                self::clear_document_cache();
                $fresh = wc_get_order( $id );
                if ( $fresh instanceof WC_Order ) { $order = $fresh; }
                $sent++;
                $items[] = array( 'id' => $id, 'status' => 'sent', 'message' => 'با موفقیت ثبت شد: ' . self::document_label( $order ), 'document' => self::document_label( $order ) );
            }
        }
        wp_send_json_success( array( 'sent' => $sent, 'total' => count( $ids ), 'items' => $items ) );
    }
}
