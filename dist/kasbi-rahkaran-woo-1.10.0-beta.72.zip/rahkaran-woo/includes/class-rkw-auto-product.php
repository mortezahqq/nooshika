<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Product publication and explicit edits -> only the linked Rahkaran product. */
class RKW_Auto_Product {
	private static $running = array();
	private static $completed = array();
	private static $pending = array();
	const NOTICE_KEY = 'rkw_auto_product_notice_';
	const STATUS_KEY = '_rkw_product_refresh';

	public static function init() {
		add_action( 'woocommerce_product_options_sku', array( __CLASS__, 'parent_field' ), 20 );
		add_action( 'woocommerce_admin_process_product_object', array( __CLASS__, 'save_parent_meta' ), 20 );
		add_action( 'woocommerce_process_product_meta', array( __CLASS__, 'after_parent_save' ), 99, 2 );
		add_action( 'woocommerce_variation_options_pricing', array( __CLASS__, 'variation_field' ), 20, 3 );
		add_action( 'woocommerce_save_product_variation', array( __CLASS__, 'after_variation_save' ), 99, 2 );
		// These paths do not fire woocommerce_process_product_meta. Wait until all
		// metadata/variations have been persisted, within the same HTTP request.
		add_action( 'woocommerce_new_product', array( __CLASS__, 'queue' ), 99 );
		add_action( 'woocommerce_new_product_variation', array( __CLASS__, 'queue' ), 99 );
		add_action( 'transition_post_status', array( __CLASS__, 'published' ), 99, 3 );
		add_action( 'woocommerce_rest_insert_product_object', array( __CLASS__, 'after_external_save' ), 99 );
		add_action( 'woocommerce_rest_insert_product_variation_object', array( __CLASS__, 'after_external_save' ), 99 );
		add_action( 'woocommerce_product_import_inserted_product_object', array( __CLASS__, 'after_external_save' ), 99 );
		// Run before WooCommerce's deferred parent price/stock synchronization.
		add_action( 'shutdown', array( __CLASS__, 'flush' ), 5 );
		add_action( 'admin_notices', array( __CLASS__, 'notice' ) );
	}

	public static function queue( $product_id ) {
		$id = absint( $product_id );
		if ( $id && ! empty( rkw_settings()['auto_product_on_save'] ) && ! isset( self::$running[ $id ] ) && ! isset( self::$completed[ $id ] ) ) { self::$pending[ $id ] = true; }
	}

	public static function published( $new_status, $old_status, $post ) {
		if ( 'publish' !== $new_status || 'publish' === $old_status || ! is_object( $post ) || ! in_array( $post->post_type, array( 'product', 'product_variation' ), true ) ) { return; }
		self::queue( $post->ID );
	}

	public static function after_external_save( $product ) {
		if ( is_object( $product ) && is_callable( array( $product, 'get_id' ) ) ) { self::queue( $product->get_id() ); }
	}

	public static function flush() {
		$pending = array_keys( self::$pending );
		self::$pending = array();
		foreach ( $pending as $id ) {
			$product = wc_get_product( $id );
			if ( ! $product || 'publish' !== $product->get_status() ) { continue; }
			// An enabled variation under an unpublished parent is not public yet.
			if ( $product->is_type( 'variation' ) ) {
				$parent = wc_get_product( $product->get_parent_id() );
				if ( ! $parent || 'publish' !== $parent->get_status() ) { continue; }
			}
			self::refresh_product( $product );
		}
	}

	private static function refresh_product( $product ) {
		if ( $product->is_type( 'simple' ) || $product->is_type( 'variation' ) ) { self::update( $product->get_id() ); return; }
		if ( ! $product->is_type( 'variable' ) || empty( rkw_settings()['auto_product_on_save'] ) ) { return; }
		$children = $product->get_children();
		if ( ! $children ) { self::failure( $product->get_id(), 'محصول متغیر هنوز متغیری ندارد؛ پس از ساخت متغیرها، شناسه مستقل راهکاران هر متغیر را وارد و تغییرات را ذخیره کنید.' ); return; }
		$ok = 0; $failed = 0;
		foreach ( $children as $id ) {
			$child = wc_get_product( $id );
			if ( ! $child || ! $child->is_type( 'variation' ) || 'publish' !== $child->get_status() ) { continue; }
			self::update( $id );
			$status = wc_get_product( $id )->get_meta( self::STATUS_KEY, true );
			if ( is_array( $status ) && ! empty( $status['success'] ) ) { $ok++; } else { $failed++; }
		}
		$message = sprintf( 'دریافت راهکاران برای محصول متغیر %d: %d متغیر به‌روزرسانی شد؛ %d متغیر ناموفق. علت هر مورد کنار شناسه همان متغیر و در گزارش‌ها ثبت شده است.', $product->get_id(), $ok, $failed );
		if ( 0 === $ok + $failed ) { $message = 'محصول هیچ متغیر فعالی ندارد؛ متغیرها را فعال و تغییرات را ذخیره کنید.'; }
		self::save_status( $product->get_id(), $ok > 0 && 0 === $failed, $message );
		if ( get_current_user_id() ) { set_transient( self::NOTICE_KEY . get_current_user_id(), array( 'success' => $ok > 0 && 0 === $failed, 'message' => $message ), 10 * MINUTE_IN_SECONDS ); }
	}

	private static function save_status( $id, $success, $message ) {
		$product = wc_get_product( $id );
		if ( ! $product ) { return; }
		$product->update_meta_data( self::STATUS_KEY, array( 'success' => (bool) $success, 'time' => time(), 'message' => sanitize_text_field( $message ), 'rahkaran_id' => absint( $product->get_meta( '_rahkaran_product_id', true ) ) ) );
		// Do not run a product save (stock hooks) just to record diagnostics.
		$product->save_meta_data();
	}

	public static function status_html( $product ) {
		$status = $product ? $product->get_meta( self::STATUS_KEY, true ) : null;
		if ( ! is_array( $status ) || empty( $status['message'] ) ) { return ''; }
		$when = ! empty( $status['time'] ) ? wp_date( 'Y/m/d H:i:s', (int) $status['time'] ) : '';
		return '<span class="description rkw-product-refresh-status" style="display:block;color:' . ( ! empty( $status['success'] ) ? '#166534' : '#b32d2e' ) . '">' . esc_html( $when . ' — ' . $status['message'] ) . '</span>';
	}

	public static function parent_field() {
		global $product_object, $post;
		$id = $product_object && is_a( $product_object, 'WC_Product' ) ? $product_object->get_id() : ( $post ? (int) $post->ID : 0 );
		$product = $id ? wc_get_product( $id ) : false;
		woocommerce_wp_text_input( array(
			'id' => '_rahkaran_product_id',
			'label' => 'شناسه محصول راهکاران',
			'value' => $product ? $product->get_meta( '_rahkaran_product_id', true ) : '',
			'type' => 'number',
			'custom_attributes' => array( 'min' => '1', 'step' => '1' ),
			'description' => 'پس از انتشار یا به‌روزرسانی، همین شناسه دریافت می‌شود. برای محصول متغیر، هر رنگ/سایز شناسه مستقل دارد و ذخیره محصول اصلی همه متغیرهای فعال را دریافت می‌کند. اگر کلید تطبیق تنظیمات «شناسه داخلی» است، SKU عددی همان متغیر نیز قابل استفاده است.',
			'desc_tip' => true,
		) );
		if ( $product ) { echo '<p class="form-field">' . self::status_html( $product ) . '</p>'; }
	}

	public static function save_parent_meta( $product ) {
		if ( ! $product || ! current_user_can( 'edit_post', $product->get_id() ) ) { return; }
		if ( ! isset( $_POST['_rahkaran_product_id'] ) ) { return; }
		$value = absint( wp_unslash( $_POST['_rahkaran_product_id'] ) );
		if ( $value ) { $product->update_meta_data( '_rahkaran_product_id', $value ); }
		else { $product->delete_meta_data( '_rahkaran_product_id' ); }
	}

	public static function after_parent_save( $post_id, $post = null ) {
		if ( ! current_user_can( 'edit_post', $post_id ) ) { return; }
		$product = wc_get_product( $post_id );
		if ( ! $product ) { return; }
		// Refresh each linked variation, never apply a parent's ID to its children.
		self::refresh_product( $product );
	}

	public static function variation_field( $loop, $variation_data, $variation ) {
		$id = isset( $variation->ID ) ? absint( $variation->ID ) : 0;
		$product = $id ? wc_get_product( $id ) : false;
		$value = $product ? $product->get_meta( '_rahkaran_product_id', true ) : '';
		echo '<p class="form-row form-row-full"><label for="rkw_variation_rahkaran_' . esc_attr( $loop ) . '">شناسه محصول راهکاران (این متغیر)</label>';
		echo '<input type="number" min="1" step="1" class="short" id="rkw_variation_rahkaran_' . esc_attr( $loop ) . '" name="rkw_variation_rahkaran_id[' . esc_attr( $loop ) . ']" value="' . esc_attr( $value ) . '" placeholder="شناسه مستقل در راهکاران">';
		echo '<span class="description">با «ذخیره تغییرات» این متغیر، اطلاعات همین شناسه به‌روزرسانی می‌شود.</span></p>';
		echo self::status_html( $product );
	}

	public static function after_variation_save( $variation_id, $loop ) {
		$variation_id = absint( $variation_id );
		if ( ! $variation_id || ! current_user_can( 'edit_post', $variation_id ) ) { return; }
		$product = wc_get_product( $variation_id );
		if ( ! $product || ! $product->is_type( 'variation' ) ) { return; }
		if ( isset( $_POST['rkw_variation_rahkaran_id'] ) && is_array( $_POST['rkw_variation_rahkaran_id'] ) && array_key_exists( $loop, $_POST['rkw_variation_rahkaran_id'] ) ) {
			$number = absint( wp_unslash( $_POST['rkw_variation_rahkaran_id'][ $loop ] ) );
			if ( $number ) { $product->update_meta_data( '_rahkaran_product_id', $number ); }
			else { $product->delete_meta_data( '_rahkaran_product_id' ); }
			$product->save_meta_data();
		}
		self::update( $variation_id );
	}

	private static function failure( $woocommerce_id, $message ) {
		$clean = sanitize_text_field( $message );
		self::save_status( $woocommerce_id, false, $clean );
		RKW_Log::add( 'error', 'بروزرسانی خودکار ووکامرس ' . $woocommerce_id . ': ' . $clean );
		if ( get_current_user_id() ) {
			set_transient( self::NOTICE_KEY . get_current_user_id(), 'بروزرسانی خودکار راهکاران برای محصول ' . $woocommerce_id . ' انجام نشد: ' . $clean, 10 * MINUTE_IN_SECONDS );
		}
	}

	public static function notice() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) { return; }
		$key = self::NOTICE_KEY . get_current_user_id();
		$notice = get_transient( $key );
		if ( ! $notice ) { return; }
		delete_transient( $key );
		$success = is_array( $notice ) && ! empty( $notice['success'] );
		$message = is_array( $notice ) && isset( $notice['message'] ) ? $notice['message'] : $notice;
		echo '<div class="notice ' . ( $success ? 'notice-success' : 'notice-warning' ) . ' is-dismissible"><p>' . esc_html( $message ) . '</p></div>';
	}

	public static function update( $woocommerce_id ) {
		$settings = rkw_settings();
		if ( empty( $settings['auto_product_on_save'] ) ) { return; }
		$woocommerce_id = absint( $woocommerce_id );
		if ( ! $woocommerce_id || isset( self::$running[ $woocommerce_id ] ) || isset( self::$completed[ $woocommerce_id ] ) ) { return; }
		$product = wc_get_product( $woocommerce_id );
		if ( ! $product ) { return; }
		if ( ! $product->is_type( 'simple' ) && ! $product->is_type( 'variation' ) ) { return; }
		$rahkaran_id = absint( $product->get_meta( '_rahkaran_product_id', true ) );
		// Legacy ID mode stores the Rahkaran ID in this variation's own SKU.
		// Validate the live response before update_target persists the linkage.
		if ( ! $rahkaran_id && 'id' === $settings['key_field'] ) {
			$sku = trim( (string) $product->get_sku( 'edit' ) );
			if ( preg_match( '/^[1-9][0-9]*$/D', $sku ) && (string) (int) $sku === $sku ) { $rahkaran_id = (int) $sku; }
		}
		if ( ! $rahkaran_id ) {
			self::$completed[ $woocommerce_id ] = true;
			self::failure( $woocommerce_id, 'شناسه محصول راهکاران خالی است؛ شناسه مستقل همین محصول یا همین متغیر را وارد و تغییرات را ذخیره کنید. در حالت تطبیق «شناسه داخلی راهکاران»، SKU عددیِ خود همان متغیر هم پذیرفته می‌شود. شناسه والد جایگزین نمی‌شود.' );
			return;
		}
		self::$running[ $woocommerce_id ] = true;
		self::$completed[ $woocommerce_id ] = true;
		$started = microtime( true );
		try {
			$client = new RKW_Client();
			// A saved administrative list is a display snapshot, never a live price source.
			$raw = $client->product_by_id( $rahkaran_id );
			if ( is_wp_error( $raw ) ) { self::failure( $woocommerce_id, $raw->get_error_message() ); return; }
			$item = RKW_Sync::normalize_single( $raw, $settings['api'] );
			if ( ! $item || (int) $item['id'] !== $rahkaran_id ) {
				self::failure( $woocommerce_id, 'شناسه محصول در پاسخ راهکاران یافت نشد یا با شناسه ثبت‌شده مطابقت ندارد.' );
				return;
			}
			// In v19 product details have no price. Query Price for this product alone.
			if ( 'v19' === $settings['api'] && ! empty( $settings['sync_price'] ) && ! empty( $item['unit'] ) ) {
				$prices = $client->prices19( array( $rahkaran_id => (int) $item['unit'] ) );
				if ( is_wp_error( $prices ) ) { self::failure( $woocommerce_id, $prices->get_error_message() ); return; }
				foreach ( (array) $prices as $price ) {
					if ( ! is_array( $price ) || ! isset( $price['itemId'] ) || 1 !== (int) $price['itemId'] ) { continue; }
					$key = $settings['price_field'];
					$item['price'] = isset( $price[ $key ] ) && is_numeric( $price[ $key ] ) ? (float) $price[ $key ] : null;
					if ( isset( $price['discount'], $price['netOfFee'] ) && (float) $price['discount'] > 0 ) { $item['sale'] = (float) $price['netOfFee']; }
					break;
				}
			}
			$item = RKW_Sync::calculate_sale( $item, $settings, $client );
			if ( $settings !== rkw_settings() ) { self::failure( $woocommerce_id, 'تنظیمات همگام‌سازی تغییر کرد؛ دوباره به‌روزرسانی کنید.' ); return; }
			$result = RKW_Sync::update_target( $woocommerce_id, $item, $client );
			if ( is_wp_error( $result ) ) { self::failure( $woocommerce_id, $result->get_error_message() ); return; }
			self::$completed[ $woocommerce_id ] = true;
			$elapsed = round( microtime( true ) - $started, 2 );
			$message = sprintf( 'دریافت تازه از راهکاران و به‌روزرسانی محصول ووکامرس %d انجام شد؛ مدت پردازش %s ثانیه. این اجرا منتظر زمان‌بندی دوره‌ای نماند.', $woocommerce_id, $elapsed );
			if ( ! empty( $item['sale_notice'] ) ) { $message .= ' ' . $item['sale_notice']; }
			elseif ( 'v21' === $settings['api'] && ! empty( $settings['sync_sale'] ) && null === $item['sale'] ) { $message .= ' راهکاران مبلغ تخفیفی صریح برای همین متغیر ارائه نکرد؛ قیمت فروش ویژهٔ قبلی حفظ شد و تخفیف رنگ دیگری کپی نشد.'; }
			self::save_status( $woocommerce_id, true, $message );
			RKW_Log::add( 'info', $message );
			if ( get_current_user_id() ) { set_transient( self::NOTICE_KEY . get_current_user_id(), array( 'success' => true, 'message' => $message ), 10 * MINUTE_IN_SECONDS ); }
		} catch ( Exception $e ) {
			self::failure( $woocommerce_id, $e->getMessage() );
		} finally {
			unset( self::$running[ $woocommerce_id ] );
		}
	}
}
