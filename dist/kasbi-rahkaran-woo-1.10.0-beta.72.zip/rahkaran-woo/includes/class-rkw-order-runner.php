<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** WooCommerce background dispatch for order writes; catalog scheduling remains independent. */
class RKW_Order_Runner {
 const GROUP = 'rkw-orders';
 private static $wake = false;
 public static function init() {
  add_action( 'init', array( __CLASS__, 'migrate_pending' ), 40 );
  add_action( 'shutdown', array( __CLASS__, 'wake' ), 99 );
 }
 public static function available() { return function_exists( 'as_enqueue_async_action' ) && function_exists( 'as_get_scheduled_actions' ); }
 public static function pending( $id ) {
  if ( self::available() ) { return (bool) as_get_scheduled_actions( array( 'hook'=>'rkw_send_order','args'=>array((int)$id),'group'=>self::GROUP,'status'=>'pending','per_page'=>1 ),'ids' ); }
  return function_exists('wp_next_scheduled') && (bool) wp_next_scheduled( 'rkw_send_order', array((int)$id) );
 }
 public static function allowed( WC_Order $o ) {
  $s=rkw_settings();$statuses=array_filter(array_map('trim',explode(',',(string)$s['order_statuses'])));
  return !RKW_Manual_Orders::is_marked($o) && !empty($s['order_enabled']) && 'v21'===$s['api'] && !in_array($o->get_status(),array('failed','cancelled','refunded'),true) && (in_array($o->get_status(),$statuses,true)||RKW_Modules::invoice_order_eligible($o));
 }
 public static function enqueue( $id, $delay = 0 ) {
  $id=(int)$id;$args=array($id);
  $o=wc_get_order($id);if($o instanceof WC_Order&&RKW_Manual_Orders::is_marked($o)){return true;}
  try {
   if(self::pending($id)){return true;}
   if(self::available() && ($delay<=0 || function_exists('as_schedule_single_action'))){
    $job=$delay>0&&function_exists('as_schedule_single_action')?as_schedule_single_action(time()+$delay,'rkw_send_order',$args,self::GROUP,false):as_enqueue_async_action('rkw_send_order',$args,self::GROUP,false);
    if(!$job&&!self::pending($id)){throw new RuntimeException('queue unavailable');}
    self::$wake=true;$engine='صف پس‌زمینه ووکامرس';
   } else {
    $job=wp_schedule_single_event(time()+max(1,$delay),'rkw_send_order',$args);
    if(is_wp_error($job)||!$job){throw new RuntimeException('schedule unavailable');}
    if(function_exists('spawn_cron')){spawn_cron();}$engine='زمان‌بندی وردپرس';
   }
   RKW_Log::add('info','سفارش #'.$id.' برای ارسال خودکار در '.$engine.' قرار گرفت.');return true;
  } catch(Throwable$error){RKW_Log::add('error','ساخت صف ارسال خودکار سفارش #'.$id.' ناموفق بود؛ هیچ سندی از این مسیر صادر نشد.');return false;}
 }
 public static function wake() {
  if(!self::$wake){return;}self::$wake=false;
  try{if(class_exists('ActionScheduler')&&is_callable(array('ActionScheduler','runner'))){$runner=ActionScheduler::runner();if(is_callable(array($runner,'maybe_dispatch_async_request'))){$runner->maybe_dispatch_async_request();}}}
  catch(Throwable$error){RKW_Log::add('warn','درخواست بیدارکردن صف سفارش انجام نشد؛ صف و درخواست‌های داخلی هاست بررسی شوند.');}
 }
 public static function migrate_pending() {
  $s=rkw_settings();if(empty($s['order_enabled'])||!self::available()||!function_exists('_get_cron_array')){return;}
  $cron=_get_cron_array();if(!is_array($cron)){return;}$count=0;
  foreach($cron as$time=>$hooks){
   foreach(isset($hooks['rkw_send_order'])?$hooks['rkw_send_order']:array()as$event){
    if(++$count>25){return;}$args=isset($event['args'])?$event['args']:array();$id=isset($args[0])?(int)$args[0]:0;$o=$id?wc_get_order($id):false;
    if(!$o instanceof WC_Order||!self::allowed($o)||$o->get_meta('_rkw_doc_id')||$o->get_meta('_rkw_reconcile_required')){if(function_exists('wp_unschedule_event')){wp_unschedule_event((int)$time,'rkw_send_order',$args);}continue;}
    if(self::enqueue($id,max(0,(int)$time-time()))&&function_exists('wp_unschedule_event')){wp_unschedule_event((int)$time,'rkw_send_order',$args);}
   }
  }
 }
}
