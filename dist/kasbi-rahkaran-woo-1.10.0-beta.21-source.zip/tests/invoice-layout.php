<?php
require __DIR__ . '/bootstrap.php';

class TestOrderUtil {public static $hpos=false;public static function custom_orders_table_usage_is_enabled(){return self::$hpos;}}
class_alias(TestOrderUtil::class,'Automattic\\WooCommerce\\Utilities\\OrderUtil');
class FilterDB extends TestDB {
 public $prefix='wp_',$total=null,$ids=null,$queries=[],$fail=false;
 function prepare($sql,...$args){
  $this->last_sql=$sql;$this->last_args=$args;if(count($args)===1&&is_array($args[0]))$args=$args[0];$i=0;
  return preg_replace_callback('/%[sd]/',function($m)use(&$i,$args){$v=$args[$i++];return $m[0]==='%d'?(string)(int)$v:"'".str_replace("'","''",(string)$v)."'";},$sql);
 }
 function eligible($sql){
  $ids=[];preg_match_all("/o\\.(post_date|date_created_gmt) (>=|<=) '([^']+)'/",$sql,$bounds,PREG_SET_ORDER);
  foreach($GLOBALS['local_orders']as$o){
   if(!RKW_Modules::invoice_order_eligible($o)||0.0===(float)$o->get_total())continue;
   if(strpos($sql,"m.meta_key='_rkw_doc_id'")!==false&&RKW_Order_List_UI::state($o)==='sent')continue;
   $eligible=true;foreach($bounds as$b){$date=$o->get_date_created();if(!$date){$eligible=false;break;}$date=$date->setTimezone($b[1]==='date_created_gmt'?new DateTimeZone('UTC'):wp_timezone())->format('Y-m-d H:i:s');if(($b[2]==='>='&&$date<$b[3])||($b[2]==='<='&&$date>$b[3]))$eligible=false;}
   if($eligible)$ids[]=$o->id;
  }
  rsort($ids);return $ids;
 }
 function get_var($sql){$this->queries[]=$sql;if($this->fail){$this->last_error='synthetic';return null;}return $this->total??count($this->eligible($sql));}
 function get_col($sql){$this->queries[]=$sql;if($this->ids!==null)return $this->ids;preg_match('/LIMIT (\d+) OFFSET (\d+)/',$sql,$limit);return array_slice($this->eligible($sql),(int)$limit[2],(int)$limit[1]);}
}
function wc_get_order_statuses(){return $GLOBALS['registered_statuses']??['wc-processing'=>'در حال انجام','wc-completed'=>'تکمیل شده'];}
class FilterOrder extends WC_Order {public $status='processing',$created=null,$paid=null;function get_date_paid(){return $this->paid;}function get_status(){return $this->status;}function get_date_created(){return $this->created;}}
function wp_timezone(){return new DateTimeZone('Asia/Tehran');}
function wc_date_format(){return 'Y-m-d';}function wc_time_format(){return 'H:i';}function wc_format_datetime($date,$format){return $date->format($format);}
function esc_url($v){return esc_attr($v);}
function selected($a,$b=true,$echo=true){$v=(string)$a===(string)$b?' selected="selected"':'';if($echo)echo $v;return $v;}
function wc_get_order_status_name($v){return $v==='processing'?'در حال انجام':($v==='completed'?'تکمیل‌شده':$v);}
function remove_filter($name,$callback,$priority=10){foreach($GLOBALS['filters'][$name][$priority]??[]as$i=>$value)if($value===$callback)unset($GLOBALS['filters'][$name][$priority][$i]);}
class NativeTableQuery {function get_table_name($table){return 'wp_wc_orders';}}
function wc_get_orders($args){
 $GLOBALS['order_queries'][]=$args;
 if(isset($GLOBALS['order_query_override']))return ($GLOBALS['order_query_override'])($args);
 $nonzero=false;
 if(!empty($args['rkw_local_nonzero'])){
  if(TestOrderUtil::$hpos){$sql=apply_filters('woocommerce_orders_table_query_clauses',['where'=>'1=1'],new NativeTableQuery,$args);$nonzero=strpos($sql['where'],'wp_wc_orders.total_amount <> 0')!==false;}
  else{$query=apply_filters('woocommerce_order_data_store_cpt_get_orders_query',['meta_query'=>[]],$args);$nonzero=in_array(['key'=>'_order_total','value'=>0,'compare'=>'!=','type'=>'DECIMAL(26,8)'],$query['meta_query'],true);}
 }
 $orders=array_values(array_filter($GLOBALS['local_orders'],function($o)use($args,$nonzero){
  if($nonzero&&0.0===(float)$o->get_total())return false;
  if(!empty($args['rkw_local_paid_custom'])&&!RKW_Modules::invoice_order_eligible($o))return false;
  if(!in_array('wc-'.$o->get_status(),$args['status'],true)||(isset($args['include'])&&!in_array($o->id,$args['include'],true)))return false;
  if(isset($args['date_created'])){$t=$o->get_date_created()?$o->get_date_created()->getTimestamp():0;$range=$args['date_created'];if(strpos($range,'...')!==false){[$start,$end]=explode('...',$range);return $t>=(int)$start&&$t<=(int)$end;}return substr($range,0,2)==='>='?$t>=(int)substr($range,2):$t<=(int)substr($range,2);}
  return true;
 }));
 usort($orders,function($a,$b){return $b->id<=>$a->id;});
 $total=count($orders);$orders=array_slice($orders,(($args['page']??1)-1)*$args['limit'],$args['limit']);
 return !empty($args['paginate'])?(object)['orders'=>$orders,'max_num_pages'=>max(1,(int)ceil($total/$args['limit'])),'total'=>$total]:$orders;
}
function layout_reset(){
 reset_case();RKW_Order_List_UI::clear_document_cache();RKW_Returns::clear_cache();TestOrderUtil::$hpos=false;
 $GLOBALS['registered_statuses']=['wc-processing'=>'در حال انجام','wc-completed'=>'تکمیل شده'];$GLOBALS['wpdb']=new FilterDB;$GLOBALS['local_orders']=[];$GLOBALS['order_queries']=[];unset($GLOBALS['order_query_override']);$_GET=['page'=>'rkw-invoices'];
}
function local_order($id,$status='processing',$doc=''){$o=new FilterOrder;$o->id=$id;$o->total=100;$o->status=$status;if($doc!==''){$o->meta['_rkw_doc_id']=$doc;$o->meta['_rkw_doc_type']='invoice';}return $o;}
function layout_html(){ob_start();RKW_Modules::page();return ob_get_clean();}

$tests=[];
$tests['only processing and completed are requested and rendered']=function(){
 $GLOBALS['local_orders']=[local_order(1),local_order(2,'completed'),local_order(3,'cancelled'),local_order(4,'failed'),local_order(5,'pending'),local_order(6,'refunded')];
 $h=layout_html();check($GLOBALS['order_queries'][0]['status']===['wc-processing','wc-completed']);check(strpos($h,'data-order-id="1"')!==false);check(strpos($h,'data-order-id="2"')!==false);foreach([3,4,5,6]as$id)check(strpos($h,'data-order-id="'.$id.'"')===false);check(!$GLOBALS['http_calls']);
};
$tests['local orders and local filter precede a closed remote accordion']=function(){
 $GLOBALS['local_orders']=[local_order(1)];$h=layout_html();$local=strpos($h,'rkwm-local-orders');$remote=strpos($h,'<details id="rkwm-remote-invoices"');check($local<$remote);check(strpos($h,'id="rkw-local-order-filter"')<$remote);check(strpos($h,'<details id="rkwm-remote-invoices" class="rkwm-remote-invoices">')!==false);check(strpos($h,'id="rkwm-filter"')>$remote);check(!$GLOBALS['http_calls']);
};
$tests['unsent filter uses pre-pagination queries and hydrates only requested ids']=function(){
 for($i=101;$i<=127;$i++)$GLOBALS['local_orders'][]=local_order($i);
 $GLOBALS['wpdb']->total=27;$GLOBALS['wpdb']->ids=[101,102];$p=RKW_Modules::local_order_page(2,'unsent');check($p->max_num_pages===2);check(count($p->orders)===2);$q=$GLOBALS['order_queries'][0];check($q['include']===[101,102]);check($q['status']===['wc-processing','wc-completed']);check($q['page']===1);check($q['paginate']===false);check(strpos($GLOBALS['wpdb']->queries[1],'LIMIT 25 OFFSET 25')!==false);check(strpos($GLOBALS['wpdb']->queries[0],"o.post_status IN ('wc-processing','wc-completed')")!==false);
};
$tests['HPOS filter reads HPOS orders/meta while recognizing old CPT queues']=function(){
 TestOrderUtil::$hpos=true;$GLOBALS['wpdb']->total=1;$GLOBALS['wpdb']->ids=[1];$GLOBALS['local_orders']=[local_order(1)];RKW_Modules::local_order_page(1,'unsent');$sql=implode(' ', $GLOBALS['wpdb']->queries);check(strpos($sql,'FROM wp_wc_orders o')!==false);check(strpos($sql,'FROM wp_wc_orders_meta m WHERE m.order_id=o.id')!==false);check(strpos($sql,"lp.post_type='rahkaran-invoice'")!==false);check(strpos($sql,'o.date_created_gmt DESC')!==false);
};
$tests['empty unsent results never fall back to querying every order']=function(){
 $GLOBALS['local_orders']=[local_order(1,'processing','501')];$p=RKW_Modules::local_order_page(1,'unsent');check($p->orders===[]);check(!$GLOBALS['order_queries']);$GLOBALS['wpdb']->total=1;$GLOBALS['wpdb']->ids=[];$p=RKW_Modules::local_order_page(1,'unsent');check($p->orders===[]);check(!$GLOBALS['order_queries']);
};
$tests['filter query read errors are shown instead of silently widening the filter']=function(){
 $GLOBALS['wpdb']->fail=true;$_GET['rkw_order_filter']='unsent';$h=layout_html();check(strpos($h,'دریافت سفارش‌ها از پایگاه داده ناموفق بود')!==false);check(!$GLOBALS['order_queries']);
};
$tests['selected unsent filter persists in links and resets on form submission']=function(){
 $_GET['rkw_order_filter']='unsent';$_GET['rkw_orders_page']=2;$GLOBALS['wpdb']->total=60;$GLOBALS['wpdb']->ids=[1];$GLOBALS['local_orders']=[local_order(1)];$h=layout_html();check(strpos($h,'value="unsent"  selected="selected"')!==false);check(strpos($h,'rkw_order_filter=unsent')!==false);check(strpos($h,'name="rkw_orders_page"')===false);check(strpos($h,'data-rkw-order-filter="unsent"')!==false);
};
$tests['unknown filter values cannot expand statuses or change query conditions']=function(){
 $_GET['rkw_order_filter']=['unsent'];$GLOBALS['local_orders']=[local_order(1)];$h=layout_html();check(strpos($h,'data-rkw-order-filter="all"')!==false);check($GLOBALS['order_queries'][0]['status']===['wc-processing','wc-completed']);
};
$tests['confirmed orders leave the attention filter while pending orders remain checkable']=function(){
 $_GET['rkw_order_filter']='unsent';$GLOBALS['wpdb']->total=2;$GLOBALS['wpdb']->ids=[1,2];$one=local_order(1,'processing','501');$two=local_order(2);$two->meta['_rkw_reconcile_required']=1;$GLOBALS['local_orders']=[$one,$two];$h=layout_html();check(strpos($h,'data-order-id="1"')===false);check(strpos($h,'data-order-id="2"')!==false);check(strpos($h,'rkw-check-one')!==false);check(strpos($h,'rkw-send-one')===false);
};
$tests['out of range local pages are clamped to the actual last page']=function(){
 for($i=1;$i<=30;$i++)$GLOBALS['local_orders'][]=local_order($i);$p=RKW_Modules::local_order_page(99,'all');check($p->page===2);check(count($p->orders)===5);$GLOBALS['wpdb']->total=30;$GLOBALS['wpdb']->ids=[1,2,3,4,5];$p=RKW_Modules::local_order_page(99,'unsent');check($p->page===2);check(strpos($GLOBALS['wpdb']->queries[1],'OFFSET 25')!==false);
};
$tests['date range includes both full store-local days in all orders query']=function(){
 $dates=['2026-10-19 23:59:59','2026-10-20 00:00:00','2026-10-21 23:59:59','2026-10-22 00:00:00'];
 foreach($dates as$i=>$date){$o=local_order($i+1);$o->created=new DateTimeImmutable($date,wp_timezone());$GLOBALS['local_orders'][]=$o;}
 $p=RKW_Modules::local_order_page(1,'all','2026-10-20','2026-10-21');check(array_map(fn($o)=>$o->id,$p->orders)===[3,2]);
 check($GLOBALS['order_queries'][0]['date_created']===(new DateTimeImmutable($dates[1],wp_timezone()))->getTimestamp().'...'.(new DateTimeImmutable($dates[2],wp_timezone()))->getTimestamp());
 $p=RKW_Modules::local_order_page(1,'all','2026-10-22','');check(count($p->orders)===1);$p=RKW_Modules::local_order_page(1,'all','','2026-10-19');check(count($p->orders)===1);
};
$tests['combined unsent date range uses local CPT dates and UTC HPOS dates before count']=function(){
 foreach([false,true]as$hpos){layout_reset();TestOrderUtil::$hpos=$hpos;$GLOBALS['wpdb']->total=1;$GLOBALS['wpdb']->ids=[1];$o=local_order(1);$o->created=new DateTimeImmutable('2026-10-21 12:00:00',wp_timezone());$GLOBALS['local_orders']=[$o];
  $p=RKW_Modules::local_order_page(1,'unsent','2026-10-21','2026-10-21');check(count($p->orders)===1);$sql=$GLOBALS['wpdb']->queries[0];
  check(strpos($sql,$hpos?"o.date_created_gmt >= '2026-10-20 20:30:00'":"o.post_date >= '2026-10-21 00:00:00'")!==false);
  check(strpos($sql,$hpos?"o.date_created_gmt <= '2026-10-21 20:29:59'":"o.post_date <= '2026-10-21 23:59:59'")!==false);
 }
};
$tests['invalid or reversed dates fail without querying orders or silently dropping the filter']=function(){
 foreach([['2026-02-30',''],['2026-2-01',''],[['2026-10-21'],''],['','garbage'],['2026-10-22','2026-10-21']]as$range){expect_error(RKW_Modules::local_order_page(1,'unsent',...$range),'rkw_local_order_date');}
 check(!$GLOBALS['wpdb']->queries);check(!$GLOBALS['order_queries']);$_GET['rkw_order_from']=['invalid'];$h=layout_html();check(strpos($h,'تاریخ معتبر را از تقویم انتخاب کنید.')!==false);
};
$tests['calendar date inputs and both dates persist with send status across pagination']=function(){
 $_GET+=['rkw_order_from'=>'2026-10-20','rkw_order_to'=>'2026-10-21','rkw_order_filter'=>'unsent'];$GLOBALS['wpdb']->total=26;$GLOBALS['wpdb']->ids=[1];$o=local_order(1);$o->created=new DateTimeImmutable('2026-10-21 12:00:00',wp_timezone());$GLOBALS['local_orders']=[$o];$h=layout_html();
 check(strpos($h,'type="hidden" id="rkw-local-order-from" name="rkw_order_from" value="2026-10-20"')!==false);check(strpos($h,'type="hidden" id="rkw-local-order-to" name="rkw_order_to" value="2026-10-21"')!==false);check(substr_count($h,'class="button rkw-jalali-trigger"')===2);check(strpos($h,'type="date"')===false);check(strpos($h,'rkw_order_filter=unsent')!==false);check(strpos($h,'rkw_order_from=2026-10-20')!==false);check(strpos($h,'rkw_order_to=2026-10-21')!==false);check(strpos($h,'name="rkw_orders_page"')===false);
};
$tests['zero totals are excluded before pagination in all and unsent while sent nonzero orders stay in all']=function(){
 foreach(['all','unsent']as$filter){layout_reset();for($i=1;$i<=60;$i++){$o=local_order($i);$o->total=$i>30?0:100;$GLOBALS['local_orders'][]=$o;}$GLOBALS['local_orders'][0]->meta['_rkw_doc_id']='501';
  $p=RKW_Modules::local_order_page(1,$filter);check(count($p->orders)===25);check($p->max_num_pages===2);check($p->orders[0]->id===30);$p=RKW_Modules::local_order_page(2,$filter);check(count($p->orders)===($filter==='all'?5:4));
 }
};
$tests['zero total race after selection is not rendered and all-zero list stays empty']=function(){
 $zero=local_order(1);$zero->total=0;$GLOBALS['local_orders']=[$zero];$h=layout_html();check(strpos($h,'data-order-id="1"')===false);check(strpos($h,'سفارشی با این فیلتر یافت نشد.')!==false);check(!$GLOBALS['wpdb']->queries);
 $_GET['rkw_order_filter']='unsent';$GLOBALS['wpdb']->total=1;$GLOBALS['wpdb']->ids=[1];$h=layout_html();check(strpos($h,'data-order-id="1"')===false);
};
$tests['all orders use WooCommerce directly even when independent raw-table candidates contain only two records']=function(){
 foreach([false,true]as$hpos){layout_reset();TestOrderUtil::$hpos=$hpos;for($id=1;$id<=60;$id++)$GLOBALS['local_orders'][]=local_order($id);
  $GLOBALS['wpdb']->total=2;$GLOBALS['wpdb']->ids=[1,2];$p=RKW_Modules::local_order_page(1,'all');check(count($p->orders)===25);check($p->total===60);check($p->max_num_pages===3);check($p->orders[0]->id===60);check(!$GLOBALS['wpdb']->queries);check(!isset($GLOBALS['order_queries'][0]['include']));
  $p=RKW_Modules::local_order_page(2,'all');check(count($p->orders)===25);check($p->orders[0]->id===35);$p=RKW_Modules::local_order_page(3,'all');check(count($p->orders)===10);
 }
};
$tests['native nonzero adapters preserve existing conditions and are restricted to this query']=function(){
 $existing=['meta_query'=>['relation'=>'OR',['key'=>'site_marker','value'=>'keep']],'post_status'=>['wc-processing']];$clauses=['where'=>'1=1 AND customer_id=9','limits'=>'LIMIT 0,25'];
 $GLOBALS['order_query_override']=function($args)use($existing,$clauses){
  check(apply_filters('woocommerce_order_data_store_cpt_get_orders_query',$existing,[])===$existing);check(apply_filters('woocommerce_orders_table_query_clauses',$clauses,new NativeTableQuery,[])===$clauses);
  $q=apply_filters('woocommerce_order_data_store_cpt_get_orders_query',$existing,$args);check($q['meta_query']['relation']==='AND');check($q['meta_query'][0]===$existing['meta_query']);check($q['post_status']===$existing['post_status']);
  $q=apply_filters('woocommerce_orders_table_query_clauses',$clauses,new NativeTableQuery,$args);check($q['where']===$clauses['where'].' AND wp_wc_orders.total_amount <> 0');check($q['limits']===$clauses['limits']);
  return(object)['orders'=>[],'max_num_pages'=>1,'total'=>0];
 };RKW_Modules::local_order_page(1,'all');check(apply_filters('woocommerce_order_data_store_cpt_get_orders_query',$existing,['rkw_local_nonzero'=>true])===$existing);check(apply_filters('woocommerce_orders_table_query_clauses',$clauses,new NativeTableQuery,['rkw_local_nonzero'=>true])===$clauses);
};
$tests['native nonzero adapters are removed on query errors and exceptions']=function(){
 foreach([false,true]as$throws){$GLOBALS['order_query_override']=function()use($throws){if($throws)throw new RuntimeException('synthetic query exception');return new WP_Error('synthetic','query error');};
  try{$p=RKW_Modules::local_order_page(1,'all');check(!$throws);expect_error($p,'synthetic');}catch(RuntimeException$e){check($throws&&$e->getMessage()==='synthetic query exception');}
  check(apply_filters('woocommerce_order_data_store_cpt_get_orders_query',[],['rkw_local_nonzero'=>true])===[]);check(apply_filters('woocommerce_orders_table_query_clauses',['where'=>'1=1'],new NativeTableQuery,['rkw_local_nonzero'=>true])===['where'=>'1=1']);
 }
};
$tests['result count and reset link expose current pagination without hiding eligible orders']=function(){
 for($id=1;$id<=27;$id++)$GLOBALS['local_orders'][]=local_order($id);$_GET['rkw_orders_page']=2;$h=layout_html();check(strpos($h,'نمایش 2 سفارش از 27 نتیجه')!==false);check(strpos($h,'صفحه 2 از 2')!==false);check(strpos($h,'حذف فیلترها و نمایش از ابتدا')!==false);
};

$tests['pending local and legacy cases render in the attention filter with review instead of send']=function(){
 $cases=[['',true,[]],['OK',false,[]],['901',true,[]],['',false,[['ID'=>77,'post_status'=>'publish','invoice_id'=>'']]],['',false,[['ID'=>77,'invoice_id'=>'901'],['ID'=>78,'invoice_id'=>'902']]],['',false,[['ID'=>77,'invoice_id'=>'OK']]]];
 foreach($cases as[$doc,$pending,$records]){layout_reset();$_GET['rkw_order_filter']='unsent';$o=local_order(5,'processing',$doc);if($pending)$o->meta['_rkw_reconcile_required']=1;$GLOBALS['local_orders']=[$o];$GLOBALS['wpdb']->records=$records;$before=$o->meta;$h=layout_html();check(strpos($h,'data-order-id="5"')!==false);check(strpos($h,'rkw-check-one')!==false);check(strpos($h,'rkw-send-one')===false);check($o->meta===$before);check(!$GLOBALS['http_calls']);}
};
$tests['showing pending orders in the filter never authorizes a financial resend']=function(){
 $_GET['rkw_order_filter']='unsent';$o=local_order(5);$o->meta['_rkw_reconcile_required']=1;$GLOBALS['local_orders']=[$o];$GLOBALS['test_orders']=[5=>$o];$h=layout_html();check(strpos($h,'data-order-id="5"')!==false);$_POST=['order_ids'=>[5]];
 try{RKW_Order_List_UI::ajax_send();}catch(TestJSON$r){check($r->success);check($r->data['items'][0]['status']==='blocked');check(!$GLOBALS['http_calls']);check($o->get_meta('_rkw_reconcile_required')===1);return;}throw new RuntimeException('expected blocked AJAX response');
};
$tests['paid custom fulfillment stages stay visible throughout the supposedly missing period']=function(){
 $GLOBALS['registered_statuses']+=['wc-packed'=>'بسته بندی شده','wc-cancelled'=>'لغو شده','wc-failed'=>'ناموفق'];
 for($i=1;$i<=60;$i++){$o=local_order($i,'packed');$o->paid=new DateTimeImmutable('2026-10-01',wp_timezone());$o->created=new DateTimeImmutable('2026-06-01',wp_timezone());$GLOBALS['local_orders'][]=$o;}
 foreach(['all','unsent']as$filter){$GLOBALS['order_queries']=[];$p=RKW_Modules::local_order_page(1,$filter);check($p->total===60);check($p->max_num_pages===3);check(count($p->orders)===25);check(in_array('wc-packed',$GLOBALS['order_queries'][0]['status'],true));}
 $h=layout_html();check(strpos($h,'data-order-id="60"')!==false);$GLOBALS['local_orders'][0]->paid=null;check(!RKW_Modules::invoice_order_eligible($GLOBALS['local_orders'][0]));
};
$tests['native custom-state guards are scoped to the invoice query and removed afterwards']=function(){
 $GLOBALS['registered_statuses']['wc-packed']='بسته بندی شده';$GLOBALS['order_query_override']=function($args){$q=apply_filters('woocommerce_order_data_store_cpt_get_orders_query',[],$args);check($q['rkw_invoice_paid_custom']===true);$scope=new class{function get($key){return$key==='rkw_invoice_paid_custom';}};$where=apply_filters('posts_where','1=1',$scope);check(strpos($where,"post_status IN ('wc-processing','wc-completed')")!==false);check(strpos($where,"pd.meta_key='_date_paid'")!==false);$h=apply_filters('woocommerce_orders_table_query_clauses',['where'=>'1=1'],new NativeTableQuery,$args);check(strpos($h['where'],'wp_wc_order_operational_data')!==false);return(object)['orders'=>[],'total'=>0,'max_num_pages'=>1];};
 RKW_Modules::local_order_page(1,'all');$scope=new class{function get($key){return true;}};check(apply_filters('posts_where','1=1',$scope)==='1=1');
};
if(isset($argv[1])&&$argv[1]==='html'){
 layout_reset();$one=local_order(1);$one->created=new DateTimeImmutable('2026-10-21 12:34:00',wp_timezone());$GLOBALS['local_orders']=[$one,local_order(2,'completed')];if(isset($argv[2])&&in_array($argv[2],['review','unsent-review'],true)){$one->meta['_rkw_reconcile_required']=1;}if(isset($argv[2])&&in_array($argv[2],['unsent','unsent-review'],true)){$_GET['rkw_order_filter']='unsent';$GLOBALS['wpdb']->total=2;$GLOBALS['wpdb']->ids=[1,2];}if(isset($argv[2])&&$argv[2]==='products')$_GET['page']='rkw-products';echo layout_html();exit;
}
if(isset($argv[1])&&$argv[1]==='sql'){
 layout_reset();if(isset($argv[7])&&$argv[7]==='custom')$GLOBALS['registered_statuses']['wc-packed']='بسته بندی شده';$GLOBALS['wpdb']->total=100;TestOrderUtil::$hpos=isset($argv[2])&&$argv[2]==='hpos';RKW_Modules::local_order_page(isset($argv[3])?(int)$argv[3]:1,$argv[6]??'unsent',$argv[4]??'',$argv[5]??'');echo json_encode($GLOBALS['wpdb']->queries);exit;
}
$fail=0;foreach($tests as $name=>$test){layout_reset();try{$test();echo 'PASS '.$name."\n";}catch(Throwable $e){$fail++;echo 'FAIL '.$name.': '.$e->getMessage().' at '.$e->getFile().':'.$e->getLine()."\n";}}
echo count($tests).' tests, '.$fail." failed\n";exit($fail?1:0);
