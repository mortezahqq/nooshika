<?php
require __DIR__.'/bootstrap.php';
class QuoteClient { public $rows=[],$calls=[]; function prices19($units){$this->calls[]=$units;return $this->rows;} }
function quote_settings(){return array_merge(rkw_settings(),['api'=>'v21','sync_price'=>1,'sync_sale'=>1,'shop_id'=>2,'currency_id'=>1,'sales_area_id'=>3,'customer_id'=>0]);}
function quote_item($id=174541){return ['id'=>$id,'unit'=>1,'price'=>5950000,'sale'=>null];}
$tests=[];
$tests['documented Price result maps by itemId even when response is reversed']=function(){
 $c=new QuoteClient;$c->rows=[['itemId'=>2,'fee'=>5950000,'discount'=>500,'netOfFee'=>5949500],['itemId'=>1,'fee'=>5950000,'discount'=>2975000,'netOfFee'=>2975000]];
 $out=RKW_Sync::quote_sales([quote_item(174537),quote_item()],quote_settings(),$c);
 check($out[0]['sale']===2975000.0&&$out[1]['sale']===5949500.0);check($c->calls===[[174537=>1,174541=>1]]);check($out[1]['sale_confirmed']);
};
$tests['missing malformed duplicate and inconsistent results preserve existing sale']=function(){
 foreach([[],[['itemId'=>1,'netOfFee'=>1]], [['itemId'=>1,'fee'=>100,'discount'=>1,'netOfFee'=>99]], [['itemId'=>1,'fee'=>5950000,'discount'=>0,'netOfFee'=>100]], [['itemId'=>1,'fee'=>5950000,'discount'=>1,'netOfFee'=>INF]], [['itemId'=>1,'fee'=>5950000,'discount'=>1,'netOfFee'=>100],['itemId'=>1,'fee'=>5950000,'discount'=>1,'netOfFee'=>100]]] as $rows){$c=new QuoteClient;$c->rows=$rows;$out=RKW_Sync::quote_sales([quote_item()],quote_settings(),$c);check($out[0]['sale']===null&&empty($out[0]['sale_confirmed']));check(!empty($out[0]['sale_notice']));}
};
$tests['successful no discount result is distinguished from read failure']=function(){
 $c=new QuoteClient;$c->rows=[['itemId'=>1,'fee'=>5950000,'discount'=>0,'netOfFee'=>5950000]];$out=RKW_Sync::quote_sales([quote_item()],quote_settings(),$c);check($out[0]['sale']===null&&$out[0]['sale_confirmed']);
 $c->rows=new WP_Error('failed','synthetic timeout');$out=RKW_Sync::quote_sales([quote_item()],quote_settings(),$c);check(empty($out[0]['sale_confirmed'])&&str_contains($out[0]['sale_notice'],'synthetic timeout'));
};
$tests['disabled sale and explicit GetProduct discount avoid extra calls']=function(){
 $c=new QuoteClient;$s=quote_settings();$s['sync_sale']=0;RKW_Sync::quote_sales([quote_item()],$s,$c);$i=quote_item();$i['sale']=100;RKW_Sync::quote_sales([$i],quote_settings(),$c);check(!$c->calls);
};
$tests['missing configured context never guesses identifiers or calls service']=function(){
 $c=new QuoteClient;$s=quote_settings();$s['sales_area_id']=0;$out=RKW_Sync::quote_sales([quote_item()],$s,$c);check(!$c->calls&&str_contains($out[0]['sale_notice'],'تکمیل'));
};
$tests['quote flag prevents repeated calculation within same refresh']=function(){
 $c=new QuoteClient;$c->rows=[['itemId'=>1,'fee'=>5950000,'discount'=>0,'netOfFee'=>5950000]];$out=RKW_Sync::quote_sales([quote_item()],quote_settings(),$c);RKW_Sync::quote_sales($out,quote_settings(),$c);check(count($c->calls)===1);
};
$failed=0;foreach($tests as$name=>$test){reset_case();try{$test();echo "PASS $name\n";}catch(Throwable $e){$failed++;echo "FAIL $name: ".$e->getMessage()."\n";}}echo count($tests)." tests, $failed failures\n";exit($failed?1:0);
