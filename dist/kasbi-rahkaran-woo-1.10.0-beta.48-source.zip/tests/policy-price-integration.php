<?php
define('RKW_AUTO_PRODUCT_FIXTURES_ONLY',true);require __DIR__.'/auto-product.php';
$tests=[];
function quote_auto_context(){auto_reset();$GLOBALS['options'][RKW_OPT]['sales_area_id']=3;$s=rkw_settings();set_transient(RKW_Client::COOKIE_TRANSIENT,['name'=>'sg-auth-sg','value'=>'synthetic-cookie','signature'=>RKW_Policy_Catalog::signature($s)],60);}
$tests['grey saves calculated sale via real Price HTTP path without writing an invoice']=function(){
 quote_auto_context();$GLOBALS['products'][101]->meta['_rahkaran_product_id']=174541;
 $GLOBALS['http_handler']=function($url,$args){
  if(strpos($url,'/GetProduct?')!==false)return response(['productId'=>174541,'fee'=>5950000,'RetailUnitRef'=>1]);
  if(strpos($url,'/ESales.svc/Price')!==false){check($args['method']==='POST');$b=json_decode($args['body'],true);$s=rkw_settings();check($b['customerId']===$s['customer_id']);check($b['salesAreaId']===3);check($b['items']===[['itemId'=>1,'productId'=>174541,'trackingFactors'=>[],'unitId'=>1,'quantity'=>1]]);return response([['itemId'=>1,'fee'=>5950000,'discount'=>2975000,'netOfFee'=>2975000]]);}
  check(strpos($url,'GetRemainingQuantityInfo')!==false);return response([['StoreID'=>2,'RemainingQuantity'=>0]]);
 };
 RKW_Auto_Product::update(101);$p=$GLOBALS['products'][101];check($p->regular==='595000'&&$p->sale==='297500'&&$p->price==='297500');check($p->qty===0);check(str_contains($p->meta[RKW_Auto_Product::STATUS_KEY]['message'],'محاسبه و دریافت'));check(count($GLOBALS['http_calls'])===3);
};
$tests['failed quote saves base but preserves prior sale and explains the upstream failure']=function(){
 quote_auto_context();$GLOBALS['products'][101]->sale='400';$GLOBALS['http_handler']=function($url){if(strpos($url,'/GetProduct?')!==false)return response(['productId'=>30,'fee'=>5000,'RetailUnitRef'=>1]);if(strpos($url,'/ESales.svc/Price')!==false)return new WP_Error('timeout','quote timeout');return response([['StoreID'=>2,'RemainingQuantity'=>2]]);};RKW_Auto_Product::update(101);$p=$GLOBALS['products'][101];check($p->regular==='500'&&$p->sale==='400');check(str_contains($p->meta[RKW_Auto_Product::STATUS_KEY]['message'],'quote timeout'));
};
$tests['confirmed no-discount clears a stale sale while failed lookup does not']=function(){
 quote_auto_context();$GLOBALS['products'][101]->sale='400';$GLOBALS['http_handler']=function($url){if(strpos($url,'/GetProduct?')!==false)return response(['productId'=>30,'fee'=>5000,'RetailUnitRef'=>1]);if(strpos($url,'/ESales.svc/Price')!==false)return response([['itemId'=>1,'fee'=>5000,'discount'=>0,'netOfFee'=>5000]]);return response([['StoreID'=>2,'RemainingQuantity'=>2]]);};RKW_Auto_Product::update(101);$p=$GLOBALS['products'][101];check($p->sale===''&&$p->price==='500');
};
$failed=0;foreach($tests as$n=>$t){try{$t();echo"PASS $n\n";}catch(Throwable$e){$failed++;echo"FAIL $n: ".$e->getMessage()."\n";}}echo count($tests)." tests, $failed failed\n";exit($failed?1:0);
