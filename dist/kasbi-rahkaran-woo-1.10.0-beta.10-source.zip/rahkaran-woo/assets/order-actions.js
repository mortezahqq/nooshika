/* global rkwOrderActions */
(function () {
  'use strict';
  if (typeof rkwOrderActions === 'undefined') return;
  const feedback = document.getElementById('rkw-local-send-status');
  const busy = new Set();
  function message(text, error) {
    if (feedback) { feedback.textContent = text; feedback.className = 'rkw-send-feedback ' + (error ? 'rkw-send-error' : 'rkw-send-ok'); }
    else {
      let top = document.getElementById('rkw-send-result-top');
      if (!top) {
        top = document.createElement('div'); top.id = 'rkw-send-result-top';
        top.setAttribute('role', 'status');
        const wrap = document.querySelector('.wrap') || document.body;
        wrap.prepend(top);
      }
      top.textContent = text;
      top.className = 'notice ' + (error ? 'notice-error' : 'notice-info');
    }
  }
  function updateRow(item) {
    const id = String(item.id);
    const row = document.querySelector('.rkw-bulk-table tr[data-order-id="' + id + '"]');
    const doc = document.querySelectorAll('.rkw-order-doc[data-order="' + id + '"]');
    const actions = document.querySelectorAll('.rkw-order-actions[data-order="' + id + '"]');
    const confirmed = item.status === 'sent' || (item.status === 'skipped' && !!item.document);
    if (confirmed || item.status === 'blocked') {
      doc.forEach(el => { el.textContent = confirmed ? (item.document || 'ثبت‌شده') : 'نیازمند تطبیق'; });
      actions.forEach(el => {
        el.textContent = confirmed ? (item.document || 'ثبت‌شده') : 'نیازمند بررسی در راهکاران';
        el.classList.add(confirmed ? 'rkw-order-sent' : 'rkw-order-pending');
      });
      if (row) { const checkbox = row.querySelector('.rkw-order-check'); if (checkbox) checkbox.remove(); }
      if (row && row.closest('.rkwm-local-orders[data-rkw-order-filter="unsent"]')) {
        const body = row.parentElement;
        row.remove();
        if (!body.querySelector('tr')) {
          const empty = document.createElement('tr'); const cell = document.createElement('td');
          cell.colSpan = 8; cell.textContent = 'سفارش دیگری در این صفحه باقی نمانده است؛ فهرست را به‌روزرسانی کنید.';
          empty.appendChild(cell); body.appendChild(empty);
        }
      }
    }
    if (row) {
      const result = row.querySelector('.rkw-last-result');
      if (result) { result.textContent = item.message; result.classList.toggle('rkw-row-error', item.status !== 'sent' && item.status !== 'skipped'); }
    }
  }
  async function send(ids) {
    const selected = [...new Set(ids.map(Number).filter(v => Number.isSafeInteger(v) && v > 0))];
    if (!selected.length) { message('ابتدا سفارش‌های قابل ارسال را انتخاب کنید.', true); return; }
    if (selected.length > 25) { message('در هر نوبت حداکثر ۲۵ سفارش قابل ارسال است.', true); return; }
    const label = selected.length === 1 ? 'سفارش #' + selected[0] : selected.length + ' سفارش';
    if (!window.confirm('ارسال ' + label + ' به راهکاران؟ اسناد ثبت‌شده و نتایج نامشخص دوباره ارسال نمی‌شوند. تا پایان عملیات صفحه را باز نگه دارید.')) return;
    if (busy.size) return;
    selected.forEach(id => busy.add(id));
    const controls = document.querySelectorAll('.rkw-send-one, .rkw-send-bulk');
    controls.forEach(button => button.disabled = true);
    let sent = 0; let finished = 0; let interrupted = false;
    const issues = [];
    // One request per invoice prevents a long PHP timeout and preserves the
    // result of earlier orders even if a later call is interrupted.
    for (const id of selected) {
      message('در حال ارسال سفارش ' + (finished + 1) + ' از ' + selected.length + ' (شناسه ' + id + ')…', false);
      try {
        const data = new URLSearchParams({ action: 'rkw_send_selected_orders', nonce: rkwOrderActions.nonce });
        data.append('order_ids[]', String(id));
        const response = await fetch(rkwOrderActions.ajax, {
          method: 'POST', credentials: 'same-origin',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
          body: data.toString()
        });
        const json = await response.json();
        if (!response.ok || !json.success) throw new Error(json && json.data && json.data.message ? json.data.message : 'خطا در درخواست.');
        const report = json.data.items || [];
        report.forEach(item => {
          updateRow(item);
          if (item.status === 'sent') sent++;
          else issues.push('#' + item.id + ': ' + item.message);
        });
        finished++;
      } catch (error) {
        issues.push('#' + id + ': نتیجه درخواست نامشخص است (' + error.message + ')');
        interrupted = true;
        break; // Never retry an uncertain POST without verifying Rahkaran.
      }
    }
    const summary = 'ارسال ' + finished + ' از ' + selected.length + ' سفارش بررسی شد؛ ' + sent + ' مورد ثبت شد.';
    message(summary + (interrupted ? ' ارسال گروه متوقف شد؛ نتیجه سفارش بعدی را در راهکاران بررسی کنید.' : '') + (issues.length ? ' ' + issues.slice(0, 5).join(' | ') : ''), interrupted || issues.length > 0);
    selected.forEach(id => busy.delete(id));
    controls.forEach(button => { if (button.isConnected) button.disabled = false; });
  }
  document.addEventListener('click', event => {
    const single = event.target.closest('.rkw-send-one');
    if (single) { event.preventDefault(); send([single.dataset.order]); return; }
    const bulk = event.target.closest('.rkw-send-bulk');
    if (bulk) {
      event.preventDefault();
      const table = bulk.closest('.rkwm-local-orders');
      if (!table) return;
      send([...table.querySelectorAll('.rkw-order-check:checked')].map(el => el.value));
    }
  });
  document.addEventListener('change', event => {
    if (!event.target.matches('.rkw-order-check-all')) return;
    const table = event.target.closest('table');
    if (table) table.querySelectorAll('.rkw-order-check:not(:disabled)').forEach(box => { box.checked = event.target.checked; });
  });
})();
