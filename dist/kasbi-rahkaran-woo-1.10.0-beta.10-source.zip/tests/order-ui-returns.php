<?php
require __DIR__ . '/bootstrap.php';

function update_post_meta($id,$key,$value){$GLOBALS['test_post_meta'][$id][$key]=$value;return true;}
function selected($a,$b=true,$echo=true){$v=(string)$a===(string)$b?' selected="selected"':'';if($echo)echo $v;return $v;}
function wc_get_orders($args){return $GLOBALS['test_order_list']??[];}

function reset_ui_case(){
 reset_case();RKW_Order_List_UI::clear_document_cache();RKW_Returns::clear_cache();
 $GLOBALS['test_capability']=true;$GLOBALS['test_nonce']=true;$GLOBALS['test_orders']=[];$GLOBALS['test_order_list']=[];$GLOBALS['test_post_meta']=[];
 $_POST=[];$_SERVER['REQUEST_METHOD']='POST';
}
function fixture(){
 return ['id'=>55,'number'=>'1001','customerId'=>45,'currencyId'=>1,'currencyTitle'=>'RIAL','inventoryId'=>1,'storeId'=>1,'netPrice'=>1000,'price'=>1000,'settlementPolicyId'=>27,'documentPatternId'=>9,'items'=>[['id'=>80,'inventoryId'=>1,'storeId'=>1,'productId'=>30,'unitId'=>1,'quantity'=>2,'fee'=>500,'price'=>1000,'netPrice'=>1000,'policies'=>[]]]];
}
function return_server($contract='v21'){
 $GLOBALS['options'][RKW_OPT]['document_contract']=$contract;$s=rkw_settings();set_transient(RKW_Client::COOKIE_TRANSIENT,['name'=>'sg-auth-sg','value'=>'synthetic-cookie','signature'=>RKW_Policy_Catalog::signature($s)],60);
 $GLOBALS['return_original']=fixture();$GLOBALS['return_draft']=fixture();$GLOBALS['return_draft']['id']=0;$GLOBALS['return_draft']['items'][0]['id']=-1;$GLOBALS['return_draft']['items'][0]['referenceId']=80;$GLOBALS['return_draft']['items'][0]['referenceType']=2;
 $GLOBALS['http_handler']=function($url,$args){
  if(strpos($url,'/GetInvoice?')!==false){check($args['method']==='GET');return response($GLOBALS['return_original']);}
  if(strpos($url,'/getDefaultMobileDocumentPatternByType?')!==false){check(strpos($url,'retailDocumentType=3')!==false);return response(['id'=>7,'defaults'=>['defaultSettlementPolicyId'=>77]]);}
  if(strpos($url,'/copyToReturnInvoice?')!==false){check(strpos($url,'invoiceId=55')!==false);check(strpos($url,'returnInvoicePatternId=7')!==false);return response($GLOBALS['return_draft']);}
  if(strpos($url,'/getSettlementPolicies?')!==false){check(strpos($url,'applicabilityType=3')!==false);return response([['settlementPolicyID'=>77,'settlementPolicyName'=>'Synthetic return','settlementMethodGroups'=>[['settlementMethods'=>[['settlementNatureKey'=>'Cash'],['natureKey'=>'BankReceipt'],['key'=>'ThirdPartyCoupon']]]]]]);}
  if(strpos($url,'/thirdPartyCouponTypes')!==false)return response([['Id'=>5,'title'=>'synthetic type']]);
  if(strpos($url,'/SaveReturnInvoice')!==false||strpos($url,'/ESales.svc/returninvoice')!==false){
   check($args['method']==='POST');check(get_option(RKW_Returns::key(55))['state']==='pending','durable marker missing before write');
   if(isset($GLOBALS['return_validate_wire']))($GLOBALS['return_validate_wire'])(json_decode($args['body'],true));
   return $GLOBALS['return_reply']??response(['id'=>501]);
  }
  throw new RuntimeException('unexpected fixture request: '.parse_url($url,PHP_URL_PATH));
 };
 unset($GLOBALS['return_validate_wire'],$GLOBALS['return_reply']);
}
function return_posts(){return array_values(array_filter($GLOBALS['http_calls'],function($c){return $c[1]['method']==='POST';}));}
function consent($prepared,$selection=[]){return RKW_Returns::submit(55,array_merge(['policy_id'=>77,'receipt_key'=>'Cash'],$selection),$prepared['fingerprint']);}
function preview(){return RKW_Returns::prepare(55,new RKW_Client);}
function ajax_result($fn){try{$fn();throw new RuntimeException('missing JSON response');}catch(TestJSON $reply){return $reply;}}

$tests=[];
$tests['registered RKW invoice shows its id and has no send button']=function(){
 $o=order();$o->meta['_rkw_doc_id']='501';$o->meta['_rkw_doc_type']='invoice';check(RKW_Order_List_UI::state($o)==='sent');$html=RKW_Order_List_UI::send_button($o);check(strpos($html,'501')!==false);check(strpos($html,'rkw-send-one')===false);
};
$tests['legacy-only confirmed invoice hides send in both classic and HPOS columns']=function(){
 $o=order();$GLOBALS['test_orders'][$o->id]=$o;$GLOBALS['wpdb']->records=[['ID'=>90,'post_status'=>'publish','invoice_id'=>'701']];
 check(RKW_Order_List_UI::document_label($o)==='شناسه نرم‌افزار #701');
 ob_start();RKW_Order_List_UI::classic_column('rkw_send',$o->id);$classic=ob_get_clean();ob_start();RKW_Order_List_UI::hpos_column('rkw_document_id',$o);$hpos=ob_get_clean();check(strpos($classic,'701')!==false);check(strpos($classic,'rkw-send-one')===false);check(strpos($hpos,'701')!==false);check(!$GLOBALS['http_calls']);
};
$tests['stale send click returns the existing id without issuing a document']=function(){
 $o=order();$GLOBALS['test_orders'][$o->id]=$o;$GLOBALS['wpdb']->records=[['ID'=>90,'invoice_id'=>'701']];$_POST=['order_ids'=>[$o->id]];
 $r=ajax_result(function(){RKW_Order_List_UI::ajax_send();});check($r->success);check($r->data['items'][0]['status']==='skipped');check(strpos($r->data['items'][0]['document'],'701')!==false);check(!$GLOBALS['http_calls']);
};
$tests['legacy queue, ambiguous ids and read failure never show a send button']=function(){
 foreach([[['ID'=>90,'invoice_id'=>'']],[['ID'=>90,'invoice_id'=>'701'],['ID'=>91,'invoice_id'=>'702']],[['ID'=>90,'invoice_id'=>'OK']]] as $rows){RKW_Order_List_UI::clear_document_cache();$GLOBALS['wpdb']->records=$rows;$o=order();check(RKW_Order_List_UI::state($o)==='pending');check(strpos(RKW_Order_List_UI::send_button($o),'rkw-send-one')===false);}
 RKW_Order_List_UI::clear_document_cache();$GLOBALS['wpdb']->last_error='synthetic DB failure';check(RKW_Order_List_UI::state(order())==='pending');$GLOBALS['wpdb']->last_error='';
};
$tests['unsent order still has its send button and invalid OK remains pending']=function(){
 $o=order();check(strpos(RKW_Order_List_UI::send_button($o),'rkw-send-one')!==false);$o->meta['_rkw_doc_id']='OK';check(RKW_Order_List_UI::state($o)==='pending');
};
$tests['successful send response contains the saved invoice id for immediate row replacement']=function(){
 $o=order();$GLOBALS['test_orders'][$o->id]=$o;$_POST=['order_ids'=>[$o->id]];$GLOBALS['http_handler']=function($u,$a){return strpos($u,'calculateAmount')!==false?response(['netPrice'=>1000]):response(['id'=>900]);};
 $r=ajax_result(function(){RKW_Order_List_UI::ajax_send();});check($r->data['items'][0]['status']==='sent');check($r->data['items'][0]['document']==='فاکتور #900');check(strpos(RKW_Order_List_UI::send_button($o),'rkw-send-one')===false);
};
$tests['return preview only reads actual invoice copy pattern and return policies']=function(){
 return_server();$p=preview();check(!is_wp_error($p));check($p['amount']===1000.0);check($p['pattern_id']===7);check($p['item_count']===1);check(count($p['policies'])===1);check(!return_posts());check(get_option(RKW_Returns::key(55))===false);
};
$tests['modern full return preserves original amounts and references in outgoing payments']=function(){
 return_server();$before=get_option(RKW_OPT);$p=preview();$GLOBALS['return_validate_wire']=function($wire){check($wire['document']['documentType']===3);check($wire['document']['documentPatternId']===7);check($wire['document']['settlementPolicyId']===77);check($wire['document']['items'][0]['referenceId']===80);check($wire['document']['items'][0]['quantity']===2);check($wire['payments'][0]['amount']===1000);check($wire['receipts']===[]);};
 $r=consent($p,['amount'=>1,'document'=>['customerId'=>999]]);check($r['id']===501);check(count(return_posts())===1);check(get_option(RKW_OPT)===$before);check(RKW_Returns::status(55)['state']==='returned');
};
$tests['legacy full return uses ESales returninvoice and per-unit line prices']=function(){
 return_server('legacy_esales');$p=preview();$GLOBALS['return_validate_wire']=function($wire){check($wire['document']['items'][0]['price']===500);check($wire['document']['items'][0]['fee']===500);check($wire['document']['items'][0]['storeId']===1);check($wire['payments'][0]['amount']===1000);check(!isset($wire['receipts']));};
 check(consent($p)['id']===501);check(strpos(return_posts()[0][0],'/ESales.svc/returninvoice')!==false);
};
$tests['return submit cannot be repeated after success']=function(){return_server();$p=preview();check(consent($p)['id']===501);$n=count($GLOBALS['http_calls']);expect_error(consent($p),'rkw_return_existing');check(count($GLOBALS['http_calls'])===$n);check(count(return_posts())===1);};
$tests['return timeout preserves pending state and blocks another financial POST']=function(){
 return_server();$p=preview();$GLOBALS['return_reply']=new WP_Error('http_request_failed','synthetic timeout');expect_error(consent($p),'http_request_failed');check(RKW_Returns::status(55)['state']==='pending');expect_error(consent($p),'rkw_return_existing');check(count(return_posts())===1);
};
$tests['return 500 and unconfirmed 200 cannot be blindly retried']=function(){
 foreach([response([],false,'synthetic server failure',500),response([]),response(['id'=>true])] as $reply){reset_ui_case();return_server();$p=preview();$GLOBALS['return_reply']=$reply;$r=consent($p);check(is_wp_error($r));check(RKW_Returns::status(55)['state']==='pending');expect_error(consent($p),'rkw_return_existing');check(count(return_posts())===1);}
};
$tests['definitive business rejection releases only this return marker']=function(){
 return_server();$p=preview();$GLOBALS['return_reply']=response([],false,'synthetic policy rejection');expect_error(consent($p),'rkw_api');check(get_option(RKW_Returns::key(55))===false);$GLOBALS['return_reply']=response(['id'=>502]);check(consent($p)['id']===502);
};
$tests['full-return preview rejects partially returnable items or changed amount']=function(){
 return_server();$GLOBALS['return_draft']['items'][0]['quantity']=1;expect_error(preview(),'rkw_return_partial');check(!return_posts());$GLOBALS['return_draft']['items'][0]['quantity']=2;$GLOBALS['return_draft']['netPrice']=900;expect_error(preview(),'rkw_return_amount');
};
$tests['tampered preview fingerprint and payment policy never reach the financial POST']=function(){
 return_server();$p=preview();expect_error(RKW_Returns::submit(55,['policy_id'=>77,'receipt_key'=>'Cash'],'invalid'),'rkw_return_changed');expect_error(consent($p,['policy_id'=>999]),'rkw_return_payment');check(!return_posts());check(get_option(RKW_Returns::key(55))===false);
};
$tests['source amount changes require a fresh preview']=function(){return_server();$p=preview();$GLOBALS['return_original']['netPrice']=1100;$GLOBALS['return_draft']['netPrice']=1100;expect_error(consent($p),'rkw_return_changed');check(!return_posts());};
$tests['bank return requires real bank and tracking fields']=function(){
 return_server();$p=preview();expect_error(consent($p,['receipt_key'=>'BankReceipt']),'rkw_return_bank');check(!return_posts());$GLOBALS['return_validate_wire']=function($wire){check($wire['payments'][0]['attr']['bankAccountRef']===30);check($wire['payments'][0]['attr']['transactionNumber']==='synthetic-refund-trace');};check(consent($p,['receipt_key'=>'BankReceipt','bank_account_ref'=>30,'transaction_number'=>'synthetic-refund-trace'])['id']===501);
};
$tests['coupon return validates type against the actual catalogue']=function(){
 return_server();$p=preview();expect_error(consent($p,['receipt_key'=>'ThirdPartyCoupon','coupon_type_id'=>46]),'rkw_coupon_type_not_found');check(!return_posts());check(consent($p,['receipt_key'=>'ThirdPartyCoupon','coupon_type_id'=>5])['id']===501);
};
$tests['registered legacy return and database error prevent a duplicate return']=function(){
 $GLOBALS['wpdb']->records=[['ID'=>90,'return_id'=>'601']];check(RKW_Returns::status(55)['id']===601);return_server();expect_error(preview(),'rkw_return_existing');check(!$GLOBALS['http_calls']);RKW_Returns::clear_cache();$GLOBALS['wpdb']->last_error='synthetic';check(RKW_Returns::status(55)['state']==='pending');$GLOBALS['wpdb']->last_error='';
};
$tests['return success also records the id in the linked old record']=function(){
 return_server();$GLOBALS['wpdb']->records=[['ID'=>90]];$p=preview();check(consent($p)['id']===501);check($GLOBALS['test_post_meta'][90]['return_invoice_id']===501);
};
$tests['return identity persists across credential and contract changes']=function(){
 $key=RKW_Returns::key(55);$GLOBALS['options'][RKW_OPT]['username']='another-user';$GLOBALS['options'][RKW_OPT]['password_enc']='synthetic-new-password';$GLOBALS['options'][RKW_OPT]['document_contract']='legacy_esales';check(RKW_Returns::key(55)===$key);$GLOBALS['options'][RKW_OPT]['ip']='other.example.invalid';check(RKW_Returns::key(55)!==$key);
};
$tests['concurrent return lock is not removed by another caller']=function(){
 $key=str_replace('rkw_return_invoice_','rkw_return_lock_',RKW_Returns::key(55));add_option($key,123,'',false);expect_error(RKW_Returns::submit(55,[],'x'),'rkw_return_lock');check(get_option($key)===123);check(!$GLOBALS['http_calls']);
};
$tests['return AJAX requires permission nonce POST and explicit confirmation']=function(){
 foreach(['capability','nonce','method','confirm'] as $failure){reset_ui_case();$_POST=['invoice_id'=>55,'confirm'=>'1'];if($failure==='capability')$GLOBALS['test_capability']=false;if($failure==='nonce')$GLOBALS['test_nonce']=false;if($failure==='method')$_SERVER['REQUEST_METHOD']='GET';if($failure==='confirm')unset($_POST['confirm']);$r=ajax_result(function(){RKW_Returns::ajax_submit();});check(!$r->success);check(!$GLOBALS['http_calls']);}
};
$tests['return preview AJAX does not expose the raw invoice document']=function(){return_server();$_POST=['invoice_id'=>55];$r=ajax_result(function(){RKW_Returns::ajax_prepare();});check($r->success);check(!isset($r->data['document']));check(isset($r->data['fingerprint']));check(!return_posts());};
$tests['saved invoice lists are decorated with existing return status']=function(){
 update_option(RKW_Returns::key(55),['state'=>'returned','id'=>501,'invoice_id'=>55]);$m=new ReflectionMethod(RKW_Modules::class,'decorate_invoices');$r=$m->invoke(null,['headers'=>[],'rows'=>[['id'=>'55','cells'=>['55','1001','synthetic customer','','1000','policy']]]]);check($r['rows'][0]['return_status']['id']===501);
};


$tests['legacy return retains shipping additions and discount directions']=function(){
 return_server('legacy_esales');
 foreach(['return_original','return_draft'] as $k){$GLOBALS[$k]['netPrice']=1050;$GLOBALS[$k]['price']=1200;$GLOBALS[$k]['items'][0]['fee']=600;$GLOBALS[$k]['items'][0]['price']=1200;$GLOBALS[$k]['items'][0]['policies']=[['policyId'=>80,'price'=>200,'effect'=>1,'isIncluded'=>true,'isReadOnly'=>true]];$GLOBALS[$k]['policies']=[['policyId'=>81,'price'=>50,'effect'=>2,'isIncluded'=>true,'enforcement'=>4]];}
 $p=preview();$GLOBALS['return_validate_wire']=function($w){check($w['payments'][0]['amount']===1050);$line=$w['document']['items'][0];check($line['quantity']===2);check($line['fee']===600);check(!isset($line['price']));check($line['policies'][0]['price']===200);check($line['policies'][0]['effect']==='Decrease');check(!isset($line['policies'][0]['isReadOnly']));check($w['document']['policies'][0]['effect']==='Increase');check(!isset($w['document']['policies'][0]['enforcement']));};check(consent($p)['id']===501);
};
$tests['invalid remote item rate and wrong customer never reach the return POST']=function(){
 return_server();$GLOBALS['return_draft']['customerId']=46;expect_error(preview(),'rkw_return_identity');$GLOBALS['return_draft']['customerId']=45;$GLOBALS['return_draft']['items'][0]['fee']='invalid';$p=preview();expect_error(consent($p),'rkw_return_line');check(!return_posts());
};
$tests['corrupt persisted return acknowledgment is treated as unknown']=function(){update_option(RKW_Returns::key(55),['state'=>'returned','id'=>'OK']);check(RKW_Returns::status(55)['state']==='pending');};

$tests['legacy zero return id means no registered return, as in the old plugin']=function(){ $GLOBALS['wpdb']->records=[['ID'=>90,'return_id'=>'0']];check(RKW_Returns::status(55)['state']==='available'); };

$fail=0;foreach($tests as $name=>$test){reset_ui_case();try{$test();echo 'PASS '.$name."\n";}catch(Throwable $e){$fail++;echo 'FAIL '.$name.': '.$e->getMessage().' at '.$e->getFile().':'.$e->getLine()."\n";}}
echo count($tests).' tests, '.$fail." failed\n";exit($fail?1:0);
