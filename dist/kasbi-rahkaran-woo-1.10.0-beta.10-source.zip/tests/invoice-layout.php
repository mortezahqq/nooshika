<?php
require __DIR__ . '/bootstrap.php';

class TestOrderUtil {public static $hpos=false;public static function custom_orders_table_usage_is_enabled(){return self::$hpos;}}
class_alias(TestOrderUtil::class,'Automattic\\WooCommerce\\Utilities\\OrderUtil');
class FilterDB extends TestDB {
 public $prefix='wp_',$total=0,$ids=[],$queries=[],$fail=false;
 function prepare($sql,...$args){
  $this->last_sql=$sql;$this->last_args=$args;$i=0;
  return preg_replace_callback('/%[sd]/',function($m)use(&$i,$args){$v=$args[$i++];return $m[0]==='%d'?(string)(int)$v:"'".str_replace("'","''",(string)$v)."'";},$sql);
 }
 function get_var($sql){$this->queries[]=$sql;if($this->fail){$this->last_error='synthetic';return null;}return $this->total;}
 function get_col($sql){$this->queries[]=$sql;return $this->ids;}
}
class FilterOrder extends WC_Order {public $status='processing';function get_status(){return $this->status;}}
function esc_url($v){return esc_attr($v);}
function selected($a,$b=true,$echo=true){$v=(string)$a===(string)$b?' selected="selected"':'';if($echo)echo $v;return $v;}
function wc_get_order_status_name($v){return $v==='processing'?'در حال انجام':($v==='completed'?'تکمیل‌شده':$v);}
function wc_get_orders($args){
 $GLOBALS['order_queries'][]=$args;
 if(isset($GLOBALS['order_query_override']))return ($GLOBALS['order_query_override'])($args);
 $orders=array_values(array_filter($GLOBALS['local_orders'],function($o)use($args){return in_array('wc-'.$o->get_status(),$args['status'],true)&&(!isset($args['include'])||in_array($o->id,$args['include'],true));}));
 usort($orders,function($a,$b){return $b->id<=>$a->id;});
 $total=count($orders);$orders=array_slice($orders,(($args['page']??1)-1)*$args['limit'],$args['limit']);
 return !empty($args['paginate'])?(object)['orders'=>$orders,'max_num_pages'=>max(1,(int)ceil($total/$args['limit'])),'total'=>$total]:$orders;
}
function layout_reset(){
 reset_case();RKW_Order_List_UI::clear_document_cache();RKW_Returns::clear_cache();TestOrderUtil::$hpos=false;
 $GLOBALS['wpdb']=new FilterDB;$GLOBALS['local_orders']=[];$GLOBALS['order_queries']=[];unset($GLOBALS['order_query_override']);$_GET=['page'=>'rkw-invoices'];
}
function local_order($id,$status='processing',$doc=''){$o=new FilterOrder;$o->id=$id;$o->total=100;$o->status=$status;if($doc!==''){$o->meta['_rkw_doc_id']=$doc;$o->meta['_rkw_doc_type']='invoice';}return $o;}
function layout_html(){ob_start();RKW_Modules::page();return ob_get_clean();}

$tests=[];
$tests['only processing and completed are requested and rendered']=function(){
 $GLOBALS['local_orders']=[local_order(1),local_order(2,'completed'),local_order(3,'cancelled'),local_order(4,'failed'),local_order(5,'pending'),local_order(6,'refunded')];
 $h=layout_html();check($GLOBALS['order_queries'][0]['status']===['wc-processing','wc-completed']);check(strpos($h,'data-order-id="1"')!==false);check(strpos($h,'data-order-id="2"')!==false);foreach([3,4,5,6]as$id)check(strpos($h,'data-order-id="'.$id.'"')===false);check(!$GLOBALS['http_calls']);
};
$tests['local orders and local filter precede a closed remote accordion']=function(){
 $GLOBALS['local_orders']=[local_order(1)];$h=layout_html();$local=strpos($h,'rkwm-local-orders');$remote=strpos($h,'<details id="rkwm-remote-invoices"');check($local<$remote);check(strpos($h,'id="rkw-local-order-filter"')<$remote);check(strpos($h,'<details id="rkwm-remote-invoices" class="rkwm-remote-invoices">')!==false);check(strpos($h,'id="rkwm-filter"')>$remote);check(!$GLOBALS['http_calls']);
};
$tests['unsent filter uses pre-pagination queries and hydrates only requested ids']=function(){
 for($i=101;$i<=127;$i++)$GLOBALS['local_orders'][]=local_order($i);
 $GLOBALS['wpdb']->total=27;$GLOBALS['wpdb']->ids=[101,102];$p=RKW_Modules::local_order_page(2,'unsent');check($p->max_num_pages===2);check(count($p->orders)===2);$q=$GLOBALS['order_queries'][0];check($q['include']===[101,102]);check($q['status']===['wc-processing','wc-completed']);check($q['page']===1);check($q['paginate']===false);check(strpos($GLOBALS['wpdb']->queries[1],'LIMIT 25 OFFSET 25')!==false);check(strpos($GLOBALS['wpdb']->queries[0],"o.post_status IN ('wc-processing','wc-completed')")!==false);
};
$tests['HPOS filter reads HPOS orders/meta while recognizing old CPT queues']=function(){
 TestOrderUtil::$hpos=true;$GLOBALS['wpdb']->total=1;$GLOBALS['wpdb']->ids=[1];$GLOBALS['local_orders']=[local_order(1)];RKW_Modules::local_order_page(1,'unsent');$sql=implode(' ', $GLOBALS['wpdb']->queries);check(strpos($sql,'FROM wp_wc_orders o')!==false);check(strpos($sql,'FROM wp_wc_orders_meta m WHERE m.order_id=o.id')!==false);check(strpos($sql,"lp.post_type='rahkaran-invoice'")!==false);check(strpos($sql,'o.date_created_gmt DESC')!==false);
};
$tests['empty unsent results never fall back to querying every order']=function(){
 $GLOBALS['local_orders']=[local_order(1,'processing','501')];$p=RKW_Modules::local_order_page(1,'unsent');check($p->orders===[]);check(!$GLOBALS['order_queries']);$GLOBALS['wpdb']->total=1;$GLOBALS['wpdb']->ids=[];$p=RKW_Modules::local_order_page(1,'unsent');check($p->orders===[]);check(!$GLOBALS['order_queries']);
};
$tests['filter query read errors are shown instead of silently widening the filter']=function(){
 $GLOBALS['wpdb']->fail=true;$_GET['rkw_order_filter']='unsent';$h=layout_html();check(strpos($h,'دریافت سفارش‌های ارسال‌نشده از پایگاه داده ناموفق بود')!==false);check(!$GLOBALS['order_queries']);
};
$tests['selected unsent filter persists in links and resets on form submission']=function(){
 $_GET['rkw_order_filter']='unsent';$_GET['rkw_orders_page']=2;$GLOBALS['wpdb']->total=60;$GLOBALS['wpdb']->ids=[1];$GLOBALS['local_orders']=[local_order(1)];$h=layout_html();check(strpos($h,'value="unsent"  selected="selected"')!==false);check(strpos($h,'rkw_order_filter=unsent')!==false);check(strpos($h,'name="rkw_orders_page"')===false);check(strpos($h,'data-rkw-order-filter="unsent"')!==false);
};
$tests['unknown filter values cannot expand statuses or change query conditions']=function(){
 $_GET['rkw_order_filter']=['unsent'];$h=layout_html();check(strpos($h,'data-rkw-order-filter="all"')!==false);check($GLOBALS['order_queries'][0]['status']===['wc-processing','wc-completed']);
};
$tests['orders that become sent or uncertain after selection are not labeled unsent']=function(){
 $_GET['rkw_order_filter']='unsent';$GLOBALS['wpdb']->total=2;$GLOBALS['wpdb']->ids=[1,2];$one=local_order(1,'processing','501');$two=local_order(2);$two->meta['_rkw_reconcile_required']=1;$GLOBALS['local_orders']=[$one,$two];$h=layout_html();check(strpos($h,'data-order-id="1"')===false);check(strpos($h,'data-order-id="2"')===false);check(strpos($h,'سفارشی با این فیلتر یافت نشد.')!==false);
};
$tests['out of range local pages are clamped to the actual last page']=function(){
 for($i=1;$i<=30;$i++)$GLOBALS['local_orders'][]=local_order($i);$p=RKW_Modules::local_order_page(99,'all');check($p->page===2);check(count($p->orders)===5);$GLOBALS['wpdb']->total=30;$GLOBALS['wpdb']->ids=[1,2,3,4,5];$p=RKW_Modules::local_order_page(99,'unsent');check($p->page===2);check(strpos($GLOBALS['wpdb']->queries[1],'OFFSET 25')!==false);
};

if(isset($argv[1])&&$argv[1]==='html'){
 layout_reset();$GLOBALS['local_orders']=[local_order(1),local_order(2,'completed')];if(isset($argv[2])&&$argv[2]==='unsent'){$_GET['rkw_order_filter']='unsent';$GLOBALS['wpdb']->total=2;$GLOBALS['wpdb']->ids=[1,2];}if(isset($argv[2])&&$argv[2]==='products')$_GET['page']='rkw-products';echo layout_html();exit;
}
if(isset($argv[1])&&$argv[1]==='sql'){
 layout_reset();$GLOBALS['wpdb']->total=100;TestOrderUtil::$hpos=isset($argv[2])&&$argv[2]==='hpos';RKW_Modules::local_order_page(isset($argv[3])?(int)$argv[3]:1,'unsent');echo json_encode($GLOBALS['wpdb']->queries);exit;
}
$fail=0;foreach($tests as $name=>$test){layout_reset();try{$test();echo 'PASS '.$name."\n";}catch(Throwable $e){$fail++;echo 'FAIL '.$name.': '.$e->getMessage().' at '.$e->getFile().':'.$e->getLine()."\n";}}
echo count($tests).' tests, '.$fail." failed\n";exit($fail?1:0);
