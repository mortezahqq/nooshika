<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** A fresh, read-only ERP check before payment. Does not change product stock or issue documents. */
class RKW_Checkout_Stock {
	const EVIDENCE = '_rkw_checkout_stock_check';
	const ROW_LIMIT = 500;

	/** Shared with page-view refreshes so paid, unexported units are not restocked. */
	public static function outstanding( $ids, $exclude = 0 ) { return self::reductions( $ids, $exclude ); }

	public static function init() {
		// Classic checkout has already made its native stock reservation at priority 10.
		add_action( 'woocommerce_checkout_order_created', array( __CLASS__, 'classic' ), 20 );
		// Store API reserves stock before this hook, and processes payment afterwards.
		add_action( 'woocommerce_store_api_checkout_order_processed', array( __CLASS__, 'blocks' ), 20 );
		add_action( 'woocommerce_before_pay_action', array( __CLASS__, 'pay_again' ), 20 );
	}

	private static function enabled() {
		$s = rkw_settings();
		return ! empty( $s['checkout_stock_guard'] ) && 'v21' === $s['api'];
	}

	public static function classic( $order ) { self::enforce( $order, false ); }
	private static function has_targets( $order ) {
		if ( ! self::enabled() || ! $order instanceof WC_Order ) { return false; }
		$s = rkw_settings();
		foreach ( $order->get_items() as $item ) {
			$p = $item->get_product();
			if ( $p && $p->managing_stock() && ! $p->backorders_allowed() && ( self::product_id( $p, $s ) || '' !== trim( (string) $p->get_meta( '_rahkaran_product_id', true ) ) ) ) { return true; }
		}
		return false;
	}
	public static function blocks( $order ) {
		if ( self::has_targets( $order ) ) {
			// The Store API's existing-order payment route does not reserve stock.
			// Renewing a new checkout's existing reservation replaces it, not adds to it.
			try { wc_reserve_stock_for_order( $order ); }
			catch ( Exception $error ) {
				wc_release_stock_for_order( $order );
				$message = 'تأیید موجودی سفارش در حال حاضر ممکن نیست. لطفاً کمی بعد دوباره تلاش کنید.';
				if ( class_exists( '\Automattic\WooCommerce\StoreApi\Exceptions\RouteException' ) ) { throw new \Automattic\WooCommerce\StoreApi\Exceptions\RouteException( 'rkw_checkout_stock_reserve', $message, 409 ); }
				throw new Exception( $message );
			}
		}
		self::enforce( $order, true );
	}
	public static function pay_again( $order ) {
		if ( ! self::has_targets( $order ) ) { return; }
		// A previous checkout's reservation may have expired. Restore the native
		// reservation before counting other shoppers' holds, without reducing stock.
		// WC_Form_Handler fires before_pay_action outside its exception handler.
		// Add a native error notice instead of throwing: it checks error notices
		// before calling the gateway's process_payment().
		try {
			wc_reserve_stock_for_order( $order );
			$result = self::check( $order );
		} catch ( Exception $error ) {
			$result = new WP_Error( 'rkw_checkout_stock_reserve', 'تأیید موجودی سفارش در حال حاضر ممکن نیست. لطفاً کمی بعد دوباره تلاش کنید.' );
		}
		if ( is_wp_error( $result ) ) { wc_release_stock_for_order( $order ); wc_add_notice( $result->get_error_message(), 'error' ); }
	}

	private static function enforce( $order, $blocks ) {
		$result = self::check( $order );
		if ( ! is_wp_error( $result ) ) { return; }
		// Release only this checkout's native hold; never restore/reduce physical stock.
		if ( $order instanceof WC_Order ) { wc_release_stock_for_order( $order ); }
		if ( $blocks && class_exists( '\Automattic\WooCommerce\StoreApi\Exceptions\RouteException' ) ) {
			throw new \Automattic\WooCommerce\StoreApi\Exceptions\RouteException( $result->get_error_code(), $result->get_error_message(), 409 );
		}
		throw new Exception( $result->get_error_message() );
	}

	private static function product_id( $product, $s ) {
		$id = trim( (string) $product->get_meta( '_rahkaran_product_id', true ) );
		if ( '' === $id && 'id' === $s['key_field'] ) { $id = trim( (string) $product->get_sku( 'edit' ) ); }
		return preg_match( '/^[1-9][0-9]*$/D', $id ) && (string) (int) $id === $id ? (int) $id : 0;
	}

	/** Use the document's warehouse, never another branch's available stock. */
	private static function store( $s ) {
		if ( (int) $s['inventory_id'] > 0 ) { return (int) $s['inventory_id']; }
		$ids = array_values( array_unique( array_filter( array_map( 'absint', explode( ',', (string) $s['store_ids'] ) ) ) ) );
		return 1 === count( $ids ) ? $ids[0] : 0;
	}

	/** Kept separate so the authoritative CPT/HPOS query can be exercised against SQL fixtures. */
	public static function reductions_sql( $ids, $exclude, $hpos ) {
		global $wpdb;
		$ids = array_values( array_unique( array_map( 'absint', $ids ) ) );
		$items = $wpdb->prefix . 'woocommerce_order_items';
		$im = $wpdb->prefix . 'woocommerce_order_itemmeta';
		$orders = $hpos ? $wpdb->prefix . 'wc_orders' : $wpdb->posts;
		$meta = $hpos ? $wpdb->prefix . 'wc_orders_meta' : $wpdb->postmeta;
		$oid = $hpos ? 'id' : 'ID'; $mid = $hpos ? 'order_id' : 'post_id';
		$type = $hpos ? 'type' : 'post_type'; $status = $hpos ? 'status' : 'post_status';
		$slots = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
		$sql = "SELECT DISTINCT oi.order_item_id AS item_id, oi.order_id, r.meta_value AS quantity,
			CASE WHEN EXISTS (SELECT 1 FROM {$meta} u WHERE u.{$mid}=oi.order_id AND u.meta_key='_rkw_reconcile_required' AND u.meta_value NOT IN ('','0'))
			OR EXISTS (SELECT 1 FROM {$meta} d WHERE d.{$mid}=oi.order_id AND d.meta_key='_rkw_doc_id' AND d.meta_value<>'' AND d.meta_value NOT REGEXP '^[1-9][0-9]*$') THEN 1 ELSE 0 END AS uncertain
			FROM {$items} oi INNER JOIN {$orders} o ON o.{$oid}=oi.order_id
			INNER JOIN {$im} p ON p.order_item_id=oi.order_item_id AND p.meta_key='_product_id'
			LEFT JOIN {$im} v ON v.order_item_id=oi.order_item_id AND v.meta_key='_variation_id'
			INNER JOIN {$im} r ON r.order_item_id=oi.order_item_id AND r.meta_key='_reduced_stock'
			WHERE oi.order_item_type='line_item' AND o.{$type}='shop_order' AND o.{$status} NOT IN ('trash','wc-trash')
			AND oi.order_id<>%d AND r.meta_value NOT IN ('','0','0.0')
			AND (CASE WHEN CAST(COALESCE(v.meta_value,'0') AS UNSIGNED)>0 THEN CAST(v.meta_value AS UNSIGNED) ELSE CAST(p.meta_value AS UNSIGNED) END) IN ({$slots})
			AND NOT EXISTS (SELECT 1 FROM {$meta} m WHERE m.{$mid}=oi.order_id AND m.meta_key='_rkw_manual_recorded' AND m.meta_value='1')
			AND NOT (EXISTS (SELECT 1 FROM {$meta} d WHERE d.{$mid}=oi.order_id AND d.meta_key='_rkw_doc_id' AND d.meta_value REGEXP '^[1-9][0-9]*$')
			AND NOT EXISTS (SELECT 1 FROM {$meta} d WHERE d.{$mid}=oi.order_id AND d.meta_key='_rkw_doc_id' AND d.meta_value<>'' AND d.meta_value NOT REGEXP '^[1-9][0-9]*$')
			AND NOT EXISTS (SELECT 1 FROM {$meta} u WHERE u.{$mid}=oi.order_id AND u.meta_key='_rkw_reconcile_required' AND u.meta_value NOT IN ('','0')))
			LIMIT " . ( self::ROW_LIMIT + 1 );
		return $wpdb->prepare( $sql, array_merge( array( (int) $exclude ), $ids ) );
	}

	/** Actual Woo reductions only; unpaid native reservations are counted separately. */
	private static function reductions( $ids, $exclude ) {
		global $wpdb;
		$hpos = class_exists( '\Automattic\WooCommerce\Utilities\OrderUtil' ) && \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled();
		$rows = $wpdb->get_results( self::reductions_sql( $ids, $exclude, $hpos ), ARRAY_A );
		if ( ! is_array( $rows ) || ! empty( $wpdb->last_error ) || count( $rows ) > self::ROW_LIMIT ) { return new WP_Error( 'rkw_checkout_local_stock', 'local_stock_read_failed' ); }
		$out = array(); $legacy = array();
		foreach ( $rows as $row ) {
			if ( ! isset( $row['item_id'], $row['order_id'], $row['quantity'] ) || ! is_numeric( $row['quantity'] ) || ! is_finite( (float) $row['quantity'] ) ) { return new WP_Error( 'rkw_checkout_local_stock', 'local_stock_invalid' ); }
			$qty = (float) $row['quantity']; if ( $qty <= 0 ) { continue; }
			$oid = (int) $row['order_id']; $iid = (int) $row['item_id'];
			if ( $oid <= 0 || $iid <= 0 ) { return new WP_Error( 'rkw_checkout_local_stock', 'local_stock_invalid' ); }
			if ( ! empty( $row['uncertain'] ) ) { $out[ $iid ] = max( $out[ $iid ] ?? 0, $qty ); continue; }
			if ( ! array_key_exists( $oid, $legacy ) ) {
				// Do not release a hold for a legacy queue row, an ambiguous ID, or a DB error.
				$records = RKW_Migration::legacy_order_records( $oid ); $confirmed = array(); $ambiguous = false;
				foreach ( is_array( $records ) ? $records : array() as $record ) {
					$id = trim( (string) ( $record['invoice_id'] ?? '' ) );
					if ( preg_match( '/^[1-9][0-9]*$/D', $id ) ) { $confirmed[ $id ] = true; }
					elseif ( '' !== $id ) { $ambiguous = true; }
				}
				$legacy[ $oid ] = ! is_wp_error( $records ) && ! $ambiguous && 1 === count( $confirmed );
			}
			if ( ! $legacy[ $oid ] ) { $out[ $iid ] = max( $out[ $iid ] ?? 0, $qty ); }
		}
		return $out;
	}

	private static function quantity( $rows, $store ) {
		if ( ! is_array( $rows ) || array_values( $rows ) !== $rows ) { return new WP_Error( 'rkw_checkout_stock_schema', 'invalid_stock_list' ); }
		$found = false; $quantity = 0;
		foreach ( $rows as $row ) {
			if ( ! is_array( $row ) ) { return new WP_Error( 'rkw_checkout_stock_schema', 'invalid_stock_row' ); }
			$id = $row['StoreID'] ?? $row['storeID'] ?? null;
			if ( ! ( is_int( $id ) || is_string( $id ) ) || ! preg_match( '/^[1-9][0-9]*$/D', (string) $id ) ) { return new WP_Error( 'rkw_checkout_stock_schema', 'invalid_store' ); }
			if ( (int) $id !== $store ) { continue; }
			$q = $row['RemainingQuantity'] ?? $row['remainingQuantity'] ?? null;
			if ( $found || ! is_numeric( $q ) || ! is_finite( (float) $q ) ) { return new WP_Error( 'rkw_checkout_stock_schema', 'invalid_or_duplicate_quantity' ); }
			$found = true; $quantity = max( 0, (float) $q );
		}
		// An absent warehouse is unknown, not permission to use other branches.
		return $found ? $quantity : new WP_Error( 'rkw_checkout_stock_store', 'store_not_returned' );
	}

	private static function stop( $order, $row, $code, $evidence ) {
		$evidence['status'] = 'blocked'; $evidence['reason'] = $code;
		$order->update_meta_data( self::EVIDENCE, $evidence ); $order->save_meta_data();
		RKW_Log::add( 'warn', 'کنترل موجودی پیش از پرداخت: ' . wp_json_encode( array( 'order_id' => $order->get_id(), 'product_id' => $row['id'], 'store_id' => $evidence['store_id'], 'reason' => $code, 'checks' => $evidence['checks'] ), JSON_UNESCAPED_UNICODE ) );
		$name = sanitize_text_field( $row['name'] );
		$message = 'rkw_checkout_stock_shortage' === $code
			? sprintf( 'موجودی کافی برای «%s» تأیید نشد. لطفاً تعداد را کاهش دهید یا کالا را از سبد حذف کنید.', $name )
			: sprintf( 'بررسی موجودی «%s» در حال حاضر ممکن نیست. لطفاً کمی بعد دوباره تلاش کنید.', $name );
		return new WP_Error( $code, $message );
	}

	public static function check( $order ) {
		if ( ! self::enabled() || ! $order instanceof WC_Order || 'shop_order' !== $order->get_type() ) { return true; }
		$s = rkw_settings(); $groups = array();
		foreach ( $order->get_items() as $item ) {
			$product = $item->get_product();
			if ( ! $product || ! $product->managing_stock() || $product->backorders_allowed() ) { continue; }
			$id = self::product_id( $product, $s );
			if ( ! $id ) {
				if ( '' !== trim( (string) $product->get_meta( '_rahkaran_product_id', true ) ) ) { return new WP_Error( 'rkw_checkout_product_mapping', 'اتصال موجودی یکی از کالاها معتبر نیست. لطفاً با پشتیبانی فروشگاه تماس بگیرید.' ); }
				continue;
			}
			$raw_qty = apply_filters( 'woocommerce_order_item_quantity', $item->get_quantity(), $order, $item );
			if ( ! is_numeric( $raw_qty ) || ! is_finite( (float) $raw_qty ) || (float) $raw_qty <= 0 ) { return new WP_Error( 'rkw_checkout_quantity', 'تعداد کالا معتبر نیست؛ لطفاً سبد را بررسی کنید.' ); }
			$qty = (float) $raw_qty;
			if ( ! isset( $groups[ $id ] ) ) { $groups[ $id ] = array( 'id' => $id, 'ids' => array(), 'owners' => array(), 'quantity' => 0.0, 'name' => $product->get_name() ); }
			$groups[ $id ]['ids'][ $product->get_id() ] = $product->get_id();
			$groups[ $id ]['owners'][ $product->get_stock_managed_by_id() ] = $product;
			$groups[ $id ]['quantity'] += $qty;
		}
		if ( ! $groups ) { return true; }
		$store = self::store( $s );
		$evidence = array( 'time' => time(), 'store_id' => $store, 'status' => 'checking', 'checks' => array() );
		$first = reset( $groups );
		if ( ! $store || count( $groups ) > 20 || ! function_exists( 'wc_get_held_stock_quantity' ) ) { return self::stop( $order, $first, 'rkw_checkout_stock_config', $evidence ); }
		$client = RKW_Client::checkout_stock_client(); $started = microtime( true );
		foreach ( $groups as $row ) {
			if ( microtime( true ) - $started > 15 ) { return self::stop( $order, $row, 'rkw_checkout_stock_budget', $evidence ); }
			$before = self::reductions( array_values( $row['ids'] ), $order->get_id() );
			if ( is_wp_error( $before ) ) { return self::stop( $order, $row, $before->get_error_code(), $evidence ); }
			$quantity = self::quantity_or_error( $client->remaining21( $row['id'] ), $store );
			if ( is_wp_error( $quantity ) ) { return self::stop( $order, $row, $quantity->get_error_code(), $evidence ); }
			if ( microtime( true ) - $started > 20 ) { return self::stop( $order, $row, 'rkw_checkout_stock_budget', $evidence ); }
			$held = 0.0;
			foreach ( $row['owners'] as $product ) { $held += (float) wc_get_held_stock_quantity( $product, $order->get_id() ); }
			$after = self::reductions( array_values( $row['ids'] ), $order->get_id() );
			if ( is_wp_error( $after ) || ! is_finite( $held ) || $held < 0 ) { return self::stop( $order, $row, 'rkw_checkout_local_stock', $evidence ); }
			// Merge by item, not max(sum): one order can finish while another arrives
			// during the GET. A concurrent release may conservatively require a retry.
			foreach ( $after as $item_id => $qty ) { $before[ $item_id ] = max( $before[ $item_id ] ?? 0, $qty ); }
			$pending = array_sum( $before ); $available = max( 0, $quantity - $held - $pending );
			$evidence['checks'][] = array( 'product_id' => $row['id'], 'woocommerce_ids' => array_values( $row['ids'] ), 'requested' => $row['quantity'], 'erp_remaining' => $quantity, 'other_unpaid_holds' => $held, 'other_unexported_reductions' => $pending, 'available' => $available );
			if ( $row['quantity'] > $available ) { return self::stop( $order, $row, 'rkw_checkout_stock_shortage', $evidence ); }
		}
		if ( $s !== rkw_settings() ) { return self::stop( $order, $first, 'rkw_checkout_stock_changed', $evidence ); }
		$evidence['status'] = 'passed'; $order->update_meta_data( self::EVIDENCE, $evidence ); $order->save_meta_data();
		RKW_Log::add( 'info', 'تأیید موجودی پیش از پرداخت: ' . wp_json_encode( array( 'order_id' => $order->get_id(), 'store_id' => $store, 'checks' => $evidence['checks'] ), JSON_UNESCAPED_UNICODE ) );
		return true;
	}

	private static function quantity_or_error( $result, $store ) { return is_wp_error( $result ) ? new WP_Error( 'rkw_checkout_stock_service', 'stock_service_unavailable' ) : self::quantity( $result, $store ); }
}
