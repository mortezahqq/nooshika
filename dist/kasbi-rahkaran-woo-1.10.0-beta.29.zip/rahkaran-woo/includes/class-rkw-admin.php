<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class RKW_Admin {
	const CAP = 'manage_woocommerce';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_post_rkw_save', array( __CLASS__, 'save' ) );
		add_action( 'admin_post_rkw_reset_saved_data', array( __CLASS__, 'reset_saved_data' ) );
		add_action( 'admin_post_rkw_clear_log', array( __CLASS__, 'clear_log' ) );
		add_action( 'admin_post_rkw_delete_log', array( __CLASS__, 'delete_log' ) );
		add_action( 'admin_post_rkw_export_log', array( __CLASS__, 'export_log' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_log_assets' ) );
		add_action( 'wp_ajax_rkw_test', array( __CLASS__, 'ajax_test' ) );
		add_action( 'wp_ajax_rkw_discover', array( __CLASS__, 'ajax_discover' ) );
		add_action( 'wp_ajax_rkw_policy_catalog', array( __CLASS__, 'ajax_policy_catalog' ) );
		add_action( 'wp_ajax_rkw_step', array( __CLASS__, 'ajax_step' ) );
		add_action( 'wp_ajax_rkw_payment_diagnose', array( __CLASS__, 'ajax_payment_diagnose' ) );
		add_action( 'wp_ajax_rkw_pos_diagnose', array( __CLASS__, 'ajax_pos_diagnose' ) );
	}

	/** Display only the resolved gateway mapping; never submits anything to Rahkaran. */
	public static function ajax_payment_diagnose() {
		if ( ! current_user_can( self::CAP ) || ! check_ajax_referer( 'rkw_ajax', '_ajax_nonce', false ) ) {
			wp_send_json_error( array( 'message' => 'دسترسی یا نشست نامعتبر است.' ), 403 );
		}
		$order_id = isset( $_POST['order_id'] ) ? absint( wp_unslash( $_POST['order_id'] ) ) : 0;
		$order = $order_id ? wc_get_order( $order_id ) : false;
		if ( ! $order instanceof WC_Order || 'shop_order' !== $order->get_type() ) {
			wp_send_json_error( array( 'message' => 'سفارش ووکامرس معتبر یافت نشد.' ), 404 );
		}
		$report = RKW_Payment::diagnose_order( $order, rkw_settings() );
		$ui_version = isset( $_POST['ui_version'] ) && is_string( $_POST['ui_version'] ) ? sanitize_text_field( wp_unslash( $_POST['ui_version'] ) ) : '';
		if ( RKW_VER !== $ui_version ) {
			if ( ! isset( $report['warnings'] ) ) { $report['warnings'] = array(); }
			$report['warnings'][] = 'صفحه بررسی با نسخه فعال افزونه (' . RKW_VER . ') هم‌نسخه نیست؛ صفحه مدیریت را با Ctrl+F5 تازه‌سازی کنید و دوباره بررسی بزنید.';
		}
		wp_send_json_success( $report );
	}

	/** Read-only POS device discovery; never return hardware configuration values. */
	public static function ajax_pos_diagnose() {
		if ( ! current_user_can( self::CAP ) || ! check_ajax_referer( 'rkw_ajax', '_ajax_nonce', false ) ) {
			wp_send_json_error( array( 'message' => 'دسترسی یا نشست نامعتبر است.' ), 403 );
		}
		$c = new RKW_Client();
		$result = $c->poses_info21();
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => 'بررسی دستگاه‌ها: ' . $result->get_error_message() ), 502 );
		}
		if ( is_array( $result ) && isset( $result['items'] ) && is_array( $result['items'] ) ) { $result = $result['items']; }
		if ( is_array( $result ) && isset( $result['ID'] ) ) { $result = array( $result ); }
		$rows = array();
		foreach ( is_array( $result ) ? array_slice( $result, 0, 100 ) : array() as $device ) {
			if ( ! is_array( $device ) ) { continue; }
			$row = array();
			foreach ( array( 'ID', 'RetailShopRef', 'DeviceRef' ) as $key ) {
				$row[ $key ] = isset( $device[ $key ] ) ? absint( $device[ $key ] ) : 0;
			}
			foreach ( array( 'DeviceTitle', 'DeviceModelUniqueKey' ) as $key ) {
				$row[ $key ] = isset( $device[ $key ] ) && is_scalar( $device[ $key ] ) ? sanitize_text_field( (string) $device[ $key ] ) : '';
			}
			// Exclude device configuration, IPs, ports and any session/merchant identifiers.
			$rows[] = $row;
		}
		wp_send_json_success( array(
			'count' => count( $rows ),
			'devices' => $rows,
			'note' => 'این نتیجه فقط دستگاه‌های POS قابل مشاهده برای صندوق/فروشگاه فعلی را نشان می‌دهد و علت خطای SaveInvoice را به‌تنهایی ثابت نمی‌کند.',
		) );
	}

	public static function menu() {
		// Independent admin menu; keep the original page slug to preserve existing links.
		add_menu_page(
			'کاسبی راهکاران',
			'کاسبی راهکاران',
			self::CAP,
			'rkw',
			array( __CLASS__, 'page' ),
			'dashicons-store',
			56
		);
		add_submenu_page( 'rkw', 'داشبورد کاسبی راهکاران', 'داشبورد', self::CAP, 'rkw', array( __CLASS__, 'page' ) );
		RKW_Modules::menu();
		RKW_Extensions::menu();
		RKW_Migration::menu();
		RKW_Reports::menu();
		RKW_Coupon_Types::menu();
	}

	public static function product_field() {
		global $post;
		if ( ! $post ) { return; }
		$p = wc_get_product( $post->ID );
		if ( ! $p ) { return; }
		$id = $p->get_meta( '_rahkaran_product_id' );
		if ( $id ) {
			echo '<p class="form-field"><label>شناسه راهکاران</label><span>' . esc_html( $id ) . '</span></p>';
		}
	}

	/* ---------- ذخیره ---------- */

	public static function save() {
		if ( ! current_user_can( self::CAP ) ) { wp_die( 'دسترسی ندارید' ); }
		check_admin_referer( 'rkw_save' );
		$old = get_option( RKW_OPT, array() );
		$old = wp_parse_args( is_array( $old ) ? $old : array(), rkw_defaults() );
		$in  = isset( $_POST['rkw'] ) ? wp_unslash( $_POST['rkw'] ) : array();
		if ( ! is_array( $in ) ) { $in = array(); }
		$tab = isset( $_POST['tab'] ) ? sanitize_key( $_POST['tab'] ) : 'dashboard';
		$new = $old;

		$fields = array(
			'connection' => array(
				'text' => array( 'ip', 'port', 'cluster', 'username', 'machine_name' ),
				'int'  => array( 'timeout' ),
				'bool' => array( 'verify_ssl', 'debug' ),
			),
			'catalog' => array(
				'text'  => array( 'store_ids' ),
				'int'   => array( 'shop_id', 'currency_id', 'customer_id', 'sales_area_id', 'batch_size', 'page_start' ),
				'bool'  => array( 'sync_stock', 'sync_price', 'sync_sale', 'sync_name', 'create_missing', 'auto_product_on_save', 'checkout_stock_guard', 'product_view_refresh' ),
			),
			'orders' => array(
				'text' => array( 'order_statuses', 'receipt_key', 'national_key', 'e_receipt_type', 'credit_receipt_key' ),
				'int'  => array( 'doc_pattern_id', 'invoice_doc_pattern_id', 'order_doc_pattern_id', 'settlement_id', 'invoice_settlement_id', 'order_settlement_id', 'sales_area_ord', 'inventory_id', 'loyalty_id', 'fallback_cust', 'bank_account_ref', 'credit_policy_id', 'default_unit_id', 'item_discount_policy_id', 'coupon_type_id' ),
				'bool' => array( 'order_enabled', 'fida_fallback', 'invoice_preflight' ),
			),
		);

		if ( isset( $fields[ $tab ] ) ) {
			foreach ( $fields[ $tab ]['text'] as $k ) { $new[ $k ] = sanitize_text_field( isset( $in[ $k ] ) ? $in[ $k ] : '' ); }
			foreach ( $fields[ $tab ]['int'] as $k ) { $new[ $k ] = max( 0, (int) ( isset( $in[ $k ] ) ? $in[ $k ] : 0 ) ); }
			foreach ( $fields[ $tab ]['bool'] as $k ) { $new[ $k ] = empty( $in[ $k ] ) ? 0 : 1; }
		}

		if ( 'connection' === $tab ) {
			$new['api']      = ( isset( $in['api'] ) && 'v19' === $in['api'] ) ? 'v19' : 'v21';
			$new['protocol'] = ( isset( $in['protocol'] ) && 'https' === $in['protocol'] ) ? 'https' : 'http';
			$new['ip']       = preg_replace( '#^https?://#i', '', trim( $new['ip'], " /\t" ) );
			if ( isset( $in['password'] ) && '' !== $in['password'] ) { $new['password_enc'] = RKW_Crypto::encrypt( $in['password'] ); }
			$new['timeout'] = max( 5, min( 120, $new['timeout'] ) );
			delete_transient( RKW_Client::COOKIE_TRANSIENT );
		}
		if ( 'catalog' === $tab ) {
			$new['key_field']     = ( isset( $in['key_field'] ) && 'id' === $in['key_field'] ) ? 'id' : 'code';
			$new['price_divisor'] = rkw_price_multiplier( $in );
			$new['price_field']   = ( isset( $in['price_field'] ) && in_array( $in['price_field'], array( 'fee', 'consumerFee', 'netOfFee' ), true ) ) ? $in['price_field'] : 'fee';
			$ci = array( 'off', 'rkw_1min', 'rkw_5min', 'rkw_15min', 'hourly', 'twicedaily', 'daily' );
			$new['cron_interval'] = ( isset( $in['cron_interval'] ) && in_array( $in['cron_interval'], $ci, true ) ) ? $in['cron_interval'] : 'rkw_1min';
			$new['batch_size']    = max( 5, min( 200, $new['batch_size'] ) );
			$new['store_ids']     = preg_replace( '/[^0-9,]/', '', $new['store_ids'] );
		}
		if ( 'orders' === $tab ) {
			$new['document_contract'] = isset( $in['document_contract'] ) && 'v21' === $in['document_contract'] ? 'v21' : 'legacy_esales';
			if ( $new['document_contract'] !== $old['document_contract'] ) { delete_transient( RKW_Client::COOKIE_TRANSIENT ); delete_transient( 'rkw_cash_register' ); }
			$new['customer_mode'] = isset( $in['customer_mode'] ) && 'default' === $in['customer_mode'] ? 'default' : 'individual';
			$new['order_mode']     = ( isset( $in['order_mode'] ) && 'invoice' === $in['order_mode'] ) ? 'invoice' : 'salesorder';
			$new['order_statuses'] = preg_replace( '/[^a-z0-9_\-,]/', '', strtolower( $new['order_statuses'] ) );
			$new['credit_receipt_key'] = preg_replace( '/[^A-Za-z0-9_]/', '', $new['credit_receipt_key'] );
			$new['receipt_key']    = preg_replace( '/[^A-Za-z0-9_]/', '', $new['receipt_key'] );
			$new['e_receipt_type'] = preg_replace( '/[^A-Za-z0-9_-]/', '', $new['e_receipt_type'] );
			$new['e_receipt_mode'] = isset( $in['e_receipt_mode'] ) && 'explicit' === $in['e_receipt_mode'] ? 'explicit' : 'omit';
			$new['electronic_route'] = 'receipts'; // v21 SaveInvoice: receipts, never repayments.
			$new['no_gateway_order'] = in_array( isset( $in['no_gateway_order'] ) ? $in['no_gateway_order'] : 'cash', array( 'cash', 'credit', 'block' ), true ) ? $in['no_gateway_order'] : 'cash';
			$new['credit_gateways'] = RKW_Payment::sanitize_gateways( isset( $in['credit_gateways'] ) ? $in['credit_gateways'] : array() );
			$new['payment_rules']   = RKW_Payment::sanitize_rules( isset( $in['payment_rules'] ) ? $in['payment_rules'] : array() );
		}

		update_option( RKW_OPT, $new );
		if ( 'catalog' === $tab ) { RKW_Sync::reschedule(); }
		wp_safe_redirect( admin_url( 'admin.php?page=rkw&tab=' . $tab . '&saved=1' ) );
		exit;
	}


	/**
	 * A deliberate, separately confirmed cleanup of plugin-owned persisted data.
	 * Never run this from the WordPress uninstall lifecycle.
	 */
	public static function reset_saved_data() {
		if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'فقط مدیر سایت می‌تواند داده‌های افزونه را پاک کند.' ); }
		check_admin_referer( 'rkw_reset_saved_data' );
		$confirmation = isset( $_POST['rkw_confirm_reset'] ) && is_string( $_POST['rkw_confirm_reset'] )
			? trim( wp_unslash( $_POST['rkw_confirm_reset'] ) ) : '';
		if ( 'DELETE RAHKARAN' !== $confirmation ) {
			wp_safe_redirect( admin_url( 'admin.php?page=rkw&tab=retention&reset_error=1' ) );
			exit;
		}

		// Only owned options. Do not touch WooCommerce products, customers, orders,
		// per-order mappings or the shared legacy loyalty-members table.
		foreach ( array(
			'rkw_settings', 'rkw_extensions', 'rkw_log', 'rkw_cursor',
			'rkw_last_run', 'rkw_loyalty_db_version', 'rkw_invoices_list_revision',
		) as $option ) {
			delete_option( $option );
		}
		$index = get_option( 'rkw_admin_snapshot_index_v1', array() );
		if ( is_array( $index ) ) {
			foreach ( array_keys( $index ) as $option_name ) {
				if ( is_string( $option_name ) && 0 === strpos( $option_name, 'rkw_admin_snap_' ) ) {
					delete_option( $option_name );
				}
			}
		}
		delete_option( 'rkw_admin_snapshot_index_v1' );
		foreach ( array( 'stores', 'customers', 'products', 'policies', 'invoices' ) as $section ) {
			delete_metadata( 'user', 0, 'rkw_admin_last_view_' . $section, '', true );
		}
		delete_transient( 'rkw_session_cookies' );
		delete_transient( 'rkw_sync_lock' );
		delete_transient( 'rkw_cash_register' );
		wp_clear_scheduled_hook( 'rkw_cron_sync' );
		wp_clear_scheduled_hook( 'rkw_cron_continue' );
		// Keep cron disabled after reset; default settings will be applied only when saved.
		wp_safe_redirect( admin_url( 'admin.php?page=rkw&tab=retention&reset_done=1' ) );
		exit;
	}

	/** Settings stay in wp_options after disabling, updating, deleting or reinstalling. */
	private static function retention_page() {
		$main = get_option( RKW_OPT, false );
		$extra = get_option( RKW_Extensions::OPTION, false );
		$main_saved = is_array( $main ) && ! empty( $main );
		$extra_saved = is_array( $extra ) && ! empty( $extra );
		echo '<section class="rkw-panel"><h2>نگهداری تنظیمات پس از حذف و نصب مجدد</h2>';
		echo '<p>تنظیمات اتصال، همگام‌سازی کالا و موجودی، سفارش‌ها، روش پرداخت، شناسه بانک، امکانات تکمیلی، گزارش‌ها و فهرست‌های ذخیره‌شده هنگام غیرفعال‌کردن، به‌روزرسانی یا حذف افزونه <strong>حفظ می‌شوند</strong>. پس از نصب دوباره، اطلاعات از دیتابیس همین سایت خوانده می‌شود.</p>';
		echo '<table class="widefat striped" style="max-width:700px"><thead><tr><th>نوع اطلاعات</th><th>وضعیت</th></tr></thead><tbody>';
		echo '<tr><td>تنظیمات اتصال، کالا و سفارش (rkw_settings)</td><td>' . ( $main_saved ? 'ذخیره‌شده' : 'هنوز ذخیره نشده' ) . '</td></tr>';
		echo '<tr><td>تنظیمات امکانات تکمیلی (rkw_extensions)</td><td>' . ( $extra_saved ? 'ذخیره‌شده' : 'هنوز ذخیره نشده' ) . '</td></tr>';
		echo '</tbody></table>';
		echo '<p class="description">رمز عبور اتصال به شکل رمزنگاری‌شده در دیتابیس ذخیره شده و برای بازیابی آن باید کلیدها و Saltهای فایل wp-config.php همین سایت تغییر نکرده باشند. انتقال تنظیمات به سایت با کلیدهای متفاوت نیاز به ثبت دوباره رمز دارد.</p>';
		echo '<p class="description">توجه: اگر افزونه قبلاً با نسخه 1.9.2 یا پایین‌تر حذف شده و اطلاعات آن پاک شده باشد، این نسخه نمی‌تواند تنظیمات حذف‌شده را بازیابی کند؛ تنها بکاپ قبلی دیتابیس می‌تواند کمک کند.</p>';
		echo '</section>';
		if ( ! current_user_can( 'manage_options' ) ) { return; }
		echo '<section class="rkw-panel" style="border-color:#dba4a4"><h2 style="color:#a02d26">پاک‌سازی دستی اطلاعات افزونه</h2>';
		echo '<p><strong>خطر:</strong> این کار تنظیمات اتصال، تنظیمات کالا و سفارش، تنظیمات امکانات تکمیلی، لاگ‌ها و فهرست‌های ذخیره‌شده را حذف می‌کند. محصولات، مشتریان و سفارش‌های ووکامرس و جدول مشترک اعضای وفاداری پاک نمی‌شوند. این عملیات قابل بازگشت نیست.</p>';
		if ( isset( $_GET['reset_error'] ) ) { echo '<div class="notice notice-error inline"><p>عبارت تأیید صحیح نبود؛ هیچ اطلاعاتی پاک نشد.</p></div>'; }
		if ( isset( $_GET['reset_done'] ) ) { echo '<div class="notice notice-success inline"><p>داده‌های داخلی انتخاب‌شده پاک شدند.</p></div>'; }
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		echo '<input type="hidden" name="action" value="rkw_reset_saved_data">';
		wp_nonce_field( 'rkw_reset_saved_data' );
		echo '<label for="rkw-confirm-reset">برای تأیید پاک‌سازی عمدی، عبارت <code>DELETE RAHKARAN</code> را دقیقاً وارد کنید:</label> ';
		echo '<input type="text" id="rkw-confirm-reset" name="rkw_confirm_reset" required autocomplete="off" style="direction:ltr;width:220px"> ';
		echo '<button class="button" type="submit" style="border-color:#a02d26;color:#a02d26">پاک‌سازی عمدی اطلاعات افزونه</button></form></section>';
	}

	public static function clear_log() {
		if ( ! current_user_can( self::CAP ) ) { wp_die( 'دسترسی ندارید' ); }
		check_admin_referer( 'rkw_clear_log' );
		RKW_Log::clear();
		self::log_redirect( 'cleared' );
	}

	/** استایل و اسکریپت جدول و پاپ‌آپ گزارش‌ها روی داشبورد و صفحه گزارش‌ها. */
	public static function enqueue_log_assets() {
		if ( ! current_user_can( self::CAP ) ) { return; }
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
		$tab  = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'dashboard';
		if ( 'rkw' !== $page || ! in_array( $tab, array( 'log', 'dashboard' ), true ) ) { return; }
		wp_enqueue_style( 'rkw-log-ui', plugins_url( 'assets/log.css', RKW_FILE ), array(), RKW_VER );
		wp_enqueue_script( 'rkw-log-ui', plugins_url( 'assets/log.js', RKW_FILE ), array(), RKW_VER, true );
	}

	/** حذف یک رکورد بدون دست‌کاری سایر رویدادها. */
	public static function delete_log() {
		if ( ! current_user_can( self::CAP ) ) { wp_die( 'دسترسی ندارید' ); }
		check_admin_referer( 'rkw_delete_log' );
		$id = isset( $_POST['log_id'] ) ? sanitize_text_field( wp_unslash( $_POST['log_id'] ) ) : '';
		$deleted = '' !== $id && RKW_Log::delete( $id );
		self::log_redirect( $deleted ? 'deleted' : 'missing' );
	}

	/** خروجی JSON گزارش‌هایی که در افزونه ذخیره شده‌اند. */
	public static function export_log() {
		if ( ! current_user_can( self::CAP ) ) { wp_die( 'دسترسی ندارید' ); }
		check_admin_referer( 'rkw_export_log' );
		nocache_headers();
		header( 'Content-Type: application/json; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="rahkaran-logs-' . gmdate( 'Y-m-d-His' ) . '.json"' );
		header( 'X-Content-Type-Options: nosniff' );
		echo wp_json_encode( RKW_Log::all(), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
		exit;
	}

	private static function log_redirect( $notice ) {
		$return_tab = isset( $_POST['rkw_return'] ) && 'dashboard' === sanitize_key( wp_unslash( $_POST['rkw_return'] ) ) ? 'dashboard' : 'log';
		$args = array( 'page' => 'rkw', 'tab' => $return_tab, 'rkw_notice' => $notice );
		foreach ( array( 'rkw_level', 'rkw_search', 'rkw_paged' ) as $key ) {
			if ( ! isset( $_POST[ $key ] ) ) { continue; }
			$value = sanitize_text_field( wp_unslash( $_POST[ $key ] ) );
			if ( '' !== $value ) { $args[ $key ] = $value; }
		}
		wp_safe_redirect( add_query_arg( $args, admin_url( 'admin.php' ) ) );
		exit;
	}

	private static function log_action_form( $action, $label, $nonce, $fields = array(), $confirm = '', $class = '' ) {
		$attributes = $confirm ? ' data-rkwlog-confirm="' . esc_attr( $confirm ) . '"' : '';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"' . $attributes . '>';
		echo '<input type="hidden" name="action" value="' . esc_attr( $action ) . '">';
		wp_nonce_field( $nonce );
		foreach ( $fields as $key => $value ) {
			echo '<input type="hidden" name="' . esc_attr( $key ) . '" value="' . esc_attr( $value ) . '">';
		}
		echo '<button type="submit" class="button ' . esc_attr( $class ) . '">' . esc_html( $label ) . '</button></form>';
	}


	/** خلاصهٔ تک‌خطی از لاگ، بدون نمایش URL یا پاسخ طولانی در داشبورد. */
	private static function log_summary( $message, $limit = 115 ) {
		$message = (string) $message;
		if ( preg_match( '/^عملیات:\s*([^\r\n]+)/u', $message, $match ) ) {
			$summary = 'فراخوانی سرویس ' . trim( $match[1] );
			if ( preg_match( '/^وضعیت:\s*([^\r\n]+)/mu', $message, $status ) ) {
				$summary .= ' — ' . trim( $status[1] );
			}
			return $summary;
		}
		$summary = trim( preg_replace( '/\s+/u', ' ', $message ) );
		return rkw_text_length( $summary ) > $limit ? rkw_text_slice( $summary, 0, $limit ) . '…' : $summary;
	}

	/** محتوا فقط به‌صورت متن escape‌شده ذخیره می‌شود؛ پنجره در سمت مرورگر آن را می‌خواند. */
	private static function render_log_source( $source_id, $row ) {
		$levels = array( 'info' => 'اطلاع‌رسانی', 'warn' => 'هشدار', 'error' => 'خطا', 'debug' => 'عیب‌یابی' );
		$label = isset( $levels[ $row['level'] ] ) ? $levels[ $row['level'] ] : $row['level'];
		echo '<div class="rkwlog-source" id="' . esc_attr( $source_id ) . '" hidden>';
		echo '<span class="rkwlog-source-date">' . esc_html( $row['date'] ) . '</span>';
		echo '<span class="rkwlog-source-level">' . esc_html( $label ) . '</span>';
		echo '<span class="rkwlog-source-id">' . esc_html( $row['id'] ) . '</span>';
		echo '<pre class="rkwlog-source-message">' . esc_html( $row['message'] ) . '</pre></div>';
	}

	/** تنها یک پاپ‌آپ در هر صفحه؛ مناسب برای نمایش کامل و امن جزئیات لاگ. */
	private static function render_log_modal() {
		?>
		<div id="rkwlog-modal" class="rkwlog-modal" hidden>
			<div class="rkwlog-backdrop" data-rkwlog-close="1"></div>
			<section class="rkwlog-dialog" role="dialog" aria-modal="true" aria-labelledby="rkwlog-modal-title" aria-describedby="rkwlog-modal-description" dir="rtl" tabindex="-1">
				<header class="rkwlog-modal-header">
					<div><span class="rkwlog-modal-eyebrow">گزارش رویداد راهکاران</span><h2 id="rkwlog-modal-title">جزئیات کامل رویداد</h2></div>
					<button type="button" class="rkwlog-modal-x" data-rkwlog-close="1" aria-label="بستن پنجره">&times;</button>
				</header>
				<div class="rkwlog-modal-body">
					<p id="rkwlog-modal-description" class="rkwlog-modal-description">جزئیات ذخیره‌شده برای رویداد انتخابی</p>
					<div class="rkwlog-modal-meta">
						<div><span>تاریخ و ساعت</span><strong id="rkwlog-modal-date" dir="ltr"></strong></div>
						<div><span>نوع رویداد</span><strong id="rkwlog-modal-level"></strong></div>
						<div><span>شناسه رویداد</span><code id="rkwlog-modal-id" dir="ltr"></code></div>
					</div>
					<div id="rkwlog-modal-structured" class="rkwlog-structured" hidden>
						<div class="rkwlog-fields">
							<div><span>عملیات</span><strong id="rkwlog-modal-operation"></strong></div>
							<div><span>وضعیت درخواست</span><strong id="rkwlog-modal-status" dir="ltr"></strong></div>
							<div class="rkwlog-fields-wide"><span>آدرس سرویس</span><code id="rkwlog-modal-url" dir="ltr"></code></div>
						</div>
						<div class="rkwlog-code-section"><h3>اطلاعات درخواست</h3><pre id="rkwlog-modal-request" class="rkwlog-full"></pre></div>
						<div class="rkwlog-code-section"><h3>اطلاعات پاسخ</h3><pre id="rkwlog-modal-response" class="rkwlog-full"></pre></div>
					</div>
					<div id="rkwlog-modal-raw" class="rkwlog-code-section"><h3>متن کامل ثبت‌شده</h3><pre id="rkwlog-modal-text" class="rkwlog-full"></pre></div>
				</div>
				<footer class="rkwlog-modal-footer">
					<button type="button" class="button rkwlog-toggle-raw" hidden>نمایش متن خام</button>
					<div class="rkwlog-modal-footer-actions"><button type="button" class="button rkwlog-copy" data-source="rkwlog-modal-text">کپی متن کامل</button><button type="button" class="button button-primary" data-rkwlog-close="1">بستن</button></div>
				</footer>
			</section>
		</div>
		<?php
	}

	private static function render_log_page() {
		$rows = RKW_Log::all();
		$level_labels = array( 'info' => 'اطلاع‌رسانی', 'warn' => 'هشدار', 'error' => 'خطا', 'debug' => 'عیب‌یابی' );
		$counts = array( 'all' => count( $rows ), 'error' => 0, 'warn' => 0, 'info' => 0, 'debug' => 0 );
		foreach ( $rows as $row ) { if ( isset( $counts[ $row['level'] ] ) ) { ++$counts[ $row['level'] ]; } }
		$level = isset( $_GET['rkw_level'] ) ? sanitize_key( wp_unslash( $_GET['rkw_level'] ) ) : 'all';
		if ( 'all' !== $level && ! isset( $level_labels[ $level ] ) ) { $level = 'all'; }
		$search = isset( $_GET['rkw_search'] ) ? rkw_text_slice( sanitize_text_field( wp_unslash( $_GET['rkw_search'] ) ), 0, 150 ) : '';
		$filtered = array();
		foreach ( $rows as $row ) {
			if ( 'all' !== $level && $row['level'] !== $level ) { continue; }
			if ( '' !== $search && false === rkw_text_search( $row['message'] . ' ' . $row['date'] . ' ' . $row['level'], $search ) ) { continue; }
			$filtered[] = $row;
		}
		$per_page = 20;
		$total = count( $filtered );
		$pages = max( 1, (int) ceil( $total / $per_page ) );
		$page = isset( $_GET['rkw_paged'] ) ? max( 1, min( $pages, absint( $_GET['rkw_paged'] ) ) ) : 1;
		$visible = array_slice( $filtered, ( $page - 1 ) * $per_page, $per_page );
		$url = admin_url( 'admin.php' );
		$query = array( 'page' => 'rkw', 'tab' => 'log', 'rkw_level' => $level, 'rkw_search' => $search );
		$hidden = array( 'rkw_level' => $level, 'rkw_search' => $search, 'rkw_paged' => $page );
		echo '<section class="rkwlog-wrap"><div class="rkwlog-top"><div><h2>گزارش فعالیت‌ها و خطاهای راهکاران</h2><p>جست‌وجو، بررسی متن کامل رویدادها و مدیریت گزارش‌های ذخیره‌شده.</p></div></div>';
		$notice = isset( $_GET['rkw_notice'] ) ? sanitize_key( $_GET['rkw_notice'] ) : '';
		if ( 'deleted' === $notice ) { echo '<div class="notice notice-success inline"><p>گزارش انتخاب‌شده حذف شد.</p></div>'; }
		if ( 'cleared' === $notice ) { echo '<div class="notice notice-success inline"><p>گزارش‌ها پاک شدند.</p></div>'; }
		if ( 'missing' === $notice ) { echo '<div class="notice notice-warning inline"><p>رکورد مورد نظر پیدا نشد.</p></div>'; }
		echo '<div class="rkwlog-stats">';
		foreach ( array( 'all' => 'کل رویدادها', 'error' => 'خطاها', 'warn' => 'هشدارها', 'info' => 'اطلاع‌رسانی', 'debug' => 'عیب‌یابی' ) as $key => $label ) {
			echo '<div class="rkwlog-stat"><span>' . esc_html( $label ) . '</span><strong>' . esc_html( number_format_i18n( $counts[ $key ] ) ) . '</strong></div>';
		}
		echo '</div><div class="rkwlog-controls"><form method="get" action="' . esc_url( $url ) . '" class="rkwlog-filters">';
		echo '<input type="hidden" name="page" value="rkw"><input type="hidden" name="tab" value="log">';
		echo '<label>نوع رویداد<select name="rkw_level"><option value="all">همه رویدادها</option>';
		foreach ( $level_labels as $key => $label ) {
			echo '<option value="' . esc_attr( $key ) . '" ' . selected( $level, $key, false ) . '>' . esc_html( $label ) . '</option>';
		}
		echo '</select></label><label>جست‌وجو در پیام و تاریخ<input type="search" name="rkw_search" maxlength="150" value="' . esc_attr( $search ) . '" placeholder="عبارت مورد نظر..." /></label><button type="submit" class="button button-primary">اعمال فیلتر</button>';
		echo '<a href="' . esc_url( add_query_arg( array( 'page' => 'rkw', 'tab' => 'log' ), $url ) ) . '" class="button">پاک کردن فیلتر</a></form><div class="rkwlog-actions">';
		self::log_action_form( 'rkw_export_log', 'دریافت JSON گزارش‌ها', 'rkw_export_log' );
		self::log_action_form( 'rkw_clear_log', 'حذف همه گزارش‌ها', 'rkw_clear_log', array(), 'تمام گزارش‌های ثبت‌شده حذف شوند؟ این کار قابل بازگشت نیست.', 'rkwlog-delete' );
		echo '</div></div><div class="rkwlog-table-area"><table class="rkwlog-table"><thead><tr><th scope="col">ردیف</th><th scope="col">تاریخ و زمان</th><th scope="col">سطح</th><th scope="col">عنوان / خلاصه رویداد</th><th scope="col">عملیات</th></tr></thead><tbody>';
		if ( ! $visible ) { echo '<tr><td colspan="5"><div class="rkwlog-empty"><strong>گزارشی پیدا نشد</strong>هنوز رویدادی ثبت نشده یا نتیجه‌ای با این فیلتر وجود ندارد.</div></td></tr>'; }
		foreach ( $visible as $i => $row ) {
			$ordinal = ( $page - 1 ) * $per_page + $i + 1;
			$id = 'rkwlog-record-' . sanitize_html_class( (string) $row['id'] );
			$preview = self::log_summary( $row['message'] );
			$label = isset( $level_labels[ $row['level'] ] ) ? $level_labels[ $row['level'] ] : $row['level'];
			echo '<tr><td>' . esc_html( number_format_i18n( $ordinal ) ) . '</td><td class="rkwlog-time">' . esc_html( $row['date'] ) . '</td>';
			echo '<td><span class="rkwlog-level rkwlog-level--' . esc_attr( sanitize_html_class( $row['level'] ) ) . '">' . esc_html( $label ) . '</span></td>';
			echo '<td><span class="rkwlog-summary" title="' . esc_attr( $preview ) . '">' . esc_html( $preview ) . '</span></td><td><div class="rkwlog-buttons">';
			echo '<button type="button" class="button rkwlog-view" data-rkwlog-source="' . esc_attr( $id ) . '" aria-haspopup="dialog" aria-controls="rkwlog-modal">نمایش اطلاعات</button>';
			self::log_action_form( 'rkw_delete_log', 'حذف', 'rkw_delete_log', array_merge( $hidden, array( 'log_id' => $row['id'] ) ), 'این گزارش حذف شود؟', 'rkwlog-delete' );
			echo '</div></td></tr>';
		}
		echo '</tbody></table></div><div class="rkwlog-bottom"><span>نمایش ' . esc_html( number_format_i18n( $total ? ( $page - 1 ) * $per_page + 1 : 0 ) ) . ' تا ' . esc_html( number_format_i18n( min( $page * $per_page, $total ) ) ) . ' از ' . esc_html( number_format_i18n( $total ) ) . ' گزارش</span>';
		RKW_Pagination::render( $page, $pages, $query, 'rkw_paged', 'rkwlog-pager' );
		echo '</div><p class="rkwlog-help">جزئیات شامل متن کاملِ ذخیره‌شده برای هر رویداد است. گزارش‌های نسخه‌های قبل، اگر هنگام ثبت کوتاه شده باشند، قابل بازیابی نیستند. اطلاعات لاگ ممکن است محرمانه باشد؛ خروجی را در اختیار افراد غیرمجاز نگذارید.</p></section>';
		foreach ( $visible as $row ) { self::render_log_source( 'rkwlog-record-' . sanitize_html_class( (string) $row['id'] ), $row ); }
		self::render_log_modal();
	}

	/* ---------- AJAX ---------- */

	private static function ajax_guard() {
		check_ajax_referer( 'rkw_ajax' );
		if ( ! current_user_can( self::CAP ) ) { wp_send_json_error( 'دسترسی ندارید' ); }
	}

	/** A successful HTTP login does not imply that the server returned register details. */
	public static function connection_test_message( $status, $register ) {
		if ( empty( $status['cashier_requested'] ) ) { return 'ورود عمومی موفق بود؛ نام ماشین در تنظیمات ذخیره‌شده خالی است و ورود به صندوق انجام نشد. نام ماشین را وارد و تنظیمات را ذخیره کنید، سپس تست اتصال را بزنید.'; }
		if ( empty( $status['cashier_accepted'] ) ) { return 'ورود عمومی انجام شد، اما ورود به صندوق تأیید نشده است.'; }
		if ( is_array( $register ) && ! empty( $register['cashRegisterId'] ) ) {
			return 'اتصال و ورود به صندوق موفق. صندوق: ' . sanitize_text_field( isset( $register['cashRegisterTitle'] ) ? $register['cashRegisterTitle'] : '' ) . ' (شناسه ' . (int) $register['cashRegisterId'] . ') | فروشگاه: ' . sanitize_text_field( isset( $register['retailShopTitle'] ) ? $register['retailShopTitle'] : '' );
		}
		if ( ! empty( $status['legacy_empty_ack'] ) ) { return 'ورود عمومی موفق بود. سرویس قدیمی برای ورود به صندوق با نام ماشین «' . sanitize_text_field( $status['machine_name'] ) . '» پاسخ HTTP 200 و JSON خالی برگرداند؛ مطابق رفتار wp-rahkaran، درخواست موفق تلقی شد. سرویس شناسه و مشخصات صندوق را برنگرداند.'; }
		return 'ورود عمومی موفق و درخواست ورود به صندوق با نام ماشین «' . sanitize_text_field( $status['machine_name'] ) . '» توسط سرویس پذیرفته شد. سرویس مشخصات صندوق را برنگرداند؛ شناسه و عنوان صندوق از این پاسخ قابل تأیید نیست.';
	}

	public static function ajax_test() {
		self::ajax_guard();
		$c = new RKW_Client();
		$l = $c->login();
		if ( is_wp_error( $l ) ) { wp_send_json_error( $l->get_error_message() ); }
		if ( $c->is_v21() ) { wp_send_json_success( self::connection_test_message( $c->login_status(), get_transient( 'rkw_cash_register' ) ) ); }
		$shops = $c->shops19();
		if ( is_wp_error( $shops ) ) { wp_send_json_error( 'ورود موفق بود اما دریافت فروشگاه‌ها خطا داد: ' . $shops->get_error_message() ); }
		$out = array();
		foreach ( (array) $shops as $sh ) {
			$st = array();
			foreach ( (array) ( isset( $sh['stores'] ) ? $sh['stores'] : array() ) as $x ) { $st[] = $x['id'] . ':' . $x['name']; }
			$out[] = 'فروشگاه ' . $sh['id'] . ' (' . $sh['name'] . ') — انبارها: ' . implode( '، ', $st );
		}
		wp_send_json_success( 'اتصال موفق. ' . implode( ' | ', $out ) );
	}

	/** Fetch actual available policies and document metadata, never a baked-in ID list. */
	public static function ajax_policy_catalog() {
		self::ajax_guard();
		$r = RKW_Policy_Catalog::refresh();
		if ( is_wp_error( $r ) ) { wp_send_json_error( $r->get_error_message() ); }
		wp_send_json_success( $r );
	}

	/** Numeric setting paired with an optional server-populated selector. */
	private static function policy_picker( $key, $label, $s, $type, $description = '' ) {
		$val = isset( $s[ $key ] ) ? absint( $s[ $key ] ) : 0;
		$html = '<div class="rkw-choice"><input type="number" min="0" class="small-text" id="rkw-setting-' . esc_attr( $key ) . '" name="rkw[' . esc_attr( $key ) . ']" value="' . esc_attr( $val ) . '">';
		$html .= '<select class="rkw-catalog-choice" data-rkw-for="' . esc_attr( $key ) . '" data-rkw-type="' . esc_attr( $type ) . '" aria-label="' . esc_attr( $label ) . '"><option value="">انتخاب از شناسه‌های دریافت‌شده…</option></select></div>';
		self::row( $label, $html, $description );
	}

	/** نمایش شناسه‌های لازم برای تنظیم سفارش (v21) */
	public static function ajax_discover() {
		self::ajax_guard();
		$c = new RKW_Client();
		if ( ! $c->is_v21() ) { wp_send_json_error( 'فقط برای API نسخه 21.' ); }
		$out = array();
		$cr  = $c->call( 'GET', 'Retail/Api/DocumentStructure/SalesAreaService.svc/getSalesAreas' );
		if ( is_wp_error( $cr ) ) { wp_send_json_error( $cr->get_error_message() ); }
		$t = array();
		foreach ( (array) $cr as $r ) { $t[] = ( isset( $r['salesAreaID'] ) ? $r['salesAreaID'] : '?' ) . ':' . ( isset( $r['salesAreaName'] ) ? $r['salesAreaName'] : '' ); }
		$out[] = 'حوزه‌های فروش → ' . implode( '، ', $t );
		foreach ( array( 1 => 'سیاست تسویه فاکتور', 2 => 'سیاست تسویه سفارش' ) as $type => $label ) {
			$r = $c->settlement_policies21( $type );
			if ( is_wp_error( $r ) ) { $out[] = $label . ': ' . $r->get_error_message(); continue; }
			$t = array();
			foreach ( (array) $r as $p ) {
				$keys = array();
				foreach ( (array) ( isset( $p['settlementMethodGroups'] ) ? $p['settlementMethodGroups'] : array() ) as $g ) {
					foreach ( (array) ( isset( $g['settlementMethods'] ) ? $g['settlementMethods'] : array() ) as $m ) {
						if ( isset( $m['settlementNatureKey'] ) ) { $keys[] = $m['settlementNatureKey']; }
					}
				}
				$t[] = ( isset( $p['settlementPolicyID'] ) ? $p['settlementPolicyID'] : '?' ) . ':' . ( isset( $p['settlementPolicyName'] ) ? $p['settlementPolicyName'] : '' ) . ( $keys ? ' [' . implode( '/', array_unique( $keys ) ) . ']' : '' );
			}
			$out[] = $label . ' → ' . implode( '، ', $t );
		}
		foreach ( array( 1 => 'الگوی فاکتور', 2 => 'الگوی سفارش' ) as $type => $label ) {
			$r = $c->default_pattern21( $type );
			if ( is_wp_error( $r ) ) { $out[] = $label . ': ' . $r->get_error_message(); continue; }
			$out[] = $label . ' → ' . ( isset( $r['id'] ) ? $r['id'] : '?' ) . ':' . ( isset( $r['title'] ) ? $r['title'] : '' );
		}
		wp_send_json_success( implode( "\n", $out ) );
	}

	public static function ajax_step() {
		self::ajax_guard();
		$r = RKW_Sync::step( ! empty( $_POST['reset'] ) );
		if ( is_wp_error( $r ) ) { wp_send_json_error( $r->get_error_message() ); }
		wp_send_json_success( $r );
	}

	/* ---------- ابزارهای فرم ---------- */

	private static function row( $label, $html, $desc = '' ) {
		echo '<tr><th scope="row"><label>' . esc_html( $label ) . '</label></th><td>' . $html . ( $desc ? '<p class="description">' . esc_html( $desc ) . '</p>' : '' ) . '</td></tr>';
	}

	private static function text( $k, $label, $s, $desc = '', $type = 'text', $ltr = true ) {
		$val  = ( 'password' === $type ) ? '' : $s[ $k ];
		$ph   = ( 'password' === $type && ! empty( $s['password_enc'] ) ) ? ' placeholder="•••••• (بدون تغییر)" autocomplete="new-password"' : '';
		$html = '<input type="' . esc_attr( $type ) . '" name="rkw[' . esc_attr( $k ) . ']" value="' . esc_attr( $val ) . '" class="regular-text"' . $ph . ( 'number' === $type ? ' step="any"' : '' ) . ( $ltr ? ' style="direction:ltr;text-align:left"' : '' ) . '>';
		self::row( $label, $html, $desc );
	}

	private static function check( $k, $label, $s, $desc = '' ) {
		self::row( $label, '<label><input type="checkbox" name="rkw[' . esc_attr( $k ) . ']" value="1" ' . checked( $s[ $k ], 1, false ) . '> فعال</label>', $desc );
	}

	private static function select( $k, $label, $s, $opts, $desc = '' ) {
		$h = '<select name="rkw[' . esc_attr( $k ) . ']">';
		foreach ( $opts as $v => $l ) { $h .= '<option value="' . esc_attr( $v ) . '" ' . selected( (string) $s[ $k ], (string) $v, false ) . '>' . esc_html( $l ) . '</option>'; }
		self::row( $label, $h . '</select>', $desc );
	}

	private static function form_open( $tab ) {
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="rkw_save"><input type="hidden" name="tab" value="' . esc_attr( $tab ) . '">';
		wp_nonce_field( 'rkw_save' );
		echo '<table class="form-table" role="presentation">';
	}

	private static function form_close() {
		echo '</table>';
		submit_button( 'ذخیره تنظیمات' );
		echo '</form>';
	}

	/* ---------- صفحه ---------- */

	public static function page() {
		if ( ! current_user_can( self::CAP ) ) { return; }
		$s    = rkw_settings();
		$tabs = array( 'dashboard' => 'داشبورد', 'connection' => 'اتصال', 'catalog' => 'همگام‌سازی کالا و موجودی', 'orders' => 'سفارش‌ها', 'log' => 'گزارش', 'retention' => 'نگهداری اطلاعات' );
		$tab  = isset( $_GET['tab'] ) ? sanitize_key( $_GET['tab'] ) : 'dashboard';
		if ( ! isset( $tabs[ $tab ] ) ) { $tab = 'connection'; }
		$nonce = wp_create_nonce( 'rkw_ajax' );

		echo '<div class="wrap rkw-admin" dir="rtl"><div class="rkw-hero"><h1>کاسبی راهکاران</h1><p>مدیریت یکپارچه فروشگاه، موجودی و سفارش‌ها</p></div>';
		if ( ! empty( $_GET['saved'] ) ) { echo '<div class="notice notice-success is-dismissible"><p>تنظیمات ذخیره شد.</p></div>'; }
		echo '<style>.rkw-admin{max-width:1250px;font-family:inherit}.rkw-hero{background:linear-gradient(115deg,#152b4b,#2667a8);padding:30px;border-radius:16px;color:white;margin:18px 0}.rkw-hero h1{color:white;font-size:27px;margin:0 0 10px}.rkw-hero p{color:#e4edf9;margin:0}.rkw-admin .nav-tab-wrapper{border:0;display:flex;gap:8px;flex-wrap:wrap;margin:20px 0}.rkw-admin .nav-tab{border:1px solid #dbe3ef;border-radius:9px;background:white;padding:10px 17px;margin:0}.rkw-admin .nav-tab-active{background:#e7f0ff;border-color:#8bb8ed;color:#134c91}.rkw-cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:16px;margin:22px 0}.rkw-card,.rkw-panel{background:#fff;border:1px solid #e1e7ef;border-radius:14px;padding:23px;box-shadow:0 5px 20px #142c4710}.rkw-card span{display:block;color:#64748b}.rkw-card strong{display:block;font-size:27px;margin-top:12px;color:#173f71}.rkw-panel{margin:16px 0}.rkw-panel h2{margin-top:0}.rkw-events li{padding:10px;border-bottom:1px solid #eef1f5;overflow-wrap:anywhere}.rkw-admin .form-table{background:#fff;border-radius:12px}.rkw-admin .button{border-radius:7px}</style>';
		echo '<h2 class="nav-tab-wrapper">';
		foreach ( $tabs as $k => $l ) {
			echo '<a class="nav-tab' . ( $k === $tab ? ' nav-tab-active' : '' ) . '" href="' . esc_url( admin_url( 'admin.php?page=rkw&tab=' . $k ) ) . '">' . esc_html( $l ) . '</a>';
		}
		echo '</h2>';

		if ( 'dashboard' === $tab ) {
            $last = get_option( RKW_Sync::STATS, array() );
            $log = RKW_Log::all();
            $metrics = array(
                'نسخه رابط' => 'v21' === $s['api'] ? '۲۱' : '۱۹',
                'وضعیت همگام‌سازی' => 'off' === $s['cron_interval'] ? 'دستی' : 'زمان‌بندی‌شده',
                'کالاهای بررسی‌شده' => isset($last['processed']) ? (int)$last['processed'] : '—',
                'خطاهای آخرین اجرا' => isset($last['errors']) ? (int)$last['errors'] : '—',
            );
            echo '<section class="rkw-cards">';
            foreach ($metrics as $label => $value) {
                echo '<div class="rkw-card"><span>'.esc_html($label).'</span><strong>'.esc_html($value).'</strong></div>';
            }
            echo '</section><div class="rkw-panel"><h2>مرکز عملیات</h2><p>برای راه‌اندازی، ابتدا اتصال را تنظیم و آزمایش کنید؛ سپس همگام‌سازی را اجرا کنید.</p>';
            echo '<p><a class="button button-primary" href="'.esc_url(admin_url('admin.php?page=rkw&tab=connection')).'">تنظیم اتصال</a> <a class="button" href="'.esc_url(admin_url('admin.php?page=rkw&tab=catalog')).'">مدیریت همگام‌سازی</a> <a class="button" href="'.esc_url(admin_url('admin.php?page=rkw&tab=orders')).'">سفارش‌ها</a></p></div>';
            echo '<div class="rkw-panel"><h2>ماژول‌های مدیریتی راهکاران</h2><p>';
            foreach(array('stores'=>'انبارها','customers'=>'مشتریان','products'=>'محصولات','policies'=>'سیاست‌های پرداخت','invoices'=>'فاکتورهای فروش') as $key=>$label){echo '<a class="button" style="margin:4px" href="'.esc_url(admin_url('admin.php?page=rkw-'.$key)).'">'.esc_html($label).'</a> ';}
            echo '</p></div>';
            echo '<div class="rkw-panel rkwlog-recent"><div class="rkwlog-recent-header"><div><h2>آخرین رویدادها</h2><p>خلاصه فعالیت‌های اخیر؛ برای بررسی جزئیات، روی «نمایش اطلاعات» بزنید.</p></div><a class="button" href="' . esc_url( admin_url( 'admin.php?page=rkw&tab=log' ) ) . '">مشاهده همه گزارش‌ها</a></div>';
            $recent = array_slice( $log, 0, 6 );
            $notice = isset( $_GET['rkw_notice'] ) ? sanitize_key( wp_unslash( $_GET['rkw_notice'] ) ) : '';
            if ( 'deleted' === $notice ) { echo '<div class="notice notice-success inline"><p>رویداد انتخاب‌شده حذف شد.</p></div>'; }
            if ( 'missing' === $notice ) { echo '<div class="notice notice-warning inline"><p>رویداد مورد نظر پیدا نشد.</p></div>'; }
            if ( ! $recent ) {
                echo '<div class="rkwlog-empty"><strong>هنوز رویدادی ثبت نشده است.</strong>پس از شروع فعالیت، گزارش‌های جدید اینجا نمایش داده می‌شوند.</div>';
            } else {
                $level_labels = array( 'info' => 'اطلاع‌رسانی', 'warn' => 'هشدار', 'error' => 'خطا', 'debug' => 'عیب‌یابی' );
                echo '<div class="rkwlog-table-area"><table class="rkwlog-table"><thead><tr><th scope="col">تاریخ و ساعت</th><th scope="col">نوع رویداد</th><th scope="col">عنوان / خلاصه</th><th scope="col">عملیات</th></tr></thead><tbody>';
                foreach ( $recent as $entry ) {
                    $id = 'rkwlog-recent-' . sanitize_html_class( (string) $entry['id'] );
                    $label = isset( $level_labels[ $entry['level'] ] ) ? $level_labels[ $entry['level'] ] : $entry['level'];
                    $preview = self::log_summary( $entry['message'] );
                    echo '<tr><td class="rkwlog-time">' . esc_html( $entry['date'] ) . '</td>';
                    echo '<td><span class="rkwlog-level rkwlog-level--' . esc_attr( sanitize_html_class( $entry['level'] ) ) . '">' . esc_html( $label ) . '</span></td>';
                    echo '<td><span class="rkwlog-summary" title="' . esc_attr( $preview ) . '">' . esc_html( $preview ) . '</span></td>';
                    echo '<td><div class="rkwlog-buttons"><button type="button" class="button rkwlog-view" data-rkwlog-source="' . esc_attr( $id ) . '" aria-controls="rkwlog-modal" aria-haspopup="dialog">نمایش اطلاعات</button>';
                    self::log_action_form( 'rkw_delete_log', 'حذف', 'rkw_delete_log', array( 'log_id' => $entry['id'], 'rkw_return' => 'dashboard' ), 'این رویداد حذف شود؟', 'rkwlog-delete' );
                    echo '</div></td></tr>';
                }
                echo '</tbody></table></div>';
                foreach ( $recent as $entry ) { self::render_log_source( 'rkwlog-recent-' . sanitize_html_class( (string) $entry['id'] ), $entry ); }
            }
            echo '</div>';
            self::render_log_modal();
        }

		if ( 'connection' === $tab ) {
			self::form_open( 'connection' );
			self::select( 'api', 'نسخه API', $s, array( 'v21' => 'راهکاران ۲۱ (Retail/Api) — پیشنهادی', 'v19' => 'راهکاران ۱۹ (ESales.svc)' ), 'ارسال مشتری و سفارش فقط در نسخه ۲۱ فعال است.' );
			self::select( 'protocol', 'پروتکل', $s, array( 'http' => 'http', 'https' => 'https' ) );
			self::text( 'ip', 'آی‌پی یا دامنه سرور', $s, 'مثال: 192.168.1.10  (بدون http و بدون مسیر)' );
			self::text( 'port', 'پورت (اختیاری)', $s );
			self::text( 'cluster', 'کلاستر', $s, 'معمولاً sg  — اگر آدرس سرویس‌ها بدون کلاستر است خالی بگذارید.' );
			self::text( 'username', 'نام کاربری (کاربر فروشگاه اینترنتی)', $s );
			self::text( 'password', 'رمز عبور', $s, 'رمز به‌صورت رمزنگاری‌شده ذخیره می‌شود.', 'password' );
			self::text( 'machine_name', 'نام ماشین/کامپیوتر صندوق', $s, 'نام ماشین تعریف‌شده در راهکاران؛ نوع ورود صندوق مطابق قرارداد سند است. پس از واردکردن، ابتدا تنظیمات را ذخیره و سپس تست اتصال را اجرا کنید.' );
			self::text( 'timeout', 'تایم‌اوت (ثانیه)', $s, '', 'number' );
			self::check( 'verify_ssl', 'بررسی گواهی SSL', $s );
			self::check( 'debug', 'حالت عیب‌یابی', $s, 'درخواست و پاسخ سرویس‌ها در گزارش ثبت می‌شود (فقط موقع نیاز روشن کنید).' );
			self::form_close();
			echo '<p><button type="button" class="button" id="rkw-test">تست اتصال</button> <span id="rkw-test-out"></span></p>';
		}

		if ( 'catalog' === $tab ) {
			self::form_open( 'catalog' );
			self::select( 'key_field', 'کلید تطبیق با SKU', $s, array( 'code' => 'کد/بارکد کالا (productNumber)', 'id' => 'شناسه داخلی راهکاران (productId)' ), 'شناسه مستقل راهکارانِ ذخیره‌شده روی محصول یا متغیر اولویت دارد. اگر اتصال مستقلی وجود نداشته باشد، SKU طبق این گزینه تطبیق داده می‌شود.' );
			self::text( 'store_ids', 'شناسه انبارها', $s, 'با کاما جدا کنید (مثال 1,3). در نسخه ۲۱: موجودی این انبارها جمع زده می‌شود؛ خالی = همه‌ی انبارها. در نسخه ۱۹: اولین انبار.' );
			self::text( 'shop_id', 'شناسه فروشگاه (نسخه ۱۹)', $s, '', 'number' );
			self::text( 'currency_id', 'شناسه ارز', $s, '', 'number' );
			self::text( 'customer_id', 'مشتری قیمت‌گذاری (نسخه ۱۹)', $s, '0 = قیمت عمومی', 'number' );
			self::text( 'sales_area_id', 'حوزه فروش قیمت‌گذاری (نسخه ۱۹)', $s, '', 'number' );
			self::select( 'price_field', 'فیلد قیمت (نسخه ۱۹)', $s, array( 'fee' => 'fee', 'consumerFee' => 'consumerFee', 'netOfFee' => 'netOfFee' ) );
			self::text( 'price_divisor', 'ضریب تقسیم قیمت', $s, 'ووکامرس تومان / راهکاران ریال: 10؛ واحد یکسان: 1؛ ووکامرس ریال / راهکاران تومان: 0.1. در ارسال سفارش، قیمت‌ها در همین عدد ضرب می‌شوند.', 'number' );
			self::check( 'sync_stock', 'همگام‌سازی موجودی', $s );
			self::check( 'product_view_refresh', 'دریافت قیمت و موجودی هنگام مشاهده محصول، پس از ۵ دقیقه (نسخه ۲۱)', $s, 'در بازشدن صفحه محصول، داده‌های قدیمی‌تر از پنج دقیقه با درخواست جداگانه از راهکاران دریافت می‌شوند؛ متغیرها با شناسه مستقل خود و به‌ترتیب بررسی می‌شوند. به کرون وابسته نیست. پس از نصب، کش صفحات سایت را یک‌بار پاک کنید تا اسکریپت جدید بارگذاری شود. محافظ قبل از پرداخت نیز روشن بماند.' );
			self::check( 'checkout_stock_guard', 'بررسی زنده موجودی راهکاران قبل از پرداخت (نسخه ۲۱)', $s, 'برای کالاهای متصل با مدیریت موجودی و پیش‌خرید غیرمجاز، انبار سند قبل از پرداخت اولیه و مجدد بررسی می‌شود؛ اگر انبار سند تعیین نشده، یک انبار کالا باید انتخاب شده باشد. کمبود موجودی یا پاسخ نامعتبر راهکاران، ادامه پرداخت را متوقف می‌کند. این بررسی به کرون وابسته نیست و موجودی فهرست محصولات را تغییر نمی‌دهد.' );
			self::check( 'sync_price', 'همگام‌سازی قیمت', $s );
			self::check( 'sync_sale', 'قیمت حراج از تخفیف راهکاران (نسخه ۱۹)', $s );
			self::check( 'sync_name', 'بروزرسانی نام محصولات موجود', $s );
			self::check( 'create_missing', 'ساخت محصول جدید (پیش‌نویس) برای کالاهای راهکاران که در سایت نیستند', $s );
			self::check( 'auto_product_on_save', 'بروزرسانی خودکار هنگام انتشار/ذخیره محصول و همه متغیرهای آن', $s, 'شناسه مستقل راهکاران را برای محصول ساده یا هر متغیر وارد کنید. ذخیره محصول اصلی، هر متغیر فعال را با شناسه خودش دریافت می‌کند. انتشار زمان‌بندی‌شده، REST و ورود CSV نیز پوشش داده می‌شوند؛ دریافت در همان درخواست انجام می‌شود و منتظر همگام‌سازی دوره‌ای نمی‌ماند. نتیجه آخرین دریافت کنار شناسه هر متغیر نمایش داده می‌شود.' );
			self::text( 'batch_size', 'تعداد کالا در هر دسته', $s, '', 'number' );
			self::text( 'page_start', 'شماره صفحه اول (نسخه ۲۱)', $s, 'اگر صفحه‌بندی سرور از 0 شروع می‌شود 0 بگذارید، در غیر این صورت 1.', 'number' );
			self::select( 'cron_interval', 'زمان‌بندی خودکار', $s, array( 'off' => 'غیرفعال', 'rkw_1min' => 'هر یک دقیقه (سریع)', 'rkw_5min' => 'هر پنج دقیقه', 'rkw_15min' => 'هر ۱۵ دقیقه', 'hourly' => 'ساعتی', 'twicedaily' => 'دو بار در روز', 'daily' => 'روزانه' ) );
			self::form_close();

			echo '<section class="rkw-panel"><h2>وضعیت به‌روزرسانی خودکار</h2><pre id="rkw-catalog-status" style="white-space:pre-wrap;font:inherit;line-height:2">' . esc_html( RKW_Sync_Runner::status() ) . '</pre></section>';
			echo '<h2>اجرای دستی</h2><p><button type="button" class="button button-primary" id="rkw-sync">شروع همگام‌سازی</button> <span id="rkw-sync-out"></span></p>';
			$last = get_option( RKW_Sync::STATS );
			if ( is_array( $last ) ) {
				printf( '<p>آخرین اجرا (%s): %d بررسی، %d ایجاد، %d بروزرسانی، %d نادیده، %d خطا</p>', esc_html( isset( $last['finished'] ) ? $last['finished'] : '' ), $last['processed'], $last['created'], $last['updated'], $last['skipped'], $last['errors'] );
			}
		}

		if ( 'orders' === $tab ) {
			if ( 'v21' !== $s['api'] ) { echo '<div class="notice notice-warning inline"><p>ارسال سفارش فقط با API نسخه ۲۱ کار می‌کند.</p></div>'; }
			self::form_open( 'orders' );
			self::check( 'order_enabled', 'ارسال خودکار سفارش‌ها به راهکاران', $s );
			self::select( 'document_contract', 'قرارداد ارسال سند و ورود صندوق', $s, array( 'legacy_esales' => 'سازگار با wp-rahkaran (ESales/invoice و CashierLogin)', 'v21' => 'قرارداد جدید نسخه ۲۱ (SaveInvoice و DesktopCashierLogin)' ) );
			self::select( 'order_mode', 'نوع سند', $s, array( 'salesorder' => 'سفارش فروش', 'invoice' => 'فاکتور فروش' ) );
			self::text( 'order_statuses', 'وضعیت‌های فعال‌کننده', $s, 'کد وضعیت‌های ووکامرس بدون wc- و با کاما؛ مثال: processing,completed', 'text' );
			echo '<tr><th colspan="2"><div class="rkw-policy-heading"><h2>شناسه‌های سیاست پرداخت و تسویه</h2><p>شناسه‌ها و روش‌های پرداخت مستقیماً از راهکاران دریافت می‌شوند. می‌توانید سیاست فاکتور و سفارش فروش را جداگانه انتخاب کنید؛ هر دو مقدار ذخیره می‌شوند. شناسه عددی قابل ورود دستی است.</p><button type="button" class="button button-secondary" id="rkw-load-policy-catalog">دریافت / به‌روزرسانی شناسه‌ها از راهکاران</button> <span id="rkw-policy-feedback" role="status" aria-live="polite"></span><div id="rkw-policy-directory" aria-live="polite"></div></div></th></tr>';
			self::policy_picker( 'invoice_settlement_id', 'شناسه سیاست پرداخت فاکتور فروش', $s, 'invoice', 'برای ارسال فاکتور فروش. سیاست باید نوع دریافت انتخاب‌شده را پشتیبانی کند.' );
			self::policy_picker( 'order_settlement_id', 'شناسه سیاست پرداخت سفارش فروش', $s, 'order', 'برای ارسال سفارش فروش، مستقل از سیاست فاکتور.' );
			self::text( 'settlement_id', 'شناسه سیاست تسویه قدیمی (جایگزین)', $s, 'برای حفظ سازگاری با تنظیمات قبلی؛ تنها زمانی استفاده می‌شود که شناسه اختصاصی نوع سند صفر باشد.', 'number' );
			self::policy_picker( 'invoice_doc_pattern_id', 'شناسه الگوی فاکتور فروش', $s, 'pattern_invoice', 'الگوی سند فاکتور را جداگانه تعیین کنید. در صورت نبود الگوی پیش‌فرض، شناسه را دستی وارد کنید.' );
			self::policy_picker( 'order_doc_pattern_id', 'شناسه الگوی سفارش فروش', $s, 'pattern_order', 'الگوی سند سفارش فروش را مستقل تعیین کنید.' );
			self::text( 'doc_pattern_id', 'شناسه الگوی سند قدیمی (جایگزین)', $s, 'اگر برای نوع سند، الگوی جداگانه تعیین نشده باشد از این شناسه استفاده می‌شود.', 'number' );
			self::text( 'inventory_id', 'شناسه انبار سند', $s, '', 'number' );
			echo '<tr><th scope="row">انتخاب انبار از راهکاران</th><td><select data-rkw-for="inventory_id" data-rkw-type="stores" class="rkw-catalog-choice"><option value="">از فهرست انبارها…</option></select></td></tr>';
			self::text( 'sales_area_ord', 'شناسه حوزه فروش (اختیاری)', $s, '', 'number' );
			echo '<tr><th scope="row">انتخاب حوزه فروش از راهکاران</th><td><select data-rkw-for="sales_area_ord" data-rkw-type="areas" class="rkw-catalog-choice"><option value="">از فهرست حوزه‌های فروش…</option></select></td></tr>';
			self::text( 'receipt_key', 'نوع پرداخت / دریافت پیش‌فرض راهکاران (key)', $s, 'کلید نوع دریافت باید با سیاست انتخاب‌شده سازگار باشد.' );
			echo '<tr><th scope="row">انتخاب نوع دریافت</th><td><select class="rkw-catalog-choice" data-rkw-for="receipt_key" data-rkw-type="methods"><option value="">روش‌های موجود در سیاست انتخابی…</option></select><p class="description" id="rkw-receipt-warning" role="status"></p></td></tr>';
			self::text( 'bank_account_ref', 'شناسه بانک راهکاران (bankAccountRef)', $s, 'برای EReceipt / BankReceipt. صفر = ارسال نشود.', 'number' );
			echo '<tr><th scope="row">نحوه ارسال نوع دریافت الکترونیک</th><td><select name="rkw[e_receipt_mode]">';
			foreach ( array( 'omit' => 'سازگار با افزونه قدیمی — eReceiptType ارسال نشود (پیشنهادی)', 'explicit' => 'ارسال eReceiptType مطابق مقدار تنظیم‌شده' ) as $mode => $caption ) {
				echo '<option value="' . esc_attr( $mode ) . '"' . selected( isset( $s['e_receipt_mode'] ) && 'explicit' === $s['e_receipt_mode'] ? 'explicit' : 'omit', $mode, false ) . '>' . esc_html( $caption ) . '</option>';
			}
			echo '</select><p class="description">در سرویس SaveInvoice راهکاران نوع دریافت الکترونیک باید با تنظیم واقعی سرور منطبق باشد. نمونه eReceiptType=1 در مستند مربوط به سرویس جداگانه saveKioskInvoice است و نباید برای همه سرورها فرض شود. این گزینه در حالت پیش‌فرض ارسال نمی‌شود.</p></td></tr>';
			self::text( 'e_receipt_type', 'شناسه اختیاری eReceiptType', $s, 'فقط در حالت «ارسال eReceiptType» استفاده می‌شود. شناسه بانک (bankAccountRef) را اینجا تکرار نکنید مگر راهکاران جداگانه آن را تأیید کرده باشد.' );
			echo '<tr><th scope="row">محل ثبت دریافت بانکی</th><td><input type="hidden" name="rkw[electronic_route]" value="receipts"><strong>' . ( 'legacy_esales' === $s['document_contract'] ? 'payments — قرارداد wp-rahkaran / ESales' : 'receipts — قرارداد جدید SaveInvoice نسخه ۲۱' ) . '</strong><p class="description">در قرارداد قدیمی وجه مشتری در payments و در SaveInvoice جدید در receipts ثبت می‌شود. این دو ساختار قابل جابه‌جایی نیستند. در حالت قدیمی eReceiptType مطابق افزونه قبلی حذف می‌شود؛ شناسه بانک و سیاست تسویه از تنظیمات همان درگاه خوانده می‌شوند.</p></td></tr>';
			RKW_Payment::render_settings( $s );
			echo '<tr><th scope="row">هزینه حمل و هزینه‌های اضافی</th><td>هزینه حمل و هزینه‌های جانبی ووکامرس جزء جمع کل سفارش هستند، اما برای ثبت در فاکتور راهکاران باید سیاست فروش متناظر داشته باشند. <a href="' . esc_url( admin_url( 'admin.php?page=rkw-extensions' ) ) . '">تنظیم سیاست حمل و هزینه‌های جانبی در امکانات تکمیلی</a>. برای تشخیص اختلاف مبلغ، «بررسی بدون ارسال» را اجرا کنید.</td></tr>';
			self::text( 'loyalty_id', 'شناسه برنامه وفاداری (اختیاری)', $s, '', 'number' );
			self::text( 'coupon_type_id', 'شناسه نوع بن سازمانی پیش‌فرض', $s, 'فقط برای ThirdPartyCoupon؛ شناسه را از صفحه انواع بن سازمانی دریافت کنید. این شناسه با سیاست تسویه متفاوت است.', 'number' );
			self::text( 'credit_receipt_key', 'کلید تسویه نسیه در قرارداد قدیمی', $s, 'فقط برای ESales؛ مقدار واقعی سیاست نسیه افزونه قبلی، بدون مقدار فرضی.' );
			self::text( 'default_unit_id', 'شناسه واحد پیش‌فرض کالا (مهاجرت)', $s, 'فقط وقتی واحد کالا ذخیره نشده است؛ شناسه واقعی راهکاران.', 'number' );
			self::text( 'item_discount_policy_id', 'سیاست تخفیف ردیف کالا', $s, 'اختیاری؛ برای انتقال تخفیف کوپن به سیاست کاهش ردیف.', 'number' );
			echo '<tr><th>کنترل مبلغ نزد راهکاران</th><td><label><input type="checkbox" name="rkw[invoice_preflight]" value="1" ' . checked( $s['invoice_preflight'], 1, false ) . '> اجرای calculateAmount پیش از ثبت فاکتور در قرارداد جدید ۲۱</label><p class="description">اگر جمع محاسبه‌شده توسط سرور با مبلغ سند برابر نباشد، SaveInvoice اجرا نمی‌شود.</p></td></tr>';
			echo '<tr><th>تخصیص مشتری</th><td><select name="rkw[customer_mode]"><option value="individual" ' . selected( $s['customer_mode'], 'individual', false ) . '>مشتری هر سفارش</option><option value="default" ' . selected( $s['customer_mode'], 'default', false ) . '>همیشه مشتری پیش‌فرض (رفتار قابل انتخاب قدیمی)</option></select></td></tr>';
			self::text( 'national_key', 'کلید متای کد ملی', $s, 'نام متای سفارش/کاربر که کد ملی در آن ذخیره می‌شود (برای ساخت مشتری لازم است).' );
			self::check( 'fida_fallback', 'اگر کد ملی نبود، شماره موبایل به‌عنوان «ثبت‌نام فیدا» ثبت شود', $s );
			self::text( 'fallback_cust', 'شناسه مشتری پیش‌فرض', $s, 'اگر ساخت مشتری ممکن نشد، سند با این مشتری ثبت می‌شود (0 = خطا).', 'number' );
			self::form_close();
			echo '<p><button type="button" class="button" id="rkw-discover">دریافت شناسه‌ها از راهکاران</button></p><pre id="rkw-discover-out" style="direction:rtl;white-space:pre-wrap;background:#fff;padding:10px;border:1px solid #ccd0d4;max-width:900px;display:none"></pre>';
			echo '<p class="description">ارسال دستی یا مجدد: در صفحه‌ی ویرایش سفارش، از «اقدامات سفارش» گزینه‌ی «ارسال به راهکاران».</p>';
			echo '<section class="rkw-panel" style="max-width:960px"><h2>بررسی تنظیمات پرداخت سفارش (بدون ارسال)</h2>';
			echo '<p>شماره سفارش ووکامرس را وارد کنید تا مشخص شود افزونه برای همان سفارش از کدام قانون درگاه، سیاست تسویه، نوع دریافت، شناسه بانک و eReceiptType استفاده خواهد کرد. <strong>این دکمه هیچ درخواستی برای ثبت فاکتور به راهکاران نمی‌فرستد.</strong></p>';
			echo '<p><label for="rkw-payment-order-id">شناسه سفارش ووکامرس:</label> <input id="rkw-payment-order-id" type="number" min="1" class="regular-text" inputmode="numeric" placeholder="برای مثال 236438"> <button id="rkw-payment-diagnose" type="button" class="button button-primary">بررسی بدون ارسال</button> <button id="rkw-invoice-calculate" type="button" class="button">محاسبه مالی در راهکاران (بدون ثبت)</button> <button id="rkw-document-probe" type="button" class="button">بررسی دقیق تسویه و کالا (بدون ثبت)</button></p>';
			echo '<p class="description">«بررسی دقیق» تعریف زنده روش‌های تسویه در سیاست انتخاب‌شده، ویژگی‌های بن، کالا و موجودی انبار را مرحله‌ای می‌خواند. هر مرحله فقط اطلاعات دریافت می‌کند؛ هیچ فاکتور، مشتری یا محصولی ساخته نمی‌شود. این گزارش تأیید نهایی ثبت ESales نیست.</p>';
			echo '<pre id="rkw-payment-diagnose-output" role="status" aria-live="polite" dir="ltr" style="display:none;background:#f8fafc;border:1px solid #cbd5e1;padding:12px;max-height:440px;overflow:auto;white-space:pre-wrap;overflow-wrap:anywhere"></pre></section>';
			echo '<section class="rkw-panel" style="max-width:960px"><h2>بررسی سخت‌افزار صندوق (بدون ارسال فاکتور)</h2>';
			echo '<p>برای خطای «سخت افزار تعریف نشده است»، فهرست دستگاه‌های POS مرتبط با صندوق/فروشگاه فعلی را از راهکاران دریافت کنید. این بررسی هیچ فاکتوری صادر نمی‌کند، دستگاهی تعریف نمی‌کند و تنظیمات پرداخت را تغییر نمی‌دهد. برای پرداخت بانکی آنلاین الزام به وجود دستگاه فیزیکی هنوز تأیید نشده است.</p>';
			echo '<p><button type="button" class="button button-secondary" id="rkw-pos-diagnose">بررسی دستگاه‌های تعریف‌شده</button></p>';
			echo '<pre id="rkw-pos-diagnose-output" role="status" aria-live="polite" style="display:none;background:#f8fafc;border:1px solid #cbd5e1;padding:12px;max-height:420px;overflow:auto;white-space:pre-wrap;overflow-wrap:anywhere"></pre></section>';

		}

		if ( 'orders' === $tab ) {
			wp_enqueue_style( 'rkw-config-policies', plugins_url( 'assets/config-policies.css', RKW_FILE ), array(), RKW_VER );
			wp_enqueue_script( 'rkw-config-policies', plugins_url( 'assets/config-policies.js', RKW_FILE ), array(), RKW_VER, true );
			wp_localize_script( 'rkw-config-policies', 'rkwPolicyConfig', array(
				'ajax' => admin_url( 'admin-ajax.php' ),
				'nonce' => $nonce,
				'catalog' => RKW_Policy_Catalog::stored(),
			) );
		}
		if ( 'log' === $tab ) { self::render_log_page(); }
		if ( 'retention' === $tab ) { self::retention_page(); }
		echo '</div>';
		self::script( $nonce );
	}

	private static function script( $nonce ) {
		?>
		<script>
		(function(){
			var ajax = <?php echo wp_json_encode( admin_url( 'admin-ajax.php' ) ); ?>, nonce = <?php echo wp_json_encode( $nonce ); ?>, uiVersion = <?php echo wp_json_encode( RKW_VER ); ?>;
			function post(data){
				data._ajax_nonce = nonce;
				return fetch(ajax,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams(data)}).then(function(r){return r.json();});
			}
			var t=document.getElementById('rkw-test');
			if(t){t.onclick=function(){var o=document.getElementById('rkw-test-out');o.textContent='در حال اتصال...';o.style.color='';
				post({action:'rkw_test'}).then(function(r){o.textContent=r.data;o.style.color=r.success?'green':'red';}).catch(function(){o.textContent='خطای شبکه';o.style.color='red';});};}
			var d=document.getElementById('rkw-discover');
			if(d){d.onclick=function(){var o=document.getElementById('rkw-discover-out');o.style.display='block';o.textContent='در حال دریافت...';
				post({action:'rkw_discover'}).then(function(r){o.textContent=r.data;o.style.color=r.success?'':'red';}).catch(function(){o.textContent='خطای شبکه';});};}
			var diag=document.getElementById('rkw-payment-diagnose');
			if(diag){diag.onclick=function(){
				var id=document.getElementById('rkw-payment-order-id').value;
				var out=document.getElementById('rkw-payment-diagnose-output');
				out.style.display='block';out.textContent='در حال بررسی تنظیمات ذخیره‌شده؛ فاکتوری ارسال نمی‌شود...';
				if(!/^[1-9]\d*$/.test(id)){out.textContent='شناسه سفارش معتبر وارد کنید.';return;}
				post({action:'rkw_payment_diagnose',order_id:id,ui_version:uiVersion}).then(function(r){
					if(!r.success){out.textContent=(r.data&&r.data.message)||'خطا در بررسی سفارش';return;}
					var x=r.data;
					function displayAmount(value){return value == null ? 'نامشخص' : value;}
					var lines=[
						'نسخه فعال افزونه: '+(x.plugin_version||'نامشخص'),
						'افزونه قدیمی wp-rahkaran فعال است؟ '+(x.legacy_sender_status&&x.legacy_sender_status.plugin_active?'بله':'خیر'),
						'ارسال خودکار سفارش افزونه قدیمی فعال است؟ '+(x.legacy_sender_status&&x.legacy_sender_status.automatic_sender_active?'بله؛ پیش از ارسال از کاسبی غیرفعال شود':'خیر'),
						'سفارش ووکامرس: #'+x.order_id,
						'وضعیت واقعی ووکامرس: '+(x.woo_order_status||'نامشخص'),
						'واجد شرایط فهرست فاکتورهای فروش: '+(x.invoice_list_eligible?'بله':'خیر'),
						'موتور صف خودکار سفارش: '+(x.order_queue_engine==='woocommerce'?'ووکامرس':'وردپرس'),
						'کار در انتظار اجرای خودکار: '+(x.order_queue_pending?'بله':'خیر'),
						'شناسه واقعی درگاه سفارش: '+(x.payment_gateway_id||'نامشخص'),
						'عنوان روش پرداخت در سفارش: '+(x.payment_gateway_title||'نامشخص'),
						'منبع تنظیم تسویه فعلی: '+({default:'پیش‌فرض عمومی',gateway_rule:'قانون اختصاصی همین درگاه',credit_policy:'سیاست نسیه',unresolved:'متوقف به علت تنظیمات'}[x.mapping_source]||'نامشخص'),
						'تطبیق روش حمل (تنظیمات فعلی): '+JSON.stringify(x.shipping_mapping||{}),
						'درگاه در فهرست روش‌های پرداخت نسیه انتخاب شده؟ '+(x.credit_gateway_configured?'بله':'خیر'),
						'قانون اختصاصی برای این درگاه وجود دارد؟ '+(x.gateway_rule_configured?'بله':'خیر'),
						'قانون اختصاصی این درگاه اعمال می‌شود؟ '+(x.gateway_rule_matched?'بله':(x.configuration_error?'خیر؛ بررسی تنظیمات متوقف شد':(x.payment_mode==='credit'?'خیر؛ سیاست نسیه اعمال می‌شود':'خیر؛ از پیش‌فرض استفاده می‌شود'))),
						'تعداد قوانین منطبق: '+(x.matching_rules_count||0),
						'شناسه سیاست تسویه: '+(x.settlement_policy_id||'نامشخص'),
						'نوع دریافت: '+(x.receipt_key||(x.payment_mode==='credit'?'نسیه/بدون دریافت':'نامشخص؛ بررسی تنظیمات متوقف شد')),
						'couponType بن سازمانی: '+(x.coupon_type_id||(x.configuration_error?'بررسی نشده':'ارسال نمی‌شود')),
						'نوع بن در آخرین فهرست دریافتی: '+({found_in_last_fetch:'وجود دارد؛ هنگام ارسال دوباره بررسی می‌شود',not_found_in_last_fetch:'وجود ندارد',not_fetched:'فهرست اتصال فعلی دریافت نشده',not_applicable:'برای این نوع دریافت کاربرد ندارد'}[x.coupon_type_catalog_status]||'بررسی نشده'),
						'شناسه بانک: '+(x.bank_account_ref||(x.configuration_error?'بررسی نشده':'وارد نشده')),
						'eReceiptType در درخواست: '+(x.e_receipt_type_value_sent==='NOT_SENT'?'ارسال نمی‌شود':(x.e_receipt_type_value_sent||'وارد نشده')),
						'محل اطلاعات پرداخت بانکی در SaveInvoice: '+(x.payment_container||'نامشخص'),
						'شماره تراکنش بانکی در سفارش ثبت شده؟ '+(x.transaction_id_present?'بله':'خیر'),
						'کلیدهای مشخصات پرداخت: '+((x.receipt_attr_keys||[]).join(', ')||(x.configuration_error?'بررسی نشده':'بدون دریافت')),
						'مبلغ کل سفارش به واحد راهکاران (تخمینی): '+displayAmount(x.woo_order_total_in_rahkaran_units),
						'جمع کالاها به واحد راهکاران: '+displayAmount(x.amount_breakdown&&x.amount_breakdown.items_total),
						'هزینه حمل (با مالیات): '+displayAmount(x.amount_breakdown&&x.amount_breakdown.shipping_total),
						'هزینه‌های جانبی: '+displayAmount(x.amount_breakdown&&x.amount_breakdown.other_fees_total),
						'مغایرت ناشی از سایر تعدیلات: '+displayAmount(x.amount_breakdown&&x.amount_breakdown.unexplained_total),
						'درگاه‌های دارای قانون: '+((x.configured_gateway_ids||[]).join(', ')||'هیچ‌کدام')
					];
					if(x.configuration_error){lines.push('خطای تنظیمات: '+x.configuration_error);}
					if(x.legacy_record_check_error){lines.push('خطای بررسی سوابق قدیمی: '+x.legacy_record_check_error);}
					if(x.legacy_records&&x.legacy_records.length){
						lines.push('سوابق افزونه قدیمی (صرف وجود رکورد، ثبت فاکتور را ثابت نمی‌کند):');
						x.legacy_records.slice(0,20).forEach(function(row){lines.push('رکورد #'+row.record_id+' | وضعیت: '+row.post_status+' | '+(row.invoice_id?'شناسه فاکتور: '+row.invoice_id:(row.invoice_id_recorded?'شناسه ذخیره‌شده قابل تأیید نیست':'شناسه فاکتور ذخیره نشده است')));});
					}
					if(x.warnings&&x.warnings.length){lines.push('هشدارها:');x.warnings.forEach(function(w){lines.push(' - '+w);});}
					lines.push('این بررسی هیچ فاکتوری صادر نکرده است.');
					out.textContent=lines.join('\n');out.dir='rtl';
				}).catch(function(){out.textContent='خطای اتصال AJAX؛ هیچ فاکتوری ارسال نشده است.';});
			};}
			var calc=document.getElementById('rkw-invoice-calculate');
			if(calc){calc.onclick=function(){
				var input=document.getElementById('rkw-payment-order-id'),out=document.getElementById('rkw-payment-diagnose-output');
				out.style.display='block';out.dir='rtl';
				if(!input.value||!/^[1-9][0-9]*$/.test(input.value)){out.textContent='شناسه سفارش معتبر وارد کنید.';return;}
				calc.disabled=true;out.textContent='در حال محاسبه مقایسه‌ای؛ هیچ فاکتوری ثبت نمی‌شود…';
				post({action:'rkw_invoice_calculation',order_id:input.value}).then(function(r){out.textContent=r.success&&r.data?r.data.text:((r.data&&r.data.message)||'محاسبه انجام نشد؛ فاکتوری ثبت نشد.');}).catch(function(){out.textContent='پاسخ محاسبه دریافت نشد؛ این درخواست برای ثبت فاکتور نبود.';}).finally(function(){calc.disabled=false;});
			};}
			var hw=document.getElementById('rkw-pos-diagnose');
			if(hw){hw.onclick=function(){
				var out=document.getElementById('rkw-pos-diagnose-output');
				out.style.display='block';out.textContent='در حال دریافت فهرست دستگاه‌ها؛ هیچ فاکتوری ارسال نمی‌شود...';hw.disabled=true;
				post({action:'rkw_pos_diagnose'}).then(function(r){
					if(!r.success){out.textContent=(r.data&&r.data.message)||'دریافت دستگاه‌ها ناموفق بود.';return;}
					var x=r.data, lines=['تعداد دستگاه‌های قابل مشاهده: '+(x.count||0)];
					(x.devices||[]).forEach(function(d,i){
						lines.push((i+1)+'. '+(d.DeviceTitle||'بدون عنوان')+' | شناسه: '+d.ID+' | شناسه دستگاه: '+d.DeviceRef+' | فروشگاه: '+d.RetailShopRef+' | مدل: '+(d.DeviceModelUniqueKey||'نامشخص'));
					});
					lines.push(x.note||'');lines.push('مقادیر تنظیمات فنی دستگاه نمایش داده نمی‌شوند.');
					out.textContent=lines.join('\n');
				}).catch(function(){out.textContent='خطای ارتباط AJAX؛ فاکتوری ارسال نشده است.';}).finally(function(){hw.disabled=false;});
			};}
			var b=document.getElementById('rkw-sync');
			var catalogStatus=document.getElementById('rkw-catalog-status');
			var catalogStatusBusy=false;
			if(catalogStatus){setInterval(function(){if(document.hidden||catalogStatusBusy){return;}catalogStatusBusy=true;post({action:'rkw_catalog_status'}).then(function(r){catalogStatus.textContent=r.success&&r.data?r.data.text:'دریافت وضعیت صف ناموفق بود؛ صفحه را تازه‌سازی کنید.';}).catch(function(){catalogStatus.textContent='ارتباط برای دریافت وضعیت صف برقرار نشد؛ بررسی دوباره انجام می‌شود.';}).finally(function(){catalogStatusBusy=false;});},5000);}
			if(b){b.onclick=function(){
				var o=document.getElementById('rkw-sync-out');b.disabled=true;
				function run(reset){
					post({action:'rkw_step',reset:reset?1:''}).then(function(r){
						if(!r.success){o.textContent='خطا: '+r.data;o.style.color='red';b.disabled=false;return;}
						var x=r.data;o.style.color='';
						o.textContent='بررسی‌شده: '+x.processed+' | ایجاد: '+x.created+' | بروزرسانی: '+x.updated+' | نادیده: '+x.skipped+' | خطا: '+x.errors;
						if(x.done){o.textContent+=' ✔ پایان';b.disabled=false;}else{run(false);}
					}).catch(function(){o.textContent='خطای شبکه';b.disabled=false;});
				}
				run(true);
			};}
		})();
		</script>
		<?php
	}
}
