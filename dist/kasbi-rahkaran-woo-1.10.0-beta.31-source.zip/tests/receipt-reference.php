<?php
require __DIR__.'/bootstrap.php';
function reference_reset(){reset_case();$GLOBALS['test_nonce']=true;$GLOBALS['test_capability']=true;$_POST=['invoice_id'=>'30577','contract'=>'legacy_esales'];}
function reference_ajax(){try{RKW_Document_Probe::ajax_reference();throw new RuntimeException('missing JSON');}catch(TestJSON $r){return$r;}}
function reference_invoice(){return['id'=>30577,'number'=>917,'settlementPolicyId'=>45,'customerName'=>'PRIVATE CUSTOMER','description'=>'PRIVATE ADDRESS','receipts'=>[['settlementNature'=>'ThirdPartyCoupon','amount'=>36950000,'details'=>['count'=>1,'couponType'=>5,'number'=>'PRIVATE SERIAL','cardNumber'=>'PRIVATE CARD','description'=>'PRIVATE DESCRIPTION','token'=>'PRIVATE TOKEN','customerId'=>45678]]],'payments'=>[]];}
$tests=[];
$tests['both readers use exactly one fixed GET and preserve all local financial state']=function(){
 foreach(['legacy_esales','v21']as$contract){reference_reset();$_POST['contract']=$contract;$before=$GLOBALS['options'];$GLOBALS['http_handler']=function($u,$a)use($contract){check($a['method']==='GET'&&!isset($a['body']));check(strpos($u,$contract==='legacy_esales'?'/Services/Retail/ESales.svc/invoice?id=30577':'/Retail/Api/RetailDocuments/InvoiceService.svc/GetInvoice?invoiceId=30577')!==false);return response(reference_invoice());};$r=reference_ajax();check($r->success&&$r->data['report']['identity_verified']);check($r->data['report']['third_party_coupon_found']);check($r->data['report']['response_is_post_contract']===false);check(count($GLOBALS['http_calls'])===1&&$before===$GLOBALS['options']);}
};
$tests['only voucher type and count values are shown while serials customer and bank data are omitted']=function(){
 $GLOBALS['http_handler']=fn()=>response(reference_invoice());$r=reference_ajax();$text=json_encode($r->data);check(strpos($text,'PRIVATE')===false&&strpos($text,'45678')===false);$fields=$r->data['report']['receipts'][0]['shape']['fields'];$details=array_values(array_filter($fields,fn($f)=>$f['key']==='details'))[0]['shape']['fields'];check($details[0]['numeric_value']===1.0&&$details[1]['numeric_value']===5.0);check(!isset($details[2]['numeric_value']));
};
$tests['legacy envelopes and attribute lists retain shape without turning response fields into a write']=function(){
 $raw=['document'=>['id'=>30577,'settlementPolicyId'=>45],'payments'=>[['key'=>'ThirdPartyCoupon','amount'=>100,'attr'=>[['attributeKey'=>'Count','value'=>'2'],['attributeKey'=>'ThirdPartyCouponType','value'=>['Id'=>5,'title'=>'PRIVATE TYPE']],['attributeKey'=>'Description','value'=>'PRIVATE DESCRIPTION']]]]];$GLOBALS['http_handler']=fn()=>response($raw);$r=reference_ajax();$fields=$r->data['report']['receipts'][0]['shape']['fields'];$attrs=end($fields)['shape']['fields'];check($attrs[0]['numeric_value']===2.0&&$attrs[1]['reference_id']===5);check(strpos(json_encode($r->data),'PRIVATE')===false);check(count($GLOBALS['http_calls'])===1);
};
$tests['a mismatched or missing document ID never confirms a receipt or imports a mapping']=function(){
 foreach([123,null]as$id){$GLOBALS['http_handler']=function()use($id){$r=reference_invoice();$r['id']=$id;return response($r);};$r=reference_ajax();check(!$r->data['report']['identity_verified']);check($r->data['report']['status']==='unverified'&&!isset($r->data['report']['receipts']));check(strpos(json_encode($r->data),'PRIVATE')===false);}
};
$tests['invalid permissions nonce identifiers paths and API versions cannot perform any read']=function(){
 foreach(['test_nonce','test_capability']as$flag){reference_reset();$GLOBALS[$flag]=false;check(!reference_ajax()->success&&!$GLOBALS['http_calls']);}
 foreach(['',[],0,'0','-1','30577.0',str_repeat('9',30),'30577&customerId=1']as$id){reference_reset();$_POST['invoice_id']=$id;check(!reference_ajax()->success&&!$GLOBALS['http_calls']);}
 reference_reset();$_POST['contract']='https://attacker.invalid/';check(!reference_ajax()->success&&!$GLOBALS['http_calls']);reference_reset();$GLOBALS['options'][RKW_OPT]['api']='v19';check(!reference_ajax()->success&&!$GLOBALS['http_calls']);
};
$tests['HTTP and business errors are sanitized and never trigger a financial or authentication retry']=function(){
 foreach([401,500,200]as$code){reference_reset();$GLOBALS['http_handler']=fn()=>response([],false,'PRIVATE ERROR',$code);$r=reference_ajax();check($r->success&&$r->data['report']['status']==='read_error');check(count($GLOBALS['http_calls'])===1);check(strpos(json_encode($r->data),'PRIVATE')===false);}
};
$tests['changed connections cannot blend receipts from a previous server into a result']=function(){
 $GLOBALS['http_handler']=function(){$GLOBALS['options'][RKW_OPT]['ip']='changed.example.invalid';return response(reference_invoice());};$r=reference_ajax();check(!$r->success&&count($GLOBALS['http_calls'])===1);check(strpos(json_encode($r->data),'36950000')===false);
};
$tests['malformed and oversized receipt lists remain bounded and never imply voucher success']=function(){
 $raw=reference_invoice();$raw['receipts']=array_fill(0,25,['key'=>'EReceipt','amount'=>10,'details'=>array_fill_keys(array_map(fn($i)=>'field'.$i,range(1,50)),'PRIVATE')]);$GLOBALS['http_handler']=fn()=>response($raw);$r=reference_ajax();$p=$r->data['report'];check(count($p['receipts'])===20&&$p['receipts_schema']['truncated']&&!$p['third_party_coupon_found']);check(strpos(json_encode($r->data),'PRIVATE')===false);
};
$fail=0;foreach($tests as$name=>$test){reference_reset();try{$test();echo'PASS '.$name."\n";}catch(Throwable$e){$fail++;echo'FAIL '.$name.': '.$e->getMessage().' at '.$e->getLine()."\n";}}echo count($tests).' tests, '.$fail." failed\n";exit($fail?1:0);
