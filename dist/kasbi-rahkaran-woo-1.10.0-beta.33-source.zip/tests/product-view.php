<?php
define('RKW_AUTO_PRODUCT_FIXTURES_ONLY',true);
require __DIR__.'/auto-product.php';
class ViewDB extends TestDB {
 public $prefix='wp_',$options='wp_options',$reductions=[],$fail=false;
 function get_results($sql,$format){if(strpos($sql,'woocommerce_order_items')!==false){if($this->fail){$this->last_error='synthetic';return null;}return$this->reductions;}return[];}
 function query($sql){[$key,$lease]=$this->last_args;if(($GLOBALS['options'][$key]??null)===$lease){unset($GLOBALS['options'][$key]);return 1;}return 0;}
}
class ViewProduct extends SyncProduct {
 function get_price_html(){return'<span>'.$this->price.'</span>';}
 function is_in_stock(){return$this->stock_status!=='outofstock';}function is_purchasable(){return$this->price!=='';}
 function get_min_purchase_quantity(){return 1;}function get_max_purchase_quantity(){return$this->qty;}
 function get_available_variation($p){return['variation_id'=>$p->get_id(),'display_price'=>(float)$p->price,'availability_html'=>wc_get_stock_html($p),'is_in_stock'=>$p->is_in_stock(),'attributes'=>['attribute_color'=>'blue']];}
 function get_available_variations(){return array_values(array_map(fn($p)=>$this->get_available_variation($p),array_filter(array_map('wc_get_product',$this->children),fn($p)=>$p&&$p->status==='publish')));}
}
class WC_Product_Variable {static function sync($id){$GLOBALS['parent_sync'][]=$id;$p=$GLOBALS['products'][$id];$prices=array_map(fn($id)=>(float)$GLOBALS['products'][$id]->price,$p->children);if($prices)$p->price=(string)min($prices);}}
function post_password_required($id){return in_array($id,$GLOBALS['protected']??[],true);}
function wp_cache_delete($key,$group){}
function is_product(){return$GLOBALS['product_page']??true;}function get_queried_object_id(){return$GLOBALS['queried_product']??101;}
function plugins_url($path,$file){return'https://wordpress.example.invalid/wp-content/plugins/rahkaran-woo/'.$path;}
function wp_enqueue_script($handle,$src,$deps,$ver,$footer){$GLOBALS['enqueued'][]=[$handle,$src,$deps,$ver,$footer];}
function wp_localize_script($handle,$object,$data){$GLOBALS['localized'][]=[$object,$data];}
function nocache_headers(){$GLOBALS['nocache']=true;}
function wc_get_stock_html($p){return'<p class="stock '.($p->is_in_stock()?'in-stock':'out-of-stock').'">'.$p->qty.'</p>';}
function woocommerce_template_single_add_to_cart(){echo'<form class="cart"><button>خرید</button></form>';}
function view_reset(){auto_reset();$GLOBALS['wpdb']=new ViewDB;$GLOBALS['products']=[101=>new ViewProduct(101)];$GLOBALS['parent_sync']=[];$GLOBALS['protected']=[];$GLOBALS['product_page']=true;$GLOBALS['queried_product']=101;$GLOBALS['enqueued']=[];$GLOBALS['localized']=[];$GLOBALS['nocache']=false;}
function view_family($count=20){$p=new ViewProduct(200,999);$p->type='variable';$GLOBALS['products'][200]=$p;for($i=0;$i<$count;$i++){$c=new ViewProduct(300+$i,1000+$i);$c->type='variation';$c->parent=200;$p->children[]=$c->id;$GLOBALS['products'][$c->id]=$c;}$GLOBALS['http_handler']=function($u,$a){check($a['method']==='GET'&&$a['timeout']===5);parse_str(parse_url($u,PHP_URL_QUERY),$q);return strpos($u,'/GetProduct?')!==false?response(['productId'=>(int)$q['id'],'fee'=>34500000,'RetailUnitRef'=>1]):response([['StoreID'=>2,'RemainingQuantity'=>(int)$q['productId']-999]]);};return$p;}
if(defined('RKW_VIEW_FIXTURES_ONLY'))return;
$tests=[];
$tests['a first product view updates both enabled fields and stamps a five minute success']=function(){
 $r=RKW_Product_View::step(101);$p=$GLOBALS['products'][101];check($r['done']&&$r['updated']);check($p->regular==='500'&&$p->qty===5&&$p->saves===1);check(RKW_Product_View::fresh($p));check(count($GLOBALS['http_calls'])===2);
};
$tests['repeat views and a 299 second success do not request ERP again; the 300 second boundary does']=function(){
 $p=$GLOBALS['products'][101];RKW_Product_View::step(101);$stamp=$p->meta[RKW_Product_View::FRESH];$p->meta[RKW_Product_View::FRESH]['time']=time()-299;check(!RKW_Product_View::step(101)['updated']);check(count($GLOBALS['http_calls'])===2);$p->meta[RKW_Product_View::FRESH]['time']=time()-300;check(RKW_Product_View::step(101)['updated']);check(count($GLOBALS['http_calls'])===4);
};
$tests['a successful admin refresh also counts as the last successful update']=function(){
 RKW_Auto_Product::update(101);check(RKW_Product_View::fresh($GLOBALS['products'][101]));check(!RKW_Product_View::step(101)['updated']);check(count($GLOBALS['http_calls'])===2);
};
$tests['settings or own mapping changes invalidate the previous freshness stamp']=function(){
 RKW_Product_View::step(101);$p=$GLOBALS['products'][101];$GLOBALS['options'][RKW_OPT]['price_divisor']=1;check(!RKW_Product_View::fresh($p));RKW_Product_View::step(101);check($p->regular==='5000');$p->meta['_rahkaran_product_id']=31;check(!RKW_Product_View::fresh($p));
};
$tests['a failure preserves prices quantities and the actual old success; immediate repeat is cooled down']=function(){
 $p=$GLOBALS['products'][101];RKW_Product_View::stamp($p,30,rkw_settings());$p->meta[RKW_Product_View::FRESH]['time']=time()-600;$stamp=$p->meta[RKW_Product_View::FRESH];$GLOBALS['http_handler']=fn()=>new WP_Error('http_request_failed','PRIVATE');$r=RKW_Product_View::step(101);check($r['status']==='failed'&&$p->saves===0&&$p->qty===9&&$p->price==='100'&&$p->meta[RKW_Product_View::FRESH]===$stamp);check(RKW_Product_View::step(101)['status']==='cooldown');check(count($GLOBALS['http_calls'])===1);check(strpos(json_encode(RKW_Log::all()),'PRIVATE')===false);
};
$tests['a failed stock read cannot save a new price or advertise a fresh success']=function(){
 $handler=$GLOBALS['http_handler'];$GLOBALS['http_handler']=fn($u,$a)=>strpos($u,'GetRemainingQuantityInfo')!==false?new WP_Error('timeout','PRIVATE'):$handler($u,$a);$r=RKW_Product_View::step(101);$p=$GLOBALS['products'][101];check($r['status']==='failed'&&$p->saves===0&&$p->price==='100'&&!isset($p->meta[RKW_Product_View::FRESH]));
};
$tests['a product save exception cannot advance the last successful stamp']=function(){
 $p=$GLOBALS['products'][101];$p->on_save=function(){throw new Exception('synthetic');};$r=RKW_Product_View::step(101);check($r['status']==='failed'&&!isset($p->meta[RKW_Product_View::FRESH]));
};
$tests['invalid price and wrong product IDs never partially update the product']=function(){
 foreach([['productId'=>30,'fee'=>0],['productId'=>31,'fee'=>8000]]as$raw){view_reset();$GLOBALS['http_handler']=fn($u)=>strpos($u,'/GetProduct?')!==false?response($raw):response([['StoreID'=>2,'RemainingQuantity'=>5]]);check(RKW_Product_View::step(101)['status']==='failed');check($GLOBALS['products'][101]->saves===0&&$GLOBALS['products'][101]->price==='100');}
};
$tests['twenty independent variants are processed one per request and the parent ID is never queried']=function(){
 $parent=view_family();$r=['cursor'=>0,'done'=>false];$steps=0;while(!$r['done']){$before=count($GLOBALS['http_calls']);$r=RKW_Product_View::step(200,$r['cursor']);check($r['updated']&&count($GLOBALS['http_calls'])===$before+2);$steps++;}check($steps===20&&count($GLOBALS['parent_sync'])===20);foreach($parent->children as$i=>$id){$p=$GLOBALS['products'][$id];check($p->price==='3450000'&&$p->qty===$i+1&&RKW_Product_View::fresh($p));}check(count($GLOBALS['http_calls'])===40);check(RKW_Product_View::step(200)['done']);check(count($GLOBALS['http_calls'])===40);
};
$tests['fresh children are skipped together without extra ERP requests or changing the parent mapping']=function(){
 $p=view_family(3);foreach($p->children as$id)RKW_Product_View::stamp($GLOBALS['products'][$id],$GLOBALS['products'][$id]->meta['_rahkaran_product_id'],rkw_settings());$r=RKW_Product_View::step(200);check($r['done']&&!$r['updated']&&!$GLOBALS['http_calls']);check($p->meta['_rahkaran_product_id']===999);
};
$tests['unmapped disabled draft children and foreign parent relationships are never refreshed']=function(){
 $p=view_family(4);$GLOBALS['products'][300]->meta=[];$GLOBALS['products'][301]->status='private';$GLOBALS['products'][302]->status='draft';$GLOBALS['products'][303]->parent=777;$r=RKW_Product_View::step(200);check($r['done']&&!$GLOBALS['http_calls']);
};
$tests['a concurrent visitor gets a bounded busy result while only the owner calls ERP']=function(){
 $handler=$GLOBALS['http_handler'];$nested=null;$GLOBALS['http_handler']=function($u,$a)use($handler,&$nested){if(strpos($u,'/GetProduct?')!==false)$nested=RKW_Product_View::step(101);return$handler($u,$a);};check(RKW_Product_View::step(101)['updated']);check($nested['status']==='busy'&&$nested['retry_cursor']===0);check(count($GLOBALS['http_calls'])===2&&!get_option('rkw_view_lock_101'));
};
$tests['an expired lease is replaced and an old worker cannot delete the new owner lease']=function(){
 add_option('rkw_view_lock_101',json_encode(['token'=>'old','expires'=>time()-1]));$handler=$GLOBALS['http_handler'];$GLOBALS['http_handler']=function($u,$a)use($handler){$GLOBALS['options']['rkw_view_lock_101']='replacement';return$handler($u,$a);};check(RKW_Product_View::step(101)['updated']);check(get_option('rkw_view_lock_101')==='replacement');
};
$tests['page refresh cannot replenish paid units waiting for ERP registration']=function(){
 $GLOBALS['wpdb']->reductions=[['item_id'=>1,'order_id'=>777,'quantity'=>2,'uncertain'=>1]];RKW_Product_View::step(101);check($GLOBALS['products'][101]->qty===3);check(RKW_Product_View::fresh($GLOBALS['products'][101]));
};
$tests['a local hold read failure prevents the ERP fetch and any product change']=function(){
 $GLOBALS['wpdb']->fail=true;check(RKW_Product_View::step(101)['status']==='failed');check(!$GLOBALS['http_calls']&&$GLOBALS['products'][101]->saves===0);
};
$tests['changes during a read are rejected and do not stamp the old connection as current']=function(){
 $handler=$GLOBALS['http_handler'];$GLOBALS['http_handler']=function($u,$a)use($handler){$r=$handler($u,$a);if(strpos($u,'RemainingQuantityInfo')!==false)$GLOBALS['options'][RKW_OPT]['price_divisor']=1;return$r;};check(RKW_Product_View::step(101)['status']==='failed');check($GLOBALS['products'][101]->saves===0);
};
$tests['view refresh is independent of admin save automatic queue and cron; disabled fields are respected']=function(){
 $GLOBALS['options'][RKW_OPT]['auto_product_on_save']=0;$GLOBALS['options'][RKW_OPT]['cron_interval']='off';$GLOBALS['options'][RKW_OPT]['order_enabled']=0;$GLOBALS['options'][RKW_OPT]['sync_stock']=0;check(RKW_Product_View::step(101)['updated']);check(count($GLOBALS['http_calls'])===1&&$GLOBALS['products'][101]->qty===9);view_reset();$GLOBALS['options'][RKW_OPT]['sync_price']=0;check(RKW_Product_View::step(101)['updated']);check($GLOBALS['products'][101]->regular==='100'&&$GLOBALS['products'][101]->qty===5);
};
$tests['disabled feature API19 and both fields disabled make no ERP calls']=function(){
 foreach(['feature','api','fields']as$kind){view_reset();if($kind==='feature')$GLOBALS['options'][RKW_OPT]['product_view_refresh']=0;if($kind==='api')$GLOBALS['options'][RKW_OPT]['api']='v19';if($kind==='fields'){$GLOBALS['options'][RKW_OPT]['sync_stock']=0;$GLOBALS['options'][RKW_OPT]['sync_price']=0;}check(RKW_Product_View::step(101)['status']==='disabled'&&!$GLOBALS['http_calls']);}
};
$tests['only public unprotected parent products are accepted by the endpoint']=function(){
 $GLOBALS['products'][101]->status='draft';expect_error(RKW_Product_View::step(101),'rkw_view_product');view_reset();$GLOBALS['protected']=[101];expect_error(RKW_Product_View::step(101),'rkw_view_product');view_family(1);expect_error(RKW_Product_View::step(300),'rkw_view_product');check(!$GLOBALS['http_calls']);
};
$tests['only explicit legacy ID mode uses a numeric own SKU']=function(){
 $p=$GLOBALS['products'][101];$p->meta=[];$p->sku='30';check(!RKW_Product_View::step(101)['updated']&&!$GLOBALS['http_calls']);$GLOBALS['options'][RKW_OPT]['key_field']='id';check(RKW_Product_View::step(101)['updated']);check($p->meta['_rahkaran_product_id']===30);
};
$tests['untrusted cursor and product IDs cannot select private products or invoke a financial operation']=function(){
 foreach([['product_id'=>[]],['product_id'=>'-1'],['product_id'=>'101','cursor'=>[]],['product_id'=>'101','cursor'=>'-1'],['product_id'=>'101','cursor'=>'90']]as$post){$_POST=$post;try{RKW_Product_View::ajax();check(false);}catch(TestJSON$e){check(!$e->success);}}check(!$GLOBALS['http_calls']);
};
$tests['public AJAX returns uncached native price and stock even if the HTML page was old']=function(){
 RKW_Product_View::step(101);$GLOBALS['http_calls']=[];$_POST=['product_id'=>'101','cursor'=>'0'];try{RKW_Product_View::ajax();check(false);}catch(TestJSON$e){check($e->success&&$e->data['display']['price_html']==='<span>500</span>');check($e->data['display']['in_stock']);}check($GLOBALS['nocache']&&!$GLOBALS['http_calls']);
};
$tests['native cart rendering restores the previous global product and returns only public display data']=function(){
 $GLOBALS['product']='prior';$d=RKW_Product_View::display(101,true);check(strpos($d['cart_html'],'form')!==false&&$GLOBALS['product']==='prior');check(strpos(json_encode($d),'password')===false);$p=view_family(2);$GLOBALS['products'][301]->status='private';$d=RKW_Product_View::display(200);check(count($d['variations'])===1&&$d['variations'][0]['variation_id']===300);$p=view_family(31);check(RKW_Product_View::display(200)['variations']===false);
};
$tests['future corrupt and incomplete freshness metadata cannot suppress live refresh forever']=function(){
 $p=$GLOBALS['products'][101];foreach([['time'=>time()+999,'signature'=>'x'],['time'=>time(),'signature'=>[]],['time'=>time()],false]as$meta){$p->meta[RKW_Product_View::FRESH]=$meta;check(!RKW_Product_View::fresh($p));}check(!RKW_Product_View::fresh(false));
};
$tests['public script is added only on a valid product page and supports native variations without an expiring nonce']=function(){
 RKW_Product_View::assets();check(count($GLOBALS['enqueued'])===1&&$GLOBALS['localized'][0][1]['product']===101);check(!isset($GLOBALS['localized'][0][1]['nonce']));$GLOBALS['product_page']=false;RKW_Product_View::assets();check(count($GLOBALS['enqueued'])===1);$GLOBALS['product_page']=true;view_family(2);$GLOBALS['queried_product']=200;RKW_Product_View::assets();check(in_array('wc-add-to-cart-variation',$GLOBALS['enqueued'][1][2],true));
};
$fail=0;foreach($tests as$name=>$test){view_reset();try{$test();echo'PASS '.$name."\n";}catch(Throwable$e){$fail++;echo'FAIL '.$name.': '.$e->getMessage().' at '.$e->getLine()."\n";}}echo count($tests).' tests, '.$fail." failed\n";exit($fail?1:0);
