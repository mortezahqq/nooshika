(() => {
 'use strict';
 const root = document.querySelector('.rkw-manual'); if (!root) return;
 const cfg = window.rkwManualOrders || {}, el = id => document.getElementById('rkw-manual-' + id);
 let busy = false, blockedCode = '';
 const fa = new Intl.NumberFormat('fa-IR', {maximumFractionDigits: 2});
 const amount = (v, currency) => fa.format(Number(v) || 0) + ' ' + ({IRT:'تومان',IRR:'ریال',IRHT:'هزار تومان',IRHR:'هزار ریال'}[currency] || currency || '');
 const date = value => { if (!value) return '—'; try { return new Intl.DateTimeFormat('fa-IR-u-ca-persian', {year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',timeZone:'Asia/Tehran'}).format(new Date(value)); } catch (_) { return '—'; } };
 function node(tag, text, className) { const n = document.createElement(tag); if (text !== undefined) n.textContent = String(text); if (className) n.className = className; return n; }
 function feedback(target, text, error = false) { target.textContent = text; target.classList.toggle('is-error', error); }
 async function request(action, fields) {
  const response = await fetch(cfg.ajax, {method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams(Object.assign({action,nonce:cfg.nonce || ''},fields))});
  const result = await response.json(); if (!result.success) throw new Error(result.data?.message || 'عملیات انجام نشد.'); return result.data;
 }
 function pair(dl, label, value) { dl.append(node('dt',label),node('dd',value === null || value === undefined || value === '' ? '—' : value)); }
 function listMessages(messages, className) { const list = node('ul',undefined,className);for(const msg of messages || []) list.append(node('li',msg));return list; }
 function render(p) {
  const target = el('detail');target.replaceChildren();el('title').textContent = 'بررسی سفارش #' + p.number;
  target.append(listMessages(p.issues,'rkw-manual-issues'),listMessages(p.warnings,'rkw-manual-warnings'));
  const dl = node('dl',undefined,'rkwm-detail-grid');
  pair(dl,'نوع سند',p.document_type);pair(dl,'خریدار',p.buyer);pair(dl,'شماره همراه',p.phone);pair(dl,'کد ملی در اطلاعات سفارش',p.national_code_present ? 'ثبت شده' : 'ثبت نشده');pair(dl,'کد پستی',p.address?.postcode);
  pair(dl,'نشانی',Object.entries(p.address || {}).filter(([key])=>key !== 'postcode').map(([,value])=>value).filter(Boolean).join('، '));
  pair(dl,'تاریخ سفارش',date(p.date));pair(dl,'وضعیت سفارش',p.status);pair(dl,'شناسه مشتری راهکاران',p.customer_id || 'هنگام ثبت جست‌وجو و در صورت نیاز ایجاد می‌شود');
  pair(dl,'روش پرداخت',p.payment_title);pair(dl,'شناسه درگاه',p.gateway);pair(dl,'روش حمل',(p.shipping_methods || []).join('، '));
  pair(dl,'سیاست تسویه',p.payment?.policy_id);pair(dl,'نوع دریافت',p.payment?.key);if(p.payment?.coupon_type_id)pair(dl,'نوع بن سازمانی',p.payment.coupon_type_id);if(p.payment?.bank_ref)pair(dl,'شناسه حساب بانک',p.payment.bank_ref);
  target.append(dl);
  const wrap = node('div',undefined,'rkwm-table-wrap'), table = node('table',undefined,'widefat striped rkwm-table'), head = node('thead'), hr = node('tr');
  ['کالا','SKU','تعداد','قیمت واحد قبل از تخفیف','تخفیف ردیف','مبلغ ردیف','مالیات','کد کالا / واحد راهکاران'].forEach(v=>hr.append(node('th',v)));head.append(hr);table.append(head);const body = node('tbody');
  for(const item of p.items || []) { const tr = node('tr');[item.name,item.sku || '—',fa.format(item.quantity),amount(item.quantity > 0 ? item.subtotal / item.quantity : 0,p.currency),amount(item.subtotal-item.total,p.currency),amount(item.total,p.currency),amount(item.tax,p.currency),(item.product_id || 'نامشخص') + ' / ' + (item.unit_id || 'نامشخص')].forEach(v=>tr.append(node('td',v)));body.append(tr); }
  table.append(body);wrap.append(table);target.append(node('h3','اقلام سفارش'),wrap);
  const totals = node('dl',undefined,'rkwm-detail-grid');pair(totals,'حمل با مالیات',amount(Number(p.shipping_total)+Number(p.shipping_tax),p.currency));
  for(const fee of p.fees || []) pair(totals,fee.name,amount(Number(fee.amount)+Number(fee.tax),p.currency));
  pair(totals,'مجموع سفارش ووکامرس',amount(p.total,p.currency));pair(totals,'مبلغ سفارش به واحد راهکاران',fa.format(p.amounts.woo_order_total));target.append(totals);
  const description = node('details'), summary = node('summary','توضیحات ارسالی فاکتور');description.append(summary,node('p',p.description));target.append(description);
  el('edit').href = p.edit_url;
  if(p.document && p.document !== '—')pair(dl,'شناسه سند راهکاران',p.document);
  if (!p.can_submit && p.state === 'pending') { const link = node('a','رفتن به فاکتورهای فروش برای بررسی وضعیت','button');link.href = 'admin.php?page=rkw-invoices';target.append(link); }
 }
 function controls(value) {
  busy=value;root.querySelectorAll('input,button').forEach(n=>{n.disabled=value;});
  if(!value)el('register').disabled=blockedCode!==''&&blockedCode===el('code').value;
 }
 function hideDetails(){el('preview').hidden=true;el('detail').replaceChildren();}
 async function run(register){
  if(busy)return;const code=el('code').value.trim();
  if(!code){feedback(el('status'),'کد سفارش ووکامرس را وارد کنید.',true);return;}
  if(register&&blockedCode===el('code').value)return;
  controls(true);hideDetails();feedback(el('status'),register?'در حال ثبت سفارش با کد '+code+' در راهکاران…':'در حال دریافت اطلاعات سفارش '+code+'…');
  try{
   const result=await request(register?'rkw_manual_register_code':'rkw_manual_lookup_code',{code,confirm:register?'1':'0'});
   const data=register?result.details:result;
   if(data){render(data);el('preview').hidden=false;}
   if(register){
    const done=result.status==='sent'||result.status==='already_sent';
    document.dispatchEvent(new CustomEvent('rkw-order-result',{detail:{id:result.id,status:result.status==='already_sent'?'skipped':(result.status==='pending'?'blocked':result.status),document:result.document,message:result.message}}));
    blockedCode=done||result.status==='pending'?el('code').value:'';
    feedback(el('status'),result.message+(done?' '+result.document:''),!done);
    feedback(el('result'),done?'نتیجه ثبت: '+result.document:result.message,!done);
   }else{
    if(data.state==='sent'||data.state==='pending')document.dispatchEvent(new CustomEvent('rkw-order-result',{detail:{id:data.id,status:data.state==='sent'?'skipped':'blocked',document:data.document,message:(data.issues||[]).join(' ')}}));
    blockedCode=data.can_submit?'':el('code').value;
    feedback(el('status'),data.can_submit?'اطلاعات سفارش دریافت شد؛ برای ثبت، دکمه «ثبت سفارش در راهکاران» را بزنید.':(data.issues||[]).join(' '),!data.can_submit);
    feedback(el('result'),'این بررسی هیچ مشتری یا فاکتوری ثبت نکرده است.');
   }
  }catch(error){
   if(register){blockedCode=el('code').value;feedback(el('status'),'نتیجه ثبت تأیید نشد: '+(error.message||'پاسخ دریافت نشد.')+' ابتدا «فقط نمایش اطلاعات سفارش» را بزنید و وضعیت را بررسی کنید.',true);}
   else feedback(el('status'),error.message||'اطلاعات سفارش دریافت نشد.',true);
  }finally{controls(false);}
 }
 el('code-form').addEventListener('submit',event=>{event.preventDefault();run(true);});
 el('lookup').addEventListener('click',()=>run(false));
 el('refresh').addEventListener('click',()=>run(false));
 el('close').addEventListener('click',hideDetails);
 el('code').addEventListener('input',()=>{if(busy)return;blockedCode='';hideDetails();el('register').disabled=false;feedback(el('status'),'برای ثبت، کد سفارش را وارد و دکمه ثبت را بزنید.');});
})();
