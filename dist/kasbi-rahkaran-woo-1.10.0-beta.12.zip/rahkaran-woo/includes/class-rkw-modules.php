<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Read-only operational screens for Retail API resources. */
class RKW_Modules {
	const CAP = 'manage_woocommerce';
	private static $sections = array(
		'stores' => 'انبارها',
		'customers' => 'مشتریان',
		'products' => 'محصولات',
		'policies' => 'سیاست‌های پرداخت',
		'invoices' => 'فاکتورهای فروش',
	);

	public static function init() {
		add_action( 'wp_ajax_rkw_module_list', array( __CLASS__, 'ajax_list' ) );
		add_action( 'wp_ajax_rkw_module_detail', array( __CLASS__, 'ajax_detail' ) );
		add_action( 'wp_ajax_rkw_invoice_settlement', array( __CLASS__, 'ajax_invoice_settlement' ) );
		add_action( 'wp_ajax_rkw_module_count', array( __CLASS__, 'ajax_count' ) );
		add_action( 'wp_ajax_rkw_policy_select', array( __CLASS__, 'ajax_policy_select' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
	}

	public static function menu() {
		foreach ( self::$sections as $key => $label ) {
			add_submenu_page( 'rkw', $label . ' | کاسبی راهکاران', $label, self::CAP, 'rkw-' . $key, array( __CLASS__, 'page' ) );
		}
	}

	private static function section() {
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
		$key  = preg_replace( '/^rkw-/', '', $page );
		return isset( self::$sections[ $key ] ) ? $key : '';
	}

	public static function assets( $hook ) {
		$section = self::section();
		if ( ! $section || ! current_user_can( self::CAP ) ) { return; }
		wp_enqueue_style( 'rkw-modules', plugins_url( 'assets/admin.css', RKW_FILE ), array(), RKW_VER );
		wp_enqueue_script( 'rkw-modules', plugins_url( 'assets/admin.js', RKW_FILE ), array(), RKW_VER, true );
		wp_localize_script( 'rkw-modules', 'rkwModules', array(
			'ajax' => admin_url( 'admin-ajax.php' ),
			'nonce' => wp_create_nonce( 'rkw_module' ),
			'section' => $section,
			'error' => 'ارتباط با سرور برقرار نشد. لطفاً دوباره تلاش کنید.',
			'initial' => RKW_Snapshot::last_view( $section ),
		) );
	}

	public static function page() {
		if ( ! current_user_can( self::CAP ) ) { wp_die( esc_html__( 'Access denied.', 'rahkaran-woo' ) ); }
		$section = self::section();
		if ( ! $section ) { return; }
		$s = rkw_settings();
		$descriptions = array(
			'stores' => 'مشاهده انبارهای تعریف‌شده در راهکاران و شناسه‌هایی که برای موجودی و اسناد فروش استفاده می‌شوند.',
			'customers' => 'جست‌وجو و مشاهده اطلاعات مشتریان راهکاران بدون تغییر اطلاعات اصلی.',
			'products' => 'مشاهده محصولات، کد کالا و قیمت پایه؛ همگام‌سازی با ووکامرس از بخش تنظیمات کالا انجام می‌شود.',
			'policies' => 'نمایش سیاست‌های تسویه و روش‌های پرداخت راهکاران؛ انتخاب سیاست پیش‌فرض ارسال اسناد فروش.',
			'invoices' => 'فاکتورهای راهکاران و سفارش‌های ووکامرس؛ نمایش شناسه‌ها و ارسال تکی/گروهی سفارش‌های ارسال‌نشده یا خطادار.',
		);
		echo '<div class="wrap rkwm-wrap" dir="rtl">';
		echo '<header class="rkwm-header"><div><div class="rkwm-eyebrow">RAHKARAN × WOOCOMMERCE</div><h1>' . esc_html( self::$sections[ $section ] ) . '</h1><p>' . esc_html( $descriptions[ $section ] ) . '</p></div><a class="button" href="' . esc_url( admin_url( 'admin.php?page=rkw&tab=connection' ) ) . '">تنظیمات اتصال</a></header>';
		echo '<nav class="rkwm-nav" aria-label="بخش‌های راهکاران">';
		foreach ( self::$sections as $k => $label ) {
			echo '<a class="' . ( $section === $k ? 'is-active' : '' ) . '" href="' . esc_url( admin_url( 'admin.php?page=rkw-' . $k ) ) . '">' . esc_html( $label ) . '</a>';
		}
		echo '</nav>';
		if ( 'v19' === $s['api'] && in_array( $section, array( 'customers', 'policies', 'invoices' ), true ) ) {
			echo '<div class="notice notice-warning inline"><p>این صفحه بر اساس وب‌سرویس‌های نسخه ۲۱ پیاده‌سازی شده است. اتصال فعلی روی نسخه ۱۹ تنظیم شده؛ برای جلوگیری از درخواست نامعتبر، این بخش غیرفعال است.</p></div>';
			echo '</div>';
			return;
		}
		if ( 'policies' === $section ) {
			echo '<div class="rkwm-info">سیاست انتخاب‌شده در تنظیمات ارسال سفارش‌ها: <strong id="rkwm-current-policy">' . esc_html( (string) (int) ( ! empty( $s[ 'invoice' === $s['order_mode'] ? 'invoice_settlement_id' : 'order_settlement_id' ] ) ? $s[ 'invoice' === $s['order_mode'] ? 'invoice_settlement_id' : 'order_settlement_id' ] : $s['settlement_id'] ) ) . '</strong> — نوع سند فعلی: <strong>' . esc_html( 'invoice' === $s['order_mode'] ? 'فاکتور فروش' : 'سفارش فروش' ) . '</strong>. انتخاب سیاست در این صفحه روش‌های پرداخت ووکامرس را به‌طور خودکار تغییر نمی‌دهد.</div>';
		}
		if ( 'invoices' === $section ) {
			self::recent_woocommerce_orders();
			echo '<details id="rkwm-remote-invoices" class="rkwm-remote-invoices"><summary>مشاهده فاکتورها و اطلاعات راهکاران</summary><div class="rkwm-remote-invoices-content">';
		}
		echo '<section class="rkwm-box"><form id="rkwm-filter" class="rkwm-toolbar">';
		if ( 'customers' === $section || 'products' === $section || 'invoices' === $section ) {
			$placeholder = array( 'customers' => 'نام مشتری…', 'products' => 'نام یا کد محصول…', 'invoices' => 'نام مشتری…' );
			echo '<label class="rkwm-search"><span>جست‌وجو</span><input id="rkwm-search" type="search" maxlength="100" placeholder="' . esc_attr( $placeholder[ $section ] ) . '"></label>';
		}
		if ( 'invoices' === $section ) {
			echo '<label><span>موبایل مشتری</span><input id="rkwm-mobile" type="text" inputmode="tel" maxlength="20" placeholder="0912…" dir="ltr"></label>';
			echo '<label><span>شناسه فروشگاه داخلی (اختیاری)</span><input id="rkwm-shop" type="number" min="0" step="1" value="0"></label>';
		}
		if ( 'policies' === $section ) {
			$chosen_type = 'invoice' === $s['order_mode'] ? 1 : 2;
			echo '<label><span>کاربرد سیاست</span><select id="rkwm-doc-type"><option value="1" ' . selected( $chosen_type, 1, false ) . '>فاکتور فروش</option><option value="2" ' . selected( $chosen_type, 2, false ) . '>سفارش فروش</option></select></label>';
		}
		echo '<label><span>تعداد در صفحه</span><select id="rkwm-size"><option value="20">۲۰</option><option value="50">۵۰</option><option value="100">۱۰۰</option></select></label>';
		echo '<button type="submit" class="button button-primary">به‌روزرسانی از راهکاران</button></form>';
		echo '<p class="rkwm-cache-note">اطلاعات دریافت‌شده در وردپرس ذخیره می‌شود و پس از بارگذاری مجدد باقی می‌ماند. برای مشاهده آخرین تغییرات، «به‌روزرسانی از راهکاران» را بزنید.</p>';
		echo '<div id="rkwm-snapshot-status" class="rkwm-snapshot-status" role="status" aria-live="polite"></div>';
		echo '<div id="rkwm-alert" class="rkwm-alert" role="status" aria-live="polite"></div>';
		echo '<div id="rkwm-results" class="rkwm-table-wrap"><p class="rkwm-empty">در حال بارگذاری آخرین اطلاعات ذخیره‌شده…</p></div>';
		echo '<div class="rkwm-footer"><span id="rkwm-count"></span><nav class="rkwm-pages" aria-label="صفحه‌بندی فهرست"><button type="button" id="rkwm-prev" class="button" disabled>قبلی</button><span id="rkwm-numbers" class="rkwm-numbers"></span><button type="button" id="rkwm-next" class="button" disabled>بعدی</button></nav><form id="rkwm-jump" class="rkwm-jump"><label for="rkwm-jump-num">برو به صفحه</label><input id="rkwm-jump-num" type="number" min="1" max="100000" value="1" inputmode="numeric" aria-label="شماره صفحه مقصد"><button class="button" type="submit">برو</button></form><span id="rkwm-page" class="rkwm-page-count">صفحه ۱</span></div></section>';
		if ( 'products' === $section ) {
			echo '<p class="rkwm-hint">برای انتقال قیمت و موجودی به ووکامرس، از <a href="' . esc_url( admin_url( 'admin.php?page=rkw&tab=catalog' ) ) . '">همگام‌سازی محصولات</a> استفاده کنید. دکمه «موجودی» اطلاعات هر محصول را جداگانه از راهکاران می‌خواند.</p>';
		}
		if ( 'invoices' === $section ) {
			echo '<section class="rkwm-settlement-shortcut"><h2>بررسی دریافت‌های فاکتور ثبت‌شده در راهکاران</h2><p>شناسه فاکتور راهکاران را وارد کنید (مثلاً 119893). این بررسی فقط GetInvoice را می‌خواند و هیچ سندی صادر نمی‌کند.</p><form id="rkwm-settlement-lookup"><label for="rkwm-settlement-invoice-id">شناسه فاکتور</label><input id="rkwm-settlement-invoice-id" type="number" min="1" step="1" required placeholder="119893"><button type="submit" class="button button-secondary">جزئیات تسویه و پرداخت</button></form></section>';
		}
		echo '<section class="rkwm-detail" id="rkwm-detail" hidden><div class="rkwm-detail-head"><h2 id="rkwm-detail-title">جزئیات</h2><button type="button" id="rkwm-detail-close" class="button">بستن</button></div><div id="rkwm-detail-content"></div><div id="rkwm-detail-settlement" hidden><button type="button" class="button button-primary" id="rkwm-detail-settlement-btn">جزئیات تسویه و پرداخت</button></div></section>';
		if ( 'invoices' === $section ) {
			echo '<div id="rkwm-settlement-modal" class="rkwm-settlement-overlay" hidden><section class="rkwm-settlement-modal" role="dialog" aria-modal="true" aria-labelledby="rkwm-settlement-title" tabindex="-1"><header><div><span class="rkwm-settlement-eyebrow">راهکاران · فقط خواندنی</span><h2 id="rkwm-settlement-title">جزئیات تسویه و پرداخت</h2></div><button id="rkwm-settlement-close" class="button" type="button">بستن ×</button></header><div id="rkwm-settlement-content" class="rkwm-settlement-content" aria-live="polite"></div><form id="rkwm-settlement-compare" class="rkwm-settlement-compare"><label for="rkwm-settlement-order-id">مقایسه با تنظیمات یک سفارش ووکامرس (اختیاری)</label><input type="number" min="1" step="1" id="rkwm-settlement-order-id" placeholder="شناسه سفارش ووکامرس"><button type="submit" class="button button-secondary">مقایسه بدون ارسال</button></form><p class="rkwm-settlement-disclaimer">اطلاعات از GetInvoice خوانده می‌شود. شماره کارت و شماره پیگیری به‌صورت کامل نمایش داده نمی‌شود. شناسه داخلی حساب بانکیِ خروجی ممکن است با bankAccountRef ورودی متفاوت باشد.</p></section></div>';
		}
		if ( 'invoices' === $section ) { echo '</div></details>'; }
		echo '</div>';
	}

	/** Buyer name from the related WooCommerce order (compatible with HPOS and guest checkout). */
	private static function order_customer_name( $order ) {
		if ( ! $order instanceof WC_Order ) { return '—'; }
		$name = trim( (string) $order->get_billing_first_name() . ' ' . (string) $order->get_billing_last_name() );
		if ( '' !== $name ) { return $name; }
		$user_id = (int) $order->get_customer_id();
		if ( $user_id > 0 ) {
			$user = get_userdata( $user_id );
			if ( $user && '' !== trim( (string) $user->display_name ) ) { return (string) $user->display_name; }
		}
		return '—';
	}

	/** Retrieve a complete local page; unsent filtering precedes LIMIT, including legacy records. */
	public static function local_order_page( $page, $filter, $from = '', $to = '' ) {
		$page = max( 1, (int) $page );
		foreach ( array( $from, $to ) as $value ) {
			if ( ! is_string( $value ) || ( '' !== $value && ( ! preg_match( '/^([0-9]{4})-([0-9]{2})-([0-9]{2})$/D', $value, $match ) || ! checkdate( (int) $match[2], (int) $match[3], (int) $match[1] ) ) ) ) {
				return new WP_Error( 'rkw_local_order_date', 'تاریخ معتبر را از تقویم انتخاب کنید.' );
			}
		}
		if ( '' !== $from && '' !== $to && $from > $to ) { return new WP_Error( 'rkw_local_order_date', 'تاریخ شروع نباید بعد از تاریخ پایان باشد.' ); }
		$after = '' !== $from ? new DateTimeImmutable( $from . ' 00:00:00', wp_timezone() ) : null;
		$before = '' !== $to ? ( new DateTimeImmutable( $to . ' 00:00:00', wp_timezone() ) )->modify( '+1 day' )->modify( '-1 second' ) : null;
		$args = array( 'limit' => 25, 'page' => $page, 'paginate' => true, 'orderby' => 'date', 'order' => 'DESC', 'type' => 'shop_order', 'status' => array( 'wc-processing', 'wc-completed' ) );
		// Timestamp ranges use the store timezone, including the entire selected end date.
		if ( $after && $before ) { $args['date_created'] = $after->getTimestamp() . '...' . $before->getTimestamp(); }
		elseif ( $after ) { $args['date_created'] = '>=' . $after->getTimestamp(); }
		elseif ( $before ) { $args['date_created'] = '<=' . $before->getTimestamp(); }
		if ( 'unsent' !== $filter ) {
			$found = wc_get_orders( $args );
			if ( is_wp_error( $found ) ) { return $found; }
			$pages = is_object( $found ) && isset( $found->max_num_pages ) ? max( 1, (int) $found->max_num_pages ) : 1;
			if ( $page > $pages ) { $page = $pages; $args['page'] = $page; $found = wc_get_orders( $args ); }
			if ( is_wp_error( $found ) ) { return $found; }
			return (object) array( 'orders' => is_object( $found ) && isset( $found->orders ) ? (array) $found->orders : ( is_array( $found ) ? $found : array() ), 'max_num_pages' => $pages, 'page' => $page );
		}
		global $wpdb;
		$util = '\\Automattic\\WooCommerce\\Utilities\\OrderUtil';
		$hpos = class_exists( $util ) && method_exists( $util, 'custom_orders_table_usage_is_enabled' ) && $util::custom_orders_table_usage_is_enabled();
		$table = $hpos ? $wpdb->prefix . 'wc_orders' : $wpdb->posts;
		$meta = $hpos ? $wpdb->prefix . 'wc_orders_meta' : $wpdb->postmeta;
		$id = $hpos ? 'id' : 'ID'; $type = $hpos ? 'type' : 'post_type'; $status = $hpos ? 'status' : 'post_status';
		$date = $hpos ? 'date_created_gmt' : 'post_date'; $meta_id = $hpos ? 'order_id' : 'post_id';
		// Do not treat an uncertain result, an invalid nonempty ID or an old queue as unsent.
		$where = $wpdb->prepare( "o.{$type}=%s AND o.{$status} IN (%s,%s)", 'shop_order', 'wc-processing', 'wc-completed' );
		foreach ( array( array( $after, '>=' ), array( $before, '<=' ) ) as $bound ) {
			if ( $bound[0] ) {
				$value = $hpos ? $bound[0]->setTimezone( new DateTimeZone( 'UTC' ) ) : $bound[0];
				$where .= $wpdb->prepare( " AND o.{$date} {$bound[1]} %s", $value->format( 'Y-m-d H:i:s' ) );
			}
		}
		$where .= " AND NOT EXISTS (SELECT 1 FROM {$meta} m WHERE m.{$meta_id}=o.{$id} AND m.meta_key='_rkw_doc_id' AND TRIM(m.meta_value)<>'')";
		$where .= " AND NOT EXISTS (SELECT 1 FROM {$meta} m WHERE m.{$meta_id}=o.{$id} AND m.meta_key='_rkw_reconcile_required' AND m.meta_value NOT IN ('','0'))";
		// This uncorrelated subquery can be materialized once instead of rescanning old queues per order.
		$where .= " AND o.{$id} NOT IN (SELECT CAST(lm.meta_value AS UNSIGNED) FROM {$wpdb->posts} lp INNER JOIN {$wpdb->postmeta} lm ON lm.post_id=lp.ID AND lm.meta_key='order_id' WHERE lp.post_type='rahkaran-invoice' AND lm.meta_value REGEXP '^[1-9][0-9]*$')";
		$total = $wpdb->get_var( "SELECT COUNT(*) FROM {$table} o WHERE {$where}" );
		if ( ! empty( $wpdb->last_error ) || ! is_numeric( $total ) ) { return new WP_Error( 'rkw_local_order_filter', 'دریافت سفارش‌های ارسال‌نشده از پایگاه داده ناموفق بود؛ دوباره تلاش کنید.' ); }
		$pages = max( 1, (int) ceil( (int) $total / 25 ) ); $page = min( $page, $pages );
		if ( 0 === (int) $total ) { return (object) array( 'orders' => array(), 'max_num_pages' => 1, 'page' => 1 ); }
		$sql = "SELECT o.{$id} FROM {$table} o WHERE {$where} ORDER BY o.{$date} DESC, o.{$id} DESC";
		$ids = $wpdb->get_col( $wpdb->prepare( $sql . ' LIMIT %d OFFSET %d', 25, ( $page - 1 ) * 25 ) );
		if ( ! empty( $wpdb->last_error ) || ! is_array( $ids ) ) { return new WP_Error( 'rkw_local_order_filter', 'دریافت صفحه سفارش‌های ارسال‌نشده ناموفق بود؛ دوباره تلاش کنید.' ); }
		$ids = array_values( array_filter( array_map( 'absint', $ids ) ) );
		$orders = $ids ? wc_get_orders( array_merge( $args, array( 'page' => 1, 'paginate' => false, 'include' => $ids ) ) ) : array();
		if ( is_wp_error( $orders ) ) { return $orders; }
		return (object) array( 'orders' => is_array( $orders ) ? $orders : array(), 'max_num_pages' => $pages, 'page' => $page );
	}

	/** Only processing and completed WooCommerce orders are shown on this screen. */
	private static function recent_woocommerce_orders() {
		if ( ! function_exists( 'wc_get_orders' ) ) { return; }
		$page = isset( $_GET['rkw_orders_page'] ) ? max( 1, min( 100000, absint( $_GET['rkw_orders_page'] ) ) ) : 1;
		$filter = isset( $_GET['rkw_order_filter'] ) && is_string( $_GET['rkw_order_filter'] ) && 'unsent' === $_GET['rkw_order_filter'] ? 'unsent' : 'all';
		$from = isset( $_GET['rkw_order_from'] ) ? wp_unslash( $_GET['rkw_order_from'] ) : '';
		$to = isset( $_GET['rkw_order_to'] ) ? wp_unslash( $_GET['rkw_order_to'] ) : '';
		$found = self::local_order_page( $page, $filter, $from, $to );
		echo '<section class="rkwm-box rkwm-local-orders" data-rkw-order-filter="' . esc_attr( $filter ) . '"><h2>سفارش‌های ووکامرس و ارسال برای راهکاران</h2>';
		echo '<p>فقط سفارش‌های «در حال انجام» و «تکمیل‌شده» نمایش داده می‌شوند. دکمه ارسال برای سفارش‌های ارسال‌نشده یا خطادار فعال است؛ نتیجه نامشخص ابتدا باید تطبیق داده شود.</p>';
		echo '<form method="get" action="' . esc_url( admin_url( 'admin.php' ) ) . '" class="rkwm-toolbar rkwm-local-filter"><input type="hidden" name="page" value="rkw-invoices"><label for="rkw-local-order-filter"><span>وضعیت ارسال به راهکاران</span><select id="rkw-local-order-filter" name="rkw_order_filter"><option value="all" ' . selected( $filter, 'all', false ) . '>همه سفارش‌های در حال انجام و تکمیل‌شده</option><option value="unsent" ' . selected( $filter, 'unsent', false ) . '>ارسال‌نشده‌ها و خطادارها</option></select></label>';
		echo '<label for="rkw-local-order-from"><span>تاریخ پرداخت از</span><input type="date" id="rkw-local-order-from" name="rkw_order_from" value="' . esc_attr( is_string( $from ) ? $from : '' ) . '"></label><label for="rkw-local-order-to"><span>تاریخ پرداخت تا</span><input type="date" id="rkw-local-order-to" name="rkw_order_to" value="' . esc_attr( is_string( $to ) ? $to : '' ) . '"></label><button type="submit" class="button">اعمال فیلتر</button></form>';
		if ( is_wp_error( $found ) ) { echo '<p class="notice notice-error">' . esc_html( $found->get_error_message() ) . '</p></section>'; return; }
		$orders = $found->orders; $pages = $found->max_num_pages; $page = $found->page;
		$s = rkw_settings();
		if ( 'invoice' !== $s['order_mode'] ) { echo '<div class="notice notice-warning inline"><p>نوع سند فعلی «سفارش فروش» است؛ ارسال جدید در فهرست فاکتورهای فروش نمایش داده نمی‌شود.</p></div>'; }
		echo '<div id="rkw-local-send-status" class="rkw-send-feedback" role="status" aria-live="polite"></div>';
		echo '<div class="rkwm-table-wrap"><table class="widefat striped rkwm-table rkw-bulk-table"><thead><tr><th><input type="checkbox" class="rkw-order-check-all" aria-label="انتخاب همه سفارش‌های قابل ارسال در این صفحه"></th><th>شناسه خرید ووکامرس</th><th>تاریخ پرداخت</th><th>نام کاربر</th><th>شناسه مشتری راهکاران</th><th>وضعیت ووکامرس</th><th>شناسه راهکاران</th><th>آخرین نتیجه</th><th>ارسال برای راهکاران</th></tr></thead><tbody>';
		$shown = 0;
		foreach ( $orders as $order ) {
			if ( ! $order instanceof WC_Order ) { continue; }
			if ( ! in_array( $order->get_status(), array( 'processing', 'completed' ), true ) ) { continue; }
			$id = (int) $order->get_id();
			$state = RKW_Order_List_UI::state( $order );
			if ( 'unsent' === $filter && ! in_array( $state, array( 'unsent', 'error' ), true ) ) { continue; }
			$shown++;
			$pending = 'pending' === $state;
			$error = (string) $order->get_meta( '_rkw_error' );
			$attempts = (int) $order->get_meta( '_rkw_attempts' );
			$info = $pending ? 'نتیجه ارسال نامشخص؛ ابتدا تطبیق دهید' : ( $error ? $error : ( 'sent' === $state ? 'ثبت تأییدشده' : ( $attempts ? 'تلاش ناموفق' : 'هنوز ارسال نشده' ) ) );
			$url = method_exists( $order, 'get_edit_order_url' ) ? $order->get_edit_order_url() : admin_url( 'post.php?post=' . $id . '&action=edit' );
			echo '<tr data-order-id="' . esc_attr( $id ) . '"><td>';
			if ( in_array( $state, array( 'error', 'unsent' ), true ) ) { echo '<input type="checkbox" class="rkw-order-check" value="' . esc_attr( $id ) . '" aria-label="انتخاب سفارش ' . esc_attr( $id ) . '">'; }
			echo '</td><td><a href="' . esc_url( $url ) . '">#' . esc_html( $order->get_order_number() ) . '</a><small class="rkw-id-note"> (ID: ' . esc_html( $id ) . ')</small></td>';
			$created = $order->get_date_created();
			echo '<td>' . esc_html( $created ? wc_format_datetime( $created, wc_date_format() . ' ' . wc_time_format() ) : '—' ) . '</td>';
			echo '<td>' . esc_html( self::order_customer_name( $order ) ) . '</td>';
			echo '<td>' . esc_html( $order->get_meta( '_rkw_customer_id' ) ?: '—' ) . '</td>';
			echo '<td>' . esc_html( wc_get_order_status_name( $order->get_status() ) ) . '</td>';
			echo '<td><span class="rkw-order-doc" data-order="' . esc_attr( $id ) . '">' . esc_html( RKW_Order_List_UI::document_label( $order ) ) . '</span></td>';
			echo '<td class="rkw-last-result">' . esc_html( $info ) . '</td>';
			echo '<td><span class="rkw-order-actions" data-order="' . esc_attr( $id ) . '">' . RKW_Order_List_UI::send_button( $order, 'ارسال برای راهکاران' ) . '</span>';
			if ( 'OK' === (string) $order->get_meta( '_rkw_doc_id' ) || ( ! $order->get_meta( '_rkw_doc_id' ) && $pending ) ) {
				echo ' <button type="button" class="button rkwm-reconcile" data-order="' . esc_attr( $id ) . '">جست‌وجو و تطبیق فاکتور</button>';
			}
			echo '</td></tr>';
		}
		if ( ! $shown ) { echo '<tr><td colspan="9">سفارشی با این فیلتر یافت نشد.</td></tr>'; }
		echo '</tbody></table></div><p><button type="button" class="button button-primary rkw-send-bulk">ارسال سفارش‌های انتخاب‌شده</button> <span class="description">حداکثر ۲۵ سفارش در هر نوبت؛ انتخاب محدود به همین صفحه است.</span></p>';
		if ( $pages > 1 ) {
			echo '<nav class="rkwm-pages rkw-local-pages" aria-label="صفحه‌بندی سفارش‌های ووکامرس">';
			for ( $n = max( 1, $page - 2 ); $n <= min( $pages, $page + 2 ); $n++ ) {
				$url = add_query_arg( array( 'rkw_orders_page' => $n, 'rkw_order_filter' => $filter, 'rkw_order_from' => $from, 'rkw_order_to' => $to ), admin_url( 'admin.php?page=rkw-invoices' ) );
				echo '<a class="button' . ( $n === $page ? ' button-primary' : '' ) . '" href="' . esc_url( $url ) . '">' . esc_html( $n ) . '</a>';
			}
			echo '<span>صفحه ' . esc_html( $page ) . ' از ' . esc_html( $pages ) . '</span></nav>';
		}
		echo '</section>';
	}

	/** Add verified local WooCommerce links to the Rahkaran invoice API table, including saved snapshots. */
	private static function decorate_invoices( $data ) {
		if ( ! is_array( $data ) || ! isset( $data['rows'] ) || ! is_array( $data['rows'] ) ) { return $data; }
		$ids = array();
		foreach ( $data['rows'] as $row ) {
			if ( isset( $row['id'] ) && preg_match( '/^[1-9][0-9]*$/', (string) $row['id'] ) && (int) $row['id'] > 0 ) { $ids[] = (string) $row['id']; }
		}
		$map = array();
		if ( $ids && function_exists( 'wc_get_orders' ) ) {
			$linked = wc_get_orders( array( 'limit' => min( 150, count( $ids ) * 2 ), 'type' => 'shop_order', 'meta_query' => array( array( 'key' => '_rkw_doc_id', 'value' => array_unique( $ids ), 'compare' => 'IN' ) ) ) );
			foreach ( is_array( $linked ) ? $linked : array() as $order ) {
				if ( ! $order instanceof WC_Order || 'invoice' !== $order->get_meta( '_rkw_doc_type' ) ) { continue; }
				$key = (string) $order->get_meta( '_rkw_doc_id' );
				if ( array_key_exists( $key, $map ) ) { $map[ $key ] = null; /* duplicate link: do not guess */ }
				else { $map[ $key ] = $order; }
			}
		}
		$data['headers'] = array( 'شناسه', 'شماره سند', 'مشتری', 'موبایل', 'مبلغ خالص', 'سیاست تسویه', 'شناسه خرید ووکامرس', 'نام کاربر', 'شناسه مشتری راهکاران' );
		foreach ( $data['rows'] as &$row ) {
			$key = isset( $row['id'] ) ? (string) $row['id'] : '';
			if ( preg_match( '/^[1-9][0-9]*$/D', $key ) ) { $row['return_status'] = RKW_Returns::status( (int) $key ); }
			$customer_id = isset( $row['rkw_customer_id'] ) ? absint( $row['rkw_customer_id'] ) : 0;
			$row['cells'] = array_slice( isset( $row['cells'] ) ? (array) $row['cells'] : array(), 0, 6 );
			$linked_order = isset( $map[ $key ] ) && $map[ $key ] instanceof WC_Order ? $map[ $key ] : null;
			$row['cells'][] = $linked_order ? (string) $linked_order->get_id() : '—';
			$row['cells'][] = $linked_order ? self::order_customer_name( $linked_order ) : '—';
			$row['cells'][] = $customer_id ? (string) $customer_id : '—';
		}
		unset( $row );
		return $data;
	}

	private static function guard() {
		if ( ! current_user_can( self::CAP ) ) { wp_send_json_error( array( 'message' => 'دسترسی غیرمجاز.' ), 403 ); }
		if ( ! check_ajax_referer( 'rkw_module', 'nonce', false ) ) { wp_send_json_error( array( 'message' => 'نشست مدیریت منقضی شده است؛ صفحه را تازه‌سازی کنید.' ), 403 ); }
	}

	private static function field( $data, $keys, $fallback = '—' ) {
		foreach ( (array) $keys as $key ) {
			if ( isset( $data[ $key ] ) && ( is_string( $data[ $key ] ) || is_numeric( $data[ $key ] ) || is_bool( $data[ $key ] ) ) && ( is_bool( $data[ $key ] ) || '' !== (string) $data[ $key ] ) ) {
				return is_bool( $data[ $key ] ) ? ( $data[ $key ] ? 'بله' : 'خیر' ) : (string) $data[ $key ];
			}
		}
		return $fallback;
	}

	private static function limit_search( $search ) {
		if ( preg_match( '/^.{0,100}/us', (string) $search, $match ) ) { return $match[0]; }
		return '';
	}

	private static function as_list( $data ) {
		if ( ! is_array( $data ) ) { return array(); }
		if ( array_key_exists( 'items', $data ) && is_array( $data['items'] ) ) { return $data['items']; }
		if ( array_key_exists( 'data', $data ) && is_array( $data['data'] ) ) { return $data['data']; }
		if ( array_values( $data ) === $data ) { return $data; }
		return array( $data );
	}

	private static function policy_methods( $row ) {
		$methods = array();
		foreach ( isset( $row['settlementMethodGroups'] ) && is_array( $row['settlementMethodGroups'] ) ? $row['settlementMethodGroups'] : array() as $group ) {
			$group_name = self::field( $group, array( 'settlementMethodGroupName' ), '' );
			foreach ( isset( $group['settlementMethods'] ) && is_array( $group['settlementMethods'] ) ? $group['settlementMethods'] : array() as $method ) {
				$name = self::field( $method, array( 'settlementMethodName', 'settlementNatureKey' ), '' );
				$key  = self::field( $method, array( 'settlementNatureKey' ), '' );
				if ( '' !== $name ) { $methods[] = trim( $group_name . ': ' . $name . ( '' !== $key ? ' [' . $key . ']' : '' ) ); }
			}
		}
		return implode( '، ', array_unique( $methods ) );
	}

	private static function fetch( $section, $page, $size, $search, $mobile, $shop, $doc_type ) {
		$c = new RKW_Client();
		if ( ! $c->is_v21() ) {
			if ( 'stores' === $section ) {
				$shops = $c->shops19();
				if ( is_wp_error( $shops ) ) { return $shops; }
				$all = array();
				foreach ( self::as_list( $shops ) as $shop_row ) {
					foreach ( isset( $shop_row['stores'] ) && is_array( $shop_row['stores'] ) ? $shop_row['stores'] : array() as $store ) { $all[] = $store; }
				}
				return $all;
			}
			if ( 'products' === $section ) { return $c->products19( ( $page - 1 ) * $size + 1, $size ); }
			return new WP_Error( 'rkw_version', 'این سرویس در رابط فعلی فقط برای نسخه ۲۱ پشتیبانی می‌شود.' );
		}
		switch ( $section ) {
			case 'stores': return $c->stores21();
			case 'customers':
				if ( '' !== $search ) { return $c->search_customers21( $search, 1, $page, $size ); }
				return $c->customers21( $page, $size );
			case 'products': return $c->products21( $page, $size, $search );
			case 'policies': return $c->settlement_policies21( $doc_type );
			case 'invoices': return $c->invoices21( $page, $size, $search, $mobile, $shop );
		}
		return new WP_Error( 'rkw_section', 'بخش نامعتبر است.' );
	}

	/** Read a declared total from an API result, without confusing list items with pagination metadata. */
	private static function declared_total( $raw ) {
		if ( ! is_array( $raw ) ) { return null; }
		foreach ( array( 'totalCount', 'TotalCount', 'totalRecords', 'TotalRecords', 'totalItems', 'TotalItems', 'recordsTotal', 'recordCount', 'total' ) as $key ) {
			if ( array_key_exists( $key, $raw ) && is_numeric( $raw[ $key ] ) && (float) $raw[ $key ] >= 0 ) {
				return max( 0, (int) $raw[ $key ] );
			}
		}
		foreach ( array( 'pagination', 'paging', 'pageInfo' ) as $key ) {
			if ( isset( $raw[ $key ] ) && is_array( $raw[ $key ] ) ) { return self::declared_total( $raw[ $key ] ); }
		}
		return null;
	}

	private static function count_cache_key( $section, $size, $search, $mobile, $shop, $doc_type ) {
		$s = rkw_settings();
		return 'rkw_pages_' . md5( wp_json_encode( array( $section, $size, $search, $mobile, $shop, $doc_type, $s['api'], $s['ip'], $s['cluster'], $s['username'], 'invoices' === $section ? (int) get_option( 'rkw_invoices_list_revision', 0 ) : 0 ) ) );
	}

	/**
	 * Compute exact totals with bounded, incremental probes. Each request reads at most
	 * THREE pages; the browser continues the search without blocking PHP for minutes.
	 * This is only used when the upstream API omits record counts.
	 */
	public static function ajax_count() {
		self::guard();
		$section = isset( $_POST['section'] ) ? sanitize_key( wp_unslash( $_POST['section'] ) ) : '';
		if ( ! in_array( $section, array( 'customers', 'products', 'invoices' ), true ) ) { wp_send_json_error( array( 'message' => 'فهرست قابل شمارش نیست.' ), 400 ); }
		$size = isset( $_POST['size'] ) ? max( 5, min( 100, absint( $_POST['size'] ) ) ) : 20;
		$search = isset( $_POST['search'] ) ? self::limit_search( sanitize_text_field( wp_unslash( $_POST['search'] ) ) ) : '';
		$mobile = isset( $_POST['mobile'] ) ? substr( preg_replace( '/[^0-9+]/', '', wp_unslash( $_POST['mobile'] ) ), 0, 20 ) : '';
		$shop = isset( $_POST['shop'] ) ? absint( $_POST['shop'] ) : 0;
		$doc_type = 1;
		$key = self::count_cache_key( $section, $size, $search, $mobile, $shop, $doc_type );
		$cached = get_transient( $key );
		if ( is_array( $cached ) && isset( $cached['total'] ) ) { wp_send_json_success( array( 'done' => true, 'total' => (int) $cached['total'] ) ); }
		$low = isset( $_POST['low'] ) ? max( 0, min( 100000, absint( $_POST['low'] ) ) ) : 1;
		$high = isset( $_POST['high'] ) ? max( 2, min( 100001, absint( $_POST['high'] ) ) ) : 2;
		$phase = isset( $_POST['phase'] ) && 'binary' === sanitize_key( $_POST['phase'] ) ? 'binary' : 'expand';
		if ( $high <= $low || $low < 1 ) { wp_send_json_error( array( 'message' => 'داده صفحه‌بندی نامعتبر است.' ), 400 ); }
		for ( $tries = 0; $tries < 3; $tries++ ) {
			if ( 'binary' === $phase && $high - $low <= 1 ) {
				$raw = self::fetch( $section, $low, $size, $search, $mobile, $shop, $doc_type );
				if ( is_wp_error( $raw ) ) { wp_send_json_error( array( 'message' => 'شمارش دقیق با پاسخ فعلی سرور ممکن نیست: ' . $raw->get_error_message() ), 502 ); }
				$length = count( self::as_list( $raw ) );
				$total = ( $low - 1 ) * $size + $length;
				set_transient( $key, array( 'total' => $total ), DAY_IN_SECONDS );
				wp_send_json_success( array( 'done' => true, 'total' => $total ) );
			}
			$probe = 'expand' === $phase ? $high : $low + (int) floor( ( $high - $low ) / 2 );
			if ( $probe > 100000 ) { wp_send_json_success( array( 'done' => false, 'unavailable' => true, 'message' => 'بازه شمارش از حد مجاز بیشتر است.' ) ); }
			$raw = self::fetch( $section, $probe, $size, $search, $mobile, $shop, $doc_type );
			if ( is_wp_error( $raw ) ) { wp_send_json_success( array( 'done' => false, 'unavailable' => true, 'message' => 'سرور اجازه بررسی تعداد صفحات را نداد.' ) ); }
			$len = count( self::as_list( $raw ) );
			if ( $len < $size && $len > 0 ) {
				$total = ( $probe - 1 ) * $size + $len;
				set_transient( $key, array( 'total' => $total ), DAY_IN_SECONDS );
				wp_send_json_success( array( 'done' => true, 'total' => $total ) );
			}
			if ( $len === $size ) { $low = $probe; }
			else { $high = $probe; $phase = 'binary'; }
			if ( 'expand' === $phase ) { $high = min( 100001, $high * 2 ); }
		}
		wp_send_json_success( array( 'done' => false, 'phase' => $phase, 'low' => $low, 'high' => $high ) );
	}

	public static function ajax_list() {
		self::guard();
		$section = isset( $_POST['section'] ) ? sanitize_key( wp_unslash( $_POST['section'] ) ) : '';
		if ( ! isset( self::$sections[ $section ] ) ) { wp_send_json_error( array( 'message' => 'بخش نامعتبر است.' ), 400 ); }
		$page     = isset( $_POST['page_num'] ) ? max( 1, min( 100000, absint( $_POST['page_num'] ) ) ) : 1;
		$size     = isset( $_POST['size'] ) ? max( 5, min( 100, absint( $_POST['size'] ) ) ) : 20;
		$search   = isset( $_POST['search'] ) ? self::limit_search( sanitize_text_field( wp_unslash( $_POST['search'] ) ) ) : '';
		$mobile   = isset( $_POST['mobile'] ) ? substr( preg_replace( '/[^0-9+]/', '', wp_unslash( $_POST['mobile'] ) ), 0, 20 ) : '';
		$shop     = isset( $_POST['shop'] ) ? absint( $_POST['shop'] ) : 0;
		$doc_type = isset( $_POST['doc_type'] ) && 2 === absint( $_POST['doc_type'] ) ? 2 : 1;
		$force = isset( $_POST['force'] ) && '1' === (string) wp_unslash( $_POST['force'] );
		$view = array( 'page' => $page, 'size' => $size, 'search' => $search, 'mobile' => $mobile, 'shop' => $shop, 'docType' => $doc_type );
		$cache_key = RKW_Snapshot::key( $section, $page, $size, $search, $mobile, $shop, $doc_type );
		if ( ! $force ) {
			$existing = RKW_Snapshot::read( $cache_key );
			if ( null !== $existing ) {
				RKW_Snapshot::remember_view( $section, $view );
				$out = $existing['data'];
				$out['source'] = 'saved';
				$out['saved_at'] = $existing['saved_at'];
				$out['persisted'] = true;
				wp_send_json_success( 'invoices' === $section ? self::decorate_invoices( $out ) : $out );
			}
		}
		$raw = self::fetch( $section, $page, $size, $search, $mobile, $shop, $doc_type );
		if ( is_wp_error( $raw ) ) { wp_send_json_error( array( 'message' => $raw->get_error_message() ), 502 ); }
		$list = self::as_list( $raw );
		if ( in_array( $section, array( 'stores', 'policies' ), true ) ) {
			$all_count = count( $list );
			$list = array_slice( $list, ( $page - 1 ) * $size, $size );
			$has_next = $page * $size < $all_count;
		} else {
			$all_count = self::declared_total( $raw );
			if ( null === $all_count && count( $list ) < $size && ( 1 === $page || count( $list ) > 0 ) ) {
				$all_count = ( $page - 1 ) * $size + count( $list );
			}
			if ( null === $all_count ) {
				$cached = get_transient( self::count_cache_key( $section, $size, $search, $mobile, $shop, $doc_type ) );
				if ( is_array( $cached ) && isset( $cached['total'] ) ) { $all_count = (int) $cached['total']; }
			}
			$has_next = null === $all_count ? count( $list ) >= $size : $page * $size < $all_count;
		}
		$rows = array();
		foreach ( $list as $row ) {
			if ( ! is_array( $row ) ) { continue; }
			switch ( $section ) {
				case 'stores':
					$rows[] = array( 'id' => self::field( $row, array( 'storeId', 'id' ) ), 'cells' => array( self::field( $row, array( 'storeId', 'id' ) ), self::field( $row, array( 'storeCode', 'code' ) ), self::field( $row, array( 'storeName', 'name' ) ), self::field( $row, array( 'immediateDelivery' ) ), self::field( $row, array( 'reservedDelivery' ) ) ) );
					break;
				case 'customers':
					$rows[] = array( 'id' => self::field( $row, array( 'id', 'Id' ) ), 'cells' => array( self::field( $row, array( 'id', 'Id' ) ), self::field( $row, array( 'code', 'number' ) ), trim( self::field( $row, array( 'customerName', 'firstName' ), '' ) . ' ' . ( isset( $row['customerName'] ) ? '' : self::field( $row, array( 'lastName' ), '' ) ) ), self::field( $row, array( 'mobile' ) ), self::field( $row, array( 'nationalCode', 'nationalID' ) ) ) );
					break;
				case 'products':
					$rows[] = array( 'id' => self::field( $row, array( 'productId', 'id' ) ), 'detail' => true, 'cells' => array( self::field( $row, array( 'productId', 'id' ) ), self::field( $row, array( 'productNumber', 'code' ) ), self::field( $row, array( 'productName', 'name' ) ), self::field( $row, array( 'unitName', 'retailUnitName' ) ), self::field( $row, array( 'fee', 'price' ) ) ) );
					break;
				case 'policies':
					$rows[] = array( 'id' => self::field( $row, array( 'settlementPolicyID', 'id' ) ), 'cells' => array( self::field( $row, array( 'settlementPolicyID', 'id' ) ), self::field( $row, array( 'settlementPolicyName', 'name' ) ), self::policy_methods( $row ) ), 'selectable' => true );
					break;
				case 'invoices':
					$rows[] = array( 'id' => self::field( $row, array( 'id', 'Id' ) ), 'detail' => true, 'rkw_customer_id' => self::field( $row, array( 'customerId', 'CustomerId', 'customerID' ), '0' ), 'cells' => array( self::field( $row, array( 'id', 'Id' ) ), self::field( $row, array( 'number' ) ), self::field( $row, array( 'customerName' ) ), self::field( $row, array( 'customerMobile' ) ), self::field( $row, array( 'netPrice', 'price' ) ), self::field( $row, array( 'settlementPolicyTitle' ) ) ) );
					break;
			}
		}
		// Keep a small, non-sensitive per-product copy in the existing bounded page snapshot.
		// Product saves reuse this first; they never have to download an entire list.
		$catalog_items = array();
		if ( 'products' === $section ) {
			$api = rkw_settings();
			foreach ( $list as $product_row ) {
				$normalized = RKW_Sync::normalize_single( $product_row, $api['api'] );
				if ( $normalized ) { $catalog_items[ $normalized['id'] ] = $normalized; }
			}
		}
		$headers = array(
			'stores' => array( 'شناسه', 'کد انبار', 'نام انبار', 'تحویل فوری', 'تحویل رزروی' ),
			'customers' => array( 'شناسه', 'کد مشتری', 'نام مشتری', 'موبایل', 'کد ملی' ),
			'products' => array( 'شناسه', 'کد کالا', 'عنوان محصول', 'واحد', 'قیمت پایه' ),
			'policies' => array( 'شناسه', 'نام سیاست', 'روش‌های تسویه / کلیدها' ),
			'invoices' => array( 'شناسه', 'شماره سند', 'مشتری', 'موبایل', 'مبلغ خالص', 'سیاست تسویه' ),
		);
		$result = array( 'headers' => $headers[ $section ], 'rows' => $rows, 'count' => count( $rows ), 'total' => $all_count, 'has_next' => $has_next, 'page' => $page, 'pages' => null === $all_count ? null : max( 1, (int) ceil( $all_count / $size ) ), 'section' => $section );
		if ( 'products' === $section ) { $result['catalog_items'] = $catalog_items; $result['snapshot_params'] = array( 'page' => $page, 'size' => $size, 'search' => $search ); }
		// A successful explicit refresh replaces the previous snapshot. Failed requests leave it intact.
		$persisted = RKW_Snapshot::save( $cache_key, $result );
		RKW_Snapshot::remember_view( $section, $view );
		if ( $force ) { delete_transient( self::count_cache_key( $section, $size, $search, $mobile, $shop, $doc_type ) ); }
		$result['source'] = 'fresh';
		$result['saved_at'] = time();
		$result['persisted'] = $persisted;
		wp_send_json_success( 'invoices' === $section ? self::decorate_invoices( $result ) : $result );
	}

	public static function ajax_detail() {
		self::guard();
		$section = isset( $_POST['section'] ) ? sanitize_key( wp_unslash( $_POST['section'] ) ) : '';
		$id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
		if ( ! $id || ! in_array( $section, array( 'products', 'invoices' ), true ) ) { wp_send_json_error( array( 'message' => 'شناسه نامعتبر است.' ), 400 ); }
		$c = new RKW_Client();
		if ( ! $c->is_v21() ) { wp_send_json_error( array( 'message' => 'جزئیات این صفحه فقط برای نسخه ۲۱ در دسترس است.' ), 400 ); }
		$r = 'products' === $section ? $c->remaining21( $id ) : $c->invoice21( $id );
		if ( is_wp_error( $r ) ) { wp_send_json_error( array( 'message' => $r->get_error_message() ), 502 ); }
		// Restrict fields to relevant operational information; do not expose raw unbounded API payloads.
		$out = array();
		if ( 'products' === $section ) {
			foreach ( self::as_list( $r ) as $line ) {
				if ( ! is_array( $line ) ) { continue; }
				$out[] = array( 'انبار' => self::field( $line, array( 'StoreName', 'storeName', 'inventoryName', 'StoreID', 'storeId', 'inventoryId' ) ), 'موجودی' => self::field( $line, array( 'RemainingQuantity', 'remainingQuantity', 'quantity', 'remaining' ) ), 'موجودی فیزیکی' => self::field( $line, array( 'InventoryPhysicalQuantity', 'inventoryPhysicalQuantity' ) ), 'رزرو فروش' => self::field( $line, array( 'RetailReserveQuantity', 'retailReserveQuantity' ) ), 'رزرو انبار' => self::field( $line, array( 'InventoryReserveQuantity', 'inventoryReserveQuantity' ) ) );
			}
		} else {
			if ( is_array( $r ) ) {
				$out[] = array( 'شناسه' => self::field( $r, array( 'id', 'Id' ) ), 'شماره' => self::field( $r, array( 'number' ) ), 'مشتری' => self::field( $r, array( 'customerName' ) ), 'شماره موبایل' => self::field( $r, array( 'customerMobile' ) ), 'مبلغ خالص' => self::field( $r, array( 'netPrice' ) ), 'انبار' => self::field( $r, array( 'inventoryName' ) ), 'سیاست تسویه' => self::field( $r, array( 'settlementPolicyTitle' ) ), 'توضیحات' => self::field( $r, array( 'description' ) ) );
			}
		}
		wp_send_json_success( array( 'items' => $out ) );
	}


	/** Read-only, field-limited receipt inspection for a confirmed Rahkaran invoice. */
	public static function ajax_invoice_settlement() {
		self::guard();
		$id = isset( $_POST['invoice_id'] ) ? absint( $_POST['invoice_id'] ) : 0;
		$order_id = isset( $_POST['order_id'] ) ? absint( $_POST['order_id'] ) : 0;
		if ( ! $id ) { wp_send_json_error( array( 'message' => 'شناسه فاکتور معتبر نیست.' ), 400 ); }
		$c = new RKW_Client();
		if ( ! $c->is_v21() ) { wp_send_json_error( array( 'message' => 'این قابلیت فقط برای API نسخه ۲۱ فعال است.' ), 400 ); }
		$invoice = $c->invoice21( $id );
		if ( is_wp_error( $invoice ) ) { wp_send_json_error( array( 'message' => $invoice->get_error_message() ), 502 ); }
		if ( ! is_array( $invoice ) || ! isset( $invoice['id'] ) || (int) $invoice['id'] !== $id ) {
			wp_send_json_error( array( 'message' => 'پاسخ GetInvoice معتبر نیست یا شناسه سند با درخواست تطابق ندارد.' ), 502 );
		}
		$view = self::settlement_view( $invoice, $id );
		if ( $order_id ) { $view['comparison'] = self::settlement_compare_order( $order_id, $view ); }
		wp_send_json_success( $view );
	}

	/** Avoid leaking private data or full transaction identifiers to the admin browser. */
	private static function masked_identifier( $value ) {
		if ( ! is_scalar( $value ) || '' === trim( (string) $value ) ) { return 'ثبت نشده'; }
		$normal = preg_replace( '/[^\\p{L}\\p{N}]/u', '', (string) $value );
		if ( ! is_string( $normal ) || '' === $normal ) { return 'ثبت شده (پنهان)'; }
		return '••••' . ( function_exists( 'mb_substr' ) ? mb_substr( $normal, -4, 4, 'UTF-8' ) : substr( $normal, -4 ) );
	}

	private static function settlement_amount( $value ) {
		return is_numeric( $value ) ? number_format_i18n( (float) $value, 0 ) : 'نامشخص';
	}

	private static function settlement_number( $value ) {
		return is_numeric( $value ) ? (string) (int) $value : 'در پاسخ موجود نیست';
	}

	private static function settlement_date( $value ) {
		if ( is_numeric( $value ) && (int) $value > 946684800 && (int) $value < 4102444800 ) {
			return wp_date( 'Y/m/d H:i', (int) $value );
		}
		return 'در پاسخ موجود نیست';
	}

	/** Normalize only published receipt fields; card/customer/raw response is intentionally excluded. */
	private static function settlement_view( $invoice, $id ) {
		$raw_receipts = isset( $invoice['receipts'] ) && is_array( $invoice['receipts'] ) ? $invoice['receipts'] : array();
		$raw_payments = isset( $invoice['payments'] ) && is_array( $invoice['payments'] ) ? $invoice['payments'] : array();
		$view = array(
			'invoice_id' => $id,
			'invoice_number' => self::field( $invoice, array( 'number' ), 'در پاسخ موجود نیست' ),
			'policy_id' => self::settlement_number( isset( $invoice['settlementPolicyId'] ) ? $invoice['settlementPolicyId'] : null ),
			'policy_title' => self::field( $invoice, array( 'settlementPolicyTitle' ), 'در پاسخ موجود نیست' ),
			'net_price' => self::settlement_amount( isset( $invoice['netPrice'] ) ? $invoice['netPrice'] : null ),
			'currency' => self::field( $invoice, array( 'currencyTitle', 'currencyId' ), 'طبق واحد سند راهکاران' ),
			'receipts' => array(),
			'payments' => array(),
			'safe_receipts_json' => array(),
			'note' => 'GetInvoice لزوماً همان فیلدهای درخواست SaveInvoice را برنمی‌گرداند. نوع دریافت الکترونیک از فیلد details.type گزارش می‌شود؛ این مقدار معادل قطعی eReceiptType ورودی نیست.',
		);
		foreach ( array_slice( $raw_receipts, 0, 50 ) as $entry ) {
			if ( ! is_array( $entry ) ) { continue; }
			$details = isset( $entry['details'] ) && is_array( $entry['details'] ) ? $entry['details'] : array();
			$key = self::field( $entry, array( 'settlementNature', 'key' ), 'نامشخص' );
			$view['safe_receipts_json'][] = array(
				'settlementNature' => preg_replace( '/[^A-Za-z0-9_]/', '', (string) $key ),
				'amount' => isset( $entry['amount'] ) && is_numeric( $entry['amount'] ) ? (float) $entry['amount'] : null,
				'settlementMethodTitle' => self::field( $entry, array( 'settlementMethodTitle' ), '' ),
				'details' => array(
					'bankId' => isset( $details['bankId'] ) && is_numeric( $details['bankId'] ) ? (int) $details['bankId'] : null,
					'bankAccountId' => isset( $details['bankAccountId'] ) && is_numeric( $details['bankAccountId'] ) ? (int) $details['bankAccountId'] : null,
					'type' => isset( $details['type'] ) && is_numeric( $details['type'] ) ? (int) $details['type'] : null,
					'typeTitle' => self::field( $details, array( 'typeTitle' ), '' ),
					'eReceiptType' => self::field( $details, array( 'eReceiptType' ), null ),
					'date' => isset( $details['date'] ) && is_numeric( $details['date'] ) ? (int) $details['date'] : null,
					'transactionNumber' => self::masked_identifier( isset( $details['transactionNumber'] ) ? $details['transactionNumber'] : null ),
					'trackingNumber' => self::masked_identifier( isset( $details['trackingNumber'] ) ? $details['trackingNumber'] : null ),
					'terminalNumber' => self::masked_identifier( isset( $details['terminalNumber'] ) ? $details['terminalNumber'] : null ),
				),
			);
			$view['receipts'][] = array(
				'نوع دریافت' => preg_replace( '/[^A-Za-z0-9_]/', '', (string) $key ),
				'عنوان روش' => self::field( $entry, array( 'settlementMethodTitle' ), '—' ),
				'مبلغ دریافت' => self::settlement_amount( isset( $entry['amount'] ) ? $entry['amount'] : null ),
				'بانک (bankId)' => self::settlement_number( isset( $details['bankId'] ) ? $details['bankId'] : null ),
				'حساب بانکی (bankAccountId)' => self::settlement_number( isset( $details['bankAccountId'] ) ? $details['bankAccountId'] : null ),
				'نوع الکترونیکی برگشتی (details.type)' => self::settlement_number( isset( $details['type'] ) ? $details['type'] : null ),
				'عنوان نوع الکترونیکی (typeTitle)' => self::field( $details, array( 'typeTitle' ), 'در پاسخ موجود نیست' ),
				'eReceiptType در خروجی' => self::field( $details, array( 'eReceiptType' ), 'در GetInvoice موجود نیست' ),
				'تاریخ دریافت' => self::settlement_date( isset( $details['date'] ) ? $details['date'] : null ),
				'شماره پیگیری' => self::masked_identifier( isset( $details['trackingNumber'] ) ? $details['trackingNumber'] : null ),
				'شماره تراکنش' => self::masked_identifier( isset( $details['transactionNumber'] ) ? $details['transactionNumber'] : null ),
				'شماره پایانه' => self::masked_identifier( isset( $details['terminalNumber'] ) ? $details['terminalNumber'] : null ),
			);
		}
		foreach ( array_slice( $raw_payments, 0, 50 ) as $entry ) {
			if ( ! is_array( $entry ) ) { continue; }
			$view['payments'][] = array(
				'نوع پرداخت خروجی' => preg_replace( '/[^A-Za-z0-9_]/', '', self::field( $entry, array( 'settlementNature', 'key' ), '' ) ),
				'مبلغ' => self::settlement_amount( isset( $entry['amount'] ) ? $entry['amount'] : null ),
			);
		}
		$view['receipt_count'] = count( $raw_receipts );
		$view['payment_count'] = count( $raw_payments );
		$view['receipt_keys'] = array_map( static function ( $item ) { return $item['نوع دریافت']; }, $view['receipts'] );
		return $view;
	}

	/** Optional comparison reads WooCommerce order metadata/settings only; never sends a document. */
	private static function settlement_compare_order( $order_id, $view ) {
		if ( ! function_exists( 'wc_get_order' ) ) { return array( 'error' => 'ووکامرس فعال نیست.' ); }
		$order = wc_get_order( $order_id );
		if ( ! $order instanceof WC_Order ) { return array( 'error' => 'سفارش ووکامرس با این شناسه پیدا نشد.' ); }
		if ( ! class_exists( 'RKW_Payment' ) ) { return array( 'error' => 'ماژول تنظیمات پرداخت در دسترس نیست.' ); }
		$pay = RKW_Payment::resolve( $order, rkw_settings() );
		if ( is_wp_error( $pay ) ) { return array( 'error' => $pay->get_error_message() ); }
		$policy_matches = (string) $pay['settlement_id'] === (string) $view['policy_id'];
		$key_matches = in_array( (string) $pay['receipt_key'], $view['receipt_keys'], true );
		return array(
			'سفارش ووکامرس' => (string) $order_id,
			'شناسه درگاه' => (string) $order->get_payment_method(),
			'منبع تنظیم' => isset( $pay['mapping_source'] ) ? (string) $pay['mapping_source'] : 'نامشخص',
			'سیاست تنظیم‌شده افزونه' => (string) $pay['settlement_id'],
			'تطابق سیاست با فاکتور' => $policy_matches ? 'مطابق' : 'متفاوت',
			'نوع دریافت تنظیم‌شده' => (string) $pay['receipt_key'],
			'تطابق با دریافت‌های فاکتور' => $view['receipt_count'] ? ( $key_matches ? 'مطابق' : 'متفاوت' ) : 'فاکتور فاقد دریافت است',
			'bankAccountRef تنظیم‌شده' => (string) $pay['bank_account_ref'],
			'eReceiptType برای ارسال' => isset( $pay['e_receipt_mode'] ) && 'explicit' === $pay['e_receipt_mode'] ? (string) $pay['e_receipt_type'] : 'ارسال نمی‌شود',
			'هشدار مقایسه' => 'این مقایسه میان فاکتور انتخابی و تنظیمات سفارش واردشده است، نه اثبات ارتباط آن دو. شناسه bankAccountId خروجی و bankAccountRef ورودی لزوماً هم‌معنا نیستند. سندی ارسال نمی‌شود.',
		);
	}

	public static function ajax_policy_select() {
		self::guard();
		$id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
		$type = isset( $_POST['doc_type'] ) && 2 === absint( $_POST['doc_type'] ) ? 2 : 1;
		$s = rkw_settings();
		$required_type = 'invoice' === $s['order_mode'] ? 1 : 2;
		if ( ! $id || $type !== $required_type ) { wp_send_json_error( array( 'message' => 'نوع سیاست باید با نوع سند فعلی در تنظیمات سفارش‌ها هماهنگ باشد.' ), 400 ); }
		$c = new RKW_Client();
		if ( ! $c->is_v21() ) { wp_send_json_error( array( 'message' => 'فقط نسخه ۲۱ پشتیبانی می‌شود.' ), 400 ); }
		$policies = $c->settlement_policies21( $type );
		if ( is_wp_error( $policies ) ) { wp_send_json_error( array( 'message' => $policies->get_error_message() ), 502 ); }
		$found = false;
		foreach ( self::as_list( $policies ) as $policy ) {
			if ( is_array( $policy ) && $id === (int) self::field( $policy, array( 'settlementPolicyID', 'id' ), '0' ) ) { $found = true; break; }
		}
		if ( ! $found ) { wp_send_json_error( array( 'message' => 'این سیاست در فهرست معتبر راهکاران پیدا نشد.' ), 400 ); }
		$old = get_option( RKW_OPT, array() );
		if ( ! is_array( $old ) ) { $old = array(); }
		$old['settlement_id'] = $id; // Preserve legacy setting for existing installations.
		$old[ 1 === $type ? 'invoice_settlement_id' : 'order_settlement_id' ] = $id;
		update_option( RKW_OPT, $old );
		wp_send_json_success( array( 'message' => 'شناسه سیاست تسویه در تنظیمات ارسال سفارش ذخیره شد.', 'id' => $id ) );
	}
}
