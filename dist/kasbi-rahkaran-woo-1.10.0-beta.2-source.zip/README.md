# nooshika — Kasbi Rahkaran WooCommerce

نسخه اصلاح‌شده آزمایشی `1.10.0-beta.1` بر پایه فایل ارسالی `1.9.17`.

- افزونه قابل نصب: `rahkaran-woo/`؛ پوشه نصب اصلی حفظ شده است.
- گزارش فارسی تغییرات، وضعیت پوشش و بررسی روی سایت: [docs/implementation-review-fa.md](docs/implementation-review-fa.md).
- فهرست مقایسه ایستای ۱۰۳ نمونه API: [docs/endpoint-inventory.md](docs/endpoint-inventory.md).
- آزمون مرزهای HTTP و WordPress/WooCommerce: `php -n tests/run.php` (برای runner به PHP 7.4+ و OpenSSL نیاز است).

این پروژه هنوز برابری کامل با افزونه قدیمی یا ثبت موفق روی سرور واقعی را ادعا نمی‌کند. سورس اصلی قدیمی با ionCube رمزگذاری شده و قابلیت‌های منتقل‌نشده در گزارش مشخص شده‌اند. اطلاعات اتصال یا نمونه‌های محیط دارای مقادیر محرمانه در مخزن کپی نشده‌اند.
