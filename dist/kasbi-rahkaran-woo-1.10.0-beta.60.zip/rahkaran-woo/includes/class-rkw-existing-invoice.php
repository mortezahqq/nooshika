<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Admin chooses an existing document only; all remote operations are GET. */
class RKW_Existing_Invoice {
 public static function init() {
  foreach ( array( 'list', 'prepare', 'attach' ) as $action ) { add_action( 'wp_ajax_rkw_existing_invoice_' . $action, array( __CLASS__, 'ajax_' . $action ) ); }
 }
 private static function key( $order_id ) { return 'rkw_existing_' . get_current_user_id() . '_' . $order_id; }
 private static function guard() {
  if ( ! current_user_can( 'manage_woocommerce' ) || ! check_ajax_referer( 'rkw_order_send', 'nonce', false ) ) { wp_send_json_error( array( 'message'=>'دسترسی یا نشست نامعتبر است.' ),403 ); }
  $id = isset( $_POST['order_id'] ) && is_scalar( $_POST['order_id'] ) ? absint( $_POST['order_id'] ) : 0;
  $o = $id ? wc_get_order( $id ) : false;
  if ( ! $o instanceof WC_Order || 'shop_order' !== $o->get_type() || 'v21' !== rkw_settings()['api'] ) { wp_send_json_error( array( 'message'=>'سفارش یا اتصال نسخه ۲۱ معتبر نیست.' ),400 ); }
  return $o;
 }
 private static function reply( $r ) { if ( is_wp_error( $r ) ) { wp_send_json_error( array( 'message'=>$r->get_error_message() ),409 ); } wp_send_json_success( $r ); }
 public static function candidates( WC_Order $o, $page ) {
  $page = max( 1,(int)$page ); $r=(new RKW_Client())->invoices21($page,20);
  if(is_wp_error($r)){return $r;}
  $rows=is_array($r)&&isset($r['items'])?$r['items']:$r;
  if(!is_array($rows)||array_values($rows)!==$rows){return new WP_Error('rkw_existing_list','قالب فهرست فاکتورها معتبر نیست.');}
  $s=rkw_settings();$amount=round((float)$o->get_total()*rkw_price_multiplier($s),2);$cid=(int)$o->get_meta('_rkw_customer_id');$out=array();
  foreach($rows as$row){
   $id=RKW_Reconciliation::invoice_id($row);if(!$id){return new WP_Error('rkw_existing_list','شناسه معتبر در فهرست فاکتورها موجود نیست.');}
   if(isset($row['netPrice'])&&is_numeric($row['netPrice'])&&abs((float)$row['netPrice']-$amount)>0.01){continue;}
   if($cid&&isset($row['customerId'])&&(int)$row['customerId']!==$cid){continue;}
   $out[]=array('id'=>$id,'number'=>isset($row['number'])&&is_scalar($row['number'])?sanitize_text_field((string)$row['number']):'',
    'date'=>isset($row['documentDate'])&&is_string($row['documentDate'])?sanitize_text_field($row['documentDate']):'',
    'amount'=>isset($row['netPrice'])&&is_numeric($row['netPrice'])?(float)$row['netPrice']:null);
  }
  return array('page'=>$page,'has_next'=>count($rows)>=20,'rows'=>$out,'scanned'=>count($rows));
 }
 private static function item_map( $items ) {
  $out=array();foreach($items as$item){
   if(!is_array($item)||empty($item['productId'])||empty($item['unitId'])||!isset($item['quantity'])||!is_numeric($item['quantity'])||!is_finite((float)$item['quantity'])||(float)$item['quantity']<=0){return false;}
   $key=(int)$item['productId'].':'.(int)$item['unitId'];$out[$key]=isset($out[$key])?$out[$key]+(float)$item['quantity']:(float)$item['quantity'];
  }ksort($out);return $out;
 }
 private static function validate( WC_Order $o,$detail,$id ) {
  $s=rkw_settings();$cid=(int)$o->get_meta('_rkw_customer_id');
  if(RKW_Reconciliation::invoice_id($detail)!==$id){return new WP_Error('rkw_existing_id','شناسه جزئیات فاکتور با انتخاب شما برابر نیست.');}
  if('conflict'===RKW_Reconciliation::reference_status($detail,$o)){return new WP_Error('rkw_existing_reference','این فاکتور شماره سفارش دیگری را در توضیحات دارد و به این سفارش متصل نمی‌شود.');}
  if(!$cid||!isset($detail['customerId'])||(int)$detail['customerId']!==$cid){return new WP_Error('rkw_existing_customer','شناسه مشتری فاکتور و سفارش برابر یا قابل تأیید نیست.');}
  if(!isset($detail['netPrice'])||!is_numeric($detail['netPrice'])||abs((float)$detail['netPrice']-round((float)$o->get_total()*rkw_price_multiplier($s),2))>0.01||!isset($detail['currencyId'])||(int)$detail['currencyId']!==(int)$s['currency_id']){return new WP_Error('rkw_existing_amount','مبلغ یا ارز فاکتور با سفارش برابر نیست؛ اتصال انجام نشد.');}
  $own=trim((string)$o->get_meta('_rkw_doc_id'));if(preg_match('/^[1-9][0-9]*$/D',$own)&&(int)$own!==$id){return new WP_Error('rkw_existing_own','این سفارش از قبل شناسه سند دیگری دارد.');}
  $expected=array();foreach($o->get_items()as$it){$p=$it->get_product();$rid=$p?(int)$p->get_meta('_rahkaran_product_id'):0;$unit=$p?(int)$p->get_meta('_rahkaran_unit_id'):0;if(!$unit){$unit=(int)$s['default_unit_id'];}if(!$rid||!$unit){return new WP_Error('rkw_existing_items','اتصال کالاهای این سفارش برای تأیید اقلام کامل نیست.');}$expected[]=array('productId'=>$rid,'unitId'=>$unit,'quantity'=>$it->get_quantity());}
  $ext=RKW_Extensions::settings();$shipping=(float)$o->get_shipping_total()+(float)$o->get_shipping_tax();
  if($shipping>0&&'product'===$ext['shipping_mode']){return new WP_Error('rkw_existing_shipping','این سفارش کالای خدمات حمل دارد؛ اتصال دستی نیازمند تطبیق دقیق سند حمل است. از تطبیق خودکار شماره سفارش استفاده کنید.');}
  $actual=self::item_map(isset($detail['items'])&&is_array($detail['items'])?$detail['items']:array());$want=self::item_map($expected);
  if(!$actual||!$want||array_keys($actual)!==array_keys($want)){return new WP_Error('rkw_existing_items','کالاها و واحدهای فاکتور با سفارش یکسان نیستند.');}
  foreach($want as$k=>$qty){if(abs($qty-$actual[$k])>0.000001){return new WP_Error('rkw_existing_quantity','تعداد اقلام فاکتور با سفارش برابر نیست.');}}
  return true;
 }
 private static function binding_check( WC_Order $o,$id ) {
  $orders=wc_get_orders(array('type'=>'shop_order','limit'=>2,'return'=>'ids','meta_key'=>'_rkw_doc_id','meta_value'=>(string)$id));
  if(is_wp_error($orders)||!is_array($orders)){return new WP_Error('rkw_existing_read','بررسی اتصال فعلی فاکتور ناموفق بود.');}
  foreach($orders as$other){if((int)$other!==(int)$o->get_id()){return new WP_Error('rkw_existing_bound','این فاکتور قبلاً به سفارش دیگری متصل شده است.');}}
  global$wpdb;$rows=$wpdb->get_results($wpdb->prepare("SELECT om.meta_value AS bound_order FROM {$wpdb->posts} p INNER JOIN {$wpdb->postmeta} im ON im.post_id=p.ID AND im.meta_key='invoice_id' INNER JOIN {$wpdb->postmeta} om ON om.post_id=p.ID AND om.meta_key='order_id' WHERE p.post_type='rahkaran-invoice' AND im.meta_value=%s",(string)$id),ARRAY_A);
  if(!empty($wpdb->last_error)||!is_array($rows)){return new WP_Error('rkw_existing_read','بررسی اتصال قدیمی فاکتور ناموفق بود.');}
  foreach($rows as$row){if(!empty($row['bound_order'])&&(int)$row['bound_order']!==(int)$o->get_id()){return new WP_Error('rkw_existing_bound','در سوابق قدیمی این فاکتور به سفارش دیگری متصل است.');}}
  return true;
 }
 private static function signature( $d ) {return hash('sha256',wp_json_encode(array($d['id']??$d['Id']??null,$d['customerId']??null,$d['netPrice']??null,$d['currencyId']??null,$d['description']??null,$d['items']??null,$d['documentDate']??null,$d['number']??null)));}
 public static function prepare( WC_Order $o,$id ) {
  $fingerprint=RKW_Reconciliation::order_fingerprint($o);if(is_wp_error($fingerprint)){return $fingerprint;}
  $d=(new RKW_Client())->invoice21($id);if(is_wp_error($d)){return $d;}$v=self::validate($o,$d,$id);if(is_wp_error($v)){return $v;}$v=self::binding_check($o,$id);if(is_wp_error($v)){return $v;}
  $token=wp_generate_uuid4();set_transient(self::key($o->get_id()),array('token'=>$token,'invoice_id'=>$id,'order'=>$fingerprint,'document'=>self::signature($d)),10*MINUTE_IN_SECONDS);
  return array('token'=>$token,'invoice_id'=>$id,'order_id'=>$o->get_id(),'amount'=>(float)$d['netPrice'],'number'=>isset($d['number'])?sanitize_text_field((string)$d['number']):'',
   'date'=>isset($d['documentDate'])?sanitize_text_field((string)$d['documentDate']):'','item_count'=>count($d['items']),'has_order_reference'=>'match'===RKW_Reconciliation::reference_status($d,$o));
 }
 public static function attach( WC_Order $o,$token ) {
  $key=self::key($o->get_id());$p=get_transient($key);if(!is_array($p)||!isset($p['token'])||!hash_equals($p['token'],$token)){return new WP_Error('rkw_existing_expired','پیش‌نمایش اتصال منقضی شده است؛ فاکتور را دوباره بررسی کنید.');}
  $lock='rkw_order_lock_'.$o->get_id();$doclock='rkw_existing_invoice_lock_'.$p['invoice_id'];
  if(!add_option($doclock,array('started'=>time()),'',false)){return new WP_Error('rkw_existing_busy','اتصال همین فاکتور در عملیات دیگری در حال انجام است.');}
  try{
   if(!add_option($lock,array('started'=>time()),'',false)){return new WP_Error('rkw_existing_busy','عملیات دیگری روی سفارش در جریان است.');}
   try{
    $fresh=wc_get_order($o->get_id());if($fresh instanceof WC_Order){$o=$fresh;}if(method_exists($o,'read_meta_data')){$o->read_meta_data(true);}
    $f=RKW_Reconciliation::order_fingerprint($o);if(is_wp_error($f)||!hash_equals($p['order'],$f)){return new WP_Error('rkw_existing_changed','سفارش یا تنظیمات تغییر کرده است؛ پیش‌نمایش اتصال را دوباره بگیرید.');}
    $d=(new RKW_Client())->invoice21($p['invoice_id']);if(is_wp_error($d)){return $d;}$v=self::validate($o,$d,$p['invoice_id']);if(is_wp_error($v)){return $v;}
    if(!hash_equals($p['document'],self::signature($d))){return new WP_Error('rkw_existing_changed','فاکتور راهکاران تغییر کرده است؛ دوباره بررسی کنید.');}
    $v=self::binding_check($o,$p['invoice_id']);if(is_wp_error($v)){return $v;}
    $fresh=wc_get_order($o->get_id());if($fresh instanceof WC_Order){$o=$fresh;}if(method_exists($o,'read_meta_data')){$o->read_meta_data(true);}
    $f=RKW_Reconciliation::order_fingerprint($o);if(is_wp_error($f)||!hash_equals($p['order'],$f)){return new WP_Error('rkw_existing_changed','سوابق سفارش هنگام بررسی تغییر کرد.');}
    $o->update_meta_data('_rkw_doc_id',(string)$p['invoice_id']);$o->update_meta_data('_rkw_doc_type','invoice');$o->delete_meta_data('_rkw_reconcile_required');$o->delete_meta_data('_rkw_error');$o->save();
    wp_clear_scheduled_hook('rkw_send_order',array((int)$o->get_id()));RKW_Order_List_UI::clear_document_cache();RKW_Snapshot::invalidate_section('invoices');delete_transient($key);
    $message='فاکتور موجود #'.$p['invoice_id'].' با انتخاب و تأیید مدیر به سفارش متصل شد؛ سند تازه‌ای صادر نشد.';$o->add_order_note($message);RKW_Log::add('info','سفارش #'.$o->get_id().': '.$message);
    return array('id'=>$o->get_id(),'status'=>'confirmed','document'=>RKW_Order_List_UI::document_label($o),'message'=>$message);
   }finally{delete_option($lock);}
  }finally{delete_option($doclock);}
 }
 public static function ajax_list(){ $o=self::guard();$page=isset($_POST['page'])&&is_scalar($_POST['page'])?absint($_POST['page']):1;self::reply(self::candidates($o,$page)); }
 public static function ajax_prepare(){ $o=self::guard();$id=isset($_POST['invoice_id'])&&is_scalar($_POST['invoice_id'])?absint($_POST['invoice_id']):0;if(!$id){self::reply(new WP_Error('rkw_existing_id','شناسه داخلی فاکتور را انتخاب کنید.'));}self::reply(self::prepare($o,$id)); }
 public static function ajax_attach(){ $o=self::guard();$token=isset($_POST['token'])&&is_string($_POST['token'])?sanitize_text_field($_POST['token']):'';if(empty($_POST['confirm'])||'1'!==$_POST['confirm']){self::reply(new WP_Error('rkw_existing_consent','انتخاب فاکتور را در پیش‌نمایش تأیید کنید.'));}self::reply(self::attach($o,$token)); }
}
