/* Policy IDs and receipt keys are populated from the actual connected Rahkaran instance. */
(function () {
  'use strict';
  var cfg = window.rkwPolicyConfig || {};
  var root = document.querySelector('.rkw-admin');
  if (!root) return;
  var catalog = cfg.catalog && typeof cfg.catalog === 'object' && !Array.isArray(cfg.catalog) ? cfg.catalog : {};
  var btn = document.getElementById('rkw-load-policy-catalog');
  var feedback = document.getElementById('rkw-policy-feedback');
  var directory = document.getElementById('rkw-policy-directory');
  var mode = document.querySelector('select[name="rkw[order_mode]"]');
  var table = root.querySelector('.rkw-gateway-rule')?.closest('table');
  var tbody = table ? table.querySelector('tbody') : null;
  var baseRow = tbody && tbody.querySelector('.rkw-gateway-rule') ? tbody.querySelector('.rkw-gateway-rule').cloneNode(true) : null;
  var nextIndex = tbody ? tbody.querySelectorAll('.rkw-gateway-rule').length : 0;

  function currentType() { return mode && mode.value === 'invoice' ? 'invoice' : 'order'; }
  function arr(key) { return Array.isArray(catalog[key]) ? catalog[key] : []; }
  function field(name, parent) { return (parent || root).querySelector('[name="rkw[' + name + ']"]'); }
  function methodsFor(id, type) {
    var pol = arr(type).find(function (p) { return String(p.id) === String(id); });
    return pol && Array.isArray(pol.keys) ? pol.keys : [];
  }
  function currentPolicyID() {
    var typed = field(currentType() === 'invoice' ? 'invoice_settlement_id' : 'order_settlement_id');
    var fallback = field('settlement_id');
    return typed && Number(typed.value) ? typed.value : fallback ? fallback.value : '';
  }
  function makeOption(value, label) {
    var option = document.createElement('option'); option.value = String(value); option.textContent = String(label); return option;
  }
  function fill(select, list, placeholder, selected) {
    if (!select) return;
    var initial = select.value;
    select.replaceChildren(makeOption('', placeholder));
    list.forEach(function (entry) {
      var label = entry.label || (entry.id + ' — ' + (entry.name || 'بدون عنوان') + (entry.keys && entry.keys.length ? ' [' + entry.keys.join(' / ') + ']' : ''));
      select.appendChild(makeOption(entry.id, label));
    });
    var existing = String(selected == null ? initial : selected);
    if (existing && Array.from(select.options).some(function (o) { return o.value === existing; })) select.value = existing;
  }
  function updateRuleRow(row) {
    var policyInput = row.querySelector('[name$="[settlement_id]"]');
    var keyInput = row.querySelector('[name$="[receipt_key]"]');
    var policySelect = row.querySelector('[data-rkw-rule-for="settlement_id"]');
    var keySelect = row.querySelector('[data-rkw-rule-for="receipt_key"]');
    fill(policySelect, arr(currentType()), 'انتخاب سیاست…', policyInput ? policyInput.value : '');
    var keys = methodsFor(policyInput && policyInput.value ? policyInput.value : currentPolicyID(), currentType());
    // When no policy is selected, show supported keys across all policies for this document type.
    if (!keys.length && (!policyInput || !policyInput.value)) {
      arr(currentType()).forEach(function (p) { (p.keys || []).forEach(function (k) { if (keys.indexOf(k) === -1) keys.push(k); }); });
    }
    fill(keySelect, keys.map(function (k) { return {id:k,label:k}; }), 'انتخاب نوع دریافت…', keyInput ? keyInput.value : '');
  }
  function updatePickers() {
    root.querySelectorAll('.rkw-catalog-choice').forEach(function (select) {
      var type = select.dataset.rkwType;
      var name = select.dataset.rkwFor;
      var input = field(name);
      var options = [];
      if (type === 'invoice' || type === 'order') options = arr(type);
      else if (type === 'current') options = arr(currentType());
      else if (type === 'stores' || type === 'areas') options = arr(type);
      else if (type === 'pattern_invoice' || type === 'pattern_order') {
        var pattern = catalog.patterns && catalog.patterns[type === 'pattern_invoice' ? 'invoice' : 'order'];
        if (pattern && Number(pattern.id)) options = [pattern];
      } else if (type === 'methods') {
        var keys = methodsFor(currentPolicyID(), currentType());
        if (!keys.length && !currentPolicyID()) {
          arr(currentType()).forEach(function (p) { (p.keys || []).forEach(function (k) { if (keys.indexOf(k) < 0) keys.push(k); }); });
        }
        options = keys.map(function (k) { return {id:k,label:k}; });
      }
      fill(select, options, 'انتخاب از شناسه‌های راهکاران…', input ? input.value : '');
    });
    if (tbody) tbody.querySelectorAll('.rkw-gateway-rule').forEach(updateRuleRow);
    validateReceipt();
  }
  function validateReceipt() {
    var policyId = currentPolicyID();
    var keyInput = field('receipt_key');
    var warning = document.getElementById('rkw-receipt-warning');
    if (!warning || !keyInput) return;
    warning.textContent = '';
    if (!policyId || !keyInput.value || !arr(currentType()).length) return;
    var chosen = arr(currentType()).find(function (p) { return String(p.id) === String(policyId); });
    if (chosen && chosen.keys && chosen.keys.length && chosen.keys.indexOf(keyInput.value) < 0) {
      warning.textContent = 'هشدار: نوع دریافت «' + keyInput.value + '» در روش‌های سیاست ' + chosen.id + ' مشاهده نشد. پیش از ثبت فاکتور اصلاح کنید.';
      warning.classList.add('rkw-config-warning');
    }
  }
  function text(el, content) { el.textContent = content; return el; }
  function showDirectory() {
    if (!directory) return;
    directory.replaceChildren();
    if (!arr('invoice').length && !arr('order').length && !catalog.updated) {
      directory.appendChild(text(document.createElement('p'), 'برای مشاهده شناسه‌های واقعی، دکمه «دریافت / به‌روزرسانی شناسه‌ها» را بزنید.'));
      return;
    }
    directory.appendChild(text(document.createElement('p'), 'آخرین دریافت: ' + (catalog.updated || 'نامشخص') + ' — شناسه‌ها از سرور اتصال فعلی خوانده شده‌اند.'));
    ['invoice','order'].forEach(function (type) {
      var section = document.createElement('section'); section.className = 'rkw-catalog-section';
      var header = document.createElement('h3'); header.textContent = type === 'invoice' ? 'سیاست‌های تسویه فاکتور فروش' : 'سیاست‌های تسویه سفارش فروش'; section.appendChild(header);
      var list = arr(type);
      if (!list.length) { section.appendChild(text(document.createElement('p'), 'فهرستی دریافت نشده است؛ می‌توانید شناسه را دستی وارد کنید.')); directory.appendChild(section); return; }
      var area = document.createElement('div'); area.className = 'rkw-catalog-table-wrap';
      var table = document.createElement('table'); table.className = 'widefat striped rkw-catalog-table';
      var thead = document.createElement('thead'); var trh = document.createElement('tr');
      ['شناسه','عنوان سیاست','روش‌های دریافت مجاز','عملیات'].forEach(function (label) {trh.appendChild(text(document.createElement('th'),label));}); thead.appendChild(trh); table.appendChild(thead);
      var body = document.createElement('tbody');
      list.forEach(function (entry) {
        var row = document.createElement('tr');
        [entry.id, entry.name || '—', (entry.keys || []).join(' / ') || '—'].forEach(function (value) { row.appendChild(text(document.createElement('td'), String(value))); });
        var td = document.createElement('td'); var choose = document.createElement('button'); choose.type = 'button'; choose.className = 'button button-small'; choose.textContent = 'انتخاب';
        choose.addEventListener('click', function () {
          var target = field(type === 'invoice' ? 'invoice_settlement_id' : 'order_settlement_id');
          if (target) { target.value = entry.id; target.dispatchEvent(new Event('change', {bubbles:true})); target.scrollIntoView({block:'nearest',behavior:'smooth'}); }
          if (feedback) feedback.textContent = 'سیاست ' + entry.id + ' انتخاب شد؛ برای ثبت در وردپرس دکمه «ذخیره تنظیمات» را بزنید.';
        });
        td.appendChild(choose); row.appendChild(td); body.appendChild(row);
      });
      table.appendChild(body); area.appendChild(table); section.appendChild(area); directory.appendChild(section);
    });
    if (catalog.errors && Object.keys(catalog.errors).length) {
      var warning = document.createElement('p'); warning.className='rkw-config-warning';
      warning.textContent = 'موارد دریافت‌نشده: ' + Object.entries(catalog.errors).map(function (e) { return e[0] + ': ' + e[1]; }).join(' | ');
      directory.appendChild(warning);
    }
  }
  root.addEventListener('change', function (event) {
    var picker = event.target.closest('[data-rkw-for], [data-rkw-rule-for]');
    if (picker && picker.value !== '') {
      var row = picker.closest('.rkw-gateway-rule');
      var input = row ? row.querySelector('[name$="[' + picker.dataset.rkwRuleFor + ']"]') : field(picker.dataset.rkwFor);
      if (input) { input.value = picker.value; input.dispatchEvent(new Event('input', {bubbles:true})); }
    }
    if (picker || event.target === mode || (event.target.name && /settlement_id|receipt_key/.test(event.target.name))) updatePickers();
  });
  if (btn) btn.addEventListener('click', function () {
    btn.disabled = true; if (feedback) feedback.textContent = 'در حال دریافت شناسه‌ها از راهکاران…';
    var params = new URLSearchParams({action:'rkw_policy_catalog',_ajax_nonce:cfg.nonce || ''});
    fetch(cfg.ajax, {method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:params})
      .then(function (res) { return res.json(); })
      .then(function (res) { if (!res.success) throw Error(typeof res.data === 'string' ? res.data : 'دریافت شناسه‌ها ناموفق بود.'); catalog = res.data || {}; showDirectory(); updatePickers(); if (feedback) feedback.textContent = 'فهرست شناسه‌ها دریافت شد. پس از انتخاب، «ذخیره تنظیمات» را بزنید.'; })
      .catch(function (err) { if (feedback) feedback.textContent = 'خطا: ' + err.message; })
      .finally(function () { btn.disabled = false; });
  });
  if (tbody) {
    tbody.addEventListener('click', function (event) {
      if (!event.target.closest('.rkw-rule-remove')) return;
      var row = event.target.closest('.rkw-gateway-rule');
      if (row) { row.remove(); }
    });
    var add = document.getElementById('rkw-add-rule');
    if (add) add.addEventListener('click', function () {
      if (!baseRow || tbody.querySelectorAll('.rkw-gateway-rule').length >= 40) return;
      var row = baseRow.cloneNode(true); var idx = nextIndex++;
      row.querySelectorAll('[name]').forEach(function (input) {
        input.name = input.name.replace(/\[payment_rules\]\[\d+\]/, '[payment_rules][' + idx + ']');
        if (input.tagName === 'SELECT') input.selectedIndex = 0; else input.value = '';
      });
      tbody.appendChild(row); updateRuleRow(row);
    });
  }
  showDirectory(); updatePickers();
})();
