<?php
/**
 * Kasbi Rahkaran: retain site configuration and locally saved data on uninstall.
 *
 * WordPress executes this file only when the plugin is deleted. Previous releases
 * deleted rkw_settings and rkw_extensions here, causing credentials, catalog sync,
 * payment and order settings to disappear after reinstalling the plugin.
 *
 * All user settings and plugin-owned stored data are deliberately retained. For
 * an intentional reset use the protected "Data retention" section in wp-admin.
 * The deactivate hook already cancels scheduled events; cancel them here too as
 * a defensive measure, without touching persistent data.
 */
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) { exit; }

wp_clear_scheduled_hook( 'rkw_cron_sync' );
wp_clear_scheduled_hook( 'rkw_cron_continue' );

// Never delete rkw_settings, rkw_extensions, cached lists, saved logs, or
// loyalty/customer data during plugin deletion/reinstallation.
