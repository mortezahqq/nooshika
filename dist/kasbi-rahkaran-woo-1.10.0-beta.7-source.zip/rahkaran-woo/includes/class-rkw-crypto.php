<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** رمزنگاری ساده‌ی رمز عبور راهکاران در دیتابیس (AES-256-CBC با کلیدهای وردپرس) */
class RKW_Crypto {
	private static function key() {
		$salt = ( defined( 'AUTH_KEY' ) ? AUTH_KEY : '' ) . ( defined( 'SECURE_AUTH_SALT' ) ? SECURE_AUTH_SALT : '' ) . wp_salt( 'auth' );
		return hash( 'sha256', $salt, true );
	}

	public static function encrypt( $plain ) {
		if ( '' === $plain || null === $plain ) { return ''; }
		if ( ! function_exists( 'openssl_encrypt' ) ) { return 'p:' . base64_encode( $plain ); }
		$iv  = openssl_random_pseudo_bytes( 16 );
		$enc = openssl_encrypt( $plain, 'aes-256-cbc', self::key(), OPENSSL_RAW_DATA, $iv );
		if ( false === $enc ) { return 'p:' . base64_encode( $plain ); }
		return 'e:' . base64_encode( $iv . $enc );
	}

	public static function decrypt( $stored ) {
		if ( ! is_string( $stored ) || '' === $stored ) { return ''; }
		if ( 0 === strpos( $stored, 'p:' ) ) { return (string) base64_decode( substr( $stored, 2 ) ); }
		if ( 0 !== strpos( $stored, 'e:' ) ) { return ''; }
		$raw = base64_decode( substr( $stored, 2 ) );
		if ( false === $raw || strlen( $raw ) < 17 || ! function_exists( 'openssl_decrypt' ) ) { return ''; }
		$out = openssl_decrypt( substr( $raw, 16 ), 'aes-256-cbc', self::key(), OPENSSL_RAW_DATA, substr( $raw, 0, 16 ) );
		return false === $out ? '' : $out;
	}
}
