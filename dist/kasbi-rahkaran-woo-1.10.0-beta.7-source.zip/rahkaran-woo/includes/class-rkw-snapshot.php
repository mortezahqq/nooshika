<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Bounded, non-autoloaded read-only snapshots of formatted administrative lists. */
class RKW_Snapshot {
	const INDEX = 'rkw_admin_snapshot_index_v1';
	const MAX_ITEMS = 120;
	const LAST_PREFIX = 'rkw_admin_last_view_';

	private static function connection_signature() {
		$s = rkw_settings();
		$values = array();
		foreach ( array( 'api', 'protocol', 'ip', 'port', 'cluster', 'username', 'password_enc' ) as $key ) {
			$values[] = isset( $s[ $key ] ) ? (string) $s[ $key ] : '';
		}
		// Do not save credentials or session data in the snapshot; only their hash in a key.
		return md5( wp_json_encode( $values ) );
	}

	public static function key( $section, $page, $size, $search, $mobile, $shop, $doc_type ) {
		$values = array( self::connection_signature(), (string) $section, (int) $page, (int) $size, (string) $search, (string) $mobile, (int) $shop, (int) $doc_type );
		return 'rkw_admin_snap_' . md5( wp_json_encode( $values ) );
	}

	public static function read( $key ) {
		$snapshot = get_option( $key, false );
		if ( ! is_array( $snapshot ) || ! isset( $snapshot['schema'], $snapshot['saved_at'], $snapshot['data'] ) || 1 !== (int) $snapshot['schema'] || ! is_array( $snapshot['data'] ) ) {
			return null;
		}
		$data = $snapshot['data'];
		if ( ! isset( $data['headers'], $data['rows'] ) || ! is_array( $data['headers'] ) || ! is_array( $data['rows'] ) ) { return null; }
		return array( 'data' => $data, 'saved_at' => (int) $snapshot['saved_at'] );
	}

	public static function save( $key, $data ) {
		$payload = array( 'schema' => 1, 'saved_at' => time(), 'data' => $data );
		$encoded = wp_json_encode( $payload );
		// Never allow large server responses to bloat wp_options.
		if ( ! is_string( $encoded ) || strlen( $encoded ) > 320 * 1024 ) { return false; }
		update_option( $key, $payload, false );
		$stored = self::read( $key );
		if ( null === $stored ) { return false; }
		$index = get_option( self::INDEX, array() );
		if ( ! is_array( $index ) ) { $index = array(); }
		$index[ $key ] = array( 'time' => time(), 'section' => isset( $data['section'] ) ? (string) $data['section'] : '' );
		if ( count( $index ) > self::MAX_ITEMS ) {
			uasort( $index, function ( $a, $b ) {
				return (int) ( isset( $a['time'] ) ? $a['time'] : 0 ) <=> (int) ( isset( $b['time'] ) ? $b['time'] : 0 );
			} );
			while ( count( $index ) > self::MAX_ITEMS ) {
				$oldest = key( $index );
				if ( ! is_string( $oldest ) || 0 !== strpos( $oldest, 'rkw_admin_snap_' ) ) { break; }
				delete_option( $oldest );
				unset( $index[ $oldest ] );
			}
		}
		update_option( self::INDEX, $index, false );
		return true;
	}

	/** On confirmed invoice creation discard saved invoice pages (never other sections). */
	public static function invalidate_section( $section ) {
		$index = get_option( self::INDEX, array() );
		if ( ! is_array( $index ) ) { $index = array(); }
		foreach ( $index as $key => $entry ) {
			if ( ! is_string( $key ) || 0 !== strpos( $key, 'rkw_admin_snap_' ) ) { continue; }
			if ( is_array( $entry ) && isset( $entry['section'] ) && $section === $entry['section'] ) {
				delete_option( $key );
				unset( $index[ $key ] );
			}
		}
		update_option( self::INDEX, $index, false );
		if ( 'invoices' === $section ) {
			update_option( 'rkw_invoices_list_revision', (int) get_option( 'rkw_invoices_list_revision', 0 ) + 1, false );
		}
	}

	/** Locate a Rahkaran ID in saved product-list pages for this exact connection. */
	public static function find_product( $product_id ) {
		$product_id = absint( $product_id );
		if ( ! $product_id ) { return null; }
		$index = get_option( self::INDEX, array() );
		if ( ! is_array( $index ) ) { return null; }
		// Most recent list data takes precedence. The key check prevents cross-server reuse.
		uasort( $index, function ( $a, $b ) {
			return (int) ( isset( $b['time'] ) ? $b['time'] : 0 ) <=> (int) ( isset( $a['time'] ) ? $a['time'] : 0 );
		} );
		foreach ( $index as $key => $entry ) {
			if ( ! is_array( $entry ) || ! isset( $entry['section'] ) || 'products' !== $entry['section'] ) { continue; }
			$snapshot = self::read( $key );
			if ( ! $snapshot ) { continue; }
			$data = $snapshot['data'];
			// A cached page from another connection must never provide product details.
			$params = isset( $data['snapshot_params'] ) ? $data['snapshot_params'] : null;
			if ( ! is_array( $params ) ) {
				// Older v1.8 pages have no embedded filter metadata; the current user's last-view
				// parameters let us verify this one page against the active connection.
				$previous = self::last_view( 'products' );
				if ( isset( $previous['page'], $previous['size'], $previous['search'] ) ) {
					$params = $previous;
				}
			}
			if ( ! is_array( $params ) || ! isset( $params['page'], $params['size'], $params['search'] ) || $key !== self::key( 'products', $params['page'], $params['size'], $params['search'], '', 0, 1 ) ) { continue; }
			if ( isset( $data['catalog_items'][ $product_id ] ) && is_array( $data['catalog_items'][ $product_id ] ) ) {
				return array( 'item' => $data['catalog_items'][ $product_id ], 'saved_at' => $snapshot['saved_at'] );
			}
			// Version 1.8 snapshots only held formatted columns, not the unit ID.
			foreach ( $data['rows'] as $row ) {
				if ( ! is_array( $row ) || ! isset( $row['id'] ) || (int) $row['id'] !== $product_id || ! isset( $row['cells'] ) ) { continue; }
				$cells = $row['cells'];
				$fee = isset( $cells[4] ) && is_numeric( $cells[4] ) ? (float) $cells[4] : null;
				return array( 'item' => array( 'id' => $product_id, 'code' => isset( $cells[1] ) ? (string) $cells[1] : '', 'name' => isset( $cells[2] ) ? (string) $cells[2] : '', 'unit' => null, 'stock' => null, 'price' => $fee, 'sale' => null ), 'saved_at' => $snapshot['saved_at'] );
			}
		}
		return null;
	}

	public static function remember_view( $section, $params ) {
		update_user_meta( get_current_user_id(), self::LAST_PREFIX . $section, $params );
	}

	public static function last_view( $section ) {
		$value = get_user_meta( get_current_user_id(), self::LAST_PREFIX . $section, true );
		return is_array( $value ) ? $value : array();
	}
}
