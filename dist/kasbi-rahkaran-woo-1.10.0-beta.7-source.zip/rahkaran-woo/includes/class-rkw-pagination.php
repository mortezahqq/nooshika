<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Consistent numbered admin pagination with direct page navigation. */
class RKW_Pagination {
	public static function render( $page, $pages, $query, $page_key, $style = '' ) {
		$page  = max( 1, (int) $page );
		$pages = max( 1, (int) $pages );
		$page  = min( $page, $pages );
		$base  = admin_url( 'admin.php' );
		$query = is_array( $query ) ? $query : array();
		$href = function ( $num ) use ( $base, $query, $page_key ) {
			return esc_url( add_query_arg( array_merge( $query, array( $page_key => $num ) ), $base ) );
		};
		echo '<div class="rkw-pagination ' . esc_attr( $style ) . '" dir="rtl"><nav class="rkw-pagination-links" aria-label="صفحه‌بندی عددی">';
		if ( $page > 1 ) { echo '<a class="button" href="' . $href( $page - 1 ) . '">قبلی</a>'; }
		$display = array( 1, $pages );
		for ( $i = max( 1, $page - 2 ); $i <= min( $pages, $page + 2 ); $i++ ) { $display[] = $i; }
		$display = array_values( array_unique( $display ) );
		sort( $display, SORT_NUMERIC );
		$previous = 0;
		foreach ( $display as $num ) {
			if ( $num - $previous > 1 ) { echo '<span class="rkw-pagination-dots" aria-hidden="true">…</span>'; }
			echo '<a class="button' . ( $page === $num ? ' is-current' : '' ) . '" ' . ( $page === $num ? 'aria-current="page"' : '' ) . ' href="' . $href( $num ) . '" aria-label="صفحه ' . esc_attr( $num ) . '">' . esc_html( number_format_i18n( $num ) ) . '</a>';
			$previous = $num;
		}
		if ( $page < $pages ) { echo '<a class="button" href="' . $href( $page + 1 ) . '">بعدی</a>'; }
		echo '</nav><span class="rkw-pagination-status">صفحه ' . esc_html( number_format_i18n( $page ) ) . ' از ' . esc_html( number_format_i18n( $pages ) ) . '</span>';
		echo '<form method="get" action="' . esc_url( $base ) . '" class="rkw-pagination-jump">';
		foreach ( $query as $k => $value ) {
			if ( ! is_scalar( $value ) ) { continue; }
			echo '<input type="hidden" name="' . esc_attr( $k ) . '" value="' . esc_attr( (string) $value ) . '">';
		}
		echo '<label>برو به صفحه <input type="number" name="' . esc_attr( $page_key ) . '" min="1" max="' . esc_attr( $pages ) . '" value="' . esc_attr( $page ) . '" required inputmode="numeric" aria-label="شماره صفحه دلخواه"></label><button type="submit" class="button">برو</button></form></div>';
	}
}
