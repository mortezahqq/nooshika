<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * همگام‌سازی راهکاران -> ووکامرس (کالا، موجودی، قیمت).
 * هر دو نسخه‌ی API به یک ساختار یکسان نرمال می‌شوند:
 *  [ id, key, name, unit, stock(float|null), price(float|null), sale(float|null) ]
 */
class RKW_Sync {
	const CURSOR = 'rkw_cursor';
	const STATS  = 'rkw_last_run';
	const LOCK   = 'rkw_sync_lock';

	public static function init() {
		add_action( 'rkw_cron_sync', array( __CLASS__, 'cron_run' ) );
		add_action( 'rkw_cron_continue', array( __CLASS__, 'cron_run' ) );
	}

	public static function reschedule() {
		wp_clear_scheduled_hook( 'rkw_cron_sync' );
		$s = rkw_settings();
		if ( 'off' !== $s['cron_interval'] ) {
			wp_schedule_event( time() + 120, $s['cron_interval'], 'rkw_cron_sync' );
		}
	}

	public static function cron_run() {
		if ( get_transient( self::LOCK ) ) { return; }
		set_transient( self::LOCK, 1, 2 * MINUTE_IN_SECONDS );
		$start = time();
		$r     = null;
		do {
			$r = self::step();
			if ( is_wp_error( $r ) ) { delete_transient( self::LOCK ); return; }
			set_transient( self::LOCK, 1, 2 * MINUTE_IN_SECONDS );
		} while ( ! $r['done'] && ( time() - $start ) < 35 );
		delete_transient( self::LOCK );
		if ( ! $r['done'] ) { wp_schedule_single_event( time() + 20, 'rkw_cron_continue' ); }
	}

	public static function reset() {
		$s = rkw_settings();
		update_option( self::CURSOR, array(
			'pos' => ( 'v21' === $s['api'] ) ? (int) $s['page_start'] : 0,
			'processed' => 0, 'created' => 0, 'updated' => 0, 'skipped' => 0, 'errors' => 0,
			'last_first' => '', 'started' => current_time( 'mysql' ),
		), false );
	}

	private static function store_filter( $s ) {
		return array_values( array_filter( array_map( 'intval', explode( ',', (string) $s['store_ids'] ) ) ) );
	}

	private static function norm_unit( $it ) {
		if ( isset( $it['RetailUnitRef'] ) && $it['RetailUnitRef'] ) { return (int) $it['RetailUnitRef']; }
		if ( isset( $it['retailUnitRef'] ) && $it['retailUnitRef'] ) { return (int) $it['retailUnitRef']; }
		if ( isset( $it['unitRef'] ) ) { return (int) $it['unitRef']; }
		if ( ! empty( $it['units'] ) && is_array( $it['units'] ) ) {
			foreach ( $it['units'] as $u ) { if ( ! empty( $u['isDefault'] ) ) { return (int) $u['id']; } }
			return (int) $it['units'][0]['id'];
		}
		return 0;
	}

	/** نرمال‌سازی داده تک‌محصول. مقدار null به معنی «اطلاعات ارائه نشده» است. */
	public static function normalize_single( $raw, $api ) {
		if ( ! is_array( $raw ) ) { return null; }
		$id = isset( $raw['productId'] ) ? absint( $raw['productId'] ) : ( isset( $raw['id'] ) ? absint( $raw['id'] ) : 0 );
		if ( ! $id ) { return null; }
		$v21 = 'v21' === $api;
		return array(
			'id'    => $id,
			'code'  => isset( $raw['productNumber'] ) ? trim( (string) $raw['productNumber'] ) : ( isset( $raw['code'] ) ? trim( (string) $raw['code'] ) : '' ),
			'name'  => isset( $raw['productName'] ) ? trim( (string) $raw['productName'] ) : ( isset( $raw['name'] ) ? trim( (string) $raw['name'] ) : '' ),
			'unit'  => self::norm_unit( $raw ) ?: null,
			'stock' => ! $v21 && isset( $raw['remaining'] ) && is_numeric( $raw['remaining'] ) ? (float) $raw['remaining'] : null,
			'price' => $v21 && isset( $raw['fee'] ) && is_numeric( $raw['fee'] ) ? (float) $raw['fee'] : null,
			'sale'  => null,
		);
	}

	/** بروزرسانی یک محصول/متغیر موجود بدون ساخت هیچ محصول جدیدی. */
	public static function update_target( $woocommerce_id, $item, $client = null ) {
		$woocommerce_id = absint( $woocommerce_id );
		$product = $woocommerce_id ? wc_get_product( $woocommerce_id ) : false;
		if ( ! $product || ! is_array( $item ) || empty( $item['id'] ) ) { return new WP_Error( 'rkw_target', 'محصول یا شناسه راهکاران معتبر نیست.' ); }
		$client = $client ? $client : new RKW_Client();
		$s = rkw_settings();
		$result = self::apply( $item, $s, $client, self::store_filter( $s ), $woocommerce_id );
		return 'updated' === $result ? true : new WP_Error( 'rkw_apply', 'بروزرسانی محصول در ووکامرس ناموفق بود.' );
	}

	/** دریافت یک صفحه و نرمال‌سازی. خروجی: [items, raw_count] یا WP_Error */
	private static function fetch( $cur, $s, $client ) {
		$size = max( 5, min( 200, (int) $s['batch_size'] ) );

		if ( 'v21' === $s['api'] ) {
			$raw = $client->products21( $cur['pos'], $size );
			if ( is_wp_error( $raw ) ) { return $raw; }
			$raw   = is_array( $raw ) ? $raw : array();
			$items = array();
			foreach ( $raw as $it ) {
				if ( ! isset( $it['productId'] ) ) { continue; }
				$items[] = array(
					'id'    => (int) $it['productId'],
					'code'  => isset( $it['productNumber'] ) ? trim( (string) $it['productNumber'] ) : '',
					'name'  => isset( $it['productName'] ) ? trim( (string) $it['productName'] ) : '',
					'unit'  => self::norm_unit( $it ),
					'stock' => null,
					'price' => isset( $it['fee'] ) ? (float) $it['fee'] : null,
					'sale'  => null,
				);
			}
			return array( $items, count( $raw ), $size );
		}

		$raw = $client->products19( $cur['pos'], $size );
		if ( is_wp_error( $raw ) ) { return $raw; }
		$raw   = is_array( $raw ) ? $raw : array();
		$items = array();
		$units = array();
		foreach ( $raw as $it ) {
			if ( ! isset( $it['id'] ) ) { continue; }
			$unit  = self::norm_unit( $it );
			$units[ (int) $it['id'] ] = $unit;
			$items[ (int) $it['id'] ] = array(
				'id'    => (int) $it['id'],
				'code'  => isset( $it['code'] ) ? trim( (string) $it['code'] ) : '',
				'name'  => isset( $it['name'] ) ? trim( (string) $it['name'] ) : '',
				'unit'  => $unit,
				'stock' => isset( $it['remaining'] ) ? (float) $it['remaining'] : null,
				'price' => null,
				'sale'  => null,
			);
		}
		if ( $s['sync_price'] && $units ) {
			$pr = $client->prices19( $units );
			if ( is_wp_error( $pr ) ) {
				RKW_Log::add( 'error', 'دریافت قیمت: ' . $pr->get_error_message() );
			} else {
				$ids = array_keys( $units );
				foreach ( (array) $pr as $row ) {
					$idx = isset( $row['itemId'] ) ? (int) $row['itemId'] - 1 : -1;
					if ( ! isset( $ids[ $idx ] ) ) { continue; }
					$pid   = $ids[ $idx ];
					$field = $s['price_field'];
					$val   = isset( $row[ $field ] ) ? (float) $row[ $field ] : 0;
					$items[ $pid ]['price'] = $val > 0 ? $val : null;
					$disc = isset( $row['discount'] ) ? (float) $row['discount'] : 0;
					if ( $disc > 0 && ! empty( $row['netOfFee'] ) ) { $items[ $pid ]['sale'] = (float) $row['netOfFee']; }
				}
			}
		}
		return array( array_values( $items ), count( $raw ), $size );
	}

	/** یک گام (یک صفحه). خروجی: آرایه وضعیت یا WP_Error */
	public static function step() {
		$s   = rkw_settings();
		$cur = get_option( self::CURSOR );
		if ( ! is_array( $cur ) ) { self::reset(); $cur = get_option( self::CURSOR ); }

		$client = new RKW_Client();
		$res    = self::fetch( $cur, $s, $client );
		if ( is_wp_error( $res ) ) {
			RKW_Log::add( 'error', 'دریافت محصولات: ' . $res->get_error_message() );
			return $res;
		}
		list( $items, $raw_count, $size ) = $res;

		// جلوگیری از حلقه‌ی بی‌پایان اگر سرور صفحه‌بندی را نادیده بگیرد
		$first = $items ? $items[0]['id'] : '';
		if ( '' !== $first && (string) $first === (string) $cur['last_first'] && $cur['processed'] > 0 ) {
			RKW_Log::add( 'warn', 'پاسخ صفحه‌ی بعد با صفحه‌ی قبل یکسان بود؛ صفحه‌بندی متوقف شد. تنظیم «شماره صفحه اول» و «تعداد در دسته» را بررسی کنید.' );
			$raw_count = 0;
			$items     = array();
		}
		$cur['last_first'] = $first;

		$stores = self::store_filter( $s );
		foreach ( $items as $it ) {
			$r = self::apply( $it, $s, $client, $stores );
			if ( isset( $cur[ $r ] ) ) { $cur[ $r ]++; }
		}

		$cur['processed'] += count( $items );
		$cur['pos']        = ( 'v21' === $s['api'] ) ? $cur['pos'] + 1 : $cur['pos'] + $raw_count;
		$done              = $raw_count < $size;

		if ( $done ) {
			$cur['finished'] = current_time( 'mysql' );
			update_option( self::STATS, $cur, false );
			delete_option( self::CURSOR );
			RKW_Log::add( 'info', sprintf( 'همگام‌سازی کامل شد: %d بررسی، %d ایجاد، %d بروزرسانی، %d نادیده، %d خطا', $cur['processed'], $cur['created'], $cur['updated'], $cur['skipped'], $cur['errors'] ) );
		} else {
			update_option( self::CURSOR, $cur, false );
		}
		return array( 'done' => $done, 'processed' => $cur['processed'], 'created' => $cur['created'], 'updated' => $cur['updated'], 'skipped' => $cur['skipped'], 'errors' => $cur['errors'] );
	}

	/** یافتن محصول ووکامرس با کلید تطبیق (SKU) */
	private static function find_product_id( $it, $s ) {
		$sku = ( 'id' === $s['key_field'] ) ? (string) $it['id'] : $it['code'];
		if ( '' === $sku ) { return 0; }
		$pid = wc_get_product_id_by_sku( $sku );
		return $pid ? (int) $pid : 0;
	}

	/** موجودی v21: جمع RemainingQuantity انبارهای انتخابی (یا همه). null یعنی خطا/نامشخص */
	private static function stock21( $client, $pid, $stores ) {
		$rows = $client->remaining21( $pid );
		if ( is_wp_error( $rows ) ) {
			RKW_Log::add( 'error', 'موجودی کالا ' . $pid . ': ' . $rows->get_error_message() );
			return null;
		}
		$sum = 0.0;
		foreach ( (array) $rows as $r ) {
			$sid = isset( $r['StoreID'] ) ? (int) $r['StoreID'] : ( isset( $r['storeID'] ) ? (int) $r['storeID'] : 0 );
			if ( $stores && ! in_array( $sid, $stores, true ) ) { continue; }
			$q = isset( $r['RemainingQuantity'] ) ? $r['RemainingQuantity'] : ( isset( $r['remainingQuantity'] ) ? $r['remainingQuantity'] : null );
			$sum += (float) $q;
		}
		return $sum;
	}

	/** اعمال یک کالا روی ووکامرس. خروجی: created|updated|skipped|errors */
	private static function apply( $it, $s, $client, $stores, $target_id = 0 ) {
		$key_ok = $target_id ? ! empty( $it['id'] ) : ( ( 'id' === $s['key_field'] ) ? true : ( '' !== $it['code'] ) );
		if ( ! $key_ok ) { return 'skipped'; }

		$wid = $target_id ? absint( $target_id ) : self::find_product_id( $it, $s );
		$new = false;
		if ( ! $wid ) {
			if ( ! $s['create_missing'] ) { return 'skipped'; }
			$p = new WC_Product_Simple();
			$p->set_sku( ( 'id' === $s['key_field'] ) ? (string) $it['id'] : $it['code'] );
			$p->set_name( '' !== $it['name'] ? $it['name'] : $it['code'] );
			$p->set_status( 'draft' );
			$new = true;
		} else {
			$p = wc_get_product( $wid );
			if ( ! $p ) { return 'errors'; }
			if ( $s['sync_name'] && '' !== $it['name'] && ! $p->is_type( 'variation' ) ) { $p->set_name( $it['name'] ); }
		}

		$p->update_meta_data( '_rahkaran_product_id', (int) $it['id'] );
		if ( ! empty( $it['unit'] ) ) { $p->update_meta_data( '_rahkaran_unit_id', (int) $it['unit'] ); }

		if ( $s['sync_stock'] ) {
			$qty = $it['stock'];
			if ( null === $qty && 'v21' === $s['api'] ) { $qty = self::stock21( $client, $it['id'], $stores ); }
			if ( null !== $qty ) {
				$qty = max( 0, (float) $qty );
				$p->set_manage_stock( true );
				$p->set_stock_quantity( (int) floor( $qty ) );
				$p->set_stock_status( $qty >= 1 ? 'instock' : 'outofstock' );
			}
		}

		if ( $s['sync_price'] && null !== $it['price'] && $it['price'] > 0 ) {
			$div = rkw_price_multiplier( $s );
			$p->set_regular_price( (string) round( $it['price'] / $div ) );
			if ( $s['sync_sale'] && 'v19' === $s['api'] ) {
				if ( null !== $it['sale'] ) { $p->set_sale_price( (string) round( $it['sale'] / $div ) ); }
				else { $p->set_sale_price( '' ); }
			}
			// WooCommerce also stores the active price separately from the regular price.
			// Preserve an existing sale when sale synchronization is disabled.
			$regular = (float) $p->get_regular_price( 'edit' );
			$sale = $p->get_sale_price( 'edit' );
			$p->set_price( '' !== (string) $sale && (float) $sale < $regular ? (string) $sale : (string) $regular );
		}

		try {
			$p->save();
		} catch ( Exception $e ) {
			RKW_Log::add( 'error', 'ذخیره محصول ' . $it['code'] . ': ' . $e->getMessage() );
			return 'errors';
		}
		return $new ? 'created' : 'updated';
	}
}
