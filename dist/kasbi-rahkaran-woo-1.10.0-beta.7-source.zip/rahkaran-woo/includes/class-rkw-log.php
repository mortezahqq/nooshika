<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** گزارش رویدادهای افزونه؛ سازگار با رکوردهای سه‌ستونی نسخه‌های قدیمی. */
class RKW_Log {
	const OPT = 'rkw_log';
	const MAX = 300;
	const MESSAGE_LIMIT = 64000;

	private static function entries() {
		$stored = get_option( self::OPT, array() );
		if ( ! is_array( $stored ) ) { return array(); }
		$changed = false;
		$out = array();
		foreach ( $stored as $entry ) {
			if ( ! is_array( $entry ) ) { $changed = true; continue; }
			if ( isset( $entry['id'], $entry['date'], $entry['level'], $entry['message'] ) ) {
				$out[] = $entry;
				continue;
			}
			if ( ! isset( $entry[0], $entry[1], $entry[2] ) ) { $changed = true; continue; }
			$out[] = array(
				'id'      => wp_generate_uuid4(),
				'date'    => (string) $entry[0],
				'level'   => (string) $entry[1],
				'message' => (string) $entry[2],
			);
			$changed = true;
		}
		if ( $changed ) { update_option( self::OPT, $out, false ); }
		return $out;
	}

	public static function add( $level, $msg ) {
		$log = self::entries();
		$message = is_scalar( $msg ) ? (string) $msg : wp_json_encode( $msg, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT );
		$log[] = array(
			'id'      => wp_generate_uuid4(),
			'date'    => current_time( 'mysql' ),
			'level'   => sanitize_key( $level ),
			'message' => rkw_text_length( (string) $message ) > self::MESSAGE_LIMIT ? rkw_text_slice( (string) $message, 0, self::MESSAGE_LIMIT ) . "\n[متن گزارش به علت محدودیت ذخیره‌سازی کوتاه شده است]" : (string) $message,
		);
		if ( count( $log ) > self::MAX ) { $log = array_slice( $log, -self::MAX ); }
		update_option( self::OPT, $log, false );
	}

	public static function all() { return array_reverse( self::entries() ); }

	public static function delete( $id ) {
		$rows = self::entries();
		$kept = array();
		$removed = false;
		foreach ( $rows as $row ) {
			if ( hash_equals( (string) $row['id'], (string) $id ) ) { $removed = true; continue; }
			$kept[] = $row;
		}
		if ( $removed ) { update_option( self::OPT, $kept, false ); }
		return $removed;
	}

	public static function clear() { delete_option( self::OPT ); }
}
