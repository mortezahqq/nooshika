<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Configurable Rahkaran identifiers, sourced from the active connection only. */
class RKW_Policy_Catalog {
	const OPTION = 'rkw_policy_catalog';

	public static function signature( $settings = null ) {
		$s = is_array( $settings ) ? $settings : rkw_settings();
		$parts = array();
		foreach ( array( 'api', 'protocol', 'ip', 'port', 'cluster', 'username', 'machine_name', 'password_enc', 'document_contract' ) as $field ) {
			$parts[] = isset( $s[ $field ] ) ? (string) $s[ $field ] : '';
		}
		return hash( 'sha256', implode( "\x00", $parts ) );
	}

	public static function stored() {
		$v = get_option( self::OPTION, array() );
		return is_array( $v ) && isset( $v['signature'] ) && hash_equals( self::signature(), (string) $v['signature'] ) ? $v : array();
	}

	private static function rows( $data ) {
		if ( ! is_array( $data ) ) { return array(); }
		foreach ( array( 'items', 'data', 'Items', 'Data' ) as $field ) {
			if ( isset( $data[ $field ] ) && is_array( $data[ $field ] ) ) { $data = $data[ $field ]; break; }
		}
		return array_values( $data ) === $data ? $data : array( $data );
	}

	private static function number( $row, $keys ) {
		foreach ( $keys as $k ) {
			if ( isset( $row[ $k ] ) && is_numeric( $row[ $k ] ) ) { return absint( $row[ $k ] ); }
		}
		return 0;
	}

	private static function title( $row, $keys ) {
		foreach ( $keys as $k ) {
			if ( isset( $row[ $k ] ) && is_scalar( $row[ $k ] ) ) { return sanitize_text_field( (string) $row[ $k ] ); }
		}
		return '';
	}

	private static function policies( $data ) {
		$out = array();
		foreach ( array_slice( self::rows( $data ), 0, 500 ) as $row ) {
			if ( ! is_array( $row ) ) { continue; }
			$id = self::number( $row, array( 'settlementPolicyID', 'settlementPolicyId', 'id', 'ID' ) );
			if ( ! $id ) { continue; }
			$keys = array();
			foreach ( (array) ( isset( $row['settlementMethodGroups'] ) ? $row['settlementMethodGroups'] : array() ) as $g ) {
				if ( ! is_array( $g ) ) { continue; }
				foreach ( (array) ( isset( $g['settlementMethods'] ) ? $g['settlementMethods'] : array() ) as $m ) {
					if ( ! is_array( $m ) ) { continue; }
					$key = self::title( $m, array( 'settlementNatureKey', 'natureKey', 'key' ) );
					if ( '' !== $key && preg_match( '/^[A-Za-z0-9_]{1,80}$/', $key ) ) { $keys[ $key ] = $key; }
				}
			}
			$out[ $id ] = array( 'id' => $id, 'name' => self::title( $row, array( 'settlementPolicyName', 'name', 'title' ) ), 'keys' => array_values( $keys ) );
		}
		return array_values( $out );
	}

	private static function locations( $data, $type ) {
		$out = array();
		foreach ( array_slice( self::rows( $data ), 0, 500 ) as $row ) {
			if ( ! is_array( $row ) ) { continue; }
			if ( 'areas' === $type ) {
				$id = self::number( $row, array( 'salesAreaID', 'salesAreaId', 'id' ) );
				$name = self::title( $row, array( 'salesAreaName', 'name', 'title' ) );
			} else {
				$id = self::number( $row, array( 'storeID', 'storeId', 'id', 'inventoryId', 'inventoryID' ) );
				$name = self::title( $row, array( 'storeName', 'name', 'title', 'inventoryName' ) );
			}
			if ( $id ) { $out[ $id ] = array( 'id' => $id, 'name' => $name ); }
		}
		return array_values( $out );
	}

	/** Refresh only on manager's explicit request. No fixed Rahkaran ID or policy list. */
	public static function refresh() {
		$c = new RKW_Client();
		if ( ! $c->is_v21() ) { return new WP_Error( 'rkw_catalog_version', 'فهرست شناسه‌ها برای API نسخه ۲۱ در دسترس است.' ); }
		$old = self::stored();
		$out = array(
			'signature' => self::signature(),
			'updated' => current_time( 'mysql' ),
			'invoice' => isset( $old['invoice'] ) ? $old['invoice'] : array(),
			'order' => isset( $old['order'] ) ? $old['order'] : array(),
			'areas' => isset( $old['areas'] ) ? $old['areas'] : array(),
			'stores' => isset( $old['stores'] ) ? $old['stores'] : array(),
			'patterns' => isset( $old['patterns'] ) ? $old['patterns'] : array(),
			'errors' => array(),
		);
		$tasks = array(
			'invoice' => $c->settlement_policies21( 1 ),
			'order'   => $c->settlement_policies21( 2 ),
			'areas'   => $c->sales_areas21(),
			'stores'  => $c->stores21(),
		);
		$successes = 0;
		foreach ( $tasks as $name => $response ) {
			if ( is_wp_error( $response ) ) { $out['errors'][ $name ] = $response->get_error_message(); continue; }
			$out[ $name ] = in_array( $name, array( 'invoice', 'order' ), true ) ? self::policies( $response ) : self::locations( $response, $name );
			$successes++;
		}
		foreach ( array( 1 => 'invoice', 2 => 'order' ) as $id => $type ) {
			$response = $c->default_pattern21( $id );
			if ( is_wp_error( $response ) ) { $out['errors'][ 'pattern_' . $type ] = $response->get_error_message(); continue; }
			$pattern = is_array( $response ) ? $response : array();
			$pattern_id = self::number( $pattern, array( 'id', 'documentPatternID', 'documentPatternId' ) );
			$out['patterns'][ $type ] = $pattern_id ? array( 'id' => $pattern_id, 'name' => self::title( $pattern, array( 'title', 'name', 'documentPatternName' ) ) ) : array();
		}
		if ( ! $successes ) { return new WP_Error( 'rkw_catalog_empty', 'هیچ شناسه‌ای دریافت نشد: ' . implode( ' | ', array_map( 'sanitize_text_field', $out['errors'] ) ) ); }
		update_option( self::OPTION, $out, false );
		return $out;
	}
}
