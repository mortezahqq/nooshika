<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Read-only discovery from the v21 Promotions service, PDF pages 220-222. */
class RKW_Coupon_Types {
	const OPTION = 'rkw_coupon_types';
	public static function init() { add_action( 'admin_post_rkw_coupon_types_refresh', array( __CLASS__, 'refresh' ) ); }
	public static function menu() { add_submenu_page( 'rkw', 'انواع بن سازمانی', 'انواع بن سازمانی', 'manage_woocommerce', 'rkw-coupon-types', array( __CLASS__, 'page' ) ); }
	public static function store( $rows, $settings ) {
		update_option( self::OPTION, array( 'signature' => RKW_Policy_Catalog::signature( $settings ), 'rows' => $rows, 'fetched_at' => current_time( 'mysql' ) ), false );
	}
	public static function stored( $settings = null ) {
		$stored = get_option( self::OPTION, array() );
		if ( null === $settings ) { $settings = rkw_settings(); }
		return is_array( $stored ) && isset( $stored['signature'], $stored['rows'] ) && is_string( $stored['signature'] ) && is_array( $stored['rows'] ) && hash_equals( RKW_Policy_Catalog::signature( $settings ), $stored['signature'] ) ? $stored : false;
	}
	public static function choices( $settings ) {
		$stored = self::stored( $settings ); $choices = array( '' => 'انتخاب نوع بن از فهرست دریافت‌شده…' );
		foreach ( $stored ? $stored['rows'] : array() as $row ) { $choices[ $row['id'] ] = $row['id'] . ' — ' . $row['title'] . ' (' . $row['third_party'] . ')'; }
		return $choices;
	}
	public static function normalize( $data ) {
		if ( ! is_array( $data ) ) { return new WP_Error( 'rkw_coupon_types_response', 'پاسخ انواع بن سازمانی معتبر نیست.' ); }
		if ( isset( $data['items'] ) ) { $data = $data['items']; }
		if ( isset( $data['Id'] ) || isset( $data['id'] ) ) { $data = array( $data ); }
		$out = array();
		foreach ( $data as $row ) {
			if ( ! is_array( $row ) ) { return new WP_Error( 'rkw_coupon_types_response', 'ساختار پاسخ انواع بن سازمانی معتبر نیست.' ); }
			$id = isset( $row['Id'] ) ? $row['Id'] : ( isset( $row['id'] ) ? $row['id'] : null );
			if ( ! ( is_int( $id ) || ( is_string( $id ) && preg_match( '/^[0-9]+$/D', $id ) ) ) || (int) $id <= 0 ) { return new WP_Error( 'rkw_coupon_types_response', 'شناسه صحیح و مثبت نوع بن سازمانی در پاسخ وجود ندارد.' ); }
			$id = (int) $id;
			$out[ $id ] = array( 'id' => $id, 'title' => sanitize_text_field( isset( $row['title'] ) ? $row['title'] : '' ), 'third_party' => sanitize_text_field( isset( $row['thirdPartyName'] ) ? $row['thirdPartyName'] : '' ) );
		}
		return array_values( $out );
	}
	public static function refresh() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) { wp_die( 'عدم دسترسی' ); }
		check_admin_referer( 'rkw_coupon_types_refresh' );
		$c = new RKW_Client();
		if ( ! $c->is_v21() ) { wp_die( 'دریافت انواع بن از این سرویس به API نسخه ۲۱ نیاز دارد.' ); }
		$r = $c->coupon_types21();
		if ( ! is_wp_error( $r ) ) { $r = self::normalize( $r ); }
		if ( is_wp_error( $r ) ) { wp_die( esc_html( $r->get_error_message() ) ); }
		self::store( $r, rkw_settings() );
		wp_safe_redirect( admin_url( 'admin.php?page=rkw-coupon-types&saved=1' ) ); exit;
	}
	public static function page() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) { wp_die( 'عدم دسترسی' ); }
		$stored = self::stored();
		$rows = $stored ? $stored['rows'] : array();
		echo '<div class="wrap rkwe" dir="rtl"><header class="rkwe-header"><h1>انواع بن سازمانی</h1></header><section class="rkwe-card"><p>برای دریافت ThirdPartyCoupon، شناسه نوع بن با شناسه سیاست تسویه متفاوت است. نوع مربوط به cod و اسنپ‌پی را براساس عنوان واقعی و تنظیمات راهکاران انتخاب و در ستون couponType قانون همان درگاه وارد کنید. هیچ نوعی خودکار انتخاب نمی‌شود.</p><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="rkw_coupon_types_refresh">';
		wp_nonce_field( 'rkw_coupon_types_refresh' );
		echo '<button class="button button-primary">دریافت انواع بن از راهکاران (بدون ثبت فاکتور)</button></form><table class="widefat striped"><thead><tr><th>شناسه نوع بن</th><th>عنوان</th><th>طرف قرارداد</th></tr></thead><tbody>';
		foreach ( $rows as $row ) { echo '<tr><td>' . (int) $row['id'] . '</td><td>' . esc_html( $row['title'] ) . '</td><td>' . esc_html( $row['third_party'] ) . '</td></tr>'; }
		if ( ! $rows ) { echo '<tr><td colspan="3">' . ( $stored ? 'راهکاران برای این اتصال فهرست خالی انواع بن برگرداند؛ نوع بن معتبری برای انتخاب وجود ندارد.' : 'فهرست معتبر برای اتصال فعلی ذخیره نشده است.' ) . '</td></tr>'; }
		echo '</tbody></table><p>اگر عنوان صحیح قابل تشخیص نیست، نتیجه فهرست را با مدیر راهکاران تطبیق دهید؛ شناسه ۴۶ سیاست تسویه، شناسه نوع بن را تعیین نمی‌کند.</p></section></div>';
	}
}
