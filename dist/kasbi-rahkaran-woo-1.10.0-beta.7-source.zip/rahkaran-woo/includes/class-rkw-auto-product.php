<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** WooCommerce admin saves -> only the matching Rahkaran product. */
class RKW_Auto_Product {
	private static $running = array();
	private static $completed = array();
	const NOTICE_KEY = 'rkw_auto_product_notice_';

	public static function init() {
		add_action( 'woocommerce_product_options_sku', array( __CLASS__, 'parent_field' ), 20 );
		add_action( 'woocommerce_admin_process_product_object', array( __CLASS__, 'save_parent_meta' ), 20 );
		add_action( 'woocommerce_process_product_meta', array( __CLASS__, 'after_parent_save' ), 99, 2 );
		add_action( 'woocommerce_variation_options_pricing', array( __CLASS__, 'variation_field' ), 20, 3 );
		add_action( 'woocommerce_save_product_variation', array( __CLASS__, 'after_variation_save' ), 99, 2 );
		add_action( 'admin_notices', array( __CLASS__, 'notice' ) );
	}

	public static function parent_field() {
		global $product_object, $post;
		$id = $product_object && is_a( $product_object, 'WC_Product' ) ? $product_object->get_id() : ( $post ? (int) $post->ID : 0 );
		$product = $id ? wc_get_product( $id ) : false;
		woocommerce_wp_text_input( array(
			'id' => '_rahkaran_product_id',
			'label' => 'شناسه محصول راهکاران',
			'value' => $product ? $product->get_meta( '_rahkaran_product_id', true ) : '',
			'type' => 'number',
			'custom_attributes' => array( 'min' => '1', 'step' => '1' ),
			'description' => 'پس از انتشار یا به‌روزرسانی محصول ساده، فقط این شناسه از راهکاران همگام می‌شود. برای محصولات متغیر، شناسه را در هر متغیر وارد کنید.',
			'desc_tip' => true,
		) );
	}

	public static function save_parent_meta( $product ) {
		if ( ! $product || ! current_user_can( 'edit_post', $product->get_id() ) ) { return; }
		if ( ! isset( $_POST['_rahkaran_product_id'] ) ) { return; }
		$value = absint( wp_unslash( $_POST['_rahkaran_product_id'] ) );
		if ( $value ) { $product->update_meta_data( '_rahkaran_product_id', $value ); }
		else { $product->delete_meta_data( '_rahkaran_product_id' ); }
	}

	public static function after_parent_save( $post_id, $post = null ) {
		if ( ! current_user_can( 'edit_post', $post_id ) ) { return; }
		$product = wc_get_product( $post_id );
		// Parent variable saves must not overwrite variation pricing or stock.
		if ( ! $product || ! $product->is_type( 'simple' ) ) { return; }
		self::update( $post_id );
	}

	public static function variation_field( $loop, $variation_data, $variation ) {
		$id = isset( $variation->ID ) ? absint( $variation->ID ) : 0;
		$product = $id ? wc_get_product( $id ) : false;
		$value = $product ? $product->get_meta( '_rahkaran_product_id', true ) : '';
		echo '<p class="form-row form-row-full"><label for="rkw_variation_rahkaran_' . esc_attr( $loop ) . '">شناسه محصول راهکاران (این متغیر)</label>';
		echo '<input type="number" min="1" step="1" class="short" id="rkw_variation_rahkaran_' . esc_attr( $loop ) . '" name="rkw_variation_rahkaran_id[' . esc_attr( $loop ) . ']" value="' . esc_attr( $value ) . '" placeholder="شناسه مستقل در راهکاران">';
		echo '<span class="description">با «ذخیره تغییرات» این متغیر، اطلاعات همین شناسه به‌روزرسانی می‌شود.</span></p>';
	}

	public static function after_variation_save( $variation_id, $loop ) {
		$variation_id = absint( $variation_id );
		if ( ! $variation_id || ! current_user_can( 'edit_post', $variation_id ) ) { return; }
		$product = wc_get_product( $variation_id );
		if ( ! $product || ! $product->is_type( 'variation' ) ) { return; }
		if ( isset( $_POST['rkw_variation_rahkaran_id'] ) && is_array( $_POST['rkw_variation_rahkaran_id'] ) && array_key_exists( $loop, $_POST['rkw_variation_rahkaran_id'] ) ) {
			$number = absint( wp_unslash( $_POST['rkw_variation_rahkaran_id'][ $loop ] ) );
			if ( $number ) { $product->update_meta_data( '_rahkaran_product_id', $number ); }
			else { $product->delete_meta_data( '_rahkaran_product_id' ); }
			$product->save_meta_data();
		}
		self::update( $variation_id );
	}

	private static function failure( $woocommerce_id, $message ) {
		$clean = sanitize_text_field( $message );
		RKW_Log::add( 'error', 'بروزرسانی خودکار ووکامرس ' . $woocommerce_id . ': ' . $clean );
		if ( get_current_user_id() ) {
			set_transient( self::NOTICE_KEY . get_current_user_id(), 'بروزرسانی خودکار راهکاران برای محصول ' . $woocommerce_id . ' انجام نشد: ' . $clean, 10 * MINUTE_IN_SECONDS );
		}
	}

	public static function notice() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) { return; }
		$key = self::NOTICE_KEY . get_current_user_id();
		$message = get_transient( $key );
		if ( ! $message ) { return; }
		delete_transient( $key );
		echo '<div class="notice notice-warning is-dismissible"><p>' . esc_html( $message ) . '</p></div>';
	}

	public static function update( $woocommerce_id ) {
		$settings = rkw_settings();
		if ( empty( $settings['auto_product_on_save'] ) ) { return; }
		$woocommerce_id = absint( $woocommerce_id );
		if ( ! $woocommerce_id || isset( self::$running[ $woocommerce_id ] ) || isset( self::$completed[ $woocommerce_id ] ) ) { return; }
		$product = wc_get_product( $woocommerce_id );
		if ( ! $product ) { return; }
		$rahkaran_id = absint( $product->get_meta( '_rahkaran_product_id', true ) );
		if ( ! $rahkaran_id ) { return; }
		self::$running[ $woocommerce_id ] = true;
		try {
			$client = new RKW_Client();
			$source = 'cached';
			// The existing page snapshots are keyed by connection; do not use stale data from another account.
			$saved = 'v21' === $settings['api'] ? RKW_Snapshot::find_product( $rahkaran_id ) : null;
			$item = $saved && isset( $saved['item'] ) && isset( $saved['saved_at'] ) && time() - (int) $saved['saved_at'] <= DAY_IN_SECONDS ? $saved['item'] : null;
			if ( ! $item || ( ! empty( $settings['sync_price'] ) && null === $item['price'] && 'v21' === $settings['api'] ) ) {
				$source = 'direct';
				$raw = $client->product_by_id( $rahkaran_id );
				if ( is_wp_error( $raw ) ) { self::failure( $woocommerce_id, $raw->get_error_message() ); return; }
				$item = RKW_Sync::normalize_single( $raw, $settings['api'] );
				if ( ! $item || (int) $item['id'] !== $rahkaran_id ) {
					self::failure( $woocommerce_id, 'شناسه محصول در پاسخ راهکاران یافت نشد یا با شناسه ثبت‌شده مطابقت ندارد.' );
					return;
				}
			}
			// In v19 product details have no price. Query Price for this product alone.
			if ( 'v19' === $settings['api'] && ! empty( $settings['sync_price'] ) && ! empty( $item['unit'] ) ) {
				$prices = $client->prices19( array( $rahkaran_id => (int) $item['unit'] ) );
				if ( is_wp_error( $prices ) ) { self::failure( $woocommerce_id, $prices->get_error_message() ); return; }
				foreach ( (array) $prices as $price ) {
					if ( ! is_array( $price ) || ! isset( $price['itemId'] ) || 1 !== (int) $price['itemId'] ) { continue; }
					$key = $settings['price_field'];
					$item['price'] = isset( $price[ $key ] ) && is_numeric( $price[ $key ] ) ? (float) $price[ $key ] : null;
					if ( isset( $price['discount'], $price['netOfFee'] ) && (float) $price['discount'] > 0 ) { $item['sale'] = (float) $price['netOfFee']; }
					break;
				}
			}
			$result = RKW_Sync::update_target( $woocommerce_id, $item, $client );
			if ( is_wp_error( $result ) ) { self::failure( $woocommerce_id, $result->get_error_message() ); return; }
			self::$completed[ $woocommerce_id ] = true;
			RKW_Log::add( 'info', sprintf( 'بروزرسانی خودکار %s ووکامرس %d از کالای راهکاران %d (%s).', $product->is_type( 'variation' ) ? 'متغیر' : 'محصول', $woocommerce_id, $rahkaran_id, $source ) );
		} catch ( Exception $e ) {
			self::failure( $woocommerce_id, $e->getMessage() );
		} finally {
			unset( self::$running[ $woocommerce_id ] );
		}
	}
}
