<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Reporting PDF: ExportReportToJson, ordered scalar parameters only. */
class RKW_Reports {
	public static function init() { add_action( 'admin_post_rkw_report_export', array( __CLASS__, 'export' ) ); }
	public static function menu() { add_submenu_page( 'rkw', 'گزارش وب‌سرویس', 'گزارش وب‌سرویس', 'manage_options', 'rkw-reports', array( __CLASS__, 'page' ) ); }
	public static function page() {
		if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'عدم دسترسی' ); }
		echo '<div class="wrap rkwe" dir="rtl"><header class="rkwe-header"><h1>دریافت گزارش از وب‌سرویس</h1></header><section class="rkwe-card"><p>گزارش باید در مرور گزارش‌های راهکاران ساخته و دسترسی آن به کاربر وب‌سرویس داده شده باشد. ترتیب پارامترها با Report Builder یکسان باشد؛ فیلتر چندانتخابی طبق مستند پشتیبانی نمی‌شود.</p><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="rkw_report_export">'; wp_nonce_field( 'rkw_report_export' );
		echo '<label class="rkwe-field"><span>مسیر گزارش</span><input name="report_path" placeholder="CustomReports/product" required></label><label class="rkwe-field"><span>پارامترها به صورت شیء JSON (ترتیب را رعایت کنید)</span><textarea name="parameters" rows="6" dir="ltr">{}</textarea></label><button class="button button-primary">دریافت فایل JSON گزارش</button></form></section></div>';
	}
	public static function export() {
		if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'عدم دسترسی' ); }
		check_admin_referer( 'rkw_report_export' );
		$raw = isset( $_POST['parameters'] ) && is_string( $_POST['parameters'] ) ? wp_unslash( $_POST['parameters'] ) : '{}';
		$parameters = json_decode( $raw, true );
		if ( strlen( $raw ) > 65536 || ! is_array( $parameters ) || JSON_ERROR_NONE !== json_last_error() || '{' !== substr( ltrim( $raw ), 0, 1 ) ) { wp_die( 'پارامترها باید شیء JSON معتبر باشند.' ); }
		$path = isset( $_POST['report_path'] ) && is_string( $_POST['report_path'] ) ? trim( wp_unslash( $_POST['report_path'] ) ) : '';
		$client = new RKW_Client(); $result = $client->export_report( $path, $parameters );
		if ( is_wp_error( $result ) ) { wp_die( esc_html( $result->get_error_message() ) ); }
		nocache_headers(); header( 'Content-Type: application/json; charset=utf-8' ); header( 'Content-Disposition: attachment; filename="rahkaran-report.json"' );
		echo wp_json_encode( $result, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT ); exit;
	}
}
