<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** وفاداری: تطبیق عضو، اعتبار API v21، استفاده اختیاری در سبد، ورود شناسه اعضا از CSV/XLSX. */
class RKW_Loyalty {
	const META_MEMBER = '_rkw_loyalty_member_id';
	const ORDER_AMOUNT = '_rkw_loyalty_credit_amount';
	const ORDER_MEMBER = '_rkw_loyalty_member_id';
	const ORDER_LABEL = '_rkw_loyalty_fee_label';
	const SESSION = 'rkw_loyalty_use';

	public static function init() {
		// در به‌روزرسانی خودکار، هوک فعال‌سازی همیشه اجرا نمی‌شود.
		if ( get_option( 'rkw_loyalty_db_version' ) !== '1.6' ) { self::install_table(); update_option( 'rkw_loyalty_db_version', '1.6', false ); }
		add_shortcode( 'kasbi_loyalty', array( __CLASS__, 'shortcode' ) );
		if ( ! shortcode_exists( 'loyalty' ) ) { add_shortcode( 'loyalty', array( __CLASS__, 'shortcode' ) ); }
		add_action( 'admin_post_rkw_loyalty_use', array( __CLASS__, 'choose_credit' ) );
		add_action( 'admin_post_rkw_loyalty_import', array( __CLASS__, 'import' ) );
		add_action( 'admin_post_rkw_loyalty_create', array( __CLASS__, 'create_member' ) );
		add_action( 'woocommerce_cart_calculate_fees', array( __CLASS__, 'cart_fee' ), 25 );
		add_action( 'woocommerce_checkout_create_order', array( __CLASS__, 'checkout_meta' ), 10, 2 );
		add_action( 'woocommerce_store_api_checkout_update_order_meta', array( __CLASS__, 'block_checkout_meta' ), 10, 1 );
		add_action( 'woocommerce_checkout_order_processed', array( __CLASS__, 'clear_order_credit' ) );
		add_action( 'woocommerce_store_api_checkout_order_processed', array( __CLASS__, 'clear_block_credit' ) );
		add_filter( 'rkw_order_payload', array( __CLASS__, 'extend_payload' ), 30, 3 );
	}

	public static function table() { global $wpdb; return $wpdb->prefix . 'rahkaran_loyalty'; }

	/** عمداً نام جدول با نسخه قدیمی یکی است تا لیست اعضای موجود از بین نرود. */
	public static function install_table() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$table = self::table();
		$charset = $wpdb->get_charset_collate();
		$sql = "CREATE TABLE $table (
			member_id bigint(20) unsigned NOT NULL,
			mobile varchar(30) NOT NULL,
			first_name varchar(100) DEFAULT NULL,
			last_name varchar(100) DEFAULT NULL,
			PRIMARY KEY  (member_id),
			KEY mobile (mobile)
		) $charset;";
		dbDelta( $sql );
	}

	private static function first_row( $result ) {
		if ( ! is_array( $result ) ) { return null; }
		if ( isset( $result[0] ) && is_array( $result[0] ) ) { return $result[0]; }
		return isset( $result['Id'] ) || isset( $result['id'] ) ? $result : null;
	}
	private static function mobile( $uid ) {
		$mobile = RKW_Orders::normalize_mobile( get_user_meta( $uid, 'billing_phone', true ) );
		$u = get_userdata( $uid );
		if ( $u && RKW_Extensions::settings()['username_mobile_enabled'] ) {
			$login = RKW_Orders::normalize_mobile( $u->user_login );
			if ( preg_match( '/^09\d{9}$/', $login ) ) { $mobile = $login; }
		}
		return preg_match( '/^09\d{9}$/', $mobile ) ? $mobile : '';
	}
	private static function member_id( $uid, $client ) {
		$id = absint( get_user_meta( $uid, self::META_MEMBER, true ) );
		if ( $id ) { return $id; }
		// شناسه ذخیره‌شده افزونه وفاداری قدیمی.
		$id = absint( get_user_meta( $uid, 'LoyaltyMemberID', true ) );
		if ( $id ) { update_user_meta( $uid, self::META_MEMBER, $id ); return $id; }
		$mobile = self::mobile( $uid );
		if ( ! $mobile ) { return new WP_Error( 'rkw_mobile', 'شماره موبایل معتبر برای این حساب ثبت نشده است.' ); }
		global $wpdb;
		$from_table = $wpdb->get_var( $wpdb->prepare( 'SELECT member_id FROM ' . self::table() . ' WHERE mobile = %s LIMIT 1', $mobile ) );
		if ( $from_table ) { update_user_meta( $uid, self::META_MEMBER, absint( $from_table ) ); return absint( $from_table ); }
		$customer_id = absint( get_user_meta( $uid, '_rahkaran_customer_id', true ) );
		if ( ! $customer_id ) { $customer_id = absint( get_user_meta( $uid, 'rahkaran-code', true ) ); }
		if ( ! $customer_id ) {
			$customers = $client->find_customer21( $mobile, 2 );
			if ( is_wp_error( $customers ) ) { return $customers; }
			$row = self::first_row( $customers );
			if ( $row ) { $customer_id = isset( $row['Id'] ) ? absint( $row['Id'] ) : ( isset( $row['id'] ) ? absint( $row['id'] ) : 0 ); }
			if ( $customer_id ) { update_user_meta( $uid, '_rahkaran_customer_id', $customer_id ); }
		}
		if ( ! $customer_id ) { return new WP_Error( 'rkw_customer', 'مشتری در راهکاران پیدا نشد.' ); }
		$result = $client->loyalty_member_by_customer21( $customer_id );
		if ( is_wp_error( $result ) ) { return $result; }
		$row = self::first_row( $result );
		$id = $row ? ( isset( $row['Id'] ) ? absint( $row['Id'] ) : ( isset( $row['id'] ) ? absint( $row['id'] ) : 0 ) ) : 0;
		if ( ! $id ) { return new WP_Error( 'rkw_member', 'برای این مشتری عضویت وفاداری یافت نشد.' ); }
		update_user_meta( $uid, self::META_MEMBER, $id );
		return $id;
	}

	private static function invoice_ready() {
		$s = rkw_settings();
		return 'v21' === $s['api'] && 'invoice' === $s['order_mode'] && ! empty( $s['order_enabled'] );
	}
	/** اعتبار در واحد ووکامرس، به‌همراه شناسه عضو؛ بدون درخواست زنده در هر بار محاسبه سبد. */
	public static function credit( $uid, $fresh = false ) {
		$ext = RKW_Extensions::settings();
		if ( ! $ext['loyalty_enabled'] || ! $ext['loyalty_program_id'] || 'v21' !== rkw_settings()['api'] ) {
			return new WP_Error( 'rkw_loyalty_disabled', 'باشگاه مشتریان فعال یا پیکربندی نشده است.' );
		}
		$cache_key = 'rkw_loyalty_' . (int) $uid;
		if ( ! $fresh ) { $cached = get_transient( $cache_key ); if ( is_array( $cached ) ) { return $cached; } }
		$api = new RKW_Client();
		$member = self::member_id( $uid, $api );
		if ( is_wp_error( $member ) ) { return $member; }
		// از API جدید برای مانده معتبر با مبلغ تخفیف صفر استفاده می‌شود.
		$result = $api->loyalty_remaining_credit21( $ext['loyalty_program_id'], $member );
		if ( is_wp_error( $result ) ) { return $result; }
		if ( ! is_numeric( $result ) ) { return new WP_Error( 'rkw_credit', 'پاسخ اعتبار وفاداری عددی نیست.' ); }
		$divisor = rkw_price_multiplier();
		$amount = floor( max( 0, (float) $result ) / $divisor * 100 ) / 100;
		$row = array( 'amount' => $amount, 'member_id' => (int) $member );
		set_transient( $cache_key, $row, 5 * MINUTE_IN_SECONDS );
		return $row;
	}
	private static function max_for_cart( $amount, $cart ) {
		$percent = max( 1, min( 100, (int) RKW_Extensions::settings()['loyalty_max_percent'] ) );
		$subtotal = max( 0, (float) $cart->get_cart_contents_total() );
		return max( 0, floor( min( (float) $amount, $subtotal * $percent / 100, $subtotal ) * 100 ) / 100 );
	}
	private static function selected() {
		if ( ! function_exists( 'WC' ) || ! WC()->session ) { return array(); }
		$value = WC()->session->get( self::SESSION, array() );
		return is_array( $value ) ? $value : array();
	}
	public static function shortcode() {
		if ( ! is_user_logged_in() ) { return '<p class="woocommerce-info">برای استفاده از اعتبار وفاداری ابتدا وارد حساب کاربری شوید.</p>'; }
		$opt = RKW_Extensions::settings();
		if ( ! $opt['loyalty_enabled'] || ! self::invoice_ready() ) { return '<p>استفاده از اعتبار وفاداری فعال نیست. لازم است ارسال سفارش فعال و نوع سند «فاکتور» با API نسخه ۲۱ باشد.</p>'; }
		$credit = self::credit( get_current_user_id() );
		if ( is_wp_error( $credit ) ) { return '<p class="woocommerce-info">' . esc_html( $credit->get_error_message() ) . '</p>'; }
		$selected = self::selected();
		$balance = $credit['amount'];
		$max = function_exists( 'WC' ) && WC()->cart ? self::max_for_cart( $balance, WC()->cart ) : $balance;
		$out = '<div class="woocommerce rkw-loyalty-widget" dir="rtl"><h3>اعتبار وفاداری کاسبی راهکاران</h3><p>مانده اعتبار: <strong>' . wp_kses_post( wc_price( $balance ) ) . '</strong> — سقف قابل استفاده از این سبد: <strong>' . wp_kses_post( wc_price( $max ) ) . '</strong></p>';
		$out .= '<form action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" method="post"><input type="hidden" name="action" value="rkw_loyalty_use">' . wp_nonce_field( 'rkw_loyalty_use', '_wpnonce', true, false );
		$out .= '<label>مبلغ اعتبار در واحد پول فروشگاه <input type="number" name="amount" min="0" step="0.01" max="' . esc_attr( $max ) . '" value="' . esc_attr( isset( $selected['amount'] ) ? $selected['amount'] : 0 ) . '"></label> <button type="submit" class="button alt">اعمال / به‌روزرسانی اعتبار</button> <small>برای حذف اعتبار عدد صفر را ثبت کنید.</small></form></div>';
		return $out;
	}
	public static function choose_credit() {
		if ( ! is_user_logged_in() || ! function_exists( 'WC' ) || ! WC()->session || ! WC()->cart ) { wp_die( 'برای این عملیات باید وارد حساب خود شوید و سبد خرید داشته باشید.' ); }
		check_admin_referer( 'rkw_loyalty_use' );
		if ( ! self::invoice_ready() ) { wp_die( 'پرداخت با اعتبار نیازمند API نسخه ۲۱ و ارسال فعال سند از نوع فاکتور است.' ); }
		$amount = isset( $_POST['amount'] ) ? max( 0, (float) wc_format_decimal( wp_unslash( $_POST['amount'] ) ) ) : 0;
		if ( $amount < 0.01 ) { WC()->session->__unset( self::SESSION ); wc_add_notice( 'اعتبار وفاداری از سبد حذف شد.', 'notice' ); }
		else {
			$credit = self::credit( get_current_user_id(), true );
			if ( is_wp_error( $credit ) ) { WC()->session->__unset( self::SESSION ); wc_add_notice( $credit->get_error_message(), 'error' ); }
			else {
				$max = self::max_for_cart( $credit['amount'], WC()->cart );
				if ( $amount > $max || $max <= 0 ) { WC()->session->__unset( self::SESSION ); wc_add_notice( 'مبلغ از سقف اعتبار مجاز بیشتر است.', 'error' ); }
				else { WC()->session->set( self::SESSION, array( 'user_id' => get_current_user_id(), 'member_id' => $credit['member_id'], 'amount' => $amount, 'time' => time() ) ); wc_add_notice( 'اعتبار وفاداری به سبد اعمال شد.', 'success' ); }
			}
		}
		wp_safe_redirect( wp_get_referer() ? wp_get_referer() : wc_get_cart_url() );
		exit;
	}
	public static function cart_fee( $cart ) {
		$ext = RKW_Extensions::settings();
		if ( ! $ext['loyalty_enabled'] || ! self::invoice_ready() || ! is_user_logged_in() || ! $cart ) { return; }
		if ( is_admin() && ! wp_doing_ajax() ) { return; }
		$chosen = self::selected();
		if ( empty( $chosen['user_id'] ) || (int) $chosen['user_id'] !== get_current_user_id() || empty( $chosen['amount'] ) || empty( $chosen['member_id'] ) || empty( $chosen['time'] ) || time() - (int) $chosen['time'] > 15 * MINUTE_IN_SECONDS ) { return; }
		$limit = self::max_for_cart( (float) $chosen['amount'], $cart );
		$amount = min( (float) $chosen['amount'], $limit );
		if ( $amount > 0 ) { $cart->add_fee( $ext['loyalty_fee_label'], -$amount, false ); }
	}
	private static function attach_order_meta( $order ) {
		$selected = self::selected();
		$ext = RKW_Extensions::settings();
		if ( ! $ext['loyalty_enabled'] || ! is_user_logged_in() || (int) $order->get_user_id() !== get_current_user_id() || empty( $selected['user_id'] ) || (int) $selected['user_id'] !== get_current_user_id() || empty( $selected['amount'] ) || empty( $selected['member_id'] ) ) { return; }
		// منبع قطعی اعتبارِ اعمال‌شده، آیتم هزینه ثبت‌شده در سفارش است، نه ورودی فرم.
		foreach ( $order->get_fees() as $fee ) {
			if ( $fee->get_name() === $ext['loyalty_fee_label'] && (float) $fee->get_total() < 0 ) {
				$actual = abs( (float) $fee->get_total() );
				$amount = min( $actual, (float) $selected['amount'] );
				if ( $amount > 0 ) { $order->update_meta_data( self::ORDER_AMOUNT, $amount ); $order->update_meta_data( self::ORDER_MEMBER, (int) $selected['member_id'] ); $order->update_meta_data( self::ORDER_LABEL, $ext['loyalty_fee_label'] ); }
				break;
			}
		}
	}
	public static function checkout_meta( $order, $data ) { self::attach_order_meta( $order ); }
	public static function block_checkout_meta( $order ) { self::attach_order_meta( $order ); }
	public static function clear_order_credit( $order_id ) { if ( function_exists( 'WC' ) && WC()->session ) { WC()->session->__unset( self::SESSION ); } }
	public static function clear_block_credit( $order ) { self::clear_order_credit( $order->get_id() ); }
	public static function extend_payload( $payload, $order, $s ) {
		$ext = RKW_Extensions::settings();
		$old_credit = $order->get_meta( 'LoyaltyCartCoupon' );
		if ( is_array( $old_credit ) && ! empty( $old_credit['amount'] ) && ! $order->get_meta( self::ORDER_AMOUNT ) ) { return new WP_Error( 'rkw_legacy_loyalty_order', 'این سفارش اعتبار وفاداری قدیمی دارد؛ قبل از ارسال، روش مصرف کوپن/فی و سابقه مصرف اعتبار را با سند قبلی تطبیق دهید. اعتبار قدیمی خودکار دوباره مصرف نمی‌شود.' ); }
		$amount = max( 0, (float) $order->get_meta( self::ORDER_AMOUNT ) );
		$fee_label = $order->get_meta( self::ORDER_LABEL ) ?: $ext['loyalty_fee_label'];
		foreach ( $order->get_fees() as $fee ) {
			if ( $fee->get_name() === $fee_label && (float) $fee->get_total() < 0 && ! $amount ) {
				return new WP_Error( 'rkw_missing_credit_meta', 'هزینه منفی وفاداری در سفارش وجود دارد، ولی شناسه یا مبلغ تأییدشده وفاداری ذخیره نشده است؛ ارسال متوقف شد.' );
			}
		}
		if ( $amount > 0 && ( ! $ext['loyalty_enabled'] || 'invoice' !== $s['order_mode'] || 'v21' !== $s['api'] ) ) {
			return new WP_Error( 'rkw_loyalty_mismatch', 'این سفارش با اعتبار وفاداری ثبت شده ولی تنظیمات کنونی اجازه ارسال این نوع پرداخت را نمی‌دهند. ابتدا تنظیمات وفاداری/نوع سند را بررسی کنید.' );
		}
		if ( ! $ext['loyalty_enabled'] || 'invoice' !== $s['order_mode'] || 'v21' !== $s['api'] ) { return $payload; }
		$member = absint( $order->get_meta( self::ORDER_MEMBER ) );
		if ( ! $amount || ! $member || ! $ext['loyalty_program_id'] ) { return $payload; }
		$validated = false;
		foreach ( $order->get_fees() as $fee ) {
			if ( $fee->get_name() === ( $order->get_meta( self::ORDER_LABEL ) ?: $ext['loyalty_fee_label'] ) && (float) $fee->get_total() < 0 && abs( (float) $fee->get_total() + (float) $fee->get_total_tax() ) - $amount <= 0.01 && abs( abs( (float) $fee->get_total() + (float) $fee->get_total_tax() ) - $amount ) <= 0.01 ) { $validated = true; break; }
		}
		if ( ! $validated ) { return new WP_Error( 'rkw_loyalty_fee', 'مبلغ اعتبار وفاداری در اقلام سفارش با مقدار ثبت‌شده مطابقت ندارد.' ); }
		$pay = round( $amount * rkw_price_multiplier( $s ), 2 );
		if ( ! isset( $payload['payments'] ) || ! is_array( $payload['payments'] ) ) { $payload['payments'] = array(); }
		if ( empty( $payload['receipts'][0]['amount'] ) || $pay > (float) $payload['receipts'][0]['amount'] + 0.01 ) { return new WP_Error( 'rkw_loyalty_total', 'مبلغ اعتبار وفاداری بیشتر از مانده قابل پرداخت سند است.' ); }
		$payload['receipts'][] = array( 'key' => 'LoyaltyCredit', 'amount' => $pay, 'loyaltyProgramId' => (int) $ext['loyalty_program_id'] );
		if ( isset( $payload['receipts'][0]['amount'] ) ) { $payload['receipts'][0]['amount'] = max( 0, round( (float) $payload['receipts'][0]['amount'] - $pay, 2 ) ); }
		$payload['document']['data']['loyaltyProgramID'] = (int) $ext['loyalty_program_id'];
		return $payload;
	}

	/** نمای مدیریت اعضای واردشده و آخرین گزارش؛ داده‌های هویتی فقط مدیر می‌بیند. */
	public static function page() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) { wp_die( 'عدم دسترسی' ); }
		global $wpdb;
		$table = self::table();
		$count = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . $table );
		$pages = max( 1, (int) ceil( $count / 20 ) );
		$page = isset( $_GET['paged'] ) ? max( 1, min( $pages, absint( $_GET['paged'] ) ) ) : 1;
		$offset = ( $page - 1 ) * 20;
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT member_id, mobile, first_name, last_name FROM ' . $table . ' ORDER BY member_id DESC LIMIT 20 OFFSET %d', $offset ), ARRAY_A );
		echo '<div class="wrap rkwe" dir="rtl"><header class="rkwe-header"><div><span>کاسبی راهکاران / باشگاه مشتریان</span><h1>باشگاه مشتریان راهکاران</h1><p>نمایش اعضای ثبت‌شده و واردکردن فهرست وفاداری از فایل خروجی راهکاران.</p></div><a class="button" href="' . esc_url( admin_url( 'admin.php?page=rkw-extensions' ) ) . '">تنظیمات وفاداری</a></header>';
		if ( isset( $_GET['imported'] ) ) { echo '<div class="notice notice-success inline"><p>' . esc_html( absint( $_GET['imported'] ) ) . ' عضو ثبت یا به‌روزرسانی شد.</p></div>'; }
		if ( isset( $_GET['import_error'] ) ) { echo '<div class="notice notice-error inline"><p>' . esc_html( sanitize_text_field( wp_unslash( $_GET['import_error'] ) ) ) . '</p></div>'; }
		if ( isset( $_GET['member_created'] ) ) { echo '<div class="notice notice-success inline"><p>عضویت جدید با شناسه ' . esc_html( absint( $_GET['member_created'] ) ) . ' در راهکاران ثبت شد.</p></div>'; }
		echo '<div class="rkwe-cards"><section class="rkwe-card"><h2>واردکردن اعضا از CSV یا Excel</h2><p>ترتیب ستون‌ها مطابق فایل قدیمی: <strong>شناسه، نام، نام خانوادگی، نام و نام خانوادگی، شماره موبایل</strong>. ردیف نخست باید عنوان ستون‌ها باشد؛ حداکثر ۵۰۰۰ عضو و ۲ مگابایت.</p>';
		echo '<form action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" method="post" enctype="multipart/form-data"><input type="hidden" name="action" value="rkw_loyalty_import">';
		wp_nonce_field( 'rkw_loyalty_import' );
		echo '<input type="file" name="members_file" accept=".csv,.xlsx" required> <button class="button button-primary">بارگذاری و به‌روزرسانی اعضا</button></form><p class="rkwe-hint">اعضای قبلی حذف نمی‌شوند؛ شناسه تکراری به‌روزرسانی می‌شود. فرمت‌های CSV UTF-8 و XLSX پشتیبانی می‌شوند.</p></section>';
		echo '<section class="rkwe-card"><h2>وضعیت باشگاه</h2><strong class="rkwe-num">' . esc_html( number_format_i18n( $count ) ) . '</strong><p>عضو ثبت‌شده در بانک اطلاعاتی سایت (شامل داده‌های قدیمی).</p><p>کد کوتاه نمایش اعتبار: <code>[kasbi_loyalty]</code></p><p class="rkwe-hint">اعتبار واقعی فقط از API راهکاران دریافت می‌شود؛ داده‌های این جدول صرفاً برای تطبیق شناسه عضو هستند.</p></section></div>';
		echo '<div class="rkwe-cards"><section class="rkwe-card"><h2>طرح‌های وفاداری راهکاران</h2><p>برای پیدا کردن شناسه واقعی برنامه، روی دکمه دریافت کلیک کن. دریافت فقط با درخواست مدیر انجام می‌شود.</p><a class="button button-secondary" href="' . esc_url( wp_nonce_url( admin_url( 'admin.php?page=rkw-loyalty&fetch_programs=1' ), 'rkw_loyalty_programs' ) ) . '">دریافت طرح‌ها از راهکاران</a>';
		if ( isset( $_GET['fetch_programs'] ) && check_admin_referer( 'rkw_loyalty_programs' ) ) {
			$client = new RKW_Client();
			$list = $client->loyalty_programs21( 1, 50 );
			if ( is_wp_error( $list ) ) { echo '<p class="rkwe-error">' . esc_html( $list->get_error_message() ) . '</p>'; }
			elseif ( is_array( $list ) ) {
				echo '<div class="rkwe-overflow"><table class="widefat striped"><thead><tr><th>شناسه</th><th>عنوان برنامه</th><th>اعتبار</th></tr></thead><tbody>';
				$program_rows = isset( $list['items'] ) && is_array( $list['items'] ) ? $list['items'] : $list;
				foreach ( $program_rows as $program ) {
					if ( ! is_array( $program ) ) { continue; }
					echo '<tr><td>' . esc_html( isset( $program['id'] ) ? $program['id'] : '' ) . '</td><td>' . esc_html( isset( $program['title'] ) ? $program['title'] : '' ) . '</td><td>' . esc_html( ! empty( $program['isCreditProfitType'] ) ? 'دارد' : 'ندارد' ) . '</td></tr>';
				}
				echo '</tbody></table></div>';
			}
		}
		echo '</section><section class="rkwe-card"><h2>ایجاد عضو در راهکاران</h2><p>این عملیات فقط با کلیک مدیر و شناسه مشتری و الگوی عضویت معتبر در راهکاران انجام می‌شود.</p><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="rkw_loyalty_create">';
		wp_nonce_field( 'rkw_loyalty_create' );
		echo '<label class="rkwe-field"><span>شناسه مشتری راهکاران</span><input type="number" min="1" name="customer_id" required></label><label class="rkwe-field"><span>شناسه الگوی عضویت</span><input type="number" min="1" name="pattern_id" required></label><button class="button button-primary" type="submit">ایجاد عضو</button></form></section></div>';
		echo '<section class="rkwe-card"><h2>فهرست اعضای واردشده</h2><div class="rkwe-overflow"><table class="widefat striped"><thead><tr><th>شناسه عضو</th><th>نام</th><th>نام خانوادگی</th><th>شماره موبایل</th></tr></thead><tbody>';
		foreach ( (array) $rows as $row ) { echo '<tr><td>' . esc_html( $row['member_id'] ) . '</td><td>' . esc_html( $row['first_name'] ) . '</td><td>' . esc_html( $row['last_name'] ) . '</td><td dir="ltr">' . esc_html( $row['mobile'] ) . '</td></tr>'; }
		if ( ! $rows ) { echo '<tr><td colspan="4">هنوز عضوی وارد نشده است.</td></tr>'; }
		echo '</tbody></table></div>';
		RKW_Pagination::render( $page, $pages, array( 'page' => 'rkw-loyalty' ), 'paged', 'rkwe-pagination' );
		echo '</section></div>';
	}

	public static function create_member() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) { wp_die( 'عدم دسترسی' ); }
		check_admin_referer( 'rkw_loyalty_create' );
		$customer_id = isset( $_POST['customer_id'] ) ? absint( $_POST['customer_id'] ) : 0;
		$pattern_id = isset( $_POST['pattern_id'] ) ? absint( $_POST['pattern_id'] ) : 0;
		$url = admin_url( 'admin.php?page=rkw-loyalty' );
		if ( ! $customer_id || ! $pattern_id || 'v21' !== rkw_settings()['api'] ) {
			wp_safe_redirect( add_query_arg( 'import_error', rawurlencode( 'شناسه مشتری/الگوی عضویت معتبر نیست یا API نسخه ۲۱ فعال نیست.' ), $url ) ); exit;
		}
		$api = new RKW_Client();
		$existing = $api->loyalty_member_by_customer21( $customer_id );
		if ( is_wp_error( $existing ) ) { wp_safe_redirect( add_query_arg( 'import_error', rawurlencode( $existing->get_error_message() ), $url ) ); exit; }
		if ( self::first_row( $existing ) ) { wp_safe_redirect( add_query_arg( 'import_error', rawurlencode( 'این مشتری قبلاً عضو وفاداری است؛ ایجاد مجدد انجام نشد.' ), $url ) ); exit; }
		$result = $api->create_loyalty_member21( $customer_id, $pattern_id );
		if ( is_wp_error( $result ) || ! is_numeric( $result ) || (int) $result < 1 ) {
			wp_safe_redirect( add_query_arg( 'import_error', rawurlencode( is_wp_error( $result ) ? $result->get_error_message() : 'شناسه عضو معتبر برنگشت؛ ثبت را در راهکاران بررسی کنید.' ), $url ) ); exit;
		}
		RKW_Log::add( 'info', 'ایجاد عضو وفاداری در راهکاران؛ شناسه عضو: ' . (int) $result );
		wp_safe_redirect( add_query_arg( 'member_created', (int) $result, $url ) ); exit;
	}

	public static function import() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) { wp_die( 'عدم دسترسی' ); }
		check_admin_referer( 'rkw_loyalty_import' );
		$redirect = admin_url( 'admin.php?page=rkw-loyalty' );
		$fail = function ( $message ) use ( $redirect ) { wp_safe_redirect( add_query_arg( 'import_error', rawurlencode( $message ), $redirect ) ); exit; };
		$file = isset( $_FILES['members_file'] ) ? $_FILES['members_file'] : null;
		if ( ! is_array( $file ) || ! isset( $file['error'] ) || UPLOAD_ERR_OK !== (int) $file['error'] || empty( $file['tmp_name'] ) || ! is_uploaded_file( $file['tmp_name'] ) ) { $fail( 'فایل قابل خواندن نیست.' ); }
		if ( (int) $file['size'] > 2 * 1024 * 1024 ) { $fail( 'اندازه فایل بیش از دو مگابایت است.' ); }
		$extension = strtolower( pathinfo( sanitize_file_name( $file['name'] ), PATHINFO_EXTENSION ) );
		if ( ! in_array( $extension, array( 'xlsx', 'csv' ), true ) ) { $fail( 'فقط فایل‌های CSV و XLSX مجاز هستند.' ); }
		$rows = array();
		if ( 'xlsx' === $extension ) {
			if ( ! function_exists( 'simplexml_load_string' ) || ! class_exists( 'ZipArchive' ) ) { $fail( 'برای ورود XLSX باید افزونه‌های PHP به نام SimpleXML و Zip فعال باشند. می‌توانید از CSV استفاده کنید.' ); }
			require_once RKW_DIR . 'vendor/simplexlsx/SimpleXLSX.php';
			$sheet = \Shuchkin\SimpleXLSX::parse( $file['tmp_name'] );
			if ( ! $sheet ) { $fail( 'خواندن فایل اکسل ناموفق بود.' ); }
			$rows = $sheet->rows();
		} else {
			$handle = fopen( $file['tmp_name'], 'rb' );
			if ( ! $handle ) { $fail( 'بازکردن فایل CSV ناموفق بود.' ); }
			while ( ( $record = fgetcsv( $handle ) ) !== false && count( $rows ) < 5002 ) { $rows[] = $record; }
			fclose( $handle );
		}
		if ( count( $rows ) < 2 || count( $rows ) > 5001 ) { $fail( 'فایل باید بین ۱ تا ۵۰۰۰ رکورد داشته باشد.' ); }
		$headers = array( 'شناسه', 'نام', 'نام خانوادگی', 'نام و نام خانوادگی', 'شماره موبایل' );
		foreach ( $headers as $i => $header ) {
			$label = isset( $rows[0][ $i ] ) ? trim( preg_replace( '/^\xEF\xBB\xBF/', '', (string) $rows[0][ $i ] ) ) : '';
			if ( $label !== $header ) { $fail( 'نام یا ترتیب ستون‌های فایل معتبر نیست.' ); }
		}
		global $wpdb;
		$table = self::table();
		$imported = 0;
		foreach ( array_slice( $rows, 1 ) as $row ) {
			$id = isset( $row[0] ) ? absint( preg_replace( '/[^0-9]/', '', (string) $row[0] ) ) : 0;
			$mobile = isset( $row[4] ) ? RKW_Orders::normalize_mobile( $row[4] ) : '';
			if ( ! $id || ! preg_match( '/^09\d{9}$/', $mobile ) ) { continue; }
			$record = array( 'member_id' => $id, 'mobile' => $mobile, 'first_name' => sanitize_text_field( isset( $row[1] ) ? $row[1] : '' ), 'last_name' => sanitize_text_field( isset( $row[2] ) ? $row[2] : '' ) );
			$result = $wpdb->replace( $table, $record, array( '%d', '%s', '%s', '%s' ) );
			if ( false !== $result ) { $imported++; }
		}
		RKW_Log::add( 'info', 'به‌روزرسانی فهرست اعضای وفاداری: ' . $imported . ' ردیف' );
		wp_safe_redirect( add_query_arg( 'imported', $imported, $redirect ) );
		exit;
	}
}
