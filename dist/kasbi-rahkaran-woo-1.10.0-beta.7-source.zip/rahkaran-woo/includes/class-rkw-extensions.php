<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** ماژول‌های مهاجرت‌داده‌شده از افزونه‌های جانبی قدیمی. همه به‌صورت پیش‌فرض خاموش‌اند. */
class RKW_Extensions {
	const OPTION = 'rkw_extensions';
	const CAP = 'manage_woocommerce';

	public static function defaults() {
		return array(
			'loyalty_enabled' => 0, 'loyalty_program_id' => 0, 'loyalty_max_percent' => 50,
			'loyalty_fee_label' => 'اعتبار وفاداری راهکاران',
			'first_enabled' => 0, 'first_fee_label' => 'تخفیف خرید اول', 'first_policy_id' => 0,
			'first_policy_price' => 0, 'shipping_enabled' => 0, 'shipping_policy_id' => 0, 'extra_fee_policy_id' => 0,
			'username_mobile_enabled' => 0,
			'shipping_mode' => 'policy', 'shipping_product_id' => 0, 'shipping_unit_id' => 0,
			'shipping_rules' => array(), 'negative_fee_policy_id' => 0,
		);
	}
	public static function settings() {
		$o = get_option( self::OPTION, array() );
		return wp_parse_args( is_array( $o ) ? $o : array(), self::defaults() );
	}
	public static function init() {
		add_action( 'admin_post_rkw_extensions_save', array( __CLASS__, 'save' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'admin_notices', array( __CLASS__, 'legacy_notice' ) );
		add_action( 'woocommerce_cart_calculate_fees', array( __CLASS__, 'first_purchase_fee' ), 999 );
		add_filter( 'rkw_order_payload', array( __CLASS__, 'extend_payload' ), 20, 3 );
	}
	public static function menu() {
		add_submenu_page( 'rkw', 'امکانات تکمیلی | کاسبی راهکاران', 'امکانات تکمیلی', self::CAP, 'rkw-extensions', array( __CLASS__, 'page' ) );
		add_submenu_page( 'rkw', 'باشگاه مشتریان | کاسبی راهکاران', 'باشگاه مشتریان', self::CAP, 'rkw-loyalty', array( 'RKW_Loyalty', 'page' ) );
	}
	public static function assets() {
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
		if ( in_array( $page, array( 'rkw-extensions', 'rkw-loyalty', 'rkw-migration', 'rkw-reports', 'rkw-coupon-types' ), true ) ) {
			wp_enqueue_style( 'rkw-extensions', plugins_url( 'assets/extensions.css', RKW_FILE ), array(), RKW_VER );
		}
	}
	/** هشدار فقط برای همپوشانی افزونه‌های قدیمی، بدون غیرفعال‌کردن خودکار آنها. */
	public static function legacy_notice() {
		if ( ! current_user_can( self::CAP ) || ! isset( $_GET['page'] ) || 0 !== strpos( sanitize_key( wp_unslash( $_GET['page'] ) ), 'rkw' ) ) { return; }
		if ( ! function_exists( 'is_plugin_active' ) ) { require_once ABSPATH . 'wp-admin/includes/plugin.php'; }
		$previous = array(
			'wp-rahkaran/wp-rahkaran.php',
			'wp-rahkaran-loyalty/wp-rahkaran-loyalty.php',
			'wp-rahkaran-remove-fee-first-invoice/wp-rahkaran-remove-fee-first-invoice.php',
			'wp-rahkaran-shipping-policies/wp-rahkaran-shipping-policies.php',
			'wp-rahkaran-user-basis-user-login-digit/wp-rahkaran-user-basis-user-login-digit.php',
		);
		$active = array_filter( $previous, 'is_plugin_active' );
		if ( $active ) { echo '<div class="notice notice-warning"><p><strong>کاسبی راهکاران:</strong> یک یا چند افزونه قدیمی راهکاران هم‌زمان فعال‌اند. برای جلوگیری از اجرای تکراری تخفیف/ارسال سند، مهاجرت را ابتدا در سایت آزمایشی بررسی و افزونه‌های جایگزین‌شده را با دقت غیرفعال کنید. هیچ افزونه‌ای خودکار غیرفعال نمی‌شود.</p></div>'; }
	}

	public static function save() {
		if ( ! current_user_can( self::CAP ) ) { wp_die( 'عدم دسترسی' ); }
		check_admin_referer( 'rkw_extensions_save' );
		$in = isset( $_POST['ext'] ) && is_array( $_POST['ext'] ) ? wp_unslash( $_POST['ext'] ) : array();
		$out = self::defaults();
		foreach ( array( 'loyalty_enabled', 'first_enabled', 'shipping_enabled', 'username_mobile_enabled' ) as $key ) {
			$out[ $key ] = empty( $in[ $key ] ) ? 0 : 1;
		}
		foreach ( array( 'loyalty_program_id', 'first_policy_id', 'shipping_policy_id', 'extra_fee_policy_id', 'shipping_product_id', 'shipping_unit_id', 'negative_fee_policy_id' ) as $key ) {
			$out[ $key ] = isset( $in[ $key ] ) ? max( 0, absint( $in[ $key ] ) ) : 0;
		}
		$out['loyalty_max_percent'] = isset( $in['loyalty_max_percent'] ) ? min( 100, max( 1, absint( $in['loyalty_max_percent'] ) ) ) : 50;
		$out['first_policy_price'] = isset( $in['first_policy_price'] ) ? max( 0, (float) $in['first_policy_price'] ) : 0;
		foreach ( array( 'loyalty_fee_label', 'first_fee_label' ) as $key ) {
			$out[ $key ] = isset( $in[ $key ] ) ? sanitize_text_field( $in[ $key ] ) : self::defaults()[ $key ];
			if ( '' === $out[ $key ] ) { $out[ $key ] = self::defaults()[ $key ]; }
		}
		// تنها با پرشدن شناسه واقعی طرح، قابلیت وفاداری قابل فعال‌سازی است.
		if ( ! $out['loyalty_program_id'] ) { $out['loyalty_enabled'] = 0; }
		if ( ! ( 'product' === ( isset( $in['shipping_mode'] ) ? $in['shipping_mode'] : '' ) ? $out['shipping_product_id'] : $out['shipping_policy_id'] ) ) { $out['shipping_enabled'] = 0; }
		$out['shipping_mode'] = isset( $in['shipping_mode'] ) && 'product' === $in['shipping_mode'] ? 'product' : 'policy';
		$out['shipping_rules'] = RKW_Accounting::sanitize_shipping_rules( isset( $in['shipping_rules'] ) ? $in['shipping_rules'] : array() );
		update_option( self::OPTION, $out, false );
		wp_safe_redirect( admin_url( 'admin.php?page=rkw-extensions&saved=1' ) );
		exit;
	}
	private static function row( $name, $label, $value, $type = 'text', $help = '' ) {
		echo '<label class="rkwe-field"><span>' . esc_html( $label ) . '</span><input type="' . esc_attr( $type ) . '" name="ext[' . esc_attr( $name ) . ']" value="' . esc_attr( $value ) . '" ' . ( 'number' === $type ? 'step="any" min="0"' : '' ) . '>';
		if ( $help ) { echo '<small>' . esc_html( $help ) . '</small>'; }
		echo '</label>';
	}
	private static function toggle( $name, $title, $description, $enabled ) {
		echo '<label class="rkwe-toggle"><input type="checkbox" name="ext[' . esc_attr( $name ) . ']" value="1" ' . checked( (int) $enabled, 1, false ) . '><span><strong>' . esc_html( $title ) . '</strong><small>' . esc_html( $description ) . '</small></span></label>';
	}
	public static function page() {
		if ( ! current_user_can( self::CAP ) ) { wp_die( 'عدم دسترسی' ); }
		$s = self::settings();
		echo '<div class="wrap rkwe" dir="rtl"><header class="rkwe-header"><div><span>کاسبی راهکاران / تنظیمات یکپارچه</span><h1>امکانات تکمیلی</h1><p>قابلیت‌های افزونه‌های قدیمی به‌صورت مستقل و قابل کنترل، بدون تغییر رمز یا نشست اتصال فعلی.</p></div><a href="' . esc_url( admin_url( 'admin.php?page=rkw-loyalty' ) ) . '" class="button button-secondary">مدیریت باشگاه مشتریان</a></header>';
		if ( isset( $_GET['saved'] ) ) { echo '<div class="notice notice-success inline"><p>تنظیمات ذخیره شد.</p></div>'; }
		echo '<div class="rkwe-alert">برای جلوگیری از تغییر ناخواسته مبالغ فاکتور، همه قابلیت‌های جدید در نصب اولیه خاموش هستند. ابتدا شناسه سیاست‌ها را در راهکاران بررسی و سپس روی سایت آزمایشی فعال کنید. در حالت اتصال API نسخه ۱۹، این قابلیت‌ها عملیاتی نیستند.</div>';
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="rkw_extensions_save">';
		wp_nonce_field( 'rkw_extensions_save' );
		echo '<div class="rkwe-grid">';
		echo '<section class="rkwe-card"><div class="rkwe-icon">★</div><h2>وفاداری و اعتبار مشتری</h2>';
		self::toggle( 'loyalty_enabled', 'فعال‌سازی اعتبار وفاداری', 'نمایش اعتبار قابل استفاده و اعمال آن به‌صورت هزینه منفی در سبد خرید با تأیید مشتری', $s['loyalty_enabled'] );
		self::row( 'loyalty_program_id', 'شناسه طرح وفاداری', $s['loyalty_program_id'], 'number', 'شناسه واقعی برنامه در API راهکاران، نه شناسه پیش‌فرض نمونه.' );
		self::row( 'loyalty_max_percent', 'حداکثر درصد اعتبار از مبلغ کالا', $s['loyalty_max_percent'], 'number' );
		self::row( 'loyalty_fee_label', 'عنوان اعتبار در صورتحساب', $s['loyalty_fee_label'] );
		echo '<p class="rkwe-hint">شورت‌کد نمایش به مشتری: <code>[kasbi_loyalty]</code>. پرداخت اعتبار در سند راهکاران فقط برای حالت «فاکتور» اعمال می‌شود.</p></section>';
		echo '<section class="rkwe-card"><div class="rkwe-icon">٪</div><h2>کنترل تخفیف خرید اول</h2>';
		self::toggle( 'first_enabled', 'بررسی سابقه فاکتور مشتری', 'در صورت وجود فاکتور قبلی یا نامشخص بودن پاسخ API، هزینه منفی خرید اول حذف می‌شود.', $s['first_enabled'] );
		self::row( 'first_fee_label', 'عنوان هزینه/تخفیف خرید اول', $s['first_fee_label'] );
		self::row( 'first_policy_id', 'شناسه سیاست فروش خرید اول (اختیاری)', $s['first_policy_id'], 'number', 'شناسه نمونه قدیمی ۸۰ بود؛ اینجا باید شناسه محیط شما وارد شود.' );
		self::row( 'first_policy_price', 'مبلغ سیاست در واحد راهکاران (اختیاری)', $s['first_policy_price'], 'number', 'اگر صفر باشد مبلغ تخفیف همان سفارش پس از تبدیل واحد استفاده می‌شود.' );
		echo '</section>';
		echo '<section class="rkwe-card"><div class="rkwe-icon">↗</div><h2>سیاست هزینه ارسال</h2>';
		self::toggle( 'shipping_enabled', 'انتقال هزینه حمل به سیاست فروش', 'افزودن هزینه ارسال به سند فاکتور و مبلغ دریافتی آن؛ فقط با شناسه سیاست معتبر.', $s['shipping_enabled'] );
		echo '<label class="rkwe-field"><span>روش انتقال حمل</span><select name="ext[shipping_mode]"><option value="policy" ' . selected( $s['shipping_mode'], 'policy', false ) . '>سیاست فروش</option><option value="product" ' . selected( $s['shipping_mode'], 'product', false ) . '>کالای خدمات حمل (مانند افزونه قدیمی)</option></select></label>';
		self::row( 'shipping_product_id', 'شناسه کالای خدمات حمل', $s['shipping_product_id'], 'number' );
		self::row( 'shipping_unit_id', 'شناسه واحد کالای حمل', $s['shipping_unit_id'], 'number' );
		RKW_Accounting::render_shipping_rules( $s );
		self::row( 'negative_fee_policy_id', 'سیاست تخفیف هزینه‌های منفی دیگر', $s['negative_fee_policy_id'], 'number' );
		self::row( 'shipping_policy_id', 'شناسه سیاست حمل', $s['shipping_policy_id'], 'number', 'شناسه نمونه در سیستم قدیمی ۲۱۱ بود؛ خودکار انتخاب نمی‌شود.' );
		self::row( 'extra_fee_policy_id', 'شناسه سیاست هزینه‌های جانبی سفارش (اختیاری)', $s['extra_fee_policy_id'], 'number', 'برای هزینه‌های مثبت غیر از حمل (مثل هزینه بسته‌بندی). صفر = انتقال داده نشود. شناسه باید در راهکاران تأیید شود.' );
		echo '</section>';
		echo '<section class="rkwe-card"><div class="rkwe-icon">☎</div><h2>تطبیق مشتری با نام کاربری</h2>';
		self::toggle( 'username_mobile_enabled', 'اولویت نام کاربری عددی', 'اگر نام کاربری مشتری شماره موبایل معتبر باشد، به‌جای تلفن صورتحساب برای یافتن مشتری استفاده می‌شود.', $s['username_mobile_enabled'] );
		echo '<p class="rkwe-hint">نام کاربری نامعتبر یا غیرموبایلی نادیده گرفته می‌شود و موبایل صورت‌حساب استفاده خواهد شد.</p></section>';
		echo '</div><div class="rkwe-save"><button type="submit" class="button button-primary button-hero">ذخیره تنظیمات امکانات تکمیلی</button></div></form></div>';
	}
	/** شماره موبایل پیش‌فرض بدون تغییر است؛ تنظیم اختیاری نام کاربری فقط با اعتبارسنجی. */
	public static function customer_mobile_for_order( WC_Order $order ) {
		$mobile = RKW_Orders::normalize_mobile( $order->get_billing_phone() );
		$s = self::settings();
		if ( empty( $s['username_mobile_enabled'] ) || ! $order->get_user_id() ) { return $mobile; }
		$u = get_userdata( $order->get_user_id() );
		$login = $u ? RKW_Orders::normalize_mobile( $u->user_login ) : '';
		return preg_match( '/^09\d{9}$/', $login ) ? $login : $mobile;
	}
	/** فقط حذف تخفیف خرید اول؛ هیچ تخفیفی را خودکار ایجاد نمی‌کند. */
	public static function first_purchase_fee( $cart ) {
		$s = self::settings();
		if ( empty( $s['first_enabled'] ) || ! is_user_logged_in() || ! $cart || ! method_exists( $cart, 'get_fees' ) ) { return; }
		if ( 'v21' !== rkw_settings()['api'] || ( is_admin() && ! wp_doing_ajax() ) ) { return; }
		$fees = $cart->get_fees();
		$found = false;
		foreach ( $fees as $fee ) { if ( isset( $fee->name ) && $fee->name === $s['first_fee_label'] && isset( $fee->amount ) && (float) $fee->amount < 0 ) { $found = true; } }
		if ( ! $found ) { return; }
		$status = self::is_first_purchase( get_current_user_id() );
		if ( true === $status ) { return; }
		foreach ( $fees as $index => $fee ) {
			if ( isset( $fee->name ) && $fee->name === $s['first_fee_label'] && isset( $fee->amount ) && (float) $fee->amount < 0 ) { unset( $fees[ $index ] ); }
		}
		if ( method_exists( $cart, 'fees_api' ) && method_exists( $cart->fees_api(), 'set_fees' ) ) { $cart->fees_api()->set_fees( $fees ); }
	}
	private static function unverified_first( $user_id ) {
		set_transient( 'rkw_first_' . (int) $user_id, 'unknown', 2 * MINUTE_IN_SECONDS );
		return null;
	}
	/** تنها نتیجه مستند و قطعی «بدون فاکتور» اجازه نگه‌داشتن تخفیف را می‌دهد. */
	public static function is_first_purchase( $user_id ) {
		$cache = get_transient( 'rkw_first_' . (int) $user_id );
		if ( false !== $cache ) { return 'yes' === $cache; }
		$u = get_userdata( $user_id );
		if ( ! $u ) { return self::unverified_first( $user_id ); }
		$mobile = RKW_Orders::normalize_mobile( get_user_meta( $user_id, 'billing_phone', true ) );
		if ( self::settings()['username_mobile_enabled'] && preg_match( '/^09\d{9}$/', RKW_Orders::normalize_mobile( $u->user_login ) ) ) { $mobile = RKW_Orders::normalize_mobile( $u->user_login ); }
		if ( ! preg_match( '/^09\d{9}$/', $mobile ) ) { return self::unverified_first( $user_id ); }
		$api = new RKW_Client();
		$found = $api->find_customer21( $mobile, 2 );
		if ( is_wp_error( $found ) || ! is_array( $found ) ) { return self::unverified_first( $user_id ); }
		if ( empty( $found ) ) { return self::unverified_first( $user_id ); } // مشتری بدون سابقه در API به‌تنهایی دلیل تخفیف نیست.
		$customer = isset( $found[0] ) ? $found[0] : $found;
		$id = isset( $customer['Id'] ) ? absint( $customer['Id'] ) : ( isset( $customer['id'] ) ? absint( $customer['id'] ) : 0 );
		if ( ! $id ) { return self::unverified_first( $user_id ); }
		$invoices = $api->invoices21( 1, 25, '', $mobile );
		if ( is_wp_error( $invoices ) || ! is_array( $invoices ) ) { return self::unverified_first( $user_id ); }
		// اگر صفحه اول تهی است، هیچ فاکتور مرتبطی در پاسخ نیست.
		$rows = isset( $invoices['items'] ) && is_array( $invoices['items'] ) ? $invoices['items'] : ( isset( $invoices[0] ) ? $invoices : array() );
		$first = empty( $rows );
		if ( ! $first ) {
			$matching = false;
			foreach ( $rows as $row ) {
				if ( is_array( $row ) && isset( $row['customerId'] ) && (int) $row['customerId'] === $id ) { $matching = true; break; }
			}
			if ( ! $matching ) { return self::unverified_first( $user_id ); } // پاسخ نامطمئن، تخفیف را حذف کن.
		}
		set_transient( 'rkw_first_' . (int) $user_id, $first ? 'yes' : 'no', 10 * MINUTE_IN_SECONDS );
		return $first;
	}
	/** فاکتور در راهکاران: اعمال سیاست‌ها فقط بعد از فعال‌سازی و تعیین شناسه توسط مدیر. */
	public static function extend_payload( $payload, $order, $settings ) {
		return RKW_Accounting::extend_payload( $payload, $order, $settings, self::settings() );
	}
}
