# فهرست نمونه‌های API

وجود رشته مسیر در کد به معنی پیاده‌سازی کامل یا آزمون موفق endpoint نیست؛ این جدول فقط مقایسهٔ ایستا است. مقادیر ورودی نمونه‌ها و تنظیمات محیط منتشر نشده‌اند.

| نمونه | روش | مسیر | رشته مسیر در کد |
|---|---|---|---|
| Authentication/CashierLogout.bru | GET | Retail/Api/CashRegisterManagement/RetailMobileAuthenticationService.svc/CashierLogout | خیر |
| Authentication/DesktopLogin.bru | POST | Retail/Api/CashRegisterManagement/RetailDesktopAuthenticationService.svc/DesktopCashierLogin | بله |
| Authentication/EncryptedLogin/Login.bru | POST | Services/Framework/AuthenticationService.svc/login | بله |
| Authentication/EncryptedLogin/Session.bru | GET | Services/Framework/AuthenticationService.svc/session | بله |
| Authentication/GetCurrentActiveSession.bru | GET | Retail/Api/CashRegisterManagement/RetailMobileAuthenticationService.svc/GetCurrentActiveSession | خیر |
| Authentication/GetCurrentCashierInfo.bru | GET | Retail/Api/CashRegisterManagement/RetailMobileAuthenticationService.svc/GetCurrentCashierInfo | خیر |
| Authentication/HandheldLogin.bru | POST | Retail/Api/CashRegisterManagement/RetailMobileAuthenticationService.svc/HandheldCashierLogin | خیر |
| Authentication/IsLoggedIn.bru | GET | Retail/Api/CashRegisterManagement/RetailMobileAuthenticationService.svc/IsLoggedIn | خیر |
| Authentication/KioskLogin.bru | POST | Retail/Api/CashRegisterManagement/RetailKioskAuthenticationService.svc/KioskLogin | خیر |
| Authentication/Tick.bru | GET | Retail/Api/CashRegisterManagement/RetailMobileAuthenticationService.svc/Tick | خیر |
| Authentication/UnEncryptedLogin/Login.bru | POST | Services/Framework/AuthenticationService.svc/ssllogin | خیر |
| Authorization/GetAccessibleResources.bru | POST | Retail/Api/Structure/MobileSecurityService.svc/GetAccessibleResourcesByRetailShopId | خیر |
| Authorization/GetAccessibleResourcesForStateChanging.bru | POST | {{app}}/Retail/Api/Structure/MobileSecurityService.svc/GetAccessibleResourcesForStateChanging | خیر |
| Authorization/GetCurrentRetailShopAccessibleResources.bru | GET | {{app}}/Retail/Api/Structure/MobileSecurityService.svc/GetCurrentRetailShopAccessibleResources | خیر |
| Authorization/HasAccess.bru | GET | {{app}}/Retail/Api/Structure/MobileSecurityService.svc/HasAccess | خیر |
| Authorization/IsAdmin.bru | GET | {{app}}/Retail/Api/Structure/MobileSecurityService.svc/IsAdmin | خیر |
| Discovery/GetServiceEndPoints.bru | GET | Services/Retail/ServiceLocatorService.svc/getServiceEndPoints | خیر |
| Discovery/GetServices.bru | GET | Services/Retail/ServiceLocatorService.svc/getServices | خیر |
| DocumentStructure/DeviceInfo/GetKioskPosInfo.bru | GET | Retail/Api/DocumentStructure/DeviceInfoService.svc/getKioskPosInfo | خیر |
| DocumentStructure/DeviceInfo/GetPosesInfo.bru | GET | Retail/Api/DocumentStructure/DeviceInfoService.svc/getPosesInfo | بله |
| DocumentStructure/DocumentPatterns/getDefaultMobileDocumentPattern.bru | GET | Retail/Api/DocumentStructure/DocumentPatternService.svc/getDefaultMobileDocumentPatternByType | بله |
| DocumentStructure/SalesArea/GetSalesArea.bru | GET | {{app}}/Retail/Api/DocumentStructure/SalesAreaService.svc/getSalesAreas | خیر |
| DocumentStructure/SalesArea/GetSalesAreas.bru | GET | Retail/Api/DocumentStructure/SalesAreaService.svc/getSalesAreas | بله |
| DocumentStructure/SalesEmployee/GetSalesEmployees.bru | GET | Retail/Api/DocumentStructure/SalesEmpoyeeService.svc/getSalesEmployees | خیر |
| DocumentStructure/SettlementPolicy/GetSettlementPolicies.bru | GET | Retail/Api/DocumentStructure/SettlementPolicyService.svc/getSettlementPolicies | بله |
| DocumentStructure/SettlementPolicy/GetSettlementPolicy.bru | GET | {{app}}/Retail/Api/DocumentStructure/SettlementPolicyService.svc/getSettlementPolicy | خیر |
| DocumentStructure/Store/GetRemainingQuantityInfo.bru | GET | Retail/Api/DocumentStructure/StoreService.svc/GetRemainingQuantityInfo | بله |
| DocumentStructure/Store/GetStore.bru | GET | Retail/Api/DocumentStructure/StoreService.svc/getStore | بله |
| DocumentStructure/Store/GetStores.bru | GET | Retail/Api/DocumentStructure/StoreService.svc/getStores | بله |
| Loyalty/MemberService/CreateLoyaltyMemberForCustomer.bru | POST | {{app}}/Retail/LoyaltyApi/RetailLoyaltyMemberService.svc/loyaltyMember | خیر |
| Loyalty/MemberService/GetLoyaltyMember.bru | GET | Retail/LoyaltyApi/RetailLoyaltyMemberService.svc/loyaltyMemberById | بله |
| Loyalty/MemberService/GetLoyaltyMemberPattern.bru | GET | {{app}}/Retail/LoyaltyApi/RetailLoyaltyMemberService.svc/loyaltyMemberPattern | خیر |
| Loyalty/MemberService/GetLoyaltyMember_1.bru | GET | Retail/LoyaltyApi/RetailLoyaltyMemberService.svc/loyaltyMemberByMappedId | بله |
| Loyalty/MemberService/GetLoyaltyMember_2.bru | GET | {{app}}/Retail/LoyaltyApi/RetailLoyaltyMemberService.svc/searchLoyaltyData | خیر |
| Loyalty/PointCreditService/GetLoyaltyRemainingCredit.bru | GET | Retail/LoyaltyApi/RetailLoyaltyPointCreditService.svc/loyaltyRemainingCredit | بله |
| Loyalty/ProgramService/GetBaseDocumentLoyaltyProgram.bru | GET | Retail/LoyaltyApi/RetailLoyaltyProgramService.svc/getBaseDocumentLoyaltyProgram | خیر |
| Loyalty/ProgramService/GetLoyaltyPrograms.bru | GET | Retail/LoyaltyApi/RetailLoyaltyProgramService.svc/loyaltyProgram | بله |
| Promotions/AssignDiscountCard.bru | POST | Retail/Api/Promotions/RetailPromotionService.svc/assignDiscountCard | خیر |
| Promotions/GetDiscountCards.bru | GET | Retail/Api/Promotions/RetailPromotionService.svc/getDiscountCards | خیر |
| Promotions/GetPersonnelCreditPrograms.bru | GET | Retail/Api/Promotions/RetailPromotionService.svc/personnelCreditPrograms | خیر |
| Promotions/GetReturnCreditPrograms.bru | GET | Retail/Api/Promotions/RetailPromotionService.svc/returnCreditPrograms | خیر |
| Promotions/GetThirdPartyCouponTypeById.bru | GET | {{app}}/Retail/Api/Promotions/RetailPromotionService.svc/thirdPartyCouponType | خیر |
| Promotions/GetThirdPartyCouponTypes.bru | GET | {{app}}/Retail/Api/Promotions/RetailPromotionService.svc/thirdPartyCouponTypes | خیر |
| Promotions/GetThirdPartyCouponTypes_1.bru | GET | Retail/Api/Promotions/RetailPromotionService.svc/thirdPartyCouponTypes | خیر |
| Promotions/GetThirdPartyOrganizationPrograms.bru | GET | Retail/Api/Promotions/RetailPromotionService.svc/thirdPartyOrganizationPrograms | خیر |
| Promotions/ValidateDiscountCard.bru | GET | Retail/Api/Promotions/RetailPromotionService.svc/validateDiscountCard | خیر |
| RetailDocuments/Invoice/CalculateAmount copy.bru | POST | Retail/Api/RetailDocuments/InvoiceService.svc/calculateAmount | بله |
| RetailDocuments/Invoice/CalculateAmount.bru | POST | Retail/Api/RetailDocuments/InvoiceService.svc/calculateAmount | بله |
| RetailDocuments/Invoice/CopyToReturnInvoice.bru | GET | {{app}}/Retail/Api/RetailDocuments/InvoiceService.svc/copyToReturnInvoice | خیر |
| RetailDocuments/Invoice/GetBaseInvoicePermitItems.bru | POST | Retail/Api/RetailDocuments/InvoiceService.svc/getBaseInvoicePermitItems | خیر |
| RetailDocuments/Invoice/GetBaseInvoicePermits.bru | POST | Retail/Api/RetailDocuments/InvoiceService.svc/getBaseInvoicePermits | خیر |
| RetailDocuments/Invoice/GetBaseSalesOrderItems.bru | POST | Retail/Api/RetailDocuments/InvoiceService.svc/getBaseSalesOrderItems | خیر |
| RetailDocuments/Invoice/GetBaseSalesOrders.bru | POST | Retail/Api/RetailDocuments/InvoiceService.svc/getBaseSalesOrders | خیر |
| RetailDocuments/Invoice/GetInvoice Copy.bru | GET | {{app}}/Retail/Api/RetailDocuments/InvoiceService.svc/GetInvoice | خیر |
| RetailDocuments/Invoice/GetInvoice.bru | GET | Retail/Api/RetailDocuments/InvoiceService.svc/GetInvoice | بله |
| RetailDocuments/Invoice/GetInvoicesList.bru | GET | Retail/Api/RetailDocuments/InvoiceService.svc/GetInvoicesList | بله |
| RetailDocuments/Invoice/GetKioskInvoice.bru | GET | {{app}}/Retail/Api/RetailDocuments/InvoiceService.svc/getKioskInvoice | خیر |
| RetailDocuments/Invoice/SaveInvoice copy.bru | POST | Retail/Api/RetailDocuments/InvoiceService.svc/SaveInvoice | بله |
| RetailDocuments/Invoice/SaveInvoice.bru | POST | Retail/Api/RetailDocuments/InvoiceService.svc/SaveInvoice | بله |
| RetailDocuments/Invoice/SaveKioskInvoice.bru | POST | {{app}}/Retail/Api/RetailDocuments/InvoiceService.svc/saveKioskInvoice | خیر |
| RetailDocuments/PrintDocument/PrintDocument.bru | GET | Retail/Api/RetailDocuments/DocumentPrintService.svc/printDocument | خیر |
| RetailDocuments/ReturnInvoice/CaclulateAmount copy.bru | POST | Retail/Api/RetailDocuments/ReturnInvoiceService.svc/calculateAmount | خیر |
| RetailDocuments/ReturnInvoice/CaclulateAmount.bru | POST | Retail/Api/RetailDocuments/ReturnInvoiceService.svc/calculateAmount | خیر |
| RetailDocuments/ReturnInvoice/GetBaseDocumentItems.bru | POST | Retail/Api/RetailDocuments/ReturnInvoiceService.svc/getBaseDocumentItems | خیر |
| RetailDocuments/ReturnInvoice/GetBaseDocuments.bru | POST | Retail/Api/RetailDocuments/ReturnInvoiceService.svc/getBaseDocuments | خیر |
| RetailDocuments/ReturnInvoice/GetReturnInvoice.bru | GET | {{app}}/Retail/Api/RetailDocuments/ReturnInvoiceService.svc/GetReturnInvoice | خیر |
| RetailDocuments/ReturnInvoice/GetReturnInvoicesList.bru | GET | {{app}}/Retail/Api/RetailDocuments/ReturnInvoiceService.svc/GetReturnInvoicesList | خیر |
| RetailDocuments/ReturnInvoice/SaveReturnInvoice copy.bru | POST | Retail/Api/RetailDocuments/ReturnInvoiceService.svc/SaveReturnInvoice | خیر |
| RetailDocuments/ReturnInvoice/SaveReturnInvoice.bru | POST | Retail/Api/RetailDocuments/ReturnInvoiceService.svc/SaveReturnInvoice | خیر |
| RetailDocuments/SalesOrder/CalculateAmount Copy.bru | POST | Retail/Api/RetailDocuments/SalesOrderService.svc/calculateAmount | خیر |
| RetailDocuments/SalesOrder/CalculateAmount.bru | POST | Retail/Api/RetailDocuments/SalesOrderService.svc/calculateAmount | خیر |
| RetailDocuments/SalesOrder/GetSalesOrder.bru | GET | Retail/Api/RetailDocuments/SalesOrderService.svc/getSalesOrder | خیر |
| RetailDocuments/SalesOrder/GetSalesOrderList.bru | GET | {{app}}/Retail/Api/RetailDocuments/SalesOrderService.svc/getSalesOrdesList | خیر |
| RetailDocuments/SalesOrder/SaveSalesOrder Copy.bru | POST | Retail/Api/RetailDocuments/SalesOrderService.svc/saveSalesOrder | بله |
| RetailDocuments/SalesOrder/SaveSalesOrder-Mobile.bru | POST | Retail/Api/RetailDocuments/SalesOrderService.svc/saveSalesOrder | بله |
| RetailDocuments/SalesOrder/SaveSalesOrder.bru | POST | {{app}}/Retail/Api/RetailDocuments/SalesOrderService.svc/saveSalesOrder | خیر |
| Structure/Customer/GetCustomer.bru | GET | Retail/Api/Structure/CustomerService.svc/customer | بله |
| Structure/Customer/GetCustomers.bru | GET | Retail/Api/Structure/CustomerService.svc/customers | بله |
| Structure/Customer/SaveCustomer.bru | POST | Retail/Api/Structure/CustomerService.svc/customer | بله |
| Structure/FavoriteProduct/GetFavoriteProductCollection.bru | GET | Retail/Api/Structure/FavoriteProductService.svc/favoriteProudctCollection | خیر |
| Structure/FavoriteProduct/GetFavoriteProductCollectionAllocatedToCashRegisterById.bru | GET | Retail/Api/Structure/FavoriteProductService.svc/favoriteProudctCollectionAllocatedToCashRegisterById | خیر |
| Structure/FavoriteProduct/GetFavoriteProductCollectionAllocatedToRetailShopById.bru | GET | Retail/Api/Structure/FavoriteProductService.svc/favoriteProudctCollectionAllocatedToRetailShopById | خیر |
| Structure/FavoriteProduct/GetFavoriteProductCollectionsAllocatedToCurrentCashRegister.bru | GET | Retail/Api/Structure/FavoriteProductService.svc/favoriteProudctCollectionAllocatedToCurrentCashRegister | خیر |
| Structure/FavoriteProduct/GetFavoriteProductItem.bru | GET | Retail/Api/Structure/FavoriteProductService.svc/favoriteProudctItem | خیر |
| Structure/FavoriteProduct/GetFavoriteProductItems.bru | GET | Retail/Api/Structure/FavoriteProductService.svc/favoriteProudctItems | خیر |
| Structure/GeneralSettings/GetSettings.bru | GET | Retail/Api/Structure/GeneralSettingsService.svc/settings | خیر |
| Structure/Product/AllTrackingFactorsCombination.bru | GET | Retail/Api/Structure/ProductService.svc/allTrackingFactorsCombination | خیر |
| Structure/Product/ExistingTrackingFactors.bru | GET | Retail/Api/Structure/ProductService.svc/existingTrackingFactors | خیر |
| Structure/Product/GetProduct.bru | GET | Retail/Api/Structure/ProductService.svc/GetProduct | بله |
| Structure/Product/GetProductToppings.bru | GET | Retail/Api/Structure/ProductService.svc/getProductToppings | خیر |
| Structure/Product/GetProductUnits.bru | GET | Services/Retail/ProductService.svc/GetProductUnits | خیر |
| Structure/Product/GetProducts.bru | GET | Retail/Api/Structure/ProductService.svc/GetProducts | بله |
| Structure/Product/GetProductsByBarcode.bru | GET | {{app}}/Retail/Api/Structure/ProductService.svc/getProductByBarcode | خیر |
| Structure/UpdateApp/GetLatestVersion.bru | GET | Retail/Api/Structure/UpdateAppService.svc/GetLatestVersion | خیر |
| Structure/UpdateApp/GetLatestVersionNumber Copy.bru | GET | {{app}}/Retail/Api/Structure/UpdateAppService.svc/getLatestVersionNumber | خیر |
| Structure/UpdateApp/GetLatestVersionNumber.bru | GET | Retail/Api/Structure/UpdateAppService.svc/getLatestVersionNumber | خیر |
| TreasuryStructure/CreditNote/GetCreditNoteByCode.bru | GET | Retail/Api/TreasuryStructure/CreditNoteService.svc/getCreditNoteByCode | خیر |
| TreasuryStructure/CreditNote/GetCreditNoteByID.bru | GET | {{app}}/Retail/Api/TreasuryStructure/CreditNoteService.svc/getCreditNoteByID | خیر |
| TreasuryStructure/CreditNote/ValidateAndGetCreditNote.bru | GET | {{app}}/Retail/Api/TreasuryStructure/CreditNoteService.svc/validateAndGetCreditNote | خیر |
| TreasuryStructure/CreditNote/ValidateCreditNote.bru | GET | Retail/Api/TreasuryStructure/CreditNoteService.svc/validateCreditNote | خیر |
| TreasuryStructure/CreditNoteTemplate/GetCreditNoteTemplate.bru | GET | {{app}}/Retail/Api/TreasuryStructure/CreditNoteTemplateService.svc/getCreditNoteTemplateById | خیر |
| TreasuryStructure/CreditNoteTemplate/GetCreditNoteTemplates.bru | GET | {{app}}/Retail/Api/TreasuryStructure/CreditNoteTemplateService.svc/getCreditNoteTemplates | خیر |
| TreasuryStructure/CreditNoteTemplate/GetCurrentRetailShopCreditNoteTemplates.bru | GET | {{app}}/Retail/Api/TreasuryStructure/CreditNoteTemplateService.svc/getCurrentRetailShopCreditNoteTemplates | خیر |
