<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Resumable remote reads. An unsuccessful search never authorizes a financial retry. */
class RKW_Reconciliation {
	const PAGE_SIZE = 50;
	const MAX_PAGES = 200;
	const TTL = 900;

	public static function init() {
		add_action( 'wp_ajax_rkw_check_order', array( __CLASS__, 'ajax_check' ) );
	}

	/** Recognize only complete terminal markers emitted by these two plugins. */
	public static function matches( $invoice, WC_Order $order ) {
		if ( ! is_array( $invoice ) || ! isset( $invoice['description'] ) || ! is_string( $invoice['description'] ) ) { return false; }
		$description = trim( $invoice['description'] );
		$marker = 'سفارش سایت #' . $order->get_order_number();
		$legacy = 'ووکامرس: ' . $order->get_id();
		$matched = $description === $marker || substr( $description, -strlen( ' | ' . $marker ) ) === ' | ' . $marker;
		// wp-rahkaran appends the internal WooCommerce ID, not the displayed order number.
		if ( ! $matched ) { $matched = (bool) preg_match( '/(?:^|\|)\s*' . preg_quote( $legacy, '/' ) . '\s*$/uD', $description ); }
		if ( ! $matched ) { return false; }
		// If both markers exist they must agree; never accept a marker injected into an address.
		if ( preg_match_all( '/(?:^|\|)\s*ووکامرس:\s*([^|]+)/u', $description, $found ) ) {
			foreach ( $found[1] as $value ) { if ( trim( $value ) !== (string) $order->get_id() ) { return false; } }
		}
		$customer = (int) $order->get_meta( '_rkw_customer_id' );
		return ! $customer || ( isset( $invoice['customerId'] ) && (int) $invoice['customerId'] === $customer );
	}

	private static function key( $order_id ) { return 'rkw_check_' . get_current_user_id() . '_' . $order_id; }

	private static function invoice_id( $row ) {
		if ( ! is_array( $row ) ) { return 0; }
		$id = 0;
		foreach ( array( 'id', 'Id', 'invoiceId', 'InvoiceId' ) as $key ) {
			if ( ! array_key_exists( $key, $row ) ) { continue; }
			$value = $row[ $key ];
			if ( ( ! is_int( $value ) && ! is_string( $value ) ) || ! preg_match( '/^[1-9][0-9]*$/D', (string) $value ) || (string) (int) $value !== (string) $value ) { return 0; }
			if ( $id && $id !== (int) $value ) { return 0; }
			$id = (int) $value;
		}
		return $id;
	}

	private static function fingerprint( WC_Order $order, $legacy ) {
		$records = array_map( 'wp_json_encode', $legacy ); sort( $records, SORT_STRING );
		$items = array();
		foreach ( $order->get_items() as $item ) { $items[] = array( $item->get_quantity(), $item->get_total(), $item->get_total_tax() ); }
		return hash( 'sha256', wp_json_encode( array( rkw_settings(), $records, $items,
			$order->get_id(), $order->get_order_number(), $order->get_total(), RKW_Extensions::customer_mobile_for_order( $order ),
			$order->get_meta( '_rkw_customer_id' ), $order->get_meta( '_rkw_doc_id' ), $order->get_meta( '_rkw_doc_type' ), $order->get_meta( '_rkw_reconcile_required' ) ) ) );
	}

	private static function result( $status, $message, $extra = array() ) {
		return array_merge( array( 'done' => true, 'status' => $status, 'message' => $message ), $extra );
	}

	private static function progress( $key, $job ) {
		set_transient( $key, $job, self::TTL );
		return array( 'done' => false, 'token' => $job['token'], 'status' => 'checking', 'message' => 'بررسی راهکاران: ' . $job['checked'] . ' فاکتور خوانده شد؛ صفحه جست‌وجو ' . max( 1, $job['page'] ) . '.' );
	}

	/** One list page OR one detail per request; no SaveInvoice or other financial POST here. */
	public static function step( WC_Order $order, $token = '', $allow_send = false ) {
		if ( 'v21' !== rkw_settings()['api'] ) { return new WP_Error( 'rkw_check_api', 'بررسی فاکتور فقط برای API نسخه ۲۱ پشتیبانی می‌شود.' ); }
		if ( 'shop_order' !== $order->get_type() ) { return new WP_Error( 'rkw_check_order', 'سفارش فروش معتبر نیست.' ); }
		$lock = 'rkw_order_lock_' . $order->get_id();
		if ( ! add_option( $lock, array( 'started' => time(), 'operation' => 'check' ), '', false ) ) { return new WP_Error( 'rkw_check_busy', 'عملیات دیگری روی این سفارش در جریان است؛ بررسی دوباره را پس از پایان آن انجام دهید.' ); }
		try {
			// Acquire the same lock as the sender before reading local submission state.
			$fresh = wc_get_order( $order->get_id() );
			if ( $fresh instanceof WC_Order ) { $order = $fresh; }
			if ( method_exists( $order, 'read_meta_data' ) ) { $order->read_meta_data( true ); }
			return self::locked_step( $order, $token, $allow_send );
		} finally { delete_option( $lock ); }
	}

	private static function locked_step( WC_Order $order, $token, $allow_send ) {
		$key = self::key( $order->get_id() );
		$existing = trim( (string) $order->get_meta( '_rkw_doc_id' ) );
		if ( preg_match( '/^[1-9][0-9]*$/D', $existing ) && ! $order->get_meta( '_rkw_reconcile_required' ) ) {
			delete_transient( $key );
			return self::result( 'confirmed', 'شناسه سند از قبل ثبت شده است؛ ارسال مجدد انجام نشد.', array( 'document' => RKW_Order_List_UI::document_label( $order ) ) );
		}
		if ( 'salesorder' === $order->get_meta( '_rkw_doc_type' ) ) { return new WP_Error( 'rkw_check_type', 'سند قبلی سفارش فروش است؛ جست‌وجوی فاکتور نمی‌تواند نتیجه آن را تعیین کند. هیچ سند جدیدی ارسال نشد.' ); }
		$legacy = RKW_Migration::legacy_order_records( $order->get_id() );
		if ( is_wp_error( $legacy ) ) { return $legacy; }
		$fingerprint = self::fingerprint( $order, $legacy );
		if ( '' === $token ) {
			$mobile = RKW_Extensions::customer_mobile_for_order( $order );
			$mobile = preg_match( '/^09[0-9]{9}$/D', $mobile ) ? $mobile : '';
			$ids = array();
			if ( preg_match( '/^[1-9][0-9]*$/D', $existing ) ) { $ids[ $existing ] = (int) $existing; }
			foreach ( $legacy as $row ) {
				$id = isset( $row['invoice_id'] ) && is_scalar( $row['invoice_id'] ) ? trim( (string) $row['invoice_id'] ) : '';
				if ( preg_match( '/^[1-9][0-9]*$/D', $id ) ) { $ids[ $id ] = (int) $id; }
			}
			if ( ! $mobile && ! $ids ) { return new WP_Error( 'rkw_check_mobile', 'موبایل معتبر یا شناسه فاکتور قبلی برای جست‌وجو موجود نیست؛ سفارش همچنان نیازمند بررسی است و سندی ارسال نشد.' ); }
			$job = array( 'token' => wp_generate_uuid4(), 'fingerprint' => $fingerprint, 'send' => (bool) $allow_send,
				'mobile' => $mobile, 'page' => 0, 'more' => '' !== $mobile, 'queue' => array_values( $ids ), 'references' => $ids,
				'seen' => array(), 'pages' => array(), 'matches' => array(), 'checked' => 0 );
			return self::progress( $key, $job );
		}
		$job = get_transient( $key );
		if ( ! is_array( $job ) || ! isset( $job['token'] ) || ! hash_equals( $job['token'], $token ) ) { return new WP_Error( 'rkw_check_expired', 'بررسی منقضی شده یا در پنجره دیگری آغاز شده است؛ بررسی را از ابتدا شروع کنید.' ); }
		if ( ! hash_equals( $job['fingerprint'], $fingerprint ) || $job['send'] !== (bool) $allow_send ) {
			delete_transient( $key ); return new WP_Error( 'rkw_check_changed', 'سفارش، سوابق قدیمی یا تنظیمات تغییر کرده است؛ بررسی را از ابتدا شروع کنید. هیچ سندی ارسال نشد.' );
		}
		$client = new RKW_Client();
		if ( $job['queue'] ) {
			$id = array_shift( $job['queue'] );
			if ( ! isset( $job['seen'][ $id ] ) ) {
				$detail = $client->invoice21( $id );
				if ( is_wp_error( $detail ) ) { delete_transient( $key ); return $detail; }
				if ( self::invoice_id( $detail ) !== $id ) { delete_transient( $key ); return new WP_Error( 'rkw_check_detail', 'پاسخ جزئیات فاکتور با شناسه درخواست مطابقت ندارد؛ هیچ نتیجه‌ای تأیید نشد.' ); }
				$job['seen'][ $id ] = true; $job['checked']++;
				if ( isset( $job['references'][ $id ] ) && ! self::matches( $detail, $order ) ) { delete_transient( $key ); return self::result( 'unresolved', 'شناسه فاکتور موجود در سوابق قبلی با این سفارش مطابقت ندارد؛ سوابق حفظ شد و ارسال جدید انجام نشد.' ); }
				if ( self::matches( $detail, $order ) ) { $job['matches'][ $id ] = $id; }
				if ( count( $job['matches'] ) > 1 ) { delete_transient( $key ); return self::result( 'unresolved', 'بیش از یک فاکتور با شماره این سفارش پیدا شد؛ برای بررسی فاکتور تکراری اقدام کنید. هیچ سند جدیدی ارسال نشد.' ); }
			}
			return self::progress( $key, $job );
		}
		if ( $job['more'] ) {
			if ( $job['page'] >= self::MAX_PAGES ) { delete_transient( $key ); return self::result( 'unresolved', 'جست‌وجو به سقف ۲۰۰ صفحه رسید و کامل نشد؛ هیچ سندی ارسال یا تأیید نشد.' ); }
			$job['page']++;
			$response = $client->invoices21( $job['page'], self::PAGE_SIZE, '', $job['mobile'] );
			if ( is_wp_error( $response ) ) { delete_transient( $key ); return $response; }
			$rows = is_array( $response ) && isset( $response['items'] ) ? $response['items'] : $response;
			if ( ! is_array( $rows ) || array_values( $rows ) !== $rows ) { delete_transient( $key ); return new WP_Error( 'rkw_check_list', 'قالب فهرست فاکتورها معتبر نیست؛ خالی‌بودن جست‌وجو تأیید نشد.' ); }
			$ids = array();
			foreach ( $rows as $row ) {
				$id = self::invoice_id( $row );
				if ( ! $id ) { delete_transient( $key ); return new WP_Error( 'rkw_check_list', 'شناسه معتبر فاکتور در فهرست موجود نیست؛ بررسی متوقف شد.' ); }
				$ids[] = $id;
			}
			$signature_ids = $ids; sort( $signature_ids, SORT_NUMERIC ); $page_hash = hash( 'sha256', wp_json_encode( $signature_ids ) );
			if ( $ids && isset( $job['pages'][ $page_hash ] ) ) { delete_transient( $key ); return new WP_Error( 'rkw_check_repeat', 'راهکاران صفحه تکراری برگرداند؛ پایان جست‌وجو قابل تأیید نیست و هیچ سندی ارسال نشد.' ); }
			$job['pages'][ $page_hash ] = true;
			// The documented list contains headers, usually without description. Read GetInvoice for each ID.
			$job['queue'] = array_values( array_filter( array_unique( $ids ), static function ( $id ) use ( $job ) { return ! isset( $job['seen'][ $id ] ); } ) );
			$job['more'] = count( $rows ) >= self::PAGE_SIZE;
			return self::progress( $key, $job );
		}
		if ( ! $job['matches'] ) {
			delete_transient( $key );
			$uncertain = '' !== $existing || $order->get_meta( '_rkw_reconcile_required' ) || $legacy;
			if ( $job['send'] && ! $uncertain ) {
				return self::result( 'ready', 'فاکتور منطبقی در جست‌وجو پیدا نشد و سابقه ارسال نامشخصی وجود ندارد؛ ارسال از مسیر معمول افزونه بررسی می‌شود.' );
			}
			return self::result( 'unresolved', 'در ' . $job['checked'] . ' فاکتور قابل مشاهده، فاکتور منطبق پیدا نشد. این نتیجه ثبت‌نشدن قطعی را ثابت نمی‌کند؛ سوابق قبلی حفظ شد و هیچ سند جدیدی ارسال نشد.' );
		}
		$id = (int) reset( $job['matches'] );
		$detail = $client->invoice21( $id );
		if ( is_wp_error( $detail ) ) { delete_transient( $key ); return $detail; }
		$s = rkw_settings(); $expected = round( (float) $order->get_total() * rkw_price_multiplier( $s ), 2 );
		if ( self::invoice_id( $detail ) !== $id || ! self::matches( $detail, $order ) ||
			! isset( $detail['netPrice'] ) || ! is_numeric( $detail['netPrice'] ) || abs( (float) $detail['netPrice'] - $expected ) > 0.01 ||
			( isset( $detail['currencyId'] ) && (int) $detail['currencyId'] !== (int) $s['currency_id'] ) ||
			( preg_match( '/^[1-9][0-9]*$/D', $existing ) && (int) $existing !== $id ) ) {
			delete_transient( $key ); return self::result( 'unresolved', 'فاکتور پیدا شد، اما شناسه، مشتری، توضیحات، مبلغ یا ارز آن با سفارش سازگار نیست؛ اتصال و ارسال جدید انجام نشد.' );
		}
		$fresh = wc_get_order( $order->get_id() );
		if ( $fresh instanceof WC_Order ) { $order = $fresh; }
		if ( method_exists( $order, 'read_meta_data' ) ) { $order->read_meta_data( true ); }
		$legacy = RKW_Migration::legacy_order_records( $order->get_id() );
		if ( is_wp_error( $legacy ) || ! hash_equals( $job['fingerprint'], self::fingerprint( $order, $legacy ) ) ) {
			delete_transient( $key ); return new WP_Error( 'rkw_check_changed', 'اطلاعات سفارش هنگام خواندن راهکاران تغییر کرد؛ تطبیق ذخیره نشد. دوباره بررسی کنید.' );
		}
		$order->update_meta_data( '_rkw_doc_id', (string) $id );
		$order->update_meta_data( '_rkw_doc_type', 'invoice' );
		$order->delete_meta_data( '_rkw_reconcile_required' ); $order->delete_meta_data( '_rkw_error' ); $order->save();
		wp_clear_scheduled_hook( 'rkw_send_order', array( (int) $order->get_id() ) );
		RKW_Order_List_UI::clear_document_cache(); RKW_Snapshot::invalidate_section( 'invoices' ); delete_transient( $key );
		$message = 'فاکتور #' . $id . ' در راهکاران تأیید و به سفارش متصل شد؛ ارسال مجدد انجام نشد.';
		$order->add_order_note( $message ); RKW_Log::add( 'info', 'تطبیق سفارش #' . $order->get_id() . ': ' . $message );
		return self::result( 'confirmed', $message, array( 'document' => RKW_Order_List_UI::document_label( $order ) ) );
	}

	public static function ajax_check( $legacy_nonce = false ) {
		if ( ! current_user_can( 'manage_woocommerce' ) || ! check_ajax_referer( $legacy_nonce ? 'rkw_module' : 'rkw_order_send', 'nonce', false ) ) {
			wp_send_json_error( array( 'message' => 'دسترسی یا نشست نامعتبر است.' ), 403 );
		}
		$id = isset( $_POST['order_id'] ) && is_scalar( $_POST['order_id'] ) ? absint( $_POST['order_id'] ) : 0;
		$token = isset( $_POST['token'] ) && is_string( $_POST['token'] ) ? sanitize_text_field( wp_unslash( $_POST['token'] ) ) : '';
		$order = $id ? wc_get_order( $id ) : false;
		if ( ! $order instanceof WC_Order ) { wp_send_json_error( array( 'message' => 'سفارش ووکامرس یافت نشد.' ), 404 ); }
		$send = ! $legacy_nonce && isset( $_POST['allow_send'] ) && '1' === $_POST['allow_send'];
		$result = self::step( $order, $token, $send );
		if ( is_wp_error( $result ) ) { wp_send_json_error( array( 'message' => $result->get_error_message(), 'code' => $result->get_error_code() ), 409 ); }
		$result['id'] = $id; wp_send_json_success( $result );
	}
}
