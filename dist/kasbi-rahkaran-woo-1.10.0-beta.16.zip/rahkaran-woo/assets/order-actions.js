/* global rkwOrderActions */
(function () {
  'use strict';
  if (typeof rkwOrderActions === 'undefined') return;
  const feedback = document.getElementById('rkw-local-send-status');
  const busy = new Set();
  function message(text, error) {
    if (feedback) { feedback.textContent = text; feedback.className = 'rkw-send-feedback ' + (error ? 'rkw-send-error' : 'rkw-send-ok'); }
    else {
      let top = document.getElementById('rkw-send-result-top');
      if (!top) {
        top = document.createElement('div'); top.id = 'rkw-send-result-top';
        top.setAttribute('role', 'status');
        const wrap = document.querySelector('.wrap') || document.body;
        wrap.prepend(top);
      }
      top.textContent = text;
      top.className = 'notice ' + (error ? 'notice-error' : 'notice-info');
    }
  }
  function updateRow(item) {
    const id = String(item.id);
    const row = document.querySelector('.rkw-bulk-table tr[data-order-id="' + id + '"]');
    const doc = document.querySelectorAll('.rkw-order-doc[data-order="' + id + '"]');
    const actions = document.querySelectorAll('.rkw-order-actions[data-order="' + id + '"]');
    const confirmed = item.status === 'sent' || (item.status === 'skipped' && !!item.document);
    if (confirmed || item.status === 'blocked') {
      doc.forEach(el => { el.textContent = confirmed ? (item.document || 'ثبت‌شده') : 'نیازمند تطبیق'; });
      actions.forEach(el => {
        el.textContent = confirmed ? (item.document || 'ثبت‌شده') : 'نیازمند بررسی در راهکاران';
        el.classList.add(confirmed ? 'rkw-order-sent' : 'rkw-order-pending');
        if (!confirmed) {
          const button = document.createElement('button'); button.type = 'button';
          button.className = 'button button-small rkw-check-one'; button.dataset.order = id;
          button.textContent = 'بررسی وضعیت در راهکاران'; el.appendChild(button);
        }
      });
      if (row && confirmed) { const checkbox = row.querySelector('.rkw-order-check'); if (checkbox) checkbox.remove(); }
      if (row && row.closest('.rkwm-local-orders[data-rkw-order-filter="unsent"]')) {
        const body = row.parentElement;
        row.remove();
        if (!body.querySelector('tr')) {
          const empty = document.createElement('tr'); const cell = document.createElement('td');
          cell.colSpan = 9; cell.textContent = 'سفارش دیگری در این صفحه باقی نمانده است؛ فهرست را به‌روزرسانی کنید.';
          empty.appendChild(cell); body.appendChild(empty);
        }
      }
    }
    if (row) {
      const result = row.querySelector('.rkw-last-result');
      if (result) { result.textContent = item.message; result.classList.toggle('rkw-row-error', item.status !== 'sent' && item.status !== 'skipped'); }
    }
  }
  async function send(ids) {
    const selected = [...new Set(ids.map(Number).filter(v => Number.isSafeInteger(v) && v > 0))];
    if (!selected.length) { message('ابتدا سفارش‌های قابل ارسال را انتخاب کنید.', true); return; }
    if (selected.length > 25) { message('در هر نوبت حداکثر ۲۵ سفارش قابل ارسال است.', true); return; }
    const label = selected.length === 1 ? 'سفارش #' + selected[0] : selected.length + ' سفارش';
    if (!window.confirm('ارسال ' + label + ' به راهکاران؟ اسناد ثبت‌شده و نتایج نامشخص دوباره ارسال نمی‌شوند. تا پایان عملیات صفحه را باز نگه دارید.')) return;
    if (busy.size) return;
    selected.forEach(id => busy.add(id));
    const controls = document.querySelectorAll('.rkw-send-one, .rkw-send-bulk, .rkw-check-one, .rkw-check-bulk');
    controls.forEach(button => button.disabled = true);
    let sent = 0; let finished = 0; let interrupted = false;
    const issues = [];
    // One request per invoice prevents a long PHP timeout and preserves the
    // result of earlier orders even if a later call is interrupted.
    for (const id of selected) {
      message('در حال ارسال سفارش ' + (finished + 1) + ' از ' + selected.length + ' (شناسه ' + id + ')…', false);
      try {
        const data = new URLSearchParams({ action: 'rkw_send_selected_orders', nonce: rkwOrderActions.nonce });
        data.append('order_ids[]', String(id));
        const response = await fetch(rkwOrderActions.ajax, {
          method: 'POST', credentials: 'same-origin',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
          body: data.toString()
        });
        const json = await response.json();
        if (!response.ok || !json.success) throw new Error(json && json.data && json.data.message ? json.data.message : 'خطا در درخواست.');
        const report = json.data.items || [];
        report.forEach(item => {
          updateRow(item);
          if (item.status === 'sent') sent++;
          else issues.push('#' + item.id + ': ' + item.message);
        });
        finished++;
      } catch (error) {
        issues.push('#' + id + ': نتیجه درخواست نامشخص است (' + error.message + ')');
        interrupted = true;
        break; // Never retry an uncertain POST without verifying Rahkaran.
      }
    }
    const summary = 'ارسال ' + finished + ' از ' + selected.length + ' سفارش بررسی شد؛ ' + sent + ' مورد ثبت شد.';
    message(summary + (interrupted ? ' ارسال گروه متوقف شد؛ نتیجه سفارش بعدی را در راهکاران بررسی کنید.' : '') + (issues.length ? ' ' + issues.slice(0, 5).join(' | ') : ''), interrupted || issues.length > 0);
    selected.forEach(id => busy.delete(id));
    controls.forEach(button => { if (button.isConnected) button.disabled = false; });
  }
  async function request(action, fields) {
    const data = new URLSearchParams({action, nonce: rkwOrderActions.nonce, ...fields});
    const response = await fetch(rkwOrderActions.ajax, {
      method: 'POST', credentials: 'same-origin',
      headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'}, body: data.toString()
    });
    const json = await response.json();
    if (!response.ok || !json.success) throw new Error(json && json.data && json.data.message ? json.data.message : 'نتیجه درخواست قابل خواندن نیست.');
    return json.data;
  }
  async function checkOrders(ids, allowSend) {
    if (busy.size) return;
    const selected = [...new Set(ids.map(Number).filter(v => Number.isSafeInteger(v) && v > 0))];
    if (!selected.length || selected.length > 25) { message('بین یک تا ۲۵ سفارش را برای بررسی انتخاب کنید.', true); return; }
    if (allowSend && !window.confirm('ابتدا وضعیت سفارش‌های انتخاب‌شده در راهکاران بررسی می‌شود. فاکتور پیدا‌شده به سفارش وصل می‌شود؛ فقط موارد بدون سابقه ارسال نامشخص از مسیر معمول ارسال می‌شوند. سفارش نیازمند بررسی با جست‌وجوی ناموفق دوباره ارسال نمی‌شود. ادامه می‌دهید؟')) return;
    selected.forEach(id => busy.add(id));
    const controls = document.querySelectorAll('.rkw-send-one, .rkw-send-bulk, .rkw-check-one, .rkw-check-bulk');
    controls.forEach(button => button.disabled = true);
    let confirmed = 0, sent = 0, unresolved = 0, checked = 0;
    const issues = [];
    for (const id of selected) {
      let submitting = false;
      try {
        let token = '', result;
        do {
          result = await request('rkw_check_order', {order_id: String(id), token, allow_send: allowSend ? '1' : '0'});
          message('سفارش #' + id + ' — ' + result.message, false);
          if (!result.done) {
            if (!result.token) throw new Error('شناسه ادامه بررسی در پاسخ موجود نیست.');
            token = result.token;
          }
        } while (!result.done);
        checked++;
        if (result.status === 'confirmed' && result.document) {
          confirmed++; updateRow({id, status: 'skipped', document: result.document, message: result.message});
        } else if (result.status === 'ready' && allowSend) {
          submitting = true;
          const report = await request('rkw_send_selected_orders', {'order_ids[]': String(id)});
          if (!Array.isArray(report.items) || report.items.length !== 1 || Number(report.items[0].id) !== id) throw new Error('پاسخ ارسال با سفارش تطابق ندارد.');
          const item = report.items[0]; updateRow(item);
          if (item.status === 'sent') sent++;
          else if (item.status === 'skipped' && item.document) confirmed++;
          else { unresolved++; issues.push('#' + id + ': ' + item.message); }
        } else {
          unresolved++; issues.push('#' + id + ': ' + result.message);
          updateRow({id, status: 'blocked', message: result.message});
        }
      } catch (error) {
        unresolved++; issues.push('#' + id + ': ' + error.message);
        if (submitting) {
          updateRow({id, status: 'blocked', message: 'نتیجه ارسال نامشخص است؛ پیش از تلاش دوباره تطبیق دهید.'});
          issues.push('ادامه گروه متوقف شد؛ ارسال نامشخص خودکار تکرار نمی‌شود.'); break;
        }
        const row = document.querySelector('.rkw-bulk-table tr[data-order-id="' + id + '"] .rkw-last-result');
        if (row) row.textContent = error.message;
      }
    }
    message(checked + ' سفارش بررسی شد؛ ' + confirmed + ' شناسه تأیید شد؛ ' + sent + ' سند جدید ثبت شد؛ ' + unresolved + ' مورد حل‌نشده.' + (issues.length ? ' ' + issues.slice(0, 5).join(' | ') : ''), unresolved > 0);
    selected.forEach(id => busy.delete(id));
    controls.forEach(button => { if (button.isConnected) button.disabled = false; });
  }
  document.addEventListener('click', event => {
    const checkOne = event.target.closest('.rkw-check-one');
    if (checkOne) { event.preventDefault(); checkOrders([checkOne.dataset.order], false); return; }
    const checkBulk = event.target.closest('.rkw-check-bulk');
    if (checkBulk) {
      event.preventDefault(); const table = checkBulk.closest('.rkwm-local-orders');
      if (table) checkOrders([...table.querySelectorAll('.rkw-order-check:checked')].map(el => el.value), true);
      return;
    }
    const single = event.target.closest('.rkw-send-one');
    if (single) { event.preventDefault(); send([single.dataset.order]); return; }
    const bulk = event.target.closest('.rkw-send-bulk');
    if (bulk) {
      event.preventDefault();
      const table = bulk.closest('.rkwm-local-orders');
      if (!table) return;
      send([...table.querySelectorAll('.rkw-order-check:checked')].map(el => el.value));
    }
  });
  document.addEventListener('change', event => {
    if (!event.target.matches('.rkw-order-check-all')) return;
    const table = event.target.closest('table');
    if (table) table.querySelectorAll('.rkw-order-check:not(:disabled)').forEach(box => { box.checked = event.target.checked; });
  });
})();
