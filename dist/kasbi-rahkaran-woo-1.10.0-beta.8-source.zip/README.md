نسخه فعلی: `1.10.0-beta.8`. انتخاب نسیه با تیک، تشخیص ارسال‌کننده و سوابق قدیمی؛ [گزارش صف قدیمی](docs/legacy-queue-beta.8-fa.md).

نسخه فعلی: `1.10.0-beta.7`. تشخیص تعارض تنظیمات نسیه و قانون درگاه و اصلاح گزارش پرداخت؛ [گزارش اسنپ‌پی](docs/snapp-credit-conflict-beta.7-fa.md).

نسخه فعلی: `1.10.0-beta.6`. بررسی تازه شناسه نوع بن پیش از ارسال و انتخاب از فهرست راهکاران؛ [گزارش بررسی خطای Sequence](docs/sequence-audit-beta.6-fa.md).

# nooshika — Kasbi Rahkaran WooCommerce

نسخه اصلاح‌شده آزمایشی `1.10.0-beta.1` بر پایه فایل ارسالی `1.9.17`.

- افزونه قابل نصب: `rahkaran-woo/`؛ پوشه نصب اصلی حفظ شده است.
- گزارش فارسی تغییرات، وضعیت پوشش و بررسی روی سایت: [docs/implementation-review-fa.md](docs/implementation-review-fa.md).
- فهرست مقایسه ایستای ۱۰۳ نمونه API: [docs/endpoint-inventory.md](docs/endpoint-inventory.md).
- آزمون مرزهای HTTP و WordPress/WooCommerce: `php -n tests/run.php` (برای runner به PHP 7.4+ و OpenSSL نیاز است).

این پروژه هنوز برابری کامل با افزونه قدیمی یا ثبت موفق روی سرور واقعی را ادعا نمی‌کند. سورس اصلی قدیمی با ionCube رمزگذاری شده و قابلیت‌های منتقل‌نشده در گزارش مشخص شده‌اند. اطلاعات اتصال یا نمونه‌های محیط دارای مقادیر محرمانه در مخزن کپی نشده‌اند.
