<?php
/**
 * Plugin Name: کاسبی راهکاران
 * Description: اتصال ووکامرس به وب‌سرویس‌های خرده‌فروشی راهکاران (نسخه 21 و 19): همگام‌سازی کالا، موجودی و قیمت و ارسال خودکار مشتری و سفارش/فاکتور.
 * Version: 1.10.0-beta.55
 * Author: Dev
 * Text Domain: rahkaran-woo
 * Requires PHP: 7.2
 * Requires Plugins: woocommerce
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'RKW_VER', '1.10.0-beta.55' );
define( 'RKW_FILE', __FILE__ );
define( 'RKW_DIR', plugin_dir_path( __FILE__ ) );
define( 'RKW_OPT', 'rkw_settings' );

require_once RKW_DIR . 'includes/class-rkw-crypto.php';
require_once RKW_DIR . 'includes/class-rkw-log.php';
require_once RKW_DIR . 'includes/class-rkw-client.php';
require_once RKW_DIR . 'includes/class-rkw-sync.php';
require_once RKW_DIR . 'includes/class-rkw-sync-runner.php';
require_once RKW_DIR . 'includes/class-rkw-auto-product.php';
require_once RKW_DIR . 'includes/class-rkw-checkout-stock.php';
require_once RKW_DIR . 'includes/class-rkw-product-view.php';
require_once RKW_DIR . 'includes/class-rkw-payment.php';
require_once RKW_DIR . 'includes/class-rkw-coupon-types.php';
require_once RKW_DIR . 'includes/class-rkw-accounting.php';
require_once RKW_DIR . 'includes/class-rkw-migration.php';
require_once RKW_DIR . 'includes/class-rkw-reports.php';
require_once RKW_DIR . 'includes/class-rkw-policy-catalog.php';
require_once RKW_DIR . 'includes/class-rkw-orders.php';
require_once RKW_DIR . 'includes/class-rkw-order-runner.php';
require_once RKW_DIR . 'includes/class-rkw-existing-invoice.php';
require_once RKW_DIR . 'includes/class-rkw-invoice-diagnostics.php';
require_once RKW_DIR . 'includes/class-rkw-document-probe.php';
require_once RKW_DIR . 'includes/class-rkw-reconciliation.php';
require_once RKW_DIR . 'includes/class-rkw-order-list-ui.php';
require_once RKW_DIR . 'includes/class-rkw-manual-orders.php';
require_once RKW_DIR . 'includes/class-rkw-returns.php';
require_once RKW_DIR . 'includes/class-rkw-pagination.php';
require_once RKW_DIR . 'includes/class-rkw-admin.php';
require_once RKW_DIR . 'includes/class-rkw-snapshot.php';
require_once RKW_DIR . 'includes/class-rkw-modules.php';
require_once RKW_DIR . 'includes/class-rkw-product-tools.php';
require_once RKW_DIR . 'includes/class-rkw-extensions.php';
require_once RKW_DIR . 'includes/class-rkw-loyalty.php';

function rkw_defaults() {
	return array(
		// اتصال
		'api'             => 'v21',      // v21 | v19
		'protocol'        => 'http',
		'ip'              => '',
		'port'            => '',
		'cluster'         => 'sg',
		'username'        => '',
		'password_enc'    => '',
		'machine_name'    => '',
		'verify_ssl'      => 1,
		'timeout'         => 30,
		'debug'           => 0,
		// کالا
		'key_field'       => 'code',     // code = کد/بارکد کالا | id = شناسه داخلی
		'shop_id'         => 1,          // فقط v19
		'store_ids'       => '',         // لیست انبارها با کاما (v21: فیلتر جمع موجودی؛ v19: اولین انبار)
		'currency_id'     => 1,
		'customer_id'     => 0,          // v19 قیمت
		'sales_area_id'   => 1,          // v19 قیمت
		'price_field'     => 'fee',      // v19: fee | consumerFee | netOfFee
		'price_divisor'   => 10,         // ریال به تومان
		'sync_stock'      => 1,
		'sync_price'      => 1,
		'sync_sale'       => 1,          // v19
		'sync_name'       => 0,
		'create_missing'  => 0,
		'auto_product_on_save' => 1,
		'checkout_stock_guard' => 1,
		'product_view_refresh' => 1,
		'page_start'      => 1,          // v21: شماره صفحه اول
		'batch_size'      => 50,
		'cron_interval'   => 'rkw_1min',
		// سفارش
		'order_enabled'   => 0,
		'coupon_sales_agent_id' => 31, // salesAgentId from the supplied ThirdPartyCoupon request.
		'document_contract' => 'legacy_esales', // Restore the supplied wp-rahkaran wire contract.
		'order_mode'      => 'salesorder', // salesorder | invoice
		'order_statuses'  => 'processing',
		'doc_pattern_id'  => 0, // Legacy document pattern; retained for upgrades.
		'invoice_doc_pattern_id' => 0,
		'order_doc_pattern_id' => 0,
		'settlement_id'   => 0, // Legacy fallback (preserved on upgrades).
		'invoice_settlement_id' => 0, // Explicit policy ID for invoices.
		'order_settlement_id' => 0, // Explicit policy ID for sales orders.
		'sales_area_ord'  => 0,
		'inventory_id'    => 0,
		'receipt_key'     => 'Cash',
		'e_receipt_type'  => '', // Optional value, used only when e_receipt_mode is explicit.
		'e_receipt_mode'  => 'omit', // Default restores previous wp-rahkaran SaveInvoice behaviour.
		'invoice_preflight' => 1, // calculateAmount validates server policies before SaveInvoice.
		'item_discount_policy_id' => 0,
		'default_unit_id' => 0,
		'customer_mode' => 'individual',
		'coupon_type_id' => 0, // Actual ThirdPartyCoupon type; not a settlement policy ID.
		'bank_account_ref' => 0, // bankAccountRef of Rahkaran; relevant to electronic/bank receipts.
		'no_gateway_order' => 'cash', // cash | credit | block
		'credit_receipt_key' => '', // Exact legacy settlement key for credit, never guessed.
		'credit_policy_id' => 0, // Required when a payment gateway is explicitly marked as credit.
		'credit_gateways' => array(),
		'payment_rules' => array(), // Per-gateway settings, bounded to 40 to avoid oversized admin forms.
		'electronic_route' => 'receipts', // v21 SaveInvoice records incoming money in receipts; payments are outbound/refunds.

		'loyalty_id'      => 0,
		'national_key'    => '_billing_national_code',
		'fida_fallback'   => 0,
		'fallback_cust'   => 0,
	);
}

/** UTF-8 truncation also works on WordPress hosts without mbstring. */
function rkw_text_slice( $text, $start, $length ) {
	if ( function_exists( 'mb_substr' ) ) { return mb_substr( (string) $text, $start, $length, 'UTF-8' ); }
	$characters = preg_split( '//u', (string) $text, -1, PREG_SPLIT_NO_EMPTY );
	return false === $characters ? '' : implode( '', array_slice( $characters, $start, $length ) );
}
function rkw_text_length( $text ) {
	return function_exists( 'mb_strlen' ) ? mb_strlen( (string) $text, 'UTF-8' ) : preg_match_all( '/./us', (string) $text );
}
function rkw_text_search( $text, $search ) {
	return function_exists( 'mb_stripos' ) ? mb_stripos( $text, $search, 0, 'UTF-8' ) : stripos( $text, $search );
}

/** Rahkaran units per one WooCommerce currency unit (10, 1, or 0.1). */
function rkw_price_multiplier( $settings = null ) {
	$s = is_array( $settings ) ? $settings : rkw_settings();
	$v = isset( $s['price_divisor'] ) && is_numeric( $s['price_divisor'] ) ? (float) $s['price_divisor'] : 1.0;
	return is_finite( $v ) && $v > 0 ? $v : 1.0;
}

function rkw_settings() {
	$s = wp_parse_args( get_option( RKW_OPT, array() ), rkw_defaults() );
	$s['password'] = RKW_Crypto::decrypt( $s['password_enc'] );
	return $s;
}

add_filter( 'cron_schedules', function ( $s ) {
	$s['rkw_1min'] = array( 'interval' => 60, 'display' => 'هر یک دقیقه' );
	$s['rkw_5min'] = array( 'interval' => 300, 'display' => 'هر پنج دقیقه' );
	$s['rkw_15min'] = array( 'interval' => 900, 'display' => 'هر ۱۵ دقیقه' );
	return $s;
} );

add_action( 'before_woocommerce_init', function () {
	if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', RKW_FILE, true );
	}
} );

register_activation_hook( __FILE__, function () { RKW_Sync::reschedule(); RKW_Loyalty::install_table(); } );
register_deactivation_hook( __FILE__, function () {
	wp_clear_scheduled_hook( 'rkw_cron_sync' );
	wp_clear_scheduled_hook( 'rkw_cron_continue' );
	RKW_Sync_Runner::cancel_pending();
} );

add_action( 'plugins_loaded', function () {
	if ( ! class_exists( 'WooCommerce' ) ) {
		add_action( 'admin_notices', function () {
			echo '<div class="notice notice-error"><p>افزونه «کاسبی راهکاران» به ووکامرس نیاز دارد.</p></div>';
		} );
		return;
	}
	RKW_Admin::init();
	RKW_Coupon_Types::init();
	RKW_Migration::init();
	RKW_Reports::init();
	RKW_Modules::init();
	RKW_Product_Tools::init();
	RKW_Sync::init();
	RKW_Sync_Runner::init();
	RKW_Auto_Product::init();
	RKW_Checkout_Stock::init();
	RKW_Product_View::init();
	RKW_Orders::init();
	RKW_Order_Runner::init();
	RKW_Existing_Invoice::init();
	RKW_Invoice_Diagnostics::init();
	RKW_Document_Probe::init();
	RKW_Reconciliation::init();
	RKW_Order_List_UI::init();
	RKW_Manual_Orders::init();
	RKW_Returns::init();
	RKW_Extensions::init();
	RKW_Loyalty::init();
} );
