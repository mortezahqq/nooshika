<?php
define('RKW_CATALOG_FIXTURES_ONLY',true);require __DIR__.'/catalog-runner.php';
function esc_url($v){return esc_attr($v);}function selected($a,$b,$echo=true){$value=(string)$a===(string)$b?'selected="selected"':'';if($echo)echo $value;return $value;}
function wp_create_nonce($action){return 'synthetic-catalog-nonce';}function wp_nonce_field($action){echo '<input type="hidden" name="_wpnonce" value="synthetic">';}function submit_button($text){echo '<button type="submit">'.esc_html($text).'</button>';}
catalog_reset();$_GET=['tab'=>'catalog'];RKW_Admin::page();
