<?php
require __DIR__ . '/bootstrap.php';

class SaleInvoiceProduct extends TestProduct {
 function get_sale_price( $context = 'view' ) { return '5259000'; }
 function get_regular_price( $context = 'view' ) { return '6674500'; }
}

foreach ( [ 'legacy_esales', 'v21', 'header_charge', 'mismatch' ] as $scenario ) {
 reset_case();
 $legacy = 'legacy_esales' === $scenario;
 $GLOBALS['options'][RKW_OPT]['document_contract'] = $legacy ? 'legacy_esales' : 'v21';
 $settings = rkw_settings();
 set_transient(RKW_Client::COOKIE_TRANSIENT, ["name"=>"sg-auth-sg","value"=>"synthetic-cookie","signature"=>RKW_Policy_Catalog::signature($settings)],60);
 $order = order( 10518000 );
 $order->items = [ new TestItem( 10518000, 0, 2 ) ];
 $order->items[0]->product = new SaleInvoiceProduct();
 $writes = 0;
 $GLOBALS['http_handler'] = with_legacy_cashier( function ( $url, $args ) use ( $scenario, $legacy, &$writes ) {
  $payload = json_decode( $args['body'], true );
  if ( str_contains( $url, 'calculateAmount' ) ) {
   if ( 0 === $payload['customerId'] ) {
    check( $payload['items'][0]['quantity'] === 2 );
    check( $payload['items'][0]['productId'] === 30 );
    return response( [ 'netPrice' => 'header_charge' === $scenario ? 106680000 : 105180000, 'items' => [ [
      'productId' => 30, 'unitId' => 1, 'quantity' => 2, 'price' => 133490000,
      'netPrice' => 'mismatch' === $scenario ? 105000000 : 105180000,
      'policies' => [ [ 'policyId' => 439, 'policyConditionId' => 463,
       'policyConditionRowId' => 3142, 'type' => 'CustomRetailMeasurementUnitDiscount',
       'price' => 28310000, 'effect' => 3, 'isIncluded' => true ] ],
    ] ] ] );
   }
   check( $payload['items'][0]['policies'][0]['effect'] === 3 );
   return response( [ 'netPrice' => 105180000 ] );
  }
  check( str_ends_with( $url, $legacy ? '/ESales.svc/invoice' : '/SaveInvoice' ) );
  $writes++;
  $row = $payload['document']['items'][0];
  check( $row['fee'] === 66745000 && $row['quantity'] === 2 );
  check( $row['policies'][0]['policyId'] === 439 && $row['policies'][0]['price'] === 28310000 );
  check( $row['policies'][0]['effect'] === ( $legacy ? 'Decrease' : 3 ) );
  check( $legacy ? ! isset( $row['price'] ) : $row['price'] === 133490000 );
  $receipt = $payload[ $legacy ? 'payments' : 'receipts' ][0];
  check( $receipt['key'] === 'EReceipt' && $receipt['amount'] === 105180000 );
  return response( [ 'id' => 100 ] );
 } );
 $result = RKW_Orders::send( $order );
 if ( 'mismatch' === $scenario ) {
  expect_error( $result, 'rkw_sale_policy_mismatch' );
  check( 0 === $writes );
 } else {
  check( true === $result && 1 === $writes );
 }
 echo "PASS $scenario\n";
}
