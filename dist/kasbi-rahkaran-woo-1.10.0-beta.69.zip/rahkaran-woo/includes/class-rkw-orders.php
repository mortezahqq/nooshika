<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** ارسال مشتری و سفارش/فاکتور ووکامرس به راهکاران (فقط API نسخه 21) */
class RKW_Orders {
	const MAX_ATTEMPTS = 5;
	const SPLIT_PLAN = '_rkw_split_invoice_plan';

	public static function init() {
		add_action( 'woocommerce_order_status_changed', array( __CLASS__, 'on_status' ), 20, 4 );
		add_action( 'rkw_send_order', array( __CLASS__, 'cron_send' ), 10, 1 );
		add_filter( 'woocommerce_order_actions', array( __CLASS__, 'order_actions' ) );
		add_action( 'woocommerce_order_action_rkw_send_order', array( __CLASS__, 'action_send' ) );
		add_action( 'woocommerce_order_action_rkw_split_invoice', array( __CLASS__, 'action_split_invoice' ) );
		add_action( 'woocommerce_admin_order_data_after_order_details', array( __CLASS__, 'order_box' ) );
		add_action( 'wp_ajax_rkw_reconcile_invoice', array( __CLASS__, 'ajax_reconcile_invoice' ) );
	}

	/* ---------- زمان‌بندی ---------- */

	public static function on_status( $order_id, $from, $to, $order ) {
		$s = rkw_settings();
		if ( empty( $s['order_enabled'] ) || 'v21' !== $s['api'] ) { return; }
		$allowed = array_filter( array_map( 'trim', explode( ',', (string) $s['order_statuses'] ) ) );
		if ( ! in_array( $to, $allowed, true ) ) { return; }
		if ( ! $order instanceof WC_Order ) { $order = wc_get_order( $order_id ); }
		if ( ! $order || RKW_Manual_Orders::is_marked( $order ) || $order->get_meta( '_rkw_doc_id' ) || $order->get_meta( '_rkw_reconcile_required' ) ) { return; }
		RKW_Order_Runner::enqueue( $order_id );
	}

	public static function cron_send( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order || RKW_Manual_Orders::is_marked( $order ) || ! RKW_Order_Runner::allowed( $order ) || $order->get_meta( '_rkw_doc_id' ) || $order->get_meta( '_rkw_reconcile_required' ) ) { return; }
		RKW_Log::add( 'info', 'شروع اجرای ارسال خودکار سفارش #' . $order_id );
		$r = self::send( $order );
		if ( is_wp_error( $r ) ) {
			$n = (int) $order->get_meta( '_rkw_queue_lock_retries' );
			// Only an overlapping request lock is automatically retryable. API validation
			// errors (e.g. missing id) are deterministic until settings/code change.
			// Unknown write results require manual reconciliation to avoid duplicates.
			if ( ! $order->get_meta( '_rkw_reconcile_required' ) && 'rkw_lock' === $r->get_error_code() && $n < self::MAX_ATTEMPTS ) {
				$order->update_meta_data( '_rkw_queue_lock_retries', $n + 1 ); $order->save_meta_data();
				RKW_Order_Runner::enqueue( $order_id, 60 * ( $n + 1 ) );
			} else {
				// Stop pre-existing queued retries from older plugin versions too.
				wp_clear_scheduled_hook( 'rkw_send_order', array( (int) $order_id ) );
			}
		}
	}

	public static function order_actions( $actions ) {
		$actions['rkw_send_order'] = 'ارسال به راهکاران';
		$actions['rkw_split_invoice'] = 'ثبت یا ادامه دو فاکتور اسنپ‌پی در راهکاران';
		return $actions;
	}

	public static function action_send( $order ) {
		$r = self::send( $order, true );
		if ( is_wp_error( $r ) ) { $order->add_order_note( 'راهکاران: ' . $r->get_error_message() ); }
	}

	public static function action_split_invoice( $order ) {
		if ( ! current_user_can( 'manage_woocommerce' ) ) { return; }
		$result = self::send( $order, true, null, true );
		if ( is_wp_error( $result ) ) { $order->add_order_note( 'راهکاران: ' . $result->get_error_message() ); }
	}

	public static function order_box( $order ) {
		if ( ! $order instanceof WC_Order ) { return; }
		if ( RKW_Manual_Orders::is_marked( $order ) ) { echo '<p class="form-field form-field-wide"><strong>راهکاران:</strong> ثبت دستی در راهکاران (علامت مدیر؛ ارسال مجدد متوقف است).</p>'; }
		$id  = $order->get_meta( '_rkw_doc_id' );
		$err = $order->get_meta( '_rkw_error' );
		$pending = $order->get_meta( '_rkw_reconcile_required' );
		$plan = $order->get_meta( self::SPLIT_PLAN );
		$split_ids = $order->get_meta( '_rkw_split_invoice_ids' );
		if ( $split_ids || is_array( $plan ) ) {
			$ids = is_array( $split_ids ) ? $split_ids : array_filter( array_column( $plan['parts'] ?? array(), 'id' ) );
			echo '<p class="form-field form-field-wide">' . esc_html( 'فاکتورهای ثبت‌شده در راهکاران: ' . ( $ids ? implode( '، ', $ids ) : 'هنوز ثبت نشده' ) ) . '</p>';
			if ( $split_ids && ! $err && ! $pending ) { return; }
		}
		if ( ! $id && ! $err && ! $pending ) { return; }
		echo '<p class="form-field form-field-wide"><strong>راهکاران:</strong> ';
		if ( $id ) {
			echo esc_html( 'OK' === (string) $id ? 'نتیجه ارسال قدیمی نامشخص است (OK)؛ ابتدا در راهکاران بررسی شود.' : ( ( 'invoice' === $order->get_meta( '_rkw_doc_type' ) ? 'فاکتور ' : 'سفارش ' ) . $id . ' ثبت شد' ) );
		} else {
			echo '<span style="color:#b32d2e">' . ( $pending ? 'نتیجه ثبت نامشخص، قبل از ارسال مجدد در راهکاران بررسی کنید. ' : 'خطا: ' ) . esc_html( $err ) . '</span>';
		}
		echo '</p>';
	}

	/** Shared matcher includes descriptions written by wp-rahkaran. */
	public static function invoice_matches_order( $invoice, WC_Order $order ) {
		return RKW_Reconciliation::matches( $invoice, $order );
	}

	/** Retain the old endpoint, with resumable read-only checks and its original nonce. */
	public static function ajax_reconcile_invoice() { RKW_Reconciliation::ajax_check( true ); }

	/* ---------- کمکی‌ها ---------- */

	/** Match the old plugin's customer/address details, using the order snapshot only. */
	public static function invoice_description( WC_Order $order ) {
		$billing = $order->get_address( 'billing' );
		$shipping = $order->get_address( 'shipping' );
		$billing = is_array( $billing ) ? $billing : array();
		$shipping = is_array( $shipping ) ? $shipping : array();
		$clean = static function ( $value ) { return trim( str_replace( '|', '،', sanitize_text_field( (string) $value ) ) ); };
		$field = static function ( $key ) use ( $billing, $shipping, $clean ) {
			$value = isset( $billing[ $key ] ) ? $clean( $billing[ $key ] ) : '';
			return '' !== $value ? $value : ( isset( $shipping[ $key ] ) ? $clean( $shipping[ $key ] ) : '' );
		};
		$first = isset( $billing['first_name'] ) ? $clean( $billing['first_name'] ) : '';
		$last = isset( $billing['last_name'] ) ? $clean( $billing['last_name'] ) : '';
		if ( '' === $first && '' === $last ) {
			$first = isset( $shipping['first_name'] ) ? $clean( $shipping['first_name'] ) : '';
			$last = isset( $shipping['last_name'] ) ? $clean( $shipping['last_name'] ) : '';
		}
		$state = $field( 'state' ); $country = $field( 'country' );
		if ( '' !== $state && '' !== $country && function_exists( 'WC' ) && WC()->countries ) {
			$states = WC()->countries->get_states( $country );
			if ( is_array( $states ) && isset( $states[ $state ] ) ) { $state = $clean( $states[ $state ] ); }
		}
		$address = array_filter( array( $state, $field( 'city' ), $field( 'address_1' ), $field( 'address_2' ) ), static function ( $value ) { return '' !== $value; } );
		$parts = array( trim( $first . ' ' . $last ), implode( '، ', $address ), $field( 'phone' ), $field( 'postcode' ) );
		$payment = $clean( $order->get_payment_method_title() );
		if ( '' !== $payment ) { $parts[] = 'روش پرداخت ' . $payment; }
		$parts[] = 'ووکامرس: ' . $order->get_id();
		$parts[] = 'سفارش سایت #' . $order->get_order_number();
		return implode( ' | ', array_filter( $parts, static function ( $value ) { return '' !== $value; } ) );
	}

	public static function normalize_mobile( $m ) {
		$m = strtr( (string) $m, array( '۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4', '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9', '٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4', '٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9' ) );
		$m = preg_replace( '/\D+/', '', $m );
		if ( 0 === strpos( $m, '0098' ) ) { $m = substr( $m, 4 ); }
		elseif ( 0 === strpos( $m, '98' ) && strlen( $m ) >= 12 ) { $m = substr( $m, 2 ); }
		if ( 10 === strlen( $m ) && '9' === $m[0] ) { $m = '0' . $m; }
		return $m;
	}

	private static function first_result( $res ) {
		if ( is_array( $res ) && isset( $res[0] ) && is_array( $res[0] ) ) { return $res[0]; }
		if ( is_array( $res ) && ( isset( $res['Id'] ) || isset( $res['id'] ) ) ) { return $res; }
		return null;
	}

	private static function cust_id( $row ) {
		if ( ! is_array( $row ) ) { return 0; }
		if ( isset( $row['Id'] ) ) { return (int) $row['Id']; }
		if ( isset( $row['id'] ) ) { return (int) $row['id']; }
		return 0;
	}

	/** Keep the service error code/data (including HTTP status), but name the exact failed step. */
	private static function stage_error( $result, $stage ) {
		if ( ! is_wp_error( $result ) ) { return $result; }
		$message = $result->get_error_message();
		if ( false !== strpos( $message, 'سخت افزار' ) || false !== strpos( $message, 'سخت‌افزار' ) ) {
			$message .= ' نام ماشین صندوق، ورود موفق به صندوق و تخصیص سخت‌افزار/روش دریافت به همان صندوق را در راهکاران بررسی کنید؛ شناسه دستگاه POS جایگزین شناسه بانک نیست.';
		}
		if ( false !== strpos( $message, 'نوع دریافت الکترونیک' ) ) {
			$message .= ' کلید دریافت، سیاست تسویه و مقدار eReceiptType را برای شناسه واقعی درگاه همین سفارش با تنظیم سرور تطبیق دهید؛ نمونه کیوسک مقدار عمومی درگاه سامان نیست.';
		}
		return new WP_Error( $result->get_error_code(), $stage . ': ' . $message, $result->get_error_data() );
	}

	/** یافتن/ساخت مشتری در راهکاران. خروجی: شناسه یا WP_Error */
	public static function ensure_customer( WC_Order $order, $s, RKW_Client $client ) {
		if ( isset( $s['customer_mode'] ) && 'default' === $s['customer_mode'] ) {
			return ! empty( $s['fallback_cust'] ) ? (int) $s['fallback_cust'] : new WP_Error( 'rkw_default_customer', 'شناسه مشتری پیش‌فرض تعیین نشده است.' );
		}
		$cached = (int) $order->get_meta( '_rkw_customer_id' );
		if ( $cached ) { return $cached; }

		$user_id = $order->get_user_id();
		if ( $user_id ) {
			$u = (int) get_user_meta( $user_id, '_rahkaran_customer_id', true );
			if ( ! $u ) { $u = (int) get_user_meta( $user_id, 'rahkaran-code', true ); }
			if ( $u ) { return $u; }
		}

		// گزینه تطبیق نام کاربری فقط در حالت فعال جایگزین موبایل صورتحساب می‌شود.
		$mobile = RKW_Extensions::customer_mobile_for_order( $order );
		$nat    = '';
		if ( $s['national_key'] ) {
			$nat = (string) $order->get_meta( $s['national_key'] );
			if ( '' === $nat && $user_id ) { $nat = (string) get_user_meta( $user_id, $s['national_key'], true ); }
			$nat = preg_replace( '/\D+/', '', strtr( $nat, array( '۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4', '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9' ) ) );
		}

		$found = 0;
		if ( '' !== $mobile ) {
			$r = $client->find_customer21( $mobile, 2 );
			// A failed search does NOT mean "customer does not exist". Creating one
			// after a 400/500 may duplicate an existing Rahkaran customer.
			if ( is_wp_error( $r ) ) { return self::stage_error( $r, 'جست‌وجوی مشتری راهکاران با موبایل' ); }
			$found = self::cust_id( self::first_result( $r ) );
		}
		if ( ! $found && '' !== $nat ) {
			$r = $client->find_customer21( $nat, 3 );
			if ( is_wp_error( $r ) ) { return self::stage_error( $r, 'جست‌وجوی مشتری راهکاران با کد ملی' ); }
			$found = self::cust_id( self::first_result( $r ) );
		}

		if ( ! $found ) {
			$first = trim( $order->get_billing_first_name() );
			$last  = trim( $order->get_billing_last_name() );
			if ( '' === $first && '' === $last ) { $first = 'مشتری'; $last = 'سایت'; }
			if ( '' === $last ) { $last = $first; }
			$payload = array(
				'partyType' => 0,
				'Id'        => 0,
				'firstName' => $first,
				'lastName'  => $last,
				'mobile'    => $mobile,
				'tel'       => '',
				'email'     => (string) $order->get_billing_email(),
			);
			if ( '' !== $nat ) { $payload['nationalID'] = $nat; }
			elseif ( $s['fida_fallback'] && '' !== $mobile ) { $payload['fidaRegistration'] = $mobile; }
			else {
				if ( $s['fallback_cust'] ) { return (int) $s['fallback_cust']; }
				return new WP_Error( 'rkw_nat', 'کد ملی مشتری مشخص نیست (برای ساخت مشتری در راهکاران لازم است). فیلد کد ملی را در تنظیمات تعیین کنید یا «مشتری پیش‌فرض» بگذارید.' );
			}
			$r = $client->save_customer21( $payload );
			if ( is_wp_error( $r ) ) {
				$error = self::stage_error( $r, 'ایجاد مشتری راهکاران' );
				if ( $s['fallback_cust'] ) {
					RKW_Log::add( 'warn', 'ساخت مشتری ناموفق، استفاده از مشتری پیش‌فرض طبق تنظیمات: ' . $error->get_error_message() );
					return (int) $s['fallback_cust'];
				}
				return $error;
			}
			$found = self::cust_id( is_array( $r ) ? $r : null );
		}

		if ( ! $found ) { return new WP_Error( 'rkw_cust', 'شناسه مشتری از راهکاران دریافت نشد.' ); }
		$order->update_meta_data( '_rkw_customer_id', $found );
		if ( $user_id ) { update_user_meta( $user_id, '_rahkaran_customer_id', $found ); }
		return $found;
	}

	/** Only positive internal IDs are valid for GetInvoice; document numbers are NOT IDs. */
	public static function confirmed_document_id( $result ) {
		if ( ! is_array( $result ) ) { return 0; }
		$objects = array( $result );
		foreach ( array( 'document', 'invoice', 'salesOrder', 'result' ) as $key ) {
			if ( isset( $result[ $key ] ) && is_array( $result[ $key ] ) ) { $objects[] = $result[ $key ]; }
		}
		foreach ( $objects as $object ) {
			foreach ( array( 'id', 'Id', 'invoiceId', 'InvoiceId', 'documentId', 'DocumentId' ) as $key ) {
				if ( isset( $object[ $key ] ) && is_scalar( $object[ $key ] ) && preg_match( '/^[1-9][0-9]*$/', (string) $object[ $key ] ) ) { return (int) $object[ $key ]; }
			}
		}
		return 0;
	}

	/**
	 * Validate the FINAL, filtered invoice payload before the remote write. A new
	 * Rahkaran document uses id=0 (per the v21 API example); a missing id is not
	 * interchangeable with zero. Do not guess an id when a filter removes it.
	 */
	public static function validate_invoice_payload( $payload, $unresolved_customer_preview = false ) {
		if ( ! is_array( $payload ) || ! isset( $payload['document'] ) || ! is_array( $payload['document'] ) ) {
			return new WP_Error( 'rkw_invoice_payload', 'بدنه فاکتور معتبر نیست؛ document وجود ندارد.' );
		}
		$doc = $payload['document'];
		if ( ! array_key_exists( 'id', $doc ) || ! is_numeric( $doc['id'] ) || (int) $doc['id'] < 0 ) {
			return new WP_Error( 'rkw_invoice_payload', 'شناسه document.id در درخواست فاکتور وجود ندارد یا نامعتبر است. برای سند جدید مقدار صفر معتبر است.' );
		}
		foreach ( array( 'customerId', 'documentPatternId', 'settlementPolicyId', 'storeId', 'inventoryId' ) as $field ) {
			if ( 'customerId' === $field && $unresolved_customer_preview && ! isset( $doc['customerId'] ) ) { continue; }
			if ( ! isset( $doc[ $field ] ) || ! is_numeric( $doc[ $field ] ) || (int) $doc[ $field ] <= 0 ) {
				return new WP_Error( 'rkw_invoice_payload', 'شناسه الزامی فاکتور document.' . $field . ' خالی یا نامعتبر است. تنظیمات شناسه‌ها را بررسی کنید.' );
			}
		}
		if ( empty( $doc['items'] ) || ! is_array( $doc['items'] ) ) {
			return new WP_Error( 'rkw_invoice_payload', 'فاکتور بدون ردیف کالا قابل ارسال نیست.' );
		}
		foreach ( $doc['items'] as $index => $item ) {
			if ( ! is_array( $item ) ) {
				return new WP_Error( 'rkw_invoice_payload', 'ساختار ردیف ' . ( $index + 1 ) . ' فاکتور معتبر نیست.' );
			}
			// The published v21 example uses capital Id for line items and lowercase id for document.
			if ( ! array_key_exists( 'Id', $item ) && ! array_key_exists( 'id', $item ) ) {
				return new WP_Error( 'rkw_invoice_payload', 'شناسه Id ردیف ' . ( $index + 1 ) . ' فاکتور از درخواست حذف شده است.' );
			}
			foreach ( array( 'productId', 'unitId', 'storeId', 'inventoryId' ) as $field ) {
				if ( ! isset( $item[ $field ] ) || ! is_numeric( $item[ $field ] ) || (int) $item[ $field ] <= 0 ) {
					return new WP_Error( 'rkw_invoice_payload', 'شناسه ' . $field . ' در ردیف ' . ( $index + 1 ) . ' فاکتور خالی یا نامعتبر است.' );
				}
			}
			if ( ! isset( $item['quantity'] ) || ! is_numeric( $item['quantity'] ) || (float) $item['quantity'] <= 0 ) {
				return new WP_Error( 'rkw_invoice_payload', 'تعداد در ردیف ' . ( $index + 1 ) . ' فاکتور معتبر نیست.' );
			}
		}
		return true;
	}

	/** Explain the source of the WooCommerce amount without exposing order/customer data. */
	public static function order_amount_breakdown( $order, $settings ) {
		$mult = rkw_price_multiplier( $settings );
		$items_total = 0.0;
		foreach ( $order->get_items() as $item ) {
			$items_total += ( (float) $item->get_total() + (float) $item->get_total_tax() );
		}
		$shipping = (float) $order->get_shipping_total() + (float) $order->get_shipping_tax();
		$other_fees = 0.0;
		$positive_fees = 0.0;
		$negative_fees = 0.0;
		foreach ( $order->get_fees() as $fee ) {
			$amount = (float) $fee->get_total() + (float) $fee->get_total_tax();
			$other_fees += $amount;
			if ( $amount > 0 ) { $positive_fees += $amount; }
			if ( $amount < 0 ) { $negative_fees += $amount; }
		}
		$expected = (float) $order->get_total();
		return array(
			'items_total' => round( $items_total * $mult, 2 ),
			'shipping_total' => round( $shipping * $mult, 2 ),
			'other_fees_total' => round( $other_fees * $mult, 2 ),
			'positive_fees_total' => round( $positive_fees * $mult, 2 ),
			'negative_fees_total' => round( $negative_fees * $mult, 2 ),
			'woo_order_total' => round( $expected * $mult, 2 ),
			'unexplained_total' => round( ( $expected - $items_total - $shipping - $other_fees ) * $mult, 2 ),
		);
	}

	/**
	 * Check the FINAL, filtered receipt total before any SaveInvoice write.
	 * For a completed electronic WooCommerce charge, the electronic receipt must
	 * cover the order amount. This does not assert that Rahkaran will accept the
	 * type: the provider may still require additional server-specific attributes.
	 * No transaction ID, card number, or customer data is logged here.
	 */
	public static function validate_electronic_receipt_amount( $payload, $order, $settings, $payment ) {
		if ( ! is_array( $payload ) || ! is_array( $payment ) || 'EReceipt' !== ( isset( $payment['receipt_key'] ) ? $payment['receipt_key'] : '' ) ) { return true; }
		if ( 'credit' === ( isset( $payment['mode'] ) ? $payment['mode'] : '' ) ) { return true; }
		$receipts = isset( $payload['receipts'] ) && is_array( $payload['receipts'] ) ? $payload['receipts'] : array();
		$received = 0.0;
		$electronic_rows = 0;
		foreach ( $receipts as $r ) {
			if ( ! is_array( $r ) || ! isset( $r['key'] ) || 'EReceipt' !== $r['key'] ) { continue; }
			$electronic_rows++;
			if ( ! array_key_exists( 'amount', $r ) || ! is_numeric( $r['amount'] ) || (float) $r['amount'] < 0 ) {
				return new WP_Error( 'rkw_receipt_amount_missing', 'مبلغ دریافت الکترونیکی EReceipt در درخواست نهایی نامعتبر است؛ سند برای جلوگیری از مغایرت ارسال نشد.' );
			}
			$received += (float) $r['amount'];
		}
		if ( ! $electronic_rows || $received <= 0 ) {
			return new WP_Error( 'rkw_receipt_amount_zero', 'برای سفارش بانکی، دریافت EReceipt با مبلغ مثبت در فاکتور وجود ندارد. قبل از ارسال، تنظیمات درگاه و فیلترهای مالی بررسی شوند.' );
		}
		$breakdown = self::order_amount_breakdown( $order, $settings );
		$expected = $breakdown['woo_order_total'];
		// Never inflate a receipt without a corresponding document policy/amount.
		if ( $expected > 0 && abs( $received - $expected ) > 1.0 ) {
			$gap = round( $expected - $received, 2 );
			$message = 'مبلغ دریافتی ' . round( $received, 2 ) . ' و جمع سفارش ' . $expected . ' برابر نیستند (اختلاف ' . $gap . '). '; 
			$message .= 'کالاها: ' . $breakdown['items_total'] . '؛ حمل با مالیات: ' . $breakdown['shipping_total'] . '؛ هزینه‌های جانبی: ' . $breakdown['other_fees_total'] . '. ';
			$ext = class_exists( 'RKW_Extensions' ) ? RKW_Extensions::settings() : array();
			$shipping_mapping = $ext ? RKW_Accounting::shipping_mapping( $order, $ext ) : array();
			$shipping_set = ! is_wp_error( $shipping_mapping ) && ! empty( $shipping_mapping['enabled'] ) && ! empty( $shipping_mapping['id'] );
			$fee_set = ! empty( $ext['extra_fee_policy_id'] );
			$shipping_missing = $breakdown['shipping_total'] > 0 && ! $shipping_set;
			$fee_missing = $breakdown['positive_fees_total'] > 0 && ! $fee_set;
			if ( $gap > 0 && $shipping_missing && abs( $gap - $breakdown['shipping_total'] ) <= 1.0 ) {
				$message .= 'اختلاف دقیقاً برابر هزینه حمل است؛ در «کاسبی راهکاران ← امکانات تکمیلی ← سیاست هزینه ارسال»، شناسه سیاست حمل معتبر را تنظیم و گزینه انتقال هزینه حمل را فعال کنید.';
			} elseif ( $gap > 0 && $fee_missing && abs( $gap - $breakdown['positive_fees_total'] ) <= 1.0 ) {
				$message .= 'اختلاف برابر هزینه‌های جانبی است؛ در «امکانات تکمیلی»، شناسه سیاست هزینه جانبی معتبر را وارد کنید.';
			} elseif ( $gap > 0 && ( $shipping_missing || $fee_missing ) && abs( $gap - $breakdown['shipping_total'] - $breakdown['positive_fees_total'] ) <= 1.0 ) {
				$message .= 'اختلاف ناشی از هزینه حمل و هزینه جانبی منتقل‌نشده است؛ سیاست‌های معتبر را در «امکانات تکمیلی» تنظیم کنید.';
			} else {
				$message .= 'جزئیات تخفیف، اعتبار وفاداری، مالیات و سیاست‌های اعمال‌شده را بررسی کنید؛ مبلغ به‌صورت خودکار دستکاری نمی‌شود.';
			}
			return new WP_Error( 'rkw_receipt_amount_mismatch', $message );
		}
		return true;
	}

	/** Minimal field-level diagnostics, with no customer contact, credentials or transaction values. */
	private static function invoice_debug_summary( $payload, $error ) {
		$doc = isset( $payload['document'] ) && is_array( $payload['document'] ) ? $payload['document'] : array();
		$items = isset( $doc['items'] ) && is_array( $doc['items'] ) ? $doc['items'] : array();
		$first = isset( $items[0] ) && is_array( $items[0] ) ? $items[0] : array();
		$receipts = isset( $payload['receipts'] ) && is_array( $payload['receipts'] ) ? $payload['receipts'] : array();
		$payments = isset( $payload['payments'] ) && is_array( $payload['payments'] ) ? $payload['payments'] : array();
		$receipt_total = 0.0;
		$payment_total = 0.0;
		foreach ( $receipts as $entry ) { if ( is_array( $entry ) && isset( $entry['amount'] ) && is_numeric( $entry['amount'] ) ) { $receipt_total += (float) $entry['amount']; } }
		foreach ( $payments as $entry ) { if ( is_array( $entry ) && isset( $entry['amount'] ) && is_numeric( $entry['amount'] ) ) { $payment_total += (float) $entry['amount']; } }
		$items_total = 0.0;
		foreach ( $items as $entry ) { if ( is_array( $entry ) && isset( $entry['price'] ) && is_numeric( $entry['price'] ) ) { $items_total += (float) $entry['price']; } }
		$selected = $payments ? $payments : $receipts;
		$attrs = isset( $selected[0]['attr'] ) && is_array( $selected[0]['attr'] ) ? $selected[0]['attr'] : array();
		$data = $error->get_error_data();
		$http = is_array( $data ) && isset( $data['http_status'] ) ? (int) $data['http_status'] : 0;
		$policies = isset( $doc['policies'] ) && is_array( $doc['policies'] ) ? $doc['policies'] : array();
		$policy_shapes = array();
		foreach ( array_slice( $policies, 0, 5 ) as $policy_row ) {
			if ( ! is_array( $policy_row ) ) { $policy_shapes[] = array( 'type' => gettype( $policy_row ) ); continue; }
			$policy_shapes[] = array(
				'policy_id' => isset( $policy_row['policyId'] ) ? absint( $policy_row['policyId'] ) : 0,
				'fields' => array_keys( $policy_row ),
				'effect_type' => isset( $policy_row['effect'] ) ? gettype( $policy_row['effect'] ) : 'absent',
			);
		}
		$http_diagnostics = array();
		foreach ( array( 'response_content_type', 'response_kind', 'response_length', 'response_fingerprint', 'response_hint' ) as $name ) {
			if ( is_array( $data ) && isset( $data[ $name ] ) && is_scalar( $data[ $name ] ) ) {
				$http_diagnostics[ $name ] = $data[ $name ];
			}
		}
		return array(
			'operation' => 'SaveInvoice',
			'http_status' => $http ?: 'not_provided',
			'error_code' => $error->get_error_code(),
			'document_id' => array_key_exists( 'id', $doc ) ? $doc['id'] : 'MISSING',
			'document_fields' => array_keys( $doc ),
			'customer_id_present' => ! empty( $doc['customerId'] ),
			'pattern_id' => isset( $doc['documentPatternId'] ) ? (int) $doc['documentPatternId'] : 'MISSING',
			'settlement_id' => isset( $doc['settlementPolicyId'] ) ? (int) $doc['settlementPolicyId'] : 'MISSING',
			'store_id' => isset( $doc['storeId'] ) ? (int) $doc['storeId'] : 'MISSING',
			'inventory_id' => isset( $doc['inventoryId'] ) ? (int) $doc['inventoryId'] : 'MISSING',
			'item_count' => count( $items ),
			'first_item_id' => array_key_exists( 'Id', $first ) ? $first['Id'] : ( array_key_exists( 'id', $first ) ? $first['id'] : 'MISSING' ),
			'first_item_fields' => array_keys( $first ),
			'receipt_count' => count( $receipts ),
			'payment_count' => count( $payments ),
			// Numerical only: distinguish an amount lost in the outgoing JSON from
			// a receipt ignored by Rahkaran's business validation.
			'sent_receipt_total' => round( $receipt_total, 2 ),
			'sent_payment_total' => round( $payment_total, 2 ),
			'sent_items_total' => round( $items_total, 2 ),
			'first_receipt_amount' => isset( $receipts[0]['amount'] ) && is_numeric( $receipts[0]['amount'] ) ? round( (float) $receipts[0]['amount'], 2 ) : 'MISSING',
			'payment_container' => $payments ? 'payments' : ( $receipts ? 'receipts' : 'none' ),
			'receipt_type_sent' => array_key_exists( 'eReceiptType', $attrs ),
			'receipt_keys' => array_map( static function ( $row ) { return is_array( $row ) && isset( $row['key'] ) ? preg_replace( '/[^A-Za-z0-9_]/', '', (string) $row['key'] ) : 'MISSING'; }, $receipts ),
			'payment_keys' => array_map( static function ( $row ) { return is_array( $row ) && isset( $row['key'] ) ? preg_replace( '/[^A-Za-z0-9_]/', '', (string) $row['key'] ) : 'MISSING'; }, $payments ),
			'first_receipt_attr_fields' => array_keys( $attrs ),
			'coupon_type_id_sent' => isset( $attrs['CouponType'] ) ? (int) $attrs['CouponType'] : 0,
			'document_policy_count' => count( $policies ),
			'document_policy_shapes' => $policy_shapes,
			'http_diagnostics' => $http_diagnostics,
		);
	}

	/** After an indeterminate POST, block retries until checked in Rahkaran. */
	private static function needs_reconciliation( $error ) {
		if ( ! is_wp_error( $error ) ) { return false; }
		if ( 'rkw_invoice_unconfirmed' === $error->get_error_code() ) { return true; }
		if ( 'rkw_http' === $error->get_error_code() || 'http_request_failed' === $error->get_error_code() ) { return true; }
		if ( 'rkw_http_status' === $error->get_error_code() ) {
			$data = $error->get_error_data();
			$code = is_array( $data ) && isset( $data['http_status'] ) ? (int) $data['http_status'] : 0;
			return ! $code || $code >= 500 || 408 === $code || 429 === $code;
		}
		return false;
	}

	/* ---------- ارسال سفارش ---------- */

	public static function send( WC_Order $order, $force = false, $locked_precondition = null, $allow_split = false ) {
		if ( RKW_Manual_Orders::is_marked( $order ) ) { return new WP_Error( 'rkw_manual_recorded', 'این سفارش ثبت دستی در راهکاران علامت خورده است؛ ارسال مجدد انجام نشد.' ); }
		if ( $allow_split && in_array( $order->get_status(), array( 'failed', 'cancelled', 'refunded' ), true ) ) {
			return new WP_Error( 'rkw_split_order_status', 'برای سفارش ناموفق، لغوشده یا برگشت‌خورده ثبت دو فاکتور انجام نمی‌شود.' );
		}
		$s = rkw_settings();
		if ( 'v21' !== $s['api'] ) { return new WP_Error( 'rkw_api', 'ارسال سفارش فقط با API نسخه 21 پشتیبانی می‌شود.' ); }
		if ( ! $force && $order->get_meta( '_rkw_doc_id' ) ) { return true; }
		if ( $order->get_meta( '_rkw_doc_id' ) ) { return new WP_Error( 'rkw_dup', 'این سفارش قبلاً در راهکاران ثبت شده است.' ); }
		$legacy = RKW_Migration::legacy_order_records( $order->get_id() );
		if ( is_wp_error( $legacy ) ) { return $legacy; }
		if ( $legacy ) { return RKW_Migration::legacy_order_error( $legacy ); }
		$legacy_sender = RKW_Migration::legacy_sender_status();
		if ( $legacy_sender['automatic_sender_active'] ) { return new WP_Error( 'rkw_legacy_sender_active', 'ارسال خودکار سفارش در wp-rahkaran فعال است. برای ارسال سفارش‌ها از کاسبی، ارسال خودکار سفارش افزونه قدیمی را خاموش و ذخیره کنید یا خود افزونه قدیمی را غیرفعال کنید؛ سند جدید از کاسبی ارسال نشد تا دو افزونه هم‌زمان فاکتور صادر نکنند.' ); }
		if ( $order->get_meta( '_rkw_reconcile_required' ) ) { return new WP_Error( 'rkw_reconcile', 'نتیجه آخرین درخواست ثبت سند مشخص نیست. قبل از ارسال مجدد، شماره سفارش را در راهکاران بررسی کنید تا فاکتور تکراری ایجاد نشود.' ); }

		$lock = 'rkw_order_lock_' . $order->get_id();
		// add_option uses the unique option_name index: two workers cannot own this lock.
		if ( ! add_option( $lock, array( 'started' => time() ), '', false ) ) { return new WP_Error( 'rkw_lock', 'ارسال این سفارش قفل است؛ اگر اجرای قبلی قطع شده، ابتدا وضعیت سند راهکاران را بررسی کنید.' ); }

		try {
		// A marker can have been saved after this sender loaded the order. Read it
		// again under the same lock before customer creation or any financial POST.
		$fresh_mark = wc_get_order( $order->get_id() );
		if ( $fresh_mark instanceof WC_Order ) {
			if ( method_exists( $fresh_mark, 'read_meta_data' ) ) { $fresh_mark->read_meta_data( true ); }
			if ( RKW_Manual_Orders::is_marked( $fresh_mark ) ) { return new WP_Error( 'rkw_manual_recorded', 'این سفارش ثبت دستی در راهکاران علامت خورده است؛ ارسال مجدد انجام نشد.' ); }
			if ( $fresh_mark->get_meta( '_rkw_doc_id' ) ) { return $force ? new WP_Error( 'rkw_dup', 'این سفارش قبلاً در راهکاران ثبت شده است.' ) : true; }
			if ( $fresh_mark->get_meta( '_rkw_reconcile_required' ) ) { return new WP_Error( 'rkw_reconcile', 'نتیجه ثبت قبلی نامشخص است؛ برای جلوگیری از سند تکراری، ارسال انجام نشد.' ); }
			if ( $fresh_mark->get_meta( self::SPLIT_PLAN ) ) { $order = $fresh_mark; }
		}
		if ( null !== $locked_precondition ) {
			$fresh = wc_get_order( $order->get_id() );
			if ( ! $fresh instanceof WC_Order ) { return new WP_Error( 'rkw_manual_missing', 'سفارش برای ثبت دستی پیدا نشد.' ); }
			if ( method_exists( $fresh, 'get_data_store' ) ) { $store = $fresh->get_data_store(); if ( $store && is_callable( array( $store, 'read' ) ) ) { $store->read( $fresh ); } }
			if ( method_exists( $fresh, 'read_meta_data' ) ) { $fresh->read_meta_data( true ); }
			$guard = call_user_func( $locked_precondition, $fresh );
			if ( is_wp_error( $guard ) ) { return $guard; }
			if ( true !== $guard ) { return new WP_Error( 'rkw_manual_guard', 'تأیید پیش‌نمایش ثبت دستی معتبر نیست.' ); }
			$order = $fresh;
			$s = rkw_settings();
		}
		$plan = $order->get_meta( self::SPLIT_PLAN );
		if ( is_array( $plan ) ) {
			$result = $allow_split
				? self::continue_split_invoice( $order, $s, new RKW_Client(), $plan )
				: new WP_Error( 'rkw_split_in_progress', 'ثبت دو فاکتور برای سفارش شروع شده است. از عمل «ثبت یا ادامه دو فاکتور اسنپ‌پی» استفاده کنید.' );
		} else {
			$result = self::do_send( $order, $s, false, $allow_split );
		}

		if ( is_wp_error( $result ) ) {
			$n = (int) $order->get_meta( '_rkw_attempts' ) + 1;
			$order->update_meta_data( '_rkw_attempts', $n );
			$order->update_meta_data( '_rkw_error', $result->get_error_message() );
			$order->save();
			RKW_Log::add( 'error', 'سفارش #' . $order->get_id() . ' (تلاش ' . $n . '): ' . $result->get_error_message() );
			if ( $order->get_meta( '_rkw_reconcile_required' ) ) { $order->add_order_note( 'راهکاران: نتیجه ثبت سند نامشخص است؛ ارسال خودکار برای جلوگیری از سند تکراری متوقف شد. ابتدا در راهکاران بررسی شود.' ); }
			return $result;
		}
		return true;
		} finally { delete_option( $lock ); }
	}

	/** Build the current invoice for an explicit calculation probe, never resolve/create missing mappings. */
	/** Recover the ERP discount only when it reproduces the stored WooCommerce line subtotal. */
	private static function public_sale_policies( $client, $settings, $product_id, $unit, $quantity, $subtotal ) {
		$result = $client->calculate_public_product_price(
			array( 'id' => $product_id, 'unit' => $unit, 'quantity' => $quantity ),
			$settings
		);
		if ( is_wp_error( $result ) ) { return $result; }
		$mismatch = static function ( $reason ) use ( $product_id ) {
			return new WP_Error(
				'rkw_sale_policy_mismatch',
				sprintf( 'تخفیف کالای %d با مبلغ سفارش تطبیق داده نشد. %s', $product_id, $reason )
			);
		};
		if ( ! is_array( $result ) || ! is_array( $result['items'] ?? null ) || 1 !== count( $result['items'] ) ) {
			return $mismatch( 'راهکاران دقیقاً یک ردیف کالا برنگرداند.' );
		}
		if ( ! empty( $result['hasError'] ) ) {
			return $mismatch( 'خطای محاسبه سند راهکاران. ' . sanitize_text_field( (string) ( $result['errorMessage'] ?? '' ) ) );
		}
		$row = reset( $result['items'] );
		if ( ! is_array( $row ) || (int) ( $row['productId'] ?? 0 ) !== $product_id
			|| (int) ( $row['unitId'] ?? 0 ) !== $unit || (float) ( $row['quantity'] ?? 0 ) !== $quantity ) {
			return $mismatch( sprintf( 'ردیف برگشتی با شناسه کالا، واحد %d و تعداد %s منطبق نبود.', $unit, $quantity ) );
		}
		if ( ! empty( $row['hasError'] ) ) {
			return $mismatch( 'خطای ردیف راهکاران. ' . sanitize_text_field( (string) ( $row['errorMessage'] ?? '' ) ) );
		}
		foreach ( array( $row['price'] ?? null, $row['netPrice'] ?? null ) as $amount ) {
			if ( ! is_numeric( $amount ) || ! is_finite( (float) $amount ) ) {
				return $mismatch( 'قیمت پایه یا خالص ردیف عدد معتبر نبود.' );
			}
		}
		$base = (float) $row['price'];
		$net = (float) $row['netPrice'];
		// The quote can include header charges. Only the item net belongs to this comparison.
		if ( $base < $net || $net < 0 || $net + 0.01 < $subtotal ) {
			return $mismatch( sprintf( 'مبلغ ردیف سفارش %s، پایه ردیف راهکاران %s و خالص ردیف راهکاران %s است.', $subtotal, $base, $net ) );
		}
		$policies = array();
		$sum = 0.0;
		foreach ( (array) ( $row['policies'] ?? array() ) as $policy ) {
			if ( ! is_array( $policy ) ) { return $mismatch( 'سیاست‌های ردیف شامل مبلغ نامعتبر یا سیاست مالی دیگری است.' ); }
			if ( true !== ( $policy['isIncluded'] ?? false ) ) { continue; }
			$amount = $policy['price'] ?? null;
			if ( ! is_numeric( $amount ) || ! is_finite( (float) $amount ) || $amount < 0 ) { return $mismatch( 'سیاست‌های ردیف شامل مبلغ نامعتبر یا سیاست مالی دیگری است.' ); }
			if ( 0.0 === (float) $amount ) { continue; }
			if ( ! RKW_Accounting::is_calculated_discount( $policy ) || empty( $policy['policyId'] ) ) { return $mismatch( 'سیاست‌های ردیف شامل مبلغ نامعتبر یا سیاست مالی دیگری است.' ); }
			$policies[] = array_intersect_key( $policy, array_flip( array( 'policyId', 'policyConditionId', 'policyConditionRowId', 'type', 'price', 'effect', 'isIncluded' ) ) );
			$sum += (float) $amount;
		}
		if ( ! is_finite( $sum ) || abs( $base - $net - $sum ) > 0.01 ) {
			return $mismatch( sprintf( 'اختلاف پایه و خالص %s است، اما جمع سیاست‌های تخفیف فعال %s است.', $base - $net, $sum ) );
		}
		$gap = max( 0, round( $net - $subtotal, 2 ) );
		$manual_policy_id = (int) ( $settings['item_discount_policy_id'] ?? 0 );
		if ( $gap > 0.01 && $manual_policy_id <= 0 ) {
			$discount_options = array();
			foreach ( (array) ( $row['policies'] ?? array() ) as $policy ) {
				if ( ! is_array( $policy ) || empty( $policy['policyId'] ) || ! RKW_Accounting::is_calculated_discount( $policy ) ) { continue; }
				$entry = array_intersect_key( $policy, array_flip( array( 'policyId', 'policyConditionId', 'policyConditionRowId', 'price', 'isIncluded', 'isReadOnly', 'enforcement', 'definitiveness' ) ) );
				if ( is_string( $policy['title'] ?? null ) ) { $entry['title'] = sanitize_text_field( $policy['title'] ); }
				$discount_options[] = $entry;
			}
			RKW_Log::add( 'info', 'سیاست‌های تخفیف ردیف راهکاران | ' . wp_json_encode( array(
				'productId' => $product_id,
				'unitId' => $unit,
				'quantity' => $quantity,
				'gap' => $gap,
				'policies' => $discount_options,
			), JSON_UNESCAPED_UNICODE ) );
			$error = $mismatch( sprintf( 'خالص راهکاران %s و مبلغ ردیف سفارش %s است. برای ثبت اختلاف %s، جزئیات گزینه‌های برگشتی را در رویداد «سیاست‌های تخفیف ردیف راهکاران» ببینید و شناسه معتبر را در «سیاست تخفیف ردیف کالا» وارد کنید.', $net, $subtotal, $gap ) );
			return new WP_Error( $error->get_error_code(), $error->get_error_message(), array( 'verified_gap' => $gap, 'base' => $base ) );
		}
		$manual_policy = null;
		foreach ( (array) ( $row['policies'] ?? array() ) as $candidate ) {
			if ( ! is_array( $candidate ) || (int) ( $candidate['policyId'] ?? 0 ) !== $manual_policy_id
				|| false !== ( $candidate['isReadOnly'] ?? null ) || ! RKW_Accounting::is_calculated_discount( $candidate )
				|| empty( $candidate['policyConditionId'] ) || empty( $candidate['policyConditionRowId'] ) ) {
				continue;
			}
			$manual_policy = array_intersect_key( $candidate, array_flip( array(
				'policyId', 'policyConditionId', 'policyConditionRowId', 'type', 'effect', 'enforcement', 'definitiveness', 'isReadOnly',
			) ) );
			if ( is_array( $candidate['outputs'] ?? null ) ) {
				$manual_policy['outputs'] = $candidate['outputs'];
			}
			break;
		}
		return array( 'base' => $base, 'policies' => $policies, 'gap' => $gap, 'manual_policy' => $manual_policy );
	}

	/** Use the editable fixed-value output returned by the server, when unambiguous. */
	private static function set_manual_discount_amount( $policy, $amount ) {
		$policy['price'] = $amount;
		$policy['isIncluded'] = true;
		$editable = array();
		foreach ( $policy['outputs'] ?? array() as $key => $output ) {
			$number = is_array( $output ) ? ( $output['numericValue'] ?? null ) : null;
			if ( is_array( $number ) && true === ( $number['canChangeValue'] ?? false ) ) {
				$editable[ $key ] = $number;
			}
		}
		if ( count( $editable ) === 1 ) {
			$key = key( $editable );
			if ( false === ( $editable[ $key ]['isPercentageBased'] ?? null ) ) {
				$policy['outputs'][ $key ]['numericValue']['value'] = $amount;
				$policy['outputs'][ $key ]['numericValue']['valueChanged'] = true;
			}
		}
		return $policy;
	}

	/** WooCommerce stores sale prices in the subtotal, before checkout coupons. */
	private static function matches_product_sale( $product, $order, $item, $quantity ) {
		if ( ! is_callable( array( $product, 'get_sale_price' ) ) || ! is_callable( array( $product, 'get_regular_price' ) ) ) { return false; }
		$sale = $product->get_sale_price( 'edit' );
		$regular = $product->get_regular_price( 'edit' );
		if ( ! is_numeric( $sale ) || ! is_numeric( $regular ) || $sale <= 0 || $regular <= $sale ) { return false; }
		$subtotal = (float) $item->get_subtotal();
		if ( is_callable( array( $order, 'get_prices_include_tax' ) ) && $order->get_prices_include_tax() ) {
			$subtotal += (float) $item->get_subtotal_tax();
		}
		return abs( $subtotal - (float) $sale * $quantity ) <= 0.01;
	}

	public static function preview_invoice_payload( WC_Order $order ) {
		$s = rkw_settings();
		if ( 'v21' !== $s['api'] || 'invoice' !== $s['order_mode'] ) { return new WP_Error( 'rkw_probe_mode', 'محاسبه تشخیصی فقط برای فاکتور با اتصال نسخه ۲۱ است.' ); }
		return self::do_send( $order, $s, true );
	}

	/** Read-only manual draft; missing customers are omitted, never replaced with invented IDs. */
	public static function preview_manual_payload( WC_Order $order ) {
		$s = rkw_settings();
		if ( 'v21' !== $s['api'] ) { return new WP_Error( 'rkw_manual_api', 'ثبت دستی سفارش به اتصال API نسخه ۲۱ نیاز دارد.' ); }
		return self::do_send( $order, $s, 'manual' );
	}

	/** Freeze the commercial values so a partial invoice cannot resume on an edited order. */
	private static function split_signature( $order, $settings ) {
		$lines = array();
		foreach ( $order->get_items() as $item ) {
			$product = $item->get_product();
			$product_key = $product ? array( $product->get_meta( '_rahkaran_product_id' ), $product->get_meta( '_rahkaran_unit_id' ), $product->get_sku() ) : null;
			$lines[] = array( $product_key, (float) $item->get_quantity(), (float) $item->get_subtotal(), (float) $item->get_subtotal_tax(),
				(float) $item->get_total(), (float) $item->get_total_tax() );
		}
		return hash( 'sha256', wp_json_encode( array( $order->get_id(), $order->get_payment_method(), (float) $order->get_total(),
			self::order_amount_breakdown( $order, $settings ), $lines, $settings, RKW_Extensions::settings() ) ) );
	}

	private static function start_split_invoice( $order, $settings, $client, $payload, $document, $calculated, $expected_total ) {
		$receipts = $payload['receipts'] ?? array();
		if ( count( $receipts ) !== 1 || ! empty( $payload['payments'] ) || 'ThirdPartyCoupon' !== ( $receipts[0]['key'] ?? '' )
			|| abs( (float) $receipts[0]['amount'] - $expected_total ) > 0.01 ) {
			return new WP_Error( 'rkw_split_receipts', 'ثبت دو فاکتور فقط برای یک دریافت اسنپ‌پی برابر جمع سفارش پشتیبانی می‌شود.' );
		}
		$groups = null;
		$report = RKW_Invoice_Diagnostics::inspect_snapp_groups( $client, $document, $calculated, $expected_total, $groups );
		if ( empty( $report['combined_matches'] ) || ! is_array( $groups ) || count( $groups ) !== 2 ) {
			return new WP_Error( 'rkw_split_calculation', 'راهکاران مبلغ و ردیف‌های هر دو فاکتور را تأیید نکرد؛ هیچ فاکتوری ارسال نشد.' );
		}
		$parts = array();
		foreach ( $groups as $key => $draft ) {
			$amount = round( (float) $report['groups'][ $key ]['expected'], 2 );
			if ( $amount <= 0 ) { return new WP_Error( 'rkw_split_amount', 'مبلغ یکی از دو فاکتور معتبر نیست.' ); }
			$parts[] = array( 'document' => $draft, 'amount' => $amount, 'id' => 0 );
		}
		if ( abs( array_sum( array_column( $parts, 'amount' ) ) - $expected_total ) > 0.005 ) {
			return new WP_Error( 'rkw_split_amount', 'جمع مبالغ دو فاکتور با دریافت سفارش برابر نیست.' );
		}
		$plan = array( 'signature' => self::split_signature( $order, $settings ), 'parts' => $parts, 'receipt' => $receipts[0], 'pending' => null );
		$order->update_meta_data( self::SPLIT_PLAN, $plan );
		$order->save();
		return self::continue_split_invoice( $order, $settings, $client, $plan, false );
	}

	private static function continue_split_invoice( $order, $settings, $client, $plan, $recheck = true ) {
		if ( ! hash_equals( (string) ( $plan['signature'] ?? '' ), self::split_signature( $order, $settings ) )
			|| count( $plan['parts'] ?? array() ) !== 2 ) {
			return new WP_Error( 'rkw_split_changed', 'سفارش یا تنظیمات از زمان آماده‌سازی دو فاکتور تغییر کرده است؛ ابتدا وضعیت بخش‌های قبلی را بررسی کنید.' );
		}
		if ( null !== ( $plan['pending'] ?? null ) ) {
			return new WP_Error( 'rkw_split_pending', 'نتیجه ثبت یکی از دو فاکتور نامشخص است؛ برای جلوگیری از ثبت تکراری، ادامه متوقف شد.' );
		}
		$coupon_type = (int) $plan['receipt']['attr']['CouponType'];
		$client->use_coupon_invoice_context();
		$client->expect_coupon_type( $coupon_type, $order->get_id() );
		foreach ( $plan['parts'] as $i => $part ) {
			if ( ! empty( $part['id'] ) ) { continue; }
			$label = 'فاکتور ' . ( $i + 1 ) . ' از ۲';
			$draft = $part['document'];
			if ( $recheck ) {
				$checked = $client->calculate_invoice21( $draft );
				if ( is_wp_error( $checked ) ) { return self::stage_error( $checked, 'محاسبه دوباره ' . $label ); }
				$lines = is_array( $checked ) ? RKW_Accounting::snapp_line_check( $draft, $checked ) : array();
				if ( empty( $lines['matched'] ) || ! empty( $lines['differences'] ) || ! empty( $checked['hasError'] )
					|| ! is_numeric( $checked['netPrice'] ?? null ) || ! is_finite( (float) $checked['netPrice'] )
					|| abs( (float) $checked['netPrice'] - $part['amount'] ) > 0.01 ) {
					return new WP_Error( 'rkw_split_calculation', 'محاسبه دوباره ' . $label . ' با مبلغ سفارش هم‌خوان نیست؛ این بخش ارسال نشد.' );
				}
			}
			$draft['description'] = self::invoice_description( $order ) . ' | ' . $label;
			$receipt = $plan['receipt'];
			$receipt['amount'] = $part['amount'];
			$payload = array( 'document' => $draft, 'receipts' => array( $receipt ), 'payments' => array() );
			$valid = $client->validate_document_coupon_types( $payload );
			if ( is_wp_error( $valid ) ) { return self::stage_error( $valid, $label ); }
			$context = $client->prepare_document_context();
			if ( is_wp_error( $context ) ) { return self::stage_error( $context, $label ); }

			$plan['pending'] = $i;
			$order->update_meta_data( self::SPLIT_PLAN, $plan );
			$order->update_meta_data( '_rkw_reconcile_required', 1 );
			$order->save();
			$result = $client->save_invoice21( $payload );
			if ( is_wp_error( $result ) ) {
				if ( 'rkw_api' === $result->get_error_code() ) {
					$plan['pending'] = null;
					$order->update_meta_data( self::SPLIT_PLAN, $plan );
					$order->delete_meta_data( '_rkw_reconcile_required' );
					$order->save();
				}
				return self::stage_error( $result, $label );
			}
			$id = self::confirmed_document_id( $result );
			if ( ! $id || in_array( $id, array_column( $plan['parts'], 'id' ), true ) ) {
				return new WP_Error( 'rkw_split_unconfirmed', 'شناسه مستقل و معتبر برای ' . $label . ' دریافت نشد؛ ادامه متوقف شد.' );
			}
			$plan['parts'][ $i ]['id'] = $id;
			$plan['pending'] = null;
			$order->update_meta_data( self::SPLIT_PLAN, $plan );
			$order->delete_meta_data( '_rkw_reconcile_required' );
			$order->save();
			$order->add_order_note( 'راهکاران: ' . $label . ' با شناسه ' . $id . ' و مبلغ ' . $part['amount'] . ' ثبت شد.' );
			RKW_Snapshot::invalidate_section( 'invoices' );
		}
		$ids = array_column( $plan['parts'], 'id' );
		$order->update_meta_data( '_rkw_split_invoice_ids', $ids );
		$order->update_meta_data( '_rkw_split_second_invoice_id', (string) $ids[1] );
		$order->update_meta_data( '_rkw_doc_id', (string) $ids[0] );
		$order->update_meta_data( '_rkw_doc_type', 'invoice' );
		$order->delete_meta_data( '_rkw_error' );
		$order->delete_meta_data( '_rkw_reconcile_required' );
		$order->delete_meta_data( self::SPLIT_PLAN );
		$order->save();
		if ( $order->get_user_id() ) { set_transient( 'rkw_first_' . (int) $order->get_user_id(), 'no', HOUR_IN_SECONDS ); }
		RKW_Log::add( 'info', 'سفارش #' . $order->get_id() . ' با دو فاکتور راهکاران ثبت شد: ' . implode( '، ', $ids ) );
		return true;
	}

	private static function do_send( WC_Order $order, $s, $diagnostic = false, $allow_split = false ) {
		$client = new RKW_Client();
		if ( 'invoice' === $s['order_mode'] && '' === trim( (string) $s['machine_name'] ) ) { return new WP_Error( 'rkw_machine_required', 'برای ثبت فاکتور، نام ماشین صندوق تعریف‌شده در راهکاران را در تنظیمات اتصال وارد کنید؛ شناسه سخت‌افزار نمونه ساخته نمی‌شود.' ); }

		$pattern_key = 'invoice' === $s['order_mode'] ? 'invoice_doc_pattern_id' : 'order_doc_pattern_id';
		$pattern_id = ! empty( $s[ $pattern_key ] ) ? (int) $s[ $pattern_key ] : (int) $s['doc_pattern_id'];
		if ( ! $pattern_id || ! (int) $s['inventory_id'] ) {
			return new WP_Error( 'rkw_cfg', 'شناسه الگوی سند مربوط به نوع فاکتور/سفارش و انبار در تنظیمات سفارش تکمیل نشده است.' );
		}

		$payment = RKW_Payment::resolve( $order, $s );
		if ( is_wp_error( $payment ) ) { return self::stage_error( $payment, 'اعتبارسنجی سیاست و نوع دریافت' ); }
		if ( isset( $payment['receipt_key'] ) && 'ThirdPartyCoupon' === $payment['receipt_key'] ) {
			if ( 'invoice' === $s['order_mode'] ) { $client->use_coupon_invoice_context(); $client->expect_coupon_type( (int) $payment['coupon_type_id'], $order->get_id() ); }
			$valid = $client->validate_coupon_type21( $payment['coupon_type_id'] );
			if ( is_wp_error( $valid ) ) { return self::stage_error( $valid, 'تطبیق نوع بن با فهرست واقعی راهکاران' ); }
		}

		$mult  = rkw_price_multiplier( $s ); // تومان -> ریال
		$items = array();
		$verify_coupon_discount = 'ThirdPartyCoupon' === $payment['receipt_key']
			&& 'WC_Gateway_SnappPay' === $payment['gateway'] && ! empty( $s['invoice_preflight'] );
		$additional_unit_rows = 0;
		$total = 0.0;
		$bad   = array();
		foreach ( $order->get_items() as $it ) {
			$product = $it->get_product();
			if ( ! $product ) { $bad[] = $it->get_name(); continue; }
			$rid  = (int) $product->get_meta( '_rahkaran_product_id' );
			$unit = (int) $product->get_meta( '_rahkaran_unit_id' );
			if ( ! $rid ) {
				if ( $diagnostic ) { return new WP_Error( 'rkw_probe_mapping', 'شناسه راهکاران یکی از کالاها ذخیره نشده است؛ بررسی بدون ثبت، اتصال کالا را تغییر نمی‌دهد.' ); }
				$mapping = RKW_Migration::product_mapping( $product, $client, $s );
				if ( is_wp_error( $mapping ) ) { return $mapping; }
				$rid = $mapping['id']; $unit = $mapping['unit'];
			}
			if ( ! $unit ) { $unit = (int) $s['default_unit_id']; }
			if ( ! $rid || ! $unit ) { $bad[] = $it->get_name(); continue; }
			$qty = (float) $it->get_quantity();
			if ( $qty <= 0 ) { continue; }
			$line  = ( (float) $it->get_total() + (float) $it->get_total_tax() ) * $mult;
			$gross = ( (float) $it->get_subtotal() + (float) $it->get_subtotal_tax() ) * $mult;
			$discount = round( $gross - $line, 2 );
			$discount_policy = ! empty( $s['item_discount_policy_id'] ) && $discount > 0 ? array( array( 'policyId' => (int) $s['item_discount_policy_id'], 'price' => $discount, 'effect' => 1, 'isIncluded' => true ) ) : array();
			$confirmed_sale = false;
			$copies = 1;
			if ( 'invoice' === $s['order_mode'] && self::matches_product_sale( $product, $order, $it, $qty ) ) {
				$public_sale = self::public_sale_policies( $client, $s, $rid, $unit, $qty, $gross );
				$quote = is_wp_error( $public_sale ) ? $public_sale->get_error_data() : $public_sale;
				$gap = is_array( $quote ) ? ( $quote['gap'] ?? $quote['verified_gap'] ?? 0 ) : 0;
				// A fixed reduction may apply once per row. Try one unit using the same ERP product and unit.
				if ( 'ThirdPartyCoupon' === $payment['receipt_key'] && $gap > 0.01 && 0.0 === $discount
					&& $qty >= 2 && $qty <= 20 && floor( $qty ) === $qty && $additional_unit_rows + $qty - 1 <= 40 ) {
					$per_unit = round( $gross / $qty, 2 );
					if ( abs( $per_unit * $qty - $gross ) < 0.005 ) {
						$unit_sale = self::public_sale_policies( $client, $s, $rid, $unit, 1.0, $per_unit );
						if ( ! is_wp_error( $unit_sale ) && $unit_sale['gap'] <= 0.01 && $unit_sale['policies']
							&& abs( $unit_sale['base'] * $qty - $quote['base'] ) <= 0.01 ) {
							$copies = (int) $qty;
							$additional_unit_rows += $copies - 1;
							$qty = 1.0;
							$line = $per_unit;
							$public_sale = $unit_sale;
							$verify_coupon_discount = true;
						}
					}
				}
				if ( is_wp_error( $public_sale ) ) { return self::stage_error( $public_sale, 'تطبیق تخفیف کالا با مبلغ سفارش' ); }
				$manual_discount = round( $discount + $public_sale['gap'], 2 );
				$discount_policy = $public_sale['policies'];
				if ( $manual_discount > 0.01 ) {
					$manual_id = (int) $s['item_discount_policy_id'];
					if ( $manual_id <= 0 || in_array( $manual_id, array_map( 'intval', array_column( $discount_policy, 'policyId' ) ), true ) ) {
						return new WP_Error( 'rkw_coupon_line_policy', 'برای ثبت اختلاف قیمت سفارش، در «سیاست تخفیف ردیف کالا» یک سیاست کاهش دستی مستقل از سیاست تخفیف خودکار راهکاران تعیین کنید.' );
					}
					if ( 'ThirdPartyCoupon' === $payment['receipt_key'] ) {
						$manual_policy = $public_sale['manual_policy'];
						if ( null === $manual_policy ) {
							return new WP_Error( 'rkw_coupon_line_policy', sprintf( 'راهکاران برای کالای %d اطلاعات سیاست تخفیف قابل اعمال %d را برنگرداند؛ فاکتور ارسال نشد.', $rid, $manual_id ) );
						}
						$discount_policy[] = self::set_manual_discount_amount( $manual_policy, $manual_discount );
					} else {
						$discount_policy[] = array( 'policyId' => $manual_id, 'price' => $manual_discount, 'effect' => 1, 'isIncluded' => true );
					}
				}
				$gross = $public_sale['base'];
				$confirmed_sale = true;
				if ( 'ThirdPartyCoupon' === $payment['receipt_key'] && $discount_policy ) {
					$verify_coupon_discount = true;
				}
			}
			// wp-rahkaran sends the pre-discount unit amount as fee in ESales, even without a discount policy.
			// price remains the actual charged unit amount in that contract.
			$fee   = round( ( $discount_policy || ( ! isset( $s['document_contract'] ) || 'legacy_esales' === $s['document_contract'] ) ? $gross : $line ) / $qty, 6 );
			$price = round( $line, 2 );
			$total += $price * $copies;
			$item = array(
				'Id' => 0, 'inventoryId' => (int) $s['inventory_id'], 'storeId' => (int) $s['inventory_id'], 'productId' => $rid, 'quantity' => $qty, 'unitId' => $unit,
				'fee' => $fee, 'price' => $discount_policy ? round( $gross, 2 ) : $price, 'settlementPolicyId' => (int) $payment['settlement_id'], 'policies' => $discount_policy, 'toppings' => array(),
				'returnInvoicePermitItemId' => null, 'referenceId' => null,
				'trackingFactor1' => null, 'trackingFactor2' => null, 'trackingFactor3' => null, 'trackingFactor4' => null, 'trackingFactor5' => null,
				'partTrackingFactorRef1' => null, 'partTrackingFactorRef2' => null, 'partTrackingFactorRef3' => null, 'partTrackingFactorRef4' => null, 'partTrackingFactorRef5' => null,
				'isTrackingFactorInputModeManual1' => null, 'isTrackingFactorInputModeManual2' => null, 'isTrackingFactorInputModeManual3' => null, 'isTrackingFactorInputModeManual4' => null, 'isTrackingFactorInputModeManual5' => null,
				'trackingFactorHasQuantity1' => false, 'trackingFactorHasQuantity2' => false, 'TrackingFactorHasQuantity3' => false, 'trackingFactorHasQuantity4' => false, 'trackingFactorHasQuantity5' => false,
			);
			if ( $confirmed_sale && $client->uses_legacy_documents() && 'ThirdPartyCoupon' !== $payment['receipt_key'] ) {
				$item['netPrice'] = $price;
			}
			for ( $copy = 0; $copy < $copies; $copy++ ) {
				$items[] = $item;
			}
		}
		if ( $bad ) {
			return new WP_Error( 'rkw_map', 'کالاهای بدون اتصال به راهکاران (ابتدا همگام‌سازی کالا را اجرا کنید): ' . implode( '، ', array_unique( $bad ) ) );
		}
		if ( ! $items ) { return new WP_Error( 'rkw_empty', 'سفارش آیتم قابل ارسال ندارد.' ); }


		$cust = $diagnostic ? (int) $order->get_meta( '_rkw_customer_id' ) : self::ensure_customer( $order, $s, $client );
		if ( 'manual' === $diagnostic && 'default' === $s['customer_mode'] ) { $cust = (int) $s['fallback_cust']; }
		if ( $diagnostic && ! $cust && 'default' === $s['customer_mode'] ) { $cust = (int) $s['fallback_cust']; }
		if ( 'manual' === $diagnostic && ! $cust && $order->get_user_id() ) { $cust = (int) get_user_meta( $order->get_user_id(), '_rahkaran_customer_id', true ) ?: (int) get_user_meta( $order->get_user_id(), 'rahkaran-code', true ); }
		if ( $diagnostic && ! $cust && 'manual' !== $diagnostic ) { return new WP_Error( 'rkw_probe_customer', 'شناسه مشتری این سفارش ذخیره نشده است؛ محاسبه بدون ثبت، مشتری جدید نمی‌سازد.' ); }
		if ( is_wp_error( $cust ) ) { return $cust; }
		// Keep the Rahkaran customer ID on the WooCommerce order even when
		// resolved via a user mapping or the configured fallback customer.
		if ( ! $diagnostic ) { $order->update_meta_data( '_rkw_customer_id', (int) $cust ); }

		$invoice = ( 'invoice' === $s['order_mode'] );
		$doc     = array(
			'id'                => 0,
			'inventoryId'       => (int) $s['inventory_id'],
			'storeId'           => (int) $s['inventory_id'],
			'salesAreaId'       => (int) $s['sales_area_ord'] ? (int) $s['sales_area_ord'] : null,
			'documentPatternId' => $pattern_id,
			'documentType'      => $invoice ? 1 : 3,
			'customerId'        => (int) $cust,
			'status'            => 1,
			'currencyId'        => (int) $s['currency_id'],
			'date'              => gmdate( 'Y-m-d\TH:i:s', $order->get_date_created() ? $order->get_date_created()->getTimestamp() : time() ),
			'description'       => self::invoice_description( $order ),
			'items'             => $items,
			'settlementPolicyId' => (int) $payment['settlement_id'],
			'policies'          => array(),
			'data'              => array(
				'loyaltyProgramID' => (int) $s['loyalty_id'] ? (int) $s['loyalty_id'] : null,
				'discountCards'    => array(),
			),
		);
		$payload = array(
			'document' => $doc,
			'receipts' => array(),
			'payments' => array(),
		);
		$settlement_entries = RKW_Payment::settlement_entries( $order, $total, $payment, $invoice );
		$payload['receipts'] = $settlement_entries['receipts'];
		$payload['payments'] = $settlement_entries['payments'];
		$payload = apply_filters( 'rkw_order_payload', $payload, $order, $s );
		if ( is_wp_error( $payload ) ) { return $payload; }
		foreach ( $payload['receipts'] as &$receipt ) {
			if ( isset( $receipt['key'] ) && 'ThirdPartyCoupon' === $receipt['key'] ) {
				$receipt['amount'] = round( (float) $order->get_total() * $mult, 2 );
				if ( 'ThirdPartyCoupon' === $payment['receipt_key'] ) {
					$receipt['attr'] = array( 'ID' => (int) $payment['coupon_type_id'], 'CouponType' => (int) $payment['coupon_type_id'], 'Count' => 1 );
				}
			}
		} unset( $receipt );
		$unresolved_customer_preview = 'manual' === $diagnostic && ! $cust;
		if ( $unresolved_customer_preview ) { unset( $payload['document']['customerId'] ); }
		if ( $invoice ) {
			// Guard third-party payload filters too: electronic receipts must not be
			// mistakenly sent as outgoing payments in v21 SaveInvoice.
			foreach ( isset( $payload['payments'] ) && is_array( $payload['payments'] ) ? $payload['payments'] : array() as $row ) {
				if ( is_array( $row ) && in_array( isset( $row['key'] ) ? $row['key'] : '', array( 'EReceipt', 'BankReceipt' ), true ) ) {
					return new WP_Error( 'rkw_invoice_outbound_payment', 'دریافت بانکی به اشتباه در payments قرار گرفته است؛ برای فاکتور فروش نسخه ۲۱ باید در receipts باشد. ارسال فاکتور متوقف شد.' );
				}
			}
			$valid = self::validate_invoice_payload( $payload, $unresolved_customer_preview );
			if ( is_wp_error( $valid ) ) { return self::stage_error( $valid, 'بررسی اطلاعات فاکتور قبل از ارسال' ); }
			$amount_check = RKW_Accounting::validate( $payload, $order, $s, $payment );
			if ( is_wp_error( $amount_check ) ) {
				$amount_summary = self::invoice_debug_summary( $payload, $amount_check );
				$amount_summary['woo_breakdown'] = self::order_amount_breakdown( $order, $s );
				RKW_Log::add( 'error', 'عیب‌یابی جمع فاکتور (بدون اطلاعات شخصی): ' . wp_json_encode( $amount_summary, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) );
				return self::stage_error( $amount_check, 'کنترل مبلغ دریافت قبل از SaveInvoice' );
			}
		}

		if ( ! $invoice ) {
			$valid = RKW_Accounting::validate( $payload, $order, $s, $payment );
			if ( is_wp_error( $valid ) ) { return $valid; }
		}
		if ( $diagnostic ) { return $payload; }
		if ( $invoice && ( $verify_coupon_discount || ( ! $client->uses_legacy_documents() && ! empty( $s['invoice_preflight'] ) ) ) ) {
			$document = $verify_coupon_discount ? RKW_Client::document_payload( $payload, $s )['document'] : $payload['document'];
			if ( $verify_coupon_discount ) { unset( $document['description'] ); }
			$calculated = $client->calculate_invoice21( $document );
			if ( is_wp_error( $calculated ) ) { return self::stage_error( $calculated, 'محاسبه مبلغ پیش از ثبت فاکتور' ); }
			$valid = RKW_Accounting::validate_calculated( $calculated, $payload, $order, $s );
			if ( $verify_coupon_discount && is_wp_error( $valid ) && 'rkw_server_total' === $valid->get_error_code() ) {
				$expected_total = round( ( $order->get_total() + (float) $order->get_meta( '_rkw_loyalty_credit_amount' ) ) * $mult, 2 );
				$exclusions = RKW_Accounting::snapp_policy_exclusions( $document, $calculated, $expected_total );
				if ( $exclusions ) {
					$candidate = $payload;
					foreach ( $exclusions as $i => $policy ) {
						$candidate['document']['items'][ $i ]['policies'][] = $policy;
					}
					$check_document = RKW_Client::document_payload( $candidate, $s )['document'];
					unset( $check_document['description'] );
					$checked = $client->calculate_invoice21( $check_document );
					if ( is_wp_error( $checked ) ) { return self::stage_error( $checked, 'بررسی مجدد تخفیف خودکار' ); }
					$verified = RKW_Accounting::validate_calculated( $checked, $candidate, $order, $s );
					$line_check = RKW_Accounting::snapp_line_check( $check_document, $checked );
					$explicit_price_check = null;
					if ( is_wp_error( $verified ) && 'rkw_server_total' === $verified->get_error_code() && $line_check['matched'] ) {
						// Supply the actual full-price line amount explicitly as well as the exclusions.
						$priced = $candidate;
						foreach ( $exclusions as $i => $policy ) {
							$priced['document']['items'][ $i ]['netPrice'] = $priced['document']['items'][ $i ]['price'];
						}
						$priced['document']['netPrice'] = $expected_total;
						$priced_document = RKW_Client::document_payload( $priced, $s )['document'];
						unset( $priced_document['description'] );
						$priced_calculation = $client->calculate_invoice21( $priced_document );
						$explicit_price_check = is_wp_error( $priced_calculation )
							? array( 'error_code' => $priced_calculation->get_error_code() )
							: array( 'returned_net' => is_numeric( $priced_calculation['netPrice'] ?? null ) && is_finite( (float) $priced_calculation['netPrice'] ) ? (float) $priced_calculation['netPrice'] : null );
						if ( ! is_wp_error( $priced_calculation ) ) {
							$priced_check = RKW_Accounting::snapp_line_check( $priced_document, $priced_calculation );
							$priced_valid = RKW_Accounting::validate_calculated( $priced_calculation, $priced, $order, $s );
							if ( ! is_wp_error( $priced_valid ) && $priced_check['matched'] && ! $priced_check['differences']
								&& ! RKW_Accounting::has_excluded_snapp_discount( $priced_calculation, $exclusions ) ) {
								$candidate = $priced;
								$check_document = $priced_document;
								$checked = $priced_calculation;
								$verified = true;
								$line_check = $priced_check;
							}
						}
					}
					$paid_price_check = null;
					if ( is_wp_error( $verified ) && 'rkw_server_total' === $verified->get_error_code()
						&& $line_check['matched'] ) {
						$paid_document = RKW_Accounting::snapp_paid_price_document( $candidate['document'] );
						if ( $paid_document ) {
							$paid = $candidate;
							$paid['document'] = $paid_document;
							$ledger = RKW_Accounting::validate( $paid, $order, $s, $payment );
							if ( ! is_wp_error( $ledger ) ) {
								$paid_wire = RKW_Client::document_payload( $paid, $s )['document'];
								unset( $paid_wire['description'] );
								$paid_result = $client->calculate_invoice21( $paid_wire );
								$paid_price_check = is_wp_error( $paid_result ) ? $paid_result->get_error_code() : 'خالص نامعتبر';
								if ( ! is_wp_error( $paid_result ) && is_numeric( $paid_result['netPrice'] ?? null )
									&& is_finite( (float) $paid_result['netPrice'] ) ) {
									$paid_price_check = (float) $paid_result['netPrice'];
								}
								if ( ! is_wp_error( $paid_result ) ) {
									$paid_valid = RKW_Accounting::validate_calculated( $paid_result, $paid, $order, $s );
									$paid_lines = RKW_Accounting::snapp_line_check( $paid_wire, $paid_result );
									if ( ! is_wp_error( $paid_valid ) && $paid_lines['matched'] && ! $paid_lines['differences']
										&& ! RKW_Accounting::has_excluded_snapp_discount( $paid_result, $paid_wire['items'] ) ) {
										$candidate = $paid;
										$verified = true;
										$line_check = $paid_lines;
									}
								}
							}
						}
					}
					if ( is_wp_error( $verified ) || ! $line_check['matched'] || $line_check['differences'] ) {
						$net = is_numeric( $checked['netPrice'] ?? null ) && is_finite( (float) $checked['netPrice'] ) ? (float) $checked['netPrice'] : null;
						$report = array(
							'expected_total' => $expected_total,
							'returned_net' => $net,
							'requested_exclusions' => array_values( array_map( static function ( $i ) use ( $check_document ) {
								return (int) $check_document['items'][ $i ]['productId'];
							}, array_keys( $exclusions ) ) ),
							'line_check' => $line_check,
							'explicit_price_check' => $explicit_price_check,
							'paid_price_check' => is_scalar( $paid_price_check ) ? $paid_price_check : null,
							'error_code' => is_wp_error( $verified ) ? $verified->get_error_code() : null,
						);
						RKW_Log::add( 'info', 'بررسی تخفیف 507 سفارش #' . (int) $order->get_id() . ' | ' . wp_json_encode( $report, JSON_UNESCAPED_UNICODE ) );
						$message = sprintf( 'پس از درخواست حذف تخفیف اضافه 507، خالص راهکاران %s و مبلغ سفارش %s است.', null === $net ? 'نامشخص' : $net, $expected_total );
						if ( ! $line_check['matched'] ) {
							$message .= ' ساختار ردیف‌های پاسخ با درخواست تطبیق نداشت.';
						}
						foreach ( array_slice( $line_check['differences'], 0, 5 ) as $difference ) {
							$message .= sprintf( ' کالای %d، خالص %s، مبلغ مورد انتظار %s%s.', $difference['product'], $difference['net'],
								$difference['expected'], $difference['applied_507'] ? '، تخفیف اعمال‌شده 507: ' . implode( ' + ', $difference['applied_507'] ) : '' );
						}
						if ( null !== $explicit_price_check ) {
							$message .= sprintf( ' محاسبه با مبلغ صریح نیز تأیید نشد (%s).', $explicit_price_check['returned_net'] ?? $explicit_price_check['error_code'] ?? 'خالص نامشخص' );
						}
						if ( is_scalar( $paid_price_check ) ) {
							$message .= sprintf( ' محاسبه با قیمت فروش نهایی نیز تأیید نشد (%s).', $paid_price_check );
						}
						if ( $allow_split && 'WC_Gateway_SnappPay' === $payment['gateway'] ) {
							return self::start_split_invoice( $order, $s, $client, $payload, $document, $calculated, $expected_total );
						}
						return new WP_Error( 'rkw_extra_auto_discount', $message . ' فاکتور ارسال نشد.' );
					}
					$payload = $candidate;
					$valid = true;
				}
			}
			if ( is_wp_error( $valid ) ) {
				if ( $verify_coupon_discount ) {
					$editability = array();
					foreach ( $document['items'] as $line_item ) {
						foreach ( $line_item['policies'] ?? array() as $policy ) {
							if ( (int) ( $policy['policyId'] ?? 0 ) !== (int) $s['item_discount_policy_id'] ) { continue; }
							$editable_fixed_amount = false;
							foreach ( $policy['outputs'] ?? array() as $output ) {
								$number = is_array( $output ) ? ( $output['numericValue'] ?? null ) : null;
								if ( is_array( $number ) && true === ( $number['canChangeValue'] ?? null )
									&& false === ( $number['isPercentageBased'] ?? null ) && true === ( $number['valueChanged'] ?? null )
									&& ( $number['value'] ?? null ) === $policy['price'] ) { $editable_fixed_amount = true; }
							}
							$editability[] = sprintf( '%d: %s', $line_item['productId'], $editable_fixed_amount ? 'ارسال شد' : 'در دسترس نبود' );
						}
					}
					if ( ! $editability ) { return $valid; }
					return new WP_Error( $valid->get_error_code(), $valid->get_error_message()
						. ' وضعیت فیلد مبلغ دستی سیاست برای کالاها: ' . implode( '، ', $editability ) );
				}
				return $valid;
			}
		}

		if ( $allow_split ) {
			return new WP_Error( 'rkw_split_not_needed', 'مغایرت قابل رفع با ثبت دو فاکتور پیدا نشد. اگر محاسبه یک فاکتور هم‌خوان است، از «ارسال به راهکاران» استفاده کنید.' );
		}
		$valid = $client->validate_document_coupon_types( $payload );
		if ( is_wp_error( $valid ) ) { return self::stage_error( $valid, 'اعتبارسنجی نوع بن در درخواست نهایی' ); }
		$context = $client->prepare_document_context();
		if ( is_wp_error( $context ) ) { return self::stage_error( $context, 'ورود به صندوق پیش از ثبت سند' ); }
		// Persist BEFORE the financial POST. A killed PHP process must not trigger a blind retry.
		$order->update_meta_data( '_rkw_reconcile_required', 1 );
		$order->save();
		$res = $invoice ? $client->save_invoice21( $payload ) : $client->save_sales_order21( $payload );
		if ( is_wp_error( $res ) ) {
			if ( $invoice ) {
				$summary = self::invoice_debug_summary( RKW_Client::document_payload( $payload, $s ), $res );
				$summary['order_id'] = (int) $order->get_id();
				$cashier = $client->login_status();
				$summary['cashier_before_document'] = array( 'required_by_contract' => $client->uses_legacy_documents(), 'prepared' => ! empty( $cashier['document_context_prepared'] ), 'accepted' => ! empty( $cashier['cashier_accepted'] ), 'legacy_empty_ack' => ! empty( $cashier['legacy_empty_ack'] ) );
				$shipping_route = self::order_amount_breakdown( $order, $s );
				if ( ! empty( $shipping_route['shipping_total'] ) ) {
					$shipping_route = RKW_Accounting::shipping_mapping( $order, RKW_Extensions::settings() );
					$summary['shipping_mapping_settings'] = is_wp_error( $shipping_route ) ? array( 'error_code' => $shipping_route->get_error_code() ) : $shipping_route;
				}
				$summary['financial_detail'] = RKW_Invoice_Diagnostics::wire_summary( RKW_Client::document_payload( $payload, $s ), $s['document_contract'] );
				$summary['sent_items_total'] = $summary['financial_detail']['item_base_total'];
				$summary['sent_items_total_basis'] = 'quantity_adjusted_before_line_policies';
				$summary['document_contract'] = $s['document_contract'];
				$summary['wc_gateway_id'] = isset( $payment['gateway'] ) ? (string) $payment['gateway'] : '';
				$summary['payment_mapping_source'] = isset( $payment['mapping_source'] ) ? (string) $payment['mapping_source'] : '';
				$summary['gateway_matching_rules'] = isset( $payment['matched_rules'] ) ? (int) $payment['matched_rules'] : 0;
				$summary['effective_policy_id'] = (int) $payment['settlement_id'];
				$summary['effective_receipt_key'] = (string) $payment['receipt_key'];
				$summary['coupon_type_existence_verified'] = ! empty( $summary['coupon_type_id_sent'] );
				$summary['effective_bank_ref'] = (int) $payment['bank_account_ref'];
				$summary['woo_order_total_in_rahkaran_units'] = round( (float) $order->get_total() * rkw_price_multiplier( $s ), 2 );
				$summary['note'] = 'sent_receipt_total is the amount in the outgoing request; if nonzero while the server reports received=0, investigate electronic receipt type and server-side receipt validation rather than changing invoice item amounts.';
				$summary['e_receipt_mode'] = isset( $payment['e_receipt_mode'] ) ? (string) $payment['e_receipt_mode'] : 'omit';
				$wire = RKW_Client::document_payload( $payload, $s );
				$effective_entries = ! empty( $wire['payments'] ) ? $wire['payments'] : ( isset( $wire['receipts'] ) ? $wire['receipts'] : array() );
				$summary['e_receipt_type_sent'] = isset( $effective_entries[0]['attr']['eReceiptType'] ) ? (string) $effective_entries[0]['attr']['eReceiptType'] : 'NOT_SENT';
				RKW_Log::add( 'error', 'جزئیات فنی درخواست ناموفق SaveInvoice (بدون اطلاعات شخصی): ' . wp_json_encode( $summary, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) );
			}
			if ( ! self::needs_reconciliation( $res ) ) { $order->delete_meta_data( '_rkw_reconcile_required' ); }
			return self::stage_error( $res, $invoice ? ( $client->uses_legacy_documents() && 'ThirdPartyCoupon' !== $payment['receipt_key'] ? 'ثبت فاکتور در راهکاران (ESales/invoice)' : 'ثبت فاکتور در راهکاران (SaveInvoice)' ) : 'ثبت سفارش در راهکاران (saveSalesOrder)' );
		}

		$doc_id = self::confirmed_document_id( $res );
		if ( ! $doc_id ) {
			// Never write the fabricated "OK" marker or retry blindly: server may have created a document.
			$order->update_meta_data( '_rkw_reconcile_required', 1 );
			return new WP_Error( 'rkw_invoice_unconfirmed', 'پاسخ ثبت سند شناسه معتبر نداشت. نتیجه نامشخص است؛ قبل از هر ارسال مجدد، راهکاران را با شماره سفارش بررسی کنید.' );
		}

		$order->update_meta_data( '_rkw_doc_id', (string) $doc_id );
		$order->update_meta_data( '_rkw_doc_type', $invoice ? 'invoice' : 'salesorder' );
		$order->delete_meta_data( '_rkw_error' );
		$order->delete_meta_data( '_rkw_reconcile_required' );
		$order->save();
		if ( $invoice ) { RKW_Snapshot::invalidate_section( 'invoices' ); }
		if ( $invoice && $order->get_user_id() ) { set_transient( 'rkw_first_' . (int) $order->get_user_id(), 'no', HOUR_IN_SECONDS ); }
		$order->add_order_note( 'ثبت در راهکاران: ' . ( $invoice ? 'فاکتور' : 'سفارش' ) . ' ' . $doc_id );
		RKW_Log::add( 'info', 'سفارش #' . $order->get_id() . ' در راهکاران ثبت شد (' . $doc_id . ')' );
		return true;
	}
}
