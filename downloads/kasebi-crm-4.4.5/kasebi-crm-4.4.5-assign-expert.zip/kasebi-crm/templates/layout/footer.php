<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
$DB              = new kcp_db();
$intros          = $DB->get_introduce_methods();
$action_types    = $DB->get_activity_types();
$track_titles    = $DB->track_title;
$track_type      = $DB->get_track_types();
$track_status    = $DB->get_track_status();
$call_statuses   = $DB->get_call_statuses();
$call_categories = $DB->get_call_categories();
$actions         = $DB->log_action;
$stocks          = $DB->stocks;
$types           = $DB->log_type;
$all_roles       = kcp_get_all_roles( FALSE );
$templates       = $DB->get_warning_templates();
$report_category = $DB->get_report_category();
$states          = WC()->countries->get_states( 'IR' );
$organs          = [
	'education'    => 'آموزش و پرورش',
	'oragh'        => 'اوراق گام',
	'admin'        => 'تأمین اجتماعی',
	'ab'           => 'اداره آب',
	'medical'      => 'علوم پزشکی',
	'armed_forces' => 'نیروهای مسلح',
	'other'        => 'سایر',
];
$user_groups     = get_option( 'kcp_user_groups', [] );
$user_types      = get_option( 'kcp_user_types', [] );
?>
<div class="nk-footer">
    <div class="container-xl wide-xl">
        <div class="nk-footer-wrap">
            <div class="nk-footer-copyright">طراحی و توسعه توسط <a href="https://kasebi.co/" target="_blank">کاسبی</a>
            </div>
            <div class="nk-footer-links english_number">
                Copyright 2017-<?php echo date( "Y" ); ?>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="addMarketer">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <a href="#" class="close" data-bs-dismiss="modal" aria-label="بستن">
                <em class="icon ni ni-cross-sm"></em>
            </a>
            <div class="modal-body modal-body-md">
                <h5 class="modal-title">افزودن کارشناس</h5>
                <form action="#" class="mt-2">
                    <div class="row g-gs">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="new_marketer_name">نام و نام خانوادگی</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="new_marketer_name"
                                           placeholder="به عنوان مثال، احمد گلچین">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="new_marketer_username">نام کاربری</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="new_marketer_username"
                                           placeholder="به عنوان مثال، ahmad_marketer">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="new_marketer_phone">شماره تماس</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="new_marketer_phone"
                                           placeholder="به عنوان مثال، 09123456789">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="new_marketer_role">نقش</label>
                                <div class="form-control-wrap">
                                    <select class="form-select" id="new_marketer_role">
										<?php
										foreach ( $all_roles as $role ) {
                                            if ( $role === 'phone_salesman' ) { continue; }
											$role_label = kcp_get_role_label( $role );
											?>
                                            <option value="<?php echo $role; ?>"><?php echo $role_label; ?></option>
											<?php
										}
										?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-group">
                                <div id="create_new_employee" class="btn btn-primary">ایجاد</div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer bg-light">
                <span class="sub-text text-end ">
                    نام مشتریی همان username جهت ورود می‌باشد.
                    <br>
                    رمز عبور به صورت پیشفرض 123456 می باشد. کارشناس می تواند پس از ورود این رمز را تغییر دهد.
                </span>
            </div>
        </div>
    </div>
</div>
<div class="modal fade zoom" id="addCustomer">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">افزودن مشتری</h5>
                <a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
            </div>
            <div class="modal-body">
                <form action="#">
                    <div class="row g-gs">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="new_customer_user_name">نام و نام خانوادگی</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="new_customer_user_name">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="new_customer_phone">شماره موبایل</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="new_customer_phone">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="new_customer_intro_id">نحوه آشنایی</label>
                                <div class="form-control-wrap">
                                    <select class="form-select js-select2" id="new_customer_intro_id">
                                        <option value="" selected disabled>انتخاب کنید</option>
										<?php
										foreach ( $intros as $key => $data ) {
											?>
                                            <option value="<?php echo $key; ?>"><?php echo $data['label']; ?></option>
											<?php
										}
										?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="new_customer_shop">نام فروشگاه</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="new_customer_shop">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="new_customer_type">تگ</label>
                                <div class="form-control-wrap">
                                    <select class="form-select js-select2" id="new_customer_type" multiple>
                                        <option value="" disabled>انتخاب کنید</option>
										<?php
										foreach ( $user_types as $key => $data ) {
											?>
                                            <option value="<?php echo $key; ?>"><?php echo $data['label']; ?></option>
											<?php
										}
										?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="new_customer_group">دسته</label>
                                <div class="form-control-wrap">
                                    <select class="form-select js-select2" id="new_customer_group" multiple>
                                        <option value="" disabled>انتخاب کنید</option>
										<?php
										foreach ( $user_groups as $key => $data ) {
											?>
                                            <option value="<?php echo $key; ?>"><?php echo $data['label']; ?></option>
											<?php
										}
										?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                <li>
                                    <div id="register_new_user" class="btn btn-primary">افزودن مشتری
                                    </div>
                                </li>
                                <li><a href="#" class="link link-light" data-bs-dismiss="modal">لغو</a></li>
                            </ul>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<div class="modal fade zoom" id="addCustomer_for_modal">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">افزودن مشتری</h5>
                <a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
            </div>
            <div class="modal-body">
                <form action="#">
                    <div class="row g-gs">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="new_customer_user_name_for_modal">نام و نام
                                    خانوادگی</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="new_customer_user_name_for_modal">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="new_customer_phone_for_modal">شماره موبایل</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="new_customer_phone_for_modal">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label class="form-label" for="new_customer_intro_id_for_modal">نحوه آشنایی</label>
                                <div class="form-control-wrap">
                                    <select class="form-select js-select2" id="new_customer_intro_id_for_modal">
                                        <option value="" selected disabled>انتخاب کنید</option>
										<?php
										foreach ( $intros as $key => $data ) {
											?>
                                            <option value="<?php echo $key; ?>"><?php echo $data['label']; ?></option>
											<?php
										}
										?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                <li>
                                    <div id="register_new_user_for_modal" class="btn btn-primary">افزودن مشتری
                                    </div>
                                </li>
                                <li><a href="#" class="link link-light" data-bs-dismiss="modal">لغو</a></li>
                                <input type="hidden" id="modal_to_open">
                            </ul>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<div class="modal fade zoom" id="addAction">
    <div class="modal-dialog modal-lg">
        <div class="modal-content modal_form"
             data-action="crm_add_user_activity">

            <div class="modal-header">
                <h5 class="modal-title">افزودن فعالیت</h5>
                <a href="#" class="close" data-bs-dismiss="modal">
                    <em class="icon ni ni-cross-sm"></em>
                </a>
            </div>

            <div class="modal-body">
                <form action="#">
                    <div class="row g-gs">

                        <input type="hidden"
                               data-for="tab"
                               value="action">
                        <input type="hidden"
                               id="new_action_id"
                               data-for="item_id">
                        <div class="col-md-6 hide_on_profile">
                            <div class="form-group card-title">
                                <label class="form-label">ثبت فعالیت برای:</label>
                                <div class="action_customer_box nk-tb-list">
                                    <span class="sub-text">برای انتخاب مشتری لطفا در فیلد روبرو جستجو کنید.</span>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6 hide_on_profile">
                            <div class="form-group card-title search_wrapper">
                                <label class="form-label" for="search_user_actions">جستجوی مشتری</label>
                                <div class="form-control-wrap">
                                    <div class="form-icon form-icon-left">
                                        <em class="icon ni ni-user"></em>
                                    </div>
                                    <input type="text"
                                           class="form-control search_user_modal"
                                           id="search_user_actions">
                                </div>

                                <p class="mt-1">جهت جستجوی مشتری شماره موبایل و یا نام مشتری را جستجو کنید.</p>

                                <div class="customer_search_result"
                                     data-input="#new_action_customer_id"
                                     data-preview=".action_customer_box"></div>
                            </div>
                        </div>

                        <input type="hidden"
                               id="new_action_customer_id"
                               data-for="id"
                               data-req="1">

                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="new_action_title">عنوان فعالیت</label>
                                <div class="form-control-wrap">
                                    <input type="text"
                                           class="form-control"
                                           id="new_action_title"
                                           data-for="title"
                                           data-req="1">
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="new_action_type">نوع فعالیت</label>
                                <div class="form-control-wrap">
                                    <select class="form-select js-select2"
                                            id="new_action_type"
                                            data-for="type"
                                            data-req="1">
										<?php
										foreach ( $action_types as $status => $data ) {
											?>
                                            <option value="<?php echo esc_attr( $status ); ?>">
												<?php echo esc_html( $data['label'] ); ?>
                                            </option>
											<?php
										}
										?>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label">توضیحات</label>
                                <div class="form-control-wrap">
                                    <div class="quill-basic"
                                         data-name="new_action_text"
                                         data-for="content"
                                         data-req="1"></div>
                                </div>
                            </div>
                        </div>

                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label" for="new_action_file">فایل ضمیمه</label>

                                <div class="upload-zone"
                                     data-target="#new_action_file"
                                     data-action="crm_handle_file_upload"
                                     data-max-files="10">
                                    <div class="dz-message" data-dz-message>
                                        <span class="dz-message-text">بکشید و رها کنید</span>
                                        <span class="dz-message-or">یا</span>
                                        <div class="btn btn-primary">انتخاب کنید</div>
                                    </div>
                                </div>

                                <input type="hidden"
                                       id="new_action_file"
                                       data-for="file">
                            </div>
                        </div>

                        <div class="col-12">
                            <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                <li>
                                    <button type="button"
                                            class="btn btn-primary submit_modal_form"
                                            data-bs-dismiss="modal">
                                        ثبت فعالیت
                                    </button>
                                </li>
                                <li>
                                    <a href="#" class="link link-light" data-bs-dismiss="modal">لغو</a>
                                </li>
                            </ul>
                        </div>

                    </div>
                </form>
            </div>

        </div>
    </div>
</div>
<div class="modal fade zoom" id="addTrack">
    <div class="modal-dialog modal-lg">
        <div class="modal-content modal_form"
             data-action="crm_add_user_track">
            <div class="modal-header">
                <h5 class="modal-title">افزودن پیگیری</h5>
                <a href="#" class="close" data-bs-dismiss="modal">
                    <em class="icon ni ni-cross-sm"></em>
                </a>
            </div>

            <div class="modal-body">
                <form action="#">
                    <div class="row g-gs">

                        <input type="hidden"
                               data-for="tab"
                               value="track">

                        <div class="col-md-6 hide_on_profile">
                            <div class="form-group card-title">
                                <label class="form-label">ثبت پیگیری برای:</label>
                                <div class="track_customer_box nk-tb-list">
                                    <span class="sub-text">برای انتخاب مشتری لطفا در فیلد روبرو جستجو کنید.</span>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6 hide_on_profile">
                            <div class="form-group card-title search_wrapper">
                                <label class="form-label" for="search_user_tracks">جستجوی مشتری</label>
                                <div class="form-control-wrap">
                                    <div class="form-icon form-icon-left">
                                        <em class="icon ni ni-user"></em>
                                    </div>
                                    <input type="text"
                                           class="form-control search_user_modal"
                                           id="search_user_tracks">
                                </div>

                                <p class="mt-1">جهت جستجوی مشتری شماره موبایل و یا نام مشتری را جستجو کنید.</p>

                                <div class="customer_search_result"
                                     data-input="#new_track_customer_id"
                                     data-preview=".track_customer_box"></div>
                            </div>
                        </div>

                        <input type="hidden"
                               id="new_track_customer_id"
                               data-for="id"
                               data-req="1">

                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="new_track_title">عنوان پیگیری</label>
                                <div class="form-control-wrap">
                                    <select class="form-select js-select2"
                                            id="new_track_title"
                                            data-for="title"
                                            data-req="1">
										<?php
										foreach ( $track_titles as $status => $label ) {
											?>
                                            <option value="<?php echo esc_attr( $status ); ?>">
												<?php echo esc_html( $label ); ?>
                                            </option>
											<?php
										}
										?>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="new_track_type">نوع پیگیری</label>
                                <div class="form-control-wrap">
                                    <select class="form-select js-select2"
                                            id="new_track_type"
                                            data-for="type">
										<?php
										foreach ( $track_type as $status => $data ) {
											?>
                                            <option value="<?php echo esc_attr( $status ); ?>">
												<?php echo esc_html( $data['label'] ); ?>
                                            </option>
											<?php
										}
										?>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="new_track_date">تاریخ پیگیری</label>
                                <div class="form-control-wrap">
                                    <div class="form-icon form-icon-right">
                                        <em class="icon ni ni-calendar"></em>
                                    </div>
                                    <input type="text"
                                           class="form-control datepicker"
                                           id="new_track_date"
                                           placeholder="روز/ماه/سال"
                                           data-for="date"
                                           data-req="1">
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="new_track_hour">ساعت پیگیری</label>
                                <div class="form-control-wrap">
                                    <div class="form-icon form-icon-right">
                                        <em class="icon ni ni-clock"></em>
                                    </div>
                                    <input type="text"
                                           class="form-control time-picker"
                                           id="new_track_hour"
                                           data-time-format="HH:mm"
                                           data-time-minTime="8"
                                           data-time-maxTime="19"
                                           data-for="hour"
                                           data-req="1">
                                </div>
                            </div>
                        </div>

                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label">توضیحات</label>
                                <div class="form-control-wrap">
                                    <div class="quill-basic"
                                         data-name="new_track_text"
                                         data-for="content"
                                         data-req="1"></div>
                                </div>
                            </div>
                        </div>

                        <div class="col-12">
                            <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                <li>
                                    <button type="button"
                                            class="btn btn-primary submit_modal_form"
                                            data-bs-dismiss="modal">
                                        ثبت پیگیری
                                    </button>
                                </li>
                                <li>
                                    <a href="#" class="link link-light" data-bs-dismiss="modal">لغو</a>
                                </li>
                            </ul>
                        </div>

                    </div>
                </form>
            </div>

        </div>
    </div>
</div>
<div class="modal fade zoom" id="addVisit">
    <div class="modal-dialog modal-lg">
        <div class="modal-content modal_form"
             data-action="crm_add_user_visit">

            <div class="modal-header">
                <h5 class="modal-title">افزودن ویزیت</h5>
                <a href="#" class="close" data-bs-dismiss="modal">
                    <em class="icon ni ni-cross-sm"></em>
                </a>
            </div>

            <div class="modal-body">
                <form action="#">
                    <div class="row g-gs">

                        <div class="col-md-6 hide_on_profile">
                            <div class="form-group card-title">
                                <label class="form-label">ثبت ویزیت برای:</label>
                                <div class="visit_customer_box nk-tb-list">
                                    <span class="sub-text">برای انتخاب مشتری لطفا در فیلد روبرو جستجو کنید.</span>
                                    <span class="sub-text">
                                        میتوانید بدون انتخاب مشتری ویزیت را به صورت ناشناس آغاز کنید.
                                    </span>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6 hide_on_profile">
                            <div class="form-group card-title search_wrapper">
                                <label class="form-label" for="search_user_visits">جستجوی مشتری</label>
                                <div class="form-control-wrap">
                                    <div class="form-icon form-icon-left">
                                        <em class="icon ni ni-user"></em>
                                    </div>
                                    <input type="text"
                                           class="form-control search_user_modal"
                                           id="search_user_visits">
                                </div>

                                <p class="mt-1">جهت جستجوی مشتری شماره موبایل و یا نام مشتری را جستجو کنید.</p>

                                <div class="customer_search_result"
                                     data-input="#new_visit_customer_id"
                                     data-preview=".visit_customer_box"></div>
                            </div>
                        </div>

                        <input type="hidden"
                               id="new_visit_customer_id"
                               data-for="user_id">

                        <div class="col-12">
                            <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                <li>
                                    <button type="button"
                                            class="btn btn-primary submit_modal_form"
                                            data-bs-dismiss="modal">
                                        آغاز ویزیت
                                    </button>
                                </li>
                                <li>
                                    <a href="#" class="link link-light" data-bs-dismiss="modal">لغو</a>
                                </li>
                            </ul>
                        </div>

                    </div>
                </form>
            </div>

        </div>
    </div>
</div>
<div class="modal fade zoom" id="changeTrackStatus">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content modal_form"
             data-action="crm_check_user_track"
             data-page="users-track">

            <div class="modal-header">
                <h5 class="modal-title">تغییر وضعیت پیگیری</h5>
                <a href="#" class="close" data-bs-dismiss="modal">
                    <em class="icon ni ni-cross-sm"></em>
                </a>
            </div>

            <div class="modal-body">
                <form action="#">
                    <div class="row g-gs">

                        <input type="hidden"
                               data-for="tab"
                               value="track">

                        <input type="hidden"
                               data-for="id"
                               value="<?php echo esc_attr( $user_id ?? get_current_user_id() ); ?>">

                        <input type="hidden"
                               id="change_track_status_id"
                               data-for="item_id"
                               data-req="1">

                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="track_check_status">نتیجه پیگیری</label>
                                <div class="form-control-wrap">
                                    <select class="form-select js-select2"
                                            id="track_check_status"
                                            data-for="status"
                                            data-req="1">
										<?php
										unset( $track_status['pending'] );
										
										foreach ( $track_status as $status => $data ) {
											?>
                                            <option value="<?php echo esc_attr( $status ); ?>">
												<?php echo esc_html( $data['label'] ); ?>
                                            </option>
											<?php
										}
										?>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label">توضیحات انجام پیگیری</label>
                                <div class="form-control-wrap">
                                    <div class="quill-basic"
                                         data-name="track_check_result"
                                         data-for="result"></div>
                                </div>
                            </div>
                        </div>

                        <div class="col-12">
                            <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                <li>
                                    <button type="button"
                                            class="btn btn-primary submit_modal_form"
                                            data-bs-dismiss="modal">
                                        تغییر وضعیت
                                    </button>
                                </li>
                                <li>
                                    <a href="#" class="link link-light" data-bs-dismiss="modal">لغو</a>
                                </li>
                            </ul>
                        </div>

                    </div>
                </form>
            </div>

        </div>
    </div>
</div>
<div class="modal fade zoom" id="changeVisitStatus">
    <div class="modal-dialog modal-lg">
        <div class="modal-content modal_form"
             data-action="crm_change_visit_status"
             data-page="users-visit">

            <div class="modal-header">
                <h5 class="modal-title">تغییر وضعیت ویزیت</h5>
                <a href="#" class="close" data-bs-dismiss="modal">
                    <em class="icon ni ni-cross-sm"></em>
                </a>
            </div>

            <div class="modal-body">
                <form action="#">
                    <div class="row g-gs">

                        <input type="hidden"
                               data-for="tab"
                               value="visit">

                        <div class="col-md-6 hide_on_profile">
                            <div class="form-group card-title">
                                <label class="form-label">ثبت ویزیت برای:</label>
                                <div class="change_visit_customer_box nk-tb-list">
                                    <span class="sub-text">برای انتخاب مشتری لطفا در فیلد روبرو جستجو کنید.</span>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6 hide_on_profile">
                            <div class="form-group card-title search_wrapper">
                                <label class="form-label" for="search_user_change_visits">جستجوی مشتری</label>
                                <div class="form-control-wrap">
                                    <div class="form-icon form-icon-left">
                                        <em class="icon ni ni-user"></em>
                                    </div>
                                    <input type="text"
                                           class="form-control search_user_modal"
                                           id="search_user_change_visits">
                                </div>

                                <p class="mt-1">جهت جستجوی مشتری شماره موبایل و یا نام مشتری را جستجو کنید.</p>

                                <div class="customer_search_result"
                                     data-input="#change_visit_status_user_id"
                                     data-preview=".change_visit_customer_box"></div>
                            </div>
                        </div>

                        <input type="hidden"
                               id="change_visit_status_id"
                               data-for="item_id"
                               data-req="1">

                        <input type="hidden"
                               id="change_visit_status_input"
                               data-for="change_status"
                               data-req="1">

                        <input type="hidden"
                               id="change_visit_status_user_id"
                               data-for="id"
                               data-req="1">

                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label">توضیحات</label>
                                <div class="form-control-wrap">
                                    <div class="quill-basic"
                                         data-name="change_visit_status_detail"
                                         data-for="desc"
                                         data-req="1"></div>
                                </div>
                            </div>
                        </div>

                        <div class="col-12">
                            <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                <li>
                                    <button type="button"
                                            class="btn btn-primary submit_modal_form"
                                            data-bs-dismiss="modal">
                                        ثبت
                                    </button>
                                </li>
                                <li>
                                    <a href="#" class="link link-light" data-bs-dismiss="modal">لغو</a>
                                </li>
                            </ul>
                        </div>

                    </div>
                </form>
            </div>

        </div>
    </div>
</div>
<div class="modal fade zoom" id="addCall">
    <div class="modal-dialog modal-lg">
        <div class="modal-content modal_form"
             data-action="crm_add_user_call"
             data-page="users-call">

            <div class="modal-header">
                <h5 class="modal-title">افزودن درخواست مشتری</h5>
                <a href="#" class="close" data-bs-dismiss="modal">
                    <em class="icon ni ni-cross-sm"></em>
                </a>
            </div>

            <div class="modal-body">
                <form action="#">
                    <div class="row g-gs">

                        <input type="hidden"
                               data-for="tab"
                               value="call">

                        <div class="col-md-6 hide_on_profile">
                            <div class="form-group card-title">
                                <label class="form-label">ثبت درخواست برای:</label>
                                <div class="add_call_user_box nk-tb-list">
                                    <span class="sub-text">برای انتخاب مشتری لطفا در فیلد روبرو جستجو کنید.</span>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6 hide_on_profile">
                            <div class="form-group card-title search_wrapper">
                                <label class="form-label" for="search_user_calls">جستجوی مشتری</label>
                                <div class="form-control-wrap">
                                    <div class="form-icon form-icon-left">
                                        <em class="icon ni ni-user"></em>
                                    </div>
                                    <input type="text"
                                           class="form-control search_user_modal"
                                           id="search_user_calls">
                                </div>

                                <p class="mt-1">جهت جستجوی مشتری شماره موبایل و یا نام مشتری را جستجو کنید.</p>

                                <div class="customer_search_result"
                                     data-input="#add_call_user_id"
                                     data-preview=".add_call_user_box"></div>
                            </div>
                        </div>

                        <input type="hidden"
                               id="add_call_user_id"
                               data-for="id"
                               data-req="1">

                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="new_user_call_category">واحد مربوطه</label>
                                <div class="form-control-wrap">
                                    <select class="form-select js-select2"
                                            id="new_user_call_category"
                                            data-for="category"
                                            data-req="1">
										<?php
										foreach ( $call_categories as $slug => $data ) {
											?>
                                            <option value="<?php echo esc_attr( $slug ); ?>">
												<?php echo esc_html( $data['label'] ); ?>
                                            </option>
											<?php
										}
										?>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="new_user_call_assign">مسئول پیگیری</label>
                                <div class="form-control-wrap">
                                    <select class="form-select js-select2"
                                            id="new_user_call_assign"
                                            data-for="assign"
                                            data-req="1">
                                        <option value="0">جهت مشاهده کارمندان واحد را انتخاب کنید</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label">توضیحات</label>
                                <div class="form-control-wrap">
                                    <div class="quill-basic"
                                         data-name="new_user_call_content"
                                         data-for="content"
                                         data-req="1"></div>
                                </div>
                            </div>
                        </div>

                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label" for="new_user_call_file">فایل ضمیمه</label>

                                <div class="upload-zone"
                                     data-target="#new_user_call_file"
                                     data-action="crm_handle_file_upload"
                                     data-max-files="10">
                                    <div class="dz-message" data-dz-message>
                                        <span class="dz-message-text">بکشید و رها کنید</span>
                                        <span class="dz-message-or">یا</span>
                                        <div class="btn btn-primary">انتخاب کنید</div>
                                    </div>
                                </div>

                                <input type="hidden"
                                       id="new_user_call_file"
                                       data-for="attachment">
                            </div>
                        </div>

                        <div class="col-12">
                            <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                <li>
                                    <button type="button"
                                            class="btn btn-primary submit_modal_form"
                                            data-bs-dismiss="modal">
                                        ثبت
                                    </button>
                                </li>
                                <li>
                                    <a href="#" class="link link-light" data-bs-dismiss="modal">لغو</a>
                                </li>
                            </ul>
                        </div>

                    </div>
                </form>
            </div>

        </div>
    </div>
</div>
<div class="modal fade zoom" id="addHRCall">
    <div class="modal-dialog modal-lg">
        <div class="modal-content modal_form"
             data-action="crm_add_hr_call"
             data-page="crm/hr-requests">

            <div class="modal-header">
                <h5 class="modal-title">افزودن درخواست سازمانی</h5>
                <a href="#" class="close" data-bs-dismiss="modal">
                    <em class="icon ni ni-cross-sm"></em>
                </a>
            </div>

            <div class="modal-body">
                <form action="#">
                    <div class="row g-gs">

                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="new_hr_call_category">واحد مربوطه</label>
                                <div class="form-control-wrap">
                                    <select class="form-select js-select2"
                                            id="new_hr_call_category"
                                            data-for="category"
                                            data-req="1">
                                        <option value="">انتخاب کنید</option>
										<?php
										foreach ( $call_categories as $slug => $data ) {
											?>
                                            <option value="<?php echo esc_attr( $slug ); ?>">
												<?php echo esc_html( $data['label'] ); ?>
                                            </option>
											<?php
										}
										?>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="new_hr_call_assign">مخاطب درخواست</label>
                                <div class="form-control-wrap">
                                    <select class="form-select js-select2"
                                            id="new_hr_call_assign"
                                            data-for="assign"
                                            data-req="1">
                                        <option value="">جهت مشاهده کارمندان واحد را انتخاب کنید</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label">توضیحات</label>
                                <div class="form-control-wrap">
                                    <div class="quill-basic"
                                         data-name="new_hr_call_content"
                                         data-for="content"
                                         data-req="1"></div>
                                </div>
                            </div>
                        </div>

                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label" for="new_hr_call_file">فایل ضمیمه</label>

                                <div class="upload-zone"
                                     data-target="#new_hr_call_file"
                                     data-action="crm_handle_file_upload"
                                     data-max-files="10">
                                    <div class="dz-message" data-dz-message>
                                        <span class="dz-message-text">بکشید و رها کنید</span>
                                        <span class="dz-message-or">یا</span>
                                        <div class="btn btn-primary">انتخاب کنید</div>
                                    </div>
                                </div>

                                <input type="hidden"
                                       id="new_hr_call_file"
                                       data-for="attachment">
                            </div>
                        </div>

                        <div class="col-12">
                            <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                <li>
                                    <button type="button"
                                            class="btn btn-primary submit_modal_form"
                                            data-bs-dismiss="modal">
                                        ثبت
                                    </button>
                                </li>
                                <li>
                                    <a href="#" class="link link-light" data-bs-dismiss="modal">لغو</a>
                                </li>
                            </ul>
                        </div>

                    </div>
                </form>
            </div>

        </div>
    </div>
</div>
<div class="modal fade zoom" id="changeCallStatus">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content modal_form"
             data-action="crm_add_call_progress"
             data-page="users-call">

            <div class="modal-header">
                <h5 class="modal-title">تغییر وضعیت درخواست</h5>
                <a href="#" class="close" data-bs-dismiss="modal">
                    <em class="icon ni ni-cross-sm"></em>
                </a>
            </div>

            <div class="modal-body">
                <form action="#">
                    <div class="row g-gs">

                        <input type="hidden"
                               data-for="tab"
                               value="call">

                        <input type="hidden"
                               data-for="id"
                               value="<?php echo esc_attr( $user_id ?? 0 ); ?>">

                        <input type="hidden"
                               id="change_call_status_id"
                               data-for="call_id"
                               data-req="1">

                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="change_call_new_status">وضعیت جدید</label>
                                <div class="form-control-wrap">
                                    <select class="form-select js-select2"
                                            id="change_call_new_status"
                                            data-for="new_status"
                                            data-req="1">
										<?php
										$change_call_statuses = $call_statuses;
										unset( $change_call_statuses['new'] );
										
										foreach ( $change_call_statuses as $slug => $data ) {
											?>
                                            <option value="<?php echo esc_attr( $slug ); ?>">
												<?php echo esc_html( $data['label'] ); ?>
                                            </option>
											<?php
										}
										?>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6"></div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="change_call_new_category">ارجاع به واحد</label>
                                <div class="form-control-wrap">
                                    <select class="form-select js-select2"
                                            id="change_call_new_category"
                                            data-for="new_category">
                                        <option value="0">بدون تغییر</option>
										<?php
										foreach ( $call_categories as $slug => $data ) {
											?>
                                            <option value="<?php echo esc_attr( $slug ); ?>">
												<?php echo esc_html( $data['label'] ); ?>
                                            </option>
											<?php
										}
										?>
                                    </select>
                                </div>
                                <span class="sub-text">این بخش می تواند خالی بماند و تغییری نکند.</span>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="change_call_status_assign">مسئول پیگیری</label>
                                <div class="form-control-wrap">
                                    <select class="form-select js-select2"
                                            id="change_call_status_assign"
                                            data-for="assigned">
                                        <option value="0">جهت مشاهده کارمندان واحد را انتخاب کنید</option>
                                    </select>
                                </div>
                                <span class="sub-text">این بخش می تواند خالی بماند و تغییری نکند.</span>
                            </div>
                        </div>

                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label">توضیحات</label>
                                <div class="form-control-wrap">
                                    <div class="quill-basic"
                                         data-name="change_call_status_detail"
                                         data-for="content"
                                         data-req="1"></div>
                                </div>
                            </div>
                        </div>

                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label" for="user_call_progress_file">فایل ضمیمه</label>

                                <div class="upload-zone"
                                     data-target="#user_call_progress_file"
                                     data-action="crm_handle_file_upload"
                                     data-max-files="10">
                                    <div class="dz-message" data-dz-message>
                                        <span class="dz-message-text">بکشید و رها کنید</span>
                                        <span class="dz-message-or">یا</span>
                                        <div class="btn btn-primary">انتخاب کنید</div>
                                    </div>
                                </div>

                                <input type="hidden"
                                       id="user_call_progress_file"
                                       data-for="attachment">
                            </div>
                        </div>

                        <div class="col-12">
                            <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                <li>
                                    <button type="button"
                                            class="btn btn-primary submit_modal_form"
                                            data-bs-dismiss="modal">
                                        تغییر وضعیت
                                    </button>
                                </li>
                                <li>
                                    <a href="#" class="link link-light" data-bs-dismiss="modal">لغو</a>
                                </li>
                            </ul>
                        </div>

                    </div>
                </form>
            </div>

        </div>
    </div>
</div>
<div class="modal fade zoom" id="addWarningTemplate">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">تنظیم الگو</h5>
                <a href="#" class="close" data-bs-dismiss="modal"
                   aria-label="بستن">
                    <em class="icon ni ni-cross"></em>
                </a>
            </div>
            <div class="modal-body modal-body-md">
                <form action="#" class="mt-2">
                    <div class="row g-gs">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label overline-title-alt"
                                       for="warning_template_title">عنوان</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="warning_template_title">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label overline-title-alt"
                                       for="warning_template_template">نام الگو</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="warning_template_template">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label class="form-label overline-title-alt"
                                       for="warning_template_token1">متغیر اول</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="warning_template_token1">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label class="form-label overline-title-alt"
                                       for="warning_template_token2">متغیر دوم</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="warning_template_token2">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label class="form-label overline-title-alt"
                                       for="warning_template_token3">متغیر سوم</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="warning_template_token3">
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                <li>
                                    <div id="add_warning_template" class="btn btn-primary"
                                         data-bs-dismiss="modal">ثبت
                                    </div>
                                    <input type="hidden" id="warning_template_id">
                                </li>
                                <li>
                                    <a href="#" class="link link-light" data-bs-dismiss="modal">لغو</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer bg-light">
                <span class="sub-text text-end ">
                    الگوی پیامک اخطار بایستی در پنل کاوه نگار شما ثبت شده باشد.
                    <br>
                    در بخش متغیر ها میتوانید از مقادیر first_name, last_name, phone, date استفاده کنید.
                </span>
            </div>
        </div>
    </div>
</div>
<div class="modal fade zoom" id="sendWarning">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">تنظیم الگو</h5>
                <a href="#" class="close" data-bs-dismiss="modal"
                   aria-label="بستن">
                    <em class="icon ni ni-cross"></em>
                </a>
            </div>
            <div class="modal-body modal-body-md">
                <form action="#" class="mt-2">
                    <div class="row g-gs">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="send_warning_template_id">انتخاب اخطاریه</label>
                                <div class="form-control-wrap">
                                    <select class="form-select js-select2" id="send_warning_template_id">
										<?php
										foreach ( $templates as $template ) {
											extract( $template );
											?>
                                            <option value="<?php echo $id; ?>"><?php echo $title; ?></option>
											<?php
										}
										?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                <li>
                                    <div id="send_warning_template" class="btn btn-primary"
                                         data-bs-dismiss="modal">ثبت
                                    </div>
                                    <input type="hidden" id="send_warning_to_user">
                                </li>
                                <li>
                                    <a href="#" class="link link-light" data-bs-dismiss="modal">لغو</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer bg-light">
                <span class="sub-text text-end ">
                    الگوی پیامک اخطار بایستی در پنل کاوه نگار شما ثبت شده باشد.
                    <br>
                    در بخش متغیر ها میتوانید از مقادیر first_name, last_name, phone, date استفاده کنید.
                </span>
            </div>
        </div>
    </div>
</div>

<div class="modal fade zoom" id="addEmployeeReport">
    <div class="modal-dialog modal-lg">
        <div class="modal-content modal_form"
             data-action="crm_add_employee_report"
             data-page="/crm/hr-reports">

            <div class="modal-header">
                <h5 class="modal-title">ثبت گزارش</h5>
                <a href="#" class="close" data-bs-dismiss="modal">
                    <em class="icon ni ni-cross-sm"></em>
                </a>
            </div>

            <div class="modal-body">
                <form action="#">
                    <div class="row g-gs">

                        <input type="hidden"
                               id="new_report_id"
                               data-for="report_id"
                               value="">

                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="new_report_title">عنوان گزارش</label>
                                <div class="form-control-wrap">
                                    <input type="text"
                                           class="form-control"
                                           id="new_report_title"
                                           data-for="title"
                                           data-req="1">
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="new_report_category">نوع گزارش</label>
                                <div class="form-control-wrap">
                                    <select class="form-select js-select2"
                                            id="new_report_category"
                                            data-for="new_category"
                                            data-req="1">
                                        <option value="">انتخاب کنید</option>
										<?php
										foreach ( $report_category as $category => $data ) {
											?>
                                            <option value="<?php echo esc_attr( $category ); ?>">
												<?php echo esc_html( $data['label'] ); ?>
                                            </option>
											<?php
										}
										?>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label">توضیحات</label>
                                <div class="form-control-wrap">
                                    <div class="quill-basic"
                                         data-name="new_report_content"
                                         data-for="content"
                                         data-req="1"></div>
                                </div>
                            </div>
                        </div>

                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label" for="new_report_file">فایل ضمیمه</label>

                                <div class="upload-zone"
                                     data-target="#new_report_file"
                                     data-action="crm_handle_file_upload"
                                     data-max-files="10">
                                    <div class="dz-message" data-dz-message>
                                        <span class="dz-message-text">بکشید و رها کنید</span>
                                        <span class="dz-message-or">یا</span>
                                        <div class="btn btn-primary">انتخاب کنید</div>
                                    </div>
                                </div>

                                <input type="hidden"
                                       id="new_report_file"
                                       data-for="attachment"
                                       value="">
                            </div>
                        </div>

                        <div class="col-12">
                            <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                <li>
                                    <button type="button"
                                            class="btn btn-primary submit_modal_form"
                                            data-bs-dismiss="modal">
                                        ثبت گزارش
                                    </button>
                                </li>
                                <li>
                                    <a href="#" class="link link-light" data-bs-dismiss="modal">لغو</a>
                                </li>
                            </ul>
                        </div>

                    </div>
                </form>
            </div>

        </div>
    </div>
</div>
<div class="modal fade" id="addUserAddress">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">افزودن آدرس</h5>
                <a href="#" class="close" data-bs-dismiss="modal" aria-label="بستن">
                    <em class="icon ni ni-cross"></em>
                </a>
            </div>
            <div class="modal-body modal-body-md">
                <form action="#">
                    <div class="row g-gs">
                        <div class="custom-control custom-control-sm custom-switch checked address_for_main_customer">
                            <input type="checkbox" class="custom-control-input" id="address_for_main_customer"
                                   value="1">
                            <label class="custom-control-label" for="address_for_main_customer">گیرنده همان مشتری
                                هست</label>
                        </div>
                        <div class="col-md-6 hide_for_customer">
                            <div class="form-group">
                                <label class="form-label" for="address_first_name">نام</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="address_first_name"
                                           placeholder="به عنوان مثال، احمد">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 hide_for_customer">
                            <div class="form-group">
                                <label class="form-label" for="address_last_name">نام خانوادگی</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="address_last_name"
                                           placeholder="به عنوان مثال، گلچین">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 hide_for_customer">
                            <div class="form-group">
                                <label class="form-label" for="address_phone">شماره موبایل</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="address_phone"
                                           placeholder="به عنوان مثال، 09123456789">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="address_postcode">کد پستی</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="address_postcode"
                                           placeholder="به عنوان مثال، 12345-67890">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <div class="form-control-wrap">
                                    <label class="form-label" for="address_state">استان</label>
                                    <select
                                        class="form-select js-select2 js-select2-sm select2-hidden-accessible load_city"
                                        id="address_state" data-target="#address_city">
                                        <option value="0">انتخاب کنید</option>
										<?php
										foreach ( $states as $state => $label ) {
											?>
                                            <option value="<?= $state ?>"><?= $label ?></option>
											<?php
										}
										?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="address_city">شهر</label>
                                <div class="form-control-wrap">
                                    <select class="form-select js-select2 js-select2-sm select2-hidden-accessible"
                                            id="address_city">
                                        <option value="0">ابتدا استان را انتخاب کنید</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label class="form-label" for="address_address">آدرس</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="address_address"
                                           placeholder="به عنوان مثال، خیابان شریعتی - مدرس 22">
                                </div>
                            </div>
                        </div>
                        <input type="hidden" id="save_address_key" value="false">
                        <input type="hidden" id="save_address_user_id" value="">
                        <div class="col-12">
                            <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                <li>
                                    <div id="save_address_form" class="btn btn-primary"
                                         data-bs-dismiss="modal">ثبت آدرس
                                    </div>
                                </li>
                                <li>
                                    <a href="#" class="link link-light" data-bs-dismiss="modal">لغو</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<div class="modal fade zoom" id="addCashPayment">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">افزودن پرداخت نقدی</h5>
                <a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
            </div>
            <div class="modal-body">
                <form action="#">
                    <div class="row g-gs">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="new_cash_payment_row_price">مبلغ واریز</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control price_input" id="new_cash_payment_row_price">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="new_cash_payment_row_bank">نزد بانک </label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="new_cash_payment_row_bank">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="new_cash_payment_row_date">تاریخ پرداخت</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control datepicker" id="new_cash_payment_row_date">
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                <li>
                                    <div id="submit_cash_payment" class="btn btn-primary"
                                         data-bs-dismiss="modal">ثبت پرداخت
                                    </div>
                                </li>
                                <li>
                                    <a href="#" class="link link-light" data-bs-dismiss="modal">لغو</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<div class="modal fade zoom" id="orderItemsTable">
    <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">آیتم های سفارش</h5>
                <a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
            </div>
            <div class="bg-white modal-body">
            </div>
        </div>
    </div>
</div>
<div class="modal fade zoom" id="orderChequeTable">
    <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">چک های ثبت شده سفارش</h5>
                <a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
            </div>
            <div class="bg-white modal-body">
            </div>
        </div>
    </div>
</div>
<div class="modal fade zoom" id="orderCashTable">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">اطلاعات پرداخت نقدی سفارش</h5>
                <a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
            </div>
            <div class="bg-white modal-body">
            </div>
        </div>
    </div>
</div>
<div class="modal fade zoom" id="orderInstallmentTable">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">اطلاعات پرداخت قسطی سفارش</h5>
                <a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
            </div>
            <div class="bg-white modal-body">
            </div>
        </div>
    </div>
</div>
<div class="modal fade zoom" id="addCashPaymentForOrder">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">افزودن پرداخت نقدی</h5>
                <a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
            </div>
            <div class="modal-body">
                <form action="#">
                    <div class="row g-gs">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="new_cash_payment_price_for_order">مبلغ واریز</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control price_input"
                                           id="new_cash_payment_price_for_order">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="new_cash_payment_row_bank_for_order">نزد بانک </label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="new_cash_payment_row_bank_for_order">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="new_cash_payment_row_date_for_order">تاریخ پرداخت</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control datepicker"
                                           id="new_cash_payment_row_date_for_order">
                                </div>
                            </div>
                        </div>
                        <input type="hidden" id="cash_payment_order_id">
                        <div class="col-12">
                            <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                <li>
                                    <div id="submit_cash_payment_for_order" class="btn btn-primary"
                                         data-bs-dismiss="modal">ثبت پرداخت
                                    </div>
                                </li>
                                <li>
                                    <a href="#" class="link link-light" data-bs-dismiss="modal">لغو</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<div class="modal fade zoom" id="addChequeForOrder">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">افزودن چک</h5>
                <a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
            </div>
            <div class="modal-body">
                <form action="#">
                    <div class="row g-gs">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="new_cheque_serial_number">سریال چک</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control"
                                           id="new_cheque_serial_number">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="new_cheque_due_date">تاریخ سررسید</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control datepicker"
                                           id="new_cheque_due_date">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label class="form-label" for="new_cheque_bank">بانک</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="new_cheque_bank">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label class="form-label" for="new_cheque_branch">شعبه</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="new_cheque_branch">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label class="form-label" for="new_cheque_current">جاری</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="new_cheque_current">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="new_cheque_owner">صاحب حساب</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="new_cheque_owner">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="new_cheque_owner_id">شماره ملی</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="new_cheque_owner_id">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="new_cheque_price">مبلغ چک</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control price_input" id="new_cheque_price">
                                </div>
                            </div>
                        </div>
                        <input type="hidden" id="new_cheque_order_id">
                        <input type="hidden" id="cheque_order_id_key" value="false">
                        <div class="col-12">
                            <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                <li>
                                    <div id="submit_new_cheque_for_order" class="btn btn-primary"
                                         data-bs-dismiss="modal">ثبت چک
                                    </div>
                                </li>
                                <li>
                                    <a href="#" class="link link-light" data-bs-dismiss="modal">لغو</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<div class="modal fade zoom" id="addInstallmentDataForOrder">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">افزودن اطلاعات اقساطی</h5>
                <a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
            </div>
            <div class="modal-body">
                <form action="#">
                    <div class="row g-gs">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="order_installment_name">نام و نام خانوادگی پرداخت کننده
                                </label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control "
                                           id="order_installment_name">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="order_installment_national_id">کد ملی</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="order_installment_national_id">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="order_installment_organ">نام طرح/سازمان</label>
                                <div class="form-control-wrap">
                                    <select class="form-select" id="order_installment_organ">
										<?php
										foreach ( $organs as $organ => $label ) {
											?>
                                            <option value="<?php echo $organ; ?>"><?php echo $label; ?></option>
											<?php
										}
										?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="order_installment_start_date">تاریخ شروع قسط</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control datepicker"
                                           id="order_installment_date">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="order_installment_month">تعداد ماه</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="order_installment_month">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="order_installment_rec_no">شماره معرفی نامه</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="order_installment_rec_no">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="order_installment_rec_date">تاریخ معرفی نامه</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control datepicker" id="order_installment_rec_date">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="order_installment_recorded_bank">ثبت شده در سامانه
                                    بانکی</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="order_installment_recorded_bank">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="order_installment_recorded_by">ثبت شده توسط</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="order_installment_recorded_by">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="order_installment_record_date">تاریخ ثبت</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control datepicker"
                                           id="order_installment_record_date">
                                </div>
                            </div>
                        </div>
                        <input type="hidden" id="order_installment_data_order_id">
                        <input type="hidden" id="order_installment_amount">
                        <div class="col-12">
                            <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                <li>
                                    <div id="submit_order_installment_data" class="btn btn-primary"
                                         data-bs-dismiss="modal">ثبت پرداخت
                                    </div>
                                </li>
                                <li>
                                    <div id="delete_order_installment_data" class="btn btn-secondary"
                                         data-bs-dismiss="modal">حذف اطلاعات
                                    </div>
                                </li>
                                <li>
                                    <a href="#" class="link link-light" data-bs-dismiss="modal">لغو</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<div class="modal fade zoom" id="stockLogSteps">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">اقدامات صورت گرفته برای محصول</h5>
                <a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
            </div>
            <div class="bg-white modal-body">
            </div>
        </div>
    </div>
</div>
<div class="modal fade zoom" id="callProgressModal">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">اقدامات صورت گرفته برای درخواست</h5>
                <a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
            </div>
            <div class="bg-white modal-body">
            </div>
        </div>
    </div>
</div>
<div class="modal fade zoom" id="processStepsModal">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">اقدامات صورت گرفته</h5>
                <a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
            </div>
            <div class="bg-white modal-body">
            </div>
        </div>
    </div>
</div>
<div class="modal fade zoom" id="processChangeStatusModal">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">اقدامات صورت گرفته</h5>
                <a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
            </div>
            <div class="bg-white modal-body">
                <form action="#">
                    <div class="row g-gs">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="new_report_title">عنوان گزارش</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="new_report_title">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="new_report_category">نوع گزارش</label>
                                <div class="form-control-wrap">
                                    <select class="form-select js-select2 select2-hidden-accessible"
                                            id="new_report_category">
										<?php
										foreach ( $report_category as $category => $data ) {
											?>
                                            <option
                                                value="<?php echo $category; ?>"><?php echo $data['label']; ?></option>
											<?php
										}
										?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label">توضیحات</label>
                                <div class="form-control-wrap">
                                    <div class="quill-basic" data-name="process_step_details">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label" for="process_step_attachment">فایل ضمیمه</label>
                                <div class="upload-zone" data-target="#process_step_attachment"
                                     data-action="crm_handle_file_upload" data-max-files="10">
                                    <div class="dz-message" data-dz-message>
                                        <span class="dz-message-text">بکشید و رها کنید</span>
                                        <span class="dz-message-or">یا</span>
                                        <div class="btn btn-primary">انتخاب کنید</div>
                                    </div>
                                </div>
                            </div>
                            <input type="hidden" id="process_step_attachment">
                        </div>
                        <input type="hidden" id="transfer_process_id">
                        <div class="col-12">
                            <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                <li>
                                    <div id="submit_process_transfer" class="btn btn-primary"
                                         data-bs-dismiss="modal">ثبت انتقال
                                    </div>
                                </li>
                                <li>
                                    <a href="#" class="link link-light" data-bs-dismiss="modal">لغو</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="modal fade zoom" id="addStoreStockLog">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">افزودن محصول به فروشگاه</h5>
                <a href="#" class="close" data-bs-dismiss="modal" aria-label="بستن">
                    <em class="icon ni ni-cross"></em>
                </a>
            </div>
            <div class="modal-body modal-body-md">
                <form action="#" class="modal_form" data-action="crm_add_product_to_store"
                      data-page="/crm/stock-store">
                    <div class="row g-gs">
                        <div class="col-md-6 hide_on_profile">
                            <div class="form-group card-title">
                                <label class="form-label">ثبت ورود برای:</label>
                                <div class="add_product_store_stock_box nk-tb-list">
                                    <span class="sub-text">برای انتخاب محصول لطفا در فیلد روبرو جستجو کنید.</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 hide_on_profile">
                            <div class="form-group card-title search_wrapper">
                                <label class="form-label" for="search_product_store_stock">جستجوی محصول</label>
                                <div class="form-control-wrap">
                                    <div class="form-icon form-icon-left"><em class="icon ni ni-package"></em></div>
                                    <input type="text" class="form-control search_product_modal"
                                           id="search_product_store_stock">
                                </div>
                                <p class="mt-1">جهت جستجوی محصول نام یا بارکد محصول را جستجو کنید.</p>
                                <div class="customer_search_result" data-input="#add_product_store_stock_id"
                                     data-preview=".add_product_store_stock_box"></div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label overline-title-alt"
                                       for="log_product_qty">تعداد محصول</label>
                                <div class="form-control-wrap">
                                    <input type="text"
                                           class="form-control price_input" data-for="qty"
                                           id="log_product_qty">
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                <li>
                                    <div class="btn btn-primary submit_modal_form">افزودن گزارش</div>
                                </li>
                                <li>
                                    <a href="#" class="link link-light" data-bs-dismiss="modal">لغو</a>
                                </li>
                            </ul>
                        </div>
                        <input type="hidden" id="add_product_store_stock_id" data-for="product_id">
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<div class="modal fade zoom" id="addProductionRequest">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">افزودن درخواست تولید محصول</h5>
                <a href="#" class="close" data-bs-dismiss="modal" aria-label="بستن">
                    <em class="icon ni ni-cross"></em>
                </a>
            </div>
            <div class="modal-body modal-body-md">
                <form action="#" class="modal_form" data-action="crm_add_production_request_log"
                      data-page="/crm/stock-produce">
                    <div class="row g-gs">
                        <div class="col-md-6 hide_on_profile">
                            <div class="form-group card-title">
                                <label class="form-label">ثبت درخواست برای:</label>
                                <div class="add_production_item_box nk-tb-list">
                                    <span class="sub-text">برای انتخاب محصول لطفا در فیلد روبرو جستجو کنید.</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 hide_on_profile">
                            <div class="form-group card-title search_wrapper">
                                <label class="form-label" for="search_production_item_stock">جستجوی محصول</label>
                                <div class="form-control-wrap">
                                    <div class="form-icon form-icon-left"><em class="icon ni ni-package"></em></div>
                                    <input type="text" class="form-control search_product_modal"
                                           id="search_production_item_stock">
                                </div>
                                <p class="mt-1">جهت جستجوی محصول نام یا بارکد محصول را جستجو کنید.</p>
                                <div class="customer_search_result" data-input="#add_production_item_product_id"
                                     data-preview=".add_production_item_box"></div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label overline-title-alt"
                                       for="production_request_log_qty">تعداد محصول</label>
                                <div class="form-control-wrap">
                                    <input type="text"
                                           class="form-control price_input"
                                           id="production_request_log_qty" data-for="count" data-req="1">
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label">توضیحات</label>
                                <div class="form-control-wrap">
                                    <div class="quill-basic" data-name="stock_log_note" data-for="note"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                <li>
                                    <div class="btn btn-primary submit_modal_form">افزودن درخواست</div>
                                </li>
                                <li>
                                    <a href="#" class="link link-light" data-bs-dismiss="modal">لغو</a>
                                </li>
                            </ul>
                        </div>
                        <input type="hidden" id="add_production_item_product_id" data-for="product_id">
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<div class="modal fade zoom" id="qcFormModal">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">فرم ثبت کنترل کیفی محصول</h5>
                <a href="#" class="close" data-bs-dismiss="modal" aria-label="بستن">
                    <em class="icon ni ni-cross"></em>
                </a>
            </div>
            <div class="modal-body modal-body-md">
                <form action="#">
                    <div class="row g-gs">
                        <div class="col-12">
                            <div class="custom-control custom-control custom-switch">
                                <input type="checkbox" class="custom-control-input" id="item_qc_approved"
                                       value="qccheck_approved">
                                <label class="custom-control-label" for="item_qc_approved">کیفیت محصول مورد تایید
                                    است.</label>
                            </div>
                        </div>
						<?php
						$questions = render_qc_form_fields();
						foreach ( $questions as $q ) {
							$id    = esc_attr( $q['id'] );
							$label = esc_html( $q['label'] );
							
							switch ( $q['type'] ) {
								case 'radio':
									?>
                                    <div class="col-12">
                                        <div class="form-group">
                                            <label class="form-label"><?php echo $label; ?></label>
                                            <div class="form-control-wrap">
                                                <div class="g-3 align-center flex-wrap">
													<?php
													foreach ( $q['options'] as $val => $text ) {
														?>
                                                        <div class="g">
                                                            <div class="custom-control custom-control-sm custom-radio">
                                                                <input type="radio" name="<?php echo $id; ?>"
                                                                       value="<?php echo esc_attr( $val ); ?>"
                                                                       id="<?php echo $id . '_' . $val; ?>"
                                                                       class="custom-control-input">
                                                                <label class="custom-control-label"
                                                                       for="<?php echo $id . '_' . $val; ?>"><?php echo esc_html( $text ); ?></label>
                                                            </div>
                                                        </div>
														<?php
													}
													?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
									<?php
									break;
								case 'checkbox':
									?>
                                    <div class="col-12">
                                        <div class="form-group">
                                            <label class="form-label"><?php echo esc_html( $label ); ?></label>
                                            <div class="form-control-wrap">
                                                <div class="g-3 align-center flex-wrap">
													<?php foreach ( $q['options'] as $val => $text ) : ?>
                                                        <div class="g">
                                                            <div
                                                                class="custom-control custom-control-sm custom-checkbox">
                                                                <input
                                                                    type="checkbox"
                                                                    name="<?php echo esc_attr( $id ); ?>[]"
                                                                    value="<?php echo esc_attr( $val ); ?>"
                                                                    id="<?php echo esc_attr( $id . '_' . $val ); ?>"
                                                                    class="custom-control-input"
                                                                >
                                                                <label
                                                                    class="custom-control-label"
                                                                    for="<?php echo esc_attr( $id . '_' . $val ); ?>">
																	<?php echo esc_html( $text ); ?>
                                                                </label>
                                                            </div>
                                                        </div>
													<?php endforeach; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
									<?php
									break;
								case 'select': ?>
                                    <div class="col-12">
                                        <div class="form-group">
                                            <label class="form-label"
                                                   for="<?php echo $id; ?>"><?php echo $label; ?></label>
                                            <div class="form-control-wrap">
                                                <select id="<?php echo $id; ?>" class="form-control">
                                                    <option value="">انتخاب کنید...</option>
													<?php foreach ( $q['options'] as $val => $text ) { ?>
                                                        <option
                                                            value="<?php echo esc_attr( $val ); ?>"><?php echo esc_html( $text ); ?></option>
													<?php } ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
									<?php
									break;
								case 'text': ?>
                                    <div class="col-12">
                                        <div class="form-group">
                                            <label class="form-label"
                                                   for="<?php echo $id; ?>"><?php echo $label; ?></label>
                                            <div class="form-control-wrap">
                                                <input type="text" id="<?php echo $id; ?>" class="form-control">
                                            </div>
                                        </div>
                                    </div>
									<?php
									break;
								case 'textarea': ?>
                                    <div class="col-12">
                                        <div class="form-group">
                                            <label class="form-label"
                                                   for="<?php echo $id; ?>"><?php echo $label; ?></label>
                                            <div class="form-control-wrap">
                                                <textarea id="<?php echo $id; ?>" class="form-control"
                                                          rows="3"></textarea>
                                            </div>
                                        </div>
                                    </div>
									<?php
									break;
							}
						}
						?>

                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label" for="action_attachment">فایل ضمیمه</label>
                                <div class="upload-zone" data-target="#qc_attachment_link"
                                     data-action="crm_handle_file_upload" data-max-files="10">
                                    <div class="dz-message" data-dz-message>
                                        <span class="dz-message-text">بکشید و رها کنید</span>
                                        <span class="dz-message-or">یا</span>
                                        <div class="btn btn-primary">انتخاب کنید</div>
                                    </div>
                                </div>
                            </div>
                            <input type="hidden" id="qc_attachment_link">
                        </div>
                        <div class="col-12">
                            <div class="form-group">
                                <div id="submit_product_qc_form"
                                     class="btn btn-primary">ثبت گزارش کنترل کیفی
                                </div>
                                <input type="hidden" id="submit_qc_form_item_ids">
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
