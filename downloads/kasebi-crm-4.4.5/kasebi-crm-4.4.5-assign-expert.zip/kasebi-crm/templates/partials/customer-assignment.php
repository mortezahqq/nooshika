<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
$current_agent = kcp_get_customer_agent_id( (int) $user_id );
$agents = kcp_customer_agents();
?>
<div class="nk-block card card-bordered p-3 mb-4">
    <h6>اختصاص کارشناس</h6>
    <p>کارشناس فعلی: <?php echo esc_html( $current_agent ? get_user_name_by_id( $current_agent ) : '-' ); ?></p>
    <?php if ( kcp_can_assign_customers() ) : ?>
        <label for="kcp-customer-agent">انتخاب کارشناس</label>
        <select id="kcp-customer-agent" class="form-select mb-2">
            <option value="0" <?php selected( $current_agent, 0 ); ?>>بدون کارشناس</option>
            <?php if ( $current_agent && ! in_array( $current_agent, array_map( 'intval', wp_list_pluck( $agents, 'ID' ) ), TRUE ) ) : ?>
                <option value="<?php echo esc_attr( $current_agent ); ?>" selected disabled><?php echo esc_html( get_user_name_by_id( $current_agent ) . ' (تخصیص قبلی)' ); ?></option>
            <?php endif; ?>
            <?php foreach ( $agents as $agent ) : ?>
                <option value="<?php echo esc_attr( $agent->ID ); ?>" <?php selected( $current_agent, $agent->ID ); ?>><?php echo esc_html( get_user_name_by_id( $agent->ID ) ); ?></option>
            <?php endforeach; ?>
        </select>
        <?php if ( ! $agents ) : ?><p>ابتدا در بخش کارمندان، کاربری با نقش کارشناس فروش بسازید.</p><?php endif; ?>
        <button type="button" class="btn btn-primary kcp-save-customer-agent" data-customer="<?php echo esc_attr( $user_id ); ?>" data-nonce="<?php echo esc_attr( wp_create_nonce( 'kcp_customer_assignment' ) ); ?>">ذخیره کارشناس</button>
    <?php endif; ?>
</div>
