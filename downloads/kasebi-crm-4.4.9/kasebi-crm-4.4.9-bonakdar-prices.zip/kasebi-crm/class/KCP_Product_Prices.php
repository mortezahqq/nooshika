<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Read-only CRM prices for the role named «بنکدار». Never changes the signed-in user. */
final class KCP_Product_Prices {
    public static function init() {
        add_action( 'plugins_loaded', [ __CLASS__, 'ensure_ajax_access' ], 20 );
    }

    public static function ensure_ajax_access() {
        $plugin = 'kasebi-wc-management/kasebi-wc-management.php';
        if ( ! is_file( WP_PLUGIN_DIR . '/' . $plugin ) ) { return; }
        $allowed = get_option( 'kcp_ajax_active_plugins', [] );
        $allowed = is_array( $allowed ) ? $allowed : [];
        if ( ! in_array( $plugin, $allowed, true ) ) {
            $allowed[] = $plugin;
            update_option( 'kcp_ajax_active_plugins', $allowed );
        }
    }

    public static function ready() {
        return class_exists( 'KWCM_Modules_Pricing_Storage' )
            && class_exists( 'KWCM_Modules_Pricing_Rule_Resolver' )
            && class_exists( 'KWCM_Modules' ) && KWCM_Modules::is_enabled( 'pricing' );
    }

    private static function normalize_label( $label ) {
        $label = strtr( (string) $label, [ 'ك' => 'ک', 'ي' => 'ی', 'ى' => 'ی' ] );
        return preg_replace( '/[\s\x{200c}\x{200d}\x{200e}\x{200f}]+/u', '', $label );
    }

    public static function role() {
        $matches = [];
        foreach ( wp_roles()->roles as $slug => $role ) {
            if ( self::normalize_label( translate_user_role( $role['name'] ) ) === 'بنکدار'
                || self::normalize_label( $role['name'] ) === 'بنکدار' ) {
                $matches[] = $slug;
            }
        }
        // Do not guess an unrelated wholesale role when the label is missing or ambiguous.
        return count( $matches ) === 1 ? $matches[0] : '';
    }

    public static function notice() {
        if ( self::ready() && ! self::role() ) {
            echo '<div class="alert alert-warning" role="alert">نقش «بنکدار» به‌صورت یکتا پیدا نشد؛ فعلاً قیمت پایه محصولات نمایش داده می‌شود. نام نقش را در وردپرس بررسی کنید.</div>';
        }
    }

    private static function find_rule( $rules, $role ) {
        foreach ( $rules as $rule ) {
            if ( isset( $rule['role'] ) && $rule['role'] === $role ) { return $rule; }
        }
        return [];
    }

    private static function resolve( $product, $role ) {
        // Same priority as KWCM: variation, parent/product, deepest category.
        if ( $product->is_type( 'variation' ) ) {
            $rule = self::find_rule( KWCM_Modules_Pricing_Storage::get_variation_rules( $product->get_id() ), $role );
            if ( $rule ) { return $rule; }
        }
        $id = $product->is_type( 'variation' ) ? $product->get_parent_id() : $product->get_id();
        $rule = self::find_rule( KWCM_Modules_Pricing_Storage::get_product_rules( $id ), $role );
        if ( $rule ) { return $rule; }
        $categories = KWCM_Modules_Pricing_Storage::get_product_category_ids( $id );
        usort( $categories, static function( $a, $b ) {
            return KWCM_Modules_Pricing_Rule_Resolver::get_category_depth( $b )
                <=> KWCM_Modules_Pricing_Rule_Resolver::get_category_depth( $a );
        } );
        $all = KWCM_Modules_Pricing_Storage::get_category_rules();
        foreach ( $categories as $category ) {
            $rule = self::find_rule( $all[ $category ] ?? [], $role );
            if ( $rule ) { return $rule; }
        }
        return [];
    }

    public static function get( $product, $target = 'price' ) {
        $getter = [ 'price' => 'get_price', 'regular_price' => 'get_regular_price', 'sale_price' => 'get_sale_price' ];
        $target = isset( $getter[ $target ] ) ? $target : 'price';
        $fallback = $product->{$getter[ $target ]}( 'edit' );
        if ( ! self::ready() ) { return $product->{$getter[ $target ]}(); }
        $role = self::role();
        $rule = $role ? self::resolve( $product, $role ) : [];
        if ( ! $rule ) { return $fallback; }
        // KWCM has no arbitrary-role calculation API. Mirror its three formulas,
        // using its public, sanitized storage readers without saving any rules.
        $amount = (float) $rule['amount'];
        if ( $rule['type'] === 'fixed_price' ) {
            $sale = (float) ( $rule['sale_price'] ?? 0 );
            $sale = $sale > 0 && $sale < $amount ? $sale : '';
            $price = $target === 'regular_price' ? $amount : ( $target === 'sale_price' ? $sale : ( $sale !== '' ? $sale : $amount ) );
        } elseif ( $target === 'sale_price' ) {
            $price = '';
        } elseif ( $target === 'regular_price' ) {
            $price = max( 0, (float) $product->get_regular_price( 'edit' ) );
        } else {
            $base = max( 0, (float) $product->get_price( 'edit' ) );
            if ( $base <= 0 ) { $base = max( 0, (float) $product->get_regular_price( 'edit' ) ); }
            if ( $base <= 0 ) { return $fallback; }
            $price = max( 0, $base - ( $rule['type'] === 'percent_discount' ? $base * $amount / 100 : $amount ) );
        }
        return $price === '' ? '' : wc_format_decimal( $price, wc_get_price_decimals() );
    }

    public static function format( $price ) {
        if ( $price === '' || $price === null ) { return '—'; }
        $formatted = number_format( (float) $price, wc_get_price_decimals(), '.', ',' );
        return strpos( $formatted, '.' ) !== false ? rtrim( rtrim( $formatted, '0' ), '.' ) : $formatted;
    }

    public static function display( $product, $target = 'price' ) {
        if ( ! $product->is_type( 'variable' ) ) { return self::format( self::get( $product, $target ) ); }
        $prices = [];
        foreach ( $product->get_visible_children() as $id ) {
            $child = wc_get_product( $id );
            if ( ! $child ) { continue; }
            $price = self::get( $child, $target );
            if ( $price !== '' && $price !== null ) { $prices[] = (float) $price; }
        }
        if ( ! $prices ) { return '—'; }
        $min = min( $prices ); $max = max( $prices );
        return self::format( $min ) . ( $min != $max ? ' تا ' . self::format( $max ) : '' );
    }
}
