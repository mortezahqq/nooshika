<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
foreach ( kcp_sales_assignment_types() as $assignment_type => $config ) :
    $current_agent = kcp_get_customer_sales_agent_id( (int) $user_id, $assignment_type );
    $agents = kcp_sales_agents( $assignment_type );
    $select_id = 'kcp-sales-agent-' . $assignment_type;
?>
<div class="nk-block card card-bordered p-3 mb-4">
    <h6><?php echo esc_html( $config['label'] ); ?></h6>
    <p>مسئول فعلی: <?php echo esc_html( $current_agent ? get_user_name_by_id( $current_agent ) : 'تعیین نشده' ); ?></p>
    <?php if ( kcp_can_assign_customers() ) : ?>
        <label for="<?php echo esc_attr( $select_id ); ?>"><?php echo esc_html( 'انتخاب ' . $config['label'] ); ?></label>
        <select id="<?php echo esc_attr( $select_id ); ?>" class="form-select mb-2">
            <option value="0" <?php selected( $current_agent, 0 ); ?>><?php echo esc_html( 'بدون ' . $config['label'] ); ?></option>
            <?php if ( $current_agent && ! in_array( $current_agent, array_map( 'intval', wp_list_pluck( $agents, 'ID' ) ), TRUE ) ) : ?>
                <option value="<?php echo esc_attr( $current_agent ); ?>" selected disabled><?php echo esc_html( get_user_name_by_id( $current_agent ) . ' (تخصیص قبلی؛ نقش فعلی متفاوت است)' ); ?></option>
            <?php endif; ?>
            <?php foreach ( $agents as $agent ) : ?>
                <option value="<?php echo esc_attr( $agent->ID ); ?>" <?php selected( $current_agent, $agent->ID ); ?>><?php echo esc_html( get_user_name_by_id( $agent->ID ) ); ?></option>
            <?php endforeach; ?>
        </select>
        <?php if ( ! $agents ) : ?><p><?php echo esc_html( 'ابتدا در بخش کارمندان، کاربری با نقش «' . kcp_get_role_label( $config['role'] ) . '» بسازید یا نقش کارمند موردنظر را تنظیم کنید.' ); ?></p><?php endif; ?>
        <button type="button" class="btn btn-primary kcp-save-sales-agent" data-type="<?php echo esc_attr( $assignment_type ); ?>" data-select="<?php echo esc_attr( $select_id ); ?>" data-customer="<?php echo esc_attr( $user_id ); ?>" data-nonce="<?php echo esc_attr( wp_create_nonce( 'kcp_customer_assignment' ) ); ?>"><?php echo esc_html( 'ذخیره ' . $config['label'] ); ?></button>
    <?php endif; ?>
</div>
<?php endforeach; ?>
