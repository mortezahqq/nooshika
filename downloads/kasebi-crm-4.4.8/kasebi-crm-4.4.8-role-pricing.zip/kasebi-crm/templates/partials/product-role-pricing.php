<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<div class="col-12 kcp-role-pricing-panel" data-nonce="<?php echo esc_attr( wp_create_nonce( 'kcp_role_pricing' ) ); ?>">
    <div class="card card-bordered p-3">
        <h6>قیمت‌گذاری</h6>
        <p class="text-soft">برای هر نقش یک قانون قیمت ثابت، تخفیف درصدی یا تخفیف مبلغی تعریف کنید. مبالغ را در واحد پول فروشگاه وارد کنید.</p>
        <div class="kcp-pricing-status" role="status" aria-live="polite"></div>
        <button type="button" class="btn btn-sm btn-outline-secondary kcp-pricing-retry" hidden>دریافت دوباره قوانین</button>
        <div class="kcp-pricing-editor" hidden>
            <div class="table-responsive">
                <table class="table table-bordered align-middle">
                    <thead><tr><th>نقش کاربری</th><th>نوع قیمت‌گذاری</th><th>مقدار / مبلغ</th><th>قیمت فروش ویژه</th><th>حذف</th></tr></thead>
                    <tbody class="kcp-pricing-rows"></tbody>
                </table>
            </div>
            <p class="kcp-pricing-empty text-soft">قانونی برای این محصول ثبت نشده است.</p>
            <button type="button" class="btn btn-sm btn-outline-primary kcp-pricing-add"><em class="icon ni ni-plus"></em><span>افزودن قانون</span></button>
            <p class="small text-soft mt-2 mb-0">قوانین همراه دکمه «ذخیره» محصول ذخیره می‌شوند.</p>
        </div>
        <template class="kcp-pricing-row-template">
            <tr class="kcp-pricing-row">
                <td><select class="form-select kcp-pricing-role" aria-label="نقش کاربری"></select></td>
                <td><select class="form-select kcp-pricing-type" aria-label="نوع قیمت‌گذاری"></select></td>
                <td><input type="text" inputmode="decimal" class="form-control kcp-pricing-amount" aria-label="مقدار قانون"></td>
                <td><input type="text" inputmode="decimal" class="form-control kcp-pricing-sale" aria-label="قیمت فروش ویژه نقش"><span class="kcp-pricing-no-sale">—</span></td>
                <td><button type="button" class="btn btn-sm btn-outline-danger kcp-pricing-remove" aria-label="حذف قانون"><em class="icon ni ni-trash"></em></button></td>
            </tr>
        </template>
    </div>
</div>
