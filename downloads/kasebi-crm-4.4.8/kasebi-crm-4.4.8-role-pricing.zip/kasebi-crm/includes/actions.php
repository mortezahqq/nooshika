<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/*
 * show marketers in users list
 */
add_filter( 'manage_users_columns', function( $columns ) {
	$columns['user_marketer'] = 'بازاریاب';
	
	return $columns;
}, 10, 1 );
add_filter( 'manage_users_custom_column', function( $row_output, $column_id_attr, $user ) {
	switch ( $column_id_attr ) {
		case 'user_marketer' :
			$user_marketer = crm_get_user_marketer( $user );
			if ( $user_marketer ) {
				return get_user_name_by_id( $user_marketer );
			}
			
			return ' - ';
		default:
	}
	
	return $row_output;
}, 10, 3 );

add_action( 'wp_print_scripts', function() {
	$page = kcp_get_current_page_basename();
	if ( ! in_array( $page, kcp_get_page_list() ) ) {
		return;
	}
	global $wp_scripts;
	$scripts = $wp_scripts->registered;
	foreach ( $scripts as $script ) {
		wp_dequeue_script( $script->handle );
	}
	
	wp_enqueue_style(
		'kasebi-neshan-leaflet',
		'https://static.neshan.org/sdk/leaflet/v1.9.4/neshan-sdk/v1.0.8/index.css',
		[],
		'1.0.8'
	);
	
	wp_enqueue_script(
		'kasebi-neshan-leaflet',
		'https://static.neshan.org/sdk/leaflet/v1.9.4/neshan-sdk/v1.0.8/index.js',
		[],
		'1.0.8',
		TRUE
	);
	
	wp_enqueue_script( 'kasebi_crm_bundle', KCP_ASSETS_URL . 'js/bundle.js', [], '1.5', FALSE );
	//	wp_enqueue_script( 'kasebi_chart_quill', KCP_ASSETS_URL . 'js/plugins/chart.min.js', [], 1, TRUE );
	wp_enqueue_script( 'kasebi_crm_quill', KCP_ASSETS_URL . 'js/plugins/quill.js', [], 1, TRUE );
	wp_enqueue_script( 'kasebi_crm_datepicker', KCP_ASSETS_URL . 'js/plugins/persianDatepicker.min.js', [], 1, TRUE );
	wp_enqueue_script( 'kasebi_crm_xlsx', KCP_ASSETS_URL . 'js/plugins/xlsx.full.min.js', [], 1, TRUE );
	wp_enqueue_script( 'kasebi_crm_script', KCP_ASSETS_URL . 'js/scripts.js', [], KCP_VER, TRUE );
    wp_enqueue_script( 'kasebi_crm_role_pricing', KCP_ASSETS_URL . 'js/role-pricing.js', [ 'kasebi_crm_script' ], KCP_VER, TRUE );
	wp_localize_script( 'kasebi_crm_script', 'kcpData', [
		'ajax_url' => home_url( KCP_AJAX_URI ),
		'key'      => KASEBI_NESHAN_WEB_API_KEY,
	] );
	
	wp_add_inline_style(
		'kasebi-neshan-leaflet',
		'
		#kasebi-user-location-map {
			width: 100%;
			height: 360px;
			border-radius: 8px;
			overflow: hidden;
			border: 1px solid #ccd0d4;
			margin-bottom: 12px;
		}
		.kasebi-user-location-fields {
			display: flex;
			gap: 12px;
			align-items: end;
			flex-wrap: wrap;
		}
		.kasebi-user-location-fields label {
			display: flex;
			flex-direction: column;
			gap: 4px;
		}
		'
	);
} );
add_action( 'wp_print_styles', function() {
	$page = kcp_get_current_page_basename();
	if ( ! in_array( $page, kcp_get_page_list() ) ) {
		return;
	}
	global $wp_styles;
	$styles = $wp_styles->registered;
	foreach ( $styles as $style ) {
		wp_dequeue_style( $style->handle );
	}
	wp_enqueue_style( 'nooshika_fonts_css', NASSETSURL . 'css/nooshika-fonts.css', [], NOOSHIKA_MAIN_VERSION );
	wp_enqueue_style( 'kasebi_crm_style', KCP_ASSETS_URL . 'css/dashlite.rtl.css', [], KCP_VER );
	wp_enqueue_style( 'kasebi_crm_quill', KCP_ASSETS_URL . 'css/plugins/quill.rtl.css' );
	wp_enqueue_style( 'kasebi_crm_datepicker', KCP_ASSETS_URL . 'css/plugins/persianDatepicker-default.css' );
	wp_enqueue_style( 'kasebi_crm_theme', KCP_ASSETS_URL . 'css/theme.css', [], KCP_VER );
	$skin = get_user_meta( get_current_user_id(), 'crm_skin', TRUE ) ?: 'default';
	if ( $skin != 'default' ) {
		wp_enqueue_style( 'kasebi_crm_skin', KCP_ASSETS_URL . 'css/skins/theme-' . $skin . '.css', [], KCP_VER );
	}
} );

add_filter( 'body_class', function( $classes ) {
	$dark_mode = get_user_meta( get_current_user_id(), 'crm_dark_mode', TRUE ) == 'true' ? 'dark-mode' : '';
	if ( $dark_mode ) {
		$classes[] = $dark_mode;
	}
	
	return $classes;
} );
add_action( 'template_redirect', function() {
	$page = kcp_get_current_page_basename();
	if ( isset( $_GET['action'] ) ) {
		$action = $_GET['action'];
		switch ( $action ) {
			case 'factor':
				$type = $_GET['type'] ?? 'roll';
				echo crm_get_template( "misc/factor_$type.php" );
				exit;
			case 'bill':
				$type = $_GET['type'] ?? 'roll';
				echo crm_get_template( "bill/$type.php" );
				exit;
			case 'print':
				$type = $_GET['type'];
				if ( ! $type ) {
					return;
				}
				echo crm_get_template( "print/$type.php" );
				exit;
			default:
				break;
		}
	}
	if ( is_page( 'crm' ) ) {
		if ( isset( $_GET['action'] ) && $_GET['action'] == 'logout' ) {
			wp_logout();
			wp_redirect( home_url( "/crm-login" ) );
			exit;
		}
		if ( ! is_user_logged_in() ) {
			wp_redirect( home_url( "/crm-login" ) );
			exit;
		}
	}
	if ( is_page( 'crm-password' ) ) {
		if ( ! is_user_logged_in() ) {
			wp_redirect( home_url( "/crm-login" ) );
			exit;
		}
	}
	if ( is_page( 'crm-login' ) ) {
		if ( is_user_logged_in() ) {
			$url = $_GET['redirect'] ?? 'crm';
			wp_redirect( home_url( "/" . $url ) );
			exit;
		}
	}
	if ( in_array( $page, kcp_get_page_list() ) ) {
		add_filter( 'show_admin_bar', '__return_false' );
		remove_action( 'wp_head', '_admin_bar_bump_cb' );
	}
}, 200 );

add_action( 'init', function() {
	$pages = get_crm_pages_list();
	foreach ( $pages as $page => $data ) {
		$type = $data['type'] ?? 'page';
		if ( $type == 'page' ) {
			add_rewrite_endpoint( $page, EP_PAGES );
		} else {
			if ( isset( $data['sub'] ) ) {
				foreach ( $data['sub'] as $sub_page => $datum ) {
					add_rewrite_endpoint( $sub_page, EP_PAGES );
				}
			}
		}
	}
	$single_pages = get_crm_single_page_list();
	foreach ( $single_pages as $slug => $page ) {
		add_rewrite_endpoint( $slug, EP_PAGES );
	}
	flush_rewrite_rules();
} );

add_action( 'init', function() {
	add_role( 'marketer', 'بازاریاب', [
		'read' => TRUE,
	] );
} );
add_action( 'init', function() {
	$roles = kcp_get_all_roles( FALSE );
	
	foreach ( $roles as $role_key ) {
		if ( ! get_role( $role_key ) ) {
			$role_label = kcp_get_role_label( $role_key );
			add_role( $role_key, $role_label, [ 'read' => TRUE ] );
		}
	}
} );
add_action( 'gform_field_standard_settings', function( $position ) {
	if ( $position == 1600 ) {
		?>
        <li class="crm_settings field_setting">
            <label for="crm" class="section_label">تنظیمات CRM</label>
            <ul class="rules_container">
                <li>
                    <input type="checkbox" id="field_crm_phone" onclick="SetFieldProperty('crm_phone',this.checked);"
                           onkeypress="SetFieldProperty('crm_phone',this.checked);"/>
                    <label for="field_crm_phone" class="inline">شماره تماس مشتری</label>
                </li>
                <li>
                    <div class="duplicate_setting field_setting">
                        <input type="checkbox" id="field_crm_name"
                               onclick="SetFieldProperty('crm_name', this.checked);"
                               onkeypress="SetFieldProperty('crm_name', this.checked);"/>
                        <label for="field_crm_name" class="inline">نام و نام خانوادگی مشتری</label>
                    </div>
                </li>
            </ul>

        </li>
		<?php
	}
} );

add_action( 'gform_editor_js', function() {
	?>
    <script type='text/javascript'>
        fieldSettings['text'] += ', .crm_settings';
        jQuery(document).bind('gform_load_field_settings', function(event, field, form) {
            jQuery('#field_crm_phone').prop('checked', Boolean(rgar(field, 'crm_phone')));
            jQuery('#field_crm_name').prop('checked', Boolean(rgar(field, 'crm_name')));
        });
    </script>
	<?php
} );

add_action( 'gform_after_submission', function( $entry, $form ) {
	if ( is_user_logged_in() ) {
		return;
	}
	$phone = '';
	$name  = '';
	foreach ( $form['fields'] as $field ) {
		if ( rgar( $field, 'crm_phone' ) ) {
			$phone = rgar( $entry, $field['id'] );
		}
		if ( rgar( $field, 'crm_name' ) ) {
			$name = rgar( $entry, $field['id'] );
		}
	}
	if ( $phone || $name ) {
		$phone   = is_valid_phone( $phone );
		$name    = separate_first_last_from_name( $name );
		$user_id = get_user_id_by_phone( $phone );
		if ( ! $user_id ) {
			$user_id = wp_insert_user( [
				'user_login' => $phone,
				'user_pass'  => wp_generate_password(),
				'first_name' => $name['first'],
				'last_name'  => $name['last'],
				'role'       => 'subscriber',
				'meta_input' => [
					'nooshika_phone_num'        => $phone,
					'user_registered_funnel'    => 'g_form',
					'user_registered_by_g_form' => $form['id'],
				],
			] );
			if ( is_wp_error( $user_id ) ) {
				return;
			}
		}
		GFAPI::update_entry_property( $entry['id'], 'created_by', $user_id );
	}
}, 10, 2 );
add_action( 'init', function() {
	register_post_status( 'wc-delivered', [
		'label'                     => 'تحویل کالا',
		'public'                    => TRUE,
		'show_in_admin_status_list' => TRUE,
		'show_in_admin_all_list'    => TRUE,
		'exclude_from_search'       => FALSE,
		'label_count'               => _n_noop( 'تحویل کالا (%s)', 'تحویل کالا (%s)' ),
	] );
} );
add_filter( 'wc_order_statuses', function( $order_statuses ) {
	return [
		'wc-pending'    => 'پیش فاکتور',
		'wc-processing' => 'تایید مالی',
		'wc-completed'  => 'تکمیل شده',
		'wc-delivered'  => 'تحویل کالا',
		'wc-cancelled'  => 'لغو شده',
	];
}, 100 );

add_action( 'woocommerce_order_status_changed', function( $order_id ) {
	$order = wc_get_order( $order_id );
	if ( ! $order ) {
		return;
	}
	
	$user_id = $order->get_customer_id();
	if ( ! $user_id ) {
		return;
	}
	
	$total = crm_get_user_total_order_value( $user_id );
	$count = crm_get_user_total_order_count( $user_id );
	
	update_user_meta( $user_id, 'user_total_order', $total );
	update_user_meta( $user_id, 'user_total_order_count', $count );
}, 10 );

function kcp_get_my_hr_requests_badge_count( int $user_id = 0 ): int {
	global $wpdb;
	
	$user_id = $user_id ?: get_current_user_id();
	
	if ( ! $user_id ) {
		return 0;
	}
	
	$is_admin = function_exists( 'is_current_user_admin' )
		? is_current_user_admin( 0, FALSE, FALSE )
		: current_user_can( 'manage_options' );
	
	static $counts = [];
	
	$cache_key = $user_id . '_' . ( $is_admin ? 'admin' : 'user' );
	
	if ( isset( $counts[ $cache_key ] ) ) {
		return $counts[ $cache_key ];
	}
	
	$calls_table      = $wpdb->prefix . 'kcp_calls';
	$calls_meta_table = $wpdb->prefix . 'kcp_calls_meta';
	
	if ( $is_admin ) {
		$count = $wpdb->get_var( $wpdb->prepare(
			"
			SELECT COUNT(*)
			FROM {$calls_table}
			WHERE source = %s
				AND status IN ('new', 'referred')
			",
			'internal'
		) );
	} else {
		$count = $wpdb->get_var( $wpdb->prepare(
			"
			SELECT COUNT(DISTINCT c.id)
			FROM {$calls_table} AS c
			INNER JOIN {$calls_meta_table} AS cm
				ON cm.call_id = c.id
				AND cm.meta_key = 'assigned_to'
			WHERE c.source = %s
				AND c.status IN ('new', 'referred')
				AND CAST(cm.meta_value AS UNSIGNED) = %d
			",
			'internal',
			$user_id
		) );
	}
	
	$counts[ $cache_key ] = absint( $count );
	
	return $counts[ $cache_key ];
}

add_action( 'ncp_navbar_title_after', function( string $key ) {
	if ( $key !== 'hr-requests' ) {
		return;
	}
	
	$count = kcp_get_my_hr_requests_badge_count();
	
	if ( ! $count ) {
		return;
	}
	
	printf(
		' <span class="me-2 bg-warning badge">%s</span>',
		esc_html( number_format_i18n( $count ) )
	);
} );

add_filter( 'woocommerce_stock_amount', static function( $amount ) {
	return is_numeric( $amount ) ? (float) $amount : $amount;
}, 999 );