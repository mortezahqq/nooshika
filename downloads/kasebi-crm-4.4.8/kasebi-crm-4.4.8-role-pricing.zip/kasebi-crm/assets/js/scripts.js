!function(NioApp, $) {
    'use strict';
    
    NioApp.Package.name = 'DashLite';
    NioApp.Package.version = '3.2';
    var $win         = $(window),
        $body        = $('body'),
        $doc         = $(document),
        _menu        = 'nk-menu',
        _header      = 'nk-header',
        _header_menu = 'nk-header-menu',
        _sidebar     = 'nk-sidebar',
        _sidebar_mob = 'nk-sidebar-mobile',
        _break       = NioApp.Break;
    let ajax_url    = kcpData.ajax_url,
        ajax_search = false;
    NioApp.State.isRTL = true;
    const charts = {};
    
    function extend(obj, ext) {
        Object.keys(ext).forEach(function(key) {
            obj[key] = ext[key];
        });
        return obj;
    }
    
    NioApp.ClassBody = function() {
        NioApp.AddInBody(_sidebar);
    };
    NioApp.ClassNavMenu = function() {
        NioApp.BreakClass('.' + _header_menu, _break.lg, {
            timeOut: 0,
        });
        NioApp.BreakClass('.' + _sidebar, _break.lg, {
            timeOut:  0,
            classAdd: _sidebar_mob,
        });
        $win.on('resize', function() {
            NioApp.BreakClass('.' + _header_menu, _break.lg);
            NioApp.BreakClass('.' + _sidebar, _break.lg, {
                classAdd: _sidebar_mob,
            });
        });
    };
    NioApp.Prettify = function() {
        window.prettyPrint && prettyPrint();
    };
    
    NioApp.Copied = function() {
        var clip   = '.clipboard-init',
            target = '.clipboard-text',
            sclass = 'clipboard-success',
            eclass = 'clipboard-error';
        
        // Feedback
        function feedback(el, state) {
            var $elm = $(el),
                $elp = $elm.parent(),
                copy = {
                    text: 'کپی',
                    done: 'کپی شد',
                    fail: 'ناموفق',
                },
                data = {
                    text: $elm.data('clip-text'),
                    done: $elm.data('clip-success'),
                    fail: $elm.data('clip-error'),
                };
            copy.text = data.text ? data.text : copy.text;
            copy.done = data.done ? data.done : copy.done;
            copy.fail = data.fail ? data.fail : copy.fail;
            var copytext = state === 'success' ? copy.done : copy.fail,
                addclass = state === 'success' ? sclass : eclass;
            $elp.addClass(addclass).find(target).html(copytext);
            setTimeout(function() {
                $elp.removeClass(sclass + ' ' + eclass).
                    find(target).
                    html(copy.text).
                    blur();
                $elp.find('input').blur();
            }, 2000);
        }
        
        // Init ClipboardJS
        if (ClipboardJS.isSupported()) {
            var clipboard = new ClipboardJS(clip);
            clipboard.on('success', function(e) {
                feedback(e.trigger, 'success');
                e.clearSelection();
            }).on('error', function(e) {
                feedback(e.trigger, 'error');
            });
        } else {
            $(clip).css('display', 'none');
        }
        
    };
    
    // Sticky Nav @v1.0
    NioApp.StickyNav = function() {
        var elem = document.querySelectorAll('.' + _header);
        if (elem.length > 0) {
            elem.forEach(function(item) {
                var _item_offset = 30;
                if (window.scrollY > _item_offset) {
                    item.classList.add('has-fixed');
                } else {
                    item.classList.remove('has-fixed');
                }
            });
        }
    };
    NioApp.StickyNav.init = function() {
        NioApp.StickyNav();
        window.addEventListener('scroll', function() {
            NioApp.StickyNav();
        });
    };
    
    // PasswordSwitch @v1.0
    NioApp.PassSwitch = function() {
        NioApp.Passcode('.passcode-switch');
    };
    
    // Toastr Message @v1.0
    NioApp.Toast = function(msg, ttype, opt) {
        var ttype = ttype ? ttype : 'info',
            msi   = '',
            ticon = ttype === 'info' ? 'ni ni-info-fill' : ttype ===
                                                           'success'
                                                           ? 'ni ni-check-circle-fill'
                                                           : ttype === 'error'
                                                             ? 'ni ni-cross-circle-fill'
                                                             : ttype === 'warning' ? 'ni ni-alert-fill' : '',
            def   = {
                position: 'bottom-right',
                ui:       '',
                icon:     'auto',
                clear:    false,
            },
            attr  = opt ? extend(def, opt) : def;
        attr.position = attr.position
                        ? 'toast-' + attr.position
                        : 'toast-bottom-right';
        attr.icon = attr.icon === 'auto' ? ticon : attr.icon
                                                   ? attr.icon
                                                   : '';
        attr.ui = attr.ui ? ' ' + attr.ui : '';
        msi = attr.icon !== ''
              ? '<span class="toastr-icon"><em class="icon ' + attr.icon +
                  '"></em></span>'
              : '', msg = msg !== '' ? msi + '<div class="toastr-text">' + msg +
            '</div>' : '';
        if (msg !== '') {
            if (attr.clear === true) {
                toastr.clear();
            }
            var option = {
                'closeButton':       true,
                'debug':             false,
                'newestOnTop':       false,
                'progressBar':       false,
                'positionClass':     attr.position + attr.ui,
                'closeHtml':         '<span class="btn-trigger">Close</span>',
                'preventDuplicates': true,
                'showDuration':      '1500',
                'hideDuration':      '1500',
                'timeOut':           '2000',
                'toastClass':        'toastr',
                'extendedTimeOut':   '3000',
            };
            toastr.options = extend(option, attr);
            toastr[ttype](msg);
        }
    };
    
    // Toggle Screen @v1.0
    NioApp.TGL.screen = function(elm) {
        if ($(elm).exists()) {
            $(elm).each(function() {
                var ssize = $(this).data('toggle-screen');
                if (ssize) {
                    $(this).addClass('toggle-screen-' + ssize);
                }
            });
        }
    };
    
    // Toggle Content @v1.0
    NioApp.TGL.content = function(elm, opt) {
        var toggle        = elm ? elm : '.toggle',
            $toggle       = $(toggle),
            $contentD     = $('[data-content]'),
            toggleBreak   = true,
            toggleCurrent = false,
            def           = {
                active:  'active',
                content: 'content-active',
                'break': toggleBreak,
            },
            attr          = opt ? extend(def, opt) : def;
        NioApp.TGL.screen($contentD);
        $toggle.on('click', function(e) {
            toggleCurrent = this;
            NioApp.Toggle.trigger($(this).data('target'), attr);
            e.preventDefault();
        });
        $doc.on('mouseup', function(e) {
            if (toggleCurrent) {
                var $toggleCurrent  = $(toggleCurrent),
                    currentTarget   = $(toggleCurrent).data('target'),
                    $contentCurrent = $(
                        '[data-content="'.concat(currentTarget, '"]')),
                    $dpd            = $('.datepicker-dropdown'),
                    $tpc            = $('.ui-timepicker-container');
                if (!$toggleCurrent.is(e.target) &&
                    $toggleCurrent.has(e.target).length === 0 &&
                    !$contentCurrent.is(e.target) &&
                    $contentCurrent.has(e.target).length === 0 &&
                    $(e.target).closest('.select2-container').length === 0 &&
                    !$dpd.is(e.target) &&
                    $dpd.has(e.target).length === 0 && !$tpc.is(e.target) &&
                    $tpc.has(e.target).length === 0) {
                    NioApp.Toggle.removed($toggleCurrent.data('target'), attr);
                    toggleCurrent = false;
                }
            }
        });
        $win.on('resize', function() {
            $contentD.each(function() {
                var content     = $(this).data('content'),
                    ssize       = $(this).data('toggle-screen'),
                    toggleBreak = _break[ssize];
                if (NioApp.Win.width > toggleBreak) {
                    NioApp.Toggle.removed(content, attr);
                }
            });
        });
    };
    
    // ToggleExpand @v1.0
    NioApp.TGL.expand = function(elm, opt) {
        var toggle = elm ? elm : '.expand',
            def    = {
                toggle: true,
            },
            attr   = opt ? extend(def, opt) : def;
        $(toggle).on('click', function(e) {
            NioApp.Toggle.trigger($(this).data('target'), attr);
            e.preventDefault();
        });
    };
    
    // Dropdown Menu @v1.0
    NioApp.TGL.ddmenu = function(elm, opt) {
        var imenu = elm ? elm : '.nk-menu-toggle',
            def   = {
                active: 'active',
                self:   'nk-menu-toggle',
                child:  'nk-menu-sub',
            },
            attr  = opt ? extend(def, opt) : def;
        $(imenu).on('click', function(e) {
            e.stopPropagation();
            if (NioApp.Win.width < _break.lg ||
                $(this).parents().hasClass(_sidebar)) {
                NioApp.Toggle.dropMenu($(this), attr);
            }
            e.preventDefault();
        });
    };
    
    // Show Menu @v1.0
    NioApp.TGL.showmenu = function(elm, opt) {
        var toggle      = elm ? elm : '.nk-nav-toggle',
            $toggle     = $(toggle),
            $contentD   = $('[data-content]'),
            toggleBreak = $contentD.hasClass(_header_menu)
                          ? _break.lg
                          : _break.xl,
            toggleOlay  = _sidebar + '-overlay',
            toggleClose = {
                profile: true,
                menu:    false,
            },
            def         = {
                active:  'toggle-active',
                content: _sidebar + '-active',
                body:    'nav-shown',
                overlay: toggleOlay,
                'break': toggleBreak,
                close:   toggleClose,
            },
            attr        = opt ? extend(def, opt) : def;
        $toggle.on('click', function(e) {
            NioApp.Toggle.trigger($(this).data('target'), attr);
            e.preventDefault();
        });
        $doc.on('mouseup', function(e) {
            if (!$toggle.is(e.target) && $toggle.has(e.target).length === 0 &&
                !$contentD.is(e.target) &&
                $contentD.has(e.target).length === 0 && NioApp.Win.width <
                toggleBreak) {
                NioApp.Toggle.removed($toggle.data('target'), attr);
            }
        });
        $win.on('resize', function() {
            if (NioApp.Win.width < _break.xl || NioApp.Win.width <
                toggleBreak) {
                NioApp.Toggle.removed($toggle.data('target'), attr);
            }
        });
    };
    
    // Animate FormSearch @v1.0
    NioApp.Ani.formSearch = function(elm, opt) {
        var def  = {
                active:  'active',
                timeout: 400,
                target:  '[data-search]',
            },
            attr = opt ? extend(def, opt) : def;
        var $elem   = $(elm),
            $target = $(attr.target);
        if ($elem.exists()) {
            $elem.on('click', function(e) {
                e.preventDefault();
                var $self      = $(this),
                    the_target = $self.data('target'),
                    $self_st   = $('[data-search=' + the_target + ']'),
                    $self_tg   = $('[data-target=' + the_target + ']');
                if (!$self_st.hasClass(attr.active)) {
                    $self_tg.add($self_st).addClass(attr.active);
                    $self_st.find('input').focus();
                } else {
                    $self_tg.add($self_st).removeClass(attr.active);
                }
            });
            $doc.on({
                keyup:   function keyup(e) {
                    if (e.key === 'Escape') {
                        $elem.add($target).removeClass(attr.active);
                    }
                },
                mouseup: function mouseup(e) {
                    if (!$target.is(e.target) &&
                        $target.has(e.target).length ===
                        0 && !$elem.is(e.target) &&
                        $elem.has(e.target).length === 0) {
                        $elem.add($target).removeClass(attr.active);
                    }
                },
            });
        }
    };
    
    // Animate FormElement @v1.0
    NioApp.Ani.formElm = function(elm, opt) {
        var def  = {
                focus: 'focused',
            },
            attr = opt ? extend(def, opt) : def;
        if ($(elm).exists()) {
            $(elm).each(function() {
                var $self = $(this);
                if ($self.val()) {
                    $self.parent().addClass(attr.focus);
                }
                $self.on({
                    focus: function focus() {
                        $self.parent().addClass(attr.focus);
                    },
                    blur:  function blur() {
                        if (!$self.val()) {
                            $self.parent().removeClass(attr.focus);
                        }
                    },
                });
            });
        }
    };
    
    // Form Validate @v1.0
    NioApp.Validate = function(elm, opt) {
        if ($(elm).exists()) {
            $(elm).each(function() {
                var def  = {
                        errorElement: 'span',
                    },
                    attr = opt ? extend(def, opt) : def;
                $(this).validate(attr);
            });
            NioApp.Validate.OnChange('.js-select2');
            NioApp.Validate.OnChange('.date-picker');
            NioApp.Validate.OnChange('.js-tagify');
        }
    };
    
    //On change validation for third party plugins
    NioApp.Validate.OnChange = function(elm) {
        $(elm).on('change', function() {
            $(this).valid();
        });
    };
    NioApp.Validate.init = function() {
        NioApp.Validate('.form-validate', {
            errorElement:   'span',
            errorClass:     'invalid',
            errorPlacement: function errorPlacement(error, element) {
                if (element.parents().hasClass('input-group')) {
                    error.appendTo(element.parent().parent());
                } else {
                    error.appendTo(element.parent());
                }
            },
        });
    };
    
    // Dropzone @v1.1
    NioApp.Dropzone = function(elm, opt) {
        if ($(elm).exists()) {
            $(elm).each(function() {
                var maxFiles = $(elm).data('max-files'),
                    maxFiles = maxFiles ? maxFiles : null;
                var maxFileSize = $(elm).data('max-file-size'),
                    maxFileSize = maxFileSize ? maxFileSize : 256;
                var acceptedFiles = $(elm).data('accepted-files'),
                    acceptedFiles = acceptedFiles ? acceptedFiles : null;
                var def  = {
                        autoDiscover:  false,
                        maxFiles:      maxFiles,
                        maxFilesize:   maxFileSize,
                        acceptedFiles: acceptedFiles,
                    },
                    attr = opt ? extend(def, opt) : def;
                $(this).addClass('dropzone').dropzone(attr);
            });
        }
    };
    /*
     NioApp.Dropzone.init = function () {
     $('.upload-zone').each(function () {
     const el = this
     const $el = $(el)
     const maxFiles = parseInt($el.attr('data-max-files')) || 1
     const target = $el.attr('data-target')
     const urlsStr = ($el.attr('data-urls') || '').trim()
     const idsStr = ($el.attr('data-ids') || '').trim()
     let isInitializing = true
     
     let dz = NioApp.Dropzone(el, {
     url:            ajax_url,
     addRemoveLinks: true,
     maxFiles:       maxFiles,
     accept:         function (file, done) {
     const nameData = $el.attr('data-name')
     if (nameData) {
     let modal = Swal.mixin({
     title:             'عنوان فایل',
     html:              '<div class="form-group">' +
     '<label class="form-label" for="attachment_title">عنوان فایل</label>' +
     '<div class="form-control-wrap">' +
     '<input class="form-control" id="attachment_title">' +
     '</div>' +
     '</div>',
     focusConfirm:      false,
     showCancelButton:  true,
     confirmButtonText: 'آپلود کن',
     cancelButtonText:  `لغو`,
     preConfirm:        () => {
     return $('#attachment_title').val()
     },
     })
     modal.fire().then(function (result) {
     console.log(result.value)
     if (result.isConfirmed && result.value) {
     file.custom_filename = result.value // ذخیره روی فایل
     done()
     } else {
     done('عنوان فایل وارد نشده است')
     }
     })
     } else {
     done()
     }
     },
     sending:        function (file, xhr, formData) {
     formData.append('action', $el.attr('data-action'))
     if (file.custom_filename) {
     formData.append('file_name', file.custom_filename)
     }
     },
     success:        function (file, response) {
     file._uploaded_url = response.attachment
     let $target = $(target)
     let currentVal = $target.val().trim()
     let urls = currentVal ? currentVal.split(',') : []
     urls.push(response.attachment)
     if (urls.length > maxFiles) {
     urls = urls.slice(urls.length - maxFiles)
     }
     
     $target.val(urls.join(','))
     if (!isInitializing) {
     $target.trigger('change')
     }
     },
     removedfile:    function (file) {
     let uploadedUrl = file._uploaded_url
     let $target = $(target)
     let currentVal = $target.val().trim()
     let urls = currentVal ? currentVal.split(',') : []
     
     urls = urls.filter(function (url) {
     return url !== uploadedUrl
     })
     
     $target.val(urls.join(','))
     if (!isInitializing) {
     $target.trigger('change')
     }
     
     // حذف ظاهری فایل از UI
     if (file.previewElement) {
     file.previewElement.remove()
     }
     
     },
     })
     console.log(dz)
     const urls = urlsStr.split(',').map(u => u.trim()).filter(Boolean)
     isInitializing = false // بعد از مقداردهی اولیه
     if (urls.length) {
     urls.forEach((url, index) => {
     const mockFile = {
     name: url.split('/').pop(),
     size: 123456,
     }
     dz.emit('addedfile', mockFile)
     dz.emit('thumbnail', mockFile, url)
     dz.emit('complete', mockFile)
     mockFile.previewElement.classList.add('dz-success', 'dz-complete')
     })
     }
     })
     }
     */
    NioApp.Dropzone.init = function() {
        if (window.Dropzone && Dropzone.autoDiscover) {
            Dropzone.autoDiscover = false;
        }
        
        $('.upload-zone').each(function() {
            const el = this;
            const $el = $(el);
            const maxFiles = parseInt($el.attr('data-max-files')) || 1;
            const target = $el.attr('data-target');
            const $target = $(target);
            const urlsStr = ($el.attr('data-urls') || '').trim();
            let isInitializing = true;
            
            $el.addClass('dropzone');
            
            const dz = new Dropzone(el, {
                url:            ajax_url,
                addRemoveLinks: true,
                maxFiles:       maxFiles,
                
                accept(file, done) {
                    const nameData = $el.attr('data-name');
                    if (!nameData) {
                        return done();
                    }
                    
                    const modal = Swal.mixin({
                        title:             'عنوان فایل',
                        html:
                                           '<div class="form-group">' +
                                               '  <label class="form-label" for="attachment_title">عنوان فایل</label>' +
                                               '  <div class="form-control-wrap">' +
                                               '    <input class="form-control" id="attachment_title">' +
                                               '  </div>' +
                                               '</div>',
                        focusConfirm:      false,
                        showCancelButton:  true,
                        confirmButtonText: 'آپلود کن',
                        cancelButtonText:  'لغو',
                        preConfirm:        () => $('#attachment_title').val(),
                    });
                    
                    modal.fire().then(res => {
                        if (res.isConfirmed && res.value) {
                            file.custom_filename = res.value;
                            done();
                        } else {
                            done('عنوان فایل وارد نشده است');
                        }
                    });
                },
                
                sending(file, xhr, formData) {
                    formData.append('action', $el.attr('data-action'));
                    if (file.custom_filename) {
                        formData.append('file_name', file.custom_filename);
                    }
                },
                
                success(file, response) {
                    // اگر سرور متن برگرداند، تلاش برای پارس
                    let resp = response;
                    if (typeof resp === 'string') {
                        try { resp = JSON.parse(resp); } catch (e) {}
                    }
                    const uploadedUrl = (resp && (resp.attachment || resp.url || resp.file_url)) || '';
                    
                    file._uploaded_url = uploadedUrl;
                    
                    let urls = ($target.val().trim() ? $target.val().split(',') : []);
                    if (uploadedUrl) {
                        urls.push(uploadedUrl);
                    }
                    
                    if (urls.length > maxFiles) {
                        urls = urls.slice(urls.length - maxFiles);
                    }
                    
                    $target.val(urls.join(','));
                    if (!isInitializing) {
                        $target.trigger('change');
                    }
                },
                
                removedfile(file) {
                    const uploadedUrl = file._uploaded_url;
                    let urls = ($target.val().trim() ? $target.val().split(',') : []);
                    if (uploadedUrl) {
                        urls = urls.filter(u => u !== uploadedUrl);
                    }
                    
                    $target.val(urls.join(','));
                    if (!isInitializing) {
                        $target.trigger('change');
                    }
                    
                    if (file.previewElement) {
                        file.previewElement.remove();
                    }
                },
            });
            
            // --- لود اولیه از data-urls + پر کردن target ---
            const urls = urlsStr.split(',').map(u => u.trim()).filter(Boolean);
            if (urls.length) {
                const initial = maxFiles ? urls.slice(-maxFiles) : urls;
                // پر کردن ورودی هدف
                $target.val(initial.join(','));
                // ساخت پیش‌نمایش‌ها
                initial.forEach(url => {
                    const mockFile = {
                        name:          url.split('/').pop(),
                        size:          123456,
                        _uploaded_url: url, // برای حذف درست
                    };
                    dz.emit('addedfile', mockFile);
                    dz.emit('thumbnail', mockFile, url);
                    dz.emit('complete', mockFile);
                    if (mockFile.previewElement) {
                        mockFile.previewElement.classList.add('dz-success', 'dz-complete');
                    }
                });
            }
            
            isInitializing = false;
        });
    };
    
    // Wizard @v1.0
    NioApp.Wizard = function() {
        var $wizard = $('.nk-wizard');
        if ($wizard.exists()) {
            $wizard.each(function() {
                var $self    = $(this),
                    _self_id = $self.attr('id'),
                    $self_id = $('#' + _self_id).show();
                $self_id.steps({
                    headerTag:      '.nk-wizard-head',
                    bodyTag:        '.nk-wizard-content',
                    labels:         {
                        finish:   'ارسال',
                        next:     'بعدی',
                        previous: 'قبلی',
                        loading:  'در حال بارگذاری ...',
                    },
                    titleTemplate:  '<span class="number">0#index#</span> #title#',
                    onStepChanging: function onStepChanging(
                        event, currentIndex, newIndex) {
                        // Allways allow previous action even if the current
                        // form is not valid!
                        if (currentIndex > newIndex) {
                            return true;
                        }
                        // Needed in some cases if the user went back (clean up)
                        if (currentIndex < newIndex) {
                            // To remove error styles
                            $self_id.find(
                                    '.body:eq(' + newIndex + ') label.error').
                                remove();
                            $self_id.find('.body:eq(' + newIndex + ') .error').
                                removeClass('error');
                        }
                        $self_id.validate().settings.ignore = ':disabled,:hidden';
                        return $self_id.valid();
                    },
                    onFinishing:    function onFinishing(event, currentIndex) {
                        $self_id.validate().settings.ignore = ':disabled';
                        return $self_id.valid();
                    },
                    onFinished:     function onFinished(event, currentIndex) {
                        window.location.href = '#';
                    },
                }).validate({
                    errorElement:   'span',
                    errorClass:     'invalid',
                    errorPlacement: function errorPlacement(error, element) {
                        error.appendTo(element.parent());
                    },
                });
            });
        }
    };
    
    // DataTable @1.1
    NioApp.DataTable = function(elm, opt) {
        if ($(elm).exists()) {
            $(elm).each(function() {
                var auto_responsive = $(this).data('auto-responsive'),
                    has_export      = typeof opt.buttons !== 'undefined' &&
                                      opt.buttons
                                      ? true
                                      : false;
                var export_title = $(this).data('export-title') ? $(this).
                    data('export-title') : 'Export';
                var btn     = has_export
                              ? '<"dt-export-buttons d-flex align-center"<"dt-export-title d-none d-md-inline-block">B>'
                              : '',
                    btn_cls = has_export ? ' with-export' : '';
                var dom_normal = '<"row justify-between g-2' + btn_cls +
                    '"<"col-7 col-sm-4 text-start"f><"col-5 col-sm-8 text-end"<"datatable-filter"<"d-flex justify-content-end g-2"' +
                    btn +
                    'l>>>><"datatable-wrap my-3"t><"row align-items-center"<"col-7 col-sm-12 col-md-9"p><"col-5 col-sm-12 col-md-3 text-start text-md-end"i>>';
                var dom_separate = '<"row justify-between g-2' + btn_cls +
                    '"<"col-7 col-sm-4 text-start"f><"col-5 col-sm-8 text-end"<"datatable-filter"<"d-flex justify-content-end g-2"' +
                    btn +
                    'l>>>><"my-3"t><"row align-items-center"<"col-7 col-sm-12 col-md-9"p><"col-5 col-sm-12 col-md-3 text-start text-md-end"i>>';
                var dom = $(this).hasClass('is-separate')
                          ? dom_separate
                          : dom_normal;
                var def  = {
                        responsive: true,
                        autoWidth:  false,
                        dom:        dom,
                        language:   {
                            search:            '',
                            searchPlaceholder: 'برای جستجو تایپ کنید',
                            lengthMenu:        '<span class=\'d-none d-sm-inline-block\'>نمایش</span><div class=\'form-control-select\'> _MENU_ </div>',
                            info:              '_START_ -_END_ از _TOTAL_',
                            infoEmpty:         '0',
                            infoFiltered:      '( کل _MAX_  )',
                            paginate:          {
                                'first':    'اول',
                                'last':     'آخر',
                                'next':     'بعدی',
                                'previous': 'قبلی',
                            },
                        },
                    },
                    attr = opt ? extend(def, opt) : def;
                attr = auto_responsive === false ? extend(attr, {
                    responsive: false,
                }) : attr;
                $(this).DataTable(attr);
                $('.dt-export-title').text(export_title);
            });
        }
    };
    
    // DataTable Init @v1.0
    NioApp.DataTable.init = function() {
        NioApp.DataTable('.datatable-init', {
            responsive: {
                details: true,
            },
        });
        NioApp.DataTable('.datatable-init-export', {
            responsive: {
                details: true,
            },
            buttons:    ['copy', 'excel', 'csv', 'pdf'],
        });
        $.fn.DataTable.ext.pager.numbers_length = 7;
    };
    
    // BootStrap Extended
    NioApp.BS.ddfix = function(elm, exc) {
        var dd = elm ? elm : '.dropdown-menu',
            ex = exc
                 ? exc
                 : 'a:not(.clickable), button:not(.clickable), a:not(.clickable) *, button:not(.clickable) *';
        $(dd).on('click', function(e) {
            if (!$(e.target).is(ex)) {
                e.stopPropagation();
                return;
            }
        });
        if (NioApp.State.isRTL) {
            var $dMenu = $('.dropdown-menu');
            $dMenu.each(function() {
                var $self = $(this);
                if ($self.hasClass('dropdown-menu-end') &&
                    !$self.hasClass('dropdown-menu-center')) {
                    $self.prev('[data-bs-toggle="dropdown"]').dropdown({
                        popperConfig: {
                            placement: 'bottom-start',
                        },
                    });
                } else if (!$self.hasClass('dropdown-menu-end') &&
                    !$self.hasClass('dropdown-menu-center')) {
                    $self.prev('[data-bs-toggle="dropdown"]').dropdown({
                        popperConfig: {
                            placement: 'bottom-end',
                        },
                    });
                }
            });
        }
    };
    
    // BootStrap Specific Tab Open
    NioApp.BS.tabfix = function(elm) {
        var tab = elm ? elm : '[data-bs-toggle="modal"]';
        $(tab).on('click', function() {
            var _this       = $(this),
                target      = _this.data('target'),
                target_href = _this.attr('href'),
                tg_tab      = _this.data('tab-target');
            var modal = target ? $body.find(target) : $body.find(
                target_href);
            if (tg_tab && tg_tab !== '#' && modal) {
                modal.find('[href="' + tg_tab + '"]').tab('show');
            } else if (modal) {
                var tabdef = modal.find('.nk-nav.nav-tabs');
                var link = $(tabdef[0]).find('[data-bs-toggle="tab"]');
                $(link[0]).tab('show');
            }
        });
    };
    
    // Dark Mode Switch @since v2.0
    NioApp.ModeSwitch = function() {
        var toggle = $('.dark-switch');
        if ($body.hasClass('dark-mode')) {
            toggle.addClass('active');
        } else {
            toggle.removeClass('active');
        }
        toggle.on('click', function(e) {
            e.preventDefault();
            $(this).toggleClass('active');
            $body.toggleClass('dark-mode');
        });
    };
    
    // Knob @v1.0
    NioApp.Knob = function(elm, opt) {
        if ($(elm).exists() && typeof $.fn.knob === 'function') {
            var def  = {
                    min: 0,
                },
                attr = opt ? extend(def, opt) : def;
            $(elm).each(function() {
                $(this).knob(attr);
            });
        }
    };
    // Knob Init @v1.0
    NioApp.Knob.init = function() {
        var knob = {
            'default': {
                readOnly: true,
                lineCap:  'round',
            },
            half:      {
                angleOffset: -90,
                angleArc:    180,
                readOnly:    true,
                lineCap:     'round',
            },
        };
        NioApp.Knob('.knob', knob['default']);
        NioApp.Knob('.knob-half', knob.half);
    };
    
    // Range @v1.0.1
    NioApp.Range = function(elm, opt) {
        if ($(elm).exists() && typeof noUiSlider !== 'undefined') {
            $(elm).each(function() {
                var $self   = $(this),
                    self_id = $self.attr('id');
                var _start        = $self.data('start'),
                    _start        = /\s/g.test(_start)
                                    ? _start.split(' ')
                                    : _start,
                    _start        = _start ? _start : 0,
                    _connect      = $self.data('connect'),
                    _connect      = /\s/g.test(_connect)
                                    ? _connect.split(' ')
                                    : _connect,
                    _connect      = typeof _connect == 'undefined'
                                    ? 'lower'
                                    : _connect,
                    _min          = $self.data('min'),
                    _min          = _min ? _min : 0,
                    _max          = $self.data('max'),
                    _max          = _max ? _max : 100,
                    _min_distance = $self.data('min-distance'),
                    _min_distance = _min_distance ? _min_distance : null,
                    _max_distance = $self.data('max-distance'),
                    _max_distance = _max_distance ? _max_distance : null,
                    _step         = $self.data('step'),
                    _step         = _step ? _step : 1,
                    _orientation  = $self.data('orientation'),
                    _orientation  = _orientation ? _orientation : 'horizontal',
                    _tooltip      = $self.data('tooltip'),
                    _tooltip      = _tooltip ? _tooltip : false;
                var target = document.getElementById(self_id);
                var def  = {
                        start:       _start,
                        connect:     _connect,
                        direction:   NioApp.State.isRTL ? 'rtl' : 'ltr',
                        range:       {
                            'min': _min,
                            'max': _max,
                        },
                        margin:      _min_distance,
                        limit:       _max_distance,
                        step:        _step,
                        orientation: _orientation,
                        tooltips:    _tooltip,
                    },
                    attr = opt ? extend(def, opt) : def;
                noUiSlider.create(target, attr);
            });
        }
    };
    
    // Range Init @v1.0
    NioApp.Range.init = function() {
        NioApp.Range('.form-control-slider');
        NioApp.Range('.form-range-slider');
    };
    NioApp.Select2.init = function() {
        NioApp.Select2('.js-select2');
    };
    
    // Slick Slider @v1.0.1
    NioApp.Slick = function(elm, opt) {
        if ($(elm).exists() && typeof $.fn.slick === 'function') {
            $(elm).each(function() {
                var def  = {
                        'prevArrow': '<div class="slick-arrow-prev"><a href="javascript:void(0);" class="slick-prev"><em class="icon ni ni-chevron-left"></em></a></div>',
                        'nextArrow': '<div class="slick-arrow-next"><a href="javascript:void(0);" class="slick-next"><em class="icon ni ni-chevron-right"></em></a></div>',
                        rtl:         NioApp.State.isRTL,
                    },
                    attr = opt ? extend(def, opt) : def;
                $(this).slick(attr);
            });
        }
    };
    
    // Slick Init @v1.0
    NioApp.Slider.init = function() {
        NioApp.Slick('.slider-init');
    };
    
    // Magnific Popup @v1.0.0
    NioApp.Lightbox = function(elm, type, opt) {
        if ($(elm).exists()) {
            $(elm).each(function() {
                var def = {};
                if (type == 'video' || type == 'iframe') {
                    def = {
                        type:            'iframe',
                        removalDelay:    160,
                        preloader:       true,
                        fixedContentPos: false,
                        callbacks:       {
                            beforeOpen: function beforeOpen() {
                                this.st.image.markup = this.st.image.markup.replace(
                                    'mfp-figure',
                                    'mfp-figure mfp-with-anim');
                                this.st.mainClass = this.st.el.attr(
                                    'data-effect');
                            },
                        },
                    };
                } else if (type == 'content') {
                    def = {
                        type:         'inline',
                        preloader:    true,
                        removalDelay: 400,
                        mainClass:    'mfp-fade content-popup',
                    };
                } else {
                    def = {
                        type:      'image',
                        mainClass: 'mfp-fade image-popup',
                    };
                }
                var attr = opt ? extend(def, opt) : def;
                $(this).magnificPopup(attr);
            });
        }
    };
    
    // Controls @v1.0.0
    NioApp.Control = function(elm) {
        var control = document.querySelectorAll(elm);
        control.forEach(function(item, index, arr) {
            item.checked ? item.parentNode.classList.add('checked') : null;
            item.addEventListener('change', function() {
                if (item.type == 'checkbox') {
                    item.checked
                    ? item.parentNode.classList.add('checked')
                    : item.parentNode.classList.remove(
                        'checked');
                }
                if (item.type == 'radio') {
                    document.querySelectorAll(
                            'input[name="' + item.name + '"]').
                        forEach(function(item, index, arr) {
                            item.parentNode.classList.remove('checked');
                        });
                    item.checked
                    ? item.parentNode.classList.add('checked')
                    : null;
                }
            });
        });
    };
    
    // Number Spinner @v1.0
    NioApp.NumberSpinner = function(elm, opt) {
        var plus = document.querySelectorAll('[data-number=\'plus\']');
        var minus = document.querySelectorAll('[data-number=\'minus\']');
        plus.forEach(function(item, index, arr) {
            var parent = plus[index].parentNode;
            plus[index].addEventListener('click', function() {
                var child = plus[index].parentNode.children;
                child.forEach(function(item, index, arr) {
                    if (child[index].classList.contains('number-spinner')) {
                        var value = !child[index].value == '' ? parseInt(
                            child[index].value) : 0;
                        var step = !child[index].step == ''
                                   ? parseInt(child[index].step)
                                   : 1;
                        var max = !child[index].max == ''
                                  ? parseInt(child[index].max)
                                  : Infinity;
                        if (max + 1 > value + step) {
                            child[index].value = value + step;
                        } else {
                            child[index].value = value;
                        }
                    }
                });
            });
        });
        minus.forEach(function(item, index, arr) {
            var parent = minus[index].parentNode;
            minus[index].addEventListener('click', function() {
                var child = minus[index].parentNode.children;
                child.forEach(function(item, index, arr) {
                    if (child[index].classList.contains('number-spinner')) {
                        var value = !child[index].value == '' ? parseInt(
                            child[index].value) : 0;
                        var step = !child[index].step == ''
                                   ? parseInt(child[index].step)
                                   : 1;
                        var min = !child[index].min == ''
                                  ? parseInt(child[index].min)
                                  : 0;
                        if (min - 1 < value - step) {
                            child[index].value = value - step;
                        } else {
                            child[index].value = value;
                        }
                    }
                });
            });
        });
    };
    
    // Stepper @v1.0
    NioApp.Stepper = function(elm, opt) {
        var element = document.querySelectorAll(elm);
        if (element.length > 0) {
            element.forEach(function(item, index) {
                var def  = {
                        selectors:    {
                            nav:      'stepper-nav',
                            progress: 'stepper-progress',
                            content:  'stepper-steps',
                            prev:     'step-prev',
                            next:     'step-next',
                            submit:   'step-submit',
                        },
                        classes:      {
                            nav_current: 'current',
                            nav_done:    'done',
                            step_active: 'active',
                            step_done:   'done',
                            active_step: 'active',
                        },
                        current_step: 1,
                    },
                    attr = opt ? extend(def, opt) : def;
                NioApp.Custom.Stepper(item, attr);
                NioApp.Validate.OnChange('.js-select2');
                NioApp.Validate.OnChange('.date-picker');
                NioApp.Validate.OnChange('.js-tagify');
            });
        }
    };
    // Stepper Init @v1.0
    NioApp.Stepper.init = function() {
        NioApp.Stepper('.stepper-init');
    };
    
    // Tagify @v1.0.1
    NioApp.Tagify = function(elm, opt) {
        if ($(elm).exists() && typeof $.fn.tagify === 'function') {
            var def,
                attr = opt ? extend(def, opt) : def;
            $(elm).tagify(attr);
        }
    };
    // Tagify Init @v1.0
    NioApp.Tagify.init = function() {
        NioApp.Tagify('.js-tagify');
    };
    
    /* Isotope - Filter @v1.0 */
    NioApp.Filter = function(elem, childSelector) {
        var qsRegex;
        var elm = document.querySelectorAll(elem);
        elm.forEach(function(item) {
            if (typeof item != 'undefined' && item != null) {
                var iso = new Isotope(item, {
                    itemSelector: childSelector,
                    layoutMode:   'fitRows',
                    filter:       function filter(itemElem) {
                        return qsRegex
                               ? itemElem.textContent.match(qsRegex)
                               : true;
                    },
                    hiddenStyle:  {
                        opacity:   0,
                        transform: 'scale(0.001)',
                    },
                    visibleStyle: {
                        opacity:   1,
                        transform: 'scale(1)',
                    },
                });
                var filterBtn = document.querySelectorAll('[data-filter]');
                console.log();
                filterBtn.forEach(function(btnItem) {
                    btnItem.addEventListener('click', function(event) {
                        // only work with buttons
                        if (!matchesSelector(event.target, 'button')) {
                            return;
                        }
                        var filterValue = event.target.getAttribute(
                            'data-filter');
                        iso.arrange({
                            filter: filterValue,
                        });
                        filterBtn.forEach(function(allButtons) {
                            allButtons.classList.remove('active');
                        });
                        btnItem.classList.add('active');
                    });
                });
            }
        });
    };
    
    // Extra @v1.1
    NioApp.OtherInit = function() {
        NioApp.ClassBody();
        NioApp.PassSwitch();
        NioApp.LinkOff('.is-disable');
        NioApp.ClassNavMenu();
        NioApp.SetHW('[data-height]', 'height');
        NioApp.SetHW('[data-width]', 'width');
        NioApp.NumberSpinner();
        NioApp.Lightbox('.popup-video', 'video');
        NioApp.Lightbox('.popup-iframe', 'iframe');
        NioApp.Lightbox('.popup-image', 'image');
        NioApp.Lightbox('.popup-content', 'content');
        NioApp.Control('.custom-control-input');
        NioApp.Filter('.filter-container', '.filter-item');
    };
    
    // Animate Init @v1.0
    NioApp.Ani.init = function() {
        NioApp.Ani.formElm('.form-control-outlined');
        NioApp.Ani.formSearch('.toggle-search');
    };
    
    // BootstrapExtend Init @v1.0
    NioApp.BS.init = function() {
        NioApp.BS.menutip('a.nk-menu-link');
        NioApp.BS.tooltip('.nk-tooltip');
        NioApp.BS.tooltip('.btn-tooltip', {
            placement: 'top',
        });
        NioApp.BS.tooltip('[data-toggle="tooltip"]');
        NioApp.BS.tooltip('[data-bs-toggle="tooltip"]');
        NioApp.BS.tooltip('.tipinfo,.nk-menu-tooltip', {
            placement: 'right',
        });
        NioApp.BS.popover('[data-toggle="popover"]');
        NioApp.BS.popover('[data-bs-toggle="popover"]');
        NioApp.BS.progress('[data-progress]');
        NioApp.BS.fileinput('.form-file-input');
        NioApp.BS.modalfix();
        NioApp.BS.ddfix();
        NioApp.BS.tabfix();
    };
    
    document.addEventListener('shown.bs.popover', function(e) {
        const openedEl = e.target;
        
        document.querySelectorAll('[data-bs-toggle="popover"]').forEach((el) => {
            if (el === openedEl) {
                return;
            }
            
            const inst = bootstrap.Popover.getInstance(el);
            if (inst) {
                inst.hide();
            }
        });
    });
    
    // Picker Init @v1.0
    NioApp.Picker.init = function() {
        NioApp.Picker.date('.date-picker');
        NioApp.Picker.dob('.date-picker-alt');
        NioApp.Picker.time('.time-picker');
        NioApp.Picker.date('.date-picker-range', {
            todayHighlight: false,
            autoclose:      false,
        });
        NioApp.Picker.date('.date-picker-ym', {
            format:      'yy/mm',
            startView:   2,
            autoclose:   true,
            maxViewMode: 2,
            minViewMode: 1,
        });
    };
    
    // Addons @v1
    NioApp.Addons.Init = function() {
        NioApp.Knob.init();
        NioApp.Range.init();
        NioApp.Select2.init();
        NioApp.Dropzone.init();
        NioApp.Slider.init();
        NioApp.DataTable.init();
        NioApp.Tagify.init();
    };
    
    // Toggler @v1
    NioApp.TGL.init = function() {
        NioApp.TGL.content('.toggle');
        NioApp.TGL.expand('.toggle-expand');
        NioApp.TGL.expand('.toggle-opt', {
            toggle: false,
        });
        NioApp.TGL.showmenu('.nk-nav-toggle');
        NioApp.TGL.ddmenu('.' + _menu + '-toggle', {
            self:  _menu + '-toggle',
            child: _menu + '-sub',
        });
    };
    NioApp.BS.modalOnInit = function() {
        $('.modal').on('shown.bs.modal', function() {
            NioApp.Select2.init();
            NioApp.Validate.init();
        });
    };
    NioApp.Quill = function() {
        var _basic = '.quill-basic';
        if ($(_basic).exists()) {
            $(_basic).each(function() {
                var toolbarOptions = [
                    ['bold', 'italic', 'underline', 'strike'],        // toggled
                                                                      // buttons
                    ['blockquote', 'code-block'],
                    
                    [{'list': 'ordered'}, {'list': 'bullet'}],
                    [{'script': 'sub'}, {'script': 'super'}],      // superscript/subscript
                    [{'indent': '-1'}, {'indent': '+1'}],          // outdent/indent
                    
                    [{'header': [1, 2, 3, 4, 5, 6]}],
                    
                    [{'color': []}, {'background': []}],          // dropdown
                                                                  // with
                                                                  // defaults
                                                                  // from theme
                    [{'align': []}],
                    
                    ['clean'],                                         // remove
                                                                       // formatting
                                                                       // button
                ];
                
                var quill = new Quill(this, {
                    modules: {
                        toolbar: toolbarOptions,
                    },
                    theme:   'snow',
                });
            });
        }
        
        var _minimal = '.quill-minimal';
        if ($(_minimal).exists()) {
            $(_minimal).each(function() {
                var toolbarOptions = [
                    ['bold', 'italic', 'underline'],        // toggled buttons
                    ['blockquote', {'list': 'bullet'}],
                    [{'align': []}],
                    ['clean'],                                         // remove
                ];
                
                var quill = new Quill(this, {
                    modules: {
                        toolbar: toolbarOptions,
                    },
                    theme:   'snow',
                });
            });
        }
    };
    
    function activate_date_pickers() {
        let years = [];
        for (let i = 1321; i <= 1407; i++) {
            years.push(i);
        }
        $('.datepicker').each(function() {
            let _this = $(this);
            let args = {
                nextArrow:       '<i class="fas fa-chevron-left"></i>',
                prevArrow:       '<i class="fas fa-chevron-right"></i>',
                formatDate:      'YYYY-MM-DD',
                cellWidth:       27,
                cellHeight:      26,
                selectableYears: years,
                onSelect:        function() {
                    _this.trigger('change');
                },
            };
            if (_this.attr('data-value')) {
                let selectedDate = _this.attr('data-value');
                args['selectedDate'] = new Date(
                    selectedDate).toLocaleDateString(
                    'fa-IR-u-nu-latn');
                args['selectedBefore'] = !0;
            }
            _this.persianDatepicker(args);
        });
    }
    
    function add_loading_block() {
        let loading_html = '<div class="modal fade" id="loading_modal">'
            + '<div class="modal-dialog">'
            +
            '<div class="spinner-border text-light" style="width: 3rem; height: 3rem; margin: auto" role="status"></div>'
            + '</div></div>';
        $('#loading_modal').remove();
        $('body').append(loading_html);
    }
    
    function show_loading_modal() {
        $('#loading_modal').addClass('show').css('display', 'block');
    }
    
    function hide_loading_modal() {
        $('#loading_modal').removeClass('show').css('display', 'none');
    }
    
    function validate_phone_number(phone) {
        let regex = /^(\+98|0)?9\d{9}$/;
        return regex.test(toEnglishNumber(phone));
    }
    
    function validate_slug(slug) {
        let regex = /^[a-zA-Z0-9-_]+$/;
        return regex.test(slug);
    }
    
    function number_format(number) {
        return new Intl.NumberFormat('en').format(number);
    }
    
    function toEnglishNumber(strNum, element = null) {
        if (strNum === undefined || strNum === null) {
            return '';
        }
        let s = String(strNum);
        
        // تبدیل ارقام فارسی (۰-۹) و عربی (٠-٩) به انگلیسی
        const fa = '۰۱۲۳۴۵۶۷۸۹';
        const ar = '٠١٢٣٤٥٦٧٨٩';
        s = s.replace(/[۰-۹]/g, d => String(fa.indexOf(d))).replace(/[٠-٩]/g, d => String(ar.indexOf(d)));
        
        if (element) {
            $(element).val(s);
            return;
        }
        return s;
    }
    
    function sanitizeNumber(number, keepDecimal = false) {
        if (number === undefined || number === null || number === '') {
            return 0;
        }
        
        let s = toEnglishNumber(String(number)).trim();
        
        // − -> -
        s = s.replace(/\u2212/g, '-');
        
        // (123) -> -123
        if (/^\(.*\)$/.test(s)) {
            s = '-' + s.slice(1, -1);
        }
        
        // ممیز عربی/فارسی -> نقطه
        s = s.replace(/\u066B/g, '.'); // ٫ -> .
        
        // جداکننده‌های هزارگان: comma انگلیسی هم باید باشد
        s = s.replace(/[,٬،\u00A0\u202F_]/g, '');
        
        if (keepDecimal) {
            // فقط عدد، منفی و نقطه بماند
            s = s.replace(/[^0-9.\-]/g, '');
            
            // منفی فقط اول رشته مجاز باشد
            s = s.replace(/(?!^)-/g, '');
            
            // اگر چندتا نقطه داشت، فقط اولی ممیز باشد
            const parts = s.split('.');
            if (parts.length > 2) {
                s = parts.shift() + '.' + parts.join('');
            }
        } else {
            // بدون اعشار: نقطه هم حذف شود
            s = s.replace(/\./g, '');
            
            // فقط عدد و منفی بماند
            s = s.replace(/[^0-9\-]/g, '');
            
            // منفی فقط اول رشته مجاز باشد
            s = s.replace(/(?!^)-/g, '');
        }
        
        const n = keepDecimal ? parseFloat(s) : parseInt(s, 10);
        
        return isNaN(n) ? 0 : n;
    }
    
    function formatNumber(num) {
        if (num >= 1_000_000_000) {
            return (num / 1_000_000_000).toFixed(2) + ' میلیارد';
        } else if (num >= 1_000_000) {
            return (num / 1_000_000).toFixed(2) + ' میلیون';
        } else if (num >= 1_000) {
            return (num / 1_000).toFixed(2) + ' هزار';
        }
        return num.toFixed(2);
    }
    
    NioApp.init = function() {
        NioApp.coms.docReady.push(NioApp.OtherInit);
        NioApp.coms.docReady.push(NioApp.Prettify);
        NioApp.coms.docReady.push(NioApp.ColorBG);
        NioApp.coms.docReady.push(NioApp.ColorTXT);
        NioApp.coms.docReady.push(NioApp.Copied);
        NioApp.coms.docReady.push(NioApp.Ani.init);
        NioApp.coms.docReady.push(NioApp.TGL.init);
        NioApp.coms.docReady.push(NioApp.BS.init);
        NioApp.coms.docReady.push(NioApp.Validate.init);
        NioApp.coms.docReady.push(NioApp.Picker.init);
        NioApp.coms.docReady.push(NioApp.Addons.Init);
        NioApp.coms.docReady.push(NioApp.Wizard);
        NioApp.coms.docReady.push(NioApp.Stepper.init);
        NioApp.coms.winLoad.push(NioApp.ModeSwitch);
        NioApp.coms.winLoad.push(NioApp.StickyNav.init);
        NioApp.coms.docReady.push(NioApp.Quill);
        activate_date_pickers();
        add_loading_block();
        calc_factor_total();
        evaluateAll();
        renderCharts();
        activate_charts();
        render_map();
    };
    NioApp.ajaxInit = function() {
        NioApp.OtherInit();
        NioApp.Prettify();
        NioApp.ColorBG();
        NioApp.ColorTXT();
        NioApp.Copied();
        NioApp.Ani.init();
        NioApp.TGL.init();
        NioApp.BS.init();
        NioApp.Validate.init();
        NioApp.Picker.init();
        NioApp.Addons.Init();
        NioApp.Wizard();
        NioApp.ModeSwitch();
        NioApp.Stepper.init();
        NioApp.StickyNav.init();
        NioApp.Quill();
        activate_date_pickers();
        add_loading_block();
        calc_factor_total();
        evaluateAll();
        renderCharts();
        activate_charts();
        render_map();
    };
    
    NioApp.init();
    
    function request_panel_page_content($url) {
        show_loading_modal();
        $url = $url.split('?');
        let data = {
            'action': 'crm_request_page_content',
            'page':   $url ? $url[0] : '',
        };
        if ($url[1]) {
            let params = $url[1].split('&');
            for (let i = 0; i < params.length; i++) {
                let param = params[i].split('=');
                data[param[0]] = param[1];
            }
        }
        $.post(ajax_url, data, function(response) {
            change_panel_html(response);
            history.pushState({}, '', response.url);
        });
    }
    
    let time,
        timer_interval;
    
    function start_timer() {
        let timer_div = $('.otp_timer');
        timer_div.addClass('disabled');
        timer_div.html(`<span>دریافت مجدد کد:</span>
                            <span class="timer_text">01:00</span>`);
        time = 60;
        timer_interval = setInterval(function() {
            time--;
            let timer = (time < 10) ? '0' + time : time;
            timer_div.find('.timer_text').text('00:' + timer);
            if (time === 0) {
                clearInterval(timer_interval);
                timer_div.html('دریافت مجدد پیامک');
                timer_div.removeClass('disabled');
            }
        }, 1000);
    }
    
    function activate_otp_inputs() {
        let inputs = $('#otp_input_form').find('input');
        let len = inputs.length;
        inputs.each(function() {
            $(this).val('');
        });
        
        const handlePaste = (ev) => {
            const clip = ev.clipboardData.getData('text');
            const pin = clip.replace(/\s/g, '');
            const ch = [...pin];
            inputs.removeClass('filled');
            inputs.each(function(index, element) {
                element.value = ch[index] ?? '';
                if (ch[index]) {
                    $(element).addClass('filled');
                }
            });
            inputs[pin.length - 1].focus();                  // Focus input
        };
        const handleInput = (ev) => {
            const elInp = ev.currentTarget;
            const i = inputs.index(elInp);
            if (elInp.value && (i + 1) % len) {
                inputs[i + 1].focus();
            }
            let full_code = '';
            inputs.removeClass('filled');
            inputs.each(function(index, element) {
                if ($(element).val()) {
                    $(element).addClass('filled');
                }
                full_code += $(element).val() + '';
            });
            $('#otp_input_form').attr('data-code', full_code);
        };
        const handleKeyDn = (ev) => {
            const elInp = ev.currentTarget;
            const i = inputs.index(elInp);
            if (elInp.value) {
                $(elInp).addClass('filled');
            } else {
                $(elInp).removeClass('filled');
            }
            if (!elInp.value && ev.key === 'Backspace' && i) {
                inputs[i - 1].focus();
            }
            if (ev.key === 'Enter') {
                $('#otp_modal').find('.submit_otp_btn').trigger('click');
            }
        };
        inputs.each(function(index, element) {
            element.addEventListener('paste', handlePaste);   // Handle pasting
            element.addEventListener('input', handleInput);   // Handle typing
            element.addEventListener('keydown', handleKeyDn); // Handle deleting
        });
    }
    
    function focus_first_otp_input() {
        let inputs = $('#otp_input_form').find('input');
        inputs.each(function() {
            $(this).val('');
        });
        inputs.removeClass('filled');
        inputs[0].focus();
    }
    
    function get_current_page_filters() {
        const data = {
            search: $('.search_crm_list').val(),
        };
        
        $('.filter_form_wrapper').find('input, select').each(function() {
            const $el = $(this);
            const type = $el.attr('type');
            const key = $el.data('for');
            const val = $el.val();
            
            if (!key) {
                return;
            }
            
            if (type === 'checkbox' && !$el.prop('checked')) {
                return;
            }
            if (type === 'radio' && !$el.prop('checked')) {
                return;
            }
            
            const match = key.match(/^(\w+)\[(\w+)\]$/);
            
            if (match) {
                const [, main, sub] = match;
                data[main] = data[main] || {};
                
                if (type === 'checkbox') {
                    data[main][sub] = data[main][sub] || [];
                    data[main][sub].push(val);
                } else {
                    data[main][sub] = val;
                }
            } else {
                if (type === 'checkbox') {
                    data[key] = data[key] || [];
                    data[key].push(val);
                } else {
                    data[key] = val;
                }
            }
        });
        
        return data;
    }
    
    function change_panel_html(response) {
        $('.modal').modal('hide');
        $('.modal-backdrop').remove();
        $('.tooltip').remove();
        if (response.main) {
            $('.nk-app-root').html(response.main);
            NioApp.ajaxInit();
        }
        if (response.title) {
            document.title = response.title;
        }
        if (response.message) {
            NioApp.Toast(response.message, response.status, {position: 'top-right'});
        }
    }
    
    $(document).ajaxSend(function() {
        if (ajax_search) {
            return;
        }
        show_loading_modal();
    });
    $(document).ajaxStop(function() {
        hide_loading_modal();
    });
    
    $(document).on('input', '.price_input', function() {
        toEnglishNumber($(this).val(), this);
        
        let hasDecimal = $(this).data('decimal') == 1;
        let value = String(this.value || '');
        
        // تبدیل ممیز فارسی/عربی به نقطه
        value = value.replace(/\u066B/g, '.'); // ٫ -> .
        
        if (hasDecimal) {
            // فقط عدد و نقطه مجاز باشد
            value = value.replace(/[^0-9.]/g, '');
            
            // اگر چندتا نقطه وارد شد، فقط اولی بماند
            let parts = value.split('.');
            let intPart = parts[0] || '';
            let decimalPart = parts.length > 1 ? parts.slice(1).join('') : null;
            
            if (intPart === '' && decimalPart === null) {
                $(this).val('');
                return;
            }
            
            intPart = intPart.replace(/\D/g, '');
            
            let formatted = intPart !== '' ? number_format(intPart) : '';
            
            if (decimalPart !== null) {
                formatted += '.' + decimalPart;
            }
            
            $(this).val(formatted);
            return;
        }
        
        // حالت قبلی: بدون اعشار
        value = value.replace(/\D/g, '');
        
        if (value === '') {
            $(this).val('');
            return;
        }
        
        $(this).val(number_format(value));
    });
    
    $(document).on('click', '.filter_drop_down_toggle', function(e) {
        e.stopPropagation();
        $(this).next('.filters_input_box').toggleClass('show');
        NioApp.Select2.init();
    });
    $(document).on('click', 'body', function() {
        $('.filters_input_box').removeClass('show');
    });
    $(document).on('click', '.page_activator', function(e) {
        e.preventDefault();
        request_panel_page_content($(this).attr('data-url'));
    });
    $(window).on('popstate', function() {
        let data = {
            'action': 'crm_request_back_btn',
            'path':   window.location.href,
        };
        $.post(ajax_url, data, function(response) {
            change_panel_html(response);
        });
    });
    $(document).on('change', '.datepicker', function() {
        let val = $(this).val();
        if (val === '') {
            $(this).attr('data-value', '');
            $(this).attr('data-gdate', '');
            $(this).attr('data-jdate', '');
        }
    });
    $(document).on('click', '.pdp-default', function(e) {
        e.stopPropagation();
    });
    $(document).on('click', '.language-item', function() {
        let skin = $(this).attr('data-skin');
        let data = {
            'action': 'crm_change_skin',
            'skin':   skin,
        };
        $.post(ajax_url, data, function() {
            location.reload();
        });
    });
    
    $(document).on('click', '.submit_login_form', function() {
        let data = {
            action:   'crm_submit_login_form',
            username: $('#username').val(),
            password: $('#password').val(),
        };
        if (data.username === '' || data.password === '') {
            NioApp.Toast('نام کاربری و رمز عبور را وارد کنید', 'error', {position: 'top-right'});
            return;
        }
        $.post(ajax_url, data, function(response) {
            NioApp.Toast(response.message, response.status, {position: 'top-right'});
            if (response.status === 'error') {
                return;
            }
            location.reload();
        });
    });
    $(document).on('click', '.send_otp', function() {
        let phone = $('#otp_phone').val();
        if (phone === '') {
            NioApp.Toast('شماره تلفن همراه را وارد کنید', 'error', {position: 'top-right'});
            return;
        }
        if (!validate_phone_number(phone)) {
            NioApp.Toast('شماره تلفن همراه معتبر نیست', 'error', {position: 'top-right'});
            return;
        }
        
        let data = {
            action: 'crm_send_login_otp',
            phone:  phone,
        };
        $.post(ajax_url, data, function(response) {
            NioApp.Toast(response.message, response.status, {position: 'top-right'});
            if (response.status === 'error') {
                return;
            }
            $('.each_login_form').removeClass('active');
            $('.otp_login_text').text(`کد تایید برای شماره ${phone} پیامک شد`);
            $('#submit_otp_form').addClass('active');
            focus_first_otp_input();
            clearInterval(timer_interval);
            start_timer();
            activate_otp_inputs();
        });
    });
    $(document).on('click', '.otp_timer', function() {
        let phone = $('#otp_phone').val();
        let data = {
            action: 'crm_send_login_otp',
            phone:  phone,
        };
        $.post(ajax_url, data, function(response) {
            NioApp.Toast(response.message, response.status, {position: 'top-right'});
            if (response.status === 'error') {
                return;
            }
            $('.each_login_form').removeClass('active');
            $('.otp_login_text').text(`کد تایید برای شماره ${phone} پیامک شد`);
            $('#submit_otp_form').addClass('active');
            focus_first_otp_input();
            clearInterval(timer_interval);
            start_timer();
            activate_otp_inputs();
        });
    });
    
    $(document).on('click', '.submit_otp', function() {
        let phone = $('#otp_phone').val(),
            otp   = $('#otp_input_form').attr('data-code');
        if (!otp || otp.length < 4) {
            NioApp.Toast('کد تایید را وارد کنید', 'error', {position: 'top-right'});
            return;
        }
        let data = {
            action: 'crm_submit_login_otp',
            phone:  phone,
            otp:    otp,
        };
        $.post(ajax_url, data, function(response) {
            NioApp.Toast(response.message, response.status, {position: 'top-right'});
            if (response.status === 'error') {
                focus_first_otp_input();
                return;
            }
            location.reload();
        });
    });
    $(document).on('click', '.toggle_login_form', function() {
        $('.each_login_form').removeClass('active');
        let id = $(this).attr('data-url');
        $(id).addClass('active');
    });
    $(document).on('click', '.change_pass', function() {
        let old_pass = $('#old_password').val();
        let new_pass = $('#new_password').val();
        let rep_pass = $('#confirm_password').val();
        if (new_pass !== rep_pass) {
            NioApp.Toast('رمز عبور جدید و تکرار آن باید یکسان باشند', 'error', {position: 'top-right'});
            return;
        }
        const input = {
            old_pass: old_pass,
            new_pass: new_pass,
            action:   'crm_submit_change_password_form',
        };
        $.post(ajax_url, input, function(response) {
            if (response.status === 'failed') {
                NioApp.Toast(response.msg, 'error', {position: 'top-right'});
            } else {
                NioApp.Toast(response.msg, 'success', {position: 'top-right'});
                location.reload();
            }
        });
    });
    let search_ajax;
    $(document).on('input', '#header_user_search', function(e) {
        ajax_search = true;
        let result = $('.search_result_container');
        if (this.value === '') {
            result.html('').hide();
            return;
        }
        if (typeof search_ajax === 'object') {
            search_ajax.abort();
        }
        result.show();
        let data = {
            action: 'crm_search_user',
            search: this.value,
        };
        search_ajax = $.post(ajax_url, data, function(response) {
            result.html(response.searchResult);
            ajax_search = false;
        });
    });
    $(document).on('click', 'body', function() {
        $('.search_result_container').hide();
    });
    $(document).on('click', '.card-search', function(e) {
        e.stopPropagation();
        $('.search_result_container').show();
    });
    
    $(document).on('click', '.dark-switch', function(e) {
        let is_active = $(this).hasClass('active');
        let data = {
            action:    'crm_save_dark_mode',
            is_active: is_active,
        };
        ajax_search = true;
        $.post(ajax_url, data, function() {
            ajax_search = false;
        });
    });
    $(document).on('click', '[data-bs-target="#addCustomer"]', function() {
        let search = $('#header_user_search').val();
        let is_numeric = parseInt(search) == search;
        if (is_numeric) {
            $('#new_customer_phone').val(search);
        } else {
            $('#new_customer_user_name').val(search);
        }
    });
    $(document).on('click', '#register_new_user', function() {
        let phone = $('#new_customer_phone');
        let name = $('#new_customer_user_name');
        let intro = $('#new_customer_intro_id');
        let shop = $('#new_customer_shop');
        let groups = $('#new_customer_group');
        let types = $('#new_customer_type');
        
        if (!name.val() || !phone.val()) {
            NioApp.Toast('نام و شماره تلفن را وارد کنید', 'error',
                {position: 'top-right'});
            return;
        }
        if (!intro.val()) {
            NioApp.Toast('شیوه آشنایی ضروری است.', 'error',
                {position: 'top-right'});
            return;
        }
        let full_name = name.val();
        let first_name,
            last_name;
        first_name = full_name.substr(0, full_name.indexOf(' '));
        last_name = full_name.substr(full_name.indexOf(' ') + 1);
        if (!first_name || !last_name) {
            NioApp.Toast('نام و نام خانوادگی را به صورت کامل وارد کنید',
                'error',
                {position: 'top-right'});
            return;
        }
        if (!validate_phone_number(phone.val())) {
            // NioApp.Toast('شماره تلفن همراه معتبر نیست', 'error',
            //     {position: 'top-right'});
            // return;
        }
        
        let data = {
            action:     'crm_add_user',
            phone:      phone.val(),
            first_name: first_name,
            last_name:  last_name,
            intro:      intro.val(),
            groups:     groups.val(),
            types:      types.val(),
            shop:       shop.val(),
        };
        $.post(ajax_url, data, function(response) {
            change_panel_html(response);
            history.pushState({}, '', response.url);
        });
    });
    $(document).on('click', '.change_per_page a', function(e) {
        e.preventDefault();
    });
    $(document).on('click', '.change_list_order a', function(e) {
        e.preventDefault();
    });
    $(document).on('click', '.delete_user', function(e) {
        e.preventDefault();
        let user_id = $(this).attr('data-user-id');
        let page = $(this).attr('data-page');
        let data = {
            action:  'crm_delete_user',
            user_id: user_id,
            page:    page,
        };
        Swal.fire({
            title:             'آیا از حذف این کاربر اطمینان دارید؟',
            icon:              'warning',
            text:              'این عملیات غیر قابل بازگشت است',
            focusConfirm:      false,
            showCancelButton:  true,
            confirmButtonText: 'بله',
            cancelButtonText:  `خیر`,
        }).then((result) => {
            if (result.isConfirmed) {
                $.post(ajax_url, data, function(response) {
                    change_panel_html(response);
                    history.pushState({}, '', response.url);
                });
            }
        });
    });
    $(document).on('click', '.change_per_page', function() {
        let per_page = $(this).attr('data-per-page');
        let currentPage = $('#current_page').val();
        let sort_order = $('.change_list_order.active').attr('data-order');
        
        let data = {
            action:     'crm_request_page_content',
            page:       currentPage,
            per_page:   per_page,
            sort_order: sort_order,
        };
        $.post(ajax_url, data, function(response) {
            change_panel_html(response);
            history.pushState({}, '', response.url);
        });
    });
    $(document).on('click', '.change_list_order', function() {
        let sort_order = $(this).attr('data-order');
        let currentPage = $('#current_page').val();
        let per_page = $('.change_per_page.active').attr('data-per-page');
        
        let data = {
            action:     'crm_request_page_content',
            page:       currentPage,
            per_page:   per_page,
            sort_order: sort_order,
        };
        $.post(ajax_url, data, function(response) {
            change_panel_html(response);
            history.pushState({}, '', response.url);
        });
    });
    $(document).on('click', '.page-link', function(e) {
        e.preventDefault();
    });
    $(document).on('click', '.reset_page_filter', function(e) {
        e.preventDefault();
        let data = {
            action: 'crm_request_page_content',
            page:   $('#current_page').val(),
        };
        $.post(ajax_url, data, function(response) {
            change_panel_html(response);
            history.pushState({}, '', response.url);
        });
    });
    $(document).on('change', '.activate_logic', function() {
        let id = $(this).attr('data-target');
        let selected = this.value;
        $('.conditional_show[data-logic=\'' + id + '\']').each(function() {
            let logic = $(this).attr('data-value');
            if (logic === selected) {
                $(this).show();
            } else {
                $(this).hide();
            }
        });
    });
    $(document).on('click', '.page-item', function() {
        let currentPage = $('#current_page').val();
        let page = $(this).attr('data-page');
        let data = get_current_page_filters();
        data.action = 'crm_request_page_content';
        data.page = currentPage;
        data.page_number = page;
        $.post(ajax_url, data, function(response) {
            change_panel_html(response);
            history.pushState({}, '', response.url);
        });
    });
    $(document).on('click', '.filter_crm_list', function() {
        let currentPage = $('#current_page').val();
        let data = get_current_page_filters();
        let sort_order = $('.change_list_order.active').attr('data-order');
        data.action = 'crm_request_page_content';
        data.page = currentPage;
        data.sort_order = sort_order;
        
        $.post(ajax_url, data, function(response) {
            change_panel_html(response);
            history.pushState({}, '', response.url);
        });
    });
    $(document).on('keydown', '.filter_form_wrapper input', function(e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            $('.filter_crm_list').trigger('click');
        }
    });
    $(document).on('change', '.filter_form_wrapper input', function() {
        // $('.filter_crm_list').trigger('click');
    });
    $(document).on('input', '.search_crm_list', function() {
        ajax_search = true;
        let currentPage = $('#current_page').val();
        let data = get_current_page_filters();
        
        if (typeof search_ajax === 'object') {
            search_ajax.abort();
        }
        data.action = 'crm_request_page_content';
        data.page = currentPage;
        search_ajax = $.post(ajax_url, data, function(response) {
            change_panel_html(response);
            history.pushState({}, '', response.url);
            const $input = $('.search_crm_list');
            $input.trigger('focus');
            const val = $input.val();
            $input.val('').val(val);
            ajax_search = false;
        });
    });
    
    $(document).on('click', '#update_user_personal_data', function(e) {
        let inputs = $('#editPersonal').find('input, select');
        let data = {
            action: 'crm_update_user_personal_data',
            id:     $('#current_user_id').val(),
            meta:   {},
            page:   $('#current_page').val(),
        };
        inputs.each(function() {
            let key = $(this).attr('data-for');
            let val = $(this).val();
            if ($(this).hasClass('price_input')) {
                val = sanitizeNumber(val);
            }
            if (val) {
                data.meta[key] = val;
            }
        });
        $.post(ajax_url, data, function(response) {
            change_panel_html(response);
            history.pushState({}, '', response.url);
        });
    });
    
    $(document).on('click', '#create_new_employee', function() {
        let name = $('#new_marketer_name').val();
        let username = $('#new_marketer_username').val();
        let phone = $('#new_marketer_phone').val();
        let role = $('#new_marketer_role').val();
        if (!name || !username) {
            NioApp.Toast('نام و نام کاربری را وارد کنید', 'error', {position: 'top-right'});
            return;
        }
        if (!validate_slug(username)) {
            NioApp.Toast('نام کاربری باید شامل حروف انگلیسی و اعداد باشد', 'error', {position: 'top-right'});
            return;
        }
        let first_name,
            last_name;
        first_name = name.substr(0, name.indexOf(' '));
        last_name = name.substr(name.indexOf(' ') + 1);
        if (!first_name || !last_name) {
            NioApp.Toast('نام و نام خانوادگی را به صورت کامل وارد کنید', 'error', {position: 'top-right'});
            return;
        }
        let data = {
            action:     'crm_add_employee',
            first_name: first_name,
            last_name:  last_name,
            username:   username,
            phone:      phone,
            role:       role,
        };
        $.post(ajax_url, data, function(response) {
            change_panel_html(response);
            history.pushState({}, '', response.url);
        });
    });
    $(document).on('click', '.login_as_this', function(e) {
        e.preventDefault();
        let user_id = $(this).attr('data-id');
        let data = {
            action:  'crm_login_as_user',
            user_id: user_id,
        };
        $.post(ajax_url, data, function(response) {
            window.location.href = response.url;
        });
    });
    $(document).on('click', '.change_role', function() {
        let user_id = $(this).parents('.employees_row').attr('data-id');
        let select_role = $('#new_marketer_role').html();
        let modal = Swal.mixin({
            title:             'تغییر نقش کارمند',
            html:              '<div class="form-group">' +
                                   '<label class="form-label" for="new_marketer_role">نقش</label>' +
                                   '<div class="form-control-wrap">' +
                                   '<select class="form-select" id="edit_user_role">' + select_role + '</select>' +
                                   '</div>' +
                                   '</div>',
            focusConfirm:      false,
            showCancelButton:  true,
            confirmButtonText: 'ذخیره تغییرات',
            cancelButtonText:  `لغو`,
            onRender:          function() {
                activate_date_pickers();
            },
        });
        modal.fire().then(function(result) {
            if (result.isConfirmed) {
                let data = {
                    action:  'crm_update_user_role',
                    user_id: user_id,
                    role:    $('#edit_user_role').val(),
                };
                $.post(ajax_url, data, function(response) {
                    change_panel_html(response);
                    NioApp.Toast(response.msg, 'success', {position: 'top-right'});
                });
            }
        });
    });
    $(document).on('click', 'a.btn-trigger', function(e) {
        e.preventDefault();
    });
    $(document).on('click', '.reset_password', function(e) {
        e.preventDefault();
        let user_id = $(this).attr('data-id');
        let data = {
            action:  'crm_reset_password',
            user_id: user_id,
        };
        $.post(ajax_url, data, function(response) {
            Swal.fire({
                title:             'رمز عبور تغییر کرد.',
                html:              response.html,
                focusConfirm:      false,
                confirmButtonText: 'باشه',
            });
        });
    });
    $(document).on('click', '.save_site_settings', function() {
        let inputs = $('.site_setting_field');
        let options = {};
        inputs.each(function() {
            let key = $(this).attr('data-for');
            if ($(this).attr('type') === 'checkbox') {
                options[key] = $(this).is(':checked');
            } else {
                options[key] = $(this).val();
            }
        });
        let data = {
            action:  'crm_save_site_settings',
            options: options,
            tab:     $(this).attr('data-tab'),
        };
        $.post(ajax_url, data, function(response) {
            change_panel_html(response);
            history.pushState({}, '', response.url);
        });
    });
    
    $(document).on('input', '.search_user_modal', function(e) {
        ajax_search = true;
        let result = $('.customer_search_result');
        if (this.value === '') {
            result.html('').hide();
            return;
        }
        if (typeof search_ajax === 'object') {
            search_ajax.abort();
        }
        result.show();
        let data = {
            action: 'crm_search_user_for_modal',
            search: this.value,
        };
        search_ajax = $.post(ajax_url, data, function(response) {
            result.html(response.searchResult);
            ajax_search = false;
        });
    });
    
    $(document).on('input', '.search_product_modal', function(e) {
        ajax_search = true;
        let result = $('.customer_search_result');
        if (this.value === '') {
            result.html('').hide();
            return;
        }
        if (typeof search_ajax === 'object') {
            search_ajax.abort();
        }
        result.show();
        let data = {
            action: 'crm_search_product_for_modal',
            search: this.value,
        };
        search_ajax = $.post(ajax_url, data, function(response) {
            result.html(response.searchResult);
            ajax_search = false;
        });
    });
    
    $(document).on('click', '.each_user_search_result_row', function() {
        let search_result = $(this).parents('.customer_search_result');
        search_result.html('');
        let input = search_result.attr('data-input');
        let preview = search_result.attr('data-preview');
        $('.search_user_modal').val('');
        $(input).val($(this).attr('data-id')).trigger('change');
        $(preview).html(this.innerHTML);
    });
    
    $(document).on('click', '.select_current_user_for_modal', function() {
        let input = $(this).attr('data-input');
        $('.hide_on_profile').remove();
        $(input).val($(this).attr('data-id'));
    });
    
    $(document).on('click', '.submit_track_check', function(e) {
        e.preventDefault();
        let item_id = $(this).attr('data-item-id');
        $('#changeTrackStatus').modal('show');
        $('#change_track_status_id').val(item_id);
    });
    
    $(document).on('click', '.change_visit_status', function(e) {
        e.preventDefault();
        let item_id = $(this).attr('data-item-id');
        let status = $(this).attr('data-status');
        let user_id = $(this).attr('data-user-id');
        $('#change_visit_status_user_id').val(user_id);
        $('#change_visit_status_id').val(item_id);
        $('#change_visit_status_input').val(status);
        if (status === 'finished') {
            $('[data-name="change_visit_status_detail"] .ql-editor').html('ارجاع ویزیت به فاکتور');
        } else {
            $('[data-name="change_visit_status_detail"] .ql-editor').html('');
            $('#changeVisitStatus').modal('show');
        }
        if (user_id != 0) {
            $('.hide_on_profile').hide();
            if (status === 'finished') {
                $('#change_visit_status').trigger('click');
            }
        } else {
            $('.hide_on_profile').show();
            $('#changeVisitStatus').modal('show');
        }
    });
    $(document).on('click', '.change_call_status', function(e) {
        e.preventDefault();
        let item_id = $(this).attr('data-item-id');
        $('#changeCallStatus').modal('show');
        $('#change_call_status_id').val(item_id);
    });
    
    $(document).on('click', '.view_stock_log_steps', function(e) {
        e.preventDefault();
        let item_id = $(this).attr('data-item-id');
        let data = {
            action:  'crm_get_stock_log_steps',
            item_id: item_id,
        };
        $.post(ajax_url, data, function(response) {
            $('#stockLogSteps').modal('show');
            $('#stockLogSteps .modal-body').html(response.html);
            NioApp.BS.tooltip('[data-bs-toggle="tooltip"]');
        });
    });
    $(document).on('click', '.view_call_progress', function(e) {
        e.preventDefault();
        let item_id = $(this).attr('data-item-id');
        let data = {
            action:  'crm_get_call_progress',
            item_id: item_id,
        };
        $.post(ajax_url, data, function(response) {
            $('#callProgressModal').modal('show');
            $('#callProgressModal .modal-body').html(response.html);
        });
    });
    $(document).on('change', '#new_user_call_category', function(e) {
        ajax_search = true;
        let data = {
            action:   'crm_get_call_category_users',
            category: $(this).val(),
        };
        $.post(ajax_url, data, function(response) {
            ajax_search = false;
            $('#new_user_call_assign').html(response.html);
        });
    });
    $(document).on('change', '#new_hr_call_category', function(e) {
        ajax_search = true;
        let data = {
            action:   'crm_get_call_category_users',
            category: $(this).val(),
        };
        $.post(ajax_url, data, function(response) {
            ajax_search = false;
            $('#new_hr_call_assign').html(response.html);
        });
    });
    $(document).on('change', '#change_call_new_category', function(e) {
        ajax_search = true;
        let data = {
            action:   'crm_get_call_category_users',
            category: $(this).val(),
        };
        $.post(ajax_url, data, function(response) {
            ajax_search = false;
            $('#change_call_status_assign').html(response.html);
        });
    });
    
    $(document).on('change', '#log_action', function() {
        let stock_out = $('.transfer_out_stock_cul');
        switch ($(this).val()) {
            case 'import':
                stock_out.hide();
                break;
            case 'export':
                stock_out.hide();
                break;
            case 'transfer':
                stock_out.show();
                break;
        }
    });
    $(document).on('change', '#log_product_sku', function(e) {
        let input = $(this);
        let title = $('.stock_log_product_sku_title');
        ajax_search = true;
        let data = {
            action: 'crm_search_product_sku',
            search: input.val(),
            for:    'stock_log',
        };
        search_ajax = $.post(ajax_url, data, function(response) {
            ajax_search = false;
            if (response.status === 'error') {
                input.val('');
                title.html('');
                NioApp.Toast(response.msg, 'error', {position: 'top-right'});
                return;
            }
            title.html(response.title);
        });
    });
    $(document).on('click', '#submit_stock_log', function() {
        let sku = $('#log_product_sku').val();
        let action = $('#log_action').val();
        let qty = $('#log_product_qty').val();
        qty = sanitizeNumber(qty);
        let details = $('[data-name="stock_log_details"] .ql-editor').html();
        let stock = $('#log_stock').val();
        if (!stock) {
            NioApp.Toast('یک انبار انتخاب کنید', 'error',
                {position: 'top-right'});
            return;
        }
        if (!action) {
            NioApp.Toast('بارکد وارد نشده است', 'error',
                {position: 'top-right'});
            return;
        }
        if (!qty) {
            NioApp.Toast('تعداد کالا را وارد کنید', 'error',
                {position: 'top-right'});
            return;
        }
        if (qty == 0) {
            NioApp.Toast('تعداد نمی تواند صفر باشد', 'error',
                {position: 'top-right'});
            return;
        }
        let destinations = $('#log_stock_transfer_from').val();
        if (action === 'transfer' && !destinations) {
            NioApp.Toast('انبار مبدا انتقال را انتخاب کنید', 'error',
                {position: 'top-right'});
            return;
        }
        if (action === 'transfer' && destinations == stock) {
            NioApp.Toast('انبار مبدا و مقصد نمی تواند یکی باشد', 'error',
                {position: 'top-right'});
            return;
        }
        let data = {
            action:         'crm_new_stock_log',
            new_sku:        sku,
            new_log_action: action,
            qty:            qty,
            details:        details,
            new_stock:      stock,
            destinations:   destinations,
        };
        search_ajax = $.post(ajax_url, data, function(response) {
            change_panel_html(response);
            history.pushState({}, '', response.url);
        });
    });
    $(document).on('click', '#add_warning_template', function() {
        let title       = $('#warning_template_title').val(),
            template    = $('#warning_template_template').val(),
            template_id = $('#warning_template_id').val(),
            token1      = $('#warning_template_token1').val(),
            token2      = $('#warning_template_token2').val(),
            token3      = $('#warning_template_token3').val();
        if (!title) {
            NioApp.Toast('عنوان ضروری است.', 'error',
                {position: 'top-right'});
            return;
        }
        if (!template) {
            NioApp.Toast('نام الگو ضروری است.', 'error',
                {position: 'top-right'});
            return;
        }
        if (!token1) {
            NioApp.Toast('حداقل متغیر اول برای ثبت الگو ضروری است.', 'error',
                {position: 'top-right'});
            return;
        }
        let data = {
            action:      'crm_add_warning_template',
            template_id: template_id,
            title:       title,
            template:    template,
            token1:      token1,
            token2:      token2,
            token3:      token3,
        };
        search_ajax = $.post(ajax_url, data, function(response) {
            change_panel_html(response);
            history.pushState({}, '', response.url);
        });
    });
    $(document).on('click', '.edit_warning_template', function(e) {
        e.preventDefault();
        let item_id  = $(this).attr('data-item-id'),
            title    = $(this).attr('data-title'),
            template = $(this).attr('data-template'),
            token1   = $(this).attr('data-token1'),
            token2   = $(this).attr('data-token2'),
            token3   = $(this).attr('data-token3');
        $('#addWarningTemplate').modal('show');
        $('#warning_template_id').val(item_id);
        $('#warning_template_title').val(title);
        $('#warning_template_template').val(template);
        $('#warning_template_token1').val(token1);
        $('#warning_template_token2').val(token2);
        $('#warning_template_token3').val(token3);
    });
    $(document).on('click', '.send_alert_employee', function(e) {
        e.preventDefault();
        let user_id = $(this).attr('data-id');
        $('#sendWarning').modal('show');
        $('#send_warning_to_user').val(user_id);
    });
    
    $(document).on('click', '#send_warning_template', function(e) {
        e.preventDefault();
        let user_id     = $('#send_warning_to_user').val(),
            template_id = $('#send_warning_template_id').val();
        if (!template_id) {
            NioApp.Toast('اخطاریه را انتخاب کنید.', 'error',
                {position: 'top-right'});
            return;
        }
        let data = {
            action:      'crm_send_warning_template',
            template_id: template_id,
            user_id:     user_id,
        };
        Swal.fire({
            title:             'آیا از ارسال این مورد اطمینان دارید؟',
            icon:              'warning',
            focusConfirm:      false,
            showCancelButton:  true,
            confirmButtonText: 'بله',
            cancelButtonText:  `خیر`,
        }).then((result) => {
            if (result.isConfirmed) {
                $.post(ajax_url, data, function(response) {
                    change_panel_html(response);
                    history.pushState({}, '', response.url);
                });
            }
        });
    });
    
    $(document).on('click', '.delete_warning_template', function(e) {
        e.preventDefault();
        let data = {
            action:  'crm_delete_warning_template',
            item_id: $(this).attr('data-item-id'),
        };
        Swal.fire({
            title:             'آیا از حذف این مورد اطمینان دارید؟',
            icon:              'warning',
            text:              'این عملیات غیر قابل بازگشت است',
            focusConfirm:      false,
            showCancelButton:  true,
            confirmButtonText: 'بله',
            cancelButtonText:  `خیر`,
        }).then((result) => {
            if (result.isConfirmed) {
                $.post(ajax_url, data, function(response) {
                    change_panel_html(response);
                    history.pushState({}, '', response.url);
                });
            }
        });
    });
    $(document).on('click', '[data-bs-target="#addCustomer_for_modal"]', function() {
        let modal = $(this).parents('.modal');
        let search = modal.find('.search_user_modal').val();
        let is_numeric = parseInt(search) == search;
        if (is_numeric) {
            $('#new_customer_phone_for_modal').val(search);
        } else {
            $('#new_customer_user_name_for_modal').val(search);
        }
        $('#modal_to_open').val($(modal).attr('id'));
    });
    $(document).on('click', '#register_new_user_for_modal', function() {
        let phone = $('#new_customer_phone_for_modal');
        let name = $('#new_customer_user_name_for_modal');
        let intro = $('#new_customer_intro_id_for_modal');
        if (!name.val() || !phone.val()) {
            NioApp.Toast('نام و شماره تلفن را وارد کنید', 'error',
                {position: 'top-right'});
            return;
        }
        if (!intro.val()) {
            NioApp.Toast('شیوه آشنایی ضروری است.', 'error',
                {position: 'top-right'});
            return;
        }
        let full_name = name.val();
        let first_name,
            last_name;
        first_name = full_name.substr(0, full_name.indexOf(' '));
        last_name = full_name.substr(full_name.indexOf(' ') + 1);
        if (!first_name || !last_name) {
            NioApp.Toast('نام و نام خانوادگی را به صورت کامل وارد کنید',
                'error',
                {position: 'top-right'});
            return;
        }
        if (!validate_phone_number(phone.val())) {
            NioApp.Toast('شماره تلفن همراه معتبر نیست', 'error',
                {position: 'top-right'});
            return;
        }
        
        let data = {
            action:     'crm_add_user',
            phone:      phone.val(),
            first_name: first_name,
            last_name:  last_name,
            intro:      intro.val(),
            target:     'modal',
        };
        $.post(ajax_url, data, function(response) {
            let modal_id = $('#modal_to_open').val();
            hide_loading_modal();
            $('#addCustomer_for_modal').modal('hide');
            NioApp.Toast(response.message, 'success', {position: 'top-right'});
            if (!modal_id) {
                $('.customer_box').html(response.html);
                $('.customer_search_result').html('');
                $('#new_order_customer_id').val(response.user_id).trigger('change');
            } else {
                let modal = $('#' + modal_id);
                modal.modal('show');
                let result = modal.find('.customer_search_result');
                let preview = result.attr('data-preview');
                let input = result.attr('data-input');
                $(preview).html(response.html);
                $(input).val(response.user_id);
                $(result).html('');
                modal.find('.search_user_modal').val('');
            }
        });
    });
    $(document).on('hidden.bs.modal', '#addCustomer_for_modal', function(e) {
        let modal_id = $('#modal_to_open').val();
        if (!modal_id) {
            return;
        }
        let modal = $('#' + modal_id);
        modal.modal('show');
    });
    $(document).on('click', '#open_addUserAddress', function(e) {
        e.preventDefault();
        let user_id = $('#new_order_customer_id').val();
        if (!user_id) {
            user_id = $(this).attr('data-id');
            if (!user_id) {
                NioApp.Toast('پیش از ثبت آدرس مشتری را انتخاب کنید.', 'error', {position: 'top-right'});
                return;
            }
        }
        $('#save_address_user_id').val(user_id);
        $('#addUserAddress').modal('show');
    });
    $(document).on('click', '.address_for_main_customer', function() {
        if (!$('#address_for_main_customer').is(':checked')) {
            $('#address_first_name').val('');
            $('#address_last_name').val('');
            $('#address_phone').val('');
        } else {
            $('#address_first_name').val($('#customer_first_name_default').val());
            $('#address_last_name').val($('#customer_last_name_default').val());
            $('#address_phone').val($('#customer_phone_num_default').val());
        }
    });
    $(document).on('change', '#new_order_customer_id', function(e) {
        let user_id = $(this).val();
        if (!user_id) {
            return;
        }
        let data = {
            action:  'crm_load_user_address',
            user_id: user_id,
        };
        $.post(ajax_url, data, function(response) {
            $('.address_wrapper').html(response.html);
            NioApp.Control('.custom-control-input');
        });
    });
    $(document).on('change', '#new_order_customer_id', function(e) {
        let user_id = $(this).val();
        if (!user_id) {
            return;
        }
        let data = {
            action:  'crm_load_user_referral_block',
            user_id: user_id,
        };
        $.post(ajax_url, data, function(response) {
            if (response.status == 'valid') {
                $('.order_referrer_block_card').remove();
                $('.product_block_card').after(response.html);
                NioApp.Control('.custom-control-input');
            }
        });
    });
    $(document).on('click', '#set_referral_code_for_user', function(e) {
        
        let data = {
            action:  'crm_set_referral_code_for_user',
            user_id: $(this).attr('data-user-id'),
            code:    $('#referral_code_input').val(),
        };
        $.post(ajax_url, data, function(response) {
            NioApp.Toast(response.msg, response.status, {position: 'top-right'});
            if (response.status == 'success') {
                $('.order_referrer_block_card').remove();
                $('.product_block_card').after(response.html);
                NioApp.Control('.custom-control-input');
            }
        });
    });
    $(document).on('click', '.each_product_search_result_row', function(e) {
        let data = {
            action:     'crm_load_product_block',
            product_id: $(this).attr('data-id'),
        };
        $.post(ajax_url, data, function(response) {
            if (response.status == 'success') {
                $('.product_search_list').html('');
                $('.product_search_result').html(response.html);
                NioApp.NumberSpinner();
            } else {
                NioApp.Toast(response.message, response.status, {position: 'top-right'});
                $('#search_sku_for_order').val('');
                $('.product_search_result').html('');
                $('.product_search_list').html('');
            }
        });
    });
    $(document).on('input', '#search_sku_for_order', function(e) {
        if (this.value === '') {
            $('.product_search_result').html('');
            return;
        }
        ajax_search = true;
        let data = {
            action: 'crm_search_sku_for_order',
            search: this.value,
        };
        $.post(ajax_url, data, function(response) {
            ajax_search = false;
            if (response.status == 'success') {
                $('.product_search_result').html(response.html);
                NioApp.NumberSpinner();
            } else if (response.status == 'list') {
                $('.product_search_list').html(response.html);
            } else {
                NioApp.Toast(response.message, response.status, {position: 'top-right'});
                $('#search_sku_for_order').val('');
                $('.product_search_result').html('');
                $('.product_search_list').html('');
            }
        });
    });
    $(document).on('change', '.toggle_product_stock', function(e) {
        let slug = this.value;
        $(`.stock_spinner`).removeClass('d-block').addClass('d-none');
        $(`.stock_spinner[data-for="${slug}"]`).addClass('d-block').removeClass('d-none');
    });
    
    $(document).on('input', '.order_factor_card input', function() {
        calc_factor_total(this);
    });
    $(document).on('click', '.use_referrer_discount', function() {
        calc_factor_total();
    });
    
    function calc_factor_total(el = false) {
        let card = $('.order_factor_card');
        let tbody = card.find('tbody');
        let items = tbody.find('tr');
        let total = 0;
        let subtotal = 0;
        
        items.each(function() {
            let line_qty = $(this).find('.line_qty');
            let qty = sanitizeNumber(line_qty.val(), true);
            let reg_price = sanitizeNumber($(this).find('.item_reg_total').val());
            let off = sanitizeNumber($(this).find('.item_off_percent').val());
            let percent = (100 - off) / 100;
            let price = reg_price * percent;
            let line_total = price * qty;
            
            $(this).find('.item_subtotal').val(number_format(price));
            $(this).find('.line_total').val(number_format(line_total));
            
            total += reg_price * qty;
            subtotal += line_total;
        });
        
        let total_discount = total - subtotal;
        
        card.find('.order_subtotal').text(number_format(total));
        card.find('.order_discount').text(number_format(total_discount));
        card.find('.order_total').text(number_format(subtotal));
        
        let final_price = subtotal;
        
        let custom_fee = sanitizeNumber($('.order_custom_fee').val());
        let custom_extra_fee = sanitizeNumber($('.order_custom_extra_fee').val());
        
        let payment_items = $('.cash_payment_table tr');
        let beyane = 0;
        
        payment_items.each(function() {
            let amount = sanitizeNumber($(this).find('.payment_amount').text());
            beyane += amount;
        });
        
        $('.cart_total_beyane').text(number_format(beyane));
        
        let referral_discount = 0;
        
        if ($('#use_referrer_discount').is(':checked')) {
            referral_discount = sanitizeNumber($('.use_referrer_discount').attr('data-amount'));
            $('.cart_referral_discount').text(number_format(referral_discount));
        } else {
            $('.cart_referral_discount').text(number_format(0));
        }
        
        /**
         * پایه مبلغ قابل پرداخت قبل از محاسبه تفاوت مدت
         *
         * custom_fee              => تخفیف روی کل سفارش
         * custom_extra_fee        => میزان بالابرد
         * beyane                  => پیش پرداخت
         * referral_discount       => تخفیف معرف
         */
        final_price = final_price - beyane - custom_fee - referral_discount + custom_extra_fee;
        
        let payment_fee = 0;
        let payment_type = $('input[name="payment_type"]:checked').val();
        
        if (payment_type == 'pay_monthly') {
            let payment_data = $('#monthly_payment_json').text();
            let percentageObject = JSON.parse(payment_data);
            
            let monthCount = sanitizeNumber($('#month_count').val());
            let chequeCount = sanitizeNumber($('#cheque_count').val());
            
            let basePercentage = 0;
            
            if (
                percentageObject[chequeCount] !== undefined &&
                percentageObject[chequeCount][monthCount] !== undefined
            ) {
                basePercentage = percentageObject[chequeCount][monthCount];
            }
            
            if (basePercentage === undefined || basePercentage === 0 || basePercentage === '') {
                if (percentageObject[chequeCount] !== undefined) {
                    const nextHigherMonth = Object.keys(percentageObject[chequeCount]).
                        map(Number).
                        filter((months) => months > monthCount).
                        sort((a, b) => a - b)[0];
                    
                    if (nextHigherMonth) {
                        basePercentage = percentageObject[chequeCount][nextHigherMonth];
                    }
                }
            }
            
            if (basePercentage) {
                $('#monthly_payment_percent').val(basePercentage);
                
                let monthPercent = monthCount * basePercentage;
                
                payment_fee = (final_price * monthPercent) / 100;
                payment_fee = parseInt(payment_fee);
            } else {
                $('#monthly_payment_percent').val(0);
            }
            
            final_price = final_price + payment_fee;
            
            let total_cheque_count = Math.floor(monthCount / chequeCount);
            
            if (total_cheque_count > 0 && monthCount > 0) {
                let each_month_price = final_price / monthCount;
                let each_cheque_price = final_price / total_cheque_count;
                
                each_month_price = parseInt(each_month_price);
                each_cheque_price = parseInt(each_cheque_price);
                
                $('.each_cheque_price_value').text(number_format(each_cheque_price));
                $('.each_month_price_value').text(number_format(each_month_price));
            } else {
                $('.each_cheque_price_value').text(number_format(0));
                $('.each_month_price_value').text(number_format(0));
            }
        } else {
            $('#monthly_payment_percent').val(0);
            $('.each_cheque_price_value').text(number_format(0));
            $('.each_month_price_value').text(number_format(0));
        }
        
        $('.cart_total_payment_fee').text(number_format(payment_fee));
        
        let in_person_discount = sanitizeNumber($('.order_in_person_discount').val());
        
        final_price = final_price - in_person_discount;
        
        card.find('.order_total_final').text(number_format(final_price));
        
        if (beyane > 0) {
            $('.beyane_row').show();
        } else {
            $('.beyane_row').hide();
        }
        
        if (payment_fee > 0) {
            $('.payment_fee').show();
        } else {
            $('.payment_fee').hide();
        }
        
        if (referral_discount > 0) {
            $('.referral_discount').show();
        } else {
            $('.referral_discount').hide();
        }
    }
    
    $(document).on('change', '#month_count', function(e) {
        let months = $(this).val();
        months = sanitizeNumber(months);
        if (months > 24) {
            $(this).val(24).trigger('change');
        }
        calc_factor_total();
    });
    $(document).on('change', '#cheque_count', function(e) {
        calc_factor_total();
    });
    $(document).on('click', '#submit_cash_payment', function() {
        let price = sanitizeNumber($('#new_cash_payment_row_price').val()),
            bank  = $('#new_cash_payment_row_bank').val(),
            date  = $('#new_cash_payment_row_date').val();
        if (!price) {
            NioApp.Toast('مبلغ پرداخت ضروری است.', 'error', {position: 'top-right'});
            return;
        }
        if (!bank) {
            NioApp.Toast('بانک پرداخت ضروری است.', 'error', {position: 'top-right'});
            return;
        }
        if (!date) {
            NioApp.Toast('تاریخ پرداخت ضروری است.', 'error', {position: 'top-right'});
            return;
        }
        
        let card = $('.cash_payment_table');
        let tbody = card.find('tbody');
        price = number_format(price);
        let html = `<tr>
                        <td class="payment_amount">${price}</td>
                        <td class="payment_bank">${bank}</td>
                        <td class="payment_date">${date}</td>
                        <td>
                            <a class="link-cross me-sm-n1 delete_payment_row"><em class="icon ni ni-cross"></em></a>
                        </td>
                    </tr>`;
        card.show();
        tbody.append(html);
        $('#addCashPayment input').each(function() {
            $(this).val('');
        });
        calc_factor_total();
    });
    
    $(document).on('click', '.delete_payment_row', function() {
        $(this).parents('tr').remove();
        let card = $('.cash_payment_table');
        let tbody = card.find('tbody');
        if (tbody.find('tr').length == 0) {
            card.hide();
        }
        calc_factor_total();
    });
    // $(document).on('change', '.change_payment_method', function(e) {
    //     if ($(this).val() == 'pay_monthly') {
    //         $('.monthly_payment_fields').show();
    //         $('.payment_status').show();
    //     } else {
    //         $('.monthly_payment_fields').hide();
    //         $('.payment_status').hide();
    //     }
    //
    //     calc_factor_total();
    // });
    $(document).on('change', '.change_payment_method', function() {
        let paymentMethod = $(this).val();
        
        $('.payment-method-dependent').each(function() {
            let methods = ($(this).data('payment-methods') || '').toString().
                split(',').
                map(item => item.trim()).
                filter(Boolean);
            
            if (methods.includes(paymentMethod)) {
                $(this).stop(true, true).slideDown(150);
            } else {
                $(this).stop(true, true).slideUp(150);
            }
        });
        
        calc_factor_total();
    });
    $(document).on('click', '.delete_factor_row', function() {
        $(this).parents('tr').remove();
        calc_factor_total();
    });
    $(document).on('click', '.add_product_to_factor', function() {
        let card = $('.order_factor_card .products_payment');
        let tbody = card.find('tbody');
        let qty_input = $(`.stock_spinner .number-spinner`);
        let qty = sanitizeNumber(qty_input.val(), true);
        let max_qty = sanitizeNumber(qty_input.attr('max'));
        let product_id = $('#select_product_id').val();
        let sku = $('#select_product_sku').val();
        let title = $('#select_product_title').val();
        let price = $('#select_product_price').val();
        let reg_price = $('#select_product_reg_price').val();
        let qty_html = `<input class="price_input line_qty form-control" data-decimal="1" value="${qty}"></td>`;
        
        price = sanitizeNumber(price);
        reg_price = number_format(reg_price);
        
        let existing_row = tbody.find(`tr[data-product="${product_id}"]`);
        if (existing_row.length) {
            let prev_qty = sanitizeNumber(existing_row.find('.line_qty').val(), true);
            let new_qty = prev_qty + qty;
            if (max_qty && new_qty > max_qty) {
                new_qty = max_qty;
            }
            existing_row.find('.line_qty').val(new_qty);
        } else {
            if (qty == 0) {
                return;
            }
            let subtotal = number_format(qty * price);
            price = number_format(price);
            let html = `<tr data-product="${product_id}">
                        <td>${title}</td>
                        <td>${qty_html}</td>
                        <td class="line_reg_price">
                            <input class="price_input item_reg_total form-control" value="${reg_price}"></td>
                        <td><input class="price_input item_off_percent form-control" value="0"></td>
                        <td class="line_price">
                            <input class="price_input item_subtotal form-control" value="${price}" readonly></td>
                        <td class="tb-col-action">
                            <input class="price_input line_total form-control" value="${subtotal}">
                              <input type="hidden" class="line_note">
                            <div class="d-flex justify-end" style="gap: 5px">
                                <a class="link-cross me-sm-n1 set_line_note"
                                    data-bs-toggle="popover" data-bs-trigger="hover"
                                    title="یادداشت"
                                    data-bs-content=""
                                    data-bs-placement="top"><em class="icon ni ni-note-add-c"></em></a>
                                <a class="link-cross me-sm-n1 delete_factor_row"><em class="icon ni ni-cross"></em></a>
                            </div>
                        </td>
                    </tr>`;
            tbody.append(html);
            NioApp.BS.popover('.set_line_note');
        }
        
        calc_factor_total();
    });
    $(document).on('click', '.set_line_note', function() {
        let $this = $(this);
        let row = $(this).parents('tr');
        let current_note = row.find('.line_note').val() || '';
        let escaped_note = $('<div>').text(current_note).html();
        
        let modal = Swal.mixin({
            title:             'یادداشت ردیف',
            html:              `<div class="form-group">
                                    <label class="form-label" for="swal_line_note">توضیح خود برای این محصول را وارد کنید</label>
                                    <div class="form-control-wrap">
                                        <textarea id="swal_line_note" class="form-control">${escaped_note}</textarea>
                                    </div>
                                </div>`,
            focusConfirm:      false,
            confirmButtonText: 'ثبت یادداشت',
        });
        modal.fire().then(function(result) {
            if (!result.isConfirmed) {
                return;
            }
            let note = $('#swal_line_note').val();
            row.find('.line_note').val(note);
            $this.attr('data-bs-content', note);
            NioApp.BS.popover('.set_line_note');
        });
    });
    let request_city = true;
    
    function request_city_list(state_id, city_id = 0, target = '') {
        let city = $(target);
        let data = {
            action:   'kasebi_load_city_list',
            state_id: state_id,
            city_id:  city_id,
        };
        $.post(ajax_url, data, function(response) {
            city.html(response.list);
            NioApp.Select2(target);
            if (city_id) {
                $(target).val(city_id).trigger('change');
            }
            request_city = true;
        });
    }
    
    $(document).on('change', '.load_city', function() {
        if (request_city) {
            request_city_list($(this).val(), 0, $(this).attr('data-target'));
        }
    });
    
    $(document).on('click', '#save_address_form', function(e) {
        let first_name = $('#address_first_name').val(),
            last_name  = $('#address_last_name').val(),
            phone      = $('#address_phone').val(),
            postcode   = $('#address_postcode').val(),
            state      = $('#address_state').val(),
            city       = $('#address_city').val(),
            region     = $('#address_region').val(),
            section    = $('#address_section').val(),
            address    = $('#address_address').val();
        
        let data = {
            action:     'crm_save_user_address',
            address_id: $('#save_address_key').val(),
            user_id:    $('#save_address_user_id').val(),
            address:    {
                first_name: first_name,
                last_name:  last_name,
                phone:      phone,
                postcode:   postcode,
                state:      state,
                city:       city,
                region:     region,
                section:    section,
                address_1:  address,
            },
        };
        $.post(ajax_url, data, function(response) {
            $('.address_wrapper').html(response.html);
            NioApp.Control('.custom-control-input');
            
            $('#addUserAddress input').each(function() {
                $(this).val('');
            });
        });
    });
    
    $(document).on('click', '.edit_customer_address', function() {
        $('#save_address_key').val($(this).attr('data-key'));
        $('#address_first_name').val($(this).attr('data-first_name'));
        $('#address_last_name').val($(this).attr('data-last_name'));
        $('#address_phone').val($(this).attr('data-phone'));
        $('#address_postcode').val($(this).attr('data-postcode'));
        $('#address_region').val($(this).attr('data-region'));
        let state = $(this).attr('data-state');
        let city = $(this).attr('data-city');
        request_city = false;
        $('#address_state').val(state).change();
        request_city_list(state, city, '#address_city');
        $('#address_address').val($(this).attr('data-address_1'));
        let user_id = $('#new_order_customer_id').val();
        if (!user_id) {
            user_id = $('#current_user_id').val();
        }
        $('#save_address_user_id').val(user_id);
        $('#addUserAddress').modal('show');
    });
    $(document).on('click', '.delete_customer_address', function() {
        let user_id = $('#new_order_customer_id').val();
        if (!user_id) {
            user_id = $('#current_user_id').val();
        }
        let data = {
            action:     'crm_delete_customer_address',
            address_id: $(this).attr('data-key'),
            user_id:    user_id,
        };
        Swal.fire({
            title:             'حذف آدرس',
            icon:              'warning',
            text:              'از حذف آدرس مطمئن هستید؟ این عمل غیر قابل بازگشت است.',
            focusConfirm:      false,
            showCancelButton:  true,
            confirmButtonText: 'بله',
            cancelButtonText:  `خیر`,
        }).then(function(result) {
            if (result.isConfirmed) {
                $.post(ajax_url, data, function(response) {
                    $('.address_wrapper').html(response.html);
                    NioApp.Control('.custom-control-input');
                });
            }
        });
    });
    $(document).on('click', '.submit_order', function() {
        let attachments = $('#new_order_attachment').val();
        let customer_id = $('#new_order_customer_id').val();
        
        if (Number(customer_id) <= 0) {
            NioApp.Toast('کاربری انتخاب نشده است', 'error', {position: 'top-right'});
            return;
        }
        
        let address_id = $('.select_new_order_address.checked');
        
        if (address_id.length === 0) {
            NioApp.Toast('آدرس انتخاب نشده است', 'error', {position: 'top-right'});
            return;
        }
        
        address_id = address_id.attr('data-key');
        
        let items = $('.products_payment tr');
        
        if (items.length === 0) {
            NioApp.Toast('محصولی انتخاب نشده است', 'error', {position: 'top-right'});
            return;
        }
        
        let products = [];
        
        items.each(function() {
            let product_id = $(this).attr('data-product');
            
            if (!product_id) {
                return;
            }
            
            let line_qty = $(this).find('.line_qty');
            
            let qty = sanitizeNumber(line_qty.val(), true);
            let reg_price = sanitizeNumber($(this).find('.item_reg_total').val());
            let off_percent = sanitizeNumber($(this).find('.item_off_percent').val());
            
            qty = qty > 0 ? qty : 1;
            reg_price = reg_price > 0 ? reg_price : 0;
            off_percent = off_percent >= 0 ? off_percent : 0;
            off_percent = off_percent > 100 ? 100 : off_percent;
            
            let regular_line_total = reg_price * qty;
            let discount_amount = regular_line_total * off_percent / 100;
            let line_total = regular_line_total - discount_amount;
            
            regular_line_total = Math.round(regular_line_total);
            discount_amount = Math.round(discount_amount);
            line_total = Math.round(line_total);
            
            let product_data = {
                product_id:  product_id,
                qty:         qty,
                subtotal:    regular_line_total,
                line_total:  line_total,
                reg_price:   reg_price,
                off_percent: off_percent,
                off_amount:  discount_amount,
                note:        $(this).find('.line_note').val(),
            };
            
            products.push(product_data);
        });
        
        let custom_fee = sanitizeNumber($('.order_custom_fee').val());
        let custom_extra_fee = sanitizeNumber($('.order_custom_extra_fee').val());
        let in_person_discount = sanitizeNumber($('.order_in_person_discount').val());
        
        let payment_items = $('.cash_payment_table tr');
        let payment_list = [];
        
        payment_items.each(function() {
            let amount = sanitizeNumber($(this).find('.payment_amount').text());
            
            if (!amount) {
                return;
            }
            
            let user_id = $(this).attr('data-user') ? $(this).attr('data-user') : 0;
            
            let payment_data = {
                amount: amount,
                bank:   $(this).find('.payment_bank').text(),
                date:   $(this).find('.payment_date').text(),
                user:   user_id,
            };
            
            payment_list.push(payment_data);
        });
        
        let payment_type = $('input[name="payment_type"]:checked').attr('id');
        let dated_payment_days = $('input[name="dated_payment_days"]:checked').val() || '';
        
        let data = {
            action:             'crm_submit_new_order',
            address_id:         address_id,
            products:           products,
            attachments:        attachments,
            payment_type:       payment_type,
            payment_list:       payment_list,
            description:        $('#order_description').val(),
            factor_date:        $('#new_factor_date').val(),
            customer_id:        customer_id,
            in_person_discount: in_person_discount,
            custom_fee:         custom_fee,
            custom_extra_fee:   custom_extra_fee,
            use_referral:       sanitizeNumber($('.cart_referral_discount').text()),
        };
        
        if (payment_type == 'pay_monthly') {
            data.month_count = $('#month_count').val();
            data.cheque_count = $('#cheque_count').val();
            data.percentage = $('#monthly_payment_percent').val();
        }
        
        if (payment_type == 'pay_dated') {
            data.dated_payment_days = dated_payment_days;
        }
        
        let order_id = $(this).attr('data-id');
        
        if (order_id) {
            data.order_id = order_id;
        }
        
        $.post(ajax_url, data, function(response) {
            change_panel_html(response);
            history.pushState({}, '', response.url);
            
            let factor_url = response.factor;
            
            Swal.fire({
                title:             'عملیات موفق',
                icon:              'success',
                text:              'سفارش با موفقیت ثبت شد',
                confirmButtonText: 'مشاهده فاکتور',
                cancelButtonText:  'باشه',
            }).then(function(result) {
                if (result.isConfirmed) {
                    window.open(factor_url, '_blank');
                }
            });
        });
    });
    $(document).on('click', '.load_order_items_table', function(e) {
        e.preventDefault();
        let order_id = $(this).attr('data-order-id');
        let data = {
            action:   'crm_load_order_items_table',
            order_id: order_id,
        };
        $.post(ajax_url, data, function(response) {
            $('#orderItemsTable').modal('show');
            $('#orderItemsTable .modal-body').html(response.html);
        });
    });
    $(document).on('click', '.load_order_cheque', function(e) {
        e.preventDefault();
        let order_id = $(this).attr('data-order-id');
        let data = {
            action:   'crm_load_order_cheque',
            order_id: order_id,
        };
        $.post(ajax_url, data, function(response) {
            $('#orderChequeTable').modal('show');
            $('#orderChequeTable .modal-body').html(response.html);
        });
    });
    
    $(document).on('click', '.delete_cheque', function(e) {
        e.preventDefault();
        let $el = $(this);
        let data = {
            action:   'crm_delete_cheque_for_order',
            item_key: $el.data('item_key'),
            order_id: $el.data('order_id'),
        };
        Swal.fire({
            title:             'آیا از حذف این مورد اطمینان دارید؟',
            icon:              'warning',
            text:              'این عملیات غیر قابل بازگشت است',
            focusConfirm:      false,
            showCancelButton:  true,
            confirmButtonText: 'بله',
            cancelButtonText:  `خیر`,
        }).then((result) => {
            if (result.isConfirmed) {
                $.post(ajax_url, data, function(response) {
                    $('#orderChequeTable').modal('show');
                    $('#orderChequeTable .modal-body').html(response.html);
                });
            }
        });
        
    });
    
    $(document).on('click', '.copy_cheque', function(e) {
        e.preventDefault();
        let $el = $(this);
        $('#new_cheque_order_id').val($el.data('order_id'));
        $('#cheque_order_id_key').val('false');
        $('#new_cheque_serial_number').val($el.data('check_serial'));
        $('#new_cheque_due_date').val($el.data('check_expire'));
        $('#new_cheque_bank').val($el.data('bank_name'));
        $('#new_cheque_branch').val($el.data('branch_name'));
        $('#new_cheque_current').val($el.data('current_account'));
        $('#new_cheque_owner').val($el.data('account_owner'));
        $('#new_cheque_owner_id').val($el.data('national_code'));
        $('#new_cheque_price').val($el.data('check_amount'));
        $('#addChequeForOrder').modal('show');
    });
    $(document).on('click', '.edit_cheque', function(e) {
        e.preventDefault();
        let $el = $(this);
        $('#new_cheque_order_id').val($el.data('order_id'));
        $('#cheque_order_id_key').val($el.data('item_key'));
        $('#new_cheque_serial_number').val($el.data('check_serial'));
        $('#new_cheque_due_date').val($el.data('check_expire'));
        $('#new_cheque_bank').val($el.data('bank_name'));
        $('#new_cheque_branch').val($el.data('branch_name'));
        $('#new_cheque_current').val($el.data('current_account'));
        $('#new_cheque_owner').val($el.data('account_owner'));
        $('#new_cheque_owner_id').val($el.data('national_code'));
        $('#new_cheque_price').val($el.data('check_amount'));
        $('#addChequeForOrder').modal('show');
    });
    $(document).on('click', '[data-bs-target="#addChequeForOrder"]', function() {
        let order_id = $(this).attr('data-order');
        $('#new_cheque_order_id').val(order_id);
        $('#cheque_order_id_key').val('false');
        $('#new_cheque_serial_number').val('');
        $('#new_cheque_due_date').val('');
        $('#new_cheque_bank').val('');
        $('#new_cheque_branch').val('');
        $('#new_cheque_current').val('');
        $('#new_cheque_owner').val('');
        $('#new_cheque_owner_id').val('');
        $('#new_cheque_price').val('');
    });
    $(document).on('click', '#submit_new_cheque_for_order', function(e) {
        e.preventDefault();
        let order_id = $('#new_cheque_order_id').val();
        let item_key = $('#cheque_order_id_key').val();
        let data = {
            action:          'crm_submit_new_cheque_for_order',
            item_key:        item_key,
            order_id:        order_id,
            check_serial:    $('#new_cheque_serial_number').val(),
            check_expire:    $('#new_cheque_due_date').val(),
            bank_name:       $('#new_cheque_bank').val(),
            branch_name:     $('#new_cheque_branch').val(),
            current_account: $('#new_cheque_current').val(),
            account_owner:   $('#new_cheque_owner').val(),
            national_code:   $('#new_cheque_owner_id').val(),
            check_amount:    sanitizeNumber($('#new_cheque_price').val()),
        };
        $.post(ajax_url, data, function(response) {
            $('#orderChequeTable').modal('show');
            $('#orderChequeTable .modal-body').html(response.html);
        });
    });
    
    $(document).on('click', '.load_order_cash_table', function(e) {
        e.preventDefault();
        let order_id = $(this).attr('data-order-id');
        let data = {
            action:   'crm_load_order_cash_table',
            order_id: order_id,
        };
        $.post(ajax_url, data, function(response) {
            $('#orderCashTable').modal('show');
            $('#orderCashTable .modal-body').html(response.html);
        });
    });
    $(document).on('click', '[data-bs-target="#addCashPaymentForOrder"]', function() {
        let order_id = $(this).attr('data-order');
        $('#cash_payment_order_id').val(order_id);
        $('#new_cash_payment_row_date_for_order').val('');
        $('#new_cash_payment_row_bank_for_order').val('');
        $('#new_cash_payment_price_for_order').val('');
    });
    $(document).on('click', '#submit_cash_payment_for_order', function(e) {
        e.preventDefault();
        let order_id = $('#cash_payment_order_id').val();
        let data = {
            action:   'crm_submit_cash_payment_for_order',
            order_id: order_id,
            date:     $('#new_cash_payment_row_date_for_order').val(),
            bank:     $('#new_cash_payment_row_bank_for_order').val(),
            amount:   sanitizeNumber($('#new_cash_payment_price_for_order').val()),
        };
        $.post(ajax_url, data, function(response) {
            $('#orderCashTable').modal('show');
            $('#orderCashTable .modal-body').html(response.html);
        });
    });
    $(document).on('click', '.delete_cash', function(e) {
        e.preventDefault();
        let $el = $(this);
        let data = {
            action:   'crm_delete_cash_for_order',
            item_key: $el.data('item_key'),
            order_id: $el.data('order_id'),
        };
        Swal.fire({
            title:             'آیا از حذف این مورد اطمینان دارید؟',
            icon:              'warning',
            text:              'این عملیات غیر قابل بازگشت است',
            focusConfirm:      false,
            showCancelButton:  true,
            confirmButtonText: 'بله',
            cancelButtonText:  `خیر`,
        }).then((result) => {
            if (result.isConfirmed) {
                $.post(ajax_url, data, function(response) {
                    $('#orderCashTable').modal('show');
                    $('#orderCashTable .modal-body').html(response.html);
                });
            }
        });
        
    });
    $(document).on('click', '.load_order_installments', function(e) {
        e.preventDefault();
        let order_id = $(this).attr('data-order-id');
        let data = {
            action:   'crm_load_order_installments',
            order_id: order_id,
        };
        $.post(ajax_url, data, function(response) {
            $('#orderInstallmentTable').modal('show');
            $('#orderInstallmentTable .modal-body').html(response.html);
        });
    });
    $(document).on('click', '#edit_order_installment_data', function(e) {
        $('#addInstallmentDataForOrder').modal('show');
        $('#order_installment_data_order_id').val($(this).data('data_order_id'));
        $('#order_installment_name').val($(this).data('name'));
        $('#order_installment_national_id').val($(this).data('national_id'));
        $('#order_installment_organ').val($(this).data('organ'));
        $('#order_installment_date').val($(this).data('start_date'));
        $('#order_installment_month').val($(this).data('month'));
        $('#order_installment_rec_no').val($(this).data('rec_no'));
        $('#order_installment_rec_date').val($(this).data('rec_date'));
        $('#order_installment_recorded_bank').val($(this).data('recorded_bank'));
        $('#order_installment_recorded_by').val($(this).data('recorded_by'));
        $('#order_installment_record_date').val($(this).data('record_date'));
        $('#order_installment_amount').val($(this).data('total_amount'));
    });
    $(document).on('click', '#submit_order_installment_data', function(e) {
        e.preventDefault();
        let order_id = $('#order_installment_data_order_id').val();
        let month = sanitizeNumber($('#order_installment_month').val());
        let data = {
            action:                  'crm_submit_order_installment_data',
            order_id:                order_id,
            payment_user_name:       $('#order_installment_name').val(),
            payment_user_nid:        $('#order_installment_national_id').val(),
            payment_plan_name:       $('#order_installment_organ').val(),
            payment_plan_start_date: $('#order_installment_date').val(),
            payment_plan_month:      month,
            payment_plan_amount:     parseInt($('#order_installment_amount').val()) / month,
            payment_rec_number:      $('#order_installment_rec_no').val(),
            payment_rec_date:        $('#order_installment_rec_date').val(),
            payment_recorded_bank:   $('#order_installment_recorded_bank').val(),
            payment_recorded_by:     $('#order_installment_recorded_by').val(),
            payment_recorded_date:   $('#order_installment_record_date').val(),
        };
        $.post(ajax_url, data, function(response) {
            $('#orderInstallmentTable').modal('show');
            $('#orderInstallmentTable .modal-body').html(response.html);
        });
    });
    
    $(document).on('click', '#delete_order_installment_data', function(e) {
        e.preventDefault();
        let order_id = $('#order_installment_data_order_id').val();
        let data = {
            action:   'crm_delete_order_installment_data',
            order_id: order_id,
        };
        $.post(ajax_url, data, function(response) {
            $('#orderInstallmentTable').modal('show');
            $('#orderInstallmentTable .modal-body').html(response.html);
        });
    });
    
    $(document).on('click', '.change_order_status', function(e) {
        e.preventDefault();
        let order_id = $(this).attr('data-order-id');
        let status = $(this).attr('data-status');
        let data = get_current_page_filters();
        let label = $(this).text();
        data.action = 'crm_change_order_status';
        data.page = $('#current_page').val();
        data.order_id = order_id;
        data.new_status = status;
        data.id = $('#current_user_id').val();
        data.tab = 'orders';
        let text = 'وضعیت سفارش به ' + label + ' تغییر کند؟';
        if (status === 'factor') {
            text = '<div class="form-group">' +
                '<label class="form-label" for="order_shipment_days">مدت زمان تحویل کالا را وارد کنید</label>' +
                '<div class="form-control-wrap">' +
                '<input id="order_shipment_days" type="text" class="form-control form-control-sm"' +
                '</div>' +
                '</div>';
        }
        Swal.fire({
            title:             'تغییر وضعیت سفارش',
            icon:              'warning',
            html:              text,
            focusConfirm:      false,
            showCancelButton:  true,
            confirmButtonText: 'بله',
            cancelButtonText:  `خیر`,
        }).then((result) => {
            if (result.isConfirmed) {
                if (status === 'factor') {
                    data.shipment_days = $('#order_shipment_days').val();
                }
                $.post(ajax_url, data, function(response) {
                    change_panel_html(response);
                    history.pushState({}, '', response.url);
                });
            }
        });
    });
    $(document).on('click', '.set_production_processing', function(e) {
        e.preventDefault();
        let process_id = $(this).attr('data-process-id');
        let data = get_current_page_filters();
        data.action = 'crm_set_production_processing';
        data.page = $('#current_page').val();
        data.process_id = process_id;
        Swal.fire({
            title:             'تاریخ تولید را وارد کنید.',
            html:              '<div class="form-group">' +
                                   '<label class="form-label" for="process_complete_date">تاریخ اعلامی تولید کننده</label>' +
                                   '<div class="form-control-wrap">' +
                                   '<input id="process_complete_date" type="text" class="form-control form-control-sm datepicker">' +
                                   '</div>' +
                                   '</div>',
            icon:              'warning',
            focusConfirm:      false,
            showCancelButton:  true,
            confirmButtonText: 'بله',
            cancelButtonText:  `خیر`,
            onRender:          function() {
                activate_date_pickers();
            },
        }).then((result) => {
            if (result.isConfirmed) {
                data.complete_date = $('#process_complete_date').val();
                $.post(ajax_url, data, function(response) {
                    change_panel_html(response);
                    history.pushState({}, '', response.url);
                });
            }
        });
    });
    $(document).on('click', '.open_stock_items_row', function(e) {
        e.preventDefault();
        let row = $(this).data('row'); // مقدار data-row روی دکمه
        $(`[data-sku='${row}']`).toggleClass('d-none');
    });
    $(document).on('click', '.view_process_steps', function(e) {
        e.preventDefault();
        let process_id = $(this).attr('data-process-id');
        let data = {
            action:     'crm_get_process_steps',
            process_id: process_id,
        };
        $.post(ajax_url, data, function(response) {
            $('#processStepsModal').modal('show');
            $('#processStepsModal .modal-body').html(response.html);
        });
    });
    
    $(document).on('click', '.save_user_location', function(e) {
        e.preventDefault();
        let id = $(this).attr('data-id');
        let data = {
            action: 'crm_save_user_location',
            id:     id,
            tab:    'profile',
            page:   '/crm/user',
            lat:    $('#kasebi_user_lat').val(),
            lng:    $('#kasebi_user_lng').val(),
        };
        $.post(ajax_url, data, function(response) {
            change_panel_html(response);
        });
    });
    
    function buildNeedsHtml(needFields, itemsCount, actionLabel) {
        if (!needFields || !needFields.length) {
            return `<div class="text-center py-2">آیا از اجرای «${actionLabel}» برای ${itemsCount} مورد مطمئن هستید؟</div>`;
        }
        const blocks = needFields.map(f => {
            const id = `swal_need_${f.key || f.name || Math.random().toString(36).slice(2)}`;
            const label = f.label || '';
            const wrapStart = `<div class="form-group"><label class="form-label" for="${id}">${label}</label><div class="form-control-wrap">`;
            const wrapEnd = `</div></div>`;
            if (f.type === 'select') {
                const opts = (f.options || []).map(o => {
                    const v = (typeof o === 'object') ? (o.value ?? o.id ?? '') : o;
                    const t = (typeof o === 'object') ? (o.label ?? o.text ?? v) : o;
                    const selected = f.value && f.value == v ? ' selected' : '';
                    return `<option value="${String(v).replace(/"/g, '&quot;')}"${selected}>${t}</option>`;
                }).join('');
                return `${wrapStart}<select id="${id}" class="form-select" data-key="${f.key}">${opts}</select>${wrapEnd}`;
            }
            if (f.type === 'textarea') {
                const val = (f.value ?? '');
                return `${wrapStart}<textarea id="${id}" class="form-control" data-key="${f.key}">${String(
                    val).replace(/"/g, '&quot;')}</textarea>${wrapEnd}`;
            }
            const extraClass = (f.type === 'date') ? ' datepicker' : '';
            const val = (f.value ?? '');
            return `${wrapStart}<input type="text" id="${id}" class="form-control${extraClass}" data-key="${f.key}" value="${String(
                val).replace(/"/g, '&quot;')}">${wrapEnd}`;
        });
        return blocks.join('');
    }
    
    function collectNeedsValues(needFields) {
        const vals = {};
        (needFields || []).forEach(f => {
            if (f.type === 'modal') {
                return;
            }
            const $inp = $(`.swal2-container [data-key="${f.key}"]`);
            if ($inp.length) {
                vals[f.key] = $inp.val();
            }
        });
        return vals;
    }
    
    $(document).on('change', '.row_bulk_actions', function() {
        const $select = $(this);
        const bulk_action = this.value;
        if (!bulk_action || bulk_action == 0) {
            return;
        }
        
        const actionLabel = $.trim($select.find('option:selected').text());
        const itemsArr = $('.select_item_row:checked').map(function() { return $(this).val(); }).get();
        
        if (!itemsArr.length) {
            NioApp.Toast('هیچ آیتمی انتخاب نشده است.', 'warning', {position: 'top-right'});
            $select.val('0').trigger('change');
            return;
        }
        const items = itemsArr.join(',');
        
        let needs = $select.find(':selected').attr('data-needs');
        try { needs = (needs && needs !== 'null') ? JSON.parse(needs) : null; } catch (e) { needs = null; }
        const needFields = needs
                           ? (Array.isArray(needs) ? needs : (Array.isArray(needs.needs) ? needs.needs : null))
                           : null;
        
        // modal type
        if (needFields && needFields.length === 1 && needFields[0].type === 'modal') {
            const nf = needFields[0];
            if (nf.itemsInput) { $('#' + nf.itemsInput).val(items); }
            if (nf.modalId) { $('#' + nf.modalId).modal('show'); }
            $select.val('0').trigger('change');
            return;
        }
        
        const data = get_current_page_filters();
        data.action = 'crm_stock_items_set_step';
        data.page = $('#current_page').val();
        data.step_action = bulk_action;
        data.items = items;
        
        Swal.fire({
            title:             actionLabel,
            icon:              'warning',
            html:              buildNeedsHtml(needFields, itemsArr.length, actionLabel),
            focusConfirm:      false,
            showCancelButton:  true,
            confirmButtonText: 'تایید',
            cancelButtonText:  'لغو',
            onRender:          function() {
                activate_date_pickers();
            },
        }).then((result) => {
            if (!result.isConfirmed) {
                $select.val('0').trigger('change');
                return;
            }
            Object.assign(data, collectNeedsValues(needFields));
            $.post(ajax_url, data, function(response) {
                if (response.redirect) {
                    window.open(response.redirect, '_blank');
                    $select.val('0').trigger('change');
                    return;
                }
                change_panel_html(response);
            });
            $select.val('').trigger('change.select2');
        });
    });
    
    // 2) هندلِ کلیک روی لینکِ set_step_for_stock_item (همان فرآیند، آیتم تکی)
    $(document).on('click', '.set_step_for_stock_item', function(e) {
        e.preventDefault();
        const $a = $(this);
        const itemId = $a.data('item-id');
        const step = $a.data('step');
        const label = $.trim($a.text()) || $a.attr('title') || 'تایید عملیات';
        
        if (!itemId || !step) {
            NioApp.Toast('اطلاعات آیتم یا مرحله ناقص است.', 'danger', {position: 'top-right'});
            return;
        }
        
        $('#item_qc_approved').prop('checked', step == 'qccheck_approved').trigger('change');
        
        let needs = $a.attr('data-needs');
        try { needs = (needs && needs !== 'null') ? JSON.parse(needs) : null; } catch (e2) { needs = null; }
        const needFields = needs
                           ? (Array.isArray(needs) ? needs : (Array.isArray(needs.needs) ? needs.needs : null))
                           : null;
        
        if (needFields && needFields.length === 1 && needFields[0].type === 'modal') {
            const nf = needFields[0];
            if (nf.itemsInput) { $('#' + nf.itemsInput).val(String(itemId)); }
            if (nf.modalId) { $('#' + nf.modalId).modal('show'); }
            if (nf.step) { $('#item_qc_approved').val(nf.step); }
            return;
        }
        
        const data = get_current_page_filters();
        data.action = 'crm_stock_items_set_step';
        data.page = $('#current_page').val();
        data.step_action = step;
        data.items = String(itemId);
        
        Swal.fire({
            title:             label,
            icon:              'warning',
            html:              buildNeedsHtml(needFields, 1, label),
            focusConfirm:      false,
            showCancelButton:  true,
            confirmButtonText: 'تایید',
            cancelButtonText:  'لغو',
            onRender:          function() {
                activate_date_pickers();
            },
        }).then((result) => {
            if (!result.isConfirmed) {
                return;
            }
            Object.assign(data, collectNeedsValues(needFields));
            $.post(ajax_url, data, function(response) {
                change_panel_html(response);
            });
        });
    });
    // ارسال فرم QC از داخل مدال
    $(document).on('click', '#submit_product_qc_form', function() {
        const data = get_current_page_filters();
        const $modal = $('#qcFormModal');
        const itemId = $('#submit_qc_form_item_ids').val();
        const approve = $('#item_qc_approved');
        const step = approve.is(':checked') ? approve.val() : 'qccheck_rejected';
        
        data.action = 'crm_stock_items_set_step';
        data.page = $('#current_page').val();
        data.step_action = step;
        data.items = String(itemId);
        
        // خواندن همه فیلدهای مدال (به جز submit_qc_form_item_ids)
        const form_data = {};
        $modal.find(':input').each(function() {
            const $el = $(this);
            const id = $el.attr('id');
            const name = $el.attr('name') || id;
            
            if (!id && !name) {
                return;
            }                            // بدون شناسه/نام رد بشه
            if (id === 'submit_qc_form_item_ids') {
                return;
            }        // اسکیپ کردن این فیلد
            
            const tag = this.tagName.toLowerCase();
            const type = ($el.attr('type') || tag).toLowerCase();
            
            if (type === 'checkbox') {
                if (!$el.is(':checked')) {
                    return;
                }
                
                if (name.endsWith('[]')) {
                    const cleanKey = name.replace(/\[\]$/, '');
                    if (!Array.isArray(form_data[cleanKey])) {
                        form_data[cleanKey] = [];
                    }
                    form_data[cleanKey].push($el.val());
                } else {
                    // checkbox تکی
                    form_data[name] = $el.val() ?? 1;
                }
            } else if (type === 'radio') {
                if ($el.is(':checked')) {
                    form_data[name] = $el.val();
                }
            } else if (tag === 'select' || tag === 'textarea' || type === 'text') {
                form_data[name] = $el.val();
            } else {
                form_data[name] = $el.val();
            }
        });
        
        data.qcForm = form_data;
        
        $.post(ajax_url, data, function(response) {
            change_panel_html(response);
        });
    });
    
    function getFieldValueByMeta(metaKey) {
        let $el = $('[data-for="' + metaKey + '"]');
        if (!$el.length) {
            return null;
        }
        
        let tag = ($el.prop('tagName') || '').toLowerCase();
        let type = ($el.attr('type') || '').toLowerCase();
        
        if (tag === 'select') {
            return $el.val();
        }
        if (tag === 'textarea') {
            return $el.val();
        }
        if (type === 'checkbox') {
            return $el.is(':checked') ? '1' : '0';
        }
        return $el.val();
    }
    
    function matchCondition(actual, expected, operator) {
        let isArray = Array.isArray(expected);
        let isMatch = isArray ? expected.indexOf(actual) !== -1 : (actual === expected);
        return (operator === '!=') ? !isMatch : isMatch;
    }
    
    function parseExpected(jsonStr) {
        try {
            let parsed = JSON.parse(jsonStr);
            if (Array.isArray(parsed)) {
                return parsed.map(function(v) { return (v === null || v === undefined) ? '' : String(v); });
            }
            return (parsed === null || parsed === undefined) ? '' : String(parsed);
        } catch (e) {
            return jsonStr;
        }
    }
    
    function evaluateVisibilityForRow($row) {
        let isConditional = $row.data('conditional') === 1 || $row.data('conditional') === '1';
        if (!isConditional) {
            return; // always visible
        }
        let condMeta = $row.data('cond-meta') || '';
        let expectedRaw = $row.attr('data-cond-expected') || '';
        let operator = $row.data('cond-operator') || '==';
        
        let expected = parseExpected(expectedRaw);
        let actual = getFieldValueByMeta(condMeta);
        if (actual === null || actual === undefined) {
            actual = '';
        } else {
            actual = String(actual);
        }
        
        let ok = matchCondition(actual, expected, operator);
        $row.toggleClass('d-none', !ok);
    }
    
    function evaluateAll() {
        $('.meta-field-row').each(function() {
            evaluateVisibilityForRow($(this));
        });
    }
    
    $(document).on('change input', '[data-for]', function() {
        evaluateAll();
    });
    $(document).on('select2:select select2:clear', '[data-for]', function() {
        evaluateAll();
    });
    
    function parseChartConfig(el) {
        const raw = el.getAttribute('data-chart') || '';
        try {
            return JSON.parse(raw);
        } catch (e) {
            console.warn('Invalid chart JSON in data-chart:', el, e);
            return null;
        }
    }
    
    function renderCharts(selector) {
        // Chart.defaults.scale.gridLines.color = 'transparent';
        // Chart.defaults.scale.ticks.autoSkip = false;
        // Chart.defaults.scale.ticks.maxRotation = 0;
        // Chart.defaults.scale.ticks.minRotation = 0;
        const nodes = document.querySelectorAll(selector || 'canvas.render_chart');
        nodes.forEach((canvas) => {
            const cfg = parseChartConfig(canvas);
            if (!cfg) {
                return;
            }
            
            if (canvas._chartInstance) {
                canvas._chartInstance.destroy();
            }
            
            const ctx = canvas.getContext('2d');
            canvas._chartInstance = new Chart(ctx, cfg);
        });
    }
    
    function showRequiredError($field) {
        let $group = $field.closest('.form-group');
        let label = $group.find('.form-label');
        if (!label.length) {
            label = 'این فیلد';
        } else {
            label = label.get(0).innerText.trim();
        }
        NioApp.Toast(label + ' ضروری است', 'error',
            {position: 'top-right'});
    }
    
    function setNestedValue(obj, path, value) {
        let keys = path.replace(/\]/g, '').split('['); // meta[national_id] => ['meta','national_id']
        
        let ref = obj;
        keys.forEach(function(key, index) {
            if (index === keys.length - 1) {
                ref[key] = value;
            } else {
                if (!ref[key] || typeof ref[key] !== 'object') {
                    ref[key] = {};
                }
                ref = ref[key];
            }
        });
    }
    
    function getNestedValue(obj, path) {
        let keys = path.replace(/\]/g, '').split('[');
        let ref = obj;
        
        for (let i = 0; i < keys.length; i++) {
            if (ref == null || typeof ref !== 'object') {
                return undefined;
            }
            ref = ref[keys[i]];
        }
        return ref;
    }
    
    $(document).on('click', '.submit_modal_form', function() {
        
        let $form = $(this).parents('.modal_form');
        let page = $form.attr('data-page') || '';
        
        let data = {
            action: $form.attr('data-action'),
            page:   page,
        };
        
        let hasError = false;
        let requiredMap = {}; // key => { fields: [] }
        
        let $inputs = $form.find('input[data-for], select[data-for], textarea[data-for]');
        
        // ----------------- inputs -----------------
        $inputs.each(function() {
            
            let $field = $(this);
            let key = $field.data('for');
            
            if (!key) {
                return;
            }
            
            if ($field.data('req') == 1) {
                if (!requiredMap[key]) {
                    requiredMap[key] = {fields: []};
                }
                requiredMap[key].fields.push($field);
            }
            
            // checkbox
            if ($field.is(':checkbox')) {
                
                if ($field.is(':checked')) {
                    let val = $field.val() || 1;
                    
                    if (key.includes('[')) {
                        let current = getNestedValue(data, key);
                        if (!Array.isArray(current)) {
                            setNestedValue(data, key, []);
                            current = getNestedValue(data, key);
                        }
                        current.push(val);
                    } else {
                        if (!Array.isArray(data[key])) {
                            data[key] = [];
                        }
                        data[key].push(val);
                    }
                }
                
                return;
            }
            
            // radio
            if ($field.is(':radio')) {
                
                if ($field.is(':checked')) {
                    let val = $field.val();
                    
                    if (key.includes('[')) {
                        setNestedValue(data, key, val);
                    } else {
                        data[key] = val;
                    }
                }
                
                return;
            }
            
            let val = $field.val();
            if (key == 'phone') {
                if (!validate_phone_number(val)) {
                    NioApp.Toast('شماره تلفن همراه معتبر نیست', 'error',
                        {position: 'top-right'});
                    return;
                }
            }
            if (key.includes('[')) {
                setNestedValue(data, key, val);
            } else {
                data[key] = val;
            }
            
        });
        
        Object.keys(requiredMap).forEach(function(key) {
            if (hasError) {
                return;
            }
            let value = key.includes('[')
                        ? getNestedValue(data, key)
                        : data[key];
            
            let isEmpty =
                    value === undefined ||
                    value === null ||
                    (Array.isArray(value) && value.length === 0) ||
                    (typeof value === 'string' && value.trim() === '');
            
            if (isEmpty) {
                let $firstField = requiredMap[key].fields[0];
                showRequiredError($firstField);
                hasError = true;
            }
        });
        
        // ----------------- quill editors -----------------
        let $quills = $form.find('.quill-basic[data-for]');
        
        $quills.each(function() {
            
            let $wrapper = $(this);
            let key = $wrapper.data('for');
            
            if (!key) {
                return;
            }
            
            let quillInstance = $wrapper.data('quill');
            let html = '';
            
            if (quillInstance && quillInstance.root) {
                html = quillInstance.root.innerHTML;
            } else {
                html = $wrapper.find('.ql-editor').html() || '';
            }
            
            let textContent = $('<div>').html(html).text().trim();
            
            if ($wrapper.data('req') == 1 && textContent === '') {
                if (!hasError) {
                    showRequiredError($wrapper);
                }
                hasError = true;
            }
            
            if (key.includes('[')) {
                setNestedValue(data, key, html);
            } else {
                data[key] = html;
            }
        });
        
        if (hasError) {
            return;
        }
        
        if (data.action === 'crm_add_product' && window.kcpRolePricing) {
            const pricing = window.kcpRolePricing.collect($form[0]);
            if (!pricing.ok) { NioApp.Toast(pricing.message, 'error', {position: 'top-right'}); return; }
            Object.assign(data, pricing.data);
        }

        $.post(ajax_url, data, function(response) {
            if (data.action === 'crm_add_product' && response.status === 'error' && !response.main) {
                NioApp.Toast(response.message, 'error', {position: 'top-right'});
                return;
            }
            change_panel_html(response);
            history.pushState({}, '', response.url);
            
            if (response.link) {
                window.open(response.link, '_blank');
            }
        });
    });
    $(document).on('click', '#export_current_list', function() {
        $(this).addClass('disabled');
        let data = get_current_page_filters();
        data.action = 'crm_export_products';
        data.page_number = 1;
        data.export_id = false;
        request_export_data(data, 0);
    });
    
    function request_export_data(data) {
        ajax_search = true;
        let wrapper = $('.export_progress_container');
        let progress_bar = wrapper.find('.progress-bar');
        wrapper.removeClass('d-none');
        $.post(ajax_url, data, function(e) {
            if (e.status === 'finished') {
                wrapper.addClass('d-none');
                let result_wrapper = $('.export_result_container');
                result_wrapper.removeClass('d-none');
                $('#export_current_list').removeClass('disabled');
                result_wrapper.find('.xls_link').attr('href', e.xls);
                result_wrapper.find('.csv_link').attr('href', e.csv);
                ajax_search = false;
                return;
            }
            progress_bar.css('width', e.percent + '%');
            progress_bar.text(e.percent + '%');
            data.page_number = e.next_page;
            data.export_id = e.export_id;
            request_export_data(data);
        });
    }
    
    function read_file(data) {
        let workbook = XLSX.read(data, {type: 'binary'});
        let sheet = workbook.Sheets[workbook.SheetNames[0]];
        
        let rows = XLSX.utils.sheet_to_json(sheet, {
            header:    1,
            defval:    '',
            blankrows: false,
        });
        
        if (!rows.length) {
            return [];
        }
        
        let headers = rows.shift().map(h => String(h).trim());
        let output = [];
        
        for (let i = 0; i < rows.length; i++) {
            let row = rows[i];
            let obj = {};
            
            for (let j = 0; j < headers.length; j++) {
                let key = headers[j];
                let val = row[j] ?? '';
                
                if (!key) {
                    continue;
                }
                
                // meta[phone1] => obj.meta.phone1
                let metaMatch = key.match(/^meta\[(.+)]$/);
                if (metaMatch) {
                    obj.meta = obj.meta || {};
                    obj.meta[metaMatch[1]] = val;
                } else {
                    obj[key] = val;
                }
            }
            
            output.push(obj);
        }
        
        return output;
    }
    
    function sendAjaxData(args) {
        let {
                rows,
                perPage,
                offset,
                total,
                progress,
                action,
                btn,
            } = args;
        
        if (offset >= total) {
            btn.html('<span>اتمام عملیات</span>');
            btn.prop('disabled', false);
            NioApp.Toast('ایمپورت به پایان رسید', 'success', {position: 'top-right'});
            ajax_search = false;
            return;
        }
        
        let slice = rows.slice(offset, offset + perPage);
        
        $.ajax({
            url:      ajax_url,
            type:     'post',
            dataType: 'json',
            data:     {
                action: action,
                data:   slice,
                offset: offset,
            },
            success:  function() {
                let percent = Math.min(100, Math.round(((offset + perPage) / total) * 100));
                progress.width(percent + '%');
                
                setTimeout(function() {
                    sendAjaxData({
                        rows,
                        perPage,
                        offset: offset + perPage,
                        total,
                        progress,
                        action,
                        btn,
                    });
                }, 0);
            },
        });
    }
    
    $(document).on('click', '.start_import', function() {
        let file_id = $(this).attr('data-file');
        let action = $(this).attr('data-action');
        let perPage = parseInt($(this).attr('data-per-page'), 10);
        let progress = $('#' + $(this).attr('data-progress'));
        let btn = $(this);
        let fileInput = $('#' + file_id)[0];
        
        if (!fileInput.files[0]) {
            NioApp.Toast('فایلی انتخاب نشده است', 'error', {position: 'top-right'});
            return false;
        }
        
        ajax_search = true;
        
        btn.html('<span class="spinner-border spinner-border-sm"></span><span>در حال خواندن فایل...</span>');
        btn.prop('disabled', true);
        
        let reader = new FileReader();
        reader.onload = function(e) {
            let rows = read_file(e.target.result);
            let total = rows.length;
            btn.html('<span class="spinner-border spinner-border-sm"></span><span>در حال ایمپورت...</span>');
            
            sendAjaxData({
                rows,
                perPage,
                offset: 0,
                total,
                progress,
                action,
                btn,
            });
        };
        
        reader.readAsBinaryString(fileInput.files[0]);
    });
    $(document).on('click', '.print-json-table', function(e) {
        e.preventDefault();
        
        const $btn = $(this);
        const targetSelector = $btn.attr('data-target');
        const printUrl = $btn.attr('data-print-url');
        const title = $btn.attr('data-title') || 'پرینت جدول';
        
        let $target = $(targetSelector);
        
        if (!$target.length) {
            alert('جدول مورد نظر پیدا نشد.');
            return;
        }
        
        let $table = $target.is('table') ? $target : $target.find('table').first();
        
        if (!$table.length) {
            alert('داخل target هیچ جدولی پیدا نشد.');
            return;
        }
        
        if (!printUrl) {
            alert('آدرس صفحه پرینت مشخص نیست.');
            return;
        }
        
        const columns = [];
        const rows = [];
        
        let $headerCells = $table.find('thead tr:first th');
        
        if (!$headerCells.length) {
            $headerCells = $table.find('tr:first th');
        }
        
        if (!$headerCells.length) {
            $headerCells = $table.find('tr:first td');
        }
        
        $headerCells.each(function() {
            const text = $(this).
                clone().
                find('script, style, button, a, .no-print, .cs-hide_print').
                remove().
                end().
                text().
                replace(/\s+/g, ' ').
                trim();
            
            columns.push(text);
        });
        
        let $bodyRows = $table.find('tbody tr');
        
        if (!$bodyRows.length) {
            $bodyRows = $table.find('tr').not(':first');
        }
        
        $bodyRows.each(function() {
            const $tr = $(this);
            
            if ($tr.hasClass('no-print') || $tr.hasClass('cs-hide_print')) {
                return;
            }
            
            const row = [];
            
            $tr.find('td').each(function() {
                const $td = $(this);
                const $img = $td.find('img').first();
                
                const text = $td.clone().
                    find('script, style, button, a, input, select, textarea, .no-print, .cs-hide_print').
                    remove().
                    end().
                    text().
                    replace(/\s+/g, ' ').
                    trim();
                
                row.push({
                    text:    text,
                    image:   $img.length ? $img.attr('src') : '',
                    colspan: parseInt($td.attr('colspan') || 1, 10),
                    rowspan: parseInt($td.attr('rowspan') || 1, 10),
                });
            });
            
            if (row.length) {
                rows.push(row);
            }
        });
        
        if (!columns.length || !rows.length) {
            console.log({
                targetSelector: targetSelector,
                table:          $table.get(0),
                columns:        columns,
                rows:           rows,
            });
            
            alert('ستون یا ردیف قابل پرینت پیدا نشد. console را چک کن.');
            return;
        }
        
        const payload = {
            title:   title,
            columns: columns,
            rows:    rows,
        };
        
        const payloadBase64 = btoa(unescape(encodeURIComponent(JSON.stringify(payload))));
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = printUrl;
        form.target = '_blank';
        form.style.display = 'none';
        form.enctype = 'application/x-www-form-urlencoded';
        
        const input = document.createElement('input');
        input.type = 'hidden';
        input.name = 'payload_b64';
        input.value = payloadBase64;
        
        form.appendChild(input);
        document.body.appendChild(form);
        
        form.submit();
        
        setTimeout(function() {
            form.remove();
        }, 1000);
    });
    $(document).on('click', '.open_options_modal', function(e) {
        $('#options_tab').val($(this).attr('data-tab'));
        $('#options_key').val($(this).attr('data-option-key'));
    });
    $(document).on('click', '.delete_db_item', function(e) {
        e.preventDefault();
        
        let $btn = $(this);
        
        let data = {
            action:  $btn.attr('data-action'),
            item_id: $btn.attr('data-item_id') || $btn.attr('data-item-id'),
            tab:     $btn.attr('data-tab'),
            page:    $btn.attr('data-page'),
        };
        
        $.each($btn.data(), function(key, value) {
            if (typeof data[key] === 'undefined') {
                data[key] = value;
            }
        });
        
        if (!data.id && $('#current_user_id').length) {
            data.id = $('#current_user_id').val();
        }
        
        Swal.fire({
            title:             'آیا از حذف این مورد اطمینان دارید؟',
            icon:              'warning',
            text:              'این عملیات غیر قابل بازگشت است',
            focusConfirm:      false,
            showCancelButton:  true,
            confirmButtonText: 'بله',
            cancelButtonText:  `خیر`,
        }).then((result) => {
            if (result.isConfirmed) {
                $.post(ajax_url, data, function(response) {
                    change_panel_html(response);
                    history.pushState({}, '', response.url);
                });
            }
        });
    });
    $(document).on('click', '.atlas-report-modal-trigger', function() {
        let target  = $(this).data('content-target'),
            content = $(target).html() || '';
        
        $('#atlasReportContentModal .atlas-report-modal-body').html(content);
    });
    
    $(document).on('click', '.request_dashboard_block_data', function(e) {
        e.preventDefault();
        
        let $btn = $(this);
        let $card = $btn.closest('.card');
        
        if ($card.data('loading')) {
            return;
        }
        
        let action = $btn.attr('data-action') || '';
        
        if (!action) {
            console.warn('Dashboard block action is empty');
            return;
        }
        
        let data = atlas_parse_dashboard_atts($btn.attr('data-atts') || '');
        data.action = action;
        
        $card.data('loading', true).addClass('is-loading');
        ajax_search = true;
        $.post(ajax_url, data, function(response) {
            let payload = atlas_get_dashboard_payload(response);
            
            if (!payload) {
                console.warn('Invalid dashboard response', response);
                return;
            }
            
            atlas_apply_dashboard_targets(
                $btn.attr('data-targets') || '',
                payload,
            );
            ajax_search = false;
        }).always(function() {
            $card.data('loading', false).removeClass('is-loading');
            $card.find('.request_dashboard_block_data').removeClass('active');
            $btn.addClass('active');
        });
    });
    
    function atlas_parse_dashboard_atts(raw) {
        let data = {};
        
        if (!raw) {
            return data;
        }
        
        raw.split(';').forEach(function(row) {
            row = row.trim();
            
            if (!row) {
                return;
            }
            
            let parts = row.split(':');
            let key = (parts.shift() || '').trim();
            let value = parts.join(':').trim();
            
            if (!key) {
                return;
            }
            
            data[key] = value;
        });
        
        return data;
    }
    
    function atlas_get_dashboard_payload(response) {
        if (!response) {
            return null;
        }
        
        if (response.data) {
            return response.data;
        }
        
        if (response.result) {
            return response.result;
        }
        
        return response;
    }
    
    function atlas_apply_dashboard_targets(rawTargets, payload) {
        if (!rawTargets) {
            return;
        }
        
        rawTargets.split(';').forEach(function(row) {
            row = row.trim();
            
            if (!row) {
                return;
            }
            
            let parts = row.split(':');
            
            if (parts.length < 3) {
                return;
            }
            
            let responseKey = (parts.shift() || '').trim();
            let selector = (parts.shift() || '').trim();
            let action = parts.join(':').trim();
            
            if (!responseKey || !selector || !action) {
                return;
            }
            
            if (typeof payload[responseKey] === 'undefined') {
                return;
            }
            
            let value = payload[responseKey];
            let $target = $(selector);
            
            if (!$target.length) {
                return;
            }
            
            atlas_apply_dashboard_target_action($target, action, value);
        });
    }
    
    function atlas_apply_dashboard_target_action($target, action, value) {
        if (action === 'text') {
            $target.text(value);
            return;
        }
        
        if (action === 'html') {
            $target.html(value);
            return;
        }
        
        if (action === 'class') {
            atlas_apply_dashboard_class($target, value);
            return;
        }
        
        if (action === 'chart') {
            atlas_apply_dashboard_chart($target, value);
        }
    }
    
    function atlas_apply_dashboard_class($target, value) {
        let baseClass = $target.data('baseClass') || '';
        
        if (Array.isArray(value)) {
            value = value.join(' ');
        }
        
        $target.attr('class', (baseClass + ' ' + value).trim());
    }
    
    function atlas_apply_dashboard_chart($target, value) {
        if (!value || typeof value !== 'object') {
            return;
        }
        
        if (value.labels) {
            $target.attr('data-labels', JSON.stringify(value.labels));
        }
        
        if (value.data) {
            $target.attr('data-data', JSON.stringify(value.data));
        }
        
        if (value.points) {
            $target.attr('data-points', JSON.stringify(value.points));
        }
        
        let chart = $target.data('chartInstance');
        
        if (!chart) {
            $target.removeData('chartActivated');
            
            if (typeof activate_charts === 'function') {
                activate_charts();
            }
            
            return;
        }
        
        if (value.labels) {
            chart.data.labels = value.labels;
        }
        
        if (value.points) {
            if (chart.data.datasets[0]) {
                chart.data.datasets[0].data = value.points;
            }
            
            chart.update();
            return;
        }
        
        if (value.data) {
            let datasetsData = atlas_normalize_dashboard_chart_datasets(value.data);
            
            if (chart.data.datasets.length !== datasetsData.length) {
                chart.destroy();
                $target.removeData('chartInstance');
                $target.removeData('chartActivated');
                
                if (typeof activate_charts === 'function') {
                    activate_charts();
                }
                
                return;
            }
            
            chart.data.datasets.forEach(function(dataset, index) {
                dataset.data = datasetsData[index] || [];
            });
            
            chart.update();
        }
    }
    
    function atlas_normalize_dashboard_chart_datasets(data) {
        if (!Array.isArray(data)) {
            return [[data]];
        }
        
        if (!data.length) {
            return [[]];
        }
        
        if (Array.isArray(data[0])) {
            return data;
        }
        
        return [data];
    }
    
    function activate_charts() {
        if (typeof Chart === 'undefined') {
            console.warn('Chart.js not found');
            return;
        }
        
        atlas_init_chart_defaults();
        register_atlas_chart_center_text_plugin();
        register_atlas_doughnut_label_plugin();
        register_atlas_polar_donut_plugin();
        
        $('.atlas-chart, .atlas_chart').each(function() {
            let $chart = $(this);
            
            if ($chart.data('chartActivated')) {
                return;
            }
            
            $chart.data('chartActivated', true);
            
            let type = $chart.attr('data-chart-type') || 'bar';
            let data = atlas_parse_chart_data($chart);
            
            if (!data) {
                console.warn('Invalid chart data', this);
                return;
            }
            
            let canvas = atlas_get_chart_canvas($chart);
            let ctx = canvas.getContext('2d');
            
            let config = {
                type:    atlas_normalize_chart_type(type),
                data:    atlas_build_chart_data($chart, type, data),
                options: atlas_build_chart_options($chart, type),
            };
            
            let chart = new Chart(ctx, config);
            
            $chart.data('chartInstance', chart);
        });
    }
    
    /**
     * =========================
     * Parse chart data
     * =========================
     */
    function atlas_parse_chart_data($chart) {
        let raw = $chart.attr('data-chart-data');
        
        if (raw) {
            return atlas_safe_json_parse(raw);
        }
        
        let points = atlas_safe_json_parse($chart.attr('data-points'));
        
        if (points) {
            return {
                points: points,
            };
        }
        
        let labels = atlas_safe_json_parse($chart.attr('data-labels'));
        let chartData = atlas_safe_json_parse($chart.attr('data-data'));
        
        if (labels && chartData) {
            return {
                labels: labels,
                data:   chartData,
            };
        }
        
        let percent = $chart.attr('data-percent');
        let value = $chart.attr('data-value');
        
        if (percent !== undefined || value !== undefined) {
            return {
                title:   $chart.attr('data-title') || '',
                value:   value || 0,
                percent: percent || 0,
            };
        }
        
        return null;
    }
    
    /**
     * =========================
     * Build chart data
     * =========================
     */
    function atlas_build_chart_data($chart, type, data) {
        let colors = atlas_get_chart_colors();
        
        if (type === 'scatter') {
            return {
                datasets: [
                    {
                        label: $chart.attr('data-label') || '',
                        data:  data.points || [],
                        
                        backgroundColor: $chart.attr('data-color') || $chart.attr('data-point-color') || colors.teal,
                        borderColor:     $chart.attr('data-color') || $chart.attr('data-point-color') || colors.teal,
                        
                        pointRadius:      parseInt($chart.attr('data-point-radius') || 5),
                        pointHoverRadius: parseInt($chart.attr('data-point-hover-radius') || 7),
                        
                        xLabel: $chart.attr('data-x-label') || $chart.attr('data-x-title') || 'محور X',
                        yLabel: $chart.attr('data-y-label') || $chart.attr('data-y-title') || 'محور Y',
                        
                        xUnit: $chart.attr('data-x-unit') || '',
                        yUnit: $chart.attr('data-y-unit') || $chart.attr('data-unit') || '',
                    },
                ],
            };
        }
        
        if (type === 'polar-donut') {
            let rawValues = atlas_normalize_single_dataset(data.data);
            let minRadius = parseFloat($chart.attr('data-min-radius') || 24);
            let renderedValues = atlas_build_polar_donut_render_data(rawValues, minRadius);
            
            return {
                labels:   data.labels,
                datasets: [
                    {
                        label:           $chart.attr('data-label') || '',
                        data:            renderedValues,
                        rawData:         rawValues,
                        backgroundColor: atlas_get_chart_dataset_colors($chart, rawValues),
                        borderWidth:     parseInt($chart.attr('data-border-width') || 0),
                        unit:            $chart.attr('data-unit') || '',
                    },
                ],
            };
        }
        
        if (type === 'line' || type === 'area') {
            return {
                labels:   data.labels,
                datasets: atlas_build_multi_datasets($chart, type, data),
            };
        }
        
        if (type === 'bar' || type === 'horizontalBar') {
            return {
                labels:   data.labels,
                datasets: atlas_build_multi_datasets($chart, type, data),
            };
        }
        
        if (type === 'radar') {
            return {
                labels:   data.labels,
                datasets: atlas_build_multi_datasets($chart, type, data),
            };
        }
        
        if (type === 'radial') {
            let percent = parseFloat(data.percent || 0);
            let remain = Math.max(100 - percent, 0);
            
            return {
                labels:   [
                    data.title || $chart.attr('data-label') || 'مقدار',
                    'باقی‌مانده',
                ],
                datasets: [
                    {
                        data:            [percent, remain],
                        backgroundColor: [
                            $chart.attr('data-color') || $chart.attr('data-ring-color') || colors.primary,
                            $chart.attr('data-ring-bg') || '#eef0f7',
                        ],
                        borderWidth:     0,
                        unit:            $chart.attr('data-unit') || '',
                    },
                ],
            };
        }
        
        /**
         * doughnut / pie / donut
         */
        return {
            labels:   data.labels,
            datasets: [
                {
                    label:           $chart.attr('data-label') || '',
                    data:            atlas_normalize_single_dataset(data.data),
                    backgroundColor: atlas_get_chart_dataset_colors($chart, data.data),
                    borderWidth:     parseInt($chart.attr('data-border-width') || 0),
                    unit:            $chart.attr('data-unit') || '',
                },
            ],
        };
    }
    
    /**
     * =========================
     * Multi Dataset Builder
     * data-label / data-data / data-color / data-unit
     * =========================
     */
    function atlas_build_multi_datasets($chart, type, data) {
        let labels = atlas_to_array(
            atlas_safe_json_parse($chart.attr('data-label')) || $chart.attr('data-label') || '');
        let rawData = data.data;
        let datasetsData = atlas_normalize_datasets_data(rawData);
        
        let colors = atlas_to_array(
            atlas_safe_json_parse($chart.attr('data-color')) || $chart.attr('data-color') || '');
        console.log($chart);
        let units = atlas_to_array(atlas_safe_json_parse($chart.attr('data-unit')) || $chart.attr('data-unit') || '');
        let tensions = atlas_to_array(
            atlas_safe_json_parse($chart.attr('data-tension')) || $chart.attr('data-tension') || '');
        let fills = atlas_to_array(atlas_safe_json_parse($chart.attr('data-fill')) || $chart.attr('data-fill') || '');
        
        let defaultColors = atlas_get_default_color_list();
        
        return datasetsData.map(function(datasetData, index) {
            let color = atlas_get_index_value(colors, index, defaultColors[index % defaultColors.length]);
            let label = atlas_get_index_value(labels, index, '');
            let unit = atlas_get_index_value(units, index, atlas_get_index_value(units, 0, ''));
            
            if (type === 'line' || type === 'area') {
                let tension = parseFloat(atlas_get_index_value(tensions, index, 0.38));
                let fill = atlas_get_bool_value(atlas_get_index_value(fills, index, type === 'area'));
                
                return {
                    label: label,
                    data:  datasetData,
                    
                    borderColor:     color,
                    backgroundColor: atlas_hex_to_rgba(color, fill ? 0.12 : 0),
                    
                    borderWidth:      parseInt($chart.attr('data-border-width') || 3),
                    pointRadius:      parseInt($chart.attr('data-point-radius') || 3),
                    pointHoverRadius: parseInt($chart.attr('data-point-hover-radius') || 5),
                    
                    fill:        fill,
                    lineTension: tension,
                    unit:        unit,
                };
            }
            
            if (type === 'radar') {
                return {
                    label: label,
                    data:  datasetData,
                    
                    backgroundColor:      atlas_hex_to_rgba(color, 0.18),
                    borderColor:          color,
                    pointBackgroundColor: color,
                    pointBorderColor:     '#fff',
                    
                    pointRadius: parseInt($chart.attr('data-point-radius') || 4),
                    borderWidth: parseInt($chart.attr('data-border-width') || 2),
                    unit:        unit,
                };
            }
            
            return {
                label:           label,
                data:            datasetData,
                backgroundColor: color,
                borderColor:     color,
                borderWidth:     parseInt($chart.attr('data-border-width') || 0),
                unit:            unit,
            };
        });
    }
    
    /**
     * =========================
     * Build chart options
     * =========================
     */
    function atlas_build_chart_options($chart, type) {
        let showLegend = $chart.attr('data-legend') !== '0';
        let showGrid = $chart.attr('data-grid') !== '0';
        let title = $chart.attr('data-chart-title') || '';
        let isResponsive = $chart.attr('data-responsive') !== '0';
        let fontFamily = atlas_get_chart_font_family();
        
        let tooltipColors = $chart.attr('data-tooltip-colors');
        
        if (tooltipColors === '0') {
            tooltipColors = false;
        } else if (tooltipColors === '1') {
            tooltipColors = true;
        } else {
            tooltipColors = type !== 'scatter';
        }
        tooltipColors = false;
        
        let tooltipMode = $chart.attr('data-tooltip-mode') || '';
        
        if (!tooltipMode) {
            tooltipMode = (type === 'line' || type === 'area') ? 'index' : 'nearest';
        }
        
        let tooltipIntersect = $chart.attr('data-tooltip-intersect');
        
        if (tooltipIntersect === '1') {
            tooltipIntersect = true;
        } else if (tooltipIntersect === '0') {
            tooltipIntersect = false;
        } else {
            tooltipIntersect = !(type === 'line' || type === 'area');
        }
        
        let options = {
            responsive:          isResponsive,
            maintainAspectRatio: false,
            
            legend: {
                display:  showLegend,
                position: $chart.attr('data-legend-position') || 'bottom',
                rtl:      true,
                labels:   {
                    usePointStyle: true,
                    boxWidth:      8,
                    fontFamily:    fontFamily,
                    padding:       18,
                },
            },
            
            title: {
                display:    title !== '',
                text:       title,
                fontFamily: fontFamily,
                fontSize:   15,
                fontColor:  '#1f2937',
                padding:    18,
            },
            
            tooltips: {
                rtl:             true,
                mode:            tooltipMode,
                intersect:       tooltipIntersect,
                displayColors:   tooltipColors,
                titleFontFamily: fontFamily,
                bodyFontFamily:  fontFamily,
                backgroundColor: '#111827',
                cornerRadius:    8,
                xPadding:        12,
                yPadding:        10,
                callbacks:       {
                    title: function(tooltipItems, chartData) {
                        return atlas_chart_tooltip_title(tooltipItems, chartData, type);
                    },
                    label: function(tooltipItem, chartData) {
                        return atlas_chart_tooltip_label(tooltipItem, chartData, type);
                    },
                },
            },
            
            hover: {
                mode:      tooltipMode,
                intersect: tooltipIntersect,
            },
            
            animation: {
                duration: parseInt($chart.attr('data-animation-duration') || 700),
            },
        };
        
        if (type === 'polar-donut') {
            options.scale = {
                ticks:       {
                    display:     false,
                    beginAtZero: true,
                },
                gridLines:   {
                    display: false,
                },
                angleLines:  {
                    display: false,
                },
                pointLabels: {
                    display: false,
                },
            };
            
            options.startAngle = -0.5 * Math.PI;
            
            options.polarDonut = {
                cutoutPercentage: parseInt($chart.attr('data-cutout') || 36),
                centerFill:       $chart.attr('data-center-fill') || '#fff',
            };
            
            return options;
        }
        
        if (type === 'doughnut' || type === 'donut' || type === 'pie' || type === 'radial') {
            options.cutoutPercentage = parseInt($chart.attr('data-cutout') || 68);
            
            if ($chart.attr('data-show-labels') === '1') {
                options.atlasDoughnutLabels = {
                    type:  $chart.attr('data-label-type') || 'percent',
                    color: $chart.attr('data-label-color') || '#111827',
                };
            }
            
            if (type === 'radial') {
                options.legend.display = false;
                options.tooltips.enabled = $chart.attr('data-tooltip') === '1';
                options.centerText = {
                    title:    $chart.attr('data-center-title') || '',
                    value:    $chart.attr('data-center-value') || '',
                    subtitle: $chart.attr('data-center-subtitle') || '',
                };
            }
            
            return options;
        }
        
        if (type === 'radar') {
            options.scale = {
                ticks:       {
                    display:     false,
                    beginAtZero: true,
                },
                gridLines:   {
                    display: $chart.attr('data-radar-grid') === '1',
                    color:   'rgba(0,0,0,0)',
                },
                angleLines:  {
                    display: $chart.attr('data-radar-lines') === '1',
                    color:   'rgba(0,0,0,0)',
                },
                pointLabels: {
                    fontFamily: fontFamily,
                    fontColor:  '#6b7280',
                    fontSize:   12,
                },
            };
            
            return options;
        }
        
        if (type === 'scatter') {
            options.scales = {
                xAxes: [
                    {
                        type:       'linear',
                        position:   'bottom',
                        gridLines:  {
                            display:    showGrid,
                            color:      '#edf0f5',
                            drawBorder: false,
                        },
                        scaleLabel: {
                            display:     !!$chart.attr('data-x-title'),
                            labelString: $chart.attr('data-x-title') || '',
                            fontFamily:  fontFamily,
                        },
                        ticks:      {
                            fontFamily:  fontFamily,
                            fontColor:   '#6b7280',
                            beginAtZero: $chart.attr('data-begin-zero') !== '0',
                        },
                    },
                ],
                yAxes: [
                    {
                        gridLines:  {
                            display:    showGrid,
                            color:      '#edf0f5',
                            drawBorder: false,
                        },
                        scaleLabel: {
                            display:     !!$chart.attr('data-y-title'),
                            labelString: $chart.attr('data-y-title') || '',
                            fontFamily:  fontFamily,
                        },
                        ticks:      {
                            fontFamily:  fontFamily,
                            fontColor:   '#6b7280',
                            beginAtZero: $chart.attr('data-begin-zero') !== '0',
                        },
                    },
                ],
            };
            
            return options;
        }
        
        if (type === 'line' || type === 'area' || type === 'bar' || type === 'horizontalBar') {
            let showXTicks = $chart.attr('data-x-ticks') !== '0';
            let showYTicks = $chart.attr('data-y-ticks') !== '0';
            
            options.scales = {
                xAxes: [
                    {
                        gridLines: {
                            display:    type === 'horizontalBar' ? showGrid : false,
                            color:      '#edf0f5',
                            drawBorder: false,
                        },
                        ticks:     {
                            display:    showXTicks,
                            fontFamily: fontFamily,
                            fontColor:  '#6b7280',
                        },
                    },
                ],
                yAxes: [
                    {
                        gridLines: {
                            display:    showGrid,
                            color:      '#edf0f5',
                            drawBorder: false,
                        },
                        ticks:     {
                            display:     showYTicks,
                            fontFamily:  fontFamily,
                            fontColor:   '#6b7280',
                            beginAtZero: true,
                        },
                    },
                ],
            };
            
            return options;
        }
        
        return options;
    }
    
    /**
     * =========================
     * Tooltip
     * =========================
     */
    function atlas_chart_tooltip_title(tooltipItems, chartData, type) {
        if (!tooltipItems || !tooltipItems.length) {
            return '';
        }
        
        if (
            type === 'donut' ||
            type === 'doughnut' ||
            type === 'pie' ||
            type === 'polar-donut' ||
            type === 'radial' ||
            type === 'scatter'
        ) {
            return '';
        }
        
        let item = tooltipItems[0];
        let index = typeof item.index !== 'undefined' ? item.index : item._index;
        
        if (chartData.labels && typeof chartData.labels[index] !== 'undefined') {
            return chartData.labels[index];
        }
        
        return '';
    }
    
    function atlas_chart_tooltip_label(tooltipItem, chartData, type) {
        let datasetIndex = typeof tooltipItem.datasetIndex !== 'undefined'
                           ? tooltipItem.datasetIndex
                           : tooltipItem._datasetIndex;
        
        let index = typeof tooltipItem.index !== 'undefined'
                    ? tooltipItem.index
                    : tooltipItem._index;
        
        let dataset = chartData.datasets[datasetIndex || 0];
        
        if (!dataset) {
            return '';
        }
        
        let dataItem = null;
        
        if (dataset.data && typeof dataset.data[index] !== 'undefined') {
            dataItem = dataset.data[index];
        }
        
        /**
         * Scatter:
         * labelX:valueX unitX
         * labelY:valueY unitY
         */
        if (type === 'scatter' && typeof dataItem === 'object' && dataItem !== null) {
            let xLabel = dataItem.x_label || dataItem.label || dataItem.labelX || dataItem.xLabel || dataItem.x;
            let yLabel = dataItem.y_label || dataItem.labelY || dataItem.yLabel || dataItem.y;
            
            let xValue = dataItem.x_value || dataItem.valueX || xLabel;
            let yValue = dataItem.y_value || dataItem.valueY || dataItem.y;
            
            let lines = [];
            
            lines.push(
                (dataset.xLabel || 'محور X') + ': ' + atlas_format_chart_value(xValue, dataset.xUnit || ''),
            );
            
            lines.push(
                (dataset.yLabel || 'محور Y') + ': ' + atlas_format_chart_value(yValue, dataset.yUnit || ''),
            );
            
            return lines;
        }
        
        /**
         * Donut / Doughnut / Pie / Radial
         */
        if (
            type === 'donut' ||
            type === 'doughnut' ||
            type === 'pie' ||
            type === 'radial' ||
            type === 'polar-donut'
        ) {
            let label = '';
            
            if (chartData.labels && typeof chartData.labels[index] !== 'undefined') {
                label = chartData.labels[index];
            }
            
            let tooltipValue = dataItem;
            
            if (
                type === 'polar-donut' &&
                dataset.rawData &&
                typeof dataset.rawData[index] !== 'undefined'
            ) {
                tooltipValue = dataset.rawData[index];
            }
            
            return label + ': ' + atlas_format_chart_value(tooltipValue, dataset.unit || '');
        }
        
        /**
         * Normal charts:
         * title
         * label:value unit
         */
        let value = dataItem;
        
        if (typeof tooltipItem.yLabel !== 'undefined') {
            value = tooltipItem.yLabel;
        } else if (typeof tooltipItem.xLabel !== 'undefined') {
            value = tooltipItem.xLabel;
        }
        
        let datasetLabel = dataset.label || '';
        
        if (datasetLabel) {
            return datasetLabel + ': ' + atlas_format_chart_value(value, dataset.unit || '');
        }
        
        return atlas_format_chart_value(value, dataset.unit || '');
    }
    
    /**
     * =========================
     * Helpers
     * =========================
     */
    function atlas_safe_json_parse(value) {
        if (!value) {
            return null;
        }
        
        if (typeof value !== 'string') {
            return value;
        }
        
        try {
            return JSON.parse(value);
        } catch (e) {
            try {
                return JSON.parse(value.replace(/&quot;/g, '"'));
            } catch (e2) {
                return null;
            }
        }
    }
    
    function atlas_get_chart_canvas($chart) {
        let canvas = $chart.find('canvas').get(0);
        
        if (canvas) {
            return canvas;
        }
        
        let height = parseInt($chart.attr('data-chart-height') || 260);
        
        canvas = document.createElement('canvas');
        canvas.height = height;
        
        $chart.empty().append(canvas);
        
        return canvas;
    }
    
    function atlas_normalize_chart_type(type) {
        if (type === 'donut') {
            return 'doughnut';
        }
        
        if (type === 'area') {
            return 'line';
        }
        
        if (type === 'radial') {
            return 'doughnut';
        }
        
        if (type === 'polar-donut') {
            return 'polarArea';
        }
        
        return type;
    }
    
    function atlas_get_chart_font_family() {
        return $('body').css('font-family') || 'Tahoma, sans-serif';
    }
    
    function atlas_init_chart_defaults() {
        if (typeof Chart === 'undefined') {
            return;
        }
        
        let fontFamily = atlas_get_chart_font_family();
        
        Chart.defaults.global.defaultFontFamily = fontFamily;
        Chart.defaults.global.defaultFontColor = '#6b7280';
    }
    
    function atlas_normalize_datasets_data(data) {
        if (!Array.isArray(data)) {
            return [[data]];
        }
        
        if (!data.length) {
            return [[]];
        }
        
        if (Array.isArray(data[0])) {
            return data;
        }
        
        return [data];
    }
    
    function atlas_normalize_single_dataset(data) {
        if (!Array.isArray(data)) {
            return [data];
        }
        
        if (Array.isArray(data[0])) {
            return data[0];
        }
        
        return data;
    }
    
    function atlas_to_array(value) {
        if (Array.isArray(value)) {
            return value;
        }
        
        if (value === null || typeof value === 'undefined' || value === '') {
            return [];
        }
        
        return [value];
    }
    
    function atlas_get_index_value(values, index, fallback) {
        if (Array.isArray(values) && typeof values[index] !== 'undefined') {
            return values[index];
        }
        
        if (Array.isArray(values) && typeof values[0] !== 'undefined') {
            return values[0];
        }
        
        return fallback;
    }
    
    function atlas_get_bool_value(value) {
        if (value === true || value === 'true' || value === '1' || value === 1) {
            return true;
        }
        
        if (value === false || value === 'false' || value === '0' || value === 0) {
            return false;
        }
        
        return !!value;
    }
    
    function atlas_format_chart_value(value, unit) {
        if (typeof value === 'undefined' || value === null) {
            value = '';
        }
        
        if (!unit) {
            return value;
        }
        
        if (unit === '٪' || unit === '%') {
            return value + unit;
        }
        
        return value + ' ' + unit;
    }
    
    function atlas_get_chart_colors() {
        return {
            primary: '#635bff',
            blue:    '#3b82f6',
            teal:    '#14b8a6',
            orange:  '#f97316',
            pink:    '#ec4899',
            red:     '#f43f5e',
            yellow:  '#f59e0b',
            gray:    '#9ca3af',
        };
    }
    
    function atlas_get_default_color_list() {
        return [
            '#635bff',
            '#3b82f6',
            '#14b8a6',
            '#f97316',
            '#ec4899',
            '#f43f5e',
            '#f59e0b',
            '#9ca3af',
        ];
    }
    
    function atlas_get_chart_dataset_colors($chart, data) {
        let colors = atlas_safe_json_parse($chart.attr('data-color'));
        
        if (!colors) {
            colors = atlas_safe_json_parse($chart.attr('data-colors'));
        }
        
        if (colors && Array.isArray(colors)) {
            return colors;
        }
        
        let singleColor = $chart.attr('data-color');
        
        if (singleColor) {
            return singleColor;
        }
        
        let count = Array.isArray(data) ? data.length : 1;
        let base = atlas_get_default_color_list();
        let output = [];
        
        for (let i = 0; i < count; i++) {
            output.push(base[i % base.length]);
        }
        
        return output;
    }
    
    function atlas_hex_to_rgba(hex, alpha) {
        if (!hex || hex.indexOf('#') !== 0) {
            return hex || 'rgba(99,91,255,' + alpha + ')';
        }
        
        hex = hex.replace('#', '');
        
        if (hex.length === 3) {
            hex = hex.split('').map(function(char) {
                return char + char;
            }).join('');
        }
        
        let r = parseInt(hex.substring(0, 2), 16);
        let g = parseInt(hex.substring(2, 4), 16);
        let b = parseInt(hex.substring(4, 6), 16);
        
        return 'rgba(' + r + ',' + g + ',' + b + ',' + alpha + ')';
    }
    
    /**
     * =========================
     * Center text plugin
     * =========================
     */
    function register_atlas_chart_center_text_plugin() {
        if (window.atlasChartCenterTextPluginRegistered) {
            return;
        }
        
        window.atlasChartCenterTextPluginRegistered = true;
        
        Chart.plugins.register({
            beforeDraw: function(chart) {
                if (!chart.config.options.centerText) {
                    return;
                }
                
                let ctx = chart.chart.ctx;
                let width = chart.chart.width;
                let height = chart.chart.height;
                let centerText = chart.config.options.centerText;
                let fontFamily = atlas_get_chart_font_family();
                
                ctx.save();
                ctx.textAlign = 'center';
                ctx.textBaseline = 'middle';
                ctx.direction = 'rtl';
                
                if (centerText.title) {
                    ctx.font = '12px ' + fontFamily;
                    ctx.fillStyle = '#6b7280';
                    ctx.fillText(centerText.title, width / 2, height / 2 - 24);
                }
                
                if (centerText.value) {
                    ctx.font = 'bold 22px ' + fontFamily;
                    ctx.fillStyle = '#111827';
                    ctx.fillText(centerText.value, width / 2, height / 2);
                }
                
                if (centerText.subtitle) {
                    ctx.font = '12px ' + fontFamily;
                    ctx.fillStyle = '#6b7280';
                    ctx.fillText(centerText.subtitle, width / 2, height / 2 + 24);
                }
                
                ctx.restore();
            },
        });
    }
    
    /**
     * =========================
     * Doughnut labels plugin
     * =========================
     */
    function register_atlas_doughnut_label_plugin() {
        if (window.atlasDoughnutLabelPluginRegistered) {
            return;
        }
        
        window.atlasDoughnutLabelPluginRegistered = true;
        
        Chart.plugins.register({
            afterDatasetsDraw: function(chart) {
                let options = chart.config.options || {};
                
                if (!options.atlasDoughnutLabels) {
                    return;
                }
                
                if (chart.config.type !== 'doughnut' && chart.config.type !== 'pie') {
                    return;
                }
                
                let ctx = chart.chart.ctx;
                let dataset = chart.data.datasets[0];
                
                if (!dataset || !dataset.data) {
                    return;
                }
                
                let total = dataset.data.reduce(function(sum, value) {
                    return sum + Number(value || 0);
                }, 0);
                
                let fontFamily = atlas_get_chart_font_family();
                
                ctx.save();
                ctx.textAlign = 'center';
                ctx.textBaseline = 'middle';
                ctx.direction = 'rtl';
                ctx.font = '12px ' + fontFamily;
                ctx.fillStyle = options.atlasDoughnutLabels.color || '#111827';
                
                chart.getDatasetMeta(0).data.forEach(function(element, index) {
                    let value = Number(dataset.data[index] || 0);
                    
                    if (!value || total <= 0) {
                        return;
                    }
                    
                    let percent = Math.round((value / total) * 100);
                    
                    if (percent < 6) {
                        return;
                    }
                    
                    let position = element.tooltipPosition();
                    let label = chart.data.labels[index] || '';
                    
                    let text = options.atlasDoughnutLabels.type === 'label'
                               ? label
                               : percent + '٪';
                    
                    ctx.fillText(text, position.x, position.y);
                });
                
                ctx.restore();
            },
        });
    }
    
    function atlas_build_polar_donut_render_data(values, minRadiusPercent) {
        if (!Array.isArray(values)) {
            values = [values];
        }
        
        minRadiusPercent = parseFloat(minRadiusPercent || 25);
        
        if (minRadiusPercent < 0) {
            minRadiusPercent = 0;
        }
        
        if (minRadiusPercent > 95) {
            minRadiusPercent = 95;
        }
        
        let maxValue = Math.max.apply(null, values.map(function(value) {
            return Number(value || 0);
        }));
        
        if (!maxValue || maxValue <= 0) {
            return values.map(function() {
                return minRadiusPercent;
            });
        }
        
        return values.map(function(value) {
            value = Number(value || 0);
            
            return minRadiusPercent + ((value / maxValue) * (100 - minRadiusPercent));
        });
    }
    
    function register_atlas_polar_donut_plugin() {
        if (window.atlasPolarDonutPluginRegistered) {
            return;
        }
        
        window.atlasPolarDonutPluginRegistered = true;
        
        Chart.plugins.register({
            afterDatasetsDraw: function(chart) {
                let options = chart.config.options || {};
                
                if (!options.polarDonut) {
                    return;
                }
                
                if (chart.config.type !== 'polarArea') {
                    return;
                }
                
                let meta = chart.getDatasetMeta(0);
                
                if (!meta || !meta.data || !meta.data.length) {
                    return;
                }
                
                let firstArc = meta.data[0];
                
                if (!firstArc || !firstArc._model) {
                    return;
                }
                
                let model = firstArc._model;
                let ctx = chart.chart.ctx;
                
                let centerX = model.x;
                let centerY = model.y;
                let outerRadius = model.outerRadius || 0;
                
                let cutoutPercentage = options.polarDonut.cutoutPercentage || 36;
                let innerRadius = outerRadius * (cutoutPercentage / 100);
                
                ctx.save();
                ctx.beginPath();
                ctx.fillStyle = options.polarDonut.centerFill || '#fff';
                ctx.arc(centerX, centerY, innerRadius, 0, Math.PI * 2);
                ctx.closePath();
                ctx.fill();
                ctx.restore();
            },
        });
    }
    
    function crmNormalizeUploadUrls(value) {
        if (!value) {
            return [];
        }
        
        if (Array.isArray(value)) {
            return value.map(String).map(u => u.trim()).filter(Boolean);
        }
        
        if (typeof value === 'object') {
            if (value.url) {
                return [String(value.url).trim()].filter(Boolean);
            }
            
            return [];
        }
        
        let str = String(value).trim();
        
        if (!str) {
            return [];
        }
        
        try {
            let parsed = JSON.parse(str);
            
            if (Array.isArray(parsed)) {
                return parsed.map(item => {
                    if (typeof item === 'object') {
                        return item.url || item.file_url || item.attachment || '';
                    }
                    
                    return item;
                }).map(String).map(u => u.trim()).filter(Boolean);
            }
            
            if (parsed && typeof parsed === 'object') {
                let url = parsed.url || parsed.file_url || parsed.attachment || '';
                return url ? [String(url).trim()] : [];
            }
        } catch (e) {}
        
        return str.split(',').map(u => u.trim()).filter(Boolean);
    }
    
    function crmFileNameFromUrl(url) {
        let clean = String(url || '').split('?')[0].split('#')[0];
        let name = clean.split('/').pop() || 'file';
        
        try {
            return decodeURIComponent(name);
        } catch (e) {
            return name;
        }
    }
    
    function crmRefreshUploadZone($zone, value) {
        if (!$zone.length) {
            return;
        }
        
        const target = $zone.attr('data-target');
        
        if (!target) {
            return;
        }
        
        const $target = $(target);
        const maxFiles = parseInt($zone.attr('data-max-files')) || 1;
        
        let urls = crmNormalizeUploadUrls(value);
        
        if (maxFiles && urls.length > maxFiles) {
            urls = urls.slice(urls.length - maxFiles);
        }
        
        $target.val(urls.join(',')).trigger('input').trigger('change');
        
        const dz = $zone[0].dropzone;
        
        // اگر هنوز Dropzone init نشده، data-urls را ست کن تا موقع init شدن خودش بسازد
        if (!dz) {
            $zone.attr('data-urls', urls.join(','));
            return;
        }
        
        // حذف previewهای قبلی بدون اینکه hidden input دوباره خراب شود
        dz.files.slice().forEach(function(file) {
            if (file.previewElement) {
                file.previewElement.remove();
            }
        });
        
        dz.files = [];
        $zone.find('.dz-preview').remove();
        
        urls.forEach(function(url) {
            const mockFile = {
                name:          crmFileNameFromUrl(url),
                size:          123456,
                accepted:      true,
                status:        'success',
                _uploaded_url: url,
            };
            
            dz.files.push(mockFile);
            
            dz.emit('addedfile', mockFile);
            
            if (/\.(jpg|jpeg|png|gif|webp|bmp|svg)$/i.test(url)) {
                dz.emit('thumbnail', mockFile, url);
            }
            
            dz.emit('complete', mockFile);
            
            if (mockFile.previewElement) {
                mockFile.previewElement.classList.add('dz-success', 'dz-complete');
            }
        });
    }
    
    $(document).on('click', '.edit_item', function(e) {
        e.preventDefault();
        
        const $btn = $(this);
        const data = ($btn.data('data') || $btn.data()) || {};
        
        let modalName = data.modal || $btn.data('modal');
        
        if (!modalName) {
            return;
        }
        
        const modalSelector = String(modalName).startsWith('#')
                              ? modalName
                              : ('#' + modalName);
        
        const $modal = $(modalSelector);
        
        $modal.find('[data-for]').each(function() {
            const $field = $(this);
            const key = $field.data('for');
            
            if (!key || typeof data[key] === 'undefined') {
                return;
            }
            
            const val = data[key] || '';
            
            // ----------------- quill -----------------
            if ($field.hasClass('quill-basic')) {
                const quillInstance = $field.data('quill');
                
                if (quillInstance && quillInstance.root) {
                    quillInstance.clipboard.dangerouslyPasteHTML(val);
                } else {
                    $field.find('.ql-editor').html(val);
                }
                
                $field.trigger('input').trigger('change');
                return;
            }
            
            // ----------------- select -----------------
            if ($field.is('select')) {
                $field.val(val);
                
                if ($field.hasClass('select2') || $field.hasClass('js-select2') || $field.data('select2')) {
                    $field.trigger('change.select2');
                    $field.trigger('change');
                } else {
                    $field.trigger('change');
                }
                
                return;
            }
            
            // ----------------- checkbox -----------------
            if ($field.is(':checkbox')) {
                if (Array.isArray(val)) {
                    $field.prop('checked', val.includes($field.val()));
                } else {
                    $field.prop('checked', !!val && String(val) === String($field.val()));
                }
                
                $field.trigger('change');
                return;
            }
            
            // ----------------- radio -----------------
            if ($field.is(':radio')) {
                $modal.find(
                    'input[type="radio"][data-for="' + key + '"][value="' + val + '"]',
                ).prop('checked', true).trigger('change');
                
                return;
            }
            
            // ----------------- normal fields -----------------
            $field.val(val).trigger('input').trigger('change');
        });
        
        // ----------------- upload-zone / dropzone -----------------
        $modal.find('.upload-zone[data-target]').each(function() {
            const $zone = $(this);
            const target = $zone.attr('data-target');
            
            if (!target) {
                return;
            }
            
            const $target = $(target);
            
            if (!$target.length) {
                return;
            }
            
            const key = $target.data('for');
            
            if (!key || typeof data[key] === 'undefined') {
                return;
            }
            
            crmRefreshUploadZone($zone, data[key]);
        });
        
        $modal.modal('show');
    });
    $(document).on('hidden.bs.modal', '.modal', function() {
        let $modal = $(this);
        
        $modal.find('input, textarea, select').each(function() {
            let $field = $(this);
            let type = ($field.attr('type') || '').toLowerCase();
            if ($field.hasClass('no_clear')) {
                return;
            }
            if (type === 'checkbox' || type === 'radio') {
                $field.prop('checked', false).trigger('change');
                return;
            }
            
            if ($field.is('select')) {
                $field.val('').trigger('change');
                return;
            }
            
            $field.val('').trigger('change');
        });
        
        $modal.find('[contenteditable="true"]').each(function() {
            $(this).html('');
        });
        
        $modal.find('.ql-editor').each(function() {
            $(this).html('<p><br></p>');
        });
        
        $modal.find('[data-readonly-on-edit="1"]').each(function() {
            $(this).prop('readonly', false);
            $(this).prop('disabled', false);
        });
    });
    
    function render_map() {
        const mapEl = document.getElementById('kasebi-user-location-map');
        console.log(mapEl);
        if (!mapEl || typeof L === 'undefined') {
            return;
        }
        
        const latInput = document.getElementById('kasebi_user_lat');
        const lngInput = document.getElementById('kasebi_user_lng');
        const clearBtn = document.getElementById('kasebi-clear-user-location');
        
        if (!latInput || !lngInput) {
            return;
        }
        
        let lat = parseFloat(mapEl.getAttribute('data-lat')) || 35.700936;
        let lng = parseFloat(mapEl.getAttribute('data-lng')) || 51.391194;
        
        const map = new L.Map('kasebi-user-location-map', {
            key:     kcpData.key,
            maptype: 'dreamy',
            center:  [lat, lng],
            zoom:    15,
        });
        console.log(map);
        let marker = L.marker([lat, lng], {
            draggable: true,
        }).addTo(map);
        
        function normalizeNumber(value) {
            value = parseFloat(value);
            
            if (Number.isNaN(value)) {
                return '';
            }
            
            return value.toFixed(7);
        }
        
        function setLocation(newLat, newLng, moveMap = false) {
            newLat = parseFloat(newLat);
            newLng = parseFloat(newLng);
            
            if (Number.isNaN(newLat) || Number.isNaN(newLng)) {
                return;
            }
            
            latInput.value = normalizeNumber(newLat);
            lngInput.value = normalizeNumber(newLng);
            
            marker.setLatLng([newLat, newLng]);
            
            if (moveMap) {
                map.setView([newLat, newLng], map.getZoom());
            }
        }
        
        function showLocationError(message) {
            if (typeof alert === 'function') {
                alert(message);
            }
        }
        
        const CurrentLocationControl = L.Control.extend({
            options: {
                position: 'topleft',
            },
            
            onAdd: function() {
                const container = L.DomUtil.create('div', 'leaflet-bar kasebi-current-location-control');
                const button = L.DomUtil.create('button', '', container);
                
                button.type = 'button';
                button.title = 'موقعیت فعلی من';
                button.innerHTML = 'موقعیت من';
                
                L.DomEvent.disableClickPropagation(container);
                L.DomEvent.disableScrollPropagation(container);
                
                L.DomEvent.on(button, 'click', function(event) {
                    L.DomEvent.preventDefault(event);
                    
                    if (!navigator.geolocation) {
                        showLocationError('مرورگر شما از دریافت موقعیت مکانی پشتیبانی نمی‌کند.');
                        return;
                    }
                    
                    button.classList.add('is-loading');
                    button.disabled = true;
                    button.innerHTML = 'در حال دریافت...';
                    
                    navigator.geolocation.getCurrentPosition(
                        function(position) {
                            const currentLat = position.coords.latitude;
                            const currentLng = position.coords.longitude;
                            
                            setLocation(currentLat, currentLng, true, 16);
                            
                            button.classList.remove('is-loading');
                            button.disabled = false;
                            button.innerHTML = 'موقعیت من';
                        },
                        function() {
                            button.classList.remove('is-loading');
                            button.disabled = false;
                            button.innerHTML = 'موقعیت من';
                            
                            showLocationError(
                                'امکان دریافت موقعیت فعلی وجود ندارد. دسترسی لوکیشن مرورگر را بررسی کنید.');
                        },
                        {
                            enableHighAccuracy: true,
                            timeout:            10000,
                            maximumAge:         0,
                        },
                    );
                });
                
                return container;
            },
        });
        
        map.addControl(new CurrentLocationControl());
        
        map.on('click', function(event) {
            setLocation(event.latlng.lat, event.latlng.lng);
        });
        
        marker.on('dragend', function() {
            const position = marker.getLatLng();
            
            setLocation(position.lat, position.lng);
        });
        
        latInput.addEventListener('change', function() {
            setLocation(latInput.value, lngInput.value, true);
        });
        
        lngInput.addEventListener('change', function() {
            setLocation(latInput.value, lngInput.value, true);
        });
        
        if (clearBtn) {
            clearBtn.addEventListener('click', function() {
                latInput.value = '';
                lngInput.value = '';
            });
        }
        
        setTimeout(function() {
            map.invalidateSize();
        }, 300);
    }
    
    $(document).on('click', '.change_user_marketer_bulk', function(e) {
        e.preventDefault();
        const itemsArr = $('.select_item_row:checked').map(function() { return $(this).val(); }).get();
        if (!itemsArr.length) {
            NioApp.Toast('هیچ آیتمی انتخاب نشده است.', 'warning', {position: 'top-right'});
            return;
        }
        let data = {
            action:   'crm_assign_customer_sales',
            user_ids: itemsArr,
            marketer: $(this).attr('data-id'),
            assignment_type: $(this).attr('data-type'),
            assignment_nonce: $(this).attr('data-nonce'),
        };
        $.post(ajax_url, data, function(response) {
            change_panel_html(response);
            if (response.status === 'success') { window.location.reload(); }
        }).fail(function() {
            NioApp.Toast('ارتباط با سرور برقرار نشد؛ دوباره تلاش کنید.', 'error', {position: 'top-right'});
        });
    });

    $(document).on('click', '.kcp-save-sales-agent', function(e) {
        e.preventDefault();
        const button = $(this);
        button.prop('disabled', true);
        $.post(ajax_url, {
            action: 'crm_assign_customer_sales',
            user_ids: [button.attr('data-customer')],
            marketer: $('#' + button.attr('data-select')).val(),
            assignment_type: button.attr('data-type'),
            assignment_nonce: button.attr('data-nonce')
        }, function(response) {
            change_panel_html(response);
            if (response.status === 'success') { window.location.reload(); }
        }).fail(function() {
            NioApp.Toast('ارتباط با سرور برقرار نشد؛ دوباره تلاش کنید.', 'error', {position: 'top-right'});
        }).always(function() { button.prop('disabled', false); });
    });
}(NioApp, jQuery);
