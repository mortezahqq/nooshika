(function($) {
    'use strict';
    let sequence = 0;
    function state(panel) { return $(panel).data('kcpPricingState'); }
    function status(panel, message, error) {
        const node = panel.querySelector('.kcp-pricing-status');
        node.textContent = message;
        node.classList.toggle('text-danger', !!error);
    }
    function empty(panel) {
        panel.querySelector('.kcp-pricing-empty').hidden = !!panel.querySelector('.kcp-pricing-row');
    }
    function saleVisibility(row) {
        const show = row.querySelector('.kcp-pricing-type').value === 'fixed_price';
        const input = row.querySelector('.kcp-pricing-sale');
        input.hidden = !show; input.disabled = !show;
        row.querySelector('.kcp-pricing-no-sale').hidden = show;
    }
    function addRow(panel, rule) {
        const current = state(panel);
        const row = panel.querySelector('.kcp-pricing-row-template').content.firstElementChild.cloneNode(true);
        const role = row.querySelector('.kcp-pricing-role');
        role.add(new Option('انتخاب نقش', ''));
        Object.keys(current.roles).forEach(key => {
            const value = current.roles[key];
            role.add(new Option(typeof value === 'object' ? value.label : value, key));
        });
        const type = row.querySelector('.kcp-pricing-type');
        Object.keys(current.types).forEach(key => type.add(new Option(current.types[key], key)));
        role.value = rule.role || '';
        type.value = rule.type || 'percent_discount';
        row.querySelector('.kcp-pricing-amount').value = rule.amount == null ? '' : rule.amount;
        row.querySelector('.kcp-pricing-sale').value = rule.sale_price == null ? '' : rule.sale_price;
        panel.querySelector('.kcp-pricing-rows').appendChild(row);
        saleVisibility(row); empty(panel);
    }
    function load(modal) {
        const panel = modal.querySelector('.kcp-role-pricing-panel');
        if (!panel) { return; }
        const old = state(panel);
        if (old && old.xhr) { old.xhr.abort(); }
        const id = modal.querySelector('[data-for="product_id"]').value || '0';
        const current = {id: String(id), token: ++sequence, loading: true, loaded: false, dirty: false, version: '', roles: {}, types: {}};
        $(panel).data('kcpPricingState', current);
        panel.querySelector('.kcp-pricing-rows').replaceChildren();
        panel.querySelector('.kcp-pricing-editor').hidden = true;
        panel.querySelector('.kcp-pricing-retry').hidden = true;
        status(panel, 'در حال دریافت قوانین قیمت‌گذاری…', false);
        current.xhr = $.post(kcpData.ajax_url, {
            action: 'crm_get_role_pricing', product_id: current.id, pricing_nonce: panel.getAttribute('data-nonce')
        }).done(function(response) {
            if (state(panel) !== current) { return; }
            current.loading = false;
            if (!response || response.status !== 'success' || !Array.isArray(response.rules)) {
                status(panel, response && response.message ? response.message : 'دریافت قوانین انجام نشد.', true);
                panel.querySelector('.kcp-pricing-retry').hidden = false;
                return;
            }
            current.roles = response.roles || {}; current.types = response.types || {}; current.version = response.version || '';
            response.rules.forEach(rule => addRow(panel, rule));
            current.loaded = true;
            panel.querySelector('.kcp-pricing-editor').hidden = false;
            empty(panel); status(panel, '', false);
        }).fail(function(xhr, reason) {
            if (state(panel) !== current || reason === 'abort') { return; }
            current.loading = false;
            status(panel, 'ارتباط برقرار نشد؛ دریافت دوباره قوانین را بزنید.', true);
            panel.querySelector('.kcp-pricing-retry').hidden = false;
        });
    }
    window.kcpRolePricing = {
        collect: function(form) {
            const panel = form.querySelector('.kcp-role-pricing-panel');
            if (!panel) { return {ok: true, data: {}}; }
            const current = state(panel);
            const id = String(form.querySelector('[data-for="product_id"]').value || '0');
            if (!current || current.id !== id || current.loading) {
                return {ok: false, message: 'دریافت قوانین قیمت‌گذاری هنوز تمام نشده است؛ چند لحظه صبر کنید.'};
            }
            if (!current.loaded || !current.dirty) { return {ok: true, data: {}}; }
            const rules = Array.from(panel.querySelectorAll('.kcp-pricing-row')).map(row => ({
                role: row.querySelector('.kcp-pricing-role').value,
                type: row.querySelector('.kcp-pricing-type').value,
                amount: row.querySelector('.kcp-pricing-amount').value,
                sale_price: row.querySelector('.kcp-pricing-type').value === 'fixed_price' ? row.querySelector('.kcp-pricing-sale').value : ''
            }));
            return {ok: true, data: {role_pricing_submitted: '1', role_pricing_nonce: panel.getAttribute('data-nonce'), role_pricing_version: current.version, role_pricing_rules: JSON.stringify(rules)}};
        }
    };
    $(document).on('show.bs.modal', '#addProduct', function() { load(this); });
    $(document).on('hidden.bs.modal', '#addProduct', function() {
        const panel = this.querySelector('.kcp-role-pricing-panel');
        if (!panel) { return; }
        const current = state(panel);
        $(panel).removeData('kcpPricingState');
        if (current && current.xhr) { current.xhr.abort(); }
    });
    $(document).on('click', '.kcp-pricing-retry', function() { load(this.closest('.modal')); });
    $(document).on('click', '.kcp-pricing-add', function() {
        const panel = this.closest('.kcp-role-pricing-panel'), current = state(panel);
        if (!current || !current.loaded) { return; }
        if (panel.querySelectorAll('.kcp-pricing-row').length >= 100) { status(panel, 'حداکثر ۱۰۰ قانون برای محصول مجاز است.', true); return; }
        addRow(panel, {}); current.dirty = true;
    });
    $(document).on('click', '.kcp-pricing-remove', function() {
        const panel = this.closest('.kcp-role-pricing-panel');
        this.closest('.kcp-pricing-row').remove(); state(panel).dirty = true; empty(panel);
    });
    $(document).on('input change', '.kcp-pricing-row input, .kcp-pricing-row select', function() {
        const panel = this.closest('.kcp-role-pricing-panel'), current = state(panel);
        if (!current || !current.loaded) { return; }
        current.dirty = true; saleVisibility(this.closest('.kcp-pricing-row'));
    });
})(jQuery);
