<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Edit KWCM product pricing from CRM without duplicating its pricing engine. */
final class KCP_Role_Pricing {
    public static function init(): void {
        add_action( 'plugins_loaded', [ __CLASS__, 'ensure_ajax_access' ], 20 );
        add_action( 'nooshika_ajax_crm_get_role_pricing', [ __CLASS__, 'ajax_get' ] );
    }

    public static function ensure_ajax_access(): void {
        $plugin = 'kasebi-wc-management/kasebi-wc-management.php';
        if ( ! is_file( WP_PLUGIN_DIR . '/' . $plugin ) ) { return; }
        $allowed = get_option( 'kcp_ajax_active_plugins', [] );
        $allowed = is_array( $allowed ) ? $allowed : [];
        if ( ! in_array( $plugin, $allowed, TRUE ) ) {
            $allowed[] = $plugin;
            // Only permits an already-active plugin on CRM's filtered requests.
            update_option( 'kcp_ajax_active_plugins', $allowed );
        }
    }

    public static function ready(): bool {
        return class_exists( 'KWCM_Modules' ) && KWCM_Modules::is_enabled( 'pricing' )
            && class_exists( 'KWCM_Roles' ) && class_exists( 'KWCM_Modules_Pricing_Storage' )
            && class_exists( 'KWCM_Modules_Pricing_Product' );
    }

    private static function can_edit( int $id ): bool {
        return is_user_logged_in() && ( current_user_can( 'manage_woocommerce' ) || current_user_can( 'manage_options' ) )
            && ( ! $id || current_user_can( 'edit_post', $id ) );
    }

    private static function valid_nonce( $nonce ): bool {
        return is_string( $nonce ) && (bool) wp_verify_nonce( wp_unslash( $nonce ), 'kcp_role_pricing' );
    }

    public static function fingerprint( int $id ): string {
        return hash_hmac( 'sha256', wp_json_encode( [ $id,
            get_post_meta( $id, '_kwcm_pricing_role_rules', TRUE ),
            get_post_meta( $id, '_krbp_role_pricing_rules', TRUE ),
        ] ), wp_salt( 'nonce' ) );
    }

    public static function ajax_get(): void {
        $raw_id = $_POST['product_id'] ?? '0';
        if ( ! is_scalar( $raw_id ) || ! preg_match( '/^[0-9]+$/D', (string) $raw_id ) ) {
            wp_send_json( [ 'status' => 'error', 'message' => 'شناسه محصول معتبر نیست.' ] );
        }
        $id = (int) $raw_id;
        if ( ! self::can_edit( $id ) || ! self::valid_nonce( $_POST['pricing_nonce'] ?? '' ) ) {
            wp_send_json( [ 'status' => 'error', 'message' => 'اجازه دسترسی ندارید یا اعتبار درخواست تمام شده؛ صفحه را تازه کنید.' ] );
        }
        if ( ! self::ready() ) {
            wp_send_json( [ 'status' => 'error', 'message' => 'افزونه مدیریت ووکامرس و ماژول قیمت‌گذاری آن باید فعال باشند.' ] );
        }
        if ( $id && ! wc_get_product( $id ) ) {
            wp_send_json( [ 'status' => 'error', 'message' => 'محصول انتخاب‌شده یافت نشد.' ] );
        }
        wp_send_json( [ 'status' => 'success',
            'rules' => $id ? KWCM_Modules_Pricing_Product::get_product_rules( $id ) : [],
            'roles' => KWCM_Roles::get_role_options( TRUE ),
            'types' => KWCM_Modules_Pricing_Storage::get_type_options(),
            'version' => $id ? self::fingerprint( $id ) : '',
        ] );
    }

    private static function number( $raw, string $label, bool $optional = FALSE ) {
        if ( ! is_scalar( $raw ) ) { return new WP_Error( 'number', $label . ' معتبر نیست.' ); }
        $text = strtr( trim( (string) $raw ), array_combine(
            preg_split( '//u', '۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩', -1, PREG_SPLIT_NO_EMPTY ),
            str_split( '01234567890123456789' )
        ) );
        $text = str_replace( [ ',', '٬', '،', ' ', "\xC2\xA0" ], '', $text );
        $text = str_replace( '٫', '.', $text );
        if ( $text === '' && $optional ) { return ''; }
        if ( ! preg_match( '/^(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)$/D', $text ) || ! is_finite( (float) $text ) ) {
            return new WP_Error( 'number', $label . ' باید عددی نامنفی باشد.' );
        }
        return (float) $text;
    }

    public static function validate_rules( array $rules ) {
        if ( count( $rules ) > 100 ) { return new WP_Error( 'limit', 'حداکثر ۱۰۰ قانون برای محصول مجاز است.' ); }
        $roles = KWCM_Roles::get_role_options( TRUE );
        $types = KWCM_Modules_Pricing_Storage::get_allowed_types();
        $clean = []; $seen = [];
        foreach ( $rules as $i => $rule ) {
            if ( ! is_array( $rule ) ) { return new WP_Error( 'rule', 'ساختار قانون قیمت‌گذاری معتبر نیست.' ); }
            foreach ( [ 'role', 'type', 'amount', 'sale_price' ] as $key ) {
                if ( isset( $rule[ $key ] ) && ! is_scalar( $rule[ $key ] ) ) {
                    return new WP_Error( 'rule', 'مقدار یکی از فیلدهای قانون معتبر نیست.' );
                }
            }
            if ( trim( (string) ( $rule['role'] ?? '' ) ) === '' && trim( (string) ( $rule['amount'] ?? '' ) ) === ''
                && trim( (string) ( $rule['sale_price'] ?? '' ) ) === '' ) { continue; }
            $role = (string) ( $rule['role'] ?? '' ); $type = (string) ( $rule['type'] ?? '' );
            if ( ! isset( $roles[ $role ] ) ) { return new WP_Error( 'role', 'نقش کاربری قانون را انتخاب کنید.' ); }
            if ( isset( $seen[ $role ] ) ) { return new WP_Error( 'duplicate', 'برای هر نقش فقط یک قانون قیمت‌گذاری ثبت کنید.' ); }
            if ( ! in_array( $type, $types, TRUE ) ) { return new WP_Error( 'type', 'نوع قیمت‌گذاری معتبر نیست.' ); }
            $amount = self::number( $rule['amount'] ?? '', 'مقدار قانون' );
            if ( is_wp_error( $amount ) ) { return $amount; }
            if ( $type === 'percent_discount' && ( $amount <= 0 || $amount > 100 ) ) {
                return new WP_Error( 'percent', 'درصد تخفیف باید بیشتر از صفر و حداکثر ۱۰۰ باشد.' );
            }
            if ( $type === 'fixed_discount' && $amount <= 0 ) { return new WP_Error( 'amount', 'مبلغ تخفیف باید بیشتر از صفر باشد.' ); }
            $item = [ 'role' => $role, 'type' => $type, 'amount' => $amount ];
            if ( $type === 'fixed_price' ) {
                $sale = self::number( $rule['sale_price'] ?? '', 'قیمت فروش ویژه', TRUE );
                if ( is_wp_error( $sale ) ) { return $sale; }
                if ( $sale !== '' && $sale > 0 && $sale >= $amount ) {
                    return new WP_Error( 'sale', 'قیمت فروش ویژه نقش باید کمتر از قیمت ثابت آن باشد.' );
                }
                $item['sale_price'] = $sale !== '' && $sale > 0 ? $sale : '';
            }
            $clean[] = $item; $seen[ $role ] = TRUE;
        }
        // The original storage remains the authority for its saved format.
        return KWCM_Modules_Pricing_Storage::sanitize_rules( $clean );
    }

    /** Null means the pricing section was not changed: preserve all stored rules. */
    public static function prepare_submission( array $request, int $id ) {
        if ( ! isset( $request['role_pricing_submitted'] ) ) { return NULL; }
        if ( ! in_array( $request['role_pricing_submitted'], [ '1', 1 ], TRUE ) ) {
            return new WP_Error( 'rules', 'وضعیت ارسال قوانین معتبر نیست.' );
        }
        if ( ! self::can_edit( $id ) || ! self::valid_nonce( $request['role_pricing_nonce'] ?? '' ) ) {
            return new WP_Error( 'access', 'اجازه تغییر قیمت‌گذاری ندارید یا اعتبار درخواست تمام شده است.' );
        }
        if ( ! self::ready() ) { return new WP_Error( 'inactive', 'افزونه مدیریت ووکامرس و ماژول قیمت‌گذاری آن باید فعال باشند.' ); }
        if ( $id && ! wc_get_product( $id ) ) { return new WP_Error( 'product', 'محصول انتخاب‌شده یافت نشد.' ); }
        $version = $request['role_pricing_version'] ?? '';
        if ( $id && ( ! is_string( $version ) || ! hash_equals( self::fingerprint( $id ), $version ) ) ) {
            return new WP_Error( 'conflict', 'قیمت‌گذاری این محصول در جای دیگری تغییر کرده است؛ محصول را دوباره باز کنید.' );
        }
        $json = $request['role_pricing_rules'] ?? NULL;
        if ( ! is_string( $json ) || strlen( $json ) > 131072 ) { return new WP_Error( 'rules', 'اطلاعات قوانین قیمت‌گذاری معتبر نیست.' ); }
        $json = trim( wp_unslash( $json ) );
        if ( $json === '' || $json[0] !== '[' ) { return new WP_Error( 'rules', 'فهرست قوانین معتبر نیست.' ); }
        $rules = json_decode( $json, TRUE );
        if ( json_last_error() !== JSON_ERROR_NONE || ! is_array( $rules ) ) {
            return new WP_Error( 'rules', 'اطلاعات قوانین قیمت‌گذاری معتبر نیست.' );
        }
        return self::validate_rules( $rules );
    }

    public static function save( int $id, array $rules ) {
        try {
            KWCM_Modules_Pricing_Product::update_product_rules( $id, $rules );
            if ( KWCM_Modules_Pricing_Product::get_product_rules( $id ) !== $rules ) {
                return new WP_Error( 'write', 'ذخیره قوانین قیمت‌گذاری انجام نشد؛ دوباره تلاش کنید.' );
            }
        } catch ( Throwable $e ) {
            return new WP_Error( 'write', 'ذخیره قوانین قیمت‌گذاری انجام نشد؛ دوباره تلاش کنید.' );
        }
        return TRUE;
    }
}
