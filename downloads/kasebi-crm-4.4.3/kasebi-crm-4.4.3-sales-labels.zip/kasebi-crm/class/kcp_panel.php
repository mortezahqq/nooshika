<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class kcp_panel {
	
	public function __construct() {
		add_shortcode( 'kasebi-crm', [ $this, 'render_crm_page_template' ] );
	}
	
	public function render_crm_page_template(): bool|string {
		ob_start();
		echo '<div class="nk-app-root">';
		echo crm_get_template( 'layout/main.php' );
		echo '</div>';
		
		return ob_get_clean();
	}
	
}