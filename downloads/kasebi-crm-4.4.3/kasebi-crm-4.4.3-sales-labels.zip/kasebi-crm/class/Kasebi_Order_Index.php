<?php

defined( 'ABSPATH' ) || exit;

class Kasebi_Order_Index {
	
	private string $db_prefix;
	private string $db_charset;
	private wpdb   $db;
	
	public string $order_index_table;
	
	public function __construct() {
		global $wpdb;
		$this->db         = $wpdb;
		$this->db_prefix  = $this->db->prefix . 'kasebi_crm_';
		$this->db_charset = $this->db->get_charset_collate();
		
		$this->order_index_table = $this->db_prefix . 'order_index';
		
		add_action( 'woocommerce_after_order_object_save', [ $this, 'on_order_saved' ], 100, 2 );
		add_action( 'woocommerce_order_status_changed', [ $this, 'on_status_changed' ], 100, 4 );
		add_action( 'kasebi_order_saved', [ $this, 'on_status_changed' ] );
		add_action( 'before_delete_post', [ $this, 'on_before_delete_post' ], 100 );
		add_action( 'woocommerce_before_delete_order', [ $this, 'on_before_delete_order' ], 100, 1 );
		
		add_action( 'nooshika_ajax_reindex_woocommerce_orders', [ $this, 'reindex_all' ] );
	}
	
	// ---------- Hook wrappers ----------
	
	/** @param   WC_Order  $order */
	public function on_order_saved( $order, $data_store = NULL ): void {
		if ( $order instanceof WC_Order ) {
			$this->upsert_order_by_id( (int) $order->get_id() );
		}
	}
	
	public function on_status_changed( int $order_id, $old = '', $new = '', $order = NULL ): void {
		$this->upsert_order_by_id( $order_id );
	}
	
	public function on_before_delete_post( int $post_id ): void {
		if ( get_post_type( $post_id ) === 'shop_order' ) {
			$this->delete_order_by_id( $post_id );
		}
	}
	
	/** @param   WC_Order  $order */
	public function on_before_delete_order( $order ): void {
		if ( $order instanceof WC_Order ) {
			$this->delete_order_by_id( $order->get_id() );
		} elseif ( is_numeric( $order ) ) {
			$this->delete_order_by_id( (int) $order );
		}
	}
	
	public function create_main_table(): void {
		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
		maybe_create_table( $this->order_index_table, $this->get_order_index_table_query() );
		$this->ensure_order_index_columns();
	}
	
	private function ensure_order_index_columns(): void {
		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
		
		maybe_add_column(
			$this->order_index_table,
			'billing_state',
			"ALTER TABLE {$this->order_index_table} ADD billing_state VARCHAR(100) NULL AFTER billing_email"
		);
		
		maybe_add_column(
			$this->order_index_table,
			'billing_city',
			"ALTER TABLE {$this->order_index_table} ADD billing_city VARCHAR(100) NULL AFTER billing_state"
		);
		
		maybe_add_column(
			$this->order_index_table,
			'billing_address_1',
			"ALTER TABLE {$this->order_index_table} ADD billing_address_1 TEXT NULL AFTER billing_city"
		);
		
		$has_index = $this->db->get_var(
			$this->db->prepare(
				"SHOW INDEX FROM {$this->order_index_table} WHERE Key_name = %s LIMIT 1",
				'idx_state_city'
			)
		);
		
		if ( ! $has_index ) {
			$this->db->query(
				"ALTER TABLE {$this->order_index_table} ADD KEY idx_state_city (billing_state, billing_city)"
			);
		}
	}
	
	private function get_order_index_table_query(): string {
		return <<<SQL
			CREATE TABLE {$this->order_index_table} (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				order_id BIGINT UNSIGNED NOT NULL,
				order_item_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				product_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				variation_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				item_qty DECIMAL(20,6) NOT NULL DEFAULT 0,
				item_subtotal DECIMAL(20,6) NOT NULL DEFAULT 0,
				item_total DECIMAL(20,6) NOT NULL DEFAULT 0,
				status VARCHAR(32) NOT NULL,
				date_created_gmt DATETIME NOT NULL,
				billing_first_name VARCHAR(100) NULL,
				billing_last_name  VARCHAR(100) NULL,
				billing_phone      VARCHAR(50)  NULL,
				billing_email      VARCHAR(190) NULL,
				billing_state      VARCHAR(100) NULL,
				billing_city       VARCHAR(100) NULL,
				billing_address_1  TEXT NULL,
				marketer_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				utm_source   VARCHAR(150) NULL,
				utm_medium   VARCHAR(150) NULL,
				utm_campaign VARCHAR(200) NULL,
				utm_term     VARCHAR(200) NULL,
				utm_content  VARCHAR(200) NULL,
				total DECIMAL(20,6) NULL,
				currency VARCHAR(10) NULL,
				PRIMARY KEY (id),
				KEY idx_order_item (order_id, order_item_id),
				KEY idx_product_date (product_id, variation_id, date_created_gmt),
				KEY idx_status_date (status, date_created_gmt),
				KEY idx_marketer_date (marketer_id, date_created_gmt),
				KEY idx_email (billing_email),
				KEY idx_phone (billing_phone),
				KEY idx_utm_source (utm_source),
				KEY idx_utm_campaign (utm_campaign),
				KEY idx_state_city (billing_state, billing_city),
				KEY idx_date (date_created_gmt)
			) {$this->db_charset};
		SQL;
	}
	
	// ---------- Core upsert/delete ----------
	
	public function upsert_order_by_id( int $order_id ): void {
		if ( $order_id <= 0 ) {
			return;
		}
		
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return;
		}
		$this->db->delete( $this->order_index_table, [ 'order_id' => $order_id ], [ '%d' ] );
		
		$status = 'wc-' . str_replace( 'wc-', '', $order->get_status() );
		$dt     = $order->get_date_created( 'gmt' );
		$dt_sql = $dt ? $dt->date( 'Y-m-d H:i:s' ) : current_time( 'mysql', TRUE );
		
		$billing_first     = (string) $order->get_billing_first_name();
		$billing_last      = (string) $order->get_billing_last_name();
		$billing_phone     = (string) $order->get_billing_phone();
		$billing_email     = (string) $order->get_billing_email();
		$billing_state     = (string) $order->get_billing_state();
		$billing_city      = (string) $order->get_billing_city();
		$billing_address_1 = (string) $order->get_billing_address_1();
		$customer_id       = absint( $order->get_customer_id() );
		$billing_first     = $billing_first !== '' || $customer_id <= 0
			? $billing_first
			: (string) get_user_meta( $customer_id, 'first_name', TRUE );
		
		$billing_last = $billing_last !== '' || $customer_id <= 0
			? $billing_last
			: (string) get_user_meta( $customer_id, 'last_name', TRUE );
		
		$billing_phone = $billing_phone !== '' || $customer_id <= 0
			? $billing_phone
			: (string) get_user_meta( $customer_id, 'nooshika_phone_num', TRUE );
		
		$marketer_id = absint( (string) $order->get_meta( 'marketer_id', TRUE ) );
		
		$utm_source   = (string) $order->get_meta( '_wc_order_attribution_utm_source', TRUE );
		$utm_medium   = (string) $order->get_meta( '_wc_order_attribution_utm_medium', TRUE );
		$utm_campaign = (string) $order->get_meta( '_wc_order_attribution_utm_campaign', TRUE );
		$utm_term     = (string) $order->get_meta( '_wc_order_attribution_utm_term', TRUE );
		$utm_content  = (string) $order->get_meta( '_wc_order_attribution_utm_content', TRUE );
		
		$total    = (float) $order->get_total();
		$currency = strtoupper( $order->get_currency() );
		
		$rows = [];
		foreach ( $order->get_items() as $item ) {
			/** @var WC_Order_Item_Product $item */
			$pid           = $item->get_product_id();
			$vid           = (int) $item->get_variation_id();
			$order_item_id = (int) $item->get_id();
			$item_qty      = $item->get_meta( 'line_decimal_qty' ) ?: $item->get_quantity();
			$item_subtotal = (float) $item->get_subtotal();
			$item_total    = (float) $item->get_total();
			
			$rows[] = [
				'order_id'           => $order_id,
				'product_id'         => $pid,
				'variation_id'       => $vid,
				'item_qty'           => $item_qty,
				'item_subtotal'      => $item_subtotal,
				'item_total'         => $item_total,
				'status'             => $status,
				'date_created_gmt'   => $dt_sql,
				'billing_first_name' => $billing_first ?: NULL,
				'billing_last_name'  => $billing_last ?: NULL,
				'billing_phone'      => $billing_phone ?: NULL,
				'billing_email'      => $billing_email ?: NULL,
				'billing_state'      => $billing_state ?: NULL,
				'billing_city'       => $billing_city ?: NULL,
				'billing_address_1'  => $billing_address_1 ?: NULL,
				'marketer_id'        => $marketer_id,
				'utm_source'         => $utm_source ?: NULL,
				'utm_medium'         => $utm_medium ?: NULL,
				'utm_campaign'       => $utm_campaign ?: NULL,
				'utm_term'           => $utm_term ?: NULL,
				'utm_content'        => $utm_content ?: NULL,
				'total'              => $total,
				'currency'           => $currency ?: NULL,
			];
		}
		
		if ( empty( $rows ) ) {
			$rows[] = [
				'order_id'           => $order_id,
				'order_item_id'      => 0,
				'product_id'         => 0,
				'variation_id'       => 0,
				'status'             => $status,
				'date_created_gmt'   => $dt_sql,
				'item_qty'           => 0,
				'item_subtotal'      => 0,
				'item_total'         => 0,
				'billing_first_name' => $billing_first ?: NULL,
				'billing_last_name'  => $billing_last ?: NULL,
				'billing_phone'      => $billing_phone ?: NULL,
				'billing_email'      => $billing_email ?: NULL,
				'billing_state'      => $billing_state ?: NULL,
				'billing_city'       => $billing_city ?: NULL,
				'billing_address_1'  => $billing_address_1 ?: NULL,
				'marketer_id'        => $marketer_id,
				'utm_source'         => $utm_source ?: NULL,
				'utm_medium'         => $utm_medium ?: NULL,
				'utm_campaign'       => $utm_campaign ?: NULL,
				'utm_term'           => $utm_term ?: NULL,
				'utm_content'        => $utm_content ?: NULL,
				'total'              => $total,
				'currency'           => $currency ?: NULL,
			];
		}
		
		foreach ( $rows as $row ) {
			$this->db->insert( $this->order_index_table, $row );
		}
	}
	
	public function delete_order_by_id( int $order_id ): void {
		if ( $order_id <= 0 ) {
			return;
		}
		$this->db->delete( $this->order_index_table, [ 'order_id' => $order_id ] );
	}
	
	public function reindex_all(): void {
		$page       = $_POST['page_number'] ?: 1;
		$batch_size = 200;
		$q          = wc_get_orders( [
			'type'     => 'shop_order',
			'limit'    => $batch_size,
			'paginate' => TRUE,
			'page'     => $page,
			'return'   => 'ids',
			'orderby'  => 'date',
			'order'    => 'ASC',
		] );
		
		$ids   = $q->orders ?? [];
		$total = (int) ( $q->total ?? 0 );
		$pages = (int) ceil( $total / $batch_size );
		
		if ( empty( $ids ) ) {
			wp_send_json( [
				'status'    => 'finished',
				'page'      => $page,
				'pages'     => $pages,
				'processed' => 0,
				'progress'  => ( $pages > 0 ) ? min( 100, round( ( $page - 1 ) / $pages * 100 ) ) : 100,
			] );
		}
		
		foreach ( $ids as $oid ) {
			$this->upsert_order_by_id( (int) $oid );
		}
		wp_send_json( [
			'status'    => ( $page >= $pages ) ? 'finished' : 'continue',
			'page'      => $page,
			'pages'     => $pages,
			'processed' => count( (array) $ids ),
			'progress'  => ( $pages > 0 ) ? min( 100, round( $page / $pages * 100 ) ) : 100,
			'next_page' => $page + 1,
		] );
	}
	
	public function get_indexed_marketers( array $args = [] ): array {
		$defaults = [
			'status' => '',
			'date'   => [
				'from' => '',
				'to'   => '',
			],
		];
		
		$args = wp_parse_args( $args, $defaults );
		
		$where  = [
			'marketer_id > 0',
		];
		$params = [];
		
		// وضعیت سفارش
		$status = isset( $args['status'] ) ? trim( (string) $args['status'] ) : '';
		
		if ( $status !== '' && strtolower( $status ) !== 'all' ) {
			$status   = 'wc-' . ltrim( str_replace( 'wc-', '', $status ), '-' );
			$where[]  = 'status = %s';
			$params[] = $status;
		}
		
		// تاریخ
		$date_from = $args['date']['from'] ?? '';
		$date_to   = $args['date']['to'] ?? '';
		
		[ $from_gmt, $to_gmt ] = $this->normalize_dates_to_gmt(
			(string) $date_from,
			(string) $date_to
		);
		
		if ( $from_gmt ) {
			$where[]  = 'date_created_gmt >= %s';
			$params[] = $from_gmt;
		}
		
		if ( $to_gmt ) {
			$where[]  = 'date_created_gmt <= %s';
			$params[] = $to_gmt;
		}
		
		$where_sql = 'WHERE ' . implode( ' AND ', $where );
		
		$sql = "
		SELECT
			marketer_id,
			COUNT(DISTINCT order_id) as order_count,
			MAX(date_created_gmt) as last_order_gmt
		FROM {$this->order_index_table}
		{$where_sql}
		GROUP BY marketer_id
		ORDER BY order_count DESC, marketer_id ASC
	";
		
		if ( ! empty( $params ) ) {
			$sql = $this->db->prepare( $sql, ...$params );
		}
		
		$items = [];
		
		foreach ( (array) $this->db->get_results( $sql ) as $row ) {
			$marketer_id = absint( $row->marketer_id );
			
			if ( ! $marketer_id ) {
				continue;
			}
			
			$items[ $marketer_id ] = [
				'id'             => $marketer_id,
				'label'          => get_user_name_by_id( $marketer_id ),
				'order_count'    => (int) $row->order_count,
				'last_order_gmt' => $row->last_order_gmt,
			];
		}
		
		return $items;
	}
	
	public function get_indexed_products( array $args = [] ): array {
		$defaults = [
			'status' => '',
			'date'   => [
				'from' => '',
				'to'   => '',
			],
			'limit'  => 0,
			'search' => '',
		];
		
		$args = wp_parse_args( $args, $defaults );
		
		$where  = [
			'oi.product_id > 0',
		];
		$params = [];
		
		// وضعیت سفارش
		$status = isset( $args['status'] ) ? trim( (string) $args['status'] ) : '';
		
		if ( $status !== '' && strtolower( $status ) !== 'all' ) {
			$status   = 'wc-' . ltrim( str_replace( 'wc-', '', $status ), '-' );
			$where[]  = 'oi.status = %s';
			$params[] = $status;
		}
		
		// تاریخ
		$date_from = $args['date']['from'] ?? '';
		$date_to   = $args['date']['to'] ?? '';
		
		[ $from_gmt, $to_gmt ] = $this->normalize_dates_to_gmt(
			(string) $date_from,
			(string) $date_to
		);
		
		if ( $from_gmt ) {
			$where[]  = 'oi.date_created_gmt >= %s';
			$params[] = $from_gmt;
		}
		
		if ( $to_gmt ) {
			$where[]  = 'oi.date_created_gmt <= %s';
			$params[] = $to_gmt;
		}
		
		// جستجوی عنوان محصول
		$search = isset( $args['search'] ) ? trim( (string) $args['search'] ) : '';
		
		if ( $search !== '' ) {
			$like     = '%' . $this->db->esc_like( $search ) . '%';
			$where[]  = 'p.post_title LIKE %s';
			$params[] = $like;
		}
		
		$where_sql = 'WHERE ' . implode( ' AND ', $where );
		
		$limit_sql = '';
		$limit     = absint( $args['limit'] ?? 0 );
		
		if ( $limit > 0 ) {
			$limit_sql = $this->db->prepare( 'LIMIT %d', $limit );
		}
		
		$posts_table = $this->db->posts;
		
		$sql = "
		SELECT
			CASE
				WHEN oi.variation_id > 0 THEN oi.variation_id
				ELSE oi.product_id
			END AS indexed_product_id,
			oi.product_id,
			oi.variation_id,
			p.post_title AS product_title,
			COUNT(DISTINCT oi.order_id) AS order_count,
			SUM(oi.item_qty) AS sold_qty,
			SUM(oi.item_total) AS total,
			MAX(oi.date_created_gmt) AS last_order_gmt
		FROM {$this->order_index_table} oi
		LEFT JOIN {$posts_table} p ON p.ID = (
			CASE
				WHEN oi.variation_id > 0 THEN oi.variation_id
				ELSE oi.product_id
			END
		)
		{$where_sql}
		GROUP BY indexed_product_id, oi.product_id, oi.variation_id, p.post_title
		ORDER BY order_count DESC, total DESC
		{$limit_sql}
	";
		
		if ( ! empty( $params ) ) {
			$sql = $this->db->prepare( $sql, ...$params );
		}
		
		$items = [];
		
		foreach ( (array) $this->db->get_results( $sql ) as $row ) {
			$indexed_product_id = absint( $row->indexed_product_id );
			
			if ( ! $indexed_product_id ) {
				continue;
			}
			
			$title = $row->product_title ?: sprintf( 'محصول #%d', $indexed_product_id );
			
			$items[ $indexed_product_id ] = [
				'id'             => $indexed_product_id,
				'product_id'     => absint( $row->product_id ),
				'variation_id'   => absint( $row->variation_id ),
				'label'          => $title,
				'order_count'    => (int) $row->order_count,
				'sold_qty'       => (float) $row->sold_qty,
				'total'          => (float) $row->total,
				'last_order_gmt' => $row->last_order_gmt,
			];
		}
		
		return $items;
	}
	
	/**
	 * جست‌وجوی سفارش‌ها از جدول ایندکس
	 *
	 * @param   array   $args         {
	 *                                آرگومان‌های جست‌وجوی سفارش.
	 *
	 * @type int        $per_page     تعداد آیتم در هر صفحه. پیش‌فرض 20.
	 * @type int        $page_number  شماره صفحه، 1-based. پیش‌فرض 1.
	 * @type string     $status       وضعیت سفارش. مثل `wc-processing` یا `processing`. مقدار `all` یعنی همه.
	 * @type array      $statuses     آرایه وضعیت‌ها. مثل ['wc-processing', 'completed'].
	 * @type array      $date         بازه تاریخ محلی.
	 * @type string     $date         ['from'] تاریخ شروع با فرمت `Y-m-d` یا تاریخ جلالی قابل تبدیل.
	 * @type string     $date         ['to']   تاریخ پایان با فرمت `Y-m-d` یا تاریخ جلالی قابل تبدیل.
	 * @type string     $search       جست‌وجوی چندکلمه‌ای روی نام، نام خانوادگی، موبایل، ایمیل، استان، شهر و آدرس.
	 * @type string     $state        کد/نام استان billing برای فیلتر دقیق. مقدار خالی یا `0` نادیده گرفته می‌شود.
	 * @type string     $city         کد/نام شهر billing برای فیلتر دقیق. مقدار خالی یا `0` نادیده گرفته می‌شود.
	 * @type int        $marketer_id  شناسه بازاریاب.
	 * @type int        $product_id   فیلتر روی product_id یا variation_id.
	 * @type int        $variation_id فیلتر دقیق روی variation_id.
	 * @type int[]      $product_ids  آرایه شناسه محصولات/ورییشن‌ها، حداکثر 500 مورد برای IN.
	 * @type array      $utm          فیلترهای UTM.
	 * @type string     $utm          ['source']   فیلتر source.
	 * @type string     $utm          ['medium']   فیلتر medium.
	 * @type string     $utm          ['campaign'] فیلتر campaign.
	 * @type string     $utm          ['term']     فیلتر term.
	 * @type string     $utm          ['content']  فیلتر content.
	 * @type float|null $min_total    حداقل مبلغ سفارش.
	 * @type float|null $max_total    حداکثر مبلغ سفارش.
	 * @type string     $order_by     ستون مرتب‌سازی: `date` یا `total`. پیش‌فرض `date`.
	 * @type string     $order        جهت مرتب‌سازی: `DESC` یا `ASC`. پیش‌فرض `DESC`.
	 * @type int        $order_id     اگر ست شود، مستقیماً همان سفارش بررسی و بازگردانی می‌شود.
	 * }
	 *
	 * @return array {
	 *     نتیجه جست‌وجو.
	 *
	 * @type int[]      $result       شناسه سفارش‌ها.
	 * @type array      $pagination   {
	 *         اطلاعات صفحه‌بندی.
	 *
	 * @type int        $total        تعداد کل سفارش‌های مطابق فیلتر.
	 * @type int        $per_page     تعداد آیتم در هر صفحه.
	 * @type int        $current_page شماره صفحه فعلی.
	 * @type int        $total_pages  تعداد کل صفحات.
	 * @type bool       $has_prev     آیا صفحه قبل وجود دارد؟
	 * @type bool       $has_next     آیا صفحه بعد وجود دارد؟
	 * @type int|null   $prev_page    شماره صفحه قبل یا null.
	 * @type int|null   $next_page    شماره صفحه بعد یا null.
	 * @type int        $from         شماره اولین آیتم نمایشی در این صفحه.
	 * @type int        $to           شماره آخرین آیتم نمایشی در این صفحه.
	 *     }
	 * }
	 */
	public function find_orders( array $args = [] ): array {
		$defaults = [
			'per_page'     => 20,
			'page_number'  => 1,
			'status'       => '',
			'date'         => [
				'from' => '',
				'to'   => '',
			],
			'search'       => '',
			'city'         => '',
			'state'        => '',
			'marketer_id'  => 0,
			'product_id'   => 0,
			'variation_id' => 0,
			'product_ids'  => [],
			'utm'          => [],
			'min_total'    => NULL,
			'max_total'    => NULL,
			'order_by'     => 'date', // date|total
			'order'        => 'DESC',
			'order_id'     => 0,
		];
		$args     = wp_parse_args( $args, $defaults );
		$per_page = max( 1, (int) $args['per_page'] );
		$page     = max( 1, (int) $args['page_number'] );
		$orderDir = strtoupper( (string) $args['order'] ) === 'ASC' ? 'ASC' : 'DESC';
		
		$make_pagination = static function( int $total, int $per_page, int $page ): array {
			$total_pages = $total > 0 ? (int) ceil( $total / $per_page ) : 0;
			
			return [
				'total'        => $total,
				'per_page'     => $per_page,
				'current_page' => $page,
				'total_pages'  => $total_pages,
				'has_prev'     => $page > 1,
				'has_next'     => $total_pages > 0 && $page < $total_pages,
				'prev_page'    => $page > 1 ? $page - 1 : NULL,
				'next_page'    => $total_pages > 0 && $page < $total_pages ? $page + 1 : NULL,
				'from'         => $total > 0 ? ( ( $page - 1 ) * $per_page ) + 1 : 0,
				'to'           => $total > 0 ? min( $page * $per_page, $total ) : 0,
			];
		};
		
		$prepare_sql = function( string $sql, array $params = [] ): string {
			if ( empty( $params ) ) {
				return $sql;
			}
			
			return $this->db->prepare( $sql, ...$params );
		};
		
		// --- شورت‌کات: order_id
		$order_id_direct = absint( $args['order_id'] );
		
		if ( $order_id_direct > 0 ) {
			$sql = $this->db->prepare(
				"SELECT 1 FROM {$this->order_index_table} WHERE order_id = %d LIMIT 1",
				$order_id_direct
			);
			
			$exists = (int) $this->db->get_var( $sql );
			$total  = $exists ? 1 : 0;
			
			return [
				'result'     => $exists ? [ $order_id_direct ] : [],
				'pagination' => $make_pagination( $total, $per_page, $page ),
			];
		}
		
		$where  = [ '1=1' ];
		$params = [];
		
		// وضعیت
		$st = '';
		
		$statuses = [];
		
		if ( ! empty( $args['status'] ) ) {
			$statuses = is_array( $args['status'] )
				? $args['status']
				: [ $args['status'] ];
		} elseif ( ! empty( $args['statuses'] ) ) {
			$statuses = (array) $args['statuses'];
		}
		
		$statuses = array_values( array_unique( array_filter( array_map( static function( $status ) {
			$status = sanitize_text_field( wp_unslash( (string) $status ) );
			
			if ( $status === '' ) {
				return '';
			}
			
			return str_starts_with( $status, 'wc-' ) ? $status : 'wc-' . $status;
		}, $statuses ) ) ) );
		
		if ( count( $statuses ) === 1 ) {
			$where[]  = "status = %s";
			$params[] = $statuses[0];
		} elseif ( count( $statuses ) > 1 ) {
			$placeholders = implode( ', ', array_fill( 0, count( $statuses ), '%s' ) );
			
			$where[] = "status IN ({$placeholders})";
			$params  = array_merge( $params, $statuses );
		}
		
		// تاریخ
		$date_from = $args['date']['from'] ?? '';
		$date_to   = $args['date']['to'] ?? '';
		
		[ $from_gmt, $to_gmt ] = $this->normalize_dates_to_gmt(
			(string) $date_from,
			(string) $date_to
		);
		
		if ( $from_gmt ) {
			$where[]  = 'date_created_gmt >= %s';
			$params[] = $from_gmt;
		}
		
		if ( $to_gmt ) {
			$where[]  = 'date_created_gmt <= %s';
			$params[] = $to_gmt;
		}
		
		// مبلغ
		if ( $args['min_total'] !== NULL && $args['min_total'] !== '' ) {
			$where[]  = 'total >= %f';
			$params[] = (float) $args['min_total'];
		}
		
		if ( $args['max_total'] !== NULL && $args['max_total'] !== '' ) {
			$where[]  = 'total <= %f';
			$params[] = (float) $args['max_total'];
		}
		
		// marketer_id
		$marketer_id = absint( $args['marketer_id'] );
		
		if ( $marketer_id > 0 ) {
			$where[]  = 'marketer_id = %d';
			$params[] = $marketer_id;
		}
		
		// استان / شهر
		$state = isset( $args['state'] ) ? sanitize_text_field( (string) $args['state'] ) : '';
		$city  = isset( $args['city'] ) ? sanitize_text_field( (string) $args['city'] ) : '';
		
		if ( $state !== '' && $state !== '0' ) {
			$where[]  = 'billing_state = %s';
			$params[] = $state;
		}
		
		if ( $city !== '' && $city !== '0' ) {
			$where[]  = 'billing_city = %s';
			$params[] = $city;
		}
		
		// محصول / ورییشن
		$variation_id = absint( $args['variation_id'] );
		$product_id   = absint( $args['product_id'] );
		$product_ids  = array_values(
			array_unique(
				array_map( 'absint', (array) $args['product_ids'] )
			)
		);
		
		if ( $variation_id > 0 ) {
			$where[]  = 'variation_id = %d';
			$params[] = $variation_id;
		} elseif ( $product_id > 0 ) {
			$where[]  = '(product_id = %d OR variation_id = %d)';
			$params[] = $product_id;
			$params[] = $product_id;
		} elseif ( ! empty( $product_ids ) ) {
			$product_ids = array_slice( $product_ids, 0, 500 );
			$ph          = implode( ',', array_fill( 0, count( $product_ids ), '%d' ) );
			
			$where[] = "(product_id IN ($ph) OR variation_id IN ($ph))";
			
			array_push( $params, ...$product_ids, ...$product_ids );
		}
		
		// سرچ روی بیلینگ + آدرس
		$tokens = preg_split( '/\s+/', (string) $args['search'], - 1, PREG_SPLIT_NO_EMPTY );
		
		if ( ! empty( $tokens ) ) {
			$parts = [];
			
			foreach ( $tokens as $tok ) {
				$like = '%' . $this->db->esc_like( $tok ) . '%';
				
				$parts[] = "(
				billing_first_name LIKE %s
				OR billing_last_name LIKE %s
				OR billing_phone LIKE %s
				OR billing_email LIKE %s
				OR billing_state LIKE %s
				OR billing_city LIKE %s
				OR billing_address_1 LIKE %s
			)";
				
				array_push(
					$params,
					$like,
					$like,
					$like,
					$like,
					$like,
					$like,
					$like
				);
			}
			
			$where[] = '(' . implode( ' OR ', $parts ) . ')';
		}
		
		// UTM فیلترها
		$utm = is_array( $args['utm'] ) ? $args['utm'] : [];
		
		$map = [
			'source'   => 'utm_source',
			'medium'   => 'utm_medium',
			'campaign' => 'utm_campaign',
			'term'     => 'utm_term',
			'content'  => 'utm_content',
		];
		
		foreach ( $map as $k => $col ) {
			if ( isset( $utm[ $k ] ) && $utm[ $k ] !== '' ) {
				$like     = '%' . $this->db->esc_like( (string) $utm[ $k ] ) . '%';
				$where[]  = "$col LIKE %s";
				$params[] = $like;
			}
		}
		
		// مرتب‌سازی
		$order_by_col = ( $args['order_by'] === 'total' ) ? 'total' : 'date_created_gmt';
		$where_sql    = 'WHERE ' . implode( ' AND ', $where );
		
		$limit  = $per_page;
		$offset = ( $page - 1 ) * $per_page;
		
		// COUNT DISTINCT
		$sql_cnt = $prepare_sql(
			"SELECT COUNT(DISTINCT order_id)
		 FROM {$this->order_index_table}
		 $where_sql",
			$params
		);
		
		$total = (int) $this->db->get_var( $sql_cnt );
		
		if ( $total === 0 ) {
			return [
				'result'     => [],
				'pagination' => $make_pagination( 0, $per_page, $page ),
			];
		}
		
		// IDs paged
		$sql_ids   = $prepare_sql(
			"SELECT order_id
		 FROM {$this->order_index_table}
		 $where_sql
		 GROUP BY order_id
		 ORDER BY MAX({$order_by_col}) {$orderDir}
		 LIMIT %d OFFSET %d",
			array_merge( $params, [ $limit, $offset ] )
		);
		$order_ids = array_map(
			'absint',
			(array) $this->db->get_col( $sql_ids )
		);
		
		return [
			'result'     => $order_ids,
			'pagination' => $make_pagination( $total, $per_page, $page ),
		];
	}
	
	/**
	 * گزارش‌گیری از سفارش‌ها در بازه زمانی
	 *
	 * @param   string  $date_from  'Y-m-d'
	 * @param   string  $date_to    'Y-m-d'
	 *
	 * @return array {
	 *   marketers => [ marketer_id => ['count'=>int,'total'=>float] ]
	 *   products  => [ product_id  => ['count'=>int,'total'=>float] ]
	 *   utms      => [
	 *       'source'   => [ value => ['count'=>int,'total'=>float] ],
	 *       'medium'   => [ value => ['count'=>int,'total'=>float] ],
	 *       'campaign' => [ value => ['count'=>int,'total'=>float] ],
	 *       'term'     => [ value => ['count'=>int,'total'=>float] ],
	 *       'content'  => [ value => ['count'=>int,'total'=>float] ],
	 *   ]
	 * }
	 */
	public function get_orders_report( string $date_from = '', string $date_to = '' ): array {
		[ $from_gmt, $to_gmt ] = $this->normalize_dates_to_gmt( $date_from, $date_to );
		
		$where  = [
			'1=1',
			"status IN ('wc-completed', 'wc-delivered', 'wc-processing')",
		];
		$params = [];
		
		if ( $from_gmt ) {
			$where[]  = "date_created_gmt >= %s";
			$params[] = $from_gmt;
		}
		if ( $to_gmt ) {
			$where[]  = "date_created_gmt <= %s";
			$params[] = $to_gmt;
		}
		
		$where_sql = 'WHERE ' . implode( ' AND ', $where );
		
		// =========================
		// 1. marketers
		// =========================
		$sql       = $this->db->prepare(
			"SELECT marketer_id, COUNT(*) as cnt, SUM(order_total) as total
	 FROM (
		SELECT order_id, marketer_id, MAX(total) as order_total
		FROM {$this->order_index_table}
		$where_sql
		AND marketer_id > 0
		GROUP BY order_id, marketer_id
	 ) x
	 GROUP BY marketer_id",
			...$params
		);
		$marketers = [];
		foreach ( (array) $this->db->get_results( $sql ) as $row ) {
			$marketers[ (int) $row->marketer_id ] = [
				'count' => (int) $row->cnt,
				'total' => (float) $row->total,
			];
		}
		
		// =========================
		// 2. products
		// =========================
		$sql = $this->db->prepare(
			"SELECT product_id, variation_id,
	        SUM(item_qty) as cnt,
	        SUM(item_total) as total
	 FROM {$this->order_index_table}
	 $where_sql
	 AND product_id > 0
	 GROUP BY product_id, variation_id
	 ORDER BY total DESC
	 LIMIT 10",
			...$params
		);
		
		$products = [];
		
		foreach ( (array) $this->db->get_results( $sql ) as $row ) {
			$id = $row->variation_id > 0 ? (int) $row->variation_id : (int) $row->product_id;
			
			if ( ! isset( $products[ $id ] ) ) {
				$products[ $id ] = [
					'count' => 0,
					'total' => 0.0,
				];
			}
			
			$products[ $id ]['count'] += (float) $row->cnt;
			$products[ $id ]['total'] += (float) $row->total;
		}
		
		$sql = $this->db->prepare(
			"SELECT COUNT(*) as cnt, COALESCE(SUM(order_total), 0) as total
	 FROM (
		SELECT order_id, MAX(total) as order_total
		FROM {$this->order_index_table}
		$where_sql
		GROUP BY order_id
	 ) x",
			...$params
		);
		
		$summary_row = $this->db->get_row( $sql );
		
		$summary = [
			'count' => (int) $summary_row?->cnt,
			'total' => $summary_row ? (float) $summary_row->total : 0.0,
		];
		
		return [
			'summary'   => $summary,
			'marketers' => $marketers,
			'products'  => $products,
		];
	}
	
	/**
	 * تبدیل Y-m-d محلی به GMT برای ستون date_created_gmt
	 *
	 * @return array [$from_gmt, $to_gmt]
	 */
	private function normalize_dates_to_gmt( string $from, string $to ): array {
		// پشتیبانی از تاریخ جلالی اگر تابع کمکی‌ات هست و فرمت میلادی نبود
		if ( $from && function_exists( 'nooshika_jalali_to_gregorian' ) && ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $from ) ) {
			$from = nooshika_jalali_to_gregorian( $from );
		}
		if ( $to && function_exists( 'nooshika_jalali_to_gregorian' ) && ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $to ) ) {
			$to = nooshika_jalali_to_gregorian( $to );
		}
		
		$tz       = wp_timezone();
		$from_gmt = '';
		$to_gmt   = '';
		
		if ( $from ) {
			try {
				$d        = new DateTimeImmutable( $from . ' 00:00:00', $tz );
				$from_gmt = $d->setTimezone( new DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' );
			}
			catch ( \Exception $e ) {
			}
		}
		if ( $to ) {
			try {
				$d      = new DateTimeImmutable( $to . ' 23:59:59', $tz );
				$to_gmt = $d->setTimezone( new DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' );
			}
			catch ( \Exception $e ) {
			}
		}
		
		return [ $from_gmt, $to_gmt ];
	}
	
	public function get_successful_orders_last_7_days_chart_data(): array {
		$tz    = wp_timezone();
		$today = new DateTimeImmutable( current_time( 'Y-m-d' ), $tz );
		$start = $today->modify( '-6 days' );
		$end   = $today;
		
		$days = [];
		
		for ( $i = 0; $i < 7; $i ++ ) {
			$date = $start->modify( "+{$i} days" );
			
			$days[ $date->format( 'Y-m-d' ) ] = [
				'label' => wp_date( 'j M', $date->getTimestamp(), $tz ),
				'count' => 0,
				'total' => 0,
			];
		}
		
		[ $from_gmt, $to_gmt ] = $this->normalize_dates_to_gmt(
			$start->format( 'Y-m-d' ),
			$end->format( 'Y-m-d' )
		);
		
		$sql = $this->db->prepare(
			"SELECT
			order_id,
			MIN(date_created_gmt) as date_created_gmt,
			MAX(total) as total
		FROM {$this->order_index_table}
		WHERE status IN ('wc-completed', 'wc-delivered', 'wc-processing')
		AND date_created_gmt >= %s
		AND date_created_gmt <= %s
		GROUP BY order_id",
			$from_gmt,
			$to_gmt
		);
		
		foreach ( (array) $this->db->get_results( $sql ) as $row ) {
			try {
				$date_key = ( new DateTimeImmutable( $row->date_created_gmt, new DateTimeZone( 'UTC' ) ) )
					->setTimezone( $tz )
					->format( 'Y-m-d' );
			}
			catch ( Exception $e ) {
				continue;
			}
			
			if ( ! isset( $days[ $date_key ] ) ) {
				continue;
			}
			
			$days[ $date_key ]['count'] ++;
			$days[ $date_key ]['total'] += (float) $row->total;
		}
		
		return [
			'labels' => array_column( $days, 'label' ),
			'counts' => array_column( $days, 'count' ),
			'totals' => array_column( $days, 'total' ),
			'days'   => $days,
		];
	}
	
	public function get_users_last_7_days_chart_data( string $role = 'subscriber' ): array {
		$tz    = wp_timezone();
		$today = new DateTimeImmutable( current_time( 'Y-m-d' ), $tz );
		$start = $today->modify( '-6 days' );
		$end   = $today;
		
		$days = [];
		
		for ( $i = 0; $i < 7; $i ++ ) {
			$date = $start->modify( "+{$i} days" );
			
			$days[ $date->format( 'Y-m-d' ) ] = [
				'label' => wp_date( 'j M', $date->getTimestamp(), $tz ),
				'count' => 0,
			];
		}
		
		[ $from_gmt, $to_gmt ] = $this->normalize_dates_to_gmt(
			$start->format( 'Y-m-d' ),
			$end->format( 'Y-m-d' )
		);
		
		$users_table    = $this->db->users;
		$usermeta_table = $this->db->usermeta;
		
		if ( $role ) {
			$cap_key   = $this->db->prefix . 'capabilities';
			$role_like = '%"' . $this->db->esc_like( $role ) . '"%';
			
			$sql = $this->db->prepare(
				"SELECT
				u.ID,
				u.user_registered
			FROM {$users_table} u
			INNER JOIN {$usermeta_table} um ON um.user_id = u.ID
			WHERE u.user_registered >= %s
			AND u.user_registered <= %s
			AND um.meta_key = %s
			AND um.meta_value LIKE %s",
				$from_gmt,
				$to_gmt,
				$cap_key,
				$role_like
			);
		} else {
			$sql = $this->db->prepare(
				"SELECT
				ID,
				user_registered
			FROM {$users_table}
			WHERE user_registered >= %s
			AND user_registered <= %s",
				$from_gmt,
				$to_gmt
			);
		}
		
		foreach ( (array) $this->db->get_results( $sql ) as $row ) {
			try {
				$date_key = ( new DateTimeImmutable( $row->user_registered, new DateTimeZone( 'UTC' ) ) )
					->setTimezone( $tz )
					->format( 'Y-m-d' );
			}
			catch ( Exception $e ) {
				continue;
			}
			
			if ( ! isset( $days[ $date_key ] ) ) {
				continue;
			}
			
			$days[ $date_key ]['count'] ++;
		}
		
		return [
			'labels' => array_column( $days, 'label' ),
			'counts' => array_column( $days, 'count' ),
			'days'   => $days,
		];
	}
	
}
