<?php

class kcp_ajax {
	
	public array     $actions;
	public kcp_db    $kcp_db;
	public kcp_stock $kcp_stock;
	
	public function __construct() {
		$this->actions   = [
			'crm_submit_login_form'             => [ $this, 'submit_login_form', ],
			'crm_send_login_otp'                => [ $this, 'send_login_otp', ],
			'crm_submit_login_otp'              => [ $this, 'submit_login_otp', ],
			'crm_submit_change_password_form'   => [ $this, 'submit_change_password_form', ],
			'crm_reset_password'                => [ $this, 'reset_password', ],
			'crm_add_user'                      => [ $this, 'add_user', ],
			'crm_search_user'                   => [ $this, 'search_user', ],
			'crm_delete_user'                   => [ $this, 'delete_user', ],
			'crm_login_as_user'                 => [ $this, 'login_as_user', ],
			'crm_change_skin'                   => [ $this, 'change_skin', ],
			'crm_save_dark_mode'                => [ $this, 'save_dark_mode', ],
			'crm_request_page_content'          => [ $this, 'request_page_content', ],
			'crm_request_back_btn'              => [ $this, 'request_back_btn', ],
			'crm_add_employee'                  => [ $this, 'add_employee', ],
			'crm_update_user_role'              => [ $this, 'update_user_role', ],
			'crm_save_site_settings'            => [ $this, 'save_site_settings', ],
			'crm_handle_file_upload'            => [ $this, 'handle_file_upload', ],
			'crm_update_user_personal_data'     => [ $this, 'update_user_personal_data', ],
			'crm_search_user_for_modal'         => [ $this, 'search_user_list', ],
			'crm_search_product_for_modal'      => [ $this, 'search_product_for_modal', ],
			'crm_change_user_profile_image'     => [ $this, 'change_user_profile_image', ],
			'crm_add_user_activity'             => [ $this, 'add_user_activity', ],
			'crm_delete_action'                 => [ $this, 'delete_action', ],
			'crm_add_user_track'                => [ $this, 'add_user_track', ],
			'crm_check_user_track'              => [ $this, 'check_user_track', ],
			'crm_delete_track'                  => [ $this, 'delete_track', ],
			'crm_add_user_visit'                => [ $this, 'add_user_visit', ],
			'crm_change_visit_status'           => [ $this, 'change_visit_status', ],
			'crm_delete_visit'                  => [ $this, 'delete_visit', ],
			'crm_add_user_note'                 => [ $this, 'add_user_note', ],
			'crm_delete_user_note'              => [ $this, 'delete_user_note', ],
			'crm_add_user_call'                 => [ $this, 'add_user_call', ],
			'crm_add_hr_call'                   => [ $this, 'add_hr_call', ],
			'crm_add_call_progress'             => [ $this, 'add_call_progress', ],
			'crm_delete_call'                   => [ $this, 'delete_call', ],
			'crm_get_stock_log_steps'           => [ $this, 'get_stock_log_steps', ],
			'crm_get_call_progress'             => [ $this, 'get_call_progress', ],
			'crm_get_call_category_users'       => [ $this, 'get_call_category_users', ],
			'crm_search_product_sku'            => [ $this, 'search_product_sku', ],
			'crm_add_warning_template'          => [ $this, 'add_warning_template', ],
			'crm_send_warning_template'         => [ $this, 'send_warning_template' ],
			'crm_delete_warning_template'       => [ $this, 'delete_warning_template' ],
			'crm_add_employee_report'           => [ $this, 'add_employee_report' ],
			'crm_delete_employee_report'        => [ $this, 'delete_employee_report' ],
			'crm_search_sku_for_order'          => [ $this, 'search_sku_for_order' ],
			'crm_load_product_block'            => [ $this, 'load_product_block' ],
			'crm_load_user_address'             => [ $this, 'load_user_address' ],
			'crm_load_user_referral_block'      => [ $this, 'load_user_referral_block' ],
			'crm_set_referral_code_for_user'    => [ $this, 'set_referral_code_for_user' ],
			'crm_save_user_address'             => [ $this, 'save_user_address' ],
			'crm_delete_customer_address'       => [ $this, 'delete_customer_address' ],
			'crm_submit_new_order'              => [ $this, 'submit_new_order' ],
			'crm_change_order_status'           => [ $this, 'change_order_status' ],
			'crm_load_order_items_table'        => [ $this, 'load_order_items_table' ],
			'crm_load_order_cheque'             => [ $this, 'load_order_cheque' ],
			'crm_submit_new_cheque_for_order'   => [ $this, 'submit_new_cheque_for_order' ],
			'crm_submit_cash_payment_for_order' => [ $this, 'submit_cash_payment_for_order' ],
			'crm_delete_cheque_for_order'       => [ $this, 'delete_cheque_for_order' ],
			'crm_delete_cash_for_order'         => [ $this, 'delete_cash_for_order' ],
			'crm_load_order_cash_table'         => [ $this, 'load_order_cash_table' ],
			'crm_load_order_installments'       => [ $this, 'load_order_installments' ],
			'crm_submit_order_installment_data' => [ $this, 'submit_order_installment_data' ],
			'crm_delete_order_installment_data' => [ $this, 'delete_order_installment_data' ],
			'crm_add_product_to_store'          => [ $this, 'add_product_to_store' ],
			'crm_add_production_request_log'    => [ $this, 'add_production_request_log' ],
			'crm_stock_items_set_step'          => [ $this, 'stock_items_set_step' ],
			'crm_export_products'               => [ $this, 'export_products', ],
			'crm_import_qty'                    => [ $this, 'crm_import_qty' ],
			'crm_add_option_item'               => [ $this, 'add_option_item' ],
			'crm_delete_option_item'            => [ $this, 'delete_option_item' ],
			'crm_add_product'                   => [ $this, 'add_product' ],
			'crm_trash_product'                 => [ $this, 'trash_product' ],
			'crm_save_user_location'            => [ $this, 'save_user_location' ],
			'crm_delete_order'                  => [ $this, 'delete_order', ],
			'crm_change_users_marketer'         => [ $this, 'change_users_marketer', ],
            'crm_assign_customer_sales'         => [ $this, 'change_users_marketer', ],
		];
		$this->kcp_db    = new kcp_db();
		$this->kcp_stock = new kcp_stock();
		foreach ( $this->actions as $action => $callback ) {
			add_action( 'nooshika_ajax_' . $action, $callback );
		}
	}
	
	public function submit_login_form() {
		$ip_address    = $_SERVER['REMOTE_ADDR'];
		$transient_key = 'login_attempts_' . md5( $ip_address );
		$attempts      = (int) get_transient( $transient_key );
		
		if ( $attempts >= 5 ) {
			wp_send_json( [
				'status'  => 'error',
				'message' => 'دسترسی موقتاً مسدود شده است. لطفاً بعداً تلاش کنید.',
			] );
		}
		
		if ( empty( $_POST['username'] ) || empty( $_POST['password'] ) ) {
			wp_send_json( [
				'status'  => 'error',
				'message' => 'نام کاربری و رمز عبور الزامی است.',
			] );
		}
		
		$username = sanitize_user( $_POST['username'] );
		$password = $_POST['password'];
		
		$cred = [
			'user_login'    => $username,
			'user_password' => $password,
			'remember'      => TRUE,
		];
		
		$user = wp_signon( $cred, FALSE );
		
		if ( is_wp_error( $user ) ) {
			$attempts ++;
			set_transient( $transient_key, $attempts, MINUTE_IN_SECONDS * 10 );
			wp_send_json( [
				'status'  => 'error',
				'message' => 'نام کاربری یا رمز عبور اشتباه است.',
			] );
		}
		
		delete_transient( $transient_key );
		
		wp_send_json( [
			'status'  => 'success',
			'message' => 'با موفقیت وارد شدید.',
		] );
	}
	
	public function send_login_otp() {
		$phone = nooshika_sanitize_numbers( $_POST['phone'] );
		$phone = remove_zero_from_phone( $phone );
		
		if ( empty( $phone ) ) {
			wp_send_json( [
				'status'  => 'error',
				'message' => 'شماره موبایل نامعتبر است',
			] );
		}
		$otp_data = get_transient( 'nooshika_otp_' . $phone );
		
		if ( $otp_data && $otp_data['created'] + 20 > time() ) {
			wp_send_json( [
				'status'  => 'error',
				'message' => 'لطفا 20 ثانیه صبر کنید',
			] );
		}
		$otp_try_key = 'nooshika_otp_try_' . $phone;
		$otp_try     = get_transient( $otp_try_key );
		if ( $otp_try && $otp_try['count'] > 5 && $otp_try['first_try'] + 300 > time() ) {
			wp_send_json( [
				'status'  => 'error',
				'message' => 'تعداد درخواست‌های بیش از حد. ۵ دقیقه صبر کنید.',
			] );
		}
		if ( ! $otp_try ) {
			$otp_try = [
				'count'     => 1,
				'first_try' => time(),
			];
		} else {
			$otp_try['count'] ++;
		}
		set_transient( $otp_try_key, $otp_try, 600 ); // 10 دقیقه اعتبار
		
		$otp = str_pad( rand( 100, 9999 ), 4, "0", STR_PAD_LEFT );
		
		$user_id = get_user_id_by_phone( $phone );
		set_transient( 'nooshika_otp_' . $phone, [
			'otp'     => $otp,
			'created' => time(),
			'user_id' => $user_id,
		], 180 ); // 3 دقیقه اعتبار
		
		( new kasebiSMS() )->send_otp_sms( $phone, $otp );
		
		wp_send_json( [
			'status'  => 'success',
			'message' => 'کد تایید به شماره موبایل شما ارسال شد',
		] );
	}
	
	public function submit_login_otp() {
		$otp   = nooshika_sanitize_numbers( $_POST['otp'] );
		$phone = nooshika_sanitize_numbers( $_POST['phone'] );
		$phone = remove_zero_from_phone( $phone );
		
		if ( empty( $phone ) || empty( $otp ) ) {
			wp_send_json( [
				'status'  => 'error',
				'message' => 'شماره یا کد تایید نامعتبر است',
			] );
		}
		
		$data = get_transient( 'nooshika_otp_' . $phone );
		if ( ! $data ) {
			wp_send_json( [
				'status'  => 'error',
				'message' => 'کد تایید منقضی شده است. لطفا مجدد درخواست دهید.',
			] );
		}
		if ( $data['created'] + 180 < time() ) {
			delete_transient( 'nooshika_otp_' . $phone );
			wp_send_json( [
				'status'  => 'error',
				'message' => 'کد تایید منقضی شده است.',
			] );
		}
		$wrong_key = 'nooshika_otp_wrong_' . $phone;
		$wrong     = get_transient( $wrong_key );
		if ( $wrong && $wrong['count'] > 5 && $wrong['first_try'] + 300 > time() ) {
			wp_send_json( [
				'status'  => 'error',
				'message' => 'تعداد تلاش‌های ناموفق زیاد بوده است. لطفا ۵ دقیقه صبر کنید.',
			] );
		}
		if ( $data['otp'] !== $otp ) {
			if ( ! $wrong ) {
				$wrong = [
					'count'     => 1,
					'first_try' => time(),
				];
			} else {
				$wrong['count'] ++;
			}
			set_transient( $wrong_key, $wrong, 600 );
			
			wp_send_json( [
				'status'  => 'error',
				'message' => 'کد تایید اشتباه است.',
			] );
		}
		
		delete_transient( 'nooshika_otp_' . $phone );
		delete_transient( $wrong_key );
		
		$user_id = $data['user_id'];
		if ( ! $user_id ) {
			$new_user = [
				'user_pass'     => wp_generate_password( 12, FALSE ),
				'user_login'    => $phone,
				'user_nicename' => $phone,
				'display_name'  => $phone,
			];
			$user_id  = wp_insert_user( $new_user );
			update_user_meta( $user_id, 'nooshika_phone_num', $phone );
		}
		
		wp_clear_auth_cookie();
		wp_set_current_user( $user_id );
		wp_set_auth_cookie( $user_id, TRUE );
		
		wp_send_json( [
			'status'  => 'success',
			'message' => 'کد تایید صحیح است.',
			'user_id' => $user_id,
		] );
	}
	
	public function submit_change_password_form() {
		extract( $_POST );
		$user_id = get_current_user_id();
		$user    = get_user_by( 'id', $user_id );
		if ( $user && wp_check_password( $old_pass, $user->data->user_pass, $user->ID ) ) {
			wp_set_password( $new_pass, $user_id );
			$return['status'] = 'success';
			$return['msg']    = 'رمز عبور با موفقیت تغییر کرد';
			wp_logout();
		} else {
			$return['status'] = 'failed';
			$return['msg']    = 'رمز عبور قبلی اشتباه است';
		}
		wp_send_json( $return );
	}
	
	public function reset_password() {
		$user_id      = $_POST['user_id'];
		$new_password = wp_generate_password( 12, 0 );
		wp_set_password( $new_password, $user_id );
		$return = [
			'html' => "<p>رمز جدید: $new_password</p><p>پسورد جدید را حتما ذخیره بفرمایید.</p>",
		];
		wp_send_json( $return );
	}
	
	public function add_user() {
		extract( $_POST );
		$phone   = nooshika_sanitize_numbers( $phone );
		$phone   = remove_zero_from_phone( $phone );
		$user_id = get_user_id_by_phone( $phone );
		$is_old  = FALSE;
		if ( ! $user_id ) {
			$new_user = [
				'user_pass'    => wp_generate_password( 12, 0 ),
				'user_login'   => $phone,
				'first_name'   => $first_name,
				'last_name'    => $last_name,
				'display_name' => $first_name . ' ' . $last_name,
				'meta_input'   => [
					'nooshika_phone_num'    => $phone,
					'creator_id'            => get_current_user_id(),
					'ncp_user_intro_method' => $_POST['intro'],
					'kcp_user_groups'       => $_POST['groups'],
					'kcp_user_types'        => $_POST['types'],
					'shop_name'             => $_POST['shop'],
				],
			];
			$new_user['meta_input'] = array_merge( $new_user['meta_input'], kcp_new_customer_sales_meta() );
            $user_id  = wp_insert_user( $new_user );
		} else {
			$is_old = TRUE;
		}
		$page = 'crm/user';
		$url  = home_url( 'crm/user/' . $user_id );
		if ( is_wp_error( $user_id ) ) {
			$status = 'error';
			$msg    = $user_id->get_error_message();
			$page   = 'crm/users';
			$url    = home_url( 'crm/users' );
		} else {
			$status = 'success';
			$msg    = $is_old ? 'شماره موبایل پیشتر در سایت وجود دارد.' : 'مشتری با موفقیت ایجاد شد.';
		}
		$target = $_POST['target'] ?? '';
		if ( $target == 'modal' ) {
			$html   = crm_get_template( 'partials/user-card.php', [
				'user_id'    => $user_id,
				'show_phone' => TRUE,
			] );
			$return = [
				'user_id' => $user_id,
				'html'    => $html,
				'status'  => $status,
				'message' => $msg,
			];
			wp_send_json( $return );
		}
		
		$_REQUEST['id'] = $user_id;
		$return         = [
			'main'    => crm_get_template( 'layout/main.php', [ 'page' => $page ] ),
			'url'     => $url,
			'status'  => $status,
			'message' => $msg,
		];
		wp_send_json( $return );
	}
	
	public function search_user() {
		$search = $_POST['search'];
		$args   = [
			'users' => kcp_get_user_list( $search )['users'],
		];
		$result = [
			'searchResult' => crm_get_template( "misc/search_result.php", $args ),
		];
		wp_send_json( $result );
	}
	
	public function delete_user() {
		$user_id = $_POST['user_id'];
		require_once( ABSPATH . 'wp-admin/includes/user.php' );
		$status = wp_delete_user( $user_id );
		$return = [
			'main'    => crm_get_template( 'layout/main.php', [ 'page' => $_POST['page'] ?? 'crm/users', ] ),
			'status'  => $status ? 'success' : 'error',
			'message' => $status ? 'حذف مشتری با موفقیت انجام شد' : 'حذف مشتری با خطا روبرو شد',
		];
		wp_send_json( $return );
	}
	
	public function login_as_user() {
		$user_id    = $_POST['user_id'];
		$current_id = get_current_user_id();
		if ( ! current_user_can( 'manage_options' ) ) {
			setcookie( 'ksm_admin_user_id', $current_id, time() + 7200, '/' );
		} else {
			setcookie( 'ksm_admin_user_id', '', 1 );
		}
		wp_clear_auth_cookie();
		wp_set_current_user( $user_id );
		wp_set_auth_cookie( $user_id, TRUE );
		wp_send_json( [
			'status' => 'success',
			'url'    => home_url( '/crm' ),
		] );
	}
	
	public function change_skin() {
		$skin = $_POST['skin'];
		update_user_meta( get_current_user_id(), 'crm_skin', $skin );
		wp_send_json( [ 'status' => 'success' ] );
	}
	
	public function save_dark_mode() {
		$is_active = $_POST['is_active'];
		update_user_meta( get_current_user_id(), 'crm_dark_mode', $is_active );
		wp_send_json( [ 'status' => 'success' ] );
	}
	
	public function request_page_content() {
		$page = $_POST['page'];
		unset( $_POST['page'] );
		unset( $_POST['action'] );
		$_POST     = array_filter( $_POST );
		$query     = http_build_query( $_POST );
		$query     = urldecode( $query );
		$parts     = get_crm_end_point( $page );
		$sub_pages = get_crm_single_page_list();
		if ( isset( $sub_pages[ $parts[0] ] ) ) {
			$_REQUEST['id'] = $parts[1];
		}
		$url    = $query ? home_url( $page . '?' . $query ) : home_url( $page );
		$return = [
			'url'   => $url,
			'main'  => crm_get_template( 'layout/main.php', [ 'page' => $page ] ),
			'title' => get_crm_page_title( $parts[0] ),
		];
		wp_send_json( $return );
	}
	
	public function request_back_btn() {
		$path      = $_POST['path'];
		$query     = explode( '?', $path );
		$path      = kcp_sanitize_url_for_template_path( $query[0] );
		$parts     = get_crm_end_point( $path );
		$sub_pages = get_crm_single_page_list();
		if ( isset( $sub_pages[ $parts[0] ] ) ) {
			$_REQUEST['id'] = $parts[1];
		}
		$query = $query[1] ?? '';
		$query = explode( '&', $query );
		foreach ( $query as $value ) {
			$value                 = explode( '=', $value );
			$_REQUEST[ $value[0] ] = $value[1];
		}
		$return = [
			'main' => crm_get_template( 'layout/main.php', [ 'page' => $path ] ),
		];
		wp_send_json( $return );
	}
	
	public function add_employee() {
		$first_name = $_POST['first_name'];
		$last_name  = $_POST['last_name'];
		$username   = $_POST['username'];
		$new_user   = [
			'user_pass'    => '123456',
			'user_login'   => $username,
			'first_name'   => $first_name,
			'last_name'    => $last_name,
			'display_name' => $first_name . ' ' . $last_name,
		];
		$user_id    = wp_insert_user( $new_user );
		if ( ! is_wp_error( $user_id ) ) {
			$user = new WP_User( $user_id );
			$user->set_role( $_POST['role'] );
			$phone = nooshika_sanitize_numbers( remove_zero_from_phone( $_POST['phone'] ) );
			update_user_meta( $user_id, 'marketer_phone_num', $phone );
			update_user_meta( $user_id, 'nooshika_phone_num', $phone );
			
			$return = [
				'msg'  => 'کارمند با موفقیت ایجاد شد.',
				'main' => crm_get_template( 'layout/main.php', [ 'page' => 'crm/hr-employees' ] ),
			];
			wp_send_json( $return );
		}
		$return['result'] = 'error';
		$return['msg']    = $user_id->get_error_message();
		wp_send_json( $return );
	}
	
	public function update_user_role() {
		$user_id = $_POST['user_id'];
		$user    = new WP_User( $user_id );
		$user->set_role( $_POST['role'] );
		$return = [
			'msg'  => 'کارمند با موفقیت به روز رسانی شد.',
			'main' => crm_get_template( 'layout/main.php', [ 'page' => 'crm/hr-employees' ] ),
		];
		wp_send_json( $return );
	}
	
	public function save_site_settings() {
		$options = $_POST['options'];
		foreach ( $options as $key => $option ) {
			update_option( $key, $option );
		}
		$return = [
			'main'    => crm_get_template( 'layout/main.php', [ 'page' => 'crm/settings' ] ),
			'message' => 'اطلاعات با موفقیت ذخیره شد.',
			'status'  => 'success',
		];
		wp_send_json( $return );
	}
	
	public function handle_file_upload() {
		$attachment = $_FILES['file'];
		$attachment = crm_handle_upload_file( $attachment, 'crm-files' );
		$return     = [
			'attachment' => $attachment,
			'status'     => 'success',
			'message'    => 'فایل با موفقیت آپلود شد.',
		];
		wp_send_json( $return );
	}
	
	public function update_user_personal_data() {
		$user_id    = $_POST['id'];
		$meta       = $_POST['meta'];
		$taxonomies = [
			'kcp_user_groups' => 'دسته بندی مشتری',
			'kcp_user_types'  => 'تگ مشتری',
		];
		foreach ( $meta as $meta_key => $meta_value ) {
            if ( in_array( $meta_key, [ 'creator_id', 'crm_assignment_history', 'user_marketer_id', 'crm_phone_sales_agent_id', 'crm_phone_sales_assignment_history' ], TRUE ) ) {
                continue;
            }
			if ( str_starts_with( $meta_key, 'taxonomy_' ) ) {
				$taxonomy = substr( $meta_key, strlen( 'taxonomy_' ) );
				$terms    = (array) $meta_value;
				$terms    = array_map( 'intval', $terms );
				$terms    = array_filter( $terms );
				$terms    = array_unique( $terms );
				
				wp_set_object_terms( $user_id, $terms, $taxonomy, FALSE );
				continue;
			}
			
			if ( $meta_key === 'birth_date' && $meta_value !== '' ) {
				$meta_value = nooshika_jalali_to_gregorian( $meta_value );
			}
			update_user_meta( $user_id, $meta_key, $meta_value );
		}
		foreach ( $taxonomies as $slug => $label ) {
			if ( ! isset( $meta[ $slug ] ) ) {
				delete_user_meta( $user_id, $slug );
			}
		}
		$return = [
			'main'    => crm_get_template( 'layout/main.php', [ 'page' => $_POST['page'] ] ),
			'message' => 'اطلاعات با موفقیت به روز رسانی شد',
			'status'  => 'info',
		];
		wp_send_json( $return );
	}
	
	public function search_user_list() {
		$search = $_POST['search'];
		$args   = [
			'users' => kcp_get_user_list( $search )['users'],
		];
		$result = [
			'searchResult' => crm_get_template( "misc/search_user_for_modal.php", $args ),
		];
		wp_send_json( $result );
	}
	
	public function search_product_for_modal() {
		global $wpdb;
		
		$search_raw = $_POST['search'] ?? '';
		$search     = sanitize_text_field( wp_unslash( $search_raw ) );
		
		$product_ids = [];
		
		if ( $search !== '' ) {
			$like = '%' . $wpdb->esc_like( $search ) . '%';
			
			// --- SKU exact + partial ---
			$sku_ids = $wpdb->get_col(
				$wpdb->prepare(
					"SELECT p.ID
				   FROM {$wpdb->posts} p
				   JOIN {$wpdb->postmeta} m
				     ON m.post_id = p.ID AND m.meta_key = '_sku'
				  WHERE p.post_status = 'publish'
				    AND p.post_type IN ('product','product_variation')
				    AND ( m.meta_value = %s OR m.meta_value LIKE %s )
				  LIMIT 100",
					$search,
					$like
				)
			);
			
			// --- Title match: simple products ---
			$simple_title_ids = $wpdb->get_col(
				$wpdb->prepare(
					"SELECT p.ID
				   FROM {$wpdb->posts} p
				  WHERE p.post_status = 'publish'
				    AND p.post_type   = 'product'
				    AND p.post_title  LIKE %s
				  LIMIT 100",
					$like
				)
			);
			
			// --- Title match: children variations of variable products ---
			$child_var_ids = $wpdb->get_col(
				$wpdb->prepare(
					"SELECT c.ID
				   FROM {$wpdb->posts} p
				   JOIN {$wpdb->posts} c
				     ON c.post_parent = p.ID
				    AND c.post_type   = 'product_variation'
				    AND c.post_status = 'publish'
				  WHERE p.post_status = 'publish'
				    AND p.post_type   = 'product'
				    AND p.post_title  LIKE %s
				  LIMIT 200",
					$like
				)
			);
			
			$title_ids = array_merge( (array) $simple_title_ids, (array) $child_var_ids );
			
			$product_ids = array_merge( (array) $sku_ids, (array) $title_ids );
		}
		
		// Deduplicate
		$product_ids = array_values( array_unique( array_map( 'intval', $product_ids ) ) );
		
		// حذف خود variable ها (فقط simple و variation بماند)
		$filtered = [];
		foreach ( $product_ids as $pid ) {
			$p = wc_get_product( $pid );
			if ( ! $p ) {
				continue;
			}
			if ( $p->is_type( 'variable' ) ) {
				continue; // حذف والد متغیر
			}
			if ( $p->is_type( 'simple' ) || $p->is_type( 'variation' ) ) {
				$filtered[] = $pid;
			}
		}
		
		// محدودیت خروجی
		$filtered = array_slice( $filtered, 0, 50 );
		
		$args   = [
			'product_ids' => $filtered,
			'search'      => $search,
		];
		$result = [
			'searchResult' => crm_get_template( 'misc/search_product_for_modal.php', $args ),
		];
		
		wp_send_json( $result );
	}
	
	public function change_user_profile_image() {
		$image = $_POST['image'];
		update_user_meta( $_POST['id'], 'nooshika_user_avatar_url', $image );
		$page   = 'crm/user';
		$return = [
			'main'    => crm_get_template( 'layout/main.php', [ 'page' => $page ] ),
			'message' => 'تصویر با موفقیت تنظیم شد',
			'status'  => 'success',
		];
		wp_send_json( $return );
	}
	
	public function add_user_activity() {
		$data   = [
			'user_id'    => $_POST['id'],
			'item_id'    => $_POST['item_id'],
			'title'      => $_POST['title'],
			'content'    => $_POST['content'],
			'type'       => $_POST['type'],
			'attachment' => $_POST['file'],
		];
		$result = $this->kcp_db->add_user_action( $data );
		$return = [
			'main'    => crm_get_template( 'layout/main.php', [ 'page' => 'crm/user' ] ),
			'status'  => $result['status'],
			'message' => $result['msg'],
		];
		wp_send_json( $return );
	}
	
	public function delete_action() {
		$result = $this->kcp_db->delete_user_action( $_POST['item_id'] );
		$return = [
			'main'    => crm_get_template( 'layout/main.php', [ 'page' => $_POST['page'] ] ),
			'status'  => $result['status'],
			'message' => $result['msg'],
		];
		wp_send_json( $return );
	}
	
	public function add_user_track() {
		$data   = [
			'user_id'    => $_POST['id'],
			'title'      => $_POST['title'],
			'content'    => $_POST['content'],
			'type'       => $_POST['type'],
			'track_date' => nooshika_jalali_to_gregorian( $_POST['date'] ),
			'track_hour' => $_POST['hour'],
		];
		$result = $this->kcp_db->add_user_track( $data );
		$return = [
			'main'    => crm_get_template( 'layout/main.php', [ 'page' => 'crm/user' ] ),
			'status'  => $result['status'],
			'message' => $result['msg'],
		];
		wp_send_json( $return );
	}
	
	public function check_user_track() {
		$item_id = $_POST['item_id'];
		$status  = $_POST['status'];
		$result  = $_POST['result'];
		$result  = $this->kcp_db->check_user_track( $item_id, $status, $result );
		$return  = [
			'main'    => crm_get_template( 'layout/main.php', [ 'page' => $_POST['page'] ] ),
			'status'  => $result['status'],
			'message' => $result['msg'],
		];
		wp_send_json( $return );
	}
	
	public function delete_track() {
		$result = $this->kcp_db->delete_user_track( $_POST['item_id'] );
		$return = [
			'main'    => crm_get_template( 'layout/main.php', [ 'page' => $_POST['page'] ] ),
			'status'  => $result['status'],
			'message' => $result['msg'],
		];
		wp_send_json( $return );
	}
	
	public function add_user_visit() {
		$data   = [
			'user_id' => $_POST['user_id'],
		];
		$result = $this->kcp_db->add_visit( $data );
		$return = [
			'main'    => crm_get_template( 'layout/main.php', [ 'page' => 'crm/users-visit' ] ),
			'status'  => $result['status'],
			'message' => $result['msg'],
		];
		wp_send_json( $return );
	}
	
	public function change_visit_status() {
		$data   = [
			'user_id'  => $_POST['id'],
			'details'  => $_POST['desc'],
			'visit_id' => $_POST['item_id'],
			'status'   => $_POST['change_status'],
		];
		$result = $this->kcp_db->change_visit_status( $data );
		$return = [
			'main'    => crm_get_template( 'layout/main.php', [ 'page' => $_POST['page'] ] ),
			'status'  => $result['status'],
			'message' => $result['msg'],
		];
		if ( $_POST['change_status'] == 'finished' ) {
			$return['link'] = home_url( '/crm/order-new/?c_id=' . $_POST['id'] );
		}
		wp_send_json( $return );
	}
	
	public function delete_visit() {
		$result = $this->kcp_db->delete_user_visit( $_POST['item_id'] );
		$return = [
			'main'    => crm_get_template( 'layout/main.php', [ 'page' => $_POST['page'] ] ),
			'status'  => $result['status'],
			'message' => $result['msg'],
		];
		wp_send_json( $return );
	}
	
	public function add_user_note() {
		$user_id = $_POST['id'];
		$desc    = $_POST['desc'];
		$note    = [
			'desc'    => $desc,
			'creator' => get_current_user_id(),
			'date'    => date( 'Y-m-d H:i:s' ),
		];
		$notes   = get_user_meta( $user_id, 'crm_user_notes', TRUE ) ?: [];
		$notes[] = $note;
		update_user_meta( $user_id, 'crm_user_notes', $notes );
		$return = [
			'main'    => crm_get_template( 'layout/main.php', [ 'page' => 'crm/user' ] ),
			'url'     => home_url( 'crm/user/' . $user_id ),
			'message' => 'یادداشت جدید با موفقیت اضافه شد.',
			'status'  => 'info',
		];
		wp_send_json( $return );
	}
	
	public function delete_user_note() {
		$user_id  = $_POST['id'];
		$notes    = get_user_meta( $user_id, 'crm_user_notes', TRUE ) ?: [];
		$note_key = $_POST['key'];
		unset( $notes[ $note_key ] );
		$notes = array_values( $notes );
		update_user_meta( $user_id, 'crm_user_notes', $notes );
		$return = [
			'main'    => crm_get_template( 'layout/main.php', [ 'page' => 'crm/user' ] ),
			'url'     => home_url( 'crm/user/' . $user_id ),
			'message' => 'یادداشت با موفقیت حذف شد.',
			'status'  => 'error',
		];
		wp_send_json( $return );
	}
	
	public function add_user_call() {
		$data   = [
			'user_id'    => $_POST['id'],
			'content'    => $_POST['content'],
			'category'   => $_POST['category'],
			'attachment' => $_POST['attachment'],
			'assign'     => $_POST['assign'],
		];
		$result = $this->kcp_db->add_call_request( $data );
		$return = [
			'main'    => crm_get_template( 'layout/main.php', [ 'page' => 'crm/user' ] ),
			'status'  => $result['status'],
			'message' => $result['msg'],
		];
		wp_send_json( $return );
	}
	
	public function add_hr_call() {
		$data         = [
			'user_id'    => 'hr',
			'content'    => $_POST['content'],
			'category'   => $_POST['category'],
			'attachment' => $_POST['attachment'],
			'assign'     => $_POST['assign'],
			'source'     => 'internal',
		];
		$result       = $this->kcp_db->add_call_request( $data );
		$admin_number = get_user_meta( $_POST['assign'], 'marketer_phone_num', TRUE );
		$sms_data     = [
			'token' => sanitize_string_for_pattern( get_user_name_by_id( get_current_user_id() ) ),
		];
		crm_send_sms( $admin_number, $sms_data, 'requestNotif' );
		$return = [
			'main'    => crm_get_template( 'layout/main.php', [ 'page' => 'crm/hr-requests' ] ),
			'status'  => $result['status'],
			'message' => $result['msg'],
		];
		wp_send_json( $return );
	}
	
	public function add_call_progress() {
		$data   = [
			'call_id'     => $_POST['call_id'],
			'to_status'   => $_POST['new_status'],
			'comment'     => $_POST['content'],
			'to_category' => $_POST['new_category'] ?: '',
			'attachment'  => $_POST['attachment'],
			'assign'      => $_POST['assigned'],
		];
		$result = $this->kcp_db->add_call_progress( $data );
		
		if ( $_POST['assigned'] ) {
			$admin_number = get_user_meta( $_POST['assigned'], 'marketer_phone_num', TRUE );
			$sms_data     = [
				'token' => sanitize_string_for_pattern( get_user_name_by_id( get_current_user_id() ) ),
			];
			crm_send_sms( $admin_number, $sms_data, 'hamkar' );
		}
		$return = [
			'main'    => crm_get_template( 'layout/main.php', [ 'page' => $_POST['page'] ] ),
			'status'  => $result['status'],
			'message' => $result['msg'],
		];
		wp_send_json( $return );
	}
	
	public function delete_call() {
		$result = $this->kcp_db->delete_user_call( $_POST['item_id'] );
		$return = [
			'main'    => crm_get_template( 'layout/main.php', [ 'page' => $_POST['page'] ] ),
			'status'  => $result['status'],
			'message' => $result['msg'],
		];
		wp_send_json( $return );
	}
	
	public function get_stock_log_steps() {
		$return = [
			'html' => crm_get_template( 'partials/stock-progress.php', [ 'item_id' => $_POST['item_id'] ] ),
		];
		wp_send_json( $return );
	}
	
	public function get_call_progress() {
		$return = [
			'html' => crm_get_template( 'partials/call-progress.php', [ 'call_id' => $_POST['item_id'] ] ),
		];
		wp_send_json( $return );
	}
	
	public function get_call_category_users() {
		$employees = get_users( [
			'fields'   => 'ids',
			'orderby'  => 'ID',
			'order'    => 'DESC',
			'role__in' => [ $_POST['category'] ],
		] );
		ob_start();
		foreach ( $employees as $employee ) {
			?>
            <option value="<?php echo $employee; ?>"><?php echo get_user_name_by_id( $employee ); ?></option>
			<?php
		}
		$html   = ob_get_clean();
		$return = [
			'html' => $html,
		];
		wp_send_json( $return );
	}
	
	public function search_product_sku() {
		$sku = $_POST['search'];
		$for = $_POST['for'];
		if ( ! $sku ) {
			$result = [
				'msg'    => 'لطفا کد محصول را وارد کنید.',
				'status' => 'error',
			];
			wp_send_json( $result );
		}
		$product_id = crm_get_product_by_sku( $sku );
		if ( ! $product_id ) {
			$result = [
				'msg'    => 'محصولی با این کد یافت نشد.',
				'status' => 'error',
			];
			wp_send_json( $result );
		}
		$product = wc_get_product( $product_id );
		if ( ! $product ) {
			$result = [
				'msg'    => 'محصولی با این کد یافت نشد.',
				'status' => 'error',
			];
			wp_send_json( $result );
		}
		$title = $product->get_name();
		if ( $for == 'submit_order' ) {
			$stock_status = $product->get_stock_status();
			if ( $stock_status == 'outofstock' ) {
				$result = [
					'msg'    => 'محصول ناموجود است.',
					'status' => 'error',
				];
				wp_send_json( $result );
			}
			$stock     = $product->get_stock_quantity();
			$reg_price = $product->get_regular_price();
			$price     = $product->get_price();
			$price     = round( $price );
			$result    = [
				'status'     => 'success',
				'title'      => $title . '- کد: ' . $sku,
				'main_price' => $reg_price,
				'price'      => $price,
				'stock'      => $stock,
				'product_id' => $product_id,
			];
			wp_send_json( $result );
		}
		$result = [
			'status' => 'success',
			'title'  => $title . '- کد: ' . $sku,
		];
		wp_send_json( $result );
	}
	
	public function add_warning_template() {
		$data = [
			'title'    => $_POST['title'],
			'template' => $_POST['template'],
			'token'    => $_POST['token1'],
			'token2'   => $_POST['token2'] ?: '',
			'token3'   => $_POST['token3'],
		];
		if ( $_POST['template_id'] ) {
			$result = $this->kcp_db->update_warning_template( $_POST['template_id'], $data );
		} else {
			$result = $this->kcp_db->add_warning_template( $data );
		}
		$return = [
			'main'    => crm_get_template( 'layout/main.php', [ 'page' => 'crm/hr-warning-setting' ] ),
			'status'  => $result['status'],
			'message' => $result['msg'],
		];
		wp_send_json( $return );
	}
	
	public function delete_warning_template() {
		$result = $this->kcp_db->delete_warning_template( $_POST['item_id'] );
		$return = [
			'main'    => crm_get_template( 'layout/main.php', [ 'page' => 'crm/hr-warning-setting' ] ),
			'status'  => $result['status'],
			'message' => $result['msg'],
		];
		wp_send_json( $return );
	}
	
	public function send_warning_template() {
		$user_id    = $_POST['user_id'];
		$warning_id = $_POST['template_id'];
		$warning    = $this->kcp_db->get_warning_template( $warning_id );
		
		$phone     = get_user_meta( $user_id, 'marketer_phone_num', TRUE );
		$phone     = nooshika_sanitize_numbers( $phone );
		$phone     = remove_zero_from_phone( $phone );
		$receptor  = '0' . $phone;
		$sms_array = [
			'token'  => $warning['token'],
			'token2' => $warning['token2'],
			'token3' => $warning['token3'],
		];
		$sms_array = nooshika_fill_sms_array_shortcodes( $sms_array, $user_id );
		$sent      = crm_send_sms( $receptor, $sms_array, $warning['template'] );
		$message   = $sent->entries[0]->message;
		$result    = $this->kcp_db->add_warning_log( compact( 'user_id', 'warning_id', 'message' ) );
		
		$return = [
			'main'    => crm_get_template( 'layout/main.php', [ 'page' => 'crm/hr-warning' ] ),
			'status'  => $result['status'],
			'message' => $result['msg'],
		];
		wp_send_json( $return );
	}
	
	public function add_employee_report() {
		$report_id = isset( $_POST['report_id'] ) ? absint( wp_unslash( $_POST['report_id'] ) ) : 0;
		
		$data = [
			'report_id'  => $report_id,
			'title'      => isset( $_POST['title'] ) ? wp_unslash( $_POST['title'] ) : '',
			'content'    => isset( $_POST['content'] ) ? wp_unslash( $_POST['content'] ) : '',
			'category'   => isset( $_POST['new_category'] ) ? wp_unslash( $_POST['new_category'] ) : '',
			'attachment' => isset( $_POST['attachment'] ) ? wp_unslash( $_POST['attachment'] ) : '',
		];
		
		$result = $this->kcp_db->add_employee_report( $data );
		
		$return = [
			'main'    => crm_get_template( 'layout/main.php', [ 'page' => 'crm/hr-reports' ] ),
			'status'  => $result['status'],
			'message' => $result['msg'],
		];
		
		wp_send_json( $return );
	}
	
	public function delete_employee_report() {
		$report_id = isset( $_POST['item_id'] ) ? absint( wp_unslash( $_POST['item_id'] ) ) : 0;
		$result    = $this->kcp_db->delete_employee_report( $report_id );
		
		$return = [
			'main'    => crm_get_template( 'layout/main.php', [ 'page' => 'crm/hr-reports' ] ),
			'status'  => $result['status'],
			'message' => $result['msg'],
		];
		
		wp_send_json( $return );
	}
	
	public function load_product_block() {
		$product_id = $_POST['product_id'];
		if ( ! $product_id ) {
			$result = [
				'message' => 'محصولی با این کد یافت نشد.',
				'status'  => 'error',
			];
			wp_send_json( $result );
		}
		$product = wc_get_product( $product_id );
		if ( ! $product ) {
			$result = [
				'message' => 'محصولی با این کد یافت نشد.',
				'status'  => 'error',
			];
			wp_send_json( $result );
		}
		$title         = $product->get_name();
		$sku           = get_post_meta( $product_id, '_sku', TRUE );
		$reg_price     = (int) $product->get_regular_price();
		$price         = (int) $product->get_price();
		$price         = round( $price );
		$stock         = 1000;
		$size_taxonomy = 'pa_size';
		$child_size    = $product->get_attribute( $size_taxonomy );
		$custom_size   = $child_size == 'سایز دلخواه';
		$cut_carpet    = kcp_product_has_cut_carpet_tag( $product );
		$result        = [
			'status'      => 'success',
			'title'       => $title,
			'main_price'  => $reg_price,
			'price'       => $price,
			'stock'       => $stock,
			'product_id'  => $product_id,
			'custom_size' => $custom_size,
			'cut_carpet'  => $cut_carpet,
			'html'        => crm_get_template(
				'misc/product_block.php',
				compact( 'product_id', 'price', 'stock', 'reg_price', 'title', 'sku', 'custom_size', 'cut_carpet' )
			),
		];
		wp_send_json( $result );
	}
	
	public function search_sku_for_order() {
		$search_raw = $_POST['search'] ?? '';
		$search     = sanitize_text_field( wp_unslash( $search_raw ) );
		if ( $search == '' ) {
			$result = [
				'message' => 'متن جستجو را وارد کنید.',
				'status'  => 'error',
			];
			wp_send_json( $result );
		}
		global $wpdb;
		
		$like = '%' . $wpdb->esc_like( $search ) . '%';
		
		// --- Title match: simple products ---
		$parent_ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT p.ID
				   FROM {$wpdb->posts} p
				  WHERE p.post_status = 'publish'
				    AND p.post_type   = 'product'
				    AND p.post_title  LIKE %s
				  LIMIT 100",
				$like
			)
		);
		
		$result_ids = [];
		foreach ( $parent_ids as $pid ) {
			$p = wc_get_product( $pid );
			if ( ! $p ) {
				continue;
			}
			
			if ( $p->is_type( 'variable' ) ) {
				$children = $p->get_children(); // IDs of variations
				if ( $children ) {
					$result_ids = array_merge( $result_ids, $children );
				}
			} else {
				$result_ids[] = $pid; // ساده یا هر نوع غیر variable
			}
		}
		
		// Deduplicate & clean
		$result_ids = array_values( array_unique( array_map( 'intval', $result_ids ) ) );
		
		$filtered = array_slice( $result_ids, 0, 50 );
		$args     = [
			'product_ids' => $filtered,
			'type'        => $_POST['type'],
		];
		
		$result = [
			'status' => 'list',
			'html'   => crm_get_template( "misc/product_search.php", $args ),
		];
		wp_send_json( $result );
	}
	
	public function load_user_address() {
		$user_id   = $_POST['user_id'];
		$addresses = get_user_meta( $user_id, 'address_list', TRUE );
		$addresses = kasebi_unminified_string( $addresses );
		$addresses = $addresses ?: [];
		$result    = [
			'html' => crm_get_template( "misc/addresses.php", [
				'addresses' => $addresses,
				'user_id'   => $user_id,
			] ),
		];
		wp_send_json( $result );
	}
	
	public function load_user_referral_block() {
		$user_id           = $_POST['user_id'];
		$has_used_referral = get_user_meta( $user_id, 'kasebi_has_used_referral', TRUE );
		if ( $has_used_referral != 'yes' ) {
			$result = [
				'status' => 'valid',
				'html'   => crm_get_template( "misc/referral_form.php", [
					'user_id' => $user_id,
				] ),
			];
			wp_send_json( $result );
		}
		$result = [
			'status' => 'in-valid',
		];
		wp_send_json( $result );
	}
	
	public function set_referral_code_for_user() {
		$user_id  = $_POST['user_id'];
		$code     = $_POST['code'];
		$referrer = crm_get_user_by_referral_code( $code );
		$return   = [];
		
		if ( $referrer == $user_id ) {
			$return['status'] = 'error';
			$return['msg']    = 'کد معرف متعلق به خود مشتری است';
			wp_send_json( $return );
		}
		if ( $referrer == 0 ) {
			$return['status'] = 'error';
			$return['msg']    = 'کد معرف معتبر نیست';
			wp_send_json( $return );
		}
		update_user_meta( $user_id, 'kasebi_user_referrer_id', $referrer );
		$return['status'] = 'success';
		$return['html']   = crm_get_template( "misc/referral_form.php", [
			'user_id' => $user_id,
		] );
		$return['msg']    = 'کد معرف با موفقیت اعمال شد';
		wp_send_json( $return );
	}
	
	public function save_user_address() {
		$user_id   = $_POST['user_id'];
		$addresses = get_user_meta( $user_id, 'address_list', TRUE );
		$addresses = kasebi_unminified_string( $addresses );
		
		$address    = $_POST['address'] ?? [];
		$address_id = isset( $_POST['address_id'] ) && $_POST['address_id'] !== 'false'
			? absint( $_POST['address_id'] )
			: count( $addresses );
		
		$addresses[ $address_id ] = $address;
		
		$state = is_array( $address ) && isset( $address['state'] )
			? sanitize_text_field( $address['state'] )
			: '';
		$city  = is_array( $address ) && isset( $address['city'] )
			? sanitize_text_field( $address['city'] )
			: '';
		
		update_user_meta( $user_id, 'state', $state );
		update_user_meta( $user_id, 'city', $city );
		
		$result    = [
			'html' => crm_get_template( "misc/addresses.php", [
				'addresses' => $addresses,
				'user_id'   => $user_id,
			] ),
		];
		$addresses = kasebi_minify_array( $addresses );
		update_user_meta( $user_id, 'address_list', $addresses );
		update_user_meta( $user_id, 'default_address', $address_id );
		wp_send_json( $result );
	}
	
	public function delete_customer_address() {
		$user_id    = absint( $_POST['user_id'] ?? 0 );
		$addresses  = get_user_meta( $user_id, 'address_list', TRUE );
		$addresses  = kasebi_unminified_string( $addresses );
		$address_id = absint( $_POST['address_id'] ?? 0 );
		
		if ( ! is_array( $addresses ) ) {
			$addresses = [];
		}
		
		unset( $addresses[ $address_id ] );
		
		$addresses = array_values( $addresses );
		
		$default_address = get_user_meta( $user_id, 'default_address', TRUE );
		
		if ( (string) $default_address === (string) $address_id ) {
			$new_default_address = ! empty( $addresses ) ? 0 : '';
			
			update_user_meta( $user_id, 'default_address', $new_default_address );
			
			if ( isset( $addresses[0] ) && is_array( $addresses[0] ) ) {
				update_user_meta( $user_id, 'state', sanitize_text_field( $addresses[0]['state'] ?? '' ) );
				update_user_meta( $user_id, 'city', sanitize_text_field( $addresses[0]['city'] ?? '' ) );
			} else {
				delete_user_meta( $user_id, 'state' );
				delete_user_meta( $user_id, 'city' );
			}
		}
		
		$result = [
			'html' => crm_get_template( "misc/addresses.php", [
				'addresses' => $addresses,
				'user_id'   => $user_id,
			] ),
		];
		
		$addresses = kasebi_minify_array( $addresses );
		
		update_user_meta( $user_id, 'address_list', $addresses );
		
		wp_send_json( $result );
	}
	
	public function submit_new_order() {
		$customer_id    = $_POST['customer_id'];
		$address_key    = $_POST['address_id'];
		$addresses      = get_user_meta( $customer_id, 'address_list', TRUE );
		$addresses      = kasebi_unminified_string( $addresses );
		$address        = $addresses[ $address_key ];
		$full_address   = [
			$address['region'],
			$address['section'],
			$address['address_1'],
		];
		$full_address   = array_filter( $full_address );
		$address        = [
			'first_name' => $address['first_name'],
			'last_name'  => $address['last_name'],
			'city'       => $address['city'],
			'state'      => $address['state'],
			'phone'      => $address['phone'],
			'postcode'   => $address['postcode'],
			'address_1'  => implode( ' - ', $full_address ),
		];
		$products       = $_POST['products'];
		$maybe_order_id = absint( $_POST['order_id'] ?? 0 );
		$marketer_id    = get_current_user_id();
		$marketer_name  = get_user_name_by_id( $marketer_id );
		if ( $maybe_order_id > 0 && ( $existing = wc_get_order( $maybe_order_id ) ) ) {
			$order    = $existing;
			$order_id = $order->get_id();
			
			foreach ( $order->get_items( 'line_item' ) as $item_id => $item ) {
				$order->remove_item( $item_id );
			}
			foreach ( $order->get_items( 'fee' ) as $item_id => $item ) {
				$order->remove_item( $item_id );
			}
			
			$action_label = 'ویرایش شد.';
		} else {
			$order        = wc_create_order( [ 'customer_id' => $customer_id ] );
			$order_id     = $order->get_id();
			$action_label = 'ایجاد شد.';
			
			$order->update_meta_data( 'marketer_id', $marketer_id );
		}
		
		$order->update_meta_data( 'address_id', $address_key );
		foreach ( $products as $data ) {
			$product_id = absint( $data['product_id'] ?? 0 );
			
			if ( ! $product_id ) {
				continue;
			}
			
			$product = wc_get_product( $product_id );
			
			if ( ! $product ) {
				continue;
			}
			
			$qty = isset( $data['qty'] )
				? (float) wc_format_decimal( wp_unslash( $data['qty'] ), 3 )
				: 0;
			
			if ( $qty <= 0 ) {
				continue;
			}
			
			$off_percent = isset( $data['off_percent'] )
				? (float) wc_format_decimal( wp_unslash( $data['off_percent'] ), 2 )
				: 0;
			
			$off_percent = max( 0, min( 100, $off_percent ) );
			
			$subtotal = isset( $data['subtotal'] )
				? (float) wc_format_decimal( wp_unslash( $data['subtotal'] ), wc_get_price_decimals() )
				: 0;
			
			$line_total = isset( $data['line_total'] )
				? (float) wc_format_decimal( wp_unslash( $data['line_total'] ), wc_get_price_decimals() )
				: 0;
			
			/*
			 * اگر line_total از JS نیامده بود،
			 * از روی subtotal و درصد تخفیف محاسبه می‌کنیم.
			 */
			if ( $subtotal > 0 && $line_total <= 0 ) {
				$line_total = $subtotal - ( $subtotal * $off_percent / 100 );
			}
			
			$subtotal   = max( 0, $subtotal );
			$line_total = max( 0, $line_total );
			
			/*
			 * جلوگیری از اینکه قیمت بعد از تخفیف از قیمت اصلی بیشتر شود
			 */
			if ( $subtotal > 0 && $line_total > $subtotal ) {
				$line_total = $subtotal;
			}
			
			$regular_unit_price = $qty > 0 ? $subtotal / $qty : 0;
			$discount_amount    = $subtotal - $line_total;
			
			$args    = [
				'name'     => $product->get_name(),
				'subtotal' => $subtotal,
				'total'    => $line_total,
			];
			$item_id = $order->add_product( $product, $qty, $args );
			if ( ! $item_id ) {
				continue;
			}
			$item = $order->get_item( $item_id );
			
			if ( ! $item || ! is_object( $item ) ) {
				continue;
			}
			
			$item->add_meta_data( 'line_single_total', wc_format_decimal( $regular_unit_price, wc_get_price_decimals() ), TRUE );
			$item->add_meta_data( 'line_regular_total', wc_format_decimal( $subtotal, wc_get_price_decimals() ), TRUE );
			$item->add_meta_data( 'line_discount_total', wc_format_decimal( $discount_amount, wc_get_price_decimals() ), TRUE );
			$item->add_meta_data( 'line_decimal_qty', $qty, TRUE );
			
			if ( isset( $data['off_percent'] ) ) {
				$item->add_meta_data( 'off_percent', $off_percent, TRUE );
			}
			
			if ( isset( $data['note'] ) && $data['note'] !== '' ) {
				$item->add_meta_data( 'note', sanitize_textarea_field( wp_unslash( $data['note'] ) ), TRUE );
			}
			$item->save();
		}
		$order->set_address( $address );
		$order->set_address( $address, 'shipping' );
		$order->calculate_totals();
		if ( ! empty( $_POST['custom_fee'] ) && $_POST['custom_fee'] > 0 ) {
			$custom_fee = floatval( $_POST['custom_fee'] );
			$fee        = new WC_Order_Item_Fee();
			$fee->set_name( 'تخفیف سفارش' );
			$fee->set_amount( - $custom_fee );
			$fee->set_total( - $custom_fee );
			$fee->set_order_id( $order->get_id() );
			$order->add_item( $fee );
			$order->update_meta_data( 'custom_fee', $custom_fee );
		} else {
			$order->delete_meta_data( 'custom_fee' );
		}
		$custom_extra_fee = floatval( $_POST['custom_extra_fee'] ?? 0 );
		
		if ( $custom_extra_fee > 0 ) {
			$fee = new WC_Order_Item_Fee();
			$fee->set_name( 'میزان بالابرد' );
			$fee->set_amount( $custom_extra_fee );
			$fee->set_total( $custom_extra_fee );
			$fee->set_order_id( $order->get_id() );
			
			$order->add_item( $fee );
			$order->update_meta_data( 'custom_extra_fee', $custom_extra_fee );
		} else {
			$order->delete_meta_data( 'custom_extra_fee' );
		}
		if ( ! empty( $_POST['use_referral'] ) && $_POST['use_referral'] > 0 ) {
			$off_amount = get_option( 'kasebi_referral_amount' );
			$fee        = new WC_Order_Item_Fee();
			$fee->set_name( 'تخفیف معرف' );
			$fee->set_amount( - $off_amount );
			$fee->set_total( - $off_amount );
			$fee->set_order_id( $order->get_id() );
			$order->add_item( $fee );
			$order->update_meta_data( 'referral_amount', $off_amount );
			update_user_meta( $customer_id, 'kasebi_has_used_referral', 'yes' );
		} else {
			$order->delete_meta_data( 'referral_amount' );
		}
		$payments_list_raw = $_POST['payment_list'] ?? [];
		$payments_list     = is_array( $payments_list_raw ) ? $payments_list_raw : [];
		$payments_list     = array_map( static function( $item ) {
			$item = is_array( $item ) ? $item : [];
			
			if ( ! empty( $item['date'] ) ) {
				$item['date'] = nooshika_jalali_to_gregorian( $item['date'] );
			}
			
			return $item;
		}, $payments_list );
		
		usort( $payments_list, static function( $a, $b ) {
			$ad = $a['date'] ?? '';
			$bd = $b['date'] ?? '';
			
			return strtotime( $ad ) <=> strtotime( $bd );
		} );
		
		$cash_total      = 0;
		$current_user_id = (int) get_current_user_id();
		$this->kcp_db->delete_cash_payment( [
			'order_id' => $order_id,
		] );
		$saved_payments = [];
		
		foreach ( $payments_list as $p ) {
			$p       = is_array( $p ) ? $p : [];
			$user_id = ! empty( $p['user'] ) ? (int) $p['user'] : $current_user_id;
			$amount  = (float) ( $p['amount'] ?? 0 );
			
			$insert_id        = $this->kcp_db->add_cash_payment( [
				'order_id'  => $order_id,
				'user_id'   => $user_id,
				'amount'    => $amount,
				'bank'      => ( $p['bank'] ?? NULL ),
				'paid_date' => ( $p['date'] ?? NULL ),
			] );
			$saved_payments[] = [
				'id'       => (int) $insert_id,      // id واقعی جدول
				'order_id' => $order_id,
				'user'     => $user_id,
				'amount'   => $amount,
				'bank'     => ( $p['bank'] ?? NULL ),
				'date'     => ( $p['date'] ?? NULL ),
			];
			$cash_total       += floatval( $amount ?? 0 );
		}
		$order->update_meta_data( '_ksm_order_cash_payments_data', $saved_payments );
		
		$payment_type = $_POST['payment_type'] ?? '';
		$order->update_meta_data( 'order_payment_type', $payment_type );
		$order->calculate_totals();
		if ( $payment_type === 'pay_dated' ) {
			$dated_payment_days = absint( $_POST['dated_payment_days'] ?? 0 );
			
			if ( $dated_payment_days > 0 ) {
				$order->update_meta_data( 'dated_payment_days', $dated_payment_days );
			} else {
				$order->delete_meta_data( 'dated_payment_days' );
			}
		} else {
			$order->delete_meta_data( 'dated_payment_days' );
		}
		if ( $payment_type === 'pay_monthly' ) {
			$month_count = (int) ( $_POST['month_count'] ?? 0 );
			$cheque_diff = (int) ( $_POST['cheque_count'] ?? 1 );
			$percentage  = (float) ( $_POST['percentage'] ?? 0 );
			
			$cheque_count  = floor( $month_count / $cheque_diff );
			$total_percent = $percentage * $month_count;
			$order_total   = $order->get_total() - $cash_total;
			$extra_fee     = $order_total * $total_percent / 100;
			$each_cheque   = $order_total / max( 1, $cheque_count );
			
			$fee = new WC_Order_Item_Fee();
			$fee->set_name( 'تفاوت مدت' );
			$fee->set_amount( $extra_fee );
			$fee->set_total( $extra_fee );
			$fee->set_order_id( $order->get_id() );
			$order->add_item( $fee );
			
			$order->update_meta_data( 'extra_fee', $extra_fee );
			$order->update_meta_data( 'order_each_cheque', $each_cheque );
			$order->update_meta_data( 'order_month_count', $month_count );
			$order->update_meta_data( 'order_cheque_count', $cheque_diff );
			$order->update_meta_data( 'order_percentage', $percentage );
		} else {
			foreach (
				[
					'order_month_count',
					'order_cheque_count',
					'order_first_cheque_date',
					'order_percentage',
					'extra_fee',
					'order_each_cheque',
				] as $meta_key
			) {
				$order->delete_meta_data( $meta_key );
			}
		}
		
		$in_person_discount = floatval( $_POST['in_person_discount'] ?? 0 );
		if ( $in_person_discount > 0 ) {
			$fee = new WC_Order_Item_Fee();
			$fee->set_name( 'تخفیف حضوری' );
			$fee->set_amount( - $in_person_discount );
			$fee->set_total( - $in_person_discount );
			$fee->set_order_id( $order->get_id() );
			$order->add_item( $fee );
			$order->update_meta_data( 'in_person_discount', $in_person_discount );
		} else {
			$order->delete_meta_data( 'in_person_discount' );
		}
		
		$order->calculate_totals();
		$description = $_POST['description'];
		if ( $description ) {
			$order->update_meta_data( 'cashier_note', $description );
		} else {
			$order->delete_meta_data( 'cashier_note' );
		}
		$attachment_string = $_POST['attachments'] ?? '';
		
		if ( $attachment_string ) {
			$urls        = array_filter( array_map( 'trim', explode( ',', $attachment_string ) ) );
			$order_files = [];
			foreach ( $urls as $url ) {
				$order_files[] = [
					'url' => $url,
				];
			}
			
			if ( ! empty( $order_files ) ) {
				$order->update_meta_data( 'order_files', $order_files );
			}
		}
		if ( $maybe_order_id > 0 ) {
			$order->add_order_note( "این سفارش توسط {$marketer_name} ویرایش شد." );
		} else {
			$order->add_order_note( "این سفارش توسط {$marketer_name} ایجاد شد." );
			$order->update_status( 'pending', 'پیش فاکتور ثبت شد.' );
		}
		$factor_date = $_POST['factor_date'];
		if ( $factor_date ) {
			$factor_date = nooshika_jalali_to_gregorian( $factor_date );
			$order->set_date_created( strtotime( $factor_date ) );
		}
		
		$order->save();
		do_action( 'kasebi_order_saved', $order_id );
		/**
		 *
		 */
		$return = [
			'factor'  => home_url() . '/crm/?action=factor&type=pre&order_id=' . $order_id,
			'main'    => crm_get_template( 'layout/main.php', [ 'page' => 'crm/sale-orders' ] ),
			'status'  => 'success',
			'message' => 'سفارش ' . $action_label,
		];
		wp_send_json( $return );
	}
	
	public function change_order_status() {
		$order_id = $_POST['order_id'];
		$status   = $_POST['new_status'];
		$order    = wc_get_order( $order_id );
		if ( isset( $_POST['shipment_days'] ) ) {
			$shipment_days = $_POST['shipment_days'];
			if ( $shipment_days < 5 ) {
				$shipment_days += 2;
			} elseif ( $shipment_days < 11 ) {
				$shipment_days += 3;
			} elseif ( $shipment_days < 16 ) {
				$shipment_days += 4;
			} elseif ( $shipment_days < 26 ) {
				$shipment_days += 5;
			} else {
				$shipment_days += 7;
			}
			$order->update_meta_data( 'shipment_days', $shipment_days );
			$order->update_meta_data( 'shipment_date', date( 'Y-m-d', strtotime( "+$shipment_days days" ) ) );
		}
		$order->update_meta_data( "order_status_to_$status", get_current_user_id() );
		$order->update_meta_data( "order_status_to_{$status}_date", date( 'Y-m-d H:i:s' ) );
		$order->update_status( $status );
		unset( $_POST['order_id'] );
		unset( $_REQUEST['order_id'] );
		$return = [
			'main'    => crm_get_template( 'layout/main.php', [ 'page' => $_POST['page'] ] ),
			'message' => 'وضعیت سفارش با موفقیت تغییر یافت.',
			'status'  => 'info',
		];
		wp_send_json( $return );
	}
	
	public function load_order_items_table() {
		$return = [
			'html' => crm_get_template( 'partials/order-items.php', [ 'order_id' => $_POST['order_id'] ] ),
		];
		wp_send_json( $return );
	}
	
	public function load_order_cheque() {
		$return = [
			'html' => crm_get_template( 'partials/order-cheque.php', [ 'order_id' => $_POST['order_id'] ] ),
		];
		wp_send_json( $return );
	}
	
	public function submit_new_cheque_for_order() {
		$order_id = (int) ( $_POST['order_id'] ?? 0 );
		$item_key = $_POST['item_key'] ?? 'false';
		
		if ( $order_id <= 0 ) {
			wp_send_json_error( [ 'message' => 'invalid_order_id' ], 400 );
		}
		
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			wp_send_json_error( [ 'message' => 'order_not_found' ], 404 );
		}
		$current_user_id = (int) get_current_user_id();
		$cheque_data     = [
			'order_id'        => $order_id,
			'user_id'         => $current_user_id,
			'check_serial'    => sanitize_text_field( $_POST['check_serial'] ?? '' ),
			'check_amount'    => (float) ( $_POST['check_amount'] ?? 0 ),
			'check_expire'    => ! empty( $_POST['check_expire'] )
				? nooshika_jalali_to_gregorian( sanitize_text_field( $_POST['check_expire'] ) )
				: NULL,
			'bank_name'       => sanitize_text_field( $_POST['bank_name'] ?? '' ),
			'branch_name'     => sanitize_text_field( $_POST['branch_name'] ?? '' ),
			'current_account' => sanitize_text_field( $_POST['current_account'] ?? '' ),
			'account_owner'   => sanitize_text_field( $_POST['account_owner'] ?? '' ),
			'national_code'   => sanitize_text_field( $_POST['national_code'] ?? '' ),
		];
		
		if ( $cheque_data['check_amount'] <= 0 ) {
			wp_send_json_error( [ 'message' => 'invalid_amount' ], 400 );
		}
		if ( $item_key !== 'false' ) {
			$this->kcp_db->delete_order_cheque( [
				'id'       => (int) $item_key,
				'order_id' => $order_id,
			] );
		}
		$insert_id = $this->kcp_db->add_order_cheque( $cheque_data );
		if ( ! $insert_id ) {
			wp_send_json_error( [ 'message' => 'insert_failed' ], 500 );
		}
		
		// ریلود از DB
		$cheque_list = $this->kcp_db->get_order_cheques( [
			'order_id' => $order_id,
		] );
		
		// مرتب‌سازی بر اساس تاریخ سررسید
		usort( $cheque_list, static function( $a, $b ) {
			return strtotime( $a['check_expire'] ?? '' ) <=> strtotime( $b['check_expire'] ?? '' );
		} );
		
		// سینک متای سفارش (صرفاً برای UI)
		$saved_cheques = [];
		foreach ( (array) $cheque_list as $c ) {
			$saved_cheques[] = [
				'id'              => (int) ( $c['id'] ?? 0 ),
				'order_id'        => $order_id,
				'user'            => (int) ( $c['user_id'] ?? $current_user_id ),
				'check_serial'    => $c['check_serial'] ?? '',
				'check_amount'    => (float) ( $c['check_amount'] ?? 0 ),
				'check_expire'    => $c['check_expire'] ?? NULL,
				'bank_name'       => $c['bank_name'] ?? NULL,
				'branch_name'     => $c['branch_name'] ?? NULL,
				'current_account' => $c['current_account'] ?? NULL,
				'account_owner'   => $c['account_owner'] ?? NULL,
				'national_code'   => $c['national_code'] ?? NULL,
				'status'          => $c['status'] ?? 'registered',
			];
		}
		
		$order->update_meta_data( '_ksm_order_payments_data', $saved_cheques );
		$order->save();
		$return = [
			'html' => crm_get_template( 'partials/order-cheque.php', [ 'order_id' => $_POST['order_id'] ] ),
		];
		wp_send_json( $return );
	}
	
	public function delete_cheque_for_order() {
		$order_id = (int) ( $_POST['order_id'] ?? 0 );
		$item_id  = (int) ( $_POST['item_key'] ?? 0 );
		
		if ( $order_id <= 0 || $item_id <= 0 ) {
			wp_send_json_error( [ 'message' => 'invalid_params' ], 400 );
		}
		
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			wp_send_json_error( [ 'message' => 'order_not_found' ], 404 );
		}
		$deleted_ok = $this->kcp_db->delete_order_cheque( [
			'id'       => $item_id,
			'order_id' => $order_id, // ایمن
		] );
		
		if ( ! $deleted_ok ) {
			wp_send_json_error( [ 'message' => 'delete_failed' ], 500 );
		}
		
		// 2) ریلود از DB
		$cheque_list = $this->kcp_db->get_order_cheques( [
			'order_id' => $order_id,
		] );
		
		usort( $cheque_list, static function( $a, $b ) {
			return strtotime( $a['check_expire'] ?? '' ) <=> strtotime( $b['check_expire'] ?? '' );
		} );
		$current_user_id = (int) get_current_user_id();
		$saved_cheques   = [];
		foreach ( (array) $cheque_list as $c ) {
			$saved_cheques[] = [
				'id'              => (int) ( $c['id'] ?? 0 ),
				'order_id'        => $order_id,
				'user'            => (int) ( $c['user_id'] ?? $current_user_id ),
				'check_serial'    => $c['check_serial'] ?? '',
				'check_amount'    => (float) ( $c['check_amount'] ?? 0 ),
				'check_expire'    => $c['check_expire'] ?? NULL,
				'bank_name'       => $c['bank_name'] ?? NULL,
				'branch_name'     => $c['branch_name'] ?? NULL,
				'current_account' => $c['current_account'] ?? NULL,
				'account_owner'   => $c['account_owner'] ?? NULL,
				'national_code'   => $c['national_code'] ?? NULL,
				'status'          => $c['status'] ?? 'registered',
			];
		}
		
		$order->update_meta_data( '_ksm_order_payments_data', $saved_cheques );
		$order->save();
		
		$return = [
			'html' => crm_get_template( 'partials/order-cheque.php', [ 'order_id' => $_POST['order_id'] ] ),
		];
		wp_send_json( $return );
	}
	
	public function load_order_installments() {
		$return = [
			'html' => crm_get_template( 'partials/order-installments.php', [ 'order_id' => $_POST['order_id'] ] ),
		];
		wp_send_json( $return );
	}
	
	public function load_order_cash_table() {
		$return = [
			'html' => crm_get_template( 'partials/order-cash.php', [ 'order_id' => $_POST['order_id'] ] ),
		];
		wp_send_json( $return );
	}
	
	public function submit_cash_payment_for_order() {
		$order_id = (int) ( $_POST['order_id'] ?? 0 );
		if ( $order_id <= 0 ) {
			wp_send_json_error( [ 'message' => 'invalid_order_id' ], 400 );
		}
		
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			wp_send_json_error( [ 'message' => 'order_not_found' ], 404 );
		}
		$amount = (float) ( $_POST['amount'] ?? 0 );
		$bank   = isset( $_POST['bank'] ) ? sanitize_text_field( wp_unslash( $_POST['bank'] ) ) : NULL;
		$date   = isset( $_POST['date'] ) ? sanitize_text_field( wp_unslash( $_POST['date'] ) ) : NULL;
		
		if ( $amount <= 0 ) {
			wp_send_json_error( [ 'message' => 'invalid_amount' ], 400 );
		}
		
		if ( ! empty( $date ) ) {
			$date = nooshika_jalali_to_gregorian( $date );
		}
		$current_user_id = (int) get_current_user_id();
		$insert_id       = $this->kcp_db->add_cash_payment( [
			'order_id'  => $order_id,
			'user_id'   => $current_user_id,
			'amount'    => $amount,
			'bank'      => $bank,
			'paid_date' => $date,
		] );
		
		if ( ! $insert_id ) {
			wp_send_json_error( [ 'message' => 'insert_failed' ], 500 );
		}
		$cash_list      = $this->kcp_db->get_cash_payments( [ 'order_id' => $order_id ] );
		$saved_payments = [];
		foreach ( (array) $cash_list as $p ) {
			$p                = is_array( $p ) ? $p : [];
			$user_id          = ! empty( $p['user_id'] ) ? (int) $p['user_id'] : $current_user_id;
			$amt              = (float) ( $p['amount'] ?? 0 );
			$saved_payments[] = [
				'id'       => (int) ( $p['id'] ?? 0 ),
				'order_id' => $order_id,
				'user'     => $user_id,
				'amount'   => $amt,
				'bank'     => ( $p['bank'] ?? NULL ),
				'date'     => ( $p['paid_date'] ?? NULL ),
			];
		}
		
		$order->update_meta_data( '_ksm_order_cash_payments_data', $saved_payments );
		$order->save();
		$return = [
			'html' => crm_get_template( 'partials/order-cash.php', [ 'order_id' => $_POST['order_id'] ] ),
		];
		wp_send_json( $return );
	}
	
	public function delete_cash_for_order() {
		$order_id = (int) ( $_POST['order_id'] ?? 0 );
		$item_id  = (int) ( $_POST['item_key'] ?? 0 );
		if ( $order_id <= 0 || $item_id <= 0 ) {
			wp_send_json_error( [ 'message' => 'invalid_params' ], 400 );
		}
		
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			wp_send_json_error( [ 'message' => 'order_not_found' ], 404 );
		}
		$this->kcp_db->delete_cash_payment( [
			'id'       => $item_id,
			'order_id' => $order_id,
		] );
		$saved_payments  = [];
		$cash_list       = $this->kcp_db->get_cash_payments( [ 'order_id' => $order_id, ] );
		$current_user_id = get_current_user_id();
		foreach ( $cash_list as $p ) {
			$p                = is_array( $p ) ? $p : [];
			$user_id          = ! empty( $p['user'] ) ? (int) $p['user'] : $current_user_id;
			$amount           = (float) ( $p['amount'] ?? 0 );
			$saved_payments[] = [
				'id'       => (int) $p['id'],      // id واقعی جدول
				'order_id' => $order_id,
				'user'     => $user_id,
				'amount'   => $amount,
				'bank'     => ( $p['bank'] ?? NULL ),
				'date'     => ( $p['date'] ?? NULL ),
			];
		}
		$order->update_meta_data( '_ksm_order_cash_payments_data', $saved_payments );
		$order->save();
		$return = [
			'html' => crm_get_template( 'partials/order-cash.php', [ 'order_id' => $_POST['order_id'] ] ),
		];
		wp_send_json( $return );
	}
	
	public function submit_order_installment_data() {
		$order_id = (int) ( $_POST['order_id'] ?? 0 );
		if ( $order_id <= 0 ) {
			wp_send_json_error( [ 'message' => 'invalid_order_id' ], 400 );
		}
		
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			wp_send_json_error( [ 'message' => 'order_not_found' ], 404 );
		}
		$this->kcp_db->delete_installment( $order_id );
		$current_user_id   = (int) get_current_user_id();
		$installment_data  = [
			'order_id'                => $order_id,
			'user_id'                 => $current_user_id,
			'payment_user_name'       => sanitize_text_field( $_POST['payment_user_name'] ?? '' ),
			'payment_user_nid'        => sanitize_text_field( $_POST['payment_user_nid'] ?? '' ),
			'payment_plan_name'       => sanitize_text_field( $_POST['payment_plan_name'] ?? '' ),
			'payment_plan_start_date' => ! empty( $_POST['payment_plan_start_date'] )
				? nooshika_jalali_to_gregorian( sanitize_text_field( $_POST['payment_plan_start_date'] ) )
				: NULL,
			'payment_plan_month'      => (int) ( $_POST['payment_plan_month'] ?? 0 ),
			'payment_plan_amount'     => (float) ( $_POST['payment_plan_amount'] ?? 0 ),
			'payment_rec_number'      => sanitize_text_field( $_POST['payment_rec_number'] ?? '' ),
			'payment_rec_date'        => ! empty( $_POST['payment_rec_date'] )
				? nooshika_jalali_to_gregorian( sanitize_text_field( $_POST['payment_rec_date'] ) )
				: NULL,
			'payment_recorded_bank'   => sanitize_text_field( $_POST['payment_recorded_bank'] ?? '' ),
			'payment_recorded_by'     => sanitize_text_field( $_POST['payment_recorded_by'] ?? '' ),
			'payment_recorded_date'   => ! empty( $_POST['payment_recorded_date'] )
				? nooshika_jalali_to_gregorian( sanitize_text_field( $_POST['payment_recorded_date'] ) )
				: NULL,
		];
		$oragh_fee_item    = NULL;
		$oragh_fee_item_id = NULL;
		
		foreach ( $order->get_items( 'fee' ) as $item_id => $fee_item ) {
			if ( $fee_item->get_meta( '_ksm_oragh_fee' ) ) {
				$oragh_fee_item_id = $item_id;
				$oragh_fee_item    = $fee_item;
				break;
			}
		}
		
		if ( $installment_data['payment_plan_name'] === 'oragh' ) {
			$subtotal   = (float) $order->get_subtotal();
			$fee_amount = round( $subtotal * 0.08, wc_get_price_decimals() );
			
			if ( $oragh_fee_item ) {
				$oragh_fee_item->set_amount( $fee_amount );
				$oragh_fee_item->set_total( $fee_amount );
			} else {
				$fee = new WC_Order_Item_Fee();
				$fee->set_name( 'کارمزد اوراق (۸٪)' );
				$fee->set_amount( $fee_amount );
				$fee->set_total( $fee_amount );
				$fee->set_tax_status( 'none' );
				$fee->add_meta_data( '_ksm_oragh_fee', 1, TRUE );
				$order->add_item( $fee );
			}
			
			if ( $installment_data['payment_plan_month'] > 0 ) {
				$installment_data['payment_plan_amount'] =
					( $subtotal + $fee_amount ) / $installment_data['payment_plan_month'];
			}
		} else {
			// حذف کارمزد در صورت تغییر پلن
			if ( $oragh_fee_item_id ) {
				$order->remove_item( $oragh_fee_item_id );
			}
		}
		$insert_id = $this->kcp_db->add_installment( $installment_data );
		
		if ( ! $insert_id ) {
			wp_send_json_error( [ 'message' => 'installment_insert_failed' ], 500 );
		}
		$order->update_meta_data( '_ksm_order_payment_extra_data', array_merge(
			$installment_data,
			[ 'id' => $insert_id ]
		) );
		
		$order->calculate_totals();
		$order->save();
		
		$return = [
			'html' => crm_get_template( 'partials/order-installments.php', [ 'order_id' => $order_id ] ),
		];
		wp_send_json( $return );
	}
	
	public function delete_order_installment_data() {
		$order_id = (int) ( $_POST['order_id'] ?? 0 );
		if ( $order_id <= 0 ) {
			wp_send_json_error( [ 'message' => 'invalid_order_id' ], 400 );
		}
		
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			wp_send_json_error( [ 'message' => 'order_not_found' ], 404 );
		}
		$deleted_ok = $this->kcp_db->delete_installment( $order_id );
		
		if ( ! $deleted_ok ) {
			wp_send_json_error( [ 'message' => 'delete_failed' ], 500 );
		}
		foreach ( $order->get_items( 'fee' ) as $item_id => $fee_item ) {
			if ( $fee_item->get_meta( '_ksm_oragh_fee' ) ) {
				$order->remove_item( $item_id );
				break;
			}
		}
		
		/*
		 * ---------- پاک‌سازی متای UI ----------
		 */
		$order->delete_meta_data( '_ksm_order_payment_extra_data' );
		$order->calculate_totals();
		$order->save();
		$return = [
			'html' => crm_get_template( 'partials/order-installments.php', [ 'order_id' => $order_id ] ),
		];
		wp_send_json( $return );
	}
	
	public function set_production_processing() {
		$process_id    = $_POST['process_id'];
		$complete_date = $_POST['complete_date'];
		$complete_date = nooshika_jalali_to_gregorian( $complete_date );
		$result        = $this->kcp_db->set_production_processing( $process_id, $complete_date );
		$return        = [
			'main'    => crm_get_template( 'layout/main.php', [ 'page' => $_POST['page'] ] ),
			'status'  => $result['status'],
			'message' => $result['msg'],
		];
		wp_send_json( $return );
	}
	
	public function get_process_steps() {
		$return = [
			'html' => crm_get_template( 'partials/process-steps.php', [ 'process_id' => $_POST['process_id'] ] ),
		];
		wp_send_json( $return );
	}
	
	public function add_product_to_store() {
		$product_id = $_POST['product_id'];
		$qty        = nooshika_sanitize_numbers( $_POST['qty'] );
		$to_stock   = $_POST['to_stock'] ?? 'store';
		$product    = wc_get_product( $product_id );
		if ( ! $product ) {
			$return = [
				'main'    => crm_get_template( 'layout/main.php', [ 'page' => 'crm/stock-store' ] ),
				'message' => 'محصول یافت نشد.',
				'status'  => 'error',
			];
			wp_send_json( $return );
		}
		$brand = crm_get_product_brand( $product );
		
		$args = [
			'sku'          => $product->get_sku(),
			'mode'         => 'in',
			'product_id'   => $product_id,
			'to_stock'     => $to_stock,
			'qty'          => $qty,
			'product_name' => $product->get_name(),
			'item_meta'    => [
				'brand' => $brand,
				'note'  => $_POST['note'],
			],
		];
		$this->kcp_stock->manual_stock_by_sku( $args );
		
		$return = [
			'main'    => crm_get_template( 'layout/main.php', [ 'page' => 'crm/stock-store' ] ),
			'message' => 'لاگ با موفقیت اضافه شد.',
			'status'  => 'success',
		];
		wp_send_json( $return );
	}
	
	public function add_production_request_log() {
		$product_id = $_POST['product_id'];
		$qty        = nooshika_sanitize_numbers( $_POST['count'] );
		$product    = wc_get_product( $product_id );
		if ( ! $product ) {
			$return = [
				'main'    => crm_get_template( 'layout/main.php', [ 'page' => 'crm/stock-store' ] ),
				'message' => 'محصول یافت نشد.',
				'status'  => 'error',
			];
			wp_send_json( $return );
		}
		
		$brand = crm_get_product_brand( $product );
		$this->kcp_stock->add_production_request( [
			'sku'          => $product->get_sku(),
			'count'        => $qty,
			'product_id'   => $product->get_id(),
			'product_name' => $product->get_name(),
			'process_meta' => [
				'brand'  => $brand,
				'source' => 'manual_production',
			],
			'item_meta'    => [
				'brand' => $brand,
				'note'  => $_POST['note'],
			],
		] );
		
		$return = [
			'main'    => crm_get_template( 'layout/main.php', [ 'page' => $_POST['page'] ] ),
			'message' => 'درخواست با موفقیت ثبت شد.',
			'status'  => 'success',
		];
		wp_send_json( $return );
	}
	
	public function stock_items_set_step() {
		$csv_items   = (string) ( $_POST['items'] ?? '' );              // مثال: "12, 15,28"
		$step_action = sanitize_key( (string) ( $_POST['step_action'] ?? '' ) );
		$page        = isset( $_POST['page'] ) ? sanitize_text_field( $_POST['page'] ) : '';
		$item_ids    = array_filter( array_map( function( $x ) {
			$x = trim( (string) $x );
			$x = nooshika_sanitize_numbers( $x );
			
			return absint( $x );
		}, explode( ',', $csv_items ) ) );
		
		if ( empty( $item_ids ) || $step_action === '' ) {
			$return = [
				'main'    => crm_get_template( 'layout/main.php', [ 'page' => $page ] ),
				'message' => 'ورودی نامعتبر است (آیتم یا اقدام خالی است).',
				'status'  => 'error',
			];
			wp_send_json( $return );
		}
		
		$apply_args = [
			'item_ids'  => $item_ids,
			'step_type' => $step_action,
		];
		switch ( $step_action ) {
			// --- تولید / QC ---
			case 're_produce_request':
			case 'request_production':
				$apply_args['set_stock']  = 'produce';
				$apply_args['set_status'] = 'in_production';
				
				$production_date = nooshika_sanitize_numbers( $_POST['production_date'] );
				if ( $production_date < 5 ) {
					$production_date += 2;
				} elseif ( $production_date < 11 ) {
					$production_date += 3;
				} elseif ( $production_date < 16 ) {
					$production_date += 4;
				} elseif ( $production_date < 26 ) {
					$production_date += 5;
				} else {
					$production_date += 7;
				}
				$apply_args['item_meta']['production_date'] = date( 'Y-m-d', strtotime( "+$production_date days" ) );
				break;
			case 'qccheck_requested':
				break;
			case 'qccheck_approved':
			case 'delivery_prepared':
				$apply_args['step_meta']['qcForm'] = $_POST['qcForm'];
				$apply_args['set_stock']           = 'deliver';
				break;
			case 'qccheck_rejected':
				$apply_args['step_meta']['qcForm'] = $_POST['qcForm'];
				
				$apply_args['set_status'] = 'rejected_qc';
				$apply_args['set_stock']  = 'refund';
				break;
			case 'manual_out':
				$apply_args['details'] = $_POST['manual_out_details'];
				
				$apply_args['set_status'] = 'get_out';
				$apply_args['set_stock']  = 'out';
				break;
			
			// --- انتقال ---
			case 'transfer_requested':
				$apply_args['set_stock']                = $_POST['target_stock'];
				$apply_args['step_meta']['destination'] = $_POST['target_stock'];
				break;
			case 'transfer_approved':
			case 'transfer_rejected':
				// بعداً اگر نیاز شد، مثلاً to_stock را همینجا از $_POST گرفته و به $apply_args['set_stock'] یا ['step_meta'] اضافه می‌کنیم
				break;
			
			// --- ارسال ---
			case 'accounting_approved':
				// --- تایید حسابداری ---
				break;
			case 'bill_of_lading_created':
				$apply_args['item_meta']['package_lading_code'] = $_POST['package_lading_code'];
				break;
			case 'product_delivered':
				$deliver_date                               = $_POST['deliver_date'];
				$apply_args['item_meta']['production_date'] = nooshika_jalali_to_gregorian( $deliver_date );
				$apply_args['set_stock']                    = 'delivered';
				$page                                       = '/crm/stock-warranty';
				break;
			
			// --- گارانتی ---
			case 'warranty_returned':
			case 'warranty_checked':
			case 'warranty_repaired':
			case 'warranty_rejected':
				// ورودی اضافه ندارد مگر بعداً اعلام کنید
				break;
			
			// --- اسقاط ---
			case 'scrap_requested':
			case 'scrap_confirmed':
				break;
			case 'print_barcode':
				$return = [
					'message'  => 'ارجاع به تب جدید',
					'status'   => 'success',
					'redirect' => home_url( '/crm?action=bill&type=barcode&items=' . $csv_items ),
				];
				wp_send_json( $return );
			case 'print_production_request':
				$return = [
					'message'  => 'ارجاع به تب جدید',
					'status'   => 'success',
					'redirect' => home_url( '/crm?action=bill&type=produce_req&items=' . $csv_items ),
				];
				wp_send_json( $return );
			default:
				$return = [
					'main'    => crm_get_template( 'layout/main.php', [ 'page' => $page ] ),
					'message' => 'اقدام ناشناخته است.',
					'status'  => 'error',
				];
				wp_send_json( $return );
		}
		$result = $this->kcp_stock->apply_step_to_items( $apply_args );
		
		$return = [
			'main'    => crm_get_template( 'layout/main.php', [ 'page' => $page ] ),
			'message' => 'عملیات با موفقیت اضافه شد.',
			'status'  => 'success',
			'result'  => $result,
		];
		wp_send_json( $return );
	}
	
	public function export_products() {
		$defaults = [
			'pa_brand'    => '',
			'product_cat' => '',
			'pa_size'     => '',
			'search'      => '',
			'page_number' => 1,
			'per_page'    => 200,
		];
		$args     = wp_parse_args( $_REQUEST, $defaults );
		$args     = array_map( fn( $v ) => $v == 0 ? '' : $v, $args );
		if ( ! is_current_user_admin() ) {
			$args['teacher_id'] = get_current_user_id();
		}
		$page_number = max( 1, (int) ( $args['page_number'] ?? 1 ) );
		$per_page    = max( 1, (int) ( $args['per_page'] ?? 200 ) );
		$offset      = ( $page_number - 1 ) * $per_page;
		extract( $args );
		$result = crm_get_products_list( compact( 'per_page', 'offset', 'pa_brand', 'product_cat',
			'pa_size', 'search' ) );
		$items  = [];
		$total  = 0;
		if ( isset( $result['product_ids'] ) ) {
			$items = (array) $result['product_ids'];
		}
		$total = isset( $result['total_products'] ) ? (int) $result['total_products'] : 0;
		
		$export_id = isset( $_POST['export_id'] ) && $_POST['export_id'] !== '' ? (int) $_POST['export_id'] : 0;
		
		$upload_dir = wp_upload_dir();
		$base_dir   = trailingslashit( $upload_dir['basedir'] ) . 'kasebi-export';
		$base_url   = trailingslashit( $upload_dir['baseurl'] ) . 'kasebi-export';
		
		if ( ! is_dir( $base_dir ) ) {
			wp_mkdir_p( $base_dir );
		}
		
		if ( ! $export_id ) {
			$creator  = get_current_user_id();
			$filename = 'export_products_' . date( 'Y-m-d_H-i-s' ) . '_' . wp_generate_password( 6, FALSE, FALSE );
			
			$file_path = $base_dir . '/' . $filename . '.csv';
			$file_url  = $base_url . '/' . $filename . '.csv';
			
			// ساخت فایل و نوشتن هدرها (اگر دیتایی هست)
			$fh = fopen( $file_path, 'w' );
			if ( ! $fh ) {
				wp_send_json( [
					'status'  => 'error',
					'message' => 'Cannot create export file.',
				] );
			}
			if ( ! empty( $items ) ) {
				fwrite( $fh, "\xEF\xBB\xBF" );
				$headers = [
					'product_id',
					'product_title',
					'category',
					'brand',
					'qty',
				];
				
				fputcsv( $fh, $headers );
				foreach ( $items as $row ) {
					fputcsv( $fh, $this->normalize_csv_row( $row ) );
				}
			}
			
			fclose( $fh );
			$log       = $this->kcp_db->create_export_log( $creator, $file_url, $file_path, $args );
			$export_id = (int) ( $log['export_id'] ?? 0 );
			
			if ( ! $export_id ) {
				wp_send_json( [
					'status'  => 'error',
					'message' => 'Cannot create export log.',
				] );
			}
		} else {
			$log = $this->kcp_db->get_export_log( $export_id );
			if ( ! $log ) {
				wp_send_json( [
					'status'  => 'error',
					'message' => 'Export log not found.',
				] );
			}
			$file_path = (string) ( $log['file_path'] ?? '' );
			$file_url  = (string) ( $log['file_url'] ?? '' );
			
			if ( empty( $file_path ) || ! file_exists( $file_path ) ) {
				wp_send_json( [
					'status'  => 'error',
					'message' => 'Export file is missing.',
				] );
			}
			
			if ( ! empty( $items ) ) {
				$fh = fopen( $file_path, 'a' );
				if ( ! $fh ) {
					wp_send_json( [
						'status'  => 'error',
						'message' => 'Cannot open export file for append.',
					] );
				}
				
				// هدرها را از فایل موجود می‌خوانیم تا ترتیب ستون‌ها ثابت بماند
				$headers = $this->read_csv_headers( $file_path );
				if ( empty( $headers ) ) {
					// اگر به هر دلیل نبود، از کلیدهای آیتم اول بساز (fallback)
					$headers = array_keys( (array) $items[0] );
					// و همان‌جا اضافه کن تا فایل خراب نشود
					fputcsv( $fh, $headers );
				}
				
				foreach ( $items as $row ) {
					fputcsv( $fh, $this->normalize_csv_row( $row, $headers ) );
				}
				
				fclose( $fh );
			}
		}
		$done_count = $total > 0 ? min( $page_number * $per_page, $total ) : ( empty( $items ) ? 0 : ( $page_number * $per_page ) );
		$percent    = $total > 0 ? (int) floor( ( $done_count / $total ) * 100 ) : ( empty( $items ) ? 100 : 100 );
		$finished   = ( $total === 0 ) ? TRUE : ( $done_count >= $total );
		$next_page  = $page_number + 1;
		
		if ( $finished ) {
			$xls_url = NULL;
			
			// اگر PhpSpreadsheet نصب بود، XLSX هم بساز
			if ( class_exists( '\PhpOffice\PhpSpreadsheet\Spreadsheet' ) ) {
				$xls_url = $this->make_xlsx_from_csv( $file_path, $base_dir, $base_url );
			}
			
			wp_send_json( [
				'status'    => 'finished',
				'export_id' => $export_id,
				'percent'   => 100,
				'csv'       => $file_url,
				'xls'       => $xls_url ?: $file_url, // در صورت نبود XLSX، همان CSV را بده
			] );
		}
		
		wp_send_json( [
			'status'    => 'running',
			'export_id' => $export_id,
			'percent'   => max( 1, $percent ), // حداقل کمی حرکت نشان دهیم
			'next_page' => $next_page,
			'csv'       => $file_url,
		] );
	}
	
	private function normalize_csv_row( $product_id ): array {
		$parent_id = wp_get_post_parent_id( $product_id ) ?: $product_id;
		$category  = wp_get_post_terms( $parent_id, 'product_cat', [ 'fields' => 'names' ] );
		$category  = is_wp_error( $category ) ? [] : $category;
		$category  = implode( ' - ', $category );
		$brand     = wp_get_post_terms( $parent_id, 'pa_brand', [ 'fields' => 'names' ] );
		$brand     = is_wp_error( $brand ) ? [] : $brand;
		$brand     = implode( ' - ', $brand );
		
		return [
			$product_id,
			get_the_title( $product_id ),
			$category,
			$brand,
			0,
		];
	}
	
	private function read_csv_headers( string $file_path ): array {
		$fh = fopen( $file_path, 'r' );
		if ( ! $fh ) {
			return [];
		}
		
		$first = fgets( $fh );
		if ( $first === FALSE ) {
			fclose( $fh );
			
			return [];
		}
		rewind( $fh );
		$start = fread( $fh, 3 );
		if ( $start !== "\xEF\xBB\xBF" ) {
			rewind( $fh );
		}
		
		$headers = fgetcsv( $fh );
		fclose( $fh );
		
		return is_array( $headers ) ? $headers : [];
	}
	
	public function crm_import_qty() {
		$items    = $_POST['data'];
		$to_stock = 'store';
		foreach ( $items as $data ) {
			$product_id = $data['product_id'];
			$qty        = $data['qty'];
			$product    = wc_get_product( $product_id );
			if ( ! $product ) {
				continue;
			}
			$brand = crm_get_product_brand( $product );
			
			$args = [
				'sku'          => $product->get_sku(),
				'mode'         => 'in',
				'product_id'   => $product_id,
				'to_stock'     => $to_stock,
				'qty'          => $qty,
				'product_name' => $product->get_name(),
				'item_meta'    => [
					'brand' => $brand,
					'note'  => 'ایمپورت دستی',
				],
			];
			$this->kcp_stock->manual_stock_by_sku( $args );
		}
		wp_send_json( [] );
	}
	
	public function add_option_item() {
		extract( $_POST );
		$options_list           = get_option( $option ) ?: [];
		$options_list           = is_array( $options_list ) ? $options_list : [];
		$options_list[ $index ] = [
			'label' => $label,
		];
		update_option( $option, $options_list );
		$return = [
			'main'    => crm_get_template( 'layout/main.php', [ 'page' => $page ] ),
			'status'  => 'success',
			'message' => 'آیتم با موفقیت ثبت شد.',
		];
		wp_send_json( $return );
	}
	
	public function delete_option_item() {
		extract( $_POST );
		$options_list = get_option( $tab ) ?: [];
		$options_list = is_array( $options_list ) ? $options_list : [];
		unset( $options_list[ $item_id ] );
		update_option( $tab, $options_list );
		$return = [
			'main'    => crm_get_template( 'layout/main.php', [ 'page' => $page ] ),
			'status'  => 'success',
			'message' => 'آیتم با موفقیت حذف شد.',
		];
		wp_send_json( $return );
	}
	
	private function clean_price_value( $value ): string {
		$value = isset( $value ) ? wp_unslash( $value ) : '';
		$value = trim( (string) $value );
		
		if ( $value === '' ) {
			return '';
		}
		
		if ( function_exists( 'nooshika_sanitize_numbers' ) ) {
			$value = nooshika_sanitize_numbers( $value );
		}
		
		$value = str_replace( [ ',', '،', ' ' ], '', $value );
		$value = preg_replace( '/[^0-9.]/', '', $value );
		
		if ( $value === '' ) {
			return '';
		}
		
		return wc_format_decimal( $value );
	}
	
	public function add_product() {
		if ( ! current_user_can( 'manage_woocommerce' ) && ! current_user_can( 'manage_options' ) ) {
			wp_send_json( [
				'status'  => 'error',
				'message' => 'دسترسی کافی ندارید.',
			] );
		}
		
		$page       = isset( $_POST['page'] ) ? sanitize_text_field( wp_unslash( $_POST['page'] ) ) : '/crm/settings-products';
		$product_id = isset( $_POST['product_id'] ) ? absint( wp_unslash( $_POST['product_id'] ) ) : 0;
		
		$title      = isset( $_POST['title'] ) ? sanitize_text_field( wp_unslash( $_POST['title'] ) ) : '';
		$price      = $this->clean_price_value( $_POST['price'] ?? '' );
		$sale_price = $this->clean_price_value( $_POST['sale_price'] ?? '' );
		
		if ( ! $title ) {
			wp_send_json( [
				'status'  => 'error',
				'message' => 'عنوان محصول الزامی است.',
			] );
		}
		
		if ( $price === '' ) {
			wp_send_json( [
				'status'  => 'error',
				'message' => 'قیمت اصلی محصول الزامی است.',
			] );
		}
		
		if ( $sale_price !== '' && (float) $sale_price > (float) $price ) {
			wp_send_json( [
				'status'  => 'error',
				'message' => 'قیمت فروش ویژه نمی‌تواند بیشتر از قیمت اصلی باشد.',
			] );
		}
		
		if ( $product_id > 0 ) {
			$product = wc_get_product( $product_id );
			
			if ( ! $product ) {
				wp_send_json( [
					'status'  => 'error',
					'message' => 'محصول انتخاب‌شده معتبر نیست.',
				] );
			}
		} else {
			$product = new WC_Product_Simple();
			$product->set_status( 'publish' );
			$product->set_catalog_visibility( 'visible' );
		}
		
		$product->set_name( $title );
		$product->set_regular_price( $price );
		
		if ( $sale_price !== '' ) {
			$product->set_sale_price( $sale_price );
			$product->set_price( $sale_price );
		} else {
			$product->set_sale_price( '' );
			$product->set_price( $price );
		}
		
		$product->save();
		
		$message = $product_id > 0 ? 'محصول ویرایش شد.' : 'محصول اضافه شد.';
		
		$return = [
			'main'    => crm_get_template( 'layout/main.php', [ 'page' => $page ] ),
			'status'  => 'success',
			'message' => $message,
		];
		
		wp_send_json( $return );
	}
	
	public function trash_product() {
		if ( ! current_user_can( 'manage_woocommerce' ) && ! current_user_can( 'manage_options' ) ) {
			wp_send_json( [
				'status'  => 'error',
				'message' => 'دسترسی کافی ندارید.',
			] );
		}
		
		$product_id = isset( $_POST['item_id'] ) ? absint( wp_unslash( $_POST['item_id'] ) ) : 0;
		$page       = isset( $_POST['page'] ) ? sanitize_text_field( wp_unslash( $_POST['page'] ) ) : '/crm/settings-products';
		
		if ( ! $product_id ) {
			wp_send_json( [
				'status'  => 'error',
				'message' => 'شناسه محصول معتبر نیست.',
			] );
		}
		
		$product = wc_get_product( $product_id );
		
		if ( ! $product ) {
			wp_send_json( [
				'status'  => 'error',
				'message' => 'محصول یافت نشد.',
			] );
		}
		
		$trashed = wp_trash_post( $product_id );
		
		if ( ! $trashed ) {
			wp_send_json( [
				'status'  => 'error',
				'message' => 'حذف محصول انجام نشد.',
			] );
		}
		
		$return = [
			'main'    => crm_get_template( 'layout/main.php', [ 'page' => $page ] ),
			'status'  => 'success',
			'message' => 'محصول حذف شد.',
		];
		
		wp_send_json( $return );
	}
	
	public function delete_order() {
		if ( ! current_user_can( 'manage_woocommerce' ) && ! current_user_can( 'manage_options' ) ) {
			wp_send_json( [
				'status'  => 'error',
				'message' => 'دسترسی کافی ندارید.',
			] );
		}
		
		$order_id = isset( $_POST['item_id'] ) ? absint( wp_unslash( $_POST['item_id'] ) ) : 0;
		$page     = isset( $_POST['page'] ) ? sanitize_text_field( wp_unslash( $_POST['page'] ) ) : '/crm/sale-orders';
		if ( ! $order_id ) {
			wp_send_json( [
				'main'    => crm_get_template( 'layout/main.php', [ 'page' => $page ] ),
				'status'  => 'error',
				'message' => 'شناسه سفارش معتبر نیست.',
				'url'     => home_url( '/' . $page ),
			] );
		}
		
		$order = wc_get_order( $order_id );
		
		if ( ! $order ) {
			wp_send_json( [
				'main'    => crm_get_template( 'layout/main.php', [ 'page' => $page ] ),
				'status'  => 'error',
				'message' => 'سفارش مورد نظر یافت نشد.',
				'url'     => home_url( '/' . $page ),
			] );
		}
		
		/**
		 * اگر می‌خواهی سفارش مستقیم کامل حذف شود:
		 * true = force delete
		 *
		 * اگر می‌خواهی فقط به زباله‌دان منتقل شود:
		 * false بگذار.
		 */
		$deleted = $order->delete( TRUE );
		
		if ( ! $deleted ) {
			wp_send_json( [
				'main'    => crm_get_template( 'layout/main.php', [ 'page' => $page ] ),
				'status'  => 'error',
				'message' => 'حذف سفارش با خطا مواجه شد.',
				'url'     => home_url( '/' . $page ),
			] );
		}
		
		$return = [
			'main'    => crm_get_template( 'layout/main.php', [ 'page' => $page ] ),
			'status'  => 'success',
			'message' => 'سفارش حذف شد.',
		];
		
		wp_send_json( $return );
	}
	
    public function change_users_marketer() {
        if ( ! kcp_can_assign_customers() ) {
            wp_send_json( [ 'status' => 'error', 'message' => 'اجازه تغییر کارشناس مشتری را ندارید.' ] );
        }
        $nonce = $_POST['assignment_nonce'] ?? '';
        if ( ! is_string( $nonce ) || ! wp_verify_nonce( wp_unslash( $nonce ), 'kcp_customer_assignment' ) ) {
            wp_send_json( [ 'status' => 'error', 'message' => 'اعتبار درخواست تمام شده؛ صفحه را تازه کنید.' ] );
        }
        $ids = $_POST['user_ids'] ?? [];
        $agent = $_POST['marketer'] ?? '';
        $type = $_POST['assignment_type'] ?? ( ( $_POST['action'] ?? '' ) === 'crm_change_users_marketer' ? 'in_person' : '' );
        $valid = kcp_validate_customer_assignment( $ids, $agent, $type );
        if ( is_wp_error( $valid ) ) {
            wp_send_json( [ 'status' => 'error', 'message' => $valid->get_error_message() ] );
        }
        $config = kcp_sales_assignment_types()[ $type ];
        $failed = FALSE;
        foreach ( array_unique( array_map( 'intval', $ids ) ) as $id ) {
            $previous = (int) get_user_meta( $id, $config['meta'], TRUE );
            if ( $previous === (int) $agent ) {
                continue;
            }
            if ( ! update_user_meta( $id, $config['meta'], (int) $agent ) ) {
                $failed = TRUE;
                continue;
            }
            add_user_meta( $id, $config['history'], [
                'type' => $type,
                'from' => $previous, 'to' => (int) $agent,
                'by' => get_current_user_id(), 'at' => current_time( 'mysql', TRUE ),
            ] );
        }
        wp_send_json( [
            'status' => $failed ? 'error' : 'success',
            'message' => $failed ? 'ذخیره بعضی مشتری‌ها انجام نشد؛ صفحه را تازه کنید و دوباره بررسی کنید.' : $config['label'] . ' مشتری‌ها ذخیره شد.',
        ] );
    }
    
	public function save_user_location() {
		$user_id = isset( $_POST['id'] ) ? absint( wp_unslash( $_POST['id'] ) ) : 0;
		$page    = isset( $_POST['page'] ) ? sanitize_text_field( wp_unslash( $_POST['page'] ) ) : '/crm/user';
		
		$lat = isset( $_POST['lat'] )
			? sanitize_text_field( wp_unslash( $_POST['lat'] ) )
			: '';
		
		$lng = isset( $_POST['lng'] )
			? sanitize_text_field( wp_unslash( $_POST['lng'] ) )
			: '';
		
		$lat = trim( $lat );
		$lng = trim( $lng );
		
		$lat_float = (float) $lat;
		$lng_float = (float) $lng;
		
		if (
			$lat_float < - 90 ||
			$lat_float > 90 ||
			$lng_float < - 180 ||
			$lng_float > 180
		) {
			wp_send_json( [
				'status'  => 'error',
				'message' => 'لوکیشن نامعتبر است.',
			] );
		}
		
		update_user_meta( $user_id, 'kasebi_user_lat', $lat_float );
		update_user_meta( $user_id, 'kasebi_user_lng', $lng_float );
		
		$return = [
			'main'    => crm_get_template( 'layout/main.php', [ 'page' => $page ] ),
			'status'  => 'success',
			'message' => 'لوکیشن ذخیره شد.',
		];
		
		wp_send_json( $return );
	}
	
	/*
	 * helper functions
	 */
}
