<?php

class kcp_stock {
	
	private string $db_prefix;
	private string $db_charset;
	private wpdb   $db;
	
	private string $stock_process;
	private string $stock_items;
	private string $stock_item_step_log;
	private string $stock_process_meta;
	private string $stock_items_meta;
	private string $stock_item_step_log_meta;
	
	public function __construct() {
		global $wpdb;
		$this->db         = $wpdb;
		$this->db_prefix  = $this->db->prefix . 'kcp_';
		$this->db_charset = $this->db->get_charset_collate();
		
		$this->stock_process            = $this->db_prefix . 'stock_process';
		$this->stock_items              = $this->db_prefix . 'stock_items';
		$this->stock_item_step_log      = $this->db_prefix . 'stock_item_step_log';
		$this->stock_process_meta       = $this->db_prefix . 'stock_process_meta';
		$this->stock_items_meta         = $this->db_prefix . 'stock_items_meta';
		$this->stock_item_step_log_meta = $this->db_prefix . 'stock_item_step_log_meta';
		
		$this->create_main_table();
	}
	
	public function create_main_table(): void {
		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
		
		maybe_create_table( $this->stock_process, $this->get_stock_process_table_query() );
		maybe_create_table( $this->stock_items, $this->get_stock_items_table_query() );
		maybe_create_table( $this->stock_item_step_log, $this->get_stock_item_step_log_table_query() );
		maybe_create_table( $this->stock_process_meta, $this->get_meta_table_query( $this->stock_process_meta, 'process_id' ) );
		maybe_create_table( $this->stock_items_meta, $this->get_meta_table_query( $this->stock_items_meta, 'item_id' ) );
		maybe_create_table( $this->stock_item_step_log_meta, $this->get_meta_table_query( $this->stock_item_step_log_meta, 'step_id' ) );
	}
	
	private function get_stock_process_table_query() {
		return <<<SQL
			CREATE TABLE {$this->stock_process} (
				process_id     MEDIUMINT NOT NULL AUTO_INCREMENT,
				type           VARCHAR(64) NOT NULL,              -- production / transfer / delivery / send / manual
				from_stock     VARCHAR(64),                       -- مبدأ
				to_stock       VARCHAR(64),                       -- مقصد
				creator_id     MEDIUMINT NOT NULL,
				product_id     MEDIUMINT,                         -- اختیاری
				sku            VARCHAR(255),                      -- اختیاری
				product_name   VARCHAR(255),                      -- اختیاری
				order_id       MEDIUMINT,
				io_type        ENUM('in','out') NOT NULL,         -- ورود یا خروج کلی این فرآیند
				date_created   DATETIME NOT NULL,
				date_updated   DATETIME,
				PRIMARY KEY (process_id)
			) {$this->db_charset};
		SQL;
	}
	
	private function get_stock_items_table_query() {
		return <<<SQL
			CREATE TABLE {$this->stock_items} (
				item_id      MEDIUMINT NOT NULL AUTO_INCREMENT,
				process_id   MEDIUMINT NOT NULL,                  -- وابسته به stock_process
				product_id   MEDIUMINT,                         -- اختیاری
				sku          VARCHAR(255) NOT NULL,
				product_name VARCHAR(255),                      -- اختیاری
				serial       VARCHAR(255) NOT NULL UNIQUE,        -- سریال یونیک هر کالا
				status       VARCHAR(64) NOT NULL,                -- وضعیت فعلی کالا (مثلاً: pending, approved, rejected, delivered, ...)
				current_stock VARCHAR(64) NOT NULL,               -- در کدام انبار است
				last_step_type VARCHAR(64) NOT NULL,               -- در کدام انبار است
				last_step_date DATETIME NOT NULL,
				date_created DATETIME NOT NULL,
				date_updated DATETIME,
				PRIMARY KEY (item_id)
			) {$this->db_charset};
		SQL;
	}
	
	private function get_stock_item_step_log_table_query() {
		return <<<SQL
			CREATE TABLE {$this->stock_item_step_log} (
				step_id     MEDIUMINT NOT NULL AUTO_INCREMENT,
				item_id     MEDIUMINT NOT NULL,                   -- وابسته به stock_items
				process_id  MEDIUMINT NOT NULL,                   -- وابسته به stock_process ← جهت گزارش‌گیری بهتر
				user_id     MEDIUMINT NOT NULL,
				step_type   VARCHAR(64) NOT NULL,                 -- request / approve / reject / deliver / qccheck / note / attachment / ...
				details     TEXT,
				attachment  VARCHAR(255),
				date        DATETIME NOT NULL,
				PRIMARY KEY (step_id)
			) {$this->db_charset};
		SQL;
	}
	
	private function get_meta_table_query( string $table_name, string $foreign_key ): string {
		return <<<SQL
			CREATE TABLE {$table_name} (
				id INT NOT NULL AUTO_INCREMENT,
				{$foreign_key} INT NOT NULL,
				meta_key VARCHAR(255) NOT NULL,
				meta_value LONGTEXT,
				PRIMARY KEY (id)
			) {$this->db_charset};
		SQL;
	}
	
	public function get_warehouse_stocks(): array {
		return [
			'produce'   => [
				'label' => 'انبار تولید',
				'class' => 'bg-azure',
			],
			'store'     => [
				'label' => 'انبار فروشگاه',
				'class' => 'bg-success',
			],
			'vitrine'   => [
				'label' => 'ویترین',
				'class' => 'bg-info',
			],
			'deliver'   => [
				'label' => 'انبار تحویل کالا',
				'class' => 'bg-warning',
			],
			'refund'    => [
				'label' => 'مرجوعی',
				'class' => 'bg-danger',
			],
			'delivered' => [
				'label' => 'تحویل داده شده',
				'class' => 'bg-gray',
			],
			'scrap'     => [
				'label' => 'انبار اسقاط',
				'class' => 'bg-dark',
			],
			'out'       => [
				'label' => 'انبار خارج شده',
				'class' => 'bg-dark',
			],
		];
	}
	
	public function get_stock_process_types(): array {
		return [
			'production' => [
				'label' => 'تولید',
				'class' => 'bg-primary',
			],
			'transfer'   => [
				'label' => 'انتقال بین انبارها',
				'class' => 'bg-info',
			],
			'delivery'   => [
				'label' => 'تحویل به مشتری',
				'class' => 'bg-success',
			],
			'send'       => [
				'label' => 'ارسال کالا',
				'class' => 'bg-warning',
			],
			'manual_in'  => [
				'label' => 'ورود دستی',
				'class' => 'bg-secondary',
			],
			'manual_out' => [
				'label' => 'خروج دستی',
				'class' => 'bg-secondary',
			],
			'refund'     => [
				'label' => 'مرجوعی مشتری',
				'class' => 'bg-danger',
			],
			'warranty'   => [
				'label' => 'گارانتی/تعمیر',
				'class' => 'bg-dark',
			],
			'scrap'      => [
				'label' => 'انتقال به اسقاط',
				'class' => 'bg-light text-dark',
			],
		];
	}
	
	public function get_stock_item_statuses(): array {
		return [
			'pending'       => [
				'label' => 'در انتظار اقدام',
				'class' => 'bg-pink',
			],
			'in_production' => [
				'label' => 'در حال تولید',
				'class' => 'bg-azure',
			],
			'produced'      => [
				'label' => 'آماده',
				'class' => 'bg-success',
			],
			'delivering'    => [
				'label' => 'نیاز به ارسال',
				'class' => 'bg-info',
			],
			'delivered'     => [
				'label' => 'تحویل داده شده',
				'class' => 'bg-teal',
			],
			'returned'      => [
				'label' => 'مرجوعی',
				'class' => 'bg-warning',
			],
			'in_warranty'   => [
				'label' => 'در حال بررسی گارانتی',
				'class' => 'bg-dark',
			],
			'rejected_qc'   => [
				'label' => 'رد شده توسط QC',
				'class' => 'bg-danger',
			],
			'scrapped'      => [
				'label' => 'منتقل شده به اسقاط',
				'class' => 'bg-gray',
			],
			'get_out'       => [
				'label' => 'خارج شده',
				'class' => 'bg-gray',
			],
			'rejected'      => [
				'label' => 'لغو شده',
				'class' => 'bg-danger',
			],
		];
	}
	
	public function get_stock_item_step_types(): array {
		return [
			// عمومی
			'request_production'     => [
				'label' => 'درخواست تولید',
				'class' => 'bg-info',
				'needs' => [
					[
						'type'  => 'text',
						'label' => 'فاصله روز تا تحویل',
						'key'   => 'production_date',
					],
				],
			],
			'order_cancelled'        => [
				'label' => 'لغو تولید به دلیل لغو سفارش',
				'class' => 'bg-danger',
			],
			'qccheck_requested'      => [
				'label' => 'ارجاع به کنترل کیفی',
				'class' => 'bg-warning',
			],
			'qccheck_approved'       => [
				'label' => 'تأیید کنترل کیفی',
				'class' => 'bg-success',
				'needs' => [
					[
						'type'       => 'modal',
						'modalId'    => 'qcFormModal',
						'itemsInput' => 'submit_qc_form_item_ids',
						'step'       => 'qccheck_approved',
					],
				],
			],
			'qccheck_rejected'       => [
				'label' => 'رد کنترل کیفی',
				'class' => 'bg-danger',
				'needs' => [
					[
						'type'       => 'modal',
						'modalId'    => 'qcFormModal',
						'itemsInput' => 'submit_qc_form_item_ids',
					],
				],
			],
			
			// ورود/خروج دستی
			'manual_in'              => [
				'label' => 'ورود دستی',
				'class' => 'bg-secondary',
			],
			'manual_out'             => [
				'label' => 'خروج دستی',
				'class' => 'bg-secondary',
				'needs' => [
					[
						'type'  => 'textarea',
						'label' => 'توضیحات',
						'key'   => 'manual_out_details',
					],
				],
			],
			
			// انتقالات بین انبارها
			'transfer_requested'     => [
				'label' => 'انتقال به انبار دیگر',
				'class' => 'bg-info',
				'needs' => [
					[
						'type'    => 'select',
						'label'   => 'انبار مقصد',
						'key'     => 'target_stock',
						'options' => [
							[
								'id'    => 'vitrine',
								'label' => 'ویترین',
							],
							[
								'id'    => 'store',
								'label' => 'فروشگاه',
							],
						],
					],
				],
			],
			'transfer_approved'      => [
				'label' => 'تأیید انتقال',
				'class' => 'bg-success',
			],
			'transfer_rejected'      => [
				'label' => 'رد انتقال',
				'class' => 'bg-danger',
			],
			
			// تحویل کالا
			'delivery_prepared'      => [
				'label' => 'آماده‌سازی برای ارسال',
				'class' => 'bg-info',
				'needs' => [
					[
						'type'       => 'modal',
						'modalId'    => 'qcFormModal',
						'itemsInput' => 'submit_qc_form_item_ids',
						'step'       => 'delivery_prepared',
					],
				],
			],
			'accounting_approved'    => [
				'label' => 'تایید حسابداری',
				'class' => 'bg-primary',
			],
			'bill_of_lading_created' => [
				'label' => 'صدور حواله',
				'class' => 'bg-primary',
				'needs' => [
					[
						'type'  => 'text',
						'label' => 'کد مرسوله',
						'key'   => 'package_lading_code',
					],
				],
			],
			'product_delivered'      => [
				'label' => 'تحویل به مشتری',
				'class' => 'bg-success',
				'needs' => [
					[
						'type'  => 'date',
						'label' => 'تاریخ تحویل',
						'key'   => 'deliver_date',
					],
				],
			],
			
			// مرجوعی / گارانتی
			'warranty_returned'      => [
				'label' => 'مرجوعی تحت گارانتی',
				'class' => 'bg-warning',
			],
			'warranty_repaired'      => [
				'label' => 'تعمیر و برگشت به مشتری',
				'class' => 'bg-success',
			],
			'warranty_rejected'      => [
				'label' => 'گارانتی ردشده',
				'class' => 'bg-danger',
			],
			'scrap_requested'        => [
				'label' => 'درخواست اسقاط',
				'class' => 'bg-secondary',
			],
			're_produce_request'     => [
				'label' => 'درخواست باز تولید',
				'class' => 'bg-info',
				'needs' => [
					[
						'type'  => 'date',
						'label' => 'تاریخ اعلامی تولید کننده',
						'key'   => 'production_date',
					],
				],
			],
			'scrap_confirmed'        => [
				'label' => 'تأیید اسقاط',
				'class' => 'bg-dark',
			],
		];
	}
	
	/**
	 * Resolve meta table + foreign key column by context.
	 * $context: 'process' | 'item' | 'step'
	 */
	private function resolve_meta_table( string $context ): array {
		switch ( $context ) {
			case 'process':
				return [
					'table' => $this->stock_process_meta,
					'col'   => 'process_id',
				];
			case 'item':
				return [
					'table' => $this->stock_items_meta,
					'col'   => 'item_id',
				];
			case 'step':
				return [
					'table' => $this->stock_item_step_log_meta,
					'col'   => 'step_id',
				];
			default:
				throw new InvalidArgumentException( 'Invalid meta context' );
		}
	}
	
	/**
	 * Get meta values.
	 *
	 * @param   string  $context   'process'|'item'|'step'
	 * @param   int     $object_id
	 * @param   string  $meta_key  optional
	 * @param   bool    $single    if true, returns first value (or null)
	 *
	 * @return mixed            array|scalar|null
	 */
	public function get_meta( string $context, int $object_id, string $meta_key = '', bool $single = FALSE ) {
		$m = $this->resolve_meta_table( $context );
		
		if ( $meta_key !== '' ) {
			$rows = $this->db->get_col(
				$this->db->prepare(
					"SELECT meta_value FROM {$m['table']} WHERE {$m['col']} = %d AND meta_key = %s ORDER BY id ASC",
					$object_id, $meta_key
				)
			);
			if ( empty( $rows ) ) {
				return $single ? NULL : [];
			}
			$vals = array_map( 'maybe_unserialize', $rows );
			
			return $single ? $vals[0] : $vals;
		}
		
		// All metas for the object
		$rows = $this->db->get_results(
			$this->db->prepare(
				"SELECT meta_key, meta_value FROM {$m['table']} WHERE {$m['col']} = %d ORDER BY id ASC",
				$object_id
			),
			ARRAY_A
		);
		
		if ( empty( $rows ) ) {
			return [];
		}
		
		$out = [];
		foreach ( $rows as $r ) {
			$k = $r['meta_key'];
			$v = maybe_unserialize( $r['meta_value'] );
			if ( isset( $out[ $k ] ) ) {
				// normalize to array if duplicated keys exist
				if ( ! is_array( $out[ $k ] ) || array_keys( $out[ $k ] ) === range( 0, count( $out[ $k ] ) - 1 ) ) {
					$out[ $k ] = (array) $out[ $k ];
				}
				$out[ $k ][] = $v;
			} else {
				$out[ $k ] = $v;
			}
		}
		
		return $out;
	}
	
	/**
	 * Update/Insert/Delete meta.
	 *
	 * @param   string      $context     'process'|'item'|'step'
	 * @param   int         $object_id
	 * @param   string      $meta_key
	 * @param   mixed|null  $meta_value  if NULL → delete (all rows for this key)
	 * @param   bool        $unique      if TRUE update first row or insert; if FALSE insert new row
	 *
	 * @return bool
	 */
	public function update_meta( string $context, int $object_id, string $meta_key, $meta_value, bool $unique = TRUE ): bool {
		$m = $this->resolve_meta_table( $context );
		
		// Delete
		if ( $meta_value === NULL ) {
			$deleted = $this->db->delete(
				$m['table'],
				[
					$m['col']  => $object_id,
					'meta_key' => $meta_key,
				],
				[
					'%d',
					'%s',
				]
			);
			
			return $deleted !== FALSE;
		}
		
		$serialized = maybe_serialize( $meta_value );
		
		if ( $unique ) {
			$existing_id = (int) $this->db->get_var(
				$this->db->prepare(
					"SELECT id FROM {$m['table']} WHERE {$m['col']} = %d AND meta_key = %s ORDER BY id ASC LIMIT 1",
					$object_id, $meta_key
				)
			);
			
			if ( $existing_id > 0 ) {
				$ok = $this->db->update(
					$m['table'],
					[ 'meta_value' => $serialized ],
					[ 'id' => $existing_id ],
					[ '%s' ],
					[ '%d' ]
				);
				
				return $ok !== FALSE;
			}
			
			$ok = $this->db->insert(
				$m['table'],
				[
					$m['col']    => $object_id,
					'meta_key'   => $meta_key,
					'meta_value' => $serialized,
				],
				[
					'%d',
					'%s',
					'%s',
				]
			);
			
			return (bool) $ok;
		}
		
		// Non-unique: insert another row
		$ok = $this->db->insert(
			$m['table'],
			[
				$m['col']    => $object_id,
				'meta_key'   => $meta_key,
				'meta_value' => $serialized,
			],
			[
				'%d',
				'%s',
				'%s',
			]
		);
		
		return (bool) $ok;
	}
	
	public function get_stock_item_current_step( int $item_id ): array {
		if ( $item_id <= 0 ) {
			return [
				'current_step'       => 'نامشخص',
				'current_step_label' => 'نامشخص',
				'warehouse'          => 'نامشخص',
				'warehouse_label'    => 'نامشخص',
				'status'             => 'نامشخص',
				'status_label'       => 'نامشخص',
				'process_id'         => NULL,
			];
		}
		
		// اطلاعات آیتم شامل وضعیت و انبار
		$item = $this->db->get_row( $this->db->prepare(
			"SELECT status, current_stock FROM {$this->stock_items} WHERE item_id = %d",
			$item_id
		), ARRAY_A );
		
		if ( empty( $item ) ) {
			return [
				'current_step'       => 'یافت نشد',
				'current_step_label' => 'یافت نشد',
				'warehouse'          => 'نامشخص',
				'warehouse_label'    => 'نامشخص',
				'status'             => 'یافت نشد',
				'status_label'       => 'یافت نشد',
				'process_id'         => NULL,
			];
		}
		
		$current_stock = $item['current_stock'];
		$status        = $item['status'];
		$step          = $this->db->get_row( $this->db->prepare(
			"SELECT step_type, process_id
		 FROM {$this->stock_item_step_log}
		 WHERE item_id = %d
		 ORDER BY date DESC, step_id DESC
		 LIMIT 1",
			$item_id
		), ARRAY_A );
		
		$step_type  = $step['step_type'] ?? 'بدون اقدام';
		$process_id = $step['process_id'] ?? NULL;
		
		$step_types = $this->get_stock_item_step_types();
		$step_label = $step_types[ $step_type ]['label'] ?? $step_type;
		
		$warehouses      = $this->get_warehouse_stocks();
		$warehouse_label = $warehouses[ $current_stock ]['label'] ?? $current_stock;
		
		$status_labels = $this->get_stock_item_statuses();
		$status_label  = $status_labels[ $status ]['label'] ?? $status;
		
		return [
			'current_step'       => $step_type,
			'current_step_label' => $step_label,
			'warehouse'          => $current_stock,
			'warehouse_label'    => $warehouse_label,
			'status'             => $status,
			'status_label'       => $status_label,
			'process_id'         => $process_id,
		];
	}
	
	public function get_product_stock_in_warehouse( array $args = [] ): int {
		$defaults = [
			'product_id' => 0,
			// شناسه محصول (اجباری نیست اگر sku استفاده شود)
			'sku'        => '',
			// کد SKU محصول
			'status'     => 'produced',
			// وضعیت پیشفرض: آماده
			'stock'      => 'store',
			// انبار پیشفرض: فروشگاه
		];
		
		$args = wp_parse_args( $args, $defaults );
		
		$where  = [ '1=1' ];
		$params = [];
		
		if ( ! empty( $args['product_id'] ) ) {
			$where[]  = 'product_id = %d';
			$params[] = $args['product_id'];
		}
		
		if ( ! empty( $args['sku'] ) ) {
			$where[]  = 'sku = %s';
			$params[] = $args['sku'];
		}
		
		if ( ! empty( $args['status'] ) ) {
			$where[]  = 'status = %s';
			$params[] = $args['status'];
		}
		
		if ( ! empty( $args['stock'] ) ) {
			$where[]  = 'current_stock = %s';
			$params[] = $args['stock'];
		}
		
		$sql = "SELECT COUNT(*) FROM {$this->stock_items} WHERE " . implode( ' AND ', $where );
		
		return (int) $this->db->get_var( $this->db->prepare( $sql, $params ) );
	}
	
	/**
	 * ایجاد فرآیند جدید و الصاق آیتم‌ها
	 * - اگر args['items'] خالی نباشد: از همان آیتم‌ها استفاده می‌کند (می‌تواند item_id عددی یا آرایه مشخصات باشد)
	 * - اگر args['items'] خالی باشد: به تعداد count آیتم جدید می‌سازد
	 *
	 * ساختار ورودی:
	 * $args = [
	 *   'type'         => 'production',     // production | transfer | delivery | send | manual | refund | warranty |
	 *   scrap
	 *   'from_stock'   => null,
	 *   'to_stock'     => 'produce',
	 *   'creator_id'   => 0,
	 *   'product_id'   => 0,
	 *   'sku'          => '',
	 *   'product_name' => '',
	 *   'order_id'     => 0,
	 *   'io_type'      => 'in',             // in | out
	 *
	 *   // اگر items ندی → از count برای ساخت آیتم جدید استفاده می‌شود
	 *   'count'        => 1,
	 *
	 *   // پیش‌فرض‌ها برای آیتم‌های جدید (و در صورت تمایل آپدیت آیتم‌های ورودی)
	 *   'item_status'  => 'produced',
	 *   'item_stock'   => null,             // اگر null باشد از to_stock پر می‌شود
	 *
	 *   // لیست آیتم‌ها (اختیاری)
	 *   // مدل 1: [12, 15, 19] → فقط item_id
	 *   // مدل 2: [['item_id'=>12,'status'=>'produced','stock'=>'store'],
	 *   ['sku'=>'ABC','status'=>'produced','stock'=>'store','serial'=>'...'], ...]
	 *   // اگر 'item_id' نباشد، به عنوان آیتم جدید ساخته می‌شود (از گزینه‌های آرایه استفاده می‌گردد)
	 *   'items'        => [],
	 *
	 *   // اگر TRUE باشد، روی آیتم‌های موجود هم status/stock را با item_status/item_stock به‌روزرسانی می‌کند (وقتی
	 *   items داده‌ای)
	 *   'update_existing_items' => false,
	 * ];
	 *
	 * @return array ['process_id'=>int, 'items'=>[['item_id'=>int,'serial'=>string], ...]]
	 */
	public function add_stock_process( array $args = [] ): array {
		$defaults = [
			'type'                  => 'production',
			'from_stock'            => NULL,
			'to_stock'              => 'produce',
			'creator_id'            => 0,
			'product_id'            => 0,
			'sku'                   => '',
			'product_name'          => '',
			'order_id'              => 0,
			'io_type'               => 'in',
			'count'                 => 1,
			'item_status'           => 'produced',
			'item_stock'            => NULL,
			'items'                 => [],
			'update_existing_items' => FALSE,
			
			'process_meta'        => [],
			'item_meta'           => [],
			'process_meta_unique' => TRUE,
			'item_meta_unique'    => TRUE,
		];
		
		$args = wp_parse_args( $args, $defaults );
		
		$args['creator_id'] = $args['creator_id'] ?: get_current_user_id();
		$args['sku']        = $args['sku'] ?: ( $args['product_id'] ? (string) $args['product_id'] : '' );
		$item_stock         = $args['item_stock'] ?: $args['to_stock'];
		$count              = max( 0, (int) $args['count'] );
		$now                = current_time( 'mysql' );
		
		$this->db->query( 'START TRANSACTION' );
		
		// 1) ایجاد رکورد فرآیند
		$ok = $this->db->insert(
			$this->stock_process,
			[
				'type'         => $args['type'],
				'from_stock'   => $args['from_stock'],
				'to_stock'     => $args['to_stock'],
				'creator_id'   => (int) $args['creator_id'],
				'product_id'   => (int) $args['product_id'],
				'sku'          => $args['sku'],
				'product_name' => $args['product_name'],
				'order_id'     => (int) $args['order_id'],
				'io_type'      => $args['io_type'],
				'date_created' => $now,
				'date_updated' => NULL,
			],
		
		);
		if ( ! $ok ) {
			$this->db->query( 'ROLLBACK' );
			
			return [
				'process_id' => 0,
				'items'      => [],
			];
		}
		
		$process_id = (int) $this->db->insert_id;
		
		// 1.1) ثبت متای فرآیند
		if ( ! empty( $args['process_meta'] ) && is_array( $args['process_meta'] ) ) {
			$this->save_meta_batch( 'process', $process_id, $args['process_meta'], (bool) $args['process_meta_unique'] );
		}
		
		$attached = [];
		
		// 2) اگر items داده شده بود: همان‌ها را پردازش کن؛ وگرنه آیتم جدید بساز
		if ( ! empty( $args['items'] ) ) {
			foreach ( $args['items'] as $row ) {
				if ( is_numeric( $row ) ) {
					$item_id = (int) $row;
					
					// اتصال آیتم موجود به فرآیند + آپدیت اختیاری وضعیت/انبار
					$update = [
						'date_updated' => $now,
						'process_id'   => $process_id,
					];
					
					if ( $args['update_existing_items'] ) {
						$update['status']        = $args['item_status'];
						$update['current_stock'] = $item_stock;
					}
					$update['last_step_type'] = $args['type'];
					$update['last_step_date'] = $now;
					$this->db->update( $this->stock_items, $update, [ 'item_id' => $item_id ] );
					
					$serial = (string) $this->db->get_var( $this->db->prepare(
						"SELECT serial FROM {$this->stock_items} WHERE item_id = %d", $item_id
					) );
					
					// متای عمومی آیتم‌ها
					if ( ! empty( $args['item_meta'] ) ) {
						$this->save_meta_batch( 'item', $item_id, $args['item_meta'], (bool) $args['item_meta_unique'] );
					}
					
					$attached[] = [
						'item_id' => $item_id,
						'serial'  => $serial,
					];
				} else {
					// آرایه‌ی مشخصات آیتم
					$row = (array) $row;
					
					if ( ! empty( $row['item_id'] ) ) {
						$item_id = (int) $row['item_id'];
						
						$update = [
							'date_updated' => $now,
							'process_id'   => $process_id,
						];
						
						if ( array_key_exists( 'status', $row ) ) {
							$update['status'] = (string) $row['status'];
						} elseif ( $args['update_existing_items'] ) {
							$update['status'] = $args['item_status'];
						}
						if ( array_key_exists( 'stock', $row ) ) {
							$update['current_stock'] = (string) $row['stock'];
						} elseif ( $args['update_existing_items'] ) {
							$update['current_stock'] = $item_stock;
						}
						$update['last_step_type'] = $args['type'];
						$update['last_step_date'] = $now;
						
						$this->db->update( $this->stock_items, $update, [ 'item_id' => $item_id ] );
						
						$serial = (string) $this->db->get_var( $this->db->prepare(
							"SELECT serial FROM {$this->stock_items} WHERE item_id = %d", $item_id
						) );
						
						// متای عمومی + متای اختصاصی آیتم
						if ( ! empty( $args['item_meta'] ) ) {
							$this->save_meta_batch( 'item', $item_id, $args['item_meta'], (bool) $args['item_meta_unique'] );
						}
						if ( ! empty( $row['meta'] ) && is_array( $row['meta'] ) ) {
							$this->save_meta_batch( 'item', $item_id, $row['meta'], (bool) $args['item_meta_unique'] );
						}
						
						$attached[] = [
							'item_id' => $item_id,
							'serial'  => $serial,
						];
					} else {
						// ساخت آیتم جدید
						$serial = ! empty( $row['serial'] ) ? (string) $row['serial'] : $this->generate_unique_serial_16();
						$ok     = $this->db->insert(
							$this->stock_items,
							[
								'process_id'     => $process_id,
								'sku'            => $row['sku'] ?? $args['sku'],
								'serial'         => $serial,
								'status'         => $row['status'] ?? $args['item_status'],
								'current_stock'  => $row['stock'] ?? $item_stock,
								'product_name'   => $args['product_name'],
								'product_id'     => (int) $args['product_id'],
								'last_step_type' => $args['type'],
								'last_step_date' => current_time( 'mysql' ),
								'date_created'   => $now,
								'date_updated'   => NULL,
							],
						);
						if ( ! $ok ) {
							$retry = FALSE;
							for ( $t = 0; $t < 5; $t ++ ) {
								$serial = $this->generate_unique_serial_16();
								$ok     = $this->db->insert(
									$this->stock_items,
									[
										'process_id'     => $process_id,
										'sku'            => $row['sku'] ?? $args['sku'],
										'serial'         => $serial,
										'status'         => $row['status'] ?? $args['item_status'],
										'current_stock'  => $row['stock'] ?? $item_stock,
										'product_name'   => $args['product_name'],
										'product_id'     => (int) $args['product_id'],
										'last_step_type' => $args['type'],
										'last_step_date' => current_time( 'mysql' ),
										'date_created'   => $now,
										'date_updated'   => NULL,
									],
								);
								if ( $ok ) {
									$retry = TRUE;
									break;
								}
							}
							if ( ! $ok && ! $retry ) {
								$this->db->query( 'ROLLBACK' );
								
								return [
									'process_id' => 0,
									'items'      => [],
								];
							}
						}
						$item_id = (int) $this->db->insert_id;
						
						// متای عمومی + متای اختصاصی آیتم
						if ( ! empty( $args['item_meta'] ) ) {
							$this->save_meta_batch( 'item', $item_id, $args['item_meta'], (bool) $args['item_meta_unique'] );
						}
						if ( ! empty( $row['meta'] ) && is_array( $row['meta'] ) ) {
							$this->save_meta_batch( 'item', $item_id, $row['meta'], (bool) $args['item_meta_unique'] );
						}
						
						$attached[] = [
							'item_id' => $item_id,
							'serial'  => $serial,
						];
					}
				}
			}
		} else {
			// ساخت count آیتم جدید
			if ( $count < 1 ) {
				$this->db->query( 'ROLLBACK' );
				
				return [
					'process_id' => $process_id,
					'items'      => [],
				];
			}
			for ( $i = 0; $i < $count; $i ++ ) {
				$serial = $this->generate_unique_serial_16();
				$ok     = $this->db->insert(
					$this->stock_items,
					[
						'process_id'     => $process_id,
						'sku'            => $row['sku'] ?? $args['sku'],
						'serial'         => $serial,
						'status'         => $row['status'] ?? $args['item_status'],
						'current_stock'  => $row['stock'] ?? $item_stock,
						'product_name'   => $args['product_name'],
						'product_id'     => (int) $args['product_id'],
						'last_step_type' => $args['type'],
						'last_step_date' => current_time( 'mysql' ),
						'date_created'   => $now,
						'date_updated'   => NULL,
					],
				);
				if ( ! $ok ) {
					$retry = FALSE;
					for ( $t = 0; $t < 5; $t ++ ) {
						$serial = $this->generate_unique_serial_16();
						$ok     = $this->db->insert(
							$this->stock_items,
							[
								'process_id'     => $process_id,
								'sku'            => $row['sku'] ?? $args['sku'],
								'serial'         => $serial,
								'status'         => $row['status'] ?? $args['item_status'],
								'current_stock'  => $row['stock'] ?? $item_stock,
								'product_name'   => $args['product_name'],
								'product_id'     => (int) $args['product_id'],
								'last_step_type' => $args['type'],
								'last_step_date' => current_time( 'mysql' ),
								'date_created'   => $now,
								'date_updated'   => NULL,
							],
						);
						if ( $ok ) {
							$retry = TRUE;
							break;
						}
					}
					if ( ! $ok && ! $retry ) {
						$this->db->query( 'ROLLBACK' );
						
						return [
							'process_id' => 0,
							'items'      => [],
						];
					}
				}
				$item_id = (int) $this->db->insert_id;
				
				// متای عمومی آیتم‌ها
				if ( ! empty( $args['item_meta'] ) ) {
					$this->save_meta_batch( 'item', $item_id, $args['item_meta'], (bool) $args['item_meta_unique'] );
				}
				
				$attached[] = [
					'item_id' => $item_id,
					'serial'  => $serial,
				];
			}
		}
		
		$this->db->query( 'COMMIT' );
		
		return [
			'process_id' => $process_id,
			'items'      => $attached,
		];
	}
	
	/**
	 * تولید سریال یکتا 16 رقمی (سازگار با وردپرس)
	 */
	private function generate_unique_serial_16(): string {
		// ترجیح: منبع امن اگر وجود داشته باشد
		if ( function_exists( 'random_bytes' ) ) {
			$bytes = random_bytes( 16 ); // 16 بایت → 128 بیت
			// به رقم تبدیل می‌کنیم (mod 10)
			$out = '';
			for ( $i = 0; $i < 16; $i ++ ) {
				$out .= ( ord( $bytes[ $i ] ) % 10 );
			}
			
			return $out;
		}
		
		// fallback: wp_rand
		$out = '';
		for ( $i = 0; $i < 16; $i ++ ) {
			$out .= (string) wp_rand( 0, 9 );
		}
		
		return $out;
	}
	
	private function save_meta_batch( string $context, int $object_id, array $meta, bool $unique = TRUE ): void {
		foreach ( $meta as $k => $v ) {
			if ( $v === NULL ) {
				$this->update_meta( $context, $object_id, $k, NULL, TRUE );
				continue;
			}
			if ( $unique ) {
				$this->update_meta( $context, $object_id, $k, $v, TRUE );
			} else {
				// اگر v آرایه بود، هر کدام یک ردیف
				if ( is_array( $v ) ) {
					foreach ( $v as $each ) {
						$this->update_meta( $context, $object_id, $k, $each, FALSE );
					}
				} else {
					$this->update_meta( $context, $object_id, $k, $v, FALSE );
				}
			}
		}
	}
	
	public function get_items_for_fulfillment( array $args = [] ): array {
		$defaults = [
			'sku'    => '',
			'stock'  => 'store',
			'status' => 'produced',
			'limit'  => 1,
		];
		$args     = wp_parse_args( $args, $defaults );
		
		if ( empty( $args['sku'] ) || $args['limit'] < 1 ) {
			return [];
		}
		$stock = $args['stock'];
		$stock = implode( "','", $stock );
		$sql   = $this->db->prepare(
			"SELECT item_id
		   FROM {$this->stock_items}
		  WHERE sku = %s
		    AND current_stock IN ('$stock')
		    AND status = %s
		  ORDER BY date_created ASC, item_id ASC
		  LIMIT %d",
			$args['sku'], $args['status'], (int) $args['limit']
		);
		
		return array_map( 'intval', (array) $this->db->get_col( $sql ) );
	}
	
	public function add_production_request( array $args = [] ): array {
		$defaults = [
			'type'        => 'production',
			'io_type'     => 'in',
			'to_stock'    => 'produce',
			'item_status' => 'pending',
			// درخواست تولید → آیتم‌ها در انتظار اقدام
		];
		$args     = wp_parse_args( $args, $defaults );
		
		if ( empty( $args['count'] ) && ! empty( $args['qty'] ) ) {
			$args['count'] = (int) $args['qty'];
		}
		if ( empty( $args['count'] ) ) {
			$args['count'] = 1;
		}
		
		return $this->add_stock_process( $args );
	}
	
	// داخل کلاس kcp_stock
	
	/**
	 * عملیات دستی روی موجودی بر اساس SKU (ورود یا خروج)
	 *
	 * ورودی‌ها:
	 * $args = [
	 *   'sku'            => (string)   اجباری
	 *   'mode'           => 'in'|'out' اجباری (نوع عملیات)
	 *   'qty'            => (int)      پیش‌فرض 1
	 *
	 *   // جهت «ورود»
	 *   'to_stock'       => (string)   پیش‌فرض 'store'
	 *   'in_status'      => (string)   پیش‌فرض 'produced'
	 *
	 *   // جهت «خروج»
	 *   'from_stock'     => (string)   پیش‌فرض 'store'
	 *   'out_status_src' => (string)   پیش‌فرض 'produced' (از چه وضعیتی برداشته شود)
	 *   'to_stock_out'   => (string)   پیش‌فرض 'delivered' (به کجا برود)
	 *   'out_status_dst' => (string)   پیش‌فرض 'delivered' (وضعیت مقصد)
	 *
	 *   // عمومی
	 *   'creator_id'     => (int)      پیش‌فرض current_user
	 *   'order_id'       => (int)      اختیاری
	 *   'product_name'   => (string)   اختیاری
	 *   'process_meta'   => (array)    اختیاری
	 *   'item_meta'      => (array)    اختیاری (برای آیتم‌های جدید یا برای خروج اعمال نمی‌شود مگر آیتم جدیدی ساخته شود
	 *   که در خروج نداریم)
	 * ]
	 *
	 * خروجی: [
	 *   'success'       => bool,
	 *   'mode'          => 'in'|'out',
	 *   'requested_qty' => int,
	 *   'done_qty'      => int,
	 *   'shortage'      => int,           // فقط در خروج اگر به تعداد کافی آیتم نبود
	 *   'process_id'    => int,
	 *   'items'         => [ ['item_id'=>int,'serial'=>string], ... ],
	 * ]
	 */
	public function release_order_from_in_production_items( int $order_id ): array {
		$order_id = absint( $order_id );
		
		if ( $order_id <= 0 ) {
			return [
				'count'    => 0,
				'item_ids' => [],
			];
		}
		
		$items = $this->db->get_results(
			$this->db->prepare(
				"
			SELECT si.item_id, si.process_id
			  FROM {$this->stock_items} si
			  INNER JOIN {$this->stock_items_meta} sim
			          ON sim.item_id = si.item_id
			         AND sim.meta_key = 'order_id'
			 WHERE sim.meta_value = %s
			   AND si.current_stock = 'produce'
			   AND si.status = 'in_production'
			",
				(string) $order_id
			),
			ARRAY_A
		);
		
		if ( empty( $items ) ) {
			return [
				'count'    => 0,
				'item_ids' => [],
			];
		}
		
		$item_ids = array_values( array_map( static function( $item ) {
			return absint( $item['item_id'] );
		}, $items ) );
		
		$now = current_time( 'mysql' );
		
		$this->db->query( 'START TRANSACTION' );
		
		foreach ( $items as $item ) {
			$item_id    = absint( $item['item_id'] );
			$process_id = absint( $item['process_id'] );
			
			if ( ! $item_id || ! $process_id ) {
				continue;
			}
			
			$this->add_stock_item_step( [
				'item_id'    => $item_id,
				'process_id' => $process_id,
				'user_id'    => get_current_user_id(),
				'step_type'  => 'order_cancelled',
				'details'    => sprintf( 'سفارش #%d لغو شد و تولید این آیتم نیز لغو گردید.', $order_id ),
				'date'       => $now,
				'meta'       => [
					'order_id' => $order_id,
				],
			] );
		}
		
		$placeholders = implode( ',', array_fill( 0, count( $item_ids ), '%d' ) );
		
		$sql = "
		UPDATE {$this->stock_items}
		   SET status = %s,
		       current_stock = %s,
		       date_updated = %s
		 WHERE item_id IN ({$placeholders})
	";
		
		$params = array_merge(
			[
				'rejected',
				'produce',
				$now,
			],
			$item_ids
		);
		
		$this->db->query( $this->db->prepare( $sql, $params ) );
		
		$this->db->query( 'COMMIT' );
		
		return [
			'count'    => count( $item_ids ),
			'item_ids' => $item_ids,
		];
	}
	
	public function manual_stock_by_sku( array $args = [] ): array {
		$defaults = [
			'sku'            => '',
			'mode'           => '',
			// 'in' | 'out'
			
			// IN
			'to_stock'       => 'store',
			'in_status'      => 'produced',
			
			// OUT
			'from_stock'     => 'store',
			'out_status_src' => 'produced',
			'to_stock_out'   => 'delivered',
			'out_status_dst' => 'delivered',
			
			// Common
			'qty'            => 1,
			'creator_id'     => 0,
			'order_id'       => 0,
			'product_name'   => '',
			'product_id'     => '',
			'process_meta'   => [],
			'item_meta'      => [],
		];
		$args     = wp_parse_args( $args, $defaults );
		
		// اعتبارسنجی
		if ( empty( $args['sku'] ) || ! in_array( $args['mode'], [
				'in',
				'out',
			], TRUE ) ) {
			return [
				'success'       => FALSE,
				'mode'          => $args['mode'] ?: '',
				'requested_qty' => (int) $args['qty'],
				'done_qty'      => 0,
				'shortage'      => 0,
				'process_id'    => 0,
				'items'         => [],
			];
		}
		
		$qty        = max( 1, (int) $args['qty'] );
		$creator_id = $args['creator_id'] ?: get_current_user_id();
		// ورود دستی
		if ( $args['mode'] === 'in' ) {
			$res = $this->add_stock_process( [
				'type'                  => 'manual_in',
				'from_stock'            => NULL,
				'to_stock'              => $args['to_stock'] ?: 'store',
				'creator_id'            => $creator_id,
				'product_id'            => $args['product_id'],
				'sku'                   => $args['sku'],
				'product_name'          => $args['product_name'],
				'order_id'              => (int) $args['order_id'],
				'io_type'               => 'in',
				'count'                 => $qty,
				'item_status'           => $args['in_status'],
				'item_stock'            => $args['to_stock'] ?: 'store',
				'items'                 => [],
				'update_existing_items' => FALSE,
				'process_meta'          => (array) $args['process_meta'],
				'item_meta'             => (array) $args['item_meta'],
				'process_meta_unique'   => TRUE,
				'item_meta_unique'      => TRUE,
			] );
			
			// ثبت استپ برای هر آیتم
			if ( ! empty( $res['process_id'] ) && ! empty( $res['items'] ) ) {
				foreach ( $res['items'] as $row ) {
					$this->add_stock_item_step( [
						'item_id'    => (int) $row['item_id'],
						'process_id' => (int) $res['process_id'],
						'user_id'    => $creator_id,
						'step_type'  => 'manual_in',
						'details'    => 'Manual stock IN by SKU: ' . $args['sku'],
						'meta'       => [
							'sku'        => $args['sku'],
							'to_stock'   => $args['to_stock'] ?: 'store',
							'new_status' => $args['in_status'],
						],
					] );
				}
			}
			
			return [
				'success'       => (bool) ( $res['process_id'] ?? 0 ),
				'mode'          => 'in',
				'requested_qty' => $qty,
				'done_qty'      => count( $res['items'] ?? [] ),
				'shortage'      => 0,
				'process_id'    => (int) ( $res['process_id'] ?? 0 ),
				'items'         => $res['items'] ?? [],
			];
		}
		
		// خروج دستی
		$candidate_ids = $this->get_items_for_fulfillment( [
			'sku'    => $args['sku'],
			'stock'  => $args['from_stock'] ?: 'store',
			'status' => $args['out_status_src'] ?: 'produced',
			'limit'  => $qty,
		] );
		
		$done_qty = count( $candidate_ids );
		if ( $done_qty === 0 ) {
			return [
				'success'       => FALSE,
				'mode'          => 'out',
				'requested_qty' => $qty,
				'done_qty'      => 0,
				'shortage'      => $qty,
				'process_id'    => 0,
				'items'         => [],
			];
		}
		
		$items_for_process = [];
		foreach ( $candidate_ids as $iid ) {
			$items_for_process[] = [
				'item_id' => (int) $iid,
				'status'  => $args['out_status_dst'] ?: 'delivered',
				'stock'   => $args['to_stock_out'] ?: 'delivered',
			];
		}
		
		$res = $this->add_stock_process( [
			'type'                  => 'manual_out',
			'from_stock'            => $args['from_stock'] ?: 'store',
			'to_stock'              => $args['to_stock_out'] ?: 'delivered',
			'creator_id'            => $creator_id,
			'product_id'            => $args['product_id'],
			'sku'                   => $args['sku'],
			'product_name'          => $args['product_name'],
			'order_id'              => (int) $args['order_id'],
			'io_type'               => 'out',
			'count'                 => 0,
			'item_status'           => $args['out_status_dst'] ?: 'delivered',
			'item_stock'            => $args['to_stock_out'] ?: 'delivered',
			'items'                 => $items_for_process,
			'update_existing_items' => TRUE,
			'process_meta'          => (array) $args['process_meta'],
			'item_meta'             => [],
			'process_meta_unique'   => TRUE,
			'item_meta_unique'      => TRUE,
		] );
		
		// ثبت استپ برای هر آیتم
		if ( ! empty( $res['process_id'] ) && ! empty( $res['items'] ) ) {
			foreach ( $res['items'] as $row ) {
				$this->add_stock_item_step( [
					'item_id'    => (int) $row['item_id'],
					'process_id' => (int) $res['process_id'],
					'user_id'    => $creator_id,
					'step_type'  => 'manual_out',
					'details'    => 'Manual stock OUT by SKU: ' . $args['sku'],
					'meta'       => [
						'sku'        => $args['sku'],
						'from_stock' => $args['from_stock'] ?: 'store',
						'new_stock'  => $args['to_stock_out'] ?: 'delivered',
						'new_status' => $args['out_status_dst'] ?: 'delivered',
					],
				] );
			}
		}
		
		return [
			'success'       => (bool) ( $res['process_id'] ?? 0 ),
			'mode'          => 'out',
			'requested_qty' => $qty,
			'done_qty'      => $done_qty,
			'shortage'      => max( 0, $qty - $done_qty ),
			'process_id'    => (int) ( $res['process_id'] ?? 0 ),
			'items'         => $res['items'] ?? [],
		];
	}
	
	// داخل class kcp_stock
	
	/**
	 * افزودن Step جدید برای یک آیتم
	 *
	 * @param   array  $args  [
	 *                        'item_id'    => (int) اجباری
	 *                        'process_id' => (int) اجباری
	 *                        'user_id'    => (int) پیش‌فرض current_user
	 *                        'step_type'  => (string) اجباری (request / approve / reject / deliver / note / ...)
	 *                        'details'    => (string) توضیحات (اختیاری)
	 *                        'attachment' => (string) مسیر/نام فایل ضمیمه (اختیاری)
	 *                        'date'       => (string) تاریخ دلخواه (اختیاری، پیش‌فرض now)
	 *                        'meta'       => (array)  آرایه متاهای اضافی (اختیاری)
	 *                        ]
	 *
	 * @return int step_id یا 0 در صورت خطا
	 */
	public function add_stock_item_step( array $args ): int {
		$defaults = [
			'item_id'    => 0,
			'process_id' => 0,
			'user_id'    => 0,
			'step_type'  => '',
			'details'    => '',
			'attachment' => '',
			'date'       => current_time( 'mysql' ),
			'meta'       => [],
		];
		$args     = wp_parse_args( $args, $defaults );
		
		if ( $args['item_id'] <= 0 || $args['process_id'] <= 0 || empty( $args['step_type'] ) ) {
			return 0;
		}
		
		$user_id = $args['user_id'] ?: get_current_user_id();
		
		$ok = $this->db->insert(
			$this->stock_item_step_log,
			[
				'item_id'    => (int) $args['item_id'],
				'process_id' => (int) $args['process_id'],
				'user_id'    => (int) $user_id,
				'step_type'  => sanitize_key( $args['step_type'] ),
				'details'    => $args['details'],
				'attachment' => $args['attachment'],
				'date'       => $args['date'],
			],
			[
				'%d',
				'%d',
				'%d',
				'%s',
				'%s',
				'%s',
				'%s',
			]
		);
		
		if ( ! $ok ) {
			return 0;
		}
		
		$step_id = (int) $this->db->insert_id;
		$this->db->update(
			$this->stock_items,
			[
				'last_step_type' => sanitize_key( $args['step_type'] ),
				'last_step_date' => $args['date'],
				'date_updated'   => $args['date'],
			],
			[
				'item_id' => (int) $args['item_id'],
			]
		);
		// ذخیره متا در صورت نیاز
		if ( ! empty( $args['meta'] ) && is_array( $args['meta'] ) ) {
			$this->save_meta_batch( 'step', $step_id, $args['meta'], TRUE );
		}
		
		return $step_id;
	}
	
	/**
	 * آغاز فرآیند انتقال بین انبارها
	 *
	 * حالت‌ها:
	 * 1) با SKU و qty → از انبار مبدا آیتم‌های آماده را برمی‌دارد و به مقصد منتقل می‌کند (FIFO).
	 * 2) با items → لیست item_id ها (یا آرایه‌های دارای item_id/status/stock) را منتقل می‌کند.
	 *
	 * ورودی:
	 * $args = [
	 *   // انتخاب آیتم‌ها (یکی از این دو حالت را بده)
	 *   'sku'            => '',          // اگر بدهی از get_items_for_fulfillment انتخاب می‌شود
	 *   'qty'            => 0,           // تعداد مورد نیاز
	 *   'items'          => [],          // مثلا [12,15] یا [['item_id'=>12,'status'=>'produced','stock'=>'store']]
	 *
	 *   // انتقال
	 *   'from_stock'     => 'store',     // انبار مبدا
	 *   'to_stock'       => 'deliver',   // انبار مقصد
	 *   'status_src'     => 'produced',  // وضعیت مبدا برای فیلتر انتخاب (وقتی sku/qty می‌دهی)
	 *   'status_dst'     => 'produced',  // وضعیت مقصد پس از انتقال
	 *
	 *   // عمومی
	 *   'creator_id'     => 0,
	 *   'order_id'       => 0,
	 *   'product_name'   => '',
	 *   'process_meta'   => [],
	 *   'item_meta'      => [],          // فقط روی آیتم‌های ورودیِ جدید اعمال می‌شود (اگر آرایه items بدون item_id
	 *   بدهی)
	 * ]
	 *
	 * خروجی:
	 * [
	 *   'success'       => bool,
	 *   'requested_qty' => int,
	 *   'done_qty'      => int,
	 *   'shortage'      => int,
	 *   'process_id'    => int,
	 *   'items'         => [ ['item_id'=>int,'serial'=>string], ... ],
	 * ]
	 */
	public function start_transfer( array $args = [] ): array {
		$defaults = [
			'sku'   => '',
			'qty'   => 0,
			'items' => [],
			
			'from_stock' => 'store',
			'to_stock'   => 'deliver',
			'status_src' => 'produced',
			'status_dst' => 'produced',
			
			'creator_id'   => 0,
			'order_id'     => 0,
			'product_name' => '',
			'process_meta' => [],
			'item_meta'    => [],
		];
		$args     = wp_parse_args( $args, $defaults );
		
		$creator_id = $args['creator_id'] ?: get_current_user_id();
		$requested  = (int) $args['qty'];
		
		// اگر items ندادند و با SKU/qty می‌خواهند:
		$selected_items = [];
		if ( empty( $args['items'] ) && ! empty( $args['sku'] ) && $requested > 0 ) {
			$selected_items = $this->get_items_for_fulfillment( [
				'sku'    => $args['sku'],
				'stock'  => $args['from_stock'],
				'status' => $args['status_src'],
				'limit'  => $requested,
			] );
			// به قالب آیتم‌های فرایند تبدیل کن
			$tmp = [];
			foreach ( $selected_items as $iid ) {
				$tmp[] = [
					'item_id' => (int) $iid,
					'status'  => $args['status_dst'],
					'stock'   => $args['to_stock'],
				];
			}
			$args['items'] = $tmp;
		}
		
		// اگر همچنان آیتمی نداریم، خروج با خطا
		if ( empty( $args['items'] ) ) {
			return [
				'success'       => FALSE,
				'requested_qty' => $requested,
				'done_qty'      => 0,
				'shortage'      => max( $requested, 0 ),
				'process_id'    => 0,
				'items'         => [],
			];
		}
		
		// product_id از روی SKU (اختیاری)
		$product_id = (int) crm_get_product_by_sku( $args['sku'] );
		// اجرای فرآیند انتقال
		$res = $this->add_stock_process( [
			'type'                  => 'transfer',
			'from_stock'            => $args['from_stock'],
			'to_stock'              => $args['to_stock'],
			'creator_id'            => $creator_id,
			'product_id'            => $product_id,
			'sku'                   => (string) $args['sku'],
			'product_name'          => (string) $args['product_name'],
			'order_id'              => (int) $args['order_id'],
			'io_type'               => 'out',
			// برای گزارش‌گیری: این فرآیند از مبدا خارج و به مقصد وارد می‌کند
			'count'                 => 0,
			// آیتم‌ها موجودند
			'item_status'           => $args['status_dst'],
			'item_stock'            => $args['to_stock'],
			'items'                 => $args['items'],
			// لیست آیتم‌ها جهت انتقال
			'update_existing_items' => TRUE,
			// وضعیت/انبار آیتم‌ها آپدیت شود
			'process_meta'          => (array) $args['process_meta'],
			'item_meta'             => [],
			// روی آیتم‌های موجود متا عمومی اضافه نمی‌کنیم
			'process_meta_unique'   => TRUE,
			'item_meta_unique'      => TRUE,
		] );
		
		$done_qty = count( $res['items'] ?? [] );
		$shortage = 0;
		if ( $requested > 0 && $requested > $done_qty ) {
			$shortage = $requested - $done_qty;
		}
		
		// Step لاگ: انتقال تأیید‌شده
		if ( ! empty( $res['process_id'] ) && ! empty( $res['items'] ) ) {
			foreach ( $res['items'] as $row ) {
				$this->add_stock_item_step( [
					'item_id'    => (int) $row['item_id'],
					'process_id' => (int) $res['process_id'],
					'user_id'    => $creator_id,
					'step_type'  => 'transfer_requested',
					'details'    => sprintf(
						'Transfer item by SKU %s from %s to %s (status: %s)',
						$args['sku'] ?: '[items]',
						$args['from_stock'],
						$args['to_stock'],
						$args['status_dst']
					),
					'meta'       => [
						'sku'        => (string) $args['sku'],
						'from_stock' => $args['from_stock'],
						'to_stock'   => $args['to_stock'],
						'status_dst' => $args['status_dst'],
						'order_id'   => (int) $args['order_id'],
					],
				] );
			}
		}
		
		return [
			'success'       => (bool) ( $res['process_id'] ?? 0 ),
			'requested_qty' => $requested,
			'done_qty'      => $done_qty,
			'shortage'      => $shortage,
			'process_id'    => (int) ( $res['process_id'] ?? 0 ),
			'items'         => $res['items'] ?? [],
		];
	}
	
	/**
	 * نهایی‌سازی انتقال برای «چند آیتم» از یک فرآیند (امکان تایید/رد تکی برای هر آیتم)
	 *
	 * ورودی:
	 * $args = [
	 *   'process_id' => (int) اجباری
	 *   'items'      => [                // الزامی
	 *      // مدل ساده: فقط آیدی → پیش‌فرض approve با مقادیر new_status/new_stock عمومی
	 *      123, 124,
	 *      // مدل کامل: کنترل مجزا برای هر آیتم
	 *      [
	 *        'item_id'   => 125,
	 *        'decision'  => 'reject'|'approve',   // پیش‌فرض 'approve'
	 *        'new_status'=> 'produced',           // فقط وقتی approve
	 *        'new_stock' => 'deliver',            // فقط وقتی approve
	 *        'note'      => 'اختیاری',
	 *        'meta'      => [ ... ],              // اختیاری: متای Step
	 *      ],
	 *   ],
	 *   // مقادیر پیش‌فرض برای همه آیتم‌هایی که مدل ساده داده شده‌اند یا فیلد نداشته باشند:
	 *   'default_decision' => 'approve',
	 *   'default_status'   => 'produced',
	 *   'default_stock'    => 'deliver',
	 *   'user_id'          => 0,                  // پیش‌فرض current user
	 *   'note'             => '',                 // یادداشت عمومی (اگر note آیتم خالی بود)
	 * ]
	 *
	 * خروجی:
	 * [
	 *   'success'      => bool,
	 *   'process_id'   => int,
	 *   'approved'     => int,
	 *   'rejected'     => int,
	 *   'results'      => [
	 *      ['item_id'=>123,'decision'=>'approve','ok'=>true],
	 *      ['item_id'=>124,'decision'=>'reject','ok'=>true],
	 *      ...
	 *   ]
	 * ]
	 */
	public function finish_transfer( array $args ): array {
		$defaults = [
			'process_id'       => 0,
			'items'            => [],
			'default_decision' => 'approve',
			'default_status'   => 'produced',
			'default_stock'    => 'deliver',
			'user_id'          => 0,
			'note'             => '',
		];
		$args     = wp_parse_args( $args, $defaults );
		
		$process_id = (int) $args['process_id'];
		if ( $process_id <= 0 || empty( $args['items'] ) || ! is_array( $args['items'] ) ) {
			return [
				'success'    => FALSE,
				'process_id' => $process_id,
				'approved'   => 0,
				'rejected'   => 0,
				'results'    => [],
			];
		}
		
		$user_id  = $args['user_id'] ?: get_current_user_id();
		$approved = 0;
		$rejected = 0;
		$results  = [];
		
		// فقط آیتم‌های همین فرآیند مجازند
		$valid_item_ids = $this->db->get_col( $this->db->prepare(
			"SELECT item_id FROM {$this->stock_items} WHERE process_id = %d",
			$process_id
		) );
		$valid_map      = array_fill_keys( array_map( 'intval', (array) $valid_item_ids ), TRUE );
		
		foreach ( $args['items'] as $it ) {
			// نرمال‌سازی ورودی آیتم
			if ( is_numeric( $it ) ) {
				$it = [
					'item_id'    => (int) $it,
					'decision'   => $args['default_decision'],
					'new_status' => $args['default_status'],
					'new_stock'  => $args['default_stock'],
					'note'       => $args['note'],
					'meta'       => [],
				];
			} else {
				$it               = (array) $it;
				$it['item_id']    = isset( $it['item_id'] ) ? (int) $it['item_id'] : 0;
				$it['decision']   = isset( $it['decision'] ) ? (string) $it['decision'] : $args['default_decision'];
				$it['new_status'] = isset( $it['new_status'] ) ? (string) $it['new_status'] : $args['default_status'];
				$it['new_stock']  = isset( $it['new_stock'] ) ? (string) $it['new_stock'] : $args['default_stock'];
				$it['note']       = isset( $it['note'] ) ? (string) $it['note'] : $args['note'];
				$it['meta']       = isset( $it['meta'] ) && is_array( $it['meta'] ) ? $it['meta'] : [];
			}
			
			$item_id = (int) $it['item_id'];
			if ( $item_id <= 0 || ! isset( $valid_map[ $item_id ] ) ) {
				$results[] = [
					'item_id'  => $item_id,
					'decision' => $it['decision'],
					'ok'       => FALSE,
					'error'    => 'INVALID_ITEM',
				];
				continue;
			}
			
			if ( $it['decision'] === 'approve' ) {
				$ok = $this->db->update(
					$this->stock_items,
					[
						'status'        => $it['new_status'],
						'current_stock' => $it['new_stock'],
						'date_updated'  => current_time( 'mysql' ),
					],
					[ 'item_id' => $item_id ],
					[
						'%s',
						'%s',
						'%s',
					],
					[ '%d' ]
				);
				$ok = ( $ok !== FALSE );
				
				// Step: transfer_approved
				$this->add_stock_item_step( [
					'item_id'    => $item_id,
					'process_id' => $process_id,
					'user_id'    => $user_id,
					'step_type'  => 'transfer_approved',
					'details'    => $it['note'] ?: 'Transfer approved',
					'meta'       => array_merge( [
						'new_status' => $it['new_status'],
						'new_stock'  => $it['new_stock'],
					], $it['meta'] ),
				] );
				
				if ( $ok ) {
					$approved ++;
					$results[] = [
						'item_id'  => $item_id,
						'decision' => 'approve',
						'ok'       => TRUE,
					];
				} else {
					$results[] = [
						'item_id'  => $item_id,
						'decision' => 'approve',
						'ok'       => FALSE,
						'error'    => 'UPDATE_FAILED',
					];
				}
			} else { // reject
				// Step: transfer_rejected (بدون تغییر آیتم)
				$this->add_stock_item_step( [
					'item_id'    => $item_id,
					'process_id' => $process_id,
					'user_id'    => $user_id,
					'step_type'  => 'transfer_rejected',
					'details'    => $it['note'] ?: 'Transfer rejected',
					'meta'       => (array) $it['meta'],
				] );
				
				$rejected ++;
				$results[] = [
					'item_id'  => $item_id,
					'decision' => 'reject',
					'ok'       => TRUE,
				];
			}
		}
		
		return [
			'success'    => ( $approved + $rejected ) > 0,
			'process_id' => $process_id,
			'approved'   => $approved,
			'rejected'   => $rejected,
			'results'    => $results,
		];
	}
	
	/**
	 * دریافت محصولات انبار (گروه‌بندی بر اساس SKU) + لیست سریال‌ها
	 * - دیفالت: انبار تولید (produce)
	 * - آیتم‌های هر SKU بر اساس تاریخ «آخرین استپ» از قدیم به جدید مرتب می‌شوند
	 *
	 * @param   array  $args  [
	 *                        'page_number' => 1,
	 *                        'per_page'    => 20,
	 *                        'stock'       => 'produce',   // انبار مقصد (store/vitrine/produce/...)
	 *                        'status'      => '',          // فیلتر وضعیت آیتم
	 *                        'sku'         => '',          // LIKE روی SKU
	 *                        'brand'       => '',          // LIKE روی meta_key='brand' (در صورت ورود → JOIN)
	 *                        'type'        => '',          // فیلتر «نوع آخرین استپ»
	 *                        'date_from'   => '',          // YYYY-MM-DD روی تاریخ آخرین استپ
	 *                        'date_to'     => '',          // YYYY-MM-DD روی تاریخ آخرین استپ
	 *                        'search'      => '',          // LIKE روی sku یا product_name
	 *                        ]
	 *
	 * @return array [
	 *   'total'       => int,
	 *   'pages'       => int,
	 *   'page_number' => int,
	 *   'per_page'    => int,
	 *   'rows'        => [
	 *     [
	 *       'sku'          => string,
	 *       'product_id'   => int|null,
	 *       'product_name' => string|null,
	 *       'brand'        => string|null,    // فقط وقتی فیلتر برند دادی
	 *       'count'        => int,            // تعداد آیتم‌های این SKU بعد از فیلتر
	 *       'items'        => [               // مرتب‌شده بر اساس last_step_date صعودی
	 *         [
	 *           'item_id'        => int,
	 *           'serial'         => string,
	 *           'status'         => string,
	 *           'stock'          => string,
	 *           'last_step_type' => string|null,
	 *           'last_step_date' => string|null,
	 *         ],
	 *         ...
	 *       ],
	 *     ],
	 *     ...
	 *   ]
	 * ]
	 */
	/**
	 * Faster version — builds JOINs only when needed, uses COUNT(DISTINCT) for SKU totals,
	 * and avoids the latest-steps join unless it's required for filters or explicitly requested.
	 */
	public function get_warehouse_products( array $args = [] ): array {
		$defaults = [
			'page_number'       => 1,
			'per_page'          => 20,
			'stock'             => 'produce',
			'status'            => '',
			'sku'               => '',
			'brand'             => '',
			'order_id'          => '',
			'step_type'         => '',
			'date_from'         => '',
			'date_to'           => '',
			'search'            => '',
			'serial'            => '',
			'product_id'        => '',
			'product_date_from' => '',
			'product_date_to'   => '',
			'product_cat'       => '',
		];
		
		$args = wp_parse_args( $args, $defaults );
		
		$page       = max( 1, (int) $args['page_number'] );
		$perPage    = max( 1, (int) $args['per_page'] );
		$offset     = ( $page - 1 ) * $perPage;
		$need_brand = ( $args['brand'] !== '' );
		
		// ---------------- WHERE builder ----------------
		
		$where  = [ '1=1' ];
		$params = [];
		
		if ( $args['stock'] !== '' ) {
			$where[]  = 'si.current_stock = %s';
			$params[] = $args['stock'];
		}
		
		if ( $args['status'] !== '' ) {
			$where[]  = 'si.status = %s';
			$params[] = $args['status'];
		}
		
		if ( $args['sku'] !== '' ) {
			$where[]  = 'si.sku LIKE %s';
			$params[] = '%' . $this->db->esc_like( $args['sku'] ) . '%';
		}
		
		if ( $args['serial'] !== '' ) {
			$where[]  = 'si.serial LIKE %s';
			$params[] = '%' . $this->db->esc_like( $args['serial'] ) . '%';
		}
		if ( $args['product_id'] !== '' ) {
			$where[]  = 'si.product_id = %s';
			$params[] = $args['product_id'];
		}
		
		if ( $args['search'] !== '' ) {
			$like     = '%' . $this->db->esc_like( $args['search'] ) . '%';
			$where[]  = '(si.sku LIKE %s OR si.product_name LIKE %s OR si.serial LIKE %s)';
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
		}
		
		if ( $args['step_type'] !== '' ) {
			$where[]  = 'si.last_step_type = %s';
			$params[] = $args['step_type'];
		}
		
		if ( $args['date_from'] !== '' ) {
			$where[]  = 'si.last_step_date >= %s';
			$params[] = nooshika_jalali_to_gregorian( $args['date_from'] ) . ' 00:00:00';
		}
		
		if ( $args['date_to'] !== '' ) {
			$where[]  = 'si.last_step_date <= %s';
			$params[] = nooshika_jalali_to_gregorian( $args['date_to'] ) . ' 23:59:59';
		}
		
		$joins = [];
		
		if ( $need_brand ) {
			$joins[]  = "LEFT JOIN {$this->stock_items_meta} bm
                     ON bm.item_id = si.item_id AND bm.meta_key = 'brand'";
			$where[]  = 'bm.meta_value LIKE %s';
			$params[] = '%' . $this->db->esc_like( $args['brand'] ) . '%';
		}
		if ( $args['order_id'] ) {
			$joins[]  = "LEFT JOIN {$this->stock_items_meta} bm
                     ON bm.item_id = si.item_id AND bm.meta_key = 'order_id'";
			$where[]  = 'bm.meta_value = %s';
			$params[] = $args['order_id'];
		}
		
		if ( $args['product_date_from'] !== '' || $args['product_date_to'] !== '' ) {
			$joins[] = "LEFT JOIN {$this->stock_items_meta} bm
				ON bm.item_id = si.item_id AND bm.meta_key = 'production_date'";
			
			if ( $args['product_date_from'] !== '' && $args['product_date_to'] !== '' ) {
				$where[]  = 'bm.meta_value BETWEEN %s AND %s';
				$params[] = nooshika_jalali_to_gregorian( $args['product_date_from'] ) . ' 00:00:00';
				$params[] = nooshika_jalali_to_gregorian( $args['product_date_to'] ) . ' 23:59:59';
			} elseif ( $args['product_date_from'] !== '' ) {
				$where[]  = 'bm.meta_value >= %s';
				$params[] = nooshika_jalali_to_gregorian( $args['product_date_from'] ) . ' 00:00:00';
			} elseif ( $args['product_date_to'] !== '' ) {
				$where[]  = 'bm.meta_value <= %s';
				$params[] = nooshika_jalali_to_gregorian( $args['product_date_to'] ) . ' 23:59:59';
			}
		}
		if ( $args['product_cat'] !== '' ) {
			$product_ids_sql = "
	SELECT DISTINCT p.ID AS product_id
	FROM {$this->db->posts} p
	INNER JOIN {$this->db->posts} parent
		ON parent.ID = p.post_parent

	INNER JOIN {$this->db->term_relationships} trc
		ON trc.object_id = parent.ID

	INNER JOIN {$this->db->term_taxonomy} ttc
		ON ttc.term_taxonomy_id = trc.term_taxonomy_id
		AND ttc.taxonomy = 'product_cat'

	WHERE p.post_type = 'product_variation'
	AND ttc.term_taxonomy_id = " . intval( $args['product_cat'] ) . "
";
			
			$product_ids = $this->db->get_col( $product_ids_sql );
			if ( ! empty( $product_ids ) ) {
				$where[] = "si.product_id IN (" . implode( ',', array_map( 'intval', $product_ids ) ) . ")";
			}
		}
		
		$join_sql  = $joins ? "\n" . implode( "\n", $joins ) : '';
		$where_sql = implode( ' AND ', $where );
		
		// ---------------- Totals ----------------
		
		$count_skus_sql = "
        SELECT COUNT(DISTINCT si.sku)
        FROM {$this->stock_items} si
        {$join_sql}
        WHERE {$where_sql}
    ";
		
		$total_skus = (int) $this->db->get_var(
			$this->db->prepare( $count_skus_sql, $params )
		);
		
		$count_items_sql = "
        SELECT COUNT(*)
        FROM {$this->stock_items} si
        {$join_sql}
        WHERE {$where_sql}
    ";
		
		$total_items = (int) $this->db->get_var(
			$this->db->prepare( $count_items_sql, $params )
		);
		
		if ( $total_skus === 0 ) {
			return [
				'total'       => 0,
				'total_items' => 0,
				'pages'       => 0,
				'page_number' => $page,
				'per_page'    => $perPage,
				'rows'        => [],
			];
		}
		
		// ---------------- Page SKUs ----------------
		
		$page_skus_sql = "
        SELECT si.sku, COUNT(*) AS cnt
        FROM {$this->stock_items} si
        {$join_sql}
        WHERE {$where_sql}
        GROUP BY si.sku
        ORDER BY si.sku ASC
        LIMIT %d OFFSET %d
    ";
		
		$page_params   = $params;
		$page_params[] = $perPage;
		$page_params[] = $offset;
		
		$page_rows = $this->db->get_results(
			$this->db->prepare( $page_skus_sql, $page_params ),
			ARRAY_A
		);
		
		if ( empty( $page_rows ) ) {
			return [
				'total'       => $total_skus,
				'total_items' => $total_items,
				'pages'       => (int) ceil( $total_skus / $perPage ),
				'page_number' => $page,
				'per_page'    => $perPage,
				'rows'        => [],
			];
		}
		
		$sku_list     = array_column( $page_rows, 'sku' );
		$placeholders = implode( ',', array_fill( 0, count( $sku_list ), '%s' ) );
		
		$item_where   = $where;
		$item_where[] = "si.sku IN ({$placeholders})";
		$item_params  = array_merge( $params, $sku_list );
		
		$brand_select = $need_brand ? 'bm.meta_value' : 'NULL';
		
		$item_sql = "
        SELECT
            si.sku,
            si.item_id,
            si.serial,
            si.status,
            si.current_stock,
            si.product_id,
            si.product_name,
            {$brand_select} AS brand,
            si.last_step_type,
            si.last_step_date
        FROM {$this->stock_items} si
        {$join_sql}
        WHERE " . implode( ' AND ', $item_where ) . "
        ORDER BY si.sku ASC, si.item_id ASC
    ";
		
		$rows_items = $this->db->get_results(
			$this->db->prepare( $item_sql, $item_params ),
			ARRAY_A
		);
		
		// ---------------- Group in PHP ----------------
		
		$counts_by_sku = [];
		foreach ( $page_rows as $pr ) {
			$counts_by_sku[ (string) $pr['sku'] ] = (int) $pr['cnt'];
		}
		
		$by_sku = [];
		foreach ( $rows_items as $r ) {
			$sku = (string) $r['sku'];
			
			if ( ! isset( $by_sku[ $sku ] ) ) {
				$by_sku[ $sku ] = [
					'sku'          => $sku,
					'product_id'   => $r['product_id'] !== NULL ? (int) $r['product_id'] : NULL,
					'product_name' => $r['product_name'] !== NULL ? (string) $r['product_name'] : NULL,
					'brand'        => $r['brand'] !== NULL ? (string) $r['brand'] : NULL,
					'count'        => $counts_by_sku[ $sku ] ?? 0,
					'items'        => [],
				];
			}
			
			$by_sku[ $sku ]['items'][] = [
				'item_id'        => (int) $r['item_id'],
				'serial'         => (string) $r['serial'],
				'status'         => (string) $r['status'],
				'stock'          => (string) $r['current_stock'],
				'last_step_type' => $r['last_step_type'] !== NULL ? (string) $r['last_step_type'] : NULL,
				'last_step_date' => $r['last_step_date'] !== NULL ? (string) $r['last_step_date'] : NULL,
			];
		}
		
		$out_rows = [];
		foreach ( $sku_list as $sku ) {
			if ( isset( $by_sku[ $sku ] ) ) {
				$out_rows[] = $by_sku[ $sku ];
			}
		}
		
		return [
			'total'       => $total_skus,
			'total_items' => $total_items,
			'pages'       => (int) ceil( $total_skus / $perPage ),
			'page_number' => $page,
			'per_page'    => $perPage,
			'rows'        => $out_rows,
		];
	}
	
	/**
	 * Get last step type (and date) for a stock item by item_id
	 *
	 * @param   int  $item_id
	 *
	 * @return array|null { 'step_type' => string, 'date' => string } or null if not found
	 */
	public function get_last_step_for_item( int $item_id ): ?array {
		if ( $item_id <= 0 ) {
			return NULL;
		}
		
		$sql = "
		SELECT step_type, date
		  FROM {$this->stock_item_step_log}
		 WHERE item_id = %d
		 ORDER BY date DESC
		 LIMIT 1
	";
		
		$row = $this->db->get_row( $this->db->prepare( $sql, $item_id ), ARRAY_A );
		
		if ( ! $row ) {
			return NULL;
		}
		
		return [
			'step_type' => (string) $row['step_type'],
			'date'      => (string) $row['date'],
		];
	}
	
	public function get_stock_item_data( $item_id ): ?array {
		if ( $item_id <= 0 ) {
			return NULL;
		}
		
		$sql = "
		SELECT *
		  FROM {$this->stock_items}
		 WHERE item_id = %d	";
		
		return $this->db->get_row( $this->db->prepare( $sql, $item_id ), ARRAY_A );
	}
	
	public function get_stock_item_steps_list( $item_id ): ?array {
		if ( $item_id <= 0 ) {
			return NULL;
		}
		
		$sql = "
		SELECT *
		  FROM {$this->stock_item_step_log}
		 WHERE item_id = %d
		 ORDER BY date DESC
	";
		
		return $this->db->get_results( $this->db->prepare( $sql, $item_id ), ARRAY_A );
	}
	
	public function get_warehouse_products_rows( array $args = [] ): array {
		$defaults = [
			'page_number' => 1,
			'per_page'    => 20,
			'stock'       => 'produce',
			'status'      => '',
			'sku'         => '',
			'serial'      => '',
			// 🔹 فیلتر شماره سریال
			'step_type'   => '',
			'date_from'   => '',
			'date_to'     => '',
			'search'      => '',
			'order_id'    => '',
		];
		$args     = wp_parse_args( $args, $defaults );
		
		$page    = max( 1, (int) $args['page_number'] );
		$perPage = max( 1, (int) $args['per_page'] );
		$offset  = ( $page - 1 ) * $perPage;
		$where   = [ '1=1' ];
		$params  = [];
		
		if ( $args['stock'] !== '' ) {
			$where[]  = 'si.current_stock = %s';
			$params[] = $args['stock'];
		}
		if ( $args['status'] !== '' ) {
			$where[]  = 'si.status = %s';
			$params[] = $args['status'];
		}
		if ( $args['sku'] !== '' ) {
			$where[]  = 'si.sku LIKE %s';
			$params[] = '%' . $this->db->esc_like( $args['sku'] ) . '%';
		}
		if ( $args['serial'] !== '' ) {
			$where[]  = 'si.serial LIKE %s';
			$params[] = '%' . $this->db->esc_like( $args['serial'] ) . '%';
		}
		if ( $args['search'] !== '' ) {
			$like     = '%' . $this->db->esc_like( $args['search'] ) . '%';
			$where[]  = '(si.sku LIKE %s OR si.product_name LIKE %s)';
			$params[] = $like;
			$params[] = $like;
		}
		if ( $args['step_type'] !== '' ) {
			$where[]  = 'si.last_step_type = %s';
			$params[] = $args['step_type'];
		}
		if ( $args['date_from'] !== '' ) {
			$where[]  = 'si.last_step_date >= %s';
			$params[] = nooshika_jalali_to_gregorian( $args['date_from'] ) . ' 00:00:00';
		}
		if ( $args['date_to'] !== '' ) {
			$where[]  = 'si.last_step_date <= %s';
			$params[] = nooshika_jalali_to_gregorian( $args['date_to'] ) . ' 23:59:59';
		}
		$joins = [];
		if ( $args['order_id'] ) {
			$joins[]  = "LEFT JOIN {$this->stock_items_meta} bm
                     ON bm.item_id = si.item_id AND bm.meta_key = 'order_id'";
			$where[]  = 'bm.meta_value = %s';
			$params[] = $args['order_id'];
		}
		
		$join_sql  = $joins ? "\n" . implode( "\n", $joins ) : '';
		$where_sql = implode( ' AND ', $where );
		
		$count_sql   = "
		SELECT COUNT(*)
		  FROM {$this->stock_items} si
		  {$join_sql}
		 WHERE {$where_sql}
	";
		$total_items = (int) $this->db->get_var( $this->db->prepare( $count_sql, $params ) );
		
		if ( $total_items === 0 ) {
			return [
				'total'       => 0,
				'pages'       => 0,
				'page_number' => $page,
				'per_page'    => $perPage,
				'rows'        => [],
			];
		}
		
		// گرفتن آیتم‌ها
		$item_sql    = "
		SELECT
			si.item_id,
			si.sku,
			si.serial,
			si.status,
			si.current_stock,
			si.product_id,
			si.product_name
		  FROM {$this->stock_items} si
		  {$join_sql}
		 WHERE {$where_sql}
		 ORDER BY si.item_id ASC
		 LIMIT %d OFFSET %d
	";
		$item_params = array_merge( $params, [
			$perPage,
			$offset,
		] );
		$rows_items  = $this->db->get_results( $this->db->prepare( $item_sql, $item_params ), ARRAY_A );
		
		return [
			'total'       => $total_items,
			'pages'       => (int) ceil( $total_items / $perPage ),
			'page_number' => $page,
			'per_page'    => $perPage,
			'rows'        => $rows_items,
		];
	}
	
	/**
	 * Allowed next actions (step types) based on current item status and last step.
	 * قوانین اصلاح‌شده:
	 * - هیچ جا manual_in نداریم.
	 * - manual_out فقط برای محصولات آماده (produced) مجاز است.
	 * - warranty_repaired باید منجر به ارسال دوباره شود (delivering).
	 */
	public function get_allowed_next_steps( array $args ): array {
		$defaults = [
			'status'         => '',
			'last_step_type' => '',
		];
		$args     = wp_parse_args( $args, $defaults );
		
		$status    = sanitize_key( (string) $args['status'] );
		$last_step = sanitize_key( (string) $args['last_step_type'] );
		
		$all_steps = $this->get_stock_item_step_types();
		
		$base        = [
			'pending'       => [
				'request_production',
				'rejected',
			],
			'in_production' => [
				'qccheck_requested',
			],
			'produced'      => [
				'transfer_requested',
				'manual_out',
				'scrap_requested',
			],
			'delivering'    => [
				'delivery_prepared',
			],
			'delivered'     => [ 'warranty_returned' ],
			'returned'      => [
				'warranty_checked',
				'scrap_requested',
			],
			'in_warranty'   => [
				'warranty_repaired',
				'warranty_rejected',
				'scrap_requested',
			],
			'rejected_qc'   => [
				'qccheck_requested',
				'scrap_requested',
				're_produce_request',
			],
			'scrapped'      => [],
			'rejected'      => [],
		];
		$conditional = [
			// گردش QC
			'in_production' => [
				// ⬇️ بعد از درخواست QC، فقط تایید یا رد QC مجاز است
				'qccheck_requested' => [
					'qccheck_approved',
					'qccheck_rejected',
				],
			],
			
			'delivering'  => [
				'qccheck_approved'       => [ 'delivery_prepared' ],
				'delivery_prepared'      => [ 'accounting_approved' ],
				'accounting_approved'    => [ 'bill_of_lading_created' ],
				'bill_of_lading_created' => [ 'product_delivered' ],
			],
			'produced'    => [
				'transfer_approved' => [
					'transfer_requested',
					'delivery_prepared',
					'manual_out',
					'scrap_requested',
				],
				'qccheck_approved'  => [
					'transfer_requested',
					'delivery_prepared',
					'manual_out',
					'scrap_requested',
				],
			],
			'delivered'   => [
				'product_delivered' => [ 'warranty_returned' ],
			],
			'returned'    => [
				'warranty_returned' => [ 'warranty_checked' ],
			],
			'in_warranty' => [
				'warranty_repaired' => [ 'delivery_prepared' ],
			],
		];
		
		$allowed = $base[ $status ] ?? [];
		if ( isset( $conditional[ $status ], $conditional[ $status ][ $last_step ] ) ) {
			$allowed = $conditional[ $status ][ $last_step ];
		}
		
		$out = [];
		foreach ( $allowed as $key ) {
			if ( isset( $all_steps[ $key ] ) ) {
				$out[] = array_merge( [ 'key' => $key ], $all_steps[ $key ] );
			}
		}
		
		return $out;
	}
	
	/**
	 * تعیین وضعیت بعد از اجرای یک اقدام (step → status)
	 * نکات:
	 * - manual_in حذف شد.
	 * - manual_out فقط از produced مجاز است و وضعیت را تغییر نمی‌دهد (در سیستم فقط خروج را لاگ می‌کنیم).
	 * - warranty_repaired → delivering (ارسال مجدد به مشتری)
	 */
	public function get_next_status_after_step( array $args ): string {
		$defaults = [
			'current_status' => '',
			'step_type'      => '',
		];
		$args     = wp_parse_args( $args, $defaults );
		
		$current = sanitize_key( (string) $args['current_status'] );
		$step    = sanitize_key( (string) $args['step_type'] );
		
		$map = [
			// تولید و QC
			'pending'       => [
				're_produce_request' => 'in_production',
				'request_production' => 'in_production',
				'rejected'           => 'rejected',
			],
			'in_production' => [
				'qccheck_requested' => 'in_production',
				'scrap_requested'   => 'scrapped',
			],
			'rejected_qc'   => [
				'qccheck_requested' => 'in_production',
				'scrap_requested'   => 'scrapped',
			],
			
			// آماده ← ارسال
			'produced'      => [
				'delivery_prepared'  => 'delivering',
				'transfer_requested' => 'produced',
				'transfer_approved'  => 'produced',
				'manual_out'         => 'produced',
				// فقط خروج ثبت می‌شود
				'scrap_requested'    => 'scrapped',
			],
			
			// ارسال
			'delivering'    => [
				'accounting_approved'    => 'delivering',
				'bill_of_lading_created' => 'delivering',
				'product_delivered'      => 'delivered',
			],
			
			// پس از تحویل
			'delivered'     => [ 'warranty_returned' => 'in_warranty' ],
			
			// گارانتی / مرجوعی
			'returned'      => [
				'scrap_requested' => 'scrapped',
			],
			'in_warranty'   => [
				'warranty_repaired' => 'delivering',
				// ⬅️ ارسال مجدد
				'warranty_rejected' => 'delivered',
				'scrap_requested'   => 'scrapped',
			],
			
			// پایان‌ها
			'scrapped'      => [],
			'rejected'      => [],
		];
		
		if ( isset( $map[ $current ][ $step ] ) ) {
			return $map[ $current ][ $step ];
		}
		
		return $current;
	}
	
	/**
	 * اعمال یک استپ روی چند آیتم ــ بدون تکرار لاجیک ثبت لاگ
	 * از متد موجود add_stock_item_step استفاده می‌کند.
	 *
	 * @param   array  $args       {
	 *
	 * @type int[]     $item_ids   لیست آیتم‌ها (شناسه‌ها)
	 * @type string    $step_type  نوع استپ (کلید get_stock_item_step_types)
	 * @type string    $date       اختیاری. اگر YYYY-MM-DD جلالی بود با nooshika_jalali_to_gregorian تبدیل می‌شود؛
	 *       پیش‌فرض now()
	 * @type string    $details    اختیاری. توضیح استپ
	 * @type string    $attachment اختیاری. آدرس فایل
	 * @type array     $meta       اختیاری. متای استپ
	 * @type string    $set_status اختیاری. اگر مقداردهی شد، وضعیت آیتم به این مقدار تغییر می‌کند؛ وگرنه از
	 *       get_next_status_after_step استفاده می‌شود.
	 * @type string    $set_stock  اختیاری. اگر مقداردهی شد، انبار جاری آیتم به این مقدار تغییر می‌کند.
	 * }
	 * @return array { done, skipped, errors[] }
	 */
	public function apply_step_to_items( array $args ): array {
		$defaults = [
			'item_ids'   => [],
			'step_type'  => '',
			'details'    => '',
			'attachment' => '',
			'meta'       => [],
			'item_meta'  => [],
			'step_meta'  => [],
			'set_status' => NULL,
			'set_stock'  => NULL,
		];
		$args     = wp_parse_args( $args, $defaults );
		
		// --- sanitize inputs ---
		$step_type = sanitize_key( (string) $args['step_type'] );
		if ( $step_type === '' ) {
			return [
				'done'    => 0,
				'skipped' => 0,
				'errors'  => [ 'step_type خالی است.' ],
			];
		}
		
		$item_ids = array_values( array_filter( array_map( static function( $x ) {
			$x = nooshika_sanitize_numbers( $x );
			
			return absint( $x );
		}, (array) $args['item_ids'] ) ) );
		if ( empty( $item_ids ) ) {
			return [
				'done'    => 0,
				'skipped' => 0,
				'errors'  => [ 'item_ids خالی است.' ],
			];
		}
		
		$when       = current_time( 'mysql' );
		$details    = isset( $args['details'] ) ? wp_kses_post( (string) $args['details'] ) : '';
		$attachment = isset( $args['attachment'] ) ? sanitize_text_field( (string) $args['attachment'] ) : '';
		$meta       = is_array( $args['meta'] ) ? $args['meta'] : [];
		$item_meta  = is_array( $args['item_meta'] ) ? $args['item_meta'] : [];
		$step_meta  = is_array( $args['step_meta'] ) ? $args['step_meta'] : [];
		
		$override_status = $args['set_status'] !== NULL ? sanitize_key( (string) $args['set_status'] ) : NULL;
		$override_stock  = $args['set_stock'] !== NULL ? sanitize_text_field( (string) $args['set_stock'] ) : NULL;
		
		// قوانین کلی پروژه
		if ( $step_type === 'manual_in' ) {
			return [
				'done'    => 0,
				'skipped' => count( $item_ids ),
				'errors'  => [ 'manual_in مجاز نیست.' ],
			];
		}
		
		// --- یک بار وضعیت فعلی، انبار، process_id و آخرین استپ همه آیتم‌ها را بگیریم (بهینه) ---
		$placeholders = implode( ',', array_fill( 0, count( $item_ids ), '%d' ) );
		
		$latest_steps_sql = "
		SELECT s.item_id, s.step_type, s.date
		  FROM {$this->stock_item_step_log} s
		  JOIN (
		        SELECT item_id, MAX(date) AS max_date
		          FROM {$this->stock_item_step_log}
		      GROUP BY item_id
		  ) m ON m.item_id = s.item_id AND m.max_date = s.date
	";
		
		$sql = "
		SELECT si.item_id, si.process_id, si.status, si.current_stock, ls.step_type AS last_step
		  FROM {$this->stock_items} si
		  LEFT JOIN ( {$latest_steps_sql} ) ls ON ls.item_id = si.item_id
		 WHERE si.item_id IN ({$placeholders})
	";
		
		$states = $this->db->get_results( $this->db->prepare( $sql, $item_ids ), ARRAY_A );
		if ( empty( $states ) ) {
			return [
				'done'    => 0,
				'skipped' => count( $item_ids ),
				'errors'  => [ 'هیچ آیتمی یافت نشد.' ],
			];
		}
		
		$by_id = [];
		foreach ( $states as $row ) {
			$by_id[ (int) $row['item_id'] ] = [
				'process_id'    => (int) $row['process_id'],
				'status'        => (string) $row['status'],
				'current_stock' => (string) $row['current_stock'],
				'last_step'     => $row['last_step'] !== NULL ? (string) $row['last_step'] : '',
			];
		}
		
		$errors    = [];
		$done      = 0;
		$skipped   = 0;
		$to_update = []; // item_id => ['status' => ?, 'current_stock' => ?]
		
		$this->db->query( 'START TRANSACTION' );
		
		foreach ( $item_ids as $item_id ) {
			if ( ! isset( $by_id[ $item_id ] ) ) {
				$skipped ++;
				$errors[] = "آیتم {$item_id} یافت نشد.";
				continue;
			}
			
			$cur = $by_id[ $item_id ];
			
			// اعتبارسنجی اقدام مجاز
			$allowed      = $this->get_allowed_next_steps( [
				'status'         => $cur['status'],
				'last_step_type' => $cur['last_step'],
			] );
			$allowed_keys = array_map( static fn( $x ) => $x['key'], $allowed );
			
			if ( ! in_array( $step_type, $allowed_keys, TRUE ) ) {
				$skipped ++;
				$errors[] = "اقدام {$step_type} برای آیتم {$item_id} با وضعیت {$cur['status']} مجاز نیست.";
				continue;
			}
			
			if ( $step_type === 'manual_out' && $cur['status'] !== 'produced' ) {
				$skipped ++;
				$errors[] = "خروج دستی فقط در وضعیت produced مجاز است. (آیتم {$item_id})";
				continue;
			}
			
			// تعیین وضعیت بعدی
			$new_status = $override_status !== NULL && $override_status !== ''
				? $override_status
				: $this->get_next_status_after_step( [
					'current_status' => $cur['status'],
					'step_type'      => $step_type,
				] );
			
			// ثبت لاگ استپ با متد موجود (عدم تکرار کد)
			$step_id = $this->add_stock_item_step( [
				'item_id'    => $item_id,
				'process_id' => $cur['process_id'],
				'user_id'    => get_current_user_id(),
				'step_type'  => $step_type,
				'details'    => $details,
				'attachment' => $attachment,
				'date'       => $when,
				'meta'       => $step_meta,
			] );
			$this->save_meta_batch( 'item', $item_id, $item_meta, TRUE );
			
			if ( $step_id <= 0 ) {
				$skipped ++;
				$errors[] = "ثبت لاگ برای آیتم {$item_id} ناموفق بود.";
				continue;
			}
			
			// آماده‌سازی به‌روزرسانی وضعیت/انبار
			$upd = [];
			if ( $step_type == 'qccheck_approved' ) {
				$order_id       = $this->get_meta( 'item', $item_id, 'order_id', TRUE );
				$order_id       = $order_id !== NULL ? absint( nooshika_sanitize_numbers( $order_id ) ) : 0;
				$override_stock = ( $order_id > 0 ) ? 'deliver' : 'store';
				$new_status     = ( $order_id > 0 ) ? 'delivering' : 'produced';
			}
			
			if ( $new_status !== '' && $new_status !== $cur['status'] ) {
				$upd['status'] = $new_status;
			}
			if ( $override_stock !== NULL && $override_stock !== '' && $override_stock !== $cur['current_stock'] ) {
				$upd['current_stock'] = $override_stock;
			}
			if ( ! empty( $upd ) ) {
				$to_update[ $item_id ] = $upd;
			}
			
			$done ++;
		}
		
		// به‌روزرسانی‌های انبوه (در صورت نیاز)
		if ( ! empty( $to_update ) ) {
			// گروه‌بندی بر اساس ترکیب فیلدها برای کاهش تعداد UPDATE
			$groups = []; // key => ['status'=>?, 'stock'=>?, 'ids'=>[]]
			foreach ( $to_update as $iid => $upd ) {
				$k = ( $upd['status'] ?? '-' ) . '|' . ( $upd['current_stock'] ?? '-' );
				if ( ! isset( $groups[ $k ] ) ) {
					$groups[ $k ] = [
						'status' => $upd['status'] ?? NULL,
						'stock'  => $upd['current_stock'] ?? NULL,
						'ids'    => [],
					];
				}
				$groups[ $k ]['ids'][] = $iid;
			}
			
			foreach ( $groups as $g ) {
				$set_parts = [];
				$params    = [];
				if ( $g['status'] !== NULL ) {
					$set_parts[] = 'status = %s';
					$params[]    = $g['status'];
				}
				if ( $g['stock'] !== NULL ) {
					$set_parts[] = 'current_stock = %s';
					$params[]    = $g['stock'];
				}
				if ( empty( $set_parts ) ) {
					continue;
				}
				
				$ph      = implode( ',', array_fill( 0, count( $g['ids'] ), '%d' ) );
				$sql_upd = "
				UPDATE {$this->stock_items}
				   SET " . implode( ', ', $set_parts ) . "
				 WHERE item_id IN ( {$ph} )
			";
				$params  = array_merge( $params, $g['ids'] );
				
				$this->db->query( $this->db->prepare( $sql_upd, $params ) );
			}
		}
		
		$this->db->query( 'COMMIT' );
		
		return [
			'done'    => $done,
			'skipped' => $skipped,
			'errors'  => $errors,
		];
	}
	
	/**
	 * مقصد انبار بر اساس استپ (ساده‌شده و منطبق با get_meta)
	 *
	 * - فقط به نوع استپ وابسته است.
	 * - qccheck_approved: اگر متای order_id روی آیتم بود → deliver، وگرنه → store.
	 * - transfer_requested و transfer_approved: false (تغییری نده؛ جابه‌جایی همان‌جا انجام می‌شود).
	 * - transfer_rejected: بازگشت به انبار مبدا (از متای transfer_origin_stock آیتم)، اگر نبود → current_stock.
	 *
	 * @param   array  $args  {
	 *
	 * @type string    $step_type
	 * @type int       $item_id
	 * }
	 * @return string|false
	 */
	public function get_stock_destination_by_step( array $args = [] ) {
		$defaults = [
			'step_type' => '',
			'item_id'   => 0,
		];
		$args     = wp_parse_args( $args, $defaults );
		
		$step_type = sanitize_key( (string) $args['step_type'] );
		$item_id   = absint( $args['item_id'] );
		
		if ( $step_type === '' || $item_id <= 0 ) {
			return FALSE;
		}
		
		// current_stock آیتم
		$current_stock = (string) $this->db->get_var(
			$this->db->prepare(
				"SELECT current_stock FROM {$this->stock_items} WHERE item_id = %d LIMIT 1",
				$item_id
			)
		);
		
		switch ( $step_type ) {
			// تولید و QC
			case 're_produce_request':
			case 'request_production':
			case 'qccheck_requested':
				return 'produce';
			
			case 'qccheck_approved':
				$order_id = $this->get_meta( 'item', $item_id, 'order_id', TRUE );
				$order_id = $order_id !== NULL ? absint( nooshika_sanitize_numbers( $order_id ) ) : 0;
				
				return ( $order_id > 0 ) ? 'deliver' : 'store';
			
			case 'qccheck_rejected':
				return 'refund';
			
			// انتقال
			case 'transfer_requested':
			case 'transfer_approved':
				return FALSE;
			
			case 'transfer_rejected':
				$origin = $this->get_meta( 'item', $item_id, 'transfer_origin_stock', TRUE );
				
				return $origin ? sanitize_key( (string) $origin ) : $current_stock;
			
			// ارسال
			case 'delivery_prepared':
			case 'bill_of_lading_created':
				return 'deliver';
			
			case 'product_delivered':
				return 'delivered';
			
			// گارانتی / مرجوعی
			case 'warranty_returned':
				return 'refund';
			
			case 'warranty_repaired':
				return 'deliver';
			
			case 'warranty_rejected':
				return 'refund';
			
			// اسقاط
			case 'scrap_requested':
			case 'scrap_confirmed':
				return 'scrap';
			
			// خروج دستی
			case 'manual_out':
				return $current_stock ?: FALSE;
			
			default:
				return FALSE;
		}
	}
	
}
