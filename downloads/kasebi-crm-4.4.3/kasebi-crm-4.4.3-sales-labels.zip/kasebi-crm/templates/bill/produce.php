<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>
<html dir="rtl" lang="fa-IR">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="ThemeMarch">
    <title></title>
    <link rel="stylesheet" href="<?php echo KCP_ASSETS_URL; ?>css/bill.css?ver=<?php echo time(); ?>"/>
</head>
<body>
<div class="cs-container">
    <div class="cs-invoice cs-style1 tm-software">
        <div class="cs-invoice_in" id="download_section">
            <div class="print_page_header">
                <div class="header_data">
                    <div class="ccs-f14"><?php echo esc_html( $order_id ?: $item_id ); ?></div>
                    <div class="cs-f14"><?php echo date_i18n( 'Y/m/d' ); ?></div>
                </div>
                <div class="display-flex align-item-center cs-hide_print">
                    <div class="cs-m0 tm-align-item-center cs-invoice_btns tm-align-item-center cs-hide_print cs-p0">
                        <a href="javascript:window.print()" class="cs-invoice_btn cs-p0">
                            <svg class="cs-primary_color" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                <path
                                    d="M384 368h24a40.12 40.12 0 0040-40V168a40.12 40.12 0 00-40-40H104a40.12 40.12 0 00-40 40v160a40.12 40.12 0 0040 40h24"
                                    fill="none" stroke="currentColor" stroke-linejoin="round"
                                    stroke-width="32"></path>
                                <rect x="128" y="240" width="256" height="208" rx="24.32" ry="24.32" fill="none"
                                      stroke="currentColor" stroke-linejoin="round" stroke-width="32"></rect>
                                <path d="M384 128v-24a40.12 40.12 0 00-40-40H168a40.12 40.12 0 00-40 40v24"
                                      fill="none"
                                      stroke="currentColor" stroke-linejoin="round" stroke-width="32"></path>
                                <circle cx="392" cy="184" r="24"></circle>
                            </svg>
                            <span class="cs-primary_color">پرینت</span>
                        </a>
                    </div>
                </div>
            </div>
            <div class="print_page_body content-block">
                <div class="display-flex cs-mb10 space-between cs-f12 each_body_block">
                    <div class="cs-invoice_left" style="flex-basis:30%">
                        <span class="cs-primary_color">برند تولید کننده:</span>
                        <strong><?php echo $brand; ?></strong>
                    </div>
                    <div class="factor_title" style="flex-basis:30%;text-align: center">
                        حواله برگشت از خرید
                    </div>
                    <div class="cs-invoice_right" style="flex-basis:30%">
                        <div>
                            <span>سریال کالا:</span>
                            <strong><?= $item_data['serial']; ?></strong>
                        </div>
                        <div>
                            <span>تاریخ:</span>
                            <strong><?php echo date_i18n( 'Y/m/d' ); ?></strong>
                        </div>
                    </div>
                </div>
                <div class="cs-table cs-style2 tm-border-none cs-mb20 padding-right-left">
                    <table>
                        <thead class="border-bottom-1 product_head each_body_block">
                        <tr class="cs-secondary_color">
                            <th class="cs-width_5 cs-normal">کالا</th>
                            <th class="cs-width_2 cs-normal">متراژ</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr class="product_row each_body_block">
                            <td class="cs-width_5 cs-primary_color cs-f13"><?php echo trim( $title_parts[0] ) ?>
                            </td>
                            <td class="cs-width_1 cs-primary_color cs-f13"><?php echo trim( $title_parts[1] ); ?></td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="page_footer content-block">
                <div class="display-flex space-between after_factor_text">
                    اینجانب ............ به کدملی ........ اقلام فوق الذکر را تحویل گرفتم.
                </div>
                <div class="display-flex space-between after_factor_text">
                    <div>انباردار</div>
                    <div>مسئول انبار</div>
                    <div>راننده</div>
                    <div>حسابداری</div>
                    <div>تحویل گیرنده</div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="<?php echo KCP_ASSETS_URL; ?>js/factor/jquery.min.js"></script>
<script src="<?php echo KCP_ASSETS_URL; ?>js/factor/jspdf.min.js"></script>
<script src="<?php echo KCP_ASSETS_URL; ?>js/factor/html2canvas.min.js"></script>
<script src="<?php echo KCP_ASSETS_URL; ?>js/factor/main.js"></script>
</body>
</html>