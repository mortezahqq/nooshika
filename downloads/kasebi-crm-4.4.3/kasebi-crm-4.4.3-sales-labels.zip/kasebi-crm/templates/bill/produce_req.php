<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
$base_DB    = new kcp_db();
$DB         = new kcp_stock();
$items      = $_REQUEST['items'];
$items      = explode( ',', $items );
$shop_title = get_option( 'ksm_shop_name' );

$grouped = [];

foreach ( $items as $item_id ) {
	$item_data = $DB->get_stock_item_data( $item_id );
	
	$order_id = $DB->get_meta( 'item', $item_id, 'order_id', TRUE ) ?: '';
	$brand    = $DB->get_meta( 'item', $item_id, 'brand', TRUE ) ?: '';
	$note     = $DB->get_meta( 'item', $item_id, 'note', TRUE ) ?: '';
	
	$product = $item_data['product_id'] ?? 'no_product';
	
	$brand   = $brand !== '' ? $brand : 'no_brand';
	$product = $product !== '' ? $product : 'no_product';
	
	if ( $order_id !== '' ) {
		$group_key   = 'order_' . $order_id;
		$group_label = 'درخواست تولید سفارش ' . $order_id;
	} else {
		$group_key   = 'note_' . md5( $note ); // برای یکتا بودن key
		$group_label = $note !== '' ? $note : '-';
	}
	
	if ( ! isset( $grouped[ $brand ][ $product ][ $group_key ] ) ) {
		$grouped[ $brand ][ $product ][ $group_key ]                = $item_data;
		$grouped[ $brand ][ $product ][ $group_key ]['count']       = 0;
		$grouped[ $brand ][ $product ][ $group_key ]['group_label'] = $group_label;
		$grouped[ $brand ][ $product ][ $group_key ]['order_id']    = $order_id;
		$grouped[ $brand ][ $product ][ $group_key ]['item_ids']    = [];
	}
	
	$grouped[ $brand ][ $product ][ $group_key ]['count'] ++;
	$grouped[ $brand ][ $product ][ $group_key ]['item_ids'][] = (int) $item_id;
}
$size_taxonomy = 'pa_size';

?>
<html dir="rtl" lang="fa-IR">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="ThemeMarch">
    <title>درخواست خرید - <?= $shop_title; ?></title>
    <link rel="stylesheet" href="<?php echo KCP_ASSETS_URL; ?>css/bill.css?ver=<?php echo time(); ?>"/>
    <style>
        @page {
            size: A4;
            margin: 0;
        }
        
        body {
            margin: 0;
        }
        
        .cs-table.cs-style2 td {
            border-bottom: 1px solid #c4c4c4;
            border-left: 1px solid #c4c4c4;
        }
        
        .cs-table.cs-style2 td:first-child {
            border-right: 1px solid #c4c4c4;
        }
        
        .cs-container {
            width: 210mm;
            min-height: 297mm;
            padding: 5mm;
            margin-left: auto;
            margin-right: auto;
            color: #222222;
            box-sizing: border-box;
            border: 0;
        }
        
        span.sub-text {
            display: block;
        }
    </style>
</head>
<body>
<?php
foreach ( $grouped as $brand => $brand_items ) {
	?>
    <div class="cs-container">
        <div class="cs-invoice cs-style1 tm-software">
            <div class="cs-invoice_in" id="download_section">
                <div class="print_page_header">
                    <div class="header_data">
                        <div class="ccs-f14"><?php echo esc_html( ! empty( $items ) ? reset( $items ) : '-' ); ?></div>
                        <div class="cs-f14"><?php echo date_i18n( 'Y/m/d' ); ?></div>
                    </div>
                    <div class="display-flex align-item-center cs-hide_print">
                        <div
                            class="cs-m0 tm-align-item-center cs-invoice_btns tm-align-item-center cs-hide_print cs-p0">
                            <a href="javascript:window.print()" class="cs-invoice_btn cs-p0">
                                <svg class="cs-primary_color" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                    <path
                                        d="M384 368h24a40.12 40.12 0 0040-40V168a40.12 40.12 0 00-40-40H104a40.12 40.12 0 00-40 40v160a40.12 40.12 0 0040 40h24"
                                        fill="none" stroke="currentColor" stroke-linejoin="round"
                                        stroke-width="32"></path>
                                    <rect x="128" y="240" width="256" height="208" rx="24.32" ry="24.32" fill="none"
                                          stroke="currentColor" stroke-linejoin="round" stroke-width="32"></rect>
                                    <path d="M384 128v-24a40.12 40.12 0 00-40-40H168a40.12 40.12 0 00-40 40v24"
                                          fill="none"
                                          stroke="currentColor" stroke-linejoin="round" stroke-width="32"></path>
                                    <circle cx="392" cy="184" r="24"></circle>
                                </svg>
                                <span class="cs-primary_color">پرینت</span>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="print_page_body cs-mb2 content-block">
                    <div class="display-flex cs-mb20 space-between cs-f12 each_body_block">
                        <div class="cs-invoice_left" style="flex-basis:30%">
                            <span class="cs-primary_color">برند تولید کننده:</span>
                            <strong><?php echo $brand; ?></strong>
                        </div>
                        <div class="factor_title" style="flex-basis:30%;text-align: center">
                            درخواست خرید
                        </div>
                        <div class="cs-invoice_right" style="flex-basis:30%">
                            <div>
                                <span>تاریخ:</span>
                                <strong><?php echo date_i18n( 'Y/m/d' ); ?></strong>
                            </div>
                        </div>
                    </div>
                    <div class="cs-table cs-style2 tm-border-none cs-mb20 padding-right-left">
                        <table>
                            <thead class="border-bottom-1 product_head each_body_block">
                            <tr class="cs-secondary_color fs-12px">
                                <th class="cs-width_5 cs-normal">تصویر</th>
                                <th class="cs-width_5 cs-normal">کالا</th>
                                <th class="cs-width_2 cs-normal">تعداد</th>
                                <th class="cs-width_2 cs-normal">متراژ</th>
                                <th class="cs-width_2 cs-normal">ملاحظات</th>
                            </tr>
                            </thead>
                            <tbody>
							<?php
							foreach ( $brand_items as $product_id => $grouped_items ) {
								$product = wc_get_product( $product_id );
								if ( ! $product ) {
									continue;
								}
								$child_size  = $product->get_attribute( $size_taxonomy );
								$size_id     = get_term_by( 'name', $child_size, $size_taxonomy )->term_id;
								$size_metric = get_term_meta( $size_id, 'size_squere', TRUE ) ?: 0;
								foreach ( $grouped_items as $item_data ) {
									$title        = $item_data['product_name'];
									$count        = $item_data['count'];
									$label        = $item_data['group_label'];
									$order_id     = $item_data['order_id'];
									$item_note    = '';
									$cashier_note = '';
									$meterage     = $size_metric ? $count * $size_metric : '-';
									if ( ! empty( $item_data['item_ids'][0] ) ) {
										$item_meta = $DB->get_meta( 'item', (int) $item_data['item_ids'][0] );
										if ( ! empty( $item_meta['cut_carpet'] ) ) {
											$cut_length_cm = (float) ( $item_meta['cut_length_cm'] ?? $item_meta['carpet_height'] ?? 0 );
											$meterage      = $cut_length_cm > 0 ? number_format( $cut_length_cm / 100, 2 ) : '-';
										}
									}
									if ( $order_id ) {
										$order = wc_get_order( $order_id );
										if ( $order ) {
											$cashier_note = $order->get_meta( 'cashier_note', TRUE );
											foreach ( $order->get_items() as $order_item_id => $item ) {
												/** @var WC_Order_Item_Product $item */
												$item_product_id   = (int) $item->get_product_id();
												$item_variation_id = (int) $item->get_variation_id();
												if (
													$item_product_id === (int) $product_id ||
													$item_variation_id === (int) $product_id
												) {
													$item_note = $item->get_meta( 'note', TRUE );
													break;
												}
											}
										}
									}
									$product_image_id = $product->get_image_id();
									
									if ( ! $product_image_id && $product->is_type( 'variation' ) ) {
										$parent_product = wc_get_product( $product->get_parent_id() );
										if ( $parent_product ) {
											$product_image_id = $parent_product->get_image_id();
										}
									}
									
									$product_image_url = $product_image_id
										? wp_get_attachment_image_url( $product_image_id, 'thumbnail' )
										: wc_placeholder_img_src( 'thumbnail' );
									?>
                                    <tr class="product_row each_body_block">
                                        <td class="cs-width_1 cs-primary_color cs-f13">
                                            <img
                                                src="<?php echo esc_url( $product_image_url ); ?>"
                                                alt="<?php echo esc_attr( $title ); ?>"
                                                style="width:50px;height:50px;object-fit:cover;border-radius:4px;"
                                            >
                                        </td>
                                        <td class="cs-width_5 cs-primary_color cs-f13"><?php echo $title ?></td>
                                        <td class="cs-width_1 cs-primary_color cs-f13"><?php echo $count; ?></td>
                                        <td class="cs-width_1 cs-primary_color cs-f13"><?php echo $meterage; ?></td>
                                        <td class="cs-width_1 cs-primary_color cs-f13"><?php echo $label; ?>
											<?php
											if ( $cashier_note ) {
												echo "<span class='sub-text'>$cashier_note</span>";
											}
											if ( $item_note ) {
												echo "<span class='sub-text'>$item_note</span>";
											}
											?>
                                        </td>
                                    </tr>
									<?php
								}
							}
							?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="page_footer content-block">
                    <div class="display-flex space-between after_factor_text ">
                        <div>کارشناس فروش:</div>
                        <div>مدیر سفارشات:</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
	<?php
}
?>
<script src="<?php echo KCP_ASSETS_URL; ?>js/factor/jquery.min.js"></script>
<script src="<?php echo KCP_ASSETS_URL; ?>js/factor/jspdf.min.js"></script>
<script src="<?php echo KCP_ASSETS_URL; ?>js/factor/html2canvas.min.js"></script>
<script src="<?php echo KCP_ASSETS_URL; ?>js/factor/main.js"></script>
</body>
</html>
