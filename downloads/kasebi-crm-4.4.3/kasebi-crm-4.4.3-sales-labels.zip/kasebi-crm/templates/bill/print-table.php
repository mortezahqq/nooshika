<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

$shop_title = get_option( 'ksm_shop_name' );
$payload    = isset( $_REQUEST['payload_b64'] )
	? wp_unslash( $_REQUEST['payload_b64'] )
	: '';
$payload    = base64_decode( sanitize_text_field( wp_unslash( $payload ) ) );
$data       = json_decode( $payload, TRUE );

if ( empty( $data ) || ! is_array( $data ) ) {
	wp_die( 'داده‌ای برای پرینت ارسال نشده است.' );
}

$title   = sanitize_text_field( $data['title'] ?? 'پرینت جدول' );
$columns = $data['columns'] ?? [];
$rows    = $data['rows'] ?? [];

if ( ! is_array( $columns ) ) {
	$columns = [];
}

if ( ! is_array( $rows ) ) {
	$rows = [];
}

?>
<html dir="rtl" lang="fa-IR">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="ThemeMarch">
    <title><?php echo esc_html( $title . ' - ' . $shop_title ); ?></title>
    <link rel="stylesheet" href="<?php echo esc_url( KCP_ASSETS_URL . 'css/bill.css?ver=' . time() ); ?>"/>
    <style>
        @page {
            size: A4;
            margin: 0;
        }
        
        body {
            margin: 0;
        }
        
        .cs-container {
            width: 210mm;
            min-height: 297mm;
            padding: 5mm;
            margin-left: auto;
            margin-right: auto;
            color: #222222;
            box-sizing: border-box;
            border: 0;
        }
        
        .print-table-title {
            text-align: center;
            font-size: 17px;
            font-weight: 700;
            margin-bottom: 15px;
        }
        
        .cs-table.cs-style2 table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .cs-table.cs-style2 th,
        .cs-table.cs-style2 td {
            border-bottom: 1px solid #c4c4c4;
            border-left: 1px solid #c4c4c4;
            padding: 7px;
            text-align: right;
            vertical-align: middle;
            font-size: 12px;
        }
        
        .cs-table.cs-style2 th:first-child,
        .cs-table.cs-style2 td:first-child {
            border-right: 1px solid #c4c4c4;
        }
        
        .cs-table.cs-style2 th {
            font-weight: 700;
            background: #f7f7f7;
        }
        
        .print-table-img {
            width: 55px;
            height: 55px;
            object-fit: cover;
            display: block;
            margin: 0 auto 4px;
            border-radius: 4px;
        }
        
        .print-empty {
            text-align: center;
            padding: 20px;
            color: #777;
        }
    </style>
</head>
<body>
<div class="cs-container">
    <div class="cs-invoice cs-style1 tm-software">
        <div class="cs-invoice_in" id="download_section">
            <div class="print_page_header">
                <div class="header_data">
                    <div class="cs-f14"><?php echo date_i18n( 'Y/m/d' ); ?></div>
                </div>
                <div class="display-flex align-item-center cs-hide_print">
                    <div class="cs-m0 tm-align-item-center cs-invoice_btns tm-align-item-center cs-hide_print cs-p0">
                        <a href="javascript:window.print()" class="cs-invoice_btn cs-p0">
                            <svg class="cs-primary_color" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                <path
                                    d="M384 368h24a40.12 40.12 0 0040-40V168a40.12 40.12 0 00-40-40H104a40.12 40.12 0 00-40 40v160a40.12 40.12 0 0040 40h24"
                                    fill="none" stroke="currentColor" stroke-linejoin="round"
                                    stroke-width="32"></path>
                                <rect x="128" y="240" width="256" height="208" rx="24.32" ry="24.32" fill="none"
                                      stroke="currentColor" stroke-linejoin="round" stroke-width="32"></rect>
                                <path d="M384 128v-24a40.12 40.12 0 00-40-40H168a40.12 40.12 0 00-40 40v24"
                                      fill="none"
                                      stroke="currentColor" stroke-linejoin="round" stroke-width="32"></path>
                                <circle cx="392" cy="184" r="24"></circle>
                            </svg>
                            <span class="cs-primary_color">پرینت</span>
                        </a>
                    </div>
                </div>
            </div>

            <div class="print_page_body content-block">
                <div class="display-flex cs-mb10 space-between cs-f12 each_body_block">
                    <div class="factor_title" style="flex-basis:100%;text-align: center">
						<?php echo esc_html( $title ); ?>
                    </div>
                </div>

                <div class="cs-table cs-style2 tm-border-none cs-mb20 padding-right-left">
					<?php if ( empty( $columns ) || empty( $rows ) ) : ?>
                        <div class="print-empty">داده‌ای برای نمایش وجود ندارد.</div>
					<?php else : ?>
                        <table>
                            <thead class="border-bottom-1 product_head each_body_block">
                            <tr class="cs-secondary_color">
								<?php foreach ( $columns as $column ) : ?>
                                    <th class="cs-normal"><?php echo esc_html( $column ); ?></th>
								<?php endforeach; ?>
                            </tr>
                            </thead>
                            <tbody>
							<?php foreach ( $rows as $row ) : ?>
                                <tr class="product_row each_body_block">
									<?php
									foreach ( $row as $cell ) :
										$cell_text = '';
										$cell_image = '';
										$cell_colspan = 1;
										$cell_rowspan = 1;
										
										if ( is_array( $cell ) ) {
											$cell_text    = $cell['text'] ?? '';
											$cell_image   = $cell['image'] ?? '';
											$cell_colspan = max( 1, absint( $cell['colspan'] ?? 1 ) );
											$cell_rowspan = max( 1, absint( $cell['rowspan'] ?? 1 ) );
										} else {
											$cell_text = $cell;
										}
										?>
                                        <td
                                            class="cs-primary_color cs-f13"
                                            colspan="<?php echo esc_attr( $cell_colspan ); ?>"
                                            rowspan="<?php echo esc_attr( $cell_rowspan ); ?>"
                                        >
											<?php if ( ! empty( $cell_image ) ) : ?>
                                                <img
                                                    class="print-table-img"
                                                    src="<?php echo esc_url( $cell_image ); ?>"
                                                    alt=""
                                                >
											<?php endif; ?>
											
											<?php if ( $cell_text !== '' ) : ?>
												<?php echo nl2br( esc_html( $cell_text ) ); ?>
											<?php endif; ?>
                                        </td>
									<?php endforeach; ?>
                                </tr>
							<?php endforeach; ?>
                            </tbody>
                        </table>
					<?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="<?php echo esc_url( KCP_ASSETS_URL . 'js/factor/jquery.min.js' ); ?>"></script>
<script src="<?php echo esc_url( KCP_ASSETS_URL . 'js/factor/jspdf.min.js' ); ?>"></script>
<script src="<?php echo esc_url( KCP_ASSETS_URL . 'js/factor/html2canvas.min.js' ); ?>"></script>
<script src="<?php echo esc_url( KCP_ASSETS_URL . 'js/factor/main.js' ); ?>"></script>
</body>
</html>