<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

$clean_total_value = static function( $value ): string {
	if ( $value === NULL || $value === '' ) {
		return '';
	}
	
	$value = nooshika_sanitize_numbers( wp_unslash( (string) $value ) );
	
	return preg_replace( '/[^\d]/u', '', $value );
};
$list_order        = [
	'newest'     => 'جدید ترین',
	'oldest'     => 'قدیمی ترین',
	'high-price' => 'بیشترین قیمت',
	'low-price'  => 'کمترین قیمت',
];
$sort_map          = [
	'newest'     => [
		'order_by' => 'date',
		'order'    => 'DESC',
	],
	'oldest'     => [
		'order_by' => 'date',
		'order'    => 'ASC',
	],
	'high-price' => [
		'order_by' => 'total',
		'order'    => 'DESC',
	],
	'low-price'  => [
		'order_by' => 'total',
		'order'    => 'ASC',
	],
];

$per_page_key = basename( __FILE__, '.php' );
$per_page_key = "crm_{$per_page_key}_per_page";
$user_id      = get_current_user_id();
$defaults     = [
	'page_number' => 1,
	'per_page'    => get_user_meta( $user_id, $per_page_key, TRUE ) ?: 20,
	'date'        => [
		'from' => '',
		'to'   => '',
	],
	'search'      => '',
	'marketer_id' => '',
	'status'      => '',
	'order_id'    => '',
	'city'        => '',
	'state'       => '',
	'product_id'  => '',
	'total'       => [
		'from' => '',
		'to'   => '',
	],
	'sort_order'  => 'newest',
];
$args         = wp_parse_args( $_REQUEST, $defaults );
$args         = array_map( fn( $v ) => $v == 0 ? '' : $v, $args );
$has_filter   = kcp_page_has_filter( $args, $defaults );
extract( $args );
update_user_meta( $user_id, $per_page_key, $per_page );
$offset = ( $page_number - 1 ) * $per_page;

$date        = is_array( $date ) ? $date : [];
$total_range = is_array( $args['total'] ?? NULL ) ? $args['total'] : [];
$order_by    = $sort_map[ $sort_order ]['order_by'];
$order       = $sort_map[ $sort_order ]['order'];

$date_from = $date['from'] ?? '';
$date_to   = $date['to'] ?? '';
$min_total = $clean_total_value( $total_range['from'] ?? '' );
$max_total = $clean_total_value( $total_range['to'] ?? '' );

if ( ! is_current_user_admin( 0, TRUE ) ) {
	$args['marketer_id'] = get_current_user_id();
	$marketer_id         = $args['marketer_id'];
}
$order_index = new Kasebi_Order_Index();
$DB          = new kcp_db();
$states      = WC()->countries->get_states( 'IR' );
$statuses    = wc_get_order_statuses();
$order_query = $order_index->find_orders( [
	'per_page'    => $per_page,
	'page_number' => $page_number,
	'status'      => $args['status'],
	'date'        => [
		'from' => $date_from,
		'to'   => $date_to,
	],
	'search'      => $search,
	'marketer_id' => $args['marketer_id'],
	'product_id'  => $product_id,
	'city'        => $city,
	'state'       => $state,
	'order_id'    => $order_id,
	'min_total'   => $min_total,
	'max_total'   => $max_total,
	'order_by'    => $order_by,
	'order'       => $order,
] );

$order_ids     = array_map( 'absint', (array) ( $order_query['result'] ?? [] ) );
$pagination    = is_array( $order_query['pagination'] ?? NULL ) ? $order_query['pagination'] : [];
$total_results = (int) ( $pagination['total'] ?? 0 );
$total_page    = (int) ( $pagination['total_pages'] ?? 0 );

$badges            = [
	'pending'    => 'warning',
	'processing' => 'purple',
	'completed'  => 'success',
	'delivered'  => 'teal',
	'cancelled'  => 'danger',
];
$indexed_marketers = $order_index->get_indexed_marketers();
$marketer_options  = [ 0 => 'همه موارد' ];

foreach ( $indexed_marketers as $indexed_marketer_id => $indexed_marketer ) {
	$marketer_options[ $indexed_marketer_id ] = $indexed_marketer['label'] ?? get_user_name_by_id( $indexed_marketer_id );
}

$indexed_products = $order_index->get_indexed_products( [
	'limit' => 300,
] );

$product_options = [ 0 => 'همه موارد' ];

foreach ( $indexed_products as $indexed_product_id => $indexed_product ) {
	$product_options[ $indexed_product_id ] = $indexed_product['label'] ?? get_the_title( $indexed_product_id );
}

$city_options = [ 0 => 'همه موارد' ];

if ( ! empty( $state ) && function_exists( 'PWS' ) ) {
	$state_cities = PWS()::cities( $state );
	
	if ( is_array( $state_cities ) ) {
		$city_options += $state_cities;
	}
}
$query_args = [
	'action'      => 'print',
	'type'        => 'orders',
	'per_page'    => $per_page,
	'page_number' => $page_number,
	'offset'      => $offset,
	
	'status'      => $selected_status,
	'date'        => [
		'from' => $date_from,
		'to'   => $date_to,
	],
	'search'      => $search,
	'marketer_id' => $args['marketer_id'],
	'product_id'  => $product_id,
	'city'        => $city,
	'state'       => $state,
	'order_id'    => $order_id,
	
	'min_total' => $min_total,
	'max_total' => $max_total,
	
	'order_by' => 'date',
	'order'    => 'DESC',
];
$query_args = array_filter( $query_args, static function( $value ) {
	if ( is_array( $value ) ) {
		return (bool) array_filter( $value, static function( $nested_value ) {
			return $nested_value !== '' && $nested_value !== NULL && $nested_value !== [];
		} );
	}
	
	return $value !== '' && $value !== NULL && $value !== [];
} );
$list_order = [
	'newest'     => 'جدید ترین',
	'oldest'     => 'قدیمی ترین',
	'high-price' => 'بیشترین قیمت',
	'low-price'  => 'کمترین قیمت',
];
?>
<div class="nk-block-head nk-block-head-sm">
    <div class="nk-block-between">
        <div class="nk-block-head-content">
            <h3 class="nk-block-title page-title">لیست سفارشات</h3>
            <div class="nk-block-des text-soft">
                <p class="mb-0">شما در مجموع <?php echo $total_results; ?> سفارش دارید.</p>
            </div>
        </div>
        <div class="nk-block-head-content">
            <div class="toggle-wrap nk-block-tools-toggle">
                <div class="toggle-expand-content">
                    <ul class="nk-block-tools g-3">
                        <li class="nk-block-tools-opt">
                            <a href="<?php echo add_query_arg( $query_args, home_url( '/crm/' ) ); ?>"
                               class="btn btn-info" target="_blank">
                                <em class="icon ni ni-printer-fill"></em><span>پرینت</span>
                            </a>
                        </li>
                        <li class="nk-block-tools-opt">
                            <a href="<?php echo home_url( '/crm/order-new/' ); ?>" target="_blank"
                               class=" btn btn-icon btn-primary"><em class="icon ni ni-plus"></em></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="nk-block">
    <div class="card card-stretch">
        <div class="card-inner-group">
            <div class="card-inner position-relative card-tools-toggle">
                <div class="card-title-group">
                    <div class="card-tools">
                    </div>
                    <div class="card-tools ">
                        <ul class="btn-toolbar gx-1">
                            <div class="dropdown">
                                <a href="#" class="btn btn-trigger btn-icon dropdown-toggle" data-bs-toggle="dropdown">
                                    <em class="icon ni ni-swap-v"></em>
                                </a>
                                <div class="dropdown-menu dropdown-menu-end">
                                    <ul class="link-check">
                                        <li><span>مرتب سازی</span></li>
										<?php
										foreach ( $list_order as $key => $label ) {
											?>
                                            <li class="change_list_order<?php
											echo $key == $sort_order ? ' active' : ''; ?>"
                                                data-order="<?php
											    echo esc_attr( $key ); ?>">
                                                <a href="#"><?php
													echo esc_html( $label ); ?></a>
                                            </li>
											<?php
										}
										?>
                                    </ul>
                                </div>
                            </div>
                            <li class="btn-toolbar-sep"></li>
                            <li>
								<?php
								$filter_fields = [
									[
										'type'  => 'date-range',
										'label' => 'تاریخ',
										'name'  => 'date',
										'value' => [
											'from' => $date_from ?? '',
											'to'   => $date_to ?? '',
										],
									],
									[
										'type'  => 'text',
										'label' => 'شماره سفارش',
										'name'  => 'order_id',
										'col'   => 4,
										'value' => $order_id,
									],
									[
										'type'  => 'text',
										'label' => 'جستجوی سفارش',
										'name'  => 'search',
										'col'   => 8,
										'value' => $search,
									],
									[
										'type'    => 'select',
										'label'   => 'وضعیت',
										'name'    => 'status',
										'value'   => $status,
										'col'     => 6,
										'options' => [ 0 => 'همه موارد' ] + $statuses,
									],
									'marketer' => [
										'type'    => 'select',
										'label'   => 'ثبت کننده',
										'name'    => 'marketer_id',
										'value'   => $marketer_id,
										'col'     => 6,
										'options' => $marketer_options,
									],
									[
										'type'    => 'select',
										'label'   => 'محصول',
										'name'    => 'product_id',
										'value'   => $product_id,
										'col'     => 12,
										'options' => $product_options,
										'data'    => [
											'search' => 'on',
										],
									],
									[
										'type'  => 'num-range',
										'label' => 'مبلغ سفارش',
										'name'  => 'total',
										'class' => 'price_input',
										'value' => [
											'from' => $total['from'] ?? '',
											'to'   => $total['to'] ?? '',
										],
									],
									[
										'type'    => 'select',
										'label'   => 'استان',
										'name'    => 'state',
										'value'   => $state,
										'col'     => 6,
										'options' => [ 0 => 'همه موارد' ] + $states,
										'class'   => 'load_city',
										'data'    => [
											'target' => '#order_city_filter',
											'search' => 'on',
										],
									],
									[
										'type'    => 'select',
										'label'   => 'شهر',
										'name'    => 'city',
										'value'   => $city,
										'col'     => 6,
										'options' => $city_options,
										'id'      => 'order_city_filter',
										'data'    => [
											'search' => 'on',
										],
									],
								];
								if ( ! is_current_user_admin( 0, TRUE ) ) {
									unset( $filter_fields['marketer'] );
								}
								echo crm_get_template( 'partials/filter-dropdown.php', [
									'has_filter'    => $has_filter,
									'filter_fields' => $filter_fields,
								] );
								?>
                            </li>
                            <li class="btn-toolbar-sep"></li>
                            <li>
								<?php
								echo crm_get_template( 'partials/per-page-selector.php', [
									'per_page' => $per_page,
								] );
								?>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="card-inner p-0 overflow-auto">
                <div class="nk-tb-list nk-tb-ulist is-compact">
                    <div class="nk-tb-item nk-tb-head">
                        <div class="nk-tb-col"><span class="sub-text">#</span></div>
                        <div class="nk-tb-col"><span class="sub-text">تاریخ</span></div>
                        <div class="nk-tb-col"><span class="sub-text">مشتری</span></div>
                        <div class="nk-tb-col"><span class="sub-text">وضعیت</span></div>
                        <div class="nk-tb-col"><span class="sub-text">آیتم های سفارش</span></div>
                        <div class="nk-tb-col"><span class="sub-text">مبلغ کل</span></div>
                        <div class="nk-tb-col"><span class="sub-text">آدرس</span></div>
                        <div class="nk-tb-col nk-tb-col-tools text-end">
                        </div>
                    </div>
					<?php
					foreach ( $order_ids as $order_id ) {
						$order = wc_get_order( $order_id );
						if ( ! $order ) {
							continue;
						}
						$user_id      = $order->get_customer_id();
						$order_edit   = get_edit_post_link( $order_id );
						$items        = $order->get_items();
						$status       = $order->get_status();
						$status_label = $statuses[ 'wc-' . $status ];
						$status_badge = "bg-" . $badges[ $status ];
						$order_date   = $order->get_date_created();
						$state        = $order->get_billing_state();
						$cities       = PWS()::cities( $state );
						$city         = $order->get_billing_city();
						$address      = $order->get_billing_address_1();
						$postcode     = $order->get_billing_postcode();
						$full_address = $state ?
							$states[ $state ] . '، ' . $cities[ $city ] . '<br>' . $address . '<br>' . $postcode
							: '-';
						$note         = $order->get_meta( 'cashier_note', TRUE );
						$files        = $order->get_meta( 'order_files', TRUE );
						$marketer_id  = $order->get_meta( 'marketer_id', TRUE );
						?>
                        <div class="nk-tb-item">
                            <div class="nk-tb-col">
                                <a href="<?php echo $order_edit; ?>" target="_blank">
                                    <span><?php echo $order_id; ?></span>
                                </a>
                            </div>
                            <div class="nk-tb-col">
                                <span
                                    class="sub-text"><?php echo date_i18n( 'j F Y', strtotime( $order_date ) ); ?></span>
                            </div>
                            <div class="nk-tb-col">
								<?php
								echo crm_get_template( 'partials/user-card.php', [
									'user_id'    => $user_id,
									'show_phone' => TRUE,
								] );
								?>
                            </div>
                            <div class="nk-tb-col">
                                <span class="badge <?php echo $status_badge; ?>"><?php echo $status_label; ?></span>
                            </div>
                            <div class="nk-tb-col">
								<?php
								$counter = 0;
								foreach ( $items as $item ) {
									$counter ++;
									if ( $counter <= 2 ) {
										echo '<span class="sub-text">' . esc_html( $item->get_name() ) . '</span>';
									} else {
										echo '<span class="sub-text">...</span>';
										break;
									}
								}
								?>
                            </div>
                            <div class="nk-tb-col">
                                <span class="tb-amount">
                                    <?php echo number_format( $order->get_total() ); ?>
                                    <span class="currency">تومان</span>
                                </span>
                            </div>
                            <div class="nk-tb-col">
                                <div class="sub-text"><?php echo $full_address; ?></div>
                            </div>
                            <div class="nk-tb-col">
                                <ul class="nk-tb-actions gx-2">
									<?php
									if ( $note ) {
										?>
                                        <li>
                                            <div class="btn btn-sm btn-icon btn-trigger"
                                                 data-bs-toggle="popover"
                                                 data-bs-trigger="click"
                                                 data-bs-html="true"
                                                 title="یادداشت سفارش"
                                                 data-bs-content="<?php echo wpautop( $note ); ?>"
                                                 data-bs-placement="top">
                                                <em class="icon ni ni-note-add-c"></em>
                                            </div>
                                        </li>
										<?php
									}
									$hidden_actions = [
										[
											'link'  => '',
											'title' => get_user_name_by_id( $marketer_id ),
											'icon'  => 'ni-user-check',
										],
										[
											'link'  => '',
											'title' => 'جزئیات سفارش',
											'class' => 'load_order_items_table',
											'icon'  => 'ni-package',
											'data'  => [
												'order-id' => $order_id,
											],
										],
									
									];
									if ( is_current_user_admin() ) {
										$hidden_actions['delete'] = [
											'link'  => '',
											'title' => 'حذف سفارش',
											'icon'  => 'ni-trash',
											'class' => 'delete_db_item',
											'data'  => [
												'action'  => 'crm_delete_order',
												'item_id' => $order_id,
												'page'    => '/crm/sale-orders',
											],
										];
									}
									echo crm_get_template( 'partials/row-actions-hidden.php', [
										'actions' => $hidden_actions,
									] );
									?>
                                    <li>
										<?php
										$factors = [
											'pre'  => 'پیش فاکتور',
											'roll' => 'فاکتور فروش',
											'acc'  => 'فاکتور پرداخت',
										];
										$actions = [];
										foreach ( $factors as $factor => $label ) {
											$actions[] = [
												'link'   => home_url() . "/crm/?action=factor&type=$factor&order_id=$order_id",
												'title'  => $label,
												'target' => '_blank',
											];
										}
										
										echo crm_get_template( 'partials/row-actions-dropdown.php', [
											'actions'   => $actions,
											'main_icon' => 'printer',
											'title'     => 'چاپ فاکتور',
										] );
										?>
                                    </li>
									<?php
									if ( $files ) {
										?>
                                        <li>
											<?php
											$actions = [];
											foreach ( $files as $file ) {
												extract( $file );
												$file_data = $DB->get_uploaded_file_data( $url );
												if ( ! $file_data ) {
													$file_name = $file['title'];
												} else {
													$file_name = $file_data['original_name'];
												}
												$actions[] = [
													'link'     => $url,
													'title'    => $file_name,
													'icon'     => 'ni-download',
													'target'   => '_blank',
													'download' => TRUE,
												];
											}
											echo crm_get_template( 'partials/row-actions-dropdown.php', [
												'actions'   => $actions,
												'main_icon' => 'file-docs',
												'title'     => 'فایل ضمیمه',
											] );
											?>
                                        </li>
										<?php
									}
									?>
                                    <li>
										<?php
										$valid_statuses = crm_get_valid_next_status( $status );
										$actions        = [];
										if ( empty( $valid_statuses ) ) {
											$actions = [
												[
													'link'  => '',
													'title' => 'وضعیت سفارش نمی تواند تغییر کند.',
												
												],
											];
										} else {
											foreach ( $valid_statuses as $valid_status ) {
												$actions[] = [
													'link'  => '',
													'title' => $statuses[ 'wc-' . $valid_status ],
													'class' => 'change_order_status',
													'data'  => [
														'status'   => $valid_status,
														'order-id' => $order_id,
													],
												];
											}
										}
										echo crm_get_template( 'partials/row-actions-dropdown.php', [
											'actions'   => $actions,
											'main_icon' => 'repeat',
											'title'     => 'تغییر وضعیت سفارش',
										] );
										?>
                                    </li>
                                    <li>
										<?php
										$actions  = [
											'edit'           => [
												'link'   => home_url() . "/crm/order-edit?order_id=$order_id",
												'icon'   => 'ni-edit',
												'title'  => 'ویرایش سفارش',
												'target' => '_blank',
											],
											'edit_separator' => [
												'divider' => TRUE,
											],
											[
												'link'  => '',
												'title' => 'اطلاعات چک های سفارش',
												'icon'  => 'ni-edit-alt',
												'class' => 'load_order_cheque',
												'data'  => [
													'order-id' => $order_id,
												],
											],
											[
												'link'  => '',
												'title' => 'اطلاعات پرداخت نقدی',
												'icon'  => 'ni-coins',
												'class' => 'load_order_cash_table',
												'data'  => [
													'order-id' => $order_id,
												],
											],
											[
												'link'  => '',
												'title' => 'اطلاعات پرداخت قسطی',
												'icon'  => 'ni-card-view',
												'class' => 'load_order_installments',
												'data'  => [
													'order-id' => $order_id,
												],
											],
											[
												'divider' => TRUE,
											],
											[
												'link'  => '/crm/user/' . $user_id,
												'title' => 'مشخصات مشتری',
												'icon'  => 'ni-eye',
												'class' => 'page_activator',
											],
											[
												'link'  => '/crm/user/' . $user_id . '?tab=orders',
												'title' => 'همه سفارشات',
												'icon'  => 'ni-cart',
												'class' => 'page_activator',
											],
										];
										$can_edit = crm_can_edit_order( $status );
										if ( $status == 'confirmed' ) {
											unset( $actions['edit'] );
											unset( $actions['edit_separator'] );
										}
										if ( ! $can_edit ) {
											unset( $actions['edit'] );
											unset( $actions['edit_separator'] );
										}
										echo crm_get_template( 'partials/row-actions-dropdown.php', [
											'actions' => $actions,
										] );
										?>
                                    </li>
                                </ul>
                            </div>
                        </div>
						<?php
					}
					?>
                </div>
            </div>
            <div class="card-inner">
				<?php
				echo crm_get_template( 'partials/pagination.php', [
					'max_page_num' => $total_page,
					'current_page' => $page_number,
					'class_name'   => 'user_pagination_link',
					'show_count'   => 2,
				] );
				?>
            </div>
        </div>
    </div>
</div>
