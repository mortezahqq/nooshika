<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

$per_page_key = basename( __FILE__, '.php' );
$per_page_key = "crm_{$per_page_key}_per_page";
$user_id      = get_current_user_id();
$defaults     = [
	'page_number' => 1,
	'per_page'    => get_user_meta( $user_id, $per_page_key, TRUE ) ?: 20,
	'date'        => [
		'from' => '',
		'to'   => '',
	],
	'search'      => '',
	'employee_id' => '',
	'category'    => '',
];
$args         = wp_parse_args( $_REQUEST, $defaults );
$args         = array_map( fn( $v ) => $v == 0 ? '' : $v, $args );
$has_filter   = kcp_page_has_filter( $args, $defaults );
extract( $args );
update_user_meta( $user_id, $per_page_key, $per_page );
$offset    = ( $page_number - 1 ) * $per_page;
$date      = is_array( $date ) ? $date : [];
$date_from = $date['from'] ?? '';
$date_to   = $date['to'] ?? '';
$DB        = new kcp_db();
if ( ! is_current_user_admin() ) {
	$employee_id = get_current_user_id();
}
$reports         = $DB->get_employee_reports(
	compact( 'per_page', 'offset', 'date_from', 'date_to', 'search', 'employee_id', 'category' ) );
$total           = $reports['count'] ?: 0;
$total_page      = ceil( $total / $per_page );
$reports         = $reports['result'];
$employees       = get_users( [
	'role__in' => kcp_get_all_roles(),
	'fields'   => 'ids',
] );
$report_category = $DB->get_report_category();
$query_args      = array_merge( [
	'action' => 'print',
	'type'   => 'hr-reports',
], compact( 'per_page', 'offset', 'date_from', 'date_to', 'search', 'employee_id', 'category' ) );
$query_args      = array_filter( $query_args );
?>
<div class="nk-block-head nk-block-head-sm">
    <div class="nk-block-between">
        <div class="nk-block-head-content">
            <h3 class="nk-block-title page-title">لیست گزارش های کارمندان</h3>
            <div class="nk-block-des text-soft">
                <p class="mb-0">شما در مجموع <?php echo $total; ?> گزارش ثبت شده دارید.</p>
            </div>
        </div>
        <div class="nk-block-head-content">
            <ul class="nk-block-tools g-3">
                <li class="nk-block-tools-opt">
                    <a href="<?php echo add_query_arg( $query_args, home_url( '/crm/' ) ); ?>"
                       class="btn btn-info" target="_blank">
                        <em class="icon ni ni-printer-fill"></em><span>پرینت</span>

                    </a>
                </li>
                <li class="nk-block-tools-opt">
                    <a href="#addEmployeeReport" class="btn btn-icon btn-primary"
                       data-bs-target="#addEmployeeReport"
                       data-bs-toggle="modal"><em class="icon ni ni-plus"></em></a>
                </li>
            </ul>
        </div>
    </div>
</div>
<div class="nk-block">
    <div class="card card-stretch">
        <div class="card-inner-group">
            <div class="card-inner position-relative card-tools-toggle">
                <div class="card-title-group">
                    <div class="card-tools">
                        <a class="btn btn-icon search-toggle toggle-search" data-target="search_reports">
                            <em class="icon ni ni-search"></em>
                        </a>
                    </div>
                    <div class="card-tools">
                        <ul class="btn-toolbar gx-1">
                            <li>
								<?php
								$filter_fields = [
									[
										'type'  => 'date-range',
										'label' => 'تاریخ ثبت گزارش',
										'name'  => 'date',
										'value' => [
											'from' => $date_from ?? '',
											'to'   => $date_to ?? '',
										],
									],
									'employee_id' => [
										'type'    => 'select',
										'label'   => 'ثبت کننده',
										'name'    => 'employee_id',
										'value'   => $employee_id,
										'col'     => 6,
										'options' => [ 0 => 'همه موارد' ] + array_combine(
												$employees,
												array_map( 'get_user_name_by_id', $employees )
											),
									],
									[
										'type'    => 'select',
										'label'   => 'دسته بندی',
										'name'    => 'category',
										'value'   => $category,
										'col'     => 6,
										'options' => [ 0 => 'همه موارد' ] + array_combine(
												array_keys( $report_category ),
												array_column( $report_category, 'label' )
											),
									],
								];
								if ( ! is_current_user_admin() ) {
									unset( $filter_fields['employee_id'] );
								}
								echo crm_get_template( 'partials/filter-dropdown.php', [
									'has_filter'    => $has_filter,
									'filter_fields' => $filter_fields,
								] );
								?>
                            </li>
                            <li class="btn-toolbar-sep"></li>
                            <li>
								<?php
								echo crm_get_template( 'partials/per-page-selector.php', [
									'per_page' => $per_page,
								] );
								?>
                            </li>
                        </ul>
                    </div>
                    <div class="card-search search-wrap<?php echo $search ? ' active' : ''; ?>"
                         data-search="search_reports">
                        <div class="card-body">
                            <div class="search-content">
                                <a href="#" class="search-back btn btn-icon toggle-search"
                                   data-target="search_visits"><em
                                        class="icon ni ni-arrow-left"></em></a>
                                <input type="text" value="<?php echo $search; ?>"
                                       class="form-control border-transparent form-focus-none search_crm_list"
                                       placeholder="جستجو میان گزارش ها">
                                <div class="search-submit btn btn-icon submit_search_actions">
                                    <em class="icon ni ni-search"></em>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-inner p-0">
                <div class="nk-tb-list nk-tb-ulist is-compact">
                    <div class="nk-tb-item nk-tb-head">
                        <div class="nk-tb-col tb-col-md"><span class="sub-text">تاریخ</span></div>
                        <div class="nk-tb-col ps-3 ps-md-2"><span class="sub-text">کارمند</span></div>
                        <div class="nk-tb-col"><span class="sub-text">عنوان</span></div>
                        <div class="nk-tb-col tb-col-md"><span class="sub-text">واحد گزارش</span></div>
                        <div class="nk-tb-col tb-col-md"><span class="sub-text">توضیحات</span></div>
                        <div class="nk-tb-col nk-tb-col-tools text-end"></div>
                    </div>
					<?php
					if ( empty( $reports ) ) {
						echo '<div class="no-item-found">گزارش یافت نشد</div>';
					} else {
						foreach ( $reports as $report ) {
							extract( $report );
							$creator           = get_user_name_by_id( $employee_id );
							$category_badge    = $report_category[ $category ]['class'];
							$category_label    = $report_category[ $category ]['label'];
							$attachment        = $DB->get_employee_report_meta( $id, 'attachment' );
							$report_content_id = wp_unique_id( 'report_content_' );
							?>
                            <div class="nk-tb-item">
                                <div class="nk-tb-col tb-col-md">
                                    <span class="sub-text">
                                        <?php echo date_i18n( 'j F Y', strtotime( $created_at ) ); ?></span>
                                </div>
                                <div class="nk-tb-col ps-3 ps-md-2">
									<?php
									echo crm_get_template( 'partials/user-card.php', [
										'user_id' => $employee_id,
									] );
									?>
                                </div>
                                <div class="nk-tb-col">
                                    <div class="fw-bold text-dark"><?php echo $title; ?></div>
                                    <div class="d-block d-sm-none mt-1" style="gap: 10px">
                                        <div class="w-max-250px w-250px fs-12px nk-news-text atlas-report-modal-trigger"
                                             data-bs-toggle="modal"
                                             data-bs-target="#atlasReportContentModal"
                                             data-content-target="#<?php echo esc_attr( $report_content_id ); ?>"
                                             style="cursor:pointer;">
                                            <p><?php echo esc_html( wp_strip_all_tags( $content ) ); ?></p>
                                        </div>
                                    </div>
                                    <div class="d-flex justify-between d-sm-none mt-1" style="gap: 10px">
                                        <span class="badge <?php echo $category_badge; ?>"><?php echo
	                                        $category_label; ?></span>
                                        <span
                                            class="sub-text fs-10px text-nowrap"><?php echo date_i18n( 'j F Y', strtotime( $created_at ) ); ?></span>
                                    </div>
                                </div>
                                <div class="nk-tb-col tb-col-md">
                                    <span
                                        class="badge <?php echo $category_badge; ?>"><?php echo $category_label; ?></span>
                                </div>
                                <div class="nk-tb-col tb-col-md">
                                    <div class="w-max-250px w-250px fs-12px nk-news-text atlas-report-modal-trigger"
                                         data-bs-toggle="modal"
                                         data-bs-target="#atlasReportContentModal"
                                         data-content-target="#<?php echo esc_attr( $report_content_id ); ?>"
                                         style="cursor:pointer;">
                                        <p><?php echo esc_html( wp_strip_all_tags( $content ) ); ?></p>
                                    </div>
                                </div>
                                <div class="nk-tb-col nk-tb-col-tools">
                                    <ul class="nk-tb-actions gx-2">
										<?php
										$row_actions = [
											[
												'link'  => '',
												'title' => 'ویرایش گزارش',
												'icon'  => 'ni-edit',
												'class' => 'edit_item',
												'data'  => [
													'modal'        => 'addEmployeeReport',
													'report_id'    => $id,
													'title'        => $title,
													'new_category' => $category,
													'content'      => $content,
													'attachment'   => $attachment,
												],
											],
											[
												'link'  => '',
												'title' => 'حذف گزارش',
												'icon'  => 'ni-trash',
												'class' => 'delete_db_item',
												'data'  => [
													'page'    => '/crm/hr-reports',
													'item_id' => $id,
													'action'  => 'crm_delete_employee_report',
												],
											],
										];
										
										if ( $attachment ) {
											array_unshift( $row_actions, [
												'link'     => $attachment,
												'title'    => 'فایل ضمیمه',
												'icon'     => 'ni-download',
												'download' => TRUE,
											] );
										}
										
										echo crm_get_template( 'partials/row-actions-dropdown.php', [
											'actions' => $row_actions,
										] );
										?>
                                    </ul>
                                    <div id="<?php echo esc_attr( $report_content_id ); ?>" class="d-none">
										<?php echo wpautop( wp_kses_post( $content ) ); ?>
                                    </div>
                                </div>
                            </div>
							<?php
						}
					}
					?>
                </div>
            </div>
            <div class="card-inner">
				<?php
				echo crm_get_template( 'partials/pagination.php', [
					'max_page_num' => $total_page,
					'current_page' => $page_number,
					'class_name'   => 'user_pagination_link',
					'show_count'   => 2,
				] );
				?>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="atlasReportContentModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title">محتوای گزارش</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="بستن"></button>
            </div>

            <div class="modal-body atlas-report-modal-body"></div>

        </div>
    </div>
</div>