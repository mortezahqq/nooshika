<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
$per_page_key = basename( __FILE__, '.php' );
$per_page_key = "crm_{$per_page_key}_per_page";
$user_id      = get_current_user_id();
$defaults     = [
	'page_number' => 1,
	'per_page'    => get_user_meta( $user_id, $per_page_key, TRUE ) ?: 20,
	'intro'       => '',
	'register'    => [
		'from' => '',
		'to'   => '',
	],
	'gender'      => '',
	'creator'     => '',
    'phone_sales_agent' => '',
	'level'       => '',
	'order_count' => '',
	'groups'      => '',
	'types'       => '',
	'city'        => '',
	'state'       => '',
];
$args         = wp_parse_args( $_REQUEST, $defaults );
$args         = array_map( fn( $v ) => $v == 0 ? '' : $v, $args );
$has_filter   = kcp_page_has_filter( $args, $defaults );
extract( $args );
update_user_meta( $user_id, $per_page_key, $per_page );
$offset        = ( $page_number - 1 ) * $per_page;
$user_args     = [
	'order'       => 'DESC',
	'orderby'     => 'user_registered',
	'number'      => $per_page,
	'offset'      => $offset,
	'count_total' => TRUE,
	'fields'      => 'ids',
	'role__in'    => [ 'subscriber' ],
];
$user_metas    = [
	'intro'       => [
		'meta_key' => 'ncp_user_intro_method',
		'compare'  => 'LIKE',
		'type'     => 'CHAR',
	],
	'creator'     => [
		'meta_key' => 'creator_id',
		'compare'  => '=',
		'type'     => 'CHAR',
	],
    'phone_sales_agent' => [
        'meta_key' => 'crm_phone_sales_agent_id', 'compare' => '=', 'type' => 'NUMERIC',
    ],
	'state'       => [
		'meta_key' => 'state',
		'compare'  => '=',
		'type'     => 'CHAR',
	],
	'city'        => [
		'meta_key' => 'city',
		'compare'  => '=',
		'type'     => 'CHAR',
	],
	'gender'      => [
		'meta_key' => 'gender',
		'compare'  => '=',
		'type'     => 'CHAR',
	],
	'groups'      => [
		'meta_key' => 'kcp_user_groups',
		'compare'  => 'LIKE',
	],
	'types'       => [
		'meta_key' => 'kcp_user_types',
		'compare'  => 'LIKE',
	],
	'order_count' => [
		'meta_key' => 'user_total_order_count',
		'compare'  => '>=',
		'type'     => 'NUMERIC',
	],
];
$access_to_all = get_option( 'crm_marketer_access_to_all_user' ) ?: TRUE;
$access_to_all = filter_var( $access_to_all, FILTER_VALIDATE_BOOLEAN );
if ( ! is_current_user_admin() && ! $access_to_all ) {
	$owner_filter = in_array( 'phone_salesman', (array) wp_get_current_user()->roles, TRUE ) ? 'phone_sales_agent' : 'creator';
    $args[ $owner_filter ] = get_current_user_id();
}
foreach ( $user_metas as $meta => $user_meta ) {
	if ( ( $meta === 'creator' && $args[ $meta ] === 'without_marketer' ) ||
        ( $meta === 'phone_sales_agent' && $args[ $meta ] === 'without_phone_agent' ) ) {
		$user_args['meta_query'][] = [
			'relation' => 'OR',
			[
				'key'     => $user_meta['meta_key'],
				'compare' => 'NOT EXISTS',
			],
			[
				'key'     => $user_meta['meta_key'],
				'value'   => '',
				'compare' => '=',
			],
			[
				'key'     => $user_meta['meta_key'],
				'value'   => '0',
				'compare' => '=',
			],
		];
		continue;
	}
	
	if ( $args[ $meta ] ) {
		$user_args['meta_query'][] = [
			'key'     => $user_meta['meta_key'],
			'compare' => $user_meta['compare'],
			'value'   => $args[ $meta ],
		];
	}
}

$levels = ncp_get_user_levels();
if ( ! empty( $args['level'] ) && isset( $levels[ $args['level'] ] ) ) {
	$filtered_level            = $levels[ $args['level'] ];
	$user_args['meta_query'][] = [
		'key'     => 'user_total_order',
		'value'   => $filtered_level['min'],
		'compare' => '>=',
		'type'    => 'NUMERIC',
	];
	$user_args['meta_query'][] = [
		'key'     => 'user_total_order',
		'value'   => $filtered_level['max'],
		'compare' => '<=',
		'type'    => 'NUMERIC',
	];
}

if ( ! empty( $user_args['meta_query'] ) ) {
	$user_args['meta_query']['relation'] = 'AND';
}

$register_from = $register['from'] ?? '';
$register_to   = $register['to'] ?? '';

if ( $register_from || $register_to ) {
	$user_args['date_query'] = [
		[
			'column'    => 'user_registered',
			'inclusive' => TRUE,
			'after'     => $register_from ? nooshika_jalali_to_gregorian( $register_from ) : NULL,
			'before'    => $register_to ? nooshika_jalali_to_gregorian( $register_to ) : NULL,
		],
	];
}
$user_query  = new WP_User_Query( $user_args );
$users       = $user_query->get_results();
$total_users = $user_query->get_total();
$total_page  = ceil( $total_users / $per_page );
$DB          = new kcp_db();
$intros      = $DB->get_introduce_methods();
$states      = WC()->countries->get_states( 'IR' );
$all_roles   = kcp_get_all_roles( FALSE );
$employees   = get_users( [
	'fields'   => 'ids',
	'orderby'  => 'ID',
	'order'    => 'DESC',
	'role__in' => array_values( array_diff( $all_roles, [ 'phone_salesman' ] ) ),
] );

$phone_agent_options = [ 0 => 'همه موارد', 'without_phone_agent' => 'بدون مسئول فروش حضوری' ];
foreach ( kcp_sales_agents( 'phone' ) as $phone_agent ) {
    $phone_agent_options[ $phone_agent->ID ] = get_user_name_by_id( $phone_agent->ID );
}

$city_options = [ 0 => 'همه موارد' ];

if ( ! empty( $state ) && $state != 0 ) {
	$state_cities = PWS()::cities( $state );
	
	if ( is_array( $state_cities ) && ! empty( $state_cities ) ) {
		$city_options += $state_cities;
	}
}

if ( ! isset( $city_options[ $city ] ) ) {
	$city = 0;
}
?>
<div class="nk-block-head nk-block-head-sm">
    <div class="nk-block-between">
        <div class="nk-block-head-content">
            <h3 class="nk-block-title page-title">لیست مشتریان</h3>
            <div class="nk-block-des text-soft">
                <p class="mb-0">شما در مجموع <?php echo $total_users; ?> مشتری دارید.</p>
            </div>
        </div>
        <div class="nk-block-head-content">
            <div class="toggle-wrap nk-block-tools-toggle">
                <div class="toggle-expand-content">
                    <ul class="nk-block-tools g-3">
                        <li class="nk-block-tools-opt">
                            <a href="#" class=" btn btn-icon btn-primary" data-bs-target="#addCustomer"
                               data-bs-toggle="modal"><em class="icon ni ni-plus"></em></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="nk-block">
    <div class="card card-stretch">
        <div class="card-inner-group">
            <div class="card-inner position-relative card-tools-toggle">
                <div class="card-title-group">
                    <div class="card-tools">
                    </div>
                    <div class="card-tools">
                        <ul class="btn-toolbar gx-1">
                            <?php if ( kcp_can_assign_customers() ) : ?>
                            <?php foreach ( kcp_sales_assignment_types() as $assignment_type => $config ) : ?>
                            <li>
                                <div class="dropdown">
                                    <a href="#" class="dropdown-toggle btn btn-outline-primary" data-bs-toggle="dropdown">
                                        <em class="icon ni ni-repeat-v"></em><span><?php echo esc_html( 'اختصاص ' . $config['label'] ); ?></span>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-end">
                                        <ul class="link-list-opt no-bdr">
                                            <li><a href="#" class="change_user_marketer_bulk" data-type="<?php echo esc_attr( $assignment_type ); ?>" data-id="0" data-nonce="<?php echo esc_attr( wp_create_nonce( 'kcp_customer_assignment' ) ); ?>"><span><?php echo esc_html( 'بدون ' . $config['label'] ); ?></span></a></li>
                                            <?php foreach ( kcp_sales_agents( $assignment_type ) as $sales_agent ) : ?>
                                                <li><a href="#" class="change_user_marketer_bulk" data-type="<?php echo esc_attr( $assignment_type ); ?>" data-id="<?php echo esc_attr( $sales_agent->ID ); ?>" data-nonce="<?php echo esc_attr( wp_create_nonce( 'kcp_customer_assignment' ) ); ?>"><span><?php echo esc_html( get_user_name_by_id( $sales_agent->ID ) ); ?></span></a></li>
                                            <?php endforeach; ?>
                                        </ul>
                                    </div>
                                </div>
                            </li>
                            <?php endforeach; ?>
                            <?php endif; ?>
                            <li>
								<?php
								$levels_filter = [ 0 => 'همه موارد' ] + array_combine(
										array_keys( $levels ),
										array_column( $levels, 'label' )
									);
								$filter_fields = [
									[
										'type'    => 'select',
										'label'   => 'شیوه آشنایی',
										'name'    => 'intro',
										'value'   => $intro,
										'col'     => 6,
										'options' => [ 0 => 'همه موارد' ] + array_combine(
												array_keys( $intros ),
												array_column( $intros, 'label' )
											),
									],
									[
										'type'    => 'radio',
										'label'   => 'جنسیت',
										'name'    => 'gender',
										'value'   => $gender ?? '',
										'col'     => 6,
										'options' => [
											'male'   => 'مرد',
											'female' => 'زن',
										],
									],
									[
										'type'    => 'select',
										'label'   => 'سطح مشتری',
										'name'    => 'level',
										'value'   => $level,
										'col'     => 6,
										'options' => $levels_filter,
									],
									[
										'type'  => 'number',
										'label' => 'تعداد سفارشات',
										'name'  => 'order_count',
										'col'   => 6,
										'value' => $order_count,
									],
									'marketer' => [
										'type'    => 'select',
										'label'   => 'مسئول فروش تلفنی',
										'name'    => 'creator',
										'value'   => $creator,
										'col'     => 12,
										'options' => [
											             0                  => 'همه موارد',
											             'without_marketer' => 'بدون مسئول فروش تلفنی',
										             ] + array_combine(
											             $employees,
											             array_map( 'get_user_name_by_id', $employees )
										             ),
									],
                                    'phone_sales' => [
                                        'type' => 'select',
                                        'label' => 'مسئول فروش حضوری',
                                        'name' => 'phone_sales_agent',
                                        'value' => $phone_sales_agent,
                                        'col' => 12,
                                        'options' => $phone_agent_options,
                                    ],
									[
										'type'    => 'select',
										'label'   => 'استان',
										'name'    => 'state',
										'value'   => $state,
										'col'     => 6,
										'options' => [ 0 => 'همه موارد' ] + $states,
										'class'   => 'load_city',
										'data'    => [
											'target' => '#user_city_filter',
										],
									],
									[
										'type'    => 'select',
										'label'   => 'شهر',
										'name'    => 'city',
										'value'   => $city,
										'col'     => 6,
										'options' => $city_options,
										'id'      => 'user_city_filter',
									],
									[
										'type'  => 'date-range',
										'label' => 'بازه ثبت‌نام',
										'name'  => 'register',
										'value' => [
											'from' => $register_from ?? '',
											'to'   => $register_to ?? '',
										],
									],
									[
										'type'    => 'select',
										'label'   => 'دسته بندی مشتری',
										'name'    => 'groups',
										'value'   => $groups,
										'col'     => 6,
										'options' => [ 0 => 'همه موارد' ] + ncp_get_taxonomy_filter_options( 'groups' ),
									],
									[
										'type'    => 'select',
										'label'   => 'تگ مشتری',
										'name'    => 'types',
										'value'   => $types,
										'col'     => 6,
										'options' => [ 0 => 'همه موارد' ] + ncp_get_taxonomy_filter_options( 'types' ),
									],
								];
								echo crm_get_template( 'partials/filter-dropdown.php', [
									'has_filter'    => $has_filter,
									'filter_fields' => $filter_fields,
								] );
								?>
                            </li>
                            <li class="btn-toolbar-sep"></li>
                            <li>
								<?php
								echo crm_get_template( 'partials/per-page-selector.php', [
									'per_page' => $per_page,
								] );
								?>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="card-inner p-0">
                <div class="nk-tb-list nk-tb-ulist is-compact">
                    <div class="nk-tb-item nk-tb-head">
                        <div class="nk-tb-col tb-col-md nk-tb-col-check"></div>
                        <div class="nk-tb-col"><span class="sub-text">مشتری</span></div><div class="nk-tb-col"><span class="sub-text">کارشناس فروش حضوری</span></div>
                        <div class="nk-tb-col text-center tb-col-md"><span class="sub-text">نام فروشگاه</span></div>
                        <div class="nk-tb-col text-center tb-col-md"><span class="sub-text">شیوه آشنایی</span></div>
                        <div class="nk-tb-col text-center tb-col-md"><span class="sub-text">تگ مشتری</span></div>
                        <div class="nk-tb-col text-center tb-col-md"><span class="sub-text">دسته بندی مشتری</span></div>
                        <div class="nk-tb-col text-center tb-col-md"><span class="sub-text">سطح مشتری</span></div>
                        <div class="nk-tb-col text-center tb-col-md"><span class="sub-text">موقعیت</span></div>
                        <div class="nk-tb-col text-end">
                        </div>
                    </div>
					<?php
					if ( empty( $users ) ) {
						echo '<div class="no-item-found">مشتری یافت نشد</div>';
					} else {
						foreach ( $users as $user_id ) {
							$creator_id        = get_user_meta( $user_id, 'creator_id', TRUE );
                            $phone_sales_id = get_user_meta( $user_id, 'crm_phone_sales_agent_id', TRUE );
							$phone             = get_user_meta( $user_id, 'nooshika_phone_num', TRUE );
							$total_spend       = get_user_meta( $user_id, 'user_total_order', TRUE );
							$shop_name         = get_user_meta( $user_id, 'shop_name', TRUE );
							$total_spend       = get_user_meta( $user_id, 'user_total_order', TRUE );
							$total_spend       = get_user_meta( $user_id, 'user_total_order', TRUE );
							$intro_method_slug = get_user_meta( $user_id, 'ncp_user_intro_method', TRUE );
							$intro_method      = $intros[ $intro_method_slug ] ?? FALSE;
							if ( $intro_method_slug == 'other' ) {
								$other                 = get_user_meta( $user_id, 'intro_method_other', TRUE );
								$intro_method['label'] .= ': ' . $other;
							}
							
							$groups = get_user_meta( $user_id, 'kcp_user_groups', TRUE );
							$types  = get_user_meta( $user_id, 'kcp_user_types', TRUE );
							$state  = get_user_meta( $user_id, 'state', TRUE );
							$city   = get_user_meta( $user_id, 'city', TRUE );
							if ( $state ) {
								$cities = PWS()::cities( $state );
								
								$city  = $cities[ $city ] ?? $city;
								$state = $states[ $state ] ?? $state;
							}
							$location_parts = array_filter( [ $state, $city ] );
							
							$registered = get_the_author_meta( 'registered', $user_id );
							$registered = date_i18n( 'j M Y, H:i', strtotime( $registered ) + 12600 );
							?>
                            <div class="nk-tb-item">
                                <div class="nk-tb-col tb-col-md nk-tb-col-check">
                                    <div
                                        class="custom-control custom-control-sm custom-checkbox notext">
                                        <input type="checkbox"
                                               class="custom-control-input select_item_row"
                                               value="<?php echo $user_id; ?>"
                                               id="user_row<?php echo $user_id; ?>">
                                        <label class="custom-control-label"
                                               for="user_row<?php echo $user_id; ?>"></label>
                                    </div>
                                </div>
                                <div class="nk-tb-col w-max-300px">
									<?php
									echo crm_get_template( 'partials/user-card.php', [
										'user_id'    => $user_id,
										'show_phone' => TRUE,
									] );
									?>
                                </div>
                                <div class="nk-tb-col"><span><?php echo esc_html( $phone_sales_id ? get_user_name_by_id( $phone_sales_id ) : '-' ); ?></span></div>
                                <div class="nk-tb-col tb-col-md">
                                    <span class="sub-text"><?php echo $shop_name; ?></span>
                                </div>
                                <div class="nk-tb-col text-center tb-col-md">
									<?php
									if ( $intro_method ) {
										?>
                                        <a class="btn btn-sm btn-icon btn-trigger"
                                           data-bs-toggle="tooltip" data-bs-placement="top"
                                           title="<?php echo $intro_method['label']; ?>">
                                            <em class="icon ni ni-<?php echo $intro_method['icon']; ?>"></em>
                                        </a>
										<?php
									} else {
										echo '-';
									}
									?>
                                </div>
                                <div class="nk-tb-col text-center tb-col-md">
                                    <ul class="g-1 profile-ud-value">
										<?php
										if ( $types ) {
											$types_list = ncp_get_taxonomy_filter_options( 'types' );
											foreach ( $types as $item ) {
												?>
                                                <li class="btn-group">
                                                    <span
                                                        class="badge bg-info"><?php echo $types_list[ $item ]; ?></span>
                                                </li>
												<?php
											}
										} else {
											echo '-';
										}
										?>
                                    </ul>
                                </div>
                                <div class="nk-tb-col text-center tb-col-md">
                                    <ul class="g-1 profile-ud-value">
										<?php
										if ( $groups ) {
											$groups_list = ncp_get_taxonomy_filter_options( 'groups' );
											foreach ( $groups as $item ) {
												?>
                                                <li class="btn-group">
                                                    <span
                                                        class="badge bg-info"><?php echo $groups_list[ $item ];
	                                                    ?></span>
                                                </li>
												<?php
											}
										} else {
											echo '-';
										}
										?>
                                    </ul>
                                </div>
                                <div class="nk-tb-col text-center tb-col-md">
									<?php
									if ( $total_spend ) {
										$user_level  = ncp_get_user_level_by_total( $total_spend );
										$total_spend = convert_number_to_text( $total_spend );
										?>
                                        <span class="badge mb-1 <?php echo $user_level['badge']; ?>"><?php
											echo $user_level['label']; ?></span>
                                        <span
                                            class="small sub-text fs-10px"><?php echo $total_spend . " ($total_order سفارش)";
											?></span>
										<?php
									} else {
										echo '-';
									}
									?>
                                </div>
                                <div class="nk-tb-col tb-col-md">
                                    <span
                                        class="sub-text"><?php echo esc_html( implode( '، ', $location_parts ) ); ?></span>
                                </div>
                                <div class="nk-tb-col">
                                    <ul class="nk-tb-actions gx-2">
										<?php
										echo crm_get_template( 'partials/row-actions-hidden.php', [
											'actions' => [
												[
													'link'  => '/crm/user/' . $user_id,
													'title' => 'مشاهده مشخصات',
													'icon'  => 'ni-eye',
													'class' => 'page_activator',
												],
												[
													'link'  => '',
													'title' => $registered,
													'icon'  => 'ni-calendar',
												],
												[
													'link'  => '',
													'title' => $creator_id ? get_user_name_by_id( $creator_id ) : '-',
													'icon'  => 'ni-user-check',
												],
												[
													'link'  => '/crm/user/' . $user_id . '?tab=orders',
													'title' => 'سفارشات',
													'icon'  => 'ni-tranx',
													'class' => 'page_activator',
												],
												[
													'link'  => '/crm/user/' . $user_id . '?tab=wallet',
													'title' => 'تراکنش های کیف پول',
													'icon'  => 'ni-coins',
													'class' => 'page_activator',
												],
												//												[
												//													'link'  => '',
												//													'title' => 'حذف مشتری',
												//													'icon'  => 'ni-user-cross',
												//													'class' => 'delete_user',
												//													'data'  => [
												//														'user-id' => $id,
												//													],
												//												],
											],
										] );
										?>
                                    </ul>
                                </div>
                            </div>
							<?php
						}
					}
					?>
                </div>
            </div>
            <div class="card-inner">
				<?php
				echo crm_get_template( 'partials/pagination.php', [
					'max_page_num' => $total_page,
					'current_page' => $page_number,
					'class_name'   => 'user_pagination_link',
					'show_count'   => 2,
				] );
				?>
            </div>
        </div>
    </div>
</div>

