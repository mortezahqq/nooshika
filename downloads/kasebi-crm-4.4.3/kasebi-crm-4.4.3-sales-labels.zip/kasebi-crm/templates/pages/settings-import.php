<?php

?>
<div class="nk-block nk-block-lg">
    <div class="card card-preview">
        <div class="card-inner">
            <div class="row g-gs">
                <div class="col-md-4">
                    <ul class="nav link-list-menu border border-light round m-0" role="tablist">
                        <li>
                            <a class="active" data-bs-toggle="tab" href="#import_users">
                                <em class="icon ni ni-user"></em>
                                <span>ایمپورت مشتری</span>
                            </a>
                        </li>
                        <li>
                            <a data-bs-toggle="tab" href="#import_orders">
                                <em class="icon ni ni-cart"></em>
                                <span>ایمپورت سفارش</span>
                            </a>
                        </li>
                        <li>
                            <a data-bs-toggle="tab" href="#import_qty">
                                <em class="icon ni ni-cart"></em>
                                <span>ایمپورت موجودی</span>
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="col-md-8">
                    <div class="tab-content">
                        <div class="tab-pane active show" id="import_users">
                            <div class="form-group">
                                <label class="form-label">ایمپورت مشتری</label>
                                <div class="form-control-wrap">
                                    <div class="form-file">
                                        <input type="file" class="form-file-input" id="import_users_file">
                                        <label class="form-file-label" for="import_users_file">
                                            <span>انتخاب فایل اکسل</span>
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="align-center justify-between gap-sm-2 mb-4">
                                <button class="btn btn-primary start_import"
                                        data-progress="user_import_progress"
                                        data-per-page="100"
                                        data-file="import_users_file" data-action="crm_import_users">
                                    <span>آغاز ایمپورت</span>
                                </button>
                                <div class="progress" style="flex-grow: 1;">
                                    <div class="progress-bar progress-bar-striped progress-bar-animated"
                                         id="user_import_progress"
                                         data-progress="0"></div>
                                </div>
                            </div>
                            <div class="card-inner card-inner-md bg-danger-dim rounded-3 mt-1 text-danger">
                                <div class="card-note ">
                                    <em class="icon ni ni-info-fill"></em>
                                    <span>تا پایان ایمپورت از رفرش کردن و بستن این صفحه به شدت خودداری بفرمایید.</span>
                                </div>
                            </div>
                            <div class="card-inner card-inner-md bg-light rounded-3 mt-1">
                                <div class="card-note">
                                    <em class="icon ni ni-info-fill"></em>
                                    <span>جهت ایمپورت مشتریان لطفا فایل اکسل را مطابق با فایل نمونه آماده کنید و در فیلد بالا انتخاب و بر روی آغاز ایمپورت کلیک کنید.</span>
                                </div>
                            </div>
                            <div class="card-inner card-inner-md bg-light rounded-3 mt-1">
                                <div class="card-note align-center">
                                    <em class="icon ni ni-info-fill"></em>
                                    <span>دانلود فایل نمونه ایمپورت.</span>
                                    <a href="<?php echo KCP_ASSETS_URL; ?>files/import-user.xlsx" download
                                       class="btn btn-info btn-sm" style="margin-right: auto;">
                                        <span>اکسل نمونه مشتریان</span>
                                        <em class="icon ni ni-download"></em>
                                    </a>
                                </div>
                            </div>
                            <div class="card-inner card-inner-md bg-light rounded-3 mt-1">
                                <div class="card-note">
                                    <em class="icon ni ni-info-fill"></em>
                                    <span>برای مقادیر طبقه بندی های مشتری و شیوه آشنایی حتما از نامک لاتین این موارد استفاده کنید. برای ثبت چند مورد از علامت , میان اسلاگ های مختلف استفاده کنید.</span>
                                </div>
                            </div>
                            <div class="card-inner card-inner-md bg-light rounded-3 mt-1">
                                <div class="card-note">
                                    <em class="icon ni ni-info-fill"></em>
                                    <span>فایل اکسل حتما بایستی یک sheet داشته باشد.</span>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane" id="import_orders">
                            <div class="form-group">
                                <label class="form-label">ایمپورت سفارش</label>
                                <div class="form-control-wrap">
                                    <div class="form-file">
                                        <input type="file" class="form-file-input" id="import_orders_file">
                                        <label class="form-file-label" for="import_orders_file">
                                            <span>انتخاب فایل اکسل</span>
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="align-center justify-between gap-sm-2 mb-4">
                                <button class="btn btn-primary start_import"
                                        data-progress="order_import_progress"
                                        data-per-page="50"
                                        data-file="import_orders_file" data-action="crm_import_orders">
                                    <span>آغاز ایمپورت</span>
                                </button>
                                <div class="progress" style="flex-grow: 1;">
                                    <div class="progress-bar progress-bar-striped progress-bar-animated"
                                         id="order_import_progress"
                                         data-progress="0"></div>
                                </div>
                            </div>
                            <div class="card-inner card-inner-md bg-danger-dim rounded-3 mt-1 text-danger">
                                <div class="card-note ">
                                    <em class="icon ni ni-info-fill"></em>
                                    <span>تا پایان ایمپورت از رفرش کردن و بستن این صفحه به شدت خودداری بفرمایید.</span>
                                </div>
                            </div>
                            <div class="card-inner card-inner-md bg-light rounded-3 mt-1">
                                <div class="card-note">
                                    <em class="icon ni ni-info-fill"></em>
                                    <span>جهت ایمپورت سفارشات لطفا فایل اکسل را مطابق با فایل نمونه آماده کنید و در فیلد بالا انتخاب و بر روی آغاز ایمپورت کلیک کنید.</span>
                                </div>
                            </div>
                            <div class="card-inner card-inner-md bg-light rounded-3 mt-1">
                                <div class="card-note align-center">
                                    <em class="icon ni ni-info-fill"></em>
                                    <span>دانلود فایل نمونه ایمپورت.</span>
                                    <a href="<?php echo KCP_ASSETS_URL; ?>files/import-order.xlsx" download
                                       class="btn btn-info btn-sm" style="margin-right: auto;">
                                        <span>اکسل نمونه سفارشات</span>
                                        <em class="icon ni ni-download"></em>
                                    </a>
                                </div>
                            </div>
                            <div class="card-inner card-inner-md bg-light rounded-3 mt-1">
                                <div class="card-note">
                                    <em class="icon ni ni-info-fill"></em>
                                    <span>در وارد کردن شناسه محصول در فایل اکسل نهایت دقت را داشته باشید و به صورت عدد لاتین در اکسل وارد کنید. شناسه محصولات را می توانید از بخش تنظیمات مشاهده کنید.</span>
                                </div>
                            </div>
                            <div class="card-inner card-inner-md bg-light rounded-3 mt-1">
                                <div class="card-note">
                                    <em class="icon ni ni-info-fill"></em>
                                    <span>در صورت خالی گذاشتن ستون subtotal (قیمت فروش محصول) این مقدار به صورت پیشفرض از روی محصول ثبت می شود. مقدار باید به تومان و بدون علامت اضافه ثبت شود.</span>
                                </div>
                            </div>
                            <div class="card-inner card-inner-md bg-light rounded-3 mt-1">
                                <div class="card-note">
                                    <em class="icon ni ni-info-fill"></em>
                                    <span>در صورتی که مشتری محصولی را پیشتر خریداری کرده باشد و سفارش موفق داشته باشد ثبت سفارش مجدد انجام نمی شود.</span>
                                </div>
                            </div>
                            <div class="card-inner card-inner-md bg-light rounded-3 mt-1">
                                <div class="card-note">
                                    <em class="icon ni ni-info-fill"></em>
                                    <span>فایل اکسل حتما بایستی یک sheet داشته باشد.</span>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane" id="import_qty">
                            <div class="form-group">
                                <label class="form-label">ایمپورت موجودی</label>
                                <div class="form-control-wrap">
                                    <div class="form-file">
                                        <input type="file" class="form-file-input" id="import_qty_file">
                                        <label class="form-file-label" for="import_qty_file">
                                            <span>انتخاب فایل اکسل</span>
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="align-center justify-between gap-sm-2 mb-4">
                                <button class="btn btn-primary start_import"
                                        data-progress="qty_import_progress"
                                        data-per-page="50"
                                        data-file="import_qty_file" data-action="crm_import_qty">
                                    <span>آغاز ایمپورت</span>
                                </button>
                                <div class="progress" style="flex-grow: 1;">
                                    <div class="progress-bar progress-bar-striped progress-bar-animated"
                                         id="qty_import_progress"
                                         data-progress="0"></div>
                                </div>
                            </div>
                            <div class="card-inner card-inner-md bg-danger-dim rounded-3 mt-1 text-danger">
                                <div class="card-note ">
                                    <em class="icon ni ni-info-fill"></em>
                                    <span>تا پایان ایمپورت از رفرش کردن و بستن این صفحه به شدت خودداری بفرمایید.</span>
                                </div>
                            </div>
                            <div class="card-inner card-inner-md bg-light rounded-3 mt-1">
                                <div class="card-note">
                                    <em class="icon ni ni-info-fill"></em>
                                    <span>فایل اکسل حتما بایستی یک sheet داشته باشد.</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
