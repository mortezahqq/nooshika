<?php
if ( ! current_user_can( 'manage_options' ) ) {
	?>
    <div class="container-xl wide-xl">
        <div class="card text-danger text-center fw-bold">
            <div class="card-inner">شما دسترسی لازم برای مشاهده این صفحه را ندارید</div>
        </div>
    </div>
	<?php
	return;
}

$defaults = [
	'date' => [
		'from' => '1405-1-1',
		'to'   => '',
	],
];
$args     = wp_parse_args( $_REQUEST, $defaults );
extract( $args );
$date      = is_array( $date ) ? $date : [];
$date_from = $date['from'] ?? '';
$date_to   = $date['to'] ?? '';

$kasebi_order_class = new Kasebi_Order_Index();
$orders_report      = $kasebi_order_class->get_orders_report( $date_from, $date_to );
if ( ! empty( $orders_report['products'] ) ) {
	uasort( $orders_report['products'], function( $a, $b ) {
		return $b['total'] <=> $a['total']; // بیشترین فروش اول
	} );
}
if ( ! empty( $orders_report['marketers'] ) ) {
	uasort( $orders_report['marketers'], function( $a, $b ) {
		return $b['total'] <=> $a['total']; // بیشترین فروش اول
	} );
}
?>
<div class="nk-block-head nk-block-head-sm">
    <div class="nk-block-between">
        <div class="nk-block-head-content">
            <h3 class="nk-block-title page-title">گزارش جامع فروش:</h3>
        </div>
        <div class="card-tools">
            <ul class="btn-toolbar gx-1">
                <li>
					<?php
					$filter_fields = [
						[
							'type'  => 'date-range',
							'label' => 'تاریخ گزارش',
							'name'  => 'date',
							'value' => [
								'from' => $date_from ?? '',
								'to'   => $date_to ?? '',
							],
						],
					
					];
					echo crm_get_template( 'partials/filter-dropdown.php', [
						'has_filter'    => FALSE,
						'filter_fields' => $filter_fields,
					] );
					?>
                </li>
            </ul>
        </div>
    </div>
</div>
<div class="nk-block">
    <div class="row g-gs">
        <div class="col-8">
            <div class="card">
                <div class="card-inner">
                    <div class="card-title-group mb-2">
                        <div class="card-title">
                            <h6 class="title">گزارش بازاریابان</h6>
                        </div>
                    </div>
                    <div class="tab-content">
                        <ul class="gy-4">
							<?php
							$total_items = count( $orders_report['marketers'] );
							$i           = 0;
							foreach ( $orders_report['marketers'] as $marketer_id => $report ) {
								$i ++;
								$is_last = $i === $total_items;
								?>
                                <li class="justify-between align-center border-0 border-dashed <?php echo $is_last ? '' : 'border-bottom'; ?>">
                                    <div class="ms-2">
                                        <div class="lead-text"><?php echo get_user_name_by_id( $marketer_id ); ?></div>
                                        <div class="sub-text"><?php echo $report['count']; ?> سفارش موفق</div>
                                    </div>
                                    <div class="fs-20px me-1">
										<?php echo number_format( $report['total'] ); ?> تومان
                                    </div>
                                </li>
								<?php
							}
							?>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-inner">
                    <div class="card-title-group mb-2">
                        <div class="card-title">
                            <h6 class="title">گزارش محصولات پرفروش</h6>
                        </div>
                    </div>
                    <div class="tab-content">
                        <ul class="gy-4">
							<?php
							$total_items = count( $orders_report['products'] );
							$i           = 0;
							foreach ( $orders_report['products'] as $product_id => $report ) {
								$i ++;
								$is_last = $i === $total_items;
								?>
                                <li class="justify-between align-center border-0 border-dashed <?php echo $is_last ? '' : 'border-bottom'; ?>">
                                    <div class="ms-2">
                                        <div class="lead-text"><?php echo get_the_title( $product_id ); ?></div>
                                        <div class="sub-text"><?php echo $report['count']; ?> سفارش موفق</div>
                                    </div>
                                    <div class="fs-20px me-1">
										<?php echo number_format( $report['total'] ); ?> تومان
                                    </div>
                                </li>
								<?php
							}
							?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-4">
            <h6 class="title mb-2">گزارش مسیر های بازاریابی</h6>
            <div class="card">
                <div class="card-inner">
                    <div class="card-title-group mb-2">
                        <h6 class="card-title">SOURCES</h6>
                    </div>
                    <div class="tab-content">
                        <ul class="gy-4">
							<?php
							$sources = $orders_report['utms']['source'];
							$i       = 0;
							uasort( $sources, function( $a, $b ) {
								return $b['total'] <=> $a['total']; // بیشترین فروش اول
							} );
							foreach ( $sources as $value => $report ) {
								$i ++;
								if ( $i > 5 ) {
									break;
								}
								?>
                                <li class="justify-between align-center border-0 border-dashed <?php echo $i == 5 ? '' :
									'border-bottom'; ?>">
                                    <div class="ms-2">
                                        <div class="lead-text"><?php echo $value; ?></div>
                                        <div class="sub-text"><?php echo $report['count']; ?> سفارش موفق</div>
                                    </div>
                                    <div class="fs-20px me-1">
										<?php echo number_format( $report['total'] ); ?> تومان
                                    </div>
                                </li>
								<?php
							}
							?>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-inner">
                    <div class="card-title-group mb-2">
                        <h6 class="card-title">MEDIUM</h6>
                    </div>
                    <div class="tab-content">
                        <ul class="gy-4">
							<?php
							$mediums = $orders_report['utms']['medium'];
							uasort( $mediums, function( $a, $b ) {
								return $b['total'] <=> $a['total']; // بیشترین فروش اول
							} );
							$i = 0;
							foreach ( $mediums as $value => $report ) {
								$i ++;
								if ( $i > 5 ) {
									break;
								}
								?>
                                <li class="justify-between align-center border-0 border-dashed <?php echo $i == 5 ? '' :
									'border-bottom'; ?>">
                                    <div class="ms-2">
                                        <div class="lead-text"><?php echo $value; ?></div>
                                        <div class="sub-text"><?php echo $report['count']; ?> سفارش موفق</div>
                                    </div>
                                    <div class="fs-20px me-1">
										<?php echo number_format( $report['total'] ); ?> تومان
                                    </div>
                                </li>
								<?php
							}
							?>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-inner">
                    <div class="card-title-group mb-2">
                        <h6 class="card-title">CAMPAIGN</h6>
                    </div>
                    <div class="tab-content">
                        <ul class="gy-4">
							<?php
							$campaign = $orders_report['utms']['campaign'];
							uasort( $campaign, function( $a, $b ) {
								return $b['total'] <=> $a['total']; // بیشترین فروش اول
							} );
							$i = 0;
							foreach ( $mediums as $value => $report ) {
								$i ++;
								if ( $i > 5 ) {
									break;
								}
								?>
                                <li class="justify-between align-center border-0 border-dashed <?php echo $i == 5 ? '' :
									'border-bottom'; ?>">
                                    <div class="ms-2">
                                        <div class="lead-text"><?php echo $value; ?></div>
                                        <div class="sub-text"><?php echo $report['count']; ?> سفارش موفق</div>
                                    </div>
                                    <div class="fs-20px me-1">
										<?php echo number_format( $report['total'] ); ?> تومان
                                    </div>
                                </li>
								<?php
							}
							?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
