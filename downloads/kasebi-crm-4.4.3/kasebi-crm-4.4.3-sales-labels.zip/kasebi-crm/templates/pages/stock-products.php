<?php

$per_page_key = basename( __FILE__, '.php' );
$per_page_key = "crm_{$per_page_key}_per_page";
$user_id      = get_current_user_id();
$defaults     = [
	'page_number' => 1,
	'per_page'    => get_user_meta( $user_id, $per_page_key, TRUE ) ?: 20,
	'date'        => [
		'from' => '',
		'to'   => '',
	],
	'stock'       => '',
	'sku'         => '',
	'step_type'   => '',
	'status'      => '',
	'search'      => '',
	'serial'      => '',
	'brand'       => '',
	'order_id'    => '',
];
$args         = wp_parse_args( $_REQUEST, $defaults );
$args         = array_map( fn( $v ) => $v == 0 ? '' : $v, $args );
$has_filter   = kcp_page_has_filter( $args, $defaults );
extract( $args );
update_user_meta( $user_id, $per_page_key, $per_page );
$date           = is_array( $date ) ? $date : [];
$date_from      = $date['from'] ?? '';
$date_to        = $date['to'] ?? '';
$DB             = new kcp_stock();
$logs           = $DB->get_warehouse_products_rows(
	compact( 'per_page', 'page_number', 'date_from', 'date_to', 'stock', 'serial',
		'sku', 'step_type', 'status', 'search', 'brand', 'order_id' ) );
$total_logs     = $logs['total'];
$total_page     = $logs['pages'];
$store_products = $logs['rows'];
$process_types  = $DB->get_stock_process_types();
$item_statuses  = $DB->get_stock_item_statuses();
$step_types     = $DB->get_stock_item_step_types();

?>
<div class="nk-block-head nk-block-head-sm">
    <div class="nk-block-between">
        <div class="nk-block-head-content">
            <h3 class="nk-block-title page-title">انبار محصولات</h3>
        </div>
    </div>
</div>
<div class="nk-block">
    <div class="card card-stretch">
        <div class="card-inner-group">
            <div class="card-inner position-relative card-tools-toggle">
                <div class="card-title-group">
                    <div class="card-tools">
                    </div>
                    <div class="card-tools">
                        <ul class="btn-toolbar gx-1">
                            <li>
								<?php
								$filter_fields = [
									[
										'type'  => 'date-range',
										'label' => 'تاریخ آخرین ویرایش',
										'name'  => 'date',
										'value' => [
											'from' => $date_from ?? '',
											'to'   => $date_to ?? '',
										],
									],
									[
										'type'  => 'text',
										'label' => 'شماره سریال کالا',
										'name'  => 'serial',
										'value' => $serial,
									],
									[
										'type'  => 'text',
										'label' => 'جستجوی محصول',
										'name'  => 'search',
										'col'   => 6,
										'value' => $search,
									],
									[
										'type'  => 'text',
										'label' => 'شناسه سفارش',
										'name'  => 'order_id',
										'col'   => 6,
										'value' => $order_id,
									],
									[
										'type'    => 'select',
										'label'   => 'آخرین فعالیت',
										'name'    => 'step_type',
										'value'   => $step_type,
										'options' => [ 0 => 'همه موارد' ] + array_combine(
												array_keys( $step_types ),
												array_column( $step_types, 'label' )
											),
									],
									[
										'type'    => 'select',
										'label'   => 'وضعیت محصول',
										'name'    => 'status',
										'value'   => $status,
										'options' => [ 0 => 'همه موارد' ] + array_combine(
												array_keys( $item_statuses ),
												array_column( $item_statuses, 'label' )
											),
									],
								];
								echo crm_get_template( 'partials/filter-dropdown.php', [
									'has_filter'    => $has_filter,
									'filter_fields' => $filter_fields,
								] );
								?>
                            </li>
                            <li class="btn-toolbar-sep"></li>
                            <li>
								<?php
								echo crm_get_template( 'partials/per-page-selector.php', [
									'per_page' => $per_page,
								] );
								?>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="card-inner p-0">
                <table class="nk-tb-list nk-tb-ulist">
                    <thead>
                    <tr class="nk-tb-item nk-tb-head">
                        <td class="nk-tb-col"><span class="sub-text">محصول</span></td>
                        <td class="nk-tb-col"><span class="sub-text">سریال محصول</span></td>
                        <td class="nk-tb-col"><span class="sub-text">وضعیت محصول</span></td>
                        <td class="nk-tb-col"><span class="sub-text">آخرین اقدام</span></td>
                        <td class="nk-tb-col nk-tb-col-tools text-end"></td>
                    </tr>
                    </thead>
                    <tbody>
					<?php
					foreach ( $store_products as $store_product ) {
						extract( $store_product );
						$qty_color = $io_type == 'in' ? 'success' : 'danger';
						$qty_icon  = $io_type == 'in' ? 'plus-sm' : 'minus-sm';
						$product   = wc_get_product( $product_id );
						if ( ! $product ) {
							continue;
						}
						
						$last_step       = $DB->get_last_step_for_item( $item_id );
						$last_step_type  = $last_step['step_type'];
						$last_step_date  = $last_step['date'];
						$allowed_actions = $DB->get_allowed_next_steps( compact( 'status', 'last_step_type' ) );
						$order_id        = $DB->get_meta( 'item', $item_id, 'order_id', TRUE ) ?: '';
						?>
                        <tr class="nk-tb-item">
                            <td class="nk-tb-col"><?php echo $product_name; ?></td>
                            <td class="nk-tb-col"><?php echo $serial; ?></td>
                            <td class="nk-tb-col">
                                <span class="badge <?php echo $item_statuses[ $status ]['class']; ?>">
                                    <?php echo $item_statuses[ $status ]['label']; ?>
                                </span>
                            </td>
                            <td class="nk-tb-col">
                                <span
                                    class="badge <?php echo $step_types[ $last_step_type ]['class']; ?>">
                                    <?php echo $step_types[ $last_step_type ]['label']; ?>
                                </span>
                            </td>
                            <td class="nk-tb-col">
                                <ul class="nk-tb-actions gx-2">
									<?php
									$actions = [
										[
											'link'  => '',
											'title' => 'اقدامات صورت گرفته',
											'icon'  => 'ni-list-thumb-alt',
											'class' => 'view_stock_log_steps',
											'data'  => [
												'item-id' => $item_id,
											],
										],
									];
									if ( $order_id ) {
										$actions[] = [
											'link'  => '',
											'title' => 'ثبت شده برای سفارش:' . $order_id,
											'icon'  => 'ni-package',
										];
										$order     = wc_get_order( $order_id );
										if ( $order ) {
											$user_id   = $order->get_customer_id();
											$actions[] = [
												'link'  => '/crm/user/' . $user_id,
												'title' => get_user_name_by_id( $user_id ),
												'icon'  => 'ni-eye',
												'class' => 'page_activator',
											];
										}
									}
									echo crm_get_template( 'partials/row-actions-hidden.php', [
										'actions' => $actions,
									] );
									?>
                                </ul>
                            </td>
                        </tr>
						<?php
					}
					?>
                    </tbody>
                </table>
            </div>
            <div class="card-inner">
				<?php
				echo crm_get_template( 'partials/pagination.php', [
					'max_page_num' => $total_page,
					'current_page' => $page_number,
					'class_name'   => 'user_pagination_link',
					'show_count'   => 2,
				] );
				?>
            </div>
        </div>
    </div>
</div>

