<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

$per_page_key = basename( __FILE__, '.php' );
$per_page_key = "crm_{$per_page_key}_per_page";
$user_id      = get_current_user_id();
$defaults     = [
	'page_number' => 1,
	'per_page'    => get_user_meta( $user_id, $per_page_key, TRUE ) ?: 20,
	'date'        => [
		'from' => '',
		'to'   => '',
	],
	'search'      => '',
	'search_user' => '',
	'creator'     => '',
	'status'      => '',
	'category'    => '',
];
$args         = wp_parse_args( $_REQUEST, $defaults );
$args         = array_map( fn( $v ) => $v == 0 ? '' : $v, $args );
$has_filter   = kcp_page_has_filter( $args, $defaults );
extract( $args );
update_user_meta( $user_id, $per_page_key, $per_page );
$offset          = ( $page_number - 1 ) * $per_page;
$date            = is_array( $date ) ? $date : [];
$date_from       = $date['from'] ?? '';
$date_to         = $date['to'] ?? '';
$DB              = new kcp_db();
$calls           = $DB->get_calls(
	compact( 'per_page', 'offset', 'date_from', 'date_to',
		'search', 'search_user', 'creator', 'status', 'category' ) );
$total           = $calls['total'] ?: 0;
$total_page      = ceil( $total / $per_page );
$calls           = $calls['result'];
$employees       = get_users( [
	'role__in' => kcp_get_all_roles(),
	'fields'   => 'ids',
] );
$call_statuses   = $DB->get_call_statuses();
$call_categories = $DB->get_call_categories();
$query_args      = array_merge( [
	'action' => 'print',
	'type'   => 'call',
], compact( 'per_page', 'offset', 'date_from', 'date_to', 'search', 'search_user', 'creator', 'status', 'category' ) );
$query_args      = array_filter( $query_args );
?>
<div class="nk-block-head nk-block-head-sm">
    <div class="nk-block-between">
        <div class="nk-block-head-content">
            <h3 class="nk-block-title page-title">لیست درخواست های مشتریان</h3>
            <div class="nk-block-des text-soft">
                <p class="mb-0">شما در مجموع <?php echo $total; ?> درخواست ثبت شده دارید.</p>
            </div>
        </div>
        <div class="nk-block-head-content">
            <div class="toggle-wrap nk-block-tools-toggle">
                <div class="toggle-expand-content">
                    <ul class="nk-block-tools g-3">
                        <li class="nk-block-tools-opt">
                            <a href="<?php echo add_query_arg( $query_args, home_url( '/crm/' ) ); ?>"
                               class="btn btn-info" target="_blank">
                                <em class="icon ni ni-printer-fill"></em><span>پرینت</span>

                            </a>
                        </li>
                        <li class="nk-block-tools-opt">
                            <a href="#addCall" class="btn btn-icon btn-primary" data-bs-target="#addCall"
                               data-bs-toggle="modal"><em class="icon ni ni-plus"></em></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="nk-block">
    <div class="card card-stretch">
        <div class="card-inner-group">
            <div class="card-inner position-relative card-tools-toggle">
                <div class="card-title-group">
                    <div class="card-tools">
                        <a class="btn btn-icon search-toggle toggle-search" data-target="search_calls">
                            <em class="icon ni ni-search"></em>
                        </a>
                    </div>
                    <div class="card-tools">
                        <ul class="btn-toolbar gx-1">
                            <li>
								<?php
								$filter_fields = [
									[
										'type'  => 'date-range',
										'label' => 'تاریخ ثبت درخواست',
										'name'  => 'date',
										'value' => [
											'from' => $date_from ?? '',
											'to'   => $date_to ?? '',
										],
									],
									[
										'type'  => 'text',
										'label' => 'جستجوی مشتری',
										'name'  => 'search_user',
										'value' => $search_user,
									],
									[
										'type'    => 'select',
										'label'   => 'ثبت کننده',
										'name'    => 'creator',
										'value'   => $creator,
										'col'     => 6,
										'options' => [ 0 => 'همه موارد' ] + array_combine(
												$employees,
												array_map( 'get_user_name_by_id', $employees )
											),
									],
									[
										'type'    => 'select',
										'label'   => 'وضعیت',
										'name'    => 'status',
										'value'   => $status,
										'col'     => 6,
										'options' => [ 0 => 'همه موارد' ] + array_combine(
												array_keys( $call_statuses ),
												array_column( $call_statuses, 'label' )
											),
									],
									[
										'type'    => 'select',
										'label'   => 'واحد مربوطه',
										'name'    => 'category',
										'value'   => $category,
										'options' => [ 0 => 'همه موارد' ] + array_combine(
												array_keys( $call_categories ),
												array_column( $call_categories, 'label' )
											),
									],
								];
								echo crm_get_template( 'partials/filter-dropdown.php', [
									'has_filter'    => $has_filter,
									'filter_fields' => $filter_fields,
								] );
								?>
                            </li>
                            <li class="btn-toolbar-sep"></li>
                            <li>
								<?php
								echo crm_get_template( 'partials/per-page-selector.php', [
									'per_page' => $per_page,
								] );
								?>
                            </li>
                        </ul>
                    </div>
                    <div class="card-search search-wrap<?php echo $search ? ' active' : ''; ?>"
                         data-search="search_calls">
                        <div class="card-body">
                            <div class="search-content">
                                <a href="#" class="search-back btn btn-icon toggle-search"
                                   data-target="search_visits"><em
                                        class="icon ni ni-arrow-left"></em></a>
                                <input type="text" value="<?php echo $search; ?>"
                                       class="form-control border-transparent form-focus-none search_crm_list"
                                       placeholder="جستجو میان درخواست ها">
                                <div class="search-submit btn btn-icon submit_search_actions">
                                    <em class="icon ni ni-search"></em>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-inner p-0">
                <div class="nk-tb-list nk-tb-ulist is-compact">
                    <div class="nk-tb-item nk-tb-head">
                        <div class="nk-tb-col tb-col-md"><span class="sub-text">تاریخ</span></div>
                        <div class="nk-tb-col tb-col-md"><span class="sub-text">وضعیت</span></div>
                        <div class="nk-tb-col ps-3 ps-md-2"><span class="sub-text">مشتری</span></div>
                        <div class="nk-tb-col tb-col-md"><span class="sub-text">واحد ارجاع</span></div>
                        <div class="nk-tb-col tb-col-md"><span class="sub-text">مسئول انجام</span></div>
                        <div class="nk-tb-col"><span class="sub-text">توضیحات</span></div>
                        <div class="nk-tb-col nk-tb-col-tools text-end"></div>
                    </div>
					<?php
					if ( empty( $calls ) ) {
						echo '<div class="no-item-found">درخواستی یافت نشد</div>';
					} else {
						foreach ( $calls as $call ) {
							extract( $call );
							$creator           = get_user_name_by_id( $creator_id );
							$status_badge      = $call_statuses[ $status ]['class'];
							$status_label      = $call_statuses[ $status ]['label'];
							$attachment        = $DB->get_call_meta( $id, 'attachment' );
							$assigned_to       = $DB->get_call_meta( $id, 'assigned_to' );
							$assigned_to       = $assigned_to ? get_user_name_by_id( $assigned_to ) : '-';
							$report_content_id = wp_unique_id( 'report_content_' );
							?>
                            <div class="nk-tb-item">
                                <div class="nk-tb-col tb-col-md">
                                    <span class="sub-text">
                                        <?php echo date_i18n( 'j F Y', strtotime( $created_at ) ); ?></span>
                                </div>
                                <div class="nk-tb-col tb-col-md">
                                    <span class="badge <?php echo $status_badge; ?>"><?php echo $status_label; ?></span>
                                </div>
                                <div class="nk-tb-col ps-3 ps-md-2">
									<?php
									echo crm_get_template( 'partials/user-card.php', [
										'user_id'    => $user_id,
										'show_phone' => TRUE,
									] );
									?>
                                </div>
                                <div class="nk-tb-col tb-col-md">
									<?php echo $call_categories[ $category ]['label']; ?>
                                </div>
                                <div class="nk-tb-col tb-col-md">
									<?php echo $assigned_to; ?>
                                </div>
                                <div class="nk-tb-col">
                                    <div class="w-max-250px w-250px fs-12px nk-news-text atlas-report-modal-trigger"
                                         data-bs-toggle="modal"
                                         data-bs-target="#atlasReportContentModal"
                                         data-content-target="#<?php echo esc_attr( $report_content_id ); ?>"
                                         style="cursor:pointer;">
                                        <p><?php echo esc_html( wp_strip_all_tags( $content ) ); ?></p>
                                    </div>
                                </div>
                                <div id="<?php echo esc_attr( $report_content_id ); ?>" class="d-none">
									<?php echo wpautop( ( $content ) ); ?>
                                </div>
                                <div class="nk-tb-col nk-tb-col-tools">
                                    <ul class="nk-tb-actions gx-2">
										<?php
										$hidden_actions = [
											[
												'link'  => '',
												'title' => $creator,
												'icon'  => 'ni-user-check',
											],
										];
										if ( $attachment ) {
											array_unshift( $hidden_actions, [
												'link'     => $attachment,
												'title'    => 'فایل ضمیمه',
												'icon'     => 'ni-download',
												'download' => TRUE,
											] );
										}
										echo crm_get_template( 'partials/row-actions-hidden.php', [
											'actions' => $hidden_actions,
										] );
										?>
                                        <li>
											<?php
											$actions = [
												[
													'link'  => '',
													'title' => 'تغییر وضعیت',
													'icon'  => 'ni-repeat',
													'class' => 'change_call_status',
													'data'  => [
														'item-id' => $id,
													],
												],
												[
													'link'  => '',
													'title' => 'اقدامات صورت گرفته',
													'icon'  => 'ni-list-thumb-alt',
													'class' => 'view_call_progress',
													'data'  => [
														'item-id' => $id,
													],
												],
												[
													'link'  => '/crm/user/' . $user_id,
													'title' => 'مشخصات مشتری',
													'icon'  => 'ni-eye',
													'class' => 'page_activator',
												],
												[
													'link'  => '/crm/user/' . $user_id . '?tab=call',
													'title' => 'همه درخواست ها',
													'icon'  => 'ni-chat-msg',
													'class' => 'page_activator',
												],
												[
													'link'  => '',
													'title' => 'حذف درخواست',
													'icon'  => 'ni-trash',
													'class' => 'delete_db_item',
													'data'  => [
														'action'  => 'crm_delete_call',
														'item_id' => $id,
														'tab'     => 'call',
														'page'    => '/crm/users-call',
													],
												],
											];
											echo crm_get_template( 'partials/row-actions-dropdown.php', [
												'actions' => $actions,
											] );
											?>
                                        </li>
                                    </ul>
                                </div>
                            </div>
							<?php
						}
					}
					?>
                </div>
            </div>
            <div class="card-inner">
				<?php
				echo crm_get_template( 'partials/pagination.php', [
					'max_page_num' => $total_page,
					'current_page' => $page_number,
					'class_name'   => 'user_pagination_link',
					'show_count'   => 2,
				] );
				?>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="atlasReportContentModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title">محتوای درخواست </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="بستن"></button>
            </div>

            <div class="modal-body atlas-report-modal-body"></div>

        </div>
    </div>
</div>