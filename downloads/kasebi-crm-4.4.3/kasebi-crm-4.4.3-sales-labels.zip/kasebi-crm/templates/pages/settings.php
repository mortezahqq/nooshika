<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
if ( isset( $_REQUEST['id'] ) ) {
	$user_id = $_REQUEST['id'];
} else {
	global $wp;
	$path    = explode( '/', $wp->request );
	$user_id = $path[2];
}
$tab       = $_REQUEST['tab'] ?? 'site-settings';
$tabs_list = [
	'site-settings' => [
		'label' => 'تنظیمات سایت',
		'icon'  => 'laptop',
	],
	'sms'           => [
		'label' => 'پنل پیامکی',
		'icon'  => 'mail',
	],
];
?>
<div class="nk-block nk-block-lg">
    <div class="card">
        <div class="card-aside-wrap">
            <div class="card-content">
                <ul class="nav nav-tabs nav-tabs-mb-icon nav-tabs-card">
					<?php
					foreach ( $tabs_list as $tab_key => $tab_data ) {
						$active = $tab == $tab_key ? ' active' : '';
						?>
                        <li class="nav-item">
                            <a class="page_activator nav-link<?php echo $active; ?>"
                               href="<?php echo '/crm/settings/' . $user_id . '?tab=' . $tab_key; ?>"
                               data-url="<?php echo '/crm/settings/' . $user_id . '?tab=' . $tab_key; ?>">
                                <em class="icon ni ni-<?php echo $tab_data['icon']; ?>"></em>
                                <span><?php echo $tab_data['label']; ?></span>
                            </a>
                        </li>
						<?php
					}
					?>
                </ul>
                <div class="card-inner">
                    <div class="tab-content">
                        <div class="tab-pane active">
							<?php echo crm_get_template( "tab/settings/$tab.php", [ 'user_id' => $user_id ] ); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
