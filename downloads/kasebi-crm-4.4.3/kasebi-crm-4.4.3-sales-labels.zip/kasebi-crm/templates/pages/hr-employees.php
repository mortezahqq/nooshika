<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
global $wpdb;
$prefix                             = $wpdb->prefix;
$action_table                       = $prefix . 'kcp_actions';
$order_meta                         = $prefix . 'wc_orders_meta';
$order_table                        = $prefix . 'wc_order_stats';
$track_table                        = $prefix . 'kcp_track_logs';
$all_roles                          = kcp_get_all_roles( FALSE );
$employees                          = get_users( [
	'fields'   => 'ids',
	'orderby'  => 'ID',
	'order'    => 'DESC',
	'role__in' => $all_roles,
] );
$order_index                        = new Kasebi_Order_Index();
$get_employee_completed_order_count = static function( int $user_id ) use ( $order_index ): int {
	$query = $order_index->find_orders( [
		'per_page'    => 1,
		'page_number' => 1,
		'status'      => [
			'wc-completed',
			'wc-delivered',
			'wc-processing',
		],
		'marketer_id' => $user_id,
		'order_by'    => 'date',
		'order'       => 'DESC',
	] );
	
	$pagination = is_array( $query['pagination'] ?? NULL )
		? $query['pagination']
		: [];
	
	return (int) ( $pagination['total'] ?? 0 );
};
?>
<div class="nk-block-head nk-block-head-sm">
    <div class="nk-block-between">
        <div class="nk-block-head-content">
            <h3 class="nk-block-title page-title">لیست کارمندان</h3>
            <div class="nk-block-des text-soft">
                <p>شما در مجموع <?php echo count( $employees ); ?> کارمند دارید.</p>
            </div>
        </div>
        <div class="nk-block-head-content">
            <div class="toggle-wrap nk-block-tools-toggle card-tools ">
                <ul class="g-3 btn-toolbar">
                    <li class="nk-block-tools-opt">
                        <div data-bs-toggle="tooltip" data-bs-placement="top" title="افزودن کارمند">
                            <div class="dropdown-toggle btn btn-icon btn-primary" data-bs-toggle="modal"
                                 data-bs-target="#addMarketer"><em class="icon ni ni-plus"></em></div>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<div class="nk-block">
    <div class="row g-gs">
		<?php
		foreach ( $employees as $user_id ) {
			$name          = get_user_name_by_id( $user_id );
			$user_login    = get_user_by( 'ID', $user_id )->user_login;
			$balance       = woo_wallet()->wallet->get_wallet_balance( $user_id, 'edit' );
			$actions_query = "SELECT count(*) FROM $action_table WHERE creator = $user_id";
			$action_count  = $wpdb->get_var( $actions_query );
			$tracks_query  = "SELECT count(*) FROM $track_table WHERE creator = $user_id AND status = 'completed'";
			$order_count   = $get_employee_completed_order_count( (int) $user_id );
			$tracks_count  = $wpdb->get_var( $tracks_query );
			$user_role     = nooshika_get_user_role( $user_id );
			$role          = kcp_get_role_label( $user_role );
			?>
            <div class="col-md-4">
                <div class="card card-bordered card-full">
                    <div class="card-inner">
                        <div class="team">
                            <div class="team-options">
								<?php
								$actions = [
									[
										'link'  => '/crm/employee/' . $user_id,
										'title' => 'مشخصات کارمند',
										'icon'  => 'ni-eye',
										'class' => 'page_activator',
									],
									[
										'link'  => '/crm/employee/' . $user_id . '?tab=wallet',
										'title' => 'کیف پول',
										'icon'  => 'ni-wallet',
										'class' => 'page_activator',
									],
									[
										'link'  => '',
										'title' => 'ورود با کارمند',
										'icon'  => 'ni-signin',
										'class' => 'login_as_this',
										'data'  => [
											'id' => $user_id,
										],
									],
									[ 'divider' => 'divider' ],
									[
										'link'  => '',
										'title' => 'بازنشانی رمز عبور',
										'icon'  => 'ni-repeat',
										'class' => 'reset_password',
										'data'  => [
											'id' => $user_id,
										],
									],
									[
										'link'  => '',
										'title' => 'ارسال اخطاریه',
										'icon'  => 'ni-alert',
										'class' => 'send_alert_employee',
										'data'  => [
											'id' => $user_id,
										],
									],
									[
										'link'  => '',
										'title' => 'حذف کارمند',
										'icon'  => 'ni-user-cross',
										'class' => 'delete_user',
										'data'  => [
											'user-id' => $user_id,
										],
									],
								];
								echo crm_get_template( 'partials/row-actions-dropdown.php', [
									'actions' => $actions,
								] );
								?>
                            </div>
                            <div class="user-card user-card-s2">
                                <div class="user-avatar md bg-white text-primary">
                                    <em class="icon ni ni-user-circle" style="font-size: 60px"></em>
                                </div>
                                <div class="user-info">
                                    <h6><?php echo $name; ?></h6>
                                    <span class="sub-text"><?php echo $role; ?></span>
                                    <span class="sub-text">@<?php echo $user_login; ?></span>
                                </div>
                                <div class="d-flex align-center text-soft" style="gap:0.25rem">
                                    <em class="icon ni ni-wallet-fill"></em>
                                    <span><?php echo number_format( $balance ); ?></span>
                                </div>
                            </div>
                            <ul class="team-statistics">
                                <li class="col-4"><span><?php echo $action_count; ?></span><span>فعالیت</span></li>
                                <li class="col-4"><span><?php echo $order_count; ?></span><span>سفارش موفق</span></li>
                                <li class="col-4"><span><?php echo $tracks_count; ?></span><span>پیگیری موفق</span></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
			<?php
		}
		?>
    </div>
</div>
