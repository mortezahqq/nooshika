<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
$per_page_key = basename( __FILE__, '.php' );
$per_page_key = "crm_{$per_page_key}_per_page";
$user_id      = get_current_user_id();
$defaults     = [
	'page_number' => 1,
	'per_page'    => get_user_meta( $user_id, $per_page_key, TRUE ) ?: 20,
	'date'        => [
		'from' => '',
		'to'   => '',
	],
	'due_date'    => '',
	'search'      => '',
	'search_user' => '',
	'creator'     => '',
	'type'        => '',
	'status'      => '',
];
$args         = wp_parse_args( $_REQUEST, $defaults );
$args         = array_map( fn( $v ) => $v == 0 ? '' : $v, $args );
$has_filter   = kcp_page_has_filter( $args, $defaults );
extract( $args );
update_user_meta( $user_id, $per_page_key, $per_page );
$offset       = ( $page_number - 1 ) * $per_page;
$date         = is_array( $date ) ? $date : [];
$date_from    = $date['from'] ?? '';
$date_to      = $date['to'] ?? '';
$DB           = new kcp_db();
$tracks       = $DB->get_user_tracks(
	compact( 'per_page', 'offset', 'date_from', 'date_to', 'due_date',
		'search', 'search_user', 'creator', 'type', 'status' ) );
$total        = $tracks['count'] ?: 0;
$total_page   = ceil( $total / $per_page );
$tracks       = $tracks['result'];
$employees    = get_users( [
	'role__in' => kcp_get_all_roles(),
	'fields'   => 'ids',
] );
$track_type   = $DB->get_track_types();
$track_status = $DB->get_track_status();
$track_titles = $DB->track_title;

?>
<div class="nk-block-head nk-block-head-sm">
    <div class="nk-block-between">
        <div class="nk-block-head-content">
            <h3 class="nk-block-title page-title">لیست پیگیری ها</h3>
            <div class="nk-block-des text-soft">
                <p class="mb-0">شما در مجموع <?php echo $total; ?> پیگیری ثبت شده دارید.</p>
            </div>
        </div>
        <div class="nk-block-head-content">
            <div class="toggle-wrap nk-block-tools-toggle">
                <div class="toggle-expand-content">
                    <ul class="nk-block-tools g-3">
                        <li class="nk-block-tools-opt">
                            <a href="#addTrack" class=" btn btn-icon btn-primary" data-bs-target="#addTrack"
                               data-bs-toggle="modal"><em class="icon ni ni-plus"></em></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="nk-block">
    <div class="card card-stretch">
        <div class="card-inner-group">
            <div class="card-inner position-relative card-tools-toggle">
                <div class="card-title-group">
                    <div class="card-tools">
                        <a class="btn btn-icon search-toggle toggle-search" data-target="search_tracks">
                            <em class="icon ni ni-search"></em>
                        </a>
                    </div>
                    <div class="card-tools">
                        <ul class="btn-toolbar gx-1">
                            <li>
								<?php
								$filter_fields = [
									[
										'type'  => 'date-range',
										'label' => 'تاریخ ثبت پیگیری',
										'name'  => 'date',
										'value' => [
											'from' => $date_from ?? '',
											'to'   => $date_to ?? '',
										],
									],
									[
										'type'  => 'date',
										'label' => 'تاریخ انجام پیگیری',
										'name'  => 'due_date',
										'value' => $due_date,
									],
									[
										'type'  => 'text',
										'label' => 'جستجوی مشتری',
										'name'  => 'search_user',
										'value' => $search_user,
									],
									[
										'type'    => 'select',
										'label'   => 'ثبت کننده',
										'name'    => 'creator',
										'value'   => $creator,
										'col'     => 6,
										'options' => [ 0 => 'همه موارد' ] + array_combine(
												$employees,
												array_map( 'get_user_name_by_id', $employees )
											),
									],
									[
										'type'    => 'select',
										'label'   => 'وضعیت پیگیری',
										'name'    => 'status',
										'value'   => $status,
										'col'     => 6,
										'options' => [ 0 => 'همه موارد' ] + array_combine(
												array_keys( $track_status ),
												array_column( $track_status, 'label' )
											),
									],
									[
										'type'  => 'select',
										'label' => 'نوع پیگیری',
										'name'  => 'type',
										'value' => $type,
										'col'   => 6,
										
										'options' => [ 0 => 'همه موارد' ] + array_combine(
												array_keys( $track_type ),
												array_column( $track_type, 'label' ) ),
									],
								];
								echo crm_get_template( 'partials/filter-dropdown.php', [
									'has_filter'    => $has_filter,
									'filter_fields' => $filter_fields,
								] );
								?>
                            </li>
                            <li class="btn-toolbar-sep"></li>
                            <li>
								<?php
								echo crm_get_template( 'partials/per-page-selector.php', [
									'per_page' => $per_page,
								] );
								?>
                            </li>
                        </ul>
                    </div>
                    <div class="card-search search-wrap<?php echo $search ? ' active' : ''; ?>"
                         data-search="search_tracks">
                        <div class="card-body">
                            <div class="search-content">
                                <a href="#" class="search-back btn btn-icon toggle-search" data-target="search_actions"><em
                                        class="icon ni ni-arrow-left"></em></a>
                                <input type="text" value="<?php echo $search; ?>"
                                       class="form-control border-transparent form-focus-none search_crm_list"
                                       placeholder="جستجو میان پیگیری ها">
                                <div class="search-submit btn btn-icon submit_search_actions">
                                    <em class="icon ni ni-search"></em>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-inner p-0">
                <div class="nk-tb-list nk-tb-ulist is-compact">
                    <div class="nk-tb-item nk-tb-head">
                        <div class="nk-tb-col tb-col-md"><span class="sub-text">تاریخ</span></div>
                        <div class="nk-tb-col ps-3 ps-md-2"><span class="sub-text">مشتری</span></div>
                        <div class="nk-tb-col tb-col-md"><span class="sub-text">نوع پیگیری</span></div>
                        <div class="nk-tb-col tb-col-md"><span class="sub-text">عنوان</span></div>
                        <div class="nk-tb-col tb-col-md"><span class="sub-text">نتیجه</span></div>
                        <div class="nk-tb-col tb-col-md"><span class="sub-text">زمان پیگیری</span></div>
                        <div class="nk-tb-col"><span class="sub-text">توضیحات</span></div>
                        <div class="nk-tb-col tb-col-md"><span class="sub-text">ثبت کننده</span></div>
                        <div class="nk-tb-col nk-tb-col-tools text-end"></div>
                    </div>
					<?php
					if ( empty( $tracks ) ) {
						echo '<div class="no-item-found">پیگیری یافت نشد</div>';
					} else {
						foreach ( $tracks as $track ) {
							extract( $track );
							$status_badge      = $track_status[ $status ]['class'];
							$status_label      = $track_status[ $status ]['label'];
							$creator           = get_user_name_by_id( $creator );
							$report_content_id = wp_unique_id( 'report_content_' );
							?>
                            <div class="nk-tb-item">
                                <div class="nk-tb-col tb-col-md">
                                    <span class="sub-text">
                                        <?php echo date_i18n( 'j F Y', strtotime( $date ) ); ?></span>
                                </div>
                                <div class="nk-tb-col ps-3 ps-md-2">
									<?php
									echo crm_get_template( 'partials/user-card.php', [
										'user_id'    => $user_id,
										'show_phone' => TRUE,
									] );
									?>
                                </div>
                                <div class="nk-tb-col tb-col-md">
                                    <a class="btn btn-sm btn-icon btn-trigger" data-bs-toggle="tooltip"
                                       data-bs-placement="top"
                                       title="<?php echo $track_type[ $type ]['label']; ?>">
                                        <em class="icon ni ni-<?php echo $track_type[ $type ]['icon']; ?>"></em>
                                    </a>
                                </div>
                                <div class="nk-tb-col tb-col-md">
                                    <span><?php echo $track_titles[ $title ]; ?></span>
                                </div>
								<?php
								if ( $status == 'pending' ) {
									?>
                                    <div class="nk-tb-col tb-col-md">
                                        <span
                                            class="badge <?php echo $status_badge; ?>"><?php echo $status_label; ?></span>
                                    </div>
									<?php
								} else {
									?>
                                    <div class="nk-tb-col tb-col-md">
                                        <span class="badge <?php echo $status_badge; ?>"
                                              data-bs-toggle="popover"
                                              data-bs-trigger="click"
                                              data-bs-html="true"
                                              title="<?php echo date_i18n( 'j F Y', strtotime( $checked_date ) ); ?>"
                                              data-bs-content="<?php echo $check_result; ?>"
                                              data-bs-placement="top"><?php echo $status_label; ?></span>
                                    </div>
									<?php
								}
								?>
                                <div class="nk-tb-col text-center tb-col-md">
                                    <span><?php echo date_i18n( 'j F Y', strtotime( $track_date ) ); ?></span>
                                    <span class="sub-text"><?php echo $track_hour ?></span>
                                </div>
                                <div class="nk-tb-col">
                                    <div class="w-max-250px w-250px fs-12px nk-news-text atlas-report-modal-trigger"
                                         data-bs-toggle="modal"
                                         data-bs-target="#atlasReportContentModal"
                                         data-content-target="#<?php echo esc_attr( $report_content_id ); ?>"
                                         style="cursor:pointer;">
                                        <p><?php echo esc_html( wp_strip_all_tags( $content ) ); ?></p>
                                    </div>
                                </div>
                                <div id="<?php echo esc_attr( $report_content_id ); ?>" class="d-none">
									<?php echo wpautop( ( $content ) ); ?>
                                </div>
                                <div class="nk-tb-col tb-col-md">
                                    <span><?php echo $creator; ?></span>
                                </div>
                                <div class="nk-tb-col nk-tb-col-tools">
                                    <ul class="nk-tb-actions gx-2">
										<?php
										$hidden_actions = [];
										if ( $status == 'pending' ) {
											array_unshift( $hidden_actions, [
												'link'  => '',
												'title' => 'ثبت نتیجه',
												'icon'  => 'ni-check-thick',
												'class' => 'submit_track_check',
												'data'  => [
													'item-id' => $item_id,
												],
											] );
										}
										echo crm_get_template( 'partials/row-actions-hidden.php', [
											'actions' => $hidden_actions,
										] );
										?>
                                        <li>
											<?php
											$actions = [
												[
													'link'  => '/crm/user/' . $user_id,
													'title' => 'مشخصات مشتری',
													'icon'  => 'ni-eye',
													'class' => 'page_activator',
												],
												[
													'link'  => '/crm/user/' . $user_id . '?tab=track',
													'title' => 'همه پیگیری ها',
													'icon'  => 'ni-call-alt',
													'class' => 'page_activator',
												],
												'delete' => [
													'link'  => '',
													'title' => 'حذف پیگیری',
													'icon'  => 'ni-trash',
													'class' => 'delete_db_item',
													'data'  => [
														'action'  => 'crm_delete_track',
														'item_id' => $item_id,
														'tab'     => 'track',
														'page'    => '/crm/users-track',
													],
												],
											];
											if ( ! is_current_user_admin() ) {
												//												unset( $actions['delete'] );
											}
											echo crm_get_template( 'partials/row-actions-dropdown.php', [
												'actions' => $actions,
											] );
											?>
                                        </li>
                                    </ul>
                                </div>
                            </div>
							<?php
						}
					}
					?>
                </div>
            </div>
            <div class="card-inner">
				<?php
				echo crm_get_template( 'partials/pagination.php', [
					'max_page_num' => $total_page,
					'current_page' => $page_number,
					'class_name'   => 'user_pagination_link',
					'show_count'   => 2,
				] );
				?>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="atlasReportContentModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title">محتوای پیگیری </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="بستن"></button>
            </div>

            <div class="modal-body atlas-report-modal-body"></div>

        </div>
    </div>
</div>
