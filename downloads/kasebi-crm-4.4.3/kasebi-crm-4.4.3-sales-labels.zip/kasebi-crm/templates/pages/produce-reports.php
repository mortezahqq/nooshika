<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

$per_page_key = basename( __FILE__, '.php' );
$per_page_key = "crm_{$per_page_key}_per_page";
$user_id      = get_current_user_id();
$defaults     = [
	'page_number' => 1,
	'per_page'    => get_user_meta( $user_id, $per_page_key, TRUE ) ?: 20,
	'date'        => [
		'from' => '',
		'to'   => '',
	],
	'brand'       => '',
	'stock'       => 'produce',

];
$args         = wp_parse_args( $_REQUEST, $defaults );
$args         = array_map( fn( $v ) => $v == 0 ? '' : $v, $args );
$has_filter   = kcp_page_has_filter( $args, $defaults );
extract( $args );
update_user_meta( $user_id, $per_page_key, $per_page );
$date      = is_array( $date ) ? $date : [];
$date_from = $date['from'] ?? '';
$date_to   = $date['to'] ?? '';

$DB             = new kcp_stock();
$logs           = $DB->get_warehouse_products(
	compact( 'per_page', 'page_number', 'date_from', 'date_to', 'stock', 'brand' ) );
$total_logs     = $logs['total'];
$total_page     = $logs['pages'];
$store_products = $logs['rows'];

$pending_items  = $DB->get_warehouse_products( [
	'stock'    => 'produce',
	'status'   => 'pending',
	'per_page' => 1,
] );
$in_productions = $DB->get_warehouse_products( [
	'stock'     => 'produce',
	'status'    => 'in_production',
	'step_type' => 'request_production',
	'per_page'  => 1,
] );
$print_url      = add_query_arg(
	[
		'action' => 'bill',
		'type'   => 'print-table',
	],
	home_url( '/crm/' )
);
?>
<div class="nk-block-head nk-block-head-sm">
    <div class="nk-block-between">
        <div class="nk-block-head-content">
            <h3 class="nk-block-title page-title">گزارش تولید فروشگاه</h3>
        </div>
        <div class="nk-block-head-content">
            <ul class="nk-block-tools g-3">
                <li class="nk-block-tools-opt">
                    <button class="print-json-table btn btn-icon btn-primary"
                            type="button"
                            data-print-url="<?php echo esc_url( $print_url ); ?>"
                            data-target="#report_table"
                            data-title="گزارش تولید">
                        <em class="icon ni ni-printer"></em></button>
                </li>
            </ul>
        </div>
    </div>
</div>
<div class="nk-block">
    <div class="card card-stretch">
        <div class="card-inner-group">
            <div class="card-inner position-relative card-tools-toggle">
                <div class="card-title-group">
                    <div class="card-tools">
                    </div>
                    <div class="card-tools ">
                        <ul class="btn-toolbar gx-1">
                            <li>
								<?php
								$filter_fields = [
									[
										'type'  => 'date-range',
										'label' => 'تاریخ درخواست',
										'name'  => 'date',
										'value' => [
											'from' => $date_from ?? '',
											'to'   => $date_to ?? '',
										],
									],
									[
										'type'  => 'text',
										'label' => 'جستجوی برند',
										'name'  => 'brand',
										'col'   => 6,
										'value' => $brand,
									],
								];
								echo crm_get_template( 'partials/filter-dropdown.php', [
									'has_filter'    => $has_filter,
									'filter_fields' => $filter_fields,
								] );
								?>
                            </li>
                            <li class="btn-toolbar-sep"></li>
                            <li>
								<?php
								echo crm_get_template( 'partials/per-page-selector.php', [
									'per_page' => $per_page,
								] );
								?>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="card-inner p-0">
                <table class="nk-tb-list nk-tb-ulist is-compact" id="report_table">
                    <tr class="nk-tb-item nk-tb-head">
                        <th class="nk-tb-col"><span class="sub-text">تاریخ درخواست</span></th>
                        <th class="nk-tb-col"><span class="sub-text">تاریخ تولید</span></th>
                        <th class="nk-tb-col"><span class="sub-text">نام کالا</span></th>
                        <th class="nk-tb-col"><span class="sub-text">نام برند</span></th>
                        <th class="nk-tb-col"><span class="sub-text">تعداد کل</span></th>
                        <th class="nk-tb-col"><span class="sub-text">درحال تولید</span></th>
                        <th class="nk-tb-col"><span class="sub-text">متراژ</span></th>
                    </tr>
					<?php
					$size_taxonomy = 'pa_size';
					$total_req     = 0;
					$total_p       = 0;
					$total_s       = 0;
					foreach ( $store_products as $store_product ) {
						extract( $store_product );
						$product = wc_get_product( $product_id );
						if ( ! $product ) {
							continue;
						}
						$dates    = array_column( $items, 'last_step_date' );
						$minDate  = min( $dates );
						$minPDate = NULL;
						foreach ( $items as $item ) {
							$production_date = $DB->get_meta( 'item', $item['item_id'], 'production_date', TRUE ) ?: '';
							if ( $production_date ) {
								if ( $minPDate === NULL || $production_date < $minPDate ) {
									$minPDate = $production_date;
								}
							}
						}
						$countProduction = count( array_filter( $items, fn( $item ) => $item['last_step_type'] === 'request_production' ) );
						$countPending    = count( array_filter( $items, fn( $item ) => $item['status'] === 'pending' ) );
						$countRequested  = count( $items ) - $countPending;
						$child_size      = $product->get_attribute( $size_taxonomy );
						$size_id         = get_term_by( 'name', $child_size, $size_taxonomy )->term_id;
						$size_metric     = get_term_meta( $size_id, 'size_squere', TRUE );
						$brand           = crm_get_product_brand( $product );
						$class           = $minPDate && $minPDate < date( 'Y-m-d' ) ? ' bg-danger-dim' : '';
						?>
                        <tr class="nk-tb-item<?php echo $class; ?>">
                            <td class="nk-tb-col"><?php echo date_i18n( 'Y-m-d', strtotime( $minDate ) ); ?></td>
                            <td class="nk-tb-col"><?php echo date_i18n( 'Y-m-d', strtotime( $minPDate ) ); ?></td>
                            <td class="nk-tb-col"><?php echo $product_name; ?></td>
                            <td class="nk-tb-col"><?php echo $brand; ?></td>
                            <td class="nk-tb-col"><?php echo $countRequested; ?></td>
                            <td class="nk-tb-col"><?php echo $countProduction; ?></td>
                            <td class="nk-tb-col"><?php echo $size_metric * count( $items ); ?></td>
                        </tr>
						<?php
						foreach ( $items as $item ) {
							$item_id  = $item['item_id'];
							$item_id  = $item['item_id'];
							$order_id = $DB->get_meta( 'item', $item_id, 'order_id', TRUE ) ?: '';
							if ( ! $order_id ) {
								continue;
							}
							$order = wc_get_order( $order_id );
							if ( ! $order ) {
								continue;
							}
							$cashier_note = $order->get_meta( 'cashier_note', TRUE );
							$item_note    = '';
							foreach ( $order->get_items() as $order_item_id => $item ) {
								$item_product_id   = (int) $item->get_product_id();
								$item_variation_id = (int) $item->get_variation_id();
								if (
									$item_product_id === (int) $product_id ||
									$item_variation_id === (int) $product_id
								) {
									$item_note = $item->get_meta( 'note', TRUE );
									break;
								}
							}
							?>
                            <tr class="nk-tb-item<?php echo $class; ?>">
                                <td class="nk-tb-col" colspan="2">
                                    شماره سفارش:<?php echo $order_id; ?>
                                </td>
                                <td class="nk-tb-col"></td>
                                <td class="nk-tb-col" colspan="4">
									<?php
									if ( $cashier_note ) {
										echo wpautop( $cashier_note );
									}
									if ( $item_note ) {
										echo wpautop( $item_note );
									}
									?>
                                </td>
                            </tr>
							<?php
						}
						$total_req += $countRequested;
						$total_p   += $countProduction;
						$total_s   += $size_metric * count( $items );
					}
					?>
                    <tr class="nk-tb-item text-dark fw-bold">
                        <td class="nk-tb-col" colspan="4">جمع کل</td>
                        <td class="nk-tb-col"><?php echo $total_req; ?></td>
                        <td class="nk-tb-col"><?php echo $total_p; ?></td>
                        <td class="nk-tb-col"><?php echo $total_s; ?></td>
                    </tr>
                </table>
            </div>
            <div class="card-inner">
				<?php
				echo crm_get_template( 'partials/pagination.php', [
					'max_page_num' => $total_page,
					'current_page' => $page_number,
					'class_name'   => 'user_pagination_link',
					'show_count'   => 2,
				] );
				?>
            </div>
        </div>
    </div>
</div>

