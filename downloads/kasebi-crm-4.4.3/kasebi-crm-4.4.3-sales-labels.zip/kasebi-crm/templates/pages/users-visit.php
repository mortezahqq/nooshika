<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

$per_page_key = basename( __FILE__, '.php' );
$per_page_key = "crm_{$per_page_key}_per_page";
$user_id      = get_current_user_id();
$defaults     = [
	'page_number' => 1,
	'per_page'    => get_user_meta( $user_id, $per_page_key, TRUE ) ?: 20,
	'date'        => [
		'from' => '',
		'to'   => '',
	],
	'search'      => '',
	'search_user' => '',
	'creator'     => '',
	'status'      => '',
	'intro'       => '',
];
$args         = wp_parse_args( $_REQUEST, $defaults );
$args         = array_map( fn( $v ) => $v == 0 ? '' : $v, $args );
$has_filter   = kcp_page_has_filter( $args, $defaults );
extract( $args );
update_user_meta( $user_id, $per_page_key, $per_page );
$offset         = ( $page_number - 1 ) * $per_page;
$date           = is_array( $date ) ? $date : [];
$date_from      = $date['from'] ?? '';
$date_to        = $date['to'] ?? '';
$DB             = new kcp_db();
$visits         = $DB->get_visits(
	compact( 'per_page', 'offset', 'date_from', 'date_to',
		'search', 'search_user', 'creator', 'status', 'intro' ) );
$total          = $visits['count'] ?: 0;
$total_page     = ceil( $total / $per_page );
$total_duration = $visits['duration'];
$visits         = $visits['result'];
$employees      = get_users( [
	'role__in' => kcp_get_all_roles(),
	'fields'   => 'ids',
] );
$visit_status   = $DB->get_visit_status();
$intros         = $DB->get_introduce_methods();
$duration_text  = convert_seconds_to_text( $total_duration );
$query_args     = array_merge( [
	'action' => 'print',
	'type'   => 'visit',
], compact( 'per_page', 'offset', 'date_from', 'date_to', 'search', 'search_user', 'creator', 'status', 'intro' ) );
$query_args     = array_filter( $query_args );
?>
<div class="nk-block-head nk-block-head-sm">
    <div class="nk-block-between">
        <div class="nk-block-head-content">
            <h3 class="nk-block-title page-title">لیست ویزیت ها</h3>
            <div class="nk-block-des text-soft">
                <p class="mb-0">شما در مجموع <?php echo $total; ?> ویزیت ثبت شده دارید.</p>
                <p class="mb-0">مجموع زمان ویزیت ها: <?php echo $duration_text ?></p>
            </div>
        </div>
        <div class="nk-block-head-content">
            <div class="toggle-wrap nk-block-tools-toggle">
                <div class="toggle-expand-content">
                    <ul class="nk-block-tools g-3">
                        <li class="nk-block-tools-opt">
                            <a href="<?php echo add_query_arg( $query_args, home_url( '/crm/' ) ); ?>"
                               class="btn btn-info" target="_blank">
                                <em class="icon ni ni-printer-fill"></em><span>پرینت</span>

                            </a>
                        </li>
                        <li class="nk-block-tools-opt">
                            <a href="#addVisit" class=" btn btn-icon btn-primary" data-bs-target="#addVisit"
                               data-bs-toggle="modal"><em class="icon ni ni-plus"></em></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="nk-block">
    <div class="card card-stretch">
        <div class="card-inner-group">
            <div class="card-inner position-relative card-tools-toggle">
                <div class="card-title-group">
                    <div class="card-tools">
                        <a class="btn btn-icon search-toggle toggle-search" data-target="search_visits">
                            <em class="icon ni ni-search"></em>
                        </a>
                    </div>
                    <div class="card-tools">
                        <ul class="btn-toolbar gx-1">
                            <li>
								<?php
								$filter_fields = [
									'date'    => [
										'type'  => 'date-range',
										'label' => 'تاریخ ثبت ویزیت',
										'name'  => 'date',
										'value' => [
											'from' => $date_from ?? '',
											'to'   => $date_to ?? '',
										],
									],
									'search'  => [
										'type'  => 'text',
										'label' => 'جستجوی مشتری',
										'name'  => 'search_user',
										'value' => $search_user,
									],
									'creator' => [
										'type'    => 'select',
										'label'   => 'ثبت کننده',
										'name'    => 'creator',
										'value'   => $creator,
										'options' => [ 0 => 'همه موارد' ] + array_combine(
												$employees,
												array_map( 'get_user_name_by_id', $employees )
											),
									],
									'status'  => [
										'type'    => 'select',
										'label'   => 'وضعیت',
										'name'    => 'status',
										'value'   => $status,
										'col'     => 6,
										'options' => [ 0 => 'همه موارد' ] + array_combine(
												array_keys( $visit_status ),
												array_column( $visit_status, 'label' )
											),
									],
									'intro'   => [
										'type'    => 'select',
										'label'   => 'شیوه آشنایی مشتری',
										'name'    => 'intro',
										'value'   => $intro,
										'col'     => 6,
										'options' => [ 0 => 'همه موارد' ] + array_combine(
												array_keys( $intros ),
												array_column( $intros, 'label' )
											),
									],
								];
								
								if ( ! is_current_user_admin() ) {
									unset( $filter_fields['creator'] );
								}
								echo crm_get_template( 'partials/filter-dropdown.php', [
									'has_filter'    => $has_filter,
									'filter_fields' => $filter_fields,
								] );
								?>
                            </li>
                            <li class="btn-toolbar-sep"></li>
                            <li>
								<?php
								echo crm_get_template( 'partials/per-page-selector.php', [
									'per_page' => $per_page,
								] );
								?>
                            </li>
                        </ul>
                    </div>
                    <div class="card-search search-wrap<?php echo $search ? ' active' : ''; ?>"
                         data-search="search_tracks">
                        <div class="card-body">
                            <div class="search-content">
                                <a href="#" class="search-back btn btn-icon toggle-search"
                                   data-target="search_visits"><em
                                        class="icon ni ni-arrow-left"></em></a>
                                <input type="text" value="<?php echo $search; ?>"
                                       class="form-control border-transparent form-focus-none search_crm_list"
                                       placeholder="جستجو میان ویزیت ها">
                                <div class="search-submit btn btn-icon submit_search_actions">
                                    <em class="icon ni ni-search"></em>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-inner p-0">
                <div class="nk-tb-list nk-tb-ulist is-compact">
                    <div class="nk-tb-item nk-tb-head">
                        <div class="nk-tb-col"><span class="sub-text">مشتری</span></div>
                        <div class="nk-tb-col"><span class="sub-text">تاریخ ویزیت</span></div>
                        <div class="nk-tb-col"><span class="sub-text">وضعیت</span></div>
                        <div class="nk-tb-col"><span class="sub-text">توضیحات</span></div>
                        <div class="nk-tb-col nk-tb-col-tools text-end"></div>
                    </div>
					<?php
					if ( empty( $visits ) ) {
						echo '<div class="no-item-found">ویزیت یافت نشد</div>';
					} else {
						foreach ( $visits as $visit ) {
							extract( $visit );
							$creator      = get_user_name_by_id( $creator );
							$status_badge = $visit_status[ $status ]['class'];
							$status_label = $visit_status[ $status ]['label'];
							?>
                            <div class="nk-tb-item">
                                <div class="nk-tb-col">
									<?php
									if ( $user_id ) {
										echo crm_get_template( 'partials/user-card.php', [
											'user_id'    => $user_id,
											'show_phone' => TRUE,
										] );
									} else {
										echo 'ویزیت ناشناس';
									}
									?>
                                </div>
                                <div class="nk-tb-col">
                                    <span>
                                        <?php
                                        echo date_i18n( 'j F Y H:i', strtotime( $start_time ) );
                                        if ( $end_date ) {
	                                        echo ' الی ';
	                                        echo date_i18n( 'j F Y H:i', strtotime( $end_date ) );
                                        }
                                        ?>
                                    </span>
                                    <span class="sub-text"><?php echo convert_seconds_to_text( $duration ); ?></span>
                                </div>
                                <div class="nk-tb-col">
                                    <span class="badge <?php echo $status_badge; ?>"><?php echo $status_label; ?></span>
                                </div>
                                <div class="nk-tb-col w-max-250px w-250px fs-12px nk-news-text"
                                     data-bs-toggle="popover"
                                     data-bs-trigger="click"
                                     data-bs-html="true"
                                     title="نتیجه ویزیت"
                                     data-bs-content="<?php echo wpautop( $details ?: 'ویزیت پایان نیافته است.' ); ?>"
                                     data-bs-placement="top">
									<?php echo wpautop( $details ?: 'ویزیت پایان نیافته است.' ); ?>
                                </div>
                                <div class="nk-tb-col nk-tb-col-tools">
                                    <ul class="nk-tb-actions gx-2">
										<?php
										$hidden_actions = [
											[
												'link'  => '',
												'title' => $creator,
												'icon'  => 'ni-user-check',
											],
										];
										if ( $status == 'started' ) {
											array_unshift( $hidden_actions, [
												'link'  => '',
												'title' => 'ارجاع به فاکتور',
												'icon'  => 'ni-check-c',
												'class' => 'change_visit_status',
												'data'  => [
													'item-id' => $id,
													'user-id' => $user_id,
													'status'  => 'finished',
												],
											] );
											array_unshift( $hidden_actions, [
												'link'  => '',
												'title' => 'ویزیت ناموفق',
												'icon'  => 'ni-cross-c',
												'class' => 'change_visit_status',
												'data'  => [
													'item-id' => $id,
													'user-id' => $user_id,
													'status'  => 'canceled',
												],
											] );
										}
										echo crm_get_template( 'partials/row-actions-hidden.php', [
											'actions' => $hidden_actions,
										] );
										?>
                                        <li>
											<?php
											$actions = [];
											if ( $user_id ) {
												$actions = [
													[
														'link'  => '/crm/user/' . $user_id,
														'title' => 'مشخصات مشتری',
														'icon'  => 'ni-eye',
														'class' => 'page_activator',
													],
													[
														'link'  => '/crm/user/' . $user_id . '?tab=visit',
														'title' => 'همه ویزیت ها',
														'icon'  => 'ni-reports-alt',
														'class' => 'page_activator',
													],
												];
											}
											if ( $status == 'finished' ) {
												$actions[] = [
													'link'  => '',
													'title' => 'لغو ویزیت',
													'icon'  => 'ni-cross-c',
													'class' => 'change_visit_status',
													'data'  => [
														'item-id' => $id,
														'user-id' => $user_id,
														'status'  => 'canceled',
													],
												];
											}
											if ( $status == 'canceled' ) {
												$actions[] = [
													'link'  => '',
													'icon'  => 'ni-check-c',
													'title' => 'ارجاع به فاکتور',
													'class' => 'change_visit_status',
													'data'  => [
														'item-id' => $id,
														'user-id' => $user_id,
														'status'  => 'finished',
													],
												];
											}
											if ( is_current_user_admin() ) {
												$actions[] = [
													'link'  => '',
													'title' => 'حذف ویزیت',
													'icon'  => 'ni-trash',
													'class' => 'delete_db_item',
													'data'  => [
														'action'  => 'crm_delete_visit',
														'item_id' => $id,
														'tab'     => 'visit',
														'page'    => 'users-visit',
													],
												];
											}
											
											echo crm_get_template( 'partials/row-actions-dropdown.php', [
												'actions' => $actions,
											] );
											?>
                                        </li>
                                    </ul>
                                </div>
                            </div>
							<?php
						}
					}
					?>
                </div>
            </div>
            <div class="card-inner">
				<?php
				echo crm_get_template( 'partials/pagination.php', [
					'max_page_num' => $total_page,
					'current_page' => $page_number,
					'class_name'   => 'user_pagination_link',
					'show_count'   => 2,
				] );
				?>
            </div>
        </div>
    </div>
</div>
