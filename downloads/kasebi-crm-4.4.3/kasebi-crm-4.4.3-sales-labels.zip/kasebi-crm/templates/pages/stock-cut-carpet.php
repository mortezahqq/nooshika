<?php

$per_page_key = basename( __FILE__, '.php' );
$per_page_key = "crm_{$per_page_key}_per_page";
$user_id      = get_current_user_id();
$defaults     = [
	'page_number' => 1,
	'per_page'    => get_user_meta( $user_id, $per_page_key, TRUE ) ?: 20,
	'search'      => '',
	'brand'       => '',
];
$args         = wp_parse_args( $_REQUEST, $defaults );
$has_filter   = kcp_page_has_filter( $args, $defaults );
extract( $args );
update_user_meta( $user_id, $per_page_key, $per_page );

$page_number = max( 1, (int) $page_number );
$per_page    = max( 1, (int) $per_page );
$offset      = ( $page_number - 1 ) * $per_page;
$tag_ids     = kcp_get_cut_carpet_tag_term_ids();
$rows        = [];
$total_rows  = 0;

if ( ! empty( $tag_ids ) ) {
	global $wpdb;
	
	$tag_placeholders = implode( ',', array_fill( 0, count( $tag_ids ), '%d' ) );
	$stock_table      = $wpdb->prefix . 'stock_items';
	$where            = [
		"si.current_stock IN ('store','vitrine')",
		"si.status = 'produced'",
		"tt.taxonomy = 'product_tag'",
		"tt.term_id IN ({$tag_placeholders})",
	];
	$params           = $tag_ids;
	
	if ( $search !== '' ) {
		$like     = '%' . $wpdb->esc_like( $search ) . '%';
		$where[]  = '(si.product_name LIKE %s OR si.sku LIKE %s)';
		$params[] = $like;
		$params[] = $like;
	}
	
	$where_sql = implode( ' AND ', $where );
	$base_sql  = "
		FROM {$stock_table} si
		INNER JOIN {$wpdb->posts} p
			ON p.ID = si.product_id
		INNER JOIN {$wpdb->term_relationships} tr
			ON tr.object_id = CASE WHEN p.post_parent > 0 THEN p.post_parent ELSE p.ID END
		INNER JOIN {$wpdb->term_taxonomy} tt
			ON tt.term_taxonomy_id = tr.term_taxonomy_id
		WHERE {$where_sql}
	";
	
	$total_rows = (int) $wpdb->get_var( $wpdb->prepare(
		"SELECT COUNT(DISTINCT si.sku) {$base_sql}",
		$params
	) );
	
	if ( $total_rows > 0 ) {
		$query_params   = $params;
		$query_params[] = $per_page;
		$query_params[] = $offset;
		$rows           = $wpdb->get_results( $wpdb->prepare(
			"
			SELECT
				MIN(si.product_id) AS product_id,
				si.sku,
				MIN(si.product_name) AS product_name,
				COUNT(*) AS stock_cm
			{$base_sql}
			GROUP BY si.sku
			ORDER BY si.sku ASC
			LIMIT %d OFFSET %d
			",
			$query_params
		), ARRAY_A );
	}
}

$total_page = $total_rows > 0 ? (int) ceil( $total_rows / $per_page ) : 0;
?>
<div class="nk-block-head nk-block-head-sm">
    <div class="nk-block-between">
        <div class="nk-block-head-content">
            <h3 class="nk-block-title page-title">فرش برشی</h3>
            <div class="nk-block-des text-soft">
                <p class="mb-0">موجودی محصولات دارای تگ برشی بر اساس سانتی متر ذخیره و در این برگه به متر نمایش داده می‌شود.</p>
            </div>
        </div>
    </div>
</div>
<div class="nk-block">
    <div class="card card-stretch">
        <div class="card-inner-group">
            <div class="card-inner position-relative card-tools-toggle">
                <div class="card-title-group">
                    <div class="card-tools"></div>
                    <div class="card-tools">
                        <ul class="btn-toolbar gx-1">
                            <li>
								<?php
								$filter_fields = [
									[
										'type'  => 'text',
										'label' => 'جستجوی محصول',
										'name'  => 'search',
										'col'   => 12,
										'value' => $search,
									],
								];
								echo crm_get_template( 'partials/filter-dropdown.php', [
									'has_filter'    => $has_filter,
									'filter_fields' => $filter_fields,
								] );
								?>
                            </li>
                            <li class="btn-toolbar-sep"></li>
                            <li>
								<?php
								echo crm_get_template( 'partials/per-page-selector.php', [
									'per_page' => $per_page,
								] );
								?>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="card-inner p-0">
                <table class="nk-tb-list nk-tb-ulist">
                    <thead>
                    <tr class="nk-tb-item nk-tb-head">
                        <td class="nk-tb-col"><span class="sub-text">محصول</span></td>
                        <td class="nk-tb-col"><span class="sub-text">SKU</span></td>
                        <td class="nk-tb-col"><span class="sub-text">موجودی سانتی متر</span></td>
                        <td class="nk-tb-col"><span class="sub-text">موجودی متر</span></td>
                    </tr>
                    </thead>
                    <tbody>
					<?php foreach ( $rows as $row ) {
						$stock_cm = (int) $row['stock_cm'];
						$stock_m  = $stock_cm / 100;
						?>
                        <tr class="nk-tb-item">
                            <td class="nk-tb-col"><?php echo esc_html( $row['product_name'] ); ?></td>
                            <td class="nk-tb-col"><?php echo esc_html( $row['sku'] ); ?></td>
                            <td class="nk-tb-col"><?php echo number_format( $stock_cm ); ?></td>
                            <td class="nk-tb-col"><?php echo number_format( $stock_m, 2 ); ?></td>
                        </tr>
					<?php } ?>
					<?php if ( empty( $rows ) ) { ?>
                        <tr class="nk-tb-item">
                            <td class="nk-tb-col text-center" colspan="4">موردی یافت نشد.</td>
                        </tr>
					<?php } ?>
                    </tbody>
                </table>
            </div>
            <div class="card-inner">
				<?php
				echo crm_get_template( 'partials/pagination.php', [
					'max_page_num' => $total_page,
					'current_page' => $page_number,
					'class_name'   => 'user_pagination_link',
					'show_count'   => 2,
				] );
				?>
            </div>
        </div>
    </div>
</div>
