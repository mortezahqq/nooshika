<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
global $wpdb;
$order_index            = new Kasebi_Order_Index();
$completed_orders_chart = $order_index->get_successful_orders_last_7_days_chart_data();
$users_chart            = $order_index->get_users_last_7_days_chart_data( 'subscriber' );
$users                  = $users_chart['counts'];
$kcp_db                 = $DB = new kcp_db();
?>
<div class="nk-block-head nk-block-head-sm">
    <div class="nk-block-between">
        <div class="nk-block-head-content">
            <h3 class="nk-block-title page-title">مدیریت مشتریان</h3>
            <div class="nk-block-des text-soft">
                <p>به داشبورد مدیریت مشتریان خوش آمدید.</p>
            </div>
        </div>
        <div class="nk-block-head-content">
            <div class="toggle-wrap nk-block-tools-toggle">
            </div>
        </div>
    </div>
</div>
<div class="nk-block">
    <div class="row g-gs">
        <div class="col-md-4">
            <div class="card h-100 bg-warning">
                <div class="nk-cmwg nk-cmwg1">
                    <div class="card-inner pt-3">
                        <div class="d-flex justify-content-between">
                            <div class="flex-item">
                                <div class="text-white d-flex flex-wrap">
                                    <span class="fs-2 me-1">
                                        <?php
                                        $order_count_compare = crm_dashboard_compare_today_with_yesterday( $completed_orders_chart['counts'] ?? [] );
                                        echo number_format_i18n( $order_count_compare['today'] );
                                        ?>
                                        عدد
                                    </span>
                                    <span class="align-self-end fs-13px pb-1">
                                        <?php
                                        echo wp_kses_post( $order_count_compare['html'] );
                                        ?>
                                    </span>
                                </div>
                                <h6 class="text-white">سفارش جدید برای امروز</h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card h-100 bg-info">
                <div class="nk-cmwg nk-cmwg1">
                    <div class="card-inner pt-3">
                        <div class="d-flex justify-content-between">
                            <div class="flex-item">
                                <div class="text-white d-flex flex-wrap">
                                    <span class="fs-2 me-1">
                                        <?php
                                        $user_compare = crm_dashboard_compare_today_with_yesterday( $users_chart['counts'] ?? [] );
                                        echo number_format_i18n( $user_compare['today'] );
                                        ?>
                                        نفر
                                    </span>
                                    <span class="align-self-end fs-13px pb-1">
                                        <?php
                                        echo wp_kses_post( $user_compare['html'] );
                                        ?>
                                    </span>
                                </div>
                                <h6 class="text-white">مشتری جدید برای امروز</h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card h-100 bg-success">
                <div class="nk-cmwg nk-cmwg1">
                    <div class="card-inner pt-3">
                        <div class="d-flex justify-content-between">
                            <div class="flex-item">
                                <div class="text-white d-flex flex-wrap">
                                    <span class="fs-2 me-1">
                                        <?php
                                        $order_total_compare = crm_dashboard_compare_today_with_yesterday( $completed_orders_chart['totals'] ?? [] );
                                        echo number_format_i18n( $order_total_compare['today'] );
                                        ?>
                                        <small>تومان</small>
                                    </span>
                                    <span class="align-self-end fs-13px pb-1">
                                        <?php
                                        echo wp_kses_post( $order_total_compare['html'] );
                                        ?>
                                    </span>
                                </div>
                                <h6 class="text-white">سفارش موفق برای امروز</h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-8 ">
            <div class="card">
                <div class="card-inner pb-0">
                    <div class="card-title-group mb-1">
                        <div class="card-title">
                            <h6 class="title">پیگیری ها</h6>
                        </div>
                        <div class="card-tools">
                            <a href="<?php echo home_url( '/crm/users-track' ); ?>" data-url="/crm/users-track"
                               class="link page_activator ">تمام پیگیری ها</a>
                        </div>
                    </div>
                    <ul class="nav nav-tabs nav-tabs-card nav-tabs-xs">
                        <li class="nav-item">
                            <a class="nav-link active" data-bs-toggle="tab" href="#today_track">امروز</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-bs-toggle="tab" href="#tomorrow_track">فردا</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-bs-toggle="tab" href="#two_track">دو روز آتی</a>
                        </li>
                    </ul>
                </div>
                <div class="tab-content mt-0">
					<?php
					$list         = [
						'today_track'    => 0,
						'tomorrow_track' => 1,
						'two_track'      => 2,
					];
					$admin_id     = get_current_user_id();
					$role         = nooshika_get_user_role( $admin_id );
					$creator      = $role == 'administrator' ? '' : $admin_id;
					$track_type   = $kcp_db->get_track_types();
					$track_status = $kcp_db->get_track_status();
					foreach ( $list as $id => $day ) {
						$due_date = date_i18n( 'Y-m-d', strtotime( "$day days" ) );
						$per_page = 5;
						$tracks   = $kcp_db->get_user_tracks(
							compact( 'per_page', 'due_date', 'creator' ) );
						$tracks   = $tracks['result'];
						?>
                        <div class="tab-pane dashboard_tab <?php echo $day === 0 ? ' active' : ''; ?>"
                             id="<?php echo $id; ?>"
                             data-simplebar="">
							<?php
							if ( empty( $tracks ) ) {
								?>
                                <div class="card-inner">
                                    هیچ پیگیری برای این روز ثبت نشده است.
                                </div>
								<?php
							} else {
								?>
                                <div class="card-inner p-0">
                                    <div class="nk-tb-list nk-tb-ulist is-compact">
                                        <div class="nk-tb-item nk-tb-head">
                                            <div class="nk-tb-col"><span class="sub-text">مشتری</span></div>
                                            <div class="nk-tb-col"><span class="sub-text">نوع پیگیری</span></div>
                                            <div class="nk-tb-col"><span class="sub-text">زمان پیگیری</span></div>
                                            <div class="nk-tb-col tb-col-md"><span class="sub-text">توضیحات</span></div>
                                            <div class="nk-tb-col nk-tb-col-tools text-end"></div>
                                        </div>
										<?php
										foreach ( $tracks as $track ) {
											extract( $track );
											$status_badge      = $track_status[ $status ]['class'];
											$status_label      = $track_status[ $status ]['label'];
											$creator           = get_user_name_by_id( $creator );
											$report_content_id = wp_unique_id( 'report_content_' );
											?>
                                            <div class="nk-tb-item">
                                                <div class="nk-tb-col">
													<?php
													echo crm_get_template( 'partials/user-card.php', [
														'user_id'     => $user_id,
														'show_phone'  => TRUE,
														'show_avatar' => FALSE,
													] );
													?>
                                                </div>
                                                <div class="nk-tb-col">
                                                    <a class="btn btn-sm btn-icon btn-trigger" data-bs-toggle="tooltip"
                                                       data-bs-placement="top"
                                                       title="<?php echo $track_type[ $type ]['label']; ?>">
                                                        <em class="icon ni ni-<?php echo $track_type[ $type ]['icon']; ?>"></em>
                                                    </a>
                                                </div>
                                                <div class="nk-tb-col">
                                                    <span><?php echo date_i18n( 'j F Y', strtotime( $track_date ) ); ?></span>
                                                    <span class="sub-text"><?php echo $track_hour ?></span>
                                                </div>
                                                <div class="nk-tb-col">
                                                    <div
                                                        class="w-max-250px w-250px fs-12px nk-news-text atlas-report-modal-trigger"
                                                        data-bs-toggle="modal"
                                                        data-bs-target="#atlasReportContentModal"
                                                        data-content-target="#<?php echo esc_attr( $report_content_id ); ?>"
                                                        style="cursor:pointer;">
                                                        <p><?php echo esc_html( wp_strip_all_tags( $content ) ); ?></p>
                                                    </div>
                                                </div>
                                                <div id="<?php echo esc_attr( $report_content_id ); ?>" class="d-none">
													<?php echo wpautop( ( $content ) ); ?>
                                                </div>
                                                <div class="nk-tb-col nk-tb-col-tools">
                                                    <ul class="nk-tb-actions gx-2">
														<?php
														$hidden_actions = [
															[
																'link'  => '',
																'title' => $creator,
																'icon'  => 'ni-user-check',
															],
															[
																'link'  => '/crm/user/' . $user_id,
																'title' => 'مشخصات مشتری',
																'icon'  => 'ni-eye',
																'class' => 'page_activator',
															],
															[
																'link'  => '/crm/user/' . $user_id . '?tab=track',
																'title' => 'همه پیگیری ها',
																'icon'  => 'ni-call-alt',
																'class' => 'page_activator',
															],
														];
														echo crm_get_template( 'partials/row-actions-hidden.php', [
															'actions' => $hidden_actions,
														] );
														?>

                                                    </ul>
                                                </div>
                                            </div>
											<?php
										}
										?>
                                    </div>
                                </div>
								<?php
							}
							?>

                        </div>
						<?php
					}
					?>
                </div>
            </div>
            <div class="card">
                <div class="card-inner pb-0">
                    <div class="card-title-group mb-1">
                        <div class="card-title">
                            <h6 class="title">درخواست ها</h6>
                        </div>
                        <div class="card-tools">
                            <a href="<?php echo home_url( '/crm/users-call' ); ?>" data-url="/crm/users-call"
                               class="link page_activator ">تمام درخواست ها</a>
                        </div>
                    </div>
                </div>
                <div class="tab-content mt-0">
					<?php
					$admin_id        = get_current_user_id();
					$role            = nooshika_get_user_role( $admin_id );
					$category        = $role == 'administrator' ? '' : $role;
					$status          = 'new';
					$calls           = $kcp_db->get_calls(
						compact( 'per_page', 'category', 'status' ) );
					$calls           = $calls['result'];
					$call_statuses   = $kcp_db->get_call_statuses();
					$call_categories = $kcp_db->get_call_categories();
					if ( empty( $calls ) ) {
						?>
                        <div class="card-inner">
                            هیچ درخواست جدیدی وجود ندارد.
                        </div>
						<?php
					} else {
						?>
                        <div class="card-inner p-0">
                            <div class="nk-tb-list nk-tb-ulist is-compact">
                                <div class="nk-tb-item nk-tb-head">
                                    <div class="nk-tb-col"><span class="sub-text">تاریخ</span></div>
                                    <div class="nk-tb-col tb-col-md"><span class="sub-text">وضعیت</span></div>
                                    <div class="nk-tb-col"><span class="sub-text">مشتری</span></div>
                                    <div class="nk-tb-col"><span class="sub-text">واحد ارجاع</span></div>
                                    <div class="nk-tb-col tb-col-md"><span class="sub-text">مسئول انجام</span></div>
                                    <div class="nk-tb-col tb-col-md"><span class="sub-text">توضیحات</span></div>
                                    <div class="nk-tb-col tb-col-md text-end"></div>
                                </div>
								<?php
								foreach ( $calls as $call ) {
									extract( $call );
									$creator      = get_user_name_by_id( $creator_id );
									$status_badge = $call_statuses[ $status ]['class'];
									$status_label = $call_statuses[ $status ]['label'];
									$attachment   = $DB->get_call_meta( $id, 'attachment' );
									$assigned_to  = $DB->get_call_meta( $id, 'assigned_to' );
									$assigned_to  = $assigned_to ? get_user_name_by_id( $assigned_to ) : '-';
									?>
                                    <div class="nk-tb-item">
                                        <div class="nk-tb-col">
                                    <span class="sub-text">
                                        <?php echo date_i18n( 'j F Y', strtotime( $created_at ) ); ?></span>
                                        </div>
                                        <div class="nk-tb-col tb-col-md">
                                            <span
                                                class="badge <?php echo $status_badge; ?>"><?php echo $status_label; ?></span>
                                        </div>
                                        <div class="nk-tb-col">
											<?php
											echo crm_get_template( 'partials/user-card.php', [
												'user_id'    => $user_id,
												'show_phone' => TRUE,
											] );
											?>
                                        </div>
                                        <div class="nk-tb-col">
											<?php echo $call_categories[ $category ]['label']; ?>
                                        </div>
                                        <div class="nk-tb-col tb-col-md">
											<?php echo $assigned_to; ?>
                                        </div>
                                        <div class="nk-tb-col tb-col-md fs-12px nk-news-text"
                                             data-bs-toggle="popover"
                                             data-bs-trigger="click"
                                             data-bs-html="true"
                                             title="محتوای درخواست"
                                             data-bs-content="<?php echo wpautop( $content ); ?>"
                                             data-bs-placement="top">
                                            <a class="btn btn-sm btn-icon ">
                                                <em class="icon ni ni-card-view"></em>
                                            </a>
                                        </div>
                                        <div class="nk-tb-col tb-col-md ">
                                            <ul class="nk-tb-actions gx-2">
												<?php
												$hidden_actions = [
													[
														'link'  => '',
														'title' => $creator,
														'icon'  => 'ni-user-check',
													],
												];
												if ( $attachment ) {
													array_unshift( $hidden_actions, [
														'link'     => $attachment,
														'title'    => 'فایل ضمیمه',
														'icon'     => 'ni-download',
														'download' => TRUE,
													] );
												}
												echo crm_get_template( 'partials/row-actions-hidden.php', [
													'actions' => $hidden_actions,
												] );
												?>
                                                <li>
													<?php
													$actions = [
														[
															'link'  => '',
															'title' => 'اقدامات صورت گرفته',
															'icon'  => 'ni-list-thumb-alt',
															'class' => 'view_call_progress',
															'data'  => [
																'item-id' => $id,
															],
														],
														[
															'link'  => '/crm/user/' . $user_id,
															'title' => 'مشخصات مشتری',
															'icon'  => 'ni-eye',
															'class' => 'page_activator',
														],
														[
															'link'  => '/crm/user/' . $user_id . '?tab=call',
															'title' => 'همه درخواست ها',
															'icon'  => 'ni-chat-msg',
															'class' => 'page_activator',
														],
													];
													echo crm_get_template( 'partials/row-actions-dropdown.php', [
														'actions' => $actions,
													] );
													?>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
									<?php
								}
								?>
                            </div>
                        </div>
						<?php
					}
					?>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card card-full">
                <div class="card-inner">
                    <div class="card-title-group">
                        <div class="card-title">
                            <h6 class="title">شیوه های آشنایی مخاطبان</h6>
                        </div>
                    </div>
                </div>
                <div class="card-inner pt-0">
                    <ul class="gy-4">
						<?php
						$intros      = $kcp_db->get_introduce_methods();
						$total_users = count_users();
						$total_users = $total_users['avail_roles']['subscriber'] ?: 1;
						$has_intro   = 0;
						foreach ( $intros as $key => $data ) {
							$query     = "SELECT COUNT(*) FROM $wpdb->usermeta WHERE meta_key = 'ncp_user_intro_method' AND meta_value = '$key'";
							$count     = $wpdb->get_var( $query );
							$has_intro += $count;
							?>
                            <li class="justify-between align-center border-bottom border-0 border-dashed">
                                <div class="align-center">
                                    <div class="btn btn-lg btn-icon btn-trigger">
                                        <em class="icon ni ni-<?php echo $data['icon']; ?>"></em>
                                    </div>
                                    <div class="ms-2">
                                        <div class="lead-text">
											<?php echo $data['label']; ?>
                                        </div>
                                        <div class="sub-text"><?php echo $count; ?> مشتری</div>
                                    </div>
                                </div>
                                <div class="align-center">
                                    <div class="sub-text me-2"><?php echo round( $count / $total_users * 100 ); ?>%
                                    </div>
                                    <div class="progress rounded-pill w-80px">
                                        <div class="progress-bar bg-<?php echo $data['color']; ?> rounded-pill"
                                             data-progress="<?php echo round( $count / $total_users * 100 ); ?>"></div>
                                    </div>
                                </div>
                            </li>
							<?php
						}
						$others = $total_users - $has_intro;
						?>
                        <li class="justify-between align-center border-bottom border-0 border-dashed">
                            <div class="align-center">
                                <div class="btn btn-lg btn-icon btn-trigger">
                                    <em class="icon ni ni-alert-circle"></em>
                                </div>
                                <div class="ms-2">
                                    <div class="lead-text">
                                        ست نشده
                                        <span class="badge badge-dot badge-dot-xs badge-danger">
                                            <?php echo $others; ?> مشتری
                                    </div>
                                    <div class="sub-text">مشتریانی که شیوه آشنایی ندارند</div>
                                </div>
                            </div>
                            <div class="align-center">
                                <div class="sub-text me-2">
									<?php echo round( $others / $total_users * 100 ); ?>%
                                </div>
                                <div class="progress rounded-pill w-80px">
                                    <div class="progress-bar bg-danger rounded-pill"
                                         data-progress="<?php echo round( $others / $total_users * 100 ); ?>"></div>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
