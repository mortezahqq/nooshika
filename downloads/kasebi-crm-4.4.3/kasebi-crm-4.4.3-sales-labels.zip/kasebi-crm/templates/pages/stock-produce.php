<?php

$per_page_key = basename( __FILE__, '.php' );
$per_page_key = "crm_{$per_page_key}_per_page";
$user_id      = get_current_user_id();
$defaults     = [
	'page_number'  => 1,
	'per_page'     => get_user_meta( $user_id, $per_page_key, TRUE ) ?: 20,
	'date'         => [
		'from' => '',
		'to'   => '',
	],
	'product_date' => [
		'from' => '',
		'to'   => '',
	],
	'stock'        => 'produce',
	'sku'          => '',
	'step_type'    => '',
	'status'       => '',
	'search'       => '',
	'brand'        => '',
	'product_cat'  => '',
];
$args         = wp_parse_args( $_REQUEST, $defaults );
$args         = array_map( fn( $v ) => $v == 0 ? '' : $v, $args );
$has_filter   = kcp_page_has_filter( $args, $defaults );
extract( $args );
update_user_meta( $user_id, $per_page_key, $per_page );
$date              = is_array( $date ) ? $date : [];
$date_from         = $date['from'] ?? '';
$date_to           = $date['to'] ?? '';
$product_date      = is_array( $product_date ) ? $product_date : [];
$product_date_from = $product_date['from'] ?? '';
$product_date_to   = $product_date['to'] ?? '';
$DB                = new kcp_stock();
$logs              = $DB->get_warehouse_products(
	compact( 'per_page', 'page_number', 'date_from', 'date_to', 'stock', 'product_cat',
		'sku', 'step_type', 'status', 'search', 'brand', 'product_date_from', 'product_date_from' ) );
$total_logs        = $logs['total'];
$total_page        = $logs['pages'];
$store_products    = $logs['rows'];
$process_types     = $DB->get_stock_process_types();
$item_statuses     = $DB->get_stock_item_statuses();
$step_types        = $DB->get_stock_item_step_types();
$pending_items     = $DB->get_warehouse_products( [
	'stock'    => 'produce',
	'status'   => 'pending',
	'per_page' => 1,
] );
$in_productions    = $DB->get_warehouse_products( [
	'stock'     => 'produce',
	'status'    => 'in_production',
	'step_type' => 'request_production',
	'per_page'  => 1,
] );
$qc_items          = $DB->get_warehouse_products( [
	'stock'     => 'produce',
	'status'    => 'in_production',
	'step_type' => 'qccheck_requested',
	'per_page'  => 1,
] );
$categories        = get_terms( [
	'taxonomy'   => 'product_cat',
	'hide_empty' => FALSE,
	'fields'     => 'ids',
] );
?>
<div class="nk-block-head nk-block-head-sm">
    <div class="nk-block-between">
        <div class="nk-block-head-content">
            <h3 class="nk-block-title page-title">انبار تولید</h3>
            <div class="nk-block-des text-soft">
                <p class="mb-0">کالاهایی که نیازمند تولید هستند در اینجا به صورت دسته بندی بر اساس محصول لیست می
                    شوند.</p>
            </div>
        </div>
        <div class="nk-block-head-content">
            <div class="toggle-wrap nk-block-tools-toggle">
                <div class="toggle-expand-content">
                    <ul class="nk-block-tools g-3">
                        <li class="nk-block-tools-opt">
                            <a href="#addProductionRequest" class=" btn btn-icon btn-primary"
                               data-bs-target="#addProductionRequest"
                               data-bs-toggle="modal"><em class="icon ni ni-plus"></em></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="nk-block">
    <div class="row g-gs">
        <div class="col-4">
            <div class="card h-100">
                <div class="nk-ecwg nk-ecwg6">
                    <div class="card-inner">
                        <div class="card-title-group d-flex justify-between align-center">
                            <div class="card-title"><h6 class="title">کالاهای نیازمند تولید</h6></div>
                            <a href="/crm/stock-produce?status=pending"
                               class="link link-light link-sm page_activator"
                               data-url="/crm/stock-produce?status=pending">مشاهده</a>
                        </div>
                        <div class="data">
                            <div class="data-group mt-3 mb-1 d-flex align-center" style="gap: 5px">
                                <h3 class="amount"><?php echo $pending_items['total_items'] ?: 0; ?></h3><span>قلم
                                    کالا</span>
                            </div>
                            <div class="info fs-11px">کالاهایی که ثبت سفارش شده اند و بایستی با تولید کننده جهت
                                تولید تماس بگیرید.
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-4">
            <div class="card h-100">
                <div class="nk-ecwg nk-ecwg6">
                    <div class="card-inner">
                        <div class="card-title-group d-flex justify-between align-center">
                            <div class="card-title"><h6 class="title">کالاهای درحال تولید</h6></div>
                            <a href="/crm/stock-produce?status=in_production&step_type=request_production"
                               class="link link-light link-sm page_activator"
                               data-url="/crm/stock-produce?status=in_production&step_type=request_production">مشاهده</a>
                        </div>
                        <div class="data">
                            <div class="data-group mt-3 mb-1 d-flex align-center" style="gap: 5px">
                                <h3 class="amount"><?php echo $in_productions['total_items'] ?: 0; ?></h3><span>قلم
                                    کالا</span>
                            </div>
                            <div class="info fs-11px">کالاهایی که تامین کننده درحال تولید آنها می باشند.</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-4">
            <div class="card h-100">
                <div class="nk-ecwg nk-ecwg6">
                    <div class="card-inner">
                        <div class="card-title-group d-flex justify-between align-center">
                            <div class="card-title"><h6 class="title">کالاهای درانتظار کنترل کیفی</h6></div>
                            <a href="/crm/stock-produce?status=in_production&step_type=qccheck_requested"
                               class="link link-light link-sm page_activator"
                               data-url="/crm/stock-produce?status=in_production&step_type=qccheck_requested">مشاهده</a>
                        </div>
                        <div class="data">
                            <div class="data-group mt-3 mb-1 d-flex align-center" style="gap: 5px">
                                <h3 class="amount"><?php echo $qc_items['total_items'] ?: 0; ?></h3><span>قلم
                                    کالا</span>
                            </div>
                            <div class="info fs-11px">کالاهای تولید شده که بایستی فرآیند کنترل کیفی بر روی آنها صورت
                                پذیرد
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="nk-block">
    <div class="card card-stretch">
        <div class="card-inner-group">
            <div class="card-inner position-relative card-tools-toggle">
                <div class="card-title-group">
                    <div class="card-tools">
                    </div>
                    <div class="card-tools">
                        <ul class="btn-toolbar gx-1">
                            <li>
                                <select class="form-select js-select2 row_bulk_actions">
                                    <option value="0">ویرایش دسته جمعی</option>
									<?php
									$bulks = [
										'request_production',
										'qccheck_requested',
										'qccheck_approved',
										'qccheck_rejected',
									];
									foreach ( $bulks as $bulk ) {
										$step = $step_types[ $bulk ] ?? FALSE;
										if ( ! $step ) {
											continue;
										}
										?>
                                        <option value="<?php echo $bulk; ?>"
                                                data-needs='<?php echo json_encode( $step['needs'] ); ?>'><?php echo $step['label']; ?></option>
										<?php
									}
									?>
                                    <option value="print_barcode">پرینت بارکد</option>
                                    <option value="print_production_request">پرینت درخواست تولید</option>
                                </select>
                            </li>
                            <li class="btn-toolbar-sep"></li>
                            <li>
								<?php
								$filter_fields = [
									[
										'type'  => 'date-range',
										'label' => 'تاریخ آخرین ویرایش',
										'name'  => 'date',
										'value' => [
											'from' => $date_from ?? '',
											'to'   => $date_to ?? '',
										],
									],
									[
										'type'  => 'date-range',
										'label' => 'تاریخ تولید',
										'name'  => 'product_date',
										'value' => [
											'from' => $product_date_from ?? '',
											'to'   => $product_date_to ?? '',
										],
									],
									[
										'type'  => 'text',
										'label' => 'جستجوی محصول',
										'name'  => 'search',
										'col'   => 6,
										'value' => $search,
									],
									[
										'type'  => 'text',
										'label' => 'جستجوی برند',
										'name'  => 'brand',
										'col'   => 6,
										'value' => $brand,
									],
									'product_cat' => [
										'type'    => 'select',
										'label'   => 'دسته بندی محصول',
										'name'    => 'product_cat',
										'value'   => $product_cat,
										'options' => [ 0 => 'همه موارد' ] + array_combine(
												$categories,
												array_map( function( $term_id ) {
													return crm_get_term_title( (int) $term_id, 'product_cat' );
												}, $categories )
											),
									],
									[
										'type'    => 'select',
										'label'   => 'آخرین فعالیت',
										'name'    => 'step_type',
										'value'   => $step_type,
										'options' => [ 0 => 'همه موارد' ] + array_combine(
												array_keys( $step_types ),
												array_column( $step_types, 'label' )
											),
									],
									[
										'type'    => 'select',
										'label'   => 'وضعیت محصول',
										'name'    => 'status',
										'value'   => $status,
										'options' => [ 0 => 'همه موارد' ] + array_combine(
												array_keys( $item_statuses ),
												array_column( $item_statuses, 'label' )
											),
									],
								];
								echo crm_get_template( 'partials/filter-dropdown.php', [
									'has_filter'    => $has_filter,
									'filter_fields' => $filter_fields,
								] );
								?>
                            </li>
                            <li class="btn-toolbar-sep"></li>
                            <li>
								<?php
								echo crm_get_template( 'partials/per-page-selector.php', [
									'per_page' => $per_page,
								] );
								?>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="card-inner p-0">
                <table class="nk-tb-list nk-tb-ulist">
                    <thead>
                    <tr class="nk-tb-item nk-tb-head">
                        <td class="nk-tb-col"><span class="sub-text">محصول</span></td>
                        <td class="nk-tb-col"><span class="sub-text">برند</span></td>
                        <td class="nk-tb-col"><span class="sub-text">تعداد</span></td>
                    </tr>
                    </thead>
                    <tbody>
					<?php
					foreach ( $store_products as $store_product ) {
						extract( $store_product );
						$qty_color = $io_type == 'in' ? 'success' : 'danger';
						$qty_icon  = $io_type == 'in' ? 'plus-sm' : 'minus-sm';
						$product   = wc_get_product( $product_id );
						if ( ! $product ) {
							continue;
						}
						$brand = crm_get_product_brand( $product );
						?>
                        <tr class="nk-tb-item">
                            <td class="nk-tb-col"><?php echo $product_name; ?></td>
                            <td class="nk-tb-col"><?php echo $brand; ?></td>
                            <td class="nk-tb-col"><?php echo $count; ?></td>
                        </tr>
                        <tr class="nk-tb-item stock_items_wrapper bg-light" data-sku="<?php echo $sku; ?>">
                            <td class="nk-tb-col" colspan="5">
                                <table class="nk-tb-list nk-tb-ulist is-compact bg-white rounded-4">
                                    <thead>
                                    <tr class="nk-tb-item nk-tb-head">
                                        <td class="nk-tb-col nk-tb-col-check"></td>
                                        <td class="nk-tb-col"><span class="sub-text">سریال محصول</span></td>
                                        <td class="nk-tb-col"><span class="sub-text">وضعیت محصول</span></td>
                                        <td class="nk-tb-col"><span class="sub-text">شماره سفارش</span></td>
                                        <td class="nk-tb-col"><span class="sub-text">آخرین اقدام</span></td>
                                        <td class="nk-tb-col"><span class="sub-text">تاریخ تولید</span></td>
                                        <td class="nk-tb-col"><span class="sub-text">وضعیت کنترل کیفی</span></td>
                                        <td class="nk-tb-col"></td>
                                    </tr>
                                    </thead>
                                    <tbody>
									<?php
									foreach ( $items as $item ) {
										extract( $item );
										$last_step       = $DB->get_last_step_for_item( $item_id );
										$last_step_type  = $last_step['step_type'];
										$last_step_date  = $last_step['date'];
										$note            = $DB->get_meta( 'item', $item_id, 'note', TRUE ) ?: '';
										$order_id        = $DB->get_meta( 'item', $item_id, 'order_id', TRUE ) ?: '';
										$production_date = $DB->get_meta( 'item', $item_id, 'production_date', TRUE ) ?: '';
										$qc_status       = $DB->get_meta( 'item', $item_id, 'qc_status', TRUE ) ?: '';
										$allowed_actions = $DB->get_allowed_next_steps( compact( 'status', 'last_step_type' ) );
										$class           = $production_date && $production_date < date( 'Y-m-d' ) ? ' bg-danger-dim' : '';
										?>
                                        <tr class="nk-tb-item<?php echo $class; ?>">
                                            <td class="nk-tb-col nk-tb-col-check">
                                                <div
                                                    class="custom-control custom-control-sm custom-checkbox notext">
                                                    <input type="checkbox"
                                                           class="custom-control-input select_item_row"
                                                           value="<?php echo $item_id; ?>"
                                                           id="stock_item_<?php echo $item_id; ?>">
                                                    <label class="custom-control-label"
                                                           for="stock_item_<?php echo $item_id; ?>"></label>
                                                </div>
                                            </td>
                                            <td class="nk-tb-col"><?php echo $serial; ?></td>
                                            <td class="nk-tb-col">
                                                <span class="badge <?php echo $item_statuses[ $status ]['class']; ?>">
                                                    <?php echo $item_statuses[ $status ]['label']; ?>
                                                </span>
                                            </td>
                                            <td class="nk-tb-col"><?php echo $order_id; ?></td>
                                            <td class="nk-tb-col">
                                                <span
                                                    class="badge <?php echo $step_types[ $last_step_type ]['class']; ?>">
                                                    <?php echo $step_types[ $last_step_type ]['label']; ?>
                                                </span>
                                            </td>
                                            <td class="nk-tb-col">
                                                <span class="sub-text">
                                                    <?php echo $production_date ? date_i18n( 'j F Y', strtotime(
	                                                    $production_date ) ) : '-'; ?>
                                                </span>
                                            </td>
                                            <td class="nk-tb-col">
                                                <span class="sub-text">
                                                    <?php echo $qc_status; ?>
                                                </span>
                                            </td>
                                            <td class="nk-tb-col">
                                                <ul class="nk-tb-actions gx-2">
													<?php
													if ( $order_id ) {
														$order = wc_get_order( $order_id );
														if ( $order ) {
															$cashier_note = $order->get_meta( 'cashier_note', TRUE );
															if ( $cashier_note ) {
																?>
                                                                <li>
                                                                    <div class="btn btn-sm btn-icon btn-trigger"
                                                                         data-bs-toggle="popover"
                                                                         data-bs-trigger="hover"
                                                                         data-bs-html="true"
                                                                         title="یادداشت سفارش"
                                                                         data-bs-content="<?php echo wpautop( $cashier_note ); ?>"
                                                                         data-bs-placement="top">
                                                                        <em class="icon ni ni-note-add-c"></em>
                                                                    </div>
                                                                </li>
																<?php
															}
															$item_note = '';
															foreach ( $order->get_items() as $order_item_id => $item ) {
																/** @var WC_Order_Item_Product $item */
																$item_product_id   = (int) $item->get_product_id();
																$item_variation_id = (int) $item->get_variation_id();
																if (
																	$item_product_id === (int) $product_id ||
																	$item_variation_id === (int) $product_id
																) {
																	$item_note = $item->get_meta( 'note', TRUE );
																	break;
																}
															}
															if ( $item_note ) {
																?>
                                                                <li>
                                                                    <div class="btn btn-sm btn-icon btn-trigger"
                                                                         data-bs-toggle="popover"
                                                                         data-bs-trigger="hover"
                                                                         data-bs-html="true"
                                                                         title="یادداشت آیتم"
                                                                         data-bs-content="<?php echo wpautop( $item_note ); ?>"
                                                                         data-bs-placement="top">
                                                                        <em class="icon ni ni-note-add-c"></em>
                                                                    </div>
                                                                </li>
																<?php
															}
														}
													}
													if ( $note ) {
														?>
                                                        <li>
                                                            <div class="btn btn-sm btn-icon btn-trigger"
                                                                 data-bs-toggle="popover"
                                                                 data-bs-trigger="hover"
                                                                 data-bs-html="true"
                                                                 title="یادداشت تولید"
                                                                 data-bs-content="<?php echo wpautop( $note ); ?>"
                                                                 data-bs-placement="top">
                                                                <em class="icon ni ni-note-add-c"></em>
                                                            </div>
                                                        </li>
														<?php
													}
													$actions = [
														[
															'link'  => '',
															'title' => 'اقدامات صورت گرفته',
															'icon'  => 'ni-list-thumb-alt',
															'class' => 'view_stock_log_steps',
															'data'  => [
																'item-id' => $item_id,
															],
														],
													];
													echo crm_get_template( 'partials/row-actions-hidden.php', [
														'actions' => $actions,
													] );
													?>
                                                    <li>
														<?php
														$actions = [];
														foreach ( $allowed_actions as $allowed_action ) {
															$actions[] = [
																'link'  => '',
																'title' => $allowed_action['label'],
																'class' => 'set_step_for_stock_item',
																'data'  => [
																	'item-id' => $item_id,
																	'step'    => $allowed_action['key'],
																	'needs'   => json_encode( $allowed_action['needs'] ),
																],
															];
														}
														echo crm_get_template( 'partials/row-actions-dropdown.php', [
															'actions' => $actions,
														] );
														?>
                                                    </li>
                                                </ul>
                                            </td>
                                        </tr>
										<?php
									}
									?>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
						<?php
					}
					?>
                    </tbody>
                </table>
            </div>
            <div class="card-inner">
				<?php
				echo crm_get_template( 'partials/pagination.php', [
					'max_page_num' => $total_page,
					'current_page' => $page_number,
					'class_name'   => 'user_pagination_link',
					'show_count'   => 2,
				] );
				?>
            </div>
        </div>
    </div>
</div>

