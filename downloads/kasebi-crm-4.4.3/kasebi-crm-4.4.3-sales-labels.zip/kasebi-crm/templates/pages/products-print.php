<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
$per_page_key = basename( __FILE__, '.php' );
$per_page_key = "crm_{$per_page_key}_per_page";
$user_id      = get_current_user_id();
$defaults     = [
	'pa_brand'    => '',
	'product_cat' => '',
	'pa_size'     => '',
	'search'      => '',
	'page_number' => 1,
	'per_page'    => get_user_meta( $user_id, $per_page_key, TRUE ) ?: 20,
];
$args         = wp_parse_args( $_REQUEST, $defaults );
$args         = array_map( fn( $v ) => $v == 0 ? '' : $v, $args );
$has_filter   = kcp_page_has_filter( $args, $defaults );
extract( $args );
update_user_meta( $user_id, $per_page_key, $per_page );
$offset = ( $page_number - 1 ) * $per_page;

$products    = crm_get_products_list( compact( 'per_page', 'offset', 'pa_brand', 'product_cat',
	'pa_size', 'search' ) );
$product_ids = $products['product_ids'];
$total_pages = $products['total_pages'];
$query_args  = array_merge( [
	'action' => 'print',
	'type'   => 'ticket',
], compact( 'per_page', 'offset', 'pa_brand', 'product_cat', 'pa_size', 'search' ) );
$query_args  = array_filter( $query_args );

$categories = get_terms( [
	'taxonomy'   => 'product_cat',
	'hide_empty' => FALSE,
	'fields'     => 'ids',
] );
$sizes      = get_terms( [
	'taxonomy'   => 'pa_size',
	'hide_empty' => FALSE,
	'fields'     => 'ids',
] );
$brands     = get_terms( [
	'taxonomy'   => 'pa_brand',
	'hide_empty' => FALSE,
	'fields'     => 'ids',
] );

?>
<div class="nk-block-head nk-block-head-sm">
    <div class="nk-block-between">
        <div class="nk-block-head-content">
            <h3 class="nk-block-title page-title">لیست محصولات</h3>
            <div class="nk-block-des text-soft">
                <p class="mb-0">شما در مجموع <?php echo $products['total_products']; ?> محصول دارید.</p>
            </div>
        </div>
        <div class="nk-block-head-content">
            <div class="toggle-wrap nk-block-tools-toggle">
                <div class="toggle-expand-content">
                    <ul class="nk-block-tools g-3">
                        <li class="export_result_container d-none">
                            <a class="btn btn-icon icon bg-info-dim csv_link" data-bs-toggle="tooltip"
                               data-bs-placement="top"
                               title="دانلود CSV" target="_blank" href="#">
                                <em class="icon ni ni-file-code"></em>
                            </a>
                        </li>
                        <li class="export_progress_container w-200px d-none">
                            <div class="request_export_msg"></div>
                            <div class="progress bg-light w-100">
                                <div class="progress-bar progress-bar-striped progress-bar-animated bg-info"
                                     style="width: 0%;">0%
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="btn btn-white btn-dim btn-outline-light" id="export_current_list">
                                <em class="icon ni ni-download-cloud"></em><span>دریافت خروجی</span>
                            </div>
                        </li>
                        <li class="nk-block-tools-opt">
                            <a href="<?php echo add_query_arg( $query_args, home_url( '/crm/' ) ); ?>"
                               class="btn btn-info" target="_blank">
                                <em class="icon ni ni-printer-fill"></em><span>پرینت</span>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="nk-block">
    <div class="card card-stretch">
        <div class="card-inner-group">
            <div class="card-inner position-relative card-tools-toggle">
                <div class="card-title-group">
                    <div class="card-tools">
                        <a class="btn btn-icon search-toggle toggle-search" data-target="search_name">
                            <em class="icon ni ni-search"></em>
                        </a>
                    </div>
                    <div class="card-tools">
                        <ul class="btn-toolbar gx-1">
                            <li>
								<?php
								$filter_fields = [
									'pa_brand'    => [
										'type'    => 'select',
										'label'   => 'برند محصول',
										'name'    => 'pa_brand',
										'value'   => $pa_brand,
										'options' => [ 0 => 'همه موارد' ] + array_combine(
												$brands,
												array_map( function( $term_id ) {
													return crm_get_term_title( (int) $term_id, 'pa_brand' );
												}, $brands )
											),
									],
									'product_cat' => [
										'type'    => 'select',
										'label'   => 'دسته بندی محصول',
										'name'    => 'product_cat',
										'value'   => $product_cat,
										'options' => [ 0 => 'همه موارد' ] + array_combine(
												$categories,
												array_map( function( $term_id ) {
													return crm_get_term_title( (int) $term_id, 'product_cat' );
												}, $categories )
											),
									],
									'pa_size'     => [
										'type'    => 'select',
										'label'   => 'سایز محصول',
										'name'    => 'pa_size',
										'value'   => $pa_size,
										'options' => [ 0 => 'همه موارد' ] + array_combine(
												$sizes,
												array_map( function( $term_id ) {
													return crm_get_term_title( (int) $term_id, 'pa_size' );
												}, $sizes )
											),
									],
								];
								echo crm_get_template( 'partials/filter-dropdown.php', [
									'has_filter'    => $has_filter,
									'filter_fields' => $filter_fields,
								] );
								?>
                            </li>
                            <li class="btn-toolbar-sep"></li>
                            <li>
								<?php
								echo crm_get_template( 'partials/per-page-selector.php', [
									'per_page' => $per_page,
								] );
								?>
                            </li>
                        </ul>
                    </div>
                    <div class="card-search search-wrap<?php echo $search ? ' active' : ''; ?>"
                         data-search="search_name">
                        <div class="card-body">
                            <div class="search-content">
                                <a href="#" class="search-back btn btn-icon toggle-search"
                                   data-target="search_name"><em
                                        class="icon ni ni-arrow-left"></em></a>
                                <input type="text" value="<?php echo $search; ?>"
                                       class="form-control border-transparent form-focus-none search_crm_list"
                                       placeholder="جستجو میان محصولات">
                                <div class="search-submit btn btn-icon submit_search_actions">
                                    <em class="icon ni ni-search"></em>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-inner p-0">
                <div class="nk-tb-list nk-tb-ulist is-compact">
                    <div class="nk-tb-item nk-tb-head">
                        <div class="nk-tb-col"><span class="sub-text">#</span></div>
                        <div class="nk-tb-col"><span class="sub-text">عنوان</span></div>
                        <div class="nk-tb-col"><span class="sub-text">دسته بندی</span></div>
                        <div class="nk-tb-col"><span class="sub-text">برند</span></div>
                        <div class="nk-tb-col"><span class="sub-text">قیمت</span></div>
                    </div>
					<?php
					if ( empty( $product_ids ) ) {
						echo '<div class="no-item-found">محصولی یافت نشد</div>';
					} else {
						foreach ( $product_ids as $product_id ) {
							$product = wc_get_product( $product_id );
							if ( ! $product ) {
								continue;
							}
							$parent_id = wp_get_post_parent_id( $product_id ) ?: $product_id;
							$category  = wp_get_post_terms( $parent_id, 'product_cat', [ 'fields' => 'names' ] );
							$category  = is_wp_error( $category ) ? [] : $category;
							$category  = implode( ' - ', $category );
							$brand     = wp_get_post_terms( $parent_id, 'pa_brand', [ 'fields' => 'names' ] );
							$brand     = is_wp_error( $brand ) ? [] : $brand;
							$brand     = implode( ' - ', $brand );
							$price     = $product->get_price();
							?>
                            <div class="nk-tb-item">
                                <div class="nk-tb-col"><?php echo $product_id; ?></div>
                                <div class="nk-tb-col"><?php echo get_the_title( $product_id ); ?></div>
                                <div class="nk-tb-col"><?php echo $category; ?></div>
                                <div class="nk-tb-col"><?php echo $brand; ?></div>
                                <div class="nk-tb-col">
                                <span class="tb-amount">
                                    <?php echo number_format( $price ?: 0 ); ?><span class="currency">تومان</span>
                                </span></div>
                            </div>
							<?php
						}
					}
					?>
                </div>
            </div>
            <div class="card-inner">
				<?php
				echo crm_get_template( 'partials/pagination.php', [
					'max_page_num' => $total_pages,
					'current_page' => $page_number,
					'class_name'   => 'user_pagination_link',
					'show_count'   => 2,
				] );
				?>
            </div>
        </div>
    </div>
</div>
