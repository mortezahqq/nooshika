<?php
$DB        = new kcp_db();
$templates = $DB->get_warning_templates();
?>
<div class="nk-block-head nk-block-head-sm">
    <div class="nk-block-between">
        <div class="nk-block-head-content">
            <h3 class="nk-block-title page-title">لیست قالب های هشدار</h3>
        </div>
        <div class="nk-block-head-content">
            <div class="toggle-wrap nk-block-tools-toggle">
                <div class="toggle-expand-content">
                    <ul class="nk-block-tools g-3">
                        <li class="nk-block-tools-opt">
                            <a href="#addWarningTemplate" class="btn btn-icon btn-primary"
                               data-bs-target="#addWarningTemplate"
                               data-bs-toggle="modal"><em class="icon ni ni-plus"></em></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="nk-block">
    <div class="card card-stretch">
        <div class="card-inner-group">
            <div class="card-inner p-0">
                <div class="nk-tb-list nk-tb-ulist is-compact">
                    <div class="nk-tb-item nk-tb-head">
                        <div class="nk-tb-col"><span class="sub-text">عنوان</span></div>
                        <div class="nk-tb-col"><span class="sub-text">نام الگو</span></div>
                        <div class="nk-tb-col"><span class="sub-text">متغیر اول</span></div>
                        <div class="nk-tb-col"><span class="sub-text">متغیر دوم</span></div>
                        <div class="nk-tb-col"><span class="sub-text">متغیر سوم</span></div>
                        <div class="nk-tb-col nk-tb-col-tools text-end"></div>
                    </div>
					<?php
					if ( empty( $templates ) ) {
						echo '<div class="no-item-found">الگویی یافت نشد</div>';
					} else {
						foreach ( $templates as $template ) {
							extract( $template );
							$count   = $DB->count_warning_by_template_id( $id );
							$creator = get_user_name_by_id( $creator_id );
							?>
                            <div class="nk-tb-item">
                                <div class="nk-tb-col"><?php echo $title; ?></div>
                                <div class="nk-tb-col"><?php echo $template; ?></div>
                                <div class="nk-tb-col"><?php echo $token; ?></div>
                                <div class="nk-tb-col"><?php echo $token2 ?: '-'; ?></div>
                                <div class="nk-tb-col"><?php echo $token3 ?: '-'; ?></div>
                                <div class="nk-tb-col nk-tb-col-tools">
                                    <ul class="nk-tb-actions gx-2">
										<?php
										$hidden_actions = [
											[
												'link'  => '',
												'title' => $creator,
												'icon'  => 'ni-user-check',
											],
											[
												'link'  => '',
												'title' => $count . ' عدد',
												'icon'  => 'ni-alert',
											],
										];
										echo crm_get_template( 'partials/row-actions-hidden.php', [
											'actions' => $hidden_actions,
										] );
										?>
                                        <li>
											<?php
											$actions = [
												[
													'link'  => '',
													'title' => 'ویرایش قالب',
													'icon'  => 'ni-edit',
													'class' => 'edit_warning_template',
													'data'  => [
														'item-id'  => $id,
														'title'    => $title,
														'template' => $template,
														'token1'   => $token,
														'token2'   => $token2,
														'token3'   => $token3,
													],
												],
												[
													'link'  => '',
													'title' => 'حذف قالب',
													'icon'  => 'ni-trash',
													'class' => 'delete_warning_template',
													'data'  => [
														'item-id' => $id,
													],
												],
											];
											echo crm_get_template( 'partials/row-actions-dropdown.php', [
												'actions' => $actions,
											] );
											?>
                                        </li>
                                    </ul>
                                </div>
                            </div>
							<?php
						}
					}
					?>
                </div>
            </div>
        </div>
    </div>
</div>
