<?php

$per_page_key = basename( __FILE__, '.php' );
$per_page_key = "crm_{$per_page_key}_per_page";
$user_id      = get_current_user_id();
$defaults     = [
	'stock'       => '',
	'sku'         => '',
	'type'        => '',
	'log_action'  => '',
	'page_number' => 1,
	'status'      => 'normal',
	'per_page'    => get_user_meta( $user_id, $per_page_key, TRUE ) ?: 20,
];
$args         = wp_parse_args( $_REQUEST, $defaults );
$args         = array_map( fn( $v ) => $v == 0 ? '' : $v, $args );
$has_filter   = kcp_page_has_filter( $args, $defaults );
extract( $args );
update_user_meta( $user_id, $per_page_key, $per_page );
$offset     = ( $page_number - 1 ) * $per_page;
$date       = is_array( $date ) ? $date : [];
$DB         = new kcp_db();
$logs       = $DB->get_stock_log( compact( 'sku', 'type', 'log_action', 'stock', 'page_number', 'per_page' ) );
$total_logs = $logs['count'];
$total_page = ceil( $total_logs / $per_page );
$stock_logs = $logs['results'];
$actions    = $DB->log_action;
$stocks     = $DB->stocks;
$types      = $DB->log_type;
?>
<div class="nk-block-head nk-block-head-sm">
    <div class="nk-block-between">
        <div class="nk-block-head-content">
            <h3 class="nk-block-title page-title">انبار</h3>
        </div>
        <div class="nk-block-head-content">
            <div class="toggle-wrap nk-block-tools-toggle">
                <div class="toggle-expand-content">
                    <ul class="nk-block-tools g-3">
                        <li class="nk-block-tools-opt">
                            <a href="<?php echo home_url(); ?>/crm/order-new" class=" btn btn-info" target="_blank">
                                <em class="icon ni ni-cart"></em>
                                <span>ثبت سفارش</span>
                            </a>
                        </li>
                        <li class="nk-block-tools-opt">
                            <div class="drodown" data-bs-toggle="tooltip"
                                 data-bs-placement="top" title="افزودن گزارش">
                                <div class="dropdown-toggle btn btn-icon btn-primary"
                                     data-bs-toggle="modal"
                                     data-bs-target="#add_stock_log"><em
                                        class="icon ni ni-plus"></em></div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="nk-block">
    <div class="card card-stretch">
        <div class="card-inner-group">
            <div class="card-inner position-relative card-tools-toggle">
                <div class="card-title-group">
                    <div class="card-tools">
                    </div>
                    <div class="card-tools">
                        <ul class="btn-toolbar gx-1">
                            <li>
								<?php
								$filter_fields = [
									[
										'type'    => 'select',
										'label'   => 'انبار',
										'name'    => 'stock',
										'value'   => $stock,
										'col'     => 6,
										'options' => [ 0 => 'همه موارد' ] + $stocks,
									],
									[
										'type'    => 'select',
										'label'   => 'نوع گزارش',
										'name'    => 'log_action',
										'value'   => $log_action,
										'col'     => 6,
										'options' => [ 0 => 'همه موارد' ] + $actions,
									],
								];
								echo crm_get_template( 'partials/filter-dropdown.php', [
									'has_filter'    => $has_filter,
									'filter_fields' => $filter_fields,
								] );
								?>
                            </li>
                            <li class="btn-toolbar-sep"></li>
                            <li>
								<?php
								echo crm_get_template( 'partials/per-page-selector.php', [
									'per_page' => $per_page,
								] );
								?>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="card-inner p-0">
                <div class="nk-tb-list nk-tb-ulist is-compact">
                    <div class="nk-tb-item nk-tb-head">
                        <div class="nk-tb-col"><span class="sub-text">تاریخ</span></div>
                        <div class="nk-tb-col"><span class="sub-text">ثبت کننده</span></div>
                        <div class="nk-tb-col"><span class="sub-text">انبار</span></div>
                        <div class="nk-tb-col"><span class="sub-text">نوع لاگ</span></div>
                        <div class="nk-tb-col"><span class="sub-text">محصول</span></div>
                        <div class="nk-tb-col"><span class="sub-text">شماره سفارش</span></div>
                        <div class="nk-tb-col"><span class="sub-text">تعداد</span></div>
                        <div class="nk-tb-col"><span class="sub-text">توضیحات</span></div>
                        <div class="nk-tb-col nk-tb-col-tools text-end">
                        </div>
                    </div>
					<?php
					foreach ( $stock_logs as $stock_log ) {
						$log_id       = $stock_log['item_id'];
						$user_id      = $stock_log['user_id'];
						$log_type     = $stock_log['type'];
						$icon         = $log_type == 'stock_in' ? 'arrow-long-up' : 'arrow-long-down';
						$badge_class  = $log_type == 'stock_out' ? 'bg-outline-danger' : 'bg-outline-success';
						$action       = $stock_log['action'];
						$action_label = $actions[ $action ];
						if ( $action == 'transfer_in' ) {
							$action_label = 'انتقال از انبار' . ' ' . $stocks[ $stock_log['destination'] ];
						}
						if ( $action == 'transfer_out' ) {
							$action_label = 'انتقال به انبار' . ' ' . $stocks[ $stock_log['destination'] ];
						}
						$product_id = crm_get_product_by_sku( $stock_log['sku'] );
						$product    = wc_get_product( $product_id );
						if ( ! $product ) {
							continue;
						}
						$product_name = $product->get_name();
						$sku          = $product->get_sku();
						$order_id     = $stock_log['order_id'];
						$user_color   = get_user_meta( $user_id, 'user_color', TRUE ) ?: 'primary';
						$first_name   = get_user_meta( $user_id, 'first_name', TRUE );
						$last_name    = get_user_meta( $user_id, 'last_name', TRUE );
						?>
                        <div class="nk-tb-item">
                            <div class="nk-tb-col">
                                <span class="sub-text">
                                    <?php echo date_i18n( 'j F Y', strtotime( $stock_log['date'] ) + 12600 ); ?>
                                </span>
                            </div>
                            <div class="nk-tb-col">
                                <div class="user-card">
                                    <div class="user-avatar xs bg-<?php echo $user_color; ?>">
                                        <span><?php echo mb_substr( $first_name, 0, 1 ) . "‌" . mb_substr( $last_name, 0, 1 ); ?></span>
                                    </div>
                                    <div class="user-info">
                                        <span class="tb-lead"><?php echo get_user_name_by_id( $user_id ); ?></span>
                                    </div>
                                </div>
                            </div>
                            <div class="nk-tb-col">
                                <span><?php echo $stocks[ $stock_log['stock'] ]; ?></span>
                            </div>
                            <div class="nk-tb-col">
                                <small class="tb-odr-status badge <?= $badge_class; ?>">
                                    <em class="icon ni ni-<?php echo $icon; ?>"></em>
									<?php echo $action_label; ?>
                                </small>
                            </div>
                            <div class="nk-tb-col">
                                <div class="user-info">
                                    <span class="tb-lead"><?php echo $product_name; ?></span>
                                    <span><?php echo $sku; ?></span>
                                </div>
                            </div>
                            <div class="nk-tb-col">
								<?php
								if ( $order_id ) {
									$order_edit_link = "/wp-admin/post.php?post=$order_id&action=edit";
									echo '<a href="' . $order_edit_link . '" target="_blank">' . $order_id . '</a>';
								} else {
									echo '-';
								}
								?>
                            </div>
                            <div class="nk-tb-col">
                                <span><?= $stock_log['qty'] ?></span>
                            </div>
                            <div class="nk-tb-col user_action_content">
								<?php echo wpautop( $stock_log['details'] ); ?>
                            </div>
                            <div class="nk-tb-col nk-tb-col-tools">
                                <ul class="nk-tb-actions gx-2">
                                    <li>
                                    </li>
                                </ul>
                            </div>
                        </div>
						<?php
					}
					?>

                </div>
            </div>
            <div class="card-inner">
				<?php
				echo crm_get_template( 'partials/pagination.php', [
					'max_page_num' => $total_page,
					'current_page' => $page_number,
					'class_name'   => 'user_pagination_link',
					'show_count'   => 2,
				] );
				?>
            </div>
        </div>
    </div>
</div>

