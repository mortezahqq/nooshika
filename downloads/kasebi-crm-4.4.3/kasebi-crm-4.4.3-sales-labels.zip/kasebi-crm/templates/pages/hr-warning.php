<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

$per_page_key = basename( __FILE__, '.php' );
$per_page_key = "crm_{$per_page_key}_per_page";
$user_id      = get_current_user_id();
$defaults     = [
	'page_number' => 1,
	'per_page'    => get_user_meta( $user_id, $per_page_key, TRUE ) ?: 20,
	'date'        => [
		'from' => '',
		'to'   => '',
	],
	'warning_id'  => '',
	'user_id'     => '',
];
$args         = wp_parse_args( $_REQUEST, $defaults );
$args         = array_map( fn( $v ) => $v == 0 ? '' : $v, $args );
$has_filter   = kcp_page_has_filter( $args, $defaults );
extract( $args );
update_user_meta( $user_id, $per_page_key, $per_page );
$offset          = ( $page_number - 1 ) * $per_page;
$date            = is_array( $date ) ? $date : [];
$date_from       = $date['from'] ?? '';
$date_to         = $date['to'] ?? '';
$DB              = new kcp_db();
$logs            = $DB->get_warning_logs(
	compact( 'per_page', 'offset', 'date_from', 'date_to',
		'warning_id', 'user_id' ) );
$total           = $logs['total'] ?: 0;
$logs            = $logs['result'];
$employees       = get_users( [ 'role__in' => kcp_get_all_roles(), 'fields' => 'ids', ] );
$call_statuses   = $DB->get_call_statuses();
$call_categories = $DB->get_call_categories();
$templates       = $DB->get_warning_templates();

?>
<div class="nk-block-head nk-block-head-sm">
    <div class="nk-block-between">
        <div class="nk-block-head-content">
            <h3 class="nk-block-title page-title">گزارش ارسال اخطار به کارمندان</h3>
            <div class="nk-block-des text-soft">
                <p class="mb-0">شما در مجموع <?php echo $total; ?> اخطار به کارمندان ارسال کردید.</p>
            </div>
        </div>
    </div>
</div>
<div class="nk-block">
    <div class="card card-stretch">
        <div class="card-inner-group">
            <div class="card-inner position-relative card-tools-toggle">
                <div class="card-title-group">
                    <div class="card-tools"></div>
                    <div class="card-tools">
                        <ul class="btn-toolbar gx-1">
                            <li>
								<?php
								$filter_fields = [
									[
										'type'  => 'date-range',
										'label' => 'تاریخ ارسال',
										'name'  => 'date',
										'value' => [
											'from' => $date_from ?? '',
											'to'   => $date_to ?? '',
										],
									],
									[
										'type'    => 'select',
										'label'   => 'نوع اخطار',
										'name'    => 'status',
										'value'   => $status,
										'options' => [ 0 => 'همه موارد' ] + array_combine(
												array_column( $templates, 'id' ),
												array_column( $templates, 'title' )
											),
									],
									[
										'type'    => 'select',
										'label'   => 'گیرنده',
										'name'    => 'user_id',
										'value'   => $user_id,
										'col'     => 6,
										'options' => [ 0 => 'همه موارد' ] + array_combine(
												$employees,
												array_map( 'get_user_name_by_id', $employees )
											),
									],
								];
								echo crm_get_template( 'partials/filter-dropdown.php', [
									'has_filter'    => $has_filter,
									'filter_fields' => $filter_fields,
								] );
								?>
                            </li>
                            <li class="btn-toolbar-sep"></li>
                            <li>
								<?php
								echo crm_get_template( 'partials/per-page-selector.php', [
									'per_page' => $per_page,
								] );
								?>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="card-inner p-0">
                <div class="nk-tb-list nk-tb-ulist is-compact">
                    <div class="nk-tb-item nk-tb-head">
                        <div class="nk-tb-col w-200px"><span class="sub-text">تاریخ</span></div>
                        <div class="nk-tb-col"><span class="sub-text">نوع اخطار</span></div>
                        <div class="nk-tb-col"><span class="sub-text">گیرنده</span></div>
                        <div class="nk-tb-col"><span class="sub-text">متن اخطار</span></div>
                        <div class="nk-tb-col nk-tb-col-tools text-end"></div>
                    </div>
					<?php
					if ( empty( $logs ) ) {
						echo '<div class="no-item-found">گزارشی یافت نشد</div>';
					} else {
						foreach ( $logs as $log ) {
							extract( $log );
							$creator = get_user_name_by_id( $sender );
							$warning = $DB->get_warning_template( $warning_id );
							?>
                            <div class="nk-tb-item">
                                <div class="nk-tb-col">
                                    <span class="sub-text">
                                        <?php echo date_i18n( 'j F Y', strtotime( $date ) ); ?></span>
                                </div>
                                <div class="nk-tb-col">
									<?php echo $warning['title']; ?>
                                </div>
                                <div class="nk-tb-col">
									<?php
									echo crm_get_template( 'partials/user-card.php', [
										'user_id'    => $user_id,
										'show_phone' => TRUE,
									] );
									?>
                                </div>
                                <div class="nk-tb-col w-max-250px w-250px fs-12px nk-news-text"
                                     data-bs-toggle="popover"
                                     data-bs-trigger="click"
                                     data-bs-html="true"
                                     title="متن ارسالی"
                                     data-bs-content='<?php echo wpautop( $message ); ?>'
                                     data-bs-placement="top">
                                    <p><?php echo esc_html( $message ); ?></p>
                                </div>
                                <div class="nk-tb-col nk-tb-col-tools">
                                    <ul class="nk-tb-actions gx-2">
										<?php
										$hidden_actions = [
											[
												'link'  => '',
												'title' => $creator,
												'icon'  => 'ni-user-check',
											],
										];
										echo crm_get_template( 'partials/row-actions-hidden.php', [
											'actions' => $hidden_actions,
										] );
										?>
                                    </ul>
                                </div>
                            </div>
							<?php
						}
					}
					?>
                </div>
            </div>
            <div class="card-inner">
				<?php
				echo crm_get_template( 'partials/pagination.php', [
					'max_page_num' => $total_page,
					'current_page' => $page_number,
					'class_name'   => 'user_pagination_link',
					'show_count'   => 2,
				] );
				?>
            </div>
        </div>
    </div>
</div>
