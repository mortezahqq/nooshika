<?php
if ( ! current_user_can( 'manage_options' ) ) {
	?>
    <div class="container-xl wide-xl">
        <div class="card text-danger text-center fw-bold">
            <div class="card-inner">شما دسترسی لازم برای مشاهده این صفحه را ندارید</div>
        </div>
    </div>
	<?php
	return;
}

$defaults = [
	'date' => [
		'from' => '1405-1-1',
		'to'   => '',
	],
];
$args     = wp_parse_args( $_REQUEST, $defaults );
extract( $args );
$date      = is_array( $date ) ? $date : [];
$date_from = $date['from'] ?? '';
$date_to   = $date['to'] ?? '';

$kasebi_order_class = new Kasebi_Order_Index();
$orders_report      = $kasebi_order_class->get_orders_report( $date_from, $date_to );
if ( ! empty( $orders_report['products'] ) ) {
	uasort( $orders_report['products'], function( $a, $b ) {
		return $b['total'] <=> $a['total']; // بیشترین فروش اول
	} );
}
if ( ! empty( $orders_report['marketers'] ) ) {
	uasort( $orders_report['marketers'], function( $a, $b ) {
		return $b['total'] <=> $a['total']; // بیشترین فروش اول
	} );
}
$marketer_chart_labels = [];
$marketer_chart_data   = [];

foreach ( $orders_report['marketers'] as $marketer_id => $report ) {
	$marketer_chart_labels[] = get_user_name_by_id( $marketer_id );
	$marketer_chart_data[]   = (float) ( $report['total'] ?? 0 );
}

$product_chart_labels = [];
$product_chart_data   = [];

foreach ( $orders_report['products'] as $product_id => $report ) {
	$product_chart_labels[] = get_the_title( $product_id );
	$product_chart_data[]   = (float) ( $report['total'] ?? 0 );
}

$marketer_chart_labels_json = esc_attr( wp_json_encode( array_values( $marketer_chart_labels ), JSON_UNESCAPED_UNICODE ) );
$marketer_chart_data_json   = esc_attr( wp_json_encode( array_values( $marketer_chart_data ), JSON_UNESCAPED_UNICODE ) );
$product_chart_labels_json  = esc_attr( wp_json_encode( array_values( $product_chart_labels ), JSON_UNESCAPED_UNICODE ) );
$product_chart_data_json    = esc_attr( wp_json_encode( array_values( $product_chart_data ), JSON_UNESCAPED_UNICODE ) );
?>
<div class="nk-block-head nk-block-head-sm">
    <div class="nk-block-between">
        <div class="nk-block-head-content">
            <h3 class="nk-block-title page-title">گزارش جامع فروش:</h3>
        </div>
        <div class="card-tools">
            <ul class="btn-toolbar gx-1">
                <li>
					<?php
					$filter_fields = [
						[
							'type'  => 'date-range',
							'label' => 'تاریخ گزارش',
							'name'  => 'date',
							'value' => [
								'from' => $date_from ?? '',
								'to'   => $date_to ?? '',
							],
						],
					
					];
					echo crm_get_template( 'partials/filter-dropdown.php', [
						'has_filter'    => FALSE,
						'filter_fields' => $filter_fields,
					] );
					?>
                </li>
            </ul>
        </div>
    </div>
</div>
<div class="nk-block">
	<?php
	$summary = is_array( $orders_report['summary'] ?? NULL ) ? $orders_report['summary'] : [];
	
	$total_orders = (int) ( $summary['count'] ?? 0 );
	$total_sales  = (float) ( $summary['total'] ?? 0 );
	$avg_sales    = $total_orders > 0 ? $total_sales / $total_orders : 0;
	?>

    <div class="row g-gs">
        <div class="col-md-4">
            <div class="card card-bordered">
                <div class="card-inner">
                    <div class="card-title-group align-start mb-2">
                        <div class="card-title">
                            <h6 class="title">جمع کل فروش</h6>
                        </div>
                        <div class="card-tools">
                            <em class="icon ni ni-coins text-success"></em>
                        </div>
                    </div>

                    <div class="align-end flex-sm-wrap g-4 flex-md-nowrap">
                        <div class="nk-sale-data">
                            <span class="amount">
                                <?php echo esc_html( number_format_i18n( $total_sales ) ); ?>
                                <span class="currency currency-usd">تومان</span>
                            </span>
                        </div>
                    </div>

                    <div class="sub-text mt-1">
                        مجموع مبلغ سفارش‌های موفق در بازه انتخاب‌شده
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card card-bordered">
                <div class="card-inner">
                    <div class="card-title-group align-start mb-2">
                        <div class="card-title">
                            <h6 class="title">تعداد سفارش</h6>
                        </div>
                        <div class="card-tools">
                            <em class="icon ni ni-cart text-primary"></em>
                        </div>
                    </div>

                    <div class="align-end flex-sm-wrap g-4 flex-md-nowrap">
                        <div class="nk-sale-data">
                            <span class="amount">
                                <?php echo esc_html( number_format_i18n( $total_orders ) ); ?>
                            </span>
                        </div>
                    </div>

                    <div class="sub-text mt-1">
                        تعداد سفارش‌های محاسبه‌شده در گزارش
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card card-bordered">
                <div class="card-inner">
                    <div class="card-title-group align-start mb-2">
                        <div class="card-title">
                            <h6 class="title">میانگین فروش هر سفارش</h6>
                        </div>
                        <div class="card-tools">
                            <em class="icon ni ni-growth text-info"></em>
                        </div>
                    </div>

                    <div class="align-end flex-sm-wrap g-4 flex-md-nowrap">
                        <div class="nk-sale-data">
                            <span class="amount">
                                <?php echo esc_html( number_format_i18n( $avg_sales ) ); ?>
                                <span class="currency currency-usd">تومان</span>
                            </span>
                        </div>
                    </div>

                    <div class="sub-text mt-1">
                        جمع فروش تقسیم بر تعداد سفارش‌ها
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="nk-block">
    <div class="row g-gs">
        <div class="col-md-6">
            <div class="card h-100">
                <div class="card-inner">
                    <div class="card-title-group mb-2">
                        <div class="card-title">
                            <h6 class="title">نمودار فروش بازاریابان</h6>
                        </div>
                    </div>
                    <div class="atlas-chart"
                         data-chart-type="bar"
                         data-label="مبلغ فروش"
                         data-labels="<?php echo $marketer_chart_labels_json; ?>"
                         data-data="<?php echo $marketer_chart_data_json; ?>"
                         data-unit="تومان"
                         data-legend="0"
                         data-grid="1"
                         data-chart-height="320">
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card h-100">
                <div class="card-inner">
                    <div class="card-title-group mb-2">
                        <div class="card-title">
                            <h6 class="title">گزارش بازاریابان</h6>
                        </div>
                    </div>
                    <ul class="gy-4">
						<?php
						$total_items = count( $orders_report['marketers'] );
						$i           = 0;
						foreach ( $orders_report['marketers'] as $marketer_id => $report ) {
							$i ++;
							$is_last = $i === $total_items;
							?>
                            <li class="justify-between align-center border-0 border-dashed <?php echo $is_last ? '' : 'border-bottom'; ?>">
                                <div class="ms-2">
                                    <div class="lead-text"><?php echo get_user_name_by_id( $marketer_id ); ?></div>
                                    <div class="sub-text"><?php echo $report['count']; ?> سفارش موفق</div>
                                </div>
                                <div class="fs-20px me-1">
									<?php echo number_format( $report['total'] ); ?> تومان
                                </div>
                            </li>
							<?php
						}
						?>
                    </ul>
                </div>
            </div>
        </div>
        <div class="col-md-8">
            <div class="card h-100">
                <div class="card-inner">
                    <div class="card-title-group mb-2">
                        <div class="card-title">
                            <h6 class="title">نمودار فروش محصولات</h6>
                        </div>
                    </div>
                    <div class="atlas-chart"
                         data-chart-type="bar"
                         data-label="مبلغ فروش"
                         data-labels="<?php echo $product_chart_labels_json; ?>"
                         data-data="<?php echo $product_chart_data_json; ?>"
                         data-unit="تومان"
                         data-legend="0"
                         data-grid="1"
                         data-chart-height="320">
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card h-100">
                <div class="card-inner">
                    <div class="card-title-group mb-2">
                        <div class="card-title">
                            <h6 class="title">گزارش محصولات پرفروش</h6>
                        </div>
                    </div>
                    <ul class="gy-4">
						<?php
						$total_items = count( $orders_report['products'] );
						$i           = 0;
						foreach ( $orders_report['products'] as $product_id => $report ) {
							$i ++;
							$is_last = $i === $total_items;
							?>
                            <li class="justify-between align-center border-0 border-dashed <?php echo $is_last ? '' : 'border-bottom'; ?>">
                                <div class="ms-2">
                                    <div class="lead-text"><?php echo get_the_title( $product_id ); ?></div>
                                    <div class="sub-text"><?php echo $report['count']; ?> واحد</div>
                                </div>
                                <div class="fs-20px me-1">
									<?php echo number_format( $report['total'] ); ?> تومان
                                </div>
                            </li>
							<?php
						}
						?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
