<?php
$defaults = [
	'c_id' => '',
];
$args     = wp_parse_args( $_REQUEST, $defaults );

$customer_id = $args['c_id'];
$addresses   = [];
if ( $customer_id ) {
	$addresses = get_user_meta( $customer_id, 'address_list', TRUE );
	$addresses = kasebi_unminified_string( $addresses );
	$addresses = $addresses ?: [];
}

$monthly_percents = [
	1 => [
		6  => 0,
		12 => 1,
		18 => 1.2,
		24 => 1.5,
	],
	2 => [
		6  => 0,
		12 => 1,
		18 => 1.2,
		24 => 1.5,
	],
	3 => [
		6  => 1.3,
		12 => 1.3,
		18 => 1.6,
		24 => 2.2,
	],
	4 => [
		6  => 1.3,
		12 => 1.3,
		18 => 1.6,
		24 => 2.2,
	],
	5 => [
		6  => 1.5,
		12 => 1.5,
		18 => 2,
		24 => 2.5,
	],
	6 => [
		6  => 1.5,
		12 => 1.5,
		18 => 2,
		24 => 2.5,
	],
];
$payments         = [
	'pay_in_cash' => [
		'title' => 'نقدی',
	],
	'pay_monthly' => [
		'title' => 'قسطی',
	],
	'pay_dated'   => [
		'title' => 'مدت دار',
	],
];
?>
<div id="monthly_payment_json" hidden>
	<?php echo json_encode( $monthly_percents ); ?>
</div>
<div class="nk-block-head nk-block-head-sm">
    <div class="nk-block-between">
        <div class="nk-block-head-content">
            <h3 class="nk-block-title page-title">ثبت سفارش</h3>
        </div>
    </div>
</div>
<div class="nk-block invoice-bills">
    <div class="row g-gs">
        <div class="col-12 col-md-4">
            <div class="card">
                <div class="card-inner">
                    <div class="form-group card-title search_wrapper">
                        <label class="form-label" for="search_user_for_order">جستجوی مشتری</label>
                        <div class="form-control-wrap">
                            <div class="form-icon form-icon-left"><em class="icon ni ni-user"></em></div>
                            <input type="text" class="form-control search_user_modal" id="search_user_for_order">
                        </div>
                        <p class="mt-1">جهت جستجوی مشتری شماره موبایل و یا نام مشتری را جستجو کنید.</p>
                        <div class="customer_search_result" data-input="#new_order_customer_id"
                             data-preview=".customer_box"></div>
                    </div>
                    <div class="customer_box nk-tb-list">
						<?php
						if ( $customer_id ) {
							echo crm_get_template( 'partials/user-card.php', [
								'user_id'    => $customer_id,
								'show_phone' => TRUE,
							] );
						}
						?>
                    </div>
                    <input type="hidden" id="new_order_customer_id" value="<?php echo $customer_id; ?>">
                </div>
            </div>
        </div>
        <div class="col-12 col-md-8 product_block_card">
            <div class="card h-100">
                <div class="card-inner">
                    <div class="row g-gs">
                        <div class="col-12 col-md-4">
                            <div class="form-group card-title">
                                <label class="form-label" for="search_sku_for_order">جستجوی محصول</label>
                                <div class="form-control-wrap">
                                    <div class="form-icon form-icon-left"><em class="icon ni ni-package"></em></div>
                                    <input type="text" class="form-control" id="search_sku_for_order"
                                           placeholder="نام محصول">
                                </div>
                            </div>
                            <div class="product_search_list"></div>
                        </div>
                        <div class="col-12 col-md-8">
                            <div class="product_search_result"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<?php
		if ( $customer_id ) {
			$has_used_referral = get_user_meta( $customer_id, 'kasebi_has_used_referral', TRUE );
			if ( $has_used_referral != 'yes' ) {
				echo crm_get_template( "misc/referral_form.php", [
					'user_id' => $customer_id,
				] );
			}
		}
		?>
        <div class="col-12 order_factor_card">
            <div class="card">
                <div class="card-inner">
                    <table class="table table-striped products_payment">
                        <thead>
                        <tr>
                            <th class="w-30">عنوان محصول</th>
                            <th class="w-110px">مقدار(کیلوگرم)</th>
                            <th>فی</th>
                            <th class="w-80px"> تخفیف</th>
                            <th>فی بعد از تخفیف</th>
                            <th class="text-end">مبلغ کل</th>
                        </tr>
                        </thead>
                        <tbody>
                        </tbody>
                        <tfoot>
                        <tr>
                            <td colspan="3"></td>
                            <td colspan="2">جمع کل</td>
                            <td class="order_subtotal">0</td>
                        </tr>
                        <tr>
                            <td colspan="3"></td>
                            <td colspan="2">تخفیفات</td>
                            <td class="order_discount">0</td>
                        </tr>
                        <tr>
                            <td colspan="3"></td>
                            <td colspan="2">جمع کل کالاها</td>
                            <td class="order_total">0</td>
                        </tr>
                        <tr>
                            <td colspan="3"></td>
                            <td colspan="2">میزان بالابرد</td>
                            <td>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control price_input order_custom_extra_fee ltr">
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="3"></td>
                            <td colspan="2">میزان تخفیف</td>
                            <td>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control price_input order_custom_fee ltr">
                                </div>
                            </td>
                        </tr>
                        <tr class="beyane_row">
                            <td colspan="3"></td>
                            <td colspan="2">پیش پرداخت</td>
                            <td class="cart_total_beyane">0</td>
                        </tr>
                        <tr class="referral_discount">
                            <td colspan="3"></td>
                            <td colspan="2">تخفیف معرف</td>
                            <td class="cart_referral_discount">0</td>
                        </tr>
                        <tr class="payment_fee">
                            <td colspan="3"></td>
                            <td colspan="2">تفاوت مدت</td>
                            <td class="cart_total_payment_fee">0</td>
                        </tr>
                        <tr>
                            <td colspan="3"></td>
                            <td colspan="2">مبلغ قابل پرداخت</td>
                            <td class="order_total_final">0</td>
                        </tr>
                        </tfoot>
                    </table>
                    <div class="d-flex justify-end mt-3">
                        <button class="btn btn-success submit_order">ثبت سفارش</button>
                    </div>
                    <div class="order_extra_table">
                        <h6 class="nk-block-title">شیوه پرداخت</h6>
                        <div class="payment_type_block mb-4">
                            <div class="g-4 align-center flex-wrap">
								<?php
								foreach ( $payments as $payment => $data ) {
									$checked = 'pay_in_cash' == $payment ? ' checked' : '';
									?>
                                    <div class="g">
                                        <div
                                            class="custom-control custom-control-sm custom-radio <?php echo $checked; ?>">
                                            <input type="radio" class="custom-control-input change_payment_method"
                                                   name="payment_type"<?php echo $checked; ?>
                                                   id="<?php echo $payment; ?>"
                                                   value="<?php echo $payment; ?>">
                                            <label class="custom-control-label"
                                                   for="<?php echo $payment; ?>"><?php echo $data['title']; ?></label>
                                        </div>
                                    </div>
									<?php
								}
								?>
                            </div>
                            <div class="monthly_payment_fields payment-method-dependent mb-2"
                                 data-payment-methods="pay_monthly">
                                <div class="row g-3">
                                    <div class="col-6">
                                        <div class="form-group">
                                            <label for="month_count" class="form-label">تعداد ماه</label>
                                            <input type="text" id="month_count" class="form-control" value="6">
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="form-group">
                                            <div class="form-control-wrap">

                                                <label for="cheque_count"
                                                       class="form-label">فاصله هر چک</label>
                                                <select id="cheque_count" class="form-select js-select2">
													<?php
													for ( $i = 1; $i <= 6; $i ++ ) {
														echo "<option value='$i'>$i</option>";
													}
													?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="payment_status payment-method-dependent mb-1"
                                 data-payment-methods="pay_monthly">
                                <div class="nk-block-between">
                                    <div class="fw-bold">مبلغ هر چک:</div>
                                    <span class="each_cheque_price_value"></span>
                                </div>
                                <div class="nk-block-between">
                                    <div class="fw-bold">قسط هر ماه:</div>
                                    <span class="each_month_price_value"></span>
                                </div>
                            </div>
                            <input type="hidden" id="monthly_payment_percent">
                        </div>
                        <div class="dated_payment_fields payment-method-dependent mb-2"
                             data-payment-methods="pay_dated">
                            <label class="form-label fw-bold mb-2">مدت پرداخت</label>

                            <div class="g-3 align-center flex-wrap">
								<?php
								$dated_days = [ 7, 15, 21, 30, 45, 60 ];
								
								foreach ( $dated_days as $day ) {
									$checked = 30 === $day ? ' checked' : '';
									?>
                                    <div class="g">
                                        <div class="custom-control custom-control-sm custom-radio">
                                            <input type="radio"
                                                   class="custom-control-input change_dated_payment_day"
                                                   name="dated_payment_days"
                                                   id="dated_payment_days_<?php echo esc_attr( $day ); ?>"
                                                   value="<?php echo esc_attr( $day ); ?>"<?php echo $checked; ?>>

                                            <label class="custom-control-label"
                                                   for="dated_payment_days_<?php echo esc_attr( $day ); ?>">
												<?php echo esc_html( $day ); ?> روزه
                                            </label>
                                        </div>
                                    </div>
									<?php
								}
								?>
                            </div>
                        </div>
                        <input type="hidden" id="monthly_payment_percent">
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-inner">
                    <div class="nk-block-between mb-2">
                        <h6 class="nk-block-title">مستندات سفارش</h6>
                    </div>
                    <div class="form-group">
                        <div class="upload-zone" data-target="#new_order_attachment"
                             data-name="title"
                             data-action="crm_handle_file_upload" data-max-files="30">
                            <div class="dz-message" data-dz-message>
                                <span class="dz-message-text">بکشید و رها کنید</span>
                                <span class="dz-message-or">یا</span>
                                <div class="btn btn-primary">انتخاب کنید</div>
                            </div>
                        </div>
                    </div>
                    <input type="hidden" id="new_order_attachment">
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card h-100">
                <div class="card-inner">
                    <div class="nk-block-between">
                        <h6 class="nk-block-title">پرداخت های نقدی</h6>
                        <a href="#" class="btn btn-icon btn-primary" data-bs-target="#addCashPayment"
                           data-bs-toggle="modal"><em class="icon ni ni-plus"></em></a>
                    </div>
                    <div class="cash_payment_table">
                        <table class="table table-striped">
                            <thead>
                            <tr>
                                <th class="w-150px">مبلغ واریز</th>
                                <th class="w-30">نزد بانک</th>
                                <th>تاریخ پرداخت</th>
                                <th class="text-end"></th>
                            </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-inner">
                    <div class="form-group mb-3">
                        <label class="form-label fw-bold" for="new_factor_date">تاریخ فاکتور</label>
                        <div class="form-control-wrap">
                            <div class="form-icon form-icon-left">
                                <em class="icon ni ni-calendar-alt"></em>
                            </div>
                            <input type="text" class="form-control datepicker" id="new_factor_date">
                        </div>
                    </div>
                    <div class="nk-block-between mb-2">
                        <h6 class="nk-block-title">توضیحات سفارش</h6>
                    </div>
                    <div class="form-control-wrap">
                        <textarea class="form-control no-resize" id="order_description"></textarea>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card">
                <div class="card-inner  pb-0">
                    <div class="nk-block-between">
                        <h6 class="nk-block-title">آدرس تحویل سفارش</h6>
                        <a href="#" class="btn btn-icon btn-primary" id="open_addUserAddress"><em class="icon
                                 ni ni-plus"></em></a>
                    </div>
                </div>
                <div class="card-inner address_wrapper">
					<?php
					echo crm_get_template( "misc/addresses.php", [
						'addresses' => $addresses,
						'user_id'   => $customer_id,
					] );
					?>
                </div>
            </div>
        </div>
    </div>
</div>
