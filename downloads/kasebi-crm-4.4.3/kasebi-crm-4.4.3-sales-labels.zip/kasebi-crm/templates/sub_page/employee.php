<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
if ( isset( $_REQUEST['id'] ) ) {
	$user_id = $_REQUEST['id'];
} else {
	global $wp;
	$path    = explode( '/', $wp->request );
	$user_id = $path[2];
}
$tab       = $_REQUEST['tab'] ?? 'profile';
$tabs_list = [
	'profile' => [
		'label' => 'پروفایل',
		'icon'  => 'user-circle',
	],
	'wallet'  => [
		'label' => 'کیف پول',
		'icon'  => 'wallet-in',
	],
	'reports' => [
		'label' => 'گزارشات',
		'icon'  => 'bar-chart',
	],
];

$metas = [
	'first_name'  => [
		'type'  => 'text',
		'label' => 'نام',
	],
	'last_name'   => [
		'type'  => 'text',
		'label' => 'نام خانوادگی',
	],
	'birth_date'  => [
		'type'  => 'date',
		'label' => 'تاریخ تولد',
	],
	'gender'      => [
		'type'    => 'select',
		'label'   => 'جنسیت',
		'width'   => '6',
		'options' => [
			'male'   => [
				'label' => 'مرد',
			],
			'female' => [
				'label' => 'زن',
			],
			'other'  => [
				'label' => 'سایر',
			],
		],
	],
	'national_id' => [
		'type'  => 'number',
		'label' => 'کد ملی',
	],
	
	'mobile'  => [
		'type'  => 'text',
		'label' => 'شماره تماس',
	],
	'address' => [
		'label' => 'آدرس',
		'width' => '100%',
	],
];
?>
<input type="hidden" id="current_user_id" value="<?php echo $user_id; ?>">
<div class="nk-block nk-block-lg">
    <div class="card">
        <div class="card-aside-wrap">
            <div class="card-content">
                <ul class="nav nav-tabs nav-tabs-mb-icon nav-tabs-card">
					<?php
					foreach ( $tabs_list as $tab_key => $tab_data ) {
						$active = $tab == $tab_key ? ' active' : '';
						?>
                        <li class="nav-item">
                            <a class="page_activator nav-link<?php echo $active; ?>"
                               href="<?php echo '/crm/employee/' . $user_id . '?tab=' . $tab_key; ?>"
                               data-url="<?php echo '/crm/employee/' . $user_id . '?tab=' . $tab_key; ?>">
                                <em class="icon ni ni-<?php echo $tab_data['icon']; ?>"></em>
                                <span><?php echo $tab_data['label']; ?></span>
                            </a>
                        </li>
						<?php
					}
					?>
                    <li class="nav-item nav-item-trigger d-xxl-none">
                        <a href="#" class="toggle btn btn-icon btn-trigger" data-target="userAside"><em
                                class="icon ni ni-user-list-fill"></em></a>
                    </li>
                </ul>
                <div class="card-inner">
                    <div class="tab-content">
                        <div class="tab-pane active">
							<?php echo crm_get_template( "tab/employee/$tab.php", [
								'user_id' => $user_id,
								'metas'   => $metas,
							] ); ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-aside card-aside-right user-aside toggle-slide toggle-slide-right toggle-break-lg"
                 data-toggle-body="true" data-content="userAside" data-toggle-screen="lg" data-toggle-overlay="true">
                <div class="card-inner-group" data-simplebar>
					<?php echo crm_get_template( "tab/employee/info.php", [ 'user_id' => $user_id ] ); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" tabindex="-1" role="dialog" id="editPersonal">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
            <div class="modal-body modal-body-md">
                <h5 class="modal-title">به روز رسانی اطلاعات کارمند</h5>
                <form action="#" class="mt-4">
                    <div class="row g-gs">
						<?php
						foreach ( $metas as $key => $meta ) {
							$value    = get_user_meta( $user_id, $key, TRUE );
							$type     = $meta['type'];
							$label    = $meta['label'];
							$required = $meta['required'];
							$width    = isset( $meta['width'] ) && $meta['width'] == '100%' ? 12 : 6;
							$id       = 'edit_' . $key;
							
							$is_conditional = ( ! empty( $meta['state'] ) && $meta['state'] === 'conditional' );
							$cond_meta      = $meta['conditions']['meta'] ?? '';
							$cond_value     = $meta['conditions']['value'] ?? '';
							$cond_operator  = $meta['conditions']['operator'] ?? '==';
							
							$expected_json = wp_json_encode( $cond_value );
							$row_classes   = 'col-md-' . (int) $width . ' meta-field-row';
							if ( $required ) {
								$label .= ' *';
							}
							?>
                            <div class="<?php echo esc_attr( $row_classes ); ?>"
                                 data-meta-key="<?php echo esc_attr( $key ); ?>"
                                 data-conditional="<?php echo $is_conditional ? '1' : '0'; ?>"
                                 data-cond-meta="<?php echo esc_attr( $cond_meta ); ?>"
                                 data-cond-expected='<?php echo esc_attr( $expected_json ); ?>'
                                 data-cond-operator="<?php echo esc_attr( $cond_operator ); ?>">
                                <div class="form-group">
                                    <label class="form-label" for="<?php echo $id; ?>"><?php echo $label; ?></label>
                                    <div class="form-control-wrap">
										<?php
										if ( $type === 'textarea' ) {
											?>
                                            <textarea class="form-control" id="<?php echo $id; ?>"
                                                      data-for="<?php echo $key; ?>"><?php echo esc_html( $value ); ?></textarea>
											<?php
										} elseif ( $type === 'select' && ! empty( $meta['options'] ) ) {
											?>
                                            <select class="form-select js-select2" id="<?php echo $id; ?>"
                                                    data-for="<?php echo $key; ?>">
                                                <option value="" selected disabled>انتخاب کنید</option>
												<?php
												foreach ( $meta['options'] as $option_value => $option_data ) {
													$option_label = $option_data['label'];
													$selected     = selected( $value, $option_value, FALSE );
													echo "<option value='$option_value' $selected>$option_label</option>";
												}
												?>
                                            </select>
											<?php
										} elseif ( $type === 'date' ) {
											if ( ! empty( $value ) ) {
												$value = date( 'Y/m/d', strtotime( $value ) );
											}
											?>
                                            <div class="form-icon form-icon-right">
                                                <em class="icon ni ni-calendar"></em>
                                            </div>
                                            <input type="text" class="form-control datepicker"
                                                   id="<?php echo $id; ?>"
                                                   data-for="<?php echo $key; ?>"
                                                   placeholder="روز-ماه-سال"
                                                   value="<?php echo $value; ?>"/>
											<?php
										} else {
											?>
                                            <input type="<?php echo $type; ?>" class="form-control"
                                                   id="<?php echo $id; ?>"
                                                   data-for="<?php echo $key; ?>"
                                                   value="<?php echo $value; ?>"/>
											<?php
										}
										?>
                                    </div>
                                </div>
                            </div>
							<?php
						}
						foreach ( $taxonomies as $taxonomy => $label ) {
							?>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label" for="kcl_<?php echo $taxonomy; ?>">
										<?php echo $label; ?>
                                    </label>
                                    <div class="form-control-wrap">
                                        <select class="form-select js-select2"
                                                data-for="kcl_<?php echo $taxonomy; ?>"
                                                id="kcl_<?php echo $taxonomy; ?>"
                                                data-placeholder="گروه را انتخاب کنید" multiple>
                                            <option value="">انتخاب کنید</option>
											<?php
											$terms   = get_user_meta( $user_id, 'kcl_' . $taxonomy, TRUE ) ?: [];
											$options = get_option( 'kcl_therapy_' . $taxonomy, ) ?: [];
											foreach ( $options as $term_id => $data ) {
												$selected = in_array( $term_id, $terms ) ? 'selected' : '';
												?>
                                                <option
                                                    value="<?php echo $term_id; ?>" <?php echo $selected; ?>><?php
													echo $data['label']; ?></option>
												<?php
											}
											?>
                                        </select>
                                    </div>
                                </div>
                            </div>
							<?php
						}
						?>
                        <div class="col-12">
                            <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                <li>
                                    <div id="update_user_personal_data" class="btn btn-primary">به روز رسانی
                                    </div>
                                </li>
                                <li>
                                    <a href="#" class="link link-light" data-bs-dismiss="modal">لغو</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>