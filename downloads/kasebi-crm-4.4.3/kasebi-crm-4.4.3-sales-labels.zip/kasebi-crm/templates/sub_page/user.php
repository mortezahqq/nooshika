<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
if ( isset( $_REQUEST['id'] ) ) {
	$user_id = $_REQUEST['id'];
} else {
	global $wp;
	$path    = explode( '/', $wp->request );
	$user_id = $path[2];
}
$tab         = $_REQUEST['tab'] ?? 'profile';
$tabs_list   = [
	'profile' => [
		'label' => 'پروفایل',
		'icon'  => 'user-circle',
	],
	'action'  => [
		'label' => 'فعالیت',
		'icon'  => 'activity',
	],
	'track'   => [
		'label' => 'پیگیری',
		'icon'  => 'call-alt-fill',
	],
	'call'    => [
		'label' => 'درخواست',
		'icon'  => 'chat-msg',
	],
	'orders'  => [
		'label' => 'سفارشات',
		'icon'  => 'repeat',
	],
	'wallet'  => [
		'label' => 'کیف پول',
		'icon'  => 'wallet',
	],
];
$product_ids = get_posts( [
	'post_type'      => 'product',
	'post_status'    => [ 'publish', 'private' ],
	'posts_per_page' => - 1,
] );
$product_ids = wp_list_pluck( $product_ids, 'post_title', 'ID' );
$kcp_db      = new kcp_db();
$track_type  = $kcp_db->get_track_types();
?>
<input type="hidden" id="current_user_id" value="<?php echo $user_id; ?>">
<div class="nk-block nk-block-lg">
    <div class="card">
        <div class="card-aside-wrap">
            <div class="card-content">
                <ul class="nav nav-tabs nav-tabs-mb-icon nav-tabs-card">
					<?php
					foreach ( $tabs_list as $tab_key => $tab_data ) {
						$active = $tab == $tab_key ? ' active' : '';
						?>
                        <li class="nav-item pe-4">
                            <a class="page_activator nav-link<?php echo $active; ?>"
                               href="<?php echo '/crm/user/' . $user_id . '?tab=' . $tab_key; ?>"
                               data-url="<?php echo '/crm/user/' . $user_id . '?tab=' . $tab_key; ?>">
                                <em class="icon ni ni-<?php echo $tab_data['icon']; ?>"></em>
                                <span><?php echo $tab_data['label']; ?></span>
                            </a>
                        </li>
						<?php
					}
					?>
                    <li class="nav-item nav-item-trigger d-xxl-none">
                        <a href="#" class="toggle btn btn-icon btn-trigger" data-target="userAside"><em
                                class="icon ni ni-user-list-fill"></em></a>
                    </li>
                </ul>
                <div class="card-inner">
                    <div class="tab-content">
                        <div class="tab-pane active">
							<?php echo crm_get_template( "tab/user/$tab.php", [ 'user_id' => $user_id ] ); ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-aside card-aside-right user-aside toggle-slide toggle-slide-right toggle-break-lg"
                 data-toggle-body="true" data-content="userAside" data-toggle-screen="lg" data-toggle-overlay="true">
                <div class="card-inner-group" data-simplebar>
					<?php echo crm_get_template( "tab/user/info.php", [ 'user_id' => $user_id ] ); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="modal fade zoom" id="addNewUserNote">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content modal_form"
             data-action="crm_add_user_note">

            <a href="#" class="close" data-bs-dismiss="modal">
                <em class="icon ni ni-cross-sm"></em>
            </a>

            <div class="modal-body">
                <h5 class="modal-title">افزودن یادداشت مشتری</h5>

                <form action="#" class="mt-4">
                    <div class="row g-gs">

                        <input type="hidden"
                               data-for="id"
                               value="<?php echo esc_attr( $user_id ?? get_current_user_id() ); ?>">

                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label">متن یادداشت</label>
                                <div class="form-control-wrap">
                                    <div class="quill-basic"
                                         data-name="user_note_content"
                                         data-for="desc"
                                         data-req="1"></div>
                                </div>
                            </div>
                        </div>

                        <div class="col-12">
                            <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                <li>
                                    <button type="button"
                                            class="btn btn-primary submit_modal_form"
                                            data-bs-dismiss="modal">
                                        افزودن یادداشت
                                    </button>
                                </li>
                                <li>
                                    <a href="#" class="link link-light" data-bs-dismiss="modal">لغو</a>
                                </li>
                            </ul>
                        </div>

                    </div>
                </form>
            </div>

        </div>
    </div>
</div>
<div class="modal fade zoom" id="crop">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">تنظیم تصویر پروفایل</h5>
                <a href="#" class="close" data-bs-dismiss="modal" aria-label="بستن">
                    <em class="icon ni ni-cross"></em>
                </a>
            </div>
            <div class="modal-body">
                <form action="#" class="modal_form" data-action="crm_change_user_profile_image">
                    <div class="row g-gs">
                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label" for="new_profile_image">انتخاب تصویر</label>
                                <div class="upload-zone" data-target="#new_profile_image"
                                     data-crop="1" data-action="crm_handle_file_upload" data-max-files="1">
                                    <div class="dz-message" data-dz-message>
                                        <span class="dz-message-text">بکشید و رها کنید</span>
                                        <span class="dz-message-or">یا</span>
                                        <div class="btn btn-primary">انتخاب کنید</div>
                                    </div>
                                </div>
                                <input type="hidden" id="new_profile_image" data-for="image" data-req="1">
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="col-12">
                                <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                    <li>
                                        <div class="btn btn-primary submit_modal_form">ثبت تصویر پروفایل</div>
                                    </li>
                                    <li>
                                        <a href="#" class="link link-light btn-trigger" data-bs-dismiss="modal">لغو</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <input type="hidden" data-for="id" value="<?php echo $user_id; ?>">
                        <input type="hidden" value="profile" data-for="tab">
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>