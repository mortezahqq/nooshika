<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
if ( get_current_user_id() != 1 ) {
	echo 'صفحه صندوق در حال به روزرسانی می باشد.';
	
	die();
}
$options       = [
	'ksm_shop_name'     => 'فرستنده',
	'ksm_shop_address'  => 'آدرس',
	'ksm_shop_postcode' => 'کد پستی',
	'ksm_shop_phone'    => 'شماره تماس',
];
$order_id      = $_REQUEST['order_id'];
$order         = wc_get_order( $order_id );
$states        = WC()->countries->get_states( 'IR' );
$cities        = PWS()::cities( $order->get_billing_state() );
$state_label   = 'استان ' . $states[ $order->get_billing_state() ] . '، ';
$city_label    = 'شهر ' . $cities[ $order->get_billing_city() ] . '، ';
$receiver_data = [
	'گیرنده'             => $state_label . $city_label . $order->get_billing_address_1(),
	'نام و نام خانوادگی' => $order->get_formatted_billing_full_name(),
	'کد پستی'            => $order->get_billing_postcode(),
	'شماره تماس'         => $order->get_billing_phone(),
	'تاریخ سفارش'        => $order->get_date_created()->date_i18n( 'Y/m/d' ),
];
$shop_logo     = '/wp-content/uploads/2023/11/cropped-5645641.jpg';
$note_customer = get_post_meta( $order_id, 'customer_note', TRUE );

?>
<html dir="rtl" lang="fa-IR">
<head>
    <title>برچسب پستی - <?= $order_id; ?></title>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, initial-scale=1, shrink-to-fit=no, maximum-scale=1.0, user-scalable=no">
    <link id="roll_styles" rel="stylesheet"
          href="<?php echo KCP_ASSETS_URL; ?>css/factor_post.css?ver=<?php echo time() ?>"/>
    <style type="text/css">

    </style>
</head>
<body class="body" style="margin-top:0;" onload="printInvoice()">
<div class="container" style="">
    <div class="factor_header">
        <div class="factor_logo_container" style="filter: brightness(0);margin-bottom: 10px;">
            <img src="<?= $shop_logo ?>" alt="" class="shop_logo" width="120">
        </div>
    </div>
    <div class="factor_shop_data">
        <div class="data_wrapper">
			<?php
			foreach ( $options as $option => $label ) {
				$value = get_option( $option );
				?>
                <div class="each_post_label_row">
                    <span><?= $label; ?>:</span>
                    <span><strong><?= $value; ?></strong></span>
                </div>
				<?php
			}
			?>
        </div>
    </div>
    <div class="factor_customer_data">
        <div class="data_wrapper">
			<?php
			foreach ( $receiver_data as $label => $value ) {
				?>
                <div class="each_post_label_row">
                    <span><?= $label; ?>:</span>
                    <span><strong><?= $value; ?></strong></span>
                </div>
				<?php
			}
			?>
        </div>
    </div>
	<?php
	if ( $note_customer ) {
		?>
        <div class="factor_customer_data">
            <div class="data_wrapper">
                <div class="each_post_label_row">
                    <span>توضیحات مشتری:</span>
                    <span><strong><?= $note_customer; ?></strong></span>
                </div>
            </div>
        </div>
		<?php
	}
	?>
    <div class="print">
        <a href="#" class="button" onclick="printInvoice()">چاپ این برگه</a>
    </div>
    <script>
        function printInvoice () {
            window.print()
        }
    </script>
</div>
</body>
</html>
