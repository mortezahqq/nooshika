<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

$order_id           = $_REQUEST['order_id'];
$order              = wc_get_order( $order_id );
$user_id            = $order->get_user_id();
$options            = get_option( 'usof_options_Kasebi' );
$img_id             = $options['site_icon'];
$shop_logo          = wp_get_attachment_image_url( $img_id, 'full' );
$shop_title         = get_option( 'ksm_shop_name' );
$payment_extra_data = $order->get_meta( '_ksm_order_payment_extra_data', TRUE );
$payment_extra_data = $payment_extra_data ?: [];
$payments_list      = $order->get_meta( '_ksm_order_payments_data', TRUE );
$cash_list          = $order->get_meta( '_ksm_order_cash_payments_data', TRUE );
$cash_list          = $cash_list ?: [];
$payments_list      = $payments_list ?: [];
$payments_list      = $order->get_meta( '_ksm_order_payments_data', TRUE );
$payments_list      = $payments_list ?: [];
$total_check_amount = array_map( function( $payment ) {
	return $payment['check_amount'];
}, $payments_list );
$total_check_amount = array_sum( $total_check_amount );
$total_cash_amount  = array_map( function( $payment ) {
	return $payment['amount'];
}, $cash_list );
$total_cash_amount  = array_sum( $total_cash_amount );
$order_total        = $order->get_total();
$remaining_total    = $order_total - $total_check_amount - $total_cash_amount;
$fin_date           = $order->get_meta( '_ksm_order_fin_date', TRUE );

?>
<html dir="rtl" lang="fa-IR">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="ThemeMarch">
    <title>فاکتور شماره <?= $order_id; ?> - <?= $shop_title; ?></title>
    <link rel="stylesheet" href="<?php echo KCP_ASSETS_URL; ?>css/factor.css?ver=<?php echo time(); ?>"/>
</head>
<body>
<div class="cs-container">
    <div class="cs-invoice cs-style1 tm-software">
        <div class="cs-invoice_in" id="download_section">
            <div class="print_page_body content-block">
                <div class="display-flex cs-mb10 space-between cs-f12">
                    <div class="cs-invoice_left">
                        <b class="cs-primary_color">اطلاعات خریدار:</b>
                        <p>
							<?php echo $order->get_formatted_billing_full_name(); ?>
                            <br>
							<?php echo get_user_meta( $user_id, 'national_id', TRUE ); ?>
                        </p>
                    </div>
                    <div class="cs-invoice_right">
                        <p class="cs-primary_color cs-mb3 cs-semi_bold">اطلاعات فروشنده:</p>
                        <p class="cs-lh-165">
							<?php echo get_option( 'ksm_shop_name' ); ?>
                            <br>
							<?php echo get_option( 'ksm_shop_address' ); ?>
                        </p>
                    </div>
                </div>
                <div class="display-flex cs-mb20 space-between">
                    <div class="cs-invoice">
						<?php
						$cash_list = $order->get_meta( '_ksm_order_cash_payments_data', TRUE );
						if ( $cash_list ) {
							foreach ( $cash_list as $cash_item ) {
								?>
                                <div class="cs-mb10">
                                    واریز مبلغ
                                    <strong><?php echo number_format( $cash_item['amount'] ); ?></strong> تومان
                                    به حساب <strong><?php echo $cash_item['bank']; ?></strong>
                                    در تاریخ
                                    <strong><?php echo date_i18n( 'j F Y', strtotime( $cash_item['date'] ) ); ?></strong>
                                    انجام شد.
                                </div>
								<?php
							}
						}
						?>
                    </div>
                </div>
                <div class="cs-table cs-style2 tm-border-none cs-mb30 padding-right-left">
                    <div class="tm-border-1px"></div>
                    <div class="tm-border-none">
                        <div class="cs-table_responsive tm-custom-td-padding">
                            <table class="cs-mb30 cs-f13">
                                <thead class="border-bottom-1 cs-mb50">
                                <tr class="cs-secondary_color">
                                    <th class="row_item_counter">#</th>
                                    <th>سریال چک</th>
                                    <th>سررسید</th>
                                    <th>بانک</th>
                                    <th>شعبه</th>
                                    <th>جاری</th>
                                    <th>صاحب حساب</th>
                                    <th>شماره ملی</th>
                                    <th class="cs-width_2 cs-normal cs-text_right">مبلغ<span class="cs-f10 cs-normal">
                                            (تومان)</span></th>
                                </tr>
                                </thead>
                                <tbody>
								<?php
								foreach ( $payments_list as $key => $payment ) {
									?>
                                    <tr>
                                        <td class="row_item_counter"><?php echo esc_html( $key + 1 ); ?></td>
                                        <td><?php echo esc_html( $payment['check_serial'] ); ?></td>
                                        <td><?php echo date_i18n( 'Y-m-d', strtotime( $payment['check_expire'] ) ); ?></td>
                                        <td><?php echo esc_html( $payment['bank_name'] ); ?></td>
                                        <td><?php echo esc_html( $payment['branch_name'] ); ?></td>
                                        <td><?php echo esc_html( $payment['current_account'] ); ?></td>
                                        <td><?php echo esc_html( $payment['account_owner'] ); ?></td>
                                        <td><?php echo esc_html( $payment['national_code'] ); ?></td>
                                        <td><?php echo number_format( $payment['check_amount'] ); ?></td>
                                    </tr>
									<?php
								}
								$beyane_total = 0;
								/*foreach ( $order->get_fees() as $order_fee ) {
									$name = $order_fee->get_name();
									if ( $name == 'پیش پرداخت' ) {
										continue;
									}
									$beyane_total = $order_fee->get_total();
									?>
                                    <tr class="first_row small_row">
                                        <td colspan="7"></td>
                                        <td class="cs-primary_color">
											<?php echo $name ?>
                                        </td>
                                        <td colspan="1"><?php echo number_format( abs( $beyane_total ) ); ?></td>
                                    </tr>
									<?php
								}*/
								?>
                                <tr class="first_row small_row">
                                    <td colspan="7"></td>
                                    <td class="cs-primary_color">جمع چک دریافتی</td>
                                    <td colspan="1"><?php echo number_format( abs( $total_check_amount ) ); ?></td>
                                </tr>
                                <tr class="small_row">
                                    <td colspan="7"></td>
                                    <td class="cs-primary_color">جمع پرداخت های نقدی</td>
                                    <td colspan="1"><?php echo number_format( abs( $total_cash_amount ) ); ?></td>
                                </tr>
                                <tr class="small_row">
                                    <td colspan="7"></td>
                                    <td class="cs-primary_color">باقی مانده</td>
                                    <td colspan="1"><?php echo number_format( abs( $remaining_total ) ); ?></td>
                                </tr>
                                <tr class="small_row">
                                    <td colspan="7"></td>
                                    <td class="cs-primary_color">جمع کل سفارش</td>
                                    <td colspan="1"><?php echo number_format( $order->get_total() ); ?></td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
				<?php
				if ( ! empty( $payment_extra_data ) ) {
					$count  = $payment_extra_data['payment_plan_month'];
					$amount = $payment_extra_data['payment_plan_amount'];
					?>
                    <div class="display-flex space-between cs-mb40 content-block">
                        <p>
                            مقرر گردید مبلغ
                            <strong><?php echo number_format( $count * $amount ); ?></strong>
                            طی
                            <strong><?php echo $count; ?></strong>
                            قسط، مبلغ هر قسط
                            <strong><?php echo number_format( $amount ); ?></strong>
                            با تاریخ سررسید اولین قسط
                            <strong><?php echo date_i18n( 'j F Y', strtotime( $payment_extra_data['payment_plan_start_date'] ) ); ?></strong>
                            توسط
                            <strong><?php echo $payment_extra_data['payment_user_name']; ?></strong> با کد ملی
                            <strong><?php echo $payment_extra_data['payment_user_nid']; ?></strong>
                            از طرح <strong><?php echo $payment_extra_data['payment_plan_name']; ?></strong> پرداخت شود.
                            <br>
                            شماره معرفی نامه از سازمان طرف
                            قرارداد: <?php echo $payment_extra_data['payment_rec_number']; ?>
                            <br>
                            تاریخ معرفی
                            نامه: <?php echo date_i18n( 'j F Y', strtotime( $payment_extra_data['payment_rec_date'] ) ); ?>
                            <br>
                            ثبت در سامانه بانکی
                            <strong><?php echo $payment_extra_data['payment_recorded_bank']; ?></strong>
                            توسط
                            <strong><?php echo $payment_extra_data['payment_recorded_by']; ?></strong> در
                            تاریخ <?php echo date_i18n( 'j F Y', strtotime( $payment_extra_data['payment_recorded_date'] ) ); ?>
                            صورت پذیرفت
                        </p>
                    </div>
					<?php
				}
				?>
            </div>
            <div class="page_footer content-block">
                <div class="display-flex space-between after_factor_text">
					<?php echo wpautop( get_option( 'after_factor_acc_text' ) ); ?>
                </div>
                <div class="display-flex space-between after_factor_text">
                    <div>
                        کارشناس فروش
                        <br>
						<?php
						$marketer_id = $order->get_meta( 'marketer_id', TRUE );
						echo get_user_name_by_id( $marketer_id );
						?>
                    </div>
                    <div>
                        واحد مالی
                        <br>
						<?php
						$payment_id = $order->get_meta( 'order_status_to_processing', TRUE );
						echo $payment_id ? get_user_name_by_id( $payment_id ) : '-';
						?>
                    </div>
                    <div>
                        خریدار
                        <br>
						<?php echo $order->get_formatted_billing_full_name(); ?>
                        <br>
						<?php echo $order->get_billing_phone(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="<?php echo KCP_ASSETS_URL; ?>js/factor/jquery.min.js"></script>
<script src="<?php echo KCP_ASSETS_URL; ?>js/factor/jspdf.min.js"></script>
<script src="<?php echo KCP_ASSETS_URL; ?>js/factor/html2canvas.min.js"></script>
<script src="<?php echo KCP_ASSETS_URL; ?>js/factor/main.js"></script>
</body>
</html>