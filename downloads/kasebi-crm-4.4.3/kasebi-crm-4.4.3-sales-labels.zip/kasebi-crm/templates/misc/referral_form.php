<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
/**
 * @var $user_id         int
 * @var $referral_amount int
 */
$referrer   = get_user_meta( $user_id, 'kasebi_user_referrer_id', TRUE );
$off_amount = get_option( 'kasebi_referral_amount' );

?>
<div class="col-12 order_referrer_block_card">
    <div class="card h-100">
        <div class="card-inner">
            <div class="row g-gs">
                <div class="col-12 col-md-8">
					<?php
					if ( $referrer ) {
						?>
                        <h6>کاربر معرف:</h6>
						<?php
						echo crm_get_template( 'partials/user-card.php', [
							'user_id'    => $referrer,
							'show_phone' => TRUE,
						] );
					} else {
						?>
                        <div class="row g-gs align-end">
                            <div class="col-12 col-md-8">
                                <div class="form-group card-title">
                                    <label class="form-label" for="referral_code_input">کد معرف</label>
                                    <div class="form-control-wrap">
                                        <div class="form-icon form-icon-left"><em class="icon ni ni-diamond"></em></div>
                                        <input type="text" class="form-control" id="referral_code_input">
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 col-md-4">
                                <div id="set_referral_code_for_user"
                                     data-user-id="<?php echo $user_id; ?>"
                                     class="btn btn-primary">ثبت کد معرف
                                </div>
                            </div>
                        </div>
						<?php
					}
					?>

                </div>
                <div class="col-12 col-md-4">
					<?php
					if ( $referrer ) {
						?>
                        <div
                            class="custom-control custom-control-sm custom-switch <?php echo $referral_amount > 0 ? ' checked' : ''; ?> use_referrer_discount"
                            data-amount="<?php echo $off_amount; ?>">
                            <input type="checkbox" class="custom-control-input" id="use_referrer_discount"
								<?php echo $referral_amount > 0 ? ' checked' : ''; ?>
                                   value="1">
                            <label class="custom-control-label" for="use_referrer_discount">استفاده از تخفیف معرف
                                برای این سفارش
                            </label>
                        </div>
						<?php
					}
					?>
                </div>
            </div>
        </div>
    </div>
</div>
