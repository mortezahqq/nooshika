<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

$order_id    = $_REQUEST['order_id'];
$order       = wc_get_order( $order_id );
$states      = WC()->countries->get_states( 'IR' );
$cities      = PWS()::cities( $order->get_billing_state() );
$state_label = 'استان ' . $states[ $order->get_billing_state() ] . '، ';
$city_label  = 'شهر ' . $cities[ $order->get_billing_city() ];
$payments    = [
	'pay_in_cash' => [
		'title' => 'نقدی',
	],
	'pay_monthly' => [
		'title' => 'قسطی',
	],
];

$options         = get_option( 'usof_options_Kasebi' );
$img_id          = $options['site_icon'];
$shop_logo       = wp_get_attachment_image_url( $img_id, 'full' );
$shop_title      = get_option( 'ksm_shop_name' );
$shipping_cost   = $order->get_shipping_total();
$shipping_method = $order->get_shipping_method();
$user_id         = $order->get_customer_id();

$referral_code = get_user_meta( $user_id, 'kasebi_user_referral_code', TRUE );
if ( ! $referral_code ) {
	$referral_code = substr( md5( $user_id ), 0, 3 );
	$referral_code = 'po' . $referral_code . $user_id;
	update_user_meta( $user_id, 'kasebi_user_referral_code', $referral_code );
}
?>
<html dir="rtl" lang="fa-IR">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="ThemeMarch">
    <title>پیش فاکتور شماره <?= $order_id; ?> - <?= $shop_title; ?></title>
    <link rel="stylesheet" href="<?php echo KCP_ASSETS_URL; ?>css/factor.css?ver=<?php echo time(); ?>"/>
</head>
<body>
<div class="cs-container">
    <div class="print_page_body">
        <div class="display-flex cs-mb10 space-between cs-f12 each_body_block">
            <div class="cs-invoice_left" style="flex-basis:30%">
                <b class="cs-primary_color">اطلاعات خریدار:</b>
                <p>
					<?php echo $order->get_formatted_billing_full_name(); ?>
                    <br>
					<?php echo get_user_meta( $user_id, 'national_id', TRUE ); ?>
                </p>
            </div>
            <div class="factor_title" style="flex-basis:30%;text-align: center">
                پیش فاکتور سفارش
            </div>
            <div class="cs-invoice_right" style="flex-basis:30%">
                <b class="cs-primary_color">اطلاعات ارسال:</b>
                <p>
					<?php echo $state_label . $city_label; ?>
                    <br>
					<?php echo $order->get_billing_address_1(); ?>
                    <br>
					<?php echo $order->get_billing_postcode(); ?>
                </p>
            </div>
        </div>
        <div class="cs-table cs-style2 tm-border-none cs-mb20 padding-right-left">
            <table>
                <thead class="border-bottom-1 product_head each_body_block">
                <tr class="cs-secondary_color">
                    <th class="cs-width_5 cs-normal">کالا</th>
                    <th class="cs-width_1 cs-normal">تعداد</th>
                    <th class="cs-width_1 cs-normal">فی<span class="cs-f10 cs-normal">(تومان)</span>
                    </th>
                    <th class="cs-width_2 cs-normal cs-text_right">جمع کل<span class="cs-f10 cs-normal">
                                            (تومان)</span></th>
                </tr>
                </thead>
                <tbody>
				<?php
				$order_pre_total    = 0;
				$order_pre_subtotal = 0;
				$items_list         = [];
				foreach ( $order->get_items() as $item_id => $item ) {
					$product_id   = $item->get_product_id();
					$variation_id = $item->get_variation_id();
					if ( $variation_id ) {
						$product_id = $variation_id;
					}
					$name          = $item->get_name();
					$qty           = $item->get_quantity();
					$size          = '-';
					$line_total    = $item->get_total();
					$item_subtotal = $item->get_meta( 'line_single_total' ) ?: $item->get_subtotal();
					$width         = $item->get_meta( 'carpet_width' ) ?: 0;
					$length        = $item->get_meta( 'carpet_height' ) ?: 0;
					if ( $width && $length ) {
						$size = $length . ' * ' . $width;
						if ( $qty != 1 ) {
							$qty           = 1;
							$item_subtotal = $item_subtotal * $width * $length;
						}
					} else {
						$taxonomy  = 'pa_size';
						$meta_data = $item->get_all_formatted_meta_data();
						foreach ( $meta_data as $meta ) {
							if ( $meta->key == $taxonomy ) {
								$size = $meta->display_value;
								break;
							}
						}
					}
					
					$order_pre_subtotal += $item->get_subtotal();
					$order_pre_total    += $line_total;
					?>
                    <tr class="product_row each_body_block">
                        <td class="cs-width_5 cs-primary_color cs-f13">
							<?php echo $name ?>
                        </td>
                        <td class="cs-width_1 cs-primary_color cs-f13"><?php echo $qty; ?></td>
                        <td class="cs-width_1 cs-primary_color cs-f13"><?php echo number_format( $item_subtotal );
							?></td>
                        <td class="cs-width_2 cs-text_right cs-primary_color cs-f13"><?php echo number_format( $line_total ); ?></td>
                    </tr>
					<?php
				}
				$total_title        = ( $order_pre_subtotal == $order_pre_total ) ? 'مبلغ کل' : 'مبلغ کل پیش از تخفیف';
				$month_count        = $order->get_meta( 'order_month_count', TRUE );
				$cheque_count       = $order->get_meta( 'order_cheque_count', TRUE );
				$selected_method    = $order->get_meta( 'order_payment_type', TRUE );
				$payment_type       = [
					'pay_in_cash' => [
						'title' => 'نقدی',
					],
					'pay_monthly' => [
						'title' => 'قسطی',
					],
				];
				$payment_type_title = $payment_type[ $selected_method ]['title'];
				if ( $selected_method == 'pay_monthly' ) {
					$payment_type_title .= ' (' . $month_count . ' ماهه)';
					$payment_type_title .= ' - هر ' . $cheque_count . ' ماه یک چک';
				}
				$cashier_note = $order->get_meta( 'cashier_note', TRUE );
				$cash_list    = $order->get_meta( '_ksm_order_cash_payments_data', TRUE );
				?>
                </tbody>
                <tbody class="each_body_block">
                <tr class="cs-secondary_color">
                    <th class="cs-width_5 cs-normal"></th>
                    <th class="cs-width_1 cs-normal"></th>
                    <th class="cs-width_1 cs-normal"></th>
                    <th class="cs-width_2 cs-normal"></th>
                </tr>
                <tr class="first_row ">
                    <td class="cs-width_1 cs-primary_color cs-f13"
                        rowspan="10">
                        <div class="order_extra_data">
                            <div class="order_payment_type">
                                شیوه پرداخت: <strong><?php echo $payment_type_title; ?></strong>
                            </div>
							<?php
							if ( $cash_list ) {
								?>
                                <hr>
                                <strong>پرداخت های نقدی سفارش:</strong>
								<?php
								foreach ( $cash_list as $cash_item ) {
									?>
                                    <div class="order_details">
                                        <div class="cs-mb10">
                                            واریز مبلغ
                                            <strong><?php echo number_format( $cash_item['amount'] ); ?></strong>
                                            به حساب <strong><?php echo $cash_item['bank']; ?></strong>
                                            در تاریخ
                                            <strong><?php echo date_i18n( 'j F Y', strtotime( $cash_item['date'] ) ); ?></strong>
                                            انجام شد.
                                        </div>
                                    </div>
									<?php
								}
							}
							?>
                        </div>
                    </td>
                    <td class="cs-primary_color cs-f13" colspan="2"><?php echo $total_title; ?></td>
                    <td class="cs-width_2 cs-text_right cs-primary_color cs-f13"
                        colspan="1"><?php echo number_format( $order_pre_subtotal ); ?></td>
                </tr>
				<?php
				if ( $order_pre_subtotal != $order_pre_total ) {
					$discount = $order_pre_subtotal - $order_pre_total;
					?>
                    <tr>
                        <td class="cs-primary_color cs-f13" colspan="2">تخفیف کالاها</td>
                        <td class="cs-width_2 cs-text_right cs-primary_color cs-f13"
                            colspan="1">-<?php echo number_format( $discount ); ?>
                        </td>
                    </tr>
                    <tr>
                        <td class="cs-primary_color cs-f13" colspan="2">جمع کل کالاها</td>
                        <td class="cs-width_2 cs-text_right cs-primary_color cs-f13"
                            colspan="1"><?php echo number_format( $order_pre_total ); ?>
                        </td>
                    </tr>
					<?php
				}
				foreach ( $order->get_fees() as $order_fee ) {
					$name  = $order_fee->get_name();
					$total = $order_fee->get_total();
					if ( $name == 'تفاوت مدت' ) {
						$payment       = $order->get_meta( 'order_payment_type', TRUE );
						$payment_title = $payments[ $payment ]['title'];
						$percent       = $order->get_meta( 'order_percentage', TRUE );
						$name          .= ' (' . $payment_title . '-' . $percent . '%)';
					}
					if ( $name == 'تخفیف سفارش' ) {
						$name = 'تخفیف روی کل سفارش';
					}
					?>
                    <tr>
                        <td class="cs-primary_color cs-f13" colspan="3">
							<?php echo $name ?>
                        </td>
                        <td class="cs-width_2 cs-text_right cs-primary_color cs-f13"
                            colspan="1"><?php echo number_format( $total ); ?></td>
                    </tr>
					<?php
					$fee_class = '';
				}
				$cash_list         = $cash_list ?: [];
				$total_cash_amount = array_map( function( $payment ) {
					return $payment['amount'];
				}, $cash_list );
				$total_cash_amount = array_sum( $total_cash_amount );
				if ( $total_cash_amount > 0 ) {
					?>
                    <tr>
                        <td class="cs-primary_color cs-f13" colspan="3">پیش پرداخت</td>
                        <td class="cs-width_2 cs-text_right cs-primary_color cs-f13"
                            colspan="1"><?php echo number_format( $total_cash_amount ); ?></td>
                    </tr>
					<?php
				}
				?>
                </tbody>
            </table>
        </div>
		<?php
		if ( $cashier_note ) {
			?>
            <div class="display-flex space-between cs-mb30 each_body_block cs-f13 text-dark" style="color: #000">
                <div class="order_details">
                    <strong>توضیحات سفارش:</strong>
                    <br>
					<?php echo wpautop( $cashier_note ); ?>
                </div>
            </div>
			<?php
		}
		?>
        <div class="display-flex space-between cs-mb30 each_body_block">
            <div></div>
            <div>
                <p class="cs-secondary_color cs-text_right">مبلغ کل سفارش</p>
                <p class="cs-primary_color cs-f18 cs-semi_bold cs-f28">
					<?php
					echo number_format( $order->get_total() );
					?><span class="cs-f18">تومان</span>
                </p>
            </div>
        </div>
    </div>
    <div class="page_footer">
        <div class="display-flex space-between after_factor_text">
        </div>
        <div class="display-flex space-between after_factor_text">
            <div>
                کارشناس فروش
                <br>
				<?php
				$marketer_id = $order->get_meta( 'marketer_id', TRUE );
				echo get_user_name_by_id( $marketer_id );
				?>
            </div>
            <div>
                خریدار
                <br>
				<?php echo $order->get_formatted_billing_full_name(); ?>
                <br>
				<?php echo $order->get_billing_phone(); ?>
                <br>
                کد معرف: <strong><?php echo $referral_code; ?></strong>
            </div>
        </div>
    </div>
</div>
<script src="<?php echo KCP_ASSETS_URL; ?>js/factor/jquery.min.js"></script>
<script>
    (function($) {
        var PAGE_PX = 700;
        
        function trimUntilHeight(el, maxHeightPx) {
            if (!el) {
                return;
            }
            let blocks = el.find('.each_body_block');
            if (!blocks.length) {
                return;
            }
            for (let i = blocks.length - 1; i >= 0; i--) {
                if (el.height() <= maxHeightPx) {
                    break;
                }
                
                blocks[i].remove();
            }
        }
        
        function paginate() {
            var original = $('.cs-container');
            let blocks = original.find('.each_body_block');
            blocks.each(function(index) {
                $(this).attr('data-id', 'block_' + index);
            });
            
            if (!original) {
                return;
            }
            let bodyOriginal = original.find('.print_page_body');
            let bodyHeight = bodyOriginal.height();
            while (bodyHeight > PAGE_PX) {
                let cloneWrapper = original.clone();
                let cloneBody = cloneWrapper.find('.print_page_body');
                $('body').append(cloneWrapper);
                trimUntilHeight(cloneBody, PAGE_PX);
                let clonedRow = cloneBody.find('.each_body_block');
                clonedRow.each(function() {
                    let dataId = $(this).attr('data-id');
                    let mainRow = bodyOriginal.find('.each_body_block[data-id="' + dataId + '"]');
                    mainRow.remove();
                });
                bodyHeight = bodyOriginal.height();
            }
            let cloneWrapper = original.clone();
            let cloneBody = cloneWrapper.find('.print_page_body');
            let clonedRow = cloneBody.find('.each_body_block');
            if ($(clonedRow.get(0)).hasClass('product_row')) {
                cloneBody.find('table').prepend($('.product_head').get(0).outerHTML);
            }
            $('body').append(cloneWrapper);
            original.remove();
        }
        
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', paginate);
        } else {
            paginate();
        }
        
    })(jQuery);
</script>
</body>
</html>