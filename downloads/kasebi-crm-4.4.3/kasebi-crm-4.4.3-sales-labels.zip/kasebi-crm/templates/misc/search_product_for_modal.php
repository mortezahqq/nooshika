<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>
<div class="card card-stretch">
    <div class="card-inner-group">
		<?php
		if ( ! empty( $product_ids ) ) {
			?>
            <div class="card-inner p-0 nk-tb-list">
				<?php
				foreach ( $product_ids as $product_id ) {
					$product = wc_get_product( $product_id );
					if ( ! $product ) {
						continue;
					}
					
					$title = $product->get_name();
					$sku   = $product->get_sku();
					$brand = crm_get_product_brand( $product );
					?>
                    <div class="each_user_search_result_row" data-id="<?php echo esc_attr( $product_id ); ?>">
                        <div class="search_result_title text-dark"><?php echo esc_html( $title ); ?></div>
                        <div class="d-flex">
                            <div class="search_result_sku sub-text">sku:<?php echo $sku ? esc_html( $sku ) : '-';
								?></div>
                            /
                            <div class="search_result_brand sub-text"><?php echo $brand ? esc_html( $brand
								) : '-'; ?></div>
                        </div>
                    </div>
					<?php
				}
				?>
            </div>
			<?php
		} else {
			?>
            <div class="card-inner p-0">
                <div class="is-compact nk-tb-list nk-tb-ulist">
                    <div class="nk-tb-item">
                        <div class="nk-tb-col">
                            <div class="title">محصولی یافت نشد</div>
                        </div>
                    </div>
                </div>
            </div>
			<?php
		}
		?>
    </div>
</div>
