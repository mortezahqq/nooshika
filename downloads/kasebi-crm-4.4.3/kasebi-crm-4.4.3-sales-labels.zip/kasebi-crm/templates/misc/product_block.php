<?php

/**
 * @var int    $product_id
 * @var array  $stocks
 * @var array  $stock
 * @var string $price
 * @var string $reg_price
 * @var string $title
 * @var string $sku
 * @var bool   $custom_size
 * @var bool   $cut_carpet
 */
$cut_carpet = $cut_carpet ?? FALSE;
$off        = $reg_price - $price;
if ( $off == 0 ) {
	$off = '-';
} else {
	$off = number_format( $off );
}
if ( $custom_size ) {
	$price     = $price * 10000;
	$reg_price = $reg_price * 10000;
}

?>
<input type="hidden" id="select_product_sku" value="<?php echo $sku; ?>">
<input type="hidden" id="select_product_id" value="<?php echo $product_id; ?>">
<input type="hidden" id="select_product_title" value="<?php echo $title; ?>">
<input type="hidden" id="select_product_reg_price" value="<?php echo $reg_price; ?>">
<input type="hidden" id="select_product_price" value="<?php echo $price; ?>">
<input type="hidden" id="select_product_off" value="<?php echo $off; ?>">
<input type="hidden" id="is_custom_size" value="<?php echo $custom_size ? '1' : 0; ?>">
<h5 class="product-title"><?php echo $title; ?></h5>
<h5 class="product-price text-primary d-flex align-end">
	<?php
	echo number_format( $price );
	if ( $reg_price != $price ) {
		$reg_price = number_format( $reg_price );
		echo "<small class='text-muted fs-14px ms-1 del'>$reg_price</small>";
	}
	?>
</h5>

<div class="product-meta d-flex mt-2 align-center" style="gap: 30px">
    <ul class="d-flex flex-wrap align-center g-2 pt-1">
        <li class="w-140px stock_spinner">
            <div class="form-control-wrap number-spinner-wrap">
                <button class="btn btn-icon btn-outline-light number-spinner-btn number-minus" data-number="minus">
                    <em class="icon ni ni-minus"></em></button>
                <input type="number" class="form-control number-spinner" value="1">
                <button class="btn btn-icon btn-outline-light number-spinner-btn number-plus" data-number="plus">
                    <em class="icon ni ni-plus"></em></button>
            </div>
        </li>
        <li>
            <button class="btn btn-primary btn-dim add_product_to_factor">افزودن به سفارش</button>
        </li>
    </ul>
</div>
