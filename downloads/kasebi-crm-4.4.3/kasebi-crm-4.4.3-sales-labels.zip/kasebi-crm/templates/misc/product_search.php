<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * @var $product_ids array
 * @var $type        string
 */
?>
    <div class="card card-stretch">
        <div class="card-inner-group">
			<?php
			if ( empty( $product_ids ) ) {
				echo '<div class="alert alert-warning">محصولی پیدا نشد.</div>';
			} else {
				?>
                <div class="card-inner p-0">
                    <div class="is-compact nk-tb-list nk-tb-ulist">
						<?php
						$stock_html        = '';
						$out_of_stock_html = '';
						foreach ( $product_ids as $product_id ) {
							$product = wc_get_product( $product_id );
							if ( $product->get_type() == 'variable' ) {
								continue;
							}
							$size_taxonomy = 'pa_size';
							$child_size    = $product->get_attribute( $size_taxonomy );
							$title         = $product->get_name();
							$main_price    = $product->get_regular_price() ?: 0;
							$main_price    = round( $main_price );
							$price         = $product->get_price() ?: 0;
							$price         = round( $price );
							$stock_status  = $product->get_stock_status();
							$stock         = $product->get_stock_quantity();
							if ( $stock_status == 'instock' ) {
								$stock = 1000;
							}
							$class = ( $stock == 0 ) ? 'each_product_search_result out_of_stock' : 'each_product_search_result';
							if ( $type == 'stock' ) {
								$class = 'each_product_search_result_stock';
							}
							if ( $type == 'eticket' ) {
								$class = 'each_product_search_result_eticket';
							}
							$image = $product->get_image( 'thumbnail' );
							ob_start();
							?>
                            <div class="each_product_search_result_row d-flex align-center"
                                 data-id="<?php echo $product_id; ?>">
                                <div class="product_image w-80px rounded-5 overflow-hidden"><?php echo $image; ?></div>
                                <div class="each_product_search_row product_title"><?= $title; ?></div>
                                <div class="each_product_search_row" hidden="">
									<?= number_format( $price ); ?>
                                    <small>تومان</small>
                                </div>
                            </div>
							<?php
							if ( $stock == 0 ) {
								$out_of_stock_html .= ob_get_clean();
							} else {
								$stock_html .= ob_get_clean();
							}
						}
						echo $stock_html;
						echo $out_of_stock_html;
						?>
                    </div>
                </div>
				<?php
			}
			?>
        </div>
    </div>
<?php
