<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * @var string $page
 */
$page         = $page ?: '';
$pages        = get_crm_pages_list();
$current      = get_crm_end_point( $page );
$current      = $current[0];
$single_pages = get_crm_single_page_list();
if ( isset( $single_pages[ $current ] ) ) {
	$current = $single_pages[ $current ]['parent'];
}
$role      = nooshika_get_user_role( get_current_user_id(), TRUE );
$all_roles = kcp_get_all_roles();
?>
<div class="nk-sidebar-element nk-sidebar-head">
    <div class="nk-sidebar-brand">
        <a href="https://kasebi.co/" class="logo-link nk-sidebar-logo" target="_blank">
            <img src="https://kasebi.co/wp-content/uploads/2021/10/kasebi_logo.png" alt="logo"
                 class="logo_kasebi logo-img">
        </a>
    </div>
    <div class="nk-menu-trigger me-n2">
        <a href="#" class="nk-nav-toggle nk-quick-nav-icon d-xl-none" data-target="sidebarMenu"><em
                class="icon ni ni-arrow-left"></em></a>
    </div>
</div>
<div class="nk-sidebar-element">
    <div class="nk-sidebar-content">
        <div class="nk-sidebar-menu" data-simplebar>
            <ul class="nk-menu">
				<?php
				foreach ( $pages as $key => $data ) {
					$data['valid_roles'] = $data['valid_roles'] ?? 'all';
					$valid_roles         = $data['valid_roles'] == 'all' ? $all_roles : $data['valid_roles'];
					if ( ! in_array( $role, $valid_roles ) ) {
						continue;
					}
					$active       = ( $key == $current ) ? ' active' : '';
					$data['icon'] = $data['icon'] ?? 'home';
					$icon         = "icon ni ni-{$data['icon']}";
					if ( $active == ' active' ) {
						$icon = "icon ni ni-{$data['icon']}-fill";
					}
					$title = apply_filters( 'ncp_navbar_title', $data['title'], $key );
					$type  = $data['type'] ?? 'page';
					if ( $type == 'divider' ) {
						?>
                        <li class="nk-menu-heading">
                            <h6 class="overline-title text-primary-alt"><?php echo $title ?></h6>
                        </li>
						<?php
					} elseif ( $type == 'page' ) {
						?>
                        <li class="nk-menu-item<?php echo $active; ?>">
                            <a href="<?php echo home_url(); ?>/crm/<?php echo $key; ?>"
                               class="page_activator nk-menu-link"
                               data-url="/crm/<?php echo $key; ?>">
                                <span class="nk-menu-icon"><em class="<?php echo $icon ?>"></em></span>
                                <span class="nk-menu-text"><?php echo $title; ?></span>
								<?php do_action( 'ncp_navbar_title_after', $key ); ?>
                            </a>
                        </li>
						<?php
					} else {
						$sub_pages = $data['sub'];
						$is_open   = FALSE;
						ob_start();
						?>
                        <ul class="nk-menu-sub">
							<?php
							foreach ( $sub_pages as $sub_key => $sub_data ) {
								$sub_active              = ( $sub_key == $current ) ? ' active' : '';
								$is_open                 = $is_open || ( $sub_key == $current );
								$sub_title               = apply_filters( 'ncp_navbar_title', $sub_data['title'], $sub_key );
								$sub_data['valid_roles'] = $sub_data['valid_roles'] ?? 'all';
								$valid_roles             = $sub_data['valid_roles'] == 'all' ? $all_roles : $sub_data['valid_roles'];
								if ( ! in_array( $role, $valid_roles ) ) {
									continue;
								}
								$type = $sub_data['type'] ?? 'page';
								if ( $type == 'link' ) {
									?>
                                    <li class="nk-menu-item<?php echo $sub_active; ?>">
                                        <a href="<?php echo $sub_data['url']; ?>"
                                           class="nk-menu-link<?php echo $sub_active; ?>" target="_blank">
                                            <span class="nk-menu-text"><?php echo $title; ?></span>
											<?php do_action( 'ncp_navbar_title_after', $key ); ?>
                                        </a>
                                    </li>
									<?php
								} else {
									?>
                                    <li class="nk-menu-item<?php echo $sub_active; ?>">
                                        <a href="<?php echo home_url(); ?>/crm/<?php echo $sub_key; ?>"
                                           class="page_activator nk-menu-link<?php echo $sub_active; ?>"
                                           data-url="/crm/<?php echo $sub_key; ?>">
                                            <span class="nk-menu-text"><?php echo $sub_title; ?></span>
											<?php do_action( 'ncp_navbar_title_after', $key ); ?>
                                        </a>
                                    </li>
									<?php
								}
							}
							?>
                        </ul>
						<?php
						$sub_list = ob_get_clean();
						$active   = $is_open ? ' active' : '';
						?>
                        <li class="nk-menu-item<?php echo $active; ?>">
                            <a href="#" class="nk-menu-link nk-menu-toggle<?php echo $active; ?>">
                                <span class="nk-menu-icon"><em class="<?php echo $icon ?>"></em></span>
                                <span class="nk-menu-text"><?php echo $sub_title; ?></span>
								<?php do_action( 'ncp_navbar_title_after', $key ); ?>
                            </a>
							<?php echo $sub_list; ?>
                        </li>
						<?php
					}
				}
				?>
            </ul>
        </div>
    </div>
</div>

