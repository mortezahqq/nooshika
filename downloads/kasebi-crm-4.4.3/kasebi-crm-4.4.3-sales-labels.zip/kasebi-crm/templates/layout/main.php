<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
/**
 * @var string $page
 */

$valid_roles = kcp_get_all_roles();
$role        = nooshika_get_user_role( get_current_user_id() );

$page = $page ?: '';
?>
<div class="nk-main">
	<?php
	if ( ! in_array( $role, $valid_roles ) ) {
		?>
        <div class="card">
            <div class="card-inner">
                <div class="text-danger text-center">
                    <strong>شما دسترسی لازم برای مشاهده این صفحه را ندارید</strong>
                </div>
            </div>
        </div>
		<?php
	} else {
		?>
        <div class="nk-sidebar nk-sidebar-fixed is-light" data-content="sidebarMenu">
			<?php echo crm_get_template( 'layout/navbar.php', [ 'page' => $page ] ); ?>
        </div>
        <div class="nk-wrap">
			<?php echo crm_get_template( 'layout/header.php' ); ?>
			<?php echo crm_get_template( 'layout/body.php', [ 'page' => $page ] ); ?>
			<?php echo crm_get_template( 'layout/footer.php' ); ?>
        </div>
		<?php
	}
	?>
</div>
