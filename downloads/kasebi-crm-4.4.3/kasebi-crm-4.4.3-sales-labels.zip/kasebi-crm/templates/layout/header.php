<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
$user_id      = get_current_user_id();
$current_skin = get_user_meta( $user_id, 'crm_skin', TRUE ) ?: 'default';

?>
<div class="nk-header nk-header-fixed is-light">
    <div class="container-xl wide-xl">
        <div class="nk-header-wrap">
            <div class="nk-menu-trigger d-xl-none ms-n1 me-3">
                <a href="#" class="nk-nav-toggle nk-quick-nav-icon" data-target="sidebarMenu"><em
                        class="icon ni ni-menu"></em></a>
            </div>
            <div class="nk-header-search">
                <div class="btn btn-icon search-toggle toggle-search" data-target="search">
                    <em class="icon ni ni-search"></em>
                </div>
                <div class="card-search search-wrap" data-search="search">
                    <div class="card-body">
                        <div class="search-content">
                            <a href="#" class="search-back btn btn-icon toggle-search" data-target="search"><em
                                    class="icon ni ni-arrow-left"></em></a>
                            <input type="text" class="form-control border-transparent form-focus-none"
                                   id="header_user_search"
                                   placeholder="جستجو بر اساس نام یا شماره تماس">
                            <button class="search-submit btn btn-icon">
                                <em class="icon ni ni-search"></em>
                            </button>
                        </div>
                    </div>
                    <div class="search_result_container"></div>
                </div>
            </div>
            <div class="nk-header-tools">
                <ul class="nk-quick-nav">
                    <li class="dropdown notification-dropdown">
                        <a class="nk-quick-nav-icon" data-bs-toggle="modal"
                           data-bs-target="#addCustomer">
                            <em class="icon ni ni-plus"></em>
                        </a>
                    </li>
                    <li class="dropdown language-dropdown d-none d-sm-block me-n1">
                        <a href="#" class="dropdown-toggle nk-quick-nav-icon" data-bs-toggle="dropdown">
                            <div class="quick-icon border border-light">
                                <span class="nk-opt-item-bg"><span
                                        class="skin-<?php echo $current_skin; ?>"></span></span>
                            </div>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end">
                            <ul class="language-list">
                                <li>
                                    <a href="#" class="language-item" data-skin="default">
                                        <span class="nk-opt-item-bg"><span class="skin-default"></span></span>
                                        <span class="language-name">پیش‌‎فرض</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" class="language-item" data-skin="green">
                                        <span class="nk-opt-item-bg"><span class="skin-green"></span></span>
                                        <span class="language-name">سبز</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" class="language-item" data-skin="blue">
                                        <span class="nk-opt-item-bg"><span class="skin-egyptian"></span></span>
                                        <span class="language-name">آبی روشن</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" class="language-item" data-skin="egyptian">
                                        <span class="nk-opt-item-bg"><span class="skin-egyptian"></span></span>
                                        <span class="language-name">آبی سیر</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" class="language-item" data-skin="purple">
                                        <span class="nk-opt-item-bg"><span class="skin-purple"></span></span>
                                        <span class="language-name">بنفش</span>
                                    </a>
                                </li>
                                <li>
                                    <a href="#" class="language-item" data-skin="red">
                                        <span class="nk-opt-item-bg"><span class="skin-red"></span></span>
                                        <span class="language-name">قرمز</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </li>
                    <li class="dropdown user-dropdown">
                        <a href="#" class="dropdown-toggle" data-bs-toggle="dropdown">
                            <div class="user-toggle">
                                <div class="user-avatar sm">
                                    <em class="icon ni ni-setting-alt"></em>
                                </div>
                            </div>
                        </a>
                        <div class="dropdown-menu dropdown-menu-md dropdown-menu-end">
                            <div class="dropdown-inner user-card-wrap bg-lighter d-none d-md-block">
                                <div class="user-card">
                                    <div class="user-avatar">
                                        <span><?php echo get_user_name_for_avatar(); ?></span>
                                    </div>
                                    <div class="user-info">
                                        <span class="lead-text"><?php echo get_user_name_by_id(); ?></span>
                                        <span class="sub-text">
                                            <?php
                                            global $wp_roles;
                                            $user_role = nooshika_get_user_role( $user_id );
                                            $role      = $wp_roles->roles[ $user_role ];
                                            echo translate_user_role( $role['name'] );
                                            ?>
                                        </span>
                                    </div>
                                </div>
                            </div>
							<?php
							$admin_id = $_COOKIE['ksm_admin_user_id'] ?? 0;
							if ( $admin_id ) {
								?>
                                <div class="dropdown-inner">
                                    <ul class="link-list">
                                        <li>
                                            <a href="#" class="login_as_this" data-id="<?php echo $admin_id; ?>">
                                                <em class="icon ni ni-chevron-left-c"></em><span>بازگشت به ادمین</span>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
								<?php
							}
							?>
                            <div class="dropdown-inner">
                                <ul class="link-list">
                                    <li>
                                        <a href="<?php echo get_home_url(); ?>/crm-password" target="_blank">
                                            <em class="icon ni ni-lock-alt-fill"></em><span>تغییر رمزعبور</span>
                                        </a>
                                    </li>
                                    <li>
                                        <a class="dark-switch" href="#"><em class="icon ni ni-moon"></em><span>حالت تاریک</span></a>
                                    </li>
                                </ul>
                            </div>
                            <div class="dropdown-inner">
                                <ul class="link-list">
                                    <li>
                                        <a href="<?php echo get_home_url(); ?>/crm?action=logout">
                                            <em class="icon ni ni-signout"></em><span>خروج</span>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
