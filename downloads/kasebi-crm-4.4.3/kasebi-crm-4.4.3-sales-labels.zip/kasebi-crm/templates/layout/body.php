<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
/**
 * @var string $page
 */

$page      = $page ?: '';
$current   = get_crm_end_point( $page );
$current   = $current[0];
$folder    = 'pages';
$sub_pages = get_crm_single_page_list();
if ( isset( $sub_pages[ $current ] ) ) {
	$folder = 'sub_page';
}
?>
<script>
    (function() {
        const cookieName = 'YOUR_COOKIE_NAME'; // اسم کوکی را اینجا بگذار
        const maxRefresh = 1; // چند بار اجازه رفرش داشته باشد
        
        function hasCookie(name) {
            return document.cookie.split(';').
                map(cookie => cookie.trim()).
                some(cookie => cookie.startsWith(name + '='));
        }
        
        const refreshKey = 'cookie_refresh_' + cookieName;
        const refreshCount = parseInt(sessionStorage.getItem(refreshKey) || '0', 10);
        
        if (!hasCookie(cookieName) && refreshCount < maxRefresh) {
            sessionStorage.setItem(refreshKey, refreshCount + 1);
            location.reload();
        }
    })();
</script>
<input type="hidden" id="current_page" value="/crm/<?php echo $current; ?>">
<div class="nk-content nk-content-fluid">
    <div class="container-xl wide-xl">
        <div class="nk-content-body">
			<?php
			
			echo crm_get_template( "$folder/$current.php" );
			?>
        </div>
    </div>
</div>
