<?php
/**
 * @var int $order_id
 */

$order            = wc_get_order( $order_id );
$installment_data = $order->get_meta( '_ksm_order_payment_extra_data' ) ?: [];
$cheque_list      = $order->get_meta( '_ksm_order_payments_data' ) ?: [];
$cash_list        = $order->get_meta( '_ksm_order_cash_payments_data' ) ?: [];
extract( $installment_data );

$organs          = [
	'education'    => 'آموزش و پرورش',
	'oragh'        => 'اوراق گام',
	'tamin'        => 'تأمین اجتماعی',
	'ab'           => 'اداره آب',
	'medical'      => 'علوم پزشکی',
	'armed_forces' => 'نیروهای مسلح',
	'other'        => 'سایر',
];
$total_cheque    = array_map( function( $cheque ) {
	return $cheque['check_amount'];
}, $cheque_list );
$total_cash      = array_map( function( $payment ) {
	return $payment['amount'];
}, $cash_list );
$total_cheque    = array_sum( $total_cheque );
$total_cash      = array_sum( $total_cash );
$order_total     = $order->get_total();
$remaining_total = $order_total - $total_cheque - $total_cash;
if ( ! empty( $installment_data ) ) {
	$count  = (int) $payment_plan_month;
	$amount = (int) $payment_plan_amount;
	?>
    <div class="mb-3">
        <p>
            مقرر گردید مبلغ
            <strong><?php echo number_format( $count * $amount ); ?></strong>
            طی
            <strong><?php echo $count; ?></strong>
            قسط، مبلغ هر قسط
            <strong><?php echo number_format( $amount ); ?></strong>
            با تاریخ سررسید اولین قسط
            <strong><?php echo date_i18n( 'j F Y', strtotime( $payment_plan_start_date ) ); ?></strong>
            توسط
            <strong><?php echo $payment_user_name; ?></strong> با کد ملی
            <strong><?php echo $payment_user_nid; ?></strong>
            از طرح <strong><?php echo $organs[ $payment_plan_name ] ?? $payment_plan_name; ?></strong> پرداخت شود.
            <br>
            شماره معرفی نامه از سازمان طرف
            قرارداد: <?php echo $payment_rec_number; ?>
            <br>
            تاریخ معرفی
            نامه: <?php echo date_i18n( 'j F Y', strtotime( $payment_rec_date ) ); ?>
            <br>
            ثبت در سامانه بانکی
            <strong><?php echo $payment_recorded_bank; ?></strong>
            توسط
            <strong><?php echo $payment_recorded_by; ?></strong> در
            تاریخ <?php echo date_i18n( 'j F Y', strtotime( $payment_recorded_date ) ); ?>
            صورت پذیرفت
        </p>
    </div>
	<?php
} else {
	echo '<div class="no-item-found">تا کنون اطلاعاتی ثبت نشده است.</div>';
}
?>
<div class="row g-gs">
    <div class="col-12">
        <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
            <li>
                <div id="edit_order_installment_data" class="btn btn-primary"
                     data-data_order_id="<?php echo $order_id; ?>"
                     data-name="<?php echo $payment_user_name; ?>"
                     data-national_id="<?php echo $payment_user_nid; ?>"
                     data-organ="<?php echo $payment_plan_name; ?>"
                     data-start_date="<?php echo date_i18n( 'Y-n-d', strtotime( $payment_plan_start_date ) ); ?>"
                     data-month="<?php echo $payment_plan_month; ?>"
                     data-rec_no="<?php echo $payment_rec_number; ?>"
                     data-rec_date="<?php echo date_i18n( 'Y-n-d', strtotime( $payment_rec_date ) ); ?>"
                     data-recorded_bank="<?php echo $payment_recorded_bank; ?>"
                     data-recorded_by="<?php echo $payment_recorded_by; ?>"
                     data-record_date="<?php echo date_i18n( 'Y-n-d', strtotime( $payment_recorded_date ) ); ?>"
                     data-total_amount="<?php echo $remaining_total; ?>"
                     data-bs-dismiss="modal">ویرایش اطلاعات اقساط
                </div>
            </li>
            <li>
                <a href="#" class="link link-light" data-bs-dismiss="modal">لغو</a>
            </li>
        </ul>
    </div>
</div>

