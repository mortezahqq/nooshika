<?php
/**
 * @var int $order_id
 */

$DB          = new kcp_db();
$cheque_list = $DB->get_order_cheques( [ 'order_id' => $order_id, ] );
?>
<div class="nk-block mb-3">
    <div class="nk-tb-list nk-tb-ulist is-compact v-align-top border border-1">
        <div class="nk-tb-item nk-tb-head">
            <div class="nk-tb-col"><span class="sub-text">سریال چک</span></div>
            <div class="nk-tb-col"><span class="sub-text">سررسید</span></div>
            <div class="nk-tb-col"><span class="sub-text">بانک</span></div>
            <div class="nk-tb-col"><span class="sub-text">شعبه</span></div>
            <div class="nk-tb-col"><span class="sub-text">جاری</span></div>
            <div class="nk-tb-col"><span class="sub-text">صاحب حساب</span></div>
            <div class="nk-tb-col"><span class="sub-text">شماره ملی</span></div>
            <div class="nk-tb-col"><span class="sub-text">مبلغ چک</span></div>
            <div class="nk-tb-col nk-tb-col-tools text-end"></div>
        </div>
		<?php
		if ( empty( $cheque_list ) ) {
			echo '<div class="no-item-found">هنوز چکی برای سفارش ثبت نشده است</div>';
		} else {
			foreach ( $cheque_list as $item_key => $cheque_item ) {
				extract( $cheque_item );
				?>
                <div class="nk-tb-item">
                    <div class="nk-tb-col"><?php echo $check_serial; ?></div>
                    <div class="nk-tb-col">
						<?php echo date_i18n( 'j F Y', strtotime( $check_expire ) ); ?>
                    </div>
                    <div class="nk-tb-col"><?php echo $bank_name; ?></div>
                    <div class="nk-tb-col"><?php echo $branch_name; ?></div>
                    <div class="nk-tb-col"><?php echo $current_account; ?></div>
                    <div class="nk-tb-col"><?php echo $account_owner; ?></div>
                    <div class="nk-tb-col"><?php echo $national_code; ?></div>
                    <div class="nk-tb-col"><?php echo number_format( $check_amount ); ?></div>
                    <div class="nk-tb-col nk-tb-col-tools">
                        <ul class="nk-tb-actions gx-2">
                            <li>
								<?php
								$actions = [
									[
										'link'  => '',
										'title' => 'کپی چک',
										'icon'  => 'ni-copy',
										'class' => 'copy_cheque',
										'data'  => [
											'order_id'        => $order_id,
											'check_serial'    => $check_serial,
											'check_expire'    => $check_expire,
											'bank_name'       => $bank_name,
											'branch_name'     => $branch_name,
											'current_account' => $current_account,
											'account_owner'   => $account_owner,
											'national_code'   => $national_code,
											'check_amount'    => $check_amount,
										],
									],
									[
										'link'  => '',
										'title' => 'ویرایش چک',
										'icon'  => 'ni-edit',
										'class' => 'edit_cheque',
										'data'  => [
											'item_key'        => $id,
											'order_id'        => $order_id,
											'check_serial'    => $check_serial,
											'check_expire'    => $check_expire,
											'bank_name'       => $bank_name,
											'branch_name'     => $branch_name,
											'current_account' => $current_account,
											'account_owner'   => $account_owner,
											'national_code'   => $national_code,
											'check_amount'    => $check_amount,
										],
									],
									[
										'link'  => '',
										'title' => 'حذف چک',
										'icon'  => 'ni-trash',
										'class' => 'delete_cheque',
										'data'  => [
											'item_key' => $id,
											'order_id' => $order_id,
										],
									],
								];
								echo crm_get_template( 'partials/row-actions-dropdown.php', [
									'actions' => $actions,
								] );
								?>
                            </li>
                        </ul>
                    </div>
                </div>
				<?php
			}
		}
		?>
    </div>
</div>
<div class="row g-gs">
    <div class="col-12">
        <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
            <li>
                <div href="#addChequeForOrder" class="btn btn-primary"
                     data-bs-target="#addChequeForOrder"
                     data-order="<?php echo $order_id; ?>" data-bs-toggle="modal"> افزودن چک
                </div>
            </li>
            <li>
                <a href="#" class="link link-light" data-bs-dismiss="modal">لغو</a>
            </li>
        </ul>
    </div>
</div>