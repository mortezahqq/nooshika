<?php
/**
 * @var int $order_id
 */

$DB        = new kcp_db();
$cash_list = $DB->get_cash_payments( [ 'order_id' => $order_id, ] );
?>
<div class="nk-block mb-3">
    <div class="nk-tb-list nk-tb-ulist is-compact v-align-top border border-1">
        <div class="nk-tb-item nk-tb-head">
            <div class="nk-tb-col"><span class="sub-text">مبلغ پرداخت</span></div>
            <div class="nk-tb-col"><span class="sub-text">بانک</span></div>
            <div class="nk-tb-col"><span class="sub-text">تاریخ</span></div>
            <div class="nk-tb-col"><span class="sub-text">ثبت کننده</span></div>
            <div class="nk-tb-col nk-tb-col-tools text-end"></div>
        </div>
		<?php
		if ( empty( $cash_list ) ) {
			echo '<div class="no-item-found">پرداخت نقدی برای سفارش ثبت نشده است</div>';
		} else {
			foreach ( $cash_list as $cash_item ) {
				extract( $cash_item );
				?>
                <div class="nk-tb-item">
                    <div class="nk-tb-col"><?php echo number_format( $amount ); ?></div>
                    <div class="nk-tb-col"><?php echo $bank; ?></div>
                    <div class="nk-tb-col">
						<?php echo date_i18n( 'j F Y', strtotime( $date ) ); ?>
                    </div>
                    <div class="nk-tb-col"><?php echo get_user_name_by_id( $user_id ); ?></div>
                    <div class="nk-tb-col nk-tb-col-tools">
                        <ul class="nk-tb-actions gx-2">
                            <li>
								<?php
								$actions = [
									[
										'link'  => '',
										'title' => 'حذف پرداخت',
										'icon'  => 'ni-trash',
										'class' => 'delete_cash',
										'data'  => [
											'item_key' => $id,
											'order_id' => $order_id,
										],
									],
								];
								echo crm_get_template( 'partials/row-actions-dropdown.php', [
									'actions' => $actions,
								] );
								?>
                            </li>
                        </ul>
                    </div>
                </div>
				<?php
			}
		}
		?>
    </div>
</div>
<div class="row g-gs">
    <div class="col-12">
        <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
            <li>
                <div href="#addCashPaymentForOrder" class="btn btn-primary"
                     data-bs-target="#addCashPaymentForOrder"
                     data-order="<?php echo $order_id; ?>" data-bs-toggle="modal"> افزودن پرداخت جدید
                </div>
            </li>
        </ul>
    </div>
</div>