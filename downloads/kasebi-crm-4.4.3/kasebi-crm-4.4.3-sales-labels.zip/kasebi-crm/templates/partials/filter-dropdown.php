<?php
/**
 * @var bool  $has_filter
 * @var array $filter_fields
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$defaults = [
	'has_filter'    => FALSE,
	'filter_fields' => [],
];
$args     = wp_parse_args( $args ?? [], $defaults );
extract( $args );
?>

<div class="dropdown">
    <a href="#" class="btn btn-trigger btn-icon dropdown-toggle" data-bs-toggle="dropdown">
		<?php echo $has_filter ? '<div class="dot dot-primary"></div>' : ''; ?>
        <em class="icon ni ni-filter-alt"></em>
    </a>
    <div class="filter-wg dropdown-menu dropdown-menu-xl dropdown-menu-end filter_form_wrapper">
        <div class="dropdown-head">
            <span class="sub-title dropdown-title">فیلتر</span>
        </div>
        <div class="dropdown-body dropdown-body-rg">
            <div class="row gx-6 gy-3">
				<?php foreach ( $filter_fields as $field ) {
					$type       = $field['type'] ?? 'select';
					$name       = $field['name'] ?? '';
					$value      = $field['value'] ?? '';
					$label      = $field['label'] ?? '';
					$options    = $field['options'] ?? [];
					$class      = $field['class'] ?? '';
					$col        = $field['col'] ?? 12;
					$id         = $field['id'] ?? '';
					$data       = $field['data'] ?? [];
					$id_attr    = $id ? ' id="' . esc_attr( $id ) . '"' : '';
					$data_attrs = '';
					if ( is_array( $data ) && ! empty( $data ) ) {
						foreach ( $data as $data_key => $data_value ) {
							$data_key = str_replace( '_', '-', $data_key );
							
							if ( is_array( $data_value ) ) {
								$data_value = wp_json_encode( $data_value );
							}
							
							$data_attrs .= ' data-' . esc_attr( $data_key ) . '="' . esc_attr( $data_value ) . '"';
						}
					}
					if ( ! is_current_user_admin() ) {
						if ( $name == 'creator' ) {
							continue;
						}
					}
					if ( $type == 'hidden' ) {
						?>
                        <input type="hidden"
							<?php echo $id_attr; ?>
                               class="<?php echo esc_attr( $class ); ?>"
                               data-for="<?php echo esc_attr( $name ); ?>"
							<?php echo $data_attrs; ?>
                               value="<?php echo esc_attr( $value ); ?>">
						<?php
					} else {
						?>
                        <div class="col-<?php echo $col; ?>">
                            <div class="form-group">
                                <label class="overline-title overline-title-alt">
									<?php echo esc_html( $label ); ?>
                                </label>
								<?php
								switch ( $type ) {
									case 'select':
										?>
                                        <select class="form-select js-select2 <?php echo esc_attr( $class ); ?>"
											<?php echo $id_attr; ?>
                                                data-for="<?php echo esc_attr( $name ); ?>"
											<?php echo $data_attrs; ?>>
											<?php
											foreach ( $options as $key => $option_label ) {
												?>
                                                <option
                                                    value="<?php echo esc_attr( $key ); ?>"<?php selected( $key, $value ); ?>>
													<?php echo esc_html( $option_label ); ?>
                                                </option>
												<?php
											}
											?>
                                        </select>
										<?php
										break;
									case 'num-range':
										$from = is_array( $value ) ? ( $value['from'] ?? '' ) : '';
										$to = is_array( $value ) ? ( $value['to'] ?? '' ) : '';
										?>
                                        <div class="form-control-wrap">
                                            <div class="input-group">
                                                <input type="text"
                                                       class="form-control <?php echo esc_attr( $class ); ?> "
                                                       data-for="<?php echo esc_attr( $name ); ?>[from]"
													<?php echo $data_attrs; ?>
                                                       value="<?php echo esc_attr( $from ); ?>"/>
                                                <div class="input-group-addon">تا</div>
                                                <input type="text"
                                                       class="form-control <?php echo esc_attr( $class ); ?>"
                                                       data-for="<?php echo esc_attr( $name ); ?>[to]"
													<?php echo $data_attrs; ?>
                                                       value="<?php echo esc_attr( $to ); ?>"/>
                                            </div>
                                        </div>
										<?php
										break;
									case 'text':
									case 'number':
										?>
                                        <input type="<?php echo esc_attr( $type ); ?>"
                                               class="form-control <?php echo esc_attr( $class ); ?>"
											<?php echo $id_attr; ?>
                                               data-for="<?php echo esc_attr( $name ); ?>"
											<?php echo $data_attrs; ?>
                                               value="<?php echo esc_attr( $value ); ?>">
										<?php
										break;
									case 'date':
										?>
                                        <input type="text"
                                               class="form-control datepicker <?php echo esc_attr( $class ); ?>"
											<?php echo $id_attr; ?>
                                               data-for="<?php echo esc_attr( $name ); ?>"
											<?php echo $data_attrs; ?>
                                               value="<?php echo esc_attr( $value ); ?>">
										<?php
										break;
									
									case 'date-range':
										$from = $value['from'] ?? '';
										$to = $value['to'] ?? '';
										?>
                                        <div class="form-control-wrap">
                                            <div class="input-group">
                                                <input type="text" class="form-control datepicker"
                                                       data-for="<?php echo esc_attr( $name ); ?>[from]"
                                                       value="<?php echo esc_attr( $from ); ?>"/>
                                                <div class="input-group-addon">تا</div>
                                                <input type="text" class="form-control datepicker"
                                                       data-for="<?php echo esc_attr( $name ); ?>[to]"
                                                       value="<?php echo esc_attr( $to ); ?>"/>
                                            </div>
                                        </div>
										<?php
										break;
									
									case 'checkbox':
									case 'radio':
										?>
                                        <div class="g-4 align-center flex-wrap">
											
											<?php
											foreach ( $options as $key => $option_label ) {
												$input_id   = $name . '_' . sanitize_key( $key );
												$is_checked = is_array( $value )
													? in_array( (string) $key, $value )
													: (string) $key === (string) $value;
												?>
                                                <div class="g">
                                                    <div class="custom-control custom-control-sm custom-radio">
                                                        <input type="<?php echo esc_attr( $type ); ?>"
                                                               id="<?php echo esc_attr( $input_id ); ?>"
                                                               name="<?php echo esc_attr( $type === 'checkbox' ? $name . '[]' : $name ); ?>"
                                                               value="<?php echo esc_attr( $key ); ?>"
                                                               class="custom-control-input <?php echo esc_attr( $class ); ?>"
                                                               data-for="<?php echo esc_attr( $name . ( $type === 'checkbox' ? '[]' : '' ) ); ?>"
															<?php checked( $is_checked ); ?>>
                                                        <label class="custom-control-label"
                                                               for="<?php echo esc_attr( $input_id ); ?>">
															<?php echo esc_html( $option_label ); ?>
                                                        </label>
                                                    </div>
                                                </div>
												<?php
											}
											?>
                                        </div>
										<?php
										break;
								}
								?>
                            </div>
                        </div>
						<?php
					}
				}
				?>
                <div class="col-12">
                    <div class="form-group">
                        <button class="btn btn-secondary filter_crm_list">فیلتر</button>
                    </div>
                </div>
            </div>
        </div>
        <div class="dropdown-foot between">
            <a class="reset_page_filter">بازنشانی فیلتر</a>
        </div>
    </div>
</div>
