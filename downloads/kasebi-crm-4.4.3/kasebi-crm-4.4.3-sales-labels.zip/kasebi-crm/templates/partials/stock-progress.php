<?php
/**
 * @var int $item_id
 */
$base_DB = new kcp_db();
$DB      = new kcp_stock();
$steps   = $DB->get_stock_item_steps_list( $item_id );

$step_types = $DB->get_stock_item_step_types();
$metas      = $DB->get_meta( 'item', $item_id );
if ( empty( $steps ) ) {
	echo '<div class="no-item-found">تا کنون اقدامی برای این محصول صورت نگرفته است.</div>';
} else {
	?>
    <div class="bq-note">
		<?php
		foreach ( $steps as $step ) {
			extract( $step );
			$status_badge = $step_types[ $step_type ]['class'];
			$status_label = $step_types[ $step_type ]['label'];
			$step_metas   = $DB->get_meta( 'step', $step_id );
			?>
            <div class="bq-note-item">
                <div class="bq-note-text">
                    <div class="d-flex mb-1 align-center" style="gap: 5px">
                        <span class="sub-text">اقدام صورت گرفته:</span>
                        <span class="badge <?php echo $status_badge; ?>"><?php echo $status_label; ?></span>
						<?php
						if ( $step_type == 're_produce_request' ) {
							$url = home_url() . "/crm/?action=bill&type=produce&item_id=$item_id";
							?>
                            <a href="<?php echo $url; ?>" style="margin-right:auto"
                               target="_blank" class="btn btn-sm btn-icon">
                                <em data-bs-toggle="tooltip" data-bs-placement="top" class="icon ni ni-printer"
                                    title="حواله برگشت از خرید"></em>
                            </a>
							<?php
						} elseif ( $step_type == 'warranty_returned' ) {
							$url = home_url() . "/crm/?action=bill&type=warranty&item_id=$item_id";
							?>
                            <a href="<?php echo $url; ?>" style="margin-right:auto"
                               target="_blank" class="btn btn-sm btn-icon">
                                <em data-bs-toggle="tooltip" data-bs-placement="top" class="icon ni ni-printer"
                                    title="رسید برگشت از فروش"></em>
                            </a>
							<?php
						} elseif ( $step_type == 'bill_of_lading_created' ) {
							$url = home_url() . "/crm/?action=bill&type=send&item_id=$item_id";
							?>
                            <a href="<?php echo $url; ?>" style="margin-right:auto"
                               target="_blank" class="btn btn-sm btn-icon">
                                <em data-bs-toggle='tooltip' data-bs-placement='top' class="icon ni ni-printer"
                                    title="حواله فروش"></em>
                            </a>
							<?php
						}
						?>
                    </div>
					<?php
					echo wpautop( $details );
					if ( ! empty( $step_metas ) ) {
						?>
                        <div class="d-flex mb-1" style="gap: 5px">سایر توضیحات</div>
						<?php
						foreach ( $step_metas as $step_key => $step_meta ) {
							if ( $step_key == 'qcForm' ) {
								$questions = render_qc_form_fields();
								echo '<div class="qc-summary">';
								foreach ( $questions as $q ) {
									$id    = $q['id'];
									$label = $q['label'];
									$type  = $q['type'];
									$raw   = $step_meta[ $id ] ?? '';
									// مقدار قابل نمایش
									$display = '—';
									if ( $raw !== '' ) {
										if ( $type === 'switch' ) {
											$display = ( $raw === '1' || $raw === 'true' || $raw === 'delivery_prepared' || $raw === 'qccheck_approved' ) ? 'بله' : 'خیر';
										} elseif ( ! empty( $q['options'] ) && is_array( $q['options'] ) ) {
											if ( is_array( $raw ) ) {
												$labels = [];
												
												foreach ( $raw as $val ) {
													if ( isset( $q['options'][ $val ] ) ) {
														$labels[] = $q['options'][ $val ];
													} else {
														$labels[] = $val; // fallback
													}
												}
												
												$display = ! empty( $labels )
													? implode( '، ', $labels )
													: '—';
											} else {
												$display = $q['options'][ $raw ] ?? $raw;
											} // برگرداندن لیبل گزینه
										} else {
											$display = $raw;
										}
									}
									
									echo '<div class="d-flex mb-1">'
									     . '<span class="sub-text me-1">' . esc_html( $label ) . ':  </span>'
									     . '<span class="fw-semibold sub-text text-dark">' . esc_html( $display ) . '</span>'
									     . '</div>';
								}
								echo '</div>';
								if ( isset( $step_meta['qc_attachment_link'] ) && $step_meta['qc_attachment_link'] ) {
									$qc_attachment = $step_meta['qc_attachment_link'];
									$file_data     = $base_DB->get_uploaded_file_data( $qc_attachment );
									if ( ! $file_data ) {
										$file_name = basename( $attachment );
									} else {
										$file_name = $file_data['original_name'];
									}
									?>
                                    <div class="attach-files mt-1">
                                        <ul class="attach-list">
                                            <li class="attach-item">
                                                <a class="download file-link" href="<?php echo $attachment; ?>"
                                                   download>
                                                    <em class="icon ni ni-img"></em>
                                                    <span><?php echo $file_name; ?></span>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
									<?php
								}
							} elseif ( $step_key == 'destination' ) {
								$stocks    = $DB->get_warehouse_stocks();
								$step_meta = isset( $stocks[ $step_meta ] ) ? $stocks[ $step_meta ]['label'] : $step_meta;
								echo "<span class='sub-text'>انبار مقصد: $step_meta</span>";
							} else {
								echo "<span class='sub-text'>$step_key: $step_meta</span>";
							}
						}
					}
					?>
                </div>
				<?php
				if ( $attachment ) {
					$file_data = $base_DB->get_uploaded_file_data( $attachment );
					if ( ! $file_data ) {
						$file_name = basename( $attachment );
					} else {
						$file_name = $file_data['original_name'];
					}
					?>
                    <div class="attach-files mt-1">
                        <ul class="attach-list">
                            <li class="attach-item">
                                <a class="download file-link" href="<?php echo $attachment; ?>" download>
                                    <em class="icon ni ni-img"></em>
                                    <span><?php echo $file_name; ?></span>
                                </a>
                            </li>
                        </ul>
                    </div>
					<?php
				}
				?>
                <div class="bq-note-meta">
                        <span class="bq-note-added">
                            اضافه شده در <span
                                class="date"><?php echo date_i18n( 'j F Y', strtotime( $date ) ); ?></span>
                            در <span class="time"><?php echo date_i18n( 'H:i', strtotime( $date ) ); ?></span>
                        </span>
                    <span class="bq-note-sep sep">|</span>
                    <span class="bq-note-by">توسط <span><?php echo get_user_name_by_id( $user_id ); ?></span>
                        </span>
                </div>
            </div>
			<?php
		}
		?>
    </div>
	<?php
}
if ( ! empty( $metas ) ) {
	?>
    <h6 class="d-flex mt-2" style="gap: 5px">سایر توضیحات محصول</h6>
	<?php
	$meta_titles = [
		'order_id'            => 'شناسه سفارش',
		'brand'               => 'برند محصول',
		'package_lading_code' => 'کد مرسوله',
		'production_date'     => 'تاریخ تولید',
	];
	foreach ( $metas as $step_key => $step_meta ) {
		if ( $step_key == 'production_date' ) {
			$step_meta = date_i18n( 'j F Y', strtotime( $step_meta ) );
		}
		$step_key = $meta_titles[ $step_key ] ?? $step_key;
		
		echo "<span class='sub-text'>$step_key : $step_meta</span>";
	}
}