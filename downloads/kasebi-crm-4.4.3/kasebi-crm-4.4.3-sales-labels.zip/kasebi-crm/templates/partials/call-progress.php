<?php
/**
 * @var int $call_id
 */
$DB              = new kcp_db();
$progresses      = $DB->get_call_progress( $call_id );
$call_statuses   = $DB->get_call_statuses();
$call_categories = $DB->get_call_categories();
if ( empty( $progresses ) ) {
	echo '<div class="no-item-found">تا کنون اقدامی برای این درخواست صورت نگرفته است.</div>';
} else {
	?>
    <div class="bq-note">
		<?php
		foreach ( $progresses as $progress ) {
			extract( $progress );
			$status_badge = $call_statuses[ $to_status ]['class'];
			$status_label = $call_statuses[ $to_status ]['label'];
			?>
            <div class="bq-note-item">
                <div class="bq-note-text">
					<?php
					echo wpautop( $comment );
					$attachment    = $DB->get_call_meta( $call_id, "attachment_$id" );
					$assigned_from = $DB->get_call_meta( $call_id, "assigned_from_$id" );
					$assigned_to   = $DB->get_call_meta( $call_id, "assigned_to_$id" );
					$from          = $call_categories[ $from_category ]['label'];
					if ( $progress['to_category'] != $progress['from_category'] ) {
						$to = $call_categories[ $to_category ]['label'];
						?>
                        <div class="sub-text mb-1">
							<?php echo "درخواست از <strong>$from</strong> به <strong>$to</strong> ارجاع داده شد."; ?>
                        </div>
						<?php
					} else {
						?>
                        <div class="sub-text mb-1">
							<?php echo "درخواست در واحد <strong>$from</strong> بررسی شد."; ?>
                        </div>
						<?php
					}
					if ( $assigned_from != $assigned_to && $assigned_to ) {
						$assigned_to   = get_user_name_by_id( $assigned_to );
						$assigned_from = get_user_name_by_id( $assigned_from );
						?>
                        <div class="sub-text mb-1">
							<?php echo "درخواست از <strong>$assigned_from</strong> به <strong>$assigned_to</strong> محول شد."; ?>
                        </div>
						<?php
					}
					?>
                    <div class="d-flex mt-1" style="gap: 5px">
                        <span class="sub-text">تغییر وضعیت به:</span>
                        <span class="badge <?php echo $status_badge; ?>"><?php echo $status_label; ?></span>
                    </div>
                </div>
				<?php
				if ( $attachment ) {
					$file_data = $DB->get_uploaded_file_data( $attachment );
					if ( ! $file_data ) {
						$file_name = basename( $attachment );
					} else {
						$file_name = $file_data['original_name'];
					}
					?>
                    <div class="attach-files mt-1">
                        <ul class="attach-list">
                            <li class="attach-item">
                                <a class="download file-link" href="<?php echo $attachment; ?>" download>
                                    <em class="icon ni ni-img"></em>
                                    <span><?php echo $file_name; ?></span>
                                </a>
                            </li>
                        </ul>
                    </div>
					<?php
				}
				?>
                <div class="bq-note-meta">
                        <span class="bq-note-added">
                            اضافه شده در <span
                                class="date"><?php echo date_i18n( 'j F Y', strtotime( $changed_at ) ); ?></span>
                            در <span class="time"><?php echo date_i18n( 'H:i', strtotime( $changed_at ) ); ?></span>
                        </span>
                    <span class="bq-note-sep sep">|</span>
                    <span class="bq-note-by">توسط <span><?php echo get_user_name_by_id( $changed_by ); ?></span>
                        </span>
                </div>
            </div>
			<?php
		}
		?>
    </div>
	<?php
}
