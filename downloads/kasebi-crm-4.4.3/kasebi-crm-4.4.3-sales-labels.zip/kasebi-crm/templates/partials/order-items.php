<?php
/**
 * @var int $order_id
 */

$order = wc_get_order( $order_id );

if ( ! $order ) {
	return;
}

$items            = $order->get_items();
$installment_data = $order->get_meta( '_ksm_order_payment_extra_data' ) ?: [];
$cheque_list      = $order->get_meta( '_ksm_order_payments_data' ) ?: [];
$cash_list        = $order->get_meta( '_ksm_order_cash_payments_data' ) ?: [];
$fees             = $order->get_items( 'fee' );

$order_total = (float) $order->get_total();

$total_cheque = 0;
if ( is_array( $cheque_list ) ) {
	foreach ( $cheque_list as $cheque ) {
		$total_cheque += isset( $cheque['check_amount'] ) ? (float) $cheque['check_amount'] : 0;
	}
}

$total_cash = 0;
if ( is_array( $cash_list ) ) {
	foreach ( $cash_list as $payment ) {
		$total_cash += isset( $payment['amount'] ) ? (float) $payment['amount'] : 0;
	}
}

$total_installment = 0;
if ( ! empty( $installment_data['payment_plan_month'] ) && ! empty( $installment_data['payment_plan_amount'] ) ) {
	$total_installment = (float) $installment_data['payment_plan_month'] * (float) $installment_data['payment_plan_amount'];
}

$items_total    = 0;
$items_subtotal = 0;
$items_discount = 0;

$format_price = static function( $amount ) {
	return number_format( (float) $amount );
};

$format_qty = static function( $qty ) {
	$qty = (float) $qty;
	
	return rtrim( rtrim( number_format( $qty, 3, '.', '' ), '0' ), '.' );
};
?>

<style>
    .ksm-order-table {
        --ksm-col-title: minmax(240px, 1fr);
        --ksm-col-qty: 110px;
        --ksm-col-price: 140px;
        --ksm-col-discount: 90px;
        --ksm-col-final-price: 150px;
        --ksm-col-total: 160px;
    }
    
    .ksm-order-table .nk-tb-item {
        display: grid;
        grid-template-columns:
            var(--ksm-col-title)
            var(--ksm-col-qty)
            var(--ksm-col-price)
            var(--ksm-col-discount)
            var(--ksm-col-final-price)
            var(--ksm-col-total);
        align-items: center;
    }
    
    .ksm-order-table .nk-tb-col {
        width: auto;
        min-width: 0;
    }
    
    .ksm-order-table .ksm-order-col-total {
        text-align: end;
    }
    
    .ksm-order-table .ksm-order-col-summary-label {
        grid-column: 5;
    }
    
    .ksm-order-table .ksm-order-col-summary-value {
        grid-column: 6;
        text-align: end;
    }
    
    .ksm-order-table .ksm-order-summary-empty {
        display: none;
    }
    
    @media (max-width: 991px) {
        .ksm-order-table {
            overflow-x: auto;
        }
        
        .ksm-order-table .nk-tb-item {
            min-width: 900px;
        }
    }
</style>

<div class="nk-block mb-3">
    <div class="nk-tb-list nk-tb-ulist is-compact v-align-top border border-1 ksm-order-table ksm-order-items-table">

        <div class="nk-tb-item nk-tb-head">
            <div class="nk-tb-col ksm-order-col-title">
                <span class="sub-text">عنوان محصول</span>
            </div>

            <div class="nk-tb-col ksm-order-col-qty">
                <span class="sub-text">مقدار</span>
            </div>

            <div class="nk-tb-col ksm-order-col-price">
                <span class="sub-text">فی</span>
            </div>

            <div class="nk-tb-col ksm-order-col-discount">
                <span class="sub-text">تخفیف</span>
            </div>

            <div class="nk-tb-col ksm-order-col-final-price">
                <span class="sub-text">فی بعد از تخفیف</span>
            </div>

            <div class="nk-tb-col ksm-order-col-total">
                <span class="sub-text">مبلغ کل</span>
            </div>
        </div>
		
		<?php foreach ( $items as $item ) : ?>
			<?php
			$qty = $item->get_meta( 'line_decimal_qty', TRUE );
			
			if ( $qty === '' || $qty === NULL ) {
				$qty = $item->get_quantity();
			}
			
			$qty = (float) $qty;
			
			$line_regular_total = $item->get_meta( 'line_regular_total', TRUE );
			
			if ( $line_regular_total === '' || $line_regular_total === NULL ) {
				$line_regular_total = $item->get_subtotal();
			}
			
			$line_regular_total = (float) $line_regular_total;
			$line_total         = (float) $item->get_total();
			
			$unit_regular_price = $qty > 0 ? $line_regular_total / $qty : 0;
			$unit_final_price   = $qty > 0 ? $line_total / $qty : 0;
			
			$line_discount_total = max( 0, $line_regular_total - $line_total );
			
			$off_percent = $item->get_meta( 'off_percent', TRUE );
			
			if ( $off_percent === '' && $line_regular_total > 0 && $line_discount_total > 0 ) {
				$off_percent = round( ( $line_discount_total / $line_regular_total ) * 100, 2 );
			}
			
			$note = $item->get_meta( 'note', TRUE );
			
			$items_subtotal += $line_regular_total;
			$items_total    += $line_total;
			$items_discount += $line_discount_total;
			?>

            <div class="nk-tb-item text-dark">
                <div class="nk-tb-col ksm-order-col-title">
					<?php echo esc_html( $item->get_name() ); ?>
					
					<?php if ( $note ) : ?>
                        <div class="sub-text">
							<?php echo esc_html( $note ); ?>
                        </div>
					<?php endif; ?>
                </div>

                <div class="nk-tb-col ksm-order-col-qty">
					<?php echo esc_html( $format_qty( $qty ) ); ?>
                </div>

                <div class="nk-tb-col ksm-order-col-price">
					<?php echo esc_html( $format_price( $unit_regular_price ) ); ?>
                </div>

                <div class="nk-tb-col ksm-order-col-discount">
					<?php echo $off_percent !== '' ? esc_html( $off_percent ) : '-'; ?>
                </div>

                <div class="nk-tb-col ksm-order-col-final-price">
					<?php echo esc_html( $format_price( $unit_final_price ) ); ?>
                </div>

                <div class="nk-tb-col ksm-order-col-total">
					<?php echo esc_html( $format_price( $line_total ) ); ?>
                </div>
            </div>
		<?php endforeach; ?>

    </div>
</div>

<div class="nk-block mb-3">
    <div class="table-borderless nk-tb-list nk-tb-ulist is-compact v-align-top ksm-order-table ksm-order-summary-table">

        <div class="nk-tb-item">
            <div class="nk-tb-col ksm-order-summary-empty"></div>
            <div class="nk-tb-col ksm-order-summary-empty"></div>
            <div class="nk-tb-col ksm-order-summary-empty"></div>
            <div class="nk-tb-col ksm-order-summary-empty"></div>

            <div class="nk-tb-col border-bottom-0 ksm-order-col-summary-label">
                جمع کل
            </div>

            <div class="nk-tb-col border-bottom-0 ksm-order-col-summary-value">
				<?php echo esc_html( $format_price( $items_subtotal ) ); ?>
            </div>
        </div>

        <div class="nk-tb-item">
            <div class="nk-tb-col ksm-order-summary-empty"></div>
            <div class="nk-tb-col ksm-order-summary-empty"></div>
            <div class="nk-tb-col ksm-order-summary-empty"></div>
            <div class="nk-tb-col ksm-order-summary-empty"></div>

            <div class="nk-tb-col border-bottom-0 ksm-order-col-summary-label">
                تخفیفات
            </div>

            <div class="nk-tb-col border-bottom-0 ksm-order-col-summary-value">
				<?php echo esc_html( $format_price( $items_discount ) ); ?>
            </div>
        </div>

        <div class="nk-tb-item">
            <div class="nk-tb-col ksm-order-summary-empty"></div>
            <div class="nk-tb-col ksm-order-summary-empty"></div>
            <div class="nk-tb-col ksm-order-summary-empty"></div>
            <div class="nk-tb-col ksm-order-summary-empty"></div>

            <div class="nk-tb-col border-bottom-0 ksm-order-col-summary-label">
                جمع کل کالاها
            </div>

            <div class="nk-tb-col border-bottom-0 ksm-order-col-summary-value">
				<?php echo esc_html( $format_price( $items_total ) ); ?>
            </div>
        </div>
		
		<?php foreach ( $fees as $fee ) : ?>
            <div class="nk-tb-item">
                <div class="nk-tb-col ksm-order-summary-empty"></div>
                <div class="nk-tb-col ksm-order-summary-empty"></div>
                <div class="nk-tb-col ksm-order-summary-empty"></div>
                <div class="nk-tb-col ksm-order-summary-empty"></div>

                <div class="nk-tb-col border-bottom-0 ksm-order-col-summary-label">
					<?php echo esc_html( $fee->get_name() ); ?>
                </div>

                <div class="nk-tb-col border-bottom-0 ksm-order-col-summary-value">
					<?php echo esc_html( $format_price( $fee->get_total() ) ); ?>
                </div>
            </div>
		<?php endforeach; ?>
		
		<?php if ( $total_cash > 0 ) : ?>
            <div class="nk-tb-item">
                <div class="nk-tb-col ksm-order-summary-empty"></div>
                <div class="nk-tb-col ksm-order-summary-empty"></div>
                <div class="nk-tb-col ksm-order-summary-empty"></div>
                <div class="nk-tb-col ksm-order-summary-empty"></div>

                <div class="nk-tb-col border-bottom-0 ksm-order-col-summary-label">
                    پرداخت نقدی
                </div>

                <div class="nk-tb-col border-bottom-0 ksm-order-col-summary-value">
					<?php echo esc_html( $format_price( $total_cash ) ); ?>
                </div>
            </div>
		<?php endif; ?>
		
		<?php
		$payable_total = max( 0, $order_total - $total_cash );
		?>

        <div class="nk-tb-item">
            <div class="nk-tb-col ksm-order-summary-empty"></div>
            <div class="nk-tb-col ksm-order-summary-empty"></div>
            <div class="nk-tb-col ksm-order-summary-empty"></div>
            <div class="nk-tb-col ksm-order-summary-empty"></div>

            <div class="nk-tb-col border-bottom-0 border-top-1 border-top ksm-order-col-summary-label">
                مبلغ قابل پرداخت
            </div>

            <div class="nk-tb-col border-bottom-0 border-top-1 border-top ksm-order-col-summary-value">
				<?php echo esc_html( $format_price( $payable_total ) ); ?>
            </div>
        </div>

    </div>
</div>