<?php
/**
 * @var int $process_id
 */
$DB         = new kcp_db();
$progresses = $DB->get_stock_process_steps( $process_id );
$step_types = $DB->get_stock_step_types();
$statuses   = $DB->get_stock_process_statuses();

if ( empty( $progresses ) ) {
	echo '<div class="no-item-found">تا کنون اقدامی برای این فرآیند صورت نگرفته است.</div>';
} else {
	?>
    <div class="bq-note">
		<?php
		foreach ( $progresses as $progress ) {
			extract( $progress );
			$step_badge = $step_types[ $step_type ]['class'];
			$step_label = $step_types[ $step_type ]['label'];
			?>
            <div class="bq-note-item">
                <div class="bq-note-text">
					<?php
					echo wpautop( $details );
					$from = $statuses[ $from_status ]['label'];
					if ( $progress['from_status'] != $progress['to_status'] ) {
						$to = $statuses[ $to_status ]['label'];
						?>
                        <div class="sub-text mb-1">
							<?php echo "فرآیند از <strong>$from</strong> به <strong>$to</strong> تغییر وضعیت داده شد
							."; ?>
                        </div>
						<?php
					} else {
						?>
                        <div class="sub-text mb-1">
							<?php echo "فرآیند در وضعیت  <strong>$from</strong> به روزرسانی شد."; ?>
                        </div>
						<?php
					}
					?>
                    <div class="d-flex mt-1" style="gap: 5px">
                        <span class="sub-text">نوع اقدام:</span>
                        <span class="badge <?php echo $step_badge; ?>"><?php echo $step_label; ?></span>
                    </div>
                </div>
				<?php
				if ( $attachment ) {
					$file_data = $DB->get_uploaded_file_data( $attachment );
					if ( ! $file_data ) {
						$file_name = basename( $attachment );
					} else {
						$file_name = $file_data['original_name'];
					}
					?>
                    <div class="attach-files mt-1">
                        <ul class="attach-list">
                            <li class="attach-item">
                                <a class="download file-link" href="<?php echo $attachment; ?>" download>
                                    <em class="icon ni ni-img"></em>
                                    <span><?php echo $file_name; ?></span>
                                </a>
                            </li>
                        </ul>
                    </div>
					<?php
				}
				?>
                <div class="bq-note-meta">
                        <span class="bq-note-added">
                            ثبت شده در <span
                                class="date"><?php echo date_i18n( 'j F Y', strtotime( $date ) ); ?></span>
                            در <span class="time"><?php echo date_i18n( 'H:i', strtotime( $date ) ); ?></span>
                        </span>
                    <span class="bq-note-sep sep">|</span>
                    <span class="bq-note-by">توسط <span><?php echo get_user_name_by_id( $user_id ); ?></span>
                        </span>
                </div>
            </div>
			<?php
		}
		?>
    </div>
	<?php
}
