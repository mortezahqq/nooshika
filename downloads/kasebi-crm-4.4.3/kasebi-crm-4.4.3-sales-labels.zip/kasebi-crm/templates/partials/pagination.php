<?php

/**
 * @var int    $max_page_num
 * @var int    $current_page
 * @var string $class_name
 * @var int    $show_count
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$defaults = [
	'max_page_num' => 1,
	'current_page' => 1,
	'class_name'   => '',
	'show_count'   => 2,
];

$args = wp_parse_args( $args ?? [], $defaults );

extract( $args );

if ( $max_page_num <= 1 ) {
	return '';
}
?>
<ul class="pagination justify-content-center">
	<?php
	if ( $max_page_num < 5 ) {
		for ( $i = 1; $i <= $max_page_num; $i ++ ) {
			$class = $i == $current_page ? ' active' : '';
			?>
            <li class="page-item <?php echo esc_attr( $class_name . $class ); ?>"
                data-page="<?php echo esc_attr( $i ); ?>">
                <a class="page-link" href=""><?php echo esc_html( $i ); ?></a>
            </li>
			<?php
		}
	} else {
		$dots = TRUE;
		for ( $n = 1; $n <= $max_page_num; $n ++ ) {
			$class = $n == $current_page ? ' active' : '';
			if ( $n == 1 || ( $n >= $current_page - $show_count && $n <= $current_page + $show_count ) || $n == $max_page_num ) {
				?>
                <li class="page-item <?php echo esc_attr( $class_name . $class ); ?>"
                    data-page="<?php echo esc_attr( $n ); ?>">
                    <a class="page-link" href=""><?php echo esc_html( $n ); ?></a>
                </li>
				<?php
				$dots = TRUE;
			} else {
				if ( $dots ) {
					?>
                    <li class="page-item">
                        <span class="page-link"><em class="icon ni ni-more-h"></em></span>
                    </li>
					<?php
					$dots = FALSE;
				}
			}
		}
	}
	?>
</ul>
