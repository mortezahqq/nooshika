<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
/**
 * @var $user_id
 */

$user_color = get_user_meta( $user_id, 'user_color', TRUE ) ?: 'primary';
$first_name = get_user_meta( $user_id, 'first_name', TRUE );
$last_name  = get_user_meta( $user_id, 'last_name', TRUE );
$gender     = get_user_meta( $user_id, 'gender', TRUE );

?>
<div class="card-inner">
    <div class="user-card user-card-s2">
        <div class="user-avatar fs-38px lg bg-<?php echo $user_color; ?>">
			<?php
			if ( $gender == 'female' ) {
				echo '<i class="uik-r fa-woman-head"></i>';
			} else {
				echo '<i class="uik-r fa-smile"></i>';
			}
			?>
        </div>
        <div class="user-info">
            <h5><?php echo $first_name . ' ' . $last_name; ?></h5>
        </div>
    </div>
</div>
<div class="card-inner card-inner-sm">
    <ul class="btn-toolbar justify-center gx-1">
        <li>
            <a class="btn btn-icon icon bg-success-dim login_as_this" data-id="<?php echo $user_id; ?>"
               data-bs-toggle="tooltip"
               data-bs-placement="top" title="ورود به عنوان کارمند">
                <em class="icon ni ni-signin"></em>
            </a>
        </li>
    </ul>
</div>
<div class="card-inner">
    <div class="row text-center">
        <div class="col-4">
            <div class="profile-stats">
                <span class="amount"><?php echo 0; ?></span>
                <span class="sub-text">ویزیت های انجام شده</span>
            </div>
        </div>
        <div class="col-4">
            <div class="profile-stats">
                <span class="amount"><?php echo 0; ?></span>
                <span class="sub-text">سفارشات تکمیل شده</span>
            </div>
        </div>
        <div class="col-4">
            <div class="profile-stats">
                <span class="amount"><?php echo 0; ?></span>
                <span class="sub-text">سفارشات لغوشده</span>
            </div>
        </div>
    </div>
</div>
