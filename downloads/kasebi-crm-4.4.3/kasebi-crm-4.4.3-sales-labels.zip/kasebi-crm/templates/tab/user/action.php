<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * @var $user_id
 */
$DB       = new kcp_db();
$per_page = 500;
$actions  = $DB->get_user_actions( compact( 'per_page', 'user_id' ) );
$types    = $DB->get_activity_types();
$actions  = $actions['result'];
?>
<div class="nk-block nk-block-between">
    <div class="nk-block-head">
        <h6 class="title">فعالیت ها</h6>
        <p>گزارش فعالیت های کارشناسان و مشتری</p>
    </div>
    <div class="nk-block">
        <a href="#addAction" class="select_current_user_for_modal btn btn-icon btn-primary" data-bs-target="#addAction"
           data-input="#new_action_customer_id" data-id="<?php echo $user_id; ?>"
           data-bs-toggle="modal"><em class="icon ni ni-plus"></em></a>
    </div>
</div>
<div class="nk-block">
    <div class="card">
        <div class="nk-tb-list nk-tb-ulist is-compact v-align-top">
            <div class="nk-tb-item nk-tb-head">
                <div class="nk-tb-col tb-col-md"><span class="sub-text">تاریخ</span></div>
                <div class="nk-tb-col tb-col-md"><span class="sub-text">عنوان فعالیت</span></div>
                <div class="nk-tb-col ps-3 ps-md-2"><span class="sub-text">محتوای فعالیت</span></div>
                <div class="nk-tb-col tb-col-md"><span class="sub-text">ثبت کننده</span></div>
                <div class="nk-tb-col text-end"></div>
            </div>
			<?php
			
			if ( empty( $actions ) ) {
				echo '<div class="no-item-found">فعالیتی یافت نشد</div>';
			} else {
				foreach ( $actions as $action ) {
					extract( $action );
					$attachment        = $DB->get_actions_meta( $item_id, 'attachment' );
					$type              = $DB->get_actions_meta( $item_id, 'type' );
					$creator           = get_user_name_by_id( $creator );
					$report_content_id = wp_unique_id( 'report_content_' );
					?>
                    <div class="nk-tb-item">
                        <div class="nk-tb-col tb-col-md">
                                    <span class="sub-text">
                                        <?php echo date_i18n( 'j F Y', strtotime( $date ) ); ?></span>
                        </div>
                        <div class="nk-tb-col tb-col-md">
                            <span><?php echo $title; ?></span>
                        </div>
                        <div class="nk-tb-col ps-3 ps-md-2">
                            <div class="w-max-250px w-250px fs-12px nk-news-text atlas-report-modal-trigger"
                                 data-bs-toggle="modal"
                                 data-bs-target="#atlasReportContentModal"
                                 data-content-target="#<?php echo esc_attr( $report_content_id ); ?>"
                                 style="cursor:pointer;">
                                <p><?php echo esc_html( wp_strip_all_tags( $content ) ); ?></p>
                            </div>
                        </div>
                        <div id="<?php echo esc_attr( $report_content_id ); ?>" class="d-none">
							<?php echo wpautop( ( $content ) ); ?>
                        </div>
                        <div class="nk-tb-col tb-col-md">
                            <span><?php echo $creator; ?></span>
                        </div>
                        <div class="nk-tb-col">
                            <ul class="nk-tb-actions gx-2">
								<?php
								$hidden_actions = [
									'edit'   => [
										'link'  => '',
										'title' => 'ویرایش فعالیت',
										'icon'  => 'ni-edit',
										'class' => 'edit_item select_current_user_for_modal',
										'data'  => [
											'modal'   => 'addAction',
											'input'   => '#new_action_customer_id',
											'id'      => $user_id,
											'item_id' => $item_id,
											'title'   => $title,
											'type'    => $type,
											'content' => $content,
											'file'    => $attachment,
										],
									],
									'delete' => [
										'link'  => '',
										'title' => 'حذف فعالیت',
										'icon'  => 'ni-trash',
										'class' => 'delete_db_item',
										'data'  => [
											'action'  => 'crm_delete_action',
											'item_id' => $item_id,
											'tab'     => 'action',
											'page'    => 'crm/user',
										],
									],
								];
								
								if ( ! is_current_user_admin() ) {
									unset( $hidden_actions['delete'] );
								}
								if ( $attachment ) {
									array_unshift( $hidden_actions, [
										'link'     => $attachment,
										'title'    => 'فایل ضمیمه',
										'icon'     => 'ni-download',
										'download' => TRUE,
									] );
								}
								echo crm_get_template( 'partials/row-actions-hidden.php', [
									'actions' => $hidden_actions,
								] );
								?>
                            </ul>
                        </div>
                    </div>
					<?php
				}
			}
			?>
        </div>
    </div>
</div>

<div class="modal fade" id="atlasReportContentModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title">محتوای فعالیت</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="بستن"></button>
            </div>

            <div class="modal-body atlas-report-modal-body"></div>

        </div>
    </div>
</div>