<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * @var $user_id
 */

$DB              = new kcp_db();
$per_page        = 500;
$calls           = $DB->get_calls( compact( 'per_page', 'user_id' ) );
$calls           = $calls['result'];
$call_statuses   = $DB->get_call_statuses();
$call_categories = $DB->get_call_categories();
?>
<div class="nk-block nk-block-between">
    <div class="nk-block-head">
        <h6 class="title">درخواست ها</h6>
        <p>گزارش درخواست های مشتری</p>
    </div>
    <div class="nk-block">
        <a href="#addCall" class="select_current_user_for_modal btn btn-icon btn-primary" data-bs-target="#addCall"
           data-input="#add_call_user_id" data-id="<?php echo $user_id; ?>"
           data-bs-toggle="modal"><em class="icon ni ni-plus"></em></a>
    </div>
</div>
<div class="nk-block">
    <div class="card">
        <div class="nk-tb-list nk-tb-ulist is-compact v-align-top">
            <div class="nk-tb-item nk-tb-head">
                <div class="nk-tb-col tb-col-md w-120px"><span class="sub-text">تاریخ</span></div>
                <div class="nk-tb-col tb-col-md w-120px"><span class="sub-text">وضعیت</span></div>
                <div class="nk-tb-col tb-col-md"><span class="sub-text">واحد ارجاع</span></div>
                <div class="nk-tb-col tb-col-md"><span class="sub-text">مسئول انجام</span></div>
                <div class="nk-tb-col ps-3 ps-md-2"><span class="sub-text">توضیحات</span></div>
                <div class="nk-tb-col nk-tb-col-tools text-end"></div>
            </div>
			<?php
			if ( empty( $calls ) ) {
				echo '<div class="no-item-found">درخواستی یافت نشد</div>';
			} else {
				foreach ( $calls as $call ) {
					extract( $call );
					$creator           = get_user_name_by_id( $creator_id );
					$status_badge      = $call_statuses[ $status ]['class'];
					$status_label      = $call_statuses[ $status ]['label'];
					$attachment        = $DB->get_call_meta( $id, 'attachment' );
					$assigned_to       = $DB->get_call_meta( $id, 'assigned_to' );
					$assigned_to       = $assigned_to ? get_user_name_by_id( $assigned_to ) : '-';
					$report_content_id = wp_unique_id( 'report_content_' );
					?>
                    <div class="nk-tb-item">
                        <div class="nk-tb-col tb-col-md">
                                    <span class="sub-text">
                                        <?php echo date_i18n( 'j F Y', strtotime( $created_at ) ); ?></span>
                        </div>
                        <div class="nk-tb-col tb-col-md">
                            <span class="badge <?php echo $status_badge; ?>"><?php echo $status_label; ?></span>
                        </div>
                        <div class="nk-tb-col tb-col-md">
							<?php echo $call_categories[ $category ]['label']; ?>
                        </div>
                        <div class="nk-tb-col tb-col-md">
							<?php echo $assigned_to; ?>
                        </div>
                        <div class="nk-tb-col ps-3 ps-md-2">
                            <div class="w-max-250px w-250px fs-12px nk-news-text atlas-report-modal-trigger"
                                 data-bs-toggle="modal"
                                 data-bs-target="#atlasReportContentModal"
                                 data-content-target="#<?php echo esc_attr( $report_content_id ); ?>"
                                 style="cursor:pointer;">
                                <p><?php echo esc_html( wp_strip_all_tags( $content ) ); ?></p>
                            </div>
                        </div>
                        <div id="<?php echo esc_attr( $report_content_id ); ?>" class="d-none">
							<?php echo wpautop( ( $content ) ); ?>
                        </div>
                        <div class="nk-tb-col nk-tb-col-tools">
                            <ul class="nk-tb-actions gx-2">
								<?php
								$hidden_actions = [
									[
										'link'  => '',
										'title' => $creator,
										'icon'  => 'ni-user-check',
									],
								];
								if ( $attachment ) {
									array_unshift( $hidden_actions, [
										'link'     => $attachment,
										'title'    => 'فایل ضمیمه',
										'icon'     => 'ni-download',
										'download' => TRUE,
									] );
								}
								echo crm_get_template( 'partials/row-actions-hidden.php', [
									'actions' => $hidden_actions,
								] );
								?>
                                <li>
									<?php
									$actions = [
										[
											'link'  => '',
											'title' => 'تغییر وضعیت',
											'icon'  => 'ni-repeat',
											'class' => 'change_call_status',
											'data'  => [
												'item-id' => $id,
											],
										],
										[
											'link'  => '',
											'title' => 'اقدامات صورت گرفته',
											'icon'  => 'ni-list-thumb-alt',
											'class' => 'view_call_progress',
											'data'  => [
												'item-id' => $id,
											],
										],
										'delete' => [
											'link'  => '',
											'title' => 'حذف درخواست',
											'icon'  => 'ni-trash',
											'class' => 'delete_call',
											'data'  => [
												'item-id' => $id,
											],
										],
									];
									
									if ( ! is_current_user_admin() ) {
										unset( $actions['delete'] );
									}
									echo crm_get_template( 'partials/row-actions-dropdown.php', [
										'actions' => $actions,
									] );
									?>
                                </li>
                            </ul>
                        </div>
                    </div>
					<?php
				}
			}
			?>
        </div>
    </div>

</div>

<div class="modal fade" id="atlasReportContentModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title">محتوای درخواست </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="بستن"></button>
            </div>

            <div class="modal-body atlas-report-modal-body"></div>

        </div>
    </div>
</div>
