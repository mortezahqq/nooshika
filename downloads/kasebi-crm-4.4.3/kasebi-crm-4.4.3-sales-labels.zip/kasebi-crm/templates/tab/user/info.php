<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
/**
 * @var $user_id
 */

$kcp_db     = new kcp_db();
$user_color = get_user_meta( $user_id, 'user_color', TRUE ) ?: 'primary';
$first_name = get_user_meta( $user_id, 'first_name', TRUE );
$last_name  = get_user_meta( $user_id, 'last_name', TRUE );
$phone      = get_user_meta( $user_id, 'nooshika_phone_num', TRUE );

$total_order   = get_user_meta( $user_id, 'user_total_order_count', TRUE );
$total_spend   = get_user_meta( $user_id, 'user_total_order', TRUE );
$phone         = $phone ? '0' . $phone : '';
$registered    = get_the_author_meta( 'registered', $user_id );
$registered    = date_i18n( 'j M Y, H:i', strtotime( $registered ) + 12600 );
$balance       = woo_wallet()->wallet->get_wallet_balance( $user_id, 'edit' );
$referral_code = get_user_meta( $user_id, 'kasebi_user_referral_code', TRUE );
if ( ! $referral_code ) {
	$referral_code = substr( md5( $user_id ), 0, 3 );
	$referral_code = 'po' . $referral_code . $user_id;
	update_user_meta( $user_id, 'kasebi_user_referral_code', $referral_code );
}
?>
<div class="card-inner">
    <div class="user-card user-card-s2">
        <div class="avatar_section">
            <div class="w-80px rounded-circle overflow-hidden">
                <img src="<?php echo nooshika_get_user_avatar( $user_id ); ?>" class="user_avatar">
            </div>
        </div>
        <div class="user-info">
			<?php
			if ( $total_spend ) {
				$user_level  = ncp_get_user_level_by_total( $total_spend );
				$total_spend = convert_number_to_text( $total_spend );
				?>
                <span class="badge mb-1 <?php echo $user_level['badge']; ?>"><?php
					echo $user_level['label']; ?></span>
                <span
                    class="small sub-text fs-10px"><?php echo $total_spend . " ($total_order سفارش)";
					?></span>
				<?php
			} else {
				echo '-';
			}
			?>
            <h5><?php echo $first_name . ' ' . $last_name; ?></h5>
            <span class="sub-text"><?php echo $phone; ?></span>
        </div>
    </div>
</div>
<div class="card-inner card-inner-sm">
    <ul class="btn-toolbar justify-center gx-1">
        <li>
            <div data-bs-toggle="modal" data-bs-target="#crop">
                <a class="btn btn-icon icon bg-purple-dim"
                   data-bs-toggle="tooltip"
                   data-bs-placement="top" title="تنظیم پروفایل">
                    <em class="icon ni ni-user-check-fill"></em>
                </a>
            </div>
        </li>
        <li>
            <div class="toggle" data-target="addOrder">
                <a class="btn btn-icon icon bg-teal-dim page_activator"
                   href="<?php echo home_url( '/crm/order-new/?c_id=' . $user_id ); ?>"
                   data-url="<?php echo '/crm/order-new/?c_id=' . $user_id; ?>"
                   target="_blank" data-bs-placement="top" title="ایجاد سفارش" data-bs-toggle="tooltip">
                    <em class="icon ni ni-plus-medi"></em>
                </a>
            </div>
        </li>
        <li>
            <div data-bs-toggle="modal"
                 data-bs-target="#sendSMS">
                <a class="btn btn-icon icon bg-info-dim"
                   data-bs-toggle="tooltip"
                   data-bs-placement="top" title="ارسال پیامک">
                    <em class="icon ni ni-mail"></em>
                </a>
            </div>
        </li>
        <li>
            <div data-bs-toggle="modal"
                 data-bs-target="#addNewUserNote">
                <a class="btn btn-icon icon bg-purple-dim"
                   data-bs-toggle="tooltip"
                   data-bs-placement="top" title="افزودن یادداشت">
                    <em class="icon ni ni-property"></em>
                </a>
            </div>
        </li>
        <li>
            <a class="btn btn-icon icon bg-pink-dim delete_user" data-user-id="<?php echo $user_id; ?>"
               data-bs-toggle="tooltip"
               data-bs-placement="top" title="حذف مشتری">
                <em class="icon ni ni-na"></em>
            </a>
        </li>
    </ul>
</div>
<div class="card-inner">
    <div class="row text-center">
        <div class="col-6">
            <div class="profile-stats">
                <span class="amount"><?php echo $total_spend; ?></span>
                <span class="sub-text">مجموع پرداختی ها</span>
            </div>
        </div>
        <div class="col-6">
            <div class="profile-stats">
                <span class="amount"><?php echo number_format( $balance ); ?></span>
                <span class="sub-text">موجودی کیف پول</span>
            </div>
        </div>

    </div>
</div>
<div class="card-inner">
    <div class="row g-3">
        <div class="col-6">
            <span class="sub-text">تاریخ عضویت</span>
            <span><?php echo $registered; ?></span>
        </div>
        <div class="col-6">
            <span class="sub-text">کد معرف:</span>
            <span><?php echo $referral_code; ?></span>
        </div>
    </div>
</div>