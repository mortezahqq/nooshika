<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * @var $user_id
 */
$metas      = get_user_meta_keys();
unset( $metas['creator_id'] );
echo crm_get_template( 'partials/customer-assignment.php', [ 'user_id' => $user_id ] );
$taxonomies = [
	'kcp_user_groups' => 'دسته بندی مشتری',
	'kcp_user_types'  => 'تگ مشتری',
];
?>
<div class="nk-block nk-block-between">
    <div class="nk-block-head">
        <h6 class="title">اطلاعات شخصی</h6>
        <p>اطلاعات شخصی مشتری</p>
    </div>
    <div class="nk-block">
        <a class="btn btn-white btn-icon btn-outline-light" data-bs-toggle="modal" href="#editPersonal">
            <em class="icon ni ni-edit"></em>
        </a>
    </div>
</div>
<div class="nk-block">
    <div class="profile-ud-list">
		<?php
		foreach ( $metas as $key => $meta ) {
			if ( ! kcp_meta_is_visible( $meta, $user_id ) ) {
				continue;
			}
			
			$label = $meta['label'] ?? $key;
			$type  = $meta['type'] ?? 'text';
			$value = get_user_meta( $user_id, $key, TRUE );
			
			if ( $type === 'select' && isset( $meta['options'] ) && is_array( $meta['options'] ) ) {
				if ( is_array( $value ) ) {
					$mapped = array_map( function( $v ) use ( $meta ) {
						return $meta['options'][ $v ]['label'] ?? $v;
					}, $value );
					$value  = implode( '، ', $mapped );
				} elseif ( isset( $meta['options'][ $value ]['label'] ) ) {
					$value = $meta['options'][ $value ]['label'];
				}
			}
			if ( $type === 'date' && ! empty( $value ) ) {
				$ts    = is_numeric( $value ) ? (int) $value : strtotime( (string) $value );
				$value = $ts ? date_i18n( 'Y/m/d', $ts ) : $value;
			}
			if ( empty( $value ) && $value !== '0' ) {
				$value = '-';
			}
			$style = ( ! empty( $meta['width'] ) ) ? ' style="width:' . esc_attr( $meta['width'] ) . ';"' : '';
			?>
            <div class="profile-ud-item" <?php echo $style; ?>>
                <div class="profile-ud wider">
                    <span class="profile-ud-label"><?php echo esc_html( $label ); ?></span>
                    <span
                        class="profile-ud-value"><?php echo is_string( $value ) ? esc_html( $value ) : esc_html( (string) $value ); ?></span>
                </div>
            </div>
			<?php
		}
		?>
    </div>
</div>
<div class="nk-block mb-2">
    <div class="nk-block-head nk-block-head-line">
        <h6 class="title text-base">اطلاعات تکمیلی</h6>
    </div>
    <div class="profile-ud-list">
		<?php
		foreach ( $taxonomies as $taxonomy => $label ) {
			$items = get_option( $taxonomy, [] );
			$terms = get_user_meta( $user_id, $taxonomy, TRUE );
			?>
            <div class="profile-ud-item">
                <div class="profile-ud wider">
                    <span class="profile-ud-label"><?php echo $label; ?></span>
                    <ul class="g-1 profile-ud-value">
						<?php
						if ( ! empty( $terms ) ) {
							foreach ( $terms as $slug ) {
								$term = $items[ $slug ];
								?>
                                <li class="btn-group">
                                    <span class="badge bg-info"><?php echo $term['label']; ?></span>
                                </li>
								<?php
							}
						} else {
							echo '-';
						}
						?>
                    </ul>
                </div>
            </div>
			<?php
		}
		?>
    </div>
</div>
<div class="nk-divider divider md"></div>
<div class="nk-block">
    <div class="nk-block-head nk-block-head-sm nk-block-between">
        <h5 class="title">آدرس های مشتری</h5>
        <a id="open_addUserAddress" class="link link-sm" data-id="<?php echo $user_id; ?>">+ افزودن آدرس</a>
    </div>
    <div class="card-inner address_wrapper">
		<?php
		$addresses = get_user_meta( $user_id, 'address_list', TRUE );
		$addresses = kasebi_unminified_string( $addresses );
		$addresses = $addresses ?: [];
		if ( empty( $addresses ) ) {
			echo 'هیچ آدرسی برای نمایش وجود ندارد.';
		} else {
			echo crm_get_template( "misc/addresses.php", [
				'addresses' => $addresses,
				'user_id'   => $user_id,
			] );
		}
		?>
    </div>
</div>
<div class="nk-divider divider md"></div>
<div class="nk-block">
    <div class="nk-block-head nk-block-head-sm nk-block-between">
        <h5 class="title">موقعیت مکانی کاربر</h5>
        <a class="save_user_location link link-sm" data-id="<?php echo $user_id; ?>">ذخیره موقعیت</a>
    </div>
	<?php
	kasebi_render_user_location_field( $user_id );
	?>
</div>
<div class="nk-divider divider md"></div>
<div class="nk-block">
    <div class="nk-block-head nk-block-head-sm nk-block-between">
        <h5 class="title">یادداشت کارشناسان</h5>
        <a data-bs-toggle="modal"
           data-bs-target="#addNewUserNote" class="link link-sm">+ افزودن یادداشت</a>
    </div>
    <div class="bq-note">
		<?php
		$notes = get_user_meta( $user_id, 'crm_user_notes', TRUE ) ?: [];
		if ( empty( $notes ) ) {
			echo 'هیچ یادداشتی برای نمایش وجود ندارد.';
		} else {
			foreach ( $notes as $note_key => $note ) {
				extract( $note );
				?>
                <div class="bq-note-item">
                    <div class="bq-note-text">
						<?php echo wpautop( $desc ); ?>
                    </div>
                    <div class="bq-note-meta">
                        <span class="bq-note-added">
                            اضافه شده در <span
                                class="date"><?php echo date_i18n( 'j F Y', strtotime( $date ) ); ?></span>
                            در <span class="time"><?php echo date_i18n( 'H:i', strtotime( $date ) ); ?></span>
                        </span>
                        <span class="bq-note-sep sep">|</span>
                        <span class="bq-note-by">توسط <span><?php echo get_user_name_by_id( $creator ); ?></span>
                        </span>
                        <div class="link link-sm delete_db_item link-danger"
                             data-action="crm_delete_user_note"
                             data-key="<?php echo esc_attr( $note_key ); ?>"
                             data-id="<?php echo esc_attr( $user_id ?? 0 ); ?>"
                             data-tab="profile"
                             data-page="/crm/user">
                            حذف یادداشت
                        </div>
                    </div>
                </div>
				<?php
			}
		}
		?>
    </div>
</div>
<div class="modal fade" tabindex="-1" role="dialog" id="editPersonal">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
            <div class="modal-body modal-body-md">
                <h5 class="modal-title">به روز رسانی اطلاعات مشتری</h5>
                <form action="#" class="mt-4">
                    <div class="row g-gs">
						<?php
						foreach ( $metas as $key => $meta ) {
							$value = get_user_meta( $user_id, $key, TRUE );
							$type  = $meta['type'] ?? 'text';
							$label = $meta['label'] ?? $key;
							$width = ( isset( $meta['width'] ) && $meta['width'] == '100%' ) ? 12 : 6;
							$id    = 'edit_' . $key;
							
							$is_conditional = ( ! empty( $meta['state'] ) && $meta['state'] === 'conditional' );
							$cond_meta      = $meta['conditions']['meta'] ?? '';
							$cond_value     = $meta['conditions']['value'] ?? '';
							$cond_operator  = $meta['conditions']['operator'] ?? '==';
							
							$expected_json = wp_json_encode( $cond_value );
							
							$visible     = kcp_meta_is_visible( $meta, $user_id );
							$row_classes = 'col-md-' . (int) $width . ' meta-field-row';
							if ( ! $visible ) {
								$row_classes .= ' d-none';
							}
							?>
                            <div class="<?php echo esc_attr( $row_classes ); ?>"
                                 data-meta-key="<?php echo esc_attr( $key ); ?>"
                                 data-conditional="<?php echo $is_conditional ? '1' : '0'; ?>"
                                 data-cond-meta="<?php echo esc_attr( $cond_meta ); ?>"
                                 data-cond-expected='<?php echo esc_attr( $expected_json ); ?>'
                                 data-cond-operator="<?php echo esc_attr( $cond_operator ); ?>">
                                <div class="form-group">
                                    <label class="form-label"
                                           for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $label ); ?></label>
                                    <div class="form-control-wrap">
										<?php
										if ( $type === 'textarea' ) {
											?>
                                            <textarea class="form-control"
                                                      id="<?php echo esc_attr( $id ); ?>"
                                                      data-for="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $value ); ?></textarea>
											<?php
										} elseif ( $type === 'select' && ! empty( $meta['options'] ) ) {
											?>
                                            <select class="form-select js-select2"
                                                    id="<?php echo esc_attr( $id ); ?>"
                                                    data-for="<?php echo esc_attr( $key ); ?>">
												<?php foreach ( $meta['options'] as $option_value => $option_data ) :
													$option_label = $option_data['label'] ?? (string) $option_value;
													$selected = selected( $value, (string) $option_value, FALSE );
													?>
                                                    <option
                                                        value="<?php echo esc_attr( $option_value ); ?>" <?php echo $selected; ?>>
														<?php echo esc_html( $option_label ); ?>
                                                    </option>
												<?php endforeach; ?>
                                            </select>
											<?php
										} elseif ( $type === 'date' ) {
											if ( ! empty( $value ) ) {
												$value = date_i18n( 'Y-m-d', strtotime( $value ) );
											}
											?>
                                            <div class="form-icon form-icon-right">
                                                <em class="icon ni ni-calendar"></em>
                                            </div>
                                            <input type="text" class="form-control datepicker"
                                                   id="<?php echo $id; ?>"
                                                   data-for="<?php echo $key; ?>"
                                                   placeholder="روز-ماه-سال"
                                                   value="<?php echo $value; ?>"/>
											<?php
										} else {
											?>
                                            <input type="<?php echo $type; ?>" class="form-control"
                                                   id="<?php echo $id; ?>"
                                                   data-for="<?php echo $key; ?>"
                                                   value="<?php echo $value; ?>"/>
											<?php
										}
										?>
                                    </div>
                                </div>
                            </div>
							<?php
						}
						?>
						<?php
						foreach ( $taxonomies as $taxonomy => $label ) {
							$items = get_option( $taxonomy, [] );
							$terms = get_user_meta( $user_id, $taxonomy, TRUE ) ?: [];
							?>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label" for="<?php echo $taxonomy; ?>">
										<?php echo $label; ?>
                                    </label>
                                    <div class="form-control-wrap">
                                        <select class="form-select js-select2"
                                                data-for="<?php echo $taxonomy; ?>"
                                                id="<?php echo $taxonomy; ?>"
                                                data-placeholder="گروه را انتخاب کنید" multiple>
                                            <option value="">انتخاب کنید</option>
											<?php
											foreach ( $items as $slug => $item ) {
												$selected = in_array( $slug, $terms ) ? 'selected' : '';
												?>
                                                <option
                                                    value="<?php echo $slug; ?>" <?php echo $selected; ?>><?php echo
													$item['label']; ?></option>
												<?php
											}
											?>
                                        </select>
                                    </div>
                                </div>
                            </div>
							<?php
						}
						?>
                        <div class="col-12">
                            <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                <li>
                                    <div id="update_user_personal_data" class="btn btn-primary"
                                         data-bs-dismiss="modal">به روز رسانی
                                    </div>
                                </li>
                                <li>
                                    <a href="#" class="link link-light" data-bs-dismiss="modal">لغو</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
