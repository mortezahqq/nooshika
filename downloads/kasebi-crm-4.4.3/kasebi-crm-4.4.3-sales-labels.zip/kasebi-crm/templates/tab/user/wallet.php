<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * @var $user_id
 */

$balance      = woo_wallet()->wallet->get_wallet_balance( $user_id );
$args         = array(
	'user_id' => $user_id,
);
$transactions = get_wallet_transactions( $args );
?>
<div class="nk-block nk-block-between">
    <div class="nk-block-head">
        <h6 class="title">اطلاعات کیف پول</h6>
        <p>تراکنش های کیف پول مشتری</p>
    </div>
    <div class="nk-block">
        <a class="btn btn-primary btn-icon" data-bs-toggle="modal" href="#addWalletTr">
            <em class="icon ni ni-plus"></em>
        </a>
    </div>
</div>
<div class="nk-block">
	<?php
	if ( empty( $transactions ) ) {
		echo '<div class="no_massages">تراکنشی برای نمایش وجود ندارد.</div>';
	} else {
		?>
        <div class="card">
            <div class="nk-tb-list nk-tb-ulist is-compact">
                <div class="nk-tb-item nk-tb-head">
                    <div class="nk-tb-col"><span class="sub-text">تاریخ</span></div>
                    <div class="nk-tb-col"><span class="sub-text">مبلغ (تومان)</span></div>
                    <div class="nk-tb-col"><span class="sub-text">توضیحات</span></div>
                </div>
				<?php
				foreach ( $transactions as $transaction ) {
					$icon    = $transaction->type == "credit" ? 'ni-arrow-long-up' : 'ni-arrow-long-down';
					$class   = $transaction->type == "credit" ? 'text-success' : 'text-danger';
					$date    = date_i18n( 'j F Y H:i', strtotime( $transaction->date ) );
					$details = $transaction->details;
					$amount  = number_format( $transaction->amount );
					?>
                    <div class="nk-tb-item">
                        <div class="nk-tb-col">
                            <span><?php echo $date; ?></span>
                        </div>
                        <div class="nk-tb-col <?php echo $class; ?>">
                            <div class="btn-group">
                                <span><?php echo $amount; ?></span>
                                <em class="icon ni <?php echo $icon; ?>"></em>
                            </div>
                        </div>
                        <div class="nk-tb-col">
							<?php echo wpautop( $details ); ?>
                        </div>
                    </div>
					<?php
				}
				?>
            </div>
        </div>
		<?php
	}
	?>
</div>
<div class="modal fade" tabindex="-1" role="dialog" id="addWalletTr">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
            <div class="modal-body modal-body-md">
                <h5 class="modal-title">ثبت تراکنش کیف پول</h5>
                <form action="#" class="mt-4">
                    <div class="row g-gs">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="transaction_amount">مقدار(تومان)</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control price_input" id="transaction_amount">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="transaction_type">نوع تراکنش</label>
                                <div class="form-control-wrap">
                                    <select class="form-select js-select2 select2-hidden-accessible"
                                            id="transaction_type">
                                        <option value="credit">افزایش</option>
                                        <option value="debit">کاهش</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label">توضیحات</label>
                                <div class="form-control-wrap">
                                    <div class="quill-basic" data-name="transaction_description">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                <li>
                                    <div id="add_wallet_transactions" class="btn btn-primary"
                                         data-bs-dismiss="modal">ثبت تراکنش
                                    </div>
                                </li>
                                <li>
                                    <a href="#" class="link link-light" data-bs-dismiss="modal">لغو</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
