<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * @var $user_id
 */

$DB           = new kcp_db();
$per_page     = 500;
$tracks       = $DB->get_user_tracks( compact( 'per_page', 'user_id' ) );
$tracks       = $tracks['result'];
$track_type   = $DB->get_track_types();
$track_status = $DB->get_track_status();
$track_titles = $DB->track_title;
?>
<div class="nk-block nk-block-between">
    <div class="nk-block-head">
        <h6 class="title">پیگیری ها</h6>
        <p>گزارش پیگیری های ثبت شده برای مشتری</p>
    </div>
    <div class="nk-block">
        <a href="#addTrack" class="select_current_user_for_modal btn btn-icon btn-primary" data-bs-target="#addTrack"
           data-input="#new_track_customer_id" data-id="<?php echo $user_id; ?>"
           data-bs-toggle="modal"><em class="icon ni ni-plus"></em></a>
    </div>
</div>
<div class="nk-block">
    <div class="card">
        <div class="nk-tb-list nk-tb-ulist is-compact v-align-top">
            <div class="nk-tb-item nk-tb-head">
                <div class="nk-tb-col tb-col-md"><span class="sub-text">تاریخ</span></div>
                <div class="nk-tb-col tb-col-md"><span class="sub-text">نوع پیگیری</span></div>
                <div class="nk-tb-col tb-col-md"><span class="sub-text">عنوان</span></div>
                <div class="nk-tb-col tb-col-md"><span class="sub-text">وضعیت</span></div>
                <div class="nk-tb-col tb-col-md text-center"><span class="sub-text">زمان پیگیری</span></div>
                <div class="nk-tb-col ps-3 ps-md-2"><span class="sub-text">توضیحات</span></div>
                <div class="nk-tb-col nk-tb-col-tools text-end"></div>
            </div>
			<?php
			if ( empty( $tracks ) ) {
				echo '<div class="no-item-found">پیگیری یافت نشد</div>';
			} else {
				foreach ( $tracks as $track ) {
					extract( $track );
					$status_badge      = $track_status[ $status ]['class'];
					$status_label      = $track_status[ $status ]['label'];
					$creator           = get_user_name_by_id( $creator );
					$report_content_id = wp_unique_id( 'report_content_' );
					?>
                    <div class="nk-tb-item">
                        <div class="nk-tb-col tb-col-md">
                            <span><?php echo date_i18n( 'j F Y', strtotime( $date ) ); ?></span>
                        </div>
                        <div class="nk-tb-col tb-col-md">
                            <a class="btn btn-sm btn-icon btn-trigger" data-bs-toggle="tooltip"
                               data-bs-placement="top"
                               title="<?php echo $track_type[ $type ]['label']; ?>">
                                <em class="icon ni ni-<?php echo $track_type[ $type ]['icon']; ?>"></em>
                            </a>
                        </div>
                        <div class="nk-tb-col tb-col-md">
                            <span><?php echo $track_titles[ $title ]; ?></span>
                        </div>
						<?php
						if ( $status == 'pending' ) {
							?>
                            <div class="nk-tb-col tb-col-md">
                                <div class="badge <?php echo $status_badge; ?>"><?php echo $status_label; ?></div>
                            </div>
							<?php
						} else {
							?>
                            <div class="nk-tb-col tb-col-md">
                                <div class="badge <?php echo $status_badge; ?>"
                                     data-bs-toggle="popover"
                                     data-bs-trigger="click"
                                     data-bs-html="true"
                                     title="<?php echo date_i18n( 'j F Y', strtotime( $checked_date ) ); ?>"
                                     data-bs-content="<?php echo $check_result; ?>"
                                     data-bs-placement="top"><?php echo $status_label; ?></div>
                            </div>
							<?php
						}
						?>

                        <div class="nk-tb-col text-center tb-col-md">
                            <span><?php echo date_i18n( 'j F Y', strtotime( $track_date ) ); ?></span>
                            <span class="sub-text"><?php echo $track_hour ?></span>
                        </div>
                        <div class="nk-tb-col ps-3 ps-md-2">
                            <div class="w-max-250px fs-12px nk-news-text atlas-report-modal-trigger"
                                 data-bs-toggle="modal"
                                 data-bs-target="#atlasReportContentModal"
                                 data-content-target="#<?php echo esc_attr( $report_content_id ); ?>"
                                 style="cursor:pointer;">
                                <p><?php echo esc_html( wp_strip_all_tags( $content ) ); ?></p>
                            </div>
                        </div>
                        <div id="<?php echo esc_attr( $report_content_id ); ?>" class="d-none">
							<?php echo wpautop( ( $content ) ); ?>
                        </div>
                        <div class="nk-tb-col nk-tb-col-tools">
                            <ul class="nk-tb-actions gx-2">
								<?php
								$hidden_actions = [
									[
										'link'  => '',
										'title' => $creator,
										'icon'  => 'ni-user-check',
									],
									'delete' => [
										'link'  => '',
										'title' => 'حذف پیگیری',
										'icon'  => 'ni-trash',
										'class' => 'delete_db_item',
										'data'  => [
											'action'  => 'crm_delete_track',
											'item_id' => $item_id,
											'tab'     => 'track',
											'page'    => '/crm/user',
										],
									],
								];
								if ( $status == 'pending' ) {
									array_unshift( $hidden_actions, [
										'link'  => '',
										'title' => 'ثبت نتیجه',
										'icon'  => 'ni-check-thick',
										'class' => 'submit_track_check',
										'data'  => [
											'item-id' => $item_id,
										],
									] );
								}
								
								if ( ! is_current_user_admin() ) {
									unset( $hidden_actions['delete'] );
								}
								echo crm_get_template( 'partials/row-actions-hidden.php', [
									'actions' => $hidden_actions,
								] );
								?>
                            </ul>
                        </div>
                    </div>
					<?php
				}
			}
			?>
        </div>
    </div>
</div>
<div class="modal fade" id="atlasReportContentModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="modal-title">محتوای پیگیری </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="بستن"></button>
            </div>

            <div class="modal-body atlas-report-modal-body"></div>

        </div>
    </div>
</div>
