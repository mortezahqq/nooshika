<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * @var $user_id
 */

$args     = [
	'customer_id' => $user_id,
	'return'      => 'ids',
	'status'      => 'any',
	'limit'       => - 1,
];
$statuses = wc_get_order_statuses();
$orders   = wc_get_orders( $args );
$states   = WC()->countries->get_states( 'IR' );

$badges = [
	'pending'          => 'warning',
	// پیش فاکتور
	'factor'           => 'info',
	// فاکتورشده
	'confirming'       => 'indigo',
	// تایید فروش
	'processing'       => 'purple',
	// تایید مالی
	'confirmed'        => 'success',
	// تایید سفارش
	'stock-delivery'   => 'indigo',
	// تحویل به انبار
	'completed'        => 'success',
	// ارسال بار
	'delivered'        => 'teal',
	// تحویل کالا
	'cancelled'        => 'danger',
	// لغو شده
	'refund-submitted' => 'orange',
	// ثبت استرداد
	'refund-confirm'   => 'blue',
	// تایید استرداد
	'refund-paid'      => 'success',
	// پرداخت استرداد
	'refund-delivered' => 'info',
	// تحویل استرداد
	'refund-cancelled' => 'dark',
	// لغو استرداد
];
$DB     = new kcp_db();
?>
<div class="nk-block nk-block-between">
    <div class="nk-block-head">
        <h6 class="title">لیست سفارشات</h6>
        <p>تمامی سفارشات ثبت شده مشتری</p>
    </div>
    <div class="nk-block">
        <div class="toggle" data-target="addOrder">
            <a class="btn btn-icon icon bg-teal-dim page_activator"
               href="<?php echo home_url( '/crm/order-new/?c_id=' . $user_id ); ?>"
               data-url="<?php echo '/crm/order-new/?c_id=' . $user_id; ?>"
               target="_blank" data-bs-placement="top" title="ایجاد سفارش" data-bs-toggle="tooltip">
                <em class="icon ni ni-plus-medi"></em>
            </a>
        </div>
    </div>
</div>
<div class="nk-block">
	<?php
	if ( empty( $orders ) ) {
		echo '<div class="no_massages">سفارشی برای نمایش وجود ندارد.</div>';
	} else {
		?>
        <div class="card">
            <div class="nk-tb-list nk-tb-ulist is-compact">
                <div class="nk-tb-item nk-tb-head">
                    <div class="nk-tb-col"><span class="sub-text">#</span></div>
                    <div class="nk-tb-col"><span class="sub-text">تاریخ</span></div>
                    <div class="nk-tb-col"><span class="sub-text">وضعیت</span></div>
                    <div class="nk-tb-col"><span class="sub-text">مبلغ کل</span></div>
                    <div class="nk-tb-col"><span class="sub-text">آدرس</span></div>
                    <div class="nk-tb-col nk-tb-col-tools text-end">
                    </div>
                </div>
				<?php
				foreach ( $orders as $order_id ) {
					$order = wc_get_order( $order_id );
					if ( ! $order ) {
						continue;
					}
					$order_id     = $order->get_id();
					$user_id      = $order->get_customer_id();
					$order_edit   = get_edit_post_link( $order_id );
					$items        = $order->get_items();
					$status       = $order->get_status();
					$status_label = $statuses[ 'wc-' . $status ];
					$status_badge = "bg-" . $badges[ $status ];
					$order_date   = $order->get_date_created();
					$order_date   = date_i18n( 'j F Y', strtotime( $order_date ) );
					$state        = $order->get_billing_state();
					$cities       = PWS()::cities( $state );
					$city         = $order->get_billing_city();
					$address      = $order->get_billing_address_1();
					$postcode     = $order->get_billing_postcode();
					$full_address = $state ?
						$states[ $state ] . '، ' . $cities[ $city ] . '<br>' . $address . '<br>' . $postcode
						: '-';
					$note         = $order->get_meta( 'cashier_note', TRUE );
					$files        = $order->get_meta( 'order_files', TRUE );
					$marketer_id  = $order->get_meta( 'marketer_id', TRUE );
					?>
                    <div class="nk-tb-item">
                        <div class="nk-tb-col">
                            <a href="<?php echo $order_edit; ?>" target="_blank">
                                <span><?php echo $order_id; ?></span>
                            </a>
                        </div>
                        <div class="nk-tb-col">
                            <span class="sub-text"><?php echo $order_date; ?></span>
                        </div>
                        <div class="nk-tb-col">
                            <span class="badge <?php echo $status_badge; ?>"><?php echo $status_label; ?></span>
                        </div>
                        <div class="nk-tb-col">
                                <span class="tb-amount">
                                    <?php echo number_format( $order->get_total() ); ?>
                                    <span class="currency">تومان</span>
                                </span>
                        </div>
                        <div class="nk-tb-col">
                            <div class="sub-text"><?php echo $full_address; ?></div>
                        </div>
                        <div class="nk-tb-col">
                            <ul class="nk-tb-actions gx-2">
								<?php
								if ( $note ) {
									?>
                                    <li>
                                        <div class="btn btn-sm btn-icon btn-trigger"
                                             data-bs-toggle="hover"
                                             data-bs-trigger="click"
                                             data-bs-html="true"
                                             title="یادداشت سفارش"
                                             data-bs-content="<?php echo wpautop( $note ); ?>"
                                             data-bs-placement="top">
                                            <em class="icon ni ni-note-add-c"></em>
                                        </div>
                                    </li>
									<?php
								}
								$hidden_actions = [
									[
										'link'  => '',
										'title' => get_user_name_by_id( $marketer_id ),
										'icon'  => 'ni-user-check',
									],
									[
										'link'  => '',
										'title' => 'جزئیات سفارش',
										'class' => 'load_order_items_table',
										'icon'  => 'ni-package',
										'data'  => [
											'order-id' => $order_id,
										],
									],
								];
								echo crm_get_template( 'partials/row-actions-hidden.php', [
									'actions' => $hidden_actions,
								] );
								?>
                                <li>
									<?php
									$factors = [
										'pre'  => 'پیش فاکتور',
										'roll' => 'فاکتور فروش',
										'acc'  => 'فاکتور پرداخت',
									];
									$actions = [];
									foreach ( $factors as $factor => $label ) {
										$actions[] = [
											'link'   => home_url() . "/crm/?action=factor&type=$factor&order_id=$order_id",
											'title'  => $label,
											'target' => '_blank',
										];
									}
									
									echo crm_get_template( 'partials/row-actions-dropdown.php', [
										'actions'   => $actions,
										'main_icon' => 'printer',
										'title'     => 'چاپ فاکتور',
									] );
									?>
                                </li>
								<?php
								if ( $files ) {
									?>
                                    <li>
										<?php
										$actions = [];
										foreach ( $files as $file ) {
											extract( $file );
											$file_data = $DB->get_uploaded_file_data( $url );
											if ( ! $file_data ) {
												$file_name = $file['title'];
											} else {
												$file_name = $file_data['original_name'];
											}
											$actions[] = [
												'link'     => $url,
												'title'    => $file_name,
												'icon'     => 'ni-download',
												'target'   => '_blank',
												'download' => TRUE,
											];
										}
										echo crm_get_template( 'partials/row-actions-dropdown.php', [
											'actions'   => $actions,
											'main_icon' => 'file-docs',
											'title'     => 'فایل ضمیمه',
										] );
										?>
                                    </li>
									<?php
								}
								?>
                                <li>
									<?php
									$valid_statuses = crm_get_valid_next_status( $status );
									$actions        = [];
									if ( empty( $valid_statuses ) ) {
										$actions = [
											[
												'link'  => '',
												'title' => 'وضعیت سفارش نمی تواند تغییر کند.',
											
											],
										];
									} else {
										foreach ( $valid_statuses as $valid_status ) {
											$actions[] = [
												'link'  => '',
												'title' => $statuses[ 'wc-' . $valid_status ],
												'class' => 'change_order_status',
												'data'  => [
													'status'   => $valid_status,
													'order-id' => $order_id,
												],
											];
										}
									}
									echo crm_get_template( 'partials/row-actions-dropdown.php', [
										'actions'   => $actions,
										'main_icon' => 'repeat',
										'title'     => 'تغییر وضعیت سفارش',
									] );
									?>
                                </li>
                                <li>
									<?php
									$actions = [
										[
											'link'   => home_url() . "/crm/order-edit?order_id=$order_id",
											'icon'   => 'ni-edit',
											'title'  => 'ویرایش سفارش',
											'target' => '_blank',
										],
										[
											'divider' => TRUE,
										],
										[
											'link'  => '',
											'title' => 'اطلاعات چک های سفارش',
											'icon'  => 'ni-edit-alt',
											'class' => 'load_order_cheque',
											'data'  => [
												'order-id' => $order_id,
											],
										],
										[
											'link'  => '',
											'title' => 'اطلاعات پرداخت قسطی',
											'icon'  => 'ni-card-view',
											'class' => 'load_order_installments',
											'data'  => [
												'order-id' => $order_id,
											],
										],
									];
									echo crm_get_template( 'partials/row-actions-dropdown.php', [
										'actions' => $actions,
									] );
									?>
                                </li>
                            </ul>
                        </div>
                    </div>
					<?php
				}
				?>
            </div>
        </div>
		<?php
	}
	?>
</div>

