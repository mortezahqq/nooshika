<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * @var $user_id
 */

$DB           = new kcp_db();
$per_page     = 500;
$visits       = $DB->get_visits( compact( 'per_page', 'user_id' ) );
$visits       = $visits['result'];
$visit_status = $DB->get_visit_status();
?>
<div class="nk-block nk-block-between">
    <div class="nk-block-head">
        <h6 class="title">ویزیت ها</h6>
        <p>گزارش ویزیت های ثبت شده برای مشتری</p>
    </div>
    <div class="nk-block">
        <a href="#addVisit" class="select_current_user_for_modal btn btn-icon btn-primary" data-bs-target="#addVisit"
           data-input="#new_visit_customer_id" data-id="<?php echo $user_id; ?>"
           data-bs-toggle="modal"><em class="icon ni ni-plus"></em></a>
    </div>
</div>
<div class="nk-block">
    <div class="card">
        <div class="nk-tb-list nk-tb-ulist is-compact v-align-top">
            <div class="nk-tb-item nk-tb-head">
                <div class="nk-tb-col"><span class="sub-text">تاریخ ویزیت</span></div>
                <div class="nk-tb-col"><span class="sub-text">وضعیت</span></div>
                <div class="nk-tb-col"><span class="sub-text">توضیحات</span></div>
                <div class="nk-tb-col nk-tb-col-tools text-end"></div>
            </div>
			<?php
			if ( empty( $visits ) ) {
				echo '<div class="no-item-found">ویزیت یافت نشد</div>';
			} else {
				foreach ( $visits as $visit ) {
					extract( $visit );
					$creator      = get_user_name_by_id( $creator );
					$status_badge = $visit_status[ $status ]['class'];
					$status_label = $visit_status[ $status ]['label'];
					?>
                    <div class="nk-tb-item">
                        <div class="nk-tb-col">
                                    <span>
                                        <?php
                                        echo date_i18n( 'j F Y H:i', strtotime( $start_time ) );
                                        if ( $end_date ) {
	                                        echo ' الی ';
	                                        echo date_i18n( 'j F Y H:i', strtotime( $end_date ) );
                                        }
                                        ?>
                                    </span>
                            <span class="sub-text"><?php echo convert_seconds_to_text( $duration ); ?></span>
                        </div>
                        <div class="nk-tb-col">
                            <span class="badge <?php echo $status_badge; ?>"><?php echo $status_label; ?></span>
                        </div>
                        <div class="nk-tb-col w-max-250px w-250px fs-12px nk-news-text"
                             data-bs-toggle="popover"
                             data-bs-trigger="click"
                             data-bs-html="true"
                             title="نتیجه ویزیت"
                             data-bs-content="<?php echo wpautop( $details ?: 'ویزیت پایان نیافته است.' ); ?>"
                             data-bs-placement="top">
							<?php echo wpautop( $details ?: 'ویزیت پایان نیافته است.' ); ?>
                        </div>
                        <div class="nk-tb-col nk-tb-col-tools">
                            <ul class="nk-tb-actions gx-2">
								<?php
								$hidden_actions = [
									[
										'link'  => '',
										'title' => $creator,
										'icon'  => 'ni-user-check',
									],
									'delete' => [
										'link'  => '',
										'title' => 'حذف ویزیت',
										'icon'  => 'ni-trash',
										'class' => 'delete_visit',
										'data'  => [
											'item-id' => $id,
										],
									],
								];
								if ( $status == 'started' ) {
									array_unshift( $hidden_actions, [
										'link'  => '',
										'title' => 'ارجاع به فاکتور',
										'icon'  => 'ni-check-c',
										'class' => 'change_visit_status',
										'data'  => [
											'item-id' => $id,
											'user-id' => $user_id,
											'status'  => 'finished',
										],
									] );
									array_unshift( $hidden_actions, [
										'link'  => '',
										'title' => 'ویزیت ناموفق',
										'icon'  => 'ni-cross-c',
										'class' => 'change_visit_status',
										'data'  => [
											'item-id' => $id,
											'user-id' => $user_id,
											'status'  => 'canceled',
										],
									] );
								}
								if ( ! is_current_user_admin() ) {
									unset( $hidden_actions['delete'] );
								}
								echo crm_get_template( 'partials/row-actions-hidden.php', [
									'actions' => $hidden_actions,
								] );
								?>
                            </ul>
                        </div>
                    </div>
					<?php
				}
			}
			?>
        </div>
    </div>

</div>
