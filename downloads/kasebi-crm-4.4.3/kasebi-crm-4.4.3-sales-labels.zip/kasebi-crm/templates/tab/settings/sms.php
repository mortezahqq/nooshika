<?php

?>
<h6 class="title nk-block-title">تنظیمات پنل پیامکی</h6>
<p>جهت ارسال پیامک به مشتریان اطلاعات پنل فراز خود را وارد کنید.</p>
<div class="gy-3 form-settings">
    <div class="row g-3 align-center">
        <div class="col-lg-5">
            <div class="form-group"><label class="form-label" for="faraz_user_name">نام کاربری</label>
            </div>
        </div>
        <div class="col-lg-7">
            <div class="form-group">
                <div class="form-control-wrap">
                    <input type="text" class="form-control site_setting_field"
                           data-for="crm_faraz_user_name"
                           id="faraz_user_name" value="<?php echo get_option( 'crm_faraz_user_name' ); ?>">
                </div>
            </div>
        </div>
    </div>
    <div class="row g-3 align-center">
        <div class="col-lg-5">
            <div class="form-group"><label class="form-label" for="faraz_password">رمز عبور</label>
            </div>
        </div>
        <div class="col-lg-7">
            <div class="form-group">
                <div class="form-control-wrap">
                    <input type="text" class="form-control site_setting_field"
                           data-for="crm_faraz_password"
                           id="faraz_password" value="<?php echo get_option( 'crm_faraz_password' ); ?>">
                </div>
            </div>
        </div>
    </div>
    <div class="row g-3 align-center">
        <div class="col-lg-5">
            <div class="form-group"><label class="form-label" for="faraz_sender">شماره ارسال پیامک</label>
            </div>
        </div>
        <div class="col-lg-7">
            <div class="form-group">
                <div class="form-control-wrap">
                    <input type="text" class="form-control site_setting_field"
                           data-for="crm_faraz_sender"
                           id="faraz_sender" value="<?php echo get_option( 'crm_faraz_sender' ); ?>">
                </div>
            </div>
        </div>
    </div>
    <div class="row g-3 align-center">
        <div class="col-lg-5">
            <div class="form-group"><label class="form-label" for="faraz_api_url">لینک بیس API</label>
            </div>
        </div>
        <div class="col-lg-7">
            <div class="form-group">
                <div class="form-control-wrap">
                    <input type="text" class="form-control site_setting_field"
                           data-for="crm_faraz_api_url"
                           id="faraz_api_url" value="<?php echo get_option( 'crm_faraz_api_url' ); ?>">
                </div>
            </div>
        </div>
    </div>
    <div class="d-flex justify-end mt-3">
        <div class="btn btn-primary save_site_settings" data-tab="sms">به روزرسانی تنظیمات</div>
    </div>
</div>

