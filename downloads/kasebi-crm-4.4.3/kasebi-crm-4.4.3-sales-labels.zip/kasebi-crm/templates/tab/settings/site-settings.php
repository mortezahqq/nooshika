<h6 class="title nk-block-title">تنظیمات پایه وبسایت</h6>
<p>در این قسمت شما می توانید اطلاعات پایه وبسایت خود را تنظیم کنید.</p>
<div class="gy-3 form-settings">
    <div class="row g-3 align-center">
        <div class="col-lg-5">
            <div class="form-group"><label class="form-label" for="site-name">نام فروشگاه</label>
                <span class="form-note">نام نمایشی فروشگاه در فاکتورها</span>
            </div>
        </div>
        <div class="col-lg-7">
            <div class="form-group">
                <div class="form-control-wrap">
                    <input type="text" class="form-control site_setting_field"
                           data-for="crm_site_title"
                           id="site-name" value="<?php echo get_option( 'crm_site_title' ); ?>">
                </div>
            </div>
        </div>
    </div>
    <div class="row g-3 align-center">
        <div class="col-lg-5">
            <div class="form-group">
                <label class="form-label" for="crm_site_subtitle">زیر عنوان فروشگاه</label>
                <span class="form-note">اسلوگان فروشگاه را اینجا وارد نمایید</span>
            </div>
        </div>
        <div class="col-lg-7">
            <div class="form-group">
                <div class="form-control-wrap">
                    <input type="text" class="form-control site_setting_field"
                           data-for="crm_site_subtitle"
                           id="crm_site_subtitle" value="<?php echo get_option( 'crm_site_subtitle' ); ?>">
                </div>
            </div>
        </div>
    </div>
    <div class="row g-3 align-center">
        <div class="col-lg-5">
            <div class="form-group"><label class="form-label" for="site-address">آدرس فروشگاه</label>
                <span class="form-note">آدرس فروشگاه در فاکتورها</span>
            </div>
        </div>
        <div class="col-lg-7">
            <div class="form-group">
                <div class="form-control-wrap">
                    <input type="text" class="form-control site_setting_field"
                           data-for="crm_site_address"
                           id="site-address" value="<?php echo get_option( 'crm_site_address' ); ?>">
                </div>
            </div>
        </div>
    </div>
    <div class="row g-3 align-center">
        <div class="col-lg-5">
            <div class="col-lg-5">
                <div class="form-group">
                    <label class="form-label" for="site-description">توضیحات فاکتور</label>
                </div>
            </div>
        </div>
        <div class="col-lg-7">
            <div class="form-group">
                <div class="form-control-wrap">
                    <div class="form-control-wrap">
                            <textarea class="form-control form-control site_setting_field" id="site-description"
                                      data-for="crm_site_description"><?php echo get_option( 'crm_site_description' ); ?></textarea>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row g-3 align-center">
        <div class="col-lg-5">
            <div class="form-group"><label class="form-label" for="site-address">دسترسی بازاریاب</label>
                <span class="form-note">بازاریاب به تمام مشتریان وبسایت دسترسی داشته باشد.</span>
            </div>
        </div>
		<?php
		$access_to_all = get_option( 'crm_marketer_access_to_all_user' ) ?: FALSE;
		$access_to_all = filter_var( $access_to_all, FILTER_VALIDATE_BOOLEAN );
		?>
        <div class="col-lg-7">
            <div class="form-group">
                <div class="custom-control custom-switch <?php echo checked( $access_to_all ); ?>">
                    <input type="checkbox" <?php echo checked( $access_to_all ); ?>
                           class="custom-control-input site_setting_field"
                           data-for="crm_marketer_access_to_all_user"
                           id="crm_marketer_access_to_all_user">
                    <label class="custom-control-label" for="crm_marketer_access_to_all_user">دسترسی به همه
                        مشتریان</label>
                </div>
            </div>
        </div>
    </div>
    <div class="row g-3 align-center">
        <div class="col-lg-5">
            <div class="form-group">
                <label class="form-label" for="crm_site_subtitle">لوگوی پنل</label>
                <span class="form-note">لوگوی پنل را اینجا آپلود کنید</span>
            </div>
        </div>
        <div class="col-lg-7">
            <div class="row g-3 align-center">
                <div class="col-lg-7">
					<?php
					$logo = get_option( 'crm_panel_logo' );
					if ( $logo ) {
						?>
                        <div class="crm_logo_preview text-center">
                            <img src="<?php echo $logo; ?>" alt="لوگوی پنل" class="img-fluid">
                        </div>
						<?php
					} else {
						?>
                        <div class="crm_logo_preview text-center">
                            <img src="<?php echo KCP_ASSETS_URL . 'image/kasebi_logo.png'; ?>" alt="لوگوی پنل"
                                 class="img-fluid">
                        </div>
						<?php
					}
					?>
                </div>
                <div class="col-lg-5">
                    <div class="upload-zone" data-target="#crm_panel_logo" data-action="crm_handle_file_upload"
                         data-max-files="10">
                        <div class="dz-message" data-dz-message>
                            <span class="dz-message-text">تصویر را بکشید و رها کنید</span>
                            <span class="dz-message-or">یا</span>
                            <button class="btn btn-primary">انتخاب کنید</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <input type="hidden" class="site_setting_field"
               data-for="crm_panel_logo" id="crm_panel_logo" value="<?php echo $logo; ?>">
    </div>
    <div class="d-flex justify-end mt-3">
        <div class="btn btn-primary save_site_settings" data-tab="site-settings">به روزرسانی تنظیمات</div>
    </div>
</div>
