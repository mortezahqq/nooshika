<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

$clean_total_value = static function( $value ): string {
	if ( $value === NULL || $value === '' ) {
		return '';
	}
	
	$value = nooshika_sanitize_numbers( wp_unslash( (string) $value ) );
	
	return preg_replace( '/[^\d]/u', '', $value );
};

$per_page_key = basename( __FILE__, '.php' );
$per_page_key = "crm_users_{$per_page_key}_per_page";

$current_user_id = get_current_user_id();

$defaults = [
	'page_number' => 1,
	'per_page'    => get_user_meta( $current_user_id, $per_page_key, TRUE ) ?: 20,
	'date'        => [
		'from' => '',
		'to'   => '',
	],
	'search'      => '',
	'marketer_id' => '',
	'status'      => '',
	'order_id'    => '',
	'city'        => '',
	'state'       => '',
	'product_id'  => '',
	'min_total'   => '',
	'max_total'   => '',
	'total'       => [
		'from' => '',
		'to'   => '',
	],
];

$args = wp_parse_args( $_REQUEST, $defaults );

foreach ( $args as $key => $value ) {
	if ( ! is_array( $value ) && $value == 0 ) {
		$args[ $key ] = '';
	}
}

$per_page    = max( 1, absint( $args['per_page'] ) );
$page_number = max( 1, absint( $args['page_number'] ) );

$date = is_array( $args['date'] ?? NULL ) ? $args['date'] : [];

$date_from = $date['from'] ?? '';
$date_to   = $date['to'] ?? '';

$total_range = is_array( $args['total'] ?? NULL ) ? $args['total'] : [];

$min_total = ! empty( $args['min_total'] )
	? $clean_total_value( $args['min_total'] )
	: $clean_total_value( $total_range['from'] ?? '' );

$max_total = ! empty( $args['max_total'] )
	? $clean_total_value( $args['max_total'] )
	: $clean_total_value( $total_range['to'] ?? '' );

$search      = sanitize_text_field( wp_unslash( (string) ( $args['search'] ?? '' ) ) );
$marketer_id = absint( $args['marketer_id'] ?? 0 );
$status      = sanitize_text_field( wp_unslash( (string) ( $args['status'] ?? '' ) ) );
$order_id    = absint( preg_replace( '/\D+/', '', (string) ( $args['order_id'] ?? '' ) ) );
$city        = sanitize_text_field( wp_unslash( (string) ( $args['city'] ?? '' ) ) );
$state       = sanitize_text_field( wp_unslash( (string) ( $args['state'] ?? '' ) ) );
$product_id  = absint( $args['product_id'] ?? 0 );

$order_index       = new Kasebi_Order_Index();
$viewable_statuses = crm_get_viewable_statuses_for_user();
$statuses          = wc_get_order_statuses();
$states            = WC()->countries->get_states( 'IR' );

if ( ! is_current_user_admin( 0, TRUE ) ) {
	$marketer_id = $current_user_id;
}

$selected_status = '';

if ( ! empty( $status ) ) {
	$selected_status = in_array( $status, $viewable_statuses, TRUE )
		? $status
		: 'no_status';
}

$order_query = $order_index->find_orders( [
	'per_page'    => $per_page,
	'page_number' => $page_number,
	'status'      => $selected_status,
	'date'        => [
		'from' => $date_from,
		'to'   => $date_to,
	],
	'search'      => $search,
	'marketer_id' => $marketer_id,
	'product_id'  => $product_id,
	'city'        => $city,
	'state'       => $state,
	'order_id'    => $order_id,
	'min_total'   => $min_total,
	'max_total'   => $max_total,
	'order_by'    => 'date',
	'order'       => 'DESC',
] );

$order_ids     = array_map( 'absint', (array) ( $order_query['result'] ?? [] ) );
$pagination    = is_array( $order_query['pagination'] ?? NULL ) ? $order_query['pagination'] : [];
$total_results = (int) ( $pagination['total'] ?? 0 );

?>
<html dir="rtl" lang="fa-IR">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="ThemeMarch">
    <title>پرینت سفارشات مشتریان</title>
    <link rel="stylesheet" href="<?php echo esc_url( NASSETSURL ); ?>css/nooshika-fonts.css"/>
    <link rel="stylesheet" href="<?php echo esc_url( KCP_ASSETS_URL ); ?>css/print.css?ver=<?php echo time(); ?>"/>

    <style>
        body {
            background: #f5f6fa;
            font-family: inherit;
            direction: rtl;
        }
        
        .cs-container {
            max-width: 1120px;
            margin: 0 auto;
            padding: 24px;
        }
        
        .print_page_title {
            margin-bottom: 20px;
            padding: 16px 20px;
            background: #fff;
            border: 1px solid #e5e9f2;
            border-radius: 12px;
        }
        
        .print_page_title h1 {
            margin: 0 0 8px;
            font-size: 20px;
        }
        
        .print_page_title p {
            margin: 0;
            color: #6c757d;
            font-size: 13px;
        }
        
        .each_print_block {
            background: #fff;
            border: 1px solid #e5e9f2;
            border-radius: 12px;
            margin-bottom: 18px;
            padding: 18px;
            page-break-inside: avoid;
        }
        
        .print_block_header {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            gap: 16px;
            padding-bottom: 14px;
            margin-bottom: 14px;
            border-bottom: 1px solid #e5e9f2;
        }
        
        .customer_block,
        .creator_block,
        .order_meta_block {
            flex: 1;
        }
        
        .creator_block,
        .order_meta_block {
            font-size: 13px;
            line-height: 2;
        }
        
        .print_label {
            color: #8094ae;
            margin-left: 4px;
        }
        
        .print_value {
            color: #1f2b3d;
            font-weight: 600;
        }
        
        .print_address {
            margin-top: 10px;
            padding: 10px 12px;
            background: #f8f9fb;
            border-radius: 8px;
            color: #364a63;
            font-size: 13px;
            line-height: 1.9;
        }
        
        .print_items_table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
            font-size: 13px;
        }
        
        .print_items_table th,
        .print_items_table td {
            border: 1px solid #e5e9f2;
            padding: 9px 10px;
            text-align: right;
            vertical-align: middle;
        }
        
        .print_items_table th {
            background: #f5f6fa;
            color: #526484;
            font-weight: 700;
        }
        
        .print_total_row {
            display: flex;
            justify-content: flex-end;
            margin-top: 14px;
        }
        
        .print_total_box {
            min-width: 260px;
            padding: 12px 14px;
            border-radius: 8px;
            background: #f5f6fa;
            font-size: 14px;
        }
        
        .print_total_box strong {
            font-size: 16px;
        }
        
        .no-print-orders {
            background: #fff;
            border: 1px solid #e5e9f2;
            border-radius: 12px;
            padding: 24px;
            text-align: center;
            color: #8094ae;
        }
        
        @media print {
            body {
                background: #fff;
            }
            
            .cs-container {
                max-width: none;
                padding: 0;
            }
            
            .each_print_block {
                border-radius: 0;
                border-color: #ddd;
            }
        }
        
        .print_order_items_table {
            table-layout: fixed;
        }
        
        .print_order_items_table .print-col-index {
            width: 50px;
        }
        
        .print_order_items_table .print-col-product {
            width: auto;
        }
        
        .print_order_items_table .print-col-qty {
            width: 95px;
        }
        
        .print_order_items_table .print-col-price {
            width: 130px;
        }
        
        .print_order_items_table .print-col-discount {
            width: 90px;
        }
        
        .print_order_items_table .print-col-final-price {
            width: 140px;
        }
        
        .print_order_items_table .print-col-total {
            width: 150px;
        }
        
        .print_order_items_table .print-price-cell,
        .print_order_items_table .print-qty-cell,
        .print_order_items_table .print-discount-cell {
            white-space: nowrap;
        }
        
        .print_product_note {
            margin-top: 4px;
            color: #8094ae;
            font-size: 12px;
            line-height: 1.8;
        }
        
        .print_discount_percent {
            color: #8094ae;
            font-size: 12px;
            margin-top: 3px;
        }
        
        .print_items_summary {
            margin-top: 12px;
            display: flex;
            justify-content: flex-end;
        }
        
        .print_items_summary_box {
            min-width: 320px;
            background: #f5f6fa;
            border-radius: 8px;
            padding: 10px 12px;
            font-size: 13px;
        }
        
        .print_items_summary_row {
            display: flex;
            justify-content: space-between;
            gap: 16px;
            line-height: 2;
        }
        
        .print_items_summary_row.is-final {
            margin-top: 6px;
            padding-top: 6px;
            border-top: 1px solid #e5e9f2;
            font-weight: 700;
        }
    </style>
</head>
<body>
<div class="cs-container">

    <div class="print_page_title">
        <h1>پرینت سفارشات مشتریان</h1>
        <p>
            تعداد کل سفارش‌های مطابق فیلتر:
			<?php echo esc_html( number_format_i18n( $total_results ) ); ?>
        </p>
    </div>
	
	<?php
	if ( empty( $order_ids ) ) {
		?>
        <div class="no-print-orders">
            سفارشی برای چاپ یافت نشد.
        </div>
		<?php
	} else {
		foreach ( $order_ids as $order_id ) {
			$order = wc_get_order( $order_id );
			
			if ( ! $order ) {
				continue;
			}
			
			$customer_id = absint( $order->get_customer_id() );
			$items       = $order->get_items();
			$order_date  = $order->get_date_created();
			$order_date  = $order_date ? date_i18n( 'j F Y - H:i', strtotime( $order_date ) ) : '-';
			
			$order_status       = $order->get_status();
			$order_status_key   = 'wc-' . $order_status;
			$order_status_label = $statuses[ $order_status_key ] ?? $order_status;
			
			$marketer_id   = absint( $order->get_meta( 'marketer_id', TRUE ) );
			$creator       = $marketer_id ? get_user_name_by_id( $marketer_id ) : '-';
			$billing_state = (string) $order->get_billing_state();
			$billing_city  = (string) $order->get_billing_city();
			$address       = (string) $order->get_billing_address_1();
			$postcode      = (string) $order->get_billing_postcode();
			
			$state_label = $billing_state && isset( $states[ $billing_state ] )
				? $states[ $billing_state ]
				: $billing_state;
			
			$city_label = $billing_city;
			
			if ( $billing_state && function_exists( 'PWS' ) ) {
				$cities = PWS()::cities( $billing_state );
				
				if ( is_array( $cities ) && isset( $cities[ $billing_city ] ) ) {
					$city_label = $cities[ $billing_city ];
				}
			}
			
			$address_parts = array_filter( [
				$state_label,
				$city_label,
				$address,
				$postcode,
			] );
			
			$full_address = ! empty( $address_parts )
				? implode( '، ', $address_parts )
				: '-';
			
			?>
            <div class="each_print_block">

                <div class="print_block_header">
                    <div class="customer_block">
						<?php
						if ( $customer_id ) {
							echo crm_get_template( 'partials/user-card.php', [
								'user_id'    => $customer_id,
								'show_phone' => TRUE,
							] );
						} else {
							$billing_name  = trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() );
							$billing_phone = $order->get_billing_phone();
							?>
                            <div>
                                <div>
                                    <span class="print_label">مشتری:</span>
                                    <span class="print_value"><?php echo esc_html( $billing_name ?: 'مهمان' ); ?></span>
                                </div>
                                <div>
                                    <span class="print_label">موبایل:</span>
                                    <span class="print_value"><?php echo esc_html( $billing_phone ?: '-' ); ?></span>
                                </div>
                            </div>
							<?php
						}
						?>

                        <div class="print_address">
                            <span class="print_label">آدرس:</span>
							<?php echo esc_html( $full_address ); ?>
                        </div>
                    </div>

                    <div class="order_meta_block">
                        <div>
                            <span class="print_label">شماره سفارش:</span>
                            <span class="print_value">#<?php echo esc_html( $order_id ); ?></span>
                        </div>
                        <div>
                            <span class="print_label">تاریخ:</span>
                            <span class="print_value"><?php echo esc_html( $order_date ); ?></span>
                        </div>
                        <div>
                            <span class="print_label">وضعیت:</span>
                            <span class="print_value"><?php echo esc_html( $order_status_label ); ?></span>
                        </div>
                    </div>

                    <div class="creator_block">
                        <div>
                            <span class="print_label">ثبت‌کننده:</span>
                            <span class="print_value"><?php echo esc_html( $creator ); ?></span>
                        </div>
                    </div>
                </div>

                <div class="print_block_body">
					<?php
					$format_price = static function( $amount ): string {
						return number_format_i18n( (float) $amount );
					};
					
					$format_qty = static function( $qty ): string {
						$qty = (float) $qty;
						
						return rtrim( rtrim( number_format( $qty, 3, '.', '' ), '0' ), '.' );
					};
					
					$items_subtotal = 0;
					$items_discount = 0;
					$items_total    = 0;
					?>

                    <table class="print_items_table print_order_items_table">
                        <colgroup>
                            <col class="print-col-index">
                            <col class="print-col-product">
                            <col class="print-col-qty">
                            <col class="print-col-price">
                            <col class="print-col-discount">
                            <col class="print-col-final-price">
                            <col class="print-col-total">
                        </colgroup>

                        <thead>
                        <tr>
                            <th>#</th>
                            <th>محصول</th>
                            <th>مقدار</th>
                            <th>فی</th>
                            <th>تخفیف</th>
                            <th>فی بعد از تخفیف</th>
                            <th>مبلغ کل</th>
                        </tr>
                        </thead>

                        <tbody>
						<?php
						$item_counter = 0;
						
						foreach ( $items as $item ) {
							$item_counter ++;
							
							$item_qty = $item->get_meta( 'line_decimal_qty', TRUE );
							
							if ( $item_qty === '' || $item_qty === NULL ) {
								$item_qty = $item->get_quantity();
							}
							
							$item_qty = (float) $item_qty;
							
							$line_regular_total = $item->get_meta( 'line_regular_total', TRUE );
							
							if ( $line_regular_total === '' || $line_regular_total === NULL ) {
								$line_regular_total = $item->get_subtotal();
							}
							
							$line_regular_total = (float) $line_regular_total;
							$line_total         = (float) $item->get_total();
							
							$unit_regular_price = $item_qty > 0 ? $line_regular_total / $item_qty : 0;
							$unit_final_price   = $item_qty > 0 ? $line_total / $item_qty : 0;
							
							$line_discount_total = $item->get_meta( 'line_discount_total', TRUE );
							
							if ( $line_discount_total === '' || $line_discount_total === NULL ) {
								$line_discount_total = max( 0, $line_regular_total - $line_total );
							}
							
							$line_discount_total = (float) $line_discount_total;
							
							$off_percent = $item->get_meta( 'off_percent', TRUE );
							
							if ( $off_percent === '' && $line_regular_total > 0 && $line_discount_total > 0 ) {
								$off_percent = round( ( $line_discount_total / $line_regular_total ) * 100, 2 );
							}
							
							$note = $item->get_meta( 'note', TRUE );
							
							$items_subtotal += $line_regular_total;
							$items_discount += $line_discount_total;
							$items_total    += $line_total;
							?>
                            <tr>
                                <td><?php echo esc_html( $item_counter ); ?></td>

                                <td>
									<?php echo esc_html( $item->get_name() ); ?>
									
									<?php if ( $note ) : ?>
                                        <div class="print_product_note">
											<?php echo esc_html( $note ); ?>
                                        </div>
									<?php endif; ?>
                                </td>

                                <td class="print-qty-cell">
									<?php echo esc_html( $format_qty( $item_qty ) ); ?>
                                </td>

                                <td class="print-price-cell">
									<?php echo esc_html( $format_price( $unit_regular_price ) ); ?>
                                </td>

                                <td class="print-discount-cell">
									<?php if ( $line_discount_total > 0 ) : ?>
										<?php echo esc_html( $format_price( $line_discount_total ) ); ?>
										
										<?php if ( $off_percent !== '' ) : ?>
                                            <div class="print_discount_percent">
												<?php echo esc_html( $off_percent ); ?>٪
                                            </div>
										<?php endif; ?>
									<?php else : ?>
                                        -
									<?php endif; ?>
                                </td>

                                <td class="print-price-cell">
									<?php echo esc_html( $format_price( $unit_final_price ) ); ?>
                                </td>

                                <td class="print-price-cell">
									<?php echo esc_html( $format_price( $line_total ) ); ?>
                                </td>
                            </tr>
							<?php
						}
						
						if ( $item_counter === 0 ) {
							?>
                            <tr>
                                <td colspan="7">آیتمی برای این سفارش ثبت نشده است.</td>
                            </tr>
							<?php
						}
						?>
                        </tbody>
                    </table>
					
					<?php if ( $item_counter > 0 ) : ?>
                        <div class="print_items_summary">
                            <div class="print_items_summary_box">
                                <div class="print_items_summary_row">
                                    <span>جمع قیمت اصلی کالاها:</span>
                                    <strong><?php echo esc_html( $format_price( $items_subtotal ) ); ?> </strong>
                                </div>

                                <div class="print_items_summary_row">
                                    <span>تخفیفات کالاها:</span>
                                    <strong><?php echo esc_html( $format_price( $items_discount ) ); ?> </strong>
                                </div>

                                <div class="print_items_summary_row is-final">
                                    <span>جمع کل کالاها:</span>
                                    <strong><?php echo esc_html( $format_price( $items_total ) ); ?> </strong>
                                </div>
                            </div>
                        </div>
					<?php endif; ?>

                </div>

            </div>
			<?php
		}
	}
	?>

</div>

<script src="<?php echo esc_url( KCP_ASSETS_URL ); ?>js/factor/jquery.min.js"></script>
<script src="<?php echo esc_url( KCP_ASSETS_URL ); ?>js/factor/jspdf.min.js"></script>
<script src="<?php echo esc_url( KCP_ASSETS_URL ); ?>js/factor/html2canvas.min.js"></script>
<script src="<?php echo esc_url( KCP_ASSETS_URL ); ?>js/factor/main.js"></script>
</body>
</html>