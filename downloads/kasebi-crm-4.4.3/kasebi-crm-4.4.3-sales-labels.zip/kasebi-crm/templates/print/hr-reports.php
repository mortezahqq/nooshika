<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
$per_page_key = basename( __FILE__, '.php' );
$per_page_key = "crm_users_{$per_page_key}_per_page";
$user_id      = get_current_user_id();
$defaults     = [
	'page_number' => 1,
	'per_page'    => get_user_meta( $user_id, $per_page_key, TRUE ) ?: 20,
	'date_from'   => '',
	'date_to'     => '',
	'search'      => '',
	'employee_id' => '',
	'category'    => '',
];
$args         = wp_parse_args( $_REQUEST, $defaults );
$args         = array_map( fn( $v ) => $v == 0 ? '' : $v, $args );
extract( $args );
$DB              = new kcp_db();
$source          = 'internal';
$calls           = $DB->get_employee_reports(
	compact( 'per_page', 'offset', 'date_from', 'date_to', 'search', 'employee_id', 'category' ) );
$calls           = $calls['result'];
$report_category = $DB->get_report_category();
?>
<html dir="rtl" lang="fa-IR">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="ThemeMarch">
    <title>پرینت گزارش های کارمندان</title>
    <link rel="stylesheet" href="<?php echo NASSETSURL; ?>css/nooshika-fonts.css"/>
    <link rel="stylesheet" href="<?php echo KCP_ASSETS_URL; ?>css/print.css?ver=<?php echo time(); ?>"/>
</head>
<body>
<div class="cs-container">
	<?php
	foreach ( $calls as $call ) {
		extract( $call );
		$category_badge = $report_category[ $category ]['class'];
		$category_label = $report_category[ $category ]['label'];
		?>
        <div class="each_print_block">
            <div class="print_block_header">
                <div class="customer_block">
					<?php
					echo crm_get_template( 'partials/user-card.php', [
						'user_id'    => $employee_id,
						'show_phone' => TRUE,
					] );
					?>
                </div>
            </div>
            <div class="print_block_body">
                <h4 class="print_block_detail" style="margin-bottom: 5px; margin-top: 0;"><?php echo $title; ?></h4>
                <div class="print_block_detail"><?php echo wpautop( $content ); ?></div>
            </div>
            <div class="print_block_footer">
                <div class="item_status" style="gap: 5px; display: flex; justify-content: space-between;">
                   <span class="badge <?php echo $category_badge; ?>"><?php echo
	                   $category_label; ?></span>
                    <span
                        class="sub-text fs-10px text-nowrap"><?php echo date_i18n( 'j F Y', strtotime( $created_at ) ); ?></span>
                </div>
            </div>
        </div>
		<?php
	}
	?>
</div>
<script src="<?php echo KCP_ASSETS_URL; ?>js/factor/jquery.min.js"></script>
<script src="<?php echo KCP_ASSETS_URL; ?>js/factor/jspdf.min.js"></script>
<script src="<?php echo KCP_ASSETS_URL; ?>js/factor/html2canvas.min.js"></script>
<script src="<?php echo KCP_ASSETS_URL; ?>js/factor/main.js"></script>
</body>
</html>