<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

$defaults = [
	'pa_brand'    => '',
	'product_cat' => '',
	'pa_size'     => '',
	'search'      => '',
	'offset'      => 0,
	'per_page'    => 20,
];
$args     = wp_parse_args( $_REQUEST, $defaults );
$args     = array_map( fn( $v ) => $v == 0 ? '' : $v, $args );
extract( $args );
//$offset      = ( $page_number - 1 ) * $per_page;
$products    = crm_get_products_list( compact( 'per_page', 'offset', 'pa_brand', 'product_cat',
	'pa_size', 'search' ) );
$product_ids = $products['product_ids'];
$brand_tax   = 'pa_brand';
?>
<html dir="rtl" lang="fa-IR">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>پرینت اتیکت</title>
    <link rel="stylesheet" href="<?php echo NASSETSURL; ?>css/nooshika-fonts.css"/>
    <link rel="stylesheet" href="<?php echo KCP_ASSETS_URL; ?>css/print.css?ver=<?php echo time(); ?>"/>
    <link rel="stylesheet" href="<?php echo KCP_ASSETS_URL; ?>css/ticket.css?ver=<?php echo time(); ?>"/>
</head>
<body>
<div class="cs-container eticket_wrapper">
    <div class="each_a4_page">
		<?php
		$count = 0;
		foreach ( $product_ids as $product_id ) {
			$parent_id = wp_get_post_parent_id( $product_id ) ?: $product_id;
			$brand     = wp_get_post_terms( $parent_id, $brand_tax );
			$brand     = $brand[0]->name ?? '';
			$brand     = $brand ?: '';
			$title     = get_the_title( $parent_id );
			$size      = get_post_meta( $product_id, 'attribute_pa_size', TRUE );
			$size      = get_term_by( 'slug', $size, 'pa_size' )->name;
			$price     = get_post_meta( $product_id, '_price', TRUE ) ?: 0;
			?>
            <div class="each_eticket_block">
                <div class="eticket_product_title">
					<?php echo nooshika_sanitize_numbers( $title, 'fa' ); ?>
                </div>
                <div class="eticket_product_size">سایز: <?php echo $size; ?>
                </div>
                <div class="eticket_product_brand">برند: <?php echo $brand; ?>
                </div>
                <div class="eticket_product_price">
                    <span class="price"><?php echo nooshika_sanitize_numbers( number_format( $price ), 'fa' ); ?></span>
                    <span class="currency">تومان</span>
                </div>
            </div>
			<?php
			$count ++;
			if ( $count % 4 == 0 ) {
				echo '</div><div class="each_a4_page">';
			}
		}
		?>
    </div>
</div>
<script src="<?php echo KASEBI_SHOP_ASSETS_URL; ?>js/factor/jquery.min.js"></script>
<script src="<?php echo KASEBI_SHOP_ASSETS_URL; ?>js/factor/jspdf.min.js"></script>
<script src="<?php echo KASEBI_SHOP_ASSETS_URL; ?>js/factor/html2canvas.min.js"></script>
<script src="<?php echo KASEBI_SHOP_ASSETS_URL; ?>js/factor/main.js"></script>
</body>
</html>