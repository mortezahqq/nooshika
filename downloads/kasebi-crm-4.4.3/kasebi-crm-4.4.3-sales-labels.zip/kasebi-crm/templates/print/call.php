<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
$per_page_key = basename( __FILE__, '.php' );
$per_page_key = "crm_users_{$per_page_key}_per_page";
$user_id      = get_current_user_id();
$defaults     = [
	'page_number' => 1,
	'per_page'    => get_user_meta( $user_id, $per_page_key, TRUE ) ?: 20,
	'date'        => [
		'from' => '',
		'to'   => '',
	],
	'search'      => '',
	'search_user' => '',
	'creator'     => '',
	'status'      => '',
	'category'    => '',
];
$args         = wp_parse_args( $_REQUEST, $defaults );
$args         = array_map( fn( $v ) => $v == 0 ? '' : $v, $args );
extract( $args );
$date            = is_array( $date ) ? $date : [];
$date_from       = $date['from'] ?? '';
$date_to         = $date['to'] ?? '';
$DB              = new kcp_db();
$calls           = $DB->get_calls(
	compact( 'per_page', 'offset', 'date_from', 'date_to',
		'search', 'search_user', 'creator', 'status', 'category' ) );
$calls           = $calls['result'];
$call_statuses   = $DB->get_call_statuses();
$call_categories = $DB->get_call_categories();
?>
<html dir="rtl" lang="fa-IR">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="ThemeMarch">
    <title>پرینت درخواست های مشتریان</title>
    <link rel="stylesheet" href="<?php echo NASSETSURL; ?>css/nooshika-fonts.css"/>
    <link rel="stylesheet" href="<?php echo KCP_ASSETS_URL; ?>css/print.css?ver=<?php echo time(); ?>"/>
</head>
<body>
<div class="cs-container">
	<?php
	foreach ( $calls as $call ) {
		extract( $call );
		$assigned_to = $DB->get_call_meta( $id, 'assigned_to' );
		$progresses  = $DB->get_call_progress( $id );
		$assigned_to = $assigned_to ? get_user_name_by_id( $assigned_to ) : '-';
		?>
        <div class="each_print_block">
            <div class="print_block_header">
                <div class="customer_block">
					<?php
					echo crm_get_template( 'partials/user-card.php', [
						'user_id'    => $user_id,
						'show_phone' => TRUE,
					] );
					?>
                </div>
                <div class="creator_block"><?php echo $assigned_to; ?></div>
            </div>
            <div class="print_block_body">
                <div class="print_block_detail"><?php echo wpautop( $content ); ?></div>
            </div>
            <div class="print_block_footer">
                <div class="item_status" style="gap: 5px">
                    <span class="sub-text">وضعیت:</span>
                    <span class="badge bg-info"><?php echo $call_statuses[ $status ]['label']; ?></span>
                </div>
                <div class="call_progress_wrapper">
					<?php
					
					if ( empty( $progresses ) ) {
						echo '<div class="no-item-found">تا کنون اقدامی برای این درخواست صورت نگرفته است.</div>';
					} else {
						?>
                        <div class="bq-note">
							<?php
							foreach ( $progresses as $progress ) {
								extract( $progress );
								$status_badge = $call_statuses[ $to_status ]['class'];
								$status_label = $call_statuses[ $to_status ]['label'];
								?>
                                <div class="bq-note-item">
                                    <div class="bq-note-text">
										<?php
										echo wpautop( $comment );
										$assigned_from = $DB->get_call_meta( $call_id, "assigned_from_$id" );
										$assigned_to   = $DB->get_call_meta( $call_id, "assigned_to_$id" );
										$from          = $call_categories[ $from_category ]['label'];
										if ( $progress['to_category'] != $progress['from_category'] ) {
											$to = $call_categories[ $to_category ]['label'];
											?>
                                            <div class="sub-text mb-1">
												<?php echo "درخواست از <strong>$from</strong> به <strong>$to</strong> ارجاع داده شد."; ?>
                                            </div>
											<?php
										} else {
											?>
                                            <div class="sub-text mb-1">
												<?php echo "درخواست در واحد <strong>$from</strong> بررسی شد."; ?>
                                            </div>
											<?php
										}
										if ( $assigned_from != $assigned_to && $assigned_to ) {
											$assigned_to   = get_user_name_by_id( $assigned_to );
											$assigned_from = get_user_name_by_id( $assigned_from );
											?>
                                            <div class="sub-text mb-1">
												<?php echo "درخواست از <strong>$assigned_from</strong> به <strong>$assigned_to</strong> محول شد."; ?>
                                            </div>
											<?php
										}
										?>
                                        <div class="d-flex mt-1" style="gap: 5px">
                                            <span class="sub-text">تغییر وضعیت به:</span>
                                            <span
                                                class="badge <?php echo $status_badge; ?>"><?php echo $status_label; ?></span>
                                        </div>
                                    </div>
                                    <div class="bq-note-meta">
                        <span class="bq-note-added">
                            اضافه شده در <span
                                class="date"><?php echo date_i18n( 'j F Y', strtotime( $changed_at ) ); ?></span>
                            در <span class="time"><?php echo date_i18n( 'H:i', strtotime( $changed_at ) ); ?></span>
                        </span>
                                        <span class="bq-note-sep sep">|</span>
                                        <span
                                            class="bq-note-by">توسط <span><?php echo get_user_name_by_id( $changed_by ); ?></span>
                        </span>
                                    </div>
                                </div>
								<?php
							}
							?>
                        </div>
						<?php
					}
					?>
                </div>
            </div>
        </div>
		<?php
	}
	?>
</div>
<script src="<?php echo KCP_ASSETS_URL; ?>js/factor/jquery.min.js"></script>
<script src="<?php echo KCP_ASSETS_URL; ?>js/factor/jspdf.min.js"></script>
<script src="<?php echo KCP_ASSETS_URL; ?>js/factor/html2canvas.min.js"></script>
<script src="<?php echo KCP_ASSETS_URL; ?>js/factor/main.js"></script>
</body>
</html>