<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
$per_page_key = basename( __FILE__, '.php' );
$per_page_key = "crm_users_{$per_page_key}_per_page";
$user_id      = get_current_user_id();
$defaults     = [
	'offset'      => 0,
	'per_page'    => get_user_meta( $user_id, $per_page_key, TRUE ) ?: 20,
	'date'        => [
		'from' => '',
		'to'   => '',
	],
	'search'      => '',
	'search_user' => '',
	'creator'     => '',
	'status'      => '',
	'intro'       => '',
];
$args         = wp_parse_args( $_REQUEST, $defaults );
$args         = array_map( fn( $v ) => $v == 0 ? '' : $v, $args );
extract( $args );
$date         = is_array( $date ) ? $date : [];
$date_from    = $date['from'] ?? '';
$date_to      = $date['to'] ?? '';
$DB           = new kcp_db();
$visits       = $DB->get_visits(
	compact( 'per_page', 'offset', 'date_from', 'date_to',
		'search', 'search_user', 'creator', 'status', 'intro' ) );
$visit_status = $DB->get_visit_status();
$visits       = $visits['result'];

?>
<html dir="rtl" lang="fa-IR">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="ThemeMarch">
    <title>پرینت ویزیت</title>
    <link rel="stylesheet" href="<?php echo NASSETSURL; ?>css/nooshika-fonts.css"/>
    <link rel="stylesheet" href="<?php echo KCP_ASSETS_URL; ?>css/print.css?ver=<?php echo time(); ?>"/>
</head>
<body>
<div class="cs-container">
	<?php
	foreach ( $visits as $visit ) {
		extract( $visit );
		$status_label = $visit_status[ $status ]['label'];
		?>
        <div class="each_print_block">
            <div class="print_block_header">
                <div class="customer_block">
					<?php
					if ( $user_id ) {
						echo crm_get_template( 'partials/user-card.php', [
							'user_id'    => $user_id,
							'show_phone' => TRUE,
						] );
					} else {
						echo 'ویزیت ناشناس';
					}
					?>
                </div>
                <div class="creator_block"><?php echo get_user_name_by_id( $creator ); ?></div>
            </div>
            <div class="print_block_body">
                <div class="print_block_detail"><?php echo wpautop( $details ?: 'ویزیت پایان نیافته است.' ); ?></div>
            </div>
            <div class="print_block_footer">
                <div class="item_status" style="gap: 5px">
                    <span class="sub-text">وضعیت:</span>
                    <span class="badge bg-info"><?php echo $visit_status[ $status ]['label']; ?></span>
                </div>
                <div class="visit_time">
                    <div>
						<?php
						echo date_i18n( 'j F Y H:i', strtotime( $start_time ) );
						if ( $end_date ) {
							echo ' الی ';
							echo date_i18n( 'j F Y H:i', strtotime( $end_date ) );
						}
						?>
                    </div>
                    <span class="sub-text"><?php echo convert_seconds_to_text( $duration ); ?></span>
                </div>
            </div>
        </div>
		<?php
	}
	?>
</div>
<script src="<?php echo KCP_ASSETS_URL; ?>js/factor/jquery.min.js"></script>
<script src="<?php echo KCP_ASSETS_URL; ?>js/factor/jspdf.min.js"></script>
<script src="<?php echo KCP_ASSETS_URL; ?>js/factor/html2canvas.min.js"></script>
<script src="<?php echo KCP_ASSETS_URL; ?>js/factor/main.js"></script>
</body>
</html>