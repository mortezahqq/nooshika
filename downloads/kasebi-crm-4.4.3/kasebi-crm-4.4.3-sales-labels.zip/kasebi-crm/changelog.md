### Version 1.0.0

<details>
<summary>click to see changes</summary>

- Create a new project

</details>

### Version 2.0.0

<details>
<summary>features</summary>

- enhance the project ui
- complete change the ajax
- complete change the admin panel
- complete change the user panel

</details>

### Version 2.1.0 (2023-04-27)

> this change come for easy to use for client and install on new site

<details>
<summary>features</summary>

* add changelog file
* automate create main pages
* new page shortcode
* automate create user role
* automate create marketers
* automate create ajax mu-plugin
* redirect to login page if user not logged in
* marketer change password btn
* add import page
    * file template for import
    * import users
* remove unused codes
* custom logout link
* add new marketer for admin panel
* auto update from server
* edit marketer name for admin
* minor bug fix
* minor ui fix

</details>

### Version 2.2.0 (2023-06-01)

<details>
<summary>todo list</summary>

- [x] add new product to panel
- [ ] add new group and tag for users
- [x] add export from users
- [x] add export from orders
- [ ] add activity report for admin and marketer
- [x] add export activity report
- [ ] refactor activity log
- [x] update page content on create users
- [ ] add user tag id in import users
- [x] calender filter bug
- [x] marketer dropdown name bug
- [x] add reminder category for followup items
- [x] add remove followup in users edit page
- [ ] add user input filter
- [ ] user register date filter
- [ ] add shepherd js for crm panel
- [ ] add question mark for start guide
- [ ] enhance save user data
- [x] fix Receipt image bug
- [x] add [today] and [all pass] filter to followup pages

</details>

### Version 4.0.0 (2025-01-25)

### Version 4.1.0 (2025-02-05)

> fixing crm bugs that reported from users

<details>
<summary>bug reported</summary>

</details>

<details>
<summary>bug fixed</summary>

- number format for price unit in dashboard fixed
- redirect after adding transaction to wallet fixed

</details>

### Version 4.2.0 (2025-02-12)

<details>
<summary>fixed</summary>

- marketer only see their users
- marketer only see their orders

</details>

<details>
<summary>added</summary>

- RFM system

</details>

### Version 4.2.1 (2025-02-15)

<details>
<summary>fixed</summary>

- fix back to admin link when visiting marketer panel
- fix save checkbox type field in settings

</details>

<details>
<summary>added</summary>

- setting for show all users to marketer or not

</details>
