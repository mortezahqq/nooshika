<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

add_filter( 'plugins_api', 'nooshika_crm_info', 20, 3 );
function nooshika_crm_info( $res, $action, $args ) {
	if ( $action !== 'plugin_information' ) {
		return $res;
	}
	if ( 'nooshika-crm/nooshika-crm.php' !== $args->slug ) {
		return $res;
	}
	$remote = wp_remote_get(
		'https://kasebi-plugins.iran.liara.run/info.php?plugin=nooshika-crm',
		array(
			'timeout' => 10,
			'headers' => array(
				'Accept' => 'application/json'
			)
		)
	);
	if ( is_wp_error( $remote )
	     || 200 !== wp_remote_retrieve_response_code( $remote )
	     || empty( wp_remote_retrieve_body( $remote ) ) ) {
		return $res;
	}
	$remote             = json_decode( wp_remote_retrieve_body( $remote ) );
	$res                = new stdClass();
	$res->name          = $remote->name;
	$res->slug          = $remote->slug;
	$res->author        = $remote->author;
	$res->version       = $remote->version;
	$res->tested        = $remote->tested;
	$res->requires      = $remote->requires;
	$res->requires_php  = $remote->requires_php;
	$res->download_link = $remote->download_url;
	$res->trunk         = $remote->download_url;
	$res->last_updated  = $remote->last_updated;

	return $res;
}

add_filter( 'site_transient_update_plugins', 'nooshika_crm_push_update' );
function nooshika_crm_push_update( $transient ) {
	if ( empty( $transient->checked ) ) {
		return $transient;
	}
	$remote = wp_remote_get(
		'https://kasebi-plugins.iran.liara.run/info.php?plugin=nooshika-crm',
		array(
			'timeout' => 10,
			'headers' => array(
				'Accept' => 'application/json'
			)
		)
	);
	if ( is_wp_error( $remote )
	     || 200 !== wp_remote_retrieve_response_code( $remote )
	     || empty( wp_remote_retrieve_body( $remote ) ) ) {
		return $transient;
	}
	$remote = json_decode( wp_remote_retrieve_body( $remote ) );
	if (
		$remote
		&& version_compare( NCP_VERSION, $remote->version, '<' )
		&& version_compare( $remote->requires, get_bloginfo( 'version' ), '<' )
		&& version_compare( $remote->requires_php, PHP_VERSION, '<' )
	) {

		$res                                 = new stdClass();
		$res->slug                           = $remote->slug;
		$res->plugin                         = NCP_BASE_NAME;
		$res->new_version                    = $remote->version;
		$res->tested                         = $remote->tested;
		$res->package                        = $remote->download_url;
		$transient->response[ $res->plugin ] = $res;
	}

	return $transient;
}
