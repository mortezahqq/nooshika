<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

add_shortcode( 'crm-login', function() {
	$title    = get_option( 'crm_site_title' ) ?: 'کاسبی';
	$subtitle = get_option( 'crm_site_subtitle' ) ?: 'برای هر نیاز کسب‌وکارت، یک راه‌حل داریم';
	$logo     = get_option( 'crm_panel_logo' );
	if ( ! $logo ) {
		$logo = KCP_ASSETS_URL . 'image/kasebi_logo.png';
	}
	ob_start();
	?>
    <div class="nk-wrap justify-center ui-rounder">
        <div class="container px-4 py-5 px-md-5 text-center my-5">
            <div class="row align-items-center ">
                <div class="login_form_col col-md-4 col-12 mb-5">
                    <div class="card card-bordered">
                        <div class="card-inner p-5">
                            <div class="website_logo_wrapper">
                                <img src="<?php echo $logo; ?>" alt="" width="120">
                            </div>
                            <div class="each_login_form" id="log_password_form">
                                <h6 class="login_form_title mb-2 mt-4">ورود به حساب مشتریی</h6>
                                <div class="login_form_subtitle mb-3">
                                    جهت ورود به پنل نام کاربری و رمزعبور خود را وارد نمایید
                                </div>
                                <div class="login_form_wrapper">
                                    <div class="form-group mb-2">
                                        <div class="form-control-wrap">
                                            <input type="text" class="form-control form-control-outlined dir_ltr"
                                                   id="username" name="username">
                                            <label class="form-label-outlined" for="username">نام کاربری</label>
                                        </div>
                                    </div>
                                    <div class="form-group mb-2">
                                        <div class="form-control-wrap">
                                            <a tabindex="-1" href="#"
                                               class="form-icon form-icon-right passcode-switch"
                                               data-target="password">
                                                <em class="passcode-icon icon-show icon ni ni-eye"></em>
                                                <em class="passcode-icon icon-hide icon ni ni-eye-off"></em></a>
                                            <input type="password" class="form-control form-control-outlined dir_ltr"
                                                   id="password" name="password">
                                            <label class="form-label-outlined" for="password">رمز عبور</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <div class="btn btn-block btn-primary submit_login_form">ورود</div>
                                </div>
                                <div class="terms_link_wrapper">
                                    <div data-url="#login_otp_form" class="link toggle_login_form">ورود با کد یکبار
                                        مصرف
                                    </div>
                                </div>
                            </div>
                            <div class="each_login_form active" id="login_otp_form">
                                <h6 class="login_form_title mb-2 mt-4">ورود/ثبت نام</h6>
                                <div class="login_form_subtitle mb-3">
                                    جهت ورود به پنل شماره موبایل خود را وارد نمایید.
                                </div>
                                <div class="login_form_wrapper">
                                    <div class="form-group mb-2">
                                        <div class="form-control-wrap">
                                            <input type="text" class="form-control form-control-outlined dir_ltr"
                                                   id="otp_phone" name="phone">
                                            <label class="form-label-outlined" for="otp_phone">شماره موبایل</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <div class="btn btn-block btn-primary send_otp">ارسال رمز یکبار مصرف</div>
                                </div>
                                <div class="terms_link_wrapper">
                                    <div data-url="#log_password_form" class="link toggle_login_form">ورود با رمز عبور
                                    </div>
                                </div>
                            </div>
                            <div class="each_login_form" id="submit_otp_form">
                                <h6 class="login_form_title mb-2 mt-4">کد تایید را وارد کنید</h6>
                                <div class="otp_login_text ">
                                    جهت ورود به پنل شماره موبایل خود را وارد نمایید.
                                </div>
                                <div class="terms_link_wrapper mb-3">
                                    <div data-url="#login_otp_form" class="link toggle_login_form fs-11px text-primary">
                                        اصلاح شماره
                                    </div>
                                </div>
                                <div class="login_form_wrapper mb-3">
                                    <div class="form-group mb-2">
                                        <div class="step_form otp_form" id="otp_input_form">
                                            <input type="text"
                                                   class="otp_input form-control form-control-outlined dir_ltr"
                                                   id="otp_1" inputmode="numeric"
                                                   maxlength="1">
                                            <input type="text"
                                                   class="otp_input form-control form-control-outlined dir_ltr"
                                                   id="otp_2" inputmode="numeric"
                                                   maxlength="1">
                                            <input type="text"
                                                   class="otp_input form-control form-control-outlined dir_ltr"
                                                   id="otp_3" inputmode="numeric"
                                                   maxlength="1">
                                            <input type="text" class="otp_input form-control form-control-outlined
                                            dir_ltr" id="otp_4" inputmode="numeric"
                                                   maxlength="1">
                                        </div>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <div class="btn btn-block btn-primary submit_otp">تایید</div>
                                </div>
                                <div class="otp_timer disabled">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="kasebi_logo_co col-md-8 col-12">
                    <div class="login_image_wrapper">
                        <img src="<?php echo KCP_ASSETS_URL; ?>image/login.jpg?v=2" alt="" width="580">
                    </div>
                    <h2 class="kasebi_title fw-bolder mb-3"><?php echo $title; ?></h2>
                    <h6 class="kasebi_subtitle fw-medium"><?php echo $subtitle; ?></h6>
                </div>
            </div>
        </div>
    </div>
	<?php
	return ob_get_clean();
} );

add_shortcode( 'crm-password', function() {
	$logo = get_option( 'crm_panel_logo' );
	if ( ! $logo ) {
		$logo = KCP_ASSETS_URL . 'image/kasebi_logo.png';
	}
	ob_start();
	?>
    <div class="nk-wrap justify-center ui-rounder">
        <div class="container px-4 py-5 px-md-5 text-center my-5">
            <div class="row align-items-center ">
                <div class="login_form_col col-md-4 col-12 mb-5">
                    <div class="card card-bordered">
                        <div class="card-inner p-5">
                            <div class="website_logo_wrapper">
                                <img src="<?php echo $logo; ?>" alt="" width="120">
                            </div>
                            <h5 class="login_form_title mb-2 mt-4">تغییر رمز عبور</h5>
                            <div class="login_form_subtitle mb-3">
                                جهت تغییر رمز عبور اطلاعات زیر را تکمیل نمایید
                            </div>
                            <div class="login_form_wrapper">
                                <div class="form-group mb-2">
                                    <div class="form-control-wrap">
                                        <a class="form-icon form-icon-right passcode-switch"
                                           data-target="old_password">
                                            <em class="passcode-icon icon-show icon ni ni-eye"></em>
                                            <em class="passcode-icon icon-hide icon ni ni-eye-off"></em></a>
                                        <input type="password" class="form-control form-control-outlined"
                                               id="old_password"
                                               name="old_password">
                                        <label class="form-label-outlined" for="old_password">رمز عبور قدیمی</label>
                                    </div>
                                </div>
                                <div class="form-group mb-2">
                                    <div class="form-control-wrap">
                                        <a class="form-icon form-icon-right passcode-switch"
                                           data-target="new_password">
                                            <em class="passcode-icon icon-show icon ni ni-eye"></em>
                                            <em class="passcode-icon icon-hide icon ni ni-eye-off"></em></a>
                                        <input type="password" class="form-control form-control-outlined"
                                               id="new_password"
                                               name="new_password">
                                        <label class="form-label-outlined" for="new_password">رمز عبور جدید</label>
                                    </div>
                                </div>
                                <div class="form-group mb-2">
                                    <div class="form-control-wrap">
                                        <a class="form-icon form-icon-right passcode-switch"
                                           data-target="confirm_password">
                                            <em class="passcode-icon icon-show icon ni ni-eye"></em>
                                            <em class="passcode-icon icon-hide icon ni ni-eye-off"></em></a>
                                        <input type="password" class="form-control form-control-outlined"
                                               id="confirm_password"
                                               name="password">
                                        <label class="form-label-outlined" for="confirm_password">تکرار رمز عبور</label>
                                    </div>
                                </div>
                            </div>
                            <div class="mb-3">
                                <div class="btn btn-block btn-primary change_pass">تغییر رمز</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="kasebi_logo_co col-md-8 col-12">
                    <div class="login_image_wrapper">
                        <img src="<?php echo KCP_ASSETS_URL; ?>image/password.jpg" alt="" width="580">
                    </div>
                </div>
            </div>
        </div>
    </div>
	<?php
	return ob_get_clean();
} );
