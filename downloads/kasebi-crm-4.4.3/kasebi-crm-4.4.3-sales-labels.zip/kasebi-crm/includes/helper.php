<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

function crm_get_template( $path, $args = [] ) {
	ob_start();
	extract( $args );
	$role          = nooshika_get_user_role( get_current_user_id() );
	$template_path = KCP_TEMPLATE_PATH . $path;
	if ( file_exists( KCP_TEMPLATE_PATH . 'u-' . $role . '/' . $path ) ) {
		$template_path = KCP_TEMPLATE_PATH . 'u-' . $role . '/' . $path;
	}
	$template_path = apply_filters( 'crm_template_path', $template_path, $path, $args );
	include $template_path;
	
	return ob_get_clean();
}

function crm_get_user_marketer( $user_id = NULL ) {
	if ( ! $user_id ) {
		$user_id = get_current_user_id();
	}
	$marketer_id = get_user_meta( $user_id, KCP_MARKETER_META, TRUE );
	if ( ! $marketer_id ) {
		return FALSE;
	}
	
	return $marketer_id;
}

function crm_plugin_activated() {
	if ( function_exists( 'kasebi_create_new_page' ) ) {
		kasebi_create_new_page( 'crm', '[kasebi-crm]', 'مدیریت مشتریان' );
		kasebi_create_new_page( 'crm-login', '[crm-login]', 'ورود به پنل مدیریت مشتریان' );
		kasebi_create_new_page( 'crm-password', '[crm-password]', 'تغییر رمزعبور' );
	}
	kcp_create_wordpress_mu_plugin();
	kcp_activate_necessary_kcp_ajax_plugins();
}

function kcp_create_wordpress_mu_plugin() {
	$mu_plugin_dir = WPMU_PLUGIN_DIR;
	if ( ! file_exists( $mu_plugin_dir ) ) {
		mkdir( $mu_plugin_dir );
	}
	$mu_plugin_file_dec = $mu_plugin_dir . '/kcp-ajax.php';
	if ( file_exists( $mu_plugin_file_dec ) ) {
		unlink( $mu_plugin_file_dec );
	}
	$mu_plugin_file = $mu_plugin_dir . '/kcp-ajax.php';
	if ( ! file_exists( $mu_plugin_file ) ) {
		$mu_plugin_content = file_get_contents( KCP_TEMPLATE_PATH . 'mu-plugin/kcp-ajax.php' );
		file_put_contents( $mu_plugin_file, $mu_plugin_content );
	}
}

function kcp_activate_necessary_kcp_ajax_plugins() {
	$necessary_plugins = [
		'kasebi-crm/kasebi-crm.php',
		'nooshika-main/nooshika-main.php',
		'woo-wallet/woo-wallet.php',
		'woocommerce/woocommerce.php',
	];
	$ajax_plugins      = get_option( 'kcp_ajax_active_plugins' );
	if ( ! $ajax_plugins ) {
		$ajax_plugins = [];
	}
	$ajax_plugins = array_merge( $ajax_plugins, $necessary_plugins );
	$ajax_plugins = array_unique( $ajax_plugins );
	update_option( 'kcp_ajax_active_plugins', $ajax_plugins );
}

function kcp_sanitize_url_for_template_path( $url ): string {
	$path = str_replace( home_url(), '', $url );
	$path = substr( $path, 1 );
	
	return untrailingslashit( $path );
}

function get_crm_page_title( $page ) {
	$pages  = get_crm_pages_list();
	$titles = [];
	foreach ( $pages as $slug => $page_data ) {
		if ( $page_data['type'] == 'page' ) {
			$titles[ $slug ] = $page_data['title'];
		}
		if ( $page_data['type'] == 'sub' ) {
			foreach ( $page_data['sub'] as $sub_slug => $sub_data ) {
				$titles[ $sub_slug ] = $sub_data['title'];
			}
		}
	}
	
	return $titles[ $page ];
}

function get_crm_end_point( $path = '' ): array {
	if ( ! $path ) {
		global $wp;
		$path = $wp->request;
	}
	$path    = ltrim( $path, '/' );
	$path    = explode( '/', $path );
	$crm_key = array_search( 'crm', $path );
	unset( $path[ $crm_key ] );
	$path = array_values( $path );
	if ( ! isset( $path[0] ) ) {
		$list        = get_crm_pages_list();
		$user_id     = get_current_user_id();
		$role        = nooshika_get_user_role( $user_id );
		$x           = array_key_first( $list );
		$valid_roles = $list[ $x ]['valid_roles'];
		if ( $valid_roles == 'all' ) {
			return [
				$x,
			];
		}
		if ( in_array( $role, $valid_roles ) ) {
			return [
				$x,
			];
		} else {
			unset( $list[ $x ] );
			$x = array_key_first( $list );
		}
		
		return [
			$x,
		];
	}
	
	return $path;
}

function get_crm_pages_list() {
	$pages = [
		'dashboard'     => [
			'type'        => 'page',
			'title'       => 'میزکار',
			'icon'        => 'dashboard',
			'valid_roles' => [
				'salesman',
				'phone_salesman',
				'cashier',
				'sales_cs',
				'treasurer_accountant',
				'sales_manager',
				'sales_cs',
				'after_sales',
				'support_manager',
				'support_orders',
				'finance_manager',
				'administrator',
			],
		],
		'hr-reports'    => [
			'type'        => 'page',
			'title'       => 'گزارشات کارمندان',
			'icon'        => 'todo',
			'valid_roles' => 'all',
		],
		'hr-requests'   => [
			'type'        => 'page',
			'title'       => 'درخواست سازمانی',
			'icon'        => 'archive',
			'valid_roles' => [
				'salesman',
				'phone_salesman',
				'cashier',
				'sales_cs',
				'treasurer_accountant',
				'sales_manager',
				'sales_cs',
				'after_sales',
				'support_manager',
				'support_orders',
				'finance_manager',
				'administrator',
			],
		],
		'divider-users' => [
			'type'        => 'divider',
			'title'       => 'دپارتمان مشتریان',
			'valid_roles' => [
				'salesman',
				'phone_salesman',
				'cashier',
				'sales_cs',
				'treasurer_accountant',
				'sales_manager',
				'sales_cs',
				'after_sales',
				'support_manager',
				'support_orders',
				'finance_manager',
				'administrator',
			],
		],
		'users'         => [
			'type'        => 'page',
			'title'       => 'مشتریان',
			'icon'        => 'users',
			'valid_roles' => [
				'salesman',
				'phone_salesman',
				'cashier',
				'sales_cs',
				'treasurer_accountant',
				'sales_manager',
				'sales_cs',
				'after_sales',
				'support_manager',
				'support_orders',
				'finance_manager',
				'administrator',
			],
		],
		'activity'      => [
			'type'        => 'sub',
			'title'       => 'ارتباط مشتریان',
			'icon'        => 'list-index',
			'valid_roles' => [
				'salesman',
				'phone_salesman',
				'cashier',
				'sales_cs',
				'treasurer_accountant',
				'sales_manager',
				'sales_cs',
				'after_sales',
				'support_manager',
				'support_orders',
				'finance_manager',
				'administrator',
			],
			'sub'         => [
				'users-action' => [
					'type'        => 'page',
					'title'       => 'فعالیت ها',
					'valid_roles' => [
						'salesman',
						'phone_salesman',
						'cashier',
						'sales_cs',
						'treasurer_accountant',
						'sales_manager',
						'sales_cs',
						'after_sales',
						'support_manager',
						'support_orders',
						'finance_manager',
						'administrator',
					],
				],
				'users-track'  => [
					'type'        => 'page',
					'title'       => 'پیگیری ها',
					'valid_roles' => [
						'salesman',
						'phone_salesman',
						'cashier',
						'sales_cs',
						'treasurer_accountant',
						'sales_manager',
						'sales_cs',
						'after_sales',
						'support_manager',
						'support_orders',
						'finance_manager',
						'administrator',
					],
				],
				'users-call'   => [
					'type'        => 'page',
					'title'       => 'درخواست های مشتریان',
					'valid_roles' => [
						'salesman',
						'phone_salesman',
						'cashier',
						'sales_cs',
						'treasurer_accountant',
						'sales_manager',
						'sales_cs',
						'after_sales',
						'support_manager',
						'support_orders',
						'finance_manager',
						'administrator',
					],
				],
			],
		],
		'divider-sale'  => [
			'type'        => 'divider',
			'title'       => 'دپارتمان فروش',
			'valid_roles' => [
				'salesman',
				'phone_salesman',
				'cashier',
				'sales_cs',
				'treasurer_accountant',
				'sales_manager',
				'sales_cs',
				'after_sales',
				'support_manager',
				'support_orders',
				'finance_manager',
				'administrator',
			],
		],
		'sale-orders'   => [
			'type'        => 'page',
			'title'       => 'سفارشات',
			'icon'        => 'cart',
			'valid_roles' => [
				'salesman',
				'phone_salesman',
				'cashier',
				'sales_cs',
				'treasurer_accountant',
				'sales_manager',
				'sales_cs',
				'after_sales',
				'support_manager',
				'support_orders',
				'support_hr',
				'finance_manager',
				'administrator',
			],
		],
		'sale-reports'  => [
			'type'        => 'page',
			'title'       => 'گزارشات فروش',
			'icon'        => 'bar-chart',
			'valid_roles' => [
				'sales_manager',
				'administrator',
			],
		],
		'divider-hr'    => [
			'type'        => 'divider',
			'title'       => 'دپارتمان اداری',
			'valid_roles' => [
				'administrator',
			],
		],
		'hr-employees'  => [
			'type'        => 'page',
			'title'       => 'منابع انسانی',
			'icon'        => 'account-setting',
			'valid_roles' => [
				'administrator',
			],
		],
		
		'divider-admin' => [
			'type'        => 'divider',
			'title'       => '',
			'valid_roles' => [
				'administrator',
			],
		],
		
		'settings-products' => [
			'type'        => 'page',
			'title'       => 'ویرایش محصولات',
			'icon'        => 'package',
			'valid_roles' => [
				'administrator',
				'sales_manager',
			],
		],
		'settings'          => [
			'type'        => 'sub',
			'title'       => 'تنظیمات',
			'icon'        => 'setting',
			'valid_roles' => [
				'administrator',
			],
			'sub'         => [
				'settings-category' => [
					'type'  => 'page',
					'title' => 'طبقه بندی مشتریان',
				],
				'settings-import'   => [
					'type'  => 'page',
					'title' => 'ایمپورت',
				],
				'settings'          => [
					'type'  => 'page',
					'title' => 'تنظیمات',
				],
			],
		],
	
	];
	
	return apply_filters( 'nooshika_crm_pages_list', $pages );
}

function get_crm_single_page_list() {
	$pages = [
		'user'       => [
			'title'  => 'مشتری',
			'parent' => 'users',
		],
		'employee'   => [
			'title'  => 'کارشناس فروش',
			'parent' => 'employees',
		],
		'order-new'  => [
			'title'  => 'ثبت سفارش',
			'parent' => 'sale-orders',
		],
		'order-edit' => [
			'title'  => 'ویرایش سفارش',
			'parent' => 'sale-orders',
		],
	];
	
	return apply_filters( 'nooshika_crm_single_page_list', $pages );
}

function kcp_get_cut_carpet_tag_identifiers(): array {
	return apply_filters( 'kcp_cut_carpet_tag_identifiers', [
		'cut-carpet',
		'cut_carpet',
		'cuttable-carpet',
		'boreshi',
		'برشی',
	] );
}

function kcp_product_has_cut_carpet_tag( $product ): bool {
	if ( ! $product instanceof WC_Product ) {
		$product = wc_get_product( $product );
	}
	if ( ! $product ) {
		return FALSE;
	}
	
	$product_ids = [ $product->get_id() ];
	if ( $product->is_type( 'variation' ) ) {
		$product_ids[] = $product->get_parent_id();
	}
	
	foreach ( array_filter( array_map( 'absint', $product_ids ) ) as $product_id ) {
		if ( has_term( kcp_get_cut_carpet_tag_identifiers(), 'product_tag', $product_id ) ) {
			return TRUE;
		}
	}
	
	return FALSE;
}

function kcp_get_cut_carpet_tag_term_ids(): array {
	$identifiers = kcp_get_cut_carpet_tag_identifiers();
	$terms       = get_terms( [
		'taxonomy'   => 'product_tag',
		'hide_empty' => FALSE,
	] );
	
	if ( is_wp_error( $terms ) || empty( $terms ) ) {
		return [];
	}
	
	$term_ids = [];
	foreach ( $terms as $term ) {
		if ( in_array( $term->slug, $identifiers, TRUE ) || in_array( $term->name, $identifiers, TRUE ) ) {
			$term_ids[] = (int) $term->term_id;
		}
	}
	
	return array_values( array_unique( $term_ids ) );
}

function kcp_page_has_filter( $args, $defaults ) {
	unset( $defaults['page_number'] );
	unset( $defaults['per_page'] );
	foreach ( $defaults as $key => $value ) {
		if ( $args[ $key ] != $value ) {
			return TRUE;
		}
	}
	
	return FALSE;
}

function get_user_name_for_avatar( $user_id = NULL, $avatar = FALSE ): string {
	if ( ! $user_id ) {
		$user_id = get_current_user_id();
	}
	if ( $avatar ) {
		$key = get_user_meta( $user_id, 'nooshika_user_avatar_url', TRUE );
		if ( $key ) {
			$upload_dir = wp_upload_dir();
			
			$key = $upload_dir['baseurl'] . $key;
			
			return "<img src='$key' alt='avatar' class='avatar photo'>";
		}
	}
	$first_name = get_user_meta( $user_id, 'first_name', TRUE );
	$last_name  = get_user_meta( $user_id, 'last_name', TRUE );
	
	return mb_substr( $first_name, 0, 1 ) . "‌" . mb_substr( $last_name, 0, 1 );
}

function sanitize_date_for_filter( $date ) {
	return date( 'Y-m-d', strtotime( $date ) );
}

function get_actions_meta( $action_id, $key ) {
	global $wpdb;
	$meta_table = $wpdb->prefix . 'kcp_action_meta';
	$is_set     = $wpdb->get_results(
		"SELECT * FROM {$meta_table} WHERE meta_key = '{$key}' AND action_id = '{$action_id}'",
		ARRAY_A );
	if ( $is_set ) {
		return $is_set[0]['meta_value'];
	} else {
		return FALSE;
	}
}

function crm_handle_upload_file( $file, $folder ) {
	$allowed_mimes = [
		'jpg'  => 'image/jpeg',
		'jpeg' => 'image/jpeg',
		'png'  => 'image/png',
		'gif'  => 'image/gif',
		'pdf'  => 'application/pdf',
		'doc'  => 'application/msword',
		'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
		'xls'  => 'application/vnd.ms-excel',
		'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
		'txt'  => 'text/plain',
	];
	if ( ! isset( $file['tmp_name'], $file['name'], $file['type'] ) || ! file_exists( $file['tmp_name'] ) ) {
		return FALSE;
	}
	
	$filename  = $file['name'];
	$file_ext  = strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) );
	$mime_type = mime_content_type( $file['tmp_name'] );
	if ( ! isset( $allowed_mimes[ $file_ext ] ) || stripos( $mime_type, $allowed_mimes[ $file_ext ] ) === FALSE ) {
		return FALSE;
	}
	$upload_dir  = wp_upload_dir();
	$upload_path = $upload_dir['basedir'] . '/' . $folder;
	$upload_url  = $upload_dir['baseurl'] . '/' . $folder;
	
	if ( ! file_exists( $upload_path ) ) {
		wp_mkdir_p( $upload_path );
	}
	$base_name  = pathinfo( $filename, PATHINFO_FILENAME );
	$base_name  = preg_replace( '/[^A-Za-z0-9_\-]/', '-', $base_name );
	$saved_name = $base_name . '_' . uniqid() . '.' . $file_ext;
	$full_path  = $upload_path . '/' . $saved_name;
	$full_url   = $upload_url . '/' . $saved_name;
	
	if ( move_uploaded_file( $file['tmp_name'], $full_path ) ) {
		$DB       = new kcp_db();
		$filename = $_POST['file_name'] ?? $filename;
		$DB->add_uploaded_file_record( [
			'saved_name'    => $saved_name,
			'original_name' => $filename,
			'file_path'     => str_replace( ABSPATH, '/', $full_path ),
			'file_url'      => $full_url,
		] );
		
		return $full_url;
	}
	
	return FALSE;
}

function get_user_badge_color( $user_id ) {
	$user_color = get_user_meta( $user_id, 'user_color', TRUE ) ?: 'primary';
	
	return 'bg-' . $user_color;
}

function is_valid_phone( $phone ) {
	$phone = nooshika_sanitize_numbers( $phone );
	$phone = str_replace( '+98', '0', $phone );
	$phone = str_replace( ' ', '', $phone );
	$phone = str_replace( '-', '', $phone );
	$phone = str_replace( '+', '', $phone );
	$phone = str_replace( '(', '', $phone );
	$phone = str_replace( ')', '', $phone );
	$phone = str_replace( '_', '', $phone );
	$phone = str_replace( '.', '', $phone );
	$phone = str_replace( ',', '', $phone );
	$phone = str_replace( '/', '', $phone );
	$phone = remove_zero_from_phone( $phone );
	$phone = substr( $phone, - 10 );
	if ( strlen( $phone ) != 10 ) {
		return FALSE;
	}
	
	return $phone;
}

function crm_get_user_total_spend( $user_id ) {
	$orders = wc_get_orders(
		[
			'customer' => $user_id,
			'status'   => 'completed',
		]
	);
	$total  = 0;
	foreach ( $orders as $order ) {
		$total += $order->get_total();
	}
	
	return $total;
}

function convert_number_to_text( $number ) {
	$texts = [
		'میلیارد' => 1000000000,
		'میلیون'  => 1000000,
		'هزار'    => 1000,
	];
	foreach ( $texts as $text => $value ) {
		if ( $number >= $value ) {
			$number = $number / $value;
			$number = number_format( $number, 2 );
			$number = str_replace( '.00', '', $number );
			
			return $number . ' ' . $text;
		}
	}
	
	return $number;
}

function kcp_get_all_roles( $include_admin = TRUE ) {
	$roles = [
		'administrator'   => 'مدیر کل',
		'finance_manager' => 'مدیر مالی',
		'cashier'         => 'صندوق‌دار',
		'sales_manager'   => 'مدیر فروش',
		'salesman'        => 'کارشناس فروش تلفنی',
        'phone_salesman'  => 'کارشناس فروش حضوری',
		'sales_cs'        => 'امور مشتریان',
		'employee'        => 'کارمند',
	];
	if ( ! $include_admin ) {
		unset( $roles['administrator'] );
	}
	
	return array_keys( $roles );
}

function kcp_get_role_label( $role ): string {
	$roles = [
		'administrator'   => 'مدیر کل',
		'finance_manager' => 'مدیر مالی',
		'cashier'         => 'صندوق‌دار',
		'sales_manager'   => 'مدیر فروش',
		'salesman'        => 'کارشناس فروش تلفنی',
        'phone_salesman'  => 'کارشناس فروش حضوری',
		'sales_cs'        => 'امور مشتریان',
		'employee'        => 'کارمند',
	];
	
	return $roles[ $role ] ?? 'مشتری';
}

function kasebi_get_orders( $product_id = '', $status_is = '', $marketer_id = '', $referrer = '', $after = '2000-01-01 00:00:00', $before = '2030-01-01 23:59:59', $per_page = 10, $offset = 0 ): array {
	global $wpdb;
	$order_meta   = $wpdb->prefix . 'wc_orders_meta';
	$order_table  = $wpdb->prefix . 'wc_order_stats';
	$select_query = "SELECT DISTINCT $order_table.order_id FROM $order_table";
	$total_query  = "SELECT COUNT(DISTINCT $order_table.order_id) FROM $order_table";
	$query        = '';
	if ( $product_id ) {
		$query .= " LEFT JOIN {$wpdb->prefix}wc_order_product_lookup product_lookup ON $order_table.order_id = product_lookup.order_id";
	}
	$query .= ' WHERE 1=1';
	if ( $product_id ) {
		$query .= " AND product_lookup.product_id = $product_id";
	}
	$query .= " AND ($order_table.status IN ( '" . implode( "','", $status_is ) . "' ))";
	if ( $marketer_id ) {
		$query .= " AND ($order_table.order_id IN ( SELECT order_id FROM {$order_meta}
            WHERE meta_key = 'marketer_id' AND meta_value ='{$marketer_id}'))";
	}
	if ( $referrer ) {
		$query .= " AND ($order_table.order_id IN ( SELECT order_id FROM {$order_meta}
            WHERE meta_key = '_wc_order_attribution_referrer' AND meta_value LIKE '%{$referrer}%'))";
	}
	$query .= " AND $order_table.date_created <= '$before' AND $order_table.date_created >= '$after'";
	
	$total_query   .= $query . ';';
	$query         .= "  ORDER BY $order_table.date_created DESC LIMIT $per_page OFFSET $offset;";
	$select_query  .= $query;
	$results       = $wpdb->get_results( $select_query, ARRAY_A );
	$total_results = $wpdb->get_var( $total_query );
	
	return [
		'orders' => $results,
		'count'  => $total_results,
	];
}

function formatNumberToPersian( $num ) {
	if ( $num >= 1_000_000_000 ) {
		return number_format( $num / 1_000_000_000, 2 ) . " میلیارد";
	} elseif ( $num >= 1_000_000 ) {
		return number_format( $num / 1_000_000, 2 ) . " میلیون";
	} elseif ( $num >= 1_000 ) {
		return number_format( $num / 1_000, 2 ) . " هزار";
	}
	
	return number_format( $num, 2 );
}

function ncp_get_user_levels(): array {
	return [
		'bronze' => [
			'label' => 'برنزی',
			'min'   => 1000,
			'max'   => 49999999,
			'badge' => 'bg-gray',
		],
		'silver' => [
			'label' => 'نقره‌ای',
			'min'   => 50000000,
			'max'   => 119999999,
			'badge' => 'bg-info',
		],
		'gold'   => [
			'label' => 'طلایی',
			'min'   => 120000000,
			'max'   => PHP_INT_MAX,
			'badge' => 'bg-warning',
		],
	];
}

function ncp_get_user_level_by_total( $total ) {
	$levels = ncp_get_user_levels();
	
	foreach ( $levels as $key => $level ) {
		if ( $total >= $level['min'] && $total <= $level['max'] ) {
			return [
				'key'   => $key,
				'label' => $level['label'],
				'badge' => $level['badge'],
			];
		}
	}
	
	return NULL;
}

function ncp_get_taxonomy_filter_options( $taxonomy ): array {
	$types = get_option( "kcp_user_$taxonomy", [] );
	
	return array_combine(
		array_keys( $types ),
		array_column( $types, 'label' )
	);
}

function kcp_get_user_list( $search, $limit = 10, $offset = 0 ): array|object|null {
	global $wpdb;
	$search = nooshika_sanitize_numbers( $search );
	$search = remove_zero_from_phone( $search );
	$wild   = '%';
	
	$limit_sql  = '';
	$offset_sql = '';
	
	if ( $limit != - 1 ) {
		$limit_sql  = " LIMIT " . intval( $limit );
		$offset_sql = " OFFSET " . intval( $offset );
	}
	
	if ( is_numeric( $search ) ) {
		$statement = $wild . $wpdb->esc_like( $search ) . $wild;
		$query     = $wpdb->prepare(
			"SELECT DISTINCT user_id
			 FROM {$wpdb->usermeta}
			 WHERE meta_key = 'nooshika_phone_num'
			 AND meta_value LIKE %s {$limit_sql} {$offset_sql}",
			$statement
		);
	} else {
		$names = separate_first_last_from_name( $search );
		$first = $names['first'];
		$last  = $names['last'];
		$first = $wild . $wpdb->esc_like( $first ) . $wild;
		
		if ( $last ) {
			$last  = $wild . $wpdb->esc_like( $last ) . $wild;
			$query = "
				SELECT DISTINCT ID as user_id
				FROM {$wpdb->users} as main
				INNER JOIN {$wpdb->usermeta} as meta1 ON meta1.user_id=main.ID
				INNER JOIN {$wpdb->usermeta} as meta2 ON meta2.user_id=main.ID
				WHERE (meta1.meta_key='first_name' AND meta1.meta_value LIKE '$first')
				AND (meta2.meta_key='last_name' AND meta2.meta_value LIKE '$last')
				{$limit_sql} {$offset_sql}";
		} else {
			$query = "
				SELECT DISTINCT user_id
				FROM {$wpdb->usermeta}
				WHERE (meta_key='first_name' OR meta_key='last_name')
				AND meta_value LIKE '$first'
				{$limit_sql} {$offset_sql}";
		}
	}
	
	$users = $wpdb->get_results( $query, ARRAY_A );
	
	$count_q = preg_replace( '/SELECT\s+distinct\s+ID.*?FROM/si', 'SELECT count(distinct ID) as total FROM', $query );
	$count_q = preg_replace( '/SELECT\s+distinct\s+user_id.*?FROM/si', 'SELECT count(distinct user_id) as total FROM', $count_q );
	$count_q = preg_replace( '/LIMIT.*$/si', '', $count_q );
	
	$total = $wpdb->get_var( $count_q );
	
	if ( ! $users ) {
		$search = $wpdb->esc_like( strip_tags( $_POST['search'] ) );
		$query  = "
			SELECT DISTINCT ID as user_id
			FROM wp_users
			WHERE display_name LIKE '%$search%'
			{$limit_sql} {$offset_sql}";
		$users  = $wpdb->get_results( $query, ARRAY_A );
	}
	if ( $total ) {
		return [
			'users' => $users,
			'total' => $total,
		];
	}
	
	return $users;
}

function convert_seconds_to_text( $total_duration ) {
	if ( $total_duration <= 0 ) {
		return 'بدون زمان';
	}
	
	$days    = floor( $total_duration / 86400 );
	$hours   = floor( ( $total_duration % 86400 ) / 3600 );
	$minutes = floor( ( $total_duration % 3600 ) / 60 );
	$seconds = $total_duration % 60;
	
	$parts = [];
	$days ? $parts[] = "{$days} روز" : NULL;
	$hours ? $parts[] = "{$hours} ساعت" : NULL;
	$minutes ? $parts[] = "{$minutes} دقیقه" : NULL;
	$seconds ? $parts[] = "{$seconds} ثانیه" : NULL;
	
	return implode( ' و ', $parts );
}

function get_user_meta_keys() {
	$DB               = new kcp_db();
	$intros           = $DB->get_introduce_methods();
	$all_roles        = kcp_get_all_roles( FALSE );
	$employees        = get_users( [
		'fields'   => 'ids',
		'orderby'  => 'ID',
		'order'    => 'DESC',
		'role__in' => $all_roles,
	] );
	$employee_options = [];
	
	foreach ( $employees as $employee_id ) {
		$employee_options[ (string) $employee_id ] = [
			'label' => get_user_name_by_id( $employee_id ),
		];
	}
	
	return [
		'first_name'            => [
			'label' => 'نام',
		],
		'last_name'             => [
			'label' => 'نام خانوادگی',
		],
		'birthday'              => [
			'type'  => 'date',
			'label' => 'تاریخ تولد',
		],
		'gender'                => [
			'type'    => 'select',
			'label'   => 'جنسیت',
			'options' => [
				'male'   => [
					'label' => 'مرد',
				],
				'female' => [
					'label' => 'زن',
				],
				'other'  => [
					'label' => 'سایر',
				],
			],
		],
		'shop_name'             => [
			'label' => 'نام فروشگاه',
		],
		'national_id'           => [
			'label' => 'کد ملی',
		],
		'user_phone'            => [
			'label' => 'شماره همراه',
		],
		'user_mobile'           => [
			'label' => 'شماره ثابت',
		],
		'user_fax'              => [
			'label' => 'همراه دوم',
		],
		'job'                   => [
			'label' => 'شغل',
		],
		'creator_id'            => [
			'type'    => 'select',
			'label'   => 'مسئول فروش تلفنی',
			'options' => $employee_options,
		],
		'ncp_user_intro_method' => [
			'type'    => 'select',
			'label'   => 'نحوه آشنایی',
			'options' => $intros,
		],
		'intro_method_other'    => [
			'state'      => 'conditional',
			'label'      => 'سایر نحوه آشنایی',
			'width'      => '100%',
			'conditions' => [
				'meta'  => 'ncp_user_intro_method',
				'value' => 'other',
			],
		],
		'intro_method_company'  => [
			'state'      => 'conditional',
			'type'       => 'select',
			'width'      => '100%',
			'label'      => 'سازمان طرف قرار داد',
			'conditions' => [
				'meta'  => 'ncp_user_intro_method',
				'value' => 'other-company',
			],
			'options'    => [
				'education'       => [
					'label' => 'آموزش و پرورش',
				],
				'social-retired'  => [
					'label' => 'بازنشستگان تامین اجتماعی',
				],
				'bandar-amirabad' => [
					'label' => 'سازمان بندر امیرآباد',
				],
				'water'           => [
					'label' => 'آب و فاضلاب',
				],
				'meteorology'     => [
					'label' => 'هواشناسی',
				],
				'medical'         => [
					'label' => 'دانشگاه علوم پزشکی',
				],
				'customs'         => [
					'label' => 'اداره کل گمرک',
				],
				'comite-emdad'    => [
					'label' => 'کمیته امداد',
				],
				'jihad'           => [
					'label' => 'جهاد کشاورزی',
				],
			],
		],
		'postal_code'           => [
			'label' => 'کد پستی',
		],
		'email'                 => [
			'label' => 'ایمیل',
		],
	];
}

function kcp_meta_is_visible( array $meta, int $user_id ): bool {
	if ( empty( $meta['state'] ) || $meta['state'] !== 'conditional' ) {
		return TRUE;
	}
	$cond     = $meta['conditions'] ?? [];
	$meta_key = $cond['meta'] ?? '';
	if ( $meta_key === '' ) {
		return TRUE;
	}
	$expected = $cond['value'] ?? NULL;        // string|array|null
	$operator = $cond['operator'] ?? '==';
	$actual   = get_user_meta( $user_id, $meta_key, TRUE );
	
	$is_match = is_array( $expected ) ? in_array( $actual, $expected, TRUE ) : ( $actual === $expected );
	
	return ( $operator === '!=' ) ? ! $is_match : $is_match;
}

function crm_get_product_by_sku( $sku ) {
	global $wpdb;
	$query      = "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_sku' AND meta_value in ('{$sku}','0{$sku}','00{$sku}')";
	$product_id = $wpdb->get_var( $query );
	if ( ! $product_id ) {
		return FALSE;
	}
	
	return $product_id;
}

function nooshika_fill_sms_array_shortcodes( $sms_array, $user_id ) {
	$tags = [
		'first_name' => 'first_name',
		'last_name'  => 'last_name',
		'phone'      => 'marketer_phone_num',
	];
	foreach ( $sms_array as $key => $value ) {
		if ( isset( $tags[ $value ] ) ) {
			$sms_array[ $key ] = get_user_meta( $user_id, $tags[ $value ], TRUE );
		} elseif ( $value == 'date' ) {
			$sms_array[ $key ] = date_i18n( 'Y/m/d' );
		}
	}
	
	return $sms_array;
}

function crm_send_sms( $phone, $data, $template ) {
	$api              = get_option( 'nooshika_sms_kavenegar_api' );
	$url              = 'https://api.kavenegar.com/v1/' . $api . '/verify/lookup.json';
	$data['template'] = $template;
	$data['receptor'] = $phone;
	$params           = http_build_query( $data );
	$url              .= '/?' . $params;
	
	return nooshika_run_curl( $url );
}

function crm_get_viewable_statuses_for_user(): array {
	$roles = nooshika_get_user_role( get_current_user_id(), TRUE );
	
	$all_statuses = [
		'wc-pending',
		'wc-factor',
		'wc-confirming',
		'wc-processing',
		'wc-confirmed',
		'wc-stock-delivery',
		'wc-completed',
		'wc-delivered',
		'wc-cancelled',
		'wc-refund-submitted',
		'wc-refund-confirm',
		'wc-refund-paid',
		'wc-refund-delivered',
		'wc-refund-cancelled',
	];
	
	// تعریف دسترسی هر نقش به مشاهده وضعیت‌ها (مثال: همه وضعیت‌ها برای همه نقش‌ها باز است)
	$role_statuses = [
		'administrator'        => $all_statuses,
		'finance_manager'      => $all_statuses,
		'cashier'              => $all_statuses,
		'treasurer_accountant' => $all_statuses,
		'warehouse_accountant' => $all_statuses,
		'sales_manager'        => $all_statuses,
		'salesman'             => $all_statuses,
        'phone_salesman'       => $all_statuses,
		'sales_cs'             => $all_statuses,
		'after_sales'          => $all_statuses,
		'support_manager'      => $all_statuses,
		'support_qc'           => $all_statuses,
		'support_orders'       => $all_statuses,
		'support_warehouse'    => $all_statuses,
		'support_worker'       => $all_statuses,
		'support_host'         => $all_statuses,
	];
	
	$viewable = [];
	foreach ( $roles as $role ) {
		if ( isset( $role_statuses[ $role ] ) ) {
			$viewable = array_merge( $viewable, $role_statuses[ $role ] );
		}
	}
	
	$viewable = array_unique( $viewable );
	
	return $viewable;
}

function crm_get_valid_next_status( string $current_status ): array {
	$roles          = nooshika_get_user_role( get_current_user_id(), TRUE );
	$current_status = str_replace( 'wc-', '', $current_status );
	
	// وضعیت‌های بعدی مجاز برای هر وضعیت
	$valid_transitions = [
		'pending'    => [
			'processing',
			'cancelled',
		],
		'processing' => [
			'completed',
			'cancelled',
		],
		'completed'  => [
			'delivered',
			'cancelled',
		],
	];
	
	// نقش‌هایی که مجاز به تغییر هر وضعیت هستند (بدون ادمین)
	$role_edit_permission = [
		'pending'          => [
			'salesman',
			'phone_salesman',
			'sales_manager',
		],
		'factor'           => [ 'sales_manager' ],
		'confirming'       => [
			'finance_manager',
			'cashier',
			'treasurer_accountant',
		],
		'processing'       => [
			'warehouse_accountant',
			'warehouse',
			'sales_manager',
		],
		'confirmed'        => [
			'warehouse_accountant',
			'warehouse',
		],
		'stock-delivery'   => [
			'warehouse_accountant',
			'warehouse',
			'support_warehouse',
		],
		'completed'        => [
			'support_warehouse',
			'warehouse',
		],
		'delivered'        => [
			'support_worker',
			'support_host',
		],
		'cancelled'        => [
			'sales_manager',
			'finance_manager',
		],
		'refund-submitted' => [
			'after_sales',
			'support_manager',
		],
		'refund-confirm'   => [ 'finance_manager' ],
		'refund-paid'      => [
			'finance_manager',
			'cashier',
		],
		'refund-delivered' => [ 'support_worker' ],
		'refund-cancelled' => [ 'after_sales' ],
	];
	
	// ادمین همیشه همه وضعیت‌های بعدی رو می‌بینه
	if ( is_current_user_admin() ) {
		return $valid_transitions[ $current_status ] ?? [];
	}
	
	// بررسی دسترسی نقش‌های کاربر
	$allowed = FALSE;
	foreach ( $roles as $role ) {
		if ( isset( $role_edit_permission[ $current_status ] ) && in_array( $role, $role_edit_permission[ $current_status ], TRUE ) ) {
			$allowed = TRUE;
			break;
		}
	}
	
	return $allowed ? ( $valid_transitions[ $current_status ] ?? [] ) : [];
}

function crm_can_edit_order( string $current_status ): bool {
	/** @var int $user_id */
	$user_id        = get_current_user_id();
	$roles          = nooshika_get_user_role( $user_id, TRUE );
	$current_status = str_replace( 'wc-', '', $current_status );
	
	// Admins can always edit.
	if ( function_exists( 'is_current_user_admin' ) && is_current_user_admin() ) {
		return TRUE;
	}
	
	// Define the lifecycle order so we can decide what comes "after processing".
	$status_order = [
		'pending',
		'factor',
		'confirming',
		'processing',
		'confirmed',
		'stock-delivery',
		'completed',
		'delivered',
		'refund-submitted',
		'refund-confirm',
		'refund-paid',
		'refund-delivered',
		'refund-cancelled',
		'cancelled',
	];
	
	$idx_current    = array_search( $current_status, $status_order, TRUE );
	$idx_processing = array_search( 'processing', $status_order, TRUE );
	
	// Unknown status? Be safe: deny for non-admins.
	if ( $idx_current === FALSE || $idx_processing === FALSE ) {
		return FALSE;
	}
	
	// Anything strictly after 'processing' is NOT editable for non-admins.
	if ( $idx_current > $idx_processing ) {
		return FALSE;
	}
	
	// Up to and including 'processing' → editable by non-admins.
	$can = TRUE;
	
	/**
	 * Filter: allow projects to further restrict/allow edits based on roles, etc.
	 *
	 * @param   bool    $can
	 * @param   string  $current_status
	 * @param   array   $roles
	 */
	return (bool) apply_filters( 'crm_can_edit_order', $can, $current_status, $roles );
}

function crm_get_product_brand( $product ) {
	$brand = $product->get_attribute( 'pa_brand' );
	if ( empty( $brand ) && $product->is_type( 'variation' ) ) {
		$parent_id      = $product->get_parent_id();
		$parent_product = wc_get_product( $parent_id );
		if ( $parent_product ) {
			$brand = $parent_product->get_attribute( 'pa_brand' );
		}
	}
	
	return $brand;
}

function render_qc_form_fields() {
	$questions = [
		[
			'id'    => 'item_qc_approved',
			'label' => 'کیفیت محصول مورد تایید است',
			'type'  => 'switch',
		],
		[
			'id'      => 'qc_color',
			'label'   => 'مشکلات ظاهری',
			'type'    => 'checkbox',
			'options' => [
				'not_match' => 'مغایرت با سفارش',
				'pattern'   => 'مشکلات بافت',
				'uniform'   => 'پارگی',
				'fade'      => 'ریشه و زیگزاگ',
				'stains'    => 'شکستگی',
				'color'     => 'رنگ آمیزی',
				'rooye'     => 'رویه کوبی',
				'yaraq'     => 'یراق',
			],
		],
		[
			'id'    => 'qc_notes',
			'label' => 'توضیحات تکمیلی',
			'type'  => 'textarea',
		],
	];
	
	return $questions;
}

function crm_get_user_total_order_value( $user_id ): int {
	$args   = [
		'customer_id' => $user_id,
		'status'      => [
			'completed',
			'confirming',
			'stock-delivery',
			'delivered',
			'processing',
			'confirmed',
		],
	];
	$orders = wc_get_orders( $args );
	$total  = 0;
	foreach ( $orders as $order ) {
		$total += $order->get_total();
	}
	
	return $total;
}

function crm_get_user_total_order_count( $user_id ): int {
	$args = [
		'customer_id' => $user_id,
		'status'      => [
			'completed',
			'confirming',
			'stock-delivery',
			'delivered',
			'processing',
			'confirmed',
		],
	];
	
	$orders = wc_get_orders( $args );
	
	return count( $orders );
}

function crm_get_user_by_referral_code( $code ) {
	$user = get_users( [
		'meta_key'   => 'kasebi_user_referral_code',
		'meta_value' => $code,
	] );
	
	return $user[0] ? $user[0]->id : 0;
}

function crm_get_products_list( $args = [] ): array {
	$defaults = [
		'type'        => 'both', // product | variation | both
		'pa_brand'    => '',
		'pa_size'     => '',
		'product_cat' => '',
		'search'      => '',
		'per_page'    => 20,
		'offset'      => 0,
	];
	
	$args = wp_parse_args( $args, $defaults );
	extract( $args );
	
	global $wpdb;
	$pre = $wpdb->prefix;
	
	$type     = in_array( $type, [ 'product', 'variation', 'both' ], TRUE ) ? $type : 'both';
	$per_page = max( 1, (int) $per_page );
	$offset   = max( 0, (int) $offset );
	
	$parse_ids = static function( $csv ): array {
		$ids = array_values( array_filter( array_map( 'intval', explode( ',', (string) $csv ) ) ) );
		
		return array_values( array_unique( $ids ) );
	};
	
	$select = [ 'DISTINCT p.ID' ];
	$join   = [];
	$wheres = [ "p.post_status = 'publish'" ];
	
	// --- Type logic (بدون JOIN به product_type)
	if ( $type === 'product' ) {
		$wheres[] = "p.post_type = 'product'";
		$wheres[] = "p.post_parent = 0";
		
		// حذف variable parents: محصولی که ورییشن دارد = variable => نباید بیاید
		$wheres[] = "NOT EXISTS (
			SELECT 1 FROM {$pre}posts v
			WHERE v.post_type = 'product_variation'
			  AND v.post_status = 'publish'
			  AND v.post_parent = p.ID
			LIMIT 1
		)";
	} elseif ( $type === 'variation' ) {
		$wheres[] = "p.post_type = 'product_variation'";
		$wheres[] = "p.post_parent > 0";
	} else {
		$wheres[] = "p.post_type IN ('product','product_variation')";
		
		// اگر product بود، نباید ورییشن داشته باشد
		$wheres[] = "(
			p.post_type='product'
			AND p.post_parent=0
			AND NOT EXISTS (
				SELECT 1 FROM {$pre}posts v
				WHERE v.post_type='product_variation'
				  AND v.post_status='publish'
				  AND v.post_parent=p.ID
				LIMIT 1
			)
		) OR (p.post_type='product_variation' AND p.post_parent>0)";
	}
	
	// --- search (امن)
	if ( $search !== '' ) {
		$search   = str_replace( [ '+', ' ' ], '%', (string) $search );
		$like     = '%' . $search . '%';
		$wheres[] = $wpdb->prepare( "p.post_title LIKE %s", $like );
	}
	
	// --- product_cat (روی parent اگر variation بود)
	if ( $product_cat ) {
		$cat_ids = $parse_ids( $product_cat );
		if ( $cat_ids ) {
			$join[]   = "LEFT JOIN {$wpdb->term_relationships} trc
				ON trc.object_id = IF(p.post_type='product_variation', p.post_parent, p.ID)";
			$wheres[] = "trc.term_taxonomy_id IN (" . implode( ',', $cat_ids ) . ")";
		}
	}
	
	// --- pa_size (روی خود variation / product)
	if ( $pa_size ) {
		$size_ids = $parse_ids( $pa_size );
		if ( $size_ids ) {
			$join[]   = "LEFT JOIN {$pre}wc_product_attributes_lookup pals
				ON pals.product_id = p.ID AND pals.taxonomy = 'pa_size'";
			$wheres[] = "pals.term_id IN (" . implode( ',', $size_ids ) . ")";
		}
	}
	
	// --- pa_brand (روی parent اگر variation بود)
	if ( $pa_brand ) {
		$brand_ids = $parse_ids( $pa_brand );
		if ( $brand_ids ) {
			$join[]   = "LEFT JOIN {$pre}wc_product_attributes_lookup pab
				ON pab.product_id = IF(p.post_type='product_variation', p.post_parent, p.ID) AND pab.taxonomy = 'pa_brand'";
			$wheres[] = "pab.term_id IN (" . implode( ',', $brand_ids ) . ")";
		}
	}
	
	$join_sql  = $join ? implode( ' ', $join ) : '';
	$where_sql = $wheres ? implode( ' AND ', array_map( fn( $w ) => "( $w )", $wheres ) ) : '(1=1)';
	
	$base = "FROM {$pre}posts p {$join_sql} WHERE {$where_sql}";
	
	$total_products = (int) $wpdb->get_var( "SELECT COUNT(DISTINCT p.ID) {$base}" );
	$total_pages    = (int) ceil( $total_products / $per_page );
	
	$products = $wpdb->get_results(
		$wpdb->prepare(
			"SELECT " . implode( ', ', $select ) . " {$base} ORDER BY p.ID DESC LIMIT %d OFFSET %d",
			$per_page,
			$offset
		),
		ARRAY_A
	);
	
	return [
		'product_ids'    => wp_list_pluck( $products, 'ID' ),
		'total_pages'    => $total_pages,
		'total_products' => $total_products,
	];
}

function crm_get_term_title( $term, $taxonomy = '' ): string {
	if ( $term instanceof \WP_Term ) {
		return (string) $term->name;
	}
	
	$term = get_term( $term, $taxonomy );
	
	if ( ! $term || is_wp_error( $term ) ) {
		return '';
	}
	
	return (string) $term->name;
}

function crm_dashboard_compare_today_with_yesterday( $items ) {
	$items = array_values( is_array( $items ) ? $items : [] );
	
	$today_index     = count( $items ) - 1;
	$yesterday_index = count( $items ) - 2;
	
	$today     = $today_index >= 0 ? (float) $items[ $today_index ] : 0;
	$yesterday = $yesterday_index >= 0 ? (float) $items[ $yesterday_index ] : 0;
	
	$result = [
		'today'     => $today,
		'yesterday' => $yesterday,
		'html'      => '',
	];
	
	if ( $today == 0 && $yesterday == 0 ) {
		$result['html'] = '<span>بدون تغییر نسبت به دیروز</span>';
		
		return $result;
	}
	
	if ( $yesterday == 0 ) {
		$result['html'] = '<em class="icon ni ni-arrow-long-up"></em> رشد کامل نسبت به دیروز';
		
		return $result;
	}
	
	$diff    = $today - $yesterday;
	$percent = abs( $diff / $yesterday * 100 );
	
	if ( $diff == 0 ) {
		$result['html'] = '<span>بدون تغییر نسبت به دیروز</span>';
		
		return $result;
	}
	
	$icon  = $diff > 0 ? 'ni-arrow-long-up' : 'ni-arrow-long-down';
	$label = $diff > 0 ? 'افزایش نسبت به دیروز' : 'کاهش نسبت به دیروز';
	
	$result['html'] = sprintf(
		'<em class="icon ni %s"></em> %s%% %s',
		esc_attr( $icon ),
		esc_html( number_format_i18n( $percent, 1 ) ),
		esc_html( $label )
	);
	
	return $result;
}

function kasebi_render_user_location_field( $user_id ): void {
	$lat = get_user_meta( $user_id, 'kasebi_user_lat', TRUE );
	$lng = get_user_meta( $user_id, 'kasebi_user_lng', TRUE );
	
	$lat = $lat !== '' ? $lat : '36.5445346';
	$lng = $lng !== '' ? $lng : '52.6793790';
	?>
    <div id="kasebi-user-location-map"
         data-lat="<?php echo esc_attr( $lat ); ?>"
         data-lng="<?php echo esc_attr( $lng ); ?>"></div>
    <input type="hidden" name="kasebi_user_lat" id="kasebi_user_lat" value="<?php echo esc_attr( $lat ); ?>">
    <input type="hidden" name="kasebi_user_lng" id="kasebi_user_lng" value="<?php echo esc_attr( $lng ); ?>">
	<?php
}


// Legacy field and type identifiers are retained for compatibility; the labels define the sales channel shown to users.
function kcp_can_assign_customers(): bool {
    $user = wp_get_current_user();
    return is_user_logged_in() && ( current_user_can( 'manage_options' ) ||
        (bool) array_intersect( [ 'administrator', 'sales_manager' ], (array) $user->roles ) );
}

function kcp_sales_assignment_types(): array {
    return [
        'in_person' => [
            'role' => 'salesman', 'meta' => 'creator_id',
            'history' => 'crm_assignment_history', 'label' => 'مسئول فروش تلفنی',
        ],
        'phone' => [
            'role' => 'phone_salesman', 'meta' => 'crm_phone_sales_agent_id',
            'history' => 'crm_phone_sales_assignment_history', 'label' => 'مسئول فروش حضوری',
        ],
    ];
}

function kcp_sales_agents( string $type = 'phone' ): array {
    $types = kcp_sales_assignment_types();
    if ( ! isset( $types[ $type ] ) ) { return []; }
    return get_users( [ 'role' => $types[ $type ]['role'], 'orderby' => 'display_name', 'order' => 'ASC' ] );
}

function kcp_validate_customer_assignment( $customer_ids, $agent, $type = 'phone' ) {
    if ( ! kcp_can_assign_customers() ) {
        return new WP_Error( 'forbidden', 'فقط مدیر و مدیر فروش می‌توانند مسئول فروش مشتری را تغییر دهند.' );
    }
    $types = kcp_sales_assignment_types();
    if ( ! is_string( $type ) || ! isset( $types[ $type ] ) ) {
        return new WP_Error( 'type', 'نوع مسئول فروش معتبر نیست.' );
    }
    if ( ! is_array( $customer_ids ) || ! $customer_ids || count( $customer_ids ) > 500 ) {
        return new WP_Error( 'customers', 'بین ۱ تا ۵۰۰ مشتری انتخاب کنید.' );
    }
    if ( ! is_scalar( $agent ) || ! preg_match( '/^[0-9]+$/D', (string) $agent ) ) {
        return new WP_Error( 'agent', 'کارشناس انتخاب‌شده معتبر نیست.' );
    }
    if ( (int) $agent !== 0 ) {
        $user = get_userdata( (int) $agent );
        if ( ! $user || ! in_array( $types[ $type ]['role'], (array) $user->roles, TRUE ) ) {
            return new WP_Error( 'agent', 'کارشناس انتخاب‌شده باید از نوع «' . $types[ $type ]['label'] . '» باشد.' );
        }
    }
    foreach ( $customer_ids as $id ) {
        if ( ! is_scalar( $id ) || ! preg_match( '/^[0-9]+$/D', (string) $id ) || (int) $id < 1 ) {
            return new WP_Error( 'customer', 'شناسه مشتری معتبر نیست.' );
        }
        $customer = get_userdata( (int) $id );
        if ( ! $customer || ! in_array( 'subscriber', (array) $customer->roles, TRUE ) ) {
            return new WP_Error( 'customer', 'مشتری انتخاب‌شده معتبر نیست.' );
        }
    }
    return TRUE;
}

// Keep the existing role-to-field mapping when a salesperson creates a customer.
function kcp_new_customer_sales_meta(): array {
    $user = wp_get_current_user();
    $is_phone = in_array( 'phone_salesman', (array) $user->roles, TRUE );
    $is_in_person = in_array( 'salesman', (array) $user->roles, TRUE );
    $meta = [ 'creator_id' => $is_phone && ! $is_in_person ? 0 : get_current_user_id() ];
    if ( $is_phone ) { $meta['crm_phone_sales_agent_id'] = get_current_user_id(); }
    return $meta;
}
