<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Employee birthdays: Gregorian storage for compatibility, Jalali forms and profiles. */
final class KCP_Employee_Birth_Date {
    private static function normalize( $value ) {
        if ( ! is_string( $value ) && ! is_numeric( $value ) ) { return ''; }
        return trim( strtr( (string) $value, [
            '۰'=>'0', '۱'=>'1', '۲'=>'2', '۳'=>'3', '۴'=>'4', '۵'=>'5', '۶'=>'6', '۷'=>'7', '۸'=>'8', '۹'=>'9',
            '٠'=>'0', '١'=>'1', '٢'=>'2', '٣'=>'3', '٤'=>'4', '٥'=>'5', '٦'=>'6', '٧'=>'7', '٨'=>'8', '٩'=>'9',
        ] ) );
    }

    private static function parts( $value ) {
        if ( ! preg_match( '~^(\d{4})[-/](\d{1,2})[-/](\d{1,2})(?: 00:00:00)?$~D', $value, $m ) ) { return []; }
        return [ (int) $m[1], (int) $m[2], (int) $m[3] ];
    }

    public static function to_jalali( $value ) {
        $value = self::normalize( $value );
        $parts = self::parts( $value );
        if ( ! $parts ) { return $value; }
        [ $gy, $gm, $gd ] = $parts;
        // Older records that already contain Jalali dates must not be converted twice.
        if ( $gy < 1700 ) { return sprintf( '%04d/%02d/%02d', $gy, $gm, $gd ); }
        if ( ! checkdate( $gm, $gd, $gy ) ) { return $value; }
        // Same Gregorian-to-Jalali arithmetic as the bundled persianDatepicker.
        $month_days = [ 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334 ];
        $jy = 979;
        $gy -= 1600;
        $gy2 = $gm > 2 ? $gy + 1 : $gy;
        $days = 365 * $gy + intdiv( $gy2 + 3, 4 ) - intdiv( $gy2 + 99, 100 )
            + intdiv( $gy2 + 399, 400 ) - 80 + $gd + $month_days[ $gm - 1 ];
        $jy += 33 * intdiv( $days, 12053 );
        $days %= 12053;
        $jy += 4 * intdiv( $days, 1461 );
        $days %= 1461;
        if ( $days > 365 ) {
            $jy += intdiv( $days - 1, 365 );
            $days = ( $days - 1 ) % 365;
        }
        $jm = $days < 186 ? 1 + intdiv( $days, 31 ) : 7 + intdiv( $days - 186, 30 );
        $jd = 1 + ( $days < 186 ? $days % 31 : ( $days - 186 ) % 30 );
        return sprintf( '%04d/%02d/%02d', $jy, $jm, $jd );
    }

    public static function to_storage( $value ) {
        $error = new WP_Error( 'invalid_birth_date', 'تاریخ تولد معتبر نیست. تاریخ شمسی را به صورت سال/ماه/روز وارد کنید؛ مانند ۱۳۷۰/۰۵/۱۲.' );
        if ( ! is_string( $value ) && ! is_numeric( $value ) ) { return $error; }
        $value = self::normalize( $value );
        if ( $value === '' ) { return ''; }
        $parts = self::parts( $value );
        if ( ! $parts ) { return $error; }
        [ $year, $month, $day ] = $parts;
        if ( $year >= 1700 ) {
            // Accept a previously stored Gregorian date without treating its year as Jalali.
            return checkdate( $month, $day, $year ) ? sprintf( '%04d-%02d-%02d', $year, $month, $day ) : $error;
        }
        if ( $year < 1000 || $month < 1 || $month > 12 || $day < 1
            || $day > ( $month <= 6 ? 31 : 30 ) || ! function_exists( 'nooshika_jalali_to_gregorian' ) ) {
            return $error;
        }
        $jalali = sprintf( '%04d-%02d-%02d', $year, $month, $day );
        $converted = nooshika_jalali_to_gregorian( $jalali );
        $parts = self::parts( self::normalize( $converted ) );
        if ( ! $parts || ! checkdate( $parts[1], $parts[2], $parts[0] ) ) { return $error; }
        $gregorian = sprintf( '%04d-%02d-%02d', $parts[0], $parts[1], $parts[2] );
        // Reject rolled-over dates, including Esfand 30 in a non-leap year.
        return self::to_jalali( $gregorian ) === str_replace( '-', '/', $jalali ) ? $gregorian : $error;
    }
}
