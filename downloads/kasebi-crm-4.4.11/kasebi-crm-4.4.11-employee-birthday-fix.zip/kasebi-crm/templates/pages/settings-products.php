<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$per_page_key = basename( __FILE__, '.php' );
$per_page_key = "crm_{$per_page_key}_per_page";
$user_id      = get_current_user_id();
$defaults     = [
	'search'      => '',
	'page_number' => 1,
	'per_page'    => get_user_meta( $user_id, $per_page_key, TRUE ) ?: 20,
];

$args = wp_parse_args( $_REQUEST, $defaults );

$args = array_map( function( $v ) {
	return ! is_array( $v ) && $v == 0 ? '' : $v;
}, $args );

$has_filter = kcp_page_has_filter( $args, $defaults );

$search      = sanitize_text_field( wp_unslash( (string) ( $args['search'] ?? '' ) ) );
$page_number = max( 1, absint( $args['page_number'] ?? 1 ) );
$per_page    = max( 1, absint( $args['per_page'] ?? 20 ) );

update_user_meta( $user_id, $per_page_key, $per_page );

$query_args = [
	'status'  => [ 'publish' ],
	'limit'   => $per_page,
	'page'    => $page_number,
	'orderby' => 'date',
	'order'   => 'DESC',
	'return'  => 'objects',
];

if ( $search !== '' ) {
	$query_args['s'] = $search;
}

$query    = new WC_Product_Query( $query_args );
$products = $query->get_products();

$query       = new WC_Product_Query( $query_args );
$result      = $query->get_products();
$total_count = (int) ( $result->total ?? 0 );
$total_pages = (int) ( $result->max_num_pages ?? 1 );

$total_pages = max( 1, $total_pages );

?>
<?php KCP_Product_Prices::notice(); ?>
<div class="nk-block-head nk-block-head-sm">
    <div class="nk-block-between">
        <div class="nk-block-head-content">
            <h3 class="nk-block-title page-title">تنظیمات محصولات</h3>
            <div class="nk-block-des text-soft">
                <p class="mb-0">شما در مجموع <?php echo $total_count; ?> محصول دارید.</p>
            </div>
        </div>
        <div class="nk-block-head-content">
            <div class="toggle-wrap nk-block-tools-toggle">
                <div class="toggle-expand-content">
                    <ul class="nk-block-tools g-3">
                        <li class="nk-block-tools-opt">
                            <a href="#" class=" btn btn-icon btn-primary" data-bs-target="#addProduct"
                               data-bs-toggle="modal"><em class="icon ni ni-plus"></em></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="nk-block">
    <div class="card card-stretch">
        <div class="card-inner-group">
            <div class="card-inner position-relative card-tools-toggle">
                <div class="card-title-group">
                    <div class="card-tools">
                        <a class="btn btn-icon search-toggle toggle-search" data-target="search_actions">
                            <em class="icon ni ni-search"></em>
                        </a>
                    </div>
                    <div class="card-tools">
                        <ul class="btn-toolbar gx-1">
                            <li>
								<?php
								echo crm_get_template( 'partials/per-page-selector.php', [
									'per_page' => $per_page,
								] );
								?>
                            </li>
                        </ul>
                    </div>
                    <div class="card-search search-wrap<?php echo $search ? ' active' : ''; ?>"
                         data-search="search_actions">
                        <div class="card-body">
                            <div class="search-content">
                                <a href="#" class="search-back btn btn-icon toggle-search" data-target="search_actions"><em
                                        class="icon ni ni-arrow-left"></em></a>
                                <input type="text" value="<?php echo $search; ?>"
                                       class="form-control border-transparent form-focus-none search_crm_list"
                                       placeholder="جستجو میان محصولات">
                                <div class="search-submit btn btn-icon submit_search_actions">
                                    <em class="icon ni ni-search"></em>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-inner p-0">
                <div class="nk-tb-list nk-tb-ulist is-compact">
                    <div class="nk-tb-item nk-tb-head">
                        <div class="nk-tb-col"><span class="sub-text">نام محصول</span></div>
                        <div class="nk-tb-col"><span class="sub-text">قیمت عادی</span></div>
                        <div class="nk-tb-col"><span class="sub-text">قیمت نهایی (بنکدار)</span></div>
                        <div class="nk-tb-col text-end"></div>
                    </div>
					<?php
					if ( empty( $products ) ) {
						echo '<div class="no-item-found">محصول یافت نشد</div>';
					} else {
						foreach ( $products as $product ) {
							if ( ! $product instanceof WC_Product ) {
								continue;
							}
							
							$product_id = $product->get_id();
							$title      = $product->get_name();
							$sku        = $product->get_sku();
							
                            $regular_price_display = KCP_Product_Prices::display( $product, 'base_regular_price' ) . ' تومان';
                            $sale_price_display = KCP_Product_Prices::display( $product ) . ' تومان';
                            $regular_price_input = wc_format_decimal( $product->get_regular_price( 'edit' ) );
                            $sale_price_input = wc_format_decimal( $product->get_sale_price( 'edit' ) );

							?>
                            <div class="nk-tb-item">
                                <div class="nk-tb-col">
                                    <div class="user-card">
                                        <div class="user-info">
                                            <div class="lead-text">
												<?php echo esc_html( $title ); ?>
                                            </div>
											
											<?php if ( $sku ) { ?>
                                                <div class="sub-text">
                                                    کد محصول: <?php echo esc_html( $sku ); ?>
                                                </div>
											<?php } ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="nk-tb-col">
                                    <span class="tb-amount">
										<?php echo esc_html( $regular_price_display ); ?>
                                    </span>
                                </div>

                                <div class="nk-tb-col">
                                    <span class="tb-amount">
										<?php echo esc_html( $sale_price_display ); ?>
                                    </span>
                                </div>
                                <div class="nk-tb-col nk-tb-col-tools">
                                    <ul class="nk-tb-actions gx-2">
                                        <li>
											<?php
											echo crm_get_template( 'partials/row-actions-dropdown.php', [
												'actions' => [
													[
														'link'  => '',
														'title' => 'ویرایش محصول',
														'icon'  => 'ni-edit',
														'class' => 'edit_item',
														'data'  => [
															'modal'      => 'addProduct',
															'product_id' => $product_id,
															'title'      => $title,
															'price'      => $regular_price_input,
															'sale_price' => $sale_price_input,
														],
													],
													[
														'link'  => '',
														'title' => 'حذف محصول',
														'icon'  => 'ni-trash',
														'class' => 'delete_db_item',
														'data'  => [
															'page'    => '/crm/settings-products',
															'item_id' => $product_id,
															'action'  => 'crm_trash_product',
														],
													],
												],
											] );
											?>
                                        </li>
                                    </ul>
                                </div>
                            </div>
							<?php
						}
					}
					?>
                </div>
            </div>
            <div class="card-inner">
				<?php
				echo crm_get_template( 'partials/pagination.php', [
					'max_page_num' => $total_pages,
					'current_page' => $page_number,
					'class_name'   => 'user_pagination_link',
					'show_count'   => 2,
				] );
				?>
            </div>
        </div>
    </div>
</div>
<div class="modal fade zoom" id="addProduct">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
            <div class="modal-body">
                <h5 class="modal-title">افزودن محصول</h5>
                <form action="#" class="mt-4 modal_form" data-action="crm_add_product"
                      data-page="/crm/settings-products">
                    <div class="row g-gs">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="product_title">عنوان</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="product_title" data-for="title">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="product_main_price">قیمت اصلی</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control price_input" id="product_main_price"
                                           data-for="price">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="product_sale_price">قیمت فروش ویژه</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control price_input" id="product_sale_price"
                                           data-for="sale_price">
                                </div>
                            </div>
                        </div>
                        <input type="hidden" data-for="product_id" value="">
                        <div class="col-12">
                            <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                <li>
                                    <div class="btn btn-primary submit_modal_form">ذخیره</div>
                                </li>
                                <li>
                                    <a href="#" class="link link-light" data-bs-dismiss="modal">لغو</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>