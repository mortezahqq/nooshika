<?php
/**
 * Plugin Name: کاسبی: سیستم مدیریت مشتریان
 * Plugin URI: https://kasebi.co/
 * Description: افزونه crm ویژه کاسبی
 * Version: 4.4.2
 * Author: احمد گلچین
 * Author URI: https://kasebi.co/
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

define( 'KCP_PATH', plugin_dir_path( __FILE__ ) );
define( 'KCP_URL', plugin_dir_url( __FILE__ ) );
define( 'KCP_NAME', plugin_basename( __FILE__ ) );

const KCP_TEMPLATE_PATH = KCP_PATH . 'templates/';
const KCP_MARKETER_META = 'user_marketer_id';
const KCP_ASSETS_URL    = KCP_URL . 'assets/';
const KCP_DEBUG_MODE    = TRUE;
if ( ! KCP_DEBUG_MODE ) {
	define( 'KCP_VER', get_plugin_data( __FILE__ )['Version'] );
} else {
	define( 'KCP_VER', time() );
}
const KASEBI_NESHAN_WEB_API_KEY = 'web.4cd709d30442427ca0942096019984df';
include "includes/helper.php";
include "includes/shortcodes.php";
include "includes/actions.php";
include "class/kcp_db.php";
include "class/kcp_stock.php";
include "class/kcp_panel.php";
include "class/kcp_ajax.php";
include "class/Kasebi_Order_Index.php";

register_activation_hook( __FILE__, 'crm_plugin_activated' );
new kcp_panel();
new kcp_ajax();
new Kasebi_Order_Index();

