<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
$current_agent = (int) get_user_meta( $user_id, 'creator_id', TRUE );
$agents = kcp_sales_agents();
?>
<div class="nk-block card card-bordered p-3 mb-4">
    <h6>کارشناس فروش مسئول مشتری</h6>
    <p>کارشناس فعلی: <?php echo esc_html( $current_agent ? get_user_name_by_id( $current_agent ) : 'بدون کارشناس' ); ?></p>
    <?php if ( kcp_can_assign_customers() ) : ?>
        <label for="kcp-sales-agent">انتخاب کارشناس فروش</label>
        <select id="kcp-sales-agent" class="form-select mb-2">
            <option value="0" <?php selected( $current_agent, 0 ); ?>>بدون کارشناس</option>
            <?php if ( $current_agent && ! in_array( $current_agent, array_map( 'intval', wp_list_pluck( $agents, 'ID' ) ), TRUE ) ) : ?>
                <option value="<?php echo esc_attr( $current_agent ); ?>" selected disabled><?php echo esc_html( get_user_name_by_id( $current_agent ) . ' (تخصیص قبلی؛ کارشناس فروش نیست)' ); ?></option>
            <?php endif; ?>
            <?php foreach ( $agents as $agent ) : ?>
                <option value="<?php echo esc_attr( $agent->ID ); ?>" <?php selected( $current_agent, $agent->ID ); ?>><?php echo esc_html( get_user_name_by_id( $agent->ID ) ); ?></option>
            <?php endforeach; ?>
        </select>
        <?php if ( ! $agents ) : ?><p>ابتدا در بخش کارمندان، کاربری با نقش «کارشناس فروش» بسازید.</p><?php endif; ?>
        <button type="button" class="btn btn-primary kcp-save-sales-agent" data-customer="<?php echo esc_attr( $user_id ); ?>" data-nonce="<?php echo esc_attr( wp_create_nonce( 'kcp_customer_assignment' ) ); ?>">ذخیره کارشناس</button>
    <?php endif; ?>
</div>
