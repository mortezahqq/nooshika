<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class kcp_db {
	
	private string $db_prefix;
	private string $db_charset;
	private wpdb   $db;
	
	private string $uploaded_files;
	private string $export_log;
	private string $actions_table;
	private string $action_meta;
	private string $track_table;
	private string $task_table;
	private string $sms_log;
	private string $visits_table;
	private string $calls_table;
	private string $calls_progress_table;
	private string $calls_meta_table;
	private string $warning_table;
	private string $warning_log_table;
	private string $reports_table;
	private string $reports_meta_table;
	private string $installments;
	private string $order_cheques;
	private string $cash_payments;
	private string $order_index;
	
	public array $track_title;
	public array $stocks;
	public array $log_action;
	public array $log_type;
	
	public function __construct() {
		global $wpdb;
		$this->db         = $wpdb;
		$this->db_prefix  = $this->db->prefix . 'kcp_';
		$this->db_charset = $this->db->get_charset_collate();
		
		$this->uploaded_files       = $this->db_prefix . 'uploaded_files';
		$this->export_log           = $this->db_prefix . 'export_log';
		$this->actions_table        = $this->db_prefix . 'actions';
		$this->action_meta          = $this->db_prefix . 'action_meta';
		$this->track_table          = $this->db_prefix . 'track_logs';
		$this->task_table           = $this->db_prefix . 'task_logs';
		$this->sms_log              = $this->db_prefix . 'sms_log';
		$this->visits_table         = $this->db_prefix . 'visits';
		$this->calls_table          = $this->db_prefix . 'calls';
		$this->calls_meta_table     = $this->db_prefix . 'calls_meta';
		$this->calls_progress_table = $this->db_prefix . 'calls_progress';
		$this->warning_table        = $this->db_prefix . 'warning';
		$this->warning_log_table    = $this->db_prefix . 'warning_log';
		$this->reports_table        = $this->db_prefix . 'reports';
		$this->reports_meta_table   = $this->db_prefix . 'reports_meta';
		
		$this->installments  = $this->db_prefix . 'installments';
		$this->order_cheques = $this->db_prefix . 'order_cheques';
		$this->cash_payments = $this->db_prefix . 'cash_payments';
		
		$this->create_main_table();
		
		$this->track_title = [
			'online_counseling'    => 'مشاوره آنلاین',
			'in_person_counseling' => 'مشاوره حضوری',
			'call_counseling'      => 'مشاوره تلفنی',
			'returned_check'       => 'چک برگشتی',
			'deposit_remaining'    => 'واریزی مانده حساب',
			'factor_tracking'      => 'پیگیری فاکتور',
			'cancelled_visit'      => 'ویزیت لغو شده',
			'assigned_job'         => 'امور محوله',
		];
		$this->stocks      = [
			'produce' => 'انبار تولید',
			'store'   => 'انبار فروشگاه',
			'vitrine' => 'ویترین',
			'deliver' => 'انبار تحویل کالا',
			'refund'  => 'مرجوعی',
		];
		$this->log_action  = [
			'production'   => 'درخواست تولید',
			'invoice'      => 'فاکتور',
			'import'       => 'ورود دستی',
			'export'       => 'خروج دستی',
			'transfer_in'  => 'انتقال ورودی',
			'transfer_out' => 'انتقال خروجی',
			'reject'       => 'مرجوعی',
		];
		$this->log_type    = [
			'stock_in'  => 'ورودی',
			'on_hold'   => 'در انتظار تولید',
			'stock_out' => 'خروجی',
		];
		
		add_action( 'woocommerce_after_order_object_save', [ $this, 'on_order_saved' ], 100, 2 );
		add_action( 'woocommerce_order_status_changed', [ $this, 'on_status_changed' ], 100, 4 );
		//		add_action( 'before_delete_post', [ $this, 'on_before_delete_post' ], 100 );
		add_action( 'woocommerce_before_delete_order', [ $this, 'on_before_delete_order' ], 100, 1 );
	}
	
	public function create_main_table(): void {
		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
		maybe_create_table( $this->uploaded_files, $this->get_uploaded_files_table_query() );
		maybe_create_table( $this->actions_table, $this->get_actions_table_query() );
		maybe_create_table( $this->action_meta, $this->get_action_meta_table_query() );
		maybe_create_table( $this->track_table, $this->get_track_logs_table_query() );
		maybe_create_table( $this->task_table, $this->get_task_logs_table_query() );
		maybe_create_table( $this->sms_log, $this->get_sms_log_table_query() );
		maybe_create_table( $this->visits_table, $this->get_visits_table_query() );
		maybe_create_table( $this->calls_table, $this->get_calls_table_query() );
		maybe_create_table( $this->calls_meta_table, $this->get_call_meta_table_query() );
		maybe_create_table( $this->calls_progress_table, $this->get_call_progress_logs_table_query() );
		maybe_create_table( $this->warning_table, $this->get_warning_table_query() );
		maybe_create_table( $this->warning_log_table, $this->get_warning_log_table_query() );
		maybe_create_table( $this->reports_table, $this->get_reports_table_query() );
		maybe_create_table( $this->reports_meta_table, $this->get_reports_meta_table_query() );
		maybe_create_table( $this->installments, $this->get_installments_table_query() );
		maybe_create_table( $this->order_cheques, $this->get_order_cheques_table_query() );
		maybe_create_table( $this->cash_payments, $this->get_cash_payments_table_query() );
		maybe_create_table( $this->export_log, $this->get_export_log_table_query() );
	}
	
	/*
	 * tables query
	 */
	
	private function get_uploaded_files_table_query(): string {
		return <<<SQL
			CREATE TABLE $this->uploaded_files (
				id MEDIUMINT NOT NULL AUTO_INCREMENT,
				user_id MEDIUMINT NOT NULL,
				original_name VARCHAR(255) NOT NULL,
				saved_name VARCHAR(255) NOT NULL,
				file_url TEXT NOT NULL,
				file_path TEXT NOT NULL,
				file_ext VARCHAR(20) NOT NULL,
				ip_address VARCHAR(45) DEFAULT NULL,
				uploaded_at DATETIME NOT NULL,
				PRIMARY KEY (id)
			) $this->db_charset;
		SQL;
	}
	
	private function get_actions_table_query(): string {
		return <<< SQL
			create table $this->actions_table (
			    item_id MEDIUMINT not null AUTO_INCREMENT,
			    user_id MEDIUMINT not null,
			    title TEXT not null,
			    content TEXT not null,
			    date datetime not null,
			    creator MEDIUMINT not null,
			    PRIMARY KEY (item_id)
			) $this->db_charset;
		SQL;
	}
	
	private function get_action_meta_table_query(): string {
		return <<< SQL
			create table $this->action_meta (
			    meta_id MEDIUMINT not null AUTO_INCREMENT,
			    action_id MEDIUMINT not null,
			    meta_key TEXT not null,
			    meta_value TEXT not null,
			    PRIMARY KEY (meta_id)
			) $this->db_charset;
		SQL;
	}
	
	private function get_track_logs_table_query(): string {
		return <<< SQL
			create table $this->track_table (
			    item_id MEDIUMINT not null AUTO_INCREMENT,
			    user_id MEDIUMINT not null,
			    status varchar(20) not null,
			    title TEXT not null,
			    content TEXT not null,
			    type varchar(20) not null,
			    track_date datetime not null,
			    track_hour varchar(20) not null,
			    date datetime not null,
			    creator MEDIUMINT not null,
			    checked_date datetime ,
			    check_result TEXT,
			    checked_by MEDIUMINT,
			 	PRIMARY KEY (item_id)
			) $this->db_charset;
		SQL;
	}
	
	private function get_task_logs_table_query(): string {
		return <<< SQL
			create table $this->task_table (
			    id MEDIUMINT not null AUTO_INCREMENT,
			    user_id MEDIUMINT not null,
			    status varchar(20) not null,
			    title TEXT not null,
			    content TEXT not null,
			    type TEXT not null,
			    date datetime not null,
			    creator MEDIUMINT not null,
			    checked_date datetime ,
			    check_result TEXT,
			    PRIMARY KEY (id)
			) $this->db_charset;
		SQL;
	}
	
	private function get_sms_log_table_query(): string {
		return <<< SQL
			create table $this->sms_log (
			    log_id MEDIUMINT not null AUTO_INCREMENT,
			    sender MEDIUMINT not null,
			    user_id MEDIUMINT not null,
			    content TEXT not null,
			    response TEXT not null,
			    date datetime not null,
			    PRIMARY KEY (log_id)
			) $this->db_charset;
		SQL;
	}
	
	private function get_visits_table_query(): string {
		return <<< SQL
			create table $this->visits_table (
			    id int not null AUTO_INCREMENT,
			    user_id int not null,
			    start_time datetime not null,
			    end_time datetime not null,
			    duration int not null,
			    status varchar(255) not null,
			    creator int not null,
			    details TEXT not null,
			    PRIMARY KEY (id)
			) $this->db_charset;
		SQL;
	}
	
	private function get_calls_table_query(): string {
		return <<<SQL
			CREATE TABLE {$this->calls_table} (
				id INT NOT NULL AUTO_INCREMENT,
				user_id INT NOT NULL,
				creator_id INT NOT NULL,
				category VARCHAR(255) NOT NULL,
				content TEXT NOT NULL,
				status ENUM('new', 'finished', 'need_follow', 'referred', 'follow_again') NOT NULL DEFAULT 'new',
				source ENUM('customer', 'internal') NOT NULL DEFAULT 'customer',
				created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
				PRIMARY KEY (id)
			) {$this->db_charset};
		SQL;
	}
	
	private function get_call_progress_logs_table_query(): string {
		return <<<SQL
			CREATE TABLE {$this->calls_progress_table} (
				id INT NOT NULL AUTO_INCREMENT,
				call_id INT NOT NULL,
				from_status ENUM('new', 'finished', 'need_follow', 'referred', 'follow_again') NOT NULL,
				to_status ENUM('new', 'finished', 'need_follow', 'referred', 'follow_again') NOT NULL,
				from_category VARCHAR(255) DEFAULT NULL,
				to_category VARCHAR(255) DEFAULT NULL,
				comment TEXT,
				changed_by INT NOT NULL,
				changed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
				PRIMARY KEY (id),
				KEY call_idx (call_id),
				KEY status_change_idx (from_status, to_status)
			) {$this->db_charset};
		SQL;
	}
	
	private function get_call_meta_table_query(): string {
		return <<<SQL
			CREATE TABLE {$this->calls_meta_table} (
				id INT NOT NULL AUTO_INCREMENT,
				call_id INT NOT NULL,
				meta_key VARCHAR(255) NOT NULL,
				meta_value LONGTEXT,
				PRIMARY KEY (id)
			) {$this->db_charset};
		SQL;
	}
	
	private function get_warning_table_query(): string {
		return <<< SQL
			create table $this->warning_table (
			    id int not null AUTO_INCREMENT,
			    title TEXT not null,
			    template TEXT not null,
			    token varchar(255) not null,
			    token2 varchar(255) ,
			    token3 varchar(255) ,
			    date datetime not null,
			    creator int not null,
			    PRIMARY KEY (id)
			) $this->db_charset;
		SQL;
	}
	
	private function get_warning_log_table_query(): string {
		return <<< SQL
			create table $this->warning_log_table (
			    id int not null AUTO_INCREMENT,
			    user_id int not null,
			    sender int not null,
			    warning_id int not null,
			    message TEXT not null,
			    date datetime not null,
			    PRIMARY KEY (id)
			) $this->db_charset;
		SQL;
	}
	
	private function get_reports_table_query(): string {
		return <<<SQL
			CREATE TABLE {$this->reports_table} (
				id INT NOT NULL AUTO_INCREMENT,
				employee_id INT NOT NULL,
				title VARCHAR(255) NOT NULL,
				content TEXT,
				category ENUM('cashier', 'hr', 'sale', 'warehouse') NOT NULL,
				created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
				PRIMARY KEY (id)
				) {$this->db_charset};
		SQL;
	}
	
	private function get_reports_meta_table_query(): string {
		return <<<SQL
			CREATE TABLE {$this->reports_meta_table} (
				id INT NOT NULL AUTO_INCREMENT,
				report_id INT NOT NULL,
				meta_key VARCHAR(255) NOT NULL,
				meta_value LONGTEXT,
				PRIMARY KEY (id)
			) {$this->db_charset};
		SQL;
	}
	
	private function get_installments_table_query(): string {
		return <<<SQL
	CREATE TABLE {$this->installments} (
		id                         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,

		-- relations
		order_id                   BIGINT UNSIGNED NOT NULL,
		user_id                    BIGINT UNSIGNED NULL,

		-- payer info
		payment_user_name           VARCHAR(191) NULL,
		payment_user_nid            VARCHAR(32)  NULL,

		-- plan info
		payment_plan_name           VARCHAR(64)  NOT NULL,
		payment_plan_start_date     DATE         NULL,
		payment_plan_month          TINYINT UNSIGNED NOT NULL,
		payment_plan_amount         BIGINT UNSIGNED NOT NULL,

		-- record / receipt
		payment_rec_number          VARCHAR(64)  NULL,
		payment_rec_date            DATE         NULL,
		payment_recorded_bank       VARCHAR(128) NULL,
		payment_recorded_by         BIGINT UNSIGNED NULL,
		payment_recorded_date       DATETIME     NULL,

		-- meta
		note                       TEXT NULL,
		created_at                 DATETIME NOT NULL,

		PRIMARY KEY (id),

		KEY order_id (order_id),
		KEY user_id (user_id),
		KEY payment_plan_name (payment_plan_name),
		KEY payment_plan_start_date (payment_plan_start_date),
		KEY payment_recorded_by (payment_recorded_by)
	) {$this->db_charset};
	SQL;
	}
	
	private function get_cash_payments_table_query(): string {
		return <<<SQL
	CREATE TABLE {$this->cash_payments} (
		id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,

		-- relations
		order_id     BIGINT UNSIGNED NOT NULL,
		user_id      BIGINT UNSIGNED NULL,

		-- payment data
		amount       BIGINT UNSIGNED NOT NULL,
		bank         VARCHAR(128) NULL,
		paid_date    DATE NOT NULL,

		-- meta
		created_at  DATETIME NOT NULL,

		PRIMARY KEY (id),

		KEY order_id (order_id),
		KEY user_id (user_id),
		KEY paid_date (paid_date),
		KEY bank (bank)
	) {$this->db_charset};
	SQL;
	}
	
	private function get_order_cheques_table_query(): string {
		return <<<SQL
	CREATE TABLE {$this->order_cheques} (
		id               BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,

		-- relations
		order_id         BIGINT UNSIGNED NOT NULL,
		user_id          BIGINT UNSIGNED NULL,

		-- cheque info
		check_serial     VARCHAR(64)  NOT NULL,
		check_amount     BIGINT UNSIGNED NOT NULL,
		check_expire     DATE NOT NULL,

		-- bank info
		bank_name        VARCHAR(128) NULL,
		branch_name      VARCHAR(128) NULL,
		current_account  VARCHAR(64)  NULL,

		-- owner info
		account_owner    VARCHAR(191) NULL,
		national_code    VARCHAR(16)  NULL,

		-- status / meta
		status           VARCHAR(32)  NOT NULL DEFAULT 'registered',
		note             TEXT NULL,
		created_at       DATETIME NOT NULL,

		PRIMARY KEY (id),

		KEY order_id (order_id),
		KEY user_id (user_id),
		KEY check_serial (check_serial),
		KEY check_expire (check_expire),
		KEY status (status),
		KEY bank_name (bank_name)
	) {$this->db_charset};
	SQL;
	}
	
	private function get_order_index_table_query(): string {
		return <<<SQL
	CREATE TABLE {$this->order_index} (
		id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,

		-- relations
		order_id        BIGINT UNSIGNED NOT NULL,
		user_id         BIGINT UNSIGNED NULL,
		marketer_id     BIGINT UNSIGNED NULL,

		-- order data
		order_total     BIGINT UNSIGNED NOT NULL,
		status          VARCHAR(32) NOT NULL,

		-- dates
		created_at      DATETIME NOT NULL,
		updated_at      DATETIME NULL,

		PRIMARY KEY (id),

		UNIQUE KEY order_id (order_id),
		KEY user_id (user_id),
		KEY marketer_id (marketer_id),
		KEY status (status),
		KEY created_at (created_at),
		KEY updated_at (updated_at)
	) {$this->db_charset};
	SQL;
	}
	
	private function get_export_log_table_query(): string {
		return <<<SQL
			CREATE TABLE $this->export_log (
				export_id MEDIUMINT NOT NULL AUTO_INCREMENT,
				creator MEDIUMINT NOT NULL,
				file_url VARCHAR(255) NOT NULL,
				file_path TEXT NOT NULL,
				date datetime not null,
				args TEXT not null,
				PRIMARY KEY (export_id)
			) $this->db_charset;
		SQL;
	}
	
	/*
	 * options
	 */
	
	public function get_introduce_methods(): array {
		$methods = get_option( 'kcp_introduce_methods', [] );
		if ( empty( $methods ) || ! is_array( $methods ) ) {
			$methods = [
				'tv-ads'        => [
					'label' => 'تبلیغات صدا و سیما',
					'icon'  => 'presentation',
				],
				'insta'         => [
					'label' => 'اینستاگرام',
					'icon'  => 'instagram',
				],
				'friends'       => [
					'label' => 'معرفی دوستان',
					'icon'  => 'user-add',
				],
				'other-company' => [
					'label' => 'سازمان های طرف قرارداد',
					'icon'  => 'building',
				],
				'site'          => [
					'label' => 'سایت',
					'icon'  => 'globe',
				],
				'ads'           => [
					'label' => 'تبلیغات محیطی',
					'icon'  => 'projector-screen',
				],
				'google'        => [
					'label' => 'گوگل',
					'icon'  => 'google',
				],
				'old-customer'  => [
					'label' => 'مشتری قبلی',
					'icon'  => 'copy',
				],
				'other'         => [
					'label' => 'سایر',
					'icon'  => 'layers',
				],
			];
			
			update_option( 'kcp_introduce_methods', $methods );
		}
		
		return $methods;
	}
	
	public function get_activity_types(): array {
		$types = get_option( 'kcp_activity_types', [] );
		
		if ( empty( $types ) || ! is_array( $types ) ) {
			$types = [
				'phone_call' => [
					'label' => 'تماس تلفنی',
					'icon'  => 'bxs-phone-call',
				],
				'in_person'  => [
					'label' => 'ملاقات حضوری',
					'icon'  => 'bxs-user-voice',
				],
				'follow_up'  => [
					'label' => 'پیگیری مجدد',
					'icon'  => 'bxs-repeat',
				],
				'send_sms'   => [
					'label' => 'ارسال پیامک',
					'icon'  => 'bxs-message-rounded-dots',
				],
				'send_docs'  => [
					'label' => 'ارسال مدارک',
					'icon'  => 'bxs-file-pdf',
				],
				'other'      => [
					'label' => 'سایر',
					'icon'  => 'bxs-dots-horizontal-rounded',
				],
			];
			
			update_option( 'kcp_activity_types', $types );
		}
		
		return $types;
	}
	
	public function get_track_types(): array {
		$types = get_option( 'kcp_track_types', [] );
		
		if ( empty( $types ) || ! is_array( $types ) ) {
			$types = [
				'call'     => [
					'label' => 'تماس تلفنی',
					'icon'  => 'call-alt',
				],
				'sms'      => [
					'label' => ' پیامک',
					'icon'  => 'emails',
				],
				'whatsapp' => [
					'label' => 'واتساپ',
					'icon'  => 'whatsapp',
				],
				'telegram' => [
					'label' => 'تلگرام',
					'icon'  => 'telegram',
				],
			];
			
			update_option( 'kcp_track_types', $types );
		}
		
		return $types;
	}
	
	public function get_track_status(): array {
		return [
			'pending'   => [
				'label' => 'در انتظار اقدام',
				'class' => 'bg-warning',
			],
			'completed' => [
				'label' => 'موفق',
				'class' => 'bg-success',
				'icon'  => 'ni-calendar-check-fill',
			],
			'cancelled' => [
				'label' => 'ناموفق',
				'class' => 'bg-danger',
				'icon'  => 'ni-calendar-fill',
			],
		];
	}
	
	public function get_visit_status(): array {
		return [
			'started'  => [
				'label' => 'در حال ویزیت',
				'class' => 'bg-info',
			],
			'finished' => [
				'label' => 'ارجاع به فاکتور',
				'class' => 'bg-success',
			],
			'canceled' => [
				'label' => 'لغو شده',
				'class' => 'bg-danger',
			],
		];
	}
	
	public function get_call_statuses(): array {
		return [
			'new'          => [
				'label' => 'جدید',
				'class' => 'bg-warning',
			],
			'finished'     => [
				'label' => 'پایان یافته',
				'class' => 'bg-success',
			],
			'need_follow'  => [
				'label' => 'نیاز به پیگیری',
				'class' => 'bg-orange',
			],
			'referred'     => [
				'label' => 'ارجاع شده',
				'class' => 'bg-info',
			],
			'follow_again' => [
				'label' => 'نیاز به پیگیری مجدد',
				'class' => 'bg-danger',
			],
		];
	}
	
	public function get_report_category(): array {
		return [
			'cashier'   => [
				'label' => 'صندوق',
				'class' => 'bg-danger',
			],
			'hr'        => [
				'label' => 'پرسنلی',
				'class' => 'bg-success',
			],
			'sale'      => [
				'label' => 'فروش',
				'class' => 'bg-warning',
			],
			'warehouse' => [
				'label' => 'انبار',
				'class' => 'bg-info',
			],
		];
	}
	
	public function get_call_categories(): array {
		return [
			'administrator'   => [ 'label' => 'مدیریت' ],
			'finance_manager' => [ 'label' => 'مدیریت مالی' ],
			'cashier'         => [ 'label' => 'صندوق‌' ],
			'sales_manager'   => [ 'label' => 'مدیریت فروش' ],
			'salesman'        => [ 'label' => 'کارشناسان فروش' ],
			'sales_cs'        => [ 'label' => 'امور مشتریان' ],
		];
	}
	
	/*
	 * functions
	 */
	
	public function add_uploaded_file_record( $data ) {
		if ( empty( $data['user_id'] ) ) {
			$data['user_id'] = get_current_user_id();
		}
		
		if ( empty( $data['original_name'] ) && ! empty( $data['saved_name'] ) ) {
			$data['original_name'] = pathinfo( $data['saved_name'], PATHINFO_FILENAME );
		}
		
		if ( empty( $data['file_ext'] ) && ! empty( $data['saved_name'] ) ) {
			$data['file_ext'] = pathinfo( $data['saved_name'], PATHINFO_EXTENSION );
		}
		
		if ( empty( $data['ip_address'] ) ) {
			$data['ip_address'] = $_SERVER['REMOTE_ADDR'] ?? NULL;
		}
		
		if ( empty( $data['uploaded_at'] ) ) {
			$data['uploaded_at'] = current_time( 'mysql' );
		}
		
		if ( empty( $data['saved_name'] ) || empty( $data['file_path'] ) || empty( $data['file_url'] ) ) {
			return FALSE;
		}
		
		$inserted = $this->db->insert( $this->uploaded_files, $data );
		
		return (bool) $inserted;
	}
	
	public function get_uploaded_file_data( $file_url ) {
		if ( empty( $file_url ) ) {
			return NULL;
		}
		
		$row = $this->db->get_row(
			$this->db->prepare(
				"SELECT * FROM {$this->uploaded_files} WHERE file_url = %s LIMIT 1",
				$file_url
			),
			ARRAY_A
		);
		
		return $row ?: NULL;
	}
	
	public function get_user_actions( array $args = [] ): array {
		$defaults = [
			'creator'     => NULL,
			'search'      => '',
			'search_user' => '',
			'date_from'   => '',
			'date_to'     => '',
			'action_type' => '',
			'user_id'     => '',
			'per_page'    => 20,
			'offset'      => 0,
		];
		
		$args = wp_parse_args( $args, $defaults );
		
		$where  = [ '1=1' ];
		$params = [];
		$joins  = '';
		
		if ( ! empty( $args['creator'] ) && is_numeric( $args['creator'] ) ) {
			$where[]  = 'a.creator = %d';
			$params[] = $args['creator'];
		}
		if ( ! empty( $args['user_id'] ) && is_numeric( $args['user_id'] ) ) {
			$where[]  = 'a.user_id = %d';
			$params[] = $args['user_id'];
		}
		
		if ( ! empty( $args['search'] ) ) {
			$search   = '%' . $this->db->esc_like( $args['search'] ) . '%';
			$where[]  = '(a.title LIKE %s OR a.content LIKE %s)';
			$params[] = $search;
			$params[] = $search;
		}
		
		if ( ! empty( $args['search_user'] ) ) {
			$user_list = kcp_get_user_list( $args['search_user'], - 1 )['users'] ?? [];
			$user_ids  = array_map( fn( $u ) => (int) $u['user_id'], $user_list );
			if ( ! empty( $user_ids ) ) {
				$placeholders = implode( ',', array_fill( 0, count( $user_ids ), '%d' ) );
				$where[]      = "a.user_id IN ($placeholders)";
				$params       = array_merge( $params, $user_ids );
			} else {
				// No match found
				return [
					'count'  => 0,
					'result' => [],
				];
			}
		}
		
		if ( ! empty( $args['date_from'] ) ) {
			$where[]  = 'a.date >= %s';
			$params[] = nooshika_jalali_to_gregorian( $args['date_from'] );
		}
		if ( ! empty( $args['date_to'] ) ) {
			$where[]  = 'a.date <= %s';
			$params[] = nooshika_jalali_to_gregorian( $args['date_to'] );
		}
		if ( ! empty( $args['action_type'] ) ) {
			$joins    .= " LEFT JOIN {$this->action_meta} AS am_type ON am_type.action_id = a.item_id AND am_type.meta_key = 'type'";
			$where[]  = 'am_type.meta_value = %s';
			$params[] = $args['action_type'];
		}
		$where_sql = implode( ' AND ', $where );
		
		$count_query = "SELECT COUNT(*) FROM {$this->actions_table} AS a $joins WHERE $where_sql";
		$query       = "
		SELECT a.*
		FROM {$this->actions_table} AS a
		$joins
		WHERE $where_sql
		ORDER BY a.date DESC
		LIMIT %d OFFSET %d
	";
		
		$params[] = $args['per_page'];
		$params[] = $args['offset'];
		
		$prepared_query = $this->db->prepare( $query, ...$params );
		$results        = $this->db->get_results( $prepared_query, ARRAY_A );
		
		$total_count = (int) $this->db->get_var( $this->db->prepare( $count_query, ...array_slice( $params, 0, - 2 ) ) );
		
		return [
			'count'  => $total_count,
			'result' => $results ?: [],
		];
	}
	
	public function add_user_action( array $data ): array {
		$action_id = ! empty( $data['item_id'] ) ? absint( $data['item_id'] ) : 0;
		
		if ( empty( $data['user_id'] ) ) {
			return [
				'status' => 'error',
				'msg'    => 'کاربر انتخاب نشده است.',
			];
		}
		
		if ( empty( $data['title'] ) || empty( $data['content'] ) ) {
			return [
				'status' => 'error',
				'msg'    => 'عنوان و توضیحات باید وارد شوند.',
			];
		}
		
		$save_data = [
			'user_id' => absint( $data['user_id'] ),
			'title'   => sanitize_text_field( $data['title'] ),
			'content' => wp_kses_post( $data['content'] ),
		];
		
		$type       = ! empty( $data['type'] ) ? sanitize_text_field( $data['type'] ) : '';
		$attachment = '';
		
		if ( ! empty( $data['attachment'] ) ) {
			$attachment = esc_url_raw( $data['attachment'] );
		} elseif ( ! empty( $data['file'] ) ) {
			$attachment = esc_url_raw( $data['file'] );
		}
		
		/**
		 * Update
		 */
		if ( $action_id ) {
			$exists = $this->db->get_var(
				$this->db->prepare(
					"SELECT item_id FROM {$this->actions_table} WHERE item_id = %d LIMIT 1",
					$action_id
				)
			);
			
			if ( ! $exists ) {
				return [
					'status' => 'error',
					'msg'    => 'فعالیت مورد نظر یافت نشد.',
				];
			}
			
			$updated = $this->db->update(
				$this->actions_table,
				$save_data,
				[
					'item_id' => $action_id,
				]
			);
			
			if ( FALSE === $updated ) {
				return [
					'status' => 'error',
					'msg'    => 'ویرایش فعالیت با خطا مواجه شد.',
				];
			}
			
			$this->add_action_meta( $action_id, 'type', $type );
			$this->add_action_meta( $action_id, 'attachment', $attachment );
			
			return [
				'status'    => 'success',
				'action_id' => $action_id,
				'msg'       => 'فعالیت با موفقیت ویرایش شد.',
			];
		}
		
		/**
		 * Insert
		 */
		$insert_data = array_merge( $save_data, [
			'date'    => $data['date_created'] ?? current_time( 'mysql' ),
			'creator' => $data['creator'] ?? get_current_user_id(),
		] );
		
		$inserted = $this->db->insert( $this->actions_table, $insert_data );
		
		if ( ! $inserted ) {
			return [
				'status' => 'error',
				'msg'    => 'ثبت فعالیت با خطا مواجه شد.',
			];
		}
		
		$action_id = (int) $this->db->insert_id;
		
		if ( $type !== '' ) {
			$this->add_action_meta( $action_id, 'type', $type );
		}
		
		if ( $attachment !== '' ) {
			$this->add_action_meta( $action_id, 'attachment', $attachment );
		}
		
		return [
			'status'    => 'success',
			'action_id' => $action_id,
			'msg'       => 'فعالیت با موفقیت ثبت شد.',
		];
	}
	
	public function add_action_meta( int $action_id, string $key, string $value ): void {
		if ( $action_id <= 0 || $key === '' ) {
			return;
		}
		
		$action_id = absint( $action_id );
		$key       = sanitize_key( $key );
		
		// حذف متای قبلی برای جلوگیری از duplicate
		$this->db->delete(
			$this->action_meta,
			[
				'action_id' => $action_id,
				'meta_key'  => $key,
			],
			[
				'%d',
				'%s',
			]
		);
		
		$this->db->insert(
			$this->action_meta,
			[
				'action_id'  => $action_id,
				'meta_key'   => $key,
				'meta_value' => $value,
			],
			[
				'%d',
				'%s',
				'%s',
			]
		);
	}
	
	public function get_actions_meta( int $action_id, string $key = '', bool $single = TRUE ) {
		if ( $action_id <= 0 ) {
			return $single ? NULL : [];
		}
		
		if ( $key !== '' ) {
			$query  = $this->db->prepare(
				"SELECT meta_value FROM {$this->action_meta} WHERE action_id = %d AND meta_key = %s",
				$action_id,
				$key
			);
			$values = $this->db->get_col( $query );
			
			if ( $single ) {
				return $values[0] ?? NULL;
			}
			
			return $values;
		}
		
		// بدون کلید خاص → همه متاها رو بیار
		$results = $this->db->get_results(
			$this->db->prepare(
				"SELECT meta_key, meta_value FROM {$this->action_meta} WHERE action_id = %d",
				$action_id
			),
			ARRAY_A
		);
		
		if ( empty( $results ) ) {
			return [];
		}
		
		$meta = [];
		
		foreach ( $results as $row ) {
			$k = $row['meta_key'];
			$v = $row['meta_value'];
			
			if ( isset( $meta[ $k ] ) ) {
				if ( is_array( $meta[ $k ] ) ) {
					$meta[ $k ][] = $v;
				} else {
					$meta[ $k ] = [
						$meta[ $k ],
						$v,
					];
				}
			} else {
				$meta[ $k ] = $v;
			}
		}
		
		return $meta;
	}
	
	public function delete_user_action( $action_id ) {
		if ( $action_id <= 0 ) {
			return [
				'status' => 'error',
				'msg'    => 'شناسه فعالیت نامعتبر است.',
			];
		}
		
		$this->db->delete( $this->action_meta, [ 'action_id' => $action_id ] );
		$deleted = $this->db->delete( $this->actions_table, [ 'item_id' => $action_id ] );
		if ( ! $deleted ) {
			return [
				'status' => 'error',
				'msg'    => 'حذف فعالیت با خطا مواجه شد.',
			];
		}
		
		return [
			'status' => 'success',
			'msg'    => 'فعالیت با موفقیت حذف شدند.',
		];
	}
	
	public function get_user_tracks( array $args = [] ): array {
		$defaults = [
			'creator'     => NULL,
			'user_id'     => '',
			'search'      => '',
			'search_user' => '',
			'date_from'   => '',
			'date_to'     => '',
			'due_date'    => '',
			// یعنی فقط پیگیری‌هایی که باید در این تاریخ انجام می‌شدن
			'type'        => '',
			'status'      => '',
			'per_page'    => 20,
			'offset'      => 0,
		];
		
		$args = wp_parse_args( $args, $defaults );
		
		$where  = [ '1=1' ];
		$params = [];
		
		if ( ! is_current_user_admin( 0, TRUE ) ) {
			$args['creator'] = get_current_user_id();
		}
		// فیلتر سازنده
		if ( ! empty( $args['creator'] ) && is_numeric( $args['creator'] ) ) {
			$where[]  = 't.creator = %d';
			$params[] = $args['creator'];
		}
		
		if ( ! empty( $args['user_id'] ) && is_numeric( $args['user_id'] ) ) {
			$where[]  = 't.user_id = %d';
			$params[] = $args['user_id'];
		}
		
		// فیلتر سرچ در عنوان و متن
		if ( ! empty( $args['search'] ) ) {
			$search   = '%' . $this->db->esc_like( $args['search'] ) . '%';
			$where[]  = '(t.title LIKE %s OR t.content LIKE %s)';
			$params[] = $search;
			$params[] = $search;
		}
		
		// فیلتر کاربر هدف
		if ( ! empty( $args['search_user'] ) ) {
			$user_list = kcp_get_user_list( $args['search_user'], - 1 )['users'] ?? [];
			$user_ids  = array_map( fn( $u ) => (int) $u['user_id'], $user_list );
			
			if ( ! empty( $user_ids ) ) {
				$placeholders = implode( ',', array_fill( 0, count( $user_ids ), '%d' ) );
				$where[]      = "t.user_id IN ($placeholders)";
				$params       = array_merge( $params, $user_ids );
			} else {
				return [
					'count'  => 0,
					'result' => [],
				];
			}
		}
		
		// فیلتر تاریخ ایجاد
		if ( ! empty( $args['date_from'] ) ) {
			$where[]  = 't.date >= %s';
			$params[] = nooshika_jalali_to_gregorian( $args['date_from'] );
		}
		if ( ! empty( $args['date_to'] ) ) {
			$where[]  = 't.date <= %s';
			$params[] = nooshika_jalali_to_gregorian( $args['date_to'] );
		}
		
		// فیلتر تاریخ انجام پیگیری (track_date)
		if ( ! empty( $args['due_date'] ) ) {
			$where[]  = 'DATE(t.track_date) = %s';
			$params[] = nooshika_jalali_to_gregorian( $args['due_date'] ) . ' 00:00:00';
		}
		
		// فیلتر نوع
		if ( ! empty( $args['type'] ) ) {
			$where[]  = 't.type = %s';
			$params[] = $args['type'];
		}
		
		// فیلتر وضعیت
		if ( ! empty( $args['status'] ) ) {
			$where[]  = 't.status = %s';
			$params[] = $args['status'];
		}
		
		$where_sql = implode( ' AND ', $where );
		
		$count_query = "
		SELECT COUNT(*)
		FROM {$this->track_table} AS t
		WHERE $where_sql
	";
		
		$query = "
		SELECT t.*
		FROM {$this->track_table} AS t
		WHERE $where_sql
		ORDER BY CASE WHEN t.status = 'pending' THEN 1 ELSE 0 END DESC , t.track_date ASC, t.track_hour ASC
		LIMIT %d OFFSET %d
	";
		
		$params[] = $args['per_page'];
		$params[] = $args['offset'];
		
		$prepared_query = $this->db->prepare( $query, ...$params );
		$results        = $this->db->get_results( $prepared_query, ARRAY_A );
		
		$total_count = (int) $this->db->get_var(
			$this->db->prepare( $count_query, ...array_slice( $params, 0, - 2 ) )
		);
		
		return [
			'count'  => $total_count,
			'result' => $results ?: [],
		];
	}
	
	public function add_user_track( array $data ): array {
		if ( empty( $data['user_id'] ) ) {
			return [
				'status' => 'error',
				'msg'    => 'کاربر انتخاب نشده است.',
			];
		}
		
		if ( empty( $data['title'] ) || empty( $data['content'] ) ) {
			return [
				'status' => 'error',
				'msg'    => 'عنوان و توضیحات الزامی است.',
			];
		}
		
		if ( empty( $data['track_date'] ) || empty( $data['track_hour'] ) ) {
			return [
				'status' => 'error',
				'msg'    => 'تاریخ و ساعت پیگیری الزامی است.',
			];
		}
		
		$insert_data = [
			'user_id'      => (int) $data['user_id'],
			'status'       => $data['status'] ?? 'pending',
			'title'        => sanitize_text_field( $data['title'] ),
			'content'      => wp_kses_post( $data['content'] ),
			'type'         => sanitize_text_field( $data['type'] ?? 'call' ),
			'track_date'   => sanitize_text_field( $data['track_date'] ),
			'track_hour'   => sanitize_text_field( $data['track_hour'] ),
			'date'         => $data['date_created'] ?? current_time( 'mysql' ),
			'creator'      => $data['creator'] ?? get_current_user_id(),
			'checked_date' => $data['checked_date'] ?? NULL,
			'check_result' => '',
		];
		
		$inserted = $this->db->insert( $this->track_table, $insert_data );
		
		if ( ! $inserted ) {
			return [
				'status' => 'error',
				'msg'    => 'ثبت پیگیری با خطا مواجه شد.',
			];
		}
		
		return [
			'status'   => 'success',
			'track_id' => $this->db->insert_id,
			'msg'      => 'پیگیری با موفقیت ثبت شد.',
		];
	}
	
	public function delete_user_track( $track_id ) {
		if ( $track_id <= 0 ) {
			return [
				'status' => 'error',
				'msg'    => 'شناسه پیگیری نامعتبر است.',
			];
		}
		
		$deleted = $this->db->delete( $this->track_table, [ 'item_id' => $track_id ] );
		if ( ! $deleted ) {
			return [
				'status' => 'error',
				'msg'    => 'حذف فعالیت با خطا مواجه شد.',
			];
		}
		
		return [
			'status' => 'success',
			'msg'    => 'فعالیت با موفقیت حذف شدند.',
		];
	}
	
	public function check_user_track( int $item_id, string $status, string $result ): array {
		if ( $item_id <= 0 ) {
			return [
				'status' => 'error',
				'msg'    => 'شناسه پیگیری نامعتبر است.',
			];
		}
		
		if ( ! in_array( $status, [
			'completed',
			'cancelled',
		], TRUE ) ) {
			return [
				'status' => 'error',
				'msg'    => 'وضعیت انتخاب‌شده نامعتبر است.',
			];
		}
		
		$updated = $this->db->update(
			$this->track_table,
			[
				'status'       => $status,
				'check_result' => wp_kses_post( $result ),
				'checked_date' => current_time( 'mysql' ),
				'checked_by'   => get_current_user_id(),
			],
			[ 'item_id' => $item_id ]
		);
		
		if ( $updated === FALSE ) {
			return [
				'status' => 'error',
				'msg'    => 'ثبت نتیجه پیگیری با خطا مواجه شد.',
			];
		}
		
		return [
			'status' => 'success',
			'msg'    => 'نتیجه پیگیری با موفقیت ثبت شد.',
		];
	}
	
	public function get_visits( array $args = [] ): array {
		$defaults = [
			'creator'     => NULL,
			'user_id'     => '',
			'search'      => '',
			'search_user' => '',
			'date_from'   => '',
			'date_to'     => '',
			'status'      => '',
			'intro'       => '',
			'per_page'    => 20,
			'offset'      => 0,
		];
		$args     = wp_parse_args( $args, $defaults );
		
		$where  = [ '1=1' ];
		$params = [];
		$joins  = '';
		if ( ! is_current_user_admin( 0, TRUE ) ) {
			$args['creator'] = get_current_user_id();
		}
		if ( ! empty( $args['creator'] ) && is_numeric( $args['creator'] ) ) {
			$where[]  = 't.creator = %d';
			$params[] = $args['creator'];
		}
		if ( ! empty( $args['user_id'] ) && is_numeric( $args['user_id'] ) ) {
			$where[]  = 't.user_id = %d';
			$params[] = $args['user_id'];
		}
		if ( ! empty( $args['search'] ) ) {
			$search   = '%' . $this->db->esc_like( $args['search'] ) . '%';
			$where[]  = 't.details LIKE %s';
			$params[] = $search;
		}
		if ( ! empty( $args['search_user'] ) ) {
			$user_list = kcp_get_user_list( $args['search_user'], - 1 )['users'] ?? [];
			$user_ids  = array_map( fn( $u ) => (int) $u['user_id'], $user_list );
			
			if ( ! empty( $user_ids ) ) {
				$placeholders = implode( ',', array_fill( 0, count( $user_ids ), '%d' ) );
				$where[]      = "t.user_id IN ($placeholders)";
				$params       = array_merge( $params, $user_ids );
			} else {
				return [
					'count'  => 0,
					'result' => [],
				];
			}
		}
		if ( ! empty( $args['date_from'] ) ) {
			$where[]  = 't.start_time >= %s';
			$params[] = nooshika_jalali_to_gregorian( $args['date_from'] ) . ' 00:00:00';
		}
		if ( ! empty( $args['date_to'] ) ) {
			$where[]  = 't.start_time <= %s';
			$params[] = nooshika_jalali_to_gregorian( $args['date_to'] ) . ' 23:59:59';
		}
		if ( ! empty( $args['status'] ) ) {
			$where[]  = 't.status = %s';
			$params[] = $args['status'];
		}
		
		if ( ! empty( $args['intro'] ) ) {
			$joins    .= " INNER JOIN {$this->db->usermeta} AS um ON um.user_id = t.user_id AND um.meta_key = 'ncp_user_intro_method'";
			$where[]  = 'um.meta_value = %s';
			$params[] = $args['intro'];
		}
		
		$where_sql = implode( ' AND ', $where );
		
		$count_query    = "
		SELECT COUNT(*)
		FROM {$this->visits_table} AS t $joins
		WHERE $where_sql
	";
		$duration_query = "
		SELECT SUM(duration)
		FROM {$this->visits_table} AS t $joins
		WHERE $where_sql
	";
		
		$query = "
		SELECT t.*
		FROM {$this->visits_table} AS t $joins
		WHERE $where_sql
		ORDER BY t.start_time DESC
		LIMIT %d OFFSET %d
	";
		
		$params[] = $args['per_page'];
		$params[] = $args['offset'];
		
		$prepared_query = $this->db->prepare( $query, ...$params );
		$results        = $this->db->get_results( $prepared_query, ARRAY_A );
		
		$total_count = (int) $this->db->get_var(
			$this->db->prepare( $count_query, ...array_slice( $params, 0, - 2 ) )
		);
		//		n_dump( $this->db->prepare( $count_query, ...array_slice( $params, 0, - 2 ) ) );
		
		$duration = (int) $this->db->get_var(
			$this->db->prepare( $duration_query, ...array_slice( $params, 0, - 2 ) )
		);
		
		return [
			'count'    => $total_count,
			'duration' => $duration,
			'result'   => $results ?: [],
		];
	}
	
	public function add_visit( array $data ): array {
		$start_time = current_time( 'mysql' );
		
		$insert_data = [
			'user_id'    => ! empty( $data['user_id'] ) ? (int) $data['user_id'] : 0,
			'start_time' => $start_time,
			'end_time'   => '0000-00-00 00:00:00',
			'duration'   => 0,
			'status'     => 'started',
			'creator'    => get_current_user_id(),
			'details'    => ! empty( $data['details'] ) ? wp_kses_post( $data['details'] ) : '',
		];
		
		$inserted = $this->db->insert( $this->visits_table, $insert_data );
		
		if ( ! $inserted ) {
			return [
				'status' => 'error',
				'msg'    => 'شروع ویزیت با خطا مواجه شد.',
			];
		}
		
		return [
			'status'   => 'success',
			'visit_id' => $this->db->insert_id,
			'msg'      => 'ویزیت با موفقیت آغاز شد.',
		];
	}
	
	public function delete_user_visit( $visit_id ) {
		if ( $visit_id <= 0 ) {
			return [
				'status' => 'error',
				'msg'    => 'شناسه ویزیت نامعتبر است.',
			];
		}
		
		$deleted = $this->db->delete( $this->visits_table, [ 'id' => $visit_id ] );
		if ( ! $deleted ) {
			return [
				'status' => 'error',
				'msg'    => 'حذف ویزیت با خطا مواجه شد.',
			];
		}
		
		return [
			'status' => 'success',
			'msg'    => 'ویزیت با موفقیت حذف شدند.',
		];
	}
	
	public function change_visit_status( array $data ): array {
		if ( empty( $data['visit_id'] ) || empty( $data['status'] ) ) {
			return [
				'status' => 'error',
				'msg'    => 'شناسه و وضعیت ویزیت الزامی هستند.',
			];
		}
		
		$visit_id = (int) $data['visit_id'];
		$status   = sanitize_text_field( $data['status'] );
		
		$visit = $this->db->get_row( $this->db->prepare(
			"SELECT start_time FROM {$this->visits_table} WHERE id = %d",
			$visit_id
		), ARRAY_A );
		
		if ( ! $visit ) {
			return [
				'status' => 'error',
				'msg'    => 'ویزیت یافت نشد.',
			];
		}
		
		$end_time        = current_time( 'mysql' );
		$start_timestamp = strtotime( $visit['start_time'] );
		$end_timestamp   = strtotime( $end_time );
		$duration        = max( 0, $end_timestamp - $start_timestamp );
		
		$update_data = [
			'status'   => $status,
			'end_time' => $end_time,
			'duration' => $duration,
		];
		
		$update_data['details'] = ! empty( $data['details'] ) ? wp_kses_post( $data['details'] ) : '';
		
		if ( ! empty( $data['user_id'] ) ) {
			$update_data['user_id'] = (int) $data['user_id'];
		}
		
		$formats = [ '%s' ];
		if ( isset( $update_data['end_time'] ) ) {
			$formats[] = '%s';
			$formats[] = '%d';
		}
		$formats[] = '%s';
		if ( isset( $update_data['user_id'] ) ) {
			$formats[] = '%d';
		}
		
		$updated = $this->db->update(
			$this->visits_table,
			$update_data,
			[ 'id' => $visit_id ],
			$formats,
			[ '%d' ]
		);
		
		if ( ! $updated ) {
			return [
				'status' => 'error',
				'msg'    => 'تغییر وضعیت ویزیت با خطا مواجه شد.',
			];
		}
		
		return [
			'status' => 'success',
			'msg'    => 'وضعیت ویزیت با موفقیت تغییر کرد.',
		];
	}
	
	public function add_call_request( array $data ): array {
		if ( empty( $data['user_id'] ) || empty( $data['category'] ) || empty( $data['content'] ) ) {
			return [
				'status' => 'error',
				'msg'    => 'اطلاعات ضروری ناقص است.',
			];
		}
		
		$inserted = $this->db->insert(
			$this->calls_table,
			[
				'user_id'    => $data['user_id'],
				'creator_id' => $data['creator'] ?? get_current_user_id(),
				'category'   => sanitize_text_field( $data['category'] ),
				'content'    => wp_kses_post( $data['content'] ),
				'status'     => sanitize_text_field( $data['status'] ?? 'new' ),
				'source'     => $data['source'] ?? 'customer',
				'created_at' => $data['date_created'] ?? current_time( 'mysql' ),
			]
		);
		
		if ( ! $inserted ) {
			return [
				'status' => 'error',
				'msg'    => 'ثبت درخواست با خطا مواجه شد.',
			];
		}
		$call_id = $this->db->insert_id;
		if ( ! empty( $data['attachment'] ) ) {
			$this->update_call_meta( $call_id, "attachment", esc_url_raw( $data['attachment'] ) );
		}
		$this->update_call_meta( $call_id, 'assigned_to', $data['assign'] );
		
		return [
			'status'  => 'success',
			'call_id' => $call_id,
			'msg'     => 'درخواست با موفقیت ثبت شد.',
		];
	}
	
	public function delete_user_call( $call_id ) {
		if ( $call_id <= 0 ) {
			return [
				'status' => 'error',
				'msg'    => 'شناسه نامعتبر است.',
			];
		}
		
		$deleted = $this->db->delete( $this->calls_table, [ 'id' => $call_id ] );
		if ( ! $deleted ) {
			return [
				'status' => 'error',
				'msg'    => 'حذف درخواست با خطا مواجه شد.',
			];
		}
		
		return [
			'status' => 'success',
			'msg'    => 'درخواست با موفقیت حذف شدند.',
		];
	}
	
	public function get_calls( array $args = [] ): array {
		$defaults = [
			'creator'     => NULL,
			'user_id'     => '',
			'search'      => '',
			'search_user' => '',
			'status'      => '',
			'category'    => '',
			'date_from'   => '',
			'date_to'     => '',
			'assigned'    => '',
			'source'      => 'customer',
			'per_page'    => 20,
			'offset'      => 0,
		];
		
		$args = wp_parse_args( $args, $defaults );
		
		$where  = [ '1=1' ];
		$params = [];
		
		// فیلتر نوع تماس
		$where[]   = 'c.source = %s';
		$params[]  = $args['source'];
		$join_meta = '';
		
		if ( ! is_current_user_admin( 0, FALSE ) ) {
			$args['creator'] = get_current_user_id();
		}
		if ( ! empty( $args['creator'] ) && is_numeric( $args['creator'] ) ) {
			if ( ! is_current_user_admin() ) {
				$join_meta = "LEFT JOIN {$this->calls_meta_table} AS cm
		              ON cm.call_id = c.id AND cm.meta_key = 'assigned_to'";
				$where[]   = '(c.creator_id = %d OR cm.meta_value = %d OR c.user_id = %d)';
				$params[]  = $args['creator'];
				$params[]  = $args['creator'];
				$params[]  = $args['creator'];
			} else {
				$where[]  = 'c.creator_id = %d';
				$params[] = $args['creator'];
			}
		}
		
		if ( ! empty( $args['user_id'] ) && is_numeric( $args['user_id'] ) ) {
			$where[]  = 'c.user_id = %d';
			$params[] = $args['user_id'];
		}
		
		if ( ! empty( $args['search'] ) ) {
			$search   = '%' . $this->db->esc_like( $args['search'] ) . '%';
			$where[]  = '(c.content LIKE %s OR c.category LIKE %s)';
			$params[] = $search;
			$params[] = $search;
		}
		
		if ( ! empty( $args['search_user'] ) ) {
			$user_list = kcp_get_user_list( $args['search_user'], - 1 )['users'] ?? [];
			$user_ids  = array_map( fn( $u ) => (int) $u['user_id'], $user_list );
			
			if ( ! empty( $user_ids ) ) {
				$placeholders = implode( ',', array_fill( 0, count( $user_ids ), '%d' ) );
				$where[]      = "c.user_id IN ($placeholders)";
				$params       = array_merge( $params, $user_ids );
			} else {
				return [
					'count'  => 0,
					'result' => [],
				];
			}
		}
		
		if ( ! empty( $args['status'] ) ) {
			$where[]  = 'c.status = %s';
			$params[] = $args['status'];
		}
		
		if ( ! empty( $args['category'] ) ) {
			$where[]  = 'c.category = %s';
			$params[] = $args['category'];
		}
		
		if ( ! empty( $args['date_from'] ) ) {
			$where[]  = 'c.created_at >= %s';
			$params[] = nooshika_jalali_to_gregorian( $args['date_from'] );
		}
		if ( ! empty( $args['date_to'] ) ) {
			$where[]  = 'c.created_at <= %s';
			$params[] = nooshika_jalali_to_gregorian( $args['date_to'] );
		}
		
		// مشخص‌کردن نیاز به JOIN متا
		if ( ! empty( $args['assigned'] ) && is_numeric( $args['assigned'] ) ) {
			$join_meta = "LEFT JOIN {$this->calls_meta_table} AS cm
		              ON cm.call_id = c.id AND cm.meta_key = 'assigned_to'";
			$where[]   = 'cm.meta_value = %d';
			$params[]  = $args['assigned'];
		}
		
		$where_sql = implode( ' AND ', $where );
		
		$count_query = "
		SELECT COUNT(*)
		FROM {$this->calls_table} AS c
		$join_meta
		WHERE $where_sql
	";
		
		$query = "
		SELECT c.*
		FROM {$this->calls_table} AS c
		$join_meta
		WHERE $where_sql
		ORDER BY c.created_at DESC
		LIMIT %d OFFSET %d
	";
		
		$params[] = $args['per_page'];
		$params[] = $args['offset'];
		
		$prepared_query = $this->db->prepare( $query, ...$params );
		$results        = $this->db->get_results( $prepared_query, ARRAY_A );
		
		$total_count = (int) $this->db->get_var(
			$this->db->prepare( $count_query, ...array_slice( $params, 0, - 2 ) )
		);
		
		return [
			'total'  => $total_count,
			'result' => $results ?: [],
		];
	}
	
	public function update_call_meta( int $call_id, string $key, $value ): bool {
		if ( $call_id <= 0 || empty( $key ) ) {
			return FALSE;
		}
		
		$exists = $this->db->get_var( $this->db->prepare(
			"SELECT id FROM {$this->calls_meta_table} WHERE call_id = %d AND meta_key = %s",
			$call_id, $key
		) );
		
		if ( $exists ) {
			return (bool) $this->db->update(
				$this->calls_meta_table,
				[ 'meta_value' => maybe_serialize( $value ) ],
				[
					'call_id'  => $call_id,
					'meta_key' => $key,
				]
			);
		} else {
			return (bool) $this->db->insert(
				$this->calls_meta_table,
				[
					'call_id'    => $call_id,
					'meta_key'   => $key,
					'meta_value' => maybe_serialize( $value ),
				]
			);
		}
	}
	
	public function get_call_meta( int $call_id, string $key, $default = NULL ) {
		if ( $call_id <= 0 || empty( $key ) ) {
			return $default;
		}
		
		$value = $this->db->get_var( $this->db->prepare(
			"SELECT meta_value FROM {$this->calls_meta_table} WHERE call_id = %d AND meta_key = %s",
			$call_id, $key
		) );
		
		return $value !== NULL ? maybe_unserialize( $value ) : $default;
	}
	
	public function delete_call_meta( int $call_id, string $key ): bool {
		if ( $call_id <= 0 || empty( $key ) ) {
			return FALSE;
		}
		
		return (bool) $this->db->delete(
			$this->calls_meta_table,
			[
				'call_id'  => $call_id,
				'meta_key' => $key,
			]
		);
	}
	
	public function get_call_progress( int $call_id ): array {
		if ( $call_id <= 0 ) {
			return [];
		}
		
		$query = $this->db->prepare(
			"SELECT * FROM {$this->calls_progress_table}
		 WHERE call_id = %d
		 ORDER BY changed_at ASC",
			$call_id
		);
		
		$results = $this->db->get_results( $query, ARRAY_A );
		
		return $results ?: [];
	}
	
	public function add_call_progress( array $data ): array {
		if ( empty( $data['call_id'] ) || empty( $data['to_status'] ) ) {
			return [
				'status' => 'error',
				'msg'    => 'شناسه درخواست یا وضعیت مقصد مشخص نیست.',
			];
		}
		
		$call_id   = (int) $data['call_id'];
		$to_status = sanitize_text_field( $data['to_status'] );
		$to_cat    = ! empty( $data['to_category'] ) ? sanitize_text_field( $data['to_category'] ) : NULL;
		$comment   = wp_kses_post( $data['comment'] ?? '' );
		
		// دریافت اطلاعات فعلی تماس
		$call = $this->db->get_row( $this->db->prepare(
			"SELECT status, category FROM {$this->calls_table} WHERE id = %d",
			$call_id
		), ARRAY_A );
		
		if ( empty( $call ) ) {
			return [
				'status' => 'error',
				'msg'    => 'درخواست مورد نظر یافت نشد.',
			];
		}
		
		$from_status   = $call['status'];
		$from_category = $call['category'];
		
		$creator_id   = $call['creator_id'];
		$admin_number = get_user_meta( $creator_id, 'marketer_phone_num', TRUE );
		$sms_data     = [
			'token' => sanitize_string_for_pattern( get_user_name_by_id( get_current_user_id() ) ),
		];
		crm_send_sms( $admin_number, $sms_data, 'requestAnswered' );
		
		$progress_data = [
			'call_id'       => $call_id,
			'from_status'   => $from_status,
			'to_status'     => $to_status,
			'from_category' => $from_category,
			'to_category'   => $to_cat ?? $from_category,
			'comment'       => $comment,
			'changed_by'    => $data['creator'] ?? get_current_user_id(),
			'changed_at'    => $data['date_created'] ?? current_time( 'mysql' ),
		];
		$inserted      = $this->db->insert( $this->calls_progress_table, $progress_data );
		
		if ( ! $inserted ) {
			return [
				'status' => 'error',
				'msg'    => 'ثبت گردش وضعیت با خطا مواجه شد.',
			];
		}
		
		$progress_id = $this->db->insert_id;
		
		// آپدیت وضعیت و دسته‌بندی در جدول تماس
		$update_data = [ 'status' => $to_status ];
		if ( $to_cat !== NULL && $to_cat !== $from_category ) {
			$update_data['category'] = $to_cat;
		}
		
		$this->db->update(
			$this->calls_table,
			$update_data,
			[ 'id' => $call_id ]
		);
		if ( ! empty( $data['attachment'] ) ) {
			$this->update_call_meta( $call_id, "attachment_$progress_id", esc_url_raw( $data['attachment'] ) );
		}
		$assigned_from = $this->get_call_meta( $call_id, 'assigned_to' );
		if ( $data['assign'] ) {
			$this->update_call_meta( $call_id, "assigned_from_$progress_id", $assigned_from );
			$this->update_call_meta( $call_id, "assigned_to_$progress_id", $data['assign'] );
			$this->update_call_meta( $call_id, 'assigned_to', $data['assign'] );
		}
		
		return [
			'status'      => 'success',
			'progress_id' => $this->db->insert_id,
			'msg'         => 'اطلاعات با موفقیت به‌روز شد.',
		];
	}
	
	public function delete_call_progress( int $progress_id ): array {
		if ( $progress_id <= 0 ) {
			return [
				'status' => 'error',
				'msg'    => 'شناسه نامعتبر است.',
			];
		}
		
		$deleted = $this->db->delete(
			$this->calls_progress_table,
			[ 'id' => $progress_id ],
			[ '%d' ]
		);
		
		if ( ! $deleted ) {
			return [
				'status' => 'error',
				'msg'    => 'حذف گردش وضعیت با خطا مواجه شد.',
			];
		}
		
		return [
			'status' => 'success',
			'msg'    => 'گردش وضعیت با موفقیت حذف شد.',
		];
	}
	
	public function get_warning_templates() {
		return $this->db->get_results(
			"SELECT * FROM
			  $this->warning_table ORDER BY date DESC",
			ARRAY_A
		);
	}
	
	public function get_warning_template( $id ) {
		return $this->db->get_row(
			"SELECT * FROM
			  $this->warning_table WHERE id = $id",
			ARRAY_A
		);
	}
	
	public function add_warning_template( array $data ): array {
		if ( empty( $data['title'] ) || empty( $data['template'] ) ) {
			return [
				'status' => 'error',
				'msg'    => 'عنوان و متن الگو الزامی است.',
			];
		}
		
		$insert_data = [
			'title'    => sanitize_text_field( $data['title'] ),
			'template' => wp_kses_post( $data['template'] ),
			'token'    => sanitize_text_field( $data['token'] ?? '' ),
			'token2'   => sanitize_text_field( $data['token2'] ?? '' ),
			'token3'   => sanitize_text_field( $data['token3'] ?? '' ),
			'date'     => current_time( 'mysql' ),
			'creator'  => get_current_user_id(),
		];
		
		$inserted = $this->db->insert( $this->warning_table, $insert_data );
		
		if ( ! $inserted ) {
			return [
				'status' => 'error',
				'msg'    => 'ثبت الگو با خطا مواجه شد.',
			];
		}
		
		return [
			'status'      => 'success',
			'template_id' => $this->db->insert_id,
			'msg'         => 'الگوی هشدار با موفقیت ثبت شد.',
		];
	}
	
	public function update_warning_template( $template_id, $data ): array {
		if ( $template_id <= 0 ) {
			return [
				'status' => 'error',
				'msg'    => 'شناسه الگو نامعتبر است.',
			];
		}
		
		if ( empty( $data['title'] ) || empty( $data['template'] ) ) {
			return [
				'status' => 'error',
				'msg'    => 'عنوان و متن الگو الزامی است.',
			];
		}
		
		$update_data = [
			'title'    => sanitize_text_field( $data['title'] ),
			'template' => wp_kses_post( $data['template'] ),
			'token'    => sanitize_text_field( $data['token'] ?? '' ),
			'token2'   => sanitize_text_field( $data['token2'] ?? '' ),
			'token3'   => sanitize_text_field( $data['token3'] ?? '' ),
		];
		
		$updated = $this->db->update(
			$this->warning_table,
			$update_data,
			[ 'id' => $template_id ]
		);
		
		if ( ! $updated ) {
			return [
				'status' => 'error',
				'msg'    => 'ویرایش الگو با خطا مواجه شد.',
			];
		}
		
		return [
			'status' => 'success',
			'msg'    => 'الگوی هشدار با موفقیت ویرایش شد.',
		];
	}
	
	public function delete_warning_template( int $template_id ): array {
		if ( $template_id <= 0 ) {
			return [
				'status' => 'error',
				'msg'    => 'شناسه الگو نامعتبر است.',
			];
		}
		
		$deleted = $this->db->delete(
			$this->warning_table,
			[ 'id' => $template_id ],
			[ '%d' ]
		);
		
		if ( ! $deleted ) {
			return [
				'status' => 'error',
				'msg'    => 'حذف الگو با خطا مواجه شد.',
			];
		}
		
		return [
			'status' => 'success',
			'msg'    => 'الگوی هشدار با موفقیت حذف شد.',
		];
	}
	
	public function add_warning_log( array $data ): array {
		if ( empty( $data['user_id'] ) || empty( $data['warning_id'] ) || empty( $data['message'] ) ) {
			return [
				'status' => 'error',
				'msg'    => 'اطلاعات ضروری ناقص است.',
			];
		}
		
		$inserted = $this->db->insert(
			$this->warning_log_table,
			[
				'user_id'    => (int) $data['user_id'],
				'sender'     => get_current_user_id(),
				'warning_id' => (int) $data['warning_id'],
				'message'    => wp_kses_post( $data['message'] ),
				'date'       => current_time( 'mysql' ),
			]
		);
		
		if ( ! $inserted ) {
			return [
				'status' => 'error',
				'msg'    => 'ثبت لاگ هشدار با خطا مواجه شد.',
			];
		}
		
		return [
			'status' => 'success',
			'log_id' => $this->db->insert_id,
			'msg'    => 'هشدار با موفقیت ثبت شد.',
		];
	}
	
	public function get_warning_logs( array $args = [] ): array {
		$defaults = [
			'user_id'    => NULL,
			'sender'     => NULL,
			'warning_id' => NULL,
			'date_from'  => '',
			'date_to'    => '',
			'per_page'   => 20,
			'offset'     => 0,
		];
		
		$args   = wp_parse_args( $args, $defaults );
		$where  = [ '1=1' ];
		$params = [];
		
		if ( ! empty( $args['user_id'] ) && is_numeric( $args['user_id'] ) ) {
			$where[]  = 'l.user_id = %d';
			$params[] = (int) $args['user_id'];
		}
		
		if ( ! empty( $args['sender'] ) && is_numeric( $args['sender'] ) ) {
			$where[]  = 'l.sender = %d';
			$params[] = (int) $args['sender'];
		}
		
		if ( ! empty( $args['warning_id'] ) && is_numeric( $args['warning_id'] ) ) {
			$where[]  = 'l.warning_id = %d';
			$params[] = (int) $args['warning_id'];
		}
		
		if ( ! empty( $args['date_from'] ) ) {
			$where[]  = 'l.date >= %s';
			$params[] = nooshika_jalali_to_gregorian( $args['date_from'] );
		}
		
		if ( ! empty( $args['date_to'] ) ) {
			$where[]  = 'l.date <= %s';
			$params[] = nooshika_jalali_to_gregorian( $args['date_to'] );
		}
		
		$where_sql = implode( ' AND ', $where );
		
		$count_query = "
		SELECT COUNT(*)
		FROM {$this->warning_log_table} AS l
		WHERE $where_sql
	";
		
		$select_query = "
		SELECT l.*, t.title AS warning_title
		FROM {$this->warning_log_table} AS l
		LEFT JOIN {$this->warning_table} AS t ON l.warning_id = t.id
		WHERE $where_sql
		ORDER BY l.date DESC
		LIMIT %d OFFSET %d
	";
		
		$params[] = (int) $args['per_page'];
		$params[] = (int) $args['offset'];
		
		$results = $this->db->get_results(
			$this->db->prepare( $select_query, ...$params ),
			ARRAY_A
		);
		
		$total = (int) $this->db->get_var(
			$this->db->prepare( $count_query, ...array_slice( $params, 0, - 2 ) )
		);
		
		return [
			'count'  => $total,
			'result' => $results ?: [],
		];
	}
	
	public function count_warning_by_template_id( int $warning_id ): int {
		if ( $warning_id <= 0 ) {
			return 0;
		}
		
		return (int) $this->db->get_var( $this->db->prepare(
			"SELECT COUNT(*) FROM {$this->warning_log_table} WHERE warning_id = %d",
			$warning_id
		) );
	}
	
	public function count_warning_by_user_id( int $user_id ): int {
		if ( $user_id <= 0 ) {
			return 0;
		}
		
		return (int) $this->db->get_var( $this->db->prepare(
			"SELECT COUNT(*) FROM {$this->warning_log_table} WHERE user_id = %d",
			$user_id
		) );
	}
	
	public function add_employee_report( array $data ): array {
		$report_id = ! empty( $data['report_id'] ) ? absint( $data['report_id'] ) : 0;
		
		if ( empty( $data['title'] ) || empty( $data['content'] ) ) {
			return [
				'status' => 'error',
				'msg'    => 'عنوان و توضیحات باید وارد شوند.',
			];
		}
		
		$save_data = [
			'title'    => sanitize_text_field( $data['title'] ),
			'content'  => wp_kses_post( $data['content'] ),
			'category' => sanitize_text_field( $data['category'] ),
		];
		
		/**
		 * Update
		 */
		if ( $report_id ) {
			$where = [
				'id' => $report_id,
			];
			
			// اگر ادمین نیست، فقط گزارش خودش را بتواند ویرایش کند.
			if ( ! is_current_user_admin() ) {
				$where['employee_id'] = get_current_user_id();
			}
			
			$updated = $this->db->update(
				$this->reports_table,
				$save_data,
				$where
			);
			
			if ( FALSE === $updated ) {
				return [
					'status' => 'error',
					'msg'    => 'ویرایش گزارش با خطا مواجه شد.',
				];
			}
			
			$this->add_employee_report_meta(
				$report_id,
				'attachment',
				! empty( $data['attachment'] ) ? esc_url_raw( $data['attachment'] ) : ''
			);
			
			return [
				'status'    => 'success',
				'action_id' => $report_id,
				'msg'       => 'گزارش با موفقیت ویرایش شد.',
			];
		}
		
		/**
		 * Insert
		 */
		$insert_data = array_merge( $save_data, [
			'employee_id' => get_current_user_id(),
			'created_at'  => current_time( 'mysql' ),
		] );
		
		$inserted = $this->db->insert( $this->reports_table, $insert_data );
		
		if ( ! $inserted ) {
			return [
				'status' => 'error',
				'msg'    => 'ثبت گزارش با خطا مواجه شد.',
			];
		}
		
		$report_id = (int) $this->db->insert_id;
		
		if ( ! empty( $data['attachment'] ) ) {
			$this->add_employee_report_meta(
				$report_id,
				'attachment',
				esc_url_raw( $data['attachment'] )
			);
		}
		
		return [
			'status'    => 'success',
			'action_id' => $report_id,
			'msg'       => 'گزارش با موفقیت ثبت شد.',
		];
	}
	
	public function delete_employee_report( int $report_id ): array {
		$report_id = absint( $report_id );
		
		if ( ! $report_id ) {
			return [
				'status' => 'error',
				'msg'    => 'شناسه گزارش معتبر نیست.',
			];
		}
		
		$where = [
			'id' => $report_id,
		];
		
		// اگر ادمین نیست، فقط گزارش خودش را بتواند حذف کند.
		if ( ! is_current_user_admin() ) {
			$where['employee_id'] = get_current_user_id();
		}
		
		$report = $this->db->get_row(
			$this->db->prepare(
				"SELECT * FROM {$this->reports_table} WHERE id = %d LIMIT 1",
				$report_id
			),
			ARRAY_A
		);
		
		if ( ! $report ) {
			return [
				'status' => 'error',
				'msg'    => 'گزارش مورد نظر یافت نشد.',
			];
		}
		
		if ( ! is_current_user_admin() && (int) $report['employee_id'] !== get_current_user_id() ) {
			return [
				'status' => 'error',
				'msg'    => 'شما دسترسی حذف این گزارش را ندارید.',
			];
		}
		
		$deleted = $this->db->delete(
			$this->reports_table,
			$where
		);
		
		if ( FALSE === $deleted ) {
			return [
				'status' => 'error',
				'msg'    => 'حذف گزارش با خطا مواجه شد.',
			];
		}
		
		return [
			'status'    => 'success',
			'action_id' => $report_id,
			'msg'       => 'گزارش با موفقیت حذف شد.',
		];
	}
	
	public function add_employee_report_meta( int $report_id, string $key, string $value ): void {
		if ( $report_id <= 0 || $key === '' ) {
			return;
		}
		
		$this->db->insert( $this->reports_meta_table, [
			'report_id'  => $report_id,
			'meta_key'   => $key,
			'meta_value' => $value,
		] );
	}
	
	public function get_employee_report_meta( int $report_id, string $key = '', bool $single = TRUE ) {
		if ( $report_id <= 0 ) {
			return $single ? NULL : [];
		}
		
		if ( $key !== '' ) {
			$query  = $this->db->prepare(
				"SELECT meta_value FROM {$this->reports_meta_table} WHERE report_id = %d AND meta_key = %s",
				$report_id,
				$key
			);
			$values = $this->db->get_col( $query );
			
			if ( $single ) {
				return $values[0] ?? NULL;
			}
			
			return $values;
		}
		
		// بدون کلید خاص → همه متاها رو بیار
		$results = $this->db->get_results(
			$this->db->prepare(
				"SELECT meta_key, meta_value FROM {$this->reports_meta_table} WHERE report_id = %d",
				$report_id
			),
			ARRAY_A
		);
		
		if ( empty( $results ) ) {
			return [];
		}
		
		$meta = [];
		
		foreach ( $results as $row ) {
			$k = $row['meta_key'];
			$v = $row['meta_value'];
			
			if ( isset( $meta[ $k ] ) ) {
				if ( is_array( $meta[ $k ] ) ) {
					$meta[ $k ][] = $v;
				} else {
					$meta[ $k ] = [
						$meta[ $k ],
						$v,
					];
				}
			} else {
				$meta[ $k ] = $v;
			}
		}
		
		return $meta;
	}
	
	public function get_employee_reports( array $args = [] ): array {
		$defaults = [
			'employee_id' => NULL,
			'category'    => '',
			'search'      => '',
			'date_from'   => '',
			'date_to'     => '',
			'per_page'    => 20,
			'offset'      => 0,
		];
		
		$args   = wp_parse_args( $args, $defaults );
		$where  = [ '1=1' ];
		$params = [];
		
		if ( ! empty( $args['employee_id'] ) ) {
			$where[]  = 'r.employee_id = %d';
			$params[] = $args['employee_id'];
		}
		
		if ( ! empty( $args['status'] ) ) {
			$where[]  = 'r.category = %s';
			$params[] = $args['category'];
		}
		
		if ( ! empty( $args['search'] ) ) {
			$search   = '%' . $this->db->esc_like( $args['search'] ) . '%';
			$where[]  = '(r.title LIKE %s OR r.content LIKE %s)';
			$params[] = $search;
			$params[] = $search;
		}
		
		if ( ! empty( $args['date_from'] ) ) {
			$where[]  = 'r.created_at >= %s';
			$params[] = nooshika_jalali_to_gregorian( $args['date_from'] );
		}
		if ( ! empty( $args['date_to'] ) ) {
			$where[]  = 'r.created_at <= %s';
			$params[] = nooshika_jalali_to_gregorian( $args['date_to'] );
		}
		
		$where_sql = implode( ' AND ', $where );
		
		$count_query = "SELECT COUNT(*)  FROM {$this->reports_table} AS r  WHERE $where_sql ";
		
		$query = "SELECT r.*  FROM {$this->reports_table} AS r WHERE $where_sql ORDER BY r.created_at DESC LIMIT %d OFFSET %d";
		
		$params[] = $args['per_page'];
		$params[] = $args['offset'];
		
		$results = $this->db->get_results( $this->db->prepare( $query, ...$params ), ARRAY_A );
		$count   = (int) $this->db->get_var( $this->db->prepare( $count_query, ...array_slice( $params, 0, - 2 ) ) );
		
		return [
			'count'  => $count,
			'result' => $results ?: [],
		];
	}
	
	public function add_installment( array $args ): int|false {
		$args = wp_parse_args( $args, [
			'order_id'                => 0,
			'user_id'                 => NULL,
			'payment_user_name'       => NULL,
			'payment_user_nid'        => NULL,
			'payment_plan_name'       => '',
			'payment_plan_start_date' => NULL,
			'payment_plan_month'      => 0,
			'payment_plan_amount'     => 0,
			'payment_rec_number'      => NULL,
			'payment_rec_date'        => NULL,
			'payment_recorded_bank'   => NULL,
			'payment_recorded_by'     => NULL,
			'payment_recorded_date'   => NULL,
			'note'                    => NULL,
		] );
		
		if ( $args['order_id'] <= 0 ) {
			return FALSE;
		}
		
		$this->db->query( 'START TRANSACTION' );
		
		$inserted = $this->db->insert(
			$this->installments,
			array_merge( $args, [
				'created_at' => current_time( 'mysql' ),
			] ),
			[
				'%d',
				'%d',
				'%s',
				'%s',
				'%s',
				'%s',
				'%d',
				'%d',
				'%s',
				'%s',
				'%s',
				'%d',
				'%s',
				'%s',
				'%s',
			]
		);
		
		if ( ! $inserted ) {
			$this->db->query( 'ROLLBACK' );
			
			return FALSE;
		}
		
		$id = (int) $this->db->insert_id;
		$this->db->query( 'COMMIT' );
		
		return $id;
	}
	
	public function add_cash_payment( array $args ): int|false {
		$args = wp_parse_args( $args, [
			'order_id'  => 0,
			'user_id'   => NULL,
			'amount'    => 0,
			'bank'      => NULL,
			'paid_date' => NULL,
		] );
		
		if ( $args['order_id'] <= 0 || $args['amount'] <= 0 ) {
			return FALSE;
		}
		
		$this->db->query( 'START TRANSACTION' );
		
		$inserted = $this->db->insert(
			$this->cash_payments,
			[
				'order_id'   => $args['order_id'],
				'user_id'    => $args['user_id'],
				'amount'     => $args['amount'],
				'bank'       => $args['bank'],
				'paid_date'  => $args['paid_date'],
				'created_at' => current_time( 'mysql' ),
			],
		);
		
		if ( ! $inserted ) {
			$this->db->query( 'ROLLBACK' );
			
			return FALSE;
		}
		
		$id = (int) $this->db->insert_id;
		$this->db->query( 'COMMIT' );
		
		return $id;
	}
	
	public function add_order_cheque( array $args ): int|false {
		$args = wp_parse_args( $args, [
			'order_id'        => 0,
			'user_id'         => NULL,
			'check_serial'    => '',
			'check_amount'    => 0,
			'check_expire'    => NULL,
			'bank_name'       => NULL,
			'branch_name'     => NULL,
			'current_account' => NULL,
			'account_owner'   => NULL,
			'national_code'   => NULL,
			'status'          => 'registered',
			'note'            => NULL,
		] );
		
		if ( $args['order_id'] <= 0 || ! $args['check_serial'] || $args['check_amount'] <= 0 ) {
			return FALSE;
		}
		
		$this->db->query( 'START TRANSACTION' );
		
		$inserted = $this->db->insert(
			$this->order_cheques,
			array_merge( $args, [
				'created_at' => current_time( 'mysql' ),
			] ),
			[
				'%d',
				'%d',
				'%s',
				'%d',
				'%s',
				'%s',
				'%s',
				'%s',
				'%s',
				'%s',
				'%s',
				'%s',
			]
		);
		
		if ( ! $inserted ) {
			$this->db->query( 'ROLLBACK' );
			
			return FALSE;
		}
		
		$id = (int) $this->db->insert_id;
		$this->db->query( 'COMMIT' );
		
		return $id;
	}
	
	public function delete_cash_payment( array $args ): bool {
		$args = wp_parse_args( $args, [
			'id'       => 0,
			'order_id' => 0,
		] );
		
		if ( $args['id'] <= 0 && $args['order_id'] <= 0 ) {
			return FALSE;
		}
		
		$where  = [];
		$format = [];
		
		if ( $args['id'] > 0 ) {
			$where['id'] = (int) $args['id'];
			$format[]    = '%d';
		}
		
		if ( $args['order_id'] > 0 ) {
			$where['order_id'] = (int) $args['order_id'];
			$format[]          = '%d';
		}
		
		$this->db->query( 'START TRANSACTION' );
		
		$deleted = $this->db->delete( $this->cash_payments, $where, $format );
		
		if ( $deleted === FALSE ) {
			$this->db->query( 'ROLLBACK' );
			
			return FALSE;
		}
		
		$this->db->query( 'COMMIT' );
		
		return TRUE;
	}
	
	public function delete_order_cheque( array $args ): bool {
		$args = wp_parse_args( $args, [
			'id'       => 0,
			'order_id' => 0,
		] );
		
		if ( $args['id'] <= 0 && $args['order_id'] <= 0 ) {
			return FALSE;
		}
		
		$where  = [];
		$format = [];
		
		if ( $args['id'] > 0 ) {
			$where['id'] = (int) $args['id'];
			$format[]    = '%d';
		}
		
		if ( $args['order_id'] > 0 ) {
			$where['order_id'] = (int) $args['order_id'];
			$format[]          = '%d';
		}
		
		$this->db->query( 'START TRANSACTION' );
		
		$deleted = $this->db->delete( $this->order_cheques, $where, $format );
		
		if ( $deleted === FALSE ) {
			$this->db->query( 'ROLLBACK' );
			
			return FALSE;
		}
		
		$this->db->query( 'COMMIT' );
		
		return TRUE;
	}
	
	public function delete_installment( int $order_id ): bool {
		if ( $order_id <= 0 ) {
			return FALSE;
		}
		
		$this->db->query( 'START TRANSACTION' );
		
		$deleted = $this->db->delete(
			$this->installments,
			[
				'order_id' => $order_id,
			],
			[
				'%d',
			]
		);
		
		if ( $deleted === FALSE ) {
			$this->db->query( 'ROLLBACK' );
			
			return FALSE;
		}
		
		$this->db->query( 'COMMIT' );
		
		return TRUE;
	}
	
	public function get_installments( array $args = [] ): array {
		$args = wp_parse_args( $args, [
			'order_id'  => 0,
			'date_from' => NULL, // Y-m-d
			'date_to'   => NULL, // Y-m-d
		] );
		
		$wheres = [];
		$params = [];
		
		if ( $args['order_id'] > 0 ) {
			$wheres[] = 'order_id = %d';
			$params[] = $args['order_id'];
		}
		
		if ( $args['date_from'] ) {
			$wheres[] = 'DATE(created_at) >= %s';
			$params[] = nooshika_jalali_to_gregorian( $args['date_from'] ) . ' 00:00:00';
		}
		
		if ( $args['date_to'] ) {
			$wheres[] = 'DATE(created_at) <= %s';
			$params[] = nooshika_jalali_to_gregorian( $args['date_to'] ) . ' 23:59:59';
		}
		
		$where_sql = $wheres ? 'WHERE ' . implode( ' AND ', $wheres ) : '';
		
		$sql = "
		SELECT *
		FROM {$this->installments}
		{$where_sql}
		ORDER BY created_at ASC
	";
		
		return $this->db->get_results(
			$this->db->prepare( $sql, $params ),
			ARRAY_A
		) ?: [];
	}
	
	public function get_cash_payments( array $args = [] ): array {
		$args = wp_parse_args( $args, [
			'order_id'  => 0,
			'date_from' => NULL, // Y-m-d
			'date_to'   => NULL, // Y-m-d
			'bank'      => NULL,
		] );
		
		$wheres = [];
		$params = [];
		
		if ( $args['order_id'] > 0 ) {
			$wheres[] = 'order_id = %d';
			$params[] = $args['order_id'];
		}
		
		if ( $args['date_from'] ) {
			$wheres[] = 'paid_date >= %s';
			$params[] = nooshika_jalali_to_gregorian( $args['date_from'] ) . ' 00:00:00';
		}
		
		if ( $args['date_to'] ) {
			$wheres[] = 'paid_date <= %s';
			$params[] = nooshika_jalali_to_gregorian( $args['date_to'] ) . ' 23:59:59';
		}
		
		if ( $args['bank'] ) {
			$wheres[] = 'bank = %s';
			$params[] = $args['bank'];
		}
		
		$where_sql = $wheres ? 'WHERE ' . implode( ' AND ', $wheres ) : '';
		
		$sql = "
		SELECT *
		FROM {$this->cash_payments}
		{$where_sql}
		ORDER BY paid_date ASC, created_at ASC
	";
		
		return $this->db->get_results(
			$this->db->prepare( $sql, $params ),
			ARRAY_A
		) ?: [];
	}
	
	public function get_order_cheques( array $args = [] ): array {
		$args = wp_parse_args( $args, [
			'order_id'  => 0,
			'date_from' => NULL, // Y-m-d (check_expire)
			'date_to'   => NULL,
			'status'    => NULL,
		] );
		
		$wheres = [];
		$params = [];
		
		if ( $args['order_id'] > 0 ) {
			$wheres[] = 'order_id = %d';
			$params[] = $args['order_id'];
		}
		
		if ( $args['date_from'] ) {
			$wheres[] = 'check_expire >= %s';
			$params[] = nooshika_jalali_to_gregorian( $args['date_from'] ) . ' 00:00:00';
		}
		
		if ( $args['date_to'] ) {
			$wheres[] = 'check_expire <= %s';
			$params[] = nooshika_jalali_to_gregorian( $args['date_to'] ) . ' 23:59:59';
		}
		
		if ( $args['status'] ) {
			$wheres[] = 'status = %s';
			$params[] = $args['status'];
		}
		
		$where_sql = $wheres ? 'WHERE ' . implode( ' AND ', $wheres ) : '';
		
		$sql = "
		SELECT *
		FROM {$this->order_cheques}
		{$where_sql}
		ORDER BY check_expire ASC, created_at ASC
	";
		
		return $this->db->get_results(
			$this->db->prepare( $sql, $params ),
			ARRAY_A
		) ?: [];
	}
	
	public function migrate_order_payment_meta_to_tables( int $page = 1, int $per_page = 50 ): array {
		$args = [
			'limit'      => max( 1, $per_page ),
			'page'       => max( 1, $page ),
			'orderby'    => 'ID',
			'order'      => 'ASC',
			'status'     => array_keys( wc_get_order_statuses() ),
			'meta_query' => [
				[
					'key'     => '_kcp_payment_tables_migrated',
					'compare' => 'NOT EXISTS',
				],
			],
		];
		
		/** @var WC_Order[] $orders */
		$orders = wc_get_orders( $args );
		if ( empty( $orders ) ) {
			return [
				'done'  => TRUE,
				'count' => 0,
				'page'  => $page,
			];
		}
		
		$count = 0;
		
		foreach ( $orders as $order ) {
			$order_id = (int) $order->get_id();
			if ( $order->get_meta( '_kcp_payment_tables_migrated', TRUE ) ) {
				continue;
			}
			
			$this->db->query( 'START TRANSACTION' );
			
			$ok = TRUE;
			
			/* ===============================
			 * installments (single object)
			 * =============================== */
			$installment = $order->get_meta( '_ksm_order_payment_extra_data', TRUE );
			if ( is_array( $installment ) && ! empty( $installment ) ) {
				$installment['order_id'] = $order_id;
				$installment['user_id']  = (int) $order->get_user_id();
				
				if ( ! empty( $installment['payment_plan_start_date'] ) ) {
					$installment['payment_plan_start_date'] = $this->normalize_date_to_gregorian( $installment['payment_plan_start_date'] );
				}
				if ( ! empty( $installment['payment_rec_date'] ) ) {
					$installment['payment_rec_date'] = $this->normalize_date_to_gregorian( $installment['payment_rec_date'] );
				}
				if ( ! empty( $installment['payment_recorded_date'] ) ) {
					// اگر تاریخ فقط Y-m-d بود، همون بمونه؛ اگر شمسی بود تبدیل میشه
					$installment['payment_recorded_date'] = $this->normalize_datetime_to_gregorian( $installment['payment_recorded_date'] );
				}
				
				$insert_id = $this->add_installment( $installment );
				if ( ! $insert_id ) {
					$ok = FALSE;
				}
			}
			
			/* ===============================
			 * cash payments (list)
			 * =============================== */
			if ( $ok ) {
				$cash_list = $order->get_meta( '_ksm_order_cash_payments_data', TRUE ) ?: [];
				if ( is_array( $cash_list ) ) {
					foreach ( $cash_list as $cash ) {
						$paid_date = $cash['date'] ?? NULL;
						if ( $paid_date ) {
							$paid_date = $this->normalize_date_to_gregorian( $paid_date );
						}
						
						$insert_id = $this->add_cash_payment( [
							'order_id'  => $order_id,
							'user_id'   => (int) $order->get_user_id(),
							'amount'    => (int) ( $cash['amount'] ?? 0 ),
							'bank'      => $cash['bank'] ?? NULL,
							'paid_date' => $paid_date,
						] );
						
						if ( $insert_id === FALSE ) {
							$ok = FALSE;
							break;
						}
					}
				}
			}
			
			/* ===============================
			 * cheques (list)
			 * =============================== */
			if ( $ok ) {
				$cheque_list = $order->get_meta( '_ksm_order_payments_data', TRUE ) ?: [];
				if ( is_array( $cheque_list ) ) {
					foreach ( $cheque_list as $cheque ) {
						$expire = $cheque['check_expire'] ?? NULL;
						if ( $expire ) {
							$expire = $this->normalize_date_to_gregorian( $expire );
						}
						
						$insert_id = $this->add_order_cheque( [
							'order_id'        => $order_id,
							'user_id'         => (int) $order->get_user_id(),
							'check_serial'    => (string) ( $cheque['check_serial'] ?? '' ),
							'check_amount'    => (int) ( $cheque['check_amount'] ?? 0 ),
							'check_expire'    => $expire,
							'bank_name'       => $cheque['bank_name'] ?? NULL,
							'branch_name'     => $cheque['branch_name'] ?? NULL,
							'current_account' => $cheque['current_account'] ?? NULL,
							'account_owner'   => $cheque['account_owner'] ?? NULL,
							'national_code'   => $cheque['national_code'] ?? NULL,
						] );
						
						if ( $insert_id === FALSE ) {
							$ok = FALSE;
							break;
						}
					}
				}
			}
			
			if ( ! $ok ) {
				$this->db->query( 'ROLLBACK' );
				continue;
			}
			
			// فلگ: فقط وقتی همه insert ها موفق بودن
			$order->update_meta_data( '_kcp_payment_tables_migrated', 1 );
			$order->update_meta_data( '_kcp_payment_tables_migrated_at', current_time( 'mysql' ) );
			$order->save(); // HPOS-safe
			
			$this->db->query( 'COMMIT' );
			
			$count ++;
		}
		
		return [
			'done'  => FALSE,
			'count' => $count,
			'page'  => $page,
		];
	}
	
	/**
	 * تاریخ ورودی اگر شمسی بود (مثلاً 1404-12-01 یا 1404/12/01) تبدیل می‌کند،
	 * اگر میلادی بود همان را برمی‌گرداند.
	 */
	private function normalize_date_to_gregorian( $date ): ?string {
		$date = is_string( $date ) ? trim( $date ) : '';
		if ( $date === '' ) {
			return NULL;
		}
		
		// اگر شبیه شمسی بود: 13xx/.. یا 14xx/..
		if ( preg_match( '/^(13|14)\d{2}[-\/]\d{1,2}[-\/]\d{1,2}$/', $date ) ) {
			$date = str_replace( '/', '-', $date );
			
			return nooshika_jalali_to_gregorian( $date );
		}
		
		// اگر میلادی Y-m-d بود
		if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ) {
			return $date;
		}
		
		// fallback: اگر چیزی مثل Y/m/d بود
		if ( preg_match( '/^\d{4}\/\d{2}\/\d{2}$/', $date ) ) {
			return str_replace( '/', '-', $date );
		}
		
		return $date;
	}
	
	private function normalize_datetime_to_gregorian( $dt ): ?string {
		$dt = is_string( $dt ) ? trim( $dt ) : '';
		if ( $dt === '' ) {
			return NULL;
		}
		
		// اگر فقط تاریخ بود
		if ( preg_match( '/^(13|14)\d{2}[-\/]\d{1,2}[-\/]\d{1,2}$/', $dt ) ) {
			return $this->normalize_date_to_gregorian( $dt ) . ' 00:00:00';
		}
		
		// اگر شمسی تاریخ+ساعت بود: 1404-12-01 14:30
		if ( preg_match( '/^(13|14)\d{2}[-\/]\d{1,2}[-\/]\d{1,2}\s+\d{1,2}:\d{2}(:\d{2})?$/', $dt ) ) {
			$dt = str_replace( '/', '-', $dt );
			[ $d, $t ] = preg_split( '/\s+/', $dt, 2 );
			$gd = nooshika_jalali_to_gregorian( $d );
			if ( ! $gd ) {
				return NULL;
			}
			$t = preg_match( '/^\d{1,2}:\d{2}:\d{2}$/', $t ) ? $t : ( $t . ':00' );
			
			return $gd . ' ' . $t;
		}
		
		// اگر میلادی datetime بود
		if ( preg_match( '/^\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}(:\d{2})?$/', $dt ) ) {
			return preg_match( '/:\d{2}$/', $dt ) ? $dt : ( $dt . ':00' );
		}
		
		return $dt;
	}
	
	public function on_order_saved( $order, $data_store ): void {
		if ( ! $order instanceof WC_Order ) {
			return;
		}
		
		$order_id = (int) $order->get_id();
		if ( $order_id <= 0 ) {
			return;
		}
		
		$this->sync_order_index( $order );
	}
	
	public function on_status_changed( $order_id, $old_status, $new_status, $order ): void {
		if ( ! $order instanceof WC_Order ) {
			$order = wc_get_order( $order_id );
		}
		
		if ( ! $order ) {
			return;
		}
		
		if ( $new_status === 'cancelled' && class_exists( 'kcp_stock' ) ) {
			$stock  = new kcp_stock();
			$result = $stock->release_order_from_in_production_items( (int) $order_id );
			if ( ! empty( $result['count'] ) ) {
				$order->add_order_note( sprintf(
					'تولید %d آیتم مرتبط با این سفارش لغو شد.',
					(int) $result['count']
				) );
			}
		}
		
		$this->sync_order_index( $order );
	}
	
	public function on_before_delete_order( $order_id ): void {
		$this->delete_order_index( (int) $order_id );
	}
	
	private function sync_order_index( WC_Order $order ): void {
		$table = $this->db_prefix . 'order_index';
		
		$data = [
			'order_id'    => (int) $order->get_id(),
			'user_id'     => (int) $order->get_user_id(),
			'marketer_id' => (int) $order->get_meta( 'marketer_id', TRUE ),
			'order_total' => (int) $order->get_total(),
			'status'      => $order->get_status(),
			'created_at'  => $order->get_date_created()
				? $order->get_date_created()->date( 'Y-m-d H:i:s' )
				: current_time( 'mysql' ),
			'updated_at'  => current_time( 'mysql' ),
		];
		
		$exists = (bool) $this->db->get_var(
			$this->db->prepare(
				"SELECT 1 FROM {$table} WHERE order_id = %d",
				$data['order_id']
			)
		);
		
		if ( $exists ) {
			unset( $data['created_at'] );
			
			$this->db->update(
				$table,
				$data,
				[ 'order_id' => $data['order_id'] ],
				[ '%d', '%d', '%d', '%s', '%s', '%s' ],
				[ '%d' ]
			);
		} else {
			$this->db->insert(
				$table,
				$data,
				[ '%d', '%d', '%d', '%d', '%s', '%s', '%s' ]
			);
		}
	}
	
	private function delete_order_index( int $order_id ): void {
		if ( $order_id <= 0 ) {
			return;
		}
		
		$this->db->delete(
			$this->db_prefix . 'order_index',
			[ 'order_id' => $order_id ],
			[ '%d' ]
		);
	}
	
	public function migrate_order_index( int $page = 1, int $per_page = 50 ): array {
		$args = [
			'limit'      => max( 1, $per_page ),
			'page'       => max( 1, $page ),
			'orderby'    => 'ID',
			'order'      => 'ASC',
			'status'     => array_keys( wc_get_order_statuses() ),
			'meta_query' => [
				[
					'key'     => '_kcp_order_index_migrated',
					'compare' => 'NOT EXISTS',
				],
			],
		];
		
		/** @var WC_Order[] $orders */
		$orders = wc_get_orders( $args );
		
		if ( empty( $orders ) ) {
			return [
				'done'  => TRUE,
				'count' => 0,
				'page'  => $page,
			];
		}
		
		$count = 0;
		
		foreach ( $orders as $order ) {
			if ( ! $order instanceof WC_Order ) {
				continue;
			}
			
			$order_id = (int) $order->get_id();
			if ( $order_id <= 0 ) {
				continue;
			}
			
			$data = [
				'order_id'    => $order_id,
				'user_id'     => (int) $order->get_user_id(),
				'marketer_id' => (int) $order->get_meta( 'marketer_id', TRUE ),
				'order_total' => (int) $order->get_total(),
				'status'      => $order->get_status(),
				'created_at'  => $order->get_date_created()
					? $order->get_date_created()->date( 'Y-m-d H:i:s' )
					: current_time( 'mysql' ),
				'updated_at'  => current_time( 'mysql' ),
			];
			
			$exists = (bool) $this->db->get_var(
				$this->db->prepare(
					"SELECT 1 FROM {$this->db_prefix}order_index WHERE order_id = %d",
					$order_id
				)
			);
			
			if ( $exists ) {
				unset( $data['created_at'] );
				
				$this->db->update(
					$this->db_prefix . 'order_index',
					$data,
					[ 'order_id' => $order_id ],
					[ '%d', '%d', '%d', '%d', '%s', '%s' ],
					[ '%d' ]
				);
			} else {
				$this->db->insert(
					$this->db_prefix . 'order_index',
					$data,
					[ '%d', '%d', '%d', '%d', '%s', '%s', '%s' ]
				);
			}
			
			// فلگ مهاجرت (HPOS-safe)
			$order->update_meta_data( '_kcp_order_index_migrated', 1 );
			$order->update_meta_data( '_kcp_order_index_migrated_at', current_time( 'mysql' ) );
			$order->save();
			
			$count ++;
		}
		
		return [
			'done'  => FALSE,
			'count' => $count,
			'page'  => $page,
		];
	}
	
	public function get_sales_summary_from_index( array $args = [] ): array {
		$args = wp_parse_args( $args, [
			'date_from'   => NULL, // شمسی Y-m-d
			'date_to'     => NULL, // شمسی Y-m-d
			'marketer_id' => 0,
			'status'      => NULL, // string|array|null
			'intro'       => NULL, // ncp_user_intro_method
		] );
		
		$intro = ! empty( $args['intro'] )
			? sanitize_text_field( $args['intro'] )
			: NULL;
		
		$completed_statuses = [
			'factor',
			'confirming',
			'processing',
			'confirmed',
			'stock-delivery',
			'completed',
			'delivered',
		];
		
		$statuses = $args['status']
			? (array) $args['status']
			: $completed_statuses;
		
		$date_from = $args['date_from']
			? nooshika_jalali_to_gregorian( $args['date_from'] )
			: NULL;
		
		$date_to = $args['date_to']
			? nooshika_jalali_to_gregorian( $args['date_to'] )
			: NULL;
		
		/* ===============================
	 * 1) جمع کل سفارش‌ها
		 * =============================== */
		$wheres = [];
		$params = [];
		$joins  = [];
		
		$placeholders = implode( ',', array_fill( 0, count( $statuses ), '%s' ) );
		$wheres[]     = "oi.status IN ($placeholders)";
		$params       = array_merge( $params, $statuses );
		
		if ( $intro ) {
			$joins[]  = "
			INNER JOIN {$this->db->usermeta} um_intro
				ON um_intro.user_id = oi.user_id
				AND um_intro.meta_key = 'ncp_user_intro_method'
		";
			$wheres[] = 'um_intro.meta_value = %s';
			$params[] = $intro;
		}
		
		if ( $args['marketer_id'] > 0 ) {
			$wheres[] = 'oi.marketer_id = %d';
			$params[] = (int) $args['marketer_id'];
		}
		
		if ( $date_from ) {
			$wheres[] = 'oi.created_at >= %s';
			$params[] = $date_from . ' 00:00:00';
		}
		
		if ( $date_to ) {
			$wheres[] = 'oi.created_at <= %s';
			$params[] = $date_to . ' 23:59:59';
		}
		
		$join_sql  = implode( "\n", $joins );
		$where_sql = implode( ' AND ', $wheres );
		
		$orders_total = (int) $this->db->get_var(
			$this->db->prepare(
				"
			SELECT COALESCE(SUM(oi.order_total),0)
			FROM {$this->db_prefix}order_index oi
			{$join_sql}
			WHERE {$where_sql}
			",
				$params
			)
		);
		
		/* ===============================
		 * 2) پرداخت نقدی
		 *    تاریخ: paid_date
		 * =============================== */
		$wheres = [];
		$params = [];
		$joins  = [];
		
		if ( $intro ) {
			$joins[]  = "
			INNER JOIN {$this->db->usermeta} um_intro
				ON um_intro.user_id = oi.user_id
				AND um_intro.meta_key = 'ncp_user_intro_method'
		";
			$wheres[] = 'um_intro.meta_value = %s';
			$params[] = $intro;
		}
		
		if ( $args['marketer_id'] > 0 ) {
			$wheres[] = 'oi.marketer_id = %d';
			$params[] = (int) $args['marketer_id'];
		}
		
		if ( $date_from ) {
			$wheres[] = 'cp.paid_date >= %s';
			$params[] = $date_from;
		}
		
		if ( $date_to ) {
			$wheres[] = 'cp.paid_date <= %s';
			$params[] = $date_to;
		}
		
		$join_sql  = implode( "\n", $joins );
		$where_sql = $wheres ? 'WHERE ' . implode( ' AND ', $wheres ) : '';
		
		$cash_total = (int) $this->db->get_var(
			$this->db->prepare(
				"
			SELECT COALESCE(SUM(cp.amount),0)
			FROM {$this->cash_payments} cp
			INNER JOIN {$this->db_prefix}order_index oi
				ON oi.order_id = cp.order_id
			{$join_sql}
			{$where_sql}
			",
				$params
			)
		);
		
		/* ===============================
		 * 3) چک‌ها
		 *    تاریخ: check_expire
		 * =============================== */
		$wheres = [];
		$params = [];
		$joins  = [];
		
		if ( $intro ) {
			$joins[]  = "
			INNER JOIN {$this->db->usermeta} um_intro
				ON um_intro.user_id = oi.user_id
				AND um_intro.meta_key = 'ncp_user_intro_method'
		";
			$wheres[] = 'um_intro.meta_value = %s';
			$params[] = $intro;
		}
		
		if ( $args['marketer_id'] > 0 ) {
			$wheres[] = 'oi.marketer_id = %d';
			$params[] = (int) $args['marketer_id'];
		}
		
		if ( $date_from ) {
			$wheres[] = 'ch.check_expire >= %s';
			$params[] = $date_from;
		}
		
		if ( $date_to ) {
			$wheres[] = 'ch.check_expire <= %s';
			$params[] = $date_to;
		}
		
		$join_sql  = implode( "\n", $joins );
		$where_sql = $wheres ? 'WHERE ' . implode( ' AND ', $wheres ) : '';
		
		$cheque_total = (int) $this->db->get_var(
			$this->db->prepare(
				"
			SELECT COALESCE(SUM(ch.check_amount),0)
			FROM {$this->order_cheques} ch
			INNER JOIN {$this->db_prefix}order_index oi
				ON oi.order_id = ch.order_id
			{$join_sql}
			{$where_sql}
			",
				$params
			)
		);
		
		/* ===============================
		 * 4) اقساط
		 *    تاریخ: payment_plan_start_date
		 * =============================== */
		$wheres = [];
		$params = [];
		$joins  = [];
		
		if ( $intro ) {
			$joins[]  = "
			INNER JOIN {$this->db->usermeta} um_intro
				ON um_intro.user_id = oi.user_id
				AND um_intro.meta_key = 'ncp_user_intro_method'
		";
			$wheres[] = 'um_intro.meta_value = %s';
			$params[] = $intro;
		}
		
		if ( $args['marketer_id'] > 0 ) {
			$wheres[] = 'oi.marketer_id = %d';
			$params[] = (int) $args['marketer_id'];
		}
		
		if ( $date_from ) {
			$wheres[] = "DATE_ADD(ins.payment_plan_start_date, INTERVAL ins.payment_plan_month MONTH) >= %s";
			$params[] = $date_from;
		}
		
		if ( $date_to ) {
			$wheres[] = 'ins.payment_plan_start_date <= %s';
			$params[] = $date_to;
		}
		
		$join_sql  = implode( "\n", $joins );
		$where_sql = $wheres ? 'WHERE ' . implode( ' AND ', $wheres ) : '';
		
		$final_sql = $this->db->prepare(
			"
		SELECT COALESCE(SUM(
			GREATEST(
				0,
				LEAST(
					ins.payment_plan_month - 1,
					(
						CASE
							WHEN DATE_ADD(ins.payment_plan_start_date, INTERVAL TIMESTAMPDIFF(MONTH, ins.payment_plan_start_date, %s) MONTH) > %s
								THEN TIMESTAMPDIFF(MONTH, ins.payment_plan_start_date, %s) - 1
							ELSE TIMESTAMPDIFF(MONTH, ins.payment_plan_start_date, %s)
						END
					)
				)
				-
				GREATEST(
					0,
					(
						CASE
							WHEN DATE_ADD(ins.payment_plan_start_date, INTERVAL TIMESTAMPDIFF(MONTH, ins.payment_plan_start_date, %s) MONTH) < %s
								THEN TIMESTAMPDIFF(MONTH, ins.payment_plan_start_date, %s) + 1
							ELSE TIMESTAMPDIFF(MONTH, ins.payment_plan_start_date, %s)
						END
					)
				)
				+ 1
			) * ins.payment_plan_amount
		), 0)
		FROM {$this->installments} ins
		INNER JOIN {$this->db_prefix}order_index oi
			ON oi.order_id = ins.order_id
		{$join_sql}
		{$where_sql}
		",
			array_merge(
				[
					$date_to,
					$date_to,
					$date_to,
					$date_to,
					$date_from,
					$date_from,
					$date_from,
					$date_from,
				],
				$params
			)
		);
		
		$installment_total = (int) $this->db->get_var( $final_sql );
		
		return [
			'orders_total'      => $orders_total,
			'cash_total'        => $cash_total,
			'cheque_total'      => $cheque_total,
			'installment_total' => $installment_total,
		];
	}
	
	public function create_export_log( int $creator, string $file_url, string $file_path, array $args ): array {
		$creator  = absint( $creator );
		$file_url = esc_url_raw( $file_url );
		$date     = current_time( 'mysql' );
		$json     = wp_json_encode( $args, JSON_UNESCAPED_UNICODE );
		
		$inserted = $this->db->insert(
			$this->export_log,
			[
				'creator'   => $creator,
				'file_url'  => $file_url,
				'file_path' => $file_path,
				'date'      => $date,
				'args'      => $json,
			],
			[ '%d', '%s', '%s', '%s' ]
		);
		
		if ( ! $inserted ) {
			return [
				'export_id' => 0,
				'row'       => NULL,
			];
		}
		
		$export_id = (int) $this->db->insert_id;
		
		return [
			'export_id' => $export_id,
			'row'       => $this->get_export_log( $export_id ),
		];
	}
	
	/**
	 * بازیابی یک لاگ اکسپورت با شناسه
	 *
	 * @param   int  $export_id
	 *
	 * @return array|null رکورد کامل (با args دیکد شده) یا null اگر یافت نشد
	 */
	public function get_export_log( int $export_id ): ?array {
		$export_id = absint( $export_id );
		
		$row = $this->db->get_row(
			$this->db->prepare(
				"SELECT export_id, creator, file_url, file_path , date, args FROM {$this->export_log} WHERE export_id = %d",
				$export_id
			),
			ARRAY_A
		);
		
		if ( ! $row ) {
			return NULL;
		}
		
		$decoded     = json_decode( (string) $row['args'], TRUE );
		$row['args'] = is_array( $decoded ) ? $decoded : [];
		
		return $row;
	}
	
}
