<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
$per_page_key = basename( __FILE__, '.php' );
$per_page_key = "kph_{$per_page_key}_per_page";
$user_id      = get_current_user_id();
$defaults     = [
	'status'         => 'proforma',
	'supplier_group' => '',
	'page_number'    => 1,
	'per_page'       => get_user_meta( $user_id, $per_page_key, TRUE ) ?: 20,
	'date'           => [
		'from' => '',
		'to'   => '',
	],
];
$args         = wp_parse_args( $_REQUEST, $defaults );
$args         = array_map( fn( $v ) => $v == 0 ? '' : $v, $args );
$has_filter   = kph_page_has_filter( $args, $defaults );
extract( $args );
update_user_meta( $user_id, $per_page_key, $per_page );

$date_from = $date['from'] ?? '';
$date_to   = $date['to'] ?? '';

$DB       = new kph_db();
$statuses = $DB->get_supplier_invoice_statuses();
$invoices = $DB->get_supplier_invoices( [
	'page'           => $page_number,
	'per_page'       => $per_page,
	'status'         => $status,
	'supplier_group' => $supplier_group,
	'date_from'      => $date_from ? nooshika_jalali_to_gregorian( $date_from ) : NULL,
	'date_to'        => $date_to ? nooshika_jalali_to_gregorian( $date_to ) : NULL,
] );

$total_page      = $invoices['pagination']['total_page'];
$total_items     = $invoices['pagination']['total'];
$invoices        = $invoices['items'];
$supplier_groups = $DB->get_raw_categories();
$supplier_groups = $supplier_groups['items'];
?>
<div class="nk-block-head nk-block-head-sm">
    <div class="nk-block-between">
        <div class="nk-block-head-content">
            <h3 class="nk-block-title page-title">لیست فاکتور های تامین کنندگان</h3>
            <div class="nk-block-des text-soft">
                <p class="mb-0">شما در مجموع <?php echo $total_items; ?> فاکتور دارید.</p>
            </div>
        </div>
        <div class="nk-block-head-content">
            <div class="toggle-wrap nk-block-tools-toggle">
                <div class="toggle-expand-content">
                    <ul class="nk-block-tools g-3">
						<?php
						foreach ( $statuses as $slug => $data ) {
							$class = 'btn-' . $data['class'];
							if ( $slug != $status ) {
								$class .= ' btn-dim';
							}
							?>
                            <li>
                                <div data-url="/crm/produce-invoice?status=<?php echo $slug; ?>"
                                     class="page_activator btn <?php echo $class; ?>"><?php echo $data['label']; ?></div>
                            </li>
							<?php
						}
						?>
                        <li class="nk-block-tools-opt">
                            <a href="<?php echo home_url( '/crm/order-supplier/' ); ?>" target="_blank"
                               class=" btn btn-icon btn-primary"><em class="icon ni ni-plus"></em></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="nk-block">
    <div class="card card-stretch">
        <div class="card-inner-group">
            <div class="card-inner position-relative card-tools-toggle">
                <div class="card-title-group">
                    <div class="card-tools">
                    </div>
                    <div class="card-tools">
                        <ul class="btn-toolbar gx-1">
                            <li>
								<?php
								$filter_fields = [
									[
										'type'  => 'date-range',
										'label' => 'تاریخ فاکتور',
										'name'  => 'date',
										'value' => [
											'from' => $date_from ?? '',
											'to'   => $date_to ?? '',
										],
									],
									[
										'type'    => 'select',
										'label'   => 'گروه تامین',
										'name'    => 'supplier_group',
										'value'   => $supplier_group,
										'col'     => 6,
										'options' => [ 0 => 'همه موارد' ] + array_combine(
												array_column( $supplier_groups, 'id' ),
												array_column( $supplier_groups, 'title' )
											),
									],
									[
										'type'  => 'hidden',
										'name'  => 'status',
										'value' => $status,
									],
								];
								echo kph_get_template( 'components/filter-dropdown.php', [
									'has_filter'    => $has_filter,
									'filter_fields' => $filter_fields,
								] );
								?>
                            </li>
                            <li class="btn-toolbar-sep"></li>
                            <li>
								<?php
								echo kph_get_template( 'components/per-page-selector.php', [
									'per_page' => $per_page,
								] );
								?>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="card-inner p-0">
                <div class="nk-tb-list nk-tb-ulist is-compact">
                    <div class="nk-tb-item nk-tb-head">
                        <div class="nk-tb-col"><span class="sub-text">تاریخ ثبت</span></div>
                        <div class="nk-tb-col"><span class="sub-text">تامین کننده</span></div>
                        <div class="nk-tb-col"><span class="sub-text">گروه تامین</span></div>
                        <div class="nk-tb-col"><span class="sub-text">جمع کل</span></div>
                        <div class="nk-tb-col"><span class="sub-text">باقیمانده</span></div>
                        <div class="nk-tb-col text-end nk-tb-col-tools"></div>
                    </div>
					<?php
					if ( empty( $invoices ) ) {
						echo '<div class="no-item-found">فاکتوری یافت نشد</div>';
					} else {
						foreach ( $invoices as $invoice ) {
							$date       = date_i18n( 'j F Y', strtotime( $invoice['issued_at'] ) );
							$amount     = number_format( $invoice['total_amount'] );
							$attachment = $DB->get_invoice_meta( $invoice['id'], 'attachments' );
							$note       = $invoice['note'];
							$states     = $DB->get_supplier_invoice_settlement_remaining( $invoice['id'] );
							$remaining  = number_format( $states['data']['remaining'] );
							$user_id    = $invoice['supplier_user_id'];
							$group      = get_user_meta( $user_id, 'kph_supplier_group', TRUE );
							?>
                            <div class="nk-tb-item">
                                <div class="nk-tb-col">
                                    <span><?php echo $date; ?></span>
                                </div>
                                <div class="nk-tb-col">
									<?php
									echo kph_get_template( 'components/user-card.php', [
										'user_id'    => $user_id,
										'show_phone' => TRUE,
									] );
									?>
                                </div>
                                <div class="nk-tb-col">
                                    <ul class="g-1 profile-ud-value">
										<?php
										if ( $group ) {
											$product_category = $DB->get_raw_category( $group );
											?>
                                            <li class="btn-group">
                                                 <span class="badge bg-info">
                                                     <?php echo isset( $product_category['item'] ) ?
	                                                     $product_category['item']['title'] :
	                                                     '-'; ?></span>
                                            </li>
											<?php
										} else {
											echo '-';
										}
										?>
                                    </ul>
                                </div>
                                <div class="nk-tb-col">
                                    <div class="btn-group align-items-baseline">
                                        <span><?php echo $amount; ?></span>
                                    </div>
                                </div>
                                <div class="nk-tb-col">
                                    <div class="btn-group align-items-baseline">
                                        <span><?php echo $remaining; ?></span>
                                    </div>
                                </div>
                                <div class="nk-tb-col nk-tb-col-tools">
                                    <ul class="nk-tb-actions gx-2">
										<?php
										echo kph_get_template( 'components/row-actions-hidden.php', [
											'actions' => [
												[
													'link'  => '',
													'title' => 'جزئیات فاکتور',
													'class' => 'load_invoice_items_table',
													'icon'  => 'ni-package',
													'data'  => [
														'invoice-id' => $invoice['id'],
													],
												],
												[
													'link'  => '/crm/supplier/' . $user_id,
													'title' => 'مشخصات تامین کننده',
													'icon'  => 'ni-eye',
													'class' => 'page_activator',
												],
												[
													'link'  => '/crm/supplier/' . $user_id . '?tab=financial',
													'title' => 'تاریخچه حسابداری',
													'icon'  => 'ni-coin-alt',
													'class' => 'page_activator',
												],
											],
										] );
										?>
                                        <li>
											<?php
											$actions = [
												'edit'     => [
													'link'   => home_url() . "/crm/order-supplier-edit?invoice_id={$invoice['id']}",
													'icon'   => 'ni-edit',
													'title'  => 'ویرایش فاکتور',
													'target' => '_blank',
												],
												'change'   => [
													'title' => $status == 'proforma' ? 'تایید فاکتور' : 'تسویه فاکتور',
													'icon'  => 'ni-check-round-cut',
													'class' => 'change_invoice_status',
													'data'  => [
														'invoice-id' => $invoice['id'],
														'status'     => $status == 'proforma' ? 'confirmed' : 'settled',
														'user-id'    => $user_id,
													],
												],
												'divider'  => [
													'divider' => TRUE,
												],
												'payment'  => [
													'title' => 'ثبت پرداختی',
													'icon'  => 'ni-cc-alt2',
													'class' => 'populate_modal_inputs',
													'data'  => [
														'modal' => '#addUserPayments',
														'set'   => esc_attr( wp_json_encode(
															[
																'#new_payment_customer_id' => (int) $user_id,
																'#new_payment_invoice_id'  => (int) $invoice['id'],
															]
														) ),
													],
												],
												'transfer' => [
													'title' => 'ثبت حواله',
													'icon'  => 'ni-tranx',
													'class' => 'populate_modal_inputs',
													'data'  => [
														'modal' => '#addUserTransfer',
														'set'   => esc_attr( wp_json_encode(
															[
																'#new_transfer_customer_id' => (int) $user_id,
																'#new_transfer_invoice_id'  => (int) $invoice['id'],
															]
														) ),
													],
												],
												'cheque'   => [
													'title' => 'ثبت چک برای فاکتور',
													'icon'  => 'ni-activity-round',
													'class' => 'populate_modal_inputs',
													'data'  => [
														'modal' => '#referChequeToUser',
														'set'   => esc_attr( wp_json_encode(
															[
																'#refer_cheque_user_id'    => (int) $user_id,
																'#refer_cheque_invoice_id' => (int) $invoice['id'],
															]
														) ),
													],
												],
											];
$delete_action = kph_supplier_invoice_action($invoice, 'produce-invoice');
                                    if ($delete_action) { $actions['delete_supplier_invoice'] = $delete_action; }
                                    											if ($invoice['status'] === 'canceled') { unset($actions['edit'],$actions['change'],$actions['payment'],$actions['transfer'],$actions['cheque'],$actions['divider']); }
                                    if ( $status != 'proforma' ) {
												unset( $actions['edit'] );
											}
											if ( $status == 'settled' ) {
												unset( $actions['change'] );
												unset( $actions['divider'] );
											}
											echo kph_get_template( 'components/row-actions-dropdown.php', [
												'actions' => $actions,
											] );
											?>
                                        </li>
                                    </ul>
                                </div>
                            </div>
							<?php
						}
					}
					?>
                </div>
            </div>
            <div class="card-inner">
				<?php
				echo kph_get_template( 'components/pagination.php', [
					'max_page_num' => $total_page,
					'current_page' => $page_number,
					'class_name'   => 'user_pagination_link',
					'show_count'   => 2,
				] );
				?>
            </div>
        </div>
    </div>
</div>

