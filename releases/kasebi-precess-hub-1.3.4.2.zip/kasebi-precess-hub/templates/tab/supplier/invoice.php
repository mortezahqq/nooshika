<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * @var $user_id
 */
$defaults = [
	'status'      => 'proforma',
	'per_page'    => 10,
	'page_number' => 1,
];
$args = wp_parse_args( array_intersect_key( $_REQUEST, $defaults ), $defaults );
$status = is_string( $args['status'] ) && in_array( $args['status'], [ 'proforma', 'confirmed', 'settled', 'canceled' ], TRUE ) ? $args['status'] : 'proforma';
$per_page = is_scalar( $args['per_page'] ) ? max( 1, min( 200, (int) $args['per_page'] ) ) : 10;
$page_number = is_scalar( $args['page_number'] ) ? max( 1, (int) $args['page_number'] ) : 1;
$DB         = new kph_db();
$statuses   = $DB->get_supplier_invoice_statuses();
$invoices   = $DB->get_supplier_invoices( [
	'page'             => $page_number,
	'per_page'         => $per_page,
	'supplier_user_id' => $user_id,
	'status'           => $status,
] );
$total_page = $invoices['pagination']['total_page'];
$invoices   = $invoices['items'];
?>
<div class="nk-block nk-block-between">
    <div class="nk-block-head">
        <h6 class="title">لیست فاکتورها</h6>
    </div>
    <ul class="nk-block-tools g-3">
        <li class="nk-block-tools-opt">
            <a href="#" class="btn btn-icon btn-primary print_list_items" data-type="invoice"
               data-collect="ids">
                <em class="icon ni ni-printer"></em></a>
        </li>
		<?php
		foreach ( $statuses as $slug => $data ) {
			$class = 'btn-' . $data['class'];
			if ( $slug != $status ) {
				$class .= ' btn-dim';
			}
			?>
            <li>
                <div data-url="/crm/supplier/<?php echo $user_id; ?>?tab=invoice&status=<?php echo $slug; ?>"
                     class="page_activator btn <?php echo $class; ?>"><?php echo $data['label']; ?></div>
            </li>
			<?php
		}
		?>
    </ul>
</div>
<div class="nk-block">
	<?php
	if ( empty( $invoices ) ) {
		echo '<div class="no_massages">فاکتوری برای نمایش وجود ندارد.</div>';
	} else {
		?>
        <div class="card">
            <div class="nk-tb-list nk-tb-ulist is-compact">
                <div class="nk-tb-item nk-tb-head">
                    <div class="nk-tb-col nk-tb-col-check"></div>
                    <div class="nk-tb-col"><span class="sub-text">تاریخ ثبت</span></div>
                    <div class="nk-tb-col"><span class="sub-text">شناسه فاکتور</span></div>
                    <div class="nk-tb-col"><span class="sub-text">جمع کل</span></div>
                    <div class="nk-tb-col"><span class="sub-text">باقیمانده</span></div>
                    <div class="nk-tb-col nk-tb-col-tools text-end"></div>
                </div>
				<?php
				foreach ( $invoices as $invoice ) {
					$date       = date_i18n( 'j F Y', strtotime( $invoice['issued_at'] ) );
					$amount     = number_format( $invoice['total_amount'] );
					$attachment = $DB->get_invoice_meta( $invoice['id'], 'attachments' );
					$note       = $invoice['note'];
					$states     = $DB->get_supplier_invoice_settlement_remaining( $invoice['id'] );
					$remaining  = number_format( $states['data']['remaining'] );
					?>
                    <div class="nk-tb-item">
                        <div class="nk-tb-col nk-tb-col-check">
                            <div class="custom-control custom-control-sm custom-checkbox notext">
                                <input type="checkbox" class="custom-control-input select_item_for_print"
                                       value="<?php echo $invoice['id']; ?>"
                                       id="print_item_<?php echo $invoice['id']; ?>">
                                <label class="custom-control-label"
                                       for="print_item_<?php echo $invoice['id']; ?>"></label>
                            </div>
                        </div>
                        <div class="nk-tb-col">
                            <span><?php echo $date; ?></span>
                        </div>
                        <div class="nk-tb-col">
                            <span><?php echo $invoice['invoice_no']; ?></span>
                        </div>
                        <div class="nk-tb-col">
                            <div class="btn-group align-items-baseline">
                                <span><?php echo $amount; ?></span>
                            </div>
                        </div>
                        <div class="nk-tb-col">
                            <div class="btn-group align-items-baseline">
                                <span><?php echo $remaining; ?></span>
                            </div>
                        </div>
                        <div class="nk-tb-col">
                            <ul class="nk-tb-actions gx-2">
								<?php
								if ( $note ) {
									?>
                                    <li class="nk-tb-action">
                                        <div class="btn btn-sm btn-icon btn-trigger"
                                             data-bs-toggle="popover"
                                             data-bs-trigger="hover"
                                             data-bs-html="true"
                                             title="یادداشت"
                                             data-bs-content="<?php echo wpautop( $note ); ?>"
                                             data-bs-placement="top">
                                            <em class="icon ni ni-note-add-c"></em>
                                        </div>
                                    </li>
									<?php
								}
								$hidden_actions = [
									[
										'link'  => "/crm/supplier/{$user_id}?tab=cheque&invoice_id={$invoice['id']}",
										'title' => 'چک ها',
										'icon'  => 'ni-activity-round',
										'class' => 'page_activator',
									],
									[
										'link'  => "/crm/supplier/{$user_id}?tab=payments&invoice_id={$invoice['id']}",
										'title' => 'پرداخت ها',
										'class' => 'page_activator',
										'icon'  => 'ni-cc-alt2',
									],
									[
										'link'  => "/crm/supplier/{$user_id}?tab=transfers&invoice_id={$invoice['id']}",
										'title' => 'حواله ها',
										'icon'  => 'ni-tranx',
										'class' => 'page_activator',
									],
									[
										'link'  => '',
										'title' => 'جزئیات فاکتور',
										'class' => 'load_invoice_items_table',
										'icon'  => 'ni-package',
										'data'  => [
											'invoice-id' => $invoice['id'],
										],
									],
								];
								echo kph_get_template( 'components/row-actions.php', [
									'actions' => $hidden_actions,
								] );
								if ( $attachment ) {
									$attachment = explode( ',', $attachment );
									?>
                                    <li class="nk-tb-action">
										<?php
										$actions = [];
										foreach ( $attachment as $url ) {
											$file_data = $DB->get_uploaded_file_data( $url );
											if ( ! $file_data ) {
												$file_name = $url;
											} else {
												$file_name = $file_data['original_name'];
											}
											$actions[] = [
												'link'     => $url,
												'title'    => $file_name,
												'icon'     => 'ni-download',
												'target'   => '_blank',
												'download' => TRUE,
											];
										}
										echo kph_get_template( 'components/row-actions-dropdown.php', [
											'actions'   => $actions,
											'main_icon' => 'file-docs',
											'title'     => 'فایل ضمیمه',
										] );
										?>
                                    </li>
									<?php
								}
								?>
                                <li>
									<?php
									$actions = [
										'edit'     => [
											'link'   => home_url() . "/crm/order-supplier-edit?invoice_id={$invoice['id']}",
											'icon'   => 'ni-edit',
											'title'  => 'ویرایش فاکتور',
											'target' => '_blank',
										],
										'change'   => [
											'title' => $status == 'proforma' ? 'تایید فاکتور' : 'تسویه فاکتور',
											'icon'  => 'ni-check-round-cut',
											'class' => 'change_invoice_status',
											'data'  => [
												'invoice-id' => $invoice['id'],
												'status'     => $status == 'proforma' ? 'confirmed' : 'settled',
												'user-id'    => $user_id,
											],
										],
										'divider'  => [
											'divider' => TRUE,
										],
										'payment'  => [
											'title' => 'ثبت پرداختی برای فاکتور',
											'icon'  => 'ni-cc-alt2',
											'class' => 'populate_modal_inputs',
											'data'  => [
												'modal' => '#addUserPayments',
												'set'   => esc_attr( wp_json_encode(
													[
														'#new_payment_customer_id' => (int) $user_id,
														'#new_payment_invoice_id'  => (int) $invoice['id'],
													]
												) ),
											],
										],
										'transfer' => [
											'title' => 'ثبت حواله برای فاکتور',
											'icon'  => 'ni-tranx',
											'class' => 'populate_modal_inputs',
											'data'  => [
												'modal' => '#addUserTransfer',
												'set'   => esc_attr( wp_json_encode(
													[
														'#new_transfer_customer_id' => (int) $user_id,
														'#new_transfer_invoice_id'  => (int) $invoice['id'],
													]
												) ),
											],
										],
										'cheque'   => [
											'title' => 'ثبت چک برای فاکتور',
											'icon'  => 'ni-activity-round',
											'class' => 'populate_modal_inputs',
											'data'  => [
												'modal' => '#referChequeToUser',
												'set'   => esc_attr( wp_json_encode(
													[
														'#refer_cheque_user_id'    => (int) $user_id,
														'#refer_cheque_invoice_id' => (int) $invoice['id'],
													]
												) ),
											],
										],
									];
$delete_action = kph_supplier_invoice_action($invoice, 'supplier');
                                    if ($delete_action) { $actions['delete_supplier_invoice'] = $delete_action; }
                                    									if ($invoice['status'] === 'canceled') { unset($actions['edit'],$actions['change'],$actions['payment'],$actions['transfer'],$actions['cheque'],$actions['divider']); }
                                    if ( $status != 'proforma' ) {
										unset( $actions['edit'] );
									}
									if ( $status == 'settled' ) {
										unset( $actions['change'] );
										unset( $actions['divider'] );
									}
									echo kph_get_template( 'components/row-actions-dropdown.php', [
										'actions' => $actions,
									] );
									?>
                                </li>
                            </ul>
                        </div>
                    </div>
					<?php
				}
				?>
            </div>
        </div>
        <div class="p-1 mt-2">
			<?php
			echo kph_get_template( 'components/pagination.php', [
				'max_page_num' => $total_page,
				'current_page' => $page_number,
				'show_count'   => 2,
				'data'         => [
					'tab'      => 'invoice',
					'status'   => $status,
					'per_page' => $per_page,
					'id'       => (int) $user_id,
				],
			] );
			?>
        </div>
		<?php
	}
	?>
</div>
