<?php
if ( ! defined('ABSPATH') ) { exit; }
require_once __DIR__ . '/../Core/kph_hr.php';

// Resolve navigation for the current account; never grant the support role as a whole.
add_filter('nooshika_kph_pages_list', function($pages) {
    if (kph_hr::allowed() && !current_user_can('manage_options')) {
        foreach (['hr-employees', 'divider-hr'] as $key) {
            if (isset($pages[$key])) {
                $pages[$key]['valid_roles'] = array_unique(array_merge((array)$pages[$key]['valid_roles'], ['supp']));
            }
        }
    }
    return $pages;
}, 100);
add_filter('nooshika_kph_single_page_list', function($pages) {
    if (kph_hr::allowed() && !current_user_can('manage_options') && isset($pages['employee'])) {
        $pages['employee']['parent'] = 'hr-employees';
    }
    return $pages;
}, 100);

function kph_hr_fields( string $kind ): array {
    $common=['title'=>['عنوان','text'],'date_from'=>['از تاریخ','date'],'date_to'=>['تا تاریخ','date'],'notes'=>['یادداشت پرونده','textarea']];
    $extra=[
        'contract'=>['job_title'=>['سمت','text'],'basis'=>['روش حقوق','select',['monthly'=>'ماهانه','daily'=>'روزانه','hourly'=>'ساعتی']],'rate'=>['حقوق پایه / نرخ (ریال)','number'],'normal_days'=>['روزهای مبنا در ماه','number'],'overtime_rate'=>['نرخ هر ساعت اضافه‌کاری (ریال)','number'],'terms'=>['شرایط قرارداد','textarea']],
        'leave'=>['leave_type'=>['نوع مرخصی','select',['paid'=>'استحقاقی با حقوق','unpaid'=>'بدون حقوق','sick'=>'استعلاجی']],'leave_year'=>['سال سهمیه مانند ۱۴۰۵','text'],'minutes'=>['مدت مرخصی (دقیقه)','number'],'reason'=>['علت مرخصی','textarea']],
        'attendance'=>['worked_minutes'=>['کارکرد عادی (دقیقه)','number'],'overtime_minutes'=>['اضافه‌کاری (دقیقه)','number'],'late_minutes'=>['تأخیر (دقیقه)','number']],
        'payslip'=>['period'=>['دوره فیش مانند ۱۴۰۵/۰۷','text'],'contract_id'=>['قرارداد تأییدشده','contract'],'paid_days'=>['روزهای پرداخت حقوق','number'],'benefits'=>['مزایا (ریال)','number'],'bonus'=>['پاداش (ریال)','number'],'insurance'=>['بیمه سهم پرسنل (ریال)','number'],'tax'=>['مالیات (ریال)','number'],'deductions'=>['سایر کسورات (ریال)','number']],
        'settlement'=>['severance'=>['سنوات جدید (ریال)','number'],'annual_bonus'=>['عیدی جدید (ریال)','number'],'leave_cash'=>['بازخرید مرخصی (ریال)','number'],'other_due'=>['سایر مطالبات جدید (ریال)','number'],'deductions'=>['کسورات این تسویه (ریال)','number']],
        'payment'=>['amount'=>['مبلغ (ریال)','number'],'payment_method'=>['روش پرداخت','select',['cash'=>'نقدی','pos'=>'کارت‌خوان','card_to_card'=>'کارت به کارت','online'=>'آنلاین','other'=>'سایر']]],
        'transfer'=>['amount'=>['مبلغ (ریال)','number'],'bank_name'=>['نام بانک','text'],'tracking_no'=>['شماره پیگیری','text']],
        'cheque'=>['amount'=>['مبلغ (ریال)','number'],'bank_name'=>['بانک صادرکننده','text'],'cheque_no'=>['شماره چک','text'],'sayad_id'=>['شناسه صیادی','text'],'due_date'=>['تاریخ سررسید','date']],
    ][$kind]??[];
    if(in_array($kind,['payment','transfer','cheque'],TRUE)){
        $extra+=['account_id'=>['حساب پرداخت مجموعه','account'],'purpose'=>['بابت','select',['salary'=>'حقوق','advance'=>'مساعده','settlement'=>'تسویه','other'=>'سایر']],'related_id'=>['شماره فیش یا تسویه مرتبط (اختیاری)','number']];
    }
    return $common+$extra;
}
function kph_hr_form_field(string $name,array $def,$value=''):void{
    [$label,$type]=$def;$id='kph_hr_'.$name;
    echo '<div class="col-md-6 mb-3"><label class="form-label" for="'.esc_attr($id).'">'.esc_html($label).'</label>';
    if($type==='textarea'){echo '<textarea class="form-control" id="'.esc_attr($id).'" name="'.esc_attr($name).'" rows="3">'.esc_textarea($value).'</textarea>';}
    elseif($type==='select'){
        echo '<select class="form-select" id="'.esc_attr($id).'" name="'.esc_attr($name).'">';
        foreach($def[2] as $key=>$text){echo '<option value="'.esc_attr($key).'"'.selected((string)$value,(string)$key,FALSE).'>'.esc_html($text).'</option>';}
        echo '</select>';
    }else{
        $date=$type==='date';
        if($date&&$value){$value=date_i18n('Y/m/d',strtotime($value));}
        echo '<input class="form-control'.($date?' datepicker':'').'" id="'.esc_attr($id).'" name="'.esc_attr($name).'" type="'.($type==='number'?'number':'text').'" value="'.esc_attr($value).'"'.($type==='number'?' min="0" step="0.0001"':'').'>';
    }
    echo '</div>';
}
function kph_hr_audit_changes(array $before,array $after):array{
    foreach(['before','after'] as $key){
        $v=$$key;$data=is_array($v['data']??NULL)?$v['data']:(json_decode($v['data']??'{}',TRUE)?:[]);
        $$key=array_merge($v,$data);
    }
    $defs=['employee_no'=>['کد پرسنلی','text'],'status'=>['وضعیت','select',kph_hr::statuses()+['active'=>'فعال','inactive'=>'پایان همکاری']], 'amount'=>['خالص مبلغ','number'], 'file_id'=>['شماره پیوست','number']];
    foreach(array_keys(kph_hr::kinds()) as $kind){$defs+=kph_hr_fields($kind);}
    foreach(['department'=>'واحد','insurance_no'=>'شماره بیمه','iban'=>'شبا','emergency_name'=>'تماس اضطراری','emergency_phone'=>'تلفن اضطراری','address'=>'نشانی','national_id'=>'کد ملی','phone'=>'تلفن','email'=>'ایمیل','join_date'=>'شروع همکاری','exit_date'=>'پایان همکاری','leave_allowance_minutes'=>'سهمیه مرخصی','base_amount'=>'حقوق پایه محاسبه‌شده','overtime_amount'=>'اضافه‌کاری محاسبه‌شده','gross'=>'حقوق ناخالص','change_reason'=>'علت تغییر'] as $key=>$label){$defs[$key]=[$label,'text'];}
    $out=[];
    foreach($defs as $key=>$def){$a=$before[$key]??'';$b=$after[$key]??'';if(is_scalar($a)&&is_scalar($b)&&(string)$a!==(string)$b){
        if($def[1]==='select'){$a=$def[2][$a]??$a;$b=$def[2][$b]??$b;}
        $out[]=['label'=>$def[0],'before'=>$a,'after'=>$b];
    }} return $out;
}
function kph_hr_url(int $employee,string $tab,array $params=[]):string{
    return add_query_arg(array_merge(['tab'=>'hr','hr_section'=>$tab],$params),home_url('/crm/employee/'.$employee));
}
function kph_hr_print_url(int $employee,int $record):string{
    return add_query_arg(['action'=>'print','type'=>'hr-record','user_id'=>$employee,'record_id'=>$record,'_wpnonce'=>wp_create_nonce('kph_hr_print_'.$record)],home_url('/crm/'));
}
function kph_hr_financial_protected(string $kind,int $id):bool{
    global $wpdb;
    if(get_option('kph_hr_schema')!=='1'){return FALSE;}
    return (bool)$wpdb->get_var($wpdb->prepare("SELECT id FROM {$wpdb->prefix}kph_hr_records WHERE kind=%s AND financial_ref=%d AND status='posted' LIMIT 1",$kind,$id));
}
function kph_hr_personnel_protected(int $id):bool{
    global $wpdb;
    if(get_option('kph_hr_schema')!=='1'){return FALSE;}
    return (bool)$wpdb->get_var($wpdb->prepare("SELECT id FROM {$wpdb->prefix}kph_hr_records WHERE employee_id=%d LIMIT 1",$id));
}
add_action('delete_user',function($id){
    if(kph_hr_personnel_protected((int)$id)){wp_die('پرسنل دارای سابقه کارگزینی حذف نمی‌شود؛ پایان همکاری را در پرونده ثبت کنید.','',['response'=>409]);}
});
add_action('init',function(){
    add_role('kph_employee','پرسنل بدون دسترسی پنل',['read'=>TRUE]);
    if(current_user_can('manage_options') && get_option('kph_hr_schema')!=='1'){
        try{(new kph_hr())->install();update_option('kph_hr_schema','1',FALSE);}catch(Throwable $e){ /* The HR page reports missing storage explicitly. */ }
    }
},30);
add_action('wp_print_scripts',function(){
    if(wp_script_is('kasebi_clinic_script','enqueued')&&kph_hr::allowed()){
        wp_enqueue_script('kph-hr',KPH_ASSETS_URL.'js/hr.js',['kasebi_clinic_script'],KPH_VER,TRUE);
    }
},20);
$kph_hr_action_handler=function(){
    if(!kph_hr::allowed()||!wp_verify_nonce($_POST['nonce']??'','kph_hr')){wp_send_json(['status'=>'error','message'=>'اجازه دسترسی یا اعتبار فرم کافی نیست.'],403);}
    try{
        $hr=new kph_hr();$input=wp_unslash($_POST);$op=sanitize_key($input['operation']??'');$employee=absint($input['employee_id']??0);$record=absint($input['record_id']??0);
        if($op==='access'){
            $enabled=$input['access_enabled']??'';
            if(!is_string($enabled)||!in_array($enabled,['0','1'],TRUE)){throw new RuntimeException('وضعیت دسترسی معتبر نیست.');}
            kph_hr::set_support_access(absint($input['support_user_id']??0),$enabled==='1');
        }
        elseif($op==='prepare'){$hr->prepare_finance();}
        elseif($op==='profile'){$hr->save_profile($employee,$input);}
        elseif($op==='save'){$record=$hr->save($employee,sanitize_key($input['kind']??''),$input,$record,absint($input['version']??0));}
        elseif($op==='attach'){$hr->attach($employee,$record,$_FILES['file']??[]);}
        elseif(in_array($op,['approve','cancel','reject','clear','bounce'],TRUE)){$hr->transition($employee,$record,absint($input['version']??0),$op,$input['reason']??'');}
        elseif($op==='create_employee'){
            $name=sanitize_text_field($input['name']??'');$phone=sanitize_text_field(nooshika_sanitize_numbers($input['phone']??''));
            if(!$name){throw new RuntimeException('نام پرسنل الزامی است.');}
            $id=wp_insert_user(['user_login'=>'hr_'.strtolower(wp_generate_password(16,FALSE,FALSE)),'user_pass'=>wp_generate_password(32,TRUE,TRUE),'display_name'=>$name,'first_name'=>$name,'user_email'=>sanitize_email($input['email']??''),'role'=>'kph_employee']);
            if(is_wp_error($id)){throw new RuntimeException('ایجاد پرسنل انجام نشد: '.$id->get_error_message());}
            update_user_meta($id,'nooshika_phone_num',$phone);
            try{$hr->save_profile((int)$id,['version'=>0,'employee_no'=>$input['employee_no']??'P-'.$id,'phone'=>$phone,'email'=>$input['email']??'','status'=>'active']);}
            catch(Throwable $e){require_once ABSPATH.'wp-admin/includes/user.php';wp_delete_user($id);throw $e;}
            wp_send_json(['status'=>'success','message'=>'پرسنل ایجاد شد.','url'=>kph_hr_url((int)$id,'hr_file')]);
        }else{throw new RuntimeException('عملیات معتبر نیست.');}
        wp_send_json(['status'=>'success','message'=>'اطلاعات با موفقیت ثبت شد.','record_id'=>$record]);
    }catch(Throwable $e){wp_send_json(['status'=>'error','message'=>$e instanceof RuntimeException?$e->getMessage():'ثبت اطلاعات ناموفق بود؛ صفحه را تازه کنید.']);}
};
add_action('wp_ajax_kph_hr_action',$kph_hr_action_handler);
add_action('nooshika_ajax_kph_hr_action',$kph_hr_action_handler);
unset($kph_hr_action_handler);
add_action('admin_post_kph_hr_file',function(){
    $id=absint($_GET['file_id']??0);
    if(!kph_hr::allowed()||!wp_verify_nonce($_GET['_wpnonce']??'','kph_hr_file_'.$id)){wp_die('دسترسی به فایل مجاز نیست.','',['response'=>403]);}
    try{$file=(new kph_hr())->file($id);}catch(Throwable $e){wp_die('فایل یافت نشد.','',['response'=>404]);}
    nocache_headers();header('Content-Type: '.$file['mime']);header('X-Content-Type-Options: nosniff');
    header('Content-Disposition: attachment; filename="hr-file-'.$id.'"; filename*=UTF-8\'\''.rawurlencode($file['filename']));
    header('Content-Length: '.strlen($file['contents']));echo $file['contents'];exit;
});
