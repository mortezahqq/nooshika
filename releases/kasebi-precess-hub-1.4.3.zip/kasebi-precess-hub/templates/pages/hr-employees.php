<?php
if(!defined('ABSPATH')){exit;}
if(!kph_hr::allowed()){echo '<p>دسترسی به منابع انسانی مجاز نیست.</p>';return;}
$hr=new kph_hr();$search=sanitize_text_field(wp_unslash($_REQUEST['hr_search']??''));$state=sanitize_key($_REQUEST['hr_employment']??'');$page=max(1,absint($_REQUEST['hr_page']??1));
$ids=get_users(['fields'=>'ids','orderby'=>'ID','order'=>'DESC','role__in'=>kph_hr::roles()]);
$staff=[];
foreach($ids as $id){$p=$hr->profile((int)$id);$name=get_user_name_by_id($id);$d=$p['data'];
    if($state!==''&&$p['status']!==$state){continue;}
    if($search!==''&&mb_stripos($name.' '.$p['employee_no'].' '.($d['department']??'').' '.($d['job_title']??''),$search)===FALSE){continue;}
    $staff[]=['id'=>$id,'name'=>$name,'profile'=>$p];
}
$total=count($staff);$pages=max(1,(int)ceil($total/20));$staff=array_slice($staff,($page-1)*20,20);$dash=$hr->dashboard();
?>
<div class="kph-hr" data-nonce="<?php echo esc_attr(wp_create_nonce('kph_hr'));?>">
<div class="kph-hr-message" role="status" aria-live="polite"></div>
<h3>منابع انسانی و کارگزینی</h3>
<?php if(current_user_can('manage_options')){ $support_users=get_users(['role'=>'supp','orderby'=>'display_name','order'=>'ASC']); ?>
<details class="mb-4"><summary class="btn btn-outline-primary">دسترسی پشتیبان به منابع انسانی</summary>
<form class="kph-hr-form mt-3" method="post"><input type="hidden" name="operation" value="access">
<label class="form-label" for="kph_hr_support_user">کاربر پشتیبان</label>
<select class="form-select mb-3" name="support_user_id" id="kph_hr_support_user" required><option value="">انتخاب کنید</option>
<?php foreach($support_users as $support){ ?><option value="<?php echo (int)$support->ID;?>"><?php echo esc_html($support->display_name.' (#'.$support->ID.') — '.(!empty($support->caps[kph_hr::CAPABILITY])?'دسترسی فعال':'بدون دسترسی'));?></option><?php } ?></select>
<label class="form-label" for="kph_hr_access_enabled">دسترسی منابع انسانی</label>
<select class="form-select mb-3" name="access_enabled" id="kph_hr_access_enabled"><option value="1">فعال: مدیریت کامل کارگزینی</option><option value="0">لغو دسترسی</option></select>
<p>شامل پرونده‌ها، قراردادها، مرخصی، کارکرد، حقوق، پرداخت‌ها و مدارک پرسنل است. این دسترسی فقط برای حساب انتخاب‌شده ثبت می‌شود.</p>
<button class="btn btn-primary" type="submit">ذخیره دسترسی</button></form></details>
<?php } ?>
<div class="row mb-4"><div class="col-md-4"><div class="card card-bordered p-3">تعداد پرسنل در این فهرست: <strong><?php echo number_format($total);?></strong></div></div><div class="col-md-8"><div class="card card-bordered p-3">در انتظار تأیید: <?php foreach($dash['pending'] as $r){echo esc_html((kph_hr::kinds()[$r['kind']]??$r['kind']).' : '.$r['total'].' | ');}if(!$dash['pending']){echo 'موردی وجود ندارد.';}?></div></div></div>
<?php if($dash['contracts']){?><details class="alert alert-warning"><summary>قراردادهای منقضی‌شده یا با پایان در ۳۰ روز آینده</summary><ul><?php foreach($dash['contracts'] as $r){?><li><a class="page_activator" href="<?php echo esc_url(kph_hr_url((int)$r['employee_id'],'hr_contracts'));?>"><?php echo esc_html(get_user_name_by_id($r['employee_id']).' — '.date_i18n('Y/m/d',strtotime($r['date_to'])));?></a></li><?php }?></ul></details><?php }?>
<details class="mb-4"><summary class="btn btn-primary">افزودن پرسنل</summary><form class="kph-hr-form mt-3" method="post"><input type="hidden" name="operation" value="create_employee"><div class="row"><?php foreach(['name'=>['نام و نام خانوادگی','text'],'employee_no'=>['کد پرسنلی یکتا','text'],'phone'=>['موبایل','text'],'email'=>['ایمیل (اختیاری)','text']] as $key=>$def){kph_hr_form_field($key,$def);}?></div><p>پرسنل جدید به‌صورت پرونده بدون دسترسی مدیریتی پنل ایجاد می‌شود. حساب کاربران فعلی تغییر نمی‌کند.</p><button class="btn btn-primary" type="submit">ایجاد پرونده</button></form></details>
<form method="get" class="row mb-4"><div class="col-md-6"><label>نام، کد پرسنلی، واحد یا سمت</label><input class="form-control" name="hr_search" value="<?php echo esc_attr($search);?>"></div><div class="col-md-4"><label>وضعیت همکاری</label><select class="form-select" name="hr_employment"><option value="">همه</option><option value="active" <?php selected($state,'active');?>>فعال</option><option value="inactive" <?php selected($state,'inactive');?>>پایان همکاری</option></select></div><div class="col-md-2 align-self-end"><button class="btn btn-light" type="submit">جستجو</button></div></form>
<div class="table-responsive"><table class="table table-bordered"><thead><tr><th>کد پرسنلی</th><th>نام</th><th>واحد / سمت</th><th>وضعیت</th><th>پرونده</th></tr></thead><tbody><?php foreach($staff as $s){$p=$s['profile'];?><tr><td><?php echo esc_html($p['employee_no']);?></td><td><?php echo esc_html($s['name']);?></td><td><?php echo esc_html(($p['data']['department']??'').' / '.($p['data']['job_title']??''));?></td><td><?php echo $p['status']==='active'?'فعال':'پایان همکاری';?></td><td><a class="btn btn-sm btn-primary page_activator" href="<?php echo esc_url(kph_hr_url((int)$s['id'],'hr_file'));?>">کارگزینی</a><a class="btn btn-sm btn-light page_activator" href="<?php echo esc_url(current_user_can('manage_options')?add_query_arg('tab','financial',home_url('/crm/employee/'.$s['id'])):kph_hr_url((int)$s['id'],'payments'));?>">حسابداری</a></td></tr><?php }if(!$staff){?><tr><td colspan="5">پرسنلی یافت نشد.</td></tr><?php }?></tbody></table></div>
<?php if($pages>1){?><nav aria-label="صفحه‌بندی پرسنل"><?php for($i=1;$i<=$pages;$i++){if($i!==1&&$i!==$pages&&abs($i-$page)>2){continue;}?><a class="btn <?php echo $i===$page?'btn-primary':'btn-light';?> page_activator" href="<?php echo esc_url(add_query_arg(['hr_page'=>$i,'hr_search'=>$search,'hr_employment'=>$state],home_url('/crm/hr-employees')));?>"><?php echo $i;?></a><?php }?></nav><?php }?></div>
