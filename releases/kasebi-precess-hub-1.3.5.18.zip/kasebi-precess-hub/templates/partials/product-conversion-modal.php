<?php if(!defined('ABSPATH'))exit; ?>
<div class="modal fade" id="convertLotToProduct">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">تبدیل به محصول</h5>
                <a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
            </div>
            <div class="modal-body modal-body-md">
                <form action="#" class="modal_form" data-action="<?php echo !empty($bulk_conversion) ? 'kph_convert_bulk_pack_to_shop_product' : 'kph_convert_packaging_lot_to_shop_product'; ?>"
                      data-page="<?php echo !empty($bulk_conversion) ? '/crm/produce-bulk' : '/crm/produce-saloon'; ?>">
                    <div class="row g-gs">
                        <div class="col-12">
                            <label class="form-label" for="production_code_search">انتخاب محصول / کد تولید</label>
                            <input type="search" class="form-control" id="production_code_search" placeholder="نام محصول یا کد تولید را جستجو کنید" autocomplete="off">
                            <select class="form-select mt-2" id="production_code_id" data-for="production_code_id" data-req="1" aria-label="محصول و کد تولید">
                                <option value="">نام محصول یا کد را جستجو و یک مورد را انتخاب کنید</option>
                            </select>
                            <button type="button" class="btn btn-outline-secondary mt-2" id="production_code_more" style="display:none">نمایش کدهای بیشتر</button>
                            <div id="production_code_selected" class="text-primary mt-2" aria-live="polite"></div>
                            <input type="hidden" data-for="production_nonce" id="production_nonce" value="<?php echo esc_attr( wp_create_nonce( 'kph_production_codes' ) ); ?>">
                        </div>
                        <?php if ( kph_plugin_management_allowed() ) { ?>
                        <div class="col-12">
                            <details>
                                <summary>تعریف کد تولید جدید</summary>
                                <label class="form-label mt-2" for="new_production_product">محصول کد جدید</label>
                                <select class="form-select" id="new_production_product">
                                    <option value="">محصول را انتخاب کنید</option>
                                    <?php foreach ( $products as $product ) { ?>
                                    <option value="<?php echo esc_attr( $product['id'] ); ?>"><?php echo esc_html( $product['title'] ); ?></option>
                                    <?php } ?>
                                </select>
                                <label class="form-label mt-2" for="new_production_code">کد جدید</label>
                                <input type="text" class="form-control" id="new_production_code" maxlength="64" autocomplete="off">
                                <label class="mt-2"><input type="checkbox" id="new_production_confirm"> ارتباط کد جدید با محصول انتخاب‌شده را تأیید می‌کنم.</label>
                                <button type="button" class="btn btn-outline-primary mt-2" id="register_production_code">تعریف کد جدید</button>
                            </details>
                        </div>
                        <?php } ?>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label class="form-label" for="product_conversion_total_weight">وزن کل(به گرم وارد
                                    شود)</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control validate_weight"
                                           id="product_conversion_total_weight"
                                           data-target="#max_conversion_weight"
                                           data-for="total_weight">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label class="form-label" for="weight_per_item">وزن هر آیتم(به گرم وارد شود)</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control"
                                           id="weight_per_item"
                                           data-for="weight_per_item">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="packaging_cost_per_item">هزینه بسته بندی هر
                                    مورد</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control price_input" id="packaging_cost_per_item"
                                           data-for="packaging_cost_per_item" data-req="1">
                                </div>
                            </div>
                        </div>
                        <input type="hidden" id="max_conversion_weight">
                        <input type="hidden" data-for="<?php echo !empty($bulk_conversion) ? 'pack_id' : 'lot_id'; ?>" id="new_conversion_lot_id">
                        <input type="hidden" data-for="category_id" id="new_conversion_category_id">
                        <div class="col-12">
                            <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                <li>
                                    <div class="btn btn-primary submit_modal_form">ثبت</div>
                                </li>
                                <li>
                                    <a href="#" class="link link-light" data-bs-dismiss="modal">لغو</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
