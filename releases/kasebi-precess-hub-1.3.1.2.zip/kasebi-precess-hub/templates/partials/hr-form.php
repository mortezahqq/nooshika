<?php
if(!defined('ABSPATH')||!kph_hr::allowed()){return;}
$values=array_merge(['child_count'=>$profile['data']['child_count']??0],$hr->person_form_defaults($employee),(array)get_option('kph_hr_company',[]),$formValues,$formValues['person']??[],$formValues['employer']??[]);
$contractOptions=[];$contractPage=1;
do{$contractList=$hr->listing($employee,'contract',$contractPage,'approved');foreach($contractList['items'] as $c){$contractOptions[(int)$c['id']]=$c;}$contractPage++;}while($contractPage<=$contractList['pages']);
if(!$editing){
    if($kind==='contract'){$values=array_merge(kph_hr::contract_defaults(),$values);$values['contract_date']=substr(current_time('mysql'),0,10);}
    if($kind==='settlement'){$values+=['template'=>'final','settlement_effect'=>'document_only','declaration_text'=>kph_hr::settlement_declaration(),'receipt_date'=>substr(current_time('mysql'),0,10)];}
}
if($kind==='payslip'){
    $period=nooshika_sanitize_numbers($values['period']??'');if(!preg_match('/^(\d{4})[\/-](\d{1,2})$/D',$period,$m)){preg_match('/^(\d{4})\/(\d{2})/',nooshika_sanitize_numbers(kph_hr_exports::date(substr(current_time('mysql'),0,10))),$m);}
    $values['salary_year']=$m[1];$values['salary_month']=str_pad($m[2],2,'0',STR_PAD_LEFT);
    $monthInfo=$hr->salary_period($values);$values['calculation_mode']=$values['calculation_mode']??($editing?'contract':'manual');$values['work_source']=$values['work_source']??($editing?'attendance':'manual');
    $values['monthly_base']=$values['monthly_base']??$values['contract_snapshot']['rate']??0;$values['normal_days']=$values['normal_days']??$values['contract_snapshot']['normal_days']??30;
    $values['paid_days']=$values['paid_days']??$monthInfo['days'];$values['overtime_hours']=$values['overtime_hours']??(($values['work_snapshot']['overtime_minutes']??0)/60);$values['overtime_rate']=$values['overtime_rate']??$values['contract_snapshot']['overtime_rate']??0;
}
?>
<form class="kph-hr-form kph-hr-advanced mt-3" data-kind="<?php echo esc_attr($kind); ?>" data-declarations="<?php $decls=[];foreach(kph_hr::settlement_templates() as $key=>$label){$decls[$key]=kph_hr::settlement_declaration($key);}echo esc_attr(wp_json_encode($decls)); ?>" method="post">
<input type="hidden" name="operation" value="save"><input type="hidden" name="form_version" value="2"><input type="hidden" name="employee_id" value="<?php echo (int)$employee; ?>"><input type="hidden" name="kind" value="<?php echo esc_attr($kind); ?>"><input type="hidden" name="record_id" value="<?php echo (int)($editing['id']??0); ?>"><input type="hidden" name="version" value="<?php echo (int)($editing['version']??0); ?>">
<div class="row g-gs">
<?php foreach(kph_hr_fields($kind) as $key=>$def){
    if($def[1]==='contract'){ ?>
        <div class="col-md-6 kph-hr-contract-field"><div class="form-group"><label class="form-label">قرارداد تأییدشده</label><div class="form-control-wrap"><select class="form-select kph-hr-contract-picker" name="contract_id"><option value="0">انتخاب کنید</option><?php foreach($contractOptions as $id=>$contract){$data=$contract['data'];$summary=array_intersect_key($data,array_flip(['rate','basis','normal_days','overtime_rate','housing','food_allowance','marriage_allowance','child_allowance','seniority_base','employer'])); ?><option value="<?php echo (int)$id; ?>" data-contract="<?php echo esc_attr(wp_json_encode($summary)); ?>" <?php selected($values['contract_id']??0,$id); ?>><?php echo esc_html('#'.$id.' — '.$data['title'].' — '.kph_hr_exports::date($contract['date_from']).' تا '.kph_hr_exports::date($contract['date_to'])); ?></option><?php } ?></select></div></div></div>
    <?php }else{$value=$values[$key]??($def[1]==='number'&&!in_array($key,['receipt_amount'],TRUE)?0:'');kph_hr_form_field($key,$def,$value);} ?>
<?php } ?></div>
<?php if($kind==='payslip'){ ?><div class="alert alert-info kph-hr-period-hint">بازهٔ فیش: <?php echo esc_html(kph_hr_exports::date($monthInfo['from']).' تا '.kph_hr_exports::date($monthInfo['to'])); ?>؛ <?php echo (int)$monthInfo['days']; ?> روز تقویمی.</div>
<p class="kph-hr-pay-preview" aria-live="polite"><?php foreach(['base'=>'حقوق پایه','gross'=>'جمع حقوق و مزایا','deductions'=>'جمع کسورات و مساعده','payable'=>'مبلغ قابل پرداخت'] as $key=>$label){ ?><span class="d-inline-block me-3 mb-2"><?php echo esc_html($label); ?>: <strong data-pay-total="<?php echo esc_attr($key); ?>">—</strong> ریال</span><?php } ?></p><p class="text-soft">مبلغ نهایی پس از ذخیره در سرور محاسبه می‌شود. در حالت کارکرد تأییدشده، ساعات عادی و اضافه‌کاری از سوابق همان ماه خوانده می‌شود. بیمه و مالیات، مبلغ تأییدشدهٔ همین ماه هستند. مساعدهٔ پرداخت‌شده را در سایر کسورات دوباره وارد نکنید.</p><?php } ?>
<button class="btn btn-primary" type="submit">ذخیره پیش‌نویس<?php echo $kind==='payslip'?' و محاسبه فیش':''; ?></button>
<?php if($editing){ ?><a class="btn btn-light page_activator" href="<?php echo esc_url(kph_hr_url($employee,$active)); ?>">انصراف از ویرایش</a><?php } ?>
</form>
