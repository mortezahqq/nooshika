<?php
if(!defined('ABSPATH'))exit;

trait kph_finance_integrity {
    public static function finance_balance_allowed(): bool {
        return get_current_user_id() && (current_user_can('manage_options')||in_array(nooshika_get_user_role(get_current_user_id()),['administrator','accountant'],true));
    }
    private function finance_tables_ready(array $tables): void {
        foreach(array_unique($tables) as $table){
            $row=$this->db->get_row($this->db->prepare('SHOW TABLE STATUS LIKE %s',$this->db->esc_like($table)),ARRAY_A);
            if(!$row||strcasecmp((string)$row['Engine'],'InnoDB'))throw new RuntimeException('برای ثبت یکپارچه، جدول‌های مالی باید InnoDB باشند.');
        }
    }
    /** A transfer deposited to an account, including its party ledger, is one operation. */
    public function add_transfer_to_account(array $transfer,int $account_id,array $meta=[]): array {
        if($account_id<=0)return $this->fail('حساب مقصد را انتخاب کنید.');
        if(!is_numeric($transfer['amount']??null)||!is_finite((float)$transfer['amount'])||(float)$transfer['amount']>=0)return $this->fail('واریز به حساب فقط برای حواله دریافتی مجاز است.');
        try{
            $this->finance_tables_ready([$this->transfers,$this->db_prefix.'transfer_meta',$this->ledger_entries,$this->db_prefix.'ledger_entry_meta',$this->accounts,$this->account_transactions,$this->db_prefix.'account_transaction_meta']);
            if(false===$this->db->query('START TRANSACTION'))throw new RuntimeException('شروع ثبت یکپارچه حواله ناموفق بود.');
            $result=$this->add_transfer($transfer,true);
            if(($result['status']??'')!=='success'){$this->db->query('ROLLBACK');return $result;}
            $id=(int)$result['data']['id'];
            $account=$this->db->get_row($this->db->prepare("SELECT id,type,status FROM {$this->accounts} WHERE id=%d FOR UPDATE",$account_id),ARRAY_A);
            if(!$account||$this->db->last_error||$account['status']!=='active')throw new RuntimeException('حساب مقصد فعال پیدا نشد.');
            $journal=$this->add_account_transaction(['account_id'=>$account_id,'amount'=>abs((float)$transfer['amount']),
                'type'=>$account['type']==='expense'?'debit':'credit','action'=>'transfer_deposit','description'=>'واریز حواله #'.$id,
                'created_by'=>get_current_user_id(),'created_at'=>current_time('mysql'),'meta'=>array_merge($meta,['transfer_id'=>$id])],true);
            if(($journal['status']??'')!=='success'){$this->db->query('ROLLBACK');return $journal;}
            if(false===$this->db->query('COMMIT'))throw new RuntimeException('ثبت نهایی حواله و حساب انجام نشد.');
            $hook=$result['data']['_hook_data']??$transfer;unset($result['data']['_hook_data']);
            // The committed financial result must not become a failure if a notification hook fails.
            try{do_action('kph_transfer_added',$id,$hook,['status'=>'success','data'=>['id'=>$result['data']['ledger_id']??0]]);}catch(Throwable $notification_error){}
            return $result;
        }catch(Throwable $e){$this->db->query('ROLLBACK');return $this->fail($e->getMessage());}
    }
    private function account_balance_review_rows(array $account,array $rows): array {
        $balance='0';$valid=true;$initial=null;$risk=0;
        foreach($rows as $index=>$row){
            if(!in_array($row['type'],['credit','debit'],true)||!preg_match('/^[0-9]+$/D',(string)$row['amount'])||bccomp((string)$row['amount'],'0',0)<=0){$valid=false;continue;}
            $delta=($row['type']==='credit'?'':'-').$row['amount'];
            if($index===0)$initial=bcsub((string)$row['balance_after'],$delta,0);
            $balance=bcadd($balance,$delta,0);
            if($account['type']==='expense'&&$row['action']==='transfer_deposit'&&$row['type']==='credit')$risk++;
        }
        $different=bccomp((string)$account['balance'],$balance,0)!==0;
        // Establish the journal opening before aligning the current balance. Legacy document warnings are a separate review concern.
        $eligible=$valid && count($rows)>0 && $initial==='0'
            && bccomp($balance,(string)PHP_INT_MAX,0)<=0 && bccomp($balance,(string)PHP_INT_MIN,0)>=0
            && ($account['type']==='expense'||bccomp($balance,'0',0)>=0);
        $reason='';
        if(!$valid)$reason='گردش نامعتبر نیاز به بررسی دارد.';
        elseif(!$rows && (string)$account['balance']!=='0')$reason='موجودی حساب بدون سابقه گردش ثبت شده است.';
        elseif($initial!==null&&$initial!=='0')$reason='موجودی ابتدای گردش یا تراکنش حذف‌شده نیاز به بررسی دارد.';
        elseif($risk)$reason='سند حوالهٔ قدیمیِ حساب هزینه نیاز به بررسی جداگانه دارد؛ تطبیق مانده، جهت حواله را تأیید یا تغییر نمی‌دهد.';
        elseif(!$eligible&&$different)$reason='مانده محاسبه‌شده نیاز به بررسی دارد.';
        return ['account_id'=>(int)$account['id'],'title'=>$account['title'],'account_type'=>$account['type'],'stored'=>(string)$account['balance'],'journal'=>$balance,
            'difference'=>bcsub($balance,(string)$account['balance'],0),'different'=>$different,'eligible'=>$eligible,'reason'=>$reason,
            'opening'=>$initial,'count'=>count($rows),'legacy_direction_risk'=>$risk,
            'reconciliation_scope'=>'recorded_journal_only','requires_document_review'=>$risk>0,
            'token'=>hash('sha256',wp_json_encode([$account['id'],(string)$account['balance'],$rows]))];
    }
    private function read_account_balance_review(int $id,bool $lock=false): array {
        $suffix=$lock?' FOR UPDATE':'';
        $account=$this->db->get_row($this->db->prepare("SELECT id,title,type,status,balance FROM {$this->accounts} WHERE id=%d$suffix",$id),ARRAY_A);
        if(!$account||$this->db->last_error)throw new RuntimeException('حساب یافت نشد.');
        $rows=$this->db->get_results($this->db->prepare("SELECT id,amount,type,action,balance_after FROM {$this->account_transactions} WHERE account_id=%d ORDER BY id$suffix",$id),ARRAY_A);
        if($this->db->last_error)throw new RuntimeException('خواندن گردش حساب انجام نشد.');
        return $this->account_balance_review_rows($account,$rows?:[]);
    }
    public function get_account_balance_review(int $id): array {
        if(!self::finance_balance_allowed())return $this->fail('اجازه بررسی مانده حساب را ندارید.');
        try{return $this->ok('',$this->read_account_balance_review($id));}catch(Throwable $e){return $this->fail($e->getMessage());}
    }
    /** Rebuild only an evidenced stale cache; preserve the actual journal and its old snapshots. */
    public function reconcile_account_balance(int $id,string $expected): array {
        if(!self::finance_balance_allowed())return $this->fail('اجازه تطبیق حساب را ندارید.');
        try{
            $this->finance_tables_ready([$this->accounts,$this->account_transactions,$this->actions_table,$this->db_prefix.'action_meta']);
            if(false===$this->db->query('START TRANSACTION'))throw new RuntimeException('شروع تطبیق حساب انجام نشد.');
            $review=$this->read_account_balance_review($id,true);
            if(!hash_equals($review['token'],$expected))throw new RuntimeException('گردش این حساب تغییر کرده؛ دوباره بررسی کنید.');
            if(!$review['eligible'])throw new RuntimeException($review['reason']?:'این حساب به بررسی سوابق نیاز دارد.');
            if($review['different']){
                if(false===$this->db->update($this->accounts,['balance'=>(int)$review['journal'],'updated_at'=>current_time('mysql')],['id'=>$id]))throw new RuntimeException('ثبت مانده حساب ناموفق بود.');
                if(!$this->db->insert($this->actions_table,['user_id'=>get_current_user_id(),'title'=>sanitize_text_field('تطبیق مانده حساب '.$review['title']),'content'=>$review['stored'].' ← '.$review['journal'],'date'=>current_time('mysql'),'creator'=>get_current_user_id()]))throw new RuntimeException('ثبت سابقه تطبیق حساب انجام نشد.');
                $audit=$this->save_meta_batch('action',(int)$this->db->insert_id,['type'=>'account_balance_reconciliation','account_id'=>$id,'previous_balance'=>$review['stored'],'journal_balance'=>$review['journal'],'review_token'=>$review['token'],'reconciliation_scope'=>'recorded_journal_only','legacy_direction_risk'=>$review['legacy_direction_risk']]);
                if(($audit['status']??'')!=='success')throw new RuntimeException('ثبت سابقه تطبیق حساب انجام نشد.');
            }
            if(false===$this->db->query('COMMIT'))throw new RuntimeException('ثبت نهایی تطبیق انجام نشد.');
            return $this->ok('مانده با خالص گردش‌های موجود یکسان شد؛ اسناد حواله تغییر نکردند.',['account_id'=>$id,'balance'=>$review['journal'],'label'=>number_format((int)$review['journal']),'reconciliation_scope'=>'recorded_journal_only','requires_document_review'=>$review['requires_document_review']]);
        }catch(Throwable $e){$this->db->query('ROLLBACK');return $this->fail($e->getMessage());}
    }
}
