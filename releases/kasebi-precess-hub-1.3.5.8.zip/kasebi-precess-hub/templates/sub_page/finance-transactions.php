<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
$per_page_key = basename( __FILE__, '.php' );
$per_page_key = "kph_{$per_page_key}_per_page";
$user_id      = get_current_user_id();
$defaults     = [
	'account_id'  => '',
	'cost'        => '',
	'page_number' => 1,
	'per_page'    => get_user_meta( $user_id, $per_page_key, TRUE ) ?: 20,
	'date'        => [
		'from' => '',
		'to'   => '',
	],
];
$args         = wp_parse_args( $_REQUEST, $defaults );
$args         = array_map( fn( $v ) => $v == 0 ? '' : $v, $args );
$has_filter   = kph_page_has_filter( $args, $defaults );
extract( $args );
update_user_meta( $user_id, $per_page_key, $per_page );

$date_from = $date['from'] ?? '';
$date_to   = $date['to'] ?? '';

$DB           = new kph_db();
$statuses     = $DB->get_cheque_statuses();
$transactions = $DB->get_account_transactions( [
	'page'       => $page_number,
	'per_page'   => $per_page,
	'account_id' => $account_id,
	'cost_type'  => $cost,
	'date_from'  => $date_from ? nooshika_jalali_to_gregorian( $date_from ) : NULL,
	'date_to'    => $date_to ? nooshika_jalali_to_gregorian( $date_to ) : NULL,
] );
$total_page   = $transactions['pagination']['total_page'];
$total_items  = $transactions['pagination']['total'];
$transactions = $transactions['items'];

/*
 * مقدار ذخیره‌شده در balance_after بر اساس زمان ثبت در سیستم است و اگر
 * تراکنشی با تاریخ گذشته ثبت شود، مانده تاریخی ردیف‌ها را درست نشان نمی‌دهد.
 * مانده هر تراکنش را بر اساس created_at و برای زمان‌های یکسان بر اساس id
 * دوباره محاسبه می‌کنیم.
 */
if ( ! empty( $transactions ) ) {
	global $wpdb;
	
	$transaction_ids = array_values(
		array_filter(
			array_map( 'absint', wp_list_pluck( $transactions, 'id' ) )
		)
	);
	
	if ( ! empty( $transaction_ids ) ) {
		$account_transactions_table = $wpdb->prefix . 'kph_account_transactions';
		$id_placeholders            = implode( ', ', array_fill( 0, count( $transaction_ids ), '%d' ) );
		
		$balance_rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT
					current_transaction.id,
					COALESCE(
						SUM(
							CASE
								WHEN previous_transaction.type = 'credit'
									THEN previous_transaction.amount
								ELSE -previous_transaction.amount
							END
						),
						0
					) AS balance_after
				FROM {$account_transactions_table} AS current_transaction
				LEFT JOIN {$account_transactions_table} AS previous_transaction
					ON previous_transaction.account_id = current_transaction.account_id
					AND (
						previous_transaction.created_at < current_transaction.created_at
						OR (
							previous_transaction.created_at = current_transaction.created_at
							AND previous_transaction.id <= current_transaction.id
						)
					)
				WHERE current_transaction.id IN ({$id_placeholders})
				GROUP BY current_transaction.id",
				$transaction_ids
			),
			ARRAY_A
		);
		
		$balances_by_transaction_id = [];
		foreach ( $balance_rows as $balance_row ) {
			$balances_by_transaction_id[ (int) $balance_row['id'] ] = (int) $balance_row['balance_after'];
		}
		
		foreach ( $transactions as &$transaction ) {
			$transaction_id = (int) $transaction['id'];
			if ( array_key_exists( $transaction_id, $balances_by_transaction_id ) ) {
				$transaction['balance_after'] = $balances_by_transaction_id[ $transaction_id ];
			}
		}
		unset( $transaction );
	}
}

$account    = $DB->get_account( $account_id );
$cost_types = get_option( 'kph_cost_category', [] );
?>
<div class="nk-block-head nk-block-head-sm">
    <div class="nk-block-between">
        <div class="nk-block-head-content">
            <h3 class="nk-block-title page-title">لیست تراکنش های <?php echo $account['title']; ?></h3>
            <div class="nk-block-des text-soft">
                <p class="mb-0"> در مجموع <?php echo $total_items; ?> تراکنش برای این حساب وجود دارد.</p>
            </div>
        </div>
        <div class="nk-block-head-content">
            <div class="toggle-wrap nk-block-tools-toggle">
                <div class="toggle-expand-content">
                    <ul class="nk-block-tools g-3">
                        <li class="nk-block-tools-opt">
                            <a href="" data-modal="#addAccountTransaction"
                               data-set="<?php echo esc_attr( wp_json_encode(
								   [
									   '#new_transaction_account_id' => $account_id,
								   ]
							   ) ); ?>"
                               class="btn btn-primary btn-icon populate_modal_inputs" data-bs-toggle="tooltip"
                               data-bs-placement="top" aria-label="ثبت تراکنش جدید"
                               data-bs-original-title="ثبت تراکنش جدید">
                                <em class="icon ni ni-ticket-plus"></em></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="nk-block">
    <div class="card card-stretch">
        <div class="card-inner-group">
            <div class="card-inner position-relative card-tools-toggle">
                <div class="card-title-group">
                    <div class="card-tools">
                    </div>
                    <div class="card-tools">
                        <ul class="btn-toolbar gx-1">
                            <li>
								<?php
								$filter_fields = [
									[
										'type'  => 'date-range',
										'label' => 'تاریخ تراکنش',
										'name'  => 'date',
										'value' => [
											'from' => $date_from ?? '',
											'to'   => $date_to ?? '',
										],
									],
									[
										'type'    => 'select',
										'label'   => 'نوع دسته بندی تراکنش',
										'name'    => 'cost',
										'value'   => $cost,
										'col'     => 6,
										'options' => [ 0 => 'همه موارد' ] + array_combine(
												array_keys( $cost_types ),
												array_column( $cost_types, 'label' )
											),
									],
									[
										'type'  => 'hidden',
										'name'  => 'account_id',
										'value' => $account_id,
									],
								];
								echo kph_get_template( 'components/filter-dropdown.php', [
									'has_filter'    => $has_filter,
									'filter_fields' => $filter_fields,
								] );
								?>
                            </li>
                            <li class="btn-toolbar-sep"></li>
                            <li>
								<?php
								echo kph_get_template( 'components/per-page-selector.php', [
									'per_page' => $per_page,
								] );
								?>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="card-inner p-0">
                <div class="nk-tb-list nk-tb-ulist is-compact">
                    <div class="nk-tb-item nk-tb-head">
                        <div class="nk-tb-col"><span class="sub-text">تاریخ تراکنش</span></div>
                        <div class="nk-tb-col"><span class="sub-text">مبلغ تراکنش</span></div>
                        <div class="nk-tb-col"><span class="sub-text">مانده پس از تراکنش</span></div>
                        <div class="nk-tb-col"><span class="sub-text">توضیحات</span></div>
                        <div class="nk-tb-col"><span class="sub-text">دسته بندی تراکنش</span></div>
                        <div class="nk-tb-col"><span class="sub-text">مقصد</span></div>
                        <div class="nk-tb-col text-end nk-tb-col-tools"></div>
                    </div>
					<?php
					if ( empty( $transactions ) ) {
						echo '<div class="no-item-found">تراکنشی یافت نشد</div>';
					} else {
						foreach ( $transactions as $entry ) {
							$date        = date_i18n( 'Y/m/d', strtotime( $entry['created_at'] ) );
							$amount      = number_format( $entry['amount'] );
							$icon        = $entry['type'] == "credit" ? 'ni-arrow-long-up' : 'ni-arrow-long-down';
							$class       = $entry['type'] == "credit" ? 'text-success' : 'text-danger';
							$attachment  = $DB->get_account_transaction_meta( $entry['id'], 'attachment' );
							$cost_type   = $DB->get_account_transaction_meta( $entry['id'], 'cost_type' );
							$destination = $DB->get_account_transaction_meta( $entry['id'], 'destination' );
							?>
                            <div class="nk-tb-item">
                                <div class="nk-tb-col">
                                    <span><?php echo $date; ?></span>
                                    <span class="sub-text"><?php echo date_i18n( 'H:i', strtotime( $entry['created_at']
										) );
										?></span>
                                </div>
                                <div class="nk-tb-col">
                                    <div class="amount <?php echo $class; ?>">
                                        <span><?php echo $amount; ?></span>
										<?php echo "<em class='icon ni $icon'></em>"; ?>
                                    </div>
                                </div>
                                <div class="nk-tb-col">
                                    <div class="amount">
                                        <span><?php echo number_format( $entry['balance_after'] ); ?></span>
                                    </div>
                                </div>
                                <div class="nk-tb-col">
									<?php echo $entry['description']; ?>
                                </div>
                                <div class="nk-tb-col">
									<?php
									if ( $cost_type ) {
										echo $cost_types[ $cost_type ] ? $cost_types[ $cost_type ]['label'] : $cost_type;
									} else {
										echo '-';
									}
									?>
                                </div>

                                <div class="nk-tb-col">
									<?php echo $destination; ?>
                                </div>
                                <div class="nk-tb-col nk-tb-col-tools">
                                    <ul class="nk-tb-actions gx-2">
                                        <?php if(kph_db::finance_balance_allowed()): ?>
                                        <li><a href="#" class="btn btn-sm btn-icon btn-trigger kph-edit-finance-attachment" title="افزودن یا جایگزینی ضمیمه" data-receipt="<?php echo esc_attr(wp_json_encode(['transaction_id'=>(int)$entry['id'],'attachment'=>(string)$attachment,'account_id'=>(int)$entry['account_id']])); ?>"><em class="icon ni ni-clip"></em></a></li>
                                        <?php endif; ?>
										<?php
										if ( $attachment ) {
											$attachment = explode( ',', $attachment );
											?>
                                            <li class="nk-tb-action">
												<?php
												$actions = [];
												foreach ( $attachment as $url ) {
													$file_data = $DB->get_uploaded_file_data( $url );
													if ( ! $file_data ) {
														$file_name = $url;
													} else {
														$file_name = $file_data['original_name'];
													}
													$actions[] = [
														'link'     => $url,
														'title'    => $file_name,
														'icon'     => 'ni-download',
														'target'   => '_blank',
														'download' => TRUE,
													];
												}
												echo kph_get_template( 'components/row-actions-dropdown.php', [
													'actions'   => $actions,
													'main_icon' => 'file-docs',
													'title'     => 'فایل ضمیمه',
												] );
												?>
                                            </li>
											<?php
										}
										?>
                                    </ul>
                                </div>
                            </div>
							<?php
						}
					}
					?>
                </div>
            </div>
            <div class="card-inner">
				<?php
				echo kph_get_template( 'components/pagination.php', [
					'max_page_num' => $total_page,
					'current_page' => $page_number,
					'class_name'   => 'user_pagination_link',
					'show_count'   => 2,
				] );
				?>
            </div>
        </div>
    </div>
</div>


<?php if(kph_db::finance_balance_allowed())echo kph_get_template('components/finance-attachment-modal.php'); ?>
