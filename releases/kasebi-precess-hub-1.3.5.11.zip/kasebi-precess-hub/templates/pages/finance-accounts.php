<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
$user_id    = get_current_user_id();
$defaults   = [
	'type' => '',
];
$args       = wp_parse_args( $_REQUEST, $defaults );
$args       = array_map( fn( $v ) => $v == 0 ? '' : $v, $args );
$has_filter = kph_page_has_filter( $args, $defaults );
extract( $args );

$DB       = new kph_db();
$types    = $DB->get_account_types();
$accounts = $DB->get_accounts( [
	'page'     => 1,
	'per_page' => 100,
	'type'     => $type,
] );
$total_items = (int) ( $accounts['pagination']['total'] ?? count( $accounts['items'] ?? [] ) );
$department_summary = $DB->get_account_department_summary();
$accounts = $accounts['items'];

?>
<div class="row g-gs mb-3">
    <div class="col-md-3"><a class="card card-bordered page_activator" href="<?php echo esc_url(home_url('/crm/finance-accounts')); ?>"><div class="card-inner"><h6>حساب‌ها و صندوق‌ها</h6><small class="text-soft">مدیریت حساب‌ها و مانده</small></div></a></div>
    <div class="col-md-3"><a class="card card-bordered page_activator" href="<?php echo esc_url(home_url('/crm/finance-transfers')); ?>"><div class="card-inner"><h6>حواله‌ها و گردش وجوه</h6><small class="text-soft">انتقال و پیگیری وجوه</small></div></a></div>
    <div class="col-md-3"><a class="card card-bordered page_activator" href="<?php echo esc_url(home_url('/crm/finance-cheque')); ?>"><div class="card-inner"><h6>چک‌ها</h6><small class="text-soft">وضعیت و گردش چک‌ها</small></div></a></div>
    <div class="col-md-3"><a class="card card-bordered page_activator" href="<?php echo esc_url(home_url('/crm/reports-cost')); ?>"><div class="card-inner"><h6>گزارش هزینه‌ها</h6><small class="text-soft">عملکرد هزینه‌ای</small></div></a></div>
</div>
<div class="row g-gs mb-3">
    <div class="col-md-4"><a class="card card-bordered page_activator" href="<?php echo esc_url(home_url('/crm/reports-order')); ?>"><div class="card-inner"><h6>عملکرد فروش</h6><small class="text-soft">فروش، برکت و سفارش‌ها</small></div></a></div>
    <div class="col-md-4"><a class="card card-bordered page_activator" href="<?php echo esc_url(home_url('/crm/reports-stock')); ?>"><div class="card-inner"><h6>ارزش و گردش موجودی</h6><small class="text-soft">موجودی مخزن‌ها و انبار محصولات</small></div></a></div>
    <div class="col-md-4"><a class="card card-bordered page_activator" href="<?php echo esc_url(home_url('/crm/produce-warehouses')); ?>"><div class="card-inner"><h6>انبارها</h6><small class="text-soft">موجودی و انتقال بین انبارها</small></div></a></div>
</div>
<div class="card card-bordered mb-3"><div class="card-inner"><h5 class="mb-3">خلاصه تراکنش‌های مالی به تفکیک دپارتمان</h5><div class="table-responsive"><table class="table"><thead><tr><th>دپارتمان</th><th>تعداد تراکنش</th><th>درآمد</th><th>هزینه</th><th>خالص</th></tr></thead><tbody><?php if(empty($department_summary)): ?><tr><td colspan="5">تراکنش مالی ثبت نشده است.</td></tr><?php else: foreach($department_summary as $dept): $labels=['finance'=>'مالی','sales'=>'فروش','production'=>'تولید','supply'=>'تأمین','warehouse'=>'انبار','admin'=>'اداری','unassigned'=>'بدون دپارتمان']; ?><tr><td><?php echo esc_html($labels[$dept['department']]??$dept['department']); ?></td><td><?php echo number_format((int)$dept['transaction_count']); ?></td><td><?php echo number_format((float)$dept['income']); ?> ریال</td><td><?php echo number_format((float)$dept['expenses']); ?> ریال</td><td><?php echo number_format((float)$dept['net']); ?> ریال</td></tr><?php endforeach; endif; ?></tbody></table></div><small class="text-soft">این خلاصه بر اساس تراکنش‌های حساب‌هاست؛ تراکنش‌های قدیمی یا خودکار که برچسب دپارتمان ندارند در ردیف «بدون دپارتمان» نمایش داده می‌شوند.</small></div></div>
<div class="nk-block-head nk-block-head-sm">
    <div class="nk-block-between">
        <div class="nk-block-head-content">
            <h3 class="nk-block-title page-title">مرکز مدیریت حساب‌های مالی</h3>
            <div class="nk-block-des text-soft">
                <p class="mb-0">شما در مجموع <?php echo $total_items; ?> حساب دارید.</p>
            </div>
        </div>
        <div class="nk-block-head-content">
            <div class="toggle-wrap nk-block-tools-toggle">
                <div class="toggle-expand-content">
                    <ul class="nk-block-tools g-3">
                        <li class="nk-block-tools-opt">
                            <a href="#addAccount" class=" btn btn-icon btn-primary" data-bs-target="#addAccount"
                               data-bs-toggle="modal"><em class="icon ni ni-plus"></em></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="nk-block">
    <div class="card card-stretch">
        <div class="card-inner-group">
            <div class="card-inner position-relative card-tools-toggle">
                <div class="card-title-group">
                    <div class="card-tools">
                    </div>
                    <div class="card-tools">
                        <ul class="btn-toolbar gx-1">
                            <li>
								<?php
								$filter_fields = [
									[
										'type'    => 'select',
										'label'   => 'نوع حساب',
										'name'    => 'type',
										'value'   => $type,
										'options' => [ 0 => 'همه موارد' ] + array_combine(
												array_keys( $types ),
												array_column( $types, 'label' )
											),
									],
								];
								
								echo kph_get_template( 'components/filter-dropdown.php', [
									'has_filter'    => $has_filter,
									'filter_fields' => $filter_fields,
								] );
								?>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="card-inner p-0">
                <div class="nk-tb-list nk-tb-ulist is-compact">
                    <div class="nk-tb-item nk-tb-head">
                        <div class="nk-tb-col"><span class="sub-text">تاریخ ایجاد</span></div>
                        <div class="nk-tb-col"><span class="sub-text">نام حساب</span></div>
                        <div class="nk-tb-col"><span class="sub-text">مانده حساب</span></div>
                        <div class="nk-tb-col text-end nk-tb-col-tools"></div>
                    </div>
					<?php
					if ( empty( $accounts ) ) {
						echo '<div class="no-item-found">حسابی یافت نشد</div>';
					} else {
						foreach ( $accounts as $entry ) {
							$date    = date_i18n( 'Y/m/d', strtotime( $entry['created_at'] ) );
							$balance = number_format( $entry['balance'] );
							?>
                            <div class="nk-tb-item">
                                <div class="nk-tb-col">
                                    <span><?php echo $date; ?></span>
                                </div>
                                <div class="nk-tb-col"><span><?php echo esc_html($entry['title']); ?></span></div>
                                <div class="nk-tb-col">
                                    <div class="amount">
                                        <span class="kph-finance-account-balance" data-account-id="<?php echo (int)$entry['id']; ?>"><?php echo $balance; ?></span>
                                    </div>
                                </div>
                                <div class="nk-tb-col nk-tb-col-tools">
                                    <ul class="nk-tb-actions gx-2">
                                        <?php if(kph_db::finance_balance_allowed()){ ?><li><button type="button" class="btn btn-sm btn-icon btn-trigger kph-review-account-balance" data-account-id="<?php echo (int)$entry['id']; ?>" data-nonce="<?php echo esc_attr(wp_create_nonce('kph_finance_balance_'.(int)$entry['id'])); ?>" title="بررسی و تطبیق مانده" aria-label="بررسی و تطبیق مانده"><em class="icon ni ni-reload" aria-hidden="true"></em></button></li><?php } ?>
                                        <?php if(kph_db::finance_balance_allowed()){ ?><li><button type="button" class="btn btn-sm btn-icon btn-trigger kph-review-transfer-deposits" data-account-id="<?php echo (int)$entry['id']; ?>" data-nonce="<?php echo esc_attr(wp_create_nonce('kph_finance_transfer_deposits_'.(int)$entry['id'])); ?>" title="بررسی واریز حواله‌ها" aria-label="بررسی واریز حواله‌ها"><em class="icon ni ni-exchange" aria-hidden="true"></em></button></li><?php } ?>
										<?php
										$hidden_actions = [];
										
										if ( $entry['bank_name'] ) {
											$hidden_actions[] = [
												'link'  => "",
												'title' => $entry['bank_name'],
												'icon'  => 'ni-server',
											];
										}
										if ( $entry['owner_name'] ) {
											$hidden_actions[] = [
												'link'  => "",
												'title' => $entry['owner_name'],
												'icon'  => 'ni-user-list-fill',
											];
										}
										if ( $entry['account_no'] ) {
											$hidden_actions[] = [
												'link'  => "",
												'title' => $entry['account_no'],
												'icon'  => 'ni-slack-hash',
											];
										}
										$hidden_actions[] = [
											'link'  => '/crm/finance-transactions/?account_id=' . $entry['id'],
											'title' => 'تاریخچه تراکنش ها',
											'icon'  => 'ni-swap-v',
											'class' => 'page_activator',
										];
										$hidden_actions[] = [
											'title' => 'ویرایش حساب',
											'icon'  => 'ni-edit',
											'class' => 'edit_item',
											'data'  => [
												'modal'      => 'addAccount',
												'account_id' => $entry['id'],
												'title'      => $entry['title'],
												'type'       => $entry['type'],
												'bank_name'  => $entry['bank_name'],
												'account_no' => $entry['account_no'],
												'owner_name' => $entry['owner_name'],
											],
										];
										$hidden_actions[] = [
											'title' => 'ثبت تراکنش جدید',
											'icon'  => 'ni-ticket-plus',
											'class' => 'populate_modal_inputs',
											'data'  => [
												'modal' => '#addAccountTransaction',
												'set'   => esc_attr( wp_json_encode(
													[
														'#new_transaction_account_id' => $entry['id'],
													]
												) ),
											],
										];
										echo kph_get_template( 'components/row-actions.php', [
											'actions' => $hidden_actions,
										] );
										
										?>
                                    </ul>
                                </div>
                            </div>
							<?php
						}
					}
					?>
                </div>
            </div>
        </div>
    </div>
</div>

