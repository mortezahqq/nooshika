<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * @var array $date
 * @var array $request
 */

$DB      = new kph_db();
$request = isset( $request ) && is_array( $request ) ? $request : [];
$section = sanitize_key( $request['section'] ?? 'all' );

$allowed_sections = [ 'all', 'repository', 'saloon', 'finished', 'trace', 'batches', 'batch' ];
if ( ! in_array( $section, $allowed_sections, TRUE ) ) {
	wp_die( 'بخش گزارش انبار برای پرینت معتبر نیست.' );
}

$date_from_j = sanitize_text_field( wp_unslash( $date['from'] ?? '' ) );
$date_to_j   = sanitize_text_field( wp_unslash( $date['to'] ?? '' ) );
$date_from   = $date_from_j ? nooshika_jalali_to_gregorian( $date_from_j ) : '';
$date_to     = $date_to_j ? nooshika_jalali_to_gregorian( $date_to_j ) : '';

$raw_product_id = absint( $request['raw_product_id'] ?? 0 );
$customer_id    = absint( $request['customer_id'] ?? 0 );
$batch_id       = absint( $request['batch_id'] ?? 0 );
$search         = sanitize_text_field( wp_unslash( $request['search'] ?? '' ) );

if ( ! function_exists( 'kph_print_stock_num' ) ) {
	function kph_print_stock_num( $value, int $decimals = 0 ): string {
		$value = (float) $value;
		
		return $decimals > 0
			? rtrim( rtrim( number_format( $value, $decimals ), '0' ), '.' )
			: number_format( $value );
	}
}

if ( ! function_exists( 'kph_print_stock_date' ) ) {
	function kph_print_stock_date( $value ): string {
		return empty( $value ) ? '-' : date_i18n( 'Y/m/d', strtotime( $value ) );
	}
}

$common_args = [
	'date_from'      => $date_from,
	'date_to'        => $date_to,
	'raw_product_id' => $raw_product_id,
	'search'         => $search,
];

$tables       = [];
$summary      = [];
$report_title = 'گزارش انبارها';

if ( $section === 'all' || $section === 'repository' ) {
	$report = $DB->get_stock_repository_report( $common_args );
	$rows   = [];
	foreach ( $report['items'] as $item ) {
		$rows[] = [
			$item['raw_product_title'],
			$item['raw_product_code'] ?: '-',
			kph_print_stock_num( $item['purchase_in'], 3 ),
			kph_print_stock_num( $item['processing_out'], 3 ),
			kph_print_stock_num( $item['processing_return'], 3 ),
			kph_print_stock_num( $item['waste'], 3 ),
			kph_print_stock_num( $item['current_weight'], 3 ),
			kph_print_stock_num( $item['current_value'] ),
		];
	}
	$tables[] = [
		'title'   => 'مخزن مواد اولیه',
		'headers' => [ 'ماده اولیه', 'کد', 'ورودی خرید', 'خروج فرآوری', 'برگشتی', 'ضایعات', 'موجودی', 'ارزش موجودی (ریال)' ],
		'rows'    => $rows,
	];
	$summary['موجودی مخزن'] = kph_print_stock_num( $report['summary']['current_weight'], 3 );
	if ( $section === 'repository' ) {
		$report_title = 'گزارش مخزن مواد اولیه';
	}
}

if ( $section === 'all' || $section === 'saloon' ) {
	$report = $DB->get_stock_saloon_report( $common_args );
	$rows   = [];
	foreach ( $report['items'] as $item ) {
		$rows[] = [
			$item['raw_product_title'],
			$item['raw_product_code'] ?: '-',
			kph_print_stock_num( $item['from_processing'], 3 ),
			kph_print_stock_num( $item['converted_to_product'], 3 ),
			kph_print_stock_num( $item['return_to_processing'], 3 ),
			kph_print_stock_num( $item['waste'], 3 ),
			kph_print_stock_num( $item['current_weight'], 3 ),
		];
	}
	$tables[] = [
		'title'   => 'سالن بسته‌بندی / فرآوری',
		'headers' => [ 'ماده اولیه', 'کد', 'ورودی از فرآوری', 'تبدیل به محصول', 'برگشت به فرآوری', 'ضایعات', 'موجودی سالن' ],
		'rows'    => $rows,
	];
	$summary['موجودی سالن'] = kph_print_stock_num( $report['summary']['current_weight'], 3 );
	if ( $section === 'saloon' ) {
		$report_title = 'گزارش سالن بسته‌بندی / فرآوری';
	}
}

if ( $section === 'all' || $section === 'finished' ) {
	$report = $DB->get_stock_finished_goods_report( [
		'date_from' => $date_from,
		'date_to'   => $date_to,
		'search'    => $search,
	] );
	$rows = [];
	foreach ( $report['items'] as $item ) {
		$rows[] = [
			$item['product_title'],
			$item['unique_product_code'],
			'#' . $item['wc_product_id'],
			kph_print_stock_num( $item['production_in_qty'] ),
			kph_print_stock_num( $item['sale_out_qty'] ),
			kph_print_stock_num( $item['current_qty'] ),
			kph_print_stock_num( $item['current_value'] ),
		];
	}
	$tables[] = [
		'title'   => 'انبار محصول آماده',
		'headers' => [ 'محصول', 'کد یکتا', 'شناسه محصول', 'ورودی تولید', 'خروج فروش', 'موجودی', 'ارزش موجودی (ریال)' ],
		'rows'    => $rows,
	];
	$summary['موجودی محصول آماده'] = kph_print_stock_num( $report['summary']['current_qty'] );
	$summary['خروج فروش در بازه']  = kph_print_stock_num( $report['summary']['sale_out_qty'] );
	if ( $section === 'finished' ) {
		$report_title = 'گزارش انبار محصول آماده';
	}
}

if ( $section === 'all' || $section === 'trace' ) {
	$report = $DB->get_stock_inventory_trace_report( [
		'date_from'   => $date_from,
		'date_to'     => $date_to,
		'customer_id' => $customer_id,
		'search'      => $search,
		'page'        => 1,
		'per_page'    => 5000,
	] );
	$rows = [];
	foreach ( $report['items'] as $item ) {
		$is_in = (int) $item['change_qty'] > 0;
		$party = ! empty( $item['customer_id'] )
			? trim( (string) $item['customer_name'] . ' / سفارش ' . (string) $item['order_number'] )
			: '-';
		$rows[] = [
			kph_print_stock_date( $item['created_at'] ),
			$item['product_title'],
			$item['unique_product_code'],
			$is_in ? 'ورودی' : 'خروجی',
			kph_print_stock_num( absint( $item['change_qty'] ) ),
			$item['ref_type'] . ' #' . $item['ref_id'],
			$party,
			kph_print_stock_num( abs( $item['total_cost'] ) ),
		];
	}
	$tables[] = [
		'title'   => 'رهگیری ورودی و خروجی محصول',
		'headers' => [ 'تاریخ', 'محصول', 'کد', 'نوع', 'تعداد', 'مرجع', 'مشتری / سفارش', 'بهای تمام‌شده (ریال)' ],
		'rows'    => $rows,
	];
	if ( $section === 'trace' ) {
		$report_title = 'گزارش رهگیری ورودی و خروجی محصول';
	}
}

if ( $section === 'all' || $section === 'batches' ) {
	$report = $DB->get_stock_batches_factor_report( array_merge( $common_args, [ 'per_page' => 5000 ] ) );
	$rows   = [];
	foreach ( $report['items'] as $item ) {
		$rows[] = [
			'محموله ' . $item['batch_id'],
			$item['invoice_no'] ?: '-',
			$item['supplier_name'] ?: '-',
			$item['raw_product_title'],
			kph_print_stock_num( $item['initial_qty_weight'], 3 ),
			kph_print_stock_num( $item['converted_weight'], 3 ),
			kph_print_stock_num( $item['sold_qty'], 2 ),
			kph_print_stock_num( $item['sales_amount'] ),
			kph_print_stock_num( $item['gross_profit'] ),
		];
	}
	$tables[] = [
		'profit' => array_sum(array_column($report['items']??[],'gross_profit')),
        'title'   => 'گزارش فاکتورهای مواد اولیه',
		'headers' => [ 'محموله', 'شماره فاکتور', 'تأمین‌کننده', 'ماده', 'وزن اولیه', 'تبدیل‌شده', 'فروش‌رفته', 'مبلغ فروش', 'برکت' ],
		'rows'    => $rows,
	];
	if ( $section === 'batches' ) {
		$report_title = 'گزارش فاکتورهای مواد اولیه';
	}
}

if ( $section === 'batch' ) {
	if ( $batch_id <= 0 ) {
		wp_die( 'شناسه محموله برای پرینت مشخص نشده است.' );
	}
	$batch_report = $DB->get_stock_single_batch_factor_report( $batch_id, [
		'date_from' => $date_from,
		'date_to'   => $date_to,
	] );
	$batch = $batch_report['batch'] ?? NULL;
	if ( empty( $batch ) ) {
		wp_die( 'محموله برای پرینت یافت نشد.' );
	}
	$report_title = 'ریزگزارش محموله شماره ' . $batch_id;
	$summary      = [
		'ماده اولیه'   => $batch['raw_product_title'],
		'تأمین‌کننده'  => $batch['supplier_name'] ?: '-',
		'شماره فاکتور' => $batch['invoice_no'] ?: '-',
		'وزن خرید'     => kph_print_stock_num( $batch['initial_qty_weight'], 3 ),
		'قیمت واحد'    => kph_print_stock_num( $batch['unit_cost'] ),
		'مبلغ خرید'    => kph_print_stock_num( (float) $batch['initial_qty_weight'] * (float) $batch['unit_cost'] ) . ' ریال',
	];

	$rows = [];
	foreach ( $batch_report['conversions'] ?? [] as $item ) {
		$rows[] = [
			get_the_title( $item['wc_product_id'] ),
			$item['unique_product_code'],
			kph_product_weight::print_label((string)get_the_title($item['wc_product_id']),$item['weight_per_item']),
			kph_print_stock_num( $item['allocated_items'], 6 ),
			kph_print_stock_num( $item['allocated_weight'], 6 ),
			kph_print_stock_num( $item['sold_qty'], 6 ),
			kph_print_stock_num( $item['sales_amount'] ),
			kph_print_stock_num( (float) $item['sales_amount'] - (float) $item['cogs_amount'] ),
		];
	}
	$tables[] = [
		'profit' => array_sum(array_map(static fn($r)=>(float)$r['sales_amount']-(float)$r['cogs_amount'],$batch_report['conversions']??[])),
        'title'   => 'تبدیل‌های این محموله',
		'headers' => [ 'محصول', 'کد', 'وزن هر عدد (گرم)', 'سهم تولید', 'وزن تخصیص‌یافته (کیلوگرم)', 'فروش‌رفته', 'فروش', 'برکت' ],
		'rows'    => $rows,
	];

	$rows = [];
	foreach ( $batch_report['customers'] ?? [] as $item ) {
		$rows[] = [
			$item['customer_name'] ?: '-',
			$item['order_number'],
			get_the_title( $item['wc_product_id'] ),
			$item['unique_product_code'],
			kph_print_stock_num( $item['sold_qty'], 6 ),
			kph_print_stock_num( $item['sales_amount'] ),
			kph_print_stock_num( $item['gross_profit'] ),
		];
	}
	$tables[] = [
		'profit' => array_sum(array_column($batch_report['customers']??[],'gross_profit')),
        'title'   => 'مشتری‌های این محموله',
		'headers' => [ 'مشتری', 'سفارش', 'محصول', 'کد', 'تعداد', 'مبلغ فروش', 'برکت' ],
		'rows'    => $rows,
	];
}

$logo = get_option( 'kph_print_logo' ) ?: get_option( 'kph_panel_logo' );
if ( ! $logo ) {
	$logo = KPH_ASSETS_URL . 'image/kasebi_logo.png';
}

$range_label = 'همه تاریخ‌ها';
if ( $date_from_j || $date_to_j ) {
	$range_label = ( $date_from_j ?: 'ابتدا' ) . ' تا ' . ( $date_to_j ?: 'امروز' );
}
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title><?php echo esc_html( $report_title ); ?></title>
    <link rel="stylesheet" href="/wp-content/plugins/nooshika-main/assets/css/nooshika-fonts.css?ver=5.4.0">
    <style>
        @page { size: A4 landscape; margin: 9mm; }
        * { box-sizing: border-box; }
        body { margin: 0; direction: rtl; color: #111827; background: #fff; font-size: 11px; line-height: 1.7; }
        .print-actions { position: fixed; top: 12px; left: 12px; z-index: 10; }
        .print-actions button { border: 0; border-radius: 7px; padding: 8px 16px; color: #fff; background: #111827; cursor: pointer; font-family: inherit; }
        .header { display: grid; grid-template-columns: 120px 1fr 210px; gap: 16px; align-items: center; padding-bottom: 10px; border-bottom: 2px solid #111827; margin-bottom: 12px; }
        .logo img { max-width: 105px; max-height: 68px; object-fit: contain; }
        h1 { margin: 0; text-align: center; font-size: 19px; }
        .meta { font-size: 11px; }
        .summary { display: grid; grid-template-columns: repeat(4, 1fr); gap: 7px; margin: 10px 0 14px; }
        .card { border: 1px solid #9ca3af; border-radius: 6px; padding: 7px; text-align: center; }
        .card span { display: block; color: #6b7280; font-size: 10px; }
        .card strong { display: block; margin-top: 2px; font-size: 13px; }
        .report-section { margin: 0 0 16px; break-inside: avoid; }
        .report-section h2 { margin: 0 0 6px; font-size: 14px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #6b7280; padding: 6px 5px; text-align: center; vertical-align: middle; }
        th { background: #eef2f7; font-weight: 700; }
        @media print {
            .print-actions { display: none; }
            body { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
            thead { display: table-header-group; }
        }
    </style>
</head>
<body>
<div class="print-actions"><button onclick="window.print()">پرینت</button></div>
<main>
    <header class="header">
        <div class="logo"><img src="<?php echo esc_url( $logo ); ?>" alt=""></div>
        <h1><?php echo esc_html( $report_title ); ?></h1>
        <div class="meta">
            <div><strong>تاریخ چاپ:</strong> <?php echo esc_html( date_i18n( 'Y/m/d H:i' ) ); ?></div>
            <div><strong>بازه گزارش:</strong> <?php echo esc_html( $range_label ); ?></div>
        </div>
    </header>

	<?php if ( ! empty( $summary ) ) { ?>
        <div class="summary">
			<?php foreach ( $summary as $label => $value ) { ?>
                <div class="card"><span><?php echo esc_html( $label ); ?></span><strong><?php echo esc_html( $value ); ?></strong></div>
			<?php } ?>
        </div>
	<?php } ?>

	<?php foreach ( $tables as $table ) { ?>
        <section class="report-section">
            <h2><?php echo esc_html( $table['title'] ); ?></h2>
            <table>
                <thead><tr><?php foreach ( $table['headers'] as $header ) { ?><th><?php echo esc_html( $header ); ?></th><?php } ?></tr></thead>
                <tbody>
				<?php if ( empty( $table['rows'] ) ) { ?>
                    <tr><td colspan="<?php echo count( $table['headers'] ); ?>">گزارشی یافت نشد.</td></tr>
				<?php } else { foreach ( $table['rows'] as $row ) { ?>
                    <tr><?php foreach ( $row as $value ) { ?><td><?php echo esc_html( $value ); ?></td><?php } ?></tr>
				<?php } } ?>
                </tbody>
            </table>
            <?php if(array_key_exists('profit',$table)){ ?><p><strong>جمع برکت: <?php echo number_format($table['profit']); ?> ریال</strong></p><?php } ?>
        </section>
	<?php } ?>
</main>
</body>
</html>
