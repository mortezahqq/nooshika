<?php

$defaults   = [
	'order-id' => '',
];
$args       = wp_parse_args( $_REQUEST, $defaults );
$order_id   = $args['order-id'];
$DB         = new kph_db();
$order_data = $DB->get_order_data( (int) $order_id );
if ( empty( $order_data ) ) {
	echo "<div class='no-item-found'>سفارش یافت نشد</div>";
} else {
	$customer_id   = $order_data['customer_id'];
	$addresses     = get_user_meta( $customer_id, 'address_list', TRUE );
	$addresses     = kasebi_unminified_string( $addresses );
	$addresses     = $addresses ?: [];
	$address_id    = $DB->get_order_meta( $order_id, 'address_id' );
	$attachment    = $DB->get_order_meta( $order_id, 'attachment' );
	$factor_date   = $DB->get_order_meta( $order_id, 'factor_date' );
	$shipment_date = $DB->get_order_meta( $order_id, 'shipment_date' );
	$factor_number = $DB->get_order_meta( $order_id, 'factor_number' );
	?>
    <div class="nk-block-head nk-block-head-sm">
        <div class="nk-block-between">
            <div class="nk-block-head-content">
                <h3 class="nk-block-title page-title">ویرایش فاکتور مشتری</h3>
            </div>
        </div>
    </div>
    <div class="nk-block invoice-bills">
        <div class="row g-gs">
            <div class="col-12 col-md-4">
                <div class="card">
                    <div class="card-inner">
                        <div class="form-group card-title search_wrapper">
                            <label class="form-label" for="search_user_for_order">جستجوی مشتری</label>
                            <div class="form-control-wrap">
                                <div class="form-icon form-icon-left"><em class="icon ni ni-user"></em></div>
                                <input type="text" class="form-control search_user_modal" id="search_user_for_order"
                                       data-role="subscriber">
                            </div>
                            <p class="mt-1">جهت جستجوی مشتری شماره موبایل و یا نام مشتری را جستجو کنید.</p>
                            <div class="customer_search_result" data-input="#new_order_customer_id"
                                 data-preview=".customer_box"></div>
                        </div>
                        <div class="customer_box nk-tb-list">
							<?php
							if ( $customer_id ) {
								echo kph_get_template( 'components/user-card.php', [
									'user_id'    => $customer_id,
									'show_phone' => TRUE,
								] );
							}
							?>
                        </div>
                        <input type="hidden" id="new_order_customer_id"
                               data-page="order-edit"
                               value="<?php echo $customer_id; ?>">
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-8 product_block_card">
                <div class="card h-100">
                    <div class="card-inner">
                        <div class="row g-gs">
                            <div class="col-12 col-md-4">
                                <div class="form-group card-title">
                                    <label class="form-label" for="search_sku_for_customer_invoice">جستجوی محصول</label>
                                    <div class="form-control-wrap">
                                        <div class="form-icon form-icon-left"><em class="icon ni ni-package"></em></div>
                                        <input type="text" class="form-control" id="search_sku_for_customer_invoice"
                                               placeholder="نام محصول">
                                    </div>
                                </div>
                                <div class="product_search_list"></div>
                            </div>
                            <div class="col-12 col-md-8">
                                <div class="product_search_result"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 order_factor_card">
                <div class="card">
                    <div class="card-inner">
                        <table class="table table-striped products_payment">
                            <thead>
                            <tr>
                                <th class="w-30">محصول</th>
                                <th class="w-120px">قیمت پایه</th>
                                <th class="w-80px">تعداد</th>
                                <th class="w-80px">درصد تخفیف</th>
                                <th class="w-150px">تخفیف کالایی</th>
                                <th class="w-175px text-end">مبلغ نهایی</th>
                            </tr>
                            </thead>
                            <tbody>
							<?php
							foreach ( $order_data['items'] as $order_item ) {
								$title = get_the_title( $order_item['wc_product_id'] );
								$x     = $order_item['goods_buy_x'];
								$y     = $order_item['goods_free_y'];
								?>
                                <tr data-product="<?php echo $order_item['wc_product_id']; ?>">
                                    <td>
                                        <div class="user-info">
                                            <span class="tb-lead"><?php echo $title; ?></span>
                                            <span
                                                class="sub-text"><?php echo $order_item['unique_product_code']; ?></span>
                                        </div>
                                    </td>
                                    <td class="line_reg_price">
                                        <input class="price_input item_reg_total form-control"
                                               value="<?php echo number_format( $order_item['base_price'] ); ?>">
                                    </td>
                                    <td><input class="line_qty form-control"
                                               value="<?php echo $order_item['qty_ordered']; ?>"></td>
                                    <td>
                                        <input class="line_off_percent form-control"
                                               value="<?php echo (int) $order_item['discount_cash_value']; ?>">
                                    </td>
                                    <td class="line_off_goods">
                                        <div class="off_goods_desc">
											<?php
											if ( $x ) {
												echo "هر $x عدد، $y رایگان";
											} else {
												echo '-';
											}
											?>

                                        </div>
                                        <div class="off_goods_qty fs-13px"></div>
                                        <input class="line_buy_x" type="hidden" value="<?php echo $x; ?>">
                                        <input class="line_get_y" type="hidden" value="<?php echo $y; ?>">
                                    </td>
                                    <td class="tb-col-action">
                                        <div>
                                            <span class="tb-lead line_subtotal fw-bold fs-18px">0</span>
                                            <span class="sub-text line_per_item">0</span>
                                        </div>
                                        <input type="hidden" class="line_note">
                                        <div class="d-flex justify-end" style="gap: 5px">
                                            <a class="link-cross me-sm-n1 set_line_note" data-bs-toggle="popover"
                                               data-bs-trigger="hover"
                                               data-bs-content="<?php echo $order_item['note']; ?>"
                                               data-bs-placement="top"
                                               aria-label="یادداشت" data-bs-original-title="یادداشت"><em
                                                    class="icon ni ni-note-add-c"></em></a>
                                            <a class="link-done me-sm-n1 set_good_offer"><em
                                                    class="icon ni ni-percent"></em></a>
                                            <a class="link-cross me-sm-n1 delete_factor_row"><em
                                                    class="icon ni ni-cross"></em></a>
                                        </div>
                                    </td>
                                </tr>
								<?php
							}
							?>
                            </tbody>
                            <tfoot>
                            <tr>
                                <td colspan="3"></td>
                                <td colspan="2">جمع کل</td>
                                <td class="order_subtotal">0</td>
                            </tr>
                            <tr>
                                <td colspan="3"></td>
                                <td colspan="2">جمع تخفیفات</td>
                                <td class="order_total_off">0</td>
                            </tr>
                            <tr>
                                <td colspan="3"></td>
                                <td colspan="2">مبلغ کل فاکتور</td>
                                <td class="order_total_final">0</td>
                            </tr>
                            </tfoot>
                        </table>
                        <div class="d-flex justify-end mt-3">
                            <button class="btn btn-success submit_customer_order"
                                    data-id="<?php echo $order_data['id']; ?>">ویرایش سفارش
                            </button>
                        </div>
                    </div>
                </div>
                <div class="row g-gs mt-0">
                    <div class="col-md-4">
                        <div class="card h-100">
                            <div class="card-inner">
                                <div class="nk-block-between mb-2">
                                    <h6 class="nk-block-title">مستندات سفارش</h6>
                                </div>
                                <div class="form-group">
                                    <div class="upload-zone" data-target="#new_order_attachment"
                                         data-name="title"
                                         data-urls="<?php echo $attachment; ?>"
                                         data-action="kph_handle_file_upload" data-max-files="30">
                                        <div class="dz-message" data-dz-message>
                                            <span class="dz-message-text">بکشید و رها کنید</span>
                                            <span class="dz-message-or">یا</span>
                                            <div class="btn btn-primary">انتخاب کنید</div>
                                        </div>
                                    </div>
                                </div>
                                <input type="hidden" id="new_order_attachment">
                            </div>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="card h-100">
                            <div class="card-inner">
                                <div class="nk-block-between mb-4">
                                    <h6 class="nk-block-title">توضیحات سفارش</h6>
                                </div>
                                <div class="form-control-wrap">
                                    <textarea class="form-control no-resize" id="order_description"><?php
	                                    echo $order_data['note']; ?></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="card h-100">
                            <div class="card-inner">
                                <div class="nk-block-between mb-3">
                                    <h6 class="nk-block-title">اطلاعات اضافه سفارش</h6>
                                </div>
                                <div class="form-group">
                                    <label class="form-label" for="new_factor_date">تاریخ فاکتور</label>
                                    <div class="form-control-wrap">
                                        <div class="form-icon form-icon-left">
                                            <em class="icon ni ni-calendar-alt"></em>
                                        </div>
                                        <input type="text" class="form-control datepicker" id="new_factor_date"
                                               value="<?php echo $factor_date; ?>">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="form-label" for="new_shipment_date">تاریخ ارسال سفارش</label>
                                    <div class="form-control-wrap">
                                        <div class="form-icon form-icon-left"><em class="icon ni ni-truck"></em></div>
                                        <input type="text" class="form-control datepicker" id="new_shipment_date" value="<?php echo esc_attr( $shipment_date ); ?>" placeholder="در صورت مشخص بودن تاریخ ارسال وارد کنید">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="form-label" for="new_payment_term_days">مهلت تسویه از تاریخ فاکتور (روز)</label>
                                    <input type="number" class="form-control" id="new_payment_term_days" min="0" max="3650" step="1" placeholder="تعیین نشده" value="<?php echo esc_attr( $DB->get_order_meta( $order_id, 'payment_term_days' ) ); ?>">
                                    <small class="text-soft">صفر: تسویه همان روز؛ خالی: سررسید تعیین نشده</small>
                                </div>
                                <div class="form-group">
                                    <label class="form-label" for="new_factor_number">شماره فاکتور</label>
                                    <div class="form-control-wrap">
                                        <div class="form-icon form-icon-left">
                                            <em class="icon ni ni-tag-alt"></em>
                                        </div>
                                        <input type="text" class="form-control" id="new_factor_number"
                                               value="<?php echo $factor_number; ?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="card">
                            <div class="card-inner  pb-0">
                                <div class="nk-block-between">
                                    <h6 class="nk-block-title">آدرس تحویل سفارش</h6>
                                    <a href="#" class="btn btn-icon btn-primary" id="open_addUserAddress"><em class="icon
                                 ni ni-plus"></em></a>
                                </div>
                            </div>
                            <div class="card-inner address_wrapper">
								<?php
								echo kph_get_template( "misc/addresses.php", [
									'addresses' => $addresses,
									'user_id'   => $customer_id,
									'selected'  => $address_id,
								] );
								?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
	<?php
}