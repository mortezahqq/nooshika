<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
$DB     = new kph_db();
$intros = $DB->get_introduce_methods();
$colors = [
	'success',
	'warning',
	'info',
	'pink',
	'teal',
	'purple',
	'orange',
	'azure',
];
?>
<div class="nk-block-head nk-block-head-sm">
    <div class="nk-block-between">
        <div class="nk-block-head-content">
            <h3 class="nk-block-title page-title">مدیریت تولید</h3>
            <div class="nk-block-des text-soft">
                <p>به داشبورد مدیریت تولید خوش آمدید.</p>
            </div>
        </div>
        <div class="nk-block-head-content">
            <div class="toggle-wrap nk-block-tools-toggle">
            </div>
        </div>
    </div>
</div>
<div class="nk-block">
    <div class="card card-bordered">
        <div class="card-inner">
            <div class="card-title-group align-center mb-3">
                <div class="card-title"><h6 class="title">عملکرد فروش ویزیتورها</h6><p class="text-soft mb-0">گزارش فروش ماه جاری و جزئیات فاکتورهای هر ویزیتور</p></div>
                <div class="card-tools"><a class="btn btn-sm btn-outline-primary page_activator" href="<?php echo esc_url( home_url( '/crm/hr-visitors' ) ); ?>">مدیریت ویزیتورها</a></div>
            </div>
            <?php echo kph_get_template( 'partials/visitor-monthly-sales.php' ); ?>
        </div>
    </div>
</div>
<div class="nk-block">
    <div class="card card-bordered"><div class="card-inner">
        <div class="card-title-group align-center"><div class="card-title"><h6 class="title">دسترسی سریع به گزارش مشتریان</h6><p class="text-soft mb-0">مشاهده مطالبات، سررسیدها و دیرکرد مشتریان</p></div>
        <div class="card-tools"><a class="btn btn-sm btn-outline-primary page_activator" href="<?php echo esc_url( add_query_arg( 'report_view', 'customers', home_url( '/crm/reports-user' ) ) . '#customer-receivables' ); ?>">گزارش سررسید و دیرکرد مشتریان</a></div></div>
    </div></div>
</div>

<?php
// Share the existing managerial reports without changing the workdesk for other roles.
if ( get_current_user_id() && current_user_can( 'manage_options' ) ) {
    $erp_on_workdesk = true;
    require dirname( __DIR__ ) . '/partials/erp-dashboard.php';
}
?>
