<?php
if ( ! defined('ABSPATH') ) exit;
$DB = new kph_db();
$role = nooshika_get_user_role(get_current_user_id());
if ( ! in_array($role,['administrator','saff','tea','hell','nabat','zereshk','vanil'],true) ) { echo '<div class="alert alert-danger">دسترسی مجاز نیست.</div>'; return; }
$groups = $DB->get_raw_categories();
$groups = $groups['items'] ?? [];
$selected_category = absint($_REQUEST['category_id'] ?? ($groups[0]['id'] ?? 0));
$batches = $DB->get_batches_list(['page'=>1,'per_page'=>100,'category_id'=>$selected_category,'only_available'=>true]);
$open_packs = $DB->get_processing_packs_list(['page'=>1,'per_page'=>100,'category_id'=>$selected_category,'status'=>'open']);
$bulk_packs = [];
foreach (($open_packs['items'] ?? []) as $pack) {
    if ($DB->get_processing_pack_meta((int)$pack['id'],'production_mode',true) === 'bulk') {
        $pack['pack_code'] = $DB->get_processing_pack_meta((int)$pack['id'],'pack_code',true);
        $pack['remaining'] = $DB->get_processing_pack_remaining_weight((int)$pack['id']);
        $bulk_packs[] = $pack;
    }
}
?>
<div class="nk-block-head nk-block-head-sm"><div class="nk-block-between"><div><h3 class="nk-block-title page-title">سالن تولید فله</h3><p class="text-soft">برداشت مستقیم محموله از مخزن و آماده‌سازی خروجی فله برای تبدیل به محصول</p></div></div></div>
<div class="alert alert-info">این مسیر برداشت مواد را با گردش استاندارد مخزن ثبت می‌کند. پس از ایجاد بچ فله، خروجی به مرحله تبدیل محصول منتقل می‌شود تا کد تولید، وزن واحد و بهای تمام‌شده ثبت شود.</div>
<div class="card"><div class="card-inner"><h5>۱. برداشت از مخزن و ایجاد بچ فله</h5>
<form action="#" class="modal_form" data-action="kph_create_processing_pack" data-page="/crm/produce-bulk">
<input type="hidden" data-for="category_id" value="<?php echo esc_attr($selected_category); ?>"><input type="hidden" data-for="production_mode" value="bulk">
<div class="form-group"><label class="form-label">گروه مواد اولیه</label><select class="form-control" onchange="window.location.href='<?php echo esc_js(home_url('/crm/produce-bulk?category_id=')); ?>'+this.value"><?php foreach($groups as $g): ?><option value="<?php echo (int)$g['id']; ?>" <?php selected($selected_category,(int)$g['id']); ?>><?php echo esc_html($g['title']); ?></option><?php endforeach; ?></select></div>
<?php if (!empty($batches['items'])): ?><?php echo kph_get_template('partials/batch-table.php',['batches'=>$batches,'DB'=>$DB]); ?><?php else: ?><div class="alert alert-warning">در این گروه محموله دارای موجودی وجود ندارد.</div><?php endif; ?>
<div class="row mt-3"><div class="col-md-6"><label class="form-label">شناسه تولید فله</label><input class="form-control" data-for="pack_code" data-req="1" required></div><div class="col-md-6"><label class="form-label">توضیحات</label><input class="form-control" data-for="note" value="تولید فله"></div></div>
<?php if (!empty($batches['items'])): ?><div class="btn btn-primary mt-3 submit_modal_form">ثبت برداشت و ایجاد بچ فله</div><?php endif; ?>
</form></div></div>
<div class="card mt-3"><div class="card-inner"><h5>۲. بچ‌های فله آماده انتقال</h5><div class="table-responsive"><table class="table"><thead><tr><th>شناسه تولید</th><th>وزن باقی‌مانده</th><th>عملیات</th></tr></thead><tbody>
<?php if(empty($bulk_packs)): ?><tr><td colspan="3">بچ فله باز برای انتقال وجود ندارد.</td></tr><?php else: foreach($bulk_packs as $pack): ?><tr><td><?php echo esc_html($pack['pack_code']?:('#'.$pack['id'])); ?></td><td><?php echo number_format((float)$pack['remaining'],3); ?> کیلوگرم</td><td><?php $actions=['move'=>['title'=>'انتقال خروجی به مرحله تبدیل محصول','icon'=>'ni-reply-all','class'=>'row_inline_action','data'=>['action'=>'kph_transfer_pack_to_packaging','item-id'=>(int)$pack['id'],'swal-title'=>'انتقال خروجی فله به مرحله تبدیل محصول','needs'=>wp_json_encode([['type'=>'text','label'=>'وزن خروجی برای انتقال (کیلوگرم)','key'=>'qty_weight','max'=>(float)$pack['remaining']]])]]]; echo kph_get_template('components/row-actions-dropdown.php',['actions'=>$actions]); ?></td></tr><?php endforeach; endif; ?>
</tbody></table></div><p class="text-soft mb-0">پس از انتقال، برای ثبت محصول نهایی، وارد <a class="page_activator" href="<?php echo esc_url(home_url('/crm/produce-saloon')); ?>">سالن تولید</a> شوید و عملیات تبدیل به محصول فروشگاهی را با کد تولید معتبر تکمیل کنید.</p></div></div>
