(function($){
    'use strict';
    function money(v){return String(v).replace(/\B(?=(\d{3})+(?!\d))/g,',');}
    function request(button,action,extra){return $.ajax({url:window.kphData.ajax_url,method:'POST',dataType:'json',global:false,timeout:20000,data:Object.assign({action:action,account_id:button.attr('data-account-id'),nonce:button.attr('data-nonce')},extra||{})});}
    $(document).on('click','.kph-review-account-balance',function(e){
        e.preventDefault();const button=$(this);if(button.data('pending'))return;button.data('pending',true).prop('disabled',true);
        request(button,'kph_review_account_balance').done(function(result){
            if(!result||result.status!=='success'){Swal.fire({icon:'error',text:result&&result.message?result.message:'بررسی حساب انجام نشد.'});return;}
            const r=result.data;
            let text='مانده نمایش‌داده‌شده: '+money(r.stored)+' ریال\nخالص گردش‌های ثبت‌شده: '+money(r.journal)+' ریال\nتعداد گردش: '+r.count;
            if(r.reason)text+='\n'+r.reason;
            const canFix=r.different&&r.eligible;
            if(!r.different&&!r.reason)text+='\nمانده با گردش‌های ثبت‌شده یکسان است.';
            if(r.account_type==='expense')text+='\nمانده منفی حساب هزینه می‌تواند حاصل ثبت هزینه‌ها باشد و به‌تنهایی نشانه خطا نیست.';
            if(canFix)text+='\nمانده جاری با گردش‌ها تطبیق داده شود؟ تراکنش‌های اصلی حفظ می‌شوند.';
            const details=$('<div class="text-start"></div>');
            text.split('\n').forEach(function(line){details.append($('<p class="mb-1"></p>').text(line));});
            button.data('dialog',true);
            Swal.fire({titleText:'بررسی مانده «'+r.title+'»',html:details[0],icon:canFix?'warning':'info',showCancelButton:canFix,confirmButtonText:canFix?'تطبیق مانده با گردش':'بستن',cancelButtonText:'لغو'}).then(function(answer){
                if(!canFix||!answer.isConfirmed){button.data('dialog',false).data('pending',false).prop('disabled',false);return;}
                button.data('pending',true).prop('disabled',true);
                request(button,'kph_reconcile_account_balance',{token:r.token}).done(function(saved){
                    if(saved&&saved.status==='success'){
                        $('.kph-finance-account-balance').filter(function(){return $(this).attr('data-account-id')===button.attr('data-account-id');}).text(saved.data.label);
                    }
                    Swal.fire({icon:saved&&saved.status==='success'?'success':'error',text:saved&&saved.message?saved.message:'تطبیق انجام نشد.'});
                }).fail(function(){Swal.fire({icon:'error',text:'پاسخ ثبت دریافت نشد؛ دوباره مانده حساب را بررسی کنید.'});}).always(function(){button.data('dialog',false).data('pending',false).prop('disabled',false);});
            });
        }).fail(function(){Swal.fire({icon:'error',text:'ارتباط برای بررسی مانده برقرار نشد.'});}).always(function(){if(!button.data('dialog'))button.data('pending',false).prop('disabled',false);});
    });
})(jQuery);
