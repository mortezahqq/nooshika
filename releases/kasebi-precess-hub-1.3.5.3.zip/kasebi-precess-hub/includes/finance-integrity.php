<?php
if(!defined('ABSPATH'))exit;
add_action('wp_print_scripts',function(){
    if(kph_db::finance_balance_allowed()&&wp_script_is('kasebi_clinic_script','enqueued'))wp_enqueue_script('kph-finance-integrity',KPH_ASSETS_URL.'js/finance-integrity.js',['kasebi_clinic_script'],KPH_VER,true);
},20);
foreach(['kph_review_account_balance'=>'review','kph_reconcile_account_balance'=>'reconcile'] as $action=>$operation){
    add_action('nooshika_ajax_'.$action,function()use($operation){
        $id=is_scalar($_POST['account_id']??null)?absint($_POST['account_id']):0;$nonce=$_POST['nonce']??'';
        if(!kph_db::finance_balance_allowed()||!is_string($nonce)||!wp_verify_nonce($nonce,'kph_finance_balance_'.$id))wp_send_json(['status'=>'error','message'=>'دسترسی یا اعتبار درخواست بررسی حساب معتبر نیست.'],403);
        $db=new kph_db();
        if($operation==='review')wp_send_json($db->get_account_balance_review($id));
        $token=$_POST['token']??'';
        if(!is_string($token))wp_send_json(['status'=>'error','message'=>'درخواست معتبر نیست.'],400);
        wp_send_json($db->reconcile_account_balance($id,$token));
    });
}
