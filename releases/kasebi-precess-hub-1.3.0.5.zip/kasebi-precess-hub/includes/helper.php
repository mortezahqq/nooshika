<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

function kph_get_template( $path, $args = [] ) {
	ob_start();
	extract( $args );
	$role          = nooshika_get_user_role( get_current_user_id() );
	if ( $role === 'visitor' ) {
		// Enforce the same page permissions used by the navigation, including AJAX requests.
		if ( preg_match( '#^(pages|sub_page)/([^/]+)\.php$#', $path, $match ) ) {
			$pages = get_kph_pages_list();
			$single = get_kph_single_page_list();
			$key = $single[$match[2]]['parent'] ?? $match[2];
			if ( ! isset( $pages[$key] ) ) {
				foreach ( $pages as $parent => $page_info ) {
					foreach ( array_keys( $page_info['sub'] ?? [] ) as $child ) {
						if ( explode( '?', $child )[0] === $key ) { $key = $parent; break 2; }
					}
				}
			}
			$roles = $pages[$key]['valid_roles'] ?? [];
			if ( $roles !== 'all' && ! in_array( 'visitor', (array) $roles, TRUE ) ) {
				echo '<div class="alert alert-warning">اجازه دسترسی به این بخش را ندارید.</div>';
				return ob_get_clean();
			}
		}
		if ( in_array( $path, [ 'partials/order-items.php', 'partials/order-fulfillments.php', 'partials/order-fin.php' ], TRUE ) &&
			! ( new kph_db() )->visitor_can_access_order( (int) ( $args['order_id'] ?? 0 ) ) ) {
			echo '<div class="alert alert-warning">اجازه دسترسی به این سفارش را ندارید.</div>';
			return ob_get_clean();
		}
	}
	$template_path = KPH_TEMPLATE_PATH . $path;
	if ( file_exists( KPH_TEMPLATE_PATH . 'u-' . $role . '/' . $path ) ) {
		$template_path = KPH_TEMPLATE_PATH . 'u-' . $role . '/' . $path;
	}
	$template_path = apply_filters( 'kph_template_path', $template_path, $path, $args );
	include $template_path;
	
	return ob_get_clean();
}

function kph_get_user_visitor( $user_id = NULL ) {
	if ( ! $user_id ) {
		$user_id = get_current_user_id();
	}
	$marketer_id = get_user_meta( $user_id, KPH_MARKETER_META, TRUE );
	if ( ! $marketer_id ) {
		return FALSE;
	}
	
	return $marketer_id;
}

function kph_plugin_activated() {
	if ( function_exists( 'kasebi_create_new_page' ) ) {
		kasebi_create_new_page( 'crm', '[kasebi-kph]', 'مدیریت تولید' );
		kasebi_create_new_page( 'crm-login', '[kph-login]', 'ورود به پنل مدیریت تولید' );
		kasebi_create_new_page( 'crm-password', '[kph-password]', 'تغییر رمزعبور' );
	}
	kph_create_wordpress_mu_plugin();
	kph_activate_necessary_kph_ajax_plugins();
	//	kph_import_acf_jsons();
}

function kph_import_acf_jsons() {
	$json_path = KPH_PATH . 'assets/json';
	if ( function_exists( 'acf_import_field_group' ) ) {
		$path = trailingslashit( $json_path );
		if ( is_dir( $path ) ) {
			foreach ( glob( $path . '*.json' ) as $file ) {
				$json = file_get_contents( $file );
				if ( ! $json ) {
					continue;
				}
				$json = json_decode( $json, TRUE );
				foreach ( $json as $to_import ) {
					$post_type = acf_determine_internal_post_type( $to_import['key'] );
					$post      = acf_get_internal_post_type_post( $to_import['key'], $post_type );
					if ( $post ) {
						$to_import['ID'] = $post->ID;
					}
					acf_import_internal_post_type( $to_import, $post_type );
				}
			}
		}
	}
}

function kph_create_wordpress_mu_plugin() {
	$mu_plugin_dir = WPMU_PLUGIN_DIR;
	if ( ! file_exists( $mu_plugin_dir ) ) {
		mkdir( $mu_plugin_dir );
	}
	$mu_plugin_file_dec = $mu_plugin_dir . '/kph-ajax.php';
	if ( file_exists( $mu_plugin_file_dec ) ) {
		unlink( $mu_plugin_file_dec );
	}
	$mu_plugin_file = $mu_plugin_dir . '/kph-ajax.php';
	if ( ! file_exists( $mu_plugin_file ) ) {
		$mu_plugin_content = file_get_contents( KPH_TEMPLATE_PATH . 'mu-plugin/kph-ajax.php' );
		file_put_contents( $mu_plugin_file, $mu_plugin_content );
	}
}

function kph_activate_necessary_kph_ajax_plugins() {
	$necessary_plugins = [
		'kasebi-precess-hub/kasebi-precess-hub.php',
		'nooshika-main/nooshika-main.php',
		'woocommerce/woocommerce.php',
	];
	$ajax_plugins      = get_option( 'kph_ajax_active_plugins' );
	if ( ! $ajax_plugins ) {
		$ajax_plugins = [];
	}
	$ajax_plugins = array_merge( $ajax_plugins, $necessary_plugins );
	$ajax_plugins = array_unique( $ajax_plugins );
	update_option( 'kph_ajax_active_plugins', $ajax_plugins );
}

function kph_sanitize_url_for_template_path( $url ): string {
	$path = str_replace( home_url(), '', $url );
	$path = substr( $path, 1 );
	
	return untrailingslashit( $path );
}

function get_kph_page_title( $page ) {
	$pages  = get_kph_pages_list();
	$titles = [];
	foreach ( $pages as $slug => $page_data ) {
		if ( $page_data['type'] == 'page' ) {
			$titles[ $slug ] = $page_data['title'];
		}
		if ( $page_data['type'] == 'sub' ) {
			foreach ( $page_data['sub'] as $sub_slug => $sub_data ) {
				$titles[ $sub_slug ] = $sub_data['title'];
			}
		}
	}
	
	return $titles[ $page ];
}

function get_kph_end_point( $path = '' ): array {
	if ( ! $path ) {
		global $wp;
		$path = $wp->request;
	}
	$path    = ltrim( $path, '/' );
	$path    = explode( '/', $path );
	$kph_key = array_search( 'crm', $path );
	unset( $path[ $kph_key ] );
	$path = array_values( $path );
	if ( ! isset( $path[0] ) ) {
		$list        = get_kph_pages_list();
		$user_id     = get_current_user_id();
		$role        = nooshika_get_user_role( $user_id );
		$x           = array_key_first( $list );
		$valid_roles = $list[ $x ]['valid_roles'];
		if ( $valid_roles == 'all' ) {
			return [
				$x,
			];
		}
		if ( in_array( $role, $valid_roles ) ) {
			return [
				$x,
			];
		} else {
			unset( $list[ $x ] );
			$x = array_key_first( $list );
		}
		
		return [
			$x,
		];
	}
	
	return $path;
}

function get_kph_pages_list() {
	$pages = [
		'dashboard'            => [
			'type'        => 'page',
			'title'       => 'میزکار',
			'icon'        => 'dashboard',
			'valid_roles' => 'all',
		],
		'visitor-targets'      => [
			'type'        => 'page',
			'title'       => 'تارگت و پاداش من',
			'icon'        => 'growth',
			'valid_roles' => [ 'visitor' ],
		],
		'subscriber-profile'   => [
			'type'        => 'page',
			'title'       => 'اطلاعات کاربری',
			'icon'        => 'user-circle',
			'valid_roles' => [
				'subscriber',
				'supplier',
			],
		],
		'subscriber-orders'    => [
			'type'        => 'page',
			'title'       => 'سفارش ها',
			'icon'        => 'file-text',
			'valid_roles' => [
				'subscriber',
			],
		],
		'supplier-orders'      => [
			'type'        => 'page',
			'title'       => 'سفارش ها',
			'icon'        => 'file-text',
			'valid_roles' => [
				'supplier',
			],
		],
		'subscriber-financial' => [
			'type'        => 'page',
			'title'       => 'حسابداری',
			'icon'        => 'coin-alt',
			'valid_roles' => [
				'supplier',
				'subscriber',
				'visitor',
			],
		],
		'subscriber-transfers' => [
			'type'        => 'page',
			'title'       => 'حواله‌ها',
			'icon'        => 'tranx',
			'valid_roles' => [
				'supplier',
				'subscriber',
				'visitor',
			],
		],
		'subscriber-cheque'    => [
			'type'        => 'page',
			'title'       => 'چک‌ها',
			'icon'        => 'activity-round',
			'valid_roles' => [
				'supplier',
				'subscriber',
				'visitor',
			],
		],
		'subscriber-payments'  => [
			'type'        => 'page',
			'title'       => 'پرداخت‌ها',
			'icon'        => 'cc-alt2',
			'valid_roles' => [
				'supplier',
				'subscriber',
				'visitor',
			],
		],
		'divider-users'        => [
			'type'        => 'divider',
			'title'       => 'دپارتمان کاربران',
			'valid_roles' => [
				'administrator',
				'visitor',
				'supp',
				'accountant',
			],
		],
		'users'                => [
			'type'        => 'page',
			'title'       => 'مشتریان',
			'icon'        => 'users',
			'valid_roles' => [
				'administrator',
				'visitor',
				'supp',
				'accountant',
			],
		],
		'suppliers'            => [
			'type'        => 'page',
			'title'       => 'تامین‌کنندگان',
			'icon'        => 'inbox-in',
			'valid_roles' => [
				'administrator',
				'accountant',
			],
		],
		'divider-produce'      => [
			'type'        => 'divider',
			'title'       => 'دپارتمان تولید',
			'valid_roles' => [
				'administrator',
				'supp',
				'saff',
				'tea',
				'hell',
				'nabat',
				'zereshk',
				'vanil',
				'accountant',
			],
		],
		'produce-invoice'      => [
			'type'        => 'page',
			'title'       => 'فاکتورهای تامین‌',
			'icon'        => 'file-text',
			'valid_roles' => [
				'administrator',
				'accountant',
			],
		],
		'produce-repository'   => [
			'type'        => 'page',
			'title'       => 'مخزن محصولات',
			'icon'        => 'bag',
			'valid_roles' => [
				'administrator',
			],
		],
		'produce-supplies' => [
			'type'=>'page', 'title'=>'ملزومات بسته‌بندی', 'icon'=>'box', 'valid_roles'=>['administrator'],
		],
		'produce-packaging'    => [
			'type'        => 'page',
			'title'       => 'فرآوری محصولات',
			'icon'        => 'package',
			'valid_roles' => [
				'administrator',
				'saff',
				'tea',
				'hell',
				'nabat',
				'zereshk',
				'vanil',
			],
		],
		'produce-saloon'       => [
			'type'        => 'page',
			'title'       => 'سالن تولید',
			'icon'        => 'home',
			'valid_roles' => [
				'administrator',
				'saff',
				'tea',
				'hell',
				'nabat',
				'zereshk',
				'vanil',
			],
		],
		'produce-warehouse'    => [
			'type'        => 'page',
			'title'       => 'انبار محصولات',
			'icon'        => 'layers',
			'valid_roles' => [
				'administrator',
				'supp',
			],
		],
		'divider-sale'         => [
			'type'        => 'divider',
			'title'       => 'دپارتمان فروش',
			'valid_roles' => [
				'administrator',
				'visitor',
				'supp',
			],
		],
		'orders-list'          => [
			'type'        => 'sub',
			'title'       => 'لیست سفارشات',
			'icon'        => 'cart',
			'valid_roles' => [
				'administrator',
				'accountant',
				'visitor',
				'supp',
			],
			'sub'         => [
				'orders-list?status=proforma'   => [
					'type'  => 'page',
					'title' => 'پیش فاکتور',
				],
				'orders-list?status=registered' => [
					'type'  => 'page',
					'title' => 'ثبت شده',
				],
				'orders-list?status=shortage'   => [
					'type'  => 'page',
					'title' => 'دارای کسری',
				],
				'orders-list?status=shipped'    => [
					'type'  => 'page',
					'title' => 'ارسال شده',
				],
			],
		],
		'reports'              => [
			'type'        => 'sub',
			'title'       => 'گزارشات',
			'icon'        => 'bar-chart',
			'valid_roles' => [
				'administrator',
			],
			'sub'         => [
				'reports-order' => [
					'type'  => 'page',
					'title' => 'گزارش فروش',
				],
				'reports-cost'  => [
					'type'  => 'page',
					'title' => 'گزارش هزینه',
				],
				'reports-stock' => [
					'type'  => 'page',
					'title' => 'گزارش انبارها',
				],
				'reports-user'  => [
					'type'  => 'page',
					'title' => 'گزارش مشتریان',
				],
			],
		],
		'divider-finance'      => [
			'type'        => 'divider',
			'title'       => 'دپارتمان مالی',
			'valid_roles' => [
				'administrator',
				'accountant',
			],
		],
		'finance-cheque'       => [
			'type'        => 'sub',
			'title'       => 'مخزن چک',
			'icon'        => 'activity-round',
			'valid_roles' => [
				'administrator',
				'accountant',
			],
			'sub'         => [
				'finance-cheque?status=in_hand'  => [
					'type'  => 'page',
					'title' => 'چک‌های در اختیار',
				],
				'finance-cheque?status=endorsed' => [
					'type'  => 'page',
					'title' => 'چک‌های واگذارشده',
				],
				'finance-cheque?status=cleared'  => [
					'type'  => 'page',
					'title' => 'چک‌های وصول‌شده',
				],
				'finance-cheque?status=bounced'  => [
					'type'  => 'page',
					'title' => 'چک‌های برگشتی',
				],
			],
		],
		'finance-transfers'    => [
			'type'        => 'page',
			'title'       => 'حواله‌ها',
			'icon'        => 'tranx',
			'valid_roles' => [
				'administrator',
				'accountant',
			],
		],
		'finance-accounts'     => [
			'type'        => 'page',
			'title'       => 'حساب‌های مالی',
			'icon'        => 'cc-alt2',
			'valid_roles' => [
				'administrator',
				'accountant',
			],
		],
		'divider-hr'           => [
			'type'        => 'divider',
			'title'       => 'دپارتمان اداری',
			'valid_roles' => [
				'administrator',
			],
		],
		'hr-visitors'          => [
			'type'        => 'page',
			'title'       => 'ویزیتور ها',
			'icon'        => 'account-setting',
			'valid_roles' => [
				'administrator',
			],
		],
		'hr-employees'         => [
			'type'        => 'page',
			'title'       => 'منابع انسانی',
			'icon'        => 'account-setting',
			'valid_roles' => [
				'administrator',
			],
		],
		'divider-admin'        => [
			'type'        => 'divider',
			'title'       => 'مدیریت',
			'valid_roles' => [
				'administrator',
			],
		],
		'settings'             => [
			'type'        => 'sub',
			'title'       => 'تنظیمات',
			'icon'        => 'setting',
			'valid_roles' => [
				'administrator',
				'accountant',
			],
			'sub'         => [
				'settings-products' => [
					'type'  => 'page',
					'title' => 'محصولات',
				],
				'settings-other'    => [
					'type'  => 'page',
					'title' => 'سایر تنظیمات',
				],
				'settings'          => [
					'type'  => 'page',
					'title' => 'امکانات',
				],
			],
		],
	];
	
	return apply_filters( 'nooshika_kph_pages_list', $pages );
}

function get_kph_single_page_list() {
	$pages = [
		'user'                 => [
			'title'  => 'کاربر',
			'parent' => 'users',
		],
		'supplier'             => [
			'title'  => 'تامین‌کننده',
			'parent' => 'suppliers',
		],
		'order-supplier'       => [
			'title'  => 'ثبت سفارش تامین‌کننده',
			'parent' => 'produce-invoice',
		],
		'order-supplier-edit'  => [
			'title'  => 'ویرایش سفارش تامین‌کننده',
			'parent' => 'produce-invoice',
		],
		'order-customer'       => [
			'title'  => 'ثبت سفارش مشتری',
			'parent' => 'orders-list',
		],
		'order-customer-edit'  => [
			'title'  => 'ویرایش سفارش مشتری',
			'parent' => 'orders-list',
		],
		'finance-transactions' => [
			'title'  => 'تراکنش های حساب',
			'parent' => 'finance-accounts',
		],
		'inventory-log'        => [
			'title'  => 'گزارشات آیتم انبار',
			'parent' => 'produce-warehouse',
		],
		'employee'             => [
			'title'  => 'کارشناسان',
			'parent' => 'employees',
		],
	];
	
	return apply_filters( 'nooshika_kph_single_page_list', $pages );
}

function kph_page_has_filter( $args, $defaults ) {
	unset( $defaults['page_number'] );
	unset( $defaults['per_page'] );
	foreach ( $defaults as $key => $value ) {
		if ( $args[ $key ] != $value ) {
			return TRUE;
		}
	}
	
	return FALSE;
}

function kph_get_user_name_for_avatar( $user_id = NULL, $avatar = FALSE ): string {
	if ( ! $user_id ) {
		$user_id = get_current_user_id();
	}
	if ( $avatar ) {
		$key = get_user_meta( $user_id, 'nooshika_user_avatar_url', TRUE );
		if ( $key ) {
			$upload_dir = wp_upload_dir();
			
			$key = $upload_dir['baseurl'] . $key;
			
			return "<img src='$key' alt='avatar' class='avatar photo'>";
		}
	}
	$first_name = get_user_meta( $user_id, 'first_name', TRUE );
	$last_name  = get_user_meta( $user_id, 'last_name', TRUE );
	
	return mb_substr( $first_name, 0, 1 ) . "‌" . mb_substr( $last_name, 0, 1 );
}

function kph_handle_upload_file( $file, $folder ) {
	$allowed_mimes = [
		'jpg'  => 'image/jpeg',
		'jpeg' => 'image/jpeg',
		'png'  => 'image/png',
		'gif'  => 'image/gif',
		'pdf'  => 'application/pdf',
		'doc'  => 'application/msword',
		'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
		'xls'  => 'application/vnd.ms-excel',
		'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
		'txt'  => 'text/plain',
	];
	if ( ! isset( $file['tmp_name'], $file['name'], $file['type'] ) || ! file_exists( $file['tmp_name'] ) ) {
		return FALSE;
	}
	
	$filename  = $file['name'];
	$file_ext  = strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) );
	$mime_type = mime_content_type( $file['tmp_name'] );
	if ( ! isset( $allowed_mimes[ $file_ext ] ) || stripos( $mime_type, $allowed_mimes[ $file_ext ] ) === FALSE ) {
		return FALSE;
	}
	
	$upload_dir  = wp_upload_dir();
	$upload_path = $upload_dir['basedir'] . '/' . $folder;
	$upload_url  = $upload_dir['baseurl'] . '/' . $folder;
	
	if ( ! file_exists( $upload_path ) ) {
		wp_mkdir_p( $upload_path );
	}
	$base_name  = pathinfo( $filename, PATHINFO_FILENAME );
	$base_name  = preg_replace( '/[^A-Za-z0-9_\-]/', '-', $base_name );
	$saved_name = $base_name . '_' . uniqid() . '.' . $file_ext;
	$full_path  = $upload_path . '/' . $saved_name;
	$full_url   = $upload_url . '/' . $saved_name;
	
	if ( move_uploaded_file( $file['tmp_name'], $full_path ) ) {
		$DB       = new kph_db();
		$filename = $_POST['file_name'] ?? $filename;
		$DB->add_uploaded_file_record( [
			'saved_name'    => $saved_name,
			'original_name' => $filename,
			'file_path'     => str_replace( ABSPATH, '/', $full_path ),
			'file_url'      => $full_url,
		] );
		
		return $full_url;
	}
	
	return FALSE;
}

function kph_get_user_badge_color( $user_id ) {
	$user_color = get_user_meta( $user_id, 'user_color', TRUE ) ?: 'primary';
	
	return 'bg-' . $user_color;
}

function kph_get_user_total_spend( $user_id ) {
	$orders = wc_get_orders(
		[
			'customer' => $user_id,
			'status'   => 'completed',
		]
	);
	$total  = 0;
	foreach ( $orders as $order ) {
		$total += $order->get_total();
	}
	
	return $total;
}

function kph_convert_number_to_text( $number ) {
	$texts = [
		'میلیارد' => 1000000000,
		'میلیون'  => 1000000,
		'هزار'    => 1000,
	];
	foreach ( $texts as $text => $value ) {
		if ( $number >= $value ) {
			$number = $number / $value;
			$number = number_format( $number, 2 );
			$number = str_replace( '.00', '', $number );
			
			return $number . ' ' . $text;
		}
	}
	
	return $number;
}

function kph_get_all_roles( $include_admin = TRUE ) {
	$roles = [
		'administrator' => 'مدیر کل',
		'supplier'      => 'تامین‌کننده',
		'visitor'       => 'ویزیتور',
		'accountant'    => 'حسابدار',
		'supp'          => 'پشتیبانی',
		'saff'          => 'سالندار زعفران',
		'tea'           => 'سالندار چای',
		'hell'          => 'سالندار هل',
		'nabat'         => 'سالندار نبات',
		'zereshk'       => 'سالندار زرشک',
		'vanil'         => 'سالندار وانیل',
	];
	if ( ! $include_admin ) {
		unset( $roles['administrator'] );
	}
	
	return array_keys( $roles );
}

function kph_get_role_label( $role ): string {
	$roles = [
		'kph_employee' => 'پرسنل',
		'administrator' => 'مدیر کل',
		'visitor'       => 'ویزیتور',
		'accountant'    => 'حسابدار',
		'supp'          => 'پشتیبانی',
		'saff'          => 'سالندار زعفران',
		'tea'           => 'سالندار چای',
		'hell'          => 'سالندار هل',
		'nabat'         => 'سالندار نبات',
		'zereshk'       => 'سالندار زرشک',
		'vanil'         => 'سالندار وانیل',
	];
	
	return $roles[ $role ] ?? 'کاربر';
}

function kph_get_taxonomy_filter_options( $taxonomy ): array {
	return get_option( 'kph_user_taxonomy__' . $taxonomy, [] );
}

function kph_get_user_list( $search, $role = 'subscriber', $limit = 10, $offset = 0 ): array|object|null {
	global $wpdb;
	
	$search = nooshika_sanitize_numbers( $search );
	$search = remove_zero_from_phone( $search );
	$wild   = '%';
	
	$limit  = max( 1, (int) $limit );
	$offset = max( 0, (int) $offset );
	
	$role_join  = '';
	$role_where = '';
	if ( $role && $role !== 'any' ) {
		$role       = sanitize_key( (string) $role );
		$role_join  = " INNER JOIN {$wpdb->usermeta} role_meta ON role_meta.user_id = main.ID ";
		$role_where = $wpdb->prepare(
			" AND role_meta.meta_key = %s AND role_meta.meta_value LIKE %s ",
			$wpdb->get_blog_prefix() . 'capabilities',
			'%' . $wpdb->esc_like( '"' . $role . '"' ) . '%'
		);
	}
	
	if ( is_numeric( $search ) ) {
		$statement = $wild . $wpdb->esc_like( $search ) . $wild;
		
		if ( $role && $role !== 'any' ) {
			$query = $wpdb->prepare(
				"SELECT DISTINCT main.ID AS user_id
				 FROM {$wpdb->users} main
				 {$role_join}
				 INNER JOIN {$wpdb->usermeta} phone_meta ON phone_meta.user_id = main.ID
				 WHERE phone_meta.meta_key = %s
				   AND phone_meta.meta_value LIKE %s
				   {$role_where}
				 LIMIT %d OFFSET %d",
				'nooshika_phone_num',
				$statement,
				$limit,
				$offset
			);
		} else {
			$query = $wpdb->prepare(
				"SELECT DISTINCT user_id
				 FROM {$wpdb->usermeta}
				 WHERE meta_key = %s
				   AND meta_value LIKE %s
				 LIMIT %d OFFSET %d",
				'nooshika_phone_num',
				$statement,
				$limit,
				$offset
			);
		}
	} else {
		$names = separate_first_last_from_name( $search );
		$first = $wild . $wpdb->esc_like( $names['first'] ) . $wild;
		$last  = $names['last'] ? $wild . $wpdb->esc_like( $names['last'] ) . $wild : '';
		
		if ( $last ) {
			$query = $wpdb->prepare(
				"SELECT DISTINCT main.ID AS user_id
				 FROM {$wpdb->users} main
				 {$role_join}
				 INNER JOIN {$wpdb->usermeta} meta1 ON meta1.user_id = main.ID
				 INNER JOIN {$wpdb->usermeta} meta2 ON meta2.user_id = main.ID
				 WHERE (meta1.meta_key = 'first_name' AND meta1.meta_value LIKE %s)
				   AND (meta2.meta_key = 'last_name'  AND meta2.meta_value LIKE %s)
				   {$role_where}
				 LIMIT %d OFFSET %d",
				$first,
				$last,
				$limit,
				$offset
			);
		} else {
			$query = $wpdb->prepare(
				"SELECT DISTINCT main.ID AS user_id
				 FROM {$wpdb->users} main
				 {$role_join}
				 INNER JOIN {$wpdb->usermeta} meta ON meta.user_id = main.ID
				 WHERE (meta.meta_key IN ('first_name','last_name') AND meta.meta_value LIKE %s)
				   {$role_where}
				 LIMIT %d OFFSET %d",
				$first,
				$limit,
				$offset
			);
		}
	}
	
	$users = $wpdb->get_results( $query, ARRAY_A );
	
	$count_q = preg_replace( '/LIMIT\s+\d+\s+OFFSET\s+\d+/i', '', $query );
	$count_q = preg_replace( '/^SELECT\s+DISTINCT\s+.*?\s+AS\s+user_id/i', 'SELECT COUNT(DISTINCT main.ID)', $count_q );
	$total   = (int) $wpdb->get_var( $count_q );
	
	if ( ! $users ) {
		$search = $wpdb->esc_like( strip_tags( $_POST['search'] ?? '' ) );
		
		$query = $wpdb->prepare(
			"SELECT DISTINCT main.ID AS user_id
			 FROM {$wpdb->users} main
			 {$role_join}
			 WHERE main.display_name LIKE %s
			   {$role_where}
			 LIMIT %d OFFSET %d",
			'%' . $search . '%',
			$limit,
			$offset
		);
		
		$users = $wpdb->get_results( $query, ARRAY_A );
		
		$count_q = preg_replace( '/LIMIT\s+\d+\s+OFFSET\s+\d+/i', '', $query );
		$count_q = preg_replace( '/^SELECT\s+DISTINCT\s+main\.ID\s+AS\s+user_id/i', 'SELECT COUNT(DISTINCT main.ID)', $count_q );
		$total   = (int) $wpdb->get_var( $count_q );
	}
	
	if ( $total ) {
		return [
			'users' => $users,
			'total' => $total,
		];
	}
	
	return $users;
}

function kph_get_user_meta_keys() {
	$DB     = new kph_db();
	$intros = $DB->get_introduce_methods();
	
	return [
		'first_name'         => [
			'label'    => 'نام',
			'required' => TRUE,
		],
		'last_name'          => [
			'label'    => 'نام خانوادگی',
			'required' => TRUE,
		],
		'birthday'           => [
			'type'     => 'date',
			'label'    => 'تاریخ تولد',
			'editable' => 'once',
			'required' => TRUE,
		],
		'gender'             => [
			'type'     => 'select',
			'label'    => 'جنسیت',
			'options'  => [
				'male'   => [
					'label' => 'مرد',
				],
				'female' => [
					'label' => 'زن',
				],
				'other'  => [
					'label' => 'سایر',
				],
			],
			'required' => TRUE,
			'editable' => 'once',
		],
		'education'          => [
			'label' => 'تحصیلات',
		],
		'nooshika_phone_num' => [
			'label'    => 'شماره همراه',
			'editable' => FALSE,
		],
		'email'              => [
			'label' => 'ایمیل',
		],
		'telephone_number'   => [
			'label' => 'شماره تماس ثابت',
		],
		'intro_method'       => [
			'type'    => 'select',
			'label'   => 'ارجاع دهنده',
			'options' => $intros,
		],
		'address'            => [
			'label'    => 'آدرس',
			'width'    => '100%',
			'required' => TRUE,
		],
	];
}

function kph_user_has_filled_required_meta( int $user_id ): bool {
	if ( $user_id <= 0 ) {
		return FALSE;
	}
	
	$meta_keys = kph_get_user_meta_keys();
	
	foreach ( $meta_keys as $meta_key => $args ) {
		if ( empty( $args['required'] ) ) {
			continue;
		}
		
		$value = get_user_meta( $user_id, $meta_key, TRUE );
		
		if ( is_array( $value ) ) {
			if ( empty( $value ) ) {
				return FALSE;
			}
		} else {
			if ( trim( (string) $value ) === '' ) {
				return FALSE;
			}
		}
	}
	
	return TRUE;
}

function kph_meta_is_visible( array $meta, $user_id ): bool {
	if ( empty( $meta['state'] ) || $meta['state'] !== 'conditional' ) {
		return TRUE;
	}
	$cond     = $meta['conditions'] ?? [];
	$meta_key = $cond['meta'] ?? '';
	if ( $meta_key === '' ) {
		return TRUE;
	}
	$expected = $cond['value'] ?? NULL;        // string|array|null
	$operator = $cond['operator'] ?? '==';
	$actual   = get_user_meta( $user_id, $meta_key, TRUE );
	
	$is_match = is_array( $expected ) ? in_array( $actual, $expected, TRUE ) : ( $actual === $expected );
	
	return ( $operator === '!=' ) ? ! $is_match : $is_match;
}

function get_woocommerce_products_id_title(): array {
	$posts = get_posts( [
		'post_type'        => 'product',
		'post_status'      => 'publish',
		'numberposts'      => - 1,
		'fields'           => 'ids', // فقط ID بگیر برای سبک بودن
		'suppress_filters' => FALSE,
	] );
	
	if ( empty( $posts ) ) {
		return [];
	}
	
	$products = [];
	
	foreach ( $posts as $product_id ) {
		$products[] = [
			'id'    => (int) $product_id,
			'title' => get_the_title( $product_id ),
		];
	}
	
	return $products;
}

function kph_handle_print_request(): void {
	$type = isset( $_GET['type'] ) ? sanitize_key( $_GET['type'] ) : '';
	
	if ( ! $type ) {
		wp_die( 'نوع پرینت مشخص نشده است.' );
	}
	
	$template = KPH_TEMPLATE_PATH . 'prints/' . $type . '.php';
	
	if ( ! file_exists( $template ) ) {
		wp_die( 'تمپلیت پرینت یافت نشد: ' . esc_html( $type ) );
	}
	
	$args = [
		'type'    => $type,
		'ids'     => kph_get_print_ids_from_request(),
		'user_id' => isset( $_GET['user_id'] ) ? absint( $_GET['user_id'] ) : 0,
		'date'    => kph_get_print_date_range_from_request(),
		'request' => $_GET,
	];
	
	nocache_headers();
	status_header( 200 );
	
	echo kph_get_print_template( $type, $args );
	exit;
}

function kph_get_print_template( string $type, array $args = [] ): string {
	$type = sanitize_key( $type );
	if ( nooshika_get_user_role( get_current_user_id() ) === 'visitor' ) {
		$print_db = new kph_db();
		if ( in_array( $type, [ 'factor', 'c-factor', 'order-items', 'fulfillments', 'preparation-list' ], TRUE ) ) {
			$print_ids = $type === 'fulfillments' ? [ (int) ( $args['request']['order_id'] ?? 0 ) ] : ( $args['ids'] ?? [] );
			if ( ! $print_ids ) { wp_die( 'اجازه دسترسی به این سفارش را ندارید.', '', [ 'response' => 403 ] ); }
			foreach ( $print_ids as $print_id ) {
				if ( ! $print_db->visitor_can_access_order( (int) $print_id ) ) { wp_die( 'اجازه دسترسی به این سفارش را ندارید.', '', [ 'response' => 403 ] ); }
			}
		} elseif ( ! in_array( $type, [ 'financial', 'payments', 'transfers', 'cheques' ], TRUE ) ||
			(int) ( $args['user_id'] ?? 0 ) !== (int) get_current_user_id() || ! empty( $args['ids'] ) ) {
			wp_die( 'اجازه دسترسی به این گزارش را ندارید.', '', [ 'response' => 403 ] );
		}
	}
	
	if ( ! $type ) {
		return '';
	}
	
	ob_start();
	extract( $args );
	
	$template_path = KPH_TEMPLATE_PATH . 'prints/' . $type . '.php';
	$template_path = apply_filters( 'kph_print_template_path', $template_path, $type, $args );
	
	if ( file_exists( $template_path ) ) {
		include $template_path;
	}
	
	return ob_get_clean();
}

function kph_get_print_ids_from_request(): array {
	$ids = $_GET['ids'] ?? '';
	
	if ( is_array( $ids ) ) {
		$ids = implode( ',', $ids );
	}
	
	$ids = explode( ',', (string) $ids );
	$ids = array_map( 'absint', $ids );
	$ids = array_filter( $ids );
	$ids = array_values( array_unique( $ids ) );
	
	return $ids;
}

function kph_get_print_date_range_from_request(): array {
	$date = $_GET['date'] ?? '';
	
	$from = '';
	$to   = '';
	
	if ( is_string( $date ) && str_contains( $date, '...' ) ) {
		$parts = explode( '...', $date );
		$from  = trim( $parts[0] ?? '' );
		$to    = trim( $parts[1] ?? '' );
	}
	
	if ( isset( $_GET['date_from'] ) ) {
		$from = trim( sanitize_text_field( $_GET['date_from'] ) );
	}
	
	if ( isset( $_GET['date_to'] ) ) {
		$to = trim( sanitize_text_field( $_GET['date_to'] ) );
	}
	
	return [
		'from' => $from,
		'to'   => $to,
	];
}

function kph_print_user_name( int $user_id ): string {
	if ( $user_id <= 0 ) {
		return '-';
	}
	
	$first_name = get_user_meta( $user_id, 'first_name', TRUE );
	$last_name  = get_user_meta( $user_id, 'last_name', TRUE );
	$name       = trim( $first_name . ' ' . $last_name );
	
	if ( ! $name ) {
		$user = get_userdata( $user_id );
		$name = $user ? $user->display_name : '';
	}
	
	return $name ?: 'کاربر #' . $user_id;
}

function kph_print_money( $amount ): string {
	return number_format( (float) $amount );
}

function kph_print_date( $date ): string {
	if ( empty( $date ) ) {
		return '-';
	}
	
	return date_i18n( 'Y/m/d', strtotime( $date ) );
}
