<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$per_page_key    = basename( __FILE__, '.php' );
$per_page_key    = "kph_{$per_page_key}_per_page";
$current_user_id = get_current_user_id();

$defaults = [
	'page_number' => 1,
	'per_page'    => get_user_meta( $current_user_id, $per_page_key, TRUE ) ?: 20,
	'date'        => [
		'from' => '',
		'to'   => '',
	],
	'cost'           => '',
	'secondary_cost' => '',
	'account_id'     => '',
	'search'         => '',
];

$args = wp_parse_args( $_REQUEST, $defaults );

foreach ( $args as $key => $value ) {
	if ( ! is_array( $value ) && $value == 0 ) {
		$args[ $key ] = '';
	}
}

$has_filter = kph_page_has_filter( $args, $defaults );

extract( $args );

$cost           = sanitize_key( (string) $cost );
$secondary_cost = sanitize_text_field( wp_unslash( (string) $secondary_cost ) );

update_user_meta( $current_user_id, $per_page_key, $per_page );

$date_from = $date['from'] ?? '';
$date_to   = $date['to'] ?? '';

$date_from_g = $date_from ? nooshika_jalali_to_gregorian( $date_from ) : '';
$date_to_g   = $date_to ? nooshika_jalali_to_gregorian( $date_to ) : '';

$DB = new kph_db();

$cost_types = get_option( 'kph_cost_category', [] );
$cost_types = is_array( $cost_types ) ? $cost_types : [];

$secondary_cost_types = get_option( 'kph_cost_secondary_category', [] );
$secondary_cost_types = is_array( $secondary_cost_types ) ? $secondary_cost_types : [];

$accounts_result = $DB->get_accounts( [
	'per_page' => 100,
	'status'   => 'active',
	'orderby'  => 'title',
	'order'    => 'ASC',
] );

$accounts = $accounts_result['items'] ?? [];

$account_options = [ 0 => 'همه حساب‌ها' ];
foreach ( $accounts as $account ) {
	$account_options[ $account['id'] ] = $account['title'];
}

$cost_options = [ 0 => 'همه دسته‌بندی‌ها' ];
foreach ( $cost_types as $key => $item ) {
	$cost_options[ $key ] = $item['label'] ?? $key;
}
$cost_options['uncategorized'] = 'بدون دسته‌بندی';

$secondary_cost_options = [ 0 => 'همه دسته‌بندی‌های ثانویه' ];
foreach ( $secondary_cost_types as $key => $item ) {
	$secondary_cost_options[ $key ] = $item['label'] ?? $key;
}

$filtered_cost_types = NULL;
if ( $secondary_cost !== '' ) {
	$filtered_cost_types = [];
	foreach ( $cost_types as $key => $item ) {
		if ( ( $item['secondary_category'] ?? '' ) === $secondary_cost ) {
			$filtered_cost_types[] = $key;
		}
	}
}

$category_report = $DB->get_cost_categories_report( [
	'date_from'  => $date_from_g,
	'date_to'    => $date_to_g,
	'account_id' => $account_id,
	'search'     => $search,
	'cost_types' => $filtered_cost_types,
] );

$detail_report = $DB->get_cost_transactions_report( [
	'date_from'  => $date_from_g,
	'date_to'    => $date_to_g,
	'cost_type'  => $cost,
	'account_id' => $account_id,
	'search'     => $search,
	'cost_types' => $filtered_cost_types,
	'page'       => $page_number,
	'per_page'   => $per_page,
] );

$summary        = $category_report['summary'];
$category_items = $category_report['items'];

$transactions = $detail_report['items'];
$total_page   = $detail_report['pagination']['total_page'];
$total_items  = $detail_report['pagination']['total'];

if ( ! function_exists( 'kph_report_cost_label' ) ) {
	function kph_report_cost_label( string $key, array $cost_types ): string {
		if ( $key === 'uncategorized' ) {
			return 'بدون دسته‌بندی';
		}
		
		return $cost_types[ $key ]['label'] ?? $key;
	}
}

if ( ! function_exists( 'kph_report_cost_secondary_label' ) ) {
	function kph_report_cost_secondary_label( string $cost_key, array $cost_types, array $secondary_cost_types ): string {
		$secondary_key = $cost_types[ $cost_key ]['secondary_category'] ?? '';
		
		return $secondary_key !== ''
			? ( $secondary_cost_types[ $secondary_key ]['label'] ?? $secondary_key )
			: 'بدون دسته‌بندی ثانویه';
	}
}

if ( ! function_exists( 'kph_report_cost_date' ) ) {
	function kph_report_cost_date( $date ): string {
		if ( empty( $date ) ) {
			return '-';
		}
		
		return date_i18n( 'Y/m/d', strtotime( $date ) );
	}
}

if ( ! function_exists( 'kph_report_cost_print_link' ) ) {
	function kph_report_cost_print_link( string $section, array $params = [] ): string {
		return add_query_arg(
			array_filter(
				array_merge( [
					'action'  => 'print',
					'type'    => 'cost',
					'section' => sanitize_key( $section ),
				], $params ),
				static function( $value ) {
					return $value !== '' && $value !== 0;
				}
			),
			home_url( '/crm' )
		);
	}
}

if ( ! function_exists( 'kph_report_cost_print_button' ) ) {
	function kph_report_cost_print_button( string $section, array $params = [] ): string {
		return sprintf(
			'<a href="%s" target="_blank" rel="noopener" class="btn btn-sm btn-icon btn-outline-primary ms-1" title="پرینت جدول"><em class="icon ni ni-printer"></em></a>',
			esc_url( kph_report_cost_print_link( $section, $params ) )
		);
	}
}

$cost_print_filters = [
	'date_from'      => $date_from,
	'date_to'        => $date_to,
	'cost'           => $cost,
	'secondary_cost' => $secondary_cost,
	'account_id'     => absint( $account_id ),
	'search'         => sanitize_text_field( (string) $search ),
];

$selected_cost_label = $cost
	? kph_report_cost_label( $cost, $cost_types )
	: 'همه دسته‌بندی‌ها';

?>
    <div class="nk-block-head nk-block-head-sm">
        <div class="nk-block-between">
            <div class="nk-block-head-content">
                <h3 class="nk-block-title page-title">گزارش هزینه‌ها</h3>
                <div class="nk-block-des text-soft">
                    <p class="mb-0">گزارش مصرف هزینه‌ها به تفکیک دسته‌بندی و ریز تراکنش‌های هر دسته.</p>
                </div>
            </div>

            <div class="card-tools">
                <ul class="btn-toolbar gx-1">
                    <li>
						<?php
						$filter_fields = [
							[
								'type'  => 'date-range',
								'label' => 'بازه گزارش',
								'name'  => 'date',
								'value' => [
									'from' => $date_from ?? '',
									'to'   => $date_to ?? '',
								],
							],
							[
								'type'    => 'select',
								'label'   => 'دسته‌بندی هزینه',
								'name'    => 'cost',
								'value'   => $cost,
								'col'     => 6,
								'options' => $cost_options,
							],
							[
								'type'    => 'select',
								'label'   => 'دسته‌بندی ثانویه',
								'name'    => 'secondary_cost',
								'value'   => $secondary_cost,
								'col'     => 6,
								'options' => $secondary_cost_options,
							],
							[
								'type'    => 'select',
								'label'   => 'حساب',
								'name'    => 'account_id',
								'value'   => $account_id,
								'col'     => 6,
								'options' => $account_options,
							],
						];
						
						echo kph_get_template( 'components/filter-dropdown.php', [
							'has_filter'    => $has_filter,
							'filter_fields' => $filter_fields,
						] );
						?>
                    </li>

                    <li class="btn-toolbar-sep"></li>

                    <li>
						<?php
						echo kph_get_template( 'components/per-page-selector.php', [
							'per_page' => $per_page,
						] );
						?>
                    </li>
                </ul>
            </div>
        </div>
    </div>

    <div class="nk-block">
        <div class="row g-gs">
            <div class="col-md-3">
                <div class="card card-full">
                    <div class="card-inner">
                        <h6 class="title">جمع هزینه‌ها</h6>
                        <div class="amount text-danger">
							<?php echo number_format( $summary['total_amount'] ); ?>
                            <small class="currency currency-usd fs-12px">ریال</small>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card card-full">
                    <div class="card-inner">
                        <h6 class="title">تعداد تراکنش</h6>
                        <div class="amount">
							<?php echo number_format( $summary['total_count'] ); ?>
                            <small class="currency currency-usd fs-12px">مورد</small>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card card-full">
                    <div class="card-inner">
                        <h6 class="title">تعداد دسته‌بندی</h6>
                        <div class="amount">
							<?php echo number_format( $summary['total_categories'] ); ?>
                            <small class="currency currency-usd fs-12px">دسته</small>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card card-full">
                    <div class="card-inner">
                        <h6 class="title">میانگین هر هزینه</h6>
                        <div class="amount">
							<?php echo number_format( $summary['avg_per_transaction'] ); ?>
                            <small class="currency currency-usd fs-12px">ریال</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php
if ( $cost ) {
	?>
    <div class="nk-block">
        <div class="card card-stretch">
            <div class="card-inner position-relative card-tools-toggle">
                <div class="card-title-group">
                    <div class="card-tools">
                        <h6 class="title mb-0">
                            ریز هزینه‌ها - <?php echo esc_html( $selected_cost_label ); ?>
							<?php echo kph_report_cost_print_button( 'detail', $cost_print_filters ); ?>
                        </h6>
                        <span class="sub-text">تعداد نتیجه: <?php echo number_format( $total_items ); ?></span>
                    </div>
                </div>
            </div>

            <div class="card-inner p-0 overflow-auto">
                <div class="nk-tb-list nk-tb-ulist is-compact">
                    <div class="nk-tb-item nk-tb-head">
                        <div class="nk-tb-col"><span class="sub-text">تاریخ</span></div>
                        <div class="nk-tb-col"><span class="sub-text">دسته‌بندی</span></div>
                        <div class="nk-tb-col"><span class="sub-text">دسته‌بندی ثانویه</span></div>
                        <div class="nk-tb-col"><span class="sub-text">حساب</span></div>
                        <div class="nk-tb-col"><span class="sub-text">مقصد / بابت</span></div>
                        <div class="nk-tb-col"><span class="sub-text">مبلغ</span></div>
                        <div class="nk-tb-col"><span class="sub-text">توضیحات</span></div>
                        <div class="nk-tb-col text-end nk-tb-col-tools"></div>
                    </div>
					
					<?php
					if ( empty( $transactions ) ) {
						echo '<div class="no-item-found">هزینه‌ای یافت نشد</div>';
					} else {
						foreach ( $transactions as $entry ) {
							$attachment = trim( (string) $entry['attachment'] );
							?>
                            <div class="nk-tb-item">
                                <div class="nk-tb-col">
                                    <span><?php echo kph_report_cost_date( $entry['created_at'] ); ?></span>
                                </div>

                                <div class="nk-tb-col">
                                <span class="badge badge-dot bg-danger">
									<?php echo esc_html( kph_report_cost_label( $entry['cost_type'], $cost_types ) ); ?>
                                </span>
                                </div>

                                <div class="nk-tb-col">
                                    <span><?php echo esc_html( kph_report_cost_secondary_label( $entry['cost_type'], $cost_types, $secondary_cost_types ) ); ?></span>
                                </div>

                                <div class="nk-tb-col">
                                    <span><?php echo esc_html( $entry['account_title'] ?: '-' ); ?></span>
                                </div>

                                <div class="nk-tb-col">
                                    <span><?php echo esc_html( $entry['destination'] ?: '-' ); ?></span>
                                </div>

                                <div class="nk-tb-col">
                                    <div class="amount text-danger">
                                        <span><?php echo number_format( $entry['amount'] ); ?></span>
                                        <em class="icon ni ni-arrow-long-down"></em>
                                    </div>
                                </div>

                                <div class="nk-tb-col">
                                    <span><?php echo wp_kses_post( $entry['description'] ?: '-' ); ?></span>
                                </div>

                                <div class="nk-tb-col nk-tb-col-tools">
                                    <ul class="nk-tb-actions gx-2">
										<?php if ( $attachment ) { ?>
                                            <li>
                                                <a href="<?php echo esc_url( $attachment ); ?>"
                                                   target="_blank"
                                                   class="btn btn-sm btn-icon btn-trigger"
                                                   data-bs-toggle="tooltip"
                                                   data-bs-original-title="دانلود ضمیمه">
                                                    <em class="icon ni ni-download"></em>
                                                </a>
                                            </li>
										<?php } ?>
                                    </ul>
                                </div>
                            </div>
							<?php
						}
					}
					?>
                </div>
            </div>

            <div class="card-inner">
				<?php
				echo kph_get_template( 'components/pagination.php', [
					'max_page_num' => $total_page,
					'current_page' => $page_number,
					'class_name'   => 'reports_cost_pagination_link',
					'show_count'   => 2,
				] );
				?>
            </div>
        </div>
    </div>
	<?php
} else {
	?>
    <div class="nk-block">
        <div class="card card-stretch">
            <div class="card-inner position-relative card-tools-toggle">
                <div class="card-title-group">
                    <div class="card-tools">
                        <h6 class="title mb-0">
							مصرف هزینه بر اساس دسته‌بندی
							<?php echo kph_report_cost_print_button( 'categories', $cost_print_filters ); ?>
						</h6>
                    </div>

                    <div class="card-tools">
                        <div class="form-inline flex-nowrap gx-3">
                            <div class="form-wrap">
                                <input type="text"
                                       class="form-control form-control-sm search_kph_list"
                                       value="<?php echo esc_attr( $search ); ?>"
                                       placeholder="جستجوی توضیحات، حساب، مقصد...">
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card-inner p-0 overflow-auto">
                <div class="nk-tb-list nk-tb-ulist is-compact">
                    <div class="nk-tb-item nk-tb-head">
                        <div class="nk-tb-col"><span class="sub-text">دسته‌بندی</span></div>
                        <div class="nk-tb-col"><span class="sub-text">دسته‌بندی ثانویه</span></div>
                        <div class="nk-tb-col"><span class="sub-text">تعداد تراکنش</span></div>
                        <div class="nk-tb-col"><span class="sub-text">مبلغ هزینه</span></div>
                        <div class="nk-tb-col"><span class="sub-text">میانگین</span></div>
                        <div class="nk-tb-col"><span class="sub-text">سهم از کل</span></div>
                        <div class="nk-tb-col"><span class="sub-text">آخرین ثبت</span></div>
                        <div class="nk-tb-col text-end nk-tb-col-tools"></div>
                    </div>
					
					<?php
					if ( empty( $category_items ) ) {
						echo '<div class="no-item-found">گزارشی یافت نشد</div>';
					} else {
						foreach ( $category_items as $item ) {
							$cost_type_key = $item['cost_type'];
							?>
                            <div class="nk-tb-item">
                                <div class="nk-tb-col">
                                <span class="tb-lead">
									<?php echo esc_html( kph_report_cost_label( $cost_type_key, $cost_types ) ); ?>
                                </span>
                                    <span class="sub-text"><?php echo esc_html( $cost_type_key ); ?></span>
                                </div>

                                <div class="nk-tb-col">
                                    <span><?php echo esc_html( kph_report_cost_secondary_label( $cost_type_key, $cost_types, $secondary_cost_types ) ); ?></span>
                                </div>

                                <div class="nk-tb-col">
                                    <span><?php echo number_format( $item['transaction_count'] ); ?></span>
                                </div>

                                <div class="nk-tb-col">
                                <span class="tb-amount text-danger">
									<?php echo number_format( $item['total_amount'] ); ?>
                                </span>
                                </div>

                                <div class="nk-tb-col">
                                    <span><?php echo number_format( $item['avg_amount'] ); ?></span>
                                </div>

                                <div class="nk-tb-col">
                                    <span><?php echo esc_html( $item['percent'] ); ?>٪</span>
                                </div>

                                <div class="nk-tb-col">
                                    <span><?php echo kph_report_cost_date( $item['last_transaction_at'] ); ?></span>
                                </div>

                                <div class="nk-tb-col nk-tb-col-tools">
                                    <ul class="nk-tb-actions gx-2">
										<?php
										echo kph_get_template( 'components/row-actions-hidden.php', [
											'actions' => [
												[
													'link'  => add_query_arg(
														array_filter( [
															'cost'           => $cost_type_key,
															'secondary_cost' => $secondary_cost,
														] ),
														'/crm/reports-cost'
													),
													'title' => 'نمایش ریز هزینه‌ها',
													'icon'  => 'ni-list-thumb',
													'class' => 'page_activator',
												],
											],
										] );
										?>
                                    </ul>
                                </div>
                            </div>
							<?php
						}
					}
					?>
                </div>
            </div>
        </div>
    </div>
	<?php
}

