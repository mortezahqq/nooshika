<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

$category_role_map = [
	1 => 'saff',
	2 => 'zereshk',
	3 => 'tea',
	4 => 'hell',
	5 => 'nabat',
	7 => 'vanil',
];
$role              = nooshika_get_user_role( get_current_user_id() );

$DB              = new kph_db();
$supplier_groups = $DB->get_raw_categories();
$supplier_groups = $supplier_groups['items'];
if ( in_array( $role, $category_role_map, TRUE ) ) {
	$supplier_groups = array_values(
		array_filter(
			$supplier_groups,
			static function( array $group ) use ( $category_role_map, $role ): bool {
				$category_id = (int) ( $group['id'] ?? 0 );
				
				return isset( $category_role_map[ $category_id ] )
				       && $category_role_map[ $category_id ] === $role;
			}
		)
	);
}
$default_category = $supplier_groups[0] ?? FALSE;
$per_page_key     = basename( __FILE__, '.php' );
$per_page_key     = "kph_{$per_page_key}_per_page";
$user_id          = get_current_user_id();
$defaults         = [
	'category_id' => $default_category ? $default_category['id'] : '',
	'page_number' => 1,
	'per_page'    => get_user_meta( $user_id, $per_page_key, TRUE ) ?: 20,
	'status'      => 'in_packaging',
	'date'        => [
		'from' => '',
		'to'   => '',
	],
];
$args             = wp_parse_args( $_REQUEST, $defaults );
$args             = array_map( fn( $v ) => $v == 0 ? '' : $v, $args );
$has_filter       = kph_page_has_filter( $args, $defaults );
extract( $args );
update_user_meta( $user_id, $per_page_key, $per_page );
$date_from = $date['from'] ?? '';
$date_to   = $date['to'] ?? '';

$packs             = $DB->get_packaging_lots_in_packaging( [
	'page'        => $page_number,
	'per_page'    => $per_page,
	'category_id' => $category_id,
	'status'      => $status,
] );
$total_page        = $packs['pagination']['total_page'];
$total_items       = $packs['pagination']['total'];
$packs             = $packs['items'];
$statuses          = $DB->get_processing_lot_statuses();
$selected_category = $DB->get_raw_category( $category_id );
$date_from         = $date_from ? nooshika_jalali_to_gregorian( $date_from ) : NULL;
$date_to           = $date_to ? nooshika_jalali_to_gregorian( $date_to ) : NULL;
$summery           = $DB->get_packaging_hall_summary( $category_id, $date_from, $date_to );
$products          = get_woocommerce_products_id_title();
?>
<?php echo kph_get_template( 'components/workflow-tools.php', [ 'DB' => $DB ] ); ?>
<div class="nk-block-head nk-block-head-sm">
    <div class="nk-block-between">
        <div class="nk-block-head-content">
            <h3 class="nk-block-title page-title">سالن تولید</h3>
        </div>
        <div class="nk-block-head-content">
            <div class="drodown">
                <a href="#" class="dropdown-toggle btn btn-outline-info btn-dim"
                   data-bs-toggle="dropdown" aria-expanded="true">
                    <span><?php echo $selected_category['item']['title']; ?></span>
                    <em class="icon ni ni-chevron-down"></em>
                </a>
                <div class="dropdown-menu dropdown-menu-end " data-popper-placement="bottom-start">
                    <ul class="link-list-opt no-bdr">
						<?php
						foreach ( $supplier_groups as $data ) {
							?>
                            <li>
                                <a class="page_activator"
                                   href="<?php echo home_url( "/crm/produce-saloon?category_id={$data['id']}" ); ?>"
                                   data-url="<?php echo "/crm/produce-saloon?category_id={$data['id']}"; ?>">
                                    <span><?php echo $data['title']; ?></span>
                                </a>
                            </li>
							<?php
						}
						?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="nk-block">
    <div class="card card-stretch">
        <div class="card-inner-group">
            <div class="card-inner position-relative card-tools-toggle">
                <div class="card-title-group">
                    <div class="card-tools">
                    </div>
                    <div class="card-tools">
                        <ul class="btn-toolbar gx-1">
							<?php
							foreach ( $statuses as $slug => $data ) {
								$class = 'btn-' . $data['class'];
								if ( $slug != $status ) {
									$class .= ' btn-dim';
								}
								?>
                                <li>
                                    <div
                                        data-url="/crm/produce-saloon?status=<?php echo $slug . "&category_id={$category_id}"; ?>"
                                        class="page_activator btn <?php echo $class; ?>"><?php echo $data['label']; ?></div>
                                </li>
								<?php
							}
							?>
                            <li class="btn-toolbar-sep"></li>
                            <li>
								<?php
								echo kph_get_template( 'components/per-page-selector.php', [
									'per_page' => $per_page,
								] );
								?>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="card-inner p-0">
                <div class="nk-tb-list nk-tb-ulist is-compact">
                    <div class="nk-tb-item nk-tb-head">
                        <div class="nk-tb-col"><span class="sub-text">کد فرآوری</span></div>
                        <div class="nk-tb-col"><span class="sub-text">تاریخ انتقال به سالن</span></div>
                        <div class="nk-tb-col"><span class="sub-text">وزن باقی مانده در سالن</span></div>
                        <div class="nk-tb-col"><span class="sub-text">قیمت هر کیلو</span></div>
                        <div class="nk-tb-col text-end nk-tb-col-tools"></div>
                    </div>
					<?php
					if ( empty( $packs ) ) {
						echo '<div class="no-item-found">آیتمی یافت نشد</div>';
					} else {
						foreach ( $packs as $entry ) {
							$pack_id        = $entry['processing_pack_id'];
							$pack_code      = $DB->get_processing_pack_meta( $pack_id, 'pack_code', TRUE );
							$remaining      = number_format( $entry['remaining_weight'], 5, '.', '' );
							$initial_weight = $entry['input_qty_weight'];
							$wastes         = $entry['total_waste'];
							$total_valid    = $initial_weight - $wastes;
							$avg            = $entry['avg_unit_cost'];
							$new_avg        = ( $avg * $initial_weight ) / $total_valid;
							
							?>
                            <div class="nk-tb-item">
                                <div class="nk-tb-col text-dark"><?php echo $pack_code; ?></div>
                                <div class="nk-tb-col">
                                    <div
                                        class="sub-text"><?php echo date_i18n( 'Y-m-d', strtotime( $entry['created_at'] ) ); ?></div>
                                    <div class="sub-text"><?php echo date_i18n( 'h:i', strtotime(
											$entry['created_at'] ) ); ?></div>
                                </div>
                                <div class="nk-tb-col">
                                    <span><?php echo $remaining; ?></span>
                                </div>
                                <div class="nk-tb-col">
                                    <span><?php echo number_format( $new_avg ); ?></span>
                                </div>
                                <div class="nk-tb-col nk-tb-col-tools">
                                    <ul class="nk-tb-actions gx-2">
										<?php
										$rate    = ( $month > 0 ) ? number_format( $base_price * $rate * $month / 100 ) : 'نقدی';
										$actions = [
											[
												'link'  => '',
												'title' => 'وزن اولیه: ' . number_format( (float) $entry['input_qty_weight'], 5, '.', '' ),
												'icon'  => 'ni-opt-alt',
											],
										];
										if ( $entry['total_waste'] > 0 ) {
											$actions[] = [
												'link'  => '',
												'title' => 'وزن هدررفت: ' . number_format( (float) $entry['total_waste'],
														5, '.', '' ),
												'icon'  => 'ni-trash-alt',
											];
										}
										echo kph_get_template( 'components/row-actions-hidden.php', [
											'actions' => $actions,
										] );
										?>
                                        <li>
											<?php
											$actions = [
												'waste'   => [
													'title' => 'ثبت هدررفت',
													'icon'  => 'ni-trash-alt',
													'class' => 'row_inline_action',
													'data'  => [
														'action'      => 'kph_submit_wasted_packaging_lot',
														'item-id'     => $entry['id'],
														'swal-title'  => 'ثبت هدررفت',
														'category_id' => $category_id,
														'needs'       => json_encode( [
															[
																'type'  => 'text',
																'label' => 'وزن هدررفت را به گرم وارد کنید.',
																'key'   => 'wasted_weight',
																'max'   => $remaining * 1000,
															],
														] ),
													],
												],
												'return'  => [
													'title' => 'بازگشت به مخزن',
													'icon'  => 'ni-curve-up-left',
													'class' => 'row_inline_action',
													'data'  => [
														'action'      => 'kph_return_lot_to_processing',
														'item-id'     => $entry['id'],
														'swal-title'  => 'بازگشت از سالن تولید',
														'category_id' => $category_id,
														'needs'       => json_encode( [
															[
																'type'  => 'text',
																'label' => 'وزن بازگشتی را به کیلوگرم وارد کنید.',
																'key'   => 'qty_weight',
																'max'   => $remaining,
															],
														] ),
													],
												],
												'product' => [
													'title' => 'تبدیل به محصول',
													'icon'  => 'ni-package',
													'class' => 'populate_modal_inputs',
													'data'  => [
														'modal' => '#convertLotToProduct',
														'set'   => esc_attr( wp_json_encode(
															[
																'#new_conversion_lot_id'      => $entry['id'],
																'#max_conversion_weight'      => $remaining * 1000,
																'#new_conversion_category_id' => $category_id,
															]
														) ),
													],
												],
												'divider' => [
													'divider' => TRUE,
												],
												[
													'link'  => '',
													'title' => 'گزارشات اقدامات سالن',
													'class' => 'load_item_data_to_modal',
													'icon'  => 'ni-check-round-cut',
													'data'  => [
														'item-id' => $entry['id'],
														'action'  => 'kph_load_lot_moves',
														'modal'   => '#lotMovesLogTable',
													],
												],
											];
											if ( $entry['status'] != 'in_packaging' ) {
												unset( $actions['waste'] );
												unset( $actions['return'] );
												unset( $actions['product'] );
												unset( $actions['divider'] );
											}
											echo kph_get_template( 'components/row-actions-dropdown.php', [
												'actions' => $actions,
											] );
											?>
                                        </li>
                                    </ul>
                                </div>
                            </div>
							<?php
						}
					}
					?>
                </div>
            </div>
            <div class="card-inner">
				<?php
				echo kph_get_template( 'components/pagination.php', [
					'max_page_num' => $total_page,
					'current_page' => $page_number,
					'class_name'   => 'user_pagination_link',
					'show_count'   => 2,
				] );
				?>
            </div>
        </div>
    </div>
</div>
<div class="nk-block-head nk-block-head-sm">
    <div class="nk-block-between">
        <div class="nk-block-head-content">
            <h3 class="nk-block-title page-title">گزارش جامع سالن:</h3>
        </div>
        <div class="card-tools">
            <ul class="btn-toolbar gx-1">
                <li>
					<?php
					$filter_fields = [
						[
							'type'  => 'date-range',
							'label' => 'تاریخ گزارش',
							'name'  => 'date',
							'value' => [
								'from' => $date_from ?? '',
								'to'   => $date_to ?? '',
							],
						],
						[
							'type'  => 'hidden',
							'name'  => 'category_id',
							'value' => $category_id,
						],
						[
							'type'  => 'hidden',
							'name'  => 'status',
							'value' => $status,
						],
					];
					echo kph_get_template( 'components/filter-dropdown.php', [
						'has_filter'    => FALSE,
						'filter_fields' => $filter_fields,
					] );
					?>
                </li>
            </ul>
        </div>
    </div>
</div>
<div class="nk-block">
    <div class="row g-gs">
        <div class="col-md-4">
            <div class="card card-full">
                <div class="card-inner">
                    <div class="card-title-group align-center mb-1">
                        <div class="card-title">
                            <h6 class="title">موجود در سالن</h6>
                        </div>
                        <div class="card-amount">
                            <div class="amount">
								<?php echo number_format( $summery['current_in_packaging'], 5, '.', '' ); ?>
                                <small class="currency currency-usd fs-12px">کیلوگرم</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card card-full">
                <div class="card-inner">
                    <div class="card-title-group align-center mb-1">
                        <div class="card-title">
                            <h6 class="title">هدر رفته در سالن</h6>
                        </div>
                        <div class="card-amount">
                            <div class="amount text-danger">
								<?php echo number_format( $summery['total_waste'], 5, '.', '' ); ?>
                                <small class="currency currency-usd fs-12px">کیلوگرم</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card card-full">
                <div class="card-inner">
                    <div class="card-title-group align-center mb-1">
                        <div class="card-title">
                            <h6 class="title">تبدیل شده به محصول</h6>
                        </div>
                        <div class="card-amount">
                            <div class="amount text-success">
								<?php echo number_format( $summery['total_converted'], 5, '.', '' ); ?>
                                <small class="currency currency-usd fs-12px">کیلوگرم</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="convertLotToProduct">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">تبدیل به محصول</h5>
                <a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
            </div>
            <div class="modal-body modal-body-md">
                <form action="#" class="modal_form" data-action="kph_convert_packaging_lot_to_shop_product"
                      data-page="/crm/produce-saloon">
                    <div class="row g-gs">
                        <div class="col-12">
                            <label class="form-label" for="production_code_search">انتخاب محصول / کد تولید</label>
                            <input type="search" class="form-control" id="production_code_search" placeholder="نام محصول یا کد تولید را جستجو کنید" autocomplete="off">
                            <select class="form-select mt-2" id="production_code_id" data-for="production_code_id" data-req="1" aria-label="محصول و کد تولید">
                                <option value="">نام محصول یا کد را جستجو و یک مورد را انتخاب کنید</option>
                            </select>
                            <button type="button" class="btn btn-outline-secondary mt-2" id="production_code_more" style="display:none">نمایش کدهای بیشتر</button>
                            <div id="production_code_selected" class="text-primary mt-2" aria-live="polite"></div>
                            <input type="hidden" data-for="production_nonce" id="production_nonce" value="<?php echo esc_attr( wp_create_nonce( 'kph_production_codes' ) ); ?>">
                        </div>
                        <?php if ( current_user_can( 'manage_options' ) ) { ?>
                        <div class="col-12">
                            <details>
                                <summary>تعریف کد تولید جدید</summary>
                                <label class="form-label mt-2" for="new_production_product">محصول کد جدید</label>
                                <select class="form-select" id="new_production_product">
                                    <option value="">محصول را انتخاب کنید</option>
                                    <?php foreach ( $products as $product ) { ?>
                                    <option value="<?php echo esc_attr( $product['id'] ); ?>"><?php echo esc_html( $product['title'] ); ?></option>
                                    <?php } ?>
                                </select>
                                <label class="form-label mt-2" for="new_production_code">کد جدید</label>
                                <input type="text" class="form-control" id="new_production_code" maxlength="64" autocomplete="off">
                                <label class="mt-2"><input type="checkbox" id="new_production_confirm"> ارتباط کد جدید با محصول انتخاب‌شده را تأیید می‌کنم.</label>
                                <button type="button" class="btn btn-outline-primary mt-2" id="register_production_code">تعریف کد جدید</button>
                            </details>
                        </div>
                        <?php } ?>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label class="form-label" for="product_conversion_total_weight">وزن کل(به گرم وارد
                                    شود)</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control validate_weight"
                                           id="product_conversion_total_weight"
                                           data-target="#max_conversion_weight"
                                           data-for="total_weight">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label class="form-label" for="weight_per_item">وزن هر آیتم(به گرم وارد شود)</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control"
                                           id="weight_per_item"
                                           data-for="weight_per_item">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="packaging_cost_per_item">هزینه بسته بندی هر
                                    مورد</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control price_input" id="packaging_cost_per_item"
                                           data-for="packaging_cost_per_item" data-req="1">
                                </div>
                            </div>
                        </div>
                        <input type="hidden" id="max_conversion_weight">
                        <input type="hidden" data-for="lot_id" id="new_conversion_lot_id">
                        <input type="hidden" data-for="category_id" id="new_conversion_category_id">
                        <div class="col-12">
                            <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                <li>
                                    <div class="btn btn-primary submit_modal_form">ثبت</div>
                                </li>
                                <li>
                                    <a href="#" class="link link-light" data-bs-dismiss="modal">لغو</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

