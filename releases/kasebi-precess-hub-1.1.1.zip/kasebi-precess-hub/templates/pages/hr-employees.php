<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
$all_roles = [
	'accountant' => 'حسابدار',
	'supp'       => 'پشتیبانی',
	'saff'       => 'سالندار زعفران',
	'tea'        => 'سالندار چای',
	'hell'       => 'سالندار هل',
	'nabat'      => 'سالندار نبات',
	'zereshk'    => 'سالندار زرشک',
	'vanil'      => 'سالندار وانیل',
];
$employees = get_users( [
	'fields'   => 'ids',
	'orderby'  => 'ID',
	'order'    => 'DESC',
	'role__in' => array_keys( $all_roles ),
] );

?>
<div class="nk-block-head nk-block-head-sm">
    <div class="nk-block-between">
        <div class="nk-block-head-content">
            <h3 class="nk-block-title page-title">لیست کارمندان</h3>
            <div class="nk-block-des text-soft">
                <p>شما در مجموع <?php echo count( $employees ); ?> کارمند دارید.</p>
            </div>
        </div>
        <div class="nk-block-head-content">
            <div class="toggle-wrap nk-block-tools-toggle card-tools ">
                <ul class="g-3 btn-toolbar">
                    <li class="nk-block-tools-opt">
                        <div data-bs-toggle="tooltip" data-bs-placement="top" title="افزودن کارمند">
                            <div class="dropdown-toggle btn btn-icon btn-primary" data-bs-toggle="modal"
                                 data-bs-target="#addEmployee"><em class="icon ni ni-plus"></em></div>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<div class="nk-block">
    <div class="row g-gs">
		<?php
		foreach ( $employees as $user_id ) {
			$name       = get_user_name_by_id( $user_id );
			$user_login = get_user_by( 'ID', $user_id )->user_login;
			$user_role  = nooshika_get_user_role( $user_id );
			$role       = kph_get_role_label( $user_role );
			?>
            <div class="col-4">
                <div class="card card-bordered card-full">
                    <div class="card-inner">
                        <div class="team">
                            <div class="team-options">
								<?php
								$actions = [
									[
										'link'  => '/crm/employee/' . $user_id,
										'title' => 'مشخصات کارمند',
										'icon'  => 'ni-eye',
										'class' => 'page_activator',
									],
									[
										'link'  => '',
										'title' => 'ورود با کارمند',
										'icon'  => 'ni-signin',
										'class' => 'login_as_this',
										'data'  => [
											'id' => $user_id,
										],
									],
									[ 'divider' => 'divider' ],
									[
										'link'  => '',
										'title' => 'بازنشانی رمز عبور',
										'icon'  => 'ni-repeat',
										'class' => 'reset_password',
										'data'  => [
											'id' => $user_id,
										],
									],
									[
										'link'  => '',
										'title' => 'حذف کارمند',
										'icon'  => 'ni-user-cross',
										'class' => 'delete_user',
										'data'  => [
											'user-id' => $user_id,
										],
									],
								];
								echo kph_get_template( 'components/row-actions-dropdown.php', [
									'actions' => $actions,
								] );
								?>
                            </div>
                            <div class="user-card user-card-s2">
                                <div class="user-avatar md bg-white text-primary">
                                    <em class="icon ni ni-user-circle" style="font-size: 60px"></em>
                                </div>
                                <div class="user-info">
                                    <h6><?php echo $name; ?></h6>
                                    <span class="sub-text"><?php echo $role; ?></span>
                                    <span class="sub-text">@<?php echo $user_login; ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
			<?php
		}
		?>
    </div>
</div>
