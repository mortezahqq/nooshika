<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
if ( ! kph_visitor_monthly_allowed() ) { return; }
$monthly_self = nooshika_get_user_role( get_current_user_id() ) === 'visitor';
// Identity and scope always come from the authenticated session.
$monthly_ids = $monthly_self ? [ get_current_user_id() ] : get_users( [ 'role__in' => [ 'visitor' ], 'fields' => 'ids' ] );
$monthly_period = kph_visitor_sales_period();
$monthly_db = new kph_db();
$monthly_sales = $monthly_db->get_visitor_monthly_sales( $monthly_ids, $monthly_period['from'], $monthly_period['until'] );
$monthly_invoice_count = array_sum( array_map( static fn( $summary ) => count( $summary['items'] ), $monthly_sales ) );
?>
<?php if ( empty( $monthly_fragment ) ) : ?>
<section class="nk-block kph-visitors kph-monthly-sales mb-5" data-nonce="<?php echo esc_attr( wp_create_nonce( 'kph_visitor_monthly_sales' ) ); ?>">
<?php endif; ?>
    <div class="kv-heading">
        <div>
            <h3>فروش ماه جاری <?php echo $monthly_self ? 'من' : 'ویزیتورها'; ?></h3>
            <p><?php echo esc_html( $monthly_period['label'] ); ?></p>
        </div>
        <button type="button" class="btn btn-outline-primary kph-monthly-refresh">
            <em class="icon ni ni-reload" aria-hidden="true"></em><span>به‌روزرسانی</span>
        </button>
    </div>
    <div class="kv-overview">
        <?php foreach ( [ 'shipped' => 'فروش ارسالی', 'proforma' => 'پیش‌فاکتورهای باز' ] as $key => $label ) : ?>
        <div class="kv-stat">
            <span class="kv-stat-label"><?php echo esc_html( $label ); ?></span>
            <div class="kv-stat-value"><bdi class="kv-number"><?php echo esc_html( number_format( array_sum( array_column( $monthly_sales, $key ) ) ) ); ?></bdi><small>ریال</small></div>
            <p class="kv-help"><?php echo $key === 'shipped' ? 'به قیمت فروش، پس از کسر برگشتی‌ها' : 'پیش‌فاکتورهای ثبت‌شده در این ماه'; ?></p>
        </div>
        <?php endforeach; ?>
        <div class="kv-stat">
            <span class="kv-stat-label">تعداد فاکتورها</span>
            <div class="kv-stat-value"><bdi class="kv-number"><?php echo esc_html( number_format( $monthly_invoice_count ) ); ?></bdi><small>فاکتور</small></div>
            <p class="kv-help">ارسالی و پیش‌فاکتورهای باز این ماه</p>
        </div>
    </div>
    <?php foreach ( $monthly_sales as $visitor_id => $summary ) : ?>
    <details class="kv-history" data-monthly-visitor="<?php echo esc_attr( $visitor_id ); ?>">
        <summary>
            <?php echo $monthly_self ? 'ریز فاکتورهای این ماه' : esc_html( get_user_name_by_id( $visitor_id ) ); ?>
            <span class="kv-pill"><?php echo esc_html( number_format( count( $summary['items'] ) ) ); ?> فاکتور</span>
        </summary>
        <?php if ( ! $monthly_self ) : ?>
        <div class="kv-target-footer mb-3">
            <span>ارسالی: <bdi class="kv-number"><?php echo esc_html( number_format( $summary['shipped'] ) ); ?></bdi> ریال</span>
            <span>پیش‌فاکتور: <bdi class="kv-number"><?php echo esc_html( number_format( $summary['proforma'] ) ); ?></bdi> ریال</span>
        </div>
        <?php endif; ?>
        <?php if ( $summary['items'] ) : ?>
        <div class="card card-bordered"><div class="table-responsive">
            <table class="table table-striped mb-0">
                <thead><tr><th scope="col">شماره سفارش</th><th scope="col">مشتری</th><th scope="col">نوع</th><th scope="col">تاریخ</th><th scope="col">مبلغ (ریال)</th></tr></thead>
                <tbody><?php foreach ( $summary['items'] as $item ) : ?>
                <tr>
                    <td><bdi><?php echo esc_html( $item['id'] ); ?></bdi></td>
                    <td><?php echo esc_html( get_user_name_by_id( (int) $item['customer_id'] ) ); ?></td>
                    <td><span class="badge bg-<?php echo $item['kind'] === 'shipped' ? 'success' : 'warning'; ?>"><?php echo $item['kind'] === 'shipped' ? 'ارسالی' : 'پیش‌فاکتور'; ?></span></td>
                    <td class="text-nowrap"><?php echo esc_html( date_i18n( 'Y/m/d', strtotime( $item['activity_at'] ) ) ); ?></td>
                    <td class="text-nowrap"><bdi class="kv-number"><?php echo esc_html( number_format( (float) $item['amount'] ) ); ?></bdi></td>
                </tr>
                <?php endforeach; ?></tbody>
            </table>
        </div></div>
        <?php else : ?>
        <div class="kv-empty"><em class="icon ni ni-file-text" aria-hidden="true"></em><h6>هنوز فاکتوری در این ماه ثبت نشده است</h6><p>پس از ثبت پیش‌فاکتور یا ارسال سفارش، جزئیات اینجا نمایش داده می‌شود.</p></div>
        <?php endif; ?>
    </details>
    <?php endforeach; ?>
    <?php if ( ! $monthly_sales ) : ?><div class="kv-empty"><h6>هنوز ویزیتوری ثبت نشده است</h6></div><?php endif; ?>
    <div class="kv-target-footer mt-3">
        <small class="kv-muted">آخرین به‌روزرسانی: <bdi><?php echo esc_html( $monthly_period['time'] ); ?></bdi> · خودکار هر ۳۰ ثانیه</small>
        <span class="kph-monthly-message text-danger" role="status"></span>
    </div>
<?php if ( empty( $monthly_fragment ) ) : ?></section><?php endif; ?>
