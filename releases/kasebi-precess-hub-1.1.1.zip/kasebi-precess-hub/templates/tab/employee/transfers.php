<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** @var int $user_id */
echo kph_get_template( 'tab/user/transfers.php', [
	'user_id'     => $user_id,
	'record_page' => '/crm/employee',
] );
