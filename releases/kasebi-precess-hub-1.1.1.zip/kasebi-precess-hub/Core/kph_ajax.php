<?php

class kph_ajax {
	
	public array  $actions;
	public kph_db $DB;
	public wpdb   $wpdb;

	private function require_visitor_order_access( string $key, bool $is_item = FALSE, bool $optional = FALSE ): void {
		if ( ! $this->DB->visitor_order_scope_id() ) { return; }
		$value = $_POST[$key] ?? 0;
		$id = is_scalar( $value ) ? absint( $value ) : 0;
		if ( $optional && ! $id && is_scalar( $value ) ) { return; }
		if ( ! $this->DB->visitor_can_access_order( $id, $is_item ) ) {
			wp_send_json( [ 'status' => 'error', 'message' => 'اجازه دسترسی به این سفارش را ندارید.' ], 403 );
		}
	}
	
	public function __construct() {
		$this->actions = [
			'kph_search_production_codes' => [ $this, 'search_production_codes' ],
			'kph_register_production_code' => [ $this, 'register_production_code' ],
			'kph_set_cheque_note_print' => [ $this, 'set_cheque_note_print' ],
			'kph_delete_visitor_target' => [ $this, 'delete_visitor_target' ],
			'kph_save_customer_payment_term' => [ $this, 'save_customer_payment_term' ],
			'kph_submit_login_form'                     => [ $this, 'submit_login_form', ],
			'kph_send_login_otp'                        => [ $this, 'send_login_otp', ],
			'kph_submit_login_otp'                      => [ $this, 'submit_login_otp', ],
			'kph_submit_change_password_form'           => [ $this, 'submit_change_password_form', ],
			'kph_reset_password'                        => [ $this, 'reset_password', ],
			'kph_add_user'                              => [ $this, 'add_user', ],
			'kph_search_user'                           => [ $this, 'search_user', ],
			'kph_delete_user'                           => [ $this, 'delete_user', ],
			'kph_login_as_user'                         => [ $this, 'login_as_user', ],
			'kph_change_skin'                           => [ $this, 'change_skin', ],
			'kph_change_timezone'                       => [ $this, 'change_timezone', ],
			'kph_save_dark_mode'                        => [ $this, 'save_dark_mode', ],
			'kph_request_page_content'                  => [ $this, 'request_page_content', ],
			'kph_request_back_btn'                      => [ $this, 'request_back_btn', ],
			'kph_save_site_settings'                    => [ $this, 'save_site_settings', ],
			'kph_handle_file_upload'                    => [ $this, 'handle_file_upload', ],
			'kph_add_employee'                          => [ $this, 'add_employee', ],
			'kph_update_user_personal_data'             => [ $this, 'update_user_personal_data', ],
			'kph_update_inline_meta'                    => [ $this, 'update_inline_meta' ],
			'kph_search_user_for_modal'                 => [ $this, 'search_user_list', ],
			'kph_save_user_address'                     => [ $this, 'save_user_address', ],
			'kph_delete_customer_address'               => [ $this, 'delete_customer_address', ],
			'kph_load_user_address'                     => [ $this, 'load_user_address', ],
			'kph_delete_option_item'                    => [ $this, 'delete_option_item' ],
			'kph_add_option_item'                       => [ $this, 'add_option_item' ],
			'kph_add_raw_category'                      => [ $this, 'add_raw_category', ],
			'kph_delete_raw_category'                   => [ $this, 'delete_raw_category', ],
			'kph_add_raw_product'                       => [ $this, 'add_raw_product', ],
			'kph_delete_raw_product'                    => [ $this, 'delete_raw_product', ],
			'kph_add_supplier_user'                     => [ $this, 'add_supplier_user', ],
			'kph_search_supplier_invoice_product'       => [ $this, 'search_supplier_invoice_product', ],
			'kph_submit_new_supplier_order'             => [ $this, 'submit_new_supplier_order', ],
			'kph_load_invoice_items_table'              => [ $this, 'load_invoice_items_table', ],
			'kph_load_batch_storage_move'               => [ $this, 'load_batch_storage_move', ],
			'kph_change_invoice_status'                 => [ $this, 'change_invoice_status', ],
			'kph_edit_invoice_item_rate'                => [ $this, 'edit_invoice_item_rate', ],
			'kph_add_payment'                           => [ $this, 'add_payment', ],
			'kph_delete_payment'                        => [ $this, 'delete_payment', ],
			'kph_add_transfer'                          => [ $this, 'add_transfer', ],
			'kph_delete_transfer'                       => [ $this, 'delete_transfer', ],
			'kph_add_cheque'                            => [ $this, 'add_cheque', ],
			'kph_delete_cheque'                         => [ $this, 'delete_cheque', ],
			'kph_add_account'                           => [ $this, 'add_account', ],
			'kph_load_cheque_moves_table'               => [ $this, 'load_cheque_moves_table', ],
			'kph_load_cheques_list'                     => [ $this, 'load_cheques_list', ],
			'kph_change_cheque_status'                  => [ $this, 'change_cheque_status', ],
			'kph_refer_cheque_to_user'                  => [ $this, 'refer_cheque_to_user', ],
			'kph_add_account_transaction'               => [ $this, 'add_account_transaction', ],
			'kph_submit_wasted_batch'                   => [ $this, 'submit_wasted_batch', ],
			'kph_delete_batch_move'                     => [ $this, 'delete_batch_move', ],
			'kph_return_lot_to_processing'              => [ $this, 'return_lot_to_processing', ],
			'kph_submit_wasted_packaging_lot'           => [ $this, 'submit_wasted_packaging_lot', ],
			'kph_delete_lot_move'                       => [ $this, 'delete_lot_move', ],
			'kph_return_processing_pack_to_storage'     => [ $this, 'return_processing_pack_to_storage', ],
			'kph_create_processing_pack'                => [ $this, 'create_processing_pack', ],
			'kph_load_processing_pack_inputs'           => [ $this, 'load_processing_pack_inputs', ],
			'kph_load_processing_to_packaging_report'   => [ $this, 'load_processing_to_packaging_report', ],
			'kph_load_lot_moves'                        => [ $this, 'load_lot_moves', ],
			'kph_transfer_pack_to_packaging'            => [ $this, 'transfer_pack_to_packaging', ],
			'kph_delete_processing_pack_item'           => [ $this, 'delete_processing_pack_item', ],
			'kph_convert_packaging_lot_to_shop_product' => [ $this, 'convert_packaging_lot_to_shop_product', ],
			'kph_set_inventory_item_price'              => [ $this, 'set_inventory_item_price', ],
			'kph_load_inventory_logs'                   => [ $this, 'load_inventory_logs', ],
			'kph_load_inventory_table'                  => [ $this, 'load_inventory_table', ],
			'kph_search_customer_invoice_product'       => [ $this, 'search_customer_invoice_product', ],
			'kph_submit_customer_order'                 => [ $this, 'submit_customer_order', ],
			'kph_check_customer_proforma'               => [ $this, 'check_customer_proforma', ],
			'kph_change_order_status'                   => [ $this, 'change_order_status', ],
			'kph_load_order_items'                      => [ $this, 'load_order_items', ],
			'kph_load_order_fulfillment'                => [ $this, 'load_order_fulfillment', ],
			'kph_load_order_financial'                  => [ $this, 'load_order_financial', ],
			'kph_add_order_item_fulfillment'            => [ $this, 'add_order_item_fulfillment', ],
			'kph_send_order_sms'                        => [ $this, 'send_order_sms', ],
			'kph_cancel_remaining_item'                 => [ $this, 'cancel_remaining_item', ],
			'kph_cancel_sended_product'                 => [ $this, 'cancel_sended_product', ],
			'kph_submit_new_action_for_user'            => [ $this, 'submit_new_action_for_user', ],
			'kph_delete_customer_proforma'              => [ $this, 'delete_customer_proforma' ],
			'kph_save_visitor_target' => [ $this, 'save_visitor_target' ],
			'kph_save_visitor_commission_settings'       => [ $this, 'save_visitor_commission_settings' ],
		];
		$this->DB      = new kph_db();
		global $wpdb;
		$this->wpdb = $wpdb;
		foreach ( $this->actions as $action => $callback ) {
			add_action( 'nooshika_ajax_' . $action, $callback );
		}
	}
	

	private function require_production_access(): void {
		$pages = get_kph_pages_list();
		$role = nooshika_get_user_role( get_current_user_id() );
		if ( ! get_current_user_id() || ! in_array( $role, $pages['produce-saloon']['valid_roles'] ?? [], TRUE )
			|| ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['production_nonce'] ?? '' ) ), 'kph_production_codes' ) ) {
			wp_send_json( [ 'status' => 'error', 'message' => 'دسترسی یا اعتبار فرم تولید معتبر نیست؛ صفحه را تازه کنید.' ], 403 );
		}
	}

	public function search_production_codes(): void {
		$this->require_production_access();
		$items = $this->DB->search_production_codes( sanitize_text_field( wp_unslash( $_POST['search'] ?? '' ) ), absint( $_POST['page_number'] ?? 1 ) );
		wp_send_json( [ 'status' => 'success', 'items' => $items, 'more' => count( $items ) === 30 ] );
	}

	public function register_production_code(): void {
		$this->require_production_access();
		wp_send_json( $this->DB->register_production_code( sanitize_text_field( wp_unslash( $_POST['code'] ?? '' ) ), absint( $_POST['product_id'] ?? 0 ) ) );
	}

	public function set_cheque_note_print(): void {
		if ( ! current_user_can( 'manage_options' ) || ! wp_verify_nonce( $_POST['nonce'] ?? '', 'kph_cheque_admin_note' ) ) {
			wp_send_json( [ 'status' => 'error', 'message' => 'دسترسی یا اعتبار فرم چک معتبر نیست.' ], 403 );
		}
		wp_send_json( $this->DB->set_cheque_note_print( absint( $_POST['cheque_id'] ?? 0 ), (string) ( $_POST['show'] ?? '0' ) === '1' ) );
	}

	public function submit_login_form() {
		$ip_address    = $_SERVER['REMOTE_ADDR'];
		$transient_key = 'login_attempts_' . md5( $ip_address );
		$attempts      = (int) get_transient( $transient_key );
		
		if ( $attempts >= 5 ) {
			wp_send_json( [
				'status'  => 'error',
				'message' => 'دسترسی موقتاً مسدود شده است. لطفاً بعداً تلاش کنید.',
			] );
		}
		
		if ( empty( $_POST['username'] ) || empty( $_POST['password'] ) ) {
			wp_send_json( [
				'status'  => 'error',
				'message' => 'نام کاربری و رمز عبور الزامی است.',
			] );
		}
		
		$username = sanitize_user( $_POST['username'] );
		$password = $_POST['password'];
		
		$cred = [
			'user_login'    => $username,
			'user_password' => $password,
			'remember'      => TRUE,
		];
		
		$user = wp_signon( $cred, FALSE );
		
		if ( is_wp_error( $user ) ) {
			$attempts ++;
			set_transient( $transient_key, $attempts, MINUTE_IN_SECONDS * 10 );
			wp_send_json( [
				'status'  => 'error',
				'message' => 'نام کاربری یا رمز عبور اشتباه است.',
			] );
		}
		
		delete_transient( $transient_key );
		
		wp_send_json( [
			'status'  => 'success',
			'message' => 'با موفقیت وارد شدید.',
		] );
	}
	
	public function send_login_otp() {
		$phone = nooshika_sanitize_numbers( $_POST['phone'] );
		$phone = remove_zero_from_phone( $phone );
		
		if ( empty( $phone ) ) {
			wp_send_json( [
				'status'  => 'error',
				'message' => 'شماره موبایل نامعتبر است',
			] );
		}
		$otp_data = get_transient( 'nooshika_otp_' . $phone );
		if ( $otp_data && $otp_data['created'] + 60 > time() ) {
			wp_send_json( [
				'status'  => 'error',
				'message' => 'لطفا یک دقیقه صبر کنید',
			] );
		}
		$otp_try_key = 'nooshika_otp_try_' . $phone;
		$otp_try     = get_transient( $otp_try_key );
		if ( $otp_try && $otp_try['count'] > 5 && $otp_try['first_try'] + 300 > time() ) {
			wp_send_json( [
				'status'  => 'error',
				'message' => 'تعداد درخواست‌های بیش از حد. ۵ دقیقه صبر کنید.',
			] );
		}
		if ( ! $otp_try ) {
			$otp_try = [
				'count'     => 1,
				'first_try' => time(),
			];
		} else {
			$otp_try['count'] ++;
		}
		set_transient( $otp_try_key, $otp_try, 600 ); // 10 دقیقه اعتبار
		
		$otp = str_pad( rand( 100, 9999 ), 4, "0", STR_PAD_LEFT );
		
		$user_id = get_user_id_by_phone( $phone );
		set_transient( 'nooshika_otp_' . $phone, [
			'otp'     => $otp,
			'created' => time(),
			'user_id' => $user_id,
		], 180 ); // 3 دقیقه اعتبار
		
		( new nooshika_otp() )->send_otp_sms( $phone, $otp );
		
		wp_send_json( [
			'status'  => 'success',
			'message' => 'کد تایید به شماره موبایل شما ارسال شد',
		] );
	}
	
	public function submit_login_otp() {
		$otp   = nooshika_sanitize_numbers( $_POST['otp'] );
		$phone = nooshika_sanitize_numbers( $_POST['phone'] );
		$phone = remove_zero_from_phone( $phone );
		
		if ( empty( $phone ) || empty( $otp ) ) {
			wp_send_json( [
				'status'  => 'error',
				'message' => 'شماره یا کد تایید نامعتبر است',
			] );
		}
		
		$data = get_transient( 'nooshika_otp_' . $phone );
		if ( ! $data ) {
			wp_send_json( [
				'status'  => 'error',
				'message' => 'کد تایید منقضی شده است. لطفا مجدد درخواست دهید.',
			] );
		}
		if ( $data['created'] + 180 < time() ) {
			delete_transient( 'nooshika_otp_' . $phone );
			wp_send_json( [
				'status'  => 'error',
				'message' => 'کد تایید منقضی شده است.',
			] );
		}
		$wrong_key = 'nooshika_otp_wrong_' . $phone;
		$wrong     = get_transient( $wrong_key );
		if ( $wrong && $wrong['count'] > 5 && $wrong['first_try'] + 300 > time() ) {
			wp_send_json( [
				'status'  => 'error',
				'message' => 'تعداد تلاش‌های ناموفق زیاد بوده است. لطفا ۵ دقیقه صبر کنید.',
			] );
		}
		if ( $data['otp'] !== $otp ) {
			if ( ! $wrong ) {
				$wrong = [
					'count'     => 1,
					'first_try' => time(),
				];
			} else {
				$wrong['count'] ++;
			}
			set_transient( $wrong_key, $wrong, 600 );
			
			wp_send_json( [
				'status'  => 'error',
				'message' => 'کد تایید اشتباه است.',
			] );
		}
		
		delete_transient( 'nooshika_otp_' . $phone );
		delete_transient( $wrong_key );
		
		$user_id = $data['user_id'];
		if ( ! $user_id ) {
			$new_user = [
				'user_pass'     => wp_generate_password( 12, FALSE ),
				'user_login'    => $phone,
				'user_nicename' => $phone,
				'display_name'  => $phone,
			];
			$user_id  = wp_insert_user( $new_user );
			update_user_meta( $user_id, 'nooshika_phone_num', $phone );
		}
		
		wp_clear_auth_cookie();
		wp_set_current_user( $user_id );
		wp_set_auth_cookie( $user_id, TRUE );
		
		wp_send_json( [
			'status'  => 'success',
			'message' => 'کد تایید صحیح است.',
			'user_id' => $user_id,
		] );
	}
	
	public function submit_change_password_form() {
		extract( $_POST );
		$user_id = get_current_user_id();
		$user    = get_user_by( 'id', $user_id );
		if ( $user && wp_check_password( $old_pass, $user->data->user_pass, $user->ID ) ) {
			wp_set_password( $new_pass, $user_id );
			$return['status'] = 'success';
			$return['msg']    = 'رمز عبور با موفقیت تغییر کرد';
			wp_logout();
		} else {
			$return['status'] = 'failed';
			$return['msg']    = 'رمز عبور قبلی اشتباه است';
		}
		wp_send_json( $return );
	}
	
	public function reset_password() {
		$user_id      = $_POST['user_id'];
		$new_password = wp_generate_password( 12, 0 );
		wp_set_password( $new_password, $user_id );
		$return = [
			'html' => "<p>رمز جدید: $new_password</p><p>پسورد جدید را حتما ذخیره بفرمایید.</p>",
		];
		wp_send_json( $return );
	}
	
	public function add_user() {
		extract( $_POST );
		$phone       = nooshika_sanitize_numbers( $phone );
		$phone       = remove_zero_from_phone( $phone );
		$user_id     = get_user_id_by_phone( $phone );
		$is_new_user = ! $user_id;
		if ( ! $user_id ) {
			$new_user = [
				'user_pass'    => wp_generate_password( 12, 0 ),
				'user_login'   => $phone,
				'first_name'   => $first_name,
				'last_name'    => $last_name,
				'display_name' => $first_name . ' ' . $last_name,
				'meta_input'   => [
					'nooshika_phone_num' => $phone,
					'creator_id'         => get_current_user_id(),
				],
			];
			$user_id  = wp_insert_user( $new_user );
		}
		if ( is_wp_error( $user_id ) ) {
			$status = 'error';
			$msg    = $user_id->get_error_message();
			$page   = 'crm/users';
			$url    = home_url( 'crm/users' );
		} else {
			if ( isset( $_POST['meta'] ) ) {
				foreach ( $_POST['meta'] as $key => $value ) {
					if ( $key == 'birthday' ) {
						$value = $value ? nooshika_jalali_to_gregorian( $value ) : '';
					}
					update_user_meta( $user_id, $key, $value );
				}
			}
			$_REQUEST['id'] = $user_id;
			$url            = home_url( 'crm/user/' . $user_id );
			$status         = 'success';
			$msg            = 'کاربر با موفقیت ایجاد شد.';
			$page           = 'crm/user';
		}
		if ( $status === 'success' && $is_new_user ) {
			do_action( 'kph_customer_user_added', (int) $user_id );
		}
		$return = [
			'main'    => kph_get_template( 'layout/main.php', [ 'page' => $page ] ),
			'url'     => $url,
			'status'  => $status,
			'message' => $msg,
		];
		wp_send_json( $return );
	}
	
	public function search_user() {
		$search = $_POST['search'];
		$args   = [
			'users' => kph_get_user_list( $search )['users'],
		];
		$result = [
			'searchResult' => kph_get_template( "misc/search_result.php", $args ),
		];
		wp_send_json( $result );
	}
	
	public function delete_user() {
		$user_id = $_POST['user_id'];
		require_once( ABSPATH . 'wp-admin/includes/user.php' );
		$status = wp_delete_user( $user_id );
		$return = [
			'main'    => kph_get_template( 'layout/main.php', [ 'page' => $_POST['page'] ?? 'crm/users', ] ),
			'status'  => $status ? 'success' : 'error',
			'message' => $status ? 'حذف کاربر با موفقیت انجام شد' : 'حذف کاربر با خطا روبرو شد',
		];
		wp_send_json( $return );
	}
	
	public function login_as_user() {
		$user_id    = $_POST['user_id'];
		$current_id = get_current_user_id();
		if ( ! is_current_user_admin( $user_id ) ) {
			setcookie( 'ksm_admin_user_id', $current_id, time() + 7200, '/' );
		} else {
			setcookie( 'ksm_admin_user_id', '', 1 );
		}
		wp_clear_auth_cookie();
		wp_set_current_user( $user_id );
		wp_set_auth_cookie( $user_id, TRUE );
		wp_send_json( [
			'status' => 'success',
			'url'    => home_url( '/crm' ),
		] );
	}
	
	public function change_skin() {
		$skin = $_POST['skin'];
		update_user_meta( get_current_user_id(), 'kph_skin', $skin );
		wp_send_json( [ 'status' => 'success' ] );
	}
	
	public function change_timezone() {
		$skin = $_POST['timezone'];
		update_user_meta( get_current_user_id(), 'kph_timezone', $skin );
		wp_send_json( [ 'status' => 'success' ] );
	}
	
	public function save_dark_mode() {
		$is_active = $_POST['is_active'];
		update_user_meta( get_current_user_id(), 'kph_dark_mode', $is_active );
		wp_send_json( [ 'status' => 'success' ] );
	}
	
	public function request_page_content() {
		$page = $_POST['page'];
		unset( $_POST['page'] );
		unset( $_POST['action'] );
		$_POST     = array_filter( $_POST );
		$query     = http_build_query( $_POST );
		$query     = urldecode( $query );
		$parts     = get_kph_end_point( $page );
		$sub_pages = get_kph_single_page_list();
		if ( isset( $sub_pages[ $parts[0] ] ) ) {
			if ( $parts[1] ) {
				$_REQUEST['id'] = $parts[1];
			}
		}
		$url    = $query ? home_url( $page . '?' . $query ) : home_url( $page );
		$return = [
			'url'   => $url,
			'main'  => kph_get_template( 'layout/main.php', [ 'page' => $page ] ),
			'title' => get_kph_page_title( $parts[0] ),
		];
		wp_send_json( $return );
	}
	
	public function request_back_btn() {
		$path      = $_POST['path'];
		$query     = explode( '?', $path );
		$path      = kph_sanitize_url_for_template_path( $query[0] );
		$parts     = get_kph_end_point( $path );
		$sub_pages = get_kph_single_page_list();
		if ( isset( $sub_pages[ $parts[0] ] ) ) {
			$_REQUEST['id'] = $parts[1];
		}
		$query = $query[1] ?? '';
		parse_str( $query, $query_args );
		$_REQUEST = array_merge( $_REQUEST, $query_args );
		$return = [
			'main' => kph_get_template( 'layout/main.php', [ 'page' => $path ] ),
		];
		wp_send_json( $return );
	}
	
	public function update_user_role() {
		$user_id = $_POST['user_id'];
		$user    = new WP_User( $user_id );
		$user->set_role( $_POST['role'] );
		$return = [
			'msg'  => 'تامین‌کننده با موفقیت به روز رسانی شد.',
			'main' => kph_get_template( 'layout/main.php', [ 'page' => 'crm/hr-employees' ] ),
		];
		wp_send_json( $return );
	}
	
	public function add_employee() {
		$full_name = $_POST['full_name'];
		$username  = $_POST['username'];
		$phone     = $_POST['phone'];
		$role      = $_POST['role'];
		$name      = separate_first_last_from_name( $full_name );
		$new_user  = [
			'user_pass'    => '123456',
			'user_login'   => $username,
			'first_name'   => $name['first'],
			'last_name'    => $name['last'],
			'display_name' => $full_name,
		];
		$user_id   = wp_insert_user( $new_user );
		if ( ! is_wp_error( $user_id ) ) {
			$user = new WP_User( $user_id );
			$user->set_role( $role );
			$phone = nooshika_sanitize_numbers( $phone );
			$phone = remove_zero_from_phone( $phone );
			update_user_meta( $user_id, 'nooshika_phone_num', $phone );
			
			$return = [
				'status' => 'success',
				'msg'    => 'کارمند با موفقیت ایجاد شد.',
				'main'   => kph_get_template( 'layout/main.php', [ 'page' => 'crm/hr-employees' ] ),
			];
			wp_send_json( $return );
		}
		$return = [
			'status' => 'success',
			'msg'    => $user_id->get_error_message(),
			'main'   => kph_get_template( 'layout/main.php', [ 'page' => 'crm/hr-employees' ] ),
		];
		wp_send_json( $return );
	}

	public function delete_visitor_target() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json( [ 'status' => 'error', 'message' => 'اجازه حذف تارگت ویزیتور را ندارید.' ] );
		}
		$id = isset( $_POST['id'] ) && is_scalar( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
		$target_id = isset( $_POST['item_id'] ) && is_scalar( $_POST['item_id'] ) ? absint( $_POST['item_id'] ) : 0;
		$nonce = isset( $_POST['nonce'] ) && is_string( $_POST['nonce'] ) ? $_POST['nonce'] : '';
		if ( ! wp_verify_nonce( $nonce, 'kph_delete_visitor_target_' . $id . '_' . $target_id ) ) {
			wp_send_json( [ 'status' => 'error', 'message' => 'اعتبار درخواست تمام شده؛ صفحه را تازه کنید.' ] );
		}
		$result = $this->DB->delete_visitor_target( $id, $target_id );
		$_REQUEST['id'] = $id;
		$_REQUEST['tab'] = 'targets';
		unset( $_REQUEST['target_id'] );
		$result['main'] = kph_get_template( 'layout/main.php', [ 'page' => '/crm/employee' ] );
		wp_send_json( $result );
	}

	public function save_visitor_target() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json( [ 'status' => 'error', 'message' => 'اجازه تغییر تارگت ویزیتور را ندارید.' ] );
		}
		$id = isset( $_POST['id'] ) && is_scalar( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
		$nonce = isset( $_POST['target_nonce'] ) && is_string( $_POST['target_nonce'] ) ? $_POST['target_nonce'] : '';
		if ( ! wp_verify_nonce( $nonce, 'kph_visitor_target_' . $id ) ) {
			wp_send_json( [ 'status' => 'error', 'message' => 'اعتبار فرم تمام شده؛ صفحه را تازه کنید.' ] );
		}
		$result = $this->DB->save_visitor_target( $id, wp_unslash( $_POST ) );
		if ( $result['status'] === 'success' ) {
			$_REQUEST['id'] = $id;
			$_REQUEST['tab'] = 'targets';
			unset( $_REQUEST['target_id'] );
			$result['main'] = kph_get_template( 'layout/main.php', [ 'page' => '/crm/employee' ] );
		}
		wp_send_json( $result );
	}

	public function save_visitor_commission_settings() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json( [
				'status'  => 'error',
				'message' => 'شما اجازه تغییر تنظیمات پورسانت را ندارید.',
			] );
		}

		$user_id = absint( $_POST['id'] ?? 0 );
		if ( $user_id <= 0 || nooshika_get_user_role( $user_id ) !== 'visitor' ) {
			wp_send_json( [
				'status'  => 'error',
				'message' => 'ویزیتور معتبر نیست.',
			] );
		}

		$posted_rules = isset( $_POST['rules'] ) && is_array( $_POST['rules'] ) ? $_POST['rules'] : [];
		$rules        = [];
		foreach ( $posted_rules as $product_id => $rule ) {
			$product_id = absint( $product_id );
			$type       = sanitize_key( $rule['type'] ?? 'none' );
			$value      = max( 0, (float) ( $rule['value'] ?? 0 ) );

			if ( $product_id <= 0 || ! in_array( $type, [ 'percent', 'per_kg' ], TRUE ) || $value <= 0 ) {
				continue;
			}
			if ( $type === 'percent' ) {
				$value = min( 100, $value );
			}
			$rules[ $product_id ] = [
				'type'  => $type,
				'value' => $value,
			];
		}

		update_user_meta( $user_id, 'kph_visitor_commission_rules', $rules );
		$_REQUEST['id']  = $user_id;
		$_REQUEST['tab'] = 'commissions';
		wp_send_json( [
			'main'    => kph_get_template( 'layout/main.php', [ 'page' => '/crm/employee' ] ),
			'status'  => 'success',
			'message' => 'تنظیمات پورسانت ویزیتور ذخیره شد.',
		] );
	}
	
	public function save_site_settings() {
		$options = $_POST['options'];
		foreach ( $options as $key => $option ) {
			update_option( $key, $option );
		}
		$return = [
			'main'    => kph_get_template( 'layout/main.php', [ 'page' => 'crm/settings' ] ),
			'message' => 'اطلاعات با موفقیت ذخیره شد.',
			'status'  => 'success',
		];
		wp_send_json( $return );
	}
	
	public function handle_file_upload() {
		$attachment = $_FILES['file'];
		$attachment = kph_handle_upload_file( $attachment, 'kph-files' );
		$return     = [
			'attachment' => $attachment,
			'status'     => 'success',
			'message'    => 'فایل با موفقیت آپلود شد.',
		];
		wp_send_json( $return );
	}
	
	public function update_user_personal_data() {
		$user_id = absint( $_POST['id'] ?? 0 );
		$meta    = isset( $_POST['meta'] ) && is_array( $_POST['meta'] ) ? $_POST['meta'] : [];

		if ( array_key_exists( 'nooshika_phone_num', $meta ) && $meta['nooshika_phone_num'] !== '' ) {
			$phone = sanitize_text_field( wp_unslash( (string) $meta['nooshika_phone_num'] ) );
			$phone = nooshika_sanitize_numbers( $phone );
			$phone = remove_zero_from_phone( $phone );

			$phone_owner_id = get_user_id_by_phone( $phone );
			if ( $phone_owner_id && (int) $phone_owner_id !== $user_id ) {
				wp_send_json( [
					'main'    => kph_get_template( 'layout/main.php', [ 'page' => $_POST['page'] ] ),
					'message' => 'این شماره ورود قبلاً برای کاربر دیگری ثبت شده است.',
					'status'  => 'error',
				] );
			}

			$meta['nooshika_phone_num'] = $phone;
		}

		foreach ( $meta as $meta_key => $meta_value ) {
			if ( ! $meta_value ) {
				delete_user_meta( $user_id, $meta_key );
				continue;
			}
			if ( $meta_key == 'birthday' ) {
				$meta_value = nooshika_jalali_to_gregorian( $meta_value );
			}
			update_user_meta( $user_id, $meta_key, $meta_value );
		}
		$return = [
			'main'    => kph_get_template( 'layout/main.php', [ 'page' => $_POST['page'] ] ),
			'message' => 'اطلاعات با موفقیت به روز رسانی شد',
			'status'  => 'info',
		];
		wp_send_json( $return );
	}
	
	public function update_inline_meta() {
		$user_id = $_POST['id'];
		update_user_meta( $user_id, $_POST['key'], $_POST['value'] );
		wp_send_json( [] );
	}
	
	public function search_user_list() {
		$search = $_POST['search'];
		$role   = $_POST['role'] ?? 'subscriber';
		$args   = [
			'users' => kph_get_user_list( $search, $role )['users'],
		];
		$result = [
			'searchResult' => kph_get_template( "misc/search_user_for_modal.php", $args ),
		];
		wp_send_json( $result );
	}
	
	public function save_user_address() {
		$user_id   = $_POST['user_id'];
		$addresses = get_user_meta( $user_id, 'address_list', TRUE );
		$addresses = kasebi_unminified_string( $addresses );
		
		$address_id               = $_POST['address_id'] !== 'false' ? $_POST['address_id'] : count( $addresses );
		$addresses[ $address_id ] = $_POST['address'];
		$result                   = [
			'html' => kph_get_template( "misc/addresses.php", [
				'addresses' => $addresses,
				'user_id'   => $user_id,
			] ),
		];
		$addresses                = kasebi_minify_array( $addresses );
		update_user_meta( $user_id, 'address_list', $addresses );
		update_user_meta( $user_id, 'default_address', $address_id );
		wp_send_json( $result );
	}
	
	public function delete_customer_address() {
		$user_id    = $_POST['user_id'];
		$addresses  = get_user_meta( $user_id, 'address_list', TRUE );
		$addresses  = kasebi_unminified_string( $addresses );
		$address_id = $_POST['address_id'];
		unset( $addresses[ $address_id ] );
		$addresses = array_values( $addresses );
		$result    = [
			'html' => kph_get_template( "misc/addresses.php", [
				'addresses' => $addresses,
				'user_id'   => $user_id,
			] ),
		];
		$addresses = kasebi_minify_array( $addresses );
		update_user_meta( $user_id, 'address_list', $addresses );
		wp_send_json( $result );
	}
	
	public function load_user_address() {
		$user_id   = $_POST['user_id'];
		$addresses = get_user_meta( $user_id, 'address_list', TRUE );
		$addresses = kasebi_unminified_string( $addresses );
		$addresses = $addresses ?: [];
		$result    = [
			'html' => kph_get_template( "misc/addresses.php", [
				'addresses' => $addresses,
				'user_id'   => $user_id,
			] ),
		];
		wp_send_json( $result );
	}
	
	public function add_option_item() {
		extract( $_POST );
		$options_list           = get_option( $option ) ?: [];
		$options_list           = is_array( $options_list ) ? $options_list : [];
		$option_item = [
			'label' => sanitize_text_field( $label ),
		];
		if ( $option === 'kph_cost_category' ) {
			$secondary_category = sanitize_text_field( wp_unslash( $_POST['secondary_category'] ?? '' ) );
			$secondary_options  = get_option( 'kph_cost_secondary_category', [] );
			if ( $secondary_category !== '' && isset( $secondary_options[ $secondary_category ] ) ) {
				$option_item['secondary_category'] = $secondary_category;
			}
		}
		$options_list[ $index ] = $option_item;
		update_option( $option, $options_list );
		$return = [
			'main'    => kph_get_template( 'layout/main.php', [ 'page' => $page ] ),
			'status'  => 'success',
			'message' => 'آیتم با موفقیت ثبت شد.',
		];
		wp_send_json( $return );
	}
	
	public function delete_option_item() {
		extract( $_POST );
		$options_list = get_option( $tab ) ?: [];
		$options_list = is_array( $options_list ) ? $options_list : [];
		unset( $options_list[ $item_id ] );
		update_option( $tab, $options_list );
		if ( $tab === 'kph_cost_secondary_category' ) {
			$cost_categories = get_option( 'kph_cost_category', [] );
			if ( is_array( $cost_categories ) ) {
				foreach ( $cost_categories as &$cost_category ) {
					if ( ( $cost_category['secondary_category'] ?? '' ) === $item_id ) {
						unset( $cost_category['secondary_category'] );
					}
				}
				unset( $cost_category );
				update_option( 'kph_cost_category', $cost_categories );
			}
		}
		$return = [
			'main'    => kph_get_template( 'layout/main.php', [ 'page' => $page ] ),
			'status'  => 'success',
			'message' => 'آیتم با موفقیت حذف شد.',
		];
		wp_send_json( $return );
	}
	
	public function add_raw_category() {
		if ( isset( $_POST['category_id'] ) && $_POST['category_id'] ) {
			$result = $this->DB->update_raw_category( $_POST['category_id'], [
				'title'      => $_POST['title'],
				'sort_order' => $_POST['sort_order'],
			] );
		} else {
			$result = $this->DB->add_raw_category( [
				'title'      => $_POST['title'],
				'sort_order' => $_POST['sort_order'],
			] );
		}
		$return = [
			'main'    => kph_get_template( 'layout/main.php', [ 'page' => $_POST['page'] ] ),
			'status'  => $result['status'],
			'message' => $result['message'],
		];
		wp_send_json( $return );
	}
	
	public function delete_raw_category() {
		$result = $this->DB->delete_raw_category( $_POST['item_id'] );
		
		$return = [
			'main'    => kph_get_template( 'layout/main.php', [ 'page' => $_POST['page'] ] ),
			'status'  => $result['status'],
			'message' => $result['message'],
		];
		wp_send_json( $return );
	}
	
	public function delete_raw_product() {
		$result = $this->DB->delete_raw_product( $_POST['item_id'] );
		
		$return = [
			'main'    => kph_get_template( 'layout/main.php', [ 'page' => $_POST['page'] ] ),
			'status'  => $result['status'],
			'message' => $result['message'],
		];
		wp_send_json( $return );
	}
	
	public function add_raw_product() {
		if ( isset( $_POST['product_id'] ) && $_POST['product_id'] ) {
			$result = $this->DB->update_raw_product( $_POST['product_id'], [
				'title'       => $_POST['title'],
				'code'        => $_POST['code'],
				'category_id' => $_POST['category_id'],
			] );
		} else {
			$result = $this->DB->add_raw_product( [
				'title'       => $_POST['title'],
				'code'        => $_POST['code'],
				'category_id' => $_POST['category_id'],
			] );
		}
		$return = [
			'main'    => kph_get_template( 'layout/main.php', [ 'page' => $_POST['page'] ] ),
			'status'  => $result['status'],
			'message' => $result['message'],
		];
		wp_send_json( $return );
	}
	
	public function add_supplier_user() {
		$phone   = $_POST['phone'];
		$phone   = nooshika_sanitize_numbers( $phone );
		$phone   = remove_zero_from_phone( $phone );
		$user_id = get_user_id_by_phone( $phone );
		
		if ( $user_id ) {
			unset( $_REQUEST );
			$return = [
				'status' => 'error',
				'msg'    => 'شماره موبایل تکراری است',
				'main'   => kph_get_template( 'layout/main.php', [ 'page' => '/crm/suppliers' ] ),
			];
			
			wp_send_json( $return );
		} else {
			extract( $_POST );
			$phone    = nooshika_sanitize_numbers( $phone );
			$phone    = remove_zero_from_phone( $phone );
			$new_user = [
				'user_pass'    => wp_generate_password( 12, 0 ),
				'user_login'   => $phone,
				'first_name'   => $first_name,
				'last_name'    => $last_name,
				'display_name' => $first_name . ' ' . $last_name,
				'role'         => 'supplier',
				'meta_input'   => [
					'nooshika_phone_num' => $phone,
					'national_code'      => $national_code,
					'birthday'           => nooshika_jalali_to_gregorian( $birthday ),
					'account_number'     => $account_number,
					'kph_supplier_group' => $supplier_group,
					'cart_number'        => $cart_number,
					'shaba_number'       => $shaba_number,
					'state'              => $state,
					'city'               => $city,
					'address'            => $address,
				],
			];
			$user_id  = wp_insert_user( $new_user );
			if ( is_wp_error( $user_id ) ) {
				$return = [
					'main'    => kph_get_template( 'layout/main.php', [ 'page' => $_POST['page'] ] ),
					'status'  => 'error',
					'message' => $user_id->get_error_message(),
				];
				wp_send_json( $return );
			}
			
			$_REQUEST['id'] = $user_id;
			do_action( 'kph_supplier_user_added', (int) $user_id );
		}
		
		$return = [
			'main'    => kph_get_template( 'layout/main.php', [ 'page' => $_POST['page'] ] ),
			'status'  => 'success',
			'message' => 'کاربر با موفقیت ایجاد شد',
			'url'     => home_url( '/crm/supplier/' . $user_id ),
		];
		wp_send_json( $return );
	}
	
	public function search_supplier_invoice_product() {
		$search_raw = $_POST['search'] ?? '';
		$search     = sanitize_text_field( wp_unslash( $search_raw ) );
		if ( $search == '' ) {
			$result = [
				'message' => 'متن جستجو را وارد کنید.',
				'status'  => 'error',
			];
			wp_send_json( $result );
		}
		$group  = $_POST['group'] ?: 1;
		$args   = [
			'items' => $this->DB->search_supplier_products( $search, $group ),
		];
		$result = [
			'status' => 'list',
			'html'   => kph_get_template( "misc/product_list.php", $args ),
		];
		wp_send_json( $result );
	}
	
	public function submit_new_supplier_order() {
		$user_id = $_POST['customer_id'];
		
		$products = isset( $_POST['products'] ) && is_array( $_POST['products'] ) ? $_POST['products'] : [];
		$items    = [];
		foreach ( $products as $product ) {
			$items[] = [
				'item_id'        => $product['item_id'],
				'raw_product_id' => $product['product_id'],
				'qty_weight'     => $product['qty'],
				'unit_price'     => $product['per_unit'],
				'line_total'     => $product['line_total'],
				'meta'           => [
					'month'         => $product['meta']['month'],
					'rate'          => $product['meta']['rate'],
					'per_unit_base' => $product['per_unit_base'],
				],
			];
		}
		$data = [
			'supplier_user_id' => $user_id,
			'invoice_no'       => $_POST['factor_number'],
			'status'           => 'proforma',
			'issued_at'        => nooshika_jalali_to_gregorian( $_POST['factor_date'] ),
			'note'             => $_POST['note'],
			'items'            => $items,
			'meta'             => [
				'attachments' => $_POST['attachments'],
			],
		];
		if ( isset( $_POST['invoice_id'] ) ) {
			if ( ! current_user_can( 'manage_options' ) || ! wp_verify_nonce( $_POST['edit_nonce'] ?? '', 'kph_supplier_edit_' . absint( $_POST['invoice_id'] ) ) ) {
				wp_send_json( [ 'status' => 'error', 'message' => 'اعتبار فرم ویرایش پیش‌فاکتور معتبر نیست.' ], 403 );
			}
			$data['delete_items'] = isset( $_POST['delete_items'] ) && is_array( $_POST['delete_items'] ) ? array_map( 'absint', $_POST['delete_items'] ) : [];
			unset( $data['status'] );
			$res = $this->DB->update_supplier_invoice( $_POST['invoice_id'], $data );
		} else {
			$res = $this->DB->add_supplier_invoice( $data );
		}
		$_REQUEST['id']     = $user_id;
		$_REQUEST['tab']    = 'invoice';
		$_REQUEST['status'] = 'proforma';
		$return             = [
			'main'    => kph_get_template( 'layout/main.php', [ 'page' => '/crm/supplier' ] ),
			'status'  => $res['status'],
			'message' => $res['message'],
		];
		wp_send_json( $return );
	}
	
	public function load_invoice_items_table() {
		$invoice = $this->DB->get_invoice_data( $_POST['invoice_id'] );
		$return  = [
			'html' => kph_get_template( 'partials/invoice-items.php', [
				'invoice_data' => $invoice,
				'DB'           => $this->DB,
			] ),
		];
		wp_send_json( $return );
	}
	
	public function change_invoice_status() {
		$res    = $this->DB->change_supplier_invoice_status(
			$_POST['invoice_id'],
			$_POST['status'],
			[
				$_POST['status'] . '_change_note' => $_POST['note'],
			]
		);
		$return = [
			'main'    => kph_get_template( 'layout/main.php', [ 'page' => '/crm/supplier' ] ),
			'status'  => $res['status'],
			'message' => $res['message'],
		];
		wp_send_json( $return );
	}
	
	public function edit_invoice_item_rate() {
		$res                = $this->DB->update_invoice_item_rate(
			$_POST['item_id'],
			$_POST['item_rate'],
			$_POST['item_month'],
		);
		$_REQUEST['status'] = 'confirmed';
		$return             = [
			'main'    => kph_get_template( 'layout/main.php', [ 'page' => '/crm/produce-invoice' ] ),
			'status'  => $res['status'],
			'message' => $res['message'],
		];
		wp_send_json( $return );
	}
	
	public function add_payment() {
		$res  = $this->DB->add_payment( [
			'user_id'        => $_POST['id'],
			'amount'         => str_replace( ',', '', $_POST['amount'] ),
			'type'           => $_POST['side'] ?? 'credit',
			'payment_method' => $_POST['payment_method'],
			'paid_at'        => nooshika_jalali_to_gregorian( $_POST['paid_at'] ),
			'note'           => $_POST['note'],
			'ref_id'         => $_POST['invoice_id'],
			'meta'           => [
				'attachment' => $_POST['attachment'],
				'creator_id' => get_current_user_id(),
			],
		] );
		$user_role = nooshika_get_user_role( $_POST['id'] );
		$page      = $user_role === 'subscriber' ? 'user' : ( $user_role === 'visitor' ? 'employee' : 'supplier' );
		
		$return = [
			'main'    => kph_get_template( 'layout/main.php', [ 'page' => "/crm/$page" ] ),
			'status'  => $res['status'],
			'message' => $res['message'],
		];
		wp_send_json( $return );
	}
	
	public function delete_payment() {
		$res    = $this->DB->delete_payment( $_POST['item_id'] );
		$page   = $_POST['page'];
		$return = [
			'main'    => kph_get_template( 'layout/main.php', [ 'page' => $page ] ),
			'status'  => $res['status'],
			'message' => $res['message'],
			'data'    => $res['data'] ?: '',
		];
		wp_send_json( $return );
	}
	
	public function add_transfer() {
		$amount        = isset( $_POST['amount'] )
			? (float) str_replace( ',', '', $_POST['amount'] )
			: 0;
		$side          = isset( $_POST['side'] ) ? strtolower( trim( $_POST['side'] ) ) : 'credit';
		$signed_amount = ( $side === 'credit' ) ? - 1 * $amount : $amount;
		$user_id       = isset( $_POST['id'] ) ? (int) $_POST['id'] : 0;
		$user_role     = nooshika_get_user_role( $user_id );
		
		$res = $this->DB->add_transfer( [
			'user_id'        => $user_id,
			'amount'         => $signed_amount,
			'bank_name'      => $_POST['bank'],
			'tracking_no'    => $_POST['tracking_no'],
			'transferred_at' => nooshika_jalali_to_gregorian( $_POST['transferred_at'] ),
			'note'           => $_POST['note'],
			'ref_id'         => $_POST['invoice_id'],
			'meta'           => [
				'attachment' => $_POST['attachment'],
				'creator_id' => get_current_user_id(),
			],
		] );
		if ( ( $res['status'] ?? '' ) === 'success' ) {
			$transfer_id = (int) ( $res['data']['id'] ?? 0 );
			$destination = isset( $_POST['destination_id'] ) ? sanitize_text_field( $_POST['destination_id'] ) : 'none';
			
			if ( $destination === 'supplier' ) {
				$destination_user_id = isset( $_POST['destination_user_id'] )
					? (int) $_POST['destination_user_id']
					: $user_id;
				
				if ( $destination_user_id > 0 ) {
					$supplier_res = $this->DB->add_transfer( [
						'user_id'        => $destination_user_id,
						'amount'         => abs( $amount ),
						'bank_name'      => $_POST['bank'],
						'tracking_no'    => $_POST['tracking_no'],
						'transferred_at' => nooshika_jalali_to_gregorian( $_POST['transferred_at'] ),
						'note'           => 'پرداخت حواله به تامین کننده - ' . sanitize_textarea_field( $_POST['note'] ?? '' ),
						'ref_id'         => $_POST['invoice_id'],
						'meta'           => [
							'attachment'         => $_POST['attachment'],
							'creator_id'         => get_current_user_id(),
							'source_transfer_id' => $transfer_id,
							'source_user_id'     => $user_id,
							'destination'        => 'supplier',
						],
					] );
					
					if ( ( $supplier_res['status'] ?? '' ) !== 'success' ) {
						$res = $supplier_res;
					}
				}
			}
			
			if ( $destination === 'account' ) {
				$account_id = isset( $_POST['account_id'] )
					? (int) $_POST['account_id']
					: 0;
				
				if ( $account_id > 0 ) {
					$account     = $this->wpdb->get_row(
						$this->wpdb->prepare(
							"SELECT id, balance,type FROM {$this->accounts} WHERE id = %d",
							$account_id
						),
						ARRAY_A
					);
					$account_res = $this->DB->add_account_transaction( [
						'account_id'  => $account_id,
						'amount'      => abs( $amount ),
						'type'        => (string) ( $account['type'] ?? '' ) !== 'expense' ? 'credit' : 'debit',
						'action'      => 'transfer_deposit',
						'description' => 'واریز حواله #' . $transfer_id,
						'created_by'  => get_current_user_id(),
						'created_at'  => current_time( 'mysql' ),
						'meta'        => [
							'transfer_id' => $transfer_id,
							'user_id'     => $user_id,
							'invoice_id'  => $_POST['invoice_id'],
							'tracking_no' => $_POST['tracking_no'],
							'bank_name'   => $_POST['bank'],
							'attachment'  => $_POST['attachment'],
							'destination' => $_POST['account_destination'],
							'cost_type'   => $_POST['account_cost_type'],
						],
					] );
					
					if ( ( $account_res['status'] ?? '' ) !== 'success' ) {
						$res = $account_res;
					}
				}
			}
		}
		
		$page = $user_role === 'subscriber' ? 'user' : ( $user_role === 'visitor' ? 'employee' : 'supplier' );
		
		$return = [
			'main'    => kph_get_template( 'layout/main.php', [ 'page' => "/crm/$page" ] ),
			'data'    => $res['data'],
			'status'  => $res['status'],
			'message' => $res['message'],
		];
		wp_send_json( $return );
	}
	
	public function delete_transfer() {
		$res    = $this->DB->delete_transfer( $_POST['item_id'] );
		$page   = $_POST['page'];
		$return = [
			'main'    => kph_get_template( 'layout/main.php', [ 'page' => $page ] ),
			'status'  => $res['status'],
			'message' => $res['message'],
			'data'    => $res['data'] ?: '',
		];
		wp_send_json( $return );
	}
	
	public function add_cheque() {
		$admin_note = '';
		if ( current_user_can( 'manage_options' ) && isset( $_POST['admin_note'] ) && is_string( $_POST['admin_note'] ) ) {
			$admin_note = sanitize_textarea_field( wp_unslash( $_POST['admin_note'] ) );
			$nonce = isset( $_POST['admin_note_nonce'] ) && is_string( $_POST['admin_note_nonce'] ) ? $_POST['admin_note_nonce'] : '';
			if ( ( $admin_note !== '' || ! empty( $_POST['admin_note_print'] ) ) && ! wp_verify_nonce( $nonce, 'kph_cheque_admin_note' ) ) {
				wp_send_json( [ 'status' => 'error', 'message' => 'اعتبار فرم تمام شده؛ صفحه را تازه کنید.' ] );
			}
		}
		$_POST['meta'] = isset( $_POST['meta'] ) && is_array( $_POST['meta'] ) ? $_POST['meta'] : [];
		unset( $_POST['meta']['admin_note'], $_POST['meta']['admin_note_print'] );
		$_POST['meta']['creator_id'] = get_current_user_id();
		
		$res  = $this->DB->add_cheque( [
			'user_id'   => $_POST['id'],
			'cheque_no' => $_POST['cheque_no'],
			'sayad_id'  => $_POST['sayad_id'],
			'admin_note' => $admin_note,
			'admin_note_print' => current_user_can( 'manage_options' ) && ! empty( $_POST['admin_note_print'] ),
			'bank_name' => $_POST['bank_name'],
			'amount'    => str_replace( ',', '', $_POST['amount'] ),
			'due_at'    => nooshika_jalali_to_gregorian( $_POST['due_at'] ),
			'note'      => isset( $_POST['note'] ) && is_string( $_POST['note'] ) ? sanitize_textarea_field( wp_unslash( $_POST['note'] ) ) : '',
			'meta'      => $_POST['meta'],
		] );
		$user_role = nooshika_get_user_role( $_POST['id'] );
		$page      = $user_role === 'subscriber' ? 'user' : ( $user_role === 'visitor' ? 'employee' : 'supplier' );
		
		$return = [
			'main'    => kph_get_template( 'layout/main.php', [ 'page' => "/crm/$page" ] ),
			'status'  => $res['status'],
			'message' => $res['message'],
			'data'    => $res['data'] ?: '',
		];
		wp_send_json( $return );
	}
	
	public function delete_cheque() {
		$res    = $this->DB->delete_cheque( $_POST['item_id'] );
		$page   = $_POST['page'];
		$return = [
			'main'    => kph_get_template( 'layout/main.php', [ 'page' => $page ] ),
			'status'  => $res['status'],
			'message' => $res['message'],
			'data'    => $res['data'] ?: '',
		];
		wp_send_json( $return );
	}
	
	public function add_account() {
		$account_id = absint( $_POST['account_id'] ?? 0 );
		
		if ( $account_id > 0 ) {
			$res = $this->DB->update_account( $account_id, $_POST );
		} else {
			$res = $this->DB->add_account( $_POST );
		}
		
		$return = [
			'main'    => kph_get_template( 'layout/main.php', [
				'page' => $_POST['page'],
			] ),
			'status'  => $res['status'],
			'message' => $res['message'],
			'data'    => $res['data'] ?? '',
		];
		
		wp_send_json( $return );
	}
	
	public function load_cheque_moves_table() {
		$cheque_moves = $this->DB->get_cheque_moves( $_POST['cheque_id'] );
		$return       = [
			'html' => kph_get_template( 'partials/cheque-moves.php', [
				'moves' => $cheque_moves,
				'DB'    => $this->DB,
			] ),
		];
		wp_send_json( $return );
	}
	
	public function load_cheques_list() {
		$in_hands = $this->DB->get_cheques( [
			'page'     => $_POST['page_number'],
			'per_page' => 5,
			'status'   => 'in_hand',
		] );
		$return   = [
			'html' => kph_get_template( 'partials/in-hand-table.php', [
				'in_hands'    => $in_hands,
				'DB'          => $this->DB,
				'page_number' => $_POST['page_number'],
			] ),
		];
		wp_send_json( $return );
	}
	
	public function load_inventory_table() {
		$return = [
			'html' => kph_get_template( 'partials/inventory-table.php', [
				'DB'           => $this->DB,
				'page_number'  => $_POST['page_number'],
				'inventory_id' => $_POST['inventory_id'],
			] ),
		];
		wp_send_json( $return );
	}
	
	public function change_cheque_status() {
		$res = $this->DB->add_cheque_move( [
			'cheque_id'  => $_POST['cheque_id'],
			'action'     => $_POST['status'],
			'account_id' => $_POST['account_id'],
		] );
		
		$return = [
			'main'    => kph_get_template( 'layout/main.php', [ 'page' => "/crm/finance-cheque" ] ),
			'status'  => $res['status'],
			'message' => $res['message'],
			'data'    => $res['data'] ?: '',
		];
		wp_send_json( $return );
	}
	
	public function refer_cheque_to_user() {
		$cheque_id  = isset( $_POST['cheque_to_refer'] ) ? (int) $_POST['cheque_to_refer'] : 0;
		$user_id    = isset( $_POST['id'] ) ? (int) $_POST['id'] : 0;
		$invoice_id = isset( $_POST['invoice_id'] ) ? (int) $_POST['invoice_id'] : 0;
		$note       = isset( $_POST['note'] ) ? sanitize_text_field( wp_unslash( $_POST['note'] ) ) : '';
		
		$res = $this->DB->add_cheque_move( [
			'cheque_id'      => $cheque_id,
			'action'         => 'endorse',
			'holder_user_id' => $user_id,
			'holder_type'    => 'user',
			'note'           => $note ?: 'واگذاری چک به کاربر #',
			'actor_user_id'  => get_current_user_id(),
			'created_at'     => current_time( 'mysql', TRUE ),
			'meta'           => [
				'invoice_id' => $invoice_id,
				'action'     => 'refer_to_user',
			],
		] );
		
		$return = [
			'main'    => kph_get_template( 'layout/main.php', [ 'page' => $_POST['page'] ] ),
			'status'  => $res['status'],
			'message' => $res['message'],
			'data'    => $res['data'] ?: '',
		];
		wp_send_json( $return );
	}
	
	public function add_account_transaction() {
		$time            = nooshika_sanitize_numbers( $_POST['created_at_time'] );
		$created_at_date = date( 'Y-m-d', strtotime( nooshika_jalali_to_gregorian( $_POST['created_at'] ) ) );
		$created_at_time = ! empty( $time ) ? date( 'H:i:s', strtotime( sanitize_text_field( $time ) ) ) : ( $created_at_date === current_time( 'Y-m-d' ) ? current_time( 'H:i:s' ) : '00:00:00' );
		$res             = $this->DB->add_account_transaction( [
			'account_id'  => $_POST['account_id'],
			'amount'      => str_replace( ',', '', $_POST['amount'] ),
			'type'        => $_POST['type'],
			'action'      => 'manual_transaction',
			'description' => $_POST['description'],
			'meta'        => $_POST['meta'],
			'created_at'  => $created_at_date . ' ' . $created_at_time,
		] );
		
		$return = [
			'main'    => kph_get_template( 'layout/main.php', [ 'page' => $_POST['page'] ] ),
			'status'  => $res['status'],
			'message' => $res['message'],
			'data'    => $res['data'] ?: '',
		];
		wp_send_json( $return );
	}
	
	public function submit_wasted_batch() {
		$res = $this->DB->submit_storage_move( [
			'batch_id'   => $_POST['item_id'],
			'direction'  => 'out',
			'reason'     => 'waste',
			'qty_weight' => nooshika_sanitize_numbers( $_POST['wasted_weight'] ) / 1000,
			'note'       => 'ثبت هدر رفت',
		] );
		
		$return = [
			'main'    => kph_get_template( 'layout/main.php', [ 'page' => $_POST['page'] ] ),
			'status'  => $res['status'],
			'message' => $res['message'],
			'data'    => $res['data'] ?: '',
		];
		wp_send_json( $return );
	}
	
	public function delete_batch_move() {
		$res = $this->DB->delete_storage_move( $_POST['item_id'], );
		
		$return = [
			'main'    => kph_get_template( 'layout/main.php', [ 'page' => $_POST['page'] ] ),
			'status'  => $res['status'],
			'message' => $res['message'],
			'data'    => $res['data'] ?: '',
		];
		wp_send_json( $return );
	}
	
	public function load_batch_storage_move() {
		$return = [
			'html' => kph_get_template( 'partials/batch-moves.php', [
				'batch_id' => $_POST['item_id'],
				'DB'       => $this->DB,
			] ),
		];
		wp_send_json( $return );
	}
	
	public function return_processing_pack_to_storage() {
		$res = $this->DB->return_processing_pack_to_storage( [
			'pack_id' => absint(
				$_POST['pack_id'] ?? 0
			),
			
			'raw_product_id' => absint(
				$_POST['raw_product_id'] ?? 0
			),
			
			'note' => sanitize_textarea_field(
				wp_unslash( $_POST['note'] ?? '' )
			),
		] );
		
		wp_send_json( [
			'main'    => kph_get_template( 'layout/main.php', [
				'page' => '/crm/produce-packaging',
			] ),
			'status'  => $res['status'],
			'message' => $res['message'],
			'data'    => $res['data'] ?: '',
		] );
	}
	
	public function create_processing_pack() {
		$batch_ids  = $_POST['batch_to_process'];
		$qty_weight = $_POST['qty_weight'];
		$inputs     = [];
		foreach ( $batch_ids as $batch_id ) {
			$inputs[] = [
				'batch_id'   => $batch_id,
				'qty_weight' => nooshika_sanitize_numbers( $qty_weight[ $batch_id ] ),
			];
		}
		
		$res = $this->DB->create_processing_pack( [
			'inputs' => $inputs,
			'meta'   => [
				'category_id' => $_POST['category_id'],
				'pack_code'   => $_POST['pack_code'],
				'note'        => $_POST['note'],
			],
		] );
		
		$return = [
			'main'    => kph_get_template( 'layout/main.php', [ 'page' => $_POST['page'] ] ),
			'status'  => $res['status'],
			'message' => $res['message'],
			'data'    => $res['data'] ?: '',
		];
		wp_send_json( $return );
	}
	
	public function load_processing_to_packaging_report() {
		$return = [
			'html' => kph_get_template( 'partials/pack-moves.php', [
				'pack_id' => $_POST['item_id'],
				'DB'      => $this->DB,
			] ),
		];
		wp_send_json( $return );
	}
	
	public function load_processing_pack_inputs() {
		$return = [
			'html' => kph_get_template( 'partials/pack-inputs.php', [
				'pack_id' => $_POST['item_id'],
				'DB'      => $this->DB,
			] ),
		];
		wp_send_json( $return );
	}
	
	public function load_lot_moves() {
		$return = [
			'html' => kph_get_template( 'partials/lot-moves.php', [
				'lot_id' => $_POST['item_id'],
				'DB'     => $this->DB,
			] ),
		];
		wp_send_json( $return );
	}
	
	public function load_inventory_logs() {
		$return = [
			'html' => kph_get_template( 'partials/inventory-log.php', [
				'inventory_id' => $_POST['item_id'],
				'DB'           => $this->DB,
			] ),
		];
		wp_send_json( $return );
	}
	
	public function transfer_pack_to_packaging() {
		$res = $this->DB->transfer_processing_pack_to_packaging( [
			'pack_id'    => $_POST['item_id'],
			'qty_weight' => nooshika_sanitize_numbers( $_POST['qty_weight'] ),
		] );
		
		$return = [
			'main'    => kph_get_template( 'layout/main.php', [ 'page' => $_POST['page'] ] ),
			'status'  => $res['status'],
			'message' => $res['message'],
			'data'    => $res['data'] ?: '',
		];
		wp_send_json( $return );
	}
	
	public function delete_processing_pack_item() {
		$res = $this->DB->delete_processing_pack( $_POST['item_id'] );
		
		$return = [
			'main'    => kph_get_template( 'layout/main.php', [ 'page' => $_POST['page'] ] ),
			'status'  => $res['status'],
			'message' => $res['message'],
			'data'    => $res['data'] ?: '',
		];
		wp_send_json( $return );
	}
	
	public function submit_wasted_packaging_lot() {
		$res = $this->DB->register_packaging_waste( [
			'lot_id'     => $_POST['item_id'],
			'qty_weight' => nooshika_sanitize_numbers( $_POST['wasted_weight'] ) / 1000,
			'note'       => 'ثبت هدر رفت',
		] );
		
		$return = [
			'main'    => kph_get_template( 'layout/main.php', [ 'page' => $_POST['page'] ] ),
			'status'  => $res['status'],
			'message' => $res['message'],
			'data'    => $res['data'] ?: '',
		];
		wp_send_json( $return );
	}
	
	public function delete_lot_move() {
		$res = $this->DB->remove_packaging_waste( $_POST['item_id'] );
		
		$return = [
			'main'    => kph_get_template( 'layout/main.php', [ 'page' => $_POST['page'] ] ),
			'status'  => $res['status'],
			'message' => $res['message'],
			'data'    => $res['data'] ?: '',
		];
		wp_send_json( $return );
	}
	
	public function set_inventory_item_price() {
		$res = $this->DB->update_inventory_balance_meta(
			$_POST['item_id'],
			'sale_price',
			str_replace( ',', '', $_POST['sale_price'] )
		);
		
		$return = [
			'main'    => kph_get_template( 'layout/main.php', [ 'page' => $_POST['page'] ] ),
			'status'  => $res['status'],
			'message' => $res['message'],
			'data'    => $res['data'] ?: '',
		];
		wp_send_json( $return );
	}
	
	public function return_lot_to_processing() {
		$res = $this->DB->return_packaging_lot_to_processing( [
			'lot_id'     => $_POST['item_id'],
			'qty_weight' => nooshika_sanitize_numbers( $_POST['qty_weight'] ),
			'note'       => 'بازگشت به مخزن',
		] );
		
		$return = [
			'main'    => kph_get_template( 'layout/main.php', [ 'page' => $_POST['page'] ] ),
			'status'  => $res['status'],
			'message' => $res['message'],
			'data'    => $res['data'] ?: '',
		];
		wp_send_json( $return );
	}
	
	public function convert_packaging_lot_to_shop_product() {
		$this->require_production_access();
		$mapping = $this->DB->get_production_code( absint( $_POST['production_code_id'] ?? 0 ) );
		if ( ! $mapping ) { wp_send_json( [ 'status' => 'error', 'message' => 'محصول و کد تولید را از فهرست مشترک انتخاب کنید.' ] ); }
		$total_weight_gram = isset( $_POST['total_weight'] )
			? (string) $_POST['total_weight']
			: '0';
		
		$total_weight_gram = nooshika_sanitize_numbers( $total_weight_gram );
		
		$weight_per_item_gram = isset( $_POST['weight_per_item'] )
			? (string) $_POST['weight_per_item']
			: '0';
		
		$weight_per_item_gram = nooshika_sanitize_numbers( $weight_per_item_gram );
		
		// حذف جداکننده هزارگان
		$total_weight_gram    = str_replace( ',', '', $total_weight_gram );
		$weight_per_item_gram = str_replace( ',', '', $weight_per_item_gram );
		
		$pack_cost_raw = str_replace( ',', '', nooshika_sanitize_numbers( (string) ( $_POST['packaging_cost_per_item'] ?? '' ) ) );
		if (
			! preg_match( '/^[0-9]+(?:\.[0-9]{1,6})?$/D', $total_weight_gram ) ||
			! preg_match( '/^[0-9]+(?:\.[0-9]{1,6})?$/D', $weight_per_item_gram ) ||
			! preg_match( '/^[0-9]+(?:\.[0-9]{1,2})?$/D', $pack_cost_raw ) ||
			bccomp( $total_weight_gram, '0', 6 ) <= 0 ||
			bccomp( $weight_per_item_gram, '0', 6 ) <= 0
		) {
			wp_send_json( [
				'main'    => kph_get_template( 'layout/main.php', [
					'page' => $_POST['page'],
				] ),
				'status'  => 'error',
				'message' => 'مقادیر وزن نامعتبر است.',
			] );
		}
		
		/**
		 * تعداد محصول
		 *
		 * چون هر دو مقدار بر حسب گرم هستند:
		 * 3526 / 250 = 14.104
		 * نتیجه نهایی = 14 عدد
		 */
		$qty_items = (int) floor(
			(float) bcdiv(
				$total_weight_gram,
				$weight_per_item_gram,
				6
			)
		);
		
		/**
		 * تبدیل وزن هر محصول از گرم به کیلوگرم
		 *
		 * مثال:
		 * 250 گرم => 0.250 کیلوگرم
		 */
		$weight_per_item = bcdiv(
			$weight_per_item_gram,
			'1000',
			6
		);
		$res             = $this->DB->convert_packaging_lot_to_shop_product( [
			'lot_id'                  => $_POST['lot_id'],
			'wc_product_id'           => $mapping['wc_product_id'],
			'production_code_id'      => (int) $mapping['id'],
			'qty_items'               => $qty_items,
			'weight_per_item'         => $weight_per_item,
			'packaging_cost_per_item' => $pack_cost_raw,
			'unique_product_code'     => $mapping['code'],
		] );
		
		$return = [
			'main'    => kph_get_template( 'layout/main.php', [
				'page' => $_POST['page'],
			] ),
			'status'  => $res['status'],
			'message' => $res['message'],
			'data'    => $res['data'] ?: '',
		];
		
		wp_send_json( $return );
	}
	
	public function search_customer_invoice_product() {
		$search_raw = $_POST['search'] ?? '';
		$search     = sanitize_text_field( wp_unslash( $search_raw ) );
		if ( $search == '' ) {
			$result = [
				'message' => 'متن جستجو را وارد کنید.',
				'status'  => 'error',
			];
			wp_send_json( $result );
		}
		$args   = [
			'items' => $this->DB->search_inventory_products( $search ),
		];
		$result = [
			'status' => 'list',
			'html'   => kph_get_template( "misc/products.php", $args ),
		];
		wp_send_json( $result );
	}
	
	public function save_customer_payment_term() {
		$nonce = is_string( $_POST['nonce'] ?? NULL ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';
		if ( ! current_user_can( 'manage_options' ) || ! wp_verify_nonce( $nonce, 'kph_customer_payment_term' ) ) {
			wp_send_json( [ 'status' => 'error', 'message' => 'اجازه ثبت مهلت را ندارید؛ صفحه را تازه کنید.' ], 403 );
		}
		wp_send_json( $this->DB->save_customer_payment_term( absint( $_POST['order_id'] ?? 0 ), wp_unslash( $_POST['payment_term_days'] ?? '' ) ) );
	}

	public function submit_customer_order() {
		$this->require_visitor_order_access( 'order_id', FALSE, TRUE );
		$res = $this->DB->add_or_update_order( $_POST );
		
		$return = [
			'main'    => kph_get_template( 'layout/main.php', [ 'page' => "/crm/user" ] ),
			'status'  => $res['status'],
			'message' => $res['message'],
			'data'    => $res['data'] ?: '',
		];
		wp_send_json( $return );
	}
	
	public function check_customer_proforma() {
		$res = $this->DB->get_customer_open_proforma( $_POST['customer_id'] );
		
		$return = [
			'order_id' => $res['id'] ?? 0,
		];
		wp_send_json( $return );
	}
	
	public function change_order_status() {
		$this->require_visitor_order_access( 'order_id' );
		$res    = $this->DB->update_order_status( $_POST['order_id'], $_POST['status'] );
		$return = [
			'main'    => kph_get_template( 'layout/main.php', [ 'page' => '/crm/user' ] ),
			'status'  => $res['status'],
			'message' => $res['message'],
		];
		wp_send_json( $return );
	}
	
	public function load_order_items() {
		$this->require_visitor_order_access( 'item_id' );
		$return = [
			'html' => kph_get_template( 'partials/order-items.php', [
				'DB'       => $this->DB,
				'order_id' => $_POST['item_id'],
			] ),
		];
		wp_send_json( $return );
	}
	
	public function load_order_fulfillment() {
		$this->require_visitor_order_access( 'item_id' );
		$return = [
			'html' => kph_get_template( 'partials/order-fulfillments.php', [
				'DB'       => $this->DB,
				'order_id' => $_POST['item_id'],
			] ),
		];
		wp_send_json( $return );
	}
	
	public function load_order_financial() {
		$this->require_visitor_order_access( 'item_id' );
		$return = [
			'html' => kph_get_template( 'partials/order-fin.php', [
				'DB'       => $this->DB,
				'order_id' => $_POST['item_id'],
			] ),
		];
		wp_send_json( $return );
	}
	
	public function add_order_item_fulfillment() {
		$this->require_visitor_order_access( 'item_id', TRUE );
		$res             = $this->DB->add_fulfillment(
			absint( $_POST['item_id'] ?? 0 ),
			absint( nooshika_sanitize_numbers( $_POST['total_qty'] ?? 0 ) ),
			absint( $_POST['inventory_id'] ?? 0 ),
			[
				'shipping_method' => $_POST['shipping_method'],
			]
		);
		$_REQUEST['tab'] = 'orders';
		$_REQUEST['id']  = $this->DB->get_customer_id_by_order_item( $_POST['item_id'] );
		
		$return = [
			'main'    => kph_get_template( 'layout/main.php', [ 'page' => '/crm/user' ] ),
			'status'  => $res['status'],
			'message' => $res['message'],
		];
		wp_send_json( $return );
	}
	
	public function send_order_sms() {
		$this->require_visitor_order_access( 'order_id' );
		$order_id = $_POST['order_id'];
		$template = $_POST['template'];
		if ( $template == 'order2' || $template == 'order3' || $template == 'completed-order' ) {
			$order_data   = $this->DB->get_order_data( $order_id );
			$user_id      = (int) ( $order_data['customer_id'] ?? 0 );
			$order_number = $this->DB->get_order_meta( $order_id, 'factor_number' );
			kph_send_pattern_sms_to_user( $user_id, $template, [
				'token2'  => $order_number,
				'token3'  => $_POST['shipping_method'],
				'token10' => home_url( "/?action=print&type=c-factor&ids=$order_id" ),
			] );
		}
		$return = [
			'main'    => kph_get_template( 'layout/main.php', [ 'page' => '/crm/user' ] ),
			'status'  => 'success',
			'message' => 'پیامک ارسال شد.',
		];
		wp_send_json( $return );
	}
	
	public function cancel_remaining_item() {
		$this->require_visitor_order_access( 'item_id', TRUE );
		$res = $this->DB->clear_order_item_qty( $_POST['item_id'], $_POST['qty'], $_POST['free_qty'] );
		
		$_REQUEST['tab'] = 'orders';
		$_REQUEST['id']  = $this->DB->get_customer_id_by_order_item( $_POST['item_id'] );
		
		$return = [
			'main'    => kph_get_template( 'layout/main.php', [ 'page' => '/crm/user' ] ),
			'status'  => $res['status'],
			'message' => $res['message'],
		];
		wp_send_json( $return );
	}
	
	public function cancel_sended_product() {
		$this->require_visitor_order_access( 'item_id', TRUE );
		$res             = $this->DB->cancel_sended_product_qty( $_POST['item_id'], $_POST['refund_qty'], $_POST['free_qty'] );
		$_REQUEST['tab'] = 'orders';
		$_REQUEST['id']  = $this->DB->get_customer_id_by_order_item( $_POST['item_id'] );
		$return          = [
			'main'    => kph_get_template( 'layout/main.php', [ 'page' => '/crm/user' ] ),
			'status'  => $res['status'],
			'message' => $res['message'],
		];
		wp_send_json( $return );
	}
	
	public function submit_new_action_for_user() {
		$res = $this->DB->add_user_action( [
			'user_id'    => $_POST['id'],
			'title'      => $_POST['title'],
			'content'    => $_POST['description'],
			'attachment' => $_POST['attachment'],
			'meta'       => [],
		] );
		
		$return = [
			'main'    => kph_get_template( 'layout/main.php', [ 'page' => '/crm/user' ] ),
			'status'  => $res['status'],
			'message' => $res['message'],
		];
		wp_send_json( $return );
	}
	
	public function delete_customer_proforma() {
		$this->require_visitor_order_access( 'item_id' );
		$order_id = isset( $_POST['item_id'] )
			? absint( $_POST['item_id'] )
			: 0;
		
		$nonce = isset( $_POST['nonce'] )
			? sanitize_text_field( wp_unslash( $_POST['nonce'] ) )
			: '';
		
		if ( ! is_user_logged_in() ) {
			wp_send_json( [
				'status'  => 'error',
				'message' => 'برای انجام این عملیات باید وارد حساب کاربری شوید.',
			], 403 );
		}
		
		$user_role = nooshika_get_user_role( get_current_user_id() );
		
		if ( ! in_array( $user_role, [ 'administrator', 'visitor' ], TRUE ) ) {
			wp_send_json( [
				'status'  => 'error',
				'message' => 'شما اجازه حذف پیش‌فاکتور را ندارید.',
			], 403 );
		}
		
		if (
			$order_id <= 0 ||
			! wp_verify_nonce(
				$nonce,
				'kph_delete_customer_proforma_' . $order_id
			)
		) {
			wp_send_json( [
				'status'  => 'error',
				'message' => 'درخواست حذف معتبر نیست.',
			], 403 );
		}
		
		$res = $this->DB->delete_customer_proforma( $order_id );
		
		$page = isset( $_POST['page'] )
			? sanitize_text_field( wp_unslash( $_POST['page'] ) )
			: '/crm/orders-list';
		
		if ( ! in_array( $page, [
			'/crm/user',
			'/crm/orders-list',
		], TRUE ) ) {
			$page = '/crm/orders-list';
		}
		
		if (
			$res['status'] === 'success' &&
			$page === '/crm/user'
		) {
			$_REQUEST['id']  = (int) ( $res['data']['customer_id'] ?? 0 );
			$_REQUEST['tab'] = 'orders';
		}
		
		wp_send_json( [
			'main'    => kph_get_template( 'layout/main.php', [
				'page' => $page,
			] ),
			'status'  => $res['status'],
			'message' => $res['message'],
			'data'    => $res['data'] ?? [],
		] );
	}
	
}
