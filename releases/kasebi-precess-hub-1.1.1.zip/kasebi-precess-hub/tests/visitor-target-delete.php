<?php
/** Run: php -d extension=pdo_sqlite tests/visitor-target-delete.php */
if ( PHP_SAPI !== 'cli' ) { exit; }
require __DIR__ . '/visitor-targets.php';
$delete_id = array_key_first( $DB->get_visitor_targets(20) );
function delete_result() {
    global $ajax;
    try { $ajax->delete_visitor_target(); } catch ( JsonResponse $e ) { return $e->response; }
    throw new Exception('No response');
}
$_POST = ['id'=>20,'item_id'=>$delete_id,'nonce'=>'valid-kph_delete_visitor_target_20_'.$delete_id];
$authorized = FALSE;
check(delete_result()['status']==='error' && isset($DB->get_visitor_targets(20)[$delete_id]),'unauthorized deletion blocked');
$authorized = TRUE;
$_POST['nonce'] = ['malformed'];
check(delete_result()['status']==='error','malformed deletion nonce blocked');
$_POST['nonce'] = 'invalid';
check(delete_result()['status']==='error','invalid deletion nonce blocked');
check($DB->delete_visitor_target(30,$delete_id)['status']==='error','cannot delete another visitor target');
check($DB->delete_visitor_target(10,$target_id)['status']==='error' && isset($DB->get_visitor_targets(10)[$target_id]),'reward history retained even after reversal');
$_POST['nonce']='valid-kph_delete_visitor_target_20_'.$delete_id;
check(delete_result()['status']==='success' && !$DB->get_visitor_targets(20),'authorized target deletion succeeds');
check($_REQUEST['tab']==='targets' && !isset($_REQUEST['target_id']),'refresh returns to target list');
check($DB->delete_visitor_target(20,$delete_id)['status']==='error','repeated deletion fails safely');
check($DB->save_visitor_target(20,$target)['status']==='success','deleted period can be reused');
