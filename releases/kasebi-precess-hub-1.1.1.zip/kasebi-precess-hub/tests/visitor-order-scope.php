<?php
/** Run: php -d extension=pdo_sqlite tests/visitor-order-scope.php */
if ( PHP_SAPI !== 'cli' ) { exit; }
require __DIR__ . '/visitor-targets.php';
$wpdb->query('ALTER TABLE wp_kph_orders ADD COLUMN total_payable REAL DEFAULT 1000');
$wpdb->query('CREATE TABLE wp_kph_order_items (id INTEGER PRIMARY KEY, order_id INTEGER, qty_ordered INTEGER, shipped_paid_qty INTEGER, expected_free_qty INTEGER, shipped_free_qty INTEGER)');
$rc->getProperty('order_items')->setValue($DB,'wp_kph_order_items');
$wpdb->query('INSERT INTO wp_kph_order_items VALUES (40,4,2,1,0,0),(10,1,2,1,0,0)');
$scope_test_user=10;
check(array_column($DB->get_orders_list()['items'],'id')===[4],'visitor sees only orders created by session identity');
check(array_column($DB->get_orders_list(['customer_marketer_id'=>20,'visitor_id'=>20,'marketer_id'=>20])['items'],'id')===[4],'assignment filters cannot override creator scope');
check(!$DB->get_orders_list(['customer_id'=>100])['items'],'shared customer does not grant access to another creator orders');
check($DB->get_order_data(1)===[] && count($DB->get_order_data(4)['items'])===1,'direct order detail is scoped');
check(!$DB->visitor_can_access_order(10,TRUE) && $DB->visitor_can_access_order(40,TRUE),'item ownership resolves to order creator');
check($DB->get_order_items(1)===[],'foreign item query returns no rows');
check($DB->add_or_update_order(['order_id'=>1,'created_by'=>10])['status']==='error','cannot take over foreign order by spoofing creator');
check($DB->get_customer_open_proforma(102)===[],'foreign open proforma is not disclosed');
$wpdb->insert('wp_kph_orders',['id'=>7,'customer_id'=>102,'created_by'=>10,'status'=>'proforma','created_at'=>'2026-09-28 12:00:00']);
check($DB->get_customer_open_proforma(102)['id']==7,'own open proforma selected for shared customer');
$monthly=$DB->get_visitor_monthly_sales([20],'2026-09-01 00:00:00','2026-09-30 23:59:59');
check(array_keys($monthly)===[10] && array_column($monthly[10]['items'],'id')===[7],'monthly report ignores requested visitor and assigned orders by others');
$_POST=['item_id'=>1];
try {$ajax->load_order_fulfillment(); throw new Exception('Access was not denied');}
catch(JsonResponse $e){check($e->response['status']==='error','AJAX shipment detail denies foreign order');}
$_POST=['item_id'=>10];
try {$ajax->cancel_sended_product(); throw new Exception('Access was not denied');}
catch(JsonResponse $e){check($e->response['status']==='error','AJAX order-item mutation denies foreign order');}
$scope_test_user=20;
check(array_column($DB->get_orders_list()['items'],'id')===[5],'another visitor has a separate creator scope');
$scope_test_user=1;
check($DB->get_orders_list()['pagination']['total']===7,'management retains all orders');
