<?php
if ( PHP_SAPI !== 'cli' ) { exit; }
define('ABSPATH', __DIR__);
define('KPH_TEMPLATE_PATH', __DIR__ . '/nonexistent-templates/');
function get_current_user_id(){return 10;}
function nooshika_get_user_role($id){return 'visitor';}
function sanitize_key($value){return $value;}
function wp_die($message,...$args){throw new RuntimeException($message);}
function apply_filters($name,$value,...$args){return $value;}
class kph_db { public function visitor_can_access_order(int $id):bool{return $id===4;} }
require dirname(__DIR__).'/includes/helper.php';
foreach ([['factor',['ids'=>[1]]],['c-factor',['ids'=>[4,1]]],['fulfillments',['request'=>['order_id'=>1]]],['customers-report',[]],['financial',['user_id'=>99]],['financial',['user_id'=>10,'ids'=>[1]]]] as [$type,$args]) {
    try {kph_get_print_template($type,$args);} catch(RuntimeException $e){echo "PASS: blocked $type\n";continue;}
    throw new Exception('Foreign report permitted');
}
if(kph_get_print_template('factor',['ids'=>[4]])!==''){throw new Exception('Unexpected render');}
echo "PASS: own order passes print authorization\n";
if(!str_contains(kph_get_template('partials/order-fulfillments.php',['order_id'=>1]),'اجازه دسترسی')){throw new Exception('Foreign partial allowed');}
echo "PASS: direct partial access blocked\n";
