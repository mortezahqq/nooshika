<?php
/** Standalone privacy regression: php -d extension=pdo_sqlite tests/cheque-admin-note.php
 * Tests actual persistence and AJAX validation with WordPress stubs. Cheque accounting is stubbed.
 */
if ( PHP_SAPI !== 'cli' ) { exit; }
define( 'ABSPATH', __DIR__ );
define( 'ARRAY_A', 'ARRAY_A' );
$authorized = TRUE;
function current_user_can( $cap ) { return $cap === 'manage_options' && $GLOBALS['authorized']; }
function get_current_user_id() { return 1; }
function wp_parse_args( $args, $defaults ) { return array_merge( $defaults, $args ); }
function sanitize_textarea_field( $value ) { return trim( strip_tags( $value ) ); }
function wp_unslash( $value ) { return stripslashes( $value ); }
function wp_create_nonce( $action ) { return 'valid-' . $action; }
function wp_verify_nonce( $nonce, $action ) { return $nonce === wp_create_nonce( $action ); }
function nooshika_sanitize_numbers( $value ) { return $value; }
function nooshika_jalali_to_gregorian( $value ) { return '2026-10-01'; }
function nooshika_get_user_role( $id ) { return 'subscriber'; }
function current_time( $format, $gmt = FALSE ) { return '2026-09-28 12:00:00'; }
function maybe_serialize( $value ) { return is_array( $value ) ? serialize( $value ) : $value; }
function maybe_unserialize( $value ) { return $value; }
function do_action( ...$args ) { $GLOBALS['events'][] = $args; }
function esc_html( $value ) { return htmlspecialchars( $value, ENT_QUOTES, 'UTF-8' ); }
function esc_attr( $value ) { return esc_html( $value ); }
function kph_get_template( $path, $args = [] ) { return 'rendered'; }
class JsonResponse extends Exception { public function __construct( public array $response ) { parent::__construct(); } }
function wp_send_json( $response ) { throw new JsonResponse( $response ); }
set_error_handler( static function( $severity, $message, $file, $line ) { throw new ErrorException( $message, 0, $severity, $file, $line ); } );
class wpdb {
    public string $last_error = '';
    public int $insert_id = 0;
    public bool $fail_note = FALSE;
    public PDO $pdo;
    public function __construct() { $this->pdo = new PDO( 'sqlite::memory:' ); $this->pdo->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION ); }
    public function prepare( $sql, ...$args ) {
        $i = 0;
        return preg_replace_callback( '/%[sdf]/', function( $m ) use ( &$i, $args ) {
            $v = $args[ $i++ ]; return $m[0] === '%s' ? $this->pdo->quote( (string) $v ) : (string) (int) $v;
        }, $sql );
    }
    public function query( $sql ) { return $this->pdo->exec( str_replace( 'START TRANSACTION', 'BEGIN TRANSACTION', $sql ) ); }
    public function get_results( $sql, $mode = NULL ) { return $this->pdo->query( $sql )->fetchAll( PDO::FETCH_ASSOC ); }
    public function get_col( $sql ) { return array_map( fn( $r ) => array_values( $r )[0], $this->get_results( $sql ) ); }
    public function insert( $table, $data, $formats = NULL ) {
        if ( $this->fail_note && ( $data['meta_key'] ?? '' ) === 'admin_note' ) { return FALSE; }
        $keys = implode( ',', array_keys( $data ) ); $marks = implode( ',', array_fill( 0, count( $data ), '?' ) );
        $this->pdo->prepare( "INSERT INTO $table ($keys) VALUES ($marks)" )->execute( array_values( $data ) );
        $this->insert_id = (int) $this->pdo->lastInsertId(); return 1;
    }
    public function delete( $table, $where, $formats = NULL ) {
        $conditions = implode( ' AND ', array_map( fn( $k ) => "$k=?", array_keys( $where ) ) );
        $stmt = $this->pdo->prepare( "DELETE FROM $table WHERE $conditions" ); $stmt->execute( array_values( $where ) ); return $stmt->rowCount();
    }
}
require dirname( __DIR__ ) . '/Core/kph_db.php';
require dirname( __DIR__ ) . '/Core/kph_ajax.php';
class ChequeTestDB extends kph_db {
    public array $moves = [];
    public function __construct() {}
    public function add_cheque_move( array $data ): array {
        $this->moves[] = $data;
        $GLOBALS['wpdb']->query( 'COMMIT' );
        return [ 'status'=>'success', 'data'=>['id'=>1] ];
    }
}
$wpdb = new wpdb();
$wpdb->query( 'CREATE TABLE wp_kph_cheques (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, cheque_no TEXT, sayad_id TEXT, bank_name TEXT, amount REAL, currency TEXT, due_at TEXT, status TEXT, issuer_user_id INTEGER, current_holder_user_id INTEGER, created_at TEXT, updated_at TEXT, note TEXT)' );
$wpdb->query( 'CREATE TABLE wp_kph_cheque_meta (id INTEGER PRIMARY KEY AUTOINCREMENT, cheque_id INTEGER, meta_key TEXT COLLATE NOCASE, meta_value TEXT)' );
$DB = new ChequeTestDB();
$rc = new ReflectionClass( kph_db::class );
foreach ( [ 'db'=>$wpdb, 'db_prefix'=>'wp_kph_', 'cheques'=>'wp_kph_cheques', 'meta_tables'=>['cheque'=>'cheque_id'], 'meta_aliases'=>[] ] as $key=>$value ) { $rc->getProperty( $key )->setValue( $DB, $value ); }
$checks = 0;
function check( $condition, $label ) { global $checks; if ( ! $condition ) { throw new Exception( 'FAIL: ' . $label ); } $checks++; echo "PASS: $label\n"; }
function render_note( $id, $field = FALSE ) {
    global $DB; $cheque_id = $id;
    ob_start(); include dirname( __DIR__ ) . '/templates/components/cheque-admin-note' . ( $field ? '-field' : '' ) . '.php'; return ob_get_clean();
}
$base = [ 'user_id'=>10, 'cheque_no'=>'123', 'amount'=>1000, 'due_at'=>'2026-10-01' ];
$private = "یادداشت محرمانه\nخط دوم";
$res = $DB->add_cheque( $base + [ 'admin_note'=>$private, 'note'=>'public', 'meta'=>['admin_note'=>'forged', 'ADMIN_NOTE'=>'forged', 'branch'=>'Tehran'] ] );
$id = $res['data']['id'];
check( $res['status'] === 'success' && $DB->get_cheque_meta( $id, 'admin_note' ) === $private, 'admin note persisted separately, multiline preserved' );
check( $wpdb->get_col( 'SELECT note FROM wp_kph_cheques' ) === ['public'] && $DB->moves[0]['note'] === 'public', 'public cheque and movement notes unchanged' );
check( ! str_contains( json_encode( $GLOBALS['events'], JSON_UNESCAPED_UNICODE ), $private ) && ! isset( $GLOBALS['events'][0][2]['meta']['ADMIN_NOTE'] ), 'private note excluded from cheque event and notification payload' );
check( str_contains( render_note( $id, TRUE ), 'data-for="admin_note"' ) && str_contains( render_note( $id ), esc_html( $private ) ), 'admin form and saved note visible' );
$authorized = FALSE;
check( render_note( $id, TRUE ) === '' && render_note( $id ) === '', 'non-admin receives no field or display markup' );
check( $DB->get_cheque_meta( $id, 'admin_note' ) === NULL && $DB->get_meta( 'cheques', $id, 'ADMIN_NOTE' ) === [] && $DB->get_meta( 'cheque_meta', $id, 'admin_note ' ) === [], 'direct reads and case variants blocked' );
check( $DB->get_cheque_meta( $id ) === ['branch'=>['Tehran']] && $DB->get_cheque_meta( $id, 'branch' ) === 'Tehran', 'bulk reads hide private note and preserve public metadata' );
check( $DB->update_cheque_meta( $id, 'ADMIN_NOTE', 'overwritten' )['status'] === 'error', 'non-admin direct write rejected' );
$DB->save_meta_batch( 'cheque', $id, ['admin_note'=>'overwritten', 'ADMIN_NOTE'=>'overwritten', 'branch'=>'Shiraz'] );
$res = $DB->add_cheque( $base + [ 'admin_note'=>$private, 'meta'=>['admin_note'=>$private, 'ADMIN_NOTE'=>$private] ] );
check( $res['status'] === 'success' && count( $wpdb->get_col( 'SELECT meta_value FROM wp_kph_cheque_meta WHERE meta_key="admin_note"' ) ) === 1, 'forged non-admin creation and batch writes cannot store private notes' );
$authorized = TRUE;
check( $DB->get_cheque_meta( $id, 'admin_note' ) === $private && $DB->get_cheque_meta( $id, 'branch' ) === 'Shiraz', 'forged batch cannot overwrite existing note' );
$DB->update_cheque_meta( $id, 'admin_note', '<img src=x onerror=alert(1)>' );
check( ! str_contains( render_note( $id ), '<img' ) && str_contains( render_note( $id ), '&lt;img' ), 'saved text escaped on display' );
$res = $DB->add_cheque( $base + ['admin_note'=>str_repeat( 'ی', 5001 )] );
check( $res['status'] === 'error', 'oversized note rejected' );
$before = count( $wpdb->get_col( 'SELECT id FROM wp_kph_cheques' ) );
$wpdb->fail_note = TRUE;
check( $DB->add_cheque( $base + ['admin_note'=>$private] )['status'] === 'error' && count( $wpdb->get_col( 'SELECT id FROM wp_kph_cheques' ) ) === $before, 'note persistence failure rolls back cheque creation' );
$wpdb->fail_note = FALSE;
$ajax = (new ReflectionClass( kph_ajax::class ))->newInstanceWithoutConstructor(); $ajax->DB = $DB;
function submit() { global $ajax; try { $ajax->add_cheque(); } catch ( JsonResponse $e ) { return $e->response; } throw new Exception( 'No response' ); }
$_POST = ['id'=>10, 'cheque_no'=>'456', 'sayad_id'=>'', 'bank_name'=>'', 'amount'=>'1,000', 'due_at'=>'1405-07-09', 'admin_note'=>$private, 'admin_note_nonce'=>'invalid'];
check( submit()['status'] === 'error' && count( $wpdb->get_col( 'SELECT id FROM wp_kph_cheques' ) ) === $before, 'invalid nonce rejected before mutation' );
$_POST['admin_note_nonce'] = ['malformed'];
check( submit()['status'] === 'error', 'malformed nonce rejected without warnings' );
$_POST['admin_note_nonce'] = wp_create_nonce( 'kph_cheque_admin_note' );
$_POST['admin_note'] = "<b>Internal</b>\nO\\'Reilly";
$res = submit();
check( $res['status'] === 'success' && $DB->get_cheque_meta( $res['data']['id'], 'admin_note' ) === "Internal\nO'Reilly", 'AJAX sanitizes and unslashes note; absent public note accepted' );
unset( $_POST['admin_note'], $_POST['admin_note_nonce'] );
check( submit()['status'] === 'success', 'optional note not required for registration' );
$authorized = FALSE;
$_POST['admin_note'] = $private; $_POST['meta'] = ['ADMIN_NOTE'=>$private];
$res = submit();
check( $res['status'] === 'success' && $wpdb->get_col( 'SELECT meta_value FROM wp_kph_cheque_meta WHERE cheque_id=' . (int) $res['data']['id'] . ' AND meta_key="admin_note"' ) === [], 'non-admin AJAX forgery ignored while normal cheque creation works' );
echo "$checks checks passed.\n";
