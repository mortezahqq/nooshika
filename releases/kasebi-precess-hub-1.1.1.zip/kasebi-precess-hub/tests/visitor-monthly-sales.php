<?php
/** Run: php -d extension=pdo_sqlite tests/visitor-monthly-sales.php */
if ( PHP_SAPI !== 'cli' ) { exit; }
require __DIR__ . '/visitor-targets.php';
$wpdb->query('ALTER TABLE wp_kph_orders ADD COLUMN total_payable REAL DEFAULT 0');
$wpdb->query('DELETE FROM wp_kph_ledger_entries');
$wpdb->query('DELETE FROM wp_kph_fulfillments');
$wpdb->query('DELETE FROM wp_kph_orders_meta');
$wpdb->query('DELETE FROM wp_kph_orders');
foreach ( [[11,100,10,'registered','2026-08-01',9000],[12,101,10,'proforma','2026-09-23',4000],
    [13,101,10,'proforma','2026-09-22',8000],[14,102,20,'proforma','2026-09-24',3000],
    [15,101,10,'canceled','2026-09-25',6000],[16,101,10,'proforma','2026-10-01',1000]] as $v ) {
    $v[4] .= ' 00:00:00';
    $wpdb->insert('wp_kph_orders',array_combine(['id','customer_id','created_by','status','created_at','total_payable'], $v));
}
$wpdb->insert('wp_kph_orders_meta',['order_id'=>11,'meta_key'=>'marketer_id','meta_value'=>10]);
foreach ([[21,11,'2026-09-23 00:00:00'],[22,11,'2026-09-25 12:00:00'],[23,11,'2026-09-22 23:59:59'],[24,11,'2026-10-01 00:00:00']] as $v) {
    $wpdb->insert('wp_kph_fulfillments',array_combine(['id','order_id','created_at'],$v));
}
foreach ([[21,1000,'debit'],[22,500,'debit'],[22,100,'credit'],[23,700,'debit'],[24,900,'debit']] as [$fid,$amount,$type]) {
    $wpdb->insert('wp_kph_ledger_entries',['user_id'=>100,'entry_type'=>'customer_order','ref_type'=>'fulfillment','ref_id'=>$fid,
        'amount'=>$amount,'type'=>$type,'created_at'=>'2026-09-28 11:00:00']);
}
$res=$DB->get_visitor_monthly_sales([10,20,30],'2026-09-23 00:00:00','2026-09-28 12:00:00');
check($res[10]['shipped']===1400.0,'partial shipments at selling price minus returns, no full invoice amount');
check($res[10]['proforma']===4000.0,'only current-month open proformas, no canceled or future orders');
check(count($res[10]['items'])===2,'multiple shipments grouped into one invoice');
check($res[20]['proforma']===3000.0 && $res[20]['shipped']===0.0,'snapshot retains sales after customer reassignment');
check($res[30]['items']===[] && $res[30]['shipped']===0.0,'empty visitor has zero figures');
check(array_keys($DB->get_visitor_monthly_sales([10],'2026-09-23 00:00:00','2026-09-28 12:00:00'))===[10],'query limits visitor scope');
$wpdb->query("UPDATE wp_kph_orders SET status='registered' WHERE id=12");
check($DB->get_visitor_monthly_sales([10],'2026-09-23 00:00:00','2026-09-28 12:00:00')[10]['proforma']===0.0,'status changes reflected immediately without stale cache');
