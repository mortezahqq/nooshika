<?php
/** Standalone regression tests: php -d extension=pdo_sqlite tests/visitor-targets.php
 * SQLite exercises actual reporting SQL; MySQL row locking requires an integration environment.
 */
if ( PHP_SAPI !== 'cli' ) { exit; }
define( 'ABSPATH', __DIR__ );
define( 'ARRAY_A', 'ARRAY_A' );
define( 'KPH_MARKETER_META', 'user_visitor_id' );
define( 'DAY_IN_SECONDS', 86400 );
function absint( $n ) { return abs( (int) $n ); }
function get_users( $args ) { return [ 10, 20, 30 ]; }
function get_current_user_id() { return $GLOBALS['scope_test_user'] ?? 1; }
function nooshika_get_user_role( $id ) { return in_array( (int) $id, [ 10, 20, 30 ], TRUE ) ? 'visitor' : 'subscriber'; }
function current_time( $format, $gmt = FALSE ) { return $format === 'Y-m-d' ? '2026-09-28' : '2026-09-28 12:00:00'; }
function wp_parse_args( $args, $defaults ) { return array_merge( $defaults, $args ); }
function maybe_serialize( $value ) { return is_array( $value ) ? serialize( $value ) : $value; }
function maybe_unserialize( $value ) { return is_string( $value ) && str_starts_with( $value, 'a:' ) ? unserialize( $value, [ 'allowed_classes' => FALSE ] ) : $value; }
function sanitize_text_field( $value ) { return trim( strip_tags( $value ) ); }
function sanitize_key( $value ) { return preg_replace( '/[^a-z0-9_-]/', '', $value ); }
function wp_cache_delete( ...$args ) {}
function get_user_meta( $id, $key, $single = TRUE ) {
    global $wpdb;
    return $wpdb->get_var( $wpdb->prepare( 'SELECT meta_value FROM wp_usermeta WHERE user_id = %d AND meta_key = %s ORDER BY umeta_id LIMIT 1', $id, $key ) ) ?: '';
}
function nooshika_jalali_to_gregorian( $date ) {
    // Known calendar fixtures; production uses the existing Nooshika converter.
    return [ '1403-01-01' => '2024-03-20', '1404-01-01' => '2025-03-21', '1405-01-01' => '2026-03-21',
        '1406-01-01' => '2027-03-21', '1403-12-30' => '2025-03-20',
        '1405-07-01' => '2026-09-23', '1405-07-30' => '2026-10-22',
        '1405-08-01' => '2026-10-23', '1405-08-30' => '2026-11-21' ][ $date ] ?? throw new Exception( 'Missing date fixture: ' . $date );
}
class wpdb {
    public string $prefix = 'wp_', $users = 'wp_users', $usermeta = 'wp_usermeta', $last_error = '';
    public int $insert_id = 0;
    public PDO $pdo;
    public bool $fail_bonus = FALSE;
    public function __construct() { $this->pdo = new PDO( 'sqlite::memory:' ); $this->pdo->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION ); }
    public function prepare( $sql, ...$args ) {
        if ( count( $args ) === 1 && is_array( $args[0] ) ) { $args = $args[0]; }
        $i = 0;
        return preg_replace_callback( '/%[sdf]/', function( $m ) use ( &$i, $args ) {
            $v = $args[ $i++ ]; return $m[0] === '%s' ? $this->pdo->quote( (string) $v ) : (string) ( $m[0] === '%d' ? (int) $v : (float) $v );
        }, $sql );
    }
    private function sql( $sql ) { return str_replace( [ ' FOR UPDATE', 'START TRANSACTION' ], [ '', 'BEGIN TRANSACTION' ], $sql ); }
    public function query( $sql ) { $this->last_error = ''; return $this->pdo->exec( $this->sql( $sql ) ); }
    public function get_results( $sql, $mode = NULL ) { $this->last_error = ''; return $this->pdo->query( $this->sql( $sql ) )->fetchAll( PDO::FETCH_ASSOC ); }
    public function get_row( $sql, $mode = NULL ) { return $this->get_results( $sql )[0] ?? NULL; }
    public function get_col( $sql ) { return array_map( fn( $row ) => array_values( $row )[0], $this->get_results( $sql ) ); }
    public function get_var( $sql ) { $r = $this->get_row( $sql ); return $r ? array_values( $r )[0] : NULL; }
    public function insert( $table, $data, $formats = NULL ) {
        if ( $this->fail_bonus && ( $data['entry_type'] ?? '' ) === 'visitor_target_bonus' ) { $this->last_error = 'Injected failure'; return FALSE; }
        $keys = implode( ',', array_keys( $data ) ); $marks = implode( ',', array_fill( 0, count( $data ), '?' ) );
        $this->pdo->prepare( "INSERT INTO $table ($keys) VALUES ($marks)" )->execute( array_values( $data ) );
        $this->insert_id = (int) $this->pdo->lastInsertId(); $this->last_error = ''; return 1;
    }
    public function update( $table, $data, $where, ...$formats ) {
        $set = implode( ',', array_map( fn( $k ) => "$k=?", array_keys( $data ) ) );
        $conditions = implode( ' AND ', array_map( fn( $k ) => "$k=?", array_keys( $where ) ) );
        $stmt = $this->pdo->prepare( "UPDATE $table SET $set WHERE $conditions" );
        $stmt->execute( array_merge( array_values( $data ), array_values( $where ) ) ); return $stmt->rowCount();
    }
    public function delete( $table, $where, $formats = NULL ) {
        $conditions = implode( ' AND ', array_map( fn( $k ) => "$k=?", array_keys( $where ) ) );
        $stmt = $this->pdo->prepare( "DELETE FROM $table WHERE $conditions" ); $stmt->execute( array_values( $where ) ); return $stmt->rowCount();
    }
}
require dirname( __DIR__ ) . '/Core/kph_db.php';
$wpdb = new wpdb();
foreach ( [
    'wp_users (ID INTEGER PRIMARY KEY)',
    'wp_usermeta (umeta_id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, meta_key TEXT, meta_value TEXT)',
    'wp_kph_orders (id INTEGER PRIMARY KEY, customer_id INTEGER, created_by INTEGER, status TEXT, created_at TEXT)',
    'wp_kph_orders_meta (id INTEGER PRIMARY KEY AUTOINCREMENT, order_id INTEGER, meta_key TEXT, meta_value TEXT)',
    'wp_kph_fulfillments (id INTEGER PRIMARY KEY, order_id INTEGER, created_at TEXT)',
    'wp_kph_ledger_entries (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, entry_type TEXT, type TEXT, amount REAL, ref_type TEXT, ref_id INTEGER, posted_at TEXT, created_at TEXT, note TEXT)',
    'wp_kph_ledger_entry_meta (id INTEGER PRIMARY KEY AUTOINCREMENT, entry_id INTEGER, meta_key TEXT, meta_value TEXT)',
] as $schema ) { $wpdb->query( 'CREATE TABLE ' . $schema ); }
$rc = new ReflectionClass( kph_db::class );
$DB = $rc->newInstanceWithoutConstructor();
foreach ( [ 'db' => $wpdb, 'db_prefix' => 'wp_kph_', 'orders' => 'wp_kph_orders', 'fulfillments' => 'wp_kph_fulfillments',
    'ledger_entries' => 'wp_kph_ledger_entries', 'meta_tables' => [ 'orders' => 'order_id', 'ledger_entry' => 'entry_id' ],
    'meta_aliases' => [] ] as $key => $value ) { $rc->getProperty( $key )->setValue( $DB, $value ); }
$checks = 0;
function check( $ok, $label ) { global $checks; if ( ! $ok ) { throw new Exception( 'FAIL: ' . $label ); } $checks++; echo "PASS: $label\n"; }
function meta( $user, $key, $value ) { global $wpdb; $wpdb->insert( 'wp_usermeta', [ 'user_id' => $user, 'meta_key' => $key, 'meta_value' => $value ] ); }
foreach ( [ 1, 10, 20, 30, 100, 101, 102, 103 ] as $id ) { $wpdb->insert( 'wp_users', [ 'ID' => $id ] ); }
meta( 100, 'customer_marketer', 10 ); meta( 100, KPH_MARKETER_META, 20 ); meta( 100, 'customer_marketer', 10 );
meta( 101, KPH_MARKETER_META, 10 ); meta( 102, 'customer_marketer', 20 );
foreach ( [ [1,100,1,'registered'], [2,101,1,'shortage'], [3,102,1,'proforma'], [4,103,10,'registered'], [5,100,20,'shipped'], [6,100,1,'canceled'] ] as [ $id, $customer, $creator, $status ] ) {
    $wpdb->insert( 'wp_kph_orders', [ 'id' => $id, 'customer_id' => $customer, 'created_by' => $creator, 'status' => $status, 'created_at' => '2026-09-28 10:00:00' ] );
}
$wpdb->insert( 'wp_kph_orders_meta', [ 'order_id' => 3, 'meta_key' => 'marketer_id', 'meta_value' => 10 ] );
$s = $DB->get_visitor_summaries( [10,20,30] );
check( $s[10]['open_orders'] === 4 && $s[20]['open_orders'] === 0, 'legacy, snapshot and creator attribution; duplicates do not multiply orders' );
check( $s[30]['customer_balance'] === 0 && $s[30]['open_orders'] === 0, 'visitor without customers has zero statistics' );
$orders = $DB->get_orders_list( [ 'visitor_id' => 10 ] );
check( count( $orders['items'] ) === 6, 'visitor orders use the same attribution including legacy orders' );
$target = [ 'title' => 'مهر', 'date_from' => '1405-07-01', 'date_to' => '1405-07-30', 'amount' => '1000', 'bonus' => '200' ];
check( $DB->save_visitor_target( 10, $target )['status'] === 'success', 'create target' );
$target_id = array_key_first( $DB->get_visitor_targets( 10 ) );
check( $DB->save_visitor_target( 10, $target )['status'] === 'error', 'overlapping target rejected' );
check( $DB->save_visitor_target( 100, $target )['status'] === 'error', 'non-visitor rejected' );
check( $DB->save_visitor_target( 20, array_merge( $target, ['amount'=>'-1'] ) )['status'] === 'error', 'negative amount rejected' );
check( $DB->save_visitor_target( 20, array_merge( $target, ['bonus'=>'1e6'] ) )['status'] === 'error', 'malformed money rejected' );
check( $DB->save_visitor_target( 20, array_merge( $target, ['date_from'=>'1405-07-31'] ) )['status'] === 'error', 'invalid Jalali day rejected' );
check( $DB->save_visitor_target( 20, array_merge( $target, ['date_from'=>'1405-12-30'] ) )['status'] === 'error', 'non-leap Esfand rejected' );
check( $DB->save_visitor_target( 20, array_merge( $target, ['date_from'=>'1405-08-01'] ) )['status'] === 'error', 'reversed dates rejected' );
check( $DB->save_visitor_target( 10, array_merge( $target, ['target_id'=>$target_id, 'title'=>'تارگت مهر'] ) )['status'] === 'success', 'unrewarded target can be edited' );
check( $DB->save_visitor_target( 20, array_merge( $target, ['target_id'=>$target_id] ) )['status'] === 'error', 'cannot edit another visitor target' );
function shipment( $fid, $amount, $side = 'debit', $date = '2026-09-28 12:00:00' ) {
    global $wpdb, $DB;
    if ( ! $wpdb->get_var( 'SELECT id FROM wp_kph_fulfillments WHERE id=' . (int) $fid ) ) { $wpdb->insert( 'wp_kph_fulfillments', [ 'id'=>$fid, 'order_id'=>1, 'created_at'=>$date ] ); }
    $wpdb->query( 'START TRANSACTION' );
    $res = $DB->add_ledger_entry( [ 'user_id'=>100, 'entry_type'=>'customer_order', 'type'=>$side, 'amount'=>$amount, 'ref_type'=>'fulfillment', 'ref_id'=>$fid ] );
    $wpdb->query( $res['status'] === 'success' ? 'COMMIT' : 'ROLLBACK' ); return $res;
}
function target_state() { global $DB, $target_id; return $DB->get_visitor_targets( 10 )[ $target_id ]; }
check( shipment( 1, 600 )['status'] === 'success' && target_state()['reward'] === 0.0, 'no reward below threshold' );
check( shipment( 2, 400 )['status'] === 'success' && target_state()['reward'] === 200.0, 'exact threshold awards bonus without commission configuration' );
shipment( 3, 300 );
check( target_state()['sales'] === 1300.0 && target_state()['reward'] === 200.0, 'more sales do not duplicate reward' );
shipment( 3, 400, 'credit' );
check( target_state()['sales'] === 900.0 && target_state()['reward'] === 0.0, 'return below threshold reverses reward' );
shipment( 4, 200 );
check( target_state()['reward'] === 200.0, 'reaching threshold again restores only the reward difference' );
shipment( 5, 800, 'debit', '2026-10-23 00:00:00' );
check( target_state()['sales'] === 1100.0, 'out-of-period shipment excluded' );
check( $DB->save_visitor_target( 10, array_merge( $target, ['target_id'=>$target_id] ) )['status'] === 'error', 'rewarded target cannot be edited' );
$wpdb->update( 'wp_usermeta', ['meta_value'=>20], ['user_id'=>100,'meta_key'=>'customer_marketer'] );
shipment( 4, 200, 'credit' );
check( target_state()['sales'] === 900.0 && target_state()['reward'] === 0.0, 'customer reassignment preserves historical order reward and reversal' );
$wpdb->fail_bonus = TRUE;
check( shipment( 6, 500 )['status'] === 'error' && target_state()['sales'] === 900.0, 'bonus failure rolls back customer ledger mutation' );
$wpdb->fail_bonus = FALSE;
$s = $DB->get_visitor_summaries( [10,20] );
check( $s[20]['customer_balance'] === 1700.0 && $s[10]['customer_balance'] === 0.0, 'customer balances follow current assignment; visitor rewards are excluded' );
$DB->add_ledger_entry( ['user_id'=>101,'entry_type'=>'submit_payment','type'=>'credit','amount'=>50,'ref_type'=>'payment','ref_id'=>1] );
check( $DB->get_visitor_summaries([10])[10]['customer_balance'] === -50.0, 'customer credit balances preserve their sign' );
check( $DB->save_visitor_target( 30, array_merge( $target, ['date_from'=>'۱۴۰۵/۰۷/۰۱','date_to'=>'۱۴۰۵/۰۷/۳۰'] ) )['status'] === 'success', 'Persian date digits and slashes accepted' );
check( $DB->save_visitor_target( 30, array_merge( $target, ['date_from'=>'1403-12-30','date_to'=>'1403-12-30'] ) )['status'] === 'success', 'leap Esfand accepted' );
$authorized = FALSE;
function current_user_can( $cap ) { return $GLOBALS['authorized']; }
function wp_verify_nonce( $nonce, $action ) { return $nonce === 'valid-' . $action; }
function wp_unslash( $value ) { return $value; }
function kph_get_template( $path, $args = [] ) { return 'rendered'; }
class JsonResponse extends Exception { public function __construct( public array $response ) { parent::__construct(); } }
function wp_send_json( $response ) { throw new JsonResponse( $response ); }
require dirname( __DIR__ ) . '/Core/kph_ajax.php';
$ajax = (new ReflectionClass(kph_ajax::class))->newInstanceWithoutConstructor();
$ajax->DB = $DB;
function ajax_result() { global $ajax; try { $ajax->save_visitor_target(); } catch ( JsonResponse $e ) { return $e->response; } throw new Exception('No response'); }
$_POST = array_merge( $target, ['id'=>20,'target_nonce'=>'valid-kph_visitor_target_20'] );
check( ajax_result()['status'] === 'error' && !$DB->get_visitor_targets(20), 'unauthorized target request rejected before mutation' );
$authorized = TRUE;
$_POST['target_nonce'] = 'invalid';
check( ajax_result()['status'] === 'error' && !$DB->get_visitor_targets(20), 'invalid nonce rejected before mutation' );
$_POST['target_nonce'] = ['malformed'];
check( ajax_result()['status'] === 'error', 'non-scalar nonce rejected' );
$_POST['target_nonce'] = 'valid-kph_visitor_target_20';
check( ajax_result()['status'] === 'success' && $_REQUEST['tab'] === 'targets', 'authorized save refreshes the target tab' );
echo "$checks checks passed.\n";
