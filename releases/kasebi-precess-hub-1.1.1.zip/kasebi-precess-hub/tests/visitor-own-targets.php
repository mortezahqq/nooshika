<?php
/** Run with: php tests/visitor-own-targets.php. No WordPress/database writes. */
if ( PHP_SAPI !== 'cli' ) { exit; }
define( 'ABSPATH', __DIR__ );
define( 'KPH_TEMPLATE_PATH', dirname( __DIR__ ) . '/templates/' );
$session_user = 10;
$session_role = 'visitor';
$queried_ids = [];
$fixture_targets = [
    1 => [ 'title' => 'تارگت فعال', 'date_from' => '2026-09-01', 'date_to' => '2026-09-30', 'amount' => 1000, 'sales' => 740, 'bonus' => 200, 'reward' => 0, 'has_reward_history' => FALSE ],
    2 => [ 'title' => 'تارگت آینده', 'date_from' => '2026-10-01', 'date_to' => '2026-10-31', 'amount' => 2000, 'sales' => 0, 'bonus' => 300, 'reward' => 0, 'has_reward_history' => FALSE ],
    3 => [ 'title' => 'تارگت گذشته', 'date_from' => '2026-08-01', 'date_to' => '2026-08-31', 'amount' => 1000, 'sales' => 1200, 'bonus' => 200, 'reward' => 200, 'has_reward_history' => TRUE ],
];
function get_current_user_id() { return $GLOBALS['session_user']; }
function is_user_logged_in() { return $GLOBALS['session_user'] > 0; }
function nooshika_get_user_role( $id ) { return $GLOBALS['session_role']; }
function get_user_name_by_id( $id ) { return 'ویزیتور ' . $id; }
function current_time( $format ) { return '2026-09-28'; }
function current_datetime() { return new DateTimeImmutable( '2026-09-28 12:00:00', new DateTimeZone( 'Asia/Tehran' ) ); }
function nooshika_jalali_to_gregorian( $date ) {
    return [ '1405-01-01'=>'2026-03-21', '1405-02-01'=>'2026-04-21', '1405-03-01'=>'2026-05-22',
        '1405-04-01'=>'2026-06-22', '1405-05-01'=>'2026-07-23', '1405-06-01'=>'2026-08-23',
        '1405-07-01'=>'2026-09-23', '1405-08-01'=>'2026-10-23' ][$date];
}
function add_action( ...$args ) {}
function wp_create_nonce( $action ) { return 'test-nonce'; }
function home_url( $path = '' ) { return 'https://example.test' . $path; }
function esc_html( $value ) { return htmlspecialchars( (string) $value, ENT_QUOTES, 'UTF-8' ); }
function esc_attr( $value ) { return esc_html( $value ); }
function esc_url( $value ) { return esc_html( $value ); }
function apply_filters( $name, $value, ...$args ) { return $value; }
class kph_db {
    public function get_visitor_monthly_sales( array $ids, string $from, string $until ): array {
        if ( $ids !== [10] ) { throw new RuntimeException('Monthly report leaked identity'); }
        return [10 => ['shipped'=>500, 'proforma'=>200, 'items'=>[]]];
    }
    public function get_visitor_targets( int $user_id ): array {
        $GLOBALS['queried_ids'][] = $user_id;
        return $GLOBALS['fixture_targets'];
    }
}
require dirname( __DIR__ ) . '/includes/helper.php';
require dirname( __DIR__ ) . '/includes/visitor-monthly.php';
$checks = 0;
function check( bool $ok, string $label ): void {
    if ( ! $ok ) { throw new RuntimeException( 'FAIL: ' . $label ); }
    $GLOBALS['checks']++;
    echo 'PASS: ' . $label . PHP_EOL;
}

$_REQUEST = [ 'id' => 99, 'user_id' => 99, 'target_id' => 99, 'can_manage' => TRUE ];
$html = kph_get_template( 'pages/visitor-targets.php', [ 'user_id' => 99, 'can_manage' => TRUE ] );
check( $queried_ids === [ 10 ], 'identity comes from the session, not request or template arguments' );
check( str_contains( $html, '74٪' ) && str_contains( $html, '260' ), 'progress and remaining amount are rendered' );
check( str_contains( $html, 'پاداش خالص ثبت‌شده' ) && str_contains( $html, '200' ), 'reward status is visible' );
check( str_contains( $html, 'تارگت فعال من' ) && str_contains( $html, 'تارگت‌های پیش‌رو' ) && str_contains( $html, 'سوابق تارگت و پاداش من' ), 'active, upcoming and past periods are separated' );
check( ! str_contains( $html, '/crm/employee/' ) && ! str_contains( $html, '<form' ) && ! str_contains( $html, 'ویرایش تارگت' ), 'no management links or forms are rendered' );
$dashboard = kph_get_template( 'pages/dashboard.php' );
check( str_contains( $dashboard, 'تارگت و پاداش من' ) && $queried_ids === [10,10], 'visitor dashboard routes to personal targets' );
$menu = get_kph_pages_list();
check( $menu['visitor-targets']['valid_roles'] === ['visitor'] && get_kph_page_title('visitor-targets') === 'تارگت و پاداش من', 'menu and AJAX page title are registered for visitors' );
check( get_kph_end_point('/crm') === ['dashboard'], 'default login landing route remains dashboard' );
$fixture_targets = [];
check( str_contains( kph_get_template('pages/visitor-targets.php'), 'هنوز تارگتی برای شما تعریف نشده است' ), 'empty target state is clear' );
$queried_ids = [];
$session_role = 'administrator';
check( str_contains( kph_get_template('pages/visitor-targets.php'), 'مخصوص حساب ویزیتور' ) && !$queried_ids, 'other roles cannot use this page to inspect visitor data' );
$session_user = 0;
$session_role = 'visitor';
check( str_contains( kph_get_template('pages/visitor-targets.php'), 'مخصوص حساب ویزیتور' ) && !$queried_ids, 'anonymous AJAX access does not query target data' );
echo "$checks checks passed.\n";
