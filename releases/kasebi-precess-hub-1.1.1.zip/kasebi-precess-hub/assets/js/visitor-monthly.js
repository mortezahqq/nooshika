(function ($) {
    'use strict';
    function refresh() {
        if (document.hidden || !window.kphData) return;
        $('.kph-monthly-sales').each(function () {
            const panel = $(this);
            if (panel.data('loading')) return;
            panel.data('loading', true);
            panel.find('.kph-monthly-refresh').prop('disabled', true);
            $.ajax({ url: window.kphData.ajax_url, method: 'POST', timeout: 20000,
                data: { action: 'kph_visitor_monthly_sales', nonce: panel.attr('data-nonce') }
            }).done(function (response) {
                if (!panel[0].isConnected) return;
                if (response.success && response.data && response.data.html) {
                    const open = panel.find('details[open]').map(function () { return this.dataset.monthlyVisitor; }).get();
                    panel.html(response.data.html);
                    panel.find('details').each(function () { this.open = open.includes(this.dataset.monthlyVisitor); });
                } else {
                    panel.find('.kph-monthly-message').text('به‌روزرسانی انجام نشد؛ دوباره تلاش کنید.');
                }
            }).fail(function () {
                panel.find('.kph-monthly-message').text('ارتباط برقرار نشد؛ اطلاعات نمایش‌داده‌شده مربوط به آخرین به‌روزرسانی است.');
            }).always(function () {
                panel.data('loading', false);
                panel.find('.kph-monthly-refresh').prop('disabled', false);
            });
        });
    }
    $(document).on('click', '.kph-monthly-refresh', refresh);
    document.addEventListener('visibilitychange', function () { if (!document.hidden) refresh(); });
    setInterval(refresh, 30000);
})(jQuery);
