<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Resolve the Persian month using the same converter as the rest of the panel. */
function kph_visitor_sales_period(): array {
    $now = current_datetime();
    $today = $now->format( 'Y-m-d' );
    $year = (int) $now->format( 'Y' ) - 621;
    $convert = static fn( $y, $m ) => str_replace( '/', '-', nooshika_jalali_to_gregorian( sprintf( '%04d-%02d-01', $y, $m ) ) );
    if ( $today < $convert( $year, 1 ) ) { $year--; }
    $month = 1;
    for ( $m = 2; $m <= 12; $m++ ) {
        if ( $today < $convert( $year, $m ) ) { break; }
        $month = $m;
    }
    $from = $convert( $year, $month );
    $day = (int) ( new DateTimeImmutable( $from, $now->getTimezone() ) )->diff( $now )->format( '%a' ) + 1;
    $names = [ 1 => 'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند' ];
    return [ 'from' => $from . ' 00:00:00', 'until' => $now->format( 'Y-m-d H:i:s' ),
        'label' => $names[$month] . ' ' . $year . '، از روز ۱ تا ' . $day, 'time' => $now->format( 'H:i:s' ) ];
}

function kph_visitor_monthly_allowed(): bool {
    return is_user_logged_in() && in_array( nooshika_get_user_role( get_current_user_id() ), [ 'administrator', 'visitor' ], TRUE );
}

add_action( 'nooshika_ajax_kph_visitor_monthly_sales', function() {
    if ( ! kph_visitor_monthly_allowed() || ! check_ajax_referer( 'kph_visitor_monthly_sales', 'nonce', FALSE ) ) {
        wp_send_json_error( [ 'message' => 'اجازه دسترسی ندارید؛ صفحه را دوباره باز کنید.' ], 403 );
    }
    nocache_headers();
    wp_send_json_success( [ 'html' => kph_get_template( 'partials/visitor-monthly-sales.php', [ 'monthly_fragment' => TRUE ] ) ] );
} );

add_action( 'wp_enqueue_scripts', function() {
    if ( is_page( 'crm' ) && kph_visitor_monthly_allowed() ) {
        wp_enqueue_script( 'kph-visitor-monthly', KPH_ASSETS_URL . 'js/visitor-monthly.js', [ 'jquery' ], KPH_VER, TRUE );
    }
} );
