<?php
if (!defined('ABSPATH')) { exit; }

/** The support role keeps operational and personnel access, without general accounting access. */
function kph_support_accounting_restricted(): bool {
    return get_current_user_id() > 0 && nooshika_get_user_role(get_current_user_id()) === 'supp';
}
/** Scoped to this plugin: never grant WordPress administrator capabilities to the role. */
function kph_plugin_management_allowed(): bool {
    return current_user_can('manage_options') || kph_support_accounting_restricted();
}
function kph_support_stock_print(array $args): bool {
    $section = $args['request']['section'] ?? 'all';
    return is_string($section) && (isset(kph_db::warehouse_print_titles()[$section]) || in_array($section, ['repository','saloon','finished','trace'], true));
}
function kph_support_financial_tabs(): array { return ['financial','payments','transfers','cheque']; }
function kph_support_financial_page(string $page): bool {
    $slug = basename((string)parse_url($page,PHP_URL_PATH));
    return str_starts_with($slug,'finance-') || in_array($slug,[
        'divider-finance','subscriber-financial','subscriber-payments','subscriber-transfers','subscriber-cheque',
        'reports-cost','reports-order','reports-user',
    ],true);
}
function kph_support_filter_pages(array $pages): array {
    if (!kph_support_accounting_restricted()) return $pages;
    foreach ($pages as $key=>&$page) {
        if (kph_support_financial_page((string)$key)) { unset($pages[$key]); continue; }
        // Management pages, not the separate customer/supplier self-service portals.
        if (!str_starts_with((string)$key,'subscriber-') && !in_array($key,['supplier-orders','visitor-targets'],true)) {
            if (($page['valid_roles']??'all')!=='all') $page['valid_roles']=array_values(array_unique(array_merge((array)$page['valid_roles'],['supp'])));
        }
        foreach ($page['sub']??[] as $child=>$value) {
            if (kph_support_financial_page((string)$child)) unset($page['sub'][$child]);
        }
        if (($page['type']??'')==='sub' && empty($page['sub'])) unset($pages[$key]);
    }
    unset($page);
    return $pages;
}
function kph_support_financial_template(string $path): bool {
    $path=ltrim(str_replace('\\','/',$path),'/');
    $parts=[];foreach(explode('/',$path) as $part){if($part===''||$part==='.')continue;if($part==='..'){array_pop($parts);continue;}$parts[]=$part;}$path=implode('/',$parts);
    if (preg_match('~^(?:pages|sub_page)/([^/]+)\.php$~D',$path,$m)) return kph_support_financial_page($m[1]);
    if (preg_match('~^tab/(?:user|supplier)/([^/]+)\.php$~D',$path,$m)) return in_array($m[1],kph_support_financial_tabs(),true);
    return in_array($path,['partials/order-fin.php','partials/erp-dashboard.php','partials/customer-receivables-report.php','partials/customer-invoices-report.php'],true);
}
function kph_support_financial_print(string $type): bool {
    return in_array($type,['financial','payments','transfers','cheques','cost','stock','sales-report','customers-report'],true);
}
function kph_support_financial_action(string $action): bool {
    return in_array($action,[
        'kph_add_payment','kph_delete_payment','kph_add_transfer','kph_delete_transfer',
        'kph_add_cheque','kph_delete_cheque','kph_add_account','kph_add_account_transaction',
        'kph_load_cheque_moves_table','kph_load_cheques_list','kph_change_cheque_status','kph_refer_cheque_to_user',
        'kph_set_cheque_note_print','kph_set_cheque_note_print_all','kph_update_finance_attachment',
        'kph_load_order_financial','kph_save_customer_payment_term','kph_customer_freight_invoices',
        'kph_review_account_balance','kph_reconcile_account_balance','kph_review_transfer_deposits','kph_repair_transfer_deposits',
        'kph_visitor_monthly_sales',
    ],true);
}
function kph_support_action_visible(array $action): bool {
    if (!kph_support_accounting_restricted()) return true;
    $data=$action['data']??[];$link=(string)($action['link']??$data['url']??'');
    if (kph_support_financial_action((string)($data['action']??''))) return false;
    if (kph_support_financial_page($link)) return false;
    parse_str((string)(parse_url($link,PHP_URL_QUERY)??''),$query);
    if (in_array($query['tab']??'',kph_support_financial_tabs(),true) && !str_contains($link,'/employee/')) return false;
    if (($query['action']??'')==='print' && kph_support_financial_print((string)($query['type']??''))) return false;
    return true;
}
function kph_support_accounting_deny(): void {
    wp_send_json(['status'=>'error','message'=>'دسترسی پشتیبان به حسابداری و عملیات مالی مجاز نیست.'],403);
}
// Enforce before any existing callback, including both panel and WordPress AJAX transports.
$kph_support_actions=[
    'kph_add_payment','kph_delete_payment','kph_add_transfer','kph_delete_transfer','kph_add_cheque','kph_delete_cheque',
    'kph_add_account','kph_add_account_transaction','kph_load_cheque_moves_table','kph_load_cheques_list',
    'kph_change_cheque_status','kph_refer_cheque_to_user','kph_set_cheque_note_print','kph_set_cheque_note_print_all',
    'kph_update_finance_attachment','kph_load_order_financial','kph_save_customer_payment_term','kph_customer_freight_invoices',
    'kph_review_account_balance','kph_reconcile_account_balance','kph_review_transfer_deposits','kph_repair_transfer_deposits',
    'kph_visitor_monthly_sales',
    'kph_login_as_user',
];
foreach ($kph_support_actions as $kph_support_action) {
    foreach (['nooshika_ajax_','wp_ajax_'] as $prefix) {
        add_action($prefix.$kph_support_action,static function(){if(kph_support_accounting_restricted())kph_support_accounting_deny();},-100);
    }
}
unset($kph_support_actions,$kph_support_action,$prefix);
// Generic metadata updates must not be used to grant a different effective role or edit financial settings.
foreach (['kph_update_inline_meta','kph_update_user_personal_data','kph_add_user'] as $kph_support_action) {
    add_action('nooshika_ajax_'.$kph_support_action,static function()use($kph_support_action){
        if (!kph_support_accounting_restricted()) return;
        $keys=array_keys((array)($_POST['meta']??[]));$keys[]=$_POST['key']??'';
        foreach($keys as $key){
            if (is_string($key) && preg_match('/(?:capabilities|user_level|commission|payment_term|^role$)/i',$key)) kph_support_accounting_deny();
        }
    },-100);
}
unset($kph_support_action);
// Reject page-content requests before building the shared footer or reading any financial page data.
foreach(['kph_request_page_content','kph_request_back_btn'] as $kph_support_action){
    add_action('nooshika_ajax_'.$kph_support_action,static function(){
        if(!kph_support_accounting_restricted())return;
        $page=is_string($_POST['page']??null)?$_POST['page']:'';
        if(kph_support_financial_page($page))kph_support_accounting_deny();
        if(preg_match('~/crm/(?:user|supplier)(?:/|$)~',(string)parse_url($page,PHP_URL_PATH))){
            parse_str((string)(parse_url($page,PHP_URL_QUERY)??''),$query);
            $tab=$_POST['tab']??$query['tab']??'';
            if(is_string($tab)&&in_array($tab,kph_support_financial_tabs(),true))kph_support_accounting_deny();
        }
    },-100);
}
unset($kph_support_action);
/** Keep the explicitly retained HR accounting scope bound to a personnel subject. */
function kph_support_personnel_subject(int $id): bool {
    if ($id<=0 || !class_exists('kph_hr') || !kph_hr::allowed()) return false;
    $user=get_userdata($id);
    return $user && !array_intersect(['subscriber','supplier','visitor','administrator'],(array)$user->roles)
        && (bool)array_intersect(kph_hr::roles(),(array)$user->roles);
}
function kph_support_hr_ledger_print(string $type,array $args): bool {
    if ($type!=='financial' || !kph_support_personnel_subject((int)($args['user_id']??0))) return false;
    $ids=array_values(array_filter(array_map('absint',(array)($args['ids']??[]))));
    if (!$ids) return true;
    global $wpdb;
    $slots=implode(',',array_fill(0,count($ids),'%d'));
    $count=$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}kph_ledger_entries WHERE user_id=%d AND id IN ($slots)",array_merge([(int)$args['user_id']],$ids)));
    return !$wpdb->last_error && (int)$count===count(array_unique($ids));
}
// The newly granted settings permission covers this plugin, not arbitrary WordPress options.
add_action('nooshika_ajax_kph_save_site_settings',static function(){
    if(!kph_support_accounting_restricted())return;
    $options=$_POST['options']??[];
    if(!is_array($options))kph_support_accounting_deny();
    foreach(array_keys($options) as $key){
        if(!is_string($key)||!str_starts_with($key,'kph_')||$key==='kph_ajax_active_plugins')kph_support_accounting_deny();
    }
},-100);
