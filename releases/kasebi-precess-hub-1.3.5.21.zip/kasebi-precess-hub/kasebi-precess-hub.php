<?php
/**
 * Plugin Name: کاسبی: سیستم مدیریت تولید و فروش
 * Plugin URI: https://kasebi.co/
 * Description: افزونه مدیریت فروش - تامین‌کنندگان و انبارداری ویژه کاسبی
 * Version: 1.3.5.21
 * Author: احمد گلچین
 * Author URI: https://kasebi.co/
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
define( 'KPH_PATH', plugin_dir_path( __FILE__ ) );
define( 'KPH_URL', plugin_dir_url( __FILE__ ) );
define( 'KPH_NAME', plugin_basename( __FILE__ ) );
const KPH_TEMPLATE_PATH = KPH_PATH . 'templates/';
const KPH_MARKETER_META = 'user_visitor_id';
const KPH_ASSETS_URL    = KPH_URL . 'assets/';
const KPH_DEBUG_MODE    = TRUE;
if ( ! KPH_DEBUG_MODE ) {
	define( 'KPH_VER', get_plugin_data( __FILE__ )['Version'] );
} else {
	define( 'KPH_VER', time() );
}

include "includes/helper.php";
include "includes/support-access.php";
include "includes/visitor-monthly.php";
include "includes/order-dates.php";
include "includes/finance-integrity.php";
include "includes/pricing.php";
include "includes/workflow-tools.php";
include "includes/preparation-list.php";
include "includes/shortcodes.php";
include "includes/actions.php";
include "Core/kph_db.php";
include "includes/supplier-tools.php";
include "includes/hr.php";
include "includes/shipping-control.php";
include "includes/customer-freight.php";
include "includes/sms.php";
include "Core/kph_panel.php";
include "Core/kph_ajax.php";
register_activation_hook( __FILE__, 'kph_plugin_activated' );
new kph_panel();
new kph_ajax();
