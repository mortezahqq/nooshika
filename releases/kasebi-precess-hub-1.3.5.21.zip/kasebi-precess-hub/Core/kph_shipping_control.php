<?php
if(!defined('ABSPATH')){exit;}
require_once __DIR__.'/kph_hr_calendar.php';

/** Shipment follow-up with atomic waybill communication and customer freight accounting. */
require_once __DIR__.'/kph_shipping_integrations.php';
final class kph_shipping_control {
    use kph_shipping_integrations;
    private wpdb $d;private string $p;private kph_db $ledger;
    public function __construct(){global $wpdb;$this->d=$wpdb;$this->p=$wpdb->prefix.'kph_shipping_';$this->ledger=new kph_db();}
    public static function allowed():bool{return is_user_logged_in()&&(kph_plugin_management_allowed()||in_array(nooshika_get_user_role(get_current_user_id()),['accountant','supp'],TRUE));}
    private function guard():void{if(!self::allowed()){throw new RuntimeException('دسترسی به کنترل ارسال و دریافت مجاز نیست.');}}
    private function ok($result):void{if($result===FALSE){throw new RuntimeException('ذخیره اطلاعات انجام نشد؛ صفحه را تازه کنید.');}}
    private function text($value,int $max=190):string{if(!is_scalar($value)){throw new RuntimeException('ساختار اطلاعات معتبر نیست.');}$value=sanitize_textarea_field((string)$value);if(mb_strlen($value)>$max){throw new RuntimeException('متن واردشده طولانی است.');}return $value;}
    private function choice($value,array $choices,string $label):string{$value=$this->text($value,40);if(!isset($choices[$value])){throw new RuntimeException($label.' را انتخاب کنید.');}return $value;}
    private function date($value,bool $required=FALSE):?string{$value=$this->text($value,10);if($value===''){if($required){throw new RuntimeException('تاریخ ارسال الزامی است.');}return NULL;}return kph_hr_calendar::normalize($value);}
    private function encode(array $data):string{return wp_json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);}
    public static function lines():array{return ['moghim'=>'مقیم‌زاده','horsan'=>'هورسان'];}
    public static function halls(string $line):array{return $line==='moghim'?['cardamom'=>'سالن هل','saffron'=>'سالن زعفران']:($line==='horsan'?['spices'=>'سالن ادویه‌جات','barberry'=>'سالن زرشک']:[]);}
    public static function carriers():array{return ['almas'=>'الماس ترابر','jahan'=>'جهان بار طوس','terminal'=>'ترمینال','tipax'=>'تیپاکس','post'=>'پست'];}
    public static function waybills():array{return ['pending'=>'در انتظار دریافت','received'=>'دریافت شد'];}
    public static function communications():array{return ['not_registered'=>'عدم ثبت','registered'=>'ثبت شد'];}
    public static function receipts():array{return ['pending'=>'تماس انجام نشده','received'=>'دریافت شد','not_received'=>'دریافت نشد','no_answer'=>'عدم پاسخ'];}
    public static function surveys():array{return ['pending'=>'انجام نشده','again'=>'نیاز به پیگیری مجدد','done'=>'انجام شد'];}
    public static function views():array{return ['all'=>'همه ارسال‌ها','waybill'=>'بارنامه دریافت‌نشده','communication'=>'بارنامه ثبت‌نشده در ارتباطات','receipt'=>'پیگیری دریافت','survey'=>'پیگیری رضایت‌سنجی'];}
    private function detected_line():?string{$host=strtolower((string)parse_url(home_url('/'),PHP_URL_HOST));if(preg_match('/(^|\.)moghimzadeh?\.com$/D',$host)){return 'moghim';}if(preg_match('/(^|\.)horsunam\.com$/D',$host)){return 'horsan';}return NULL;}
    public function install():void{
        $this->guard();$charset='ENGINE=InnoDB '.$this->d->get_charset_collate();
        foreach([
            "CREATE TABLE IF NOT EXISTS {$this->p}settings(id TINYINT UNSIGNED PRIMARY KEY,line VARCHAR(16) NULL,version INT UNSIGNED NOT NULL DEFAULT 1,updated_at DATETIME NOT NULL) $charset",
            "CREATE TABLE IF NOT EXISTS {$this->p}records(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,line VARCHAR(16) NOT NULL,order_id BIGINT UNSIGNED NOT NULL,customer_id BIGINT UNSIGNED NOT NULL,shipped_on DATE NOT NULL,waybill_status VARCHAR(20) NOT NULL,communication_status VARCHAR(20) NOT NULL,receipt_result VARCHAR(20) NOT NULL,survey_status VARCHAR(20) NOT NULL,survey_on DATE NULL,freight_cost BIGINT UNSIGNED NULL,payer VARCHAR(16) NOT NULL,status VARCHAR(16) NOT NULL DEFAULT 'active',data LONGTEXT NOT NULL,request_key CHAR(64) NOT NULL UNIQUE,version INT UNSIGNED NOT NULL DEFAULT 1,created_by BIGINT UNSIGNED NOT NULL,created_at DATETIME NOT NULL,updated_at DATETIME NOT NULL,KEY shipment_line(line,status,shipped_on),KEY order_tracking(order_id),KEY customer_tracking(customer_id),KEY followup(line,status,receipt_result,survey_status)) $charset",
            "CREATE TABLE IF NOT EXISTS {$this->p}audit(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,record_id BIGINT UNSIGNED NOT NULL,event VARCHAR(20) NOT NULL,actor_id BIGINT UNSIGNED NOT NULL,before_data LONGTEXT NOT NULL,after_data LONGTEXT NOT NULL,created_at DATETIME NOT NULL,KEY record_history(record_id,id)) $charset"
        ] as $sql){$this->ok($this->d->query($sql));}
        $this->ok($this->d->query($this->d->prepare("INSERT IGNORE INTO {$this->p}settings(id,line,version,updated_at) VALUES(1,NULLIF(%s,''),1,%s)",$this->detected_line()??'',current_time('mysql'))));
        $this->install_integrations();
    }
    public function setting():array{$this->guard();$r=$this->d->get_row("SELECT * FROM {$this->p}settings WHERE id=1",ARRAY_A);if(!$r){throw new RuntimeException('آماده‌سازی بخش ارسال انجام نشده است؛ صفحه را تازه کنید.');}return $r;}
    private function locked_setting():array{$r=$this->d->get_row("SELECT * FROM {$this->p}settings WHERE id=1 FOR UPDATE",ARRAY_A);if(!$r){throw new RuntimeException('تنظیم لاین پنل انجام نشده است.');}return $r;}
    private function line():string{$line=$this->setting()['line']??'';if(!isset(self::lines()[$line])){throw new RuntimeException('مدیر ابتدا لاین پنل را در تنظیمات این بخش انتخاب کند.');}return $line;}
    public function save_setting(array $input):void{
        $this->guard();if(!kph_plugin_management_allowed()){throw new RuntimeException('تنظیم لاین فقط برای مدیر مجاز است.');}$line=$this->choice($input['line']??'',self::lines(),'لاین پنل');
        $this->ok($this->d->query('START TRANSACTION'));try{$old=$this->locked_setting();if((int)$old['version']!==(int)($input['version']??0)){throw new RuntimeException('تنظیمات تغییر کرده است؛ صفحه را تازه کنید.');}
            if($old['line']!==$line&&(int)$this->d->get_var("SELECT COUNT(*) FROM {$this->p}records")>0){throw new RuntimeException('لاین این پنل دارای سوابق ارسال است و قابل تغییر نیست.');}
            $next=['line'=>$line,'version'=>(int)$old['version']+1,'updated_at'=>current_time('mysql')];$this->ok($this->d->update($this->p.'settings',$next,['id'=>1]));$this->audit(0,'settings',$old,$next);$this->ok($this->d->query('COMMIT'));
        }catch(Throwable $e){$this->d->query('ROLLBACK');throw $e;}
    }
    private function customer(int $id):object{$u=get_user_by('ID',$id);if(!$u||!in_array('subscriber',(array)$u->roles,TRUE)){throw new RuntimeException('مشتری ثبت‌شده را انتخاب کنید.');}return $u;}
    public function customers(string $term,int $page=1):array{
        $this->guard();$term=$this->text(kph_hr_calendar::latin($term),100);$like='%'.$this->d->esc_like($term).'%';$phoneLike='%'.$this->d->esc_like(ltrim($term,'0')?:$term).'%';$prefix=$this->d->prefix;
        $sql=$this->d->prepare("SELECT DISTINCT u.ID,u.display_name FROM {$this->d->users} u WHERE EXISTS(SELECT 1 FROM {$this->d->usermeta} cap WHERE cap.user_id=u.ID AND cap.meta_key=%s AND cap.meta_value LIKE %s) AND (u.display_name LIKE %s OR u.user_login LIKE %s OR EXISTS(SELECT 1 FROM {$this->d->usermeta} phone WHERE phone.user_id=u.ID AND phone.meta_key='nooshika_phone_num' AND phone.meta_value LIKE %s)) ORDER BY u.ID DESC LIMIT 21 OFFSET %d",$prefix.'capabilities','%"subscriber"%',$like,$like,$phoneLike,(max(1,$page)-1)*20);
        $rows=$this->d->get_results($sql,ARRAY_A);if($this->d->last_error){throw new RuntimeException('جستجوی مشتری انجام نشد.');}$more=count($rows)>20;$rows=array_slice($rows,0,20);
        return ['results'=>array_map(static fn($r)=>['id'=>(int)$r['ID'],'text'=>$r['display_name']],$rows),'pagination'=>['more'=>$more]];
    }
    public function invoices(int $customer,string $term,int $page=1):array{
        $this->guard();$this->customer($customer);$term=$this->text(kph_hr_calendar::latin($term),100);$like='%'.$this->d->esc_like($term).'%';
        $base=$this->d->prefix.'kph_';
        $rows=$this->d->get_results($this->d->prepare("SELECT o.id,m.invoice_number FROM {$base}orders o INNER JOIN (SELECT order_id,MAX(NULLIF(TRIM(meta_value),'')) AS invoice_number FROM {$base}orders_meta WHERE meta_key='factor_number' GROUP BY order_id) m ON m.order_id=o.id WHERE o.customer_id=%d AND o.status<>'canceled' AND m.invoice_number IS NOT NULL AND m.invoice_number LIKE %s ORDER BY o.id DESC LIMIT 21 OFFSET %d",$customer,$like,(max(1,$page)-1)*20),ARRAY_A);
        if($this->d->last_error){throw new RuntimeException('جستجوی فاکتور انجام نشد.');}$more=count($rows)>20;
        return ['results'=>array_map(static fn($r)=>['id'=>(int)$r['id'],'text'=>'#'.$r['invoice_number']],array_slice($rows,0,20)),'pagination'=>['more'=>$more]];
    }
    public function orders(int $customer,string $term,int $page=1):array{return $this->invoices($customer,$term,$page);}
    public function order(int $id):array{
        $this->guard();$base=$this->d->prefix.'kph_';$r=$this->d->get_row($this->d->prepare("SELECT id,order_number,customer_id,status FROM {$base}orders WHERE id=%d",$id),ARRAY_A);
        if($this->d->last_error||!$r){throw new RuntimeException('فاکتور انتخاب‌شده یافت نشد.');}$this->customer((int)$r['customer_id']);
        $numbers=$this->d->get_col($this->d->prepare("SELECT DISTINCT TRIM(meta_value) FROM {$base}orders_meta WHERE order_id=%d AND meta_key='factor_number' AND TRIM(COALESCE(meta_value,''))<>''",$id));
        if($this->d->last_error||count($numbers)>1){throw new RuntimeException('شماره فاکتور این سفارش ناسازگار است؛ مدیر آن را بررسی کند.');}$r['invoice_number']=(string)($numbers[0]??'');return $r;
    }
    private function normalized(array $input,string $line):array{
        $order=$this->order(absint($input['order_id']??0));if($order['status']==='canceled'){throw new RuntimeException('فاکتور لغوشده قابل انتخاب نیست.');}if($order['invoice_number']===''&&empty($input['_legacy_record'])){throw new RuntimeException('برای این سفارش هنوز شماره فاکتور صادر نشده است؛ ابتدا فاکتور را صادر کنید.');}$customer=absint($input['customer_id']??0);$u=$this->customer($customer);if((int)$order['customer_id']!==$customer){throw new RuntimeException('سفارش انتخاب‌شده متعلق به این مشتری نیست.');}
        $data=['invoice_number'=>$this->text($order['invoice_number']),'order_number'=>$this->text($order['order_number']),'customer_name'=>$this->text(get_user_name_by_id($customer)),
            'hall'=>$this->choice($input['hall']??'',self::halls($line),'سالن ارسال‌کننده'),'destination'=>$this->text($input['destination']??'',1000),
            'carrier'=>$this->choice($input['carrier']??'',self::carriers(),'شرکت حمل'),'waybill_no'=>$this->text(kph_hr_calendar::latin($input['waybill_no']??'')),
            'waybill_on'=>$this->date($input['waybill_on']??''),'first_contact_on'=>$this->date($input['first_contact_on']??''),'notes'=>$this->text($input['notes']??'',10000)];
        if($line==='moghim'){$data['driver']=$this->text($input['driver']??'');}elseif(trim($this->text($input['driver']??''))!==''){throw new RuntimeException('فیلد راننده در لاین هورسان وجود ندارد.');}
        if($data['destination']===''){throw new RuntimeException('مقصد را وارد کنید.');}
        $cost=trim(kph_hr_calendar::latin($this->text($input['freight_cost']??'',40)));$cost=str_replace([',','٬'],'',$cost);
        if($cost!==''&&(!preg_match('/^\d+$/D',$cost)||(float)$cost>1000000000000)){throw new RuntimeException('هزینه باربری را به ریال و به‌صورت غیرمنفی وارد کنید.');}
        $customerPays=$this->choice($input['customer_pays']??'0',['0'=>'شرکت','1'=>'مشتری'],'پرداخت‌کننده');
        return ['finance_enabled'=>(int)$this->choice($input['post_freight']??$input['finance_enabled']??'1',['0'=>'خیر','1'=>'بله'],'ثبت هزینه'),'line'=>$line,'order_id'=>(int)$order['id'],'customer_id'=>$customer,'shipped_on'=>$this->date($input['shipped_on']??'',TRUE),
            'waybill_status'=>$this->choice($input['waybill_status']??'pending',self::waybills(),'وضعیت بارنامه'),'communication_status'=>$this->choice($input['communication_status']??'not_registered',self::communications(),'ثبت در ارتباطات'),
            'receipt_result'=>$this->choice($input['receipt_result']??'pending',self::receipts(),'نتیجه تماس دریافت'),'survey_status'=>$this->choice($input['survey_status']??'pending',self::surveys(),'وضعیت رضایت‌سنجی'),
            'survey_on'=>$this->date($input['survey_on']??''),'freight_cost'=>$cost===''?NULL:(int)$cost,'payer'=>$customerPays==='1'?'customer':'company','data'=>$this->encode($data)];
    }
    private function audit(int $record,string $event,array $before,array $after):void{$this->ok($this->d->insert($this->p.'audit',['record_id'=>$record,'event'=>$event,'actor_id'=>get_current_user_id(),'before_data'=>$this->encode($before),'after_data'=>$this->encode($after),'created_at'=>current_time('mysql')]));}
    private function decoded(array $r):array{$r['data']=json_decode($r['data']??'{}',TRUE)?:[];if(!array_key_exists('invoice_number',$r['data'])){$o=$this->order((int)$r['order_id']);$r['data']['invoice_number']=$o['invoice_number'];}return $r;}
    public function record(int $id):array{$this->guard();$line=$this->line();$r=$this->d->get_row($this->d->prepare("SELECT * FROM {$this->p}records WHERE id=%d AND line=%s",$id,$line),ARRAY_A);if(!$r){throw new RuntimeException('سابقهٔ ارسال این لاین یافت نشد.');}$r=$this->decoded($r);$r['waybill_file']=$this->waybill_info($id);$r['freight_posting']=$this->freight_info($id);$r['manual_freight_posting']=kph_customer_freight::for_order((int)$r['order_id']);return $r;}
    public function save(array $input,bool $receiptMode=FALSE,array $file=[]):int{
        $this->guard();$upload=$file&&($file['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_NO_FILE?$this->validated_waybill($file):NULL;$id=absint($input['record_id']??0);$this->integration_ready();$this->ok($this->d->query('START TRANSACTION'));
        try{$setting=$this->locked_setting();$line=$setting['line']??'';if(!isset(self::lines()[$line])){throw new RuntimeException('لاین پنل را انتخاب کنید.');}$old=[];
            if($id){$old=$this->d->get_row($this->d->prepare("SELECT * FROM {$this->p}records WHERE id=%d AND line=%s FOR UPDATE",$id,$line),ARRAY_A);if(!$old||$old['status']!=='active'||(int)$old['version']!==(int)($input['version']??0)){throw new RuntimeException('سابقه تغییر کرده است؛ صفحه را تازه کنید.');}}
            $effective=$old?array_merge($old,json_decode($old['data'],TRUE)?:[],['customer_pays'=>$old['payer']==='customer'?1:0],$input):$input;$effective['_legacy_record']=$old&&(int)$old['order_id']===absint($effective['order_id']??0);if($receiptMode){$effective['post_freight']=(string)($old['finance_enabled']??0);}
            $support_accounting = kph_support_accounting_restricted();
            if ($support_accounting && !$old) {
                if (!empty($effective['post_freight']) || !empty($effective['finance_enabled']) || trim((string)($effective['freight_cost']??''))!=='' || !empty($effective['customer_pays'])) {
                    throw new RuntimeException('ثبت مالی کرایه فقط توسط حسابداری انجام می‌شود.');
                }
                $effective['post_freight']='0';
            }
            $next=$this->normalized($effective,$line);
            if ($support_accounting && $old) {
                foreach(['finance_enabled','freight_cost','payer','customer_id','order_id'] as $financial_key) {
                    if ((string)$next[$financial_key] !== (string)$old[$financial_key]) throw new RuntimeException('پشتیبان اجازه تغییر اطلاعات مالی این ارسال را ندارد.');
                }
            }

            $waybill=$id?$this->waybill_info($id):NULL;
            if($upload||$waybill){$next['waybill_status']='received';$next['communication_status']='registered';}
            $fingerprint=hash('sha256',$this->encode($next).'|'.($upload['checksum']??''));
            if(!$id){$key=$this->text($input['request_key']??'',64);if(!preg_match('/^[A-Za-z0-9_-]{16,64}$/D',$key)){throw new RuntimeException('اعتبار فرم کافی نیست؛ صفحه را تازه کنید.');}$key=hash('sha256',get_current_user_id().'|'.$key);$existing=$this->d->get_row($this->d->prepare("SELECT * FROM {$this->p}records WHERE request_key=%s FOR UPDATE",$key),ARRAY_A);
                if($existing){if(!$existing['request_fingerprint']||!hash_equals($existing['request_fingerprint'],$fingerprint)||$existing['status']!=='active'){throw new RuntimeException('این فرم قبلاً ثبت شده است؛ صفحه را تازه کنید.');}$this->ok($this->d->query('COMMIT'));return (int)$existing['id'];}
                $next+=['request_key'=>$key,'request_fingerprint'=>$fingerprint,'created_by'=>get_current_user_id(),'created_at'=>current_time('mysql')];}
            $next['version']=$old?(int)$old['version']+1:1;$next['updated_at']=current_time('mysql');
            if($id){$this->ok($this->d->update($this->p.'records',$next,['id'=>$id]));}else{$this->ok($this->d->insert($this->p.'records',$next));$id=(int)$this->d->insert_id;}
            $current=array_merge(['status'=>'active','action_id'=>0],$old,$next,['id'=>$id]);
            if(!$receiptMode){$action=$this->sync_waybill($current,$upload);if($action){$next['action_id']=$action;$this->ok($this->d->update($this->p.'records',['action_id'=>$action],['id'=>$id]));}}
            if(!$receiptMode && !$support_accounting){$this->sync_freight(array_merge($current,$next));}
            $this->audit($id,$old?($receiptMode?'receipt':'edit'):'create',$old,$next);$this->ok($this->d->query('COMMIT'));return $id;
        }catch(Throwable $e){$this->d->query('ROLLBACK');throw $e;}
    }
    public function receipt(array $input):int{
        $old=$this->record(absint($input['record_id']??0));$allowed=array_intersect_key($input,array_flip(['record_id','version','receipt_result','first_contact_on','survey_status','survey_on','notes']));
        return $this->save(array_merge($old,$old['data'],['record_id'=>(int)$old['id']],$allowed),TRUE);
    }
    public function cancel(int $id,int $version,string $reason):void{
        $this->guard();$reason=$this->text($reason,1000);$this->integration_ready();if($reason===''){throw new RuntimeException('علت ابطال را وارد کنید.');}$this->ok($this->d->query('START TRANSACTION'));
        try{$s=$this->locked_setting();$r=$this->d->get_row($this->d->prepare("SELECT * FROM {$this->p}records WHERE id=%d AND line=%s FOR UPDATE",$id,$s['line']),ARRAY_A);if(!$r||$r['status']!=='active'||(int)$r['version']!==$version){throw new RuntimeException('سابقه تغییر کرده است؛ صفحه را تازه کنید.');}if(kph_support_accounting_restricted() && !empty($this->freight_info($id)['amount'])) throw new RuntimeException('ابطال ارسال دارای ثبت مالی باید توسط حسابداری انجام شود.');$data=json_decode($r['data'],TRUE)?:[];$data['cancel_reason']=$reason;$next=['status'=>'canceled','version'=>$version+1,'data'=>$this->encode($data),'updated_at'=>current_time('mysql')];$this->ok($this->d->update($this->p.'records',$next,['id'=>$id]));if(!kph_support_accounting_restricted()){$this->sync_freight(array_merge($r,$next));}$this->sync_waybill(array_merge($r,$next),NULL);$this->audit($id,'cancel',$r,$next);$this->ok($this->d->query('COMMIT'));
        }catch(Throwable $e){$this->d->query('ROLLBACK');throw $e;}
    }
    public function listing(array $filters=[],int $page=1):array{
        $this->guard();$line=$this->line();if(($filters['from']??'')!==''&&($filters['to']??'')!==''&&$this->date($filters['from'])>$this->date($filters['to'])){throw new RuntimeException('پایان بازه قبل از شروع است.');}$sql='line=%s';$bind=[$line];$status=$this->choice($filters['status']??'active',['active'=>'فعال','canceled'=>'ابطال‌شده','all'=>'همه'],'وضعیت');if($status!=='all'){$sql.=' AND status=%s';$bind[]=$status;}
        $q=$this->text($filters['q']??'',100);if($q!==''){$sql.=' AND (data LIKE %s OR order_id=%d)';$bind[]='%'.$this->d->esc_like(kph_hr_calendar::latin($q)).'%';$bind[]=preg_match('/^\d+$/D',kph_hr_calendar::latin($q))?(int)kph_hr_calendar::latin($q):0;}
        foreach(['from'=>'>=','to'=>'<='] as $key=>$op){if(($filters[$key]??'')!==''){$sql.=' AND shipped_on'.$op.'%s';$bind[]=$this->date($filters[$key]);}}
        foreach(['waybill_status'=>self::waybills(),'communication_status'=>self::communications(),'receipt_result'=>self::receipts(),'survey_status'=>self::surveys()] as $key=>$choices){if(($filters[$key]??'')!==''){$sql.=' AND '.$key.'=%s';$bind[]=$this->choice($filters[$key],$choices,$key);}}
        if(!empty($filters['order_id'])){$sql.=' AND order_id=%d';$bind[]=absint($filters['order_id']);}
        $base=$this->d->prepare($sql,$bind);$counts=$this->d->get_row("SELECT COUNT(*) AS all_count,SUM(waybill_status='pending') AS waybill,SUM(communication_status='not_registered') AS communication,SUM(receipt_result IN('not_received','no_answer')) AS receipt,SUM(survey_status IN('pending','again')) AS survey FROM {$this->p}records WHERE $base",ARRAY_A);
        $view=$this->choice($filters['view']??'all',self::views(),'نمایش');$views=['all'=>'1=1','waybill'=>"waybill_status='pending'",'communication'=>"communication_status='not_registered'",'receipt'=>"receipt_result IN('not_received','no_answer')",'survey'=>"survey_status IN('pending','again')"];$where=$base.' AND '.$views[$view];
        $summary=$this->d->get_row("SELECT COUNT(*) AS total,COALESCE(SUM(freight_cost),0) AS freight_total,SUM(freight_cost IS NULL) AS unknown_cost,COALESCE(SUM(CASE WHEN payer='customer' THEN freight_cost ELSE 0 END),0) AS customer_cost FROM {$this->p}records WHERE $where",ARRAY_A);
        $pages=max(1,(int)ceil(($summary['total']??0)/20));$page=min(max(1,$page),$pages);
        $items=$this->d->get_results("SELECT * FROM {$this->p}records WHERE $where ORDER BY shipped_on DESC,id DESC LIMIT 20 OFFSET ".(($page-1)*20),ARRAY_A);
        if($this->d->last_error||!$summary||!$counts){throw new RuntimeException('خواندن سوابق ارسال انجام نشد.');}return ['items'=>array_map(function($row){$r=$this->decoded($row);$r['waybill_file']=$this->waybill_info((int)$row['id']);$r['freight_posting']=$this->freight_info((int)$row['id']);$r['manual_freight_posting']=kph_customer_freight::for_order((int)$r['order_id']);return $r;},$items),'total'=>(int)$summary['total'],'pages'=>$pages,'page'=>$page,'summary'=>$summary,'counts'=>['all'=>(int)$counts['all_count']]+array_map('intval',array_intersect_key($counts,self::views()))];
    }
}
