<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

trait kph_multiwarehouse {

    public static function warehouse_print_titles(): array {
        return [
            'warehouse_summary' => 'خلاصه انبارها بر اساس فیلتر انتخابی',
            'warehouse_directory' => 'انبارهای تعریف‌شده',
            'warehouse_finished' => 'موجودی تخصیص‌یافته به تفکیک انبار',
            'warehouse_moves' => 'تاریخچه انتقال بین انبارها',
            'warehouse_raw' => 'موجودی مواد اولیه به تفکیک انبار',
        ];
    }

    public static function warehouse_type_labels(): array {
        return ['mixed'=>'ترکیبی', 'finished'=>'محصول نهایی', 'raw'=>'مواد اولیه', 'semi'=>'نیمه‌ساخته'];
    }

    public static function summarize_warehouse_stock(array $warehouses, int $warehouse_id, array $stock, array $batches): array {
        $totals = [];
        foreach ($warehouses as $warehouse) {
            $id = (int) $warehouse['id'];
            if (!$warehouse_id || $warehouse_id === $id) {
                $totals[$id] = ['warehouse'=>$warehouse, 'finished'=>0, 'value'=>0, 'weight'=>0, 'batches'=>0];
            }
        }
        foreach ($stock as $item) {
            $id = $item['warehouse_id'];
            $totals[$id]['finished'] += (float) $item['qty'];
            $totals[$id]['value'] += (float) $item['allocated_value'];
        }
        foreach ($batches as $batch) {
            $id = $batch['warehouse_id'];
            $totals[$id]['weight'] += (float) $batch['qty_weight'];
            ++$totals[$id]['batches'];
        }
        return $totals;
    }

    private string $warehouses_table;
    private string $warehouse_stock_table;
    private string $warehouse_batch_stock_table;
    private string $warehouse_moves_table;
    private bool $multiwarehouse_ready = false;

    private function create_multiwarehouse_tables(): void {
        if ( $this->multiwarehouse_ready ) { return; }
        $this->warehouses_table = $this->db_prefix . 'warehouses';
        $this->warehouse_stock_table = $this->db_prefix . 'warehouse_stock';
        $this->warehouse_batch_stock_table = $this->db_prefix . 'warehouse_batch_stock';
        $this->warehouse_moves_table = $this->db_prefix . 'warehouse_moves';
        maybe_create_table( $this->warehouses_table, "CREATE TABLE {$this->warehouses_table} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            name VARCHAR(190) NOT NULL,
            code VARCHAR(60) NOT NULL,
            warehouse_type VARCHAR(40) NOT NULL DEFAULT 'finished',
            is_default TINYINT(1) NOT NULL DEFAULT 0,
            is_active TINYINT(1) NOT NULL DEFAULT 1,
            created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id), UNIQUE KEY code (code), KEY is_active (is_active)
        ) ENGINE=InnoDB {$this->db->get_charset_collate()};" );
        maybe_create_table( $this->warehouse_stock_table, "CREATE TABLE {$this->warehouse_stock_table} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            warehouse_id BIGINT UNSIGNED NOT NULL,
            inventory_id BIGINT UNSIGNED NOT NULL,
            qty DECIMAL(18,5) NOT NULL DEFAULT 0,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id), UNIQUE KEY warehouse_inventory (warehouse_id,inventory_id), KEY inventory_id (inventory_id)
        ) ENGINE=InnoDB {$this->db->get_charset_collate()};" );
        maybe_create_table( $this->warehouse_batch_stock_table, "CREATE TABLE {$this->warehouse_batch_stock_table} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            warehouse_id BIGINT UNSIGNED NOT NULL,
            batch_id BIGINT UNSIGNED NOT NULL,
            qty_weight DECIMAL(18,6) NOT NULL DEFAULT 0,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (id), UNIQUE KEY warehouse_batch (warehouse_id,batch_id), KEY batch_id (batch_id)
        ) ENGINE=InnoDB {$this->db->get_charset_collate()};" );
        maybe_create_table( $this->warehouse_moves_table, "CREATE TABLE {$this->warehouse_moves_table} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            source_warehouse_id BIGINT UNSIGNED NOT NULL,
            target_warehouse_id BIGINT UNSIGNED NOT NULL,
            inventory_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            batch_id BIGINT UNSIGNED NULL,
            qty DECIMAL(18,6) NOT NULL,
            note TEXT NULL,
            created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id), KEY inventory_id (inventory_id), KEY created_at (created_at)
        ) ENGINE=InnoDB {$this->db->get_charset_collate()};" );
        // Raw transfers use the same six decimal kilogram precision as batch balances.
        $quantity_column=$this->db->get_row("SHOW COLUMNS FROM {$this->warehouse_moves_table} LIKE 'qty'",ARRAY_A);
        if($quantity_column && strtolower((string)$quantity_column['Type'])==='decimal(18,5)'){
            $this->db->query("ALTER TABLE {$this->warehouse_moves_table} MODIFY qty DECIMAL(18,6) NOT NULL");
        }
        // Upgrade-safe column addition for installations that already created the first 1.3.4.8 preview schema.
        $batch_column = $this->db->get_var( $this->db->prepare("SHOW COLUMNS FROM {$this->warehouse_moves_table} LIKE %s", 'batch_id') );
        if ( ! $batch_column ) { $this->db->query("ALTER TABLE {$this->warehouse_moves_table} ADD COLUMN batch_id BIGINT UNSIGNED NULL AFTER inventory_id"); }

        $default_id = (int) $this->db->get_var( "SELECT id FROM {$this->warehouses_table} WHERE is_default=1 LIMIT 1" );
        if ( ! $default_id ) {
            $this->db->insert( $this->warehouses_table, [
                'name' => 'انبار اصلی', 'code' => 'MAIN', 'warehouse_type' => 'mixed',
                'is_default' => 1, 'is_active' => 1, 'created_by' => 0, 'created_at' => current_time('mysql'),
            ] );
            $default_id = (int) $this->db->insert_id;
        }
        $default_type = (string)$this->db->get_var($this->db->prepare("SELECT warehouse_type FROM {$this->warehouses_table} WHERE id=%d",$default_id));
        if($default_type !== 'mixed') $this->db->update($this->warehouses_table, ['warehouse_type'=>'mixed'], ['id'=>$default_id,'is_default'=>1]);
        $ordinary_raw=$this->ordinary_raw_condition('seed_raw');
        // One-time migration: allocate all pre-existing balances to the default warehouse.
        // Subsequent stock deltas are synchronized from apply_inventory_change().
        if ( $default_id && ! get_option('kph_multiwarehouse_seeded_v1', false) ) {
            $this->db->query( $this->db->prepare(
                "INSERT IGNORE INTO {$this->warehouse_stock_table} (warehouse_id, inventory_id, qty, updated_at)
                 SELECT %d, id, GREATEST(qty_available,0), %s FROM {$this->inventory_balance}",
                $default_id, current_time('mysql')
            ) );
            if ( ! $this->db->last_error ) { update_option('kph_multiwarehouse_seeded_v1', 1, false); }
        }
        if ( $default_id && ! get_option('kph_multiwarehouse_batch_seeded_v1', false) ) {
            $this->db->query( $this->db->prepare(
                "INSERT IGNORE INTO {$this->warehouse_batch_stock_table} (warehouse_id,batch_id,qty_weight,updated_at)
                 SELECT %d,b.id,GREATEST(COALESCE(SUM(CASE WHEN sm.direction='in' THEN sm.qty_weight WHEN sm.direction='out' THEN -sm.qty_weight ELSE 0 END),0),0),%s
                 FROM {$this->batches} b INNER JOIN {$this->raw_products} seed_raw ON seed_raw.id=b.raw_product_id LEFT JOIN {$this->storage_moves} sm ON sm.batch_id=b.id WHERE $ordinary_raw GROUP BY b.id
                 HAVING SUM(CASE WHEN sm.direction='in' THEN sm.qty_weight WHEN sm.direction='out' THEN -sm.qty_weight ELSE 0 END) > 0",
                $default_id, current_time('mysql')
            ) );
            if ( ! $this->db->last_error ) { update_option('kph_multiwarehouse_batch_seeded_v1', 1, false); }
        }
        if ( ! $this->db->last_error ) { $this->multiwarehouse_ready = true; }
    }


    private function apply_warehouse_allocation_delta( int $inventory_id, float $previous_qty, float $change_qty ): bool {
        $default_id = (int) $this->db->get_var("SELECT id FROM {$this->warehouses_table} WHERE is_default=1 LIMIT 1");
        if ( $default_id <= 0 ) return false;
        $rows = $this->db->get_results($this->db->prepare(
            "SELECT ws.id,ws.warehouse_id,ws.qty,w.is_default FROM {$this->warehouse_stock_table} ws
             INNER JOIN {$this->warehouses_table} w ON w.id=ws.warehouse_id
             WHERE ws.inventory_id=%d ORDER BY w.is_default DESC,ws.qty DESC FOR UPDATE", $inventory_id
        ), ARRAY_A) ?: [];
        $sum = 0.0;
        foreach($rows as $row){ $sum += (float)$row['qty']; }
        $target = $previous_qty + $change_qty;
        // INSERT IGNORE migration may already have seeded the newly-created row at target quantity.
        if ( round($sum - $target, 5) == 0 ) return true;
        if ( round($sum - $previous_qty, 5) != 0 ) {
            // Reconcile an under-allocation to the pre-change balance, but never silently erase over-allocation.
            if ( round($sum - $previous_qty, 5) > 0 ) return false;
            $gap = $previous_qty - $sum;
            if ( $gap > 0 ) {
                $default_row = $this->db->get_row($this->db->prepare("SELECT id,qty FROM {$this->warehouse_stock_table} WHERE warehouse_id=%d AND inventory_id=%d FOR UPDATE",$default_id,$inventory_id),ARRAY_A);
                if($default_row){$ok=$this->db->update($this->warehouse_stock_table,['qty'=>(float)$default_row['qty']+$gap,'updated_at'=>current_time('mysql')],['id'=>(int)$default_row['id']]);}
                else{$ok=$this->db->insert($this->warehouse_stock_table,['warehouse_id'=>$default_id,'inventory_id'=>$inventory_id,'qty'=>$gap,'updated_at'=>current_time('mysql')]);}
                if(!$ok)return false;
                $sum += $gap;
                $rows = $this->db->get_results($this->db->prepare("SELECT ws.id,ws.warehouse_id,ws.qty,w.is_default FROM {$this->warehouse_stock_table} ws INNER JOIN {$this->warehouses_table} w ON w.id=ws.warehouse_id WHERE ws.inventory_id=%d ORDER BY w.is_default DESC,ws.qty DESC FOR UPDATE",$inventory_id),ARRAY_A) ?: [];
            }
        }
        if ( $change_qty > 0 ) {
            $default_row = $this->db->get_row($this->db->prepare("SELECT id,qty FROM {$this->warehouse_stock_table} WHERE warehouse_id=%d AND inventory_id=%d FOR UPDATE",$default_id,$inventory_id),ARRAY_A);
            if($default_row){return $this->db->update($this->warehouse_stock_table,['qty'=>(float)$default_row['qty']+$change_qty,'updated_at'=>current_time('mysql')],['id'=>(int)$default_row['id']]) !== false;}
            return (bool)$this->db->insert($this->warehouse_stock_table,['warehouse_id'=>$default_id,'inventory_id'=>$inventory_id,'qty'=>$change_qty,'updated_at'=>current_time('mysql')]);
        }
        $remaining = abs($change_qty);
        foreach($rows as $row){
            if($remaining <= 0.000001) break;
            $available = (float)$row['qty'];
            if($available <= 0) continue;
            $take = min($available,$remaining);
            $ok = $this->db->update($this->warehouse_stock_table,['qty'=>max(0,$available-$take),'updated_at'=>current_time('mysql')],['id'=>(int)$row['id']]);
            if($ok === false) return false;
            $remaining -= $take;
        }
        return round($remaining, 5) <= 0;
    }


    private function apply_warehouse_batch_delta( int $batch_id, float $previous_qty, float $change_qty ): bool {
        $raw_id=(int)$this->db->get_var($this->db->prepare("SELECT raw_product_id FROM {$this->batches} WHERE id=%d",$batch_id));
        if($this->is_supply_raw_product($raw_id))return true;
        $default_id = (int)$this->db->get_var("SELECT id FROM {$this->warehouses_table} WHERE is_default=1 LIMIT 1");
        if($default_id<=0)return false;
        $rows=$this->db->get_results($this->db->prepare(
            "SELECT ws.id,ws.warehouse_id,ws.qty_weight,w.is_default FROM {$this->warehouse_batch_stock_table} ws
             INNER JOIN {$this->warehouses_table} w ON w.id=ws.warehouse_id WHERE ws.batch_id=%d
             ORDER BY w.is_default DESC,ws.qty_weight DESC FOR UPDATE",$batch_id
        ),ARRAY_A)?:[];
        $sum=0.0;foreach($rows as $row){$sum+=(float)$row['qty_weight'];}
        $target=$previous_qty+$change_qty;
        if(abs($sum-$target)<0.000001)return true;
        if(abs($sum-$previous_qty)>0.000001){
            if($sum>$previous_qty+0.000001)return false;
            $gap=$previous_qty-$sum;
            if($gap>0){
                $default_row=$this->db->get_row($this->db->prepare("SELECT id,qty_weight FROM {$this->warehouse_batch_stock_table} WHERE warehouse_id=%d AND batch_id=%d FOR UPDATE",$default_id,$batch_id),ARRAY_A);
                if($default_row){$ok=$this->db->update($this->warehouse_batch_stock_table,['qty_weight'=>(float)$default_row['qty_weight']+$gap,'updated_at'=>current_time('mysql')],['id'=>(int)$default_row['id']]);}
                else{$ok=$this->db->insert($this->warehouse_batch_stock_table,['warehouse_id'=>$default_id,'batch_id'=>$batch_id,'qty_weight'=>$gap,'updated_at'=>current_time('mysql')]);}
                if(!$ok)return false;
                $rows=$this->db->get_results($this->db->prepare("SELECT ws.id,ws.warehouse_id,ws.qty_weight,w.is_default FROM {$this->warehouse_batch_stock_table} ws INNER JOIN {$this->warehouses_table} w ON w.id=ws.warehouse_id WHERE ws.batch_id=%d ORDER BY w.is_default DESC,ws.qty_weight DESC FOR UPDATE",$batch_id),ARRAY_A)?:[];
            }
        }
        if($change_qty>0){
            $default_row=$this->db->get_row($this->db->prepare("SELECT id,qty_weight FROM {$this->warehouse_batch_stock_table} WHERE warehouse_id=%d AND batch_id=%d FOR UPDATE",$default_id,$batch_id),ARRAY_A);
            if($default_row)return $this->db->update($this->warehouse_batch_stock_table,['qty_weight'=>(float)$default_row['qty_weight']+$change_qty,'updated_at'=>current_time('mysql')],['id'=>(int)$default_row['id']])!==false;
            return (bool)$this->db->insert($this->warehouse_batch_stock_table,['warehouse_id'=>$default_id,'batch_id'=>$batch_id,'qty_weight'=>$change_qty,'updated_at'=>current_time('mysql')]);
        }
        $remaining=abs($change_qty);
        foreach($rows as $row){if($remaining<=0.000001)break;$available=(float)$row['qty_weight'];if($available<=0)continue;$take=min($available,$remaining);$ok=$this->db->update($this->warehouse_batch_stock_table,['qty_weight'=>max(0,$available-$take),'updated_at'=>current_time('mysql')],['id'=>(int)$row['id']]);if($ok===false)return false;$remaining-=$take;}
        return $remaining<=0.00001;
    }

    /** Read page-sized warehouse allocations; never infer or rewrite an allocation. */
    public function get_warehouse_distribution(string $kind,array $ids):array {
        if(!in_array($kind,['finished','raw'],true))throw new InvalidArgumentException('Invalid inventory kind');
        $ids=array_values(array_unique(array_filter(array_map('absint',$ids))));
        if(!$ids)return [];
        $field=$kind==='finished'?'inventory_id':'batch_id';
        $quantity=$kind==='finished'?'qty':'qty_weight';
        $table=$kind==='finished'?$this->warehouse_stock_table:$this->warehouse_batch_stock_table;
        $join=$kind==='raw'?" INNER JOIN {$this->batches} b ON b.id=ws.batch_id INNER JOIN {$this->raw_products} rp ON rp.id=b.raw_product_id ":'';
        $ordinary=$kind==='raw'?' AND '.$this->ordinary_raw_condition('rp'):'';
        $holders=implode(',',array_fill(0,count($ids),'%d'));
        $rows=$this->db->get_results($this->db->prepare(
            "SELECT ws.$field AS item_id,ws.warehouse_id,ws.$quantity AS quantity,w.name,w.is_active,w.is_default
             FROM $table ws INNER JOIN {$this->warehouses_table} w ON w.id=ws.warehouse_id $join
             WHERE ws.$field IN ($holders) AND ws.$quantity>0 $ordinary
             ORDER BY w.is_default DESC,w.name,w.id",$ids),ARRAY_A);
        if($this->db->last_error)throw new RuntimeException('خواندن تفکیک انبارها انجام نشد.');
        $result=array_fill_keys($ids,[]);
        foreach($rows?:[] as $row)$result[(int)$row['item_id']][]=$row;
        return $result;
    }

    private function warehouse_filter_sql(int $id,array $filters,string $kind): string {
        $where=[];
        if($id>0)$where[]=$this->db->prepare($kind==='moves'?'(m.source_warehouse_id=%d OR m.target_warehouse_id=%d)':'ws.warehouse_id=%d',...($kind==='moves'?[$id,$id]:[$id]));
        $q=sanitize_text_field((string)($filters['search']??''));
        if($q!==''){
            $like='%'.$this->db->esc_like($q).'%';
            if($kind==='raw')$where[]=$this->db->prepare('(rp.title LIKE %s OR rp.code LIKE %s OR CAST(b.id AS CHAR) LIKE %s)',$like,$like,$like);
            elseif($kind==='finished')$where[]=$this->db->prepare('(p.post_title LIKE %s OR ib.unique_product_code LIKE %s)',$like,$like);
            else $where[]=$this->db->prepare('(p.post_title LIKE %s OR ib.unique_product_code LIKE %s OR rp.title LIKE %s OR m.note LIKE %s)',$like,$like,$like,$like);
        }
        if($kind==='raw')$where[]=$this->ordinary_raw_condition('rp');
        if($kind==='moves')$where[]='(COALESCE(m.batch_id,0)=0 OR ('.$this->ordinary_raw_condition('rp').'))';
        $category=absint($filters['category_id']??0);
        if($category>0 && $kind==='raw')$where[]=$this->db->prepare('rp.category_id=%d',$category);
        if($category>0 && $kind==='moves')$where[]=$this->db->prepare('(COALESCE(m.batch_id,0)=0 OR rp.category_id=%d)',$category);
        if($kind==='finished' && !empty($filters['only_available']))$where[]='ws.qty>0';
        if($kind==='raw')$where[]='ws.qty_weight>0';
        $item_kind=$filters['item_kind']??'';
        if($kind==='moves'&&in_array($item_kind,['raw','finished'],true))$where[]=$item_kind==='raw'?'COALESCE(m.batch_id,0)>0':'COALESCE(m.batch_id,0)=0';
        return $where?' AND '.implode(' AND ',$where):'';
    }
    public function get_warehouse_batch_stock(int $warehouse_id=0,array $filters=[]): array {
        $this->create_multiwarehouse_tables();
        $where=$this->warehouse_filter_sql($warehouse_id,$filters,'raw');
        return $this->db->get_results(
            "SELECT ws.warehouse_id,w.name AS warehouse_name,ws.batch_id,ws.qty_weight,b.raw_product_id,rp.title AS raw_product_title,
                    rp.category_id,rp.base_uom,c.title AS category_name,b.source_type,b.source_id,b.created_at
             FROM {$this->warehouse_batch_stock_table} ws
             INNER JOIN {$this->warehouses_table} w ON w.id=ws.warehouse_id
             INNER JOIN {$this->batches} b ON b.id=ws.batch_id
             INNER JOIN {$this->raw_products} rp ON rp.id=b.raw_product_id
             LEFT JOIN {$this->raw_categories} c ON c.id=rp.category_id
             WHERE w.is_active=1 $where ORDER BY w.name,rp.title,b.id DESC",ARRAY_A
        )?:[];
    }

    public function transfer_warehouse_batch( int $source_id, int $target_id, int $batch_id, float $qty, string $note = '' ): array {
        $this->create_multiwarehouse_tables();
        if($source_id<=0||$target_id<=0||$source_id===$target_id||$batch_id<=0||$qty<=0||!is_finite($qty)||abs($qty-round($qty,6))>0.00000001)return $this->fail('اطلاعات انتقال محموله معتبر نیست.');
        $this->db->query('START TRANSACTION');
        $warehouse_types=$this->db->get_col($this->db->prepare("SELECT warehouse_type FROM {$this->warehouses_table} WHERE is_active=1 AND id IN (%d,%d)",$source_id,$target_id));
        if(count($warehouse_types)!==2 || array_diff($warehouse_types,['mixed','raw','semi'])){$this->db->query('ROLLBACK');return $this->fail('انتقال مواد اولیه فقط بین انبارهای مواد اولیه، ترکیبی یا نیمه‌ساخته مجاز است.');}
        $batch=$this->db->get_row($this->db->prepare("SELECT id,raw_product_id FROM {$this->batches} WHERE id=%d FOR UPDATE",$batch_id),ARRAY_A);
        if(!$batch){$this->db->query('ROLLBACK');return $this->fail('محموله پیدا نشد.');}
        if($this->is_supply_raw_product((int)$batch['raw_product_id'])){$this->db->query('ROLLBACK');return $this->fail('چاپ و قوطی در مدیریت چندانباره دخالت ندارند؛ از ملزومات بسته‌بندی استفاده کنید.');}
        $src=$this->db->get_row($this->db->prepare("SELECT id,qty_weight FROM {$this->warehouse_batch_stock_table} WHERE warehouse_id=%d AND batch_id=%d FOR UPDATE",$source_id,$batch_id),ARRAY_A);
        if(!$src || (int)round((float)$src['qty_weight']*1000000) < (int)round($qty*1000000)){$this->db->query('ROLLBACK');return $this->fail('وزن تخصیص‌یافته در انبار مبدأ کافی نیست.');}
        $dst=$this->db->get_row($this->db->prepare("SELECT id,qty_weight FROM {$this->warehouse_batch_stock_table} WHERE warehouse_id=%d AND batch_id=%d FOR UPDATE",$target_id,$batch_id),ARRAY_A);
        $a=$this->db->update($this->warehouse_batch_stock_table,['qty_weight'=>max(0,(float)$src['qty_weight']-$qty),'updated_at'=>current_time('mysql')],['id'=>(int)$src['id']]);
        if($dst){$b=$this->db->update($this->warehouse_batch_stock_table,['qty_weight'=>(float)$dst['qty_weight']+$qty,'updated_at'=>current_time('mysql')],['id'=>(int)$dst['id']]);}
        else{$b=$this->db->insert($this->warehouse_batch_stock_table,['warehouse_id'=>$target_id,'batch_id'=>$batch_id,'qty_weight'=>$qty,'updated_at'=>current_time('mysql')]);}
        $m=$this->db->insert($this->warehouse_moves_table,['source_warehouse_id'=>$source_id,'target_warehouse_id'=>$target_id,'inventory_id'=>0,'batch_id'=>$batch_id,'qty'=>$qty,'note'=>sanitize_textarea_field($note),'created_by'=>get_current_user_id(),'created_at'=>current_time('mysql')]);
        if($a===false||$b===false||!$m){$this->db->query('ROLLBACK');return $this->fail('ثبت انتقال محموله ناموفق بود؛ تغییری اعمال نشد.');}
        $this->db->query('COMMIT');return $this->ok('انتقال محموله بین انبارها ثبت شد.');
    }

    public function get_warehouse_moves( int $limit = 100, int $warehouse_id=0, array $filters=[] ): array {
        $this->create_multiwarehouse_tables();
        $limit = max(1,min(500,$limit));
        $where=$this->warehouse_filter_sql($warehouse_id,$filters,'moves');
        return $this->db->get_results($this->db->prepare(
            "SELECT m.*,s.name AS source_name,t.name AS target_name,ib.unique_product_code,ib.wc_product_id,COALESCE(p.post_title,rp.title) AS product_name
             FROM {$this->warehouse_moves_table} m
             LEFT JOIN {$this->warehouses_table} s ON s.id=m.source_warehouse_id
             LEFT JOIN {$this->warehouses_table} t ON t.id=m.target_warehouse_id
             LEFT JOIN {$this->inventory_balance} ib ON ib.id=m.inventory_id
             LEFT JOIN {$this->db->posts} p ON p.ID=ib.wc_product_id
             LEFT JOIN {$this->batches} b ON b.id=m.batch_id
             LEFT JOIN {$this->raw_products} rp ON rp.id=b.raw_product_id
             WHERE 1=1 $where ORDER BY m.id DESC LIMIT %d",$limit
        ),ARRAY_A) ?: [];
    }

    public function get_warehouses(): array {
        $this->create_multiwarehouse_tables();
        return $this->db->get_results( "SELECT * FROM {$this->warehouses_table} WHERE is_active=1 ORDER BY is_default DESC,name ASC", ARRAY_A ) ?: [];
    }

    public function create_warehouse( string $name, string $code, string $type = 'finished' ): array {
        $this->create_multiwarehouse_tables();
        $name = sanitize_text_field( $name ); $code = strtoupper( sanitize_key( $code ) );
        $type = sanitize_key($type); if(!in_array($type,['mixed','finished','raw','semi'],true)) $type='mixed';
        if ( $name === '' || $code === '' ) return $this->fail('نام و کد انبار الزامی است.');
        $ok = $this->db->insert( $this->warehouses_table, [
            'name'=>$name,'code'=>$code,'warehouse_type'=>$type,'is_default'=>0,'is_active'=>1,
            'created_by'=>get_current_user_id(),'created_at'=>current_time('mysql')
        ] );
        if ( ! $ok ) return $this->fail('ایجاد انبار انجام نشد؛ احتمالاً کد انبار تکراری است.');
        return $this->ok('انبار جدید ایجاد شد.', ['warehouse_id'=>(int)$this->db->insert_id]);
    }

    public function get_warehouse_stock( int $warehouse_id = 0, array $filters=[] ): array {
        $this->create_multiwarehouse_tables();
        $where = $this->warehouse_filter_sql($warehouse_id,$filters,'finished');
        return $this->db->get_results(
            "SELECT ws.warehouse_id, w.name AS warehouse_name, ws.inventory_id, ws.qty,
                    ib.wc_product_id, ib.unique_product_code, ib.avg_unit_cost, (ws.qty * ib.avg_unit_cost) AS allocated_value,
                    p.post_title AS product_name
             FROM {$this->warehouse_stock_table} ws
             INNER JOIN {$this->warehouses_table} w ON w.id=ws.warehouse_id
             INNER JOIN {$this->inventory_balance} ib ON ib.id=ws.inventory_id
             LEFT JOIN {$this->db->posts} p ON p.ID=ib.wc_product_id
             WHERE w.is_active=1 {$where} ORDER BY w.name,p.post_title,ib.unique_product_code", ARRAY_A
        ) ?: [];
    }

    public function transfer_warehouse_stock( int $source_id, int $target_id, int $inventory_id, int $qty, string $note = '' ): array {
        $this->create_multiwarehouse_tables();
        if ( $source_id <= 0 || $target_id <= 0 || $source_id === $target_id || $inventory_id <= 0 || $qty <= 0 ) return $this->fail('اطلاعات انتقال معتبر نیست.');
        $this->db->query('START TRANSACTION');
        $warehouse_types = $this->db->get_col($this->db->prepare("SELECT warehouse_type FROM {$this->warehouses_table} WHERE is_active=1 AND id IN (%d,%d)",$source_id,$target_id));
        if(count($warehouse_types)!==2 || array_diff($warehouse_types,['mixed','finished','semi'])){$this->db->query('ROLLBACK');return $this->fail('انتقال محصول نهایی فقط بین انبارهای محصول، ترکیبی یا نیمه‌ساخته مجاز است.');}
        $inv = $this->db->get_row($this->db->prepare("SELECT id,qty_available FROM {$this->inventory_balance} WHERE id=%d FOR UPDATE",$inventory_id),ARRAY_A);
        if ( ! $inv ) { $this->db->query('ROLLBACK'); return $this->fail('قلم موجودی پیدا نشد.'); }
        $src = $this->db->get_row($this->db->prepare("SELECT id,qty FROM {$this->warehouse_stock_table} WHERE warehouse_id=%d AND inventory_id=%d FOR UPDATE",$source_id,$inventory_id),ARRAY_A);
        if ( ! $src || (float)$src['qty'] + 0.000001 < $qty ) { $this->db->query('ROLLBACK'); return $this->fail('موجودی انبار مبدأ برای انتقال کافی نیست.'); }
        $dst = $this->db->get_row($this->db->prepare("SELECT id,qty FROM {$this->warehouse_stock_table} WHERE warehouse_id=%d AND inventory_id=%d FOR UPDATE",$target_id,$inventory_id),ARRAY_A);
        $src_ok = $this->db->update($this->warehouse_stock_table,['qty'=>max(0,(float)$src['qty']-$qty),'updated_at'=>current_time('mysql')],['id'=>(int)$src['id']]);
        if ( $dst ) { $dst_ok = $this->db->update($this->warehouse_stock_table,['qty'=>(float)$dst['qty']+$qty,'updated_at'=>current_time('mysql')],['id'=>(int)$dst['id']]); }
        else { $dst_ok = $this->db->insert($this->warehouse_stock_table,['warehouse_id'=>$target_id,'inventory_id'=>$inventory_id,'qty'=>$qty,'updated_at'=>current_time('mysql')]); }
        $move_ok = $this->db->insert($this->warehouse_moves_table,[
            'source_warehouse_id'=>$source_id,'target_warehouse_id'=>$target_id,'inventory_id'=>$inventory_id,
            'qty'=>$qty,'note'=>sanitize_textarea_field($note),'created_by'=>get_current_user_id(),'created_at'=>current_time('mysql')
        ]);
        if ( $src_ok === false || $dst_ok === false || ! $move_ok ) { $this->db->query('ROLLBACK'); return $this->fail('ثبت انتقال ناموفق بود؛ هیچ تغییری اعمال نشد.'); }
        $this->db->query('COMMIT');
        return $this->ok('انتقال بین انبارها با موفقیت ثبت شد.');
    }
}
