<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

trait kph_workflow_updates {
	/** A read-only, non-financial preparation report of explicitly selected open orders. */
	public function get_preparation_orders( array $ids ): array {
		if ( ! kph_preparation_print_allowed() ) { return $this->fail( 'اجازه چاپ لیست آماده‌سازی را ندارید.', [ 'http_status' => 403 ] ); }
		$ids = array_values( array_unique( array_filter( array_map( 'absint', array_filter( $ids, 'is_scalar' ) ) ) ) );
		if ( ! $ids || count( $ids ) > 500 ) { return $this->fail( 'از ۱ تا ۵۰۰ پیش‌فاکتور را برای هر نوبت چاپ انتخاب کنید.' ); }
		$orders = [];
		foreach ( $ids as $id ) {
			if ( ! $this->visitor_can_access_order( $id ) ) { return $this->fail( 'اجازه دسترسی به یکی از سفارش‌های انتخاب‌شده را ندارید.', [ 'http_status' => 403 ] ); }
			$order = $this->get_order_data( $id );
			if ( $this->db->last_error ) { return $this->fail( 'خواندن اقلام سفارش انجام نشد؛ دوباره تلاش کنید.', [ 'http_status' => 500 ] ); }
			if ( ! $order ) { return $this->fail( 'سفارش شماره ' . $id . ' یافت نشد؛ فهرست را به‌روز کنید.', [ 'http_status' => 404 ] ); }
			if ( $order['status'] !== 'proforma' ) { return $this->fail( 'سفارش شماره ' . $id . ' دیگر پیش‌فاکتور باز نیست؛ انتخاب‌ها را به‌روز کنید.', [ 'http_status' => 409 ] ); }
			$items = [];
			foreach ( $order['items'] as $item ) {
				$qty = max( 0, (float) $item['qty_ordered'] );
				$free = max( 0, (int) $item['expected_free_qty'] );
				if ( $qty + $free == 0 ) { continue; }
				$title = get_the_title( (int) $item['wc_product_id'] );
				$items[] = [ 'product_title' => $title ?: 'محصول #' . (int) $item['wc_product_id'],
					'qty_ordered' => $qty, 'free_qty' => $free, 'preparation_qty' => $qty + $free ];
			}
			if ( ! $items ) { return $this->fail( 'پیش‌فاکتور شماره ' . $id . ' هیچ قلمی برای آماده‌سازی ندارد.', [ 'http_status' => 409 ] ); }
			$orders[] = [ 'id' => $id, 'customer_id' => (int) $order['customer_id'], 'created_at' => $order['created_at'], 'items' => $items ];
		}
		return $this->ok( '', $orders );
	}

	private function production_codes_table(): string {
		return $this->db_prefix . 'production_codes';
	}

	public function normalize_production_code( string $code ): string {
		return trim( strtr( $code, array_combine(
			preg_split( '//u', '۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩', -1, PREG_SPLIT_NO_EMPTY ),
			str_split( '01234567890123456789' )
		) ) );
	}

	private function create_production_codes_table(): void {
		$table = $this->production_codes_table();
		maybe_create_table( $table, "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			code VARCHAR(64) NOT NULL,
			wc_product_id BIGINT UNSIGNED NOT NULL,
			created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id), UNIQUE KEY code (code), KEY wc_product_id (wc_product_id)
		) ENGINE=InnoDB " . $this->db->get_charset_collate() );
	}

	private function workflow_tables( string $workflow ): array {
		$production = [ $this->production_codes_table(), $this->processing_packs,
			$this->packaging_lots, $this->packaging_moves, $this->shop_conversions,
			$this->inventory_balance, $this->inventory_log, $this->db_prefix . 'shop_conversion_meta',
			$this->db_prefix . 'packaging_lot_meta', $this->warehouse_stock_table, $this->warehouses_table ];
		$supplier = [ $this->supplier_invoices, $this->supplier_invoice_items,
			$this->db_prefix . 'invoice_meta', $this->db_prefix . 'invoice_item_meta' ];
		$groups = [
            'production' => $production,
            'supplier' => $supplier,
            'proforma' => [$this->orders, $this->order_items, $this->db_prefix.'orders_meta',
                $this->db_prefix.'order_items_meta', $this->actions_table, $this->db_prefix.'action_meta'],
            'endorsement' => [$this->cheques, $this->cheque_moves, $this->db_prefix.'cheque_meta',
                $this->ledger_entries, $this->db_prefix.'ledger_entry_meta'],
        ];
        return $groups[$workflow] ?? array_merge(...array_values($groups));
	}

	public function workflow_storage_ready( string $workflow = 'all' ): bool {
		foreach ( $this->workflow_tables( $workflow ) as $table ) {
			$row = $this->db->get_row( $this->db->prepare( 'SHOW TABLE STATUS LIKE %s', $this->db->esc_like( $table ) ), ARRAY_A );
			if ( ! $row || strcasecmp( (string) $row['Engine'], 'InnoDB' ) !== 0 ) { return FALSE; }
		}
		return TRUE;
	}

	/** Explicit administrator maintenance; never run DDL inside a business transaction. */
	public function prepare_workflow_storage(bool $operations_only = false): array {
		if ( ! kph_plugin_management_allowed() ) { return $this->fail( 'فقط مدیر می‌تواند آماده‌سازی را انجام دهد.' ); }
		$tables = $operations_only
            ? array_merge($this->workflow_tables('production'), $this->workflow_tables('proforma'), $this->workflow_tables('endorsement'))
            : $this->workflow_tables('all');
        foreach ($tables as $table) {
			$row = $this->db->get_row( $this->db->prepare( 'SHOW TABLE STATUS LIKE %s', $this->db->esc_like( $table ) ), ARRAY_A );
			if ( ! $row ) { return $this->fail( 'جدول مورد نیاز یافت نشد: ' . $table ); }
			if ( strcasecmp( (string) $row['Engine'], 'InnoDB' ) !== 0 && FALSE === $this->db->query( "ALTER TABLE `{$table}` ENGINE=InnoDB" ) ) {
				return $this->fail( 'آماده‌سازی جدول انجام نشد: ' . $table );
			}
		}
        if ($operations_only) return $this->ok('جدول‌های تولید، پیش‌فاکتور و واگذاری چک آماده شدند.');
		$seed = $this->seed_production_codes();
		if ( $seed['status'] !== 'success' ) { return $seed; }
		return $this->ok( 'ثبت یکپارچه آماده شد و کدهای موجودی به فهرست کدهای تولید اضافه شدند.' );
	}

	/** The established inventory mapping is authoritative; historical failed conversions do not reassign codes. */
	public function seed_production_codes(): array {
		$rows = $this->db->get_results( "SELECT unique_product_code, wc_product_id FROM {$this->inventory_balance}", ARRAY_A );
		if ( $this->db->last_error ) { return $this->fail( 'خواندن کدهای موجودی ناموفق بود.' ); }
		$table = $this->production_codes_table();
		foreach ( $rows as $row ) {
			$code = $this->normalize_production_code( (string) $row['unique_product_code'] );
			if ( $code === '' || $code !== (string) $row['unique_product_code'] ) {
				return $this->fail( 'کدهای قدیمی با فاصله یا ارقام غیراستاندارد باید پیش از انتقال بررسی شوند.' );
			}
			$existing = $this->db->get_row( $this->db->prepare( "SELECT * FROM {$table} WHERE code = %s", $code ), ARRAY_A );
			if ( $existing ) {
				if ( (int) $existing['wc_product_id'] !== (int) $row['wc_product_id'] ) { return $this->fail( 'ارتباط کد تولید با موجودی ناسازگار است: ' . $code ); }
				continue;
			}
			if ( FALSE === $this->db->insert( $table, [ 'code' => $code, 'wc_product_id' => (int) $row['wc_product_id'], 'created_by' => 0, 'created_at' => current_time( 'mysql' ) ] ) ) {
				return $this->fail( 'انتقال کد موجودی ناموفق بود: ' . $code );
			}
		}
		return $this->ok();
	}

	public function search_production_codes( string $search, int $page = 1 ): array {
		$search = $this->normalize_production_code( sanitize_text_field( $search ) );
		$table = $this->production_codes_table();
		$like = '%' . $this->db->esc_like( $search ) . '%';
		$items=$this->db->get_results( $this->db->prepare(
			"SELECT c.id, c.code, c.wc_product_id, p.post_title AS title FROM {$table} c
			INNER JOIN {$this->db->posts} p ON p.ID = c.wc_product_id
			WHERE p.post_type = 'product' AND p.post_status = 'publish'
			AND (c.code LIKE %s OR p.post_title LIKE %s)
			ORDER BY (c.code = %s) DESC, p.post_title, c.code LIMIT 30 OFFSET %d", $like, $like, $search, ( max( 1, min( 100000, $page ) ) - 1 ) * 30
		), ARRAY_A ) ?: [];
        foreach($items as &$item)$item['standard_weight_grams']=kph_product_weight::standard_grams((string)$item['title']);
        unset($item);
        return $items;
	}

	public function register_production_code( string $code, int $product_id ): array {
		if ( ! kph_plugin_management_allowed() ) { return $this->fail( 'تعریف کد تولید فقط برای مدیر مجاز است.' ); }
		$code = $this->normalize_production_code( sanitize_text_field( $code ) );
		if ( $code === '' || mb_strlen( $code ) > 64 || preg_match( '/[\x00-\x1f\x7f]/u', $code ) ) { return $this->fail( 'کد تولید معتبر نیست؛ حداکثر ۶۴ نویسه وارد کنید.' ); }
		$product = get_post( $product_id );
		if ( ! $product || $product->post_type !== 'product' || $product->post_status !== 'publish' ) { return $this->fail( 'محصول معتبر و منتشرشده را انتخاب کنید.' ); }
		$table = $this->production_codes_table();
		if ( $this->db->get_var( $this->db->prepare( "SELECT id FROM {$table} WHERE code = %s", $code ) )
			|| $this->db->get_var( $this->db->prepare( "SELECT id FROM {$this->inventory_balance} WHERE unique_product_code = %s", $code ) ) ) {
			return $this->fail( 'این کد قبلاً تعریف شده است؛ از جستجوی کدهای موجود انتخاب کنید.' );
		}
		// A code with historical activity must be reviewed, even if its balance was removed.
		foreach ( [ $this->shop_conversions, $this->inventory_log ] as $history ) {
			if ( $this->db->get_var( $this->db->prepare( "SELECT id FROM {$history} WHERE unique_product_code = %s LIMIT 1", $code ) ) ) {
				return $this->fail( 'این کد سابقه دارد و برای تعریف مجدد باید بررسی شود.' );
			}
		}
		if ( FALSE === $this->db->insert( $table, [ 'code' => $code, 'wc_product_id' => $product_id, 'created_by' => get_current_user_id(), 'created_at' => current_time( 'mysql' ) ] ) ) {
			return $this->fail( 'تعریف کد انجام نشد؛ ممکن است هم‌زمان ثبت شده باشد.' );
		}
		return $this->ok( 'کد تولید تعریف شد.', [ 'id' => (int) $this->db->insert_id, 'code' => $code, 'wc_product_id' => $product_id, 'title' => $product->post_title, 'standard_weight_grams'=>kph_product_weight::standard_grams((string)$product->post_title) ] );
	}

	public function get_production_code( int $id ): ?array {
		$table = $this->production_codes_table();
		return $this->db->get_row( $this->db->prepare( "SELECT c.* FROM {$table} c
			INNER JOIN {$this->db->posts} p ON p.ID = c.wc_product_id
			WHERE c.id = %d AND p.post_type = 'product' AND p.post_status = 'publish'", $id ), ARRAY_A );
	}

	public function production_conversion_conflicts(): array {
		return $this->db->get_results( "SELECT sc.id, sc.unique_product_code AS code, sc.qty_items, sc.weight_per_item, sc.packaging_cost_per_item,
			sc.packaging_lot_id, sc.wc_product_id AS wrong_product_id, ib.wc_product_id AS expected_product_id,
			p.post_title AS wrong_title, ep.post_title AS expected_title
			FROM {$this->shop_conversions} sc INNER JOIN {$this->inventory_balance} ib ON ib.unique_product_code = sc.unique_product_code
			LEFT JOIN {$this->db->posts} p ON p.ID = sc.wc_product_id LEFT JOIN {$this->db->posts} ep ON ep.ID = ib.wc_product_id
			WHERE sc.wc_product_id <> ib.wc_product_id ORDER BY sc.id", ARRAY_A ) ?: [];
	}

	/** Repair only an unfulfilled, incomplete conversion. Unit changes require explicit administrator input. */
	public function repair_incomplete_conversion( int $conversion_id, ?float $weight_per_item = NULL ): array {
		if ( ! kph_plugin_management_allowed() || ! $this->workflow_storage_ready( 'production' ) ) { return $this->fail( 'آماده‌سازی ثبت یکپارچه و دسترسی مدیر لازم است.' ); }
		if ( FALSE === $this->db->query( 'START TRANSACTION' ) ) { return $this->fail( 'تراکنش آغاز نشد.' ); }
		$abort = function( string $message ): array { $this->db->query( 'ROLLBACK' ); return $this->fail( $message ); };
		$c = $this->db->get_row( $this->db->prepare( "SELECT * FROM {$this->shop_conversions} WHERE id = %d FOR UPDATE", $conversion_id ), ARRAY_A );
		if ( ! $c ) { return $abort( 'تبدیل یافت نشد.' ); }
		$b = $this->db->get_row( $this->db->prepare( "SELECT * FROM {$this->inventory_balance} WHERE unique_product_code = %s FOR UPDATE", $c['unique_product_code'] ), ARRAY_A );
		if ( ! $b || (int) $b['wc_product_id'] === (int) $c['wc_product_id'] ) { return $abort( 'این تبدیل ناسازگار نیست یا قبلاً اصلاح شده است.' ); }
		$baseline = $this->db->get_row( $this->db->prepare( "SELECT COALESCE(SUM(change_qty),0) AS qty, COALESCE(SUM(total_cost),0) AS value
			FROM {$this->inventory_log} WHERE unique_product_code = %s AND wc_product_id = %d", $c['unique_product_code'], $b['wc_product_id'] ), ARRAY_A );
		if ( ! $baseline || (int) $baseline['qty'] !== (int) $b['qty_available'] || abs( (float) $baseline['value'] - (float) $b['inventory_value'] ) > 0.01 ) {
			return $abort( 'موجودی با گردش ثبت‌شده مطابقت ندارد؛ اصلاح خودکار مجاز نیست.' );
		}
		$logs = $this->db->get_results( $this->db->prepare( "SELECT * FROM {$this->inventory_log}
			WHERE unique_product_code = %s AND wc_product_id = %d FOR UPDATE", $c['unique_product_code'], $c['wc_product_id'] ), ARRAY_A );
		if ( count( $logs ) !== 1 || $logs[0]['ref_type'] !== 'production' || (int) $logs[0]['ref_id'] !== $conversion_id
			|| (int) $logs[0]['change_qty'] !== (int) $c['qty_items'] || (float) $logs[0]['total_cost'] !== (float) $c['total_cost'] ) {
			return $abort( 'این مورد سابقه دیگری دارد و نیازمند بررسی دستی است.' );
		}
		$move = $this->db->get_row( $this->db->prepare( "SELECT * FROM {$this->packaging_moves}
			WHERE packaging_lot_id = %d AND reason = 'convert_to_shop_product' AND ref_type = 'shop_conversion' AND ref_id = %d FOR UPDATE", $c['packaging_lot_id'], $conversion_id ), ARRAY_A );
		if ( ! $move || abs( (float) $move['qty_weight'] - (int) $c['qty_items'] * (float) $c['weight_per_item'] ) > 0.000001 ) {
			return $abort( 'گردش خروج سالن با تبدیل مطابقت ندارد.' );
		}
		$qty = (int) $c['qty_items'];
		$weight = (float) $c['weight_per_item'];
		$packaging_total = (float) $c['total_packaging_cost'];
		$total_cost = (float) $c['total_cost'];
		$unit_cost = (float) $c['unit_cost_final'];
		if ( $weight_per_item !== NULL && $weight_per_item !== $weight ) {
			if ( ! is_finite( $weight_per_item ) || $weight_per_item <= 0 ) { return $abort( 'وزن هر آیتم معتبر نیست.' ); }
			$weight = round( $weight_per_item, 6 );
			if ( $weight <= 0 ) { return $abort( 'وزن هر آیتم معتبر نیست.' ); }
			$qty = (int) round( (float) $move['qty_weight'] / $weight );
			if ( $qty <= 0 || abs( $qty * $weight - (float) $move['qty_weight'] ) > 0.000001 ) {
				return $abort( 'وزن کل باید دقیقاً به تعداد صحیح آیتم تقسیم شود؛ اصلاح دستی لازم است.' );
			}
			$packaging_total = round( $qty * (float) $c['packaging_cost_per_item'], 2 );
			$total_cost = round( (float) $c['total_material_cost'] + $packaging_total, 2 );
			$unit_cost = round( $total_cost / $qty, 2 );
		}
		if ( FALSE === $this->db->update( $this->shop_conversions, [ 'wc_product_id' => (int) $b['wc_product_id'], 'qty_items' => $qty, 'weight_per_item' => $weight,
			'total_packaging_cost' => $packaging_total, 'total_cost' => $total_cost, 'unit_cost_final' => $unit_cost ], [ 'id' => $conversion_id ] )
			|| FALSE === $this->db->update( $this->inventory_log, [ 'wc_product_id' => (int) $b['wc_product_id'], 'change_qty' => $qty,
			'unit_cost' => $unit_cost, 'total_cost' => $total_cost ], [ 'id' => (int) $logs[0]['id'] ] ) ) {
			return $abort( 'اصلاح ارتباط محصول انجام نشد.' );
		}
		$result = $this->apply_inventory_change( [ 'unique_product_code' => $c['unique_product_code'], 'wc_product_id' => (int) $b['wc_product_id'], 'change_qty' => $qty, 'total_cost' => $total_cost ] );
		if ( $result['status'] !== 'success' ) { return $abort( $result['message'] ); }
		$audit = $this->update_shop_conversion_meta( $conversion_id, 'product_mapping_repair', [ 'old_product_id' => (int) $c['wc_product_id'], 'new_product_id' => (int) $b['wc_product_id'],
			'old_qty' => (int) $c['qty_items'], 'new_qty' => $qty, 'old_weight' => (float) $c['weight_per_item'], 'new_weight' => $weight,
			'old_total_cost' => (float) $c['total_cost'], 'new_total_cost' => $total_cost, 'actor_id' => get_current_user_id(), 'at' => current_time( 'mysql' ) ] );
		if ( $audit['status'] !== 'success' || FALSE === $this->db->query( 'COMMIT' ) ) { return $abort( 'ذخیره اصلاحات کامل نشد.' ); }
		return $this->ok( 'ارتباط محصول اصلاح و موجودی تکمیل شد؛ تعداد: ' . $qty . '، وزن هر آیتم: ' . $weight . ' کیلوگرم.' );
	}

	public function cheque_note_print_all_enabled(): bool {
		return current_user_can( 'manage_options' ) && (string) get_option( 'kph_cheque_note_print_all', '0' ) === '1';
	}

	public function should_print_cheque_note( int $cheque_id ): bool {
		return current_user_can( 'manage_options' ) && ( $this->cheque_note_print_all_enabled()
			|| (string) $this->get_cheque_meta( $cheque_id, 'admin_note_print' ) === '1' );
	}

	public function set_cheque_note_print_all( bool $show ): array {
		if ( ! current_user_can( 'manage_options' ) ) { return $this->fail( 'اجازه تغییر چاپ یادداشت داخلی را ندارید.' ); }
		$value = $show ? '1' : '0';
		update_option( 'kph_cheque_note_print_all', $value, FALSE );
		if ( (string) get_option( 'kph_cheque_note_print_all', '0' ) !== $value ) {
			return $this->fail( 'تنظیم چاپ ذخیره نشد؛ دوباره تلاش کنید.' );
		}
		return $this->ok( 'تنظیم چاپ یادداشت همه چک‌ها ذخیره شد.', [ 'show' => $show ] );
	}

	public function set_cheque_note_print( int $cheque_id, bool $show ): array {
		if ( ! current_user_can( 'manage_options' ) || ! $this->get_cheque( $cheque_id ) ) { return $this->fail( 'چک معتبر یا دسترسی مدیر لازم است.' ); }
		return $this->update_cheque_meta( $cheque_id, 'admin_note_print', $show ? '1' : '0' );
	}
}
