<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
$DB = new kph_db();
$targets = $DB->get_visitor_targets( (int) $user_id );
$summary = $DB->get_visitor_summaries( [ (int) $user_id ] )[ $user_id ];
$can_manage = kph_plugin_management_allowed();
$edit_id = isset( $_REQUEST['target_id'] ) && is_scalar( $_REQUEST['target_id'] ) ? absint( $_REQUEST['target_id'] ) : 0;
$editing = $can_manage && isset( $targets[ $edit_id ] ) && ! $targets[ $edit_id ]['has_reward_history'] ? $targets[ $edit_id ] : [];
$edit_unavailable = $edit_id && ! $editing;
if ( ! $editing ) { $edit_id = 0; }
$today = current_time( 'Y-m-d' );
$current_targets = $history_targets = [];
foreach ( $targets as $id => $target ) {
    if ( $target['date_to'] < $today ) { $history_targets[ $id ] = $target; }
    else { $current_targets[ $id ] = $target; }
}
uasort( $current_targets, fn( $a, $b ) => strcmp( $a['date_from'], $b['date_from'] ) );
$orders_url = "/crm/employee/$user_id?tab=orders";
$targets_url = "/crm/employee/$user_id?tab=targets";
?>
<div class="kv-heading">
    <div><h4>تارگت و عملکرد فروش</h4><p>وضعیت مشتریان و مسیر رسیدن به پاداش را یک‌جا ببینید.</p></div>
    <?php if ( $can_manage ) { ?><button type="button" class="btn btn-primary kv-open-target"><em class="icon ni ni-plus" aria-hidden="true"></em><span><?php echo $edit_id ? 'ادامه ویرایش' : 'تعریف تارگت'; ?></span></button><?php } ?>
</div>
<div class="kv-overview">
    <div class="kv-stat"><span class="kv-stat-label">مانده خالص مشتریان</span>
        <div class="kv-stat-value"><bdi class="kv-number"><?php echo number_format( abs( $summary['customer_balance'] ) ); ?></bdi><small>ریال</small></div>
        <span class="kv-pill <?php echo $summary['customer_balance'] > 0 ? 'kv-pill--warning' : 'kv-pill--success'; ?>"><?php echo $summary['customer_balance'] > 0 ? 'بدهکار' : ( $summary['customer_balance'] < 0 ? 'بستانکار' : 'تسویه' ); ?></span>
        <p class="kv-help">جمع مانده بدهکار و بستانکار مشتریان فعلی</p>
    </div>
    <div class="kv-stat"><span class="kv-stat-label">سفارش‌های باز</span><div class="kv-stat-value"><bdi class="kv-number"><?php echo number_format( $summary['open_orders'] ); ?></bdi><small>سفارش</small></div>
        <p class="kv-help">پیش‌فاکتور، ثبت‌شده و دارای کسری</p>
        <a class="page_activator" href="<?php echo esc_url( $orders_url ); ?>" data-url="<?php echo esc_url( $orders_url ); ?>">مشاهده سفارش‌ها <em class="icon ni ni-arrow-left" aria-hidden="true"></em></a>
    </div>
    <div class="kv-stat"><span class="kv-stat-label">هدف فروش در بازه فعال</span><div class="kv-stat-value"><?php if ( $summary['target_amount'] > 0 ) { ?><bdi class="kv-number"><?php echo number_format( $summary['target_amount'] ); ?></bdi><small>ریال</small><?php } else { ?><span>تعیین نشده</span><?php } ?></div>
        <p class="kv-help">مبنای محاسبه: فروش ارسال‌شده پس از کسر برگشت</p>
    </div>
</div>
<?php if ( $edit_unavailable ) { ?><div class="alert alert-warning" role="status">این تارگت قابل ویرایش نیست. تارگت‌های دارای سابقه پاداش قفل می‌شوند.</div><?php } ?>
<?php if ( $can_manage ) { ?>
<details class="kv-form-panel" id="visitor-target-editor" <?php echo $edit_id || ! $targets ? 'open' : ''; ?>>
    <summary><?php echo $edit_id ? 'ویرایش تارگت' : 'تارگت جدید'; ?><small>بازه فروش، مبلغ هدف و پاداش را مشخص کنید.</small></summary>
    <form class="kv-target-form" data-action="kph_save_visitor_target" novalidate>
        <input type="hidden" data-for="id" value="<?php echo esc_attr( $user_id ); ?>">
        <input type="hidden" data-for="target_id" value="<?php echo esc_attr( $edit_id ); ?>">
        <input type="hidden" data-for="target_nonce" value="<?php echo esc_attr( wp_create_nonce( 'kph_visitor_target_' . $user_id ) ); ?>">
        <div class="kv-form-status" role="alert" tabindex="-1"></div>
        <div class="kv-form-grid">
            <div class="kv-full"><label class="form-label" for="visitor-target-title">عنوان تارگت</label>
                <input id="visitor-target-title" class="form-control" data-for="title" required maxlength="150" value="<?php echo esc_attr( $editing['title'] ?? '' ); ?>" placeholder="مثلاً فروش مهر ۱۴۰۵" aria-describedby="visitor-target-title-error">
                <span class="kv-field-error" id="visitor-target-title-error"></span></div>
            <?php foreach ( [ 'date_from' => 'تاریخ شروع', 'date_to' => 'تاریخ پایان' ] as $key => $label ) { ?>
            <div><label class="form-label" for="visitor-target-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?> <span class="kv-muted">(شمسی)</span></label>
                <input id="visitor-target-<?php echo esc_attr( $key ); ?>" class="form-control datepicker" data-for="<?php echo esc_attr( $key ); ?>" required value="<?php echo esc_attr( $editing[ $key . '_fa' ] ?? '' ); ?>" placeholder="۱۴۰۵-۰۷-۰۱" autocomplete="off" dir="ltr" aria-describedby="visitor-target-<?php echo esc_attr( $key ); ?>-error">
                <span class="kv-field-error" id="visitor-target-<?php echo esc_attr( $key ); ?>-error"></span></div>
            <?php } ?>
            <?php foreach ( [ 'amount' => 'هدف فروش', 'bonus' => 'پاداش تحقق هدف' ] as $key => $label ) { ?>
            <div><label class="form-label" for="visitor-target-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></label>
                <div class="kv-input-unit"><input id="visitor-target-<?php echo esc_attr( $key ); ?>" type="text" inputmode="numeric" class="form-control kv-money-input" data-for="<?php echo esc_attr( $key ); ?>" required value="<?php echo isset( $editing[ $key ] ) ? esc_attr( number_format( $editing[ $key ] ) ) : ''; ?>" placeholder="<?php echo $key === 'amount' ? '۱۰۰٬۰۰۰٬۰۰۰' : '۵٬۰۰۰٬۰۰۰'; ?>" aria-describedby="visitor-target-<?php echo esc_attr( $key ); ?>-help visitor-target-<?php echo esc_attr( $key ); ?>-error"><span>ریال</span></div>
                <small id="visitor-target-<?php echo esc_attr( $key ); ?>-help" class="kv-help"><?php echo $key === 'amount' ? 'مبلغ فروش خالص مورد انتظار در این بازه' : 'مبلغ ثابت و جدا از پورسانت محصولات'; ?></small>
                <span class="kv-field-error" id="visitor-target-<?php echo esc_attr( $key ); ?>-error"></span></div>
            <?php } ?>
        </div>
        <div class="kv-form-footer"><p class="kv-help">همه فیلدها الزامی‌اند. بازه‌ها نباید هم‌پوشانی داشته باشند.</p><div class="kv-actions">
            <?php if ( $edit_id ) { ?><a class="btn btn-light page_activator" href="<?php echo esc_url( $targets_url ); ?>" data-url="<?php echo esc_url( $targets_url ); ?>">انصراف</a><?php } else { ?><button type="button" class="btn btn-light kv-close-target">بستن فرم</button><?php } ?>
            <button type="submit" class="btn btn-primary"><?php echo $edit_id ? 'ذخیره تغییرات' : 'ثبت تارگت'; ?></button>
        </div></div>
    </form>
</details>
<?php } ?>
<div class="kv-section-heading"><h5>تارگت‌های جاری و پیش‌رو</h5><span class="kv-pill"><?php echo count( $current_targets ); ?> تارگت</span></div>
<?php if ( ! $current_targets ) { ?>
<div class="kv-empty"><em class="icon ni ni-growth" aria-hidden="true"></em><h6><?php echo $targets ? 'تارگت فعالی وجود ندارد' : 'اولین تارگت این ویزیتور را تعریف کنید'; ?></h6><p>با تعیین هدف فروش و پاداش، میزان پیشرفت در همین بخش نمایش داده می‌شود.</p><?php if ( $can_manage ) { ?><button type="button" class="btn btn-outline-primary kv-open-target">تعریف تارگت</button><?php } ?></div>
<?php } ?>
<?php foreach ( $current_targets as $id => $target ) { echo kph_get_template( 'components/visitor-target-card.php', compact( 'target', 'id', 'user_id', 'can_manage', 'today' ) ); } ?>
<?php if ( $history_targets ) { ?>
<details class="kv-history"><summary>سوابق تارگت‌ها <span class="kv-pill"><?php echo count( $history_targets ); ?> بازه پایان‌یافته</span></summary>
    <?php foreach ( $history_targets as $id => $target ) { echo kph_get_template( 'components/visitor-target-card.php', compact( 'target', 'id', 'user_id', 'can_manage', 'today' ) ); } ?>
</details>
<?php } ?>
<details class="kv-rules"><summary>تارگت و پاداش چگونه محاسبه می‌شوند؟</summary><ul>
    <li>فروش ارسال‌شده پس از کسر تخفیف و برگشت کالا، مبنای پیشرفت است.</li>
    <li>با رسیدن فروش به هدف، پاداش ثابت علاوه بر پورسانت در حساب ویزیتور ثبت می‌شود.</li>
    <li>اگر برگشت کالا فروش را زیر هدف ببرد، پاداش برگشت می‌خورد؛ با تحقق مجدد هدف، دوباره ثبت می‌شود.</li>
    <li>تارگت دارای سابقه پاداش قابل ویرایش نیست. برگشت کالا به بازه ارسال اصلی مربوط می‌شود.</li>
</ul></details>
