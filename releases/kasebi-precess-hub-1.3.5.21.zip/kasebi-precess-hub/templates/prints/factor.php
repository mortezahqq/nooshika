<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * @var array $ids
 * @var int   $user_id
 * @var array $date
 * @var array $request
 */

$DB = new kph_db();

if ( empty( $ids ) ) {
	wp_die( 'شناسه فاکتور مشخص نشده است.' );
}

$orders = [];

foreach ( $ids as $order_id ) {
	$order = $DB->get_order_data( (int) $order_id );
	
	if ( ! empty( $order ) ) {
		$orders[] = $order;
	}
}

if ( empty( $orders ) ) {
	wp_die( 'فاکتوری یافت نشد.' );
}

$logo = get_option( 'kph_print_logo' );

if ( ! $logo ) {
	$logo = get_option( 'kph_panel_logo' );
}

if ( ! $logo ) {
	$logo = KPH_ASSETS_URL . 'image/kasebi_logo.png';
}

$site_title = get_option( 'kph_site_title' ) ?: get_bloginfo( 'name' );

?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>پرینت فاکتور فروش</title>
    <link rel="stylesheet" id="nooshika_fonts_css-css"
          href="/wp-content/plugins/nooshika-main/assets/css/nooshika-fonts.css?ver=5.4.0"
          media="all">
    <style>
        @page {
            size: A4 portrait;
            margin: 10mm;
        }
        
        * {
            box-sizing: border-box;
        }
        
        body {
            direction: rtl;
            margin: 2mm;
            background: #fff;
            color: #111;
            font-size: 12px;
            line-height: 1.8;
        }
        
        .print-page {
            width: 100%;
            min-height: 277mm;
            padding: 0;
            page-break-after: always;
        }
        
        .print-page:last-child {
            page-break-after: auto;
        }
        
        .factor-header {
            display: grid;
            grid-template-columns: 120px 1fr 170px;
            gap: 12px;
            align-items: start;
            margin-bottom: 8px;
        }
        
        .factor-logo img {
            max-width: 100px;
            max-height: 70px;
            object-fit: contain;
        }
        
        .factor-title {
            text-align: center;
            font-size: 17px;
            font-weight: 700;
            padding-top: 8px;
        }
        
        .factor-meta {
            text-align: right;
            font-size: 12px;
            line-height: 2;
        }
        
        .order-note { border: 1px solid #777; border-radius: 6px; padding: 7px 10px; margin: 8px 0 10px; white-space: pre-wrap; }
        .order-note strong { display: block; margin-bottom: 3px; }
        .customer-box {
            border: 1px solid #222;
            border-radius: 7px;
            padding: 10px 10px;
            margin-bottom: 8px;
            font-weight: 700;
            position: relative;
        }
        
        .customer-box .side-label {
            position: absolute;
            left: 0;
            top: 0;
            bottom: 0;
            writing-mode: vertical-rl;
            transform: rotate(180deg);
            border-left: 1px solid #222;
            background: #e7e7e7;
            padding: 5px 3px;
            font-size: 11px;
            border-radius: 0 7px 7px 0;
            text-align: center;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .factor-table th,
        .factor-table td {
            border: 1px solid #222;
            padding: 4px 6px;
            vertical-align: middle;
        }
        
        .factor-table th {
            background: #d9d9d9;
            font-weight: 700;
            text-align: center;
        }
        
        .factor-table td {
            text-align: center;
        }
        
        .factor-table .desc {
            text-align: right;
        }
        
        .summary-row td {
            background: #d9d9d9;
            font-weight: 700;
        }
        
        .summary-table {
            border: 1px solid #222;
            border-top: 0;
        }
        
        .summary-table td {
            padding: 3px 8px;
        }
        
        .summary-table .label {
            width: 150px;
            font-weight: 700;
        }
        
        .summary-table .amount {
            width: 170px;
            text-align: left;
            direction: ltr;
        }
        
        .payable-box {
            display: grid;
            grid-template-columns: 1fr 170px;
            border: 1px solid #222;
            border-top: 0;
            border-radius: 0 0 8px 8px;
            overflow: hidden;
            font-weight: 700;
        }
        
        .payable-text {
            padding: 5px 8px;
            border-left: 1px solid #222;
            font-size: 11px;
        }
        
        .payable-amount {
            padding: 5px 8px;
            text-align: center;
            font-size: 14px;
            direction: ltr;
        }
        
        .signatures {
            display: grid;
            grid-template-columns: 1fr 1fr;
            margin-top: 30px;
            text-align: center;
            font-weight: 700;
        }
        
        .footer-note {
            margin-top: 25px;
            text-align: center;
            font-size: 10px;
            font-weight: 700;
        }
        
        .print-actions {
            position: fixed;
            top: 12px;
            left: 12px;
            z-index: 99;
        }
        
        .print-actions button {
            border: 0;
            background: #111827;
            color: #fff;
            border-radius: 7px;
            padding: 8px 14px;
            cursor: pointer;
            font-family: inherit;
        }
        
        @media print {
            .print-actions {
                display: none;
            }
            
            body {
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
        }
    </style>
</head>
<body>

<div class="print-actions">
    <button onclick="window.print()">پرینت</button>
</div>

<?php foreach ( $orders as $order ) { ?>
	<?php
	$order_id    = (int) $order['id'];
	$customer_id = (int) $order['customer_id'];
	$customer    = kph_print_user_name( $customer_id );
	$items       = $order['items'] ?? [];
	
	$items_subtotal = (float) $order['items_subtotal'];
	$discount       = (float) $order['discount_cash_total'];
	$total_payable  = (float) $order['total_payable'];
	$balance_res    = $customer_id
		? $DB->get_ledger_balance_now( $customer_id, [
			'date_to' => $order['updated_at'],
		] )
		: [ 'balance' => 0 ];
	
	$previous_balance = (float) ( $balance_res['balance'] ?? 0 );
	
	if ( $previous_balance < 0 ) {
		$previous_balance = 0;
	}
	
	$final_payable    = $previous_balance;
	$previous_balance = $previous_balance - $total_payable;
	$factor_number    = $DB->get_order_meta( $order_id, 'factor_number' );
	$shipment_date    = $DB->get_order_meta( $order_id, 'shipment_date' );
	
	$discount_percent = $items_subtotal > 0
		? round( ( $discount / $items_subtotal ) * 100, 2 )
		: 0;
	?>
    <section class="print-page">
        <div class="factor-header">
            <div class="factor-logo">
            </div>

            <div class="factor-title">
                فاکتور فروش
            </div>

            <div class="factor-meta">
                <div>شماره: <?php echo $factor_number; ?></div>
                <div>تاریخ ثبت سفارش: <?php echo esc_html( kph_print_date( $order['created_at'] ) ); ?></div>
                <?php if ( $shipment_date ) : ?><div>تاریخ ارسال سفارش: <?php echo esc_html( $shipment_date ); ?></div><?php endif; ?>
            </div>
        </div>

        <div class="customer-box">
            <span class="side-label">خریدار</span>
            نام: <?php echo esc_html( $customer ); ?>
        </div>

        <?php if ( trim( (string) ( $order['note'] ?? '' ) ) !== '' ) : ?>
        <div class="order-note"><strong>توضیحات سفارش</strong><?php echo esc_html( $order['note'] ); ?></div>
        <?php endif; ?>

        <table class="factor-table">
            <thead>
            <tr>
                <th style="width: 35px;">ردیف</th>
                <th>شرح</th>
                <th style="width: 70px;">تعداد</th>
                <th style="width: 120px;">قیمت واحد</th>
                <th style="width: 130px;">قیمت کل ریال</th>
            </tr>
            </thead>
            <tbody>
			<?php
			$row = 1;
			foreach ( $items as $item ) {
				$qty = (float) $item['qty_ordered'];
				
				if ( $qty <= 0 ) {
					continue;
				}
				
				$line_total    = (float) $item['final_amount'];
				$unit_price    = $qty > 0 ? $line_total / $qty : 0;
				$product_title = get_the_title( (int) $item['wc_product_id'] );
				
				if ( ! $product_title ) {
					$product_title = $item['unique_product_code'];
				}
				?>
                <tr>
                    <td><?php echo esc_html( $row ); ?></td>
                    <td class="desc"><?php echo esc_html( $product_title ); ?></td>
                    <td><?php echo esc_html( kph_db::format_order_quantity( $qty ) ); ?></td>
                    <td><?php echo esc_html( kph_print_money( $unit_price ) ); ?></td>
                    <td><?php echo esc_html( kph_print_money( $line_total ) ); ?></td>
                </tr>
				<?php
				$row ++;
			}
			?>

            <tr class="summary-row">
                <td colspan="2">جمع فاکتور</td>
                <td><?php echo esc_html( kph_db::format_order_quantity( (float) $order['total_ordered_qty'] ) ); ?></td>
                <td></td>
                <td><?php echo esc_html( kph_print_money( $items_subtotal ) ); ?></td>
            </tr>
            </tbody>
        </table>

        <table class="summary-table">
            <tr>
                <td></td>
                <td class="label">تخفیف <?php echo esc_html( $discount_percent ); ?>٪ :</td>
                <td class="amount"><?php echo esc_html( kph_print_money( $discount ) ); ?></td>
            </tr>
            <tr>
                <td></td>
                <td class="label">بدهی قبلی :</td>
                <td class="amount"><?php echo esc_html( kph_print_money( $previous_balance ) ); ?></td>
            </tr>
        </table>

        <div class="payable-box">
            <div class="payable-text">
                مبلغ قابل پرداخت:
				<?php
				if ( function_exists( 'convert_number_to_words' ) ) {
					echo esc_html( convert_number_to_words( $final_payable ) );
				} else {
					echo esc_html( kph_print_money( $final_payable ) . ' ریال' );
				}
				?>
            </div>
            <div class="payable-amount">
				<?php echo esc_html( kph_print_money( $final_payable ) ); ?>
            </div>
        </div>

        <div class="signatures">
            <div>امضا فروشنده</div>
            <div>امضا خریدار</div>
        </div>
    </section>
<?php } ?>
</body>
</html>