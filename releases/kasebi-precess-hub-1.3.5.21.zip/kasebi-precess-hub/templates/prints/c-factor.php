<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * @var array $ids
 * @var int   $user_id
 * @var array $date
 * @var array $request
 */

$DB = new kph_db();

if ( empty( $ids ) ) {
	wp_die( 'شناسه فاکتور مشخص نشده است.' );
}

$orders = [];

foreach ( $ids as $order_id ) {
	$order = $DB->get_order_data( (int) $order_id );
	
	if ( ! empty( $order ) ) {
		$orders[] = $order;
	}
}

if ( empty( $orders ) ) {
	wp_die( 'فاکتوری یافت نشد.' );
}

$logo = get_option( 'kph_print_logo' );

if ( ! $logo ) {
	$logo = get_option( 'kph_panel_logo' );
}

if ( ! $logo ) {
	$logo = KPH_ASSETS_URL . 'image/kasebi_logo.png';
}

$site_title = get_option( 'kph_site_title' ) ?: get_bloginfo( 'name' );

if ( ! function_exists( 'kph_factor_v2_first_option' ) ) {
	function kph_factor_v2_first_option( array $keys, string $default = '' ): string {
		foreach ( $keys as $key ) {
			$value = get_option( $key );
			if ( is_scalar( $value ) && trim( (string) $value ) !== '' ) {
				return trim( (string) $value );
			}
		}
		
		return $default;
	}
}

if ( ! function_exists( 'kph_factor_v2_first_user_meta' ) ) {
	function kph_factor_v2_first_user_meta( int $user_id, array $keys, string $default = '' ): string {
		foreach ( $keys as $key ) {
			$value = get_user_meta( $user_id, $key, TRUE );
			if ( is_scalar( $value ) && trim( (string) $value ) !== '' ) {
				return trim( (string) $value );
			}
		}
		
		return $default;
	}
}

if ( ! function_exists( 'kph_factor_v2_user_phone' ) ) {
	function kph_factor_v2_user_phone( int $user_id ): string {
		$phone = kph_factor_v2_first_user_meta( $user_id, [
			'phone',
			'mobile',
			'billing_phone',
			'purchasing_phone',
			'accountant_phone',
		] );
		
		if ( $phone ) {
			return $phone;
		}
		
		$user = get_userdata( $user_id );
		
		return $user ? (string) $user->user_login : '';
	}
}

if ( ! function_exists( 'kph_factor_v2_state_label' ) ) {
	function kph_factor_v2_state_label( string $state ): string {
		if ( $state === '' ) {
			return '';
		}
		
		if ( function_exists( 'WC' ) && WC() && WC()->countries ) {
			$states = WC()->countries->get_states( 'IR' );
			if ( isset( $states[ $state ] ) ) {
				return (string) $states[ $state ];
			}
		}
		
		return $state;
	}
}

if ( ! function_exists( 'kph_factor_v2_city_label' ) ) {
	function kph_factor_v2_city_label( string $state, string $city ): string {
		if ( $city === '' ) {
			return '';
		}
		
		if ( $state !== '' && function_exists( 'PWS' ) ) {
			try {
				$cities = PWS()::cities( $state );
				if ( is_array( $cities ) && isset( $cities[ $city ] ) ) {
					return is_array( $cities[ $city ] ) ? (string) ( $cities[ $city ]['label'] ?? $city ) : (string) $cities[ $city ];
				}
			}
			catch ( Throwable $e ) {
				// Keep raw city value.
			}
		}
		
		return $city;
	}
}

if ( ! function_exists( 'kph_factor_v2_split_chars' ) ) {
	function kph_factor_v2_split_chars( string $value ): array {
		$value = preg_replace( '/[^0-9۰-۹٠-٩]/u', '', $value );
		if ( ! $value ) {
			return [];
		}
		
		return preg_split( '//u', $value, - 1, PREG_SPLIT_NO_EMPTY ) ?: [];
	}
}

if ( ! function_exists( 'kph_factor_v2_digit_boxes' ) ) {
	function kph_factor_v2_digit_boxes( string $value, int $length = 10 ): string {
		$chars = kph_factor_v2_split_chars( $value );
		$length = max( $length, count( $chars ) ); // Never truncate identifiers or leading zeroes.
		
		ob_start();
		?>
        <span class="digit-boxes" aria-label="<?php echo esc_attr( $value ); ?>">
			<?php for ( $i = 0; $i < $length; $i ++ ) { ?>
                <span><?php echo esc_html( $chars[ $i ] ?? '' ); ?></span>
			<?php } ?>
        </span>
		<?php
		return ob_get_clean();
	}
}

if ( ! function_exists( 'kph_factor_v2_money' ) ) {
	function kph_factor_v2_money( $amount ): string {
		return function_exists( 'kph_print_money' ) ? kph_print_money( $amount ) : number_format( (float) $amount );
	}
}

if ( ! function_exists( 'kph_factor_v2_date' ) ) {
	function kph_factor_v2_date( $date ): string {
		return function_exists( 'kph_print_date' ) ? kph_print_date( $date ) : ( empty( $date ) ? '-' : date_i18n( 'Y/m/d', strtotime( $date ) ) );
	}
}

if ( ! function_exists( 'kph_factor_v2_number_words' ) ) {
	function kph_factor_v2_number_words( $amount ): string {
		if ( function_exists( 'convert_number_to_words' ) ) {
			return convert_number_to_words( (float) $amount ) . ' ریال';
		}
		
		return kph_factor_v2_money( $amount ) . ' ریال';
	}
}

if ( ! function_exists( 'kph_factor_v2_product_title' ) ) {
	function kph_factor_v2_product_title( array $item ): string {
		$title = '';
		if ( ! empty( $item['wc_product_id'] ) ) {
			$title = get_the_title( (int) $item['wc_product_id'] );
		}
		
		return $title ?: (string) ( $item['unique_product_code'] ?? '-' );
	}
}

// Saved defaults can be overridden for this print run without changing customer data.
$print_request = isset( $request ) && is_array( $request ) ? $request : [];
$print_options = [];
foreach ( [ 'sale_type' => 'cash', 'payment_method' => '', 'payment_due' => '', 'notes' => '' ] as $key => $default ) {
	$value = array_key_exists( $key, $print_request ) ? $print_request[ $key ] : get_option( 'kph_factor_' . $key, $default );
	$print_options[ $key ] = is_scalar( $value ) ? sanitize_text_field( wp_unslash( (string) $value ) ) : $default;
}
if ( ! in_array( $print_options['sale_type'], [ 'cash', 'credit' ], TRUE ) ) {
	$print_options['sale_type'] = 'cash';
}

?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>صورتحساب فروش کالا و خدمات</title>
    <link rel="stylesheet" id="nooshika_fonts_css-css"
          href="/wp-content/plugins/nooshika-main/assets/css/nooshika-fonts.css?ver=5.4.0"
          media="all">
    <style>
        @page {
            size: A4 landscape;
            margin: 8mm;
        }
        
        * {
            box-sizing: border-box;
        }
        
        body {
            direction: rtl;
            margin: 0;
            background: #fff;
            color: #111;
            font-size: 9.2px;
            line-height: 1.55;
        }
        
        .print-actions {
            position: fixed;
            top: 10px;
            left: 10px;
            z-index: 99;
        }
        
        .print-actions button {
            border: 0;
            background: #111827;
            color: #fff;
            border-radius: 7px;
            padding: 8px 14px;
            cursor: pointer;
            font-family: inherit;
        }
        
        .factor-page {
            width: 281mm;
            min-height: 194mm;
            margin: 0 auto;
            padding: 2mm 0 0;
            page-break-after: always;
            position: relative;
        }
        
        .factor-page:last-child {
            page-break-after: auto;
        }
        
        .doc-head {
            height: 28mm;
            position: relative;
        }
        
        .doc-title {
            position: absolute;
            top: 10mm;
            left: 70mm;
            right: 70mm;
            text-align: center;
            font-size: 13px;
            font-weight: 700;
        }
        
        .doc-page-number {
            position: absolute;
            top: 18mm;
            left: 0;
            right: 0;
            text-align: center;
            font-size: 8px;
        }
        
        .doc-meta {
            position: absolute;
            top: 4mm;
            left: 7mm;
            width: 48mm;
            font-size: 11px;
            line-height: 2.05;
            font-weight: 700;
        }
        
        .doc-logo {
            position: absolute;
            top: 0;
            right: 35mm;
            width: 22mm;
            height: 20mm;
            text-align: center;
        }
        
        .doc-logo img {
            max-width: 100%;
            max-height: 100%;
            object-fit: contain;
        }
        
        .party-box {
            height: 20.7mm;
            border: 1px solid #111;
            border-radius: 2mm;
            position: relative;
            margin-bottom: 1.2mm;
            overflow: hidden;
        }
        
        .party-label {
            position: absolute;
            top: 0;
            right: 0;
            bottom: 0;
            width: 7.6mm;
            border-left: 1px solid #111;
            writing-mode: vertical-rl;
            transform: rotate(180deg);
            text-align: center;
            font-size: 9px;
            font-weight: 700;
            background: #eee;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .party-content {
            position: absolute;
            top: 0;
            right: 7.6mm;
            left: 0;
            bottom: 0;
            padding: 1.3mm 2mm 1mm 2mm;
        }
        
        .party-grid {
            display: grid;
            grid-template-columns: 86mm 42mm 1fr;
            gap: 3mm;
            height: 100%;
            align-items: center;
        }
        
        .party-fields {
            display: grid;
            gap: .7mm;
        }
        
        .field-line {
            display: flex;
            align-items: center;
            gap: 1.2mm;
            white-space: nowrap;
            justify-content: space-between;
        }
        
        .field-title {
            font-size: 9px;
            color: #222;
        }
        
        .digit-boxes {
            direction: ltr;
            display: inline-flex;
            vertical-align: middle;
        }
        
        .digit-boxes span {
            width: 4.1mm;
            height: 4.5mm;
            border: 1px solid #111;
            border-left: 0;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 10px;
            font-weight: 700;
            line-height: 1;
        }
        
        .digit-boxes span:first-child {
            border-left: 1px solid #111;
        }
        
        .postal-line {
            justify-content: center;
        }
        
        .party-address {
            text-align: right;
            line-height: 1.9;
            font-size: 9px;
        }
        
        .party-name {
            font-weight: 700;
        }
        
        .products-title {
            border: 1px solid #111;
            border-bottom: 0;
            height: 7mm;
            line-height: 7mm;
            text-align: center;
            font-weight: 700;
            border-radius: 1.4mm 1.4mm 0 0;
            position: relative;
        }
        
        .currency-label {
            position: absolute;
            right: 3mm;
            top: 0;
            font-weight: 700;
        }
        
        .factor-table {
            width: 100%;
            border-collapse: collapse;
            table-layout: fixed;
        }
        
        .factor-table th,
        .factor-table td {
            border: 1px solid #111;
            padding: 1.5mm 1mm;
            vertical-align: middle;
            text-align: center;
            height: 8.2mm;
        }
        
        .factor-table th {
            background: #f3f3f3;
            font-weight: 700;
        }
        
        .factor-table .desc {
            text-align: right;
            padding-right: 2mm;
        }
        
        .factor-table .ltr {
            direction: ltr;
            text-align: center;
        }
        
        .total-row td {
            font-weight: 700;
        }
        
        .sale-condition td {
            height: 7.2mm;
            padding: 1mm 1.5mm;
            font-size: 9px;
        }
        
        .checkmark {
            font-size: 13px;
            font-weight: 700;
            padding: 0 1.5mm;
        }
        
        .bottom-grid {
            direction: ltr;
            display: grid;
            grid-template-columns: 80mm 90mm 111mm;
            gap: 0;
        }
        
        .bottom-grid > div {
            direction: rtl;
        }
        
        .summary-box,
        .note-box,
        .signature-box {
            border: 1px solid #111;
            border-top: 0;
            min-height: 26mm;
            overflow: hidden;
        }
        
        .summary-line {
            display: grid;
            grid-template-columns: 34mm 1fr;
            min-height: 6.6mm;
            border-bottom: 1px solid #111;
            align-items: center;
        }
        
        .summary-line:last-child {
            border-bottom: 0;
        }
        
        .summary-line .label {
            padding: 0 2mm;
            border-left: 1px solid #111;
            font-weight: 700;
        }
        
        .summary-line .value {
            padding: 0 2mm;
            text-align: left;
            direction: ltr;
            font-weight: 700;
        }
        
        .summary-words {
            padding: 2mm;
            text-align: center;
            font-size: 9px;
            line-height: 1.8;
        }
        
        .note-title,
        .signature-title {
            padding: 1.5mm 2mm;
            font-weight: 700;
        }
        
        .signature-box {
            display: grid;
            grid-template-columns: 1fr 1fr;
        }
        
        .signature-box > div:first-child {
            border-left: 1px solid #111;
        }
        
        .footer-note {
            text-align: center;
            margin-top: 1mm;
            font-size: 8px;
            font-weight: 700;
        }
        
        .page-bottom-line {
            position: absolute;
            left: 0;
            right: 0;
            bottom: 0;
            border-bottom: 1px solid #111;
        }
        
        @media print {
            .print-actions {
                display: none;
            }
            
            body {
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
        }
        /* Keep account identifiers in their original left-to-right order. */
        .digit-boxes, .postal-code { direction: ltr; unicode-bidi: isolate; }
        .postal-code { font-size: 13px; font-weight: bold; letter-spacing: 1px; }
        .print-actions { position: static; margin: 12px auto; padding: 12px; width: min(100%, 1062px); background: #eef5fb; border: 1px solid #bed0df; border-radius: 8px; }
        .print-actions form { display: flex; flex-wrap: wrap; align-items: end; gap: 10px; }
        .print-actions label { display: grid; gap: 4px; font-size: 12px; }
        .print-actions input, .print-actions select { padding: 6px; max-width: 190px; border: 1px solid #a9bfd3; border-radius: 4px; font: inherit; }
        .print-hint { margin-top: 8px; font-size: 11px; }
        .doc-title { color: #164d77; }
        .party-box { border-color: #386d98; border-radius: 3mm; overflow: hidden; }
        .party-label, .factor-table thead th { background: #225d8b; color: #fff; }
        .factor-table td, .factor-table th { border-color: #7e9eb8; }
        .factor-table tr, .party-box, .bottom-grid { break-inside: avoid; }
        .total-row, .sale-condition, .note-title { background: #eef5fb; }
        .payment-detail { padding: 1mm 2mm; overflow-wrap: anywhere; }
        .note-box { min-height: 34mm; height: auto; }
        @media print { .print-actions { display: none; } }
    </style>
</head>
<body>

<div class="print-actions">
    <form method="get">
        <input type="hidden" name="action" value="print">
        <input type="hidden" name="type" value="c-factor">
        <input type="hidden" name="ids" value="<?php echo esc_attr( implode( ',', array_map( 'absint', $ids ) ) ); ?>">
        <label>شرایط فروش
            <select name="sale_type">
                <option value="cash" <?php selected( $print_options['sale_type'], 'cash' ); ?>>نقدی</option>
                <option value="credit" <?php selected( $print_options['sale_type'], 'credit' ); ?>>غیر نقدی</option>
            </select>
        </label>
        <label>روش پرداخت <input name="payment_method" list="payment-methods" value="<?php echo esc_attr( $print_options['payment_method'] ); ?>"></label>
        <datalist id="payment-methods"><option value="نقدی"><option value="کارتخوان"><option value="حواله بانکی"><option value="چک"></datalist>
        <label>مهلت پرداخت <input name="payment_due" list="payment-terms" placeholder="مثلاً ۴۵ روزه" value="<?php echo esc_attr( $print_options['payment_due'] ); ?>"></label>
        <datalist id="payment-terms"><option value="فوری"><option value="۳۰ روزه"><option value="۴۵ روزه"><option value="۶۰ روزه"><option value="۹۰ روزه"></datalist>
        <label>توضیحات تکمیلی <input name="notes" value="<?php echo esc_attr( $print_options['notes'] ); ?>"></label>
        <button type="submit">اعمال و پیش‌نمایش</button>
        <button type="button" id="print-factor">پرینت</button>
    </form>
    <div class="print-hint">تنظیمات این بخش برای چاپ فعلی است؛ پیش‌فرض‌ها در تنظیمات فاکتور ذخیره می‌شوند.</div>
</div>
<script>
document.getElementById('print-factor').addEventListener('click', function () {
    const form = this.form;
    const dirty = Array.from(form.elements).some(function (field) {
        return field.tagName === 'SELECT'
            ? Array.from(field.options).some(function (option) { return option.selected !== option.defaultSelected; })
            : field.tagName === 'INPUT' && field.value !== field.defaultValue;
    });
    if (dirty) {
        form.requestSubmit();
        return;
    }
    window.print();
});
</script>

<?php foreach ( $orders as $order ) { ?>
	<?php
	$order_id    = (int) $order['id'];
	$customer_id = (int) $order['customer_id'];
	$customer    = function_exists( 'kph_print_user_name' ) ? kph_print_user_name( $customer_id ) : '-';
	$items       = $order['items'] ?? [];
	
	$items_subtotal = (float) ( $order['items_subtotal'] ?? 0 );
	$discount       = (float) ( $order['discount_cash_total'] ?? 0 );
	$total_payable  = (float) ( $order['total_payable'] ?? 0 );
	
	$balance_res = $customer_id
		? $DB->get_ledger_balance_now( $customer_id, [
			'date_to' => $order['updated_at'],
		] )
		: [ 'balance' => 0 ];
	
	$previous_balance = (float) ( $balance_res['balance'] ?? 0 );
	
	if ( $previous_balance < 0 ) {
		$previous_balance = 0;
	}
	
	$final_payable    = $previous_balance;
	$previous_balance = $previous_balance - $total_payable;
	$buyer_state_raw  = kph_factor_v2_first_user_meta( $customer_id, [ 'state_id', 'billing_state' ] );
	$buyer_city_raw   = kph_factor_v2_first_user_meta( $customer_id, [ 'city_id', 'billing_city' ] );
	
	$buyer = [
		'name'        => $customer,
		'person_type' => get_user_meta( $customer_id, 'customer_person_type', TRUE ) === 'legal' ? 'legal' : 'individual',
		'national_id' => kph_factor_v2_first_user_meta( $customer_id, [ 'national_id', 'company_national_id', 'legal_national_id' ] ),
		'economic_code' => kph_factor_v2_first_user_meta( $customer_id, [ 'economic_code' ] ),
		'postal_code' => kph_factor_v2_first_user_meta( $customer_id, [ 'postal_code', 'billing_postcode' ] ),
		'phone'       => kph_factor_v2_user_phone( $customer_id ),
		'fax'         => kph_factor_v2_first_user_meta( $customer_id, [ 'fax', 'billing_fax' ] ),
		'state'       => kph_factor_v2_state_label( $buyer_state_raw ),
		'city'        => kph_factor_v2_city_label( $buyer_state_raw, $buyer_city_raw ),
		'address'     => kph_factor_v2_first_user_meta( $customer_id, [ 'address', 'billing_address_1' ] ),
	];
	
	$total_qty           = 0;
	$total_before        = 0;
	$total_line_discount = 0;
	$total_tax           = 0;
	$total_final         = 0;
	$factor_number       = $DB->get_order_meta( $order_id, 'factor_number' );
	$shipment_date       = $DB->get_order_meta( $order_id, 'shipment_date' );
	?>
    <section class="factor-page">
        <header class="doc-head">
            <div class="doc-meta">
                <div>شماره: <?php echo $factor_number; ?></div>
                <div>تاریخ ثبت سفارش: <?php echo esc_html( kph_factor_v2_date( $order['created_at'] ) ); ?></div>
                <?php if ( $shipment_date ) : ?><div>تاریخ ارسال سفارش: <?php echo esc_html( $shipment_date ); ?></div><?php endif; ?>
            </div>

            <div class="doc-title">صورتحساب فروش کالا و خدمات</div>
            <div class="doc-page-number">فاکتور رسمی</div>
        </header>
		
		<?php
		$seller = [
			'national_id' => get_option( 'kph_factor_store_id', '' ),
			'economic_code' => get_option( 'kph_factor_national_id', '' ),
			'postal_code' => get_option( 'kph_factor_postal_code', '' ),
			'state'       => get_option( 'kph_factor_province', '' ),
			'city'        => get_option( 'kph_factor_city', '' ),
			'address'     => get_option( 'kph_factor_address', '' ),
			'phone'       => get_option( 'kph_factor_phone', '' ),
			'fax'         => get_option( 'kph_factor_fax', '' ),
			
			// چون در تنظیمات قبلی فیلد نام فروشگاه وجود نداشت.
			'name'        => get_option( 'kph_factor_store_name', get_bloginfo( 'name' ) ),
		];
		?>

        <div class="party-box seller-box">
            <div class="party-label">فروشنده</div>

            <div class="party-content">
                <div class="party-grid">
                    <div class="party-fields">
                        <div class="field-line">
                            <span class="field-title">شناسه ملی:</span>
							<?php
							echo kph_factor_v2_digit_boxes(
								(string) $seller['national_id'],
								max( 10, count( kph_factor_v2_split_chars( (string) $seller['national_id'] ) ) )
							);
							?>

                        </div>

                        <div class="field-line">
                            <span class="field-title">کد اقتصادی:</span>
							<?php
							echo kph_factor_v2_digit_boxes(
								(string) $seller['economic_code'],
								12
							);
							?>

                        </div>

                        <div class="field-line">
                            <span class="field-title">نمابر:</span>
                            <span>
						<?php echo esc_html( $seller['fax'] ?: '-' ); ?>
					</span>

                            <span style="margin-right: 18mm;">تلفن:</span>
                            <span>
						<?php echo esc_html( $seller['phone'] ?: '-' ); ?>
					</span>
                        </div>
                    </div>

                    <div class="party-fields">
                        <div class="field-line postal-line">
                            <span class="field-title">کد پستی:</span>
                        </div>
                        <div class="field-line postal-line">
							<?php
							echo kph_factor_v2_digit_boxes(
								(string) $seller['postal_code'],
								10
							);
							?>
                        </div>
                    </div>

                    <div class="party-address">
                        <div class="party-name">
							<?php echo esc_html( $seller['name'] ?: '-' ); ?>
                        </div>

                        <div>
                            استان:
							<?php echo esc_html( $seller['state'] ?: '-' ); ?>

                            &nbsp;&nbsp;

                            شهرستان:
							<?php echo esc_html( $seller['city'] ?: '-' ); ?>
                        </div>

                        <div>
                            نشانی:
							<?php echo esc_html( $seller['address'] ?: '-' ); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="party-box buyer-box">
            <div class="party-label">خریدار</div>
            <div class="party-content">
                <div class="party-grid">
                    <div class="party-fields">
                        <div class="field-line">
                            <span class="field-title">شناسه ملی:</span>
                            <?php echo kph_factor_v2_digit_boxes( $buyer['national_id'], $buyer['person_type'] === 'legal' ? 11 : 10 ); ?>
                        </div>
                        <?php if ( $buyer['person_type'] !== 'legal' ) : ?>
                        <div class="field-line">
                            <span class="field-title">کد اقتصادی:</span>
                            <?php echo kph_factor_v2_digit_boxes( $buyer['economic_code'], 12 ); ?>
                        </div>
                        <?php endif; ?>
                        <div class="field-line">
                            <span class="field-title">تلفن:</span>
                            <bdi dir="ltr"><?php echo esc_html( $buyer['phone'] ?: '-' ); ?></bdi>
                        </div>
                    </div>

                    <div class="party-fields">
                        <div class="field-line postal-line">
							<bdi class="postal-code" dir="ltr"><?php echo esc_html( $buyer['postal_code'] ); ?></bdi>
                        </div>
                        <div class="field-line postal-line">
                            <span class="field-title">کد پستی :</span>
                        </div>
                    </div>

                    <div class="party-address">
                        <div class="party-name"><?php echo esc_html( $buyer['name'] ?: '-' ); ?></div>
                        <div><?php echo $buyer['person_type'] === 'legal' ? 'اشخاص حقوقی' : 'اشخاص حقیقی'; ?></div>
                        <div>
                            استان : <?php echo esc_html( $buyer['state'] ?: '-' ); ?>
                            &nbsp;&nbsp; شهرستان : <?php echo esc_html( $buyer['city'] ?: '-' ); ?>
                        </div>
                        <div>نشانی : <?php echo esc_html( $buyer['address'] ?: '-' ); ?></div>
                    </div>
                </div>
            </div>
        </div>

        <div class="products-title">
            <span class="currency-label">( مبالغ به ریال )</span>
            مشخصات کالا یا خدمات مورد معامله
        </div>

        <table class="factor-table">
            <thead>
            <tr>
                <th style="width:9mm;">ردیف</th>
                <th style="width:22mm;">کد کالا</th>
                <th>شرح کالا یا خدمات</th>
                <th style="width:14mm;">تعداد / مقدار</th>
                <th style="width:14mm;">تعداد ارسال شده کل</th>
                <th style="width:16mm;">واحد اندازه گیری</th>
                <th style="width:24mm;">بهای واحد</th>
                <th style="width:26mm;">بهای کل</th>
                <th style="width:21mm;">تخفیف</th>
                <th style="width:27mm;">مبلغ کل</th>
            </tr>
            </thead>
            <tbody>
			<?php
			$row = 1;
			foreach ( $items as $item ) {
				$qty = (float) ( $item['qty_ordered'] ?? 0 );
				
				if ( $qty <= 0 ) {
					continue;
				}
				
				$line_total          = (float) ( $item['final_amount'] ?? 0 );
				$line_discount       = (float) ( $item['discount_cash_amount'] ?? 0 );
				$line_before         = $line_total + $line_discount;
				$unit_price          = $qty > 0 ? $line_before / $qty : 0;
				$line_tax            = 0;
				$line_final          = $line_total + $line_tax;
				$product_title       = kph_factor_v2_product_title( $item );
				$product_code        = (string) ( $item['unique_product_code'] ?? ( $item['wc_product_id'] ?? '' ) );
				$unit_label          = ! empty( $item['unit'] ) ? (string) $item['unit'] : 'عدد';
				$total_send          = (float) $item['shipped_paid_qty'] + (int) $item['shipped_free_qty'];
				$total_qty           += $qty;
				$total_before        += $line_before;
				$total_line_discount += $line_discount;
				$total_tax           += $line_tax;
				$total_final         += $line_final;
				?>
                <tr>
                    <td><?php echo esc_html( $row ); ?></td>
                    <td><?php echo esc_html( $product_code ?: '-' ); ?></td>
                    <td class="desc"><?php echo esc_html( $product_title ); ?></td>
                    <td><?php echo esc_html( kph_db::format_order_quantity( $qty ) ); ?></td>
                    <td><?php echo esc_html( $total_send ); ?></td>
                    <td><?php echo esc_html( $unit_label ); ?></td>
                    <td class="ltr"><?php echo esc_html( kph_factor_v2_money( $unit_price ) ); ?></td>
                    <td class="ltr"><?php echo esc_html( kph_factor_v2_money( $line_before ) ); ?></td>
                    <td class="ltr"><?php echo esc_html( kph_factor_v2_money( $line_discount ) ); ?></td>
                    <td class="ltr"><?php echo esc_html( kph_factor_v2_money( $line_final ) ); ?></td>
                </tr>
				<?php
				$row ++;
			}
			
			if ( $row === 1 ) {
				?>
                <tr>
                    <td colspan="10">آیتمی برای این فاکتور ثبت نشده است.</td>
                </tr>
				<?php
			}
			?>
            <tr class="total-row">
                <td colspan="3">جمع کل</td>
                <td><?php echo esc_html( kph_db::format_order_quantity( $total_qty ) ); ?></td>
                <td></td>
                <td></td>
                <td></td>
                <td class="ltr"><?php echo esc_html( kph_factor_v2_money( $total_before ?: $items_subtotal ) ); ?></td>
                <td class="ltr"><?php echo esc_html( kph_factor_v2_money( $total_line_discount ?: $discount ) ); ?></td>
                <td class="ltr"><?php echo esc_html( kph_factor_v2_money( $total_final ?: $total_payable ) ); ?></td>
            </tr>
            <tr class="sale-condition">
                <td colspan="3">شرایط و نحوه فروش :</td>
                <td colspan="2"><span class="checkmark"><?php echo $print_options['sale_type'] === 'cash' ? '☑' : '☐'; ?></span> نقدی</td>
                <td colspan="2"><span class="checkmark"><?php echo $print_options['sale_type'] === 'credit' ? '☑' : '☐'; ?></span> غیر نقدی</td>
                <td colspan="2">جمع فاکتور :</td>
                <td class="ltr"><?php echo esc_html( kph_factor_v2_money( $total_payable ) ); ?></td>
            </tr>
            </tbody>
        </table>

        <div class="bottom-grid">
            <div class="summary-box">
                <div class="summary-line">
                    <div class="label">بدهی قبلی :</div>
                    <div class="value"><?php echo esc_html( kph_factor_v2_money( $previous_balance ) ); ?></div>
                </div>
                <div class="summary-line">
                    <div class="label">جمع کل :</div>
                    <div class="value"><?php echo esc_html( kph_factor_v2_money( $final_payable ) ); ?></div>
                </div>
                <div class="summary-words">
                    مبلغ به حروف: <?php echo esc_html( kph_factor_v2_number_words( $final_payable ) ); ?>
                </div>
            </div>

            <div class="note-box">
                <div class="note-title">سایر اطلاعات</div>
                <?php if ( $print_options['payment_method'] !== '' ) : ?>
                <div class="payment-detail">روش پرداخت: <?php echo esc_html( $print_options['payment_method'] ); ?></div>
                <?php endif; ?>
                <?php if ( $print_options['payment_due'] !== '' ) : ?>
                <div class="payment-detail">مهلت پرداخت: <?php echo esc_html( $print_options['payment_due'] ); ?></div>
                <?php endif; ?>
                <div class="payment-detail"><?php echo esc_html( $print_options['notes'] ); ?></div>
                <div class="payment-detail">توضیحات:</div>
                <div style="padding:0 2mm;">
					<?php echo esc_html( $order['note'] ?? '' ); ?>
                </div>
            </div>

            <div class="signature-box">
                <div>
                    <div class="signature-title">مهر و امضای فروشنده</div>
                </div>
                <div>
                    <div class="signature-title">مهر و امضای خریدار</div>
                </div>
            </div>
        </div>

        <div class="footer-note">تبصره: از بخشش یا کسر هر گونه وجه، کسر یا اضافه خودداری شود مگر با هماهنگی واحد
            حسابداری.
        </div>
        <div class="page-bottom-line"></div>
    </section>
<?php } ?>
</body>
</html>
