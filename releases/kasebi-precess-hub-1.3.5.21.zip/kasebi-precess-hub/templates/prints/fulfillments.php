<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$DB       = new kph_db();
$order_id = isset( $_GET['order_id'] ) ? absint( $_GET['order_id'] ) : 0;

if ( ! $order_id ) {
	wp_die( 'شناسه سفارش مشخص نشده است.' );
}

$order = $DB->get_order_data( $order_id );

if ( empty( $order ) ) {
	wp_die( 'سفارش یافت نشد.' );
}

global $wpdb;

$fulfillments_table      = $wpdb->prefix . 'kph_fulfillments';
$fulfillment_items_table = $wpdb->prefix . 'kph_fulfillment_items';
$order_items_table       = $wpdb->prefix . 'kph_order_items';
$ledger_entries_table    = $wpdb->prefix . 'kph_ledger_entries';
$entries                 = $wpdb->get_results(
	$wpdb->prepare(
		"SELECT
			f.id AS fulfillment_id,
			f.status,
			f.shipped_by,
			f.shipped_at,
			f.note,
			f.created_at,
			fi.id AS fulfillment_item_id,
			fi.shipped_paid_qty,
			fi.shipped_free_qty,
			oi.base_price AS unit_price,
			( oi.base_price * fi.shipped_paid_qty ) AS total_price,
			oi.wc_product_id,
			oi.unique_product_code
		FROM {$fulfillments_table} AS f
		INNER JOIN {$fulfillment_items_table} AS fi
			ON fi.fulfillment_id = f.id
		INNER JOIN {$order_items_table} AS oi
			ON oi.id = fi.order_item_id
		WHERE f.order_id = %d
		ORDER BY f.id ASC, fi.id ASC",
		$order_id
	),
	ARRAY_A
);
$statuses                = $DB->get_fulfillment_statuses();
$statuses['canceled']    = [
	'label' => 'لغو شده',
	'class' => 'danger',
];

$logo = get_option( 'kph_print_logo' );

if ( ! $logo ) {
	$logo = get_option( 'kph_panel_logo' );
}

if ( ! $logo ) {
	$logo = KPH_ASSETS_URL . 'image/kasebi_logo.png';
}

if ( ! function_exists( 'kph_fulfillment_print_money' ) ) {
	function kph_fulfillment_print_money( $amount ): string {
		return function_exists( 'kph_print_money' )
			? kph_print_money( $amount )
			: number_format( (float) $amount );
	}
}

if ( ! function_exists( 'kph_fulfillment_print_date' ) ) {
	function kph_fulfillment_print_date( $date, string $format = 'Y/m/d' ): string {
		if ( empty( $date ) ) {
			return '-';
		}
		
		if ( $format === 'Y/m/d' && function_exists( 'kph_print_date' ) ) {
			return kph_print_date( $date );
		}
		
		return date_i18n( $format, strtotime( $date ) );
	}
}

if ( ! function_exists( 'kph_fulfillment_first_user_meta' ) ) {
	function kph_fulfillment_first_user_meta( int $user_id, array $keys, string $default = '' ): string {
		foreach ( $keys as $key ) {
			$value = get_user_meta( $user_id, $key, TRUE );
			
			if ( is_scalar( $value ) && trim( (string) $value ) !== '' ) {
				return trim( (string) $value );
			}
		}
		
		return $default;
	}
}

if ( ! function_exists( 'kph_fulfillment_user_phone' ) ) {
	function kph_fulfillment_user_phone( int $user_id ): string {
		$phone = kph_fulfillment_first_user_meta(
			$user_id,
			[
				'phone',
				'mobile',
				'billing_phone',
				'purchasing_phone',
				'accountant_phone',
			]
		);
		
		if ( $phone ) {
			return $phone;
		}
		
		$user = get_userdata( $user_id );
		
		return $user ? (string) $user->user_login : '';
	}
}

if ( ! function_exists( 'kph_fulfillment_product_title' ) ) {
	function kph_fulfillment_product_title( array $entry ): string {
		$title = '';
		
		if ( ! empty( $entry['wc_product_id'] ) ) {
			$title = get_the_title( (int) $entry['wc_product_id'] );
		}
		
		return $title ?: (string) ( $entry['unique_product_code'] ?? '-' );
	}
}

if ( ! function_exists( 'kph_fulfillment_user_name' ) ) {
	function kph_fulfillment_user_name( int $user_id ): string {
		if ( ! $user_id ) {
			return '-';
		}
		
		if ( function_exists( 'kph_print_user_name' ) ) {
			return (string) kph_print_user_name( $user_id );
		}
		
		$user = get_userdata( $user_id );
		
		return $user ? $user->display_name : '-';
	}
}

$customer_id = (int) ( $order['customer_id'] ?? 0 );
$customer    = $customer_id ? kph_fulfillment_user_name( $customer_id ) : '-';
$phone       = $customer_id ? kph_fulfillment_user_phone( $customer_id ) : '';
$address     = $customer_id ? kph_fulfillment_first_user_meta(
	$customer_id,
	[
		'address',
		'billing_address_1',
	]
) : '';

$factor_number    = $DB->get_order_meta( $order_id, 'factor_number' );
$order_date       = $order['created_at'] ?? '';
$previous_balance = 0;

if ( $customer_id > 0 ) {
	/*
	 * آخرین سند دفتر کل که بابت یکی از ارسال‌های همین سفارش ثبت شده است.
	 * created_at مبنای ترتیب واقعی عملیات است؛ posted_at ممکن است فقط تاریخ
	 * سند را داشته باشد و ساعت آن 00:00:00 ذخیره شده باشد.
	 */
	$last_fulfillment_ledger = $wpdb->get_row(
		$wpdb->prepare(
			"SELECT
				l.id AS ledger_id,
				l.created_at AS ledger_created_at
			 FROM {$ledger_entries_table} AS l
			 INNER JOIN {$fulfillments_table} AS f
				ON f.id = l.ref_id
			 WHERE l.user_id = %d
			   AND l.ref_type = 'fulfillment'
			   AND f.order_id = %d
			 ORDER BY l.created_at ASC , l.id ASC
			 LIMIT 1",
			$customer_id,
			$order_id
		),
		ARRAY_A
	);
	
	if ( $last_fulfillment_ledger ) {
		$ledger_id         = (int) $last_fulfillment_ledger['ledger_id'];
		$ledger_created_at = (string) $last_fulfillment_ledger['ledger_created_at'];
		
		$previous_balance = (float) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COALESCE(
					SUM(
						CASE
							WHEN l.type = 'debit' THEN l.amount
							ELSE -l.amount
						END
					),
					0
				)
				 FROM {$ledger_entries_table} AS l
				 WHERE l.user_id = %d
				   AND (
					l.created_at < %s
					OR (
						l.created_at = %s
						AND l.id < %d
					)
				   )",
				$customer_id,
				$ledger_created_at,
				$ledger_created_at,
				$ledger_id
			)
		);
	}
}

$previous_balance   = max( 0, $previous_balance );
$total_paid         = 0;
$total_free         = 0;
$total_price        = 0;
$fulfillment_groups = [];

foreach ( $entries as $entry ) {
	$fulfillment_id = (int) $entry['fulfillment_id'];
	
	if ( ! isset( $fulfillment_groups[ $fulfillment_id ] ) ) {
		$fulfillment_groups[ $fulfillment_id ] = [
			'status'     => (string) $entry['status'],
			'shipped_by' => (int) $entry['shipped_by'],
			'shipped_at' => $entry['shipped_at'],
			'note'       => (string) $entry['note'],
			'created_at' => $entry['created_at'],
			'items'      => [],
		];
	}
	
	$fulfillment_groups[ $fulfillment_id ]['items'][] = $entry;
	
	$total_paid  += (float) $entry['shipped_paid_qty'];
	$total_free  += (int) $entry['shipped_free_qty'];
	$total_price += (float) $entry['total_price'];
}
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>گزارش ارسال سفارش #<?php echo esc_html( $order_id ); ?></title>
    <link rel="stylesheet"
          id="nooshika_fonts_css-css"
          href="/wp-content/plugins/nooshika-main/assets/css/nooshika-fonts.css?ver=5.4.0"
          media="all">
    <style>
        @page {
            size: A4 landscape;
            margin: 8mm;
        }
        
        * {
            box-sizing: border-box;
        }
        
        body {
            direction: rtl;
            margin: 0;
            background: #fff;
            color: #111;
            font-size: 9.2px;
            line-height: 1.55;
        }
        
        .print-actions {
            position: fixed;
            top: 10px;
            left: 10px;
            z-index: 99;
        }
        
        .print-actions button {
            border: 0;
            background: #111827;
            color: #fff;
            border-radius: 7px;
            padding: 8px 14px;
            cursor: pointer;
            font-family: inherit;
        }
        
        .fulfillment-page {
            width: 281mm;
            min-height: 194mm;
            margin: 0 auto;
            padding: 2mm 0 0;
            position: relative;
        }
        
        .doc-head {
            height: 28mm;
            position: relative;
        }
        
        .doc-title {
            position: absolute;
            top: 8mm;
            left: 70mm;
            right: 70mm;
            text-align: center;
            font-size: 14px;
            font-weight: 700;
        }
        
        .doc-subtitle {
            position: absolute;
            top: 17mm;
            left: 70mm;
            right: 70mm;
            text-align: center;
            font-size: 8px;
            color: #555;
        }
        
        .doc-meta {
            position: absolute;
            top: 3mm;
            left: 7mm;
            width: 55mm;
            font-size: 10px;
            line-height: 2;
            font-weight: 700;
        }
        
        .doc-logo {
            position: absolute;
            top: 0;
            right: 7mm;
            width: 30mm;
            height: 22mm;
            text-align: center;
        }
        
        .doc-logo img {
            max-width: 100%;
            max-height: 100%;
            object-fit: contain;
        }
        
        .info-box {
            border: 1px solid #111;
            border-radius: 2mm;
            margin-bottom: 1.2mm;
            overflow: hidden;
        }
        
        .info-title {
            height: 7mm;
            line-height: 7mm;
            padding: 0 2mm;
            background: #eee;
            border-bottom: 1px solid #111;
            font-weight: 700;
        }
        
        .info-grid {
            display: grid;
            grid-template-columns: 1fr 1fr 1fr 2fr;
        }
        
        .info-item {
            min-height: 13mm;
            padding: 2mm;
            border-left: 1px solid #111;
        }
        
        .info-item:last-child {
            border-left: 0;
        }
        
        .info-label {
            display: block;
            margin-bottom: .8mm;
            font-size: 8px;
            color: #555;
        }
        
        .info-value {
            font-weight: 700;
        }
        
        .section-title {
            position: relative;
            height: 7mm;
            line-height: 7mm;
            margin-top: 2mm;
            border: 1px solid #111;
            border-bottom: 0;
            border-radius: 1.4mm 1.4mm 0 0;
            text-align: center;
            font-weight: 700;
            background: #f8f8f8;
        }
        
        .section-meta {
            position: absolute;
            right: 3mm;
            top: 0;
            font-size: 8px;
            font-weight: 400;
        }
        
        .fulfillment-table {
            width: 100%;
            border-collapse: collapse;
            table-layout: fixed;
        }
        
        .fulfillment-table th,
        .fulfillment-table td {
            border: 1px solid #111;
            padding: 1.5mm 1mm;
            vertical-align: middle;
            text-align: center;
            height: 8.2mm;
        }
        
        .fulfillment-table th {
            background: #f3f3f3;
            font-weight: 700;
        }
        
        .fulfillment-table .desc {
            text-align: right;
            padding-right: 2mm;
        }
        
        .fulfillment-table .ltr {
            direction: ltr;
            text-align: center;
        }
        
        .fulfillment-table .note {
            text-align: right;
            white-space: normal;
            line-height: 1.7;
        }
        
        .group-row td {
            background: #ececec;
            font-weight: 700;
            text-align: right;
            padding: 1.8mm 2mm;
        }
        
        .group-row .group-meta {
            display: flex;
            align-items: center;
            gap: 6mm;
            flex-wrap: wrap;
        }
        
        .status {
            display: inline-block;
            padding: .5mm 2mm;
            border: 1px solid #777;
            border-radius: 20mm;
            font-size: 8px;
            background: #fff;
        }
        
        .total-row td {
            background: #f3f3f3;
            font-weight: 700;
        }
        
        .summary-grid {
            display: flex;
            flex-direction: column;
            border: 1px solid #111;
            border-top: 0;
        }
        
        .summary-item {
            width: 100%;
            min-height: 9mm;
            padding: 2mm;
            border-left: 0;
            border-bottom: 1px solid #111;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 3mm;
        }
        
        .summary-item:last-child {
            border-bottom: 0;
        }
        
        .summary-item.summary-total {
            background: #e8e8e8;
            font-size: 10px;
        }
        
        .summary-label,
        .summary-value {
            font-weight: 700;
        }
        
        .summary-value {
            direction: ltr;
        }
        
        .empty-box {
            border: 1px solid #111;
            padding: 12mm 3mm;
            text-align: center;
            font-size: 11px;
        }
        
        .signature-box {
            display: grid;
            grid-template-columns: 1fr 1fr 1fr;
            min-height: 28mm;
            margin-top: 2mm;
            border: 1px solid #111;
        }
        
        .signature-item {
            padding: 2mm;
            border-left: 1px solid #111;
            text-align: center;
        }
        
        .signature-item:last-child {
            border-left: 0;
        }
        
        .signature-title {
            font-weight: 700;
        }
        
        .footer-note {
            margin-top: 2mm;
            text-align: center;
            font-size: 8px;
            color: #555;
        }
        
        @media print {
            .print-actions {
                display: none;
            }
            
            body {
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
            
            .fulfillment-section {
                break-inside: avoid;
            }
            
            thead {
                display: table-header-group;
            }
        }
    </style>
</head>
<body>

<div class="print-actions">
    <button type="button" onclick="window.print()">پرینت</button>
</div>

<section class="fulfillment-page">
    <header class="doc-head">
        <div class="doc-logo">
            <img src="<?php echo esc_url( $logo ); ?>" alt="">
        </div>

        <div class="doc-meta">
            <div>شماره سفارش: <?php echo esc_html( $order_id ); ?></div>
			
			<?php if ( $factor_number ) { ?>
                <div>شماره فاکتور: <?php echo esc_html( $factor_number ); ?></div>
			<?php } ?>

            <div>تاریخ سفارش: <?php echo esc_html( kph_fulfillment_print_date( $order_date ) ); ?></div>
        </div>

        <div class="doc-title">گزارش ارسال کالا</div>
        <div class="doc-subtitle">جزئیات ارسال‌های ثبت‌شده برای سفارش</div>
    </header>

    <div class="info-box">
        <div class="info-title">مشخصات سفارش و خریدار</div>

        <div class="info-grid">
            <div class="info-item">
                <span class="info-label">نام خریدار</span>
                <span class="info-value"><?php echo esc_html( $customer ?: '-' ); ?></span>
            </div>

            <div class="info-item">
                <span class="info-label">شماره تماس</span>
                <span class="info-value"><?php echo esc_html( $phone ?: '-' ); ?></span>
            </div>

            <div class="info-item">
                <span class="info-label">تعداد ارسال‌ها</span>
                <span
                    class="info-value"><?php echo esc_html( number_format_i18n( count( $fulfillment_groups ) ) ); ?></span>
            </div>

            <div class="info-item">
                <span class="info-label">نشانی</span>
                <span class="info-value"><?php echo esc_html( $address ?: '-' ); ?></span>
            </div>
        </div>
    </div>
	
	<?php if ( empty( $fulfillment_groups ) ) { ?>
        <div class="empty-box">
            هنوز ارسالی برای این سفارش ثبت نشده است.
        </div>
	<?php } else { ?>
		<?php
		$row = 1;
		
		foreach ( $fulfillment_groups as $fulfillment_id => $fulfillment ) {
			$status = $statuses[ $fulfillment['status'] ] ?? [
					'label' => $fulfillment['status'],
					'class' => 'light',
				];
			
			$shipped_by_name  = kph_fulfillment_user_name( (int) $fulfillment['shipped_by'] );
			$fulfillment_date = $fulfillment['shipped_at'] ?: $fulfillment['created_at'];
			?>
            <div class="fulfillment-section">
                <div class="section-title">
                    ارسال شماره <?php echo esc_html( $fulfillment_id ); ?>

                    <span class="section-meta">
						ثبت:
						<?php echo esc_html( kph_fulfillment_print_date( $fulfillment_date, 'Y/m/d H:i' ) ); ?>
					</span>
                </div>

                <table class="fulfillment-table">
                    <thead>
                    <tr>
                        <th style="width:9mm;">ردیف</th>
                        <th>شرح کالا</th>
                        <th style="width:19mm;">تعداد</th>
                        <th style="width:19mm;">هدیه</th>
                        <th style="width:28mm;">بهای واحد</th>
                        <th style="width:30mm;">بهای کل</th>
                    </tr>
                    </thead>

                    <tbody>
					<?php
					foreach ( $fulfillment['items'] as $entry ) {
						$product_title = kph_fulfillment_product_title( $entry );
						?>
                        <tr>
                            <td><?php echo esc_html( $row ); ?></td>
                            <td class="desc"><?php echo esc_html( $product_title ); ?></td>
                            <td><?php echo esc_html( kph_db::format_order_quantity( (float) $entry['shipped_paid_qty'] ) ); ?></td>
                            <td><?php echo esc_html( number_format_i18n( (int) $entry['shipped_free_qty'] ) ); ?></td>
                            <td class="ltr">
								<?php echo esc_html(
									kph_fulfillment_print_money( $entry['unit_price'] )
								); ?>
                            </td>

                            <td class="ltr">
								<?php echo esc_html(
									kph_fulfillment_print_money( $entry['total_price'] )
								); ?>
                            </td>
                        </tr>
						<?php
						$row ++;
					}
					?>
                    </tbody>
                </table>
            </div>
		<?php } ?>
		<?php $account_total = $total_price + $previous_balance; ?>

        <div class="summary-grid">
            <div class="summary-item">
                <span class="summary-label">جمع مبلغ ارسالی‌ها:</span>

                <span class="summary-value">
			<?php echo esc_html(
				kph_fulfillment_print_money( $total_price )
			); ?>
		</span>
            </div>

            <div class="summary-item">
                <span class="summary-label">مانده قبل این سفارش:</span>

                <span class="summary-value">
			<?php echo esc_html(
				kph_fulfillment_print_money( $previous_balance )
			); ?>
		</span>
            </div>

            <div class="summary-item summary-total">
                <span class="summary-label">جمع کل حساب:</span>

                <span class="summary-value">
			<?php echo esc_html(
				kph_fulfillment_print_money( $account_total )
			); ?>
		</span>
            </div>
        </div>
	<?php } ?>

    <div class="signature-box">
        <div class="signature-item">
            <div class="signature-title">تحویل‌دهنده</div>
        </div>

        <div class="signature-item">
            <div class="signature-title">تحویل‌گیرنده</div>
        </div>

        <div class="signature-item">
            <div class="signature-title">مهر و امضاء</div>
        </div>
    </div>

    <div class="footer-note">
        این برگه بر اساس ارسال‌های ثبت‌شده برای سفارش شماره
		<?php echo esc_html( $order_id ); ?>
        تهیه شده است.
    </div>
</section>

</body>
</html>
