<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
$category_role_map = [
	1 => 'saff',
	2 => 'zereshk',
	3 => 'tea',
	4 => 'hell',
	5 => 'nabat',
	7 => 'vanil',
];
$role              = nooshika_get_user_role( get_current_user_id() );

$DB              = new kph_db();
$supplier_groups = $DB->get_raw_categories();
$supplier_groups = $supplier_groups['items'];
$excluded_supply_categories=$DB->supply_category_ids();
$supplier_groups=array_values(array_filter($supplier_groups,static fn($g)=>!in_array((int)$g['id'],$excluded_supply_categories,true)));

if ( in_array( $role, $category_role_map, TRUE ) ) {
	$supplier_groups = array_values(
		array_filter(
			$supplier_groups,
			static function( array $group ) use ( $category_role_map, $role ): bool {
				$category_id = (int) ( $group['id'] ?? 0 );
				
				return isset( $category_role_map[ $category_id ] )
				       && $category_role_map[ $category_id ] === $role;
			}
		)
	);
}
$default_category = $supplier_groups[0] ?? FALSE;
$per_page_key     = basename( __FILE__, '.php' );
$per_page_key     = "kph_{$per_page_key}_per_page";
$user_id          = get_current_user_id();
$defaults         = [
	'category_id' => $default_category ? $default_category['id'] : '',
	'show_all'    => 'stock',
	'page_number' => 1,
	'per_page'    => get_user_meta( $user_id, $per_page_key, TRUE ) ?: 20,
	'date'        => [
		'from' => '',
		'to'   => '',
	],
];
$args             = wp_parse_args( $_REQUEST, $defaults );
$args             = array_map( fn( $v ) => $v == 0 ? '' : $v, $args );
$has_filter       = kph_page_has_filter( $args, $defaults );
extract( $args );
update_user_meta( $user_id, $per_page_key, $per_page );

$valid_categories=array_map('intval',array_column($supplier_groups,'id'));
if(!in_array((int)$category_id,$valid_categories,true))$category_id=$default_category['id']??0;
$date_from = $date['from'] ?? '';
$date_to   = $date['to'] ?? '';

$batches     = $DB->get_batches_list( [
	'page'           => $page_number,
	'per_page'       => $per_page,
	'category_id'    => $category_id,
	'only_available' => $show_all == 'stock',
    'exclude_supplies' => true,
	'date_from'      => $date_from ? nooshika_jalali_to_gregorian( $date_from ) : NULL,
	'date_to'        => $date_to ? nooshika_jalali_to_gregorian( $date_to ) : NULL,
] );
$summery     = $batches['summary'];
$total_page  = $batches['pagination']['total_page'];
$total_items = $batches['pagination']['total'];
$batches     = $batches['items'];
try{$warehouse_distribution=$DB->get_warehouse_distribution('raw',array_column($batches,'id'));}catch(Throwable $e){$warehouse_distribution=null;}

$selected_category = $DB->get_raw_category( $category_id );
?>
<?php if (kph_plugin_management_allowed() && $DB->supplies_is_category((int)$category_id)) { ?>
<div class="alert alert-info"><a class="page_activator" href="<?php echo esc_url(home_url('/crm/produce-supplies')); ?>">مدیریت موجودی، افزودن قلم و کسر خودکار ملزومات بسته‌بندی</a></div>
<?php } ?>
<div class="nk-block-head nk-block-head-sm">
    <div class="nk-block-between">
        <div class="nk-block-head-content">
            <h3 class="nk-block-title page-title">مخزن محصولات</h3>
        </div>
        <div class="nk-block-head-content">
            <div class="drodown">
                <a href="#" class="dropdown-toggle btn btn-outline-info btn-dim"
                   data-bs-toggle="dropdown" aria-expanded="true">
                    <span><?php echo $selected_category['item']['title']; ?></span>
                    <em class="icon ni ni-chevron-down"></em>
                </a>
                <div class="dropdown-menu dropdown-menu-end " data-popper-placement="bottom-start">
                    <ul class="link-list-opt no-bdr">
						<?php
						foreach ( $supplier_groups as $data ) {
							?>
                            <li>
                                <a class="page_activator"
                                   href="<?php echo home_url( "/crm/produce-repository?category_id={$data['id']}" ); ?>"
                                   data-url="<?php echo "/crm/produce-repository?category_id={$data['id']}"; ?>">
                                    <span><?php echo $data['title']; ?></span>
                                </a>
                            </li>
							<?php
						}
						?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="nk-block">
    <div class="card card-stretch">
        <div class="card-inner-group">
            <div class="card-inner position-relative card-tools-toggle">
                <div class="card-title-group">
                    <div class="card-tools">
                    </div>
                    <div class="card-tools">
                        <ul class="btn-toolbar gx-1">
                            <li>
								<?php
								$filter_fields = [
									[
										'type'    => 'radio',
										'label'   => 'نمایش محصولات',
										'name'    => 'show_all',
										'value'   => $show_all,
										'options' => [
											'stock' => 'فقط محصولات موجود در مخزن رو نشون بده.',
											'all'   => 'همه محصولات رو نشون بده.',
										],
									],
									[
										'type'  => 'date-range',
										'label' => 'تاریخ گزارش',
										'name'  => 'date',
										'value' => [
											'from' => $date_from ?? '',
											'to'   => $date_to ?? '',
										],
									],
								];
								echo kph_get_template( 'components/filter-dropdown.php', [
									'has_filter'    => $has_filter,
									'filter_fields' => $filter_fields,
								] );
								?>
                            </li>
                            <li class="btn-toolbar-sep"></li>
                            <li>
								<?php
								echo kph_get_template( 'components/per-page-selector.php', [
									'per_page' => $per_page,
								] );
								?>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="card-inner p-0">
                <div class="nk-tb-list nk-tb-ulist is-compact">
                    <div class="nk-tb-item nk-tb-head">
                        <div class="nk-tb-col"><span class="sub-text">محصول</span></div>
                        <div class="nk-tb-col"><span class="sub-text">مقدار مانده در مخزن</span></div>
                        <div class="nk-tb-col"><span class="sub-text">ارزش موجودی</span></div>
                        <div class="nk-tb-col"><span class="sub-text">قیمت واحد</span></div>
                        <div class="nk-tb-col text-end nk-tb-col-tools"></div>
                    </div>
					<?php
					if ( empty( $batches ) ) {
						echo '<div class="no-item-found">آیتمی یافت نشد</div>';
					} else {
						foreach ( $batches as $entry ) {
							$product       = $DB->get_raw_product( $entry['raw_product_id'] );
							$invoice_no    = $DB->get_meta( 'batch', $entry['id'], 'invoice_no', TRUE );
							$base_price    = $DB->get_invoice_item_meta( $entry['source_id'], 'per_unit_base', TRUE );
							$month         = $DB->get_invoice_item_meta( $entry['source_id'], 'month', TRUE );
							$rate          = $DB->get_invoice_item_meta( $entry['source_id'], 'rate', TRUE );
							$total_amount  = $entry['unit_cost'] * $entry['initial_qty_weight'];
							$net_weight    = $entry['initial_qty_weight'] - $entry['total_waste'];
							$new_unit_cost = $total_amount / $net_weight;
							?>
                            <div class="nk-tb-item">
                                <div class="nk-tb-col">
                                    <div class="user-card">
                                        <div class="user-info">
                                            <span class="tb-lead"><?php echo $product['item']['title']; ?></span>
                                            <span class="sub-text"><?php echo $invoice_no; ?></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="nk-tb-col">
									<?php echo number_format( (float) $entry['current_stock'], 4, '.', '' ); echo ($product['item']['base_uom'] ?? 'kg') === 'count' ? ' عدد' : ' کیلوگرم'; ?>
                                    <?php echo kph_get_template('components/warehouse-distribution.php',['allocations'=>$warehouse_distribution===null?null:($warehouse_distribution[(int)$entry['id']]??[]),'total'=>$entry['current_stock'],'unit'=>($product['item']['base_uom']??'kg')==='count'?'عدد':'کیلوگرم']); ?>
                                </div>
                                <div class="nk-tb-col">
                                    <span><?php echo number_format( $new_unit_cost * $entry['current_stock'] ); ?></span>
                                </div>
                                <div class="nk-tb-col">
                                    <span><?php echo number_format( $new_unit_cost ); ?></span>
                                </div>
                                <div class="nk-tb-col nk-tb-col-tools">
                                    <ul class="nk-tb-actions gx-2">
										<?php
										$rate    = ( $month > 0 ) ? number_format( $base_price * $rate * $month / 100 ) : 'نقدی';
										$actions = [
											[
												'link'  => '',
												'title' => 'مبلغ کل: ' . number_format( $total_amount ),
												'icon'  => 'ni-sign-dollar',
											],
											[
												'link'  => '',
												'title' => 'وزن اولیه: ' . number_format( (float) $entry['initial_qty_weight'], 4, '.', '' ),
												'icon'  => 'ni-opt-alt',
											],
											[
												'link'  => '',
												'title' => 'کارمزد: ' . $rate,
												'icon'  => 'ni-percent',
											],
										];
										if ( $entry['total_waste'] > 0 ) {
											$actions[] = [
												'link'  => '',
												'title' => 'وزن دررو: ' . number_format( (float)
													$entry['total_waste'], 4, '.', '' ) * 1000 . ' گرم',
												'icon'  => 'ni-trash-alt',
											];
										}
										echo kph_get_template( 'components/row-actions-hidden.php', [
											'actions' => $actions,
										] );
										?>
                                        <li>
											<?php
											$actions = [
												[
													'title'       => 'ثبت وزن دررو',
													'icon'        => 'ni-trash-alt',
													'class'       => 'row_inline_action',
													'category_id' => $category_id,
													'data'        => [
														'action'     => 'kph_submit_wasted_batch',
														'item-id'    => $entry['id'],
														'swal-title' => 'ثبت هدررفت',
														'needs'      => json_encode( [
															[
																'type'  => 'text',
																'label' => 'وزن هدر رفت را به گرم وارد کنید.',
																'key'   => 'wasted_weight',
															],
														] ),
													],
												],
												'divider' => [
													'divider' => TRUE,
												],
												[
													'link'  => '',
													'title' => 'گزارشات گردش انبار',
													'class' => 'load_item_data_to_modal',
													'icon'  => 'ni-repeat-v',
													'data'  => [
														'item-id' => $entry['id'],
														'action'  => 'kph_load_batch_storage_move',
														'modal'   => '#batchStorageMoveTable',
													],
												],
											];
											echo kph_get_template( 'components/row-actions-dropdown.php', [
												'actions' => $actions,
											] );
											?>
                                        </li>
                                    </ul>
                                </div>
                            </div>
							<?php
						}
					}
					?>
                </div>
            </div>
            <div class="card-inner">
				<?php
				echo kph_get_template( 'components/pagination.php', [
					'max_page_num' => $total_page,
					'current_page' => $page_number,
					'class_name'   => 'user_pagination_link',
					'show_count'   => 2,
				] );
				?>
            </div>
        </div>
    </div>
</div>
<div class="nk-block-head nk-block-head-sm">
    <div class="nk-block-between">
        <div class="nk-block-head-content">
            <h3 class="nk-block-title page-title">موجودی کل:</h3>
        </div>
    </div>
</div>
<div class="nk-block">
    <div class="row g-gs">
		<?php
		foreach ( $summery as $product_id => $data ) {
			$product = $DB->get_raw_product( $product_id );
			?>
            <div class="col-md-4">
                <div class="card card-full">
                    <div class="card-inner">
                        <div class="card-title-group align-center mb-1">
                            <div class="card-title">
                                <h6 class="title"><?php echo $product['item']['title']; ?></h6>
                            </div>
                            <div class="card-amount">
                                <div class="card-tools me-1">
                                    <em class="card-hint icon ni ni-help-fill" data-bs-toggle="tooltip"
                                        data-bs-placement="right" title="وزن کل باقی مانده"></em>
                                </div>
                                <div class="amount">
									<?php echo number_format( (float) $data['total_remaining'], 4, '.', '' ); ?>
                                    <small class="currency currency-usd fs-12px">کیلوگرم</small>
                                </div>
                            </div>
                        </div>
                        <div class="invest-data">
                            <div class="invest-data-amount g-2">
                                <div class="invest-data-history">
                                    <div class="title">کل ورودی</div>
                                    <div class="amount">
										<?php echo number_format( (float) $data['total_received'], 4, '.', '' ); ?>
                                        <small class="currency currency-usd fs-12px">کیلوگرم</small>
                                    </div>
                                </div>
                                <div class="invest-data-history">
                                    <div class="title">کل فرآوری شده</div>
                                    <div class="amount text-success">
										<?php echo number_format( (float) $data['total_processing_out'], 4, '.', '' ); ?>
                                        <small class="currency currency-usd fs-12px">کیلوگرم</small>
                                    </div>
                                </div>
                                <div class="invest-data-history">
                                    <div class="title">کل دررو</div>
                                    <div class="amount text-danger">
										<?php echo number_format( (float) $data['total_wasted'], 4, '.', '' ); ?>
                                        <small class="currency currency-usd fs-12px">کیلوگرم</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
			<?php
		}
		?>
    </div>
</div>

