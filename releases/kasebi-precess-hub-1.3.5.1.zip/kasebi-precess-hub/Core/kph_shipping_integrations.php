<?php
if(!defined('ABSPATH')){exit;}

/** These methods run under the shipment settings/record locks and the caller's transaction. */
trait kph_shipping_integrations {
    private function integration_tables():array{
        $base=$this->d->prefix.'kph_';return [$base.'accounts',$base.'account_meta',$base.'account_transactions',$base.'account_transaction_meta',$base.'ledger_entries',$base.'ledger_entry_meta',$base.'actions',$base.'action_meta',$this->p.'settings',$this->p.'records',$this->p.'audit',$this->p.'files',$this->p.'freight'];
    }
    private function install_integrations():void{
        $c='ENGINE=InnoDB '.$this->d->get_charset_collate();
        foreach([
            "CREATE TABLE IF NOT EXISTS {$this->p}files(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,record_id BIGINT UNSIGNED NOT NULL UNIQUE,filename VARCHAR(190) NOT NULL,mime VARCHAR(40) NOT NULL,contents LONGBLOB NOT NULL,checksum CHAR(64) NOT NULL,created_by BIGINT UNSIGNED NOT NULL,created_at DATETIME NOT NULL,updated_at DATETIME NOT NULL) $c",
            "CREATE TABLE IF NOT EXISTS {$this->p}freight(record_id BIGINT UNSIGNED PRIMARY KEY,customer_id BIGINT UNSIGNED NOT NULL,order_id BIGINT UNSIGNED NOT NULL,invoice_number VARCHAR(190) NOT NULL DEFAULT '',amount BIGINT UNSIGNED NOT NULL,posted_on DATE NOT NULL,ledger_id BIGINT UNSIGNED NOT NULL DEFAULT 0,expense_id BIGINT UNSIGNED NOT NULL DEFAULT 0,account_id BIGINT UNSIGNED NOT NULL DEFAULT 0,updated_at DATETIME NOT NULL) $c"
        ] as $sql){$this->ok($this->d->query($sql));}
        foreach(['records'=>['finance_enabled'=>'TINYINT UNSIGNED NOT NULL DEFAULT 0','action_id'=>'BIGINT UNSIGNED NOT NULL DEFAULT 0','request_fingerprint'=>'CHAR(64) NULL'],'settings'=>['cost_key'=>"VARCHAR(191) NOT NULL DEFAULT ''"]] as $table=>$columns){
            foreach($columns as $name=>$definition){$column=$this->d->get_row($this->d->prepare("SHOW COLUMNS FROM {$this->p}{$table} LIKE %s",$name),ARRAY_A);if(!$column){$this->ok($this->d->query("ALTER TABLE {$this->p}{$table} ADD COLUMN {$name} {$definition}"));}}
        }
        foreach($this->integration_tables() as $table){$row=$this->d->get_row($this->d->prepare('SHOW TABLE STATUS LIKE %s',$this->d->esc_like($table)),ARRAY_A);if(!$row){throw new RuntimeException('جدول موردنیاز ثبت یکپارچه ارسال یافت نشد.');}if(strcasecmp($row['Engine'],'InnoDB')){$this->ok($this->d->query("ALTER TABLE `{$table}` ENGINE=InnoDB"));}}
        $this->configure_freight_category();
    }
    private function integration_ready():void{
        foreach($this->integration_tables() as $table){$row=$this->d->get_row($this->d->prepare('SHOW TABLE STATUS LIKE %s',$this->d->esc_like($table)),ARRAY_A);if(!$row||strcasecmp($row['Engine'],'InnoDB')){throw new RuntimeException('آماده‌سازی ثبت یکپارچه ارسال کامل نیست؛ صفحه را با حساب مدیر تازه کنید.');}}
    }
    private static function category_name(string $name):string{return preg_replace('/[\s\x{200c}\x{200e}\x{200f}_-]+/u','',strtr(mb_strtolower($name),['ي'=>'ی','ك'=>'ک']));}
    private function configure_freight_category():void{
        $categories=get_option('kph_cost_category',[]);$categories=is_array($categories)?$categories:[];$key='';
        $wanted=array_map([self::class,'category_name'],['کرایه مشتری','کرایه مشتریان','هزینه کرایه مشتریان','customerfreightcharges','customer_freight']);
        foreach($categories as $candidate=>$value){if(in_array(self::category_name((string)$candidate),$wanted,TRUE)||in_array(self::category_name((string)($value['label']??'')),$wanted,TRUE)){$key=(string)$candidate;break;}}
        if($key===''){
            $key='customer_freight';$item=['label'=>'کرایه مشتریان'];$secondary=get_option('kph_cost_secondary_category',[]);
            foreach(is_array($secondary)?$secondary:[] as $candidate=>$value){if(in_array(self::category_name((string)($value['label']??'')),['هزینههایتولید','هزینهتولید'],TRUE)){$item['secondary_category']=(string)$candidate;break;}}
            $categories[$key]=$item;update_option('kph_cost_category',$categories,FALSE);
            $stored=get_option('kph_cost_category',[]);if(!isset($stored[$key])){throw new RuntimeException('ثبت دسته کرایه مشتریان انجام نشد.');}
        }
        $this->ok($this->d->update($this->p.'settings',['cost_key'=>$key],['id'=>1]));
    }
    public function freight_info(int $id):?array{
        $this->guard();$row=$this->d->get_row($this->d->prepare("SELECT * FROM {$this->p}freight WHERE record_id=%d",$id),ARRAY_A);if($this->d->last_error){throw new RuntimeException('خواندن ثبت کرایه انجام نشد.');}return $row;
    }
    public function waybill_info(int $id):?array{
        $this->guard();$row=$this->d->get_row($this->d->prepare("SELECT id,record_id,filename,mime,checksum,OCTET_LENGTH(contents) AS bytes FROM {$this->p}files WHERE record_id=%d",$id),ARRAY_A);if($this->d->last_error){throw new RuntimeException('خواندن بارنامه انجام نشد.');}return $row;
    }
    private function validated_waybill(array $file):array{
        if(($file['error']??1)!==UPLOAD_ERR_OK||!is_uploaded_file($file['tmp_name']??'')){throw new RuntimeException('بارنامه بارگذاری نشد؛ فایل و محدودیت حجم سرور را بررسی کنید.');}
        $limit=min(5*1024*1024,function_exists('wp_max_upload_size')?(int)wp_max_upload_size():5*1024*1024);$size=filesize($file['tmp_name']);
        if(!$size||$size>$limit){throw new RuntimeException('بارنامه باید حداکثر ۵ مگابایت و کمتر از سقف سرور باشد.');}
        $bytes=file_get_contents($file['tmp_name']);if($bytes===FALSE||strlen($bytes)!==$size){throw new RuntimeException('خواندن فایل بارنامه انجام نشد.');}
        if(!class_exists('finfo')){throw new RuntimeException('امکان شناسایی نوع فایل روی سرور فعال نیست.');}
        $filename=mb_substr(sanitize_file_name($file['name']??'waybill'),0,190);$ext=strtolower(pathinfo($filename,PATHINFO_EXTENSION));$mime=(new finfo(FILEINFO_MIME_TYPE))->buffer($bytes);$valid=$ext==='pdf'&&$mime==='application/pdf'&&str_starts_with($bytes,'%PDF-');
        if(in_array($ext,['jpg','jpeg','png'],TRUE)&&in_array($mime,['image/jpeg','image/png'],TRUE)){$image=@getimagesizefromstring($bytes);$valid=$image&&(($ext==='png'&&$mime==='image/png')||($ext!=='png'&&$mime==='image/jpeg'));}
        if(!$valid){throw new RuntimeException('فقط بارنامه معتبر PDF، JPG یا PNG پذیرفته می‌شود.');}
        return ['filename'=>$filename,'mime'=>$mime,'contents'=>$bytes,'checksum'=>hash('sha256',$bytes)];
    }
    public function waybill_file(int $id):array{
        $this->guard();$line=$this->line();$row=$this->d->get_row($this->d->prepare("SELECT f.* FROM {$this->p}files f INNER JOIN {$this->p}records r ON r.id=f.record_id WHERE f.id=%d AND r.line=%s",$id,$line),ARRAY_A);if(!$row||$this->d->last_error){throw new RuntimeException('فایل بارنامه یافت نشد.');}return $row;
    }
    private function put_meta(string $table,string $fk,int $id,array $values):void{
        $table=$this->d->prefix.'kph_'.$table;
        foreach($values as $key=>$value){$this->ok($this->d->delete($table,[$fk=>$id,'meta_key'=>$key]));$this->ok($this->d->insert($table,[$fk=>$id,'meta_key'=>$key,'meta_value'=>maybe_serialize($value)]));}
    }
    private function sync_waybill(array $record,?array $upload):int{
        $id=(int)$record['id'];$file=$this->waybill_info($id);$now=current_time('mysql');
        if($upload){
            if($file){if(!hash_equals($file['checksum'],$upload['checksum'])){$this->ok($this->d->update($this->p.'files',$upload+['updated_at'=>$now],['id'=>$file['id']]));$this->audit($id,'replace_waybill',$file,array_diff_key($upload,['contents'=>1]));}}
            else{$this->ok($this->d->insert($this->p.'files',$upload+['record_id'=>$id,'created_by'=>get_current_user_id(),'created_at'=>$now,'updated_at'=>$now]));$this->audit($id,'upload_waybill',[],array_diff_key($upload,['contents'=>1]));}
            $file=$this->waybill_info($id);
        }
        if(!$file){return 0;}
        $data=json_decode($record['data'],TRUE)?:[];$number=$data['invoice_number']??'';$canceled=$record['status']==='canceled';
        $action=['user_id'=>(int)$record['customer_id'],'title'=>($canceled?'ابطال ارسال — ':'').'بارنامه فاکتور '.($number!==''?'#'.$number:'بدون شماره').' — ارسال #'.$id,'content'=>'بارنامه: '.($data['waybill_no']?:'بدون شماره').' | مقصد: '.$data['destination'].' | شرکت حمل: '.self::carriers()[$data['carrier']].' | تاریخ ارسال: '.kph_hr_calendar::display($record['shipped_on']),'date'=>$record['shipped_on'].' 00:00:00','creator'=>get_current_user_id()];
        $action['content']=esc_html($action['content']).' <a href="'.esc_url(kph_shipping_file_url((int)$file['id'])).'" target="_blank" rel="noopener">دریافت بارنامه: '.esc_html($file['filename']).'</a>';
        $actionId=(int)($record['action_id']??0);$base=$this->d->prefix.'kph_';
        if($actionId){$existing=$this->d->get_row($this->d->prepare("SELECT id,creator FROM {$base}actions WHERE id=%d FOR UPDATE",$actionId),ARRAY_A);if($this->d->last_error){throw new RuntimeException('خواندن ارتباطات مشتری انجام نشد.');}if(!$existing){$actionId=0;}else{$action['creator']=$existing['creator'];}}
        if($actionId){$this->ok($this->d->update($base.'actions',$action,['id'=>$actionId]));}else{$this->ok($this->d->insert($base.'actions',$action));$actionId=(int)$this->d->insert_id;}
        $this->put_meta('action_meta','action_id',$actionId,['attachment'=>kph_shipping_file_url((int)$file['id']),'type'=>'shipping_waybill','shipping_record_id'=>$id,'order_id'=>$record['order_id'],'invoice_number'=>$number]);
        return $actionId;
    }
    private function expense_account():array{
        $base=$this->d->prefix.'kph_';$account=$this->d->get_row("SELECT a.* FROM {$base}accounts a INNER JOIN {$base}account_meta m ON m.account_id=a.id AND m.meta_key='system_key' AND m.meta_value='shipping_customer_freight' WHERE a.type='expense' LIMIT 1 FOR UPDATE",ARRAY_A);
        if($this->d->last_error){throw new RuntimeException('خواندن حساب هزینه کرایه انجام نشد.');}
        if(!$account){
            $account=$this->d->get_row($this->d->prepare("SELECT * FROM {$base}accounts WHERE type='expense' AND title=%s LIMIT 1 FOR UPDATE",'کرایه مشتریان'),ARRAY_A);
            if($this->d->last_error){throw new RuntimeException('خواندن حساب هزینه کرایه انجام نشد.');}
            if(!$account){$this->ok($this->d->insert($base.'accounts',['title'=>'کرایه مشتریان','type'=>'expense','balance'=>0,'status'=>'active','created_by'=>get_current_user_id(),'created_at'=>current_time('mysql')]));$account=['id'=>(int)$this->d->insert_id,'balance'=>0];}
            $this->put_meta('account_meta','account_id',(int)$account['id'],['system_key'=>'shipping_customer_freight']);
        }
        return $account;
    }
    private function freight_ledger(array $record,int $customer,int $amount,bool $reverse):int{
        $data=json_decode($record['data'],TRUE)?:[];$result=$this->ledger->add_ledger_entry(['user_id'=>$customer,'entry_type'=>$reverse?'shipping_freight_reversal':'shipping_freight','type'=>$reverse?'debit':'credit','amount'=>$amount,'ref_type'=>'shipping_control','ref_id'=>(int)$record['id'],'posted_at'=>$reverse?current_time('mysql'):$record['shipped_on'].' 00:00:00','note'=>($reverse?'برگشت ':'').'کرایه پرداخت‌شده توسط شرکت — فاکتور #'.($data['invoice_number']??'').' — ارسال #'.$record['id'],'meta'=>['creator_id'=>get_current_user_id(),'shipping_record_id'=>$record['id'],'order_id'=>$record['order_id'],'invoice_number'=>$data['invoice_number']??'']]);
        if(($result['status']??'')!=='success'){throw new RuntimeException('ثبت کرایه در حساب مشتری انجام نشد.');}return (int)($result['data']['id']??$result['data']['entry_id']??0);
    }
    private function sync_freight(array $record):void{
        $id=(int)$record['id'];$base=$this->d->prefix.'kph_';$old=$this->freight_info($id);$amount=$record['status']==='active'&&$record['payer']==='company'&&!empty($record['finance_enabled'])?(int)($record['freight_cost']??0):0;
        if(!$old&&$amount===0){return;}
        if($old&&(int)$old['amount']===$amount&&($amount===0||((int)$old['customer_id']===(int)$record['customer_id']&&$old['posted_on']===$record['shipped_on']&&(int)$old['order_id']===(int)$record['order_id']&&$old['invoice_number']===(json_decode($record['data'],TRUE)['invoice_number']??'')))){return;}
        $now=current_time('mysql');$data=json_decode($record['data'],TRUE)?:[];
        if($old&&(int)$old['amount']>0){
            $expense=$this->d->get_row($this->d->prepare("SELECT * FROM {$base}account_transactions WHERE id=%d AND action='shipping_freight' FOR UPDATE",$old['expense_id']),ARRAY_A);
            $credit=$this->d->get_row($this->d->prepare("SELECT * FROM {$base}ledger_entries WHERE id=%d AND ref_type='shipping_control' AND ref_id=%d AND entry_type='shipping_freight' AND type='credit'",$old['ledger_id'],$id),ARRAY_A);
            $accountRow=$this->d->get_row($this->d->prepare("SELECT id,type,balance FROM {$base}accounts WHERE id=%d FOR UPDATE",$old['account_id']),ARRAY_A);
            if(!$accountRow||$accountRow['type']!=='expense'||!$expense||!$credit||(int)$expense['account_id']!==(int)$old['account_id']||(int)$credit['user_id']!==(int)$old['customer_id']||(int)$expense['amount']!==(int)$old['amount']||(int)$credit['amount']!==(int)$old['amount']){throw new RuntimeException('ثبت مالی مرتبط تغییر کرده است؛ مدیر آن را بررسی کند.');}
            $reversedRecord=$record;$oldData=$data;$oldData['invoice_number']=$old['invoice_number'];$reversedRecord['data']=$this->encode($oldData);$reversedRecord['order_id']=$old['order_id'];
            $reversal=$this->freight_ledger($reversedRecord,(int)$old['customer_id'],(int)$old['amount'],TRUE);
            $restoredBalance=(int)$accountRow['balance']+(int)$old['amount'];
            $this->ok($this->d->insert($base.'account_transactions',['account_id'=>$old['account_id'],'amount'=>$old['amount'],'type'=>'credit','action'=>'shipping_freight_reversal','balance_after'=>$restoredBalance,'description'=>'برگشت هزینه کرایه — فاکتور #'.$old['invoice_number'].' — ارسال #'.$id,'created_by'=>get_current_user_id(),'created_at'=>$now]));$reversalTransaction=(int)$this->d->insert_id;
            // Reversal is a movement of the expense account, not a new categorized expense.
            $this->put_meta('account_transaction_meta','transaction_id',$reversalTransaction,['source'=>'shipping_control','shipping_record_id'=>$id,'reversed_expense_id'=>$old['expense_id'],'customer_id'=>$old['customer_id'],'order_id'=>$old['order_id'],'invoice_number'=>$old['invoice_number']]);
            $this->put_meta('account_transaction_meta','transaction_id',(int)$old['expense_id'],['shipping_voided'=>1,'reversal_ledger_id'=>$reversal,'reversal_transaction_id'=>$reversalTransaction]);
            $this->ok($this->d->update($base.'accounts',['balance'=>$restoredBalance,'updated_at'=>$now],['id'=>$old['account_id']]));
        }
        $next=['customer_id'=>(int)$record['customer_id'],'order_id'=>(int)$record['order_id'],'invoice_number'=>$data['invoice_number']??'','amount'=>$amount,'posted_on'=>$record['shipped_on'],'ledger_id'=>0,'expense_id'=>0,'account_id'=>0,'updated_at'=>$now];
        if($amount>0){
            $account=$this->expense_account();$balance=(int)$account['balance']-$amount;$settings=$this->locked_setting();$costKey=$settings['cost_key']??'';$categories=get_option('kph_cost_category',[]);
            if($costKey===''||!isset($categories[$costKey])){throw new RuntimeException('دسته کرایه مشتریان تغییر کرده است؛ مدیر تنظیمات هزینه را بررسی کند.');}
            $next['ledger_id']=$this->freight_ledger($record,(int)$record['customer_id'],$amount,FALSE);$next['account_id']=(int)$account['id'];
            $this->ok($this->d->insert($base.'account_transactions',['account_id'=>$next['account_id'],'amount'=>$amount,'type'=>'debit','action'=>'shipping_freight','balance_after'=>$balance,'description'=>'کرایه مشتری: '.$data['customer_name'].' — فاکتور #'.($data['invoice_number']??'').' — ارسال #'.$id,'created_by'=>get_current_user_id(),'created_at'=>$record['shipped_on'].' 00:00:00']));$next['expense_id']=(int)$this->d->insert_id;
            $this->put_meta('account_transaction_meta','transaction_id',$next['expense_id'],['cost_type'=>$costKey,'destination'=>$data['customer_name'],'source'=>'shipping_control','shipping_record_id'=>$id,'customer_id'=>$record['customer_id'],'order_id'=>$record['order_id'],'invoice_number'=>$data['invoice_number']??'']);
            $this->ok($this->d->update($base.'accounts',['balance'=>$balance,'updated_at'=>$now],['id'=>$next['account_id']]));
        }
        if($old){$this->ok($this->d->update($this->p.'freight',$next,['record_id'=>$id]));}else{$this->ok($this->d->insert($this->p.'freight',['record_id'=>$id]+$next));}
        $this->audit($id,'freight',$old??[],$next);
    }
}
