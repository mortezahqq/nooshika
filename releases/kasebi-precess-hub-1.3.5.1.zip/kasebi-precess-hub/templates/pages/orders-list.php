<?php
$per_page_key = basename( __FILE__, '.php' );
$per_page_key = "kph_{$per_page_key}_per_page";
$user_id      = get_current_user_id();
$defaults     = [
	'status'      => 'proforma',
	'page_number' => 1,
	'per_page'    => get_user_meta( $user_id, $per_page_key, TRUE ) ?: 20,
	'date'        => [
		'from' => '',
		'to'   => '',
	],
];
$args         = wp_parse_args( $_REQUEST, $defaults );
$args         = array_map( fn( $v ) => $v == 0 ? '' : $v, $args );
$has_filter   = kph_page_has_filter( $args, $defaults );
extract( $args );
update_user_meta( $user_id, $per_page_key, $per_page );

$date_from = $date['from'] ?? '';
$date_to   = $date['to'] ?? '';

$DB       = new kph_db();
$statuses = $DB->get_order_statuses();
$entries  = $DB->get_orders_list( [
	'page'      => $page_number,
	'per_page'  => $per_page,
	'status'    => $status,
	'date_from' => $date_from ? nooshika_jalali_to_gregorian( $date_from ) : NULL,
	'date_to'   => $date_to ? nooshika_jalali_to_gregorian( $date_to ) : NULL,
] );

$total_items = $entries['pagination']['total'];
$total_page = $entries['pagination']['total_page'];
$entries    = $entries['items'];
$show_preparation = $status === 'proforma' && kph_preparation_print_allowed();
$show_shipment_date = $status === 'shipped';
$shipment_dates = $show_shipment_date ? $DB->get_order_last_shipment_dates( array_column( $entries, 'id' ) ) : [];
?>
<div class="nk-block-head nk-block-head-sm">
    <div class="nk-block-between">
        <div class="nk-block-head-content">
            <h3 class="nk-block-title page-title">لیست سفارشات مشتریان</h3>
            <div class="nk-block-des text-soft">
                <p class="mb-0">شما در مجموع <?php echo $total_items; ?> سفارش دارید.</p>
            </div>
        </div>
        <div class="nk-block-head-content">
            <div class="toggle-wrap nk-block-tools-toggle">
                <div class="toggle-expand-content">
                    <ul class="nk-block-tools g-3">
						<?php
						foreach ( $statuses as $slug => $data ) {
							$class = 'btn-' . $data['class'];
							if ( $slug != $status ) {
								$class .= ' btn-dim';
							}
							?>
                            <li>
                                <div data-url="/crm/orders-list?status=<?php echo $slug; ?>"
                                     class="page_activator btn <?php echo $class; ?>"><?php echo $data['label']; ?></div>
                            </li>
							<?php
						}
						?>
                        <li class="nk-block-tools-opt">
                            <a href="<?php echo home_url( '/crm/order-customer/' ); ?>" target="_blank"
                               class=" btn btn-icon btn-primary"><em class="icon ni ni-plus"></em></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<?php if ( $show_preparation ) { echo kph_get_template( 'components/preparation-print-controls.php' ); } ?>
<div class="nk-block">
    <div class="card card-stretch">
        <div class="card-inner-group">
            <div class="card-inner position-relative card-tools-toggle">
                <div class="card-title-group">
                    <div class="card-tools">
                    </div>
                    <div class="card-tools">
                        <ul class="btn-toolbar gx-1">
                            <li>
								<?php
								$filter_fields = [
									[
										'type'  => 'date-range',
										'label' => 'تاریخ ثبت فاکتور',
										'name'  => 'date',
										'value' => [
											'from' => $date_from ?? '',
											'to'   => $date_to ?? '',
										],
									],
									[
										'type'  => 'hidden',
										'name'  => 'status',
										'value' => $status,
									],
								];
								echo kph_get_template( 'components/filter-dropdown.php', [
									'has_filter'    => $has_filter,
									'filter_fields' => $filter_fields,
								] );
								?>
                            </li>
                            <li class="btn-toolbar-sep"></li>
                            <li>
								<?php
								echo kph_get_template( 'components/per-page-selector.php', [
									'per_page' => $per_page,
								] );
								?>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="card-inner p-0">
                <div class="nk-tb-list nk-tb-ulist is-compact">
                    <div class="nk-tb-item nk-tb-head">
                        <?php if ( $show_preparation ) { ?><div class="nk-tb-col nk-tb-col-check"><span class="sub-text">انتخاب</span></div><?php } ?>
                        <div class="nk-tb-col"><span class="sub-text">تاریخ ثبت</span></div>
                        <?php if ( $show_shipment_date ) { ?><div class="nk-tb-col"><span class="sub-text">تاریخ آخرین ارسال</span></div><?php } ?>
                        <div class="nk-tb-col"><span class="sub-text">مشتری</span></div>
                        <div class="nk-tb-col"><span class="sub-text">جمع کل</span></div>
                        <div class="nk-tb-col"><span class="sub-text">تعداد محصولات</span></div>
                        <div class="nk-tb-col"><span class="sub-text">وضعیت</span></div>
                        <div class="nk-tb-col"><span class="sub-text">برکت ناخالص</span></div>
                        <div class="nk-tb-col text-end nk-tb-col-tools"></div>
                    </div>
					<?php
					if ( empty( $entries ) ) {
						echo '<div class="no-item-found">فاکتوری یافت نشد</div>';
					} else {
						foreach ( $entries as $entry ) {
							$date         = date_i18n( 'Y/m/d', strtotime( $entry['created_at'] ) );
							$amount       = number_format( $entry['total_payable'] );
							$note         = $entry['note'];
							$created_by   = $entry['created_by'];
							$order_status = $statuses[ $entry['display_status'] ?? $entry['status'] ] ?? [ 'label' => 'نامشخص', 'class' => 'secondary' ];
							$attachment   = $DB->get_order_meta( $entry['id'], 'attachment' );
							$address_id   = $DB->get_order_meta( $entry['id'], 'address_id' );
							$factor_date  = $DB->get_order_meta( $entry['id'], 'factor_date' );
							$user_id      = $entry['customer_id'];
							$report       = $DB->get_order_profit_report( $entry['id'] );
							?>
                            <div class="nk-tb-item">
                                <?php if ( $show_preparation && $entry['status'] === 'proforma' ) { ?><div class="nk-tb-col nk-tb-col-check"><?php echo kph_get_template( 'components/preparation-print-select.php', [ 'order_id' => (int) $entry['id'] ] ); ?></div><?php } ?>
                                <div class="nk-tb-col">
                                    <span><?php echo $date; ?></span>
                                </div>
                                <?php if ( $show_shipment_date ) { ?>
                                <div class="nk-tb-col"><span><?php echo esc_html( ! empty( $shipment_dates[$entry['id']] ) ? date_i18n( 'Y/m/d', strtotime( $shipment_dates[$entry['id']] ) ) : 'ثبت نشده' ); ?></span></div>
                                <?php } ?>
                                <div class="nk-tb-col">
									<?php
									echo kph_get_template( 'components/user-card.php', [
										'user_id'    => $user_id,
										'show_phone' => TRUE,
									] );
									?>
                                </div>
                                <div class="nk-tb-col">
                                    <div class="amount">
                                        <span><?php echo $amount; ?></span>
                                    </div>
                                </div>
                                <div class="nk-tb-col">
                                    <strong class="fs-14px"><?php echo $entry['total_ordered_qty']; ?> عدد کالا</strong>
									<?php
									if ( $entry['total_expected_free_qty'] ) {
										?><span class="sub-text">
                                        +<?php echo $entry['total_expected_free_qty']; ?> هدیه</span><?php
									}
									?>
                                </div>
                                <div class="nk-tb-col">
                                    <span class="badge bg-<?php echo $order_status['class']; ?>">
                                        <?php echo $order_status['label']; ?></span>
                                </div>
                                <div class="nk-tb-col">
                                    <span><?php echo number_format( $report['total_sales_amount'] -
                                                                    $report['total_cogs'] ); ?></span>
                                </div>
                                <div class="nk-tb-col nk-tb-col-tools">
                                    <ul class="nk-tb-actions gx-2">

										
										<?php
										echo kph_get_template( 'components/row-actions-hidden.php', [
											'actions' => [
												'print' => [
													'link' => add_query_arg( [
														'action' => 'print',
														'type'   => 'factor',
														'ids'    => (int) $entry['id'],
													], home_url( '/crm/' ) ),
													'title'  => 'پرینت فاکتور',
													'icon'   => 'ni-printer',
													'target' => '_blank',
												],
												'date'       => [
													'link'  => "",
													'title' => 'تاریخ فاکتور: ' . $factor_date,
													'icon'  => 'ni-calendar-alt',
												],
												'created_by' => [
													'link'  => "",
													'title' => 'ثبت کننده: ' . get_user_name_by_id( $created_by ),
													'icon'  => 'ni-user-check',
												],
												[
													'link'  => '',
													'title' => 'آیتم های سفارش',
													'class' => 'load_item_data_to_modal',
													'icon'  => 'ni-package',
													'data'  => [
														'item-id' => $entry['id'],
														'action'  => 'kph_load_order_items',
														'modal'   => '#invoiceItemsTable',
													],
												],
												[
													'link'  => '',
													'title' => 'ارسال های سفارش',
													'class' => 'load_item_data_to_modal',
													'icon'  => 'ni-send',
													'data'  => [
														'item-id' => $entry['id'],
														'action'  => 'kph_load_order_fulfillment',
														'modal'   => '#invoiceFulfillmentTable',
													],
												],
												[
													'link'  => '/crm/user/' . $user_id,
													'title' => 'مشخصات مشتری',
													'icon'  => 'ni-eye',
													'class' => 'page_activator',
												],
												[
													'link'  => '/crm/user/' . $user_id . '?tab=financial',
													'title' => 'تاریخچه حسابداری',
													'icon'  => 'ni-coin-alt',
													'class' => 'page_activator',
												],
											],
										] );
										if ( $note ) {
											?>
                                            <li class="nk-tb-action">
                                                <div class="btn btn-sm btn-icon btn-trigger"
                                                     data-bs-toggle="popover"
                                                     data-bs-trigger="hover"
                                                     data-bs-html="true"
                                                     title="یادداشت"
                                                     data-bs-content="<?php echo wpautop( $note ); ?>"
                                                     data-bs-placement="top">
                                                    <em class="icon ni ni-note-add-c"></em>
                                                </div>
                                            </li>
											<?php
										}
										if ( $attachment ) {
											$attachment = explode( ',', $attachment );
											?>
                                            <li class="nk-tb-action">
												<?php
												$actions = [];
												foreach ( $attachment as $url ) {
													$file_data = $DB->get_uploaded_file_data( $url );
													if ( ! $file_data ) {
														$file_name = $url;
													} else {
														$file_name = $file_data['original_name'];
													}
													$actions[] = [
														'link'     => $url,
														'title'    => $file_name,
														'icon'     => 'ni-download',
														'target'   => '_blank',
														'download' => TRUE,
													];
												}
												echo kph_get_template( 'components/row-actions-dropdown.php', [
													'actions'   => $actions,
													'main_icon' => 'file-docs',
													'title'     => 'فایل ضمیمه',
												] );
												?>
                                            </li>
											<?php
										}
										if ( $entry['status'] == 'proforma' ) {
											?>
                                            <li>
												<?php
												$actions = [
													'edit'     => [
														'link'   => home_url() . "/crm/order-customer-edit?order-id={$entry['id']}",
														'icon'   => 'ni-edit',
														'title'  => 'ویرایش فاکتور',
														'target' => '_blank',
													],
													'delete'   => [
														'title' => 'حذف پیش‌فاکتور',
														'icon'  => 'ni-trash-alt',
														'class' => 'row_inline_action text-danger',
														'data'  => [
															'action'     => 'kph_delete_customer_proforma',
															'item-id'    => (int) $entry['id'],
															'swal-title' => 'حذف پیش‌فاکتور',
															'needs'      => wp_json_encode( [] ),
															'nonce'      => wp_create_nonce(
																'kph_delete_customer_proforma_' . (int) $entry['id']
															),
														],
													],
													'register' => [
														'link'  => '',
														'title' => 'تایید فاکتور',
														'icon'  => 'ni-check-round-cut',
														'class' => 'change_order_status',
														'data'  => [
															'order-id' => $entry['id'],
															'status'   => 'registered',
															'user-id'  => $user_id,
														],
													],
												];
												echo kph_get_template( 'components/row-actions-dropdown.php', [
													'actions' => $actions,
												] );
												?>
                                            </li>
											<?php
										}
										?>

                                    </ul>
                                </div>
                            </div>
							<?php
						}
					}
					?>
                </div>
            </div>
            <div class="card-inner">
				<?php
				echo kph_get_template( 'components/pagination.php', [
					'max_page_num' => $total_page,
					'current_page' => $page_number,
					'class_name'   => 'user_pagination_link',
					'show_count'   => 2,
				] );
				?>
            </div>
        </div>
    </div>
</div>
