<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
$DB              = new kph_db();
$intros          = $DB->get_introduce_methods();
$all_roles       = [
	'accountant' => 'حسابدار',
	'supp'       => 'پشتیبانی',
	'saff'       => 'سالندار زعفران',
	'tea'        => 'سالندار چای',
	'hell'       => 'سالندار هل',
	'nabat'      => 'سالندار نبات',
	'zereshk'    => 'سالندار زرشک',
	'vanil'      => 'سالندار وانیل',
];
$categories      = $DB->get_raw_categories();
$payment_methods = $DB->get_payment_methods();
$user_metas      = $DB->get_user_meta_list();
$cost_type       = get_option( 'kph_cost_category', [] );
$can_account = !kph_support_accounting_restricted();
$accounts = $can_account ? $DB->get_accounts( [
	'page'     => 1,
	'per_page' => 100,
] ) : ['items'=>[]];
$accounts = $accounts['items'] ?? [];
?>
<div class="nk-footer">
    <div class="container-xl wide-xl">
        <div class="nk-footer-wrap">
            <div class="nk-footer-copyright">طراحی و توسعه توسط <a href="https://kasebi.co/" target="_blank">کاسبی</a>
            </div>
            <div class="nk-footer-links english_number">
                Copyright 2017-<?php echo date( "Y" ); ?>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="addSupplier">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">افزودن تامین‌کننده</h5>
                <a href="#" class="close" data-bs-dismiss="modal" aria-label="بستن">
                    <em class="icon ni ni-cross-sm"></em>
                </a>
            </div>
            <div class="modal-body modal-body-md">
                <form action="#" class="modal_form" data-action="kph_add_supplier_user"
                      data-page="/crm/supplier">
                    <div class="row g-gs">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="supplier_firstname">نام</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="supplier_firstname"
                                           data-for="first_name" data-req="1"
                                           placeholder="به عنوان مثال، احمد">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="supplier_lastname">نام خانوادگی</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="supplier_lastname"
                                           data-for="last_name" data-req="1"
                                           placeholder="به عنوان مثال، گلچین">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="supplier_phone">شماره تماس</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="supplier_phone"
                                           data-for="phone" data-req="1">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="supplier_national_code">کد ملی</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="supplier_national_code"
                                           data-for="national_code" data-req="1">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="supplier_birthday">تاریخ تولد</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control datepicker" id="supplier_birthday"
                                           data-for="birthday" data-req="1">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="supplier_group">گروه تامین‌کننده</label>
                                <div class="form-control-wrap">
                                    <select class="form-select" id="supplier_group"
                                            data-for="supplier_group" data-req="1">
										<?php
										if ( empty( $categories['items'] ) ) {
											echo '<option value="0">پیش از ثبت تامین‌کننده بایستی دسته بندی ایجاد شود</option>';
										} else {
											foreach ( $categories['items'] as $index => $item ) {
												echo "<option value='{$item['id']}'>{$item['title']}</option>";
											}
										}
										?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="supplier_account_number">شماره حساب</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="supplier_account_number"
                                           data-for="account_number" data-req="1">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="supplier_cart_number">شماره کارت</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="supplier_cart_number"
                                           data-for="cart_number" data-req="1">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="supplier_shaba_number">شماره شبا</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="supplier_shaba_number"
                                           data-for="shaba_number" data-req="1">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="supplier_state">استان</label>
                                <div class="form-control-wrap">
                                    <select class="form-select js-select2 js-select2-sm load_city"
                                            id="supplier_state" data-for="state" data-req="1"
                                            data-target="#supplier_city">
										<?php
										$states = WC()->countries->get_states( 'IR' );
										foreach ( $states as $state => $label ) {
											?>
                                            <option value="<?= $state ?>"><?= $label ?></option>
											<?php
										}
										?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="supplier_city">شهر</label>
                                <div class="form-control-wrap">
                                    <select class="form-select js-select2 js-select2-sm"
                                            id="supplier_city" data-for="city" data-req="1">
                                        <option value="0">ابتدا استان را انتخاب کنید</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label" for="supplier_address">آدرس</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="supplier_address"
                                           data-for="address" data-req="1">
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                <li>
                                    <div class="btn btn-primary submit_modal_form">ثبت اطلاعات</div>
                                </li>
                                <li>
                                    <a href="#" class="link link-light" data-bs-dismiss="modal">لغو</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<div class="modal fade zoom" id="addCustomer">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">افزودن کاربر</h5>
                <a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
            </div>
            <div class="modal-body">
                <form action="#" class="modal_form" data-action="kph_add_user" data-page="/crm/user">
                    <div class="row g-gs">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label class="form-label" for="new_customer_first_name">نام</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="new_customer_first_name"
                                           data-req="1" data-for="first_name">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label class="form-label" for="new_customer_last_name">نام خانوادگی</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="new_customer_last_name"
                                           data-req="1" data-for="last_name">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label class="form-label" for="new_customer_phone">شماره موبایل</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="new_customer_phone"
                                           data-req="1" data-for="phone">
                                </div>
                            </div>
                        </div>
						<?php
						foreach ( $user_metas as $key => $meta ) {
							$type        = $meta['type'] ?? 'text';
							$label       = $meta['label'];
							$required    = $meta['required'] ?? FALSE;
							$target      = $meta['target'] ?? FALSE;
							$width       = $meta['width'] ?? 6;
							$id          = 'new_customer_' . $key;
							$row_classes = 'col-md-' . (int) $width . ' meta-field-row';
							$is_conditional = ( $meta['state'] ?? '' ) === 'conditional';
							if ( $required ) {
								$label .= '*';
							}
							?>
                            <div class="<?php echo esc_attr( $row_classes ); ?>"
                                 data-conditional="<?php echo $is_conditional ? '1' : '0'; ?>"
                                 data-cond-meta="<?php echo esc_attr( $meta['conditions']['meta'] ?? '' ); ?>"
                                 data-cond-expected='<?php echo esc_attr( wp_json_encode( $meta['conditions']['value'] ?? '' ) ); ?>'
                                 data-cond-operator="<?php echo esc_attr( $meta['conditions']['operator'] ?? '==' ); ?>">
                                <div class="form-group">
                                    <label class="form-label" for="<?php echo $id; ?>"><?php echo $label; ?></label>
                                    <div class="form-control-wrap">
										<?php
										if ( $type === 'select' && ! empty( $meta['options'] ) ) {
											?>
                                            <select class="form-select js-select2 <?php echo $meta['class'] ?? ''; ?>"
												<?php echo $required ? 'data-req="1"' : ""; ?>
												<?php echo $target ? "data-target='{$target }'" : ""; ?>
                                                    id="<?php echo $id; ?>"
                                                    data-for="meta[<?php echo $key; ?>]">
                                                <option value="" selected disabled>انتخاب کنید</option>
												<?php
												foreach ( $meta['options'] as $option_value => $option_data ) {
													$option_label = is_array( $option_data ) ? $option_data['label'] : $option_data;
													echo "<option value='$option_value'>$option_label</option>";
												}
												?>
                                            </select>
											<?php
										} elseif ( $type === 'date' ) {
											if ( ! empty( $value ) ) {
												$value = date_i18n( 'Y/m/d', strtotime( $value ) );
											}
											?>
                                            <div class="form-icon form-icon-right">
                                                <em class="icon ni ni-calendar"></em>
                                            </div>
                                            <input type="text" class="form-control datepicker"
												<?php echo $required ? 'data-req="1"' : ""; ?>
                                                   id="<?php echo $id; ?>"
                                                   data-for="meta[<?php echo $key; ?>]"
                                                   placeholder="روز-ماه-سال"/>
											<?php
										} else {
											?>
                                            <input type="<?php echo $type; ?>" class="form-control"
												<?php echo $required ? 'data-req="1"' : ""; ?>
                                                   id="<?php echo $id; ?>"
                                                   data-for="meta[<?php echo $key; ?>]">
											<?php
										}
										?>
                                    </div>
                                </div>
                            </div>
							<?php
						}
						?>
                        <div class="col-12">
                            <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                <li>
                                    <div class="btn btn-primary submit_modal_form">افزودن مشتری</div>
                                </li>
                                <li><a href="#" class="link link-light" data-bs-dismiss="modal">لغو</a></li>
                            </ul>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<div class="modal fade zoom" id="addCustomer_for_modal">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">افزودن کاربر</h5>
                <a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
            </div>
            <div class="modal-body">
                <form action="#">
                    <div class="row g-gs">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="new_customer_user_name_for_modal">نام و نام
                                    خانوادگی</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="new_customer_user_name_for_modal">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="new_customer_phone_for_modal">شماره موبایل</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="new_customer_phone_for_modal">
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                <li>
                                    <div id="register_new_user_for_modal" class="btn btn-primary"
                                         data-bs-dismiss="modal">افزودن کاربر
                                    </div>
                                </li>
                                <li><a href="#" class="link link-light" data-bs-dismiss="modal">لغو</a></li>
                                <input type="hidden" id="modal_to_open">
                            </ul>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php if ($can_account) { ?>
<div class="modal fade" id="addUserPayments">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">افزودن پرداختی</h5>
                <a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
            </div>
            <div class="modal-body modal-body-md">
                <form action="#" class="modal_form" data-action="kph_add_payment"
                      data-page="/crm/user">
                    <div class="row g-gs">
                        <div class="col-md-6 hide_on_profile">
                            <div class="form-group card-title">
                                <label class="form-label">کاربر:</label>
                                <div class="payment_customer_box nk-tb-list">
                                    <span class="sub-text">برای انتخاب کاربر لطفا در فیلد روبرو جستجو کنید.</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 hide_on_profile">
                            <div class="form-group card-title search_wrapper">
                                <label class="form-label" for="search_user_payment">جستجوی کاربر</label>
                                <div class="form-control-wrap">
                                    <div class="form-icon form-icon-left"><em class="icon ni ni-user"></em></div>
                                    <input type="text" class="form-control search_user_modal" id="search_user_payment">
                                </div>
                                <p class="mt-1">جهت جستجوی کاربر شماره موبایل و یا نام کاربر را جستجو کنید.</p>
                                <div class="customer_search_result" data-input="#new_payment_customer_id"
                                     data-preview=".payment_customer_box"></div>
                            </div>
                        </div>
                        <input type="hidden" id="new_payment_customer_id" data-for="id" data-req="1">
                        <input type="hidden" data-for="freight_nonce" value="<?php echo esc_attr(wp_create_nonce('kph_customer_freight')); ?>">
                        <input type="hidden" data-for="freight_request" value="<?php echo esc_attr(wp_generate_uuid4()); ?>">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="payment_paid_at">تاریخ پرداخت</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control datepicker" id="payment_paid_at"
                                           data-for="paid_at" data-req="1">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="payment_method">شیوه پرداخت</label>
                                <div class="form-control-wrap">
                                    <select class="form-select" id="payment_method"
                                            data-for="payment_method" data-req="1">
										<?php
										foreach ( $payment_methods as $key => $item ) {
                                            if ($key==='customer_freight' && !kph_customer_freight::allowed()) continue;
											echo "<option value='{$key}'>{$item['label']}</option>";
										}
										?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="payment_amount">مبلغ پرداختی</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control price_input" id="payment_amount"
                                           data-for="amount" data-req="1">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 kph-payment-side-field">
                            <div class="form-group">
                                <label class="form-label">نوع</label>
                                <div class="form-control-wrap">
                                    <ul class="custom-control-group">
                                        <li>
                                            <div class="custom-control custom-control-pro no-control ">
                                                <input type="radio" class="custom-control-input"
                                                       data-for="side"
                                                       value="credit" name="payment_side" id="payment_side_credit">
                                                <label class="custom-control-label text-success"
                                                       for="payment_side_credit">
                                                    <em class="icon ni ni-arrow-long-up"></em>
                                                    <span>بستانکار</span>
                                                </label>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="custom-control custom-control-pro no-control checked">
                                                <input type="radio" class="custom-control-input" checked
                                                       data-for="side"
                                                       value="debit" name="payment_side" id="payment_side_debit">
                                                <label class="custom-control-label text-danger"
                                                       for="payment_side_debit">
                                                    <em class="icon ni ni-arrow-long-down"></em>
                                                    <span>بدهکار</span>
                                                </label>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 kph-freight-fields d-none">
                            <div class="form-group">
                                <label class="form-label" for="payment_freight_invoice">فاکتور مربوط به کرایه (اختیاری)</label>
                                <div class="form-control-wrap"><select class="form-select" id="payment_freight_invoice" data-for="freight_order_id"><option value="">بدون اتصال به فاکتور</option></select></div>
                            </div>
                        </div>
                        <div class="col-12 kph-freight-fields d-none"><p class="text-soft">مبلغ از بدهی مشتری کم و خودکار در هزینه‌های «کرایه مشتریان» ثبت می‌شود. با انتخاب فاکتور مربوط، از ثبت دوبارهٔ کرایه در کنترل ارسال جلوگیری می‌شود.</p></div>
                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label">توضیحات</label>
                                <div class="form-control-wrap">
                                    <div class="quill-basic" data-name="payment_note" data-for="note"
                                         data-req="1">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label" for="action_attachment">فایل ضمیمه</label>
                                <div class="upload-zone" data-target="#new_payment_attachment"
                                     data-action="kph_handle_file_upload" data-max-files="1">
                                    <div class="dz-message" data-dz-message>
                                        <span class="dz-message-text">بکشید و رها کنید</span>
                                        <span class="dz-message-or">یا</span>
                                        <div class="btn btn-primary">انتخاب کنید</div>
                                    </div>
                                </div>
                            </div>
                            <input type="hidden" id="new_payment_attachment" data-for="attachment">
                        </div>
                        <input type="hidden" data-for="tab" value="payments">
                        <input type="hidden" data-for="invoice_id" value="0" id="new_payment_invoice_id">
                        <div class="col-12">
                            <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                <li>
                                    <div class="btn btn-primary submit_modal_form">ثبت</div>
                                </li>
                                <li>
                                    <a href="#" class="link link-light" data-bs-dismiss="modal">لغو</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="addUserTransfer">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">افزودن حواله</h5>
                <a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
            </div>
            <div class="modal-body modal-body-md">
                <form action="#" class="modal_form" data-action="kph_add_transfer"
                      data-page="/crm/user">
                    <div class="row g-gs">
                        <div class="col-md-6 hide_on_profile">
                            <div class="form-group card-title">
                                <label class="form-label">کاربر:</label>
                                <div class="transfer_customer_box nk-tb-list">
                                    <span class="sub-text">برای انتخاب کاربر لطفا در فیلد روبرو جستجو کنید.</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 hide_on_profile">
                            <div class="form-group card-title search_wrapper">
                                <label class="form-label" for="search_user_transfer">جستجوی کاربر</label>
                                <div class="form-control-wrap">
                                    <div class="form-icon form-icon-left"><em class="icon ni ni-user"></em></div>
                                    <input type="text" class="form-control search_user_modal" id="search_user_transfer">
                                </div>
                                <p class="mt-1">جهت جستجوی کاربر شماره موبایل و یا نام کاربر را جستجو کنید.</p>
                                <div class="customer_search_result" data-input="#new_transfer_customer_id"
                                     data-preview=".transfer_customer_box"></div>
                            </div>
                        </div>
                        <input type="hidden" id="new_transfer_customer_id" data-for="id" data-req="1">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="transferred_at">تاریخ پرداخت</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control datepicker" id="transferred_at"
                                           data-for="transferred_at" data-req="1">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="transfer_bank">نام بانک</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="transfer_bank"
                                           data-for="bank" data-req="1">
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label" for="transfer_tracking_no">کد پیگیری</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="transfer_tracking_no"
                                           data-for="tracking_no" data-req="1">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="transfer_amount">مبلغ حواله</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control price_input" id="transfer_amount"
                                           data-for="amount" data-req="1">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">نوع</label>
                                <div class="form-control-wrap">
                                    <ul class="custom-control-group">
                                        <li>
                                            <div class="custom-control custom-control-pro no-control checked">
                                                <input type="radio" class="custom-control-input activate_logic" checked
                                                       data-target="transfer_side"
                                                       data-for="side"
                                                       value="credit" name="transfer_side" id="transfer_side_credit">
                                                <label class="custom-control-label text-success"
                                                       for="transfer_side_credit">
                                                    <em class="icon ni ni-arrow-long-up"></em>
                                                    <span>بستانکار</span>
                                                </label>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="custom-control custom-control-pro no-control">
                                                <input type="radio" class="custom-control-input activate_logic"
                                                       data-target="transfer_side" data-target-value="none"
                                                       data-for="side"
                                                       value="debit" name="transfer_side" id="transfer_side_debit">
                                                <label class="custom-control-label text-danger"
                                                       for="transfer_side_debit">
                                                    <em class="icon ni ni-arrow-long-down"></em>
                                                    <span>بدهکار</span>
                                                </label>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 conditional_show" data-logic="transfer_side" data-value="credit">
                            <div class="form-group">
                                <label class="form-label">مقصد حواله</label>
                                <div class="form-control-wrap">
                                    <select class="form-select activate_logic" id="transfer_destination_id"
                                            data-for="destination_id" data-target="transfer_destination">
                                        <option value="none" selected>حواله آزاد</option>
                                        <option value="account">حساب مالی</option>
                                        <option value="supplier">تامین کننده</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 conditional_show" data-logic="transfer_destination" data-value="account"
                             style="display: none">
                            <div class="form-group">
                                <label class="form-label" for="transfer_to_account_id">حساب مقصد</label>
                                <div class="form-control-wrap">
                                    <select class="form-select " id="transfer_to_account_id"
                                            data-for="account_id" data-req="1">
										<?php
										foreach ( $accounts as $entry ) {
											$key = $entry['id'];
											echo "<option value='{$key}'>{$entry['title']}</option>";
										}
										?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 conditional_show" data-logic="transfer_destination" data-value="account"
                             style="display: none">
                            <p class="form-note">واریز حواله، موجودی حساب را افزایش می‌دهد. هزینه را هنگام برداشت از حساب ثبت کنید.</p>
                        </div>
                        <div class="col-md-6 conditional_show" data-logic="transfer_destination" data-value="account"
                             style="display: none">
                            <div class="form-group">
                                <label class="form-label" for="transfer_to_account_destination">مقصد حواله
                                </label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" data-req="1"
                                           id="transfer_to_account_destination"
                                           data-for="account_destination">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 conditional_show" data-logic="transfer_destination" data-value="supplier"
                             style="display: none">
                            <div class="form-group card-title">
                                <label class="form-label">تامین کننده:</label>
                                <div class="transfer_supplier_box nk-tb-list">
                                    <span class="sub-text">برای انتخاب تامین کننده لطفا در فیلد روبرو جستجو کنید.</span>
                                </div>
                                <input type="hidden" id="transfer_supplier_id" data-for="destination_user_id"
                                       data-req="1">
                            </div>
                            <div class="form-group card-title search_wrapper">
                                <label class="form-label" for="search_user_transfer_supplier">جستجوی تامین کننده</label>
                                <div class="form-control-wrap">
                                    <div class="form-icon form-icon-left"><em class="icon ni ni-user"></em></div>
                                    <input type="text" class="form-control search_user_modal" data-role="supplier"
                                           id="search_user_transfer_supplier">
                                </div>
                                <p class="mt-1">جهت جستجوی کاربر شماره موبایل و یا نام کاربر را جستجو کنید.</p>
                                <div class="customer_search_result" data-input="#transfer_supplier_id"
                                     data-preview=".transfer_supplier_box"></div>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label">توضیحات</label>
                                <div class="form-control-wrap">
                                    <div class="quill-basic" data-name="transfer_note" data-for="note"
                                         data-req="1">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label" for="action_attachment">فایل ضمیمه</label>
                                <div class="upload-zone" data-target="#new_transfer_attachment"
                                     data-action="kph_handle_file_upload" data-max-files="1">
                                    <div class="dz-message" data-dz-message>
                                        <span class="dz-message-text">بکشید و رها کنید</span>
                                        <span class="dz-message-or">یا</span>
                                        <div class="btn btn-primary">انتخاب کنید</div>
                                    </div>
                                </div>
                            </div>
                            <input type="hidden" id="new_transfer_attachment" data-for="attachment">
                        </div>
                        <input type="hidden" data-for="tab" value="transfers">
                        <input type="hidden" data-for="invoice_id" value="0" id="new_transfer_invoice_id">
                        <div class="col-12">
                            <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                <li>
                                    <div class="btn btn-primary submit_modal_form">ثبت</div>
                                </li>
                                <li>
                                    <a href="#" class="link link-light" data-bs-dismiss="modal">لغو</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="addCheque">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">افزودن چک</h5>
                <a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
            </div>
            <div class="modal-body modal-body-md">
                <form action="#" class="modal_form" data-action="kph_add_cheque" data-page="/crm/user">
                    <div class="row g-3">
                        <div class="col-md-6 hide_on_profile">
                            <div class="form-group card-title">
                                <label class="form-label">کاربر:</label>
                                <div class="cheque_customer_box nk-tb-list">
                                    <span class="sub-text">برای انتخاب کاربر لطفا در فیلد روبرو جستجو کنید.</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 hide_on_profile">
                            <div class="form-group card-title search_wrapper">
                                <label class="form-label" for="search_user_cheque">جستجوی کاربر</label>
                                <div class="form-control-wrap">
                                    <div class="form-icon form-icon-left"><em class="icon ni ni-user"></em></div>
                                    <input type="text" class="form-control search_user_modal" id="search_user_cheque">
                                </div>
                                <p class="mt-1">جهت جستجوی کاربر شماره موبایل و یا نام کاربر را جستجو کنید.</p>
                                <div class="customer_search_result" data-input="#new_cheque_customer_id"
                                     data-preview=".cheque_customer_box"></div>
                            </div>
                        </div>
                        <input type="hidden" id="new_cheque_customer_id" data-for="id" data-req="1">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="cheque_cheque_no">شماره سریال چک</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="cheque_cheque_no"
                                           data-for="cheque_no" data-req="1">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="cheque_sayad_id">شناسه صیادی</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="cheque_sayad_id"
                                           data-for="sayad_id" data-req="1">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label class="form-label" for="cheque_bank">نام بانک</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="cheque_bank"
                                           data-for="bank_name" data-req="1">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label class="form-label" for="cheque_bank_branch">نام شعبه</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="cheque_bank_branch"
                                           data-for="meta[bank_branch]" data-req="1">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label class="form-label" for="cheque_bank_owner">صاحب حساب</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="cheque_bank_owner"
                                           data-for="meta[bank_owner]" data-req="1">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="cheque_amount">مبلغ چک</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control price_input" id="cheque_amount"
                                           data-for="amount" data-req="1">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="cheque_due_at">تاریخ سررسید</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control datepicker" id="cheque_due_at"
                                           data-for="due_at" data-req="1">
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label">فایل ضمیمه</label>
                                <div class="upload-zone" data-target="#new_cheque_attachment"
                                     data-action="kph_handle_file_upload" data-max-files="1">
                                    <div class="dz-message" data-dz-message>
                                        <span class="dz-message-text">بکشید و رها کنید</span>
                                        <span class="dz-message-or">یا</span>
                                        <div class="btn btn-primary">انتخاب کنید</div>
                                    </div>
                                </div>
                            </div>
                            <input type="hidden" id="new_cheque_attachment" data-for="meta[attachment]">
                        </div>
                        <?php echo kph_get_template( 'components/cheque-admin-note-field.php' ); ?>
                        <input type="hidden" data-for="tab" value="cheque">
                        <div class="col-12">
                            <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                <li>
                                    <div class="btn btn-primary submit_modal_form">ثبت</div>
                                </li>
                                <li>
                                    <a href="#" class="link link-light" data-bs-dismiss="modal">لغو</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="addAccount">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">افزودن حساب</h5>
                <a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
            </div>
            <div class="modal-body modal-body-md">
                <form action="#" class="modal_form" data-action="kph_add_account" data-page="/crm/finance-accounts">
                    <div class="row g-3">
                        <input data-for="account_id" value="0" type="hidden">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="account_title">عنوان حساب</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="account_title"
                                           data-for="title" data-req="1">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 conditional_show" data-logic="account_type" data-value="bank">
                            <div class="form-group">
                                <label class="form-label" for="account_initial_balance">موجودی اولیه</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control price_input" id="account_initial_balance"
                                           data-for="initial_balance">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 conditional_show" data-logic="account_type" data-value="cash"
                             style="display: none">
                            <div class="form-group">
                                <label class="form-label" for="account_initial_balance">موجودی اولیه</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control price_input" id="account_initial_balance"
                                           data-for="initial_balance">
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label">نوع حساب</label>
                                <div class="form-control-wrap">
                                    <ul class="custom-control-group">
                                        <li>
                                            <div class="custom-control custom-control-pro no-control checked ">
                                                <input type="radio" class="custom-control-input activate_logic" checked
                                                       data-target="account_type"
                                                       data-for="type" data-req="1"
                                                       value="bank" name="account_type" id="account_type_bank">
                                                <label class="custom-control-label"
                                                       for="account_type_bank">
                                                    <em class="icon ni ni-cc-alt"></em>
                                                    <span>حساب بانکی</span>
                                                </label>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="custom-control custom-control-pro no-control">
                                                <input type="radio" class="custom-control-input activate_logic"
                                                       data-target="account_type"
                                                       data-for="type" data-req="1"
                                                       value="cash" name="account_type" id="account_type_cash">
                                                <label class="custom-control-label"
                                                       for="account_type_cash">
                                                    <em class="icon ni ni-money"></em>
                                                    <span>حساب نقدی</span>
                                                </label>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="custom-control custom-control-pro no-control">
                                                <input type="radio" class="custom-control-input activate_logic"
                                                       data-target="account_type"
                                                       data-for="type" data-req="1"
                                                       value="expense" name="account_type" id="account_type_expense">
                                                <label class="custom-control-label"
                                                       for="account_type_expense">
                                                    <em class="icon ni ni-money"></em>
                                                    <span>حساب هزینه</span>
                                                </label>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 conditional_show" data-logic="account_type" data-value="bank">
                            <div class="form-group">
                                <label class="form-label" for="account_owner_name">مالک حساب</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="account_owner_name"
                                           data-for="owner_name">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 conditional_show" data-logic="account_type" data-value="bank">
                            <div class="form-group">
                                <label class="form-label" for="account_bank_name">نام بانک</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="account_bank_name"
                                           data-for="bank_name">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 conditional_show" data-logic="account_type" data-value="bank">
                            <div class="form-group">
                                <label class="form-label" for="account_account_no">شماره حساب</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="account_account_no"
                                           data-for="account_no">
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                <li>
                                    <div class="btn btn-primary submit_modal_form">ثبت</div>
                                </li>
                                <li>
                                    <a href="#" class="link link-light" data-bs-dismiss="modal">لغو</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="referChequeToUser">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">انتقال چک به تامین کننده</h5>
                <a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
            </div>
            <div class="modal-body modal-body-md">
                <form action="#" class="modal_form" data-action="kph_refer_cheque_to_user" data-page="/crm/supplier">
                    <div class="row g-3">
                        <div class="col-12">
							<?php
							$in_hands = $DB->get_cheques( [
								'page'     => 1,
								'per_page' => 5,
								'status'   => 'in_hand',
							] );
							if ( empty( $in_hands['items'] ) ) {
								echo "<div class='no-item-found'>چکی برای انتقال در اختیار مجموعه نیست.</div>";
							} else {
								?>
                                <div id="cheque_to_refer_table">
									<?php
									echo kph_get_template( 'partials/in-hand-table.php', [
										'in_hands'    => $in_hands,
										'DB'          => $DB,
										'page_number' => 1,
									] )
									?>
                                </div>
								<?php
							}
							?>
                        </div>
                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label">توضیحات</label>
                                <div class="form-control-wrap">
                                    <div class="quill-basic" data-name="payment_note" data-for="note"
                                         data-req="1">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <input type="hidden" data-for="tab" value="cheque">
                        <input type="hidden" id="refer_cheque_user_id" data-for="id" data-req="1">
                        <input type="hidden" id="refer_cheque_invoice_id" data-for="invoice_id">
                        <div class="col-12">
                            <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                <li>
                                    <div class="btn btn-primary submit_modal_form">ثبت</div>
                                </li>
                                <li>
                                    <a href="#" class="link link-light" data-bs-dismiss="modal">لغو</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php } ?>
<div class="modal fade zoom" id="invoiceItemsTable">
    <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">آیتم های فاکتور</h5>
                <a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
            </div>
            <div class="bg-white modal-body">
            </div>
        </div>
    </div>
</div>
<div class="modal fade zoom" id="invoiceFulfillmentTable">
    <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">ارسال های سفارش</h5>
                <a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
            </div>
            <div class="bg-white modal-body">
            </div>
        </div>
    </div>
</div>
<?php if ($can_account) { ?>
<div class="modal fade zoom" id="orderFinancialTable">
    <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">حسابداری سفارش</h5>
                <a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
            </div>
            <div class="bg-white modal-body">
            </div>
        </div>
    </div>
</div>

<?php } ?>
<div class="modal fade zoom" id="batchStorageMoveTable">
    <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">گزارشات گردش انبار</h5>
                <a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
            </div>
            <div class="bg-white modal-body">
            </div>
        </div>
    </div>
</div>
<div class="modal fade zoom" id="processingToPackagingReport">
    <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">گزارش انتقال محصول فرآوری شده به سالن</h5>
                <a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
            </div>
            <div class="bg-white modal-body">
            </div>
        </div>
    </div>
</div>
<div class="modal fade zoom" id="processingPackInputs">
    <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">آیتم های محصول فرآوری شده</h5>
                <a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
            </div>
            <div class="bg-white modal-body">
            </div>
        </div>
    </div>
</div>
<div class="modal fade zoom" id="lotMovesLogTable">
    <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">سوابق اقدامات درون سالن</h5>
                <a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
            </div>
            <div class="bg-white modal-body">
            </div>
        </div>
    </div>
</div>
<div class="modal fade zoom" id="inventoryLogTable">
    <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">گزارش گردش انبار محصول</h5>
                <a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
            </div>
            <div class="bg-white modal-body">
            </div>
        </div>
    </div>
</div>
<?php if ($can_account) { ?>
<div class="modal fade zoom" id="chequeMovesTable">
    <div class="modal-dialog modal-md" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">سوابق گردش چک</h5>
                <a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
            </div>
            <div class="bg-white modal-body">
            </div>
        </div>
    </div>
</div>
<?php } ?>
<div class="modal fade" id="addVisitor">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">افزودن ویزیتور</h5>
                <a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
            </div>
            <div class="modal-body modal-body-md">
                <form action="#" class="modal_form" data-action="kph_add_employee"
                      data-page="/crm/hr-visitors">
                    <div class="row g-gs">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="new_visitors_name">نام و نام خانوادگی</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="new_visitors_name"
                                           data-for="full_name">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="new_visitors_username">نام کاربری</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="new_visitors_username"
                                           data-for="username">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="new_visitors_phone">شماره تماس</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="new_visitors_phone"
                                           data-for="phone">
                                </div>
                            </div>
                        </div>
                        <input type="hidden" value="visitor" data-for="role">
                        <div class="col-12">
                            <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                <li>
                                    <div class="btn btn-primary submit_modal_form">ثبت</div>
                                </li>
                                <li>
                                    <a href="#" class="link link-light" data-bs-dismiss="modal">لغو</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer bg-light">
                <span class="sub-text text-end ">
                    نام کاربری همان username جهت ورود می‌باشد.
                    <br>
                    رمز عبور به صورت پیشفرض 123456 می باشد. کارشناس می تواند پس از ورود این رمز را تغییر دهد.
                </span>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="addEmployee">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">افزودن کارشناس</h5>
                <a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
            </div>
            <div class="modal-body modal-body-md">
                <form action="#" class="modal_form" data-action="kph_add_employee"
                      data-page="/crm/hr-employees">
                    <div class="row g-gs">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="new_employee_name">نام و نام خانوادگی</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="new_employee_name"
                                           data-for="full_name">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="new_employee_username">نام کاربری</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="new_employee_username"
                                           data-for="username">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="new_employee_phone">شماره تماس</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="new_employee_phone"
                                           data-for="phone">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="new_employee_role">نقش</label>
                                <div class="form-control-wrap">
                                    <select class="form-select" id="new_employee_role" data-for="role">
										<?php
										foreach ( $all_roles as $role => $role_label ) {
											?>
                                            <option value="<?php echo $role; ?>"><?php echo $role_label; ?></option>
											<?php
										}
										?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                <li>
                                    <div class="btn btn-primary submit_modal_form">ثبت</div>
                                </li>
                                <li>
                                    <a href="#" class="link link-light" data-bs-dismiss="modal">لغو</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer bg-light">
                <span class="sub-text text-end ">
                    نام کاربری همان username جهت ورود می‌باشد.
                    <br>
                    رمز عبور به صورت پیشفرض 123456 می باشد. کارشناس می تواند پس از ورود این رمز را تغییر دهد.
                </span>
            </div>
        </div>
    </div>
</div>
<?php if ($can_account) { ?>
<div class="modal fade" id="addAccountTransaction">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">ثبت تراکنش برای حساب</h5>
                <a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
            </div>
            <div class="modal-body modal-body-md">
                <form action="#" class="modal_form" data-action="kph_add_account_transaction"
                      data-page="/crm/finance-transactions">
                    <input type="hidden" data-for="finance_request" value="<?php echo esc_attr( wp_generate_uuid4() ); ?>">
                    <input type="hidden" data-for="finance_nonce" value="<?php echo esc_attr(wp_create_nonce('kph_finance_transaction')); ?>">
                    <div class="row g-3">
                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label" for="cost_category">دسته بندی تراکنش</label>
                                <div class="form-control-wrap">
                                    <select class="form-select" id="cost_category"
                                            data-for="meta[cost_type]" data-req="1">
										<?php
										foreach ( $cost_type as $key => $item ) {
											echo "<option value='{$key}'>{$item['label']}</option>";
										}
										?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="cost_transaction_date">تاریخ تراکنش</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control datepicker" id="cost_transaction_date"
                                           autocomplete="off" data-for="created_at" data-req="1">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="cost_transaction_time">ساعت تراکنش</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control time-picker" id="cost_transaction_time"
                                           autocomplete="off"
                                           data-time-format="HH:mm"
                                           data-for="created_at_time">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="cost_transaction_amount">مبلغ تراکنش</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control price_input" id="cost_transaction_amount"
                                           data-for="amount" data-req="1">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">نوع</label>
                                <div class="form-control-wrap">
                                    <ul class="custom-control-group">
                                        <li>
                                            <div class="custom-control custom-control-pro no-control ">
                                                <input type="radio" class="custom-control-input"
                                                       data-for="type"
                                                       value="credit" name="payment_side" id="cost_transaction_credit">
                                                <label class="custom-control-label text-success"
                                                       for="cost_transaction_credit">
                                                    <em class="icon ni ni-arrow-long-up"></em>
                                                    <span>درآمد</span>
                                                </label>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="custom-control custom-control-pro no-control checked">
                                                <input type="radio" class="custom-control-input" checked
                                                       data-for="type"
                                                       value="debit" name="payment_side" id="cost_transaction_debit">
                                                <label class="custom-control-label text-danger"
                                                       for="cost_transaction_debit">
                                                    <em class="icon ni ni-arrow-long-down"></em>
                                                    <span>هزینه</span>
                                                </label>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">دپارتمان مرتبط</label>
                                <select class="form-select" data-for="meta[department]" data-req="1">
                                    <option value="finance">مالی</option>
                                    <option value="sales">فروش</option>
                                    <option value="production">تولید</option>
                                    <option value="supply">تأمین</option>
                                    <option value="warehouse">انبار</option>
                                    <option value="admin">اداری</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label class="form-label" for="cost_transaction_destination">مقصد تراکنش</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="cost_transaction_destination"
                                           data-for="meta[destination]">
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label">توضیحات</label>
                                <div class="form-control-wrap">
                                    <div class="quill-basic" data-name="cost_transaction_description"
                                         data-for="description" data-req="1">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label">فایل ضمیمه</label>
                                <div class="upload-zone" data-target="#new_transaction_attachment"
                                     data-action="kph_handle_file_upload" data-max-files="1">
                                    <div class="dz-message" data-dz-message>
                                        <span class="dz-message-text">بکشید و رها کنید</span>
                                        <span class="dz-message-or">یا</span>
                                        <div class="btn btn-primary">انتخاب کنید</div>
                                    </div>
                                </div>
                            </div>
                            <input type="hidden" id="new_transaction_attachment" data-for="meta[attachment]">
                        </div>
                        <input type="hidden" id="new_transaction_account_id" data-for="account_id" data-req="1">
                        <div class="col-12">
                            <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                <li>
                                    <button type="button" class="btn btn-primary submit_modal_form">ثبت</button>
                                </li>
                                <li>
                                    <a href="#" class="link link-light" data-bs-dismiss="modal">لغو</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="addChequeToAccount">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">وصول چک</h5>
                <a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
            </div>
            <div class="modal-body modal-body-md">
                <form action="#" class="modal_form" data-action="kph_change_cheque_status"
                      data-page="/crm/finance-cheque">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="cheque_to_account_id">حساب مقصد</label>
                                <div class="form-control-wrap">
                                    <select class="form-select" id="cheque_to_account_id"
                                            data-for="account_id" data-req="1">
										<?php
										foreach ( $accounts as $entry ) {
											$key = $entry['id'];
											echo "<option value='{$key}'>{$entry['title']}</option>";
										}
										?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="cheque_to_account_cost_category">دسته بندی تراکنش</label>
                                <div class="form-control-wrap">
                                    <select class="form-select" id="cheque_to_account_cost_category"
                                            data-for="meta[cost_type]" data-req="1">
										<?php
										foreach ( $cost_type as $key => $item ) {
											echo "<option value='{$key}'>{$item['label']}</option>";
										}
										?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="cheque_to_account_destination">مقصد پرداخت</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control"
                                           id="cheque_to_account_destination"
                                           data-for="meta[destination]" data-req="1">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="cheque_to_account_cost_transaction_date">تاریخ
                                    وصول</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control datepicker"
                                           id="cheque_to_account_cost_transaction_date"
                                           data-for="created_at" data-req="1">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label">نوع</label>
                                <div class="form-control-wrap">
                                    <ul class="custom-control-group">
                                        <li>
                                            <div class="custom-control custom-control-pro no-control ">
                                                <input type="radio" class="custom-control-input"
                                                       data-for="type"
                                                       value="credit" name="payment_side"
                                                       id="cheque_to_account_cost_transaction_credit">
                                                <label class="custom-control-label text-success"
                                                       for="cheque_to_account_cost_transaction_credit">
                                                    <em class="icon ni ni-arrow-long-up"></em>
                                                    <span>درآمد</span>
                                                </label>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="custom-control custom-control-pro no-control checked">
                                                <input type="radio" class="custom-control-input" checked
                                                       data-for="type"
                                                       value="debit" name="payment_side"
                                                       id="cheque_to_account_cost_transaction_debit">
                                                <label class="custom-control-label text-danger"
                                                       for="cheque_to_account_cost_transaction_debit">
                                                    <em class="icon ni ni-arrow-long-down"></em>
                                                    <span>هزینه</span>
                                                </label>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label">توضیحات</label>
                                <div class="form-control-wrap">
                                    <div class="quill-basic" data-name="cheque_to_account_cost_transaction_description"
                                         data-for="description" data-req="1">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label">فایل ضمیمه</label>
                                <div class="upload-zone" data-target="#cheque_to_account_new_transaction_attachment"
                                     data-action="kph_handle_file_upload" data-max-files="1">
                                    <div class="dz-message" data-dz-message>
                                        <span class="dz-message-text">بکشید و رها کنید</span>
                                        <span class="dz-message-or">یا</span>
                                        <div class="btn btn-primary">انتخاب کنید</div>
                                    </div>
                                </div>
                            </div>
                            <input type="hidden" id="cheque_to_account_new_transaction_attachment"
                                   data-for="meta[attachment]">
                        </div>
                        <input type="hidden" data-for="status" value="clear" data-req="1">
                        <input type="hidden" id="cheque_to_account_cheque_id" data-for="cheque_id"
                               data-req="1">
                        <input type="hidden" id="cheque_to_account_cost_transaction_amount" data-for="amount"
                               data-req="1">
                        <input type="hidden" id="cost_transaction_cheque_id" data-for="meta[cheque]" data-req="1">
                        <div class="col-12">
                            <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                <li>
                                    <div class="btn btn-primary submit_modal_form">ثبت</div>
                                </li>
                                <li>
                                    <a href="#" class="link link-light" data-bs-dismiss="modal">لغو</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php } ?>
<div class="modal fade" id="addUserAddress">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">افزودن آدرس</h5>
                <a href="#" class="close" data-bs-dismiss="modal" aria-label="بستن">
                    <em class="icon ni ni-cross"></em>
                </a>
            </div>
            <div class="modal-body modal-body-md">
                <form action="#">
                    <div class="row g-gs">
                        <div class="custom-control custom-control-sm custom-switch checked address_for_main_customer">
                            <input type="checkbox" class="custom-control-input" id="address_for_main_customer"
                                   value="1">
                            <label class="custom-control-label" for="address_for_main_customer">گیرنده همان مشتری
                                هست</label>
                        </div>
                        <div class="col-md-6 hide_for_customer">
                            <div class="form-group">
                                <label class="form-label" for="address_first_name">نام</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="address_first_name">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 hide_for_customer">
                            <div class="form-group">
                                <label class="form-label" for="address_last_name">نام خانوادگی</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="address_last_name">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 hide_for_customer">
                            <div class="form-group">
                                <label class="form-label" for="address_phone">شماره موبایل</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="address_phone">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="address_postcode">کد پستی</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="address_postcode">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <div class="form-control-wrap">
                                    <label class="form-label" for="address_state">استان</label>
                                    <select class="form-select js-select2 js-select2-sm load_city"
                                            id="address_state"
                                            data-target="#address_city">
                                        <option value="0">انتخاب کنید</option>
										<?php
										foreach ( $states as $state => $label ) {
											?>
                                            <option value="<?= $state ?>"><?= $label ?></option>
											<?php
										}
										?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="address_city">شهر</label>
                                <div class="form-control-wrap">
                                    <select class="form-select js-select2 js-select2-sm select2-hidden-accessible"
                                            id="address_city">
                                        <option value="0">ابتدا استان را انتخاب کنید</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label class="form-label" for="address_address">آدرس</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="address_address">
                                </div>
                            </div>
                        </div>
                        <input type="hidden" id="save_address_key" value="false">
                        <input type="hidden" id="save_address_user_id" value="">
                        <div class="col-12">
                            <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                <li>
                                    <div id="save_address_form" class="btn btn-primary"
                                         data-bs-dismiss="modal">ثبت آدرس
                                    </div>
                                </li>
                                <li>
                                    <a href="#" class="link link-light" data-bs-dismiss="modal">لغو</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<div class="modal fade zoom" id="addUserAction">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">افزودن فعالیت</h5>
                <a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
            </div>
            <div class="modal-body">
                <form action="#" class="modal_form" data-action="kph_submit_new_action_for_user"
                      data-page="/crm/user">
                    <div class="row g-gs">
                        <div class="col-md-6 hide_on_profile">
                            <div class="form-group card-title">
                                <label class="form-label">ثبت فعالیت برای:</label>
                                <div class="action_customer_box nk-tb-list">
                                    <span class="sub-text">برای انتخاب مشتری لطفا در فیلد روبرو جستجو کنید.</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 hide_on_profile">
                            <div class="form-group card-title search_wrapper">
                                <label class="form-label" for="search_user_actions">جستجوی مشتری</label>
                                <div class="form-control-wrap">
                                    <div class="form-icon form-icon-left"><em class="icon ni ni-user"></em></div>
                                    <input type="text" class="form-control search_user_modal" id="search_user_actions">
                                </div>
                                <p class="mt-1">جهت جستجوی مشتری شماره موبایل و یا نام مشتری را جستجو کنید.</p>
                                <div class="customer_search_result" data-input="#new_action_customer_id"
                                     data-preview=".action_customer_box"></div>
                            </div>
                        </div>
                        <input type="hidden" id="new_action_customer_id" data-for="id">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="new_action_title">عنوان فعالیت</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="new_action_title" data-for="title">
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label">توضیحات</label>
                                <div class="form-control-wrap">
                                    <div class="quill-basic" data-name="new_action_description"
                                         data-for="description" data-req="1">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label">فایل ضمیمه</label>
                                <div class="upload-zone" data-target="#new_action_attachment"
                                     data-action="kph_handle_file_upload" data-max-files="1">
                                    <div class="dz-message" data-dz-message>
                                        <span class="dz-message-text">بکشید و رها کنید</span>
                                        <span class="dz-message-or">یا</span>
                                        <div class="btn btn-primary">انتخاب کنید</div>
                                    </div>
                                </div>
                            </div>
                            <input type="hidden" id="new_action_attachment"
                                   data-for="attachment">
                        </div>
                        <input type="hidden" value="actions" data-for="tab">
                        <div class="col-12">
                            <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                <li>
                                    <div class="btn btn-primary submit_modal_form">ثبت</div>
                                </li>
                                <li>
                                    <a href="#" class="link link-light" data-bs-dismiss="modal">لغو</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
