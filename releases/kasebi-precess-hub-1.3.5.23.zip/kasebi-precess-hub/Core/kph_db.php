<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

require_once __DIR__ . '/kph_visitor_targets.php';
require_once __DIR__ . '/kph_customer_reports.php';
require_once __DIR__ . '/kph_workflow_updates.php';
require_once __DIR__ . '/kph_supplies.php';
require_once __DIR__ . '/kph_supplier_tools.php';
require_once __DIR__ . '/kph_erp_reports.php';
require_once __DIR__ . '/kph_multiwarehouse.php';
require_once __DIR__ . '/kph_order_dates.php';
require_once __DIR__ . '/kph_finance_integrity.php';
require_once __DIR__ . '/kph_customer_freight.php';
require_once __DIR__ . '/kph_customer_proformas.php';
require_once __DIR__ . '/kph_product_weight.php';
require_once __DIR__ . '/kph_hr_calendar.php';
require_once __DIR__ . '/kph_hr_calendar.php';

class kph_db {
	
	use kph_visitor_targets;
    use kph_customer_proformas;
	use kph_customer_reports;
	use kph_workflow_updates;
	use kph_supplies;
	use kph_supplier_tools;
	use kph_multiwarehouse;
    use kph_order_dates;
    use kph_finance_integrity;
	
	private string $db_prefix;
	private string $db_charset;
	private wpdb   $db;
	
	private string $uploaded_files;
	private string $actions_table;
	private string $sms_log;
	
	private string $accounts;
	private string $account_transactions;
	
	private string $raw_categories;
	private string $raw_products;
	
	private string $supplier_invoices;
	private string $supplier_invoice_items;
	
	private string $payments;
	private string $transfers;
	private string $cheques;
	private string $cheque_moves;
	
	private string $batches;
	private string $storage_moves;
	
	private string $processing_packs;
	private string $processing_pack_inputs;
	
	private string $packaging_lots;
	private string $packaging_moves;
	
	private string $shop_conversions;
	private string $inventory_balance;
	private string $inventory_log;
	
	private string $orders;
	private string $order_items;
	private string $fulfillments;
	private string $fulfillment_items;
	
	private string $ledger_entries;
	
	private array $meta_tables;
	private array $meta_aliases;
	
	public function __construct() {
		global $wpdb;
		$this->db         = $wpdb;
		$this->db_prefix  = $this->db->prefix . 'kph_';
		$this->db_charset = 'ENGINE=InnoDB ' . $this->db->get_charset_collate();
		
		$this->uploaded_files = $this->db_prefix . 'uploaded_files';
		$this->actions_table  = $this->db_prefix . 'actions';
		$this->sms_log        = $this->db_prefix . 'sms_log';
		
		$this->accounts             = $this->db_prefix . 'accounts';
		$this->account_transactions = $this->db_prefix . 'account_transactions';
		
		$this->raw_categories = $this->db_prefix . 'raw_categories';
		$this->raw_products   = $this->db_prefix . 'raw_products';
		
		$this->supplier_invoices      = $this->db_prefix . 'supplier_invoices';
		$this->supplier_invoice_items = $this->db_prefix . 'supplier_invoice_items';
		
		$this->payments     = $this->db_prefix . 'payments';
		$this->transfers    = $this->db_prefix . 'transfers';
		$this->cheques      = $this->db_prefix . 'cheques';
		$this->cheque_moves = $this->db_prefix . 'cheque_moves';
		
		$this->batches       = $this->db_prefix . 'batches';
		$this->storage_moves = $this->db_prefix . 'storage_moves';
		
		$this->processing_packs       = $this->db_prefix . 'processing_packs';
		$this->processing_pack_inputs = $this->db_prefix . 'processing_pack_inputs';
		
		$this->packaging_lots  = $this->db_prefix . 'packaging_lots';
		$this->packaging_moves = $this->db_prefix . 'packaging_moves';
		
		$this->shop_conversions  = $this->db_prefix . 'shop_conversions';
		$this->inventory_balance = $this->db_prefix . 'inventory_balance';
		$this->inventory_log     = $this->db_prefix . 'inventory_log';
		
		$this->orders            = $this->db_prefix . 'orders';
		$this->order_items       = $this->db_prefix . 'order_items';
		$this->fulfillments      = $this->db_prefix . 'fulfillments';
		$this->fulfillment_items = $this->db_prefix . 'fulfillment_items';
		
		$this->ledger_entries = $this->db_prefix . 'ledger_entries';
		
		$this->meta_tables = [
			'raw_category' => 'category_id',
			'raw_product'  => 'raw_product_id',
			
			'invoice'      => 'invoice_id',
			'invoice_item' => 'invoice_item_id',
			'payment'      => 'payment_id',
			'transfer'     => 'transfer_id',
			
			'cheque' => 'cheque_id',
			
			'batch'        => 'batch_id',
			'storage_move' => 'move_id',
			
			'processing_pack'       => 'pack_id',
			'processing_pack_input' => 'input_id',
			
			'packaging_lot'  => 'lot_id',
			'packaging_move' => 'move_id',
			
			'shop_conversion'   => 'conversion_id',
			'inventory_balance' => 'inventory_id',
			
			'orders'            => 'order_id',
			'order_items'       => 'order_item_id',
			'fulfillments'      => 'fulfillment_id',
			'fulfillment_items' => 'fulfillment_item_id',
			
			'ledger_entry' => 'entry_id',
			
			'account'             => 'account_id',
			'account_transaction' => 'transaction_id',
			
			'action' => 'action_id',
		];
		
		$this->meta_aliases = [
			'raw_category' => 'raw_categories',
			'raw_product'  => 'raw_products',
			
			'invoice'      => 'supplier_invoices',
			'invoice_item' => 'supplier_invoice_items',
			
			'payment'  => 'payments',
			'transfer' => 'transfers',
			'cheque'   => 'cheques',
			
			'batch'        => 'batches',
			'storage_move' => 'storage_moves',
			
			'processing_pack'       => 'processing_packs',
			'processing_pack_input' => 'processing_pack_inputs',
			
			'packaging_lot'  => 'packaging_lots',
			'packaging_move' => 'packaging_moves',
			
			'shop_conversion'   => 'shop_conversions',
			'inventory_balance' => 'inventory_balances',
			
			'ledger_entry' => 'ledger_entries',
			
			'account'             => 'accounts',
			'account_transaction' => 'account_transactions',
			
			'actions' => 'action',
		];
		
		$this->create_main_table();
	}
	
	public function create_main_table(): void {
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		
		$this->create_production_codes_table();
		$this->create_supply_tables();
		// ===== Core / utility tables (existing)
		maybe_create_table( $this->uploaded_files, $this->get_uploaded_files_table_query() );
		maybe_create_table( $this->actions_table, $this->get_actions_table_query() );
		maybe_create_table( $this->sms_log, $this->get_sms_log_table_query() );
		
		maybe_create_table( $this->accounts, $this->get_accounts_table_query() );
		maybe_create_table( $this->account_transactions, $this->get_account_transactions_table_query() );
		$request_table = $this->db_prefix . 'manual_transaction_requests';
		maybe_create_table( $request_table, "CREATE TABLE {$request_table} (
			request_key CHAR(64) NOT NULL PRIMARY KEY,
			fingerprint CHAR(64) NOT NULL,
			transaction_id BIGINT UNSIGNED NULL
		) {$this->db_charset}" );
		
		// ===== KPH core tables
		maybe_create_table( $this->raw_categories, $this->get_raw_categories_table_query() );
		maybe_create_table( $this->raw_products, $this->get_raw_products_table_query() );
		
		maybe_create_table( $this->supplier_invoices, $this->get_supplier_invoices_table_query() );
		maybe_create_table( $this->supplier_invoice_items, $this->get_supplier_invoice_items_table_query() );
		
		maybe_create_table( $this->payments, $this->get_payments_table_query() );
		maybe_create_table( $this->transfers, $this->get_transfers_table_query() );
		maybe_create_table( $this->cheques, $this->get_cheques_table_query() );
		maybe_create_table( $this->cheque_moves, $this->get_cheque_moves_table_query() );
		
		maybe_create_table( $this->batches, $this->get_batches_table_query() );
		maybe_create_table( $this->storage_moves, $this->get_storage_moves_table_query() );
		
		maybe_create_table( $this->processing_packs, $this->get_processing_packs_table_query() );
		maybe_create_table( $this->processing_pack_inputs, $this->get_processing_pack_inputs_table_query() );
		
		maybe_create_table( $this->packaging_lots, $this->get_packaging_lots_table_query() );
		maybe_create_table( $this->packaging_moves, $this->get_packaging_moves_table_query() );
		
		maybe_create_table( $this->shop_conversions, $this->get_shop_conversions_table_query() );
		maybe_create_table( $this->inventory_balance, $this->get_inventory_balance_table_query() );
		maybe_create_table( $this->inventory_log, $this->get_inventory_log_table_query() );
		$this->create_multiwarehouse_tables();
		$this->create_multiwarehouse_tables();
		
		maybe_create_table( $this->orders, $this->get_orders_table_query() );
		maybe_create_table( $this->order_items, $this->get_order_items_table_query() );
		maybe_create_table( $this->fulfillments, $this->get_fulfillments_table_query() );
		maybe_create_table( $this->fulfillment_items, $this->get_fulfillment_items_table_query() );
		
		maybe_create_table( $this->ledger_entries, $this->get_ledger_entries_table_query() );
		
		// ===== Meta tables (generic)
		foreach ( $this->meta_tables as $base => $foreign_key ) {
			$table = $this->db_prefix . $base . '_meta';
			$sql   = $this->get_meta_table_sql( $table, $foreign_key );
			maybe_create_table( $table, $sql );
		}
	}
	
	/** ---------- Table queries ---------- */
	
	private function get_uploaded_files_table_query(): string {
		return <<<SQL
			CREATE TABLE $this->uploaded_files (
				id MEDIUMINT NOT NULL AUTO_INCREMENT,
				user_id MEDIUMINT NOT NULL,
				original_name VARCHAR(255) NOT NULL,
				saved_name VARCHAR(255) NOT NULL,
				file_url TEXT NOT NULL,
				file_path TEXT NOT NULL,
				file_ext VARCHAR(20) NOT NULL,
				ip_address VARCHAR(45) DEFAULT NULL,
				uploaded_at DATETIME NOT NULL,
				PRIMARY KEY (id)
			) $this->db_charset;
		SQL;
	}
	
	private function get_actions_table_query(): string {
		return <<< SQL
			create table $this->actions_table (
			    id MEDIUMINT not null AUTO_INCREMENT,
			    user_id MEDIUMINT not null,
			    title TEXT not null,
			    content TEXT not null,
			    date datetime not null,
			    creator MEDIUMINT not null,
			    PRIMARY KEY (id)
			) $this->db_charset;
		SQL;
	}
	
	private function get_sms_log_table_query(): string {
		return <<< SQL
			create table $this->sms_log (
			    log_id MEDIUMINT not null AUTO_INCREMENT,
			    sender MEDIUMINT not null,
			    user_id MEDIUMINT not null,
			    content TEXT not null,
			    response TEXT not null,
			    date datetime not null,
			    PRIMARY KEY (log_id)
			) $this->db_charset;
		SQL;
	}
	
	private function get_accounts_table_query(): string {
		return <<< SQL
			create table $this->accounts (
			    id MEDIUMINT not null AUTO_INCREMENT,
			    title VARCHAR(190) NOT NULL,
			    type VARCHAR(20) NOT NULL DEFAULT 'bank',
			    bank_name VARCHAR(100) NULL,
			    owner_name VARCHAR(100) NULL,
			    account_no VARCHAR(100) NULL,
			    balance BIGINT NOT NULL DEFAULT 0,
			    status VARCHAR(20) NOT NULL DEFAULT 'active',
			    created_by BIGINT UNSIGNED NULL,
				created_at DATETIME NOT NULL,
				updated_at DATETIME NULL,
			    
			    PRIMARY KEY (id)
			) $this->db_charset;
		SQL;
	}
	
	private function get_account_transactions_table_query(): string {
		return <<< SQL
			create table $this->account_transactions  (
			    id MEDIUMINT not null AUTO_INCREMENT,
			    account_id MEDIUMINT NOT NULL,
				amount BIGINT NOT NULL,
				type VARCHAR(10) NOT NULL,
				action VARCHAR(50) NOT NULL,
				balance_after BIGINT NOT NULL,
				description TEXT NULL,
			    created_by BIGINT UNSIGNED NULL,
				created_at DATETIME NOT NULL,
			    
			    PRIMARY KEY (id)
			) $this->db_charset;
		SQL;
	}
	
	private function get_raw_categories_table_query(): string {
		return <<<SQL
		CREATE TABLE {$this->raw_categories} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			parent_id BIGINT UNSIGNED NULL,
			title VARCHAR(190) NOT NULL,
			sort_order INT UNSIGNED NOT NULL DEFAULT 0,
			is_active TINYINT(1) NOT NULL DEFAULT 1,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NULL,
			PRIMARY KEY (id),
			KEY parent_id (parent_id),
			KEY sort_order (sort_order)
		) $this->db_charset;
	SQL;
	}
	
	private function get_raw_products_table_query(): string {
		return <<<SQL
		CREATE TABLE {$this->raw_products} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			category_id BIGINT UNSIGNED NOT NULL,
			title VARCHAR(190) NOT NULL,
			code VARCHAR(64) NULL,
			base_uom VARCHAR(16) NOT NULL DEFAULT 'kg',
			is_active TINYINT(1) NOT NULL DEFAULT 1,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NULL,
			PRIMARY KEY (id),
			UNIQUE KEY uq_code (code),
			KEY category_id (category_id),
			KEY title (title)
		) $this->db_charset;
	SQL;
	}
	
	private function get_supplier_invoices_table_query(): string {
		return <<<SQL
		CREATE TABLE {$this->supplier_invoices} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			supplier_user_id BIGINT UNSIGNED NOT NULL,
			invoice_no VARCHAR(64) NULL,
			status ENUM('proforma','confirmed','settled','canceled') NOT NULL DEFAULT 'proforma',
			issued_at DATETIME NOT NULL,
			confirmed_at DATETIME NULL,
			settled_at DATETIME NULL,
			total_amount DECIMAL(18,2) NOT NULL DEFAULT 0,
			currency VARCHAR(8) NOT NULL DEFAULT 'IRR',
			note TEXT NULL,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NULL,
			PRIMARY KEY (id),
			UNIQUE KEY uq_invoice_no (invoice_no),
			KEY supplier_user_id (supplier_user_id),
			KEY status (status)
		) $this->db_charset;
	SQL;
	}
	
	private function get_supplier_invoice_items_table_query(): string {
		return <<<SQL
		CREATE TABLE {$this->supplier_invoice_items} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			invoice_id BIGINT UNSIGNED NOT NULL,
			raw_product_id BIGINT UNSIGNED NOT NULL,
			qty_weight DECIMAL(18,6) NOT NULL,
			unit_price DECIMAL(18,2) NOT NULL,
			line_total DECIMAL(18,2) NOT NULL,
			note TEXT NULL,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NULL,
			PRIMARY KEY (id),
			KEY invoice_id (invoice_id),
			KEY raw_product_id (raw_product_id)
		) $this->db_charset;
	SQL;
	}
	
	private function get_payments_table_query(): string {
		return <<<SQL
		CREATE TABLE {$this->payments} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			user_id BIGINT UNSIGNED NULL,
			amount BIGINT NULL,
			payment_method ENUM('cash','pos','card_to_card','online','other') NOT NULL DEFAULT 'other',
			paid_at DATETIME NOT NULL,
			note TEXT NULL,
			ref_id BIGINT UNSIGNED NULL,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NULL,
			PRIMARY KEY (id),
			KEY user_id (user_id),
			KEY paid_at (paid_at)
		) $this->db_charset;
	SQL;
	}
	
	private function get_transfers_table_query(): string {
		return <<<SQL
		CREATE TABLE {$this->transfers} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			user_id BIGINT UNSIGNED NULL,
			amount DECIMAL(18,2) NOT NULL,
			bank_name VARCHAR(120) NULL,
			tracking_no VARCHAR(120) NULL,
			transferred_at DATETIME NOT NULL,
			ref_id BIGINT UNSIGNED NULL,
			note TEXT NULL,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NULL,
			PRIMARY KEY (id),
			KEY user_id (user_id),
			KEY transferred_at (transferred_at),
			KEY tracking_no (tracking_no)
		) $this->db_charset;
	SQL;
	}
	
	private function get_cheques_table_query(): string {
		return <<<SQL
		CREATE TABLE {$this->cheques} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			user_id BIGINT UNSIGNED NULL,
			cheque_no VARCHAR(64) NOT NULL,
			sayad_id VARCHAR(64) NULL,
			bank_name VARCHAR(120) NULL,
			amount DECIMAL(18,2) NOT NULL,
			currency VARCHAR(8) NOT NULL DEFAULT 'IRR',
			due_at DATE NOT NULL,
			status ENUM('in_hand','endorsed','cleared','bounced','canceled') NOT NULL DEFAULT 'in_hand',
			issuer_user_id BIGINT UNSIGNED NULL,
			current_holder_user_id BIGINT UNSIGNED NULL,
			note TEXT NULL,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NULL,
			PRIMARY KEY (id),
			UNIQUE KEY uq_cheque_no (cheque_no),
			KEY status (status),
			KEY due_at (due_at),
			KEY issuer_user_id (issuer_user_id),
			KEY current_holder_user_id (current_holder_user_id)
		) $this->db_charset;
	SQL;
	}
	
	private function get_cheque_moves_table_query(): string {
		return <<<SQL
			CREATE TABLE {$this->cheque_moves} (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				cheque_id BIGINT UNSIGNED NOT NULL,
				actor_user_id BIGINT UNSIGNED NULL,
				holder_user_id BIGINT UNSIGNED NULL,
				action ENUM('receive','endorse','return','clear','bounce','cancel','note') NOT NULL DEFAULT 'note',
				status_from ENUM('in_hand','endorsed','cleared','bounced','canceled') NULL,
				status_to ENUM('in_hand','endorsed','cleared','bounced','canceled') NULL,
				note TEXT NULL,
				created_at DATETIME NOT NULL,
				PRIMARY KEY (id)
			) $this->db_charset;
		SQL;
	}
	
	private function get_batches_table_query(): string {
		return <<<SQL
		CREATE TABLE {$this->batches} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			raw_product_id BIGINT UNSIGNED NOT NULL,
			source_type ENUM('supplier_invoice_item','processing_return','packaging_return','manual') NOT NULL,
			source_id BIGINT UNSIGNED NULL,
			initial_qty_weight DECIMAL(18,6) NOT NULL,
			unit_cost DECIMAL(18,2) NOT NULL,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NULL,
			PRIMARY KEY (id),
			KEY raw_product_id (raw_product_id),
			KEY source_type (source_type),
			KEY source_id (source_id)
		) $this->db_charset;
	SQL;
	}
	
	private function get_storage_moves_table_query(): string {
		return <<<SQL
		CREATE TABLE {$this->storage_moves} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			batch_id BIGINT UNSIGNED NOT NULL,
			direction ENUM('in','out') NOT NULL,
			reason ENUM('purchase_in','processing_out','processing_return','waste','adjustment') NOT NULL,
			qty_weight DECIMAL(18,6) NOT NULL,
			unit_cost_at_move DECIMAL(18,2) NOT NULL,
			ref_type VARCHAR(64) NULL,
			ref_id BIGINT UNSIGNED NULL,
			note TEXT NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			KEY batch_id (batch_id),
			KEY reason (reason),
			KEY created_at (created_at),
			KEY ref_type_ref_id (ref_type, ref_id)
		) $this->db_charset;
	SQL;
	}
	
	private function get_processing_packs_table_query(): string {
		return <<<SQL
		CREATE TABLE {$this->processing_packs} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			status ENUM('open','closed','transferred_to_packaging') NOT NULL DEFAULT 'open',
			total_qty_weight DECIMAL(18,6) NOT NULL DEFAULT 0,
			total_cost DECIMAL(18,2) NOT NULL DEFAULT 0,
			avg_unit_cost DECIMAL(18,2) NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NULL,
			PRIMARY KEY (id),
			KEY status (status),
			KEY created_at (created_at)
		) $this->db_charset;
	SQL;
	}
	
	private function get_processing_pack_inputs_table_query(): string {
		return <<<SQL
		CREATE TABLE {$this->processing_pack_inputs} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			pack_id BIGINT UNSIGNED NOT NULL,
			batch_id BIGINT UNSIGNED NOT NULL,
			qty_weight DECIMAL(18,6) NOT NULL,
			unit_cost DECIMAL(18,2) NOT NULL,
			line_cost DECIMAL(18,2) NOT NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			KEY pack_id (pack_id),
			KEY batch_id (batch_id)
		) $this->db_charset;
	SQL;
	}
	
	private function get_packaging_lots_table_query(): string {
		return <<<SQL
		CREATE TABLE {$this->packaging_lots} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			processing_pack_id BIGINT UNSIGNED NOT NULL,
			input_qty_weight DECIMAL(18,6) NOT NULL,
			avg_unit_cost DECIMAL(18,2) NOT NULL,
			status ENUM('in_packaging','closed') NOT NULL DEFAULT 'in_packaging',
			created_at DATETIME NOT NULL,
			updated_at DATETIME NULL,
			PRIMARY KEY (id),
			KEY processing_pack_id (processing_pack_id),
			KEY status (status)
		) $this->db_charset;
	SQL;
	}
	
	private function get_packaging_moves_table_query(): string {
		return <<<SQL
		CREATE TABLE {$this->packaging_moves} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			packaging_lot_id BIGINT UNSIGNED NOT NULL,
			direction ENUM('in','out') NOT NULL,
			reason ENUM('from_processing','waste','return_to_processing','convert_to_shop_product','adjustment') NOT NULL,
			qty_weight DECIMAL(18,6) NOT NULL,
			ref_type VARCHAR(64) NULL,
			ref_id BIGINT UNSIGNED NULL,
			note TEXT NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			KEY packaging_lot_id (packaging_lot_id),
			KEY reason (reason),
			KEY created_at (created_at),
			KEY ref_type_ref_id (ref_type, ref_id)
		) $this->db_charset;
	SQL;
	}
	
	private function get_shop_conversions_table_query(): string {
		return <<<SQL
		CREATE TABLE {$this->shop_conversions} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			packaging_lot_id BIGINT UNSIGNED NOT NULL,
			wc_product_id BIGINT UNSIGNED NOT NULL,
			qty_items INT UNSIGNED NOT NULL,
			weight_per_item DECIMAL(18,6) NOT NULL,
			packaging_cost_per_item DECIMAL(18,2) NOT NULL DEFAULT 0,
			unique_product_code VARCHAR(64) NOT NULL,
			avg_cost_from_processing DECIMAL(18,2) NOT NULL,
			total_material_cost DECIMAL(18,2) NOT NULL,
			total_packaging_cost DECIMAL(18,2) NOT NULL,
			total_cost DECIMAL(18,2) NOT NULL,
			unit_cost_final DECIMAL(18,2) NOT NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			KEY packaging_lot_id (packaging_lot_id),
			KEY wc_product_id (wc_product_id)
		) $this->db_charset;
	SQL;
	}
	
	private function get_inventory_balance_table_query(): string {
		return <<<SQL
		CREATE TABLE {$this->inventory_balance} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			unique_product_code VARCHAR(64) NOT NULL,
			wc_product_id BIGINT UNSIGNED NOT NULL,
			qty_available DECIMAL(20,5) NOT NULL DEFAULT 0,
			inventory_value DECIMAL(18,2) NOT NULL DEFAULT 0,
			avg_unit_cost DECIMAL(18,6) NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY unique_product_code (unique_product_code),
			KEY wc_product_id (wc_product_id)
		) {$this->db_charset};
	SQL;
	}
	
	private function get_inventory_log_table_query(): string {
		return <<<SQL
		CREATE TABLE {$this->inventory_log} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			unique_product_code VARCHAR(64) NOT NULL,
			wc_product_id BIGINT UNSIGNED NOT NULL,
			change_qty DECIMAL(20,5) NOT NULL,
			unit_cost DECIMAL(18,6) NOT NULL DEFAULT 0,
			total_cost DECIMAL(18,2) NOT NULL DEFAULT 0,
			ref_type VARCHAR(50) NOT NULL,      -- production | sale | return | adjust | waste
			ref_id BIGINT UNSIGNED NOT NULL,
			note VARCHAR(255) NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			KEY unique_product_code (unique_product_code),
			KEY wc_product_id (wc_product_id),
			KEY ref_type (ref_type),
			KEY ref_id (ref_id),
			KEY created_at (created_at)
		) {$this->db_charset};
	SQL;
	}
	
	private function get_orders_table_query(): string {
		return <<<SQL
		CREATE TABLE {$this->orders} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			order_number VARCHAR(32) NOT NULL,
			status VARCHAR(32) NOT NULL DEFAULT 'proforma',
			customer_id BIGINT UNSIGNED NULL,
			created_by BIGINT UNSIGNED NOT NULL,
			currency CHAR(3) NOT NULL DEFAULT 'IRR',
			items_subtotal DECIMAL(18,2) NOT NULL DEFAULT 0,
			discount_cash_total DECIMAL(18,2) NOT NULL DEFAULT 0,
			total_payable DECIMAL(18,2) NOT NULL DEFAULT 0,
			total_ordered_qty DECIMAL(20,5) NOT NULL DEFAULT 0,
			total_expected_free_qty INT NOT NULL DEFAULT 0,
			total_shipped_qty INT NOT NULL DEFAULT 0,
			registered_at DATETIME NULL,
			shipped_at DATETIME NULL,
			note TEXT NULL,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			UNIQUE KEY order_number (order_number),
			KEY status (status),
			KEY customer_id (customer_id),
			KEY created_at (created_at)
		) {$this->db_charset};
	SQL;
	}
	
	private function get_order_items_table_query(): string {
		return <<<SQL
		CREATE TABLE {$this->order_items} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			order_id BIGINT UNSIGNED NOT NULL,
			inventory_id BIGINT UNSIGNED NOT NULL,
			unique_product_code VARCHAR(64) NOT NULL,
			wc_product_id BIGINT UNSIGNED NOT NULL,
			base_price DECIMAL(18,2) NOT NULL DEFAULT 0,
			qty_ordered DECIMAL(20,5) NOT NULL,
			discount_cash_type ENUM('none','percent','amount') NOT NULL DEFAULT 'none',
			discount_cash_value DECIMAL(18,6) NOT NULL DEFAULT 0,
			discount_cash_amount DECIMAL(18,2) NOT NULL DEFAULT 0,
			goods_buy_x INT NOT NULL DEFAULT 0,
			goods_free_y INT NOT NULL DEFAULT 0,
			expected_free_qty INT NOT NULL DEFAULT 0,
			final_amount DECIMAL(18,2) NOT NULL DEFAULT 0,
			shipped_paid_qty DECIMAL(20,5) NOT NULL DEFAULT 0,
			shipped_free_qty INT NOT NULL DEFAULT 0,
			cogs_total DECIMAL(18,2) NOT NULL DEFAULT 0,
			note TEXT NULL,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			KEY order_id (order_id),
			KEY inventory_id (inventory_id),
			KEY unique_product_code (unique_product_code),
			KEY wc_product_id (wc_product_id)
		) {$this->db_charset};
	SQL;
	}
	
	private function get_fulfillments_table_query(): string {
		return <<<SQL
		CREATE TABLE {$this->fulfillments} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			order_id BIGINT UNSIGNED NOT NULL,
			status VARCHAR(32) NOT NULL DEFAULT 'draft',
			shipped_by BIGINT UNSIGNED NULL,
			shipped_at DATETIME NULL,
			note TEXT NULL,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			KEY order_id (order_id),
			KEY status (status),
			KEY shipped_at (shipped_at)
		) {$this->db_charset};
	SQL;
	}
	
	private function get_fulfillment_items_table_query(): string {
		return <<<SQL
		CREATE TABLE {$this->fulfillment_items} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			fulfillment_id BIGINT UNSIGNED NOT NULL,
			order_item_id BIGINT UNSIGNED NOT NULL,
			inventory_id BIGINT UNSIGNED NOT NULL,
			shipped_paid_qty DECIMAL(20,5) NOT NULL DEFAULT 0,
			shipped_free_qty INT NOT NULL DEFAULT 0,
			unit_cost DECIMAL(18,6) NOT NULL DEFAULT 0,
			total_cost DECIMAL(18,2) NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			KEY fulfillment_id (fulfillment_id),
			KEY order_item_id (order_item_id),
			KEY inventory_id (inventory_id)
		) {$this->db_charset};
	SQL;
	}
	
	private function get_ledger_entries_table_query(): string {
		return <<<SQL
		CREATE TABLE {$this->ledger_entries} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			user_id BIGINT(20) UNSIGNED NOT NULL,
			entry_type VARCHAR(64) NOT NULL,
			type ENUM('debit','credit') NOT NULL,
			amount DECIMAL(18,2) NOT NULL,
			party_user_id BIGINT UNSIGNED NULL,
			ref_type VARCHAR(64) NOT NULL,
			ref_id BIGINT UNSIGNED NOT NULL,
			posted_at DATETIME NOT NULL,
			note TEXT NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			KEY user_id (user_id),
			KEY entry_type (entry_type),
			KEY posted_at (posted_at),
			KEY ref_type_ref_id (ref_type, ref_id)
		) $this->db_charset;
	SQL;
	}
	
	private function get_meta_table_sql( string $table, string $foreign_key ): string {
		return <<<SQL
			CREATE TABLE {$table} (
				id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				{$foreign_key} BIGINT UNSIGNED NOT NULL,
				meta_key   VARCHAR(191) NOT NULL,
				meta_value LONGTEXT NULL,
				PRIMARY KEY (id),
				KEY meta_key_idx ({$foreign_key}, meta_key)
			) {$this->db_charset};
			SQL;
	}
	
	/** ---------- Helpers ---------- */
	
	private function now(): string {
		return current_time( 'mysql' );
	}
	
	private function ok( string $msg = '', $data = NULL ): array {
		return [ 'status' => 'success', 'message' => $msg, 'data' => $data ];
	}
	
	private function fail( string $msg, $data = NULL ): array {
		return [ 'status' => 'error', 'message' => $msg, 'data' => $data ];
	}
	
	/** ---------- Options ---------- */
	
	public function get_introduce_methods(): array {
		$methods = get_option( 'kph_introduce_methods', [] );
		
		if ( empty( $methods ) || ! is_array( $methods ) ) {
			$methods = [
				'website'   => [
					'label' => 'وب‌سایت',
				],
				'instagram' => [
					'label' => 'اینستاگرام',
				],
				'referral'  => [
					'label' => 'معرفی دوستان',
				],
				'sms'       => [
					'label' => 'پیامک',
				],
				'other'     => [
					'label' => 'سایر',
				],
			];
			update_option( 'kph_introduce_methods', $methods );
		}
		
		return $methods;
	}
	
	public function get_customer_levels(): array {
		return [
			'level_a'   => [
				'label' => 'سطح A',
				'class' => 'gray',
			],
			'level_a_p' => [
				'label' => 'سطح A+',
				'class' => 'warning',
			],
			'level_b'   => [
				'label' => 'سطح B',
				'class' => 'info',
			],
			'level_b_p' => [
				'label' => 'سطح B+',
				'class' => 'success',
			],
		];
	}
	
	public function get_marketers(): array {
		$employees = get_users( [
			'fields'   => 'ids',
			'orderby'  => 'ID',
			'order'    => 'DESC',
			'role__in' => [ 'visitor' ],
		] );
		$list      = [];
		foreach ( $employees as $user_id ) {
			$list[ $user_id ] = [
				'label' => get_user_name_by_id( $user_id ),
			];
		}
		
		return $list;
	}
	
	public function get_customer_activity(): array {
		$departments = get_option( 'kph_user_work_type', [] );
		
		return $departments;
	}
	
	public function get_customer_business_model(): array {
		return [
			'agent'        => [
				'label' => 'نماینده',
			],
			'sales-agency' => [
				'label' => 'عاملیت فروش',
			],
			'others'       => [
				'label' => 'متفرقه',
			],
		];
	}
	
	public function get_user_meta_list(): array {
		return [
			'customer_person_type' => [
				'type'    => 'select',
				'label'   => 'نوع شخص',
				'default' => 'individual',
				'options' => [
					'individual' => [ 'label' => 'اشخاص حقیقی' ],
					'legal'      => [ 'label' => 'شرکت حقوقی (اشخاص حقوقی)' ],
				],
			],
			'national_id'          => [
				'type'  => 'text',
				'label' => 'شناسه ملی',
			],
			'economic_code'        => [
				'type'       => 'text',
				'label'      => 'کد اقتصادی',
				'state'      => 'conditional',
				'conditions' => [
					'meta'     => 'customer_person_type',
					'value'    => 'legal',
					'operator' => '!=',
				],
			],
			'birthday'             => [
				'type'  => 'date',
				'label' => 'تاریخ تولد',
			],
			'customer_category'    => [
				'type'    => 'select',
				'label'   => 'دسته بندی مشتری',
				'options' => [ '0' => 'بدون دسته' ] + get_option( 'kph_user_category' ) ?: [],
				'width'   => '4',
			],
			'customer_marketer'    => [
				'type'    => 'select',
				'label'   => 'بازاریاب',
				'options' => [ '0' => 'بدون بازاریاب' ] + $this->get_marketers(),
				'width'   => '4',
			],
			'customer_level'       => [
				'type'    => 'select',
				'label'   => 'سطح مشتری',
				'options' => [ '0' => 'بدون سطح' ] + $this->get_customer_levels(),
				'width'   => '4',
			],
			'customer_activity'    => [
				'type'    => 'select',
				'label'   => 'فعالیت مشتری',
				'options' => $this->get_customer_activity(),
				'width'   => '4',
			],
			'business_model'       => [
				'type'    => 'select',
				'label'   => 'مدل کسب‌وکار',
				'options' => $this->get_customer_business_model(),
				'width'   => '4',
			],
			'purchasing_phone'     => [
				'label' => 'شماره مسئول خرید',
			],
			'purchasing_name'      => [
				'label' => 'نام مسئول خرید',
			],
			'accountant_phone'     => [
				'label' => 'شماره حسابدار',
			],
			'accountant_name'      => [
				'label' => 'نام حسابدار',
			],
			'distributor_name'     => [
				'label' => 'نام پخش',
				'width' => '12',
			],
			'state_id'             => [
				'type'    => 'select',
				'label'   => 'استان',
				'options' => WC()->countries->get_states( 'IR' ),
				'class'   => 'load_city',
				'target'  => '#new_customer_city_id',
				'width'   => '4',
			],
			'city_id'              => [
				'type'    => 'select',
				'label'   => 'شهر',
				'options' => [
					'0' => 'ابتدا استان را انتخاب کنید',
				],
				'width'   => '4',
			],
			'postal_code'          => [
				'label' => 'کد پستی',
				'width' => '4',
			],
			'address'              => [
				'label' => 'آدرس',
				'width' => '12',
			],
		];
	}
	
	public function get_supplier_invoice_statuses(): array {
		return [
			'proforma'  => [
				'label' => 'پیش‌فاکتور',
				'class' => 'warning',
			],
			'confirmed' => [
				'label' => 'تایید شده',
				'class' => 'info',
			],
			'settled'   => [
				'label' => 'تسویه شده',
				'class' => 'success',
			],
            'canceled' => ['label'=>'باطل‌شده','class'=>'danger'],
		];
	}
	
	public function get_processing_packs_statuses(): array {
		return [
			'open'                     => [
				'label' => 'آماده ارسال به سالن',
				'class' => 'success',
			],
			'transferred_to_packaging' => [
				'label' => 'در سالن بسته‌بندی',
				'class' => 'warning',
			],
			'closed'                   => [
				'label' => 'اتمام تولید',
				'class' => 'gray',
			],
		];
	}
	
	public function get_processing_lot_statuses(): array {
		return [
			'in_packaging' => [
				'label' => 'آماده بسته بندی',
				'class' => 'success',
			],
			'closed'       => [
				'label' => 'اتمام‌یافته',
				'class' => 'gray',
			],
		];
	}
	
	public function get_storage_move_directions(): array {
		return [
			'in'  => [
				'label' => 'ورود',
				'class' => 'bg-success',
			],
			'out' => [
				'label' => 'خروج',
				'class' => 'bg-danger',
			],
		];
	}
	
	public function get_storage_move_reasons(): array {
		return [
			'purchase_in'       => [
				'label' => 'ورود از فاکتور تامین‌کننده',
				'class' => 'bg-success',
			],
			'processing_out'    => [
				'label' => 'انتقال به فرآوری',
				'class' => 'bg-warning',
			],
			'processing_return' => [
				'label' => 'بازگشت از فرآوری',
				'class' => 'label-soft bg-info',
			],
			'waste'             => [
				'label' => 'هدر رفت / وزن در رو',
				'class' => 'bg-danger',
			],
			'adjustment'        => [
				'label' => 'اصلاح موجودی',
				'class' => 'bg-gray',
			],
		];
	}
	
	public function get_processing_pack_statuses(): array {
		return [
			'open'                     => [
				'label' => 'باز',
				'class' => 'bg-warning',
			],
			'closed'                   => [
				'label' => 'بسته',
				'class' => 'bg-success',
			],
			'transferred_to_packaging' => [
				'label' => 'انتقال به سالن بسته‌بندی',
				'class' => 'bg-info',
			],
		];
	}
	
	public function get_packaging_lot_statuses(): array {
		return [
			'in_packaging' => [
				'label' => 'در سالن بسته‌بندی',
				'class' => 'bg-warning',
			],
			'closed'       => [
				'label' => 'بسته شده',
				'class' => 'bg-success',
			],
		];
	}
	
	public function get_packaging_move_directions(): array {
		return [
			'in'  => [
				'label' => 'ورود',
				'class' => 'bg-success',
			],
			'out' => [
				'label' => 'خروج',
				'class' => 'bg-danger',
			],
		];
	}
	
	public function get_packaging_move_reasons(): array {
		return [
			'from_processing'         => [
				'label' => 'ورود از فرآوری',
				'class' => 'bg-success',
			],
			'waste'                   => [
				'label' => 'هدر رفت',
				'class' => 'bg-danger',
			],
			'return_to_processing'    => [
				'label' => 'بازگشت به فرآوری',
				'class' => 'bg-warning',
			],
			'convert_to_shop_product' => [
				'label' => 'تبدیل به محصول فروشگاهی',
				'class' => 'bg-info',
			],
			'adjustment'              => [
				'label' => 'اصلاح',
				'class' => 'bg-gray',
			],
		];
	}
	
	public function get_payment_methods(): array {
		return [
			'cash'         => [
				'label' => 'نقدی',
				'class' => 'bg-success',
			],
			'pos'          => [
				'label' => 'کارتخوان',
				'class' => 'bg-info',
			],
			'card_to_card' => [
				'label' => 'کارت به کارت',
				'class' => 'bg-warning',
			],
			'online'       => [
				'label' => 'آنلاین',
				'class' => 'bg-primary',
			],
			'other'        => [
				'label' => 'سایر',
				'class' => 'bg-gray',
			],
            'customer_freight' => ['label'=>'کرایه مشتریان','class'=>'bg-info'],
		];
	}
	
	public function get_ledger_entry_types(): array {
		return [
            'customer_freight' => ['label'=>'کرایه مشتریان — پرداختی','class'=>'bg-success'],
			'shipping_freight' => [ 'label' => 'کرایه مشتری — هزینه با شرکت', 'class' => 'bg-success' ],
			'shipping_freight_reversal' => [ 'label' => 'برگشت کرایه ارسال', 'class' => 'bg-warning' ],
			'hr_payslip' => [ 'label' => 'حقوق پرسنل', 'class' => 'bg-primary' ],
			'hr_settlement' => [ 'label' => 'مزایای تسویه پرسنل', 'class' => 'bg-info' ],
			'hr_payment' => [ 'label' => 'پرداخت پرسنل', 'class' => 'bg-success' ],
			'hr_reversal' => [ 'label' => 'برگشت ثبت کارگزینی', 'class' => 'bg-warning' ],
			'supplier_invoice_cancel' => ['label'=>'ابطال فاکتور تأمین‌کننده','class'=>'bg-warning'],
            'supplier_invoice_confirm'    => [
				'label' => 'تایید فاکتور تامین‌کننده',
				'class' => 'bg-info',
			],
			'customer_order'              => [
				'label' => 'ارسال سفارش',
				'class' => 'bg-info',
			],
			'customer_order_return'       => [
				'label' => 'برگشت از فروش (اصلاح بدهی)',
				'class' => 'bg-warning',
			],
			'visitor_target_bonus'        => [ 'label' => 'پاداش تحقق تارگت', 'class' => 'bg-success' ],
			'visitor_target_reversal'     => [ 'label' => 'برگشت پاداش تارگت', 'class' => 'bg-danger' ],
			'visitor_commission'          => [
				'label' => 'پورسانت فروش',
				'class' => 'bg-success',
			],
			'visitor_commission_reversal' => [
				'label' => 'برگشت پورسانت',
				'class' => 'bg-danger',
			],
			'submit_payment'              => [
				'label' => 'ثبت پرداختی',
				'class' => 'bg-success',
			],
			'submit_transfer'             => [
				'label' => 'ثبت حواله',
				'class' => 'bg-success',
			],
			'cheque_receive'              => [
				'label' => 'دریافت چک',
				'class' => 'bg-warning',
			],
			'cheque_endorse'              => [
				'label' => 'واگذاری چک',
				'class' => 'bg-info',
			],
			'cheque_clear'                => [
				'label' => 'وصول چک',
				'class' => 'bg-success',
			],
			'cheque_bounce'               => [
				'label' => 'برگشت چک',
				'class' => 'bg-danger',
			],
			'packaging_cost'              => [
				'label' => 'هزینه بسته‌بندی',
				'class' => 'bg-primary',
			],
			'adjustment'                  => [
				'label' => 'اصلاح/تعدیل',
				'class' => 'bg-gray',
			],
		];
	}
	
	public function get_ledger_sides(): array {
		return [
			'debit'  => [
				'label' => 'بدهکار',
				'class' => 'bg-danger',
			],
			'credit' => [
				'label' => 'بستانکار',
				'class' => 'bg-success',
			],
		];
	}
	
	public function get_cheque_statuses(): array {
		return [
			'in_hand'  => [
				'label' => 'در اختیار',
				'class' => 'bg-warning',
			],
			'endorsed' => [
				'label' => 'واگذارشده',
				'class' => 'bg-info',
			],
			'cleared'  => [
				'label' => 'وصول شده',
				'class' => 'bg-success',
			],
			'bounced'  => [
				'label' => 'برگشتی',
				'class' => 'bg-danger',
			],
			'canceled' => [
				'label' => 'ابطال شده',
				'class' => 'bg-gray',
			],
		];
	}
	
	public function get_order_statuses(): array {
		return [
			'proforma'   => [
				'label' => 'پیش‌فاکتور',
				'class' => 'warning',
			],
			'registered' => [
				'label' => 'ثبت شده',
				'class' => 'info',
			],
			'shortage'   => [
				'label' => 'دارای کسری',
				'class' => 'danger',
			],
			'shipped'    => [
				'label' => 'ارسال کامل',
				'class' => 'success',
			],
			'returned'   => [
				'label' => 'مرجوع‌شده کامل',
				'class' => 'warning',
			],
			'canceled'   => [
				'label' => 'لغوشده',
				'class' => 'secondary',
			],
		];
	}
	
	public function get_fulfillment_statuses(): array {
		return [
			'draft'    => [
				'label' => 'ارسال شده',
				'class' => 'success',
			],
			'canceled' => [
				'label' => 'لغو',
				'class' => 'warning',
			],
		];
	}
	
	public function get_account_types(): array {
		return [
			'bank'    => [
				'label' => 'حساب بانکی',
				'class' => 'bg-warning',
			],
			'cash'    => [
				'label' => 'حساب نقدی',
				'class' => 'bg-info',
			],
			'expense' => [
				'label' => 'حساب هزینه',
				'class' => 'bg-danger',
			],
		];
	}
	
	public function get_batch_source_types(): array {
		return [
			'supplier_invoice_item' => [
				'label' => 'ورودی از فاکتور تامین‌کننده',
				'class' => 'bg-success',
			],
			'processing_return'     => [
				'label' => 'بازگشت از فرآوری',
				'class' => 'bg-info',
			],
			'packaging_return'      => [
				'label' => 'بازگشت از بسته‌بندی',
				'class' => 'bg-warning',
			],
			'manual'                => [
				'label' => 'ثبت دستی',
				'class' => 'bg-gray',
			],
		];
	}
	
	/** ---------- Meta API (generic) ---------- */
	public function get_meta( string $context, int $object_id, string $meta_key = '', bool $single = FALSE ) {
		[ $table, $fk ] = $this->resolve_meta_table( $context );
		if ( ! $table ) {
			return $single ? NULL : [];
		}
		
		$hide_admin_note = $table === $this->db_prefix . 'cheque_meta' && ! current_user_can( 'manage_options' );
		if ( $hide_admin_note && in_array( strtolower( rtrim( $meta_key ) ), [ 'admin_note', 'admin_note_print' ], TRUE ) ) {
			return $single ? NULL : [];
		}
		if ( $meta_key !== '' ) {
			$sql  = $this->db->prepare(
				"SELECT meta_value FROM {$table} WHERE {$fk}=%d AND meta_key=%s",
				$object_id,
				$meta_key
			);
			$rows = $this->db->get_col( $sql );
			if ( $single ) {
				return $rows ? maybe_unserialize( $rows[0] ) : NULL;
			}
			
			return array_map( 'maybe_unserialize', $rows );
		}
		
		$sql  = $this->db->prepare( "SELECT meta_key, meta_value FROM {$table} WHERE {$fk}=%d", $object_id );
		$rows = $this->db->get_results( $sql, ARRAY_A );
		$out  = [];
		foreach ( $rows as $r ) {
			if ( $hide_admin_note && in_array( strtolower( rtrim( $r['meta_key'] ) ), [ 'admin_note', 'admin_note_print' ], TRUE ) ) {
				continue;
			}
			$out[ $r['meta_key'] ][] = maybe_unserialize( $r['meta_value'] );
		}
		
		return $out;
	}
	
	public function save_meta_batch( string $context, int $object_id, array $pairs, bool $unique = TRUE ): array {
		[ $table, $fk ] = $this->resolve_meta_table( $context );
		if ( ! $table ) {
			return $this->fail( 'Invalid meta context.' );
		}
		if ( $table === $this->db_prefix . 'cheque_meta' && ! current_user_can( 'manage_options' ) ) {
			$pairs = array_filter( $pairs, static fn( $key ) => ! in_array( strtolower( rtrim( (string) $key ) ), [ 'admin_note', 'admin_note_print' ], TRUE ), ARRAY_FILTER_USE_KEY );
		}
		$done = 0;
		
		foreach ( $pairs as $k => $v ) {
			$k = (string) $k;
			if ( $k === '' ) {
				continue;
			}
			if ( $unique ) {
				if ( FALSE === $this->db->delete( $table, [ $fk => $object_id, 'meta_key' => $k ], [ '%d', '%s' ] ) ) { return $this->fail( 'Meta delete failed.' ); }
			}
			$ok = $this->db->insert(
				$table,
				[ $fk => $object_id, 'meta_key' => $k, 'meta_value' => maybe_serialize( $v ) ],
				[ '%d', '%s', '%s' ]
			);
			if ( ! $ok ) { return $this->fail( 'Meta save failed.' ); }
			$done ++;
		}
		
		return $this->ok( 'Meta saved.', [ 'count' => $done ] );
	}
	
	public function update_meta( string $context, int $object_id, string $meta_key, $meta_value, bool $unique = TRUE ): array {
		[ $table, $fk ] = $this->resolve_meta_table( $context );
		if ( ! $table || $meta_key === '' ) {
			return $this->fail( 'Invalid meta params.' );
		}
		if ( $table === $this->db_prefix . 'cheque_meta' && in_array( strtolower( rtrim( $meta_key ) ), [ 'admin_note', 'admin_note_print' ], TRUE ) && ! current_user_can( 'manage_options' ) ) {
			return $this->fail( 'اجازه تغییر یادداشت داخلی چک را ندارید.' );
		}
		
		if ( $unique ) {
			if ( FALSE === $this->db->delete( $table, [ $fk => $object_id, 'meta_key' => $meta_key ], [ '%d', '%s' ] ) ) { return $this->fail( 'Meta delete failed.' ); }
		}
		
		$ok = $this->db->insert(
			$table,
			[ $fk => $object_id, 'meta_key' => $meta_key, 'meta_value' => maybe_serialize( $meta_value ) ],
			[ '%d', '%s', '%s' ]
		);
		
		if ( ! $ok ) {
			return $this->fail( 'Meta update failed.' );
		}
		
		return $this->ok( 'Meta updated.', [ 'key' => $meta_key ] );
	}
	
	public function delete_meta( string $context, int $object_id, string $meta_key = '' ): array {
		[ $table, $fk ] = $this->resolve_meta_table( $context );
		if ( ! $table ) {
			return $this->fail( 'Invalid meta context.' );
		}
		
		if ( $meta_key === '' ) {
			$ok = $this->db->delete( $table, [ $fk => $object_id ], [ '%d' ] );
		} else {
			$ok = $this->db->delete( $table, [ $fk => $object_id, 'meta_key' => $meta_key ], [ '%d', '%s' ] );
		}
		
		if ( $ok === FALSE ) {
			return $this->fail( 'Meta delete failed.' );
		}
		
		return $this->ok( 'Meta deleted.', [ 'count' => (int) $ok ] );
	}
	
	public function get_next_factor_number(): int {
		$max = (int) $this->db->get_var(
			"SELECT MAX(
			CAST(
				REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
				REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
					meta_value,
					'۰','0'),'۱','1'),'۲','2'),'۳','3'),'۴','4'),
					'۵','5'),'۶','6'),'۷','7'),'۸','8'),'۹','9'),
					'٠','0'),'١','1'),'٢','2'),'٣','3'),'٤','4'),
					'٥','5'),'٦','6'),'٧','7'),'٨','8'),'٩','9')
			AS UNSIGNED)
		)
		FROM {$this->db_prefix}orders_meta
		WHERE meta_key = 'factor_number'"
		);
		
		return $max > 0 ? $max + 1 : 1;
	}
	
	/** -------------------- TABLE RESOLUTION -------------------- */
	
	private function resolve_meta_table( string $context ): array {
		$base = $this->normalize_meta_context( $context );
		
		if ( ! $base ) {
			return [ '', '' ];
		}
		
		$fk = $this->meta_tables[ $base ] ?? '';
		if ( $fk === '' ) {
			return [ '', '' ];
		}
		
		$table = $this->db_prefix . $base . '_meta';
		
		return [ $table, $fk ];
	}
	
	private function normalize_meta_context( string $context ): string {
		$ctx = trim( strtolower( $context ) );
		
		if ( isset( $this->meta_tables[ $ctx ] ) ) {
			return $ctx;
		}
		
		if ( isset( $this->meta_aliases[ $ctx ] ) && isset( $this->meta_tables[ $this->meta_aliases[ $ctx ] ] ) ) {
			return $this->meta_aliases[ $ctx ];
		}
		
		$sing   = rtrim( $ctx, 's' );
		$plural = $ctx . 's';
		
		if ( isset( $this->meta_tables[ $sing ] ) ) {
			return $sing;
		}
		if ( isset( $this->meta_tables[ $plural ] ) ) {
			return $plural;
		}
		
		// If context already ends with "_meta", strip and retry
		if ( str_ends_with( $ctx, '_meta' ) ) {
			$base = substr( $ctx, 0, - 5 );
			if ( isset( $this->meta_tables[ $base ] ) ) {
				return $base;
			}
		}
		
		return '';
	}
	
	/** ===================== Magic router for CRUD wrappers ===================== */
	public function __call( string $name, array $args ) {
		if ( ! preg_match( '/^(get|update|delete|save)_([a-z0-9_]+)_meta(?:_batch)?$/i', $name, $m ) ) {
			throw new BadMethodCallException( "Call to undefined method " . static::class . "::{$name}()" );
		}
		$op       = strtolower( $m[1] );      // get|update|delete|save
		$raw_ctx  = strtolower( $m[2] );      // e.g. actions / action
		$is_batch = str_ends_with( $name, '_meta_batch' );
		
		$context = $this->normalize_meta_context( $raw_ctx );
		if ( $context === '' ) {
			throw new InvalidArgumentException( "Unknown meta context '{$raw_ctx}'" );
		}
		
		switch ( $op ) {
			case 'get':
			{
				$object_id = isset( $args[0] ) ? (int) $args[0] : 0;
				$meta_key  = isset( $args[1] ) ? (string) $args[1] : '';
				$single    = isset( $args[2] ) ? (bool) $args[2] : TRUE;
				
				if ( $object_id <= 0 ) {
					return $single ? NULL : [];
				}
				
				return $this->get_meta( $context, $object_id, $meta_key, $single );
			}
			
			case 'add':
			case 'update':
			{
				$object_id  = isset( $args[0] ) ? (int) $args[0] : 0;
				$meta_key   = isset( $args[1] ) ? (string) $args[1] : '';
				$meta_value = $args[2] ?? NULL;
				$unique     = isset( $args[3] ) ? (bool) $args[3] : TRUE;
				if ( $object_id <= 0 || $meta_key === '' ) {
					return $this->fail( 'Invalid meta params.' );
				}
				
				return $this->update_meta( $context, $object_id, $meta_key, $meta_value, $unique );
			}
			
			case 'save':
			{
				if ( ! $is_batch ) {
					throw new BadMethodCallException( "Unsupported method {$name}(). Did you mean save_{$raw_ctx}_meta_batch()?" );
				}
				$object_id = isset( $args[0] ) ? (int) $args[0] : 0;
				$pairs     = isset( $args[1] ) && is_array( $args[1] ) ? $args[1] : [];
				$unique    = isset( $args[2] ) ? (bool) $args[2] : TRUE;
				
				if ( $object_id <= 0 ) {
					return $this->fail( 'Invalid meta params.' );
				}
				
				return $this->save_meta_batch( $context, $object_id, $pairs, $unique );
			}
			
			case 'delete':
			{
				$object_id = isset( $args[0] ) ? (int) $args[0] : 0;
				$meta_key  = isset( $args[1] ) ? (string) $args[1] : '';
				
				if ( $object_id <= 0 ) {
					return $this->fail( 'Invalid meta params.' );
				}
				
				return $this->delete_meta( $context, $object_id, $meta_key );
			}
		}
		
		throw new BadMethodCallException( "Unhandled operation in {$name}()" );
	}
	
	private function build_meta_equals_filter(
		string $context,
		string $meta_key,
		$value,
		string $alias = 'm',
		string $left_col = 'a.id'
	): array {
		[ $meta_table, $fk ] = $this->resolve_meta_table( $context );
		if ( ! $meta_table || ! $fk ) {
			return [ '', '', [] ];
		}
		
		$join  = " LEFT JOIN {$meta_table} AS {$alias} ON {$alias}.{$fk} = {$left_col} AND {$alias}.meta_key = '$meta_key'";
		$where = " {$alias}.meta_value = '$value'";
		
		return [ $join, $where, [] ];
	}
	
	private function build_meta_in_filter(
		string $context,
		string $meta_key,
		array $values,
		string $alias = 'm',
		string $left_col = 'a.id'
	): array {
		[ $meta_table, $fk ] = $this->resolve_meta_table( $context );
		if ( ! $meta_table || ! $fk ) {
			return [ '', '', [] ];
		}
		$values = array_values( array_filter( $values, static fn( $v ) => $v !== '' && $v !== NULL ) );
		if ( ! $values ) {
			return [ '', '', [] ];
		}
		$placeholders = implode( ',', array_fill( 0, count( $values ), '%s' ) );
		$join         = " LEFT JOIN {$meta_table} AS {$alias} ON {$alias}.{$fk} = {$left_col} AND {$alias}.meta_key = %s";
		$where        = " {$alias}.meta_value IN ({$placeholders})";
		
		return [ $join, $where, array_merge( [ $meta_key ], array_map( 'strval', $values ) ) ];
	}
	
	/** ---------- File manager ---------- */
	
	public function add_uploaded_file_record( $data ): bool {
		if ( empty( $data['user_id'] ) ) {
			$data['user_id'] = get_current_user_id();
		}
		
		if ( empty( $data['original_name'] ) && ! empty( $data['saved_name'] ) ) {
			$data['original_name'] = pathinfo( $data['saved_name'], PATHINFO_FILENAME );
		}
		
		if ( empty( $data['file_ext'] ) && ! empty( $data['saved_name'] ) ) {
			$data['file_ext'] = pathinfo( $data['saved_name'], PATHINFO_EXTENSION );
		}
		
		if ( empty( $data['ip_address'] ) ) {
			$data['ip_address'] = $_SERVER['REMOTE_ADDR'] ?? NULL;
		}
		
		if ( empty( $data['uploaded_at'] ) ) {
			$data['uploaded_at'] = current_time( 'mysql' );
		}
		
		if ( empty( $data['saved_name'] ) || empty( $data['file_path'] ) || empty( $data['file_url'] ) ) {
			return FALSE;
		}
		
		$inserted = $this->db->insert( $this->uploaded_files, $data );
		
		return (bool) $inserted;
	}
	
	public function get_uploaded_file_data( $file_url ) {
		if ( empty( $file_url ) ) {
			return NULL;
		}
		
		$row = $this->db->get_row(
			$this->db->prepare(
				"SELECT * FROM {$this->uploaded_files} WHERE file_url = %s LIMIT 1",
				$file_url
			),
			ARRAY_A
		);
		
		return $row ?: NULL;
	}
	
	/** ---------- Actions and Communications ---------- */
	public function get_user_actions( array $args = [] ): array {
		$args = wp_parse_args( $args, [
			'creator'     => NULL,
			'user_id'     => 0,
			'search'      => '',
			'search_user' => '',
			'date_from'   => '',
			'date_to'     => '',
			'type'        => '',
			'page'        => 1,
			'per_page'    => 20,
			'orderby'     => 'date',
			'order'       => 'DESC',
		] );
		
		$page     = max( 1, (int) $args['page'] );
		$per_page = max( 1, (int) $args['per_page'] );
		$offset   = ( $page - 1 ) * $per_page;
		
		$where  = [ '1=1' ];
		$params = [];
		$joins  = [];
		
		if ( ! empty( $args['creator'] ) && is_numeric( $args['creator'] ) ) {
			$where[]  = 'a.creator = %d';
			$params[] = (int) $args['creator'];
		}
		
		if ( ! empty( $args['user_id'] ) && is_numeric( $args['user_id'] ) ) {
			$where[]  = 'a.user_id = %d';
			$params[] = (int) $args['user_id'];
		}
		
		if ( ! empty( $args['search'] ) ) {
			$search   = '%' . $this->db->esc_like( $args['search'] ) . '%';
			$where[]  = '(a.title LIKE %s OR a.content LIKE %s)';
			$params[] = $search;
			$params[] = $search;
		}
		
		if ( ! empty( $args['search_user'] ) && function_exists( 'kcp_get_user_list' ) ) {
			$user_list = kcp_get_user_list( $args['search_user'], - 1 )['users'] ?? [];
			$user_ids  = array_map( fn( $u ) => (int) $u['user_id'], $user_list );
			
			if ( empty( $user_ids ) ) {
				return [
					'items'      => [],
					'pagination' => [
						'page'       => $page,
						'per_page'   => $per_page,
						'total'      => 0,
						'total_page' => 0,
					],
				];
			}
			
			$placeholders = implode( ',', array_fill( 0, count( $user_ids ), '%d' ) );
			$where[]      = "a.user_id IN ($placeholders)";
			$params       = array_merge( $params, $user_ids );
		}
		
		if ( ! empty( $args['date_from'] ) ) {
			$date_from = function_exists( 'nooshika_jalali_to_gregorian' )
				? nooshika_jalali_to_gregorian( $args['date_from'] )
				: $args['date_from'];
			
			$where[]  = 'a.date >= %s';
			$params[] = $date_from . ' 00:00:00';
		}
		
		if ( ! empty( $args['date_to'] ) ) {
			$date_to = function_exists( 'nooshika_jalali_to_gregorian' )
				? nooshika_jalali_to_gregorian( $args['date_to'] )
				: $args['date_to'];
			
			$where[]  = 'a.date <= %s';
			$params[] = $date_to . ' 23:59:59';
		}
		
		if ( ! empty( $args['type'] ) ) {
			[ $action_meta_table, $action_meta_fk ] = $this->resolve_meta_table( 'action' );
			
			$joins[]  = "INNER JOIN {$action_meta_table} AS action_type_meta
			ON action_type_meta.{$action_meta_fk} = a.id
			AND action_type_meta.meta_key = 'type'";
			$where[]  = 'action_type_meta.meta_value = %s';
			$params[] = sanitize_text_field( $args['type'] );
		}
		
		$where_sql = implode( ' AND ', $where );
		$join_sql  = $joins ? implode( ' ', $joins ) : '';
		
		$allowed_orderby = [ 'id', 'user_id', 'date', 'creator' ];
		$orderby         = in_array( $args['orderby'], $allowed_orderby, TRUE ) ? $args['orderby'] : 'date';
		$order           = strtoupper( $args['order'] ) === 'ASC' ? 'ASC' : 'DESC';
		
		$count_sql = "
		SELECT COUNT(DISTINCT a.id)
		FROM {$this->actions_table} AS a
		{$join_sql}
		WHERE {$where_sql}
	";
		
		$total = (int) $this->db->get_var(
			$this->db->prepare( $count_sql, $params )
		);
		
		$data_sql = "
		SELECT DISTINCT a.*
		FROM {$this->actions_table} AS a
		{$join_sql}
		WHERE {$where_sql}
		ORDER BY a.{$orderby} {$order}, a.id {$order}
		LIMIT %d OFFSET %d
	";
		
		$data_params = array_merge( $params, [ $per_page, $offset ] );
		
		$rows = $this->db->get_results(
			$this->db->prepare( $data_sql, $data_params ),
			ARRAY_A
		);
		
		foreach ( $rows as &$row ) {
			$row['attachment'] = $this->get_action_meta( (int) $row['id'], 'attachment', FALSE );
		}
		unset( $row );
		
		return [
			'items'      => $rows ?: [],
			'pagination' => [
				'page'       => $page,
				'per_page'   => $per_page,
				'total'      => $total,
				'total_page' => (int) ceil( $total / $per_page ),
			],
		];
	}
	
	public function add_user_action( array $data ): array {
		$data = wp_parse_args( $data, [
			'user_id'      => 0,
			'title'        => '',
			'content'      => '',
			'date_created' => current_time( 'mysql' ),
			'creator'      => get_current_user_id(),
			'type'         => '',
			'attachment'   => '',
			'meta'         => [],
		] );
		
		if ( (int) $data['user_id'] <= 0 ) {
			return $this->fail( 'کاربر انتخاب نشده است.' );
		}
		
		if ( trim( $data['title'] ) === '' || trim( $data['content'] ) === '' ) {
			return $this->fail( 'عنوان و توضیحات باید وارد شوند.' );
		}
		
		$this->db->query( 'START TRANSACTION' );
		
		$inserted = $this->db->insert(
			$this->actions_table,
			[
				'user_id' => (int) $data['user_id'],
				'title'   => sanitize_text_field( $data['title'] ),
				'content' => wp_kses_post( $data['content'] ),
				'date'    => $data['date_created'],
				'creator' => (int) $data['creator'],
			],
			[ '%d', '%s', '%s', '%s', '%d' ]
		);
		
		if ( ! $inserted ) {
			$this->db->query( 'ROLLBACK' );
			
			return $this->fail( 'ثبت فعالیت با خطا مواجه شد.' );
		}
		
		$action_id = (int) $this->db->insert_id;
		
		$meta = is_array( $data['meta'] ) ? $data['meta'] : [];
		
		if ( ! empty( $data['type'] ) ) {
			$meta['type'] = sanitize_text_field( $data['type'] );
		}
		
		if ( ! empty( $data['attachment'] ) ) {
			$meta['attachment'] = esc_url_raw( $data['attachment'] );
		}
		
		if ( ! empty( $meta ) ) {
			$meta_res = $this->save_actions_meta_batch( $action_id, $meta, TRUE );
			
			if ( $meta_res['status'] !== 'success' ) {
				$this->db->query( 'ROLLBACK' );
				
				return $meta_res;
			}
		}
		
		$this->db->query( 'COMMIT' );
		
		return $this->ok( 'فعالیت با موفقیت ثبت شد.', [
			'action_id' => $action_id,
		] );
	}
	
	public function get_user_action( int $action_id ): ?array {
		if ( $action_id <= 0 ) {
			return NULL;
		}
		
		$row = $this->db->get_row(
			$this->db->prepare(
				"SELECT * FROM {$this->actions_table} WHERE id = %d LIMIT 1",
				$action_id
			),
			ARRAY_A
		);
		
		if ( ! $row ) {
			return NULL;
		}
		
		$row['meta'] = $this->get_action_meta( $action_id, '', FALSE );
		
		return $row;
	}
	
	public function update_user_action( int $action_id, array $data ): array {
		if ( $action_id <= 0 ) {
			return $this->fail( 'شناسه فعالیت نامعتبر است.' );
		}
		
		$action = $this->get_user_action( $action_id );
		
		if ( ! $action ) {
			return $this->fail( 'فعالیت یافت نشد.' );
		}
		
		$data = wp_parse_args( $data, [
			'user_id'      => $action['user_id'],
			'title'        => $action['title'],
			'content'      => $action['content'],
			'date_created' => $action['date'],
			'creator'      => $action['creator'],
			'type'         => NULL,
			'attachment'   => NULL,
			'meta'         => [],
		] );
		
		if ( (int) $data['user_id'] <= 0 ) {
			return $this->fail( 'کاربر انتخاب نشده است.' );
		}
		
		if ( trim( $data['title'] ) === '' || trim( $data['content'] ) === '' ) {
			return $this->fail( 'عنوان و توضیحات باید وارد شوند.' );
		}
		
		$this->db->query( 'START TRANSACTION' );
		
		$updated = $this->db->update(
			$this->actions_table,
			[
				'user_id' => (int) $data['user_id'],
				'title'   => sanitize_text_field( $data['title'] ),
				'content' => wp_kses_post( $data['content'] ),
				'date'    => $data['date_created'],
				'creator' => (int) $data['creator'],
			],
			[ 'id' => $action_id ],
			[ '%d', '%s', '%s', '%s', '%d' ],
			[ '%d' ]
		);
		
		if ( $updated === FALSE ) {
			$this->db->query( 'ROLLBACK' );
			
			return $this->fail( 'ویرایش فعالیت با خطا مواجه شد.' );
		}
		
		$meta = is_array( $data['meta'] ) ? $data['meta'] : [];
		
		if ( $data['type'] !== NULL ) {
			$meta['type'] = sanitize_text_field( $data['type'] );
		}
		
		if ( $data['attachment'] !== NULL ) {
			$meta['attachment'] = esc_url_raw( $data['attachment'] );
		}
		
		if ( ! empty( $meta ) ) {
			$meta_res = $this->save_action_meta_batch( $action_id, $meta, TRUE );
			
			if ( $meta_res['status'] !== 'success' ) {
				$this->db->query( 'ROLLBACK' );
				
				return $meta_res;
			}
		}
		
		$this->db->query( 'COMMIT' );
		
		return $this->ok( 'فعالیت با موفقیت ویرایش شد.', [
			'action_id' => $action_id,
		] );
	}
	
	public function delete_user_action( int $action_id ): array {
		if ( $action_id <= 0 ) {
			return $this->fail( 'شناسه فعالیت نامعتبر است.' );
		}
		
		$this->db->query( 'START TRANSACTION' );
		
		$meta_res = $this->delete_action_meta( $action_id );
		
		if ( $meta_res['status'] !== 'success' ) {
			$this->db->query( 'ROLLBACK' );
			
			return $meta_res;
		}
		
		$deleted = $this->db->delete(
			$this->actions_table,
			[ 'id' => $action_id ],
			[ '%d' ]
		);
		
		if ( $deleted === FALSE ) {
			$this->db->query( 'ROLLBACK' );
			
			return $this->fail( 'حذف فعالیت با خطا مواجه شد.' );
		}
		
		$this->db->query( 'COMMIT' );
		
		return $this->ok( 'فعالیت با موفقیت حذف شد.', [
			'action_id' => $action_id,
		] );
	}
	
	/** ---------- Accounts and Transactions ---------- */
	
	public function add_account_transaction( array $args, bool $inside_transaction = false ): array {
		$args = wp_parse_args( $args, [
			'account_id'  => 0,
			'amount'      => 0,
			'type'        => '',          // debit | credit
			'action'      => '',
			'description' => NULL,
			'created_by'  => get_current_user_id(),
			'created_at'  => current_time( 'mysql' ),
			'meta'        => [],
		] );
		
        $amount_text=is_scalar($args['amount'])?trim(str_replace([',','٬'],'',nooshika_sanitize_numbers((string)$args['amount']))):'';
        $args['amount']=$amount_text;
        if(!preg_match('/^[0-9]{1,18}$/D',$amount_text) || (int)$amount_text<=0)return $this->fail('مبلغ تراکنش باید عدد صحیح مثبت به ریال باشد.');
		if ( ! $args['account_id'] || $args['amount'] <= 0 ) {
			return $this->fail( 'اطلاعات تراکنش معتبر نیست.' );
		}
		
		if ( ! in_array( $args['type'], [ 'debit', 'credit' ], TRUE ) ) {
			return $this->fail( 'نوع تراکنش نامعتبر است.' );
		}
		
        try{$this->finance_tables_ready([$this->accounts,$this->account_transactions,$this->db_prefix.'account_transaction_meta']);}catch(Throwable $e){return $this->fail($e->getMessage());}
        if(!$inside_transaction && false===$this->db->query('START TRANSACTION'))return $this->fail('شروع تراکنش حساب ناموفق بود.');
		$account = $this->db->get_row(
			$this->db->prepare(
				"SELECT id, balance,type FROM {$this->accounts} WHERE id = %d FOR UPDATE",
				$args['account_id']
			),
			ARRAY_A
		);
		
		if ( ! $account || $this->db->last_error ) {
            $this->db->query('ROLLBACK');
			return $this->fail( 'حساب مورد نظر یافت نشد.' );
		}
		
		$current_balance = (string) $account['balance'];
		$amount          = (int) $args['amount'];
		
        $balance_text=bcadd($current_balance,($args['type']==='credit'?'':'-').$amount,0);
        if(bccomp($balance_text,(string)PHP_INT_MAX,0)>0||bccomp($balance_text,(string)PHP_INT_MIN,0)<0){$this->db->query('ROLLBACK');return $this->fail('مانده حساب از محدوده مجاز خارج است.');}
        $new_balance=(int)$balance_text;
		if ( $new_balance < 0 && (string) ( $account['type'] ?? '' ) !== 'expense' ) {
            $this->db->query('ROLLBACK');
			return $this->fail( 'موجودی حساب کافی نیست.' );
		}
		

		
		$insert = $this->db->insert(
			$this->account_transactions,
			[
				'account_id'    => $args['account_id'],
				'amount'        => $amount,
				'type'          => $args['type'],
				'action'        => $args['action'],
				'balance_after' => $new_balance,
				'description'   => $args['description'],
				'created_by'    => $args['created_by'],
				'created_at'    => $args['created_at'],
			],
		);
		
		if ( ! $insert ) {
			$this->db->query( 'ROLLBACK' );
			
			return $this->fail( 'ثبت تراکنش انجام نشد.' );
		}
		
		$transaction_id = $this->db->insert_id;
		
		$update = $this->db->update(
			$this->accounts,
			[
				'balance'    => $new_balance,
				'updated_at' => current_time( 'mysql' ),
			],
			[ 'id' => $args['account_id'] ],
			[ '%d', '%s' ],
			[ '%d' ]
		);
		
		if ( $update === FALSE ) {
			$this->db->query( 'ROLLBACK' );
			
			return $this->fail( 'به‌روزرسانی موجودی حساب ناموفق بود.' );
		}
		
		$meta = is_array( $args['meta'] ) ? $args['meta'] : [];
		if ( empty( $meta['department'] ) ) {
			$department_map = [ 'packaging_cost' => 'production', 'supplier_invoice_fee' => 'supply' ];
			if ( isset( $department_map[ $args['action'] ] ) ) { $meta['department'] = $department_map[ $args['action'] ]; }
		}
		$meta = array_filter( $meta, static function( $v, $k ) {
			return (string) $k !== '';
		}, ARRAY_FILTER_USE_BOTH );
		if ( ! empty( $meta ) ) {
			$meta_res = $this->save_account_transaction_meta_batch( $transaction_id, $meta, TRUE );
			if ( ( $meta_res['status'] ?? '' ) !== 'success' ) {
				$this->db->query( 'ROLLBACK' );
				
				return $this->fail( 'ثبت متای تراکنش با خطا مواجه شد.', $meta_res );
			}
		}
		
        if(!$inside_transaction && false===$this->db->query('COMMIT')){$this->db->query('ROLLBACK');return $this->fail('ثبت نهایی تراکنش حساب ناموفق بود.');}
		
		return $this->ok(
			'تراکنش با موفقیت ثبت شد.',
			[
				'transaction_id' => $transaction_id,
				'account_id'     => $args['account_id'],
				'balance_after'  => $new_balance,
			]
		);
	}
	
	public function add_account( array $args ): array {
		$args = wp_parse_args( $args, [
			'account_id'      => '',
			'title'           => '',
			'type'            => 'bank',
			'bank_name'       => NULL,
			'owner_name'      => NULL,
			'account_no'      => NULL,
			'status'          => 'active',
			'initial_balance' => 0,
			'created_by'      => get_current_user_id(),
			'created_at'      => current_time( 'mysql' ),
			'meta'            => [],
		
		] );
		
		if ( ! $args['title'] ) {
			return $this->fail( 'عنوان حساب الزامی است.' );
		}
		
		$initial_balance = (int) str_replace( ',', '', $args['initial_balance'] );
		if ( $initial_balance < 0 ) {
			return $this->fail( 'موجودی اولیه نامعتبر است.' );
		}
		
		$insert = $this->db->insert(
			$this->accounts,
			[
				'title'      => $args['title'],
				'type'       => $args['type'],
				'bank_name'  => $args['bank_name'],
				'owner_name' => $args['owner_name'],
				'account_no' => $args['account_no'],
				'balance'    => 0,
				'status'     => $args['status'],
				'created_by' => $args['created_by'],
				'created_at' => $args['created_at'],
			],
		);
		
		if ( ! $insert ) {
			return $this->fail( 'ثبت حساب جدید انجام نشد.' );
		}
		
		$account_id = $this->db->insert_id;
		if ( $initial_balance > 0 ) {
			$trx = $this->add_account_transaction( [
				'account_id'  => $account_id,
				'amount'      => $initial_balance,
				'type'        => 'credit',
				'action'      => 'initial_balance',
				'description' => 'ثبت موجودی اولیه حساب',
				'created_by'  => $args['created_by'],
				'created_at'  => $args['created_at'],
			] );
			
			if ( $trx['status'] !== 'success' ) {
				$this->db->delete(
					$this->accounts,
					[ 'id' => $account_id ],
					[ '%d' ]
				);
				
				return $this->fail(
					'ثبت موجودی اولیه ناموفق بود.',
					$trx
				);
			}
		}
		$meta = is_array( $args['meta'] ) ? $args['meta'] : [];
		$meta = array_filter( $meta, static function( $v, $k ) {
			return (string) $k !== '';
		}, ARRAY_FILTER_USE_BOTH );
		if ( ! empty( $meta ) ) {
			$meta_res = $this->save_account_meta_batch( $account_id, $meta, TRUE );
			if ( ( $meta_res['status'] ?? '' ) !== 'success' ) {
				$this->db->query( 'ROLLBACK' );
				
				return $this->fail( 'ثبت متای حساب با خطا مواجه شد.', $meta_res );
			}
		}
		
		return $this->ok(
			'حساب با موفقیت ایجاد شد.',
			[
				'account_id'      => $account_id,
				'initial_balance' => $initial_balance,
			]
		);
	}
	
	public function update_account( int $account_id, array $args ): array {
		if ( $account_id <= 0 ) {
			return $this->fail( 'شناسه حساب نامعتبر است.' );
		}
		
		$account = $this->db->get_row(
			$this->db->prepare(
				"SELECT id FROM {$this->accounts} WHERE id = %d",
				$account_id
			)
		);
		
		if ( ! $account ) {
			return $this->fail( 'حساب مورد نظر یافت نشد.' );
		}
		
		$allowed_fields = [
			'title',
			'type',
			'bank_name',
			'owner_name',
			'account_no',
			'status',
		];
		
		$data = [];
		
		foreach ( $allowed_fields as $field ) {
			if ( array_key_exists( $field, $args ) ) {
				$data[ $field ] = $args[ $field ];
			}
		}
		
		if ( empty( $data ) ) {
			return $this->fail( 'اطلاعاتی برای ویرایش ارسال نشده است.' );
		}
		
		$data['updated_at'] = current_time( 'mysql' );
		
		$updated = $this->db->update(
			$this->accounts,
			$data,
			[ 'id' => $account_id ]
		);
		
		if ( $updated === FALSE ) {
			return $this->fail( 'ویرایش حساب انجام نشد.' );
		}
		
		return $this->ok(
			'حساب با موفقیت ویرایش شد.',
			[
				'account_id' => $account_id,
				'fields'     => array_keys( $data ),
			]
		);
	}
	
	public function get_accounts( array $args = [] ): array {
		$args = wp_parse_args( $args, [
			'page'     => 1,
			'per_page' => 20,
			'status'   => NULL,   // active | inactive | closed
			'type'     => NULL,   // bank | cash | wallet | gateway
			'search'   => '',     // title | bank_name | account_no
			'orderby'  => 'id',   // id | title | balance | created_at
			'order'    => 'DESC', // ASC | DESC
		] );
		
		$page     = max( 1, (int) $args['page'] );
		$per_page = max( 1, min( 100, (int) $args['per_page'] ) );
		$offset   = ( $page - 1 ) * $per_page;
		
		$where  = 'WHERE 1=1';
		$params = [];
		
		if ( $args['status'] !== NULL ) {
			$where    .= ' AND status = %s';
			$params[] = $args['status'];
		}
		
		if ( $args['type'] ) {
			$where    .= ' AND type = %s';
			$params[] = $args['type'];
		}
		
		if ( $args['search'] !== '' ) {
			$where    .= ' AND (title LIKE %s OR bank_name LIKE %s OR account_no LIKE %s)';
			$like     = '%' . $this->db->esc_like( $args['search'] ) . '%';
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
		}
		
		$allowed_orderby = [ 'id', 'title', 'balance', 'created_at' ];
		$orderby         = in_array( $args['orderby'], $allowed_orderby, TRUE )
			? $args['orderby']
			: 'id';
		
		$order = strtoupper( $args['order'] ) === 'ASC' ? 'ASC' : 'DESC';
		
		$sql = "
		SELECT SQL_CALC_FOUND_ROWS *
		FROM {$this->accounts}
		{$where}
		ORDER BY {$orderby} {$order}
		LIMIT %d OFFSET %d
	";
		
		$params[] = $per_page;
		$params[] = $offset;
		$items    = $this->db->get_results(
			$this->db->prepare( $sql, $params ),
			ARRAY_A
		);
		
		if ( $items === NULL ) {
			return $this->fail( 'دریافت لیست حساب‌ها ناموفق بود.' );
		}
		
		$total = (int) $this->db->get_var( 'SELECT FOUND_ROWS()' );
		
		return [
			'items' => $items,
			'total' => $total,
			'page'  => $page,
			'pages' => (int) ceil( $total / $per_page ),
		];
	}
	
	public function get_account( $account_id ): array {
		if ( ! $account_id ) {
			return $this->fail( 'شناسه حساب معتبر نیست.' );
		}
		
		$sql = "
		SELECT *
		FROM {$this->accounts}
		WHERE id = %s
		LIMIT 1
	";
		
		$item = $this->db->get_row(
			$this->db->prepare( $sql, $account_id ),
			ARRAY_A
		);
		
		if ( $item === NULL ) {
			return $this->fail( 'خطا در دریافت اطلاعات حساب: ' . $this->db->last_error );
		}
		
		if ( ! $item ) {
			return $this->fail( 'حسابی با این شماره پیدا نشد.' );
		}
		
		return $item;
	}
	
	public function get_account_department_summary( array $args = [] ): array {
		$args = wp_parse_args($args,['date_from'=>'','date_to'=>'']);
		$meta_table = $this->db_prefix . 'account_transaction_meta';
		$where = 'WHERE 1=1'; $params=[];
		if($args['date_from']!==''){$where.=' AND t.created_at >= %s';$params[]=$args['date_from'].' 00:00:00';}
		if($args['date_to']!==''){$where.=' AND t.created_at <= %s';$params[]=$args['date_to'].' 23:59:59';}
		$sql = "SELECT COALESCE(NULLIF(m.meta_value,''),'unassigned') AS department,
			COUNT(t.id) AS transaction_count,
			COALESCE(SUM(CASE WHEN t.type='credit' THEN t.amount ELSE 0 END),0) AS income,
			COALESCE(SUM(CASE WHEN t.type='debit' THEN t.amount ELSE 0 END),0) AS expenses,
			COALESCE(SUM(CASE WHEN t.type='credit' THEN t.amount ELSE -t.amount END),0) AS net
		FROM {$this->account_transactions} t
		LEFT JOIN {$meta_table} m ON m.transaction_id=t.id AND m.meta_key='department'
		{$where} GROUP BY COALESCE(NULLIF(m.meta_value,''),'unassigned') ORDER BY department ASC";
		$query = $params ? $this->db->prepare($sql,$params) : $sql;
		return $this->db->get_results($query,ARRAY_A) ?: [];
	}

	public function get_account_transactions( array $args = [] ): array {
		$args = wp_parse_args( $args, [
			'page'       => 1,
			'per_page'   => 20,
			'account_id' => 0,
			'type'       => NULL,   // debit|credit|null
			'cost_type'  => NULL,   // debit|credit|null
			'action'     => NULL,   // string|array|null
			'created_by' => 0,
			'date_from'  => NULL,   // created_at >=
			'date_to'    => NULL,   // created_at <=
			'min_amount' => NULL,
			'max_amount' => NULL,
			'orderby'    => 'created_at', // created_at|id|amount|balance_after
			'order'      => 'DESC',
		] );
		
		$page     = max( 1, (int) $args['page'] );
		$per_page = max( 1, min( 5000, (int) $args['per_page'] ) );
		$offset   = ( $page - 1 ) * $per_page;
		
		$allowed_orderby = [
			'created_at'    => 'i.created_at',
			'id'            => 'i.id',
			'amount'        => 'i.amount',
			'balance_after' => 'i.balance_after',
		];
		
		$orderby = $allowed_orderby[ (string) $args['orderby'] ] ?? 'i.created_at';
		
		$order = strtoupper( (string) $args['order'] );
		$order = in_array( $order, [ 'ASC', 'DESC' ], TRUE ) ? $order : 'DESC';
		
		$where = [ '1=1' ];
		$binds = [];
		
		// account_id
		if ( (int) $args['account_id'] > 0 ) {
			$where[] = 'i.account_id = %d';
			$binds[] = (int) $args['account_id'];
		}
		if ( $args['cost_type'] > 0 ) {
			$where[] = 'i.cost_type = %s';
			$binds[] = $args['cost_type'];
		}
		
		// type
		if ( ! is_null( $args['type'] ) && $args['type'] !== '' ) {
			$type = strtolower( trim( (string) $args['type'] ) );
			if ( in_array( $type, [ 'debit', 'credit' ], TRUE ) ) {
				$where[] = 'i.type = %s';
				$binds[] = $type;
			}
		}
		
		// action (single or array)
		if ( ! is_null( $args['action'] ) && $args['action'] !== '' ) {
			if ( is_array( $args['action'] ) ) {
				$actions = array_values( array_filter(
					array_unique(
						array_map( 'trim', array_map( 'strval', $args['action'] ) )
					)
				) );
				
				if ( ! empty( $actions ) ) {
					$placeholders = implode( ',', array_fill( 0, count( $actions ), '%s' ) );
					$where[]      = "i.action IN ({$placeholders})";
					$binds        = array_merge( $binds, $actions );
				}
			} else {
				$action = trim( (string) $args['action'] );
				if ( $action !== '' ) {
					$where[] = 'i.action = %s';
					$binds[] = $action;
				}
			}
		}
		
		// created_by
		if ( (int) $args['created_by'] > 0 ) {
			$where[] = 'i.created_by = %d';
			$binds[] = (int) $args['created_by'];
		}
		
		// amount range
		if ( ! is_null( $args['min_amount'] ) && $args['min_amount'] !== '' ) {
			$where[] = 'i.amount >= %d';
			$binds[] = (int) $args['min_amount'];
		}
		if ( ! is_null( $args['max_amount'] ) && $args['max_amount'] !== '' ) {
			$where[] = 'i.amount <= %d';
			$binds[] = (int) $args['max_amount'];
		}
		
		// date range
		if ( ! is_null( $args['date_from'] ) && $args['date_from'] !== '' ) {
			$where[] = 'i.created_at >= %s';
			$binds[] = (string) $args['date_from'];
		}
		if ( ! is_null( $args['date_to'] ) && $args['date_to'] !== '' ) {
			$where[] = 'i.created_at <= %s';
			$binds[] = (string) $args['date_to'];
		}
		
		$where_sql = implode( ' AND ', $where );
		
		$sql_rows = "
		SELECT i.*
		FROM {$this->account_transactions} i
		WHERE {$where_sql}
		ORDER BY {$orderby} {$order}, i.id {$order}
		LIMIT %d OFFSET %d
	";
		
		$rows_sql = $this->db->prepare( $sql_rows, array_merge( $binds, [ $per_page, $offset ] ) );
		$rows     = $this->db->get_results( $rows_sql, ARRAY_A );
		
		if ( $rows === NULL ) {
			return [
				'items'      => [],
				'pagination' => [
					'page'       => $page,
					'per_page'   => $per_page,
					'total'      => 0,
					'total_page' => 1,
				],
				'error'      => 'خطا در دریافت لیست تراکنش‌ها: ' . $this->db->last_error,
			];
		}
		
		$sql_count = "
		SELECT COUNT(*)
		FROM {$this->account_transactions} i
		WHERE {$where_sql}
	";
		
		$count_sql  = empty( $binds ) ? $sql_count : $this->db->prepare( $sql_count, $binds );
		$total      = (int) $this->db->get_var( $count_sql );
		$total_page = (int) max( 1, ceil( $total / $per_page ) );
		
		return [
			'items'      => $rows,
			'pagination' => [
				'page'       => $page,
				'per_page'   => $per_page,
				'total'      => $total,
				'total_page' => $total_page,
			],
		];
	}
	
	/** ---------- Product Raw Category ---------- */
	
	private function inject_raw_category_order( int $category_id, int $new_order ): void {
		$category_id = (int) $category_id;
		$new_order   = (int) $new_order;
		
		$ids = $this->db->get_col(
			"SELECT id FROM {$this->raw_categories} ORDER BY sort_order ASC, id ASC"
		);
		
		if ( empty( $ids ) ) {
			return;
		}
		
		// حذف آیتم (اگر هست)
		$ids = array_values( array_diff( array_map( 'intval', $ids ), [ $category_id ] ) );
		
		$position = $new_order - 1;
		if ( $position < 0 ) {
			$position = 0;
		}
		if ( $position > count( $ids ) ) {
			$position = count( $ids );
		}
		
		array_splice( $ids, $position, 0, [ $category_id ] );
		
		$counter = 1;
		foreach ( $ids as $id ) {
			$this->db->update(
				$this->raw_categories,
				[
					'sort_order' => $counter,
					'updated_at' => current_time( 'mysql', TRUE ),
				],
				[ 'id' => (int) $id ],
				[ '%d', '%s' ],
				[ '%d' ]
			);
			
			$counter ++;
		}
	}
	
	private function reorder_raw_categories(): void {
		$ids = $this->db->get_col(
			"SELECT id FROM {$this->raw_categories} ORDER BY sort_order ASC, id ASC"
		);
		
		if ( empty( $ids ) ) {
			return;
		}
		$counter = 1;
		foreach ( $ids as $id ) {
			$this->db->update(
				$this->raw_categories,
				[
					'sort_order' => $counter,
					'updated_at' => current_time( 'mysql', TRUE ),
				],
				[ 'id' => (int) $id ],
				[ '%d', '%s' ],
				[ '%d' ]
			);
			
			$counter ++;
		}
	}
	
	public function add_raw_category( array $data ): array {
		$data = wp_parse_args( $data, [
			'parent_id'  => NULL,
			'title'      => '',
			'sort_order' => 0,
			'is_active'  => 1,
			'created_at' => current_time( 'mysql', TRUE ),
			'updated_at' => NULL,
		] );
		
		$title = trim( (string) $data['title'] );
		if ( $title === '' ) {
			return $this->fail( 'عنوان دسته‌بندی معتبر نیست.' );
		}
		
		$parent_id = is_null( $data['parent_id'] ) ? NULL : (int) $data['parent_id'];
		if ( ! is_null( $parent_id ) && $parent_id <= 0 ) {
			return $this->fail( 'شناسه دسته‌بندی والد معتبر نیست.' );
		}
		
		if ( ! is_null( $parent_id ) ) {
			$exists = (int) $this->db->get_var(
				$this->db->prepare(
					"SELECT id FROM {$this->raw_categories} WHERE id = %d LIMIT 1",
					$parent_id
				)
			);
			
			if ( $exists <= 0 ) {
				return $this->fail( 'دسته‌بندی والد پیدا نشد.' );
			}
		}
		
		$insert = [
			'parent_id'  => $parent_id,
			'title'      => $title,
			'sort_order' => 1000,
			'is_active'  => (int) (bool) $data['is_active'],
			'created_at' => (string) $data['created_at'],
			'updated_at' => $data['updated_at'] ? (string) $data['updated_at'] : NULL,
		];
		
		// wpdb با NULL در format مشکل دارد، پس parent_id را در صورت NULL حذف می‌کنیم.
		if ( is_null( $insert['parent_id'] ) ) {
			unset( $insert['parent_id'] );
		}
		
		$formats = [];
		foreach ( $insert as $k => $v ) {
			if ( in_array( $k, [ 'sort_order', 'is_active' ], TRUE ) ) {
				$formats[] = '%d';
			} else {
				$formats[] = '%s';
			}
		}
		
		$ok = $this->db->insert( $this->raw_categories, $insert, $formats );
		if ( $ok === FALSE ) {
			return $this->fail( 'خطا در ثبت دسته‌بندی: ' . $this->db->last_error );
		}
		
		$new_id = (int) $this->db->insert_id;
		if ( isset( $data['sort_order'] ) && (int) $data['sort_order'] > 0 ) {
			$this->inject_raw_category_order( $new_id, (int) $data['sort_order'] );
		} else {
			$max = (int) $this->db->get_var( "SELECT MAX(sort_order) FROM {$this->raw_categories}" );
			$this->db->update(
				$this->raw_categories,
				[ 'sort_order' => max( 0, $max ) + 1, 'updated_at' => current_time( 'mysql', TRUE ) ],
				[ 'id' => $new_id ],
				[ '%d', '%s' ],
				[ '%d' ]
			);
		}
		
		return $this->ok( 'دسته‌بندی با موفقیت ثبت شد.', [
			'id' => (int) $this->db->insert_id,
		] );
	}
	
	public function update_raw_category( int $category_id, array $data ): array {
		$category_id = (int) $category_id;
		if ( $category_id <= 0 ) {
			return $this->fail( 'شناسه دسته‌بندی معتبر نیست.' );
		}
		
		$exists = (int) $this->db->get_var(
			$this->db->prepare(
				"SELECT id FROM {$this->raw_categories} WHERE id = %d LIMIT 1",
				$category_id
			)
		);
		
		if ( $exists <= 0 ) {
			return $this->fail( 'دسته‌بندی پیدا نشد.' );
		}
		
		$update  = [];
		$formats = [];
		
		if ( array_key_exists( 'title', $data ) ) {
			$title = trim( (string) $data['title'] );
			if ( $title === '' ) {
				return $this->fail( 'عنوان دسته‌بندی معتبر نیست.' );
			}
			$update['title'] = $title;
			$formats[]       = '%s';
		}
		
		if ( array_key_exists( 'is_active', $data ) ) {
			$update['is_active'] = (int) (bool) $data['is_active'];
			$formats[]           = '%d';
		}
		
		$set_parent_null = FALSE;
		if ( array_key_exists( 'parent_id', $data ) ) {
			$parent_id = is_null( $data['parent_id'] ) ? NULL : (int) $data['parent_id'];
			
			if ( ! is_null( $parent_id ) ) {
				if ( $parent_id <= 0 ) {
					return $this->fail( 'شناسه دسته‌بندی والد معتبر نیست.' );
				}
				if ( $parent_id === $category_id ) {
					return $this->fail( 'دسته‌بندی نمی‌تواند والدِ خودش باشد.' );
				}
				
				$parent_exists = (int) $this->db->get_var(
					$this->db->prepare(
						"SELECT id FROM {$this->raw_categories} WHERE id = %d LIMIT 1",
						$parent_id
					)
				);
				
				if ( $parent_exists <= 0 ) {
					return $this->fail( 'دسته‌بندی والد پیدا نشد.' );
				}
				
				$update['parent_id'] = $parent_id;
				$formats[]           = '%d';
			} else {
				// parent_id = NULL را با query جدا اعمال می‌کنیم.
				$set_parent_null = TRUE;
			}
		}
		
		if ( empty( $update ) && ! $set_parent_null ) {
			return $this->ok( 'چیزی برای بروزرسانی وجود ندارد.', [ 'updated' => 0 ] );
		}
		
		$update['updated_at'] = current_time( 'mysql', TRUE );
		$formats[]            = '%s';
		
		// اگر قرار است parent_id NULL شود، UPDATE دستی می‌زنیم (wpdb->update برای NULL قابل اعتماد نیست)
		if ( $set_parent_null ) {
			$set_sql = [ "parent_id = NULL" ];
			$args    = [];
			foreach ( $update as $k => $v ) {
				$set_sql[] = "`{$k}` = %s";
				$args[]    = $v;
			}
			$args[] = $category_id;
			
			$sql = "UPDATE {$this->raw_categories} SET " . implode( ', ', $set_sql ) . " WHERE id = %d";
			$ok  = $this->db->query( $this->db->prepare( $sql, $args ) );
			
			if ( $ok === FALSE ) {
				return $this->fail( 'خطا در بروزرسانی دسته‌بندی: ' . $this->db->last_error );
			}
			
			return $this->ok( 'دسته‌بندی با موفقیت بروزرسانی شد.', [ 'updated' => (int) $ok ] );
		}
		
		$ok = $this->db->update(
			$this->raw_categories,
			$update,
			[ 'id' => $category_id ],
			$formats,
			[ '%d' ]
		);
		if ( array_key_exists( 'sort_order', $data ) ) {
			$new_order = (int) $data['sort_order'];
			if ( $new_order <= 0 ) {
				$new_order = PHP_INT_MAX; // یعنی ببر آخر
			}
			$this->inject_raw_category_order( $category_id, $new_order );
		}
		
		if ( $ok === FALSE ) {
			return $this->fail( 'خطا در بروزرسانی دسته‌بندی: ' . $this->db->last_error );
		}
		
		return $this->ok( 'دسته‌بندی با موفقیت بروزرسانی شد.', [ 'updated' => (int) $ok ] );
	}
	
	public function delete_raw_category( int $category_id, bool $force = FALSE ): array {
		$category_id = (int) $category_id;
		if ( $category_id <= 0 ) {
			return $this->fail( 'شناسه دسته‌بندی معتبر نیست.' );
		}
		
		$row = $this->db->get_row(
			$this->db->prepare(
				"SELECT id, parent_id FROM {$this->raw_categories} WHERE id = %d LIMIT 1",
				$category_id
			),
			ARRAY_A
		);
		
		if ( empty( $row ) ) {
			return $this->fail( 'دسته‌بندی پیدا نشد.' );
		}
		
		$has_children = (int) $this->db->get_var(
			$this->db->prepare(
				"SELECT COUNT(*) FROM {$this->raw_categories} WHERE parent_id = %d",
				$category_id
			)
		);
		
		if ( $has_children > 0 && ! $force ) {
			return $this->fail( 'این دسته‌بندی زیرمجموعه دارد. برای حذف، force را true کنید.' );
		}
		
		$products_count = (int) $this->db->get_var(
			$this->db->prepare(
				"SELECT COUNT(*) FROM {$this->raw_products} WHERE category_id = %d",
				$category_id
			)
		);
		
		if ( $products_count > 0 ) {
			return $this->fail( 'این دسته‌بندی دارای محصول است. ابتدا محصولات را به دسته دیگری منتقل کنید.' );
		}
		
		// اگر فرزند دارد، قبل از حذف، فرزندها را به والد این دسته منتقل می‌کنیم (یا NULL)
		if ( $has_children > 0 ) {
			$parent_id = is_null( $row['parent_id'] ) ? NULL : (int) $row['parent_id'];
			
			if ( is_null( $parent_id ) ) {
				$ok_reparent = $this->db->query(
					$this->db->prepare(
						"UPDATE {$this->raw_categories}
					 SET parent_id = NULL, updated_at = %s
					 WHERE parent_id = %d",
						current_time( 'mysql', TRUE ),
						$category_id
					)
				);
			} else {
				$ok_reparent = $this->db->update(
					$this->raw_categories,
					[
						'parent_id'  => $parent_id,
						'updated_at' => current_time( 'mysql', TRUE ),
					],
					[ 'parent_id' => $category_id ],
					[ '%d', '%s' ],
					[ '%d' ]
				);
			}
			
			if ( $ok_reparent === FALSE ) {
				return $this->fail( 'خطا در بروزرسانی زیرمجموعه‌ها: ' . $this->db->last_error );
			}
		}
		
		$ok = $this->db->delete(
			$this->raw_categories,
			[ 'id' => $category_id ],
			[ '%d' ]
		);
		
		if ( $ok === FALSE ) {
			return $this->fail( 'خطا در حذف دسته‌بندی: ' . $this->db->last_error );
		}
		$this->reorder_raw_categories();
		
		return $this->ok( 'دسته‌بندی با موفقیت حذف شد.', [ 'deleted' => (int) $ok ] );
	}
	
	public function get_raw_categories( array $args = [] ): array {
		$args = wp_parse_args( $args, [
			'page'      => 1,
			'per_page'  => 50,
			'parent_id' => NULL,        // null = همه | 0 = فقط ریشه‌ها | عدد = فقط زیرمجموعه‌های همان
			'search'    => '',
			'is_active' => NULL,        // null = همه | 0/1
			'orderby'   => 'sort_order',// sort_order|id|title|created_at|updated_at
			'order'     => 'ASC',       // ASC|DESC
		] );
		
		$page     = max( 1, (int) $args['page'] );
		$per_page = max( 1, min( 200, (int) $args['per_page'] ) );
		$offset   = ( $page - 1 ) * $per_page;
		
		$search = trim( (string) $args['search'] );
		
		$allowed_orderby = [
			'sort_order' => 'c.sort_order',
			'id'         => 'c.id',
			'title'      => 'c.title',
			'created_at' => 'c.created_at',
			'updated_at' => 'c.updated_at',
		];
		$orderby         = $allowed_orderby[ $args['orderby'] ] ?? 'c.sort_order';
		
		$order = strtoupper( (string) $args['order'] );
		$order = in_array( $order, [ 'ASC', 'DESC' ], TRUE ) ? $order : 'ASC';
		
		$where = [ '1=1' ];
		$binds = [];
		
		// parent filter
		if ( array_key_exists( 'parent_id', $args ) ) {
			if ( $args['parent_id'] === 0 || $args['parent_id'] === '0' ) {
				$where[] = 'c.parent_id IS NULL';
			} elseif ( ! is_null( $args['parent_id'] ) ) {
				$where[] = 'c.parent_id = %d';
				$binds[] = (int) $args['parent_id'];
			}
		}
		
		// active filter
		if ( $args['is_active'] !== NULL && $args['is_active'] !== '' ) {
			$where[] = 'c.is_active = %d';
			$binds[] = (int) (bool) $args['is_active'];
		}
		
		// search
		if ( $search !== '' ) {
			$like    = '%' . $this->db->esc_like( $search ) . '%';
			$where[] = '(c.title LIKE %s OR c.id = %d)';
			$binds[] = $like;
			$binds[] = (int) $search;
		}
		
		$where_sql = implode( ' AND ', $where );
		
		$sql_rows = "
		SELECT c.*
		FROM {$this->raw_categories} c
		WHERE {$where_sql}
		ORDER BY {$orderby} {$order}, c.id {$order}
		LIMIT %d OFFSET %d
	";
		
		$rows_sql = $this->db->prepare( $sql_rows, array_merge( $binds, [ $per_page, $offset ] ) );
		$rows     = $this->db->get_results( $rows_sql, ARRAY_A );
		
		if ( $rows === NULL ) {
			return [
				'items'      => [],
				'pagination' => [
					'page'       => $page,
					'per_page'   => $per_page,
					'total'      => 0,
					'total_page' => 1,
				],
				'error'      => 'خطا در دریافت لیست دسته‌بندی‌ها: ' . $this->db->last_error,
			];
		}
		
		$sql_count = "
		SELECT COUNT(*)
		FROM {$this->raw_categories} c
		WHERE {$where_sql}
	";
		
		$count_sql = empty( $binds )
			? $sql_count
			: $this->db->prepare( $sql_count, $binds );
		
		$total      = (int) $this->db->get_var( $count_sql );
		$total_page = (int) max( 1, ceil( $total / $per_page ) );
		
		$items = array_map( static function( array $r ): array {
			return [
				'id'         => (int) $r['id'],
				'parent_id'  => isset( $r['parent_id'] ) ? (int) $r['parent_id'] : NULL,
				'title'      => (string) $r['title'],
				'sort_order' => (int) $r['sort_order'],
				'is_active'  => (int) $r['is_active'],
				'created_at' => (string) $r['created_at'],
				'updated_at' => $r['updated_at'] ? (string) $r['updated_at'] : NULL,
			];
		}, $rows );
		
		return [
			'items'      => $items,
			'pagination' => [
				'page'       => $page,
				'per_page'   => $per_page,
				'total'      => $total,
				'total_page' => $total_page,
			],
		];
	}
	
	public function get_raw_category( $category_id ): array {
		$category_id = (int) $category_id;
		if ( $category_id <= 0 ) {
			return [
				'item'  => NULL,
				'error' => 'شناسه دسته‌بندی معتبر نیست.',
			];
		}
		
		$row = $this->db->get_row(
			$this->db->prepare(
				"SELECT *
			 FROM {$this->raw_categories}
			 WHERE id = %d
			 LIMIT 1",
				$category_id
			),
			ARRAY_A
		);
		
		if ( empty( $row ) ) {
			return [
				'item'  => NULL,
				'error' => 'دسته‌بندی پیدا نشد.',
			];
		}
		
		return [
			'item' => [
				'id'         => (int) $row['id'],
				'parent_id'  => isset( $row['parent_id'] ) ? (int) $row['parent_id'] : NULL,
				'title'      => (string) $row['title'],
				'sort_order' => (int) $row['sort_order'],
				'is_active'  => (int) $row['is_active'],
				'created_at' => (string) $row['created_at'],
				'updated_at' => $row['updated_at'] ? (string) $row['updated_at'] : NULL,
			],
		];
	}
	
	/** ---------- Product Raw ---------- */
	public function add_raw_product( array $data ): array {
		$data = wp_parse_args( $data, [
			'category_id' => 0,
			'title'       => '',
			'code'        => NULL,
			'base_uom'    => 'kg',
			'is_active'   => 1,
			'created_at'  => current_time( 'mysql', TRUE ),
			'updated_at'  => NULL,
		] );
		
		$category_id = (int) $data['category_id'];
		if ( $category_id <= 0 ) {
			return $this->fail( 'شناسه دسته‌بندی معتبر نیست.' );
		}
		
		$cat_exists = (int) $this->db->get_var(
			$this->db->prepare(
				"SELECT id FROM {$this->raw_categories} WHERE id = %d LIMIT 1",
				$category_id
			)
		);
		if ( $cat_exists <= 0 ) {
			return $this->fail( 'دسته‌بندی پیدا نشد.' );
		}
		
		$title = trim( (string) $data['title'] );
		if ( $title === '' ) {
			return $this->fail( 'عنوان محصول معتبر نیست.' );
		}
		
		$code = $data['code'];
		$code = is_null( $code ) ? NULL : trim( (string) $code );
		if ( $code === '' ) {
			$code = NULL;
		}
		
		if ( ! is_null( $code ) ) {
			$code_exists = (int) $this->db->get_var(
				$this->db->prepare(
					"SELECT id FROM {$this->raw_products} WHERE code = %s LIMIT 1",
					$code
				)
			);
			if ( $code_exists > 0 ) {
				return $this->fail( 'کد محصول تکراری است.' );
			}
		}
		
		$base_uom = trim( (string) $data['base_uom'] );
		if ( $base_uom === '' ) {
			$base_uom = 'kg';
		}
		
		$insert = [
			'category_id' => $category_id,
			'title'       => $title,
			'code'        => $code,
			'base_uom'    => $base_uom,
			'is_active'   => (int) (bool) $data['is_active'],
			'created_at'  => (string) $data['created_at'],
			'updated_at'  => $data['updated_at'] ? (string) $data['updated_at'] : NULL,
		];
		
		$formats = [ '%d', '%s', '%s', '%s', '%d', '%s', '%s' ];
		
		$ok = $this->db->insert( $this->raw_products, $insert, $formats );
		if ( $ok === FALSE ) {
			return $this->fail( 'خطا در ثبت محصول: ' . $this->db->last_error );
		}
		
		return $this->ok( 'محصول با موفقیت ثبت شد.', [
			'id' => (int) $this->db->insert_id,
		] );
	}
	
	public function update_raw_product( int $product_id, array $data ): array {
		$product_id = (int) $product_id;
		if ( $product_id <= 0 ) {
			return $this->fail( 'شناسه محصول معتبر نیست.' );
		}
		
		$exists = (int) $this->db->get_var(
			$this->db->prepare(
				"SELECT id FROM {$this->raw_products} WHERE id = %d LIMIT 1",
				$product_id
			)
		);
		if ( $exists <= 0 ) {
			return $this->fail( 'محصول پیدا نشد.' );
		}
		
		$update  = [];
		$formats = [];
		
		if ( array_key_exists( 'title', $data ) ) {
			$title = trim( (string) $data['title'] );
			if ( $title === '' ) {
				return $this->fail( 'عنوان محصول معتبر نیست.' );
			}
			$update['title'] = $title;
			$formats[]       = '%s';
		}
		
		if ( array_key_exists( 'category_id', $data ) ) {
			$category_id = (int) $data['category_id'];
			if ( $category_id <= 0 ) {
				return $this->fail( 'شناسه دسته‌بندی معتبر نیست.' );
			}
			
			$cat_exists = (int) $this->db->get_var(
				$this->db->prepare(
					"SELECT id FROM {$this->raw_categories} WHERE id = %d LIMIT 1",
					$category_id
				)
			);
			if ( $cat_exists <= 0 ) {
				return $this->fail( 'دسته‌بندی پیدا نشد.' );
			}
			
			$update['category_id'] = $category_id;
			$formats[]             = '%d';
		}
		
		if ( array_key_exists( 'base_uom', $data ) ) {
			$base_uom = trim( (string) $data['base_uom'] );
			if ( $base_uom === '' ) {
				return $this->fail( 'واحد پایه معتبر نیست.' );
			}
			$update['base_uom'] = $base_uom;
			$formats[]          = '%s';
		}
		
		if ( array_key_exists( 'is_active', $data ) ) {
			$update['is_active'] = (int) (bool) $data['is_active'];
			$formats[]           = '%d';
		}
		
		if ( array_key_exists( 'code', $data ) ) {
			$code = $data['code'];
			$code = is_null( $code ) ? NULL : trim( (string) $code );
			if ( $code === '' ) {
				$code = NULL;
			}
			
			if ( ! is_null( $code ) ) {
				$code_exists = (int) $this->db->get_var(
					$this->db->prepare(
						"SELECT id FROM {$this->raw_products} WHERE code = %s AND id <> %d LIMIT 1",
						$code,
						$product_id
					)
				);
				if ( $code_exists > 0 ) {
					return $this->fail( 'کد محصول تکراری است.' );
				}
			}
			
			$update['code'] = $code;
			$formats[]      = '%s';
		}
		
		if ( empty( $update ) ) {
			return $this->ok( 'چیزی برای بروزرسانی وجود ندارد.', [ 'updated' => 0 ] );
		}
		
		$update['updated_at'] = current_time( 'mysql', TRUE );
		$formats[]            = '%s';
		
		$ok = $this->db->update(
			$this->raw_products,
			$update,
			[ 'id' => $product_id ],
			$formats,
			[ '%d' ]
		);
		
		if ( $ok === FALSE ) {
			return $this->fail( 'خطا در بروزرسانی محصول: ' . $this->db->last_error );
		}
		
		return $this->ok( 'محصول با موفقیت بروزرسانی شد.', [ 'updated' => (int) $ok ] );
	}
	
	public function delete_raw_product( int $product_id ): array {
		$product_id = (int) $product_id;
		if ( $product_id <= 0 ) {
			return $this->fail( 'شناسه محصول معتبر نیست.' );
		}
		
		$exists = (int) $this->db->get_var(
			$this->db->prepare(
				"SELECT id FROM {$this->raw_products} WHERE id = %d LIMIT 1",
				$product_id
			)
		);
		if ( $exists <= 0 ) {
			return $this->fail( 'محصول پیدا نشد.' );
		}
		
		// جلوگیری از حذف در صورت استفاده در فاکتور خرید
		$in_invoice = (int) $this->db->get_var(
			$this->db->prepare(
				"SELECT COUNT(*) FROM {$this->supplier_invoice_items} WHERE raw_product_id = %d",
				$product_id
			)
		);
		if ( $in_invoice > 0 ) {
			return $this->fail( 'این محصول در فاکتورهای خرید استفاده شده و قابل حذف نیست.' );
		}
		
		// جلوگیری از حذف در صورت داشتن بچ / حرکت انبار
		$in_batches = (int) $this->db->get_var(
			$this->db->prepare(
				"SELECT COUNT(*) FROM {$this->batches} WHERE raw_product_id = %d",
				$product_id
			)
		);
		if ( $in_batches > 0 ) {
			return $this->fail( 'برای این محصول بچ/موجودی ثبت شده و قابل حذف نیست.' );
		}
		
		$ok = $this->db->delete(
			$this->raw_products,
			[ 'id' => $product_id ],
			[ '%d' ]
		);
		
		if ( $ok === FALSE ) {
			return $this->fail( 'خطا در حذف محصول: ' . $this->db->last_error );
		}
		
		return $this->ok( 'محصول با موفقیت حذف شد.', [ 'deleted' => (int) $ok ] );
	}
	
	public function get_raw_products( array $args = [] ): array {
		$args = wp_parse_args( $args, [
			'page'        => 1,
			'per_page'    => 50,
			'category_id' => NULL,      // null=همه
			'search'      => '',
			'is_active'   => NULL,      // null=همه | 0/1
			'orderby'     => 'id',      // id|title|code|created_at|updated_at|sort
			'order'       => 'DESC',    // ASC|DESC
		] );
		
		$page     = max( 1, (int) $args['page'] );
		$per_page = max( 1, min( 200, (int) $args['per_page'] ) );
		$offset   = ( $page - 1 ) * $per_page;
		
		$search = trim( (string) $args['search'] );
		
		$allowed_orderby = [
			'id'         => 'p.id',
			'title'      => 'p.title',
			'code'       => 'p.code',
			'created_at' => 'p.created_at',
			'updated_at' => 'p.updated_at',
			'sort'       => 'p.id',
		];
		$orderby         = $allowed_orderby[ (string) $args['orderby'] ] ?? 'p.id';
		
		$order = strtoupper( (string) $args['order'] );
		$order = in_array( $order, [ 'ASC', 'DESC' ], TRUE ) ? $order : 'DESC';
		
		$where = [ '1=1' ];
		$binds = [];
		
		if ( $args['category_id'] !== NULL && $args['category_id'] !== '' ) {
			$where[] = 'p.category_id = %d';
			$binds[] = (int) $args['category_id'];
		}
		
		if ( $args['is_active'] !== NULL && $args['is_active'] !== '' ) {
			$where[] = 'p.is_active = %d';
			$binds[] = (int) (bool) $args['is_active'];
		}
		
		if ( $search !== '' ) {
			$like    = '%' . $this->db->esc_like( $search ) . '%';
			$where[] = '(p.title LIKE %s OR p.code LIKE %s OR p.id = %d)';
			$binds[] = $like;
			$binds[] = $like;
			$binds[] = (int) $search;
		}
		
		$where_sql = implode( ' AND ', $where );
		
		$sql_rows = "
		SELECT p.*
		FROM {$this->raw_products} p
		WHERE {$where_sql}
		ORDER BY {$orderby} {$order}, p.id {$order}
		LIMIT %d OFFSET %d
	";
		
		$rows_sql = $this->db->prepare( $sql_rows, array_merge( $binds, [ $per_page, $offset ] ) );
		$rows     = $this->db->get_results( $rows_sql, ARRAY_A );
		
		if ( $rows === NULL ) {
			return [
				'items'      => [],
				'pagination' => [
					'page'       => $page,
					'per_page'   => $per_page,
					'total'      => 0,
					'total_page' => 1,
				],
				'error'      => 'خطا در دریافت لیست محصولات: ' . $this->db->last_error,
			];
		}
		
		$sql_count = "
		SELECT COUNT(*)
		FROM {$this->raw_products} p
		WHERE {$where_sql}
	";
		
		$count_sql = empty( $binds ) ? $sql_count : $this->db->prepare( $sql_count, $binds );
		
		$total      = (int) $this->db->get_var( $count_sql );
		$total_page = (int) max( 1, ceil( $total / $per_page ) );
		
		$items = array_map( static function( array $r ): array {
			return [
				'id'          => (int) $r['id'],
				'category_id' => (int) $r['category_id'],
				'title'       => (string) $r['title'],
				'code'        => $r['code'] !== NULL ? (string) $r['code'] : NULL,
				'base_uom'    => (string) $r['base_uom'],
				'is_active'   => (int) $r['is_active'],
				'created_at'  => (string) $r['created_at'],
				'updated_at'  => $r['updated_at'] ? (string) $r['updated_at'] : NULL,
			];
		}, $rows );
		
		return [
			'items'      => $items,
			'pagination' => [
				'page'       => $page,
				'per_page'   => $per_page,
				'total'      => $total,
				'total_page' => $total_page,
			],
		];
	}
	
	public function get_raw_product( int $product_id ): array {
		$product_id = (int) $product_id;
		if ( $product_id <= 0 ) {
			return [
				'item'  => NULL,
				'error' => 'شناسه محصول معتبر نیست.',
			];
		}
		
		$row = $this->db->get_row(
			$this->db->prepare(
				"SELECT *
			 FROM {$this->raw_products}
			 WHERE id = %d
			 LIMIT 1",
				$product_id
			),
			ARRAY_A
		);
		
		if ( empty( $row ) ) {
			return [
				'item'  => NULL,
				'error' => 'محصول پیدا نشد.',
			];
		}
		
		return [
			'item' => [
				'id'          => (int) $row['id'],
				'category_id' => (int) $row['category_id'],
				'title'       => (string) $row['title'],
				'code'        => $row['code'] !== NULL ? (string) $row['code'] : NULL,
				'base_uom'    => (string) $row['base_uom'],
				'is_active'   => (int) $row['is_active'],
				'created_at'  => (string) $row['created_at'],
				'updated_at'  => $row['updated_at'] ? (string) $row['updated_at'] : NULL,
			],
		];
	}
	
	public function search_supplier_products( string $search, int $category_id = 0 ): array {
		$search = trim( $search );
		$where  = [];
		$params = [];
		
		if ( $search !== '' ) {
			$like     = '%' . $this->db->esc_like( $search ) . '%';
			$where[]  = '(p.title LIKE %s OR p.code LIKE %s)';
			$params[] = $like;
			$params[] = $like;
		}
		
		if ( $category_id > 0 ) {
			$where[]  = 'p.category_id = %d';
			$params[] = (int) $category_id;
		}
		
		$where_sql = $where ? ( 'WHERE ' . implode( ' AND ', $where ) ) : '';
		
		$sql = " SELECT p.* FROM {$this->raw_products} p {$where_sql} ORDER BY p.id DESC";
		
		$items = $this->db->get_results( $this->db->prepare( $sql, $params ), ARRAY_A );
		
		return $items ?: [];
	}
	
	public function search_inventory_products( string $search ): array {
		$search = trim( $search );
		
		if ( $search === '' ) {
			return [];
		}
		
		$like = '%' . $this->db->esc_like( $search ) . '%';
		
		$sql = "
		SELECT
			NULL AS inventory_id,
			NULL AS unique_product_code,
			p.ID AS wc_product_id,
			NULL AS qty_available,
			NULL AS avg_unit_cost,
			p.post_title,
			pm.meta_value AS sale_price,
			wholesale.meta_value AS wholesale_price,
			wholesale_min.meta_value AS wholesale_min_qty
		FROM {$this->db->posts} p
		LEFT JOIN {$this->db->postmeta} pm
			ON pm.post_id = p.ID
			AND pm.meta_key = '_price'
		LEFT JOIN {$this->db->postmeta} wholesale ON wholesale.post_id=p.ID AND wholesale.meta_key='_kph_wholesale_price'
		LEFT JOIN {$this->db->postmeta} wholesale_min ON wholesale_min.post_id=p.ID AND wholesale_min.meta_key='_kph_wholesale_min_qty'
		WHERE
			p.post_type = 'product'
			AND p.post_status = 'publish'
			AND p.post_title LIKE %s
		ORDER BY p.post_title ASC
		LIMIT 20
	";
		
		$items = $this->db->get_results(
			$this->db->prepare( $sql, $like ),
			ARRAY_A
		);
		
		return $items ?: [];
	}
	
	/** ---------- Ledger system ---------- */
	
	public function add_ledger_entry( array $data ): array {
		$data = wp_parse_args( $data, [
			'user_id'    => 0,
			'entry_type' => '',
			'type'       => '',
			'amount'     => 0,
			'ref_type'   => '',
			'ref_id'     => 0,
			'posted_at'  => current_time( 'mysql', TRUE ),
			'note'       => NULL,
			'meta'       => [],
		] );
		
		$user_id = (int) $data['user_id'];
		if ( $user_id <= 0 ) {
			return $this->fail( 'شناسه کاربر معتبر نیست.' );
		}
		
		$entry_type = trim( (string) $data['entry_type'] );
		if ( $entry_type === '' ) {
			return $this->fail( 'آیتم حسابداری ضروری است.' );
		}
		$types = $this->get_ledger_entry_types();
		if ( ! isset( $types[ $entry_type ] ) ) {
			return $this->fail( 'نوع آیتم حسابداری معتبر نیست.' );
		}
		
		$type = strtolower( trim( (string) $data['type'] ) );
		if ( $type === '' ) {
			return $this->fail( 'نوع بدهکار/بستانکار الزامی است.' );
		}
		$sides = $this->get_ledger_sides();
		if ( ! isset( $sides[ $type ] ) ) {
			return $this->fail( 'نوع بدهکار/بستانکار معتبر نیست.' );
		}
		
		$amount = (float) $data['amount'];
		$amount = abs( $amount );
		if ( $amount <= 0 ) {
			return $this->fail( 'مبلغ آیتم حسابداری معتبر نیست.' );
		}
		
		$ref_type = trim( (string) $data['ref_type'] );
		if ( $ref_type === '' ) {
			return $this->fail( 'نوع مرجع معتبر نیست.' );
		}
		
		$ref_id = (int) $data['ref_id'];
		if ( $ref_id <= 0 ) {
			return $this->fail( 'شناسه مرجع معتبر نیست.' );
		}
		
		$note = is_null( $data['note'] ) ? NULL : trim( (string) $data['note'] );
		if ( $note === '' ) {
			$note = NULL;
		}
		
		$insert = [
			'user_id'    => $user_id,
			'entry_type' => $entry_type,
			'type'       => $type,
			'amount'     => $amount,
			'ref_type'   => $ref_type,
			'ref_id'     => $ref_id,
			'posted_at'  => (string) $data['posted_at'],
			'created_at' => current_time( 'mysql', TRUE ),
		];
		
		$formats = [ '%d', '%s', '%s', '%f', '%s', '%d', '%s', '%s' ];
		
		if ( ! is_null( $note ) ) {
			$insert['note'] = $note;
			$formats[]      = '%s';
		}
		
		$target_visitor_id = 0;
		if ( in_array( $entry_type, [ 'customer_order', 'customer_order_return' ], TRUE ) && $ref_type === 'fulfillment' ) {
			$order = $this->db->get_row( $this->db->prepare(
				"SELECT a.* FROM {$this->orders} a INNER JOIN {$this->fulfillments} f ON f.order_id = a.id WHERE f.id = %d", $ref_id ), ARRAY_A );
			if ( ! $order ) {
				return $this->fail( 'سفارش ارسال یافت نشد.' );
			}
			$target_visitor_id = $this->get_order_visitor_id( $order );
			if ( $target_visitor_id > 0 ) {
				if ( ! $this->lock_visitor_targets( $target_visitor_id ) ) {
					return $this->fail( 'قفل تارگت دریافت نشد؛ دوباره تلاش کنید.' );
				}
				// Freeze legacy assignment when the first shipment/return is recorded.
				$assignment = $this->save_order_meta_batch( (int) $order['id'], [ 'marketer_id' => $target_visitor_id ] );
				if ( ( $assignment['status'] ?? '' ) !== 'success' || (int) ( $assignment['data']['count'] ?? 0 ) !== 1 ) {
					return $this->fail( 'ثبت ویزیتور سفارش ناموفق بود.' );
				}
			}
		}
		$ok = $this->db->insert( $this->ledger_entries, $insert, $formats );
		if ( $ok === FALSE ) {
			return $this->fail( 'خطا در ثبت آیتم حسابداری: ' . $this->db->last_error );
		}
		
		$entry_id = (int) $this->db->insert_id;
		
		$meta = is_array( $data['meta'] ) ? $data['meta'] : [];
		$meta = array_filter( $meta, static function( $v, $k ) {
			return (string) $k !== '';
		}, ARRAY_FILTER_USE_BOTH );
		
		if ( ! empty( $meta ) ) {
			$meta_res = $this->save_meta_batch( 'ledger_entry', $entry_id, $meta, TRUE );
			if ( ( $meta_res['status'] ?? '' ) !== 'success' ) {
				$this->db->delete( $this->ledger_entries, [ 'id' => $entry_id ], [ '%d' ] );
				
				return $this->fail( 'ثبت متای آیتم حسابداری با خطا مواجه شد.', $meta_res );
			}
		}
		
		if ( $target_visitor_id > 0 ) {
			$target_result = $this->sync_visitor_target_rewards( $target_visitor_id );
			if ( $target_result['status'] !== 'success' ) {
				return $target_result;
			}
		}
		
		return $this->ok( 'آیتم حسابداری با موفقیت ثبت شد.', [
			'id' => $entry_id,
		] );
	}
	
	/** Display type only: distinguish historic credit reversals from shipment debits. */
	public function get_ledger_entry_display_type( array $entry ): string {
		if ( ( $entry['entry_type'] ?? '' ) === 'customer_order'
			&& ( $entry['type'] ?? '' ) === 'credit'
			&& ( $entry['ref_type'] ?? '' ) === 'fulfillment'
			&& str_starts_with( (string) ( $entry['note'] ?? '' ), 'اصلاح بدهی مشتری بابت لغو ارسال' ) ) {
			return 'customer_order_return';
		}
		return (string) ( $entry['entry_type'] ?? '' );
	}

	public function get_ledger_entries( array $args = [] ): array {
		$args = wp_parse_args( $args, [
			'user_id'    => 0,
			'page'       => 1,
			'per_page'   => 20,
			'entry_type' => NULL,   // string|array|null
			'type'       => NULL,   // debit|credit|null
			'ref_type'   => NULL,   // string|null
			'ref_id'     => NULL,   // int|null
			'date_from'  => NULL,   // posted_at >=
			'date_to'    => NULL,   // posted_at <=
			'min_amount' => NULL,
			'max_amount' => NULL,
			'search'     => '',     // note OR id
			'orderby'    => 'created_at', // posted_at|id|amount|created_at
			'order'      => 'DESC',      // ASC|DESC
		] );
		
		$user_id = (int) $args['user_id'];
		if ( $user_id <= 0 ) {
			return [
				'items'      => [],
				'pagination' => [
					'page'       => 1,
					'per_page'   => 20,
					'total'      => 0,
					'total_page' => 1,
				],
				'error'      => 'شناسه کاربر معتبر نیست.',
			];
		}
		
		$page     = max( 1, (int) $args['page'] );
		$per_page = max( 1, min( 200, (int) $args['per_page'] ) );
		$offset   = ( $page - 1 ) * $per_page;
		
		$search = trim( (string) $args['search'] );
		
		$allowed_orderby = [
			'posted_at'  => 'l.posted_at',
			'id'         => 'l.id',
			'amount'     => 'l.amount',
			'created_at' => 'l.created_at',
		];
		$orderby         = $allowed_orderby[ (string) $args['orderby'] ] ?? 'l.posted_at';
		
		$order = strtoupper( (string) $args['order'] );
		$order = in_array( $order, [ 'ASC', 'DESC' ], TRUE ) ? $order : 'DESC';
		
		$where = [ 'l.user_id = %d' ];
		$binds = [ $user_id ];
		if ( $this->visitor_order_scope_id() ) {
			$viewer = $this->visitor_order_scope_id();
			$where[] = "(l.ref_type NOT IN ('order', 'fulfillment') OR
				(l.ref_type = 'order' AND EXISTS (SELECT 1 FROM {$this->orders} vo WHERE vo.id = l.ref_id AND vo.created_by = {$viewer})) OR
				(l.ref_type = 'fulfillment' AND EXISTS (SELECT 1 FROM {$this->fulfillments} vf INNER JOIN {$this->orders} vo ON vo.id = vf.order_id WHERE vf.id = l.ref_id AND vo.created_by = {$viewer})))";
			$where[] = "NOT EXISTS (SELECT 1 FROM {$this->db_prefix}ledger_entry_meta vm INNER JOIN {$this->orders} vo ON vo.id = CAST(vm.meta_value AS UNSIGNED)
				WHERE vm.entry_id = l.id AND vm.meta_key = 'order_id' AND vo.created_by <> {$viewer})";
		}
		
		// Group existing legacy reversal credits under the new return label for filtering.
		$effective_ledger_type = "CASE WHEN l.entry_type = 'customer_order' AND l.type = 'credit'
		 AND l.ref_type = 'fulfillment' AND l.note LIKE 'اصلاح بدهی مشتری بابت لغو ارسال%'
		 THEN 'customer_order_return' ELSE l.entry_type END";
		// entry_type (validate)
		if ( ! is_null( $args['entry_type'] ) && $args['entry_type'] !== '' ) {
			$valid_types = $this->get_ledger_entry_types();
			
			if ( is_array( $args['entry_type'] ) ) {
				$types = array_values( array_filter( array_map( 'trim', array_map( 'strval', $args['entry_type'] ) ) ) );
				$types = array_values( array_unique( $types ) );
				$types = array_values( array_filter( $types, static function( string $t ) use ( $valid_types ): bool {
					return isset( $valid_types[ $t ] );
				} ) );
				
				if ( ! empty( $types ) ) {
					$placeholders = implode( ',', array_fill( 0, count( $types ), '%s' ) );
					$where[]      = "($effective_ledger_type) IN ({$placeholders})";
					$binds        = array_merge( $binds, $types );
				}
			} else {
				$t = trim( (string) $args['entry_type'] );
				if ( isset( $valid_types[ $t ] ) ) {
					$where[] = "($effective_ledger_type) = %s";
					$binds[] = $t;
				}
			}
		}
		
		// type (debit|credit)
		if ( ! is_null( $args['type'] ) && $args['type'] !== '' ) {
			$type  = strtolower( trim( (string) $args['type'] ) );
			$sides = $this->get_ledger_sides();
			if ( isset( $sides[ $type ] ) ) {
				$where[] = 'l.type = %s';
				$binds[] = $type;
			}
		}
		
		// ref filters
		if ( ! is_null( $args['ref_type'] ) && $args['ref_type'] !== '' ) {
			$where[] = 'l.ref_type = %s';
			$binds[] = trim( (string) $args['ref_type'] );
		}
		if ( $args['ref_id'] !== NULL && $args['ref_id'] !== '' ) {
			$where[] = 'l.ref_id = %d';
			$binds[] = (int) $args['ref_id'];
		}
		
		// date range (posted_at)
		if ( ! is_null( $args['date_from'] ) && $args['date_from'] !== '' ) {
			$where[] = 'l.posted_at >= %s';
			$binds[] = (string) $args['date_from'];
		}
		if ( ! is_null( $args['date_to'] ) && $args['date_to'] !== '' ) {
			$where[] = 'l.posted_at <= %s';
			$binds[] = (string) $args['date_to'];
		}
		
		// amount range
		if ( $args['min_amount'] !== NULL && $args['min_amount'] !== '' ) {
			$where[] = 'l.amount >= %f';
			$binds[] = (float) $args['min_amount'];
		}
		if ( $args['max_amount'] !== NULL && $args['max_amount'] !== '' ) {
			$where[] = 'l.amount <= %f';
			$binds[] = (float) $args['max_amount'];
		}
		
		// search in note (and id exact)
		if ( $search !== '' ) {
			$like    = '%' . $this->db->esc_like( $search ) . '%';
			$where[] = '(l.note LIKE %s OR l.id = %d)';
			$binds[] = $like;
			$binds[] = (int) $search;
		}
		
		$where_sql = implode( ' AND ', $where );
		
		// totals on filtered set (برای net/closing)
		$sql_totals = "
		SELECT
			COALESCE(SUM(CASE WHEN l.type = 'debit' THEN l.amount ELSE 0 END), 0) AS sum_debit,
			COALESCE(SUM(CASE WHEN l.type = 'credit' THEN l.amount ELSE 0 END), 0) AS sum_credit,
			COALESCE(SUM(CASE WHEN l.type = 'debit' THEN l.amount ELSE -l.amount END), 0) AS net
		FROM {$this->ledger_entries} l
		WHERE {$where_sql}
	";
		$totals_sql = $this->db->prepare( $sql_totals, $binds );
		$totals     = (array) $this->db->get_row( $totals_sql, ARRAY_A );
		
		$sum_debit  = isset( $totals['sum_debit'] ) ? (float) $totals['sum_debit'] : 0.0;
		$sum_credit = isset( $totals['sum_credit'] ) ? (float) $totals['sum_credit'] : 0.0;
		$net_total  = isset( $totals['net'] ) ? (float) $totals['net'] : 0.0;
		
		// ids همین صفحه
		$sql_ids = "
		SELECT l.id, l.posted_at
		FROM {$this->ledger_entries} l
		WHERE {$where_sql}
		ORDER BY {$orderby} {$order}, l.id {$order}
		LIMIT %d OFFSET %d
	";
		$ids_sql = $this->db->prepare( $sql_ids, array_merge( $binds, [ $per_page, $offset ] ) );
		$ids     = $this->db->get_results( $ids_sql, ARRAY_A );
		
		if ( $ids === NULL ) {
			return [
				'items'      => [],
				'pagination' => [
					'page'       => $page,
					'per_page'   => $per_page,
					'total'      => 0,
					'total_page' => 1,
				],
				'error'      => 'خطا در دریافت لیست آیتم‌های حسابداری: ' . $this->db->last_error,
			];
		}
		
		// مجموع دلتاهای «قبل از اولین رکورد این صفحه» طبق ترتیب نمایش (sum_before)
		$sum_before = 0.0;
		
		if ( ! empty( $ids ) ) {
			$first_id     = (int) $ids[0]['id'];
			$first_posted = (string) $ids[0]['posted_at'];
			
			if ( $orderby === 'l.id' ) {
				if ( $order === 'ASC' ) {
					$opening_where = "{$where_sql} AND l.id < %d";
				} else {
					$opening_where = "{$where_sql} AND l.id > %d";
				}
				$opening_binds = array_merge( $binds, [ $first_id ] );
			} elseif ( $orderby === 'l.amount' ) {
				$first_amount = (float) $this->db->get_var(
					$this->db->prepare( "SELECT amount FROM {$this->ledger_entries} WHERE id = %d LIMIT 1", $first_id )
				);
				
				if ( $order === 'ASC' ) {
					$opening_where = "{$where_sql} AND (l.amount < %f OR (l.amount = %f AND l.id < %d))";
				} else {
					$opening_where = "{$where_sql} AND (l.amount > %f OR (l.amount = %f AND l.id > %d))";
				}
				$opening_binds = array_merge( $binds, [ $first_amount, $first_amount, $first_id ] );
			} elseif ( $orderby === 'l.created_at' ) {
				$first_created = (string) $this->db->get_var(
					$this->db->prepare( "SELECT created_at FROM {$this->ledger_entries} WHERE id = %d LIMIT 1", $first_id )
				);
				
				if ( $order === 'ASC' ) {
					$opening_where = "{$where_sql} AND (l.created_at < %s OR (l.created_at = %s AND l.id < %d))";
				} else {
					$opening_where = "{$where_sql} AND (l.created_at > %s OR (l.created_at = %s AND l.id > %d))";
				}
				$opening_binds = array_merge( $binds, [ $first_created, $first_created, $first_id ] );
			} else {
				if ( $order === 'ASC' ) {
					$opening_where = "{$where_sql} AND (l.posted_at < %s OR (l.posted_at = %s AND l.id < %d))";
				} else {
					$opening_where = "{$where_sql} AND (l.posted_at > %s OR (l.posted_at = %s AND l.id > %d))";
				}
				$opening_binds = array_merge( $binds, [ $first_posted, $first_posted, $first_id ] );
			}
			
			$sql_sum_before = "
			SELECT
				COALESCE(SUM(CASE WHEN l.type = 'debit' THEN l.amount ELSE -l.amount END), 0) AS balance
			FROM {$this->ledger_entries} l
			WHERE {$opening_where}
		";
			$sum_before     = (float) $this->db->get_var( $this->db->prepare( $sql_sum_before, $opening_binds ) );
		}
		
		// بالانس شروع صفحه بر اساس ترتیب:
		// ASC: بالانس تا قبل از اولین رکورد صفحه
		// DESC: بالانس «بعد از» اولین رکورد صفحه = net_total - مجموع رکوردهای قبل از صفحه (یعنی newer ها)
		$page_start_balance = ( $order === 'ASC' ) ? $sum_before : ( $net_total - $sum_before );
		
		// rows full
		$page_ids     = array_map( static fn( array $r ): int => (int) $r['id'], $ids );
		$placeholders = implode( ',', array_fill( 0, count( $page_ids ), '%d' ) );
		
		$sql_rows = "
		SELECT l.*
		FROM {$this->ledger_entries} l
		WHERE l.id IN ({$placeholders})
		ORDER BY {$orderby} {$order}, l.id {$order}
	";
		$rows_sql = $this->db->prepare( $sql_rows, $page_ids );
		$rows     = $this->db->get_results( $rows_sql, ARRAY_A );
		
		if ( $rows === NULL ) {
			return [
				'items'      => [],
				'pagination' => [
					'page'       => $page,
					'per_page'   => $per_page,
					'total'      => 0,
					'total_page' => 1,
				],
				'error'      => 'خطا در دریافت لیست آیتم‌های حسابداری: ' . $this->db->last_error,
			];
		}
		
		// count
		$sql_count  = "
		SELECT COUNT(*)
		FROM {$this->ledger_entries} l
		WHERE {$where_sql}
	";
		$count_sql  = $this->db->prepare( $sql_count, $binds );
		$total      = (int) $this->db->get_var( $count_sql );
		$total_page = (int) max( 1, ceil( $total / $per_page ) );
		
		$balance = (float) $page_start_balance;
		$items   = [];
		
		foreach ( $rows as $r ) {
			$amount = (float) $r['amount'];
			$delta  = ( (string) $r['type'] === 'debit' ) ? $amount : ( - 1 * $amount );
			
			if ( $order === 'ASC' ) {
				$balance += $delta;
				
				$item_balance = (float) $balance; // مانده بعد از اعمال این رکورد (ASC)
			} else {
				$item_balance = (float) $balance; // مانده بعد از اعمال این رکورد (DESC)
				$balance      -= $delta;
			}
			
			$items[] = [
				'id'         => (int) $r['id'],
				'user_id'    => (int) $r['user_id'],
				'entry_type' => $this->get_ledger_entry_display_type( $r ),
				'type'       => (string) $r['type'], // debit|credit
				'amount'     => $amount,
				'ref_type'   => (string) $r['ref_type'],
				'ref_id'     => (int) $r['ref_id'],
				'note'       => $r['note'] !== NULL ? (string) $r['note'] : NULL,
				'posted_at'  => (string) $r['posted_at'],
				'created_at' => (string) $r['created_at'],
				
				'delta'   => (float) $delta,
				'balance' => $item_balance,
			];
		}
		
		return [
			'items'      => $items,
			'pagination' => [
				'page'       => $page,
				'per_page'   => $per_page,
				'total'      => $total,
				'total_page' => $total_page,
			],
			'balances'   => [
				'opening' => (float) $page_start_balance,
				'closing' => (float) $balance,
			],
			'totals'     => [
				'sum_debit'  => $sum_debit,
				'sum_credit' => $sum_credit,
				'net'        => $net_total,
			],
		];
	}
	
	public function get_ledger_entries_by_order_number( string $order_number ): array {
		$order_number = trim( $order_number );
		
		if ( $order_number === '' ) {
			return $this->fail( 'شماره سفارش نامعتبر است.' );
		}
		
		// گرفتن ledger_id ها از meta
		$ledger_ids = $this->db->get_col(
			$this->db->prepare(
				"SELECT entry_id
			 FROM {$this->db_prefix}ledger_entry_meta
			 WHERE meta_key = 'order_id'
			 AND meta_value = %s",
				$order_number
			)
		);
		if ( empty( $ledger_ids ) ) {
			return $this->ok(
				'تراکنشی برای این سفارش یافت نشد.',
				[
					'items' => [],
				]
			);
		}
		
		$placeholders = implode( ',', array_fill( 0, count( $ledger_ids ), '%d' ) );
		
		$rows = $this->db->get_results(
			$this->db->prepare(
				"SELECT *
			 FROM {$this->ledger_entries}
			 WHERE id IN ({$placeholders})
			 ORDER BY created_at DESC",
				$ledger_ids
			),
			ARRAY_A
		);
		
		if ( $rows === NULL ) {
			return $this->fail( 'خطا در دریافت تراکنش‌ها.' );
		}
		
		return $this->ok(
			'تراکنش‌ها با موفقیت دریافت شد.',
			[
				'items' => $rows,
			]
		);
	}
	
	public function get_user_ids_by_ledger_balance_side( string $side ): array {
		$side = strtolower( trim( $side ) );
		
		if ( ! in_array( $side, [ 'debit', 'credit' ], TRUE ) ) {
			return [];
		}
		
		$operator = $side === 'debit' ? '>' : '<';
		
		$sql = "
		SELECT l.user_id
		FROM {$this->ledger_entries} l
		GROUP BY l.user_id
		HAVING COALESCE(SUM(CASE WHEN l.type = 'debit' THEN l.amount ELSE -l.amount END), 0) {$operator} 0
	";
		
		$user_ids = $this->db->get_col( $sql );
		
		if ( empty( $user_ids ) ) {
			return [];
		}
		
		return array_map( 'intval', $user_ids );
	}
	
	public function get_ledger_balance_now( int $user_id, array $filters = [] ): array {
		$user_id = (int) $user_id;
		if ( $user_id <= 0 ) {
			return [
				'balance' => 0,
				'error'   => 'شناسه کاربر معتبر نیست.',
			];
		}
		
		$filters = wp_parse_args( $filters, [
			'entry_type' => NULL,
			'type'       => NULL,
			'ref_type'   => NULL,
			'ref_id'     => NULL,
			'date_to'    => NULL, // تا همین لحظه
		] );
		
		$where = [ 'l.user_id = %d' ];
		$binds = [ $user_id ];
		
		// entry_type validate
		if ( ! is_null( $filters['entry_type'] ) && $filters['entry_type'] !== '' ) {
			$valid_types = $this->get_ledger_entry_types();
			if ( is_array( $filters['entry_type'] ) ) {
				$types = array_values( array_filter( array_map( 'trim', array_map( 'strval', $filters['entry_type'] ) ) ) );
				$types = array_values( array_unique( $types ) );
				$types = array_values( array_filter( $types, static function( string $t ) use ( $valid_types ): bool {
					return isset( $valid_types[ $t ] );
				} ) );
				if ( ! empty( $types ) ) {
					$placeholders = implode( ',', array_fill( 0, count( $types ), '%s' ) );
					$where[]      = "l.entry_type IN ({$placeholders})";
					$binds        = array_merge( $binds, $types );
				}
			} else {
				$t = trim( (string) $filters['entry_type'] );
				if ( isset( $valid_types[ $t ] ) ) {
					$where[] = 'l.entry_type = %s';
					$binds[] = $t;
				}
			}
		}
		
		if ( ! is_null( $filters['type'] ) && $filters['type'] !== '' ) {
			$type  = strtolower( trim( (string) $filters['type'] ) );
			$sides = $this->get_ledger_sides();
			if ( isset( $sides[ $type ] ) ) {
				$where[] = 'l.type = %s';
				$binds[] = $type;
			}
		}
		
		if ( ! is_null( $filters['ref_type'] ) && $filters['ref_type'] !== '' ) {
			$where[] = 'l.ref_type = %s';
			$binds[] = trim( (string) $filters['ref_type'] );
		}
		if ( $filters['ref_id'] !== NULL && $filters['ref_id'] !== '' ) {
			$where[] = 'l.ref_id = %d';
			$binds[] = (int) $filters['ref_id'];
		}
		
		if ( ! is_null( $filters['date_to'] ) && $filters['date_to'] !== '' ) {
			$where[] = 'l.posted_at <= %s';
			$binds[] = (string) $filters['date_to'];
		}
		
		$where_sql = implode( ' AND ', $where );
		
		$sql     = "
			SELECT
				COALESCE(SUM(CASE WHEN l.type = 'debit' THEN l.amount ELSE -l.amount END), 0) AS balance
			FROM {$this->ledger_entries} l
			WHERE {$where_sql}
		";
		$balance = (float) $this->db->get_var( $this->db->prepare( $sql, $binds ) );
		
		return [
			'balance' => $balance,
		];
	}
	
	public function get_ledger_balance_range( int $user_id, string $date_from, string $date_to, array $filters = [] ): array {
		$user_id = (int) $user_id;
		if ( $user_id <= 0 ) {
			return [
				'balance' => 0,
				'error'   => 'شناسه کاربر معتبر نیست.',
			];
		}
		
		$date_from = trim( $date_from );
		$date_to   = trim( $date_to );
		if ( $date_from === '' || $date_to === '' ) {
			return [
				'balance' => 0,
				'error'   => 'بازه زمانی معتبر نیست.',
			];
		}
		
		$filters = wp_parse_args( $filters, [
			'entry_type' => NULL,
			'type'       => NULL,
			'ref_type'   => NULL,
			'ref_id'     => NULL,
		] );
		
		$where = [
			'l.user_id = %d',
			'l.posted_at >= %s',
			'l.posted_at <= %s',
		];
		$binds = [ $user_id, $date_from, $date_to ];
		
		// entry_type validate
		if ( ! is_null( $filters['entry_type'] ) && $filters['entry_type'] !== '' ) {
			$valid_types = $this->get_ledger_entry_types();
			if ( is_array( $filters['entry_type'] ) ) {
				$types = array_values( array_filter( array_map( 'trim', array_map( 'strval', $filters['entry_type'] ) ) ) );
				$types = array_values( array_unique( $types ) );
				$types = array_values( array_filter( $types, static function( string $t ) use ( $valid_types ): bool {
					return isset( $valid_types[ $t ] );
				} ) );
				if ( ! empty( $types ) ) {
					$placeholders = implode( ',', array_fill( 0, count( $types ), '%s' ) );
					$where[]      = "l.entry_type IN ({$placeholders})";
					$binds        = array_merge( $binds, $types );
				}
			} else {
				$t = trim( (string) $filters['entry_type'] );
				if ( isset( $valid_types[ $t ] ) ) {
					$where[] = 'l.entry_type = %s';
					$binds[] = $t;
				}
			}
		}
		
		if ( ! is_null( $filters['type'] ) && $filters['type'] !== '' ) {
			$type  = strtolower( trim( (string) $filters['type'] ) );
			$sides = $this->get_ledger_sides();
			if ( isset( $sides[ $type ] ) ) {
				$where[] = 'l.type = %s';
				$binds[] = $type;
			}
		}
		
		if ( ! is_null( $filters['ref_type'] ) && $filters['ref_type'] !== '' ) {
			$where[] = 'l.ref_type = %s';
			$binds[] = trim( (string) $filters['ref_type'] );
		}
		if ( $filters['ref_id'] !== NULL && $filters['ref_id'] !== '' ) {
			$where[] = 'l.ref_id = %d';
			$binds[] = (int) $filters['ref_id'];
		}
		
		$where_sql = implode( ' AND ', $where );
		
		$sql = "
			SELECT
				COALESCE(SUM(CASE WHEN l.type = 'debit' THEN l.amount ELSE -l.amount END), 0) AS balance
			FROM {$this->ledger_entries} l
			WHERE {$where_sql}
		";
		
		$balance = (float) $this->db->get_var( $this->db->prepare( $sql, $binds ) );
		
		return [
			'balance' => $balance,
		];
	}
	
	/** ---------- Payment - Transfer - Cheque - system ---------- */
	public function add_payment( array $data ): array {
        if (($data['payment_method'] ?? '') === 'customer_freight') return (new kph_customer_freight($this))->add($data);
		$data = wp_parse_args( $data, [
			'user_id'        => 0,
			'amount'         => 0, // always positive
			'type'           => '', // debit|credit (required)
			'payment_method' => 'other',
			'paid_at'        => '',
			'note'           => NULL,
			'ref_id'         => 0,
			'meta'           => [],
		] );
		
		$user_id = (int) $data['user_id'];
		if ( $user_id <= 0 ) {
			return $this->fail( 'شناسه کاربر معتبر نیست.' );
		}
		
		$amount = (float) $data['amount'];
		if ( $amount <= 0 ) {
			return $this->fail( 'مبلغ پرداخت معتبر نیست.' );
		}
		$amount = abs( $amount );
		
		$type = strtolower( trim( (string) $data['type'] ) );
		if ( $type === '' ) {
			return $this->fail( 'نوع بدهکار/بستانکار الزامی است.' );
		}
		$sides = $this->get_ledger_sides();
		if ( ! isset( $sides[ $type ] ) ) {
			return $this->fail( 'نوع بدهکار/بستانکار معتبر نیست.' );
		}
		
		$payment_method = strtolower( trim( (string) $data['payment_method'] ) );
		$methods        = $this->get_payment_methods();
		if ( $payment_method === '' || ! isset( $methods[ $payment_method ] ) ) {
			return $this->fail( 'روش پرداخت معتبر نیست.' );
		}
		
		$paid_at = trim( (string) $data['paid_at'] );
		if ( $paid_at === '' ) {
			$paid_at = current_time( 'mysql', TRUE );
		} else {
			$ts = strtotime( $paid_at );
			if ( ! $ts ) {
				return $this->fail( 'تاریخ پرداخت معتبر نیست.' );
			}
			$paid_at = gmdate( 'Y-m-d H:i:s', $ts );
		}
		
		$note = is_null( $data['note'] ) ? NULL : trim( (string) $data['note'] );
		if ( $note === '' ) {
			$note = NULL;
		}
		
		$ref_id = (int) $data['ref_id'];
		if ( $ref_id < 0 ) {
			$ref_id = 0;
		}
		
		$meta = is_array( $data['meta'] ) ? $data['meta'] : [];
		$meta = array_filter( $meta, static function( $v, $k ) {
			return (string) $k !== '';
		}, ARRAY_FILTER_USE_BOTH );
		
		// keep signed amount in db for easier reporting
		$signed_amount = ( $type === 'credit' ) ? ( - 1 * $amount ) : $amount;
		
		$this->db->query( 'START TRANSACTION' );
        $invoice_guard = $this->lock_supplier_invoice_reference($user_id, $ref_id);
        if (($invoice_guard['status'] ?? '') !== 'success') {
            $this->db->query('ROLLBACK');
            return $invoice_guard;
        }

		
		$insert = [
			'user_id'        => $user_id,
			'amount'         => $signed_amount,
			'payment_method' => $payment_method,
			'paid_at'        => $paid_at,
			'ref_id'         => ( $ref_id > 0 ? $ref_id : NULL ),
			'created_at'     => current_time( 'mysql', TRUE ),
			'updated_at'     => NULL,
		];
		if ( is_null( $insert['ref_id'] ) ) {
			unset( $insert['ref_id'] );
		}
		
		if ( ! is_null( $note ) ) {
			$insert['note'] = $note;
		}
		
		$ok = $this->db->insert( $this->payments, $insert );
		if ( $ok === FALSE ) {
			$this->db->query( 'ROLLBACK' );
			
			return $this->fail( 'خطا در ثبت پرداخت: ' . $this->db->last_error );
		}
		
		$payment_id = (int) $this->db->insert_id;
		
		if ( ! empty( $meta ) ) {
			$meta_res = $this->save_payment_meta_batch( $payment_id, $meta, TRUE );
			if ( ( $meta_res['status'] ?? '' ) !== 'success' ) {
				$this->db->query( 'ROLLBACK' );
				
				return $this->fail( 'ثبت متای پرداخت با خطا مواجه شد.', $meta_res );
			}
		}
		
		$ledger_res = $this->add_ledger_entry( [
			'user_id'    => $user_id,
			'entry_type' => 'submit_payment',
			'type'       => $type,
			'amount'     => $amount,
			'ref_type'   => 'payment',
			'ref_id'     => $payment_id,
			'posted_at'  => $paid_at,
			'note'       => ( $type === 'credit' ? 'ثبت دریافت #' : 'ثبت پرداخت #' ) . $payment_id,
			'meta'       => array_merge( [
				'signed_amount' => $signed_amount,
			], $meta ),
		] );
		
		if ( ( $ledger_res['status'] ?? '' ) !== 'success' ) {
			$this->db->query( 'ROLLBACK' );
			
			return $this->fail( 'ثبت آیتم حسابداری فاکتور تاییدشده با خطا مواجه شد.', $ledger_res );
		}
		
		$this->db->query( 'COMMIT' );
		do_action( 'kph_payment_added', $payment_id, [
			'user_id'        => $user_id,
			'amount'         => $amount,
			'type'           => $type,
			'payment_method' => $payment_method,
			'paid_at'        => $paid_at,
			'ref_id'         => $ref_id,
			'meta'           => $meta,
		], $ledger_res );
		
		return $this->ok( 'پرداخت با موفقیت ثبت شد.', [
			'id'        => $payment_id,
			'ledger_id' => (int) ( $ledger_res['data']['id'] ?? 0 ),
		] );
	}
	
	public function delete_payment( int $payment_id ): array {
        if ($this->get_payment_meta($payment_id, 'payment_purpose') === 'customer_freight') return (new kph_customer_freight($this))->delete($payment_id);
		if ( $this->get_payment_meta( $payment_id, 'hr_record_id' ) || ( function_exists( 'kph_hr_financial_protected' ) && kph_hr_financial_protected( 'payment', $payment_id ) ) ) {
			return $this->fail( 'پرداخت پرسنل را از پرونده کارگزینی ابطال کنید.' );
		}
		$payment_id = (int) $payment_id;
		
		if ( $payment_id <= 0 ) {
			return $this->fail( 'شناسه پرداخت معتبر نیست.' );
		}
		
		$payment = $this->db->get_row(
			$this->db->prepare(
				"SELECT *
			FROM {$this->payments}
			WHERE id = %d
			LIMIT 1",
				$payment_id
			),
			ARRAY_A
		);
		
		if ( ! $payment ) {
			return $this->fail( 'پرداخت یافت نشد.' );
		}
		
		$this->db->query( 'START TRANSACTION' );
		
		// حذف آیتم‌های حسابداری مرتبط با پرداخت
		$ledger_ids = $this->db->get_col(
			$this->db->prepare(
				"SELECT id
			FROM {$this->ledger_entries}
			WHERE ref_type = %s
				AND ref_id = %d",
				'payment',
				$payment_id
			)
		);
		
		if ( ! empty( $ledger_ids ) ) {
			foreach ( $ledger_ids as $ledger_id ) {
				$ledger_id = (int) $ledger_id;
				
				$ledger_meta_res = $this->delete_ledger_entry_meta( $ledger_id );
				
				if ( ( $ledger_meta_res['status'] ?? '' ) !== 'success' ) {
					$this->db->query( 'ROLLBACK' );
					
					return $this->fail( 'حذف متای آیتم حسابداری پرداخت با خطا مواجه شد.', $ledger_meta_res );
				}
			}
			
			$ledger_placeholders = implode( ',', array_fill( 0, count( $ledger_ids ), '%d' ) );
			
			$deleted_ledger = $this->db->query(
				$this->db->prepare(
					"DELETE FROM {$this->ledger_entries}
				WHERE id IN ({$ledger_placeholders})",
					array_map( 'intval', $ledger_ids )
				)
			);
			
			if ( $deleted_ledger === FALSE ) {
				$this->db->query( 'ROLLBACK' );
				
				return $this->fail( 'حذف آیتم‌های حسابداری پرداخت با خطا مواجه شد: ' . $this->db->last_error );
			}
		}
		
		// حذف متای پرداخت
		$payment_meta_res = $this->delete_payment_meta( $payment_id );
		
		if ( ( $payment_meta_res['status'] ?? '' ) !== 'success' ) {
			$this->db->query( 'ROLLBACK' );
			
			return $this->fail( 'حذف متای پرداخت با خطا مواجه شد.', $payment_meta_res );
		}
		
		// حذف خود پرداخت
		$deleted_payment = $this->db->delete(
			$this->payments,
			[ 'id' => $payment_id ],
			[ '%d' ]
		);
		
		if ( $deleted_payment === FALSE ) {
			$this->db->query( 'ROLLBACK' );
			
			return $this->fail( 'حذف پرداخت با خطا مواجه شد: ' . $this->db->last_error );
		}
		
		$this->db->query( 'COMMIT' );
		
		return $this->ok( 'پرداخت و تراکنش‌های مرتبط با موفقیت حذف شدند.', [
			'payment_id'             => $payment_id,
			'deleted_ledger_entries' => count( $ledger_ids ),
		] );
	}
	
	public function get_payments_list( array $args = [] ): array {
		$args = wp_parse_args( $args, [
			'user_id'        => 0,
			'page'           => 1,
			'per_page'       => 20,
			'payment_method' => NULL, // string|array|null
			'ref_id'         => NULL, // int|null
			'date_from'      => NULL, // paid_at >=
			'date_to'        => NULL, // paid_at <=
			'min_amount'     => NULL,
			'max_amount'     => NULL,
			'search'         => '',   // note OR id
			'orderby'        => 'paid_at', // paid_at|id|amount|created_at
			'order'          => 'DESC',    // ASC|DESC
		] );
		
		$user_id = (int) $args['user_id'];
		if ( $user_id <= 0 ) {
			return [
				'items'      => [],
				'pagination' => [
					'page'       => 1,
					'per_page'   => 20,
					'total'      => 0,
					'total_page' => 1,
				],
				'error'      => 'شناسه کاربر معتبر نیست.',
			];
		}
		
		$page     = max( 1, (int) $args['page'] );
		$per_page = max( 1, min( 200, (int) $args['per_page'] ) );
		$offset   = ( $page - 1 ) * $per_page;
		
		$search = trim( (string) $args['search'] );
		
		$allowed_orderby = [
			'paid_at'    => 'p.paid_at',
			'id'         => 'p.id',
			'amount'     => 'p.amount',
			'created_at' => 'p.created_at',
		];
		$orderby         = $allowed_orderby[ (string) $args['orderby'] ] ?? 'p.paid_at';
		
		$order = strtoupper( (string) $args['order'] );
		$order = in_array( $order, [ 'ASC', 'DESC' ], TRUE ) ? $order : 'DESC';
		
		$where = [ 'p.user_id = %d' ];
		$binds = [ $user_id ];
		
        // Freight is a payment purpose stored in meta; keep the historic payment_method ENUM unchanged.
        $freight_meta="EXISTS (SELECT 1 FROM {$this->db_prefix}payment_meta pf WHERE pf.payment_id=p.id AND pf.meta_key='payment_purpose' AND pf.meta_value='customer_freight')";
        if ($args['payment_method'] !== NULL && $args['payment_method'] !== '') {
            $methods = array_values(array_intersect(array_map('strval',(array)$args['payment_method']),array_keys($this->get_payment_methods())));
            $clauses=[];
            foreach(array_unique($methods) as $method){
                if($method==='customer_freight') $clauses[]=$freight_meta;
                elseif($method==='other') $clauses[]="(p.payment_method='other' AND NOT $freight_meta)";
                else { $clauses[]='p.payment_method=%s'; $binds[]=$method; }
            }
            if($clauses)$where[]='('.implode(' OR ',$clauses).')';
        }

		// ref_id
		if ( $args['ref_id'] !== NULL && $args['ref_id'] !== '' ) {
			$where[] = 'p.ref_id = %d';
			$binds[] = (int) $args['ref_id'];
		}
		
		// date range (paid_at)
		if ( ! is_null( $args['date_from'] ) && $args['date_from'] !== '' ) {
			$where[] = 'p.paid_at >= %s';
			$binds[] = (string) $args['date_from'];
		}
		if ( ! is_null( $args['date_to'] ) && $args['date_to'] !== '' ) {
			$where[] = 'p.paid_at <= %s';
			$binds[] = (string) $args['date_to'];
		}
		
		// amount range
		if ( $args['min_amount'] !== NULL && $args['min_amount'] !== '' ) {
			$where[] = 'p.amount >= %f';
			$binds[] = (float) $args['min_amount'];
		}
		if ( $args['max_amount'] !== NULL && $args['max_amount'] !== '' ) {
			$where[] = 'p.amount <= %f';
			$binds[] = (float) $args['max_amount'];
		}
		
		// search in note (and id exact)
		if ( $search !== '' ) {
			$like    = '%' . $this->db->esc_like( $search ) . '%';
			$where[] = '(p.note LIKE %s OR p.id = %d)';
			$binds[] = $like;
			$binds[] = (int) $search;
		}
		
		$where_sql = implode( ' AND ', $where );
		
		// ids for page
		$sql_ids = "
		SELECT p.id, p.paid_at
		FROM {$this->payments} p
		WHERE {$where_sql}
		ORDER BY {$orderby} {$order}, p.id {$order}
		LIMIT %d OFFSET %d
	";
		$ids_sql = $this->db->prepare( $sql_ids, array_merge( $binds, [ $per_page, $offset ] ) );
		$ids     = $this->db->get_results( $ids_sql, ARRAY_A );
		
		if ( $ids === NULL ) {
			return [
				'items'      => [],
				'pagination' => [
					'page'       => $page,
					'per_page'   => $per_page,
					'total'      => 0,
					'total_page' => 1,
				],
				'error'      => 'خطا در دریافت لیست پرداخت‌ها: ' . $this->db->last_error,
			];
		}
		
		$opening_balance = 0.0;
		if ( ! empty( $ids ) ) {
			$first_id   = (int) $ids[0]['id'];
			$first_paid = (string) $ids[0]['paid_at'];
			
			if ( $orderby === 'p.id' ) {
				$opening_where = "{$where_sql} AND p.id < %d";
				$opening_binds = array_merge( $binds, [ $first_id ] );
			} elseif ( $orderby === 'p.amount' ) {
				$first_amount = (float) $this->db->get_var(
					$this->db->prepare( "SELECT amount FROM {$this->payments} WHERE id = %d LIMIT 1", $first_id )
				);
				if ( $order === 'ASC' ) {
					$opening_where = "{$where_sql} AND (p.amount < %f OR (p.amount = %f AND p.id < %d))";
				} else {
					$opening_where = "{$where_sql} AND (p.amount > %f OR (p.amount = %f AND p.id > %d))";
				}
				$opening_binds = array_merge( $binds, [ $first_amount, $first_amount, $first_id ] );
			} elseif ( $orderby === 'p.created_at' ) {
				$first_created = (string) $this->db->get_var(
					$this->db->prepare( "SELECT created_at FROM {$this->payments} WHERE id = %d LIMIT 1", $first_id )
				);
				if ( $order === 'ASC' ) {
					$opening_where = "{$where_sql} AND (p.created_at < %s OR (p.created_at = %s AND p.id < %d))";
				} else {
					$opening_where = "{$where_sql} AND (p.created_at > %s OR (p.created_at = %s AND p.id > %d))";
				}
				$opening_binds = array_merge( $binds, [ $first_created, $first_created, $first_id ] );
			} else {
				// paid_at
				if ( $order === 'ASC' ) {
					$opening_where = "{$where_sql} AND (p.paid_at < %s OR (p.paid_at = %s AND p.id < %d))";
				} else {
					$opening_where = "{$where_sql} AND (p.paid_at > %s OR (p.paid_at = %s AND p.id > %d))";
				}
				$opening_binds = array_merge( $binds, [ $first_paid, $first_paid, $first_id ] );
			}
			
			$sql_open        = "
			SELECT COALESCE(SUM(p.amount), 0) AS balance
			FROM {$this->payments} p
			WHERE {$opening_where}
		";
			$opening_balance = (float) $this->db->get_var( $this->db->prepare( $sql_open, $opening_binds ) );
		}
		
		$page_ids     = array_map( static fn( array $r ): int => (int) $r['id'], $ids );
		$placeholders = implode( ',', array_fill( 0, count( $page_ids ), '%d' ) );
		
		$sql_rows = "
		SELECT p.*
		FROM {$this->payments} p
		WHERE p.id IN ({$placeholders})
		ORDER BY {$orderby} {$order}, p.id {$order}
	";
		$rows_sql = $this->db->prepare( $sql_rows, $page_ids );
		$rows     = $this->db->get_results( $rows_sql, ARRAY_A );
		
		if ( $rows === NULL ) {
			return [
				'items'      => [],
				'pagination' => [
					'page'       => $page,
					'per_page'   => $per_page,
					'total'      => 0,
					'total_page' => 1,
				],
				'error'      => 'خطا در دریافت لیست پرداخت‌ها: ' . $this->db->last_error,
			];
		}
		
		// count
		$sql_count  = "
		SELECT COUNT(*)
		FROM {$this->payments} p
		WHERE {$where_sql}
	";
		$count_sql  = $this->db->prepare( $sql_count, $binds );
		$total      = (int) $this->db->get_var( $count_sql );
		$total_page = (int) max( 1, ceil( $total / $per_page ) );
		
		// running balance: sum of signed payment amounts
		$balance = $opening_balance;
		$items   = [];
		
		foreach ( $rows as $r ) {
			$amt     = (float) $r['amount'];
			$balance += $amt;
			
			$items[] = [
				'id'             => (int) $r['id'],
				'user_id'        => $r['user_id'] !== NULL ? (int) $r['user_id'] : 0,
				'amount'         => (float) $amt,
				'payment_method' => $this->get_payment_meta((int)$r['id'],'payment_purpose') === 'customer_freight' ? 'customer_freight' : (string) $r['payment_method'],
				'paid_at'        => (string) $r['paid_at'],
				'note'           => $r['note'] !== NULL ? (string) $r['note'] : NULL,
				'ref_id'         => $r['ref_id'] !== NULL ? (int) $r['ref_id'] : 0,
				'created_at'     => (string) $r['created_at'],
				'updated_at'     => $r['updated_at'] !== NULL ? (string) $r['updated_at'] : NULL,
				
				'balance' => (float) $balance,
				'delta'   => (float) $amt,
			];
		}
		
		// totals on filtered set
		$sql_totals = "
		SELECT
			COALESCE(SUM(CASE WHEN p.amount > 0 THEN p.amount ELSE 0 END), 0) AS sum_out,
			COALESCE(SUM(CASE WHEN p.amount < 0 THEN -p.amount ELSE 0 END), 0) AS sum_in,
			COALESCE(SUM(p.amount), 0) AS net
		FROM {$this->payments} p
		WHERE {$where_sql}
	";
		$totals_sql = $this->db->prepare( $sql_totals, $binds );
		$totals     = (array) $this->db->get_row( $totals_sql, ARRAY_A );
		
		return [
			'items'      => $items,
			'pagination' => [
				'page'       => $page,
				'per_page'   => $per_page,
				'total'      => $total,
				'total_page' => $total_page,
			],
			'balances'   => [
				'opening' => (float) $opening_balance,
				'closing' => (float) $balance,
			],
			'totals'     => [
				'sum_out' => isset( $totals['sum_out'] ) ? (float) $totals['sum_out'] : 0,
				'sum_in'  => isset( $totals['sum_in'] ) ? (float) $totals['sum_in'] : 0,
				'net'     => isset( $totals['net'] ) ? (float) $totals['net'] : 0,
			],
		];
	}
	
	public function add_transfer( array $data, bool $inside_transaction = false ): array {
		$data = wp_parse_args( $data, [
			'user_id'        => 0,
			'amount'         => 0,
			'transferred_at' => '',
			'tracking_no'    => '',
			'bank_name'      => '',
			'note'           => NULL,
			'ref_id'         => 0,
			'meta'           => [],
		] );
		
		$user_id = (int) $data['user_id'];
		if ( $user_id <= 0 ) {
			return $this->fail( 'شناسه کاربر معتبر نیست.' );
		}
		
		$amount      = (float) $data['amount'];
		$transfer_at = trim( (string) $data['transferred_at'] );
		
		if ( $transfer_at === '' ) {
			$transfer_at = current_time( 'mysql', TRUE );
		} else {
			$ts = strtotime( $transfer_at );
			if ( ! $ts ) {
				return $this->fail( 'تاریخ حواله معتبر نیست.' );
			}
			$transfer_at = gmdate( 'Y-m-d H:i:s', $ts );
		}
		
		$note = is_null( $data['note'] ) ? NULL : trim( (string) $data['note'] );
		if ( $note === '' ) {
			$note = NULL;
		}
		
		$ref_id = (int) $data['ref_id'];
		if ( $ref_id < 0 ) {
			$ref_id = 0;
		}
		
		$meta = is_array( $data['meta'] ) ? $data['meta'] : [];
		$meta = array_filter( $meta, static function( $v, $k ) {
			return (string) $k !== '';
		}, ARRAY_FILTER_USE_BOTH );
		
		if(!$inside_transaction && false===$this->db->query('START TRANSACTION'))return $this->fail('شروع ثبت حواله ناموفق بود.');
        $invoice_guard = $this->lock_supplier_invoice_reference($user_id, $ref_id);
        if (($invoice_guard['status'] ?? '') !== 'success') {
            $this->db->query('ROLLBACK');
            return $invoice_guard;
        }

		
		$insert = [
			'user_id'        => $user_id,
			'amount'         => $amount,
			'transferred_at' => $transfer_at,
			'bank_name'      => $data['bank_name'],
			'tracking_no'    => $data['tracking_no'],
			'created_at'     => current_time( 'mysql', TRUE ),
			'updated_at'     => NULL,
			'ref_id'         => ( $ref_id > 0 ? $ref_id : NULL ),
		];
		
		if ( is_null( $insert['ref_id'] ) ) {
			unset( $insert['ref_id'] );
		}
		
		if ( ! is_null( $note ) ) {
			$insert['note'] = $note;
		}
		
		$ok = $this->db->insert( $this->transfers, $insert );
		if ( $ok === FALSE ) {
			$this->db->query( 'ROLLBACK' );
			
			return $this->fail( 'خطا در ثبت حواله: ' . $this->db->last_error );
		}
		
		$transfer_id = (int) $this->db->insert_id;
		
		if ( ! empty( $meta ) ) {
			$meta_res = $this->save_transfer_meta_batch( $transfer_id, $meta, TRUE );
			if ( ( $meta_res['status'] ?? '' ) !== 'success' ) {
				$this->db->query( 'ROLLBACK' );
				
				return $this->fail( 'ثبت متای حواله با خطا مواجه شد.', $meta_res );
			}
		}
		
		$ledger_res = $this->add_ledger_entry( [
			'user_id'    => $user_id,
			'entry_type' => 'submit_transfer',
			'type'       => $amount > 0 ? 'debit' : 'credit',
			'amount'     => $amount,
			'ref_type'   => 'transfer',
			'ref_id'     => $transfer_id,
			'posted_at'  => $transfer_at,
			'note'       => 'ثبت حواله #' . $transfer_id,
		] );
		
		if ( ( $ledger_res['status'] ?? '' ) !== 'success' ) {
			$this->db->query( 'ROLLBACK' );
			
			return $this->fail( 'ثبت آیتم حسابداری حواله با خطا مواجه شد.', $ledger_res );
		}
		
		if(!$inside_transaction && false===$this->db->query('COMMIT')){$this->db->query('ROLLBACK');return $this->fail('ثبت نهایی حواله ناموفق بود.');}
		
		if(!$inside_transaction)do_action( 'kph_transfer_added', $transfer_id, [
			'user_id'        => $user_id,
			'amount'         => $amount,
			'transferred_at' => $transfer_at,
			'bank_name'      => $data['bank_name'],
			'tracking_no'    => $data['tracking_no'],
			'ref_id'         => $ref_id,
			'meta'           => $meta,
		], $ledger_res );
		
		return $this->ok( 'حواله با موفقیت ثبت شد.', [
			'id'        => $transfer_id,
			'ledger_id' => (int) ( $ledger_res['data']['id'] ?? 0 ),
            '_hook_data'=>$inside_transaction ? ['user_id'=>$user_id,'amount'=>$amount,'transferred_at'=>$transfer_at,'bank_name'=>$data['bank_name'],'tracking_no'=>$data['tracking_no'],'ref_id'=>$ref_id,'meta'=>$meta] : null,
		] );
	}
	
	public function delete_transfer( int $transfer_id ): array {
		if ( $this->get_transfer_meta( $transfer_id, 'hr_record_id' ) || ( function_exists( 'kph_hr_financial_protected' ) && kph_hr_financial_protected( 'transfer', $transfer_id ) ) ) {
			return $this->fail( 'حواله پرسنل را از پرونده کارگزینی ابطال کنید.' );
		}
		$transfer_id = (int) $transfer_id;
		
		if ( $transfer_id <= 0 ) {
			return $this->fail( 'شناسه حواله معتبر نیست.' );
		}
		
		$transfer = $this->db->get_row(
			$this->db->prepare(
				"SELECT *
			FROM {$this->transfers}
			WHERE id = %d
			LIMIT 1",
				$transfer_id
			),
			ARRAY_A
		);
		
		if ( ! $transfer ) {
			return $this->fail( 'حواله یافت نشد.' );
		}
		
		$this->db->query( 'START TRANSACTION' );
		
		// حذف آیتم‌های حسابداری مرتبط با حواله
		$ledger_ids = $this->db->get_col(
			$this->db->prepare(
				"SELECT id
			FROM {$this->ledger_entries}
			WHERE ref_type = %s
				AND ref_id = %d",
				'transfer',
				$transfer_id
			)
		);
		
		if ( ! empty( $ledger_ids ) ) {
			foreach ( $ledger_ids as $ledger_id ) {
				$ledger_id = (int) $ledger_id;
				
				$meta_res = $this->delete_ledger_entry_meta( $ledger_id );
				
				if ( ( $meta_res['status'] ?? '' ) !== 'success' ) {
					$this->db->query( 'ROLLBACK' );
					
					return $this->fail( 'حذف متای آیتم حسابداری حواله با خطا مواجه شد.', $meta_res );
				}
			}
			
			$ledger_placeholders = implode( ',', array_fill( 0, count( $ledger_ids ), '%d' ) );
			
			$deleted_ledger = $this->db->query(
				$this->db->prepare(
					"DELETE FROM {$this->ledger_entries}
				WHERE id IN ({$ledger_placeholders})",
					array_map( 'intval', $ledger_ids )
				)
			);
			
			if ( $deleted_ledger === FALSE ) {
				$this->db->query( 'ROLLBACK' );
				
				return $this->fail( 'حذف آیتم‌های حسابداری حواله با خطا مواجه شد: ' . $this->db->last_error );
			}
		}
		
		// حذف تراکنش‌های حساب مرتبط با حواله، اگر در نسخه‌های بعدی/قبلی ثبت شده باشند
		[ $trx_meta_table, $trx_meta_fk ] = $this->resolve_meta_table( 'account_transaction' );
		
		$account_transactions = $this->db->get_results(
			$this->db->prepare(
				"SELECT DISTINCT t.*
			FROM {$this->account_transactions} t
			LEFT JOIN {$trx_meta_table} tm
				ON tm.{$trx_meta_fk} = t.id
			WHERE
				(
					t.action IN (%s, %s)
					AND t.description = %s
				)
				OR
				(
					tm.meta_key = %s
					AND tm.meta_value = %s
				)
				OR
				(
					tm.meta_key = %s
					AND tm.meta_value = %s
				)",
				'submit_transfer',
				'transfer',
				'ثبت حواله #' . $transfer_id,
				'transfer_id',
				(string) $transfer_id,
				'ref_id',
				(string) $transfer_id
			),
			ARRAY_A
		);
		
		if ( ! empty( $account_transactions ) ) {
			foreach ( $account_transactions as $transaction ) {
				$transaction_id = (int) $transaction['id'];
				$account_id     = (int) $transaction['account_id'];
				$amount         = abs( (int) $transaction['amount'] );
				$type           = (string) $transaction['type'];
				
				if ( $account_id > 0 && $amount > 0 ) {
					$balance_sql = $type === 'credit'
						? 'balance = balance - %d'
						: 'balance = balance + %d';
					
					$updated_account = $this->db->query(
						$this->db->prepare(
							"UPDATE {$this->accounts}
						SET {$balance_sql}, updated_at = %s
						WHERE id = %d",
							$amount,
							current_time( 'mysql' ),
							$account_id
						)
					);
					
					if ( $updated_account === FALSE ) {
						$this->db->query( 'ROLLBACK' );
						
						return $this->fail( 'اصلاح موجودی حساب با خطا مواجه شد: ' . $this->db->last_error );
					}
				}
				
				$trx_meta_res = $this->delete_account_transaction_meta( $transaction_id );
				
				if ( ( $trx_meta_res['status'] ?? '' ) !== 'success' ) {
					$this->db->query( 'ROLLBACK' );
					
					return $this->fail( 'حذف متای تراکنش حساب با خطا مواجه شد.', $trx_meta_res );
				}
				
				$deleted_trx = $this->db->delete(
					$this->account_transactions,
					[ 'id' => $transaction_id ],
					[ '%d' ]
				);
				
				if ( $deleted_trx === FALSE ) {
					$this->db->query( 'ROLLBACK' );
					
					return $this->fail( 'حذف تراکنش حساب با خطا مواجه شد: ' . $this->db->last_error );
				}
			}
		}
		
		// حذف متای حواله
		$transfer_meta_res = $this->delete_transfer_meta( $transfer_id );
		
		if ( ( $transfer_meta_res['status'] ?? '' ) !== 'success' ) {
			$this->db->query( 'ROLLBACK' );
			
			return $this->fail( 'حذف متای حواله با خطا مواجه شد.', $transfer_meta_res );
		}
		
		// حذف خود حواله
		$deleted_transfer = $this->db->delete(
			$this->transfers,
			[ 'id' => $transfer_id ],
			[ '%d' ]
		);
		
		if ( $deleted_transfer === FALSE ) {
			$this->db->query( 'ROLLBACK' );
			
			return $this->fail( 'حذف حواله با خطا مواجه شد: ' . $this->db->last_error );
		}
		
		$this->db->query( 'COMMIT' );
		
		return $this->ok( 'حواله و تراکنش‌های مرتبط با موفقیت حذف شدند.', [
			'transfer_id'                  => $transfer_id,
			'deleted_ledger_entries'       => count( $ledger_ids ),
			'deleted_account_transactions' => count( $account_transactions ),
		] );
	}
	
	public function get_transfers_list( array $args = [] ): array {
		$args = wp_parse_args( $args, [
			'user_id'    => 0,
			'page'       => 1,
			'per_page'   => 20,
			'ref_id'     => NULL, // int|null
			'date_from'  => NULL, // paid_at >=
			'date_to'    => NULL, // paid_at <=
			'min_amount' => NULL,
			'max_amount' => NULL,
			'search'     => '',   // note OR id
			'orderby'    => 'transferred_at', // transferred_at|id|amount|created_at
			'order'      => 'DESC',    // ASC|DESC
		] );
		
		$page     = max( 1, (int) $args['page'] );
		$per_page = max( 1, min( 200, (int) $args['per_page'] ) );
		$offset   = ( $page - 1 ) * $per_page;
		
		$search = trim( (string) $args['search'] );
		
		$allowed_orderby = [
			'transferred_at' => 't.transferred_at',
			'id'             => 't.id',
			'amount'         => 't.amount',
			'created_at'     => 't.created_at',
		];
		$orderby         = $allowed_orderby[ (string) $args['orderby'] ] ?? 't.paid_at';
		
		$order   = strtoupper( (string) $args['order'] );
		$order   = in_array( $order, [ 'ASC', 'DESC' ], TRUE ) ? $order : 'DESC';
		$user_id = (int) $args['user_id'];
		$where   = [ '1=1' ];
		$binds   = [];
		if ( $user_id > 0 ) {
			$where[] = 't.user_id = %d';
			$binds[] = $user_id;
		}
		// ref_id
		if ( $args['ref_id'] !== NULL && $args['ref_id'] !== '' ) {
			$where[] = 't.ref_id = %d';
			$binds[] = (int) $args['ref_id'];
		}
		
		// date range (paid_at)
		if ( ! is_null( $args['date_from'] ) && $args['date_from'] !== '' ) {
			$where[] = 't.transferred_at >= %s';
			$binds[] = (string) $args['date_from'];
		}
		if ( ! is_null( $args['date_to'] ) && $args['date_to'] !== '' ) {
			$where[] = 't.transferred_at <= %s';
			$binds[] = (string) $args['date_to'];
		}
		
		// amount range
		if ( $args['min_amount'] !== NULL && $args['min_amount'] !== '' ) {
			$where[] = 't.amount >= %f';
			$binds[] = (float) $args['min_amount'];
		}
		if ( $args['max_amount'] !== NULL && $args['max_amount'] !== '' ) {
			$where[] = 't.amount <= %f';
			$binds[] = (float) $args['max_amount'];
		}
		
		// search in note (and id exact)
		if ( $search !== '' ) {
			$like    = '%' . $this->db->esc_like( $search ) . '%';
			$where[] = '(t.note LIKE %s OR t.id = %d)';
			$binds[] = $like;
			$binds[] = (int) $search;
		}
		
		$where_sql = implode( ' AND ', $where );
		
		// ids for page
		$sql_ids   = "
		SELECT *
		FROM {$this->transfers} t
		WHERE {$where_sql}
		ORDER BY {$orderby} {$order}, t.id {$order}
		LIMIT %d OFFSET %d
	";
		$items_sql = $this->db->prepare( $sql_ids, array_merge( $binds, [ $per_page, $offset ] ) );
		$items     = $this->db->get_results( $items_sql, ARRAY_A );
		
		if ( $items === NULL ) {
			return [
				'items'      => [],
				'pagination' => [
					'page'       => $page,
					'per_page'   => $per_page,
					'total'      => 0,
					'total_page' => 1,
				],
				'error'      => 'خطا در دریافت لیست حواله‌ها: ' . $this->db->last_error,
			];
		}
		// count
		$sql_count  = "
		SELECT COUNT(*)
		FROM {$this->transfers} t
		WHERE {$where_sql}
	";
		$count_sql  = $this->db->prepare( $sql_count, $binds );
		$total      = (int) $this->db->get_var( $count_sql );
		$total_page = (int) max( 1, ceil( $total / $per_page ) );
		
		return [
			'items'      => $items,
			'pagination' => [
				'page'       => $page,
				'per_page'   => $per_page,
				'total'      => $total,
				'total_page' => $total_page,
			],
		];
	}
	
	public function add_cheque( array $data ): array {
		$data = wp_parse_args( $data, [
			'user_id'        => 0,
			'cheque_no'      => '',
			'sayad_id'       => '',
			'bank_name'      => '',
			'amount'         => 0,
			'currency'       => 'IRR',
			'due_at'         => '',
			'status'         => 'in_hand',
			'issuer_user_id' => 0,
			'note'           => NULL,
			'meta'           => [],
			'actor_user_id'  => 0,
			'holder_type'    => 'system', // system|user
			'holder_user_id' => 0,        // required if holder_type=user
		] );
		
		$cheque_no = nooshika_sanitize_numbers( trim( (string) $data['cheque_no'] ) );
		if ( $cheque_no === '' ) {
			return $this->fail( 'شماره چک الزامی است.' );
		}
		
		// Private notes must never enter the public note, cheque movements or ledger.
		$admin_note = current_user_can( 'manage_options' ) && isset( $data['admin_note'] ) && is_string( $data['admin_note'] )
			? sanitize_textarea_field( $data['admin_note'] ) : '';
		if ( mb_strlen( $admin_note ) > 5000 ) {
			return $this->fail( 'یادداشت داخلی حداکثر ۵۰۰۰ نویسه است.' );
		}
		$source_user_id = (int) $data['user_id'];
		if ( $source_user_id <= 0 ) {
			return $this->fail( 'شناسه شخصی که چک را تحویل داده معتبر نیست.' );
		}
		
		$amount = (float) $data['amount'];
		if ( $amount <= 0 ) {
			return $this->fail( 'مبلغ چک معتبر نیست.' );
		}
		$amount = abs( $amount );
		
		$currency = strtoupper( trim( (string) $data['currency'] ) );
		if ( $currency === '' ) {
			$currency = 'IRR';
		}
		
		$due_at = trim( (string) $data['due_at'] );
		if ( $due_at === '' ) {
			return $this->fail( 'تاریخ سررسید الزامی است.' );
		}
		$ts = strtotime( $due_at );
		if ( ! $ts ) {
			return $this->fail( 'تاریخ سررسید معتبر نیست.' );
		}
		$due_at = gmdate( 'Y-m-d', $ts );
		
		$status  = strtolower( trim( (string) $data['status'] ) );
		$allowed = [ 'in_hand', 'endorsed', 'cleared', 'bounced', 'canceled' ];
		if ( $status === '' || ! in_array( $status, $allowed, TRUE ) ) {
			return $this->fail( 'وضعیت چک معتبر نیست.' );
		}
		
		$holder_type = strtolower( trim( (string) $data['holder_type'] ) );
		if ( $holder_type === '' ) {
			$holder_type = 'system';
		}
		if ( ! in_array( $holder_type, [ 'system', 'user' ], TRUE ) ) {
			return $this->fail( 'نوع هولدر معتبر نیست.' );
		}
		
		$holder_user_id = (int) $data['holder_user_id'];
		if ( $holder_type === 'user' ) {
			if ( $holder_user_id <= 0 ) {
				return $this->fail( 'شناسه هولدر معتبر نیست.' );
			}
		} else {
			$holder_user_id = 0;
		}
		
		$actor_user_id  = (int) $data['actor_user_id'] ?: get_current_user_id();
		$issuer_user_id = (int) $data['issuer_user_id'] ?: $source_user_id;
		
		$sayad_id  = nooshika_sanitize_numbers( trim( (string) $data['sayad_id'] ) );
		$bank_name = trim( (string) $data['bank_name'] );
		
		$note = is_null( $data['note'] ) ? NULL : trim( (string) $data['note'] );
		if ( $note === '' ) {
			$note = NULL;
		}
		
		$meta = is_array( $data['meta'] ) ? $data['meta'] : [];
		$meta = array_filter( $meta, static function( $v, $k ) {
			return (string) $k !== '';
		}, ARRAY_FILTER_USE_BOTH );
		
		$created_at = current_time( 'mysql', TRUE );
		
		if (false === $this->db->query('START TRANSACTION')) return $this->fail('شروع ثبت چک انجام نشد.');
        $invoice_guard = $this->lock_supplier_invoice_reference($holder_user_id ?: $source_user_id, (int)($meta['invoice_id'] ?? 0));
        if (($invoice_guard['status'] ?? '') !== 'success') {
            $this->db->query('ROLLBACK');
            return $invoice_guard;
        }

		
		$insert = [
			'user_id'                => $source_user_id,
			'cheque_no'              => $cheque_no,
			'sayad_id'               => ( $sayad_id !== '' ? $sayad_id : NULL ),
			'bank_name'              => ( $bank_name !== '' ? $bank_name : NULL ),
			'amount'                 => $amount,
			'currency'               => $currency,
			'due_at'                 => $due_at,
			'status'                 => $status,
			'issuer_user_id'         => $issuer_user_id,
			'current_holder_user_id' => ( $holder_type === 'user' ? $holder_user_id : NULL ),
			'created_at'             => $created_at,
			'updated_at'             => NULL,
		];
		
		if ( is_null( $insert['sayad_id'] ) ) {
			unset( $insert['sayad_id'] );
		}
		if ( is_null( $insert['bank_name'] ) ) {
			unset( $insert['bank_name'] );
		}
		if ( is_null( $insert['issuer_user_id'] ) ) {
			unset( $insert['issuer_user_id'] );
		}
		if ( is_null( $insert['current_holder_user_id'] ) ) {
			unset( $insert['current_holder_user_id'] );
		}
		
		if ( ! is_null( $note ) ) {
			$insert['note'] = $note;
		}
		
		$ok = $this->db->insert( $this->cheques, $insert );
		if ( $ok === FALSE ) {
			$this->db->query( 'ROLLBACK' );
			
			return $this->fail( 'خطا در ثبت چک: ' . $this->db->last_error );
		}
		
		$cheque_id = (int) $this->db->insert_id;
		// Ignore forged generic metadata, including submissions from non-admins.
		$meta = array_filter( $meta, static fn( $key ) => ! in_array( strtolower( rtrim( (string) $key ) ), [ 'admin_note', 'admin_note_print' ], TRUE ), ARRAY_FILTER_USE_KEY );
		if ( $admin_note !== '' ) {
			$private_note_result = $this->update_cheque_meta( $cheque_id, 'admin_note', $admin_note );
			if ( $private_note_result['status'] !== 'success' ) {
				$this->db->query( 'ROLLBACK' );
				
				return $private_note_result;
			}
		}
		
		if ( $admin_note !== '' && current_user_can( 'manage_options' ) ) {
			$print_result = $this->set_cheque_note_print( $cheque_id, ! empty( $data['admin_note_print'] ) );
			if ( $print_result['status'] !== 'success' ) { $this->db->query( 'ROLLBACK' ); return $print_result; }
		}
		if ( ! empty( $meta ) ) {
			$meta_res = $this->save_meta_batch( 'cheque', $cheque_id, $meta, TRUE );
			if ( ( $meta_res['status'] ?? '' ) !== 'success' ) {
				$this->db->query( 'ROLLBACK' );
				
				return $this->fail( 'ثبت متای چک با خطا مواجه شد.', $meta_res );
			}
		}
		$res = $this->add_cheque_move( [
			'cheque_id'         => $cheque_id,
			'action'            => 'receive',
			'actor_user_id'     => $actor_user_id,
			'holder_type'       => $holder_type, // system | user
			'holder_user_id'    => ( $holder_type === 'user' ? $holder_user_id : 0 ),
			'note'              => $note,
			'created_at'        => $created_at,
			'ledger_entry_type' => 'cheque_receive',
			'meta'              => [
				'source_user' => $source_user_id,
			],
		], true );
		
		if ( ( $res['status'] ?? '' ) !== 'success' ) {
			$this->db->query('ROLLBACK');
			return $res;
		}
		do_action( 'kph_cheque_added', $cheque_id, [
			'user_id'        => $source_user_id,
			'cheque_no'      => $cheque_no,
			'sayad_id'       => $sayad_id,
			'bank_name'      => $bank_name,
			'amount'         => $amount,
			'due_at'         => $due_at,
			'status'         => $status,
			'issuer_user_id' => $issuer_user_id,
			'holder_type'    => $holder_type,
			'holder_user_id' => $holder_user_id,
			'created_at'     => $created_at,
			'meta'           => $meta,
		], $res );
		
		return $this->ok( 'چک با موفقیت ثبت شد.', [
			'id'        => $cheque_id,
			'move_id'   => $res['data']['id'] ?? 0,
			'ledger_id' => $res['data']['ledger_id'] ?? 0,
		] );
	}
	
	public function delete_cheque( int $cheque_id ): array {
		$cheque_id = (int) $cheque_id;
		
		if ( $cheque_id <= 0 ) {
			return $this->fail( 'شناسه چک معتبر نیست.' );
		}
		
		$cheque = $this->db->get_row(
			$this->db->prepare(
				"SELECT *
			FROM {$this->cheques}
			WHERE id = %d
			LIMIT 1",
				$cheque_id
			),
			ARRAY_A
		);
		
		if ( ! $cheque ) {
			return $this->fail( 'چک یافت نشد.' );
		}
		
		$this->db->query( 'START TRANSACTION' );
		
		// حذف آیتم‌های حسابداری مرتبط با چک
		$ledger_ids = $this->db->get_col(
			$this->db->prepare(
				"SELECT id
			FROM {$this->ledger_entries}
			WHERE ref_type = %s
				AND ref_id = %d",
				'cheque',
				$cheque_id
			)
		);
		
		if ( ! empty( $ledger_ids ) ) {
			foreach ( $ledger_ids as $ledger_id ) {
				$meta_res = $this->delete_meta( 'ledger_entry', (int) $ledger_id );
				
				if ( ( $meta_res['status'] ?? '' ) !== 'success' ) {
					$this->db->query( 'ROLLBACK' );
					
					return $this->fail( 'حذف متای آیتم حسابداری با خطا مواجه شد.', $meta_res );
				}
			}
			
			$ledger_placeholders = implode( ',', array_fill( 0, count( $ledger_ids ), '%d' ) );
			
			$deleted_ledger = $this->db->query(
				$this->db->prepare(
					"DELETE FROM {$this->ledger_entries}
				WHERE id IN ({$ledger_placeholders})",
					array_map( 'intval', $ledger_ids )
				)
			);
			
			if ( $deleted_ledger === FALSE ) {
				$this->db->query( 'ROLLBACK' );
				
				return $this->fail( 'حذف آیتم‌های حسابداری چک با خطا مواجه شد: ' . $this->db->last_error );
			}
		}
		
		// حذف تراکنش حساب بانکی مربوط به وصول چک، در صورت وجود
		$account_transactions = $this->db->get_results(
			$this->db->prepare(
				"SELECT DISTINCT t.*
			FROM {$this->account_transactions} t
			LEFT JOIN {$this->db_prefix}account_transaction_meta tm
				ON tm.transaction_id = t.id
			WHERE
				(
					t.action = %s
					AND t.description = %s
				)
				OR
				(
					tm.meta_key = %s
					AND tm.meta_value = %s
				)",
				'cheque_cleared',
				'وصول چک #' . $cheque_id,
				'cheque_id',
				(string) $cheque_id
			),
			ARRAY_A
		);
		
		if ( ! empty( $account_transactions ) ) {
			foreach ( $account_transactions as $transaction ) {
				$transaction_id = (int) $transaction['id'];
				$account_id     = (int) $transaction['account_id'];
				$amount         = abs( (int) $transaction['amount'] );
				$type           = (string) $transaction['type'];
				
				if ( $account_id > 0 && $amount > 0 ) {
					if ( $type === 'credit' ) {
						$balance_sql = "balance = balance - %d";
					} else {
						$balance_sql = "balance = balance + %d";
					}
					
					$updated_account = $this->db->query(
						$this->db->prepare(
							"UPDATE {$this->accounts}
						SET {$balance_sql}, updated_at = %s
						WHERE id = %d",
							$amount,
							current_time( 'mysql' ),
							$account_id
						)
					);
					
					if ( $updated_account === FALSE ) {
						$this->db->query( 'ROLLBACK' );
						
						return $this->fail( 'اصلاح موجودی حساب با خطا مواجه شد: ' . $this->db->last_error );
					}
				}
				
				$trx_meta_res = $this->delete_meta( 'account_transaction', $transaction_id );
				
				if ( ( $trx_meta_res['status'] ?? '' ) !== 'success' ) {
					$this->db->query( 'ROLLBACK' );
					
					return $this->fail( 'حذف متای تراکنش حساب با خطا مواجه شد.', $trx_meta_res );
				}
				
				$deleted_trx = $this->db->delete(
					$this->account_transactions,
					[ 'id' => $transaction_id ],
					[ '%d' ]
				);
				
				if ( $deleted_trx === FALSE ) {
					$this->db->query( 'ROLLBACK' );
					
					return $this->fail( 'حذف تراکنش حساب با خطا مواجه شد: ' . $this->db->last_error );
				}
			}
		}
		
		// حذف متای چک
		$cheque_meta_res = $this->delete_meta( 'cheque', $cheque_id );
		
		if ( ( $cheque_meta_res['status'] ?? '' ) !== 'success' ) {
			$this->db->query( 'ROLLBACK' );
			
			return $this->fail( 'حذف متای چک با خطا مواجه شد.', $cheque_meta_res );
		}
		
		// حذف حرکات چک
		$deleted_moves = $this->db->delete(
			$this->cheque_moves,
			[ 'cheque_id' => $cheque_id ],
			[ '%d' ]
		);
		
		if ( $deleted_moves === FALSE ) {
			$this->db->query( 'ROLLBACK' );
			
			return $this->fail( 'حذف حرکات چک با خطا مواجه شد: ' . $this->db->last_error );
		}
		
		// حذف خود چک
		$deleted_cheque = $this->db->delete(
			$this->cheques,
			[ 'id' => $cheque_id ],
			[ '%d' ]
		);
		
		if ( $deleted_cheque === FALSE ) {
			$this->db->query( 'ROLLBACK' );
			
			return $this->fail( 'حذف چک با خطا مواجه شد: ' . $this->db->last_error );
		}
		
		$this->db->query( 'COMMIT' );
		
		return $this->ok( 'چک و تراکنش‌های مرتبط با موفقیت حذف شدند.', [
			'cheque_id'                    => $cheque_id,
			'deleted_ledger_entries'       => count( $ledger_ids ),
			'deleted_account_transactions' => count( $account_transactions ),
			'deleted_cheque_moves'         => (int) $deleted_moves,
		] );
	}
	
	public function add_cheque_move( array $data, bool $inside_transaction = false ): array {
		$data = wp_parse_args( $data, [
			'cheque_id'         => 0,
			'action'            => 'note',   // receive|endorse|return|clear|bounce|cancel|note
			'actor_user_id'     => 0,
			'holder_type'       => 'system', // system|user
			'holder_user_id'    => 0,        // required if holder_type=user
			'note'              => NULL,
			'meta'              => [],
			'created_at'        => '',
			'ledger_entry_type' => '', // must exist in get_ledger_entry_types()
			'account_id'        => 0,
		] );
		
		$cheque_id = (int) $data['cheque_id'];
		if ( $cheque_id <= 0 ) {
			return $this->fail( 'شناسه چک معتبر نیست.' );
		}
		
		$action          = strtolower( trim( (string) $data['action'] ) );
		$allowed_actions = [ 'receive', 'endorse', 'return', 'clear', 'bounce', 'cancel', 'note' ];
		if ( $action === '' || ! in_array( $action, $allowed_actions, TRUE ) ) {
			return $this->fail( 'نوع حرکت چک معتبر نیست.' );
		}
		
		$holder_type = strtolower( trim( (string) $data['holder_type'] ) );
		if ( $holder_type === '' ) {
			$holder_type = 'system';
		}
		if ( ! in_array( $holder_type, [ 'system', 'user' ], TRUE ) ) {
			return $this->fail( 'نوع هولدر معتبر نیست.' );
		}
		
		$holder_user_id = (int) $data['holder_user_id'];
		if ( $holder_type === 'user' ) {
			if ( $holder_user_id <= 0 ) {
				return $this->fail( 'شناسه هولدر معتبر نیست.' );
			}
		} else {
			$holder_user_id = 0;
		}
		
		$actor_user_id = (int) $data['actor_user_id'];
		if ( $actor_user_id < 0 ) {
			$actor_user_id = 0;
		}
		if ( $actor_user_id === 0 ) {
			$actor_user_id = get_current_user_id();
		}
		
		$note = is_null( $data['note'] ) ? NULL : trim( (string) $data['note'] );
		if ( $note === '' ) {
			$note = NULL;
		}
		
		$meta = is_array( $data['meta'] ) ? $data['meta'] : [];
		$meta = array_filter( $meta, static function( $v, $k ) {
			return (string) $k !== '';
		}, ARRAY_FILTER_USE_BOTH );
		
		$created_at = trim( (string) $data['created_at'] );
		if ( $created_at === '' ) {
			$created_at = current_time( 'mysql', TRUE );
		} else {
			$ts = strtotime( $created_at );
			if ( ! $ts ) {
				return $this->fail( 'تاریخ حرکت معتبر نیست.' );
			}
			$created_at = gmdate( 'Y-m-d H:i:s', $ts );
		}
		
        if ($action === 'endorse' && !$this->workflow_storage_ready('endorsement')) {
            return $this->fail('مدیر ابتدا آماده‌سازی جدول‌ها را در ابزارهای کاسبی اجرا کند.');
        }
        if (!$inside_transaction && false === $this->db->query('START TRANSACTION')) return $this->fail('شروع ثبت گردش چک انجام نشد.');
		$cheque = $this->db->get_row(
			$this->db->prepare(
				"SELECT id, user_id, issuer_user_id, current_holder_user_id, status, amount, cheque_no, currency
			 FROM {$this->cheques}
			 WHERE id = %d
			 LIMIT 1 FOR UPDATE",
				$cheque_id
			),
			ARRAY_A
		);
		
		if ( empty( $cheque ) ) {
            $this->db->query('ROLLBACK');
			return $this->fail( 'چک یافت نشد.' );
		}
		
		$status_from = (string) ( $cheque['status'] ?? '' );
        if($action==='clear' && in_array($status_from,['cleared','canceled'],true)){$this->db->query('ROLLBACK');return $this->fail('این چک قبلاً وصول یا باطل شده است.');}
		$amount      = (float) ( $cheque['amount'] ?? 0 );
		if ( $amount <= 0 ) {
            $this->db->query('ROLLBACK');
			return $this->fail( 'مبلغ چک معتبر نیست.' );
		}
		$amount = abs( $amount );
		
		$cheque_no = (string) ( $cheque['cheque_no'] ?? '' );
		
		if ( in_array( $status_from, [ 'cleared', 'canceled' ], TRUE ) && $action !== 'note' ) {
			$this->db->query('ROLLBACK');
			return $this->fail( 'این چک قابل تغییر وضعیت نیست.' );
		}
		
		// status_to mapping
		$status_to = $status_from;
		if ( $action === 'receive' ) {
			$status_to = 'in_hand';
		} elseif ( $action === 'endorse' ) {
			$status_to = 'endorsed';
		} elseif ( $action === 'clear' ) {
			$status_to = 'cleared';
		} elseif ( $action === 'bounce' ) {
			$status_to = 'bounced';
		} elseif ( $action === 'cancel' ) {
			$status_to = 'canceled';
		} elseif ( $action === 'return' ) {
			// برگشت به سیستم معمولاً یعنی دوباره دست مجموعه است
			$status_to = 'in_hand';
		}
		
        if ($action === 'endorse' && ($status_from !== 'in_hand' || $holder_type !== 'user' || !empty($cheque['current_holder_user_id']))) {
            $this->db->query('ROLLBACK');
            return $this->fail('فقط چک در دست مجموعه قابل واگذاری است. وضعیت فعلی چک را بررسی کنید.');
        }
        $invoice_guard = $this->lock_supplier_invoice_reference($holder_user_id ?: (int)($cheque['current_holder_user_id'] ?? 0), (int)($meta['invoice_id'] ?? 0));
        if (($invoice_guard['status'] ?? '') !== 'success') {
            $this->db->query('ROLLBACK');
            return $invoice_guard;
        }

		
		$update = [
			'status'     => $status_to,
			'updated_at' => current_time( 'mysql', TRUE ),
		];
		
		if ( $holder_type === 'user' ) {
			$update['current_holder_user_id'] = $holder_user_id;
		} else {
			$update['current_holder_user_id'] = NULL;
		}
		
		$ok = $this->db->update( $this->cheques, $update, [ 'id' => $cheque_id ] );
		if ( $ok === FALSE ) {
			$this->db->query( 'ROLLBACK' );
			
			return $this->fail( 'خطا در بروزرسانی چک: ' . $this->db->last_error );
		}
		
		$move_insert = [
			'cheque_id'      => $cheque_id,
			'actor_user_id'  => $actor_user_id,
			'holder_user_id' => ( $holder_type === 'user' ? $holder_user_id : NULL ),
			'action'         => $action,
			'status_from'    => ( $status_from !== '' ? $status_from : NULL ),
			'status_to'      => $status_to,
			'note'           => $note,
			'created_at'     => $created_at,
		];
		
		$ok2 = $this->db->insert( $this->cheque_moves, $move_insert );
		if ( $ok2 === FALSE ) {
			$this->db->query( 'ROLLBACK' );
			
			return $this->fail( 'خطا در ثبت حرکت چک: ' . $this->db->last_error );
		}
		
		$move_id = (int) $this->db->insert_id;
		if ( ! empty( $meta ) ) {
			$meta_res = $this->save_meta_batch( 'cheque', $cheque_id, $meta, TRUE );
			if ( ( $meta_res['status'] ?? '' ) !== 'success' ) {
                $this->db->query('ROLLBACK');
				return $this->fail( 'ثبت متای چک با خطا مواجه شد.', $meta_res );
			}
		}
		

		$source_user_id = (int) ( $cheque['user_id'] ?? 0 );
		
		if ( $action === 'clear' ) {
			$account_id = (int) $data['account_id'];
			if ( $account_id <= 0 ) {
				$this->db->query( 'ROLLBACK' );
				
				return $this->fail( 'برای وصول چک باید account_id مشخص شود.' );
			}
			
			$trx = $this->add_account_transaction( [
				'account_id'  => $account_id,
				'amount'      => $amount,
				'type'        => 'credit',
				'action'      => 'cheque_cleared',
				'description' => 'وصول چک #' . $cheque_id,
				'created_by'  => $actor_user_id,
				'created_at'  => $created_at,
				'meta'        => [
					'attachment'  => $_POST['meta']['attachment'] ?? '',
					'cost_type'   => $_POST['meta']['cost_type'] ?? '',
					'destination' => $_POST['meta']['destination'] ?? '',
				],
			], true );
			
			if ( ( $trx['status'] ?? '' ) !== 'success' ) {
				$this->db->query( 'ROLLBACK' );
				
				return $this->fail( 'ثبت تراکنش حساب با خطا مواجه شد.', $trx );
			}
			
			if(false===$this->db->query('COMMIT')){$this->db->query('ROLLBACK');return $this->fail('ثبت نهایی وصول چک ناموفق بود.');}
			
			return $this->ok( 'چک با موفقیت وصول شد.', [
				'id'        => $move_id,
				'cheque_id' => $cheque_id,
				'status'    => $status_to,
			] );
		}
		if ( $holder_type === 'user' ) {
			$ledger_user_id = $holder_user_id;
			$ledger_type    = 'debit';
		} else {
			$ledger_user_id = $source_user_id;
			$ledger_type    = 'credit';
		}
		
		if ( $ledger_user_id <= 0 ) {
			$this->db->query( 'ROLLBACK' );
			
			return $this->fail( 'شناسه کاربر برای ثبت آیتم حسابداری معتبر نیست.' );
		}
		
		$ledger_entry_type = trim( (string) $data['ledger_entry_type'] );
		if ( $ledger_entry_type === '' ) {
			$ledger_entry_type = 'cheque_' . $action;
		}
		
		$ledger_note = $note;
		if ( is_null( $ledger_note ) ) {
			if ( $action === 'endorse' ) {
				$ledger_note = 'انتقال چک #' . $cheque_id;
			} elseif ( $action === 'return' ) {
				$ledger_note = 'برگشت چک #' . $cheque_id;
			} elseif ( $action === 'bounce' ) {
				$ledger_note = 'برگشت خوردن چک #' . $cheque_id;
				$ledger_type = 'debit';
			} elseif ( $action === 'cancel' ) {
				$ledger_note = 'لغو چک #' . $cheque_id;
			} elseif ( $action === 'receive' ) {
				$ledger_note = 'دریافت چک #' . $cheque_id;
			} else {
				$ledger_note = 'ثبت حرکت چک #' . $cheque_id;
			}
		}
		
		$ledger_res = $this->add_ledger_entry( [
			'user_id'    => $ledger_user_id,
			'entry_type' => $ledger_entry_type,
			'type'       => $ledger_type,
			'amount'     => $amount,
			'ref_type'   => 'cheque',
			'ref_id'     => $cheque_id,
			'posted_at'  => $created_at,
			'note'       => $ledger_note,
			'meta'       => [
				'creator_id'  => get_current_user_id(),
				'cheque_no'   => $cheque_no,
				'move_id'     => $move_id,
				'action'      => $action,
				'holder_type' => $holder_type,
				'holder_user' => ( $holder_type === 'user' ? $holder_user_id : 0 ),
				'source_user' => $source_user_id,
				'status_from' => $status_from,
				'status_to'   => $status_to,
			],
		] );
		
		if ( ( $ledger_res['status'] ?? '' ) !== 'success' ) {
			$this->db->query( 'ROLLBACK' );
			
			return $this->fail( 'ثبت آیتم حسابداری حرکت چک با خطا مواجه شد.', $ledger_res );
		}
		
		if (false === $this->db->query('COMMIT')) {
            $this->db->query('ROLLBACK');
            return $this->fail('ثبت نهایی گردش چک انجام نشد.');
        }
		
		do_action( 'kph_cheque_move_added', $move_id, $cheque_id, [
			'action'         => $action,
			'status_from'    => $status_from,
			'status_to'      => $status_to,
			'amount'         => $amount,
			'holder_type'    => $holder_type,
			'holder_user_id' => $holder_user_id,
			'source_user_id' => $source_user_id,
			'created_at'     => $created_at,
		], $ledger_res );
		
		return $this->ok( 'حرکت چک با موفقیت ثبت شد.', [
			'id'        => $move_id,
			'cheque_id' => $cheque_id,
			'ledger_id' => (int) ( $ledger_res['data']['id'] ?? 0 ),
			'status'    => $status_to,
		] );
	}
	
	public function get_cheques( array $args = [] ): array {
		$args = wp_parse_args( $args, [
			'page'       => 1,
			'per_page'   => 20,
			'user_id'    => 0,
			'sayad_id'   => 0,
			'cheque_no'  => 0,
			'status'     => NULL,
			'invoice_id' => NULL,
			'date_from'  => NULL,  // due_at >=
			'date_to'    => NULL,  // due_at <=
			'orderby'    => 'due_at',
			'order'      => 'DESC',
		] );
		
		$page     = max( 1, (int) $args['page'] );
		$per_page = max( 1, min( 200, (int) $args['per_page'] ) );
		$offset   = ( $page - 1 ) * $per_page;
		
		$allowed_orderby = [
			'due_at'     => 'i.due_at',
			'id'         => 'i.id',
			'amount'     => 'i.amount',
			'created_at' => 'i.created_at',
		];
		$orderby         = $allowed_orderby[ (string) $args['orderby'] ] ?? 'i.due_at';
		
		$order = strtoupper( (string) $args['order'] );
		$order = in_array( $order, [ 'ASC', 'DESC' ], TRUE ) ? $order : 'DESC';
		
		$where = [ '1=1' ];
		$binds = [];
		
		$join_sql = '';
		
		$issuer_user_id = (int) $args['user_id'];
		if ( $issuer_user_id > 0 ) {
			$where[] = '(i.user_id = %d OR i.current_holder_user_id = %d)';
			$binds[] = $issuer_user_id;
			$binds[] = $issuer_user_id;
		}
		$sayad_id = $args['sayad_id'];
		if ( $sayad_id > 0 ) {
			$where[] = 'i.sayad_id = %d';
			$binds[] = $sayad_id;
		}
		$cheque_no = $args['cheque_no'];
		if ( $cheque_no > 0 ) {
			$where[] = 'i.cheque_no = %d';
			$binds[] = $cheque_no;
		}
		
		if ( ! is_null( $args['invoice_id'] ) && $args['invoice_id'] !== '' ) {
			$cheque_meta = $this->db_prefix . 'cheque_meta';
			
			$join_sql   .= " INNER JOIN {$cheque_meta} cm
			ON (cm.cheque_id = i.id AND cm.meta_key = 'invoice_id') ";
			$invoice_id = trim( (string) $args['invoice_id'] );
			if ( $invoice_id !== '' ) {
				$where[] = 'cm.meta_value = %s';
				$binds[] = $invoice_id;
			}
		}
		
		if ( ! is_null( $args['status'] ) && $args['status'] !== '' ) {
			$allowed_statuses = array_keys( $this->get_cheque_statuses() );
			
			if ( is_array( $args['status'] ) ) {
				$statuses = array_values( array_filter( array_map( 'trim', array_map( 'strval', $args['status'] ) ) ) );
				$statuses = array_values( array_unique( $statuses ) );
				$statuses = array_values( array_filter( $statuses, static fn( string $s ): bool => in_array( $s, $allowed_statuses, TRUE ) ) );
				
				if ( ! empty( $statuses ) ) {
					$placeholders = implode( ',', array_fill( 0, count( $statuses ), '%s' ) );
					$where[]      = "i.status IN ({$placeholders})";
					$binds        = array_merge( $binds, $statuses );
				}
			} else {
				$st = strtolower( trim( (string) $args['status'] ) );
				if ( in_array( $st, $allowed_statuses, TRUE ) ) {
					$where[] = 'i.status = %s';
					$binds[] = $st;
				}
			}
		}
		
		// date range (issued_at)
		if ( ! is_null( $args['date_from'] ) && $args['date_from'] !== '' ) {
			$where[] = 'i.due_at >= %s';
			$binds[] = (string) $args['date_from'];
		}
		if ( ! is_null( $args['date_to'] ) && $args['date_to'] !== '' ) {
			$where[] = 'i.due_at <= %s';
			$binds[] = (string) $args['date_to'];
		}
		
		$where_sql = implode( ' AND ', $where );
		
		$sql_rows = "
		SELECT i.*
		FROM {$this->cheques} i
		{$join_sql}
		WHERE {$where_sql}
		ORDER BY {$orderby} {$order}, i.id {$order}
		LIMIT %d OFFSET %d
	";
		$rows_sql = $this->db->prepare( $sql_rows, array_merge( $binds, [ $per_page, $offset ] ) );
		$rows     = $this->db->get_results( $rows_sql, ARRAY_A );
		
		if ( $rows === NULL ) {
			return [
				'items'      => [],
				'pagination' => [
					'page'       => $page,
					'per_page'   => $per_page,
					'total'      => 0,
					'total_page' => 1,
				],
				'error'      => 'خطا در دریافت لیست چک: ' . $this->db->last_error,
			];
		}
		
		$sql_count  = "
		SELECT COUNT(*)
		FROM {$this->cheques} i
		{$join_sql}
		WHERE {$where_sql}
	";
		$count_sql  = empty( $binds ) ? $sql_count : $this->db->prepare( $sql_count, $binds );
		$total      = (int) $this->db->get_var( $count_sql );
		$total_page = (int) max( 1, ceil( $total / $per_page ) );
		
		return [
			'items'      => $rows,
			'pagination' => [
				'page'       => $page,
				'per_page'   => $per_page,
				'total'      => $total,
				'total_page' => $total_page,
			],
		];
	}
	
	public function get_cheque( $cheque_id ): array {
		if ( ! $cheque_id ) {
			return $this->fail( 'شناسه چک معتبر نیست.' );
		}
		
		$sql = "
		SELECT *
		FROM {$this->cheques}
		WHERE id = %s
		LIMIT 1
	";
		
		$item = $this->db->get_row(
			$this->db->prepare( $sql, $cheque_id ),
			ARRAY_A
		);
		
		if ( $item === NULL ) {
			return $this->fail( 'خطا در دریافت اطلاعات چک: ' . $this->db->last_error );
		}
		
		if ( ! $item ) {
			return $this->fail( 'چک با این شناسه پیدا نشد.' );
		}
		
		return $item;
	}
	
	public function get_cheque_moves( int $cheque_id, array $args = [] ): array {
		if ( $cheque_id <= 0 ) {
			return [
				'items' => [],
				'error' => 'شناسه چک معتبر نیست.',
			];
		}
		
		$args = wp_parse_args( $args, [
			'page'      => 1,
			'per_page'  => 20,
			'action'    => NULL, // receive|endorse|return|clear|bounce|cancel|note|array|null
			'date_from' => NULL, // created_at >=
			'date_to'   => NULL, // created_at <=
			'orderby'   => 'created_at',
			'order'     => 'DESC',
		] );
		
		$page     = max( 1, (int) $args['page'] );
		$per_page = max( 1, min( 200, (int) $args['per_page'] ) );
		$offset   = ( $page - 1 ) * $per_page;
		
		$allowed_orderby = [
			'created_at' => 'm.created_at',
			'id'         => 'm.id',
			'action'     => 'm.action',
		];
		
		$orderby = $allowed_orderby[ (string) $args['orderby'] ] ?? 'm.created_at';
		
		$order = strtoupper( (string) $args['order'] );
		$order = in_array( $order, [ 'ASC', 'DESC' ], TRUE ) ? $order : 'DESC';
		
		$where = [
			'm.cheque_id = %d',
		];
		$binds = [ $cheque_id ];
		
		// action filter
		if ( ! is_null( $args['action'] ) && $args['action'] !== '' ) {
			$allowed_actions = [ 'receive', 'endorse', 'return', 'clear', 'bounce', 'cancel', 'note' ];
			
			if ( is_array( $args['action'] ) ) {
				$actions = array_values(
					array_unique(
						array_filter(
							array_map( 'strtolower', array_map( 'trim', $args['action'] ) )
						)
					)
				);
				$actions = array_values( array_intersect( $actions, $allowed_actions ) );
				
				if ( ! empty( $actions ) ) {
					$placeholders = implode( ',', array_fill( 0, count( $actions ), '%s' ) );
					$where[]      = "m.action IN ({$placeholders})";
					$binds        = array_merge( $binds, $actions );
				}
			} else {
				$action = strtolower( trim( (string) $args['action'] ) );
				if ( in_array( $action, $allowed_actions, TRUE ) ) {
					$where[] = 'm.action = %s';
					$binds[] = $action;
				}
			}
		}
		
		// date range
		if ( ! is_null( $args['date_from'] ) && $args['date_from'] !== '' ) {
			$where[] = 'm.created_at >= %s';
			$binds[] = (string) $args['date_from'];
		}
		if ( ! is_null( $args['date_to'] ) && $args['date_to'] !== '' ) {
			$where[] = 'm.created_at <= %s';
			$binds[] = (string) $args['date_to'];
		}
		
		$where_sql = implode( ' AND ', $where );
		
		$sql_rows = "
		SELECT m.*
		FROM {$this->cheque_moves} m
		WHERE {$where_sql}
		ORDER BY {$orderby} {$order}, m.id {$order}
		LIMIT %d OFFSET %d
	";
		
		$rows_sql = $this->db->prepare(
			$sql_rows,
			array_merge( $binds, [ $per_page, $offset ] )
		);
		
		$rows = $this->db->get_results( $rows_sql, ARRAY_A );
		
		if ( $rows === NULL ) {
			return [
				'items'      => [],
				'pagination' => [
					'page'       => $page,
					'per_page'   => $per_page,
					'total'      => 0,
					'total_page' => 1,
				],
				'error'      => 'خطا در دریافت حرکات چک: ' . $this->db->last_error,
			];
		}
		
		$sql_count = "
		SELECT COUNT(*)
		FROM {$this->cheque_moves} m
		WHERE {$where_sql}
	";
		
		$count_sql = $this->db->prepare( $sql_count, $binds );
		$total     = (int) $this->db->get_var( $count_sql );
		
		return [
			'items'      => $rows,
			'pagination' => [
				'page'       => $page,
				'per_page'   => $per_page,
				'total'      => $total,
				'total_page' => (int) max( 1, ceil( $total / $per_page ) ),
			],
		];
	}
	
	/** ---------- Supplier Invoice ---------- */
	
	public function add_supplier_invoice( array $data ): array {
		$data = wp_parse_args( $data, [
			'supplier_user_id' => 0,
			'invoice_no'       => NULL,
			'status'           => 'proforma', // proforma|confirmed|settled
			'issued_at'        => current_time( 'mysql', TRUE ),
			'confirmed_at'     => NULL,
			'settled_at'       => NULL,
			'currency'         => 'IRR',
			'note'             => NULL,
			'meta'             => [],
			'items'            => [], // each: [ raw_product_id, qty_weight, unit_price, line_total?, note?, meta? ]
		] );
		
		$supplier_user_id = (int) $data['supplier_user_id'];
		if ( $supplier_user_id <= 0 ) {
			return $this->fail( 'شناسه تامین‌کننده معتبر نیست.' );
		}
		
		$status           = strtolower( trim( (string) $data['status'] ) );
		$allowed_statuses = [ 'proforma', 'confirmed', 'settled' ];
		if ( ! in_array( $status, $allowed_statuses, TRUE ) ) {
			return $this->fail( 'وضعیت فاکتور معتبر نیست.' );
		}
		
		$invoice_no = is_null( $data['invoice_no'] ) ? NULL : trim( (string) $data['invoice_no'] );
		if ( $invoice_no === '' ) {
			$invoice_no = NULL;
		}
		
		$currency = strtoupper( trim( (string) $data['currency'] ) );
		if ( $currency === '' ) {
			$currency = 'IRR';
		}
		
		$issued_at = trim( (string) $data['issued_at'] );
		if ( $issued_at === '' ) {
			$issued_at = current_time( 'mysql', TRUE );
		}
		
		$confirmed_at = is_null( $data['confirmed_at'] ) ? NULL : trim( (string) $data['confirmed_at'] );
		if ( $confirmed_at === '' ) {
			$confirmed_at = NULL;
		}
		
		$settled_at = is_null( $data['settled_at'] ) ? NULL : trim( (string) $data['settled_at'] );
		if ( $settled_at === '' ) {
			$settled_at = NULL;
		}
		
		$note = is_null( $data['note'] ) ? NULL : trim( (string) $data['note'] );
		if ( $note === '' ) {
			$note = NULL;
		}
		
		$items = is_array( $data['items'] ) ? $data['items'] : [];
		if ( empty( $items ) ) {
			return $this->fail( 'آیتم‌های فاکتور ارسال نشده است.' );
		}
		
		$prepared_items = [];
		$total_amount   = 0.0;
		
		foreach ( $items as $idx => $item ) {
			$item = is_array( $item ) ? $item : [];
			
			$raw_product_id = (int) ( $item['raw_product_id'] ?? 0 );
			if ( $raw_product_id <= 0 ) {
				return $this->fail( 'محصول آیتم فاکتور معتبر نیست. (ردیف ' . ( (int) $idx + 1 ) . ')' );
			}
			
			$qty_weight = (float) ( $item['qty_weight'] ?? 0 );
			if ( $qty_weight <= 0 ) {
				return $this->fail( 'مقدار/وزن آیتم فاکتور معتبر نیست. (ردیف ' . ( (int) $idx + 1 ) . ')' );
			}
			
			$unit_price = (float) ( $item['unit_price'] ?? 0 );
			if ( $unit_price < 0 ) {
				return $this->fail( 'قیمت واحد آیتم فاکتور معتبر نیست. (ردیف ' . ( (int) $idx + 1 ) . ')' );
			}
			
			$line_total = isset( $item['line_total'] )
				? (float) $item['line_total']
				: (float) ( $qty_weight * $unit_price );
			
			if ( $line_total < 0 ) {
				return $this->fail( 'مبلغ آیتم فاکتور معتبر نیست. (ردیف ' . ( (int) $idx + 1 ) . ')' );
			}
			
			$item_note = is_null( $item['note'] ?? NULL ) ? NULL : trim( (string) $item['note'] );
			if ( $item_note === '' ) {
				$item_note = NULL;
			}
			
			$item_meta = is_array( $item['meta'] ?? NULL ) ? (array) $item['meta'] : [];
			$item_meta = array_filter( $item_meta, static function( $v, $k ) {
				return (string) $k !== '';
			}, ARRAY_FILTER_USE_BOTH );
			
			$prepared_items[] = [
				'raw_product_id' => $raw_product_id,
				'qty_weight'     => abs( $qty_weight ),
				'unit_price'     => $unit_price,
				'line_total'     => $line_total,
				'note'           => $item_note,
				'meta'           => $item_meta,
			];
			
			$total_amount += $line_total;
		}
		
		$meta = is_array( $data['meta'] ) ? $data['meta'] : [];
		$meta = array_filter( $meta, static function( $v, $k ) {
			return (string) $k !== '';
		}, ARRAY_FILTER_USE_BOTH );
		
		$now = current_time( 'mysql', TRUE );
		
		$this->db->query( 'START TRANSACTION' );
		
		$invoice_insert = [
			'supplier_user_id' => $supplier_user_id,
			'invoice_no'       => $invoice_no,
			'status'           => $status,
			'issued_at'        => $issued_at,
			'confirmed_at'     => $confirmed_at,
			'settled_at'       => $settled_at,
			'total_amount'     => (float) $total_amount,
			'currency'         => $currency,
			'note'             => $note,
			'created_at'       => $now,
		];
		
		// حذف NULLها برای جلوگیری از مشکل wpdb
		foreach ( [ 'invoice_no', 'confirmed_at', 'settled_at', 'note' ] as $k ) {
			if ( is_null( $invoice_insert[ $k ] ) ) {
				unset( $invoice_insert[ $k ] );
			}
		}
		
		$formats = [];
		foreach ( $invoice_insert as $k => $v ) {
			if ( $k === 'supplier_user_id' ) {
				$formats[] = '%d';
			} elseif ( $k === 'total_amount' ) {
				$formats[] = '%f';
			} else {
				$formats[] = '%s';
			}
		}
		
		$ok = $this->db->insert( $this->supplier_invoices, $invoice_insert, $formats );
		if ( $ok === FALSE ) {
			$this->db->query( 'ROLLBACK' );
			
			return $this->fail( 'خطا در ثبت فاکتور تامین‌کننده: ' . $this->db->last_error );
		}
		
		$invoice_id = (int) $this->db->insert_id;
		
		// meta invoice (magic route)
		if ( ! empty( $meta ) ) {
			$meta_res = $this->save_meta_batch( 'invoice', $invoice_id, $meta, TRUE );
			if ( ( $meta_res['status'] ?? '' ) !== 'success' ) {
				$this->db->query( 'ROLLBACK' );
				
				return $this->fail( 'ثبت متای فاکتور با خطا مواجه شد.', $meta_res );
			}
		}
		
		$item_ids = [];
		
		foreach ( $prepared_items as $item ) {
			$item_insert = [
				'invoice_id'     => $invoice_id,
				'raw_product_id' => (int) $item['raw_product_id'],
				'qty_weight'     => (float) $item['qty_weight'],
				'unit_price'     => (float) $item['unit_price'],
				'line_total'     => (float) $item['line_total'],
				'created_at'     => $now,
			];
			
			if ( ! is_null( $item['note'] ) ) {
				$item_insert['note'] = (string) $item['note'];
			}
			
			$item_formats = [];
			foreach ( $item_insert as $k => $v ) {
				if ( $k === 'invoice_id' || $k === 'raw_product_id' ) {
					$item_formats[] = '%d';
				} elseif ( in_array( $k, [ 'qty_weight', 'unit_price', 'line_total' ], TRUE ) ) {
					$item_formats[] = '%f';
				} else {
					$item_formats[] = '%s';
				}
			}
			
			$item_ok = $this->db->insert( $this->supplier_invoice_items, $item_insert, $item_formats );
			if ( $item_ok === FALSE ) {
				$this->db->query( 'ROLLBACK' );
				
				return $this->fail( 'خطا در ثبت آیتم‌های فاکتور: ' . $this->db->last_error );
			}
			
			$invoice_item_id = (int) $this->db->insert_id;
			$item_ids[]      = $invoice_item_id;
			
			// meta item (magic route)
			if ( ! empty( $item['meta'] ) ) {
				$item_meta_res = $this->save_meta_batch( 'invoice_item', $invoice_item_id, $item['meta'], TRUE );
				if ( ( $item_meta_res['status'] ?? '' ) !== 'success' ) {
					$this->db->query( 'ROLLBACK' );
					
					return $this->fail( 'ثبت متای آیتم فاکتور با خطا مواجه شد.', $item_meta_res );
				}
			}
		}
		
		$this->db->query( 'COMMIT' );
		
		if ( $status === 'confirmed' ) {
			$ledger_res = $this->add_ledger_entry( [
				'user_id'    => $supplier_user_id,
				'entry_type' => 'supplier_invoice_confirm',
				'type'       => 'credit',                    // بدهی به تامین‌کننده
				'amount'     => $total_amount,
				'ref_type'   => 'supplier_invoice',
				'ref_id'     => $invoice_id,
				'posted_at'  => $confirmed_at ?: $issued_at,
				'note'       => 'تایید فاکتور تامین‌کننده #' . $invoice_id,
				'meta'       => [
					'invoice_no' => $invoice_no,
					'status'     => 'confirmed',
				],
			] );
			
			if ( ( $ledger_res['status'] ?? '' ) !== 'success' ) {
				$this->db->query( 'ROLLBACK' );
				
				return $this->fail( 'ثبت آیتم حسابداری فاکتور تاییدشده با خطا مواجه شد.', $ledger_res );
			}
			$fee_expense_res = $this->sync_supplier_invoice_fee_expense( $invoice_id, [
				'id'               => $invoice_id,
				'supplier_user_id' => $supplier_user_id,
				'invoice_no'       => $invoice_no,
				'confirmed_at'     => $confirmed_at ?: $issued_at,
			], $confirmed_at ?: $issued_at );
			
			if ( ( $fee_expense_res['status'] ?? '' ) !== 'success' ) {
				return $this->fail( 'ثبت هزینه کارمزد فاکتور تاییدشده با خطا مواجه شد.', $fee_expense_res );
			}
		}
		
		return $this->ok( 'فاکتور تامین‌کننده با موفقیت ثبت شد.', [
			'invoice_id' => $invoice_id,
			'item_ids'   => $item_ids,
			'total'      => (float) $total_amount,
		] );
	}
	
	public function update_supplier_invoice( int $invoice_id, array $data ): array {
		$invoice_id = (int) $invoice_id;
		if ( $invoice_id <= 0 ) {
			return $this->fail( 'شناسه فاکتور معتبر نیست.' );
		}
		
		$current = $this->db->get_row(
			$this->db->prepare(
				"SELECT * FROM {$this->supplier_invoices} WHERE id = %d LIMIT 1",
				$invoice_id
			),
			ARRAY_A
		);
		
		if ( empty( $current ) ) {
			return $this->fail( 'فاکتور پیدا نشد.' );
		}
		
		if ( (string) $current['status'] !== 'proforma' ) {
			return $this->fail( 'فقط پیش‌فاکتور قابل ویرایش است.' );
		}
		
		$data = wp_parse_args( $data, [
			'invoice_no'   => NULL,
			'issued_at'    => (string) $current['issued_at'],
			'note'         => ( $current['note'] ?? NULL ),
			'meta'         => [],
			'items'        => [],
			// each: [ item_id?, raw_product_id, qty_weight, unit_price, line_total?, note?, meta? ]
			'delete_items' => [],
			// [item_id, ...]
		] );
		
		$invoice_no = is_null( $data['invoice_no'] ) ? NULL : trim( (string) $data['invoice_no'] );
		if ( $invoice_no === '' ) {
			$invoice_no = NULL;
		}
		
		$issued_at = trim( (string) $data['issued_at'] );
		if ( $issued_at === '' ) {
			$issued_at = (string) $current['issued_at'];
		}
		
		$note = is_null( $data['note'] ) ? NULL : trim( (string) $data['note'] );
		if ( $note === '' ) {
			$note = NULL;
		}
		
		$items = is_array( $data['items'] ) ? $data['items'] : [];
		
		$meta = is_array( $data['meta'] ) ? $data['meta'] : [];
		$meta = array_filter( $meta, static function( $v, $k ) {
			return (string) $k !== '';
		}, ARRAY_FILTER_USE_BOTH );
		
		$delete_items = is_array( $data['delete_items'] ) ? $data['delete_items'] : [];
		$delete_items = array_values( array_filter( array_map( 'intval', $delete_items ) ) );
		$delete_items = array_values( array_unique( $delete_items ) );
		
		if ( empty( $items ) && empty( $delete_items ) && empty( $meta ) ) {
			return $this->fail( 'هیچ تغییری برای اعمال ارسال نشده است.' );
		}
		
		if ( ! $this->workflow_storage_ready( 'supplier' ) ) {
			return $this->fail( 'مدیر باید ابتدا ثبت یکپارچه را از ابزارهای افزونه آماده کند.' );
		}
		$current_ids = array_map( 'intval', $this->db->get_col( $this->db->prepare( "SELECT id FROM {$this->supplier_invoice_items} WHERE invoice_id = %d", $invoice_id ) ) );
		if ( array_diff( $delete_items, $current_ids ) ) { return $this->fail( 'آیتم حذف‌شده متعلق به این پیش‌فاکتور نیست.' ); }
		$seen_ids = [];
		// آماده‌سازی آیتم‌ها
		$prepared_items = [];
		foreach ( $items as $idx => $item ) {
			$item = is_array( $item ) ? $item : [];
			
			$item_id = isset( $item['item_id'] ) ? (int) $item['item_id'] : 0;
			if ( $item_id > 0 && ( ! in_array( $item_id, $current_ids, TRUE ) || in_array( $item_id, $delete_items, TRUE ) || in_array( $item_id, $seen_ids, TRUE ) ) ) {
				return $this->fail( 'شناسه آیتم برای ویرایش نامعتبر یا تکراری است.' );
			}
			if ( $item_id > 0 ) { $seen_ids[] = $item_id; }
			
			$raw_product_id = (int) ( $item['raw_product_id'] ?? 0 );
			if ( $raw_product_id <= 0 ) {
				return $this->fail( 'محصول آیتم فاکتور معتبر نیست. (ردیف ' . ( (int) $idx + 1 ) . ')' );
			}
			
			$qty_weight = (float) ( $item['qty_weight'] ?? 0 );
			if ( $qty_weight <= 0 ) {
				return $this->fail( 'مقدار/وزن آیتم فاکتور معتبر نیست. (ردیف ' . ( (int) $idx + 1 ) . ')' );
			}
			
			$unit_price = (float) ( $item['unit_price'] ?? 0 );
			if ( $unit_price < 0 ) {
				return $this->fail( 'قیمت واحد آیتم فاکتور معتبر نیست. (ردیف ' . ( (int) $idx + 1 ) . ')' );
			}
			
			$line_total = isset( $item['line_total'] )
				? (float) $item['line_total']
				: (float) ( $qty_weight * $unit_price );
			
			if ( $line_total < 0 ) {
				return $this->fail( 'مبلغ آیتم فاکتور معتبر نیست. (ردیف ' . ( (int) $idx + 1 ) . ')' );
			}
			
			$item_note = is_null( $item['note'] ?? NULL ) ? NULL : trim( (string) $item['note'] );
			if ( $item_note === '' ) {
				$item_note = NULL;
			}
			
			$item_meta = is_array( $item['meta'] ?? NULL ) ? (array) $item['meta'] : [];
			$item_meta = array_filter( $item_meta, static function( $v, $k ) {
				return (string) $k !== '';
			}, ARRAY_FILTER_USE_BOTH );
			
			$prepared_items[] = [
				'item_id'        => $item_id,
				'raw_product_id' => $raw_product_id,
				'qty_weight'     => abs( $qty_weight ),
				'unit_price'     => $unit_price,
				'line_total'     => $line_total,
				'note'           => $item_note,
				'meta'           => $item_meta,
			];
		}
		
		$now = current_time( 'mysql', TRUE );
		
		if ( FALSE === $this->db->query( 'START TRANSACTION' ) ) { return $this->fail( 'شروع تراکنش ناموفق بود.' ); }
		
		$locked_invoice = $this->db->get_row( $this->db->prepare( "SELECT status FROM {$this->supplier_invoices} WHERE id = %d FOR UPDATE", $invoice_id ), ARRAY_A );
		if ( ! $locked_invoice || $locked_invoice['status'] !== 'proforma' ) {
			$this->db->query( 'ROLLBACK' );
			return $this->fail( 'وضعیت پیش‌فاکتور تغییر کرده؛ صفحه را تازه کنید.' );
		}
		$locked_ids = array_map( 'intval', $this->db->get_col( $this->db->prepare( "SELECT id FROM {$this->supplier_invoice_items} WHERE invoice_id = %d FOR UPDATE", $invoice_id ) ) );
		if ( $this->db->last_error || array_diff( $delete_items, $locked_ids ) || array_diff( $seen_ids, $locked_ids ) ) {
			$this->db->query( 'ROLLBACK' );
			return $this->fail( 'آیتم‌های پیش‌فاکتور تغییر کرده‌اند؛ صفحه را تازه کنید.' );
		}
		// آپدیت هدر فاکتور
		$invoice_update = [
			'invoice_no' => $invoice_no, // می‌تونه NULL باشه
			'issued_at'  => $issued_at,
			'note'       => $note,       // می‌تونه NULL باشه
		];
		
		$ok = $this->db->update(
			$this->supplier_invoices,
			$invoice_update,
			[ 'id' => $invoice_id ],
			[ '%s', '%s', '%s' ],
			[ '%d' ]
		);
		
		if ( $ok === FALSE ) {
			$this->db->query( 'ROLLBACK' );
			
			return $this->fail( 'خطا در بروزرسانی فاکتور تامین‌کننده: ' . $this->db->last_error );
		}
		
		// meta invoice
		if ( ! empty( $meta ) ) {
			$meta_res = $this->save_meta_batch( 'invoice', $invoice_id, $meta, TRUE );
			if ( ( $meta_res['status'] ?? '' ) !== 'success' ) {
				$this->db->query( 'ROLLBACK' );
				
				return $this->fail( 'ثبت متای فاکتور با خطا مواجه شد.', $meta_res );
			}
		}
		
		// حذف آیتم‌ها
		if ( ! empty( $delete_items ) ) {
			foreach ( $delete_items as $del_id ) {
				$del_id = (int) $del_id;
				if ( $del_id <= 0 ) {
					continue;
				}
				
				$del = $this->db->delete(
					$this->supplier_invoice_items,
					[
						'id'         => $del_id,
						'invoice_id' => $invoice_id,
					],
					[ '%d', '%d' ]
				);
				
				if ( $del !== 1 ) {
					$this->db->query( 'ROLLBACK' );
					
					return $this->fail( 'خطا در حذف آیتم فاکتور: ' . $this->db->last_error );
				}
				if ( FALSE === $this->db->delete( $this->db_prefix . 'invoice_item_meta', [ 'invoice_item_id' => $del_id ], [ '%d' ] ) ) {
					$this->db->query( 'ROLLBACK' );
					return $this->fail( 'حذف اطلاعات تکمیلی آیتم ناموفق بود.' );
				}
			}
		}
		
		// افزودن / آپدیت آیتم‌ها
		foreach ( $prepared_items as $item ) {
			$item_id = (int) $item['item_id'];
			
			$item_row = [
				'invoice_id'     => $invoice_id,
				'raw_product_id' => (int) $item['raw_product_id'],
				'qty_weight'     => (float) $item['qty_weight'],
				'unit_price'     => (float) $item['unit_price'],
				'line_total'     => (float) $item['line_total'],
				'note'           => $item['note'],
			];
			
			if ( $item_id > 0 ) {
				$item_ok = $this->db->update(
					$this->supplier_invoice_items,
					$item_row,
					[
						'id'         => $item_id,
						'invoice_id' => $invoice_id,
					],
					[ '%d', '%d', '%f', '%f', '%f', '%s' ],
					[ '%d', '%d' ]
				);
				
				if ( $item_ok === FALSE ) {
					$this->db->query( 'ROLLBACK' );
					
					return $this->fail( 'خطا در بروزرسانی آیتم فاکتور: ' . $this->db->last_error );
				}
				
				$invoice_item_id = $item_id;
			} else {
				$item_row['created_at'] = $now;
				
				$item_ok = $this->db->insert(
					$this->supplier_invoice_items,
					$item_row,
					[ '%d', '%d', '%f', '%f', '%f', '%s', '%s' ]
				);
				
				if ( $item_ok === FALSE ) {
					$this->db->query( 'ROLLBACK' );
					
					return $this->fail( 'خطا در افزودن آیتم فاکتور: ' . $this->db->last_error );
				}
				
				$invoice_item_id = (int) $this->db->insert_id;
			}
			
			// meta item
			if ( ! empty( $item['meta'] ) ) {
				$item_meta_res = $this->save_meta_batch( 'invoice_item', $invoice_item_id, $item['meta'], TRUE );
				if ( ( $item_meta_res['status'] ?? '' ) !== 'success' ) {
					$this->db->query( 'ROLLBACK' );
					
					return $this->fail( 'ثبت متای آیتم فاکتور با خطا مواجه شد.', $item_meta_res );
				}
			}
		}
		
		// total_amount نهایی از دیتابیس
		$total_amount = (float) $this->db->get_var(
			$this->db->prepare(
				"SELECT COALESCE(SUM(line_total),0)
			 FROM {$this->supplier_invoice_items}
			 WHERE invoice_id = %d",
				$invoice_id
			)
		);
		
		$total_ok = $this->db->update(
			$this->supplier_invoices,
			[ 'total_amount' => $total_amount ],
			[ 'id' => $invoice_id ],
			[ '%f' ],
			[ '%d' ]
		);
		
		if ( $total_ok === FALSE ) {
			$this->db->query( 'ROLLBACK' );
			
			return $this->fail( 'خطا در بروزرسانی مبلغ نهایی فاکتور: ' . $this->db->last_error );
		}
		
		if ( FALSE === $this->db->query( 'COMMIT' ) ) {
			$this->db->query( 'ROLLBACK' );
			return $this->fail( 'ثبت نهایی پیش‌فاکتور ناموفق بود.' );
		}
		
		return $this->ok( 'پیش‌فاکتور با موفقیت بروزرسانی شد.', [
			'invoice_id'   => $invoice_id,
			'total_amount' => $total_amount,
		] );
	}
	
	public function get_supplier_invoice_status( int $invoice_id ): ?string {
		$invoice_id = (int) $invoice_id;
		
		if ( $invoice_id <= 0 ) {
			return NULL;
		}
		
		$sql = "
		SELECT si.status
		FROM {$this->supplier_invoices} si
		WHERE si.id = %d
		LIMIT 1
	";
		
		$status = $this->db->get_var(
			$this->db->prepare( $sql, $invoice_id )
		);
		
		return $status !== NULL ? (string) $status : NULL;
	}
	
	private function update_invoice_item_rate_locked( $item_id, $rate, $month ): array {
		$unit_cost = $this->get_invoice_item_meta( $item_id, 'per_unit_base', TRUE );
		$this->update_invoice_item_meta( $item_id, 'month', $month );
		$this->update_invoice_item_meta( $item_id, 'rate', $rate );
		
		if ( $rate < 100 ) {
			$rate = $unit_cost * $rate / 100;
		}
		$unit_price = ( $month * $rate ) + $unit_cost;
		$line_data  = $this->db->get_row(
			$this->db->prepare(
				"SELECT * FROM {$this->supplier_invoice_items} WHERE id = %d ORDER BY id ASC",
				$item_id
			),
			ARRAY_A
		);
		$line_total = $line_data['qty_weight'] * $unit_price;
		$this->db->update(
			$this->supplier_invoice_items,
			[
				'unit_price' => $unit_price,
				'line_total' => $line_total,
			],
			[
				'id' => $item_id,
			]
		);
		$invoice_id   = $line_data['invoice_id'];
		$invoice_data = $this->get_invoice_data( $invoice_id );
		$items        = $invoice_data['items'];
		$total_amount = 0;
		foreach ( $items as $item ) {
			$total_amount += $item['line_total'];
		}
		$this->db->update(
			$this->supplier_invoices,
			[
				'total_amount' => $total_amount,
			],
			[
				'id' => $invoice_id,
			]
		);
		$this->db->update(
			$this->ledger_entries,
			[
				'amount' => $total_amount,
			],
			[
				'ref_type' => 'supplier_invoice',
				'ref_id'   => $invoice_id,
			]
		);
		$fee_expense_res = $this->sync_supplier_invoice_fee_expense( (int) $invoice_id );
		if ( ( $fee_expense_res['status'] ?? '' ) !== 'success' ) {
			return $this->fail( 'به‌روزرسانی هزینه کارمزد فاکتور با خطا مواجه شد.', $fee_expense_res );
		}
		
		return $this->ok( 'موارد فاکتور با موفقیت تغییر کرد.', );
	}
	
	private function get_supplier_invoice_fee_cost_type_key(): string {
		$key        = 'supplier_invoice_fee';
		$cost_types = get_option( 'kph_cost_category', [] );
		$cost_types = is_array( $cost_types ) ? $cost_types : [];
		
		if ( ! isset( $cost_types[ $key ] ) || ! is_array( $cost_types[ $key ] ) ) {
			$cost_types[ $key ] = [
				'label' => 'کارمزد فاکتور تامین‌کننده',
			];
			update_option( 'kph_cost_category', $cost_types );
		} elseif ( empty( $cost_types[ $key ]['label'] ) ) {
			$cost_types[ $key ]['label'] = 'کارمزد فاکتور تامین‌کننده';
			update_option( 'kph_cost_category', $cost_types );
		}
		
		return $key;
	}
	
	private function get_supplier_invoice_fee_expense_account_id(): int {
		$system_key = 'supplier_invoice_fee';
		$title      = 'کارمزد فاکتور تامین‌کننده';
		
		[ $account_meta_table, $account_meta_fk ] = $this->resolve_meta_table( 'account' );
		
		if ( $account_meta_table && $account_meta_fk ) {
			$account_id = (int) $this->db->get_var(
				$this->db->prepare(
					"SELECT a.id
				 FROM {$this->accounts} a
				 INNER JOIN {$account_meta_table} am
				 	ON am.{$account_meta_fk} = a.id
				 	AND am.meta_key = 'system_key'
				 	AND am.meta_value = %s
				 WHERE a.type = 'expense'
				 LIMIT 1",
					$system_key
				)
			);
			
			if ( $account_id > 0 ) {
				return $account_id;
			}
		}
		
		$account_id = (int) $this->db->get_var(
			$this->db->prepare(
				"SELECT id FROM {$this->accounts} WHERE type = 'expense' AND title = %s LIMIT 1",
				$title
			)
		);
		
		if ( $account_id > 0 ) {
			$this->save_meta_batch( 'account', $account_id, [
				'system_key'   => $system_key,
				'auto_created' => 1,
			], TRUE );
			
			return $account_id;
		}
		
		$ok = $this->db->insert(
			$this->accounts,
			[
				'title'      => $title,
				'type'       => 'expense',
				'balance'    => 0,
				'status'     => 'active',
				'created_by' => get_current_user_id(),
				'created_at' => current_time( 'mysql' ),
			],
			[ '%s', '%s', '%d', '%s', '%d', '%s' ]
		);
		
		if ( $ok === FALSE ) {
			return 0;
		}
		
		$account_id = (int) $this->db->insert_id;
		
		$this->save_meta_batch( 'account', $account_id, [
			'system_key'   => $system_key,
			'auto_created' => 1,
		], TRUE );
		
		return $account_id;
	}
	
	public function calculate_supplier_invoice_fee_total( int $invoice_id ): float {
		$items = $this->db->get_results(
			$this->db->prepare(
				"SELECT id, qty_weight, line_total
			 FROM {$this->supplier_invoice_items}
			 WHERE invoice_id = %d",
				$invoice_id
			),
			ARRAY_A
		);
		
		if ( empty( $items ) ) {
			return 0.0;
		}
		
		$total_fee = 0.0;
		
		foreach ( $items as $item ) {
			$item_id    = (int) ( $item['id'] ?? 0 );
			$qty        = (float) ( $item['qty_weight'] ?? 0 );
			$line_total = (float) ( $item['line_total'] ?? 0 );
			
			if ( $item_id <= 0 || $qty <= 0 || $line_total <= 0 ) {
				continue;
			}
			
			$base_price = (float) $this->get_invoice_item_meta( $item_id, 'per_unit_base', TRUE );
			$month      = (float) $this->get_invoice_item_meta( $item_id, 'month', TRUE );
			$rate       = (float) $this->get_invoice_item_meta( $item_id, 'rate', TRUE );
			$fee        = 0.0;
			
			if ( $base_price > 0 && $month > 0 && $rate > 0 ) {
				$fee_per_unit = $rate < 100
					? ( $base_price * $rate / 100 )
					: $rate;
				
				$fee = ( $month * $fee_per_unit ) * $qty;
			}
			
			if ( $fee <= 0 && $base_price > 0 ) {
				$fee = $line_total - ( $base_price * $qty );
			}
			
			if ( $fee > 0 ) {
				$total_fee += $fee;
			}
		}
		
		return round( max( 0, $total_fee ), 2 );
	}
	
	private function get_supplier_invoice_fee_expense_row( int $invoice_id ): ?array {
		[ $trx_meta_table, $trx_meta_fk ] = $this->resolve_meta_table( 'account_transaction' );
		
		if ( ! $trx_meta_table || ! $trx_meta_fk ) {
			return NULL;
		}
		
		$row = $this->db->get_row(
			$this->db->prepare(
				"SELECT t.*
			 FROM {$this->account_transactions} t
			 INNER JOIN {$trx_meta_table} im
			 	ON im.{$trx_meta_fk} = t.id
			 	AND im.meta_key = 'invoice_id'
			 	AND im.meta_value = %s
			 INNER JOIN {$trx_meta_table} sm
			 	ON sm.{$trx_meta_fk} = t.id
			 	AND sm.meta_key = 'source'
			 	AND sm.meta_value = 'supplier_invoice_fee'
			 WHERE t.action = 'supplier_invoice_fee'
			 LIMIT 1",
				(string) $invoice_id
			),
			ARRAY_A
		);
		
		return $row ?: NULL;
	}
	
	private function delete_supplier_invoice_fee_expense_row( array $row ): array {
		$transaction_id = (int) ( $row['id'] ?? 0 );
		$account_id     = (int) ( $row['account_id'] ?? 0 );
		$amount         = (int) ( $row['amount'] ?? 0 );
		$type           = (string) ( $row['type'] ?? '' );
		
		if ( $transaction_id <= 0 || $account_id <= 0 || $amount <= 0 ) {
			return $this->ok( 'ردیف هزینه‌ای برای حذف وجود ندارد.' );
		}
		
		$account = $this->db->get_row(
			$this->db->prepare(
				"SELECT id, balance FROM {$this->accounts} WHERE id = %d LIMIT 1 FOR UPDATE",
				$account_id
			),
			ARRAY_A
		);
		
		if ( ! $account ) {
			return $this->fail( 'حساب هزینه کارمزد پیدا نشد.' );
		}
		
		$new_balance = (int) $account['balance'];
		$new_balance = $type === 'debit'
			? $new_balance + $amount
			: $new_balance - $amount;
		
		$updated = $this->db->update(
			$this->accounts,
			[
				'balance'    => $new_balance,
				'updated_at' => current_time( 'mysql' ),
			],
			[ 'id' => $account_id ],
			[ '%d', '%s' ],
			[ '%d' ]
		);
		
		if ( $updated === FALSE ) {
			return $this->fail( 'برگشت مانده حساب هزینه کارمزد ناموفق بود.' );
		}
		
		$this->delete_meta( 'account_transaction', $transaction_id );
		
		$deleted = $this->db->delete(
			$this->account_transactions,
			[ 'id' => $transaction_id ],
			[ '%d' ]
		);
		
		if ( $deleted === FALSE ) {
			return $this->fail( 'حذف ردیف هزینه کارمزد ناموفق بود.' );
		}
		
		return $this->ok( 'هزینه کارمزد حذف شد.' );
	}
	
	private function sync_supplier_invoice_fee_expense( int $invoice_id, array $invoice = [], string $posted_at = '' ): array {
		$invoice_id = (int) $invoice_id;
		
		if ( $invoice_id <= 0 ) {
			return $this->fail( 'شناسه فاکتور برای ثبت هزینه کارمزد معتبر نیست.' );
		}
		
		if ( empty( $invoice ) ) {
			$invoice = $this->db->get_row(
				$this->db->prepare(
					"SELECT * FROM {$this->supplier_invoices} WHERE id = %d LIMIT 1 FOR UPDATE",
					$invoice_id
				),
				ARRAY_A
			);
		}
		
		if ( empty( $invoice ) ) {
			return $this->fail( 'فاکتور برای ثبت هزینه کارمزد پیدا نشد.' );
		}
		
		$existing = $this->get_supplier_invoice_fee_expense_row( $invoice_id );
		$amount   = (int) round( $this->calculate_supplier_invoice_fee_total( $invoice_id ) );
		
		if ( $amount <= 0 ) {
			return $existing
				? $this->delete_supplier_invoice_fee_expense_row( $existing )
				: $this->ok( 'این فاکتور کارمزدی برای ثبت هزینه ندارد.', [ 'amount' => 0 ] );
		}
		
		$cost_type  = $this->get_supplier_invoice_fee_cost_type_key();
		$account_id = $existing ? (int) $existing['account_id'] : $this->get_supplier_invoice_fee_expense_account_id();
		
		if ( $account_id <= 0 ) {
			return $this->fail( 'حساب هزینه کارمزد فاکتور تامین‌کننده ساخته نشد.' );
		}
		
		$account = $this->db->get_row(
			$this->db->prepare(
				"SELECT id, type, balance FROM {$this->accounts} WHERE id = %d LIMIT 1 FOR UPDATE",
				$account_id
			),
			ARRAY_A
		);
		
		if ( ! $account ) {
			return $this->fail( 'حساب هزینه کارمزد فاکتور تامین‌کننده پیدا نشد.' );
		}
		
		$supplier_user_id = (int) ( $invoice['supplier_user_id'] ?? 0 );
		$supplier         = $supplier_user_id > 0 ? get_userdata( $supplier_user_id ) : NULL;
		$supplier_name    = $supplier ? $supplier->display_name : '';
		$invoice_no       = (string) ( $invoice['invoice_no'] ?? '' );
		$posted_at        = $posted_at ?: ( (string) ( $invoice['confirmed_at'] ?? '' ) ?: current_time( 'mysql' ) );
		$description      = 'ثبت هزینه کارمزد فاکتور تامین‌کننده #' . $invoice_id;
		
		if ( $invoice_no !== '' ) {
			$description .= ' - شماره فاکتور: ' . $invoice_no;
		}
		
		if ( $supplier_name !== '' ) {
			$description .= ' - تامین‌کننده: ' . $supplier_name;
		}
		
		$current_balance = (int) $account['balance'];
		$old_amount      = $existing ? (int) $existing['amount'] : 0;
		$delta           = $amount - $old_amount;
		$new_balance     = $current_balance - $delta;
		
		if ( $new_balance < 0 && (string) $account['type'] !== 'expense' ) {
			return $this->fail( 'موجودی حساب برای ثبت هزینه کارمزد کافی نیست.' );
		}
		
		if ( $existing ) {
			$transaction_id = (int) $existing['id'];
			
			$ok = $this->db->update(
				$this->account_transactions,
				[
					'amount'        => $amount,
					'type'          => 'debit',
					'action'        => 'supplier_invoice_fee',
					'balance_after' => $new_balance,
					'description'   => $description,
					'created_at'    => $posted_at,
				],
				[ 'id' => $transaction_id ],
				[ '%d', '%s', '%s', '%d', '%s', '%s' ],
				[ '%d' ]
			);
		} else {
			$ok = $this->db->insert(
				$this->account_transactions,
				[
					'account_id'    => $account_id,
					'amount'        => $amount,
					'type'          => 'debit',
					'action'        => 'supplier_invoice_fee',
					'balance_after' => $new_balance,
					'description'   => $description,
					'created_by'    => get_current_user_id(),
					'created_at'    => $posted_at,
				],
				[ '%d', '%d', '%s', '%s', '%d', '%s', '%d', '%s' ]
			);
			
			$transaction_id = (int) $this->db->insert_id;
		}
		
		if ( $ok === FALSE ) {
			return $this->fail( 'ثبت هزینه کارمزد فاکتور تامین‌کننده ناموفق بود: ' . $this->db->last_error );
		}
		
		$balance_ok = $this->db->update(
			$this->accounts,
			[
				'balance'    => $new_balance,
				'updated_at' => current_time( 'mysql' ),
			],
			[ 'id' => $account_id ],
			[ '%d', '%s' ],
			[ '%d' ]
		);
		
		if ( $balance_ok === FALSE ) {
			return $this->fail( 'به‌روزرسانی مانده حساب هزینه کارمزد ناموفق بود.' );
		}
		
		$meta_res = $this->save_meta_batch( 'account_transaction', $transaction_id, [
			'cost_type'        => $cost_type,
			'destination'      => $supplier_name ?: 'تامین‌کننده',
			'source'           => 'supplier_invoice_fee',
			'invoice_id'       => $invoice_id,
			'invoice_no'       => $invoice_no,
			'supplier_user_id' => $supplier_user_id,
		], TRUE );
		
		if ( ( $meta_res['status'] ?? '' ) !== 'success' ) {
			return $this->fail( 'ثبت متای هزینه کارمزد فاکتور ناموفق بود.', $meta_res );
		}
		
		return $this->ok( 'هزینه کارمزد فاکتور تامین‌کننده ثبت شد.', [
			'transaction_id' => $transaction_id,
			'account_id'     => $account_id,
			'amount'         => $amount,
		] );
	}
	
	public function change_supplier_invoice_status( int $invoice_id, string $new_status, array $meta = [] ): array {
		$invoice_id = (int) $invoice_id;
		if ( $invoice_id <= 0 ) {
			return $this->fail( 'شناسه فاکتور معتبر نیست.' );
		}
		
		$new_status = strtolower( trim( $new_status ) );
		$allowed    = [ 'proforma', 'confirmed', 'settled' ];
		
		if ( ! in_array( $new_status, $allowed, TRUE ) ) {
			return $this->fail( 'وضعیت جدید معتبر نیست.' );
		}
		
		$invoice = $this->db->get_row(
			$this->db->prepare(
				"SELECT * FROM {$this->supplier_invoices} WHERE id = %d LIMIT 1",
				$invoice_id
			),
			ARRAY_A
		);
		
		if ( empty( $invoice ) ) {
			return $this->fail( 'فاکتور پیدا نشد.' );
		}
		
		$old_status = (string) $invoice['status'];
		if ( $old_status === $new_status ) {
			return $this->fail( 'وضعیت فاکتور تغییری نکرده است.' );
		}
		
		// قوانین تغییر وضعیت
		$allowed_transitions = [
			'proforma'  => [ 'confirmed' ],
			'confirmed' => [ 'settled' ],
		];
		
		if ( ! isset( $allowed_transitions[ $old_status ] )
		     || ! in_array( $new_status, $allowed_transitions[ $old_status ], TRUE ) ) {
			return $this->fail( 'این تغییر وضعیت مجاز نیست.' );
		}
		
		$now = current_time( 'mysql', TRUE );
		
		$this->db->query( 'START TRANSACTION' );
        $locked = $this->db->get_row($this->db->prepare("SELECT * FROM {$this->supplier_invoices} WHERE id=%d FOR UPDATE",$invoice_id),ARRAY_A);
        if (!$locked || $this->db->last_error || $locked['status'] !== $old_status) {
            $this->db->query('ROLLBACK');
            return $this->fail('فاکتور حذف شده یا وضعیت آن تغییر کرده است؛ صفحه را تازه کنید.');
        }
        $invoice = $locked;

		
		$update = [
			'status' => $new_status,
		];
		
		if ( $new_status === 'confirmed' ) {
			$update['confirmed_at'] = $now;
		}
		
		if ( $new_status === 'settled' ) {
			$update['settled_at'] = $now;
		}
		
		$ok = $this->db->update(
			$this->supplier_invoices,
			$update,
			[ 'id' => $invoice_id ],
			array_fill( 0, count( $update ), '%s' ),
			[ '%d' ]
		);
		
		if ( $ok === FALSE ) {
			$this->db->query( 'ROLLBACK' );
			
			return $this->fail( 'خطا در بروزرسانی وضعیت فاکتور.' );
		}
		
		// ذخیره متا (اختیاری)
		$meta = is_array( $meta ) ? $meta : [];
		if ( ! empty( $meta ) ) {
			$meta_res = $this->save_meta_batch( 'invoice', $invoice_id, $meta, TRUE );
			if ( ( $meta_res['status'] ?? '' ) !== 'success' ) {
				$this->db->query( 'ROLLBACK' );
				
				return $this->fail( 'ذخیره متای تغییر وضعیت ناموفق بود.', $meta_res );
			}
		}
		
		// ===== ثبت ورود کالا به مخزن (فقط در زمان تایید پیش‌فاکتور) =====
		if ( $old_status === 'proforma' && $new_status === 'confirmed' ) {
			$stock_res = $this->apply_supplier_invoice_confirmed_to_stock( $invoice_id, $invoice, $now );
			if ( ( $stock_res['status'] ?? '' ) !== 'success' ) {
				$this->db->query( 'ROLLBACK' );
				
				return $this->fail( 'ثبت ورود کالا به مخزن ناموفق بود.', $stock_res );
			}
			$fee_expense_res = $this->sync_supplier_invoice_fee_expense( $invoice_id, $invoice, $now );
			
			if ( ( $fee_expense_res['status'] ?? '' ) !== 'success' ) {
				$this->db->query( 'ROLLBACK' );
				
				return $this->fail( 'ثبت هزینه کارمزد فاکتور تاییدشده با خطا مواجه شد.', $fee_expense_res );
			}
		}
		
		// ثبت لجر فقط در زمان تایید
		if ( $old_status === 'proforma' && $new_status === 'confirmed' ) {
			$ledger_res = $this->add_ledger_entry( [
				'user_id'    => (int) $invoice['supplier_user_id'],
				'entry_type' => 'supplier_invoice_confirm',
				'type'       => 'credit',
				'amount'     => (float) $invoice['total_amount'],
				'ref_type'   => 'supplier_invoice',
				'ref_id'     => $invoice_id,
				'posted_at'  => $invoice['issued_at'],
				'note'       => 'تایید فاکتور تامین‌کننده #' . $invoice_id,
				'meta'       => [
					'invoice_no' => $invoice['invoice_no'] ?? NULL,
					'from'       => 'status_change',
				],
			] );
			
			if ( ( $ledger_res['status'] ?? '' ) !== 'success' ) {
				$this->db->query( 'ROLLBACK' );
				
				return $this->fail( 'ثبت آیتم حسابداری فاکتور تاییدشده با خطا مواجه شد.', $ledger_res );
			}
		}
		
		$this->db->query( 'COMMIT' );
		
		$invoice['status'] = $new_status;
		
		do_action( 'kph_supplier_invoice_status_changed', $invoice_id, $old_status, $new_status, $invoice );
		
		return $this->ok( 'وضعیت فاکتور با موفقیت تغییر کرد.', [
			'invoice_id' => $invoice_id,
			'from'       => $old_status,
			'to'         => $new_status,
		] );
	}
	
	public function get_supplier_invoices( array $args = [] ): array {
		$args = wp_parse_args( $args, [
			'page'             => 1,
			'per_page'         => 20,
			'supplier_user_id' => 0,
			'supplier_group'   => NULL,  // ✅ NEW: string|array|null
			'status'           => NULL,  // proforma|confirmed|settled|array|null
			'search'           => '',    // invoice_no | note | id
			'ref_type'         => NULL,
			'ref_id'           => NULL,
			'date_from'        => NULL,  // issued_at >=
			'date_to'          => NULL,  // issued_at <=
			'min_total'        => NULL,
			'max_total'        => NULL,
			'orderby'          => 'issued_at',
			'order'            => 'DESC',
		] );
		
		$page     = max( 1, (int) $args['page'] );
		$per_page = max( 1, min( 200, (int) $args['per_page'] ) );
		$offset   = ( $page - 1 ) * $per_page;
		
		$allowed_orderby = [
			'issued_at'    => 'i.issued_at',
			'id'           => 'i.id',
			'total_amount' => 'i.total_amount',
			'created_at'   => 'i.created_at',
			'confirmed_at' => 'i.confirmed_at',
			'settled_at'   => 'i.settled_at',
		];
		$orderby         = $allowed_orderby[ (string) $args['orderby'] ] ?? 'i.issued_at';
		
		$order = strtoupper( (string) $args['order'] );
		$order = in_array( $order, [ 'ASC', 'DESC' ], TRUE ) ? $order : 'DESC';
		
		$where = ["NOT EXISTS (SELECT 1 FROM {$this->db_prefix}invoice_meta deleted_invoice WHERE deleted_invoice.invoice_id=i.id AND deleted_invoice.meta_key='supplier_deleted' AND deleted_invoice.meta_value='1')"];
		$binds = [];
		
		// ✅ NEW: optional join for supplier_group filter
		$join_sql  = '';
		$group_key = 'kph_supplier_group';
		
		// supplier filter
		$supplier_user_id = (int) $args['supplier_user_id'];
		if ( $supplier_user_id > 0 ) {
			$where[] = 'i.supplier_user_id = %d';
			$binds[] = $supplier_user_id;
		}
		
		// ✅ NEW: supplier_group filter (user_meta: kph_supplier_group)
		if ( ! is_null( $args['supplier_group'] ) && $args['supplier_group'] !== '' ) {
			$join_sql .= " INNER JOIN {$this->db->usermeta} um_group
			ON (um_group.user_id = i.supplier_user_id AND um_group.meta_key = %s) ";
			$binds[]  = $group_key;
			
			if ( is_array( $args['supplier_group'] ) ) {
				$groups = array_values( array_filter( array_map( 'trim', array_map( 'strval', $args['supplier_group'] ) ) ) );
				$groups = array_values( array_unique( $groups ) );
				
				if ( ! empty( $groups ) ) {
					$placeholders = implode( ',', array_fill( 0, count( $groups ), '%s' ) );
					$where[]      = "um_group.meta_value IN ({$placeholders})";
					$binds        = array_merge( $binds, $groups );
				}
			} else {
				$group = trim( (string) $args['supplier_group'] );
				if ( $group !== '' ) {
					$where[] = 'um_group.meta_value = %s';
					$binds[] = $group;
				}
			}
		}
		
		// status filter
		if ( ! is_null( $args['status'] ) && $args['status'] !== '' ) {
			$allowed_statuses = [ 'proforma', 'confirmed', 'settled', 'canceled' ];
			
			if ( is_array( $args['status'] ) ) {
				$statuses = array_values( array_filter( array_map( 'trim', array_map( 'strval', $args['status'] ) ) ) );
				$statuses = array_values( array_unique( $statuses ) );
				$statuses = array_values( array_filter( $statuses, static fn( string $s ): bool => in_array( $s, $allowed_statuses, TRUE ) ) );
				
				if ( ! empty( $statuses ) ) {
					$placeholders = implode( ',', array_fill( 0, count( $statuses ), '%s' ) );
					$where[]      = "i.status IN ({$placeholders})";
					$binds        = array_merge( $binds, $statuses );
				}
			} else {
				$st = strtolower( trim( (string) $args['status'] ) );
				if ( in_array( $st, $allowed_statuses, TRUE ) ) {
					$where[] = 'i.status = %s';
					$binds[] = $st;
				}
			}
		}
		
		// date range (issued_at)
		if ( ! is_null( $args['date_from'] ) && $args['date_from'] !== '' ) {
			$where[] = 'i.issued_at >= %s';
			$binds[] = (string) $args['date_from'];
		}
		if ( ! is_null( $args['date_to'] ) && $args['date_to'] !== '' ) {
			$where[] = 'i.issued_at <= %s';
			$binds[] = (string) $args['date_to'];
		}
		
		// total range
		if ( $args['min_total'] !== NULL && $args['min_total'] !== '' ) {
			$where[] = 'i.total_amount >= %f';
			$binds[] = (float) $args['min_total'];
		}
		if ( $args['max_total'] !== NULL && $args['max_total'] !== '' ) {
			$where[] = 'i.total_amount <= %f';
			$binds[] = (float) $args['max_total'];
		}
		
		// search
		$search = trim( (string) $args['search'] );
		if ( $search !== '' ) {
			$like    = '%' . $this->db->esc_like( $search ) . '%';
			$where[] = '(i.invoice_no LIKE %s OR i.note LIKE %s OR i.id = %d)';
			$binds[] = $like;
			$binds[] = $like;
			$binds[] = (int) $search;
		}
		
		$where_sql = implode( ' AND ', $where );
		
		$sql_rows = "
		SELECT i.*
		FROM {$this->supplier_invoices} i
		{$join_sql}
		WHERE {$where_sql}
		ORDER BY {$orderby} {$order}, i.id {$order}
		LIMIT %d OFFSET %d
	";
		
		$rows_sql = $this->db->prepare( $sql_rows, array_merge( $binds, [ $per_page, $offset ] ) );
		$rows     = $this->db->get_results( $rows_sql, ARRAY_A );
		
		if ( $rows === NULL ) {
			return [
				'items'      => [],
				'pagination' => [
					'page'       => $page,
					'per_page'   => $per_page,
					'total'      => 0,
					'total_page' => 1,
				],
				'error'      => 'خطا در دریافت لیست فاکتورهای تامین‌کننده: ' . $this->db->last_error,
			];
		}
		
		$sql_count  = "
		SELECT COUNT(*)
		FROM {$this->supplier_invoices} i
		{$join_sql}
		WHERE {$where_sql}
	";
		$count_sql  = empty( $binds ) ? $sql_count : $this->db->prepare( $sql_count, $binds );
		$total      = (int) $this->db->get_var( $count_sql );
		$total_page = (int) max( 1, ceil( $total / $per_page ) );
		
		$items = [];
		foreach ( $rows as $r ) {
			$items[] = [
				'id'               => (int) $r['id'],
				'supplier_user_id' => (int) $r['supplier_user_id'],
				'invoice_no'       => isset( $r['invoice_no'] ) ? (string) $r['invoice_no'] : NULL,
				'status'           => (string) $r['status'],
				'issued_at'        => (string) $r['issued_at'],
				'confirmed_at'     => isset( $r['confirmed_at'] ) ? ( $r['confirmed_at'] !== NULL ? (string) $r['confirmed_at'] : NULL ) : NULL,
				'settled_at'       => isset( $r['settled_at'] ) ? ( $r['settled_at'] !== NULL ? (string) $r['settled_at'] : NULL ) : NULL,
				'total_amount'     => (float) $r['total_amount'],
				'note'             => isset( $r['note'] ) ? ( $r['note'] !== NULL ? (string) $r['note'] : NULL ) : NULL,
				'created_at'       => (string) $r['created_at'],
			];
		}
		
		return [
			'items'      => $items,
			'pagination' => [
				'page'       => $page,
				'per_page'   => $per_page,
				'total'      => $total,
				'total_page' => $total_page,
			],
		];
	}
	
	public function get_supplier_invoice_items( int $invoice_id ): array {
		$invoice_id = (int) $invoice_id;
		if ( $invoice_id <= 0 ) {
			return [
				'items' => [],
				'error' => 'شناسه فاکتور معتبر نیست.',
			];
		}
		
		$rows = $this->db->get_results(
			$this->db->prepare(
				"SELECT it.*, p.code AS raw_product_code, p.title AS raw_product_title
			 FROM {$this->supplier_invoice_items} it
			 LEFT JOIN {$this->raw_products} p ON p.id = it.raw_product_id
			 WHERE it.invoice_id = %d
			 ORDER BY it.id ASC",
				$invoice_id
			),
			ARRAY_A
		);
		
		if ( $rows === NULL ) {
			return [
				'items' => [],
				'error' => 'خطا در دریافت آیتم‌های فاکتور: ' . $this->db->last_error,
			];
		}
		
		$items = [];
		foreach ( $rows as $r ) {
			$items[] = [
				'id'                => (int) $r['id'],
				'invoice_id'        => (int) $r['invoice_id'],
				'raw_product_id'    => (int) $r['raw_product_id'],
				'raw_product_title' => isset( $r['raw_product_title'] ) ? (string) $r['raw_product_title'] : '',
				'raw_product_code'  => isset( $r['raw_product_code'] ) ? (string) $r['raw_product_code'] : '',
				'qty_weight'        => (float) $r['qty_weight'],
				'unit_price'        => (float) $r['unit_price'],
				'line_total'        => (float) $r['line_total'],
				'note'              => isset( $r['note'] ) ? ( $r['note'] !== NULL ? (string) $r['note'] : NULL ) : NULL,
				'created_at'        => (string) $r['created_at'],
			];
		}
		
		return [
			'items' => $items,
		];
	}
	
	public function get_invoice_data( int $invoice_id ): array {
		$invoice_id = (int) $invoice_id;
		if ( $invoice_id <= 0 ) {
			return [
				'invoice' => NULL,
				'items'   => [],
				'error'   => 'شناسه فاکتور معتبر نیست.',
			];
		}
		
		$invoice = $this->db->get_row(
			$this->db->prepare(
				"SELECT *
			 FROM {$this->supplier_invoices}
			 WHERE id = %d
			 LIMIT 1",
				$invoice_id
			),
			ARRAY_A
		);
		
		if ( empty( $invoice ) ) {
			return [
				'invoice' => NULL,
				'items'   => [],
				'error'   => 'فاکتور پیدا نشد.',
			];
		}
		
		$items_res = $this->get_supplier_invoice_items( $invoice_id );
		if ( isset( $items_res['error'] ) ) {
			return [
				'invoice' => NULL,
				'items'   => [],
				'error'   => (string) $items_res['error'],
			];
		}
		
		return [
			'invoice' => [
				'id'               => (int) $invoice['id'],
				'supplier_user_id' => (int) $invoice['supplier_user_id'],
				'invoice_no'       => isset( $invoice['invoice_no'] ) ? ( $invoice['invoice_no'] !== NULL ? (string) $invoice['invoice_no'] : NULL ) : NULL,
				'status'           => (string) $invoice['status'],
				'issued_at'        => (string) $invoice['issued_at'],
				'confirmed_at'     => isset( $invoice['confirmed_at'] ) ? ( $invoice['confirmed_at'] !== NULL ? (string) $invoice['confirmed_at'] : NULL ) : NULL,
				'settled_at'       => isset( $invoice['settled_at'] ) ? ( $invoice['settled_at'] !== NULL ? (string) $invoice['settled_at'] : NULL ) : NULL,
				'total_amount'     => (float) $invoice['total_amount'],
				'note'             => isset( $invoice['note'] ) ? ( $invoice['note'] !== NULL ? (string) $invoice['note'] : NULL ) : NULL,
				'created_at'       => (string) $invoice['created_at'],
			],
			'items'   => (array) ( $items_res['items'] ?? [] ),
		];
	}
	
	public function get_supplier_invoice_settlement_remaining( int $invoice_id ): array {
		$invoice_id = (int) $invoice_id;
		if ( $invoice_id <= 0 ) {
			return $this->fail( 'شناسه فاکتور معتبر نیست.' );
		}
		
		$invoice = $this->db->get_row(
			$this->db->prepare(
				"SELECT id, supplier_user_id, total_amount, currency, status FROM {$this->supplier_invoices} WHERE id = %d LIMIT 1",
				$invoice_id
			),
			ARRAY_A
		);
		
		if ( empty( $invoice ) ) {
			return $this->fail( 'فاکتور پیدا نشد.' );
		}
		
        $supplier_id=(int)$invoice['supplier_user_id'];
		$total_amount  = (float) ( $invoice['total_amount'] ?? 0 );
		$currency      = (string) ( $invoice['currency'] ?? 'IRR' );
		$paid_payments = (float) $this->db->get_var(
			$this->db->prepare(
				"SELECT COALESCE(SUM(amount),0)
			 FROM {$this->payments}
			 WHERE ref_id = %d AND user_id = %d",
				$invoice_id, $supplier_id
			)
		);
		
		$paid_transfers = (float) $this->db->get_var(
			$this->db->prepare(
				"SELECT COALESCE(SUM(amount),0)
			 FROM {$this->transfers}
			 WHERE ref_id = %d AND user_id = %d",
				$invoice_id, $supplier_id
			)
		);
		
		$cheque_meta  = $this->resolve_meta_table( 'cheques' );
		$paid_cheques = (float) $this->db->get_var(
			$this->db->prepare(
				"SELECT COALESCE(SUM(c.amount),0)
				 FROM {$this->cheques} c
				 INNER JOIN {$cheque_meta[0]} cm ON cm.cheque_id = c.id
				 WHERE cm.meta_key = 'invoice_id'
				   AND cm.meta_value = %s
                   AND (c.user_id=%d OR c.current_holder_user_id=%d OR EXISTS (SELECT 1 FROM {$this->cheque_moves} relevant_move WHERE relevant_move.cheque_id=c.id AND relevant_move.holder_user_id=%d))",
				(string) $invoice_id, $supplier_id, $supplier_id, $supplier_id
			)
		);
		
		$paid_total = (float) ( $paid_payments + $paid_transfers + $paid_cheques );
		$effective_total=$invoice['status']==='canceled'?0:$total_amount;
		$remaining  = $invoice['status']==='canceled' ? 0.0 : (float) max( 0, $effective_total - $paid_total );
		$overpaid   = (float) max( 0, $paid_total - $effective_total );
		
		return $this->ok( 'اطلاعات تسویه فاکتور.', [
			'invoice_id'     => $invoice_id,
			'currency'       => $currency,
			'total_amount'   => $total_amount,
			'paid_payments'  => $paid_payments,
			'paid_transfers' => $paid_transfers,
			'paid_cheques'   => $paid_cheques,
			'paid_total'     => $paid_total,
			'remaining'      => $remaining,
			'overpaid'       => $overpaid,
		] );
	}
	
	private function apply_supplier_invoice_confirmed_to_stock( int $invoice_id, array $invoice, string $now ): array {
		$items = $this->db->get_results(
			$this->db->prepare(
				"SELECT * FROM {$this->supplier_invoice_items} WHERE invoice_id = %d ORDER BY id ASC",
				$invoice_id
			),
			ARRAY_A
		);
		
		if ( empty( $items ) ) {
			return $this->fail( 'برای این فاکتور آیتمی ثبت نشده است.' );
		}
		
		$created_batches = 0;
		$created_moves   = 0;
		$batch_ids       = [];
		$move_ids        = [];
		
		foreach ( $items as $item ) {
			$item_id        = (int) ( $item['id'] ?? 0 );
			$raw_product_id = (int) ( $item['raw_product_id'] ?? 0 );
			$qty_weight     = (float) ( $item['qty_weight'] ?? 0 );
			$unit_cost      = $this->get_invoice_item_meta( $item_id, 'per_unit_base', TRUE );
			
			if ( $item_id <= 0 || $raw_product_id <= 0 ) {
				return $this->fail( 'آیتم فاکتور نامعتبر است.' );
			}
			if ( $qty_weight <= 0 ) {
				return $this->fail( 'وزن آیتم باید بزرگ‌تر از صفر باشد.' );
			}
			if ( $unit_cost < 0 ) {
				return $this->fail( 'قیمت واحد آیتم نامعتبر است.' );
			}
			
			// --- batch (idempotent)
			$batch_id = (int) $this->db->get_var(
				$this->db->prepare(
					"SELECT id FROM {$this->batches}
				 WHERE source_type = 'supplier_invoice_item' AND source_id = %d
				 LIMIT 1",
					$item_id
				)
			);
			
			if ( $batch_id <= 0 ) {
				$ins = $this->db->insert(
					$this->batches,
					[
						'raw_product_id'     => $raw_product_id,
						'source_type'        => 'supplier_invoice_item',
						'source_id'          => $item_id,
						'initial_qty_weight' => $qty_weight,
						'unit_cost'          => $unit_cost,
						'created_at'         => $now,
						'updated_at'         => NULL,
					],
					[ '%d', '%s', '%d', '%f', '%f', '%s', '%s' ]
				);
				
				if ( $ins === FALSE ) {
					return $this->fail( 'خطا در ساخت بچ.', $this->db->last_error );
				}
				
				$batch_id = (int) $this->db->insert_id;
				$this->update_meta( 'batch', $batch_id, 'invoice_id', $invoice['id'] );
				$this->update_meta( 'batch', $batch_id, 'invoice_no', $invoice['invoice_no'] );
				$created_batches ++;
			}
			
			$batch_ids[] = $batch_id;
			
			// --- storage move (idempotent)
			$move_id = (int) $this->db->get_var(
				$this->db->prepare(
					"SELECT id FROM {$this->storage_moves}
				 WHERE batch_id = %d
				   AND direction = 'in'
				   AND reason = 'purchase_in'
				   AND ref_type = 'supplier_invoice'
				   AND ref_id = %d
				 LIMIT 1",
					$batch_id,
					$invoice_id
				)
			);
			
			if ( $move_id <= 0 ) {
				$note = sprintf(
					'ورود از فاکتور تامین‌کننده #%d%s (آیتم #%d)',
					$invoice_id,
					! empty( $invoice['invoice_no'] ) ? ' - ' . (string) $invoice['invoice_no'] : '',
					$item_id
				);
				
				$ins2 = $this->db->insert(
					$this->storage_moves,
					[
						'batch_id'          => $batch_id,
						'direction'         => 'in',
						'reason'            => 'purchase_in',
						'qty_weight'        => $qty_weight,
						'unit_cost_at_move' => $unit_cost,
						'ref_type'          => 'supplier_invoice',
						'ref_id'            => $invoice_id,
						'note'              => $note,
						'created_at'        => $now,
					],
					[ '%d', '%s', '%s', '%f', '%f', '%s', '%d', '%s', '%s' ]
				);
				
				if ( $ins2 === FALSE ) {
					return $this->fail( 'خطا در ثبت حرکت انبار.', $this->db->last_error );
				}
				
				$move_id = (int) $this->db->insert_id;
				$this->update_meta( 'storage_move', $move_id, 'invoice_id', $invoice['id'] );
				$this->update_meta( 'storage_move', $move_id, 'invoice_no', $invoice['invoice_no'] );
				$created_moves ++;
			}
			
			$move_ids[] = $move_id;
		}
		
		return $this->ok( 'ثبت ورود کالا به مخزن انجام شد.', [
			'invoice_id'       => $invoice_id,
			'created_batches'  => $created_batches,
			'created_moves'    => $created_moves,
			'batch_ids'        => array_values( array_unique( array_map( 'intval', $batch_ids ) ) ),
			'storage_move_ids' => array_values( array_unique( array_map( 'intval', $move_ids ) ) ),
		] );
	}
	
	public function get_batch_by_id( int $batch_id ): ?array {
		$batch_id = (int) $batch_id;
		
		if ( $batch_id <= 0 ) {
			return NULL;
		}
		
		$sql = "
		SELECT b.*
		FROM {$this->batches} b
		WHERE b.id = %d
		LIMIT 1
	";
		
		$row = $this->db->get_row(
			$this->db->prepare( $sql, $batch_id ),
			ARRAY_A
		);
		
		return $row ?: NULL;
	}
	
	public function get_batches_list( array $args = [] ): array {
		$args = wp_parse_args( $args, [
			'category_id'    => 0,
            'exclude_supplies' => false,
			'date_from'      => NULL,
			'date_to'        => NULL,
			'only_available' => TRUE,
			'page'           => 1,
			'per_page'       => 20,
			'orderby'        => 'id',
			'order'          => 'DESC',
		] );
		
		$page     = max( 1, (int) $args['page'] );
		$per_page = max( 1, min( 100, (int) $args['per_page'] ) );
		$offset   = ( $page - 1 ) * $per_page;
		
		$where  = 'WHERE 1=1';
        if($args['exclude_supplies']) {
            $ordinary=$this->ordinary_raw_condition('excluded_raw');
            $where.=" AND EXISTS (SELECT 1 FROM {$this->raw_products} excluded_raw WHERE excluded_raw.id=b.raw_product_id AND $ordinary)";
        }
		$params = [];
		
		// --------------------------------
		// Raw IDs by category
		// --------------------------------
		$raw_ids = [];
		
		if ( $args['category_id'] > 0 ) {
			$raw_ids = $this->db->get_col(
				$this->db->prepare(
					"SELECT id FROM {$this->raw_products} WHERE category_id = %d",
					(int) $args['category_id']
				)
			);
			
			if ( empty( $raw_ids ) ) {
				return [
					'ok'         => TRUE,
					'items'      => [],
					'summary'    => [],
					'total'      => 0,
					'page'       => $page,
					'per_page'   => $per_page,
					'pages'      => 0,
					'pagination' => [ 'total' => 0, 'total_page' => 0 ],
				];
			}
			
			$placeholders = implode( ',', array_fill( 0, count( $raw_ids ), '%d' ) );
			$where        .= " AND b.raw_product_id IN ($placeholders)";
			$params       = array_merge( $params, array_map( 'intval', $raw_ids ) );
		}
		
		// --------------------------------
		// Date filter
		// --------------------------------
		if ( ! is_null( $args['date_from'] ) && $args['date_from'] !== '' ) {
			$where    .= ' AND b.created_at >= %s';
			$params[] = $args['date_from'] . ' 00:00:00';
		}
		if ( ! is_null( $args['date_to'] ) && $args['date_to'] !== '' ) {
			$where    .= ' AND b.created_at <= %s';
			$params[] = $args['date_to'] . ' 23:59:59';
		}
		// --------------------------------
		// Only available
		// --------------------------------
		if ( $args['only_available'] ) {
			$where .= " AND (
			SELECT COALESCE(SUM(
				CASE
					WHEN direction = 'in'  THEN qty_weight
					WHEN direction = 'out' THEN -qty_weight
				END
			),0)
			FROM {$this->storage_moves}
			WHERE batch_id = b.id
		) > 0";
		}
		
		$sql_base = "FROM {$this->batches} as b {$where}";
		// --------------------------------
		// Count
		// --------------------------------
		$sql_count = "SELECT COUNT(*) {$sql_base}";
		$total     = (int) $this->db->get_var(
			$params ? $this->db->prepare( $sql_count, $params ) : $sql_count
		);
		
		// --------------------------------
		// Data list
		// --------------------------------
		$order = strtoupper( $args['order'] ) === 'ASC' ? 'ASC' : 'DESC';
		
		$sql_data = "
		SELECT
			b.*,
			(
				SELECT COALESCE(SUM(
					CASE
						WHEN direction = 'in'  THEN qty_weight
						WHEN direction = 'out' THEN -qty_weight
					END
				),0)
				FROM {$this->storage_moves}
				WHERE batch_id = b.id
			) as current_stock,
			(
				SELECT COALESCE(SUM(qty_weight),0)
				FROM {$this->storage_moves}
				WHERE batch_id = b.id
				AND reason = 'purchase_in'
			) as total_purchase_in,
			(
				SELECT COALESCE(SUM(qty_weight),0)
				FROM {$this->storage_moves}
				WHERE batch_id = b.id
				AND reason = 'waste'
			) as total_waste,
			(
				SELECT COALESCE(SUM(qty_weight),0)
				FROM {$this->storage_moves}
				WHERE batch_id = b.id
				AND reason = 'processing_out'
			) as total_processing_consume

		{$sql_base}
		ORDER BY b.created_at {$order}
		LIMIT %d OFFSET %d
	";
		
		$params_data = array_merge( $params, [ $per_page, $offset ] );
		$items       = $this->db->get_results(
			$this->db->prepare( $sql_data, $params_data ),
			ARRAY_A
		);
		// ==========================================
		// 🔥 SUMMARY (در سطح محصول خام)
		// ==========================================
		
		$summary = [];
		
		// Use the same batch filters as the list, across all pages.
		// Remaining stock includes every movement, including processing returns.
		$sql_summary = "
			SELECT
				b.raw_product_id,
				COALESCE(SUM(CASE WHEN sm.reason = 'purchase_in'
					THEN sm.qty_weight ELSE 0 END),0) AS total_received,
				COALESCE(SUM(CASE WHEN sm.reason = 'waste'
					THEN sm.qty_weight ELSE 0 END),0) AS total_wasted,
				COALESCE(SUM(CASE WHEN sm.reason = 'processing_out'
					THEN sm.qty_weight ELSE 0 END),0) AS total_processing_out,
				COALESCE(SUM(CASE
					WHEN sm.direction = 'in' THEN sm.qty_weight
					WHEN sm.direction = 'out' THEN -sm.qty_weight
					ELSE 0 END),0) AS total_remaining
			FROM {$this->batches} b
			LEFT JOIN {$this->storage_moves} sm ON sm.batch_id = b.id
			{$where}
			GROUP BY b.raw_product_id
		";
		$rows        = $this->db->get_results(
			$params ? $this->db->prepare( $sql_summary, $params ) : $sql_summary,
			ARRAY_A
		);
		
		foreach ( $rows as $row ) {
			$summary[ $row['raw_product_id'] ] = [
				'total_received'       => (float) $row['total_received'],
				'total_wasted'         => (float) $row['total_wasted'],
				'total_processing_out' => (float) $row['total_processing_out'],
				'total_remaining'      => (float) $row['total_remaining'],
			];
		}
		
		return [
			'ok'         => TRUE,
			'items'      => $items ?: [],
			'summary'    => $summary,
			'total'      => $total,
			'page'       => $page,
			'per_page'   => $per_page,
			'pages'      => $total ? ceil( $total / $per_page ) : 0,
			'pagination' => [
				'total'      => $total,
				'total_page' => $total ? (int) ceil( $total / $per_page ) : 0,
			],
		];
	}
	
	private function submit_storage_move_locked( array $data ): array {
		$data = wp_parse_args( $data, [
			'batch_id'          => 0,
			'direction'         => '', // in | out
			'reason'            => '', // purchase_in | processing_consume | waste | ...
			'qty_weight'        => 0,
			'unit_cost_at_move' => 0,
			'ref_type'          => NULL,
			'ref_id'            => NULL,
			'note'              => NULL,
			'meta'              => [],
			'created_at'        => current_time( 'mysql' ),
		] );
		
		$batch_id   = (int) $data['batch_id'];
		$direction  = sanitize_key( $data['direction'] );
		$reason     = sanitize_key( $data['reason'] );
		$qty_weight = (float) nooshika_sanitize_numbers( $data['qty_weight'] );
		
		if ( $batch_id <= 0 ) {
			return $this->fail( 'شناسه بچ نامعتبر است.' );
		}
		
		if ( ! in_array( $direction, [ 'in', 'out' ], TRUE ) ) {
			return $this->fail( 'جهت حرکت نامعتبر است.' );
		}
		
		if ( $qty_weight <= 0 ) {
			return $this->fail( 'مقدار وزن نامعتبر است.' );
		}
		
		$inserted = $this->db->insert(
			$this->storage_moves,
			[
				'batch_id'          => $batch_id,
				'direction'         => $direction,
				'reason'            => $reason,
				'qty_weight'        => $qty_weight,
				'unit_cost_at_move' => (float) $data['unit_cost_at_move'],
				'ref_type'          => $data['ref_type'],
				'ref_id'            => $data['ref_id'],
				'note'              => $data['note'],
				'created_at'        => $data['created_at'],
			],
			[
				'%d',
				'%s',
				'%s',
				'%f',
				'%f',
				'%s',
				'%d',
				'%s',
				'%s',
			]
		);
		
		if ( ! $inserted ) {
			return $this->fail( 'ثبت حرکت انبار ناموفق بود.' );
		}
		
		$move_id = (int) $this->db->insert_id;
		
		if ( ! empty( $data['meta'] ) && method_exists( $this, 'save_storage_move_meta_batch' ) ) {
			$res = $this->save_storage_move_meta_batch( $move_id, $data['meta'] );
			
			if ( ( $res['status'] ?? '' ) !== 'success' ) {
				return $this->fail( 'ذخیره متای حرکت انبار ناموفق بود.', $res );
			}
		}
		
		return $this->ok(
			'حرکت انبار با موفقیت ثبت شد.',
			[
				'move_id' => $move_id,
			]
		);
	}
	
	public function delete_storage_move( int $move_id ): array {
		if ( $move_id <= 0 ) {
			return $this->fail( 'شناسه حرکت نامعتبر است.' );
		}
		
		$move = $this->db->get_row(
			$this->db->prepare(
				"SELECT id,batch_id,ref_type,direction,qty_weight FROM {$this->storage_moves} WHERE id = %d",
				$move_id
			),
			ARRAY_A
		);
		
		if ( ! $move ) {
			return $this->fail( 'حرکت موردنظر یافت نشد.' );
		}
		
		$this->db->query( 'START TRANSACTION' );
        $this->db->get_row($this->db->prepare("SELECT id FROM {$this->batches} WHERE id=%d FOR UPDATE",$move['batch_id']),ARRAY_A);
		$previous_batch_qty = (float) $this->db->get_var( $this->db->prepare(
			"SELECT COALESCE(SUM(CASE WHEN direction='in' THEN qty_weight WHEN direction='out' THEN -qty_weight ELSE 0 END),0) FROM {$this->storage_moves} WHERE batch_id=%d",
			(int) $move['batch_id']
		) );
        $source_status=$this->db->get_var($this->db->prepare("SELECT s.status FROM {$this->supplier_invoices} s INNER JOIN {$this->supplier_invoice_items} i ON i.invoice_id=s.id INNER JOIN {$this->batches} b ON b.source_type='supplier_invoice_item' AND b.source_id=i.id WHERE b.id=%d",$move['batch_id']));
        if($this->db->last_error){$this->db->query('ROLLBACK');return $this->fail('خواندن وضعیت فاکتور ناموفق بود.');}
        if($source_status==='canceled'||in_array($move['ref_type'],['supplier_invoice','supplier_invoice_cancel'],TRUE)){
            $this->db->query('ROLLBACK');return $this->fail('سوابق ورود و ابطال فاکتور از این بخش حذف نمی‌شوند؛ از عملیات فاکتور استفاده کنید.');
        }
		// حذف متا
		if ( method_exists( $this, 'delete_storage_move_meta_batch' ) ) {
			$res = $this->delete_storage_move_meta_batch( $move_id );
			
			if ( ( $res['status'] ?? '' ) !== 'success' ) {
				$this->db->query( 'ROLLBACK' );
				
				return $this->fail( 'حذف متای حرکت انبار ناموفق بود.', $res );
			}
		}
		
		// حذف رکورد
		$deleted = $this->db->delete(
			$this->storage_moves,
			[ 'id' => $move_id ],
			[ '%d' ]
		);
		
		if ( ! $deleted ) {
			$this->db->query( 'ROLLBACK' );
			
			return $this->fail( 'حذف حرکت انبار ناموفق بود.' );
		}
		$move_delta = $move['direction'] === 'in' ? -(float)$move['qty_weight'] : (float)$move['qty_weight'];
		if ( ! $this->apply_warehouse_batch_delta( (int)$move['batch_id'], $previous_batch_qty, $move_delta ) ) {
			$this->db->query( 'ROLLBACK' );
			return $this->fail( 'تخصیص انبار پس از حذف گردش قابل همگام‌سازی نبود؛ حذف لغو شد.' );
		}
		
		$this->db->query( 'COMMIT' );
		
		return $this->ok(
			'حرکت انبار با موفقیت حذف شد.',
			[
				'move_id' => $move_id,
			]
		);
	}
	
	public function get_storage_moves_by_batch_id( int $batch_id ): array {
		$batch_id = (int) $batch_id;
		
		if ( $batch_id <= 0 ) {
			return [
				'batch' => [],
				'moves' => [],
			];
		}
		$batch_sql = "
		SELECT *
		FROM {$this->batches}
		WHERE id = %d
		LIMIT 1
	";
		
		$batch_data = $this->db->get_row(
			$this->db->prepare( $batch_sql, $batch_id ),
			ARRAY_A
		);
		
		if ( ! $batch_data ) {
			return [
				'batch' => [],
				'moves' => [],
			];
		}
		
		$sql = "
		SELECT *
		FROM {$this->storage_moves}
		WHERE batch_id = %d
		ORDER BY created_at DESC, id ASC
	";
		
		$items = $this->db->get_results(
			$this->db->prepare( $sql, $batch_id ),
			ARRAY_A
		);
		
		return [
			'batch' => $batch_data,
			'moves' => $items ?: [],
		];
	}
	
	public function get_batch_financial_snapshot( int $batch_id ): array {
		$row = $this->db->get_row(
			$this->db->prepare(
				"
			SELECT
				b.id,
				b.initial_qty_weight,
				b.unit_cost,

				(
					SELECT COALESCE(SUM(
						CASE
							WHEN direction = 'in'  THEN qty_weight
							WHEN direction = 'out' THEN -qty_weight
						END
					),0)
					FROM {$this->storage_moves}
					WHERE batch_id = b.id
				) as current_stock,

				(
					SELECT COALESCE(SUM(qty_weight),0)
					FROM {$this->storage_moves}
					WHERE batch_id = b.id
					AND reason = 'waste'
				) as total_waste

			FROM {$this->batches} b
			WHERE b.id = %d
			",
				$batch_id
			),
			ARRAY_A
		);
		
		if ( ! $row ) {
			return $this->fail( 'بچ موردنظر یافت نشد.' );
		}
		
		$initial_qty = (float) $row['initial_qty_weight'];
		$unit_cost   = (float) $row['unit_cost'];
		$current     = (float) $row['current_stock'];
		$total_waste = (float) $row['total_waste'];
		
		$total_amount = $initial_qty * $unit_cost;
		
		$net_weight = $initial_qty - $total_waste;
		
		if ( $net_weight <= 0 ) {
			return $this->fail( 'وزن خالص بچ صفر یا منفی است.' );
		}
		
		$real_unit_cost = $total_amount / $net_weight;
		
		return $this->ok(
			'اطلاعات بچ دریافت شد.',
			[
				'initial_qty'    => $initial_qty,
				'current_stock'  => $current,
				'total_waste'    => $total_waste,
				'net_weight'     => $net_weight,
				'real_unit_cost' => $real_unit_cost,
			]
		);
	}
	
	public function delete_processing_pack( $pack_id ): array {
		if ( ! $pack_id ) {
			return $this->fail( 'شناسع فرآوری ارسال نشده است.' );
		}
		$this->db->delete( $this->processing_packs, [ 'id' => $pack_id ] );
		$this->db->delete( $this->processing_pack_inputs, [ 'pack_id' => $pack_id ] );
		$this->db->delete( $this->storage_moves, [
			'ref_type' => 'processing_pack',
			'ref_id'   => $pack_id,
		] );
		
		return $this->ok(
			'بسته فرآوری با موفقیت حذف شد.',
			[
				'pack_id' => $pack_id,
			]
		);
	}
	
	public function create_processing_pack( array $data ): array {
		$data = wp_parse_args( $data, [
			'inputs'     => [],
			'meta'       => [],
			'created_at' => current_time( 'mysql' ),
		] );
		
		if ( empty( $data['inputs'] ) ) {
			return $this->fail( 'ورودی برای فرآوری ارسال نشده است.' );
		}
		
		$this->db->query( 'START TRANSACTION' );
        $batch_ids=array_values(array_unique(array_map(static fn($row)=>(int)($row['batch_id']??0),$data['inputs'])));sort($batch_ids,SORT_NUMERIC);
        foreach($batch_ids as $source_batch){
            if(!$this->db->get_row($this->db->prepare("SELECT id FROM {$this->batches} WHERE id=%d FOR UPDATE",$source_batch),ARRAY_A)){
                $this->db->query('ROLLBACK');return $this->fail('بچ ورودی موجود نیست.');
            }
        }

		
		$total_qty  = 0;
		$total_cost = 0;
		
		// 1️⃣ ایجاد pack
		$insert = $this->db->insert(
			$this->processing_packs,
			[
				'status'     => 'open',
				'created_at' => $data['created_at'],
			]
		);
		
		if ( ! $insert ) {
			$this->db->query( 'ROLLBACK' );
			
			return $this->fail( 'ایجاد بسته فرآوری ناموفق بود.' );
		}
		
		$pack_id = (int) $this->db->insert_id;
		
		// 2️⃣ متای pack
		if ( ! empty( $data['meta'] ) ) {
			$res = $this->save_meta_batch(
				'processing_pack',
				$pack_id,
				$data['meta']
			);
			
			if ( ( $res['status'] ?? '' ) !== 'success' ) {
				$this->db->query( 'ROLLBACK' );
				
				return $this->fail( 'ذخیره متای بسته فرآوری ناموفق بود.' );
			}
		}
		
		// 3️⃣ پردازش ورودی‌ها
		foreach ( $data['inputs'] as $row ) {
			$batch_id   = (int) ( $row['batch_id'] ?? 0 );
			$qty_weight = (float) ( $row['qty_weight'] ?? 0 );
			$meta       = isset( $row['meta'] ) && is_array( $row['meta'] ) ? $row['meta'] : [];
			
			if ( $batch_id <= 0 || $qty_weight <= 0 ) {
				$this->db->query( 'ROLLBACK' );
				
				return $this->fail( 'اطلاعات یکی از ورودی‌ها نامعتبر است.' );
			}
            $raw_id=(int)$this->db->get_var($this->db->prepare("SELECT raw_product_id FROM {$this->batches} WHERE id=%d",$batch_id));
            if($this->is_supply_raw_product($raw_id)){$this->db->query('ROLLBACK');return $this->fail('چاپ و قوطی فقط در ملزومات بسته‌بندی مدیریت می‌شوند.');}
			$snapshot = $this->get_batch_financial_snapshot( $batch_id );
			
			if ( $snapshot['status'] !== 'success' ) {
				$this->db->query( 'ROLLBACK' );
				
				return $this->fail( $snapshot['message'] );
			}
			
			$current_stock  = $snapshot['data']['current_stock'];
			$real_unit_cost = $snapshot['data']['real_unit_cost'];
			
			if ( $qty_weight > $current_stock ) {
				$this->db->query( 'ROLLBACK' );
				
				return $this->fail( 'موجودی بچ کافی نیست.' );
			}
			
			$unit_cost = $real_unit_cost;
			if ( $unit_cost <= 0 ) {
				$this->db->query( 'ROLLBACK' );
				
				return $this->fail( 'قیمت واحد بچ معتبر نیست.' );
			}
			
			$line_cost = $qty_weight * $unit_cost;
			
			// ثبت input
			$insert_input = $this->db->insert(
				$this->processing_pack_inputs,
				[
					'pack_id'    => $pack_id,
					'batch_id'   => $batch_id,
					'qty_weight' => $qty_weight,
					'unit_cost'  => $unit_cost,
					'line_cost'  => $line_cost,
					'created_at' => $data['created_at'],
				]
			);
			
			if ( ! $insert_input ) {
				$this->db->query( 'ROLLBACK' );
				
				return $this->fail( 'ثبت یکی از ورودی‌های فرآوری ناموفق بود.' );
			}
			
			$input_id = (int) $this->db->insert_id;
			
			// متای input
			if ( ! empty( $meta ) ) {
				$res = $this->save_meta_batch(
					'processing_pack_input',
					$input_id,
					$meta
				);
				
				if ( ( $res['status'] ?? '' ) !== 'success' ) {
					$this->db->query( 'ROLLBACK' );
					
					return $this->fail( 'ذخیره متای ورودی فرآوری ناموفق بود.' );
				}
			}
			
			// کم کردن از مخزن
			$move = $this->submit_storage_move( [
				'batch_id'          => $batch_id,
				'direction'         => 'out',
				'reason'            => 'processing_out',
				'qty_weight'        => $qty_weight,
				'unit_cost_at_move' => $unit_cost,
				'ref_type'          => 'processing_pack',
				'ref_id'            => $pack_id,
			], TRUE );
			
			if ( ( $move['status'] ?? '' ) !== 'success' ) {
				$this->db->query( 'ROLLBACK' );
				
				return $this->fail( 'کاهش موجودی مخزن ناموفق بود.', $move );
			}
			
			$total_qty  += $qty_weight;
			$total_cost += $line_cost;
		}
		
		if ( $total_qty <= 0 ) {
			$this->db->query( 'ROLLBACK' );
			
			return $this->fail( 'مجموع وزن ورودی معتبر نیست.' );
		}
		
		$avg_unit_cost = $total_cost / $total_qty;
		
		// آپدیت pack
		$update = $this->db->update(
			$this->processing_packs,
			[
				'total_qty_weight' => $total_qty,
				'total_cost'       => $total_cost,
				'avg_unit_cost'    => $avg_unit_cost,
				'updated_at'       => current_time( 'mysql' ),
			],
			[ 'id' => $pack_id ]
		);
		
		if ( FALSE === $update ) {
			$this->db->query( 'ROLLBACK' );
			
			return $this->fail( 'بروزرسانی اطلاعات بسته فرآوری ناموفق بود.' );
		}
		
		$this->db->query( 'COMMIT' );
		
		return $this->ok(
			'بسته فرآوری با موفقیت ایجاد شد.',
			[
				'pack_id'       => $pack_id,
				'total_qty'     => $total_qty,
				'total_cost'    => $total_cost,
				'avg_unit_cost' => $avg_unit_cost,
			]
		);
	}
	
	public function get_processing_packs_list( array $args = [] ): array {
		$args = wp_parse_args( $args, [
			'category_id' => 0,
            'production_mode' => 'standard',
			'status'      => 'open',
			'page'        => 1,
			'per_page'    => 20,
		] );
		
		$page     = max( 1, (int) $args['page'] );
		$per_page = max( 1, (int) $args['per_page'] );
		$offset   = ( $page - 1 ) * $per_page;
		
		$where  = "WHERE 1=1";
		$mode_table=$this->db_prefix.'processing_pack_meta';
        $bulk_exists="EXISTS (SELECT 1 FROM $mode_table mode_meta WHERE mode_meta.pack_id=p.id AND mode_meta.meta_key='production_mode' AND mode_meta.meta_value='bulk')";
        $where.=$args['production_mode']==='bulk' ? " AND $bulk_exists" : " AND NOT $bulk_exists";
        $joins  = '';
		$params = [];
		
		// فقط بازها
		if ( $args['status'] ) {
			$where    .= " AND p.status = %s";
			$params[] = $args['status'];
		}
		
		// فیلتر کتگوری از meta
		if ( (int) $args['category_id'] > 0 ) {
			[ $join, $meta_where, $meta_params ] = $this->build_meta_equals_filter(
				'processing_pack',
				'category_id',
				(string) $args['category_id'],
				'm_cat',
				'p.id'
			);
			
			if ( $join && $meta_where ) {
				$joins  .= " {$join} ";
				$where  .= " AND {$meta_where}";
				$params = array_merge( $params, $meta_params );
			}
		}
		
		// مجموع
		$total = (int) $this->db->get_var(
			$this->db->prepare(
				"SELECT COUNT(DISTINCT p.id)
			 FROM {$this->processing_packs} p
			 {$joins}
			 {$where}",
				$params
			)
		);
		
		// لیست
		$rows = $this->db->get_results(
			$this->db->prepare(
				"SELECT DISTINCT p.*
			 FROM {$this->processing_packs} p
			 {$joins}
			 {$where}
			 ORDER BY p.id DESC
			 LIMIT %d OFFSET %d",
				array_merge( $params, [ $per_page, $offset ] )
			),
			ARRAY_A
		);
		
		$total_page = (int) ceil( $total / $per_page );
		
		return [
			'items'      => $rows,
			'pagination' => [
				'page'       => $page,
				'per_page'   => $per_page,
				'total'      => $total,
				'total_page' => $total_page,
			],
		];
	}
	
	public function get_processing_pack_inputs( int $pack_id ): array {
		$pack_id = (int) $pack_id;
		
		if ( $pack_id <= 0 ) {
			return [];
		}
		
		$sql = "
		SELECT
			i.*
		FROM {$this->processing_pack_inputs} i
		WHERE i.pack_id = %d
		ORDER BY i.id ASC
	";
		
		$rows = $this->db->get_results(
			$this->db->prepare( $sql, $pack_id ),
			ARRAY_A
		);
		
		return $rows ?: [];
	}
	
	public function get_processing_pack_remaining_weight( int $pack_id, bool $strict = FALSE ): float {
		$pack_id = absint( $pack_id );
		
		if ( $pack_id <= 0 ) {
			return 0.0;
		}
		
		$total_input = (float) $this->db->get_var(
			$this->db->prepare(
				"SELECT COALESCE(SUM(qty_weight), 0)
			 FROM {$this->processing_pack_inputs}
			 WHERE pack_id = %d",
				$pack_id
			)
		);
        if ($strict && $this->db->last_error) throw new RuntimeException('خواندن وزن باقی‌مانده تولید فله ناموفق بود؛ دوباره تلاش کنید.');
		
		$total_sent_to_packaging = (float) $this->db->get_var(
			$this->db->prepare(
				"SELECT COALESCE(SUM(input_qty_weight), 0)
			 FROM {$this->packaging_lots}
			 WHERE processing_pack_id = %d",
				$pack_id
			)
		);
        if ($strict && $this->db->last_error) throw new RuntimeException('خواندن وزن باقی‌مانده تولید فله ناموفق بود؛ دوباره تلاش کنید.');
		
		$total_returned_from_packaging = (float) $this->db->get_var(
			$this->db->prepare(
				"SELECT COALESCE(SUM(m.qty_weight), 0)
			 FROM {$this->packaging_moves} m
			 INNER JOIN {$this->packaging_lots} l
				ON l.id = m.packaging_lot_id
			 WHERE l.processing_pack_id = %d
			   AND m.direction = 'out'
			   AND m.reason = 'return_to_processing'",
				$pack_id
			)
		);
        if ($strict && $this->db->last_error) throw new RuntimeException('خواندن وزن باقی‌مانده تولید فله ناموفق بود؛ دوباره تلاش کنید.');
		
		$total_returned_to_storage = (float) $this->db->get_var(
			$this->db->prepare(
				"SELECT COALESCE(SUM(qty_weight), 0)
			 FROM {$this->storage_moves}
			 WHERE direction = 'in'
			   AND reason = 'processing_return'
			   AND ref_type = 'processing_pack'
			   AND ref_id = %d",
				$pack_id
			)
		);
        if ($strict && $this->db->last_error) throw new RuntimeException('خواندن وزن باقی‌مانده تولید فله ناموفق بود؛ دوباره تلاش کنید.');
		
		$remaining = round(
			$total_input
			- $total_sent_to_packaging
			+ $total_returned_from_packaging
			- $total_returned_to_storage,
			6
		);
		
		return max( 0, $remaining );
	}
	
	public function return_processing_pack_to_storage( array $args ): array {
		$args = wp_parse_args( $args, [
			'pack_id'        => 0,
			'raw_product_id' => 0,
			'note'           => '',
			'created_at'     => current_time( 'mysql' ),
		] );
		
		$pack_id        = absint( $args['pack_id'] );
		$raw_product_id = absint( $args['raw_product_id'] );
		$note           = sanitize_textarea_field( $args['note'] );
		$created_at     = $args['created_at'];
		
		if ( $pack_id <= 0 ) {
			return $this->fail( 'شناسه بسته فرآوری نامعتبر است.' );
		}
		
        $bulk = $this->get_processing_pack_meta($pack_id, 'production_mode', true) === 'bulk';
        if ($bulk) {
            $category = (int)$this->get_processing_pack_meta($pack_id, 'category_id', true);
            $roles = [1=>'saff',2=>'zereshk',3=>'tea',4=>'hell',5=>'nabat',7=>'vanil'];
            if (!get_current_user_id() || (!kph_plugin_management_allowed() && (!isset($roles[$category]) || $roles[$category] !== nooshika_get_user_role(get_current_user_id())))) {
                return $this->fail('اجازه برگشت این بچ فله به مخزن را ندارید.');
            }
            foreach ([$this->processing_packs,$this->processing_pack_inputs,$this->packaging_lots,$this->packaging_moves,$this->batches,$this->storage_moves,$this->db_prefix.'batch_meta',$this->db_prefix.'processing_pack_meta',$this->warehouses_table,$this->warehouse_batch_stock_table] as $table) {
                $engine = $this->db->get_row($this->db->prepare('SHOW TABLE STATUS LIKE %s',$this->db->esc_like($table)),ARRAY_A);
                if (!$engine || strcasecmp((string)$engine['Engine'],'InnoDB')) return $this->fail('جدول‌های مخزن و تولید باید برای ثبت یکپارچه InnoDB باشند.');
            }
        }
        if (false === $this->db->query('START TRANSACTION')) return $this->fail('شروع ثبت برگشت ناموفق بود.');
		
		$pack = $this->db->get_row(
			$this->db->prepare(
				"SELECT id, status, avg_unit_cost
			 FROM {$this->processing_packs}
			 WHERE id = %d
			 LIMIT 1
			 FOR UPDATE",
				$pack_id
			),
			ARRAY_A
		);
		
		if ( ! $pack ) {
			$this->db->query( 'ROLLBACK' );
			
			return $this->fail( 'بسته فرآوری موردنظر یافت نشد.' );
		}
		
        try {
            $remaining_weight = $this->get_processing_pack_remaining_weight($pack_id, $bulk);
        } catch (RuntimeException $error) {
            $this->db->query('ROLLBACK');
            return $this->fail($error->getMessage());
        }
		
		if ( $remaining_weight <= 0 ) {
			$this->db->query( 'ROLLBACK' );
			
			return $this->fail(
				'موجودی قابل‌برگشتی در این بسته فرآوری وجود ندارد.'
			);
		}
		
		$unit_cost = (float) $pack['avg_unit_cost'];
		
		if ( $unit_cost <= 0 ) {
			$this->db->query( 'ROLLBACK' );
			
			return $this->fail(
				'بهای میانگین بسته فرآوری معتبر نیست.'
			);
		}
		
		/*
		 * اگر پک فقط یک نوع محصول خام داشته باشد،
		 * محصول خام به‌صورت خودکار تشخیص داده می‌شود.
		 */
		$pack_raw_product_ids = $this->get_raw_product_ids_by_processing_pack(
			$pack_id
		);

		
		if ( $raw_product_id <= 0 ) {
			if ( count( $pack_raw_product_ids ) === 1 ) {
				$raw_product_id = (int) reset(
					$pack_raw_product_ids
				);
			} else {
				$this->db->query( 'ROLLBACK' );
				
				return $this->fail(
					'این پک شامل چند محصول خام است؛ محصول مقصد مخزن را مشخص کنید.'
				);
			}
		}
		
        if ($bulk && (!in_array($raw_product_id,$pack_raw_product_ids,true) || $this->is_supply_raw_product($raw_product_id))) {
            $this->db->query('ROLLBACK');
            return $this->fail('محصول مقصد باید از مواد اولیه همین بچ فله باشد.');
        }
		$raw_product_exists = (int) $this->db->get_var(
			$this->db->prepare(
				"SELECT id
			 FROM {$this->raw_products}
			 WHERE id = %d
			 LIMIT 1",
				$raw_product_id
			)
		);
		
		if ( $raw_product_exists <= 0 ) {
			$this->db->query( 'ROLLBACK' );
			
			return $this->fail(
				'محصول خام انتخاب‌شده معتبر نیست.'
			);
		}
		
		/*
		 * ساخت بچ جدید برای کالای برگشتی از فرآوری
		 */
		$insert_batch = $this->db->insert(
			$this->batches,
			[
				'raw_product_id'     => $raw_product_id,
				'source_type'        => 'processing_return',
				'source_id'          => $pack_id,
				'initial_qty_weight' => $remaining_weight,
				'unit_cost'          => $unit_cost,
				'created_at'         => $created_at,
				'updated_at'         => NULL,
			],
			[
				'%d',
				'%s',
				'%d',
				'%f',
				'%f',
				'%s',
				'%s',
			]
		);
		
		if ( ! $insert_batch ) {
			$this->db->query( 'ROLLBACK' );
			
			return $this->fail(
				'ایجاد بچ برگشتی در مخزن ناموفق بود.'
			);
		}
		
		$batch_id = (int) $this->db->insert_id;
		
		$move = $this->submit_storage_move( [
			'batch_id'          => $batch_id,
			'direction'         => 'in',
			'reason'            => 'processing_return',
			'qty_weight'        => $remaining_weight,
			'unit_cost_at_move' => $unit_cost,
			'ref_type'          => 'processing_pack',
			'ref_id'            => $pack_id,
			'note'              => $note ?: sprintf(
				'بازگشت مانده بسته فرآوری شماره %d به مخزن',
				$pack_id
			),
			'created_at'        => $created_at,
		], TRUE );
		
		if ( ( $move['status'] ?? '' ) !== 'success' ) {
			$this->db->query( 'ROLLBACK' );
			
			return $this->fail(
				'ثبت ورود کالای برگشتی به مخزن ناموفق بود.',
				$move
			);
		}
		
		$return_meta = $this->update_meta(
			'batch',
			$batch_id,
			'processing_pack_id',
			$pack_id
		);
        if ($bulk && ($return_meta['status'] ?? '') !== 'success') {
            $this->db->query('ROLLBACK');
            return $this->fail('ثبت سابقه برگشت ناموفق بود.');
        }
		
		$return_meta = $this->update_meta(
			'batch',
			$batch_id,
			'return_type',
			'remaining_processing_stock'
		);
        if ($bulk && ($return_meta['status'] ?? '') !== 'success') {
            $this->db->query('ROLLBACK');
            return $this->fail('ثبت سابقه برگشت ناموفق بود.');
        }
		
		/*
		 * بعد از ثبت حرکت، مانده فرآوری صفر می‌شود.
		 * اگر چیزی در سالن باشد وضعیت transferred می‌ماند،
		 * در غیر این صورت پک بسته می‌شود.
		 */
		$this->recalculate_processing_pack_status( $pack_id );
		
        if ($bulk && $this->db->last_error) {
            $this->db->query('ROLLBACK');
            return $this->fail('ثبت وضعیت بچ فله ناموفق بود.');
        }
        if (false === $this->db->query('COMMIT')) {
            $this->db->query('ROLLBACK');
            return $this->fail('ثبت نهایی برگشت ناموفق بود.');
        }
		
		return $this->ok(
			'موجودی باقی‌مانده بسته فرآوری با موفقیت به مخزن برگشت داده شد.',
			[
				'pack_id'         => $pack_id,
				'batch_id'        => $batch_id,
				'storage_move_id' => (int) (
					$move['data']['move_id'] ?? 0
				),
				'raw_product_id'  => $raw_product_id,
				'returned_weight' => $remaining_weight,
				'unit_cost'       => $unit_cost,
				'returned_cost'   => $remaining_weight * $unit_cost,
			]
		);
	}
	
	public function get_raw_product_ids_by_processing_pack( int $pack_id ): array {
		$pack_id = (int) $pack_id;
		
		if ( $pack_id <= 0 ) {
			return [];
		}
		
		$sql = "
		SELECT DISTINCT b.raw_product_id
		FROM {$this->processing_pack_inputs} i
		INNER JOIN {$this->batches} b
			ON b.id = i.batch_id
		WHERE i.pack_id = %d
		AND b.raw_product_id IS NOT NULL
	";
		
		$rows = $this->db->get_col(
			$this->db->prepare( $sql, $pack_id )
		);
		
		return $rows ? array_map( 'intval', $rows ) : [];
	}
	
	public function get_processing_overview_stats( $category_id = 0 ): array {
		$joins  = '';
		$where = "WHERE NOT EXISTS (SELECT 1 FROM {$this->db_prefix}processing_pack_meta bulk_mode WHERE bulk_mode.pack_id=p.id AND bulk_mode.meta_key='production_mode' AND bulk_mode.meta_value='bulk')";
		$params = [];
		
		if ( $category_id > 0 ) {
			[ $join, $meta_where, $meta_params ] = $this->build_meta_equals_filter(
				'processing_pack',
				'category_id',
				(string) $category_id,
				'm_cat',
				'p.id'
			);
			
			if ( $join && $meta_where ) {
				$joins  = " {$join} ";
				$where .= " AND {$meta_where}";
				$params = $meta_params;
			}
		}
		
		// 1️⃣ کل وزن فرآوری شده
		$total_processed = (float) $this->db->get_var(
			$this->db->prepare(
				"SELECT COALESCE(SUM(i.qty_weight),0)
			 FROM {$this->processing_pack_inputs} i
			 INNER JOIN {$this->processing_packs} p
			 	ON p.id = i.pack_id
			 {$joins}
			 {$where}",
				$params
			)
		);
		
		// 2️⃣ مجموع ارسال به سالن
		$total_sent_to_packaging = (float) $this->db->get_var(
			$this->db->prepare(
				"SELECT COALESCE(SUM(l.input_qty_weight),0)
			 FROM {$this->packaging_lots} l
			 INNER JOIN {$this->processing_packs} p
			 	ON p.id = l.processing_pack_id
			 {$joins}
			 {$where}",
				$params
			)
		);
		
		// 3️⃣ مجموع برگشتی از سالن
		$total_returned = (float) $this->db->get_var(
			$this->db->prepare(
				"SELECT COALESCE(SUM(m.qty_weight),0)
			 FROM {$this->packaging_moves} m
			 INNER JOIN {$this->packaging_lots} l
			 	ON l.id = m.packaging_lot_id
			 INNER JOIN {$this->processing_packs} p
			 	ON p.id = l.processing_pack_id
			 {$joins}
			 {$where}
			 " . ( $where ? " AND " : " WHERE " ) . "m.reason = 'return_to_processing'",
				$params
			)
		);
		
		$net_sent_to_packaging = round(
			max( 0, $total_sent_to_packaging - $total_returned ),
			6
		);
		
		$current_in_processing = round(
			max( 0, $total_processed - $net_sent_to_packaging ),
			6
		);
		
		return [
			'total_processed'         => round( $total_processed, 6 ),
			'current_in_processing'   => $current_in_processing,
			'total_sent_to_packaging' => $net_sent_to_packaging,
		];
	}
	
	public function transfer_processing_pack_to_packaging( array $args ) {
		$args = wp_parse_args( $args, [
			'pack_id'    => 0,
			'qty_weight' => 0,
			'note'       => '',
		] );
		
		$pack_id    = (int) $args['pack_id'];
		$qty_weight = (float) $args['qty_weight'];
		
		if ( $pack_id <= 0 || $qty_weight <= 0 ) {
			return $this->fail( 'اطلاعات انتقال نامعتبر است.' );
		}
		
        if($this->get_processing_pack_meta($pack_id,'production_mode',true)==='bulk')return $this->fail('برای تولید فله از گزینه «تبدیل مستقیم به محصول» در همان صفحه استفاده کنید.');
		// بررسی موجودی
		$remaining = $this->get_processing_pack_remaining_weight( $pack_id );
		
		if ( $qty_weight > $remaining ) {
			return $this->fail( 'وزن انتقال بیشتر از موجودی باقی‌مانده است.' );
		}
		
		// دریافت avg_unit_cost
		$pack = $this->db->get_row(
			$this->db->prepare(
				"SELECT avg_unit_cost
			 FROM {$this->processing_packs}
			 WHERE id = %d",
				$pack_id
			),
			ARRAY_A
		);
		
		if ( ! $pack ) {
			return $this->fail( 'بسته فرآوری یافت نشد.' );
		}
		
		$this->db->query( 'START TRANSACTION' );
		
		// 1️⃣ ایجاد lot
		$insert_lot = $this->db->insert(
			$this->packaging_lots,
			[
				'processing_pack_id' => $pack_id,
				'input_qty_weight'   => $qty_weight,
				'avg_unit_cost'      => (float) $pack['avg_unit_cost'],
				'status'             => 'in_packaging',
				'created_at'         => current_time( 'mysql' ),
			],
			[ '%d', '%f', '%f', '%s', '%s' ]
		);
		
		if ( FALSE === $insert_lot ) {
			$this->db->query( 'ROLLBACK' );
			
			return $this->fail( 'ایجاد lot بسته‌بندی ناموفق بود.' );
		}
		
		$lot_id = (int) $this->db->insert_id;
		
		// 2️⃣ ثبت move
		$insert_move = $this->db->insert(
			$this->packaging_moves,
			[
				'packaging_lot_id' => $lot_id,
				'direction'        => 'in',
				'reason'           => 'from_processing',
				'qty_weight'       => $qty_weight,
				'note'             => $args['note'],
				'created_at'       => current_time( 'mysql' ),
			],
			[ '%d', '%s', '%s', '%f', '%s', '%s' ]
		);
		
		if ( FALSE === $insert_move ) {
			$this->db->query( 'ROLLBACK' );
			
			return $this->fail( 'ثبت گردش بسته‌بندی ناموفق بود.' );
		}
		
		// 3️⃣ اگر موجودی صفر شد → تغییر وضعیت
		if ( $remaining - $qty_weight <= 0 ) {
			$update = $this->db->update(
				$this->processing_packs,
				[
					'status'     => 'transferred_to_packaging',
					'updated_at' => current_time( 'mysql' ),
				],
				[ 'id' => $pack_id ],
				[ '%s', '%s' ],
				[ '%d' ]
			);
			
			if ( FALSE === $update ) {
				$this->db->query( 'ROLLBACK' );
				
				return $this->fail( 'بروزرسانی وضعیت بسته فرآوری ناموفق بود.' );
			}
		}
		
		$this->db->query( 'COMMIT' );
		
		return $this->ok(
			'انتقال به سالن با موفقیت انجام شد.',
			[
				'pack_id'    => $pack_id,
				'lot_id'     => $lot_id,
				'qty_weight' => $qty_weight,
			]
		);
	}
	
	public function get_processing_packaging_transfers( array $args = [] ): array {
		$args = wp_parse_args( $args, [
			'processing_pack_id' => 0,
			'packaging_lot_id'   => 0,
			'page'               => 1,
			'per_page'           => 20,
		] );
		
		$page     = max( 1, (int) $args['page'] );
		$per_page = max( 1, (int) $args['per_page'] );
		$offset   = ( $page - 1 ) * $per_page;
		
		$where = "WHERE NOT EXISTS (SELECT 1 FROM {$this->db_prefix}packaging_lot_meta direct_trace WHERE direct_trace.lot_id=l.id AND direct_trace.meta_key='direct_bulk' AND direct_trace.meta_value='1')";
		$params = [];
		
		if ( $args['processing_pack_id'] > 0 ) {
			$where    .= " AND l.processing_pack_id = %d";
			$params[] = $args['processing_pack_id'];
		}
		
		if ( $args['packaging_lot_id'] > 0 ) {
			$where    .= " AND m.packaging_lot_id = %d";
			$params[] = $args['packaging_lot_id'];
		}
		
		// فقط مووهای انتقال (رفت و برگشت)
		$where .= " AND (
		m.reason = 'from_processing'
		OR m.reason = 'return_to_processing'
	)";
		
		// مجموع کل
		$total = (int) $this->db->get_var(
			$this->db->prepare(
				"SELECT COUNT(*)
			 FROM {$this->packaging_moves} m
			 INNER JOIN {$this->packaging_lots} l
			 	ON l.id = m.packaging_lot_id
			 {$where}",
				$params
			)
		);
		
		$sql = "
		SELECT
			m.id,
			m.packaging_lot_id,
			l.processing_pack_id,
			m.direction,
			m.reason,
			m.qty_weight,
			m.ref_type,
			m.ref_id,
			m.note,
			m.created_at

		FROM {$this->packaging_moves} m
		INNER JOIN {$this->packaging_lots} l
			ON l.id = m.packaging_lot_id

		{$where}

		ORDER BY m.id DESC
		LIMIT %d OFFSET %d
	";
		
		$rows = $this->db->get_results(
			$this->db->prepare(
				$sql,
				array_merge( $params, [ $per_page, $offset ] )
			),
			ARRAY_A
		);
		
		$total_page = (int) ceil( $total / $per_page );
		
		return [
			'items'      => $rows ?: [],
			'pagination' => [
				'page'       => $page,
				'per_page'   => $per_page,
				'total'      => $total,
				'total_page' => $total_page,
			],
		];
	}
	
	public function get_packaging_lots_in_packaging( array $args = [] ): array {
		$args = wp_parse_args( $args, [
			'category_id' => 0,
			'page'        => 1,
			'per_page'    => 20,
			'status'      => 'in_packaging',
		] );
		
		$page     = max( 1, (int) $args['page'] );
		$per_page = max( 1, (int) $args['per_page'] );
		$offset   = ( $page - 1 ) * $per_page;
		
		$where  = "WHERE l.status = '{$args['status']}'";
		$where.=" AND NOT EXISTS (SELECT 1 FROM {$this->db_prefix}packaging_lot_meta direct_trace WHERE direct_trace.lot_id=l.id AND direct_trace.meta_key='direct_bulk' AND direct_trace.meta_value='1')";
        $joins  = '';
		$params = [];
		
		// فیلتر کتگوری از meta پک
		if ( $args['category_id'] > 0 ) {
			[ $join, $meta_where, $meta_params ] = $this->build_meta_equals_filter(
				'processing_pack',
				'category_id',
				(string) $args['category_id'],
				'm_cat',
				'l.processing_pack_id'
			);
			
			if ( $join && $meta_where ) {
				$joins  .= " {$join} ";
				$where  .= " AND {$meta_where}";
				$params = array_merge( $params, $meta_params );
			}
		}
		
		// تعداد کل
		$total = (int) $this->db->get_var(
			$this->db->prepare(
				"SELECT COUNT(DISTINCT l.id)
			 FROM {$this->packaging_lots} l
			 {$joins}
			 {$where}",
				$params
			)
		);
		
		// لیست
		$sql = "
		SELECT
			l.*,
			COALESCE(SUM(
				CASE
				  WHEN m.direction = 'in' THEN m.qty_weight
				  WHEN m.direction = 'out' THEN -m.qty_weight
				END
			),0) AS remaining_weight,
	       COALESCE(SUM(
				CASE
				  WHEN m.reason IN ('waste','convert_to_shop_product','return_to_processing')
				  THEN m.qty_weight
				  ELSE 0
				END
			),0) AS total_consumed,
	       COALESCE(SUM(
				CASE
				  WHEN m.reason IN ('waste')
				  THEN m.qty_weight
				  ELSE 0
				END
			),0) AS total_waste

		FROM {$this->packaging_lots} l
		LEFT JOIN {$this->packaging_moves} m
			ON m.packaging_lot_id = l.id

		{$joins}
		{$where}

		GROUP BY l.id
		ORDER BY l.id DESC
		LIMIT %d OFFSET %d
	";
		
		$rows       = $this->db->get_results(
			$this->db->prepare(
				$sql,
				array_merge( $params, [ $per_page, $offset ] )
			),
			ARRAY_A
		);
		$total_page = (int) ceil( $total / $per_page );
		
		return [
			'items'      => $rows ?: [],
			'pagination' => [
				'page'       => $page,
				'per_page'   => $per_page,
				'total'      => $total,
				'total_page' => $total_page,
			],
		];
	}
	
	public function get_packaging_lot_remaining_weight( int $lot_id ): float {
		$lot_id = (int) $lot_id;
		
		if ( $lot_id <= 0 ) {
			return 0.0;
		}
		
		// مجموع ورود و خروج
		$balance = (float) $this->db->get_var(
			$this->db->prepare(
				"SELECT COALESCE(SUM(
				CASE
					WHEN m.direction = 'in'  THEN m.qty_weight
					WHEN m.direction = 'out' THEN -m.qty_weight
				END
			),0)
			FROM {$this->packaging_moves} m
			WHERE m.packaging_lot_id = %d",
				$lot_id
			)
		);
		
		return round( max( 0, $balance ), 6 );
	}
	
    /** Serialize salon withdrawals with conversions and physical measurements. */
    private function lock_open_lot_for_withdrawal(int $lot_id): array {
        if (false === $this->db->query('START TRANSACTION')) return $this->fail('شروع ثبت گردش سالن انجام نشد.');
        $pack = $this->db->get_var($this->db->prepare(
            "SELECT processing_pack_id FROM {$this->packaging_lots} WHERE id=%d AND status='in_packaging' FOR UPDATE", $lot_id
        ));
        if (!$pack) {
            $this->db->query('ROLLBACK');
            return $this->fail('ردیف باز سالن یافت نشد.');
        }
        return $this->ok('', ['pack_id'=>(int)$pack]);
    }

	public function return_packaging_lot_to_processing( array $args ) {
		$args = wp_parse_args( $args, [
			'lot_id'     => 0,
			'qty_weight' => 0,
			'note'       => '',
		] );
		
		$lot_id     = (int) $args['lot_id'];
		$qty_weight = (float) $args['qty_weight'];
		
		if ( $lot_id <= 0 || $qty_weight <= 0 ) {
			return $this->fail( 'اطلاعات بازگشت نامعتبر است.' );
		}
		
		// بررسی موجودی باقی‌مانده lot
		$locked = $this->lock_open_lot_for_withdrawal($lot_id);
        if ($locked['status'] !== 'success') return $locked;
        $pack_id = (int)$locked['data']['pack_id'];
        $remaining = $this->get_packaging_lot_remaining_weight($lot_id);
        if ($this->db->last_error || $qty_weight > $remaining) {
            $this->db->query('ROLLBACK');
            return $this->fail('وزن بازگشتی بیشتر از موجودی سالن است.');
        }

        $insert = $this->db->insert(
			$this->packaging_moves,
			[
				'packaging_lot_id' => $lot_id,
				'direction'        => 'out',
				'reason'           => 'return_to_processing',
				'qty_weight'       => $qty_weight,
				'note'             => $args['note'],
				'created_at'       => current_time( 'mysql' ),
			],
			[ '%d', '%s', '%s', '%f', '%s', '%s' ]
		);
		
		if ( FALSE === $insert ) {
			$this->db->query( 'ROLLBACK' );
			
			return $this->fail( 'ثبت بازگشت ناموفق بود.' );
		}
		
		// اگر lot خالی شد → بسته شود
		$new_remaining = $remaining - $qty_weight;
		
		if ( $new_remaining <= 0 ) {
			$update = $this->db->update(
				$this->packaging_lots,
				[
					'status'     => 'closed',
					'updated_at' => current_time( 'mysql' ),
				],
				[ 'id' => $lot_id ],
				[ '%s', '%s' ],
				[ '%d' ]
			);
			
			if ( FALSE === $update ) {
				$this->db->query( 'ROLLBACK' );
				
				return $this->fail( 'بروزرسانی وضعیت lot ناموفق بود.' );
			}
		}
		$this->recalculate_processing_pack_status( $pack_id );
		
		$this->db->query( 'COMMIT' );
		
		return $this->ok(
			'بازگشت به فرآوری با موفقیت ثبت شد.',
			[
				'lot_id'     => $lot_id,
				'qty_weight' => $qty_weight,
			]
		);
	}
	
	public function recalculate_processing_pack_status( int $pack_id ): void {
		$remaining_processing   = $this->get_processing_pack_remaining_weight( $pack_id );
		$remaining_in_packaging = $this->get_processing_pack_total_remaining_in_packaging( $pack_id );
		if ( $remaining_processing > 0 ) {
			$status = 'open';
		} elseif ( $remaining_in_packaging > 0 ) {
			$status = 'transferred_to_packaging';
		} else {
			$status = 'closed';
		}
		
		$this->db->update(
			$this->processing_packs,
			[
				'status'     => $status,
				'updated_at' => current_time( 'mysql' ),
			],
			[ 'id' => $pack_id ],
			[ '%s', '%s' ],
			[ '%d' ]
		);
	}
	
	public function get_processing_pack_total_remaining_in_packaging( int $pack_id ): float {
		$pack_id = (int) $pack_id;
		
		if ( $pack_id <= 0 ) {
			return 0.0;
		}
		
		$balance = (float) $this->db->get_var(
			$this->db->prepare(
				"SELECT COALESCE(SUM(
				CASE
					WHEN m.direction = 'in'  THEN m.qty_weight
					WHEN m.direction = 'out' THEN -m.qty_weight
				END
			),0)
			FROM {$this->packaging_moves} m
			INNER JOIN {$this->packaging_lots} l
				ON l.id = m.packaging_lot_id
			WHERE l.processing_pack_id = %d",
				$pack_id
			)
		);
		
		return round( max( 0, $balance ), 6 );
	}
	
    public function record_lot_measurement(int $lot_id, string $expected, string $measured): array {
        if (!kph_plugin_management_allowed() || !$this->workflow_storage_ready('production')) {
            return $this->fail('برای ثبت وزن واقعی، دسترسی مدیریت تولید و آماده‌سازی جدول‌ها لازم است.');
        }
        foreach ([$expected, $measured] as $grams) {
            if (!preg_match('/^[0-9]{1,12}(?:\.[0-9]{1,3})?$/D', $grams)) return $this->fail('وزن را به گرم با حداکثر سه رقم اعشار وارد کنید.');
        }
        if (bccomp($measured, '0', 3) <= 0) return $this->fail('وزن واقعی باید مثبت باشد.');
        if (false === $this->db->query('START TRANSACTION')) return $this->fail('شروع ثبت وزن انجام نشد.');
        try {
            $lot = $this->db->get_row($this->db->prepare("SELECT status FROM {$this->packaging_lots} WHERE id=%d FOR UPDATE", $lot_id), ARRAY_A);
            if (!$lot || $lot['status'] !== 'in_packaging') throw new RuntimeException('ردیف باز سالن یافت نشد.');
            $current = kph_product_weight::recorded_grams($this->get_packaging_lot_remaining_weight($lot_id));
            if ($this->db->last_error || bccomp($current,$expected,3) !== 0) throw new RuntimeException('ماندهٔ ردیف تغییر کرده است. فهرست را تازه کنید.');
            $difference = bcsub($measured,$current,3);
            $sign = bccomp($difference,'0',3);
            if ($sign !== 0 && !$this->db->insert($this->packaging_moves, [
                'packaging_lot_id'=>$lot_id, 'direction'=>$sign > 0 ? 'in' : 'out', 'reason'=>'adjustment',
                'qty_weight'=>bcdiv(ltrim($difference,'-'),'1000',6), 'ref_type'=>'measurement_by_user',
                'ref_id'=>get_current_user_id(), 'created_at'=>current_time('mysql'),
                'note'=>'وزن‌کشی سالن از '.$current.' به '.$measured.' گرم؛ کاربر '.get_current_user_id(),
            ])) throw new RuntimeException('ثبت گردش اصلاح وزن انجام نشد.');
            if (false === $this->db->query('COMMIT')) throw new RuntimeException('ثبت نهایی وزن انجام نشد.');
            return $this->ok('ماندهٔ توزین‌شده در سالن ثبت شد.');
        } catch (Throwable $e) {
            $this->db->query('ROLLBACK');
            return $this->fail($e->getMessage());
        }
    }

	public function register_packaging_waste( array $args ) {
		$args = wp_parse_args( $args, [
			'lot_id'     => 0,
			'qty_weight' => 0,
			'note'       => '',
		] );
		
		$lot_id     = (int) $args['lot_id'];
		$qty_weight = (float) $args['qty_weight'];
		
		if ( $lot_id <= 0 || $qty_weight <= 0 ) {
			return $this->fail( 'اطلاعات ثبت ضایعات نامعتبر است.' );
		}
		
		$locked = $this->lock_open_lot_for_withdrawal($lot_id);
        if ($locked['status'] !== 'success') return $locked;
        $pack_id = (int)$locked['data']['pack_id'];
        $remaining = $this->get_packaging_lot_remaining_weight($lot_id);
        if ($this->db->last_error || $qty_weight > $remaining) {
            $this->db->query('ROLLBACK');
            return $this->fail('وزن ضایعات بیشتر از موجودی سالن است.');
        }

        $insert = $this->db->insert(
			$this->packaging_moves,
			[
				'packaging_lot_id' => $lot_id,
				'direction'        => 'out',
				'reason'           => 'waste',
				'qty_weight'       => $qty_weight,
				'note'             => $args['note'],
				'created_at'       => current_time( 'mysql' ),
			],
			[ '%d', '%s', '%s', '%f', '%s', '%s' ]
		);
		
		if ( FALSE === $insert ) {
			$this->db->query( 'ROLLBACK' );
			
			return $this->fail( 'ثبت ضایعات ناموفق بود.' );
		}
		
		$new_remaining = $remaining - $qty_weight;
		
		if ( $new_remaining <= 0 ) {
			$update = $this->db->update(
				$this->packaging_lots,
				[
					'status'     => 'closed',
					'updated_at' => current_time( 'mysql' ),
				],
				[ 'id' => $lot_id ],
				[ '%s', '%s' ],
				[ '%d' ]
			);
			
			if ( FALSE === $update ) {
				$this->db->query( 'ROLLBACK' );
				
				return $this->fail( 'بروزرسانی وضعیت lot ناموفق بود.' );
			}
		}
		$this->recalculate_processing_pack_status( $pack_id );
		
		$this->db->query( 'COMMIT' );
		
		return $this->ok(
			'ضایعات با موفقیت ثبت شد.',
			[
				'lot_id'     => $lot_id,
				'qty_weight' => $qty_weight,
			]
		);
	}
	
	public function remove_packaging_waste( int $move_id ): array {
		if ( $move_id <= 0 ) {
			return $this->fail( 'شناسه حرکت نامعتبر است.' );
		}
		
		$move = $this->db->get_row(
			$this->db->prepare(
				"SELECT packaging_lot_id, qty_weight, reason
			 FROM {$this->packaging_moves}
			 WHERE id = %d",
				$move_id
			),
			ARRAY_A
		);
		
		if ( ! $move ) {
			return $this->fail( 'رکورد ضایعات یافت نشد.' );
		}
		
		if ( $move['reason'] !== 'waste' ) {
			return $this->fail( 'این حرکت از نوع ضایعات نیست.' );
		}
		
		$lot_id     = (int) $move['packaging_lot_id'];
		$qty_weight = (float) $move['qty_weight'];
		
		$pack_id = (int) $this->db->get_var(
			$this->db->prepare(
				"SELECT processing_pack_id
			 FROM {$this->packaging_lots}
			 WHERE id = %d",
				$lot_id
			)
		);
		
		if ( $pack_id <= 0 ) {
			return $this->fail( 'بسته فرآوری مرتبط یافت نشد.' );
		}
		
		$this->db->query( 'START TRANSACTION' );
		
		// حذف رکورد
		$deleted = $this->db->delete(
			$this->packaging_moves,
			[ 'id' => $move_id ],
			[ '%d' ]
		);
		
		if ( FALSE === $deleted ) {
			$this->db->query( 'ROLLBACK' );
			
			return $this->fail( 'حذف ضایعات ناموفق بود.' );
		}
		
		// اگر lot قبلاً بسته شده بوده، ممکنه نیاز به باز شدن داشته باشه
		$remaining = $this->get_packaging_lot_remaining_weight( $lot_id );
		
		if ( $remaining > 0 ) {
			$update = $this->db->update(
				$this->packaging_lots,
				[
					'status'     => 'in_packaging',
					'updated_at' => current_time( 'mysql' ),
				],
				[ 'id' => $lot_id ],
				[ '%s', '%s' ],
				[ '%d' ]
			);
			
			if ( FALSE === $update ) {
				$this->db->query( 'ROLLBACK' );
				
				return $this->fail( 'بروزرسانی وضعیت lot ناموفق بود.' );
			}
		}
		
		$this->recalculate_processing_pack_status( $pack_id );
		
		$this->db->query( 'COMMIT' );
		
		return $this->ok(
			'ضایعات با موفقیت حذف شد.',
			[
				'move_id' => $move_id,
				'lot_id'  => $lot_id,
			]
		);
	}
	
	public function get_lot_moves( array $args = [] ): array {
		$args = wp_parse_args( $args, [
			'lot_id'   => 0,
			'page'     => 1,
			'per_page' => 20,
		] );
		
		$lot_id   = (int) $args['lot_id'];
		$page     = max( 1, (int) $args['page'] );
		$per_page = max( 1, (int) $args['per_page'] );
		$offset   = ( $page - 1 ) * $per_page;
		
		if ( $lot_id <= 0 ) {
			return [
				'items'      => [],
				'pagination' => [
					'page'       => $page,
					'per_page'   => $per_page,
					'total'      => 0,
					'total_page' => 0,
				],
			];
		}
		
		// مجموع کل
		$total = (int) $this->db->get_var(
			$this->db->prepare(
				"SELECT COUNT(*)
			 FROM {$this->packaging_moves}
			 WHERE packaging_lot_id = %d",
				$lot_id
			)
		);
		
		// لیست
		$rows = $this->db->get_results(
			$this->db->prepare(
				"SELECT m.*, sc.wc_product_id, sc.unique_product_code, sc.qty_items, sc.weight_per_item, p.post_title AS product_title
			 FROM {$this->packaging_moves} m
			 LEFT JOIN {$this->shop_conversions} sc ON m.ref_type = 'shop_conversion' AND m.ref_id = sc.id
			 LEFT JOIN {$this->db->posts} p ON p.ID = sc.wc_product_id
			 WHERE m.packaging_lot_id = %d
			 ORDER BY m.id DESC
			 LIMIT %d OFFSET %d",
				$lot_id,
				$per_page,
				$offset
			),
			ARRAY_A
		);
		
		$total_page = (int) ceil( $total / $per_page );
		
		return [
			'items'      => $rows ?: [],
			'pagination' => [
				'page'       => $page,
				'per_page'   => $per_page,
				'total'      => $total,
				'total_page' => $total_page,
			],
		];
	}
	
    /** Direct bulk conversion: material provenance and stock receipt commit together. */
    public function convert_bulk_pack_to_shop_product(array $args): array {
        $pack_id=absint($args['pack_id']??0);
        $qty=(int)($args['qty_items']??0);$weight=(float)($args['weight_per_item']??0);
        $total=round($qty*$weight,6);
        if($pack_id<=0||$qty<=0||$weight<=0||!is_finite($total)||$total<=0)return $this->fail('وزن و محصول تولید فله معتبر نیست.');
        if (!$this->workflow_storage_ready('production')) return $this->fail('مدیر از ابزارهای کاسبی «آماده‌سازی تولید، پیش‌فاکتور و چک» را اجرا کند.');
        if(false===$this->db->query('START TRANSACTION'))return $this->fail('شروع ثبت تولید ناموفق بود.');
        try{
            $pack=$this->db->get_row($this->db->prepare("SELECT * FROM {$this->processing_packs} WHERE id=%d FOR UPDATE",$pack_id),ARRAY_A);
            if(!$pack||$this->get_processing_pack_meta($pack_id,'production_mode',true)!=='bulk')throw new RuntimeException('بچ تولید فله پیدا نشد.');
            $role=nooshika_get_user_role(get_current_user_id());
            $category=(int)$this->get_processing_pack_meta($pack_id,'category_id',true);
            $roles=[1=>'saff',2=>'zereshk',3=>'tea',4=>'hell',5=>'nabat',7=>'vanil'];
            if(!get_current_user_id()||(!kph_plugin_management_allowed()&&($roles[$category]??'')!==$role))throw new RuntimeException('اجازه تولید در این گروه را ندارید.');
            $remaining=$this->get_processing_pack_remaining_weight($pack_id,true);
            if($total>$remaining+0.0000005)throw new RuntimeException('وزن مورد نیاز بیشتر از موجودی تولید فله است.');
            // A fully consumed trace lot preserves existing invoice/FIFO reports; it is never exposed as salon stock.
            $ok=$this->db->insert($this->packaging_lots,['processing_pack_id'=>$pack_id,'input_qty_weight'=>$total,'avg_unit_cost'=>$pack['avg_unit_cost'],'status'=>'in_packaging','created_at'=>current_time('mysql')]);
            if(!$ok)throw new RuntimeException('ثبت سابقه تولید فله انجام نشد.');
            $lot_id=(int)$this->db->insert_id;
            $meta=$this->update_meta('packaging_lot',$lot_id,'direct_bulk',1);
            if(($meta['status']??'')!=='success')throw new RuntimeException('ثبت سابقه تولید فله انجام نشد.');
            if(!$this->db->insert($this->packaging_moves,['packaging_lot_id'=>$lot_id,'direction'=>'in','reason'=>'from_processing','qty_weight'=>$total,'note'=>'تبدیل مستقیم تولید فله','created_at'=>current_time('mysql')]))throw new RuntimeException('ثبت مصرف تولید فله انجام نشد.');
            $args['lot_id']=$lot_id;
            $result=$this->convert_packaging_lot_locked($args,true);
            if(($result['status']??'')!=='success'){$this->db->query('ROLLBACK');return $result;}
            if(false===$this->db->query('COMMIT'))throw new RuntimeException('ثبت نهایی تولید فله انجام نشد.');
            $result['message']='تولید فله مستقیماً به محصول تبدیل و وارد انبار شد.';
            return $result;
        }catch(Throwable $e){$this->db->query('ROLLBACK');return $this->fail($e->getMessage());}
    }

    public function convert_packaging_lot_to_shop_product(array $args) {
        return $this->convert_packaging_lot_locked($args, false);
    }
    private function convert_packaging_lot_locked(array $args, bool $inside_transaction) {
		$args = wp_parse_args( $args, [
			'lot_id'                  => 0,
			'wc_product_id'           => 0,
			'qty_items'               => 0,
			'weight_per_item'         => 0,
			'packaging_cost_per_item' => 0,
			'unique_product_code'     => '',
		] );
		
		$lot_id      = (int) $args['lot_id'];
		$product_id  = (int) $args['wc_product_id'];
		$qty_items   = (int) $args['qty_items'];
		$weight_item = (float) $args['weight_per_item'];
		$pack_cost   = (float) $args['packaging_cost_per_item'];
		$code        = sanitize_text_field( $args['unique_product_code'] );
		
		if ( $lot_id <= 0 || $product_id <= 0 || $qty_items <= 0 || $weight_item <= 0 ) {
			return $this->fail( 'اطلاعات تبدیل نامعتبر است.' );
		}
		
		if ( ! $this->workflow_storage_ready( 'production' ) ) {
			return $this->fail( 'مدیر باید ابتدا از ابزارهای افزونه، ثبت یکپارچه را آماده کند.' );
		}
		$mapping = $this->get_production_code( absint( $args['production_code_id'] ?? 0 ) );
		if ( ! $mapping || (int) $mapping['wc_product_id'] !== $product_id || $mapping['code'] !== $code ) {
			return $this->fail( 'محصول و کد تولید مطابقت ندارند؛ از فهرست مشترک انتخاب کنید.' );
		}
		if ( $pack_cost < 0 || ! is_finite( $pack_cost ) || ! is_finite( $weight_item ) ) {
			return $this->fail( 'وزن یا هزینه بسته‌بندی نامعتبر است.' );
		}
		if ( ! $inside_transaction && FALSE === $this->db->query( 'START TRANSACTION' ) ) { return $this->fail( 'شروع تراکنش ناموفق بود.' ); }
		$locked_lot = $this->db->get_row( $this->db->prepare( "SELECT * FROM {$this->packaging_lots} WHERE id = %d FOR UPDATE", $lot_id ), ARRAY_A );
        if (!$locked_lot || $locked_lot['status'] !== 'in_packaging'
            || (!empty($args['source_pack_id']) && (int)$locked_lot['processing_pack_id'] !== (int)$args['source_pack_id'])) {
            $read_error = $this->db->last_error;
            $this->db->query('ROLLBACK');
            if ($read_error) return $this->fail('خواندن ردیف سالن انجام نشد. دوباره تلاش کنید.');
            if ($locked_lot && $locked_lot['status'] === 'closed') return $this->fail('این ردیف سالن بسته شده است. فهرست را تازه کنید.');
            return $this->fail('ردیف انتخابی با محموله مطابقت ندارد. فهرست را تازه و همان ردیف را انتخاب کنید.');
        }
        // Lock the code so simultaneous productions cannot race when creating inventory.
		$table = $this->production_codes_table();
		$locked_code = $this->db->get_row( $this->db->prepare( "SELECT id FROM {$table} WHERE id = %d FOR UPDATE", (int) $mapping['id'] ) );
		if ( ! $locked_code ) { $this->db->query( 'ROLLBACK' ); return $this->fail( 'کد تولید یافت نشد؛ دوباره انتخاب کنید.' ); }
		$existing_product = $this->db->get_var( $this->db->prepare( "SELECT wc_product_id FROM {$this->inventory_balance} WHERE unique_product_code = %s FOR UPDATE", $code ) );
		if ( $this->db->last_error ) { $this->db->query( 'ROLLBACK' ); return $this->fail( 'خواندن موجودی ناموفق بود.' ); }
		if ( $existing_product && (int) $existing_product !== $product_id ) {
			$this->db->query( 'ROLLBACK' );
			return $this->fail( 'کد تولید در موجودی به محصول دیگری متصل است.' );
		}
		$total_weight = round( $qty_items * $weight_item, 6 );
		$remaining = $this->get_packaging_lot_remaining_weight( $lot_id );
		
		if ( $total_weight > $remaining + 0.0000005 ) {
			$this->db->query( 'ROLLBACK' );
			return $this->fail( 'وزن مورد نیاز بیشتر از موجودی سالن است.' );
		}
		// گرفتن اطلاعات lot
		$lot = $this->db->get_row(
			$this->db->prepare(
				"SELECT processing_pack_id, avg_unit_cost,input_qty_weight
			 FROM {$this->packaging_lots}
			 WHERE id = %d",
				$lot_id
			),
			ARRAY_A
		);
		
		if ( ! $lot ) {
			$this->db->query( 'ROLLBACK' );
			return $this->fail( 'آیتم بسته‌بندی یافت نشد.' );
		}
		
		$avg_cost       = (float) $lot['avg_unit_cost'];
		$wastes         = (float) $this->db->get_var(
			$this->db->prepare(
				"SELECT COALESCE(SUM(m.qty_weight),0)
			FROM {$this->packaging_moves} m
			WHERE m.packaging_lot_id = %d AND reason = 'waste'",
				$lot_id
			)
		);
		$initial_weight = $lot['input_qty_weight'];
		$total_valid    = $initial_weight - $wastes;
		if ( $total_valid <= 0 ) {
			$this->db->query( 'ROLLBACK' );
			return $this->fail( 'وزن قابل تبدیل معتبر نیست.' );
		}
		$new_avg        = ( $avg_cost * $initial_weight ) / $total_valid;
		
		$total_material_cost  = round( $total_weight * $new_avg, 2 );
		$total_packaging_cost = round( $qty_items * $pack_cost, 2 );
		$total_cost           = round( $total_material_cost + $total_packaging_cost, 2 );
		$unit_cost_final      = round( $total_cost / $qty_items, 2 );
		
		$insert_conversion = $this->db->insert(
			$this->shop_conversions,
			[
				'packaging_lot_id'         => $lot_id,
				'wc_product_id'            => $product_id,
				'qty_items'                => $qty_items,
				'weight_per_item'          => $weight_item,
				'packaging_cost_per_item'  => $pack_cost,
				'unique_product_code'      => $code,
				'avg_cost_from_processing' => $avg_cost,
				'total_material_cost'      => $total_material_cost,
				'total_packaging_cost'     => $total_packaging_cost,
				'total_cost'               => $total_cost,
				'unit_cost_final'          => $unit_cost_final,
				'created_at'               => current_time( 'mysql' ),
			],
			[ '%d', '%d', '%d', '%f', '%f', '%s', '%f', '%f', '%f', '%f', '%f', '%s' ]
		);
		
		if ( FALSE === $insert_conversion ) {
			$this->db->query( 'ROLLBACK' );
			
			return $this->fail( 'ثبت تبدیل ناموفق بود.' );
		}
		
		$conversion_id = (int) $this->db->insert_id;
		
		// 2️⃣ ثبت move خروج
		$insert_move = $this->db->insert(
			$this->packaging_moves,
			[
				'packaging_lot_id' => $lot_id,
				'direction'        => 'out',
				'reason'           => 'convert_to_shop_product',
				'qty_weight'       => $total_weight,
				'ref_type'         => 'shop_conversion',
				'ref_id'           => $conversion_id,
				'created_at'       => current_time( 'mysql' ),
			],
			[ '%d', '%s', '%s', '%f', '%s', '%d', '%s' ]
		);
		
		if ( FALSE === $insert_move ) {
			$this->db->query( 'ROLLBACK' );
			
			return $this->fail( 'ثبت گردش تبدیل ناموفق بود.' );
		}
		
		// 3️⃣ اگر lot خالی شد → بسته شود
		$new_remaining = round( $remaining - $total_weight, 6 );
		
		if ( $new_remaining <= 0 ) {
			$update = $this->db->update(
				$this->packaging_lots,
				[
					'status'     => 'closed',
					'updated_at' => current_time( 'mysql' ),
				],
				[ 'id' => $lot_id ],
				[ '%s', '%s' ],
				[ '%d' ]
			);
			
			if ( FALSE === $update ) {
				$this->db->query( 'ROLLBACK' );
				
				return $this->fail( 'بروزرسانی وضعیت lot ناموفق بود.' );
			}
		}
		
		$this->recalculate_processing_pack_status( (int) $lot['processing_pack_id'] );
		if ( $this->db->last_error ) {
			$this->db->query( 'ROLLBACK' );
			return $this->fail( 'به‌روزرسانی وضعیت فرآوری ناموفق بود.' );
		}
		
		// 2️⃣ ثبت ورود به انبار فروشگاه (Inventory)
		
		$movement = $this->add_inventory_movement( [
			'unique_product_code' => $code,
			'wc_product_id'       => $product_id,
			'change_qty'          => $qty_items,      // ورود کالا
			'unit_cost'           => $unit_cost_final,
			'total_cost'          => $total_cost,     // مثبت
			'ref_type'            => 'production',
			'ref_id'              => $conversion_id,
			'note'                => 'ورود از تبدیل سالن به محصول فروشگاهی',
		] );
		
		if ( $movement['status'] !== 'success' ) {
			$this->db->query( 'ROLLBACK' );
			
			return $movement;
		}
		$apply = $this->apply_inventory_change( [
			'unique_product_code' => $code,
			'wc_product_id'       => $product_id,
			'change_qty'          => $qty_items,
			'total_cost'          => $total_cost,
		] );
		
		if ( $apply['status'] !== 'success' ) {
			$this->db->query( 'ROLLBACK' );
			
			return $apply;
		}
		if ( ! $inside_transaction && FALSE === $this->db->query( 'COMMIT' ) ) {
			$this->db->query( 'ROLLBACK' );
			return $this->fail( 'ثبت نهایی تبدیل ناموفق بود.' );
		}
		return $this->ok(
			'تبدیل به محصول با موفقیت انجام شد.',
			[
				'conversion_id' => $conversion_id,
				'lot_id'        => $lot_id,
				'total_weight'  => $total_weight,
				'unit_cost'     => $unit_cost_final,
			]
		);
	}
	
	public function get_packaging_hall_summary( $category_id = 0, $date_from = '', $date_to = '' ): array {
		$joins  = '';
		$where  = ["NOT EXISTS (SELECT 1 FROM {$this->db_prefix}packaging_lot_meta direct_trace WHERE direct_trace.lot_id=m.packaging_lot_id AND direct_trace.meta_key='direct_bulk' AND direct_trace.meta_value='1')"];
		$params = [];
		
		if ( $category_id > 0 ) {
			[ $join, $meta_where, $meta_params ] = $this->build_meta_equals_filter(
				'processing_pack',
				'category_id',
				(string) $category_id,
				'm_cat',
				'l.processing_pack_id'
			);
			
			if ( $join && $meta_where ) {
				$joins .= "
				INNER JOIN {$this->packaging_lots} l
					ON l.id = m.packaging_lot_id
				{$join}
			";
				
				$where[] = $meta_where;
				$params  = $meta_params;
			}
		}
		if ( $date_from ) {
			$where[]  = 'm.created_at >= %s';
			$params[] = $date_from . ' 00:00:00';
		}
		
		if ( $date_to ) {
			$where[]  = 'm.created_at <= %s';
			$params[] = $date_to . ' 23:59:59';
		}
		$where_sql = $where ? 'WHERE ' . implode( ' AND ', $where ) : '';
		
		// 1️⃣ موجودی فعلی سالن
		$current_balance = (float) $this->db->get_var(
			$this->db->prepare(
				"SELECT COALESCE(SUM(
				CASE
					WHEN m.direction = 'in'  THEN m.qty_weight
					WHEN m.direction = 'out' THEN -m.qty_weight
				END
			),0)
			FROM {$this->packaging_moves} m
			{$joins}
			{$where_sql}",
				$params
			)
		);
		
		// 2️⃣ مجموع هدررفت
		$total_waste = (float) $this->db->get_var(
			$this->db->prepare(
				"SELECT COALESCE(SUM(m.qty_weight),0)
			FROM {$this->packaging_moves} m
			{$joins}
			{$where_sql}
			" . ( $where_sql ? " AND " : " WHERE " ) . "m.reason = 'waste'",
				$params
			)
		);
		
		// 3️⃣ مجموع تبدیل به محصول
		$total_converted = (float) $this->db->get_var(
			$this->db->prepare(
				"SELECT COALESCE(SUM(m.qty_weight),0)
			FROM {$this->packaging_moves} m
			{$joins}
			{$where_sql}
			" . ( $where_sql ? " AND " : " WHERE " ) . "m.reason = 'convert_to_shop_product'",
				$params
			)
		);
		
		return [
			'current_in_packaging' => round( max( 0, $current_balance ), 6 ),
			'total_waste'          => round( $total_waste, 6 ),
			'total_converted'      => round( $total_converted, 6 ),
		];
	}
	
	public function add_inventory_movement( array $args ): array {
		$args = wp_parse_args( $args, [
			'unique_product_code' => '',
			'wc_product_id'       => 0,
			'change_qty'          => 0,
			'unit_cost'           => 0,
			'total_cost'          => 0,
			'ref_type'            => '',
			'ref_id'              => 0,
			'note'                => NULL,
			'created_at'          => current_time( 'mysql' ),
		] );
		
		if (
			trim( (string) $args['unique_product_code'] ) === '' ||
			$args['wc_product_id'] <= 0 ||
			$args['change_qty'] == 0 ||
			$args['ref_type'] === ''
		) {
			return $this->fail( 'اطلاعات حرکت انبار نامعتبر است.' );
		}
		
		$inserted = $this->db->insert(
			$this->inventory_log,
			[
				'unique_product_code' => $args['unique_product_code'],
				'wc_product_id'       => (int) $args['wc_product_id'],
				'change_qty'          => (float) $args['change_qty'],
				'unit_cost'           => (float) $args['unit_cost'],
				'total_cost'          => (float) $args['total_cost'],
				'ref_type'            => $args['ref_type'],
				'ref_id'              => (int) $args['ref_id'],
				'note'                => $args['note'],
				'created_at'          => $args['created_at'],
			],
			[ '%s', '%d', '%f', '%f', '%f', '%s', '%d', '%s', '%s' ]
		);
		
		if ( ! $inserted ) {
			return $this->fail( 'ثبت لاگ انبار ناموفق بود.' );
		}
		
		return $this->ok(
			'حرکت انبار با موفقیت ثبت شد.',
			[
				'movement_id' => (int) $this->db->insert_id,
			]
		);
	}
	
	public function apply_inventory_change( array $args ): array {
		$args = wp_parse_args( $args, [
			'unique_product_code' => '',
			'wc_product_id'       => 0,
			'change_qty'          => 0,
			'total_cost'          => 0,
		] );
		
		// Keep the stored code byte-for-byte: inventory_balance and inventory_log
		// must use the same key. Trimming here could create a second balance row
		// when a legacy code contains surrounding whitespace.
		$unique_product_code = (string) $args['unique_product_code'];
		$wc_product_id       = absint( $args['wc_product_id'] );
		$change_qty          = (float) $args['change_qty'];
		$total_cost          = (float) $args['total_cost'];
		
		if (
			trim( $unique_product_code ) === '' ||
			$wc_product_id <= 0 ||
			$change_qty == 0
		) {
			return $this->fail( 'اطلاعات اعمال موجودی نامعتبر است.' );
		}
		
		/*
		 * موجودی باید بر اساس ترکیب:
		 *
		 * unique_product_code + wc_product_id
		 *
		 * پیدا شود.
		 */
		$row = $this->db->get_row(
			$this->db->prepare(
				"
			SELECT *
			FROM {$this->inventory_balance}
			 WHERE unique_product_code = %s
			  AND wc_product_id = %d
			LIMIT 1
			",
				$unique_product_code,
				$wc_product_id
			),
			ARRAY_A
		);
		
		$current_qty   = $row ? (float) $row['qty_available'] : 0;
		$current_value = $row ? (float) $row['inventory_value'] : 0;
		
		$new_qty   = round($current_qty + $change_qty, 5);
		$new_value = $current_value + $total_cost;
		
		if ( $new_qty < 0 ) {
			return $this->fail( 'موجودی کافی نیست.' );
		}
		
		/*
		 * برای جلوگیری از منفی شدن ارزش موجودی
		 * در اثر خطاهای اعشاری.
		 */
		if ( abs( $new_value ) < 0.000001 ) {
			$new_value = 0;
		}
		
		$new_avg = $new_qty > 0
			? $new_value / $new_qty
			: 0;
		
		if ( $row ) {
			$updated = $this->db->update(
				$this->inventory_balance,
				[
					'qty_available'   => $new_qty,
					'inventory_value' => $new_value,
					'avg_unit_cost'   => $new_avg,
					'updated_at'      => current_time( 'mysql' ),
				],
				[
					'id' => (int) $row['id'],
				],
				[
					'%f',
					'%f',
					'%f',
					'%s',
				],
				[
					'%d',
				]
			);
			
			if ( $updated === FALSE ) {
				return $this->fail( 'به‌روزرسانی موجودی ناموفق بود.' );
			}
			$allocation_ok = $this->apply_warehouse_allocation_delta( (int) $row['id'], $current_qty, $change_qty );
			if ( ! $allocation_ok ) {
				$this->db->update( $this->inventory_balance, [ 'qty_available'=>$current_qty, 'inventory_value'=>$current_value, 'avg_unit_cost'=>$current_qty > 0 ? $current_value / $current_qty : 0 ], [ 'id'=>(int)$row['id'] ] );
				return $this->fail( 'تخصیص موجودی بین انبارها نامعتبر است؛ تغییر موجودی اعمال نشد.' );
			}
			
			return $this->ok(
				'موجودی با موفقیت به‌روزرسانی شد.',
				[
					'inventory_id'    => (int) $row['id'],
					'new_qty'         => $new_qty,
					'inventory_value' => $new_value,
					'avg_unit_cost'   => $new_avg,
				]
			);
		}
		
		$inserted = $this->db->insert(
			$this->inventory_balance,
			[
				'unique_product_code' => $unique_product_code,
				'wc_product_id'       => $wc_product_id,
				'qty_available'       => $new_qty,
				'inventory_value'     => $new_value,
				'avg_unit_cost'       => $new_avg,
				'created_at'          => current_time( 'mysql' ),
				'updated_at'          => current_time( 'mysql' ),
			],
			[
				'%s',
				'%d',
				'%f',
				'%f',
				'%f',
				'%s',
				'%s',
			]
		);
		
		if ( ! $inserted ) {
			return $this->fail( 'ایجاد رکورد موجودی ناموفق بود.' );
		}
		$new_inventory_id = (int) $this->db->insert_id;
		if ( ! $this->apply_warehouse_allocation_delta( $new_inventory_id, 0, $change_qty ) ) {
			$this->db->delete( $this->inventory_balance, [ 'id' => $new_inventory_id ] );
			return $this->fail( 'تخصیص موجودی جدید به انبار اصلی ناموفق بود؛ رکورد موجودی ایجاد نشد.' );
		}
		
		return $this->ok(
			'موجودی با موفقیت ایجاد شد.',
			[
				'inventory_id'    => $new_inventory_id,
				'new_qty'         => $new_qty,
				'inventory_value' => $new_value,
				'avg_unit_cost'   => $new_avg,
			]
		);
	}
	
	public function get_inventory_items( array $args = [] ): array {
		$args = wp_parse_args( $args, [
			'page'           => 1,
			'per_page'       => 20,
			'search'         => '',
			'product_id'     => 0,
			'term_id'        => 0,
			'orderby'        => 'updated_at',
			'order'          => 'DESC',
			'only_available' => FALSE, // 👈 پیش‌فرض
		] );
		
		$page     = max( 1, (int) $args['page'] );
		$per_page = max( 1, (int) $args['per_page'] );
		$offset   = ( $page - 1 ) * $per_page;
		
		$where  = 'WHERE 1=1';
		$params = [];
		
		// فقط موجودی مثبت
		if ( ! empty( $args['only_available'] ) ) {
			$where .= " AND qty_available > 0";
		}
		
		if ( $args['search'] !== '' ) {
			$where    .= " AND unique_product_code LIKE %s";
			$params[] = '%' . $this->db->esc_like( $args['search'] ) . '%';
		}
		
		if ( $args['product_id'] > 0 ) {
			$where    .= " AND wc_product_id = %d";
			$params[] = (int) $args['product_id'];
		}
		if ( $args['term_id'] > 0 ) {
			$selected_category = get_term( $args['term_id'], 'product_cat' );
			$product_ids       = get_posts( [
				'numberposts' => - 1,
				'post_type'   => 'product',
				'taxonomy'    => 'product_cat',
				'term'        => $selected_category->slug,
				'fields'      => 'ids',
			] );
			$place_holder      = implode( "','", $product_ids );
			$where             .= " AND wc_product_id IN ('$place_holder')";
		}
		
		$allowed_orderby = [
			'unique_product_code',
			'qty_available',
			'avg_unit_cost',
			'inventory_value',
			'updated_at',
		];
		
		$orderby = in_array( $args['orderby'], $allowed_orderby, TRUE )
			? $args['orderby']
			: 'updated_at';
		
		$order = strtoupper( $args['order'] ) === 'ASC' ? 'ASC' : 'DESC';
		
		// ---- دریافت آیتم‌ها
		$sql = "
		SELECT *
		FROM {$this->inventory_balance}
		{$where}
		ORDER BY {$orderby} {$order}
		LIMIT %d OFFSET %d
	";
		
		$params_with_limit = array_merge( $params, [ $per_page, $offset ] );
		
		$rows = $this->db->get_results(
			$this->db->prepare( $sql, ...$params_with_limit ),
			ARRAY_A
		);
		
		// ---- شمارش کل
		$count_sql = "
		SELECT COUNT(*)
		FROM {$this->inventory_balance}
		{$where}
	";
		
		$total = (int) $this->db->get_var(
			empty( $params )
				? $count_sql
				: $this->db->prepare( $count_sql, ...$params )
		);
		
		$total_page = (int) ceil( $total / $per_page );
		
		return [
			'items'      => $rows ?: [],
			'pagination' => [
				'page'       => $page,
				'per_page'   => $per_page,
				'total'      => $total,
				'total_page' => $total_page,
			],
		];
	}
	
	public function get_inventory_item( int $inventory_id ): ?array {
		$inventory_id = (int) $inventory_id;
		
		if ( $inventory_id <= 0 ) {
			return NULL;
		}
		
		$row = $this->db->get_row(
			$this->db->prepare(
				"SELECT *
			 FROM {$this->inventory_balance}
			 WHERE id = %d
			 LIMIT 1",
				$inventory_id
			),
			ARRAY_A
		);
		
		return $row ?: NULL;
	}
	
	public function get_inventory_logs( int $inventory_id, int $product_id, array $args = [] ): array {
		$inventory_id = (int) $inventory_id;
		
		if ( $inventory_id <= 0 ) {
			return [
				'items'      => [],
				'pagination' => [
					'page'       => 1,
					'per_page'   => 0,
					'total'      => 0,
					'total_page' => 0,
				],
			];
		}
		
		// گرفتن unique_product_code از جدول balance
		$code = $this->db->get_var(
			$this->db->prepare(
				"SELECT unique_product_code
			 FROM {$this->inventory_balance}
			 WHERE id = %d
			 LIMIT 1",
				$inventory_id
			)
		);
		
		if ( ! $code ) {
			return [
				'items'      => [],
				'pagination' => [
					'page'       => 1,
					'per_page'   => 0,
					'total'      => 0,
					'total_page' => 0,
				],
			];
		}
		
		$args = wp_parse_args( $args, [
			'page'     => 1,
			'per_page' => 20,
			'orderby'  => 'created_at',
			'order'    => 'DESC',
		] );
		
		$page     = max( 1, (int) $args['page'] );
		$per_page = max( 1, (int) $args['per_page'] );
		$offset   = ( $page - 1 ) * $per_page;
		
		$allowed_orderby = [
			'id',
			'created_at',
			'change_qty',
			'total_cost',
			'ref_type',
		];
		
		$orderby = in_array( $args['orderby'], $allowed_orderby, TRUE )
			? $args['orderby']
			: 'created_at';
		
		$order = strtoupper( $args['order'] ) === 'ASC' ? 'ASC' : 'DESC';
		
		// دریافت لاگ‌ها
		$sql = "
		SELECT *
		FROM {$this->inventory_log}
		WHERE unique_product_code = %s AND wc_product_id= %d
		ORDER BY {$orderby} {$order}
		LIMIT %d OFFSET %d
	";
		
		$rows = $this->db->get_results(
			$this->db->prepare(
				$sql,
				$code,
				$product_id,
				$per_page,
				$offset
			),
			ARRAY_A
		);
		
		// شمارش کل
		$count_sql = "
		SELECT COUNT(*)
		FROM {$this->inventory_log}
		WHERE unique_product_code = %s
	";
		
		$total = (int) $this->db->get_var(
			$this->db->prepare(
				$count_sql,
				$code
			)
		);
		
		$total_page = (int) ceil( $total / $per_page );
		
		return [
			'items'      => $rows ?: [],
			'pagination' => [
				'page'       => $page,
				'per_page'   => $per_page,
				'total'      => $total,
				'total_page' => $total_page,
			],
		];
	}
	
    /** Quantities are kilograms for products identified as bulk in the catalogue. */
    public static function is_bulk_order_product(int $product_id): bool {
        return $product_id > 0 && (bool) preg_match('/(?<!\p{L})فله(?!\p{L})/u', get_the_title($product_id));
    }

    public static function format_order_quantity($qty): string {
        return rtrim(rtrim(number_format((float)$qty, 5, '.', ','), '0'), '.');
    }

    private function order_quantity($input): ?float {
        if (!is_scalar($input) || is_bool($input)) return null;
        $value = str_replace('٫', '.', nooshika_sanitize_numbers(trim((string)$input)));
        if (!preg_match('/^(?:[0-9]{1,10}(?:\.[0-9]{0,5}0*)?|\.[0-9]{1,5}0*)$/D', $value)) return null;
        return (float)$value;
    }

    /** Run DDL before opening the order transaction. Each completed column can be retried independently. */
    private function fractional_order_schema_ready(): bool {
        if (get_option('kph_order_quantity_decimal_v1') === 'ready') return true;
        $columns = [
            $this->orders => ['total_ordered_qty'],
            $this->order_items => ['qty_ordered','shipped_paid_qty'],
            $this->fulfillment_items => ['shipped_paid_qty'],
            $this->inventory_log => ['change_qty'],
            $this->inventory_balance => ['qty_available'],
        ];
        foreach ($columns as $table => $names) {
            $fields = array_column($this->db->get_results("SHOW COLUMNS FROM `$table`", ARRAY_A) ?: [], 'Type', 'Field');
            $changes = [];
            foreach ($names as $name) {
                $type = strtolower($fields[$name] ?? '');
                $precision = 20;
                if (preg_match('/^decimal\((\d+),(\d+)\)/', $type, $m)) {
                    if ((int)$m[2] >= 5) continue;
                    $precision = max(20, (int)$m[1] - (int)$m[2] + 5);
                    if ($precision > 65) return false;
                } elseif (!preg_match('/^int\b/', $type)) {
                    return false;
                }
                $default = in_array($name, ['qty_ordered','change_qty'], true) ? '' : ' DEFAULT 0';
                $changes[] = "MODIFY COLUMN `$name` DECIMAL($precision,5) NOT NULL$default";
            }
            if ($changes && false === $this->db->query("ALTER TABLE `$table` " . implode(', ', $changes))) return false;
        }
        update_option('kph_order_quantity_decimal_v1', 'ready');
        return true;
    }

	/**
	 * Add or update order (default status = proforma)
	 *
	 * Sample:
	 *
	 * $this->add_or_update_order([
	 *     'order_id'    => 0, // اگر 0 باشد → ایجاد
	 *     'customer_id' => 12,
	 *     'items'       => [
	 *         [
	 *             'inventory_id'        => 5,
	 *             'base_price'          => 120000,
	 *             'qty_ordered'         => 10,
	 *             'discount_cash_type'  => 'percent',
	 *             'discount_cash_value' => 10,
	 *             'goods_buy_x'         => 5,
	 *             'goods_free_y'        => 1,
	 *         ],
	 *     ],
	 * ]);
	 */
	public function add_or_update_order( array $args ): array {
		if ( $this->visitor_order_scope_id() ) {
			$args['created_by'] = $this->visitor_order_scope_id();
			if ( ! empty( $args['order_id'] ) && ! $this->visitor_can_access_order( (int) $args['order_id'] ) ) {
				return $this->fail( 'اجازه دسترسی به این سفارش را ندارید.' );
			}
		}
		$args = wp_parse_args( $args, [
			'order_id'    => 0,
			'customer_id' => NULL,
			'created_by'  => get_current_user_id(),
			'currency'    => 'IRR',
			'note'        => NULL,
			'items'       => [],
			'meta'        => [],
		] );
		
		if ( is_array( $args['meta'] ) && array_key_exists( 'payment_term_days', $args['meta'] ) ) {
			$term = $this->normalize_customer_payment_term( $args['meta']['payment_term_days'] );
			if ( $term === NULL ) {
				return $this->fail( 'مهلت تسویه باید عدد صحیح بین صفر تا ۳۶۵۰ روز باشد.' );
			}
			$args['meta']['payment_term_days'] = $term;
		}
        $needs_decimal = false;
        foreach ($args['items'] as $item) {
            $qty = $this->order_quantity($item['qty_ordered'] ?? null);
            if ($qty === null || $qty <= 0) return $this->fail('مقدار هر قلم باید عددی مثبت با حداکثر پنج رقم اعشار باشد.');
            if ($qty == floor($qty)) continue;
            $product_id = absint($item['wc_product_id'] ?? 0);
            if (!empty($item['inventory_id'])) {
                $inventory = $this->get_inventory_item(absint($item['inventory_id']));
                $product_id = (int)($inventory['wc_product_id'] ?? 0);
            }
            if (!self::is_bulk_order_product($product_id)) {
                return $this->fail('تعداد محصول بسته‌بندی‌شده باید عدد صحیح باشد.');
            }
            $needs_decimal = true;
        }
        if ($needs_decimal && !$this->fractional_order_schema_ready()) {
            return $this->fail('آماده‌سازی ستون‌های وزن در پایگاه داده انجام نشد. پیش‌فاکتور ذخیره نشد.');
        }
		if ( (int) $args['order_id'] > 0 ) {
			return $this->update_order( $args );
		}
		
		return $this->add_order_internal( $args );
	}
	
	/* ============================================================ */
	
	private function add_order_internal( array $args ): array {
		if ( empty( $args['items'] ) ) {
			return $this->fail( 'Order items are required.' );
		}
		
		if(false===$this->db->query('START TRANSACTION'))return $this->fail('شروع ثبت پیش‌فاکتور انجام نشد.');
		
		$now          = current_time( 'mysql' );
		$order_number = 'KPH-' . date( 'YmdHis' ) . '-' . wp_generate_password( 6, FALSE, FALSE );
		
		$inserted = $this->db->insert(
			$this->orders,
			[
				'order_number' => $order_number,
				'status'       => 'proforma',
				'customer_id'  => $args['customer_id'],
				'created_by'   => $args['created_by'],
				'currency'     => $args['currency'],
				'note'         => $args['note'],
				'created_at'   => $now,
				'updated_at'   => $now,
			]
		);
		
		if ( ! $inserted ) {
			$this->db->query( 'ROLLBACK' );
			
			return $this->fail( 'Order insert failed.' );
		}
		
		$order_id = (int) $this->db->insert_id;
		
		$res = $this->sync_order_items( $order_id, $args['items'] );
		if ( $res['status'] !== 'success' ) {
			$this->db->query( 'ROLLBACK' );
			
			return $res;
		}
		$assigned_visitor = absint( get_user_meta( (int) $args['customer_id'], 'customer_marketer', TRUE ) );
		if ( $assigned_visitor <= 0 ) {
			$assigned_visitor = absint( get_user_meta( (int) $args['customer_id'], KPH_MARKETER_META, TRUE ) );
		}
		if ( $assigned_visitor <= 0 || nooshika_get_user_role( $assigned_visitor ) !== 'visitor' ) {
			$current_user_role = nooshika_get_user_role( get_current_user_id() );
			$assigned_visitor  = $current_user_role === 'visitor' ? get_current_user_id() : 0;
		}
		if ( $assigned_visitor > 0 ) {
			$args['meta']['marketer_id'] = $assigned_visitor;
		}
		if ( ! empty( $args['meta'] ) ) {
			$meta_result=$this->save_order_meta_batch($order_id,$args['meta']);
            if($meta_result['status']!=='success'){$this->db->query('ROLLBACK');return $this->fail('ثبت اطلاعات پیش‌فاکتور انجام نشد.');}
		}
		
		$totals_result=$this->recalculate_order_totals($order_id);if($totals_result['status']!=='success'){$this->db->query('ROLLBACK');return $totals_result;}
		
		if(false===$this->db->query('COMMIT')){$this->db->query('ROLLBACK');return $this->fail('ثبت نهایی پیش‌فاکتور انجام نشد.');}
		
		return $this->ok( 'Order created.', [ 'order_id' => $order_id ] );
	}
	
	private function update_order( array $args ): array {
		$order_id = (int) $args['order_id'];
		if ( $order_id <= 0 ) {
			return $this->fail( 'Invalid order_id.' );
		}
		
        $guard=$this->supply_order_guard($order_id);if($guard['status']!=='success')return $guard;
        if(!$this->supply_begin_transaction())return $this->fail('شروع تراکنش انجام نشد.');
        $locked=$this->db->get_row($this->db->prepare("SELECT id FROM {$this->orders} WHERE id=%d FOR UPDATE",$order_id),ARRAY_A);
        if(!$locked){$this->db->query('ROLLBACK');return $this->fail('سفارش پیدا نشد.');}
        if($this->supply_tracked($order_id) && $this->db->get_var($this->db->prepare("SELECT id FROM {$this->order_items} WHERE order_id=%d AND (shipped_paid_qty>0 OR shipped_free_qty>0) LIMIT 1",$order_id))){$this->db->query('ROLLBACK');return $this->fail('این سفارش ارسال دارد؛ برای اصلاح از لغو ارسال یا کاهش باقیمانده استفاده کنید.');} 
		
		$updated = $this->db->update(
			$this->orders,
			[
				'customer_id' => $args['customer_id'],
				'currency'    => $args['currency'],
				'note'        => $args['note'],
				'updated_at'  => current_time( 'mysql' ),
			],
			[ 'id' => $order_id ]
		);
		
		if ( $updated === FALSE ) {
			$this->db->query( 'ROLLBACK' );
			
			return $this->fail( 'Order update failed.' );
		}
		
		$res = $this->sync_order_items( $order_id, $args['items'] );
		if ( $res['status'] !== 'success' ) {
			$this->db->query( 'ROLLBACK' );
			
			return $res;
		}
		
		if ( ! empty( $args['meta'] ) ) {
			$this->save_order_meta_batch( $order_id, $args['meta'] );
		}
		
		$totals_result=$this->recalculate_order_totals($order_id);if($totals_result['status']!=='success'){$this->db->query('ROLLBACK');return $totals_result;}
		
        $supplies=$this->sync_order_supplies($order_id);if($supplies['status']!=='success'){$this->db->query('ROLLBACK');return $supplies;}
        if(FALSE===$this->db->query('COMMIT')){$this->db->query('ROLLBACK');return $this->fail('ثبت نهایی سفارش انجام نشد.');}
		
		return $this->ok( 'Order updated.', [ 'order_id' => $order_id ] );
	}
	
	public function delete_customer_proforma( int $order_id, bool $prepare_storage = false ): array {
        return $this->delete_customer_proforma_record($order_id, $prepare_storage);
    }
	

	private function sync_order_items( int $order_id, array $items ): array {
		if(FALSE===$this->db->delete( $this->order_items, [ 'order_id' => $order_id ] ))return $this->fail('حذف اقلام قبلی سفارش انجام نشد.');
		
		foreach ( $items as $item ) {
			$res = $this->add_or_update_order_item( $order_id, $item );
			
			if ( $res['status'] !== 'success' ) {
				return $res;
			}
		}
		
		return $this->ok();
	}
	
	private function add_or_update_order_item( int $order_id, array $item ): array {
		$item = wp_parse_args( $item, [
			'inventory_id'        => 0,
			'wc_product_id'       => 0,
			'base_price'          => 0,
			'qty_ordered'         => 0,
			'discount_cash_type'  => 'none',
			'discount_cash_value' => 0,
			'goods_buy_x'         => 0,
			'goods_free_y'        => 0,
			'note'                => NULL,
			'meta'                => [],
		] );
		
		$inventory_id  = absint( $item['inventory_id'] );
		$wc_product_id = absint( $item['wc_product_id'] );
		$qty_ordered   = $this->order_quantity($item['qty_ordered']);
		$base_price    = (float) $item['base_price'];
		
		if ( $qty_ordered <= 0 ) {
			return $this->fail( 'مقدار سفارش باید بیشتر از صفر باشد.' );
		}
		
		$inv                 = NULL;
		$unique_product_code = NULL;
		
		/**
		 * اگر inventory_id داشتیم، محصول را از روی inventory پیدا کن.
		 */
		if ( $inventory_id > 0 ) {
			$inv = $this->get_inventory_item( $inventory_id );
			
			if ( ! $inv ) {
				return $this->fail( 'Inventory not found.' );
			}
			
			$wc_product_id       = absint( $inv['wc_product_id'] );
			$unique_product_code = $inv['unique_product_code'];
		}
		
		/**
		 * اگر inventory_id نداریم، باید حداقل wc_product_id داشته باشیم.
		 */
		if ( $wc_product_id <= 0 ) {
			return $this->fail( 'Product not found.' );
		}
		
		$product_post = get_post( $wc_product_id );
		
		if (
			! $product_post ||
			$product_post->post_type !== 'product' ||
			$product_post->post_status !== 'publish'
		) {
			return $this->fail( 'Invalid product.' );
		}
		
		$subtotal = $base_price * $qty_ordered;
		
		$discount_amount = 0;
		
		if ( $item['discount_cash_type'] === 'percent' ) {
			$discount_amount = ( $subtotal * (float) $item['discount_cash_value'] ) / 100;
		} elseif ( $item['discount_cash_type'] === 'amount' ) {
			$discount_amount = min( (float) $item['discount_cash_value'], $subtotal );
		}
		
		$expected_free_qty = 0;
		
		if ( $item['goods_buy_x'] > 0 && $item['goods_free_y'] > 0 ) {
			$expected_free_qty = (int) floor( $qty_ordered / (int) $item['goods_buy_x'] ) * (int) $item['goods_free_y'];
		}
		
		$inserted = $this->db->insert(
			$this->order_items,
			[
				'order_id'             => $order_id,
				'inventory_id'         => $inventory_id > 0 ? $inventory_id : 0,
				'unique_product_code'  => $unique_product_code ?? '',
				'wc_product_id'        => $wc_product_id,
				'base_price'           => $base_price,
				'qty_ordered'          => $qty_ordered,
				'discount_cash_type'   => $item['discount_cash_type'],
				'discount_cash_value'  => (float) $item['discount_cash_value'],
				'discount_cash_amount' => $discount_amount,
				'goods_buy_x'          => (int) $item['goods_buy_x'],
				'goods_free_y'         => (int) $item['goods_free_y'],
				'expected_free_qty'    => $expected_free_qty,
				'final_amount'         => $subtotal - $discount_amount,
				'note'                 => $item['note'],
				'created_at'           => current_time( 'mysql' ),
				'updated_at'           => current_time( 'mysql' ),
			]
		);
		
		if ( ! $inserted ) {
			return $this->fail( 'Order item insert failed.' );
		}
		
		$order_item_id = (int) $this->db->insert_id;
		
		if ( ! empty( $item['meta'] ) ) {
			$this->save_order_item_meta_batch( $order_item_id, $item['meta'] );
		}
		
		return $this->ok();
	}
	
	private function recalculate_order_totals( int $order_id ): array {
		$rows = $this->db->get_results(
			$this->db->prepare(
				"SELECT
				SUM(base_price * qty_ordered) AS subtotal,
				SUM(discount_cash_amount)     AS discount_total,
				SUM(final_amount)             AS payable,
				SUM(qty_ordered)              AS qty_total,
				SUM(expected_free_qty)        AS free_total
			 FROM {$this->order_items}
			 WHERE order_id = %d",
				$order_id
			),
			ARRAY_A
		);
		
		if($this->db->last_error)return $this->fail('خواندن جمع سفارش انجام نشد.');
		$row = $rows[0] ?? [];
		
		$totals_written=$this->db->update(
			$this->orders,
			[
				'items_subtotal'          => (float) $row['subtotal'],
				'discount_cash_total'     => (float) $row['discount_total'],
				'total_payable'           => (float) $row['payable'],
				'total_ordered_qty'       => (float) $row['qty_total'],
				'total_expected_free_qty' => (int) $row['free_total'],
				'updated_at'              => current_time( 'mysql' ),
			],
			[ 'id' => $order_id ]
		);
        return $totals_written===FALSE?$this->fail('ثبت جمع سفارش انجام نشد.'):$this->ok();
	}
	
	/**
	 * Get orders list with filters
	 */
	/** Latest non-canceled shipment for each visible order, including legacy shipments. */
	/**
	 * Read-only effective status for older orders. Full zero-quantity returns created
	 * before this version must not keep the misleading "shipped" badge. We don't
	 * write to the database on a read or silently erase accounting history.
	 */
	private function order_display_status_sql( string $alias ): string {
		return "CASE WHEN {$alias}.status IN ('registered','shortage','shipped')
		 AND NOT EXISTS (SELECT 1 FROM {$this->order_items} oi
		   WHERE oi.order_id = {$alias}.id
		   AND (oi.qty_ordered > 0 OR oi.expected_free_qty > 0
		        OR oi.shipped_paid_qty > 0 OR oi.shipped_free_qty > 0))
		 THEN CASE WHEN EXISTS (
		   SELECT 1 FROM {$this->fulfillments} f
		   INNER JOIN {$this->fulfillment_items} fi ON fi.fulfillment_id = f.id
		   INNER JOIN {$this->inventory_log} il
		     ON il.ref_type = 'return' AND il.ref_id = fi.id
		   WHERE f.order_id = {$alias}.id
		 ) THEN 'returned' ELSE 'canceled' END
		 ELSE {$alias}.status END";
	}

	public function get_order_last_shipment_dates( array $order_ids ): array {
		if ( $this->visitor_order_scope_id() ) { $order_ids = array_filter( $order_ids, fn( $id ) => $this->visitor_can_access_order( (int) $id ) ); }
		$ids = implode( ',', array_unique( array_filter( array_map( 'absint', $order_ids ) ) ) );
		if ( ! $ids ) { return []; }
		$rows = $this->db->get_results( "SELECT f.order_id,
			MAX(COALESCE(NULLIF(f.shipped_at, '0000-00-00 00:00:00'), f.created_at)) AS last_shipped_at
			FROM {$this->fulfillments} f
			WHERE f.order_id IN ({$ids}) AND f.status <> 'canceled'
			AND EXISTS (SELECT 1 FROM {$this->fulfillment_items} fi WHERE fi.fulfillment_id = f.id
			 AND (fi.shipped_paid_qty > 0 OR fi.shipped_free_qty > 0))
			GROUP BY f.order_id", ARRAY_A );
		return array_column( $rows ?: [], 'last_shipped_at', 'order_id' );
	}

	public function get_orders_list( array $args = [] ): array {
		$args = wp_parse_args( $args, [
			'customer_id'          => 0,
			'marketer_id'          => 0,
			'visitor_id'           => 0,
			'created_by'           => 0,
			'customer_marketer_id' => 0,
			'status'               => NULL,
			'date_from'            => NULL,
			'date_to'              => NULL,
			'page'                 => 1,
			'per_page'             => 20,
			'orderby'              => 'created_at',
			'order'                => 'DESC',
		] );
		
		$page     = max( 1, (int) $args['page'] );
		$per_page = max( 1, (int) $args['per_page'] );
		$offset   = ( $page - 1 ) * $per_page;
		
		$where  = [];
		$params = [];
		$joins  = [];
		if ( $this->visitor_order_scope_id() ) {
			$where[] = 'a.created_by = %d';
			$params[] = $this->visitor_order_scope_id();
			// Customer assignment must not hide an order registered by the current visitor.
			$args['customer_marketer_id'] = $args['marketer_id'] = $args['visitor_id'] = 0;
		}
		if ( (int) $args['created_by'] > 0 ) {
			$where[] = 'a.created_by = %d';
			$params[] = (int) $args['created_by'];
		}
		if ( (int) $args['visitor_id'] > 0 ) {
			$where[]  = $this->order_visitor_sql() . ' = %d';
			$params[] = (int) $args['visitor_id'];
		}
		
		/*
		 * فیلتر بر اساس یک مشتری مشخص
		 */
		if ( (int) $args['customer_id'] > 0 ) {
			$where[]  = 'a.customer_id = %d';
			$params[] = (int) $args['customer_id'];
		}
		
		/*
		 * فیلتر بر اساس بازاریاب ثبت‌شده روی خود سفارش
		 */
		if ( (int) $args['marketer_id'] > 0 ) {
			$order_meta_table = $this->db_prefix . 'orders_meta';
			
			$joins[] = "
         INNER JOIN {$order_meta_table} marketer_meta
            ON marketer_meta.order_id = a.id
            AND marketer_meta.meta_key = 'marketer_id'
      ";
			
			$where[]  = 'marketer_meta.meta_value = %s';
			$params[] = (string) (int) $args['marketer_id'];
		}
		
		/*
		 * فیلتر سفارشات بر اساس ویزیتور / بازاریاب مشتری
		 *
		 * دقیقاً مطابق users.php:
		 * customer_marketer = user_id
		 */
		if ( (int) $args['customer_marketer_id'] > 0 ) {
			$usermeta_table = $this->db->usermeta;
			
			$joins[] = "
         INNER JOIN {$usermeta_table} customer_marketer_meta
            ON customer_marketer_meta.user_id = a.customer_id
            AND customer_marketer_meta.meta_key = 'customer_marketer'
      ";
			
			$where[]  = 'customer_marketer_meta.meta_value = %s';
			$params[] = (string) (int) $args['customer_marketer_id'];
		}
		
		/*
		 * وضعیت نمایشی سفارش، شامل مرجوعی‌های قدیمی که قبلاً ارسال کامل نمایش داده می‌شدند.
		 */
		$display_status_sql = $this->order_display_status_sql( 'a' );
		if ( ! empty( $args['status'] ) ) {
			if ( is_array( $args['status'] ) ) {
				$placeholders = implode(
					',',
					array_fill( 0, count( $args['status'] ), '%s' )
				);
				
				$where[] = "($display_status_sql) IN ($placeholders)";
				$params  = array_merge( $params, $args['status'] );
			} else {
				$where[]  = "($display_status_sql) = %s";
				$params[] = (string) $args['status'];
			}
		}
		
		/*
		 * تاریخ شروع
		 */
		if ( ! empty( $args['date_from'] ) ) {
			$where[]  = 'a.created_at >= %s';
			$params[] = $args['date_from'] . ' 00:00:00';
		}
		
		/*
		 * تاریخ پایان
		 */
		if ( ! empty( $args['date_to'] ) ) {
			$where[]  = 'a.created_at <= %s';
			$params[] = $args['date_to'] . ' 23:59:59';
		}
		
		$join_sql  = $joins ? implode( ' ', $joins ) : '';
		$where_sql = $where ? 'WHERE ' . implode( ' AND ', $where ) : '';
		
		$allowed_orderby = [
			'id',
			'created_at',
			'total_payable',
			'status',
		];
		
		$orderby = in_array(
			$args['orderby'],
			$allowed_orderby,
			TRUE
		)
			? $args['orderby']
			: 'created_at';
		
		$order = strtoupper( $args['order'] ) === 'ASC'
			? 'ASC'
			: 'DESC';
		
		/*
		 * تعداد کل
		 */
		$count_sql = "
      SELECT COUNT(DISTINCT a.id)
      FROM {$this->orders} a
      {$join_sql}
      {$where_sql}
   ";
		
		if ( ! empty( $params ) ) {
			$count_sql = $this->db->prepare(
				$count_sql,
				$params
			);
		}
		
		$total = (int) $this->db->get_var( $count_sql );
		
		$total_page = (int) ceil(
			$total / $per_page
		);
		
		/*
		 * دریافت سفارشات
		 */
		$data_sql = "
      SELECT DISTINCT a.*, ($display_status_sql) AS display_status
      FROM {$this->orders} a
      {$join_sql}
      {$where_sql}
      ORDER BY a.{$orderby} {$order}
      LIMIT %d OFFSET %d
   ";
		
		$params_data = array_merge(
			$params,
			[
				$per_page,
				$offset,
			]
		);
		
		$prepared_sql = $this->db->prepare(
			$data_sql,
			$params_data
		);
		
		$rows = $this->db->get_results(
			$prepared_sql,
			ARRAY_A
		);
		
		return [
			'items'      => $rows ?: [],
			'pagination' => [
				'page'       => $page,
				'per_page'   => $per_page,
				'total'      => $total,
				'total_page' => $total_page,
			],
		];
	}
	
	/**
	 * Update order status
	 *
	 * Sample:
	 * $this->update_order_status( 15, 'registered' );
	 */
	public function update_order_status( int $order_id, string $new_status, bool $in_transaction = FALSE ): array {
        if ($order_id<=0 || !in_array($new_status,['proforma','registered','shipped','shortage','returned','canceled'],TRUE)) { return $this->fail('وضعیت یا شناسه سفارش معتبر نیست.'); }
        $guard=$this->supply_order_guard($order_id,$new_status==='registered');
        if($guard['status']!=='success') { return $guard; }
        if(!$in_transaction && !$this->supply_begin_transaction()) { return $this->fail('شروع ثبت سفارش انجام نشد.'); }
        $order=$this->db->get_row($this->db->prepare("SELECT * FROM {$this->orders} WHERE id=%d FOR UPDATE",$order_id),ARRAY_A);
        if(!$order){$this->db->query('ROLLBACK');return $this->fail('سفارش پیدا نشد.');}
        if ($new_status === 'returned') {
            $active = $this->db->get_var($this->db->prepare(
                "SELECT id FROM {$this->order_items} WHERE order_id = %d
                 AND (qty_ordered > 0 OR expected_free_qty > 0 OR shipped_paid_qty > 0 OR shipped_free_qty > 0)
                 LIMIT 1", $order_id));
            $active_error = (bool) $this->db->last_error;
            $returned = $this->db->get_var($this->db->prepare(
                "SELECT 1 FROM {$this->fulfillments} f
                 INNER JOIN {$this->fulfillment_items} fi ON fi.fulfillment_id = f.id
                 INNER JOIN {$this->inventory_log} il ON il.ref_type = 'return' AND il.ref_id = fi.id
                 WHERE f.order_id = %d LIMIT 1", $order_id));
            if ($active_error || $this->db->last_error || $active || !$returned) {
                $this->db->query('ROLLBACK');
                return $this->fail('ثبت وضعیت مرجوع کامل فقط پس از برگشت واقعی و لغو همه مقادیر سفارش مجاز است.');
            }
        }
        $old_status=$order['status'];
        if($old_status!==$new_status){
            $updated=$this->db->update($this->orders,['status'=>$new_status,'registered_at'=>($new_status==='registered'&&!$order['registered_at']?$this->now():$order['registered_at']),'updated_at'=>$this->now()],['id'=>$order_id]);
            if($updated===FALSE){$this->db->query('ROLLBACK');return $this->fail('تغییر وضعیت سفارش انجام نشد.');}
        }
        $supplies=$this->sync_order_supplies($order_id,$old_status==='proforma'&&$new_status==='registered');
        if($supplies['status']!=='success'){$this->db->query('ROLLBACK');return $supplies;}
        if(!$in_transaction && FALSE===$this->db->query('COMMIT')){$this->db->query('ROLLBACK');return $this->fail('ثبت نهایی سفارش انجام نشد.');}
        $event = NULL;
        if ($old_status !== $new_status) {
            $order['status'] = $new_status;
            $event = [$order_id, $old_status, $new_status, $order];
            if (!$in_transaction) { do_action('kph_order_status_changed', ...$event); }
        }
        // Parent fulfillment transactions publish their notification only after COMMIT.
        return $this->ok('سفارش با موفقیت بروزرسانی شد.', $in_transaction && $event ? ['status_event' => $event] : NULL);
    }

	/* ====================================================== */
	
	/** Recompute physical order status after return, cancellation or shipment. */
	private function update_order_status_after_fulfillment( int $order_id ): array {
		$rows = $this->db->get_results( $this->db->prepare(
			"SELECT qty_ordered, expected_free_qty, shipped_paid_qty, shipped_free_qty
			 FROM {$this->order_items} WHERE order_id = %d", $order_id
		), ARRAY_A );
		if ( $rows === NULL || $this->db->last_error ) { return $this->fail( 'خواندن وضعیت اقلام سفارش انجام نشد.' ); }
		$all_complete = ! empty( $rows );
		$any_shipped = FALSE;
		$any_remaining = FALSE;
		foreach ( $rows as $row ) {
			$paid = (float) $row['qty_ordered'];
			$free = (int) $row['expected_free_qty'];
			$sent_paid = (float) $row['shipped_paid_qty'];
			$sent_free = (int) $row['shipped_free_qty'];
			$any_shipped = $any_shipped || $sent_paid > 0 || $sent_free > 0;
			$any_remaining = $any_remaining || $paid > 0 || $free > 0;
			if ( $sent_paid < $paid || $sent_free < $free ) { $all_complete = FALSE; }
		}
		if ( ! $any_remaining && ! $any_shipped ) {
			// Only a recorded stock return is evidence of a *returned* order.
			$returned = (bool) $this->db->get_var( $this->db->prepare(
				"SELECT 1 FROM {$this->fulfillments} f
				 INNER JOIN {$this->fulfillment_items} fi ON fi.fulfillment_id = f.id
				 INNER JOIN {$this->inventory_log} il ON il.ref_type = 'return' AND il.ref_id = fi.id
				 WHERE f.order_id = %d LIMIT 1", $order_id
			) );
			if ( $this->db->last_error ) { return $this->fail( 'بررسی سابقه مرجوعی ناموفق بود.' ); }
			return $this->update_order_status( $order_id, $returned ? 'returned' : 'canceled', TRUE );
		}
		if ( $all_complete ) { return $this->update_order_status( $order_id, 'shipped', TRUE ); }
		if ( $any_shipped ) { return $this->update_order_status( $order_id, 'shortage', TRUE ); }
		return $this->update_order_status( $order_id, 'registered', TRUE );
	}

	private function get_order_visitor_id( array $order ): int {
		$customer_id = absint( $order['customer_id'] ?? 0 );
		$candidates  = [];
		
		$order_id = absint( $order['id'] ?? 0 );
		if ( $order_id > 0 ) {
			$candidates[] = absint( $this->get_order_meta( $order_id, 'marketer_id' ) );
		}
		
		if ( $customer_id > 0 ) {
			$candidates[] = absint( get_user_meta( $customer_id, 'customer_marketer', TRUE ) );
			$candidates[] = absint( get_user_meta( $customer_id, KPH_MARKETER_META, TRUE ) );
		}
		$candidates[] = absint( $order['created_by'] ?? 0 );
		
		foreach ( array_unique( array_filter( $candidates ) ) as $candidate ) {
			if ( nooshika_get_user_role( $candidate ) === 'visitor' ) {
				return $candidate;
			}
		}
		
		return 0;
	}
	
	private function get_product_weight_kg( int $product_id, string $unique_product_code = '' ): float {
		$weight = 0;
		if ( $unique_product_code !== '' ) {
			$weight = (float) $this->db->get_var(
				$this->db->prepare(
					"SELECT weight_per_item
					 FROM {$this->shop_conversions}
					 WHERE wc_product_id = %d AND unique_product_code = %s
					 ORDER BY id DESC LIMIT 1",
					$product_id,
					$unique_product_code
				)
			);
		}
		
		if ( $weight <= 0 && function_exists( 'wc_get_product' ) ) {
			$product = wc_get_product( $product_id );
			if ( $product && $product->get_weight() !== '' ) {
				$weight = function_exists( 'wc_get_weight' )
					? (float) wc_get_weight( (float) $product->get_weight(), 'kg' )
					: (float) $product->get_weight();
			}
		}
		
		return max( 0, $weight );
	}
	
	private function add_visitor_commission_for_fulfillment(
		int $fulfillment_id,
		array $order,
		array $order_item,
		float $paid_qty,
		float $shipped_amount
	): array {
		if ( $fulfillment_id <= 0 || $paid_qty <= 0 ) {
			return $this->ok();
		}
		
		$already_exists = (int) $this->db->get_var(
			$this->db->prepare(
				"SELECT id FROM {$this->ledger_entries}
				 WHERE entry_type = 'visitor_commission'
				   AND ref_type = 'visitor_commission'
				   AND ref_id = %d
				 LIMIT 1",
				$fulfillment_id
			)
		);
		if ( $already_exists > 0 ) {
			return $this->ok();
		}
		
		$visitor_id = $this->get_order_visitor_id( $order );
		if ( $visitor_id <= 0 ) {
			return $this->ok();
		}
		
		$product_id      = absint( $order_item['wc_product_id'] ?? 0 );
		$rules           = get_user_meta( $visitor_id, 'kph_visitor_commission_rules', TRUE );
		$rule            = is_array( $rules ) ? ( $rules[ $product_id ] ?? [] ) : [];
		$rule_product_id = $product_id;
		if ( empty( $rule ) ) {
			$parent_product_id = absint( wp_get_post_parent_id( $product_id ) );
			if ( $parent_product_id > 0 && is_array( $rules ) && ! empty( $rules[ $parent_product_id ] ) ) {
				$rule            = $rules[ $parent_product_id ];
				$rule_product_id = $parent_product_id;
			}
		}
		$type  = sanitize_key( $rule['type'] ?? '' );
		$value = max( 0, (float) ( $rule['value'] ?? 0 ) );
		
		if ( ! in_array( $type, [ 'percent', 'per_kg' ], TRUE ) || $value <= 0 ) {
			return $this->ok();
		}
		
		$weight_per_item = 0;
		$total_weight    = 0;
		if ( $type === 'percent' ) {
			$commission_amount = round( max( 0, $shipped_amount ) * $value / 100 );
		} else {
			$weight_per_item = self::is_bulk_order_product($product_id) ? 1 : $this->get_product_weight_kg(
				$product_id,
				(string) ( $order_item['unique_product_code'] ?? '' )
			);
			if ( $weight_per_item <= 0 ) {
				return $this->fail( 'وزن محصول «' . get_the_title( $product_id ) . '» برای محاسبه پورسانت کیلویی ثبت نشده است.' );
			}
			$total_weight      = $weight_per_item * $paid_qty;
			$commission_amount = round( $total_weight * $value );
		}
		
		if ( $commission_amount <= 0 ) {
			return $this->ok();
		}
		
		return $this->add_ledger_entry( [
			'user_id'    => $visitor_id,
			'entry_type' => 'visitor_commission',
			'type'       => 'credit',
			'amount'     => $commission_amount,
			'ref_type'   => 'visitor_commission',
			'ref_id'     => $fulfillment_id,
			'posted_at'  => current_time( 'mysql' ),
			'note'       => 'پورسانت ارسال محصول «' . get_the_title( $product_id ) . '» از سفارش #' . absint( $order['id'] ?? 0 ),
			'meta'       => [
				'order_id'           => absint( $order['id'] ?? 0 ),
				'order_item_id'      => absint( $order_item['id'] ?? 0 ),
				'product_id'         => $product_id,
				'rule_product_id'    => $rule_product_id,
				'commission_type'    => $type,
				'commission_value'   => $value,
				'commission_qty'     => $paid_qty,
				'shipped_amount'     => $shipped_amount,
				'weight_per_item_kg' => $weight_per_item,
				'total_weight_kg'    => $total_weight,
				'creator_id'         => get_current_user_id(),
			],
		] );
	}
	
	private function reverse_visitor_commission_for_fulfillment(
		int $fulfillment_id,
		float $canceled_paid_qty,
		float $current_paid_qty
	): array {
		if ( $fulfillment_id <= 0 || $canceled_paid_qty <= 0 ) {
			return $this->ok();
		}
		
		$commission = $this->db->get_row(
			$this->db->prepare(
				"SELECT * FROM {$this->ledger_entries}
				 WHERE entry_type = 'visitor_commission'
				   AND ref_type = 'visitor_commission'
				   AND ref_id = %d
				 LIMIT 1",
				$fulfillment_id
			),
			ARRAY_A
		);
		if ( ! $commission ) {
			return $this->ok();
		}
		
		$original_amount = (float) $commission['amount'];
		$original_qty    = (float)$this->get_ledger_entry_meta( (int) $commission['id'], 'commission_qty' );
		$reversed        = (float) $this->db->get_var(
			$this->db->prepare(
				"SELECT COALESCE(SUM(amount), 0) FROM {$this->ledger_entries}
				 WHERE user_id = %d
				   AND entry_type = 'visitor_commission_reversal'
				   AND ref_type = 'visitor_commission_reversal'
				   AND ref_id = %d",
				(int) $commission['user_id'],
				$fulfillment_id
			)
		);
		$outstanding     = max( 0, $original_amount - $reversed );
		if ( $outstanding <= 0 || $original_qty <= 0 ) {
			return $this->ok();
		}
		
		$reversal_amount = $canceled_paid_qty >= $current_paid_qty
			? $outstanding
			: min( $outstanding, round( $original_amount * $canceled_paid_qty / $original_qty ) );
		if ( $reversal_amount <= 0 ) {
			return $this->ok();
		}
		
		return $this->add_ledger_entry( [
			'user_id'    => (int) $commission['user_id'],
			'entry_type' => 'visitor_commission_reversal',
			'type'       => 'debit',
			'amount'     => $reversal_amount,
			'ref_type'   => 'visitor_commission_reversal',
			'ref_id'     => $fulfillment_id,
			'posted_at'  => current_time( 'mysql' ),
			'note'       => 'برگشت پورسانت بابت لغو بخشی از ارسال #' . $fulfillment_id,
			'meta'       => [
				'original_commission_entry_id' => (int) $commission['id'],
				'canceled_paid_qty'            => $canceled_paid_qty,
				'creator_id'                   => get_current_user_id(),
			],
		] );
	}
	
	/* ====================================================== */
	/** A target is absolute. A retry must never subtract the returned units a second time. */
	public function clear_order_item_qty( int $order_item_id, $qty, $free_qty, $expected_ordered = null ): array {
		$set_target = $expected_ordered !== null;
		$qty = $this->order_quantity( $qty );
		$free_qty = $this->order_quantity( $free_qty );
		$expected = $this->order_quantity( $expected_ordered );
		if ( $order_item_id <= 0 || $qty === null || $free_qty === null || $free_qty != floor( $free_qty )
			|| ( $set_target && $expected === null ) ) {
			return $this->fail( 'مقدار سفارش معتبر نیست.' );
		}
		if ( $qty != floor( $qty ) && ! $this->fractional_order_schema_ready() ) {
			return $this->fail( 'ستون‌های وزن پایگاه داده آماده نیستند.' );
		}

		if ( $set_target ) {
			try {
				$pending = $this->unprepared_workflow_tables( [ $this->orders, $this->order_items, $this->db_prefix . 'orders_meta' ] );
				if ( $pending ) return $this->fail( 'مدیر از ابزار آماده‌سازی جدول‌ها این موارد را به InnoDB تبدیل کند: ' . implode( '، ', $pending ) );
			} catch ( Throwable $e ) {
				return $this->fail( $e->getMessage() );
			}
		}
		$order_id = (int) $this->db->get_var( $this->db->prepare(
			"SELECT order_id FROM {$this->order_items} WHERE id=%d", $order_item_id
		) );
		$guard = $this->supply_order_guard( $order_id );
		if ( $guard['status'] !== 'success' ) return $guard;
		if ( ! $this->supply_begin_transaction() ) return $this->fail( 'شروع تراکنش انجام نشد.' );
		try {
			$status = $this->db->get_var( $this->db->prepare(
				"SELECT status FROM {$this->orders} WHERE id=%d FOR UPDATE", $order_id
			) );
			if ( ! in_array( $status, [ 'registered', 'shortage', 'shipped' ], true ) ) {
				throw new RuntimeException( 'اصلاح تعداد در وضعیت فعلی سفارش مجاز نیست.' );
			}
			$item = $this->db->get_row( $this->db->prepare(
				"SELECT * FROM {$this->order_items} WHERE id=%d AND order_id=%d FOR UPDATE", $order_item_id, $order_id
			), ARRAY_A );
			if ( ! $item ) throw new RuntimeException( 'قلم سفارش پیدا نشد.' );
			$ordered = (float) $item['qty_ordered'];
			$sent = (float) $item['shipped_paid_qty'];
			$gifts = (int) $item['expected_free_qty'];
			$sent_gifts = (int) $item['shipped_free_qty'];
			$target = $set_target ? $qty : round( $ordered - $qty, 5 );
			$target_gifts = $gifts - (int) $free_qty;
			if ( $set_target ) {
				if ( $target !== $ordered && $expected !== $ordered ) {
					throw new RuntimeException( 'تعداد سفارش قبلاً تغییر کرده است. فهرست را تازه کنید.' );
				}
				// Preserve shipped gifts and apply the original promotion to the reduced quantity.
				$buy = (int) $item['goods_buy_x'];
				$reward = (int) $item['goods_free_y'];
				$target_gifts = $target === $sent ? $sent_gifts : $gifts;
				if ( $target !== $ordered && $buy > 0 && $reward > 0 ) {
					$entitled = (int) floor( $target / $buy ) * $reward;
					$target_gifts = max( $sent_gifts, min( $target_gifts, $entitled ) );
				}
			}
			if ( $target < $sent || $target > $ordered || $target_gifts < $sent_gifts || $target_gifts > $gifts ) {
				throw new RuntimeException( 'تعداد نهایی باید بین تعداد ارسال‌شده و تعداد فعلی سفارش باشد.' );
			}
			if ( $target != floor( $target ) && ! self::is_bulk_order_product( (int) $item['wc_product_id'] ) ) {
				throw new RuntimeException( 'تعداد محصول بسته‌بندی‌شده باید عدد صحیح باشد.' );
			}
			if ( $ordered === $target && $gifts === $target_gifts ) {
				$this->db->query( 'ROLLBACK' );
				return $this->ok( 'تعداد سفارش از قبل همین مقدار است.' );
			}
			// Retain the net unit price used by the original shipments, including negotiated discounts.
			$amount = $ordered > 0 ? round( (float) $item['final_amount'] * ($target / $ordered), 2 ) : 0;
			$written = $this->db->update( $this->order_items, [
				'qty_ordered' => $target, 'expected_free_qty' => $target_gifts, 'final_amount' => $amount,
				'discount_cash_amount' => round( (float) $item['base_price'] * $target - $amount, 2 ),
				'updated_at' => current_time( 'mysql' ),
			], [ 'id' => $order_item_id ] );
			if ( $written === false ) throw new RuntimeException( 'ذخیره تعداد سفارش انجام نشد.' );
			$result = $this->recalculate_order_totals( $order_id );
			if ( $result['status'] !== 'success' ) throw new RuntimeException( $result['message'] );
			$result = $this->update_order_meta( $order_id, 'item_canceled', 'yes' );
			if ( $result['status'] !== 'success' ) throw new RuntimeException( $result['message'] );
			$result = $this->update_order_status_after_fulfillment( $order_id );
			if ( $result['status'] !== 'success' ) throw new RuntimeException( $result['message'] );
			if ( false === $this->db->query( 'COMMIT' ) ) throw new RuntimeException( 'ثبت نهایی سفارش انجام نشد.' );
		} catch ( Throwable $e ) {
			$this->db->query( 'ROLLBACK' );
			return $this->fail( $e->getMessage() );
		}
		if ( ! empty( $result['data']['status_event'] ) ) do_action( 'kph_order_status_changed', ...$result['data']['status_event'] );
		return $this->ok( 'تعداد سفارش اصلاح شد.' );
	}

	public function cancel_sended_product_qty( $item_id, $qty = 0, $free_qty = 0 ): array {
        $qty = $this->order_quantity($qty === '' ? 0 : $qty);
        if ($qty === null) return $this->fail('مقدار سفارش معتبر نیست.');
        if ($qty != floor($qty) && !$this->fractional_order_schema_ready()) return $this->fail('ستون‌های وزن پایگاه داده آماده نیستند.');

		$order_item_id = absint( $item_id );
		$free_qty      = absint( $free_qty );
		
		if ( $order_item_id <= 0 ) {
			return $this->fail( 'شناسه آیتم سفارش معتبر نیست.' );
		}
		
		if ( $qty <= 0 && $free_qty <= 0 ) {
			return $this->fail( 'حداقل تعداد کالای پولی یا هدیه برای برگشت باید بیشتر از صفر باشد.' );
		}
		
		$parent_order=(int)$this->db->get_var($this->db->prepare("SELECT order_id FROM {$this->order_items} WHERE id=%d",$order_item_id));
        $guard=$this->supply_order_guard($parent_order);if($guard['status']!=='success')return $guard;
        if(!$this->supply_begin_transaction())return $this->fail('شروع تراکنش انجام نشد.');
        $this->db->get_row($this->db->prepare("SELECT id FROM {$this->orders} WHERE id=%d FOR UPDATE",$parent_order));
        
		
		$order_item = $this->db->get_row(
			$this->db->prepare(
				"SELECT
				oi.*,
				o.customer_id,
				o.status AS order_status
			 FROM {$this->order_items} oi
			 INNER JOIN {$this->orders} o ON o.id = oi.order_id
			 WHERE oi.id = %d
			 LIMIT 1
			 FOR UPDATE",
				$order_item_id
			),
			ARRAY_A
		);
		
		if ( ! $order_item ) {
			$this->db->query( 'ROLLBACK' );
			
			return $this->fail( 'آیتم سفارش یافت نشد.' );
		}
        if ($qty != floor($qty) && !self::is_bulk_order_product((int)$order_item['wc_product_id'])) {
            $this->db->query('ROLLBACK');
            return $this->fail('تعداد محصول بسته‌بندی‌شده باید عدد صحیح باشد.');
        }

		
		$shipped_paid = (float) $order_item['shipped_paid_qty'];
		$shipped_free = (int) $order_item['shipped_free_qty'];
		
		if ( $qty > $shipped_paid ) {
			$this->db->query( 'ROLLBACK' );
			
			return $this->fail( 'تعداد پولی برگشتی بیشتر از تعداد ارسال‌شده است.' );
		}
		
		if ( $free_qty > $shipped_free ) {
			$this->db->query( 'ROLLBACK' );
			
			return $this->fail( 'تعداد رایگان برگشتی بیشتر از تعداد ارسال‌شده است.' );
		}
		
		$fulfillment_items = $this->db->get_results(
			$this->db->prepare(
				"SELECT
				fi.*,
				f.order_id,
				f.status AS fulfillment_status
			 FROM {$this->fulfillment_items} fi
			 INNER JOIN {$this->fulfillments} f ON f.id = fi.fulfillment_id
			 WHERE fi.order_item_id = %d
			   AND (fi.shipped_paid_qty > 0 OR fi.shipped_free_qty > 0)
			 ORDER BY fi.id DESC
			 FOR UPDATE",
				$order_item_id
			),
			ARRAY_A
		);
		
		if ( empty( $fulfillment_items ) ) {
			$this->db->query( 'ROLLBACK' );
			
			return $this->fail( 'ارسالی برای این آیتم پیدا نشد.' );
		}
		
		$remaining_paid = $qty;
		$remaining_free = $free_qty;
		$returned_qty   = 0;
		$returned_cost  = 0;
		
		$base_total_qty  = (float) $order_item['qty_ordered'];
		$sale_unit_price = $base_total_qty > 0
			? ( (float) $order_item['final_amount'] / $base_total_qty )
			: (float) $order_item['base_price'];
		
		foreach ( $fulfillment_items as $fulfillment_item ) {
			if ( $remaining_paid <= 0 && $remaining_free <= 0 ) {
				break;
			}
			
			$cancel_paid = min( $remaining_paid, (float) $fulfillment_item['shipped_paid_qty'] );
			$cancel_free = min( $remaining_free, (int) $fulfillment_item['shipped_free_qty'] );
			
			if ( $cancel_paid <= 0 && $cancel_free <= 0 ) {
				continue;
			}
			
			$cancel_total = $cancel_paid + $cancel_free;
			$inventory_id = absint( $fulfillment_item['inventory_id'] );
			
			// A historical fulfillment may point to an inventory row that was
			// removed/recreated after shipping. Resolve it from shipment evidence,
			// never by choosing an unrelated batch of the same product.
			$inventory_resolution = $this->resolve_inventory_for_fulfillment_return( $fulfillment_item, $order_item );
			if ( ( $inventory_resolution['status'] ?? '' ) !== 'success' ) {
				$this->db->query( 'ROLLBACK' );
				return $inventory_resolution;
			}
			$inventory = $inventory_resolution['data']['inventory'];
			$recovered_inventory = ! empty( $inventory_resolution['data']['recovered'] );
			
			$unit_cost        = (float) $fulfillment_item['unit_cost'];
			$return_line_cost = $unit_cost * $cancel_total;
			
			$movement = $this->add_inventory_movement( [
				'unique_product_code' => $inventory['unique_product_code'],
				'wc_product_id'       => (int) $inventory['wc_product_id'],
				'change_qty'          => $cancel_total,
				'unit_cost'           => $unit_cost,
				'total_cost'          => $return_line_cost,
				'ref_type'            => 'return',
				'ref_id'              => (int) $fulfillment_item['id'],
				'note'                => 'برگشت موجودی بابت لغو ارسال آیتم سفارش #' . $order_item_id
					. ( $recovered_inventory ? ' (بازیابی ارتباط موجودی ارسال قدیمی)' : '' ),
			] );
			
			if ( ( $movement['status'] ?? '' ) !== 'success' ) {
				$this->db->query( 'ROLLBACK' );
				
				return $movement;
			}
			
			$apply = $this->apply_inventory_change( [
				'unique_product_code' => $inventory['unique_product_code'],
				'wc_product_id'       => (int) $inventory['wc_product_id'],
				'change_qty'          => $cancel_total,
				'total_cost'          => $return_line_cost,
			] );
			
			if ( ( $apply['status'] ?? '' ) !== 'success' ) {
				$this->db->query( 'ROLLBACK' );
				
				return $apply;
			}

			// Record the repaired relationship under the *same transaction*,
			// including inventory rows recreated by apply_inventory_change().
			$resolved_inventory_id = absint( $apply['data']['inventory_id'] ?? 0 );
			if ( $resolved_inventory_id <= 0 ) {
				$this->db->query( 'ROLLBACK' );
				return $this->fail( 'شناسه موجودی برگشتی قابل تایید نیست.' );
			}
			if ( $resolved_inventory_id !== $inventory_id ) {
				$link_updated = $this->db->update(
					$this->fulfillment_items,
					[ 'inventory_id' => $resolved_inventory_id ],
					[ 'id' => (int) $fulfillment_item['id'] ],
					[ '%d' ],
					[ '%d' ]
				);
				if ( $link_updated === FALSE ) {
					$this->db->query( 'ROLLBACK' );
					return $this->fail( 'ترمیم ارتباط موجودی با ارسال ناموفق بود.' );
				}
			}
			
			$new_paid       = (float) $fulfillment_item['shipped_paid_qty'] - $cancel_paid;
			$new_free       = (int) $fulfillment_item['shipped_free_qty'] - $cancel_free;
			$new_total_cost = $unit_cost * ( $new_paid + $new_free );
			
			$updated_fulfillment_item = $this->db->update(
				$this->fulfillment_items,
				[
					'shipped_paid_qty' => $new_paid,
					'shipped_free_qty' => $new_free,
					'total_cost'       => $new_total_cost,
				],
				[ 'id' => (int) $fulfillment_item['id'] ],
				[ '%f', '%d', '%f' ],
				[ '%d' ]
			);
			
			if ( $updated_fulfillment_item === FALSE ) {
				$this->db->query( 'ROLLBACK' );
				
				return $this->fail( 'بروزرسانی آیتم ارسال انجام نشد.' );
			}
			
			$active_items_count = (int) $this->db->get_var(
				$this->db->prepare(
					"SELECT COUNT(*)
				 FROM {$this->fulfillment_items}
				 WHERE fulfillment_id = %d
				   AND (shipped_paid_qty > 0 OR shipped_free_qty > 0)",
					(int) $fulfillment_item['fulfillment_id']
				)
			);
			
			$fulfillment_status = $active_items_count > 0
				? $fulfillment_item['fulfillment_status']
				: 'canceled';
			
			$updated_fulfillment = $this->db->update(
				$this->fulfillments,
				[
					'status'     => $fulfillment_status,
					'updated_at' => current_time( 'mysql' ),
				],
				[ 'id' => (int) $fulfillment_item['fulfillment_id'] ],
				[ '%s', '%s' ],
				[ '%d' ]
			);
			
			if ( $updated_fulfillment === FALSE ) {
				$this->db->query( 'ROLLBACK' );
				
				return $this->fail( 'بروزرسانی وضعیت ارسال انجام نشد.' );
			}
			
			if ( $cancel_paid > 0 ) {
				$ledger_amount = $cancel_paid * $sale_unit_price;
				
				if ( $ledger_amount > 0 ) {
					$ledger_res = $this->add_ledger_entry( [
						'user_id'    => (int) $order_item['customer_id'],
						'entry_type' => 'customer_order_return',
						'type'       => 'credit',
						'amount'     => $ledger_amount,
						'ref_type'   => 'fulfillment',
						'ref_id'     => (int) $fulfillment_item['fulfillment_id'],
						'note'       => 'اصلاح بدهی مشتری بابت لغو ارسال آیتم سفارش #' . $order_item_id,
						'meta'       => [
							'order_id'            => (int) $order_item['order_id'],
							'order_item_id'       => $order_item_id,
							'fulfillment_item_id' => (int) $fulfillment_item['id'],
							'cancel_paid_qty'     => $cancel_paid,
							'cancel_free_qty'     => $cancel_free,
							'creator_id'          => get_current_user_id(),
						],
					] );
					
					if ( ( $ledger_res['status'] ?? '' ) !== 'success' ) {
						$this->db->query( 'ROLLBACK' );
						
						return $ledger_res;
					}
				}
				
				$commission_reversal = $this->reverse_visitor_commission_for_fulfillment(
					(int) $fulfillment_item['fulfillment_id'],
					$cancel_paid,
					(float) $fulfillment_item['shipped_paid_qty']
				);
				if ( ( $commission_reversal['status'] ?? '' ) !== 'success' ) {
					$this->db->query( 'ROLLBACK' );
					
					return $commission_reversal;
				}
			}
			
			$remaining_paid = round($remaining_paid - $cancel_paid, 5);
			$remaining_free -= $cancel_free;
			$returned_qty   += $cancel_total;
			$returned_cost  += $return_line_cost;
		}
		
		if ( $remaining_paid > 0 || $remaining_free > 0 ) {
			$this->db->query( 'ROLLBACK' );
			
			return $this->fail( 'برای این مقدار، ارسال ثبت‌شده کافی پیدا نشد.' );
		}
		
		$updated_order_item = $this->db->query(
			$this->db->prepare(
				"UPDATE {$this->order_items}
			 SET shipped_paid_qty = GREATEST(shipped_paid_qty - %f, 0),
			     shipped_free_qty = GREATEST(shipped_free_qty - %d, 0),
			     cogs_total = GREATEST(cogs_total - %f, 0),
			     updated_at = %s
			 WHERE id = %d",
				$qty,
				$free_qty,
				$returned_cost,
				current_time( 'mysql' ),
				$order_item_id
			)
		);
		
		if ( $updated_order_item === FALSE ) {
			$this->db->query( 'ROLLBACK' );
			
			return $this->fail( 'بروزرسانی آیتم سفارش انجام نشد.' );
		}
		
		$status_result = $this->update_order_status_after_fulfillment( (int) $order_item['order_id'] );
		if ( $status_result['status'] !== 'success' ) {
			$this->db->query( 'ROLLBACK' );
			return $status_result;
		}
		$new_status = (string) ( $status_result['data']['status_event'][2] ?? $order_item['order_status'] );

        if(FALSE===$this->db->query('COMMIT')){$this->db->query('ROLLBACK');return $this->fail('ثبت نهایی سفارش انجام نشد.');}
		
		if ( ! empty( $status_result['data']['status_event'] ) ) {
			do_action( 'kph_order_status_changed', ...$status_result['data']['status_event'] );
		}

		do_action( 'kph_fulfillment_qty_canceled', $order_item_id, $qty, $free_qty, [
			'order_id'      => (int) $order_item['order_id'],
			'returned_qty'  => $returned_qty,
			'returned_cost' => $returned_cost,
		] );
		
		return $this->ok( 'مقدار ارسال‌شده با موفقیت برگشت خورد.', [
			'order_id'      => (int) $order_item['order_id'],
			'order_item_id' => $order_item_id,
			'paid'          => $qty,
			'free'          => $free_qty,
			'returned_qty'  => $returned_qty,
			'returned_cost' => $returned_cost,
			'order_status'  => $new_status,
		] );
	}
	
	public function add_fulfillment( int $order_item_id, $total_qty, int $inventory_id = 0, $args = [] ): array {
        $total_qty = $this->order_quantity($total_qty);
        if ($total_qty === null) return $this->fail('مقدار سفارش معتبر نیست.');
        if ($total_qty != floor($total_qty) && !$this->fractional_order_schema_ready()) return $this->fail('ستون‌های وزن پایگاه داده آماده نیستند.');

		if ( $order_item_id <= 0 || $total_qty <= 0 ) {
			$this->db->query('ROLLBACK');return $this->fail( 'ورودی نامعتبر است.' );
		}
		
		$parent_order=(int)$this->db->get_var($this->db->prepare("SELECT order_id FROM {$this->order_items} WHERE id=%d",$order_item_id));
        $guard=$this->supply_order_guard($parent_order);if($guard['status']!=='success')return $guard;
        if(!$this->supply_begin_transaction())return $this->fail('شروع تراکنش انجام نشد.');
        $this->db->get_row($this->db->prepare("SELECT id FROM {$this->orders} WHERE id=%d FOR UPDATE",$parent_order));
        $order_item = $this->db->get_row(
			$this->db->prepare(
				"SELECT * FROM {$this->order_items} WHERE id = %d FOR UPDATE",
				$order_item_id
			),
			ARRAY_A
		);
		
		if ( ! $order_item ) {
			$this->db->query('ROLLBACK');return $this->fail( 'آیتم سفارش یافت نشد.' );
		}
        if ($total_qty != floor($total_qty) && !self::is_bulk_order_product((int)$order_item['wc_product_id'])) {
            $this->db->query('ROLLBACK');
            return $this->fail('تعداد محصول بسته‌بندی‌شده باید عدد صحیح باشد.');
        }

		
		$buy_x  = (int) $order_item['goods_buy_x'];
		$free_y = (int) $order_item['goods_free_y'];
		
		$qty_ordered = (float) $order_item['qty_ordered'];
		$line_total  = (float) $order_item['final_amount'];
		
		$ledger_unit_price = $qty_ordered > 0
			? $line_total / $qty_ordered
			: 0;
		
		$order_id = (int) $order_item['order_id'];
		
		$shipped_paid_before = (float) $order_item['shipped_paid_qty'];
		$shipped_free_before = (int) $order_item['shipped_free_qty'];
		
		$qty_paid = 0;
		$qty_free = 0;
		
		/* ===============================
		   🔹 اگر تخفیف کالایی ندارد
		================================ */
		if ( $buy_x <= 0 || $free_y <= 0 ) {
			$qty_paid = $total_qty;
			$qty_free = 0;
		} else {
			// 🔹 ابتدا فرض می‌کنیم همه پولی است
			$paid_after = $shipped_paid_before + $total_qty;
			
			// 🔹 تعداد هدیه‌ای که باید تا این لحظه داده می‌شد
			$expected_free_after =
				(int) floor( round($paid_after, 5) / $buy_x ) * $free_y;
			
			// 🔹 هدیه‌ای که الان باید اضافه شود
			$qty_free =
				$expected_free_after - $shipped_free_before;
			
			if ( $qty_free < 0 ) {
				$qty_free = 0;
			}
			
			$qty_paid = $total_qty;
		}
		
		/* ===============================
		   🔹 چک سقف سفارش
		================================ */
		
		$paid_remaining =
			round((float)$order_item['qty_ordered'] - $shipped_paid_before, 5);
		
		$free_remaining =
			(int) $order_item['expected_free_qty'] - $shipped_free_before;
		
		if ( $qty_paid > $paid_remaining ) {
			$this->db->query('ROLLBACK');return $this->fail( 'مقدار پولی بیشتر از باقیمانده سفارش است.' );
		}
		
		if ( $qty_free > $free_remaining ) {
			$this->db->query('ROLLBACK');return $this->fail( 'مقدار رایگان بیشتر از باقیمانده سفارش است.' );
		}
		
		$total_send    = $qty_paid + $qty_free;
		$ledger_amount = $qty_paid * $ledger_unit_price;
		
		$order = $this->db->get_row(
			$this->db->prepare(
				"SELECT * FROM {$this->orders} WHERE id = %d",
				$order_id
			),
			ARRAY_A
		);
		
		
		$inventory_id = absint( $inventory_id );
		
		if ( $inventory_id <= 0 ) {
			$inventory_id = absint( $order_item['inventory_id'] );
		}
		
		if ( $inventory_id <= 0 ) {
			$this->db->query('ROLLBACK');return $this->fail( 'موجودی ارسال را انتخاب کنید.' );
		}
		
		
		
		$inventory = $this->lock_inventory_row( $inventory_id );
		
		if ( ! $inventory ) {
			$this->db->query('ROLLBACK');return $this->fail( 'موجودی یافت نشد.' );
		}
		
		if ( (int) $inventory['wc_product_id'] !== (int) $order_item['wc_product_id'] ) {
			$this->db->query('ROLLBACK');return $this->fail( 'موجودی انتخاب‌شده مربوط به این محصول نیست.' );
		}
		
		if ( (float) $inventory['qty_available'] < $total_send ) {
			$this->db->query('ROLLBACK');return $this->fail( 'موجودی کافی نیست.' );
		}
		$unit_cost  = (float) $inventory['avg_unit_cost'];
		$total_cost = $unit_cost * $total_send;
		
		/* ===============================
		   🔹 ایجاد fulfillment
		================================ */
		
		$shipment_write_result = $this->db->insert(
			$this->fulfillments,
			[
				'order_id'   => $order_item['order_id'],
				'status'     => 'draft',
				'shipped_by' => $args['shipping_method'],
				'created_at' => current_time( 'mysql' ),
				'updated_at' => current_time( 'mysql' ),
			]
		);
        if($shipment_write_result===FALSE){$this->db->query('ROLLBACK');return $this->fail('ذخیره تغییرات سفارش انجام نشد.');}
		
		$fid = (int) $this->db->insert_id;
		$shipment_write_result = $this->db->insert(
			$this->fulfillment_items,
			[
				'fulfillment_id'   => $fid,
				'order_item_id'    => $order_item_id,
				'inventory_id'     => $inventory_id,
				'shipped_paid_qty' => $qty_paid,
				'shipped_free_qty' => $qty_free,
				'unit_cost'        => $unit_cost,
				'total_cost'       => $total_cost,
				'created_at'       => current_time( 'mysql' ),
			]
		);
        if($shipment_write_result===FALSE){$this->db->query('ROLLBACK');return $this->fail('ذخیره تغییرات سفارش انجام نشد.');}
		$fulfillment_item_id = (int) $this->db->insert_id;
		if ( $fulfillment_item_id <= 0 ) {
			$this->db->query('ROLLBACK');return $this->fail( 'ثبت آیتم ارسال انجام نشد.' );
		}
		
		$order_item['id']                  = $order_item_id;
		$order_item['unique_product_code'] = (string) $inventory['unique_product_code'];
		$commission_res                    = $this->add_visitor_commission_for_fulfillment(
			$fid,
			$order,
			$order_item,
			$qty_paid,
			$ledger_amount
		);
		if ( ( $commission_res['status'] ?? '' ) !== 'success' ) {
			$this->db->query( 'ROLLBACK' );
			
			return $commission_res;
		}
		
		$ledger_res = $this->add_ledger_entry( [
			'user_id'    => (int) $order['customer_id'],
			'entry_type' => 'customer_order',
			'type'       => 'debit',
			'amount'     => (float) $ledger_amount,
			'ref_type'   => 'fulfillment',
			'ref_id'     => $fid,
			'note'       => 'ثبت بدهی مشتری بابت ارسال آیتم های سفارش #' . $order_id,
			'meta'       => [
				'order_id'   => $order_id,
				'creator_id' => get_current_user_id(),
			],
		] );
		if ( $ledger_res['status'] !== 'success' ) {
			$this->db->query( 'ROLLBACK' );
			
			return $ledger_res;
		}
		/* ===============================
		   🔹 کاهش موجودی
		================================ */
		
		$res = $this->register_inventory_sale(
			$inventory,
			$fid,
			$total_send,
			$unit_cost,
			$total_cost
		);
		
		if ( $res['status'] !== 'success' ) {
			$this->db->query( 'ROLLBACK' );
			
			return $res;
		}
		
		/* ===============================
		   🔹 آپدیت آیتم سفارش
		================================ */
		
		$order_write_result = $this->db->query(
			$this->db->prepare(
				"UPDATE {$this->order_items}
			 SET shipped_paid_qty = shipped_paid_qty + %f,
			     shipped_free_qty = shipped_free_qty + %d,
			     cogs_total = cogs_total + %f
			 WHERE id = %d",
				$qty_paid,
				$qty_free,
				$total_cost,
				$order_item_id
			)
		);
        if($order_write_result===FALSE){$this->db->query('ROLLBACK');return $this->fail('ذخیره تغییرات سفارش انجام نشد.');}
		
		$status_result = $this->update_order_status_after_fulfillment((int)$order_item['order_id']);
        if($status_result['status']!=='success'){$this->db->query('ROLLBACK');return $status_result;}
		//		do_action( 'kph_new_fulfillment_added', $order_item['order_id'], $args['shipping_method'] );
		$order_meta_result = $this->update_order_meta( (int) $order_item['order_id'], 'item_canceled', 'no' );
        if($order_meta_result['status']!=='success'){$this->db->query('ROLLBACK');return $order_meta_result;}
		
		if(FALSE===$this->db->query('COMMIT')){$this->db->query('ROLLBACK');return $this->fail('ثبت نهایی سفارش انجام نشد.');}
        if (!empty($status_result['data']['status_event'])) { do_action('kph_order_status_changed', ...$status_result['data']['status_event']); }
		
		return $this->ok( 'ارسال ثبت شد.', [
			'fulfillment_id' => $fid,
			'paid'           => $qty_paid,
			'free'           => $qty_free,
		] );
	}
	

	/**
	 * Resolve the actual inventory identity for a return of a historical shipment.
	 * Called under the order/fulfillment row locks and within the return transaction.
	 *
	 * A missing inventory_balance row is not proof that the product was never
	 * shipped. Sales history is the first source of identity. When even the old
	 * product code is unavailable, a dedicated legacy-return lot is used for
	 * this exact fulfillment_item instead of merging into an arbitrary batch.
	 */
	private function resolve_inventory_for_fulfillment_return( array $fulfillment_item, array $order_item ): array {
		$product_id     = absint( $order_item['wc_product_id'] ?? 0 );
		$inventory_id   = absint( $fulfillment_item['inventory_id'] ?? 0 );
		$fulfillment_id = absint( $fulfillment_item['fulfillment_id'] ?? 0 );
		$shipment_id    = absint( $fulfillment_item['id'] ?? 0 );

		if ( $product_id <= 0 || $fulfillment_id <= 0 || $shipment_id <= 0
			|| (int) ( $fulfillment_item['order_item_id'] ?? 0 ) !== (int) ( $order_item['id'] ?? 0 )
			|| (int) ( $fulfillment_item['order_id'] ?? 0 ) !== (int) ( $order_item['order_id'] ?? 0 ) ) {
			return $this->fail( 'اطلاعات سابقه ارسال با سفارش مطابقت ندارد؛ بازگشت متوقف شد.' );
		}

		$inventory = $this->lock_inventory_row( $inventory_id );
		if ( $inventory ) {
			if ( (int) $inventory['wc_product_id'] !== $product_id ) {
				return $this->fail( 'محصول موجودی ثبت‌شده با محصول ارسال‌شده مطابقت ندارد.' );
			}
			$legacy_result = $this->ensure_legacy_inventory_code( $inventory );
			if ( ( $legacy_result['status'] ?? '' ) !== 'success' ) {
				return $legacy_result;
			}
			return $this->ok( '', [
				'inventory' => $legacy_result['data']['inventory'] ?? $inventory,
				'recovered' => FALSE,
			] );
		}
		if ( $this->db->last_error ) {
			return $this->fail( 'بررسی شناسه موجودی ارسال در پایگاه داده ناموفق بود.' );
		}

		// Inventory ID no longer exists. Only a uniquely identified sale code
		// can be mapped back to an existing batch; product ID alone is not enough.
		$sale_codes = $this->db->get_col(
			$this->db->prepare(
				"SELECT DISTINCT unique_product_code
				 FROM {$this->inventory_log}
				 WHERE ref_type = 'sale' AND ref_id = %d
				   AND wc_product_id = %d AND change_qty < 0
				   AND TRIM(COALESCE(unique_product_code, '')) <> ''",
				$fulfillment_id,
				$product_id
			)
		);
		if ( $this->db->last_error ) {
			return $this->fail( 'بررسی گردش خروج انبار برای ارسال قدیمی ناموفق بود.' );
		}
		if ( count( $sale_codes ) > 1 ) {
			return $this->fail( 'ارسال قدیمی به چند کد موجودی متفاوت مرتبط است؛ برای جلوگیری از بازگشت اشتباه، بررسی سوابق لازم است.' );
		}

		$code = $sale_codes ? (string) $sale_codes[0] : '';
		if ( trim( $code ) === '' && $inventory_id > 0
			&& $inventory_id === absint( $order_item['inventory_id'] ?? 0 ) ) {
			$code = (string) ( $order_item['unique_product_code'] ?? '' );
		}
		if ( trim( $code ) === '' ) {
			// A unique, auditable return lot for this shipped line; no batch guessed.
			$code = 'KPH-LEGACY-RETURN-FI-' . $shipment_id;
			$production_codes = $this->db_prefix . 'production_codes';
			$collision = $this->db->get_var(
				$this->db->prepare( "SELECT id FROM {$production_codes} WHERE code = %s LIMIT 1", $code )
			);
			if ( $this->db->last_error ) {
				return $this->fail( 'بررسی تداخل شناسه موجودی بازگشتی ناموفق بود.' );
			}
			if ( $collision ) {
				return $this->fail( 'شناسه بازگشت موجودی قدیمی قبلاً برای کد تولید استفاده شده است.' );
			}
			$collision = $this->db->get_var(
				$this->db->prepare( "SELECT id FROM {$this->shop_conversions} WHERE unique_product_code = %s LIMIT 1", $code )
			);
			if ( $this->db->last_error || $collision ) {
				return $this->fail( 'شناسه موجودی بازگشتی با سوابق تولید تداخل دارد.' );
			}
		}

		// Check by the UNIQUE code (not by product alone) before allowing
		// apply_inventory_change to create a missing zero-to-positive row.
		$inventory = $this->db->get_row(
			$this->db->prepare(
				"SELECT * FROM {$this->inventory_balance}
				 WHERE unique_product_code = %s LIMIT 1 FOR UPDATE",
				$code
			),
			ARRAY_A
		);
		if ( $this->db->last_error ) {
			return $this->fail( 'بازخوانی موجودی با کد ثبت‌شده ناموفق بود.' );
		}
		if ( $inventory && (int) $inventory['wc_product_id'] !== $product_id ) {
			return $this->fail( 'کد موجودی قدیمی اکنون به محصول دیگری تعلق دارد؛ برگشت نیازمند بررسی است.' );
		}
		if ( ! $inventory ) {
			$inventory = [
				'id'                  => 0,
				'wc_product_id'       => $product_id,
				'unique_product_code' => $code,
			];
		}
		return $this->ok( '', [ 'inventory' => $inventory, 'recovered' => TRUE ] );
	}

	/**
	 * Give pre-unique-code inventory rows a stable internal identity before
	 * recording a return. The synthetic code is explicitly marked as legacy;
	 * no quantity or value is changed by this migration.
	 *
	 * Must be called while the inventory row is locked and inside the caller's
	 * transaction so a failed return rolls the identity update back as well.
	 */
	private function ensure_legacy_inventory_code( array $inventory ): array {
		$raw_code = (string) ( $inventory['unique_product_code'] ?? '' );
		if ( trim( $raw_code ) !== '' ) {
			return $this->ok( '', [ 'inventory' => $inventory ] );
		}

		$inventory_id = absint( $inventory['id'] ?? 0 );
		$product_id   = absint( $inventory['wc_product_id'] ?? 0 );
		if ( $inventory_id <= 0 || $product_id <= 0 ) {
			return $this->fail( 'شناسه موجودی قدیمی برای ساخت کد داخلی معتبر نیست.' );
		}

		$blank_row_count = (int) $this->db->get_var(
			$this->db->prepare(
				"SELECT COUNT(*)
				 FROM {$this->inventory_balance}
				 WHERE wc_product_id = %d
				   AND TRIM(COALESCE(unique_product_code, '')) = ''",
				$product_id
			)
		);
		if ( $this->db->last_error ) {
			return $this->fail( 'بررسی موجودی قدیمی ناموفق بود.' );
		}
		if ( $blank_row_count !== 1 ) {
			return $this->fail( 'برای این محصول چند رکورد موجودی بدون کد یکتا وجود دارد؛ برای جلوگیری از ادغام سوابق، بررسی مدیر لازم است.' );
		}

		$production_codes = $this->db_prefix . 'production_codes';
		$legacy_code       = '';
		for ( $suffix = 0; $suffix < 100; $suffix++ ) {
			$candidate = 'KPH-LEGACY-INV-' . $inventory_id . ( $suffix ? '-' . $suffix : '' );

			$exists = $this->db->get_var(
				$this->db->prepare(
					"SELECT id FROM {$this->inventory_balance}
					 WHERE unique_product_code = %s AND id <> %d LIMIT 1",
					$candidate,
					$inventory_id
				)
			);
			if ( $this->db->last_error ) {
				return $this->fail( 'بررسی تداخل کد موجودی ناموفق بود.' );
			}
			if ( $exists ) {
				continue;
			}

			$exists = $this->db->get_var(
				$this->db->prepare(
					"SELECT id FROM {$production_codes} WHERE code = %s LIMIT 1",
					$candidate
				)
			);
			if ( $this->db->last_error ) {
				return $this->fail( 'بررسی تداخل کد تولید ناموفق بود.' );
			}
			if ( $exists ) {
				continue;
			}

			$exists = $this->db->get_var(
				$this->db->prepare(
					"SELECT id FROM {$this->order_items} WHERE unique_product_code = %s LIMIT 1",
					$candidate
				)
			);
			if ( $this->db->last_error ) {
				return $this->fail( 'بررسی سوابق سفارش برای کد داخلی ناموفق بود.' );
			}
			if ( $exists ) {
				continue;
			}

			$exists = $this->db->get_var(
				$this->db->prepare(
					"SELECT id FROM {$this->inventory_log} WHERE unique_product_code = %s LIMIT 1",
					$candidate
				)
			);
			if ( $this->db->last_error ) {
				return $this->fail( 'بررسی سوابق کد موجودی ناموفق بود.' );
			}
			if ( $exists ) {
				continue;
			}

			$exists = $this->db->get_var(
				$this->db->prepare(
					"SELECT id FROM {$this->shop_conversions} WHERE unique_product_code = %s LIMIT 1",
					$candidate
				)
			);
			if ( $this->db->last_error ) {
				return $this->fail( 'بررسی سوابق تبدیل محصول ناموفق بود.' );
			}
			if ( $exists ) {
				continue;
			}

			$legacy_code = $candidate;
			break;
		}

		if ( $legacy_code === '' ) {
			return $this->fail( 'ساخت شناسه داخلی یکتا برای موجودی قدیمی ممکن نشد.' );
		}

		$updated = $this->db->update(
			$this->inventory_balance,
			[ 'unique_product_code' => $legacy_code ],
			[ 'id' => $inventory_id ],
			[ '%s' ],
			[ '%d' ]
		);
		if ( $updated === FALSE ) {
			return $this->fail( 'ثبت شناسه داخلی موجودی قدیمی ناموفق بود.' );
		}

		// Keep historical inventory movements and linked order items under the same identity.
		$log_update = $this->db->query(
			$this->db->prepare(
				"UPDATE {$this->inventory_log}
				 SET unique_product_code = %s
				 WHERE wc_product_id = %d
				   AND TRIM(COALESCE(unique_product_code, '')) = ''",
				$legacy_code,
				$product_id
			)
		);
		if ( $log_update === FALSE ) {
			return $this->fail( 'به‌روزرسانی کد سوابق گردش انبار قدیمی ناموفق بود.' );
		}

		$order_items_update = $this->db->query(
			$this->db->prepare(
				"UPDATE {$this->order_items}
				 SET unique_product_code = %s
				 WHERE (
					inventory_id = %d
					OR id IN (
						SELECT order_item_id
						FROM {$this->fulfillment_items}
						WHERE inventory_id = %d
					)
				 )
				   AND TRIM(COALESCE(unique_product_code, '')) = ''",
				$legacy_code,
				$inventory_id,
				$inventory_id
			)
		);
		if ( $order_items_update === FALSE ) {
			return $this->fail( 'به‌روزرسانی کد اقلام سفارش قدیمی ناموفق بود.' );
		}

		$inventory['unique_product_code'] = $legacy_code;
		return $this->ok( 'برای موجودی قدیمی شناسه داخلی ایجاد شد.', [
			'inventory'          => $inventory,
			'legacy_code_created' => TRUE,
		] );
	}

	public function lock_inventory_row( int $inventory_id ): ?array {
		if ( $inventory_id <= 0 ) {
			return NULL;
		}
		$row = $this->db->get_row(
			$this->db->prepare(
				"SELECT *
			 FROM {$this->inventory_balance}
			 WHERE id = %d
			 FOR UPDATE",
				$inventory_id
			),
			ARRAY_A
		);
		
		return $row ?: NULL;
	}
	
	private function register_inventory_sale(
		array $inventory,
		int $ref_id,
		float $qty,
		float $unit_cost,
		float $total_cost
	): array {
		$res1 = $this->add_inventory_movement( [
			'unique_product_code' => $inventory['unique_product_code'],
			'wc_product_id'       => $inventory['wc_product_id'],
			'change_qty'          => - $qty,
			'unit_cost'           => $unit_cost,
			'total_cost'          => - $total_cost,
			'ref_type'            => 'sale',
			'ref_id'              => $ref_id,
			'note'                => 'خروج کالا بابت ارسال سفارش #' . $ref_id,
		] );
		
		if ( $res1['status'] !== 'success' ) {
			return $res1;
		}
		
		return $this->apply_inventory_change( [
			'unique_product_code' => $inventory['unique_product_code'],
			'wc_product_id'       => $inventory['wc_product_id'],
			'change_qty'          => - $qty,
			'total_cost'          => - $total_cost,
		] );
	}
	
	public function get_order_items( int $order_id ): array {
		if ( ! $this->visitor_can_access_order( $order_id ) ) { return []; }
		if ( $order_id <= 0 ) {
			return [];
		}
		
		$rows = $this->db->get_results(
			$this->db->prepare(
				"SELECT
				oi.*,
				(oi.qty_ordered - oi.shipped_paid_qty)   AS remaining_paid_qty,
				(oi.expected_free_qty - oi.shipped_free_qty) AS remaining_free_qty
			 FROM {$this->order_items} oi
			 WHERE oi.order_id = %d
			 ORDER BY oi.id ASC",
				$order_id
			),
			ARRAY_A
		);
		
		return $rows ?: [];
	}
	
	/**
	 * دریافت اطلاعات کامل یک سفارش به همراه آیتم‌ها
	 *
	 * نمونه استفاده:
	 * $order = $this->get_order_data( 15 );
	 */
	public function get_order_data( $order_id ): array {
		if ( ! $this->visitor_can_access_order( (int) $order_id ) ) { return []; }
		if ( $order_id <= 0 ) {
			return [];
		}
		
		$display_status_sql = $this->order_display_status_sql( 'o' );
		$order = $this->db->get_row(
			$this->db->prepare(
				"SELECT o.*, ($display_status_sql) AS display_status
			 FROM {$this->orders} o
			 WHERE o.id = %d",
				$order_id
			),
			ARRAY_A
		);
		if ( ! $order ) {
			return [];
		}
		
		$items = $this->db->get_results(
			$this->db->prepare(
				"SELECT
				oi.*,
				(oi.qty_ordered - oi.shipped_paid_qty)       AS remaining_paid_qty,
				(oi.expected_free_qty - oi.shipped_free_qty) AS remaining_free_qty
			 FROM {$this->order_items} oi
			 WHERE oi.order_id = %d
			 ORDER BY oi.id ASC",
				$order_id
			),
			ARRAY_A
		);
		
		$order['items'] = $items ?: [];
		
		return $order;
	}
	
	/**
	 * دریافت پیش‌فاکتور باز یک مشتری
	 *
	 * نمونه استفاده:
	 * $order = $this->get_customer_open_proforma( 12 );
	 */
	public function get_customer_open_proforma( int $customer_id ): array {
		$creator_scope = $this->visitor_order_scope_sql();
		if ( $customer_id <= 0 ) {
			return [];
		}
		
		$order_id = (int) $this->db->get_var(
			$this->db->prepare(
				"SELECT id
			 FROM {$this->orders}
			 WHERE customer_id = %d
			   AND status = 'proforma' {$creator_scope}
			 ORDER BY id DESC
			 LIMIT 1",
				$customer_id
			)
		);
		
		if ( $order_id <= 0 ) {
			return [];
		}
		
		return $this->get_order_data( $order_id );
	}
	
	/**
	 * بروزرسانی وضعیت ارسال (Fulfillment)
	 *
	 * نمونه استفاده:
	 * $this->update_fulfillment_status( 25, 'canceled' );
	 */
	public function update_fulfillment_status( int $fulfillment_id, string $new_status ): array {
		$allowed = [ 'draft', 'posted', 'canceled' ];
		
		if ( $fulfillment_id <= 0 ) {
			return $this->fail( 'شناسه بسته نامعتبر است.' );
		}
		
		if ( ! in_array( $new_status, $allowed, TRUE ) ) {
			return $this->fail( 'وضعیت ارسال نامعتبر است.' );
		}
		
		$fulfillment = $this->db->get_row(
			$this->db->prepare(
				"SELECT * FROM {$this->fulfillments} WHERE id = %d",
				$fulfillment_id
			),
			ARRAY_A
		);
		
		if ( ! $fulfillment ) {
			return $this->fail( 'بسته ارسالی یافت نشد.' );
		}
		
		$old_status = $fulfillment['status'];
		
		if ( $old_status === $new_status ) {
			return $this->ok( 'تغییری در وضعیت ایجاد نشد.' );
		}
		
		// اگر قبلاً ثبت شده باشد، اجازه تغییر نمی‌دهیم
		if ( $old_status === 'posted' ) {
			return $this->fail( 'امکان تغییر وضعیت آیتم ارسال شده وجود ندارد.' );
		}
		
		$data = [
			'status'     => $new_status,
			'updated_at' => current_time( 'mysql' ),
		];
		
		if ( $new_status === 'posted' ) {
			$data['shipped_by'] = get_current_user_id();
			$data['shipped_at'] = current_time( 'mysql' );
		}
		
		$updated = $this->db->update(
			$this->fulfillments,
			$data,
			[ 'id' => $fulfillment_id ]
		);
		
		if ( $updated === FALSE ) {
			return $this->fail( 'بروزرسانی وضعیت ارسال انجام نشد.' );
		}
		
		return $this->ok( 'وضعیت ارسال با موفقیت بروزرسانی شد.' );
	}
	
	public function get_order_profit_report( $order_number ): array {
		if ( ! $this->visitor_can_access_order( (int) $order_number ) ) { return []; }
		$order_number = sanitize_text_field( $order_number );
		
		if ( $order_number === '' ) {
			return $this->fail( 'شماره سفارش معتبر نیست.' );
		}
		
		$order = $this->db->get_row(
			$this->db->prepare(
				"SELECT *
			FROM {$this->orders}
			WHERE order_number = %s OR id = %d
			LIMIT 1",
				$order_number,
				(int) $order_number
			),
			ARRAY_A
		);
		
		if ( ! $order ) {
			return $this->fail( 'سفارش یافت نشد.' );
		}
		
		$order_id = (int) $order['id'];
		
		$items = $this->db->get_results(
			$this->db->prepare(
				"
			SELECT
				oi.id AS order_item_id,
				oi.inventory_id,
				oi.unique_product_code,
				oi.wc_product_id,
				p.post_title,
				
				oi.qty_ordered,
				oi.expected_free_qty,
				oi.shipped_paid_qty,
				oi.shipped_free_qty,
				(oi.shipped_paid_qty + oi.shipped_free_qty) AS shipped_total_qty,
				
				oi.final_amount,
				
				COALESCE(
					(oi.final_amount / NULLIF(oi.qty_ordered, 0)) * oi.shipped_paid_qty,
					0
				) AS total_sales_amount,
				
				COALESCE(oi.cogs_total, 0) AS total_cogs,
				
				(
					COALESCE(
						(oi.final_amount / NULLIF(oi.qty_ordered, 0)) * oi.shipped_paid_qty,
						0
					)
					-
					COALESCE(oi.cogs_total, 0)
				) AS gross_profit,
				
				COALESCE(
					GREATEST(
						(oi.qty_ordered + oi.expected_free_qty) - (oi.shipped_paid_qty + oi.shipped_free_qty),
						0
					),
					0
				) AS shortage_qty
			
			FROM {$this->order_items} oi
			
			INNER JOIN {$this->orders} o
				ON o.id = oi.order_id
			
			INNER JOIN {$this->db->posts} p
				ON p.ID = oi.wc_product_id
			
			WHERE oi.order_id = %d
			
			ORDER BY oi.id ASC
			",
				$order_id
			),
			ARRAY_A
		);
		
		$total_sales_amount = 0;
		$total_cogs         = 0;
		$gross_profit       = 0;
		$total_shortage_qty = 0;
		$shipped_paid_qty   = 0;
		$shipped_free_qty   = 0;
		$shipped_total_qty  = 0;
		
		foreach ( $items as &$item ) {
			$item['qty_ordered']        = (float) $item['qty_ordered'];
			$item['expected_free_qty']  = (float) $item['expected_free_qty'];
			$item['shipped_paid_qty']   = (float) $item['shipped_paid_qty'];
			$item['shipped_free_qty']   = (float) $item['shipped_free_qty'];
			$item['shipped_total_qty']  = (float) $item['shipped_total_qty'];
			$item['shortage_qty']       = (float) $item['shortage_qty'];
			$item['final_amount']       = (float) $item['final_amount'];
			$item['total_sales_amount'] = (float) $item['total_sales_amount'];
			$item['total_cogs']         = (float) $item['total_cogs'];
			$item['gross_profit']       = (float) $item['gross_profit'];
			
			$item['gross_profit_percent'] = $item['total_sales_amount'] > 0
				? round( ( $item['gross_profit'] / $item['total_sales_amount'] ) * 100, 2 )
				: 0;
			
			$total_sales_amount += $item['total_sales_amount'];
			$total_cogs         += $item['total_cogs'];
			$gross_profit       += $item['gross_profit'];
			$total_shortage_qty += $item['shortage_qty'];
			$shipped_paid_qty   += $item['shipped_paid_qty'];
			$shipped_free_qty   += $item['shipped_free_qty'];
			$shipped_total_qty  += $item['shipped_total_qty'];
		}
		unset( $item );
		
		return [
			'total_sales_amount'   => round( $total_sales_amount, 2 ),
			'total_cogs'           => round( $total_cogs, 2 ),
			'gross_profit'         => round( $gross_profit, 2 ),
			'gross_profit_percent' => $total_sales_amount > 0
				? round( ( $gross_profit / $total_sales_amount ) * 100, 2 )
				: 0,
			'shipped_paid_qty'     => $shipped_paid_qty,
			'shipped_free_qty'     => $shipped_free_qty,
			'shipped_total_qty'    => $shipped_total_qty,
			'total_shortage_qty'   => $total_shortage_qty,
			'items'                => $items,
		];
	}
	
	public function get_orders_report( $date_from = '', $date_to = '' ): array {
		$date_filter = '';
		if ( ! empty( $date_from ) ) {
			$date_filter .= " AND o.created_at >= '" . $date_from . "'";
		}
		if ( ! empty( $date_to ) ) {
			$date_filter .= " AND o.created_at <= '" . $date_to . "'";
		}
		
		/* ===============================
		   🔹 خلاصه بالا
		=============================== */
		
		$total_invoices = (int) $this->db->get_var(
			"SELECT COUNT(*) FROM {$this->orders} o WHERE 1=1 " . $date_filter
		);
		
		$display_status_sql = $this->order_display_status_sql( 'o' );
		$total_registered = (int) $this->db->get_var(
			"SELECT COUNT(*) FROM {$this->orders} o WHERE ($display_status_sql) IN ('registered','shipped','shortage') " . $date_filter
		);
		
		$total_proforma_amount = (float) $this->db->get_var(
			"SELECT COALESCE(SUM(total_payable),0)
		 FROM {$this->orders} o
		 WHERE status = 'proforma'" . $date_filter
		);
		
		$total_shortage_qty = (int) $this->db->get_var(
			"SELECT COALESCE(SUM(
        GREATEST( (oi.qty_ordered + oi.expected_free_qty) - (oi.shipped_paid_qty + oi.shipped_free_qty), 0 )
    ),0)
     FROM {$this->order_items} oi
     INNER JOIN {$this->orders} o ON o.id = oi.order_id
   WHERE 1=1 " . $date_filter
		);
		
		$rows = $this->db->get_results(
			"
		SELECT
			oi.inventory_id,
			oi.unique_product_code,
			oi.wc_product_id,
			p.post_title,

			COUNT(DISTINCT oi.order_id) AS order_count,

			-- تعداد ارسال‌شده (تفکیک پولی/هدیه)
			COALESCE(SUM(oi.shipped_paid_qty),0) AS shipped_paid_qty,
			COALESCE(SUM(oi.shipped_free_qty),0) AS shipped_free_qty,
			COALESCE(SUM(oi.shipped_paid_qty + oi.shipped_free_qty),0) AS shipped_total_qty,

			-- مبلغ فروش فقط از پولی
			COALESCE(SUM(
				(oi.final_amount / NULLIF(oi.qty_ordered,0)) * oi.shipped_paid_qty
			),0) AS total_sales_amount,

			-- هزینه تولید فقط برای ارسال‌شده‌ها (پولی + هدیه) چون در لحظه ارسال ثبت می‌شود
			COALESCE(SUM(oi.cogs_total),0) AS total_cogs,

			-- کسری واقعی (پولی + هدیه)
			COALESCE(SUM(
				GREATEST( (oi.qty_ordered + oi.expected_free_qty) - (oi.shipped_paid_qty + oi.shipped_free_qty), 0 )
			),0) AS total_shortage_qty

		FROM {$this->order_items} oi
		INNER JOIN {$this->orders} o
			ON o.id = oi.order_id
		INNER JOIN {$this->db->posts} p
			ON p.ID = oi.wc_product_id

		WHERE ($display_status_sql) IN ('registered','shipped','shortage') {$date_filter}

		GROUP BY oi.wc_product_id
		ORDER BY total_sales_amount DESC
		",
			ARRAY_A
		);
		
		return [
			'summary' => [
				'total_invoices'        => $total_invoices,
				'total_registered'      => $total_registered,
				'total_shortage_qty'    => $total_shortage_qty,
				'total_proforma_amount' => $total_proforma_amount,
			],
			'items'   => $rows ?: [],
		];
	}
	
	public function get_customer_id_by_order_item( int $order_item_id ): int {
		if ( $order_item_id <= 0 ) {
			return 0;
		}
		
		$customer_id = (int) $this->db->get_var(
			$this->db->prepare(
				"SELECT o.customer_id
			 FROM {$this->order_items} oi
			 INNER JOIN {$this->orders} o
			 	ON o.id = oi.order_id
			 WHERE oi.id = %d
			 LIMIT 1",
				$order_item_id
			)
		);
		
		return $customer_id ?: 0;
	}
	
	public function get_users_performance_report( array $args = [] ): array {
		$args = wp_parse_args( $args, [
			'date_from'    => '',
			'date_to'      => '',
			'level'        => '',
			'balance_side' => '',
			'search'       => '',
			'sort'         => 'purchase_amount',
			'order'        => 'DESC',
			'page'         => 1,
			'per_page'     => 20,
		] );
		
		$page     = max( 1, (int) $args['page'] );
		$per_page = max( 1, min( 200, (int) $args['per_page'] ) );
		$offset   = ( $page - 1 ) * $per_page;
		
		$date_from = trim( (string) $args['date_from'] );
		$date_to   = trim( (string) $args['date_to'] );
		
		$order_where = [
			"o.status IN ('registered','shipped','shortage')",
			'o.customer_id IS NOT NULL',
			'o.customer_id > 0',
		];
		$order_binds = [];
		
		if ( $date_from !== '' ) {
			$order_where[] = 'o.created_at >= %s';
			$order_binds[] = $date_from . ' 00:00:00';
		}
		
		if ( $date_to !== '' ) {
			$order_where[] = 'o.created_at <= %s';
			$order_binds[] = $date_to . ' 23:59:59';
		}
		
		$order_where_sql = implode( ' AND ', $order_where );
		
		$ledger_where = [
			'l.user_id > 0',
		];
		$ledger_binds = [];
		
		if ( $date_from !== '' ) {
			$ledger_where[] = 'l.posted_at >= %s';
			$ledger_binds[] = $date_from . ' 00:00:00';
		}
		
		if ( $date_to !== '' ) {
			$ledger_where[] = 'l.posted_at <= %s';
			$ledger_binds[] = $date_to . ' 23:59:59';
		}
		
		$ledger_where_sql = implode( ' AND ', $ledger_where );
		
		$balance_where = [
			'lb.user_id > 0',
		];
		$balance_binds = [];
		
		if ( $date_to !== '' ) {
			$balance_where[] = 'lb.posted_at <= %s';
			$balance_binds[] = $date_to . ' 23:59:59';
		}
		
		$balance_where_sql = implode( ' AND ', $balance_where );
		
		/*
		 * مبنای گزارش:
		 * هر کسی که یا سفارش معتبر دارد، یا آیتم حسابداری دارد.
		 * دیگر وابسته به role وردپرس نیست.
		 */
		$users_src_sql = "
		SELECT DISTINCT user_id
		FROM (
			SELECT o.customer_id AS user_id
			FROM {$this->orders} o
			WHERE {$order_where_sql}
			
			UNION
			
			SELECT l.user_id AS user_id
			FROM {$this->ledger_entries} l
			WHERE {$ledger_where_sql}
		) report_users
	";
		
		$order_agg_sql = "
		SELECT
			o.customer_id AS user_id,
			COUNT(DISTINCT o.id) AS order_count,
			COALESCE(SUM(o.total_payable), 0) AS purchase_amount,
			COALESCE(SUM(o.total_ordered_qty), 0) AS ordered_qty,
			COALESCE(SUM(o.total_expected_free_qty), 0) AS expected_free_qty,
			COALESCE(SUM(o.total_shipped_qty), 0) AS shipped_qty,
			MAX(o.created_at) AS last_order_at
		FROM {$this->orders} o
		WHERE {$order_where_sql}
		GROUP BY o.customer_id
	";
		
		$ledger_agg_sql = "
		SELECT
			l.user_id,
			COUNT(l.id) AS ledger_count,
			COALESCE(SUM(
				CASE
					WHEN l.type = 'credit'
						AND l.entry_type IN ('submit_payment','submit_transfer','cheque_receive','cheque_clear')
					THEN l.amount
					ELSE 0
				END
			), 0) AS payment_amount,
			COALESCE(SUM(
				CASE
					WHEN l.entry_type = 'cheque_bounce'
					THEN 1
					ELSE 0
				END
			), 0) AS bounced_cheque_count,
			COALESCE(SUM(
				CASE
					WHEN l.entry_type = 'cheque_bounce'
					THEN l.amount
					ELSE 0
				END
			), 0) AS bounced_cheque_amount
		FROM {$this->ledger_entries} l
		WHERE {$ledger_where_sql}
		GROUP BY l.user_id
	";
		
		$balance_agg_sql = "
		SELECT
			lb.user_id,
			COALESCE(SUM(
				CASE
					WHEN lb.type = 'debit' THEN lb.amount
					ELSE -lb.amount
				END
			), 0) AS balance
		FROM {$this->ledger_entries} lb
		WHERE {$balance_where_sql}
		GROUP BY lb.user_id
	";
		
		$top_product_sql = "
		SELECT
			x.user_id,
			SUBSTRING_INDEX(
				GROUP_CONCAT(x.wc_product_id ORDER BY x.total_qty DESC, x.total_amount DESC SEPARATOR ','),
				',',
				1
			) AS top_product_id,
			SUBSTRING_INDEX(
				GROUP_CONCAT(x.total_qty ORDER BY x.total_qty DESC, x.total_amount DESC SEPARATOR ','),
				',',
				1
			) AS top_product_qty
		FROM (
			SELECT
				o.customer_id AS user_id,
				oi.wc_product_id,
				COALESCE(SUM(oi.qty_ordered), 0) AS total_qty,
				COALESCE(SUM(oi.final_amount), 0) AS total_amount
			FROM {$this->order_items} oi
			INNER JOIN {$this->orders} o
				ON o.id = oi.order_id
			WHERE {$order_where_sql}
			GROUP BY o.customer_id, oi.wc_product_id
		) x
		GROUP BY x.user_id
	";
		
		$from_sql = "
		FROM ({$users_src_sql}) src
		
		LEFT JOIN {$this->db->users} u
			ON u.ID = src.user_id
		
		LEFT JOIN {$this->db->usermeta} level_meta
			ON level_meta.user_id = src.user_id
			AND level_meta.meta_key = 'customer_level'
		
		LEFT JOIN {$this->db->usermeta} first_name_meta
			ON first_name_meta.user_id = src.user_id
			AND first_name_meta.meta_key = 'first_name'
		
		LEFT JOIN {$this->db->usermeta} last_name_meta
			ON last_name_meta.user_id = src.user_id
			AND last_name_meta.meta_key = 'last_name'
		
		LEFT JOIN {$this->db->usermeta} phone_meta
			ON phone_meta.user_id = src.user_id
			AND phone_meta.meta_key = 'nooshika_phone_num'
		
		LEFT JOIN ({$order_agg_sql}) oa
			ON oa.user_id = src.user_id
		
		LEFT JOIN ({$ledger_agg_sql}) la
			ON la.user_id = src.user_id
		
		LEFT JOIN ({$balance_agg_sql}) ba
			ON ba.user_id = src.user_id
		
		LEFT JOIN ({$top_product_sql}) tp
			ON tp.user_id = src.user_id
	";
		
		$base_binds = array_merge(
			$order_binds,   // users_src orders
			$ledger_binds,  // users_src ledger
			$order_binds,   // order_agg
			$ledger_binds,  // ledger_agg
			$balance_binds, // balance_agg
			$order_binds    // top_product
		);
		
		$where       = [ '1=1' ];
		$where_binds = [];
		
		$level = sanitize_key( (string) $args['level'] );
		if ( $level !== '' ) {
			$where[]       = 'level_meta.meta_value = %s';
			$where_binds[] = $level;
		}
		
		$balance_side = sanitize_key( (string) $args['balance_side'] );
		
		if ( $balance_side === 'debit' ) {
			$where[] = 'COALESCE(ba.balance, 0) > 0';
		} elseif ( $balance_side === 'credit' ) {
			$where[] = 'COALESCE(ba.balance, 0) < 0';
		} elseif ( $balance_side === 'settled' ) {
			$where[] = 'ABS(COALESCE(ba.balance, 0)) < 1';
		}
		
		$search = trim( (string) $args['search'] );
		if ( $search !== '' ) {
			$like = '%' . $this->db->esc_like( $search ) . '%';
			
			$where[] = "(
			u.display_name LIKE %s
			OR u.user_login LIKE %s
			OR u.user_email LIKE %s
			OR first_name_meta.meta_value LIKE %s
			OR last_name_meta.meta_value LIKE %s
			OR phone_meta.meta_value LIKE %s
			OR src.user_id = %d
		)";
			
			$where_binds[] = $like;
			$where_binds[] = $like;
			$where_binds[] = $like;
			$where_binds[] = $like;
			$where_binds[] = $like;
			$where_binds[] = $like;
			$where_binds[] = absint( $search );
		}
		
		$where_sql = 'WHERE ' . implode( ' AND ', $where );
		
		$allowed_sort = [
			'purchase_amount'       => 'purchase_amount',
			'payment_amount'        => 'payment_amount',
			'balance_amount'        => 'ABS(balance)',
			'bounced_cheque_amount' => 'bounced_cheque_amount',
			'bounced_cheque_count'  => 'bounced_cheque_count',
			'order_count'           => 'order_count',
			'last_order_at'         => 'last_order_at',
			'ordered_qty'           => 'ordered_qty',
		];
		
		$sort_key = sanitize_key( (string) $args['sort'] );
		$orderby  = $allowed_sort[ $sort_key ] ?? 'purchase_amount';
		$order    = strtoupper( (string) $args['order'] ) === 'ASC' ? 'ASC' : 'DESC';
		
		$select_sql = "
		SELECT
			src.user_id,
			COALESCE(u.display_name, CONCAT('کاربر #', src.user_id)) AS display_name,
			COALESCE(u.user_email, '') AS user_email,
			u.user_registered,
			COALESCE(level_meta.meta_value, '') AS customer_level,
			
			COALESCE(oa.order_count, 0) AS order_count,
			COALESCE(oa.purchase_amount, 0) AS purchase_amount,
			COALESCE(oa.ordered_qty, 0) AS ordered_qty,
			COALESCE(oa.expected_free_qty, 0) AS expected_free_qty,
			COALESCE(oa.shipped_qty, 0) AS shipped_qty,
			oa.last_order_at,
			
			COALESCE(la.payment_amount, 0) AS payment_amount,
			COALESCE(la.bounced_cheque_count, 0) AS bounced_cheque_count,
			COALESCE(la.bounced_cheque_amount, 0) AS bounced_cheque_amount,
			
			COALESCE(ba.balance, 0) AS balance,
			
			COALESCE(tp.top_product_id, 0) AS top_product_id,
			COALESCE(tp.top_product_qty, 0) AS top_product_qty
		{$from_sql}
		{$where_sql}
	";
		
		$all_binds = array_merge( $base_binds, $where_binds );
		
		$count_sql = "
		SELECT COUNT(*)
		{$from_sql}
		{$where_sql}
	";
		
		$total = (int) $this->db->get_var(
			! empty( $all_binds )
				? $this->db->prepare( $count_sql, $all_binds )
				: $count_sql
		);
		
		$summary_sql = "
		SELECT
			COUNT(*) AS total_customers,
			COALESCE(SUM(purchase_amount), 0) AS total_purchase_amount,
			COALESCE(SUM(payment_amount), 0) AS total_payment_amount,
			COALESCE(SUM(bounced_cheque_count), 0) AS total_bounced_cheque_count,
			COALESCE(SUM(bounced_cheque_amount), 0) AS total_bounced_cheque_amount,
			COALESCE(SUM(CASE WHEN balance > 0 THEN balance ELSE 0 END), 0) AS total_debit_balance,
			COALESCE(SUM(CASE WHEN balance < 0 THEN ABS(balance) ELSE 0 END), 0) AS total_credit_balance
		FROM (
			{$select_sql}
		) report_rows
	";
		
		$summary = (array) $this->db->get_row(
			! empty( $all_binds )
				? $this->db->prepare( $summary_sql, $all_binds )
				: $summary_sql,
			ARRAY_A
		);
		
		$data_sql = "
		{$select_sql}
		ORDER BY {$orderby} {$order}, user_id DESC
		LIMIT %d OFFSET %d
	";
		
		$data_binds = array_merge( $all_binds, [ $per_page, $offset ] );
		
		$items = $this->db->get_results(
			$this->db->prepare( $data_sql, $data_binds ),
			ARRAY_A
		);
		
		if ( empty( $items ) ) {
			$items = [];
		}
		
		foreach ( $items as &$item ) {
			$item['user_id']               = (int) $item['user_id'];
			$item['order_count']           = (int) $item['order_count'];
			$item['ordered_qty']           = (int) $item['ordered_qty'];
			$item['expected_free_qty']     = (int) $item['expected_free_qty'];
			$item['shipped_qty']           = (int) $item['shipped_qty'];
			$item['bounced_cheque_count']  = (int) $item['bounced_cheque_count'];
			$item['purchase_amount']       = (float) $item['purchase_amount'];
			$item['payment_amount']        = (float) $item['payment_amount'];
			$item['bounced_cheque_amount'] = (float) $item['bounced_cheque_amount'];
			$item['balance']               = (float) $item['balance'];
			$item['top_product_id']        = (int) $item['top_product_id'];
			$item['top_product_qty']       = (int) $item['top_product_qty'];
			$item['top_product_title']     = $item['top_product_id'] ? get_the_title( $item['top_product_id'] ) : '';
			$item['payment_percent']       = $item['purchase_amount'] > 0
				? round( ( $item['payment_amount'] / $item['purchase_amount'] ) * 100, 2 )
				: 0;
		}
		unset( $item );
		
		return [
			'summary'    => [
				'total_customers'             => (int) ( $summary['total_customers'] ?? 0 ),
				'total_purchase_amount'       => (float) ( $summary['total_purchase_amount'] ?? 0 ),
				'total_payment_amount'        => (float) ( $summary['total_payment_amount'] ?? 0 ),
				'total_bounced_cheque_count'  => (int) ( $summary['total_bounced_cheque_count'] ?? 0 ),
				'total_bounced_cheque_amount' => (float) ( $summary['total_bounced_cheque_amount'] ?? 0 ),
				'total_debit_balance'         => (float) ( $summary['total_debit_balance'] ?? 0 ),
				'total_credit_balance'        => (float) ( $summary['total_credit_balance'] ?? 0 ),
			],
			'items'      => $items,
			'pagination' => [
				'page'       => $page,
				'per_page'   => $per_page,
				'total'      => $total,
				'total_page' => (int) max( 1, ceil( $total / $per_page ) ),
			],
		];
	}
	
	public function get_user_products_performance_report( int $user_id, array $args = [] ): array {
		$user_id = (int) $user_id;
		
		if ( $user_id <= 0 ) {
			return [
				'summary' => [],
				'items'   => [],
			];
		}
		
		$args = wp_parse_args( $args, [
			'date_from' => '',
			'date_to'   => '',
		] );
		
		$where = [
			'o.customer_id = %d',
			"o.status IN ('registered','shipped','shortage')",
			'(oi.qty_ordered <> 0 OR oi.expected_free_qty <> 0 OR oi.shipped_paid_qty <> 0 OR oi.shipped_free_qty <> 0 OR oi.final_amount <> 0 OR oi.cogs_total <> 0)',
		];
		$binds = [ $user_id ];
		
		$date_from = trim( (string) $args['date_from'] );
		$date_to   = trim( (string) $args['date_to'] );
		
		if ( $date_from !== '' ) {
			$where[] = 'o.created_at >= %s';
			$binds[] = $date_from . ' 00:00:00';
		}
		
		if ( $date_to !== '' ) {
			$where[] = 'o.created_at <= %s';
			$binds[] = $date_to . ' 23:59:59';
		}
		
		$where_sql = implode( ' AND ', $where );
		
		$sql = "
		SELECT
			oi.inventory_id,
			oi.unique_product_code,
			oi.wc_product_id,
			
			COUNT(DISTINCT oi.order_id) AS order_count,
			
			COALESCE(SUM(oi.qty_ordered), 0) AS qty_ordered,
			COALESCE(SUM(oi.expected_free_qty), 0) AS expected_free_qty,
			COALESCE(SUM(oi.shipped_paid_qty), 0) AS shipped_paid_qty,
			COALESCE(SUM(oi.shipped_free_qty), 0) AS shipped_free_qty,
			COALESCE(SUM(oi.shipped_paid_qty + oi.shipped_free_qty), 0) AS shipped_total_qty,
			
			COALESCE(SUM(oi.final_amount), 0) AS total_order_amount,
			
			COALESCE(SUM(
				(oi.final_amount / NULLIF(oi.qty_ordered, 0)) * oi.shipped_paid_qty
			), 0) AS total_sales_amount,
			
			COALESCE(SUM(oi.cogs_total), 0) AS total_cogs,
			
			COALESCE(SUM(
				COALESCE(
					(oi.final_amount / NULLIF(oi.qty_ordered, 0)) * oi.shipped_paid_qty, 0
				) - oi.cogs_total
			), 0) AS gross_profit,
			
			COALESCE(SUM(
				GREATEST(
					(oi.qty_ordered + oi.expected_free_qty) - (oi.shipped_paid_qty + oi.shipped_free_qty),
					0
				)
			), 0) AS shortage_qty,
			
			MAX(o.created_at) AS last_order_at
		
		FROM {$this->order_items} oi
		INNER JOIN {$this->orders} o
			ON o.id = oi.order_id
		
		WHERE {$where_sql}
		
		GROUP BY oi.inventory_id, oi.unique_product_code, oi.wc_product_id
		ORDER BY qty_ordered DESC, total_order_amount DESC
	";
		
		$items = $this->db->get_results(
			$this->db->prepare( $sql, $binds ),
			ARRAY_A
		);
		
		if ( empty( $items ) ) {
			$items = [];
		}
		
		$summary = [
			'product_count'      => count( $items ),
			'qty_ordered'        => 0,
			'shipped_total_qty'  => 0,
			'total_order_amount' => 0,
			'total_sales_amount' => 0,
			'total_cogs'         => 0,
			'gross_profit'       => 0,
			'shortage_qty'       => 0,
		];
		
		foreach ( $items as &$item ) {
			$item['inventory_id']         = (int) $item['inventory_id'];
			$item['wc_product_id']        = (int) $item['wc_product_id'];
			$item['order_count']          = (int) $item['order_count'];
			$item['qty_ordered']          = (float) $item['qty_ordered'];
			$item['expected_free_qty']    = (int) $item['expected_free_qty'];
			$item['shipped_paid_qty']     = (float) $item['shipped_paid_qty'];
			$item['shipped_free_qty']     = (int) $item['shipped_free_qty'];
			$item['shipped_total_qty']    = (float) $item['shipped_total_qty'];
			$item['shortage_qty']         = (float) $item['shortage_qty'];
			$item['total_order_amount']   = (float) $item['total_order_amount'];
			$item['total_sales_amount']   = (float) $item['total_sales_amount'];
			$item['total_cogs']           = (float) $item['total_cogs'];
			$item['gross_profit']         = (float) $item['gross_profit'];
			$item['gross_profit_percent'] = $item['total_sales_amount'] > 0
				? round( ( $item['gross_profit'] / $item['total_sales_amount'] ) * 100, 2 )
				: 0;
			
			$summary['qty_ordered']        += $item['qty_ordered'];
			$summary['shipped_total_qty']  += $item['shipped_total_qty'];
			$summary['total_order_amount'] += $item['total_order_amount'];
			$summary['total_sales_amount'] += $item['total_sales_amount'];
			$summary['total_cogs']         += $item['total_cogs'];
			$summary['gross_profit']       += $item['gross_profit'];
			$summary['shortage_qty']       += $item['shortage_qty'];
		}
		unset( $item );
		
		return [
			'summary' => $summary,
			'items'   => $items,
		];
	}
	
	public function get_cost_categories_report( array $args = [] ): array {
		$args = wp_parse_args( $args, [
			'date_from'  => '',
			'date_to'    => '',
			'account_id' => 0,
			'search'     => '',
			'cost_types' => NULL,
		] );
		
		[ $trx_meta_table, $trx_meta_fk ] = $this->resolve_meta_table( 'account_transaction' );
		
		$where = [
			"t.type = 'debit'",
            "t.action <> 'transfer_deposit'",
            "NOT (t.action = 'customer_freight_payment' AND EXISTS (
                SELECT 1 FROM {$trx_meta_table} freight_void
                WHERE freight_void.{$trx_meta_fk}=t.id AND freight_void.meta_key='customer_freight_voided' AND freight_void.meta_value='1'
            ))",
            "NOT (t.action = 'shipping_freight' AND EXISTS (
                SELECT 1 FROM {$trx_meta_table} shipping_void
                WHERE shipping_void.{$trx_meta_fk} = t.id
                AND shipping_void.meta_key = 'shipping_voided' AND shipping_void.meta_value = '1'
            ))",
            "NOT (t.action = 'supplier_invoice_fee' AND EXISTS (
                SELECT 1 FROM {$trx_meta_table} supplier_void WHERE supplier_void.{$trx_meta_fk}=t.id
                AND supplier_void.meta_key='supplier_invoice_voided' AND supplier_void.meta_value='1'
            ))",
            "NOT (t.action = 'hr_payment' AND EXISTS (
                SELECT 1 FROM {$trx_meta_table} void_meta
                WHERE void_meta.{$trx_meta_fk} = t.id
                AND void_meta.meta_key = 'hr_voided' AND void_meta.meta_value = '1'
            ))",
		];
		$binds = [];
		
		$date_from = trim( (string) $args['date_from'] );
		$date_to   = trim( (string) $args['date_to'] );
		
		if ( $date_from !== '' ) {
			$where[] = 't.created_at >= %s';
			$binds[] = strlen( $date_from ) <= 10 ? $date_from . ' 00:00:00' : $date_from;
		}
		
		if ( $date_to !== '' ) {
			$where[] = 't.created_at <= %s';
			$binds[] = strlen( $date_to ) <= 10 ? $date_to . ' 23:59:59' : $date_to;
		}
		
		if ( (int) $args['account_id'] > 0 ) {
			$where[] = 't.account_id = %d';
			$binds[] = (int) $args['account_id'];
		}
		
		if ( is_array( $args['cost_types'] ) ) {
			// Category identifiers are stored as text (e.g. "Bank Adjustments").
			// Preserve spaces, case and Unicode when binding report filters.
			$cost_types = array_values( array_unique( array_filter( array_map( 'sanitize_text_field', $args['cost_types'] ) ) ) );
			if ( empty( $cost_types ) ) {
				$where[] = '1 = 0';
			} else {
				$placeholders = implode( ',', array_fill( 0, count( $cost_types ), '%s' ) );
				$where[]      = "cost_meta.meta_value IN ({$placeholders})";
				$binds        = array_merge( $binds, $cost_types );
			}
		}
		
		$search = trim( (string) $args['search'] );
		if ( $search !== '' ) {
			$like = '%' . $this->db->esc_like( $search ) . '%';
			
			$where[] = "(
			t.description LIKE %s
			OR a.title LIKE %s
			OR destination_meta.meta_value LIKE %s
		)";
			
			$binds[] = $like;
			$binds[] = $like;
			$binds[] = $like;
		}
		
		$where_sql = implode( ' AND ', $where );
		
		$sql = "
		SELECT
			COALESCE(NULLIF(cost_meta.meta_value, ''), 'uncategorized') AS cost_type,
			COUNT(t.id) AS transaction_count,
			COALESCE(SUM(t.amount), 0) AS total_amount,
			COALESCE(AVG(t.amount), 0) AS avg_amount,
			MIN(t.created_at) AS first_transaction_at,
			MAX(t.created_at) AS last_transaction_at
		FROM {$this->account_transactions} t
		LEFT JOIN {$this->accounts} a
			ON a.id = t.account_id
		LEFT JOIN {$trx_meta_table} cost_meta
			ON cost_meta.{$trx_meta_fk} = t.id
			AND cost_meta.meta_key = 'cost_type'
		LEFT JOIN {$trx_meta_table} destination_meta
			ON destination_meta.{$trx_meta_fk} = t.id
			AND destination_meta.meta_key = 'destination'
		WHERE {$where_sql}
		GROUP BY COALESCE(NULLIF(cost_meta.meta_value, ''), 'uncategorized')
		ORDER BY total_amount DESC, transaction_count DESC
	";
		
		$items = $this->db->get_results(
			! empty( $binds ) ? $this->db->prepare( $sql, $binds ) : $sql,
			ARRAY_A
		);
		
		if ( empty( $items ) ) {
			$items = [];
		}
		
		$total_amount = 0;
		$total_count  = 0;
		
		foreach ( $items as &$item ) {
			$item['transaction_count'] = (int) $item['transaction_count'];
			$item['total_amount']      = (float) $item['total_amount'];
			$item['avg_amount']        = (float) $item['avg_amount'];
			
			$total_amount += $item['total_amount'];
			$total_count  += $item['transaction_count'];
		}
		unset( $item );
		
		foreach ( $items as &$item ) {
			$item['percent'] = $total_amount > 0
				? round( ( $item['total_amount'] / $total_amount ) * 100, 2 )
				: 0;
		}
		unset( $item );
		
		return [
			'summary' => [
				'total_amount'        => $total_amount,
				'total_count'         => $total_count,
				'total_categories'    => count( $items ),
				'avg_per_category'    => count( $items ) > 0 ? round( $total_amount / count( $items ) ) : 0,
				'avg_per_transaction' => $total_count > 0 ? round( $total_amount / $total_count ) : 0,
			],
			'items'   => $items,
		];
	}
	
	public function get_cost_transactions_report( array $args = [] ): array {
		$args = wp_parse_args( $args, [
			'date_from'  => '',
			'date_to'    => '',
			'cost_type'  => '',
			'cost_types' => NULL,
			'account_id' => 0,
			'search'     => '',
			'page'       => 1,
			'per_page'   => 20,
		] );
		
		[ $trx_meta_table, $trx_meta_fk ] = $this->resolve_meta_table( 'account_transaction' );
		
		$page     = max( 1, (int) $args['page'] );
		$per_page = max( 1, min( 200, (int) $args['per_page'] ) );
		$offset   = ( $page - 1 ) * $per_page;
		
		$where = [
			"t.type = 'debit'",
            "t.action <> 'transfer_deposit'",
            "NOT (t.action = 'customer_freight_payment' AND EXISTS (
                SELECT 1 FROM {$trx_meta_table} freight_void
                WHERE freight_void.{$trx_meta_fk}=t.id AND freight_void.meta_key='customer_freight_voided' AND freight_void.meta_value='1'
            ))",
            "NOT (t.action = 'shipping_freight' AND EXISTS (
                SELECT 1 FROM {$trx_meta_table} shipping_void
                WHERE shipping_void.{$trx_meta_fk} = t.id
                AND shipping_void.meta_key = 'shipping_voided' AND shipping_void.meta_value = '1'
            ))",
            "NOT (t.action = 'supplier_invoice_fee' AND EXISTS (
                SELECT 1 FROM {$trx_meta_table} supplier_void WHERE supplier_void.{$trx_meta_fk}=t.id
                AND supplier_void.meta_key='supplier_invoice_voided' AND supplier_void.meta_value='1'
            ))",
            "NOT (t.action = 'hr_payment' AND EXISTS (
                SELECT 1 FROM {$trx_meta_table} void_meta
                WHERE void_meta.{$trx_meta_fk} = t.id
                AND void_meta.meta_key = 'hr_voided' AND void_meta.meta_value = '1'
            ))",
		];
		$binds = [];
		
		$date_from = trim( (string) $args['date_from'] );
		$date_to   = trim( (string) $args['date_to'] );
		
		if ( $date_from !== '' ) {
			$where[] = 't.created_at >= %s';
			$binds[] = strlen( $date_from ) <= 10 ? $date_from . ' 00:00:00' : $date_from;
		}
		
		if ( $date_to !== '' ) {
			$where[] = 't.created_at <= %s';
			$binds[] = strlen( $date_to ) <= 10 ? $date_to . ' 23:59:59' : $date_to;
		}
		
		$cost_type = sanitize_text_field( (string) $args['cost_type'] );
		if ( $cost_type !== '' ) {
			if ( $cost_type === 'uncategorized' ) {
				$where[] = "(cost_meta.meta_value IS NULL OR cost_meta.meta_value = '')";
			} else {
				$where[] = 'cost_meta.meta_value = %s';
				$binds[] = $cost_type;
			}
		}
		
		if ( is_array( $args['cost_types'] ) ) {
			$cost_types = array_values( array_unique( array_filter( array_map( 'sanitize_text_field', $args['cost_types'] ) ) ) );
			if ( empty( $cost_types ) ) {
				$where[] = '1 = 0';
			} else {
				$placeholders = implode( ',', array_fill( 0, count( $cost_types ), '%s' ) );
				$where[]      = "cost_meta.meta_value IN ({$placeholders})";
				$binds        = array_merge( $binds, $cost_types );
			}
		}
		
		if ( (int) $args['account_id'] > 0 ) {
			$where[] = 't.account_id = %d';
			$binds[] = (int) $args['account_id'];
		}
		
		$search = trim( (string) $args['search'] );
		if ( $search !== '' ) {
			$like = '%' . $this->db->esc_like( $search ) . '%';
			
			$where[] = "(
			t.description LIKE %s
			OR a.title LIKE %s
			OR destination_meta.meta_value LIKE %s
			OR t.id = %d
		)";
			
			$binds[] = $like;
			$binds[] = $like;
			$binds[] = $like;
			$binds[] = absint( $search );
		}
		
		$where_sql = implode( ' AND ', $where );
		
		$select_sql = "
		SELECT
			t.id,
			t.account_id,
			a.title AS account_title,
			t.amount,
			t.type,
			t.action,
			t.balance_after,
			t.description,
			t.created_by,
			t.created_at,
			COALESCE(NULLIF(cost_meta.meta_value, ''), 'uncategorized') AS cost_type,
			COALESCE(destination_meta.meta_value, '') AS destination,
			COALESCE(attachment_meta.meta_value, '') AS attachment
		FROM {$this->account_transactions} t
		LEFT JOIN {$this->accounts} a
			ON a.id = t.account_id
		LEFT JOIN {$trx_meta_table} cost_meta
			ON cost_meta.{$trx_meta_fk} = t.id
			AND cost_meta.meta_key = 'cost_type'
		LEFT JOIN {$trx_meta_table} destination_meta
			ON destination_meta.{$trx_meta_fk} = t.id
			AND destination_meta.meta_key = 'destination'
		LEFT JOIN {$trx_meta_table} attachment_meta
			ON attachment_meta.{$trx_meta_fk} = t.id
			AND attachment_meta.meta_key = 'attachment'
		WHERE {$where_sql}
	";
		
		$count_sql = "
		SELECT COUNT(*)
		FROM {$this->account_transactions} t
		LEFT JOIN {$this->accounts} a
			ON a.id = t.account_id
		LEFT JOIN {$trx_meta_table} cost_meta
			ON cost_meta.{$trx_meta_fk} = t.id
			AND cost_meta.meta_key = 'cost_type'
		LEFT JOIN {$trx_meta_table} destination_meta
			ON destination_meta.{$trx_meta_fk} = t.id
			AND destination_meta.meta_key = 'destination'
		WHERE {$where_sql}
	";
		
		$total = (int) $this->db->get_var(
			! empty( $binds ) ? $this->db->prepare( $count_sql, $binds ) : $count_sql
		);
		
		$data_sql = "
		{$select_sql}
		ORDER BY t.created_at DESC, t.id DESC
		LIMIT %d OFFSET %d
	";
		
		$items = $this->db->get_results(
			$this->db->prepare( $data_sql, array_merge( $binds, [ $per_page, $offset ] ) ),
			ARRAY_A
		);
		
		if ( empty( $items ) ) {
			$items = [];
		}
		
		foreach ( $items as &$item ) {
			$item['id']            = (int) $item['id'];
			$item['account_id']    = (int) $item['account_id'];
			$item['amount']        = (float) $item['amount'];
			$item['balance_after'] = (float) $item['balance_after'];
			$item['created_by']    = (int) $item['created_by'];
		}
		unset( $item );
		
		return [
			'items'      => $items,
			'pagination' => [
				'page'       => $page,
				'per_page'   => $per_page,
				'total'      => $total,
				'total_page' => (int) max( 1, ceil( $total / $per_page ) ),
			],
		];
	}
	
	public function get_stock_repository_report( array $args = [] ): array {
		$args = wp_parse_args( $args, [
			'date_from'      => '',
			'date_to'        => '',
			'raw_product_id' => 0,
			'search'         => '',
		] );
		
		$date_from      = trim( (string) $args['date_from'] );
		$date_to        = trim( (string) $args['date_to'] );
		$raw_product_id = absint( $args['raw_product_id'] );
		$search         = trim( (string) $args['search'] );
		
		$move_join  = 'm.batch_id = b.id';
		$move_binds = [];
		
		if ( $date_from !== '' ) {
			$move_join    .= ' AND m.created_at >= %s';
			$move_binds[] = $date_from . ' 00:00:00';
		}
		
		if ( $date_to !== '' ) {
			$move_join    .= ' AND m.created_at <= %s';
			$move_binds[] = $date_to . ' 23:59:59';
		}
		
		$current_where = 'sb.raw_product_id = p.id';
		$current_binds = [];
		
		if ( $date_to !== '' ) {
			$current_where   .= ' AND sm.created_at <= %s';
			$current_binds[] = $date_to . ' 23:59:59';
		}
		
		$where         = [ '1=1' ];
		$where_binds   = [];
		$where[] = $this->ordinary_raw_condition('p');
		if ( $raw_product_id > 0 ) {
			$where[]       = 'p.id = %d';
			$where_binds[] = $raw_product_id;
		}
		
		if ( $search !== '' ) {
			$like          = '%' . $this->db->esc_like( $search ) . '%';
			$where[]       = '(p.title LIKE %s OR p.code LIKE %s OR p.id = %d)';
			$where_binds[] = $like;
			$where_binds[] = $like;
			$where_binds[] = absint( $search );
		}
		
		$where_sql = implode( ' AND ', $where );
		
		$sql = "
		SELECT
			p.id AS raw_product_id,
			p.title AS raw_product_title,
			p.code AS raw_product_code,
			p.base_uom,
			
			COUNT(DISTINCT b.id) AS batch_count,
			
			COALESCE(SUM(CASE WHEN m.direction = 'in' THEN m.qty_weight ELSE 0 END), 0) AS period_in,
			COALESCE(SUM(CASE WHEN m.direction = 'out' THEN m.qty_weight ELSE 0 END), 0) AS period_out,
			
			COALESCE(SUM(CASE WHEN m.reason = 'purchase_in' THEN m.qty_weight ELSE 0 END), 0) AS purchase_in,
			COALESCE(SUM(CASE WHEN m.reason = 'processing_out' THEN m.qty_weight ELSE 0 END), 0) AS processing_out,
			COALESCE(SUM(CASE WHEN m.reason = 'processing_return' THEN m.qty_weight ELSE 0 END), 0) AS processing_return,
			COALESCE(SUM(CASE WHEN m.reason = 'waste' THEN m.qty_weight ELSE 0 END), 0) AS waste,
			COALESCE(SUM(CASE WHEN m.reason = 'adjustment' THEN m.qty_weight ELSE 0 END), 0) AS adjustment,
			
			(
				SELECT COALESCE(SUM(
					CASE
						WHEN sm.direction = 'in' THEN sm.qty_weight
						WHEN sm.direction = 'out' THEN -sm.qty_weight
						ELSE 0
					END
				), 0)
				FROM {$this->storage_moves} sm
				INNER JOIN {$this->batches} sb ON sb.id = sm.batch_id
				WHERE {$current_where}
			) AS current_weight,
			
			(
				SELECT COALESCE(SUM(
					CASE
						WHEN sm.direction = 'in' THEN sm.qty_weight * sm.unit_cost_at_move
						WHEN sm.direction = 'out' THEN -sm.qty_weight * sm.unit_cost_at_move
						ELSE 0
					END
				), 0)
				FROM {$this->storage_moves} sm
				INNER JOIN {$this->batches} sb ON sb.id = sm.batch_id
				WHERE {$current_where}
			) AS current_value
		
		FROM {$this->raw_products} p
		LEFT JOIN {$this->batches} b ON b.raw_product_id = p.id
		LEFT JOIN {$this->storage_moves} m ON {$move_join}
		
		WHERE {$where_sql}
		GROUP BY p.id
		HAVING batch_count > 0 OR ABS(current_weight) > 0
		ORDER BY current_value DESC, current_weight DESC
	";
		
		$binds = array_merge(
			$current_binds,
			$current_binds,
			$move_binds,
			$where_binds
		);
		
		$items = $this->db->get_results(
			! empty( $binds ) ? $this->db->prepare( $sql, $binds ) : $sql,
			ARRAY_A
		);
		
		$items = $items ?: [];
		
		$summary = [
			'current_weight' => 0,
			'current_value'  => 0,
			'period_in'      => 0,
			'period_out'     => 0,
			'waste'          => 0,
		];
		
		foreach ( $items as &$item ) {
			foreach (
				[
					'period_in',
					'period_out',
					'purchase_in',
					'processing_out',
					'processing_return',
					'waste',
					'adjustment',
					'current_weight',
					'current_value',
				] as $key
			) {
				$item[ $key ] = (float) $item[ $key ];
			}
			
			$item['batch_count'] = (int) $item['batch_count'];
			
			$summary['current_weight'] += $item['current_weight'];
			$summary['current_value']  += $item['current_value'];
			$summary['period_in']      += $item['period_in'];
			$summary['period_out']     += $item['period_out'];
			$summary['waste']          += $item['waste'];
		}
		unset( $item );
		
		return [
			'summary' => $summary,
			'items'   => $items,
		];
	}
	
	public function get_stock_saloon_report( array $args = [] ): array {
		$args = wp_parse_args( $args, [
			'date_from'      => '',
			'date_to'        => '',
			'raw_product_id' => 0,
			'search'         => '',
		] );
		
		$date_from      = trim( (string) $args['date_from'] );
		$date_to        = trim( (string) $args['date_to'] );
		$raw_product_id = absint( $args['raw_product_id'] );
		$search         = trim( (string) $args['search'] );
		
		$move_join  = '1=1';
		$move_binds = [];
		
		if ( $date_from !== '' ) {
			$move_join    .= ' AND m.created_at >= %s';
			$move_binds[] = $date_from . ' 00:00:00';
		}
		
		if ( $date_to !== '' ) {
			$move_join    .= ' AND m.created_at <= %s';
			$move_binds[] = $date_to . ' 23:59:59';
		}
		
		$current_where = "NOT EXISTS (SELECT 1 FROM {$this->db_prefix}packaging_lot_meta direct_trace WHERE direct_trace.lot_id=cl.id AND direct_trace.meta_key='direct_bulk' AND direct_trace.meta_value='1')";
		$current_binds = [];
		
		if ( $date_to !== '' ) {
			$current_where   .= ' AND cm.created_at <= %s';
			$current_binds[] = $date_to . ' 23:59:59';
		}
		
		$where = ["NOT EXISTS (SELECT 1 FROM {$this->db_prefix}packaging_lot_meta direct_trace WHERE direct_trace.lot_id=l.id AND direct_trace.meta_key='direct_bulk' AND direct_trace.meta_value='1')"];
		$where_binds = [];
		
		if ( $raw_product_id > 0 ) {
			$where[]       = 'rp.id = %d';
			$where_binds[] = $raw_product_id;
		}
		
		if ( $search !== '' ) {
			$like          = '%' . $this->db->esc_like( $search ) . '%';
			$where[]       = '(rp.title LIKE %s OR rp.code LIKE %s OR rp.id = %d)';
			$where_binds[] = $like;
			$where_binds[] = $like;
			$where_binds[] = absint( $search );
		}
		
		$where_sql = implode( ' AND ', $where );
		
		$sql = "
		SELECT
			rp.id AS raw_product_id,
			rp.title AS raw_product_title,
			rp.code AS raw_product_code,
			rp.base_uom,
			
			COALESCE(SUM(CASE WHEN m.reason = 'from_processing' THEN m.qty_weight * share.share_ratio ELSE 0 END), 0) AS from_processing,
			COALESCE(SUM(CASE WHEN m.reason = 'convert_to_shop_product' THEN m.qty_weight * share.share_ratio ELSE 0 END), 0) AS converted_to_product,
			COALESCE(SUM(CASE WHEN m.reason = 'waste' THEN m.qty_weight * share.share_ratio ELSE 0 END), 0) AS waste,
			COALESCE(SUM(CASE WHEN m.reason = 'return_to_processing' THEN m.qty_weight * share.share_ratio ELSE 0 END), 0) AS return_to_processing,
			
			(
				SELECT COALESCE(SUM(
					CASE
						WHEN cm.direction = 'in' THEN cm.qty_weight * cshare.share_ratio
						WHEN cm.direction = 'out' THEN -cm.qty_weight * cshare.share_ratio
						ELSE 0
					END
				), 0)
				FROM {$this->packaging_moves} cm
				INNER JOIN {$this->packaging_lots} cl ON cl.id = cm.packaging_lot_id
				INNER JOIN {$this->processing_pack_inputs} cpi ON cpi.pack_id = cl.processing_pack_id
				INNER JOIN {$this->batches} cb ON cb.id = cpi.batch_id
				INNER JOIN (
					SELECT
						pi2.id AS input_id,
						pi2.pack_id,
						pi2.qty_weight / NULLIF(pt.total_qty, 0) AS share_ratio
					FROM {$this->processing_pack_inputs} pi2
					INNER JOIN (
						SELECT pack_id, SUM(qty_weight) AS total_qty
						FROM {$this->processing_pack_inputs}
						GROUP BY pack_id
					) pt ON pt.pack_id = pi2.pack_id
				) cshare ON cshare.input_id = cpi.id
				WHERE cb.raw_product_id = rp.id
				AND {$current_where}
			) AS current_weight
		
		FROM {$this->raw_products} rp
		INNER JOIN {$this->batches} b ON b.raw_product_id = rp.id
		INNER JOIN {$this->processing_pack_inputs} pi ON pi.batch_id = b.id
		INNER JOIN {$this->packaging_lots} l ON l.processing_pack_id = pi.pack_id
		LEFT JOIN {$this->packaging_moves} m ON m.packaging_lot_id = l.id AND {$move_join}
		INNER JOIN (
			SELECT
				pi2.id AS input_id,
				pi2.pack_id,
				pi2.qty_weight / NULLIF(pt.total_qty, 0) AS share_ratio
			FROM {$this->processing_pack_inputs} pi2
			INNER JOIN (
				SELECT pack_id, SUM(qty_weight) AS total_qty
				FROM {$this->processing_pack_inputs}
				GROUP BY pack_id
			) pt ON pt.pack_id = pi2.pack_id
		) share ON share.input_id = pi.id
		
		WHERE {$where_sql}
		GROUP BY rp.id
		HAVING ABS(current_weight) > 0
			OR from_processing > 0
			OR converted_to_product > 0
			OR waste > 0
		ORDER BY current_weight DESC
	";
		
		$binds = array_merge(
			$current_binds,
			$move_binds,
			$where_binds
		);
		
		$items = $this->db->get_results(
			! empty( $binds ) ? $this->db->prepare( $sql, $binds ) : $sql,
			ARRAY_A
		);
		
		$items = $items ?: [];
		
		$summary = [
			'current_weight'       => 0,
			'from_processing'      => 0,
			'converted_to_product' => 0,
			'waste'                => 0,
			'return_to_processing' => 0,
		];
		
		foreach ( $items as &$item ) {
			foreach (
				[
					'current_weight',
					'from_processing',
					'converted_to_product',
					'waste',
					'return_to_processing',
				] as $key
			) {
				$item[ $key ]    = (float) $item[ $key ];
				$summary[ $key ] += $item[ $key ];
			}
		}
		unset( $item );
		
		return [
			'summary' => $summary,
			'items'   => $items,
		];
	}
	
	public function get_stock_finished_goods_report( array $args = [] ): array {
		$args = wp_parse_args( $args, [
			'date_from' => '',
			'date_to'   => '',
			'search'    => '',
		] );
		
		$date_from = trim( (string) $args['date_from'] );
		$date_to   = trim( (string) $args['date_to'] );
		$search    = trim( (string) $args['search'] );
		
		/*
		 * لاگ‌های بازه
		 *
		 * موجودی بر اساس ترکیب:
		 *
		 * unique_product_code + wc_product_id
		 */
		$log_join = '
		l.unique_product_code = ib.unique_product_code
		AND l.wc_product_id = ib.wc_product_id
	';
		
		$log_binds = [];
		
		if ( $date_from !== '' ) {
			$log_join    .= ' AND l.created_at >= %s';
			$log_binds[] = $date_from . ' 00:00:00';
		}
		
		if ( $date_to !== '' ) {
			$log_join    .= ' AND l.created_at <= %s';
			$log_binds[] = $date_to . ' 23:59:59';
		}
		
		/*
		 * موجودی تجمعی تا date_to
		 *
		 * باز هم بر اساس:
		 *
		 * unique_product_code + wc_product_id
		 */
		$current_where = '
		cl.unique_product_code = ib.unique_product_code
		AND cl.wc_product_id = ib.wc_product_id
	';
		
		$current_binds = [];
		
		if ( $date_to !== '' ) {
			$current_where   .= ' AND cl.created_at <= %s';
			$current_binds[] = $date_to . ' 23:59:59';
		}
		
		/*
		 * فیلترها
		 */
		$where       = [ '1=1' ];
		$where_binds = [];
		
		if ( $search !== '' ) {
			$like = '%' . $this->db->esc_like( $search ) . '%';
			
			$where[] = '(
			ib.unique_product_code LIKE %s
			OR ib.wc_product_id = %d
		)';
			
			$where_binds[] = $like;
			$where_binds[] = absint( $search );
		}
		
		$where_sql = implode( ' AND ', $where );
		
		$sql = "
		SELECT
			ib.id AS inventory_id,
			ib.unique_product_code,
			ib.wc_product_id,
			
			/*
			 * ورود در بازه
			 */
			COALESCE(
				SUM(
					CASE
						WHEN l.change_qty > 0
						THEN l.change_qty
						ELSE 0
					END
				),
				0
			) AS period_in_qty,
			
			/*
			 * خروج در بازه
			 */
			COALESCE(
				SUM(
					CASE
						WHEN l.change_qty < 0
						THEN ABS(l.change_qty)
						ELSE 0
					END
				),
				0
			) AS period_out_qty,
			
			/*
			 * تولید
			 */
			COALESCE(
				SUM(
					CASE
						WHEN l.ref_type = 'production'
						THEN l.change_qty
						ELSE 0
					END
				),
				0
			) AS production_in_qty,
			
			/*
			 * فروش
			 */
			COALESCE(
				SUM(
					CASE
						WHEN l.ref_type = 'sale'
						THEN ABS(l.change_qty)
						ELSE 0
					END
				),
				0
			) AS sale_out_qty,
			
			/*
			 * بهای تمام شده فروش
			 */
			COALESCE(
				SUM(
					CASE
						WHEN l.ref_type = 'sale'
						THEN ABS(l.total_cost)
						ELSE 0
					END
				),
				0
			) AS sale_cogs,
			
			/*
			 * موجودی تجمعی تا date_to
			 */
			(
				SELECT
					COALESCE(
						SUM(cl.change_qty),
						0
					)
				
				FROM {$this->inventory_log} cl
				
				WHERE {$current_where}
			) AS current_qty,
			
			/*
			 * ارزش تجمعی موجودی تا date_to
			 */
			(
				SELECT
					COALESCE(
						SUM(cl.total_cost),
						0
					)
				
				FROM {$this->inventory_log} cl
				
				WHERE {$current_where}
			) AS current_value
		
		FROM {$this->inventory_balance} ib
		
		LEFT JOIN {$this->inventory_log} l
			ON {$log_join}
		
		WHERE {$where_sql}
		
		GROUP BY
			ib.id,
			ib.unique_product_code,
			ib.wc_product_id
		
		HAVING
			current_qty <> 0
			OR period_in_qty > 0
			OR period_out_qty > 0
		
		ORDER BY
			current_value DESC,
			current_qty DESC
	";
		
		/*
		 * ترتیب placeholderها:
		 *
		 * 1. current_qty
		 * 2. current_value
		 * 3. LEFT JOIN logs
		 * 4. WHERE
		 */
		$binds = array_merge(
			$current_binds,
			$current_binds,
			$log_binds,
			$where_binds
		);
		
		$items = $this->db->get_results(
			! empty( $binds )
				? $this->db->prepare( $sql, $binds )
				: $sql,
			ARRAY_A
		);
		
		$items = $items ?: [];
		
		$summary = [
			'current_qty'    => 0,
			'current_value'  => 0,
			'period_in_qty'  => 0,
			'period_out_qty' => 0,
			'sale_out_qty'   => 0,
			'sale_cogs'      => 0,
		];
		
		foreach ( $items as &$item ) {
			$item['inventory_id']  = (int) $item['inventory_id'];
			$item['wc_product_id'] = (int) $item['wc_product_id'];
			
			foreach (
				[
					'period_in_qty',
					'period_out_qty',
					'production_in_qty',
					'sale_out_qty',
					'sale_cogs',
					'current_qty',
					'current_value',
				] as $key
			) {
				$item[ $key ] = (float) $item[ $key ];
			}
			
			$item['product_title'] = get_the_title(
				$item['wc_product_id']
			);
			
			$summary['current_qty'] +=
				$item['current_qty'];
			
			$summary['current_value'] +=
				$item['current_value'];
			
			$summary['period_in_qty'] +=
				$item['period_in_qty'];
			
			$summary['period_out_qty'] +=
				$item['period_out_qty'];
			
			$summary['sale_out_qty'] +=
				$item['sale_out_qty'];
			
			$summary['sale_cogs'] +=
				$item['sale_cogs'];
		}
		unset( $item );
		
		return [
			'summary' => $summary,
			'items'   => $items,
		];
	}
	
	public function get_stock_inventory_trace_report( array $args = [] ): array {
		$args = wp_parse_args( $args, [
			'date_from'   => '',
			'date_to'     => '',
			'customer_id' => 0,
			'search'      => '',
			'page'        => 1,
			'per_page'    => 20,
		] );
		
		$page     = max( 1, (int) $args['page'] );
		$per_page = max( 1, min( 200, (int) $args['per_page'] ) );
		$offset   = ( $page - 1 ) * $per_page;
		
		$where = [ '1=1' ];
		$binds = [];
		
		if ( trim( (string) $args['date_from'] ) !== '' ) {
			$where[] = 'l.created_at >= %s';
			$binds[] = trim( (string) $args['date_from'] ) . ' 00:00:00';
		}
		
		if ( trim( (string) $args['date_to'] ) !== '' ) {
			$where[] = 'l.created_at <= %s';
			$binds[] = trim( (string) $args['date_to'] ) . ' 23:59:59';
		}
		
		if ( absint( $args['customer_id'] ) > 0 ) {
			$where[] = 'o.customer_id = %d';
			$binds[] = absint( $args['customer_id'] );
		}
		
		$search = trim( (string) $args['search'] );
		if ( $search !== '' ) {
			$like    = '%' . $this->db->esc_like( $search ) . '%';
			$where[] = '(
			l.unique_product_code LIKE %s
			OR l.ref_id = %d
			OR l.wc_product_id = %d
			OR cu.display_name LIKE %s
			OR o.order_number LIKE %s
		)';
			$binds[] = $like;
			$binds[] = absint( $search );
			$binds[] = absint( $search );
			$binds[] = $like;
			$binds[] = $like;
		}
		
		$where_sql = 'WHERE ' . implode( ' AND ', $where );
		
		$base_sql = "
		FROM {$this->inventory_log} l
		
		LEFT JOIN {$this->fulfillments} f
			ON l.ref_type = 'sale'
			AND f.id = l.ref_id
		
		LEFT JOIN {$this->orders} o
			ON o.id = f.order_id
		
		LEFT JOIN {$this->db->users} cu
			ON cu.ID = o.customer_id
		
		LEFT JOIN {$this->shop_conversions} sc
			ON l.ref_type = 'production'
			AND sc.id = l.ref_id
		
		{$where_sql}
	";
		
		$total = (int) $this->db->get_var(
			! empty( $binds )
				? $this->db->prepare( "SELECT COUNT(*) {$base_sql}", $binds )
				: "SELECT COUNT(*) {$base_sql}"
		);
		
		$sql = "
		SELECT
			l.*,
			f.order_id,
			o.order_number,
			o.customer_id,
			cu.display_name AS customer_name,
			sc.packaging_lot_id,
			sc.weight_per_item,
			sc.qty_items AS conversion_qty_items
		{$base_sql}
		ORDER BY l.created_at DESC, l.id DESC
		LIMIT %d OFFSET %d
	";
		
		$items = $this->db->get_results(
			$this->db->prepare( $sql, array_merge( $binds, [ $per_page, $offset ] ) ),
			ARRAY_A
		);
		
		$items = $items ?: [];
		
		foreach ( $items as &$item ) {
			$item['id']            = (int) $item['id'];
			$item['wc_product_id'] = (int) $item['wc_product_id'];
			$item['change_qty']    = (float) $item['change_qty'];
			$item['unit_cost']     = (float) $item['unit_cost'];
			$item['total_cost']    = (float) $item['total_cost'];
			$item['customer_id']   = (int) $item['customer_id'];
			$item['product_title'] = get_the_title( $item['wc_product_id'] );
		}
		unset( $item );
		
		return [
			'items'      => $items,
			'pagination' => [
				'page'       => $page,
				'per_page'   => $per_page,
				'total'      => $total,
				'total_page' => (int) max( 1, ceil( $total / $per_page ) ),
			],
		];
	}
	
	public function get_stock_batches_factor_report( array $args = [] ): array {
		$args = wp_parse_args( $args, [
			'date_from' => '', 'date_to' => '', 'raw_product_id' => 0,
			'search' => '', 'per_page' => 50,
		] );
		$per_page = max( 1, min( 5000, absint( $args['per_page'] ) ) );
		$where = [ $this->ordinary_raw_condition( 'rp' ) ];
		$binds = [];
		$move_date = '';
		if ( trim( (string) $args['date_to'] ) !== '' ) {
			$move_date = ' AND sm.created_at <= %s';
			$binds[] = trim( (string) $args['date_to'] ) . ' 23:59:59';
		}
		if ( absint( $args['raw_product_id'] ) > 0 ) {
			$where[] = 'b.raw_product_id = %d';
			$binds[] = absint( $args['raw_product_id'] );
		}
		if ( trim( (string) $args['search'] ) !== '' ) {
			$like = '%' . $this->db->esc_like( trim( (string) $args['search'] ) ) . '%';
			$where[] = '(rp.title LIKE %s OR si.invoice_no LIKE %s OR su.display_name LIKE %s OR b.id = %d)';
			array_push( $binds, $like, $like, $like, absint( $args['search'] ) );
		}
		$sql = "SELECT b.id AS batch_id, b.raw_product_id, rp.title AS raw_product_title,
			rp.base_uom, b.source_type, b.source_id, b.initial_qty_weight, b.unit_cost,
			(b.initial_qty_weight * b.unit_cost) AS purchase_amount, b.created_at,
			si.id AS invoice_id, si.invoice_no, si.supplier_user_id, su.display_name AS supplier_name,
			COALESCE(mv.current_weight, 0) AS current_weight,
			COALESCE(mv.processing_out, 0) AS processing_out, COALESCE(mv.waste, 0) AS waste
		FROM {$this->batches} b
		INNER JOIN {$this->raw_products} rp ON rp.id = b.raw_product_id
		LEFT JOIN {$this->supplier_invoice_items} sii ON b.source_type = 'supplier_invoice_item' AND sii.id = b.source_id
		LEFT JOIN {$this->supplier_invoices} si ON si.id = sii.invoice_id
		LEFT JOIN {$this->db->users} su ON su.ID = si.supplier_user_id
		LEFT JOIN (
			SELECT sm.batch_id,
			SUM(CASE WHEN sm.direction = 'in' THEN sm.qty_weight WHEN sm.direction = 'out' THEN -sm.qty_weight ELSE 0 END) AS current_weight,
			SUM(CASE WHEN sm.reason = 'processing_out' THEN sm.qty_weight ELSE 0 END) AS processing_out,
			SUM(CASE WHEN sm.reason = 'waste' THEN sm.qty_weight ELSE 0 END) AS waste
			FROM {$this->storage_moves} sm WHERE 1=1 {$move_date} GROUP BY sm.batch_id
		) mv ON mv.batch_id = b.id
		WHERE " . implode( ' AND ', $where );
		$items = $this->db->get_results( $binds ? $this->db->prepare( $sql, $binds ) : $sql, ARRAY_A ) ?: [];
		if ( ! $items ) {
			return [ 'items' => [] ];
		}
		$indexes = [];
		foreach ( $items as $index => &$item ) {
			foreach ( [ 'batch_id', 'raw_product_id', 'invoice_id', 'supplier_user_id' ] as $key ) {
				$item[$key] = (int) $item[$key];
			}
			foreach ( [ 'initial_qty_weight', 'unit_cost', 'purchase_amount', 'current_weight', 'processing_out', 'waste' ] as $key ) {
				$item[$key] = (float) $item[$key];
			}
			foreach ( [ 'converted_weight', 'converted_items', 'sold_qty', 'sales_amount', 'cogs_amount', 'gross_profit' ] as $key ) {
				$item[$key] = 0.0;
			}
			$item['_buyers'] = $item['_orders'] = [];
			$indexes[$item['batch_id']] = $index;
		}
		unset( $item );

		// Fetch production shares once, then run the same FIFO allocation used by the detail report.
		// Joining every shipment to every same-code conversion would count sales repeatedly.
		$ids = implode( ',', array_map( 'absint', array_keys( $indexes ) ) );
		$production_date = '';
		$share_binds = [];
		if ( trim( (string) $args['date_to'] ) !== '' ) {
			$production_date = ' AND sc.created_at <= %s';
			$share_binds[] = trim( (string) $args['date_to'] ) . ' 23:59:59';
		}
		$shares_sql = "SELECT share.batch_id, share.share_ratio, sc.id AS conversion_id,
			sc.unique_product_code, sc.wc_product_id, sc.qty_items, sc.weight_per_item, sc.created_at
		FROM (
			SELECT pi.batch_id, pi.pack_id,
			CAST(SUM(pi.qty_weight) AS DECIMAL(30,12)) / NULLIF(pt.total_qty, 0) AS share_ratio
			FROM {$this->processing_pack_inputs} pi
			INNER JOIN (SELECT pack_id, SUM(qty_weight) AS total_qty FROM {$this->processing_pack_inputs} GROUP BY pack_id) pt ON pt.pack_id = pi.pack_id
			WHERE pi.batch_id IN ({$ids}) GROUP BY pi.batch_id, pi.pack_id
		) share
		INNER JOIN {$this->packaging_lots} pl ON pl.processing_pack_id = share.pack_id
		INNER JOIN {$this->shop_conversions} sc ON sc.packaging_lot_id = pl.id
		WHERE 1=1 {$production_date}";
		$shares = $this->db->get_results( $share_binds ? $this->db->prepare( $shares_sql, $share_binds ) : $shares_sql, ARRAY_A ) ?: [];
		$production = [];
		foreach ( $shares as $share ) {
			$conversion_id = (int) $share['conversion_id'];
			$production[$conversion_id] = $share;
			$production[$conversion_id]['share_ratio'] = 1.0;
		}
		$fifo = $this->apply_stock_single_batch_fifo_allocation( [
			'conversions' => array_values( $production ), 'group_customers_by_conversion' => TRUE,
		], $args );
		$sales = [];
		foreach ( $fifo['conversions'] as $conversion ) {
			$sales[(int) $conversion['conversion_id']] = $conversion;
		}
		$customers = [];
		foreach ( $fifo['customers'] as $customer ) {
			$customers[(int) $customer['conversion_id']][] = $customer;
		}
		foreach ( $shares as $share ) {
			$index = $indexes[(int) $share['batch_id']];
			$ratio = (float) $share['share_ratio'];
			$conversion_id = (int) $share['conversion_id'];
			$items[$index]['converted_items'] += (int) $share['qty_items'] * $ratio;
			$items[$index]['converted_weight'] += (int) $share['qty_items'] * (float) $share['weight_per_item'] * $ratio;
			foreach ( [ 'sold_qty', 'sales_amount', 'cogs_amount', 'gross_profit' ] as $key ) {
				$items[$index][$key] += (float) ($sales[$conversion_id][$key] ?? 0) * $ratio;
			}
			foreach ( $customers[$conversion_id] ?? [] as $customer ) {
				$items[$index]['_buyers'][(int) $customer['customer_id']] = TRUE;
				$items[$index]['_orders'][(int) $customer['order_id']] = TRUE;
			}
		}
		foreach ( $items as &$item ) {
			$item['buyers_count'] = count( $item['_buyers'] );
			$item['orders_count'] = count( $item['_orders'] );
			unset( $item['_buyers'], $item['_orders'] );
		}
		unset( $item );
		// Apply the limit after correcting profit, so sorting and totals use the actual displayed rows.
		usort( $items, static function( $a, $b ) {
			return ($b['gross_profit'] <=> $a['gross_profit']) ?: (($b['purchase_amount'] <=> $a['purchase_amount']) ?: ($a['batch_id'] <=> $b['batch_id']));
		} );
		return [ 'items' => array_slice( $items, 0, $per_page ) ];
	}
	
	public function get_stock_single_batch_factor_report( int $batch_id, array $args = [] ): array {
		$args = wp_parse_args( $args, [
			'date_from' => '',
			'date_to'   => '',
		] );
		
		$report = $this->get_stock_single_batch_factor_report_base(
			$batch_id,
			$args
		);
		
		if (
			empty( $report['batch'] )
			||
			empty( $report['conversions'] )
		) {
			return $report;
		}
		
		return $this->apply_stock_single_batch_fifo_allocation(
			$report,
			$args
		);
	}
	
	private function apply_stock_single_batch_fifo_allocation(
		array $report,
		array $args
	): array {
		$conversions = is_array( $report['conversions'] ?? NULL )
			? $report['conversions']
			: [];
		
		if ( empty( $conversions ) ) {
			$report['customers'] = [];
			
			return $report;
		}
		
		$date_from = trim( (string) ( $args['date_from'] ?? '' ) );
		$date_to   = trim( (string) ( $args['date_to'] ?? '' ) );
		$from_sql  = $date_from !== '' ? $date_from . ' 00:00:00' : '';
		$to_sql    = $date_to !== '' ? $date_to . ' 23:59:59' : '';
		
		$conversion_indexes = [];
		$pool_filters       = [];
		
		foreach ( $conversions as $index => &$conversion ) {
			$conversion_id = absint( $conversion['conversion_id'] ?? 0 );
			$product_id    = absint( $conversion['wc_product_id'] ?? 0 );
			$product_code  = trim( (string) ( $conversion['unique_product_code'] ?? '' ) );
			
			$conversion['sold_qty']      = 0.0;
			$conversion['sold_paid_qty'] = 0.0;
			$conversion['sold_free_qty'] = 0.0;
			$conversion['sales_amount']  = 0.0;
			$conversion['cogs_amount']   = 0.0;
			$conversion['gross_profit']  = 0.0;
			$conversion['buyers_count']  = 0;
			$conversion['orders_count']  = 0;
			$conversion['_buyers']       = [];
			$conversion['_orders']       = [];
			
			if (
				$conversion_id <= 0
				||
				$product_id <= 0
				||
				$product_code === ''
			) {
				continue;
			}
			
			$pool_key = $product_code . "\x1F" . $product_id;
			
			$conversion_indexes[ $conversion_id ] = $index;
			$pool_filters[ $pool_key ]            = [
				'unique_product_code' => $product_code,
				'wc_product_id'       => $product_id,
			];
		}
		unset( $conversion );
		
		if ( empty( $pool_filters ) ) {
			$report['conversions'] = $conversions;
			$report['customers']   = [];
			
			return $report;
		}
		
		$conversion_where = [];
		$conversion_binds = [];
		
		foreach ( $pool_filters as $filter ) {
			$conversion_where[] = '(
				sc.unique_product_code = %s
				AND sc.wc_product_id = %d
			)';
			$conversion_binds[] = $filter['unique_product_code'];
			$conversion_binds[] = $filter['wc_product_id'];
		}
		
		$fifo_conversions_sql = "
		SELECT
			sc.id AS conversion_id,
			sc.unique_product_code,
			sc.wc_product_id,
			sc.qty_items,
			sc.created_at
		
		FROM {$this->shop_conversions} sc
		
		WHERE " . implode( ' OR ', $conversion_where ) . "
		
		ORDER BY
			sc.unique_product_code ASC,
			sc.wc_product_id ASC,
			sc.created_at ASC,
			sc.id ASC
		";
		
		$fifo_conversions = $this->db->get_results(
			$this->db->prepare(
				$fifo_conversions_sql,
				$conversion_binds
			),
			ARRAY_A
		);
		
		$fifo_lots      = [];
		$fifo_positions = [];
		
		foreach ( $fifo_conversions ?: [] as $fifo_conversion ) {
			$qty_items = max( 0, (int) $fifo_conversion['qty_items'] );
			
			if ( $qty_items <= 0 ) {
				continue;
			}
			
			$pool_key = (string) $fifo_conversion['unique_product_code']
			            . "\x1F"
			            . (int) $fifo_conversion['wc_product_id'];
			
			$fifo_lots[ $pool_key ][]    = [
				'conversion_id' => (int) $fifo_conversion['conversion_id'],
				'remaining_qty' => $qty_items,
				'created_at'    => (string) $fifo_conversion['created_at'],
			];
			$fifo_positions[ $pool_key ] = 0;
		}
		
		if ( empty( $fifo_lots ) ) {
			$report['conversions'] = $conversions;
			$report['customers']   = [];
			
			return $report;
		}
		
		$fulfillment_where = [];
		$fulfillment_binds = [];
		
		foreach ( $pool_filters as $filter ) {
			$fulfillment_where[] = '(
				ib.unique_product_code = %s
				AND ib.wc_product_id = %d
			)';
			$fulfillment_binds[] = $filter['unique_product_code'];
			$fulfillment_binds[] = $filter['wc_product_id'];
		}
		
		$date_to_sql = '';
		
		if ( $to_sql !== '' ) {
			$date_to_sql         = ' AND fi.created_at <= %s';
			$fulfillment_binds[] = $to_sql;
		}
		
		$fulfillments_sql = "
		SELECT
			fi.id AS fulfillment_item_id,
			fi.shipped_paid_qty,
			fi.shipped_free_qty,
			fi.unit_cost,
			fi.total_cost,
			fi.created_at AS fulfilled_at,
			
			ib.unique_product_code,
			ib.wc_product_id,
			
			oi.qty_ordered,
			oi.final_amount,
			
			o.id AS order_id,
			o.order_number,
			o.customer_id,
			o.created_at AS order_created_at,
			
			cu.display_name AS customer_name
		
		FROM {$this->fulfillment_items} fi
		
		INNER JOIN {$this->inventory_balance} ib
			ON ib.id = fi.inventory_id
		
		INNER JOIN {$this->order_items} oi
			ON oi.id = fi.order_item_id
		
		INNER JOIN {$this->fulfillments} f
			ON f.id = fi.fulfillment_id
			AND f.order_id = oi.order_id
			AND f.status <> 'canceled'
		
		INNER JOIN {$this->orders} o
			ON o.id = oi.order_id
			AND o.status IN (
				'registered',
				'shortage',
				'shipped'
			)
		
		LEFT JOIN {$this->db->users} cu
			ON cu.ID = o.customer_id
		
		WHERE (
			" . implode( ' OR ', $fulfillment_where ) . "
		)
			AND (
				fi.shipped_paid_qty > 0
				OR fi.shipped_free_qty > 0
			)
			{$date_to_sql}
		
		ORDER BY
			ib.unique_product_code ASC,
			ib.wc_product_id ASC,
			fi.created_at ASC,
			fi.id ASC
		";
		
		$fulfillments = $this->db->get_results(
			$this->db->prepare(
				$fulfillments_sql,
				$fulfillment_binds
			),
			ARRAY_A
		);
		
		$customers = [];
		
		foreach ( $fulfillments ?: [] as $fulfillment ) {
			$product_code = (string) $fulfillment['unique_product_code'];
			$product_id   = (int) $fulfillment['wc_product_id'];
			$pool_key     = $product_code . "\x1F" . $product_id;
			
			if ( empty( $fifo_lots[ $pool_key ] ) ) {
				continue;
			}
			
			$paid_qty  = max( 0, (float) $fulfillment['shipped_paid_qty'] );
			$free_qty  = max( 0, (int) $fulfillment['shipped_free_qty'] );
			$total_qty = $paid_qty + $free_qty;
			
			if ( $total_qty <= 0 ) {
				continue;
			}
			
			$fulfilled_at = (string) $fulfillment['fulfilled_at'];
			$in_range     = (
				( $from_sql === '' || $fulfilled_at >= $from_sql )
				&&
				( $to_sql === '' || $fulfilled_at <= $to_sql )
			);
			
			$sale_unit_price = (float) $fulfillment['qty_ordered'] > 0
				? (float) $fulfillment['final_amount'] / (float) $fulfillment['qty_ordered']
				: 0.0;
			
			$cost_per_item = $total_qty > 0
				? (float) $fulfillment['total_cost'] / $total_qty
				: (float) $fulfillment['unit_cost'];
			
			$parts = [
				[
					'qty'     => $paid_qty,
					'is_paid' => TRUE,
				],
				[
					'qty'     => $free_qty,
					'is_paid' => FALSE,
				],
			];
			
			foreach ( $parts as $part ) {
				$remaining = (int) $part['qty'];
				
				while ( $remaining > 0 ) {
					$position = $fifo_positions[ $pool_key ] ?? 0;
					
					if ( ! isset( $fifo_lots[ $pool_key ][ $position ] ) ) {
						break;
					}
					
					$lot = $fifo_lots[ $pool_key ][ $position ];
					
					if ( (int) $lot['remaining_qty'] <= 0 ) {
						$fifo_positions[ $pool_key ] = $position + 1;
						continue;
					}
					
					/*
					 * فروش قبل از تاریخ ایجاد یک Conversion نمی‌تواند
					 * از موجودی آن Conversion مصرف کند.
					 */
					if ( (string) $lot['created_at'] > $fulfilled_at ) {
						break;
					}
					
					$take = min(
						$remaining,
						(int) $lot['remaining_qty']
					);
					
					$fifo_lots[ $pool_key ][ $position ]['remaining_qty'] -= $take;
					$remaining                                            -= $take;
					
					if ( $fifo_lots[ $pool_key ][ $position ]['remaining_qty'] <= 0 ) {
						$fifo_positions[ $pool_key ] = $position + 1;
					}
					
					$conversion_id = (int) $lot['conversion_id'];
					
					if (
						! $in_range
						||
						! isset( $conversion_indexes[ $conversion_id ] )
					) {
						continue;
					}
					
					$conversion_index = $conversion_indexes[ $conversion_id ];
					$share_ratio      = (float) $conversions[ $conversion_index ]['share_ratio'];
					$allocated_qty    = $take * $share_ratio;
					
					if ( $allocated_qty <= 0 ) {
						continue;
					}
					
					$sales_amount = ! empty( $part['is_paid'] )
						? $sale_unit_price * $allocated_qty
						: 0.0;
					$cogs_amount  = $cost_per_item * $allocated_qty;
					$customer_id  = (int) $fulfillment['customer_id'];
					$order_id     = (int) $fulfillment['order_id'];
					
					$conversions[ $conversion_index ]['sold_qty'] += $allocated_qty;
					
					if ( ! empty( $part['is_paid'] ) ) {
						$conversions[ $conversion_index ]['sold_paid_qty'] += $allocated_qty;
					} else {
						$conversions[ $conversion_index ]['sold_free_qty'] += $allocated_qty;
					}
					
					$conversions[ $conversion_index ]['sales_amount']            += $sales_amount;
					$conversions[ $conversion_index ]['cogs_amount']             += $cogs_amount;
					$conversions[ $conversion_index ]['_buyers'][ $customer_id ] = TRUE;
					$conversions[ $conversion_index ]['_orders'][ $order_id ]    = TRUE;
					
					$customer_key = $order_id
					                . "\x1F"
					                . $product_code
					                . "\x1F"
					                . $product_id;
					
					if ( ! empty( $report['group_customers_by_conversion'] ) ) {
						$customer_key .= "\x1F" . $conversion_id;
					}
					
					if ( ! isset( $customers[ $customer_key ] ) ) {
						$customers[ $customer_key ] = [
							'conversion_id'       => $conversion_id,
							'customer_id'         => $customer_id,
							'customer_name'       => (string) $fulfillment['customer_name'],
							'order_id'            => $order_id,
							'order_number'        => (string) $fulfillment['order_number'],
							'created_at'          => (string) $fulfillment['order_created_at'],
							'fulfilled_at'        => $fulfilled_at,
							'unique_product_code' => $product_code,
							'wc_product_id'       => $product_id,
							'sold_qty'            => 0.0,
							'sold_paid_qty'       => 0.0,
							'sold_free_qty'       => 0.0,
							'sales_amount'        => 0.0,
							'cogs_amount'         => 0.0,
							'gross_profit'        => 0.0,
						];
					}
					
					$customers[ $customer_key ]['fulfilled_at'] = max(
						$customers[ $customer_key ]['fulfilled_at'],
						$fulfilled_at
					);
					$customers[ $customer_key ]['sold_qty']     += $allocated_qty;
					
					if ( ! empty( $part['is_paid'] ) ) {
						$customers[ $customer_key ]['sold_paid_qty'] += $allocated_qty;
					} else {
						$customers[ $customer_key ]['sold_free_qty'] += $allocated_qty;
					}
					
					$customers[ $customer_key ]['sales_amount'] += $sales_amount;
					$customers[ $customer_key ]['cogs_amount']  += $cogs_amount;
					$customers[ $customer_key ]['gross_profit'] =
						$customers[ $customer_key ]['sales_amount']
						-
						$customers[ $customer_key ]['cogs_amount'];
				}
			}
		}
		
		foreach ( $conversions as &$conversion ) {
			$conversion['buyers_count'] = count( $conversion['_buyers'] );
			$conversion['orders_count'] = count( $conversion['_orders'] );
			$conversion['gross_profit'] =
				$conversion['sales_amount']
				-
				$conversion['cogs_amount'];
			
			unset(
				$conversion['_buyers'],
				$conversion['_orders'],
				$conversion['conversion_pool_ratio']
			);
		}
		unset( $conversion );
		
		$customers = array_values( $customers );
		
		usort(
			$customers,
			static function( array $first, array $second ): int {
				return strcmp(
					(string) $second['fulfilled_at'],
					(string) $first['fulfilled_at']
				);
			}
		);
		
		$report['conversions'] = $conversions;
		$report['customers']   = $customers;
		
		return $report;
	}
	
	private function get_stock_single_batch_factor_report_base( int $batch_id, array $args = [] ): array {
		$batch_id = absint( $batch_id );
		
		if ( $batch_id <= 0 ) {
			return [
				'batch'       => NULL,
				'conversions' => [],
				'customers'   => [],
			];
		}
		
		$args = wp_parse_args( $args, [
			'date_from' => '',
			'date_to'   => '',
		] );
		
		$date_from = trim( (string) $args['date_from'] );
		$date_to   = trim( (string) $args['date_to'] );
		
		/*
		 * اینجا نیز تاریخ فروش واقعی = تاریخ Fulfillment Item
		 */
		$date_sale_sql = '';
		$date_binds    = [];
		
		if ( $date_from !== '' ) {
			$date_sale_sql .= ' AND fi.created_at >= %s';
			$date_binds[]  = $date_from . ' 00:00:00';
		}
		
		if ( $date_to !== '' ) {
			$date_sale_sql .= ' AND fi.created_at <= %s';
			$date_binds[]  = $date_to . ' 23:59:59';
		}
		
		/*
		 * ==========================================
		 * اطلاعات Batch
		 * ==========================================
		 */
		$batch = $this->db->get_row(
			$this->db->prepare(
				"
			SELECT
				b.*,
				
				rp.title AS raw_product_title,
				rp.base_uom,
				
				si.id AS invoice_id,
				si.invoice_no,
				si.issued_at,
				si.supplier_user_id,
				
				su.display_name AS supplier_name
			
			FROM {$this->batches} b
			
			INNER JOIN {$this->raw_products} rp
				ON rp.id = b.raw_product_id
			
			LEFT JOIN {$this->supplier_invoice_items} sii
				ON b.source_type = 'supplier_invoice_item'
				AND sii.id = b.source_id
			
			LEFT JOIN {$this->supplier_invoices} si
				ON si.id = sii.invoice_id
			
			LEFT JOIN {$this->db->users} su
				ON su.ID = si.supplier_user_id
			
			WHERE b.id = %d
			
			LIMIT 1
			",
				$batch_id
			),
			ARRAY_A
		);
		
		if ( ! $batch ) {
			return [
				'batch'       => NULL,
				'conversions' => [],
				'customers'   => [],
			];
		}
		
		$move_date_sql = '';
		$move_binds = [ $batch_id ];
		if ( $date_to !== '' ) {
			$move_date_sql = ' AND created_at <= %s';
			$move_binds[] = $date_to . ' 23:59:59';
		}
		$batch['current_weight'] = (float) $this->db->get_var( $this->db->prepare(
			"SELECT COALESCE(SUM(CASE WHEN direction = 'in' THEN qty_weight WHEN direction = 'out' THEN -qty_weight ELSE 0 END), 0)
			FROM {$this->storage_moves} WHERE batch_id = %d {$move_date_sql}", $move_binds
		) );
		$production_date_sql = $date_to !== '' ? ' AND sc.created_at <= %s' : '';
		
		/*
		 * ==========================================
		 * محصولات تبدیل‌شده مرتبط با Batch
		 * ==========================================
		 *
		 * LEFT JOIN استفاده شده تا حتی محصولی که هنوز
		 * فروشی نداشته نیز در لیست نمایش داده شود.
		 */
		$conversions_sql = "
		SELECT
			sc.id AS conversion_id,
			sc.unique_product_code,
			sc.wc_product_id,
			
			sc.qty_items,
			sc.weight_per_item,
			sc.total_cost,
			sc.unit_cost_final,
			sc.created_at,
			
			share.share_ratio,
			
			(
				sc.qty_items
				/
				NULLIF(production_pool.total_qty_items, 0)
			) AS conversion_pool_ratio,
			
			(
				sc.qty_items
				*
				sc.weight_per_item
				*
				share.share_ratio
			) AS allocated_weight,
			
			(
				sc.qty_items
				*
				share.share_ratio
			) AS allocated_items,
			
			(
				sc.total_cost
				*
				share.share_ratio
			) AS allocated_cost,
			
			/*
			 * تعداد واقعی فروش / ارسال متعلق به این Batch
			 */
			COALESCE(
				SUM(
					CASE
						WHEN o.id IS NOT NULL
						THEN
							(
								fi.shipped_paid_qty
								+
								fi.shipped_free_qty
							)
							*
							share.share_ratio
							*
							(
								sc.qty_items
								/
								NULLIF(production_pool.total_qty_items, 0)
							)
						
						ELSE 0
					END
				),
				0
			) AS sold_qty,
			
			/*
			 * تعداد پولی
			 */
			COALESCE(
				SUM(
					CASE
						WHEN o.id IS NOT NULL
						THEN
							fi.shipped_paid_qty
							*
							share.share_ratio
							*
							(
								sc.qty_items
								/
								NULLIF(production_pool.total_qty_items, 0)
							)
						
						ELSE 0
					END
				),
				0
			) AS sold_paid_qty,
			
			/*
			 * تعداد هدیه
			 */
			COALESCE(
				SUM(
					CASE
						WHEN o.id IS NOT NULL
						THEN
							fi.shipped_free_qty
							*
							share.share_ratio
							*
							(
								sc.qty_items
								/
								NULLIF(production_pool.total_qty_items, 0)
							)
						
						ELSE 0
					END
				),
				0
			) AS sold_free_qty,
			
			/*
			 * مبلغ فروش فقط برای تعداد پولی
			 */
			COALESCE(
				SUM(
					CASE
						WHEN
							o.id IS NOT NULL
							AND oi.qty_ordered > 0
						THEN
							(
								oi.final_amount
								/
								oi.qty_ordered
							)
							*
							fi.shipped_paid_qty
							*
							share.share_ratio
							*
							(
								sc.qty_items
								/
								NULLIF(production_pool.total_qty_items, 0)
							)
						
						ELSE 0
					END
				),
				0
			) AS sales_amount,
			
			/*
			 * بهای واقعی خروج از Inventory
			 */
			COALESCE(
				SUM(
					CASE
						WHEN o.id IS NOT NULL
						THEN
							fi.total_cost
							*
							share.share_ratio
							*
							(
								sc.qty_items
								/
								NULLIF(production_pool.total_qty_items, 0)
							)
						
						ELSE 0
					END
				),
				0
			) AS cogs_amount,
			
			COUNT(
				DISTINCT o.customer_id
			) AS buyers_count,
			
			COUNT(
				DISTINCT o.id
			) AS orders_count
		
		FROM (
			/*
			 * سهم این Batch از هر Processing Pack
			 */
			SELECT
				pi.batch_id,
				pi.pack_id,
				
				CAST(SUM(pi.qty_weight) AS DECIMAL(30,12))
				/
				NULLIF(pt.total_qty, 0) AS share_ratio
			
			FROM {$this->processing_pack_inputs} pi
			
			INNER JOIN (
				SELECT
					pack_id,
					SUM(qty_weight) AS total_qty
				
				FROM {$this->processing_pack_inputs}
				
				GROUP BY pack_id
			) pt
				ON pt.pack_id = pi.pack_id
			
			GROUP BY
				pi.batch_id,
				pi.pack_id
		) share
		
		INNER JOIN {$this->packaging_lots} pl
			ON pl.processing_pack_id = share.pack_id
		
		INNER JOIN {$this->shop_conversions} sc
			ON sc.packaging_lot_id = pl.id
		
		/*
		 * یک کد موجودی ممکن است طی چند Conversion شارژ شده باشد.
		 * فروش موجودی تجمیعی باید به نسبت تولید هر Conversion تقسیم شود؛
		 * در غیر این صورت یک Fulfillment برای تمام Conversionهای هم‌کد
		 * دوباره شمرده می‌شود.
		 */
		INNER JOIN (
			SELECT
				unique_product_code,
				wc_product_id,
				SUM(qty_items) AS total_qty_items
			
			FROM {$this->shop_conversions}
			
			GROUP BY
				unique_product_code,
				wc_product_id
		) production_pool
			ON production_pool.unique_product_code = sc.unique_product_code
			AND production_pool.wc_product_id = sc.wc_product_id
		
		/*
		 * پیدا کردن Inventory واقعی محصول
		 */
		LEFT JOIN {$this->inventory_balance} ib
			ON ib.unique_product_code = sc.unique_product_code
			AND ib.wc_product_id = sc.wc_product_id
		
		/*
		 * ارسال‌های واقعی این Inventory
		 */
		LEFT JOIN {$this->fulfillment_items} fi
			ON fi.inventory_id = ib.id
			AND (
				fi.shipped_paid_qty > 0
				OR fi.shipped_free_qty > 0
			)
		
		LEFT JOIN {$this->order_items} oi
			ON oi.id = fi.order_item_id
		
		LEFT JOIN {$this->fulfillments} f
			ON f.id = fi.fulfillment_id
			AND f.order_id = oi.order_id
			AND f.status <> 'canceled'
		
		/*
		 * فیلتر وضعیت و تاریخ اینجا قرار گرفته
		 * تا Conversion بدون فروش حذف نشود.
		 */
		LEFT JOIN {$this->orders} o
			ON o.id = oi.order_id
			AND f.id IS NOT NULL
			AND o.status IN (
				'registered',
				'shortage',
				'shipped'
			)
			{$date_sale_sql}
		
		WHERE share.batch_id = %d
			{$production_date_sql}
		
		GROUP BY
			sc.id,
			share.share_ratio,
			production_pool.total_qty_items
		
		ORDER BY sc.created_at DESC
	";
		
		$conversions_binds = array_merge(
			$date_binds,
			[ $batch_id ]
		);
		
		if ( $date_to !== '' ) {
			$conversions_binds[] = $date_to . ' 23:59:59';
		}
		
		$conversions = $this->db->get_results(
			$this->db->prepare(
				$conversions_sql,
				$conversions_binds
			),
			ARRAY_A
		);
		
		$conversions = $conversions ?: [];
		
		/*
		 * ==========================================
		 * مشتریان / سفارش‌های مرتبط با Batch
		 * ==========================================
		 */
		$customers_sql = "
		SELECT
			o.customer_id,
			cu.display_name AS customer_name,
			
			o.id AS order_id,
			o.order_number,
			o.created_at,
			
			MAX(fi.created_at) AS fulfilled_at,
			
			sc.unique_product_code,
			sc.wc_product_id,
			
			/*
			 * تعداد کل ارسال‌شده
			 */
			COALESCE(
				SUM(
					(
						fi.shipped_paid_qty
						+
						fi.shipped_free_qty
					)
					*
					share.share_ratio
					*
					(
						sc.qty_items
						/
						NULLIF(production_pool.total_qty_items, 0)
					)
				),
				0
			) AS sold_qty,
			
			/*
			 * تعداد پولی
			 */
			COALESCE(
				SUM(
					fi.shipped_paid_qty
					*
					share.share_ratio
					*
					(
						sc.qty_items
						/
						NULLIF(production_pool.total_qty_items, 0)
					)
				),
				0
			) AS sold_paid_qty,
			
			/*
			 * تعداد هدیه
			 */
			COALESCE(
				SUM(
					fi.shipped_free_qty
					*
					share.share_ratio
					*
					(
						sc.qty_items
						/
						NULLIF(production_pool.total_qty_items, 0)
					)
				),
				0
			) AS sold_free_qty,
			
			/*
			 * مبلغ فروش
			 */
			COALESCE(
				SUM(
					CASE
						WHEN oi.qty_ordered > 0
						THEN
							(
								oi.final_amount
								/
								oi.qty_ordered
							)
							*
							fi.shipped_paid_qty
							*
							share.share_ratio
							*
							(
								sc.qty_items
								/
								NULLIF(production_pool.total_qty_items, 0)
							)
						
						ELSE 0
					END
				),
				0
			) AS sales_amount,
			
			/*
			 * بهای تمام‌شده واقعی
			 */
			COALESCE(
				SUM(
					fi.total_cost
					*
					share.share_ratio
					*
					(
						sc.qty_items
						/
						NULLIF(production_pool.total_qty_items, 0)
					)
				),
				0
			) AS cogs_amount,
			
			/*
			 * سود ناخالص
			 */
			COALESCE(
				SUM(
					CASE
						WHEN oi.qty_ordered > 0
						THEN
							(
								(
									oi.final_amount
									/
									oi.qty_ordered
								)
								*
								fi.shipped_paid_qty
							)
							-
							fi.total_cost
						
						ELSE
							-fi.total_cost
					END
					*
					share.share_ratio
					*
					(
						sc.qty_items
						/
						NULLIF(production_pool.total_qty_items, 0)
					)
				),
				0
			) AS gross_profit
		
		FROM (
			SELECT
				pi.batch_id,
				pi.pack_id,
				
				CAST(SUM(pi.qty_weight) AS DECIMAL(30,12))
				/
				NULLIF(pt.total_qty, 0) AS share_ratio
			
			FROM {$this->processing_pack_inputs} pi
			
			INNER JOIN (
				SELECT
					pack_id,
					SUM(qty_weight) AS total_qty
				
				FROM {$this->processing_pack_inputs}
				
				GROUP BY pack_id
			) pt
				ON pt.pack_id = pi.pack_id
			
			GROUP BY
				pi.batch_id,
				pi.pack_id
		) share
		
		INNER JOIN {$this->packaging_lots} pl
			ON pl.processing_pack_id = share.pack_id
		
		INNER JOIN {$this->shop_conversions} sc
			ON sc.packaging_lot_id = pl.id
		
		INNER JOIN (
			SELECT
				unique_product_code,
				wc_product_id,
				SUM(qty_items) AS total_qty_items
			
			FROM {$this->shop_conversions}
			
			GROUP BY
				unique_product_code,
				wc_product_id
		) production_pool
			ON production_pool.unique_product_code = sc.unique_product_code
			AND production_pool.wc_product_id = sc.wc_product_id
		
		INNER JOIN {$this->inventory_balance} ib
			ON ib.unique_product_code = sc.unique_product_code
			AND ib.wc_product_id = sc.wc_product_id
		
		INNER JOIN {$this->fulfillment_items} fi
			ON fi.inventory_id = ib.id
			AND (
				fi.shipped_paid_qty > 0
				OR fi.shipped_free_qty > 0
			)
		
		INNER JOIN {$this->order_items} oi
			ON oi.id = fi.order_item_id
		
		INNER JOIN {$this->fulfillments} f
			ON f.id = fi.fulfillment_id
			AND f.order_id = oi.order_id
			AND f.status <> 'canceled'
		
		INNER JOIN {$this->orders} o
			ON o.id = oi.order_id
			AND o.status IN (
				'registered',
				'shortage',
				'shipped'
			)
		
		LEFT JOIN {$this->db->users} cu
			ON cu.ID = o.customer_id
		
		WHERE
			share.batch_id = %d
			{$date_sale_sql}
		
		GROUP BY
			o.customer_id,
			cu.display_name,
			o.id,
			o.order_number,
			o.created_at,
			sc.unique_product_code,
			sc.wc_product_id
		
		ORDER BY fulfilled_at DESC
	";
		
		/*
		 * این Query برخلاف conversions،
		 * batch_id قبل از date placeholders قرار گرفته.
		 */
		$customers_binds = array_merge(
			[ $batch_id ],
			$date_binds
		);
		
		$customers = $this->db->get_results(
			$this->db->prepare(
				$customers_sql,
				$customers_binds
			),
			ARRAY_A
		);
		
		$customers = $customers ?: [];
		
		/*
		 * ==========================================
		 * Cast
		 * ==========================================
		 */
		$batch['id']             = (int) $batch['id'];
		$batch['raw_product_id'] = (int) $batch['raw_product_id'];
		$batch['invoice_id']     = (int) $batch['invoice_id'];
		
		if ( isset( $batch['supplier_user_id'] ) ) {
			$batch['supplier_user_id'] = (int) $batch['supplier_user_id'];
		}
		
		foreach (
			[
				'initial_qty_weight',
				'unit_cost',
			] as $key
		) {
			if ( isset( $batch[ $key ] ) ) {
				$batch[ $key ] = (float) $batch[ $key ];
			}
		}
		
		foreach ( $conversions as &$conversion ) {
			foreach (
				[
					'conversion_id',
					'wc_product_id',
					'qty_items',
					'buyers_count',
					'orders_count',
				] as $key
			) {
				$conversion[ $key ] = (int) $conversion[ $key ];
			}
			
			foreach (
				[
					'weight_per_item',
					'total_cost',
					'unit_cost_final',
					'share_ratio',
					'conversion_pool_ratio',
					'allocated_weight',
					'allocated_items',
					'allocated_cost',
					'sold_qty',
					'sold_paid_qty',
					'sold_free_qty',
					'sales_amount',
					'cogs_amount',
				] as $key
			) {
				$conversion[ $key ] = (float) $conversion[ $key ];
			}
			
			$conversion['gross_profit'] =
				$conversion['sales_amount']
				-
				$conversion['cogs_amount'];
		}
		unset( $conversion );
		
		foreach ( $customers as &$customer ) {
			$customer['customer_id']   = (int) $customer['customer_id'];
			$customer['order_id']      = (int) $customer['order_id'];
			$customer['wc_product_id'] = (int) $customer['wc_product_id'];
			
			foreach (
				[
					'sold_qty',
					'sold_paid_qty',
					'sold_free_qty',
					'sales_amount',
					'cogs_amount',
					'gross_profit',
				] as $key
			) {
				$customer[ $key ] = (float) $customer[ $key ];
			}
		}
		unset( $customer );
		
		return [
			'batch'       => $batch,
			'conversions' => $conversions,
			'customers'   => $customers,
		];
	}
	
	public function get_sales_performance_chart_report( array $args = [] ): array {
		$args = wp_parse_args( $args, [
			'period'          => 'daily',
			'date_from'       => '',
			'date_to'         => '',
			'comparison_from' => '',
			'comparison_to'   => '',
		] );
		
		$period = sanitize_key( $args['period'] );
		
		if ( ! in_array( $period, [ 'daily', 'monthly', 'yearly' ], TRUE ) ) {
			$period = 'daily';
		}
		
		$ranges = $this->prepare_sales_chart_ranges(
			$period,
			trim( (string) $args['date_from'] ),
			trim( (string) $args['date_to'] )
		);

		// An explicitly selected comparison range replaces the automatically preceding period.
		$comparison_from = trim( (string) $args['comparison_from'] );
		$comparison_to   = trim( (string) $args['comparison_to'] );
		if ( $comparison_from !== '' && $comparison_to !== '' ) {
			$tz = wp_timezone();
			$compare_start = DateTimeImmutable::createFromFormat( 'Y-m-d H:i:s', $comparison_from . ' 00:00:00', $tz );
			$compare_end   = DateTimeImmutable::createFromFormat( 'Y-m-d H:i:s', $comparison_to . ' 23:59:59', $tz );
			if ( $compare_start && $compare_end ) {
				if ( $compare_end < $compare_start ) { $swap = $compare_start; $compare_start = $compare_end; $compare_end = $swap; }
				if ( $period === 'monthly' ) {
					[$csy,$csm] = kph_hr_calendar::from_gregorian( $compare_start->format('Y-m-d') );
					[$cey,$cem] = kph_hr_calendar::from_gregorian( $compare_end->format('Y-m-d') );
					$compare_start = $this->sales_jalali_start( $csy, $csm );
					[$ncy,$ncm] = $this->sales_jalali_from_index( $this->sales_jalali_month_index($cey,$cem)+1 );
					$compare_end = $this->sales_jalali_start( $ncy, $ncm )->modify('-1 second');
				} elseif ( $period === 'yearly' ) {
					[$csy] = kph_hr_calendar::from_gregorian( $compare_start->format('Y-m-d') );
					[$cey] = kph_hr_calendar::from_gregorian( $compare_end->format('Y-m-d') );
					$compare_start = $this->sales_jalali_start( $csy, 1 );
					$compare_end = $this->sales_jalali_start( $cey + 1, 1 )->modify('-1 second');
				}
				$compare_buckets = $this->build_sales_chart_buckets( $period, $compare_start, $compare_end );
				$ranges['comparison_custom'] = count( $compare_buckets ) === count( $ranges['buckets'] );
				if ( $ranges['comparison_custom'] ) {
					foreach ( $ranges['buckets'] as $index => &$current_bucket ) {
						$current_bucket['previous_key'] = $compare_buckets[$index]['key'] ?? '';
					}
					unset( $current_bucket );
					$ranges['previous_start_sql'] = $compare_start->format( 'Y-m-d H:i:s' );
					$ranges['previous_end_sql']   = $compare_end->format( 'Y-m-d H:i:s' );
					$ranges['previous_label']     = kph_hr_calendar::display( $compare_start->format('Y-m-d') ) . ' تا ' . kph_hr_calendar::display( $compare_end->format('Y-m-d') );
				} else {
					$ranges['comparison_error'] = 'تعداد دوره‌های بازه مقایسه باید با تعداد دوره‌های گزارش برابر باشد.';
				}
			}
		}
		
		$current_rows = $this->get_sales_chart_rows(
			$period,
			$ranges['current_start_sql'],
			$ranges['current_end_sql']
		);
		
		$previous_rows = $this->get_sales_chart_rows(
			$period,
			$ranges['previous_start_sql'],
			$ranges['previous_end_sql']
		);
		
		$current_map  = [];
		$previous_map = [];
		
		foreach ( $current_rows as $row ) {
			$current_map[ $row['bucket_key'] ] = $row;
		}
		
		foreach ( $previous_rows as $row ) {
			$previous_map[ $row['bucket_key'] ] = $row;
		}
		
		$labels          = [];
		$current_sales   = [];
		$previous_sales  = [];
		$current_profit  = [];
		$previous_profit = [];
		$current_orders  = [];
		$previous_orders = [];
		
		foreach ( $ranges['buckets'] as $bucket ) {
			$current_key  = $bucket['current_key'];
			$previous_key = $bucket['previous_key'];
			
			$current_row = $current_map[ $current_key ] ?? [
					'total_sales_amount' => 0,
					'total_cogs'         => 0,
					'gross_profit'       => 0,
					'order_count'        => 0,
					'shipped_qty'        => 0,
				];
			
			$previous_row = $previous_map[ $previous_key ] ?? [
					'total_sales_amount' => 0,
					'total_cogs'         => 0,
					'gross_profit'       => 0,
					'order_count'        => 0,
					'shipped_qty'        => 0,
				];
			
			$labels[] = $bucket['label'];
			
			$current_sales[]   = round( (float) $current_row['total_sales_amount'] );
			$previous_sales[]  = round( (float) $previous_row['total_sales_amount'] );
			$current_profit[]  = round( (float) $current_row['gross_profit'] );
			$previous_profit[] = round( (float) $previous_row['gross_profit'] );
			$current_orders[]  = (int) $current_row['order_count'];
			$previous_orders[] = (int) $previous_row['order_count'];
		}
		
		$current_summary = [
			'sales'       => array_sum( $current_sales ),
			'profit'      => array_sum( $current_profit ),
			'order_count' => array_sum( $current_orders ),
		];
		
		$previous_summary = [
			'sales'       => array_sum( $previous_sales ),
			'profit'      => array_sum( $previous_profit ),
			'order_count' => array_sum( $previous_orders ),
		];
		
		$current_summary['profit_percent'] = $current_summary['sales'] > 0
			? round( ( $current_summary['profit'] / $current_summary['sales'] ) * 100, 2 )
			: 0;
		
		$previous_summary['profit_percent'] = $previous_summary['sales'] > 0
			? round( ( $previous_summary['profit'] / $previous_summary['sales'] ) * 100, 2 )
			: 0;
		
		return [
			'period'  => $period,
			'ranges'  => $ranges,
			'summary' => [
				'current'  => $current_summary,
				'previous' => $previous_summary,
				'changes'  => [
					'sales'          => $this->calc_sales_percent_change( $current_summary['sales'], $previous_summary['sales'] ),
					'profit'         => $this->calc_sales_percent_change( $current_summary['profit'], $previous_summary['profit'] ),
					'order_count'    => $this->calc_sales_percent_change( $current_summary['order_count'], $previous_summary['order_count'] ),
					'profit_percent' => round( $current_summary['profit_percent'] - $previous_summary['profit_percent'], 2 ),
				],
			],
			'charts'  => [
				'sales'  => [
					'labels' => $labels,
					'data'   => [
						$current_sales,
						$previous_sales,
					],
				],
				'profit' => [
					'labels' => $labels,
					'data'   => [
						$current_profit,
						$previous_profit,
					],
				],
				'orders' => [
					'labels' => $labels,
					'data'   => [
						$current_orders,
						$previous_orders,
					],
				],
			],
		];
	}
	
	private function get_sales_chart_rows( string $period, string $date_from, string $date_to ): array {
		$sql = "
		SELECT DATE(o.created_at) AS day_key,
			COUNT(DISTINCT o.id) AS order_count,
			COALESCE(SUM(oi.shipped_paid_qty + oi.shipped_free_qty), 0) AS shipped_qty,
			COALESCE(SUM(CASE WHEN oi.qty_ordered > 0 THEN (oi.final_amount / oi.qty_ordered) * oi.shipped_paid_qty ELSE 0 END), 0) AS total_sales_amount,
			COALESCE(SUM(oi.cogs_total), 0) AS total_cogs,
			COALESCE(SUM(CASE WHEN oi.qty_ordered > 0 THEN ((oi.final_amount / oi.qty_ordered) * oi.shipped_paid_qty) - oi.cogs_total ELSE 0 - oi.cogs_total END), 0) AS gross_profit
		FROM {$this->order_items} oi
		INNER JOIN {$this->orders} o ON o.id = oi.order_id
		WHERE o.status IN ('registered','shipped','shortage') AND o.created_at >= %s AND o.created_at <= %s
		GROUP BY DATE(o.created_at) ORDER BY day_key ASC";
		$daily = $this->db->get_results( $this->db->prepare( $sql, $date_from, $date_to ), ARRAY_A ) ?: [];
		$grouped = [];
		foreach ( $daily as $row ) {
			$day = (string) $row['day_key'];
			if ( $period === 'daily' ) { $key = $day; }
			else {
				[$jy,$jm] = kph_hr_calendar::from_gregorian( $day );
				$key = $period === 'yearly' ? sprintf('%04d',$jy) : sprintf('%04d-%02d',$jy,$jm);
			}
			if ( ! isset($grouped[$key]) ) { $grouped[$key] = ['bucket_key'=>$key,'order_count'=>0,'shipped_qty'=>0,'total_sales_amount'=>0,'total_cogs'=>0,'gross_profit'=>0]; }
			foreach ( ['order_count','shipped_qty','total_sales_amount','total_cogs','gross_profit'] as $field ) { $grouped[$key][$field] += (float)($row[$field]??0); }
		}
		return array_values($grouped);
	}

	private function sales_jalali_start( int $jy, int $jm = 1 ): DateTimeImmutable {
		$greg = nooshika_jalali_to_gregorian( sprintf('%04d-%02d-01',$jy,$jm) );
		return new DateTimeImmutable( $greg . ' 00:00:00', wp_timezone() );
	}

	private function sales_jalali_month_index( int $jy, int $jm ): int { return $jy * 12 + ($jm - 1); }
	private function sales_jalali_from_index( int $index ): array { $jy = (int) floor($index / 12); $jm = ($index % 12) + 1; return [$jy,$jm]; }

	private function prepare_sales_chart_ranges( string $period, string $date_from = '', string $date_to = '' ): array {
		$tz = wp_timezone();
		$today = new DateTimeImmutable('today',$tz);
		$start = $date_from ? DateTimeImmutable::createFromFormat('Y-m-d H:i:s',$date_from.' 00:00:00',$tz) : false;
		$end = $date_to ? DateTimeImmutable::createFromFormat('Y-m-d H:i:s',$date_to.' 23:59:59',$tz) : false;
		if ( ! $start || ! $end ) { $start=$today; $end=$today; }
		if ( $end < $start ) { $tmp=$start; $start=$end; $end=$tmp; }
		if ( $period === 'monthly' ) {
			[$sy,$sm] = kph_hr_calendar::from_gregorian($start->format('Y-m-d'));
			[$ey,$em] = kph_hr_calendar::from_gregorian($end->format('Y-m-d'));
			$start = $this->sales_jalali_start($sy,$sm);
			[$ny,$nm] = $this->sales_jalali_from_index($this->sales_jalali_month_index($ey,$em)+1);
			$end = $this->sales_jalali_start($ny,$nm)->modify('-1 second');
		} elseif ( $period === 'yearly' ) {
			[$sy] = kph_hr_calendar::from_gregorian($start->format('Y-m-d'));
			[$ey] = kph_hr_calendar::from_gregorian($end->format('Y-m-d'));
			$start = $this->sales_jalali_start($sy,1);
			$end = $this->sales_jalali_start($ey+1,1)->modify('-1 second');
		} else { $start=$start->setTime(0,0,0); $end=$end->setTime(23,59,59); }
		$current_buckets = $this->build_sales_chart_buckets($period,$start,$end);
		$count = max(1,count($current_buckets));
		if ( $period === 'monthly' ) {
			[$jy,$jm] = kph_hr_calendar::from_gregorian($start->format('Y-m-d'));
			$previous_end_index = $this->sales_jalali_month_index($jy,$jm)-1;
			[$pey,$pem] = $this->sales_jalali_from_index($previous_end_index);
			[$psy,$psm] = $this->sales_jalali_from_index($previous_end_index-$count+1);
			$previous_start = $this->sales_jalali_start($psy,$psm);
			$previous_end = $this->sales_jalali_start(...$this->sales_jalali_from_index($previous_end_index+1))->modify('-1 second');
		} elseif ( $period === 'yearly' ) {
			[$jy] = kph_hr_calendar::from_gregorian($start->format('Y-m-d'));
			$previous_start = $this->sales_jalali_start($jy-$count,1);
			$previous_end = $this->sales_jalali_start($jy,1)->modify('-1 second');
		} else {
			$previous_end=$start->modify('-1 second');
			$previous_start=$previous_end->modify('-'.($count-1).' days')->setTime(0,0,0);
		}
		$previous_buckets=$this->build_sales_chart_buckets($period,$previous_start,$previous_end);
		$buckets=[];
		foreach($current_buckets as $i=>$bucket){$prev=$previous_buckets[$i]??['key'=>''];$buckets[]=['label'=>$bucket['label'],'current_key'=>$bucket['key'],'previous_key'=>$prev['key']];}
		return [
			'current_start_sql'=>$start->format('Y-m-d H:i:s'),'current_end_sql'=>$end->format('Y-m-d H:i:s'),
			'previous_start_sql'=>$previous_start->format('Y-m-d H:i:s'),'previous_end_sql'=>$previous_end->format('Y-m-d H:i:s'),
			'current_label'=>kph_hr_calendar::display($start->format('Y-m-d')).' تا '.kph_hr_calendar::display($end->format('Y-m-d')),
			'previous_label'=>kph_hr_calendar::display($previous_start->format('Y-m-d')).' تا '.kph_hr_calendar::display($previous_end->format('Y-m-d')),
			'buckets'=>$buckets,
		];
	}

	private function build_sales_chart_buckets( string $period, DateTimeImmutable $start, DateTimeImmutable $end ): array {
		$buckets=[];
		if($period==='monthly'){
			[$jy,$jm]=kph_hr_calendar::from_gregorian($start->format('Y-m-d'));
			[$ey,$em]=kph_hr_calendar::from_gregorian($end->format('Y-m-d'));
			$cursor=$this->sales_jalali_month_index($jy,$jm);$last=$this->sales_jalali_month_index($ey,$em);
			for(;$cursor<=$last;$cursor++){[$y,$m]=$this->sales_jalali_from_index($cursor);$key=sprintf('%04d-%02d',$y,$m);$buckets[]=['key'=>$key,'label'=>$key];}
			return $buckets;
		}
		if($period==='yearly'){
			[$sy]=kph_hr_calendar::from_gregorian($start->format('Y-m-d'));[$ey]=kph_hr_calendar::from_gregorian($end->format('Y-m-d'));
			for($y=$sy;$y<=$ey;$y++){$key=(string)$y;$buckets[]=['key'=>$key,'label'=>$key];}
			return $buckets;
		}
		$cursor=$start->setTime(0,0,0);$last=$end->setTime(0,0,0);
		while($cursor<=$last){$key=$cursor->format('Y-m-d');$buckets[]=['key'=>$key,'label'=>kph_hr_calendar::display($key)];$cursor=$cursor->modify('+1 day');}
		return $buckets;
	}

	private function calc_sales_percent_change( $current, $previous ): float {
		$current  = (float) $current;
		$previous = (float) $previous;
		
		if ( $previous == 0 ) {
			return $current > 0 ? 100 : 0;
		}
		
		return round( ( ( $current - $previous ) / abs( $previous ) ) * 100, 2 );
	}
	
	public function temp_rebuild_inventory_balance_from_logs(): array {
		$this->db->query( 'START TRANSACTION' );
		
		try {
			/*
			 * ابتدا موجودی فعلی پاک می‌شود.
			 */
			$deleted = $this->db->query(
				"DELETE FROM {$this->inventory_balance}"
			);
			
			if ( $deleted === FALSE ) {
				throw new RuntimeException(
					'پاک کردن موجودی فعلی ناموفق بود: ' . $this->db->last_error
				);
			}
			
			/*
			 * بازسازی موجودی بر اساس:
			 *
			 * unique_product_code + wc_product_id
			 */
			$sql = "
			INSERT INTO {$this->inventory_balance} (
				unique_product_code,
				wc_product_id,
				qty_available,
				inventory_value,
				avg_unit_cost,
				created_at,
				updated_at
			)

			SELECT
				l.unique_product_code,
				l.wc_product_id,

				SUM(l.change_qty) AS qty_available,

				SUM(l.total_cost) AS inventory_value,

				CASE
					WHEN SUM(l.change_qty) > 0
					THEN
						SUM(l.total_cost)
						/
						SUM(l.change_qty)
					ELSE 0
				END AS avg_unit_cost,

				MIN(l.created_at) AS created_at,
				MAX(l.created_at) AS updated_at

			FROM {$this->inventory_log} l

			WHERE
				l.unique_product_code IS NOT NULL
				AND l.unique_product_code <> ''
				AND l.wc_product_id > 0

			GROUP BY
				l.unique_product_code,
				l.wc_product_id
		";
			
			$inserted = $this->db->query( $sql );
			
			if ( $inserted === FALSE ) {
				throw new RuntimeException(
					'بازسازی موجودی ناموفق بود: ' . $this->db->last_error
				);
			}
			
			$this->db->query( 'COMMIT' );
			
			return [
				'status'  => 'success',
				'message' => 'موجودی انبار با موفقیت از روی لاگ‌ها بازسازی شد.',
				'data'    => [
					'rows' => (int) $inserted,
				],
			];
		}
		catch ( Throwable $e ) {
			$this->db->query( 'ROLLBACK' );
			
			return [
				'status'  => 'error',
				'message' => $e->getMessage(),
			];
		}
	}
	
}
