<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$per_page_key    = basename( __FILE__, '.php' );
$per_page_key    = "kph_{$per_page_key}_per_page";
$current_user_id = get_current_user_id();

$defaults = [
	'page_number'    => 1,
	'per_page'       => get_user_meta( $current_user_id, $per_page_key, TRUE ) ?: 20,
	'date'           => [
		'from' => '',
		'to'   => '',
	],
	'date_from'      => '',
	'date_to'        => '',
	'raw_product_id' => '',
	'customer_id'    => '',
	'batch_id'       => '',
	'search'         => '',
];

$args = wp_parse_args( $_REQUEST, $defaults );

foreach ( $args as $key => $value ) {
	if ( ! is_array( $value ) && $value == 0 ) {
		$args[ $key ] = '';
	}
}

$has_filter = kph_page_has_filter( $args, $defaults );

extract( $args );

update_user_meta( $current_user_id, $per_page_key, $per_page );

$date_from = $date['from'] ?? $date_from ?? '';
$date_to   = $date['to'] ?? $date_to ?? '';

$date_from_g = $date_from ? nooshika_jalali_to_gregorian( $date_from ) : '';
$date_to_g   = $date_to ? nooshika_jalali_to_gregorian( $date_to ) : '';

$DB = new kph_db();

$raw_products_result = $DB->get_raw_products( [
	'per_page'  => 200,
	'is_active' => NULL,
	'orderby'   => 'title',
	'order'     => 'ASC',
] );

$raw_products = array_values(array_filter($raw_products_result['items'] ?? [],fn($r)=>!$DB->is_supply_raw_product((int)$r['id'])));

$raw_options = [ 0 => 'همه مواد اولیه' ];
foreach ( $raw_products as $raw_product ) {
	$raw_options[ $raw_product['id'] ] = $raw_product['title'];
}

$common_args = [
	'date_from'      => $date_from_g,
	'date_to'        => $date_to_g,
	'raw_product_id' => $raw_product_id,
	'search'         => $search,
];

$repository_report = $DB->get_stock_repository_report( $common_args );
$saloon_report     = $DB->get_stock_saloon_report( $common_args );
$finished_report   = $DB->get_stock_finished_goods_report( [
	'date_from' => $date_from_g,
	'date_to'   => $date_to_g,
	'search'    => $search,
] );

$trace_report = $DB->get_stock_inventory_trace_report( [
	'date_from'   => $date_from_g,
	'date_to'     => $date_to_g,
	'customer_id' => $customer_id,
	'search'      => $search,
	'page'        => $page_number,
	'per_page'    => $per_page,
] );

$batches_report = $DB->get_stock_batches_factor_report( [
	'date_from'      => $date_from_g,
	'date_to'        => $date_to_g,
	'raw_product_id' => $raw_product_id,
	'search'         => $search,
	'per_page'       => 50,
] );

$selected_batch_report = NULL;

if ( absint( $batch_id ) > 0 ) {
	$selected_batch_report = $DB->get_stock_single_batch_factor_report( absint( $batch_id ), [
		'date_from' => $date_from_g,
		'date_to'   => $date_to_g,
	] );
}

if ( ! function_exists( 'kph_stock_num' ) ) {
	function kph_stock_num( $value, int $decimals = 0 ): string {
		$value = (float) $value;
		
		if ( $decimals > 0 ) {
			return rtrim( rtrim( number_format( $value, $decimals ), '0' ), '.' );
		}
		
		return number_format( $value );
	}
}

if ( ! function_exists( 'kph_stock_date' ) ) {
	function kph_stock_date( $date ): string {
		if ( empty( $date ) ) {
			return '-';
		}
		
		return date_i18n( 'Y/m/d', strtotime( $date ) );
	}
}

if ( ! function_exists( 'kph_stock_report_link' ) ) {
	function kph_stock_report_link( array $params = [] ): string {
		$query = [];
		
		foreach ( $params as $key => $value ) {
			if ( $value === '' || $value === NULL || $value === 0 || $value === '0' ) {
				continue;
			}
			
			$query[] = $key . '=' . $value;
		}
		
		return '/crm/reports-stock' . ( $query ? '?' . implode( '&', $query ) : '' );
	}
}

if ( ! function_exists( 'kph_stock_print_link' ) ) {
	function kph_stock_print_link( string $section, array $params = [] ): string {
		return add_query_arg(
			array_filter(
				array_merge( [
					'action'    => 'print',
					'type'      => 'stock',
					'section'   => sanitize_key( $section ),
				], $params ),
				static function( $value ) {
					return $value !== '' && $value !== 0;
				}
			),
			home_url( '/crm' )
		);
	}
}

if ( ! function_exists( 'kph_stock_print_button' ) ) {
	function kph_stock_print_button( string $section, array $params = [], string $title = 'پرینت جدول' ): string {
		return sprintf(
			'<a href="%s" target="_blank" rel="noopener" class="btn btn-sm btn-icon btn-outline-primary ms-1" title="%s"><em class="icon ni ni-printer"></em></a>',
			esc_url( kph_stock_print_link( $section, $params ) ),
			esc_attr( $title )
		);
	}
}

$stock_print_filters = [
	'date_from'      => $date_from,
	'date_to'        => $date_to,
	'raw_product_id' => absint( $raw_product_id ),
	'customer_id'    => absint( $customer_id ),
	'search'         => sanitize_text_field( (string) $search ),
];

$trace_items      = $trace_report['items'];
$trace_pagination = $trace_report['pagination'];

$repository_summary = $repository_report['summary'];
$saloon_summary     = $saloon_report['summary'];
$finished_summary   = $finished_report['summary'];

?>
    <div class="nk-block-head nk-block-head-sm">
        <div class="nk-block-between">
            <div class="nk-block-head-content">
                <h3 class="nk-block-title page-title">
					گزارش انبارها
					<?php echo kph_stock_print_button( 'all', $stock_print_filters, 'پرینت کل گزارش' ); ?>
				</h3>
                <div class="nk-block-des text-soft">
                    <p class="mb-0">گزارش مخزن، سالن، انبار محصول، رهگیری کالا و تحلیل فاکتورهای مواد اولیه.</p>
                </div>
            </div>

            <div class="card-tools">
                <ul class="btn-toolbar gx-1">
                    <li>
						<?php
						$filter_fields = [
							[
								'type'  => 'date-range',
								'label' => 'بازه گزارش',
								'name'  => 'date',
								'value' => [
									'from' => $date_from ?? '',
									'to'   => $date_to ?? '',
								],
							],
							[
								'type'    => 'select',
								'label'   => 'ماده اولیه',
								'name'    => 'raw_product_id',
								'value'   => $raw_product_id,
								'col'     => 6,
								'options' => $raw_options,
							],
						];
						echo kph_get_template( 'components/filter-dropdown.php', [
							'has_filter'    => $has_filter,
							'filter_fields' => $filter_fields,
						] );
						?>
                    </li>

                    <li class="btn-toolbar-sep"></li>

                    <li>
						<?php
						echo kph_get_template( 'components/per-page-selector.php', [
							'per_page' => $per_page,
						] );
						?>
                    </li>
                </ul>
            </div>
        </div>
    </div>

    <div class="nk-block">
        <div class="row g-gs">
            <div class="col-md-3">
                <div class="card card-full">
                    <div class="card-inner">
                        <h6 class="title">موجودی مخزن</h6>
                        <div
                            class="amount"><?php echo kph_stock_num( $repository_summary['current_weight'], 3 ); ?></div>
                        <span
                            class="sub-text"><?php echo number_format( $repository_summary['current_value'] ); ?> ریال</span>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card card-full">
                    <div class="card-inner">
                        <h6 class="title">موجودی سالن</h6>
                        <div class="amount"><?php echo kph_stock_num( $saloon_summary['current_weight'], 3 ); ?></div>
                        <span
                            class="sub-text">تبدیل‌شده: <?php echo kph_stock_num( $saloon_summary['converted_to_product'], 3 ); ?></span>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card card-full">
                    <div class="card-inner">
                        <h6 class="title">موجودی محصول آماده</h6>
                        <div class="amount"><?php echo number_format( $finished_summary['current_qty'] ); ?></div>
                        <span
                            class="sub-text"><?php echo number_format( $finished_summary['current_value'] ); ?> ریال</span>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card card-full">
                    <div class="card-inner">
                        <h6 class="title">خروج فروش در بازه</h6>
                        <div
                            class="amount text-danger"><?php echo number_format( $finished_summary['sale_out_qty'] ); ?></div>
                        <span
                            class="sub-text">بهای تمام‌شده: <?php echo number_format( $finished_summary['sale_cogs'] ); ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="nk-block-head nk-block-head-sm">
        <div class="nk-block-between">
            <div class="nk-block-head-content">
                <h3 class="nk-block-title page-title">
					مخزن مواد اولیه
					<?php echo kph_stock_print_button( 'repository', $stock_print_filters ); ?>
				</h3>
            </div>
        </div>
    </div>
    <div class="nk-block">
        <div class="card card-stretch">
            <div class="card-inner p-0 overflow-auto">
                <div class="nk-tb-list nk-tb-ulist is-compact">
                    <div class="nk-tb-item nk-tb-head">
                        <div class="nk-tb-col"><span class="sub-text">ماده اولیه</span></div>
                        <div class="nk-tb-col"><span class="sub-text">ورودی خرید</span></div>
                        <div class="nk-tb-col"><span class="sub-text">خروج فرآوری</span></div>
                        <div class="nk-tb-col"><span class="sub-text">برگشتی</span></div>
                        <div class="nk-tb-col"><span class="sub-text">ضایعات</span></div>
                        <div class="nk-tb-col"><span class="sub-text">موجودی</span></div>
                        <div class="nk-tb-col"><span class="sub-text">ارزش موجودی</span></div>
                    </div>
					<?php if ( empty( $repository_report['items'] ) ) { ?>
                        <div class="no-item-found">گزارشی یافت نشد</div>
					<?php } else { ?>
						<?php foreach ( $repository_report['items'] as $item ) { ?>
                            <div class="nk-tb-item">
                                <div class="nk-tb-col">
									<span class="tb-lead"><?php echo esc_html( $item['raw_product_title'] ); ?></span>
                                    <span
                                        class="sub-text"><?php echo esc_html( $item['raw_product_code'] ?: '-' ); ?></span>
                                </div>
                                <div class="nk-tb-col"><?php echo kph_stock_num( $item['purchase_in'], 3 ); ?></div>
                                <div class="nk-tb-col"><?php echo kph_stock_num( $item['processing_out'], 3 ); ?></div>
                                <div
                                    class="nk-tb-col"><?php echo kph_stock_num( $item['processing_return'], 3 ); ?></div>
                                <div
                                    class="nk-tb-col text-danger"><?php echo kph_stock_num( $item['waste'], 3 ); ?></div>
                                <div class="nk-tb-col">
                                    <strong><?php echo kph_stock_num( $item['current_weight'], 3 ); ?></strong></div>
                                <div class="nk-tb-col"><?php echo number_format( $item['current_value'] ); ?></div>
                            </div>
						<?php } ?>
					<?php } ?>
                </div>
            </div>
        </div>
    </div>

    <div class="nk-block-head nk-block-head-sm">
        <div class="nk-block-between">
            <div class="nk-block-head-content">
                <h3 class="nk-block-title page-title">
					سالن بسته‌بندی / فرآوری
					<?php echo kph_stock_print_button( 'saloon', $stock_print_filters ); ?>
				</h3>
            </div>
        </div>
    </div>

    <div class="nk-block">
        <div class="card card-stretch">
            <div class="card-inner p-0 overflow-auto">
                <div class="nk-tb-list nk-tb-ulist is-compact">
                    <div class="nk-tb-item nk-tb-head">
                        <div class="nk-tb-col"><span class="sub-text">ماده اولیه</span></div>
                        <div class="nk-tb-col"><span class="sub-text">ورودی از فرآوری</span></div>
                        <div class="nk-tb-col"><span class="sub-text">تبدیل به محصول</span></div>
                        <div class="nk-tb-col"><span class="sub-text">برگشت به فرآوری</span></div>
                        <div class="nk-tb-col"><span class="sub-text">ضایعات</span></div>
                        <div class="nk-tb-col"><span class="sub-text">موجودی سالن</span></div>
                    </div>
					
					<?php if ( empty( $saloon_report['items'] ) ) { ?>
                        <div class="no-item-found">گزارشی یافت نشد</div>
					<?php } else { ?>
						<?php foreach ( $saloon_report['items'] as $item ) { ?>
                            <div class="nk-tb-item">
                                <div class="nk-tb-col">
									<span class="tb-lead"><?php echo esc_html( $item['raw_product_title'] ); ?></span>
                                    <span
                                        class="sub-text"><?php echo esc_html( $item['raw_product_code'] ?: '-' ); ?></span>
                                </div>
                                <div class="nk-tb-col"><?php echo kph_stock_num( $item['from_processing'], 3 ); ?></div>
                                <div
                                    class="nk-tb-col"><?php echo kph_stock_num( $item['converted_to_product'], 3 ); ?></div>
                                <div
                                    class="nk-tb-col"><?php echo kph_stock_num( $item['return_to_processing'], 3 ); ?></div>
                                <div
                                    class="nk-tb-col text-danger"><?php echo kph_stock_num( $item['waste'], 3 ); ?></div>
                                <div class="nk-tb-col">
                                    <strong><?php echo kph_stock_num( $item['current_weight'], 3 ); ?></strong></div>
                            </div>
						<?php } ?>
					<?php } ?>
                </div>
            </div>
        </div>
    </div>

    <div class="nk-block-head nk-block-head-sm">
        <div class="nk-block-between">
            <div class="nk-block-head-content">
                <h3 class="nk-block-title page-title">
					انبار محصول آماده
					<?php echo kph_stock_print_button( 'finished', $stock_print_filters ); ?>
				</h3>
            </div>
        </div>
    </div>

    <div class="nk-block">
        <div class="card card-stretch">
            <div class="card-inner p-0 overflow-auto">
                <div class="nk-tb-list nk-tb-ulist is-compact">
                    <div class="nk-tb-item nk-tb-head">
                        <div class="nk-tb-col"><span class="sub-text">محصول</span></div>
                        <div class="nk-tb-col"><span class="sub-text">کد یکتا</span></div>
                        <div class="nk-tb-col"><span class="sub-text">ورودی تولید</span></div>
                        <div class="nk-tb-col"><span class="sub-text">خروج فروش</span></div>
                        <div class="nk-tb-col"><span class="sub-text">موجودی</span></div>
                        <div class="nk-tb-col"><span class="sub-text">ارزش موجودی</span></div>
                    </div>
					
					<?php if ( empty( $finished_report['items'] ) ) { ?>
                        <div class="no-item-found">گزارشی یافت نشد</div>
					<?php } else { ?>
						<?php foreach ( $finished_report['items'] as $item ) { ?>
                            <div class="nk-tb-item">
                                <div class="nk-tb-col">
									<span class="tb-lead"><?php echo esc_html( $item['product_title'] ); ?></span>
                                    <span class="sub-text">#<?php echo esc_html( $item['wc_product_id'] ); ?></span>
                                </div>
                                <div class="nk-tb-col"><?php echo esc_html( $item['unique_product_code'] ); ?></div>
                                <div
                                    class="nk-tb-col text-success"><?php echo number_format( $item['production_in_qty'] ); ?></div>
                                <div
                                    class="nk-tb-col text-danger"><?php echo number_format( $item['sale_out_qty'] ); ?></div>
                                <div class="nk-tb-col">
                                    <strong><?php echo number_format( $item['current_qty'] ); ?></strong></div>
                                <div class="nk-tb-col"><?php echo number_format( $item['current_value'] ); ?></div>
                            </div>
						<?php } ?>
					<?php } ?>
                </div>
            </div>
        </div>
    </div>

    <div class="nk-block-head nk-block-head-sm">
        <div class="nk-block-between">
            <div class="nk-block-head-content">
                <h3 class="nk-block-title page-title">
					رهگیری ورودی و خروجی محصول
					<?php echo kph_stock_print_button( 'trace', $stock_print_filters ); ?>
				</h3>
                <div class="nk-block-des text-soft">
                    <p class="mb-0">از این جدول مشخص می‌شود هر کالا بابت تولید وارد شده یا برای کدام سفارش و مشتری خارج
                        شده است.</p>
                </div>
            </div>
        </div>
    </div>

    <div class="nk-block">
        <div class="card card-stretch">
            <div class="card-inner p-0 overflow-auto">
                <div class="nk-tb-list nk-tb-ulist is-compact">
                    <div class="nk-tb-item nk-tb-head">
                        <div class="nk-tb-col"><span class="sub-text">تاریخ</span></div>
                        <div class="nk-tb-col"><span class="sub-text">محصول</span></div>
                        <div class="nk-tb-col"><span class="sub-text">کد</span></div>
                        <div class="nk-tb-col"><span class="sub-text">نوع</span></div>
                        <div class="nk-tb-col"><span class="sub-text">تعداد</span></div>
                        <div class="nk-tb-col"><span class="sub-text">مشتری / سفارش</span></div>
                        <div class="nk-tb-col"><span class="sub-text">بهای تمام‌شده</span></div>
                    </div>
					
					<?php if ( empty( $trace_items ) ) { ?>
                        <div class="no-item-found">گردشی یافت نشد</div>
					<?php } else { ?>
						<?php foreach ( $trace_items as $item ) { ?>
							<?php
							$is_in      = (int) $item['change_qty'] > 0;
							$type_label = $is_in ? 'ورودی' : 'خروجی';
							$type_class = $is_in ? 'text-success' : 'text-danger';
							?>
                            <div class="nk-tb-item">
                                <div class="nk-tb-col"><?php echo kph_stock_date( $item['created_at'] ); ?></div>
                                <div class="nk-tb-col">
									<span class="tb-lead"><?php echo esc_html( $item['product_title'] ); ?></span>
                                    <span
                                        class="sub-text"><?php echo esc_html( $item['ref_type'] ); ?> #<?php echo esc_html( $item['ref_id'] ); ?></span>
                                </div>
                                <div class="nk-tb-col"><?php echo esc_html( $item['unique_product_code'] ); ?></div>
                                <div class="nk-tb-col">
                                    <span
                                        class="<?php echo esc_attr( $type_class ); ?>"><?php echo esc_html( $type_label ); ?></span>
                                </div>
                                <div
                                    class="nk-tb-col"><?php echo number_format( absint( $item['change_qty'] ) ); ?></div>
                                <div class="nk-tb-col">
									<?php if ( $item['customer_id'] ) { ?>
                                        <span class="tb-lead"><?php echo esc_html( $item['customer_name'] ); ?></span>
                                        <span class="sub-text">
                                        سفارش <?php echo esc_html( $item['order_number'] ); ?>
                                    </span>
									<?php } else { ?>
                                        <span>-</span>
									<?php } ?>
                                </div>
                                <div class="nk-tb-col"><?php echo number_format( abs( $item['total_cost'] ) ); ?></div>
                            </div>
						<?php } ?>
					<?php } ?>
                </div>
            </div>

            <div class="card-inner">
				<?php
				echo kph_get_template( 'components/pagination.php', [
					'max_page_num' => $trace_pagination['total_page'],
					'current_page' => $trace_pagination['page'],
					'class_name'   => 'reports_stock_trace_pagination',
					'show_count'   => 2,
				] );
				?>
            </div>
        </div>
    </div>

    <div class="nk-block-head nk-block-head-sm">
        <div class="nk-block-between">
            <div class="nk-block-head-content">
                <h3 class="nk-block-title page-title">
					گزارش فاکتورهای مواد اولیه
					<?php echo kph_stock_print_button( 'batches', $stock_print_filters ); ?>
				</h3>
                <div class="nk-block-des text-soft">
                    <p class="mb-0">برای هر فاکتور مشخص می‌شود از چه کسی تهیه شده، چقدر تبدیل شده، به چند مشتری فروخته
                        شده و برکت آن چقدر بوده است.</p>
                </div>
            </div>
        </div>
    </div>

    <div class="nk-block">
        <div class="card card-stretch">
            <div class="card-inner p-0 overflow-auto">
                <div class="nk-tb-list nk-tb-ulist is-compact">
                    <div class="nk-tb-item nk-tb-head">
                        <div class="nk-tb-col"><span class="sub-text">فاکتور / بچ</span></div>
                        <div class="nk-tb-col"><span class="sub-text">تأمین‌کننده</span></div>
                        <div class="nk-tb-col"><span class="sub-text">ماده</span></div>
                        <div class="nk-tb-col"><span class="sub-text">وزن اولیه</span></div>
                        <div class="nk-tb-col"><span class="sub-text">تبدیل‌شده</span></div>
                        <div class="nk-tb-col"><span class="sub-text">فروش‌رفته</span></div>
                        <div class="nk-tb-col"><span class="sub-text">مبلغ فروش</span></div>
                        <div class="nk-tb-col"><span class="sub-text">برکت</span></div>
                        <div class="nk-tb-col text-end nk-tb-col-tools"></div>
                    </div>
					
					<?php if ( empty( $batches_report['items'] ) ) { ?>
                        <div class="no-item-found">فاکتوری یافت نشد</div>
					<?php } else { ?>
						<?php foreach ( $batches_report['items'] as $item ) { ?>
							<?php
							$detail_link = kph_stock_report_link( [
								'batch_id'       => $item['batch_id'],
								'raw_product_id' => $raw_product_id,
								'date_from'      => $date_from,
								'date_to'        => $date_to,
							] );
							?>
                            <div class="nk-tb-item">
                                <div class="nk-tb-col">
									<span class="tb-lead">محموله شماره <?php echo esc_html( $item['batch_id'] ); ?></span>
                                    <span class="sub-text"><?php echo esc_html( $item['invoice_no'] ?: '-' ); ?></span>
                                </div>
                                <div class="nk-tb-col"><?php echo esc_html( $item['supplier_name'] ?: '-' ); ?></div>
                                <div class="nk-tb-col"><?php echo esc_html( $item['raw_product_title'] ); ?></div>
                                <div
                                    class="nk-tb-col"><?php echo kph_stock_num( $item['initial_qty_weight'], 3 ); ?></div>
                                <div
                                    class="nk-tb-col"><?php echo kph_stock_num( $item['converted_weight'], 3 ); ?></div>
                                <div class="nk-tb-col">
                                    <strong><?php echo kph_stock_num( $item['sold_qty'], 2 ); ?></strong>
                                    <span
                                        class="sub-text"><?php echo number_format( $item['buyers_count'] ); ?> مشتری</span>
                                </div>
                                <div class="nk-tb-col"><?php echo number_format( $item['sales_amount'] ); ?></div>
                                <div class="nk-tb-col">
                                <span
                                    class="<?php echo $item['gross_profit'] >= 0 ? 'text-success' : 'text-danger'; ?>">
                                    <?php echo number_format( $item['gross_profit'] ); ?>
                                </span>
                                </div>
                                <div class="nk-tb-col nk-tb-col-tools">
                                    <ul class="nk-tb-actions gx-2">
										<?php
										echo kph_get_template( 'components/row-actions-hidden.php', [
											'actions' => [
												[
													'link'  => $detail_link,
													'title' => 'ریز فاکتور',
													'icon'  => 'ni-list-thumb',
													'class' => 'page_activator',
												],
											],
										] );
										?>
                                    </ul>
                                </div>
                            </div>
						<?php } ?>
					<?php } ?>
                </div>
            </div>
            <div class="card-inner border-top"><strong>جمع برکت فاکتورهای نمایش‌داده‌شده: <?php echo number_format(array_sum(array_column($batches_report['items']??[],'gross_profit'))); ?> ریال</strong></div>
        </div>
    </div>

<?php if ( $selected_batch_report && ! empty( $selected_batch_report['batch'] ) ) { ?>
	<?php $batch = $selected_batch_report['batch']; ?>

    <div class="nk-block-head nk-block-head-sm">
        <div class="nk-block-between">
            <div class="nk-block-head-content">
                <h3 class="nk-block-title page-title">
                    ریزگزارش محموله شماره <?php echo esc_html( $batch['id'] ); ?>
					<?php echo kph_stock_print_button( 'batch', array_merge( $stock_print_filters, [ 'batch_id' => (int) $batch['id'] ] ), 'پرینت ریزگزارش محموله' ); ?>
                </h3>
                <div class="nk-block-des text-soft">
                    <p class="mb-0">
						<?php echo esc_html( $batch['raw_product_title'] ); ?>
                        /
                        تأمین‌کننده:
						<?php echo esc_html( $batch['supplier_name'] ?: '-' ); ?>
                    </p>
                </div>
            </div>

            <div class="nk-block-head-content">
                <a href="/crm/reports-stock" class="btn btn-light page_activator" data-url="/crm/reports-stock">
                    <em class="icon ni ni-arrow-right"></em>
                    <span>بازگشت</span>
                </a>
            </div>
        </div>
    </div>

    <div class="nk-block">
        <div class="row g-gs">
            <div class="col-md-3">
                <div class="card card-full">
                    <div class="card-inner">
                        <h6 class="title">وزن خرید</h6>
                        <div class="amount"><?php echo kph_stock_num( $batch['initial_qty_weight'], 3 ); ?></div>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card card-full">
                    <div class="card-inner">
                        <h6 class="title">قیمت واحد</h6>
                        <div class="amount"><?php echo number_format( $batch['unit_cost'] ); ?></div>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card card-full">
                    <div class="card-inner">
                        <h6 class="title">مبلغ خرید</h6>
                        <div
                            class="amount"><?php echo number_format( $batch['initial_qty_weight'] * $batch['unit_cost'] ); ?></div>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card card-full">
                    <div class="card-inner">
                        <h6 class="title">شماره فاکتور</h6>
                        <div class="amount fs-18px"><?php echo esc_html( $batch['invoice_no'] ?: '-' ); ?></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="nk-block">
        <div class="card card-stretch">
            <div class="card-inner">
                <h6 class="title">تبدیل‌های این فاکتور</h6>
            </div>

            <div class="card-inner p-0 overflow-auto">
                <div class="nk-tb-list nk-tb-ulist is-compact">
                    <div class="nk-tb-item nk-tb-head">
                        <div class="nk-tb-col"><span class="sub-text">محصول تولیدی</span></div>
                        <div class="nk-tb-col"><span class="sub-text">وزن هر عدد (گرم)</span></div>
                        <div class="nk-tb-col"><span class="sub-text">سهم تعداد تولید</span></div>
                        <div class="nk-tb-col"><span class="sub-text">وزن تخصیص‌یافته (کیلوگرم)</span></div>
                        <div class="nk-tb-col"><span class="sub-text">سهم فروش‌رفته</span></div>
                        <div class="nk-tb-col"><span class="sub-text">فروش</span></div>
                        <div class="nk-tb-col"><span class="sub-text">برکت</span></div>
                    </div>
					
					<?php if ( empty( $selected_batch_report['conversions'] ) ) { ?>
                        <div class="no-item-found">تبدیلی برای این محموله یافت نشد</div>
					<?php } else { ?>
						<?php foreach ( $selected_batch_report['conversions'] as $row ) { ?>
                            <div class="nk-tb-item">
                                <div class="nk-tb-col">
                                    <span
                                        class="tb-lead"><?php echo esc_html( get_the_title( $row['wc_product_id'] ) ); ?></span>
                                    <span class="sub-text"><?php echo esc_html( $row['unique_product_code'] ); ?></span>
                                </div>
                                <div class="nk-tb-col"><?php echo esc_html(kph_product_weight_grams_label($row['weight_per_item'])); ?></div>
                                <div class="nk-tb-col"><?php echo kph_stock_num( $row['allocated_items'], 6 ); ?><span class="sub-text">از <?php echo number_format((int)$row['qty_items']); ?> عدد تولید؛ سهم این محموله <?php echo kph_stock_num((float)$row['share_ratio']*100,6); ?>٪</span></div>
                                <div class="nk-tb-col"><?php echo kph_stock_num( $row['allocated_weight'], 6 ); ?></div>
                                <div class="nk-tb-col"><?php echo kph_stock_num( $row['sold_qty'], 6 ); ?></div>
                                <div class="nk-tb-col"><?php echo number_format( $row['sales_amount'] ); ?></div>
                                <div class="nk-tb-col">
                                    <span
                                        class="<?php echo ( $row['sales_amount'] - $row['cogs_amount'] ) >= 0 ? 'text-success' : 'text-danger'; ?>">
                                        <?php echo number_format( $row['sales_amount'] - $row['cogs_amount'] ); ?>
                                    </span>
                                </div>
                            </div>
						<?php } ?>
					<?php } ?>
                </div>
            </div>
            <div class="card-inner border-top"><strong>جمع برکت این بخش: <?php echo number_format(array_sum(array_map(static fn($r)=>(float)$r['sales_amount']-(float)$r['cogs_amount'],$selected_batch_report['conversions']??[]))); ?> ریال</strong></div>
        </div>
    </div>

    <div class="nk-block">
        <div class="card card-stretch">
            <div class="card-inner">
                <h6 class="title">مشتری‌هایی که از این فاکتور محصول گرفته‌اند</h6>
            </div>

            <div class="card-inner p-0 overflow-auto">
                <div class="nk-tb-list nk-tb-ulist is-compact">
                    <div class="nk-tb-item nk-tb-head">
                        <div class="nk-tb-col"><span class="sub-text">مشتری</span></div>
                        <div class="nk-tb-col"><span class="sub-text">سفارش</span></div>
                        <div class="nk-tb-col"><span class="sub-text">محصول</span></div>
                        <div class="nk-tb-col"><span class="sub-text">سهم تعداد</span></div>
                        <div class="nk-tb-col"><span class="sub-text">مبلغ فروش</span></div>
                        <div class="nk-tb-col"><span class="sub-text">برکت</span></div>
                    </div>
					
					<?php if ( empty( $selected_batch_report['customers'] ) ) { ?>
                        <div class="no-item-found">فروشی برای این محموله یافت نشد
                        </div>                    <?php } else { ?>
						<?php foreach ( $selected_batch_report['customers'] as $row ) { ?>
                            <div class="nk-tb-item">
                                <div class="nk-tb-col">
                                    <span class="tb-lead"><?php echo esc_html( $row['customer_name'] ?: '-' ); ?></span>
                                    <span class="sub-text">#<?php echo esc_html( $row['customer_id'] ); ?></span>
                                </div>
                                <div class="nk-tb-col"><?php echo esc_html( $row['order_number'] ); ?></div>
                                <div class="nk-tb-col">
                                    <span
                                        class="tb-lead"><?php echo esc_html( get_the_title( $row['wc_product_id'] ) ); ?></span>
                                    <span class="sub-text"><?php echo esc_html( $row['unique_product_code'] ); ?></span>
                                </div>
                                <div class="nk-tb-col"><?php echo kph_stock_num( $row['sold_qty'], 6 ); ?></div>
                                <div class="nk-tb-col"><?php echo number_format( $row['sales_amount'] ); ?></div>
                                <div class="nk-tb-col">
                                    <span
                                        class="<?php echo ( $row['sales_amount'] - $row['cogs_amount'] ) >= 0 ? 'text-success' : 'text-danger'; ?>">
                                        <?php echo number_format( $row['sales_amount'] - $row['cogs_amount'] ); ?>
                                    </span>
                                </div>
                            </div>
						<?php } ?>
					<?php } ?>
                </div>
            </div>
            <div class="card-inner border-top"><strong>جمع برکت این بخش: <?php echo number_format(array_sum(array_map(static fn($r)=>(float)$r['sales_amount']-(float)$r['cogs_amount'],$selected_batch_report['customers']??[]))); ?> ریال</strong></div>
        </div>
    </div>
<?php } ?>
