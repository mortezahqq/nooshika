<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * @var $user_id
 */
$defaults   = [
	'per_page'    => 10,
	'page_number' => 1,
	'date'        => [
		'from' => '',
		'to'   => '',
	],
];
$args       = wp_parse_args( $_REQUEST, $defaults );
$args       = array_map( fn( $v ) => $v == 0 ? '' : $v, $args );
$has_filter = kph_page_has_filter( $args, $defaults );
extract( array_intersect_key( $args, $defaults ) );
$date_from  = $date['from'] ?? '';
$date_to    = $date['to'] ?? '';
$DB         = new kph_db();
$entries    = $DB->get_user_actions( [
	'page'      => $page_number,
	'per_page'  => $per_page,
	'creator'   => $user_id,
	'date_from' => $date_from ? nooshika_jalali_to_gregorian( $date_from ) : NULL,
	'date_to'   => $date_to ? nooshika_jalali_to_gregorian( $date_to ) : NULL,
] );
$total_page = $entries['pagination']['total_page'];
$entries    = $entries['items'];

?>
<div class="nk-block nk-block-between">
    <div class="nk-block-head">
        <h6 class="title">فعالیت ها</h6>
        <p>گزارش فعالیت های کارشناسان و مشتری</p>
    </div>
    <div class="nk-block">
        <ul class="btn-toolbar gx-1">
            <li>
				<?php
				$filter_fields = [
					[
						'type'  => 'date-range',
						'label' => 'تاریخ فعالیت',
						'name'  => 'date',
						'value' => [
							'from' => $date_from ?? '',
							'to'   => $date_to ?? '',
						],
					],
					[
						'type'  => 'hidden',
						'name'  => 'tab',
						'value' => 'orders',
					],
				];
				echo kph_get_template( 'components/filter-dropdown.php', [
					'filter_fields' => $filter_fields,
				] );
				?>
            </li>
        </ul>
    </div>
</div>
<div class="nk-block">
    <div class="nk-tb-list nk-tb-ulist is-compact v-align-top">
        <div class="nk-tb-item nk-tb-head">
            <div class="nk-tb-col"><span class="sub-text">تاریخ</span></div>
            <div class="nk-tb-col"><span class="sub-text">عنوان فعالیت</span></div>
            <div class="nk-tb-col"><span class="sub-text">محتوای فعالیت</span></div>
            <div class="nk-tb-col nk-tb-col-tools text-end"></div>
        </div>
		<?php
		if ( empty( $entries ) ) {
			echo '<div class="no-item-found">فعالیتی یافت نشد</div>';
		} else {
			foreach ( $entries as $entry ) {
				$date       = date_i18n( 'Y/m/d', strtotime( $entry['date'] ) );
				$attachment = $entry['meta']['attachment'];
				?>
                <div class="nk-tb-item">
                    <div class="nk-tb-col">
                        <span><?php echo $date; ?></span>
                    </div>
                    <div class="nk-tb-col"><span><?php echo $entry['title']; ?></span></div>
                    <div class="nk-tb-col"><span><?php echo $entry['content']; ?></span></div>
                    <div class="nk-tb-col">
                        <ul class="nk-tb-actions gx-2">
							<?php
							echo kph_get_template( 'components/row-actions-hidden.php', [
								'actions' => [
									[
										'link'  => '/crm/user/' . $entry['user_id'],
										'title' => get_user_name_by_id( $entry['user_id'] ),
										'icon'  => 'ni-eye',
										'class' => 'page_activator',
									],
								],
							] );
							if ( $attachment ) {
								?>
                                <li class="nk-tb-action">
									<?php
									$actions = [];
									foreach ( $attachment as $url ) {
										$file_data = $DB->get_uploaded_file_data( $url );
										if ( ! $file_data ) {
											$file_name = $url;
										} else {
											$file_name = $file_data['original_name'];
										}
										$actions[] = [
											'link'     => $url,
											'title'    => $file_name,
											'icon'     => 'ni-download',
											'target'   => '_blank',
											'download' => TRUE,
										];
									}
									echo kph_get_template( 'components/row-actions-dropdown.php', [
										'actions'   => $actions,
										'main_icon' => 'file-docs',
										'title'     => 'فایل ضمیمه',
									] );
									?>
                                </li>
								<?php
							}
							?>
                        </ul>
                    </div>
                </div>
				<?php
			}
		}
		?>
    </div>
    <div class="p-1 mt-2">
		<?php
		echo kph_get_template( 'components/pagination.php', [
			'max_page_num' => $total_page,
			'current_page' => $page_number,
			'show_count'   => 2,
			'data'         => [
				'tab' => 'orders',
			],
		] );
		?>
    </div>
</div>
