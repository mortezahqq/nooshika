<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * @var $user_id
 */

$DB = new kcp_db();

$defaults = [
	'v_year'   => date_i18n( 'Y' ),
	'v_month'  => date_i18n( 'm' ),
	'v_period' => 'monthly',
];
$args     = wp_parse_args( $_REQUEST, $defaults );
extract( array_intersect_key( $args, $defaults ) );
$visits_log = [];
$months     = [
	'فروردین',
	'اردیبهشت',
	'خرداد',
	'تیر',
	'مرداد',
	'شهریور',
	'مهر',
	'آبان',
	'آذر',
	'دی',
	'بهمن',
	'اسفند',
];
if ( $v_period == 'monthly' ) {
	$days = $v_month < 7 ? 31 : 30;
	for ( $day = 1; $day <= $days; $day ++ ) {
		$jalali_date = sprintf( '%04d-%02d-%02d', $v_year, $v_month, $day );
		$finished    = $DB->get_visits( [
			'creator'   => $user_id,
			'date_from' => $jalali_date,
			'date_to'   => $jalali_date,
			'status'    => 'finished',
			'per_page'  => 1,
		] );
		$total       = $DB->get_visits( [
			'creator'   => $user_id,
			'date_from' => $jalali_date,
			'date_to'   => $jalali_date,
			'per_page'  => 1,
		] );
		
		$visits_log[ $day ] = [
			'total'    => $total['count'] ?? 0,
			'finished' => $finished['count'] ?? 0,
		];
	}
} else {
	for ( $month = 1; $month <= 12; $month ++ ) {
		$last_day = $month < 7 ? 31 : 30;
		$start    = sprintf( '%04d-%02d-01', $v_year, $month );
		$end      = sprintf( '%04d-%02d-%02d', $v_year, $month, $last_day );
		$finished = $DB->get_visits( [
			'creator'   => $user_id,
			'date_from' => $start,
			'date_to'   => $end,
			'status'    => 'finished',
			'per_page'  => 1,
		] );
		$total    = $DB->get_visits( [
			'creator'   => $user_id,
			'date_from' => $start,
			'date_to'   => $end,
			'per_page'  => 1,
		] );
		
		$visits_log[ $months[ $month - 1 ] ] = [
			'total'    => $total['count'] ?? 0,
			'finished' => $finished['count'] ?? 0,
		];
	}
}

$labels        = [];
$data_total    = [];
$data_finished = [];
$max_val       = 0;
$total         = 0;
$finished      = 0;
foreach ( $visits_log as $visit_label => $row ) {
	$labels[]        = $visit_label;
	$data_total[]    = (int) ( $row['total'] ?? 0 );
	$data_finished[] = (int) ( $row['finished'] ?? 0 );
	$max_val         = max( $max_val, $t, $f );
	$total           += $row['total'];
	$finished        += $row['finished'];
}

$chart_config = [
	'type'    => 'bar', // bar | line | ...
	'data'    => [
		'labels'   => $labels,
		'datasets' => [
			[
				'label'              => 'کل ویزیت‌ها',
				'data'               => $data_total,
				'backgroundColor'    => 'rgba(115, 58, 234, 0.25)',
				'borderColor'        => '#733AEA',
				'borderWidth'        => 1,
				'borderRadius'       => 8,
				'barPercentage'      => 1,
				'categoryPercentage' => 0.5,
			],
			[
				'label'              => 'موفق',
				'data'               => $data_finished,
				'backgroundColor'    => 'rgba(34, 197, 94, 0.25)',
				'borderColor'        => '#22c55e',
				'borderWidth'        => 1,
				'borderRadius'       => 8,
				'barPercentage'      => 1,
				'categoryPercentage' => 0.5,
			],
		],
	],
	'options' => [
		'responsive'          => TRUE,
		'maintainAspectRatio' => FALSE,
		'animation'           => [
			'duration' => 600,
		],
		'legend'              => [
			'display' => TRUE,
			'labels'  => [
				'fontFamily' => 'IRANSansX',
			],
		],
		'tooltips'            => [
			'enabled'    => TRUE,
			'fontFamily' => 'IRANSansX',
		],
	],
];

?>
<div class="nk-block">
    <div class="card card-full overflow-hidden">
        <div class="nk-ecwg nk-ecwg5">
            <div class="card-inner">
                <div class="card-title-group align-start pb-3 g-2">
                    <div class="card-title"><h6 class="title">گزارش ویزیت</h6></div>
                    <div class="card-tools align-center">
                        <div class="align-center btn-group gap-sm" style="gap: 10px">
							<?php
							if ( $v_period == 'monthly' ) {
								$next_year  = $v_month == 12 ? $v_year + 1 : $v_year;
								$next_month = $v_month == 12 ? 1 : $v_month + 1;
								$next_page  = "/crm/employee/$user_id?tab=reports&v_year=$next_year&v_month=$next_month";
								$pre_year   = $v_month == 1 ? $v_year - 1 : $v_year;
								$pre_month  = $v_month == 1 ? 12 : $v_month - 1;
								$pre_page   = "/crm/employee/$user_id?tab=reports&v_year=$pre_year&v_month=$pre_month";
								?>
                                <a class="btn btn-icon btn-trigger icon page_activator"
                                   data-url="<?php echo $pre_page; ?>"
                                   href="<?php echo $pre_page; ?>"
                                   data-bs-toggle="tooltip" style="width: 29px"
                                   data-bs-placement="top" title="ماه قبل">
                                    <span class="ni ni-chevron-left"></span>
                                </a>
                                <div class="mb-0">
									<?php echo date_i18n( 'F Y', strtotime( nooshika_jalali_to_gregorian( "$v_year-$v_month-1" ) ) ); ?>
                                </div>
                                <a class="btn btn-icon btn-trigger icon page_activator"
                                   data-url="<?php echo $next_page; ?>"
                                   href="<?php echo $next_page; ?>"
                                   data-bs-toggle="tooltip" style="width: 29px"
                                   data-bs-placement="top" title="ماه بعد">
                                    <span class="ni ni-chevron-right"></span>
                                </a>
								<?php
							}
							if ( $v_period == 'yearly' ) {
								$next_year = $v_year + 1;
								$next_page = "/crm/employee/$user_id?tab=reports&v_year=$next_year&v_period=yearly";
								$pre_year  = $v_year - 1;
								$pre_page  = "/crm/employee/$user_id?tab=reports&v_year=$pre_year&v_period=yearly";
								?>
                                <a class="btn btn-icon btn-trigger icon page_activator"
                                   data-url="<?php echo $pre_page; ?>"
                                   href="<?php echo $pre_page; ?>"
                                   data-bs-toggle="tooltip" style="width: 29px"
                                   data-bs-placement="top" title="سال قبل">
                                    <span class="ni ni-chevron-left"></span>
                                </a>
                                <div class="mb-0">
									<?php echo date_i18n( 'Y', strtotime( nooshika_jalali_to_gregorian( "$v_year-$v_month-1" ) ) ); ?>
                                </div>
                                <a class="btn btn-icon btn-trigger icon page_activator"
                                   data-url="<?php echo $next_page; ?>"
                                   href="<?php echo $next_page; ?>"
                                   data-bs-toggle="tooltip" style="width: 29px"
                                   data-bs-placement="top" title="سال بعد">
                                    <span class="ni ni-chevron-right"></span>
                                </a>
								<?php
							}
							?>
                        </div>
                        <div class="drodown">
                            <a href="#" class="dropdown-toggle btn btn-icon btn-trigger" data-bs-toggle="dropdown"
                               aria-expanded="false"><em class="icon ni ni-more-h"></em></a>
                            <div class="dropdown-menu dropdown-menu-sm dropdown-menu-end" style="">
                                <ul class="link-list-opt no-bdr">
                                    <li>
                                        <a class="page_activator"
                                           data-url="/crm/employee/<?php echo $user_id; ?>?tab=reports&v_period=monthly"
                                           href="/crm/employee/<?php echo $user_id; ?>?tab=reports&v_period=monthly">
                                            ماهانه
                                        </a>
                                    </li>
                                    <li>
                                        <a class="page_activator"
                                           data-url="/crm/employee/<?php echo $user_id; ?>?tab=reports&v_period=yearly"
                                           href="/crm/employee/<?php echo $user_id; ?>?tab=reports&v_period=yearly">
                                            سالانه
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="data-group mb-2 d-flex" style="gap: 30px">
                    <div class="data">
                        <div class="title">کل ویزیت ها</div>
                        <div class="amount amount-sm"><?php echo $total; ?></div>
                    </div>
                    <div class="data">
                        <div class="title">ویزیت موفق</div>
                        <div class="amount amount-sm"><?php echo $finished; ?></div>
                    </div>
                </div>
                <div class="nk-ecwg5-ck">
                    <canvas id="employee_visits_chart"
                            class="render_chart"
                            style="height:220px"
                            data-chart='<?php echo esc_attr( wp_json_encode( $chart_config ) ); ?>'></canvas>
                </div>

            </div>
        </div>
    </div>
</div>
