<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * @var $user_id
 */
$defaults   = [
	'per_page'    => 10,
	'page_number' => 1,
	'date'        => [
		'from' => '',
		'to'   => '',
	],
	'invoice_id'  => '',
	'status'      => '',
];
$args       = wp_parse_args( $_REQUEST, $defaults );
$args       = array_map( fn( $v ) => $v == 0 ? '' : $v, $args );
$has_filter = kph_page_has_filter( $args, $defaults );
extract( array_intersect_key( $args, $defaults ) );
$date_from  = $date['from'] ?? '';
$date_to    = $date['to'] ?? '';
$DB         = new kph_db();
$statuses   = $DB->get_cheque_statuses();
$entries    = $DB->get_cheques( [
	'page'       => $page_number,
	'per_page'   => $per_page,
	'user_id'    => $user_id,
	'status'     => $status,
	'invoice_id' => $invoice_id,
	'date_from'  => $date_from ? nooshika_jalali_to_gregorian( $date_from ) : NULL,
	'date_to'    => $date_to ? nooshika_jalali_to_gregorian( $date_to ) : NULL,
] );
$total_page = $entries['pagination']['total_page'];
$entries    = $entries['items'];
?>
<div class="nk-block nk-block-between">
    <div class="nk-block-head">
        <h6 class="title">لیست چک ها</h6>
    </div>
    <ul class="btn-toolbar gx-1">
        <li class="nk-block-tools-opt">
            <a href="#" class="btn btn-icon btn-primary print_list_items" data-type="cheques"
               data-collect="ids">
                <em class="icon ni ni-printer"></em></a>
        </li>
        <li>
			<?php
			$filter_fields = [
				[
					'type'  => 'date-range',
					'label' => 'تاریخ سررسید چک',
					'name'  => 'date',
					'value' => [
						'from' => $date_from ?? '',
						'to'   => $date_to ?? '',
					],
				],
				[
					'type'    => 'select',
					'label'   => 'وضعیت چک',
					'name'    => 'status',
					'value'   => $status,
					'col'     => 6,
					'options' => [ 0 => 'همه موارد' ] + array_combine(
							array_keys( $statuses ),
							array_column( $statuses, 'label' )
						),
				],
				[
					'type'  => 'hidden',
					'name'  => 'tab',
					'value' => 'financial',
				],
			];
			echo kph_get_template( 'components/filter-dropdown.php', [
				'has_filter'    => $has_filter,
				'filter_fields' => $filter_fields,
			] );
			?>
        </li>
    </ul>
</div>
<?php echo kph_get_template( 'components/cheque-note-print-all.php', [ 'DB' => $DB ] ); ?>
<div class="nk-block">
	<?php
	if ( empty( $entries ) ) {
		echo '<div class="no_massages">آیتمی برای نمایش وجود ندارد.</div>';
	} else {
		?>
        <div class="card">
            <div class="nk-tb-list nk-tb-ulist is-compact">
                <div class="nk-tb-item nk-tb-head">
                    <div class="nk-tb-col nk-tb-col-check"></div>
                    <div class="nk-tb-col"><span class="sub-text">سررسید چک</span></div>
                    <div class="nk-tb-col"><span class="sub-text">شناسه صیادی</span></div>
                    <div class="nk-tb-col"><span class="sub-text">مقدار</span></div>
                    <div class="nk-tb-col"><span class="sub-text">وضعیت</span></div>
                    <div class="nk-tb-col nk-tb-col-tools text-end"></div>
                </div>
				<?php
				foreach ( $entries as $entry ) {
					$date          = date_i18n( 'Y/m/d', strtotime( $entry['due_at'] ) );
					$amount        = number_format( $entry['amount'] );
					$note          = $entry['note'];
					$cheque_status = $statuses[ $entry['status'] ];
					$attachment    = $DB->get_cheque_meta( $entry['id'], 'attachment' );
					$bank_branch   = $DB->get_cheque_meta( $entry['id'], 'bank_branch' );
					$bank_owner    = $DB->get_cheque_meta( $entry['id'], 'bank_owner' );
					$invoice_id    = $DB->get_cheque_meta( $entry['id'], 'invoice_id' );
					$creator_id    = $DB->get_cheque_meta( $entry['id'], 'creator_id' );
					?>
                    <div class="nk-tb-item">
                        <div class="nk-tb-col nk-tb-col-check">
                            <div class="custom-control custom-control-sm custom-checkbox notext">
                                <input type="checkbox" class="custom-control-input select_item_for_print"
                                       value="<?php echo $entry['id']; ?>"
                                       id="print_item_<?php echo $entry['id']; ?>">
                                <label class="custom-control-label"
                                       for="print_item_<?php echo $entry['id']; ?>"></label>
                            </div>
                        </div>
                        <div class="nk-tb-col">
                            <span><?php echo $date; ?></span>
                        </div>
                        <div class="nk-tb-col"><span><?php echo $entry['sayad_id']; ?></span><?php echo kph_get_template( 'components/cheque-admin-note.php', [ 'DB' => $DB, 'cheque_id' => $entry['id'] ] ); ?></div>
                        <div class="nk-tb-col">
                            <div class="amount">
                                <span><?php echo $amount; ?></span>
                            </div>
                        </div>
                        <div class="nk-tb-col">
                            <span class="badge <?= $cheque_status['class']; ?>">
                                <?php echo $cheque_status['label']; ?></span>
                        </div>
                        <div class="nk-tb-col">
                            <ul class="nk-tb-actions gx-2">
                                <li class="nk-tb-action">
                                    <div class="btn btn-sm btn-icon btn-trigger" data-bs-toggle="tooltip"
                                         data-bs-placement="top"
                                         title="<?php echo get_user_name_by_id( $creator_id ); ?>">
                                        <em class="icon ni ni-user-add"></em>
                                    </div>
                                </li>
								<?php
								$hidden_actions = [
									[
										'link'  => "",
										'title' => $entry['bank_name'] . ( $bank_branch ? ' - ' . $bank_branch : '' ),
										'icon'  => 'ni-server',
									],
									[
										'link'  => '',
										'title' => 'تاریخچه گردش چک',
										'class' => 'load_cheque_moves_table',
										'icon'  => 'ni-repeat',
										'data'  => [
											'cheque-id' => $entry['id'],
										],
									],
								];
								if ( $invoice_id ) {
									$hidden_actions[] = [
										'link'  => "",
										'title' => "فاکتور #$invoice_id",
										'icon'  => 'ni-file-text',
									];
								}
								echo kph_get_template( 'components/row-actions.php', [
									'actions' => $hidden_actions,
								] );
								if ( $note ) {
									?>
                                    <li class="nk-tb-action">
                                        <div class="btn btn-sm btn-icon btn-trigger"
                                             data-bs-toggle="popover"
                                             data-bs-trigger="hover"
                                             data-bs-html="true"
                                             title="یادداشت"
                                             data-bs-content="<?php echo wpautop( $note ); ?>"
                                             data-bs-placement="top">
                                            <em class="icon ni ni-note-add-c"></em>
                                        </div>
                                    </li>
									<?php
								}
								if ( $attachment ) {
									$attachment = explode( ',', $attachment );
									?>
                                    <li class="nk-tb-action">
										<?php
										$actions = [];
										foreach ( $attachment as $url ) {
											$file_data = $DB->get_uploaded_file_data( $url );
											if ( ! $file_data ) {
												$file_name = $url;
											} else {
												$file_name = $file_data['original_name'];
											}
											$actions[] = [
												'link'     => $url,
												'title'    => $file_name,
												'icon'     => 'ni-download',
												'target'   => '_blank',
												'download' => TRUE,
											];
										}
										echo kph_get_template( 'components/row-actions-dropdown.php', [
											'actions'   => $actions,
											'main_icon' => 'file-docs',
											'title'     => 'فایل ضمیمه',
										] );
										?>
                                    </li>
									<?php
								}
								?>
                            </ul>
                        </div>
                    </div>
					<?php
				}
				?>
            </div>
        </div>
        <div class="p-1 mt-2">
			<?php
			echo kph_get_template( 'components/pagination.php', [
				'max_page_num' => $total_page,
				'current_page' => $page_number,
				'show_count'   => 2,
				'data'         => [
					'tab' => 'cheque',
				],
			] );
			?>
        </div>
		<?php
	}
	?>
</div>
