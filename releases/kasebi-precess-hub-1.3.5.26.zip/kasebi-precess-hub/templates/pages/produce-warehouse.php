<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
$DB           = new kph_db();
$per_page_key = basename( __FILE__, '.php' );
$per_page_key = "kph_{$per_page_key}_per_page";
$user_id      = get_current_user_id();
$defaults     = [
	'term_id'     => '',
	'page_number' => 1,
	'per_page'    => get_user_meta( $user_id, $per_page_key, TRUE ) ?: 20,
];
$args         = wp_parse_args( $_REQUEST, $defaults );
$args         = array_map( fn( $v ) => $v == 0 ? '' : $v, $args );
$has_filter   = kph_page_has_filter( $args, $defaults );
extract( array_intersect_key( $args, $defaults ) );
update_user_meta( $user_id, $per_page_key, $per_page );
//$DB->temp_rebuild_inventory_balance_from_logs();
$inventory   = $DB->get_inventory_items( [
	'term_id'  => $term_id,
	'page'     => $page_number,
	'per_page' => $per_page,
] );
$total_page  = $inventory['pagination']['total_page'];
$total_items = $inventory['pagination']['total'];
$inventory   = $inventory['items'];
try{$warehouse_distribution=$DB->get_warehouse_distribution('finished',array_column($inventory,'id'));}catch(Throwable $e){$warehouse_distribution=null;}

$product_cats      = get_terms( [
	'taxonomy' => 'product_cat',
] );
$selected_category = $term_id ? get_term( $term_id, 'product_cat' ) : FALSE;
?>
<div class="nk-block-head nk-block-head-sm">
    <div class="nk-block-between">
        <div class="nk-block-head-content">
            <h3 class="nk-block-title page-title">انبار محصولات</h3>
        </div>
        <div class="nk-block-head-content">
            <div class="drodown">
                <a href="#" class="dropdown-toggle btn btn-outline-info btn-dim"
                   data-bs-toggle="dropdown" aria-expanded="true">
                    <span><?php echo $selected_category ? $selected_category->name : 'همه محصولات'; ?></span>
                    <em class="icon ni ni-chevron-down"></em>
                </a>
                <div class="dropdown-menu dropdown-menu-end " data-popper-placement="bottom-start">
                    <ul class="link-list-opt no-bdr">
						<?php
						foreach ( $product_cats as $data ) {
							?>
                            <li>
                                <a class="page_activator"
                                   href="<?php echo home_url( "/crm/produce-warehouse?term_id={$data->term_id}" ); ?>"
                                   data-url="<?php echo "/crm/produce-warehouse?term_id={$data->term_id}"; ?>">
                                    <span><?php echo $data->name; ?></span>
                                </a>
                            </li>
							<?php
						}
						?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="nk-block">
    <div class="card card-stretch">
        <div class="card-inner-group">
            <div class="card-inner position-relative card-tools-toggle">
                <div class="card-title-group">
                    <div class="card-tools">
                    </div>
                    <div class="card-tools">
                        <ul class="btn-toolbar gx-1">
                            <li>
								<?php
								echo kph_get_template( 'components/per-page-selector.php', [
									'per_page' => $per_page,
								] );
								?>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="card-inner p-0">
                <div class="nk-tb-list nk-tb-ulist is-compact">
                    <div class="nk-tb-item nk-tb-head">
                        <div class="nk-tb-col"><span class="sub-text">محصول</span></div>
                        <div class="nk-tb-col"><span class="sub-text">تعداد کل در انبارها</span></div>
                        <div class="nk-tb-col"><span class="sub-text">قیمت تمام شده هر محصول</span></div>
                        <div class="nk-tb-col"><span class="sub-text">قیمت فروش</span></div>
                        <div class="nk-tb-col"><span class="sub-text">ارزش کلی</span></div>
                        <div class="nk-tb-col text-end nk-tb-col-tools"></div>
                    </div>
					<?php
					if ( empty( $inventory ) ) {
						echo '<div class="no-item-found">آیتمی یافت نشد</div>';
					} else {
						foreach ( $inventory as $entry ) {
							if ( ! $entry['qty_available'] ) {
								continue;
							}
							$sale_price = $DB->get_inventory_balance_meta( $entry['id'], 'sale_price', TRUE ) ?: $entry['avg_unit_cost'];
							?>
                            <div class="nk-tb-item">
                                <div class="nk-tb-col text-dark">
                                    <div class="user-card">
                                        <div class="user-info">
                                            <span class="tb-lead"><?php echo get_the_title( $entry['wc_product_id'] );
	                                            ?></span>
                                            <span class="sub-text"><?php echo $entry['unique_product_code']; ?></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="nk-tb-col"><?php echo kph_db::format_order_quantity( $entry['qty_available'] ); ?>
                                    <?php echo kph_get_template('components/warehouse-distribution.php',['allocations'=>$warehouse_distribution===null?null:($warehouse_distribution[(int)$entry['id']]??[]),'total'=>$entry['qty_available'],'unit'=>'عدد']); ?>
                                </div>
                                <div class="nk-tb-col">
                                    <span><?php echo number_format( $entry['avg_unit_cost'] ); ?></span>
                                </div>
                                <div class="nk-tb-col">
                                    <span><?php echo number_format( $sale_price ); ?></span>
                                </div>
                                <div class="nk-tb-col">
                                    <span><?php echo number_format( $entry['inventory_value'] ); ?></span>
                                </div>
                                <div class="nk-tb-col nk-tb-col-tools">
                                    <ul class="nk-tb-actions gx-2">
                                        <li>
											<?php
											$actions = [
												'return'  => [
													'title' => 'تنظیم قیمت فروش محصول',
													'icon'  => 'ni-coin-alt',
													'class' => 'row_inline_action',
													'data'  => [
														'action'     => 'kph_set_inventory_item_price',
														'item-id'    => $entry['id'],
														'swal-title' => 'تنظیم قیمت فروش محصول',
														'needs'      => json_encode( [
															[
																'type'  => 'text',
																'label' => 'قیمت محصول را با توجه به قیمت تمام شده ثبت نمایید.',
																'key'   => 'sale_price',
																'class' => 'price_input',
															],
														] ),
													],
												],
												'divider' => [
													'divider' => TRUE,
												],
												[
													'link'  => '',
													'title' => 'گزارش گردش انبار',
													'class' => 'load_item_data_to_modal',
													'icon'  => 'ni-check-round-cut',
													'data'  => [
														'item-id' => $entry['id'],
														'action'  => 'kph_load_inventory_logs',
														'modal'   => '#inventoryLogTable',
													],
												],
											];
											echo kph_get_template( 'components/row-actions-dropdown.php', [
												'actions' => $actions,
											] );
											?>
                                        </li>
                                    </ul>
                                </div>
                            </div>
							<?php
						}
					}
					?>
                </div>
            </div>
            <div class="card-inner">
				<?php
				echo kph_get_template( 'components/pagination.php', [
					'max_page_num' => $total_page,
					'current_page' => $page_number,
					'class_name'   => 'user_pagination_link',
					'show_count'   => 2,
				] );
				?>
            </div>
        </div>
    </div>
</div>


