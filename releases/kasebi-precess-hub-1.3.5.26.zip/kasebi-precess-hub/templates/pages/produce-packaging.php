<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
$category_role_map = [
	1 => 'saff',
	2 => 'zereshk',
	3 => 'tea',
	4 => 'hell',
	5 => 'nabat',
	7 => 'vanil',
];
$role              = nooshika_get_user_role( get_current_user_id() );

$DB              = new kph_db();
$supplier_groups = $DB->get_raw_categories();
$supplier_groups = $supplier_groups['items'];

if ( in_array( $role, $category_role_map, TRUE ) ) {
	$supplier_groups = array_values(
		array_filter(
			$supplier_groups,
			static function( array $group ) use ( $category_role_map, $role ): bool {
				$category_id = (int) ( $group['id'] ?? 0 );
				
				return isset( $category_role_map[ $category_id ] )
				       && $category_role_map[ $category_id ] === $role;
			}
		)
	);
}
$default_category = $supplier_groups[0] ?? FALSE;
$per_page_key     = basename( __FILE__, '.php' );
$per_page_key     = "kph_{$per_page_key}_per_page";
$user_id          = get_current_user_id();
$defaults         = [
	'category_id' => $default_category ? $default_category['id'] : '',
	'page_number' => 1,
	'per_page'    => get_user_meta( $user_id, $per_page_key, TRUE ) ?: 20,
	'status'      => 'open',
];
$args             = wp_parse_args( $_REQUEST, $defaults );
$args             = array_map( fn( $v ) => $v == 0 ? '' : $v, $args );
$has_filter       = kph_page_has_filter( $args, $defaults );
extract( array_intersect_key( $args, $defaults ) );
update_user_meta( $user_id, $per_page_key, $per_page );

$date_from = $date['from'] ?? '';
$date_to   = $date['to'] ?? '';

$packs       = $DB->get_processing_packs_list( [
	'page'        => $page_number,
	'per_page'    => $per_page,
	'category_id' => $category_id,
	'status'      => $status,
] );
$total_page  = $packs['pagination']['total_page'];
$total_items = $packs['pagination']['total'];
$packs       = $packs['items'];

$selected_category = $DB->get_raw_category( $category_id );
$summery           = $DB->get_processing_overview_stats( $category_id );
$statuses          = $DB->get_processing_packs_statuses();
?>
<div class="nk-block-head nk-block-head-sm">
    <div class="nk-block-between">
        <div class="nk-block-head-content">
            <h3 class="nk-block-title page-title">محصولات فرآوری شده</h3>
        </div>
        <div class="nk-block-head-content">
            <div class="toggle-wrap nk-block-tools-toggle">
                <div class="toggle-expand-content">
                    <ul class="nk-block-tools g-3">
                        <li class="nk-block-tools-opt">
                            <div class="drodown">
                                <a href="#" class="dropdown-toggle btn btn-outline-info btn-dim"
                                   data-bs-toggle="dropdown" aria-expanded="true">
                                    <span><?php echo $selected_category['item']['title']; ?></span>
                                    <em class="icon ni ni-chevron-down"></em>
                                </a>
                                <div class="dropdown-menu dropdown-menu-end " data-popper-placement="bottom-start">
                                    <ul class="link-list-opt no-bdr">
										<?php
										foreach ( $supplier_groups as $data ) {
											?>
                                            <li>
                                                <a class="page_activator"
                                                   href="<?php echo home_url( "/crm/produce-packaging?category_id={$data['id']}" ); ?>"
                                                   data-url="<?php echo "/crm/produce-packaging?category_id={$data['id']}"; ?>">
                                                    <span><?php echo $data['title']; ?></span>
                                                </a>
                                            </li>
											<?php
										}
										?>

                                    </ul>
                                </div>
                            </div>
                        </li>
                        <li class="nk-block-tools-opt">
                            <a href="#addProcessingPack" class=" btn btn-icon btn-primary"
                               data-bs-target="#addProcessingPack"
                               data-bs-toggle="modal"><em class="icon ni ni-plus"></em></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="nk-block">
    <div class="card card-stretch">
        <div class="card-inner-group">
            <div class="card-inner position-relative card-tools-toggle">
                <div class="card-title-group">
                    <div class="card-tools">
                    </div>
                    <div class="card-tools">
                        <ul class="btn-toolbar gx-1">
							<?php
							foreach ( $statuses as $slug => $data ) {
								$class = 'btn-' . $data['class'];
								if ( $slug != $status ) {
									$class .= ' btn-dim';
								}
								?>
                                <li>
                                    <div
                                        data-url="/crm/produce-packaging?status=<?php echo $slug . "&category_id={$category_id}"; ?>"
                                        class="page_activator btn <?php echo $class; ?>"><?php echo $data['label']; ?></div>
                                </li>
								<?php
							}
							?>
                            <li class="btn-toolbar-sep"></li>
                            <li>
								<?php
								echo kph_get_template( 'components/per-page-selector.php', [
									'per_page' => $per_page,
								] );
								?>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="card-inner p-0">
                <div class="nk-tb-list nk-tb-ulist is-compact">
                    <div class="nk-tb-item nk-tb-head">
                        <div class="nk-tb-col"><span class="sub-text">کد فرآوری</span></div>
                        <div class="nk-tb-col"><span class="sub-text">وضعیت آیتم</span></div>
                        <div class="nk-tb-col"><span class="sub-text">وزن باقیمانده</span></div>
                        <div class="nk-tb-col"><span class="sub-text">قیمت هر کیلو</span></div>
                        <div class="nk-tb-col"><span class="sub-text">محصولات درون پک</span></div>
                        <div class="nk-tb-col text-end nk-tb-col-tools"></div>
                    </div>
					<?php
					if ( empty( $packs ) ) {
						echo '<div class="no-item-found">آیتمی یافت نشد</div>';
					} else {
						foreach ( $packs as $entry ) {
							$pack_id      = $entry['id'];
							$pack_code    = $DB->get_processing_pack_meta( $pack_id, 'pack_code', TRUE );
							$remaining    = $DB->get_processing_pack_remaining_weight( $pack_id );
							$total_amount = $entry['total_qty_weight'] * $entry['avg_unit_cost'];
							$products     = $DB->get_raw_product_ids_by_processing_pack( $pack_id );
							$remaining    = number_format( $remaining, 4, '.', '' );
							$item_status  = $entry['status'];
							?>
                            <div class="nk-tb-item">
                                <div class="nk-tb-col"><?php echo $pack_code; ?></div>
                                <div class="nk-tb-col">
									 <span
                                         class="badge bg-<?php echo $statuses[ $item_status ]['class']; ?>"><?php echo $statuses[ $item_status ]['label']; ?></span>
                                </div>
                                <div class="nk-tb-col">
									<?php echo $remaining; ?>
                                </div>
                                <div class="nk-tb-col">
                                    <span><?php echo number_format( $entry['avg_unit_cost'] ); ?></span>
                                </div>
                                <div class="nk-tb-col">
									<?php
									foreach ( $products as $item ) {
										$product = $DB->get_raw_product( $item );
										?>
                                        <span class="sub-text"><?php echo $product['item']['title']; ?></span>
										<?php
									}
									?>
                                </div>
                                <div class="nk-tb-col nk-tb-col-tools">
                                    <ul class="nk-tb-actions gx-2">
										<?php
										$rate    = ( $month > 0 ) ? number_format( $base_price * $rate * $month / 100 ) : 'نقدی';
										$actions = [
											[
												'link'  => '',
												'title' => 'ارزش کل: ' . number_format( $total_amount ),
												'icon'  => 'ni-sign-dollar',
											],
											[
												'link'  => '',
												'title' => 'وزن اولیه: ' . number_format( (float) $entry['total_qty_weight'], 4, '.', '' ),
												'icon'  => 'ni-opt-alt',
											],
										
										];
										echo kph_get_template( 'components/row-actions-hidden.php', [
											'actions' => $actions,
										] );
										?>
                                        <li>
											<?php
											$actions = [
												'delete'  => [
													'link'  => '',
													'title' => 'حذف آیتم',
													'icon'  => 'ni-trash',
													'class' => 'delete_db_item',
													'data'  => [
														'page'        => '/crm/produce-packaging',
														'item_id'     => $pack_id,
														'category_id' => $category_id,
														'action'      => 'kph_delete_processing_pack_item',
													],
												],
												'move'    => [
													'title' => 'انتقال به سالن',
													'icon'  => 'ni-reply-all',
													'class' => 'row_inline_action',
													'data'  => [
														'action'      => 'kph_transfer_pack_to_packaging',
														'item-id'     => $pack_id,
														'swal-title'  => 'انتقال آیتم به سالن',
														'category_id' => $category_id,
														'needs'       => json_encode( [
															[
																'type'  => 'text',
																'label' => 'وزن مورد نظر برای انتقال به سالن را به کیلوگرم وارد کنید.',
																'key'   => 'qty_weight',
																'max'   => $remaining,
															],
														] ),
													],
												],
												'return'  => [
													'title' => 'بازگشت به مخزن',
													'icon'  => 'ni-reply-all',
													'class' => 'row_inline_action',
													'data'  => [
														'action'      => 'kph_return_processing_pack_to_storage',
														'pack_id'     => $pack_id,
														'swal-title'  => 'بازگشت به مخزن',
														'category_id' => $category_id,
														'needs'       => json_encode( [] ),
													],
												],
												'divider' => [
													'divider' => TRUE,
												],
												[
													'link'  => '',
													'title' => 'آیتم های تشکیل دهنده',
													'class' => 'load_item_data_to_modal',
													'icon'  => 'ni-package',
													'data'  => [
														'item-id' => $entry['id'],
														'action'  => 'kph_load_processing_pack_inputs',
														'modal'   => '#processingPackInputs',
													],
												],
												[
													'link'  => '',
													'title' => 'گزارشات انتقال به سالن',
													'class' => 'load_item_data_to_modal',
													'icon'  => 'ni-repeat-v',
													'data'  => [
														'item-id' => $entry['id'],
														'action'  => 'kph_load_processing_to_packaging_report',
														'modal'   => '#processingToPackagingReport',
													],
												],
											];
											if ( $item_status != 'open' ) {
												unset( $actions['move'] );
												unset( $actions['divider'] );
											}
											echo kph_get_template( 'components/row-actions-dropdown.php', [
												'actions' => $actions,
											] );
											?>
                                        </li>
                                    </ul>
                                </div>
                            </div>
							<?php
						}
					}
					?>
                </div>
            </div>
            <div class="card-inner">
				<?php
				echo kph_get_template( 'components/pagination.php', [
					'max_page_num' => $total_page,
					'current_page' => $page_number,
					'class_name'   => 'user_pagination_link',
					'show_count'   => 2,
				] );
				?>
            </div>
        </div>
    </div>
</div>
<div class="nk-block-head nk-block-head-sm">
    <div class="nk-block-between">
        <div class="nk-block-head-content">
            <h3 class="nk-block-title page-title">آمار فرآوری:</h3>
        </div>
    </div>
</div>
<div class="nk-block">
    <div class="row g-gs">
        <div class="col-md-4">
            <div class="card card-full">
                <div class="card-inner">
                    <div class="card-title-group align-center mb-1">
                        <div class="card-title">
                            <h6 class="title">کل وزن فرآوری شده</h6>
                        </div>
                        <div class="card-amount">
                            <div class="amount">
								<?php echo number_format( $summery['total_processed'], 4, '.', '' ); ?>
                                <small class="currency currency-usd fs-12px">کیلوگرم</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card card-full">
                <div class="card-inner">
                    <div class="card-title-group align-center mb-1">
                        <div class="card-title">
                            <h6 class="title">وزن باقیمانده در فرآوری</h6>
                        </div>
                        <div class="card-amount">
                            <div class="amount">
								<?php echo number_format( $summery['current_in_processing'], 4, '.', '' ); ?>
                                <small class="currency currency-usd fs-12px">کیلوگرم</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card card-full">
                <div class="card-inner">
                    <div class="card-title-group align-center mb-1">
                        <div class="card-title">
                            <h6 class="title">وزن ارسالی به سالن</h6>
                        </div>
                        <div class="card-amount">
                            <div class="amount">
								<?php echo number_format( $summery['total_sent_to_packaging'], 4, '.', '' ); ?>
                                <small class="currency currency-usd fs-12px">کیلوگرم</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="addProcessingPack">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">افزودن آیتم فرآوری شده</h5>
                <a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
            </div>
            <div class="modal-body modal-body-md">
                <form action="#" class="modal_form" data-action="kph_create_processing_pack"
                      data-page="/crm/produce-packaging">
                    <div class="row g-gs">
                        <div class="col-12">
							<?php
							$batches = $DB->get_batches_list( [
								'page'        => 1,
								'per_page'    => 20,
								'category_id' => $category_id,
							] );
							if ( empty( $batches['items'] ) ) {
								echo "<div class='no-item-found'>آیتمی در مخزن برای ایجاد آیتم فرآوری شده موجود نیست.</div>";
							} else {
								?>
                                <div id="cheque_to_refer_table">
									<?php
									echo kph_get_template( 'partials/batch-table.php', [
										'batches' => $batches,
										'DB'      => $DB,
									] )
									?>
                                </div>
								<?php
							}
							?>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="processing_pack_code">شناسه محصول فرآوری شده</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="processing_pack_code"
                                           data-for="pack_code" data-req="1">
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="form-group">
                                <label class="form-label">توضیحات</label>
                                <div class="form-control-wrap">
                                    <div class="quill-basic" data-name="payment_note" data-for="note"
                                         data-req="1">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <input type="hidden" data-for="category_id" value="<?php echo $category_id; ?>">
                        <div class="col-12">
                            <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                <li>
                                    <div class="btn btn-primary submit_modal_form">ثبت</div>
                                </li>
                                <li>
                                    <a href="#" class="link link-light" data-bs-dismiss="modal">لغو</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

