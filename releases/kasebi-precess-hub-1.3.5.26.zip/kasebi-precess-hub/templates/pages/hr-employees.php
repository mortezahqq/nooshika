<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
if(!kph_hr::allowed()){echo '<p class="text-danger">دسترسی به منابع انسانی مجاز نیست.</p>';return;}
$hr=new kph_hr();$search=sanitize_text_field(wp_unslash($_REQUEST['hr_search']??''));$state=sanitize_key($_REQUEST['hr_employment']??'');$page=max(1,absint($_REQUEST['hr_page']??1));
$profiles=[];$employees=[];
foreach(get_users(['fields'=>'ids','orderby'=>'ID','order'=>'DESC','role__in'=>kph_hr::roles()]) as $id){$profile=$hr->profile((int)$id);$name=$profile['data']['full_name']??get_user_name_by_id($id);
if($state!==''&&$profile['status']!==$state){continue;}
if($search!==''&&mb_stripos($name.' '.$profile['employee_no'].' '.($profile['data']['department']??'').' '.($profile['data']['job_title']??''),$search)===FALSE){continue;}
$employees[]=(int)$id;$profiles[(int)$id]=$profile;
}
$total=count($employees);$pages=max(1,(int)ceil($total/20));$employees=array_slice($employees,($page-1)*20,20);
?>
<div class="kph-hr" data-nonce="<?php echo esc_attr(wp_create_nonce('kph_hr')); ?>"><div class="kph-hr-message alert d-none" role="status" aria-live="polite"></div>
<?php if (current_user_can('manage_options') && ($_GET['access_saved']??'')==='1') { ?><div class="alert alert-success" role="status">تنظیمات دسترسی ذخیره شد.</div><?php } ?>
<div class="nk-block-head nk-block-head-sm">
    <div class="nk-block-between">
        <div class="nk-block-head-content">
            <h3 class="nk-block-title page-title">لیست کارمندان</h3>
            <div class="nk-block-des text-soft">
                <p>شما در مجموع <?php echo $total; ?> کارمند دارید.</p>
            </div>
        </div>
        <div class="nk-block-head-content">
            <div class="toggle-wrap nk-block-tools-toggle card-tools ">
                <ul class="g-3 btn-toolbar">
<li><?php echo kph_get_template('components/filter-dropdown.php',['has_filter'=>$search!==''||$state!=='','filter_fields'=>[['type'=>'text','name'=>'hr_search','label'=>'نام، کد پرسنلی، واحد یا سمت','value'=>$search],['type'=>'select','name'=>'hr_employment','label'=>'وضعیت همکاری','value'=>$state,'options'=>[''=>'همه','active'=>'فعال','inactive'=>'پایان همکاری']]]]); ?></li>
<?php if (current_user_can('manage_options')) { ?><li><button type="button" class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#kphHrAccess"><em class="icon ni ni-lock"></em><span>سطوح دسترسی</span></button></li><?php } ?>
<li><a href="#kphHrCompany" class="btn btn-icon btn-trigger" data-bs-toggle="modal" title="اطلاعات کارفرما و پیگیری کارگزینی"><em class="icon ni ni-setting-alt"></em></a></li>
                    <li class="nk-block-tools-opt">
                        <div data-bs-toggle="tooltip" data-bs-placement="top" title="افزودن کارمند">
                            <div class="dropdown-toggle btn btn-icon btn-primary" data-bs-toggle="modal"
                                 data-bs-target="#kphHrAddEmployee"><em class="icon ni ni-plus"></em></div>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<div class="nk-block">
    <div class="row g-gs">
		<?php
		foreach ( $employees as $user_id ) {
			$name       = $profiles[$user_id]['data']['full_name']??get_user_name_by_id($user_id);
			$user_login = get_user_by( 'ID', $user_id )->user_login;
			$user_role  = nooshika_get_user_role( $user_id );
			$role       = kph_get_role_label( $user_role );
			?>
            <div class="col-4">
                <div class="card card-bordered card-full">
                    <div class="card-inner">
                        <div class="team">
                            <div class="team-options">
								<?php
								$actions = [
									[
										'link'  => kph_hr_url((int)$user_id,'hr_file'),
										'title' => 'مشخصات کارمند',
										'icon'  => 'ni-eye',
										'class' => 'page_activator',
									],
									[
										'link'  => '',
										'title' => 'ورود با کارمند',
										'icon'  => 'ni-signin',
										'class' => 'login_as_this',
										'data'  => [
											'id' => $user_id,
										],
									],
									[
'link'=>add_query_arg('tab','financial',home_url('/crm/employee/'.$user_id)),
'title'=>'حسابداری','icon'=>'ni-coin-alt','class'=>'page_activator',
],
[ 'divider' => 'divider' ],
									[
										'link'  => '',
										'title' => 'بازنشانی رمز عبور',
										'icon'  => 'ni-repeat',
										'class' => 'reset_password',
										'data'  => [
											'id' => $user_id,
										],
									],
									[
										'link'  => '',
										'title' => 'حذف کارمند',
										'icon'  => 'ni-user-cross',
										'class' => 'delete_user',
										'data'  => [
											'user-id' => $user_id,
										],
									],
								];
								if (kph_hr_access::grants()!==null) {
                                    $actions=array_filter($actions,static fn($action)=>($action['class']??'')==='page_activator');
                                }
                                echo kph_get_template( 'components/row-actions-dropdown.php', [
									'actions' => $actions,'title'=>'','main_icon'=>'more-h',
								] );
								?>
                            </div>
                            <div class="user-card user-card-s2">
                                <div class="user-avatar md bg-white text-primary">
                                    <em class="icon ni ni-user-circle" style="font-size: 60px"></em>
                                </div>
                                <div class="user-info">
                                    <h6><?php echo esc_html($name); ?></h6>
                                    <span class="sub-text"><?php echo esc_html($role); ?></span>
                                    <span class="sub-text">@<?php echo esc_html($user_login); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
			<?php
		}
		?>
    </div>
</div>

<?php if(!$employees){ ?><div class="no-item-found">پرسنلی یافت نشد.</div><?php } ?>
<?php if($pages>1){ ?><nav aria-label="صفحه‌بندی پرسنل"><ul class="pagination"><?php for($i=1;$i<=$pages;$i++){if($i!==1&&$i!==$pages&&abs($i-$page)>2){continue;} ?><li class="page-item <?php echo $i===$page?'active':''; ?>"><a class="page-link page_activator" href="<?php echo esc_url(add_query_arg(['hr_page'=>$i,'hr_search'=>$search,'hr_employment'=>$state],home_url('/crm/hr-employees'))); ?>"><?php echo $i; ?></a></li><?php } ?></ul></nav><?php } ?>
<div class="modal fade" id="kphHrAddEmployee" tabindex="-1" aria-labelledby="kphHrAddEmployeeTitle"><div class="modal-dialog modal-lg"><div class="modal-content"><div class="modal-header"><h5 class="modal-title" id="kphHrAddEmployeeTitle">افزودن پرسنل</h5><a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a></div><div class="modal-body modal-body-md"><div class="kph-hr-message alert d-none" role="status" aria-live="polite"></div><form class="kph-hr-form" method="post"><input type="hidden" name="operation" value="create_employee"><div class="row g-gs"><?php foreach(['name'=>['نام و نام خانوادگی','text'],'employee_no'=>['کد پرسنلی یکتا','text'],'phone'=>['موبایل','text'],'email'=>['ایمیل (اختیاری)','text']] as $key=>$def){kph_hr_form_field($key,$def);} ?><div class="col-12"><ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2"><li><button class="btn btn-primary" type="submit">ثبت</button></li><li><a href="#" class="link link-light" data-bs-dismiss="modal">لغو</a></li></ul></div></div></form></div></div></div></div>
<div class="modal fade" id="kphHrCompany" tabindex="-1" aria-labelledby="kphHrCompanyTitle"><div class="modal-dialog modal-lg"><div class="modal-content"><div class="modal-header"><h5 class="modal-title" id="kphHrCompanyTitle">اطلاعات کارفرما</h5><a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a></div><div class="modal-body modal-body-md"><div class="kph-hr-message alert d-none" role="status" aria-live="polite"></div><form class="kph-hr-form" method="post"><input type="hidden" name="operation" value="company"><div class="row g-gs"><?php $company=(array)get_option('kph_hr_company',[]);foreach(kph_hr_employer_fields() as $key=>$def){kph_hr_form_field($key,$def,$company[$key]??'');} ?><div class="col-12"><button class="btn btn-primary" type="submit">ذخیره</button></div></div></form>
<?php $dash=$hr->dashboard(); ?><div class="nk-block"><h6 class="title">در انتظار تأیید</h6><ul class="list list-sm"><?php foreach($dash['pending'] as $row){ ?><li><?php echo esc_html((kph_hr::kinds()[$row['kind']]??$row['kind']).': '.$row['total']); ?></li><?php } ?></ul></div><?php if($dash['contracts']){ ?><div class="nk-block"><h6 class="title">قراردادهای منقضی‌شده یا نزدیک پایان</h6><ul class="list list-sm"><?php foreach($dash['contracts'] as $row){ ?><li><a class="page_activator" href="<?php echo esc_url(kph_hr_url((int)$row['employee_id'],'hr_contracts')); ?>"><?php echo esc_html(get_user_name_by_id($row['employee_id']).' — '.kph_hr_exports::date($row['date_to'])); ?></a></li><?php } ?></ul></div><?php } ?>
</div></div></div></div></div>

<?php if (current_user_can('manage_options')) echo kph_get_template('partials/hr-access.php'); ?>
