<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * @var $user_id
 */
$defaults   = [
	'per_page'    => 10,
	'page_number' => 1,
	'date'        => [
		'from' => '',
		'to'   => '',
	],
	'status'      => '',
];
$args       = wp_parse_args( $_REQUEST, $defaults );
$args       = array_map( fn( $v ) => $v == 0 ? '' : $v, $args );
$has_filter = kph_page_has_filter( $args, $defaults );
extract( array_intersect_key( $args, $defaults ) );
$date_from = $date['from'] ?? '';
$date_to   = $date['to'] ?? '';

$DB       = new kph_db();
$statuses = $DB->get_supplier_invoice_statuses();
$entries  = $DB->get_supplier_invoices( [
	'page'             => $page_number,
	'per_page'         => $per_page,
	'supplier_user_id' => $user_id,
	'status'           => $status,
	'date_from'        => $date_from ? nooshika_jalali_to_gregorian( $date_from ) : NULL,
	'date_to'          => $date_to ? nooshika_jalali_to_gregorian( $date_to ) : NULL,
] );

$total_page = $entries['pagination']['total_page'];
$entries    = $entries['items'];
?>
<div class="nk-block nk-block-between">
    <div class="nk-block-head">
        <h6 class="title">لیست فاکتور ها</h6>
    </div>
    <ul class="btn-toolbar gx-1">
        <li>
			<?php
			$filter_fields = [
				[
					'type'  => 'date-range',
					'label' => 'تاریخ فاکتور',
					'name'  => 'date',
					'value' => [
						'from' => $date_from ?? '',
						'to'   => $date_to ?? '',
					],
				],
				[
					'type'    => 'select',
					'label'   => 'وضعیت فاکتور',
					'name'    => 'status',
					'value'   => $status,
					'options' => [ 0 => 'همه موارد' ] + array_combine(
							array_keys( $statuses ),
							array_column( $statuses, 'label' )
						),
				],
				[
					'type'  => 'hidden',
					'name'  => 'tab',
					'value' => 'orders',
				],
			];
			echo kph_get_template( 'components/filter-dropdown.php', [
				'has_filter'    => $has_filter,
				'filter_fields' => $filter_fields,
			] );
			?>
        </li>
    </ul>
</div>
<div class="nk-block">
	<?php
	if ( empty( $entries ) ) {
		echo '<div class="no_massages">فاکتوری برای نمایش وجود ندارد.</div>';
	} else {
		?>
        <div class="card">
            <div class="nk-tb-list nk-tb-ulist is-compact">
                <div class="nk-tb-item nk-tb-head">
                    <div class="nk-tb-col"><span class="sub-text">تاریخ ثبت</span></div>
                    <div class="nk-tb-col"><span class="sub-text">جمع کل</span></div>
                    <div class="nk-tb-col"><span class="sub-text">باقیمانده</span></div>
                    <div class="nk-tb-col"><span class="sub-text">وضعیت</span></div>
                    <div class="nk-tb-col nk-tb-col-tools text-end"></div>
                </div>
				<?php
				foreach ( $entries as $entry ) {
					$date           = date_i18n( 'Y/m/d', strtotime( $entry['issued_at'] ) );
					$amount         = number_format( $entry['total_amount'] );
					$note           = $entry['note'];
					$invoice_status = $statuses[ $entry['status'] ] ?? [
							'class' => 'secondary',
							'label' => $entry['status'],
						];
					$attachment     = $DB->get_invoice_meta( $entry['id'], 'attachments' );
					$settlement     = $DB->get_supplier_invoice_settlement_remaining( $entry['id'] );
					$remaining      = number_format( $settlement['data']['remaining'] ?? 0 );
					?>
                    <div class="nk-tb-item">
                        <div class="nk-tb-col">
                            <span><?php echo esc_html( $date ); ?></span>
                        </div>
                        <div class="nk-tb-col">
                            <div class="amount">
                                <span><?php echo esc_html( $amount ); ?></span>
                            </div>
                        </div>
                        <div class="nk-tb-col">
                            <div class="amount">
                                <span><?php echo esc_html( $remaining ); ?></span>
                            </div>
                        </div>
                        <div class="nk-tb-col">
                            <span class="badge bg-<?php echo esc_attr( $invoice_status['class'] ); ?>">
                                <?php echo esc_html( $invoice_status['label'] ); ?></span>
                        </div>
                        <div class="nk-tb-col">
                            <ul class="nk-tb-actions gx-2">
								<?php
								$hidden_actions = [
									[
										'link'  => '',
										'title' => 'آیتم های فاکتور',
										'class' => 'load_invoice_items_table',
										'icon'  => 'ni-package',
										'data'  => [
											'invoice-id' => $entry['id'],
										],
									],
								];
								echo kph_get_template( 'components/row-actions.php', [
									'actions' => $hidden_actions,
								] );
								
								if ( $note ) {
									?>
                                    <li class="nk-tb-action">
                                        <div class="btn btn-sm btn-icon btn-trigger"
                                             data-bs-toggle="popover"
                                             data-bs-trigger="hover"
                                             data-bs-html="true"
                                             title="یادداشت"
                                             data-bs-content="<?php echo esc_attr( wpautop( $note ) ); ?>"
                                             data-bs-placement="top">
                                            <em class="icon ni ni-note-add-c"></em>
                                        </div>
                                    </li>
									<?php
								}
								
								if ( $attachment ) {
									$attachment = explode( ',', $attachment );
									?>
                                    <li class="nk-tb-action">
										<?php
										$actions = [];
										foreach ( $attachment as $url ) {
											$file_data = $DB->get_uploaded_file_data( $url );
											$file_name = $file_data ? $file_data['original_name'] : $url;
											$actions[] = [
												'link'     => $url,
												'title'    => $file_name,
												'icon'     => 'ni-download',
												'target'   => '_blank',
												'download' => TRUE,
											];
										}
										echo kph_get_template( 'components/row-actions-dropdown.php', [
											'actions'   => $actions,
											'main_icon' => 'file-docs',
											'title'     => 'فایل ضمیمه',
										] );
										?>
                                    </li>
									<?php
								}
								
								if ( 'proforma' === $entry['status'] ) {
									?>
                                    <li>
										<?php
										$actions = [
											'edit'    => [
												'link'   => home_url() . "/crm/order-supplier-edit?invoice_id={$entry['id']}",
												'icon'   => 'ni-edit',
												'title'  => 'ویرایش فاکتور',
												'target' => '_blank',
											],
											'confirm' => [
												'link'  => '',
												'title' => 'تایید فاکتور',
												'icon'  => 'ni-check-round-cut',
												'class' => 'change_invoice_status',
												'data'  => [
													'invoice-id' => $entry['id'],
													'status'     => 'confirmed',
													'user-id'    => $user_id,
												],
											],
										];
										echo kph_get_template( 'components/row-actions-dropdown.php', [
											'actions' => $actions,
										] );
										?>
                                    </li>
									<?php
								}
								?>
                            </ul>
                        </div>
                    </div>
					<?php
				}
				?>
            </div>
        </div>
        <div class="p-1 mt-2">
			<?php
			echo kph_get_template( 'components/pagination.php', [
				'max_page_num' => $total_page,
				'current_page' => $page_number,
				'show_count'   => 2,
				'data'         => [
					'tab' => 'orders',
				],
			] );
			?>
        </div>
		<?php
	}
	?>
</div>
