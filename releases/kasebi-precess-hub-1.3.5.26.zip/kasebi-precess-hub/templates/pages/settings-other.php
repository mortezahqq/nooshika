<?php

$defaults = [
	'tab' => 'kph_user_work_type',
];
$args     = wp_parse_args( $_REQUEST, $defaults );
extract( array_intersect_key( $args, $defaults ) );

$options_list = [
	'kph_user_work_type' => [
		'label' => 'فعالیت مشتری',
	],
	//	'kph_user_level'     => [
	//		'label' => 'سطح مشتری',
	//	],
	'kph_user_category'  => [
		'label' => 'دسته بندی مشتریان',
	],
	'kph_cost_category'  => [
		'label' => 'دسته بندی هزینه ها',
	],
	'kph_cost_secondary_category' => [
		'label' => 'دسته‌بندی ثانویه هزینه',
	],
];
$cost_secondary_categories = get_option( 'kph_cost_secondary_category', [] );
$cost_secondary_categories = is_array( $cost_secondary_categories ) ? $cost_secondary_categories : [];

?>
<div class="nk-block nk-block-lg">
    <div class="card card-preview">
        <div class="card-inner">
            <div class="row g-gs">
                <div class="col-md-4">
                    <ul class="nav link-list-menu border border-light round m-0" role="tablist">
						<?php
						foreach ( $options_list as $key => $option_item ) {
							$class = $tab == $key ? 'active' : '';
							?>
                            <li>
                                <a data-bs-toggle="tab" href="#<?php echo $key; ?>" class="<?php echo $class; ?>">
                                    <span><?php echo $option_item['label']; ?></span>
                                </a>
                            </li>
							<?php
						}
						?>
                    </ul>
                </div>
                <div class="col-md-8">
                    <div class="tab-content">
						<?php
						foreach ( $options_list as $key => $option_item ) {
							$options_list = get_option( $key ) ?: [];
							$options_list = is_array( $options_list ) ? $options_list : [];
							$class        = $tab == $key ? 'tab-pane active show' : 'tab-pane';
							?>
                            <div class="<?php echo $class; ?>" id="<?php echo $key; ?>">
                                <div class="card card-bordered mt-2">
                                    <div class="card-inner p-0">
                                        <div class="nk-tb-list nk-tb-ulist is-compact">
                                            <div class="nk-tb-item nk-tb-head">
                                                <div class="nk-tb-col"><span class="sub-text">عنوان</span></div>
                                                <div class="nk-tb-col"><span class="sub-text">نامک</span></div>
										<?php if ( $key === 'kph_cost_category' ) { ?>
											<div class="nk-tb-col"><span class="sub-text">دسته‌بندی ثانویه</span></div>
										<?php } ?>
                                                <div class="nk-tb-col nk-tb-col-tools text-end">
                                                    <ul class="nk-tb-actions gx-2">
                                                        <li class="nk-tb-action">
                                                            <div class="btn btn-sm btn-icon"
                                                                 data-bs-toggle="tooltip"
                                                                 data-bs-placement="top"
                                                                 data-bs-original-title="افزودن">
                                                                <a class="btn btn-sm btn-icon open_options_modal"
                                                                   data-bs-toggle="modal"
                                                                   data-tab="<?php echo $key; ?>"
                                                                   data-option-key="<?php echo $key; ?>"
                                                                   data-bs-target="#addNewOptionItem">
                                                                    <em class="icon ni ni-plus"></em>
                                                                </a>
                                                            </div>
                                                        </li>

                                                    </ul>
                                                </div>
                                            </div>
											<?php
											foreach ( $options_list as $index => $data ) {
												?>
                                                <div class="nk-tb-item">
                                                    <div class="nk-tb-col">
                                                        <div class="align-center">
                                                            <div class="lead-text"><?php echo $data['label']; ?></div>
                                                        </div>
                                                    </div>
                                                    <div class="nk-tb-col">
                                                        <span><?php echo $index; ?></span>
                                                    </div>
											<?php if ( $key === 'kph_cost_category' ) {
												$secondary_key = $data['secondary_category'] ?? '';
												?>
												<div class="nk-tb-col">
													<span><?php echo esc_html( $cost_secondary_categories[ $secondary_key ]['label'] ?? 'بدون دسته' ); ?></span>
												</div>
											<?php } ?>
                                                    <div class="nk-tb-col nk-tb-col-tools">
                                                        <ul class="nk-tb-actions gx-2">
                                                            <li>
																<?php
																echo kph_get_template( 'components/row-actions-dropdown.php', [
																	'actions' => [
																		[
																			'link'  => '',
																			'title' => 'ویرایش آیتم',
																			'icon'  => 'ni-edit',
																			'class' => 'edit_item',
																			'data'  => [
																				'modal'  => 'addNewOptionItem',
																				'label'  => $data['label'],
																				'index'  => $index,
																								'tab'    => $key,
																								'option' => $key,
																								'secondary_category' => $data['secondary_category'] ?? '',
																			],
																		],
																		[
																			'link'  => '',
																			'title' => 'حذف آیتم',
																			'icon'  => 'ni-trash-alt',
																			'class' => 'delete_db_item',
																			'data'  => [
																				'page'    => '/crm/settings-other',
																				'tab'     => $key,
																				'item_id' => $index,
																				'action'  => 'kph_delete_option_item',
																			],
																		],
																	],
																] );
																?>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
												<?php
											}
											?>
                                        </div>
                                    </div>
                                </div>
                            </div>
							<?php
						}
						?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="modal fade zoom" id="addNewOptionItem">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">افزودن آیتم</h5>
                <a href="#" class="close" data-bs-dismiss="modal" aria-label="بستن">
                    <em class="icon ni ni-cross"></em>
                </a>
            </div>
            <div class="modal-body">
                <form action="#" class="modal_form" data-action="kph_add_option_item"
                      data-page="/crm/settings-other">
                    <div class="row g-gs">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="method_label">عنوان</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="method_label" data-for="label">
                                </div>
                            </div>
                        </div>
						<div class="col-md-6 d-none" id="cost_secondary_category_field">
							<div class="form-group">
								<label class="form-label" for="method_secondary_category">دسته‌بندی ثانویه</label>
								<div class="form-control-wrap">
									<select class="form-select" id="method_secondary_category" data-for="secondary_category">
										<option value="">بدون دسته‌بندی ثانویه</option>
										<?php foreach ( $cost_secondary_categories as $secondary_key => $secondary_data ) { ?>
											<option value="<?php echo esc_attr( $secondary_key ); ?>">
												<?php echo esc_html( $secondary_data['label'] ?? $secondary_key ); ?>
											</option>
										<?php } ?>
									</select>
								</div>
							</div>
						</div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="method_key">نامک</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="method_key" data-for="index">
                                </div>
                            </div>
                        </div>
                        <input type="hidden" id="options_tab" data-for="tab" value="">
                        <input type="hidden" id="options_key" data-for="option" value="">
                        <div class="col-12">
                            <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                <li>
                                    <div class="btn btn-primary submit_modal_form">ثبت اطلاعات</div>
                                </li>
                                <li>
                                    <a href="#" class="link link-light" data-bs-dismiss="modal">لغو</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer bg-light">
                <span class="sub-text">کلید شیوه حتما بایستی لاتین و فاقد فاصله باشد.</span>
                <br>
                <span class="sub-text">در صورت تکراری بودن نامک مقدار جدید جایگزین مقدار قدیمی می شود.</span>
            </div>
        </div>
    </div>
</div>
