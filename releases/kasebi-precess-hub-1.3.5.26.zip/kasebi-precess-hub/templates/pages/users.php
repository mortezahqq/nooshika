<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
$per_page_key = basename( __FILE__, '.php' );
$per_page_key = "kph_{$per_page_key}_per_page";
$user_id      = get_current_user_id();
$defaults     = [
	'page_number'  => 1,
	'per_page'     => get_user_meta( $user_id, $per_page_key, TRUE ) ?: 20,
	'register'     => [
		'from' => '',
		'to'   => '',
	],
	'level'        => '',
	'category'     => '',
	'balance_side' => '',
];
$args         = wp_parse_args( $_REQUEST, $defaults );
$args         = array_map( fn( $v ) => $v == 0 ? '' : $v, $args );
$has_filter   = kph_page_has_filter( $args, $defaults );
extract( array_intersect_key( $args, $defaults ) );
update_user_meta( $user_id, $per_page_key, $per_page );
$offset = ( $page_number - 1 ) * $per_page;

$DB              = new kph_db();
$ledger_sides    = $DB->get_ledger_sides();
$customer_levels = $DB->get_customer_levels();
$categories      = get_option( 'kph_user_category' ) ?: [];

$user_args    = [
	'order'       => 'DESC',
	'orderby'     => 'user_registered',
	'number'      => $per_page,
	'offset'      => $offset,
	'count_total' => TRUE,
	'fields'      => 'ids',
	'role__in'    => [ 'subscriber' ],
];
$can_account = kph_crm_section('finance', !kph_support_accounting_restricted());
$balance_side = $can_account ? sanitize_key($balance_side) : '';

if ( in_array( $balance_side, [ 'debit', 'credit' ], TRUE ) ) {
	$balance_user_ids     = $DB->get_user_ids_by_ledger_balance_side( $balance_side );
	$user_args['include'] = ! empty( $balance_user_ids ) ? $balance_user_ids : [ 0 ];
}
$user_metas = [
	'level'    => [ 'meta_key' => 'customer_level', 'compare' => 'LIKE' ],
	'category' => [ 'meta_key' => 'customer_category', 'compare' => 'LIKE' ],
];
foreach ( $user_metas as $meta => $user_meta ) {
	if ( $args[ $meta ] ) {
		$user_args['meta_query'][] = [
			'key'     => $user_meta['meta_key'],
			'compare' => $user_meta['compare'],
			'value'   => $args[ $meta ],
		];
	}
}
if ( ! empty( $user_args['meta_query'] ) ) {
	$user_args['meta_query']['relation'] = 'AND';
}

$register_from = $register['from'] ?? '';
$register_to   = $register['to'] ?? '';

if ( $register_from || $register_to ) {
	$user_args['date_query'] = [
		[
			'column'    => 'user_registered',
			'inclusive' => TRUE,
			'after'     => $register_from ? nooshika_jalali_to_gregorian( $register_from ) : NULL,
			'before'    => $register_to ? nooshika_jalali_to_gregorian( $register_to ) : NULL,
		],
	];
}
$user_query  = new WP_User_Query( $user_args );
$users       = $user_query->get_results();
$total_users = $user_query->get_total();
$total_page  = ceil( $total_users / $per_page );
?>
<div class="nk-block-head nk-block-head-sm">
    <div class="nk-block-between">
        <div class="nk-block-head-content">
            <h3 class="nk-block-title page-title">لیست مشتریان</h3>
            <div class="nk-block-des text-soft">
                <p class="mb-0">شما در مجموع <?php echo $total_users; ?> مشتری دارید.</p>
            </div>
        </div>
        <div class="nk-block-head-content">
            <div class="toggle-wrap nk-block-tools-toggle">
                <div class="toggle-expand-content">
                    <ul class="nk-block-tools g-3">
                        <li class="nk-block-tools-opt">
                            <a href="#addCustomer" class=" btn btn-icon btn-primary" data-bs-target="#addCustomer"
                               data-bs-toggle="modal"><em class="icon ni ni-plus"></em></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="nk-block">
    <div class="card">
        <div class="card-inner py-3">
            <div class="d-flex flex-wrap" style="gap: 10px">
                <a href="/crm/users" data-url="/crm/users"
                   class="btn btn-sm page_activator <?php echo empty( $category ) ? 'btn-primary' : 'btn-outline-light'; ?>">
                    همه
                </a>
				
				<?php foreach ( $categories as $category_key => $category_item ) : ?>
					<?php
					$url = add_query_arg(
						'category',
						$category_key,
						'/crm/users'
					);
					?>
                    <a href="<?php echo esc_url( $url ); ?>"
                       data-url="<?php echo esc_attr( $url ); ?>"
                       class="page_activator btn btn-sm <?php echo $category === $category_key ? 'btn-primary' : 'btn-outline-light'; ?>">
						<?php echo esc_html( $category_item['label'] ); ?>
                    </a>
				<?php endforeach; ?>
            </div>
        </div>
    </div>
</div>
<div class="nk-block">
    <div class="card card-stretch">
        <div class="card-inner-group">
            <div class="card-inner position-relative card-tools-toggle">
                <div class="card-title-group">
                    <div class="card-tools">
                    </div>
                    <div class="card-tools">
                        <ul class="btn-toolbar gx-1">
                            <li>
								<?php
								$filter_fields = [
									[
										'type'  => 'date-range',
										'label' => 'بازه ثبت‌نام',
										'name'  => 'register',
										'value' => [
											'from' => $register_from ?? '',
											'to'   => $register_to ?? '',
										],
									],
									[
										'type'    => 'select',
										'label'   => 'سطح مشتری',
										'name'    => 'level',
										'value'   => $level,
										'col'     => 6,
										'options' => [ 0 => 'همه موارد' ] + array_combine(
												array_keys( $customer_levels ),
												array_column( $customer_levels, 'label' )
											),
									],
									[
										'type'    => 'select',
										'label'   => 'دسته مشتری',
										'name'    => 'category',
										'value'   => $category,
										'col'     => 6,
										'options' => [ 0 => 'همه موارد' ] + array_combine(
												array_keys( $categories ),
												array_column( $categories, 'label' )
											),
									],
									[
										'type'    => 'select',
										'label'   => 'وضعیت حسابداری',
										'name'    => 'balance_side',
										'value'   => $balance_side,
										'col'     => 6,
										'options' => [
											0        => 'همه موارد',
											'debit'  => $ledger_sides['debit']['label'],
											'credit' => $ledger_sides['credit']['label'],
										],
									],
								];
								echo kph_get_template( 'components/filter-dropdown.php', [
									'has_filter'    => $has_filter,
									'filter_fields' => $filter_fields,
								] );
								?>
                            </li>
                            <li class="btn-toolbar-sep"></li>
                            <li>
								<?php
								echo kph_get_template( 'components/per-page-selector.php', [
									'per_page' => $per_page,
								] );
								?>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="card-inner p-0 overflow-auto">
                <div class="nk-tb-list nk-tb-ulist is-compact">
                    <div class="nk-tb-item nk-tb-head">
                        <div class="nk-tb-col"><span class="sub-text">کاربر</span></div>
                        <div class="nk-tb-col"><span class="sub-text">سطح مشتری</span></div>
                        <div class="nk-tb-col"><span class="sub-text">دسته مشتری</span></div>
                        <?php if ($can_account) { ?><div class="nk-tb-col text-center"><span class="sub-text">باقیمانده حسابداری</span></div><?php } ?>
                        <div class="nk-tb-col text-end"><span class="sub-text">تاریخ عضویت</span></div>
                        <div class="nk-tb-col text-end nk-tb-col-tools"></div>
                    </div>
					<?php
					if ( empty( $users ) ) {
						echo '<div class="no-item-found">کاربر یافت نشد</div>';
					} else {
						foreach ( $users as $user_id ) {
							$level    = get_user_meta( $user_id, 'customer_level', TRUE );
							$category = get_user_meta( $user_id, 'customer_category', TRUE );
							$balance = $can_account ? $DB->get_ledger_balance_now($user_id) : ['balance'=>0];
							$balance  = $balance['balance'];
							$class    = '';
							$icon     = '';
							if ( $balance > 0 || $balance < 0 ) {
								$icon  = $balance < 0 ? 'ni-arrow-long-up' : 'ni-arrow-long-down';
								$class = $balance < 0 ? ' text-success' : ' text-danger';
							}
							$user_registered = get_the_author_meta( 'registered', $user_id );
							?>
                            <div class="nk-tb-item">
                                <div class="nk-tb-col">
									<?php
									echo kph_get_template( 'components/user-card.php', [
										'user_id'    => $user_id,
										'show_phone' => TRUE,
									] );
									?>
                                </div>
                                <div class="nk-tb-col">
									<?php
									if ( $level ) {
										?>
                                        <span
                                            class="badge badge-dot bg-<?php echo $customer_levels[ $level ]['class'];
											?> d-block text-start"><?php echo $customer_levels[ $level ]['label']; ?></span>
										<?php
									} else {
										echo '-';
									}
									?>
                                </div>
                                <div class="nk-tb-col">
									<?php
									if ( $category ) {
										?>
                                        <span
                                            class="badge badge-dot bg-info d-block text-start"><?php echo $categories[ $category ]['label']; ?></span>
										<?php
									} else {
										echo '-';
									}
									?>
                                </div>
                                <?php if ($can_account) { ?>
                                <div class="nk-tb-col text-center">
                                    <div class="amount<?php echo $class; ?>">
                                        <div class="">
                                            <span><?php echo number_format( abs( $balance ) ); ?></span>
											<?php
											if ( $icon ) {
												echo "<em class='icon ni $icon'></em>";
											}
											?>
                                        </div>
                                    </div>
                                </div>
                                <?php } ?>
                                <div class="nk-tb-col text-end">
									<?php echo date_i18n( 'j M, Y', strtotime( $user_registered ) ); ?>
                                </div>
                                <div class="nk-tb-col nk-tb-col-tools">
                                    <ul class="nk-tb-actions gx-2">
										<?php
										echo kph_get_template( 'components/row-actions-hidden.php', [
											'actions' => [
												[
													'link'  => '/crm/user/' . $user_id,
													'title' => 'مشاهده مشخصات',
													'icon'  => 'ni-eye',
													'class' => 'page_activator',
												],
												[
													'link'  => '/crm/user/' . $user_id . '?tab=financial',
													'title' => 'حسابداری',
													'icon'  => 'ni-coin-alt',
													'class' => 'page_activator',
												],
												[
													'link'  => '',
													'title' => 'حذف کاربر',
													'icon'  => 'ni-na',
													'class' => 'delete_user',
													'data'  => [
														'page'    => '/crm/users',
														'user-id' => $user_id,
													],
												],
											],
										] );
										?>
                                    </ul>
                                </div>
                            </div>
							<?php
						}
					}
					?>
                </div>
            </div>
            <div class="card-inner">
				<?php
				echo kph_get_template( 'components/pagination.php', [
					'max_page_num' => $total_page,
					'current_page' => $page_number,
					'class_name'   => 'user_pagination_link',
					'show_count'   => 2,
				] );
				?>
            </div>
        </div>
    </div>
</div>

