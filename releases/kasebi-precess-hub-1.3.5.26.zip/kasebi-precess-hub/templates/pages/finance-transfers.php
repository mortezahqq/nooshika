<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
$per_page_key = basename( __FILE__, '.php' );
$per_page_key = "kph_{$per_page_key}_per_page";
$user_id      = get_current_user_id();
$defaults     = [
	'page_number' => 1,
	'per_page'    => get_user_meta( $user_id, $per_page_key, TRUE ) ?: 20,
	'date'        => [
		'from' => '',
		'to'   => '',
	],
];
$args         = wp_parse_args( $_REQUEST, $defaults );
$args         = array_map( fn( $v ) => $v == 0 ? '' : $v, $args );
$has_filter   = kph_page_has_filter( $args, $defaults );
extract( array_intersect_key( $args, $defaults ) );
update_user_meta( $user_id, $per_page_key, $per_page );

$date_from = $date['from'] ?? '';
$date_to   = $date['to'] ?? '';

$DB          = new kph_db();
$entries     = $DB->get_transfers_list( [
	'page'      => $page_number,
	'per_page'  => $per_page,
	'date_from' => $date_from ? nooshika_jalali_to_gregorian( $date_from ) : NULL,
	'date_to'   => $date_to ? nooshika_jalali_to_gregorian( $date_to ) : NULL,
] );
$total_page  = $entries['pagination']['total_page'];
$total_items = $entries['pagination']['total'];
$entries     = $entries['items'];
?>
<div class="nk-block-head nk-block-head-sm">
    <div class="nk-block-between">
        <div class="nk-block-head-content">
            <h6 class="title">لیست حواله ها</h6>
            <div class="nk-block-des text-soft">
                <p class="mb-0">شما در مجموع <?php echo $total_items; ?> حواله دارید.</p>
            </div>
        </div>
        <div class="nk-block-head-content">
            <div class="toggle-wrap nk-block-tools-toggle">
                <div class="toggle-expand-content">
                    <ul class="nk-block-tools g-3">
                        <li class="nk-block-tools-opt">
                            <a href="#" class="btn btn-icon btn-primary print_list_items" data-type="transfers"
                               data-collect="ids">
                                <em class="icon ni ni-printer"></em></a>
                        </li>
                        <li class="nk-block-tools-opt">
                            <a href="#addUserTransfer" class=" btn btn-icon btn-primary"
                               data-bs-target="#addUserTransfer"
                               data-bs-toggle="modal"><em class="icon ni ni-plus"></em></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="nk-block">
    <div class="card card-stretch">
        <div class="card-inner-group">
            <div class="card-inner position-relative card-tools-toggle">
                <div class="card-title-group">
                    <div class="card-tools">
                    </div>
                    <div class="card-tools">
                        <ul class="btn-toolbar gx-1">
                            <li>
								<?php
								$filter_fields = [
									[
										'type'  => 'date-range',
										'label' => 'تاریخ حواله',
										'name'  => 'date',
										'value' => [
											'from' => $date_from ?? '',
											'to'   => $date_to ?? '',
										],
									],
								];
								echo kph_get_template( 'components/filter-dropdown.php', [
									'has_filter'    => $has_filter,
									'filter_fields' => $filter_fields,
								] );
								?>
                            </li>
                            <li class="btn-toolbar-sep"></li>
                            <li>
								<?php
								echo kph_get_template( 'components/per-page-selector.php', [
									'per_page' => $per_page,
								] );
								?>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="card-inner p-0">
                <div class="nk-tb-list nk-tb-ulist is-compact">
                    <div class="nk-tb-item nk-tb-head">
                        <div class="nk-tb-col nk-tb-col-check"></div>
                        <div class="nk-tb-col"><span class="sub-text">کاربر</span></div>
                        <div class="nk-tb-col"><span class="sub-text">تاریخ حواله</span></div>
                        <div class="nk-tb-col"><span class="sub-text">مقدار</span></div>
                        <div class="nk-tb-col"><span class="sub-text">بانک</span></div>
                        <div class="nk-tb-col"><span class="sub-text">کد رهگیری</span></div>
                        <div class="nk-tb-col text-end nk-tb-col-tools"></div>
                    </div>
					<?php
					if ( empty( $entries ) ) {
						echo '<div class="no-item-found">حواله یافت نشد</div>';
					} else {
						foreach ( $entries as $entry ) {
							$user_id    = $entry['user_id'];
							$icon       = $entry['amount'] < 0 ? 'ni-arrow-long-up' : 'ni-arrow-long-down';
							$class      = $entry['amount'] < 0 ? 'text-success' : 'text-danger';
							$date       = date_i18n( 'j F Y', strtotime( $entry['transferred_at'] ) );
							$amount     = number_format( abs( $entry['amount'] ) );
							$note       = $entry['note'];
							$attachment = $DB->get_transfer_meta( $entry['id'], 'attachment' );
							?>
                            <div class="nk-tb-item">
                                <div class="nk-tb-col nk-tb-col-check">
                                    <div class="custom-control custom-control-sm custom-checkbox notext">
                                        <input type="checkbox" class="custom-control-input select_item_for_print"
                                               value="<?php echo $entry['id']; ?>"
                                               id="print_item_<?php echo $entry['id']; ?>">
                                        <label class="custom-control-label"
                                               for="print_item_<?php echo $entry['id']; ?>"></label>
                                    </div>
                                </div>
                                <div class="nk-tb-col">
									<?php
									echo kph_get_template( 'components/user-card.php', [
										'user_id'    => $user_id,
										'show_phone' => TRUE,
									] );
									?>
                                </div>
                                <div class="nk-tb-col">
                                    <span><?php echo $date; ?></span>
                                </div>
                                <div class="nk-tb-col">
                                    <div class="amount <?php echo $class; ?>">
                                        <span><?php echo $amount; ?></span>
										<?php echo "<em class='icon ni $icon'></em>"; ?>
                                    </div>
                                </div>
                                <div class="nk-tb-col">
                                    <span><?php echo $entry['bank_name']; ?></span>
                                </div>
                                <div class="nk-tb-col">
                                    <span><?php echo $entry['tracking_no']; ?></span>
                                </div>
                                <div class="nk-tb-col nk-tb-col-tools">
                                    <ul class="nk-tb-actions gx-2">
										<?php
										$role = nooshika_get_user_role( $user_id );
										$page = $role == 'supplier' ? 'supplier' : 'user';
										
										$hidden_actions = [
											[
												'link'  => "/crm/$page/$user_id",
												'title' => 'مشخصات کاربر',
												'icon'  => 'ni-eye',
												'class' => 'page_activator',
											],
											[
												'link'  => "/crm/$page/$user_id?tab=financial",
												'title' => 'تاریخچه حسابداری',
												'icon'  => 'ni-coin-alt',
												'class' => 'page_activator',
											],
										];
										if ( $entry['ref_id'] ) {
											$hidden_actions[] = [
												'link'  => "",
												'title' => "فاکتور #{$entry['ref_id']}",
												'icon'  => 'ni-file-text',
											];
										}
										echo kph_get_template( 'components/row-actions.php', [
											'actions' => $hidden_actions,
										] );
										if ( $note ) {
											?>
                                            <li class="nk-tb-action">
                                                <div class="btn btn-sm btn-icon btn-trigger"
                                                     data-bs-toggle="popover"
                                                     data-bs-trigger="hover"
                                                     data-bs-html="true"
                                                     title="یادداشت"
                                                     data-bs-content="<?php echo wpautop( $note ); ?>"
                                                     data-bs-placement="top">
                                                    <em class="icon ni ni-note-add-c"></em>
                                                </div>
                                            </li>
											<?php
										}
										if ( $attachment ) {
											$attachment = explode( ',', $attachment );
											?>
                                            <li class="nk-tb-action">
												<?php
												$actions = [];
												foreach ( $attachment as $url ) {
													$file_data = $DB->get_uploaded_file_data( $url );
													if ( ! $file_data ) {
														$file_name = $url;
													} else {
														$file_name = $file_data['original_name'];
													}
													$actions[] = [
														'link'     => $url,
														'title'    => $file_name,
														'icon'     => 'ni-download',
														'target'   => '_blank',
														'download' => TRUE,
													];
												}
												echo kph_get_template( 'components/row-actions-dropdown.php', [
													'actions'   => $actions,
													'main_icon' => 'file-docs',
													'title'     => 'فایل ضمیمه',
												] );
												?>
                                            </li>
											<?php
										}
										?>
                                        <li>
											<?php
											$actions = [
												'delete' => [
													'title' => 'حذف حواله',
													'icon'  => 'ni-trash',
													'class' => 'delete_db_item',
													'data'  => [
														'page'    => '/crm/finance-transfers',
														'item_id' => $entry['id'],
														'action'  => 'kph_delete_transfer',
													],
												],
											];
											echo kph_get_template( 'components/row-actions-dropdown.php', [
												'actions' => $actions,
											] );
											?>
                                        </li>
                                    </ul>
                                </div>
                            </div>
							<?php
						}
					}
					?>
                </div>
            </div>
            <div class="card-inner">
				<?php
				echo kph_get_template( 'components/pagination.php', [
					'max_page_num' => $total_page,
					'current_page' => $page_number,
					'class_name'   => 'user_pagination_link',
					'show_count'   => 2,
				] );
				?>
            </div>
        </div>
    </div>
</div>

