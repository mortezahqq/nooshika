<?php
if (!defined('ABSPATH') || !current_user_can('manage_options')) return;

$overview = $ERP->overview($range);
$totals = $overview['sales']['totals'];
$stock = $overview['stock']['summary'];
$period_labels = ['day'=>'روزانه', 'week'=>'هفتگی', 'month'=>'ماهانه', 'year'=>'سالانه'];
$details_url = $link('overview', ['erp_detail'=>'full']);

$stat = static function(string $label, $amount, string $unit, string $href, string $hint = '') use ($money) { ?>
    <a class="erp-summary-stat <?php echo str_contains($href,'#') ? '' : 'page_activator'; ?>" href="<?php echo esc_url($href); ?>">
        <span><?php echo esc_html($label); ?></span>
        <?php if ($amount === null) { ?><strong>محاسبه نشده</strong><?php } else { ?>
            <strong><bdi dir="ltr"><?php echo esc_html($money($amount)); ?></bdi> <small><?php echo esc_html($unit); ?></small></strong>
        <?php } ?>
        <?php if ($hint !== '') { ?><small class="text-soft"><?php echo esc_html($hint); ?></small><?php } ?>
    </a>
<?php };
$labels = $values = $urls = [];
foreach ($overview['sales']['points'] as $bucket=>$point) {
    $labels[] = $range['group']==='day' ? $date($point['from']) : ($range['group']==='week' ? 'هفتهٔ '.$date((string)$bucket) : (string)$bucket);
    $values[] = $point['sales'];
    $urls[] = $link('sales',['erp_from'=>$point['from'],'erp_to'=>$point['to']]);
}
?>
<div class="erp-summary">
<section class="card card-bordered mb-4" aria-labelledby="erp-summary-sales">
    <div class="card-inner">
        <h4 id="erp-summary-sales">فروش و سود</h4>
        <p class="text-soft">از <?php echo esc_html($date($range['from'])); ?> تا <?php echo esc_html($date($range['to'])); ?></p>
        <div class="erp-summary-stats">
            <?php
            $stat('فروش پس از کسر برگشتی‌ها',$totals['sales'],'ریال',$link('sales'),'مبلغ کالاهای ارسال‌شده، با کسر برگشت‌های ثبت‌شده در این بازه');
            $stat('سود ناخالص',$totals['gross'],'ریال',$link('sales'),'فروش پس از کسر بهای تمام‌شدهٔ کالا');
            $stat('برآورد سود پس از هزینه‌ها',$totals['operating'],'ریال',$link('settings'),
                $totals['operating']===null ? 'برای محاسبه، دسته‌های هزینه را در تنظیمات انتخاب کنید.' : 'سود ناخالص پس از کسر هزینه‌های عملیاتی انتخاب‌شده');
            ?>
        </div>
        <?php
        $chart('روند فروش '.($period_labels[$range['group']]??''), $labels, [$values], ['فروش پس از برگشت'], 'ریال', 'line', $urls);
        ?>
        <a class="btn btn-sm btn-outline-primary mt-3 page_activator" href="<?php echo esc_url($link('sales')); ?>">مشاهدهٔ فاکتورها و برگشت‌ها</a>
    </div>
</section>

<section class="card card-bordered mb-4" aria-labelledby="erp-summary-cash">
    <div class="card-inner">
        <h4 id="erp-summary-cash">حساب‌ها</h4><p class="text-soft">ماندهٔ امروز</p>
        <div class="erp-summary-stats"><?php
            $stat('موجودی بانک و صندوق',$overview['cash']['balance'],'ریال',$details_url.'#erp-cash');
            $stat('طلب ما از مشتریان',$overview['debts']['debit'],'ریال',$link('debts',['balance_side'=>'debit']));
            $stat('بستانکاری مشتریان',$overview['debts']['credit'],'ریال',$link('debts',['balance_side'=>'credit']),'مبلغی که در حساب مشتریان به نفع آن‌ها ثبت شده است');
        ?></div>
    </div>
</section>

<section class="card card-bordered mb-4" aria-labelledby="erp-summary-stock">
    <div class="card-inner">
        <h4 id="erp-summary-stock">موجودی کالا</h4><p class="text-soft">تعداد قلم کالا در هر وضعیت، امروز</p>
        <?php
        $states = ['normal'=>'موجودی کافی','low'=>'کمتر از حد سفارش','unconfigured'=>'حد سفارش تعیین نشده'];
        $total_items = $stock['normal'] + $stock['low'] + $stock['unconfigured'];
        if ($total_items > 0) {
            foreach ($states as $key=>$label) { ?>
                <div class="erp-stock-row"><div><span><?php echo esc_html($label); ?></span><strong><?php echo esc_html($money($stock[$key])); ?> قلم</strong></div>
                    <div class="erp-stock-track" aria-hidden="true"><span class="erp-stock-<?php echo esc_attr($key); ?>" style="width:<?php echo esc_attr((string)(100*$stock[$key]/$total_items)); ?>%"></span></div>
                </div>
            <?php }
        } else { ?><p>هنوز کالایی در گزارش موجودی ثبت نشده است.</p><?php } ?>
        <a class="btn btn-sm btn-outline-primary mt-3 page_activator" href="<?php echo esc_url($link('stock')); ?>">مشاهدهٔ فهرست کالاها</a>
    </div>
</section>

<section class="card card-bordered mb-4" aria-labelledby="erp-summary-tasks">
    <div class="card-inner">
        <h4 id="erp-summary-tasks">پیگیری امروز</h4>
        <div class="erp-summary-stats"><?php
            $stat('مشتری با پرداخت عقب‌افتاده',$overview['debts']['receivables']['overdue_count'],'مشتری',$link('debts',['debt_filter'=>'overdue']));
            $stat('کارهای مهم یا سررسیدشده',$overview['tasks']['today'],'کار',$link('tasks',['task_filter'=>'today']));
            $stat('کارهای عقب‌افتاده',$overview['tasks']['overdue'],'کار',$link('tasks',['task_filter'=>'overdue']));
        ?></div>
        <?php if ($overview['cash']['shortfall']>0) { ?><p class="alert alert-warning mt-3 mb-0">با سررسیدهای ثبت‌شده، ممکن است در ۳۰ روز آینده <bdi><?php echo esc_html($money($overview['cash']['shortfall'])); ?></bdi> ریال کسری داشته باشیم. <a href="<?php echo esc_url($details_url.'#erp-cash-forecast'); ?>">مشاهدهٔ سررسیدها</a></p><?php } ?>
    </div>
</section>
<a class="btn btn-primary page_activator" href="<?php echo esc_url($details_url); ?>">گزارش تفصیلی و مقایسه با دورهٔ قبل</a>
</div>
