<?php
if(!defined('ABSPATH')||!kph_hr::allowed()){return;}
$values=array_merge(['child_count'=>$profile['data']['child_count']??0],$hr->person_form_defaults($employee),(array)get_option('kph_hr_company',[]),$formValues,$formValues['person']??[],$formValues['employer']??[]);
$profileMonthlyBenefit = (int) ($profile['data']['employee_monthly_benefit'] ?? 0);
$profileSeniority = $profile['data']['seniority_mode'] ?? 'separate';
if ($kind === 'contract') $values['seniority_mode'] = $values['seniority_mode'] ?? $profileSeniority;
$contractOptions=[];$contractPage=1;
do{$contractList=$hr->listing($employee,'contract',$contractPage,'approved');foreach($contractList['items'] as $c){$contractOptions[(int)$c['id']]=$c;}$contractPage++;}while($contractPage<=$contractList['pages']);
if(!$editing){
    if($kind==='contract'){$values=array_merge(kph_hr::contract_defaults(),$values);$values['contract_date']=substr(current_time('mysql'),0,10);}
    if($kind==='settlement'){$values+=['template'=>'final','settlement_effect'=>'document_only','declaration_text'=>kph_hr::settlement_declaration(),'receipt_date'=>substr(current_time('mysql'),0,10)];}
}
if($kind==='contract'&&!isset($values['seniority_daily_rate'])){$values['seniority_daily_rate']=round(($values['seniority_base']??0)/max(1,(float)($values['normal_days']??30)),4);}
if($kind==='payslip'){
    $period=nooshika_sanitize_numbers($values['period']??'');if(!preg_match('/^(\d{4})[\/-](\d{1,2})$/D',$period,$m)){preg_match('/^(\d{4})\/(\d{2})/',nooshika_sanitize_numbers(kph_hr_exports::date(substr(current_time('mysql'),0,10))),$m);}
    $values['salary_year']=$m[1];$values['salary_month']=str_pad($m[2],2,'0',STR_PAD_LEFT);
    $monthInfo=$hr->salary_period($values);$values['calculation_mode']=$values['calculation_mode']??($editing?'contract':($contractOptions?'contract':'manual'));$values['work_source']=$values['work_source']??($editing?'attendance':'manual');
    $values['monthly_base']=$values['monthly_base']??$values['contract_snapshot']['rate']??0;$values['normal_days']=$values['normal_days']??$values['contract_snapshot']['normal_days']??30;
    $values['basis']=$values['calculation_mode']==='contract'?($values['basis']??$values['contract_snapshot']['basis']??'monthly'):'daily';$values['manual_rate_basis']='daily';
    if(!$editing&&$values['calculation_mode']==='contract'&&empty($values['contract_id'])){foreach($contractOptions as $candidate){if($candidate['date_from']<=$monthInfo['from']&&($candidate['date_to']===NULL||$candidate['date_to']>=$monthInfo['to'])){$values['contract_id']=$candidate['id'];break;}}}
    $activeContract=$values['calculation_mode']==='contract'?($contractOptions[(int)($values['contract_id']??0)]['data']??[]):[];
    if(!$editing&&$activeContract){$values['monthly_base']=$activeContract['rate'];$values['normal_days']=$activeContract['normal_days'];$values['overtime_rate']=$activeContract['overtime_rate']??0;}
    $values['seniority_mode'] = $activeContract['seniority_mode'] ?? $values['seniority_mode'] ?? $profileSeniority;
    $values['housing']=$values['housing_monthly_cap']??$activeContract['housing']??$values['housing']??30000000;
    $values['food_allowance']=$values['food_monthly_cap']??$activeContract['food_allowance']??$values['food_allowance']??22000000;
    $values['seniority_daily_rate']=$activeContract['seniority_daily_rate']??$values['seniority_daily_rate']??(round(($activeContract['seniority_base']??$values['seniority_base']??0)/max(1,(float)($activeContract['normal_days']??$values['normal_days']??30)),4));
    $values['paid_days']=$values['paid_days']??min((float)$values['normal_days'],(float)$monthInfo['days']);$values['overtime_hours']=$values['overtime_hours']??(($values['work_snapshot']['overtime_minutes']??0)/60);$values['overtime_rate']=$values['overtime_rate']??$values['contract_snapshot']['overtime_rate']??0;
}
?>
<form class="kph-hr-form kph-hr-advanced mt-3" data-kind="<?php echo esc_attr($kind); ?>" <?php if($kind==='payslip'){ ?>data-unlocked-seniority="<?php echo esc_attr(empty($activeContract['seniority_mode']) ? $values['seniority_mode'] : $profileSeniority); ?>" data-profile-benefit="<?php echo $profileMonthlyBenefit; ?>" data-period-days="<?php echo (int)$monthInfo['days']; ?>" data-benefit-work="<?php echo esc_attr(wp_json_encode($values['benefit_work_snapshot']??['unpaid_minutes'=>0,'absence_days'=>0])); ?>"<?php } ?> data-declarations="<?php $decls=[];foreach(kph_hr::settlement_templates() as $key=>$label){$decls[$key]=kph_hr::settlement_declaration($key);}echo esc_attr(wp_json_encode($decls)); ?>" method="post">
<input type="hidden" name="operation" value="save"><input type="hidden" name="form_version" value="2"><input type="hidden" name="employee_id" value="<?php echo (int)$employee; ?>"><input type="hidden" name="kind" value="<?php echo esc_attr($kind); ?>"><input type="hidden" name="record_id" value="<?php echo (int)($editing['id']??0); ?>"><input type="hidden" name="version" value="<?php echo (int)($editing['version']??0); ?>">
<?php if($kind==='payslip'){ ?><input type="hidden" name="benefits_version" value="1"><input type="hidden" name="manual_rate_basis" value="<?php echo esc_attr($values['manual_rate_basis']); ?>"><?php } ?><div class="row g-gs">
<?php foreach(kph_hr_fields($kind) as $key=>$def){
    if ($kind === 'contract' && $key === 'employee_monthly_benefit') {
        if (!$profileMonthlyBenefit && !array_key_exists($key, $values)) continue;
        $values[$key] = $values[$key] ?? $profileMonthlyBenefit;
    }
    if($def[1]==='contract'){ ?>
        <div class="col-md-6 kph-hr-contract-field"><div class="form-group"><label class="form-label">قرارداد تأییدشده</label><div class="form-control-wrap"><select class="form-select kph-hr-contract-picker" name="contract_id"><option value="0">انتخاب کنید</option><?php foreach($contractOptions as $id=>$contract){$data=$contract['data'];$summary=array_intersect_key($data,array_flip(['rate','basis','normal_days','overtime_rate','housing','food_allowance','marriage_allowance','child_allowance','seniority_base','seniority_daily_rate','seniority_mode','employee_monthly_benefit','employer'])); ?><option value="<?php echo (int)$id; ?>" data-contract="<?php echo esc_attr(wp_json_encode($summary)); ?>" <?php selected($values['contract_id']??0,$id); ?>><?php echo esc_html('#'.$id.' — '.$data['title'].' — '.kph_hr_exports::date($contract['date_from']).' تا '.kph_hr_exports::end_date($contract['date_to'])); ?></option><?php } ?></select></div></div></div>
    <?php }else{if($kind==='payslip'&&in_array($key,['housing','food_allowance'],TRUE)){$def[0]=$key==='housing'?'سقف ماهانه حق مسکن طبق قرارداد (ریال)':'سقف ماهانه بن کارگری طبق قرارداد (ریال)';}$value=$values[$key]??($def[1]==='number'&&!in_array($key,['receipt_amount'],TRUE)?0:'');kph_hr_form_field($key,$def,$value);} ?>
<?php } ?></div>
<?php if($kind==='payslip'){ ?><div class="alert alert-info kph-hr-period-hint">بازهٔ فیش: <?php echo esc_html(kph_hr_exports::date($monthInfo['from']).' تا '.kph_hr_exports::date($monthInfo['to'])); ?>؛ <?php echo (int)$monthInfo['days']; ?> روز تقویمی.</div>
<p class="text-soft kph-hr-benefit-hint">پایه سنوات روزانه × روزهای مشمول؛ حق مسکن و بن = سقف ماهانه × روزهای مشمول ÷ ۳۰، حداکثر برابر سقف قرارداد. هر روز مرخصی بدون حقوق ۴۸۰ دقیقه است؛ فقط غیبت و مرخصی بدون حقوق تأییدشده در کسر خودکار لحاظ می‌شود و مرخصی استحقاقی کسر نمی‌شود. روزهای مشمول حقوق را خالص وارد کنید تا دوباره کسر نشود.</p>
<p class="kph-hr-benefit-preview" aria-live="polite"><?php foreach(['days'=>'روزهای مشمول مزایا','housing'=>'حق مسکن این ماه','food'=>'بن کارگری این ماه','seniority'=>'پایه سنوات این ماه'] as $key=>$label){ ?><span class="d-inline-block me-3 mb-2"><?php echo esc_html($label); ?>: <strong data-benefit-total="<?php echo esc_attr($key); ?>">—</strong><?php echo $key==='days'?' روز':' ریال'; ?></span><?php } ?></p>
<p class="text-soft kph-hr-monthly-benefit"<?php if (empty($activeContract['employee_monthly_benefit'] ?? $profileMonthlyBenefit)) echo ' hidden'; ?>>سایر مزایای به تبع شاغل در جمع مزد دوره (ریال): <strong><?php echo number_format($activeContract['employee_monthly_benefit'] ?? $profileMonthlyBenefit); ?></strong></p>
<p class="kph-hr-pay-preview" aria-live="polite"><?php foreach(['daily'=>'مزد روزانه','base'=>'جمع مزد دوره','gross'=>'جمع حقوق و مزایا','deductions'=>'جمع کسورات و مساعده','payable'=>'مبلغ قابل پرداخت'] as $key=>$label){ ?><span class="d-inline-block me-3 mb-2"><?php echo esc_html($label); ?>: <strong data-pay-total="<?php echo esc_attr($key); ?>">—</strong> ریال</span><?php } ?></p><p class="text-soft">در روش دستی، مبلغ ورودی «مزد روزانه» است و در تعداد روزهای مشمول حقوق ضرب می‌شود (برای ۳۰ روز: مزد روزانه × ۳۰). در روش قراردادی، مزد روزانه از مبنای قرارداد محاسبه می‌شود؛ اگر مبنای قرارداد ماهانه باشد، حقوق ماهانه بر روزهای مبنا تقسیم می‌شود و اگر روزانه باشد، نرخ قرارداد مزد هر روز است. مبلغ نهایی پس از ذخیره در سرور محاسبه می‌شود. در حالت کارکرد تأییدشده، ساعات عادی و اضافه‌کاری از سوابق همان ماه خوانده می‌شود. بیمه و مالیات، مبلغ تأییدشدهٔ همین ماه هستند. مساعدهٔ پرداخت‌شده را در سایر کسورات دوباره وارد نکنید.</p><?php } ?>
<button class="btn btn-primary" type="submit">ذخیره پیش‌نویس<?php echo $kind==='payslip'?' و محاسبه فیش':''; ?></button>
<?php if($editing){ ?><a class="btn btn-light page_activator" href="<?php echo esc_url(kph_hr_url($employee,$active)); ?>">انصراف از ویرایش</a><?php } ?>
</form>
