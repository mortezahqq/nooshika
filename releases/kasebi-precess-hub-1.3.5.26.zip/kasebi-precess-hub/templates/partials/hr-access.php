<?php
if (!defined('ABSPATH') || !current_user_can('manage_options')) return;
$state=kph_hr_access::state();
$levels=$state['levels'];
$sections=kph_hr_access::sections();
$form_fields=static function($operation) use($state) {
    wp_nonce_field('kph_hr_levels');
    ?><input type="hidden" name="action" value="kph_hr_access"><input type="hidden" name="operation" value="<?php echo esc_attr($operation); ?>"><input type="hidden" name="revision" value="<?php echo (int)$state['revision']; ?>"><?php
};
?>
<div class="modal fade" id="kphHrAccess" tabindex="-1" aria-labelledby="kphHrAccessTitle" aria-hidden="true">
<div class="modal-dialog modal-lg"><div class="modal-content">
<div class="modal-header"><h5 class="modal-title" id="kphHrAccessTitle">سطوح دسترسی پرسنل</h5><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="بستن"></button></div>
<div class="modal-body">
<ul class="nav nav-tabs"><li class="nav-item"><a class="nav-link active" href="#kphAccessLevels" data-bs-toggle="tab">تعریف سطح</a></li><li class="nav-item"><a class="nav-link" href="#kphAccessMembers" data-bs-toggle="tab">اختصاص به پرسنل</a></li></ul>
<div class="tab-content"><div class="tab-pane active" id="kphAccessLevels">
<form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="kph-access-level-form">
<?php $form_fields('save'); ?>
<div class="row g-3"><div class="col-sm-6 form-group"><label class="form-label" for="kphLevel">سطح دسترسی</label><div class="form-control-wrap">
<select name="level" id="kphLevel" class="form-select"><option value="">ساخت سطح جدید</option>
<?php foreach ($levels as $id=>$level) { ?><option value="<?php echo esc_attr($id); ?>" data-sections="<?php echo esc_attr(wp_json_encode($level['sections'])); ?>"><?php echo esc_html($level['name']); ?></option><?php } ?>
</select></div></div>
<div class="col-sm-6 form-group"><label class="form-label" for="kphLevelName">نام سطح</label><div class="form-control-wrap"><input class="form-control" name="name" id="kphLevelName" maxlength="80" required></div></div></div>
<fieldset class="form-group"><legend class="form-label">بخش‌های مجاز CRM</legend><div class="row g-2">
<?php foreach ($sections as $slug=>$title) { ?><div class="col-sm-6"><label><input name="sections[]" type="checkbox" value="<?php echo esc_attr($slug); ?>"> <?php echo esc_html($title); ?></label></div><?php } ?>
</div></fieldset>
<button class="btn btn-primary" type="submit">ذخیره سطح</button>
<button class="btn btn-outline-danger" type="submit" name="delete_level" value="1" formnovalidate hidden>حذف سطح بدون کاربر</button>
</form></div>
<div class="tab-pane" id="kphAccessMembers">
<form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
<?php $form_fields('assign'); ?>
<div class="form-group"><label for="kphAccessPerson" class="form-label">پرسنل</label><div class="form-control-wrap"><select name="employee" id="kphAccessPerson" class="form-select" required><option value="">انتخاب کارمند</option>
<?php
$people=get_users(['role__in'=>kph_hr::roles(),'orderby'=>'display_name']);
$listed=[];
foreach ($people as $person) {
    if (!kph_hr_access::eligible($person)) continue;
    $listed[$person->ID]=true;
    $assigned=$state['members'][$person->ID]??'';
    ?><option value="<?php echo (int)$person->ID; ?>" data-level="<?php echo esc_attr($assigned); ?>"><?php echo esc_html($person->display_name.' (#'.$person->ID.')'.($assigned?' — '.($levels[$assigned]['name']??''):'')); ?></option><?php
}
foreach (array_diff_key($state['members'],$listed) as $id=>$assigned) {
    $person=get_userdata($id);
    if (!$person) continue;
    ?><option value="<?php echo (int)$id; ?>" data-level="<?php echo esc_attr($assigned); ?>"><?php echo esc_html($person->display_name.' (#'.$id.') — فقط لغو تخصیص'); ?></option><?php
} ?></select></div></div>
<div class="form-group"><label for="kphAccessAssigned" class="form-label">سطح کارمند</label><div class="form-control-wrap"><select name="level" id="kphAccessAssigned" class="form-select"><option value="">دسترسی پیش‌فرض نقش</option>
<?php foreach ($levels as $id=>$level) { ?><option value="<?php echo esc_attr($id); ?>"><?php echo esc_html($level['name']); ?></option><?php } ?>
</select></div><small class="form-text">با انتخاب سطح سفارشی، فقط بخش‌های انتخاب‌شده در پنل در دسترس خواهند بود. محدودیت‌های مالی پشتیبان و محدوده سفارش‌های ویزیتور همچنان اعمال می‌شوند.</small></div>
<button class="btn btn-primary" type="submit">ذخیره دسترسی کارمند</button>
</form></div></div></div></div></div></div>
