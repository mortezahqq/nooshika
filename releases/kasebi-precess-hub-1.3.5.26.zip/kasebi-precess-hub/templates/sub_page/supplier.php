<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if ( isset( $_REQUEST['id'] ) ) {
	$user_id = $_REQUEST['id'];
} else {
	global $wp;
	$path    = explode( '/', $wp->request );
	$user_id = $path[2];
}

$requested_tab = $_REQUEST['tab'] ?? 'profile';
$tab = is_string($requested_tab) && in_array($requested_tab, ['profile','actions','invoice','financial','transfers','cheque','payments'], TRUE) ? $requested_tab : 'profile';
$tabs_list = [
	'profile'   => [
		'label' => 'اطلاعات شخصی',
		'icon'  => 'user-circle',
	],
	'actions'   => [
		'label' => 'ارتباطات',
		'icon'  => 'chat-circle',
	],
	'invoice'   => [
		'label' => 'فاکتورها',
		'icon'  => 'file-text',
	],
	'financial' => [
		'label' => 'حسابداری',
		'icon'  => 'coin-alt',
	],
	'transfers' => [
		'label' => 'حواله‌ها',
		'icon'  => 'tranx',
	],
	'cheque'    => [
		'label' => 'چک‌ها',
		'icon'  => 'activity-round',
	],
	'payments'  => [
		'label' => 'پرداخت‌ها',
		'icon'  => 'cc-alt2',
	],
] ;
if (kph_support_accounting_restricted()) {
    foreach(kph_support_financial_tabs() as $financial_tab) unset($tabs_list[$financial_tab]);
}
if (kph_hr_access::grants() !== null) {
    $tabs_list = array_filter($tabs_list, static fn($key)=>kph_hr_access::tab_allowed('supplier',$key,(int)$user_id), ARRAY_FILTER_USE_KEY);
}
?>
<input type="hidden" id="current_user_id" value="<?php echo $user_id; ?>">
<div class="nk-block nk-block-lg">
    <div class="card">
        <div class="card-aside-wrap">
            <div class="card-content">
                <ul class="nav nav-tabs nav-tabs-mb-icon nav-tabs-card">
					<?php
					foreach ( $tabs_list as $tab_key => $tab_data ) {
						$active = $tab == $tab_key ? ' active' : '';
						?>
                        <li class="nav-item pe-4">
                            <a class="page_activator nav-link<?php echo $active; ?>"
                               href="<?php echo '/crm/supplier/' . $user_id . '?tab=' . $tab_key; ?>"
                               data-url="<?php echo '/crm/supplier/' . $user_id . '?tab=' . $tab_key; ?>">
                                <em class="icon ni ni-<?php echo $tab_data['icon']; ?>"></em>
                                <span><?php echo $tab_data['label']; ?></span>
                            </a>
                        </li>
						<?php
					}
					?>
                    <li class="nav-item nav-item-trigger d-xxl-none">
                        <a href="#" class="toggle btn btn-icon btn-trigger" data-target="userAside">
                            <em class="icon ni ni-user-list-fill"></em></a>
                    </li>
                </ul>
                <div class="card-inner">
                    <div class="tab-content">
                        <div class="tab-pane active">
							<?php echo kph_get_template( "tab/supplier/$tab.php", [ 'user_id' => $user_id ] ); ?>
                        </div>
                    </div>
                </div>
            </div>
            <div
                class="card-aside card-aside-right user-aside toggle-slide toggle-slide-right toggle-break-xxl toggle-screen-xxl"
                data-content="userAside" data-toggle-screen="xxl" data-toggle-overlay="true" data-toggle-body="true">
                <div class="card-inner-group" data-simplebar>
					<?php echo kph_get_template( "tab/supplier/info.php", [ 'user_id' => $user_id ] ); ?>
                </div>
            </div>
        </div>
    </div>
</div>
