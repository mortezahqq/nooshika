<?php
if(!defined('ABSPATH'))exit;

trait kph_finance_integrity {
    public static function finance_balance_allowed(): bool {
        return get_current_user_id() && kph_crm_section('finance', (current_user_can('manage_options')||in_array(nooshika_get_user_role(get_current_user_id()),['administrator','accountant'],true)));
    }
    private function finance_tables_ready(array $tables): void {
        foreach(array_unique($tables) as $table){
            $row=$this->db->get_row($this->db->prepare('SHOW TABLE STATUS LIKE %s',$this->db->esc_like($table)),ARRAY_A);
            if(!$row||strcasecmp((string)$row['Engine'],'InnoDB'))throw new RuntimeException('برای ثبت یکپارچه، جدول‌های مالی باید InnoDB باشند.');
        }
    }
    /** Reserve a manual submission and post its journal row in the same database transaction. */
    public function submit_manual_transaction(array $args, $request_key, string $entered_time): array {
        if (!self::finance_balance_allowed()) return $this->fail('اجازه ثبت تراکنش را ندارید.');
        if (!is_string($request_key) || !preg_match('/^[a-f0-9-]{32,36}$/iD', $request_key)) {
            return $this->fail('اعتبار فرم تراکنش تمام شده است. صفحه را تازه کنید.');
        }
        $requests = $this->db_prefix . 'manual_transaction_requests';
        $key = hash('sha256', get_current_user_id() . ':' . $request_key);
        $args['action'] = 'manual_transaction';
        $args['created_by'] = get_current_user_id();
        ksort($args['meta']);
        $intent = $args;
        // When the optional time is blank, two HTTP attempts may generate different posting seconds.
        $intent['created_at'] = substr($args['created_at'], 0, 10) . ' ' . $entered_time;
        $fingerprint = hash('sha256', serialize($intent));
        try {
            $this->finance_tables_ready([$requests, $this->accounts, $this->account_transactions, $this->db_prefix . 'account_transaction_meta']);
            if (false === $this->db->query('START TRANSACTION')) throw new RuntimeException('شروع ثبت تراکنش انجام نشد.');
            $reserved = $this->db->query($this->db->prepare(
                "INSERT INTO {$requests} (request_key,fingerprint) VALUES (%s,%s)
                 ON DUPLICATE KEY UPDATE request_key=VALUES(request_key)", $key, $fingerprint
            ));
            if ($reserved === false) throw new RuntimeException('ثبت شناسه درخواست انجام نشد.');
            $row = $this->db->get_row($this->db->prepare(
                "SELECT fingerprint,transaction_id FROM {$requests} WHERE request_key=%s FOR UPDATE", $key
            ), ARRAY_A);
            if (!$row || !hash_equals($row['fingerprint'], $fingerprint)) {
                throw new RuntimeException('این فرم قبلاً با اطلاعات دیگری ثبت شده است. گردش حساب را بررسی و برای تراکنش جدید صفحه را تازه کنید.');
            }
            if ($row['transaction_id']) {
                $this->db->query('ROLLBACK');
                return $this->ok('این تراکنش قبلاً ثبت شده است.', ['transaction_id' => (int)$row['transaction_id'], 'account_id' => (int)$args['account_id']]);
            }
            $result = $this->add_account_transaction($args, true);
            if ($result['status'] !== 'success') throw new RuntimeException($result['message']);
            $saved = $this->db->update($requests, ['transaction_id' => $result['data']['transaction_id']], ['request_key' => $key]);
            if ($saved !== 1 || false === $this->db->query('COMMIT')) throw new RuntimeException('ثبت نهایی تراکنش انجام نشد.');
            return $result;
        } catch (Throwable $e) {
            $this->db->query('ROLLBACK');
            return $this->fail($e->getMessage());
        }
    }

    /** A transfer deposited to an account, including its party ledger, is one operation. */
    public function add_transfer_to_account(array $transfer,int $account_id,array $meta=[]): array {
        unset($meta['cost_type']); // Funding an account is not an expense.
        if($account_id<=0)return $this->fail('حساب مقصد را انتخاب کنید.');
        if(!is_numeric($transfer['amount']??null)||!is_finite((float)$transfer['amount'])||(float)$transfer['amount']>=0)return $this->fail('واریز به حساب فقط برای حواله دریافتی مجاز است.');
        try{
            $this->finance_tables_ready([$this->transfers,$this->db_prefix.'transfer_meta',$this->ledger_entries,$this->db_prefix.'ledger_entry_meta',$this->accounts,$this->account_transactions,$this->db_prefix.'account_transaction_meta']);
            if(false===$this->db->query('START TRANSACTION'))throw new RuntimeException('شروع ثبت یکپارچه حواله ناموفق بود.');
            $result=$this->add_transfer($transfer,true);
            if(($result['status']??'')!=='success'){$this->db->query('ROLLBACK');return $result;}
            $id=(int)$result['data']['id'];
            $account=$this->db->get_row($this->db->prepare("SELECT id,type,status FROM {$this->accounts} WHERE id=%d FOR UPDATE",$account_id),ARRAY_A);
            if(!$account||$this->db->last_error||$account['status']!=='active')throw new RuntimeException('حساب مقصد فعال پیدا نشد.');
            $journal=$this->add_account_transaction(['account_id'=>$account_id,'amount'=>abs((float)$transfer['amount']),
                'type'=>'credit','action'=>'transfer_deposit','description'=>'واریز حواله #'.$id,
                'created_by'=>get_current_user_id(),'created_at'=>current_time('mysql'),'meta'=>array_merge($meta,['transfer_id'=>$id])],true);
            if(($journal['status']??'')!=='success'){$this->db->query('ROLLBACK');return $journal;}
            if(false===$this->db->query('COMMIT'))throw new RuntimeException('ثبت نهایی حواله و حساب انجام نشد.');
            $hook=$result['data']['_hook_data']??$transfer;unset($result['data']['_hook_data']);
            // The committed financial result must not become a failure if a notification hook fails.
            try{do_action('kph_transfer_added',$id,$hook,['status'=>'success','data'=>['id'=>$result['data']['ledger_id']??0]]);}catch(Throwable $notification_error){}
            return $result;
        }catch(Throwable $e){$this->db->query('ROLLBACK');return $this->fail($e->getMessage());}
    }
    private function account_balance_review_rows(array $account,array $rows): array {
        $balance='0';$valid=true;$initial=null;$risk=0;
        foreach($rows as $index=>$row){
            if(!in_array($row['type'],['credit','debit'],true)||!preg_match('/^[0-9]+$/D',(string)$row['amount'])||bccomp((string)$row['amount'],'0',0)<=0){$valid=false;continue;}
            $delta=($row['type']==='credit'?'':'-').$row['amount'];
            if($index===0)$initial=bcsub((string)$row['balance_after'],$delta,0);
            $balance=bcadd($balance,$delta,0);
            if($account['type']==='expense'&&$row['action']==='transfer_deposit'&&$row['type']==='debit')$risk++;
        }
        $different=bccomp((string)$account['balance'],$balance,0)!==0;
        // Establish the journal opening before aligning the current balance. Legacy document warnings are a separate review concern.
        $eligible=$valid && count($rows)>0 && $initial==='0'
            && bccomp($balance,(string)PHP_INT_MAX,0)<=0 && bccomp($balance,(string)PHP_INT_MIN,0)>=0
            && ($account['type']==='expense'||bccomp($balance,'0',0)>=0);
        $reason='';
        if(!$valid)$reason='گردش نامعتبر نیاز به بررسی دارد.';
        elseif(!$rows && (string)$account['balance']!=='0')$reason='موجودی حساب بدون سابقه گردش ثبت شده است.';
        elseif($initial!==null&&$initial!=='0')$reason='موجودی ابتدای گردش یا تراکنش حذف‌شده نیاز به بررسی دارد.';
        elseif($risk)$reason='واریز حوالهٔ بدهکار در این حساب وجود دارد؛ از «بررسی واریز حواله‌ها» برای بررسی و اصلاح آن استفاده کنید.';
        elseif(!$eligible&&$different)$reason='مانده محاسبه‌شده نیاز به بررسی دارد.';
        return ['account_id'=>(int)$account['id'],'title'=>$account['title'],'account_type'=>$account['type'],'stored'=>(string)$account['balance'],'journal'=>$balance,
            'difference'=>bcsub($balance,(string)$account['balance'],0),'different'=>$different,'eligible'=>$eligible,'reason'=>$reason,
            'opening'=>$initial,'count'=>count($rows),'legacy_direction_risk'=>$risk,
            'reconciliation_scope'=>'recorded_journal_only','requires_document_review'=>$risk>0,
            'token'=>hash('sha256',wp_json_encode([$account['id'],(string)$account['balance'],$rows]))];
    }
    private function read_account_balance_review(int $id,bool $lock=false): array {
        $suffix=$lock?' FOR UPDATE':'';
        $account=$this->db->get_row($this->db->prepare("SELECT id,title,type,status,balance FROM {$this->accounts} WHERE id=%d$suffix",$id),ARRAY_A);
        if(!$account||$this->db->last_error)throw new RuntimeException('حساب یافت نشد.');
        $rows=$this->db->get_results($this->db->prepare("SELECT id,amount,type,action,balance_after FROM {$this->account_transactions} WHERE account_id=%d ORDER BY id$suffix",$id),ARRAY_A);
        if($this->db->last_error)throw new RuntimeException('خواندن گردش حساب انجام نشد.');
        return $this->account_balance_review_rows($account,$rows?:[]);
    }
    public function get_account_balance_review(int $id): array {
        if(!self::finance_balance_allowed())return $this->fail('اجازه بررسی مانده حساب را ندارید.');
        try{return $this->ok('',$this->read_account_balance_review($id));}catch(Throwable $e){return $this->fail($e->getMessage());}
    }
    /** Rebuild only an evidenced stale cache; preserve the actual journal and its old snapshots. */
    public function reconcile_account_balance(int $id,string $expected): array {
        if(!self::finance_balance_allowed())return $this->fail('اجازه تطبیق حساب را ندارید.');
        try{
            $this->finance_tables_ready([$this->accounts,$this->account_transactions,$this->actions_table,$this->db_prefix.'action_meta']);
            if(false===$this->db->query('START TRANSACTION'))throw new RuntimeException('شروع تطبیق حساب انجام نشد.');
            $review=$this->read_account_balance_review($id,true);
            if(!hash_equals($review['token'],$expected))throw new RuntimeException('گردش این حساب تغییر کرده؛ دوباره بررسی کنید.');
            if(!$review['eligible'])throw new RuntimeException($review['reason']?:'این حساب به بررسی سوابق نیاز دارد.');
            if($review['different']){
                if(false===$this->db->update($this->accounts,['balance'=>(int)$review['journal'],'updated_at'=>current_time('mysql')],['id'=>$id]))throw new RuntimeException('ثبت مانده حساب ناموفق بود.');
                if(!$this->db->insert($this->actions_table,['user_id'=>get_current_user_id(),'title'=>sanitize_text_field('تطبیق مانده حساب '.$review['title']),'content'=>$review['stored'].' ← '.$review['journal'],'date'=>current_time('mysql'),'creator'=>get_current_user_id()]))throw new RuntimeException('ثبت سابقه تطبیق حساب انجام نشد.');
                $audit=$this->save_meta_batch('action',(int)$this->db->insert_id,['type'=>'account_balance_reconciliation','account_id'=>$id,'previous_balance'=>$review['stored'],'journal_balance'=>$review['journal'],'review_token'=>$review['token'],'reconciliation_scope'=>'recorded_journal_only','legacy_direction_risk'=>$review['legacy_direction_risk']]);
                if(($audit['status']??'')!=='success')throw new RuntimeException('ثبت سابقه تطبیق حساب انجام نشد.');
            }
            if(false===$this->db->query('COMMIT'))throw new RuntimeException('ثبت نهایی تطبیق انجام نشد.');
            return $this->ok('مانده با خالص گردش‌های موجود یکسان شد؛ اسناد حواله تغییر نکردند.',['account_id'=>$id,'balance'=>$review['journal'],'label'=>number_format((int)$review['journal']),'reconciliation_scope'=>'recorded_journal_only','requires_document_review'=>$review['requires_document_review']]);
        }catch(Throwable $e){$this->db->query('ROLLBACK');return $this->fail($e->getMessage());}
    }
    public function validated_finance_attachment($value,$expected_count=null):string {
        if(!is_string($value))throw new RuntimeException('اطلاعات فایل ضمیمه معتبر نیست.');
        $urls=array_values(array_unique(array_filter(array_map('trim',explode(',',$value)))));
        if($expected_count!==null && (!is_scalar($expected_count)||!preg_match('/^\d{1,2}$/D',(string)$expected_count)||(int)$expected_count!==count($urls)))throw new RuntimeException('بارگذاری ضمیمه کامل نشده است؛ فایل را بررسی و دوباره ثبت کنید.');
        if(count($urls)>20)throw new RuntimeException('تعداد فایل‌های ضمیمه بیش از حد مجاز است.');
        foreach($urls as $url){
            if(!filter_var($url,FILTER_VALIDATE_URL)||!in_array(strtolower((string)parse_url($url,PHP_URL_SCHEME)),['http','https'],true)||!$this->get_uploaded_file_data($url))throw new RuntimeException('فایل ضمیمه در سوابق آپلود یافت نشد؛ فایل را دوباره بارگذاری کنید.');
        }
        return implode(',',$urls);
    }
    public function update_finance_attachment(int $id,$value,$expected,$expected_count=null):array {
        if(!self::finance_balance_allowed())return $this->fail('اجازه تغییر ضمیمه تراکنش را ندارید.');
        if($id<=0||!is_string($expected))return $this->fail('شناسه تراکنش یا اطلاعات ضمیمه معتبر نیست.');
        try{
            $new=$this->validated_finance_attachment($value,$expected_count);
            $table=$this->db_prefix.'account_transaction_meta';
            $this->finance_tables_ready([$this->account_transactions,$table,$this->actions_table,$this->db_prefix.'action_meta']);
            if(false===$this->db->query('START TRANSACTION'))throw new RuntimeException('شروع ثبت ضمیمه انجام نشد.');
            $row=$this->db->get_row($this->db->prepare("SELECT id,account_id FROM {$this->account_transactions} WHERE id=%d FOR UPDATE",$id),ARRAY_A);
            if(!$row||$this->db->last_error)throw new RuntimeException('تراکنش یافت نشد.');
            $meta=$this->db->get_results($this->db->prepare("SELECT meta_value FROM $table WHERE transaction_id=%d AND meta_key='attachment' ORDER BY id FOR UPDATE",$id),ARRAY_A);
            if($this->db->last_error||count($meta)>1)throw new RuntimeException('سوابق ضمیمه نیاز به بررسی دارد.');
            $old=(string)($meta[0]['meta_value']??'');
            if($old!==$expected)throw new RuntimeException('ضمیمه این تراکنش تغییر کرده است؛ فهرست را تازه کنید.');
            if($old!==$new){
                $r=$this->save_meta_batch('account_transaction',$id,['attachment'=>$new]);
                if($r['status']!=='success')throw new RuntimeException('ثبت ضمیمه انجام نشد.');
                if(false===$this->db->insert($this->actions_table,['user_id'=>get_current_user_id(),'title'=>'تغییر ضمیمه تراکنش #'.$id,'content'=>'فایل ضمیمه تراکنش به‌روزرسانی شد.','date'=>current_time('mysql'),'creator'=>get_current_user_id()]))throw new RuntimeException('ثبت سابقه تغییر ضمیمه انجام نشد.');
                $audit=$this->save_meta_batch('action',(int)$this->db->insert_id,['type'=>'finance_attachment_updated','transaction_id'=>$id,'account_id'=>$row['account_id'],'previous_attachment'=>$old,'attachment'=>$new]);
                if($audit['status']!=='success')throw new RuntimeException('ثبت سابقه تغییر ضمیمه انجام نشد.');
            }
            if(false===$this->db->query('COMMIT'))throw new RuntimeException('ثبت نهایی ضمیمه انجام نشد.');
            return $this->ok('ضمیمه تراکنش ثبت شد.',['transaction_id'=>$id,'attachment'=>$new]);
        }catch(Throwable $e){$this->db->query('ROLLBACK');return $this->fail($e->getMessage());}
    }

    /** Read-only evidence for the former debit-on-deposit bug; never infer from descriptions. */
    private function transfer_deposit_review(int $account_id,bool $lock=false):array {
        $suffix=$lock?' FOR UPDATE':'';
        $account=$this->db->get_row($this->db->prepare("SELECT * FROM {$this->accounts} WHERE id=%d$suffix",$account_id),ARRAY_A);
        if(!$account||$this->db->last_error)throw new RuntimeException('حساب یافت نشد.');
        $rows=$this->db->get_results($this->db->prepare("SELECT * FROM {$this->account_transactions} WHERE account_id=%d ORDER BY id$suffix",$account_id),ARRAY_A);
        if($this->db->last_error)throw new RuntimeException('خواندن گردش حساب انجام نشد.');
        $meta_table=$this->db_prefix.'account_transaction_meta';
        $journal='0';$fixed_sum='0';$candidates=[];$skipped=[];$evidence=[];$valid=true;$opening='0';
        foreach($rows as $index=>$row){
            if(!in_array($row['type'],['credit','debit'],true)||!preg_match('/^[0-9]{1,18}$/D',(string)$row['amount'])||bccomp((string)$row['amount'],'0',0)<=0){$valid=false;continue;}
            $delta=($row['type']==='credit'?'':'-').$row['amount'];
            if($index===0)$opening=bcsub((string)$row['balance_after'],$delta,0);
            $journal=bcadd($journal,$delta,0);
            if($row['action']!=='transfer_deposit'||$row['type']!=='debit')continue;
            $id=(int)$row['id'];
            $meta=$this->db->get_results($this->db->prepare("SELECT * FROM $meta_table WHERE transaction_id=%d ORDER BY id$suffix",$id),ARRAY_A);
            if($this->db->last_error)throw new RuntimeException('خواندن ارتباط حواله انجام نشد.');
            $values=[];foreach($meta as $m)$values[$m['meta_key']][]=$m['meta_value'];
            $transfer_ids=$values['transfer_id']??[];
            $reason='';$transfer=null;$party=[];$references=[];
            if(count($transfer_ids)!==1||!preg_match('/^[1-9][0-9]*$/D',(string)$transfer_ids[0]))$reason='ارتباط یکتای حواله یافت نشد.';
            if(!$reason){
                $transfer_id=(int)$transfer_ids[0];
                $transfer=$this->db->get_row($this->db->prepare("SELECT * FROM {$this->transfers} WHERE id=%d$suffix",$transfer_id),ARRAY_A);
                if($this->db->last_error)throw new RuntimeException('خواندن حواله انجام نشد.');
                $party=$this->db->get_results($this->db->prepare("SELECT * FROM {$this->ledger_entries} WHERE ref_type='transfer' AND ref_id=%d ORDER BY id$suffix",$transfer_id),ARRAY_A);
                if($this->db->last_error)throw new RuntimeException('خواندن سند حساب مشتری انجام نشد.');
                $references=$this->db->get_results($this->db->prepare("SELECT t.id FROM {$this->account_transactions} t WHERE EXISTS (SELECT 1 FROM $meta_table m WHERE m.transaction_id=t.id AND m.meta_key='transfer_id' AND m.meta_value=%s) ORDER BY t.id$suffix",(string)$transfer_id),ARRAY_A);
                if($this->db->last_error)throw new RuntimeException('خواندن ارتباط‌های حساب انجام نشد.');
                if(!$transfer||!preg_match('/^-[0-9]+(?:\.[0-9]{1,2})?$/D',(string)$transfer['amount'])||bccomp((string)$transfer['amount'],'-'.$row['amount'],2)!==0)$reason='مبلغ یا جهت حواله با واریز مطابقت ندارد.';
                elseif(count($references)!==1||(int)$references[0]['id']!==$id)$reason='این حواله به بیش از یک تراکنش حساب متصل است.';
                elseif(count($party)!==1||$party[0]['entry_type']!=='submit_transfer'||$party[0]['type']!=='credit'||(int)$party[0]['user_id']!==(int)$transfer['user_id']||bccomp((string)$party[0]['amount'],(string)$row['amount'],2)!==0)$reason='سند حساب مشتری با واریز مطابقت ندارد.';
                elseif(isset($values['user_id'])&&(count($values['user_id'])!==1||(int)$values['user_id'][0] !== (int)$transfer['user_id']))$reason='شخص مرتبط با تراکنش و حواله متفاوت است.';
            }
            $evidence[]=[$id,$meta,$transfer,$party,$references];
            if($reason){$skipped[]=['transaction_id'=>$id,'reason'=>$reason];continue;}
            $candidates[]=['transaction_id'=>$id,'transfer_id'=>(int)$transfer['id'],'user_id'=>(int)$transfer['user_id'],'amount'=>(string)$row['amount'],'created_at'=>$row['created_at'],'previous_cost_type'=>$values['cost_type']??[]];
            $fixed_sum=bcadd($fixed_sum,(string)$row['amount'],0);
        }
        $new_balance=bcadd($journal,bcmul($fixed_sum,'2',0),0);
        $reason='';
        if(!$valid)$reason='یک گردش حساب مبلغ یا جهت نامعتبر دارد؛ اصلاح خودکار انجام نمی‌شود.';
        elseif($opening!=='0')$reason='موجودی ابتدای گردش نامشخص است؛ اصلاح خودکار انجام نمی‌شود.';
        elseif(bccomp($new_balance,(string)PHP_INT_MAX,0)>0||bccomp($new_balance,(string)PHP_INT_MIN,0)<0||($account['type']!=='expense'&&bccomp($new_balance,'0',0)<0))$reason='مانده پس از اصلاح نیاز به بررسی دارد.';
        $token=hash('sha256',wp_json_encode([$account,$rows,$evidence]));
        return ['account_id'=>$account_id,'title'=>$account['title'],'stored'=>(string)$account['balance'],'journal'=>$journal,'new_balance'=>$new_balance,'deposit_total'=>$fixed_sum,'count'=>count($candidates),'items'=>$candidates,'skipped'=>$skipped,'eligible'=>$reason===''&&count($candidates)>0,'reason'=>$reason,'token'=>$token,'_rows'=>$rows];
    }
    public function review_transfer_deposits(int $account_id):array {
        if(!self::finance_balance_allowed())return $this->fail('اجازه بررسی حواله‌ها را ندارید.');
        try{$r=$this->transfer_deposit_review($account_id);unset($r['_rows']);return $this->ok('',$r);}catch(Throwable $e){return $this->fail($e->getMessage());}
    }
    /** Correct the evidenced existing rows, not a second transfer or customer payment. */
    public function repair_transfer_deposits(int $account_id,string $expected):array {
        if(!self::finance_balance_allowed())return $this->fail('اجازه اصلاح حواله‌ها را ندارید.');
        try{
            $this->finance_tables_ready([$this->accounts,$this->account_transactions,$this->db_prefix.'account_transaction_meta',$this->transfers,$this->ledger_entries,$this->actions_table,$this->db_prefix.'action_meta']);
            if(false===$this->db->query('START TRANSACTION'))throw new RuntimeException('شروع اصلاح حواله انجام نشد.');
            $r=$this->transfer_deposit_review($account_id,true);
            if(!hash_equals($r['token'],$expected))throw new RuntimeException('سوابق حساب یا حواله تغییر کرده است؛ دوباره بررسی کنید.');
            if(!$r['eligible'])throw new RuntimeException($r['reason']?:'واریز قابل اصلاحی یافت نشد.');
            $ids=array_column($r['items'],'transaction_id');$balance='0';$snapshots=[];
            foreach($r['_rows'] as $row){
                $changes=[];
                if(in_array((int)$row['id'],$ids,true)){
                    $changes['type']='credit';
                    if(false===$this->db->delete($this->db_prefix.'account_transaction_meta',['transaction_id'=>(int)$row['id'],'meta_key'=>'cost_type']))throw new RuntimeException('اصلاح دسته‌بندی واریز انجام نشد.');
                }
                $side=$changes['type']??$row['type'];$balance=bcadd($balance,($side==='credit'?'':'-').$row['amount'],0);
                if(bccomp($balance,(string)PHP_INT_MAX,0)>0||bccomp($balance,(string)PHP_INT_MIN,0)<0)throw new RuntimeException('مانده میانی از محدوده مجاز خارج است.');
                if((string)$row['balance_after']!==$balance)$changes['balance_after']=$balance;
                if($changes){
                    $snapshots[]=['transaction_id'=>(int)$row['id'],'type'=>$row['type'],'balance_after'=>(string)$row['balance_after']];
                    if(false===$this->db->update($this->account_transactions,$changes,['id'=>(int)$row['id']]))throw new RuntimeException('اصلاح گردش حساب انجام نشد.');
                }
            }
            if($balance!==$r['new_balance'])throw new RuntimeException('مانده محاسبه‌شده مطابقت ندارد.');
            if(false===$this->db->update($this->accounts,['balance'=>$balance,'updated_at'=>current_time('mysql')],['id'=>$account_id]))throw new RuntimeException('اصلاح مانده حساب انجام نشد.');
            if(!$this->db->insert($this->actions_table,['user_id'=>get_current_user_id(),'title'=>'اصلاح جهت واریز حواله‌های حساب #'.$account_id,'content'=>'واریزهای اشتباهاً بدهکار، بستانکار شدند؛ حواله و حساب مشتری تغییر نکرد.','date'=>current_time('mysql'),'creator'=>get_current_user_id()]))throw new RuntimeException('ثبت سابقه اصلاح انجام نشد.');
            $audit=$this->save_meta_batch('action',(int)$this->db->insert_id,['type'=>'transfer_deposit_direction_repair','account_id'=>$account_id,'previous_balance'=>$r['stored'],'new_balance'=>$balance,'deposits'=>$r['items'],'previous_snapshots'=>$snapshots]);
            if($audit['status']!=='success')throw new RuntimeException('ثبت جزئیات اصلاح انجام نشد.');
            if(false===$this->db->query('COMMIT'))throw new RuntimeException('ثبت نهایی اصلاح حواله انجام نشد.');
            return $this->ok('واریز حواله‌ها اصلاح شد؛ حساب مشتری و برداشت‌های واقعی تغییر نکرد.',['account_id'=>$account_id,'count'=>$r['count'],'balance'=>$balance,'label'=>number_format((int)$balance)]);
        }catch(Throwable $e){$this->db->query('ROLLBACK');return $this->fail($e->getMessage());}
    }

}
