<?php
if (!defined('ABSPATH')) { exit; }

trait kph_supplier_tools {
    public static function supplier_tools_allowed(): bool {
        if (!get_current_user_id()) { return FALSE; }
        return kph_hr_access::has('purchases') || kph_plugin_management_allowed() || in_array(nooshika_get_user_role(get_current_user_id()), ['administrator','accountant'], TRUE);
    }

    /** Called inside the existing writer transaction, before any financial mutation. */
    private function lock_supplier_invoice_reference(int $user_id, int $invoice_id): array {
        if ($invoice_id <= 0 || nooshika_get_user_role($user_id) !== 'supplier') { return $this->ok(''); }
        $row = $this->db->get_row($this->db->prepare(
            "SELECT id FROM {$this->supplier_invoices} WHERE id=%d AND supplier_user_id=%d AND status<>'canceled' FOR UPDATE", $invoice_id, $user_id
        ), ARRAY_A);
        if (!$row || $this->db->last_error) { return $this->fail('فاکتور تأمین‌کننده موجود نیست یا متعلق به این تأمین‌کننده نیست؛ صفحه را تازه کنید.'); }
        return $this->ok('');
    }

    /** Offset one proven duplicate. Keep both original postings for the supplier's audit trail. */
    public function reconcile_supplier_endorsement(string $sayad): array {
        if (!current_user_can('manage_options')) return $this->fail('فقط مدیر می‌تواند سند اصلاحی ثبت کند.');
        $sayad = trim(nooshika_sanitize_numbers($sayad));
        if (!preg_match('/^[0-9]{16}$/D', $sayad)) return $this->fail('شناسه صیادی ۱۶ رقمی چک را وارد کنید.');
        if (!$this->workflow_storage_ready('endorsement')) return $this->fail('ابتدا آماده‌سازی جدول‌ها را در ابزارهای کاسبی اجرا کنید.');
        if (false === $this->db->query('START TRANSACTION')) return $this->fail('شروع بررسی چک انجام نشد.');
        try {
            $cheques = $this->db->get_results($this->db->prepare(
                "SELECT id, amount, status, current_holder_user_id FROM {$this->cheques} WHERE sayad_id=%s FOR UPDATE", $sayad
            ), ARRAY_A);
            if ($this->db->last_error || count($cheques) !== 1) throw new RuntimeException('یک چک یکتا با این شناسه پیدا نشد.');
            $cheque = $cheques[0];
            $id = (int)$cheque['id'];
            $supplier = (int)$cheque['current_holder_user_id'];
            if ($cheque['status'] !== 'endorsed' || !$supplier || nooshika_get_user_role($supplier) !== 'supplier') {
                throw new RuntimeException('چک باید در وضعیت واگذارشده به تأمین‌کننده باشد.');
            }
            $moves = $this->db->get_results($this->db->prepare(
                "SELECT action, holder_user_id FROM {$this->cheque_moves} WHERE cheque_id=%d ORDER BY id FOR UPDATE", $id
            ), ARRAY_A);
            if ($this->db->last_error) throw new RuntimeException('خواندن گردش چک انجام نشد.');
            $endorsements = 0;
            foreach ($moves as $move) {
                if ($move['action'] === 'receive' && !$endorsements && !$move['holder_user_id']) continue;
                if ($move['action'] !== 'endorse' || (int)$move['holder_user_id'] !== $supplier) {
                    throw new RuntimeException('این چک سابقهٔ دیگری دارد و باید جداگانه بررسی شود.');
                }
                ++$endorsements;
            }
            $entries = $this->db->get_results($this->db->prepare(
                "SELECT id, type, entry_type, user_id, amount FROM {$this->ledger_entries}
                 WHERE ref_type='cheque' AND ref_id=%d ORDER BY id FOR UPDATE", $id
            ), ARRAY_A);
            if ($this->db->last_error) throw new RuntimeException('خواندن اسناد حسابداری چک انجام نشد.');
            $debits = [];
            foreach ($entries as $entry) {
                if ($entry['entry_type'] === 'cheque_receive' && $entry['type'] === 'credit' && (int)$entry['user_id'] !== $supplier) continue;
                if ($entry['entry_type'] !== 'cheque_endorse' || $entry['type'] !== 'debit'
                    || (int)$entry['user_id'] !== $supplier || bccomp($entry['amount'], $cheque['amount'], 2) !== 0) {
                    throw new RuntimeException('این چک سند دیگری یا سابقهٔ اصلاح دارد؛ سوابق آن را بررسی کنید.');
                }
                $debits[] = (int)$entry['id'];
            }
            if (!in_array($endorsements, [1, 2], true) || count($debits) !== 2) {
                throw new RuntimeException('دو سند بدهکار تکراری برای یک واگذاری به این تأمین‌کننده احراز نشد.');
            }
            $result = $this->add_ledger_entry([
                'user_id'=>$supplier, 'entry_type'=>'adjustment', 'type'=>'credit', 'amount'=>$cheque['amount'],
                'ref_type'=>'cheque', 'ref_id'=>$id, 'note'=>'اصلاح کسر تکراری واگذاری چک؛ سند بدهکار شماره '.$debits[1],
                'meta'=>['creator_id'=>get_current_user_id(), 'corrected_entry_id'=>$debits[1], 'original_entry_id'=>$debits[0]],
            ]);
            if ($result['status'] !== 'success' || false === $this->db->query('COMMIT')) throw new RuntimeException('ثبت سند اصلاحی انجام نشد.');
            return $this->ok('سند بستانکار اصلاحی شماره '.$result['data']['id'].' در حساب تأمین‌کننده ثبت شد.');
        } catch (Throwable $e) {
            $this->db->query('ROLLBACK');
            return $this->fail($e->getMessage());
        }
    }

    public function ensure_supplier_lifecycle_schema(): array {
        if (!self::supplier_tools_allowed()) { return $this->fail('دسترسی مجاز نیست.'); }
        $column=$this->db->get_row("SHOW COLUMNS FROM {$this->supplier_invoices} LIKE 'status'",ARRAY_A);
        if (!$column) { return $this->fail('ساختار فاکتورها قابل بررسی نیست.'); }
        if (!str_contains((string)$column['Type'],"'canceled'") && $this->db->query("ALTER TABLE {$this->supplier_invoices} MODIFY status ENUM('proforma','confirmed','settled','canceled') NOT NULL DEFAULT 'proforma'")===FALSE) {
            return $this->fail('افزودن وضعیت ابطال ناموفق بود؛ مدیر ساختار فاکتورها را بررسی کند.');
        }
        return $this->ok('');
    }

    /** Every supplier-invoice cancellation dependency must support transactions. */
    private function supplier_lifecycle_tables(): array {
        return array_values(array_unique(array_merge(
            $this->workflow_tables('supplier'),
            [
                $this->actions_table,
                $this->db_prefix . 'action_meta',
                $this->batches,
                $this->storage_moves,
                $this->processing_pack_inputs,
                $this->ledger_entries,
                $this->db_prefix . 'ledger_entry_meta',
                $this->accounts,
                $this->account_transactions,
                $this->db_prefix . 'account_transaction_meta',
            ]
        )));
    }

    /** Read-only checks, performed before a financial transaction starts. */
    private function supplier_lifecycle_table_issues(): array {
        $issues = [];
        foreach ($this->supplier_lifecycle_tables() as $table) {
            $row = $this->db->get_row(
                $this->db->prepare('SHOW TABLE STATUS LIKE %s', $this->db->esc_like($table)),
                ARRAY_A
            );
            if ($this->db->last_error) {
                $issues[] = ['table' => $table, 'engine' => '', 'kind' => 'read_error'];
            } elseif (!$row || (string)($row['Name'] ?? '') !== $table) {
                $issues[] = ['table' => $table, 'engine' => '', 'kind' => 'missing'];
            } elseif (strcasecmp((string)($row['Engine'] ?? ''), 'InnoDB') !== 0) {
                $issues[] = ['table' => $table, 'engine' => (string)($row['Engine'] ?? ''), 'kind' => 'engine'];
            }
        }
        return $issues;
    }

    /** Show actionable diagnostics only to the administrator. */
    public function supplier_lifecycle_storage_issues(): array {
        return kph_plugin_management_allowed() ? $this->supplier_lifecycle_table_issues() : [];
    }

    /**
     * Explicit administrator maintenance, never called by an invoice cancellation.
     * ALTER TABLE causes implicit commits; do not run it inside the cancellation transaction.
     * The administrator must first back up the database and stop concurrent writes.
     */
    public function prepare_supplier_lifecycle_storage(bool $confirmed = FALSE): array {
        if (!kph_plugin_management_allowed()) { return $this->fail('آماده‌سازی فقط برای مدیر مجاز است.'); }
        if (!$confirmed) { return $this->fail('پیش از آماده‌سازی باید داشتن نسخهٔ پشتیبان و توقف ثبت اطلاعات را تأیید کنید.'); }

        $issues = $this->supplier_lifecycle_table_issues();
        // Preflight all tables; avoid partially converting engines if a table is absent.
        foreach ($issues as $issue) {
            if ($issue['kind'] === 'missing') {
                return $this->fail('جدول ' . $issue['table'] . ' وجود ندارد؛ بازیابی ساختار باید توسط مدیر دیتابیس انجام شود. هیچ تبدیلی انجام نشد.');
            }
            if ($issue['kind'] === 'read_error') {
                return $this->fail('ساختار جدول ' . $issue['table'] . ' قابل بررسی نیست؛ دسترسی دیتابیس را کنترل کنید. هیچ تبدیلی انجام نشد.');
            }
        }
        $converted = 0;
        foreach ($issues as $issue) {
            $table = $issue['table']; // Identifiers only originate from fixed plugin table names.
            if (!preg_match('/^[A-Za-z0-9_]+$/D', $table)) {
                return $this->fail('نام جدول نامعتبر است؛ آماده‌سازی متوقف شد.');
            }
            if ($this->db->query("ALTER TABLE `{$table}` ENGINE=InnoDB") === FALSE) {
                return $this->fail('تبدیل جدول ' . $table . ' ناموفق بود. علت را در گزارش دیتابیس بررسی کنید؛ ' . $converted . ' جدول قبلاً تبدیل شده است.');
            }
            ++$converted;
        }
        $remaining = $this->supplier_lifecycle_table_issues();
        if ($remaining) {
            return $this->fail('آماده‌سازی کامل نشد؛ ساختار جدول ' . $remaining[0]['table'] . ' را دوباره بررسی کنید.');
        }
        return $this->ok('ساختار ابطال تأمین‌کنندگان آماده شد (' . $converted . ' جدول تبدیل شد). اکنون صفحهٔ فاکتورها را تازه کنید.');
    }

    private function supplier_lifecycle_ready(): void {
        $issues = $this->supplier_lifecycle_table_issues();
        if (!$issues) { return; }
        $issue = $issues[0];
        $table = $issue['table'];
        if ($issue['kind'] === 'engine') {
            $detail = 'موتور فعلی: ' . ($issue['engine'] ?: 'نامشخص') . '؛ موتور موردنیاز: InnoDB.';
        } elseif ($issue['kind'] === 'missing') {
            $detail = 'جدول وجود ندارد.';
        } else {
            $detail = 'بررسی جدول در دیتابیس با خطا مواجه شد.';
        }
        throw new RuntimeException(
            'ابطال فاکتور انجام نشد؛ ساختار جدول ' . $table . ' آماده نیست. ' . $detail .
            ' مدیر از «ابزارها ← ابزارهای کاسبی ← آماده‌سازی ابطال تأمین‌کنندگان» اقدام کند.'
        );
    }
    private function supplier_write($result,string $message): void {
        if ($result===FALSE||$this->db->last_error) { throw new RuntimeException($message); }
    }
    private function supplier_meta(int $id,array $pairs,string $context='invoice'): void {
        $result=$this->save_meta_batch($context,$id,$pairs,TRUE);
        if (($result['status']??'')!=='success') { throw new RuntimeException('ثبت سابقهٔ ابطال ناموفق بود.'); }
    }
    private function supplier_locked_invoice(int $id,int $supplier): array {
        $row=$this->db->get_row($this->db->prepare("SELECT * FROM {$this->supplier_invoices} WHERE id=%d FOR UPDATE",$id),ARRAY_A);
        if (!$row||$this->db->last_error||(int)$row['supplier_user_id']!==$supplier) { throw new RuntimeException('فاکتور متعلق به این تأمین‌کننده نیست یا یافت نشد.'); }
        $deleted=$this->get_invoice_meta($id,'supplier_deleted');
        if ($this->db->last_error) { throw new RuntimeException('خواندن وضعیت فاکتور ناموفق بود.'); }
        if ((string)$deleted==='1') { throw new RuntimeException('فاکتور قبلاً از فهرست حذف شده است.'); }
        return $row;
    }
    private function supplier_audit(array $invoice,string $type,string $title,array $snapshot): void {
        $json=wp_json_encode($snapshot,JSON_UNESCAPED_UNICODE);
        if (!is_string($json)) { throw new RuntimeException('ثبت سابقهٔ عملیات ناموفق بود.'); }
        $this->supplier_write($this->db->insert($this->actions_table,['user_id'=>(int)$invoice['supplier_user_id'],'creator'=>get_current_user_id(),'date'=>current_time('mysql'),'title'=>$title,'content'=>$title.' شمارهٔ '.esc_html((string)($invoice['invoice_no']?:$invoice['id'])).' ثبت شد.']),'ثبت فعالیت تأمین‌کننده ناموفق بود.');
        $this->supplier_meta((int)$this->db->insert_id,['type'=>$type,'supplier_invoice_snapshot'=>$json],'action');
    }

    public function cancel_supplier_invoice(int $id,int $supplier): array {
        if (!self::supplier_tools_allowed()) { return $this->fail('دسترسی به ابطال فاکتور مجاز نیست.'); }
        if ($id<=0||$supplier<=0) { return $this->fail('شناسه فاکتور یا تأمین‌کننده معتبر نیست.'); }
        $schema=$this->ensure_supplier_lifecycle_schema();if ($schema['status']!=='success') { return $schema; }
        try {
            $this->supplier_lifecycle_ready();
            $this->supplier_write($this->db->query('START TRANSACTION'),'آغاز ابطال ناموفق بود.');
            $invoice=$this->supplier_locked_invoice($id,$supplier);
            if ($invoice['status']==='canceled') { $this->db->query('ROLLBACK');return $this->ok('این فاکتور قبلاً باطل شده است.',['supplier_id'=>$supplier,'invoice_id'=>$id,'status'=>'canceled']); }
            foreach ([$this->storage_moves,$this->ledger_entries] as $journal) {
                $previous=$this->db->get_var($this->db->prepare("SELECT COUNT(*) FROM {$journal} WHERE ref_type='supplier_invoice_cancel' AND ref_id=%d FOR UPDATE",$id));
                if ($this->db->last_error||$previous===NULL||(int)$previous>0) { throw new RuntimeException('سوابق ابطال این فاکتور نیاز به بررسی مدیر دارد؛ برگشت دوباره ثبت نشد.'); }
            }
            $items=$this->db->get_results($this->db->prepare("SELECT * FROM {$this->supplier_invoice_items} WHERE invoice_id=%d ORDER BY id FOR UPDATE",$id),ARRAY_A);
            $this->supplier_write($items,'خواندن اقلام ناموفق بود.');
            $batches=$this->db->get_results($this->db->prepare("SELECT b.* FROM {$this->batches} b INNER JOIN {$this->supplier_invoice_items} i ON i.id=b.source_id WHERE b.source_type='supplier_invoice_item' AND i.invoice_id=%d ORDER BY b.id FOR UPDATE",$id),ARRAY_A);
            $this->supplier_write($batches,'خواندن موجودی ناموفق بود.');
            $purchases=$this->db->get_results($this->db->prepare("SELECT * FROM {$this->storage_moves} WHERE ref_type='supplier_invoice' AND ref_id=%d ORDER BY id FOR UPDATE",$id),ARRAY_A);
            $this->supplier_write($purchases,'خواندن ورود انبار ناموفق بود.');
            $byBatch=[];foreach ($purchases as $move) {
                if ($move['direction']!=='in'||$move['reason']!=='purchase_in'||(float)$move['qty_weight']<=0) { throw new RuntimeException('سوابق ورود انبار این فاکتور ناسازگار است؛ مدیر باید بررسی کند.'); }
                $byBatch[(int)$move['batch_id']][]=$move;
            }
            if (array_diff(array_keys($byBatch),array_map('intval',array_column($batches,'id')))) { throw new RuntimeException('بچ مربوط به ورود انبار یافت نشد؛ مدیر باید بررسی کند.'); }
            if ($invoice['status']!=='proforma') {
                foreach ($items as $item) {
                    if ((float)$item['qty_weight']>0&&!array_filter($batches,static fn($b)=>(int)$b['source_id']===(int)$item['id'])) { throw new RuntimeException('سابقهٔ انبار یکی از اقلام ناقص است؛ مدیر باید بررسی کند.'); }
                }
            }
            $now=current_time('mysql');$stockReversals=[];
            foreach ($batches as $batch) {
                $batchId=(int)$batch['id'];
                $used=$this->db->get_var($this->db->prepare("SELECT COUNT(*) FROM {$this->processing_pack_inputs} WHERE batch_id=%d FOR UPDATE",$batchId));
                if ($this->db->last_error||$used===NULL) { throw new RuntimeException('بررسی سوابق فرآوری ناموفق بود.'); }
                if ((int)$used>0) { throw new RuntimeException('کالای این فاکتور وارد فرآوری شده است؛ ابتدا باید سوابق مصرف و برگشت آن بررسی شود. فاکتور باطل نشد.'); }
                $moves=$byBatch[$batchId]??[];
                if (!$moves) { throw new RuntimeException('ورود اصلی یکی از بچ‌ها یافت نشد؛ مدیر باید بررسی کند.'); }
                $qty=array_sum(array_column($moves,'qty_weight'));
                $available=$this->db->get_var($this->db->prepare("SELECT COALESCE(SUM(CASE WHEN direction='in' THEN qty_weight ELSE -qty_weight END),0)>=%f FROM {$this->storage_moves} WHERE batch_id=%d FOR UPDATE",$qty,$batchId));
                if ($this->db->last_error||(string)$available!=='1') { throw new RuntimeException('موجودی کالای فاکتور برای ابطال کافی نیست؛ ابتدا مصرف، هدررفت یا خروج آن را بررسی کنید.'); }
                foreach ($moves as $move) {
                    $this->supplier_write($this->db->insert($this->storage_moves,['batch_id'=>$batchId,'direction'=>'out','reason'=>'adjustment','qty_weight'=>$move['qty_weight'],'unit_cost_at_move'=>$move['unit_cost_at_move'],'ref_type'=>'supplier_invoice_cancel','ref_id'=>$id,'note'=>'برگشت ورود بابت ابطال فاکتور تأمین‌کننده #'.$id,'created_at'=>$now]),'ثبت برگشت موجودی ناموفق بود.');
                    $stockReversals[]=(int)$this->db->insert_id;
                }
            }
            $ledger=$this->db->get_results($this->db->prepare("SELECT * FROM {$this->ledger_entries} WHERE ref_type='supplier_invoice' AND ref_id=%d ORDER BY id FOR UPDATE",$id),ARRAY_A);
            $this->supplier_write($ledger,'خواندن سند حسابداری ناموفق بود.');
            if ($invoice['status']!=='proforma'&&(float)$invoice['total_amount']>0&&!$ledger) { throw new RuntimeException('سند حسابداری اصلی فاکتور یافت نشد؛ مدیر باید بررسی کند.'); }
            $ledgerReversals=[];
            foreach ($ledger as $entry) {
                if ((int)$entry['user_id']!==$supplier||!in_array($entry['type'],['credit','debit'],TRUE)||(float)$entry['amount']<=0) { throw new RuntimeException('سند حسابداری فاکتور ناسازگار است؛ مدیر باید بررسی کند.'); }
                $result=$this->add_ledger_entry(['user_id'=>$supplier,'entry_type'=>'supplier_invoice_cancel','type'=>$entry['type']==='credit'?'debit':'credit','amount'=>$entry['amount'],'ref_type'=>'supplier_invoice_cancel','ref_id'=>$id,'posted_at'=>$now,'note'=>'ابطال فاکتور تأمین‌کننده #'.$id,'meta'=>['invoice_id'=>$id,'original_entry_id'=>$entry['id']]]);
                if ($result['status']!=='success') { throw new RuntimeException('برگشت سند حسابداری ناموفق بود.'); }
                $ledgerReversals[]=$result['data']['id'];
            }
            [$tm,$fk]=$this->resolve_meta_table('account_transaction');
            $fees=$this->db->get_results($this->db->prepare("SELECT t.* FROM {$this->account_transactions} t WHERE t.action='supplier_invoice_fee' AND EXISTS(SELECT 1 FROM {$tm} m WHERE m.{$fk}=t.id AND m.meta_key='invoice_id' AND m.meta_value=%s) ORDER BY t.account_id,t.id FOR UPDATE",(string)$id),ARRAY_A);
            $this->supplier_write($fees,'خواندن کارمزد فاکتور ناموفق بود.');$feeReversals=[];
            foreach ($fees as $fee) {
                if ((string)$this->get_account_transaction_meta((int)$fee['id'],'supplier_invoice_voided')==='1'||$this->db->last_error) { throw new RuntimeException('کارمزد این فاکتور سابقهٔ ابطال دارد؛ مدیر باید بررسی کند.'); }
                $account=$this->db->get_row($this->db->prepare("SELECT * FROM {$this->accounts} WHERE id=%d FOR UPDATE",$fee['account_id']),ARRAY_A);
                if (!$account||$this->db->last_error||$account['type']!=='expense'||$fee['type']!=='debit'||(float)$fee['amount']<=0) { throw new RuntimeException('حساب کارمزد نیاز به بررسی مدیر دارد؛ ابطال انجام نشد.'); }
                $balance=(int)$account['balance']+(int)$fee['amount'];
                $this->supplier_write($this->db->insert($this->account_transactions,['account_id'=>$account['id'],'amount'=>$fee['amount'],'type'=>'credit','action'=>'supplier_invoice_fee_cancel','balance_after'=>$balance,'description'=>'برگشت کارمزد بابت ابطال فاکتور #'.$id,'created_by'=>get_current_user_id(),'created_at'=>$now]),'ثبت برگشت کارمزد ناموفق بود.');
                $reversal=(int)$this->db->insert_id;$feeReversals[]=$reversal;
                $this->supplier_meta((int)$fee['id'],['supplier_invoice_voided'=>1,'reversal_transaction_id'=>$reversal],'account_transaction');
                $this->supplier_meta($reversal,['invoice_id'=>$id,'original_transaction_id'=>$fee['id']],'account_transaction');
                $this->supplier_write($this->db->update($this->accounts,['balance'=>$balance,'updated_at'=>$now],['id'=>$account['id']]),'برگشت ماندهٔ هزینه ناموفق بود.');
            }
            $this->supplier_meta($id,['supplier_cancel_complete'=>1,'supplier_canceled_at'=>$now,'supplier_canceled_by'=>get_current_user_id(),'supplier_status_before_cancel'=>$invoice['status']]);
            if ($this->db->update($this->supplier_invoices,['status'=>'canceled','updated_at'=>$now],['id'=>$id])!==1) { throw new RuntimeException('ثبت وضعیت ابطال ناموفق بود.'); }
            $this->supplier_audit($invoice,'supplier_invoice_canceled','ابطال فاکتور تأمین‌کننده',['invoice'=>$invoice,'items'=>$items,'stock_reversals'=>$stockReversals,'ledger_reversals'=>$ledgerReversals,'fee_reversals'=>$feeReversals]);
            $this->supplier_write($this->db->query('COMMIT'),'نهایی‌کردن ابطال ناموفق بود.');
            return $this->ok('فاکتور باطل شد. پرداخت‌های واقعی حفظ شدند؛ اکنون گزینهٔ حذف در دسترس است.',['supplier_id'=>$supplier,'invoice_id'=>$id,'status'=>'canceled']);
        } catch (Throwable $e) { $this->db->query('ROLLBACK');return $this->fail($e->getMessage()); }
    }
    /** Hide canceled invoices; immutable rows keep accounting and stock references intact. */
    public function delete_supplier_invoice(int $id,int $supplier): array {
        if (!self::supplier_tools_allowed()) { return $this->fail('دسترسی به حذف فاکتور مجاز نیست.'); }
        if ($id<=0||$supplier<=0) { return $this->fail('شناسه فاکتور یا تأمین‌کننده معتبر نیست.'); }
        try {
            $this->supplier_lifecycle_ready();$this->supplier_write($this->db->query('START TRANSACTION'),'آغاز حذف ناموفق بود.');
            $invoice=$this->supplier_locked_invoice($id,$supplier);
            if ($invoice['status']!=='canceled'||(string)$this->get_invoice_meta($id,'supplier_cancel_complete')!=='1') { throw new RuntimeException('ابتدا فاکتور را ابطال کنید؛ سپس گزینهٔ حذف فعال می‌شود.'); }
            $this->supplier_meta($id,['supplier_deleted'=>1,'supplier_deleted_at'=>current_time('mysql'),'supplier_deleted_by'=>get_current_user_id()]);
            $this->supplier_audit($invoice,'supplier_invoice_deleted','حذف فاکتور باطل‌شده از فهرست',['invoice'=>$invoice]);
            $this->supplier_write($this->db->query('COMMIT'),'نهایی‌کردن حذف ناموفق بود.');
            return $this->ok('فاکتور باطل‌شده از فهرست حذف شد؛ سوابق حسابداری و انبار حفظ شدند.',['supplier_id'=>$supplier,'invoice_id'=>$id]);
        } catch (Throwable $e) { $this->db->query('ROLLBACK');return $this->fail($e->getMessage()); }
    }

    public function update_invoice_item_rate($item_id,$rate,$month): array {
        $item=$this->db->get_row($this->db->prepare("SELECT invoice_id FROM {$this->supplier_invoice_items} WHERE id=%d",$item_id),ARRAY_A);
        if (!$item) { return $this->fail('قلم فاکتور یافت نشد.'); }
        $this->db->query('START TRANSACTION');
        $invoice=$this->db->get_row($this->db->prepare("SELECT status FROM {$this->supplier_invoices} WHERE id=%d FOR UPDATE",$item['invoice_id']),ARRAY_A);
        if (!$invoice||$this->db->last_error||$invoice['status']==='canceled') { $this->db->query('ROLLBACK');return $this->fail('فاکتور باطل‌شده قابل ویرایش نیست.'); }
        $result=$this->update_invoice_item_rate_locked($item_id,$rate,$month);
        if ($result['status']!=='success') { $this->db->query('ROLLBACK');return $result; }
        if ($this->db->query('COMMIT')===FALSE) { $this->db->query('ROLLBACK');return $this->fail('ثبت تغییر کارمزد ناموفق بود.'); }
        return $result;
    }

    public function submit_storage_move(array $data,bool $inside_transaction=FALSE): array {
        if (!$inside_transaction) { $this->db->query('START TRANSACTION'); }
        $batch=(int)($data['batch_id']??0);
        $row=$this->db->get_row($this->db->prepare("SELECT * FROM {$this->batches} WHERE id=%d FOR UPDATE",$batch),ARRAY_A);$error='';
        if (!$row||$this->db->last_error) { $error='بچ موردنظر یافت نشد.'; }
        elseif ($row['source_type']==='supplier_invoice_item') {
            $status=$this->db->get_var($this->db->prepare("SELECT s.status FROM {$this->supplier_invoices} s INNER JOIN {$this->supplier_invoice_items} i ON i.invoice_id=s.id WHERE i.id=%d",$row['source_id']));
            if($this->db->last_error){$error='ارتباط این بچ با فاکتور قابل بررسی نیست.';}
            elseif ($status==='canceled') { $error='فاکتور این موجودی باطل شده است؛ صفحه را تازه کنید.'; }
        }
        if (!$error&&($data['direction']??'')==='out') {
            $enough=$this->db->get_var($this->db->prepare("SELECT COALESCE(SUM(CASE WHEN direction='in' THEN qty_weight ELSE -qty_weight END),0)>=%f FROM {$this->storage_moves} WHERE batch_id=%d FOR UPDATE",(float)nooshika_sanitize_numbers((string)($data['qty_weight']??0)),$batch));
            if ($this->db->last_error||(string)$enough!=='1') { $error='موجودی بچ برای این خروج کافی نیست.'; }
        }
        if ($error) { if (!$inside_transaction) { $this->db->query('ROLLBACK'); }return $this->fail($error); }
        $previous_qty = (float) $this->db->get_var($this->db->prepare(
            "SELECT COALESCE(SUM(CASE WHEN direction='in' THEN qty_weight WHEN direction='out' THEN -qty_weight ELSE 0 END),0) FROM {$this->storage_moves} WHERE batch_id=%d",
            $batch
        ));
        $result=$this->submit_storage_move_locked($data);
        if ( ($result['status'] ?? '') === 'success' ) {
            $qty = (float) nooshika_sanitize_numbers((string)($data['qty_weight']??0));
            $delta = ($data['direction'] ?? '') === 'in' ? $qty : -$qty;
            if ( ! $this->apply_warehouse_batch_delta( $batch, $previous_qty, $delta ) ) {
                $result = $this->fail('تخصیص موجودی محموله بین انبارها نامعتبر است؛ عملیات ذخیره‌سازی متوقف شد.');
            }
        }
        if (!$inside_transaction) { if($this->db->query($result['status']==='success'?'COMMIT':'ROLLBACK')===FALSE){$this->db->query('ROLLBACK');return $this->fail('ثبت نهایی حرکت انبار ناموفق بود.');} }
        return $result;
    }
}
