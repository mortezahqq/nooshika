<?php
if(!defined('ABSPATH'))exit;

trait kph_customer_proformas {
    public static function customer_proforma_staff_allowed():bool {
        return get_current_user_id()>0 && (kph_hr_access::has('orders') || current_user_can('manage_options') || in_array(nooshika_get_user_role(get_current_user_id()),['administrator','accountant','supp','visitor'],true));
    }
    /** Inspect the tables that the current operation will write. */
    private function unprepared_workflow_tables(array $tables): array {
        $placeholders = implode(', ', array_fill(0, count($tables), '%s'));
        $rows = $this->db->get_results($this->db->prepare("SHOW TABLE STATUS WHERE Name IN ($placeholders)", $tables), ARRAY_A);
        if ($this->db->last_error) throw new RuntimeException('خواندن مشخصات جدول‌های سفارش انجام نشد. مدیر دسترسی پایگاه داده را بررسی کند.');
        $engines = array_column($rows, 'Engine', 'Name');
        $pending = [];
        foreach ($tables as $table) {
            if (empty($engines[$table])) throw new RuntimeException('جدول موردنیاز سفارش پیدا نشد یا موتور آن مشخص نیست: '.$table);
            if (strcasecmp($engines[$table], 'InnoDB') !== 0) $pending[] = $table;
        }
        return $pending;
    }

    private function delete_customer_proforma_record(int $id, bool $prepare_storage):array {
        if(!self::customer_proforma_staff_allowed())return $this->fail('اجازه حذف پیش‌فاکتور را ندارید.');
        if($id<=0)return $this->fail('شناسه پیش‌فاکتور معتبر نیست.');
        $in_transaction = false;
        try{
            $pending = $this->unprepared_workflow_tables($this->workflow_tables('proforma'));
            if ($pending) {
                $draft = $this->db->get_row($this->db->prepare("SELECT status, created_by FROM {$this->orders} WHERE id=%d", $id), ARRAY_A);
                if ($this->db->last_error || !$draft || $draft['status'] !== 'proforma') return $this->fail('پیش‌فاکتور تأییدنشده پیدا نشد. فهرست را تازه کنید.');
                $visitor = $this->visitor_order_scope_id();
                if ($visitor && (int)$draft['created_by'] !== $visitor) return $this->fail('فقط پیش‌فاکتور ثبت‌شده توسط خودتان را می‌توانید حذف کنید.');
                if (!current_user_can('manage_options')) return $this->fail('مدیر وردپرس باید یک‌بار جدول‌های پیش‌فاکتور را از گزینهٔ حذف یا ابزارهای کاسبی آماده کند.');
                if (!$prepare_storage) {
                    return $this->fail('جدول‌های زیر برای حذف پیش‌فاکتور نیاز به تبدیل به InnoDB دارند: '.implode('، ', $pending), [
                        'prepare_nonce' => wp_create_nonce('kph_prepare_delete_'.$id),
                    ]);
                }
                // ALTER TABLE commits implicitly. Finish and verify all preparation before starting deletion.
                foreach ($pending as $table) {
                    if (false === $this->db->query("ALTER TABLE `{$table}` ENGINE=InnoDB")) {
                        return $this->fail('تبدیل جدول '.$table.' به InnoDB انجام نشد. مدیر هاست مجوز ALTER و وضعیت این جدول را بررسی کند.');
                    }
                }
                $unconverted = $this->unprepared_workflow_tables($this->workflow_tables('proforma'));
                if ($unconverted) return $this->fail('موتور جدول‌های زیر هنوز InnoDB نیست: '.implode('، ', $unconverted));
            }
            if(false===$this->db->query('START TRANSACTION'))throw new RuntimeException('شروع حذف پیش‌فاکتور انجام نشد.');
            $in_transaction = true;
            $order=$this->db->get_row($this->db->prepare("SELECT * FROM {$this->orders} WHERE id=%d FOR UPDATE",$id),ARRAY_A);
            if(!$order||$this->db->last_error)throw new RuntimeException('پیش‌فاکتور یافت نشد یا قبلاً حذف شده است.');
            $visitor=$this->visitor_order_scope_id();
            if($visitor && (int)$order['created_by']!==$visitor)throw new RuntimeException('فقط پیش‌فاکتور ثبت‌شده توسط خودتان را می‌توانید حذف کنید.');
            if($order['status']!=='proforma')throw new RuntimeException('فقط پیش‌فاکتور تأییدنشده قابل حذف است.');
            // Deleting an unposted draft must never orphan shipment, accounting or material-consumption history.
            $queries=[
                $this->db->prepare("SELECT id FROM {$this->fulfillments} WHERE order_id=%d LIMIT 1",$id),
                $this->db->prepare("SELECT id FROM {$this->order_items} WHERE order_id=%d AND (shipped_paid_qty>0 OR shipped_free_qty>0) LIMIT 1",$id),
                $this->db->prepare("SELECT id FROM {$this->ledger_entries} WHERE ref_type='order' AND ref_id=%d LIMIT 1",$id),
            ];
            $queries[]=$this->db->prepare("SELECT e.id FROM {$this->ledger_entries} e INNER JOIN {$this->db_prefix}ledger_entry_meta m ON m.entry_id=e.id WHERE m.meta_key='order_id' AND m.meta_value=%s AND e.user_id=%d LIMIT 1",(string)$id,$order['customer_id']);
            foreach([$this->payments,$this->transfers] as $table)$queries[]=$this->db->prepare("SELECT id FROM $table WHERE ref_id=%d AND user_id=%d LIMIT 1",$id,$order['customer_id']);
            foreach(['shipping_records'=>'order_id','customer_freight_payments'=>'order_id','supply_orders'=>'order_id'] as $table=>$fk){
                $table=$this->db_prefix.$table;$exists=$this->db->get_row($this->db->prepare('SHOW TABLE STATUS LIKE %s',$this->db->esc_like($table)),ARRAY_A);
                if($this->db->last_error)throw new RuntimeException('بررسی سوابق وابسته انجام نشد.');
                if($exists)$queries[]=$this->db->prepare("SELECT $fk FROM $table WHERE $fk=%d LIMIT 1",$id);
            }
            foreach($queries as $sql){
                $found=$this->db->get_var($sql);
                if($this->db->last_error)throw new RuntimeException('خواندن سوابق ارسال یا مالی انجام نشد؛ حذف متوقف شد.');
                if($found!==null)throw new RuntimeException('این پیش‌فاکتور سابقهٔ ارسال، مالی یا مصرف ملزومات دارد و قابل حذف نیست؛ مدیر سوابق را بررسی کند.');
            }
            $items=$this->db->get_col($this->db->prepare("SELECT id FROM {$this->order_items} WHERE order_id=%d FOR UPDATE",$id));
            if($this->db->last_error)throw new RuntimeException('خواندن اقلام پیش‌فاکتور انجام نشد.');
            foreach($items as $item){$r=$this->delete_meta('order_items',(int)$item);if($r['status']!=='success')throw new RuntimeException('حذف اطلاعات اقلام انجام نشد.');}
            $r=$this->delete_meta('orders',$id);if($r['status']!=='success')throw new RuntimeException('حذف اطلاعات پیش‌فاکتور انجام نشد.');
            if(false===$this->db->delete($this->order_items,['order_id'=>$id]))throw new RuntimeException('حذف اقلام پیش‌فاکتور انجام نشد.');
            if(1!==$this->db->delete($this->orders,['id'=>$id,'status'=>'proforma']))throw new RuntimeException('حذف پیش‌فاکتور انجام نشد.');
            if(false===$this->db->insert($this->actions_table,['user_id'=>(int)$order['customer_id'],'title'=>'حذف پیش‌فاکتور '.$order['order_number'],'content'=>'پیش‌فاکتور تأییدنشده با '.count($items).' ردیف و مبلغ '.number_format((float)$order['total_payable']).' ریال حذف شد.','date'=>current_time('mysql'),'creator'=>get_current_user_id()]))throw new RuntimeException('ثبت سابقهٔ حذف انجام نشد.');
            $audit=$this->save_meta_batch('action',(int)$this->db->insert_id,['type'=>'customer_proforma_deleted','order_id'=>$id,'order_number'=>$order['order_number'],'customer_id'=>$order['customer_id'],'created_by'=>$order['created_by'],'total_payable'=>$order['total_payable'],'deleted_items'=>count($items)]);
            if($audit['status']!=='success')throw new RuntimeException('ثبت سابقهٔ حذف انجام نشد.');
            if(false===$this->db->query('COMMIT'))throw new RuntimeException('ثبت نهایی حذف انجام نشد.');
            return $this->ok('پیش‌فاکتور با موفقیت حذف شد.',['order_id'=>$id,'customer_id'=>(int)$order['customer_id'],'deleted_items'=>count($items)]);
        }catch(Throwable $e){if ($in_transaction) $this->db->query('ROLLBACK');return $this->fail($e->getMessage());}
    }
}
