document.addEventListener('change', function (event) {
    const select = event.target;
    if (select.id === 'kphLevel') {
        const option = select.selectedOptions[0];
        const sections = JSON.parse(option.dataset.sections || '[]');
        const form = select.form;
        form.elements.name.value = select.value ? option.textContent : '';
        form.querySelectorAll('[name="sections[]"]').forEach(function (box) {
            box.checked = sections.includes(box.value);
        });
        form.elements.delete_level.hidden = !select.value;
    }
    if (select.id === 'kphAccessPerson') {
        select.form.elements.level.value = select.selectedOptions[0].dataset.level || '';
    }
});
