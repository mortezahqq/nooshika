<?php
if (!defined('ABSPATH')) { exit; }

/** Site-local policy. WordPress roles and capabilities remain independent of CRM levels. */
final class kph_hr_access {
    const OPTION = 'kph_hr_crm_access_v1';

    public static function sections(): array {
        return [
            'dashboard'=>'میزکار', 'customers'=>'مشتریان', 'suppliers'=>'تأمین‌کنندگان', 'purchases'=>'فاکتورهای تأمین',
            'production'=>'مخزن، فرآوری و سالن‌های تولید', 'supplies'=>'ملزومات بسته‌بندی',
            'warehouse'=>'انبار محصولات و مدیریت چندانباره', 'orders'=>'سفارش‌ها و پیش‌فاکتور',
            'shipping'=>'کنترل ارسال و دریافت', 'finance'=>'حسابداری، حساب‌های مالی، حواله و چک',
            'sales-report'=>'گزارش فروش', 'cost-report'=>'گزارش هزینه', 'stock-report'=>'گزارش انبار',
            'customer-report'=>'گزارش مشتریان', 'hr'=>'کارگزینی و حقوق پرسنل', 'visitors'=>'ویزیتورها',
        ];
    }

    private const ROUTES = [
        'dashboard'=>'dashboard','users'=>'customers','user'=>'customers','suppliers'=>'suppliers','supplier'=>'suppliers',
        'produce-invoice'=>'purchases','order-supplier'=>'purchases','order-supplier-edit'=>'purchases',
        'produce-repository'=>'production','produce-packaging'=>'production','produce-saloon'=>'production','produce-bulk'=>'production',
        'produce-supplies'=>'supplies','produce-warehouse'=>'warehouse','produce-warehouses'=>'warehouse','inventory-log'=>'warehouse',
        'orders-list'=>'orders','order-customer'=>'orders','order-customer-edit'=>'orders','shipping-control'=>'shipping',
        'finance-accounts'=>'finance','finance-transactions'=>'finance','finance-transfers'=>'finance','finance-cheque'=>'finance',
        'reports-order'=>'sales-report','reports-cost'=>'cost-report','reports-stock'=>'stock-report','reports-user'=>'customer-report',
        'hr-employees'=>'hr','hr-visitors'=>'visitors',
    ];

    public static function state(): array {
        $raw = get_option(self::OPTION, '');
        if ($raw === '') return ['revision'=>0, 'levels'=>[], 'members'=>[]];
        static $previous, $parsed;
        if (is_string($raw) && $raw === $previous) return $parsed;
        $state = is_string($raw) ? json_decode($raw, true) : null;
        if (!isset($state['revision'],$state['levels'],$state['members']) || !is_array($state['levels']) || !is_array($state['members'])) {
            wp_die('تنظیمات سطح دسترسی قابل خواندن نیست. مدیر سایت بررسی کند.', '', ['response'=>503]);
        }
        $previous=$raw;
        return $parsed=$state;
    }

    public static function eligible($user): bool {
        return $user && !user_can($user,'manage_options') && !empty($user->roles)
            && !array_diff($user->roles, kph_hr::roles());
    }

    /** Null means legacy role policy. An empty array means no selected CRM section. */
    public static function grants(): ?array {
        $id = get_current_user_id();
        if (!$id || current_user_can('manage_options')) return null;
        $state = self::state();
        $level = $state['members'][$id] ?? null;
        $user = wp_get_current_user();
        if ($level === null) return array_values($user->roles) === ['kph_employee'] ? [] : null;
        if (!self::eligible($user)) return [];
        $sections = $state['levels'][$level]['sections'] ?? [];
        if (kph_support_accounting_restricted()) {
            $sections = array_diff($sections, ['finance','cost-report','sales-report','customer-report']);
        }
        return array_values($sections);
    }

    public static function has(string $section): bool {
        return in_array($section, self::grants() ?? [], true);
    }

    public static function menu(array $pages): array {
        $grants = self::grants();
        if ($grants === null) return $pages;
        $roles = [nooshika_get_user_role(get_current_user_id())];
        $menu = [];
        $divider = null;
        foreach ($pages as $key=>$page) {
            if ($page['type'] === 'divider') { $divider = [$key=>$page]; continue; }
            if (isset($page['sub'])) {
                foreach ($page['sub'] as $child=>$data) {
                    $slug = explode('?', $child, 2)[0];
                    if (!in_array(self::ROUTES[$slug] ?? '', $grants, true)) unset($page['sub'][$child]);
                    else $page['sub'][$child]['valid_roles'] = $roles;
                }
                if (!$page['sub']) continue;
            } elseif (!in_array(self::ROUTES[$key] ?? '', $grants, true)) continue;
            if ($divider) {
                $divider[key($divider)]['valid_roles'] = $roles;
                $menu += $divider;
                $divider = null;
            }
            $page['valid_roles'] = $roles;
            $menu[$key] = $page;
        }
        return $menu;
    }

    public static function landing(array $menu): string {
        foreach ($menu as $slug=>$page) {
            if ($page['type'] === 'page') return $slug;
            if (!empty($page['sub'])) return explode('?', array_key_first($page['sub']), 2)[0];
        }
        return 'no-access';
    }

    public static function default_tab(string $kind, int $id): string {
        if ($kind!=='employee') return 'profile';
        return $id && nooshika_get_user_role($id)==='visitor' && self::has('visitors') ? 'targets' : 'hr';
    }

    public static function tab_allowed(string $kind, string $tab, int $id): bool {
        $user = get_userdata($id);
        if (!$user || user_can($user, 'manage_options')) return false;
        if ($kind === 'employee') {
            if (!self::eligible($user)) return false;
            if (in_array($tab, ['targets','commissions','orders','reports','wallet'],true)) return self::has('visitors') && in_array('visitor',$user->roles,true);
            if (in_array($tab, ['info','profile','actions'],true) && in_array('visitor',$user->roles,true) && self::has('visitors')) return true;
            return self::has('hr') && in_array($tab,['info','profile','hr','actions','financial','transfers','payments','cheque'],true);
        }
        $supplier = $kind === 'supplier';
        if (!self::has($supplier ? 'suppliers':'customers') || !in_array($supplier ? 'supplier':'subscriber', $user->roles,true)) return false;
        if (in_array($tab,['financial','payments','transfers','cheque'],true)) return self::has('finance');
        if ($tab === 'orders') return self::has('orders');
        if ($tab === 'invoice') return self::has('purchases');
        return in_array($tab,['profile','actions','info'],true);
    }

    public static function template(string $path, array $args): bool {
        if (self::grants() === null) return true;
        if (!preg_match('~^(?:[a-zA-Z0-9_-]+/)+[a-zA-Z0-9_-]+\.php$~D',$path)) return false;
        if (preg_match('~^(pages|sub_page)/([^/]+)\.php$~D',$path,$m)) {
            if (in_array($m[2],['user','supplier','employee'],true)) {
                global $wp;
                $id = absint($_REQUEST['id'] ?? (explode('/',trim($wp->request ?? '', '/'))[2] ?? 0));
                $tab = $_REQUEST['tab'] ?? self::default_tab($m[2],$id);
                return is_string($tab) && self::tab_allowed($m[2],$tab,$id);
            }
            return self::has(self::ROUTES[$m[2]] ?? '');
        }
        if (preg_match('~^tab/(employee|user|supplier)/([^/]+)\.php$~D',$path,$m)) {
            if ($path==='tab/user/financial.php' && ($args['kph_hr_accounting']??false)===true && self::has('hr') && self::eligible(get_userdata((int)($args['user_id']??0)))) return true;
            return self::tab_allowed($m[1],$m[2],(int)($args['user_id'] ?? 0));
        }
        return true;
    }

    public static function print_allowed(string $type, array $args): bool {
        if (self::grants() === null) return true;
        $map = ['factor'=>'orders','c-factor'=>'orders','order-items'=>'orders','fulfillments'=>'orders','preparation-list'=>'orders',
            'invoice'=>'purchases','financial'=>'finance','cheques'=>'finance','payments'=>'finance','transfers'=>'finance',
            'cost'=>'cost-report','stock'=>'stock-report','sales-report'=>'sales-report','customers-report'=>'customer-report','hr-record'=>'hr'];
        if ($type==='stock' && isset(kph_db::warehouse_print_titles()[$args['request']['section'] ?? ''])) return self::has('warehouse');
        return self::has($map[$type] ?? '') || (self::has('hr') && kph_support_hr_ledger_print($type,$args));
    }

    public static function action_allowed(string $action): bool {
        if (self::grants() === null) return true;
        if ($action==='request_page_content' || $action==='request_back_btn') {
            $raw=$_POST[$action==='request_back_btn'?'path':'page'] ?? '';
            if (!is_string($raw)) return false;
            $path=trim((string)wp_parse_url($raw,PHP_URL_PATH),'/');
            $parts=explode('/',$path);
            $crm=array_search('crm',$parts,true);
            if ($crm===false) return false;
            $slug=$parts[$crm+1]??'';
            if ($slug==='') return true;
            if (in_array($slug,['employee','user','supplier'],true)) {
                $id=absint($parts[$crm+2]??$_POST['id']??0);
                parse_str((string)wp_parse_url($raw,PHP_URL_QUERY),$query);
                $tab=$_POST['tab']??$query['tab']??self::default_tab($slug,$id);
                return is_string($tab) && self::tab_allowed($slug,$tab,$id);
            }
            return self::has(self::ROUTES[$slug]??'');
        }
        if (in_array($action,['save_dark_mode','change_skin','change_timezone','submit_change_password_form'],true)) return true;
        if ($action==='handle_file_upload') return (bool)self::grants();
        if ($action==='search_user_for_modal') {
            $role=$_POST['role'] ?? 'subscriber';
            return ($role==='subscriber' && (self::has('customers') || self::has('orders') || self::has('finance')))
                || ($role==='supplier' && (self::has('suppliers') || self::has('purchases') || self::has('finance')));
        }
        if ($action==='search_user') return self::has('customers');
        if ($action==='update_user_personal_data') {
            $id=absint($_POST['id']??0);
            $meta=$_POST['meta']??[];
            return self::tab_allowed('user','profile',$id) && is_array($meta)
                && !array_diff(array_keys($meta),array_keys((new kph_db())->get_user_meta_list()));
        }
        if ($action==='add_user') {
            $meta=$_POST['meta'] ?? [];
            if (!self::has('customers') || !is_array($meta) || array_diff(array_keys($meta),array_keys((new kph_db())->get_user_meta_list()))) return false;
            $phone=remove_zero_from_phone(nooshika_sanitize_numbers(sanitize_text_field($_POST['phone']??'')));
            $existing=get_user_id_by_phone($phone);
            return !$existing || self::tab_allowed('user','profile',(int)$existing);
        }
        if ($action==='submit_new_action_for_user') return self::tab_allowed('user','actions',absint($_POST['id']??0));
        if (in_array($action,['save_user_address','delete_customer_address','load_user_address'],true)) return self::tab_allowed('user','profile',absint($_POST['user_id']??0));
        if ($action==='load_inventory_table') return self::has('orders') || self::has('warehouse');
        $groups = [
            'suppliers'=>'add_supplier_user submit_supplier_action',
            'purchases'=>'search_supplier_invoice_product submit_new_supplier_order load_invoice_items_table change_invoice_status edit_invoice_item_rate cancel_supplier_invoice delete_supplier_invoice',
            'orders'=>'search_customer_invoice_product submit_customer_order check_customer_proforma change_order_status load_order_items load_order_fulfillment add_order_item_fulfillment send_order_sms correct_order_quantity cancel_remaining_item cancel_sended_product delete_customer_proforma update_order_shipment_date',
            'production'=>'measure_salon_lot search_production_codes register_production_code load_batch_storage_move submit_wasted_batch delete_batch_move return_lot_to_processing submit_wasted_packaging_lot delete_lot_move return_processing_pack_to_storage create_processing_pack load_processing_pack_inputs load_processing_to_packaging_report load_lot_moves transfer_pack_to_packaging convert_packaging_lot_to_shop_product convert_bulk_pack_to_shop_product',
            'supplies'=>'manage_supplies','warehouse'=>'set_inventory_item_price create_warehouse transfer_warehouse_stock transfer_warehouse_batch load_inventory_logs',
            'finance'=>'add_payment delete_payment add_transfer delete_transfer add_cheque delete_cheque add_account load_cheque_moves_table load_cheques_list change_cheque_status refer_cheque_to_user add_account_transaction update_finance_attachment customer_freight_invoices load_order_financial',
            'shipping'=>'shipping_control shipping_file','hr'=>'hr_action hr_file hr_export',
            'visitors'=>'visitor_monthly_sales delete_visitor_target save_visitor_target save_visitor_commission_settings',
        ];
        foreach ($groups as $section=>$actions) {
            if (in_array($action,explode(' ',$actions),true)) return self::has($section);
        }
        return false;
    }
}

// Check the actual dispatched action on both AJAX transports and protected downloads.
add_action('all',static function($hook){
    if (!preg_match('/^(nooshika_ajax_|wp_ajax_|admin_post_)kph_(.+)$/D',$hook,$m)) return;
    if (!get_current_user_id() && !in_array($m[2],['submit_login_form','send_login_otp','submit_login_otp'],true)) {
        wp_send_json(['status'=>'error','message'=>'ابتدا وارد پنل شوید.'],403);
    }
    if ($m[1]!=='admin_post_' && kph_hr_access::grants()!==null) {
        // The CRM sends AJAX requests from the panel origin on both transports.
        $source=$_SERVER['HTTP_ORIGIN'] ?? $_SERVER['HTTP_REFERER'] ?? '';
        $parts=wp_parse_url($source);
        $origin=is_array($parts) && isset($parts['scheme'],$parts['host'])
            ? $parts['scheme'].'://'.$parts['host'].(isset($parts['port'])?':'.$parts['port']:'') : '';
        if (!$origin || !is_allowed_http_origin($origin)) wp_send_json(['status'=>'error','message'=>'درخواست را از داخل پنل ارسال کنید.'],403);
    }
    if (!kph_hr_access::action_allowed($m[2])) {
        $message='اجازه دسترسی به این عملیات را ندارید.';
        if ($m[1]==='admin_post_') wp_die($message,'',['response'=>403]);
        wp_send_json(['status'=>'error','message'=>$message],403);
    }
},-1000);

// Ordinary settings forms cannot edit the policy option. Only the revision-checked writer below changes it.
add_filter('pre_update_option_'.kph_hr_access::OPTION,static fn($new,$old)=>$old,10,2);

function kph_hr_access_change(array $state,array $input): array {
    $op=isset($input['delete_level']) && ($input['operation']??'')==='save' ? 'delete' : ($input['operation'] ?? '');
    $key=$input['level'] ?? '';
    if (!is_string($key) || ($key!=='' && !isset($state['levels'][$key]))) throw new RuntimeException('سطح انتخاب‌شده وجود ندارد.');
    if ($op==='save') {
        $name=is_string($input['name']??null) ? trim(sanitize_text_field($input['name'])) : '';
        $sections=$input['sections'] ?? [];
        if ($name==='' || mb_strlen($name)>80) throw new RuntimeException('نام سطح باید بین ۱ تا ۸۰ نویسه باشد.');
        if (!is_array($sections) || !$sections) throw new RuntimeException('حداقل یک بخش انتخاب کنید.');
        foreach ($sections as $section) {
            if (!is_string($section) || !isset(kph_hr_access::sections()[$section])) throw new RuntimeException('بخش انتخاب‌شده معتبر نیست.');
        }
        foreach ($state['levels'] as $id=>$level) {
            if ($id!==$key && $level['name']===$name) throw new RuntimeException('این نام قبلاً برای یک سطح ثبت شده است.');
        }
        $key=$key ?: wp_generate_uuid4();
        $state['levels'][$key]=['name'=>$name,'sections'=>array_values(array_unique($sections))];
    } elseif ($op==='assign') {
        $id=absint($input['employee']??0);
        if (!$id || (!kph_hr_access::eligible(get_userdata($id)) && !($key==='' && isset($state['members'][$id])))) throw new RuntimeException('یک کارمند معتبر انتخاب کنید.');
        if ($key==='') unset($state['members'][$id]);
        else $state['members'][$id]=$key;
    } elseif ($op==='delete' && $key!=='') {
        foreach ($state['members'] as $id=>$member_level) {
            if ($member_level===$key && !get_userdata((int)$id)) unset($state['members'][$id]);
        }
        if (in_array($key,$state['members'],true)) throw new RuntimeException('این سطح به پرسنل اختصاص دارد. ابتدا سطح آن‌ها را تغییر دهید.');
        unset($state['levels'][$key]);
    } else {
        throw new RuntimeException('عملیات معتبر نیست.');
    }
    $state['revision']++;
    return $state;
}

add_action('admin_post_kph_hr_access',static function(){
    if (!current_user_can('manage_options') || ($_SERVER['REQUEST_METHOD']??'')!=='POST') wp_die('این عملیات فقط برای مدیر مجاز است.','',['response'=>403]);
    check_admin_referer('kph_hr_levels');
    global $wpdb;
    $state=kph_hr_access::state();
    $error='اطلاعات تغییر کرده است. صفحه را تازه کنید و دوباره ذخیره کنید.';
    if ((string)$state['revision'] !== ($_POST['revision']??null)) wp_die($error,'',['response'=>409,'back_link'=>true]);
    try { $next=kph_hr_access_change($state,wp_unslash($_POST)); }
    catch (RuntimeException $e) { wp_die(esc_html($e->getMessage()),'',['response'=>400,'back_link'=>true]); }
    $json=wp_json_encode($next, JSON_UNESCAPED_UNICODE);
    if ($state['revision']===0) {
        $result=$wpdb->insert($wpdb->options,['option_name'=>kph_hr_access::OPTION,'option_value'=>$json,'autoload'=>'no']);
    } else {
        $result=$wpdb->query($wpdb->prepare("UPDATE {$wpdb->options} SET option_value=%s WHERE option_name=%s AND BINARY option_value=%s",
            $json,kph_hr_access::OPTION,wp_json_encode($state, JSON_UNESCAPED_UNICODE)));
    }
    if ($result!==1) wp_die($wpdb->last_error ? 'ذخیرهٔ سطح دسترسی انجام نشد.' : $error,'',['response'=>409,'back_link'=>true]);
    wp_cache_delete(kph_hr_access::OPTION,'options');
    wp_cache_delete('notoptions','options');
    wp_safe_redirect(add_query_arg('access_saved','1',home_url('/crm/hr-employees/')));
    exit;
});

add_action('wp_print_scripts',static function(){
    if (current_user_can('manage_options') && wp_script_is('kasebi_clinic_script','enqueued')) {
        wp_enqueue_script('kph-hr-access',KPH_ASSETS_URL.'js/hr-access.js',[],KPH_VER,true);
    }
},20);

function kph_crm_section(string $section, bool $legacy): bool {
    $grants=kph_hr_access::grants();
    return $grants===null ? $legacy : in_array($section,$grants,true);
}
