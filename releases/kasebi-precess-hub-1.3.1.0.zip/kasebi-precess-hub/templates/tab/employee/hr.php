<?php
if(!defined('ABSPATH')){exit;}
if(!kph_hr::allowed()){echo '<p class="text-danger">دسترسی به پرونده کارگزینی مجاز نیست.</p>';return;}
$employee=absint($user_id??0);$hr=new kph_hr();
$hr_tabs=['hr_file'=>'پرونده کارگزینی','hr_contracts'=>'قراردادها','hr_leaves'=>'مرخصی‌ها','hr_attendance'=>'کارکردها','hr_payslips'=>'فیش‌های حقوقی','hr_settlements'=>'تسویه‌حساب‌ها','hr_documents'=>'مدارک','hr_audit'=>'سوابق تغییرات','payments'=>'پرداخت‌ها','transfers'=>'حواله‌ها','cheque'=>'چک‌های پرداختی'];
$active=sanitize_key(($_REQUEST['tab']??'hr')==='hr'?($_REQUEST['hr_section']??'hr_file'):($_REQUEST['tab']??'hr_file'));if(!isset($hr_tabs[$active])){$active='hr_file';}
$map=['hr_contracts'=>'contract','hr_leaves'=>'leave','hr_attendance'=>'attendance','hr_payslips'=>'payslip','hr_settlements'=>'settlement','hr_documents'=>'document','payments'=>'payment','transfers'=>'transfer','cheque'=>'cheque'];
try{$profile=$hr->profile($employee);}catch(Throwable $e){echo '<p class="text-danger">پرونده یافت نشد؛ ورود مدیر و آماده‌سازی افزونه را بررسی کنید.</p>';return;}
$balance=(new kph_db())->get_ledger_balance_now($employee)['balance']??0;
$page=max(1,absint($_REQUEST['hr_page']??1));
?>
<div class="kph-hr" data-employee="<?php echo $employee;?>" data-nonce="<?php echo esc_attr(wp_create_nonce('kph_hr'));?>">
    <nav style="gap:0.375rem" class="d-flex flex-wrap  mb-4" aria-label="بخش‌های کارگزینی"><?php foreach($hr_tabs as $key=>$label){?><a class="btn btn-sm <?php echo $key===$active?'btn-primary':'btn-light';?> page_activator" href="<?php echo esc_url(kph_hr_url($employee,$key));?>"><?php echo esc_html($label);?></a><?php }?></nav>
    <div class="kph-hr-message mb-3" role="status" aria-live="polite"></div>
    <h5><?php echo esc_html($hr_tabs[$active]);?></h5>
    <p>مانده حساب پرسنل: <strong><?php echo number_format(abs($balance));?> ریال</strong> — <?php echo $balance<0?'طلب پرسنل از مجموعه':($balance>0?'بدهی پرسنل به مجموعه':'تسویه');?></p>
    <?php if(!$hr->financial_ready()){ ?>
        <div class="alert alert-warning">برای تأیید مالی، ابتدا ثبت یکپارچه حسابداری را آماده کنید. پیش از این کار از دیتابیس پشتیبان بگیرید.
        <button type="button" class="btn btn-sm btn-primary kph-hr-action" data-operation="prepare">آماده‌سازی حسابداری پرسنل</button></div>
    <?php } ?>
    <?php if($active==='hr_file'){
        $p=$profile['data'];$p+=['full_name'=>get_user_name_by_id($employee),'child_count'=>0];$used=$hr->leave_used($employee,$p['leave_year']??'');
        ?>
        <p>سهمیه مرخصی استحقاقی <?php echo esc_html($p['leave_year']??'');?>: <?php echo number_format($p['leave_allowance_minutes']??0);?> دقیقه | مصرف‌شده: <?php echo number_format($used);?> دقیقه | باقی‌مانده: <?php echo number_format(max(0,($p['leave_allowance_minutes']??0)-$used));?> دقیقه</p>
        <form class="kph-hr-form" method="post">
            <input type="hidden" name="operation" value="profile"><input type="hidden" name="employee_id" value="<?php echo $employee;?>"><input type="hidden" name="version" value="<?php echo (int)$profile['version'];?>">
            <div class="row">
            <?php
            $defs=['full_name'=>['نام و نام خانوادگی','text'],'father_name'=>['نام پدر','text'],'identity_no'=>['شماره شناسنامه','text'],'birth_date'=>['تاریخ تولد','date'],'birth_place'=>['محل تولد','text'],'issue_place'=>['محل صدور شناسنامه','text'],'marital_status'=>['وضعیت تأهل','text'],'child_count'=>['تعداد فرزند','number'],'education'=>['تحصیلات','text'],'bank_account_no'=>['شماره حساب','text'],'employee_no'=>['کد پرسنلی یکتا','text'],'status'=>['وضعیت همکاری','select',['active'=>'فعال','inactive'=>'پایان همکاری / غیرفعال']],'department'=>['واحد سازمانی','text'],'job_title'=>['سمت','text'],'join_date'=>['تاریخ شروع همکاری','date'],'exit_date'=>['تاریخ پایان همکاری','date'],'national_id'=>['کد ملی','text'],'insurance_no'=>['شماره بیمه','text'],'phone'=>['تلفن','text'],'email'=>['ایمیل','text'],'bank_name'=>['بانک','text'],'iban'=>['شماره شبا','text'],'address'=>['نشانی','textarea'],'emergency_name'=>['نام تماس اضطراری','text'],'emergency_phone'=>['تلفن تماس اضطراری','text'],'leave_year'=>['سال سهمیه مرخصی','text'],'leave_allowance_minutes'=>['سهمیه مرخصی سال (دقیقه)','number'],'notes'=>['یادداشت داخلی پرونده','textarea']];
            foreach($defs as $key=>$def){kph_hr_form_field($key,$def,$profile[$key]??$p[$key]??($def[1]==='number'?0:''));}
            ?></div><button class="btn btn-primary" type="submit">ذخیره پرونده</button>
        </form>
    <?php }elseif($active==='hr_documents'&&empty($_REQUEST['hr_documents_legacy'])){require KPH_PATH.'templates/partials/hr-documents.php';}elseif($active==='hr_audit'){
        $list=$hr->audits($employee,$page);?>
        <div class="table-responsive"><table class="table"><thead><tr><th>تاریخ</th><th>کاربر ثبت‌کننده</th><th>عملیات</th><th>شماره رکورد</th><th>جزئیات</th></tr></thead><tbody>
        <?php foreach($list['items'] as $r){ ?>
            <tr><td><?php echo esc_html(date_i18n('Y/m/d H:i',strtotime($r['created_at'])));?></td><td><?php echo esc_html(get_user_name_by_id($r['actor_id']));?></td><td><?php echo esc_html(['profile'=>'ویرایش پرونده','create'=>'ثبت پیش‌نویس','edit'=>'ویرایش پیش‌نویس','approve'=>'تأیید','clear'=>'وصول چک','cancel'=>'ابطال','reject'=>'رد','bounce'=>'برگشت چک','attach'=>'پیوست مدرک','replace_file'=>'جایگزینی مدرک','delete_file'=>'حذف مدرک'][$r['event']]??$r['event']);?></td><td><?php echo (int)$r['record_id'];?></td><td><details><summary>قبل و بعد</summary><table class="table table-sm"><thead><tr><th>مورد</th><th>قبل</th><th>بعد</th></tr></thead><tbody><?php foreach(kph_hr_audit_changes(json_decode($r['before_data'],TRUE)?:[],json_decode($r['after_data'],TRUE)?:[]) as $change){?><tr><th><?php echo esc_html($change['label']);?></th><td style="white-space:pre-wrap"><?php echo esc_html($change['before']);?></td><td style="white-space:pre-wrap"><?php echo esc_html($change['after']);?></td></tr><?php }?></tbody></table></details></td></tr>
        <?php } ?></tbody></table></div>
    <?php }else{
        $kind=$map[$active];$state=sanitize_key($_REQUEST['hr_status']??'');$search=sanitize_text_field(wp_unslash($_REQUEST['hr_search']??''));
        $list=$hr->listing($employee,$kind,$page,$state,$search);$editing=NULL;
        if(!empty($_REQUEST['hr_edit'])){try{$editing=$hr->record(absint($_REQUEST['hr_edit']),$employee);if($editing['kind']!==$kind||$editing['status']!=='draft'){$editing=NULL;}}catch(Throwable $e){echo '<p class="text-danger">پیش‌نویس انتخاب‌شده یافت نشد.</p>';}}
        $formValues=$editing?array_merge($editing,$editing['data']):['normal_days'=>30,'basis'=>'monthly','leave_year'=>$profile['data']['leave_year']??''];
        if($kind==='payslip'){echo '<p class="alert alert-info">اطلاعات حقوق هر ماه را دستی وارد کنید یا از قرارداد و کارکرد تأییدشده بخوانید. فیش ابتدا پیش‌نویس است؛ ثبت طلب حقوق در حسابداری فقط با تأیید شما انجام می‌شود. مساعدهٔ قبلاً پرداخت‌شده فقط مبلغ قابل پرداخت فیش را کم می‌کند؛ آن را دوباره در سایر کسورات وارد نکنید.</p>';}
        if($kind==='settlement'){echo '<p class="alert alert-info">برای برگهٔ تسویه مطابق نمونه، «فقط صدور برگه» را انتخاب کنید؛ این حالت ثبت مالی ندارد. «ثبت مزایای جدید» فقط سنوات، عیدی، مرخصی و سایر مطالبات جدید را به حساب اضافه می‌کند. مبالغ دریافت‌شدهٔ فرم، جای ثبت پرداخت واقعی را نمی‌گیرند.</p>';}
        if($kind==='cheque'){echo '<p class="alert alert-info">چک پرداختی تا زمان وصول در حسابداری و موجودی بانک اثر ندارد. پس از پرداخت واقعی، وصول را ثبت کنید. چک‌های دریافتی مشتریان در بخش قبلی چک‌ها مدیریت می‌شوند.</p>';}
        if($kind==='attendance'){echo '<p>برای هر روز یک کارکرد ثبت کنید؛ ساعات عادی و اضافه‌کاری جدا وارد می‌شوند. هر ساعت ۶۰ دقیقه است. کارکردها پس از تأیید در خلاصه فیش لحاظ می‌شوند.</p>';}
        if($kind==='leave'){echo '<p>مدت مرخصی و سال سهمیه را وارد کنید. تنها مرخصی استحقاقی تأییدشده از سهمیه کم می‌شود؛ روز تعطیل یا تعطیلات بین بازه را در مدت وارد نکنید.</p>';}
        ?>
        <?php if(in_array($kind,['contract','payslip','settlement'],TRUE)){require KPH_PATH.'templates/partials/hr-form.php';}else{ ?>
        <details class="mb-4" <?php echo $editing?'open':'';?>><summary class="btn btn-outline-primary"><?php echo $editing?'ویرایش پیش‌نویس #'.(int)$editing['id']:'افزودن '.esc_html(kph_hr::kinds()[$kind]);?></summary>
            <form class="kph-hr-form mt-3" method="post">
                <input type="hidden" name="operation" value="save"><input type="hidden" name="employee_id" value="<?php echo $employee;?>"><input type="hidden" name="kind" value="<?php echo esc_attr($kind);?>"><input type="hidden" name="record_id" value="<?php echo (int)($editing['id']??0);?>"><input type="hidden" name="version" value="<?php echo (int)($editing['version']??0);?>">
                <div class="row">
                <?php foreach(kph_hr_fields($kind) as $key=>$def){
                    if(in_array($def[1],['account','contract'],TRUE)){
                        $options=[''=>'انتخاب کنید'];
                        if($def[1]==='account'){$records=(new kph_db())->get_accounts(['status'=>'active','per_page'=>200]);foreach($records['items']??[] as $a){$options[$a['id']]=$a['title'];}}
                        else{$contracts=$hr->listing($employee,'contract',1,'approved');foreach($contracts['items'] as $c){$options[$c['id']]='#'.$c['id'].' — '.$c['data']['title'].' — '.date_i18n('Y/m/d',strtotime($c['date_to']));}}
                        $def[1]='select';$def[2]=$options;
                    }
                    kph_hr_form_field($key,$def,$formValues[$key]??(isset($def[1])&&$def[1]==='number'?0:''));
                } ?></div><button type="submit" class="btn btn-primary">ذخیره پیش‌نویس و محاسبه</button>
                <?php if($editing){ ?><a class="btn btn-light page_activator" href="<?php echo esc_url(kph_hr_url($employee,$active));?>">انصراف از ویرایش</a><?php } ?>
            </form>
        </details>
        <?php } ?>
        <form method="get" class="row mb-3">
            <input type="hidden" name="tab" value="hr"><input type="hidden" name="hr_section" value="<?php echo esc_attr($active);?>">
            <?php if($active==='hr_documents'){?><input type="hidden" name="hr_documents_legacy" value="1"><?php }?><div class="col-md-4"><label>وضعیت</label><select class="form-select" name="hr_status"><option value="">همه وضعیت‌ها</option><?php foreach(kph_hr::statuses() as $key=>$label){ ?><option value="<?php echo esc_attr($key);?>" <?php selected($state,$key);?>><?php echo esc_html($label);?></option><?php } ?></select></div>
            <div class="col-md-5"><label>عنوان یا دوره</label><input class="form-control" name="hr_search" value="<?php echo esc_attr($search);?>"></div><div class="col-md-3 align-self-end"><button type="submit" class="btn btn-light">جستجو</button></div>
        </form>
        <p>تعداد نتیجه: <?php echo number_format($list['total']);?></p>
        <div class="table-responsive"><table class="table table-bordered"><thead><tr><th>شماره / عنوان</th><th>بازه / دوره</th><th>وضعیت</th><th>مبلغ / مدت</th><th>جزئیات و اقدامات</th></tr></thead><tbody>
        <?php foreach($list['items'] as $r){$d=$r['data'];$detailData=array_merge($d,$d['person']??[],$d['employer']??[]); ?>
            <tr><td>#<?php echo (int)$r['id'];?> — <?php echo esc_html($d['title']);?></td><td><?php echo esc_html(date_i18n('Y/m/d',strtotime($r['date_from'])).' تا '.date_i18n('Y/m/d',strtotime($r['date_to'])));?><br><?php echo esc_html($r['period']);?></td><td><?php echo esc_html(kph_hr::statuses()[$r['status']]??$r['status']);?></td><td><?php echo in_array($kind,['leave','attendance'],TRUE)?number_format($d['minutes']??$d['worked_minutes']??0).' دقیقه':number_format($kind==='payslip'?($d['payable_amount']??$r['amount']):$r['amount']).' ریال';?></td><td>
                <details><summary>مشاهده جزئیات</summary>
                <dl class="mt-2">
                <?php foreach(kph_hr_fields($kind) as $key=>$def){if(!isset($detailData[$key])||$detailData[$key]===''||!is_scalar($detailData[$key])){continue;}?><dt><?php echo esc_html($def[0]);?></dt><dd style="white-space:pre-wrap"><?php echo esc_html($def[1]==='select'?($def[2][$detailData[$key]]??$detailData[$key]):$detailData[$key]);?></dd><?php } ?>
                <?php foreach(['base_amount'=>'حقوق پایه محاسبه‌شده','overtime_amount'=>'اضافه‌کاری محاسبه‌شده','gross'=>'حقوق ناخالص','salary_deductions'=>'کسورات حقوق بدون مساعده','paid_advance'=>'مساعدهٔ قبلاً پرداخت‌شده','payable_amount'=>'قابل پرداخت فیش','receipt_total'=>'مبلغ دریافتی برگهٔ تسویه','new_benefits_total'=>'مزایای جدید تسویه','balance_at_approval'=>'مانده پس از ثبت تسویه'] as $key=>$label){if(isset($d[$key])){?><dt><?php echo esc_html($label);?></dt><dd><?php echo number_format($d[$key]);?> ریال</dd><?php }} ?>
                <?php if(isset($d['work_snapshot'])){?><dt>کارکرد تأییدشده دوره</dt><dd><?php echo number_format($d['work_snapshot']['days']);?> روز، <?php echo number_format($d['work_snapshot']['worked_minutes']);?> دقیقه عادی، <?php echo number_format($d['work_snapshot']['overtime_minutes']);?> دقیقه اضافه‌کاری</dd><?php } ?>
                </dl>
                <?php foreach($hr->files($employee,(int)$r['id']) as $file){$url=add_query_arg(['action'=>'kph_hr_file','file_id'=>$file['id'],'_wpnonce'=>wp_create_nonce('kph_hr_file_'.$file['id'])],admin_url('admin-post.php'));?><p><a href="<?php echo esc_url($url);?>" target="_blank" rel="noopener"><?php echo esc_html($file['filename']);?></a></p><?php } ?>
                <form class="kph-hr-form" method="post" enctype="multipart/form-data"><input type="hidden" name="operation" value="attach"><input type="hidden" name="employee_id" value="<?php echo $employee;?>"><input type="hidden" name="record_id" value="<?php echo (int)$r['id'];?>"><label>پیوست محرمانه PDF / تصویر / Word، حداکثر ۵ مگابایت</label><input class="form-control" name="file" type="file" accept=".pdf,.jpg,.jpeg,.png,.doc,.docx" required><button class="btn btn-sm btn-light mt-2" type="submit">افزودن پیوست</button></form>
                </details>
                <div style="gap:0.375rem" class="d-flex flex-wrap  mt-2">
                <?php if($r['status']==='draft'){?><a class="btn btn-sm btn-outline-primary page_activator" href="<?php echo esc_url(kph_hr_url($employee,$active,['hr_edit'=>$r['id']]));?>">ویرایش</a><?php }
                $actions=[];
                if($r['status']==='draft'){$actions['approve']='تأیید';$actions['reject']='رد';}
                if($kind==='cheque'&&$r['status']==='posted'){$actions['clear']='وصول';$actions['bounce']='برگشت';}
                if(in_array($r['status'],['draft','approved','posted','cleared'],TRUE)){$actions['cancel']='ابطال';}
                foreach($actions as $op=>$label){?><button type="button" class="btn btn-sm btn-outline-secondary kph-hr-action" data-record="<?php echo (int)$r['id'];?>" data-version="<?php echo (int)$r['version'];?>" data-operation="<?php echo esc_attr($op);?>"><?php echo esc_html($label);?></button><?php } ?>
                <a class="btn btn-sm btn-outline-primary" href="<?php echo esc_url(kph_hr_print_url($employee,(int)$r['id']));?>" target="_blank" rel="noopener">پیش‌نمایش / چاپ</a>
                <?php if(in_array($kind,['contract','payslip','settlement'],TRUE)){foreach(['pdf'=>'دانلود PDF','docx'=>'دانلود Word'] as $format=>$label){?><a class="btn btn-sm btn-light" href="<?php echo esc_url(kph_hr_export_url($employee,(int)$r['id'],$format));?>"><?php echo esc_html($label);?></a><?php }} ?>
                </div>
            </td></tr>
        <?php }if(!$list['items']){?><tr><td colspan="5">رکوردی برای نمایش وجود ندارد.</td></tr><?php }?></tbody></table></div>
    <?php }
    if(isset($list)&&$list['pages']>1){?>
        <nav aria-label="صفحه‌بندی کارگزینی"><ul class="pagination flex-wrap">
        <?php for($i=1;$i<=$list['pages'];$i++){if($i!==1&&$i!==$list['pages']&&abs($i-$page)>2){continue;}?><li><a class="btn <?php echo $i===$page?'btn-primary':'btn-light';?> page_activator" href="<?php echo esc_url(kph_hr_url($employee,$active,['hr_page'=>$i,'hr_status'=>$state??'','hr_search'=>$search??'','hr_documents_legacy'=>($active==='hr_documents'?1:0)]));?>"><?php echo $i;?></a></li><?php }?>
        </ul></nav>
    <?php } ?>
</div>
