<?php
if ( ! defined( 'ABSPATH' ) || ! current_user_can( 'manage_options' ) ) { return; }
$DB = isset( $DB ) ? $DB : new kph_db();
$ready = $DB->workflow_storage_ready();
?>
<details id="kph-workflow-tools" class="card card-bordered p-3 mb-3" <?php echo !$ready ? 'open' : ''; ?>>
    <summary>ابزارهای ثبت یکپارچه و بررسی تولید</summary>
    <p class="mt-3">پیش از آماده‌سازی، نسخه پشتیبان دیتابیس بگیرید و عملیات را در زمان توقف ثبت تولید و فاکتور انجام دهید. این عملیات جدول‌های مرتبط را برای ثبت یکپارچه و تشخیص موجودی با کد و شناسه محصول آماده می‌کند. برای پشتیبانی کدهای مشترک، پس از نصب این نسخه یک‌بار آماده‌سازی را اجرا کنید؛ شناسه و موجودی ردیف‌های قبلی حفظ می‌شوند.</p>
    <p><?php echo $ready ? 'ثبت یکپارچه آماده است.' : 'برای جلوگیری از ثبت ناقص تولید و ویرایش فاکتور، آماده‌سازی لازم است.'; ?></p>
    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
        <input type="hidden" name="action" value="kph_workflow_maintenance">
        <input type="hidden" name="operation" value="prepare">
        <?php wp_nonce_field( 'kph_workflow_maintenance' ); ?>
        <button type="submit" class="btn btn-primary button button-primary">آماده‌سازی و انتقال کدهای موجود</button>
    </form>
    <h5 class="mt-4">کدهای مشتری بدون پسوند</h5>
    <p>پسوند کلاسیک، ممتاز یا برلیان کد مشتری را تغییر نمی‌دهد. هر نام موجود در فهرست، محصول مستقلی در انبار و فاکتور دارد. محصولی که هنوز در مخزن تعریف نشده، پس از تعریف با نام و وزن صحیح به این فهرست متصل می‌شود.</p>
    <div class="table-responsive"><table class="table"><thead><tr><th>کد مشتری</th><th>نوع و وزن</th><th>محصولات موجود</th></tr></thead><tbody>
    <?php foreach($DB->customer_product_code_report() as $rule){ ?>
        <tr><td dir="ltr"><?php echo esc_html($rule['code']); ?></td><td><?php echo esc_html($rule['name']); ?></td><td>
            <?php if(!$rule['products']){echo 'محصول منتشرشده با این نام و وزن در مخزن تعریف نشده است.';}else{foreach($rule['products'] as $product){echo '<div>'.esc_html($product['title'].' (#'.$product['id'].')').'</div>';}} ?>
        </td></tr>
    <?php } ?></tbody></table></div>
    <h5 class="mt-4">تبدیل‌های ناسازگار با کد موجودی</h5>
    <p>اصلاح هر مورد فقط برای تبدیل ناقص و بدون گردش دیگر مجاز است. محصول از کد موجودی مشخص می‌شود. پیش‌فرض، وزن قبلی حفظ می‌شود؛ اگر وزن هر آیتم را تغییر دهید، تعداد و هزینه بسته‌بندی و بهای هر آیتم دوباره محاسبه می‌شوند. وزن کل مواد تغییر نمی‌کند.</p>
    <?php foreach ( $DB->production_conversion_conflicts() as $conflict ) { ?>
    <div class="border p-3 mb-2">
        <p><?php echo esc_html( 'تبدیل #' . $conflict['id'] . ' — کد ' . $conflict['code'] . ' — محصول ثبت‌شده: ' . $conflict['wrong_title'] . ' — محصول کد موجودی: ' . $conflict['expected_title'] ); ?></p>
        <p><?php echo esc_html( 'تعداد: ' . $conflict['qty_items'] . '؛ وزن هر آیتم: ' . $conflict['weight_per_item'] . ' کیلوگرم' ); ?></p>
        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
            <input type="hidden" name="action" value="kph_workflow_maintenance">
            <input type="hidden" name="operation" value="repair">
            <input type="hidden" name="conversion_id" value="<?php echo esc_attr( $conflict['id'] ); ?>">
            <?php wp_nonce_field( 'kph_workflow_maintenance' ); ?>
            <label class="d-block">وزن تأییدشده هر آیتم (گرم): <input class="kph-repair-weight" type="number" name="weight_per_item_gram" min="0.001" step="0.001" required data-total-grams="<?php echo esc_attr( (int) $conflict['qty_items'] * (float) $conflict['weight_per_item'] * 1000 ); ?>" data-pack-cost="<?php echo esc_attr( $conflict['packaging_cost_per_item'] ); ?>" value="<?php echo esc_attr( (float) $conflict['weight_per_item'] * 1000 ); ?>"></label>
            <output class="kph-repair-preview d-block"><?php echo esc_html( 'تعداد پس از اصلاح: ' . $conflict['qty_items'] . '؛ هزینه بسته‌بندی کل: ' . number_format( (int) $conflict['qty_items'] * (float) $conflict['packaging_cost_per_item'] ) . ' ریال' ); ?></output>
            <label><input type="checkbox" name="confirm_repair" value="1" required> محصول مقصد و تعداد و وزن ثبت‌شده را بررسی و تأیید کرده‌ام.</label>
            <button type="submit" class="btn btn-warning button" <?php disabled( ! $ready ); ?>>اصلاح ارتباط محصول و تکمیل موجودی</button>
        </form>
    </div>
    <?php } ?>
</details>
<script>
if (!window.kphRepairPreviewBound) {
    window.kphRepairPreviewBound = true;
    document.addEventListener('input', function(event) {
        var field = event.target;
        if (!field.matches('.kph-repair-weight')) return;
        var weight = Number(field.value), qty = Number(field.dataset.totalGrams) / weight;
        var rounded = Math.round(qty), output = field.closest('form').querySelector('.kph-repair-preview');
        output.textContent = weight > 0 && rounded > 0 && Math.abs(qty - rounded) < 0.000001 ?
            'تعداد پس از اصلاح: ' + rounded + '؛ هزینه بسته‌بندی کل: ' + (rounded * Number(field.dataset.packCost)).toLocaleString('fa-IR') + ' ریال' :
            'وزن کل باید دقیقاً به تعداد صحیح آیتم تقسیم شود.';
    });
}
</script>
