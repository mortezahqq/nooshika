<?php
if(!defined('ABSPATH')){exit;}
$DB=new kph_db();
if(!$DB->freight_allowed()){echo '<div class="alert alert-warning">اجازه مشاهده کرایه مشتریان را ندارید.</div>';return;}
$filters=[];
foreach(['date_from','date_to','search','status'] as $key){$v=$_REQUEST['freight_'.$key]??'';$filters[$key]=is_string($v)?sanitize_text_field(wp_unslash($v)):'';}
$filters['status']=$filters['status']?:'active';
$filters['page']=max(1,absint($_REQUEST['freight_page']??1));
$dbFilters=$filters;
foreach(['date_from','date_to'] as $key){if($filters[$key]!==''){$dbFilters[$key]=nooshika_jalali_to_gregorian($filters[$key]);}}
$report=$DB->get_customer_freight_report($dbFilters);$write=$DB->freight_allowed(TRUE);
?>
<div class="kph-customer-freight" data-nonce="<?php echo esc_attr(wp_create_nonce('kph_customer_freight')); ?>">
    <div class="nk-block-head"><h3>کرایه مشتریان</h3><p>ثبت کرایه با مشخصات مشتری؛ پرداختی کرایه از بدهی مشتری کسر می‌شود و هم‌زمان هزینه ثبت می‌شود.</p></div>
    <?php if(!$DB->freight_storage_ready()){ ?>
    <div class="alert alert-warning">برای ثبت و ابطال یکپارچه کرایه، مدیر باید ابتدا آماده‌سازی را انجام دهد. پیش از آماده‌سازی، نسخه پشتیبان دیتابیس تهیه کنید.
        <?php if(current_user_can('manage_options')){ ?><button type="button" class="btn btn-warning kph-freight-action" data-operation="prepare">آماده‌سازی ثبت کرایه</button><?php } ?>
    </div><?php } ?>
    <form action="<?php echo esc_url(home_url('/crm/customer-freight')); ?>" method="get" class="row g-3 mb-4">
        <div class="col-md-3"><label class="form-label" for="freight_search">نام مشتری، موبایل یا شماره پرداخت</label><input class="form-control" id="freight_search" name="freight_search" value="<?php echo esc_attr($filters['search']); ?>"></div>
        <?php foreach(['date_from'=>'از تاریخ','date_to'=>'تا تاریخ'] as $key=>$label){ ?>
        <div class="col-md-3"><label class="form-label" for="freight_<?php echo esc_attr($key); ?>"><?php echo esc_html($label); ?></label><input type="text" class="form-control datepicker" id="freight_<?php echo esc_attr($key); ?>" name="freight_<?php echo esc_attr($key); ?>" value="<?php echo esc_attr($filters[$key]); ?>"></div>
        <?php } ?>
        <div class="col-md-3"><label class="form-label" for="freight_status">وضعیت</label><select class="form-select" id="freight_status" name="freight_status"><?php foreach(['active'=>'فعال','canceled'=>'ابطال‌شده','all'=>'همه'] as $key=>$label){ ?><option value="<?php echo esc_attr($key); ?>" <?php echo $filters['status']===$key?'selected':''; ?>><?php echo esc_html($label); ?></option><?php } ?></select></div>
        <div class="col-12"><button class="btn btn-primary" type="submit">نمایش گزارش</button></div>
    </form>
    <?php if(($report['status']??'')!=='success'){ ?><div class="alert alert-danger"><?php echo esc_html($report['message']??'خواندن گزارش انجام نشد.'); ?></div><?php }else{$data=$report['data']; ?>
    <div class="card card-bordered p-3 mb-3">تعداد: <?php echo esc_html($data['total']); ?> — مجموع مبالغ در وضعیت انتخابی: <?php echo esc_html(number_format($data['amount'])); ?> ریال</div>
    <div class="card card-bordered table-responsive"><table class="table"><thead><tr><th>تاریخ</th><th>مشتری</th><th>موبایل</th><th>مبلغ (ریال)</th><th>شماره پرداخت / سفارش</th><th>توضیحات</th><th>ثبت‌کننده</th><th>وضعیت</th><?php if($write){ ?><th>عملیات</th><?php } ?></tr></thead><tbody>
    <?php foreach($data['items'] as $row){ ?><tr>
        <td><?php echo esc_html(date_i18n('Y/m/d',strtotime($row['created_at']))); ?></td>
        <td><?php echo esc_html($row['customer_name']); ?><?php if($row['customer_id']){ ?><small class="d-block">شناسه مشتری: <?php echo esc_html($row['customer_id']); ?></small><?php } ?></td>
        <td><?php echo esc_html($row['customer_phone']?:'—'); ?></td><td><?php echo esc_html(number_format($row['amount'])); ?></td>
        <td><?php echo esc_html($row['payment_id']?'#'.$row['payment_id']:'ثبت هزینه مستقیم'); ?><?php if($row['invoice_id']){ ?><small class="d-block">سفارش #<?php echo esc_html($row['invoice_id']); ?></small><?php } ?></td>
        <td style="white-space:pre-wrap"><?php echo esc_html(html_entity_decode(wp_strip_all_tags(preg_replace('#<br\s*/?>|</(?:p|div|li)>#i',"\n",$row['note'])),ENT_QUOTES|ENT_HTML5,'UTF-8')); ?></td>
        <td><?php echo esc_html(get_user_name_by_id((int)$row['created_by'])?:'—'); ?></td>
        <td><?php echo esc_html($row['status']==='canceled'?'ابطال‌شده':'فعال'); ?><?php if($row['status']==='canceled'){ ?><small class="d-block"><?php echo esc_html($row['cancel_reason']); ?></small><small class="d-block"><?php echo esc_html(date_i18n('Y/m/d H:i',strtotime($row['canceled_at']))).' — '.esc_html(get_user_name_by_id((int)$row['canceled_by'])?:'—'); ?></small><?php } ?></td>
        <?php if($write){ ?><td><?php if($row['record_id']&&$row['status']==='active'){ ?><button class="btn btn-sm btn-outline-danger kph-freight-action" type="button" data-operation="cancel" data-record="<?php echo esc_attr($row['record_id']); ?>" data-version="<?php echo esc_attr($row['version']); ?>">ابطال کرایه</button><?php }else{echo $row['status']==='canceled'?'ابطال‌شده':'ثبت هزینه مستقیم';} ?></td><?php } ?>
    </tr><?php } ?>
    <?php if(!$data['items']){ ?><tr><td colspan="<?php echo $write?9:8; ?>">کرایه‌ای با این فیلترها یافت نشد.</td></tr><?php } ?>
    </tbody></table></div>
    <?php if($data['pages']>1){$url=home_url('/crm/customer-freight');$query=[];foreach(['date_from','date_to','search','status'] as $key){$query['freight_'.$key]=$filters[$key];} ?>
    <nav aria-label="صفحه‌های کرایه مشتریان" class="mt-3"><ul class="pagination flex-wrap"><?php for($n=1;$n<=$data['pages'];$n++){if($n>1&&$n<$data['pages']&&abs($n-$filters['page'])>2){continue;}$query['freight_page']=$n; ?><li class="page-item <?php echo $n===$filters['page']?'active':''; ?>"><a class="page-link" href="<?php echo esc_url(add_query_arg($query,$url)); ?>"><?php echo esc_html($n); ?></a></li><?php } ?></ul></nav>
    <?php } } ?>
</div>
