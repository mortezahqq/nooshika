(function($){
    'use strict';
    function request($root, data) {
        var $status=$root.find('.kph-hr-message').first();
        if($root.data('hrBusy')) return;
        $root.data('hrBusy',true);
        var $buttons=$root.find('button');$buttons.prop('disabled',true);
        var isForm=data instanceof FormData;
        if(isForm){data.set('action','kph_hr_action');data.set('nonce',$root.attr('data-nonce'));}
        else{data.action='kph_hr_action';data.nonce=$root.attr('data-nonce');}
        $status.text('در حال ثبت…').removeClass('text-danger text-success');
        $.ajax({url:window.ajax_url||(typeof ajax_url!=='undefined'?ajax_url:'/wp-admin/admin-ajax.php'),method:'POST',data:data,processData:!isForm,contentType:isForm?false:'application/x-www-form-urlencoded; charset=UTF-8'})
          .done(function(res){
              if(res.status==='success'){
                  $status.text(res.message).addClass('text-success');
                  if(res.url){window.location.assign(res.url);}else{window.location.reload();}
              }else{$status.text(res.message||'ثبت انجام نشد.').addClass('text-danger');}
          }).fail(function(xhr){$status.text(xhr.responseJSON&&xhr.responseJSON.message||'ارتباط برقرار نشد؛ وضعیت ثبت را پس از تازه‌کردن صفحه بررسی کنید.').addClass('text-danger');})
          .always(function(){$root.data('hrBusy',false);$buttons.prop('disabled',false);});
    }
    $(document).on('submit','form.kph-hr-form',function(e){
        e.preventDefault();var $form=$(this),$root=$form.closest('.kph-hr');var data=new FormData(this);
        $form.find('.datepicker').each(function(){var val=$(this).attr('data-gdate');if(val)data.set(this.name,val);});
        request($root,data);
    });
    $(document).on('click','.kph-hr-action',function(){
        var $button=$(this),$root=$button.closest('.kph-hr'),operation=$button.attr('data-operation');
        var labels={approve:'تأیید و ثبت این مورد',clear:'ثبت وصول چک و پرداخت از حساب',prepare:'آماده‌سازی جداول حسابداری برای ثبت یکپارچه'};
        var reason='';
        if(['cancel','reject','bounce'].indexOf(operation)!==-1){reason=window.prompt('علت ابطال، رد یا برگشت:');if(!reason||!reason.trim())return;}
        else if(!window.confirm((labels[operation]||'انجام عملیات')+'؟'))return;
        request($root,{operation:operation,employee_id:$root.attr('data-employee'),record_id:$button.attr('data-record')||0,version:$button.attr('data-version')||0,reason:reason});
    });
})(jQuery);
