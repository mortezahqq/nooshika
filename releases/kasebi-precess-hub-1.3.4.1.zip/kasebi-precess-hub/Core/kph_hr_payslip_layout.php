<?php
if(!defined('ABSPATH')){exit;}

/** Print-only A5 layout. Amounts come from the saved payslip, never recalculated here. */
trait kph_hr_payslip_layout {
    private static function payslip_logo():?array{
        foreach(['kph_print_logo','kph_panel_logo'] as $option){
            $value=get_option($option);if(!is_scalar($value)||trim((string)$value)===''){continue;}
            $url=(string)$value;$paths=[];
            if(preg_match('/^\d+$/D',$url)&&function_exists('get_attached_file')){$paths[]=get_attached_file((int)$url);$url=function_exists('wp_get_attachment_url')?(string)wp_get_attachment_url((int)$url):'';}
            $uploads=function_exists('wp_upload_dir')?wp_upload_dir():[];
            if(!empty($uploads['baseurl'])&&!empty($uploads['basedir'])){
                $configured=parse_url($url);$base=parse_url($uploads['baseurl']);$path=rawurldecode($configured['path']??'');$basePath=rtrim(rawurldecode($base['path']??''),'/').'/';
                if(strtolower($configured['host']??'')===strtolower($base['host']??'')&&str_starts_with($path,$basePath)){$paths[]=rtrim($uploads['basedir'],'/').'/'.substr($path,strlen($basePath));}
            }
            foreach($paths as $path){$real=$path?realpath($path):FALSE;$root=!empty($uploads['basedir'])?realpath($uploads['basedir']):FALSE;
                if(!$real||!$root||!str_starts_with($real,$root.DIRECTORY_SEPARATOR)||!is_file($real)||filesize($real)>2097152){continue;}
                $bytes=file_get_contents($real);$logo=self::payslip_logo_bytes($bytes===FALSE?'':$bytes);if($logo){return $logo;}
            }
            // WordPress validates redirects and rejects private addresses; never pass a URL to TCPDF.
            if(function_exists('wp_safe_remote_get')&&preg_match('#^https?://#i',$url)){
                $key='kph_payslip_logo_'.hash('sha256',$url);$cached=function_exists('get_transient')?get_transient($key):FALSE;if(is_array($cached)&&isset($cached['bytes'])){$logo=self::payslip_logo_bytes($cached['bytes']);if($logo){return $logo;}}
                $response=wp_safe_remote_get($url,['timeout'=>5,'redirection'=>2,'limit_response_size'=>2097153]);
                if(!is_wp_error($response)&&wp_remote_retrieve_response_code($response)===200){$logo=self::payslip_logo_bytes(wp_remote_retrieve_body($response));if($logo){if(function_exists('set_transient')){set_transient($key,$logo,900);}return $logo;}}
            }
        }
        return NULL;
    }
    private static function payslip_logo_bytes(string $bytes):?array{
        if($bytes===''||strlen($bytes)>2097152){return NULL;}$info=@getimagesizefromstring($bytes);
        if(!$info||!in_array($info['mime']??'',['image/png','image/jpeg'],TRUE)||$info[0]>4096||$info[1]>4096){return NULL;}
        return ['bytes'=>$bytes,'mime'=>$info['mime'],'width'=>$info[0],'height'=>$info[1]];
    }
    private static function payslip(array $r,array $p,array $e):array{
        $d=$r['data'];$work=$d['work_snapshot']??[];$gross=(int)($d['gross']??$r['amount']);$payable=(int)($d['payable_amount']??$r['amount']);
        $blocks=[['type'=>'letterhead','company'=>trim((string)($e['company_name']??''))?:'فیش حقوقی پرسنل','period'=>self::month($r['period']),'reference'=>self::digits($r['id']),'status'=>in_array($r['status'],['approved','posted','cleared'],TRUE)?'':($r['status']==='draft'?'پیش‌نویس — برای بررسی و امضا':'وضعیت: '.(kph_hr::statuses()[$r['status']]??$r['status']))]];
        $identity=[
            [self::c('نام و نام خانوادگی: '.self::fill($p['person_name']??''),1,TRUE),self::c('کد پرسنلی: '.self::fill($p['person_employee_no']??''))],
            [self::c('سمت: '.self::fill($p['person_job_title']??$d['contract_snapshot']['job_title']??'')),self::c('کد ملی: '.self::fill($p['person_national_id']??''))],
            [self::c('واحد: '.self::fill($p['person_department']??'')),self::c('شماره بیمه: '.self::fill($p['person_insurance_no']??''))],
        ];$block=self::table($identity,[58,42]);$block['role']='identity';$block['row_height']=6.7;$blocks[]=$block;
        $conditions=[
            'کارکرد: '.self::quantity($d['paid_days']??0).' روز','مزد روزانه: '.self::money($d['daily_rate']??0).' ریال',
            'اضافه‌کاری: '.self::quantity($d['overtime_hours']??(($work['overtime_minutes']??0)/60)).' ساعت','شب‌کاری: '.self::quantity($d['night_hours']??0).' ساعت',
            'جمعه‌کاری: '.self::quantity($d['friday_days']??0).' روز','مأموریت: '.self::quantity($d['mission_days']??0).' روز',
            'کسرکار: '.self::quantity($d['shortage_hours']??0).' ساعت','دوره: '.self::date($r['date_from']).' تا '.self::date($r['date_to']),
        ];
        if((int)($d['benefits_version']??0)===1){$conditions[]='سنوات روزانه: '.self::money($d['seniority_daily_rate']??0).' ریال';$conditions[]='روزهای مشمول مزایا: '.self::quantity($d['benefit_days']??0);$conditions[]='غیبت: '.self::quantity($d['benefit_absence_days']??0).' روز';$conditions[]='بدون حقوق: '.self::quantity($d['benefit_unpaid_days']??0).' روز';}
        $rows=[];foreach(array_chunk($conditions,4) as $pair){$row=[];foreach($pair as $text){$row[]=self::c($text);}while(count($row)<4){$row[]=self::c('');}$rows[]=$row;}
        $block=self::table($rows,[25,25,25,25]);$block['role']='work';$block['row_height']=5.8;$blocks[]=$block;
        $benefits=['base_amount'=>'حقوق پایه','overtime_amount'=>'اضافه‌کاری','night_amount'=>'شب‌کاری','friday_amount'=>'جمعه‌کاری','mission_amount'=>'حق مأموریت','housing'=>'حق مسکن','food_allowance'=>'بن کارگری','marriage_allowance'=>'حق تأهل','child_allowance'=>'حق اولاد','seniority_base'=>'پایه سنوات','benefits'=>'سایر مزایا','bonus'=>'پاداش'];
        $deductions=['insurance'=>'بیمه سهم پرسنل','tax'=>'مالیات','paid_advance'=>'مساعده پرداخت‌شده','shortage_amount'=>'کسرکار','deductions'=>'سایر کسورات'];
        $rows=[[self::c('حقوق و مزایا — ریال',2,TRUE,'center'),self::c('کسورات و مساعده — ریال',2,TRUE,'center')]];$deductionKeys=array_keys($deductions);
        foreach(array_keys($benefits) as $i=>$key){$dk=$deductionKeys[$i]??NULL;$rows[]=[self::c($benefits[$key]),self::c(self::money($d[$key]??0),1,FALSE,'center'),self::c($dk?$deductions[$dk]:''),self::c($dk?self::money($d[$dk]??0):'',1,FALSE,'center')];}
        $rows[]=[self::c('جمع حقوق و مزایا',1,TRUE),self::c(self::money($gross),1,TRUE,'center'),self::c('جمع کسورات',1,TRUE),self::c(self::money($gross-$payable),1,TRUE,'center')];
        $block=self::table($rows,[31,19,31,19]);$block['role']='earnings';$block['row_height']=6.3;$blocks[]=$block;
        $block=self::table([[self::c('خالص قابل پرداخت — ریال',1,TRUE),self::c(self::money($payable),1,TRUE,'center')]],[62,38]);$block['role']='net';$block['row_height']=9.5;$blocks[]=$block;
        $block=self::table([[self::c('توضیحات: '.(trim((string)($d['public_notes']??''))?:'—'))]],[100]);$block['role']='notes';$block['row_height']=11;$blocks[]=$block;
        $block=self::table([[self::c("امضا و مهر کارفرما\n\n",1,FALSE,'center'),self::c("امضای پرسنل\n".self::fill($p['person_name']??'')."\n",1,FALSE,'center')]],[50,50]);$block['role']='signatures';$block['row_height']=14;$blocks[]=$block;
        return $blocks;
    }
    private static function payslip_body(array $doc,bool $pdf=FALSE):string{
        $html='';$ink='#24384b';$line='#b9c4cf';$logo=$doc['logo']??NULL;
        foreach($doc['blocks'] as $block){
            if($block['type']==='paragraph'){$html.='<p style="text-align:center;font-size:8.5pt;font-weight:bold;margin:0 0 2mm;">'.self::html_text($block['text']).'</p>';continue;}
            if($block['type']==='letterhead'){
                $image='';if($logo){$ratio=min(24/$logo['width'],16/$logo['height']);$w=round($logo['width']*$ratio,2);$h=round($logo['height']*$ratio,2);$image='<img width="'.($w*72/25.4).'" height="'.($h*72/25.4).'" style="width:'.$w.'mm;height:'.$h.'mm;" src="data:'.$logo['mime'].';base64,'.base64_encode($logo['bytes']).'" alt="لوگوی شرکت">';}
                $html.='<table width="100%" dir="rtl" cellpadding="2" cellspacing="0" style="margin-bottom:2mm;border-bottom:1.2pt solid '.$ink.';"><tr><td width="24%" align="center" style="vertical-align:middle;">'.$image.'</td><td width="52%" align="center" style="color:'.$ink.';font-size:12pt;line-height:1.5;"><b>'.self::html_text($block['company']).'</b><br><span style="font-size:10pt;">فیش حقوق و دستمزد</span></td><td width="24%" align="center" style="font-size:9pt;vertical-align:middle;"><b>'.self::html_text($block['period']).'</b><br>شماره: '.self::html_text($block['reference']).(!empty($block['status'])?'<br><span style="font-size:7.5pt;">'.self::html_text($block['status']).'</span>':'').'</td></tr></table>';continue;
            }
            $role=$block['role'];$rows=$block['rows'];$html.='<table class="payslip-table payslip-'.$role.'" dir="rtl" width="100%" cellpadding="'.($pdf?'2':'0').'" cellspacing="0" border="1" style="border-collapse:collapse;border:0.5pt solid '.$line.';margin-bottom:0.4mm;">';
            foreach($rows as $i=>$row){$col=0;$shade=($role==='net'?'#e5edf5':($role==='signatures'||$role==='notes'?'#ffffff':(($role==='work'&&$i===0)||($role==='earnings'&&($i===0||$i===count($rows)-1))?'#edf1f5':($role==='earnings'&&$i%2===0?'#f8fafb':'#ffffff'))));$html.='<tr>';
                foreach($row as $cell){$width=array_sum(array_slice($block['widths'],$col,$cell['span']));$col+=$cell['span'];$size=$role==='net'?11:($role==='work'?8.5:9);if($role==='earnings'&&$cell['align']==='center'&&mb_strlen($cell['text'])>14){$size=7.8;}
                    $html.='<td width="'.$width.'%" colspan="'.$cell['span'].'" height="'.$block['row_height'].'mm" align="'.$cell['align'].'" bgcolor="'.$shade.'" style="height:'.$block['row_height'].'mm;padding:0.65mm 1.4mm;vertical-align:middle;border:0.5pt solid '.$line.';background-color:'.$shade.';color:'.$ink.';font-size:'.$size.'pt;line-height:1.4;'.($cell['bold']?'font-weight:bold;':'').'">'.self::html_text($cell['text']).'</td>';}
                $html.='</tr>';
            }
            $html.='</table>'.($pdf?'<div style="font-size:2pt;line-height:2pt;"> </div>':'');
        }
        return $html;
    }
    private static function payslip_html(array $doc):string{
        $font=__DIR__.'/../assets/fonts/payslip/';$regular=base64_encode(file_get_contents($font.'Vazirmatn-Regular.ttf'));$bold=base64_encode(file_get_contents($font.'Vazirmatn-Bold.ttf'));
        return '<!doctype html><html lang="fa" dir="rtl"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'.htmlspecialchars($doc['title'],ENT_QUOTES,'UTF-8').'</title><style>@font-face{font-family:KphPayslip;src:url(data:font/ttf;base64,'.$regular.') format("truetype");font-weight:400}@font-face{font-family:KphPayslip;src:url(data:font/ttf;base64,'.$bold.') format("truetype");font-weight:700}@page{size:A5 portrait;margin:8mm}*{box-sizing:border-box}body{font-family:KphPayslip,Tahoma,sans-serif;direction:rtl;color:#24384b;margin:0 auto;padding:8mm;width:148mm;background:white;font-size:9pt;line-height:1.4}table{width:100%;border-collapse:collapse;table-layout:fixed}td{overflow-wrap:anywhere}tr{break-inside:avoid}.print-controls{display:flex;gap:12px;margin-bottom:5mm;font-family:KphPayslip,Tahoma,sans-serif}.print-controls a,.print-controls button{font:inherit;padding:7px 10px}.payslip-notes td{white-space:normal}@media print{html,body{width:auto;margin:0;padding:0}.print-controls{display:none}table,td{-webkit-print-color-adjust:exact;print-color-adjust:exact}}</style></head><body>'.self::payslip_body($doc).'</body></html>';
    }
    private static function payslip_pdf(array $doc):string{
        if(!class_exists('TCPDF')){require_once __DIR__.'/../vendor/tcpdf/tcpdf.php';}
        if(!empty($doc['logo'])&&$doc['logo']['mime']==='image/png'&&in_array(ord($doc['logo']['bytes'][25]??"\0"),[4,6],TRUE)&&!function_exists('imagecreatefrompng')&&!class_exists('Imagick')){$opaque=self::payslip_opaque_png($doc['logo']['bytes']);if($opaque!==NULL){$doc['logo']['bytes']=$opaque;}else{$doc['logo']=NULL;}}
        $pdf=new TCPDF('P','mm','A5',TRUE,'UTF-8',FALSE);$pdf->setPrintHeader(FALSE);$pdf->setPrintFooter(FALSE);$pdf->SetCreator('Kasebi Process Hub');$pdf->SetTitle($doc['title']);$pdf->SetMargins(8,8,8);$pdf->SetAutoPageBreak(TRUE,8);$pdf->setRTL(TRUE);
        $fonts=__DIR__.'/../vendor/tcpdf/fonts/payslip/';$pdf->AddFont('vazirmatn','',$fonts.'vazirmatn.php',TRUE);$pdf->AddFont('vazirmatn','B',$fonts.'vazirmatnb.php',TRUE);$pdf->SetFont('vazirmatn','',9);$pdf->setCellHeightRatio(1.4);$pdf->SetDrawColor(185,196,207);$pdf->AddPage();
        $pdf->writeHTML(self::payslip_body($doc,TRUE),TRUE,FALSE,TRUE,FALSE,'');return $pdf->Output('hr-payslip-'.$doc['record_id'].'.pdf','S');
    }
    private static function payslip_word_header(array $block,?array $logo,int $width,callable $paragraph):string{
        $drawing='';if($logo){$scale=min(24/$logo['width'],16/$logo['height']);$cx=(int)round($logo['width']*$scale*36000);$cy=(int)round($logo['height']*$scale*36000);
            $drawing='<w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:drawing><wp:inline xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" distT="0" distB="0" distL="0" distR="0"><wp:extent cx="'.$cx.'" cy="'.$cy.'"/><wp:docPr id="1" name="Company logo"/><a:graphic xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:pic xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:nvPicPr><pic:cNvPr id="0" name="Company logo"/><pic:cNvPicPr/></pic:nvPicPr><pic:blipFill><a:blip xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" r:embed="rIdCompanyLogo"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill><pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="'.$cx.'" cy="'.$cy.'"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>';}
        $contents=[$drawing,$paragraph($block['company'],'center',TRUE).$paragraph($block['caption']??'فیش حقوق و دستمزد','center',TRUE),$paragraph($block['period'],'center',TRUE).$paragraph('شماره: '.$block['reference'],'center').(!empty($block['status'])?$paragraph($block['status'],'center',TRUE):'')];$html='<w:tbl><w:tblPr><w:bidiVisual/><w:tblW w:w="'.$width.'" w:type="dxa"/><w:tblLayout w:type="fixed"/></w:tblPr><w:tblGrid>';foreach([24,52,24] as $size){$html.='<w:gridCol w:w="'.(int)round($width*$size/100).'"/>';}$html.='</w:tblGrid><w:tr>';
        foreach($contents as $i=>$content){$size=[24,52,24][$i];$html.='<w:tc><w:tcPr><w:tcW w:w="'.(int)round($width*$size/100).'" w:type="dxa"/><w:vAlign w:val="center"/></w:tcPr>'.($content?:$paragraph('')).'</w:tc>';}
        return $html.'</w:tr></w:tbl><w:p><w:pPr><w:spacing w:before="0" w:after="0" w:line="40" w:lineRule="exact"/></w:pPr></w:p>';
    }
    private static function payslip_word_fonts(array $files):array{
        $fontXml='';$rels='';$ns='http://schemas.openxmlformats.org/officeDocument/2006/relationships';
        foreach(['Regular'=>'D1D019D5-6DA5-4E92-AAD8-748D80708AA1','Bold'=>'A1B37CCC-B026-4A56-B8B9-E1668892135A'] as $style=>$guid){
            $bytes=file_get_contents(__DIR__.'/../assets/fonts/payslip/Vazirmatn-'.$style.'.ttf');$key=strrev(hex2bin(str_replace('-','',$guid)));
            for($i=0;$i<32;$i++){$bytes[$i]=chr(ord($bytes[$i])^ord($key[$i%16]));}
            $filename='fonts/Vazirmatn-'.$style.'.odttf';$files['word/'.$filename]=$bytes;$fontXml.='<w:embed'.$style.' r:id="rId'.$style.'" w:fontKey="{'.$guid.'}" w:subsetted="false"/>';
            $rels.='<Relationship Id="rId'.$style.'" Type="'.$ns.'/font" Target="'.$filename.'"/>';
        }
        $files['word/fontTable.xml']='<?xml version="1.0" encoding="UTF-8"?><w:fonts xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="'.$ns.'"><w:font w:name="Vazirmatn"><w:family w:val="swiss"/><w:pitch w:val="variable"/>'.$fontXml.'</w:font></w:fonts>';
        $files['word/_rels/fontTable.xml.rels']='<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'.$rels.'</Relationships>';
        $files['word/settings.xml']='<?xml version="1.0" encoding="UTF-8"?><w:settings xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:embedTrueTypeFonts/><w:saveSubsetFonts/></w:settings>';
        $files['word/_rels/document.xml.rels']=str_replace('</Relationships>','<Relationship Id="rIdFontTable" Type="'.$ns.'/fontTable" Target="fontTable.xml"/><Relationship Id="rIdSettings" Type="'.$ns.'/settings" Target="settings.xml"/></Relationships>',$files['word/_rels/document.xml.rels']);
        $files['[Content_Types].xml']=str_replace('</Types>','<Default Extension="odttf" ContentType="application/vnd.openxmlformats-officedocument.obfuscatedFont"/><Override PartName="/word/fontTable.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.fontTable+xml"/><Override PartName="/word/settings.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.settings+xml"/></Types>',$files['[Content_Types].xml']);
        return $files;
    }
    /** Flatten common 8-bit PNG alpha onto white on servers without GD/Imagick. */
    private static function payslip_opaque_png(string $png):?string{
        if(!function_exists('gzuncompress')||!function_exists('gzcompress')||substr($png,0,8)!=="\x89PNG\r\n\x1a\n"||strlen($png)<33){return NULL;}
        $width=unpack('N',substr($png,16,4))[1];$height=unpack('N',substr($png,20,4))[1];$type=ord($png[25]);
        if(!in_array($type,[4,6],TRUE)||ord($png[24])!==8||ord($png[28])!==0||$width*$height>4000000){return NULL;}$channels=$type===6?4:2;$stride=$width*$channels;$idat='';$at=8;
        while($at+12<=strlen($png)){$length=unpack('N',substr($png,$at,4))[1];if($length>strlen($png)-$at-12){return NULL;}$kind=substr($png,$at+4,4);if($kind==='IDAT'){$idat.=substr($png,$at+8,$length);}$at+=$length+12;if($kind==='IEND'){break;}}
        $expected=($stride+1)*$height;$raw=@gzuncompress($idat,$expected);if($raw===FALSE||strlen($raw)!==$expected){return NULL;}$previous=str_repeat("\0",$stride);$rgb='';$at=0;
        for($y=0;$y<$height;$y++){$filter=ord($raw[$at++]);if($filter>4){return NULL;}$row=substr($raw,$at,$stride);$at+=$stride;
            for($x=0;$x<$stride;$x++){$left=$x>=$channels?ord($row[$x-$channels]):0;$up=ord($previous[$x]);$corner=$x>=$channels?ord($previous[$x-$channels]):0;$predict=0;
                if($filter===1){$predict=$left;}elseif($filter===2){$predict=$up;}elseif($filter===3){$predict=intdiv($left+$up,2);}elseif($filter===4){$p=$left+$up-$corner;$a=abs($p-$left);$b=abs($p-$up);$c=abs($p-$corner);$predict=$a<=$b&&$a<=$c?$left:($b<=$c?$up:$corner);}
                $row[$x]=chr((ord($row[$x])+$predict)&255);
            }
            $rgb.="\0";for($x=0;$x<$stride;$x+=$channels){$alpha=ord($row[$x+$channels-1]);for($c=0;$c<3;$c++){$component=ord($row[$x+($channels===2?0:$c)]);$rgb.=chr((int)round(($component*$alpha+255*(255-$alpha))/255));}}$previous=$row;
        }
        $chunk=static fn($name,$bytes)=>pack('N',strlen($bytes)).$name.$bytes.pack('N',hexdec(hash('crc32b',$name.$bytes)));
        return "\x89PNG\r\n\x1a\n".$chunk('IHDR',pack('NNCCCCC',$width,$height,8,2,0,0,0)).$chunk('IDAT',gzcompress($rgb,6)).$chunk('IEND','');
    }

}
