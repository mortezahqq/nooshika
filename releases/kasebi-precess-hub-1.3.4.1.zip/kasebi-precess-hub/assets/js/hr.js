(function($){
    'use strict';
    function endpoint(){return window.ajax_url||'/wp-admin/admin-ajax.php';}
    function send($root,data){
        var form=data instanceof FormData;
        if(form){data.set('action','kph_hr_action');data.set('nonce',$root.attr('data-nonce'));}
        else {data.action='kph_hr_action';data.nonce=$root.attr('data-nonce');}
        return $.ajax({url:endpoint(),method:'POST',data:data,processData:!form,contentType:form?false:'application/x-www-form-urlencoded; charset=UTF-8',global:false});
    }
    function busy($root,value){$root.data('hrBusy',value);$root.find('button').prop('disabled',value);}
    function message($root,text,error){$root.find('.kph-hr-message').text(text).removeClass('d-none alert-danger alert-success text-danger text-success').addClass(error?'alert-danger':'alert-success');}
    function failure(xhr){return xhr.responseJSON&&xhr.responseJSON.message||'ارتباط برقرار نشد؛ صفحه را تازه و وضعیت ثبت را بررسی کنید.';}
    function request($root,data){
        if($root.data('hrBusy'))return;busy($root,true);message($root,'در حال ثبت…');
        send($root,data).done(function(res){
            if(res.status==='success'){message($root,res.message);if(res.url){window.location.assign(res.url);}else{window.location.reload();}}
            else{message($root,res.message||'ثبت انجام نشد.',true);}
        }).fail(function(xhr){message($root,failure(xhr),true);}).always(function(){busy($root,false);});
    }
    $(document).on('submit','form.kph-hr-form',function(e){e.preventDefault();request($(this).closest('.kph-hr'),new FormData(this));});
    $(document).on('click','.kph-hr-action',function(e){e.preventDefault();
        var $button=$(this),$root=$button.closest('.kph-hr'),operation=$button.attr('data-operation');
        var labels={approve:'تأیید این مورد با اثر مالی توضیح‌داده‌شده در فرم',clear:'ثبت وصول چک و پرداخت از حساب',prepare:'آماده‌سازی جداول حسابداری برای ثبت یکپارچه'},reason='';
        if(['cancel','reject','bounce'].indexOf(operation)!==-1){reason=window.prompt('علت ابطال، رد یا برگشت:');if(!reason||!reason.trim())return;}
        else if(!window.confirm((labels[operation]||'انجام عملیات')+'؟'))return;
        request($root,{operation:operation,employee_id:$root.attr('data-employee'),record_id:$button.attr('data-record')||0,version:$button.attr('data-version')||0,reason:reason});
    });
    $(document).on('click','.kph-hr-delete-file',function(e){e.preventDefault();
        if(!window.confirm('این فایل از پرونده حذف شود؟'))return;
        var $b=$(this),$r=$b.closest('.kph-hr');request($r,{operation:'delete_document',employee_id:$r.attr('data-employee'),file_id:$b.attr('data-file'),file_version:$b.attr('data-version')});
    });
    $(document).on('change','.kph-hr-doc-upload input,.kph-hr-doc-upload select',function(){
        var $form=$(this).closest('form');$form.removeData('uploadQueue').removeData('uploadIndex');
        if(this.name==='record_id'){var period=$(this).find(':selected').attr('data-period');if(period)$form.find('[name=period]').val(period);}
    });
    $(document).on('submit','form.kph-hr-doc-upload',function(e){
        e.preventDefault();var $form=$(this),$root=$form.closest('.kph-hr'),$progress=$form.find('.kph-hr-upload-progress');
        if($root.data('hrBusy'))return;
        var queue=$form.data('uploadQueue');
        if(!queue){queue=[];$form.find('[data-hr-upload]').each(function(){var subtype=$(this).attr('data-hr-upload');Array.from(this.files||[]).forEach(function(file){queue.push({file:file,subtype:subtype});});});$form.data('uploadQueue',queue).data('uploadIndex',0);}
        if(!queue.length){$progress.text('ابتدا فایل موردنظر را انتخاب کنید.').addClass('text-danger');return;}
        if(queue.some(function(item){return item.file.size>5*1024*1024;})){$progress.text('حجم هر فایل باید حداکثر ۵ مگابایت باشد.').addClass('text-danger');return;}
        busy($root,true);$progress.removeClass('text-danger');
        function next(){
            var i=$form.data('uploadIndex')||0;
            if(i>=queue.length){$progress.text('همهٔ فایل‌ها ذخیره شدند.');busy($root,false);window.location.reload();return;}
            var item=queue[i],data=new FormData();
            $form.serializeArray().forEach(function(field){data.set(field.name,field.value);});data.set('operation','upload_document');data.set('subtype',item.subtype);data.set('file',item.file);
            $progress.text('بارگذاری '+(i+1)+' از '+queue.length+' — '+item.file.name);
            send($root,data).done(function(res){if(res.status==='success'){$form.data('uploadIndex',i+1);next();}else{stop(res.message||'فایل ذخیره نشد.');}}).fail(function(xhr){stop(failure(xhr));});
        }
        function stop(text){busy($root,false);$progress.text(text+' فایل‌های قبلی ذخیره شده‌اند؛ با همین انتخاب‌ها دوباره بارگذاری را بزنید تا ادامه داده شود.').addClass('text-danger');}
        next();
    });
    function number(value){var s=String(value||'').replace(/[۰-۹]/g,function(c){return '۰۱۲۳۴۵۶۷۸۹'.indexOf(c);}).replace(/[٠-٩]/g,function(c){return '٠١٢٣٤٥٦٧٨٩'.indexOf(c);}).replace(/[,٬\s]/g,'');return Number(s)||0;}
    function field($f,key){return $f.find('[name="'+key+'"]');}
    function benefitPreview($f){
        if(field($f,'benefits_version').val()!=='1')return null;
        var c=$f.data('contract')||{},contract=field($f,'calculation_mode').val()==='contract',work=$f.data('benefitWork')||{},monthDays=Number($f.data('periodDays')||$f.attr('data-period-days'))||30;
        var days=Math.round(Math.max(0,Math.min(number(field($f,'paid_days').val()),monthDays-number(work.absence_days)-number(work.unpaid_minutes)/480))*1000000)/1000000;
        if(contract){field($f,'housing').val(c.housing===undefined?30000000:c.housing);field($f,'food_allowance').val(c.food_allowance===undefined?22000000:c.food_allowance);field($f,'seniority_daily_rate').val(c.seniority_daily_rate===undefined?Math.round(number(c.seniority_base)/Math.max(1,number(c.normal_days)||30)*10000)/10000:c.seniority_daily_rate);}
        var result={days:days,housing:Math.round(number(field($f,'housing').val())*Math.min(1,days/30)),food_allowance:Math.round(number(field($f,'food_allowance').val())*Math.min(1,days/30)),seniority_base:Math.round(number(field($f,'seniority_daily_rate').val())*days)};
        field($f,'seniority_base').val(result.seniority_base).prop('readOnly',true);
        $f.find('[data-benefit-total]').each(function(){var key=$(this).attr('data-benefit-total'),value=key==='food'?result.food_allowance:(key==='seniority'?result.seniority_base:result[key]);$(this).text(value.toLocaleString('fa-IR'));});
        return result;
    }
    function preview($f){
        if($f.attr('data-kind')!=='payslip')return;
        function n(key){return number(field($f,key).val());}
        var c=$f.data('contract')||{},mode=field($f,'calculation_mode').val(),basis=mode==='contract'?c.basis:'monthly',rate=n('monthly_base');
        var base=Math.round(basis==='hourly'?rate*n('worked_hours'):(basis==='daily'?rate*n('paid_days'):rate*n('paid_days')/Math.max(1,n('normal_days'))));
        var computedBenefits=benefitPreview($f),gross=base;
        ['housing','food_allowance','marriage_allowance','child_allowance','seniority_base','benefits','bonus'].forEach(function(key){gross+=computedBenefits&&Object.prototype.hasOwnProperty.call(computedBenefits,key)?computedBenefits[key]:n(key);});
        ['overtime','night','friday','mission'].forEach(function(key){gross+=Math.round(n(key+'_rate')*n(key+(['friday','mission'].indexOf(key)>=0?'_days':'_hours')));});
        var deductions=n('insurance')+n('tax')+n('deductions')+n('paid_advance')+Math.round(n('shortage_rate')*n('shortage_hours'));
        var totals={base:base,gross:gross,deductions:deductions,payable:gross-deductions};
        $f.find('[data-pay-total]').each(function(){var value=totals[$(this).attr('data-pay-total')];$(this).text(value.toLocaleString('fa-IR')).toggleClass('text-danger',value<0);});
        $f.find('.kph-hr-pay-preview').attr('data-estimate',field($f,'work_source').val()==='attendance'?'attendance':'manual');
    }
    function contractMode($f,copy){
        var mode=field($f,'calculation_mode').val();$f.find('.kph-hr-contract-field').toggle(mode==='contract');
        var c={};try{c=JSON.parse($f.find('.kph-hr-contract-picker :selected').attr('data-contract')||'{}');}catch(e){}
        $f.data('contract',c);
        ['monthly_base','normal_days','overtime_rate','housing','food_allowance','seniority_daily_rate'].forEach(function(key){field($f,key).prop('readOnly',mode==='contract');});
        if(copy&&mode==='contract'&&c.rate){field($f,'monthly_base').val(c.rate);field($f,'normal_days').val(c.normal_days||30);field($f,'overtime_rate').val(c.overtime_rate||0);['housing','food_allowance','marriage_allowance','child_allowance','seniority_base'].forEach(function(key){field($f,key).val(c[key]||0);});Object.keys(c.employer||{}).forEach(function(key){field($f,key).val(c.employer[key]);});}
        preview($f);
    }
    function period($f){
        var $root=$f.closest('.kph-hr'),year=field($f,'salary_year').val(),month=field($f,'salary_month').val();
        var serial=($f.data('periodRequest')||0)+1;$f.data('periodRequest',serial);
        send($root,{operation:'period',employee_id:$root.attr('data-employee'),salary_year:year,salary_month:month,benefits_version:field($f,'benefits_version').val()||''}).done(function(res){
            if(serial!==$f.data('periodRequest'))return;
            if(res.status==='success'){var p=res.period;$f.data('periodDays',p.days);if(p.benefit_work)$f.data('benefitWork',p.benefit_work);$f.find('.kph-hr-period-hint').text('بازهٔ فیش: '+p.label+'؛ '+p.days+' روز تقویمی.');if(!$f.data('paidDaysEdited')){var lost=p.benefit_work?number(p.benefit_work.absence_days)+number(p.benefit_work.unpaid_minutes)/480:0;field($f,'paid_days').val(Math.round(Math.max(0,p.days-lost)*10000)/10000);}field($f,'paid_days').attr('max',p.days);if(field($f,'work_source').val()==='attendance'&&p.work){field($f,'worked_hours').val(p.work.worked_minutes/60);field($f,'overtime_hours').val(p.work.overtime_minutes/60);}preview($f);}else{$f.find('.kph-hr-period-hint').text(res.message||'ماه را بررسی کنید.');}
        });
    }
    function workMode($f){['worked_hours','overtime_hours'].forEach(function(key){field($f,key).prop('readOnly',field($f,'work_source').val()==='attendance');});}
    $(document).on('change','.kph-hr-document-category',function(){var value=this.value;$(this).closest('.modal').find('[data-hr-document-category]').each(function(){$(this).toggleClass('d-none',$(this).attr('data-hr-document-category')!==value);});});
    function init(){
        $('.kph-hr .modal[data-hr-open="1"]').each(function(){var element=this;if(window.bootstrap&&window.bootstrap.Modal){window.bootstrap.Modal.getOrCreateInstance(element).show();}else if($.fn.modal){$(element).modal('show');}else{return;}$(element).removeAttr('data-hr-open');});
        $('.kph-hr-advanced').each(function(){var $f=$(this);if($f.data('hrInitialized'))return;$f.data('hrInitialized',true);$f.data('paidDaysEdited',number(field($f,'record_id').val())>0);try{$f.data('benefitWork',JSON.parse($f.attr('data-benefit-work')||'{}'));}catch(e){}contractMode($f,false);workMode($f);if(field($f,'benefits_version').val()==='1')period($f);$f.data('initialDeclaration',field($f,'declaration_text').val());});
    }
    $(document).on('focusin','.kph-hr-advanced',init);
    $(document).on('input change','.kph-hr-advanced input,.kph-hr-advanced select',function(){
        var $f=$(this).closest('form');init();
        if(this.name==='paid_days')$f.data('paidDaysEdited',true);
        if(this.name==='contract_id'||this.name==='calculation_mode')contractMode($f,true);
        if(this.name==='salary_year'||this.name==='salary_month'||this.name==='work_source'){workMode($f);period($f);}
        if(this.name==='template'&&!number(field($f,'record_id').val())){var $decl=field($f,'declaration_text');if($decl.val()===$f.data('initialDeclaration')){var declarations={};try{declarations=JSON.parse($f.attr('data-declarations'));}catch(e){}$decl.val(declarations[this.value]||'');$f.data('initialDeclaration',$decl.val());}}
        preview($f);
    });
    $(init);$(document).on('kph-preparation-refresh',init);
})(jQuery);
