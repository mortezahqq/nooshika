<?php
if(!defined('ABSPATH')){exit;}
function kph_freight_allowed(bool $write=FALSE):bool{
    return is_user_logged_in()&&(current_user_can('manage_options')||in_array(nooshika_get_user_role(get_current_user_id()),$write?['accountant']:['accountant','supp'],TRUE));
}
add_action('wp_print_scripts',function(){
    if(wp_script_is('kasebi_clinic_script','enqueued')&&kph_freight_allowed()){
        wp_enqueue_script('kph-customer-freight',KPH_ASSETS_URL.'js/customer-freight.js',['kasebi_clinic_script'],KPH_VER,TRUE);
    }
},20);
add_action('wp_ajax_kph_freight_action',function(){
    if(!kph_freight_allowed(TRUE)||!wp_verify_nonce($_POST['nonce']??'','kph_customer_freight')){
        wp_send_json(['status'=>'error','message'=>'اجازه دسترسی یا اعتبار فرم کافی نیست.'],403);
    }
    $input=wp_unslash($_POST);$db=new kph_db();$op=$input['operation']??'';
    if($op==='prepare'){$result=$db->prepare_customer_freight();}
    elseif($op==='cancel'){$result=$db->cancel_customer_freight(absint($input['record_id']??0),absint($input['version']??0),is_string($input['reason']??NULL)?$input['reason']:'');}
    else{$result=['status'=>'error','message'=>'عملیات معتبر نیست.'];}
    wp_send_json($result);
});
