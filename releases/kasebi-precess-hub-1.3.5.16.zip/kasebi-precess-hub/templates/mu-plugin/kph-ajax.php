<?php

/*
Plugin Name: KPH Ajax
Plugin URI: http://kasebi.co
Description: new route for ajax
Version: 1.0
Author: ahmad_gch
Author URI: http://kasebi.co
License: GPL2
*/
if ( ! defined( 'ABSPATH' ) ) {
	die( 'really?' );
}

const KPH_AJAX_URI = 'kph-ajax';
add_action( 'admin_menu', function() {
	add_submenu_page(
		'nooshika_plugin',
		'تنظیمات KPH Ajax',
		'تنظیمات KPH Ajax',
		'administrator',
		'kph_ajax',
		'kph_ajax_setting_page_template'
	);
}, 20 );

function kph_ajax_setting_page_template() {
	nooshika_load_settings_style();
	$msg = '';
	if ( isset( $_POST['submit_ajax_settings'] ) && $_POST['submit_ajax_settings'] == 'submit' ) {
		update_option( 'kph_ajax_active_plugins', $_POST['ajax_active'] );
		$msg = 'تنظیمات ذخیره شد';
	}
	$ajax_plugins   = get_option( 'kph_ajax_active_plugins' );
	$active_plugins = (array) get_option( 'active_plugins', [] );
	?>
    <form action="#" method="post" id="nooshika_settings_form">
        <section class="settings_section usof-container">
            <div class="usof-section">
                <div class="settings_section_title">
                    <h2>تنظیمات ajax</h2>
                    <button type="submit" class="nooshika_submit_btn" value="submit" name="submit_ajax_settings">ذخیره
                    </button>
                </div>
				<?php
				if ( $msg ) {
					echo "<div class='notice notice-success is-dismissible'><p>$msg</p></div>";
				}
				?>
                <div class="settings_form_container">
					<?php
					foreach ( $active_plugins as $active_plugin ) {
						$plugin_data = get_plugin_data( WP_PLUGIN_DIR . '/' . $active_plugin );
						$plugin_name = $plugin_data['Name'];
						?>
                        <div class="type_switch desc_1 " style="display:block;">
                            <div class="usof-form-row-field">
                                <div class="usof-form-row-control">
                                    <div class="usof-switcher">
                                        <label>
                                            <input type="checkbox" name="ajax_active[]"
                                                   value="<?php echo $active_plugin ?>"
												<?php checked( in_array( $active_plugin, $ajax_plugins ) ); ?>
                                                   id="<?php echo $active_plugin ?>">
                                            <span class="usof-switcher-box"><i></i></span>
                                            <span class="usof-switcher-text"><?php echo $plugin_name ?></span>
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
						<?php
					}
					?>
                </div>
            </div>
        </section>
    </form>
	<?php
}

add_action( 'wp_loaded', function() {
	add_rewrite_endpoint( KPH_AJAX_URI, EP_ALL );
	flush_rewrite_rules();
	$page = kph_get_current_page_basename();
	if ( $page != KPH_AJAX_URI ) {
		return;
	}
	$no_action = [
		'result' => 'error',
		'msg'    => 'invalid action request',
	];
	$action    = ( isset( $_REQUEST['action'] ) ) ? $_REQUEST['action'] : '';
	if ( ! has_action( "nooshika_ajax_$action" ) ) {
		wp_send_json( $no_action );
	}
	do_action( "nooshika_ajax_$action" );
	wp_die( '0' );
}, 99 );

add_action( 'template_redirect', function() {
	$page = kph_get_current_page_basename();
	if ( ! $page ) {
		return;
	}
	if ( ! in_array( $page, kph_get_page_list() ) ) {
		return;
	}
	remove_action( 'wp_footer', 'add_kasebi_footer_options' );
} );

add_filter( 'option_active_plugins', function( $active_plugins ) {
	$page = kph_get_current_page_basename();
	if ( $page != KPH_AJAX_URI ) {
		return $active_plugins;
	}
	$ajax_plugins = get_option( 'kph_ajax_active_plugins' );
	foreach ( $active_plugins as $key => $active_plugin ) {
		if ( ! in_array( $active_plugin, $ajax_plugins ) ) {
			unset( $active_plugins[ $key ] );
		}
	}
	
	return $active_plugins;
} );

add_filter( 'option_active_plugins', function( $active_plugins ) {
	$page = kph_get_current_page_basename();
	if ( ! $page ) {
		return $active_plugins;
	}
	if ( ! in_array( $page, kph_get_page_list() ) ) {
		return $active_plugins;
	}
	$ajax_plugins = get_option( 'kph_ajax_active_plugins' );
	foreach ( $active_plugins as $key => $active_plugin ) {
		if ( ! ( in_array( $active_plugin, $ajax_plugins ) || $active_plugin == 'us-core/us-core.php' ) ) {
			unset( $active_plugins[ $key ] );
		}
	}
	remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
	remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
	remove_action( 'wp_print_styles', 'print_emoji_styles' );
	remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
	remove_action( 'admin_print_styles', 'print_emoji_styles' );
	remove_filter( 'comment_text_rss', 'wp_staticize_emoji' );
	remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );
	add_filter( 'tiny_mce_plugins', 'disable_emojis_tinymce' );
	
	return $active_plugins;
} );
add_filter( 'option_us_theme_options_css', function( $css ) {
	$page = kph_get_current_page_basename();
	if ( ! $page ) {
		return $css;
	}
	if ( ! in_array( $page, kph_get_page_list() ) ) {
		return $css;
	}
	
	return '    ';
} );
add_filter( 'usof_get_option_back_to_top', function( $css ) {
	$page = kph_get_current_page_basename();
	if ( ! $page ) {
		return $css;
	}
	if ( ! in_array( $page, kph_get_page_list() ) ) {
		return $css;
	}
	
	return 0;
} );
add_filter( 'wp_get_custom_css', function( $css ) {
	$page = kph_get_current_page_basename();
	if ( ! $page ) {
		return $css;
	}
	if ( ! in_array( $page, kph_get_page_list() ) ) {
		return $css;
	}
	
	return '    ';
} );
function kph_get_page_list(): array {
	return [
		'crm',
		'crm-login',
		'crm-password',
	];
}

function kph_get_current_page_basename() {
	$home    = get_home_url();
	$request = str_replace( $home, '', $_SERVER['SCRIPT_URI'] );
	$items   = explode( '/', $request );
	$items   = array_values( array_filter( $items ) );
	if ( ! isset( $items[0] ) ) {
		return '';
	}
	
	return $items[0];
}