<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
/**
 * @var $user_id
 */

$DB         = new kph_db();
$user_color = get_user_meta( $user_id, 'user_color', TRUE ) ?: 'primary';
$first_name = get_user_meta( $user_id, 'first_name', TRUE );
$last_name  = get_user_meta( $user_id, 'last_name', TRUE );
$phone      = get_user_meta( $user_id, 'nooshika_phone_num', TRUE );
$phone      = $phone ? '0' . $phone : '';
$registered = get_the_author_meta( 'registered', $user_id );
$registered = date_i18n( 'j M Y, H:i', strtotime( $registered ) + 12600 );
$can_account = !kph_support_accounting_restricted();
$balance = $can_account ? $DB->get_ledger_balance_now($user_id) : ['balance'=>0];
$class      = '';
$icon       = '';
$balance    = $balance['balance'];
if ( $balance != 0 ) {
	$icon  = $balance < 0 ? 'ni-arrow-long-up' : 'ni-arrow-long-down';
	$class = $balance < 0 ? ' text-success' : ' text-danger';
}
$notif_metas = [
	'customer_sms_notif' => [
		'icon'  => 'chat-fill',
		'label' => 'اطلاع رسانی پیامکی',
	],
];
?>
<div class="card-inner">
    <div class="user-card user-card-s2">
        <div class="user-avatar fs-38px lg bg-<?php echo $user_color; ?>">
            <i class="uik-r fa-smile"></i>
        </div>
        <div class="user-info">
            <h5><?php echo $first_name . ' ' . $last_name; ?></h5>
            <span class="sub-text"><?php echo $phone; ?></span>
        </div>
    </div>
</div>
<div class="card-inner card-inner-sm">
    <ul class="btn-toolbar justify-center gx-1">
        <li>
            <a class="btn btn-icon icon bg-success-dim page_activator"
               data-bs-toggle="tooltip" data-url="/crm/order-customer?c_id=<?php echo $user_id; ?>"
               data-bs-placement="top" title="افزودن سفارش">
                <em class="icon ni ni-plus-medi"></em>
            </a>
        </li>
        <?php if ($can_account) { ?>
        <li>
            <div data-bs-toggle="modal" class="select_current_user_for_modal" data-id="<?php echo $user_id; ?>"
                 data-input="#new_payment_customer_id"
                 data-bs-target="#addUserPayments">
                <a class="btn btn-icon icon bg-purple-dim "
                   data-bs-toggle="tooltip"
                   data-bs-placement="top" title="افزودن پرداختی">
                    <em class="icon ni ni-cc-alt2"></em>
                </a>
            </div>
        </li>
        <li>
            <div data-bs-toggle="modal" class="select_current_user_for_modal" data-id="<?php echo $user_id; ?>"
                 data-input="#new_cheque_customer_id"
                 data-bs-target="#addCheque">
                <a class="btn btn-icon icon bg-indigo-dim "
                   data-bs-toggle="tooltip"
                   data-bs-placement="top" title="ثبت چک">
                    <em class="icon ni ni-activity-round"></em>
                </a>
            </div>
        </li>
        <li>
            <div data-bs-toggle="modal" class="select_current_user_for_modal" data-id="<?php echo $user_id; ?>"
                 data-input="#new_transfer_customer_id"
                 data-bs-target="#addUserTransfer">
                <a class="btn btn-icon icon bg-orange-dim "
                   data-bs-toggle="tooltip"
                   data-bs-placement="top" title="ثبت حواله">
                    <em class="icon ni ni-tranx"></em>
                </a>
            </div>
        </li>
        <li>
            <a class="btn btn-icon icon bg-success-dim login_as_this" data-id="<?php echo $user_id; ?>"
               data-bs-toggle="tooltip"
               data-bs-placement="top" title="ورود به پنل کاربر">
                <em class="icon ni ni-signin"></em>
            </a>
        </li>
        <?php } ?>
        <li>
            <a class="btn btn-icon icon bg-pink-dim delete_user" data-user-id="<?php echo $user_id; ?>"
               data-bs-toggle="tooltip" data-page="/crm/users"
               data-bs-placement="top" title="حذف کاربر">
                <em class="icon ni ni-na"></em>
            </a>
        </li>
    </ul>
</div>
<div class="card-inner">
    <div class="row text-center">
        <div class="col-6">
            <div class="profile-stats">
                <span class="amount">0</span>
                <span class="sub-text">مجموع سفارشات</span>
            </div>
        </div>
        <?php if ($can_account) { ?>
        <div class="col-6">
            <div class="profile-stats">
                <div class="amount<?php echo $class; ?>">
                    <div class="">
                        <span><?php echo number_format( abs( $balance ) ); ?></span>
						<?php
						if ( $icon ) {
							echo "<em class='icon ni $icon'></em>";
						}
						?>
                    </div>
                </div>
                <span class="sub-text">باقیمانده حسابداری</span>
            </div>
        </div>
        <?php } ?>
    </div>
</div>
<div class="card-inner">
    <div class="row g-3">
        <div class="col-12">
            <ul class="chat-profile-settings">
				<?php
				foreach ( $notif_metas as $notif_meta => $notif_data ) {
					$status  = get_user_meta( $user_id, $notif_meta, TRUE ) ?: 'send';
					$checked = $status == 'send' ? 'checked' : '';
					?>
                    <li class="d-block">
                        <div class="custom-control custom-control-sm custom-switch <?php echo $checked; ?>">
                            <input type="checkbox" class="custom-control-input change_user_notif_meta"
                                   data-for="<?php echo $notif_meta; ?>"<?php echo $checked; ?>
                                   id="<?php echo $notif_meta; ?>" value="send" data-not="dont-send">
                            <label class="custom-control-label" for="<?php echo $notif_meta; ?>">
                                <span><?php echo $notif_data['label']; ?></span>
                            </label>
                        </div>
                    </li>
					<?php
				}
				?>
            </ul>
        </div>
    </div>
</div>
<div class="card-inner">
    <div class="row g-3">
        <div class="col-6">
            <span class="sub-text">تاریخ عضویت</span>
            <span><?php echo $registered; ?></span>
        </div>
    </div>
</div>
