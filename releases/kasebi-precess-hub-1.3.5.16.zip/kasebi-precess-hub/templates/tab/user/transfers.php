<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * @var $user_id
 */
$record_page = $record_page ?? '/crm/user';
$defaults   = [
	'per_page'    => 10,
	'page_number' => 1,
	'date'        => [
		'from' => '',
		'to'   => '',
	],
	'invoice_id'  => '',
];
$args       = wp_parse_args( $_REQUEST, $defaults );
$args       = array_map( fn( $v ) => $v == 0 ? '' : $v, $args );
$has_filter = kph_page_has_filter( $args, $defaults );
extract( $args );
$date_from  = $date['from'] ?? '';
$date_to    = $date['to'] ?? '';
$DB         = new kph_db();
$entries    = $DB->get_transfers_list( [
	'user_id'   => $user_id,
	'page'      => $page_number,
	'per_page'  => $per_page,
	'ref_id'    => $invoice_id,
	'date_from' => $date_from ? nooshika_jalali_to_gregorian( $date_from ) : NULL,
	'date_to'   => $date_to ? nooshika_jalali_to_gregorian( $date_to ) : NULL,
] );
$total_page = $entries['pagination']['total_page'];
$entries    = $entries['items'];
?>
<div class="nk-block nk-block-between">
    <div class="nk-block-head">
        <h6 class="title">لیست حواله ها</h6>
    </div>
    <ul class="btn-toolbar gx-1">
        <li class="nk-block-tools-opt">
            <a href="#" class="btn btn-icon btn-primary print_list_items" data-type="transfers"
               data-collect="ids,date">
                <em class="icon ni ni-printer"></em></a>
        </li>
        <li>
			<?php
			$filter_fields = [
				[
					'type'  => 'date-range',
					'label' => 'تاریخ حواله',
					'name'  => 'date',
					'value' => [
						'from' => $date_from ?? '',
						'to'   => $date_to ?? '',
					],
				],
				[
					'type'  => 'hidden',
					'name'  => 'tab',
					'value' => 'transfers',
				],
			];
			echo kph_get_template( 'components/filter-dropdown.php', [
				'has_filter'    => $has_filter,
				'filter_fields' => $filter_fields,
			] );
			?>
        </li>
    </ul>
</div>
<div class="nk-block">
	<?php
	if ( empty( $entries ) ) {
		echo '<div class="no_massages">آیتمی برای نمایش وجود ندارد.</div>';
	} else {
		?>
        <div class="card">
            <div class="nk-tb-list nk-tb-ulist is-compact">
                <div class="nk-tb-item nk-tb-head">
                    <div class="nk-tb-col nk-tb-col-check"></div>
                    <div class="nk-tb-col"><span class="sub-text">تاریخ حواله</span></div>
                    <div class="nk-tb-col"><span class="sub-text">مقدار</span></div>
                    <div class="nk-tb-col"><span class="sub-text">بانک</span></div>
                    <div class="nk-tb-col"><span class="sub-text">کد رهگیری</span></div>
                    <div class="nk-tb-col nk-tb-col-tools text-end"></div>
                </div>
				<?php
				foreach ( $entries as $entry ) {
					$icon       = $entry['amount'] < 0 ? 'ni-arrow-long-up' : 'ni-arrow-long-down';
					$class      = $entry['amount'] < 0 ? 'text-success' : 'text-danger';
					$date       = date_i18n( 'j F Y', strtotime( $entry['transferred_at'] ) );
					$amount     = number_format( $entry['amount'] );
					$note       = $entry['note'];
					$attachment = $DB->get_transfer_meta( $entry['id'], 'attachment' );
					$creator_id = $DB->get_transfer_meta( $entry['id'], 'creator_id' );
					?>
                    <div class="nk-tb-item">
                        <div class="nk-tb-col nk-tb-col-check">
                            <div class="custom-control custom-control-sm custom-checkbox notext">
                                <input type="checkbox" class="custom-control-input select_item_for_print"
                                       value="<?php echo $entry['id']; ?>"
                                       id="print_item_<?php echo $entry['id']; ?>">
                                <label class="custom-control-label"
                                       for="print_item_<?php echo $entry['id']; ?>"></label>
                            </div>
                        </div>
                        <div class="nk-tb-col">
                            <span><?php echo $date; ?></span>
                        </div>
                        <div class="nk-tb-col">
                            <div class="amount <?php echo $class; ?>">
                                <span><?php echo $amount; ?></span>
								<?php echo "<em class='icon ni $icon'></em>"; ?>
                            </div>
                        </div>
                        <div class="nk-tb-col">
                            <span><?php echo $entry['bank_name']; ?></span>
                        </div>
                        <div class="nk-tb-col">
                            <span><?php echo $entry['tracking_no']; ?></span>
                        </div>
                        <div class="nk-tb-col">
                            <ul class="nk-tb-actions gx-2">
                                <li class="nk-tb-action">
                                    <div class="btn btn-sm btn-icon btn-trigger" data-bs-toggle="tooltip"
                                         data-bs-placement="top"
                                         title="<?php echo get_user_name_by_id( $creator_id ); ?>">
                                        <em class="icon ni ni-user-add"></em>
                                    </div>
                                </li>
								<?php
								if ( $entry['ref_id'] ) {
									?>
                                    <li class="nk-tb-action">
                                        <div class="btn btn-sm btn-icon btn-trigger" data-bs-toggle="tooltip"
                                             data-bs-placement="top" title="فاکتور #<?php echo $entry['ref_id']; ?>">
                                            <em class="icon ni ni-file-text"></em>
                                        </div>
                                    </li>
									<?php
								}
								if ( $note ) {
									?>
                                    <li class="nk-tb-action">
                                        <div class="btn btn-sm btn-icon btn-trigger"
                                             data-bs-toggle="popover"
                                             data-bs-trigger="hover"
                                             data-bs-html="true"
                                             title="یادداشت"
                                             data-bs-content="<?php echo wpautop( $note ); ?>"
                                             data-bs-placement="top">
                                            <em class="icon ni ni-note-add-c"></em>
                                        </div>
                                    </li>
									<?php
								}
								if ( $attachment ) {
									$attachment = explode( ',', $attachment );
									?>
                                    <li class="nk-tb-action">
										<?php
										$actions = [];
										foreach ( $attachment as $url ) {
											$file_data = $DB->get_uploaded_file_data( $url );
											if ( ! $file_data ) {
												$file_name = $url;
											} else {
												$file_name = $file_data['original_name'];
											}
											$actions[] = [
												'link'     => $url,
												'title'    => $file_name,
												'icon'     => 'ni-download',
												'target'   => '_blank',
												'download' => TRUE,
											];
										}
										echo kph_get_template( 'components/row-actions-dropdown.php', [
											'actions'   => $actions,
											'main_icon' => 'file-docs',
											'title'     => 'فایل ضمیمه',
										] );
										?>
                                    </li>
									<?php
								}
								?>
                                <li>
									<?php
									$actions = [
										'delete' => [
											'title' => 'حذف حواله',
											'icon'  => 'ni-trash',
											'class' => 'delete_db_item',
											'data'  => [
												'page'    => $record_page,
												'item_id' => $entry['id'],
												'id'      => $user_id,
												'tab'     => 'transfers',
												'action'  => 'kph_delete_transfer',
											],
										],
									];
									echo kph_get_template( 'components/row-actions-dropdown.php', [
										'actions' => $actions,
									] );
									?>
                                </li>
                            </ul>
                        </div>
                    </div>
					<?php
				}
				?>
            </div>
        </div>
        <div class="p-1 mt-2">
			<?php
			echo kph_get_template( 'components/pagination.php', [
				'max_page_num' => $total_page,
				'current_page' => $page_number,
				'show_count'   => 2,
				'data'         => [
					'tab' => 'transfers',
				],
			] );
			?>
        </div>
		<?php
	}
	?>
</div>
