<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * @var $user_id
 * @var $metas
 * @var $taxonomies
 */

?>
<div class="nk-block nk-block-between">
    <div class="nk-block-head">
        <h6 class="title">اطلاعات کارمند</h6>
    </div>
    <div class="nk-block">
        <a class="btn btn-icon btn-trigger" data-bs-toggle="modal" href="#editPersonal">
            <em class="icon ni ni-edit"></em>
        </a>
    </div>
</div>
<div class="nk-block">
    <div class="profile-ud-list">
		<?php
		foreach ( $metas as $key => $meta ) {
			$label = $meta['label'] ?? $key;
			$type  = $meta['type'] ?? 'text';
			$value = get_user_meta( $user_id, $key, TRUE );
			if ( $type === 'select' && isset( $meta['options'][ $value ] ) ) {
				$value = $meta['options'][ $value ]['label'];
			}
			if ( $type === 'date' && ! empty( $value ) ) {
				$value = date( 'Y/m/d', strtotime( $value ) );
			}
			if ( empty( $value ) ) {
				$value = '-';
			}
			$style = ( ! empty( $meta['width'] ) ) ? ' style="width:' . esc_attr( $meta['width'] ) . ';"' : '';
			?>
            <div class="profile-ud-item" <?php echo $style; ?>>
                <div class="profile-ud wider">
                    <span class="profile-ud-label"><?php echo $label; ?></span>
                    <span class="profile-ud-value"><?php echo $value; ?></span>
                </div>
            </div>
			<?php
		}
		?>
    </div>
</div>
