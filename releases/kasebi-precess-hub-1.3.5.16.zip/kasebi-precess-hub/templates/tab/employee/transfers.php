<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( nooshika_get_user_role( $user_id ) !== 'visitor' ) {
    echo kph_get_template( 'tab/employee/hr.php', [ 'user_id' => $user_id ] );
    return;
}
/** @var int $user_id */
echo kph_get_template( 'tab/user/transfers.php', [
	'user_id'     => $user_id,
	'record_page' => '/crm/employee',
] );
