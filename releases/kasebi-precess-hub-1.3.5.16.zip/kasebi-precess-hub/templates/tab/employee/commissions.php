<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** @var int $user_id */
$products = get_woocommerce_products_id_title();
$rules    = get_user_meta( $user_id, 'kph_visitor_commission_rules', TRUE );
$rules    = is_array( $rules ) ? $rules : [];
?>
<div class="nk-block nk-block-between">
	<div class="nk-block-head">
		<h6 class="title">تنظیمات پورسانت محصولات</h6>
		<p>پورسانت فقط هنگام ارسال مقدار پولی محصول در حساب ویزیتور ثبت می‌شود.</p>
	</div>
</div>
<div class="nk-block">
	<form class="modal_form" data-action="kph_save_visitor_commission_settings"
	      data-page="/crm/employee">
		<input type="hidden" data-for="id" value="<?php echo esc_attr( $user_id ); ?>">
		<input type="hidden" data-for="tab" value="commissions">
		<div class="card">
			<div class="nk-tb-list nk-tb-ulist is-compact">
				<div class="nk-tb-item nk-tb-head">
					<div class="nk-tb-col"><span class="sub-text">محصول</span></div>
					<div class="nk-tb-col"><span class="sub-text">نوع پورسانت</span></div>
					<div class="nk-tb-col"><span class="sub-text">مقدار</span></div>
				</div>
				<?php if ( empty( $products ) ) { ?>
					<div class="p-3 text-danger">محصولی برای تنظیم پورسانت یافت نشد.</div>
				<?php } else { ?>
					<?php foreach ( $products as $product ) {
						$product_id = (int) $product['id'];
						$rule       = $rules[ $product_id ] ?? [];
						$type       = $rule['type'] ?? 'none';
						$value      = $rule['value'] ?? '';
						?>
						<div class="nk-tb-item">
							<div class="nk-tb-col">
								<span class="lead-text"><?php echo esc_html( $product['title'] ); ?></span>
								<span class="sub-text">#<?php echo $product_id; ?></span>
							</div>
							<div class="nk-tb-col">
								<select class="form-select" data-for="rules[<?php echo $product_id; ?>][type]">
									<option value="none" <?php selected( $type, 'none' ); ?>>بدون پورسانت</option>
									<option value="percent" <?php selected( $type, 'percent' ); ?>>درصدی از مبلغ ارسال</option>
									<option value="per_kg" <?php selected( $type, 'per_kg' ); ?>>مبلغ ثابت به‌ازای هر کیلو</option>
								</select>
							</div>
							<div class="nk-tb-col">
								<input type="number" min="0" step="0.01" class="form-control"
								       data-for="rules[<?php echo $product_id; ?>][value]"
								       value="<?php echo esc_attr( $value ); ?>"
								       placeholder="درصد یا مبلغ (تومان)">
							</div>
						</div>
					<?php } ?>
				<?php } ?>
			</div>
		</div>
		<?php if ( ! empty( $products ) ) { ?>
			<div class="mt-3">
				<button type="button" class="btn btn-primary submit_modal_form">ذخیره تنظیمات پورسانت</button>
			</div>
		<?php } ?>
	</form>
</div>
