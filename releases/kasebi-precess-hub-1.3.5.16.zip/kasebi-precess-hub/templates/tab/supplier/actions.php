<?php
if (!defined('ABSPATH')) { exit; }
if (!kph_db::supplier_tools_allowed()) { echo '<div class="alert alert-danger">دسترسی به ارتباطات تأمین‌کننده مجاز نیست.</div>'; return; }
$user_id=is_scalar($user_id??NULL)?absint($user_id):0;
$supplier=$user_id?get_userdata($user_id):NULL;
if (!$supplier || !in_array('supplier',(array)$supplier->roles,TRUE)) { echo '<div class="alert alert-danger">تأمین‌کننده معتبر نیست.</div>'; return; }
$page_number=is_scalar($_REQUEST['page_number']??1)?max(1,(int)($_REQUEST['page_number']??1)):1;
$per_page=is_scalar($_REQUEST['per_page']??10)?max(1,min(200,(int)($_REQUEST['per_page']??10))):10;
$date=is_array($_REQUEST['date']??NULL)?$_REQUEST['date']:[];
$date_from=is_string($date['from']??NULL)?sanitize_text_field($date['from']):'';
$date_to=is_string($date['to']??NULL)?sanitize_text_field($date['to']):'';
foreach (['date_from','date_to'] as $key) { if (!preg_match('/^\d{4}[\/\-]\d{1,2}[\/\-]\d{1,2}$/D',nooshika_sanitize_numbers($$key))) { $$key=''; } }
$DB=new kph_db();
$entries=$DB->get_user_actions(['user_id'=>$user_id,'page'=>$page_number,'per_page'=>$per_page,'date_from'=>$date_from,'date_to'=>$date_to]);
$total_page=$entries['pagination']['total_page'];$entries=$entries['items'];
?>
<div class="nk-block nk-block-between">
    <div class="nk-block-head"><h6 class="title">فعالیت ها</h6><p>گزارش ارتباطات کارشناسان و تأمین‌کننده</p></div>
    <div class="nk-block"><ul class="btn-toolbar gx-1">
        <li><?php echo kph_get_template('components/filter-dropdown.php',['has_filter'=>$date_from!==''||$date_to!=='','filter_fields'=>[
            ['type'=>'date-range','label'=>'تاریخ فعالیت','name'=>'date','value'=>['from'=>$date_from,'to'=>$date_to]],
            ['type'=>'hidden','name'=>'tab','value'=>'actions'],['type'=>'hidden','name'=>'id','value'=>$user_id],
        ]]); ?></li>
        <li><a href="#addSupplierAction" class="btn btn-icon btn-primary" data-bs-target="#addSupplierAction" data-bs-toggle="modal" aria-label="افزودن فعالیت"><em class="icon ni ni-plus"></em></a></li>
    </ul></div>
</div>
<div class="nk-block kph-supplier-communications">
    <div class="nk-tb-list nk-tb-ulist is-compact v-align-top">
        <div class="nk-tb-item nk-tb-head">
            <div class="nk-tb-col"><span class="sub-text">تاریخ</span></div>
            <div class="nk-tb-col"><span class="sub-text">عنوان فعالیت</span></div>
            <div class="nk-tb-col"><span class="sub-text">محتوای فعالیت</span></div>
            <div class="nk-tb-col nk-tb-col-tools text-end"></div>
        </div>
        <?php if (!$entries) { ?><div class="no-item-found">فعالیتی یافت نشد</div><?php } ?>
        <?php foreach ($entries as $entry) { ?>
        <div class="nk-tb-item">
            <div class="nk-tb-col"><span><?php echo esc_html(date_i18n('Y/m/d',strtotime($entry['date']))); ?></span><span class="sub-text"><?php echo esc_html(date_i18n('H:i',strtotime($entry['date']))); ?></span></div>
            <div class="nk-tb-col"><span><?php echo esc_html($entry['title']); ?></span></div>
            <div class="nk-tb-col"><span><?php echo wp_kses_post($entry['content']); ?></span></div>
            <div class="nk-tb-col"><ul class="nk-tb-actions gx-2">
                <li class="nk-tb-action"><div class="btn btn-sm btn-icon btn-trigger" data-bs-toggle="tooltip" data-bs-placement="top" title="<?php echo esc_attr(get_user_name_by_id($entry['creator'])); ?>"><em class="icon ni ni-user-add"></em></div></li>
                <?php $files=[];foreach ((array)($entry['attachment']??[]) as $url) {
                    if (!is_string($url)||!esc_url($url)) { continue; }
                    $file=$DB->get_uploaded_file_data($url);
                    $files[]=['link'=>$url,'title'=>$file['original_name']??basename(parse_url($url,PHP_URL_PATH)?:$url),'icon'=>'ni-download','target'=>'_blank','download'=>TRUE];
                }
                if ($files) { ?><li class="nk-tb-action"><?php echo kph_get_template('components/row-actions-dropdown.php',['actions'=>$files,'main_icon'=>'file-docs','title'=>'فایل ضمیمه']); ?></li><?php } ?>
            </ul></div>
        </div>
        <?php } ?>
    </div>
    <div class="p-1 mt-2"><?php echo kph_get_template('components/pagination.php',['max_page_num'=>$total_page,'current_page'=>$page_number,'show_count'=>2,'data'=>['tab'=>'actions','id'=>$user_id,'per_page'=>$per_page,'date'=>wp_json_encode(['from'=>$date_from,'to'=>$date_to])]]); ?></div>
</div>
<div class="modal fade zoom" id="addSupplierAction">
    <div class="modal-dialog modal-lg"><div class="modal-content">
        <div class="modal-header"><h5 class="modal-title">افزودن فعالیت</h5><a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a></div>
        <div class="modal-body">
            <form action="#" class="kph-supplier-action-form">
                <input type="hidden" name="supplier_id" value="<?php echo (int)$user_id; ?>">
                <input type="hidden" name="nonce" value="<?php echo esc_attr(wp_create_nonce('kph_supplier_action_'.$user_id)); ?>">
                <div class="row g-gs">
                    <div class="col-md-6"><div class="form-group"><label class="form-label">تأمین‌کننده</label><div class="form-control-wrap"><input class="form-control" value="<?php echo esc_attr($supplier->display_name); ?>" readonly></div></div></div>
                    <div class="col-md-6"><div class="form-group"><label class="form-label" for="supplier_action_title">عنوان فعالیت</label><div class="form-control-wrap"><input class="form-control" id="supplier_action_title" name="title" maxlength="200" required></div></div></div>
                    <div class="col-12"><div class="form-group"><label class="form-label">توضیحات</label><div class="form-control-wrap"><div class="quill-basic" data-name="supplier_action_description"></div></div></div></div>
                    <div class="col-12"><div class="form-group"><label class="form-label">فایل ضمیمه</label><div class="upload-zone" data-target="#supplier_action_attachment" data-action="kph_handle_file_upload" data-max-files="1"><div class="dz-message" data-dz-message><span class="dz-message-text">بکشید و رها کنید</span><span class="dz-message-or">یا</span><div class="btn btn-primary">انتخاب کنید</div></div></div></div><input type="hidden" id="supplier_action_attachment" name="attachment"></div>
                    <div class="col-12"><ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2"><li><button type="submit" class="btn btn-primary">ثبت</button></li><li><a href="#" class="link link-light" data-bs-dismiss="modal">لغو</a></li></ul></div>
                </div>
            </form>
        </div>
    </div></div>
</div>
