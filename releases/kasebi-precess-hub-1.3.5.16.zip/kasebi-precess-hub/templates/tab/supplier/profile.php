<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * @var $user_id
 */
$DB              = new kph_db();
$supplier_groups = $DB->get_raw_categories();
$supplier_groups = $supplier_groups['items'];
$states          = WC()->countries->get_states( 'IR' );
$user_state      = get_user_meta( $user_id, 'state', TRUE );
if ( $user_state ) {
	$cities = PWS()::cities( $user_state );
} else {
	$cities = [ 0 => 'استان انتخاب نشده است.' ];
}
$metas = [
	'first_name'         => [
		'label' => 'نام',
	],
	'last_name'          => [
		'label' => 'نام خانوادگی',
	],
	'nooshika_phone_num' => [
		'type'  => 'tel',
		'label' => 'شماره ورود به پنل',
	],
	'birthday'           => [
		'type'  => 'date',
		'label' => 'تاریخ تولد',
	],
	'national_code'      => [
		'label' => 'کد ملی',
	],
	'kph_supplier_group' => [
		'type'    => 'select',
		'label'   => 'گروه تامین‌کننده',
		'options' => array_combine(
			array_column( $supplier_groups, 'id' ),
			array_column( $supplier_groups, 'title' )
		),
	],
	'account_number'     => [
		'label' => 'شماره حساب',
	],
	'cart_number'        => [
		'label' => 'شماره کارت',
	],
	'shaba_number'       => [
		'label' => 'شماره شبا',
	],
	'state'              => [
		'type'    => 'select',
		'label'   => 'استان',
		'options' => $states,
	],
	'city'               => [
		'type'    => 'select',
		'label'   => 'شهرستان',
		'options' => $cities,
	],
	'address'            => [
		'label' => 'آدرس',
		'width' => '100%',
	],
];
?>
<div class="nk-block nk-block-between">
    <div class="nk-block-head">
        <h6 class="title">اطلاعات شخصی</h6>
        <p>اطلاعات شخصی تامین کننده</p>
    </div>
    <div class="nk-block">
        <a class="btn btn-white btn-icon btn-outline-light" data-bs-toggle="modal" href="#editPersonal">
            <em class="icon ni ni-edit"></em>
        </a>
    </div>
</div>
<div class="nk-block">
    <div class="profile-ud-list">
		<?php
		foreach ( $metas as $key => $meta ) {
			if ( ! kph_meta_is_visible( $meta, $user_id ) ) {
				continue;
			}
			$label      = $meta['label'] ?? $key;
			$type       = $meta['type'] ?? 'text';
			$main_value = get_user_meta( $user_id, $key, TRUE );
			$value      = $main_value;
			if ( $type === 'select' && isset( $meta['options'][ $value ] ) ) {
				$value = $meta['options'][ $value ];
			}
			if ( $type === 'date' && ! empty( $value ) ) {
				$value = date_i18n( 'Y/m/d', strtotime( $value ) );
			}
			if ( empty( $value ) ) {
				$value = '-';
			}
			if ( $key === 'kph_timezone' && ! empty( $value ) ) {
				$diff  = $meta['options'][ $main_value ]['diff'];
				$value .= "({$diff})";
			}
			$style = ( ! empty( $meta['width'] ) ) ? ' style="width:' . esc_attr( $meta['width'] ) . ';"' : '';
			?>
            <div class="profile-ud-item" <?php echo $style; ?>>
                <div class="profile-ud wider">
                    <span class="profile-ud-label"><?php echo $label; ?></span>
                    <span class="profile-ud-value"><?php echo $value; ?></span>
                </div>
            </div>
			<?php
		}
		?>
    </div>
</div>
<div class="modal fade" tabindex="-1" role="dialog" id="editPersonal">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
            <div class="modal-body modal-body-md">
                <h5 class="modal-title">به روز رسانی اطلاعات کاربر</h5>
                <form action="#" class="mt-4">
                    <div class="row g-gs">
						<?php
						foreach ( $metas as $key => $meta ) {
							$value    = get_user_meta( $user_id, $key, TRUE );
							$editable = $meta['editable'] ?? TRUE;
							if ( ! $editable ) {
								continue;
							}
							$type     = $meta['type'];
							$label    = $meta['label'];
							$required = $meta['required'];
							$width    = isset( $meta['width'] ) && $meta['width'] == '100%' ? 12 : 6;
							$id       = 'edit_' . $key;
							
							$is_conditional = ( ! empty( $meta['state'] ) && $meta['state'] === 'conditional' );
							$cond_meta      = $meta['conditions']['meta'] ?? '';
							$cond_value     = $meta['conditions']['value'] ?? '';
							$cond_operator  = $meta['conditions']['operator'] ?? '==';
							
							$expected_json = wp_json_encode( $cond_value );
							$visible       = kph_meta_is_visible( $meta, $user_id );
							$row_classes   = 'col-md-' . (int) $width . ' meta-field-row';
							if ( ! $visible ) {
								$row_classes .= ' d-none';
							}
							if ( $required ) {
								$label .= ' *';
							}
							?>
                            <div class="<?php echo esc_attr( $row_classes ); ?>"
                                 data-meta-key="<?php echo esc_attr( $key ); ?>"
                                 data-conditional="<?php echo $is_conditional ? '1' : '0'; ?>"
                                 data-cond-meta="<?php echo esc_attr( $cond_meta ); ?>"
                                 data-cond-expected='<?php echo esc_attr( $expected_json ); ?>'
                                 data-cond-operator="<?php echo esc_attr( $cond_operator ); ?>">
                                <div class="form-group">
                                    <label class="form-label" for="<?php echo $id; ?>"><?php echo $label; ?></label>
                                    <div class="form-control-wrap">
										<?php
										if ( $type === 'textarea' ) {
											?>
                                            <textarea class="form-control" id="<?php echo $id; ?>"
                                                      data-for="<?php echo $key; ?>"><?php echo esc_html( $value ); ?></textarea>
											<?php
										} elseif ( $type === 'select' && ! empty( $meta['options'] ) ) {
											$class = $key == 'state' ? ' load_city' : '';
											?>
                                            <select class="form-select js-select2<?php echo $class; ?>"
												<?php echo $key == 'state' ? 'data-target="#edit_city"' : ''; ?>
                                                    id="<?php echo $id; ?>"
                                                    data-for="<?php echo $key; ?>">
                                                <option value="" selected disabled>انتخاب کنید</option>
												<?php
												foreach ( $meta['options'] as $option_value => $option_label ) {
													$selected = selected( $value, $option_value, FALSE );
													echo "<option value='$option_value' $selected>$option_label</option>";
												}
												?>
                                            </select>
											<?php
										} elseif ( $type === 'date' ) {
											if ( ! empty( $value ) ) {
												$value = date_i18n( 'Y/m/d', strtotime( $value ) );
											}
											?>
                                            <div class="form-icon form-icon-right">
                                                <em class="icon ni ni-calendar"></em>
                                            </div>
                                            <input type="text" class="form-control datepicker"
                                                   id="<?php echo $id; ?>"
                                                   data-for="<?php echo $key; ?>"
                                                   placeholder="روز-ماه-سال"
                                                   value="<?php echo $value; ?>"/>
											<?php
										} else {
											?>
                                            <input type="<?php echo $type; ?>" class="form-control"
                                                   id="<?php echo $id; ?>"
                                                   data-for="<?php echo $key; ?>"
                                                   value="<?php echo $value; ?>"/>
											<?php
										}
										?>
                                    </div>
                                </div>
                            </div>
							<?php
						}
						?>
                        <div class="col-12">
                            <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                <li>
                                    <div id="update_user_personal_data" class="btn btn-primary"
                                         data-bs-dismiss="modal">به روز رسانی
                                    </div>
                                </li>
                                <li>
                                    <a href="#" class="link link-light" data-bs-dismiss="modal">لغو</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
