<h6 class="title nk-block-title">تنظیمات پایه وبسایت</h6>
<p>در این قسمت شما می توانید اطلاعات پایه وبسایت خود را تنظیم کنید.</p>
<div class="gy-3 form-settings">
    <div class="row g-3 align-center">
        <div class="col-lg-5">
            <div class="form-group"><label class="form-label" for="site-name">نام فروشگاه</label>
                <span class="form-note">نام نمایشی فروشگاه در پنل</span>
            </div>
        </div>
        <div class="col-lg-7">
            <div class="form-group">
                <div class="form-control-wrap">
                    <input type="text" class="form-control site_setting_field"
                           data-for="kph_site_title"
                           id="site-name" value="<?php echo get_option( 'kph_site_title' ); ?>">
                </div>
            </div>
        </div>
    </div>
    <div class="row g-3 align-center">
        <div class="col-lg-5">
            <div class="form-group">
                <label class="form-label" for="kph_site_subtitle">زیر عنوان فروشگاه</label>
                <span class="form-note">اسلوگان فروشگاه را اینجا وارد نمایید</span>
            </div>
        </div>
        <div class="col-lg-7">
            <div class="form-group">
                <div class="form-control-wrap">
                    <input type="text" class="form-control site_setting_field"
                           data-for="kph_site_subtitle"
                           id="kph_site_subtitle" value="<?php echo get_option( 'kph_site_subtitle' ); ?>">
                </div>
            </div>
        </div>
    </div>
    <div class="row g-3 align-center">
        <div class="col-lg-5">
            <div class="form-group">
                <label class="form-label" for="kph_site_subtitle">لوگوی پنل</label>
                <span class="form-note">لوگوی پنل را اینجا آپلود کنید</span>
            </div>
        </div>
        <div class="col-lg-7">
            <div class="row g-3 align-center">
                <div class="col-lg-7">
					<?php
					$logo = get_option( 'kph_panel_logo' );
					if ( $logo ) {
						?>
                        <div class="kph_logo_preview text-center">
                            <img src="<?php echo $logo; ?>" alt="لوگوی پنل" class="img-fluid">
                        </div>
						<?php
					} else {
						?>
                        <div class="kph_logo_preview text-center">
                            <img src="<?php echo KPH_ASSETS_URL . 'image/kasebi_logo.png'; ?>" alt="لوگوی پنل"
                                 class="img-fluid">
                        </div>
						<?php
					}
					?>
                </div>
                <div class="col-lg-5">
                    <div class="upload-zone" data-target="#kph_panel_logo" data-action="kph_handle_file_upload"
                         data-max-files="1">
                        <div class="dz-message" data-dz-message>
                            <span class="dz-message-text">تصویر را بکشید و رها کنید</span>
                            <span class="dz-message-or">یا</span>
                            <button class="btn btn-primary">انتخاب کنید</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <input type="hidden" class="site_setting_field"
               data-for="kph_panel_logo" id="kph_panel_logo" value="<?php echo $logo; ?>">
    </div>
</div>
<?php
$factor_items = [
	[ 'key' => 'kph_factor_store_name', 'label' => 'نام فروشنده' ],
	[ 'key' => 'kph_factor_sale_type', 'label' => 'شرایط و نحوه فروش پیش‌فرض', 'options' => [ 'cash' => 'نقدی', 'credit' => 'غیر نقدی' ], 'default' => 'cash' ],
	[ 'key' => 'kph_factor_payment_method', 'label' => 'روش پرداخت پیش‌فرض (مثلاً کارتخوان، حواله یا چک)' ],
	[ 'key' => 'kph_factor_payment_due', 'label' => 'مهلت پرداخت پیش‌فرض (مثلاً ۴۵ روزه)' ],
	[ 'key' => 'kph_factor_notes', 'label' => 'توضیحات تکمیلی فاکتور' ],
	[
		'key'   => 'kph_factor_store_id',
		'label' => 'شناسه ملی فروشنده',
	],
	[
		'key'   => 'kph_factor_national_id',
		'label' => 'کد اقتصادی فروشنده',
	],
	[
		'key'   => 'kph_factor_province',
		'label' => 'استان',
	],
	[
		'key'   => 'kph_factor_city',
		'label' => 'شهرستان',
	],
	[
		'key'   => 'kph_factor_postal_code',
		'label' => 'کد پستی',
	],
	[
		'key'   => 'kph_factor_address',
		'label' => 'نشانی',
	],
	[
		'key'   => 'kph_factor_phone',
		'label' => 'تلفن',
	],
	[
		'key'   => 'kph_factor_fax',
		'label' => 'نمابر',
	],
];
?>
<h6 class="title nk-block-title">تنظیمات فاکتور</h6>
<div class="gy-3 form-settings">
	<?php foreach ( $factor_items as $factor_item ) : ?>
		<?php
		$key   = $factor_item['key'];
		$label = $factor_item['label'];
		$value = get_option( $key, $factor_item['default'] ?? '' );
		?>

        <div class="row g-3 align-center">
            <div class="col-lg-5">
                <div class="form-group">
                    <label class="form-label" for="<?php echo esc_attr( $key ); ?>">
						<?php echo esc_html( $label ); ?>:
                    </label>
                </div>
            </div>

            <div class="col-lg-7">
                <div class="form-group">
                    <div class="form-control-wrap">
                        <?php if ( isset( $factor_item['options'] ) ) : ?>
                        <select class="form-select site_setting_field" id="<?php echo esc_attr( $key ); ?>" data-for="<?php echo esc_attr( $key ); ?>">
                            <?php foreach ( $factor_item['options'] as $option => $title ) : ?>
                            <option value="<?php echo esc_attr( $option ); ?>" <?php selected( $value, $option ); ?>><?php echo esc_html( $title ); ?></option>
                            <?php endforeach; ?>
                        </select>
                        <?php else : ?>
                        <input
                            type="text"
                            class="form-control site_setting_field"
                            id="<?php echo esc_attr( $key ); ?>"
                            data-for="<?php echo esc_attr( $key ); ?>"
                            value="<?php echo esc_attr( $value ); ?>"
                        >
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
	<?php endforeach; ?>
</div>
<div class="d-flex justify-end mt-3">
    <div class="btn btn-primary save_site_settings" data-tab="site-settings">به روزرسانی تنظیمات</div>
</div>