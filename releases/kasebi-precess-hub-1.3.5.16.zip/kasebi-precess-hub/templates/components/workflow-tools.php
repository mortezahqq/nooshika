<?php
if ( ! defined( 'ABSPATH' ) || ! current_user_can( 'manage_options' ) ) { return; }
$DB = isset( $DB ) ? $DB : new kph_db();
$ready = $DB->workflow_storage_ready();
$supplier_issues = $DB->supplier_lifecycle_storage_issues();
?>
<details class="card card-bordered p-3 mb-3" <?php echo $supplier_issues ? 'open' : ''; ?>>
    <summary>آماده‌سازی ابطال فاکتورهای تأمین‌کنندگان <?php echo $supplier_issues ? '— نیازمند بررسی' : '— آماده'; ?></summary>
    <p class="mt-3">این بررسی مستقل از آماده‌سازی کدهای تولید است. ابطال فاکتور فقط زمانی اجرا می‌شود که تمام جدول‌های مرتبط با حسابداری و ورود/خروج انبار تراکنشی (InnoDB) باشند.</p>
    <?php if (!$supplier_issues) { ?>
        <p>ساختار جدول‌های موردنیاز ابطال آماده است. برای ابطال، به فهرست فاکتورهای تأمین‌کنندگان برگردید.</p>
    <?php } else { ?>
        <p>جدول‌های نیازمند بررسی:</p>
        <ul>
            <?php foreach ($supplier_issues as $issue) { ?>
                <li><code><?php echo esc_html($issue['table']); ?></code> —
                    <?php echo esc_html($issue['kind'] === 'engine'
                        ? 'موتور فعلی: ' . ($issue['engine'] ?: 'نامشخص') . ' (باید InnoDB باشد)'
                        : ($issue['kind'] === 'missing' ? 'جدول یافت نشد؛ نیازمند بررسی مدیر دیتابیس' : 'خواندن مشخصات جدول ناموفق بود')); ?>
                </li>
            <?php } ?>
        </ul>
        <p><strong>هشدار:</strong> ابتدا از تمام دیتابیس نسخهٔ پشتیبان تهیه کنید و ثبت فاکتور، تولید و گردش انبار را موقتاً متوقف کنید. تبدیل موتور جدول می‌تواند زمان‌بر باشد و در حین تبدیل، جدول قفل شود؛ این ابزار هیچ فاکتوری را ابطال نمی‌کند.</p>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
            <input type="hidden" name="action" value="kph_workflow_maintenance">
            <input type="hidden" name="operation" value="prepare_supplier">
            <?php wp_nonce_field('kph_workflow_maintenance'); ?>
            <p><label><input type="checkbox" name="confirm_supplier_prepare" value="1" required> از دیتابیس نسخهٔ پشتیبان دارم و ثبت اطلاعات در سایت متوقف شده است.</label></p>
            <button type="submit" class="btn btn-warning button">آماده‌سازی ساختار ابطال تأمین‌کنندگان</button>
        </form>
        <p>اگر جدولی وجود نداشته باشد یا دیتابیس اجازهٔ تغییر ساختار ندهد، عملیات متوقف می‌شود و باید مدیر دیتابیس بررسی کند.</p>
    <?php } ?>
</details>
<details class="card card-bordered p-3 mb-3">
    <summary>ابزارهای ثبت یکپارچه و بررسی تولید</summary>
    <p class="mt-3">پیش از آماده‌سازی، نسخه پشتیبان دیتابیس بگیرید و عملیات را در زمان توقف ثبت تولید و فاکتور انجام دهید. این عملیات موتور جدول‌های مرتبط را به InnoDB تبدیل می‌کند؛ سوابق مالی را تغییر نمی‌دهد.</p>
    <p><?php echo $ready ? 'ثبت یکپارچه آماده است.' : 'برای جلوگیری از ثبت ناقص تولید و ویرایش فاکتور، آماده‌سازی لازم است.'; ?></p>
    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
        <input type="hidden" name="action" value="kph_workflow_maintenance">
        <input type="hidden" name="operation" value="prepare">
        <?php wp_nonce_field( 'kph_workflow_maintenance' ); ?>
        <button type="submit" class="btn btn-primary button button-primary">آماده‌سازی و انتقال کدهای موجود</button>
    </form>
    <h5 class="mt-4">تبدیل‌های ناسازگار با کد موجودی</h5>
    <p>اصلاح هر مورد فقط برای تبدیل ناقص و بدون گردش دیگر مجاز است. محصول از کد موجودی مشخص می‌شود. پیش‌فرض، وزن قبلی حفظ می‌شود؛ اگر وزن هر آیتم را تغییر دهید، تعداد و هزینه بسته‌بندی و بهای هر آیتم دوباره محاسبه می‌شوند. وزن کل مواد تغییر نمی‌کند.</p>
    <?php foreach ( $DB->production_conversion_conflicts() as $conflict ) { ?>
    <div class="border p-3 mb-2">
        <p><?php echo esc_html( 'تبدیل #' . $conflict['id'] . ' — کد ' . $conflict['code'] . ' — محصول ثبت‌شده: ' . $conflict['wrong_title'] . ' — محصول کد موجودی: ' . $conflict['expected_title'] ); ?></p>
        <p><?php echo esc_html( 'تعداد: ' . $conflict['qty_items'] . '؛ وزن هر آیتم: ' . $conflict['weight_per_item'] . ' کیلوگرم' ); ?></p>
        <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
            <input type="hidden" name="action" value="kph_workflow_maintenance">
            <input type="hidden" name="operation" value="repair">
            <input type="hidden" name="conversion_id" value="<?php echo esc_attr( $conflict['id'] ); ?>">
            <?php wp_nonce_field( 'kph_workflow_maintenance' ); ?>
            <label class="d-block">وزن تأییدشده هر آیتم (گرم): <input class="kph-repair-weight" type="number" name="weight_per_item_gram" min="0.001" step="0.001" required data-total-grams="<?php echo esc_attr( (int) $conflict['qty_items'] * (float) $conflict['weight_per_item'] * 1000 ); ?>" data-pack-cost="<?php echo esc_attr( $conflict['packaging_cost_per_item'] ); ?>" value="<?php echo esc_attr( (float) $conflict['weight_per_item'] * 1000 ); ?>"></label>
            <output class="kph-repair-preview d-block"><?php echo esc_html( 'تعداد پس از اصلاح: ' . $conflict['qty_items'] . '؛ هزینه بسته‌بندی کل: ' . number_format( (int) $conflict['qty_items'] * (float) $conflict['packaging_cost_per_item'] ) . ' ریال' ); ?></output>
            <label><input type="checkbox" name="confirm_repair" value="1" required> محصول مقصد و تعداد و وزن ثبت‌شده را بررسی و تأیید کرده‌ام.</label>
            <button type="submit" class="btn btn-warning button" <?php disabled( ! $ready ); ?>>اصلاح ارتباط محصول و تکمیل موجودی</button>
        </form>
    </div>
    <?php } ?>
</details>
<script>
if (!window.kphRepairPreviewBound) {
    window.kphRepairPreviewBound = true;
    document.addEventListener('input', function(event) {
        var field = event.target;
        if (!field.matches('.kph-repair-weight')) return;
        var weight = Number(field.value), qty = Number(field.dataset.totalGrams) / weight;
        var rounded = Math.round(qty), output = field.closest('form').querySelector('.kph-repair-preview');
        output.textContent = weight > 0 && rounded > 0 && Math.abs(qty - rounded) < 0.000001 ?
            'تعداد پس از اصلاح: ' + rounded + '؛ هزینه بسته‌بندی کل: ' + (rounded * Number(field.dataset.packCost)).toLocaleString('fa-IR') + ' ریال' :
            'وزن کل باید دقیقاً به تعداد صحیح آیتم تقسیم شود.';
    });
}
</script>
