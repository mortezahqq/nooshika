<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$percent  = (float) $target['amount'] > 0 ? round( $target['sales'] / $target['amount'] * 100, 1 ) : 0;
$achieved = $target['sales'] >= $target['amount'];
$active   = $target['date_from'] <= $today && $target['date_to'] >= $today;
$label    = $achieved ? 'محقق شده' : ( $today < $target['date_from'] ? 'شروع نشده' : ( $today > $target['date_to'] ? 'پایان‌یافته · محقق نشده' : 'در حال اجرا' ) );
$state    = $achieved ? 'success' : ( $active ? 'active' : 'warning' );
$url      = "/crm/employee/$user_id?tab=targets&target_id=$id";
?>
<article
    class="kv-target <?php echo $active ? 'kv-target--active' : ''; ?> <?php echo $achieved ? 'kv-target--achieved' : ''; ?>"
    aria-labelledby="target-title-<?php echo (int) $id; ?>">
    <div class="kv-target-top">
        <div><h6 id="target-title-<?php echo (int) $id; ?>"><?php echo esc_html( $target['title'] ); ?></h6>
            <div class="kv-period"><em class="icon ni ni-calendar" aria-hidden="true"></em>
                <bdi><?php echo esc_html( $target['date_from_fa'] ?? $target['date_from'] ); ?></bdi>
                <span>تا</span>
                <bdi><?php echo esc_html( $target['date_to_fa'] ?? $target['date_to'] ); ?></bdi>
            </div>
        </div>
        <span class="kv-pill kv-pill--<?php echo esc_attr( $state ); ?>"><?php if ( $achieved ) { ?><em
                class="icon ni ni-check-circle"
                aria-hidden="true"></em><?php } ?><?php echo esc_html( $label ); ?></span>
    </div>
    <div class="kv-progress-caption"><span class="kv-muted">تحقق هدف فروش</span><strong>
            <bdi><?php echo esc_html( number_format( $percent, $percent == floor( $percent ) ? 0 : 1 ) ); ?>٪</bdi>
        </strong></div>
    <div class="kv-progress-track" role="progressbar"
         aria-label="<?php echo esc_attr( 'پیشرفت ' . $target['title'] ); ?>"
         aria-valuenow="<?php echo esc_attr( min( 100, $percent ) ); ?>" aria-valuemin="0" aria-valuemax="100"
         aria-valuetext="<?php echo esc_attr( $percent . ' درصد تحقق هدف' ); ?>">
        <div class="kv-progress-fill" style="width: <?php echo esc_attr( min( 100, max( 0, $percent ) ) ); ?>%"></div>
    </div>
    <div class="kv-sales-line"><strong class="kv-number"><?php echo number_format( $target['sales'] ); ?></strong><span>از</span>
        <bdi class="kv-number"><?php echo number_format( $target['amount'] ); ?></bdi>
        <span>فروش هدف</span></div>
    <dl class="kv-reward-grid">
        <div>
            <dt><?php echo $achieved ? 'فروش مازاد بر هدف' : 'باقی‌مانده تا هدف'; ?></dt>
            <dd>
                <bdi class="kv-number"><?php echo number_format( abs( $target['amount'] - $target['sales'] ) ); ?></bdi>
                <small>ریال</small></dd>
        </div>
        <div>
            <dt>پاداش تعیین‌شده</dt>
            <dd>
                <bdi class="kv-number"><?php echo number_format( $target['bonus'] ); ?></bdi>
                <small>ریال</small></dd>
        </div>
        <div>
            <dt>پاداش خالص ثبت‌شده</dt>
            <dd>
                <bdi class="kv-number"><?php echo number_format( $target['reward'] ); ?></bdi>
                <small>ریال</small></dd>
        </div>
    </dl>
    <div class="kv-target-footer">
        <?php if ( $can_manage && ! $target['has_reward_history'] ) {
            echo kph_get_template( 'components/row-actions-dropdown.php', [
                'title' => 'عملیات تارگت', 'main_icon' => 'more-h',
                'actions' => [ [
                    'title' => 'حذف تارگت', 'icon' => 'ni-trash-alt', 'class' => 'row_inline_action text-danger',
                    'data' => [
                        'action' => 'kph_delete_visitor_target', 'item-id' => (int) $id, 'id' => (int) $user_id,
                        'nonce' => wp_create_nonce( 'kph_delete_visitor_target_' . (int) $user_id . '_' . (int) $id ),
                        'swal-title' => 'تارگت «' . $target['title'] . '» حذف شود؟', 'needs' => wp_json_encode( [] ),
                    ],
                ] ],
            ] );
        } ?>
        <span><?php echo $target['reward'] > 0 ? 'پاداش در حساب ویزیتور ثبت شده است.' : ( $target['has_reward_history'] ? 'پاداش با توجه به برگشت فروش اصلاح شده است.' : 'پاداش پس از تحقق هدف ثبت می‌شود.' ); ?></span>
		<?php if ( $can_manage && ! $target['has_reward_history'] ) { ?><a class="page_activator"
                                                                           href="<?php echo esc_url( $url ); ?>"
                                                                           data-url="<?php echo esc_url( $url ); ?>"><em
                    class="icon ni ni-edit" aria-hidden="true"></em>ویرایش تارگت</a>
		<?php } elseif ( $target['has_reward_history'] ) { ?><span class="kv-pill"><em class="icon ni ni-lock"
                                                                                       aria-hidden="true"></em>دارای سابقه پاداش · غیرقابل‌ویرایش و حذف</span><?php } ?>
    </div>
</article>
