<?php
if ( ! defined( 'ABSPATH' ) || ! current_user_can( 'manage_options' ) ) { return; }
$cheque_admin_note = $DB->get_cheque_meta( (int) $cheque_id, 'admin_note' );
if ( ! is_string( $cheque_admin_note ) || $cheque_admin_note === '' ) { return; }
$cheque_note_print_all = $DB->cheque_note_print_all_enabled();
$cheque_note_print_individual = (string) $DB->get_cheque_meta( (int) $cheque_id, 'admin_note_print' ) === '1';
?>
<details class="mt-2" style="max-width: 280px; white-space: normal;">
    <summary class="text-primary" style="cursor: pointer;">یادداشت داخلی <small>(فقط ادمین)</small></summary>
    <div class="mt-2 text-break" style="white-space: pre-wrap;"><?php echo esc_html( $cheque_admin_note ); ?></div>
    <label class="d-block mt-2"><input type="checkbox" class="cheque-note-print-toggle" data-cheque-id="<?php echo esc_attr( $cheque_id ); ?>" data-nonce="<?php echo esc_attr( wp_create_nonce( 'kph_cheque_admin_note' ) ); ?>" data-print-all="<?php echo $cheque_note_print_all ? '1' : '0'; ?>" data-individual-show="<?php echo $cheque_note_print_individual ? '1' : '0'; ?>" <?php checked( $cheque_note_print_all || $cheque_note_print_individual ); ?> <?php disabled( $cheque_note_print_all ); ?>> نمایش یادداشت داخلی در چاپ این چک</label>
    <small class="text-soft cheque-note-global-hint<?php echo $cheque_note_print_all ? '' : ' d-none'; ?>">چاپ یادداشت همه چک‌ها فعال است؛ برای تغییر موردی آن را از بالای لیست خاموش کنید.</small>
</details>
