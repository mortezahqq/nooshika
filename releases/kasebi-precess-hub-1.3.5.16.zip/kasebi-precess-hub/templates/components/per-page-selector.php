<?php
/**
 * @var int   $per_page
 * @var array $available_per_pages
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

$defaults = [
	'per_page'            => 20,
	'available_per_pages' => [ 10, 20, 50 ],
];
$args     = wp_parse_args( $args ?? [], $defaults );
extract( $args );
?>
<div class="dropdown">
    <a href="#" class="btn btn-trigger btn-icon dropdown-toggle" data-bs-toggle="dropdown">
        <em class="icon ni ni-setting"></em>
    </a>
    <div class="dropdown-menu dropdown-menu-xs dropdown-menu-end">
        <ul class="link-check">
            <li><span>نمایش</span></li>
			<?php
			foreach ( $available_per_pages as $item ) {
				?>
                <li class="change_per_page<?php
				echo $item == $per_page ? ' active' : ''; ?>"
                    data-per-page="<?php
				    echo esc_attr( $item ); ?>">
                    <a href="#"><?php
						echo esc_html( $item ); ?></a>
                </li>
				<?php
			}
			?>
        </ul>
    </div>
</div>
