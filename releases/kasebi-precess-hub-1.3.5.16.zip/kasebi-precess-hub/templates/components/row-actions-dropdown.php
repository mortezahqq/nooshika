<?php

/**
 * @var array $actions
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$defaults = [
	'actions' => [],
    'title' => '',
    'main_icon' => 'more-h',
];
$args     = wp_parse_args( $args ?? [], $defaults );
extract( $args );

if ( empty( $actions ) ) {
	return;
}
?>
<div class="drodown">
    <a href="#" class="btn btn-sm btn-icon btn-trigger dropdown-toggle" data-bs-toggle="dropdown">
        <em <?php echo $title ? "data-bs-toggle='tooltip' data-bs-placement='top' title='$title'" : ''; ?>
            class="icon ni ni-<?php echo $main_icon ?: 'more-h'; ?>"></em>
    </a>
    <div class="dropdown-menu dropdown-menu-end">
        <ul class="link-list-opt no-bdr">
			<?php
			foreach ( $actions as $action ) {
				if ( ! empty( $action['divider'] ) ) {
					echo '<li class="divider"></li>';
				} else {
					$link     = $action['link'] ?? '';
					$download = $action['download'] ?? FALSE;
					$title    = $action['title'] ?? '';
					$icon     = $action['icon'] ?? '';
					$class    = $action['class'] ?? '';
					$data     = $action['data'] ?? [];
					$target   = $action['target'] ?? '';
					if ( $link ) {
						$data['url'] = $link;
					}
					$data_attrs = '';
					foreach ( $data as $key => $val ) {
						$data_attrs .= ' data-' . esc_attr( $key ) . '="' . esc_attr( $val ) . '"';
					}
					$data_attrs .= $download ? ' download target="_blank"' : '';
					$tag        = $link ? 'a' : 'div';
					?>
                    <li>
                        <a href="<?php echo esc_url( $link ); ?>" <?php echo $target ? "target='$target'" : ''; ?>
                           class="<?php echo esc_attr( $class ); ?>"<?php echo $data_attrs; ?> >
							<?php
							if ( $icon ) {
								?>
                                <em class="icon ni <?php echo esc_attr( $icon ); ?>"></em>
								<?php
							}
							?>
                            <span><?php echo esc_html( $title ); ?></span>
                        </a>
                    </li>
					<?php
				}
			}
			?>
        </ul>
    </div>
</div>
