<?php if(!defined('ABSPATH'))exit; ?>
<div class="modal fade" id="financeReceipt" tabindex="-1"><div class="modal-dialog modal-lg"><div class="modal-content">
    <div class="modal-header"><h5 class="modal-title">ضمیمه تراکنش</h5><a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a></div>
    <div class="modal-body modal-body-md"><form class="modal_form" data-action="kph_update_finance_attachment" data-page="/crm/finance-transactions">
        <input type="hidden" data-for="transaction_id"><input type="hidden" data-for="account_id"><input type="hidden" data-for="expected_attachment">
        <input type="hidden" data-for="nonce" value="<?php echo esc_attr(wp_create_nonce('kph_finance_attachment')); ?>">
        <div class="row g-3"><div class="col-12"><div class="form-group"><label class="form-label">فایل ضمیمه</label>
        <div class="upload-zone" data-target="#finance_receipt_attachment" data-action="kph_handle_file_upload" data-max-files="1"><div class="dz-message" data-dz-message><span class="dz-message-text">بکشید و رها کنید</span><span class="dz-message-or">یا</span><div class="btn btn-primary">انتخاب کنید</div></div></div>
        <input type="hidden" id="finance_receipt_attachment" data-for="attachment"></div></div>
        <div class="col-12"><ul class="align-center flex-wrap gx-4 gy-2"><li><div class="btn btn-primary submit_modal_form">ثبت ضمیمه</div></li><li><a href="#" class="link link-light" data-bs-dismiss="modal">لغو</a></li></ul></div></div>
    </form></div>
</div></div></div>
