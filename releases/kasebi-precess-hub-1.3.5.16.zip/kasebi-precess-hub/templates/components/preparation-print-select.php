<?php
if ( ! defined( 'ABSPATH' ) || ! kph_preparation_print_allowed() || empty( $order_id ) ) { return; }
?>
<input type="checkbox" class="kph-preparation-select" value="<?php echo esc_attr( absint( $order_id ) ); ?>" data-viewer="<?php echo esc_attr( get_current_user_id() ); ?>" aria-label="<?php echo esc_attr( 'انتخاب پیش‌فاکتور شماره ' . absint( $order_id ) . ' برای آماده‌سازی' ); ?>">
