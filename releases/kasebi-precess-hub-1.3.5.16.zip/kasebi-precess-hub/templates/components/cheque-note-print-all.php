<?php
if ( ! defined( 'ABSPATH' ) || ! current_user_can( 'manage_options' ) ) { return; }
$cheque_note_print_all = $DB->cheque_note_print_all_enabled();
?>
<div class="card card-bordered mb-3">
    <div class="card-inner py-3">
        <label class="d-flex align-items-center mb-1">
            <input type="checkbox" class="me-2 cheque-note-print-all-toggle"
                   data-nonce="<?php echo esc_attr( wp_create_nonce( 'kph_cheque_admin_note' ) ); ?>"
                   <?php checked( $cheque_note_print_all ); ?>>
            چاپ یادداشت داخلی همه چک‌ها
        </label>
        <small class="text-soft">برای همه چک‌های فعلی و جدید فعال می‌شود. با خاموش‌کردن، تنظیم جداگانه هر چک دوباره اعمال می‌شود.</small>
    </div>
</div>
