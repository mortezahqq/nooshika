<?php
/**
 * @var array $actions
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$defaults = [
	'actions' => [],
];

$args = wp_parse_args( $args ?? [], $defaults );
extract( $args );

if ( empty( $actions ) ) {
	return;
}
foreach ( $actions as $action ) {
	$link     = $action['link'] ?? '';
	$download = $action['download'] ?? FALSE;
	$target   = $download ? '_blank' : ( $action['target'] ?? '' );
	$title    = $action['title'] ?? '';
	$icon     = $action['icon'] ?? '';
	$class    = $action['class'] ?? '';
	$data     = $action['data'] ?? [];
	if ( $link ) {
		$data['url'] = $link;
	}
	$data_attrs = '';
	foreach ( $data as $key => $value ) {
		$data_attrs .= ' data-' . esc_attr( $key ) . '="' . esc_attr( $value ) . '"';
	}
	$data_attrs .= $download ? ' download' : '';
	if ( $target ) {
		$data_attrs .= ' target="' . esc_attr( $target ) . '"';
		$data_attrs .= $target === '_blank' ? ' rel="noopener"' : '';
	}
	$class      .= ! $download ? ' btn-trigger' : '';
	$tag        = $link ? 'a' : 'div';
	?>
    <li class="nk-tb-action-hidden">
        <a href="<?php echo esc_url( $link ); ?>" <?php echo $data_attrs; ?>
           class="btn btn-sm btn-icon <?php echo esc_attr( $class ); ?>"
           data-bs-toggle="tooltip" data-bs-placement="top" title="<?php echo esc_attr( $title ); ?>">
            <em class="icon ni <?php echo esc_attr( $icon ); ?>"></em>
        </a>
    </li>
	<?php
}
?>
