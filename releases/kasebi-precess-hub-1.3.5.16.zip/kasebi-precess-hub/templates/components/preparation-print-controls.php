<?php
if ( ! defined( 'ABSPATH' ) || ! kph_preparation_print_allowed() ) { return; }
?>
<div class="kph-preparation-controls d-flex align-items-center flex-wrap gap-3 mb-3" data-viewer="<?php echo esc_attr( get_current_user_id() ); ?>">
    <label class="mb-0"><input type="checkbox" class="kph-preparation-all"> انتخاب همه پیش‌فاکتورهای این صفحه</label>
    <button type="button" class="btn btn-outline-primary kph-preparation-print" data-url="<?php echo esc_url( home_url( '/crm/' ) ); ?>" data-nonce="<?php echo esc_attr( wp_create_nonce( 'kph_preparation_print' ) ); ?>">
        <em class="icon ni ni-printer" aria-hidden="true"></em><span>چاپ لیست آماده‌سازی</span>
    </button>
    <span class="kph-preparation-count text-soft" role="status" aria-live="polite">۰ پیش‌فاکتور انتخاب شده</span>
    <button type="button" class="btn btn-sm btn-light kph-preparation-clear">پاک کردن انتخاب‌ها</button>
    <details class="kph-preparation-selection w-100" hidden>
        <summary>مشاهده و حذف پیش‌فاکتورهای انتخاب‌شده</summary>
        <div class="kph-preparation-selected d-flex flex-wrap gap-2 mt-2"></div>
    </details>
</div>
