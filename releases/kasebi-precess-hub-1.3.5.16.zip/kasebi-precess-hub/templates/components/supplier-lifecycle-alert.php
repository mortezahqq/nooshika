<?php
if (!defined('ABSPATH') || !current_user_can('manage_options')) { return; }
$DB = isset($DB) && $DB instanceof kph_db ? $DB : new kph_db();
$issues = $DB->supplier_lifecycle_storage_issues();
if (!$issues) { return; }
?>
<div class="alert alert-warning" role="alert">
    <strong>ساختار ابطال فاکتور تأمین‌کننده آماده نیست.</strong>
    جدول <code><?php echo esc_html($issues[0]['table']); ?></code>
    نیازمند بررسی است. قبل از ابطال، پس از تهیهٔ بکاپ و توقف ثبت اطلاعات،
    <a href="<?php echo esc_url(admin_url('tools.php?page=kph-workflow-tools')); ?>" target="_blank" rel="noopener noreferrer">ابزار آماده‌سازی تأمین‌کنندگان</a>
    را باز کنید.
</div>
