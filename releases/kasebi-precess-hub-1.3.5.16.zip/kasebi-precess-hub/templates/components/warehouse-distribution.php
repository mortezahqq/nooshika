<?php
if(!defined('ABSPATH'))exit;
$allocations=$allocations??null;
$unit=isset($unit)&&$unit==='کیلوگرم'?'کیلوگرم':'عدد';
$decimal=static function($value):string {
    $text=(string)$value;
    if(!preg_match('/^-?\d+(?:\.\d+)?$/D',$text))$text=is_numeric($value)?sprintf('%.6F',(float)$value):'0';
    return bcadd($text,'0',6);
};
$label=static function(string $value):string {
    [$whole,$fraction]=explode('.',bcadd($value,'0',6));
    $whole=preg_replace('/\B(?=(\d{3})+(?!\d))/',',',$whole);
    $fraction=rtrim($fraction,'0');
    return $whole.($fraction!==''?'.'.$fraction:'');
};
$total=$decimal($total??0);
?>
<div class="kph-warehouse-distribution mt-1">
<?php if($allocations===null): ?>
    <span class="sub-text">تفکیک انبارها در دسترس نیست.</span>
<?php else:
    $allocated='0';
    foreach($allocations as $allocation):
        $quantity=$decimal($allocation['quantity']);$allocated=bcadd($allocated,$quantity,6);
?>
    <span class="sub-text" data-warehouse-id="<?php echo (int)$allocation['warehouse_id']; ?>"><?php echo esc_html($allocation['name'].(empty($allocation['is_active'])?' (غیرفعال)':'').': '.$label($quantity).' '.$unit); ?></span>
<?php endforeach;
    $gap=bcsub($total,$allocated,6);
    if(bccomp($gap,'0',6)>0): ?>
    <span class="sub-text">تخصیص‌نیافته: <?php echo esc_html($label($gap).' '.$unit); ?></span>
<?php elseif(bccomp($gap,'0',6)<0): ?>
    <span class="sub-text text-danger">جمع تفکیک انبارها با موجودی کل مطابقت ندارد.</span>
<?php elseif(!$allocations): ?>
    <span class="sub-text">موجودی تخصیص‌یافته‌ای وجود ندارد.</span>
<?php endif;endif; ?>
</div>
