<?php
/**
 * @var int  $user_id
 * @var bool $show_phone
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$user_color = get_user_meta( $user_id, 'user_color', TRUE ) ?: 'primary';
$first_name = get_user_meta( $user_id, 'first_name', TRUE );
$last_name  = get_user_meta( $user_id, 'last_name', TRUE );
$name       = ! ( $first_name || $last_name ) ? 'ثبت نشده' : $first_name . ' ' . $last_name;
$class      = $show_phone ? 'sm' : 'xs';
$gender     = get_user_meta( $user_id, 'gender', TRUE );

?>
<div class="user-card">
    <div class="user-avatar fs-18px <?php echo $class; ?> bg-<?php echo $user_color; ?>">
		<?php
		if ( $gender == 'female' ) {
			echo '<i class="uik-r fa-woman-head"></i>';
		} else {
			echo '<i class="uik-r fa-smile"></i>';
		}
		?>
    </div>
    <div class="user-info">
        <span class="tb-lead"><?php echo $name; ?></span>
		<?php
		if ( $show_phone ) {
			$phone = get_user_meta( $user_id, 'nooshika_phone_num', TRUE );
			?>
            <span class="sub-text"><?php echo $phone; ?></span>
			<?php
		}
		?>
    </div>
</div>
