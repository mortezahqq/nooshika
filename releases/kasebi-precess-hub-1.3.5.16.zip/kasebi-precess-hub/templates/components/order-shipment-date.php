<?php
if(!defined('ABSPATH'))exit;
$order_id=(int)($order_id??0);$value=is_scalar($value??null)?(string)$value:'';
$editable=($status??'')!=='canceled' && $DB->can_edit_order_shipment_date($order_id);
?>
<?php if(!$editable){ ?><span><?php echo esc_html($value?:'—'); ?></span><?php }else{ ?>
<div class="kph-order-shipment-date" data-order-id="<?php echo $order_id; ?>" data-current="<?php echo esc_attr($value); ?>" data-nonce="<?php echo esc_attr(wp_create_nonce('kph_order_shipment_date_'.$order_id)); ?>">
    <button type="button" class="btn btn-sm btn-link p-0 kph-shipment-date-edit" title="ویرایش تاریخ ارسال" aria-label="ویرایش تاریخ ارسال سفارش <?php echo $order_id; ?>"><span class="kph-shipment-date-label"><?php echo esc_html($value?:'—'); ?></span><em class="icon ni ni-edit-alt ms-1" aria-hidden="true"></em></button>
    <form class="kph-shipment-date-form d-none" aria-label="ویرایش تاریخ ارسال">
        <label class="visually-hidden" for="kph-shipment-<?php echo $order_id; ?>">تاریخ ارسال سفارش</label>
        <input type="text" id="kph-shipment-<?php echo $order_id; ?>" class="form-control form-control-sm datepicker" data-kph-hr-date="1" value="<?php echo esc_attr($value); ?>" placeholder="۱۴۰۵/۰۸/۲۴" autocomplete="off" aria-label="تاریخ ارسال شمسی">
        <div class="d-flex gap-1 mt-1"><button type="submit" class="btn btn-sm btn-primary"><em class="icon ni ni-check" aria-hidden="true"></em><span>ثبت</span></button><button type="button" class="btn btn-sm btn-light kph-shipment-date-cancel">لغو</button></div>
    </form>
    <span class="kph-shipment-date-message sub-text" role="status" aria-live="polite"></span>
</div>
<?php } ?>
