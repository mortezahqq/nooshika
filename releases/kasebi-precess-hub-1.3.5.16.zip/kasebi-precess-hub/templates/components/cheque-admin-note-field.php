<?php
if ( ! defined( 'ABSPATH' ) || ! current_user_can( 'manage_options' ) ) { return; }
$cheque_note_print_all = (string) get_option( 'kph_cheque_note_print_all', '0' ) === '1';
?>
<div class="col-12">
    <div class="form-group">
        <label class="form-label" for="new_cheque_admin_note">یادداشت داخلی <span class="text-soft">(فقط ادمین)</span></label>
        <div class="form-control-wrap">
            <textarea class="form-control" id="new_cheque_admin_note" data-for="admin_note" rows="3"
                      maxlength="5000" placeholder="یادداشت مربوط به این چک…"
                      aria-describedby="new_cheque_admin_note_help"></textarea>
        </div>
        <small class="form-text text-soft" id="new_cheque_admin_note_help">اختیاری؛ فقط برای ادمین قابل مشاهده است. چاپ آن با گزینه زیر انتخاب می‌شود.</small>
        <div class="cheque-note-individual-option<?php echo $cheque_note_print_all ? ' d-none' : ''; ?>"><label class="d-block mt-2"><input type="checkbox" data-for="admin_note_print" value="1"> نمایش یادداشت داخلی در چاپ این چک</label></div>
        <small class="text-soft cheque-note-global-hint<?php echo $cheque_note_print_all ? '' : ' d-none'; ?>">چاپ یادداشت داخلی برای همه چک‌ها فعال است.</small>
        <input type="hidden" data-for="admin_note_nonce" value="<?php echo esc_attr( wp_create_nonce( 'kph_cheque_admin_note' ) ); ?>">
    </div>
</div>
