<?php

$defaults = [
	'tab' => 'supplier_group',
];
$args     = wp_parse_args( $_REQUEST, $defaults );
extract( $args );

$tabs_list  = [
	'supplier_group'    => [
		'label' => 'دسته‌بندی محصولات تامین',
	],
	'supplier_products' => [
		'label' => 'محصولات تامین کنندگان',
	],
];
$DB         = new kph_db();
$categories = $DB->get_raw_categories();
$products   = $DB->get_raw_products();

?>
<div class="nk-block nk-block-lg">
    <div class="card card-preview">
        <div class="card-inner">
            <div class="row g-gs">
                <div class="col-md-4">
                    <ul class="nav link-list-menu border border-light round m-0" role="tablist">
						<?php
						foreach ( $tabs_list as $key => $user_option ) {
							$class = $tab == $key ? 'active' : '';
							?>
                            <li>
                                <a data-bs-toggle="tab" href="#<?php echo $key; ?>" class="<?php echo $class; ?>">
                                    <span><?php echo $user_option['label']; ?></span>
                                </a>
                            </li>
							<?php
						}
						?>
                    </ul>
                </div>
                <div class="col-md-8">
                    <div class="tab-content">
                        <div class="<?php echo $tab == 'supplier_group' ? 'tab-pane active show' : 'tab-pane'; ?>"
                             id="supplier_group">
                            <div class="card card-bordered mt-2">
                                <div class="card-inner p-0">
                                    <div class="nk-tb-list nk-tb-ulist is-compact">
                                        <div class="nk-tb-item nk-tb-head">
                                            <div class="nk-tb-col"><span class="sub-text">عنوان دسته</span></div>
                                            <div class="nk-tb-col"><span class="sub-text">اولویت</span></div>
                                            <div class="nk-tb-col nk-tb-col-tools text-end">
                                                <ul class="nk-tb-actions gx-2">
                                                    <li class="nk-tb-action">
                                                        <div class="btn btn-sm btn-icon"
                                                             data-bs-toggle="tooltip"
                                                             data-bs-placement="top"
                                                             data-bs-original-title="افزودن">
                                                            <a class="btn btn-sm btn-icon"
                                                               data-bs-toggle="modal"
                                                               data-bs-target="#addRawProductCategory">
                                                                <em class="icon ni ni-plus"></em>
                                                            </a>
                                                        </div>
                                                    </li>

                                                </ul>
                                            </div>
                                        </div>
										<?php
										if ( empty( $categories['items'] ) ) {
											echo '<div class="p-1 text-danger">موردی یافت نشد</div>';
										} else {
											foreach ( $categories['items'] as $index => $item ) {
												?>
                                                <div class="nk-tb-item">
                                                    <div class="nk-tb-col">
                                                        <div class="lead-text"><?php echo $item['title']; ?></div>
                                                    </div>
                                                    <div class="nk-tb-col">
                                                        <span><?php echo $item['sort_order']; ?></span>
                                                    </div>
                                                    <div class="nk-tb-col nk-tb-col-tools">
                                                        <ul class="nk-tb-actions gx-2">
                                                            <li>
																<?php
																echo kph_get_template( 'components/row-actions-dropdown.php', [
																	'actions' => [
																		[
																			'link'  => '',
																			'title' => 'ویرایش آیتم',
																			'icon'  => 'ni-edit',
																			'class' => 'edit_item',
																			'data'  => [
																				'modal'       => 'addRawProductCategory',
																				'title'       => $item['title'],
																				'sort_order'  => $item['sort_order'],
																				'category_id' => $item['id'],
																			],
																		],
																		[
																			'link'  => '',
																			'title' => 'حذف آیتم',
																			'icon'  => 'ni-trash',
																			'class' => 'delete_db_item',
																			'data'  => [
																				'page'    => '/crm/settings-products',
																				'item_id' => $item['id'],
																				'tab'     => 'supplier_group',
																				'action'  => 'kph_delete_raw_category',
																			],
																		],
																	],
																] );
																?>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
												<?php
											}
										}
										?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="<?php echo $tab == 'supplier_products' ? 'tab-pane active show' : 'tab-pane'; ?>"
                             id="supplier_products">
                            <div class="card card-bordered mt-2">
                                <div class="card-inner p-0">
                                    <div class="nk-tb-list nk-tb-ulist is-compact">
                                        <div class="nk-tb-item nk-tb-head">
                                            <div class="nk-tb-col"><span class="sub-text">عنوان محصول</span></div>
                                            <div class="nk-tb-col"><span class="sub-text">دسته بندی</span></div>
                                            <div class="nk-tb-col"><span class="sub-text">شناسه</span></div>
                                            <div class="nk-tb-col nk-tb-col-tools text-end">
                                                <ul class="nk-tb-actions gx-2">
                                                    <li class="nk-tb-action">
                                                        <div class="btn btn-sm btn-icon"
                                                             data-bs-toggle="tooltip"
                                                             data-bs-placement="top"
                                                             data-bs-original-title="افزودن">
                                                            <a class="btn btn-sm btn-icon"
                                                               data-bs-toggle="modal"
                                                               data-bs-target="#addRawProduct">
                                                                <em class="icon ni ni-plus"></em>
                                                            </a>
                                                        </div>
                                                    </li>

                                                </ul>
                                            </div>
                                        </div>
										<?php
										if ( empty( $products['items'] ) ) {
											echo '<div class="p-1 text-danger">موردی یافت نشد</div>';
										} else {
											foreach ( $products['items'] as $index => $item ) {
												$product_category = $DB->get_raw_category( $item['category_id'] );
												
												?>
                                                <div class="nk-tb-item">
                                                    <div class="nk-tb-col">
                                                        <div class="lead-text"><?php echo $item['title']; ?></div>
                                                    </div>
                                                    <div class="nk-tb-col">
														<?php
														echo isset( $product_category['item'] ) ?
															$product_category['item']['title'] :
															'-';
														?>
                                                    </div>
                                                    <div class="nk-tb-col">
                                                        <span><?php echo $item['code']; ?></span>
                                                    </div>
                                                    <div class="nk-tb-col nk-tb-col-tools">
                                                        <ul class="nk-tb-actions gx-2">
                                                            <li>
																<?php
																echo kph_get_template( 'components/row-actions-dropdown.php', [
																	'actions' => [
																		[
																			'link'  => '',
																			'title' => 'ویرایش آیتم',
																			'icon'  => 'ni-edit',
																			'class' => 'edit_item',
																			'data'  => [
																				'modal'       => 'addRawProduct',
																				'title'       => $item['title'],
																				'code'        => $item['code'],
																				'category_id' => $item['category_id'],
																				'product_id'  => $item['id'],
																			],
																		],
																		[
																			'link'  => '',
																			'title' => 'حذف آیتم',
																			'icon'  => 'ni-trash',
																			'class' => 'delete_db_item',
																			'data'  => [
																				'page'    => '/crm/settings-products',
																				'item_id' => $item['id'],
																				'tab'     => 'supplier_products',
																				'action'  => 'kph_delete_raw_product',
																			],
																		],
																	],
																] );
																?>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>
												<?php
											}
										}
										?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="modal fade zoom" id="addRawProductCategory">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
            <div class="modal-body">
                <h5 class="modal-title">افزودن آیتم</h5>
                <form action="#" class="mt-4 modal_form" data-action="kph_add_raw_category"
                      data-page="/crm/settings-products">
                    <div class="row g-gs">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="category_title">عنوان</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="category_title" data-for="title">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="category_sort_order">اولویت</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="category_sort_order"
                                           data-for="sort_order">
                                </div>
                            </div>
                        </div>
                        <input type="hidden" data-for="tab" value="supplier_group">
                        <input type="hidden" data-for="category_id" value="">
                        <div class="col-12">
                            <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                <li>
                                    <div class="btn btn-primary submit_modal_form">ثبت اطلاعات</div>
                                </li>
                                <li>
                                    <a href="#" class="link link-light" data-bs-dismiss="modal">لغو</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer bg-light">
                <span class="sub-text">دسته بندی تامین کنندگان نیز با همین دسته ها صورت می پذیرد.</span>
            </div>
        </div>
    </div>
</div>
<div class="modal fade zoom" id="addRawProduct">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
            <div class="modal-body">
                <h5 class="modal-title">افزودن آیتم</h5>
                <form action="#" class="mt-4 modal_form" data-action="kph_add_raw_product"
                      data-page="/crm/settings-products">
                    <div class="row g-gs">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="product_title">عنوان</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="product_title" data-for="title">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="product_code">شناسه محصول</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="product_code"
                                           data-for="code">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label class="form-label" for="product_category_id">دسته بندی محصول</label>
                                <div class="form-control-wrap">
                                    <select class="form-select" id="product_category_id"
                                            data-for="category_id">
										<?php
										if ( empty( $categories['items'] ) ) {
											echo '<option value="0">پیش از ثبت محصول بایستی دسته بندی ایجاد شود</option>';
										} else {
											foreach ( $categories['items'] as $index => $item ) {
												echo "<option value='{$item['id']}'>{$item['title']}</option>";
											}
										}
										?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <input type="hidden" data-for="tab" value="supplier_products">
                        <input type="hidden" data-for="product_id" value="">
                        <div class="col-12">
                            <ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2">
                                <li>
                                    <div class="btn btn-primary submit_modal_form">ثبت اطلاعات</div>
                                </li>
                                <li>
                                    <a href="#" class="link link-light" data-bs-dismiss="modal">لغو</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer bg-light"></div>
        </div>
    </div>
</div>