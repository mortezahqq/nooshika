<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
echo kph_get_template( 'partials/visitor-monthly-sales.php' );
$employees = get_users( [ 'fields' => 'ids', 'orderby' => 'ID', 'order' => 'DESC', 'role__in' => [ 'visitor' ] ] );
$DB = new kph_db();
$visitor_summaries = $DB->get_visitor_summaries( $employees );
$active_count = count( array_filter( $visitor_summaries, fn( $s ) => $s['target_amount'] > 0 ) );
?>
<section class="kph-visitors">
    <div class="kv-heading"><div><h3>ویزیتورها</h3><p>مانده مشتریان، سفارش‌های باز و هدف فروش تیم</p></div>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addVisitor"><em class="icon ni ni-plus" aria-hidden="true"></em><span>افزودن ویزیتور</span></button>
    </div>
    <div class="kv-overview">
        <div class="kv-stat"><span class="kv-stat-label">اعضای تیم فروش</span><div class="kv-stat-value"><bdi class="kv-number"><?php echo count( $employees ); ?></bdi><small>ویزیتور</small></div></div>
        <div class="kv-stat"><span class="kv-stat-label">سفارش‌های باز تیم</span><div class="kv-stat-value"><bdi class="kv-number"><?php echo number_format( array_sum( array_column( $visitor_summaries, 'open_orders' ) ) ); ?></bdi><small>سفارش</small></div></div>
        <div class="kv-stat"><span class="kv-stat-label">ویزیتورهای دارای تارگت فعال</span><div class="kv-stat-value"><bdi class="kv-number"><?php echo $active_count; ?></bdi><small>از <?php echo count( $employees ); ?> نفر</small></div></div>
    </div>
    <?php if ( $employees ) { ?>
    <div class="kv-toolbar"><div class="kv-search"><label class="visually-hidden" for="kv-visitor-search">جستجوی نام یا نام کاربری ویزیتور</label><em class="icon ni ni-search" aria-hidden="true"></em><input type="search" class="form-control" id="kv-visitor-search" placeholder="جستجوی نام یا نام کاربری…" autocomplete="off" aria-controls="kv-visitor-grid"></div><span class="kv-muted" id="kv-search-count" role="status"><?php echo count( $employees ); ?> ویزیتور</span></div>
    <?php } ?>
    <div class="kv-grid" id="kv-visitor-grid">
    <?php foreach ( $employees as $user_id ) {
        $summary = $visitor_summaries[ $user_id ];
        $name = get_user_name_by_id( $user_id );
        $user_login = get_user_by( 'ID', $user_id )->user_login;
        $url = "/crm/employee/$user_id?tab=targets";
    ?>
        <article class="kv-visitor-card" data-visitor-search="<?php echo esc_attr( $name . ' ' . $user_login ); ?>">
            <div class="kv-card-top"><div class="kv-person"><span class="kv-avatar"><em class="icon ni ni-user" aria-hidden="true"></em></span><div><h6><a class="page_activator" href="<?php echo esc_url( $url ); ?>" data-url="<?php echo esc_url( $url ); ?>"><?php echo esc_html( $name ); ?></a></h6><small><bdi dir="ltr">@<?php echo esc_html( $user_login ); ?></bdi></small></div></div>
                <?php $actions = [
									[
										'link'  => '/crm/employee/' . $user_id . '?tab=profile',
										'title' => 'مشخصات ویزیتور',
										'icon'  => 'ni-eye',
										'class' => 'page_activator',
									],
									[
										'link'  => '',
										'title' => 'ورود با ویزیتور',
										'icon'  => 'ni-signin',
										'class' => 'login_as_this',
										'data'  => [
											'id' => $user_id,
										],
									],
									[ 'divider' => 'divider' ],
									[
										'link'  => '',
										'title' => 'بازنشانی رمز عبور',
										'icon'  => 'ni-repeat',
										'class' => 'reset_password',
										'data'  => [
											'id' => $user_id,
										],
									],
									[
										'link'  => '',
										'title' => 'حذف ویزیتور',
										'icon'  => 'ni-user-cross',
										'class' => 'delete_user',
										'data'  => [
											'user-id' => $user_id,
										],
									],
								];
								echo kph_get_template( 'components/row-actions-dropdown.php', [
									'actions' => $actions, 'title' => 'عملیات ویزیتور', 'main_icon' => 'more-h',
								] );
								 ?>
            </div>
            <div class="kv-balance"><div class="kv-balance-head"><span>مانده خالص مشتریان</span><span class="kv-pill <?php echo $summary['customer_balance'] > 0 ? 'kv-pill--warning' : 'kv-pill--success'; ?>"><?php echo $summary['customer_balance'] > 0 ? 'بدهکار' : ( $summary['customer_balance'] < 0 ? 'بستانکار' : 'تسویه' ); ?></span></div><div class="kv-money"><bdi class="kv-number"><?php echo number_format( abs( $summary['customer_balance'] ) ); ?></bdi><small>ریال</small></div></div>
            <dl class="kv-card-metrics"><div><dt>سفارش باز</dt><dd><bdi class="kv-number"><?php echo number_format( $summary['open_orders'] ); ?></bdi> سفارش</dd></div><div><dt>تارگت فعال <small>(ریال)</small></dt><dd><?php echo $summary['target_amount'] > 0 ? '<bdi class="kv-number">' . number_format( $summary['target_amount'] ) . '</bdi>' : '<span class="kv-muted">تعیین نشده</span>'; ?></dd></div></dl>
            <a class="kv-card-link page_activator" href="<?php echo esc_url( $url ); ?>" data-url="<?php echo esc_url( $url ); ?>"><span>عملکرد و تارگت فروش</span><em class="icon ni ni-arrow-left" aria-hidden="true"></em></a>
        </article>
    <?php } ?>
    </div>
    <?php if ( ! $employees ) { ?><div class="kv-empty"><em class="icon ni ni-users" aria-hidden="true"></em><h6>هنوز ویزیتوری اضافه نشده</h6><p>اولین عضو تیم فروش را اضافه کنید تا سفارش‌ها و تارگت او را مدیریت کنید.</p><button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addVisitor">افزودن اولین ویزیتور</button></div><?php } ?>
    <div class="kv-empty" id="kv-search-empty" hidden><em class="icon ni ni-search" aria-hidden="true"></em><h6>ویزیتوری پیدا نشد</h6><p>نام یا نام کاربری دیگری را جستجو کنید.</p><button type="button" class="btn btn-light" id="kv-clear-search">پاک‌کردن جستجو</button></div>
</section>
