<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

// This page is also reachable through panel AJAX. Never trust an ID from the request.
$user_id = get_current_user_id();
if ( ! is_user_logged_in() || nooshika_get_user_role( $user_id ) !== 'visitor' ) {
    echo '<div class="alert alert-warning" role="alert">این بخش مخصوص حساب ویزیتور است.</div>';
    return;
}
$DB = new kph_db();
$targets = $DB->get_visitor_targets( $user_id );
$today = current_time( 'Y-m-d' );
$can_manage = FALSE;
$active_targets = $upcoming_targets = $history_targets = [];
foreach ( $targets as $id => $target ) {
    if ( $target['date_to'] < $today ) {
        $history_targets[ $id ] = $target;
    } elseif ( $target['date_from'] > $today ) {
        $upcoming_targets[ $id ] = $target;
    } else {
        $active_targets[ $id ] = $target;
    }
}
uasort( $upcoming_targets, fn( $a, $b ) => strcmp( $a['date_from'], $b['date_from'] ) );
uasort( $history_targets, fn( $a, $b ) => strcmp( $b['date_to'], $a['date_to'] ) );
$active_amount = array_sum( array_column( $active_targets, 'amount' ) );
$active_sales = array_sum( array_column( $active_targets, 'sales' ) );
$active_bonus = array_sum( array_column( $active_targets, 'bonus' ) );
?>
<section class="kph-visitor-page" aria-labelledby="my-targets-heading">
    <div class="kv-heading">
        <div><h3 id="my-targets-heading">تارگت و پاداش من</h3><p><?php echo esc_html( get_user_name_by_id( $user_id ) ); ?>، پیشرفت فروش و وضعیت پاداش خود را اینجا ببینید.</p></div>
        <a class="btn btn-outline-primary page_activator" href="<?php echo esc_url( home_url( '/crm/subscriber-financial' ) ); ?>" data-url="/crm/subscriber-financial"><em class="icon ni ni-coin-alt" aria-hidden="true"></em><span>حسابداری من</span></a>
    </div>
    <?php if ( $active_targets ) { ?>
    <div class="kv-overview">
        <div class="kv-stat"><span class="kv-stat-label">هدف فروش فعلی</span><div class="kv-stat-value"><bdi class="kv-number"><?php echo number_format( $active_amount ); ?></bdi><small>ریال</small></div><p class="kv-help">مجموع هدف فروش در بازه فعال</p></div>
        <div class="kv-stat"><span class="kv-stat-label">فروش محقق‌شده</span><div class="kv-stat-value"><bdi class="kv-number"><?php echo number_format( $active_sales ); ?></bdi><small>ریال</small></div><p class="kv-help">فروش ارسال‌شده پس از کسر تخفیف و برگشت</p></div>
        <div class="kv-stat"><span class="kv-stat-label">پاداش تحقق هدف</span><div class="kv-stat-value"><bdi class="kv-number"><?php echo number_format( $active_bonus ); ?></bdi><small>ریال</small></div><p class="kv-help">جدا از پورسانت محصولات؛ وضعیت ثبت در کارت زیر</p></div>
    </div>
    <div class="kv-section-heading"><h5>تارگت فعال من</h5></div>
    <?php foreach ( $active_targets as $id => $target ) { echo kph_get_template( 'components/visitor-target-card.php', compact( 'target', 'id', 'user_id', 'can_manage', 'today' ) ); } ?>
    <?php } else { ?>
    <div class="kv-empty"><em class="icon ni ni-growth" aria-hidden="true"></em><h6><?php echo $targets ? 'در حال حاضر تارگت فعالی ندارید' : 'هنوز تارگتی برای شما تعریف نشده است'; ?></h6><p><?php echo $upcoming_targets ? 'تارگت بعدی شما در بخش پیش‌رو نمایش داده شده و از تاریخ شروع محاسبه می‌شود.' : 'پس از تعریف تارگت توسط مدیر، هدف فروش و پاداش شما در این بخش نمایش داده می‌شود.'; ?></p></div>
    <?php } ?>
    <?php if ( $upcoming_targets ) { ?>
    <div class="kv-section-heading"><h5>تارگت‌های پیش‌رو</h5><span class="kv-pill"><?php echo count( $upcoming_targets ); ?> تارگت</span></div>
    <?php foreach ( $upcoming_targets as $id => $target ) { echo kph_get_template( 'components/visitor-target-card.php', compact( 'target', 'id', 'user_id', 'can_manage', 'today' ) ); } ?>
    <?php } ?>
    <?php if ( $history_targets ) { ?>
    <details class="kv-history"><summary>سوابق تارگت و پاداش من <span class="kv-pill"><?php echo count( $history_targets ); ?> بازه پایان‌یافته</span></summary>
        <?php foreach ( $history_targets as $id => $target ) { echo kph_get_template( 'components/visitor-target-card.php', compact( 'target', 'id', 'user_id', 'can_manage', 'today' ) ); } ?>
    </details>
    <?php } ?>
    <details class="kv-rules"><summary>پاداش من چگونه محاسبه می‌شود؟</summary><ul>
        <li>فروش ارسال‌شده در بازه تارگت، پس از کسر تخفیف و برگشت کالا، مبنای پیشرفت است.</li>
        <li>با رسیدن به هدف، پاداش تعیین‌شده علاوه بر پورسانت در حساب شما ثبت می‌شود. ثبت پاداش به معنی پرداخت آن نیست؛ گردش حساب را در «حسابداری من» ببینید.</li>
        <li>اگر برگشت کالا فروش را زیر هدف ببرد، پاداش اصلاح می‌شود و با تحقق مجدد هدف دوباره ثبت خواهد شد.</li>
        <li>تعریف و تغییر تارگت توسط مدیر انجام می‌شود.</li>
    </ul></details>
</section>
