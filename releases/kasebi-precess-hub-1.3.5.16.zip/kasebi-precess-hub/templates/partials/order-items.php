<?php
/**
 * @var int     $order_id
 * @var \kph_db $DB
 */
$order_data = $DB->get_order_data( $order_id );
$items      = $order_data['items'];
?>
<?php if ( ( $order_data['display_status'] ?? '' ) === 'returned' ) : ?>
<div class="alert alert-warning mb-3">این سفارش به‌طور کامل مرجوع شده است؛ سوابق خروج و بازگشت کالا برای پیگیری حفظ شده‌اند.</div>
<?php elseif ( ( $order_data['display_status'] ?? '' ) === 'canceled' ) : ?>
<div class="alert alert-secondary mb-3">تمام اقلام این سفارش لغو شده‌اند.</div>
<?php endif; ?>
<div class="card mb-3">
    <div class="nk-tb-list nk-tb-ulist is-compact">
        <div class="nk-tb-item nk-tb-head">
            <div class="nk-tb-col"><span class="sub-text">نام محصول</span></div>
            <div class="nk-tb-col"><span class="sub-text">قیمت پایه</span></div>
            <div class="nk-tb-col"><span class="sub-text">تعداد</span></div>
            <div class="nk-tb-col"><span class="sub-text">درصد تخفیف</span></div>
            <div class="nk-tb-col"><span class="sub-text">تعداد ارسال شده</span></div>
            <div class="nk-tb-col"><span class="sub-text">بهای تمام‌شده هر آیتم</span></div>
            <div class="nk-tb-col"><span class="sub-text">جمع کل</span></div>
            <div class="nk-tb-col text-end nk-tb-col-tools"></div>
        </div>
		<?php
		foreach ( $items as $entry ) {
			$total_send        = (int) $entry['shipped_paid_qty'] + (int) $entry['shipped_free_qty'];
			$remaining         = (int) $entry['remaining_paid_qty'] + (int) $entry['remaining_free_qty'];
			$has_inventory     = ! empty( $entry['inventory_id'] );
			$max               = 0;
			$inventory_options = [];
			if ( $has_inventory ) {
				$inventory = $DB->get_inventory_item( (int) $entry['inventory_id'] );
				$available = $inventory ? (int) $inventory['qty_available'] : 0;
				$max       = min( $remaining, $available );
			} else {
				$inventories = $DB->get_inventory_items( [
					'product_id'     => (int) $entry['wc_product_id'],
					'only_available' => TRUE,
					'per_page'       => 100,
					'orderby'        => 'unique_product_code',
					'order'          => 'ASC',
				] );
				
				foreach ( $inventories['items'] ?? [] as $inv ) {
					$inventory_options[] = [
						'value' => (string) $inv['id'],
						'label' => sprintf(
							'%s - موجودی: %s',
							$inv['unique_product_code'],
							number_format( (int) $inv['qty_available'] )
						),
					];
				}
				
				$max = $inventory_options ? $remaining : 0;
			}
			
			$cogs_total = $total_send ? ( $entry['cogs_total'] / $total_send ) : 0;
			?>
            <div class="nk-tb-item">
                <div class="nk-tb-col">
                    <div class="user-card">
                        <div class="user-info">
                            <span class="tb-lead"><?php echo get_the_title( $entry['wc_product_id'] ); ?></span>
                            <span
                                class="sub-text"><?php echo $entry['unique_product_code'] ?: 'بدون اختصاص موجودی'; ?></span>
                        </div>
                    </div>
                </div>
                <div class="nk-tb-col">
                    <span><?php echo number_format( $entry['base_price'] ); ?></span>
                </div>
                <div class="nk-tb-col">
                    <strong class="fs-14px"><?php echo $entry['qty_ordered']; ?> عدد</strong>
					<?php
					if ( $entry['expected_free_qty'] ) {
						?><span class="sub-text">
                        +<?php echo $entry['expected_free_qty']; ?> هدیه</span><?php
					}
					?>
                </div>
                <div class="nk-tb-col">
					<?php echo round( $entry['discount_cash_value'], 2 ); ?>%
                </div>
                <div class="nk-tb-col">
                    <strong class="fs-14px"><?php echo $entry['shipped_paid_qty']; ?> عدد</strong>
					<?php
					if ( $entry['shipped_free_qty'] ) {
						?><span class="sub-text">
                        +<?php echo $entry['shipped_free_qty']; ?> هدیه</span><?php
					}
					?>
                </div>
                <div class="nk-tb-col">
                    <span><?php echo number_format( $cogs_total ); ?></span>
                </div>
                <div class="nk-tb-col">
                    <span><?php echo number_format( $entry['final_amount'] ); ?></span>
                </div>
                <div class="nk-tb-col nk-tb-col-tools">
                    <ul class="nk-tb-actions gx-2">
                        <li>
							<?php
							$actions = [];
							if (
								in_array( $order_data['status'], [ 'shipped', 'shortage' ], TRUE )
								&& ( (int) $entry['shipped_paid_qty'] > 0 || (int) $entry['shipped_free_qty'] > 0 )
							) {
								$actions['refund'] = [
									'title' => 'بازگشت سفارش',
									'icon'  => 'ni-package',
									'class' => 'row_inline_action',
									'data'  => [
										'action'     => 'kph_cancel_sended_product',
										'item-id'    => $entry['id'],
										'swal-title' => 'بازگشت سفارش',
										'needs'      => wp_json_encode( [
											[
												'type'  => 'text',
												'label' => 'تعداد کالای پولی برای برگشت (حداکثر ' . (int) $entry['shipped_paid_qty'] . '):',
												'key'   => 'refund_qty',
												'value' => (int) $entry['shipped_paid_qty'],
												'max'   => (int) $entry['shipped_paid_qty'],
											],
											[
												'type'  => 'text',
												'label' => 'تعداد کالای هدیه برای برگشت (حداکثر ' . (int) $entry['shipped_free_qty'] . '):',
												'key'   => 'free_qty',
												'value' => (int) $entry['shipped_free_qty'],
												'max'   => (int) $entry['shipped_free_qty'],
											],
										] ),
									],
								];
							}
							if ( in_array( $order_data['status'], [ 'registered', 'shortage', 'shipped' ], TRUE ) && $remaining > 0 ) {
								$send_needs = [];
								
								if ( ! $has_inventory ) {
									$send_needs[] = [
										'type'    => 'select',
										'label'   => 'موجودی ارسال را انتخاب کنید.',
										'key'     => 'inventory_id',
										'options' => $inventory_options,
									];
								}
								
								$send_needs[] = [
									'type'  => 'text',
									'label' => 'تعداد ارسالی را وارد نمایید. حداکثر:' . $max,
									'key'   => 'total_qty',
									'max'   => $max,
								];
								
								$send_needs[] = [
									'type'  => 'text',
									'label' => 'شیوه ارسال بار',
									'key'   => 'shipping_method',
								];
								
								$send_data = [
									'action'     => 'kph_add_order_item_fulfillment',
									'item-id'    => $entry['id'],
									'swal-title' => $has_inventory ? 'ثبت ارسال سفارش' : 'اختصاص موجودی و ثبت ارسال',
									'needs'      => wp_json_encode( $send_needs ),
								];
								
								if ( $has_inventory ) {
									$send_data['inventory-id'] = $entry['inventory_id'];
								}
								
								$actions['send']   = [
									'title' => $has_inventory ? 'ارسال' : 'اختصاص موجودی و ارسال',
									'icon'  => $has_inventory ? 'ni-send' : 'ni-package',
									'class' => 'row_inline_action',
									'data'  => $send_data,
								];
								$actions['delete'] = [
									'title' => 'لغو باقیمانده',
									'icon'  => 'ni-trash-alt',
									'class' => 'row_inline_action',
									'data'  => [
										'action'     => 'kph_cancel_remaining_item',
										'item-id'    => $entry['id'],
										'qty'        => $entry['remaining_paid_qty'],
										'free_qty'   => $entry['remaining_free_qty'],
										'swal-title' => 'لغو باقیمانده سفارش',
										'needs'      => wp_json_encode( [] ),
									],
								];
								if ( $max < 1 ) {
									unset( $actions['send'] );
								}
							}
							if ( $actions ) {
								echo kph_get_template( 'components/row-actions-dropdown.php', [
									'actions' => $actions,
								] );
							}
							?>
                        </li>
                    </ul>
                </div>
            </div>
			<?php
		}
		?>
    </div>
</div>
<div class="alert alert-warning alert-icon">
    <em class="icon ni ni-alert-circle"></em> بهای تمام‌شده فقط برای کالاهایی که برای مشتری ارسال شدند محاسبه میگردد.
</div><?php
$sms_items = [
	'completed' => [
		'label'     => 'پیامک تکمیل سفارش',
		'btn_class' => 'success',
		'data'      => [
			'action'   => 'kph_send_order_sms',
            'nonce'    => wp_create_nonce('kph_order_sms_'.(int)$order_id),
			'template' => 'completed-order',
			'order_id' => $order_id,
			'needs'    => [
				[
					'type'  => 'text',
					'label' => 'شیوه ارسال بار',
					'key'   => 'shipping_method',
				],
			],
		],
	],
	'shortage'  => [
		'label'     => 'پیامک کسری',
		'btn_class' => 'warning',
		'data'      => [
			'action'   => 'kph_send_order_sms',
            'nonce'    => wp_create_nonce('kph_order_sms_'.(int)$order_id),
			'template' => 'order2',
			'order_id' => $order_id,
			'needs'    => [
				[
					'type'  => 'text',
					'label' => 'شیوه ارسال بار',
					'key'   => 'shipping_method',
				],
			],
		],
	],
	'shipped'   => [
		'label'     => 'پیامک ارسال باقیمانده',
		'btn_class' => 'info',
		'data'      => [
			'action'   => 'kph_send_order_sms',
            'nonce'    => wp_create_nonce('kph_order_sms_'.(int)$order_id),
			'template' => 'order3',
			'order_id' => $order_id,
			'needs'    => [
				[
					'type'  => 'text',
					'label' => 'شیوه ارسال بار',
					'key'   => 'shipping_method',
				],
			],
		],
	],
];
?>

<ul class="align-center flex-wrap flex-sm-nowrap gx-4 gy-2 mt-2 justify-end">
	<?php foreach ( $sms_items as $sms_item ) : ?>
        <li>
            <div
                class="btn btn-<?php echo esc_attr( sanitize_html_class( $sms_item['btn_class'] ) ); ?> order_action_btn"
				
				<?php foreach ( $sms_item['data'] as $data_key => $data_value ) : ?>
					<?php
					$data_key = str_replace(
						'_',
						'-',
						sanitize_key( $data_key )
					);
					
					if ( is_array( $data_value ) || is_object( $data_value ) ) {
						$data_value = wp_json_encode(
							$data_value,
							JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
						);
					}
					?>

                    data-<?php echo esc_attr( $data_key ); ?>="<?php echo esc_attr( $data_value ); ?>"
				<?php endforeach; ?>
            >
				<?php echo esc_html( $sms_item['label'] ); ?>
            </div>
        </li>
	<?php endforeach; ?>
</ul>