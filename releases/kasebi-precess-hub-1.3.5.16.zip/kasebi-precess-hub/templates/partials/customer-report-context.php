<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
// Shared whitelist for page links and print requests. Only effective filters are carried forward.
$customer_filter_args = [];
foreach ( [ 'level', 'balance_side', 'sort', 'search' ] as $key ) {
	$customer_filter_args[$key] = isset( $report_request[$key] ) && is_scalar( $report_request[$key] ) ? sanitize_text_field( (string) $report_request[$key] ) : '';
	if ( $key !== 'search' && $customer_filter_args[$key] === '0' ) { $customer_filter_args[$key] = ''; }
}
$customer_report_args = $customer_filter_args;
if ( isset( $report_request['date'] ) && ! is_array( $report_request['date'] ) ) { wp_die( 'تاریخ گزارش معتبر نیست.' ); }
foreach ( [ 'from', 'to' ] as $key ) {
	$value = $report_request['date'][$key] ?? '';
	if ( ! is_string( $value ) ) { wp_die( 'تاریخ گزارش معتبر نیست.' ); }
	$value = trim( strtr( $value, [ '۰'=>'0', '۱'=>'1', '۲'=>'2', '۳'=>'3', '۴'=>'4', '۵'=>'5', '۶'=>'6', '۷'=>'7', '۸'=>'8', '۹'=>'9',
		'٠'=>'0', '١'=>'1', '٢'=>'2', '٣'=>'3', '٤'=>'4', '٥'=>'5', '٦'=>'6', '٧'=>'7', '٨'=>'8', '٩'=>'9', '/' => '-' ] ) );
	// The Persian picker emits unpadded month/day values. Either bound may be empty.
	if ( $value !== '' ) {
		if ( ! preg_match( '/^(1[34][0-9]{2})-(0?[1-9]|1[0-2])-(0?[1-9]|[12][0-9]|3[01])$/D', $value, $parts ) ) {
			wp_die( 'تاریخ گزارش معتبر نیست.' );
		}
		$year = (int) $parts[1];
		$month = (int) $parts[2];
		$day = (int) $parts[3];
		$max_day = $month <= 6 ? 31 : 30;
		if ( $month === 12 ) {
			$year_start = new DateTimeImmutable( nooshika_jalali_to_gregorian( $year . '-01-01' ), wp_timezone() );
			$next_year = new DateTimeImmutable( nooshika_jalali_to_gregorian( ( $year + 1 ) . '-01-01' ), wp_timezone() );
			$max_day = (int) $year_start->diff( $next_year )->format( '%a' ) === 366 ? 30 : 29;
		}
		if ( $day > $max_day ) { wp_die( 'تاریخ گزارش معتبر نیست.' ); }
		$value = sprintf( '%04d-%02d-%02d', $year, $month, $day );
	}
	$customer_filter_args['date'][$key] = $value;
	$gregorian = $value !== '' ? nooshika_jalali_to_gregorian( $value ) : '';
	if ( $value !== '' ) {
		$parsed = DateTimeImmutable::createFromFormat( '!Y-m-d', (string) $gregorian, wp_timezone() );
		if ( ! $parsed || $parsed->format( 'Y-m-d' ) !== $gregorian ) { wp_die( 'تاریخ گزارش معتبر نیست.' ); }
	}
	$customer_report_args['date_' . $key] = $gregorian;
}
if ( $customer_report_args['date_from'] && $customer_report_args['date_to'] && $customer_report_args['date_from'] > $customer_report_args['date_to'] ) { wp_die( 'بازهٔ گزارش معتبر نیست.' ); }
$due_state = is_string( $report_request['due_state'] ?? NULL ) ? $report_request['due_state'] : 'all';
if ( ! in_array( $due_state, [ 'all', 'overdue', 'upcoming', 'unknown', 'unassigned_debt' ], TRUE ) ) { $due_state = 'all'; }
$customer_filter_args['due_state'] = $due_state;
$customer_print_button = static function ( string $section, string $label, int $order_id = 0, ?int $customer = NULL ) use ( $customer_filter_args, $selected_customer_id ): string {
	$url = add_query_arg( array_merge( $customer_filter_args, [ 'action' => 'print', 'type' => 'customers-report', 'section' => $section, 'customer_id' => $customer ?? $selected_customer_id, 'order_id' => $order_id ] ), home_url( '/crm' ) );
	return '<a class="btn btn-sm btn-outline-primary no-print" href="' . esc_url( $url ) . '" target="_blank" rel="noopener"><em class="icon ni ni-printer" aria-hidden="true"></em><span>' . esc_html( $label ) . '</span></a>';
};
