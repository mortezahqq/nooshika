<?php
/**
 * @var array   $moves
 * @var \kph_db $DB
 */
$moves    = $moves['items'];
$statuses = $DB->get_cheque_statuses();
if ( ! $moves ) {
	echo "<div class='no-item-found'>گردشی برای این چک ثبت نشده است</div>";
} else {
	foreach ( $moves as $move ) {
		extract( $move );
		$description = '';
		switch ( $action ) {
			case 'receive':
				$description = 'چک از مشتری دریافت و در سیستم ثبت شد.';
				break;
			
			case 'endorse':
				$name        = $holder_user_id ? get_user_name_by_id( $holder_user_id ) : 'کاربر';
				$description = "چک به $name منتقل شد.";
				break;
			
			case 'return':
				$description = 'چک به سیستم بازگردانده شد.';
				break;
			
			case 'clear':
				$description = 'چک پاس شد و تسویه انجام گردید.';
				break;
			
			case 'bounce':
				$description = 'چک برگشت خورد و پاس نشد.';
				break;
			
			case 'cancel':
				$description = 'چک لغو شد.';
				break;
			
			case 'note':
				$description = $note
					? 'یادداشت: ' . $note
					: 'برای این چک یادداشتی ثبت شد.';
				break;
			
			default:
				$description = 'حرکت نامشخص برای چک ثبت شده است.';
				break;
		}
		?>
        <div class="bq-note mb-2">
            <div class="bq-note-item">
                <div class="bq-note-text">
					<?php
					echo $description;
					if ( $status_from != $status_to ) {
						?>
                        <div class="d-flex mt-1" style="gap: 5px">
                            <span class="sub-text">تغییر وضعیت چک:</span>
                            <span class="badge <?php echo $statuses[ $status_from ]['class']; ?>">
                                <?php echo $statuses[ $status_from ]['label']; ?>
                            </span>
                            <span class="sub-text">به</span>
                            <span class="badge <?php echo $statuses[ $status_to ]['class']; ?>">
                                <?php echo $statuses[ $status_to ]['label']; ?>
                            </span>
                        </div>
						<?php
					}
					?>
                </div>
                <div class="bq-note-meta d-flex">
                    <div class="bq-note-added">
                        ثبت شده در
                        <span class="date text-base">
                            <?php echo date_i18n( 'j F Y', strtotime( $created_at ) ); ?></span>
                        ساعت
                        <span class="time text-base"><?php echo date_i18n( 'H:i', strtotime( $created_at ) ); ?></span>
                    </div>
                    <span class="bq-note-sep sep">|</span>
                    <div class="bq-note-by">توسط
                        <span class="text-base"><?php echo get_user_name_by_id( $actor_user_id ); ?></span>
                    </div>
                </div>
            </div>
        </div>
		<?php
	}
}