<?php
/**
 * @var int     $pack_id
 * @var \kph_db $DB
 */
if ( ! $pack_id ) {
	echo "<div class='no-item-found'>آیتم مخزن یافت نشد</div>";
} else {
	$moves = $DB->get_processing_packaging_transfers( [
		'processing_pack_id' => $pack_id,
		'per_page'           => 500,
	] );
	$moves = $moves['items'];
	foreach ( $moves as $move ) {
		extract( $move );
		$description = match ( $reason ) {
			'from_processing' => 'انتقال به سالن',
			'return_to_processing' => 'بازگشت از سالن',
			default => 'حرکت نامشخص برای آیتم ثبت شده است.',
		};
		?>
        <div class="bq-note mb-2">
            <div class="bq-note-item">
                <div class="bq-note-text">
					<?php echo $description; ?>
                    <div class="card-amount">
                        <div class="amount fw-bold <?php echo $direction == 'in' ? 'text-success' : 'text-danger'; ?>">
							<?php echo number_format( (float) $move['qty_weight'], 4, '.', '' ); ?>
                            <small class="currency currency-usd fs-12px">کیلوگرم</small>
                        </div>
                    </div>
                </div>
                <div class="bq-note-meta d-flex">
                    <div class="bq-note-added">
                        ثبت شده در
                        <span class="date text-base">
                            <?php echo date_i18n( 'j F Y', strtotime( $created_at ) ); ?></span>
                        ساعت
                        <span class="time text-base"><?php echo date_i18n( 'H:i', strtotime( $created_at ) ); ?></span>
                    </div>
                </div>
            </div>
        </div>
		<?php
	}
}