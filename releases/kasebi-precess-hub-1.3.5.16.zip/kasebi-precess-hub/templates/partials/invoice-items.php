<?php
/**
 * @var array   $invoice_data
 * @var \kph_db $DB
 */
$invoice = $invoice_data['invoice'];
if ( ! $invoice ) {
	echo "<div class='no-item-found'>{$invoice_data['error']}</div>";
} else {
	$states      = $DB->get_supplier_invoice_settlement_remaining( $invoice['id'] );
	$payments    = $states['data'];
	$customer_id = $invoice['supplier_user_id'];
	$group       = get_user_meta( $customer_id, 'kph_supplier_group', TRUE );
	?>
    <div class="nk-block">
        <div class="nk-tb-list nk-tb-ulist is-compact v-align-top border border-1 text-dark">
            <div class="nk-tb-item nk-tb-head">
                <div class="nk-tb-col w-80px"><span class="sub-text">شناسه</span></div>
                <div class="nk-tb-col"><span class="sub-text">عنوان محصول</span></div>
                <div class="nk-tb-col w-80px"><span class="sub-text">وزن خالص</span></div>
                <div class="nk-tb-col w-140px"><span class="sub-text">قیمت واحد</span></div>
				<?php
				if ( $group == 1 ) {
					?>
                    <div class="nk-tb-col w-80px"><span class="sub-text">کارمزد</span></div>
                    <div class="nk-tb-col w-100px"><span class="sub-text">ماه تسویه</span></div>
                    <div class="nk-tb-col w-140px"><span class="sub-text">هر کیلو تمام شده</span></div>
					<?php
				}
				?>
                <div class="nk-tb-col text-end"><span class="sub-text">جمع کل</span></div>
                <div class="nk-tb-col text-end nk-tb-col-tools"></div>
            </div>
			<?php
			$pre = 0;
			foreach ( $invoice_data['items'] as $invoice_item ) {
				$meta = $DB->get_invoice_item_meta( $invoice_item['id'] );
				$pre  += $meta['per_unit_base'][0] * $invoice_item['qty_weight'];
				?>
                <div class="nk-tb-item">
                    <div class="nk-tb-col w-80px"><?php echo $invoice_item['raw_product_code']; ?></div>
                    <div class="nk-tb-col"><?php echo $invoice_item['raw_product_title']; ?></div>
                    <div class="nk-tb-col w-80px">
						<?php echo number_format( $invoice_item['qty_weight'], 4, '.', '' ); ?>
                    </div>
                    <div class="nk-tb-col w-140px"><?php echo number_format( $meta['per_unit_base'][0] ); ?></div>
					<?php
					if ( $group == 1 ) {
						?>
                        <div class="nk-tb-col w-80px"><?php echo number_format( $meta['rate'][0] ); ?></div>
                        <div class="nk-tb-col w-100px"><?php echo $meta['month'][0]; ?></div>
                        <div class="nk-tb-col w-140px"><?php echo number_format( $invoice_item['unit_price'] ); ?></div>
						<?php
					}
					?>
                    <div class="nk-tb-col text-end"><?php echo number_format( $invoice_item['line_total'] ); ?></div>
                    <div class="nk-tb-col nk-tb-col-tools">
                        <ul class="nk-tb-actions gx-2">
                            <li>
								<?php
								if ( $group == 1 && $invoice_data['invoice']['status'] == 'confirmed' ) {
									$actions = [
										'send' => [
											'title' => 'ویرایش کارمزد / مدت',
											'icon'  => 'ni-edit',
											'class' => 'row_inline_action',
											'data'  => [
												'action'     => 'kph_edit_invoice_item_rate',
												'item-id'    => $invoice_item['id'],
												'swal-title' => 'ویرایش جزئیات پرداخت',
												'needs'      => json_encode( [
													[
														'type'  => 'text',
														'label' => 'میزان کارمزد',
														'key'   => 'item_rate',
													],
													[
														'type'  => 'text',
														'label' => 'ماه تسویه',
														'key'   => 'item_month',
													],
												] ),
											],
										],
									];
									echo kph_get_template( 'components/row-actions-dropdown.php', [
										'actions' => $actions,
									] );
								}
								?>
                            </li>
                        </ul>
                    </div>
                </div>
				<?php
			}
			?>
        </div>
    </div>
    <div class="nk-block mb-3">
        <div class=" table-borderless nk-tb-list nk-tb-ulist is-compact v-align-top text-dark">
			<?php
			if ( $group == 1 ) {
				?>
                <div class="nk-tb-item">
                    <div class="nk-tb-col w-70 border-bottom-0"></div>
                    <div class="nk-tb-col w-140px border-bottom-0">جمع کل</div>
                    <div class="nk-tb-col w-80px border-bottom-0"></div>
                    <div
                        class="nk-tb-col text-end border-bottom-0"><?php echo number_format( $pre ); ?></div>
                </div>
                <div class="nk-tb-item">
                    <div class="nk-tb-col w-70 border-bottom-0"></div>
                    <div class="nk-tb-col w-140px border-bottom-0">تفاوت مدت</div>
                    <div class="nk-tb-col w-80px border-bottom-0"></div>
                    <div class="nk-tb-col text-end border-bottom-0"><?php echo number_format(
							$invoice['total_amount'] - $pre ); ?></div>
                </div>
				<?php
			}
			?>
            <div class="nk-tb-item">
                <div class="nk-tb-col w-70 border-bottom-0"></div>
                <div class="nk-tb-col w-140px border-bottom-0 border-top-1 border-top">مبلغ کل فاکتور</div>
                <div class="nk-tb-col w-80px border-bottom-0 border-top-1 border-top"></div>
                <div class="nk-tb-col text-end border-bottom-0 border-top-1 border-top">
					<?php echo number_format( $invoice['total_amount'] ); ?></div>
            </div>
            <div class="nk-tb-item">
                <div class="nk-tb-col w-70 border-bottom-0"></div>
                <div class="nk-tb-col w-140px border-bottom-0">پرداخت های نقدی</div>
                <div class="nk-tb-col w-80px border-bottom-0"></div>
                <div class="nk-tb-col text-end border-bottom-0">
					<?php echo number_format( $payments['paid_payments'] ); ?></div>
            </div>
            <div class="nk-tb-item">
                <div class="nk-tb-col w-70 border-bottom-0"></div>
                <div class="nk-tb-col w-140px border-bottom-0">حواله های فاکتور</div>
                <div class="nk-tb-col w-80px border-bottom-0"></div>
                <div class="nk-tb-col text-end border-bottom-0">
					<?php echo number_format( $payments['paid_transfers'] ); ?></div>
            </div>
            <div class="nk-tb-item">
                <div class="nk-tb-col w-70 border-bottom-0"></div>
                <div class="nk-tb-col w-140px border-bottom-0">چک های فاکتور</div>
                <div class="nk-tb-col w-80px border-bottom-0"></div>
                <div class="nk-tb-col text-end border-bottom-0">
					<?php echo number_format( $payments['paid_cheques'] ); ?></div>
            </div>
            <div class="nk-tb-item">
                <div class="nk-tb-col w-70 border-bottom-0"></div>
                <div class="nk-tb-col w-140px border-bottom-0">مبلغ باقیمانده</div>
                <div class="nk-tb-col w-80px border-bottom-0"></div>
                <div class="nk-tb-col text-end border-bottom-0">
					<?php echo number_format( $payments['remaining'] ); ?></div>
            </div>
        </div>
    </div>
	<?php
}