<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<style>
.kph-customer-report { color: #24354b; }
.kph-customer-report .report-card { background: #fff; border: 1px solid #dde4ee; border-radius: 12px; padding: 22px; margin: 20px 0; }
.kph-customer-report .report-heading { display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 12px; margin-bottom: 14px; }
.kph-customer-report h4 { font-size: 18px; margin: 0; }
.kph-customer-report .report-note { font-size: 12px; color: #52647b; margin: 8px 0 16px; line-height: 1.9; }
.kph-customer-report .report-scroll { overflow-x: auto; }
.kph-customer-report table { width: 100%; border-collapse: collapse; font-size: 13px; }
.kph-customer-report th, .kph-customer-report td { padding: 12px; text-align: right; border-bottom: 1px solid #e1e7ef; }
.kph-customer-report th { background: #f4f6fa; color: #3e526c; white-space: nowrap; }
.kph-customer-report .report-total { font-weight: bold; background: #f0f5fc; }
.kph-customer-report .report-negative { color: #b42318; }
.kph-customer-report .report-meta { display: flex; flex-wrap: wrap; gap: 10px 25px; font-size: 12px; margin: 12px 0; }
.kph-customer-report .term-editor { display: flex; align-items: center; flex-wrap: wrap; gap: 8px; margin-top: 14px; }
.kph-customer-report .term-editor input { width: 115px; }
.kph-customer-report details { margin-top: 12px; }
.kph-customer-report summary { cursor: pointer; color: #315bd0; }
.kph-customer-report .report-tabs { display: flex; flex-wrap: wrap; gap: 8px; margin: 12px 0; }
@media print {
 .kph-customer-report .report-card { border: 0; border-radius: 0; padding: 0; margin: 16px 0; }
 .kph-customer-report .report-scroll { overflow: visible; }
 .kph-customer-report table { font-size: 10px; }
 .kph-customer-report td, .kph-customer-report th { padding: 7px; }
 .kph-customer-report thead { display: table-header-group; }
 .kph-customer-report tr { break-inside: avoid; }
 .kph-customer-report .report-heading { break-after: avoid; }
 .kph-customer-report .no-print { display: none !important; }
 .kph-customer-report .invoice-card + .invoice-card { break-before: page; }
}
</style>
