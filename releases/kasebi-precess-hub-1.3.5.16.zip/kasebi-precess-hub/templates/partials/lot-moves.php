<?php
/**
 * @var int     $lot_id
 * @var \kph_db $DB
 */
if ( ! $lot_id ) {
	echo "<div class='no-item-found'>آیتم مخزن یافت نشد</div>";
} else {
	$moves = $DB->get_lot_moves( [
		'lot_id'   => $lot_id,
		'per_page' => 500,
	] );
	$moves = $moves['items'];
	foreach ( $moves as $move ) {
		extract( $move );
		$description = match ( $reason ) {
			'waste' => 'ثبت هدر رفت',
			'from_processing' => 'انتقال به سالن از فرآوری',
			'return_to_processing' => 'بازگشت از سالن به فرآوری',
			'convert_to_shop_product' => 'تبدیل به محصول شد.',
			default => 'حرکت نامشخص برای آیتم ثبت شده است.',
		};
		?>
        <div class="bq-note mb-2">
            <div class="bq-note-item">
                <div class="bq-note-text">
                    <div class="d-flex mb-1 align-center justify-between" style="gap: 5px">
                        <span class="sub-text">اقدام صورت گرفته:</span>
						<?php if ( $reason == 'waste' ) {
							?>
                            <a href="#" class="btn btn-sm btn-icon delete_popup_move" data-id="<?php echo $id; ?>"
                               data-action="kph_delete_lot_move">
                                <em data-bs-toggle="tooltip" data-bs-placement="top" class="icon ni ni-trash-alt"
                                    title="حذف"></em>
                            </a>
							<?php
						}
						?>
                    </div>
					<?php echo $description; ?>
                    <?php if ( $reason === 'convert_to_shop_product' ) { ?>
                    <div class="mt-2"><?php echo esc_html( 'محصول: ' . ( $move['product_title'] ?? 'نامشخص' ) . ' — کد تولید: ' . ( $move['unique_product_code'] ?? '-' ) ); ?></div>
                    <div><?php echo esc_html( 'تعداد: ' . ( $move['qty_items'] ?? '-' ) . ' — وزن هر آیتم: ' . kph_product_weight_grams_label($move['weight_per_item']??'') . ' گرم' ); ?></div>
                    <?php } ?>
                    <div class="card-amount">
                        <div class="amount fw-bold <?php echo $direction == 'in' ? 'text-success' : 'text-danger'; ?>">
							<?php echo number_format( (float) $move['qty_weight'], 5, '.', '' ); ?>
                            <small class="currency currency-usd fs-12px">کیلوگرم</small>
                        </div>
                    </div>
                </div>
                <div class="bq-note-meta d-flex">
                    <div class="bq-note-added">
                        ثبت شده در
                        <span class="date text-base">
                            <?php echo date_i18n( 'j F Y', strtotime( $created_at ) ); ?></span>
                        ساعت
                        <span class="time text-base"><?php echo date_i18n( 'H:i', strtotime( $created_at ) ); ?></span>
                    </div>
                </div>
            </div>
        </div>
		<?php
	}
}