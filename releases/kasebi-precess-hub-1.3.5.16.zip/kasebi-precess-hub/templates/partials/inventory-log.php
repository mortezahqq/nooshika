<?php
/**
 * @var int     $inventory_id
 * @var \kph_db $DB
 */
if ( ! $inventory_id ) {
	echo "<div class='no-item-found'>شناسه یافت نشد</div>";
} else {
	$item = $DB->get_inventory_item( $inventory_id );
	?>
    <div class="nk-block-head-content mb-2">
        <h6 class="nk-block-title"><?php echo get_the_title( $item['wc_product_id'] ); ?></h6>
        <div class="sub-text"><?php echo $item['unique_product_code']; ?></div>
    </div>
    <div id="inventory_log_table">
		<?php
		echo kph_get_template( 'partials/inventory-table.php', [
			'inventory_id' => $inventory_id,
			'product_id'   => $item['wc_product_id'],
			'DB'           => $DB,
			'page_number'  => 1,
		] )
		?>
    </div>
	<?php
}