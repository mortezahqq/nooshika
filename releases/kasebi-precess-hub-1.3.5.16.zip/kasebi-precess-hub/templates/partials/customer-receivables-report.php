<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
$is_print = ! empty( $is_print );
$money = static fn( $value ) => number_format_i18n( (float) $value );
$day_text = static function ( $days ) {
	if ( $days === NULL ) { return 'قابل محاسبه نیست'; }
	return $days == 0 ? 'امروز' : number_format_i18n( abs( $days ), 1 ) . ( $days < 0 ? ' روز دیرکرد' : ' روز مانده' );
};
$due_state = $due_state ?? 'all';
$totals = [ 'overdue' => 0, 'upcoming' => 0, 'unknown' => 0, 'unassigned_debt' => 0 ];
$visible_rows = [];
foreach ( $customer_rows as $entry ) {
	$aging = $receivables[(int) $entry['user_id']] ?? NULL;
	if ( ! $aging || ( ! $aging['open_count'] && $aging['unassigned_debt'] < 0.01 ) ) { continue; }
	if ( $due_state !== 'all' && ( $aging[$due_state] ?? 0 ) < 0.01 ) { continue; }
	$visible_rows[] = [ $entry, $aging ];
	foreach ( $totals as $key => $value ) { $totals[$key] += $aging[$key]; }
}
?>
<div class="kph-customer-report" id="customer-receivables"><section class="report-card">
<div class="report-heading"><h4>سررسید و دیرکرد مشتریان</h4><?php if ( ! $is_print ) { echo $customer_print_button( 'receivables', 'چاپ گزارش سررسید' ); } ?></div>
<p class="report-note">وضعیت جاری تا <?php echo esc_html( date_i18n( 'Y/m/d' ) ); ?>؛ بر اساس بدهی ثبت‌شده در حسابداری بابت ارسال کالا، برگشت و پرداخت‌ها. فیلتر بازه فقط مشتریان گزارش را انتخاب می‌کند؛ محاسبهٔ مانده از تمام سوابق آن‌هاست. پرداختِ متصل به فاکتور ابتدا همان فاکتور را تسویه می‌کند؛ بستانکاری بدون اتصال از قدیمی‌ترین فاکتور باز کسر می‌شود. دریافت چک مطابق ثبت حسابداری لحاظ می‌شود و لزوماً به معنی وصول نقدی نیست.</p>
<p class="report-note">میانگین = مجموع (روز مانده یا دیرکرد × مبلغ مانده) ÷ مجموع ماندهٔ فاکتورهای دارای سررسید. فاکتورهای بدون مهلت در میانگین نیستند. بدهی بدون اتصال به فاکتور جدا نمایش داده شده است. در نبود تاریخ فاکتور، تاریخ ثبت سفارش مبنای مهلت است.</p>
<?php if ( ! $is_print ) { ?><nav class="report-tabs no-print" aria-label="وضعیت سررسید">
<?php foreach ( [ 'all' => 'همه', 'overdue' => 'دارای دیرکرد', 'upcoming' => 'نرسیده / امروز', 'unknown' => 'بدون سررسید', 'unassigned_debt' => 'بدهی بدون فاکتور' ] as $key => $label ) { ?>
<a class="btn btn-sm <?php echo $due_state === $key ? 'btn-primary' : 'btn-outline-light'; ?> page_activator" href="<?php echo esc_url( add_query_arg( array_merge( $customer_filter_args, [ 'due_state' => $key, 'customer_id' => $selected_customer_id ?? 0 ] ), home_url( '/crm/reports-user' ) ) ); ?>"><?php echo esc_html( $label ); ?></a>
<?php } ?></nav><?php } ?>
<div class="report-scroll"><table><thead><tr><th>مشتری</th><th>فاکتور باز</th><th>دیرکرد (ریال)</th><th>نرسیده / امروز (ریال)</th><th>بدون سررسید (ریال)</th><th>بدهی بدون فاکتور</th><th>میانگین زمان پرداخت</th><?php if ( ! $is_print ) { ?><th>ریز و چاپ</th><?php } ?></tr></thead><tbody>
<?php foreach ( $visible_rows as [ $entry, $aging ] ) { ?>
<tr><td><?php echo esc_html( $entry['display_name'] ); ?></td><td><?php echo (int) $aging['open_count']; ?></td>
<?php foreach ( $totals as $key => $value ) { ?><td class="<?php echo $key === 'overdue' && $aging[$key] > 0 ? 'report-negative' : ''; ?>"><?php echo esc_html( $money( $aging[$key] ) ); ?></td><?php } ?>
<td><?php echo esc_html( $day_text( $aging['average_days'] ) ); ?></td>
<?php if ( ! $is_print ) { ?><td><a class="btn btn-sm btn-light page_activator" href="<?php echo esc_url( add_query_arg( [ 'customer_id' => $entry['user_id'] ], home_url( '/crm/reports-user' ) ) ); ?>">همه فاکتورها</a><?php echo $customer_print_button( 'receivables', 'چاپ سررسید مشتری', 0, (int) $entry['user_id'] ); ?></td><?php } ?></tr>
<?php } ?>
<?php if ( ! $visible_rows ) { ?><tr><td colspan="<?php echo $is_print ? 7 : 8; ?>">موردی با این وضعیت یافت نشد.</td></tr><?php } ?>
<tr class="report-total"><td colspan="2">جمع مشتریان نمایش‌داده‌شده</td><?php foreach ( $totals as $value ) { ?><td><?php echo esc_html( $money( $value ) ); ?></td><?php } ?><td<?php echo $is_print ? '' : ' colspan="2"'; ?>>—</td></tr>
</tbody></table></div>
<?php if ( $is_print || ! empty( $selected_customer_id ) ) { foreach ( $visible_rows as [ $entry, $aging ] ) { ?>
<h5 class="mt-4">ریز سررسید: <?php echo esc_html( $entry['display_name'] ); ?></h5>
<div class="report-scroll"><table><thead><tr><th>فاکتور</th><th>سررسید</th><th>مانده (ریال)</th><th>وضعیت</th></tr></thead><tbody>
<?php foreach ( $aging['invoices'] as $invoice ) { if ( $invoice['balance'] < 0.01 ) { continue; } ?>
<tr><td><?php echo esc_html( $invoice['invoice_number'] ); ?></td><td><?php echo esc_html( $invoice['due_date'] ? date_i18n( 'Y/m/d', strtotime( $invoice['due_date'] ) ) : 'تعیین نشده' ); ?></td><td><?php echo esc_html( $money( $invoice['balance'] ) ); ?></td><td><?php echo esc_html( $day_text( $invoice['days'] ) ); ?></td></tr>
<?php } ?></tbody></table></div>
<?php } } ?>
</section></div>
