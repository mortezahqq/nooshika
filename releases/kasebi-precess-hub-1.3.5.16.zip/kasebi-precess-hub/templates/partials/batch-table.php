<?php
/**
 * @var array   $batches
 * @var \kph_db $DB
 */
$entries = $batches['items'];
?>
<div class="card">
    <div class="nk-tb-list nk-tb-ulist is-compact">
        <div class="nk-tb-item nk-tb-head">
            <div class="nk-tb-col nk-tb-col-check"></div>
            <div class="nk-tb-col"><span class="sub-text">نام محصول</span></div>
            <div class="nk-tb-col"><span class="sub-text">قیمت هر کیلو</span></div>
            <div class="nk-tb-col"><span class="sub-text">وزن مانده در مخزن</span></div>
            <div class="nk-tb-col"><span class="sub-text">مقدار فرآوری</span></div>
        </div>
		<?php
		foreach ( $entries as $entry ) {
			$invoice_no    = $DB->get_meta( 'batch', $entry['id'], 'invoice_no', TRUE );
			$product       = $DB->get_raw_product( $entry['raw_product_id'] );
			$total_amount  = $entry['unit_cost'] * $entry['initial_qty_weight'];
			$net_weight    = $entry['initial_qty_weight'] - $entry['total_waste'];
			$new_unit_cost = $total_amount / $net_weight;
			?>
            <div class="nk-tb-item">
                <div class="nk-tb-col nk-tb-col-check">
                    <div
                        class="custom-control custom-control-sm custom-checkbox notext">
                        <input type="checkbox" class="custom-control-input"
                               name="batch_to_process"
                               id="batch_to_process_<?php echo $entry['id']; ?>"
                               data-for="batch_to_process" value="<?php echo $entry['id']; ?>"
                               data-req="1">
                        <label class="custom-control-label"
                               for="batch_to_process_<?php echo $entry['id']; ?>"></label>
                    </div>
                </div>
                <div class="nk-tb-col">
                    <div class="user-card">
                        <div class="user-info">
                            <span class="tb-lead"><?php echo $product['item']['title']; ?></span>
                            <span class="sub-text"><?php echo $invoice_no; ?></span>
                        </div>
                    </div>
                </div>
                <div class="nk-tb-col">
                    <span><?php echo number_format( $new_unit_cost ); ?></span>
                </div>
                <div class="nk-tb-col" id="current_stock_<?php echo $entry['id'];; ?>">
					<?php echo number_format( (float) $entry['current_stock'], 4, '.', '' ); ?>
                </div>
                <div class="nk-tb-col">
                    <div class="form-group">
                        <div class="form-control-wrap">
                            <input type="text" class="form-control validate_weight check_checkbox"
                                   data-target="#current_stock_<?php echo $entry['id'];; ?>"
                                   data-for="qty_weight[<?php echo $entry['id']; ?>]">
                        </div>
                    </div>
                </div>
            </div>
			<?php
		}
		?>
    </div>
</div>