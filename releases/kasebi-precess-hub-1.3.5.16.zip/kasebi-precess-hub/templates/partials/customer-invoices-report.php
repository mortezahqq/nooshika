<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
$is_print = ! empty( $is_print );
$money = static fn( $value ) => number_format_i18n( (float) $value );
$date_label = static fn( $value ) => $value ? date_i18n( 'Y/m/d', strtotime( $value ) ) : 'تعیین نشده';
$state_label = static function ( $invoice ) use ( $money ) {
	if ( $invoice['state'] === 'settled' ) { return 'مانده ثبت‌شده ندارد'; }
	if ( $invoice['days'] === NULL ) { return 'بدون سررسید'; }
	return $invoice['days'] < 0 ? $money( abs( $invoice['days'] ) ) . ' روز دیرکرد' : ( $invoice['days'] == 0 ? 'سررسید امروز' : $money( $invoice['days'] ) . ' روز تا پرداخت' );
};
?>
<div class="kph-customer-report">
<p class="report-note">مبالغ به ریال است. برکت ناخالص = فروش اقلام ارسال‌شده پس از تخفیف − بهای تمام‌شدهٔ ارسال‌ها (شامل هدایا). برکت اقلام ارسال‌نشده هنوز محقق نشده است.</p>
<?php if ( ! $invoices ) { ?><div class="report-card">فاکتوری در این بازه یافت نشد.</div><?php } ?>
<?php foreach ( $invoices as $invoice ) {
	$due = $receivables[(int) $invoice['customer_id']]['invoices'][(int) $invoice['id']] ?? NULL;
?>
<section class="report-card invoice-card">
 <div class="report-heading">
  <h4>فاکتور <bdi><?php echo esc_html( $invoice['invoice_number'] ); ?></bdi></h4>
  <?php if ( ! $is_print ) { echo $customer_print_button( 'invoices', 'چاپ این فاکتور', (int) $invoice['id'], (int) $invoice['customer_id'] ); } ?>
 </div>
 <div class="report-meta">
  <span>تاریخ فاکتور: <?php echo esc_html( $date_label( $invoice['invoice_date'] ) ); ?></span>
  <span>شناسه سفارش: <?php echo esc_html( $invoice['order_number'] ); ?></span>
  <?php if ( $due ) { ?>
  <span>سررسید: <?php echo esc_html( $date_label( $due['due_date'] ) ); ?></span>
  <span class="<?php echo $due['state'] === 'overdue' ? 'report-negative' : ''; ?>"><?php echo esc_html( $state_label( $due ) ); ?></span>
  <span>ماندهٔ ثبت‌شده: <?php echo esc_html( $money( $due['balance'] ) ); ?> ریال</span>
  <?php } ?>
 </div>
 <div class="report-scroll"><table>
 <thead><tr><th scope="col">محصول / کد</th><th scope="col">تعداد فاکتور</th><th scope="col">هدیه</th><th scope="col">ارسال‌شده / هدیه</th><th scope="col">مبلغ فاکتور</th><th scope="col">فروش ارسال‌شده</th><th scope="col">بهای تمام‌شده</th><th scope="col">برکت ناخالص</th></tr></thead>
 <tbody>
 <?php foreach ( $invoice['items'] as $product ) { ?>
 <tr>
  <td><?php echo esc_html( $product['title'] ); ?><br><small><bdi><?php echo esc_html( $product['unique_product_code'] ); ?></bdi></small></td>
  <?php foreach ( [ 'qty_ordered', 'expected_free_qty' ] as $key ) { ?><td><?php echo esc_html( $money( $product[$key] ) ); ?></td><?php } ?>
  <td><?php echo esc_html( $money( $product['shipped_paid_qty'] ) . ' فروش' ); ?><br><small><?php echo esc_html( $money( $product['shipped_free_qty'] ) . ' هدیه' ); ?></small></td>
  <?php foreach ( [ 'final_amount', 'sales', 'cogs_total', 'profit' ] as $key ) { ?><td class="<?php echo $product[$key] < 0 ? 'report-negative' : ''; ?>"><bdi><?php echo esc_html( $money( $product[$key] ) ); ?></bdi></td><?php } ?>
 </tr>
 <?php } ?>
 <?php if ( ! $invoice['items'] ) { ?><tr><td colspan="8">این فاکتور قلم فعال ندارد.</td></tr><?php } ?>
 <tr class="report-total"><td colspan="4">جمع همین فاکتور (ریال)</td>
 <?php foreach ( [ 'final_amount', 'sales', 'cogs_total', 'profit' ] as $key ) { ?><td><bdi><?php echo esc_html( $money( $invoice['totals'][$key] ) ); ?></bdi></td><?php } ?></tr>
 </tbody></table></div>
 <p class="report-note"><strong>برکت کل این فاکتور: <bdi><?php echo esc_html( $money( $invoice['totals']['profit'] ) ); ?></bdi> ریال</strong></p>
 <?php if ( ! $is_print && current_user_can( 'manage_options' ) ) { ?>
 <form class="term-editor no-print" data-order-id="<?php echo (int) $invoice['id']; ?>" data-nonce="<?php echo esc_attr( wp_create_nonce( 'kph_customer_payment_term' ) ); ?>">
 <label for="term-<?php echo (int) $invoice['id']; ?>">مهلت تسویه از تاریخ فاکتور (روز)</label>
 <input id="term-<?php echo (int) $invoice['id']; ?>" name="payment_term_days" class="form-control form-control-sm" type="number" min="0" max="3650" step="1" placeholder="تعیین نشده" value="<?php echo esc_attr( $invoice['payment_term_days'] ?? '' ); ?>">
 <button type="submit" class="btn btn-sm btn-outline-primary">ذخیره مهلت</button><small>صفر: همان روز؛ خالی: بدون سررسید</small>
 </form>
 <?php } ?>
</section>
<?php } ?>
</div>
