<?php
/**
 * @var int     $page_number
 * @var array   $in_hands
 * @var \kph_db $DB
 */
$entries = $in_hands['items'];
?>
<div class="card">
    <div class="nk-tb-list nk-tb-ulist is-compact">
        <div class="nk-tb-item nk-tb-head">
            <div class="nk-tb-col nk-tb-col-check"></div>
            <div class="nk-tb-col"><span class="sub-text">سررسید چک</span></div>
            <div class="nk-tb-col"><span class="sub-text">شناسه صیادی</span></div>
            <div class="nk-tb-col"><span class="sub-text">مقدار</span></div>
            <div class="nk-tb-col nk-tb-col-tools text-end"></div>
        </div>
		<?php
		foreach ( $entries as $entry ) {
			$date        = date_i18n( 'Y/m/d', strtotime( $entry['due_at'] ) );
			$amount      = number_format( $entry['amount'] );
			$attachment  = $DB->get_cheque_meta( $entry['id'], 'attachment' );
			$bank_branch = $DB->get_cheque_meta( $entry['id'], 'bank_branch' );
			$bank_owner  = $DB->get_cheque_meta( $entry['id'], 'bank_owner' );
			?>
            <div class="nk-tb-item">
                <div class="nk-tb-col nk-tb-col-check">
                    <div
                        class="custom-control custom-control-sm custom-radio notext">
                        <input type="radio" class="custom-control-input"
                               name="cheque_to_refer"
                               id="cheque_to_select_<?php echo $entry['id']; ?>"
                               data-for="cheque_to_refer" value="<?php echo $entry['id']; ?>"
                               data-req="1">
                        <label class="custom-control-label"
                               for="cheque_to_select_<?php echo $entry['id']; ?>"></label>
                    </div>
                </div>
                <div class="nk-tb-col">
                    <span><?php echo $date; ?></span>
                </div>
                <div class="nk-tb-col">
                    <span><?php echo $entry['sayad_id']; ?></span>
                </div>
                <div class="nk-tb-col">
                    <div class="amount">
                        <span><?php echo $amount; ?></span>
                    </div>
                </div>
                <div class="nk-tb-col">
                    <ul class="nk-tb-actions gx-2">
						<?php
						$hidden_actions = [
							[
								'link'  => "",
								'title' => $entry['bank_name'] . ( $bank_branch ? ' - ' . $bank_branch : '' ),
								'icon'  => 'ni-server',
							],
							[
								'link'  => '',
								'title' => get_user_name_by_id( $entry['issuer_user_id'] ),
								'icon'  => 'ni-user-check',
							],
						];
						echo kph_get_template( 'components/row-actions.php', [
							'actions' => $hidden_actions,
						] );
						?>
                    </ul>
                </div>
            </div>
			<?php
		}
		?>
    </div>
</div>
<div class="p-1 mt-2">
	<?php
	echo kph_get_template( 'components/pagination.php', [
		'max_page_num' => $in_hands['pagination']['total_page'],
		'current_page' => $page_number,
		'show_count'   => 2,
		'target'       => '#cheque_to_refer_table',
		'data'         => [
			'action' => 'kph_load_cheques_list',
		],
	] );
	?>
</div>
