<?php
/**
 * @var int     $pack_id
 * @var \kph_db $DB
 */

$inputs   = $DB->get_processing_pack_inputs( $pack_id );
$statuses = $DB->get_supplier_invoice_statuses();

if ( ! $inputs ) {
	echo "<div class='no-item-found'>آیتمی یافت نشد</div>";
} else {
	?>
    <div class="nk-block">
        <div class="nk-tb-list nk-tb-ulist is-compact v-align-top border border-1 text-dark">
            <div class="nk-tb-item nk-tb-head">
                <div class="nk-tb-col"><span class="sub-text">عنوان محصول</span></div>
                <div class="nk-tb-col"><span class="sub-text">وزن خالص</span></div>
                <div class="nk-tb-col"><span class="sub-text">قیمت واحد</span></div>
                <div class="nk-tb-col text-center"><span class="sub-text">جمع کل</span></div>
                <div class="nk-tb-col text-end"><span class="sub-text">وضعیت فاکتور</span></div>
            </div>
			<?php
			$pre = 0;
			foreach ( $inputs as $entry ) {
				$batch_id   = $entry['batch_id'];
				$batch      = $DB->get_batch_by_id( $batch_id );
				$product    = $DB->get_raw_product( $batch['raw_product_id'] );
				$invoice_no = $DB->get_meta( 'batch', $batch_id, 'invoice_no', TRUE );
				$invoice_id = $DB->get_meta( 'batch', $batch_id, 'invoice_id', TRUE );
				$status     = $DB->get_supplier_invoice_status( $invoice_id );
				?>
                <div class="nk-tb-item">
                    <div class="nk-tb-col">
                        <div class="user-card">
                            <div class="user-info">
                                <span class="tb-lead"><?php echo $product['item']['title']; ?></span>
                                <span class="sub-text"><?php echo $invoice_no; ?></span>
                            </div>
                        </div>
                    </div>
                    <div class="nk-tb-col">
						<?php echo number_format( (float) $entry['qty_weight'], 4, '.', '' ); ?>
                    </div>
                    <div class="nk-tb-col">
                        <span><?php echo number_format( $entry['unit_cost'] ); ?></span>
                    </div>
                    <div class="nk-tb-col text-center">
                        <span><?php echo number_format( $entry['line_cost'] ); ?></span>
                    </div>
                    <div class="nk-tb-col text-end">
                        <span
                            class="badge bg-<?php echo $statuses[ $status ]['class']; ?>"><?php echo $statuses[ $status ]['label']; ?></span>
                    </div>
                </div>
				<?php
			}
			?>
        </div>
    </div>
	<?php
}