<?php
/**
 * @var int     $batch_id
 * @var \kph_db $DB
 */
if ( ! $batch_id ) {
	echo "<div class='no-item-found'>آیتم مخزن یافت نشد</div>";
} else {
	$moves      = $DB->get_storage_moves_by_batch_id( $batch_id );
	$batch      = $moves['batch'];
	$moves      = $moves['moves'];
	$product    = $DB->get_raw_product( $batch['raw_product_id'] );
	$invoice_no = $DB->get_meta( 'batch', $batch_id, 'invoice_no', TRUE );
	?>
    <div class="card-title mb-2">
        <h6 class="title"><?php echo $product['item']['title']; ?></h6>
        <h6 class="subtitle"><?php echo $invoice_no; ?></h6>
    </div>
	<?php
	foreach ( $moves as $move ) {
		extract( $move );
		
		$description = match ( $reason ) {
			'purchase_in' => 'تایید فاکتور تامین کننده و ورود آیتم به مخزن',
			'waste' => "ثبت وزن هدر رفته",
			'processing_out' => 'تبدیل به آیتم فرآوری شده',
			default => 'حرکت نامشخص برای آیتم ثبت شده است.',
		};
		?>
        <div class="bq-note mb-2">
            <div class="bq-note-item">

                <div class="bq-note-text">
                    <div class="d-flex mb-1 align-center justify-between" style="gap: 5px">
                        <span class="sub-text">اقدام صورت گرفته:</span>
						<?php if ( $reason == 'waste' ) {
							?>
                            <a href="#" class="btn btn-sm btn-icon delete_popup_move" data-id="<?php echo $id; ?>"
                               data-action="kph_delete_batch_move">
                                <em data-bs-toggle="tooltip" data-bs-placement="top" class="icon ni ni-trash-alt"
                                    title="حذف"></em>
                            </a>
							<?php
						}
						?>
                    </div>
					<?php echo $description; ?>
                    <div class="card-amount">
                        <div class="amount fw-bold <?php echo $direction == 'in' ? 'text-success' : 'text-danger'; ?>">
							<?php echo number_format( (float) $move['qty_weight'], 4, '.', '' ); ?>
                            <small class="currency currency-usd fs-12px">کیلوگرم</small>
                        </div>
                    </div>
                </div>
                <div class="bq-note-meta d-flex">
                    <div class="bq-note-added">
                        ثبت شده در
                        <span class="date text-base">
                            <?php echo date_i18n( 'j F Y', strtotime( $created_at ) ); ?></span>
                        ساعت
                        <span class="time text-base"><?php echo date_i18n( 'H:i', strtotime( $created_at ) ); ?></span>
                    </div>
                </div>
            </div>
        </div>
		<?php
	}
}