<?php
/**
 * @var int     $page_number
 * @var int     $inventory_id
 * @var int     $product_id
 * @var \kph_db $DB
 */
$logs    = $DB->get_inventory_logs( $inventory_id, $product_id, [
	'page' => $page_number,
] );
$entries = $logs['items'];
?>
<div class="card">
    <div class="nk-tb-list nk-tb-ulist is-compact">
        <div class="nk-tb-item nk-tb-head">
            <div class="nk-tb-col"><span class="sub-text">تاریخ</span></div>
            <div class="nk-tb-col"><span class="sub-text">تعداد</span></div>
            <div class="nk-tb-col"><span class="sub-text">قیمت واحد</span></div>
            <div class="nk-tb-col"><span class="sub-text">جمع کل</span></div>
            <div class="nk-tb-col"><span class="sub-text">توضیحات</span></div>
        </div>
		<?php
		foreach ( $entries as $entry ) {
			$date  = date_i18n( 'Y/m/d', strtotime( $entry['created_at'] ) );
			$icon  = $entry['change_qty'] > 0 ? 'ni-arrow-long-up' : 'ni-arrow-long-down';
			$class = $entry['change_qty'] > 0 ? 'text-success' : 'text-danger';
			?>
            <div class="nk-tb-item">
                <div class="nk-tb-col">
                    <span><?php echo $date; ?></span>
                </div>
                <div class="nk-tb-col">
                    <div class="amount <?php echo $class; ?>">
                        <span><?php echo $entry['change_qty']; ?></span>
						<?php echo "<em class='icon ni $icon'></em>"; ?>
                    </div>
                </div>
                <div class="nk-tb-col">
                    <div class="amount">
                        <span><?php echo number_format( $entry['unit_cost'] ); ?></span>
                    </div>
                </div>
                <div class="nk-tb-col">
                    <div class="amount">
                        <span><?php echo number_format( $entry['total_cost'] ); ?></span>
                    </div>
                </div>
                <div class="nk-tb-col">
                    <span><?php echo $entry['note']; ?></span>
                </div>
            </div>
			<?php
		}
		?>
    </div>
</div>
<div class="p-1 mt-2">
	<?php
	echo kph_get_template( 'components/pagination.php', [
		'max_page_num' => $logs['pagination']['total_page'],
		'current_page' => $page_number,
		'show_count'   => 2,
		'target'       => '#inventory_log_table',
		'data'         => [
			'action'       => 'kph_load_inventory_table',
			'inventory_id' => $inventory_id,
		],
	] );
	?>
</div>
