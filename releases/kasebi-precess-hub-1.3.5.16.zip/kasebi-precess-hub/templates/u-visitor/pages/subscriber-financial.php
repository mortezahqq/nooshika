<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * @var $user_id
 */
$defaults   = [
	'per_page'    => 10,
	'page_number' => 1,
	'date'        => [
		'from' => '',
		'to'   => '',
	],
	'entry_type'  => '',
];
$args       = wp_parse_args( array_intersect_key( $_REQUEST, $defaults ), $defaults );
$args       = array_map( fn( $v ) => $v == 0 ? '' : $v, $args );
$has_filter = kph_page_has_filter( $args, $defaults );
extract( $args );
// Personal financial pages always use the authenticated visitor's account.
$user_id = get_current_user_id();
$date_from   = $date['from'] ?? '';
$date_to     = $date['to'] ?? '';
$DB          = new kph_db();
$entries     = $DB->get_ledger_entries( [
	'user_id'    => $user_id,
	'page'       => $page_number,
	'per_page'   => $per_page,
	'entry_type' => $entry_type,
	'date_from'  => $date_from ? nooshika_jalali_to_gregorian( $date_from ) : NULL,
	'date_to'    => $date_to ? nooshika_jalali_to_gregorian( $date_to ) : NULL,
] );
$entry_types = $DB->get_ledger_entry_types();
$total_page  = $entries['pagination']['total_page'];
$entries     = $entries['items'];
?>
<input type="hidden" id="current_user_id" value="<?php echo esc_attr( $user_id ); ?>">
<div class="nk-block nk-block-between">
    <div class="nk-block-head">
        <h6 class="title">لیست آیتم های حسابداری</h6>
    </div>
    <ul class="btn-toolbar gx-1">
        <li class="nk-block-tools-opt">
            <a href="#" class="btn btn-icon btn-primary print_list_items" data-type="financial"
               data-collect="date,user" data-user="#current_user_id" data-targets="#filter_date_from:#filter_date_to">
                <em class="icon ni ni-printer"></em></a>
        </li>
        <li>
			<?php
			$filter_fields = [
				[
					'type'  => 'date-range',
					'label' => 'بازه حسابداری',
					'name'  => 'date',
					'value' => [
						'from' => $date_from ?? '',
						'to'   => $date_to ?? '',
					],
				],
				[
					'type'    => 'select',
					'label'   => 'نوع تراکنش',
					'name'    => 'entry_type',
					'value'   => $entry_type,
					'col'     => 6,
					'options' => [ 0 => 'همه موارد' ] + array_combine(
							array_keys( $entry_types ),
							array_column( $entry_types, 'label' )
						),
				],
				[
					'type'  => 'hidden',
					'name'  => 'tab',
					'value' => 'financial',
				],
			];
			echo kph_get_template( 'components/filter-dropdown.php', [
				'has_filter'    => $has_filter,
				'filter_fields' => $filter_fields,
			] );
			?>
        </li>
    </ul>
</div>
<div class="nk-block">
	<?php
	if ( empty( $entries ) ) {
		echo '<div class="no_massages">آیتمی برای نمایش وجود ندارد.</div>';
	} else {
		?>
        <div class="card">
            <div class="nk-tb-list nk-tb-ulist is-compact">
                <div class="nk-tb-item nk-tb-head">
                    <div class="nk-tb-col"><span class="sub-text">تاریخ ثبت</span></div>
                    <div class="nk-tb-col"><span class="sub-text">نوع تراکنش</span></div>
                    <div class="nk-tb-col"><span class="sub-text">بدهکار</span></div>
                    <div class="nk-tb-col"><span class="sub-text">بستانکار</span></div>
                    <div class="nk-tb-col"><span class="sub-text">مانده برخط</span></div>
                    <div class="nk-tb-col nk-tb-col-tools text-end"></div>
                </div>
				<?php
				foreach ( $entries as $entry ) {
					$icon       = $entry['type'] == "credit" ? 'ni-arrow-long-up' : 'ni-arrow-long-down';
					$class      = $entry['type'] == "credit" ? 'text-success' : 'text-danger';
					$date       = date_i18n( 'j F Y', strtotime( $entry['posted_at'] ) );
					$amount     = number_format( $entry['amount'] );
					$note       = $entry['note'];
					$entry_type = $entry_types[ $entry['entry_type'] ];
					$order_id   = $DB->get_ledger_entry_meta( $entry['id'], 'order_id' );
					$label      = $entry_type['label'];
					if ( $order_id ) {
						$label .= ' ' . $order_id;
					}
					?>
                    <div class="nk-tb-item">
                        <div class="nk-tb-col">
                            <span><?php echo $date; ?></span>
                        </div>
                        <div class="nk-tb-col">
                            <span class="badge <?= $entry_type['class']; ?>"><?php echo $label; ?></span>
                        </div>
                        <div class="nk-tb-col">
							<?php
							if ( $entry['type'] == "debit" ) {
								?>
                                <div class="amount <?php echo $class; ?>">
                                    <span><?php echo $amount; ?></span>
									<?php echo "<em class='icon ni $icon'></em>"; ?>
                                </div>
								<?php
							} else {
								echo '-';
							}
							?>
                        </div>
                        <div class="nk-tb-col">
							<?php
							if ( $entry['type'] == "credit" ) {
								?>
                                <div class="amount <?php echo $class; ?>">
                                    <span><?php echo $amount; ?></span>
									<?php echo "<em class='icon ni $icon'></em>"; ?>
                                </div>
								<?php
							} else {
								echo '-';
							}
							?>
                        </div>
                        <div class="nk-tb-col">
                            <div class="amount <?php echo $entry['balance'] < 0 ? ' text-success' : ' text-danger'; ?>">
                                <span><?php echo number_format( abs( $entry['balance'] ) ); ?></span>
								<?php
								$icon = $entry['balance'] < 0 ? 'ni-arrow-long-up' : 'ni-arrow-long-down';
								echo "<em class='icon ni $icon'></em>"; ?>
                            </div>
                        </div>
                        <div class="nk-tb-col">
                            <ul class="nk-tb-actions gx-2">
								<?php
								if ( $note ) {
									?>
                                    <li class="nk-tb-action">
                                        <div class="btn btn-sm btn-icon btn-trigger"
                                             data-bs-toggle="popover"
                                             data-bs-trigger="hover"
                                             data-bs-html="true"
                                             title="یادداشت"
                                             data-bs-content="<?php echo wpautop( $note ); ?>"
                                             data-bs-placement="top">
                                            <em class="icon ni ni-note-add-c"></em>
                                        </div>
                                    </li>
									<?php
								}
								?>
                            </ul>
                        </div>
                    </div>
					<?php
				}
				?>
            </div>
        </div>
        <div class="p-1 mt-2">
			<?php
			echo kph_get_template( 'components/pagination.php', [
				'max_page_num' => $total_page,
				'current_page' => $page_number,
				'show_count'   => 2,
				'data'         => [
					'tab' => 'financial',
				],
			] );
			?>
        </div>
		<?php
	}
	?>
</div>
