<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

// Show personal target progress immediately after the visitor enters their panel.
echo kph_get_template( 'partials/visitor-monthly-sales.php' );
echo kph_get_template( 'pages/visitor-targets.php' );
