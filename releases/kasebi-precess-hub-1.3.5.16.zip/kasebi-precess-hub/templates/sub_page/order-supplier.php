<?php
$defaults    = [
	'c_id' => '',
];
$args        = wp_parse_args( $_REQUEST, $defaults );
$customer_id = $args['c_id'];
$group       = get_user_meta( $customer_id, 'kph_supplier_group', TRUE );
?>
    <div class="nk-block-head nk-block-head-sm">
        <div class="nk-block-between">
            <div class="nk-block-head-content">
                <h3 class="nk-block-title page-title">ثبت فاکتور تامین کننده</h3>
            </div>
        </div>
    </div>
    <div class="nk-block invoice-bills">
        <div class="row g-gs">
            <div class="col-12 col-md-4">
                <div class="card">
                    <div class="card-inner">
                        <div class="form-group card-title search_wrapper">
                            <label class="form-label" for="search_user_for_order">جستجوی مشتری</label>
                            <div class="form-control-wrap">
                                <div class="form-icon form-icon-left"><em class="icon ni ni-user"></em></div>
                                <input type="text" class="form-control search_user_modal" id="search_user_for_order"
                                       data-role="supplier">
                            </div>
                            <p class="mt-1">جهت جستجوی مشتری شماره موبایل و یا نام مشتری را جستجو کنید.</p>
                            <div class="customer_search_result" data-input="#new_order_customer_id"
                                 data-preview=".customer_box"></div>
                        </div>
                        <div class="customer_box nk-tb-list">
							<?php
							if ( $customer_id ) {
								echo kph_get_template( 'components/user-card.php', [
									'user_id'    => $customer_id,
									'show_phone' => TRUE,
								] );
							}
							?>
                        </div>
                        <input type="hidden" id="new_order_customer_id" value="<?php echo $customer_id; ?>">
                        <input type="hidden" id="new_order_customer_group" value="<?php echo $group; ?>">
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-8 product_block_card">
                <div class="card h-100">
                    <div class="card-inner">
                        <div class="row g-gs">
                            <div class="col-12 col-md-4">
                                <div class="form-group card-title">
                                    <label class="form-label" for="search_sku_for_supplier_invoice">جستجوی محصول</label>
                                    <div class="form-control-wrap">
                                        <div class="form-icon form-icon-left"><em class="icon ni ni-package"></em></div>
                                        <input type="text" class="form-control" id="search_sku_for_supplier_invoice"
                                               data-group="<?php echo $group; ?>"
                                               placeholder="نام محصول">
                                    </div>
                                </div>
                                <div class="product_search_list"></div>
                            </div>
                            <div class="col-12 col-md-8">
                                <div class="product_search_result"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 order_factor_card">
                <div class="card">
                    <div class="card-inner">
                        <table class="table table-striped products_payment">
                            <thead>
                            <tr>
                                <th class="w-110px">شناسه محصول</th>
                                <th class="w-30">عنوان محصول</th>
                                <th class="w-80px">وزن خالص</th>
                                <th class="w-150px">قیمت واحد</th>
                                <th class="w-80px hide_on_normal">کارمزد</th>
                                <th class="w-120px hide_on_normal">مدت زمان تسویه</th>
                                <th class="w-150px hide_on_normal">هر کیلو تمام شده</th>
                                <th class="w-150px text-end">جمع کل</th>
                            </tr>
                            </thead>
                            <tbody>
                            </tbody>
                            <tfoot>
                            <tr>
                                <td colspan="5" class="lower_colspan"></td>
                                <td colspan="2">جمع کل</td>
                                <td class="order_subtotal">0</td>
                            </tr>
                            <tr class="payment_fee hide_on_normal">
                                <td colspan="5"></td>
                                <td colspan="2">تفاوت مدت</td>
                                <td class="cart_total_payment_fee">0</td>
                            </tr>
                            <tr>
                                <td colspan="5" class="lower_colspan"></td>
                                <td colspan="2">مبلغ کل فاکتور</td>
                                <td class="order_total_final">0</td>
                            </tr>
                            </tfoot>
                        </table>
                        <div class="d-flex justify-end mt-3">
                            <button class="btn btn-success submit_supplier_order">ثبت سفارش</button>
                        </div>
                    </div>
                </div>
                <div class="row g-gs mt-0">
                    <div class="col-md-4">
                        <div class="card h-100">
                            <div class="card-inner">
                                <div class="nk-block-between mb-2">
                                    <h6 class="nk-block-title">مستندات سفارش</h6>
                                </div>
                                <div class="form-group">
                                    <div class="upload-zone" data-target="#new_order_attachment"
                                         data-name="title"
                                         data-action="kph_handle_file_upload" data-max-files="30">
                                        <div class="dz-message" data-dz-message>
                                            <span class="dz-message-text">بکشید و رها کنید</span>
                                            <span class="dz-message-or">یا</span>
                                            <div class="btn btn-primary">انتخاب کنید</div>
                                        </div>
                                    </div>
                                </div>
                                <input type="hidden" id="new_order_attachment">
                            </div>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="card h-100">
                            <div class="card-inner">
                                <div class="nk-block-between mb-3">
                                    <h6 class="nk-block-title">اطلاعات اضافه فاکتور</h6>
                                </div>
                                <div class="form-group">
                                    <label class="form-label" for="new_factor_date">تاریخ فاکتور</label>
                                    <div class="form-control-wrap">
                                        <div class="form-icon form-icon-left">
                                            <em class="icon ni ni-calendar-alt"></em>
                                        </div>
                                        <input type="text" class="form-control datepicker" id="new_factor_date">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="form-label" for="new_factor_number">شماره فاکتور</label>
                                    <div class="form-control-wrap">
                                        <div class="form-icon form-icon-left">
                                            <em class="icon ni ni-tag-alt"></em>
                                        </div>
                                        <input type="text" class="form-control" id="new_factor_number">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="card h-100">
                            <div class="card-inner">
                                <div class="nk-block-between mb-4">
                                    <h6 class="nk-block-title">توضیحات سفارش</h6>
                                </div>
                                <div class="form-control-wrap">
                                    <textarea class="form-control no-resize" id="order_description"></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php
if ( $group != 1 ) {
	?>
    <script>
        document.querySelectorAll('.hide_on_normal').forEach(el => el.style.display = 'none');
        document.querySelectorAll('.lower_colspan').forEach(el => {
            el.setAttribute('colspan', 2);
        });
    </script>
	<?php
}