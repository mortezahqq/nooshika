<?php
$defaults    = [
	'c_id' => '',
];
$args        = wp_parse_args( $_REQUEST, $defaults );
$customer_id = $args['c_id'];
$DB          = new kph_db();
$number      = $DB->get_next_factor_number();
$addresses   = [];
if ( $customer_id ) {
	$addresses = get_user_meta( $customer_id, 'address_list', TRUE );
	$addresses = kasebi_unminified_string( $addresses );
	$addresses = $addresses ?: [];
}
?>
    <div class="nk-block-head nk-block-head-sm">
        <div class="nk-block-between">
            <div class="nk-block-head-content">
                <h3 class="nk-block-title page-title">ثبت پیش‌فاکتور جدید</h3>
            </div>
        </div>
    </div>
    <div class="nk-block invoice-bills">
        <div class="row g-gs">
            <div class="col-12 col-md-4">
                <div class="card">
                    <div class="card-inner">
                        <div class="form-group card-title search_wrapper">
                            <label class="form-label" for="search_user_for_order">جستجوی مشتری</label>
                            <div class="form-control-wrap">
                                <div class="form-icon form-icon-left"><em class="icon ni ni-user"></em></div>
                                <input type="text" class="form-control search_user_modal" id="search_user_for_order"
                                       data-role="subscriber">
                            </div>
                            <p class="mt-1">جهت جستجوی مشتری شماره موبایل و یا نام مشتری را جستجو کنید.</p>
                            <div class="customer_search_result" data-input="#new_order_customer_id"
                                 data-preview=".customer_box"></div>
                        </div>
                        <div class="customer_box nk-tb-list">
							<?php
							if ( $customer_id ) {
								echo kph_get_template( 'components/user-card.php', [
									'user_id'    => $customer_id,
									'show_phone' => TRUE,
								] );
							}
							?>
                        </div>
                        <input type="hidden" id="new_order_customer_id"
                               data-page="order-submit" data-order-mode="create"
                               value="<?php echo $customer_id; ?>">
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-8 product_block_card">
                <div class="card h-100">
                    <div class="card-inner">
                        <div class="row g-gs">
                            <div class="col-12 col-md-4">
                                <div class="form-group card-title">
                                    <label class="form-label" for="search_sku_for_customer_invoice">جستجوی محصول</label>
                                    <div class="form-control-wrap">
                                        <div class="form-icon form-icon-left"><em class="icon ni ni-package"></em></div>
                                        <input type="text" class="form-control" id="search_sku_for_customer_invoice"
                                               placeholder="نام محصول">
                                    </div>
                                </div>
                                <div class="product_search_list"></div>
                            </div>
                            <div class="col-12 col-md-8">
                                <div class="product_search_result"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 order_factor_card">
                <div class="card">
                    <div class="card-inner">
                        <table class="table table-striped products_payment">
                            <thead>
                            <tr>
                                <th class="w-30">محصول</th>
                                <th class="w-120px">قیمت پایه</th>
                                <th class="w-80px">تعداد</th>
                                <th class="w-80px">درصد تخفیف</th>
                                <th class="w-150px">تخفیف کالایی</th>
                                <th class="w-175px text-end">مبلغ نهایی</th>
                            </tr>
                            </thead>
                            <tbody>
                            </tbody>
                            <tfoot>
                            <tr>
                                <td colspan="3"></td>
                                <td colspan="2">جمع کل</td>
                                <td class="order_subtotal">0</td>
                            </tr>
                            <tr>
                                <td colspan="3"></td>
                                <td colspan="2">جمع تخفیفات</td>
                                <td class="order_total_off">0</td>
                            </tr>
                            <tr>
                                <td colspan="3"></td>
                                <td colspan="2">مبلغ کل فاکتور</td>
                                <td class="order_total_final">0</td>
                            </tr>
                            </tfoot>
                        </table>
                        <div class="d-flex justify-end mt-3">
                            <button class="btn btn-success submit_customer_order" data-order-mode="create" data-nonce="<?php echo esc_attr(wp_create_nonce('kph_customer_order')); ?>">ثبت پیش‌فاکتور جدید</button>
                        </div>
                    </div>
                </div>
                <div class="row g-gs mt-0">
                    <div class="col-md-4">
                        <div class="card h-100">
                            <div class="card-inner">
                                <div class="nk-block-between mb-2">
                                    <h6 class="nk-block-title">مستندات سفارش</h6>
                                </div>
                                <div class="form-group">
                                    <div class="upload-zone" data-target="#new_order_attachment"
                                         data-name="title"
                                         data-action="kph_handle_file_upload" data-max-files="30">
                                        <div class="dz-message" data-dz-message>
                                            <span class="dz-message-text">بکشید و رها کنید</span>
                                            <span class="dz-message-or">یا</span>
                                            <div class="btn btn-primary">انتخاب کنید</div>
                                        </div>
                                    </div>
                                </div>
                                <input type="hidden" id="new_order_attachment">
                            </div>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="card h-100">
                            <div class="card-inner">
                                <div class="nk-block-between mb-4">
                                    <h6 class="nk-block-title">توضیحات سفارش</h6>
                                </div>
                                <div class="form-control-wrap">
                                    <textarea class="form-control no-resize" id="order_description"></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="card h-100">
                            <div class="card-inner">
                                <div class="nk-block-between mb-3">
                                    <h6 class="nk-block-title">اطلاعات اضافه سفارش</h6>
                                </div>
                                <div class="form-group">
                                    <label class="form-label" for="new_factor_date">تاریخ فاکتور</label>
                                    <div class="form-control-wrap">
                                        <div class="form-icon form-icon-left">
                                            <em class="icon ni ni-calendar-alt"></em>
                                        </div>
                                        <input type="text" class="form-control datepicker" id="new_factor_date"
                                               value="<?php echo date_i18n( 'Y-m-d' ); ?>">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="form-label" for="new_shipment_date">تاریخ ارسال سفارش</label>
                                    <div class="form-control-wrap">
                                        <div class="form-icon form-icon-left"><em class="icon ni ni-truck"></em></div>
                                        <input type="text" class="form-control datepicker" id="new_shipment_date" value="" placeholder="در صورت مشخص بودن تاریخ ارسال وارد کنید">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="form-label" for="new_payment_term_days">مهلت تسویه از تاریخ فاکتور (روز)</label>
                                    <input type="number" class="form-control" id="new_payment_term_days" min="0" max="3650" step="1" placeholder="تعیین نشده" value="">
                                    <small class="text-soft">صفر: تسویه همان روز؛ خالی: سررسید تعیین نشده</small>
                                </div>
                                <div class="form-group">
                                    <label class="form-label" for="new_factor_number">شماره فاکتور</label>
                                    <div class="form-control-wrap">
                                        <div class="form-icon form-icon-left">
                                            <em class="icon ni ni-tag-alt"></em>
                                        </div>
                                        <input type="text" class="form-control" id="new_factor_number"
                                               value="<?php echo $number; ?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="card">
                            <div class="card-inner  pb-0">
                                <div class="nk-block-between">
                                    <h6 class="nk-block-title">آدرس تحویل سفارش</h6>
                                    <a href="#" class="btn btn-icon btn-primary" id="open_addUserAddress"><em class="icon
                                 ni ni-plus"></em></a>
                                </div>
                            </div>
                            <div class="card-inner address_wrapper">
								<?php
								echo kph_get_template( "misc/addresses.php", [
									'addresses' => $addresses,
									'user_id'   => $customer_id,
                                    'selected' => null,
								] );
								?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
	
