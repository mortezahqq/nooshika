<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * @var array $ids
 * @var int   $user_id
 * @var array $date
 * @var array $request
 */

global $wpdb;

$DB = new kph_db();

$ids     = isset( $ids ) && is_array( $ids ) ? array_map( 'absint', $ids ) : [];
$user_id = isset( $user_id ) ? absint( $user_id ) : 0;

$date_from = trim( $date['from'] ?? '' );
$date_to   = trim( $date['to'] ?? '' );

$transfers_table = $wpdb->prefix . 'kph_transfers';

$entries = [];

if ( ! empty( $ids ) ) {
	$placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
	
	$entries = $wpdb->get_results(
		$wpdb->prepare(
			"
			SELECT *
			FROM {$transfers_table}
			WHERE id IN ({$placeholders})
			ORDER BY transferred_at ASC, id ASC
			",
			$ids
		),
		ARRAY_A
	);
} else {
	if ( ! $user_id && ! $date_from && ! $date_to ) {
		wp_die( 'برای پرینت حواله‌ها باید شناسه‌ها، کاربر یا بازه تاریخی مشخص شود.' );
	}
	
	$entries_result = $DB->get_transfers_list( [
		'user_id'   => $user_id,
		'page'      => 1,
		'per_page'  => 5000,
		'date_from' => $date_from ? $date_from . ' 00:00:00' : NULL,
		'date_to'   => $date_to ? $date_to . ' 23:59:59' : NULL,
		'orderby'   => 'transferred_at',
		'order'     => 'ASC',
	] );
	
	$entries = $entries_result['items'] ?? [];
}

if ( empty( $entries ) ) {
	wp_die( 'حواله‌ای برای پرینت یافت نشد.' );
}

$logo = get_option( 'kph_print_logo' );

if ( ! $logo ) {
	$logo = get_option( 'kph_panel_logo' );
}

if ( ! $logo ) {
	$logo = KPH_ASSETS_URL . 'image/kasebi_logo.png';
}

$report_title = 'گزارش حواله‌ها';

if ( count( $entries ) === 1 ) {
	$report_title = 'رسید حواله';
}

$customer_title = $user_id ? kph_print_user_name( $user_id ) : 'همه کاربران';

$total_positive = 0;
$total_negative = 0;
$total_abs      = 0;

foreach ( $entries as $entry ) {
	$amount = (float) $entry['amount'];
	
	if ( $amount >= 0 ) {
		$total_positive += $amount;
	} else {
		$total_negative += abs( $amount );
	}
	
	$total_abs += abs( $amount );
}

$range_label = 'همه تاریخ‌ها';

if ( $date_from || $date_to ) {
	$range_label = trim( ( $date_from ?: 'ابتدا' ) . ' تا ' . ( $date_to ?: 'امروز' ) );
}

?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title><?php echo esc_html( $report_title ); ?></title>
    <link rel="stylesheet" id="nooshika_fonts_css-css"
          href="/wp-content/plugins/nooshika-main/assets/css/nooshika-fonts.css?ver=5.4.0"
          media="all">
    <style>
        @page {
            size: A4 portrait;
            margin: 10mm;
        }
        
        * {
            box-sizing: border-box;
        }
        
        body {
            direction: rtl;
            margin: 0;
            background: #fff;
            color: #111;
            font-size: 12px;
            line-height: 1.8;
        }
        
        .print-actions {
            position: fixed;
            top: 12px;
            left: 12px;
            z-index: 99;
        }
        
        .print-actions button {
            border: 0;
            background: #111827;
            color: #fff;
            border-radius: 7px;
            padding: 8px 14px;
            cursor: pointer;
            font-family: inherit;
        }
        
        .print-page {
            width: 100%;
            min-height: 277mm;
            padding: 0;
        }
        
        .print-header {
            display: grid;
            grid-template-columns: 120px 1fr 190px;
            gap: 12px;
            align-items: start;
            margin-bottom: 10px;
        }
        
        .print-logo img {
            max-width: 100px;
            max-height: 70px;
            object-fit: contain;
        }
        
        .print-title {
            text-align: center;
            font-size: 17px;
            font-weight: 700;
            padding-top: 8px;
        }
        
        .print-meta {
            text-align: right;
            font-size: 12px;
            line-height: 2;
        }
        
        .info-box {
            border: 1px solid #222;
            border-radius: 7px;
            padding: 8px 10px;
            margin-bottom: 8px;
            position: relative;
        }
        
        .info-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 8px;
        }
        
        .info-item strong {
            font-weight: 700;
        }
        
        .summary-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 8px;
            margin-bottom: 8px;
        }
        
        .summary-card {
            border: 1px solid #222;
            border-radius: 7px;
            padding: 7px 10px;
            text-align: center;
        }
        
        .summary-card .label {
            font-size: 11px;
            color: #333;
            margin-bottom: 4px;
        }
        
        .summary-card .value {
            font-weight: 700;
            font-size: 14px;
            direction: ltr;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .transfer-table th,
        .transfer-table td {
            border: 1px solid #222;
            padding: 4px 6px;
            vertical-align: middle;
        }
        
        .transfer-table th {
            background: #d9d9d9;
            font-weight: 700;
            text-align: center;
        }
        
        .transfer-table td {
            text-align: center;
        }
        
        .transfer-table .text-right {
            text-align: right;
        }
        
        .transfer-table .ltr {
            direction: ltr;
            text-align: left;
        }
        
        .summary-row td {
            background: #d9d9d9;
            font-weight: 700;
        }
        
        .text-success {
            color: #047857;
        }
        
        .text-danger {
            color: #b91c1c;
        }
        
        .signatures {
            display: grid;
            grid-template-columns: 1fr 1fr;
            margin-top: 35px;
            text-align: center;
            font-weight: 700;
        }
        
        .signature-box {
            min-height: 55px;
        }
        
        .footer-note {
            margin-top: 20px;
            text-align: center;
            font-size: 10px;
            color: #444;
        }
        
        @media print {
            .print-actions {
                display: none;
            }
            
            body {
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
        }
    </style>
</head>
<body>

<div class="print-actions">
    <button onclick="window.print()">پرینت</button>
</div>

<section class="print-page">
    <div class="print-header">
        <div class="print-logo">
            <img src="<?php echo esc_url( $logo ); ?>" alt="">
        </div>

        <div class="print-title">
			<?php echo esc_html( $report_title ); ?>
        </div>

        <div class="print-meta">
            <div>تاریخ چاپ: <?php echo esc_html( date_i18n( 'Y/m/d' ) ); ?></div>
            <div>تعداد حواله: <?php echo esc_html( number_format( count( $entries ) ) ); ?></div>
            <div>بازه: <?php echo esc_html( $range_label ); ?></div>
        </div>
    </div>

    <div class="info-box">
        <div class="info-grid">
            <div class="info-item">
                <strong>طرف حساب:</strong>
				<?php echo esc_html( $customer_title ); ?>
            </div>
            <div class="info-item">
                <strong>از تاریخ:</strong>
				<?php echo esc_html( $date_from ?: '-' ); ?>
            </div>
            <div class="info-item">
                <strong>تا تاریخ:</strong>
				<?php echo esc_html( $date_to ?: '-' ); ?>
            </div>
        </div>
    </div>

    <div class="summary-grid">
        <div class="summary-card">
            <div class="label">جمع مبالغ مثبت</div>
            <div class="value text-danger"><?php echo esc_html( kph_print_money( $total_positive ) ); ?> ریال</div>
        </div>

        <div class="summary-card">
            <div class="label">جمع مبالغ منفی</div>
            <div class="value text-success"><?php echo esc_html( kph_print_money( $total_negative ) ); ?> ریال</div>
        </div>

        <div class="summary-card">
            <div class="label">جمع کل حواله‌ها</div>
            <div class="value"><?php echo esc_html( kph_print_money( $total_abs ) ); ?> ریال</div>
        </div>
    </div>

    <table class="transfer-table">
        <thead>
        <tr>
            <th style="width: 35px;">ردیف</th>
			<?php if ( ! $user_id ) { ?>
                <th style="width: 150px;">کاربر</th>
			<?php } ?>
            <th style="width: 90px;">تاریخ حواله</th>
            <th style="width: 125px;">مبلغ</th>
            <th style="width: 110px;">بانک</th>
            <th style="width: 120px;">کد رهگیری</th>
            <th style="width: 80px;">فاکتور</th>
            <th>یادداشت</th>
            <th style="width: 110px;">ثبت‌کننده</th>
        </tr>
        </thead>

        <tbody>
		<?php
		$row = 1;
		foreach ( $entries as $entry ) {
			$entry_id   = (int) $entry['id'];
			$amount     = (float) $entry['amount'];
			$amount_abs = abs( $amount );
			
			$amount_class = $amount < 0 ? 'text-success' : 'text-danger';
			$amount_sign  = $amount < 0 ? '-' : '+';
			
			$creator_id = (int) $DB->get_transfer_meta( $entry_id, 'creator_id' );
			$creator    = $creator_id ? kph_print_user_name( $creator_id ) : '-';
			
			$entry_user_id = (int) $entry['user_id'];
			?>
            <tr>
                <td><?php echo esc_html( $row ); ?></td>
				
				<?php if ( ! $user_id ) { ?>
                    <td class="text-right">
						<?php echo esc_html( kph_print_user_name( $entry_user_id ) ); ?>
                    </td>
				<?php } ?>

                <td><?php echo esc_html( kph_print_date( $entry['transferred_at'] ) ); ?></td>

                <td class="ltr <?php echo esc_attr( $amount_class ); ?>">
					<?php echo esc_html( $amount_sign . ' ' . kph_print_money( $amount_abs ) ); ?>
                </td>

                <td><?php echo esc_html( $entry['bank_name'] ?: '-' ); ?></td>

                <td><?php echo esc_html( $entry['tracking_no'] ?: '-' ); ?></td>

                <td>
					<?php
					if ( ! empty( $entry['ref_id'] ) ) {
						echo esc_html( '#' . $entry['ref_id'] );
					} else {
						echo '-';
					}
					?>
                </td>

                <td class="text-right">
					<?php echo wp_kses_post( $entry['note'] ? nl2br( $entry['note'] ) : '-' ); ?>
                </td>

                <td><?php echo esc_html( $creator ); ?></td>
            </tr>
			<?php
			$row ++;
		}
		?>

        <tr class="summary-row">
            <td colspan="<?php echo $user_id ? 7 : 8; ?>" class="text-right">جمع کل مبالغ حواله‌ها</td>
            <td class="ltr"><?php echo esc_html( kph_print_money( $total_abs ) ); ?></td>
        </tr>
        </tbody>
    </table>

    <div class="signatures">
        <div class="signature-box">امضا واحد مالی</div>
        <div class="signature-box">امضا طرف حساب</div>
    </div>

    <div class="footer-note">
        این گزارش بر اساس حواله‌های ثبت‌شده در سیستم صادر شده است.
    </div>
</section>

</body>
</html>