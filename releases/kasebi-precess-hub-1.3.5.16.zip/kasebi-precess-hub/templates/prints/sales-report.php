<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Print requests run before the CRM page's login check.
if ( ! is_user_logged_in() || ! current_user_can( 'manage_options' ) ) {
	wp_die( 'اجازهٔ مشاهدهٔ گزارش فروش را ندارید.', '', [ 'response' => 403 ] );
}

$request = isset( $request ) && is_array( $request ) ? $request : [];
$titles = [
	'all'        => 'گزارش کامل فروش',
	'summary'    => 'خلاصهٔ عملکرد فروش',
	'sales'      => 'نمودار فروش کالاهای ارسال‌شده',
	'profit'     => 'نمودار برکت ناخالص',
	'orders'     => 'نمودار تعداد سفارش‌های معتبر',
	'comparison' => 'جدول مقایسهٔ دوره‌های فروش',
	'status'     => 'وضعیت سفارش‌ها',
	'products'   => 'جزئیات فروش و برکت محصولات',
];
$section = is_string( $request['section'] ?? NULL ) ? sanitize_key( $request['section'] ) : 'all';
$period = is_string( $request['period'] ?? NULL ) ? sanitize_key( $request['period'] ) : 'daily';
if ( ! isset( $titles[$section] ) || ! in_array( $period, [ 'daily', 'monthly', 'yearly' ], TRUE ) ) {
	wp_die( 'بخش یا گروه‌بندی گزارش فروش معتبر نیست.' );
}

// Links carry the effective Gregorian range, not the optional Jalali filter input.
$range = [];
foreach ( [ 'range_from', 'range_to' ] as $key ) {
	$value = is_string( $request[$key] ?? NULL ) ? $request[$key] : '';
	$parsed = DateTimeImmutable::createFromFormat( '!Y-m-d', $value, wp_timezone() );
	if ( ! $parsed || $parsed->format( 'Y-m-d' ) !== $value ) {
		wp_die( 'بازهٔ چاپ معتبر نیست؛ از دکمهٔ پرینت گزارش فروش استفاده کنید.' );
	}
	$range[$key] = $value;
}
if ( $range['range_from'] > $range['range_to'] ) {
	wp_die( 'تاریخ شروع گزارش باید پیش از تاریخ پایان باشد.' );
}

$DB = new kph_db();
$chart_report = $DB->get_sales_performance_chart_report( [
	'period' => $period, 'date_from' => $range['range_from'], 'date_to' => $range['range_to'],
] );
$ranges = $chart_report['ranges'];
$current = $chart_report['summary']['current'];
$previous = $chart_report['summary']['previous'];
$orders_report = in_array( $section, [ 'all', 'status', 'products' ], TRUE )
	? $DB->get_orders_report( $ranges['current_start_sql'], $ranges['current_end_sql'] ) : NULL;
$number = static function ( $value, int $decimals = 0 ): string { return number_format_i18n( (float) $value, $decimals ); };
$change = static function ( $now, $before, bool $margin = FALSE ) use ( $number ): string {
	if ( ! $margin && $before == 0 && $now != 0 ) { return 'قابل محاسبه نیست؛ مبنای قبلی صفر است'; }
	$value = round( $margin ? $now - $before : ( $before != 0 ? ( $now - $before ) / abs( $before ) * 100 : 0 ), 2 );
	return $value == 0 ? 'بدون تغییر' : $number( abs( $value ), 2 ) . ( $margin ? ' واحد درصد ' : '٪ ' ) . ( $value > 0 ? 'افزایش' : 'کاهش' );
};
$date_label = static function ( string $key ) use ( $period ): string {
	if ( $key === '' ) { return '—'; }
	if ( $period !== 'daily' ) { return str_replace( '-', '/', $key ) . ' میلادی'; }
	return date_i18n( 'Y/m/d', ( new DateTimeImmutable( $key, wp_timezone() ) )->getTimestamp() );
};
$table = static function ( array $headers, array $rows, array $total = [] ): void {
	echo '<table><thead><tr>';
	foreach ( $headers as $header ) { echo '<th scope="col">' . esc_html( $header ) . '</th>'; }
	echo '</tr></thead><tbody>';
	if ( ! $rows ) { echo '<tr><td colspan="' . count( $headers ) . '">گزارشی یافت نشد.</td></tr>'; }
	foreach ( $rows as $row ) {
		echo '<tr>';
		foreach ( $row as $value ) { echo '<td><bdi>' . esc_html( $value ) . '</bdi></td>'; }
		echo '</tr>';
	}
	// Keep totals at the end, rather than repeating a grand total on every printed page.
	if ( $total ) {
		echo '<tr class="total">';
		foreach ( $total as $value ) { echo '<td><bdi>' . esc_html( $value ) . '</bdi></td>'; }
		echo '</tr>';
	}
	echo '</tbody></table>';
};
$metric_titles = [ 'sales' => 'فروش ارسال‌شده', 'profit' => 'برکت ناخالص', 'orders' => 'تعداد سفارش‌های معتبر' ];
$chart_payload = [];
$logo = get_option( 'kph_print_logo' ) ?: get_option( 'kph_panel_logo' );
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo esc_html( $titles[$section] ); ?></title>
    <style>
        @font-face { font-family: SalesPrint; src: url('<?php echo esc_url( KPH_ASSETS_URL . 'fonts/woff2/IRANSansXFaNum-RegularD4.woff2' ); ?>') format('woff2'); }
        @page { size: A4 landscape; margin: 10mm; }
        * { box-sizing: border-box; }
        body { margin: 0; color: #172033; background: #f3f4f6; font: 11px/1.8 SalesPrint, Tahoma, sans-serif; }
        main { max-width: 1100px; margin: 20px auto; padding: 24px; background: white; }
        header { border-bottom: 2px solid #334155; padding-bottom: 12px; margin-bottom: 16px; }
        header img { float: left; max-width: 90px; max-height: 60px; object-fit: contain; }
        h1 { font-size: 20px; margin: 0 0 10px; } h2 { font-size: 15px; margin: 0 0 8px; break-after: avoid; }
        p { margin: 4px 0; } section { margin-top: 20px; } .note { color: #475569; }
        table { width: 100%; border-collapse: collapse; table-layout: auto; margin: 10px 0; font-size: 10px; }
        th, td { border: 1px solid #c4cbd5; padding: 6px 4px; text-align: center; overflow-wrap: anywhere; }
        th { background: #eef1f6; } tr.total { font-weight: bold; background: #f3f4f6; }
        tr { break-inside: avoid; } thead { display: table-header-group; }
        .chart-box { break-inside: avoid; margin: 10px 0 16px; }
        canvas { display: block; max-width: 100%; height: auto !important; }
        .actions { padding: 12px; text-align: center; background: #fff; position: sticky; top: 0; z-index: 2; }
        button { background: #6d4aff; color: white; border: 0; border-radius: 6px; padding: 8px 20px; font: inherit; cursor: pointer; }
        button:disabled { opacity: .5; cursor: wait; }
        @media print {
            .actions { display: none; } body { background: white; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
            main { max-width: none; padding: 0; margin: 0; } .chart-box { width: 100%; }
        }
    </style>
</head>
<body>
<div class="actions"><button id="sales-print-button" type="button" onclick="window.print()">پرینت / ذخیره PDF</button></div>
<main>
    <header>
        <?php if ( $logo ) { ?><img src="<?php echo esc_url( $logo ); ?>" alt="لوگو"><?php } ?>
        <h1><?php echo esc_html( $titles[$section] ); ?></h1>
        <p><strong>بازهٔ انتخابی:</strong> <?php echo esc_html( $ranges['current_label'] ); ?> | <strong>بازهٔ قبلی:</strong> <?php echo esc_html( $ranges['previous_label'] ); ?></p>
        <p>گروه‌بندی: <?php echo esc_html( [ 'daily' => 'روزانه', 'monthly' => 'ماهیانه (تقویم میلادی)', 'yearly' => 'سالیانه (تقویم میلادی)' ][$period] ); ?> | تاریخ چاپ: <?php echo esc_html( date_i18n( 'Y/m/d H:i' ) ); ?></p>
        <p class="note">همهٔ مبالغ به ریال است. مبنای تاریخ، ثبت سفارش و مبنای فروش، اقلام ارسال‌شده است. برکت ناخالص = فروش − بهای تمام‌شدهٔ ارسال‌ها، شامل هدایا.</p>
    </header>

    <?php if ( in_array( $section, [ 'all', 'summary' ], TRUE ) ) { ?>
    <section><h2>خلاصهٔ عملکرد فروش</h2>
        <?php
        $rows = [];
        foreach ( [ 'sales' => 'فروش (ریال)', 'profit' => 'برکت ناخالص (ریال)', 'profit_percent' => 'حاشیهٔ برکت (٪)', 'order_count' => 'تعداد سفارش معتبر' ] as $key => $label ) {
            $margin = $key === 'profit_percent';
            $rows[] = [ $label, $margin && $current['sales'] <= 0 ? '—' : $number( $current[$key], $margin ? 2 : 0 ), $margin && $previous['sales'] <= 0 ? '—' : $number( $previous[$key], $margin ? 2 : 0 ), $margin && ( $current['sales'] <= 0 || $previous['sales'] <= 0 ) ? '—' : $change( $current[$key], $previous[$key], $margin ) ];
        }
        $table( [ 'شاخص', 'بازهٔ انتخابی', 'بازهٔ قبلی', 'تغییر نسبت به قبل' ], $rows );
        ?>
    </section>
    <?php } ?>

    <?php foreach ( $metric_titles as $metric => $label ) {
        if ( $section !== 'all' && $section !== $metric ) { continue; }
        $chart = $chart_report['charts'][$metric];
        $unit = $metric === 'orders' ? 'سفارش' : 'ریال';
        $labels = [];
        $rows = [];
        foreach ( $ranges['buckets'] as $index => $bucket ) {
            $labels[] = $period === 'daily' ? date_i18n( 'm/d', ( new DateTimeImmutable( $bucket['current_key'], wp_timezone() ) )->getTimestamp() ) : $bucket['current_key'];
            $rows[] = [ $date_label( $bucket['current_key'] ), $date_label( $bucket['previous_key'] ), $number( $chart['data'][0][$index] ), $number( $chart['data'][1][$index] ) ];
        }
        $chart_payload[] = [ 'id' => 'print-' . $metric, 'type' => $metric === 'sales' ? 'line' : 'bar', 'unit' => $unit, 'labels' => $labels, 'data' => $chart['data'] ];
        ?>
    <section>
        <div class="chart-box"><h2><?php echo esc_html( $label ); ?></h2>
            <p class="note">تاریخ‌های محور مربوط به بازهٔ انتخابی است؛ هر نقطه با دورهٔ هم‌موقعیت در بازهٔ قبلی مقایسه می‌شود.</p>
            <canvas id="<?php echo esc_attr( 'print-' . $metric ); ?>" width="1000" height="280" role="img" aria-label="<?php echo esc_attr( $label ); ?>"></canvas>
            <p class="chart-error" hidden>نمودار بارگذاری نشد؛ اعداد دقیق در جدول گزارش موجود است.</p>
        </div>
        <?php if ( $section !== 'all' ) {
            $table( [ 'دورهٔ انتخابی', 'دورهٔ قبلی', 'مقدار انتخابی (' . $unit . ')', 'مقدار قبلی (' . $unit . ')' ], $rows, [ 'جمع کل', '—', $number( array_sum( $chart['data'][0] ) ), $number( array_sum( $chart['data'][1] ) ) ] );
        } ?>
    </section>
    <?php } ?>

    <?php if ( in_array( $section, [ 'all', 'comparison' ], TRUE ) ) { ?>
    <section><h2>جدول اعداد دقیق و مقایسهٔ دوره‌ها</h2>
        <?php
        $rows = [];
        foreach ( $ranges['buckets'] as $index => $bucket ) {
            $row = [ $date_label( $bucket['current_key'] ), $date_label( $bucket['previous_key'] ) ];
            foreach ( [ 'sales', 'profit', 'orders' ] as $metric ) {
                foreach ( [ 0, 1 ] as $series ) { $row[] = $number( $chart_report['charts'][$metric]['data'][$series][$index] ); }
                if ( $metric !== 'orders' ) { $row[] = $change( $chart_report['charts'][$metric]['data'][0][$index], $chart_report['charts'][$metric]['data'][1][$index] ); }
            }
            $rows[] = $row;
        }
        $total = [ 'جمع کل', '—' ];
        foreach ( [ 'sales', 'profit', 'order_count' ] as $metric ) {
            $total[] = $number( $current[$metric] ); $total[] = $number( $previous[$metric] );
            if ( $metric !== 'order_count' ) { $total[] = $change( $current[$metric], $previous[$metric] ); }
        }
        $table( [ 'دورهٔ انتخابی', 'دورهٔ قبلی', 'فروش انتخابی', 'فروش قبلی', 'تغییر فروش', 'برکت انتخابی', 'برکت قبلی', 'تغییر برکت', 'سفارش انتخابی', 'سفارش قبلی' ], $rows, $total );
        ?>
    </section>
    <?php } ?>

    <?php if ( in_array( $section, [ 'all', 'status' ], TRUE ) ) { ?>
    <section><h2>وضعیت سفارش‌ها در بازهٔ انتخابی</h2>
        <p class="note">تعداد کل و اقلام ارسال‌نشده شامل همهٔ وضعیت‌هاست؛ مبلغ پیش‌فاکتور جدا از فروش واقعی گزارش می‌شود.</p>
        <?php
        $status = $orders_report['summary'];
        $table( [ 'تعداد کل سفارش‌ها', 'سفارش‌های تأییدشده', 'اقلام ارسال‌نشده', 'مبلغ پیش‌فاکتورها (ریال)' ], [ [ $number( $status['total_invoices'] ), $number( $status['total_registered'] ), $number( $status['total_shortage_qty'] ), $number( $status['total_proforma_amount'] ) ] ] );
        ?>
    </section>
    <?php } ?>

    <?php if ( in_array( $section, [ 'all', 'products' ], TRUE ) ) { ?>
    <section><h2>جزئیات فروش و برکت محصولات</h2>
        <p class="note">حاشیهٔ برکت = برکت ÷ فروش × ۱۰۰؛ بدون فروش مثبت با «—» نمایش داده می‌شود. تعداد سفارش‌های هر محصول مستقل است و قابل جمع نیست.</p>
        <?php
        $rows = [];
        $totals = [ 'shipped_paid_qty' => 0, 'shipped_free_qty' => 0, 'total_sales_amount' => 0, 'total_cogs' => 0, 'total_shortage_qty' => 0 ];
        foreach ( $orders_report['items'] as $item ) {
            $profit = (float) $item['total_sales_amount'] - (float) $item['total_cogs'];
            foreach ( $totals as $key => $value ) { $totals[$key] += (float) $item[$key]; }
            $rows[] = [ get_the_title( $item['wc_product_id'] ), $item['unique_product_code'], $number( $item['order_count'] ), $number( $item['shipped_paid_qty'] ), $number( $item['shipped_free_qty'] ), $number( $item['total_sales_amount'] ), $number( $item['total_cogs'] ), $number( $profit ), $item['total_sales_amount'] > 0 ? $number( $profit / $item['total_sales_amount'] * 100, 2 ) . '٪' : '—', $number( $item['total_shortage_qty'] ) ];
        }
        $profit = $totals['total_sales_amount'] - $totals['total_cogs'];
        $table( [ 'محصول', 'کد', 'سفارش', 'ارسال پولی', 'هدیه', 'فروش (ریال)', 'بهای تمام‌شده', 'برکت ناخالص', 'حاشیهٔ برکت', 'ارسال‌نشده' ], $rows,
            [ 'جمع محصولات', '—', '—', $number( $totals['shipped_paid_qty'] ), $number( $totals['shipped_free_qty'] ), $number( $totals['total_sales_amount'] ), $number( $totals['total_cogs'] ), $number( $profit ), $totals['total_sales_amount'] > 0 ? $number( $profit / $totals['total_sales_amount'] * 100, 2 ) . '٪' : '—', $number( $totals['total_shortage_qty'] ) ] );
        ?>
    </section>
    <?php } ?>
</main>
<?php if ( $chart_payload ) { ?>
<script src="<?php echo esc_url( KPH_ASSETS_URL . 'js/bundle.js' ); ?>"></script>
<script>
(function () {
    const charts = <?php echo wp_json_encode( $chart_payload, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT ); ?>;
    const button = document.getElementById('sales-print-button');
    button.disabled = true;
    const ready = document.fonts ? document.fonts.ready : Promise.resolve();
    ready.then(function () {
        try {
            charts.forEach(function (item) {
                const values = item.data.reduce(function (all, series) { return all.concat(series); }, []);
                const max = values.reduce(function (value, next) { return Math.max(value, Math.abs(next)); }, 0);
                const divisor = item.unit !== 'ریال' ? 1 : max >= 1e9 ? 1e9 : max >= 1e6 ? 1e6 : max >= 1e3 ? 1e3 : 1;
                const unit = ({1000000000:'میلیارد ریال',1000000:'میلیون ریال',1000:'هزار ریال'})[divisor] || item.unit;
                const format = new Intl.NumberFormat('fa-IR', {maximumFractionDigits:2});
                new Chart(document.getElementById(item.id), {
                    type: item.type,
                    data: {labels:item.labels, datasets:item.data.map(function (data, i) { return {
                        label:i === 0 ? 'بازهٔ انتخابی' : 'بازهٔ قبلی', data:data,
                        borderColor:i === 0 ? '#6d4aff' : '#c47f27', backgroundColor:i === 0 ? '#6d4aff' : '#c47f27',
                        borderWidth:2, borderDash:i === 0 ? [] : [5,5], fill:false, lineTension:0,
                        pointRadius:data.length === 1 ? 4 : 0, maxBarThickness:16,
                    }; })},
                    options: {
                        responsive:false, animation:{duration:0}, devicePixelRatio:2,
                        legend:{position:'bottom',rtl:true,labels:{fontFamily:'SalesPrint',fontSize:11}},
                        tooltips:{enabled:false},
                        scales:{
                            xAxes:[{gridLines:{display:false},ticks:{fontFamily:'SalesPrint',maxRotation:0,minRotation:0,maxTicksLimit:10}}],
                            yAxes:[{scaleLabel:{display:true,labelString:unit,fontFamily:'SalesPrint'},gridLines:{zeroLineColor:'#64748b'},ticks:{fontFamily:'SalesPrint',beginAtZero:true,maxTicksLimit:6,precision:item.unit === 'سفارش' ? 0 : undefined,callback:function (value) {return format.format(value / divisor);}}}],
                        },
                    },
                });
            });
        } catch (error) {
            document.querySelectorAll('.chart-error').forEach(function (node) { node.hidden = false; });
        } finally { button.disabled = false; }
    });
})();
</script>
<noscript><p>برای نمایش نمودارها جاوااسکریپت را فعال کنید. اعداد دقیق در جدول‌ها قابل چاپ است.</p></noscript>
<?php } ?>
</body>
</html>
