<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
// Print routing precedes the CRM login check.
if ( ! is_user_logged_in() || ! current_user_can( 'manage_options' ) ) { wp_die( 'اجازهٔ مشاهدهٔ گزارش مشتریان را ندارید.', '', [ 'response' => 403 ] ); }
$report_request = isset( $request ) && is_array( $request ) ? $request : [];
$selected_customer_id = is_scalar( $report_request['customer_id'] ?? 0 ) ? absint( $report_request['customer_id'] ?? 0 ) : 0;
$order_id = is_scalar( $report_request['order_id'] ?? 0 ) ? absint( $report_request['order_id'] ?? 0 ) : 0;
$section = is_string( $report_request['section'] ?? NULL ) ? $report_request['section'] : 'all';
if ( ! in_array( $section, [ 'all', 'summary', 'customers', 'invoices', 'receivables' ], TRUE ) || ( $section === 'invoices' && ! $selected_customer_id ) ) { wp_die( 'بخش چاپ معتبر نیست.' ); }
require dirname( __DIR__ ) . '/partials/customer-report-context.php';
$DB = new kph_db();
$is_print = TRUE;
$customer_rows = $selected_customer_id ? [ [ 'user_id' => $selected_customer_id, 'display_name' => get_the_author_meta( 'display_name', $selected_customer_id ) ] ] : $DB->get_all_customer_report_rows( $customer_report_args );
$receivables = in_array( $section, [ 'all', 'customers', 'invoices', 'receivables' ], TRUE ) ? $DB->get_customer_report_aging( $customer_rows ) : [];
$invoices = $selected_customer_id && in_array( $section, [ 'all', 'invoices' ], TRUE ) ? $DB->get_customer_invoice_report( $selected_customer_id, array_merge( $customer_report_args, [ 'order_id' => $order_id ] ) ) : [];
if ( $order_id && ! $invoices ) { wp_die( 'فاکتور متعلق به این مشتری و بازه یافت نشد.' ); }
$money = static fn( $value ) => number_format_i18n( (float) $value );
?>
<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>چاپ گزارش مشتریان</title>
<style>
@font-face { font-family: CustomerPrint; src: url('<?php echo esc_url( KPH_ASSETS_URL . 'fonts/woff2/IRANSansXFaNum-RegularD4.woff2' ); ?>') format('woff2'); }
@page { size: A4 landscape; margin: 12mm; }
body { background: #eef1f6; font: 12px/1.8 CustomerPrint, Tahoma, sans-serif; margin: 0; }
main { max-width: 1150px; margin: 24px auto; background: white; padding: 24px; }
h1 { font-size: 21px; } header { border-bottom: 2px solid #334155; padding-bottom: 15px; }
button { padding: 8px 20px; cursor: pointer; } .print-actions { text-align: center; margin: 15px; }
@media print { body { background: white; } main { margin: 0; padding: 0; max-width: none; } .print-actions { display: none; } }
</style>
<?php require dirname( __DIR__ ) . '/partials/customer-report-style.php'; ?>
</head><body><div class="print-actions"><button onclick="window.print()">چاپ / ذخیره PDF</button></div><main class="kph-customer-report">
<header><h1><?php echo $selected_customer_id ? 'گزارش مشتری: ' . esc_html( get_the_author_meta( 'display_name', $selected_customer_id ) ) : 'گزارش مشتریان'; ?></h1>
<p>بازهٔ ثبت سفارش: <?php echo esc_html( ( $customer_filter_args['date']['from'] ?: 'از ابتدا' ) . ' تا ' . ( $customer_filter_args['date']['to'] ?: 'امروز' ) ); ?> | مبالغ: ریال</p>
<p>زمان تهیه: <?php echo esc_html( date_i18n( 'Y/m/d H:i' ) ); ?></p>
<?php foreach ( [ 'search' => 'جستجو', 'level' => 'سطح', 'balance_side' => 'وضعیت حساب', 'due_state' => 'فیلتر سررسید' ] as $key => $label ) { if ( ! empty( $customer_filter_args[$key] ) && $customer_filter_args[$key] !== 'all' ) { ?><span><?php echo esc_html( $label . ': ' . $customer_filter_args[$key] ); ?> &nbsp; </span><?php } } ?>
</header>
<?php if ( ! $selected_customer_id && in_array( $section, [ 'all', 'summary' ], TRUE ) ) {
	$fields = [ 'purchase_amount' => 'مجموع خرید', 'payment_amount' => 'مجموع پرداخت', 'bounced_cheque_amount' => 'مجموع چک برگشتی' ]; ?>
<section class="report-card"><h4>خلاصهٔ گزارش</h4><p>تعداد مشتریان: <?php echo count( $customer_rows ); ?></p><table><tbody>
<?php foreach ( $fields as $key => $label ) { ?><tr><th><?php echo esc_html( $label ); ?></th><td><?php echo esc_html( $money( array_sum( array_column( $customer_rows, $key ) ) ) ); ?></td></tr><?php } ?>
<tr><th>جمع بدهکاری</th><td><?php echo esc_html( $money( array_sum( array_map( static fn( $row ) => max( 0, $row['balance'] ), $customer_rows ) ) ) ); ?></td></tr>
<tr><th>جمع بستانکاری</th><td><?php echo esc_html( $money( array_sum( array_map( static fn( $row ) => max( 0, -$row['balance'] ), $customer_rows ) ) ) ); ?></td></tr>
</tbody></table></section><?php } ?>
<?php if ( ! $selected_customer_id && in_array( $section, [ 'all', 'customers' ], TRUE ) ) { $levels = $DB->get_customer_levels(); ?>
<section class="report-card"><h4>جدول مشتریان</h4><table><thead><tr><th>مشتری / سطح</th><th>خرید / تعداد</th><th>پرداخت</th><th>چک برگشتی</th><th>مانده حساب</th><th>سررسید فعلی</th><th>محصول پرتکرار</th><th>آخرین خرید</th></tr></thead><tbody>
<?php foreach ( $customer_rows as $row ) { $aging = $receivables[(int) $row['user_id']] ?? NULL; ?>
<tr><td><?php echo esc_html( $row['display_name'] ); ?><br><small><?php echo esc_html( $levels[$row['customer_level']]['label'] ?? 'بدون سطح' ); ?></small></td>
<td><?php echo esc_html( $money( $row['purchase_amount'] ) ); ?><br><small><?php echo esc_html( $money( $row['order_count'] ) . ' فاکتور / ' . $money( $row['ordered_qty'] ) . ' کالا' ); ?></small></td>
<td><?php echo esc_html( $money( $row['payment_amount'] ) ); ?><br><small><?php echo esc_html( $row['payment_percent'] ); ?>٪ نسبت به خرید</small></td>
<td><?php echo esc_html( $money( $row['bounced_cheque_amount'] ) ); ?><br><small><?php echo esc_html( $money( $row['bounced_cheque_count'] ) ); ?> چک</small></td>
<td><?php echo esc_html( $money( abs( $row['balance'] ) ) . ( $row['balance'] > 0 ? ' بدهکار' : ( $row['balance'] < 0 ? ' بستانکار' : ' تسویه' ) ) ); ?></td>
<td><?php if ( $aging ) { echo esc_html( $money( $aging['overdue'] ) . ' ریال دیرکرد' ); if ( $aging['average_days'] !== NULL ) { ?><br><small><?php echo esc_html( 'میانگین: ' . number_format_i18n( abs( $aging['average_days'] ), 1 ) . ( $aging['average_days'] < 0 ? ' روز دیرکرد' : ' روز مانده' ) ); ?></small><?php } if ( $aging['unknown'] > 0 ) { ?><br><small>دارای فاکتور بدون سررسید</small><?php } } else { echo '—'; } ?></td>
<td><?php echo esc_html( $row['top_product_title'] ); ?><br><small><?php echo esc_html( $money( $row['top_product_qty'] ) ); ?> عدد</small></td>
<td><?php echo esc_html( $row['last_order_at'] ? date_i18n( 'Y/m/d', strtotime( $row['last_order_at'] ) ) : '—' ); ?></td></tr>
<?php } ?>
<?php if ( ! $customer_rows ) { ?><tr><td colspan="8">گزارشی یافت نشد.</td></tr><?php } ?>
</tbody></table></section><?php } ?>
<?php if ( in_array( $section, [ 'all', 'receivables' ], TRUE ) ) { require dirname( __DIR__ ) . '/partials/customer-receivables-report.php'; } ?>
<?php if ( $selected_customer_id && in_array( $section, [ 'all', 'invoices' ], TRUE ) ) { require dirname( __DIR__ ) . '/partials/customer-invoices-report.php'; } ?>
</main></body></html>
