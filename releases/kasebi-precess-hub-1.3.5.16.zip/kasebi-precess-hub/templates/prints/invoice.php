<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * @var array $ids
 * @var int   $user_id
 * @var array $date
 * @var array $request
 */

$DB = new kph_db();

$ids     = isset( $ids ) && is_array( $ids ) ? array_map( 'absint', $ids ) : [];
$user_id = isset( $user_id ) ? absint( $user_id ) : 0;

$date_from = trim( $date['from'] ?? '' );
$date_to   = trim( $date['to'] ?? '' );

$normalize_print_date = static function( string $value, string $time ): string {
	$value = trim( $value );
	
	if ( $value === '' ) {
		return '';
	}
	
	$value = nooshika_sanitize_numbers( $value );
	$value = str_replace( '/', '-', $value );
	
	if ( function_exists( 'nooshika_jalali_to_gregorian' ) && preg_match( '/^1[34][0-9]{2}-[0-9]{1,2}-[0-9]{1,2}$/', $value ) ) {
		$converted = nooshika_jalali_to_gregorian( str_replace( '-', '/', $value ) );
		if ( $converted ) {
			$value = str_replace( '/', '-', (string) $converted );
		}
	}
	
	if ( preg_match( '/^\d{4}-\d{1,2}-\d{1,2}$/', $value ) ) {
		return $value . ' ' . $time;
	}
	
	return $value;
};

$invoices = [];

if ( ! empty( $ids ) ) {
	foreach ( $ids as $invoice_id ) {
		$data = $DB->get_invoice_data( (int) $invoice_id );
		
		if ( ! empty( $data['invoice'] ) ) {
			$invoices[] = $data;
		}
	}
} else {
	if ( ! $user_id && ! $date_from && ! $date_to ) {
		wp_die( 'برای پرینت فاکتور تامین‌کننده باید شناسه فاکتور، تامین‌کننده یا بازه تاریخی مشخص شود.' );
	}
	
	$status = sanitize_key( $request['status'] ?? '' );
	
	$res = $DB->get_supplier_invoices( [
		'page'             => 1,
		'per_page'         => 5000,
		'supplier_user_id' => $user_id,
		'status'           => $status ?: NULL,
		'date_from'        => $date_from ? $normalize_print_date( $date_from, '00:00:00' ) : NULL,
		'date_to'          => $date_to ? $normalize_print_date( $date_to, '23:59:59' ) : NULL,
		'orderby'          => 'issued_at',
		'order'            => 'ASC',
	] );
	
	foreach ( (array) ( $res['items'] ?? [] ) as $row ) {
		$data = $DB->get_invoice_data( (int) $row['id'] );
		
		if ( ! empty( $data['invoice'] ) ) {
			$invoices[] = $data;
		}
	}
}

if ( empty( $invoices ) ) {
	wp_die( 'فاکتور تامین‌کننده‌ای برای پرینت یافت نشد.' );
}

$logo = get_option( 'kph_print_logo' );

if ( ! $logo ) {
	$logo = get_option( 'kph_panel_logo' );
}

if ( ! $logo ) {
	$logo = KPH_ASSETS_URL . 'image/kasebi_logo.png';
}

$statuses = $DB->get_supplier_invoice_statuses();

$format_qty = static function( $value ): string {
	$value = (float) $value;
	
	if ( floor( $value ) === $value ) {
		return number_format( $value, 0 );
	}
	
	return rtrim( rtrim( number_format( $value, 6, '.', ',' ), '0' ), '.' );
};

$amount_words = static function( $amount ): string {
	$amount = (float) $amount;
	
	if ( function_exists( 'convert_number_to_words' ) ) {
		return convert_number_to_words( $amount ) . ' ریال';
	}
	
	return kph_print_money( $amount ) . ' ریال';
};

?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>پرینت فاکتور تامین‌کننده</title>
    <link rel="stylesheet" id="nooshika_fonts_css-css"
          href="/wp-content/plugins/nooshika-main/assets/css/nooshika-fonts.css?ver=5.4.0"
          media="all">
    <style>
        @page {
            size: A4 portrait;
            margin: 10mm;
        }
        
        * {
            box-sizing: border-box;
        }
        
        body {
            direction: rtl;
            margin: 2mm;
            background: #fff;
            color: #111;
            font-size: 12px;
            line-height: 1.8;
        }
        
        .print-page {
            width: 100%;
            min-height: 277mm;
            padding: 0;
            page-break-after: always;
        }
        
        .print-page:last-child {
            page-break-after: auto;
        }
        
        .factor-header {
            display: grid;
            grid-template-columns: 120px 1fr 190px;
            gap: 12px;
            align-items: start;
            margin-bottom: 8px;
        }
        
        .factor-logo img {
            max-width: 100px;
            max-height: 70px;
            object-fit: contain;
        }
        
        .factor-title {
            text-align: center;
            font-size: 17px;
            font-weight: 700;
            padding-top: 8px;
        }
        
        .factor-meta {
            text-align: right;
            font-size: 12px;
            line-height: 2;
        }
        
        .supplier-box,
        .note-box {
            border: 1px solid #222;
            border-radius: 7px;
            padding: 10px 10px;
            margin-bottom: 8px;
            font-weight: 700;
            position: relative;
        }
        
        .supplier-box .side-label,
        .note-box .side-label {
            position: absolute;
            left: 0;
            top: 0;
            bottom: 0;
            writing-mode: vertical-rl;
            transform: rotate(180deg);
            border-left: 1px solid #222;
            background: #e7e7e7;
            padding: 5px 3px;
            font-size: 11px;
            border-radius: 0 7px 7px 0;
            text-align: center;
        }
        
        .supplier-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 8px 16px;
            padding-left: 24px;
        }
        
        .note-box {
            font-weight: 400;
            min-height: 38px;
            padding-left: 28px;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .factor-table th,
        .factor-table td {
            border: 1px solid #222;
            padding: 4px 6px;
            vertical-align: middle;
        }
        
        .factor-table th {
            background: #d9d9d9;
            font-weight: 700;
            text-align: center;
        }
        
        .factor-table td {
            text-align: center;
        }
        
        .factor-table .desc {
            text-align: right;
        }
        
        .muted {
            display: block;
            color: #444;
            font-size: 10px;
            font-weight: 400;
        }
        
        .summary-row td {
            background: #d9d9d9;
            font-weight: 700;
        }
        
        .summary-table {
            border: 1px solid #222;
            border-top: 0;
        }
        
        .summary-table td {
            padding: 3px 8px;
        }
        
        .summary-table .label {
            width: 150px;
            font-weight: 700;
        }
        
        .summary-table .amount {
            width: 170px;
            text-align: left;
            direction: ltr;
        }
        
        .payable-box {
            display: grid;
            grid-template-columns: 1fr 170px;
            border: 1px solid #222;
            border-top: 0;
            border-radius: 0 0 8px 8px;
            overflow: hidden;
            font-weight: 700;
        }
        
        .payable-text {
            padding: 5px 8px;
            border-left: 1px solid #222;
            font-size: 11px;
        }
        
        .payable-amount {
            padding: 5px 8px;
            text-align: center;
            font-size: 14px;
            direction: ltr;
        }
        
        .signatures {
            display: grid;
            grid-template-columns: 1fr 1fr;
            margin-top: 30px;
            text-align: center;
            font-weight: 700;
        }
        
        .footer-note {
            margin-top: 25px;
            text-align: center;
            font-size: 10px;
            font-weight: 700;
        }
        
        .print-actions {
            position: fixed;
            top: 12px;
            left: 12px;
            z-index: 99;
        }
        
        .print-actions button {
            border: 0;
            background: #111827;
            color: #fff;
            border-radius: 7px;
            padding: 8px 14px;
            cursor: pointer;
            font-family: inherit;
        }
        
        @media print {
            .print-actions {
                display: none;
            }
            
            body {
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
        }
    </style>
</head>
<body>

<div class="print-actions">
    <button onclick="window.print()">پرینت</button>
</div>

<?php foreach ( $invoices as $invoice_data ) { ?>
	<?php
	$invoice = (array) ( $invoice_data['invoice'] ?? [] );
	$items   = (array) ( $invoice_data['items'] ?? [] );
	
	$invoice_id  = (int) ( $invoice['id'] ?? 0 );
	$supplier_id = (int) ( $invoice['supplier_user_id'] ?? 0 );
	$supplier    = kph_print_user_name( $supplier_id );
	
	$status_key   = (string) ( $invoice['status'] ?? '' );
	$status_label = $statuses[ $status_key ]['label'] ?? $status_key;
	
	$items_total = 0;
	$total_qty   = 0;
	
	foreach ( $items as $item ) {
		$items_total += (float) ( $item['line_total'] ?? 0 );
		$total_qty   += (float) ( $item['qty_weight'] ?? 0 );
	}
	
	$invoice_total = (float) ( $invoice['total_amount'] ?? 0 );
	
	if ( $invoice_total <= 0 ) {
		$invoice_total = $items_total;
	}
	
	$settlement = $DB->get_supplier_invoice_settlement_remaining( $invoice_id );
	$settlement = (array) ( $settlement['data'] ?? [] );
	
	$paid_total = (float) ( $settlement['paid_total'] ?? 0 );
	$remaining  = (float) ( $settlement['remaining'] ?? max( 0, $invoice_total - $paid_total ) );
	$overpaid   = (float) ( $settlement['overpaid'] ?? 0 );
	?>
    <section class="print-page">
        <div class="factor-header">
            <div class="factor-logo">
                <img src="<?php echo esc_url( $logo ); ?>" alt="">
            </div>

            <div class="factor-title">
                فاکتور خرید از تامین‌کننده
            </div>

            <div class="factor-meta">
                <div>شماره: <?php echo esc_html( $invoice['invoice_no'] ?: $invoice_id ); ?></div>
                <div>تاریخ فاکتور: <?php echo esc_html( kph_print_date( $invoice['issued_at'] ?? '' ) ); ?></div>
                <div>وضعیت: <?php echo esc_html( $status_label ?: '-' ); ?></div>
            </div>
        </div>

        <div class="supplier-box">
            <span class="side-label">تامین‌کننده</span>
            <div class="supplier-grid">
                <div>نام: <?php echo esc_html( $supplier ); ?></div>
                <div>شناسه: <?php echo esc_html( $supplier_id ?: '-' ); ?></div>
                <div>تاریخ چاپ: <?php echo esc_html( date_i18n( 'Y/m/d' ) ); ?></div>
            </div>
        </div>

        <table class="factor-table">
            <thead>
            <tr>
                <th style="width: 35px;">ردیف</th>
                <th>شرح کالا / ماده اولیه</th>
                <th style="width: 90px;">تعداد / وزن</th>
                <th style="width: 120px;">قیمت واحد</th>
                <th style="width: 130px;">قیمت کل ریال</th>
            </tr>
            </thead>
            <tbody>
			<?php
			$row = 1;
			foreach ( $items as $item ) {
				$qty          = (float) ( $item['qty_weight'] ?? 0 );
				$unit_price   = (float) ( $item['unit_price'] ?? 0 );
				$line_total   = (float) ( $item['line_total'] ?? 0 );
				$product_code = trim( (string) ( $item['raw_product_code'] ?? '' ) );
				$product_name = trim( (string) ( $item['raw_product_title'] ?? '' ) );
				$item_note    = trim( (string) ( $item['note'] ?? '' ) );
				
				if ( ! $product_name ) {
					$product_name = $product_code ?: 'آیتم #' . (int) ( $item['id'] ?? 0 );
				}
				?>
                <tr>
                    <td><?php echo esc_html( $row ); ?></td>
                    <td class="desc">
						<?php echo esc_html( $product_name ); ?>
						<?php if ( $product_code ) { ?>
                            <span class="muted">کد: <?php echo esc_html( $product_code ); ?></span>
						<?php } ?>
						<?php if ( $item_note ) { ?>
                            <span class="muted">توضیح: <?php echo esc_html( $item_note ); ?></span>
						<?php } ?>
                    </td>
                    <td><?php echo esc_html( $format_qty( $qty ) ); ?></td>
                    <td><?php echo esc_html( kph_print_money( $unit_price ) ); ?></td>
                    <td><?php echo esc_html( kph_print_money( $line_total ) ); ?></td>
                </tr>
				<?php
				$row ++;
			}
			?>

            <tr class="summary-row">
                <td colspan="2">جمع فاکتور</td>
                <td><?php echo esc_html( $format_qty( $total_qty ) ); ?></td>
                <td></td>
                <td><?php echo esc_html( kph_print_money( $invoice_total ) ); ?></td>
            </tr>
            </tbody>
        </table>

        <table class="summary-table">
            <tr>
                <td></td>
                <td class="label">پرداخت شده :</td>
                <td class="amount"><?php echo esc_html( kph_print_money( $paid_total ) ); ?></td>
            </tr>
            <tr>
                <td></td>
                <td class="label">باقیمانده :</td>
                <td class="amount"><?php echo esc_html( kph_print_money( $remaining ) ); ?></td>
            </tr>
			<?php if ( $overpaid > 0 ) { ?>
                <tr>
                    <td></td>
                    <td class="label">مازاد پرداخت :</td>
                    <td class="amount"><?php echo esc_html( kph_print_money( $overpaid ) ); ?></td>
                </tr>
			<?php } ?>
        </table>

        <div class="payable-box">
            <div class="payable-text">
                مانده قابل پرداخت:
				<?php echo esc_html( $amount_words( $remaining ) ); ?>
            </div>
            <div class="payable-amount">
				<?php echo esc_html( kph_print_money( $remaining ) ); ?>
            </div>
        </div>
		
		<?php if ( ! empty( $invoice['note'] ) ) { ?>
            <div class="note-box" style="margin-top: 8px;">
                <span class="side-label">توضیحات</span>
				<?php echo esc_html( $invoice['note'] ); ?>
            </div>
		<?php } ?>

        <div class="signatures">
            <div>امضا خریدار</div>
            <div>امضا تامین‌کننده</div>
        </div>
    </section>
<?php } ?>
</body>
</html>
