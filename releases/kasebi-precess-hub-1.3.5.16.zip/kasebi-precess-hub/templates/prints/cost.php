<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * @var array $date
 * @var array $request
 */

$DB      = new kph_db();
$request = isset( $request ) && is_array( $request ) ? $request : [];
$date    = isset( $date ) && is_array( $date ) ? $date : [];
$section = sanitize_key( $request['section'] ?? 'categories' );

if ( ! in_array( $section, [ 'categories', 'detail' ], TRUE ) ) {
	wp_die( 'بخش گزارش هزینه برای پرینت معتبر نیست.' );
}

$date_from_j = sanitize_text_field( wp_unslash( $date['from'] ?? '' ) );
$date_to_j   = sanitize_text_field( wp_unslash( $date['to'] ?? '' ) );
$date_from   = $date_from_j ? nooshika_jalali_to_gregorian( $date_from_j ) : '';
$date_to     = $date_to_j ? nooshika_jalali_to_gregorian( $date_to_j ) : '';

$cost           = sanitize_text_field( wp_unslash( $request['cost'] ?? '' ) );
$secondary_cost = sanitize_text_field( wp_unslash( $request['secondary_cost'] ?? '' ) );
$account_id     = absint( $request['account_id'] ?? 0 );
$search         = sanitize_text_field( wp_unslash( $request['search'] ?? '' ) );

$cost_types = get_option( 'kph_cost_category', [] );
$cost_types = is_array( $cost_types ) ? $cost_types : [];

$secondary_cost_types = get_option( 'kph_cost_secondary_category', [] );
$secondary_cost_types = is_array( $secondary_cost_types ) ? $secondary_cost_types : [];

if ( ! function_exists( 'kph_print_cost_label' ) ) {
	function kph_print_cost_label( string $key, array $cost_types ): string {
		if ( $key === 'uncategorized' ) {
			return 'بدون دسته‌بندی';
		}

		return $cost_types[ $key ]['label'] ?? ( $key ?: '-' );
	}
}

if ( ! function_exists( 'kph_print_cost_secondary_label' ) ) {
	function kph_print_cost_secondary_label( string $cost_key, array $cost_types, array $secondary_cost_types ): string {
		$secondary_key = $cost_types[ $cost_key ]['secondary_category'] ?? '';

		return $secondary_key !== ''
			? ( $secondary_cost_types[ $secondary_key ]['label'] ?? $secondary_key )
			: 'بدون دسته‌بندی ثانویه';
	}
}

if ( ! function_exists( 'kph_print_cost_date' ) ) {
	function kph_print_cost_date( $value ): string {
		return empty( $value ) ? '-' : date_i18n( 'Y/m/d', strtotime( $value ) );
	}
}

$filtered_cost_types = NULL;
if ( $secondary_cost !== '' ) {
	$filtered_cost_types = [];
	foreach ( $cost_types as $key => $item ) {
		if ( ( $item['secondary_category'] ?? '' ) === $secondary_cost ) {
			$filtered_cost_types[] = $key;
		}
	}
}

$common_args = [
	'date_from'  => $date_from,
	'date_to'    => $date_to,
	'account_id' => $account_id,
	'search'     => $search,
	'cost_types' => $filtered_cost_types,
];

$rows = [];
if ( $section === 'detail' ) {
	$total_amount      = 0;
	$detail_categories = [];
	$page              = 1;

	// The report API caps each page at 200 rows. Print all matching pages and
	// calculate the summary from those same rows, including the cost filter.
	do {
		$report = $DB->get_cost_transactions_report( array_merge( $common_args, [
			'cost_type' => $cost,
			'page'      => $page,
			'per_page'  => 200,
		] ) );

		foreach ( $report['items'] as $item ) {
			$total_amount += (float) $item['amount'];
			$detail_categories[ $item['cost_type'] ] = TRUE;
			$rows[] = [
				kph_print_cost_date( $item['created_at'] ),
				kph_print_cost_label( $item['cost_type'], $cost_types ),
				kph_print_cost_secondary_label( $item['cost_type'], $cost_types, $secondary_cost_types ),
				$item['account_title'] ?: '-',
				$item['destination'] ?: '-',
				number_format( $item['amount'] ),
				wp_strip_all_tags( $item['description'] ?: '-' ),
			];
		}

		$page ++;
	} while ( ! empty( $report['items'] ) && $page <= (int) $report['pagination']['total_page'] );

	$total_count  = count( $rows );
	$summary_data = [
		'total_amount'        => $total_amount,
		'total_count'         => $total_count,
		'total_categories'    => count( $detail_categories ),
		'avg_per_transaction' => $total_count > 0 ? $total_amount / $total_count : 0,
	];

	$report_title = 'ریز گزارش هزینه‌ها';
	$table_title  = $cost ? 'ریز هزینه‌ها - ' . kph_print_cost_label( $cost, $cost_types ) : 'ریز هزینه‌ها';
	$headers      = [ 'تاریخ', 'دسته‌بندی', 'دسته‌بندی ثانویه', 'حساب', 'مقصد / بابت', 'مبلغ (ریال)', 'توضیحات' ];
} else {
	$category_report = $DB->get_cost_categories_report( $common_args );
	$summary_data    = $category_report['summary'];

	foreach ( $category_report['items'] as $item ) {
		$cost_key = $item['cost_type'];
		$rows[]   = [
			kph_print_cost_label( $cost_key, $cost_types ),
			kph_print_cost_secondary_label( $cost_key, $cost_types, $secondary_cost_types ),
			number_format( $item['transaction_count'] ),
			number_format( $item['total_amount'] ),
			number_format( $item['avg_amount'] ),
			$item['percent'] . '٪',
			kph_print_cost_date( $item['last_transaction_at'] ),
		];
	}

	$report_title = 'گزارش هزینه‌ها';
	$table_title  = 'مصرف هزینه بر اساس دسته‌بندی';
	$headers      = [ 'دسته‌بندی', 'دسته‌بندی ثانویه', 'تعداد تراکنش', 'مبلغ هزینه (ریال)', 'میانگین (ریال)', 'سهم از کل', 'آخرین ثبت' ];
}

$summary = [
	'جمع هزینه‌ها'     => number_format( $summary_data['total_amount'] ) . ' ریال',
	'تعداد تراکنش'     => number_format( $summary_data['total_count'] ),
	'تعداد دسته‌بندی'  => number_format( $summary_data['total_categories'] ),
	'میانگین هر هزینه' => number_format( $summary_data['avg_per_transaction'] ) . ' ریال',
];

$logo = get_option( 'kph_print_logo' ) ?: get_option( 'kph_panel_logo' );
if ( ! $logo ) {
	$logo = KPH_ASSETS_URL . 'image/kasebi_logo.png';
}

$range_label = 'همه تاریخ‌ها';
if ( $date_from_j || $date_to_j ) {
	$range_label = ( $date_from_j ?: 'ابتدا' ) . ' تا ' . ( $date_to_j ?: 'امروز' );
}

$filter_labels = [];
if ( $cost ) {
	$filter_labels[] = 'دسته‌بندی: ' . kph_print_cost_label( $cost, $cost_types );
}
if ( $secondary_cost ) {
	$filter_labels[] = 'دسته‌بندی ثانویه: ' . ( $secondary_cost_types[ $secondary_cost ]['label'] ?? $secondary_cost );
}
if ( $account_id ) {
	$accounts = $DB->get_accounts( [ 'per_page' => 100, 'status' => 'active' ] );
	foreach ( $accounts['items'] ?? [] as $account ) {
		if ( (int) $account['id'] === $account_id ) {
			$filter_labels[] = 'حساب: ' . $account['title'];
			break;
		}
	}
}
if ( $search ) {
	$filter_labels[] = 'جستجو: ' . $search;
}
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title><?php echo esc_html( $report_title ); ?></title>
    <link rel="stylesheet" href="/wp-content/plugins/nooshika-main/assets/css/nooshika-fonts.css?ver=5.4.0">
    <style>
        @page { size: A4 landscape; margin: 9mm; }
        * { box-sizing: border-box; }
        body { margin: 0; direction: rtl; color: #111827; background: #fff; font-size: 11px; line-height: 1.7; }
        .print-actions { position: fixed; top: 12px; left: 12px; z-index: 10; }
        .print-actions button { border: 0; border-radius: 7px; padding: 8px 16px; color: #fff; background: #111827; cursor: pointer; font-family: inherit; }
        .header { display: grid; grid-template-columns: 120px 1fr 240px; gap: 16px; align-items: center; padding-bottom: 10px; border-bottom: 2px solid #111827; margin-bottom: 12px; }
        .logo img { max-width: 105px; max-height: 68px; object-fit: contain; }
        h1 { margin: 0; text-align: center; font-size: 19px; }
        .meta { font-size: 11px; }
        .filters { margin-top: 3px; color: #4b5563; }
        .summary { display: grid; grid-template-columns: repeat(4, 1fr); gap: 7px; margin: 10px 0 14px; }
        .card { border: 1px solid #9ca3af; border-radius: 6px; padding: 7px; text-align: center; }
        .card span { display: block; color: #6b7280; font-size: 10px; }
        .card strong { display: block; margin-top: 2px; font-size: 13px; }
        .report-section { margin: 0 0 16px; }
        .report-section h2 { margin: 0 0 6px; font-size: 14px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #6b7280; padding: 6px 5px; text-align: center; vertical-align: middle; }
        th { background: #eef2f7; font-weight: 700; }
        @media print {
            .print-actions { display: none; }
            body { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
            thead { display: table-header-group; }
        }
    </style>
</head>
<body>
<div class="print-actions"><button onclick="window.print()">پرینت</button></div>
<main>
    <header class="header">
        <div class="logo"><img src="<?php echo esc_url( $logo ); ?>" alt=""></div>
        <h1><?php echo esc_html( $report_title ); ?></h1>
        <div class="meta">
            <div><strong>تاریخ چاپ:</strong> <?php echo esc_html( date_i18n( 'Y/m/d H:i' ) ); ?></div>
            <div><strong>بازه گزارش:</strong> <?php echo esc_html( $range_label ); ?></div>
			<?php if ( $filter_labels ) { ?>
                <div class="filters"><?php echo esc_html( implode( ' | ', $filter_labels ) ); ?></div>
			<?php } ?>
        </div>
    </header>

    <div class="summary">
		<?php foreach ( $summary as $label => $value ) { ?>
            <div class="card"><span><?php echo esc_html( $label ); ?></span><strong><?php echo esc_html( $value ); ?></strong></div>
		<?php } ?>
    </div>

    <section class="report-section">
        <h2><?php echo esc_html( $table_title ); ?></h2>
        <table>
            <thead><tr><?php foreach ( $headers as $header ) { ?><th><?php echo esc_html( $header ); ?></th><?php } ?></tr></thead>
            <tbody>
			<?php if ( empty( $rows ) ) { ?>
                <tr><td colspan="<?php echo count( $headers ); ?>">گزارشی یافت نشد.</td></tr>
			<?php } else { foreach ( $rows as $row ) { ?>
                <tr><?php foreach ( $row as $value ) { ?><td><?php echo esc_html( $value ); ?></td><?php } ?></tr>
			<?php } } ?>
            </tbody>
        </table>
    </section>
</main>
</body>
</html>
