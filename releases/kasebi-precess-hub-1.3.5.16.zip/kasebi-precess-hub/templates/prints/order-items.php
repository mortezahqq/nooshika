<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$order_id = count( $ids ?? [] ) === 1 ? absint( $ids[0] ) : 0;
$nonce = $request['_wpnonce'] ?? '';
if ( ! is_user_logged_in() || ! $order_id || ! is_string( $nonce ) ||
     ! wp_verify_nonce( $nonce, 'kph_print_order_items_' . $order_id ) ) {
    wp_die( 'برای چاپ اقلام، از گزینه پرینت در لیست سفارشات استفاده کنید.', '', [ 'response' => 403 ] );
}
$DB = new kph_db();
$order = $DB->get_order_data( $order_id );
if ( ! $order ) {
    wp_die( 'سفارش یافت نشد.', '', [ 'response' => 404 ] );
}
$items = $order['items'] ?? [];
$statuses = $DB->get_order_statuses();
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>پرینت اقلام سفارش <?php echo esc_html( $order_id ); ?></title>
    <style>
        @page { size: A4 landscape; margin: 12mm; }
        body { font-family: Tahoma, sans-serif; color: #172033; margin: 24px; line-height: 1.8; }
        h1 { font-size: 22px; } .controls { background: #f2f3f8; padding: 16px; margin-bottom: 20px; }
        button { font: inherit; cursor: pointer; background: #6546c7; color: white; border: 0; border-radius: 6px; padding: 8px 16px; }
        button:disabled { opacity: .5; cursor: default; } input { width: 18px; height: 18px; vertical-align: middle; }
        .table-wrap { overflow-x: auto; } table { width: 100%; border-collapse: collapse; }
        th, td { padding: 8px; border: 1px solid #ccc; text-align: right; }
        th { background: #f2f3f8; } .excluded { opacity: .45; } .meta { margin-bottom: 20px; }
        @media print {
            .controls, .select-col, .excluded { display: none !important; }
            body { margin: 0; color: #000; } .table-wrap { overflow: visible; }
            thead { display: table-header-group; } tr { break-inside: avoid; }
        }
    </style>
</head>
<body>
    <div class="controls">
        <p>اقلام موردنظر را انتخاب کنید، سپس دکمه پرینت را بزنید.</p>
        <label><input type="checkbox" id="select-all" checked> انتخاب همه</label>
        <button type="button" id="print-button">پرینت / ذخیره PDF</button>
        <span id="selection-count" role="status"></span>
    </div>
    <h1>اقلام سفارش مشتری</h1>
    <div class="meta">
        <strong>مشتری: <?php echo esc_html( kph_print_user_name( (int) $order['customer_id'] ) ); ?></strong><br>
        شماره سفارش: <?php echo esc_html( $order_id ); ?> |
        تاریخ: <?php echo esc_html( kph_print_date( $order['created_at'] ) ); ?> |
        وضعیت: <?php echo esc_html( $statuses[ $order['display_status'] ?? $order['status'] ]['label'] ?? ( $order['display_status'] ?? $order['status'] ) ); ?>
    </div>
    <div class="table-wrap"><table>
        <thead><tr>
            <th class="select-col">انتخاب</th><th>محصول</th><th>کد کالا</th><th>قیمت پایه (ریال)</th>
            <th>تعداد سفارش</th><th>هدیه</th><th>تخفیف (%)</th><th>ارسال‌شده (با هدیه)</th><th>مبلغ (ریال)</th>
        </tr></thead>
        <tbody>
        <?php foreach ( $items as $item ) : ?>
            <tr data-order-item data-amount="<?php echo esc_attr( (float) $item['final_amount'] ); ?>">
                <td class="select-col"><input class="item-select" type="checkbox" checked aria-label="<?php echo esc_attr( 'انتخاب ' . get_the_title( (int) $item['wc_product_id'] ) ); ?>"></td>
                <td><?php echo esc_html( get_the_title( (int) $item['wc_product_id'] ) ); ?></td>
                <td><?php echo esc_html( $item['unique_product_code'] ?: '—' ); ?></td>
                <td><?php echo esc_html( number_format( (float) $item['base_price'] ) ); ?></td>
                <td><?php echo esc_html( number_format( (int) $item['qty_ordered'] ) ); ?></td>
                <td><?php echo esc_html( number_format( (int) $item['expected_free_qty'] ) ); ?></td>
                <td><?php echo esc_html( round( (float) $item['discount_cash_value'], 2 ) ); ?></td>
                <td><?php echo esc_html( number_format( (int) $item['shipped_paid_qty'] + (int) $item['shipped_free_qty'] ) ); ?></td>
                <td><?php echo esc_html( number_format( (float) $item['final_amount'] ) ); ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table></div>
    <?php if ( ! $items ) : ?><p>این سفارش هیچ قلمی ندارد.</p><?php endif; ?>
    <p>جمع مبلغ اقلام انتخاب‌شده (ریال): <strong id="selected-total"></strong></p>
    <noscript>برای انتخاب اقلام و چاپ، جاوااسکریپت مرورگر را فعال کنید.</noscript>
    <script>
    (() => {
        const rows = Array.from(document.querySelectorAll('[data-order-item]'));
        const all = document.getElementById('select-all');
        const print = document.getElementById('print-button');
        const format = new Intl.NumberFormat('fa-IR', { maximumFractionDigits: 0 });
        function update() {
            let count = 0, total = 0;
            rows.forEach(row => {
                const checked = row.querySelector('.item-select').checked;
                row.classList.toggle('excluded', !checked);
                if (checked) { count++; total += Number(row.dataset.amount); }
            });
            all.checked = rows.length > 0 && count === rows.length;
            all.indeterminate = count > 0 && count < rows.length;
            all.disabled = rows.length === 0;
            print.disabled = count === 0;
            document.getElementById('selection-count').textContent = format.format(count) + ' قلم انتخاب شده';
            document.getElementById('selected-total').textContent = format.format(total);
        }
        rows.forEach(row => row.querySelector('.item-select').addEventListener('change', update));
        all.addEventListener('change', () => {
            rows.forEach(row => { row.querySelector('.item-select').checked = all.checked; });
            update();
        });
        print.addEventListener('click', () => { if (!print.disabled) window.print(); });
        window.addEventListener('beforeprint', update);
        update();
    })();
    </script>
</body>
</html>
