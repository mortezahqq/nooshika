<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * templates/prints/financial.php
 *
 * پرینت لیست آیتم‌های حسابداری تامین‌کننده/کاربر
 *
 * آدرس نمونه:
 * /crm?action=print&type=financial&user_id=12
 * /crm?action=print&type=financial&user_id=12&date=1405/04/01...1405/04/31
 * /crm?action=print&type=financial&ids=1,2,3
 *
 * @var array $ids
 * @var int   $user_id
 * @var array $date
 * @var array $request
 */

global $wpdb;

$DB = new kph_db();

$ids     = isset( $ids ) && is_array( $ids ) ? array_values( array_unique( array_filter( array_map( 'absint', $ids ) ) ) ) : [];
$user_id = isset( $user_id ) ? absint( $user_id ) : 0;
$request = isset( $request ) && is_array( $request ) ? $request : [];
$date    = isset( $date ) && is_array( $date ) ? $date : [];

$entry_types = $DB->get_ledger_entry_types();
$sides       = $DB->get_ledger_sides();

if ( ! function_exists( 'kph_print_financial_clean_text' ) ) {
	function kph_print_financial_clean_text( $value ): string {
		$value = is_scalar( $value ) ? (string) $value : '';
		$value = function_exists( 'nooshika_sanitize_numbers' ) ? nooshika_sanitize_numbers( $value ) : $value;
		
		return trim( sanitize_text_field( wp_unslash( $value ) ) );
	}
}

if ( ! function_exists( 'kph_print_financial_normalize_date' ) ) {
	function kph_print_financial_normalize_date( $value, bool $end_of_day = FALSE ): string {
		$value = kph_print_financial_clean_text( $value );
		
		if ( $value === '' ) {
			return '';
		}
		
		$value = str_replace( '/', '-', $value );
		
		if ( preg_match( '/^(13|14)\d{2}-\d{1,2}-\d{1,2}/', $value ) && function_exists( 'nooshika_jalali_to_gregorian' ) ) {
			$value = nooshika_jalali_to_gregorian( $value );
		}
		
		$timestamp = strtotime( $value );
		
		if ( ! $timestamp ) {
			return '';
		}
		
		return date( 'Y-m-d', $timestamp ) . ( $end_of_day ? ' 23:59:59' : ' 00:00:00' );
	}
}

if ( ! function_exists( 'kph_print_financial_label' ) ) {
	function kph_print_financial_label( string $key, array $list ): string {
		return $list[ $key ]['label'] ?? ( $key ?: '-' );
	}
}

if ( ! function_exists( 'kph_print_financial_badge_class' ) ) {
	function kph_print_financial_badge_class( string $key, array $list ): string {
		return $list[ $key ]['class'] ?? 'bg-secondary';
	}
}

if ( ! function_exists( 'kph_print_financial_side_class' ) ) {
	function kph_print_financial_side_class( string $side ): string {
		return $side === 'credit' ? 'text-success' : 'text-danger';
	}
}

if ( ! function_exists( 'kph_print_financial_balance_class' ) ) {
	function kph_print_financial_balance_class( float $balance ): string {
		if ( $balance < 0 ) {
			return 'text-success';
		}
		
		if ( $balance > 0 ) {
			return 'text-danger';
		}
		
		return '';
	}
}

if ( ! function_exists( 'kph_print_financial_balance_label' ) ) {
	function kph_print_financial_balance_label( float $balance ): string {
		if ( $balance < 0 ) {
			return 'بستانکار';
		}
		
		if ( $balance > 0 ) {
			return 'بدهکار';
		}
		
		return 'تسویه';
	}
}

if ( ! function_exists( 'kph_print_financial_money' ) ) {
	function kph_print_financial_money( $amount ): string {
		if ( function_exists( 'kph_print_money' ) ) {
			return kph_print_money( $amount );
		}
		
		return number_format( (float) $amount );
	}
}

if ( ! function_exists( 'kph_print_financial_date' ) ) {
	function kph_print_financial_date( $value ): string {
		if ( function_exists( 'kph_print_date' ) ) {
			return kph_print_date( $value );
		}
		
		$timestamp = strtotime( (string) $value );
		
		return $timestamp ? date_i18n( 'Y/m/d', $timestamp ) : '-';
	}
}
if ( ! function_exists( 'kph_print_financial_actor_name' ) ) {
	function kph_print_financial_actor_name( array $entry, kph_db $DB, wpdb $wpdb ): string {
		$actor_id       = 0;
		$entry_id       = absint( $entry['id'] ?? 0 );
		$ref_id         = absint( $entry['ref_id'] ?? 0 );
		$ref_type       = (string) ( $entry['ref_type'] ?? '' );
		$entry_type_key = (string) ( $entry['entry_type'] ?? '' );
		
		if ( $ref_type === 'fulfillment' ) {
			$actor_id = (int) $DB->get_ledger_entry_meta( $entry_id, 'creator_id' );
		}
		if ( $ref_type === 'transfer' && $ref_id ) {
			$actor_id = (int) $DB->get_transfer_meta( $ref_id, 'creator_id' );
		}
		
		if ( ! $actor_id && $ref_type === 'payment' && $ref_id ) {
			$actor_id = (int) $DB->get_payment_meta( $ref_id, 'creator_id' );
		}
		
		if ( ! $actor_id && $ref_type === 'cheque' && $ref_id ) {
			$move_id = $entry_id ? (int) $DB->get_ledger_entry_meta( $entry_id, 'move_id' ) : 0;
			
			if ( $move_id ) {
				$actor_id = (int) $wpdb->get_var(
					$wpdb->prepare(
						"SELECT actor_user_id
						 FROM {$wpdb->prefix}kph_cheque_moves
						 WHERE id = %d
						 LIMIT 1",
						$move_id
					)
				);
			}
			
			if ( ! $actor_id ) {
				$action = '';
				
				if ( str_starts_with( $entry_type_key, 'cheque_' ) ) {
					$action = substr( $entry_type_key, 7 );
				}
				
				$allowed_actions = [ 'receive', 'endorse', 'return', 'clear', 'bounce', 'cancel', 'note' ];
				
				if ( in_array( $action, $allowed_actions, TRUE ) ) {
					$actor_id = (int) $wpdb->get_var(
						$wpdb->prepare(
							"SELECT actor_user_id
							 FROM {$wpdb->prefix}kph_cheque_moves
							 WHERE cheque_id = %d
							   AND action = %s
							 ORDER BY created_at DESC, id DESC
							 LIMIT 1",
							$ref_id,
							$action
						)
					);
				} else {
					$actor_id = (int) $wpdb->get_var(
						$wpdb->prepare(
							"SELECT actor_user_id
							 FROM {$wpdb->prefix}kph_cheque_moves
							 WHERE cheque_id = %d
							 ORDER BY created_at DESC, id DESC
							 LIMIT 1",
							$ref_id
						)
					);
				}
			}
		}
		
		if ( ! $actor_id ) {
			return '-';
		}
		
		if ( function_exists( 'kph_print_user_name' ) ) {
			return kph_print_user_name( $actor_id );
		}
		
		if ( function_exists( 'get_user_name_by_id' ) ) {
			return get_user_name_by_id( $actor_id );
		}
		
		$user = get_userdata( $actor_id );
		
		return $user ? $user->display_name : '-';
	}
}
$date_from_raw = $date['from'] ?? ( $request['date_from'] ?? '' );
$date_to_raw   = $date['to'] ?? ( $request['date_to'] ?? '' );

$date_from = kph_print_financial_normalize_date( $date_from_raw, FALSE );
$date_to   = kph_print_financial_normalize_date( $date_to_raw, TRUE );

$entry_type = kph_print_financial_clean_text( $request['entry_type'] ?? '' );
$type       = kph_print_financial_clean_text( $request['ledger_type'] ?? ( $request['type_side'] ?? ( $request['side'] ?? '' ) ) );
$ref_type   = kph_print_financial_clean_text( $request['ref_type'] ?? '' );
$ref_id     = isset( $request['ref_id'] ) ? absint( $request['ref_id'] ) : 0;

$entries = [];
$totals  = [
	'sum_debit'  => 0,
	'sum_credit' => 0,
	'net'        => 0,
];

if ( ! empty( $ids ) ) {
	$ledger_table = $wpdb->prefix . 'kph_ledger_entries';
	$placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
	
	$entries = $wpdb->get_results(
		$wpdb->prepare(
			"SELECT *
			FROM {$ledger_table}
			WHERE id IN ({$placeholders})
			ORDER BY posted_at ASC, id ASC",
			$ids
		),
		ARRAY_A
	);
	
	$entries = is_array( $entries ) ? $entries : [];
	
	if ( ! $user_id && ! empty( $entries ) ) {
		$user_id = absint( $entries[0]['user_id'] ?? 0 );
	}
} else {
	if ( ! $user_id ) {
		wp_die( 'برای پرینت حسابداری باید شناسه کاربر یا شناسه آیتم‌ها مشخص شود.' );
	}
	
	$args = [
		'user_id'    => $user_id,
		'page'       => 1,
		'per_page'   => 5000,
		'orderby'    => 'posted_at',
		'order'      => 'ASC',
		'date_from'  => $date_from ?: NULL,
		'date_to'    => $date_to ?: NULL,
		'entry_type' => isset( $entry_types[ $entry_type ] ) ? $entry_type : NULL,
		'type'       => isset( $sides[ $type ] ) ? $type : NULL,
		'ref_type'   => $ref_type ?: NULL,
		'ref_id'     => $ref_id ?: NULL,
	];
	
	$res     = $DB->get_ledger_entries( $args );
	$entries = $res['items'] ?? [];
	$totals  = $res['totals'] ?? $totals;
}

if ( empty( $entries ) ) {
	wp_die( 'آیتم حسابداری برای پرینت یافت نشد.' );
}

if ( empty( $ids ) ) {
	$total_debit  = (float) ( $totals['sum_debit'] ?? 0 );
	$total_credit = (float) ( $totals['sum_credit'] ?? 0 );
	$net_balance  = (float) ( $totals['net'] ?? 0 );
} else {
	$total_debit  = 0.0;
	$total_credit = 0.0;
	$net_balance  = 0.0;
	
	foreach ( $entries as $entry ) {
		$amount = (float) ( $entry['amount'] ?? 0 );
		$side   = (string) ( $entry['type'] ?? '' );
		
		if ( $side === 'credit' ) {
			$total_credit += $amount;
			$net_balance  -= $amount;
		} else {
			$total_debit += $amount;
			$net_balance += $amount;
		}
	}
}

$logo = get_option( 'kph_print_logo' );

if ( ! $logo ) {
	$logo = get_option( 'kph_panel_logo' );
}

if ( ! $logo ) {
	$logo = defined( 'KPH_ASSETS_URL' ) ? KPH_ASSETS_URL . 'image/kasebi_logo.png' : '';
}

$site_title = get_option( 'kph_site_title' ) ?: get_bloginfo( 'name' );
$user_title = $user_id && function_exists( 'kph_print_user_name' ) ? kph_print_user_name( $user_id ) : 'نامشخص';

$range_label = 'همه تاریخ‌ها';

if ( $date_from_raw || $date_to_raw ) {
	$range_label = trim( ( $date_from_raw ?: 'ابتدا' ) . ' تا ' . ( $date_to_raw ?: 'امروز' ) );
}

$filter_labels = [];

if ( isset( $entry_types[ $entry_type ] ) ) {
	$filter_labels[] = 'نوع تراکنش: ' . $entry_types[ $entry_type ]['label'];
}

if ( isset( $sides[ $type ] ) ) {
	$filter_labels[] = 'ماهیت: ' . $sides[ $type ]['label'];
}

if ( $ref_type ) {
	$filter_labels[] = 'نوع مرجع: ' . $ref_type;
}

if ( $ref_id ) {
	$filter_labels[] = 'شناسه مرجع: ' . $ref_id;
}

$filter_label = empty( $filter_labels ) ? 'بدون فیلتر تکمیلی' : implode( ' | ', $filter_labels );
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>پرینت حسابداری</title>
    <link rel="stylesheet" id="nooshika_fonts_css-css"
          href="/wp-content/plugins/nooshika-main/assets/css/nooshika-fonts.css?ver=5.4.0"
          media="all">
    <style>
        @page {
            size: A4 portrait;
            margin: 10mm;
        }
        
        * {
            box-sizing: border-box;
        }
        
        body {
            direction: rtl;
            margin: 2mm;
            background: #fff;
            color: #111;
            font-size: 12px;
            line-height: 1.8;
        }
        
        .print-actions {
            position: fixed;
            top: 12px;
            left: 12px;
            z-index: 99;
        }
        
        .print-actions button {
            border: 0;
            background: #111827;
            color: #fff;
            border-radius: 7px;
            padding: 8px 14px;
            cursor: pointer;
            font-family: inherit;
        }
        
        .print-page {
            width: 100%;
            min-height: 277mm;
        }
        
        .print-header {
            display: grid;
            grid-template-columns: 120px 1fr 190px;
            gap: 12px;
            align-items: start;
            margin-bottom: 8px;
        }
        
        .print-logo img {
            max-width: 100px;
            max-height: 70px;
            object-fit: contain;
        }
        
        .print-title {
            text-align: center;
            font-size: 17px;
            font-weight: 700;
            padding-top: 8px;
        }
        
        .print-meta {
            text-align: right;
            font-size: 12px;
            line-height: 2;
        }
        
        .info-box {
            border: 1px solid #222;
            border-radius: 7px;
            padding: 8px 10px;
            margin-bottom: 8px;
        }
        
        .info-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 6px 12px;
        }
        
        .label {
            font-weight: 700;
        }
        
        .summary-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 8px;
            margin: 8px 0;
        }
        
        .summary-card {
            border: 1px solid #222;
            border-radius: 7px;
            padding: 7px 8px;
        }
        
        .summary-card .title {
            font-size: 11px;
            font-weight: 700;
            color: #333;
        }
        
        .summary-card .value {
            margin-top: 3px;
            font-size: 13px;
            font-weight: 700;
            direction: ltr;
            text-align: left;
        }
        
        .section-title {
            margin: 12px 0 5px;
            font-size: 13px;
            font-weight: 700;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        th,
        td {
            border: 1px solid #222;
            padding: 4px 6px;
            vertical-align: middle;
        }
        
        th {
            background: #d9d9d9;
            font-weight: 700;
            text-align: center;
        }
        
        td {
            text-align: center;
        }
        
        .text-right {
            text-align: right;
        }
        
        .ltr {
            direction: ltr;
            text-align: left;
            unicode-bidi: plaintext;
        }
        
        .badge {
            display: inline-block;
            min-width: 70px;
            border-radius: 999px;
            padding: 1px 7px;
            color: #111;
            border: 1px solid #777;
            background: #f3f4f6;
            font-size: 11px;
            font-weight: 700;
        }
        
        .text-success {
            color: #0f7a35;
            font-weight: 700;
        }
        
        .text-danger {
            color: #b42318;
            font-weight: 700;
        }
        
        .signatures {
            display: grid;
            grid-template-columns: 1fr 1fr;
            margin-top: 28px;
            text-align: center;
            font-weight: 700;
        }
        
        @media print {
            .print-actions {
                display: none;
            }
            
            body {
                margin: 0;
            }
            
            * {
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
        }
    </style>
</head>
<body>
<div class="print-actions">
    <button onclick="window.print()">پرینت</button>
</div>

<section class="print-page">
    <div class="print-header">
        <div class="print-logo">
			<?php if ( $logo ) : ?>
                <img src="<?php echo esc_url( $logo ); ?>" alt="logo">
			<?php endif; ?>
        </div>

        <div class="print-title">
            <div><?php echo esc_html( $site_title ); ?></div>
            <div>گزارش حسابداری</div>
        </div>

        <div class="print-meta">
            <div><span class="label">تاریخ چاپ:</span> <?php echo esc_html( date_i18n( 'Y/m/d H:i' ) ); ?></div>
            <div><span class="label">شناسه کاربر:</span> <?php echo esc_html( $user_id ?: '-' ); ?></div>
            <div><span class="label">تعداد آیتم:</span> <?php echo esc_html( number_format( count( $entries ) ) ); ?>
            </div>
        </div>
    </div>

    <div class="info-box">
        <div class="info-grid">
            <div><span class="label">طرف حساب:</span> <?php echo esc_html( $user_title ); ?></div>
            <div><span class="label">بازه:</span> <?php echo esc_html( $range_label ); ?></div>
            <div><span class="label">فیلتر:</span> <?php echo esc_html( $filter_label ); ?></div>
            <div><span class="label">نوع چاپ:</span> <?php echo empty( $ids ) ? 'گزارش کامل' : 'آیتم‌های انتخاب‌شده'; ?>
            </div>
        </div>
    </div>

    <div class="summary-grid">
        <div class="summary-card">
            <div class="title">جمع بدهکار</div>
            <div class="value text-danger"><?php echo esc_html( kph_print_financial_money( $total_debit ) ); ?></div>
        </div>
        <div class="summary-card">
            <div class="title">جمع بستانکار</div>
            <div class="value text-success"><?php echo esc_html( kph_print_financial_money( $total_credit ) ); ?></div>
        </div>
        <div class="summary-card">
            <div class="title">مانده</div>
            <div class="value <?php echo esc_attr( kph_print_financial_balance_class( $net_balance ) ); ?>">
				<?php echo esc_html( kph_print_financial_money( abs( $net_balance ) ) ); ?>
            </div>
        </div>
        <div class="summary-card">
            <div class="title">وضعیت مانده</div>
            <div class="value" style="direction: rtl; text-align: right;">
				<?php echo esc_html( kph_print_financial_balance_label( $net_balance ) ); ?>
            </div>
        </div>
    </div>

    <div class="section-title">ریز آیتم‌های حسابداری</div>
    <table>
        <thead>
        <tr>
            <th style="width: 36px;">#</th>
            <th style="width: 70px;">شناسه</th>
            <th style="width: 90px;">تاریخ</th>
            <th style="width: 140px;">نوع تراکنش</th>
            <th style="width: 85px;">ماهیت</th>
            <th style="width: 110px;">انجام‌دهنده</th>
            <th style="width: 120px;">بدهکار</th>
            <th style="width: 120px;">بستانکار</th>
            <th style="width: 120px;">مانده</th>
            <th>توضیحات</th>
        </tr>
        </thead>
        <tbody>
		<?php
		$running_balance     = 0.0;
		foreach ( $entries as $index => $entry ) :
			$amount = (float) ( $entry['amount'] ?? 0 );
			$side            = (string) ( $entry['type'] ?? '' );
			$entry_type_key  = $DB->get_ledger_entry_display_type( $entry );
			$entry_type_name = kph_print_financial_label( $entry_type_key, $entry_types );
			$side_name       = kph_print_financial_label( $side, $sides );
			$running_balance += $side === 'credit' ? - $amount : $amount;
			$actor_name      = kph_print_financial_actor_name( $entry, $DB, $wpdb );
			?>
            <tr>
                <td><?php echo esc_html( $index + 1 ); ?></td>
                <td><?php echo esc_html( $entry['id'] ?? '-' ); ?></td>
                <td><?php echo esc_html( kph_print_financial_date( $entry['posted_at'] ?? $entry['created_at'] ?? '' ) ); ?></td>
                <td>
                    <span
                        class="badge <?php echo esc_attr( kph_print_financial_badge_class( $entry_type_key, $entry_types ) ); ?>">
                        <?php echo esc_html( $entry_type_name ); ?>
                    </span>
                </td>
                <td class="<?php echo esc_attr( kph_print_financial_side_class( $side ) ); ?>">
					<?php echo esc_html( $side_name ); ?>
                </td>
                <td><?php echo esc_html( $actor_name ); ?></td>
                <td class="ltr text-danger">
					<?php echo $side === 'debit' ? esc_html( kph_print_financial_money( $amount ) ) : '-'; ?>
                </td>
                <td class="ltr text-success">
					<?php echo $side === 'credit' ? esc_html( kph_print_financial_money( $amount ) ) : '-'; ?>
                </td>
                <td class="ltr <?php echo esc_attr( kph_print_financial_balance_class( $running_balance ) ); ?>">
					<?php echo esc_html( kph_print_financial_money( abs( $running_balance ) ) ); ?>
                </td>
                <td class="text-right"><?php echo wp_kses_post( $entry['note'] ?? '-' ); ?></td>
            </tr>
		<?php endforeach; ?>
        </tbody>
        <tfoot>
        <tr>
            <th colspan="6">جمع</th>
            <th class="ltr text-danger"><?php echo esc_html( kph_print_financial_money( $total_debit ) ); ?></th>
            <th class="ltr text-success"><?php echo esc_html( kph_print_financial_money( $total_credit ) ); ?></th>
            <th class="ltr <?php echo esc_attr( kph_print_financial_balance_class( $net_balance ) ); ?>">
				<?php echo esc_html( kph_print_financial_money( abs( $net_balance ) ) ); ?>
            </th>
            <th><?php echo esc_html( kph_print_financial_balance_label( $net_balance ) ); ?></th>
        </tr>
        </tfoot>
    </table>

    <div class="signatures">
        <div>امضای حسابداری</div>
        <div>امضای طرف حساب</div>
    </div>
</section>

</body>
</html>
