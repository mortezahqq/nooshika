<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * @var string $page
 */
$page         = $page ?: '';
$pages        = get_kph_pages_list();
$current      = get_kph_end_point( $page );
$current      = $current[0];
$single_pages = get_kph_single_page_list();
if ( isset( $single_pages[ $current ] ) ) {
	$current = $single_pages[ $current ]['parent'];
}
$role      = nooshika_get_user_role( get_current_user_id() );
$all_roles = kph_get_all_roles();
$logo      = get_option( 'kph_panel_logo' );
if ( ! $logo ) {
	$logo = KPH_ASSETS_URL . 'image/kasebi_logo.png';
}
?>
<div class="nk-sidebar-element nk-sidebar-head">
    <div class="nk-sidebar-brand">
        <a href="#" class="logo-link nk-sidebar-logo">
            <img src="<?php echo $logo; ?>" alt="logo" class="logo_kasebi logo-img">
        </a>
    </div>
    <div class="nk-menu-trigger me-n2">
        <a href="#" class="nk-nav-toggle nk-quick-nav-icon d-xl-none" data-target="sidebarMenu"><em
                class="icon ni ni-arrow-left"></em></a>
    </div>
</div>
<div class="nk-sidebar-element">
    <div class="nk-sidebar-content">
        <div class="nk-sidebar-menu" data-simplebar>
            <ul class="nk-menu">
				<?php
				foreach ( $pages as $key => $data ) {
					$data['valid_roles'] = $data['valid_roles'] ?? 'all';
					$valid_roles         = $data['valid_roles'] == 'all' ? $all_roles : $data['valid_roles'];
					if ( ! in_array( $role, $valid_roles ) ) {
						continue;
					}
					$active       = ( $key == $current ) ? ' active' : '';
					$data['icon'] = $data['icon'] ?? 'home';
					$icon         = "icon ni ni-{$data['icon']}";
					if ( $active == ' active' ) {
						$icon = "icon ni ni-{$data['icon']}-fill";
					}
					$title = apply_filters( 'kph_navbar_title', $data['title'], $key );
					$type  = $data['type'] ?? 'page';
					if ( $type == 'divider' ) {
						?>
                        <li class="nk-menu-heading">
                            <h6 class="overline-title text-primary-alt"><?php echo $title ?></h6>
                        </li>
						<?php
					} elseif ( $type == 'page' ) {
						?>
                        <li class="nk-menu-item<?php echo $active; ?>">
                            <a href="<?php echo home_url(); ?>/crm/<?php echo $key; ?>"
                               class="page_activator nk-menu-link"
                               data-url="/crm/<?php echo $key; ?>">
                                <span class="nk-menu-icon"><em class="<?php echo $icon ?>"></em></span>
                                <span class="nk-menu-text">
                                    <?php
                                    echo $title;
                                    do_action( 'kph_navbar_title_after', $key );
                                    ?>
                                </span>
                            </a>
                        </li>
						<?php
					} else {
						$sub_pages = $data['sub'];
						$is_open   = FALSE;
						ob_start();
						?>
                        <ul class="nk-menu-sub">
							<?php
							foreach ( $sub_pages as $sub_key => $sub_data ) {
								$sub_slug   = explode( '?', $sub_key, 2 );
								$base       = $sub_slug[0] ?? '';
								$sub_active = ( $base === $current ) ? ' active' : '';
								if ( isset( $sub_slug[1] ) && $sub_slug[1] !== '' && $sub_active ) {
									parse_str( $sub_slug[1], $q );
									$match = TRUE;
									foreach ( $q as $k => $v ) {
										$req = $_REQUEST[ $k ] ?? NULL;
										if ( is_array( $req ) ) {
											$match = FALSE;
											break;
										}
										if ( (string) $req !== (string) $v ) {
											$match = FALSE;
											break;
										}
									}
									$sub_active = $match ? ' active' : '';
								}
								$is_open = $is_open || $sub_active;
								
								$sub_title = apply_filters( 'kph_navbar_title', $sub_data['title'], $sub_key );
								
								$sub_data['valid_roles'] = $sub_data['valid_roles'] ?? 'all';
								$valid_roles             = $sub_data['valid_roles'] == 'all' ? $all_roles : $sub_data['valid_roles'];
								if ( ! in_array( $role, $valid_roles ) ) {
									continue;
								}
								$type = $sub_data['type'] ?? 'page';
								if ( $type == 'link' ) {
									?>
                                    <li class="nk-menu-item<?php echo $sub_active; ?>">
                                        <a href="<?php echo $sub_data['url']; ?>"
                                           class="nk-menu-link<?php echo $sub_active; ?>" target="_blank">
                                         <span class="nk-menu-text">
                                            <?php
                                            echo $sub_title;
                                            do_action( 'kph_navbar_title_after', $key );
                                            ?>
                                        </span>
                                        </a>
                                    </li>
									<?php
								} else {
									?>
                                    <li class="nk-menu-item<?php echo $sub_active; ?>">
                                        <a href="<?php echo home_url(); ?>/crm/<?php echo $sub_key; ?>"
                                           class="page_activator nk-menu-link<?php echo $sub_active; ?>"
                                           data-url="/crm/<?php echo $sub_key; ?>">
                                         <span class="nk-menu-text">
                                            <?php
                                            echo $sub_title;
                                            do_action( 'kph_navbar_title_after', $key );
                                            ?>
                                        </span>
                                        </a>
                                    </li>
									<?php
								}
							}
							?>
                        </ul>
						<?php
						$sub_list = ob_get_clean();
						$active   = $is_open ? ' active' : '';
						if ( $is_open ) {
							$icon = "icon ni ni-{$data['icon']}-fill";
						}
						?>
                        <li class="nk-menu-item<?php echo $active; ?>">
                            <a href="#" class="nk-menu-link nk-menu-toggle<?php echo $active; ?>">
                                <span class="nk-menu-icon"><em class="<?php echo $icon ?>"></em></span>
                                <span class="nk-menu-text">
                                    <?php
                                    echo $title;
                                    do_action( 'kph_navbar_title_after', $key );
                                    ?>
                                </span>
                            </a>
							<?php echo $sub_list; ?>
                        </li>
						<?php
					}
				}
				?>
            </ul>
        </div>
    </div>
</div>

