<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
/**
 * @var string $page
 */

$page      = $page ?: '';
$current   = get_kph_end_point( $page );
$current   = $current[0];
$folder    = 'pages';
$sub_pages = get_kph_single_page_list();
if ( isset( $sub_pages[ $current ] ) ) {
	$folder = 'sub_page';
}
?>
<input type="hidden" id="current_page" value="/crm/<?php echo $current; ?>">
<div class="nk-content nk-content-fluid">
    <div class="container-xl wide-xl">
        <div class="nk-content-body">
			<?php
			echo kph_get_template( "$folder/$current.php" );
			?>
        </div>
    </div>
</div>