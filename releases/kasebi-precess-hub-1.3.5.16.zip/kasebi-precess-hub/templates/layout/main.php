<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
/**
 * @var string $page
 */

$valid_roles = kph_get_all_roles();
$role        = nooshika_get_user_role( get_current_user_id() );
$page        = $page ?? '';
?>
<div class="nk-main">

    <div class="nk-sidebar nk-sidebar-fixed is-light" data-content="sidebarMenu">
		<?php echo kph_get_template( 'layout/navbar.php', [ 'page' => $page ] ); ?>
    </div>
    <div class="nk-wrap">
		<?php echo kph_get_template( 'layout/header.php' ); ?>
		<?php echo kph_get_template( 'layout/body.php', [ 'page' => $page ] ); ?>
		<?php echo kph_get_template( 'layout/footer.php' ); ?>
    </div>
</div>
