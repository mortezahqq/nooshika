<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>
<div class="card card-stretch">
    <div class="card-inner-group">
		<?php
		if ( ! empty( $users ) ) {
			?>
            <div class="card-inner p-0">
                <div class="is-compact nk-tb-list nk-tb-ulist">
					<?php
					foreach ( $users as $user ) {
						$user_id    = $user['user_id'];
						$user_badge = kph_get_user_badge_color( $user_id );
						?>
                        <div class="nk-tb-item" data-id="<?php echo $user_id; ?>">
                            <div class="nk-tb-col">
                                <div class="user-card">
                                    <div class="user-avatar xs <?php echo $user_badge; ?>">
                                        <span><?php echo kph_get_user_name_for_avatar( $user_id ); ?></span>
                                    </div>
                                    <div class="user-info">
                                        <span class="tb-lead"><?php echo get_user_name_by_id( $user_id ); ?></span>
                                    </div>
                                </div>
                            </div>
                            <div class="nk-tb-col tb-col-md">
                                <span><?php echo get_user_meta( $user_id, 'nooshika_phone_num', TRUE ); ?></span>
                            </div>
                            <div class="nk-tb-col nk-tb-col-tools">
                                <ul class="nk-tb-actions gx-2">
                                    <li class="nk-tb-action">
                                        <a href="<?php echo home_url(); ?>/crm/user/<?php echo $user_id; ?>"
                                           data-url="/crm/user/<?php echo $user_id; ?>"
                                           class="btn btn-sm btn-icon btn-trigger page_activator"
                                           data-bs-toggle="tooltip"
                                           target="_blank" title="مشاهده مشخصات"
                                           data-bs-placement="top">
                                            <em class="icon ni ni-eye"></em>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
						<?php
					}
					?>
                </div>
            </div>
			<?php
		} else {
			?>
            <div class="card-inner p-0">
                <div class="is-compact nk-tb-list nk-tb-ulist">
                    <div class="nk-tb-item">
                        <div class="nk-tb-col">
                            <h6 class="title">کاربر یافت نشد</h6>
                        </div>
                        <div class="nk-tb-col nk-tb-col-tools">
                            <ul class="nk-tb-actions gx-2">
                                <li class="nk-tb-action">
                                    <div class="btn btn-icon btn-sm" data-bs-toggle="tooltip"
                                         data-bs-placement="left" title="افزودن کاربر">
                                        <div data-bs-toggle="modal"
                                             data-bs-target="#addCustomer">
                                            <em class="icon ni ni-plus"></em>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
			<?php
		}
		?>
    </div>
</div>
