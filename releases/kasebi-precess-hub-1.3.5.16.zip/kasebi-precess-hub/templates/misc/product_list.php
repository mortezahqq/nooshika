<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * @var $items array
 */

?>
<div class="card card-stretch">
    <div class="card-inner-group">
		<?php
		if ( empty( $items ) ) {
			echo '<div class="alert alert-warning">محصولی پیدا نشد.</div>';
		} else {
			?>
            <div class="card-inner p-0">
                <div class="is-compact nk-tb-list nk-tb-ulist">
					<?php
					foreach ( $items as $product_data ) {
						extract( $product_data );
						?>
                        <div class="each_supp_product_search_row" data-code="<?php echo $code; ?>"
                             data-id="<?php echo $id; ?>"
                             data-title="<?php echo $title; ?>">
                            <div class="each_product_search_row product_title"><?= $title . ' - ' . $code; ?></div>
                        </div>
						<?php
					}
					?>
                </div>
            </div>
			<?php
		}
		?>
    </div>
</div>