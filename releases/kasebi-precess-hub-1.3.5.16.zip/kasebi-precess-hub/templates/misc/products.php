<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * @var $items array
 */
?>
<div class="card card-stretch">
    <div class="card-inner-group">
		<?php
		if ( empty( $items ) ) {
			echo '<div class="alert alert-warning">محصولی پیدا نشد.</div>';
		} else {
			?>
            <div class="card-inner p-0">
                <div class="is-compact nk-tb-list nk-tb-ulist">
					<?php
					foreach ( $items as $product_data ) {
						extract( $product_data );
						?>
                        <div class="each_customer_product_search_row" data-code="<?php echo $unique_product_code; ?>"
                             data-price="<?php echo $sale_price ?: round( $avg_unit_cost ); ?>"
                             data-id="<?php echo $wc_product_id; ?>"
                             data-title="<?php echo esc_attr($post_title); ?>"
                             data-wholesale-price="<?php echo esc_attr($wholesale_price ?? ''); ?>"
                             data-wholesale-min-qty="<?php echo esc_attr($wholesale_min_qty ?? ''); ?>">
                            <div class="product_title"><?php echo esc_html($post_title); ?>
                                <small class="sub-text d-block">خرده: <?php echo number_format((float)($sale_price ?? 0)); ?> ریال<?php if(!empty($wholesale_price) && !empty($wholesale_min_qty)): ?> | عمده از <?php echo (int)$wholesale_min_qty; ?> عدد: <?php echo number_format((float)$wholesale_price); ?> ریال<?php endif; ?></small>
                            </div>
                        </div>
						<?php
					}
					?>
                </div>
            </div>
			<?php
		}
		?>
    </div>
</div>