<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>
<div class="card card-stretch">
    <div class="card-inner-group">
		<?php
		if ( ! empty( $users ) ) {
			?>
            <div class="card-inner p-0 nk-tb-list">
				<?php
				foreach ( $users as $user ) {
					$user_id = $user['user_id'];
					$group   = get_user_meta( $user_id, 'kph_supplier_group', TRUE );
					
					?>
                    <div class="each_user_search_result_row" data-id="<?php echo $user_id; ?>"
                         data-group="<?php echo $group; ?>">
						<?php
						echo kph_get_template( 'components/user-card.php', [
							'user_id'    => $user_id,
							'show_phone' => TRUE,
						] );
						?>
                    </div>
					<?php
				}
				?>
            </div>
			<?php
		} else {
			?>
            <div class="card-inner p-0">
                <div class="is-compact nk-tb-list nk-tb-ulist">
                    <div class="nk-tb-item">
                        <div class="nk-tb-col">
                            <div class="title">کاربر یافت نشد</div>
                        </div>
                        <div class="nk-tb-col nk-tb-col-tools">
                            <ul class="nk-tb-actions gx-2">
                                <li class="nk-tb-action">
                                    <div class="btn btn-icon btn-sm" data-bs-toggle="tooltip"
                                         data-bs-placement="left" title="افزودن کاربر">
                                        <div data-bs-toggle="modal"
                                             data-bs-target="#addCustomer_for_modal">
                                            <em class="icon ni ni-plus"></em>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
			<?php
		}
		?>
    </div>
</div>
