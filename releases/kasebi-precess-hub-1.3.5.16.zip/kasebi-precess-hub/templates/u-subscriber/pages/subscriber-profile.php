<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * @var $user_id
 */
$DB         = new kph_db();
$user_metas = $DB->get_user_meta_list();
$user_metas = [
	              'first_name' => [
		              'label' => 'نام',
	              ],
	              'last_name'  => [
		              'label' => 'نام خانوادگی',
	              ],
              ] + $user_metas;

$user_state = get_user_meta( $user_id, 'state_id', TRUE );
if ( $user_state ) {
	$cities = PWS()::cities( $user_state );
} else {
	$cities = [ 0 => 'استان انتخاب نشده است.' ];
}
$user_metas['city_id']['options'] = $cities;
?>
<div class="nk-block nk-block-between">
    <div class="nk-block-head">
        <h6 class="title">اطلاعات شخصی</h6>
        <p>اطلاعات شخصی مشتری</p>
    </div>
</div>
<div class="nk-block">
    <div class="profile-ud-list">
		<?php
		foreach ( $user_metas as $key => $meta ) {
			if ( ! kph_meta_is_visible( $meta, $user_id ) ) {
				continue;
			}
			$label      = $meta['label'] ?? $key;
			$type       = $meta['type'] ?? 'text';
			$main_value = get_user_meta( $user_id, $key, TRUE );
			$value      = $main_value;
			if ( $type === 'select' && isset( $meta['options'][ $value ] ) ) {
				$value_data = $meta['options'][ $value ];
				$value      = is_array( $value_data ) ? $value_data['label'] : $value_data;
			}
			if ( $type === 'date' && ! empty( $value ) ) {
				$value = date_i18n( 'Y/m/d', strtotime( $value ) );
			}
			if ( empty( $value ) ) {
				$value = '-';
			}
			$style = ( ! empty( $meta['width'] ) ) ? ' style="width:' . esc_attr( $meta['width'] ) . ';"' : '';
			?>
            <div class="profile-ud-item" <?php echo $style; ?>>
                <div class="profile-ud wider">
                    <span class="profile-ud-label"><?php echo $label; ?></span>
                    <span class="profile-ud-value"><?php echo $value; ?></span>
                </div>
            </div>
			<?php
		}
		?>
    </div>
</div>
