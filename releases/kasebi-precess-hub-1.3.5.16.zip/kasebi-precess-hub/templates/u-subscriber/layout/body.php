<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
/**
 * @var string $page
 */

$page      = $page ?: '';
$current   = get_kph_end_point( $page );
$current   = $current[0];
$folder    = 'pages';
$sub_pages = get_kph_single_page_list();
if ( isset( $sub_pages[ $current ] ) ) {
	$folder = 'sub_page';
}
$user_id = get_current_user_id();
?>
<input type="hidden" id="current_page" value="/crm/<?php echo $current; ?>">
<div class="nk-content nk-content-fluid">
    <div class="container-xl wide-xl">
        <div class="nk-content-body">

            <input type="hidden" id="current_user_id" value="<?php echo $user_id; ?>">
            <div class="nk-block nk-block-lg">
                <div class="card">
                    <div class="card-inner">
						<?php
						echo kph_get_template( "$folder/$current.php", [ 'user_id' => $user_id ] );
						?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>