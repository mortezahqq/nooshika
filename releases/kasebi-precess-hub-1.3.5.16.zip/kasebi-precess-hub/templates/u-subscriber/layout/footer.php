<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
<div class="nk-footer">
    <div class="container-xl wide-xl">
        <div class="nk-footer-wrap">
            <div class="nk-footer-copyright">طراحی و توسعه توسط <a href="https://kasebi.co/" target="_blank">کاسبی</a>
            </div>
            <div class="nk-footer-links english_number">
                Copyright 2017-<?php echo date( "Y" ); ?>
            </div>
        </div>
    </div>
</div>
<div class="modal fade zoom" id="invoiceItemsTable">
    <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">آیتم های فاکتور</h5>
                <a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
            </div>
            <div class="bg-white modal-body">
            </div>
        </div>
    </div>
</div>
<div class="modal fade zoom" id="invoiceFulfillmentTable">
    <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">ارسال های سفارش</h5>
                <a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
            </div>
            <div class="bg-white modal-body">
            </div>
        </div>
    </div>
</div>
<div class="modal fade zoom" id="orderFinancialTable">
    <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">حسابداری سفارش</h5>
                <a href="#" class="close" data-bs-dismiss="modal"><em class="icon ni ni-cross-sm"></em></a>
            </div>
            <div class="bg-white modal-body">
            </div>
        </div>
    </div>
</div>

