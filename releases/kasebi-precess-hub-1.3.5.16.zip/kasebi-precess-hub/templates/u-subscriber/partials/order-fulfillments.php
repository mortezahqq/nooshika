<?php
/**
 * @var int     $order_id
 * @var \kph_db $DB
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

global $wpdb;

$order_id = absint( $order_id );
$entries  = [];

if ( $order_id > 0 ) {
	$fulfillments_table      = $wpdb->prefix . 'kph_fulfillments';
	$fulfillment_items_table = $wpdb->prefix . 'kph_fulfillment_items';
	$order_items_table       = $wpdb->prefix . 'kph_order_items';
	
	$entries = $wpdb->get_results(
		$wpdb->prepare(
			"SELECT
				f.id AS fulfillment_id,
				f.status,
				f.shipped_by,
				f.shipped_at,
				f.note,
				f.created_at,
				fi.id AS fulfillment_item_id,
				fi.shipped_paid_qty,
				fi.shipped_free_qty,
				fi.unit_cost,
				fi.total_cost,
				oi.wc_product_id,
				oi.unique_product_code,
				oi.base_price
			FROM {$fulfillments_table} AS f
			INNER JOIN {$fulfillment_items_table} AS fi
				ON fi.fulfillment_id = f.id
			INNER JOIN {$order_items_table} AS oi
				ON oi.id = fi.order_item_id
			WHERE f.order_id = %d
			ORDER BY f.id DESC, fi.id ASC",
			$order_id
		),
		ARRAY_A
	);
}

$statuses             = $DB->get_fulfillment_statuses();
$statuses['canceled'] = [
	'label' => 'لغو شده',
	'class' => 'danger',
];

$current_fulfillment_id = 0;

$print_url = add_query_arg(
	[
		'action'   => 'print',
		'type'     => 'fulfillments',
		'order_id' => $order_id,
	],
	home_url( '/crm' )
);
?>

<div class="d-flex justify-content-end mb-2">
    <a href="<?php echo esc_url( $print_url ); ?>"
       target="_blank"
       class="btn btn-sm btn-outline-primary">
        <em class="icon ni ni-printer"></em>
        <span>پرینت جدول</span>
    </a>
</div>

<div class="card mb-3" id="fulfillments_print_area">
    <div class="nk-tb-list nk-tb-ulist is-compact">
        <div class="nk-tb-item nk-tb-head">
            <div class="nk-tb-col">
                <span class="sub-text">محصول</span>
            </div>

            <div class="nk-tb-col">
                <span class="sub-text">تعداد</span>
            </div>

            <div class="nk-tb-col">
                <span class="sub-text">بهای واحد</span>
            </div>

            <div class="nk-tb-col">
                <span class="sub-text">بهای کل</span>
            </div>

            <div class="nk-tb-col">
                <span class="sub-text">تاریخ</span>
            </div>
        </div>
		
		<?php if ( empty( $entries ) ) { ?>

            <div class="nk-tb-item">
                <div class="nk-tb-col text-center w-100">
					<span class="sub-text">
						هنوز ارسالی برای این سفارش ثبت نشده است.
					</span>
                </div>
            </div>
			
			<?php
		} else {
			$total_shipped_paid_qty = 0;
			$total_shipped_free_qty = 0;
			$total_base_amount      = 0;
			
			foreach ( $entries as $entry ) {
				$fulfillment_id = (int) $entry['fulfillment_id'];
				
				$status = $statuses[ $entry['status'] ] ?? [
						'label' => $entry['status'],
						'class' => 'light',
					];
				
				$product_title = get_the_title(
					(int) $entry['wc_product_id']
				);
				
				$product_title = $product_title
					?: 'محصول #' . (int) $entry['wc_product_id'];
				
				$shipped_paid_qty = (int) $entry['shipped_paid_qty'];
				$shipped_free_qty = (int) $entry['shipped_free_qty'];
				$shipped_qty      = $shipped_paid_qty + $shipped_free_qty;
				
				$base_price = (float) $entry['base_price'];
				$base_total = $base_price * $shipped_qty;
				
				$total_shipped_paid_qty += $shipped_paid_qty;
				$total_shipped_free_qty += $shipped_free_qty;
				$total_base_amount      += $base_total;
				?>

                <div class="nk-tb-item">
                    <div class="nk-tb-col">
                        <div class="user-card">
                            <div class="user-info">
								<span class="tb-lead">
									<?php echo esc_html( $product_title ); ?>
								</span>

                                <span class="sub-text">
									<?php echo esc_html(
										$entry['unique_product_code']
									); ?>
								</span>
                            </div>
                        </div>
                    </div>

                    <div class="nk-tb-col">
                        <strong class="fs-14px">
							<?php echo esc_html( $shipped_paid_qty ); ?> عدد
                        </strong>
						
						<?php if ( $shipped_free_qty > 0 ) { ?>
                            <span class="sub-text">
								+<?php echo esc_html( $shipped_free_qty ); ?> هدیه
							</span>
						<?php } ?>
                    </div>

                    <div class="nk-tb-col">
						<span>
							<?php echo esc_html(
								number_format( $base_price )
							); ?>
						</span>
                    </div>

                    <div class="nk-tb-col">
						<span>
							<?php echo esc_html(
								number_format( $base_total )
							); ?>
						</span>
                    </div>

                    <div class="nk-tb-col">
						<span class="sub-text">
							<?php echo esc_html(
								date_i18n(
									'Y-m-d',
									strtotime( $entry['created_at'] )
								)
							); ?>
						</span>

                        <span class="sub-text">
							<?php echo esc_html(
								date_i18n(
									'H:i',
									strtotime( $entry['created_at'] )
								)
							); ?>
						</span>
                    </div>
                </div>
				
				<?php
			}
			?>

            <div class="nk-tb-item bg-lighter text-dark">
                <div class="nk-tb-col">
                    <strong class="fs-14px">جمع کل</strong>
                </div>

                <div class="nk-tb-col">
                    <strong class="fs-14px">
						<?php echo esc_html(
							number_format_i18n(
								$total_shipped_paid_qty
							)
						); ?> عدد
                    </strong>
					
					<?php if ( $total_shipped_free_qty > 0 ) { ?>
                        <span class="sub-text">
							+<?php echo esc_html(
								number_format_i18n(
									$total_shipped_free_qty
								)
							); ?> هدیه
						</span>
					<?php } ?>
                </div>

                <div class="nk-tb-col">
					<span class="sub-text">
						جمع بهای پایه
					</span>
                </div>

                <div class="nk-tb-col">
                    <strong class="fs-14px">
						<?php echo esc_html(
							number_format_i18n(
								$total_base_amount
							)
						); ?>
                    </strong>
                </div>

                <div class="nk-tb-col"></div>
            </div>
			
			<?php
		}
		?>
    </div>
</div>