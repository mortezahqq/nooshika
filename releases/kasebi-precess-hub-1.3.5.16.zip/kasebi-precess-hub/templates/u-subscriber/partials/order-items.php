<?php
/**
 * @var int     $order_id
 * @var \kph_db $DB
 */
$order_data = $DB->get_order_data( $order_id );
$items      = $order_data['items'];
?>
<div class="card mb-3">
    <div class="nk-tb-list nk-tb-ulist is-compact">
        <div class="nk-tb-item nk-tb-head">
            <div class="nk-tb-col"><span class="sub-text">نام محصول</span></div>
            <div class="nk-tb-col"><span class="sub-text">قیمت پایه</span></div>
            <div class="nk-tb-col"><span class="sub-text">تعداد</span></div>
            <div class="nk-tb-col"><span class="sub-text">درصد تخفیف</span></div>
            <div class="nk-tb-col"><span class="sub-text">تعداد ارسال شده</span></div>
            <div class="nk-tb-col"><span class="sub-text">جمع کل</span></div>
        </div>
		<?php
		foreach ( $items as $entry ) {
			$total_send        = (int) $entry['shipped_paid_qty'] + (int) $entry['shipped_free_qty'];
			$remaining         = (int) $entry['remaining_paid_qty'] + (int) $entry['remaining_free_qty'];
			$has_inventory     = ! empty( $entry['inventory_id'] );
			$max               = 0;
			$inventory_options = [];
			if ( $has_inventory ) {
				$inventory = $DB->get_inventory_item( (int) $entry['inventory_id'] );
				$available = $inventory ? (int) $inventory['qty_available'] : 0;
				$max       = min( $remaining, $available );
			} else {
				$inventories = $DB->get_inventory_items( [
					'product_id'     => (int) $entry['wc_product_id'],
					'only_available' => TRUE,
					'per_page'       => 100,
					'orderby'        => 'unique_product_code',
					'order'          => 'ASC',
				] );
				
				foreach ( $inventories['items'] ?? [] as $inv ) {
					$inventory_options[] = [
						'value' => (string) $inv['id'],
						'label' => sprintf(
							'%s - موجودی: %s',
							$inv['unique_product_code'],
							number_format( (int) $inv['qty_available'] )
						),
					];
				}
				
				$max = $inventory_options ? $remaining : 0;
			}
			
			$cogs_total = $total_send ? ( $entry['cogs_total'] / $total_send ) : 0;
			?>
            <div class="nk-tb-item">
                <div class="nk-tb-col">
                    <div class="user-card">
                        <div class="user-info">
                            <span class="tb-lead"><?php echo get_the_title( $entry['wc_product_id'] ); ?></span>
                        </div>
                    </div>
                </div>
                <div class="nk-tb-col">
                    <span><?php echo number_format( $entry['base_price'] ); ?></span>
                </div>
                <div class="nk-tb-col">
                    <strong class="fs-14px"><?php echo $entry['qty_ordered']; ?> عدد</strong>
					<?php
					if ( $entry['expected_free_qty'] ) {
						?><span class="sub-text">
                        +<?php echo $entry['expected_free_qty']; ?> هدیه</span><?php
					}
					?>
                </div>
                <div class="nk-tb-col">
					<?php echo round( $entry['discount_cash_value'], 2 ); ?>%
                </div>
                <div class="nk-tb-col">
                    <strong class="fs-14px"><?php echo $entry['shipped_paid_qty']; ?> عدد</strong>
					<?php
					if ( $entry['shipped_free_qty'] ) {
						?><span class="sub-text">
                        +<?php echo $entry['shipped_free_qty']; ?> هدیه</span><?php
					}
					?>
                </div>
                <div class="nk-tb-col">
                    <span><?php echo number_format( $entry['final_amount'] ); ?></span>
                </div>
            </div>
			<?php
		}
		?>
    </div>
</div>