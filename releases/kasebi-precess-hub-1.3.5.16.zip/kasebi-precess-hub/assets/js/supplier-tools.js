(function ($) {
    'use strict';
    function toast(message, status) {
        if (window.NioApp && NioApp.Toast) NioApp.Toast(message, status || 'error', {position:'top-right'});
        else window.alert(message);
    }
    function result(response) {
        if (response.status !== 'success' || typeof response.main !== 'string') {
            toast(response.message || 'عملیات انجام نشد.'); return;
        }
        $('.modal').modal('hide'); $('.modal-backdrop,.tooltip').remove();
        $('.nk-app-root').html(response.main);
        if (response.url) history.replaceState({}, '', response.url);
        if (window.NioApp && NioApp.ajaxInit) NioApp.ajaxInit();
        toast(response.message, 'success');
    }
    $(document).on('click', '.kph-supplier-communications .pagination .page-link', function (event) {
        event.preventDefault(); // Let the native page-item handler retain the supplier/tab filters.
    });
    $(document).on('click', '.kph-supplier-invoice-action', async function (event) {
        event.preventDefault();
        const button=$(this);
        if (button.data('kphDeleting')) return;
        button.data('kphDeleting',true);
        const number=button.attr('data-invoice-no');
        const operation=button.attr('data-operation')==='delete'?'delete':'cancel';
        const label=operation==='delete'?'حذف فاکتور':'ابطال فاکتور';
        const question=operation==='delete'?'فاکتور باطل‌شدهٔ شمارهٔ '+number+' از فهرست حذف شود؟':'فاکتور شمارهٔ '+number+' ابطال شود؟ اثر انبار و بدهی فاکتور برگشت می‌خورد؛ پرداخت‌های واقعی حفظ می‌شوند.';
        let confirmed=false;
        try {
            if (window.Swal) {
                const answer=await Swal.fire({title:label,text:question,icon:'warning',showCancelButton:true,confirmButtonText:label,cancelButtonText:'لغو'});
                confirmed=answer.isConfirmed;
            } else confirmed=window.confirm(question);
            if (!confirmed) { button.data('kphDeleting',false); return; }
            const status=new URL(window.location.href).searchParams.get('status') || 'proforma';
            $.post(kphData.ajax_url,{action:operation==='delete'?'kph_delete_supplier_invoice':'kph_cancel_supplier_invoice',invoice_id:button.attr('data-invoice-id'),supplier_id:button.attr('data-supplier-id'),nonce:button.attr('data-nonce'),page:button.attr('data-page'),status:status})
                .done(result).fail(xhr=>toast(xhr.responseJSON?.message || 'پاسخ حذف دریافت نشد؛ صفحه را تازه کنید و وضعیت فاکتور را بررسی کنید.'))
                .always(()=>button.data('kphDeleting',false));
        } catch (_) { button.data('kphDeleting',false); toast('درخواست حذف انجام نشد.'); }
    });
    $(document).on('submit', '.kph-supplier-action-form', function (event) {
        event.preventDefault();
        const form=$(this),submit=form.find('[type=submit]');
        if (form.data('kphSaving')) return;
        const editor=form.find('.quill-basic'),quill=editor.data('quill');
        const description=quill?.root ? quill.root.innerHTML : (editor.find('.ql-editor').html() || '');
        const title=form.find('[name=title]').val().trim();
        if (!title || !$('<div>').html(description).text().trim()) { toast('عنوان و توضیحات فعالیت را وارد کنید.'); return; }
        form.data('kphSaving',true);submit.prop('disabled',true);
        $.post(kphData.ajax_url,{action:'kph_submit_supplier_action',supplier_id:form.find('[name=supplier_id]').val(),nonce:form.find('[name=nonce]').val(),title:title,description:description,attachment:form.find('[name=attachment]').val()})
            .done(result).fail(xhr=>toast(xhr.responseJSON?.message || 'پاسخ ثبت دریافت نشد؛ صفحه را تازه کنید و فعالیت‌های ثبت‌شده را بررسی کنید.'))
            .always(()=>{form.data('kphSaving',false);submit.prop('disabled',false);});
    });
})(jQuery);
