(function($){
    'use strict';
    function toggle(cell,editing){
        cell.find('.kph-shipment-date-edit').toggleClass('d-none',editing);
        cell.find('.kph-shipment-date-form').toggleClass('d-none',!editing);
        cell.find('.kph-shipment-date-message').text('').removeClass('text-danger');
        if(editing)cell.find('input').val(cell.attr('data-current')).trigger('focus');
    }
    $(document).on('click','.kph-shipment-date-edit',function(){toggle($(this).closest('.kph-order-shipment-date'),true);});
    $(document).on('click','.kph-shipment-date-cancel',function(){const cell=$(this).closest('.kph-order-shipment-date');if(!cell.data('pending'))toggle(cell,false);});
    $(document).on('keydown','.kph-shipment-date-form input',function(e){if(e.key==='Escape'){e.preventDefault();$(this).closest('form').find('.kph-shipment-date-cancel').trigger('click');}});
    $(document).on('submit','.kph-shipment-date-form',function(e){
        e.preventDefault();const form=$(this),cell=form.closest('.kph-order-shipment-date');
        if(cell.data('pending'))return;
        cell.data('pending',true);form.find('button,input').prop('disabled',true);
        const message=cell.find('.kph-shipment-date-message').removeClass('text-danger').text('در حال ذخیره…');
        $.ajax({url:window.kphData.ajax_url,method:'POST',dataType:'json',global:false,timeout:20000,data:{
            action:'kph_update_order_shipment_date',order_id:cell.attr('data-order-id'),nonce:cell.attr('data-nonce'),date:form.find('input').val(),expected:cell.attr('data-current')
        }}).done(function(r){
            if(!cell[0].isConnected)return;
            if(r&&r.status==='success'&&r.data){
                $('.kph-order-shipment-date').filter(function(){return $(this).attr('data-order-id')===cell.attr('data-order-id');}).each(function(){const target=$(this);target.attr('data-current',r.data.date);target.find('.kph-shipment-date-label').text(r.data.label);target.find('input').val(r.data.date);toggle(target,false);});
            }else message.addClass('text-danger').text(r&&r.message?r.message:'تاریخ ذخیره نشد؛ دوباره تلاش کنید.');
        }).fail(function(xhr){message.addClass('text-danger').text(xhr.responseJSON&&xhr.responseJSON.message?xhr.responseJSON.message:'پاسخ ثبت دریافت نشد؛ صفحه را تازه و تاریخ ذخیره‌شده را بررسی کنید.');})
        .always(function(){cell.data('pending',false);form.find('button,input').prop('disabled',false);});
    });
})(jQuery);
