(function($){
    'use strict';
    function form(){return $('#addUserPayments form[data-action="kph_add_payment"]');}
    function invoiceSelect($f){
        var $s=$f.find('#payment_freight_invoice');
        if(!$s.length||!$.fn.select2||$s.hasClass('select2-hidden-accessible'))return;
        $s.select2({width:'100%',dropdownParent:$f.closest('.modal'),placeholder:'جستجوی شماره فاکتور (اختیاری)',allowClear:true,
            language:{errorLoading:function(){return 'جستجوی فاکتور انجام نشد';},noResults:function(){return 'فاکتوری یافت نشد';},searching:function(){return 'در حال جستجو…';}},
            ajax:{url:window.kphData.ajax_url,type:'POST',dataType:'json',global:false,delay:250,
                data:function(params){return {action:'kph_customer_freight_invoices',nonce:$f.find('[data-for="freight_nonce"]').val(),customer_id:$f.find('[data-for="id"]').val(),term:params.term||'',page:params.page||1};},
                processResults:function(res){return res&&res.status==='success'?res.data:{results:[],pagination:{more:false}};}}
        });
    }
    function update($f){
        var freight=$f.find('#payment_method').val()==='customer_freight';
        $f.find('.kph-freight-fields').toggleClass('d-none',!freight);
        $f.find('.kph-payment-side-field').toggleClass('d-none',freight);
        $f.find('#payment_side_debit').prop('disabled',freight);
        if(freight){$f.find('#payment_side_credit').prop('checked',true);invoiceSelect($f);}
    }
    $(document).on('change','#payment_method',function(){update($(this).closest('form'));});
    $(document).on('shown.bs.modal','#addUserPayments',function(){update(form());});
    $(document).on('change','#new_payment_customer_id',function(){
        var $f=$(this).closest('form');$f.find('#payment_freight_invoice').val('').find('option:not([value=""])').remove();$f.find('#payment_freight_invoice').trigger('change');
    });
    $(document).on('kph-customer-freight-saved',function(e,$f){
        // A fresh successful submission gets a new key. Network-error retries retain the original key.
        var key=window.crypto&&window.crypto.randomUUID?window.crypto.randomUUID():Date.now().toString(36)+'-'+Math.random().toString(36).slice(2)+'-'+Math.random().toString(36).slice(2);
        $f.find('[data-for="freight_request"]').val(key);
    });
})(jQuery);
