(function($){
    'use strict';
    function money(v){return String(v).replace(/\B(?=(\d{3})+(?!\d))/g,',');}
    function request(button,action,extra){return $.ajax({url:window.kphData.ajax_url,method:'POST',dataType:'json',global:false,timeout:20000,data:Object.assign({action:action,account_id:button.attr('data-account-id'),nonce:button.attr('data-nonce')},extra||{})});}
    $(document).on('click','.kph-review-account-balance',function(e){
        e.preventDefault();const button=$(this);if(button.data('pending'))return;button.data('pending',true).prop('disabled',true);
        request(button,'kph_review_account_balance').done(function(result){
            if(!result||result.status!=='success'){Swal.fire({icon:'error',text:result&&result.message?result.message:'بررسی حساب انجام نشد.'});return;}
            const r=result.data;
            let text='مانده نمایش‌داده‌شده: '+money(r.stored)+' ریال\nخالص گردش‌های ثبت‌شده: '+money(r.journal)+' ریال\nتعداد گردش: '+r.count;
            if(r.reason)text+='\n'+r.reason;
            const canFix=r.different&&r.eligible;
            if(!r.different)text+='\nمانده ذخیره‌شده با خالص گردش‌های ثبت‌شده یکسان است.';
            if(r.account_type==='expense')text+='\nمانده منفی حساب هزینه می‌تواند حاصل ثبت هزینه‌ها باشد و به‌تنهایی نشانه خطا نیست.';
            if(canFix)text+='\nفقط مانده ذخیره‌شده با خالص گردش‌های موجود یکسان شود؟ اسناد و جهت حواله‌ها تغییر نمی‌کنند.';
            const details=$('<div class="text-start"></div>');
            text.split('\n').forEach(function(line){details.append($('<p class="mb-1"></p>').text(line));});
            button.data('dialog',true);
            Swal.fire({titleText:'بررسی مانده «'+r.title+'»',html:details[0],icon:canFix?'warning':'info',showCancelButton:canFix,confirmButtonText:canFix?'تطبیق مانده با گردش':'بستن',cancelButtonText:'لغو'}).then(function(answer){
                if(!canFix||!answer.isConfirmed){button.data('dialog',false).data('pending',false).prop('disabled',false);return;}
                button.data('pending',true).prop('disabled',true);
                request(button,'kph_reconcile_account_balance',{token:r.token}).done(function(saved){
                    if(saved&&saved.status==='success'){
                        $('.kph-finance-account-balance').filter(function(){return $(this).attr('data-account-id')===button.attr('data-account-id');}).text(saved.data.label);
                    }
                    Swal.fire({icon:saved&&saved.status==='success'?'success':'error',text:saved&&saved.message?saved.message:'تطبیق انجام نشد.'});
                }).fail(function(){Swal.fire({icon:'error',text:'پاسخ ثبت دریافت نشد؛ دوباره مانده حساب را بررسی کنید.'});}).always(function(){button.data('dialog',false).data('pending',false).prop('disabled',false);});
            });
        }).fail(function(){Swal.fire({icon:'error',text:'ارتباط برای بررسی مانده برقرار نشد.'});}).always(function(){if(!button.data('dialog'))button.data('pending',false).prop('disabled',false);});
    });
})(jQuery);

(function($){
    'use strict';
    function money(value){return String(value).replace(/\B(?=(\d{3})+(?!\d))/g,',');}
    $(document).on('click','.kph-review-transfer-deposits',function(event){
        event.preventDefault();const button=$(this);if(button.data('pending'))return;
        button.data('pending',true).prop('disabled',true);
        function request(action,extra){return $.ajax({url:window.kphData.ajax_url,method:'POST',dataType:'json',global:false,timeout:30000,data:Object.assign({action:action,account_id:button.attr('data-account-id'),nonce:button.attr('data-nonce')},extra||{})});}
        function release(){button.data('pending',false).prop('disabled',false);}
        function error(result){return Swal.fire({icon:'error',text:result&&result.message?result.message:'پاسخ بررسی دریافت نشد؛ پیش از تلاش مجدد صفحه را تازه کنید.'});}
        request('kph_review_transfer_deposits').done(function(result){
            if(!result||result.status!=='success'){error(result);release();return;}
            const r=result.data,details=$('<div class="text-start"></div>');
            details.append($('<p></p>').text('واریزهای اشتباهاً بدهکار: '+r.count+' مورد؛ جمع '+money(r.deposit_total)+' ریال'));
            if(r.items.length){
                const table=$('<table class="table table-bordered table-sm"><thead><tr><th>حواله</th><th>تراکنش</th><th>مبلغ (ریال)</th></tr></thead><tbody></tbody></table>');
                r.items.forEach(function(row){const tr=$('<tr></tr>');[row.transfer_id,row.transaction_id,money(row.amount)].forEach(function(value){tr.append($('<td></td>').text(value));});table.find('tbody').append(tr);});details.append($('<div class="table-responsive"></div>').append(table));
                details.append($('<p></p>').text('مانده فعلی: '+money(r.stored)+' ریال؛ مانده پس از اصلاح: '+money(r.new_balance)+' ریال'));
            }
            if(r.reason)details.append($('<p class="text-danger"></p>').text(r.reason));
            if(r.skipped.length){details.append($('<p class="text-danger"></p>').text(r.skipped.length+' مورد مبهم اصلاح نمی‌شود:'));r.skipped.forEach(function(row){details.append($('<p class="small"></p>').text('تراکنش '+row.transaction_id+': '+row.reason));});}
            if(r.eligible)details.append($('<p></p>').text('همین واریزها بستانکار می‌شوند و از هزینه حذف می‌شوند. حساب مشتری، ضمیمه‌ها و برداشت‌های واقعی حفظ می‌شوند.'));
            if(!r.count&&!r.skipped.length)details.append($('<p></p>').text('واریز بدهکار قابل اصلاحی در این حساب وجود ندارد.'));
            Swal.fire({titleText:'بررسی واریز حواله‌های «'+r.title+'»',html:details[0],icon:r.eligible?'warning':'info',showCancelButton:r.eligible,confirmButtonText:r.eligible?'اصلاح واریزهای نمایش‌داده‌شده':'بستن',cancelButtonText:'لغو'}).then(function(answer){
                if(!r.eligible||!answer.isConfirmed){release();return;}
                request('kph_repair_transfer_deposits',{token:r.token}).done(function(saved){
                    if(!saved||saved.status!=='success'){error(saved);return;}
                    Swal.fire({icon:'success',text:saved.message}).then(function(){window.location.reload();});
                }).fail(function(xhr){error(xhr.responseJSON);}).always(release);
            });
        }).fail(function(xhr){error(xhr.responseJSON);release();});
    });
})(jQuery);
