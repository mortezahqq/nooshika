(function ($) {
    'use strict';
    const selections = new Map();
    const maxOrders = 500;
    const validID = value => /^[1-9][0-9]*$/.test(String(value));
    function notice(message) {
        if (window.NioApp && window.NioApp.Toast) window.NioApp.Toast(message, 'warning', {position: 'top-right'});
        else window.alert(message);
    }
    function selected(viewer) {
        if (!selections.has(viewer)) {
            let ids = [];
            try { ids = JSON.parse(window.sessionStorage.getItem('kph-preparation-' + viewer) || '[]'); } catch (_) {}
            if (!Array.isArray(ids) || ids.length > maxOrders) ids = [];
            selections.set(viewer, new Set(ids.filter(validID).map(String)));
        }
        return selections.get(viewer);
    }
    function save(viewer) {
        try { window.sessionStorage.setItem('kph-preparation-' + viewer, JSON.stringify(Array.from(selected(viewer)))); } catch (_) {}
    }
    function inputs(viewer) {
        return $('.kph-preparation-select').filter(function () { return $(this).attr('data-viewer') === viewer; });
    }
    function refresh() {
        $('.kph-preparation-controls').each(function () {
            const controls = $(this), viewer = controls.attr('data-viewer');
            if (!validID(viewer)) return;
            const ids = selected(viewer), fields = inputs(viewer);
            fields.each(function () { this.checked = ids.has(String(this.value)); });
            const checked = fields.filter(':checked').length;
            controls.find('.kph-preparation-all').prop({checked: fields.length > 0 && checked === fields.length,
                indeterminate: checked > 0 && checked < fields.length, disabled: fields.length === 0});
            controls.find('.kph-preparation-count').text(new Intl.NumberFormat('fa-IR').format(ids.size) + ' پیش‌فاکتور انتخاب شده');
            controls.find('.kph-preparation-print, .kph-preparation-clear').prop('disabled', ids.size === 0);
            controls.find('.kph-preparation-selection').prop('hidden', ids.size === 0);
            const chosen = controls.find('.kph-preparation-selected').empty();
            ids.forEach(id => {
                $('<button>', {type: 'button', class: 'btn btn-sm btn-light kph-preparation-remove',
                    'data-id': id, 'aria-label': 'حذف پیش‌فاکتور شماره ' + id + ' از انتخاب‌ها'}).text('#' + id + ' ×').appendTo(chosen);
            });
        });
    }
    $(document).on('change', '.kph-preparation-select', function () {
        const viewer = $(this).attr('data-viewer'), id = String(this.value);
        if (!validID(viewer) || !validID(id)) return;
        const ids = selected(viewer);
        if (this.checked && !ids.has(id) && ids.size >= maxOrders) {
            this.checked = false;
            notice('در هر نوبت حداکثر ۵۰۰ پیش‌فاکتور انتخاب کنید.');
        } else if (this.checked) ids.add(id);
        else ids.delete(id);
        save(viewer); refresh();
    });
    $(document).on('change', '.kph-preparation-all', function () {
        const viewer = $(this).closest('.kph-preparation-controls').attr('data-viewer');
        const ids = selected(viewer), visible = inputs(viewer).toArray().map(field => String(field.value)).filter(validID);
        if (this.checked && new Set([...ids, ...visible]).size > maxOrders) {
            notice('در هر نوبت حداکثر ۵۰۰ پیش‌فاکتور انتخاب کنید.'); refresh(); return;
        }
        visible.forEach(id => { if (this.checked) ids.add(id); else ids.delete(id); });
        save(viewer); refresh();
    });
    $(document).on('click', '.kph-preparation-clear', function () {
        const viewer = $(this).closest('.kph-preparation-controls').attr('data-viewer');
        selected(viewer).clear(); save(viewer); refresh();
    });
    $(document).on('click', '.kph-preparation-remove', function () {
        const viewer = $(this).closest('.kph-preparation-controls').attr('data-viewer');
        selected(viewer).delete($(this).attr('data-id')); save(viewer); refresh();
    });
    $(document).on('click', '.kph-preparation-print', function () {
        const viewer = $(this).closest('.kph-preparation-controls').attr('data-viewer');
        const ids = Array.from(selected(viewer));
        if (!ids.length) { notice('حداقل یک پیش‌فاکتور را انتخاب کنید.'); return; }
        const url = new URL($(this).attr('data-url'), window.location.href);
        if (url.origin !== window.location.origin) return;
        url.searchParams.set('action', 'print');
        url.searchParams.set('type', 'preparation-list');
        url.searchParams.set('ids', ids.join(','));
        url.searchParams.set('_wpnonce', $(this).attr('data-nonce'));
        window.open(url.toString(), '_blank', 'noopener');
    });
    $(document).on('kph-preparation-refresh', refresh);
    $(refresh);
})(jQuery);
