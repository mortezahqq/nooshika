Vazirmatn Regular and Bold. Copyright 2015 The Vazirmatn Project Authors.
License: SIL Open Font License 1.1; see OFL.txt.
Source: https://github.com/rastikerdar/vazirmatn/tree/master/fonts/ttf
Original TTF files are bundled unchanged. Derived TCPDF embedding metrics are under vendor/tcpdf/fonts/payslip/.
Regular SHA256: b69fd4c680b8f3f225feabcc655a2c585d97627b8f5f5c0f9985e894069f3a56
Bold SHA256: f635fdbea28f265de395ba83b4b1570dcf2f58d13c65469e61903b1c2d2ae723
