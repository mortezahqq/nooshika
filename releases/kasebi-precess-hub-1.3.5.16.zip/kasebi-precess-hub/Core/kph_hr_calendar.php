<?php
if(!defined('ABSPATH')){exit;}

/** Date-only HR calendar: no theme converters, date_i18n filters or timezone arithmetic. */
final class kph_hr_calendar {
    public static function latin($value): string {
        return strtr((string)$value,array_combine(preg_split('//u','۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩',-1,PREG_SPLIT_NO_EMPTY),str_split('01234567890123456789')));
    }
    private static function gregorian(int $jy,int $jm,int $jd): array {
        $jy+=1595;$days=-355668+365*$jy+intdiv($jy,33)*8+intdiv($jy%33+3,4)+$jd+($jm<7?($jm-1)*31:($jm-7)*30+186);
        $gy=400*intdiv($days,146097);$days%=146097;
        if($days>36524){$gy+=100*intdiv(--$days,36524);$days%=36524;if($days>=365){$days++;}}
        $gy+=4*intdiv($days,1461);$days%=1461;
        if($days>365){$gy+=intdiv($days-1,365);$days=($days-1)%365;}
        $gd=$days+1;$months=[0,31,(($gy%4===0&&$gy%100!==0)||$gy%400===0)?29:28,31,30,31,30,31,31,30,31,30,31];
        for($gm=1;$gm<=12&&$gd>$months[$gm];$gm++){$gd-=$months[$gm];}
        return [$gy,$gm,$gd];
    }
    public static function jalali(int $gy,int $gm,int $gd): array {
        $offset=[0,31,59,90,120,151,181,212,243,273,304,334];$gy2=$gm>2?$gy+1:$gy;
        $days=355666+365*$gy+intdiv($gy2+3,4)-intdiv($gy2+99,100)+intdiv($gy2+399,400)+$gd+$offset[$gm-1];
        $jy=-1595+33*intdiv($days,12053);$days%=12053;$jy+=4*intdiv($days,1461);$days%=1461;
        if($days>365){$jy+=intdiv($days-1,365);$days=($days-1)%365;}
        $jm=$days<186?1+intdiv($days,31):7+intdiv($days-186,30);$jd=1+($days<186?$days%31:($days-186)%30);
        return [$jy,$jm,$jd];
    }
    public static function from_gregorian(string $value): array {
        $value = substr(trim($value), 0, 10);
        $parts = preg_split('/[-\/]/', $value);
        if ( count($parts) !== 3 ) { throw new RuntimeException('تاریخ میلادی معتبر نیست.'); }
        [$gy,$gm,$gd] = array_map('intval', $parts);
        if ( ! checkdate($gm,$gd,$gy) ) { throw new RuntimeException('تاریخ میلادی معتبر نیست.'); }
        return self::jalali($gy,$gm,$gd);
    }
    public static function normalize($value): string {
        if(!is_scalar($value)){throw new RuntimeException('تاریخ معتبر نیست.');}
        $value=str_replace('/','-',trim(self::latin($value)));
        if(!preg_match('/^(\d{4})-(\d{1,2})-(\d{1,2})$/D',$value,$m)){throw new RuntimeException('تاریخ را با قالب سال/ماه/روز وارد کنید.');}
        [$year,$month,$day]=[(int)$m[1],(int)$m[2],(int)$m[3]];
        if($year<1700){
            if($year<1300||$month<1||$month>12||$day<1||$day>($month<=6?31:30)){throw new RuntimeException('تاریخ شمسی معتبر نیست.');}
            $g=self::gregorian($year,$month,$day);
            if(!checkdate($g[1],$g[2],$g[0])||self::jalali(...$g)!==[$year,$month,$day]){throw new RuntimeException('تاریخ شمسی معتبر نیست؛ روز ماه و کبیسه را بررسی کنید.');}
            [$year,$month,$day]=$g;
        }
        $out=sprintf('%04d-%02d-%02d',$year,$month,$day);
        if(!checkdate($month,$day,$year)||$out<'1900-01-01'||$out>'2200-12-31'){throw new RuntimeException('تاریخ معتبر نیست.');}
        return $out;
    }
    public static function display(string $value): string {
        // Database timestamps display their date part without passing through WP date filters.
        if(preg_match('/^(\d{4}[-\/]\d{1,2}[-\/]\d{1,2})(?:[ T].*)?$/D',self::latin($value),$m)){$value=$m[1];}
        [$year,$month,$day]=array_map('intval',explode('-',self::normalize($value)));
        return vsprintf('%04d/%02d/%02d',self::jalali($year,$month,$day));
    }
}
