<?php
if (!defined('ABSPATH')) { exit; }

/** Exact Iranian commercial mesghal conversion. Stored production weights remain the audit source. */
final class kph_product_weight {
    public static function standard_grams(string $title): ?string {
        $title=strtr($title,array_combine(preg_split('//u','۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩',-1,PREG_SPLIT_NO_EMPTY),str_split('01234567890123456789')));
        $title=str_replace(['ي','ك',"\u{200C}",'٫'],['ی','ک',' ','.'],$title);
        $words=['ربع'=>'0.25','نیم'=>'0.5','نصف'=>'0.5','یک'=>'1','دو'=>'2','سه'=>'3','چهار'=>'4','پنج'=>'5','شش'=>'6','هفت'=>'7','هشت'=>'8','نه'=>'9','ده'=>'10'];
        $title=preg_replace('/\s+/u',' ',trim($title));
        foreach(['یک'=>1,'دو'=>2,'سه'=>3,'چهار'=>4,'پنج'=>5] as $word=>$whole)$words=[$word.' و نیم'=>(string)($whole+.5)]+$words;
        $count=preg_match_all('~(?<![\p{L}\p{N}./])('.implode('|',array_keys($words)).'|[0-9]+(?:\.[0-9]{1,3})?)\s*مثقال(?:ی)?(?!\p{L})~u',$title,$matches);
        if($count!==1)return null;
        $position=strpos($title,$matches[0][0]);
        $prefix=trim(substr($title,0,$position));
        if(preg_match('/(?:^|\s)(?:و|یک|دو|سه|چهار|پنج|[0-9]+|\/)$/u',$prefix))return null;
        $amount=$words[$matches[1][0]]??$matches[1][0];
        if(bccomp($amount,'0',6)<=0||bccomp($amount,'1000',6)>0)return null;
        $grams=bcmul($amount,'4.608',6);
        // Only infer weights exactly representable in the existing 0.001-gram production storage.
        if(bccomp($grams,bcadd($grams,'0',3),6)!==0)return null;
        return bcadd($grams,'0',3);
    }

    public static function recorded_grams($weight_kg): string {
        $kg=is_numeric($weight_kg)?number_format((float)$weight_kg,6,'.',''):'0';
        return rtrim(rtrim(bcmul($kg,'1000',3),'0'),'.') ?: '0';
    }

    public static function report(string $title,$weight_kg): array {
        $standard=self::standard_grams($title);
        $recorded=self::recorded_grams($weight_kg);
        return ['grams'=>$standard??$recorded,'standard'=>$standard!==null,'recorded'=>$recorded,
            'different'=>$standard!==null && bccomp($standard,$recorded,3)!==0];
    }

    public static function print_label(string $title,$weight_kg): string {
        $weight=self::report($title,$weight_kg);
        $label=$weight['grams'].' گرم'.($weight['standard']?' (استاندارد)':'');
        if($weight['different'])$label.='؛ ثبت این تولید: '.$weight['recorded'].' گرم';
        return $label;
    }
}
