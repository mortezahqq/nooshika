<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Visitor reporting and target rewards. Mutations share the caller's transaction. */
trait kph_visitor_targets {
	public function visitor_order_scope_id(): int {
		$id = get_current_user_id();
		return $id > 0 && nooshika_get_user_role( $id ) === 'visitor' ? (int) $id : 0;
	}

	public function visitor_can_access_order( int $order_id, bool $is_item = FALSE ): bool {
		$visitor = $this->visitor_order_scope_id();
		if ( ! $visitor ) { return TRUE; }
		if ( $is_item ) {
			$order_id = (int) $this->db->get_var( $this->db->prepare( "SELECT order_id FROM {$this->order_items} WHERE id = %d", $order_id ) );
		}
		return $order_id > 0 && (int) $this->db->get_var( $this->db->prepare(
			"SELECT created_by FROM {$this->orders} WHERE id = %d", $order_id ) ) === $visitor;
	}

	private function visitor_order_scope_sql( string $alias = '' ): string {
		$id = $this->visitor_order_scope_id();
		return $id ? ' AND ' . ( $alias ? $alias . '.' : '' ) . 'created_by = ' . $id : '';
	}

	public function delete_visitor_target( int $visitor_id, int $target_id ): array {
		if ( $target_id <= 0 || nooshika_get_user_role( $visitor_id ) !== 'visitor' ) { return $this->fail( 'تارگت معتبر نیست.' ); }
		$this->db->query( 'START TRANSACTION' );
		if ( ! $this->lock_visitor_targets( $visitor_id ) ) { $this->db->query( 'ROLLBACK' ); return $this->fail( 'قفل تارگت دریافت نشد؛ دوباره تلاش کنید.' ); }
		$targets = $this->visitor_target_rows( $visitor_id, TRUE );
		if ( $this->db->last_error || ! isset( $targets[$target_id] ) ) { $this->db->query( 'ROLLBACK' ); return $this->fail( 'تارگت یافت نشد.' ); }
		$reward = $this->db->get_var( $this->db->prepare( "SELECT id FROM {$this->ledger_entries}
			WHERE user_id = %d AND ref_type = 'visitor_target' AND ref_id = %d LIMIT 1 FOR UPDATE", $visitor_id, $target_id ) );
		if ( $reward || $this->db->last_error ) { $this->db->query( 'ROLLBACK' ); return $this->fail( 'تارگت دارای سابقه پاداش برای حفظ سوابق حسابداری قابل حذف نیست.' ); }
		$deleted = $this->db->query( $this->db->prepare( "DELETE FROM {$this->db->usermeta}
			WHERE umeta_id = %d AND user_id = %d AND meta_key = 'kph_visitor_sales_target'", $target_id, $visitor_id ) );
		if ( $deleted !== 1 ) { $this->db->query( 'ROLLBACK' ); return $this->fail( 'حذف تارگت انجام نشد.' ); }
		$this->db->query( 'COMMIT' );
		wp_cache_delete( $visitor_id, 'user_meta' );
		return $this->ok( 'تارگت حذف شد.' );
	}

	/** Month-to-date, grouped per invoice; shipment ledger contains actual selling amounts. */
	public function get_visitor_monthly_sales( array $visitor_ids, string $from, string $until ): array {
		if ( $this->visitor_order_scope_id() ) { $visitor_ids = [ $this->visitor_order_scope_id() ]; }
		$visitor_ids = array_values( array_filter( array_map( 'absint', $visitor_ids ) ) );
		if ( ! $visitor_ids ) { return []; }
		$ids = implode( ',', $visitor_ids );
		$assignment = $this->visitor_order_scope_id() ? 'a.created_by' : $this->order_visitor_sql();
		$proformas = $this->db->get_results( $this->db->prepare(
			"SELECT a.id, a.customer_id, a.created_at AS activity_at, {$assignment} AS visitor_id,
			 a.total_payable AS amount, 'proforma' AS kind FROM {$this->orders} a
			 WHERE a.status = 'proforma' AND a.created_at >= %s AND a.created_at <= %s
			 AND {$assignment} IN ({$ids})", $from, $until ), ARRAY_A );
		$shipments = $this->db->get_results( $this->db->prepare(
			"SELECT a.id, a.customer_id, MAX(f.created_at) AS activity_at, {$assignment} AS visitor_id,
			 SUM(CASE WHEN l.type = 'debit' THEN l.amount ELSE -l.amount END) AS amount, 'shipped' AS kind
			 FROM {$this->orders} a INNER JOIN {$this->fulfillments} f ON f.order_id = a.id
			 INNER JOIN {$this->ledger_entries} l ON l.ref_id = f.id
			 WHERE l.entry_type IN ('customer_order','customer_order_return') AND l.ref_type = 'fulfillment'
			 AND f.created_at >= %s AND f.created_at <= %s AND l.created_at <= %s
			 AND {$assignment} IN ({$ids}) GROUP BY a.id, a.customer_id, visitor_id",
			$from, $until, $until ), ARRAY_A );
		$result = array_fill_keys( $visitor_ids, [ 'proforma' => 0.0, 'shipped' => 0.0, 'items' => [] ] );
		foreach ( array_merge( $proformas ?: [], $shipments ?: [] ) as $row ) {
			$id = (int) $row['visitor_id'];
			$result[$id][$row['kind']] += (float) $row['amount'];
			$result[$id]['items'][] = $row;
		}
		foreach ( $result as &$summary ) {
			usort( $summary['items'], fn( $a, $b ) => strcmp( $b['activity_at'], $a['activity_at'] ) );
		}
		unset( $summary );
		return $result;
	}

	private ?array $visitor_report_ids = NULL;

	private function visitor_ids_sql(): string {
		if ( $this->visitor_report_ids === NULL ) {
			$this->visitor_report_ids = array_map( 'absint', get_users( [ 'role__in' => [ 'visitor' ], 'fields' => 'ids' ] ) );
		}
		return implode( ',', $this->visitor_report_ids ?: [ 0 ] );
	}

	/** Current customer assignment, with the legacy key used only as a fallback. */
	private function customer_visitor_sql( string $customer ): string {
		$ids = $this->visitor_ids_sql();
		$legacy = $this->db->prepare( '%s', KPH_MARKETER_META );
		return "COALESCE(
			(SELECT CAST(vm.meta_value AS UNSIGNED) FROM {$this->db->usermeta} vm
			 WHERE vm.user_id = {$customer} AND vm.meta_key = 'customer_marketer'
			 AND CAST(vm.meta_value AS UNSIGNED) IN ({$ids}) ORDER BY vm.umeta_id LIMIT 1),
			(SELECT CAST(vm.meta_value AS UNSIGNED) FROM {$this->db->usermeta} vm
			 WHERE vm.user_id = {$customer} AND vm.meta_key = {$legacy}
			 AND CAST(vm.meta_value AS UNSIGNED) IN ({$ids}) ORDER BY vm.umeta_id LIMIT 1))";
	}

	/** Snapshot on the order wins over current customer assignment and creator. */
	private function order_visitor_sql( string $alias = 'a' ): string {
		$ids = $this->visitor_ids_sql();
		$customer = $this->customer_visitor_sql( "{$alias}.customer_id" );
		return "COALESCE(
			(SELECT CAST(om.meta_value AS UNSIGNED) FROM {$this->db_prefix}orders_meta om
			 WHERE om.order_id = {$alias}.id AND om.meta_key = 'marketer_id'
			 AND CAST(om.meta_value AS UNSIGNED) IN ({$ids}) ORDER BY om.id LIMIT 1),
			{$customer}, CASE WHEN {$alias}.created_by IN ({$ids}) THEN {$alias}.created_by ELSE 0 END)";
	}

	public function get_visitor_summaries( array $visitor_ids, bool $creator_orders = FALSE ): array {
		$visitor_ids = array_values( array_filter( array_map( 'absint', $visitor_ids ) ) );
		if ( ! $visitor_ids ) { return []; }
		$ids = implode( ',', $visitor_ids );
		$result = array_fill_keys( $visitor_ids, [ 'customer_balance' => 0, 'open_orders' => 0, 'target_amount' => 0 ] );
		$assignment = $this->customer_visitor_sql( 'u.ID' );
		$rows = $this->db->get_results( "SELECT {$assignment} AS visitor_id,
			COALESCE(SUM(lb.balance), 0) AS balance FROM {$this->db->users} u
			LEFT JOIN (SELECT user_id, SUM(CASE WHEN type = 'debit' THEN amount ELSE -amount END) AS balance
			 FROM {$this->ledger_entries} GROUP BY user_id) lb ON lb.user_id = u.ID
			GROUP BY visitor_id HAVING visitor_id IN ({$ids})", ARRAY_A );
		foreach ( $rows ?: [] as $row ) { $result[ $row['visitor_id'] ]['customer_balance'] = (float) $row['balance']; }
		$assignment = $creator_orders ? 'a.created_by' : $this->order_visitor_sql();
		$rows = $this->db->get_results( "SELECT {$assignment} AS visitor_id, COUNT(*) AS total
			FROM {$this->orders} a WHERE a.status IN ('proforma','registered','shortage')
			GROUP BY visitor_id HAVING visitor_id IN ({$ids})", ARRAY_A );
		foreach ( $rows ?: [] as $row ) { $result[ $row['visitor_id'] ]['open_orders'] = (int) $row['total']; }
		$today = current_time( 'Y-m-d' );
		$rows = $this->db->get_results( "SELECT user_id, meta_value FROM {$this->db->usermeta}
			WHERE meta_key = 'kph_visitor_sales_target' AND user_id IN ({$ids})", ARRAY_A );
		foreach ( $rows ?: [] as $row ) {
			$target = maybe_unserialize( $row['meta_value'] );
			if ( is_array( $target ) && $target['date_from'] <= $today && $target['date_to'] >= $today ) {
				$result[ $row['user_id'] ]['target_amount'] += (float) $target['amount'];
			}
		}
		return $result;
	}

	private function visitor_target_rows( int $visitor_id, bool $lock = FALSE ): array {
		$sql = $this->db->prepare( "SELECT umeta_id, meta_value FROM {$this->db->usermeta}
			WHERE user_id = %d AND meta_key = 'kph_visitor_sales_target' ORDER BY umeta_id DESC", $visitor_id );
		$rows = $this->db->get_results( $sql . ( $lock ? ' FOR UPDATE' : '' ), ARRAY_A );
		$result = [];
		foreach ( $rows ?: [] as $row ) {
			$target = maybe_unserialize( $row['meta_value'] );
			if ( is_array( $target ) ) { $result[ (int) $row['umeta_id'] ] = $target; }
		}
		return $result;
	}

	private function visitor_target_sales( int $visitor_id, array $target, bool $lock = FALSE ): float {
		// Restrict displayed progress; accounting synchronization retains its existing attribution.
		$assignment = ! $lock && $this->visitor_order_scope_id() ? 'a.created_by' : $this->order_visitor_sql();
		// Date belongs to the original shipment: later returns correct that same period.
		$sql = $this->db->prepare( "SELECT l.id, l.type, l.amount FROM {$this->ledger_entries} l
			INNER JOIN {$this->fulfillments} f ON f.id = l.ref_id
			INNER JOIN {$this->orders} a ON a.id = f.order_id
			WHERE l.entry_type IN ('customer_order','customer_order_return') AND l.ref_type = 'fulfillment'
			AND {$assignment} = %d AND f.created_at >= %s AND f.created_at <= %s",
			$visitor_id, $target['date_from'] . ' 00:00:00', $target['date_to'] . ' 23:59:59' );
		$rows = $this->db->get_results( $sql . ( $lock ? ' FOR UPDATE' : '' ), ARRAY_A );
		$total = 0;
		foreach ( $rows ?: [] as $row ) { $total += $row['type'] === 'debit' ? (float) $row['amount'] : -(float) $row['amount']; }
		return max( 0, round( $total, 2 ) );
	}

	private function visitor_target_reward( int $visitor_id, int $target_id, bool $lock = FALSE ): float {
		$sql = $this->db->prepare( "SELECT id, type, amount FROM {$this->ledger_entries}
			WHERE user_id = %d AND ref_type = 'visitor_target' AND ref_id = %d
			AND entry_type IN ('visitor_target_bonus','visitor_target_reversal')", $visitor_id, $target_id );
		$rows = $this->db->get_results( $sql . ( $lock ? ' FOR UPDATE' : '' ), ARRAY_A );
		$total = 0;
		foreach ( $rows ?: [] as $row ) { $total += $row['type'] === 'credit' ? (float) $row['amount'] : -(float) $row['amount']; }
		return round( $total, 2 );
	}

	public function get_visitor_targets( int $visitor_id ): array {
		if ( $this->visitor_order_scope_id() ) { $visitor_id = $this->visitor_order_scope_id(); }
		$targets = $this->visitor_target_rows( $visitor_id );
		$reward_ids = $this->db->get_col( $this->db->prepare(
			"SELECT DISTINCT ref_id FROM {$this->ledger_entries} WHERE user_id = %d AND ref_type = 'visitor_target'", $visitor_id ) );
		foreach ( $targets as $id => &$target ) {
			$target['has_reward_history'] = in_array( $id, array_map( 'intval', $reward_ids ?: [] ), TRUE );
			$target['sales'] = $this->visitor_target_sales( $visitor_id, $target );
			$target['reward'] = $this->visitor_target_reward( $visitor_id, $id );
		}
		unset( $target );
		return $targets;
	}

	private function lock_visitor_targets( int $visitor_id ): bool {
		return (int) $this->db->get_var( $this->db->prepare(
			"SELECT ID FROM {$this->db->users} WHERE ID = %d FOR UPDATE", $visitor_id ) ) === $visitor_id;
	}

	private function sync_visitor_target_rewards( int $visitor_id ): array {
		foreach ( $this->visitor_target_rows( $visitor_id, TRUE ) as $id => $target ) {
			$sales = $this->visitor_target_sales( $visitor_id, $target, TRUE );
			if ( $this->db->last_error ) { return $this->fail( 'خواندن فروش تارگت ناموفق بود.' ); }
			$reward = $this->visitor_target_reward( $visitor_id, $id, TRUE );
			if ( $this->db->last_error ) { return $this->fail( 'خواندن پاداش تارگت ناموفق بود.' ); }
			$earned = $sales >= (float) $target['amount'] ? (float) $target['bonus'] : 0;
			$delta = round( $earned - $reward, 2 );
			if ( abs( $delta ) < 0.01 ) { continue; }
			$res = $this->add_ledger_entry( [
				'user_id' => $visitor_id, 'entry_type' => $delta > 0 ? 'visitor_target_bonus' : 'visitor_target_reversal',
				'type' => $delta > 0 ? 'credit' : 'debit', 'amount' => abs( $delta ),
				'ref_type' => 'visitor_target', 'ref_id' => $id, 'posted_at' => current_time( 'mysql' ),
				'note' => ( $delta > 0 ? 'پاداش تحقق تارگت: ' : 'برگشت پاداش تارگت: ' ) . $target['title'],
				'meta' => [ 'target_amount' => $target['amount'], 'net_sales' => $sales, 'creator_id' => get_current_user_id() ],
			] );
			if ( $res['status'] !== 'success' ) { return $res; }
		}
		return $this->db->last_error ? $this->fail( 'خواندن تارگت ناموفق بود.' ) : $this->ok();
	}

	public function save_visitor_target( int $visitor_id, array $data ): array {
		if ( nooshika_get_user_role( $visitor_id ) !== 'visitor' ) { return $this->fail( 'ویزیتور معتبر نیست.' ); }
		foreach ( [ 'title', 'date_from', 'date_to', 'amount', 'bonus', 'target_id' ] as $key ) {
			if ( isset( $data[ $key ] ) && ! is_scalar( $data[ $key ] ) ) { return $this->fail( 'اطلاعات تارگت معتبر نیست.' ); }
		}
		$target = [ 'title' => sanitize_text_field( $data['title'] ?? '' ) ];
		foreach ( [ 'date_from', 'date_to' ] as $key ) {
			$value = strtr( (string) ( $data[ $key ] ?? '' ), array_combine( preg_split( '//u', '۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩', -1, PREG_SPLIT_NO_EMPTY ), str_split( '01234567890123456789' ) ) );
			$value = str_replace( '/', '-', $value );
			if ( ! preg_match( '~^1[34]\d{2}-\d{2}-\d{2}$~', $value ) ) { return $this->fail( 'تاریخ شمسی را به صورت ۱۴۰۵-۰۱-۰۱ وارد کنید.' ); }
			[ $year, $month, $day ] = array_map( 'intval', explode( '-', $value ) );
			$year_days = ( strtotime( nooshika_jalali_to_gregorian( ( $year + 1 ) . '-01-01' ) ) - strtotime( nooshika_jalali_to_gregorian( $year . '-01-01' ) ) ) / DAY_IN_SECONDS;
			$max_day = $month <= 6 ? 31 : ( $month < 12 ? 30 : ( $year_days > 365 ? 30 : 29 ) );
			if ( $month < 1 || $month > 12 || $day < 1 || $day > $max_day ) { return $this->fail( 'تاریخ تارگت معتبر نیست.' ); }
			$gregorian = nooshika_jalali_to_gregorian( $value );
			$date = DateTimeImmutable::createFromFormat( '!Y-m-d', str_replace( '/', '-', (string) $gregorian ) );
			if ( ! $date ) { return $this->fail( 'تاریخ تارگت معتبر نیست.' ); }
			$target[ $key ] = $date->format( 'Y-m-d' );
			$target[ $key . '_fa' ] = $value;
		}
		foreach ( [ 'amount', 'bonus' ] as $key ) {
			$value = str_replace( ',', '', (string) ( $data[ $key ] ?? '' ) );
			if ( ! preg_match( '/^[0-9]+$/D', $value ) || (float) $value <= 0 || (float) $value > 999999999999999 ) {
				return $this->fail( 'مبلغ هدف و پاداش باید عدد صحیح و بزرگ‌تر از صفر باشند.' );
			}
			$target[ $key ] = (float) $value;
		}
		if ( $target['title'] === '' || $target['date_from'] > $target['date_to'] ) { return $this->fail( 'عنوان و بازه زمانی تارگت را بررسی کنید.' ); }
		$id = absint( $data['target_id'] ?? 0 );
		$this->db->query( 'START TRANSACTION' );
		if ( ! $this->lock_visitor_targets( $visitor_id ) ) { $this->db->query( 'ROLLBACK' ); return $this->fail( 'قفل تارگت دریافت نشد؛ دوباره تلاش کنید.' ); }
		$targets = $this->visitor_target_rows( $visitor_id, TRUE );
		if ( $this->db->last_error || ( $id && ! isset( $targets[ $id ] ) ) ) { $this->db->query( 'ROLLBACK' ); return $this->fail( 'تارگت یافت نشد.' ); }
		foreach ( $targets as $existing_id => $existing ) {
			if ( $existing_id !== $id && $target['date_from'] <= $existing['date_to'] && $target['date_to'] >= $existing['date_from'] ) {
				$this->db->query( 'ROLLBACK' ); return $this->fail( 'این بازه با تارگت دیگری هم‌پوشانی دارد.' );
			}
		}
		if ( $id ) {
			$has_reward = $this->db->get_var( $this->db->prepare( "SELECT id FROM {$this->ledger_entries}
				WHERE user_id = %d AND ref_type = 'visitor_target' AND ref_id = %d LIMIT 1 FOR UPDATE", $visitor_id, $id ) );
			if ( $has_reward || $this->db->last_error ) { $this->db->query( 'ROLLBACK' ); return $this->fail( 'تارگتی که سابقه ثبت پاداش دارد قابل ویرایش نیست.' ); }
			$written = $this->db->update( $this->db->usermeta, [ 'meta_value' => maybe_serialize( $target ) ], [ 'umeta_id' => $id, 'user_id' => $visitor_id ] );
		} else {
			$written = $this->db->insert( $this->db->usermeta, [ 'user_id' => $visitor_id, 'meta_key' => 'kph_visitor_sales_target', 'meta_value' => maybe_serialize( $target ) ] );
		}
		if ( $written === FALSE ) { $this->db->query( 'ROLLBACK' ); return $this->fail( 'ذخیره تارگت انجام نشد.' ); }
		$res = $this->sync_visitor_target_rewards( $visitor_id );
		$this->db->query( $res['status'] === 'success' ? 'COMMIT' : 'ROLLBACK' );
		wp_cache_delete( $visitor_id, 'user_meta' );
		return $res['status'] === 'success' ? $this->ok( 'تارگت ذخیره و پاداش محاسبه شد.' ) : $res;
	}
}
