<?php
if (!defined('ABSPATH')) { exit; }

/** Counted packaging materials share the existing raw-material batches and movement ledger. */
trait kph_supplies {
    private function supply_table(string $name): string { return $this->db_prefix.'supply_'.$name; }
    private function supply_write($result): void { if ($result === FALSE) { throw new RuntimeException('ذخیره اطلاعات ملزومات انجام نشد؛ دوباره تلاش کنید.'); } }
    private function supply_rows(string $sql): array {
        $rows=$this->db->get_results($sql,ARRAY_A);
        if ($this->db->last_error) { throw new RuntimeException('خواندن اطلاعات ملزومات انجام نشد.'); }
        return $rows?:[];
    }
    private function supply_begin_transaction(): bool {
        // Current stock must be read after waiting for its material lock, on MySQL and MariaDB snapshot isolation alike.
        return $this->db->query('SET TRANSACTION ISOLATION LEVEL READ COMMITTED')!==FALSE && $this->db->query('START TRANSACTION')!==FALSE;
    }
    private function supply_admin(): void {
        if (!get_current_user_id() || !current_user_can('manage_options')) { throw new RuntimeException('مدیریت ملزومات فقط برای مدیر مجاز است.'); }
    }
    private function supply_int($value,int $max=1000000000): int {
        if (!is_scalar($value)) { throw new RuntimeException('مقدار عددی معتبر وارد کنید.'); }
        $value=str_replace([',','٬'],'',nooshika_sanitize_numbers((string)$value));
        if (!preg_match('/^\d+$/D',$value) || strlen($value)>12 || (int)$value>$max) { throw new RuntimeException('تعداد باید عدد صحیح و نامنفی باشد.'); }
        return (int)$value;
    }
    private function supply_text($value,int $max=190): string {
        if (!is_scalar($value)) { throw new RuntimeException('متن معتبر وارد کنید.'); }
        $value=sanitize_text_field((string)$value);
        if (mb_strlen($value)>$max) { throw new RuntimeException('متن واردشده بیش از حد طولانی است.'); }
        return $value;
    }
    private function supply_micro($quantity): int { return (int)bcmul((string)$quantity,'1000000',0); }
    private function supply_decimal(int $micros): string { return bcdiv((string)$micros,'1000000',6); }
    public function supply_profiles(): array {
        return [
            'saffron_packet'=>['title'=>'زعفران پاکتی','sheet'=>15,'box'=>10,'kind'=>'packet'],
            'saffron_tin'=>['title'=>'زعفران قوطی','sheet'=>15,'box'=>10,'kind'=>'tin'],
            'cardamom_5'=>['title'=>'هل ممتاز پنج‌گرمی','sheet'=>12,'box'=>8,'kind'=>'packet'],
            'cardamom_25'=>['title'=>'هل ممتاز ۲٫۵ گرمی','sheet'=>12,'box'=>10,'kind'=>'packet'],
            'cardamom_powder'=>['title'=>'پودر هل ممتاز','sheet'=>12,'box'=>10,'kind'=>'packet'],
        ];
    }
    private function create_supply_tables(): void {
        $c='ENGINE=InnoDB '.$this->db->get_charset_collate();
        $definitions=[
            'materials'=>"raw_product_id BIGINT UNSIGNED PRIMARY KEY, kind VARCHAR(16) NOT NULL, warehouse VARCHAR(16) NOT NULL, created_at DATETIME NOT NULL",
            'rules'=>"id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, product_id BIGINT UNSIGNED NOT NULL, KEY product_id(product_id), profile VARCHAR(32) NOT NULL, unit_raw_id BIGINT UNSIGNED NOT NULL, sheet_raw_id BIGINT UNSIGNED NOT NULL, box_raw_id BIGINT UNSIGNED NOT NULL, is_active TINYINT NOT NULL DEFAULT 1, created_at DATETIME NOT NULL",
            'counters'=>"id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, raw_product_id BIGINT UNSIGNED NOT NULL, capacity INT UNSIGNED NOT NULL, units BIGINT NOT NULL DEFAULT 0, UNIQUE KEY material_capacity(raw_product_id,capacity)",
            'orders'=>"order_id BIGINT UNSIGNED PRIMARY KEY, started_at DATETIME NOT NULL",
            'usage'=>"id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, order_id BIGINT UNSIGNED NOT NULL, product_id BIGINT UNSIGNED NOT NULL, rule_id BIGINT UNSIGNED NOT NULL, unit_counter_id BIGINT UNSIGNED NOT NULL, sheet_counter_id BIGINT UNSIGNED NOT NULL, box_counter_id BIGINT UNSIGNED NOT NULL, units BIGINT NOT NULL DEFAULT 0, UNIQUE KEY order_product(order_id,product_id)",
            'allocations'=>"id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, counter_id BIGINT UNSIGNED NOT NULL, batch_id BIGINT UNSIGNED NOT NULL, micros BIGINT NOT NULL DEFAULT 0, UNIQUE KEY counter_batch(counter_id,batch_id)",
            'events'=>"id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, order_id BIGINT UNSIGNED NOT NULL DEFAULT 0, raw_product_id BIGINT UNSIGNED NOT NULL, counter_id BIGINT UNSIGNED NOT NULL DEFAULT 0, unit_delta BIGINT NOT NULL DEFAULT 0, quantity_delta DECIMAL(18,6) NOT NULL DEFAULT 0, actor_id BIGINT UNSIGNED NOT NULL, note TEXT NULL, created_at DATETIME NOT NULL, KEY material_time(raw_product_id,id), KEY order_id(order_id)",
        ];
        foreach($definitions as $name=>$fields){$table=$this->supply_table($name);maybe_create_table($table,"CREATE TABLE $table ($fields) $c");}
    }
    private function supply_required_tables(): array {
        $names=['orders','order_items','orders_meta','order_items_meta','fulfillments','fulfillment_items','fulfillments_meta','fulfillment_items_meta','ledger_entries','ledger_entry_meta','inventory_balance','inventory_log','batches','storage_moves','raw_products'];
        $tables=array_map(fn($n)=>$this->db_prefix.$n,$names);
        foreach(['materials','rules','counters','orders','usage','allocations','events'] as $n)$tables[]=$this->supply_table($n);
        return $tables;
    }
    public function supplies_ready(): bool {
        foreach($this->supply_required_tables() as $table){$r=$this->db->get_row($this->db->prepare('SHOW TABLE STATUS LIKE %s',$this->db->esc_like($table)),ARRAY_A);if(!$r||strcasecmp((string)$r['Engine'],'InnoDB'))return FALSE;}
        return TRUE;
    }
    public function prepare_supplies(array $data=[]): array {
        try{$this->supply_admin();$map=$this->supply_warehouses();foreach(['print','tin'] as $w){if(isset($data[$w.'_category_id']))$map[$w]=$this->supply_int($data[$w.'_category_id']);if(empty($map[$w])||!$this->db->get_var($this->db->prepare("SELECT id FROM {$this->raw_categories} WHERE id=%d AND is_active=1",$map[$w])))throw new RuntimeException('دستهٔ مخزن چاپ و قوطی را انتخاب کنید.');}if($map['print']===$map['tin'])throw new RuntimeException('مخزن چاپ و قوطی باید جدا باشند.');foreach($this->supplies_materials() as $m)if((int)$m['category_id']!==$map[$m['warehouse']])throw new RuntimeException('تغییر دستهٔ مخزنِ دارای ملزومات ثبت‌شده مجاز نیست.');foreach($this->supply_required_tables() as $table){$r=$this->db->get_row($this->db->prepare('SHOW TABLE STATUS LIKE %s',$this->db->esc_like($table)),ARRAY_A);if(!$r)throw new RuntimeException('جدول مورد نیاز یافت نشد: '.$table);if(strcasecmp((string)$r['Engine'],'InnoDB'))$this->supply_write($this->db->query("ALTER TABLE `$table` ENGINE=InnoDB"));}update_option('kph_supply_warehouses',$map,FALSE);if(get_option('kph_supply_warehouses',[])!==$map)throw new RuntimeException('ذخیرهٔ دسته‌های مخزن انجام نشد.');return $this->ok('انبار ملزومات آماده شد. اکنون اقلام و فرمول محصولات را تعریف کنید.');}catch(Throwable $e){return $this->fail($e->getMessage());}
    }
    private function supply_need_ready(): void {if(!$this->supplies_ready())throw new RuntimeException('در صفحه «ملزومات بسته‌بندی»، دکمه «آماده‌سازی انبار» را بزنید.');}
    public function supply_warehouses(): array {
        $map=get_option('kph_supply_warehouses',[]);if(is_array($map)&&!empty($map['print'])&&!empty($map['tin']))return ['print'=>(int)$map['print'],'tin'=>(int)$map['tin']];
        $map=['print'=>0,'tin'=>0];foreach($this->supplies_categories() as $r){if(trim($r['title'])==='چاپ')$map['print']=(int)$r['id'];if(trim($r['title'])==='قوطی')$map['tin']=(int)$r['id'];}return $map;
    }
    public function supplies_categories(): array {
        return $this->supply_rows("SELECT id,title FROM {$this->raw_categories} WHERE is_active=1 ORDER BY sort_order,id");
    }
    public function supplies_is_category(int $id): bool {
        return (bool)$this->db->get_var($this->db->prepare('SELECT 1 FROM '.$this->supply_table('materials')." m INNER JOIN {$this->raw_products} r ON r.id=m.raw_product_id WHERE r.category_id=%d LIMIT 1",$id));
    }
    /** Categories reserved for counted packaging supplies, independent of site-specific IDs. */
    public function supply_category_ids(): array {
        $ids=array_values($this->supply_warehouses());
        $ids=array_merge($ids,$this->db->get_col("SELECT id FROM {$this->raw_categories} WHERE TRIM(title) IN ('چاپ','قوطی','مخزن چاپ','مخزن قوطی')") ?: []);
        return array_values(array_unique(array_filter(array_map('intval',$ids))));
    }
    public function ordinary_raw_condition(string $alias='rp'): string {
        if(!preg_match('/^[a-z][a-z0-9_]*$/iD',$alias))throw new InvalidArgumentException('Invalid SQL alias');
        $ids=$this->supply_category_ids();
        $category=$ids ? "$alias.category_id NOT IN (".implode(',',$ids).") AND " : '';
        return $category."NOT EXISTS (SELECT 1 FROM ".$this->supply_table('materials')." excluded_supply WHERE excluded_supply.raw_product_id=$alias.id)";
    }
    public function is_supply_raw_product(int $id): bool {
        $ordinary=$this->ordinary_raw_condition('rp');
        return (bool)$this->db->get_var($this->db->prepare("SELECT rp.id FROM {$this->raw_products} rp WHERE rp.id=%d AND NOT ($ordinary)",$id));
    }
    private function supply_lock_material(int $id): array {
        $r=$this->supply_rows($this->db->prepare("SELECT r.*,m.kind,m.warehouse FROM {$this->raw_products} r INNER JOIN ".$this->supply_table('materials')." m ON m.raw_product_id=r.id WHERE r.id=%d FOR UPDATE",$id));
        if(!$r)throw new RuntimeException('قلم ملزومات پیدا نشد.');$map=$this->supply_warehouses();if((int)$r[0]['category_id']!==($map[$r[0]['warehouse']]??0))throw new RuntimeException('دستهٔ قلم ملزومات تغییر کرده و باید بررسی شود.');return $r[0];
    }
    private function supply_batches(int $raw_id,bool $lock=FALSE): array {
        $rows=$this->supply_rows($this->db->prepare("SELECT id,unit_cost FROM {$this->batches} WHERE raw_product_id=%d ORDER BY created_at,id".($lock?' FOR UPDATE':''),$raw_id));
        foreach($rows as &$r){if($lock){$moves=$this->supply_rows($this->db->prepare("SELECT direction,qty_weight FROM {$this->storage_moves} WHERE batch_id=%d FOR UPDATE",(int)$r['id']));$r['micros']=0;foreach($moves as $m)$r['micros']+=($m['direction']==='in'?1:-1)*$this->supply_micro($m['qty_weight']);}else{$q=$this->supply_rows($this->db->prepare("SELECT COALESCE(SUM(CASE WHEN direction='in' THEN qty_weight ELSE -qty_weight END),0) AS qty FROM {$this->storage_moves} WHERE batch_id=%d",(int)$r['id']));$r['micros']=$this->supply_micro($q[0]['qty']);}}unset($r);return $rows;
    }
    public function supply_stock(int $raw_id,bool $lock=FALSE): string {return $this->supply_decimal(array_sum(array_column($this->supply_batches($raw_id,$lock),'micros')));}
    public function supplies_materials(): array {
        $rows=$this->supply_rows("SELECT r.id,r.title,r.category_id,r.code,r.is_active,m.kind,m.warehouse FROM {$this->raw_products} r INNER JOIN ".$this->supply_table('materials')." m ON m.raw_product_id=r.id ORDER BY m.warehouse,r.title,r.id");
        foreach($rows as &$r)$r['stock']=$this->supply_stock((int)$r['id']);unset($r);return $rows;
    }
    private function supply_event(int $raw_id,int $counter,int $order,int $unit_delta,int $micros,string $note): int {
        $this->supply_write($this->db->insert($this->supply_table('events'),['order_id'=>$order,'raw_product_id'=>$raw_id,'counter_id'=>$counter,'unit_delta'=>$unit_delta,'quantity_delta'=>$this->supply_decimal($micros),'actor_id'=>get_current_user_id(),'note'=>$note,'created_at'=>$this->now()]));return (int)$this->db->insert_id;
    }
    private function supply_movement(int $batch,int $micros,string $cost,int $event,string $note): void {
        if(!$micros)return;
        $this->supply_write($this->db->insert($this->storage_moves,['batch_id'=>$batch,'direction'=>$micros>0?'out':'in','reason'=>'adjustment','qty_weight'=>$this->supply_decimal(abs($micros)),'unit_cost_at_move'=>$cost,'ref_type'=>'packaging_supplies','ref_id'=>$event,'note'=>$note,'created_at'=>$this->now()]));
    }
    private function supply_take(int $raw_id,int $micros,int $event,string $note,int $counter=0): void {
        $batches=$this->supply_batches($raw_id,TRUE);$available=0;
        foreach($batches as $b){if($b['micros']<0)throw new RuntimeException('یکی از ورودی‌های ملزومات موجودی منفی دارد؛ گردش آن را بررسی کنید.');$available+=$b['micros'];}
        if($available<$micros){$title=$this->db->get_var($this->db->prepare("SELECT title FROM {$this->raw_products} WHERE id=%d",$raw_id));throw new RuntimeException('موجودی «'.$title.'» کافی نیست؛ مورد نیاز '.$this->supply_decimal($micros).'، موجودی '.$this->supply_decimal($available).'.');}
        foreach($batches as $b){$take=min($micros,$b['micros']);if(!$take)continue;$this->supply_movement((int)$b['id'],$take,(string)$b['unit_cost'],$event,$note);
            if($counter){$a=$this->supply_rows($this->db->prepare('SELECT * FROM '.$this->supply_table('allocations').' WHERE counter_id=%d AND batch_id=%d FOR UPDATE',$counter,(int)$b['id']));if($a)$this->supply_write($this->db->update($this->supply_table('allocations'),['micros'=>(int)$a[0]['micros']+$take],['id'=>$a[0]['id']]));else $this->supply_write($this->db->insert($this->supply_table('allocations'),['counter_id'=>$counter,'batch_id'=>$b['id'],'micros'=>$take]));}
            $micros-=$take;if(!$micros)break;
        }
    }
    private function supply_return(int $counter,int $micros,int $event,string $note): void {
        $rows=$this->supply_rows($this->db->prepare('SELECT a.*,b.unit_cost FROM '.$this->supply_table('allocations')." a INNER JOIN {$this->batches} b ON b.id=a.batch_id WHERE a.counter_id=%d AND a.micros>0 ORDER BY a.id DESC FOR UPDATE",$counter));
        foreach($rows as $r){$take=min($micros,(int)$r['micros']);$this->supply_movement((int)$r['batch_id'],-$take,(string)$r['unit_cost'],$event,$note);$this->supply_write($this->db->update($this->supply_table('allocations'),['micros'=>(int)$r['micros']-$take],['id'=>$r['id']]));$micros-=$take;if(!$micros)break;}
        if($micros)throw new RuntimeException('سابقه مصرف ملزومات با برگشت تطبیق ندارد.');
    }
    public function save_supply_material(array $data): array {
        try{$this->supply_admin();$this->supply_need_ready();$raw=$this->supply_int($data['raw_product_id']??0);$kind=$this->supply_text($data['kind']??'');$warehouse=$this->supply_text($data['warehouse']??'');
            if(!in_array($kind,['packet','sheet','box','tin','other'],TRUE)||!in_array($warehouse,['print','tin'],TRUE)||($kind==='tin'&&$warehouse!=='tin'))throw new RuntimeException('نوع قلم یا مخزن معتبر نیست.');
            $category=$this->supply_int($data['category_id']??0);$map=$this->supply_warehouses();if($category!==($map[$warehouse]??0))throw new RuntimeException('قلم باید از دستهٔ همان مخزن انتخاب شود.');if(!$category||!$this->db->get_var($this->db->prepare("SELECT id FROM {$this->raw_categories} WHERE id=%d AND is_active=1",$category)))throw new RuntimeException('دستهٔ مخزن را انتخاب کنید.');
            $this->supply_write($this->supply_begin_transaction());
            if(!$raw){$title=$this->supply_text($data['title']??'');if($title==='')throw new RuntimeException('نام قلم را وارد کنید.');$res=$this->add_raw_product(['category_id'=>$category,'title'=>$title,'code'=>$this->supply_text($data['code']??'')?:NULL,'base_uom'=>'count']);if($res['status']!=='success')throw new RuntimeException($res['message']);$raw=(int)$res['data']['id'];}
            $row=$this->supply_rows($this->db->prepare("SELECT * FROM {$this->raw_products} WHERE id=%d FOR UPDATE",$raw));if(!$row||!(int)$row[0]['is_active']||(int)$row[0]['category_id']!==$category)throw new RuntimeException('قلم انتخاب‌شده با مخزن همخوان نیست.');
            $exists=$this->supply_rows($this->db->prepare('SELECT * FROM '.$this->supply_table('materials').' WHERE raw_product_id=%d FOR UPDATE',$raw));
            if($exists){if($exists[0]['kind']!==$kind||$exists[0]['warehouse']!==$warehouse)throw new RuntimeException('این قلم قبلاً با نوع دیگری ثبت شده است؛ برای مدل جدید قلم جدا بسازید.');}
            else $this->supply_write($this->db->insert($this->supply_table('materials'),['raw_product_id'=>$raw,'kind'=>$kind,'warehouse'=>$warehouse,'created_at'=>$this->now()]));
            $this->supply_write($this->db->update($this->raw_products,['base_uom'=>'count'],['id'=>$raw]));
            $this->supply_write($this->db->query('COMMIT'));return $this->ok('قلم به فهرست ملزومات اضافه شد؛ اکنون موجودی واقعی آن را ثبت کنید.',['raw_product_id'=>$raw]);
        }catch(Throwable $e){$this->db->query('ROLLBACK');return $this->fail($e->getMessage());}
    }
    public function supply_stocktake(array $data): array {
        try{$this->supply_admin();$this->supply_need_ready();$id=$this->supply_int($data['raw_product_id']??0);$count=$this->supply_int($data['count']??'');$expected=$data['expected']??NULL;
            if(!is_string($expected)||!preg_match('/^\d+(?:\.\d{1,6})?$/D',$expected))throw new RuntimeException('صفحه را تازه کنید و موجودی را دوباره وارد کنید.');
            $note=$this->supply_text($data['note']??'',500);if($note==='')throw new RuntimeException('بابت اصلاح موجودی توضیح کوتاه بنویسید.');
            $this->supply_write($this->supply_begin_transaction());$this->supply_lock_material($id);$old=$this->supply_micro($this->supply_stock($id,TRUE));
            if($old!==$this->supply_micro($expected))throw new RuntimeException('موجودی از زمان بازکردن فرم تغییر کرده؛ صفحه را تازه کنید.');
            $target=$count*1000000;$delta=$target-$old;
            if($delta){$event=$this->supply_event($id,0,0,0,-$delta,'شمارش موجودی: '.$this->supply_decimal($old).' ← '.$count.'؛ '.$note);
                if($delta<0)$this->supply_take($id,-$delta,$event,'اصلاح شمارش ملزومات؛ '.$note);
                else{$batches=$this->supply_batches($id,TRUE);$cost='0';$value='0';$q=0;foreach($batches as $b){if($b['micros']>0){$value=bcadd($value,bcmul((string)$b['micros'],(string)$b['unit_cost'],2),2);$q+=$b['micros'];}}if($q)$cost=bcdiv($value,(string)$q,2);
                    $this->supply_write($this->db->insert($this->batches,['raw_product_id'=>$id,'source_type'=>'manual','source_id'=>$event,'initial_qty_weight'=>$this->supply_decimal($delta),'unit_cost'=>$cost,'created_at'=>$this->now()]));$batch=(int)$this->db->insert_id;$this->supply_movement($batch,-$delta,$cost,$event,'افزایش شمارش ملزومات؛ '.$note);
                }
            }
            $this->supply_write($this->db->query('COMMIT'));return $this->ok('موجودی شمارش‌شده ثبت شد.');
        }catch(Throwable $e){$this->db->query('ROLLBACK');return $this->fail($e->getMessage());}
    }
    public function save_supply_rule(array $data): array {
        try{$this->supply_admin();$this->supply_need_ready();$product=$this->supply_int($data['product_id']??0);$post=get_post($product);if(!$post||$post->post_type!=='product'||$post->post_status!=='publish')throw new RuntimeException('محصول فروش را انتخاب کنید.');
            $profile=$this->supply_text($data['profile']??'');$profiles=$this->supply_profiles();if(!isset($profiles[$profile]))throw new RuntimeException('مدل بسته‌بندی را انتخاب کنید.');
            $ids=[$this->supply_int($data['unit_raw_id']??0),$this->supply_int($data['sheet_raw_id']??0),$this->supply_int($data['box_raw_id']??0)];if(count(array_unique($ids))!==3||in_array(0,$ids,TRUE))throw new RuntimeException('پاکت یا قوطی، ورق و باکس را جداگانه انتخاب کنید.');
            $active=($data['is_active']??'1')==='1'?1:0;$this->supply_write($this->supply_begin_transaction());
            $sorted=$ids;sort($sorted,SORT_NUMERIC);$m=[];foreach($sorted as $id)$m[$id]=$this->supply_lock_material($id);
            foreach([$profiles[$profile]['kind'],'sheet','box'] as $i=>$kind)if($m[$ids[$i]]['kind']!==$kind)throw new RuntimeException('نوع ملزومات انتخاب‌شده با مدل بسته‌بندی مطابقت ندارد.');
            $this->supply_counter($ids[0],1,TRUE);$this->supply_counter($ids[1],(int)$profiles[$profile]['sheet'],TRUE);$this->supply_counter($ids[2],(int)$profiles[$profile]['sheet']*(int)$profiles[$profile]['box'],TRUE);
            $table=$this->supply_table('rules');$old=$this->supply_rows($this->db->prepare("SELECT * FROM $table WHERE product_id=%d ORDER BY id DESC LIMIT 1 FOR UPDATE",$product));$fields=['product_id'=>$product,'profile'=>$profile,'unit_raw_id'=>$ids[0],'sheet_raw_id'=>$ids[1],'box_raw_id'=>$ids[2],'is_active'=>$active];
            if($old){$changed=FALSE;foreach(['profile','unit_raw_id','sheet_raw_id','box_raw_id'] as $k)$changed=$changed||((string)$old[0][$k]!== (string)$fields[$k]);$used=$this->supply_rows($this->db->prepare('SELECT id FROM '.$this->supply_table('usage').' WHERE rule_id=%d LIMIT 1',$old[0]['id']));if($changed&&$used){$this->supply_write($this->db->update($table,['is_active'=>0],['id'=>$old[0]['id']]));$fields['created_at']=$this->now();$this->supply_write($this->db->insert($table,$fields));}else $this->supply_write($this->db->update($table,$fields,['id'=>$old[0]['id']]));}
            else{$fields['created_at']=$this->now();$this->supply_write($this->db->insert($table,$fields));}
            $this->supply_write($this->db->query('COMMIT'));return $this->ok('فرمول ذخیره شد؛ از تأیید سفارش‌های بعدی اعمال می‌شود.');
        }catch(Throwable $e){$this->db->query('ROLLBACK');return $this->fail($e->getMessage());}
    }
    public function supplies_rules(): array {return $this->supply_rows('SELECT r.*,p.post_title FROM '.$this->supply_table('rules')." r LEFT JOIN {$this->db->posts} p ON p.ID=r.product_id WHERE NOT EXISTS (SELECT 1 FROM ".$this->supply_table('rules')." r2 WHERE r2.product_id=r.product_id AND r2.id>r.id) ORDER BY p.post_title,r.id");}
    public function supplies_carry(): array {return $this->supply_rows('SELECT c.*,p.title,MOD(c.units,c.capacity) AS pending_units,FLOOR(c.units/c.capacity) AS full_units FROM '.$this->supply_table('counters')." c INNER JOIN {$this->raw_products} p ON p.id=c.raw_product_id WHERE c.capacity>1 ORDER BY p.title,c.capacity");}
    public function supplies_events(int $page=1,int $raw=0): array {
        $where=$raw>0?$this->db->prepare(' WHERE e.raw_product_id=%d',$raw):'';$offset=(max(1,$page)-1)*30;
        $rows=$this->supply_rows('SELECT e.*,p.title FROM '.$this->supply_table('events')." e LEFT JOIN {$this->raw_products} p ON p.id=e.raw_product_id $where ORDER BY e.id DESC LIMIT 30 OFFSET $offset");
        $n=(int)$this->db->get_var('SELECT COUNT(*) FROM '.$this->supply_table('events').' e'.$where);return ['items'=>$rows,'total'=>$n,'pages'=>(int)ceil($n/30)];
    }
    private function supply_counter(int $raw,int $capacity,bool $create=FALSE): int {
        $t=$this->supply_table('counters');
        $rows=$this->supply_rows($this->db->prepare("SELECT id FROM $t WHERE raw_product_id=%d AND capacity=%d FOR UPDATE",$raw,$capacity));
        if($rows)return (int)$rows[0]['id'];
        if(!$create)throw new RuntimeException('شمارندهٔ مصرف پیدا نشد؛ مدیر فرمول محصول را دوباره ذخیره کند.');
        $this->supply_write($this->db->insert($t,['raw_product_id'=>$raw,'capacity'=>$capacity,'units'=>0]));return (int)$this->db->insert_id;
    }
    private function supply_tracked(int $order): bool {return (bool)$this->supply_rows($this->db->prepare('SELECT order_id FROM '.$this->supply_table('orders').' WHERE order_id=%d',$order));}
    private function supply_has_active_rules(): bool {return (bool)$this->supply_rows('SELECT id FROM '.$this->supply_table('rules').' WHERE is_active=1 LIMIT 1');}
    private function supply_order_guard(int $order,bool $start=FALSE): array {
        try{if($this->supply_tracked($order)||($start&&$this->supply_has_active_rules()))$this->supply_need_ready();return $this->ok();}catch(Throwable $e){return $this->fail($e->getMessage());}
    }
    /** Called ONLY inside the order mutation's existing transaction. Never starts or commits one. */
    private function sync_order_supplies(int $order_id,bool $start=FALSE): array {
        try{
            $tracked=$this->supply_tracked($order_id);if(!$tracked&&!$start)return $this->ok();
            if(!$tracked&&!$this->supply_has_active_rules())return $this->ok();
            $this->supply_need_ready();$order=$this->supply_rows($this->db->prepare("SELECT * FROM {$this->orders} WHERE id=%d FOR UPDATE",$order_id));if(!$order)throw new RuntimeException('سفارش ملزومات پیدا نشد.');$order=$order[0];
            if(!$tracked)$this->supply_write($this->db->insert($this->supply_table('orders'),['order_id'=>$order_id,'started_at'=>$this->now()]));
            $active=in_array($order['status'],['registered','shortage','shipped'],TRUE);
            $items=$this->supply_rows($this->db->prepare("SELECT wc_product_id,SUM(qty_ordered+expected_free_qty) AS planned,SUM(shipped_paid_qty+shipped_free_qty) AS shipped FROM {$this->order_items} WHERE order_id=%d GROUP BY wc_product_id",$order_id));$targets=[];
            foreach($items as $i)$targets[(int)$i['wc_product_id']]=max(0,(int)$i[$active?'planned':'shipped']);
            $usage=$this->supply_rows($this->db->prepare('SELECT * FROM '.$this->supply_table('usage').' WHERE order_id=%d ORDER BY product_id',$order_id));$byProduct=[];foreach($usage as $u)$byProduct[(int)$u['product_id']]=$u;
            $products=array_unique(array_merge(array_keys($targets),array_keys($byProduct)));sort($products,SORT_NUMERIC);$plans=[];$materialIds=[];
            foreach($products as $product){$target=$targets[$product]??0;$u=$byProduct[$product]??NULL;
                if($u){$rule=$this->supply_rows($this->db->prepare('SELECT * FROM '.$this->supply_table('rules').' WHERE id=%d',$u['rule_id']));if(!$rule)throw new RuntimeException('فرمول سابقه مصرف پیدا نشد.');$rule=$rule[0];}
                else{if(!$target)continue;$rule=$this->supply_rows($this->db->prepare('SELECT * FROM '.$this->supply_table('rules').' WHERE product_id=%d AND is_active=1 ORDER BY id DESC LIMIT 1',$product));if(!$rule)continue;$rule=$rule[0];}
                $delta=$target-(int)($u['units']??0);if(!$delta&&$u)continue;
                $plans[]=compact('product','target','u','rule','delta');foreach(['unit_raw_id','sheet_raw_id','box_raw_id'] as $key)$materialIds[]=(int)$rule[$key];
            }
            $materialIds=array_unique($materialIds);sort($materialIds,SORT_NUMERIC);foreach($materialIds as $raw)$this->supply_lock_material($raw);
            $counterDelta=[];$counterRaw=[];$updates=[];
            foreach($plans as $plan){extract($plan);$profile=$this->supply_profiles()[$rule['profile']];
                if(!$u){$u=['order_id'=>$order_id,'product_id'=>$product,'rule_id'=>$rule['id'],'units'=>0,'unit_counter_id'=>$this->supply_counter((int)$rule['unit_raw_id'],1),'sheet_counter_id'=>$this->supply_counter((int)$rule['sheet_raw_id'],(int)$profile['sheet']),'box_counter_id'=>$this->supply_counter((int)$rule['box_raw_id'],(int)$profile['sheet']*(int)$profile['box'])];$this->supply_write($this->db->insert($this->supply_table('usage'),$u));$u['id']=(int)$this->db->insert_id;}
                foreach(['unit_counter_id'=>'unit_raw_id','sheet_counter_id'=>'sheet_raw_id','box_counter_id'=>'box_raw_id'] as $ck=>$rk){$cid=(int)$u[$ck];$counterDelta[$cid]=($counterDelta[$cid]??0)+$delta;$counterRaw[$cid]=(int)$rule[$rk];}
                $updates[]=['id'=>$u['id'],'units'=>$target];
            }
            ksort($counterDelta,SORT_NUMERIC);$work=[];
            foreach($counterDelta as $id=>$delta){if(!$delta)continue;$row=$this->supply_rows($this->db->prepare('SELECT * FROM '.$this->supply_table('counters').' WHERE id=%d FOR UPDATE',$id));if(!$row)throw new RuntimeException('شمارنده ملزومات پیدا نشد.');$row=$row[0];$new=(int)$row['units']+$delta;if($new<0||$new>1000000000000)throw new RuntimeException('جمع مصرف ملزومات معتبر نیست.');$quantity=intdiv($new,(int)$row['capacity'])-intdiv((int)$row['units'],(int)$row['capacity']);$work[]=[$row,$delta,$new,$quantity];}
            // Release canceled quantities first, then allocate increases. Material locks are held in sorted order.
            usort($work,fn($a,$b)=>($a[3]<=>0)<=>($b[3]<=>0));
            foreach($work as [$counter,$delta,$new,$quantity]){$raw=(int)$counter['raw_product_id'];$note=($delta>0?'مصرف بابت تأیید/ویرایش سفارش #':'برگشت بابت کاهش/لغو سفارش #').$order_id;$event=$this->supply_event($raw,(int)$counter['id'],$order_id,$delta,$quantity*1000000,$note);
                if($quantity>0)$this->supply_take($raw,$quantity*1000000,$event,$note,(int)$counter['id']);elseif($quantity<0)$this->supply_return((int)$counter['id'],-$quantity*1000000,$event,$note);
                $this->supply_write($this->db->update($this->supply_table('counters'),['units'=>$new],['id'=>$counter['id']]));
            }
            foreach($updates as $u)$this->supply_write($this->db->update($this->supply_table('usage'),['units'=>$u['units']],['id'=>$u['id']]));
            return $this->ok();
        }catch(Throwable $e){return $this->fail($e->getMessage());}
    }
}
