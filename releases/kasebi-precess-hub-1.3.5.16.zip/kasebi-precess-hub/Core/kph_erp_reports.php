<?php
if (!defined('ABSPATH')) { exit; }

/** Operational reports: existing accounting remains the financial source of truth. */
class kph_erp_reports {
    private wpdb $d;
    private kph_db $core;
    private string $p;
    public function __construct(?kph_db $core = NULL) {
        global $wpdb;
        $this->d = $wpdb; $this->p = $wpdb->prefix.'kph_'; $this->core = $core ?: new kph_db();
    }
    private function guard(): void {
        if (!get_current_user_id() || !current_user_can('manage_options')) { throw new RuntimeException('دسترسی به داشبورد مدیریتی مجاز نیست.'); }
    }
    private function rows(string $sql): array {
        $r = $this->d->get_results($sql, ARRAY_A);
        if ($this->d->last_error) { throw new RuntimeException('خواندن اطلاعات گزارش انجام نشد؛ صفحه را تازه کنید.'); }
        return $r ?: [];
    }
    private function write($r): void { if ($r === FALSE) { throw new RuntimeException('ذخیره اطلاعات انجام نشد؛ دوباره تلاش کنید.'); } }
    private function text($v, int $max = 190): string {
        if (!is_scalar($v)) { throw new RuntimeException('ساختار متن معتبر نیست.'); }
        $v = trim(sanitize_textarea_field((string)$v));
        if (mb_strlen($v) > $max) { throw new RuntimeException('متن واردشده بیش از حد طولانی است.'); }
        return $v;
    }
    private function number($v, bool $decimal = FALSE): float {
        $v = str_replace([',','٬'], '', nooshika_sanitize_numbers($this->text($v, 30)));
        if (!preg_match($decimal ? '/^\d+(?:\.\d{1,6})?$/D' : '/^\d+$/D', $v) || (float)$v > 100000000000000) { throw new RuntimeException('مبلغ یا تعداد معتبر و نامنفی وارد کنید.'); }
        return (float)$v;
    }
    public function date($v, bool $optional = FALSE): string {
        $v = str_replace('/', '-', nooshika_sanitize_numbers($this->text($v, 12)));
        if ($optional && $v === '') { return ''; }
        if (!preg_match('/^(\d{4})-(\d{1,2})-(\d{1,2})$/D', $v, $m)) { throw new RuntimeException('تاریخ را به صورت سال/ماه/روز وارد کنید.'); }
        $year = (int)$m[1]; $month = (int)$m[2]; $day = (int)$m[3];
        if ($year < 1700) {
            if ($year < 1300 || $year > 1499 || $month < 1 || $month > 12 || $day < 1 || $day > ($month <= 6 ? 31 : 30)) { throw new RuntimeException('تاریخ شمسی معتبر نیست.'); }
            if ($month === 12) {
                $start = new DateTimeImmutable(nooshika_jalali_to_gregorian($year.'-01-01'), wp_timezone());
                $end = new DateTimeImmutable(nooshika_jalali_to_gregorian(($year+1).'-01-01'), wp_timezone());
                if ($day > ((int)$start->diff($end)->format('%a') === 366 ? 30 : 29)) { throw new RuntimeException('تاریخ شمسی معتبر نیست.'); }
            }
            $v = nooshika_jalali_to_gregorian(sprintf('%04d-%02d-%02d', $year, $month, $day));
        } else { $v = sprintf('%04d-%02d-%02d', $year, $month, $day); }
        $parsed = DateTimeImmutable::createFromFormat('!Y-m-d', $v, wp_timezone());
        if (!$parsed || $parsed->format('Y-m-d') !== $v || $v < '1900-01-01' || $v > '2200-12-31') { throw new RuntimeException('تاریخ معتبر نیست.'); }
        return $v;
    }
    public function display_date(string $date): string {
        if (!$date) { return '—'; }
        [$gy,$gm,$gd]=array_map('intval',explode('-',substr($date,0,10)));
        $monthDays=[0,31,59,90,120,151,181,212,243,273,304,334]; $gy2=$gm>2?$gy+1:$gy;
        $days=355666+365*$gy+intdiv($gy2+3,4)-intdiv($gy2+99,100)+intdiv($gy2+399,400)+$gd+$monthDays[$gm-1];
        $jy=-1595+33*intdiv($days,12053); $days%=12053; $jy+=4*intdiv($days,1461); $days%=1461;
        if ($days>365) { $jy+=intdiv($days-1,365); $days=($days-1)%365; }
        $jm=$days<186?1+intdiv($days,31):7+intdiv($days-186,30); $jd=1+($days<186?$days%31:($days-186)%30);
        return sprintf('%04d/%02d/%02d',$jy,$jm,$jd);
    }
    private function today(): string { return substr(current_time('mysql'), 0, 10); }
    public function install(): void {
        $this->guard(); $c = 'ENGINE=InnoDB '.$this->d->get_charset_collate();
        $tables = [
            'control' => 'id INT PRIMARY KEY, payload LONGTEXT NOT NULL',
            'tasks' => "id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, title VARCHAR(190) NOT NULL, department VARCHAR(100) NOT NULL, assignee BIGINT UNSIGNED NOT NULL DEFAULT 0, kind VARCHAR(16) NOT NULL DEFAULT 'task', priority VARCHAR(16) NOT NULL DEFAULT 'normal', status VARCHAR(16) NOT NULL DEFAULT 'open', due_on DATE NOT NULL, started_at DATETIME NOT NULL, completed_at DATETIME NULL, version INT UNSIGNED NOT NULL DEFAULT 1, created_by BIGINT UNSIGNED NOT NULL, created_at DATETIME NOT NULL, updated_at DATETIME NOT NULL, KEY due_status(status,due_on), KEY department(department)",
            'leads' => "id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, title VARCHAR(190) NOT NULL, customer_id BIGINT UNSIGNED NOT NULL DEFAULT 0, owner_id BIGINT UNSIGNED NOT NULL DEFAULT 0, stage VARCHAR(16) NOT NULL DEFAULT 'open', order_id BIGINT UNSIGNED NULL UNIQUE, version INT UNSIGNED NOT NULL DEFAULT 1, created_at DATETIME NOT NULL, updated_at DATETIME NOT NULL, KEY created_at(created_at)",
            'budgets' => 'id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, date_from DATE NOT NULL, date_to DATE NOT NULL, sales DECIMAL(18,2) NOT NULL, gross DECIMAL(18,2) NOT NULL, operating DECIMAL(18,2) NOT NULL, version INT UNSIGNED NOT NULL DEFAULT 1, KEY dates(date_from,date_to)',
            'limits' => 'resource_type VARCHAR(16) NOT NULL, resource_id BIGINT UNSIGNED NOT NULL, minimum DECIMAL(18,6) NOT NULL, target DECIMAL(18,6) NOT NULL, idle_days INT UNSIGNED NOT NULL DEFAULT 90, PRIMARY KEY(resource_type,resource_id)',
            'due_dates' => 'kind VARCHAR(16) NOT NULL, invoice_id BIGINT UNSIGNED NOT NULL, due_on DATE NOT NULL, updated_by BIGINT UNSIGNED NOT NULL, updated_at DATETIME NOT NULL, PRIMARY KEY(kind,invoice_id)',
            'purchases' => "id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, resource_type VARCHAR(16) NOT NULL, resource_id BIGINT UNSIGNED NOT NULL, quantity DECIMAL(18,6) NOT NULL, note TEXT NOT NULL, status VARCHAR(16) NOT NULL DEFAULT 'open', invoice_id BIGINT UNSIGNED NOT NULL DEFAULT 0, version INT UNSIGNED NOT NULL DEFAULT 1, created_by BIGINT UNSIGNED NOT NULL, created_at DATETIME NOT NULL, updated_at DATETIME NOT NULL, KEY resource(resource_type,resource_id,status)",
        ];
        foreach ($tables as $name=>$fields) { $this->write($this->d->query("CREATE TABLE IF NOT EXISTS {$this->p}erp_{$name} ($fields) $c")); }
        $this->write($this->d->query("INSERT IGNORE INTO {$this->p}erp_control(id,payload) VALUES(1,'{}')"));
    }
    private function begin(): void {
        $this->write($this->d->query('START TRANSACTION'));
        if (!$this->rows("SELECT id FROM {$this->p}erp_control WHERE id=1 FOR UPDATE")) { throw new RuntimeException('تنظیمات گزارش آماده نیست.'); }
    }
    private function versioned(string $table, int $id, array $data, array $in): int {
        if ($id) {
            $old = $this->rows($this->d->prepare("SELECT * FROM $table WHERE id=%d FOR UPDATE", $id));
            if (!$old || (int)$old[0]['version'] !== (int)($in['version']??0)) { throw new RuntimeException('این مورد تغییر کرده است؛ صفحه را تازه کنید.'); }
            $data['version'] = (int)$old[0]['version']+1; $this->write($this->d->update($table, $data, ['id'=>$id]));
        } else { $this->write($this->d->insert($table, $data)); $id = (int)$this->d->insert_id; }
        return $id;
    }
    public function mutate(array $in): array {
        try {
            $this->guard(); $this->install(); $op=$this->text($in['operation']??'', 30); $id=(int)$this->number($in['id']??0); $now=current_time('mysql');
            $this->begin(); $result=[];
            if ($op === 'task') {
                $title=$this->text($in['title']??''); $department=$this->text($in['department']??'', 100);
                if ($title==='' || $department==='') { throw new RuntimeException('عنوان و واحد مسئول را بنویسید.'); }
                $status=$this->text($in['status']??'open'); $kind=$this->text($in['kind']??'task'); $priority=$this->text($in['priority']??'normal');
                if (!in_array($status,['open','doing','done','canceled'],TRUE) || !in_array($kind,['task','request'],TRUE) || !in_array($priority,['normal','important'],TRUE)) { throw new RuntimeException('وضعیت وظیفه معتبر نیست.'); }
                $assignee=(int)$this->number($in['assignee']??0); if ($assignee && !get_user_by('ID',$assignee)) { throw new RuntimeException('مسئول معتبر نیست.'); }
                $old=$id ? ($this->rows($this->d->prepare("SELECT * FROM {$this->p}erp_tasks WHERE id=%d",$id))[0]??[]) : [];
                $data=['title'=>$title,'department'=>$department,'assignee'=>$assignee,'kind'=>$kind,'priority'=>$priority,'status'=>$status,'due_on'=>$this->date($in['due_on']??''),'started_at'=>$old['started_at']??$now,'completed_at'=>$status==='done'?($old['completed_at']??$now):NULL,'updated_at'=>$now];
                if (!$id) { $data+=['created_by'=>get_current_user_id(),'created_at'=>$now]; }
                $result['id']=$this->versioned($this->p.'erp_tasks',$id,$data,$in);
            } elseif ($op === 'lead') {
                $title=$this->text($in['title']??''); if ($title==='') { throw new RuntimeException('عنوان سرنخ را بنویسید.'); }
                $stage=$this->text($in['stage']??'open'); if (!in_array($stage,['open','qualified','converted','lost'],TRUE)) { throw new RuntimeException('مرحله سرنخ معتبر نیست.'); }
                $customer=(int)$this->number($in['customer_id']??0); $owner=(int)$this->number($in['owner_id']??0); $order=(int)$this->number($in['order_id']??0);
                foreach ([$customer,$owner] as $u) { if ($u && !get_user_by('ID',$u)) { throw new RuntimeException('کاربر انتخاب‌شده معتبر نیست.'); } }
                if ($order) {
                    $row=$this->rows($this->d->prepare("SELECT customer_id,status FROM {$this->p}orders WHERE id=%d",$order));
                    if (!$row || ($customer && $customer!==(int)$row[0]['customer_id'])) { throw new RuntimeException('سفارش به این مشتری تعلق ندارد.'); }
                    $customer=(int)$row[0]['customer_id'];
                    if ($this->rows($this->d->prepare("SELECT id FROM {$this->p}erp_leads WHERE order_id=%d AND id<>%d",$order,$id))) { throw new RuntimeException('این سفارش قبلاً به سرنخ دیگری متصل شده است.'); }
                    if ($stage==='converted' && !in_array($row[0]['status'],['registered','shortage','shipped'],TRUE)) { throw new RuntimeException('تبدیل موفق باید به سفارش قطعی متصل باشد.'); }
                } elseif ($stage==='converted') { throw new RuntimeException('برای تبدیل موفق، شناسه سفارش قطعی را وارد کنید.'); }
                $data=['title'=>$title,'customer_id'=>$customer,'owner_id'=>$owner,'stage'=>$stage,'order_id'=>$order?:NULL,'updated_at'=>$now]; if (!$id) { $data['created_at']=$now; }
                $result['id']=$this->versioned($this->p.'erp_leads',$id,$data,$in);
            } elseif ($op === 'budget') {
                $from=$this->date($in['date_from']??''); $to=$this->date($in['date_to']??'');
                if ($from>$to) { throw new RuntimeException('بازه بودجه معتبر نیست.'); }
                if ($this->rows($this->d->prepare("SELECT id FROM {$this->p}erp_budgets WHERE date_from<=%s AND date_to>=%s AND id<>%d",$to,$from,$id))) { throw new RuntimeException('بودجه هم‌پوشان وجود دارد؛ همان ردیف را ویرایش کنید.'); }
                $result['id']=$this->versioned($this->p.'erp_budgets',$id,['date_from'=>$from,'date_to'=>$to,'sales'=>$this->number($in['sales']??0),'gross'=>$this->number($in['gross']??0),'operating'=>$this->number($in['operating']??0)],$in);
            } elseif ($op === 'limit') {
                $type=$this->text($in['resource_type']??''); $resource=(int)$this->number($in['resource_id']??0); $this->resource($type,$resource);
                $minimum=$this->number($in['minimum']??0,TRUE); $target=$this->number($in['target']??0,TRUE); $idle=(int)$this->number($in['idle_days']??90);
                if ($target<$minimum || $idle<1 || $idle>3650 || ($type==='finished'&&((int)$minimum!=$minimum||(int)$target!=$target))) { throw new RuntimeException('هدف باید حداقل برابر حد سفارش باشد؛ کالای نهایی تعداد صحیح دارد.'); }
                $this->write($this->d->query($this->d->prepare("INSERT INTO {$this->p}erp_limits(resource_type,resource_id,minimum,target,idle_days) VALUES(%s,%d,%f,%f,%d) ON DUPLICATE KEY UPDATE minimum=VALUES(minimum),target=VALUES(target),idle_days=VALUES(idle_days)",$type,$resource,$minimum,$target,$idle)));
            } elseif ($op === 'due') {
                $kind=$this->text($in['kind']??''); $invoice=(int)$this->number($in['invoice_id']??0);
                $table=$kind==='customer'?'orders':($kind==='supplier'?'supplier_invoices':'');
                if (!$table || !$this->rows($this->d->prepare("SELECT id FROM {$this->p}{$table} WHERE id=%d",$invoice))) { throw new RuntimeException('فاکتور معتبر نیست.'); }
                $due=$this->date($in['due_on']??'',TRUE);
                if ($due==='') { $this->write($this->d->delete($this->p.'erp_due_dates',['kind'=>$kind,'invoice_id'=>$invoice])); }
                else { $this->write($this->d->query($this->d->prepare("INSERT INTO {$this->p}erp_due_dates(kind,invoice_id,due_on,updated_by,updated_at) VALUES(%s,%d,%s,%d,%s) ON DUPLICATE KEY UPDATE due_on=VALUES(due_on),updated_by=VALUES(updated_by),updated_at=VALUES(updated_at)",$kind,$invoice,$due,get_current_user_id(),$now))); }
            } elseif ($op === 'settings') {
                $selected=$in['operating_costs']??[]; if (!is_array($selected)) { throw new RuntimeException('دسته‌های هزینه معتبر نیستند.'); }
                $known=$this->cost_categories(); $keys=array_column($known,'key'); $selected=array_values(array_unique(array_map(fn($v)=>$this->text($v),$selected)));
                if (array_diff($selected,$keys)) { throw new RuntimeException('دسته هزینه انتخاب‌شده وجود ندارد.'); }
                $this->write($this->d->update($this->p.'erp_control',['payload'=>wp_json_encode(['operating_costs'=>$selected])],['id'=>1]));
            } elseif ($op === 'purchase') {
                $type=$this->text($in['resource_type']??''); $resource=(int)$this->number($in['resource_id']??0); $this->resource($type,$resource);
                $quantity=$this->number($in['quantity']??0,TRUE); if ($quantity<=0 || ($type==='finished'&&(int)$quantity!=$quantity)) { throw new RuntimeException('مقدار درخواست را صحیح و بیشتر از صفر وارد کنید.'); }
                $existing=$this->rows($this->d->prepare("SELECT id FROM {$this->p}erp_purchases WHERE resource_type=%s AND resource_id=%d AND status IN ('open','ordered') LIMIT 1",$type,$resource));
                if ($existing) { throw new RuntimeException('درخواست باز برای این قلم وجود دارد؛ درخواست #'.$existing[0]['id'].' را پیگیری کنید.'); }
                $this->write($this->d->insert($this->p.'erp_purchases',['resource_type'=>$type,'resource_id'=>$resource,'quantity'=>$quantity,'note'=>$this->text($in['note']??'',1000),'created_by'=>get_current_user_id(),'created_at'=>$now,'updated_at'=>$now])); $result['id']=(int)$this->d->insert_id;
            } elseif ($op === 'purchase_status') {
                $status=$this->text($in['status']??''); if (!in_array($status,['closed','canceled'],TRUE)) { throw new RuntimeException('وضعیت درخواست معتبر نیست.'); }
                $result['id']=$this->versioned($this->p.'erp_purchases',$id,['status'=>$status,'updated_at'=>$now],$in);
            } elseif ($op === 'purchase_invoice') {
                $result=$this->purchase_invoice($id,$in);
            } else { throw new RuntimeException('عملیات گزارش معتبر نیست.'); }
            $this->write($this->d->query('COMMIT'));
            return ['status'=>'success','message'=>$op==='purchase_invoice'?'پیش‌فاکتور خرید ساخته شد؛ تأیید و ورود موجودی از مسیر معمول انجام می‌شود.':'اطلاعات ثبت شد.','data'=>$result];
        } catch (Throwable $e) { $this->d->query('ROLLBACK'); return ['status'=>'error','message'=>$e->getMessage()]; }
    }
    private function resource(string $type,int $id): array {
        if ($type==='raw') { $rows=$this->rows($this->d->prepare("SELECT id,title,base_uom FROM {$this->p}raw_products WHERE id=%d AND is_active=1",$id)); }
        elseif ($type==='finished') { $rows=$this->rows($this->d->prepare("SELECT ID AS id,post_title AS title,'count' AS base_uom FROM {$this->d->posts} WHERE ID=%d AND post_type='product' AND post_status='publish'",$id)); }
        else { $rows=[]; }
        if (!$rows) { throw new RuntimeException('قلم موجودی معتبر نیست.'); } return $rows[0];
    }
    private function purchase_invoice(int $id,array $in): array {
        $request=$this->rows($this->d->prepare("SELECT * FROM {$this->p}erp_purchases WHERE id=%d FOR UPDATE",$id));
        if (!$request) { throw new RuntimeException('درخواست یافت نشد.'); } $request=$request[0];
        if ((int)$request['invoice_id']) { return ['invoice_id'=>(int)$request['invoice_id']]; }
        if ($request['status']!=='open'||$request['resource_type']!=='raw') { throw new RuntimeException('فقط درخواست باز مواد و ملزومات به فاکتور خرید تبدیل می‌شود.'); }
        if ((int)$request['version']!==(int)($in['version']??0)) { throw new RuntimeException('درخواست تغییر کرده؛ صفحه را تازه کنید.'); }
        $supplier=(int)$this->number($in['supplier_id']??0); $user=get_user_by('ID',$supplier);
        if (!$user || !in_array('supplier',(array)$user->roles,TRUE)) { throw new RuntimeException('تأمین‌کننده را انتخاب کنید.'); }
        $price=$this->number($in['unit_price']??0,TRUE); if ($price<=0) { throw new RuntimeException('قیمت واحد را وارد کنید.'); }
        foreach (['supplier_invoices','supplier_invoice_items','invoice_meta','invoice_item_meta'] as $name) {
            $r=$this->rows($this->d->prepare('SHOW TABLE STATUS LIKE %s',$this->d->esc_like($this->p.$name)));
            if (!$r || strcasecmp($r[0]['Engine'],'InnoDB')) { throw new RuntimeException('برای ثبت خرید، آماده‌سازی تراکنشی ابزارهای افزونه را اجرا کنید.'); }
        }
        $this->resource('raw',(int)$request['resource_id']); $now=current_time('mysql'); $number='ERP-REQ-'.$id; $total=bcmul((string)$request['quantity'],(string)$price,2);
        if ((float)$total<0.01 || (float)$total>100000000000000) { throw new RuntimeException('مبلغ درخواست بیش از حد مجاز است.'); }
        $this->write($this->d->insert($this->p.'supplier_invoices',['supplier_user_id'=>$supplier,'invoice_no'=>$number,'status'=>'proforma','issued_at'=>$now,'total_amount'=>$total,'currency'=>'IRR','note'=>'درخواست تأمین #'.$id.'؛ '.$request['note'],'created_at'=>$now])); $invoice=(int)$this->d->insert_id;
        $this->write($this->d->insert($this->p.'supplier_invoice_items',['invoice_id'=>$invoice,'raw_product_id'=>$request['resource_id'],'qty_weight'=>$request['quantity'],'unit_price'=>$price,'line_total'=>$total,'created_at'=>$now])); $item=(int)$this->d->insert_id;
        $this->write($this->d->insert($this->p.'invoice_item_meta',['invoice_item_id'=>$item,'meta_key'=>'per_unit_base','meta_value'=>(string)$price]));
        $this->write($this->d->insert($this->p.'invoice_meta',['invoice_id'=>$invoice,'meta_key'=>'erp_purchase_request_id','meta_value'=>(string)$id]));
        $this->write($this->d->update($this->p.'erp_purchases',['invoice_id'=>$invoice,'status'=>'ordered','version'=>(int)$request['version']+1,'updated_at'=>$now],['id'=>$id]));
        return ['invoice_id'=>$invoice,'supplier_id'=>$supplier];
    }
    public function settings(): array {
        $this->guard(); $r=$this->rows("SELECT payload FROM {$this->p}erp_control WHERE id=1"); $v=json_decode($r[0]['payload']??'{}',TRUE); return is_array($v)?$v:[];
    }
    public function cost_categories(): array {
        $this->guard(); $keys=[];
        foreach ((array)get_option('kph_cost_category',[]) as $key=>$item) { $keys[(string)$key]=['key'=>(string)$key,'title'=>is_array($item)?(string)($item['label']??$item['title']??$key):(string)$item]; }
        foreach ($this->rows("SELECT DISTINCT meta_value FROM {$this->p}account_transaction_meta WHERE meta_key='cost_type' AND meta_value<>''") as $r) { if (!isset($keys[$r['meta_value']])) { $keys[$r['meta_value']]=['key'=>$r['meta_value'],'title'=>$r['meta_value']]; } }
        return array_values($keys);
    }
    public function range(array $in): array {
        $today=new DateTimeImmutable($this->today(),wp_timezone()); $group=$this->text($in['group']??'day');
        if (!in_array($group,['day','week','month','year'],TRUE)) { $group='day'; }
        $from=$this->date($in['from']??'',TRUE)?:$today->modify('-29 days')->format('Y-m-d'); $to=$this->date($in['to']??'',TRUE)?:$today->format('Y-m-d');
        $start=new DateTimeImmutable($from,wp_timezone()); $end=new DateTimeImmutable($to,wp_timezone()); $days=(int)$start->diff($end)->format('%r%a')+1;
        if ($days<1 || $days>3660 || ($group==='day'&&$days>366) || ($group==='week'&&$days>1460)) { throw new RuntimeException('بازه معتبر انتخاب کنید؛ برای بازه طولانی نمایش ماهانه یا سالانه را بزنید.'); }
        return ['from'=>$from,'to'=>$to,'group'=>$group,'days'=>$days,'previous_from'=>$start->modify('-'.$days.' days')->format('Y-m-d'),'previous_to'=>$start->modify('-1 day')->format('Y-m-d')];
    }
    /** Calendar buckets use the same Persian calendar as the panel (Saturday week start). */
    private function bucket(string $date,string $group): string {
        if ($group==='day') { return $date; }
        if ($group==='week') { $d=new DateTimeImmutable($date,wp_timezone()); return $d->modify('-'.(((int)$d->format('w')+1)%7).' days')->format('Y-m-d'); }
        $j=str_replace('/','-',$this->display_date($date));
        return $group==='year'?substr($j,0,4):substr($j,0,7);
    }
    private function date_window(string $column,array $range): string { return $this->d->prepare("$column >= %s AND $column < %s",$range['from'].' 00:00:00',(new DateTimeImmutable($range['to'],wp_timezone()))->modify('+1 day')->format('Y-m-d').' 00:00:00'); }
    private function metric_rows(array $r): array {
        $w=$this->date_window('l.posted_at',$r);
        $sales=$this->rows("SELECT DATE(l.posted_at) AS day,SUM(CASE WHEN l.type='debit' THEN l.amount ELSE -l.amount END) AS amount FROM {$this->p}ledger_entries l WHERE l.entry_type IN ('customer_order','customer_order_return') AND l.ref_type='fulfillment' AND $w GROUP BY DATE(l.posted_at)");
        $w=$this->date_window('i.created_at',$r);
        $cost=$this->rows("SELECT DATE(i.created_at) AS day,-SUM(i.total_cost) AS amount FROM {$this->p}inventory_log i WHERE i.ref_type IN ('sale','return') AND $w GROUP BY DATE(i.created_at)");
        $settings=$this->settings(); $selected=$settings['operating_costs']??[]; $expenses=[];
        if ($selected) {
            $holders=implode(',',array_fill(0,count($selected),'%s')); $w=$this->date_window('t.created_at',$r);
            $expenses=$this->rows($this->d->prepare("SELECT DATE(t.created_at) AS day,SUM(CASE WHEN t.type='debit' THEN t.amount ELSE -t.amount END) AS amount FROM {$this->p}account_transactions t WHERE $w AND t.action<>'transfer_deposit' AND NOT (t.action='customer_freight_payment' AND EXISTS (SELECT 1 FROM {$this->p}account_transaction_meta freight_void WHERE freight_void.transaction_id=t.id AND freight_void.meta_key='customer_freight_voided' AND freight_void.meta_value='1')) AND NOT (t.action='shipping_freight' AND EXISTS (SELECT 1 FROM {$this->p}account_transaction_meta shipping_void WHERE shipping_void.transaction_id=t.id AND shipping_void.meta_key='shipping_voided' AND shipping_void.meta_value='1')) AND NOT (t.action='supplier_invoice_fee' AND EXISTS(SELECT 1 FROM {$this->p}account_transaction_meta supplier_void WHERE supplier_void.transaction_id=t.id AND supplier_void.meta_key='supplier_invoice_voided' AND supplier_void.meta_value='1')) AND (SELECT m.meta_value FROM {$this->p}account_transaction_meta m WHERE m.transaction_id=t.id AND m.meta_key='cost_type' ORDER BY m.id DESC LIMIT 1) IN ($holders) GROUP BY DATE(t.created_at)",$selected));
        }
        $daily=[]; foreach (['sales'=>$sales,'cogs'=>$cost,'expenses'=>$expenses] as $key=>$rows) { foreach ($rows as $row) { $daily[$row['day']][$key]=(float)$row['amount']; } }
        return ['daily'=>$daily,'operating_ready'=>(bool)$selected];
    }
    public function sales(array $r): array {
        $this->guard(); $current=$this->metric_rows($r); $prevRange=['from'=>$r['previous_from'],'to'=>$r['previous_to']]; $previous=$this->metric_rows($prevRange);
        $budgets=$this->rows($this->d->prepare("SELECT * FROM {$this->p}erp_budgets WHERE date_from<=%s AND date_to>=%s",$r['to'],$r['from']));
        $points=[]; $cursor=new DateTimeImmutable($r['from'],wp_timezone()); $end=new DateTimeImmutable($r['to'],wp_timezone());
        $keys=['sales','gross','operating','previous_sales','previous_gross','previous_operating','budget_sales','budget_gross','budget_operating'];
        while ($cursor<=$end) {
            $day=$cursor->format('Y-m-d'); $key=$this->bucket($day,$r['group']);
            if (!isset($points[$key])) { $points[$key]=array_fill_keys($keys,0.0)+['from'=>$day,'to'=>$day,'budget_days'=>0,'days'=>0]; }
            $point=&$points[$key]; $point['to']=$day; $point['days']++;
            $now=$current['daily'][$day]??[]; $before=$previous['daily'][$cursor->modify('-'.$r['days'].' days')->format('Y-m-d')]??[];
            $point['sales']+=$now['sales']??0; $point['gross']+=($now['sales']??0)-($now['cogs']??0); $point['operating']+=($now['sales']??0)-($now['cogs']??0)-($now['expenses']??0);
            $point['previous_sales']+=$before['sales']??0; $point['previous_gross']+=($before['sales']??0)-($before['cogs']??0); $point['previous_operating']+=($before['sales']??0)-($before['cogs']??0)-($before['expenses']??0);
            foreach ($budgets as $budget) { if ($day>=$budget['date_from']&&$day<=$budget['date_to']) { $n=(int)(new DateTimeImmutable($budget['date_from']))->diff(new DateTimeImmutable($budget['date_to']))->format('%a')+1; foreach (['sales','gross','operating'] as $metric) { $point['budget_'.$metric]+=(float)$budget[$metric]/$n; } $point['budget_days']++; } }
            unset($point); $cursor=$cursor->modify('+1 day');
        }
        $totals=array_fill_keys($keys,0.0); $budgetDays=0;
        foreach ($points as &$point) {
            foreach ($keys as $key) { $totals[$key]+=$point[$key]; }
            $budgetDays+=$point['budget_days'];
            if ($point['budget_days']!==$point['days']) { foreach (['sales','gross','operating'] as $k) { $point['budget_'.$k]=NULL; } }
            if (!$current['operating_ready']) { $point['operating']=NULL; $point['previous_operating']=NULL; }
        } unset($point);
        if (!$current['operating_ready']) { $totals['operating']=NULL; $totals['previous_operating']=NULL; }
        if ($budgetDays!==$r['days']) { foreach (['sales','gross','operating'] as $k) { $totals['budget_'.$k]=NULL; } }
        return ['points'=>$points,'totals'=>$totals,'operating_ready'=>$current['operating_ready'],'budget_days'=>$budgetDays];
    }
    public function sales_details(array $r,int $page=1): array {
        $this->guard(); $w=$this->date_window('l.posted_at',$r); $offset=(max(1,$page)-1)*30;
        $base="FROM {$this->p}ledger_entries l LEFT JOIN {$this->p}fulfillments f ON f.id=l.ref_id LEFT JOIN {$this->p}orders o ON o.id=f.order_id LEFT JOIN {$this->d->users} u ON u.ID=l.user_id WHERE l.entry_type IN ('customer_order','customer_order_return') AND l.ref_type='fulfillment' AND $w";
        $count=$this->rows("SELECT COUNT(*) AS n $base")[0]['n'];
        return ['items'=>$this->rows("SELECT l.id,l.user_id,l.posted_at,l.type,l.amount,l.note,f.order_id,o.order_number,u.display_name $base ORDER BY l.posted_at DESC,l.id DESC LIMIT 30 OFFSET $offset"),'pages'=>(int)ceil($count/30),'total'=>(int)$count];
    }
    public function stock(): array {
        $this->guard(); $limits=$this->rows("SELECT * FROM {$this->p}erp_limits"); $by=[]; foreach ($limits as $l) { $by[$l['resource_type'].':'.$l['resource_id']]=$l; }
        $moves="SELECT batch_id,SUM(CASE WHEN direction='in' THEN qty_weight ELSE -qty_weight END) AS qty,MAX(CASE WHEN direction='out' THEN created_at END) AS last_out FROM {$this->p}storage_moves GROUP BY batch_id";
        $ordinary=$this->core->ordinary_raw_condition('r');
        $raw=$this->rows("SELECT 'raw' AS resource_type,r.id AS resource_id,r.title,r.base_uom,c.title AS warehouse,r.category_id,SUM(COALESCE(m.qty,0)) AS quantity,SUM(COALESCE(m.qty,0)*COALESCE(b.unit_cost,0)) AS value,MAX(m.last_out) AS last_out,MIN(b.created_at) AS since FROM {$this->p}raw_products r LEFT JOIN {$this->p}raw_categories c ON c.id=r.category_id LEFT JOIN {$this->p}batches b ON b.raw_product_id=r.id LEFT JOIN ($moves) m ON m.batch_id=b.id WHERE r.is_active=1 AND $ordinary GROUP BY r.id,r.title,r.base_uom,c.title,r.category_id");
        $finished=$this->rows("SELECT 'finished' AS resource_type,src.wc_product_id AS resource_id,COALESCE(p.post_title,'محصول حذف‌شده') AS title,'count' AS base_uom,'انبار محصولات' AS warehouse,0 AS category_id,COALESCE(SUM(i.qty_available),0) AS quantity,COALESCE(SUM(i.inventory_value),0) AS value,s.last_out,MIN(i.created_at) AS since FROM (SELECT ID AS wc_product_id FROM {$this->d->posts} WHERE post_type='product' AND post_status='publish' UNION SELECT DISTINCT wc_product_id FROM {$this->p}inventory_balance) src LEFT JOIN {$this->p}inventory_balance i ON i.wc_product_id=src.wc_product_id LEFT JOIN {$this->d->posts} p ON p.ID=src.wc_product_id LEFT JOIN (SELECT wc_product_id,MAX(created_at) AS last_out FROM {$this->p}inventory_log WHERE ref_type='sale' GROUP BY wc_product_id) s ON s.wc_product_id=src.wc_product_id GROUP BY src.wc_product_id,p.post_title,s.last_out");
        $today=new DateTimeImmutable($this->today(),wp_timezone()); $summary=['normal'=>0,'low'=>0,'unconfigured'=>0,'idle'=>0,'value'=>0.0]; $warehouses=[]; $items=array_merge($raw,$finished);
        foreach ($items as &$item) {
            $item['quantity']=(float)$item['quantity']; $item['value']=(float)$item['value']; $limit=$by[$item['resource_type'].':'.$item['resource_id']]??NULL;
            $item['minimum']=$limit?(float)$limit['minimum']:NULL; $item['target']=$limit?(float)$limit['target']:NULL; $item['idle_days']=$limit?(int)$limit['idle_days']:90;
            $item['state']=$limit?($item['quantity']<$item['minimum']?'low':'normal'):'unconfigured'; $summary[$item['state']]++; $summary['value']+=$item['value'];
            $last=$item['last_out']?:$item['since']; $item['idle']=$item['quantity']>0 && $last && (int)(new DateTimeImmutable(substr($last,0,10),wp_timezone()))->diff($today)->format('%r%a')>=$item['idle_days']; if ($item['idle']) { $summary['idle']++; }
            $warehouse=$item['resource_type']==='raw'?'raw:'.$item['category_id']:'finished'; if (!isset($warehouses[$warehouse])) { $warehouses[$warehouse]=['title'=>$item['warehouse'],'value'=>0.0,'low'=>0,'items'=>0]; } $warehouses[$warehouse]['value']+=$item['value']; $warehouses[$warehouse]['items']++; $warehouses[$warehouse]['low']+=(int)($item['state']==='low');
        } unset($item);
        $top=$this->rows("SELECT i.wc_product_id,COALESCE(p.post_title,'محصول حذف‌شده') AS title,SUM(-i.change_qty) AS quantity FROM {$this->p}inventory_log i LEFT JOIN {$this->d->posts} p ON p.ID=i.wc_product_id WHERE i.ref_type IN ('sale','return') AND i.created_at>=".$this->d->prepare('%s',$today->modify('-29 days')->format('Y-m-d').' 00:00:00')." GROUP BY i.wc_product_id,p.post_title HAVING SUM(-i.change_qty)>0 ORDER BY quantity DESC LIMIT 10");
        return ['items'=>$items,'summary'=>$summary,'warehouses'=>array_values($warehouses),'top'=>$top];
    }
    private function customer_ids(): array {
        return array_map('intval',array_column($this->rows("SELECT DISTINCT customer_id AS id FROM {$this->p}orders WHERE customer_id>0 UNION SELECT DISTINCT user_id AS id FROM {$this->d->usermeta} WHERE meta_key=".$this->d->prepare('%s',$this->d->prefix.'capabilities')." AND meta_value LIKE '%\"subscriber\"%'"),'id'));
    }
    private function due_overrides(string $kind): array {
        $out=[]; foreach ($this->rows($this->d->prepare("SELECT invoice_id,due_on FROM {$this->p}erp_due_dates WHERE kind=%s",$kind)) as $r) { $out[(int)$r['invoice_id']]=$r['due_on']; } return $out;
    }
    private function aged_rows(array $customers,array $due,string $kind): array {
        $bins=['current'=>0.0,'1_30'=>0.0,'31_60'=>0.0,'over_60'=>0.0,'unknown'=>0.0]; $items=[]; $parties=[]; $today=new DateTimeImmutable($this->today(),wp_timezone());
        foreach ($customers as $user=>$customer) {
            $party=['user_id'=>(int)$user,'overdue'=>0.0,'total'=>0.0];
            foreach ($customer['invoices']??[] as $invoice) {
                $amount=(float)$invoice['balance']; if ($amount<0.01) { continue; }
                $date=$due[(int)$invoice['id']]??($invoice['due_date']??''); $age=NULL;
                if ($date) { $age=(int)(new DateTimeImmutable($date,wp_timezone()))->diff($today)->format('%r%a'); }
                $bin=$age===NULL?'unknown':($age<=0?'current':($age<=30?'1_30':($age<=60?'31_60':'over_60')));
                $bins[$bin]+=$amount; $party['total']+=$amount; if ($age!==NULL&&$age>0) { $party['overdue']+=$amount; }
                $items[]=['kind'=>$kind,'user_id'=>(int)$user,'invoice_id'=>(int)$invoice['id'],'number'=>$invoice['invoice_number']??$invoice['id'],'amount'=>$amount,'due_on'=>$date,'age'=>$age,'bin'=>$bin];
            }
            $unassigned=max(0,(float)($customer['unassigned_debt']??0)); if ($unassigned>0) { $bins['unknown']+=$unassigned; $party['total']+=$unassigned; $items[]=['kind'=>$kind,'user_id'=>(int)$user,'invoice_id'=>0,'number'=>'بدون اتصال به فاکتور','amount'=>$unassigned,'due_on'=>'','age'=>NULL,'bin'=>'unknown']; }
            if ($party['total']>0) { $parties[]=$party; }
        }
        usort($items,fn($a,$b)=>[$b['age']??-PHP_INT_MAX,$b['amount']]<=>[$a['age']??-PHP_INT_MAX,$a['amount']]);
        usort($parties,fn($a,$b)=>$b['overdue']<=>$a['overdue']);
        return ['bins'=>$bins,'items'=>$items,'parties'=>$parties,'overdue_count'=>count(array_filter($parties,fn($p)=>$p['overdue']>0))];
    }
    public function debts(): array {
        $this->guard(); $customers=[]; foreach (array_chunk($this->customer_ids(),200) as $ids) { $customers+=$this->core->get_customer_receivables_report($ids); }
        $receivables=$this->aged_rows($customers,$this->due_overrides('customer'),'customer');
        $now=current_time('mysql'); $orders=$this->rows("SELECT id,supplier_user_id AS customer_id,invoice_no AS invoice_number,DATE(issued_at) AS invoice_date FROM {$this->p}supplier_invoices WHERE status IN ('confirmed','settled') ORDER BY issued_at,id");
        foreach ($orders as &$o) { $o['payment_term_days']=''; } unset($o);
        $entries=$this->rows($this->d->prepare("SELECT l.*,CASE WHEN l.ref_type='supplier_invoice' THEN l.ref_id ELSE COALESCE((SELECT m.meta_value FROM {$this->p}ledger_entry_meta m WHERE m.entry_id=l.id AND m.meta_key='invoice_id' ORDER BY m.id DESC LIMIT 1),(SELECT p.ref_id FROM {$this->p}payments p WHERE l.ref_type='payment' AND p.id=l.ref_id),(SELECT t.ref_id FROM {$this->p}transfers t WHERE l.ref_type='transfer' AND t.id=l.ref_id),(SELECT cm.meta_value FROM {$this->p}cheque_meta cm WHERE l.ref_type='cheque' AND cm.cheque_id=l.ref_id AND cm.meta_key='invoice_id' ORDER BY cm.id DESC LIMIT 1)) END AS linked_order_id FROM {$this->p}ledger_entries l WHERE l.user_id IN (SELECT DISTINCT supplier_user_id FROM {$this->p}supplier_invoices) AND l.posted_at<=%s ORDER BY l.posted_at,l.id",$now));
        foreach ($entries as &$entry) { $entry['type']=$entry['type']==='credit'?'debit':'credit'; } unset($entry);
        $payables=$this->aged_rows($this->core->calculate_customer_receivables($orders,$entries,$this->today()),$this->due_overrides('supplier'),'supplier');
        $ids=$this->customer_ids(); $balances=[];
        foreach (array_chunk($ids,200) as $batch) { $list=implode(',',$batch); foreach ($this->rows($this->d->prepare("SELECT user_id,SUM(CASE WHEN type='debit' THEN amount ELSE -amount END) AS balance FROM {$this->p}ledger_entries WHERE user_id IN ($list) AND posted_at<=%s GROUP BY user_id",$now)) as $row) { $balances[]=$row; } }
        return ['receivables'=>$receivables,'payables'=>$payables,'balances'=>$balances,'debit'=>array_sum(array_map(fn($x)=>max(0,(float)$x['balance']),$balances)),'credit'=>array_sum(array_map(fn($x)=>max(0,-(float)$x['balance']),$balances))];
    }
    public function cash(array $r,array $debts): array {
        $this->guard(); $accounts=$this->rows("SELECT id,title,type,balance,status FROM {$this->p}accounts WHERE type IN ('bank','cash')");
        $w=$this->date_window('t.created_at',$r);
        $daily=$this->rows("SELECT DATE(t.created_at) AS day,SUM(CASE WHEN t.type='credit' THEN t.amount ELSE 0 END) AS incoming,SUM(CASE WHEN t.type='debit' THEN t.amount ELSE 0 END) AS outgoing FROM {$this->p}account_transactions t INNER JOIN {$this->p}accounts a ON a.id=t.account_id WHERE a.type IN ('bank','cash') AND t.action<>'initial_balance' AND $w GROUP BY DATE(t.created_at) ORDER BY day");
        $grouped=[]; $cursor=new DateTimeImmutable($r['from'],wp_timezone()); $end=new DateTimeImmutable($r['to'],wp_timezone()); while($cursor<=$end){$grouped[$this->bucket($cursor->format('Y-m-d'),$r['group'])]=['incoming'=>0.0,'outgoing'=>0.0];$cursor=$cursor->modify('+1 day');} foreach ($daily as $row) { $key=$this->bucket($row['day'],$r['group']); if (!isset($grouped[$key])) { $grouped[$key]=['incoming'=>0.0,'outgoing'=>0.0]; } $grouped[$key]['incoming']+=(float)$row['incoming']; $grouped[$key]['outgoing']+=(float)$row['outgoing']; }
        $balance=array_sum(array_column($accounts,'balance')); $future=[]; $today=new DateTimeImmutable($this->today(),wp_timezone());
        for ($i=0;$i<=30;$i++) { $day=$today->modify('+'.$i.' days')->format('Y-m-d'); $future[$day]=['incoming'=>0.0,'outgoing'=>0.0,'balance'=>0.0]; }
        $commitments=[];
        foreach (['receivables'=>'incoming','payables'=>'outgoing'] as $source=>$direction) { foreach ($debts[$source]['items'] as $item) { if (!$item['due_on']) { continue; } $day=max($this->today(),$item['due_on']); if (!isset($future[$day])) { continue; } $future[$day][$direction]+=$item['amount']; $commitments[]=$item+['direction'=>$direction,'forecast_on'=>$day,'source'=>$source]; } }
        // Customer cheques already credited against receivables enter only at their own due date.
        $cheques=$this->rows("SELECT c.id,c.user_id,c.amount,c.due_at FROM {$this->p}cheques c WHERE c.status='in_hand' AND c.currency='IRR' AND COALESCE(c.current_holder_user_id,0)=0");
        foreach ($cheques as $cheque) { $day=max($this->today(),$cheque['due_at']); if (isset($future[$day])) { $future[$day]['incoming']+=(float)$cheque['amount']; $commitments[]=['direction'=>'incoming','amount'=>(float)$cheque['amount'],'due_on'=>$cheque['due_at'],'forecast_on'=>$day,'source'=>'cheque','user_id'=>(int)$cheque['user_id'],'invoice_id'=>0,'number'=>'چک #'.$cheque['id']]; } }
        $hrTable=$this->rows($this->d->prepare('SHOW TABLES LIKE %s',$this->d->esc_like($this->p.'hr_records')));
        if ($hrTable) {
            foreach ($this->rows("SELECT id,employee_id,amount,data FROM {$this->p}hr_records WHERE kind='cheque' AND status='posted'") as $record) {
                $data=json_decode($record['data'],TRUE); $due=$data['due_date']??'';
                if (!is_string($due)||!preg_match('/^20[0-9]{2}-[0-9]{2}-[0-9]{2}$/D',$due)) { continue; }
                $day=max($this->today(),$due); if (isset($future[$day])) { $future[$day]['outgoing']+=(float)$record['amount']; $commitments[]=['direction'=>'outgoing','amount'=>(float)$record['amount'],'due_on'=>$due,'forecast_on'=>$day,'source'=>'hr_cheque','user_id'=>(int)$record['employee_id'],'invoice_id'=>0,'number'=>'چک پرسنل #'.$record['id']]; }
            }
        }
        $min=$balance; foreach ($future as &$point) { $balance+=$point['incoming']-$point['outgoing']; $point['balance']=$balance; $min=min($min,$balance); } unset($point);
        return ['accounts'=>$accounts,'balance'=>array_sum(array_column($accounts,'balance')),'points'=>$grouped,'future'=>$future,'shortfall'=>max(0,-$min),'commitments'=>$commitments];
    }
    public function funnel(array $r): array {
        $this->guard(); $w=$this->date_window('o.created_at',$r);
        $statuses=$this->rows("SELECT o.status,COUNT(*) AS count,SUM(o.total_payable) AS amount FROM {$this->p}orders o WHERE $w GROUP BY o.status");
        $cohort=$this->rows("SELECT COUNT(*) AS total,SUM(CASE WHEN o.status IN ('registered','shortage','shipped') THEN 1 ELSE 0 END) AS confirmed FROM {$this->p}orders o WHERE o.status<>'canceled' AND $w")[0];
        $w=$this->date_window('l.created_at',$r);
        $leads=$this->rows("SELECT COUNT(*) AS total,SUM(CASE WHEN o.status IN ('registered','shortage','shipped') THEN 1 ELSE 0 END) AS converted FROM {$this->p}erp_leads l LEFT JOIN {$this->p}orders o ON o.id=l.order_id WHERE $w")[0];
        $w=$this->date_window('o.created_at',$r);
        $sellers=$this->rows("SELECT o.created_by,u.display_name,COUNT(*) AS total,SUM(CASE WHEN o.status IN ('registered','shortage','shipped') THEN 1 ELSE 0 END) AS confirmed,SUM(CASE WHEN o.status IN ('registered','shortage','shipped') THEN o.total_payable ELSE 0 END) AS amount FROM {$this->p}orders o LEFT JOIN {$this->d->users} u ON u.ID=o.created_by WHERE $w GROUP BY o.created_by,u.display_name ORDER BY amount DESC");
        return ['statuses'=>$statuses,'orders'=>(int)$cohort['total'],'confirmed'=>(int)$cohort['confirmed'],'conversion'=>(int)$cohort['total']?round(100*$cohort['confirmed']/$cohort['total'],1):NULL,'leads'=>(int)$leads['total'],'converted_leads'=>(int)$leads['converted'],'lead_conversion'=>(int)$leads['total']?round(100*$leads['converted']/$leads['total'],1):NULL,'sellers'=>$sellers];
    }
    public function tasks(array $r): array {
        $this->guard(); $today=$this->today(); $w=$this->date_window('t.created_at',$r);
        $units=$this->rows($this->d->prepare("SELECT t.department,COUNT(*) AS total,SUM(CASE WHEN status='done' THEN 1 ELSE 0 END) AS done,SUM(CASE WHEN status IN ('open','doing') AND due_on<%s THEN 1 ELSE 0 END) AS overdue,SUM(CASE WHEN kind='request' AND status IN ('open','doing') THEN 1 ELSE 0 END) AS open_requests,SUM(CASE WHEN status='done' AND DATE(completed_at)<=due_on THEN 1 ELSE 0 END) AS on_time,AVG(CASE WHEN status='done' THEN TIMESTAMPDIFF(MINUTE,started_at,completed_at)/1440.0 END) AS avg_days FROM {$this->p}erp_tasks t WHERE $w GROUP BY t.department ORDER BY t.department",$today));
        $counts=$this->rows($this->d->prepare("SELECT SUM(CASE WHEN status IN ('open','doing') AND due_on<%s THEN 1 ELSE 0 END) AS overdue,SUM(CASE WHEN status IN ('open','doing') AND (due_on<=%s OR priority='important') THEN 1 ELSE 0 END) AS today FROM {$this->p}erp_tasks",$today,$today))[0];
        $important=$this->rows($this->d->prepare("SELECT t.*,u.display_name FROM {$this->p}erp_tasks t LEFT JOIN {$this->d->users} u ON u.ID=t.assignee WHERE status IN ('open','doing') AND (due_on<=%s OR priority='important') ORDER BY due_on,id LIMIT 10",$today));
        return ['units'=>$units,'overdue'=>(int)$counts['overdue'],'today'=>(int)$counts['today'],'important'=>$important];
    }
    public function records(string $kind,int $page=1,string $filter='',string $department=''): array {
        $this->guard(); $offset=(max(1,$page)-1)*30;
        $names=['tasks','leads','budgets','purchases']; if (!in_array($kind,$names,TRUE)) { throw new RuntimeException('نوع فهرست معتبر نیست.'); }
        $where='1=1';
        if ($kind==='tasks'&&$filter==='overdue') { $where=$this->d->prepare("status IN ('open','doing') AND due_on<%s",$this->today()); }
        if ($kind==='tasks'&&$filter==='today') { $where=$this->d->prepare("status IN ('open','doing') AND (due_on<=%s OR priority='important')",$this->today()); }
        if ($kind==='tasks' && $department!=='') { $where.=$this->d->prepare(' AND department=%s',$department); }
        $count=(int)$this->rows("SELECT COUNT(*) AS n FROM {$this->p}erp_$kind WHERE $where")[0]['n'];
        return ['items'=>$this->rows("SELECT * FROM {$this->p}erp_$kind WHERE $where ORDER BY id DESC LIMIT 30 OFFSET $offset"),'total'=>$count,'pages'=>(int)ceil($count/30)];
    }
    public function record(string $kind,int $id): array {
        $this->guard(); if (!in_array($kind,['tasks','leads','budgets','purchases'],TRUE)) { throw new RuntimeException('نوع رکورد معتبر نیست.'); }
        return $this->rows($this->d->prepare("SELECT * FROM {$this->p}erp_$kind WHERE id=%d",$id))[0]??[];
    }
    public function overview(array $r): array {
        $this->guard(); $this->install(); $debts=$this->debts();
        return ['range'=>$r,'sales'=>$this->sales($r),'stock'=>$this->stock(),'debts'=>$debts,'cash'=>$this->cash($r,$debts),'funnel'=>$this->funnel($r),'tasks'=>$this->tasks($r)];
    }
}
