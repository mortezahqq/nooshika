<?php
if(!defined('ABSPATH')){exit;}

/** Contract benefits use a fixed 30-day divisor; a working day is 480 minutes. */
trait kph_hr_payroll_benefits {
    public function benefit_work_summary(int $employee,string $from,string $to):array{
        $this->guard();$this->employee($employee);
        $rows=$this->d->get_results($this->d->prepare("SELECT id,kind,date_from,date_to,version,data FROM {$this->p}hr_records WHERE employee_id=%d AND status='approved' AND date_from<=%s AND date_to>=%s AND (kind='leave' OR (kind='attendance' AND JSON_UNQUOTE(JSON_EXTRACT(data,'$.day_status'))='absence')) ORDER BY id",$employee,$to,$from),ARRAY_A);
        if($this->d->last_error){throw new RuntimeException('خواندن غیبت و مرخصی بدون حقوق انجام نشد.');}
        $out=['unpaid_minutes'=>0,'absence_days'=>0,'day_minutes'=>480,'records'=>[]];$absences=[];$ranges=[];
        foreach($rows?:[] as $row){$data=json_decode($row['data'],TRUE)?:[];if($row['kind']==='leave'&&($data['leave_type']??'paid')!=='unpaid'){$ranges[]=[$row['date_from'],$row['date_to']];continue;}$out['records'][]=['id'=>(int)$row['id'],'version'=>(int)$row['version']];
            if($row['kind']==='attendance'){$absences[$row['date_from']]=TRUE;continue;}
            if($row['date_from']<$from||$row['date_to']>$to){throw new RuntimeException('مرخصی بدون حقوق #'.$row['id'].' بین دو ماه است؛ برای محاسبه دقیق، آن را به بازه‌های جداگانه هر ماه تقسیم کنید.');}
            $days=(int)(new DateTimeImmutable($row['date_from']))->diff(new DateTimeImmutable($row['date_to']))->format('%a')+1;$minutes=(int)($data['minutes']??0);
            if($minutes<0||$minutes>$days*480){throw new RuntimeException('مدت مرخصی بدون حقوق #'.$row['id'].' با روز کاری ۴۸۰ دقیقه سازگار نیست؛ مدت ثبت‌شده را بررسی کنید.');}
            $out['unpaid_minutes']+=$minutes;$ranges[]=[$row['date_from'],$row['date_to']];
        }
        foreach($absences as $day=>$unused){foreach($ranges as [$start,$end]){if($day>=$start&&$day<=$end){throw new RuntimeException('برای یک روز، غیبت و مرخصی تأییدشده هم‌زمان ثبت شده است؛ کارکرد را اصلاح کنید.');}}}
        $out['absence_days']=count($absences);return $out;
    }
    private function calculated_benefits(int $employee,array $period,array $input,array $data,array $contract):array{
        $work=$this->benefit_work_summary($employee,$period['from'],$period['to']);
        $days=round(max(0,min((float)$data['paid_days'],$period['days']-$work['absence_days']-$work['unpaid_minutes']/480)),6);
        if($contract){$housing=(int)$this->number($contract['housing']??30000000);$food=(int)$this->number($contract['food_allowance']??22000000);
            if(array_key_exists('seniority_daily_rate',$contract)){$rate=$this->number($contract['seniority_daily_rate'],1000000000000,TRUE);$source='daily_contract';}
            else{$rate=$this->number($contract['seniority_base']??0)/max(1,(float)($contract['normal_days']??30));$source='legacy_monthly_contract';}
        }else{
            $housing=(int)$this->number($input['housing']??30000000);$food=(int)$this->number($input['food_allowance']??22000000);
            $rate=$this->number($input['seniority_daily_rate']??0,1000000000000,TRUE);$source='manual_daily';
        }
        $factor=min(1,$days/30);
        return ['benefits_version'=>1,'benefit_divisor'=>30,'benefit_day_minutes'=>480,'benefit_days'=>$days,'benefit_unpaid_days'=>$work['unpaid_minutes']/480,'benefit_absence_days'=>$work['absence_days'],'benefit_work_snapshot'=>$work,
            'housing_monthly_cap'=>$housing,'food_monthly_cap'=>$food,'housing'=>(int)round($housing*$factor),'food_allowance'=>(int)round($food*$factor),
            'seniority_daily_rate'=>$rate,'seniority_rate_source'=>$source,'seniority_base'=>(int)round($rate*$days)];
    }
}
