<?php
if (!defined('ABSPATH')) { exit; }

/** Manual customer freight uses the native payment, customer journal and expense journal together. */
final class kph_customer_freight {
    private wpdb $d;
    private kph_db $core;
    private string $p;
    public function __construct(?kph_db $core=null) { global $wpdb; $this->d=$wpdb; $this->core=$core?:new kph_db(); $this->p=$wpdb->prefix.'kph_'; }
    public static function allowed():bool { if(kph_support_accounting_restricted()) return false; return is_user_logged_in() && (current_user_can('manage_options') || nooshika_get_user_role(get_current_user_id())==='accountant'); }
    private function guard():void { if(!self::allowed())throw new RuntimeException('ثبت یا حذف کرایه مشتری فقط برای مدیر و حسابدار مجاز است.'); }
    private function ok($result):void { if($result===false)throw new RuntimeException('ثبت یکپارچه کرایه انجام نشد؛ دوباره وضعیت را بررسی کنید.'); }
    private function result(array $result):array { if(($result['status']??'')!=='success')throw new RuntimeException($result['message']??'ثبت کرایه انجام نشد.');return $result['data']; }
    public function install():void {
        $this->guard();
        $this->ok($this->d->query("CREATE TABLE IF NOT EXISTS {$this->p}customer_freight_payments (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, payment_id BIGINT UNSIGNED NOT NULL UNIQUE,
            customer_id BIGINT UNSIGNED NOT NULL, order_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            amount BIGINT UNSIGNED NOT NULL, ledger_id BIGINT UNSIGNED NOT NULL, expense_id BIGINT UNSIGNED NOT NULL,
            status VARCHAR(16) NOT NULL DEFAULT 'active', request_key CHAR(64) NOT NULL UNIQUE,
            fingerprint CHAR(64) NOT NULL, created_by BIGINT UNSIGNED NOT NULL, created_at DATETIME NOT NULL,
            canceled_at DATETIME NULL, KEY order_status(order_id,status)
        ) ENGINE=InnoDB ".$this->d->get_charset_collate()));
    }
    private function ready():void {
        foreach(['customer_freight_payments','payments','payment_meta','ledger_entries','ledger_entry_meta','accounts','account_meta','account_transactions','account_transaction_meta','actions','action_meta','shipping_settings','shipping_freight'] as $name){
            $row=$this->d->get_row($this->d->prepare('SHOW TABLE STATUS LIKE %s',$this->d->esc_like($this->p.$name)),ARRAY_A);
            if(!$row||strcasecmp($row['Engine'],'InnoDB'))throw new RuntimeException('آماده‌سازی ثبت کرایه کامل نیست؛ صفحه را با حساب مدیر یا حسابدار تازه کنید.');
        }
    }
    public static function for_order(int $order_id):?array {
        if($order_id<=0)return null;
        global $wpdb;$table=$wpdb->prefix.'kph_customer_freight_payments';
        $exists=$wpdb->get_row($wpdb->prepare('SHOW TABLE STATUS LIKE %s',$wpdb->esc_like($table)),ARRAY_A);
        if($wpdb->last_error)throw new RuntimeException('خواندن ارتباط کرایه مشتری انجام نشد.');
        if(!$exists)return null;
        $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE order_id=%d AND status='active' ORDER BY id LIMIT 1",$order_id),ARRAY_A);
        if($wpdb->last_error)throw new RuntimeException('خواندن ارتباط کرایه مشتری انجام نشد.');return $row;
    }
    private function meta(string $entity,int $id,array $values):void { $this->result($this->core->save_meta_batch($entity,$id,$values,true)); }
    private function audit(int $customer,string $event,array $data):void {
        $this->ok($this->d->insert($this->p.'actions',['user_id'=>$customer,'title'=>$event==='create'?'ثبت کرایه مشتری از پرداختی‌ها':'حذف کرایه مشتری و برگشت ثبت مالی مرتبط','content'=>'پرداخت #'.$data['payment_id'].' — مبلغ '.number_format($data['amount']).' ریال','date'=>current_time('mysql'),'creator'=>get_current_user_id()]));
        $this->meta('action',(int)$this->d->insert_id,['type'=>'customer_freight_'.$event]+$data);
    }
    public function add(array $input):array {
        try {
            $this->guard();$this->ready();
            foreach(['user_id','amount','paid_at','request_key','freight_order_id','note','attachment'] as $key)if(isset($input[$key])&&!is_scalar($input[$key]))throw new RuntimeException('ساختار اطلاعات کرایه معتبر نیست.');
            $customer=absint($input['user_id']??0);$user=get_userdata($customer);
            if(!$user||!in_array('subscriber',(array)$user->roles,true))throw new RuntimeException('کرایه را فقط برای مشتری ثبت‌شده وارد کنید.');
            $amount=str_replace([',','٬'],'',kph_hr_calendar::latin(trim((string)($input['amount']??''))));
            // Native payment/party ledgers use DECIMAL(18,2) and PHP floats. Stay in their exact whole-rial range.
            if(!preg_match('/^[0-9]{1,14}$/D',$amount)||(int)$amount<=0)throw new RuntimeException('مبلغ کرایه باید عدد صحیح مثبت به ریال باشد.');
            $amount=(int)$amount;$date=kph_hr_calendar::normalize((string)($input['paid_at']??''));$paidAt=$date.' 00:00:00';
            $key=(string)($input['request_key']??'');if(!preg_match('/^[a-zA-Z0-9-]{20,80}$/D',$key))throw new RuntimeException('اعتبار فرم کرایه کافی نیست؛ صفحه را تازه کنید.');
            $key=hash('sha256',get_current_user_id().':'.$key);$order=absint($input['freight_order_id']??0);
            $note=wp_kses_post((string)($input['note']??''));$attachment=(string)($input['attachment']??'');
            if(strlen($note)>50000||strlen($attachment)>10000)throw new RuntimeException('یادداشت یا ضمیمه بیش از حد طولانی است.');
            $fingerprint=hash('sha256',wp_json_encode([$customer,$amount,$date,$order,$note,$attachment]));
            $this->ok($this->d->query('START TRANSACTION'));
            // Shared lock order with shipment accounting prevents cross-path duplicate postings/account creation.
            $setting=$this->d->get_row("SELECT * FROM {$this->p}shipping_settings WHERE id=1 FOR UPDATE",ARRAY_A);
            if(!$setting||$this->d->last_error)throw new RuntimeException('تنظیمات کرایه آماده نیست؛ صفحه را تازه کنید.');
            $previous=$this->d->get_row($this->d->prepare("SELECT * FROM {$this->p}customer_freight_payments WHERE request_key=%s FOR UPDATE",$key),ARRAY_A);
            if($this->d->last_error)throw new RuntimeException('بررسی ثبت قبلی انجام نشد.');
            if($previous){
                if($previous['status']!=='active'||!hash_equals($previous['fingerprint'],$fingerprint))throw new RuntimeException('این فرم قبلاً استفاده شده است؛ فرم پرداختی را دوباره باز کنید.');
                $this->ok($this->d->query('COMMIT'));return ['status'=>'success','message'=>'این کرایه قبلاً ثبت شده است؛ ثبت تکراری انجام نشد.','data'=>['id'=>(int)$previous['payment_id']]];
            }
            $invoice='';
            if($order){
                $row=$this->d->get_row($this->d->prepare("SELECT id,customer_id,status FROM {$this->p}orders WHERE id=%d FOR UPDATE",$order),ARRAY_A);
                if(!$row||$this->d->last_error||(int)$row['customer_id']!==$customer||$row['status']==='canceled')throw new RuntimeException('فاکتور معتبر همین مشتری را انتخاب کنید.');
                $invoice=(string)$this->d->get_var($this->d->prepare("SELECT meta_value FROM {$this->p}orders_meta WHERE order_id=%d AND meta_key='factor_number' ORDER BY id DESC LIMIT 1",$order));
                if($this->d->last_error||trim($invoice)==='')throw new RuntimeException('فاکتور انتخاب‌شده شماره ندارد.');
                $shipping=$this->d->get_var($this->d->prepare("SELECT record_id FROM {$this->p}shipping_freight WHERE order_id=%d AND amount>0 LIMIT 1",$order));
                if($this->d->last_error)throw new RuntimeException('بررسی کرایه ارسال انجام نشد.');
                if($shipping||self::for_order($order))throw new RuntimeException('کرایه این فاکتور قبلاً ثبت شده است؛ برای جلوگیری از کسر دوباره، سابقه قبلی را بررسی کنید.');
            }
            require_once __DIR__.'/kph_shipping_control.php';
            $context=(new kph_shipping_control())->customer_freight_context();
            $meta=['creator_id'=>get_current_user_id(),'payment_purpose'=>'customer_freight','attachment'=>$attachment,'customer_id'=>$customer,'order_id'=>$order,'invoice_number'=>$invoice];
            $this->ok($this->d->insert($this->p.'payments',['user_id'=>$customer,'amount'=>-$amount,'payment_method'=>'other','paid_at'=>$paidAt,'note'=>$note,'created_at'=>current_time('mysql',true)]));$payment=(int)$this->d->insert_id;
            $this->meta('payment',$payment,$meta);
            $ledger=$this->result($this->core->add_ledger_entry(['user_id'=>$customer,'entry_type'=>'customer_freight','type'=>'credit','amount'=>$amount,'ref_type'=>'payment','ref_id'=>$payment,'posted_at'=>$paidAt,'note'=>'کرایه مشتری — پرداخت #'.$payment.($invoice!==''?' — فاکتور #'.$invoice:''),'meta'=>$meta]));
            $expense=$this->result($this->core->add_account_transaction(['account_id'=>$context['account_id'],'amount'=>$amount,'type'=>'debit','action'=>'customer_freight_payment','created_at'=>$paidAt,'description'=>'کرایه مشتری: '.$user->display_name.' — پرداخت #'.$payment.($invoice!==''?' — فاکتور #'.$invoice:'').($note!==''?' — '.wp_strip_all_tags($note):''),'meta'=>['cost_type'=>$context['cost_key'],'destination'=>$user->display_name,'source'=>'customer_payment','payment_id'=>$payment]+$meta],true));
            $data=['payment_id'=>$payment,'customer_id'=>$customer,'order_id'=>$order,'amount'=>$amount,'ledger_id'=>$ledger['id'],'expense_id'=>$expense['transaction_id']];
            $this->ok($this->d->insert($this->p.'customer_freight_payments',$data+['request_key'=>$key,'fingerprint'=>$fingerprint,'created_by'=>get_current_user_id(),'created_at'=>current_time('mysql')]));
            $this->meta('payment',$payment,['freight_expense_id'=>$expense['transaction_id']]);$this->audit($customer,'create',$data);
            $this->ok($this->d->query('COMMIT'));
            return ['status'=>'success','message'=>'کرایه از بدهی مشتری کسر و در هزینه‌های کرایه مشتریان ثبت شد.','data'=>['id'=>$payment,'ledger_id'=>$ledger['id'],'expense_id'=>$expense['transaction_id']]];
        }catch(Throwable $e){$this->d->query('ROLLBACK');return ['status'=>'error','message'=>$e->getMessage(),'data'=>[]];}
    }
    public function delete(int $payment):array {
        try {
            $this->guard();$this->ready();$this->ok($this->d->query('START TRANSACTION'));
            if(!$this->d->get_row("SELECT id FROM {$this->p}shipping_settings WHERE id=1 FOR UPDATE",ARRAY_A))throw new RuntimeException('تنظیمات کرایه یافت نشد.');
            $record=$this->d->get_row($this->d->prepare("SELECT * FROM {$this->p}customer_freight_payments WHERE payment_id=%d FOR UPDATE",$payment),ARRAY_A);
            if(!$record||$record['status']!=='active')throw new RuntimeException('پرداخت کرایه فعال یافت نشد.');
            $p=$this->d->get_row($this->d->prepare("SELECT * FROM {$this->p}payments WHERE id=%d FOR UPDATE",$payment),ARRAY_A);
            $l=$this->d->get_row($this->d->prepare("SELECT * FROM {$this->p}ledger_entries WHERE id=%d FOR UPDATE",$record['ledger_id']),ARRAY_A);
            $expense=$this->d->get_row($this->d->prepare("SELECT * FROM {$this->p}account_transactions WHERE id=%d FOR UPDATE",$record['expense_id']),ARRAY_A);
            $account=$expense?$this->d->get_row($this->d->prepare("SELECT id,type FROM {$this->p}accounts WHERE id=%d FOR UPDATE",$expense['account_id']),ARRAY_A):null;
            if(!$account||$account['type']!=='expense'||!$p||!$l||!$expense||(int)$p['user_id']!==(int)$record['customer_id']||(int)$p['amount']!==-(int)$record['amount']||$l['type']!=='credit'||$l['entry_type']!=='customer_freight'||$l['ref_type']!=='payment'||(int)$l['ref_id']!==$payment||(int)$l['user_id']!==(int)$record['customer_id']||(int)$l['amount']!==(int)$record['amount']||$expense['action']!=='customer_freight_payment'||$expense['type']!=='debit'||(int)$expense['amount']!==(int)$record['amount'])throw new RuntimeException('ثبت مالی مرتبط تغییر کرده است؛ مدیر سوابق را بررسی کند.');
            $this->result($this->core->add_account_transaction(['account_id'=>$expense['account_id'],'amount'=>$record['amount'],'type'=>'credit','action'=>'customer_freight_reversal','description'=>'برگشت کرایه مشتری — پرداخت #'.$payment,'meta'=>['source'=>'customer_payment','payment_id'=>$payment,'customer_id'=>$record['customer_id'],'reversed_expense_id'=>$record['expense_id']]],true));
            $this->meta('account_transaction',(int)$record['expense_id'],['customer_freight_voided'=>1]);
            $this->ok($this->d->delete($this->p.'ledger_entry_meta',['entry_id'=>$record['ledger_id']]));
            $this->ok($this->d->delete($this->p.'ledger_entries',['id'=>$record['ledger_id']]));
            $this->ok($this->d->delete($this->p.'payment_meta',['payment_id'=>$payment]));$this->ok($this->d->delete($this->p.'payments',['id'=>$payment]));
            $this->ok($this->d->update($this->p.'customer_freight_payments',['status'=>'canceled','canceled_at'=>current_time('mysql')],['id'=>$record['id']]));$this->audit((int)$record['customer_id'],'delete',$record);
            $this->ok($this->d->query('COMMIT'));return ['status'=>'success','message'=>'پرداخت کرایه حذف و اثر آن در حساب مشتری و هزینه‌ها برگشت داده شد.','data'=>['payment_id'=>$payment]];
        }catch(Throwable $e){$this->d->query('ROLLBACK');return ['status'=>'error','message'=>$e->getMessage(),'data'=>[]];}
    }
}
