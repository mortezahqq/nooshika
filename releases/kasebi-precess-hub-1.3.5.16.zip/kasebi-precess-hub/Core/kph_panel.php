<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class kph_panel {
	
	public function __construct() {
		add_shortcode( 'kasebi-kph', [ $this, 'render_kph_page_template' ] );
	}
	
	public function render_kph_page_template(): bool|string {
		ob_start();
		echo '<div class="nk-app-root">';
		echo kph_get_template( 'layout/main.php' );
		echo '</div>';
		
		return ob_get_clean();
	}
	
}