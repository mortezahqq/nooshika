<?php
if (!defined('ABSPATH')) { exit; }

/** Private blobs stay in personnel storage, outside the public media library. */
trait kph_hr_documents {
    public static function document_categories(): array {
        return [
            'identity'=>['title'=>'مدارک هویتی','types'=>['national_card'=>'کارت ملی (رو و پشت)','identity_pages'=>'صفحات شناسنامه','portrait'=>'عکس پرسنلی']],
            'contract'=>['title'=>'قراردادها','types'=>['signed_contract'=>'قرارداد امضاشده','contract_annex'=>'الحاقیه قرارداد']],
            'payslip'=>['title'=>'فیش‌های حقوقی','types'=>['signed_payslip'=>'فیش حقوقی امضاشده']],
            'settlement'=>['title'=>'تسویه‌حساب‌ها','types'=>['signed_settlement'=>'فرم تسویه‌حساب امضاشده']],
            'other'=>['title'=>'سایر مدارک','types'=>['other'=>'مدرک مرتبط دیگر']],
        ];
    }
    private function install_document_storage(): void {
        $this->require_ok($this->d->query("CREATE TABLE IF NOT EXISTS {$this->p}hr_file_meta (file_id BIGINT UNSIGNED PRIMARY KEY, category VARCHAR(20) NOT NULL, subtype VARCHAR(30) NOT NULL, title VARCHAR(190) NOT NULL, period VARCHAR(20) NOT NULL DEFAULT '', version INT UNSIGNED NOT NULL DEFAULT 1, updated_by BIGINT UNSIGNED NOT NULL, updated_at DATETIME NOT NULL, KEY category_period(category,period)) ENGINE=InnoDB ".$this->d->get_charset_collate()));
    }
    private function file_rows(string $sql): array {
        $r=$this->d->get_results($sql,ARRAY_A);
        if ($this->d->last_error) { throw new RuntimeException('خواندن مدارک انجام نشد.'); }
        return $r?:[];
    }
    private function file_select(): string {
        return "SELECT f.id,f.employee_id,f.record_id,f.filename,f.mime,f.checksum,f.created_at,OCTET_LENGTH(f.contents) AS bytes,
        COALESCE(m.category,CASE WHEN r.kind IN ('contract','payslip','settlement') THEN r.kind ELSE 'other' END) AS category,
        COALESCE(m.subtype,CASE r.kind WHEN 'contract' THEN 'signed_contract' WHEN 'payslip' THEN 'signed_payslip' WHEN 'settlement' THEN 'signed_settlement' ELSE 'other' END) AS subtype,
        COALESCE(m.title,f.filename) AS title,COALESCE(NULLIF(m.period,''),r.period,'') AS period,COALESCE(m.version,1) AS version
        FROM {$this->p}hr_files f LEFT JOIN {$this->p}hr_file_meta m ON m.file_id=f.id LEFT JOIN {$this->p}hr_records r ON r.id=f.record_id AND r.employee_id=f.employee_id";
    }
    public function personnel_documents(int $employee,string $category='',int $page=1): array {
        $this->guard();$this->employee($employee);
        if ($category!==''&&!isset(self::document_categories()[$category])) { throw new RuntimeException('دستهٔ مدرک معتبر نیست.'); }
        $base=$this->file_select().$this->d->prepare(' WHERE f.employee_id=%d',$employee);
        if ($category!=='') { $base.=$this->d->prepare(" AND COALESCE(m.category,CASE WHEN r.kind IN ('contract','payslip','settlement') THEN r.kind ELSE 'other' END)=%s",$category); }
        $n=$this->file_rows('SELECT COUNT(*) AS total FROM ('.$base.') scoped')[0]['total'];
        $items=$this->file_rows($base.' ORDER BY f.id DESC LIMIT 20 OFFSET '.((max(1,$page)-1)*20));
        $counts=$this->file_rows('SELECT category,COUNT(*) AS total FROM ('.$this->file_select().$this->d->prepare(' WHERE f.employee_id=%d',$employee).') owned GROUP BY category');
        return ['items'=>$items,'total'=>(int)$n,'pages'=>max(1,(int)ceil($n/20)),'counts'=>array_column($counts,'total','category')];
    }
    private function validated_upload(array $file): array {
        $limit=min(5*1024*1024,function_exists('wp_max_upload_size')?(int)wp_max_upload_size():5*1024*1024);
        if (($file['error']??1)!==UPLOAD_ERR_OK||!is_uploaded_file($file['tmp_name']??'')) { throw new RuntimeException('فایل ارسال نشد؛ فایل معتبر و محدودیت حجم سرور را بررسی کنید.'); }
        $bytes=file_get_contents($file['tmp_name']);
        if ($bytes===FALSE||strlen($bytes)===0||strlen($bytes)>$limit) { throw new RuntimeException('هر فایل باید حداکثر ۵ مگابایت و کمتر از سقف سرور باشد.'); }
        $filename=mb_substr(sanitize_file_name($file['name']??'document'),0,190);$ext=strtolower(pathinfo($filename,PATHINFO_EXTENSION));
        if (!class_exists('finfo')) { throw new RuntimeException('امکان شناسایی نوع فایل روی سرور فعال نیست.'); }
        $mime=(new finfo(FILEINFO_MIME_TYPE))->buffer($bytes);$valid=FALSE;
        if ($ext==='pdf'&&$mime==='application/pdf'&&str_starts_with($bytes,'%PDF-')) { $valid=TRUE; }
        elseif (in_array($ext,['jpg','jpeg','png'],TRUE)&&in_array($mime,['image/jpeg','image/png'],TRUE)) { $image=@getimagesizefromstring($bytes);$valid=$image&&(($ext==='png'&&$mime==='image/png')||($ext!=='png'&&$mime==='image/jpeg')); }
        elseif ($ext==='doc'&&str_starts_with($bytes,"\xD0\xCF\x11\xE0\xA1\xB1\x1A\xE1")) { $mime='application/msword';$valid=TRUE; }
        elseif ($ext==='docx'&&str_starts_with($bytes,"PK\x03\x04")&&str_contains($bytes,'[Content_Types].xml')&&str_contains($bytes,'word/document.xml')&&!str_contains($bytes,'vbaProject.bin')) { $mime='application/vnd.openxmlformats-officedocument.wordprocessingml.document';$valid=TRUE; }
        if (!$valid) { throw new RuntimeException('فقط فایل معتبر PDF، JPG، PNG، DOC یا DOCX پذیرفته می‌شود.'); }
        return ['filename'=>$filename,'mime'=>$mime,'contents'=>$bytes,'checksum'=>hash('sha256',$bytes)];
    }
    private function document_metadata(array $in,array $record=[]): array {
        $category=$this->text($in['category']??(in_array($record['kind']??'',['contract','payslip','settlement'],TRUE)?$record['kind']:'other'),20);
        $categories=self::document_categories();
        if (!isset($categories[$category])) { throw new RuntimeException('دستهٔ مدرک را انتخاب کنید.'); }
        $subtype=$this->text($in['subtype']??array_key_first($categories[$category]['types']),30);
        if (!isset($categories[$category]['types'][$subtype])) { throw new RuntimeException('نوع مدرک با دسته انتخاب‌شده همخوان نیست.'); }
        if ($record&&in_array($category,['contract','payslip','settlement'],TRUE)&&$record['kind']!==$category) { throw new RuntimeException('مدرک باید به رکورد مرتبط همان دسته وصل شود.'); }
        $period=$this->text(nooshika_sanitize_numbers($in['period']??$record['period']??''),20);
        if ($category==='payslip') {
            if (!preg_match('/^(1[34]\d{2})[\/-](0?[1-9]|1[0-2])$/D',$period,$m)) { throw new RuntimeException('ماه فیش امضاشده را مانند ۱۴۰۵/۰۷ وارد کنید.'); }
            $period=$m[1].'/'.str_pad($m[2],2,'0',STR_PAD_LEFT);
            if ($record&&$record['period']!==$period) { throw new RuntimeException('ماه فایل با ماه فیش انتخاب‌شده برابر نیست.'); }
        } elseif ($period!=='') { $period=$this->text($period,20); }
        return ['category'=>$category,'subtype'=>$subtype,'title'=>$this->text($in['document_title']??$in['title']??$categories[$category]['types'][$subtype],190),'period'=>$period];
    }
    private function save_file_meta(int $file,array $meta,int $version): void {
        $this->require_ok($this->d->query($this->d->prepare("INSERT INTO {$this->p}hr_file_meta(file_id,category,subtype,title,period,version,updated_by,updated_at) VALUES(%d,%s,%s,%s,%s,%d,%d,%s) ON DUPLICATE KEY UPDATE category=VALUES(category),subtype=VALUES(subtype),title=VALUES(title),period=VALUES(period),version=VALUES(version),updated_by=VALUES(updated_by),updated_at=VALUES(updated_at)",$file,$meta['category'],$meta['subtype'],$meta['title'],$meta['period'],$version,get_current_user_id(),current_time('mysql'))));
    }
    public function attach_document(int $employee,int $record,array $file,array $input=[]): int {
        $this->guard();$this->employee($employee);$r=$record?$this->record($record,$employee):[];$upload=$this->validated_upload($file);$meta=$this->document_metadata($input,$r);
        $this->require_ok($this->d->query('START TRANSACTION'));
        try {
            $this->lock_employee($employee);
            $existing=$this->file_rows($this->file_select().$this->d->prepare(' WHERE f.employee_id=%d AND f.record_id=%d AND f.checksum=%s',$employee,$record,$upload['checksum']));
            foreach($existing as $same){if($same['category']===$meta['category']&&$same['subtype']===$meta['subtype']&&$same['period']===$meta['period']){$this->require_ok($this->d->query('COMMIT'));return (int)$same['id'];}}
            $this->require_ok($this->d->insert($this->p.'hr_files',$upload+['employee_id'=>$employee,'record_id'=>$record,'created_by'=>get_current_user_id(),'created_at'=>current_time('mysql')]));$id=(int)$this->d->insert_id;
            $this->save_file_meta($id,$meta,1);$this->audit($employee,$record,'attach',[],['file_id'=>$id,'filename'=>$upload['filename'],'checksum'=>$upload['checksum']]+$meta);
            $this->require_ok($this->d->query('COMMIT'));return $id;
        } catch (Throwable $e) { $this->d->query('ROLLBACK');throw $e; }
    }
    private function owned_file_meta(int $employee,int $id): array {
        $r=$this->file_rows($this->file_select().$this->d->prepare(' WHERE f.id=%d AND f.employee_id=%d FOR UPDATE',$id,$employee));
        if (!$r) { throw new RuntimeException('مدرک این پرسنل یافت نشد.'); } return $r[0];
    }
    public function replace_document(int $employee,int $id,int $version,array $file): void {
        $this->guard();$this->employee($employee);$upload=$this->validated_upload($file);$this->require_ok($this->d->query('START TRANSACTION'));
        try {
            $this->lock_employee($employee);$old=$this->owned_file_meta($employee,$id);
            if ((int)$old['version']!==$version) { throw new RuntimeException('مدرک تغییر کرده است؛ صفحه را تازه کنید.'); }
            $this->require_ok($this->d->update($this->p.'hr_files',$upload,['id'=>$id,'employee_id'=>$employee]));
            $this->save_file_meta($id,$old,$version+1);$this->audit($employee,(int)$old['record_id'],'replace_file',$old,['file_id'=>$id,'filename'=>$upload['filename'],'checksum'=>$upload['checksum'],'version'=>$version+1]);
            $this->require_ok($this->d->query('COMMIT'));
        } catch (Throwable $e) { $this->d->query('ROLLBACK');throw $e; }
    }
    public function delete_document(int $employee,int $id,int $version): void {
        $this->guard();$this->employee($employee);$this->require_ok($this->d->query('START TRANSACTION'));
        try {
            $this->lock_employee($employee);$old=$this->owned_file_meta($employee,$id);
            if ((int)$old['version']!==$version) { throw new RuntimeException('مدرک تغییر کرده است؛ صفحه را تازه کنید.'); }
            $this->require_ok($this->d->delete($this->p.'hr_file_meta',['file_id'=>$id]));$this->require_ok($this->d->delete($this->p.'hr_files',['id'=>$id,'employee_id'=>$employee]));
            $this->audit($employee,(int)$old['record_id'],'delete_file',$old,['file_id'=>$id]);$this->require_ok($this->d->query('COMMIT'));
        } catch (Throwable $e) { $this->d->query('ROLLBACK');throw $e; }
    }
}
