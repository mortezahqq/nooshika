<?php
if (!defined('ABSPATH')) { exit; }

/** Print-only layout. Saved amounts, dates, declarations and signatures are never recalculated. */
trait kph_hr_document_layout {
    private static function document_blocks(array $doc): array {
        $blocks = [];
        foreach ($doc['blocks'] as $block) {
            if ($doc['kind'] === 'contract' && $block['type'] === 'table') {
                $group = [];
                foreach ($block['rows'] as $i => $row) {
                    if (count($row) === 1) {
                        if ($group) { $blocks[] = self::table($group); $group = []; }
                        $cell = $row[0];
                        $paragraph = self::paragraph($cell['text'], $i === 0 ? 'center' : 'right', $cell['bold']);
                        $paragraph['role'] = $i === 0 ? 'title' : ($cell['bold'] ? 'section' : 'text');
                        $blocks[] = $paragraph;
                    } elseif (str_contains($row[0]['text'], 'امضا')) {
                        if ($group) { $blocks[] = self::table($group); $group = []; }
                        $signatures = self::table([$row]);
                        $signatures['role'] = 'signatures';
                        $blocks[] = $signatures;
                    } else { $group[] = $row; }
                }
                if ($group) { $blocks[] = self::table($group); }
                continue;
            }
            if ($block['type'] === 'table') {
                $first = $block['rows'][0] ?? [];
                $isSignatures = $first && !array_filter($first, static fn($cell) => !str_contains($cell['text'], 'امضا'));
                $block['role'] = $isSignatures ? 'signatures' : 'financial';
                if (!$isSignatures && count($block['widths']) === 3) {
                    $last = count($block['rows'])-1;
                    if (count($block['rows'][$last]) === 2) {
                        $block['rows'][$last][0]['span'] = 1;
                        $block['rows'][$last][1]['span'] = 2;
                    }
                }
                if (!$isSignatures && count($first) === 2) {
                    array_unshift($block['rows'], [self::c('شرح مزایا و کسورات', 1, TRUE), self::c('مبلغ (ریال)', 1, TRUE, 'center')]);
                }
            } elseif ($block['type'] === 'paragraph') {
                $block['role'] = $block['text'] === 'بسمه تعالی' ? 'invocation' : ($block['bold'] ? 'title' : 'text');
                if (str_starts_with($block['text'], 'پیش‌نویس') || str_starts_with($block['text'], 'وضعیت سند:')) { $block['role'] = 'status'; }
            }
            $blocks[] = $block;
        }
        return $blocks;
    }

    private static function document_letterhead(array $doc): string {
        $logo = $doc['logo'] ?? NULL;
        $image = '';
        if ($logo) {
            $scale = min(28 / $logo['width'], 16 / $logo['height']);
            $width = round($logo['width'] * $scale * 72 / 25.4, 2);
            $height = round($logo['height'] * $scale * 72 / 25.4, 2);
            $image = '<img width="'.$width.'" height="'.$height.'" src="data:'.$logo['mime'].';base64,'.base64_encode($logo['bytes']).'" alt="لوگوی شرکت">';
        }
        return '<table class="document-letterhead" dir="rtl" width="100%" cellpadding="3" cellspacing="0" style="border-bottom:1.2pt solid #344451;margin-bottom:3mm;"><tr>'
            .'<td width="22%" align="center" style="vertical-align:middle;">'.$image.'</td>'
            .'<td width="56%" align="center" style="font-size:14pt;vertical-align:middle;"><b>'.self::html_text($doc['company'] ?? 'منابع انسانی').'</b><br><span style="font-size:9pt;">امور اداری و منابع انسانی</span></td>'
            .'<td width="22%" align="center" style="font-size:9pt;vertical-align:middle;">شماره سند: '.self::digits($doc['record_id']).'<br>تاریخ: '.self::html_text($doc['created_date'] ?? '—').'</td>'
            .'</tr></table>';
    }

    private static function document_body(array $doc, bool $pdf = FALSE): string {
        $html = self::document_letterhead($doc);
        foreach (self::document_blocks($doc) as $block) {
            if ($block['type'] === 'pagebreak') {
                $html .= ($pdf ? '<br pagebreak="true" />' : '<div class="page-break"></div>').self::document_letterhead($doc);
                continue;
            }
            $role = $block['role'] ?? 'identity';
            if ($block['type'] === 'paragraph') {
                $size = ['title' => 14, 'section' => 11, 'invocation' => 9, 'status' => 9][$role] ?? 10.5;
                $space = ['title' => '2mm 0 4mm', 'section' => '0.7mm 0 0.6mm', 'invocation' => '1mm 0', 'status' => '1mm 0'][$role] ?? '1.3mm 0';
                $html .= '<p class="document-'.$role.'" align="'.$block['align'].'" style="font-size:'.$size.'pt;line-height:1.55;margin:'.$space.';text-align:'.$block['align'].';'.($block['bold'] ? 'font-weight:bold;' : '').($role === 'section' ? 'border-bottom:0.5pt solid #b8c2cc;padding-bottom:0.4mm;' : '').'">'.self::html_text($block['text']).'</p>';
                continue;
            }
            $signatures = $role === 'signatures';
            $financial = $role === 'financial';
            $rows = $block['rows'];
            $html .= '<table class="document-table document-'.$role.'" dir="rtl" width="100%" cellpadding="'.($signatures ? '5' : '2').'" cellspacing="0" border="1"'.($signatures ? ' nobr="true"' : '').' style="border-collapse:collapse;margin:2mm 0;">';
            foreach ($rows as $i => $row) {
                $header = $financial && $i === 0;
                $net = $financial && $i === count($rows) - 1;
                $shade = $signatures ? '#ffffff' : ($header || $net ? '#eaf0f4' : ($i % 2 ? '#f7f9fa' : '#ffffff'));
                if ($header) { $html .= '<thead>'; }
                $html .= '<tr>'; $column = 0;
                foreach ($row as $cell) {
                    $width = array_sum(array_slice($block['widths'], $column, $cell['span']));
                    $column += $cell['span'];
                    $align = $financial && $column > 1 ? 'center' : $cell['align'];
                    $html .= '<td width="'.$width.'%" colspan="'.$cell['span'].'" align="'.$align.'" bgcolor="'.$shade.'" style="vertical-align:'.($signatures ? 'top' : 'middle').';font-size:'.($net ? '11' : '10').'pt;line-height:1.45;padding:0.75mm 1.8mm;border:0.45pt solid #bac4cd;'.($cell['bold'] ? 'font-weight:bold;' : '').'">'.self::html_text($cell['text']).'</td>';
                }
                $html .= '</tr>';
                if ($header) { $html .= '</thead>'; }
            }
            $html .= '</table>'.($pdf ? '<div style="font-size:2pt;line-height:2pt;"> </div>' : '');
        }
        return $html;
    }

    /** Embedded local fonts also cover browser print and the smaller administrative forms. */
    public static function document_css(): string {
        $root = __DIR__.'/../assets/fonts/payslip/';
        $regular = base64_encode(file_get_contents($root.'Vazirmatn-Regular.ttf'));
        $bold = base64_encode(file_get_contents($root.'Vazirmatn-Bold.ttf'));
        return '@font-face{font-family:KphDocument;src:url(data:font/ttf;base64,'.$regular.') format("truetype");font-weight:400}@font-face{font-family:KphDocument;src:url(data:font/ttf;base64,'.$bold.') format("truetype");font-weight:700}'
            .'@page{size:A4 portrait;margin:14mm}*{box-sizing:border-box}body{font-family:KphDocument,Tahoma,sans-serif;direction:rtl;color:#253541;background:#fff;font-size:10.5pt;line-height:1.55;width:210mm;margin:0 auto;padding:14mm}table{width:100%;border-collapse:collapse;table-layout:fixed}td,th{overflow-wrap:anywhere}tr{break-inside:avoid}thead{display:table-header-group}.document-section{break-after:avoid}.document-signatures{break-inside:avoid;margin-top:3mm!important}.document-signatures td{height:22mm!important;border-top:0.5pt solid #bac4cd!important;padding-top:3mm!important}.page-break{break-before:page}.print-controls,.actions{display:flex;gap:10px;margin-bottom:6mm;font-family:inherit}.print-controls a,.print-controls button,.actions button{font:inherit;padding:7px 12px}.document-letterhead img{object-fit:contain;max-width:100%}@media print{html,body{width:auto;margin:0;padding:0}.print-controls,.actions{display:none}table,td{-webkit-print-color-adjust:exact;print-color-adjust:exact}}@media screen and (max-width:820px){body{width:100%;padding:16px}}';
    }

    private static function document_html(array $doc): string {
        return '<!doctype html><html lang="fa" dir="rtl"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'.htmlspecialchars($doc['title'],ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8').'</title><style>'.self::document_css().'</style></head><body>'.self::document_body($doc).'</body></html>';
    }

    private static function document_pdf(array $doc): string {
        if (!class_exists('TCPDF')) { require_once __DIR__.'/../vendor/tcpdf/tcpdf.php'; }
        if (!empty($doc['logo']) && $doc['logo']['mime'] === 'image/png' && in_array(ord($doc['logo']['bytes'][25] ?? "\0"),[4,6],TRUE) && !function_exists('imagecreatefrompng') && !class_exists('Imagick')) {
            $opaque = self::payslip_opaque_png($doc['logo']['bytes']);
            if ($opaque !== NULL) { $doc['logo']['bytes'] = $opaque; } else { $doc['logo'] = NULL; }
        }
        $pdf = new class('P','mm','A4',TRUE,'UTF-8',FALSE) extends TCPDF {
            public function Footer() {
                $this->SetY(-11); $this->SetDrawColor(186,196,205);
                $this->Line(14,$this->GetY(),196,$this->GetY());
                $this->SetFont('vazirmatn','',8); $this->SetTextColor(90,105,118);
                $this->Cell(0,6,'صفحه '.kph_hr_exports::digits($this->getPage()),0,0,'C');
            }
        };
        $pdf->setPrintHeader(FALSE); $pdf->setPrintFooter(TRUE);
        $pdf->SetCreator('Kasebi Process Hub'); $pdf->SetTitle($doc['title']);
        $pdf->SetMargins(14,14,14); $pdf->SetAutoPageBreak(TRUE,16); $pdf->setRTL(TRUE);
        $fonts = __DIR__.'/../vendor/tcpdf/fonts/payslip/';
        $pdf->AddFont('vazirmatn','',$fonts.'vazirmatn.php',TRUE);
        $pdf->AddFont('vazirmatn','B',$fonts.'vazirmatnb.php',TRUE);
        $pdf->SetFont('vazirmatn','',10.5); $pdf->setCellHeightRatio(1.55);
        $pdf->setHtmlVSpace([
            'p' => [0 => ['h'=>0.8,'n'=>1], 1 => ['h'=>1.2,'n'=>1]],
            'table' => [0 => ['h'=>1,'n'=>1], 1 => ['h'=>1,'n'=>1]],
            'div' => [0 => ['h'=>0.2,'n'=>1], 1 => ['h'=>0.2,'n'=>1]],
        ]);
        $pdf->SetTextColor(37,53,65); $pdf->SetDrawColor(186,196,205); $pdf->AddPage();
        $pdf->writeHTML(self::document_body($doc,TRUE),TRUE,FALSE,TRUE,FALSE,'');
        return $pdf->Output('hr-'.$doc['kind'].'-'.$doc['record_id'].'.pdf','S');
    }

    private static function document_word_paragraph(string $text, string $align = 'right', bool $bold = FALSE, int $size = 21, bool $keepNext = FALSE, bool $inTable = FALSE): string {
        $runs = '';
        foreach (explode("\n",$text) as $i => $line) {
            if ($i) { $runs .= '<w:r><w:br/></w:r>'; }
            $runs .= '<w:r><w:rPr><w:rFonts w:ascii="Vazirmatn" w:hAnsi="Vazirmatn" w:cs="Vazirmatn"/><w:rtl/><w:sz w:val="'.$size.'"/><w:szCs w:val="'.$size.'"/>'.($bold ? '<w:b/><w:bCs/>' : '').'<w:color w:val="253541"/></w:rPr><w:t xml:space="preserve">'.self::xml($line).'</w:t></w:r>';
        }
        $align = ['right'=>'start','left'=>'end'][$align] ?? $align;
        $space = $inTable ? 0 : 25;
        return '<w:p><w:pPr><w:bidi/><w:jc w:val="'.$align.'"/>'.($keepNext ? '<w:keepNext/>' : '').'<w:widowControl/><w:spacing w:before="'.$space.'" w:after="'.$space.'" w:line="'.($size*14).'" w:lineRule="exact"/></w:pPr>'.$runs.'</w:p>';
    }

    private static function document_docx(array $doc): string {
        $width = 10318; // A4 with 14 mm margins.
        $logo = $doc['logo'] ?? NULL;
        $paragraph = static fn($text,$align='right',$bold=FALSE) => self::document_word_paragraph($text,$align,$bold);
        $header = ['caption'=>'امور اداری و منابع انسانی','company'=>$doc['company'] ?? 'منابع انسانی','period'=>$doc['created_date'] ?? '—','reference'=>self::digits($doc['record_id'])];
        $content = self::payslip_word_header($header,$logo,$width,$paragraph);
        foreach (self::document_blocks($doc) as $block) {
            if ($block['type'] === 'pagebreak') {
                $content .= '<w:p><w:r><w:br w:type="page"/></w:r></w:p>'.self::payslip_word_header($header,$logo,$width,$paragraph);
                continue;
            }
            $role = $block['role'] ?? 'identity';
            if ($block['type'] === 'paragraph') {
                $size = ['title'=>28,'section'=>22,'invocation'=>18,'status'=>18][$role] ?? 21;
                $content .= self::document_word_paragraph($block['text'],$block['align'],$block['bold'],$size,in_array($role,['title','section','invocation','status'],TRUE));
                continue;
            }
            $financial = $role === 'financial'; $signatures = $role === 'signatures';
            $content .= '<w:tbl><w:tblPr><w:bidiVisual/><w:tblW w:w="'.$width.'" w:type="dxa"/><w:tblLayout w:type="fixed"/><w:tblBorders>';
            foreach (['top','left','bottom','right','insideH','insideV'] as $side) {
                $content .= '<w:'.$side.' w:val="single" w:sz="4" w:color="BAC4CD"/>';
            }
            $content .= '</w:tblBorders><w:tblCellMar><w:top w:w="45" w:type="dxa"/><w:bottom w:w="45" w:type="dxa"/><w:left w:w="100" w:type="dxa"/><w:right w:w="100" w:type="dxa"/></w:tblCellMar></w:tblPr><w:tblGrid>';
            foreach ($block['widths'] as $size) { $content .= '<w:gridCol w:w="'.(int)round($width*$size/100).'"/>'; }
            $content .= '</w:tblGrid>';
            foreach ($block['rows'] as $i => $row) {
                $isHeader = $financial && $i === 0;
                $shade = $signatures ? 'FFFFFF' : ($isHeader || ($financial && $i === count($block['rows'])-1) ? 'EAF0F4' : ($i%2 ? 'F7F9FA' : 'FFFFFF'));
                $content .= '<w:tr><w:trPr><w:cantSplit/>'.($isHeader ? '<w:tblHeader/>' : '').($signatures ? '<w:trHeight w:val="1360" w:hRule="atLeast"/>' : '').'</w:trPr>';
                $column = 0;
                foreach ($row as $cell) {
                    $cellWidth = array_sum(array_slice($block['widths'],$column,$cell['span']));
                    $column += $cell['span'];
                    $content .= '<w:tc><w:tcPr><w:tcW w:w="'.(int)round($width*$cellWidth/100).'" w:type="dxa"/><w:gridSpan w:val="'.$cell['span'].'"/><w:vAlign w:val="'.($signatures ? 'top' : 'center').'"/><w:shd w:val="clear" w:fill="'.$shade.'"/></w:tcPr>'.self::document_word_paragraph($cell['text'],$financial && $column>1 ? 'center' : $cell['align'],$cell['bold'],20,FALSE,TRUE).'</w:tc>';
                }
                $content .= '</w:tr>';
            }
            $content .= '</w:tbl><w:p><w:pPr><w:spacing w:before="0" w:after="0" w:line="40" w:lineRule="exact"/></w:pPr></w:p>';
        }
        $drawingId = 0;
        $content = preg_replace_callback('/<wp:docPr id="1"/',static function() use (&$drawingId) { return '<wp:docPr id="'.(++$drawingId).'"'; },$content);
        $xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
        $ns = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships';
        $files = [
            '[Content_Types].xml'=>$xml.'<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/><Override PartName="/word/footer1.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml"/></Types>',
            '_rels/.rels'=>$xml.'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="'.$ns.'/officeDocument" Target="word/document.xml"/></Relationships>',
            'word/document.xml'=>$xml.'<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="'.$ns.'"><w:body>'.$content.'<w:sectPr><w:footerReference w:type="default" r:id="rIdFooter"/><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="794" w:right="794" w:bottom="907" w:left="794" w:footer="340"/><w:bidi/></w:sectPr></w:body></w:document>',
            'word/styles.xml'=>$xml.'<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Vazirmatn" w:hAnsi="Vazirmatn" w:cs="Vazirmatn"/><w:lang w:val="fa-IR" w:bidi="fa-IR"/></w:rPr></w:rPrDefault></w:docDefaults></w:styles>',
            'word/footer1.xml'=>$xml.'<w:ftr xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:p><w:pPr><w:bidi/><w:jc w:val="center"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Vazirmatn" w:hAnsi="Vazirmatn" w:cs="Vazirmatn"/><w:sz w:val="16"/><w:szCs w:val="16"/></w:rPr><w:t>صفحه </w:t></w:r><w:fldSimple w:instr="PAGE"/></w:p></w:ftr>',
            'word/_rels/document.xml.rels'=>$xml.'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rIdStyles" Type="'.$ns.'/styles" Target="styles.xml"/><Relationship Id="rIdFooter" Type="'.$ns.'/footer" Target="footer1.xml"/></Relationships>',
        ];
        if ($logo) {
            $extension = $logo['mime'] === 'image/png' ? 'png' : 'jpg';
            $files['word/media/company-logo.'.$extension] = $logo['bytes'];
            $files['[Content_Types].xml'] = str_replace('</Types>','<Default Extension="'.$extension.'" ContentType="'.$logo['mime'].'"/></Types>',$files['[Content_Types].xml']);
            $files['word/_rels/document.xml.rels'] = str_replace('</Relationships>','<Relationship Id="rIdCompanyLogo" Type="'.$ns.'/image" Target="media/company-logo.'.$extension.'"/></Relationships>',$files['word/_rels/document.xml.rels']);
        }
        return self::zip(self::payslip_word_fonts($files));
    }
}
