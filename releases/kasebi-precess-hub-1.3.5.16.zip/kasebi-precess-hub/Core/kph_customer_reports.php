<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

trait kph_customer_reports {
	public function get_all_customer_report_rows( array $args ): array {
		$rows = []; $page = 1;
		do {
			$report = $this->get_users_performance_report( array_merge( $args, [ 'page' => $page, 'per_page' => 200 ] ) );
			$rows = array_merge( $rows, $report['items'] );
			$page++;
		} while ( $page <= $report['pagination']['total_page'] && $report['items'] );
		return $rows;
	}

	public function get_customer_report_aging( array $rows ): array {
		$result = [];
		foreach ( array_chunk( array_column( $rows, 'user_id' ), 200 ) as $ids ) {
			$result += $this->get_customer_receivables_report( $ids );
		}
		return $result;
	}
	public function normalize_customer_payment_term( $value ): ?string {
		if ( ! is_scalar( $value ) ) { return NULL; }
		$value = trim( strtr( (string) $value, array_combine( preg_split( '//u', '۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩', -1, PREG_SPLIT_NO_EMPTY ), str_split( '01234567890123456789' ) ) ) );
		if ( $value === '' ) { return ''; }
		return preg_match( '/^\d{1,4}$/D', $value ) && (int) $value <= 3650 ? (string) (int) $value : NULL;
	}

	public function save_customer_payment_term( int $order_id, $value ): array {
		$term = $this->normalize_customer_payment_term( $value );
		if ( $term === NULL ) { return $this->fail( 'مهلت تسویه باید عدد صحیح بین صفر تا ۳۶۵۰ روز باشد.' ); }
		if ( ! $this->db->get_var( $this->db->prepare( "SELECT id FROM {$this->orders} WHERE id = %d", $order_id ) ) ) {
			return $this->fail( 'فاکتور یافت نشد.' );
		}
		$this->db->query( 'START TRANSACTION' );
		$result = $this->update_meta( 'orders', $order_id, 'payment_term_days', $term );
		$this->db->query( $result['status'] === 'success' ? 'COMMIT' : 'ROLLBACK' );
		return $result;
	}

	/** Load metadata once per batch; duplicate historical meta must never multiply amounts. */
	private function customer_report_orders( array $customer_ids ): array {
		$ids = implode( ',', array_filter( array_map( 'absint', $customer_ids ) ) );
		if ( ! $ids ) { return []; }
		$display_status_sql = $this->order_display_status_sql( 'o' );
		$orders = $this->db->get_results( "SELECT o.* FROM {$this->orders} o WHERE o.customer_id IN ($ids)
			AND ($display_status_sql) IN ('registered','shipped','shortage') ORDER BY o.created_at, o.id", ARRAY_A );
        if ($this->db->last_error) { throw new RuntimeException('خواندن فاکتورهای سررسید انجام نشد.'); }
		if ( ! $orders ) { return []; }
		$order_ids = implode( ',', array_map( 'absint', array_column( $orders, 'id' ) ) );
		[ $meta_table, $fk ] = $this->resolve_meta_table( 'orders' );
		$metadata = $this->db->get_results( "SELECT $fk AS order_id, meta_key, meta_value FROM $meta_table
			WHERE $fk IN ($order_ids) AND meta_key IN ('factor_date','factor_number','payment_term_days') ORDER BY id", ARRAY_A );
        if ($this->db->last_error) { throw new RuntimeException('خواندن مهلت فاکتورها انجام نشد.'); }
		$actual_due = [];
        $due_table = $this->db_prefix . 'erp_due_dates';
        $has_due_table = $this->db->get_var($this->db->prepare('SHOW TABLES LIKE %s', $this->db->esc_like($due_table)));
        if ($this->db->last_error) { throw new RuntimeException('خواندن سررسید دستی انجام نشد.'); }
        if ($has_due_table) {
            $due_rows = $this->db->get_results("SELECT invoice_id,due_on FROM {$due_table} WHERE kind='customer' AND invoice_id IN ($order_ids)", ARRAY_A);
            if ($this->db->last_error) { throw new RuntimeException('خواندن سررسید دستی انجام نشد.'); }
            foreach ($due_rows as $due) {
                $actual_due[(int)$due['invoice_id']] = $due['due_on'];
            }
        }
		$by_id = [];
		foreach ( $metadata as $meta ) { $by_id[(int) $meta['order_id']][$meta['meta_key']] = $meta['meta_value']; }
		foreach ( $orders as &$order ) {
			$order['meta'] = $by_id[(int) $order['id']] ?? [];
			$order['invoice_number'] = ! empty( $order['meta']['factor_number'] ) ? $order['meta']['factor_number'] : $order['order_number'];
			$order['invoice_date'] = substr( $order['registered_at'] ?: $order['created_at'], 0, 10 );
			$factor_date = strtr( $order['meta']['factor_date'] ?? '', [ '۰'=>'0', '۱'=>'1', '۲'=>'2', '۳'=>'3', '۴'=>'4', '۵'=>'5', '۶'=>'6', '۷'=>'7', '۸'=>'8', '۹'=>'9' ] );
			if ( preg_match( '/^[0-9]{4}[-\/][0-9]{2}[-\/][0-9]{2}$/D', $factor_date ) ) {
				$normalized_date = str_replace( '/', '-', $factor_date );
				$converted = (int) substr( $normalized_date, 0, 4 ) < 1700 ? nooshika_jalali_to_gregorian( $normalized_date ) : $normalized_date;
				$parsed = DateTimeImmutable::createFromFormat( '!Y-m-d', (string) $converted, wp_timezone() );
				if ( $parsed && $parsed->format( 'Y-m-d' ) === $converted ) { $order['invoice_date'] = $converted; }
			}
            $order['actual_due_date'] = $actual_due[(int)$order['id']] ?? '';
			$order['payment_term_days'] = $this->normalize_customer_payment_term( $order['meta']['payment_term_days'] ?? '' );
		}
		unset( $order );
		return $orders;
	}

	public function get_customer_invoice_report( int $customer_id, array $args = [] ): array {
		$orders = array_filter( $this->customer_report_orders( [ $customer_id ] ), static function ( $order ) use ( $args ) {
			$date = substr( $order['created_at'], 0, 10 );
			return ( empty( $args['date_from'] ) || $date >= $args['date_from'] )
				&& ( empty( $args['date_to'] ) || $date <= $args['date_to'] )
				&& ( empty( $args['order_id'] ) || (int) $order['id'] === (int) $args['order_id'] );
		} );
        if ($this->db->last_error) { throw new RuntimeException('خواندن فاکتورهای سررسید انجام نشد.'); }
		if ( ! $orders ) { return []; }
		$ids = implode( ',', array_map( 'absint', array_column( $orders, 'id' ) ) );
		$items = $this->db->get_results( "SELECT * FROM {$this->order_items} WHERE order_id IN ($ids)
			AND (qty_ordered <> 0 OR expected_free_qty <> 0 OR shipped_paid_qty <> 0 OR shipped_free_qty <> 0 OR final_amount <> 0 OR cogs_total <> 0)
			ORDER BY order_id, id", ARRAY_A );
		$grouped = [];
		foreach ( $items as $item ) {
			$item['sales'] = (float) $item['qty_ordered'] > 0 ? (float) $item['final_amount'] / $item['qty_ordered'] * $item['shipped_paid_qty'] : 0;
			$item['profit'] = $item['sales'] - (float) $item['cogs_total'];
			$item['title'] = get_the_title( (int) $item['wc_product_id'] ) ?: 'محصول حذف‌شده / ' . $item['unique_product_code'];
			$grouped[(int) $item['order_id']][] = $item;
		}
		foreach ( $orders as &$order ) {
			$order['items'] = $grouped[(int) $order['id']] ?? [];
			$order['totals'] = [];
			foreach ( [ 'final_amount', 'sales', 'cogs_total', 'profit' ] as $key ) {
				$order['totals'][$key] = array_sum( array_column( $order['items'], $key ) );
			}
		}
		unset( $order );
		return array_values( $orders );
	}

	/** Current account aging: exact invoice links first, then unmatched credits oldest invoice first. */
	public function get_customer_receivables_report( array $customer_ids ): array {
		$ids = implode( ',', array_filter( array_map( 'absint', $customer_ids ) ) );
		if ( ! $ids ) { return []; }
		$orders = $this->customer_report_orders( $customer_ids );
		[ $meta_table, $fk ] = $this->resolve_meta_table( 'ledger_entry' );
		$entries = $this->db->get_results( $this->db->prepare( "SELECT l.*, COALESCE(
			(SELECT m.meta_value FROM $meta_table m WHERE m.$fk = l.id AND m.meta_key = 'order_id' ORDER BY m.id DESC LIMIT 1),
			(SELECT f.order_id FROM {$this->fulfillments} f WHERE l.ref_type = 'fulfillment' AND f.id = l.ref_id)) AS linked_order_id
			FROM {$this->ledger_entries} l WHERE l.user_id IN ($ids) AND l.posted_at <= %s ORDER BY l.posted_at, l.id", current_time( 'mysql' ) ), ARRAY_A );
        if ($this->db->last_error) { throw new RuntimeException('خواندن ماندهٔ سررسید انجام نشد.'); }
		return $this->calculate_customer_receivables( $orders, $entries, current_time( 'Y-m-d' ) );
	}

	public function calculate_customer_receivables( array $orders, array $entries, string $today ): array {
		$customers = []; $index = [];
		foreach ( $orders as $order ) {
			$id = (int) $order['id']; $user = (int) $order['customer_id'];
			$order['balance'] = 0.0; $order['allocated'] = 0.0;
			$customers[$user]['invoices'][$id] = $order;
			$index[$id] = $user;
		}
		foreach ( $entries as $entry ) {
			$user = (int) $entry['user_id']; $id = (int) ( $entry['linked_order_id'] ?? 0 );
			$amount = ( $entry['type'] === 'debit' ? 1 : -1 ) * (float) $entry['amount'];
			if ( isset( $index[$id] ) && $index[$id] === $user ) {
				$customers[$user]['invoices'][$id]['balance'] += $amount;
			} else {
				$customers[$user]['unassigned'] = ( $customers[$user]['unassigned'] ?? 0 ) + $amount;
			}
		}
		$now = new DateTimeImmutable( $today, wp_timezone() );
		foreach ( $customers as &$customer ) {
			$customer += [ 'invoices' => [], 'unassigned' => 0 ];
			$net_unassigned = $customer['unassigned'];
			foreach ( $customer['invoices'] as &$invoice ) {
				// Excess explicitly linked payments remain customer credit, never negative debt.
				$net_unassigned -= max( 0, -$invoice['balance'] );
				$invoice['balance'] = max( 0, $invoice['balance'] );
			}
			unset( $invoice );
			$credit = max( 0, -$net_unassigned );
			uasort( $customer['invoices'], static fn( $a, $b ) => [ $a['invoice_date'], (int) $a['id'] ] <=> [ $b['invoice_date'], (int) $b['id'] ] );
			$customer += [ 'overdue' => 0.0, 'upcoming' => 0.0, 'unknown' => 0.0, 'open_count' => 0, 'weighted_days' => 0.0, 'dated_balance' => 0.0 ];
			foreach ( $customer['invoices'] as &$invoice ) {
				$invoice['allocated'] = min( $credit, $invoice['balance'] );
				$invoice['balance'] -= $invoice['allocated']; $credit -= $invoice['allocated'];
				$term = $invoice['payment_term_days']; $invoice['due_date'] = ''; $invoice['days'] = NULL;
				$invoice['state'] = $invoice['balance'] < 0.01 ? 'settled' : 'unknown';
				if ( !empty($invoice['actual_due_date']) || ($term !== '' && $term !== NULL) ) {
                    $due = !empty($invoice['actual_due_date']) ? new DateTimeImmutable($invoice['actual_due_date'], wp_timezone()) : ( new DateTimeImmutable( $invoice['invoice_date'], wp_timezone() ) )->modify( '+' . (int) $term . ' days' );
					$invoice['due_date'] = $due->format( 'Y-m-d' );
					$invoice['days'] = (int) $now->diff( $due )->format( '%r%a' );
					if ( $invoice['balance'] >= 0.01 ) { $invoice['state'] = $invoice['days'] < 0 ? 'overdue' : 'upcoming'; }
				}
				if ( $invoice['balance'] >= 0.01 ) {
					$customer['open_count']++;
					$customer[$invoice['state']] += $invoice['balance'];
					if ( $invoice['days'] !== NULL ) {
						$customer['dated_balance'] += $invoice['balance'];
						$customer['weighted_days'] += $invoice['balance'] * $invoice['days'];
					}
				}
			}
			unset( $invoice );
			$customer['average_days'] = $customer['dated_balance'] > 0 ? round( $customer['weighted_days'] / $customer['dated_balance'], 1 ) : NULL;
			$customer['unassigned_debt'] = max( 0, $net_unassigned );
			$customer['credit'] = $credit;
		}
		unset( $customer );
		return $customers;
	}
}
