<?php
if(!defined('ABSPATH')){exit;}

trait kph_order_dates {
    public function can_edit_order_shipment_date(int $order_id): bool {
        if(!get_current_user_id()||$order_id<=0)return false;
        $role=nooshika_get_user_role(get_current_user_id());
        if(!current_user_can('manage_options')&&!in_array($role,['administrator','accountant','supp','visitor'],true))return false;
        return $this->visitor_can_access_order($order_id);
    }
    public function update_order_shipment_date_inline(int $id,$value,$expected): array {
        if(!$this->can_edit_order_shipment_date($id))return $this->fail('اجازه ویرایش تاریخ این سفارش را ندارید.');
        if(!is_string($value)||!is_string($expected))return $this->fail('تاریخ معتبر وارد کنید.');
        try{
            $date=trim($value)===''?'':kph_hr_calendar::display(kph_hr_calendar::normalize(trim($value)));
            foreach([$this->orders,$this->db_prefix.'orders_meta',$this->actions_table,$this->db_prefix.'action_meta'] as $table){
                $row=$this->db->get_row($this->db->prepare('SHOW TABLE STATUS LIKE %s',$this->db->esc_like($table)),ARRAY_A);
                if(!$row||strcasecmp((string)$row['Engine'],'InnoDB'))throw new RuntimeException('جدول‌های سفارش و سوابق باید InnoDB باشند.');
            }
            if(false===$this->db->query('START TRANSACTION'))throw new RuntimeException('شروع ثبت تاریخ ناموفق بود.');
            $order=$this->db->get_row($this->db->prepare("SELECT id,customer_id,status FROM {$this->orders} WHERE id=%d FOR UPDATE",$id),ARRAY_A);
            if(!$order||$order['status']==='canceled')throw new RuntimeException('سفارش پیدا نشد یا باطل شده است.');
            $rows=$this->db->get_results($this->db->prepare("SELECT meta_value FROM {$this->db_prefix}orders_meta WHERE order_id=%d AND meta_key='shipment_date' ORDER BY id FOR UPDATE",$id),ARRAY_A);
            if($this->db->last_error)throw new RuntimeException('خواندن تاریخ سفارش ناموفق بود.');
            $stored=isset($rows[0])?maybe_unserialize($rows[0]['meta_value']):'';
            if(!is_scalar($stored)&&$stored!==null)throw new RuntimeException('تاریخ قبلی این سفارش نیاز به بررسی دارد.');
            $current=(string)$stored;
            if(!hash_equals($current,$expected))throw new RuntimeException('تاریخ این سفارش هم‌زمان تغییر کرده است؛ صفحه را تازه کنید.');
            if($date!==$current){
                $result=$this->update_meta('orders',$id,'shipment_date',$date);
                if(($result['status']??'')!=='success')throw new RuntimeException('ذخیره تاریخ ارسال انجام نشد.');
                if(false===$this->db->update($this->orders,['updated_at'=>current_time('mysql')],['id'=>$id]))throw new RuntimeException('به‌روزرسانی سفارش انجام نشد.');
                if(!$this->db->insert($this->actions_table,['user_id'=>(int)$order['customer_id']?:get_current_user_id(),'title'=>'ویرایش تاریخ ارسال سفارش #'.$id,'content'=>esc_html($current?:'بدون تاریخ').' ← '.esc_html($date?:'بدون تاریخ'),'date'=>current_time('mysql'),'creator'=>get_current_user_id()]))throw new RuntimeException('ثبت سابقه تغییر تاریخ ناموفق بود.');
                $audit=(int)$this->db->insert_id;
                $result=$this->save_meta_batch('action',$audit,['type'=>'order_shipment_date','order_id'=>$id,'previous_date'=>$current,'new_date'=>$date]);
                if(($result['status']??'')!=='success')throw new RuntimeException('ثبت سابقه تغییر تاریخ ناموفق بود.');
            }
            if(false===$this->db->query('COMMIT'))throw new RuntimeException('ثبت نهایی تاریخ انجام نشد.');
            return $this->ok('تاریخ ارسال ذخیره شد.',['order_id'=>$id,'date'=>$date,'label'=>$date?:'—']);
        }catch(Throwable $e){$this->db->query('ROLLBACK');return $this->fail($e->getMessage());}
    }
}
