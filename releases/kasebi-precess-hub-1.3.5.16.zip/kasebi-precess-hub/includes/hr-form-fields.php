<?php
if (!defined('ABSPATH')) { exit; }

function kph_hr_person_fields(): array {
    return ['person_name'=>['نام و نام خانوادگی','text'],'person_father_name'=>['نام پدر','text'],'person_national_id'=>['کد ملی','text'],'person_identity_no'=>['شماره شناسنامه','text'],'person_birth_date'=>['تاریخ تولد','date'],'person_birth_place'=>['محل تولد','text'],'person_issue_place'=>['محل صدور شناسنامه','text'],'person_phone'=>['تلفن پرسنل','text'],'person_job_title'=>['سمت پرسنل','text'],'person_department'=>['واحد','text'],'person_employee_no'=>['کد پرسنلی','text'],'person_insurance_no'=>['شماره بیمه','text'],'person_address'=>['نشانی پرسنل','textarea']];
}
function kph_hr_employer_fields(): array {
    return ['company_name'=>['نام شرکت / کارگاه','text'],'employer_name'=>['نام کارفرما / نماینده','text'],'employer_national_id'=>['کد ملی / شناسه ملی کارفرما','text'],'company_registration'=>['شماره ثبت','text'],'employer_phone'=>['تلفن کارفرما','text'],'employer_address'=>['نشانی کارفرما','textarea'],'workplace_address'=>['محل انجام کار','textarea']];
}
function kph_hr_form_groups(string $kind): array {
    $person=['title'=>'مشخصات پرسنل','fields'=>kph_hr_person_fields(),'open'=>FALSE];$employer=['title'=>'اطلاعات کارفرما و کارگاه','fields'=>kph_hr_employer_fields(),'open'=>FALSE];
    if ($kind==='contract') {
        return [
            ['title'=>'اطلاعات اصلی قرارداد','open'=>TRUE,'fields'=>['title'=>['عنوان و نوع قرارداد','text'],'contract_date'=>['تاریخ تنظیم قرارداد','date'],'date_from'=>['تاریخ شروع قرارداد','date'],'date_to'=>['تاریخ پایان قرارداد (اختیاری)','date'],'job_title'=>['عنوان شغلی قرارداد','text'],'duties'=>['شرح وظایف','textarea']]],
            $employer,$person,
            ['title'=>'حقوق و مزایا','open'=>TRUE,'fields'=>['basis'=>['مبنای حقوق','select',['monthly'=>'ماهانه','daily'=>'روزانه','hourly'=>'ساعتی']],'rate'=>['حقوق پایه / نرخ مطابق مبنا (ریال)','number'],'normal_days'=>['روزهای مبنای حقوق ماهانه','number'],'overtime_rate'=>['نرخ هر ساعت اضافه‌کاری (ریال)','number'],'housing'=>['حق مسکن (ریال)','number'],'food_allowance'=>['بن کارگری (ریال)','number'],'marriage_allowance'=>['حق تأهل (ریال)','number'],'child_allowance'=>['حق اولاد (ریال)','number'],'seniority_daily_rate'=>['پایه سنوات تجمیعی روزانه (ریال)','number'],'benefits_text'=>['شرایط پرداخت مزایا','textarea'],'insurance_tax_text'=>['شرایط بیمه و مالیات','textarea']]],
            ['title'=>'ساعات کاری و سایر شرایط','open'=>FALSE,'fields'=>['working_hours_text'=>['ساعات کاری و شرایط اضافه‌کاری / کسرکار','textarea'],'termination_terms'=>['شرایط خاتمه / فسخ','textarea'],'other_conditions'=>['سایر شرایط قرارداد','textarea'],'terms'=>['توضیحات تکمیلی قرارداد','textarea'],'public_notes'=>['توضیح قابل چاپ','textarea'],'notes'=>['یادداشت داخلی (چاپ نمی‌شود)','textarea']]],
        ];
    }
    if ($kind==='payslip') {
        $months=['01'=>'فروردین','02'=>'اردیبهشت','03'=>'خرداد','04'=>'تیر','05'=>'مرداد','06'=>'شهریور','07'=>'مهر','08'=>'آبان','09'=>'آذر','10'=>'دی','11'=>'بهمن','12'=>'اسفند'];
        return [
            ['title'=>'ماه حقوق و روش محاسبه','open'=>TRUE,'fields'=>['title'=>['عنوان فیش (اختیاری)','text'],'salary_year'=>['سال حقوق (شمسی)','number'],'salary_month'=>['ماه حقوق','select',$months],'calculation_mode'=>['مبنای تعیین مزد','select',['manual'=>'ثبت مزد روزانه به‌صورت دستی','contract'=>'استفاده از قرارداد تأییدشده پرسنل']],'contract_id'=>['قرارداد (فقط در روش قراردادی)','contract'],'work_source'=>['اضافه‌کاری و ساعات عادی','select',['manual'=>'ثبت دستی در همین فیش','attendance'=>'خواندن از کارکردهای تأییدشده ماه']]]],
            ['title'=>'مزد روزانه و کارکرد دوره','open'=>TRUE,'fields'=>['monthly_base'=>['مزد روزانه (ریال)','number'],'normal_days'=>['روزهای مبنا؛ معمولاً ۳۰ روز','number'],'paid_days'=>['روزهای مشمول حقوق؛ پس از کسر غیبت و بدون حقوق','number'],'worked_hours'=>['کارکرد عادی (ساعت؛ برای قرارداد ساعتی)','number']]],
            ['title'=>'مزایا و پرداخت‌های این ماه','open'=>TRUE,'fields'=>['housing'=>['حق مسکن این فیش (ریال)','number'],'food_allowance'=>['بن کارگری این فیش (ریال)','number'],'marriage_allowance'=>['حق تأهل این فیش (ریال)','number'],'child_count'=>['تعداد فرزند','number'],'child_allowance'=>['جمع حق اولاد این فیش (ریال)','number'],'seniority_daily_rate'=>['پایه سنوات تجمیعی روزانه (ریال)','number'],'seniority_base'=>['پایه سنوات این ماه؛ محاسبه خودکار (ریال)','number'],'benefits'=>['سایر مزایا (ریال)','number'],'bonus'=>['پاداش (ریال)','number']]],
            ['title'=>'اضافه‌کاری، شب‌کاری، جمعه‌کاری و مأموریت','open'=>FALSE,'fields'=>['overtime_hours'=>['اضافه‌کاری (ساعت)','number'],'overtime_rate'=>['نرخ هر ساعت اضافه‌کاری (ریال)','number'],'night_hours'=>['شب‌کاری (ساعت)','number'],'night_rate'=>['نرخ هر ساعت شب‌کاری (ریال)','number'],'friday_days'=>['جمعه‌کاری (روز)','number'],'friday_rate'=>['نرخ هر روز جمعه‌کاری (ریال)','number'],'mission_days'=>['مأموریت (روز)','number'],'mission_rate'=>['نرخ هر روز مأموریت (ریال)','number']]],
            ['title'=>'کسورات و مساعده','open'=>TRUE,'fields'=>['insurance'=>['بیمه سهم پرسنل (ریال؛ مبلغ همین ماه)','number'],'tax'=>['مالیات (ریال؛ مبلغ همین ماه)','number'],'shortage_hours'=>['کسرکار (ساعت)','number'],'shortage_rate'=>['نرخ هر ساعت کسرکار (ریال)','number'],'deductions'=>['سایر کسورات واقعی (ریال)','number'],'paid_advance'=>['مساعده پرداخت‌شده و ثبت‌شده در حسابداری (ریال)','number']]],
            $person,$employer,
            ['title'=>'توضیحات','open'=>FALSE,'fields'=>['public_notes'=>['توضیحات قابل چاپ روی فیش','textarea'],'notes'=>['یادداشت داخلی (چاپ نمی‌شود)','textarea']]],
        ];
    }
    return [
        ['title'=>'مدل و بازه تسویه','open'=>TRUE,'fields'=>['template'=>['مدل فرم','select',kph_hr::settlement_templates()],'title'=>['عنوان پرونده تسویه (اختیاری)','text'],'date_from'=>['از تاریخ کارکرد','date'],'date_to'=>['تا تاریخ کارکرد','date'],'seniority_from'=>['از تاریخ سنوات (اختیاری)','date'],'seniority_to'=>['تا تاریخ سنوات (اختیاری)','date'],'receipt_date'=>['تاریخ دریافت / تنظیم فرم','date'],'settlement_period'=>['ماه تسویه ماهیانه، مانند ۱۴۰۵/۰۷','text'],'benefit_months'=>['تعداد ماه مزایای اشتغال','number'],'settlement_effect'=>['اثر این فرم در حسابداری','select',['document_only'=>'فقط تنظیم فرم و رسید؛ ثبت مالی جدید ندارد','new_benefits'=>'ثبت مزایای جدید پایان همکاری در حسابداری']]]],
        $person,$employer,
        ['title'=>'اقلام فرم تسویه (ریال)','open'=>TRUE,'fields'=>['base_salary'=>['حقوق مبنا طبق کارکرد','number'],'housing'=>['کمک هزینه مسکن','number'],'food_allowance'=>['بن کارگری','number'],'child_count'=>['تعداد فرزند','number'],'child_allowance'=>['حق اولاد','number'],'overtime_amount'=>['اضافه‌کاری','number'],'seniority_base'=>['پایه سنوات ماهانه','number'],'leave_days'=>['روزهای مرخصی ذخیره‌شده','number'],'leave_cash'=>['مبلغ بازخرید مرخصی','number'],'seniority_days'=>['روزهای سنوات کارکرد','number'],'severance'=>['مبلغ سنوات کارکرد','number'],'bonus_days'=>['روزهای عیدی / پاداش','number'],'annual_bonus'=>['مبلغ عیدی و پاداش','number'],'other_due'=>['سایر مطالبات','number'],'insurance'=>['کسور بیمه','number'],'tax'=>['کسور مالیات','number'],'deductions'=>['سایر کسورات این فرم','number'],'receipt_amount'=>['مبلغ دریافتی فرم (اختیاری؛ خالی = جمع اقلام)','number'],'receipt_amount_words'=>['مبلغ به حروف (اختیاری)','text']]],
        ['title'=>'نحوه پرداخت و متن فرم','open'=>FALSE,'fields'=>['paid_cash'=>['مبلغ نقد دریافتی (ریال)','number'],'paid_cheque'=>['مبلغ چک (ریال)','number'],'cheque_bank'=>['نام بانک چک','text'],'cheque_no'=>['شماره چک','text'],'cheque_date'=>['تاریخ چک','date'],'paid_transfer'=>['مبلغ حواله (ریال)','number'],'transfer_tracking'=>['شماره پیگیری حواله','text'],'case_no'=>['شماره رأی / کلاسه پرونده (اختیاری)','text'],'declaration_text'=>['متن اقرار و تسویه؛ قابل ویرایش','textarea'],'public_notes'=>['توضیحات قابل چاپ','textarea'],'notes'=>['یادداشت داخلی (چاپ نمی‌شود)','textarea']]],
    ];
}
function kph_hr_flat_form_fields(string $kind): array {
    $fields=[];foreach(kph_hr_form_groups($kind) as $group){$fields+=$group['fields'];}return $fields;
}
function kph_hr_export_url(int $employee,int $record,string $format): string {
    return add_query_arg(['action'=>'kph_hr_export','employee_id'=>$employee,'record_id'=>$record,'format'=>$format,'_wpnonce'=>wp_create_nonce('kph_hr_export_'.$employee.'_'.$record.'_'.$format)],admin_url('admin-post.php'));
}
function kph_hr_document_url(int $employee,int $file,bool $view=FALSE): string {
    return add_query_arg(['action'=>'kph_hr_file','employee_id'=>$employee,'file_id'=>$file,'view'=>$view?'1':'0','_wpnonce'=>wp_create_nonce('kph_hr_file_'.$file)],admin_url('admin-post.php'));
}
