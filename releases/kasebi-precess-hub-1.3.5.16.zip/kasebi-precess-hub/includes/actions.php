<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/*
 * show marketers in users list
 */
add_filter( 'manage_users_columns', function( $columns ) {
	$columns['user_visitor'] = 'ویزیتور';
	
	return $columns;
}, 10, 1 );
add_filter( 'manage_users_custom_column', function( $row_output, $column_id_attr, $user ) {
	switch ( $column_id_attr ) {
		case 'user_visitor' :
			$user_visitor = kph_get_user_visitor( $user );
			if ( $user_visitor ) {
				return get_user_name_by_id( $user_visitor );
			}
			
			return ' - ';
		default:
	}
	
	return $row_output;
}, 10, 3 );

add_action( 'wp_print_scripts', function() {
	$page = kph_get_current_page_basename();
	if ( ! in_array( $page, kph_get_page_list() ) ) {
		return;
	}
	global $wp_scripts;
	$scripts = $wp_scripts->registered;
	foreach ( $scripts as $script ) {
		wp_dequeue_script( $script->handle );
	}
	wp_enqueue_script( 'kasebi_clinic_bundle', KPH_ASSETS_URL . 'js/bundle.js', [], '1.4', FALSE );
	wp_enqueue_script( 'kasebi_clinic_quill', KPH_ASSETS_URL . 'js/plugins/quill.js', [], 1, TRUE );
	wp_enqueue_script( 'kasebi_clinic_datepicker', KPH_ASSETS_URL . 'js/plugins/persianDatepicker.min.js', [], 1, TRUE );
	wp_enqueue_script( 'kasebi_clinic_xlsx', KPH_ASSETS_URL . 'js/plugins/xlsx.full.min.js', [], 1, TRUE );
	wp_enqueue_script( 'kasebi_clinic_script', KPH_ASSETS_URL . 'js/scripts.js', [], KPH_VER, TRUE );
	wp_localize_script( 'kasebi_clinic_script', 'kphData', [
		'ajax_url' => home_url( KPH_AJAX_URI ),
	] );
} );
add_action( 'wp_print_styles', function() {
	$page = kph_get_current_page_basename();
	if ( ! in_array( $page, kph_get_page_list() ) ) {
		return;
	}
	global $wp_styles;
	$styles = $wp_styles->registered;
	foreach ( $styles as $style ) {
		wp_dequeue_style( $style->handle );
	}
	wp_enqueue_style( 'nooshika_fonts_css', NASSETSURL . 'css/nooshika-fonts.css', [], NOOSHIKA_MAIN_VERSION );
	wp_enqueue_style( 'kasebi_kph_style', KPH_ASSETS_URL . 'css/dashlite.rtl.css', [], '1.3' );
	wp_enqueue_style( 'kasebi_kph_quill', KPH_ASSETS_URL . 'css/plugins/quill.rtl.css' );
	wp_enqueue_style( 'kasebi_kph_datepicker', KPH_ASSETS_URL . 'css/plugins/persianDatepicker-default.css' );
	wp_enqueue_style( 'kasebi_kph_theme', KPH_ASSETS_URL . 'css/theme.css', [], KPH_VER );
	wp_enqueue_style( 'kasebi_kph_visitors', KPH_ASSETS_URL . 'css/visitor-ui.css', [ 'kasebi_kph_theme' ], KPH_VER );
	$skin = get_user_meta( get_current_user_id(), 'kph_skin', TRUE ) ?: 'default';
	if ( $skin != 'default' ) {
		wp_enqueue_style( 'kasebi_kph_skin', KPH_ASSETS_URL . 'css/skins/theme-' . $skin . '.css', [], KPH_VER );
	}
} );

add_filter( 'body_class', function( $classes ) {
	$dark_mode = get_user_meta( get_current_user_id(), 'kph_dark_mode', TRUE ) == 'true' ? 'dark-mode' : '';
	if ( $dark_mode ) {
		$classes[] = $dark_mode;
	}
	
	return $classes;
} );
add_action( 'template_redirect', function() {
	if ( isset( $_GET['action'] ) && $_GET['action'] === 'print' ) {
		kph_handle_print_request();
		exit;
	}
	$page = kph_get_current_page_basename();
	if ( is_page( 'crm' ) ) {
		if ( isset( $_GET['action'] ) && $_GET['action'] == 'logout' ) {
			wp_logout();
			wp_redirect( home_url( "/crm-login" ) );
			exit;
		}
		
		if ( ! is_user_logged_in() ) {
			wp_redirect( home_url( "/crm-login" ) );
			exit;
		}
	}
	if ( is_page( 'crm-password' ) ) {
		if ( ! is_user_logged_in() ) {
			wp_redirect( home_url( "/crm-login" ) );
			exit;
		}
	}
	if ( is_page( 'crm-login' ) ) {
		if ( is_user_logged_in() ) {
			$url = $_GET['redirect'] ?? 'crm';
			wp_redirect( home_url( "/" . $url ) );
			exit;
		}
	}
	if ( in_array( $page, kph_get_page_list() ) ) {
		add_filter( 'show_admin_bar', '__return_false' );
		remove_action( 'wp_head', '_admin_bar_bump_cb' );
	}
}, 200 );

add_action( 'init', function() {
	$pages = get_kph_pages_list();
	foreach ( $pages as $page => $data ) {
		$type = $data['type'] ?? 'page';
		if ( $type == 'page' ) {
			add_rewrite_endpoint( $page, EP_PAGES );
		} else {
			if ( isset( $data['sub'] ) ) {
				foreach ( $data['sub'] as $sub_page => $datum ) {
					$sub_slug = explode( '?', $sub_page )[0];
					add_rewrite_endpoint( $sub_slug, EP_PAGES );
				}
			}
		}
	}
	$single_pages = get_kph_single_page_list();
	foreach ( $single_pages as $slug => $page ) {
		add_rewrite_endpoint( $slug, EP_PAGES );
	}
	flush_rewrite_rules();
} );

add_action( 'init', function() {
	add_role( 'visitor', 'ویزیتور', [
		'read' => TRUE,
	] );
} );
add_action( 'init', function() {
	$roles = kph_get_all_roles( FALSE );
	
	foreach ( $roles as $role_key ) {
		if ( ! get_role( $role_key ) ) {
			$role_label = kph_get_role_label( $role_key );
			add_role( $role_key, $role_label, [ 'read' => TRUE ] );
		}
	}
} );

add_action( 'admin_bar_menu', function( $wp_admin_bar ) {
	$args = [
		'id'    => 'crm-manager',
		'title' => 'مدیریت تولید',
		'href'  => home_url( 'crm' ),
		'meta'  => [
			'target' => '_blank',
		],
	];
	$wp_admin_bar->add_node( $args );
}, 999 );

add_action( 'init', function() {
	$all_roles = [
		'accountant' => 'حسابدار',
		'supp'       => 'پشتیبانی',
		'saff'       => 'سالندار زعفران',
		'tea'        => 'سالندار چای',
		'hell'       => 'سالندار هل',
		'nabat'      => 'سالندار نبات',
		'zereshk'    => 'سالندار زرشک',
		'vanil'      => 'سالندار وانیل',
	];
	
	foreach ( $all_roles as $role_key => $role_name ) {
		if ( ! get_role( $role_key ) ) {
			add_role(
				$role_key,
				$role_name,
				[
					'read' => TRUE,
				]
			);
		}
	}
} );