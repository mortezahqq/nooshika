<?php
if (!defined('ABSPATH')) { exit; }

add_action('wp_print_scripts',static function() {
    if (kph_db::supplier_tools_allowed() && wp_script_is('kasebi_clinic_script','enqueued')) {
        wp_enqueue_script('kph-supplier-tools',KPH_ASSETS_URL.'js/supplier-tools.js',['kasebi_clinic_script'],KPH_VER,TRUE);
    }
},20);

add_action('init',static function(){
    if(kph_db::supplier_tools_allowed() && get_option('kph_supplier_lifecycle_schema')!=='1'){
        $result=(new kph_db())->ensure_supplier_lifecycle_schema();
        if($result['status']==='success'){update_option('kph_supplier_lifecycle_schema','1',FALSE);}
    }
});

function kph_supplier_invoice_action(array $invoice,string $page='supplier'): array {
    if(!kph_db::supplier_tools_allowed()){return [];}
    $operation=$invoice['status']==='canceled'?'delete':'cancel';
    return ['title'=>$operation==='delete'?'حذف فاکتور':'ابطال فاکتور',
        'icon'=>$operation==='delete'?'ni-trash-alt':'ni-cross-circle',
        'class'=>'kph-supplier-invoice-action text-danger',
        'data'=>['invoice-id'=>(int)$invoice['id'],'supplier-id'=>(int)$invoice['supplier_user_id'],
            'invoice-no'=>(string)($invoice['invoice_no']?:$invoice['id']),'operation'=>$operation,
            'nonce'=>wp_create_nonce('kph_'.$operation.'_supplier_invoice_'.(int)$invoice['id']),'page'=>$page]];
}

function kph_supplier_request_id(string $key): int {
    $value=$_POST[$key]??'';
    return is_scalar($value) && preg_match('/^[1-9][0-9]{0,17}$/D',(string)$value) ? (int)$value : 0;
}

function kph_supplier_require_request(string $nonce_action): void {
    $nonce=$_POST['nonce']??'';
    if (!kph_db::supplier_tools_allowed() || !is_string($nonce) || !wp_verify_nonce($nonce,$nonce_action)) {
        wp_send_json(['status'=>'error','message'=>'دسترسی یا اعتبار درخواست تأمین‌کننده معتبر نیست؛ صفحه را تازه کنید.'],403);
    }
}

function kph_supplier_result_page(array $result,int $supplier_id,string $tab,string $page='supplier'): void {
    if (($result['status']??'')==='success') {
        $status=$result['data']['status']??$_POST['status']??'proforma';
        $status=is_string($status)&&in_array($status,['proforma','confirmed','settled','canceled'],TRUE)?$status:'proforma';
        // Native templates read request filters; never let arbitrary posted keys become template variables.
        $_REQUEST=['id'=>$supplier_id,'tab'=>$tab,'status'=>$status,'page_number'=>1];
        $path=$page==='produce-invoice'?'/crm/produce-invoice':'/crm/supplier';
        $result['main']=kph_get_template('layout/main.php',['page'=>$path]);
        $result['url']=$page==='produce-invoice'?home_url('/crm/produce-invoice?status='.$status):home_url('/crm/supplier/'.$supplier_id.'?tab='.$tab.($tab==='invoice'?'&status='.$status:''));
    }
    wp_send_json($result);
}

add_action('nooshika_ajax_kph_cancel_supplier_invoice',static function(){
    $id=kph_supplier_request_id('invoice_id');$supplier=kph_supplier_request_id('supplier_id');
    kph_supplier_require_request('kph_cancel_supplier_invoice_'.$id);
    $page=($_POST['page']??'')==='produce-invoice'?'produce-invoice':'supplier';
    kph_supplier_result_page((new kph_db())->cancel_supplier_invoice($id,$supplier),$supplier,'invoice',$page);
});

add_action('nooshika_ajax_kph_delete_supplier_invoice',static function() {
    $id=kph_supplier_request_id('invoice_id');$supplier=kph_supplier_request_id('supplier_id');
    kph_supplier_require_request('kph_delete_supplier_invoice_'.$id);
    $page=($_POST['page']??'')==='produce-invoice'?'produce-invoice':'supplier';
    kph_supplier_result_page((new kph_db())->delete_supplier_invoice($id,$supplier),$supplier,'invoice',$page);
});

add_action('nooshika_ajax_kph_submit_supplier_action',static function() {
    $id=kph_supplier_request_id('supplier_id');
    kph_supplier_require_request('kph_supplier_action_'.$id);
    $supplier=$id?get_userdata($id):NULL;
    if (!$supplier || !in_array('supplier',(array)$supplier->roles,TRUE)) {
        wp_send_json(['status'=>'error','message'=>'تأمین‌کننده معتبر نیست.']);
    }
    $title=$_POST['title']??'';$content=$_POST['description']??'';$attachment=$_POST['attachment']??'';
    if (!is_string($title)||!is_string($content)||!is_string($attachment)) {
        wp_send_json(['status'=>'error','message'=>'اطلاعات فرم معتبر نیست.']);
    }
    $title=sanitize_text_field(wp_unslash($title));$content=wp_kses_post(wp_unslash($content));
    if (trim($title)==='' || trim(wp_strip_all_tags($content))==='' || mb_strlen($title)>200 || mb_strlen($content)>20000) {
        wp_send_json(['status'=>'error','message'=>'عنوان و توضیحات را وارد کنید؛ عنوان حداکثر ۲۰۰ و توضیحات حداکثر ۲۰۰۰۰ نویسه باشد.']);
    }
    $db=new kph_db();$attachment=trim(wp_unslash($attachment));
    if ($attachment!=='' && (strlen($attachment)>2048 || !filter_var($attachment,FILTER_VALIDATE_URL) || !$db->get_uploaded_file_data($attachment))) {
        wp_send_json(['status'=>'error','message'=>'فایل ضمیمه را با دکمهٔ بارگذاری همین فرم انتخاب کنید.']);
    }
    $result=$db->add_user_action(['user_id'=>$id,'title'=>$title,'content'=>$content,'attachment'=>$attachment,'meta'=>['type'=>'supplier_communication']]);
    kph_supplier_result_page($result,$id,'actions');
});
