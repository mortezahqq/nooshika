<?php
if ( ! defined('ABSPATH') ) exit;
add_action('woocommerce_product_options_pricing', function(){
    if ( ! function_exists('woocommerce_wp_text_input') ) return;
    echo '<div class="options_group">';
    woocommerce_wp_text_input(['id'=>'_kph_wholesale_price','label'=>'قیمت عمده (ریال)','type'=>'number','custom_attributes'=>['min'=>'0','step'=>'1'],'desc_tip'=>true,'description'=>'قیمت عمده برای فاکتورهای با تعداد خرید تعیین‌شده.']);
    woocommerce_wp_text_input(['id'=>'_kph_wholesale_min_qty','label'=>'حداقل تعداد برای قیمت عمده','type'=>'number','custom_attributes'=>['min'=>'1','step'=>'1'],'desc_tip'=>true,'description'=>'از این تعداد به بالا، قیمت عمده به‌صورت خودکار در فاکتور پیشنهاد می‌شود.']);
    echo '</div>';
});
add_action('woocommerce_admin_process_product_object', function($product){
    if ( ! $product || ! current_user_can('edit_products') ) return;
    $price = isset($_POST['_kph_wholesale_price']) ? wc_format_decimal(wp_unslash($_POST['_kph_wholesale_price'])) : '';
    $min = isset($_POST['_kph_wholesale_min_qty']) ? absint(wp_unslash($_POST['_kph_wholesale_min_qty'])) : 0;
    if ( $price !== '' && (float)$price > 0 ) $product->update_meta_data('_kph_wholesale_price',$price); else $product->delete_meta_data('_kph_wholesale_price');
    if ( $min > 0 ) $product->update_meta_data('_kph_wholesale_min_qty',$min); else $product->delete_meta_data('_kph_wholesale_min_qty');
});
