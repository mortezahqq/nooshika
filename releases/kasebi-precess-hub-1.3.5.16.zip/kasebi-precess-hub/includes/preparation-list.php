<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

function kph_preparation_print_allowed(): bool {
    if ( ! is_user_logged_in() ) { return FALSE; }
    $roles = get_kph_pages_list()['orders-list']['valid_roles'] ?? [];
    return $roles === 'all' || in_array( nooshika_get_user_role( get_current_user_id() ), (array) $roles, TRUE );
}

// The CRM removes queued theme scripts in wp_print_scripts at priority 10.
add_action( 'wp_print_scripts', function() {
    if ( wp_script_is( 'kasebi_clinic_script', 'enqueued' ) ) {
        wp_enqueue_script( 'kph-preparation-list', KPH_ASSETS_URL . 'js/preparation-list.js', [ 'kasebi_clinic_script' ], KPH_VER, TRUE );
    }
}, 20 );
