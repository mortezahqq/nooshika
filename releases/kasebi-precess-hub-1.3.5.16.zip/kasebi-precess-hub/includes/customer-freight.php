<?php
if(!defined('ABSPATH'))exit;
add_action('init',function(){
    if(kph_customer_freight::allowed() && get_option('kph_customer_freight_schema')!=='1'){
        try{(new kph_customer_freight())->install();update_option('kph_customer_freight_schema','1',false);}catch(Throwable $e){}
    }
},36);
add_action('wp_print_scripts',function(){
    if(kph_customer_freight::allowed() && wp_script_is('kasebi_clinic_script','enqueued'))wp_enqueue_script('kph-customer-freight',KPH_ASSETS_URL.'js/customer-freight.js',['kasebi_clinic_script'],KPH_VER,true);
},20);
add_action('nooshika_ajax_kph_customer_freight_invoices',function(){
    $nonce=$_POST['nonce']??'';
    if(!kph_customer_freight::allowed()||!is_string($nonce)||!wp_verify_nonce($nonce,'kph_customer_freight'))wp_send_json(['status'=>'error','message'=>'اجازه جستجوی فاکتور برای ثبت کرایه را ندارید.'],403);
    try{
        $customer=is_scalar($_POST['customer_id']??null)?absint($_POST['customer_id']):0;
        $term=is_scalar($_POST['term']??'')?(string)wp_unslash($_POST['term']??''):'';
        $page=is_scalar($_POST['page']??1)?max(1,absint($_POST['page']??1)):1;
        $result=['status'=>'success','data'=>(new kph_shipping_control())->invoices($customer,$term,$page)];
    }catch(Throwable $e){$result=['status'=>'error','message'=>$e->getMessage()];}
    wp_send_json($result);
});
