<?php
if(!defined('ABSPATH')){exit;}
add_action('nooshika_ajax_kph_update_order_shipment_date',function(){
    $id=is_scalar($_POST['order_id']??null)?absint($_POST['order_id']):0;
    $nonce=$_POST['nonce']??'';
    if(!get_current_user_id()||!is_string($nonce)||!wp_verify_nonce($nonce,'kph_order_shipment_date_'.$id))wp_send_json(['status'=>'error','message'=>'اعتبار فرم تمام شده؛ صفحه را تازه کنید.'],403);
    $db=new kph_db();
    wp_send_json($db->update_order_shipment_date_inline($id,wp_unslash($_POST['date']??''),wp_unslash($_POST['expected']??'')));
});
add_action('wp_print_scripts',function(){
    if(wp_script_is('kasebi_clinic_script','enqueued'))wp_enqueue_script('kph-order-dates',KPH_ASSETS_URL.'js/order-dates.js',['kasebi_clinic_script'],KPH_VER,true);
},20);
