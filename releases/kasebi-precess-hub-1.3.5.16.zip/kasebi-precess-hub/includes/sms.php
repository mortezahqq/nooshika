<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** All order SMS messages open the native ordinary invoice for the exact order. */
function kph_order_sms_invoice_url(int $order_id):string {
    if($order_id<=0)return '';
    return add_query_arg(['action'=>'print','type'=>'factor','ids'=>$order_id],home_url('/'));
}

function kph_sms_user_can_receive( int $user_id ): bool {
	if ( $user_id <= 0 ) {
		return FALSE;
	}
	
	$notif = get_user_meta( $user_id, 'customer_sms_notif', TRUE ) ?: 'send';
	
	if ( $notif !== 'send' ) {
		return FALSE;
	}
	
	$phone = get_user_meta( $user_id, 'nooshika_phone_num', TRUE );
	
	return ! empty( $phone );
}

function kph_sms_user_name( int $user_id ): string {
	$first_name = get_user_meta( $user_id, 'first_name', TRUE );
	$last_name  = get_user_meta( $user_id, 'last_name', TRUE );
	$name       = trim( $first_name . ' ' . $last_name );
	
	if ( $name ) {
		return $name;
	}
	
	$user = get_userdata( $user_id );
	
	return $user ? $user->display_name : '';
}

function kph_sms_money( $amount ): string {
	return number_format( abs( (float) $amount ) );
}

function kph_sms_date( $date = '' ): string {
	if ( empty( $date ) ) {
		$date = current_time( 'mysql' );
	}
	
	return date_i18n( 'Y/m/d', strtotime( $date ) );
}

function kph_sms_balance_text( int $user_id, string $date_to = '' ): string {
	$DB = new kph_db();
	
	$balance = $DB->get_ledger_balance_now( $user_id );
	$balance = $balance['balance'];
	
	if ( $balance > 0 ) {
		return number_format( abs( $balance ) ) . ' بدهکار';
	}
	
	if ( $balance < 0 ) {
		return number_format( abs( $balance ) ) . ' بستانکار';
	}
	
	return 'تسویه';
}

function kph_send_pattern_sms_to_user( int $user_id, string $template, array $tokens = [], $include_sub = FALSE ): bool {
	if ( ! kph_sms_user_can_receive( $user_id ) ) {
		return FALSE;
	}
	
	$phone = get_user_meta( $user_id, 'nooshika_phone_num', TRUE );
	
	$data = [
		'receptor' => $phone,
		'template' => $template,
		'token'    => sanitize_string_for_pattern( $tokens['token'] ?? kph_sms_user_name( $user_id ) ),
	];
	
	foreach ( [ 'token2', 'token3', 'token10', 'token20' ] as $key ) {
		if ( isset( $tokens[ $key ] ) ) {
			// A print link is a URL, not a text pattern token. Preserve its query separators.
            if($key==='token10' && in_array($template,['order2','order3','completed-order','processing-order'],true)){
                $data[$key]=esc_url_raw((string)$tokens[$key]);
            }else{
                $data[ $key ] = sanitize_string_for_pattern( $tokens[ $key ] );
            }
		}
	}
	
	( new nooshika_otp() )->send_pattern_sms( $data );
	if ( $include_sub == 'sale' ) {
		$purchasing_phone = get_user_meta( $user_id, 'purchasing_phone', TRUE );
		$purchasing_name  = get_user_meta( $user_id, 'purchasing_name', TRUE );
		$data['receptor'] = $purchasing_phone;
		$data['token']    = sanitize_string_for_pattern( $purchasing_name );
		( new nooshika_otp() )->send_pattern_sms( $data );
		
		$customer_marketer = get_user_meta( $user_id, 'customer_marketer', TRUE );
		$data['receptor']  = get_user_meta( $user_id, '$customer_marketer', TRUE );;
		$data['token'] = sanitize_string_for_pattern( get_user_name_by_id( $customer_marketer ) );
		( new nooshika_otp() )->send_pattern_sms( $data );
	}
	if ( $include_sub == 'fin' ) {
		$purchasing_phone = get_user_meta( $user_id, 'accountant_phone', TRUE );
		$purchasing_name  = get_user_meta( $user_id, 'accountant_name', TRUE );
		$data['receptor'] = $purchasing_phone;
		$data['token']    = sanitize_string_for_pattern( $purchasing_name );
		( new nooshika_otp() )->send_pattern_sms( $data );
	}
	
	return TRUE;
}

/**
 * پرداخت نقدی / کارت / متفرقه
 */
add_action( 'kph_payment_added', function( int $payment_id, array $payment_data, array $ledger_res = [] ) {
	$user_id = (int) ( $payment_data['user_id'] ?? 0 );
	$type    = (string) ( $payment_data['type'] ?? '' );
	$amount  = (float) ( $payment_data['amount'] ?? 0 );
	$paid_at = (string) ( $payment_data['paid_at'] ?? current_time( 'mysql' ) );
	
	if ( $user_id <= 0 || $amount <= 0 ) {
		return;
	}
	
	$role = function_exists( 'nooshika_get_user_role' ) ? nooshika_get_user_role( $user_id ) : '';
	
	$methods = ( new kph_db() )->get_payment_methods();
	$method  = $payment_data['payment_method'] ?? 'other';
	$reason  = $methods[ $method ]['label'] ?? 'پرداخت';
	
	if ( $role === 'supplier' && $type === 'debit' ) {
		kph_send_pattern_sms_to_user( $user_id, 'Payment-supplier', [
			'token2'  => 1,
			'token3'  => kph_sms_date( $paid_at ),
			'token10' => kph_sms_money( $amount ),
			'token20' => kph_sms_balance_text( $user_id, $paid_at ),
		] );
		
		return;
	}
	
	if ( $type === 'credit' ) {
		kph_send_pattern_sms_to_user( $user_id, 'change-account2', [
			'token2'  => $reason,
			'token3'  => kph_sms_date( $paid_at ),
			'token10' => kph_sms_money( $amount ),
			'token20' => kph_sms_balance_text( $user_id, $paid_at ),
		], 'fin' );
		
		return;
	}
	
	if ( $type === 'debit' ) {
		kph_send_pattern_sms_to_user( $user_id, 'change-account', [
			'token2'  => $reason,
			'token3'  => kph_sms_date( $paid_at ),
			'token10' => kph_sms_money( $amount ),
			'token20' => kph_sms_balance_text( $user_id, $paid_at ),
		], 'fin' );
	}
}, 10, 3 );

/**
 * حواله
 */
add_action( 'kph_transfer_added', function( int $transfer_id, array $transfer_data, array $ledger_res = [] ) {
	$user_id        = (int) ( $transfer_data['user_id'] ?? 0 );
	$amount         = (float) ( $transfer_data['amount'] ?? 0 );
	$transferred_at = (string) ( $transfer_data['transferred_at'] ?? current_time( 'mysql' ) );
	
	if ( $user_id <= 0 || $amount == 0 ) {
		return;
	}
	
	$role = function_exists( 'nooshika_get_user_role' ) ? nooshika_get_user_role( $user_id ) : '';
	
	if ( $role === 'supplier' && $amount > 0 ) {
		kph_send_pattern_sms_to_user( $user_id, 'Payment-supplier', [
			'token2'  => 1,
			'token3'  => kph_sms_date( $transferred_at ),
			'token10' => kph_sms_money( $amount ),
			'token20' => kph_sms_balance_text( $user_id, $transferred_at ),
		] );
		
		return;
	}
	
	if ( $role === 'subscriber' && $amount < 0 ) {
		kph_send_pattern_sms_to_user( $user_id, 'check-from-customer', [
			'token2'  => 1,
			'token3'  => kph_sms_date( $transferred_at ),
			'token10' => kph_sms_money( $amount ),
			'token20' => kph_sms_balance_text( $user_id, $transferred_at ),
		] );
		
		return;
	}
	
	if ( $amount < 0 ) {
		kph_send_pattern_sms_to_user( $user_id, 'change-account2', [
			'token2'  => 'حواله',
			'token3'  => kph_sms_date( $transferred_at ),
			'token10' => kph_sms_money( $amount ),
			'token20' => kph_sms_balance_text( $user_id, $transferred_at ),
		] );
	} else {
		kph_send_pattern_sms_to_user( $user_id, 'change-account', [
			'token2'  => 'حواله',
			'token3'  => kph_sms_date( $transferred_at ),
			'token10' => kph_sms_money( $amount ),
			'token20' => kph_sms_balance_text( $user_id, $transferred_at ),
		] );
	}
}, 10, 3 );

/**
 * ثبت چک از مشتری / تأمین‌کننده
 */
add_action( 'kph_cheque_added', function( int $cheque_id, array $cheque_data, array $move_res = [] ) {
	$user_id    = (int) ( $cheque_data['user_id'] ?? 0 );
	$amount     = (float) ( $cheque_data['amount'] ?? 0 );
	$created_at = (string) ( $cheque_data['created_at'] ?? current_time( 'mysql' ) );
	
	if ( $user_id <= 0 || $amount <= 0 ) {
		return;
	}
	
	$role = function_exists( 'nooshika_get_user_role' ) ? nooshika_get_user_role( $user_id ) : '';
	
	if ( $role === 'supplier' ) {
		kph_send_pattern_sms_to_user( $user_id, 'Payment-supplier', [
			'token2'  => 1,
			'token3'  => kph_sms_date( $created_at ),
			'token10' => kph_sms_money( $amount ),
			'token20' => kph_sms_balance_text( $user_id, $created_at ),
		] );
		
		return;
	}
	
	kph_send_pattern_sms_to_user( $user_id, 'check-from-customer', [
		'token2'  => 1,
		'token3'  => kph_sms_date( $created_at ),
		'token10' => kph_sms_money( $amount ),
		'token20' => kph_sms_balance_text( $user_id, $created_at ),
	] );
}, 10, 3 );

/**
 * واگذاری چک به تأمین‌کننده
 */
add_action( 'kph_cheque_move_added', function( int $move_id, int $cheque_id, array $move_data, array $ledger_res = [] ) {
	$action         = $move_data['action'] ?? '';
	$holder_user_id = (int) ( $move_data['holder_user_id'] ?? 0 );
	$amount         = (float) ( $move_data['amount'] ?? 0 );
	$created_at     = (string) ( $move_data['created_at'] ?? current_time( 'mysql' ) );
	
	if ( $action !== 'endorse' || $holder_user_id <= 0 || $amount <= 0 ) {
		return;
	}
	
	$role = function_exists( 'nooshika_get_user_role' ) ? nooshika_get_user_role( $holder_user_id ) : '';
	
	if ( $role !== 'supplier' ) {
		return;
	}
	
	kph_send_pattern_sms_to_user( $holder_user_id, 'Payment-supplier', [
		'token2'  => 1,
		'token3'  => kph_sms_date( $created_at ),
		'token10' => kph_sms_money( $amount ),
		'token20' => kph_sms_balance_text( $holder_user_id, $created_at ),
	] );
}, 10, 4 );

/**
 * تغییر وضعیت سفارش مشتری
 */
add_action( 'kph_new_fulfillment_added', function( int $order_id, string $shipping_method = 'باربری' ) {
	$DB = new kph_db();
	
	$order_data = $DB->get_order_data( $order_id );
	
	if ( empty( $order_data ) ) {
		return;
	}
	$user_id      = (int) ( $order_data['customer_id'] ?? 0 );
	$order_number = $DB->get_order_meta( $order_id, 'factor_number' );
	kph_send_pattern_sms_to_user( $user_id, 'order2', [
		'token2'  => $order_number,
		'token3'  => $shipping_method,
		'token10' => kph_order_sms_invoice_url($order_id),
	] );
}, 10, 2 );
add_action( 'kph_order_status_changed', function( int $order_id, string $old_status, string $new_status, array $order = [] ) {
	$DB = new kph_db();
	
	$order_data = $DB->get_order_data( $order_id );
	
	if ( empty( $order_data ) ) {
		return;
	}
	
	$user_id      = (int) ( $order_data['customer_id'] ?? 0 );
	$order_number = $DB->get_order_meta( $order_id, 'factor_number' );
	
	if ( $user_id <= 0 ) {
		return;
	}
	
	if ( $old_status === 'proforma' && $new_status === 'registered' ) {
		kph_send_pattern_sms_to_user( $user_id, 'processing-order', [
			'token2'  => $order_number,
			'token3'  => kph_sms_date( $order_data['registered_at'] ?: current_time( 'mysql' ) ),
			'token10' => kph_order_sms_invoice_url($order_id),
		], 'sale' );
		
		return;
	}
	
	$sender_name = $DB->get_order_meta( $order_id, 'shipping_method' );
	if ( ! $sender_name ) {
		$sender_name = 'باربری';
	}
	
	if ( $new_status === 'shortage' ) {
	}
	//
	//	if ( $new_status === 'shipped' && $old_status === 'shortage' ) {
	//		//		$canceled = $DB->get_order_meta( $order_id, 'item_canceled' ) ?: '';
	//		//		if ( $canceled != 'yes' ) {
	//		//			kph_send_pattern_sms_to_user( $user_id, 'order3', [
	//		//				'token2'  => $order_number,
	//		//				'token3'  => $sender_name,
	//		//				'token10' => kph_order_sms_invoice_url($order_id),
	//		//			] );
	//		//		}
	//		//
	//		return;
	//	}
	
	//	if ( $new_status === 'shipped' ) {
	//		kph_send_pattern_sms_to_user( $user_id, 'completed-order', [
	//			'token2' => $order_number,
	//			'token3' => $sender_name,
	//		] );
	//	}
}, 10, 4 );

/**
 * فاکتور خرید تأمین‌کننده
 */
add_action( 'kph_supplier_invoice_status_changed', function( int $invoice_id, string $old_status, string $new_status, array $invoice = [] ) {
	if ( $old_status !== 'proforma' || $new_status !== 'confirmed' ) {
		return;
	}
	
	$user_id = (int) ( $invoice['supplier_user_id'] ?? 0 );
	
	if ( $user_id <= 0 ) {
		return;
	}
	
	$invoice_no = $invoice['invoice_no'] ?: $invoice_id;
	$date       = $invoice['issued_at'] ?: current_time( 'mysql' );
	
	kph_send_pattern_sms_to_user( $user_id, 'buy-supplier', [
		'token2'  => $invoice_no,
		'token3'  => kph_sms_date( $date ),
		'token10' => home_url( "/?action=print&type=invoice&ids=$invoice_id" ),
	] );
}, 10, 4 );

/**
 * مشتری جدید
 */
add_action( 'kph_customer_user_added', function( int $user_id ) {
	kph_send_pattern_sms_to_user( $user_id, 'new-user' );
} );

/**
 * تأمین‌کننده جدید
 */
add_action( 'kph_supplier_user_added', function( int $user_id ) {
	kph_send_pattern_sms_to_user( $user_id, 'new-Supplier' );
} );