(function($){
    'use strict';
    function dataFor($root,data){if(data instanceof FormData){data.set('action','kph_shipping_control');data.set('nonce',$root.attr('data-nonce'));}else{data.action='kph_shipping_control';data.nonce=$root.attr('data-nonce');}return data;}
    function message($root,text,error){$root.find('.kph-sc-message').text(text).removeClass('d-none alert-danger alert-success').addClass(error?'alert-danger':'alert-success');}
    function request($root,data){
        if($root.data('scBusy'))return;$root.data('scBusy',true);var buttons=$root.find('button');buttons.prop('disabled',true);var form=data instanceof FormData;
        $.ajax({url:$root.attr('data-endpoint'),type:'POST',data:dataFor($root,data),processData:!form,contentType:form?false:'application/x-www-form-urlencoded; charset=UTF-8',global:false})
          .done(function(res){if(res.status==='success'){message($root,res.message,false);window.location.assign($root.attr('data-return-url'));}else{message($root,res.message||'ثبت انجام نشد.',true);}})
          .fail(function(xhr){message($root,xhr.responseJSON&&xhr.responseJSON.message||'ارتباط برقرار نشد؛ وضعیت ثبت را پس از تازه‌کردن صفحه بررسی کنید.',true);})
          .always(function(){$root.data('scBusy',false);buttons.prop('disabled',false);});
    }
    $(document).on('submit','form.kph-sc-form',function(e){e.preventDefault();var $f=$(this),data=new FormData(this);if($f.hasClass('kph-sc-shipment')){data.set('customer_pays',$f.find('input[type=checkbox][name=customer_pays]').prop('checked')?'1':'0');}request($f.closest('.kph-shipping-control'),data);});
    $(document).on('click','.kph-sc-cancel',function(e){e.preventDefault();var reason=window.prompt('علت ابطال سابقهٔ ارسال:');if(!reason||!reason.trim())return;var $b=$(this);request($b.closest('.kph-shipping-control'),{operation:'cancel',record_id:$b.attr('data-record'),version:$b.attr('data-version'),reason:reason});});
    function select($element,$root,operation,customer){
        if(!$.fn.select2||$element.hasClass('select2-hidden-accessible'))return;
        $element.select2({width:'100%',dropdownParent:$element.closest('.modal'),placeholder:operation==='customers'?'جستجوی نام یا موبایل مشتری':'جستجوی شماره سفارش',allowClear:true,
            language:{inputTooShort:function(){return 'نام یا شماره را وارد کنید';},errorLoading:function(){return 'جستجو انجام نشد';},noResults:function(){return 'موردی یافت نشد';},searching:function(){return 'در حال جستجو…';}},
            ajax:{url:$root.attr('data-endpoint'),type:'POST',global:false,delay:250,data:function(params){return dataFor($root,{operation:operation,term:params.term||'',page:params.page||1,customer_id:customer?customer.val():0});},processResults:function(res){return res.status==='success'?res.data:{results:[],pagination:{more:false}};}}
        });
    }
    function init(){
        $('.kph-shipping-control').each(function(){var $root=$(this),$customer=$root.find('.kph-sc-customer'),$order=$root.find('.kph-sc-order');select($customer,$root,'customers');select($order,$root,'orders',$customer);$order.prop('disabled',!$customer.val());
            $root.find('.modal[data-sc-open="1"]').each(function(){if(window.bootstrap&&window.bootstrap.Modal){window.bootstrap.Modal.getOrCreateInstance(this).show();}else if($.fn.modal){$(this).modal('show');}else{return;}$(this).removeAttr('data-sc-open');});
        });
    }
    $(document).on('change','.kph-sc-customer',function(){var $f=$(this).closest('form'),$order=$f.find('.kph-sc-order');$order.empty().append($('<option>').val('')).val(null).prop('disabled',!this.value).trigger('change');});
    $(document).on('shown.bs.modal','.kph-shipping-control .modal',init);
    $(init);$(document).on('kph-preparation-refresh',init);
})(jQuery);
