!function(NioApp, $) {
    'use strict';
    
    NioApp.Package.name = 'DashLite';
    NioApp.Package.version = '3.2';
    var $win         = $(window),
        $body        = $('body'),
        $doc         = $(document),
        _menu        = 'nk-menu',
        _header      = 'nk-header',
        _header_menu = 'nk-header-menu',
        _sidebar     = 'nk-sidebar',
        _sidebar_mob = 'nk-sidebar-mobile',
        _break       = NioApp.Break;
    let ajax_url    = kphData.ajax_url,
        ajax_search = false;
    NioApp.State.isRTL = true;
    const charts = {};
    

    // Operational customer reports: delegated handlers also support AJAX page navigation.
    $(document).on('submit', '.kph-erp-filter', function(event) {
        event.preventDefault();
        const fields = $(this).serializeArray();
        const params = new URLSearchParams({report_view: 'dashboard'});
        fields.forEach(function(field) { params.append(field.name, field.value); });
        request_panel_page_content('/crm/reports-user?' + params.toString());
    });
    $(document).on('submit', '.kph-erp-form', function(event) {
        event.preventDefault();
        const form = $(this);
        if (form.data('pending')) return;
        const payload = form.serializeArray();
        payload.push({name: 'action', value: 'kph_manage_erp'});
        const message = form.find('.erp-form-message');
        const buttons = form.find('button[type="submit"]');
        const pageUrl = window.location.pathname + window.location.search;
        form.data('pending', true); buttons.prop('disabled', true);
        message.removeClass('text-danger text-success').text('در حال ثبت…');
        $.ajax({url: ajax_url, type: 'POST', dataType: 'json', data: payload, global: false})
            .done(function(response) {
                const ok = response && response.status === 'success';
                message.addClass(ok ? 'text-success' : 'text-danger').text(response && response.message || 'پاسخ معتبر دریافت نشد.');
                if (ok) {
                    NioApp.Toast(response.message, 'success', {position: 'top-right'});
                    if (window.location.pathname + window.location.search === pageUrl) request_panel_page_content(pageUrl);
                }
            }).fail(function(xhr) {
                const error = xhr.responseJSON;
                message.addClass('text-danger').text(error && error.message || 'پاسخ دریافت نشد؛ پیش از تلاش مجدد وضعیت ثبت را با تازه‌کردن صفحه بررسی کنید.');
            }).always(function() { form.data('pending', false); buttons.prop('disabled', false); });
    });
    $(document).on('change', '.erp-lead-order', function() {
        const customer = $(this).find(':selected').attr('data-customer');
        if (customer) $(this).closest('form').find('[name="customer_id"]').val(customer).trigger('change');
    });
    $(document).on('click', '.erp-edit-record', function() {
        let record;
        try { record = JSON.parse($(this).attr('data-record')); } catch (error) { return; }
        const type = $(this).attr('data-type');
        const form = $('.erp-record-editor').filter(function() { return $(this).attr('data-record-type') === type; }).first();
        if (!form.length || form.data('pending')) return;
        Object.keys(record).forEach(function(key) {
            form.find('[name]').filter(function() { return this.name === key; }).val(record[key] === null ? '' : record[key]).trigger('change');
        });
        form.find('.erp-form-message').removeClass('text-danger').text('ویرایش مورد شماره ' + record.id);
        if (form[0].scrollIntoView) form[0].scrollIntoView({block: 'center', behavior: 'smooth'});
        form.find('[name="title"], [name="date_from"]').first().trigger('focus');
    });
    $(document).on('click', '.erp-clear-editor', function() {
        const form = $(this).closest('form');
        if (form.data('pending')) return;
        form[0].reset();
        form.find('[name="id"], [name="version"]').val('0');
        form.find('[name="status"]').val('open');
        form.find('[name="stage"]').val('open');
        form.find('[name="kind"]').val('task');
        form.find('[name="priority"]').val('normal');
        form.find('[name="assignee"], [name="customer_id"], [name="owner_id"], [name="order_id"]').val('0').trigger('change');
        form.find('[name="title"], [name="date_from"], [name="date_to"], [name="due_on"]').val('').trigger('change');
        form.find('.erp-form-message').text('ثبت مورد جدید');
    });
    function kph_prepare_erp_chart($chart, config) {
        if (!$chart.attr('data-erp-chart')) return;
        const urls = atlas_safe_json_parse($chart.attr('data-erp-urls')) || [];
        config.options.onClick = function(event, points) {
            if (!points || !points.length) return;
            const index = points[0]._index !== undefined ? points[0]._index : points[0].index;
            if (urls[index]) request_panel_page_content(urls[index]);
        };
        if ($chart.attr('data-erp-chart') === 'sales') {
            const colors = ['#2563eb', '#16a34a', '#9333ea'];
            config.data.datasets.forEach(function(dataset, index) {
                dataset.borderColor = colors[index % 3];
                dataset.backgroundColor = colors[index % 3];
                dataset.fill = false;
                dataset.borderWidth = 2;
                dataset.pointRadius = 2;
                dataset.lineTension = 0.15;
                dataset.hidden = index >= 3;
                if (index >= 3) dataset.borderDash = index < 6 ? [6, 4] : [2, 4];
            });
        }
    }
    function kph_bind_erp_chart($chart, chart) {
        if ($chart.attr('data-erp-chart') !== 'sales') return;
        $chart.closest('.erp-chart-card').find('.erp-chart-compare').on('change', function() {
            const start = this.value === 'previous' ? 3 : 6;
            for (let i = start; i < start + 3; i++) chart.getDatasetMeta(i).hidden = !this.checked;
            chart.update();
        });
    }

    let productionSearchTimer;
    let productionSearchRequest;
    let productionSearchVersion = 0;
    let productionSearchPage = 0;
    let productionSearchTerm = '';
    function clearProductionSearch() {
        clearTimeout(productionSearchTimer);
        if (productionSearchRequest) productionSearchRequest.abort();
        productionSearchVersion++;
    }
    function selectProductionCode(item) {
        $('#production_code_more').hide();
        const picker = $('#production_code_id');
        picker.empty().append(new Option('محصول و کد را انتخاب کنید', ''));
        if (item) {
            picker.append(new Option(item.title + ' — ' + item.code, String(item.id), true, true));
        }
        picker.trigger('change');
    }
    function searchProductionCodes(append) {
        if (!append) {
            clearProductionSearch();
            productionSearchPage = 0;
            productionSearchTerm = $('#production_code_search').val();
            selectProductionCode(null);
        }
        const requestedPage = productionSearchPage + 1;
        $('#production_code_more').prop('disabled', true);
        const version = productionSearchVersion;
        const nonce = $('#production_nonce').val();
        productionSearchRequest = $.ajax({url: ajax_url, method: 'POST', dataType: 'json', global: false, data: {
            action: 'kph_search_production_codes',
            search: productionSearchTerm,
            page_number: requestedPage,
            production_nonce: nonce,
        }}).done(function(response) {
            if (version !== productionSearchVersion) return;
            const picker = $('#production_code_id');
            if (!append) picker.empty().append(new Option('یک محصول و کد تولید را انتخاب کنید', ''));
            if (response.status !== 'success') {
                $('#production_code_selected').text(response.message || 'جستجو انجام نشد.');
                return;
            }
            (response.items || []).forEach(function(item) {
                if (!picker.find('option').toArray().some(function(option) { return option.value === String(item.id); })) {
                    picker.append(new Option(item.title + ' — ' + item.code, String(item.id)));
                }
            });
            productionSearchPage = requestedPage;
            $('#production_code_more').toggle(!!response.more);
            if (!picker.val()) $('#production_code_selected').text(picker.find('option').length > 1 ?
                'یک محصول و کد را انتخاب کنید؛ برای محدودکردن نتایج نام یا کد دقیق‌تر وارد کنید.' :
                'کدی یافت نشد؛ برای تعریف کد جدید با مدیر هماهنگ کنید.');
        }).fail(function(xhr, status) {
            if (status !== 'abort' && version === productionSearchVersion) {
                $('#production_code_selected').text('جستجوی کدها انجام نشد؛ دوباره تلاش کنید.');
            }
        }).always(function() {
            if (version === productionSearchVersion) $('#production_code_more').prop('disabled', false);
        });
    }
    $(document).on('input', '#production_code_search', function() {
        clearProductionSearch();
        selectProductionCode(null);
        productionSearchTimer = setTimeout(function() { searchProductionCodes(false); }, 250);
    });
    $(document).on('click', '#production_code_more', function() {
        if (!$(this).prop('disabled')) searchProductionCodes(true);
    });
    $(document).on('change', '#production_code_id', function() {
        $('#production_code_selected').text(this.value ? $(this).find(':selected').text() : '');
    });
    $(document).on('shown.bs.modal', '#convertLotToProduct', function() {
        $('#production_code_search, #new_production_code, #new_production_product').val('');
        $('#new_production_confirm').prop('checked', false);
        searchProductionCodes(false);
    });
    $(document).on('hidden.bs.modal', '#convertLotToProduct', clearProductionSearch);
    $(document).on('input change', '#new_production_product, #new_production_code', function() {
        $('#new_production_confirm').prop('checked', false);
    });
    $(document).on('click', '#register_production_code', function() {
        if (!$('#new_production_confirm').prop('checked') || !$('#new_production_product').val() || !$('#new_production_code').val().trim()) {
            NioApp.Toast('محصول و کد جدید را وارد و ارتباط آن‌ها را تأیید کنید.', 'error', {position: 'top-right'});
            return;
        }
        const button = $(this);
        button.prop('disabled', true);
        $.post(ajax_url, {
            action: 'kph_register_production_code',
            production_nonce: $('#production_nonce').val(),
            product_id: $('#new_production_product').val(),
            code: $('#new_production_code').val(),
        }, function(response) {
            NioApp.Toast(response.message, response.status, {position: 'top-right'});
            if (response.status === 'success') {
                clearProductionSearch();
                $('#production_code_search').val(response.data.code);
                selectProductionCode(response.data);
                $('#new_production_confirm').prop('checked', false);
                $('#new_production_code, #new_production_product').val('');
            }
        }).fail(function() {
            NioApp.Toast('تعریف کد انجام نشد؛ دوباره جستجو کنید.', 'error', {position: 'top-right'});
        }).always(function() { button.prop('disabled', false); });
    });
    $(document).on('shown.bs.modal', '#addCheque', function() {
        $('#new_cheque_admin_note').val('');
        $(this).find('[data-for="admin_note_print"]').prop('checked', false);
    });
    let chequeNotePrintAllBusy = false;
    function syncChequeNotePrintField(field) {
        const all = field.attr('data-print-all') === '1';
        field.prop('checked', all || field.attr('data-individual-show') === '1');
        field.prop('disabled', all || chequeNotePrintAllBusy || field.attr('data-note-saving') === '1');
    }
    function syncChequeNotePrintAll(show) {
        $('.cheque-note-print-all-toggle').prop('checked', show).prop('disabled', chequeNotePrintAllBusy);
        $('.cheque-note-print-toggle').attr('data-print-all', show ? '1' : '0').each(function() {
            syncChequeNotePrintField($(this));
        });
        $('.cheque-note-global-hint').toggleClass('d-none', !show);
        $('.cheque-note-individual-option').toggleClass('d-none', show);
    }
    $(document).on('change', '.cheque-note-print-all-toggle', function() {
        if (chequeNotePrintAllBusy) return;
        const field = $(this);
        const show = field.prop('checked');
        let confirmedShow = !show;
        chequeNotePrintAllBusy = true;
        $('.cheque-note-print-all-toggle, .cheque-note-print-toggle').prop('disabled', true);
        $.post(ajax_url, {
            action: 'kph_set_cheque_note_print_all',
            nonce: field.attr('data-nonce'),
            show: show ? '1' : '0',
        }, function(response) {
            if (response && response.status === 'success') {
                confirmedShow = show;
                NioApp.Toast('تنظیم چاپ یادداشت همه چک‌ها ذخیره شد.', 'success', {position: 'top-right'});
            } else {
                NioApp.Toast(response && response.message ? response.message : 'تنظیم چاپ ذخیره نشد.', 'error', {position: 'top-right'});
            }
        }).fail(function() {
            NioApp.Toast('پاسخ ذخیره دریافت نشد؛ صفحه را تازه کنید و وضعیت گزینه را بررسی کنید.', 'error', {position: 'top-right'});
        }).always(function() {
            chequeNotePrintAllBusy = false;
            syncChequeNotePrintAll(confirmedShow);
        });
    });
    $(document).on('change', '.cheque-note-print-toggle', function() {
        const field = $(this);
        const show = field.prop('checked');
        field.attr('data-note-saving', '1').prop('disabled', true);
        $.post(ajax_url, {
            action: 'kph_set_cheque_note_print',
            cheque_id: field.attr('data-cheque-id'),
            nonce: field.attr('data-nonce'),
            show: show ? '1' : '0',
        }, function(response) {
            if (response.status === 'success') field.attr('data-individual-show', show ? '1' : '0');
            NioApp.Toast(response.status === 'success' ? 'تنظیم چاپ یادداشت ذخیره شد.' : response.message, response.status, {position: 'top-right'});
        }).fail(function() {
            NioApp.Toast('تنظیم چاپ ذخیره نشد.', 'error', {position: 'top-right'});
        }).always(function() {
            field.removeAttr('data-note-saving');
            syncChequeNotePrintField(field);
        });
    });

    function supplyUpdateMaterialForm(form) {
        const warehouse=form.find('.supply-warehouse option:selected');
        const category=warehouse.attr('data-category') || '';
        form.find('[name="category_id"]').val(category);
        const existing=form.find('.supply-existing-material');
        existing.find('option[data-category]').each(function(){ $(this).prop('hidden',$(this).attr('data-category')!==category); });
        if(existing.find('option:selected').prop('hidden')) existing.val('0');
        form.find('.supply-new-material').toggleClass('d-none',existing.val()!=='0');
    }
    function supplyUpdateRuleForm(form) {
        const selected=form.find('.supply-profile option:selected');
        const unitKind=selected.attr('data-kind') || '';
        const sheet=parseInt(selected.attr('data-sheet'),10),box=parseInt(selected.attr('data-box'),10);
        form.find('.supply-profile-description').text(sheet && box ? 'هر ورق: '+sheet+' محصول — هر باکس: '+box+' ورق ('+(sheet*box)+' محصول)' : '');
        form.find('.supply-rule-material').each(function(){
            const picker=$(this),kind=picker.attr('name')==='unit_raw_id'?unitKind:(picker.attr('name')==='sheet_raw_id'?'sheet':'box');
            picker.find('option[data-kind]').each(function(){ $(this).prop('hidden',$(this).attr('data-kind')!==kind); });
            if(picker.find('option:selected').prop('hidden')) picker.val('');
        });
    }
    $(document).on('change','.supply-warehouse, .supply-existing-material',function(){ supplyUpdateMaterialForm($(this).closest('form')); });
    $(document).on('focusin','.supply-existing-material',function(){ supplyUpdateMaterialForm($(this).closest('form')); });
    $(document).on('change','.supply-profile',function(){ supplyUpdateRuleForm($(this).closest('form')); });
    $(document).on('click','.supply-edit-rule',function(){
        let rule;try{rule=JSON.parse($(this).attr('data-rule'));}catch(e){return;}
        const form=$('#supply-rule-form');
        ['product_id','profile'].forEach(function(key){form.find('[name="'+key+'"]').val(String(rule[key]));});
        supplyUpdateRuleForm(form);
        ['unit_raw_id','sheet_raw_id','box_raw_id'].forEach(function(key){form.find('[name="'+key+'"]').val(String(rule[key]));});
        form.find('[name="is_active"]').prop('checked',String(rule.is_active)==='1');
        if(form.length){form[0].scrollIntoView({behavior:'smooth',block:'center'});form.find('[name="product_id"]').trigger('focus');}
    });
    $(document).on('submit','.kph-supply-form',function(event){
        event.preventDefault();const form=$(this);if(form.data('supplySubmitting'))return;
        const data={action:'kph_manage_supplies'};
        form.serializeArray().forEach(function(pair){data[pair.name]=pair.value;});
        if(form.find('[name="is_active"]').length)data.is_active=form.find('[name="is_active"]').prop('checked')?'1':'0';
        const message=form.find('.supply-message');message.removeClass('text-danger text-success').text('در حال ثبت…');
        form.data('supplySubmitting',true);form.find('button[type="submit"]').prop('disabled',true);
        $.post(ajax_url,data,function(response){
            if(response && response.status==='success'){
                message.addClass('text-success').text(response.message);
                if(response.main)change_panel_html(response);
            }else message.addClass('text-danger').text(response && response.message ? response.message : 'پاسخ ثبت معتبر نیست.');
        }).fail(function(){message.addClass('text-danger').text('پاسخ ثبت دریافت نشد؛ پیش از تکرار، موجودی و گردش را با تازه‌کردن صفحه بررسی کنید.');})
          .always(function(){form.data('supplySubmitting',false);form.find('button[type="submit"]').prop('disabled',false);});
    });

    function extend(obj, ext) {
        Object.keys(ext).forEach(function(key) {
            obj[key] = ext[key];
        });
        return obj;
    }
    
    NioApp.ClassBody = function() {
        NioApp.AddInBody(_sidebar);
    };
    NioApp.ClassNavMenu = function() {
        NioApp.BreakClass('.' + _header_menu, _break.lg, {
            timeOut: 0,
        });
        NioApp.BreakClass('.' + _sidebar, _break.lg, {
            timeOut:  0,
            classAdd: _sidebar_mob,
        });
        $win.on('resize', function() {
            NioApp.BreakClass('.' + _header_menu, _break.lg);
            NioApp.BreakClass('.' + _sidebar, _break.lg, {
                classAdd: _sidebar_mob,
            });
        });
    };
    NioApp.Prettify = function() {
        window.prettyPrint && prettyPrint();
    };
    
    NioApp.Copied = function() {
        var clip   = '.clipboard-init',
            target = '.clipboard-text',
            sclass = 'clipboard-success',
            eclass = 'clipboard-error';
        
        // Feedback
        function feedback(el, state) {
            var $elm = $(el),
                $elp = $elm.parent(),
                copy = {
                    text: 'کپی',
                    done: 'کپی شد',
                    fail: 'ناموفق',
                },
                data = {
                    text: $elm.data('clip-text'),
                    done: $elm.data('clip-success'),
                    fail: $elm.data('clip-error'),
                };
            copy.text = data.text ? data.text : copy.text;
            copy.done = data.done ? data.done : copy.done;
            copy.fail = data.fail ? data.fail : copy.fail;
            var copytext = state === 'success' ? copy.done : copy.fail,
                addclass = state === 'success' ? sclass : eclass;
            $elp.addClass(addclass).find(target).html(copytext);
            setTimeout(function() {
                $elp.removeClass(sclass + ' ' + eclass).
                    find(target).
                    html(copy.text).
                    blur();
                $elp.find('input').blur();
            }, 2000);
        }
        
        // Init ClipboardJS
        if (ClipboardJS.isSupported()) {
            var clipboard = new ClipboardJS(clip);
            clipboard.on('success', function(e) {
                feedback(e.trigger, 'success');
                e.clearSelection();
            }).on('error', function(e) {
                feedback(e.trigger, 'error');
            });
        } else {
            $(clip).css('display', 'none');
        }
        
    };
    
    // Sticky Nav @v1.0
    NioApp.StickyNav = function() {
        var elem = document.querySelectorAll('.' + _header);
        if (elem.length > 0) {
            elem.forEach(function(item) {
                var _item_offset = 30;
                if (window.scrollY > _item_offset) {
                    item.classList.add('has-fixed');
                } else {
                    item.classList.remove('has-fixed');
                }
            });
        }
    };
    NioApp.StickyNav.init = function() {
        NioApp.StickyNav();
        window.addEventListener('scroll', function() {
            NioApp.StickyNav();
        });
    };
    
    // PasswordSwitch @v1.0
    NioApp.PassSwitch = function() {
        NioApp.Passcode('.passcode-switch');
    };
    
    // Toastr Message @v1.0
    NioApp.Toast = function(msg, ttype, opt) {
        var ttype = ttype ? ttype : 'info',
            msi   = '',
            ticon = ttype === 'info' ? 'ni ni-info-fill' : ttype ===
                                                           'success'
                                                           ? 'ni ni-check-circle-fill'
                                                           : ttype === 'error'
                                                             ? 'ni ni-cross-circle-fill'
                                                             : ttype ===
                                                               'warning'
                                                               ? 'ni ni-alert-fill'
                                                               : '',
            def   = {
                position: 'bottom-right',
                ui:       '',
                icon:     'auto',
                clear:    false,
            },
            attr  = opt ? extend(def, opt) : def;
        attr.position = attr.position
                        ? 'toast-' + attr.position
                        : 'toast-bottom-right';
        attr.icon = attr.icon === 'auto' ? ticon : attr.icon
                                                   ? attr.icon
                                                   : '';
        attr.ui = attr.ui ? ' ' + attr.ui : '';
        msi = attr.icon !== ''
              ? '<span class="toastr-icon"><em class="icon ' + attr.icon +
                  '"></em></span>'
              : '', msg = msg !== '' ? msi + '<div class="toastr-text">' + msg +
            '</div>' : '';
        if (msg !== '') {
            if (attr.clear === true) {
                toastr.clear();
            }
            var option = {
                'closeButton':       true,
                'debug':             false,
                'newestOnTop':       false,
                'progressBar':       false,
                'positionClass':     attr.position + attr.ui,
                'closeHtml':         '<span class="btn-trigger">Close</span>',
                'preventDuplicates': true,
                'showDuration':      '1500',
                'hideDuration':      '1500',
                'timeOut':           '2000',
                'toastClass':        'toastr',
                'extendedTimeOut':   '3000',
            };
            toastr.options = extend(option, attr);
            toastr[ttype](msg);
        }
    };
    
    // Toggle Screen @v1.0
    NioApp.TGL.screen = function(elm) {
        if ($(elm).exists()) {
            $(elm).each(function() {
                var ssize = $(this).data('toggle-screen');
                if (ssize) {
                    $(this).addClass('toggle-screen-' + ssize);
                }
            });
        }
    };
    
    // Toggle Content @v1.0
    NioApp.TGL.content = function(elm, opt) {
        var toggle        = elm ? elm : '.toggle',
            $toggle       = $(toggle),
            $contentD     = $('[data-content]'),
            toggleBreak   = true,
            toggleCurrent = false,
            def           = {
                active:  'active',
                content: 'content-active',
                'break': toggleBreak,
            },
            attr          = opt ? extend(def, opt) : def;
        NioApp.TGL.screen($contentD);
        $toggle.on('click', function(e) {
            toggleCurrent = this;
            NioApp.Toggle.trigger($(this).data('target'), attr);
            e.preventDefault();
        });
        $doc.on('mouseup', function(e) {
            if (toggleCurrent) {
                var $toggleCurrent  = $(toggleCurrent),
                    currentTarget   = $(toggleCurrent).data('target'),
                    $contentCurrent = $(
                        '[data-content="'.concat(currentTarget, '"]')),
                    $dpd            = $('.datepicker-dropdown'),
                    $tpc            = $('.ui-timepicker-container');
                if (!$toggleCurrent.is(e.target) &&
                    $toggleCurrent.has(e.target).length === 0 &&
                    !$contentCurrent.is(e.target) &&
                    $contentCurrent.has(e.target).length === 0 &&
                    $(e.target).closest('.select2-container').length === 0 &&
                    !$dpd.is(e.target) &&
                    $dpd.has(e.target).length === 0 && !$tpc.is(e.target) &&
                    $tpc.has(e.target).length === 0) {
                    NioApp.Toggle.removed($toggleCurrent.data('target'), attr);
                    toggleCurrent = false;
                }
            }
        });
        $win.on('resize', function() {
            $contentD.each(function() {
                var content     = $(this).data('content'),
                    ssize       = $(this).data('toggle-screen'),
                    toggleBreak = _break[ssize];
                if (NioApp.Win.width > toggleBreak) {
                    NioApp.Toggle.removed(content, attr);
                }
            });
        });
    };
    
    // ToggleExpand @v1.0
    NioApp.TGL.expand = function(elm, opt) {
        var toggle = elm ? elm : '.expand',
            def    = {
                toggle: true,
            },
            attr   = opt ? extend(def, opt) : def;
        $(toggle).on('click', function(e) {
            NioApp.Toggle.trigger($(this).data('target'), attr);
            e.preventDefault();
        });
    };
    
    // Dropdown Menu @v1.0
    NioApp.TGL.ddmenu = function(elm, opt) {
        var imenu = elm ? elm : '.nk-menu-toggle',
            def   = {
                active: 'active',
                self:   'nk-menu-toggle',
                child:  'nk-menu-sub',
            },
            attr  = opt ? extend(def, opt) : def;
        $(imenu).on('click', function(e) {
            if (NioApp.Win.width < _break.lg ||
                $(this).parents().hasClass(_sidebar)) {
                NioApp.Toggle.dropMenu($(this), attr);
            }
            e.preventDefault();
        });
    };
    
    // Show Menu @v1.0
    NioApp.TGL.showmenu = function(elm, opt) {
        var toggle      = elm ? elm : '.nk-nav-toggle',
            $toggle     = $(toggle),
            $contentD   = $('[data-content]'),
            toggleBreak = $contentD.hasClass(_header_menu)
                          ? _break.lg
                          : _break.xl,
            toggleOlay  = _sidebar + '-overlay',
            toggleClose = {
                profile: true,
                menu:    false,
            },
            def         = {
                active:  'toggle-active',
                content: _sidebar + '-active',
                body:    'nav-shown',
                overlay: toggleOlay,
                'break': toggleBreak,
                close:   toggleClose,
            },
            attr        = opt ? extend(def, opt) : def;
        $toggle.on('click', function(e) {
            NioApp.Toggle.trigger($(this).data('target'), attr);
            e.preventDefault();
        });
        $doc.on('mouseup', function(e) {
            if (!$toggle.is(e.target) && $toggle.has(e.target).length === 0 &&
                !$contentD.is(e.target) &&
                $contentD.has(e.target).length === 0 && NioApp.Win.width <
                toggleBreak) {
                NioApp.Toggle.removed($toggle.data('target'), attr);
            }
        });
        $win.on('resize', function() {
            if (NioApp.Win.width < _break.xl || NioApp.Win.width <
                toggleBreak) {
                NioApp.Toggle.removed($toggle.data('target'), attr);
            }
        });
    };
    
    // Animate FormSearch @v1.0
    NioApp.Ani.formSearch = function(elm, opt) {
        var def  = {
                active:  'active',
                timeout: 400,
                target:  '[data-search]',
            },
            attr = opt ? extend(def, opt) : def;
        var $elem   = $(elm),
            $target = $(attr.target);
        if ($elem.exists()) {
            $elem.on('click', function(e) {
                e.preventDefault();
                var $self      = $(this),
                    the_target = $self.data('target'),
                    $self_st   = $('[data-search=' + the_target + ']'),
                    $self_tg   = $('[data-target=' + the_target + ']');
                if (!$self_st.hasClass(attr.active)) {
                    $self_tg.add($self_st).addClass(attr.active);
                    $self_st.find('input').focus();
                } else {
                    $self_tg.add($self_st).removeClass(attr.active);
                }
            });
            $doc.on({
                keyup:   function keyup(e) {
                    if (e.key === 'Escape') {
                        $elem.add($target).removeClass(attr.active);
                    }
                },
                mouseup: function mouseup(e) {
                    if (!$target.is(e.target) &&
                        $target.has(e.target).length ===
                        0 && !$elem.is(e.target) &&
                        $elem.has(e.target).length === 0) {
                        $elem.add($target).removeClass(attr.active);
                    }
                },
            });
        }
    };
    
    // Animate FormElement @v1.0
    NioApp.Ani.formElm = function(elm, opt) {
        var def  = {
                focus: 'focused',
            },
            attr = opt ? extend(def, opt) : def;
        if ($(elm).exists()) {
            $(elm).each(function() {
                var $self = $(this);
                if ($self.val()) {
                    $self.parent().addClass(attr.focus);
                }
                $self.on({
                    focus: function focus() {
                        $self.parent().addClass(attr.focus);
                    },
                    blur:  function blur() {
                        if (!$self.val()) {
                            $self.parent().removeClass(attr.focus);
                        }
                    },
                });
            });
        }
    };
    
    // Form Validate @v1.0
    NioApp.Validate = function(elm, opt) {
        if ($(elm).exists()) {
            $(elm).each(function() {
                var def  = {
                        errorElement: 'span',
                    },
                    attr = opt ? extend(def, opt) : def;
                $(this).validate(attr);
            });
            NioApp.Validate.OnChange('.js-select2');
            NioApp.Validate.OnChange('.date-picker');
            NioApp.Validate.OnChange('.js-tagify');
        }
    };
    
    //On change validation for third party plugins
    NioApp.Validate.OnChange = function(elm) {
        $(elm).on('change', function() {
            $(this).valid();
        });
    };
    NioApp.Validate.init = function() {
        NioApp.Validate('.form-validate', {
            errorElement:   'span',
            errorClass:     'invalid',
            errorPlacement: function errorPlacement(error, element) {
                if (element.parents().hasClass('input-group')) {
                    error.appendTo(element.parent().parent());
                } else {
                    error.appendTo(element.parent());
                }
            },
        });
    };
    
    // Dropzone @v1.1
    NioApp.Dropzone = function(elm, opt) {
        if ($(elm).exists()) {
            $(elm).each(function() {
                var maxFiles = $(elm).data('max-files'),
                    maxFiles = maxFiles ? maxFiles : null;
                var maxFileSize = $(elm).data('max-file-size'),
                    maxFileSize = maxFileSize ? maxFileSize : 256;
                var acceptedFiles = $(elm).data('accepted-files'),
                    acceptedFiles = acceptedFiles ? acceptedFiles : null;
                var def  = {
                        autoDiscover:  false,
                        maxFiles:      maxFiles,
                        maxFilesize:   maxFileSize,
                        acceptedFiles: acceptedFiles,
                    },
                    attr = opt ? extend(def, opt) : def;
                $(this).addClass('dropzone').dropzone(attr);
            });
        }
    };
    NioApp.Dropzone.init = function() {
        if (window.Dropzone && Dropzone.autoDiscover) {
            Dropzone.autoDiscover = false;
        }
        
        $('.upload-zone').each(function() {
            const el = this;
            const $el = $(el);
            const maxFiles = parseInt($el.attr('data-max-files')) || 1;
            const target = $el.attr('data-target');
            const $target = $(target);
            const urlsStr = ($el.attr('data-urls') || '').trim();
            let isInitializing = true;
            
            $el.addClass('dropzone');
            
            const dz = new Dropzone(el, {
                url:            ajax_url,
                addRemoveLinks: true,
                maxFiles:       maxFiles,
                
                accept(file, done) {
                    const nameData = $el.attr('data-name');
                    if (!nameData) {
                        return done();
                    }
                    
                    const modal = Swal.mixin({
                        title:             'عنوان فایل',
                        html:
                                           '<div class="form-group">' +
                                               '  <label class="form-label" for="attachment_title">عنوان فایل</label>' +
                                               '  <div class="form-control-wrap">' +
                                               '    <input class="form-control" id="attachment_title">' +
                                               '  </div>' +
                                               '</div>',
                        focusConfirm:      false,
                        showCancelButton:  true,
                        confirmButtonText: 'آپلود کن',
                        cancelButtonText:  'لغو',
                        preConfirm:        () => $('#attachment_title').val(),
                    });
                    
                    modal.fire().then(res => {
                        if (res.isConfirmed && res.value) {
                            file.custom_filename = res.value;
                            done();
                        } else {
                            done('عنوان فایل وارد نشده است');
                        }
                    });
                },
                
                sending(file, xhr, formData) {
                    formData.append('action', $el.attr('data-action'));
                    if (file.custom_filename) {
                        formData.append('file_name', file.custom_filename);
                    }
                },
                
                success(file, response) {
                    // اگر سرور متن برگرداند، تلاش برای پارس
                    let resp = response;
                    if (typeof resp === 'string') {
                        try { resp = JSON.parse(resp); } catch (e) {}
                    }
                    const uploadedUrl = (resp && (resp.attachment || resp.url || resp.file_url)) || '';
                    
                    file._uploaded_url = uploadedUrl;
                    
                    let urls = ($target.val().trim() ? $target.val().split(',') : []);
                    if (uploadedUrl) {
                        urls.push(uploadedUrl);
                    }
                    
                    if (urls.length > maxFiles) {
                        urls = urls.slice(urls.length - maxFiles);
                    }
                    
                    $target.val(urls.join(','));
                    if (!isInitializing) {
                        $target.trigger('change');
                    }
                },
                
                removedfile(file) {
                    const uploadedUrl = file._uploaded_url;
                    let urls = ($target.val().trim() ? $target.val().split(',') : []);
                    if (uploadedUrl) {
                        urls = urls.filter(u => u !== uploadedUrl);
                    }
                    
                    $target.val(urls.join(','));
                    if (!isInitializing) {
                        $target.trigger('change');
                    }
                    
                    if (file.previewElement) {
                        file.previewElement.remove();
                    }
                },
            });
            
            // --- لود اولیه از data-urls + پر کردن target ---
            const urls = urlsStr.split(',').map(u => u.trim()).filter(Boolean);
            if (urls.length) {
                const initial = maxFiles ? urls.slice(-maxFiles) : urls;
                // پر کردن ورودی هدف
                $target.val(initial.join(','));
                // ساخت پیش‌نمایش‌ها
                initial.forEach(url => {
                    const mockFile = {
                        name:          url.split('/').pop(),
                        size:          123456,
                        _uploaded_url: url, // برای حذف درست
                    };
                    dz.emit('addedfile', mockFile);
                    dz.emit('thumbnail', mockFile, url);
                    dz.emit('complete', mockFile);
                    if (mockFile.previewElement) {
                        mockFile.previewElement.classList.add('dz-success', 'dz-complete');
                    }
                });
            }
            
            isInitializing = false;
        });
    };
    
    // Wizard @v1.0
    NioApp.Wizard = function() {
        var $wizard = $('.nk-wizard');
        if ($wizard.exists()) {
            $wizard.each(function() {
                var $self    = $(this),
                    _self_id = $self.attr('id'),
                    $self_id = $('#' + _self_id).show();
                $self_id.steps({
                    headerTag:      '.nk-wizard-head',
                    bodyTag:        '.nk-wizard-content',
                    labels:         {
                        finish:   'ارسال',
                        next:     'بعدی',
                        previous: 'قبلی',
                        loading:  'در حال بارگذاری ...',
                    },
                    titleTemplate:  '<span class="number">0#index#</span> #title#',
                    onStepChanging: function onStepChanging(
                        event, currentIndex, newIndex) {
                        // Allways allow previous action even if the current
                        // form is not valid!
                        if (currentIndex > newIndex) {
                            return true;
                        }
                        // Needed in some cases if the user went back (clean up)
                        if (currentIndex < newIndex) {
                            // To remove error styles
                            $self_id.find(
                                    '.body:eq(' + newIndex + ') label.error').
                                remove();
                            $self_id.find('.body:eq(' + newIndex + ') .error').
                                removeClass('error');
                        }
                        $self_id.validate().settings.ignore = ':disabled,:hidden';
                        return $self_id.valid();
                    },
                    onFinishing:    function onFinishing(event, currentIndex) {
                        $self_id.validate().settings.ignore = ':disabled';
                        return $self_id.valid();
                    },
                    onFinished:     function onFinished(event, currentIndex) {
                        window.location.href = '#';
                    },
                }).validate({
                    errorElement:   'span',
                    errorClass:     'invalid',
                    errorPlacement: function errorPlacement(error, element) {
                        error.appendTo(element.parent());
                    },
                });
            });
        }
    };
    
    // DataTable @1.1
    NioApp.DataTable = function(elm, opt) {
        if ($(elm).exists()) {
            $(elm).each(function() {
                var auto_responsive = $(this).data('auto-responsive'),
                    has_export      = typeof opt.buttons !== 'undefined' &&
                                      opt.buttons
                                      ? true
                                      : false;
                var export_title = $(this).data('export-title') ? $(this).
                    data('export-title') : 'Export';
                var btn     = has_export
                              ? '<"dt-export-buttons d-flex align-center"<"dt-export-title d-none d-md-inline-block">B>'
                              : '',
                    btn_cls = has_export ? ' with-export' : '';
                var dom_normal = '<"row justify-between g-2' + btn_cls +
                    '"<"col-7 col-sm-4 text-start"f><"col-5 col-sm-8 text-end"<"datatable-filter"<"d-flex justify-content-end g-2"' +
                    btn +
                    'l>>>><"datatable-wrap my-3"t><"row align-items-center"<"col-7 col-sm-12 col-md-9"p><"col-5 col-sm-12 col-md-3 text-start text-md-end"i>>';
                var dom_separate = '<"row justify-between g-2' + btn_cls +
                    '"<"col-7 col-sm-4 text-start"f><"col-5 col-sm-8 text-end"<"datatable-filter"<"d-flex justify-content-end g-2"' +
                    btn +
                    'l>>>><"my-3"t><"row align-items-center"<"col-7 col-sm-12 col-md-9"p><"col-5 col-sm-12 col-md-3 text-start text-md-end"i>>';
                var dom = $(this).hasClass('is-separate')
                          ? dom_separate
                          : dom_normal;
                var def  = {
                        responsive: true,
                        autoWidth:  false,
                        dom:        dom,
                        language:   {
                            search:            '',
                            searchPlaceholder: 'برای جستجو تایپ کنید',
                            lengthMenu:        '<span class=\'d-none d-sm-inline-block\'>نمایش</span><div class=\'form-control-select\'> _MENU_ </div>',
                            info:              '_START_ -_END_ از _TOTAL_',
                            infoEmpty:         '0',
                            infoFiltered:      '( کل _MAX_  )',
                            paginate:          {
                                'first':    'اول',
                                'last':     'آخر',
                                'next':     'بعدی',
                                'previous': 'قبلی',
                            },
                        },
                    },
                    attr = opt ? extend(def, opt) : def;
                attr = auto_responsive === false ? extend(attr, {
                    responsive: false,
                }) : attr;
                $(this).DataTable(attr);
                $('.dt-export-title').text(export_title);
            });
        }
    };
    
    // DataTable Init @v1.0
    NioApp.DataTable.init = function() {
        NioApp.DataTable('.datatable-init', {
            responsive: {
                details: true,
            },
        });
        NioApp.DataTable('.datatable-init-export', {
            responsive: {
                details: true,
            },
            buttons:    ['copy', 'excel', 'csv', 'pdf'],
        });
        $.fn.DataTable.ext.pager.numbers_length = 7;
    };
    
    // BootStrap Extended
    NioApp.BS.ddfix = function(elm, exc) {
        var dd = elm ? elm : '.dropdown-menu',
            ex = exc
                 ? exc
                 : 'a:not(.clickable), button:not(.clickable), a:not(.clickable) *, button:not(.clickable) *';
        $(dd).on('click', function(e) {
            if (!$(e.target).is(ex)) {
                e.stopPropagation();
                return;
            }
        });
        if (NioApp.State.isRTL) {
            var $dMenu = $('.dropdown-menu');
            $dMenu.each(function() {
                var $self = $(this);
                if ($self.hasClass('dropdown-menu-end') &&
                    !$self.hasClass('dropdown-menu-center')) {
                    $self.prev('[data-bs-toggle="dropdown"]').dropdown({
                        popperConfig: {
                            placement: 'bottom-start',
                        },
                    });
                } else if (!$self.hasClass('dropdown-menu-end') &&
                    !$self.hasClass('dropdown-menu-center')) {
                    $self.prev('[data-bs-toggle="dropdown"]').dropdown({
                        popperConfig: {
                            placement: 'bottom-end',
                        },
                    });
                }
            });
        }
    };
    
    // BootStrap Specific Tab Open
    NioApp.BS.tabfix = function(elm) {
        var tab = elm ? elm : '[data-bs-toggle="modal"]';
        $(tab).on('click', function() {
            var _this       = $(this),
                target      = _this.data('target'),
                target_href = _this.attr('href'),
                tg_tab      = _this.data('tab-target');
            var modal = target ? $body.find(target) : $body.find(
                target_href);
            if (tg_tab && tg_tab !== '#' && modal) {
                modal.find('[href="' + tg_tab + '"]').tab('show');
            } else if (modal) {
                var tabdef = modal.find('.nk-nav.nav-tabs');
                var link = $(tabdef[0]).find('[data-bs-toggle="tab"]');
                $(link[0]).tab('show');
            }
        });
    };
    
    // Dark Mode Switch @since v2.0
    NioApp.ModeSwitch = function() {
        var toggle = $('.dark-switch');
        if ($body.hasClass('dark-mode')) {
            toggle.addClass('active');
        } else {
            toggle.removeClass('active');
        }
        toggle.on('click', function(e) {
            e.preventDefault();
            $(this).toggleClass('active');
            $body.toggleClass('dark-mode');
        });
    };
    
    // Knob @v1.0
    NioApp.Knob = function(elm, opt) {
        if ($(elm).exists() && typeof $.fn.knob === 'function') {
            var def  = {
                    min: 0,
                },
                attr = opt ? extend(def, opt) : def;
            $(elm).each(function() {
                $(this).knob(attr);
            });
        }
    };
    // Knob Init @v1.0
    NioApp.Knob.init = function() {
        var knob = {
            'default': {
                readOnly: true,
                lineCap:  'round',
            },
            half:      {
                angleOffset: -90,
                angleArc:    180,
                readOnly:    true,
                lineCap:     'round',
            },
        };
        NioApp.Knob('.knob', knob['default']);
        NioApp.Knob('.knob-half', knob.half);
    };
    
    // Range @v1.0.1
    NioApp.Range = function(elm, opt) {
        if ($(elm).exists() && typeof noUiSlider !== 'undefined') {
            $(elm).each(function() {
                var $self   = $(this),
                    self_id = $self.attr('id');
                var _start        = $self.data('start'),
                    _start        = /\s/g.test(_start)
                                    ? _start.split(' ')
                                    : _start,
                    _start        = _start ? _start : 0,
                    _connect      = $self.data('connect'),
                    _connect      = /\s/g.test(_connect)
                                    ? _connect.split(' ')
                                    : _connect,
                    _connect      = typeof _connect == 'undefined'
                                    ? 'lower'
                                    : _connect,
                    _min          = $self.data('min'),
                    _min          = _min ? _min : 0,
                    _max          = $self.data('max'),
                    _max          = _max ? _max : 100,
                    _min_distance = $self.data('min-distance'),
                    _min_distance = _min_distance ? _min_distance : null,
                    _max_distance = $self.data('max-distance'),
                    _max_distance = _max_distance ? _max_distance : null,
                    _step         = $self.data('step'),
                    _step         = _step ? _step : 1,
                    _orientation  = $self.data('orientation'),
                    _orientation  = _orientation ? _orientation : 'horizontal',
                    _tooltip      = $self.data('tooltip'),
                    _tooltip      = _tooltip ? _tooltip : false;
                console.log(_tooltip);
                var target = document.getElementById(self_id);
                var def  = {
                        start:       _start,
                        connect:     _connect,
                        direction:   NioApp.State.isRTL ? 'rtl' : 'ltr',
                        range:       {
                            'min': _min,
                            'max': _max,
                        },
                        margin:      _min_distance,
                        limit:       _max_distance,
                        step:        _step,
                        orientation: _orientation,
                        tooltips:    _tooltip,
                    },
                    attr = opt ? extend(def, opt) : def;
                noUiSlider.create(target, attr);
            });
        }
    };
    
    // Range Init @v1.0
    NioApp.Range.init = function() {
        NioApp.Range('.form-control-slider');
        NioApp.Range('.form-range-slider');
    };
    NioApp.Select2.init = function() {
        NioApp.Select2('.js-select2');
    };
    
    // Slick Slider @v1.0.1
    NioApp.Slick = function(elm, opt) {
        if ($(elm).exists() && typeof $.fn.slick === 'function') {
            $(elm).each(function() {
                var def  = {
                        'prevArrow': '<div class="slick-arrow-prev"><a href="javascript:void(0);" class="slick-prev"><em class="icon ni ni-chevron-left"></em></a></div>',
                        'nextArrow': '<div class="slick-arrow-next"><a href="javascript:void(0);" class="slick-next"><em class="icon ni ni-chevron-right"></em></a></div>',
                        rtl:         NioApp.State.isRTL,
                    },
                    attr = opt ? extend(def, opt) : def;
                $(this).slick(attr);
            });
        }
    };
    
    // Slick Init @v1.0
    NioApp.Slider.init = function() {
        NioApp.Slick('.slider-init');
    };
    
    // Magnific Popup @v1.0.0
    NioApp.Lightbox = function(elm, type, opt) {
        if ($(elm).exists()) {
            $(elm).each(function() {
                var def = {};
                if (type == 'video' || type == 'iframe') {
                    def = {
                        type:            'iframe',
                        removalDelay:    160,
                        preloader:       true,
                        fixedContentPos: false,
                        callbacks:       {
                            beforeOpen: function beforeOpen() {
                                this.st.image.markup = this.st.image.markup.replace(
                                    'mfp-figure',
                                    'mfp-figure mfp-with-anim');
                                this.st.mainClass = this.st.el.attr(
                                    'data-effect');
                            },
                        },
                    };
                } else if (type == 'content') {
                    def = {
                        type:         'inline',
                        preloader:    true,
                        removalDelay: 400,
                        mainClass:    'mfp-fade content-popup',
                    };
                } else {
                    def = {
                        type:      'image',
                        mainClass: 'mfp-fade image-popup',
                    };
                }
                var attr = opt ? extend(def, opt) : def;
                $(this).magnificPopup(attr);
            });
        }
    };
    
    // Controls @v1.0.0
    NioApp.Control = function(elm) {
        var control = document.querySelectorAll(elm);
        control.forEach(function(item, index, arr) {
            item.checked ? item.parentNode.classList.add('checked') : null;
            item.addEventListener('change', function() {
                if (item.type == 'checkbox') {
                    item.checked
                    ? item.parentNode.classList.add('checked')
                    : item.parentNode.classList.remove(
                        'checked');
                }
                if (item.type == 'radio') {
                    document.querySelectorAll(
                            'input[name="' + item.name + '"]').
                        forEach(function(item, index, arr) {
                            item.parentNode.classList.remove('checked');
                        });
                    item.checked
                    ? item.parentNode.classList.add('checked')
                    : null;
                }
            });
        });
    };
    
    // Number Spinner @v1.0
    NioApp.NumberSpinner = function(elm, opt) {
        var plus = document.querySelectorAll('[data-number=\'plus\']');
        var minus = document.querySelectorAll('[data-number=\'minus\']');
        plus.forEach(function(item, index, arr) {
            var parent = plus[index].parentNode;
            plus[index].addEventListener('click', function() {
                var child = plus[index].parentNode.children;
                child.forEach(function(item, index, arr) {
                    if (child[index].classList.contains('number-spinner')) {
                        var value = !child[index].value == '' ? parseInt(
                            child[index].value) : 0;
                        var step = !child[index].step == ''
                                   ? parseInt(child[index].step)
                                   : 1;
                        var max = !child[index].max == ''
                                  ? parseInt(child[index].max)
                                  : Infinity;
                        if (max + 1 > value + step) {
                            child[index].value = value + step;
                        } else {
                            child[index].value = value;
                        }
                    }
                });
            });
        });
        minus.forEach(function(item, index, arr) {
            var parent = minus[index].parentNode;
            minus[index].addEventListener('click', function() {
                var child = minus[index].parentNode.children;
                child.forEach(function(item, index, arr) {
                    if (child[index].classList.contains('number-spinner')) {
                        var value = !child[index].value == '' ? parseInt(
                            child[index].value) : 0;
                        var step = !child[index].step == ''
                                   ? parseInt(child[index].step)
                                   : 1;
                        var min = !child[index].min == ''
                                  ? parseInt(child[index].min)
                                  : 0;
                        if (min - 1 < value - step) {
                            child[index].value = value - step;
                        } else {
                            child[index].value = value;
                        }
                    }
                });
            });
        });
    };
    
    // Stepper @v1.0
    NioApp.Stepper = function(elm, opt) {
        var element = document.querySelectorAll(elm);
        if (element.length > 0) {
            element.forEach(function(item, index) {
                var def  = {
                        selectors:    {
                            nav:      'stepper-nav',
                            progress: 'stepper-progress',
                            content:  'stepper-steps',
                            prev:     'step-prev',
                            next:     'step-next',
                            submit:   'step-submit',
                        },
                        classes:      {
                            nav_current: 'current',
                            nav_done:    'done',
                            step_active: 'active',
                            step_done:   'done',
                            active_step: 'active',
                        },
                        current_step: 1,
                    },
                    attr = opt ? extend(def, opt) : def;
                NioApp.Custom.Stepper(item, attr);
                NioApp.Validate.OnChange('.js-select2');
                NioApp.Validate.OnChange('.date-picker');
                NioApp.Validate.OnChange('.js-tagify');
            });
        }
    };
    // Stepper Init @v1.0
    NioApp.Stepper.init = function() {
        NioApp.Stepper('.stepper-init');
    };
    
    // Tagify @v1.0.1
    NioApp.Tagify = function(elm, opt) {
        if ($(elm).exists() && typeof $.fn.tagify === 'function') {
            var def,
                attr = opt ? extend(def, opt) : def;
            $(elm).tagify(attr);
        }
    };
    // Tagify Init @v1.0
    NioApp.Tagify.init = function() {
        NioApp.Tagify('.js-tagify');
    };
    
    /* Isotope - Filter @v1.0 */
    NioApp.Filter = function(elem, childSelector) {
        var qsRegex;
        var elm = document.querySelectorAll(elem);
        elm.forEach(function(item) {
            if (typeof item != 'undefined' && item != null) {
                var iso = new Isotope(item, {
                    itemSelector: childSelector,
                    layoutMode:   'fitRows',
                    filter:       function filter(itemElem) {
                        return qsRegex
                               ? itemElem.textContent.match(qsRegex)
                               : true;
                    },
                    hiddenStyle:  {
                        opacity:   0,
                        transform: 'scale(0.001)',
                    },
                    visibleStyle: {
                        opacity:   1,
                        transform: 'scale(1)',
                    },
                });
                var filterBtn = document.querySelectorAll('[data-filter]');
                console.log();
                filterBtn.forEach(function(btnItem) {
                    btnItem.addEventListener('click', function(event) {
                        // only work with buttons
                        if (!matchesSelector(event.target, 'button')) {
                            return;
                        }
                        var filterValue = event.target.getAttribute(
                            'data-filter');
                        iso.arrange({
                            filter: filterValue,
                        });
                        filterBtn.forEach(function(allButtons) {
                            allButtons.classList.remove('active');
                        });
                        btnItem.classList.add('active');
                    });
                });
            }
        });
    };
    
    // Extra @v1.1
    NioApp.OtherInit = function() {
        NioApp.ClassBody();
        NioApp.PassSwitch();
        NioApp.LinkOff('.is-disable');
        NioApp.ClassNavMenu();
        NioApp.SetHW('[data-height]', 'height');
        NioApp.SetHW('[data-width]', 'width');
        NioApp.NumberSpinner();
        NioApp.Lightbox('.popup-video', 'video');
        NioApp.Lightbox('.popup-iframe', 'iframe');
        NioApp.Lightbox('.popup-image', 'image');
        NioApp.Lightbox('.popup-content', 'content');
        NioApp.Control('.custom-control-input');
        NioApp.Filter('.filter-container', '.filter-item');
    };
    
    // Animate Init @v1.0
    NioApp.Ani.init = function() {
        NioApp.Ani.formElm('.form-control-outlined');
        NioApp.Ani.formSearch('.toggle-search');
    };
    
    // BootstrapExtend Init @v1.0
    NioApp.BS.init = function() {
        NioApp.BS.menutip('a.nk-menu-link');
        NioApp.BS.tooltip('.nk-tooltip');
        NioApp.BS.tooltip('.btn-tooltip', {
            placement: 'top',
        });
        NioApp.BS.tooltip('[data-toggle="tooltip"]');
        NioApp.BS.tooltip('[data-bs-toggle="tooltip"]');
        NioApp.BS.tooltip('.tipinfo,.nk-menu-tooltip', {
            placement: 'right',
        });
        NioApp.BS.popover('[data-toggle="popover"]');
        NioApp.BS.popover('[data-bs-toggle="popover"]');
        NioApp.BS.progress('[data-progress]');
        NioApp.BS.fileinput('.form-file-input');
        NioApp.BS.modalfix();
        NioApp.BS.ddfix();
        NioApp.BS.tabfix();
    };
    
    // Picker Init @v1.0
    NioApp.Picker.init = function() {
        NioApp.Picker.date('.date-picker');
        NioApp.Picker.dob('.date-picker-alt');
        NioApp.Picker.time('.time-picker');
        NioApp.Picker.date('.date-picker-range', {
            todayHighlight: false,
            autoclose:      false,
        });
        NioApp.Picker.date('.date-picker-ym', {
            format:      'yy/mm',
            startView:   2,
            autoclose:   true,
            maxViewMode: 2,
            minViewMode: 1,
        });
    };
    
    // Addons @v1
    NioApp.Addons.Init = function() {
        NioApp.Knob.init();
        NioApp.Range.init();
        NioApp.Select2.init();
        NioApp.Dropzone.init();
        NioApp.Slider.init();
        NioApp.DataTable.init();
        NioApp.Tagify.init();
    };
    
    // Toggler @v1
    NioApp.TGL.init = function() {
        NioApp.TGL.content('.toggle');
        NioApp.TGL.expand('.toggle-expand');
        NioApp.TGL.expand('.toggle-opt', {
            toggle: false,
        });
        NioApp.TGL.showmenu('.nk-nav-toggle');
        NioApp.TGL.ddmenu('.' + _menu + '-toggle', {
            self:  _menu + '-toggle',
            child: _menu + '-sub',
        });
    };
    NioApp.BS.modalOnInit = function() {
        $('.modal').on('shown.bs.modal', function() {
            NioApp.Select2.init();
            NioApp.Validate.init();
        });
    };
    
    NioApp.Quill = function() {
        var _basic = '.quill-basic';
        if ($(_basic).exists()) {
            $(_basic).each(function() {
                var toolbarOptions = [
                    ['bold', 'italic', 'underline', 'strike'],        // toggled
                                                                      // buttons
                    ['blockquote', 'code-block'],
                    
                    [{'list': 'ordered'}, {'list': 'bullet'}],
                    [{'script': 'sub'}, {'script': 'super'}],      // superscript/subscript
                    [{'indent': '-1'}, {'indent': '+1'}],          // outdent/indent
                    
                    [{'header': [1, 2, 3, 4, 5, 6]}],
                    
                    [{'color': []}, {'background': []}],          // dropdown
                                                                  // with
                                                                  // defaults
                                                                  // from theme
                    [{'align': []}],
                    
                    ['link'],
                    ['clean'],
                ];
                
                var quill = new Quill(this, {
                    modules: {
                        toolbar: toolbarOptions,
                    },
                    theme:   'snow',
                });
            });
        }
        
        var _minimal = '.quill-minimal';
        if ($(_minimal).exists()) {
            $(_minimal).each(function() {
                var toolbarOptions = [
                    ['bold', 'italic', 'underline'],        // toggled buttons
                    ['blockquote', {'list': 'bullet'}],
                    [{'align': []}],
                    ['clean'],                                         // remove
                ];
                
                var quill = new Quill(this, {
                    modules: {
                        toolbar: toolbarOptions,
                    },
                    theme:   'snow',
                });
            });
        }
    };
    
    function activate_date_pickers() {
        let years = [];
        for (let i = 1321; i <= 1407; i++) {
            years.push(i);
        }
        $('.datepicker').each(function() {
            let _this = $(this);
            let args = {
                nextArrow:       '<i class="fas fa-chevron-left"></i>',
                prevArrow:       '<i class="fas fa-chevron-right"></i>',
                formatDate:      'YYYY-MM-DD',
                cellWidth:       27,
                cellHeight:      26,
                selectableYears: years,
                onSelect:        function() {
                    _this.trigger('change');
                },
            };
            if (_this.attr('data-kph-hr-date') === '1') {
                let typedDate = String(_this.val() || '').replace(/[۰-۹]/g, c => '۰۱۲۳۴۵۶۷۸۹'.indexOf(c)).replace(/[٠-٩]/g, c => '٠١٢٣٤٥٦٧٨٩'.indexOf(c)).replace(/-/g, '/');
                if (/^1[3-6]\d{2}\/\d{1,2}\/\d{1,2}$/.test(typedDate)) args.selectedDate = typedDate;
                args.selectedBefore = false;
            } else if (_this.attr('data-value')) {
                let selectedDate = _this.attr('data-value');
                args['selectedDate'] = new Date(
                    selectedDate).toLocaleDateString(
                    'fa-IR-u-nu-latn');
                args['selectedBefore'] = !0;
            }
            _this.persianDatepicker(args);
        });
    }
    
    function add_loading_block() {
        let loading_html = '<div class="modal fade" id="loading_modal">'
            + '<div class="modal-dialog">'
            +
            '<div class="spinner-border text-light" style="width: 3rem; height: 3rem; margin: auto" role="status"></div>'
            + '</div></div>';
        $('#loading_modal').remove();
        $('body').append(loading_html);
    }
    
    function show_loading_modal() {
        $('#loading_modal').addClass('show').css('display', 'block');
    }
    
    function hide_loading_modal() {
        $('#loading_modal').removeClass('show').css('display', 'none');
    }
    
    function validate_phone_number(phone) {
        let regex = /^(\+98|0)?9\d{9}$/;
        return regex.test(toEnglishNumber(phone));
    }
    
    function validate_slug(slug) {
        let regex = /^[a-zA-Z0-9-_]+$/;
        return regex.test(slug);
    }
    
    function number_format(number) {
        return new Intl.NumberFormat('en').format(number);
    }
    
    function toEnglishNumber(strNum, element = null) {
        let pn    = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'],
            en    = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'],
            cache = strNum,
            i;
        if (!strNum) {
            return 0;
        }
        for (i = 0; i < 10; i++) {
            let regex_fa = new RegExp(pn[i], 'g');
            cache = cache.replace(regex_fa, en[i]);
        }
        if (element) {
            $(element).val(cache);
        } else {
            return cache;
        }
    }
    
    function sanitizeNumber(number) {
        if (!number) {
            return 0;
        }
        number = toEnglishNumber(number);
        return parseInt(number.replace(/,/g, '')) || 0;
    }
    
    function formatNumber(num) {
        if (num >= 1_000_000_000) {
            return (num / 1_000_000_000).toFixed(2) + ' میلیارد';
        } else if (num >= 1_000_000) {
            return (num / 1_000_000).toFixed(2) + ' میلیون';
        } else if (num >= 1_000) {
            return (num / 1_000).toFixed(2) + ' هزار';
        }
        return num.toFixed(2);
    }
    
    NioApp.init = function() {
        NioApp.coms.docReady.push(NioApp.OtherInit);
        NioApp.coms.docReady.push(NioApp.Prettify);
        NioApp.coms.docReady.push(NioApp.ColorBG);
        NioApp.coms.docReady.push(NioApp.ColorTXT);
        NioApp.coms.docReady.push(NioApp.Copied);
        NioApp.coms.docReady.push(NioApp.Ani.init);
        NioApp.coms.docReady.push(NioApp.TGL.init);
        NioApp.coms.docReady.push(NioApp.BS.init);
        NioApp.coms.docReady.push(NioApp.Validate.init);
        NioApp.coms.docReady.push(NioApp.Picker.init);
        NioApp.coms.docReady.push(NioApp.Addons.Init);
        NioApp.coms.docReady.push(NioApp.Wizard);
        NioApp.coms.docReady.push(NioApp.Stepper.init);
        NioApp.coms.winLoad.push(NioApp.ModeSwitch);
        NioApp.coms.winLoad.push(NioApp.StickyNav.init);
        NioApp.coms.docReady.push(NioApp.Quill);
        if (typeof activate_charts === 'function') {
            NioApp.coms.docReady.push(activate_charts);
        }
        activate_date_pickers();
        add_loading_block();
    };
    NioApp.ajaxInit = function() {
        NioApp.OtherInit();
        NioApp.Prettify();
        NioApp.ColorBG();
        NioApp.ColorTXT();
        NioApp.Copied();
        NioApp.Ani.init();
        NioApp.TGL.init();
        NioApp.BS.init();
        NioApp.Validate.init();
        NioApp.Picker.init();
        NioApp.Addons.Init();
        NioApp.Wizard();
        NioApp.ModeSwitch();
        NioApp.Stepper.init();
        NioApp.StickyNav.init();
        NioApp.Quill();
        activate_date_pickers();
        add_loading_block();
        if (typeof activate_charts === 'function') {
            activate_charts();
        }
        $('.modal').on('shown.bs.modal', function() {
            const inst = bootstrap.Modal.getInstance(this);
            if (inst) {
                inst._focustrap.deactivate();
            }
        });
    };
    
    NioApp.init();
    
    function request_panel_page_content($url) {
        if (!$url) return;
        const panelUrl = new URL($url, window.location.href);
        if (panelUrl.origin !== window.location.origin) return;
        show_loading_modal();
        let data = {
            'action': 'kph_request_page_content',
            'page':   panelUrl.pathname,
        };
        panelUrl.searchParams.forEach((value, key) => {
            if (key !== 'action' && key !== 'page') data[key] = value;
        });
        $.post(ajax_url, data, function(response) {
            change_panel_html(response);
            history.pushState({}, '', response.url);
        });
    }
    
    let time,
        timer_interval;
    
    function start_timer() {
        let timer_div = $('.otp_timer');
        timer_div.addClass('disabled');
        timer_div.html(`<span>دریافت مجدد کد:</span>
                            <span class="timer_text">01:00</span>`);
        time = 60;
        timer_interval = setInterval(function() {
            time--;
            let timer = (time < 10) ? '0' + time : time;
            timer_div.find('.timer_text').text('00:' + timer);
            if (time === 0) {
                clearInterval(timer_interval);
                timer_div.html('دریافت مجدد پیامک');
                timer_div.removeClass('disabled');
            }
        }, 1000);
    }
    
    function activate_otp_inputs() {
        let inputs = $('#otp_input_form').find('input');
        let len = inputs.length;
        inputs.each(function() {
            $(this).val('');
        });
        
        const handlePaste = (ev) => {
            const clip = ev.clipboardData.getData('text');
            const pin = clip.replace(/\s/g, '');
            const ch = [...pin];
            inputs.removeClass('filled');
            inputs.each(function(index, element) {
                element.value = ch[index] ?? '';
                if (ch[index]) {
                    $(element).addClass('filled');
                }
            });
            inputs[pin.length - 1].focus();                  // Focus input
        };
        const handleInput = (ev) => {
            const elInp = ev.currentTarget;
            const i = inputs.index(elInp);
            if (elInp.value && (i + 1) % len) {
                inputs[i + 1].focus();
            }
            let full_code = '';
            inputs.removeClass('filled');
            inputs.each(function(index, element) {
                if ($(element).val()) {
                    $(element).addClass('filled');
                }
                full_code += $(element).val() + '';
            });
            $('#otp_input_form').attr('data-code', full_code);
        };
        const handleKeyDn = (ev) => {
            const elInp = ev.currentTarget;
            const i = inputs.index(elInp);
            if (elInp.value) {
                $(elInp).addClass('filled');
            } else {
                $(elInp).removeClass('filled');
            }
            if (!elInp.value && ev.key === 'Backspace' && i) {
                inputs[i - 1].focus();
            }
            if (ev.key === 'Enter') {
                $('#otp_modal').find('.submit_otp_btn').trigger('click');
            }
        };
        inputs.each(function(index, element) {
            element.addEventListener('paste', handlePaste);   // Handle pasting
            element.addEventListener('input', handleInput);   // Handle typing
            element.addEventListener('keydown', handleKeyDn); // Handle deleting
        });
    }
    
    function focus_first_otp_input() {
        let inputs = $('#otp_input_form').find('input');
        inputs.each(function() {
            $(this).val('');
        });
        inputs.removeClass('filled');
        inputs[0].focus();
    }
    
    function get_current_page_filters() {
        const data = {
            search: $('.search_kph_list').val(),
            id:     $('#current_user_id').val(),
        };
        
        const customerReportView = $('#kph_customer_report_view');
        if (customerReportView.length) {
            data.report_view = 'customers';
            const customerId = Number(customerReportView.attr('data-customer-id')) || 0;
            if (customerId) data.customer_id = customerId;
        }
        $('.filter_form_wrapper').find('input, select').each(function() {
            const $el = $(this);
            const type = $el.attr('type');
            const key = $el.data('for');
            const val = $el.val();
            
            if (!key) {
                return;
            }
            
            if (type === 'checkbox' && !$el.prop('checked')) {
                return;
            }
            if (type === 'radio' && !$el.prop('checked')) {
                return;
            }
            
            const match = key.match(/^(\w+)\[(\w+)\]$/);
            
            if (match) {
                const [, main, sub] = match;
                data[main] = data[main] || {};
                
                if (type === 'checkbox') {
                    data[main][sub] = data[main][sub] || [];
                    data[main][sub].push(val);
                } else {
                    data[main][sub] = val;
                }
            } else {
                if (type === 'checkbox') {
                    data[key] = data[key] || [];
                    data[key].push(val);
                } else {
                    data[key] = val;
                }
            }
        });
        
        return data;
    }
    
    function change_panel_html(response) {
        $('.modal').modal('hide');
        $('.nk-app-root').html(response.main);
        $('.modal-backdrop').remove();
        $('.tooltip').remove();
        if (response.title) {
            document.title = response.title;
        }
        NioApp.ajaxInit();
        $(document).trigger('kph-preparation-refresh');
        if (response.message) {
            NioApp.Toast(response.message, response.status,
                {position: 'top-right'});
        }
    }
    
    $(document).ajaxSend(function() {
        if (ajax_search) {
            return;
        }
        show_loading_modal();
    });
    $(document).ajaxStop(function() {
        hide_loading_modal();
    });
    
    $(document).on('keyup', '.price_input', function(e) {
        toEnglishNumber($(this).val(), this);
        this.value = this.value.replace(/\D/g, '');
        $(this).val(number_format(this.value));
    });
    
    $(document).on('click', '.filter_drop_down_toggle', function(e) {
        e.stopPropagation();
        $(this).next('.filters_input_box').toggleClass('show');
        NioApp.Select2.init();
    });
    $(document).on('click', 'body', function() {
        $('.filters_input_box').removeClass('show');
    });
    $(document).on('click', '.page_activator', function(e) {
        e.preventDefault();
        request_panel_page_content($(this).attr('data-url') || $(this).attr('href'));
    });
    $(window).on('popstate', function() {
        let data = {
            'action': 'kph_request_back_btn',
            'path':   window.location.href,
        };
        $.post(ajax_url, data, function(response) {
            change_panel_html(response);
        });
    });
    $(document).on('change', '.datepicker', function() {
        let val = $(this).val();
        if (val === '') {
            $(this).attr('data-value', '');
            $(this).attr('data-gdate', '');
            $(this).attr('data-jdate', '');
        }
    });
    $(document).on('click', '.pdp-default', function(e) {
        e.stopPropagation();
    });
    $(document).on('click', '.change-skin', function(e) {
        e.preventDefault();
        let skin = $(this).attr('data-skin');
        let data = {
            'action': 'kph_change_skin',
            'skin':   skin,
        };
        $.post(ajax_url, data, function() {
            location.reload();
        });
    });
    
    $(document).on('click', '.submit_login_form', function() {
        let data = {
            action:   'kph_submit_login_form',
            username: $('#username').val(),
            password: $('#password').val(),
        };
        if (data.username === '' || data.password === '') {
            NioApp.Toast('نام کاربری و رمز عبور را وارد کنید', 'error',
                {position: 'top-right'});
            return;
        }
        $.post(ajax_url, data, function(response) {
            NioApp.Toast(response.message, response.status,
                {position: 'top-right'});
            if (response.status === 'error') {
                return;
            }
            location.reload();
        });
    });
    $(document).on('click', '.send_otp', function() {
        let phone = $('#otp_phone').val();
        if (phone === '') {
            NioApp.Toast('شماره تلفن همراه را وارد کنید', 'error',
                {position: 'top-right'});
            return;
        }
        if (!validate_phone_number(phone)) {
            NioApp.Toast('شماره تلفن همراه معتبر نیست', 'error',
                {position: 'top-right'});
            return;
        }
        
        let data = {
            action: 'kph_send_login_otp',
            phone:  phone,
        };
        $.post(ajax_url, data, function(response) {
            NioApp.Toast(response.message, response.status,
                {position: 'top-right'});
            if (response.status === 'error') {
                return;
            }
            $('.each_login_form').removeClass('active');
            $('.otp_login_text').text(`کد تایید برای شماره ${phone} پیامک شد`);
            $('#submit_otp_form').addClass('active');
            focus_first_otp_input();
            clearInterval(timer_interval);
            start_timer();
            activate_otp_inputs();
        });
    });
    $(document).on('click', '.otp_timer', function() {
        let phone = $('#otp_phone').val();
        let data = {
            action: 'kph_send_login_otp',
            phone:  phone,
        };
        $.post(ajax_url, data, function(response) {
            NioApp.Toast(response.message, response.status,
                {position: 'top-right'});
            if (response.status === 'error') {
                return;
            }
            $('.each_login_form').removeClass('active');
            $('.otp_login_text').text(`کد تایید برای شماره ${phone} پیامک شد`);
            $('#submit_otp_form').addClass('active');
            focus_first_otp_input();
            clearInterval(timer_interval);
            start_timer();
            activate_otp_inputs();
        });
    });
    
    $(document).on('click', '.submit_otp', function() {
        let phone = $('#otp_phone').val(),
            otp   = $('#otp_input_form').attr('data-code');
        if (!otp || otp.length < 4) {
            NioApp.Toast('کد تایید را وارد کنید', 'error',
                {position: 'top-right'});
            return;
        }
        let data = {
            action: 'kph_submit_login_otp',
            phone:  phone,
            otp:    otp,
        };
        $.post(ajax_url, data, function(response) {
            NioApp.Toast(response.message, response.status,
                {position: 'top-right'});
            if (response.status === 'error') {
                focus_first_otp_input();
                return;
            }
            location.reload();
        });
    });
    $(document).on('click', '.toggle_login_form', function() {
        $('.each_login_form').removeClass('active');
        let id = $(this).attr('data-url');
        $(id).addClass('active');
    });
    $(document).on('click', '.change_pass', function() {
        let old_pass = $('#old_password').val();
        let new_pass = $('#new_password').val();
        let rep_pass = $('#confirm_password').val();
        if (new_pass !== rep_pass) {
            NioApp.Toast('رمز عبور جدید و تکرار آن باید یکسان باشند', 'error',
                {position: 'top-right'});
            return;
        }
        const input = {
            old_pass: old_pass,
            new_pass: new_pass,
            action:   'kph_submit_change_password_form',
        };
        $.post(ajax_url, input, function(response) {
            if (response.status === 'failed') {
                NioApp.Toast(response.msg, 'error', {position: 'top-right'});
            } else {
                NioApp.Toast(response.msg, 'success', {position: 'top-right'});
                location.reload();
            }
        });
    });
    let search_ajax;
    $(document).on('input', '#header_user_search', function(e) {
        ajax_search = true;
        let result = $('.search_result_container');
        if (this.value === '') {
            result.html('').hide();
            return;
        }
        if (typeof search_ajax === 'object') {
            search_ajax.abort();
        }
        result.show();
        let data = {
            action: 'kph_search_user',
            search: this.value,
        };
        search_ajax = $.post(ajax_url, data, function(response) {
            result.html(response.searchResult);
            ajax_search = false;
        });
    });
    $(document).on('click', 'body', function() {
        $('.search_result_container').hide();
    });
    $(document).on('click', '.card-search', function(e) {
        e.stopPropagation();
        $('.search_result_container').show();
    });
    
    $(document).on('click', '.dark-switch', function(e) {
        let is_active = $(this).hasClass('active');
        let data = {
            action:    'kph_save_dark_mode',
            is_active: is_active,
        };
        ajax_search = true;
        $.post(ajax_url, data, function() {
            ajax_search = false;
        });
    });
    $(document).on('click', '[data-bs-target="#addCustomer"]', function() {
        let search = $('#header_user_search').val();
        let is_numeric = parseInt(search) == search;
        if (is_numeric) {
            $('#new_customer_phone').val(search);
        } else {
            $('#new_customer_user_name').val(search);
        }
    });
    $(document).on('click', '.change_per_page a', function(e) {
        e.preventDefault();
    });
    $(document).on('click', '.delete_user', function(e) {
        e.preventDefault();
        let user_id = $(this).attr('data-user-id');
        let page = $(this).attr('data-page');
        let data = {
            action:  'kph_delete_user',
            user_id: user_id,
            page:    page,
        };
        Swal.fire({
            title:             'آیا از حذف این کاربر اطمینان دارید؟',
            icon:              'warning',
            text:              'این عملیات غیر قابل بازگشت است',
            focusConfirm:      false,
            showCancelButton:  true,
            confirmButtonText: 'بله',
            cancelButtonText:  `خیر`,
        }).then((result) => {
            if (result.isConfirmed) {
                $.post(ajax_url, data, function(response) {
                    change_panel_html(response);
                    history.pushState({}, '', response.url);
                });
            }
        });
    });
    $(document).on('click', '.change_per_page', function() {
        let per_page = $(this).attr('data-per-page');
        let currentPage = $('#current_page').val();
        
        let data = {
            action:   'kph_request_page_content',
            page:     currentPage,
            per_page: per_page,
        };
        $.post(ajax_url, data, function(response) {
            change_panel_html(response);
            history.pushState({}, '', response.url);
        });
    });
    $(document).on('click', '.page-link', function(e) {
        e.preventDefault();
    });
    $(document).on('click', '.reset_page_filter', function(e) {
        e.preventDefault();
        let data = {
            action: 'kph_request_page_content',
            page:   $('#current_page').val(),
            id:     $('#current_user_id').val(),
        };
        $.post(ajax_url, data, function(response) {
            change_panel_html(response);
            history.pushState({}, '', response.url);
        });
    });
    $(document).on('change', '.activate_logic', function() {
        let id = $(this).attr('data-target');
        let target_value = $(this).attr('data-target-value');
        let selected = this.value;
        
        $('.conditional_show[data-logic="' + id + '"]').each(function() {
            let $box = $(this);
            let logic = $box.attr('data-value');
            if (target_value !== undefined && target_value !== '') {
                $box.find('input, select, textarea').each(function() {
                    let $field = $(this);
                    
                    if ($field.is(':checkbox') || $field.is(':radio')) {
                        $field.prop('checked', $field.val() == target_value).trigger('change');
                    } else {
                        $field.val(target_value).trigger('change');
                    }
                });
            }
            if (logic === selected) {
                $box.show();
            } else {
                $box.hide();
            }
        });
    });
    $(document).on('click', '.page-item', function() {
        let page = $(this).attr('data-page');
        let target = $(this).attr('data-target');
        if (target == 'root') {
            let currentPage = $('#current_page').val();
            let currentID = $('#current_user_id').val();
            let data = get_current_page_filters();
            if (currentID) {
                currentPage = currentPage + '/' + currentID;
            }
            data.action = 'kph_request_page_content';
            data.page = currentPage;
            data.page_number = page;
            const extra = $(this).data();
            Object.keys(extra).forEach((k) => {
                if (k === 'page') {
                    return;
                }
                data[k] = extra[k];
            });
            $.post(ajax_url, data, function(response) {
                change_panel_html(response);
                history.pushState({}, '', response.url);
            });
        } else {
            let data = {
                action:      $(this).attr('data-action'),
                page_number: page,
            };
            $.post(ajax_url, data, function(response) {
                console.log($(target));
                $(target).html(response.html);
            });
        }
    });
    $(document).on('click', '.filter_kph_list', function() {
        let currentPage = $('#current_page').val();
        let data = get_current_page_filters();
        data.action = 'kph_request_page_content';
        data.page = currentPage;
        $.post(ajax_url, data, function(response) {
            change_panel_html(response);
            history.pushState({}, '', response.url);
        });
    });
    $(document).on('input', '.search_kph_list', function() {
        ajax_search = true;
        let currentPage = $('#current_page').val();
        let data = get_current_page_filters();
        
        if (typeof search_ajax === 'object') {
            search_ajax.abort();
        }
        data.action = 'kph_request_page_content';
        data.page = currentPage;
        search_ajax = $.post(ajax_url, data, function(response) {
            change_panel_html(response);
            history.pushState({}, '', response.url);
            const $input = $('.search_kph_list');
            $input.trigger('focus');
            const val = $input.val();
            $input.val('').val(val);
            ajax_search = false;
        });
    });
    $(document).on('click', '.login_as_this', function(e) {
        e.preventDefault();
        let user_id = $(this).attr('data-id');
        let data = {
            action:  'kph_login_as_user',
            user_id: user_id,
        };
        $.post(ajax_url, data, function(response) {
            window.location.href = response.url;
        });
    });
    $(document).on('click', '.change_role', function() {
        let user_id = $(this).parents('.employees_row').attr('data-id');
        let select_role = $('#new_marketer_role').html();
        let modal = Swal.mixin({
            title:             'تغییر نقش تامین‌کننده',
            html:              '<div class="form-group">' +
                                   '<label class="form-label" for="new_marketer_role">نقش</label>' +
                                   '<div class="form-control-wrap">' +
                                   '<select class="form-select" id="edit_user_role">' +
                                   select_role + '</select>' +
                                   '</div>' +
                                   '</div>',
            focusConfirm:      false,
            showCancelButton:  true,
            confirmButtonText: 'ذخیره تغییرات',
            cancelButtonText:  `لغو`,
            onRender:          function() {
                activate_date_pickers();
            },
        });
        modal.fire().then(function(result) {
            if (result.isConfirmed) {
                let data = {
                    action:  'kph_update_user_role',
                    user_id: user_id,
                    role:    $('#edit_user_role').val(),
                };
                $.post(ajax_url, data, function(response) {
                    change_panel_html(response);
                    NioApp.Toast(response.msg, 'success',
                        {position: 'top-right'});
                });
            }
        });
    });
    $(document).on('click', 'a.btn-trigger', function(e) {
        // Preserve native navigation for actions explicitly opened in a new tab.
        const href = this.getAttribute('href');
        if (this.getAttribute('target') === '_blank' && href && href.charAt(0) !== '#') {
            return;
        }
        e.preventDefault();
    });
    $(document).on('click', '.reset_password', function(e) {
        e.preventDefault();
        let user_id = $(this).attr('data-id');
        let data = {
            action:  'kph_reset_password',
            user_id: user_id,
        };
        $.post(ajax_url, data, function(response) {
            Swal.fire({
                title:             'رمز عبور تغییر کرد.',
                html:              response.html,
                focusConfirm:      false,
                confirmButtonText: 'باشه',
            });
        });
    });
    $(document).on('click', '.save_site_settings', function() {
        let inputs = $('.site_setting_field');
        let options = {};
        inputs.each(function() {
            let key = $(this).attr('data-for');
            if ($(this).attr('type') === 'checkbox') {
                options[key] = $(this).is(':checked');
            } else {
                options[key] = $(this).val();
            }
        });
        let data = {
            action:  'kph_save_site_settings',
            options: options,
            tab:     $(this).attr('data-tab'),
        };
        $.post(ajax_url, data, function(response) {
            change_panel_html(response);
            history.pushState({}, '', response.url);
        });
    });
    
    function getFieldValueByMeta(metaKey, $scope) {
        let $el = $scope.find('[data-for="' + metaKey + '"], [data-for="meta[' + metaKey + ']"]').first();
        if (!$el.length) {
            return null;
        }
        
        let tag = ($el.prop('tagName') || '').toLowerCase();
        let type = ($el.attr('type') || '').toLowerCase();
        
        if (tag === 'select') {
            return $el.val();
        }
        if (tag === 'textarea') {
            return $el.val();
        }
        if (type === 'checkbox') {
            return $el.is(':checked') ? '1' : '0';
        }
        return $el.val();
    }
    
    function matchCondition(actual, expected, operator) {
        let isArray = Array.isArray(expected);
        let isMatch = isArray ? expected.indexOf(actual) !== -1 : (actual ===
            expected);
        return (operator === '!=') ? !isMatch : isMatch;
    }
    
    function parseExpected(jsonStr) {
        try {
            let parsed = JSON.parse(jsonStr);
            if (Array.isArray(parsed)) {
                return parsed.map(function(v) {
                    return (v === null || v === undefined)
                           ? ''
                           : String(v);
                });
            }
            return (parsed === null || parsed === undefined) ? '' : String(
                parsed);
        } catch (e) {
            return jsonStr;
        }
    }
    
    function evaluateVisibilityForRow($row) {
        let isConditional = $row.data('conditional') === 1 ||
            $row.data('conditional') === '1';
        if (!isConditional) {
            return; // always visible
        }
        let condMeta = $row.data('cond-meta') || '';
        let expectedRaw = $row.attr('data-cond-expected') || '';
        let operator = $row.data('cond-operator') || '==';
        
        let expected = parseExpected(expectedRaw);
        let $scope = $row.closest('form');
        let actual = getFieldValueByMeta(condMeta, $scope.length ? $scope : $(document));
        if (actual === null || actual === undefined) {
            actual = '';
        } else {
            actual = String(actual);
        }
        
        let ok = matchCondition(actual, expected, operator);
        $row.toggleClass('d-none', !ok);
    }
    
    function evaluateAll() {
        $('.meta-field-row').each(function() {
            evaluateVisibilityForRow($(this));
        });
    }
    
    $(document).on('shown.bs.modal', '#editPersonal, #addCustomer', evaluateAll);

    $(document).on('change input', '[data-for]', function() {
        evaluateAll();
    });
    $(document).on('select2:select select2:clear', '[data-for]', function() {
        evaluateAll();
    });
    
    $(document).on('click', '#update_user_personal_data', function(e) {
        let inputs = $('#editPersonal').find('input, select');
        let data = {
            action: 'kph_update_user_personal_data',
            id:     $('#current_user_id').val(),
            meta:   {},
            page:   $('#current_page').val(),
        };
        inputs.each(function() {
            let key = $(this).attr('data-for');
            let val = $(this).val();
            if ($(this).hasClass('price_input')) {
                val = sanitizeNumber(val);
            }
            data.meta[key] = val;
        });
        $.post(ajax_url, data, function(response) {
            change_panel_html(response);
            history.pushState({}, '', response.url);
        });
    });
    
    $(document).
        on('click', '[data-bs-target="#addCustomer_for_modal"]', function() {
            let modal = $(this).parents('.modal');
            let search = modal.find('.search_user_modal').val();
            let is_numeric = parseInt(search) == search;
            if (is_numeric) {
                $('#new_customer_phone_for_modal').val(search);
            } else {
                $('#new_customer_user_name_for_modal').val(search);
            }
            $('#modal_to_open').val($(modal).attr('id'));
        });
    $(document).on('click', '#register_new_user_for_modal', function() {
        let phone = $('#new_customer_phone_for_modal');
        let name = $('#new_customer_user_name_for_modal');
        let intro = $('#new_customer_intro_id_for_modal');
        if (!name.val() || !phone.val()) {
            NioApp.Toast('نام و شماره تلفن را وارد کنید', 'error',
                {position: 'top-right'});
            return;
        }
        let full_name = name.val();
        let first_name,
            last_name;
        first_name = full_name.substr(0, full_name.indexOf(' '));
        last_name = full_name.substr(full_name.indexOf(' ') + 1);
        if (!first_name || !last_name) {
            NioApp.Toast('نام و نام خانوادگی را به صورت کامل وارد کنید',
                'error',
                {position: 'top-right'});
            return;
        }
        if (!validate_phone_number(phone.val())) {
            NioApp.Toast('شماره تلفن همراه معتبر نیست', 'error',
                {position: 'top-right'});
            return;
        }
        
        let data = {
            action:     'kph_add_user',
            phone:      phone.val(),
            first_name: first_name,
            last_name:  last_name,
            intro:      intro.val(),
            target:     'modal',
        };
        $.post(ajax_url, data, function(response) {
            let modal_id = $('#modal_to_open').val();
            if (!modal_id) {
                $('.customer_box').html(response.html);
                $('.customer_search_result').html('');
                $('#new_order_customer_id').
                    val(response.user_id).
                    trigger('change');
            } else {
                let modal = $('#' + modal_id);
                modal.modal('show');
                let result = modal.find('.customer_search_result');
                result.html('');
                let input = result.attr('data-input').trigger('change');
                let preview = result.attr('data-preview');
                $('.search_user_modal').val('');
                $(input).val(response.user_id);
                $(preview).html(response.html);
            }
        });
    });
    $(document).on('hidden.bs.modal', '#addCustomer_for_modal', function(e) {
        let modal_id = $('#modal_to_open').val();
        if (!modal_id) {
            return;
        }
        let modal = $('#' + modal_id);
        modal.modal('show');
    });
    $(document).on('input', '.search_user_modal', function(e) {
        ajax_search = true;
        let result = $('.customer_search_result');
        if (this.value === '') {
            result.html('').hide();
            return;
        }
        if (typeof search_ajax === 'object') {
            search_ajax.abort();
        }
        result.show();
        let data = {
            action: 'kph_search_user_for_modal',
            search: this.value,
            role:   $(this).attr('data-role'),
        };
        search_ajax = $.post(ajax_url, data, function(response) {
            result.html(response.searchResult);
            ajax_search = false;
        });
    });
    $(document).on('click', '.select_current_user_for_modal', function() {
        let input = $(this).attr('data-input');
        $('.hide_on_profile').remove();
        $(input).val($(this).attr('data-id')).trigger('change');
    });
    $(document).on('click', '.each_user_search_result_row', function() {
        let search_result = $(this).parents('.customer_search_result');
        search_result.html('');
        let input = search_result.attr('data-input');
        let preview = search_result.attr('data-preview');
        $('.search_user_modal').val('');
        $(input).val($(this).attr('data-id')).trigger('change');
        $(preview).html(this.innerHTML);
    });
    
    function showRequiredError($field) {
        let $group = $field.closest('.form-group');
        let label = $group.find('.form-label');
        if (!label.length) {
            label = 'این فیلد';
        } else {
            label = label.get(0).innerText.trim();
        }
        NioApp.Toast(label + ' ضروری است', 'error',
            {position: 'top-right'});
    }
    
    function setNestedValue(obj, path, value) {
        let keys = path.replace(/\]/g, '').split('['); // meta[national_id] => ['meta','national_id']
        
        let ref = obj;
        keys.forEach(function(key, index) {
            if (index === keys.length - 1) {
                ref[key] = value;
            } else {
                if (!ref[key] || typeof ref[key] !== 'object') {
                    ref[key] = {};
                }
                ref = ref[key];
            }
        });
    }
    
    function getNestedValue(obj, path) {
        let keys = path.replace(/\]/g, '').split('[');
        let ref = obj;
        
        for (let i = 0; i < keys.length; i++) {
            if (ref == null || typeof ref !== 'object') {
                return undefined;
            }
            ref = ref[keys[i]];
        }
        return ref;
    }
    
    $(document).on('change', '.check_checkbox', function() {
        const $input = $(this);
        let row = $input.parents('.nk-tb-item');
        let checkbox = row.find('input[type="checkbox"]');
        let inputVal = parseFloat(toEnglishNumber($input.val()));
        if (inputVal > 0) {
            checkbox.attr('checked', true).change();
        } else {
            checkbox.attr('checked', false).change();
        }
    });
    $(document).on('change', '.validate_weight', function() {
        const $input = $(this);
        
        let targetSelector = $input.attr('data-target');
        if (!targetSelector) {
            return;
        }
        const $target = $(targetSelector);
        let inputVal = parseFloat(toEnglishNumber($input.val()));
        if (isNaN(inputVal)) {
            return;
        }
        let targetRaw = $target.is('input, textarea, select')
                        ? $target.val()
                        : $target.text();
        let targetVal = parseFloat(
            toEnglishNumber(String(targetRaw).trim()),
        );
        if (isNaN(targetVal)) {
            return;
        }
        if (inputVal > targetVal) {
            $input.val(targetVal);
        }
    });
    
    function isConditionalHidden($field) {
        let $conditionalParent = $field.closest('.conditional_show');
        
        return $conditionalParent.length && !$conditionalParent.is(':visible');
    }
    
    $(document).on('change', '.change_user_notif_meta', function() {
        let data = {
            action: 'kph_update_inline_meta',
            value:  $(this).is(':checked') ? $(this).val() : $(this).attr('data-not'),
            id:     $('#current_user_id').val(),
            key:    $(this).attr('data-for'),
            tab:    'profile',
        };
        ajax_search = true;
        $.post(ajax_url, data, function() {
            ajax_search = false;
        });
    });
    // Visitor search and target editor; delegated events also work after panel navigation.
    function visitorNormalize(value) {
        return String(value).replace(/[۰-۹]/g, c => String(c.charCodeAt(0) - 1776))
            .replace(/[٠-٩]/g, c => String(c.charCodeAt(0) - 1632))
            .replace(/ي/g, 'ی').replace(/ك/g, 'ک');
    }
    $(document).on('input', '#kv-visitor-search', function() {
        const query = visitorNormalize(this.value).trim().toLowerCase();
        let count = 0;
        $('[data-visitor-search]').each(function() {
            const match = visitorNormalize(this.dataset.visitorSearch).toLowerCase().includes(query);
            this.hidden = !match;
            if (match) count++;
        });
        $('#kv-search-count').text(count + ' ویزیتور');
        $('#kv-search-empty').prop('hidden', count > 0);
    });
    $(document).on('click', '#kv-clear-search', function() {
        $('#kv-visitor-search').val('').trigger('input').trigger('focus');
    });
    $(document).on('click', '.kv-open-target', function() {
        const editor = document.getElementById('visitor-target-editor');
        if (!editor) return;
        editor.open = true;
        editor.querySelector('input:not([type="hidden"])').focus();
    });
    $(document).on('click', '.kv-close-target', function() {
        const editor = document.getElementById('visitor-target-editor');
        editor.open = false;
        editor.querySelector('summary').focus();
    });
    $(document).on('blur', '.kv-money-input', function() {
        const raw = visitorNormalize(this.value).replace(/[,٬\s]/g, '');
        if (/^\d+$/.test(raw)) this.value = raw.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    });
    $(document).on('input change', '.kv-target-form input', function() {
        $(this).removeAttr('aria-invalid');
        document.getElementById(this.id + '-error')?.replaceChildren();
    });
    $(document).on('submit', '.kv-target-form', function(event) {
        event.preventDefault();
        const $form = $(this);
        if ($form.attr('aria-busy') === 'true') return;
        const data = {action: $form.data('action'), page: '/crm/employee'};
        const $status = $form.find('.kv-form-status');
        $status.text('');
        $form.find('.kv-field-error').text('');
        $form.find('[aria-invalid]').removeAttr('aria-invalid');
        let firstError = null;
        function invalid(field, message) {
            if (!firstError) firstError = field;
            field.setAttribute('aria-invalid', 'true');
            document.getElementById(field.id + '-error').textContent = message;
        }
        $form.find('input[data-for]').each(function() {
            const key = this.dataset.for;
            let value = this.value.trim();
            if (['date_from','date_to','amount','bonus'].includes(key)) value = visitorNormalize(value);
            if (key === 'amount' || key === 'bonus') value = value.replace(/[,٬\s]/g, '');
            if (key === 'date_from' || key === 'date_to') value = value.replace(/\//g, '-');
            data[key] = value;
            if (this.required && !value) invalid(this, 'این فیلد را تکمیل کنید.');
            else if (['amount','bonus'].includes(key) && (!/^\d+$/.test(value) || Number(value) <= 0 || Number(value) > 999999999999999)) invalid(this, 'مبلغ صحیح و بزرگ‌تر از صفر وارد کنید.');
            else if (['date_from','date_to'].includes(key) && !/^1[34]\d{2}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])$/.test(value)) invalid(this, 'تاریخ شمسی را مانند ۱۴۰۵-۰۷-۰۱ وارد کنید.');
        });
        if (!firstError && data.date_from > data.date_to) invalid($form.find('[data-for="date_to"]')[0], 'تاریخ پایان باید بعد از شروع یا برابر آن باشد.');
        if (firstError) { firstError.focus(); return; }
        const $button = $form.find('[type="submit"]');
        const label = $button.text();
        $form.attr('aria-busy', 'true');
        $button.prop('disabled', true).text('در حال ذخیره…');
        $.ajax({url: ajax_url, method: 'POST', data: data, dataType: 'json', global: false})
            .done(function(response) {
                if (response && response.status === 'success' && response.main) {
                    change_panel_html(response);
                    const url = '/crm/employee/' + encodeURIComponent(data.id) + '?tab=targets';
                    history.replaceState({}, '', url);
                    return;
                }
                $status.text(response?.message || 'ذخیره انجام نشد. اطلاعات را بررسی و دوباره تلاش کنید.').trigger('focus');
            })
            .fail(function() {
                $status.text('ارتباط با سرور برقرار نشد. اطلاعات فرم حفظ شده؛ دوباره تلاش کنید.').trigger('focus');
            })
            .always(function() {
                $form.removeAttr('aria-busy');
                $button.prop('disabled', false).text(label);
            });
    });

    $(document).on('click', '.submit_modal_form', function() {
        let $form = $(this).parents('.modal_form');
        if ($form.data('kphSubmitting')) return;
        let page = $form.attr('data-page') || '';
        
        let data = {
            action: $form.attr('data-action'),
            page:   page,
        };
        
        let hasError = false;
        let requiredMap = {}; // key => { fields: [] }
        
        let $inputs = $form.find('input[data-for], select[data-for], textarea[data-for]');
        
        // ----------------- inputs -----------------
        $inputs.each(function() {
            
            let $field = $(this);
            
            if (isConditionalHidden($field)) {
                return;
            }
            
            let key = $field.data('for');
            
            if (!key) {
                return;
            }
            
            if ($field.data('req') == 1) {
                if (!requiredMap[key]) {
                    requiredMap[key] = {fields: []};
                }
                requiredMap[key].fields.push($field);
            }
            
            // checkbox
            if ($field.is(':checkbox')) {
                
                if ($field.is(':checked')) {
                    let val = $field.val() || 1;
                    
                    if (key.includes('[')) {
                        let current = getNestedValue(data, key);
                        if (!Array.isArray(current)) {
                            setNestedValue(data, key, []);
                            current = getNestedValue(data, key);
                        }
                        current.push(val);
                    } else {
                        if (!Array.isArray(data[key])) {
                            data[key] = [];
                        }
                        data[key].push(val);
                    }
                }
                
                return;
            }
            
            // radio
            if ($field.is(':radio')) {
                
                if ($field.is(':checked')) {
                    let val = $field.val();
                    
                    if (key.includes('[')) {
                        setNestedValue(data, key, val);
                    } else {
                        data[key] = val;
                    }
                }
                
                return;
            }
            
            let val = $field.val();
            if (key == 'phone') {
                if (!validate_phone_number(val)) {
                    NioApp.Toast('شماره تلفن همراه معتبر نیست', 'error', {
                        position: 'top-right',
                    });
                    hasError = true;
                    return;
                }
            }
            if (key.includes('[')) {
                setNestedValue(data, key, val);
            } else {
                data[key] = val;
            }
            
        });
        
        Object.keys(requiredMap).forEach(function(key) {
            if (hasError) {
                return;
            }
            let value = key.includes('[')
                        ? getNestedValue(data, key)
                        : data[key];
            
            let isEmpty =
                    value === undefined ||
                    value === null ||
                    (Array.isArray(value) && value.length === 0) ||
                    (typeof value === 'string' && value.trim() === '');
            
            if (isEmpty) {
                let $firstField = requiredMap[key].fields[0];
                console.log($firstField);
                showRequiredError($firstField);
                hasError = true;
            }
        });
        
        // ----------------- quill editors -----------------
        let $quills = $form.find('.quill-basic[data-for]');
        
        $quills.each(function() {
            
            let $wrapper = $(this);
            
            if (isConditionalHidden($wrapper)) {
                return;
            }
            
            let key = $wrapper.data('for');
            
            if (!key) {
                return;
            }
            
            let quillInstance = $wrapper.data('quill');
            let html = '';
            
            if (quillInstance && quillInstance.root) {
                html = quillInstance.root.innerHTML;
            } else {
                html = $wrapper.find('.ql-editor').html() || '';
            }
            
            let textContent = $('<div>').html(html).text().trim();
            
            if ($wrapper.data('req') == 1 && textContent === '') {
                if (!hasError) {
                    showRequiredError($wrapper);
                }
                hasError = true;
            }
            
            if (key.includes('[')) {
                setNestedValue(data, key, html);
            } else {
                data[key] = html;
            }
        });
        
        if (hasError) {
            return;
        }
        
        $form.data('kphSubmitting', true);
        $.post(ajax_url, data, function(response) {
            if (data.action === 'kph_convert_packaging_lot_to_shop_product' && response.status !== 'success') {
                NioApp.Toast(response.message, response.status || 'error', {position: 'top-right'});
                return;
            }
            change_panel_html(response);
            if (response.url) history.pushState({}, '', response.url);
        }).fail(function() {
            NioApp.Toast('پاسخ ثبت دریافت نشد؛ قبل از تلاش مجدد، وضعیت را بررسی کنید.', 'error', {position: 'top-right'});
        }).always(function() { $form.data('kphSubmitting', false); });
    });
    $(document).on('change', '.load_city', function(e) {
        let target = $(this).attr('data-target');
        request_city_list($(this).val(), target, $(target).val());
    });
    
    function request_city_list(state_id, target, city_id = 0) {
        let city = $(target);
        let data = {
            'state_id': state_id,
            'city_id':  city_id,
            'action':   'kasebi_load_city_list',
        };
        $.post(ajax_url, data, function(response) {
            city.html(response.list);
            NioApp.Select2(target);
            if (city_id) {
                $(target).val(city_id).trigger('change');
            }
        });
    }
    
    function buildNeedsHtml(needFields, actionLabel) {
        if (!needFields || !needFields.length) {
            return `<div class="text-center py-2">آیا از اجرای «${actionLabel}» مطمئن هستید؟</div>`;
        }
        
        const blocks = needFields.map(f => {
            const id = `swal_need_${f.key || f.name || Math.random().toString(36).slice(2)}`;
            const label = f.label || '';
            const maxAttr = (f.max !== undefined && f.max !== null) ? ` data-max="${f.max}"` : '';
            const wrapStart = `
            <div class="form-group">
                <label class="form-label" for="${id}">${label}</label>
                <div class="form-control-wrap">
        `;
            const wrapEnd = `</div></div>`;
            
            if (f.type === 'select') {
                const opts = (Array.isArray(f.options) ? f.options : []).map(o => {
                    const v = (typeof o === 'object') ? (o.value ?? o.id ?? '') : o;
                    const t = (typeof o === 'object') ? (o.label ?? o.text ?? v) : o;
                    const selected = f.value != null && f.value == v ? ' selected' : '';
                    return `<option value="${String(v).replace(/"/g, '&quot;')}"${selected}>${t}</option>`;
                }).join('');
                
                return `${wrapStart}
                <select id="${id}" class="form-select" data-key="${f.key}"${maxAttr}>
                    ${opts}
                </select>
            ${wrapEnd}`;
            }
            
            if (f.type === 'textarea') {
                const val = f.value ?? '';
                return `${wrapStart}
                <textarea id="${id}" class="form-control" data-key="${f.key}"${maxAttr}>${String(val).
                    replace(/"/g, '&quot;')}</textarea>
            ${wrapEnd}`;
            }
            
            let extraClass = (f.type === 'date') ? ' datepicker ' : ' ';
            const val = f.value ?? '';
            extraClass += f.class;
            return `${wrapStart}
            <input
                type="text"
                id="${id}"
                class="form-control${extraClass}"
                data-key="${f.key}"
                value="${String(val).replace(/"/g, '&quot;')}"
                ${maxAttr}
            >
        ${wrapEnd}`;
        });
        
        return blocks.join('');
    }
    
    function collectNeedsValues(needFields) {
        const vals = {};
        (needFields || []).forEach(f => {
            if (f.type === 'modal') {
                return;
            }
            const $inp = $(`.swal2-container [data-key="${f.key}"]`);
            if ($inp.length) {
                vals[f.key] = $inp.val();
            }
        });
        return vals;
    }
    
    $(document).on('click', '.open_options_modal', function(e) {
        let optionKey = $(this).attr('data-option-key');
        $('#options_tab').val($(this).attr('data-tab'));
        $('#options_key').val(optionKey);
        $('#cost_secondary_category_field').toggleClass('d-none', optionKey !== 'kph_cost_category');
        $('#method_secondary_category').val('');
    });
    $(document).on('click', '.delete_db_item', function(e) {
        e.preventDefault();
        let datas = this.dataset;
        let data = {};
        Object.entries(datas).forEach(([selector, value]) => {
            data[selector] = value;
        });
        Swal.fire({
            title:             'آیا از حذف این مورد اطمینان دارید؟',
            icon:              'warning',
            text:              'این عملیات غیر قابل بازگشت است',
            focusConfirm:      false,
            showCancelButton:  true,
            confirmButtonText: 'بله',
            cancelButtonText:  `خیر`,
        }).then((result) => {
            if (result.isConfirmed) {
                $.post(ajax_url, data, function(response) {
                    change_panel_html(response);
                    history.pushState({}, '', response.url);
                });
            }
        });
    });
    $(document).on('click', '.edit_item', function(e) {
        e.preventDefault();
        
        const $btn = $(this);
        const data = ($btn.data('data') || $btn.data()) || {};
        
        let modalName = data.modal || $btn.data('modal');
        if (!modalName) { return; }
        
        const modalSelector = (String(modalName).startsWith('#')
                               ? modalName
                               : ('#' + modalName));
        const $modal = $(modalSelector);
        
        $modal.find('[data-for]').each(function() {
            const $field = $(this);
            const key = $field.data('for');
            if (!key || typeof data[key] === 'undefined') { return; }
            const val = data[key];
            if ($field.is('select')) {
                $field.val(val);
                if ($field.hasClass('select2') || $field.data('select2')) {
                    $field.trigger('change.select2');
                } else {
                    $field.trigger('change');
                }
            } else if ($field.is(':checkbox')) {
                $field.prop('checked', !!val);
            } else if ($field.is(':radio')) {
                $modal.find(
                        'input[type="radio"][data-for="' + key + '"][value="' +
                        val + '"]').
                    prop('checked', true).
                    trigger('change');
            } else {
                $field.val(val).trigger('input');
            }
        });

		if ( modalName === 'addNewOptionItem' ) {
			let optionKey = data.option || '';
			$('#cost_secondary_category_field').toggleClass('d-none', optionKey !== 'kph_cost_category');
			$('#method_secondary_category').val(data.secondary_category || '').trigger('change');
		}
        
        $modal.modal('show');
    });
    $(document).on('hidden.bs.modal', '.modal', function() {
        return;
        const $modal = $(this);
        let modal_form = $modal.find('.modal_form');
        if (modal_form.length < 1) {
        }
        $modal.find('[data-for]').each(function() {
            const $field = $(this);
            if ($field.is('select')) {
                $field.prop('selectedIndex', 0).val('');
                if ($field.hasClass('select2') || $field.data('select2')) {
                    $field.trigger('change.select2');
                } else {
                    $field.trigger('change');
                }
            } else if ($field.is(':checkbox,:radio')) {
                $field.prop('checked', false).trigger('change');
            } else {
                $field.val('').trigger('input');
            }
        });
    });
    
    $(document).on('click', '.each_user_search_result_row', function() {
        if ($(this).attr('data-group') == 1) {
            $('.hide_on_normal').show();
            $('.lower_colspan').attr('colspan', 5);
        } else {
            $('.hide_on_normal').hide();
            $('.lower_colspan').attr('colspan', 2);
        }
        $('#search_sku_for_supplier_invoice').
            attr('data-group', $(this).attr('data-group'));
        $('#new_order_customer_group').val($(this).attr('data-group'));
        // let card = $('.order_factor_card .products_payment');
        // card.find('tbody').html('');
        $('.product_search_result').html('');
        $('.product_search_list').html('');
    });
    
    $(document).on('input', '#search_sku_for_supplier_invoice', function(e) {
        if (this.value === '') {
            $('.product_search_result').html('');
            return;
        }
        ajax_search = true;
        let data = {
            action: 'kph_search_supplier_invoice_product',
            search: this.value,
            group:  $(this).attr('data-group'),
        };
        $.post(ajax_url, data, function(response) {
            ajax_search = false;
            if (response.status == 'success') {
                $('.product_search_result').html(response.html);
                NioApp.NumberSpinner();
            } else if (response.status == 'list') {
                $('.product_search_list').html(response.html);
            } else {
                NioApp.Toast(response.message, response.status,
                    {position: 'top-right'});
                $('#search_sku_for_supplier_invoice').val('');
                $('.product_search_result').html('');
                $('.product_search_list').html('');
            }
        });
    });
    
    function calc_invoice_total() {
        if ($('#new_order_customer_group').length > 0) {
            calc_supplier_invoice_total();
        } else {
            calc_customer_invoice_total();
        }
    }
    
    function calc_supplier_invoice_total() {
        let group = $('#new_order_customer_group').val();
        if (group == 1) {
            $('.hide_on_normal').show();
            $('.lower_colspan').attr('colspan', 5);
        } else {
            $('.hide_on_normal').hide();
            $('.lower_colspan').attr('colspan', 2);
        }
        
        let card        = $('.order_factor_card'),
            tbody       = card.find('tbody'),
            items       = tbody.find('tr'),
            subtotal    = 0,
            payment_fee = 0;
        if (card.length < 1) {
            return;
        }
        items.each(function() {
            let qty = $(this).find('.line_qty').val();
            let month_rate = $(this).find('.item_month_rate').val();
            let month_count = $(this).find('.item_month_count').val();
            qty = parseFloat(toEnglishNumber(qty));
            month_count = sanitizeNumber(month_count);
            month_rate = parseFloat(sanitizeNumber(toEnglishNumber(month_rate)));
            
            let reg_price = sanitizeNumber(
                $(this).find('.item_reg_total').val());
            if (month_rate < 100) {
                month_rate = reg_price * month_rate / 100;
            }
            let final_price = (month_count * month_rate) + reg_price;
            
            let line_subtotal = final_price * qty;
            $(this).find('.price_per_unit').text(number_format(final_price));
            $(this).find('.line_subtotal').text(number_format(line_subtotal));
            
            subtotal += reg_price * qty;
            payment_fee += (month_count * month_rate) * qty;
        });
        
        card.find('.order_subtotal').text(number_format(subtotal));
        
        $('.cart_total_payment_fee').text(number_format(payment_fee));
        card.find('.order_total_final').
            text(number_format(subtotal + payment_fee));
        
        if (payment_fee > 0) {
            $('.payment_fee').show();
        } else {
            $('.payment_fee').hide();
        }
    }
    
    $(document).on('input', '.order_factor_card input', function() {
        calc_invoice_total(this);
    });
    $(document).on('click', '.delete_factor_row', function() {
        const row = $(this).closest('tr');
        const table = row.closest('.products_payment');
        const id = Number(row.attr('data-id'));
        // Only persisted supplier rows need a deletion instruction.
        if (id > 0 && table.closest('.order_factor_card').find('.submit_supplier_order[data-id]').length) {
            const removed = table.data('kphDeletedItems') || [];
            if (!removed.includes(id)) removed.push(id);
            table.data('kphDeletedItems', removed);
        }
        row.remove();
        calc_invoice_total();
    });
    $(document).on('click', '.each_supp_product_search_row', function() {
        let card = $('.order_factor_card .products_payment');
        let tbody = card.find('tbody');
        let product_id = $(this).attr('data-id');
        let code = $(this).attr('data-code');
        let title = $(this).attr('data-title');
        let qty_html = `<input class="line_qty form-control" value=""></td>`;
        let existing_row = tbody.find(`tr[data-product="${product_id}"]`);
        if (existing_row.length) {
            NioApp.Toast('این آیتم پیشتر به فاکتور اضافه شده است.', 'error',
                {position: 'top-right'});
        } else {
            let html = `<tr data-product="${product_id}">
                        <td>${code}</td>
                        <td>${title}</td>
                        <td>${qty_html}</td>
                        <td class="line_reg_price">
                            <input class="price_input item_reg_total form-control" value=""></td>
                        <td class="hide_on_normal"><input class="item_month_rate price_input form-control" value="0"></td>
                        <td class="hide_on_normal"><input class="price_input item_month_count form-control" value="0"></td>
                        <td class="hide_on_normal"><span class="price_per_unit">0</span></td>
                        <td class="tb-col-action">
                            <span class="line_subtotal">0</span>
                            <a class="link-cross me-sm-n1 delete_factor_row"><em class="icon ni ni-cross"></em></a>
                        </td>
                    </tr>`;
            tbody.append(html);
        }
        
        calc_invoice_total();
    });
    $(document).on('click', '.submit_supplier_order', function() {
        let attachments = $('#new_order_attachment').val();
        let factor_date = $('#new_factor_date').val();
        let factor_number = $('#new_factor_number').val();
        let customer_id = $('#new_order_customer_id').val();
        if (!factor_date) {
            NioApp.Toast('تاریخ فاکتور انتخاب نشده است', 'error',
                {position: 'top-right'});
            return;
        }
        if (Number(customer_id) <= 0) {
            NioApp.Toast('کاربری انتخاب نشده است', 'error',
                {position: 'top-right'});
            return;
        }
        const card = $(this).closest('.order_factor_card');
        const removedItems = card.find('.products_payment').data('kphDeletedItems') || [];
        let items = card.find('.products_payment tbody tr');
        if (items.length === 0 && !( $(this).attr('data-id') && removedItems.length )) {
            NioApp.Toast('محصولی انتخاب نشده است', 'error',
                {position: 'top-right'});
            return;
        }
        let products = [];
        items.each(function() {
            let product_id = $(this).attr('data-product');
            let item_id = $(this).attr('data-id');
            if (!product_id) {
                return;
            }
            let line_per_unit_base = sanitizeNumber($(this).find('.item_reg_total').val()),
                line_per_unit      = sanitizeNumber($(this).find('.price_per_unit').text()),
                line_total         = sanitizeNumber($(this).find('.line_subtotal').text()),
                qty                = $(this).find('.line_qty').val(),
                month_rate         = $(this).find('.item_month_rate').val(),
                month_count        = $(this).find('.item_month_count').val();
            qty = parseFloat(toEnglishNumber(qty));
            month_count = sanitizeNumber(month_count);
            month_rate = parseFloat(toEnglishNumber(month_rate));
            let product_data = {
                product_id:    product_id,
                item_id:       item_id,
                qty:           qty,
                per_unit_base: line_per_unit_base,
                per_unit:      line_per_unit,
                line_total:    line_total,
                meta:          {
                    month: month_count,
                    rate:  month_rate,
                },
            };
            products.push(product_data);
        });
        let data = {
            action:        'kph_submit_new_supplier_order',
            products:      products,
            attachments:   attachments,
            customer_id:   customer_id,
            factor_number: factor_number,
            factor_date:   factor_date,
            note:          $('#order_description').val(),
        };
        let invoice_id = $(this).attr('data-id');
        if (invoice_id) {
            data.invoice_id = invoice_id;
            data.delete_items = removedItems;
            data.edit_nonce = $(this).attr('data-nonce');
        }
        const submitButton = $(this);
        if (submitButton.prop('disabled')) return;
        submitButton.prop('disabled', true);
        $.post(ajax_url, data, function(response) {
            change_panel_html(response);
            if (response.url) history.pushState({}, '', response.url);
        }).fail(function() {
            NioApp.Toast('ذخیره انجام نشد؛ وضعیت فاکتور را بررسی و دوباره تلاش کنید.', 'error', {position: 'top-right'});
        }).always(function() { submitButton.prop('disabled', false); });
    });
    calc_invoice_total();
    
    $(document).on('input', '#search_sku_for_customer_invoice', function(e) {
        if (this.value === '') {
            $('.product_search_result').html('');
            return;
        }
        ajax_search = true;
        let data = {
            action: 'kph_search_customer_invoice_product',
            search: this.value,
        };
        $.post(ajax_url, data, function(response) {
            ajax_search = false;
            if (response.status == 'success') {
                $('.product_search_result').html(response.html);
                NioApp.NumberSpinner();
            } else if (response.status == 'list') {
                $('.product_search_list').html(response.html);
            } else {
                NioApp.Toast(response.message, response.status,
                    {position: 'top-right'});
                $('#search_sku_for_customer_invoice').val('');
                $('.product_search_result').html('');
                $('.product_search_list').html('');
            }
        });
    });
    $(document).on('click', '.each_customer_product_search_row', function() {
        let card = $('.order_factor_card .products_payment');
        let tbody = card.find('tbody');
        let product_id = $(this).attr('data-id');
        let code = $(this).attr('data-code');
        let title = $(this).attr('data-title');
        let price = $(this).attr('data-price');
        price = number_format(price);
        let qty_html = `<input class="line_qty form-control" value=""></td>`;
        let existing_row = tbody.find(`tr[data-product="${product_id}"]`);
        if (existing_row.length) {
            NioApp.Toast('این آیتم پیشتر به فاکتور اضافه شده است.', 'error',
                {position: 'top-right'});
            return;
        }
        let html = `<tr data-product="${product_id}">
                        <td>
                            <div class="user-info">
                                <span class="tb-lead">${title}</span>
                                <span class="sub-text">${code}</span>
                            </div>
                        </td>
                        <td class="line_reg_price">
                            <input class="price_input item_reg_total form-control" value="${price}">
                        </td>
                        <td>${qty_html}</td>
                        <td>
                            <input class="line_off_percent form-control" value="">
                        </td>
                        <td class="line_off_goods">
                            <div class="off_goods_desc">-</div>
                            <div class="off_goods_qty fs-13px"></div>
                            <input class="line_buy_x" type="hidden">
                            <input class="line_get_y" type="hidden">
                        </td>
                        <td class="tb-col-action">
                            <div>
                                <span class="tb-lead line_subtotal fw-bold fs-18px">0</span>
                                <span class="sub-text line_per_item">${price}</span>
                            </div>
                            <input type="hidden" class="line_note">
                            <div class="d-flex justify-end" style="gap: 5px">
                                <a class="link-cross me-sm-n1 set_line_note"
                                    data-bs-toggle="popover" data-bs-trigger="hover"
                                    title="یادداشت"
                                    data-bs-content=""
                                    data-bs-placement="top"><em class="icon ni ni-note-add-c"></em></a>
                                <a class="link-done me-sm-n1 set_good_offer"><em class="icon ni ni-percent"></em></a>
                                <a class="link-cross me-sm-n1 delete_factor_row"><em class="icon ni ni-cross"></em></a>
                            </div>
                        </td>
                    </tr>`;
        tbody.append(html);
        NioApp.BS.popover('.set_line_note');
        
        calc_invoice_total();
    });
    $(document).on('click', '.set_good_offer', function() {
        let row = $(this).parents('tr');
        let modal = Swal.mixin({
            title:             'تنظیم تخفیف کالایی',
            html:              `<div class="form-group">
                                    <label class="form-label" for="swal_line_buy_x">تعداد پایه</label>
                                    <div class="form-control-wrap">
                                        <input id="swal_line_buy_x" class="form-control" type="text">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="form-label" for="swal_line_get_y">تعداد هدیه</label>
                                    <div class="form-control-wrap">
                                        <input id="swal_line_get_y" class="form-control" type="text">
                                    </div>
                                </div>
                                <div class="kph-hint">
                                مثال: اگر 100 عدد سفارش شود و قانون «هر 40 عدد، 1 عدد رایگان» باشد ⇒ 2 عدد رایگان
                                </div>`,
            focusConfirm:      false,
            confirmButtonText: 'ثبت تخفیف',
        });
        modal.fire().then(function(result) {
            let x = $('#swal_line_buy_x').val();
            let y = $('#swal_line_get_y').val();
            if (!x) {
                row.find('.off_goods_desc').text(`-`);
            } else {
                row.find('.off_goods_desc').text(`هر ${x} عدد، ${y} رایگان`);
            }
            row.find('.line_buy_x').val(x);
            row.find('.line_get_y').val(y);
            calc_invoice_total();
        });
    });
    $(document).on('click', '.set_line_note', function() {
        let $this = $(this);
        let row = $(this).parents('tr');
        
        let modal = Swal.mixin({
            title:             'یادداشت ردیف',
            html:              `<div class="form-group">
                                    <label class="form-label" for="swal_line_note">توضیح خود برای این محصول را وارد کنید</label>
                                    <div class="form-control-wrap">
                                        <textarea id="swal_line_note" class="form-control"></textarea>
                                    </div>
                                </div>`,
            focusConfirm:      false,
            confirmButtonText: 'ثبت یادداشت',
        });
        modal.fire().then(function(result) {
            let note = $('#swal_line_note').val();
            row.find('.line_note').val(note);
            $this.attr('data-bs-content', note);
            NioApp.BS.popover('.set_line_note');
            calc_invoice_total();
        });
    });
    $(document).on('click', '#open_addUserAddress', function(e) {
        e.preventDefault();
        let user_id = $('#new_order_customer_id').val();
        if (!user_id) {
            user_id = $(this).attr('data-id');
            if (!user_id) {
                NioApp.Toast('پیش از ثبت آدرس مشتری را انتخاب کنید.', 'error', {position: 'top-right'});
                return;
            }
        }
        $('#save_address_user_id').val(user_id);
        $('#addUserAddress').modal('show');
    });
    $(document).on('click', '.address_for_main_customer', function() {
        if (!$('#address_for_main_customer').is(':checked')) {
            $('#address_first_name').val('');
            $('#address_last_name').val('');
            $('#address_phone').val('');
        } else {
            $('#address_first_name').val($('#customer_first_name_default').val());
            $('#address_last_name').val($('#customer_last_name_default').val());
            $('#address_phone').val($('#customer_phone_num_default').val());
        }
    });
    $(document).on('change', '#new_order_customer_id', function(e) {
        let user_id = $(this).val();
        if (!user_id) {
            return;
        }
        let $this = $(this);
        if ($(this).attr('data-check')) {
            let data = {
                action:      'kph_check_customer_proforma',
                customer_id: user_id,
            };
            $.post(ajax_url, data, function(response) {
                let page = $this.attr('data-page');
                if (response.order_id > 0) {
                    show_loading_modal();
                    window.location.href = '/crm/order-customer-edit/?order-id=' + response.order_id;
                }
                if (response.order_id < 0 && page == 'order-edit') {
                    show_loading_modal();
                    window.location.href = '/crm/order-customer/?c_id=' + user_id;
                }
            });
        }
        
        let data = {
            action:  'kph_load_user_address',
            user_id: user_id,
        };
        $.post(ajax_url, data, function(response) {
            $('.address_wrapper').html(response.html);
            NioApp.Control('.custom-control-input');
        });
    });
    let request_city = true;
    
    $(document).on('click', '#save_address_form', function(e) {
        let first_name = $('#address_first_name').val(),
            last_name  = $('#address_last_name').val(),
            phone      = $('#address_phone').val(),
            postcode   = $('#address_postcode').val(),
            state      = $('#address_state').val(),
            city       = $('#address_city').val(),
            region     = $('#address_region').val(),
            section    = $('#address_section').val(),
            address    = $('#address_address').val();
        
        let data = {
            action:     'kph_save_user_address',
            address_id: $('#save_address_key').val(),
            user_id:    $('#save_address_user_id').val(),
            address:    {
                first_name: first_name,
                last_name:  last_name,
                phone:      phone,
                postcode:   postcode,
                state:      state,
                city:       city,
                region:     region,
                section:    section,
                address_1:  address,
            },
        };
        $.post(ajax_url, data, function(response) {
            $('.address_wrapper').html(response.html);
            NioApp.Control('.custom-control-input');
            
            $('#addUserAddress input').each(function() {
                $(this).val('');
            });
        });
    });
    $(document).on('click', '.edit_customer_address', function() {
        $('#save_address_key').val($(this).attr('data-key'));
        $('#address_first_name').val($(this).attr('data-first_name'));
        $('#address_last_name').val($(this).attr('data-last_name'));
        $('#address_phone').val($(this).attr('data-phone'));
        $('#address_postcode').val($(this).attr('data-postcode'));
        $('#address_region').val($(this).attr('data-region'));
        let state = $(this).attr('data-state');
        let city = $(this).attr('data-city');
        request_city = false;
        $('#address_state').val(state).change();
        request_city_list(state, city);
        $('#address_address').val($(this).attr('data-address_1'));
        let user_id = $('#new_order_customer_id').val();
        if (!user_id) {
            user_id = $('#current_user_id').val();
        }
        $('#save_address_user_id').val(user_id);
    });
    $(document).on('click', '.delete_customer_address', function() {
        let user_id = $('#new_order_customer_id').val();
        if (!user_id) {
            user_id = $('#current_user_id').val();
        }
        let data = {
            action:     'kph_delete_customer_address',
            address_id: $(this).attr('data-key'),
            user_id:    user_id,
        };
        Swal.fire({
            title:             'حذف آدرس',
            icon:              'warning',
            text:              'از حذف آدرس مطمئن هستید؟ این عمل غیر قابل بازگشت است.',
            focusConfirm:      false,
            showCancelButton:  true,
            confirmButtonText: 'بله',
            cancelButtonText:  `خیر`,
        }).then(function(result) {
            if (result.isConfirmed) {
                $.post(ajax_url, data, function(response) {
                    $('.address_wrapper').html(response.html);
                    NioApp.Control('.custom-control-input');
                });
            }
        });
    });
    
    function calc_customer_invoice_total() {
        let card          = $('.order_factor_card'),
            tbody         = card.find('tbody'),
            items         = tbody.find('tr'),
            subtotal      = 0,
            total_off     = 0,
            order_total   = 0,
            off_goods_qty = 0;
        if (card.length < 1) {
            return;
        }
        items.each(function() {
            let $row = $(this);
            
            let qty = parseFloat(toEnglishNumber($row.find('.line_qty').val())) || 0;
            let reg_price = sanitizeNumber($row.find('.item_reg_total').val()) || 0;
            let x = parseInt(toEnglishNumber($row.find('.line_buy_x').val())) || 0;
            let y = parseInt(toEnglishNumber($row.find('.line_get_y').val())) || 0;
            let off = parseFloat(toEnglishNumber($row.find('.line_off_percent').val())) || 0;
            
            if (qty <= 0 || reg_price <= 0) {
                $row.find('.line_subtotal').text('0');
                $row.find('.line_per_item').text('0');
                return;
            }
            
            /* ===============================
             * 1) تخفیف کالایی → فقط تعداد
             * =============================== */
            let free_qty = 0;
            if (x > 0 && y > 0) {
                free_qty = Math.floor(qty / x) * y;
            }
            let received_qty = qty + free_qty;
            /* ===============================
             * 2) قیمت پایه خرید
             * =============================== */
            let line_base_total = reg_price * qty;
            
            /* ===============================
             * 3) تخفیف درصدی (ریالی)
             * =============================== */
            let percent_discount_amount = line_base_total * off / 100;
            
            /* ===============================
             * 4) مبلغ پرداختی واقعی
             * =============================== */
            let paid_total = line_base_total - percent_discount_amount;
            
            /* ===============================
             * 5) subtotal مجازی
             * اگر کل دریافتی با قیمت اصلی خریده می‌شد
             * =============================== */
            let line_virtual_subtotal = reg_price * received_qty;
            
            /* ===============================
             * 6) ارزش ریالی تخفیف کالایی
             * =============================== */
            let free_amount = free_qty * reg_price;
            
            /* ===============================
             * 7) مجموع تخفیف‌ها
             * =============================== */
            let line_total_off = percent_discount_amount + free_amount;
            
            /* ===============================
             * 8) قیمت تمام‌شده هر واحد
             * =============================== */
            let per_unit = paid_total / Math.max(1, received_qty);
            
            /* ===============================
             * 9) جمع کل‌ها
             * =============================== */
            subtotal += line_virtual_subtotal;
            total_off += line_total_off;
            order_total += paid_total;
            
            /* ===============================
             * 10) خروجی در UI
             * =============================== */
            $row.find('.line_subtotal').text(number_format(paid_total));
            $row.find('.line_per_item').text(number_format(Math.round(per_unit)));
            $row.find('.off_goods_qty').text(number_format(free_qty) + ' عدد هدیه');
        });
        
        card.find('.order_subtotal').text(number_format(subtotal));
        card.find('.order_total_off').text(number_format(total_off));
        card.find('.order_total_final').text(number_format(order_total));
    }
    
    $(document).on('click', '.submit_customer_order', function() {
        let customer_id = $('#new_order_customer_id').val();
        if (Number(customer_id) <= 0) {
            NioApp.Toast('کاربری انتخاب نشده است', 'error', {position: 'top-right'});
            return;
        }
        let address_id = $('.select_new_order_address.checked');
        if (address_id.length === 0) {
            NioApp.Toast('آدرس انتخاب نشده است', 'error', {position: 'top-right'});
            return;
        }
        address_id = address_id.attr('data-key');
        let items = $('.products_payment tr');
        if (items.length === 0) {
            NioApp.Toast('محصولی انتخاب نشده است', 'error', {position: 'top-right'});
            return;
        }
        let products = [];
        items.each(function() {
            let wc_product_id = $(this).attr('data-product');
            if (!wc_product_id) {
                return;
            }
            let $row = $(this);
            
            let qty = parseFloat(toEnglishNumber($row.find('.line_qty').val())) || 0;
            let base_price = sanitizeNumber($row.find('.item_reg_total').val()) || 0;
            let x = parseInt(toEnglishNumber($row.find('.line_buy_x').val())) || 0;
            let y = parseInt(toEnglishNumber($row.find('.line_get_y').val())) || 0;
            let off = parseFloat(toEnglishNumber($row.find('.line_off_percent').val())) || 0;
            
            let product_data = {
                wc_product_id:       wc_product_id,
                base_price:          base_price,
                qty_ordered:         qty,
                discount_cash_type:  'percent',
                discount_cash_value: off,
                goods_buy_x:         x,
                goods_free_y:        y,
                note:                $row.find('.line_note').val(),
            };
            products.push(product_data);
        });
        if (products.length === 0) {
            NioApp.Toast('محصولی انتخاب نشده است', 'error', {position: 'top-right'});
            return;
        }
        let order_id = $(this).attr('data-id');
        let attachments = $('#new_order_attachment').val();
        let data = {
            action:      'kph_submit_customer_order',
            order_id:    order_id,
            customer_id: customer_id,
            id:          customer_id,
            items:       products,
            tab:         'orders',
            note:        $('#order_description').val(),
            meta:        {
                address_id:    address_id,
                attachments:   attachments,
                factor_date:   $('#new_factor_date').val(),
                factor_number: $('#new_factor_number').val(),
                payment_term_days: $('#new_payment_term_days').val(),
            },
        };
        if (!$('#new_payment_term_days').length) delete data.meta.payment_term_days;
        const termDays = data.meta.payment_term_days;
        if (termDays && (!/^\d{1,4}$/.test(termDays) || Number(termDays) > 3650)) {
            NioApp.Toast('مهلت تسویه باید عدد صحیح بین صفر تا ۳۶۵۰ روز باشد.', 'error', {position: 'top-right'});
            return;
        }
        $.post(ajax_url, data, function(response) {
            change_panel_html(response);
            history.pushState({}, '', response.url);
        });
    });
    
    $(document).on('submit', '.term-editor', function(e) {
        e.preventDefault();
        const form = $(this), button = form.find('button');
        if (button.prop('disabled')) return;
        button.prop('disabled', true);
        $.post(ajax_url, {
            action: 'kph_save_customer_payment_term',
            order_id: form.attr('data-order-id'),
            nonce: form.attr('data-nonce'),
            payment_term_days: form.find('[name="payment_term_days"]').val()
        }).done(function(response) {
            if (response.status === 'success') { window.location.reload(); }
            else { NioApp.Toast(response.message || 'ذخیره مهلت انجام نشد.', 'error', {position: 'top-right'}); }
        }).fail(function() {
            NioApp.Toast('ذخیره مهلت انجام نشد؛ اتصال یا دسترسی را بررسی کنید.', 'error', {position: 'top-right'});
        }).always(function() { button.prop('disabled', false); });
    });

    $(document).on('click', '.load_invoice_items_table', function(e) {
        e.preventDefault();
        let invoice_id = $(this).attr('data-invoice-id');
        let data = {
            action:     'kph_load_invoice_items_table',
            invoice_id: invoice_id,
        };
        $.post(ajax_url, data, function(response) {
            $('#invoiceItemsTable').modal('show');
            $('#invoiceItemsTable .modal-body').html(response.html);
        });
    });
    $(document).on('click', '.change_invoice_status', function(e) {
        e.preventDefault();
        let invoice_id = $(this).attr('data-invoice-id');
        let status = $(this).attr('data-status');
        let data = {
            action:     'kph_change_invoice_status',
            invoice_id: invoice_id,
            status:     status,
            tab:        'invoice',
            id:         $(this).attr('data-user-id'),
        };
        let modal = Swal.mixin({
            title:             'یادداشت تغییر وضعیت',
            html:              `<div class="form-group">
                                    <label class="form-label" for="swal_line_note">توضیحات را وارد کنید</label>
                                    <div class="form-control-wrap">
                                        <textarea id="swal_line_note" class="form-control"></textarea>
                                    </div>
                                </div>`,
            focusConfirm:      false,
            showCancelButton:  true,
            confirmButtonText: 'تغییر وضعیت',
            cancelButtonText:  `لغو`,
        });
        modal.fire().then(function(result) {
            if (result.isConfirmed) {
                let note = $('#swal_line_note').val();
                data.note = note;
                $.post(ajax_url, data, function(response) {
                    change_panel_html(response);
                });
            }
        });
        
    });
    $(document).on('click', '.change_order_status', function(e) {
        e.preventDefault();
        let order_id = $(this).attr('data-order-id');
        let status = $(this).attr('data-status');
        let data = {
            action:   'kph_change_order_status',
            order_id: order_id,
            status:   status,
            tab:      'orders',
            id:       $(this).attr('data-user-id'),
        };
        $.post(ajax_url, data, function(response) {
            change_panel_html(response);
        });
    });
    $(document).on('click', '.populate_modal_inputs', function(e) {
        e.preventDefault();
        $('.hide_on_profile').remove();
        const modal = $(this).attr('data-modal');
        const raw = $(this).attr('data-set');
        $(modal).modal('show');
        if (!raw) {
            return;
        }
        let map;
        try { map = JSON.parse(raw); } catch (err) { return; }
        Object.entries(map).forEach(([selector, value]) => {
            const $el = $(selector);
            if (!$el.length) {
                return;
            }
            $el.val(value).trigger('input').trigger('change');
        });
    });
    
    $(document).on('click', '.load_cheque_moves_table', function(e) {
        e.preventDefault();
        let cheque_id = $(this).attr('data-cheque-id');
        let data = {
            action:    'kph_load_cheque_moves_table',
            cheque_id: cheque_id,
        };
        $.post(ajax_url, data, function(response) {
            $('#chequeMovesTable').modal('show');
            $('#chequeMovesTable .modal-body').html(response.html);
        });
    });
    
    $(document).on('click', '.change_cheque_status', function(e) {
        e.preventDefault();
        const $a = $(this);
        const cheque_id = $a.attr('data-cheque-id');
        const status = $a.attr('data-status');
        const label = $.trim($a.text()) || $a.attr('title') || 'تایید عملیات';
        
        let needs = $a.attr('data-needs');
        try { needs = (needs && needs !== 'null') ? JSON.parse(needs) : null; } catch (e2) { needs = null; }
        const needFields = needs
                           ? (Array.isArray(needs) ? needs : (Array.isArray(needs.needs) ? needs.needs : null))
                           : null;
        
        const data = get_current_page_filters();
        data.action = 'kph_change_cheque_status';
        data.page = $('#current_page').val();
        data.cheque_id = cheque_id;
        data.status = status;
        
        Swal.fire({
            title:             label,
            icon:              'warning',
            html:              buildNeedsHtml(needFields, label),
            showCancelButton:  true,
            confirmButtonText: 'بله',
            cancelButtonText:  'خیر',
        }).then((result) => {
            if (!result.isConfirmed) {
                return;
            }
            Object.assign(data, collectNeedsValues(needFields));
            $.post(ajax_url, data, function(response) {
                change_panel_html(response);
            });
        });
    });
    $('.modal').on('shown.bs.modal', function() {
        const inst = bootstrap.Modal.getInstance(this);
        if (inst) {
            inst._focustrap.deactivate();
        }
    });
    $(document).on('click', '.row_inline_action', function(e) {
        e.preventDefault();
        const $a = $(this);
        
        let needs = $a.attr('data-needs');
        const needFields = JSON.parse(needs);
        let datas = this.dataset;
        
        let data = {
            action:  $a.attr('data-action'),
            item_id: $a.attr('data-item-id'),
            page:    $('#current_page').val(),
        };
        Object.entries(datas).forEach(([selector, value]) => {
            if (selector == 'action' || selector == 'itemId' ||
                selector == 'swalTitle' || selector == 'page' ||
                selector == 'needs') {
                return;
            }
            data[selector] = value;
        });
        Swal.fire({
            title:             $a.attr('data-swal-title'),
            icon:              'warning',
            html:              buildNeedsHtml(needFields, 'فرآیند'),
            showCancelButton:  true,
            confirmButtonText: 'بله',
            cancelButtonText:  'خیر',
            onRender:          () => {
                $(Swal.getHtmlContainer()).on('input change', '[data-max]', function() {
                    const $el = $(this);
                    const max = parseFloat($el.data('max'));
                    if (isNaN(max)) {
                        return;
                    }
                    
                    let val = parseFloat($el.val());
                    if (isNaN(val)) {
                        return;
                    }
                    
                    if (val > max) {
                        $el.val(max);
                    }
                });
            },
            
        }).then((result) => {
            if (!result.isConfirmed) {
                return;
            }
            Object.assign(data, collectNeedsValues(needFields));
            $.post(ajax_url, data, function(response) {
                change_panel_html(response);
            });
        });
    });
    $(document).on('click', '.delete_popup_move', function(e) {
        e.preventDefault();
        const $a = $(this);
        let datas = this.dataset;
        
        let data = {
            action:  $a.attr('data-action'),
            item_id: $a.attr('data-id'),
            page:    $('#current_page').val(),
        };
        Swal.fire({
            title:             $a.attr('data-swal-title'),
            icon:              'warning',
            html:              buildNeedsHtml([], 'حذف'),
            showCancelButton:  true,
            confirmButtonText: 'بله',
            cancelButtonText:  'خیر',
        }).then((result) => {
            if (!result.isConfirmed) {
                return;
            }
            $.post(ajax_url, data, function(response) {
                change_panel_html(response);
            });
        });
    });
    $(document).on('click', '.load_item_data_to_modal', function(e) {
        e.preventDefault();
        let item_id = $(this).attr('data-item-id');
        let action = $(this).attr('data-action');
        let modal = $(this).attr('data-modal');
        modal = $(modal);
        let data = {
            action:  action,
            item_id: item_id,
        };
        $.post(ajax_url, data, function(response) {
            modal.modal('show');
            modal.find('.modal-body').html(response.html);
        });
    });
    $(document).on('change', '.kph-report-user-level', function() {
        const $select = $(this);
        
        const data = {
            action: 'kph_update_inline_meta',
            id:     $select.attr('data-user-id'),
            key:    'customer_level',
            value:  $select.val(),
        };
        
        $.post(ajax_url, data, function() {
            if (typeof NioApp !== 'undefined' && NioApp.Toast) {
                NioApp.Toast('سطح مشتری بروزرسانی شد', 'success', {
                    position: 'top-right',
                });
            }
        });
    });
    
    $(document).on('click', '.request_dashboard_block_data', function(e) {
        e.preventDefault();
        
        let $btn = $(this);
        let $card = $btn.closest('.card');
        
        if ($card.data('loading')) {
            return;
        }
        
        let action = $btn.attr('data-action') || '';
        
        if (!action) {
            console.warn('Dashboard block action is empty');
            return;
        }
        
        let data = atlas_parse_dashboard_atts($btn.attr('data-atts') || '');
        data.action = action;
        
        $card.data('loading', true).addClass('is-loading');
        ajax_search = true;
        $.post(ajax_url, data, function(response) {
            let payload = atlas_get_dashboard_payload(response);
            
            if (!payload) {
                console.warn('Invalid dashboard response', response);
                return;
            }
            
            atlas_apply_dashboard_targets(
                $btn.attr('data-targets') || '',
                payload,
            );
            ajax_search = false;
        }).always(function() {
            $card.data('loading', false).removeClass('is-loading');
            $card.find('.request_dashboard_block_data').removeClass('active');
            $btn.addClass('active');
        });
    });
    
    function atlas_parse_dashboard_atts(raw) {
        let data = {};
        
        if (!raw) {
            return data;
        }
        
        raw.split(';').forEach(function(row) {
            row = row.trim();
            
            if (!row) {
                return;
            }
            
            let parts = row.split(':');
            let key = (parts.shift() || '').trim();
            let value = parts.join(':').trim();
            
            if (!key) {
                return;
            }
            
            data[key] = value;
        });
        
        return data;
    }
    
    function atlas_get_dashboard_payload(response) {
        if (!response) {
            return null;
        }
        
        if (response.data) {
            return response.data;
        }
        
        if (response.result) {
            return response.result;
        }
        
        return response;
    }
    
    function atlas_apply_dashboard_targets(rawTargets, payload) {
        if (!rawTargets) {
            return;
        }
        
        rawTargets.split(';').forEach(function(row) {
            row = row.trim();
            
            if (!row) {
                return;
            }
            
            let parts = row.split(':');
            
            if (parts.length < 3) {
                return;
            }
            
            let responseKey = (parts.shift() || '').trim();
            let selector = (parts.shift() || '').trim();
            let action = parts.join(':').trim();
            
            if (!responseKey || !selector || !action) {
                return;
            }
            
            if (typeof payload[responseKey] === 'undefined') {
                return;
            }
            
            let value = payload[responseKey];
            let $target = $(selector);
            
            if (!$target.length) {
                return;
            }
            
            atlas_apply_dashboard_target_action($target, action, value);
        });
    }
    
    function atlas_apply_dashboard_target_action($target, action, value) {
        if (action === 'text') {
            $target.text(value);
            return;
        }
        
        if (action === 'html') {
            $target.html(value);
            return;
        }
        
        if (action === 'class') {
            atlas_apply_dashboard_class($target, value);
            return;
        }
        
        if (action === 'chart') {
            atlas_apply_dashboard_chart($target, value);
        }
    }
    
    function atlas_apply_dashboard_class($target, value) {
        let baseClass = $target.data('baseClass') || '';
        
        if (Array.isArray(value)) {
            value = value.join(' ');
        }
        
        $target.attr('class', (baseClass + ' ' + value).trim());
    }
    
    function atlas_apply_dashboard_chart($target, value) {
        if (!value || typeof value !== 'object') {
            return;
        }
        
        if (value.labels) {
            $target.attr('data-labels', JSON.stringify(value.labels));
        }
        
        if (value.data) {
            $target.attr('data-data', JSON.stringify(value.data));
        }
        
        if (value.points) {
            $target.attr('data-points', JSON.stringify(value.points));
        }
        
        let chart = $target.data('chartInstance');
        
        if (!chart) {
            $target.removeData('chartActivated');
            
            if (typeof activate_charts === 'function') {
                activate_charts();
            }
            
            return;
        }
        
        if (value.labels) {
            chart.data.labels = value.labels;
        }
        
        if (value.points) {
            if (chart.data.datasets[0]) {
                chart.data.datasets[0].data = value.points;
            }
            
            chart.update();
            return;
        }
        
        if (value.data) {
            let datasetsData = atlas_normalize_dashboard_chart_datasets(value.data);
            
            if (chart.data.datasets.length !== datasetsData.length) {
                chart.destroy();
                $target.removeData('chartInstance');
                $target.removeData('chartActivated');
                
                if (typeof activate_charts === 'function') {
                    activate_charts();
                }
                
                return;
            }
            
            chart.data.datasets.forEach(function(dataset, index) {
                dataset.data = datasetsData[index] || [];
            });
            
            chart.update();
        }
    }
    
    function atlas_normalize_dashboard_chart_datasets(data) {
        if (!Array.isArray(data)) {
            return [[data]];
        }
        
        if (!data.length) {
            return [[]];
        }
        
        if (Array.isArray(data[0])) {
            return data;
        }
        
        return [data];
    }
    
    function activate_charts() {
        if (typeof Chart === 'undefined') {
            console.warn('Chart.js not found');
            return;
        }
        
        atlas_init_chart_defaults();
        register_atlas_chart_center_text_plugin();
        register_atlas_doughnut_label_plugin();
        register_atlas_polar_donut_plugin();
        
        $('.atlas-chart, .atlas_chart').each(function() {
            let $chart = $(this);
            
            if ($chart.data('chartActivated')) {
                return;
            }
            
            $chart.data('chartActivated', true);
            
            let type = $chart.attr('data-chart-type') || 'bar';
            let data = atlas_parse_chart_data($chart);
            
            if (!data) {
                console.warn('Invalid chart data', this);
                return;
            }
            
            let canvas = atlas_get_chart_canvas($chart);
            let ctx = canvas.getContext('2d');
            
            let config = {
                type:    atlas_normalize_chart_type(type),
                data:    atlas_build_chart_data($chart, type, data),
                options: atlas_build_chart_options($chart, type),
            };

            if ($chart.attr('data-sales-report') === '1') {
                kph_style_sales_chart($chart, config);
            }
            
            kph_prepare_erp_chart($chart, config);
            let chart = new Chart(ctx, config);
            kph_bind_erp_chart($chart, chart);
            
            $chart.data('chartInstance', chart);

            if ($chart.attr('data-sales-report') === '1') {
                $chart.closest('.kph-chart-card').find('.kph-compare-toggle').on('change', function() {
                    chart.getDatasetMeta(1).hidden = !this.checked;
                    chart.update();
                });
            }
        });
    }

    // These options apply only to the sales report; other Atlas charts keep their defaults.
    function kph_style_sales_chart($chart, config) {
        const dates = atlas_safe_json_parse($chart.attr('data-period-labels')) || [];
        const divisor = Number($chart.attr('data-display-divisor')) || 1;
        const axisUnit = $chart.attr('data-display-unit') || '';
        const unit = $chart.attr('data-unit') || '';
        const number = new Intl.NumberFormat('fa-IR', {maximumFractionDigits: 2});
        const exact = new Intl.NumberFormat('fa-IR', {maximumFractionDigits: 0});
        const options = config.options;
        const xAxis = options.scales.xAxes[0];
        const yAxis = options.scales.yAxes[0];

        options.legend.display = false;
        options.animation.duration = window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 0 : 250;
        options.layout = {padding: {top: 12, right: 8, bottom: 0, left: 0}};
        Object.assign(xAxis.ticks, {
            autoSkip: true, maxTicksLimit: $chart.width() < 500 ? 4 : 8,
            minRotation: 0, maxRotation: 0, padding: 10, fontSize: 11,
        });
        Object.assign(yAxis.ticks, {
            maxTicksLimit: 6, padding: 10, fontSize: 11,
            callback: function(value) { return number.format(value / divisor); },
        });
        if (unit === 'سفارش') yAxis.ticks.precision = 0;
        yAxis.scaleLabel = {
            display: true, labelString: axisUnit, fontFamily: yAxis.ticks.fontFamily,
            fontColor: '#64748b', fontSize: 11,
        };
        yAxis.gridLines.zeroLineColor = '#94a3b8';
        yAxis.gridLines.zeroLineWidth = 1;
        options.onResize = function(chart, size) {
            chart.options.scales.xAxes[0].ticks.maxTicksLimit = size.width < 500 ? 4 : 8;
        };
        Object.assign(options.tooltips, {
            mode: 'index', intersect: false, displayColors: true,
            backgroundColor: '#1e293b', bodySpacing: 7, bodyFontSize: 12,
            xPadding: 14, yPadding: 12, cornerRadius: 10,
            callbacks: {
                title: function() { return ''; },
                label: function(item, data) {
                    const dataset = data.datasets[item.datasetIndex];
                    const date = (dates[item.index] || [])[item.datasetIndex] || dataset.label;
                    return [date, exact.format(dataset.data[item.index]) + ' ' + unit];
                },
            },
        });
        config.data.datasets.forEach(function(dataset, index) {
            if (config.type === 'line') {
                dataset.borderWidth = index === 0 ? 2.5 : 2;
                dataset.borderDash = index === 0 ? [] : [5, 5];
                dataset.pointRadius = dataset.data.length === 1 ? 4 : 0;
                dataset.pointHoverRadius = 5;
                dataset.pointHitRadius = 12;
                dataset.pointBackgroundColor = dataset.borderColor;
            } else {
                dataset.maxBarThickness = 16;
                dataset.categoryPercentage = 0.72;
                dataset.barPercentage = 0.85;
            }
        });
    }
    
    /**
     * =========================
     * Parse chart data
     * =========================
     */
    function atlas_parse_chart_data($chart) {
        let raw = $chart.attr('data-chart-data');
        
        if (raw) {
            return atlas_safe_json_parse(raw);
        }
        
        let points = atlas_safe_json_parse($chart.attr('data-points'));
        
        if (points) {
            return {
                points: points,
            };
        }
        
        let labels = atlas_safe_json_parse($chart.attr('data-labels'));
        let chartData = atlas_safe_json_parse($chart.attr('data-data'));
        
        if (labels && chartData) {
            return {
                labels: labels,
                data:   chartData,
            };
        }
        
        let percent = $chart.attr('data-percent');
        let value = $chart.attr('data-value');
        
        if (percent !== undefined || value !== undefined) {
            return {
                title:   $chart.attr('data-title') || '',
                value:   value || 0,
                percent: percent || 0,
            };
        }
        
        return null;
    }
    
    /**
     * =========================
     * Build chart data
     * =========================
     */
    function atlas_build_chart_data($chart, type, data) {
        let colors = atlas_get_chart_colors();
        
        if (type === 'scatter') {
            return {
                datasets: [
                    {
                        label: $chart.attr('data-label') || '',
                        data:  data.points || [],
                        
                        backgroundColor: $chart.attr('data-color') || $chart.attr('data-point-color') || colors.teal,
                        borderColor:     $chart.attr('data-color') || $chart.attr('data-point-color') || colors.teal,
                        
                        pointRadius:      parseInt($chart.attr('data-point-radius') || 5),
                        pointHoverRadius: parseInt($chart.attr('data-point-hover-radius') || 7),
                        
                        xLabel: $chart.attr('data-x-label') || $chart.attr('data-x-title') || 'محور X',
                        yLabel: $chart.attr('data-y-label') || $chart.attr('data-y-title') || 'محور Y',
                        
                        xUnit: $chart.attr('data-x-unit') || '',
                        yUnit: $chart.attr('data-y-unit') || $chart.attr('data-unit') || '',
                    },
                ],
            };
        }
        
        if (type === 'polar-donut') {
            let rawValues = atlas_normalize_single_dataset(data.data);
            let minRadius = parseFloat($chart.attr('data-min-radius') || 24);
            let renderedValues = atlas_build_polar_donut_render_data(rawValues, minRadius);
            
            return {
                labels:   data.labels,
                datasets: [
                    {
                        label:           $chart.attr('data-label') || '',
                        data:            renderedValues,
                        rawData:         rawValues,
                        backgroundColor: atlas_get_chart_dataset_colors($chart, rawValues),
                        borderWidth:     parseInt($chart.attr('data-border-width') || 0),
                        unit:            $chart.attr('data-unit') || '',
                    },
                ],
            };
        }
        
        if (type === 'line' || type === 'area') {
            return {
                labels:   data.labels,
                datasets: atlas_build_multi_datasets($chart, type, data),
            };
        }
        
        if (type === 'bar' || type === 'horizontalBar') {
            return {
                labels:   data.labels,
                datasets: atlas_build_multi_datasets($chart, type, data),
            };
        }
        
        if (type === 'radar') {
            return {
                labels:   data.labels,
                datasets: atlas_build_multi_datasets($chart, type, data),
            };
        }
        
        if (type === 'radial') {
            let percent = parseFloat(data.percent || 0);
            let remain = Math.max(100 - percent, 0);
            
            return {
                labels:   [
                    data.title || $chart.attr('data-label') || 'مقدار',
                    'باقی‌مانده',
                ],
                datasets: [
                    {
                        data:            [percent, remain],
                        backgroundColor: [
                            $chart.attr('data-color') || $chart.attr('data-ring-color') || colors.primary,
                            $chart.attr('data-ring-bg') || '#eef0f7',
                        ],
                        borderWidth:     0,
                        unit:            $chart.attr('data-unit') || '',
                    },
                ],
            };
        }
        
        /**
         * doughnut / pie / donut
         */
        return {
            labels:   data.labels,
            datasets: [
                {
                    label:           $chart.attr('data-label') || '',
                    data:            atlas_normalize_single_dataset(data.data),
                    backgroundColor: atlas_get_chart_dataset_colors($chart, data.data),
                    borderWidth:     parseInt($chart.attr('data-border-width') || 0),
                    unit:            $chart.attr('data-unit') || '',
                },
            ],
        };
    }
    
    /**
     * =========================
     * Multi Dataset Builder
     * data-label / data-data / data-color / data-unit
     * =========================
     */
    function atlas_build_multi_datasets($chart, type, data) {
        let labels = atlas_to_array(
            atlas_safe_json_parse($chart.attr('data-label')) || $chart.attr('data-label') || '');
        let rawData = data.data;
        let datasetsData = atlas_normalize_datasets_data(rawData);
        
        let colors = atlas_to_array(
            atlas_safe_json_parse($chart.attr('data-color')) || $chart.attr('data-color') || '');
        let units = atlas_to_array(atlas_safe_json_parse($chart.attr('data-unit')) || $chart.attr('data-unit') || '');
        let tensions = atlas_to_array(
            atlas_safe_json_parse($chart.attr('data-tension')) || $chart.attr('data-tension') || '');
        let fills = atlas_to_array(atlas_safe_json_parse($chart.attr('data-fill')) || $chart.attr('data-fill') || '');
        
        let defaultColors = atlas_get_default_color_list();
        
        return datasetsData.map(function(datasetData, index) {
            let color = atlas_get_index_value(colors, index, defaultColors[index % defaultColors.length]);
            let label = atlas_get_index_value(labels, index, '');
            let unit = atlas_get_index_value(units, index, atlas_get_index_value(units, 0, ''));
            
            if (type === 'line' || type === 'area') {
                let tension = parseFloat(atlas_get_index_value(tensions, index, 0.38));
                let fill = atlas_get_bool_value(atlas_get_index_value(fills, index, type === 'area'));
                
                return {
                    label: label,
                    data:  datasetData,
                    
                    borderColor:     color,
                    backgroundColor: atlas_hex_to_rgba(color, fill ? 0.12 : 0),
                    
                    borderWidth:      parseInt($chart.attr('data-border-width') || 3),
                    pointRadius:      parseInt($chart.attr('data-point-radius') || 3),
                    pointHoverRadius: parseInt($chart.attr('data-point-hover-radius') || 5),
                    
                    fill:        fill,
                    lineTension: tension,
                    unit:        unit,
                };
            }
            
            if (type === 'radar') {
                return {
                    label: label,
                    data:  datasetData,
                    
                    backgroundColor:      atlas_hex_to_rgba(color, 0.18),
                    borderColor:          color,
                    pointBackgroundColor: color,
                    pointBorderColor:     '#fff',
                    
                    pointRadius: parseInt($chart.attr('data-point-radius') || 4),
                    borderWidth: parseInt($chart.attr('data-border-width') || 2),
                    unit:        unit,
                };
            }
            
            return {
                label:           label,
                data:            datasetData,
                backgroundColor: color,
                borderColor:     color,
                borderWidth:     parseInt($chart.attr('data-border-width') || 0),
                unit:            unit,
            };
        });
    }
    
    /**
     * =========================
     * Build chart options
     * =========================
     */
    function atlas_build_chart_options($chart, type) {
        let showLegend = $chart.attr('data-legend') !== '0';
        let showGrid = $chart.attr('data-grid') !== '0';
        let title = $chart.attr('data-chart-title') || '';
        let isResponsive = $chart.attr('data-responsive') !== '0';
        let fontFamily = atlas_get_chart_font_family();
        
        let tooltipColors = $chart.attr('data-tooltip-colors');
        
        if (tooltipColors === '0') {
            tooltipColors = false;
        } else if (tooltipColors === '1') {
            tooltipColors = true;
        } else {
            tooltipColors = type !== 'scatter';
        }
        tooltipColors = false;
        
        let tooltipMode = $chart.attr('data-tooltip-mode') || '';
        
        if (!tooltipMode) {
            tooltipMode = (type === 'line' || type === 'area') ? 'index' : 'nearest';
        }
        
        let tooltipIntersect = $chart.attr('data-tooltip-intersect');
        
        if (tooltipIntersect === '1') {
            tooltipIntersect = true;
        } else if (tooltipIntersect === '0') {
            tooltipIntersect = false;
        } else {
            tooltipIntersect = !(type === 'line' || type === 'area');
        }
        
        let options = {
            responsive:          isResponsive,
            maintainAspectRatio: false,
            
            legend: {
                display:  showLegend,
                position: $chart.attr('data-legend-position') || 'bottom',
                rtl:      true,
                labels:   {
                    usePointStyle: true,
                    boxWidth:      8,
                    fontFamily:    fontFamily,
                    padding:       18,
                },
            },
            
            title: {
                display:    title !== '',
                text:       title,
                fontFamily: fontFamily,
                fontSize:   15,
                fontColor:  '#1f2937',
                padding:    18,
            },
            
            tooltips: {
                rtl:             true,
                mode:            tooltipMode,
                intersect:       tooltipIntersect,
                displayColors:   tooltipColors,
                titleFontFamily: fontFamily,
                bodyFontFamily:  fontFamily,
                backgroundColor: '#111827',
                cornerRadius:    8,
                xPadding:        12,
                yPadding:        10,
                callbacks:       {
                    title: function(tooltipItems, chartData) {
                        return atlas_chart_tooltip_title(tooltipItems, chartData, type);
                    },
                    label: function(tooltipItem, chartData) {
                        return atlas_chart_tooltip_label(tooltipItem, chartData, type);
                    },
                },
            },
            
            hover: {
                mode:      tooltipMode,
                intersect: tooltipIntersect,
            },
            
            animation: {
                duration: parseInt($chart.attr('data-animation-duration') || 700),
            },
        };
        
        if (type === 'polar-donut') {
            options.scale = {
                ticks:       {
                    display:     false,
                    beginAtZero: true,
                },
                gridLines:   {
                    display: false,
                },
                angleLines:  {
                    display: false,
                },
                pointLabels: {
                    display: false,
                },
            };
            
            options.startAngle = -0.5 * Math.PI;
            
            options.polarDonut = {
                cutoutPercentage: parseInt($chart.attr('data-cutout') || 36),
                centerFill:       $chart.attr('data-center-fill') || '#fff',
            };
            
            return options;
        }
        
        if (type === 'doughnut' || type === 'donut' || type === 'pie' || type === 'radial') {
            options.cutoutPercentage = parseInt($chart.attr('data-cutout') || 68);
            
            if ($chart.attr('data-show-labels') === '1') {
                options.atlasDoughnutLabels = {
                    type:  $chart.attr('data-label-type') || 'percent',
                    color: $chart.attr('data-label-color') || '#111827',
                };
            }
            
            if (type === 'radial') {
                options.legend.display = false;
                options.tooltips.enabled = $chart.attr('data-tooltip') === '1';
                options.centerText = {
                    title:    $chart.attr('data-center-title') || '',
                    value:    $chart.attr('data-center-value') || '',
                    subtitle: $chart.attr('data-center-subtitle') || '',
                };
            }
            
            return options;
        }
        
        if (type === 'radar') {
            options.scale = {
                ticks:       {
                    display:     false,
                    beginAtZero: true,
                },
                gridLines:   {
                    display: $chart.attr('data-radar-grid') === '1',
                    color:   'rgba(0,0,0,0)',
                },
                angleLines:  {
                    display: $chart.attr('data-radar-lines') === '1',
                    color:   'rgba(0,0,0,0)',
                },
                pointLabels: {
                    fontFamily: fontFamily,
                    fontColor:  '#6b7280',
                    fontSize:   12,
                },
            };
            
            return options;
        }
        
        if (type === 'scatter') {
            options.scales = {
                xAxes: [
                    {
                        type:       'linear',
                        position:   'bottom',
                        gridLines:  {
                            display:    showGrid,
                            color:      '#edf0f5',
                            drawBorder: false,
                        },
                        scaleLabel: {
                            display:     !!$chart.attr('data-x-title'),
                            labelString: $chart.attr('data-x-title') || '',
                            fontFamily:  fontFamily,
                        },
                        ticks:      {
                            fontFamily:  fontFamily,
                            fontColor:   '#6b7280',
                            beginAtZero: $chart.attr('data-begin-zero') !== '0',
                        },
                    },
                ],
                yAxes: [
                    {
                        gridLines:  {
                            display:    showGrid,
                            color:      '#edf0f5',
                            drawBorder: false,
                        },
                        scaleLabel: {
                            display:     !!$chart.attr('data-y-title'),
                            labelString: $chart.attr('data-y-title') || '',
                            fontFamily:  fontFamily,
                        },
                        ticks:      {
                            fontFamily:  fontFamily,
                            fontColor:   '#6b7280',
                            beginAtZero: $chart.attr('data-begin-zero') !== '0',
                        },
                    },
                ],
            };
            
            return options;
        }
        
        if (type === 'line' || type === 'area' || type === 'bar' || type === 'horizontalBar') {
            options.scales = {
                xAxes: [
                    {
                        gridLines: {
                            display:    type === 'horizontalBar' ? showGrid : false,
                            color:      '#edf0f5',
                            drawBorder: false,
                        },
                        ticks:     {
                            fontFamily: fontFamily,
                            fontColor:  '#6b7280',
                        },
                    },
                ],
                yAxes: [
                    {
                        gridLines: {
                            display:    showGrid,
                            color:      '#edf0f5',
                            drawBorder: false,
                        },
                        ticks:     {
                            fontFamily:  fontFamily,
                            fontColor:   '#6b7280',
                            beginAtZero: true,
                        },
                    },
                ],
            };
            
            return options;
        }
        
        return options;
    }
    
    /**
     * =========================
     * Tooltip
     * =========================
     */
    function atlas_chart_tooltip_title(tooltipItems, chartData, type) {
        if (!tooltipItems || !tooltipItems.length) {
            return '';
        }
        
        if (
            type === 'donut' ||
            type === 'doughnut' ||
            type === 'pie' ||
            type === 'polar-donut' ||
            type === 'radial' ||
            type === 'scatter'
        ) {
            return '';
        }
        
        let item = tooltipItems[0];
        let index = typeof item.index !== 'undefined' ? item.index : item._index;
        
        if (chartData.labels && typeof chartData.labels[index] !== 'undefined') {
            return chartData.labels[index];
        }
        
        return '';
    }
    
    function atlas_chart_tooltip_label(tooltipItem, chartData, type) {
        let datasetIndex = typeof tooltipItem.datasetIndex !== 'undefined'
                           ? tooltipItem.datasetIndex
                           : tooltipItem._datasetIndex;
        
        let index = typeof tooltipItem.index !== 'undefined'
                    ? tooltipItem.index
                    : tooltipItem._index;
        
        let dataset = chartData.datasets[datasetIndex || 0];
        
        if (!dataset) {
            return '';
        }
        
        let dataItem = null;
        
        if (dataset.data && typeof dataset.data[index] !== 'undefined') {
            dataItem = dataset.data[index];
        }
        
        /**
         * Scatter:
         * labelX:valueX unitX
         * labelY:valueY unitY
         */
        if (type === 'scatter' && typeof dataItem === 'object' && dataItem !== null) {
            let xLabel = dataItem.x_label || dataItem.label || dataItem.labelX || dataItem.xLabel || dataItem.x;
            let yLabel = dataItem.y_label || dataItem.labelY || dataItem.yLabel || dataItem.y;
            
            let xValue = dataItem.x_value || dataItem.valueX || xLabel;
            let yValue = dataItem.y_value || dataItem.valueY || dataItem.y;
            
            let lines = [];
            
            lines.push(
                (dataset.xLabel || 'محور X') + ': ' + atlas_format_chart_value(xValue, dataset.xUnit || ''),
            );
            
            lines.push(
                (dataset.yLabel || 'محور Y') + ': ' + atlas_format_chart_value(yValue, dataset.yUnit || ''),
            );
            
            return lines;
        }
        
        /**
         * Donut / Doughnut / Pie / Radial
         */
        if (
            type === 'donut' ||
            type === 'doughnut' ||
            type === 'pie' ||
            type === 'radial' ||
            type === 'polar-donut'
        ) {
            let label = '';
            
            if (chartData.labels && typeof chartData.labels[index] !== 'undefined') {
                label = chartData.labels[index];
            }
            
            let tooltipValue = dataItem;
            
            if (
                type === 'polar-donut' &&
                dataset.rawData &&
                typeof dataset.rawData[index] !== 'undefined'
            ) {
                tooltipValue = dataset.rawData[index];
            }
            
            return label + ': ' + atlas_format_chart_value(tooltipValue, dataset.unit || '');
        }
        
        /**
         * Normal charts:
         * title
         * label:value unit
         */
        let value = dataItem;
        
        if (typeof tooltipItem.yLabel !== 'undefined') {
            value = tooltipItem.yLabel;
        } else if (typeof tooltipItem.xLabel !== 'undefined') {
            value = tooltipItem.xLabel;
        }
        
        let datasetLabel = dataset.label || '';
        
        if (datasetLabel) {
            return datasetLabel + ': ' + atlas_format_chart_value(value, dataset.unit || '');
        }
        
        return atlas_format_chart_value(value, dataset.unit || '');
    }
    
    /**
     * =========================
     * Helpers
     * =========================
     */
    function atlas_safe_json_parse(value) {
        if (!value) {
            return null;
        }
        
        if (typeof value !== 'string') {
            return value;
        }
        
        try {
            return JSON.parse(value);
        } catch (e) {
            try {
                return JSON.parse(value.replace(/&quot;/g, '"'));
            } catch (e2) {
                return null;
            }
        }
    }
    
    function atlas_get_chart_canvas($chart) {
        let canvas = $chart.find('canvas').get(0);
        
        if (canvas) {
            return canvas;
        }
        
        let height = parseInt($chart.attr('data-chart-height') || 260);
        
        canvas = document.createElement('canvas');
        canvas.height = height;
        
        $chart.empty().append(canvas);
        
        return canvas;
    }
    
    function atlas_normalize_chart_type(type) {
        if (type === 'donut') {
            return 'doughnut';
        }
        
        if (type === 'area') {
            return 'line';
        }
        
        if (type === 'radial') {
            return 'doughnut';
        }
        
        if (type === 'polar-donut') {
            return 'polarArea';
        }
        
        return type;
    }
    
    function atlas_get_chart_font_family() {
        return $('body').css('font-family') || 'Tahoma, sans-serif';
    }
    
    function atlas_init_chart_defaults() {
        if (typeof Chart === 'undefined') {
            return;
        }
        
        let fontFamily = atlas_get_chart_font_family();
        
        Chart.defaults.global.defaultFontFamily = fontFamily;
        Chart.defaults.global.defaultFontColor = '#6b7280';
    }
    
    function atlas_normalize_datasets_data(data) {
        if (!Array.isArray(data)) {
            return [[data]];
        }
        
        if (!data.length) {
            return [[]];
        }
        
        if (Array.isArray(data[0])) {
            return data;
        }
        
        return [data];
    }
    
    function atlas_normalize_single_dataset(data) {
        if (!Array.isArray(data)) {
            return [data];
        }
        
        if (Array.isArray(data[0])) {
            return data[0];
        }
        
        return data;
    }
    
    function atlas_to_array(value) {
        if (Array.isArray(value)) {
            return value;
        }
        
        if (value === null || typeof value === 'undefined' || value === '') {
            return [];
        }
        
        return [value];
    }
    
    function atlas_get_index_value(values, index, fallback) {
        if (Array.isArray(values) && typeof values[index] !== 'undefined') {
            return values[index];
        }
        
        if (Array.isArray(values) && typeof values[0] !== 'undefined') {
            return values[0];
        }
        
        return fallback;
    }
    
    function atlas_get_bool_value(value) {
        if (value === true || value === 'true' || value === '1' || value === 1) {
            return true;
        }
        
        if (value === false || value === 'false' || value === '0' || value === 0) {
            return false;
        }
        
        return !!value;
    }
    
    function atlas_format_chart_value(value, unit) {
        if (typeof value === 'undefined' || value === null) {
            value = '';
        }
        
        if (!unit) {
            return value;
        }
        
        if (unit === '٪' || unit === '%') {
            return value + unit;
        }
        
        return value + ' ' + unit;
    }
    
    function atlas_get_chart_colors() {
        return {
            primary: '#635bff',
            blue:    '#3b82f6',
            teal:    '#14b8a6',
            orange:  '#f97316',
            pink:    '#ec4899',
            red:     '#f43f5e',
            yellow:  '#f59e0b',
            gray:    '#9ca3af',
        };
    }
    
    function atlas_get_default_color_list() {
        return [
            '#635bff',
            '#3b82f6',
            '#14b8a6',
            '#f97316',
            '#ec4899',
            '#f43f5e',
            '#f59e0b',
            '#9ca3af',
        ];
    }
    
    function atlas_get_chart_dataset_colors($chart, data) {
        let colors = atlas_safe_json_parse($chart.attr('data-color'));
        
        if (!colors) {
            colors = atlas_safe_json_parse($chart.attr('data-colors'));
        }
        
        if (colors && Array.isArray(colors)) {
            return colors;
        }
        
        let singleColor = $chart.attr('data-color');
        
        if (singleColor) {
            return singleColor;
        }
        
        let count = Array.isArray(data) ? data.length : 1;
        let base = atlas_get_default_color_list();
        let output = [];
        
        for (let i = 0; i < count; i++) {
            output.push(base[i % base.length]);
        }
        
        return output;
    }
    
    function atlas_hex_to_rgba(hex, alpha) {
        if (!hex || hex.indexOf('#') !== 0) {
            return hex || 'rgba(99,91,255,' + alpha + ')';
        }
        
        hex = hex.replace('#', '');
        
        if (hex.length === 3) {
            hex = hex.split('').map(function(char) {
                return char + char;
            }).join('');
        }
        
        let r = parseInt(hex.substring(0, 2), 16);
        let g = parseInt(hex.substring(2, 4), 16);
        let b = parseInt(hex.substring(4, 6), 16);
        
        return 'rgba(' + r + ',' + g + ',' + b + ',' + alpha + ')';
    }
    
    /**
     * =========================
     * Center text plugin
     * =========================
     */
    function register_atlas_chart_center_text_plugin() {
        if (window.atlasChartCenterTextPluginRegistered) {
            return;
        }
        
        window.atlasChartCenterTextPluginRegistered = true;
        
        Chart.plugins.register({
            beforeDraw: function(chart) {
                if (!chart.config.options.centerText) {
                    return;
                }
                
                let ctx = chart.chart.ctx;
                let width = chart.chart.width;
                let height = chart.chart.height;
                let centerText = chart.config.options.centerText;
                let fontFamily = atlas_get_chart_font_family();
                
                ctx.save();
                ctx.textAlign = 'center';
                ctx.textBaseline = 'middle';
                ctx.direction = 'rtl';
                
                if (centerText.title) {
                    ctx.font = '12px ' + fontFamily;
                    ctx.fillStyle = '#6b7280';
                    ctx.fillText(centerText.title, width / 2, height / 2 - 24);
                }
                
                if (centerText.value) {
                    ctx.font = 'bold 22px ' + fontFamily;
                    ctx.fillStyle = '#111827';
                    ctx.fillText(centerText.value, width / 2, height / 2);
                }
                
                if (centerText.subtitle) {
                    ctx.font = '12px ' + fontFamily;
                    ctx.fillStyle = '#6b7280';
                    ctx.fillText(centerText.subtitle, width / 2, height / 2 + 24);
                }
                
                ctx.restore();
            },
        });
    }
    
    /**
     * =========================
     * Doughnut labels plugin
     * =========================
     */
    function register_atlas_doughnut_label_plugin() {
        if (window.atlasDoughnutLabelPluginRegistered) {
            return;
        }
        
        window.atlasDoughnutLabelPluginRegistered = true;
        
        Chart.plugins.register({
            afterDatasetsDraw: function(chart) {
                let options = chart.config.options || {};
                
                if (!options.atlasDoughnutLabels) {
                    return;
                }
                
                if (chart.config.type !== 'doughnut' && chart.config.type !== 'pie') {
                    return;
                }
                
                let ctx = chart.chart.ctx;
                let dataset = chart.data.datasets[0];
                
                if (!dataset || !dataset.data) {
                    return;
                }
                
                let total = dataset.data.reduce(function(sum, value) {
                    return sum + Number(value || 0);
                }, 0);
                
                let fontFamily = atlas_get_chart_font_family();
                
                ctx.save();
                ctx.textAlign = 'center';
                ctx.textBaseline = 'middle';
                ctx.direction = 'rtl';
                ctx.font = '12px ' + fontFamily;
                ctx.fillStyle = options.atlasDoughnutLabels.color || '#111827';
                
                chart.getDatasetMeta(0).data.forEach(function(element, index) {
                    let value = Number(dataset.data[index] || 0);
                    
                    if (!value || total <= 0) {
                        return;
                    }
                    
                    let percent = Math.round((value / total) * 100);
                    
                    if (percent < 6) {
                        return;
                    }
                    
                    let position = element.tooltipPosition();
                    let label = chart.data.labels[index] || '';
                    
                    let text = options.atlasDoughnutLabels.type === 'label'
                               ? label
                               : percent + '٪';
                    
                    ctx.fillText(text, position.x, position.y);
                });
                
                ctx.restore();
            },
        });
    }
    
    function atlas_build_polar_donut_render_data(values, minRadiusPercent) {
        if (!Array.isArray(values)) {
            values = [values];
        }
        
        minRadiusPercent = parseFloat(minRadiusPercent || 25);
        
        if (minRadiusPercent < 0) {
            minRadiusPercent = 0;
        }
        
        if (minRadiusPercent > 95) {
            minRadiusPercent = 95;
        }
        
        let maxValue = Math.max.apply(null, values.map(function(value) {
            return Number(value || 0);
        }));
        
        if (!maxValue || maxValue <= 0) {
            return values.map(function() {
                return minRadiusPercent;
            });
        }
        
        return values.map(function(value) {
            value = Number(value || 0);
            
            return minRadiusPercent + ((value / maxValue) * (100 - minRadiusPercent));
        });
    }
    
    function register_atlas_polar_donut_plugin() {
        if (window.atlasPolarDonutPluginRegistered) {
            return;
        }
        
        window.atlasPolarDonutPluginRegistered = true;
        
        Chart.plugins.register({
            afterDatasetsDraw: function(chart) {
                let options = chart.config.options || {};
                
                if (!options.polarDonut) {
                    return;
                }
                
                if (chart.config.type !== 'polarArea') {
                    return;
                }
                
                let meta = chart.getDatasetMeta(0);
                
                if (!meta || !meta.data || !meta.data.length) {
                    return;
                }
                
                let firstArc = meta.data[0];
                
                if (!firstArc || !firstArc._model) {
                    return;
                }
                
                let model = firstArc._model;
                let ctx = chart.chart.ctx;
                
                let centerX = model.x;
                let centerY = model.y;
                let outerRadius = model.outerRadius || 0;
                
                let cutoutPercentage = options.polarDonut.cutoutPercentage || 36;
                let innerRadius = outerRadius * (cutoutPercentage / 100);
                
                ctx.save();
                ctx.beginPath();
                ctx.fillStyle = options.polarDonut.centerFill || '#fff';
                ctx.arc(centerX, centerY, innerRadius, 0, Math.PI * 2);
                ctx.closePath();
                ctx.fill();
                ctx.restore();
            },
        });
    }
    
    $(document).on('click', '.print_list_items', function(e) {
        e.preventDefault();
        
        let $btn = $(this);
        let type = $btn.attr('data-type') || '';
        if (type === 'cheques' && chequeNotePrintAllBusy) {
            NioApp.Toast('تنظیم چاپ در حال ذخیره است؛ چند لحظه صبر کنید.', 'info', {position: 'top-right'});
            return;
        }
        let collectRaw = $btn.attr('data-collect') || 'ids';
        let baseUrl = $btn.attr('data-print-url') || '/crm';
        
        if (!type) {
            console.warn('Print type is empty');
            return;
        }
        
        let collects = collectRaw.split(',').map(function(item) {
            return item.trim();
        }).filter(Boolean);
        
        let params = {
            action: 'print',
            type:   type,
        };
        
        if (collects.includes('ids')) {
            let ids = [];
            
            $('.select_item_for_print:checked').each(function() {
                let id = parseInt($(this).val());
                
                if (id && ids.indexOf(id) === -1) {
                    ids.push(id);
                }
            });
            
            if (!ids.length) {
                kph_print_notice('حداقل یک مورد را برای پرینت انتخاب کنید.');
                return;
            }
            
            params.ids = ids.join(',');
        }
        
        if (collects.includes('date')) {
            let targets = $btn.attr('data-targets') || '';
            let targetParts = targets.split(':');
            
            let fromSelector = targetParts[0] || '';
            let toSelector = targetParts[1] || '';
            
            let dateFrom = fromSelector ? $(fromSelector).val() : '';
            let dateTo = toSelector ? $(toSelector).val() : '';
            
            if (!dateFrom && !dateTo) {
                // kph_print_notice('بازه تاریخی را انتخاب کنید.');
                // return;
            } else {
                params.date = (dateFrom || '') + '...' + (dateTo || '');
            }
        }
        
        if (collects.includes('user')) {
            let userSelector = $btn.attr('data-user') || '';
            let userId = userSelector ? $(userSelector).val() : '';
            
            if (!userId) {
                kph_print_notice('کاربر را انتخاب کنید.');
                return;
            }
            
            params.user_id = userId;
        }
        
        let queryString = $.param(params);
        let url = baseUrl + '?' + queryString;
        
        window.open(url, '_blank');
    });
    
    function kph_print_notice(message) {
        if (typeof NioApp !== 'undefined' && NioApp.Toast) {
            NioApp.Toast(message, 'warning', {
                position: 'top-right',
            });
            return;
        }
        
        alert(message);
    }
    
    $(document).on('click', '.js-print-table', function(e) {
        e.preventDefault();
        
        let btn = $(this);
        let target = btn.attr('data-target');
        let url = btn.attr('data-print-url');
        let title = btn.attr('data-title') || document.title;
        
        let table = $(target);
        
        if (!table.length) {
            alert('جدول مورد نظر پیدا نشد.');
            return;
        }
        
        let html = $('<div>').append(table.clone()).html();
        
        let form = $('<form>', {
            method: 'post',
            action: url,
            target: '_blank',
            style:  'display:none',
        });
        
        form.append($('<input>', {
            type:  'hidden',
            name:  'print_title',
            value: title,
        }));
        
        form.append($('<textarea>', {
            name: 'print_html',
            text: html,
        }));
        
        $('body').append(form);
        
        form.trigger('submit');
        
        setTimeout(function() {
            form.remove();
        }, 1000);
    });
    $(document).on('click', '.order_action_btn', function(e) {
        e.preventDefault();
        
        const $button = $(this);
        const action = $button.attr('data-action');
        const label = $.trim($button.text())
            || $button.attr('title')
            || 'تأیید عملیات';
        
        if (!action) {
            return;
        }
        
        let needs = $button.attr('data-needs');
        
        try {
            needs = (needs && needs !== 'null')
                    ? JSON.parse(needs)
                    : null;
        } catch (error) {
            needs = null;
        }
        
        const needFields = needs
                           ? (
                               Array.isArray(needs)
                               ? needs
                               : (Array.isArray(needs.needs) ? needs.needs : null)
                           )
                           : null;
        
        const data = get_current_page_filters();
        
        // اکشن به‌صورت مستقل ارسال می‌شود.
        data.action = action;
        data.page = $('#current_page').val();
        
        // تمام data-*ها به‌جز action و needs به درخواست اضافه می‌شوند.
        $.each(this.attributes, function() {
            if (!this.name.startsWith('data-')) {
                return;
            }
            
            const dataKey = this.name.replace(/^data-/, '').replace(/-/g, '_');
            
            if (dataKey === 'action' || dataKey === 'needs') {
                return;
            }
            
            data[dataKey] = this.value;
        });
        
        Swal.fire({
            title:             label,
            icon:              'warning',
            html:              buildNeedsHtml(needFields, label),
            showCancelButton:  true,
            confirmButtonText: 'بله',
            cancelButtonText:  'خیر',
        }).then((result) => {
            if (!result.isConfirmed) {
                return;
            }
            
            Object.assign(data, collectNeedsValues(needFields));
            
            $.post(ajax_url, data, function(response) {
                change_panel_html(response);
            });
        });
    });
    
    $(document).on('input change', '.line_qty', function() {
        if (!$(this).next('.line_qty_text').length) {
            $(this).after('<span class="line_qty_text"></span>');
        }
        
        updateLineQtyText($(this));
    });
    
    function updateLineQtyText(input) {
        
        let value = parseFloat(input.val());
        
        if (isNaN(value) || value <= 0) {
            input.next('.line_qty_text').text('');
            return;
        }
        
        let totalGrams = value * 1000;
        
        let kilos = Math.floor(totalGrams / 1000);
        let grams = totalGrams - (kilos * 1000);
        
        grams = parseFloat(grams.toFixed(3));
        
        let output = '';
        
        if (kilos > 0) {
            output += numberToPersian(kilos) + ' کیلو';
        }
        
        if (grams > 0) {
            if (kilos > 0) {
                output += ' و ';
            }
            
            output += grams + ' گرم';
        }
        
        input.next('.line_qty_text').text(output);
    }
    
    function numberToPersian(number) {
        const numbers = {
            1:  'یک',
            2:  'دو',
            3:  'سه',
            4:  'چهار',
            5:  'پنج',
            6:  'شش',
            7:  'هفت',
            8:  'هشت',
            9:  'نه',
            10: 'ده',
        };
        
        return numbers[number] || number;
    }
}(NioApp, jQuery);
