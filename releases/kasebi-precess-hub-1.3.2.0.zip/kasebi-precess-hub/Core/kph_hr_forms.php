<?php
if (!defined('ABSPATH')) { exit; }

/** Versioned personnel forms; legacy records keep their original calculation path. */
trait kph_hr_forms {
    public static function settlement_templates(): array {
        return ['benefits'=>'تسویه مزایای اشتغال','general'=>'تسویه‌حساب عمومی','final'=>'تسویه‌حساب پایان قرارداد','monthly'=>'تسویه‌حساب ماهیانه','combined'=>'تسویه عمومی و پایان قرارداد (دو برگی)'];
    }
    public static function settlement_declaration(string $template='general'): string {
        if ($template==='benefits') { return 'بدینوسیله با امضا و اثر انگشت خود دریافت وجه فوق را اقرار و اعلام می‌نمایم.'; }
        if ($template==='monthly') { return ''; }
        return 'با تأیید اظهارات فوق و قبول اینکه هیچ‌گونه حق و حقوقی پیش‌بینی‌نشده از کارفرمای موصوف نداشته و ندارم، اعلام و اقرار می‌نمایم که هر آینه تحت هر عنوان از عناوین مربوطه مذکور یا غیرمذکور ادعایی نمایم، آن ادعا از درجه اعتبار ساقط بوده و حق پیگیری کلیه مطالبات و اعتراضات بعدی و احتمالی خود را تحت هر عنوان در مراجع ذی‌صلاح قضایی و غیرقضایی از خود سلب و ساقط نموده و می‌نمایم.';
    }
    public static function contract_defaults(): array {
        return [
            'title'=>'قرارداد کار موقت','basis'=>'monthly','normal_days'=>30,
            'duties'=>'انجام امور محوله مطابق شرح شغل و توافق طرفین.',
            'benefits_text'=>'بن کارگری، حق مسکن، حق تأهل، حق اولاد و پایه سنوات در صورت احراز شرایط پرداخت می‌شود. پرداخت حقوق و مزایا به نسبت کارکرد است.',
            'insurance_tax_text'=>'بیمه و مالیات مشمول، مطابق مقررات و اطلاعات تأییدشده از حقوق ماهانه کسر خواهد شد.',
            'working_hours_text'=>'میزان ساعات کار و ساعت شروع و پایان با توافق طرفین تعیین می‌شود. اضافه‌کاری و کسرکار بر اساس کارکرد تأییدشده محاسبه می‌گردد.',
            'termination_terms'=>'این قرارداد با توافق طرفین و با رعایت مقررات مربوط قابل خاتمه است.',
            'other_conditions'=>'پرسنل متعهد است وسایل و اموال تحویلی را سالم به کارفرما برگرداند. عیدی و سنوات با توجه به کارکرد پرداخت می‌شود.',
        ];
    }
    public function save_company(array $in): void {
        $this->guard();$data=$this->form_employer($in);update_option('kph_hr_company',$data,FALSE);
        if (get_option('kph_hr_company',[])!==$data) { throw new RuntimeException('ذخیره اطلاعات کارفرما انجام نشد.'); }
    }
    public function person_form_defaults(int $employee): array {
        $profile=$this->profile($employee); $p=$profile['data'];
        return [
            'person_name'=>$p['full_name']??get_user_name_by_id($employee),
            'person_father_name'=>$p['father_name']??'', 'person_national_id'=>$p['national_id']??'',
            'person_identity_no'=>$p['identity_no']??'', 'person_birth_date'=>$p['birth_date']??'',
            'person_birth_place'=>$p['birth_place']??'', 'person_issue_place'=>$p['issue_place']??'',
            'person_address'=>$p['address']??'', 'person_phone'=>$p['phone']??'',
            'person_job_title'=>$p['job_title']??'', 'person_department'=>$p['department']??'',
            'person_employee_no'=>$profile['employee_no'], 'person_insurance_no'=>$p['insurance_no']??'',
        ];
    }
    private function form_person(int $employee,array $in): array {
        $out=$this->person_form_defaults($employee);
        foreach ($out as $key=>$default) { $out[$key]=$this->text($in[$key]??$default,$key==='person_address'?1000:190); }
        foreach (['person_national_id','person_identity_no','person_phone'] as $key) { $out[$key]=nooshika_sanitize_numbers($out[$key]); }
        if ($out['person_birth_date']!=='') { $out['person_birth_date']=$this->date($out['person_birth_date']); }
        if ($out['person_name']==='') { throw new RuntimeException('نام و نام خانوادگی پرسنل را وارد کنید.'); }
        return $out;
    }
    private function form_employer(array $in,array $defaults=[]): array {
        $saved=get_option('kph_hr_company',[]);$defaults=array_merge(is_array($saved)?$saved:[],$defaults);
        $out=[];
        foreach (['company_name','employer_name','employer_national_id','company_registration','employer_address','employer_phone','workplace_address'] as $key) {
            $out[$key]=$this->text($in[$key]??$defaults[$key]??'',str_contains($key,'address')?1500:190);
        }
        return $out;
    }
    public function salary_period(array $in): array {
        $period=nooshika_sanitize_numbers($this->text($in['period']??'',20));
        if (isset($in['salary_year']) || isset($in['salary_month'])) {
            $year=(int)$this->number($in['salary_year']??0,1499); $month=(int)$this->number($in['salary_month']??0,12);
        } elseif (preg_match('/^(1[34]\d{2})[\/-](\d{1,2})$/D',$period,$m)) { $year=(int)$m[1];$month=(int)$m[2]; }
        else { throw new RuntimeException('سال و ماه فیش را انتخاب کنید.'); }
        if ($year<1300||$month<1||$month>12) { throw new RuntimeException('سال و ماه حقوق معتبر نیست.'); }
        $from=$this->date(sprintf('%04d/%02d/01',$year,$month));
        $next=$this->date(sprintf('%04d/%02d/01',$month===12?$year+1:$year,$month===12?1:$month+1));
        $end=(new DateTimeImmutable($next))->modify('-1 day')->format('Y-m-d');
        return ['period'=>sprintf('%04d/%02d',$year,$month),'from'=>$from,'to'=>$end,'days'=>(int)(new DateTimeImmutable($from))->diff(new DateTimeImmutable($next))->format('%a')];
    }
    private function normalize_form(int $employee,string $kind,array $in): array {
        $d=['form_version'=>2,'title'=>$this->text($in['title']??'',200),'notes'=>$this->text($in['notes']??'',5000),'public_notes'=>$this->text($in['public_notes']??'',3000),'person'=>$this->form_person($employee,$in)];
        $period='';$lock=NULL;$amount=0;
        if ($kind==='payslip') {
            $p=$this->salary_period($in);$from=$p['from'];$to=$p['to'];$period=$p['period'];$lock=$period;
            if (!$d['title']) { $d['title']='فیش حقوقی '.$period; }
            $d['calculation_mode']=$this->text($in['calculation_mode']??'manual',20);
            $d['work_source']=$this->text($in['work_source']??'manual',20);
            if (!in_array($d['calculation_mode'],['manual','contract'],TRUE)||!in_array($d['work_source'],['manual','attendance'],TRUE)) { throw new RuntimeException('روش محاسبه فیش معتبر نیست.'); }
            $contract=NULL;$c=[];
            if ($d['calculation_mode']==='contract') {
                $contract=$this->record((int)($in['contract_id']??0),$employee);$c=$contract['data'];
                if ($contract['kind']!=='contract'||$contract['status']!=='approved'||$contract['date_from']>$from||($contract['date_to']!==NULL&&$contract['date_to']<$to)) { throw new RuntimeException('قرارداد تأییدشده باید تمام ماه حقوق را پوشش دهد.'); }
                $d['contract_id']=(int)$contract['id'];$d['contract_snapshot']=$c;
            } else { $d['contract_id']=0; }
            $d['employer']=$this->form_employer($in,$c['employer']??[]);
            $d['paid_days']=$this->number($in['paid_days']??$p['days'],31,TRUE);
            $d['normal_days']=$this->number($d['calculation_mode']==='contract'?($c['normal_days']??30):($in['normal_days']??30),31,TRUE);
            if ($d['normal_days']<1 || $d['paid_days']>$p['days']) { throw new RuntimeException('روزهای مبنا و کارکرد ماه را بررسی کنید.'); }
            $d['monthly_base']=(int)$this->number($d['calculation_mode']==='contract'?($c['rate']??0):($in['monthly_base']??0));
            if ($d['monthly_base']<=0) { throw new RuntimeException('حقوق پایه باید بیشتر از صفر باشد.'); }
            $d['basis']=$d['calculation_mode']==='contract'?($c['basis']??'monthly'):'monthly';
            foreach (['worked_hours','overtime_hours','night_hours','friday_days','mission_days','shortage_hours'] as $key) { $d[$key]=$this->number($in[$key]??0,str_ends_with($key,'days')?31:744,TRUE); }
            if ($d['work_source']==='attendance') {
                $work=$this->work_summary($employee,$from,$to);$d['work_snapshot']=$work;$d['worked_hours']=$work['worked_minutes']/60;$d['overtime_hours']=$work['overtime_minutes']/60;
            }
            foreach (['overtime_rate','night_rate','friday_rate','mission_rate','shortage_rate'] as $key) { $d[$key]=(int)$this->number($key==='overtime_rate'&&$contract?($c['overtime_rate']??0):($in[$key]??0)); }
            $d['base_amount']=(int)round($d['basis']==='hourly'?$d['monthly_base']*$d['worked_hours']:($d['basis']==='daily'?$d['monthly_base']*$d['paid_days']:$d['monthly_base']*$d['paid_days']/$d['normal_days']));
            $d['daily_rate']=(int)round($d['basis']==='daily'?$d['monthly_base']:($d['basis']==='hourly'?0:$d['monthly_base']/$d['normal_days']));
            foreach (['overtime'=>'hours','night'=>'hours','friday'=>'days','mission'=>'days','shortage'=>'hours'] as $prefix=>$unit) {
                if ($d[$prefix.'_'.$unit]>0&&$d[$prefix.'_rate']<=0) { throw new RuntimeException('نرخ '.(['overtime'=>'اضافه‌کاری','night'=>'شب‌کاری','friday'=>'جمعه‌کاری','mission'=>'مأموریت','shortage'=>'کسرکار'][$prefix]).' را وارد کنید.'); }
                $d[$prefix.'_amount']=(int)round($d[$prefix.'_'.$unit]*$d[$prefix.'_rate']);
            }
            foreach (['housing','food_allowance','marriage_allowance','child_allowance','seniority_base','benefits','bonus','insurance','tax','deductions','paid_advance'] as $key) { $d[$key]=(int)$this->number($in[$key]??0); }
            $d['child_count']=(int)$this->number($in['child_count']??0,30);
            $d['gross']=$d['base_amount']+$d['overtime_amount']+$d['night_amount']+$d['friday_amount']+$d['mission_amount'];
            foreach (['housing','food_allowance','marriage_allowance','child_allowance','seniority_base','benefits','bonus'] as $key) { $d['gross']+=$d[$key]; }
            $d['salary_deductions']=$d['insurance']+$d['tax']+$d['deductions']+$d['shortage_amount'];
            $amount=$d['gross']-$d['salary_deductions']; $d['payable_amount']=$amount-$d['paid_advance'];$d['deductions_total']=$d['salary_deductions']+$d['paid_advance'];
            if ($amount<0||$d['payable_amount']<0) { throw new RuntimeException('کسورات و مساعده بیشتر از حقوق این ماه است.'); }
        } else {
            $from=$this->date($in['date_from']??'');$end=$this->text($in['date_to']??'',10);$to=$kind==='contract'&&$end===''?NULL:$this->date($end);
            if ($to!==NULL&&$to<$from) { throw new RuntimeException('تاریخ پایان قبل از شروع است.'); }
            $d['employer']=$this->form_employer($in);
            if ($kind==='contract') {
                if (!$d['title']) { $d['title']='قرارداد کار موقت'; }
                $d['basis']=$this->text($in['basis']??'monthly',20);
                if (!in_array($d['basis'],['monthly','daily','hourly'],TRUE)) { throw new RuntimeException('روش حقوق معتبر نیست.'); }
                foreach (['rate','overtime_rate','housing','food_allowance','marriage_allowance','child_allowance','seniority_base'] as $key) { $d[$key]=(int)$this->number($in[$key]??0); }
                $d['normal_days']=$this->number($in['normal_days']??30,31,TRUE);
                if ($d['rate']<=0||$d['normal_days']<1) { throw new RuntimeException('حقوق پایه و روزهای مبنا را وارد کنید.'); }
                $d['job_title']=$this->text($in['job_title']??$d['person']['person_job_title'],200);
                $d['contract_date']=empty($in['contract_date'])?substr(current_time('mysql'),0,10):$this->date($in['contract_date']);
                foreach (['duties','benefits_text','insurance_tax_text','working_hours_text','termination_terms','other_conditions','terms'] as $key) { $d[$key]=$this->text($in[$key]??self::contract_defaults()[$key]??'',10000); }
                $amount=$d['rate'];
            } elseif ($kind==='settlement') {
                $d['template']=$this->text($in['template']??'final',20);
                if (!isset(self::settlement_templates()[$d['template']])) { throw new RuntimeException('مدل فرم تسویه را انتخاب کنید.'); }
                if (!$d['title']) { $d['title']=self::settlement_templates()[$d['template']]; }
                $d['settlement_effect']=$this->text($in['settlement_effect']??'document_only',20);
                if (!in_array($d['settlement_effect'],['document_only','new_benefits'],TRUE)) { throw new RuntimeException('نحوه ثبت تسویه معتبر نیست.'); }
                foreach (['base_salary','housing','food_allowance','child_allowance','seniority_base','overtime_amount','severance','annual_bonus','leave_cash','other_due','insurance','tax','deductions','paid_cash','paid_cheque','paid_transfer'] as $key) { $d[$key]=(int)$this->number($in[$key]??0); }
                foreach (['leave_days','seniority_days','bonus_days','benefit_months'] as $key) { $d[$key]=$this->number($in[$key]??0,40000,TRUE); }
                $d['child_count']=(int)$this->number($in['child_count']??0,30);
                $d['seniority_from']=empty($in['seniority_from'])?$from:$this->date($in['seniority_from']);$d['seniority_to']=empty($in['seniority_to'])?$to:$this->date($in['seniority_to']);
                if ($d['seniority_to']<$d['seniority_from']) { throw new RuntimeException('بازه سنوات معتبر نیست.'); }
                $d['receipt_date']=empty($in['receipt_date'])?substr(current_time('mysql'),0,10):$this->date($in['receipt_date']);
                $d['cheque_date']=empty($in['cheque_date'])?'':$this->date($in['cheque_date']);
                foreach (['cheque_bank','cheque_no','transfer_tracking','case_no','receipt_amount_words'] as $key) { $d[$key]=$this->text($in[$key]??'',500); }
                $d['declaration_text']=$this->text($in['declaration_text']??self::settlement_declaration($d['template']),10000);
                $d['settlement_period']=$this->text(nooshika_sanitize_numbers($in['settlement_period']??''),20);
                if($d['settlement_period']!==''&&!preg_match('/^1[34]\d{2}[\/-](0?[1-9]|1[0-2])$/D',$d['settlement_period'])){throw new RuntimeException('ماه تسویه معتبر نیست؛ مانند ۱۴۰۵/۰۷ وارد کنید.');}
                $d['receipt_total']=0;
                foreach (['base_salary','housing','food_allowance','child_allowance','seniority_base','overtime_amount','severance','annual_bonus','leave_cash','other_due'] as $key) { $d['receipt_total']+=$d[$key]; }
                $d['receipt_total']-=$d['insurance']+$d['tax']+$d['deductions'];
                if (isset($in['receipt_amount'])&&trim((string)$in['receipt_amount'])!=='') { $d['receipt_total']=(int)$this->number($in['receipt_amount']);$d['receipt_amount']=$d['receipt_total']; }
                if ($d['receipt_total']<0) { throw new RuntimeException('مبلغ تسویه منفی است.'); }
                $payments=$d['paid_cash']+$d['paid_cheque']+$d['paid_transfer'];
                if ($payments>0&&$payments!==$d['receipt_total']) { throw new RuntimeException('جمع مبالغ نقد، چک و حواله با مبلغ دریافتی فرم برابر نیست.'); }
                $d['new_benefits_total']=$d['severance']+$d['annual_bonus']+$d['leave_cash']+$d['other_due']-$d['deductions'];
                if ($d['settlement_effect']==='new_benefits'&&$d['new_benefits_total']<0) { throw new RuntimeException('مزایای جدید تسویه منفی است.'); }
                $d['balance_snapshot']=$this->ledger->get_ledger_balance_now($employee)['balance']??0;
                $amount=$d['settlement_effect']==='new_benefits'?$d['new_benefits_total']:$d['receipt_total'];
                $lock=$d['settlement_effect']==='new_benefits'?$from.'_'.$to:NULL;
            }
        }
        return ['employee_id'=>$employee,'kind'=>$kind,'lock_key'=>$lock,'instrument_key'=>NULL,'period'=>$period,'date_from'=>$from,'date_to'=>$to,'data'=>$this->encode($d),'amount'=>$amount];
    }
}
