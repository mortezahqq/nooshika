<?php
if(!defined('ABSPATH')){exit;}
$request=isset($request)&&is_array($request)?$request:[];
$record=absint($request['record_id']??0);$employee=absint($user_id??$request['user_id']??0);
if(!kph_hr::allowed()||!wp_verify_nonce($request['_wpnonce']??'','kph_hr_print_'.$record)){wp_die('دسترسی به چاپ کارگزینی مجاز نیست.','',['response'=>403]);}
try{$hr=new kph_hr();$r=$hr->record($record,$employee);$profile=$hr->profile($employee);}catch(Throwable $e){wp_die('رکورد کارگزینی یافت نشد.','',['response'=>404]);}
if(in_array($r['kind'],['contract','payslip','settlement'],TRUE)){echo kph_hr_export_html(kph_hr_exports::model($hr,$employee,$record));return;}
$d=$r['data'];$title=kph_hr::kinds()[$r['kind']];$fields=kph_hr_fields($r['kind']);
// Private personnel/contact data and internal notes are deliberately omitted.
unset($fields['notes']);
?>
<!doctype html><html lang="fa" dir="rtl"><head><meta charset="UTF-8"><title><?php echo esc_html($title);?></title>
<style>@page{size:A4;margin:12mm}body{font-family:Tahoma,sans-serif;direction:rtl;line-height:1.8;color:#111}table{border-collapse:collapse;width:100%;margin:20px 0}td,th{border:1px solid #777;padding:7px;text-align:right;overflow-wrap:anywhere}tr{break-inside:avoid}.actions{margin:15px 0}@media print{.actions{display:none}}</style></head><body>
<div class="actions"><button onclick="window.print()">پرینت / ذخیره PDF</button></div>
<h2><?php echo esc_html($title);?> #<?php echo (int)$r['id'];?></h2>
<p>نام پرسنل: <?php echo esc_html(get_user_name_by_id($employee));?> | کد پرسنلی: <?php echo esc_html($profile['employee_no']);?></p>
<p>وضعیت: <?php echo esc_html(kph_hr::statuses()[$r['status']]);?> | دوره: <?php echo esc_html($r['period']);?></p>
<table><thead><tr><th>شرح</th><th>مقدار</th></tr></thead><tbody>
<?php foreach($fields as $key=>$def){$v=$r[$key]??$d[$key]??'';if($v===''){continue;}
 if($def[1]==='select'){$v=$def[2][$v]??$v;}
 elseif($def[1]==='date'){$v=kph_hr_exports::date((string)$v);}
 elseif($def[1]==='number'){$v=number_format((float)$v);}
?><tr><th><?php echo esc_html($def[0]);?></th><td style="white-space:pre-wrap"><?php echo esc_html($v);?></td></tr><?php }
foreach(['base_amount'=>'حقوق پایه محاسبه‌شده (ریال)','overtime_amount'=>'اضافه‌کاری (ریال)','gross'=>'ناخالص حقوق (ریال)'] as $key=>$label){if(isset($d[$key])){?><tr><th><?php echo esc_html($label);?></th><td><?php echo number_format($d[$key]);?></td></tr><?php }}?>
<?php if(!in_array($r['kind'],['leave','attendance','document'],TRUE)){?><tr><th><?php echo $r['kind']==='settlement'?'خالص مزایای جدید تسویه (ریال)':'مبلغ / خالص فیش (ریال)';?></th><td><?php echo number_format($r['amount']);?></td></tr><?php }?>
<?php if($r['kind']==='settlement'){$b=$d['balance_at_approval']??$d['balance_snapshot'];$due=isset($d['balance_at_approval'])?-$b:-$b+$r['amount'];?><tr><th>مانده مطالبات با احتساب این تسویه (ریال)</th><td><?php echo number_format($due);?></td></tr><?php } ?>
<?php if(isset($d['work_snapshot'])){foreach(['days'=>'روزهای کارکرد تأییدشده','worked_minutes'=>'دقایق کارکرد عادی','overtime_minutes'=>'دقایق اضافه‌کاری','paid_leave_minutes'=>'دقایق مرخصی با حقوق','unpaid_leave_minutes'=>'دقایق مرخصی بدون حقوق'] as $key=>$label){?><tr><th><?php echo esc_html($label);?></th><td><?php echo number_format($d['work_snapshot'][$key]);?></td></tr><?php }}?>
</tbody></table>
<p>محل امضای تنظیم‌کننده: ………………………… &nbsp; تأیید مدیریت: …………………………</p>
<p>امضای پرسنل: …………………………</p>
<?php if(in_array($r['kind'],['payslip','settlement'],TRUE)){?><p>این برگه به‌تنهایی رسید پرداخت نیست؛ پرداخت‌ها و وصول چک در حسابداری پرونده ثبت می‌شوند.</p><?php } ?>
</body></html>
