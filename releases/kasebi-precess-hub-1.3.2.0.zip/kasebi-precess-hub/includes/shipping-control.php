<?php
if(!defined('ABSPATH')){exit;}
require_once __DIR__.'/../Core/kph_shipping_control.php';
add_action('init',function(){
    if(kph_shipping_control::allowed()&&get_option('kph_shipping_control_schema')!=='1'){
        try{(new kph_shipping_control())->install();update_option('kph_shipping_control_schema','1',FALSE);}catch(Throwable $e){}
    }
},35);
add_action('wp_print_scripts',function(){if(kph_shipping_control::allowed()&&wp_script_is('kasebi_clinic_script','enqueued')){wp_enqueue_script('kph-shipping-control',KPH_ASSETS_URL.'js/shipping-control.js',['kasebi_clinic_script'],KPH_VER,TRUE);}},20);
function kph_shipping_url(array $params=[]):string{return add_query_arg($params,home_url('/crm/shipping-control'));}
function kph_shipping_ajax():void{
    $nonce=$_POST['nonce']??'';
    if(!kph_shipping_control::allowed()||!is_string($nonce)||!wp_verify_nonce($nonce,'kph_shipping_control')){wp_send_json(['status'=>'error','message'=>'اجازه دسترسی یا اعتبار فرم کافی نیست.'],403);}
    try{$service=new kph_shipping_control();$input=wp_unslash($_POST);$op=sanitize_key($input['operation']??'');$result=[];
        if($op==='settings'){$service->save_setting($input);}
        elseif($op==='customers'){$result=$service->customers(is_string($input['term']??'')?($input['term']??''):'',max(1,absint($input['page']??1)));}
        elseif($op==='orders'){$result=$service->orders(absint($input['customer_id']??0),is_string($input['term']??'')?($input['term']??''):'',max(1,absint($input['page']??1)));}
        elseif($op==='save'){$result=['id'=>$service->save($input)];}
        elseif($op==='receipt'){$result=['id'=>$service->receipt($input)];}
        elseif($op==='cancel'){$service->cancel(absint($input['record_id']??0),absint($input['version']??0),is_string($input['reason']??'')?$input['reason']:'');}
        else{throw new RuntimeException('عملیات معتبر نیست.');}
    }catch(Throwable $e){wp_send_json(['status'=>'error','message'=>$e instanceof RuntimeException?$e->getMessage():'ثبت اطلاعات ناموفق بود؛ صفحه را تازه کنید.'],400);return;}
    wp_send_json(['status'=>'success','message'=>'اطلاعات با موفقیت ثبت شد.','data'=>$result]);
}
add_action('wp_ajax_kph_shipping_control','kph_shipping_ajax');
add_action('nooshika_ajax_kph_shipping_control','kph_shipping_ajax');
function kph_shipping_field(string $name,array $def,$value='',string $context='editor'):void{
    [$label,$type]=$def;$id='kph_sc_'.$context.'_'.$name;$value=$value??'';
    echo '<div class="col-md-6"><div class="form-group"><label class="form-label" for="'.esc_attr($id).'">'.esc_html($label).'</label><div class="form-control-wrap">';
    if($type==='select'){echo '<select class="form-select" id="'.esc_attr($id).'" name="'.esc_attr($name).'">';foreach($def[2] as $key=>$text){echo '<option value="'.esc_attr($key).'"'.selected((string)$value,(string)$key,FALSE).'>'.esc_html($text).'</option>';}echo '</select>';}
    elseif($type==='textarea'){echo '<textarea class="form-control" rows="3" id="'.esc_attr($id).'" name="'.esc_attr($name).'">'.esc_textarea($value).'</textarea>';}
    else{$date=$type==='date';if($date&&$value!==''){$value=kph_hr_exports::date((string)$value);}echo '<input class="form-control'.($date?' datepicker':'').'" id="'.esc_attr($id).'" name="'.esc_attr($name).'" type="'.($type==='number'?'number':'text').'" value="'.esc_attr($value).'"'.($date?' data-kph-hr-date="1"':'').($type==='number'?' min="0" step="1"':'').'>';}
    echo '</div></div></div>';
}
