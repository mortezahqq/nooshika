<?php
if (!defined('ABSPATH')) { exit; }

require_once __DIR__.'/kph_hr_calendar.php';
require_once __DIR__.'/kph_hr_payslip_layout.php';

/** One document model feeds HTML print, PDF and real OOXML Word output. */
class kph_hr_exports {
    use kph_hr_payslip_layout;
    public static function digits($value): string { return strtr((string)$value,array_combine(str_split('0123456789'),preg_split('//u','۰۱۲۳۴۵۶۷۸۹',-1,PREG_SPLIT_NO_EMPTY))); }
    public static function date(string $date): string {
        if(!$date){return '................';}
        try{return self::digits(kph_hr_calendar::display($date));}
        catch(RuntimeException $e){return self::digits($date);}
    }
    public static function end_date(?string $date): string {return $date?self::date($date):'بدون تاریخ پایان';}
    private static function money($value): string { return self::digits(number_format((float)$value)); }
    private static function quantity($value): string { return self::digits(rtrim(rtrim(number_format((float)$value,4,'.',''),'0'),'.')); }
    private static function fill($value): string { return trim((string)$value)!==''?self::digits($value):'................'; }
    private static function c(string $text,int $span=1,bool $bold=FALSE,string $align='right'): array { return ['text'=>$text,'span'=>$span,'bold'=>$bold,'align'=>$align]; }
    private static function table(array $rows,array $widths=[50,50],bool $border=TRUE): array { return ['type'=>'table','rows'=>$rows,'widths'=>$widths,'border'=>$border]; }
    private static function paragraph(string $text,string $align='right',bool $bold=FALSE): array { return ['type'=>'paragraph','text'=>$text,'align'=>$align,'bold'=>$bold]; }
    private static function month(string $period): string {
        $p=explode('/',str_replace('-','/',nooshika_sanitize_numbers($period)));$months=['','فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور','مهر','آبان','آذر','دی','بهمن','اسفند'];
        return count($p)===2&&isset($months[(int)$p[1]])?$months[(int)$p[1]].' '.self::digits($p[0]):self::digits($period);
    }
    public static function model(kph_hr $hr,int $employee,int $record): array {
        $r=$hr->record($record,$employee);$profile=$hr->profile($employee);$d=$r['data'];
        if (!in_array($r['kind'],['contract','payslip','settlement'],TRUE)) { throw new RuntimeException('خروجی Word و PDF این بخش برای قرارداد، فیش و تسویه‌حساب است.'); }
        $person=$d['person']??$hr->person_form_defaults($employee);$employer=$d['employer']??[];
        $doc=['title'=>$d['title']?:kph_hr::kinds()[$r['kind']],'record_id'=>$record,'employee_id'=>$employee,'kind'=>$r['kind'],'status'=>$r['status'],'blocks'=>[]];
        if ($r['kind']==='contract') { $doc['blocks']=self::contract($r,$person,$employer); }
        elseif ($r['kind']==='payslip') { $doc['blocks']=self::payslip($r,$person,$employer);$doc['paper']='A5';$doc['logo']=self::payslip_logo(); }
        else { $doc['blocks']=self::settlement($r,$person,$employer); }
        if ($r['kind']!=='payslip'&&!in_array($r['status'],['approved','posted','cleared'],TRUE)) { array_unshift($doc['blocks'],self::paragraph($r['status']==='draft'?'پیش‌نویس — برای بررسی و امضا':'وضعیت سند: '.(kph_hr::statuses()[$r['status']]??$r['status']),'center',TRUE)); }
        return $doc;
    }
    private static function contract(array $r,array $p,array $e): array {
        $d=$r['data'];$defaults=kph_hr::contract_defaults();$rows=[];
        $full=static function($text,$bold=FALSE)use(&$rows){$rows[]=[self::c($text,2,$bold)];};
        $full($d['title']?:'قرارداد کار موقت',TRUE);$full('این قرارداد در مورخ '.self::date($d['contract_date']??$r['created_at']).' با شرایط زیر منعقد می‌شود:');
        $full('طرفین قرارداد',TRUE);
        $rows[]=[self::c('کارفرما: '.self::fill($e['employer_name']??'')),self::c('کد ملی / شناسه ملی: '.self::fill($e['employer_national_id']??''))];
        $rows[]=[self::c('نام کارگاه / شرکت: '.self::fill($e['company_name']??'')),self::c('نشانی: '.self::fill($e['employer_address']??''))];
        $rows[]=[self::c('تلفن کارفرما: '.self::fill($e['employer_phone']??'')),self::c('شماره ثبت: '.self::fill($e['company_registration']??''))];
        $rows[]=[self::c('پرسنل: '.self::fill($p['person_name']??'')),self::c('کد ملی: '.self::fill($p['person_national_id']??''))];
        if (!empty($p['person_father_name'])||!empty($p['person_identity_no'])) { $rows[]=[self::c('نام پدر: '.self::fill($p['person_father_name']??'')),self::c('شماره شناسنامه: '.self::fill($p['person_identity_no']??''))]; }
        if (!empty($p['person_birth_date'])||!empty($p['person_issue_place'])) { $rows[]=[self::c('تاریخ تولد: '.self::date($p['person_birth_date']??'')),self::c('محل صدور: '.self::fill($p['person_issue_place']??''))]; }
        $rows[]=[self::c('نشانی پرسنل: '.self::fill($p['person_address']??'')),self::c('تلفن: '.self::fill($p['person_phone']??''))];
        $rows[]=[self::c('عنوان شغلی: '.self::fill($d['job_title']??$p['person_job_title']??'')),self::c('محل انجام کار: '.self::fill($e['workplace_address']??''))];
        $full('شرح وظایف',TRUE);$full($d['duties']??$defaults['duties']);
        $full('مدت قرارداد کار',TRUE);$full('این قرارداد از تاریخ '.self::date($r['date_from']).' شروع می‌شود. '.($r['date_to']?'تاریخ پایان قرارداد: '.self::date($r['date_to']).'. شرایط تمدید با توافق طرفین تعیین می‌شود.':'تاریخ پایان قرارداد تعیین نشده است.'));
        $full('حقوق و مزایا',TRUE);
        $basis=['monthly'=>'ماهانه','daily'=>'روزانه','hourly'=>'ساعتی'][$d['basis']??'monthly']??'ماهانه';
        $full('مزد '.$basis.' (ریال): '.self::money($d['rate']??$r['amount']));
        $lines=[];foreach(['housing'=>'حق مسکن','food_allowance'=>'بن کارگری','marriage_allowance'=>'حق تأهل','child_allowance'=>'حق اولاد','seniority_base'=>'پایه سنوات'] as $key=>$label){if(!empty($d[$key])){$lines[]=$label.': '.self::money($d[$key]).' ریال';}}
        if(array_key_exists('seniority_daily_rate',$d)){$lines[]='پایه سنوات تجمیعی روزانه: '.self::money($d['seniority_daily_rate']).' ریال';}
        $benefits=($lines?implode(' — ',$lines)."\n":'').($d['benefits_text']??$defaults['benefits_text'])."\n".($d['insurance_tax_text']??$defaults['insurance_tax_text']);$full($benefits);
        $full('ساعات کار',TRUE);$full($d['working_hours_text']??$defaults['working_hours_text']);
        $full('خاتمه و فسخ قرارداد کار',TRUE);$full($d['termination_terms']??$defaults['termination_terms']);
        $full('سایر شرایط',TRUE);$full(implode("\n",array_filter([$d['other_conditions']??$defaults['other_conditions'],$d['terms']??'',$d['public_notes']??''])));
        $rows[]=[self::c("امضا و مهر کارفرما\n\n................",1,FALSE,'center'),self::c("امضای پرسنل\n\n................",1,FALSE,'center')];
        return [self::table($rows)];
    }
    private static function settlement(array $r,array $p,array $e): array {
        $d=$r['data'];$template=$d['template']??'final';$blocks=[];
        foreach($template==='combined'?['general','final']:[$template] as $page=>$model){
            if($page){$blocks[]=['type'=>'pagebreak'];}
            $blocks[]=self::paragraph('بسمه تعالی','center',TRUE);
            $titles=['benefits'=>'فرم تسویه مزایای اشتغال','general'=>'فرم تسویه حساب','final'=>'فرم تسویه حساب پایان قرارداد','monthly'=>'فرم تسویه حساب ماهیانه'];
            $blocks[]=self::paragraph($titles[$model]??$r['data']['title'],'center',TRUE);
            $name=self::fill($p['person_name']??'');$national=self::fill($p['person_national_id']??'');$company=self::fill($e['company_name']??'');$job=self::fill($p['person_job_title']??'');
            $amount=(int)($d['receipt_total']??$r['amount']);$money=self::money($amount).' ریال'.(!empty($d['receipt_amount_words'])?' ('.$d['receipt_amount_words'].')':'');
            if($model==='benefits'){
                $blocks[]=self::paragraph('اینجانب '.$name.' به شماره ملی '.$national.' مبلغ '.$money.' را بابت مزایای اشتغال، '.self::quantity($d['benefit_months']??0).' ماه جدای از حقوق و مزایای قانونی و مشمول قوانین و مقررات قانون کار از کارفرمای خود شرکت '.$company.' دریافت نمودم.');
                $blocks[]=self::paragraph($d['declaration_text']??'بدینوسیله با امضا و اثر انگشت خود دریافت وجه فوق را اقرار و اعلام می‌نمایم.');
            }elseif($model==='monthly'){
                $period=$d['settlement_period']??'';
                $blocks[]=self::paragraph('اینجانب '.$name.' فرزند '.self::fill($p['person_father_name']??'').' با علم و آگاهی از حق و حقوق خود بابت اشتغال ماه '.($period?self::month($period):self::date($r['date_from'])).'، موارد زیر را از کارفرمای خود آقا/خانم '.self::fill($e['employer_name']??'').' مدیریت شرکت '.$company.' دریافت نمودم.');
                $rows=[];foreach(['child_allowance'=>'حق اولاد','food_allowance'=>'بن کارگری','housing'=>'حق مسکن','base_salary'=>'حقوق','overtime_amount'=>'اضافه‌کاری','seniority_base'=>'پایه سنوات','severance'=>'سنوات کارکرد','annual_bonus'=>'عیدی و پاداش','leave_cash'=>'بازخرید مرخصی','other_due'=>'سایر مطالبات','insurance'=>'کسر بابت بیمه','tax'=>'کسر بابت مالیات','deductions'=>'سایر کسورات'] as $key=>$label){$rows[]=[self::c($label),self::c(self::money($d[$key]??0).' ریال')];}
                $rows[]=[self::c('مبلغ دریافتی',1,TRUE),self::c($money,1,TRUE)];$blocks[]=self::table($rows,[65,35],FALSE);
                if(!empty($d['declaration_text'])){$blocks[]=self::paragraph($d['declaration_text']);}
            }else{
                $identity='اینجانب '.$name.' فرزند '.self::fill($p['person_father_name']??'').' دارای شماره شناسنامه '.self::fill($p['person_identity_no']??'').' متولد '.self::date($p['person_birth_date']??'').' در '.self::fill($p['person_birth_place']??'').'، صادره از '.self::fill($p['person_issue_place']??'').' به شماره ملی '.$national;
                $blocks[]=self::paragraph($identity.' در صحت و سلامت اقرار می‌نمایم که بابت فعالیت و کارکرد خود به عنوان '.$job.' در شرکت / مؤسسه '.$company.'، حق و حقوق خود را به شرح این فرم تسویه نموده‌ام.');
                if($model==='final'){
                    $rows=[[self::c('شرح',1,TRUE),self::c('مقدار / روز',1,TRUE),self::c('مبلغ (ریال)',1,TRUE)]];
                    foreach(['base_salary'=>['حقوق مبنا مطابق کارکرد',''],'housing'=>['کمک هزینه مسکن',''],'food_allowance'=>['بن کارگری',''],'leave_cash'=>['مرخصی‌های ذخیره‌شده','leave_days'],'severance'=>['سنوات کارکرد','seniority_days'],'annual_bonus'=>['عیدی و پاداش کارکرد','bonus_days'],'child_allowance'=>['حق اولاد','child_count'],'overtime_amount'=>['اضافه‌کاری',''],'seniority_base'=>['پایه سنوات ماهانه',''],'insurance'=>['کسر بیمه',''],'tax'=>['کسر مالیات',''],'other_due'=>['سایر مطالبات',''],'deductions'=>['کسورات','']] as $key=>[$label,$count]){
                        $rows[]=[self::c($label),self::c($count?self::quantity($d[$count]??0):'—'),self::c(self::money($d[$key]??0))];
                    }
                    $rows[]=[self::c('جمع دریافتی',2,TRUE),self::c($money,1,TRUE)];$blocks[]=self::table($rows,[50,20,30],FALSE);
                }else{
                    $blocks[]=self::paragraph('موارد تسویه شامل حقوق مبنا، مزایای ثابت و به تبع شغل، کمک هزینه مسکن و خواروبار، کمک عائله‌مندی، مأموریت و ایاب‌وذهاب، اضافه‌کاری، مرخصی ذخیره‌شده و سنوات کارکرد مطابق مبالغ و بازهٔ ثبت‌شده است.');
                }
                $blocks[]=self::paragraph('بابت فعالیت از تاریخ '.self::date($r['date_from']).' لغایت '.self::date($r['date_to']).' مبلغ '.$money.' از کارفرمای خود دریافت نمودم.');
                $blocks[]=self::paragraph('بازهٔ سنوات کارکرد: از '.self::date($d['seniority_from']??$r['date_from']).' تا '.self::date($d['seniority_to']??$r['date_to']).'.');
                $payments=[];
                if(!empty($d['paid_cash'])){$payments[]='نقد: '.self::money($d['paid_cash']).' ریال';}
                if(!empty($d['paid_cheque'])){$payments[]='چک شماره '.self::fill($d['cheque_no']??'').' بانک '.self::fill($d['cheque_bank']??'').' به تاریخ '.self::date($d['cheque_date']??'').' مبلغ '.self::money($d['paid_cheque']).' ریال';}
                if(!empty($d['paid_transfer'])){$payments[]='حواله: '.self::money($d['paid_transfer']).' ریال؛ پیگیری '.self::fill($d['transfer_tracking']??'');}
                $blocks[]=self::paragraph('تاریخ دریافت / تسویه: '.self::date($d['receipt_date']??'').($payments?"\n".implode("\n",$payments):"\nنحوه پرداخت: ................"));
                if(!empty($d['case_no'])){$blocks[]=self::paragraph('بابت رأی / کلاسه پرونده: '.self::fill($d['case_no']));}
                $blocks[]=self::paragraph($d['declaration_text']??kph_hr::settlement_declaration());
            }
            if(!empty($d['public_notes'])){$blocks[]=self::paragraph($d['public_notes']);}
            $signatures=in_array($model,['benefits','monthly'],TRUE)?[self::c("امضا و اثر انگشت پرسنل\n\n\n................",1,FALSE,'center')]:[self::c("امضا و اثر انگشت پرسنل\n\n\n................",1,FALSE,'center'),self::c("امضا و اثر انگشت شاهد\n\n\n................",1,FALSE,'center'),self::c("امضا و مهر کارفرما\n\n\n................",1,FALSE,'center')];
            $blocks[]=self::table([$signatures],array_fill(0,count($signatures),100/count($signatures)),FALSE);
        }
        return $blocks;
    }
    private static function html_text(string $text): string { return nl2br(htmlspecialchars($text,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8'),FALSE); }
    public static function body(array $doc): string {
        if(($doc['paper']??'')==='A5'&&$doc['kind']==='payslip'){return self::payslip_body($doc);}
        $html='';
        foreach($doc['blocks'] as $block){
            if($block['type']==='pagebreak'){$html.='<br pagebreak="true" /><div class="page-break"></div>';continue;}
            if($block['type']==='paragraph'){$html.='<p align="'.$block['align'].'" style="text-align:'.$block['align'].';'.($block['bold']?'font-weight:bold;':'').'">'.self::html_text($block['text']).'</p>';continue;}
            $html.='<table dir="rtl" width="100%" border="'.($block['border']?'1':'0').'" cellpadding="5" cellspacing="0" style="border-collapse:collapse;">';
            foreach($block['rows'] as $row){$html.='<tr>'; $column=0;foreach($row as $cell){$width=array_sum(array_slice($block['widths'],$column,$cell['span']));$column+=$cell['span'];$html.='<td width="'.$width.'%" colspan="'.$cell['span'].'" align="'.$cell['align'].'" style="text-align:'.$cell['align'].';vertical-align:top;'.($cell['bold']?'font-weight:bold;':'').'">'.self::html_text($cell['text']).'</td>';}$html.='</tr>';}
            $html.='</table><p style="font-size:2pt;"> </p>';
        }
        return $html;
    }
    public static function html(array $doc): string {
        if(($doc['paper']??'')==='A5'&&$doc['kind']==='payslip'){return self::payslip_html($doc);}
        return '<!doctype html><html lang="fa" dir="rtl"><head><meta charset="UTF-8"><title>'.htmlspecialchars($doc['title'],ENT_QUOTES,'UTF-8').'</title><style>@page{size:A4;margin:12mm}body{font-family:Tahoma,Arial,sans-serif;direction:rtl;color:#111;font-size:11px;line-height:1.8}table{width:100%;border-collapse:collapse;table-layout:fixed}td{padding:6px;overflow-wrap:anywhere;vertical-align:top}p{margin:9px 0;white-space:normal}tr{break-inside:avoid}.page-break{break-before:page}.print-controls{margin-bottom:16px;display:flex;gap:12px}.print-controls a,.print-controls button{padding:7px 12px}@media print{.print-controls{display:none}body{margin:0}}</style></head><body>'.self::body($doc).'</body></html>';
    }
    public static function pdf(array $doc): string {
        if(($doc['paper']??'')==='A5'&&$doc['kind']==='payslip'){return self::payslip_pdf($doc);}
        if (!class_exists('TCPDF')) { require_once __DIR__.'/../vendor/tcpdf/tcpdf.php'; }
        $pdf=new TCPDF('P','mm','A4',TRUE,'UTF-8',FALSE);$pdf->setPrintHeader(FALSE);$pdf->setPrintFooter(FALSE);$pdf->SetCreator('Kasebi Process Hub');$pdf->SetTitle($doc['title']);$pdf->SetMargins(12,12,12);$pdf->SetAutoPageBreak(TRUE,12);$pdf->setRTL(TRUE);
        $fonts=__DIR__.'/../vendor/tcpdf/fonts/';$pdf->AddFont('dejavusans','',$fonts.'dejavusans.php',TRUE);$pdf->AddFont('dejavusans','B',$fonts.'dejavusansb.php',TRUE);$pdf->SetFont('dejavusans','',9);$pdf->setCellHeightRatio(1.65);$pdf->AddPage();
        // HTML consists only of escaped local text and fixed tables: no images, links or remote resources.
        $pdf->writeHTML(self::body($doc),TRUE,FALSE,TRUE,FALSE,'');return $pdf->Output('hr-'.$doc['kind'].'-'.$doc['record_id'].'.pdf','S');
    }
    private static function xml(string $text): string { $text=preg_replace('/[^\x{9}\x{A}\x{D}\x{20}-\x{D7FF}\x{E000}-\x{FFFD}\x{10000}-\x{10FFFF}]/u','',$text)??'';return htmlspecialchars($text,ENT_QUOTES|ENT_XML1|ENT_SUBSTITUTE,'UTF-8'); }
    private static function word_paragraph(string $text,string $align='right',bool $bold=FALSE,bool $compact=FALSE,int $fontSize=0): string {
        $font=$compact?'Vazirmatn':'Arial';$size=$fontSize?:($compact?19:21);$space=$compact?0:45;$leading=$compact?250:300;
        $runs='';foreach(explode("\n",$text) as $i=>$line){if($i){$runs.='<w:r><w:br/></w:r>';}$runs.='<w:r><w:rPr><w:rFonts w:ascii="'.$font.'" w:hAnsi="'.$font.'" w:cs="'.$font.'"/><w:rtl/><w:sz w:val="'.$size.'"/><w:szCs w:val="'.$size.'"/>'.($bold?'<w:b/><w:bCs/>':'').'</w:rPr><w:t xml:space="preserve">'.self::xml($line).'</w:t></w:r>';}
        return '<w:p><w:pPr><w:bidi/><w:jc w:val="'.$align.'"/><w:spacing w:before="'.$space.'" w:after="'.$space.'" w:line="'.$leading.'" w:lineRule="'.($compact?'exact':'auto').'"/></w:pPr>'.$runs.'</w:p>';
    }
    public static function docx(array $doc): string {
        $compact=($doc['paper']??'')==='A5'&&$doc['kind']==='payslip';$tableWidth=$compact?7483:10516;$tableScale=$tableWidth/100;$logo=$compact?($doc['logo']??NULL):NULL;
        $paragraph=static fn($text,$align='right',$bold=FALSE)=>self::word_paragraph($text,$align,$bold,$compact);$content='';
        foreach($doc['blocks'] as $block){
            if($block['type']==='letterhead'){$content.=self::payslip_word_header($block,$logo,$tableWidth,$paragraph);continue;}
            if($block['type']==='pagebreak'){$content.='<w:p><w:r><w:br w:type="page"/></w:r></w:p>';continue;}
            if($block['type']==='paragraph'){$content.=$paragraph($block['text'],$block['align'],$block['bold']);continue;}
            $border=$block['border']?'single':'nil';$content.='<w:tbl><w:tblPr><w:bidiVisual/><w:tblW w:w="'.$tableWidth.'" w:type="dxa"/><w:tblLayout w:type="fixed"/><w:tblBorders>';
            foreach(['top','left','bottom','right','insideH','insideV'] as $side){$content.='<w:'.$side.' w:val="'.$border.'" w:sz="5" w:color="'.($compact?'B9C4CF':'777777').'"/>';}
            $content.='</w:tblBorders><w:tblCellMar><w:top w:w="'.($compact?'0':'55').'" w:type="dxa"/><w:bottom w:w="'.($compact?'0':'55').'" w:type="dxa"/><w:left w:w="65" w:type="dxa"/><w:right w:w="65" w:type="dxa"/></w:tblCellMar></w:tblPr><w:tblGrid>';
            foreach($block['widths'] as $width){$content.='<w:gridCol w:w="'.(int)round($width*$tableScale).'"/>';}$content.='</w:tblGrid>';
            foreach($block['rows'] as $rowIndex=>$row){$content.='<w:tr><w:trPr><w:cantSplit/>'.($compact?'<w:trHeight w:val="'.(int)round(($block['row_height']??6)*56.6929).'" w:hRule="atLeast"/>':'').'</w:trPr>';$shade=($block['role']??'')==='net'?'E5EDF5':((($block['role']??'')==='earnings'&&($rowIndex===0||$rowIndex===count($block['rows'])-1))?'EDF1F5':((($block['role']??'')==='earnings'&&$rowIndex%2===0)?'F8FAFB':'FFFFFF'));$column=0;foreach($row as $cell){$width=array_sum(array_slice($block['widths'],$column,$cell['span']));$column+=$cell['span'];$content.='<w:tc><w:tcPr><w:tcW w:w="'.(int)round($width*$tableScale).'" w:type="dxa"/><w:gridSpan w:val="'.$cell['span'].'"/><w:vAlign w:val="'.($compact?'center':'top').'"/>'.($compact?'<w:shd w:val="clear" w:fill="'.$shade.'"/>':'').'</w:tcPr>'.self::word_paragraph($cell['text'],$cell['align'],$cell['bold'],$compact,($compact&&($block['role']??'')==='work')?17:0).'</w:tc>';}$content.='</w:tr>';}$content.='</w:tbl>'.($compact?'<w:p><w:pPr><w:spacing w:before="0" w:after="0" w:line="20" w:lineRule="exact"/></w:pPr></w:p>':$paragraph(''));
        }
        $xml='<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
        $files=[
            '[Content_Types].xml'=>$xml.'<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/></Types>',
            '_rels/.rels'=>$xml.'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>',
            'word/document.xml'=>$xml.'<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>'.$content.'<w:sectPr><w:pgSz w:w="'.($compact?'8391':'11906').'" w:h="'.($compact?'11906':'16838').'"/><w:pgMar w:top="'.($compact?'454':'680').'" w:right="'.($compact?'454':'695').'" w:bottom="'.($compact?'454':'680').'" w:left="'.($compact?'454':'695').'"/><w:bidi/></w:sectPr></w:body></w:document>',
            'word/styles.xml'=>$xml.'<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial" w:cs="Arial"/><w:lang w:val="fa-IR" w:bidi="fa-IR"/></w:rPr></w:rPrDefault></w:docDefaults></w:styles>',
            'word/_rels/document.xml.rels'=>$xml.'<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rIdStyles" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>',
        ];
        if($logo){$extension=$logo['mime']==='image/png'?'png':'jpg';$files['word/media/company-logo.'.$extension]=$logo['bytes'];$files['[Content_Types].xml']=str_replace('</Types>','<Default Extension="'.$extension.'" ContentType="'.$logo['mime'].'"/></Types>',$files['[Content_Types].xml']);$files['word/_rels/document.xml.rels']=str_replace('</Relationships>','<Relationship Id="rIdCompanyLogo" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/company-logo.'.$extension.'"/></Relationships>',$files['word/_rels/document.xml.rels']);}
        if($compact){$files=self::payslip_word_fonts($files);}
        return self::zip($files);
    }
    /** A small standards-compliant ZIP writer avoids a server dependency on ZipArchive. */
    private static function zip(array $files): string {
        $body='';$directory='';$offset=0;$count=0;
        foreach($files as $name=>$bytes){$packed=function_exists('gzdeflate')?gzdeflate($bytes,6):$bytes;$method=function_exists('gzdeflate')?8:0;$crc=hexdec(hash('crc32b',$bytes));$size=strlen($bytes);$compressed=strlen($packed);$nameLength=strlen($name);
            $header=pack('VvvvvvVVVvv',0x04034b50,20,0,$method,0,33,$crc,$compressed,$size,$nameLength,0).$name;$body.=$header.$packed;
            $directory.=pack('VvvvvvvVVVvvvvvVV',0x02014b50,20,20,0,$method,0,33,$crc,$compressed,$size,$nameLength,0,0,0,0,0,$offset).$name;$offset+=strlen($header)+$compressed;$count++;
        }
        return $body.$directory.pack('VvvvvVVv',0x06054b50,0,0,$count,$count,strlen($directory),strlen($body),0);
    }
}
