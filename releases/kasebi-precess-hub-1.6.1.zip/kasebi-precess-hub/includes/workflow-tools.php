<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

// Administrator maintenance remains separate from the restored saloon interface.
add_action( 'admin_menu', function() {
	add_management_page( 'ابزارهای کاسبی', 'ابزارهای کاسبی', 'manage_options', 'kph-workflow-tools', function() {
		echo '<div class="wrap"><h1>ابزارهای کاسبی</h1>';
		echo kph_get_template( 'components/workflow-tools.php', [ 'DB' => new kph_db() ] );
		echo '</div>';
	} );
} );

add_action( 'admin_post_kph_workflow_maintenance', function() {
	if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'دسترسی مجاز نیست.', '', [ 'response' => 403 ] ); }
	check_admin_referer( 'kph_workflow_maintenance' );
	$DB = new kph_db();
	$operation = sanitize_key( $_POST['operation'] ?? '' );
	$weight = isset( $_POST['weight_per_item_gram'] ) && is_scalar( $_POST['weight_per_item_gram'] ) ? (float) nooshika_sanitize_numbers( (string) $_POST['weight_per_item_gram'] ) / 1000 : NULL;
	if ( $operation === 'repair' && (string) ( $_POST['confirm_repair'] ?? '' ) !== '1' ) { wp_die( 'ابتدا محصول و وزن اصلاح را تأیید کنید.', '', [ 'response' => 400 ] ); }
	$result = $operation === 'prepare' ? $DB->prepare_workflow_storage() : ( $operation === 'repair' ? $DB->repair_incomplete_conversion( absint( $_POST['conversion_id'] ?? 0 ), $weight ) : [ 'status' => 'error', 'message' => 'عملیات نامعتبر است.' ] );
	wp_die( esc_html( $result['message'] ) . '<p><a href="' . esc_url( admin_url( 'tools.php?page=kph-workflow-tools' ) ) . '">بازگشت به ابزارها</a></p>', 'ابزارهای کاسبی', [ 'response' => $result['status'] === 'success' ? 200 : 400, 'back_link' => TRUE ] );
} );
