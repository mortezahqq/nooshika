<?php
if(!defined('ABSPATH')||!current_user_can('manage_options')){return;}
$DB=isset($DB)?$DB:new kph_db();$ready=$DB->workflow_storage_ready();
?>
<div class="card"><h2>آماده‌سازی ثبت یکپارچه</h2><p><?php echo $ready?'ثبت یکپارچه آماده است.':'برای ثبت و ویرایش یکپارچه، مدیر باید جدول‌های مرتبط را آماده کند.';?></p><p>قبل از آماده‌سازی از دیتابیس پشتیبان بگیرید. این ابزار ساختار ثبت را آماده می‌کند؛ شناسه‌ها، موجودی و سوابق حفظ می‌شوند.</p><form method="post" action="<?php echo esc_url(admin_url('admin-post.php'));?>"><input type="hidden" name="action" value="kph_workflow_maintenance"><input type="hidden" name="operation" value="prepare"><?php wp_nonce_field('kph_workflow_maintenance');?><button type="submit" class="button button-primary">آماده‌سازی ثبت یکپارچه</button></form></div>
