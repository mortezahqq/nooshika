<?php
if ( ! defined('ABSPATH') ) { exit; }
require_once __DIR__ . '/../Core/kph_hr.php';
require_once __DIR__.'/../Core/kph_hr_exports.php';
require_once __DIR__.'/hr-form-fields.php';

function kph_hr_fields( string $kind ): array {
    if(in_array($kind,['contract','payslip','settlement'],TRUE)){return kph_hr_flat_form_fields($kind);}
    $common=['title'=>['عنوان','text'],'date_from'=>['از تاریخ','date'],'date_to'=>['تا تاریخ','date'],'notes'=>['یادداشت پرونده','textarea']];
    $extra=[
        'contract'=>['job_title'=>['سمت','text'],'basis'=>['روش حقوق','select',['monthly'=>'ماهانه','daily'=>'روزانه','hourly'=>'ساعتی']],'rate'=>['حقوق پایه / نرخ (ریال)','number'],'normal_days'=>['روزهای مبنا در ماه','number'],'overtime_rate'=>['نرخ هر ساعت اضافه‌کاری (ریال)','number'],'terms'=>['شرایط قرارداد','textarea']],
        'leave'=>['leave_type'=>['نوع مرخصی','select',['paid'=>'استحقاقی با حقوق','unpaid'=>'بدون حقوق','sick'=>'استعلاجی']],'leave_year'=>['سال سهمیه مانند ۱۴۰۵','text'],'minutes'=>['مدت مرخصی (دقیقه)','number'],'reason'=>['علت مرخصی','textarea']],
        'attendance'=>['worked_minutes'=>['کارکرد عادی (دقیقه)','number'],'overtime_minutes'=>['اضافه‌کاری (دقیقه)','number'],'late_minutes'=>['تأخیر (دقیقه)','number']],
        'payslip'=>['period'=>['دوره فیش مانند ۱۴۰۵/۰۷','text'],'contract_id'=>['قرارداد تأییدشده','contract'],'paid_days'=>['روزهای پرداخت حقوق','number'],'benefits'=>['مزایا (ریال)','number'],'bonus'=>['پاداش (ریال)','number'],'insurance'=>['بیمه سهم پرسنل (ریال)','number'],'tax'=>['مالیات (ریال)','number'],'deductions'=>['سایر کسورات (ریال)','number']],
        'settlement'=>['severance'=>['سنوات جدید (ریال)','number'],'annual_bonus'=>['عیدی جدید (ریال)','number'],'leave_cash'=>['بازخرید مرخصی (ریال)','number'],'other_due'=>['سایر مطالبات جدید (ریال)','number'],'deductions'=>['کسورات این تسویه (ریال)','number']],
        'payment'=>['amount'=>['مبلغ (ریال)','number'],'payment_method'=>['روش پرداخت','select',['cash'=>'نقدی','pos'=>'کارت‌خوان','card_to_card'=>'کارت به کارت','online'=>'آنلاین','other'=>'سایر']]],
        'transfer'=>['amount'=>['مبلغ (ریال)','number'],'bank_name'=>['نام بانک','text'],'tracking_no'=>['شماره پیگیری','text']],
        'cheque'=>['amount'=>['مبلغ (ریال)','number'],'bank_name'=>['بانک صادرکننده','text'],'cheque_no'=>['شماره چک','text'],'sayad_id'=>['شناسه صیادی','text'],'due_date'=>['تاریخ سررسید','date']],
    ][$kind]??[];
    if(in_array($kind,['payment','transfer','cheque'],TRUE)){
        $extra+=['account_id'=>['حساب پرداخت مجموعه','account'],'purpose'=>['بابت','select',['salary'=>'حقوق','advance'=>'مساعده','settlement'=>'تسویه','other'=>'سایر']],'related_id'=>['شماره فیش یا تسویه مرتبط (اختیاری)','number']];
    }
    return $common+$extra;
}
function kph_hr_form_field(string $name,array $def,$value=''):void{
    [$label,$type]=$def;$id='kph_hr_'.$name;
    echo '<div class="col-md-6"><div class="form-group"><label class="form-label" for="'.esc_attr($id).'">'.esc_html($label).'</label><div class="form-control-wrap">';
    if($type==='textarea'){echo '<textarea class="form-control" id="'.esc_attr($id).'" name="'.esc_attr($name).'" rows="3">'.esc_textarea($value).'</textarea>';}
    elseif($type==='select'){
        echo '<select class="form-select" id="'.esc_attr($id).'" name="'.esc_attr($name).'">';
        foreach($def[2] as $key=>$text){echo '<option value="'.esc_attr($key).'"'.selected((string)$value,(string)$key,FALSE).'>'.esc_html($text).'</option>';}
        echo '</select>';
    }else{
        $date=$type==='date';
        if($date&&$value){$value=kph_hr_exports::date((string)$value);}
        echo '<input class="form-control'.($date?' datepicker':'').'" id="'.esc_attr($id).'" name="'.esc_attr($name).'" type="'.($type==='number'?'number':'text').'" value="'.esc_attr($value).'"'.($date?' data-kph-hr-date="1"':'').($type==='number'?' min="0" step="0.0001"':'').'>';
    }
    echo '</div></div></div>';
}
function kph_hr_audit_changes(array $before,array $after):array{
    foreach(['before','after'] as $key){
        $v=$$key;$data=is_array($v['data']??NULL)?$v['data']:(json_decode($v['data']??'{}',TRUE)?:[]);
        $$key=array_merge($v,$data,$data['person']??[],$data['employer']??[]);
    }
    $defs=['employee_no'=>['کد پرسنلی','text'],'status'=>['وضعیت','select',kph_hr::statuses()+['active'=>'فعال','inactive'=>'پایان همکاری']], 'amount'=>['خالص مبلغ','number'], 'file_id'=>['شماره پیوست','number'],'filename'=>['نام فایل','text'],'checksum'=>['شناسه محتوای فایل','text'],'category'=>['دستهٔ مدرک','text'],'subtype'=>['نوع مدرک','text']];
    foreach(array_keys(kph_hr::kinds()) as $kind){$defs+=kph_hr_fields($kind);}
    foreach(['department'=>'واحد','insurance_no'=>'شماره بیمه','iban'=>'شبا','emergency_name'=>'تماس اضطراری','emergency_phone'=>'تلفن اضطراری','address'=>'نشانی','national_id'=>'کد ملی','phone'=>'تلفن','email'=>'ایمیل','join_date'=>'شروع همکاری','exit_date'=>'پایان همکاری','leave_allowance_minutes'=>'سهمیه مرخصی','base_amount'=>'حقوق پایه محاسبه‌شده','overtime_amount'=>'اضافه‌کاری محاسبه‌شده','gross'=>'حقوق ناخالص','change_reason'=>'علت تغییر'] as $key=>$label){$defs[$key]=[$label,'text'];}
    $out=[];
    foreach($defs as $key=>$def){$a=$before[$key]??'';$b=$after[$key]??'';if(is_scalar($a)&&is_scalar($b)&&(string)$a!==(string)$b){
        if($def[1]==='select'){$a=$def[2][$a]??$a;$b=$def[2][$b]??$b;}
        $out[]=['label'=>$def[0],'before'=>$a,'after'=>$b];
    }} return $out;
}
function kph_hr_url(int $employee,string $tab,array $params=[]):string{
    return add_query_arg(array_merge(['tab'=>'hr','hr_section'=>$tab],$params),home_url('/crm/employee/'.$employee));
}
function kph_hr_print_url(int $employee,int $record):string{
    return add_query_arg(['action'=>'print','type'=>'hr-record','user_id'=>$employee,'record_id'=>$record,'_wpnonce'=>wp_create_nonce('kph_hr_print_'.$record)],home_url('/crm/'));
}
function kph_hr_financial_protected(string $kind,int $id):bool{
    global $wpdb;
    if(!in_array(get_option('kph_hr_schema'),['1','2'],TRUE)){return FALSE;}
    return (bool)$wpdb->get_var($wpdb->prepare("SELECT id FROM {$wpdb->prefix}kph_hr_records WHERE kind=%s AND financial_ref=%d AND status='posted' LIMIT 1",$kind,$id));
}
function kph_hr_personnel_protected(int $id):bool{
    global $wpdb;
    if(!in_array(get_option('kph_hr_schema'),['1','2'],TRUE)){return FALSE;}
    return (bool)$wpdb->get_var($wpdb->prepare("SELECT id FROM {$wpdb->prefix}kph_hr_records WHERE employee_id=%d LIMIT 1",$id));
}
add_action('delete_user',function($id){
    if(kph_hr_personnel_protected((int)$id)){wp_die('پرسنل دارای سابقه کارگزینی حذف نمی‌شود؛ پایان همکاری را در پرونده ثبت کنید.','',['response'=>409]);}
});
add_action('init',function(){
    add_role('kph_employee','پرسنل بدون دسترسی پنل',['read'=>TRUE]);
    if(kph_hr::allowed() && get_option('kph_hr_schema')!=='2'){
        try{(new kph_hr())->install();update_option('kph_hr_schema','2',FALSE);}catch(Throwable $e){ /* The HR page reports missing storage explicitly. */ }
    }
},30);
add_action('wp_print_scripts',function(){
    if(wp_script_is('kasebi_clinic_script','enqueued')&&kph_hr::allowed()){
        wp_enqueue_script('kph-hr',KPH_ASSETS_URL.'js/hr.js',['kasebi_clinic_script'],KPH_VER,TRUE);
    }
},20);
add_action('wp_ajax_kph_hr_action',function(){
    $nonce=$_POST['nonce']??'';
    if(!kph_hr::allowed()||!is_string($nonce)||!wp_verify_nonce($nonce,'kph_hr')){wp_send_json(['status'=>'error','message'=>'اجازه دسترسی یا اعتبار فرم کافی نیست.'],403);}
    try{
        $hr=new kph_hr();$input=wp_unslash($_POST);$op=sanitize_key($input['operation']??'');$employee=absint($input['employee_id']??0);$record=absint($input['record_id']??0);
        if($op==='prepare'){$hr->prepare_finance();}
        elseif($op==='period'){$period=$hr->salary_period($input);$period['work']=$employee?$hr->work_summary($employee,$period['from'],$period['to']):NULL;$period['label']=kph_hr_exports::date($period['from']).' تا '.kph_hr_exports::date($period['to']);wp_send_json(['status'=>'success','period'=>$period]);}
        elseif($op==='company'){$hr->save_company($input);}
        elseif($op==='upload_document'){$file_id=$hr->attach_document($employee,$record,$_FILES['file']??[],$input);}
        elseif($op==='replace_document'){$hr->replace_document($employee,absint($input['file_id']??0),absint($input['file_version']??0),$_FILES['file']??[]);}
        elseif($op==='delete_document'){$hr->delete_document($employee,absint($input['file_id']??0),absint($input['file_version']??0));}
        elseif($op==='profile'){$hr->save_profile($employee,$input);}
        elseif($op==='save'){$record=$hr->save($employee,sanitize_key($input['kind']??''),$input,$record,absint($input['version']??0));}
        elseif($op==='attach'){$hr->attach($employee,$record,$_FILES['file']??[]);}
        elseif(in_array($op,['approve','cancel','reject','clear','bounce'],TRUE)){$hr->transition($employee,$record,absint($input['version']??0),$op,$input['reason']??'');}
        elseif($op==='create_employee'){
            $name=sanitize_text_field($input['name']??'');$phone=sanitize_text_field(nooshika_sanitize_numbers($input['phone']??''));
            if(!$name){throw new RuntimeException('نام پرسنل الزامی است.');}
            $id=wp_insert_user(['user_login'=>'hr_'.strtolower(wp_generate_password(16,FALSE,FALSE)),'user_pass'=>wp_generate_password(32,TRUE,TRUE),'display_name'=>$name,'first_name'=>$name,'user_email'=>sanitize_email($input['email']??''),'role'=>'kph_employee']);
            if(is_wp_error($id)){throw new RuntimeException('ایجاد پرسنل انجام نشد: '.$id->get_error_message());}
            update_user_meta($id,'nooshika_phone_num',$phone);
            try{$hr->save_profile((int)$id,['version'=>0,'employee_no'=>$input['employee_no']??'P-'.$id,'phone'=>$phone,'email'=>$input['email']??'','status'=>'active']);}
            catch(Throwable $e){require_once ABSPATH.'wp-admin/includes/user.php';wp_delete_user($id);throw $e;}
            wp_send_json(['status'=>'success','message'=>'پرسنل ایجاد شد.','url'=>kph_hr_url((int)$id,'hr_file')]);
        }else{throw new RuntimeException('عملیات معتبر نیست.');}
        wp_send_json(['status'=>'success','message'=>'اطلاعات با موفقیت ثبت شد.','record_id'=>$record,'file_id'=>$file_id??0]);
    }catch(Throwable $e){wp_send_json(['status'=>'error','message'=>$e instanceof RuntimeException?$e->getMessage():'ثبت اطلاعات ناموفق بود؛ صفحه را تازه کنید.']);}
});
add_action('admin_post_kph_hr_file',function(){
    $id=absint($_GET['file_id']??0);$employee=absint($_GET['employee_id']??0);$nonce=$_GET['_wpnonce']??'';
    if(!kph_hr::allowed()||!is_string($nonce)||!wp_verify_nonce($nonce,'kph_hr_file_'.$id)){wp_die('دسترسی به فایل مجاز نیست.','',['response'=>403]);}
    try{$file=(new kph_hr())->file($id,$employee);}catch(Throwable $e){wp_die('فایل این پرسنل یافت نشد.','',['response'=>404]);}
    $inline=($_GET['view']??'')==='1'&&in_array($file['mime'],['application/pdf','image/jpeg','image/png'],TRUE);
    nocache_headers();header('Cache-Control: private, no-store, max-age=0');header('Content-Type: '.$file['mime']);header('X-Content-Type-Options: nosniff');header('Referrer-Policy: no-referrer');
    header('Content-Disposition: '.($inline?'inline':'attachment').'; filename="hr-file-'.$id.'"; filename*=UTF-8\'\''.rawurlencode($file['filename']));
    header('Content-Length: '.strlen($file['contents']));echo $file['contents'];exit;
});
add_action('admin_post_kph_hr_export',function(){
    $employee=absint($_GET['employee_id']??0);$record=absint($_GET['record_id']??0);$format=$_GET['format']??'';$nonce=$_GET['_wpnonce']??'';
    if(!kph_hr::allowed()||!is_string($format)||!in_array($format,['pdf','docx','html'],TRUE)||!is_string($nonce)||!wp_verify_nonce($nonce,'kph_hr_export_'.$employee.'_'.$record.'_'.$format)){wp_die('دسترسی به خروجی مجاز نیست.','',['response'=>403]);}
    try{
        $doc=kph_hr_exports::model(new kph_hr(),$employee,$record);
        if($format==='pdf'){$bytes=kph_hr_exports::pdf($doc);$mime='application/pdf';}
        elseif($format==='docx'){$bytes=kph_hr_exports::docx($doc);$mime='application/vnd.openxmlformats-officedocument.wordprocessingml.document';}
        else{$bytes=kph_hr_export_html($doc);$mime='text/html; charset=UTF-8';}
    }catch(Throwable $e){wp_die('تولید خروجی انجام نشد؛ اطلاعات پرونده و رکورد را بررسی کنید.','',['response'=>400]);}
    nocache_headers();header('Cache-Control: private, no-store, max-age=0');header('Content-Type: '.$mime);header('X-Content-Type-Options: nosniff');header('Referrer-Policy: no-referrer');
    if($format!=='html'){header('Content-Disposition: attachment; filename="hr-'.$doc['kind'].'-'.$record.'.'.$format.'"');}
    header('Content-Length: '.strlen($bytes));echo $bytes;exit;
});
function kph_hr_export_html(array $doc): string {
    $controls='<div class="print-controls"><button type="button" onclick="window.print()">چاپ</button><a href="'.esc_url(kph_hr_export_url($doc['employee_id'],$doc['record_id'],'pdf')).'">دریافت PDF</a><a href="'.esc_url(kph_hr_export_url($doc['employee_id'],$doc['record_id'],'docx')).'">دریافت Word</a></div>';
    return str_replace('<body>','<body>'.$controls,kph_hr_exports::html($doc));
}
