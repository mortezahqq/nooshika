<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

require_once __DIR__.'/kph_hr_calendar.php';
require_once __DIR__.'/kph_hr_forms.php';
require_once __DIR__.'/kph_hr_documents.php';

/** Private personnel records. All writes serialize on the employee profile row. */
class kph_hr {
    use kph_hr_forms;
    use kph_hr_documents;
    private wpdb $d;
    private kph_db $ledger;
    private string $p;
    public function __construct() {
        global $wpdb;
        $this->d = $wpdb; $this->p = $wpdb->prefix . 'kph_'; $this->ledger = new kph_db();
    }
    public static function allowed(): bool { return is_user_logged_in() && current_user_can( 'manage_options' ); }
    public static function roles(): array { return [ 'kph_employee', 'accountant', 'supp', 'saff', 'tea', 'hell', 'nabat', 'zereshk', 'vanil', 'visitor' ]; }
    public static function kinds(): array { return [ 'contract'=>'قرارداد', 'leave'=>'مرخصی', 'attendance'=>'کارکرد', 'payslip'=>'فیش حقوقی', 'settlement'=>'تسویه‌حساب', 'document'=>'مدرک', 'payment'=>'پرداخت', 'transfer'=>'حواله', 'cheque'=>'چک پرداختی' ]; }
    public static function statuses(): array { return [ 'draft'=>'پیش‌نویس', 'approved'=>'تأییدشده', 'posted'=>'ثبت حسابداری / صادرشده', 'cleared'=>'وصول‌شده', 'rejected'=>'ردشده / برگشتی', 'canceled'=>'ابطال‌شده' ]; }
    private function guard(): void { if ( ! self::allowed() ) { throw new RuntimeException( 'اجازه دسترسی به کارگزینی ندارید.' ); } }
    private function employee( int $id ): void {
        $u = get_user_by( 'ID', $id );
        if ( ! $u || ! array_intersect( self::roles(), (array) $u->roles ) ) { throw new RuntimeException( 'پرسنل معتبر را انتخاب کنید.' ); }
    }
    private function require_ok( $result ): void { if ( $result === FALSE ) { throw new RuntimeException( 'ثبت اطلاعات انجام نشد؛ دوباره تلاش کنید.' ); } }
    private function encode( array $v ): string { return wp_json_encode( $v, JSON_UNESCAPED_UNICODE ); }
    private function decode( array $row ): array { $row['data'] = json_decode( $row['data'] ?? '{}', TRUE ) ?: []; return $row; }
    private function text( $v, int $max = 200 ): string {
        if ( ! is_scalar( $v ) ) { throw new RuntimeException( 'ساختار اطلاعات معتبر نیست.' ); }
        $v = sanitize_textarea_field( (string) $v );
        if ( mb_strlen( $v ) > $max ) { throw new RuntimeException( 'متن واردشده بیش از حد مجاز است.' ); } return $v;
    }
    private function number( $v, float $max = 1000000000000, bool $decimal = FALSE ): float {
        if(!is_scalar($v)){throw new RuntimeException('ساختار مبلغ یا مقدار معتبر نیست.');}
        $v = str_replace( [ ',', '٬' ], '', nooshika_sanitize_numbers( (string) $v ) );
        if ( ! preg_match( $decimal ? '/^\d+(\.\d{1,4})?$/' : '/^\d+$/', $v ) || (float) $v > $max ) { throw new RuntimeException( 'مبلغ یا مقدار معتبر و غیرمنفی وارد کنید.' ); }
        return (float) $v;
    }
    public function date( $v ): string {
        return kph_hr_calendar::normalize($this->text($v,10));
    }
    public function install(): void {
        $this->guard(); $c = 'ENGINE=InnoDB ' . $this->d->get_charset_collate();
        $sql = [
            "CREATE TABLE IF NOT EXISTS {$this->p}hr_profiles (employee_id BIGINT UNSIGNED PRIMARY KEY, employee_no VARCHAR(64) NOT NULL UNIQUE, status VARCHAR(20) NOT NULL DEFAULT 'active', data LONGTEXT NOT NULL, version INT UNSIGNED NOT NULL DEFAULT 1, updated_at DATETIME NOT NULL) $c",
            "CREATE TABLE IF NOT EXISTS {$this->p}hr_records (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, employee_id BIGINT UNSIGNED NOT NULL, kind VARCHAR(24) NOT NULL, lock_key VARCHAR(100) NULL, instrument_key VARCHAR(100) NULL UNIQUE, period VARCHAR(20) NOT NULL DEFAULT '', date_from DATE NOT NULL, date_to DATE NOT NULL, status VARCHAR(20) NOT NULL DEFAULT 'draft', data LONGTEXT NOT NULL, amount BIGINT NOT NULL DEFAULT 0, ledger_id BIGINT UNSIGNED NOT NULL DEFAULT 0, financial_ref BIGINT UNSIGNED NOT NULL DEFAULT 0, bank_ref BIGINT UNSIGNED NOT NULL DEFAULT 0, version INT UNSIGNED NOT NULL DEFAULT 1, created_by BIGINT UNSIGNED NOT NULL, created_at DATETIME NOT NULL, updated_at DATETIME NOT NULL, UNIQUE KEY exclusive_record(employee_id,kind,lock_key), KEY employee_kind(employee_id,kind,date_from), KEY state(kind,status,date_to)) $c",
            "CREATE TABLE IF NOT EXISTS {$this->p}hr_audit (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, employee_id BIGINT UNSIGNED NOT NULL, record_id BIGINT UNSIGNED NOT NULL DEFAULT 0, actor_id BIGINT UNSIGNED NOT NULL, event VARCHAR(32) NOT NULL, before_data LONGTEXT NOT NULL, after_data LONGTEXT NOT NULL, created_at DATETIME NOT NULL, KEY employee_audit(employee_id,id)) $c",
            "CREATE TABLE IF NOT EXISTS {$this->p}hr_files (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, employee_id BIGINT UNSIGNED NOT NULL, record_id BIGINT UNSIGNED NOT NULL, filename VARCHAR(190) NOT NULL, mime VARCHAR(127) NOT NULL, contents LONGBLOB NOT NULL, checksum CHAR(64) NOT NULL, created_by BIGINT UNSIGNED NOT NULL, created_at DATETIME NOT NULL, KEY record_files(record_id)) $c",
        ];
        foreach ( $sql as $q ) { $this->require_ok( $this->d->query( $q ) ); }
        $mimeColumn=$this->d->get_row("SHOW COLUMNS FROM {$this->p}hr_files LIKE 'mime'",ARRAY_A);
        if($mimeColumn&&preg_match('/varchar\((\d+)\)/i',$mimeColumn['Type'],$mimeSize)&&(int)$mimeSize[1]<127){$this->require_ok($this->d->query("ALTER TABLE {$this->p}hr_files MODIFY mime VARCHAR(127) NOT NULL"));}
        $this->install_document_storage();
    }
    public function financial_tables(): array { return [ 'ledger_entries', 'ledger_entry_meta', 'payments', 'payment_meta', 'transfers', 'transfer_meta', 'accounts', 'account_transactions', 'account_transaction_meta' ]; }
    public function financial_ready(): bool {
        foreach ( $this->financial_tables() as $name ) {
            $r = $this->d->get_row( $this->d->prepare( 'SHOW TABLE STATUS LIKE %s', $this->d->esc_like( $this->p . $name ) ), ARRAY_A );
            if ( ! $r || strcasecmp( $r['Engine'], 'InnoDB' ) ) { return FALSE; }
        } return TRUE;
    }
    public function prepare_finance(): void {
        $this->guard();
        foreach ( $this->financial_tables() as $name ) {
            $table = $this->p . $name;
            $r = $this->d->get_row( $this->d->prepare( 'SHOW TABLE STATUS LIKE %s', $this->d->esc_like( $table ) ), ARRAY_A );
            if ( ! $r ) { throw new RuntimeException( 'جدول حسابداری یافت نشد.' ); }
            if ( strcasecmp( $r['Engine'], 'InnoDB' ) ) { $this->require_ok( $this->d->query( "ALTER TABLE `$table` ENGINE=InnoDB" ) ); }
        }
    }
    private function audit( int $employee, int $record, string $event, array $before, array $after ): void {
        $this->require_ok( $this->d->insert( $this->p.'hr_audit', [ 'employee_id'=>$employee, 'record_id'=>$record, 'actor_id'=>get_current_user_id(), 'event'=>$event, 'before_data'=>$this->encode($before), 'after_data'=>$this->encode($after), 'created_at'=>current_time('mysql') ] ) );
    }
    public function profile( int $id ): array {
        $this->guard(); $this->employee($id);
        $profile=$this->decode( $this->d->get_row( $this->d->prepare( "SELECT * FROM {$this->p}hr_profiles WHERE employee_id=%d", $id ), ARRAY_A ) ?: [ 'employee_id'=>$id, 'employee_no'=>'P-'.$id, 'status'=>'active', 'version'=>0, 'data'=>'{}' ] );
        if((int)$profile['version']===0){
            foreach(['national_id'=>'national_id','phone'=>'nooshika_phone_num','address'=>'address'] as $key=>$meta){$profile['data'][$key]=get_user_meta($id,$meta,TRUE);}
            $profile['data']['email']=get_user_by('ID',$id)->user_email??'';
        }
        return $profile;
    }
    private function lock_employee( int $id ): array {
        $this->employee($id);
        $this->require_ok( $this->d->query( $this->d->prepare( "INSERT IGNORE INTO {$this->p}hr_profiles(employee_id,employee_no,status,data,version,updated_at) VALUES(%d,%s,'active','{}',0,%s)", $id, 'P-'.$id, current_time('mysql') ) ) );
        return $this->decode( $this->d->get_row( $this->d->prepare( "SELECT * FROM {$this->p}hr_profiles WHERE employee_id=%d FOR UPDATE", $id ), ARRAY_A ) );
    }
    public function save_profile( int $id, array $input ): void {
        $this->guard(); $this->require_ok($this->d->query('START TRANSACTION'));
        try {
            $old=$this->lock_employee($id);
            if ((int)$old['version'] !== (int)($input['version']??-1)) { throw new RuntimeException('پرونده تغییر کرده است؛ صفحه را تازه کنید.'); }
            $data=[];
            foreach ( ['full_name','father_name','identity_no','birth_place','issue_place','marital_status','education','bank_account_no','department','job_title','insurance_no','iban','bank_name','emergency_name','emergency_phone','address','national_id','phone','email','notes'] as $key ) { $data[$key]=$this->text($input[$key]??$old['data'][$key]??'', $key==='notes'?5000:1000); }
            if (!$data['full_name']) { $data['full_name']=get_user_name_by_id($id); }
            $data['iban']=strtoupper(preg_replace('/\s+/u','',nooshika_sanitize_numbers($data['iban'])));
            if($data['iban']!==''){
                if(!preg_match('/^IR\d{24}$/',$data['iban'])){throw new RuntimeException('شماره شبا باید IR و ۲۴ رقم باشد.');}
                $digits=substr($data['iban'],4).'1827'.substr($data['iban'],2,2);$mod=0;
                foreach(str_split($digits) as $digit){$mod=($mod*10+(int)$digit)%97;}
                if($mod!==1){throw new RuntimeException('شماره شبا از نظر رقم کنترل معتبر نیست.');}
            }
            foreach ( ['join_date','exit_date','birth_date'] as $key ) { $v=$input[$key]??$old['data'][$key]??'';$data[$key]=$v===''?'':$this->date($v); }
            if ($data['exit_date'] && (!$data['join_date'] || $data['exit_date']<$data['join_date'])) { throw new RuntimeException('تاریخ پایان همکاری معتبر نیست.'); }
            $data['child_count']=(int)$this->number($input['child_count']??$old['data']['child_count']??0,30);
            $data['leave_allowance_minutes']=(int)$this->number($input['leave_allowance_minutes']??0,600000);
            $data['leave_year']=$this->text(nooshika_sanitize_numbers($input['leave_year']??''),10);
            if($data['leave_allowance_minutes']<$this->leave_used($id,$data['leave_year'])){throw new RuntimeException('سهمیه جدید کمتر از مرخصی مصرف‌شده این سال است.');}
            $status=$this->text($input['status']??'active',20);
            if (!in_array($status,['active','inactive'],TRUE)) { throw new RuntimeException('وضعیت همکاری معتبر نیست.'); }
            $no=$this->text($input['employee_no']??'',64); if(!$no) {throw new RuntimeException('کد پرسنلی الزامی است.');}
            $next=['employee_no'=>$no,'status'=>$status,'data'=>$this->encode($data),'version'=>(int)$old['version']+1,'updated_at'=>current_time('mysql')];
            $this->require_ok($this->d->update($this->p.'hr_profiles',$next,['employee_id'=>$id]));
            $this->audit($id,0,'profile',$old,$next); $this->require_ok($this->d->query('COMMIT'));
        } catch(Throwable $e) {$this->d->query('ROLLBACK');throw $e;}
    }
    public function record( int $id, int $employee ): array {
        $this->guard(); $this->employee($employee);
        $r=$this->d->get_row($this->d->prepare("SELECT * FROM {$this->p}hr_records WHERE id=%d AND employee_id=%d",$id,$employee),ARRAY_A);
        if(!$r){throw new RuntimeException('رکورد این پرسنل یافت نشد.');} return $this->decode($r);
    }
    public function listing( int $employee, string $kind, int $page=1, string $status='', string $search='' ): array {
        $this->guard();$this->employee($employee);
        if(!isset(self::kinds()[$kind])){throw new RuntimeException('بخش معتبر نیست.');}
        $where='employee_id=%d AND kind=%s';$bind=[$employee,$kind];
        if($status!==''){$where.=' AND status=%s';$bind[]=$status;}
        if($search!==''){$where.=' AND (period LIKE %s OR data LIKE %s)';$bind[]='%'.$this->d->esc_like($search).'%';$bind[]='%'.$this->d->esc_like($search).'%';}
        $total=(int)$this->d->get_var($this->d->prepare("SELECT COUNT(*) FROM {$this->p}hr_records WHERE $where",$bind));
        $rows=$this->d->get_results($this->d->prepare("SELECT * FROM {$this->p}hr_records WHERE $where ORDER BY date_from DESC,id DESC LIMIT 20 OFFSET %d",array_merge($bind,[(max(1,$page)-1)*20])),ARRAY_A);
        if($this->d->last_error){throw new RuntimeException('خواندن اطلاعات ناموفق بود.');}
        return ['items'=>array_map([$this,'decode'],$rows?:[]),'total'=>$total,'pages'=>max(1,(int)ceil($total/20))];
    }
    public function audits(int $employee,int $page=1):array{
        $this->guard();$this->employee($employee);
        $total=(int)$this->d->get_var($this->d->prepare("SELECT COUNT(*) FROM {$this->p}hr_audit WHERE employee_id=%d",$employee));
        return ['items'=>$this->d->get_results($this->d->prepare("SELECT * FROM {$this->p}hr_audit WHERE employee_id=%d ORDER BY id DESC LIMIT 20 OFFSET %d",$employee,(max(1,$page)-1)*20),ARRAY_A),'pages'=>max(1,(int)ceil($total/20))];
    }
    private function closed_period(int $employee,string $from,string $to,int $exclude=0):bool{
        return (bool)$this->d->get_var($this->d->prepare("SELECT id FROM {$this->p}hr_records WHERE employee_id=%d AND kind='payslip' AND status='posted' AND date_from<=%s AND date_to>=%s AND id<>%d LIMIT 1",$employee,$to,$from,$exclude));
    }
    public function work_summary(int $employee,string $from,string $to):array{
        $this->guard();$this->employee($employee);
        $rows=$this->d->get_results($this->d->prepare("SELECT kind,date_from,date_to,data FROM {$this->p}hr_records WHERE employee_id=%d AND kind IN('attendance','leave') AND status='approved' AND date_from>=%s AND date_to<=%s",$employee,$from,$to),ARRAY_A);
        $out=['days'=>0,'worked_minutes'=>0,'overtime_minutes'=>0,'late_minutes'=>0,'paid_leave_minutes'=>0,'unpaid_leave_minutes'=>0];
        foreach($rows?:[] as $r){$d=json_decode($r['data'],TRUE)?:[];
            if($r['kind']==='attendance'){if(($d['worked_minutes']??0)>0){$out['days']++;}foreach(['worked_minutes','overtime_minutes','late_minutes'] as $k){$out[$k]+=(int)($d[$k]??0);}}
            else{$out[($d['leave_type']??'paid')==='unpaid'?'unpaid_leave_minutes':'paid_leave_minutes']+=(int)($d['minutes']??0);}
        } return $out;
    }
    private function normalize(int $employee,string $kind,array $in):array{
        if(!isset(self::kinds()[$kind])){throw new RuntimeException('نوع رکورد معتبر نیست.');}
        if ((string)($in['form_version']??'')==='2' && in_array($kind,['contract','payslip','settlement'],TRUE)) { return $this->normalize_form($employee,$kind,$in); }
        $from=$this->date($in['date_from']??'');$to=$this->date($in['date_to']??$in['date_from']??'');
        if($to<$from){throw new RuntimeException('تاریخ پایان قبل از شروع است.');}
        $d=['title'=>$this->text($in['title']??'',200),'notes'=>$this->text($in['notes']??'',5000)];$amount=0;$period='';$lock=NULL;
        if($kind==='contract'){
            if(!$d['title']){throw new RuntimeException('عنوان قرارداد الزامی است.');}
            $d['basis']=$this->text($in['basis']??'monthly',20);
            if(!in_array($d['basis'],['monthly','daily','hourly'],TRUE)){throw new RuntimeException('روش حقوق معتبر نیست.');}
            foreach(['rate','overtime_rate'] as $k){$d[$k]=(int)$this->number($in[$k]??0);}
            $d['normal_days']=$this->number($in['normal_days']??30,31,TRUE);
            if($d['normal_days']<1||$d['rate']<=0){throw new RuntimeException('نرخ حقوق مثبت و روزهای مبنا بین ۱ تا ۳۱ باشد.');}
            $d['job_title']=$this->text($in['job_title']??'',200);$d['terms']=$this->text($in['terms']??'',10000);$amount=$d['rate'];
        }elseif($kind==='leave'){
            $days=(strtotime($to)-strtotime($from))/86400+1;
            $d['minutes']=(int)$this->number($in['minutes']??0,$days*1440);
            $d['leave_type']=$this->text($in['leave_type']??'paid',20);
            if(!$d['minutes']||!in_array($d['leave_type'],['paid','unpaid','sick'],TRUE)){throw new RuntimeException('نوع یا مدت مرخصی معتبر نیست.');}
            $d['leave_year']=$this->text(nooshika_sanitize_numbers($in['leave_year']??''),10);$d['reason']=$this->text($in['reason']??'',2000);
        }elseif($kind==='attendance'){
            if($from!==$to){throw new RuntimeException('هر کارکرد برای یک روز ثبت می‌شود.');}
            foreach(['worked_minutes','overtime_minutes','late_minutes'] as $k){$d[$k]=(int)$this->number($in[$k]??0,1440);}
            if($d['worked_minutes']+$d['overtime_minutes']>1440){throw new RuntimeException('مجموع ساعات روز بیش از ۲۴ ساعت است.');}
            $lock=$from;
        }elseif($kind==='payslip'){
            if((strtotime($to)-strtotime($from))/86400>=31){throw new RuntimeException('هر فیش حداکثر برای ۳۱ روز است.');}
            $period=$this->text(nooshika_sanitize_numbers($in['period']??''),20);
            if(!preg_match('/^\d{4}[\/-](0[1-9]|1[0-2])$/',$period)){throw new RuntimeException('دوره فیش مانند ۱۴۰۵/۰۷ وارد شود.');}
            $period=str_replace('-','/',$period);$lock=$period;
            $contract=$this->record((int)($in['contract_id']??0),$employee);
            if($contract['kind']!=='contract'||$contract['status']!=='approved'||$contract['date_from']>$from||$contract['date_to']<$to){throw new RuntimeException('قرارداد تأییدشده باید تمام دوره فیش را پوشش دهد.');}
            $work=$this->work_summary($employee,$from,$to);$c=$contract['data'];
            $d['contract_id']=(int)$contract['id'];$d['contract_snapshot']=$c;$d['work_snapshot']=$work;
            $d['paid_days']=$this->number($in['paid_days']??$c['normal_days'],31,TRUE);
            $d['base_amount']=(int)round($c['basis']==='hourly'?$c['rate']*$work['worked_minutes']/60:($c['basis']==='daily'?$c['rate']*$d['paid_days']:$c['rate']*$d['paid_days']/$c['normal_days']));
            $d['overtime_amount']=(int)round($c['overtime_rate']*$work['overtime_minutes']/60);
            foreach(['benefits','bonus','insurance','tax','deductions'] as $k){$d[$k]=(int)$this->number($in[$k]??0);}
            $d['gross']=$d['base_amount']+$d['overtime_amount']+$d['benefits']+$d['bonus'];
            $amount=$d['gross']-$d['insurance']-$d['tax']-$d['deductions'];
            if($amount<0){throw new RuntimeException('کسورات بیشتر از حقوق ناخالص است.');}
        }elseif($kind==='settlement'){
            foreach(['severance','annual_bonus','leave_cash','other_due','deductions'] as $k){$d[$k]=(int)$this->number($in[$k]??0);}
            $amount=$d['severance']+$d['annual_bonus']+$d['leave_cash']+$d['other_due']-$d['deductions'];
            if($amount<0){throw new RuntimeException('خالص مزایای تسویه منفی است.');}
            $d['balance_snapshot']=$this->ledger->get_ledger_balance_now($employee)['balance']??0;
            $lock=$from.'_'.$to;
        }elseif(in_array($kind,['payment','transfer','cheque'],TRUE)){
            if($from!==$to){throw new RuntimeException('تاریخ پرداخت باید یک روز باشد.');}
            $amount=(int)$this->number($in['amount']??0);if(!$amount){throw new RuntimeException('مبلغ پرداخت باید مثبت باشد.');}
            $d['account_id']=(int)$this->number($in['account_id']??0,PHP_INT_MAX);
            $d['related_id']=(int)$this->number($in['related_id']??0,PHP_INT_MAX);
            if($d['related_id']){$rel=$this->record($d['related_id'],$employee);if(!in_array($rel['kind'],['payslip','settlement'],TRUE)||$rel['status']!=='posted'){throw new RuntimeException('مرجع پرداخت باید فیش یا تسویه تأییدشده همین پرسنل باشد.');}}
            $d['purpose']=$this->text($in['purpose']??'salary',20);
            if(!in_array($d['purpose'],['salary','advance','settlement','other'],TRUE)){throw new RuntimeException('بابت پرداخت معتبر نیست.');}
            foreach(['tracking_no','bank_name','cheque_no','sayad_id'] as $k){$d[$k]=$this->text($in[$k]??'',120);}
            $d['payment_method']=$this->text($in['payment_method']??'cash',20);
            if(!isset($this->ledger->get_payment_methods()[$d['payment_method']])){throw new RuntimeException('روش پرداخت معتبر نیست.');}
            if($kind==='transfer'&&!$d['tracking_no']){throw new RuntimeException('شماره پیگیری حواله الزامی است.');}
            if($kind==='cheque'){
                $d['cheque_no']=nooshika_sanitize_numbers($d['cheque_no']);
                $d['due_date']=$this->date($in['due_date']??'');
                if(!$d['cheque_no']||!$d['bank_name']){throw new RuntimeException('شماره چک و بانک الزامی است.');}
                $lock=hash('sha256',mb_strtolower(preg_replace('/\s+/u',' ',$d['bank_name'])).'|'.mb_strtolower($d['cheque_no']));
            }
        }elseif(!$d['title']){throw new RuntimeException('عنوان مدرک الزامی است.');}
        return ['employee_id'=>$employee,'kind'=>$kind,'lock_key'=>$lock,'instrument_key'=>$kind==='cheque'?$lock:NULL,'period'=>$period,'date_from'=>$from,'date_to'=>$to,'data'=>$this->encode($d),'amount'=>$amount];
    }
    public function save(int $employee,string $kind,array $input,int $id=0,int $version=0):int{
        $this->guard();$this->require_ok($this->d->query('START TRANSACTION'));
        try{
            $profile=$this->lock_employee($employee);
            if($profile['status']!=='active'&&!in_array($kind,['settlement','payment','transfer','cheque','document'],TRUE)){throw new RuntimeException('همکاری این پرسنل غیرفعال است.');}
            $old=$id?$this->record($id,$employee):[];
            if($old&&($old['kind']!==$kind||$old['status']!=='draft'||(int)$old['version']!==$version)){throw new RuntimeException('فقط پیش‌نویس جاری قابل ویرایش است؛ صفحه را تازه کنید.');}
            $next=$this->normalize($employee,$kind,$input);
            if(in_array($kind,['attendance','leave','payslip'],TRUE)&&$this->closed_period($employee,$next['date_from'],$next['date_to'],$id)){throw new RuntimeException('دوره حقوق بسته شده است؛ ابتدا فیش آن را ابطال کنید.');}
            $next['updated_at']=current_time('mysql');
            if($id){$next['version']=$version+1;$this->require_ok($this->d->update($this->p.'hr_records',$next,['id'=>$id]));}
            else{$next['created_by']=get_current_user_id();$next['created_at']=current_time('mysql');$this->require_ok($this->d->insert($this->p.'hr_records',$next));$id=(int)$this->d->insert_id;}
            $this->audit($employee,$id,$old?'edit':'create',$old,$next);$this->require_ok($this->d->query('COMMIT'));return $id;
        }catch(Throwable $e){$this->d->query('ROLLBACK');throw $e;}
    }
    private function eligibility(array $r):void{
        $e=(int)$r['employee_id'];$kind=$r['kind'];
        if(in_array($kind,['leave','attendance','payslip'],TRUE)&&$this->closed_period($e,$r['date_from'],$r['date_to'],(int)$r['id'])){throw new RuntimeException('فیش تأییدشده این دوره باید ابتدا ابطال شود.');}
        if($kind==='payslip'){
            $advanced=(int)($r['data']['form_version']??0)===2;
            if (!$advanced || ($r['data']['calculation_mode']??'contract')==='contract') {
                $c=$this->record((int)$r['data']['contract_id'],$e);
                if($c['status']!=='approved'||$c['data']!==$r['data']['contract_snapshot']){throw new RuntimeException('قرارداد تغییر کرده است؛ پیش‌نویس فیش را دوباره ذخیره کنید.');}
            }
            if (!$advanced || ($r['data']['work_source']??'attendance')==='attendance') {
                if($this->work_summary($e,$r['date_from'],$r['date_to'])!==$r['data']['work_snapshot']){throw new RuntimeException('کارکرد تغییر کرده است؛ پیش‌نویس فیش را دوباره ذخیره کنید.');}
            }
        }
        if(in_array($kind,['contract','leave'],TRUE)){
            $match=$kind==='contract'?"kind='contract' AND status='approved'":"kind='leave' AND status='approved'";
            if($this->d->get_var($this->d->prepare("SELECT id FROM {$this->p}hr_records WHERE employee_id=%d AND $match AND date_from<=%s AND date_to>=%s AND id<>%d LIMIT 1",$e,$r['date_to'],$r['date_from'],$r['id']))){throw new RuntimeException('بازه با رکورد تأییدشده دیگری هم‌پوشانی دارد.');}
        }
        if($kind==='leave'&&$r['data']['leave_type']==='paid'){
            $profile=$this->profile($e)['data'];$year=$r['data']['leave_year'];
            if(!$year||$year!==($profile['leave_year']??'')){throw new RuntimeException('سال سهمیه مرخصی را در پرونده تنظیم کنید.');}
            $used=$this->leave_used($e,$year);
            if($used+(int)$r['data']['minutes']>(int)($profile['leave_allowance_minutes']??0)){throw new RuntimeException('مدت مرخصی بیشتر از سهمیه باقی‌مانده است.');}
        }
        if($kind==='contract'&&$this->d->get_var($this->d->prepare("SELECT id FROM {$this->p}hr_records WHERE employee_id=%d AND kind='payslip' AND status='posted' AND JSON_EXTRACT(data,'$.contract_id')=%d LIMIT 1",$e,$r['id']))){throw new RuntimeException('قرارداد دارای فیش تأییدشده است.');}
    }
    public function leave_used(int $employee,string $year):int{
        $this->guard();$this->employee($employee);
        return (int)$this->d->get_var($this->d->prepare("SELECT COALESCE(SUM(CAST(JSON_UNQUOTE(JSON_EXTRACT(data,'$.minutes')) AS UNSIGNED)),0) FROM {$this->p}hr_records WHERE employee_id=%d AND kind='leave' AND status='approved' AND JSON_UNQUOTE(JSON_EXTRACT(data,'$.leave_type'))='paid' AND JSON_UNQUOTE(JSON_EXTRACT(data,'$.leave_year'))=%s",$employee,$year));
    }
    private function bank(array $r,bool $reverse=FALSE):int{
        $id=(int)$r['data']['account_id'];
        $a=$this->d->get_row($this->d->prepare("SELECT * FROM {$this->p}accounts WHERE id=%d FOR UPDATE",$id),ARRAY_A);
        if(!$a||$a['status']!=='active'){throw new RuntimeException('حساب فعال پرداخت را انتخاب کنید.');}
        $balance=(int)$a['balance']+($reverse?1:-1)*(int)$r['amount'];
        if($balance<0&&$a['type']!=='expense'){throw new RuntimeException('موجودی حساب پرداخت کافی نیست.');}
        $this->require_ok($this->d->insert($this->p.'account_transactions',['account_id'=>$id,'amount'=>(int)$r['amount'],'type'=>$reverse?'credit':'debit','action'=>$reverse?'hr_reversal':'hr_payment','balance_after'=>$balance,'description'=>($reverse?'برگشت پرداخت پرسنل #':'پرداخت پرسنل #').$r['id'],'created_by'=>get_current_user_id(),'created_at'=>current_time('mysql')]));
        $trx=(int)$this->d->insert_id;
        if($reverse&&(int)$r['bank_ref']>0){
            $this->require_ok($this->d->insert($this->p.'account_transaction_meta',['transaction_id'=>(int)$r['bank_ref'],'meta_key'=>'hr_voided','meta_value'=>'1']));
        }
        $this->require_ok($this->d->update($this->p.'accounts',['balance'=>$balance,'updated_at'=>current_time('mysql')],['id'=>$id]));
        foreach(['hr_record_id'=>$r['id'],'cost_type'=>'Personnel Salaries','destination'=>'پرسنل #'.$r['employee_id']] as $k=>$v){$this->require_ok($this->d->insert($this->p.'account_transaction_meta',['transaction_id'=>$trx,'meta_key'=>$k,'meta_value'=>(string)$v]));}
        return $trx;
    }
    private function post(array $r,bool $reverse=FALSE):array{
        if(!$this->financial_ready()){throw new RuntimeException('ابتدا آماده‌سازی ثبت یکپارچه حسابداری پرسنل را انجام دهید.');}
        $credit=in_array($r['kind'],['payslip','settlement'],TRUE);$out=['ledger_id'=>(int)$r['ledger_id'],'financial_ref'=>(int)$r['financial_ref'],'bank_ref'=>(int)$r['bank_ref']];
        if(!$credit){$out['bank_ref']=$this->bank($r,$reverse);}
        if(!$reverse&&in_array($r['kind'],['payment','transfer'],TRUE)){
            $transfer=$r['kind']==='transfer';$t=$this->p.($transfer?'transfers':'payments');
            $v=['user_id'=>(int)$r['employee_id'],'amount'=>(int)$r['amount'],'note'=>'پرداخت کارگزینی #'.$r['id'],'created_at'=>current_time('mysql')];
            if($transfer){$v+=['transferred_at'=>$r['date_from'].' 12:00:00','bank_name'=>$r['data']['bank_name'],'tracking_no'=>$r['data']['tracking_no']];}else{$v+=['paid_at'=>$r['date_from'].' 12:00:00','payment_method'=>$r['data']['payment_method']];}
            $this->require_ok($this->d->insert($t,$v));$out['financial_ref']=(int)$this->d->insert_id;
            $fk=$transfer?'transfer_id':'payment_id';$mt=$this->p.($transfer?'transfer_meta':'payment_meta');
            foreach(['hr_record_id'=>$r['id'],'creator_id'=>get_current_user_id()] as $k=>$value){$this->require_ok($this->d->insert($mt,[$fk=>$out['financial_ref'],'meta_key'=>$k,'meta_value'=>(string)$value]));}
        }
        if($reverse&&in_array($r['kind'],['payment','transfer'],TRUE)){
            $transfer=$r['kind']==='transfer';$table=$this->p.($transfer?'transfers':'payments');$meta=$this->p.($transfer?'transfer_meta':'payment_meta');$fk=$transfer?'transfer_id':'payment_id';
            $this->require_ok($this->d->delete($meta,[$fk=>$r['financial_ref']]));$this->require_ok($this->d->delete($table,['id'=>$r['financial_ref']]));
        }
        if((int)$r['amount']>0){
            $result=$this->ledger->add_ledger_entry(['user_id'=>(int)$r['employee_id'],'entry_type'=>$reverse?'hr_reversal':($credit?'hr_'.$r['kind']:'hr_payment'),'type'=>($credit!==$reverse)?'credit':'debit','amount'=>(int)$r['amount'],'ref_type'=>'hr_record','ref_id'=>(int)$r['id'],'posted_at'=>current_time('mysql'),'note'=>($reverse?'ابطال ':'').self::kinds()[$r['kind']].' #'.$r['id'],'meta'=>['creator_id'=>get_current_user_id(),'hr_record_id'=>$r['id']]]);
            if($result['status']!=='success'){throw new RuntimeException('ثبت حسابداری ناموفق بود.');}$out['ledger_id']=(int)$result['data']['id'];
        } return $out;
    }
    public function transition(int $employee,int $id,int $version,string $action,string $reason=''):void{
        $this->guard();$this->require_ok($this->d->query('START TRANSACTION'));
        try{
            $this->lock_employee($employee);$r=$this->record($id,$employee);
            if((int)$r['version']!==$version){throw new RuntimeException('رکورد تغییر کرده است؛ صفحه را تازه کنید.');}
            $next=[];$d=$r['data'];
            if($action==='approve'){
                if($r['status']!=='draft'){throw new RuntimeException('فقط پیش‌نویس قابل تأیید است.');}
                $this->eligibility($r);
                if($r['kind']==='settlement'&&($d['settlement_effect']??'')==='document_only'){$next['status']='approved';}
                elseif(in_array($r['kind'],['payslip','settlement','payment','transfer'],TRUE)){$next=$this->post($r);$next['status']='posted';}
                else{$next['status']=$r['kind']==='cheque'?'posted':'approved';}
                if($r['kind']==='cheque'){
                    $account=$this->d->get_row($this->d->prepare("SELECT id,status FROM {$this->p}accounts WHERE id=%d",$d['account_id']),ARRAY_A);
                    if(!$account||$account['status']!=='active'){throw new RuntimeException('حساب فعال صادرکننده چک را انتخاب کنید.');}
                }
                if($r['kind']==='settlement'){$d['balance_at_approval']=$this->ledger->get_ledger_balance_now($employee)['balance']??0;}
            }elseif($action==='clear'){
                if($r['kind']!=='cheque'||$r['status']!=='posted'){throw new RuntimeException('فقط چک صادرشده قابل وصول است.');}
                $next=$this->post($r);$next['status']='cleared';
            }elseif(in_array($action,['cancel','reject','bounce'],TRUE)){
                if(!in_array($r['status'],['draft','approved','posted','cleared'],TRUE)||($action==='reject'&&$r['status']!=='draft')||($action==='bounce'&&($r['kind']!=='cheque'||!in_array($r['status'],['posted','cleared'],TRUE)))){throw new RuntimeException('این تغییر وضعیت مجاز نیست.');}
                $reason=$this->text($reason,2000);if(!$reason){throw new RuntimeException('علت ابطال، رد یا برگشت را وارد کنید.');}
                $this->eligibility_for_cancel($r);
                if($r['ledger_id']||in_array($r['kind'],['payment','transfer'],TRUE)&&$r['status']==='posted'){$next=$this->post($r,TRUE);}
                $next['status']=$action==='cancel'?'canceled':'rejected';$next['lock_key']=NULL;$d['change_reason']=$reason;
            }else{throw new RuntimeException('عملیات معتبر نیست.');}
            $d['last_actor']=get_current_user_id();$d['last_action']=$action;$next['data']=$this->encode($d);$next['version']=$version+1;$next['updated_at']=current_time('mysql');
            $this->require_ok($this->d->update($this->p.'hr_records',$next,['id'=>$id]));$this->audit($employee,$id,$action,$r,$next);$this->require_ok($this->d->query('COMMIT'));
        }catch(Throwable $e){$this->d->query('ROLLBACK');throw $e;}
    }
    private function eligibility_for_cancel(array $r):void{
        if(in_array($r['kind'],['attendance','leave'],TRUE)&&$this->closed_period((int)$r['employee_id'],$r['date_from'],$r['date_to'])){throw new RuntimeException('ابتدا فیش دوره را ابطال کنید.');}
        if($r['kind']==='contract'&&$this->d->get_var($this->d->prepare("SELECT id FROM {$this->p}hr_records WHERE employee_id=%d AND kind='payslip' AND status='posted' AND JSON_EXTRACT(data,'$.contract_id')=%d LIMIT 1",$r['employee_id'],$r['id']))){throw new RuntimeException('ابتدا فیش‌های قرارداد را ابطال کنید.');}
        if(in_array($r['kind'],['payslip','settlement'],TRUE)&&$this->d->get_var($this->d->prepare("SELECT id FROM {$this->p}hr_records WHERE employee_id=%d AND kind IN('payment','transfer','cheque') AND status IN('posted','cleared') AND JSON_EXTRACT(data,'$.related_id')=%d LIMIT 1",$r['employee_id'],$r['id']))){throw new RuntimeException('ابتدا پرداخت‌های مرتبط را ابطال کنید.');}
    }
    public function attach(int $employee,int $record,array $file):int{
        return $this->attach_document($employee,$record,$file);
    }
    public function files(int $employee,int $record):array{
        $this->guard();$this->record($record,$employee);
        return $this->d->get_results($this->d->prepare("SELECT id,filename,mime,checksum,created_at FROM {$this->p}hr_files WHERE employee_id=%d AND record_id=%d ORDER BY id",$employee,$record),ARRAY_A)?:[];
    }
    public function file(int $id,int $employee=0):array{
        $this->guard();$r=$this->d->get_row($this->d->prepare("SELECT * FROM {$this->p}hr_files WHERE id=%d",$id),ARRAY_A);
        if(!$r||($employee&&(int)$r['employee_id']!==$employee)){throw new RuntimeException('فایل یافت نشد.');}$this->employee((int)$r['employee_id']);return $r;
    }
    public function dashboard():array{
        $this->guard();
        return ['contracts'=>$this->d->get_results($this->d->prepare("SELECT id,employee_id,date_to,data FROM {$this->p}hr_records WHERE kind='contract' AND status='approved' AND date_to<=%s ORDER BY date_to LIMIT 30",date('Y-m-d',strtotime(current_time('mysql').'+30 days'))),ARRAY_A)?:[],
        'pending'=>$this->d->get_results("SELECT kind,COUNT(*) AS total FROM {$this->p}hr_records WHERE status='draft' GROUP BY kind",ARRAY_A)?:[]];
    }
}
