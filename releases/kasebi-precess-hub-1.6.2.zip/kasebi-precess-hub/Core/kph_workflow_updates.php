<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

trait kph_workflow_updates {
	/** A read-only, non-financial preparation report of explicitly selected open orders. */
	public function get_preparation_orders( array $ids ): array {
		if ( ! kph_preparation_print_allowed() ) { return $this->fail( 'اجازه چاپ لیست آماده‌سازی را ندارید.', [ 'http_status' => 403 ] ); }
		$ids = array_values( array_unique( array_filter( array_map( 'absint', array_filter( $ids, 'is_scalar' ) ) ) ) );
		if ( ! $ids || count( $ids ) > 500 ) { return $this->fail( 'از ۱ تا ۵۰۰ پیش‌فاکتور را برای هر نوبت چاپ انتخاب کنید.' ); }
		$orders = [];
		foreach ( $ids as $id ) {
			if ( ! $this->visitor_can_access_order( $id ) ) { return $this->fail( 'اجازه دسترسی به یکی از سفارش‌های انتخاب‌شده را ندارید.', [ 'http_status' => 403 ] ); }
			$order = $this->get_order_data( $id );
			if ( $this->db->last_error ) { return $this->fail( 'خواندن اقلام سفارش انجام نشد؛ دوباره تلاش کنید.', [ 'http_status' => 500 ] ); }
			if ( ! $order ) { return $this->fail( 'سفارش شماره ' . $id . ' یافت نشد؛ فهرست را به‌روز کنید.', [ 'http_status' => 404 ] ); }
			if ( $order['status'] !== 'proforma' ) { return $this->fail( 'سفارش شماره ' . $id . ' دیگر پیش‌فاکتور باز نیست؛ انتخاب‌ها را به‌روز کنید.', [ 'http_status' => 409 ] ); }
			$items = [];
			foreach ( $order['items'] as $item ) {
				$qty = max( 0, (int) $item['qty_ordered'] );
				$free = max( 0, (int) $item['expected_free_qty'] );
				if ( $qty + $free === 0 ) { continue; }
				$title = get_the_title( (int) $item['wc_product_id'] );
				$items[] = [ 'product_title' => $title ?: 'محصول #' . (int) $item['wc_product_id'],
					'qty_ordered' => $qty, 'free_qty' => $free, 'preparation_qty' => $qty + $free ];
			}
			if ( ! $items ) { return $this->fail( 'پیش‌فاکتور شماره ' . $id . ' هیچ قلمی برای آماده‌سازی ندارد.', [ 'http_status' => 409 ] ); }
			$orders[] = [ 'id' => $id, 'customer_id' => (int) $order['customer_id'], 'created_at' => $order['created_at'], 'items' => $items ];
		}
		return $this->ok( '', $orders );
	}

	private function production_codes_table(): string {
		return $this->db_prefix . 'production_codes';
	}

	public function normalize_production_code( string $code ): string {
		return trim( strtr( $code, array_combine(
			preg_split( '//u', '۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩', -1, PREG_SPLIT_NO_EMPTY ),
			str_split( '01234567890123456789' )
		) ) );
	}

	private function create_production_codes_table(): void {
		$table = $this->production_codes_table();
		maybe_create_table( $table, "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			code VARCHAR(64) NOT NULL,
			wc_product_id BIGINT UNSIGNED NOT NULL,
			created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id), UNIQUE KEY customer_code_product (code,wc_product_id), KEY wc_product_id (wc_product_id)
		) ENGINE=InnoDB " . $this->db->get_charset_collate() );
	}

	private function workflow_tables( string $workflow ): array {
		$production = [ $this->production_codes_table(), $this->processing_packs,
			$this->packaging_lots, $this->packaging_moves, $this->shop_conversions,
			$this->inventory_balance, $this->inventory_log, $this->db_prefix . 'shop_conversion_meta' ];
		$supplier = [ $this->supplier_invoices, $this->supplier_invoice_items,
			$this->db_prefix . 'invoice_meta', $this->db_prefix . 'invoice_item_meta' ];
		return $workflow === 'production' ? $production : ( $workflow === 'supplier' ? $supplier : array_merge( $production, $supplier ) );
	}

	public function workflow_storage_ready( string $workflow = 'all' ): bool {
		foreach ( $this->workflow_tables( $workflow ) as $table ) {
			$row = $this->db->get_row( $this->db->prepare( 'SHOW TABLE STATUS LIKE %s', $this->db->esc_like( $table ) ), ARRAY_A );
			if ( ! $row || strcasecmp( (string) $row['Engine'], 'InnoDB' ) !== 0 ) { return FALSE; }
		}
		return $workflow === 'supplier' || $this->customer_production_schema_ready();
	}

	/** Explicit administrator maintenance; never run DDL inside a business transaction. */
	public function prepare_workflow_storage(): array {
		if ( ! current_user_can( 'manage_options' ) ) { return $this->fail( 'فقط مدیر می‌تواند آماده‌سازی را انجام دهد.' ); }
		foreach ( $this->workflow_tables( 'all' ) as $table ) {
			$row = $this->db->get_row( $this->db->prepare( 'SHOW TABLE STATUS LIKE %s', $this->db->esc_like( $table ) ), ARRAY_A );
			if ( ! $row ) { return $this->fail( 'جدول مورد نیاز یافت نشد: ' . $table ); }
			if ( strcasecmp( (string) $row['Engine'], 'InnoDB' ) !== 0 && FALSE === $this->db->query( "ALTER TABLE `{$table}` ENGINE=InnoDB" ) ) {
				return $this->fail( 'آماده‌سازی جدول انجام نشد: ' . $table );
			}
		}
		$schema = $this->prepare_customer_production_schema();
		if ($schema['status'] !== 'success') { return $schema; }
		$seed = $this->seed_production_codes();
		if ( $seed['status'] !== 'success' ) { return $seed; }
		return $this->ok( 'ثبت یکپارچه آماده شد و کدهای موجودی به فهرست کدهای تولید اضافه شدند.' );
	}

    /** Query identifiers here are internal aliases, never request values. */
    private function production_code_sql(string $column): string {
        $sql = "TRIM({$column})";
        $from = preg_split('//u', '۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩', -1, PREG_SPLIT_NO_EMPTY);
        foreach ($from as $i=>$digit) { $sql = "REPLACE({$sql}, '{$digit}', '" . ($i % 10) . "')"; }
        return $sql;
    }
    private function production_product_sql(string $alias): string {
        return "{$alias}.post_status = 'publish' AND {$alias}.post_type = 'product'";
    }
    /** A store SKU is not evidence of a customer-approved production code.
     * Retain historical/stock codes; hide only unused automatic SKU guesses from 1.4.1.
     */
    private function production_code_verified_sql(string $alias): string {
        $evidence=[];
        foreach([$this->inventory_balance,$this->shop_conversions,$this->inventory_log,$this->order_items] as $index=>$table){
            $history='verified_'.$index;
            $evidence[]="NOT EXISTS (SELECT 1 FROM {$table} {$history} WHERE {$history}.unique_product_code={$alias}.code AND {$history}.wc_product_id={$alias}.wc_product_id)";
        }
        $approved=$this->customer_code_pair_sql($alias.'.wc_product_id',$alias.'.code',$this->customer_code_catalog());
        $reserved=implode(',',array_map(fn($rule)=>$this->db->prepare('%s',$rule['code']),$this->customer_product_code_rules()));
        $normal=$this->production_code_sql($alias.'.code');
        return "(({$normal} NOT IN ({$reserved}) OR {$approved}) AND NOT ({$alias}.created_by=0 AND NOT ({$approved}) AND EXISTS (SELECT 1 FROM {$this->db->postmeta} guessed_sku
            WHERE guessed_sku.post_id={$alias}.wc_product_id AND guessed_sku.meta_key='_sku' AND guessed_sku.meta_value={$alias}.code)
            AND ".implode(' AND ',$evidence)."))";
    }
    /** Refresh a derived registry only; never change inventory identities or balances. */
    public function seed_production_codes(): array {
        $table = $this->production_codes_table();
        $active = $this->production_product_sql('p');
        $catalog=$this->customer_code_catalog();$shared=$this->customer_code_pair_sql('b.wc_product_id','b.unique_product_code',$catalog);
        $otherShared=$this->customer_code_pair_sql('other.wc_product_id','other.code',$catalog);
        $valid = "BINARY b.unique_product_code = BINARY TRIM(b.unique_product_code)
            AND TRIM(b.unique_product_code) <> '' AND b.unique_product_code NOT REGEXP '[[:cntrl:]<>]'";
        // A set-based insert also handles inventory added after the first upgrade.
        // On a concurrent duplicate, retain the established registry mapping.
        $added = $this->db->query($this->db->prepare("INSERT INTO {$table} (code,wc_product_id,created_by,created_at)
            SELECT b.unique_product_code,b.wc_product_id,0,%s FROM {$this->inventory_balance} b
            INNER JOIN {$this->db->posts} p ON p.ID=b.wc_product_id
            LEFT JOIN {$table} c ON c.code=b.unique_product_code AND c.wc_product_id=b.wc_product_id
            WHERE c.id IS NULL AND {$valid} AND {$active}
                AND NOT EXISTS (SELECT 1 FROM {$table} other WHERE other.code=b.unique_product_code AND other.wc_product_id<>b.wc_product_id AND NOT ({$shared} AND {$otherShared}))
            ON DUPLICATE KEY UPDATE wc_product_id={$table}.wc_product_id", current_time('mysql')));
        if ($added === FALSE) { return $this->fail('بارگذاری کدهای موجود انبار انجام نشد؛ صفحه را تازه کنید یا با مدیر تماس بگیرید.'); }
        $conflicts = (int)$this->db->get_var("SELECT COUNT(*) FROM {$this->inventory_balance} b
            INNER JOIN {$table} c ON c.code=b.unique_product_code WHERE c.wc_product_id<>b.wc_product_id AND NOT ({$shared} AND ".$this->customer_code_pair_sql('c.wc_product_id','c.code',$catalog).")");
        if ($this->db->last_error) { return $this->fail('بررسی ارتباط کدهای انبار ناموفق بود.'); }
        $unavailable = (int)$this->db->get_var("SELECT COUNT(*) FROM {$this->inventory_balance} b
            LEFT JOIN {$this->db->posts} p ON p.ID=b.wc_product_id WHERE NOT ({$valid}) OR p.ID IS NULL OR NOT ({$active})");
        if ($this->db->last_error) { return $this->fail('بررسی کدهای قابل انتخاب ناموفق بود.'); }
        $notice = ($conflicts || $unavailable) ? 'برخی کدهای قدیمی به علت ناسازگاری محصول، غیرفعال بودن محصول یا قالب نامعتبر قابل انتخاب نیستند؛ مدیر باید آن موارد را بررسی کند. کدهای معتبر انبار بارگذاری شده‌اند.' : '';
        return $this->ok('', ['added'=>(int)$added, 'conflicts'=>$conflicts, 'unavailable'=>$unavailable, 'notice'=>$notice]);
    }
    public function production_code_search_report(string $search, int $page=1): array {
        $sync=$this->seed_production_codes();if($sync['status']!=='success'){return $sync;}
        $search=$this->normalize_production_code(sanitize_text_field($search));$like='%'.$this->db->esc_like($search).'%';
        $table=$this->production_codes_table();$active=$this->production_product_sql('p');$verified=$this->production_code_verified_sql('c');
        $catalog=$this->customer_code_catalog();$canonical=$this->customer_code_case('p.ID',$catalog);
        $display="CASE WHEN ({$canonical})<>'' THEN ({$canonical}) ELSE c.code END";
        $shared=$this->customer_code_pair_sql('c.wc_product_id','c.code',$catalog);
        $otherShared=$this->customer_code_pair_sql('b.wc_product_id','b.unique_product_code',$catalog);
        $noConflict="NOT EXISTS (SELECT 1 FROM {$this->inventory_balance} b WHERE b.unique_product_code=c.code AND b.wc_product_id<>c.wc_product_id AND NOT ({$shared} AND {$otherShared}))";
        $hasCode="EXISTS (SELECT 1 FROM {$table} c WHERE c.wc_product_id=p.ID AND {$verified} AND {$noConflict})";
        $hasStock="EXISTS (SELECT 1 FROM {$this->inventory_balance} existing_stock WHERE existing_stock.wc_product_id=p.ID)";
        $union="SELECT CAST(c.id AS CHAR) AS id,c.code,c.wc_product_id,p.post_title AS title,{$display} AS display_code,0 AS catalog_selection,
            CASE WHEN EXISTS (SELECT 1 FROM {$this->inventory_balance} stock WHERE stock.unique_product_code=c.code AND stock.wc_product_id=c.wc_product_id) THEN 1 ELSE 0 END AS in_inventory
            FROM {$table} c INNER JOIN {$this->db->posts} p ON p.ID=c.wc_product_id WHERE {$active} AND {$verified} AND {$noConflict}
            UNION ALL SELECT CONCAT('catalog-',p.ID) AS id,{$canonical} AS code,p.ID AS wc_product_id,p.post_title AS title,{$canonical} AS display_code,1 AS catalog_selection,0 AS in_inventory
            FROM {$this->db->posts} p WHERE {$active} AND ({$canonical})<>'' AND NOT ({$hasCode}) AND NOT ({$hasStock})";
        $normalizedCode=$this->production_code_sql('choices.code');$normalizedTitle=$this->production_code_sql('choices.title');
        $items=$this->db->get_results($this->db->prepare("SELECT * FROM ({$union}) choices
            WHERE {$normalizedCode} LIKE %s OR choices.display_code LIKE %s OR {$normalizedTitle} LIKE %s
            ORDER BY (choices.display_code=%s) DESC,choices.title,choices.code,choices.wc_product_id,choices.id LIMIT 30 OFFSET %d",
            $like,$like,$like,$search,(max(1,min(100000,$page))-1)*30),ARRAY_A);
        if($this->db->last_error){return $this->fail('خواندن فهرست کدهای محصول ناموفق بود؛ دوباره تلاش کنید.');}
        $title=$this->production_code_sql('p.post_title');
        $uncoded=$this->db->get_results($this->db->prepare("SELECT p.ID AS product_id,p.post_title AS title FROM {$this->db->posts} p
            WHERE {$active} AND {$title} LIKE %s AND NOT ({$hasCode}) AND (({$canonical})='' OR {$hasStock}) ORDER BY p.post_title,p.ID LIMIT 30",$like),ARRAY_A);
        if($this->db->last_error){return $this->fail('بررسی محصولات بدون کد تولید انجام نشد.');}
        return $this->ok('', ['items'=>$items?:[], 'uncoded_products'=>$uncoded?:[], 'notice'=>$sync['data']['notice']]);
    }
    public function search_production_codes(string $search, int $page=1): array {
        $result=$this->production_code_search_report($search,$page);
        return $result['status']==='success' ? $result['data']['items'] : [];
    }

    public function register_production_code(string $code,int $product_id):array{
        if(!current_user_can('manage_options')){return $this->fail('تعریف کد تولید فقط برای مدیر مجاز است.');}
        $code=$this->normalize_production_code(sanitize_text_field($code));
        if($code===''||mb_strlen($code)>64||preg_match('/[\x00-\x1f\x7f<>]/u',$code)){return $this->fail('کد تولید معتبر نیست؛ حداکثر ۶۴ نویسه وارد کنید.');}
        $product=get_post($product_id);if(!$product||$product->post_type!=='product'||$product->post_status!=='publish'){return $this->fail('محصول معتبر و منتشرشده را انتخاب کنید.');}
        if($this->customer_code_reserved($code)&&!$this->customer_code_shared($code,$product_id)){return $this->fail('این کد در فهرست مشتری برای نوع و وزن دیگری تعریف شده است.');}
        $lock=$this->production_code_lock($code);
        if((int)$this->db->get_var($this->db->prepare('SELECT GET_LOCK(%s,10)',$lock))!==1){return $this->fail('تعریف این کد در حال انجام است؛ دوباره تلاش کنید.');}
        try{
            $table=$this->production_codes_table();$sync=$this->seed_production_codes();if($sync['status']!=='success'){return $sync;}
            $canonical=$this->customer_product_code($product_id);$shared=$this->customer_code_shared($code,$product_id);
            // A customer code is also a lookup alias for the established stock code.
            if($shared){
                $stock=$this->db->get_results($this->db->prepare("SELECT c.id FROM {$table} c INNER JOIN {$this->inventory_balance} b ON b.unique_product_code=c.code AND b.wc_product_id=c.wc_product_id WHERE c.wc_product_id=%d",$product_id),ARRAY_A);
                $usable=[];foreach($stock?:[] as $row){$pair=$this->get_production_code((int)$row['id']);if($pair){$usable[]=$pair;}}
                if(count($usable)===1){return $this->ok('کد مشتری به موجودی همین محصول متصل است؛ همان ردیف موجود انتخاب شد.',$this->production_code_result($usable[0],$product));}
                if(count($usable)>1){return $this->fail('این محصول چند کد انبار دارد؛ ردیف موردنظر را از فهرست مشترک انتخاب کنید.');}
            }
            $normal=$this->production_code_sql('c.code');
            $existing=$this->db->get_results($this->db->prepare("SELECT c.* FROM {$table} c WHERE {$normal}=%s ORDER BY (c.code=%s) DESC,c.id",$code,$code),ARRAY_A);
            if($this->db->last_error){return $this->fail('بررسی کد موجود ناموفق بود.');}
            foreach($existing?:[] as $row){
                if((int)$row['wc_product_id']!==$product_id&&(!$shared||!$this->customer_code_shared($code,(int)$row['wc_product_id']))){return $this->fail('این کد به محصول دیگری متصل است؛ کد مشترک فقط برای محصولات مطابق فهرست مشتری مجاز است.');}
            }
            foreach($existing?:[] as $row){if((int)$row['wc_product_id']===$product_id){
                $pair=$this->get_production_code((int)$row['id']);
                if(!$pair&&(int)$row['created_by']===0){
                    $foreign=$this->db->get_col($this->db->prepare("SELECT wc_product_id FROM {$this->inventory_balance} WHERE unique_product_code=%s AND wc_product_id<>%d",$row['code'],$product_id));
                    $safe=!$this->db->last_error;
                    foreach($foreign?:[] as $other){if(!$shared||!$this->customer_code_shared($code,(int)$other)){$safe=FALSE;}}
                    if($safe&&FALSE!==$this->db->update($table,['created_by'=>get_current_user_id()],['id'=>(int)$row['id'],'created_by'=>0])){
                        $pair=$this->get_production_code((int)$row['id']);
                        if(!$pair){$this->db->update($table,['created_by'=>0],['id'=>(int)$row['id']]);}
                    }
                }
                if(!$pair){return $this->fail('کد موجود ناسازگار یا تأییدنشده است؛ مدیر باید آن را بررسی کند.');}
                return $this->ok('کد موجود انتخاب شد؛ ردیف انبار جدید ایجاد نمی‌شود.',$this->production_code_result($pair,$product));
            }}
            if($shared&&!$this->customer_production_schema_ready()){return $this->fail('مدیر باید از ابزارهای ثبت یکپارچه، پشتیبانی کدهای مشترک را آماده کند.');}
            foreach([$this->inventory_balance,$this->shop_conversions,$this->inventory_log,$this->order_items] as $history){
                $normalized=$this->production_code_sql('unique_product_code');
                $rows=$this->db->get_results($this->db->prepare("SELECT wc_product_id FROM {$history} WHERE {$normalized}=%s",$code),ARRAY_A);
                if($this->db->last_error){return $this->fail('بررسی سابقه کد انجام نشد.');}
                foreach($rows?:[] as $row){if((int)$row['wc_product_id']===$product_id||!$shared||!$this->customer_code_shared($code,(int)$row['wc_product_id'])){return $this->fail('این کد سابقه دارد و برای تعریف مجدد باید بررسی شود.');}}
            }
            if(FALSE===$this->db->insert($table,['code'=>$code,'wc_product_id'=>$product_id,'created_by'=>get_current_user_id(),'created_at'=>current_time('mysql')])){return $this->fail('تعریف کد انجام نشد؛ وضعیت کد را بررسی کنید.');}
            return $this->ok('کد تولید تعریف شد.',$this->production_code_result(['id'=>(int)$this->db->insert_id,'code'=>$code,'wc_product_id'=>$product_id],$product));
        }finally{$this->db->get_var($this->db->prepare('SELECT RELEASE_LOCK(%s)',$lock));}
    }
    private function production_code_result(array $pair,$product):array{
        return ['id'=>$pair['id'],'code'=>$pair['code'],'display_code'=>$this->customer_product_code((int)$pair['wc_product_id'])?:$pair['code'],'wc_product_id'=>(int)$pair['wc_product_id'],'title'=>$product->post_title];
    }
    public function get_production_code(int $id):?array{
        $table=$this->production_codes_table();$active=$this->production_product_sql('p');$verified=$this->production_code_verified_sql('c');
        $catalog=$this->customer_code_catalog();$shared=$this->customer_code_pair_sql('c.wc_product_id','c.code',$catalog);$otherShared=$this->customer_code_pair_sql('b.wc_product_id','b.unique_product_code',$catalog);
        $row=$this->db->get_row($this->db->prepare("SELECT c.* FROM {$table} c INNER JOIN {$this->db->posts} p ON p.ID=c.wc_product_id
            WHERE c.id=%d AND {$active} AND {$verified} AND NOT EXISTS (SELECT 1 FROM {$this->inventory_balance} b WHERE b.unique_product_code=c.code AND b.wc_product_id<>c.wc_product_id AND NOT ({$shared} AND {$otherShared}))",$id),ARRAY_A);
        if($row){$row['display_code']=$catalog[(int)$row['wc_product_id']]??$row['code'];}return $row;
    }

    public function production_conversion_conflicts():array{
        $catalog=$this->customer_code_catalog();$left=$this->customer_code_pair_sql('sc.wc_product_id','sc.unique_product_code',$catalog);$right=$this->customer_code_pair_sql('ib.wc_product_id','ib.unique_product_code',$catalog);
        return $this->db->get_results("SELECT sc.id,sc.unique_product_code AS code,sc.qty_items,sc.weight_per_item,sc.packaging_cost_per_item,sc.packaging_lot_id,sc.wc_product_id AS wrong_product_id,ib.wc_product_id AS expected_product_id,p.post_title AS wrong_title,ep.post_title AS expected_title
            FROM {$this->shop_conversions} sc INNER JOIN {$this->inventory_balance} ib ON ib.unique_product_code=sc.unique_product_code
            LEFT JOIN {$this->db->posts} p ON p.ID=sc.wc_product_id LEFT JOIN {$this->db->posts} ep ON ep.ID=ib.wc_product_id
            WHERE sc.wc_product_id<>ib.wc_product_id AND NOT ({$left} AND {$right}) ORDER BY sc.id",ARRAY_A)?:[];
    }

	/** Repair only an unfulfilled, incomplete conversion. Unit changes require explicit administrator input. */
	public function repair_incomplete_conversion( int $conversion_id, ?float $weight_per_item = NULL ): array {
		if ( ! current_user_can( 'manage_options' ) || ! $this->workflow_storage_ready( 'production' ) ) { return $this->fail( 'آماده‌سازی ثبت یکپارچه و دسترسی مدیر لازم است.' ); }
		if ( FALSE === $this->db->query( 'START TRANSACTION' ) ) { return $this->fail( 'تراکنش آغاز نشد.' ); }
		$abort = function( string $message ): array { $this->db->query( 'ROLLBACK' ); return $this->fail( $message ); };
		$c = $this->db->get_row( $this->db->prepare( "SELECT * FROM {$this->shop_conversions} WHERE id = %d FOR UPDATE", $conversion_id ), ARRAY_A );
		if ( ! $c ) { return $abort( 'تبدیل یافت نشد.' ); }
		if ((int)$this->db->get_var($this->db->prepare("SELECT COUNT(*) FROM {$this->inventory_balance} WHERE unique_product_code=%s",$c['unique_product_code'])) !== 1) { $this->db->query('ROLLBACK'); return $this->fail('این کد به چند محصول متصل است؛ اصلاح خودکار این رکورد مجاز نیست.'); }
		$b = $this->db->get_row( $this->db->prepare( "SELECT * FROM {$this->inventory_balance} WHERE unique_product_code = %s FOR UPDATE", $c['unique_product_code'] ), ARRAY_A );
		if ( ! $b || (int) $b['wc_product_id'] === (int) $c['wc_product_id'] ) { return $abort( 'این تبدیل ناسازگار نیست یا قبلاً اصلاح شده است.' ); }
		$baseline = $this->db->get_row( $this->db->prepare( "SELECT COALESCE(SUM(change_qty),0) AS qty, COALESCE(SUM(total_cost),0) AS value
			FROM {$this->inventory_log} WHERE unique_product_code = %s AND wc_product_id = %d", $c['unique_product_code'], $b['wc_product_id'] ), ARRAY_A );
		if ( ! $baseline || (int) $baseline['qty'] !== (int) $b['qty_available'] || abs( (float) $baseline['value'] - (float) $b['inventory_value'] ) > 0.01 ) {
			return $abort( 'موجودی با گردش ثبت‌شده مطابقت ندارد؛ اصلاح خودکار مجاز نیست.' );
		}
		$logs = $this->db->get_results( $this->db->prepare( "SELECT * FROM {$this->inventory_log}
			WHERE unique_product_code = %s AND wc_product_id = %d FOR UPDATE", $c['unique_product_code'], $c['wc_product_id'] ), ARRAY_A );
		if ( count( $logs ) !== 1 || $logs[0]['ref_type'] !== 'production' || (int) $logs[0]['ref_id'] !== $conversion_id
			|| (int) $logs[0]['change_qty'] !== (int) $c['qty_items'] || (float) $logs[0]['total_cost'] !== (float) $c['total_cost'] ) {
			return $abort( 'این مورد سابقه دیگری دارد و نیازمند بررسی دستی است.' );
		}
		$move = $this->db->get_row( $this->db->prepare( "SELECT * FROM {$this->packaging_moves}
			WHERE packaging_lot_id = %d AND reason = 'convert_to_shop_product' AND ref_type = 'shop_conversion' AND ref_id = %d FOR UPDATE", $c['packaging_lot_id'], $conversion_id ), ARRAY_A );
		if ( ! $move || abs( (float) $move['qty_weight'] - (int) $c['qty_items'] * (float) $c['weight_per_item'] ) > 0.000001 ) {
			return $abort( 'گردش خروج سالن با تبدیل مطابقت ندارد.' );
		}
		$qty = (int) $c['qty_items'];
		$weight = (float) $c['weight_per_item'];
		$packaging_total = (float) $c['total_packaging_cost'];
		$total_cost = (float) $c['total_cost'];
		$unit_cost = (float) $c['unit_cost_final'];
		if ( $weight_per_item !== NULL && $weight_per_item !== $weight ) {
			if ( ! is_finite( $weight_per_item ) || $weight_per_item <= 0 ) { return $abort( 'وزن هر آیتم معتبر نیست.' ); }
			$weight = round( $weight_per_item, 6 );
			if ( $weight <= 0 ) { return $abort( 'وزن هر آیتم معتبر نیست.' ); }
			$qty = (int) round( (float) $move['qty_weight'] / $weight );
			if ( $qty <= 0 || abs( $qty * $weight - (float) $move['qty_weight'] ) > 0.000001 ) {
				return $abort( 'وزن کل باید دقیقاً به تعداد صحیح آیتم تقسیم شود؛ اصلاح دستی لازم است.' );
			}
			$packaging_total = round( $qty * (float) $c['packaging_cost_per_item'], 2 );
			$total_cost = round( (float) $c['total_material_cost'] + $packaging_total, 2 );
			$unit_cost = round( $total_cost / $qty, 2 );
		}
		if ( FALSE === $this->db->update( $this->shop_conversions, [ 'wc_product_id' => (int) $b['wc_product_id'], 'qty_items' => $qty, 'weight_per_item' => $weight,
			'total_packaging_cost' => $packaging_total, 'total_cost' => $total_cost, 'unit_cost_final' => $unit_cost ], [ 'id' => $conversion_id ] )
			|| FALSE === $this->db->update( $this->inventory_log, [ 'wc_product_id' => (int) $b['wc_product_id'], 'change_qty' => $qty,
			'unit_cost' => $unit_cost, 'total_cost' => $total_cost ], [ 'id' => (int) $logs[0]['id'] ] ) ) {
			return $abort( 'اصلاح ارتباط محصول انجام نشد.' );
		}
		$result = $this->apply_inventory_change( [ 'unique_product_code' => $c['unique_product_code'], 'wc_product_id' => (int) $b['wc_product_id'], 'change_qty' => $qty, 'total_cost' => $total_cost ] );
		if ( $result['status'] !== 'success' ) { return $abort( $result['message'] ); }
		$audit = $this->update_shop_conversion_meta( $conversion_id, 'product_mapping_repair', [ 'old_product_id' => (int) $c['wc_product_id'], 'new_product_id' => (int) $b['wc_product_id'],
			'old_qty' => (int) $c['qty_items'], 'new_qty' => $qty, 'old_weight' => (float) $c['weight_per_item'], 'new_weight' => $weight,
			'old_total_cost' => (float) $c['total_cost'], 'new_total_cost' => $total_cost, 'actor_id' => get_current_user_id(), 'at' => current_time( 'mysql' ) ] );
		if ( $audit['status'] !== 'success' || FALSE === $this->db->query( 'COMMIT' ) ) { return $abort( 'ذخیره اصلاحات کامل نشد.' ); }
		return $this->ok( 'ارتباط محصول اصلاح و موجودی تکمیل شد؛ تعداد: ' . $qty . '، وزن هر آیتم: ' . $weight . ' کیلوگرم.' );
	}

	public function set_cheque_note_print( int $cheque_id, bool $show ): array {
		if ( ! current_user_can( 'manage_options' ) || ! $this->get_cheque( $cheque_id ) ) { return $this->fail( 'چک معتبر یا دسترسی مدیر لازم است.' ); }
		return $this->update_cheque_meta( $cheque_id, 'admin_note_print', $show ? '1' : '0' );
	}
}
