<?php
if(!defined('ABSPATH')){exit;}
trait kph_customer_product_codes {
    public function customer_product_code_rules():array{
        return [
            ['family'=>'saffron','name'=>'زعفران نیم گرمی','weight'=>'0.5','code'=>'05220'],
            ['family'=>'saffron','name'=>'زعفران ۱ گرمی','weight'=>'1','code'=>'01220'],
            ['family'=>'saffron','name'=>'زعفران ۱ مثقالی','weight'=>'mithqal','code'=>'46220'],
            ['family'=>'saffron','name'=>'زعفران نیم مثقالی','weight'=>'half_mithqal','code'=>'23220'],
            ['family'=>'saffron','name'=>'زعفران ۲ گرمی','weight'=>'2','code'=>'02220'],
            ['family'=>'saffron','name'=>'زعفران ۱۵۰ سوت','weight'=>'0.15','code'=>'150220'],
            ['family'=>'saffron','name'=>'زعفران ۲۰۰ سوت','weight'=>'0.2','code'=>'200220'],
            ['family'=>'saffron','name'=>'زعفران ۳۰۰ سوت','weight'=>'0.3','code'=>'300220'],
            ['family'=>'saffron','name'=>'زعفران ۴۰۰ سوت','weight'=>'0.4','code'=>'400220'],
            ['family'=>'cardamom','name'=>'هل ۵ گرمی','weight'=>'5','code'=>'0505330'],
            ['family'=>'cardamom_powder','name'=>'پودر هل ۵ گرمی','weight'=>'5','code'=>'0505331'],
            ['family'=>'cardamom','name'=>'هل ۲٫۵ گرمی','weight'=>'2.5','code'=>'2505330'],
            ['family'=>'vanilla','name'=>'وانیل ۴ گرمی','weight'=>'4','code'=>'041100'],
            ['family'=>'barberry','name'=>'همه زرشک‌ها','weight'=>'any','code'=>'600'],
            ['family'=>'jujube','name'=>'همه عناب‌ها','weight'=>'any','code'=>'700'],
        ];
    }
    private function customer_product_name(string $name):string{
        $name=$this->normalize_production_code($name);
        return trim(preg_replace('/\s+/u',' ',strtr($name,['ي'=>'ی','ك'=>'ک','٫'=>'.',','=>'.','،'=>'.','‌'=>' '])));
    }
    /** Classify the actual product title; grade suffixes never change its customer code. */
    public function customer_product_code(int $product):string{
        $post=get_post($product);
        if(!$post||$post->post_type!=='product'||$post->post_status!=='publish'){return '';}
        $code=$this->db->get_var($this->db->prepare("SELECT meta_value FROM {$this->db->postmeta} WHERE post_id=%d AND meta_key=%s ORDER BY meta_id DESC LIMIT 1",$product,'_kph_product_code'));
        if(is_string($code)&&$code!==''){return $code;}
        return $this->customer_code_for_title((string)$post->post_title);
    }
    private function customer_code_for_title(string $title):string{
        $name=$this->customer_product_name($title);$family='';
        if(preg_match('/^زرشک(?:\s|\(|$)/u',$name)){return '600';}
        if(preg_match('/^عناب(?:\s|\(|$)/u',$name)){return '700';}
        if(preg_match('/^زعفران(?:\s|\(|$)/u',$name)){$family='saffron';}
        elseif(preg_match('/^پودر\s*هل(?:\s|\(|$)/u',$name)){$family='cardamom_powder';}
        elseif(preg_match('/^هل(?:\s|\(|$)/u',$name)){$family='cardamom';}
        elseif(preg_match('/^(?:پودر\s*)?وانیل(?:\s|\(|$)/u',$name)){$family='vanilla';}
        if(!$family||preg_match('/(?:کیلویی|کیلوگرم|\bkg\b)/iu',$name)){return '';}
        $weight='';
        if(preg_match('/نیم\s*مثقال/u',$name)){$weight='half_mithqal';}
        elseif(preg_match('/(?:1|یک)\s*مثقال/u',$name)){$weight='mithqal';}
        elseif(preg_match('/(?:نیم|0\.5)\s*گرم/u',$name)){$weight='0.5';}
        elseif(preg_match('/(?<![0-9.])([0-9]+(?:\.[0-9]+)?)\s*(گرم|سوت)/u',$name,$m)){
            $value=(float)$m[1];if($m[2]==='سوت'){$value/=1000;}$weight=(string)$value;
        }else{
            foreach(['یک'=>'1','دو'=>'2','پنج'=>'5','چهار'=>'4'] as $word=>$value){if(preg_match('/'.$word.'\s*گرم/u',$name)){$weight=$value;break;}}
        }
        foreach($this->customer_product_code_rules() as $rule){if($rule['family']===$family&&$rule['weight']===$weight){return $rule['code'];}}
        return '';
    }
    private function customer_code_catalog():array{
        $rows=$this->sales_product_code_catalog();
        $map=[];foreach($rows as $row){if($row['code']!==''){$map[$row['id']]=$row['code'];}}
        return $map;
    }
    public function customer_product_code_report():array{
        $rules=$this->customer_product_code_rules();$rows=$this->db->get_results("SELECT ID,post_title FROM {$this->db->posts} WHERE post_type='product' AND post_status='publish' ORDER BY ID",ARRAY_A);
        foreach($rules as &$rule){$rule['products']=[];foreach($rows?:[] as $row){if($this->customer_code_for_title($row['post_title'])===$rule['code']){$rule['products'][]=['id'=>(int)$row['ID'],'title'=>$row['post_title']];}}}unset($rule);return $rules;
    }
    private function customer_code_case(string $productColumn,array $map):string{
        if(!$map){return "''";}
        $sql='CASE '.$productColumn;foreach($map as $id=>$code){$sql.=$this->db->prepare(' WHEN %d THEN %s',$id,$code);}return $sql." ELSE '' END";
    }
    private function customer_code_pair_sql(string $productColumn,string $codeColumn,array $map):string{
        if(!$map){return '0=1';}
        return '('.$this->customer_code_case($productColumn,$map).'='.$this->production_code_sql($codeColumn).' AND '.$this->customer_code_case($productColumn,$map)."<>'')";
    }
    private function customer_code_reserved(string $code):bool{
        return in_array($this->normalize_production_code($code),array_column($this->customer_product_code_rules(),'code'),TRUE);
    }
    private function customer_code_shared(string $code,int $product):bool{
        $code=$this->normalize_production_code($code);
        $expected=$this->customer_product_code($product);
        if($expected!==''){return $expected===$code;}
        // An archived product still identifies its legitimate historical family/weight.
        // It remains excluded from the published catalog and new product selection.
        $post=get_post($product);
        if(!$post||$post->post_type!=='product'||!in_array($post->post_status,['draft','private','pending','trash'],TRUE)){return FALSE;}
        $explicit=$this->db->get_var($this->db->prepare("SELECT meta_value FROM {$this->db->postmeta} WHERE post_id=%d AND meta_key='_kph_product_code' ORDER BY meta_id DESC LIMIT 1",$product));
        if($this->db->last_error||($explicit!==NULL&&$explicit!==''&&$this->normalize_production_code((string)$explicit)!==$code)){return FALSE;}
        return $this->customer_code_reserved($code)&&$this->customer_code_for_title((string)$post->post_title)===$code;
    }
    private function production_code_lock(string $code):string{return 'kph_code_'.substr(hash('sha256',$this->db_prefix.$this->normalize_production_code($code)),0,44);}
    private function production_pair_indexes():array{
        return [$this->production_codes_table()=>['code','wc_product_id'],$this->inventory_balance=>['unique_product_code','wc_product_id']];
    }
    private function production_index_groups(string $table):array{
        $groups=[];
        foreach($this->db->get_results("SHOW INDEX FROM `{$table}`",ARRAY_A)?:[] as $row){
            if((int)$row['Non_unique']===0){$groups[$row['Key_name']][(int)$row['Seq_in_index']]=$row['Column_name'];}
        }
        foreach($groups as &$columns){ksort($columns);$columns=array_values($columns);}unset($columns);return $groups;
    }
    private function customer_production_schema_ready():bool{
        foreach($this->production_pair_indexes() as $table=>$columns){$groups=$this->production_index_groups($table);if(!in_array($columns,$groups,TRUE)||in_array([$columns[0]],$groups,TRUE)){return FALSE;}}
        return TRUE;
    }
    private function prepare_customer_production_schema():array{
        foreach($this->production_pair_indexes() as $table=>$columns){
            $groups=$this->production_index_groups($table);if($this->db->last_error){return $this->fail('بررسی شاخص‌های کد و محصول انجام نشد.');}
            if(!in_array($columns,$groups,TRUE)){
                if(FALSE===$this->db->query("ALTER TABLE `{$table}` ADD UNIQUE KEY customer_code_product (`{$columns[0]}`,`{$columns[1]}`)")){return $this->fail('آماده‌سازی ارتباط کد و محصول انجام نشد.');}
            }
            foreach($groups as $name=>$existing){
                if($existing===[$columns[0]]){$name=str_replace('`','``',$name);if(FALSE===$this->db->query("ALTER TABLE `{$table}` DROP INDEX `{$name}`")){return $this->fail('آماده‌سازی کدهای مشترک انجام نشد.');}}
            }
        }
        return $this->customer_production_schema_ready()?$this->ok('کد و شناسه محصول آماده شدند.'):$this->fail('آماده‌سازی کدهای مشترک کامل نشد.');
    }
    /** A catalog selection is approved by the customer's fixed code rules, not a store SKU. */
    public function get_production_selection($selection):?array{
        if(!is_scalar($selection)){return NULL;}$selection=(string)$selection;
        if(preg_match('/^[0-9]+$/D',$selection)){return $this->get_production_code((int)$selection);}
        if(!preg_match('/^catalog-([1-9][0-9]*)$/D',$selection,$match)){return NULL;}
        $id=(int)$match[1];$code=$this->customer_product_code($id);if($code===''){return NULL;}
        $row=$this->db->get_row($this->db->prepare('SELECT id FROM '.$this->production_codes_table().' WHERE wc_product_id=%d AND code=%s',$id,$code),ARRAY_A);
        if($row){$pair=$this->get_production_code((int)$row['id']);if($pair){return $pair;}}
        // A stale first-production choice must never create a second stock row.
        if($this->db->get_var($this->db->prepare("SELECT id FROM {$this->inventory_balance} WHERE wc_product_id=%d LIMIT 1",$id))){return NULL;}
        $rows=$this->db->get_results($this->db->prepare('SELECT id FROM '.$this->production_codes_table().' WHERE wc_product_id=%d',$id),ARRAY_A);
        foreach($rows?:[] as $row){if($this->get_production_code((int)$row['id'])){return NULL;}}
        return ['id'=>$selection,'code'=>$code,'display_code'=>$code,'wc_product_id'=>$id,'catalog_selection'=>TRUE];
    }
}
