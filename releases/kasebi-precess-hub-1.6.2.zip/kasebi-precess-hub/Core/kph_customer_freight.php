<?php
if(!defined('ABSPATH')){exit;}
trait kph_customer_freight {
    private function freight_table():string{return $this->db_prefix.'customer_freight';}
    private function create_customer_freight_table():void{
        $t=$this->freight_table();
        maybe_create_table($t,"CREATE TABLE {$t} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            customer_id BIGINT UNSIGNED NOT NULL, customer_name VARCHAR(190) NOT NULL,
            customer_phone VARCHAR(64) NOT NULL DEFAULT '', amount BIGINT NOT NULL,
            payment_id BIGINT UNSIGNED NOT NULL, transaction_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            account_id BIGINT UNSIGNED NOT NULL, ledger_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            invoice_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            request_key VARCHAR(64) NOT NULL, request_hash CHAR(64) NOT NULL,
            status VARCHAR(16) NOT NULL DEFAULT 'active', paid_at DATETIME NOT NULL,
            note TEXT NOT NULL, created_by BIGINT UNSIGNED NOT NULL, created_at DATETIME NOT NULL,
            canceled_by BIGINT UNSIGNED NOT NULL DEFAULT 0, canceled_at DATETIME NULL,
            cancel_reason TEXT NULL, reversal_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            version INT UNSIGNED NOT NULL DEFAULT 1,
            UNIQUE KEY request_key(request_key), UNIQUE KEY payment_id(payment_id),
            KEY customer_date(customer_id,paid_at), KEY transaction_id(transaction_id)
        ) ENGINE=InnoDB ".$this->db->get_charset_collate());
    }
    public function freight_allowed(bool $write=FALSE):bool{
        return is_user_logged_in()&&(current_user_can('manage_options')||in_array(nooshika_get_user_role(get_current_user_id()),$write?['accountant']:['accountant','supp'],TRUE));
    }
    public function freight_category_key():string{
        $key=get_option('kph_customer_freight_category','Customer Freight Charges');
        return is_string($key)&&$key!==''?$key:'Customer Freight Charges';
    }
    private function freight_tables():array{
        return [$this->freight_table(),$this->payments,$this->db_prefix.'payment_meta',$this->ledger_entries,$this->db_prefix.'ledger_entry_meta',$this->accounts,$this->account_transactions,$this->db_prefix.'account_transaction_meta'];
    }
    public function freight_storage_ready():bool{
        foreach($this->freight_tables() as $table){
            $r=$this->db->get_row($this->db->prepare('SHOW TABLE STATUS LIKE %s',$this->db->esc_like($table)),ARRAY_A);
            if(!$r||strcasecmp($r['Engine'],'InnoDB')){return FALSE;}
        }
        $id=absint(get_option('kph_customer_freight_account',0));
        return $id>0&&(bool)$this->db->get_var($this->db->prepare("SELECT id FROM {$this->accounts} WHERE id=%d AND type='expense' AND status='active'",$id));
    }
    public function prepare_customer_freight():array{
        if(!current_user_can('manage_options')){return $this->fail('آماده‌سازی کرایه فقط برای مدیر مجاز است.');}
        $lock='kph_freight_setup_'.substr(hash('sha256',$this->db_prefix),0,24);
        if((int)$this->db->get_var($this->db->prepare('SELECT GET_LOCK(%s,10)',$lock))!==1){return $this->fail('آماده‌سازی هم‌زمان است؛ دوباره تلاش کنید.');}
        try{
            foreach($this->freight_tables() as $table){
                $r=$this->db->get_row($this->db->prepare('SHOW TABLE STATUS LIKE %s',$this->db->esc_like($table)),ARRAY_A);
                if(!$r){return $this->fail('جدول ثبت کرایه یافت نشد.');}
                if(strcasecmp($r['Engine'],'InnoDB')&&FALSE===$this->db->query("ALTER TABLE `{$table}` ENGINE=InnoDB")){return $this->fail('آماده‌سازی ثبت یکپارچه انجام نشد.');}
            }
            $key=$this->freight_category_key();$categories=get_option('kph_cost_category',[]);$categories=is_array($categories)?$categories:[];
            if(!isset($categories[$key])){
                $matches=[];foreach($categories as $k=>$v){if(trim($v['label']??'')==='کرایه مشتریان'){$matches[]=$k;}}
                if(count($matches)===1){$key=(string)$matches[0];}
                else{$categories[$key]=['label'=>'کرایه مشتریان'];update_option('kph_cost_category',$categories);}
            }
            update_option('kph_customer_freight_category',$key);
            $id=absint(get_option('kph_customer_freight_account',0));
            $valid=$id?$this->db->get_var($this->db->prepare("SELECT id FROM {$this->accounts} WHERE id=%d AND type='expense' AND status='active'",$id)):0;
            if(!$valid){
                $id=(int)$this->db->get_var($this->db->prepare("SELECT id FROM {$this->accounts} WHERE title=%s AND type='expense' AND status='active' ORDER BY id LIMIT 1",'کرایه مشتریان — تهاتر حساب'));
                if(!$id){
                    if(FALSE===$this->db->insert($this->accounts,['title'=>'کرایه مشتریان — تهاتر حساب','type'=>'expense','balance'=>0,'status'=>'active','created_by'=>get_current_user_id(),'created_at'=>current_time('mysql')])){return $this->fail('ایجاد حساب هزینه کرایه انجام نشد.');}
                    $id=(int)$this->db->insert_id;
                }
                update_option('kph_customer_freight_account',$id);
            }
            return $this->freight_storage_ready()?$this->ok('ثبت یکپارچه کرایه آماده شد.'): $this->fail('تنظیمات حساب هزینه ذخیره نشد؛ دوباره بررسی کنید.');
        }finally{$this->db->get_var($this->db->prepare('SELECT RELEASE_LOCK(%s)',$lock));}
    }
    public function freight_payment(int $payment):?array{
        return $this->db->get_row($this->db->prepare('SELECT * FROM '.$this->freight_table().' WHERE payment_id=%d',$payment),ARRAY_A);
    }
    private function freight_must($value):void{if($value===FALSE){throw new RuntimeException('ثبت یکپارچه کرایه ناموفق بود؛ هیچ تغییری اعمال نشد.');}}
    private function freight_transaction(int $account,int $amount,int $record,int $customer,string $name,string $paidAt,bool $reverse=FALSE):int{
        $a=$this->db->get_row($this->db->prepare("SELECT * FROM {$this->accounts} WHERE id=%d FOR UPDATE",$account),ARRAY_A);
        if(!$a||$a['type']!=='expense'||$a['status']!=='active'){throw new RuntimeException('حساب هزینه تهاتر معتبر نیست؛ مدیر باید آماده‌سازی را بررسی کند.');}
        $balance=(int)$a['balance']+($reverse?1:-1)*$amount;
        $this->freight_must($this->db->insert($this->account_transactions,['account_id'=>$account,'amount'=>$amount,'type'=>$reverse?'credit':'debit','action'=>$reverse?'customer_freight_reversal':'customer_freight','balance_after'=>$balance,'description'=>($reverse?'ابطال کرایه مشتری — ':'کرایه مشتری — ').$name.' #'.$record,'created_by'=>get_current_user_id(),'created_at'=>$paidAt]));
        $id=(int)$this->db->insert_id;
        $this->freight_must($this->db->update($this->accounts,['balance'=>$balance,'updated_at'=>current_time('mysql')],['id'=>$account]));
        $meta=['customer_freight_id'=>$record,'user_id'=>$customer,'cost_type'=>$this->freight_category_key(),'destination'=>$name];
        foreach($meta as $key=>$value){$this->freight_must($this->db->insert($this->db_prefix.'account_transaction_meta',['transaction_id'=>$id,'meta_key'=>$key,'meta_value'=>(string)$value]));}
        return $id;
    }
    public function add_customer_freight(array $data):array{
        if(!$this->freight_allowed(TRUE)){return $this->fail('ثبت پرداختی کرایه فقط برای مدیر یا حسابدار مجاز است.');}
        if(!$this->freight_storage_ready()){return $this->fail('مدیر باید ابتدا ثبت یکپارچه کرایه مشتریان را از گزارش کرایه آماده کند.');}
        $customer=absint($data['user_id']??0);$user=get_user_by('ID',$customer);
        if(!$user||!array_intersect(['subscriber','customer'],(array)$user->roles)){return $this->fail('پرداختی کرایه فقط برای حساب مشتری قابل ثبت است.');}
        $raw=$data['amount']??'';
        if(!is_scalar($raw)){return $this->fail('مبلغ کرایه معتبر نیست.');}
        $raw=str_replace([',','٬'],'',nooshika_sanitize_numbers((string)$raw));
        if(!preg_match('/^[0-9]+$/D',$raw)||(float)$raw<=0||(float)$raw>1000000000000){return $this->fail('مبلغ کرایه را به ریال و به‌صورت عدد صحیح مثبت وارد کنید.');}
        $amount=(int)$raw;$paid=trim((string)($data['paid_at']??''));
        $date=DateTimeImmutable::createFromFormat('!Y-m-d',substr($paid,0,10));
        if(!$date||$date->format('Y-m-d')!==substr($paid,0,10)||!preg_match('/^\d{4}-\d{2}-\d{2}( 00:00:00)?$/',$paid)){return $this->fail('تاریخ کرایه معتبر نیست.');}
        $paid=$date->format('Y-m-d').' 00:00:00';
        $invoice=absint($data['ref_id']??0);
        if($invoice){$order=$this->get_order_data($invoice);if(!$order||(int)$order['customer_id']!==$customer){return $this->fail('فاکتور مرتبط متعلق به این مشتری نیست.');}}
        $note=is_string($data['note']??NULL)?sanitize_textarea_field($data['note']):'';
        if(mb_strlen($note)>5000){return $this->fail('توضیحات کرایه حداکثر ۵۰۰۰ نویسه است.');}
        $attachment=$data['meta']['attachment']??'';
        $attachment=is_string($attachment)?sanitize_text_field($attachment):'';
        if(mb_strlen($attachment)>5000){return $this->fail('نشانی ضمیمه بیش از حد طولانی است.');}
        $request=$data['freight_request_key']??'';
        if(!is_string($request)||!preg_match('/^[a-zA-Z0-9-]{20,64}$/D',$request)){return $this->fail('شناسه فرم معتبر نیست؛ پنجره پرداخت را دوباره باز کنید.');}
        $hash=hash('sha256',wp_json_encode([$customer,$amount,$paid,$invoice,$note,$attachment,get_current_user_id()]));
        $name=function_exists('get_user_name_by_id')?get_user_name_by_id($customer):($user->display_name??'');
        $name=mb_substr(sanitize_text_field($name?:'مشتری #'.$customer),0,190);$phone=mb_substr(sanitize_text_field((string)get_user_meta($customer,'nooshika_phone_num',TRUE)),0,64);
        $table=$this->freight_table();$account=absint(get_option('kph_customer_freight_account',0));
        $lock='kph_freight_req_'.substr(hash('sha256',$this->db_prefix.$request),0,30);
        if((int)$this->db->get_var($this->db->prepare('SELECT GET_LOCK(%s,10)',$lock))!==1){return $this->fail('ثبت این فرم در حال انجام است؛ وضعیت پرداخت را بررسی کنید.');}
        try{
            $existing=$this->db->get_row($this->db->prepare("SELECT * FROM {$table} WHERE request_key=%s",$request),ARRAY_A);
            if($existing){return $existing['request_hash']===$hash&&$existing['status']==='active'?$this->ok('این پرداختی کرایه قبلاً ثبت شده است؛ دوباره کسر نشد.',['id'=>(int)$existing['id'],'payment_id'=>(int)$existing['payment_id']]):$this->fail('این فرم قبلاً استفاده یا ابطال شده است؛ پنجره پرداخت را دوباره باز کنید.');}
            $this->freight_must($this->db->query('START TRANSACTION'));
            $this->freight_must($this->db->insert($this->payments,['user_id'=>$customer,'amount'=>-$amount,'payment_method'=>'other','ref_id'=>$invoice?:NULL,'paid_at'=>$paid,'note'=>'پرداختی کرایه — '.$note,'created_at'=>current_time('mysql')]));$payment=(int)$this->db->insert_id;
            $this->freight_must($this->db->insert($table,['customer_id'=>$customer,'customer_name'=>$name,'customer_phone'=>$phone,'amount'=>$amount,'payment_id'=>$payment,'account_id'=>$account,'invoice_id'=>$invoice,'request_key'=>$request,'request_hash'=>$hash,'paid_at'=>$paid,'note'=>$note,'created_by'=>get_current_user_id(),'created_at'=>current_time('mysql')]));$id=(int)$this->db->insert_id;
            $trx=$this->freight_transaction($account,$amount,$id,$customer,$name,$paid);
            $ledger=$this->add_ledger_entry(['user_id'=>$customer,'entry_type'=>'customer_freight','type'=>'credit','amount'=>$amount,'ref_type'=>'payment','ref_id'=>$payment,'posted_at'=>$paid,'note'=>'کسر بابت کرایه مشتری #'.$id,'meta'=>['customer_freight_id'=>$id,'creator_id'=>get_current_user_id()]]);
            if($ledger['status']!=='success'){throw new RuntimeException('ثبت حسابداری کرایه انجام نشد؛ هیچ تغییری اعمال نشد.');}
            foreach(['customer_freight_id'=>$id,'payment_purpose'=>'customer_freight','attachment'=>$attachment,'creator_id'=>get_current_user_id()] as $k=>$v){$this->freight_must($this->db->insert($this->db_prefix.'payment_meta',['payment_id'=>$payment,'meta_key'=>$k,'meta_value'=>(string)$v]));}
            $this->freight_must($this->db->update($table,['transaction_id'=>$trx,'ledger_id'=>(int)$ledger['data']['id']],['id'=>$id]));
            $this->freight_must($this->db->query('COMMIT'));
            return $this->ok('پرداختی کرایه از حساب مشتری کسر و در هزینه کرایه مشتریان ثبت شد.',['id'=>$id,'payment_id'=>$payment]);
        }catch(Throwable $e){$this->db->query('ROLLBACK');return $this->fail($e instanceof RuntimeException?$e->getMessage():'ثبت کرایه ناموفق بود؛ هیچ تغییری اعمال نشد.');}
        finally{$this->db->get_var($this->db->prepare('SELECT RELEASE_LOCK(%s)',$lock));}
    }
    public function cancel_customer_freight(int $id,int $version,string $reason):array{
        if(!$this->freight_allowed(TRUE)){return $this->fail('پشتیبانی فقط دسترسی مشاهده کرایه دارد.');}
        if(!$this->freight_storage_ready()){return $this->fail('ثبت یکپارچه کرایه آماده نیست.');}
        $reason=sanitize_textarea_field($reason);if($reason===''||mb_strlen($reason)>2000){return $this->fail('علت ابطال را وارد کنید؛ حداکثر ۲۰۰۰ نویسه.');}
        $table=$this->freight_table();
        try{
            $this->freight_must($this->db->query('START TRANSACTION'));
            $r=$this->db->get_row($this->db->prepare("SELECT * FROM {$table} WHERE id=%d FOR UPDATE",$id),ARRAY_A);
            if(!$r||$r['status']!=='active'||(int)$r['version']!==$version){throw new RuntimeException('رکورد تغییر کرده یا قبلاً ابطال شده است؛ صفحه را تازه کنید.');}
            $reverse=$this->freight_transaction((int)$r['account_id'],(int)$r['amount'],$id,(int)$r['customer_id'],$r['customer_name'],current_time('mysql'),TRUE);
            $ledger=$this->add_ledger_entry(['user_id'=>(int)$r['customer_id'],'entry_type'=>'customer_freight_reversal','type'=>'debit','amount'=>(int)$r['amount'],'ref_type'=>'customer_freight','ref_id'=>$id,'note'=>'ابطال کرایه مشتری #'.$id.' — '.$reason]);
            if($ledger['status']!=='success'){throw new RuntimeException('ثبت برگشت کرایه انجام نشد.');}
            $this->freight_must($this->db->insert($this->db_prefix.'account_transaction_meta',['transaction_id'=>(int)$r['transaction_id'],'meta_key'=>'freight_voided','meta_value'=>'1']));
            $this->freight_must($this->db->delete($this->db_prefix.'payment_meta',['payment_id'=>(int)$r['payment_id']]));
            $this->freight_must($this->db->delete($this->payments,['id'=>(int)$r['payment_id']]));
            $this->freight_must($this->db->update($table,['status'=>'canceled','canceled_by'=>get_current_user_id(),'canceled_at'=>current_time('mysql'),'cancel_reason'=>$reason,'reversal_id'=>(int)$ledger['data']['id'],'version'=>$version+1],['id'=>$id]));
            $this->freight_must($this->db->query('COMMIT'));return $this->ok('کرایه ابطال شد؛ کسر از حساب مشتری و هزینه آن برگشت داده شدند.');
        }catch(Throwable $e){$this->db->query('ROLLBACK');return $this->fail($e instanceof RuntimeException?$e->getMessage():'ابطال کرایه انجام نشد.');}
    }
    public function get_customer_freight_report(array $args=[]):array{
        if(!$this->freight_allowed()){return $this->fail('اجازه مشاهده کرایه مشتریان را ندارید.');}
        $args=wp_parse_args($args,['date_from'=>'','date_to'=>'','search'=>'','status'=>'active','page'=>1]);
        $page=max(1,min(100000,(int)$args['page']));$status=in_array($args['status'],['active','canceled','all'],TRUE)?$args['status']:'active';
        $meta=$this->db_prefix.'account_transaction_meta';$table=$this->freight_table();
        $joins="FROM {$this->account_transactions} t LEFT JOIN {$table} f ON f.transaction_id=t.id";
        foreach(['cost'=>'cost_type','destination'=>'destination','customer'=>'user_id'] as $alias=>$key){
            $joins.=" LEFT JOIN {$meta} {$alias} ON {$alias}.transaction_id=t.id AND {$alias}.meta_key='{$key}'
                AND {$alias}.id=(SELECT MAX(m.id) FROM {$meta} m WHERE m.transaction_id=t.id AND m.meta_key='{$key}')";
        }
        $joins.=" LEFT JOIN {$this->db->users} u ON u.ID=COALESCE(f.customer_id,CAST(customer.meta_value AS UNSIGNED))";
        $name="COALESCE(NULLIF(f.customer_name,''),NULLIF(destination.meta_value,''),u.display_name,'—')";
        $where=["t.type='debit'","cost.meta_value=%s"];$bind=[$this->freight_category_key()];
        if($status==='active'){$where[]="(f.id IS NULL OR f.status='active')";}elseif($status==='canceled'){$where[]="f.status='canceled'";}
        foreach(['date_from'=>'>=','date_to'=>'<='] as $key=>$op){
            if($args[$key]!==''){$date=DateTimeImmutable::createFromFormat('!Y-m-d',(string)$args[$key]);if(!$date||$date->format('Y-m-d')!==$args[$key]){return $this->fail('بازه تاریخ معتبر نیست.');}$where[]="t.created_at {$op} %s";$bind[]=$args[$key].($key==='date_from'?' 00:00:00':' 23:59:59');}
        }
        $search=trim(sanitize_text_field((string)$args['search']));
        if($search!==''){$like='%'.$this->db->esc_like($search).'%';$where[]="(CONVERT({$name} USING utf8mb4) COLLATE utf8mb4_unicode_ci LIKE %s OR CONVERT(f.customer_phone USING utf8mb4) COLLATE utf8mb4_unicode_ci LIKE %s OR CONVERT(t.description USING utf8mb4) COLLATE utf8mb4_unicode_ci LIKE %s OR f.payment_id=%d)";$bind=array_merge($bind,[$like,$like,$like,absint(nooshika_sanitize_numbers($search))]);}
        $whereSql=implode(' AND ',$where);
        $summary=$this->db->get_row($this->db->prepare("SELECT COUNT(*) AS total,COALESCE(SUM(t.amount),0) AS amount {$joins} WHERE {$whereSql}",$bind),ARRAY_A);
        if($this->db->last_error){return $this->fail('خواندن گزارش کرایه ناموفق بود.');}
        $rows=$this->db->get_results($this->db->prepare("SELECT t.id,t.created_at,t.amount,{$name} AS customer_name,
            COALESCE(f.customer_id,CAST(customer.meta_value AS UNSIGNED),0) AS customer_id,
            COALESCE(f.customer_phone,'') AS customer_phone,COALESCE(f.note,t.description,'') AS note,
            f.id AS record_id,f.payment_id,f.invoice_id,COALESCE(f.status,'active') AS status,f.version,
            COALESCE(f.created_by,t.created_by,0) AS created_by,f.cancel_reason,f.canceled_at,f.canceled_by
            {$joins} WHERE {$whereSql} ORDER BY t.created_at DESC,t.id DESC LIMIT 20 OFFSET %d",array_merge($bind,[($page-1)*20])),ARRAY_A);
        if($this->db->last_error){return $this->fail('خواندن ریز کرایه ناموفق بود.');}
        return $this->ok('',['items'=>$rows?:[],'total'=>(int)($summary['total']??0),'amount'=>(float)($summary['amount']??0),'pages'=>max(1,(int)ceil(($summary['total']??0)/20))]);
    }
}
