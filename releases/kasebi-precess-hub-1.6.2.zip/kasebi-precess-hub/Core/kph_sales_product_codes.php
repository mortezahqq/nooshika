<?php
if (!defined('ABSPATH')) { exit; }

/** Product lookup codes are metadata. Warehouse and production identities stay intact. */
trait kph_sales_product_codes {
    public function can_manage_sales_product_codes(): bool {
        $pages = get_kph_pages_list();
        return get_current_user_id() && (current_user_can('manage_options') || in_array(
            nooshika_get_user_role(get_current_user_id()), $pages['settings']['valid_roles'] ?? [], TRUE
        ));
    }

    private function valid_sales_product_code(string $code): bool {
        return $code !== '' && strlen($code) <= 64 && !preg_match('/[\x00-\x20\x7f<>]/u', $code);
    }

    public function sales_product_code_catalog(): array {
        $rows = $this->db->get_results("SELECT ID,post_title FROM {$this->db->posts}
            WHERE post_type='product' AND post_status='publish' ORDER BY post_title,ID", ARRAY_A);
        if ($this->db->last_error) { return []; }
        $explicit = $this->db->get_results($this->db->prepare(
            "SELECT post_id,meta_value FROM {$this->db->postmeta} WHERE meta_key=%s ORDER BY meta_id", '_kph_product_code'
        ), ARRAY_A);
        if ($this->db->last_error) { return []; }
        $codes = [];
        foreach ($explicit ?: [] as $row) { $codes[(int)$row['post_id']] = (string)$row['meta_value']; }
        $rows = $rows ?: [];
        foreach ($rows as &$row) {
            $row['id'] = (int)$row['ID'];
            $row['code'] = $codes[$row['id']] ?? $this->customer_code_for_title($row['post_title']);
        }
        unset($row);
        return $rows ?: [];
    }

    /** Exact lookup only: a partial number must never silently select another product. */
    public function lookup_sales_product_code(string $input): array {
        $code = $this->normalize_production_code($input);
        if (!$this->valid_sales_product_code($code)) { return $this->fail('کد محصول معتبر نیست؛ حداکثر ۶۴ نویسه و بدون فاصله وارد کنید.'); }
        $matches = [];
        foreach ($this->sales_product_code_catalog() as $product) {
            if ($product['code'] === $code) { $matches[$product['id']] = $product; }
        }
        if ($this->db->last_error) { return $this->fail('خواندن کد محصولات انجام نشد؛ دوباره تلاش کنید.'); }
        // Published products may already have many batch codes, including stock added before this feature.
        $sources = [$this->inventory_balance => 'unique_product_code', $this->production_codes_table() => 'code'];
        $linked = [];
        foreach ($sources as $table => $column) {
            $normal = $this->production_code_sql('c.' . $column);
            $verified = $column === 'code' ? ' AND ' . $this->production_code_verified_sql('c') : '';
            $rows = $this->db->get_results($this->db->prepare("SELECT DISTINCT c.wc_product_id,p.post_title,p.post_status,p.post_type
                FROM {$table} c LEFT JOIN {$this->db->posts} p ON p.ID=c.wc_product_id WHERE {$normal}=%s {$verified}", $code), ARRAY_A);
            if ($this->db->last_error) { return $this->fail('خواندن کد محصولات انجام نشد؛ دوباره تلاش کنید.'); }
            foreach ($rows ?: [] as $row) {
                if ($row['post_type'] !== 'product' || $row['post_status'] !== 'publish') {
                    return $this->fail('این کد به محصول غیرفعال یا حذف‌شده متصل است؛ مدیر باید محصول قبلی را بررسی کند.');
                }
                $id = (int)$row['wc_product_id'];
                $linked[$id] = TRUE;
                $matches[$id] ??= ['id' => $id, 'post_title' => $row['post_title'], 'code' => $this->customer_product_code($id)];
            }
        }
        $items = [];
        foreach ($matches as $id => $product) {
            $stock = $this->db->get_results($this->db->prepare("SELECT id,unique_product_code AS code,qty_available
                FROM {$this->inventory_balance} WHERE wc_product_id=%d ORDER BY id", $id), ARRAY_A);
            if ($this->db->last_error) { return $this->fail('خواندن موجودی محصول انجام نشد.'); }
            $exact = array_values(array_filter($stock ?: [], fn($row) => $this->normalize_production_code($row['code']) === $code));
            if ($exact) { $stock = $exact; }
            // An explicit batch code without stock keeps its own identity; a product code reuses existing stock.
            if (!$stock || (isset($linked[$id]) && $product['code'] !== $code && !$exact)) {
                $stock = [['id' => 0, 'code' => $code, 'qty_available' => 0]];
            }
            $items[] = ['id' => $id, 'title' => $product['post_title'], 'code' => $code, 'stock_codes' => $stock];
        }
        return $this->ok('', ['code' => $code, 'items' => $items]);
    }

    public function resolve_sales_product_code(string $code, int $product_id, string $stock_code): array {
        $result = $this->lookup_sales_product_code($code);
        if ($result['status'] !== 'success') { return $result; }
        foreach ($result['data']['items'] as $product) {
            if ($product['id'] !== $product_id) { continue; }
            foreach ($product['stock_codes'] as $stock) {
                if ((string)$stock['code'] === $stock_code) {
                    return $this->ok('', ['wc_product_id' => $product_id, 'code' => $stock_code]);
                }
            }
        }
        return $this->fail('کد و محصول یا ردیف انبار تغییر کرده است؛ کد محصول را دوباره وارد کنید.');
    }

    /** Validate the new alias against every historical owner before writing product metadata. */
    private function validate_sales_product_code_owner(string $code, int $product_id, string $title): array {
        if (!$this->valid_sales_product_code($code)) { return $this->fail('کد محصول معتبر نیست؛ حداکثر ۶۴ نویسه و بدون فاصله وارد کنید.'); }
        $expected = $this->customer_code_for_title($title);
        if ($this->customer_code_reserved($code) && $expected !== $code) {
            return $this->fail('این کد برای نوع یا وزن دیگری تعریف شده است؛ نام و کد محصول را بررسی کنید.');
        }
        $owners = [];
        $explicit_owners = $this->db->get_col($this->db->prepare("SELECT DISTINCT post_id FROM {$this->db->postmeta}
            WHERE meta_key='_kph_product_code' AND meta_value=%s AND post_id<>%d", $code, $product_id));
        if ($this->db->last_error) { return $this->fail('بررسی کد محصول انجام نشد.'); }
        foreach ($explicit_owners ?: [] as $id) { $owners[(int)$id] = TRUE; }
        foreach ($this->sales_product_code_catalog() as $product) {
            if ($product['code'] === $code && $product['id'] !== $product_id) { $owners[$product['id']] = TRUE; }
        }
        if ($this->db->last_error) { return $this->fail('بررسی کد محصول انجام نشد.'); }
        foreach ([$this->production_codes_table() => 'code', $this->inventory_balance => 'unique_product_code',
            $this->shop_conversions => 'unique_product_code', $this->inventory_log => 'unique_product_code',
            $this->order_items => 'unique_product_code'] as $table => $column) {
            $normal = $this->production_code_sql($column);
            $rows = $this->db->get_col($this->db->prepare("SELECT DISTINCT wc_product_id FROM {$table} WHERE {$normal}=%s AND wc_product_id<>%d", $code, $product_id));
            if ($this->db->last_error) { return $this->fail('بررسی سابقه کد محصول انجام نشد.'); }
            foreach ($rows ?: [] as $id) { $owners[(int)$id] = TRUE; }
        }
        foreach (array_keys($owners) as $id) {
            $other = get_post($id);
            if ($expected !== $code || !$other || $other->post_type !== 'product' || $other->post_status !== 'publish'
                || $this->customer_code_for_title($other->post_title) !== $code) {
                return $this->fail('این کد قبلاً به محصول دیگری متصل شده است؛ همان محصول را انتخاب کنید.');
            }
        }
        return $this->ok('');
    }

    public function save_sales_product_code(int $product_id, string $input): array {
        if (!$this->can_manage_sales_product_codes()) { return $this->fail('دسترسی به تنظیمات کد محصولات مجاز نیست.'); }
        return $this->write_sales_product_code($product_id, $input);
    }

    private function write_sales_product_code(int $product_id, string $input): array {
        $code = $this->normalize_production_code($input);
        $post = get_post($product_id);
        if (!$post || $post->post_type !== 'product' || !in_array($post->post_status, ['publish', 'draft'], TRUE)) {
            return $this->fail('محصول معتبر را انتخاب کنید.');
        }
        $lock = $this->production_code_lock($code);
        if ((int)$this->db->get_var($this->db->prepare('SELECT GET_LOCK(%s,10)', $lock)) !== 1) { return $this->fail('ثبت این کد در حال انجام است؛ دوباره تلاش کنید.'); }
        try {
            $valid = $this->validate_sales_product_code_owner($code, $product_id, $post->post_title);
            if ($valid['status'] !== 'success') { return $valid; }
            update_post_meta($product_id, '_kph_product_code', wp_slash($code));
            if ((string)get_post_meta($product_id, '_kph_product_code', TRUE) !== $code) { return $this->fail('ذخیره کد محصول انجام نشد.'); }
            return $this->ok('کد محصول ذخیره شد.', ['product_id' => $product_id, 'code' => $code]);
        } finally { $this->db->get_var($this->db->prepare('SELECT RELEASE_LOCK(%s)', $lock)); }
    }

    /** Hall operators may attach an unknown code, but may not edit an established mapping. */
    public function create_sales_product_for_code(string $input, string $name, int $existing_id = 0): array {
        $pages = get_kph_pages_list();
        if (!$this->can_manage_sales_product_codes() && (!get_current_user_id() || !in_array(nooshika_get_user_role(get_current_user_id()), $pages['produce-saloon']['valid_roles'] ?? [], TRUE))) {
            return $this->fail('دسترسی به تعریف محصول مجاز نیست.');
        }
        $code = $this->normalize_production_code($input);
        if (!$this->valid_sales_product_code($code)) { return $this->fail('کد محصول معتبر نیست.'); }
        $lock = $this->production_code_lock($code);
        if ((int)$this->db->get_var($this->db->prepare('SELECT GET_LOCK(%s,10)', $lock)) !== 1) { return $this->fail('ثبت این محصول در حال انجام است؛ دوباره تلاش کنید.'); }
        $new_id = 0;
        try {
            $lookup = $this->lookup_sales_product_code($code);
            if ($lookup['status'] !== 'success') { return $lookup; }
            // Repeat clicks, retries and concurrent requests return the established product.
            if ($lookup['data']['items']) {
                foreach ($lookup['data']['items'] as $item) {
                    if (($existing_id && $existing_id === $item['id']) || (!$existing_id && trim($name) === $item['title'])) {
                        return $this->ok('محصول با این کد موجود است.', $lookup['data']);
                    }
                }
                // Only settings may deliberately add another product to an approved family code.
                $title = $existing_id ? (get_post($existing_id)->post_title ?? '') : trim($name);
                if (!$this->can_manage_sales_product_codes() || !$this->customer_code_reserved($code)
                    || $this->customer_code_for_title($title) !== $code) {
                    return $this->fail('این کد به محصول موجود متصل است؛ کد را دوباره وارد کنید و همان محصول را انتخاب کنید.');
                }
            }
            if ($existing_id) {
                $post = get_post($existing_id);
                if (!$post || $post->post_type !== 'product' || $post->post_status !== 'publish') { return $this->fail('محصول موجود را انتخاب کنید.'); }
                if (!$this->can_manage_sales_product_codes() && $this->customer_product_code($existing_id) !== '') {
                    return $this->fail('این محصول کد دارد؛ تغییر کد فقط از تنظیمات محصولات مجاز است.');
                }
                $saved = $this->write_sales_product_code($existing_id, $code);
                if ($saved['status'] !== 'success') { return $saved; }
            } else {
                $name = trim(sanitize_text_field($name));
                if ($name === '' || mb_strlen($name) > 190) { return $this->fail('نام محصول را وارد کنید؛ حداکثر ۱۹۰ نویسه.'); }
                $same_name = $this->db->get_var($this->db->prepare("SELECT ID FROM {$this->db->posts} WHERE post_type='product' AND post_status IN ('publish','draft','pending','private') AND post_title=%s LIMIT 1", $name));
                if ($same_name) { return $this->fail('محصولی با این نام وجود دارد؛ آن را از قسمت «محصول موجود» انتخاب کنید.'); }
                $valid = $this->validate_sales_product_code_owner($code, 0, $name);
                if ($valid['status'] !== 'success') { return $valid; }
                if (!class_exists('WC_Product_Simple')) { return $this->fail('ووکامرس برای ساخت محصول در دسترس نیست.'); }
                $product = new WC_Product_Simple();
                $product->set_name($name);
                $product->set_status('draft');
                $new_id = (int)$product->save();
                if (!$new_id) { return $this->fail('ساخت محصول انجام نشد.'); }
                $saved = $this->write_sales_product_code($new_id, $code);
                if ($saved['status'] !== 'success') { wp_delete_post($new_id, TRUE); $new_id = 0; return $saved; }
                $product->set_status('publish');
                $product->save();
                if (get_post($new_id)->post_status !== 'publish') { throw new RuntimeException('publish failed'); }
            }
            $lookup = $this->lookup_sales_product_code($code);
            return $lookup['status'] === 'success' ? $this->ok('محصول با کد واردشده آماده است.', $lookup['data']) : $lookup;
        } catch (Throwable $error) {
            if ($new_id) { wp_delete_post($new_id, TRUE); }
            return $this->fail('ساخت محصول انجام نشد؛ اطلاعات را بررسی و دوباره تلاش کنید.');
        } finally { $this->db->get_var($this->db->prepare('SELECT RELEASE_LOCK(%s)', $lock)); }
    }
}
