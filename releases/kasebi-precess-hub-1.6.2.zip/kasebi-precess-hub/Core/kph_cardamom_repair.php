<?php
if (!defined('ABSPATH')) { exit; }

/** A narrowly scoped, audited repair of the verified old cardamom conversion. */
trait kph_cardamom_repair {
    private function cardamom_audit_key(): string { return 'cardamom_name_code_repair_v1'; }

    private function cardamom_query(string $sql) {
        $result = $this->db->query($sql);
        if ($result === FALSE) { throw new RuntimeException('خواندن یا ذخیره اطلاعات کامل نشد؛ هیچ اصلاح ناقصی ثبت نشد.'); }
        return $result;
    }

    private function cardamom_rows(string $sql): array {
        $result = $this->db->get_results($sql, ARRAY_A);
        if ($this->db->last_error) { throw new RuntimeException('خواندن اطلاعات اصلاح انجام نشد.'); }
        return $result ?: [];
    }

    /** Read once for preview, then again under the code and row locks on submission. */
    private function cardamom_repair_snapshot(bool $lock = FALSE): array {
        $suffix = $lock ? ' FOR UPDATE' : '';
        $conversion_table = $this->shop_conversions;
        $audit_table = $this->db_prefix . 'shop_conversion_meta';
        $conversion = $this->cardamom_rows("SELECT * FROM {$conversion_table} WHERE id=140{$suffix}")[0] ?? NULL;
        if (!$conversion) { throw new RuntimeException('این سابقهٔ قابل‌اصلاح در این سایت وجود ندارد.'); }
        $audit = $this->cardamom_rows($this->db->prepare("SELECT meta_value FROM {$audit_table} WHERE conversion_id=140 AND meta_key=%s{$suffix}", $this->cardamom_audit_key()));
        if ($audit) {
            if ($conversion['unique_product_code'] !== '0808330' || (int)$conversion['wc_product_id'] !== 7171) {
                throw new RuntimeException('این اصلاح قبلاً ثبت شده ولی اطلاعات بعداً تغییر کرده است؛ بررسی مدیر لازم است.');
            }
            return ['state' => 'done'];
        }
        $product = get_post(7171);
        $name = $product ? $this->customer_product_name($product->post_title) : '';
        if (!$product || $product->post_type !== 'product' || $product->post_status !== 'publish'
            || !preg_match('/^هل\s+ممتاز\s+(?:هشت|8)\s*گرم/u', $name)) {
            throw new RuntimeException('نام محصول با هل ممتاز هشت‌گرمی مطابقت ندارد؛ اصلاح خودکار متوقف شد.');
        }
        if ($this->customer_product_code(7171) !== '0808330') {
            throw new RuntimeException('ابتدا کد هل ممتاز هشت‌گرمی را در تنظیمات محصولات، 0808330 قرار دهید.');
        }
        if ($conversion['unique_product_code'] !== '0505330' || (int)$conversion['wc_product_id'] !== 7171
            || (int)$conversion['packaging_lot_id'] !== 83 || (int)$conversion['qty_items'] !== 44
            || bccomp((string)$conversion['weight_per_item'], '0.005000', 6) !== 0
            || bccomp((string)$conversion['total_cost'], '31944000', 2) !== 0) {
            throw new RuntimeException('سابقهٔ تولید با مورد بررسی‌شده متفاوت است؛ اصلاح خودکار انجام نمی‌شود.');
        }
        $balances = $this->cardamom_rows("SELECT * FROM {$this->inventory_balance} WHERE wc_product_id=7171 AND unique_product_code IN ('0505330','0808330') ORDER BY id{$suffix}");
        $source = $target = NULL;
        foreach ($balances as $row) {
            if ($row['unique_product_code'] === '0505330') { $source = $row; }
            if ($row['unique_product_code'] === '0808330') { $target = $row; }
        }
        if (count($balances) !== 2 || !$source || !$target || (int)$source['id'] !== 64 || (int)$target['id'] !== 53
            || (int)$source['qty_available'] !== 44 || bccomp((string)$source['inventory_value'], '31944000', 2) !== 0
            || (int)$target['qty_available'] < 0 || bccomp((string)$target['inventory_value'], '0', 2) < 0) {
            throw new RuntimeException('موجودی از زمان بررسی تغییر کرده یا مقصد مشخص نیست؛ اصلاح خودکار متوقف شد.');
        }
        $logs = $this->cardamom_rows("SELECT * FROM {$this->inventory_log} WHERE (wc_product_id=7171 AND unique_product_code='0505330') OR (ref_type='production' AND ref_id=140) ORDER BY id{$suffix}");
        if (count($logs) !== 1 || (int)$logs[0]['id'] !== 312 || (int)$logs[0]['wc_product_id'] !== 7171
            || $logs[0]['unique_product_code'] !== '0505330' || $logs[0]['ref_type'] !== 'production'
            || (int)$logs[0]['ref_id'] !== 140 || (int)$logs[0]['change_qty'] !== 44
            || bccomp((string)$logs[0]['total_cost'], '31944000', 2) !== 0) {
            throw new RuntimeException('این موجودی گردش دیگری دارد؛ اصلاح خودکار انجام نمی‌شود.');
        }
        $other_conversions = $this->cardamom_rows("SELECT id FROM {$conversion_table} WHERE wc_product_id=7171 AND unique_product_code='0505330' AND id<>140{$suffix}");
        $orders = $this->cardamom_rows("SELECT id FROM {$this->order_items} WHERE inventory_id=64 OR (wc_product_id=7171 AND unique_product_code='0505330'){$suffix}");
        $shipments = $this->cardamom_rows("SELECT id FROM {$this->fulfillment_items} WHERE inventory_id=64{$suffix}");
        $source_meta = $this->cardamom_rows("SELECT id FROM {$this->db_prefix}inventory_balance_meta WHERE inventory_id=64{$suffix}");
        if ($other_conversions || $orders || $shipments || $source_meta) {
            throw new RuntimeException('این ردیف به سفارش، ارسال یا اطلاعات دیگری متصل است؛ اصلاح خودکار متوقف شد.');
        }
        $registry = $this->cardamom_rows('SELECT * FROM ' . $this->production_codes_table() . " WHERE wc_product_id=7171 AND code IN ('0505330','0808330') ORDER BY id{$suffix}");
        $target_codes = array_filter($registry, fn($row) => $row['code'] === '0808330');
        if (count($target_codes) !== 1) { throw new RuntimeException('ارتباط کد صحیح هل هشت‌گرمی با محصول پیدا نشد.'); }
        // Keep the precise source and destination for preview validation and an audit trail.
        $snapshot = ['state' => 'ready', 'conversion' => $conversion, 'source' => $source, 'target' => $target,
            'log' => $logs[0], 'registry' => $registry, 'title' => $product->post_title];
        $snapshot['token'] = hash('sha256', wp_json_encode($snapshot));
        return $snapshot;
    }

    public function preview_cardamom_code_repair(): array {
        if (!current_user_can('manage_options')) { return $this->fail('اصلاح فقط برای مدیر مجاز است.'); }
        try {
            if (!$this->workflow_storage_ready('production')) { return $this->fail('ثبت یکپارچهٔ تولید باید از همین صفحه آماده شده باشد.'); }
            return $this->ok('', $this->cardamom_repair_snapshot());
        } catch (Throwable $error) { return $this->fail($error->getMessage()); }
    }

    public function apply_cardamom_code_repair(string $token): array {
        if (!current_user_can('manage_options')) { return $this->fail('اصلاح فقط برای مدیر مجاز است.'); }
        if (!$this->workflow_storage_ready('production')) { return $this->fail('ثبت یکپارچهٔ تولید آماده نیست.'); }
        $names = [$this->production_code_lock('0505330'), $this->production_code_lock('0808330')];
        sort($names); $held = []; $transaction = FALSE;
        try {
            foreach ($names as $name) {
                if ((int)$this->db->get_var($this->db->prepare('SELECT GET_LOCK(%s,5)', $name)) !== 1) { throw new RuntimeException('ثبت دیگری در حال انجام است؛ کمی بعد صفحه را تازه کنید.'); }
                $held[] = $name;
            }
            $this->cardamom_query('START TRANSACTION'); $transaction = TRUE;
            $before = $this->cardamom_repair_snapshot(TRUE);
            if ($before['state'] === 'done') {
                $this->cardamom_query('COMMIT'); $transaction = FALSE;
                return $this->ok('این اصلاح قبلاً انجام شده است؛ موجودی دوباره اضافه نشد.');
            }
            if (strlen($token) !== 64 || !hash_equals($before['token'], $token)) { throw new RuntimeException('اطلاعات از زمان پیش‌نمایش تغییر کرده است؛ صفحه ابزارها را تازه کنید.'); }
            $qty = (int)$before['target']['qty_available'] + 44;
            $value = bcadd((string)$before['target']['inventory_value'], '31944000', 2);
            $average = bcdiv($value, (string)$qty, 6);
            if ($this->cardamom_query("UPDATE {$this->shop_conversions} SET unique_product_code='0808330' WHERE id=140 AND wc_product_id=7171 AND unique_product_code='0505330'") !== 1
                || $this->cardamom_query("UPDATE {$this->inventory_log} SET unique_product_code='0808330' WHERE id=312 AND wc_product_id=7171 AND unique_product_code='0505330'") !== 1) {
                throw new RuntimeException('ذخیره ارتباط کد تولید انجام نشد.');
            }
            $changed = $this->db->update($this->inventory_balance, ['qty_available' => $qty, 'inventory_value' => $value,
                'avg_unit_cost' => $average, 'updated_at' => current_time('mysql')], ['id' => 53, 'wc_product_id' => 7171, 'unique_product_code' => '0808330']);
            if ($changed !== 1) { throw new RuntimeException('ذخیره موجودی مقصد انجام نشد.'); }
            if ($this->cardamom_query("DELETE FROM {$this->inventory_balance} WHERE id=64 AND wc_product_id=7171 AND unique_product_code='0505330'") !== 1) { throw new RuntimeException('ادغام ردیف موجودی انجام نشد.'); }
            $this->cardamom_query('DELETE FROM ' . $this->production_codes_table() . " WHERE wc_product_id=7171 AND code='0505330'");
            $audit = ['version' => 1, 'basis' => 'product_name', 'actor' => get_current_user_id(), 'at' => current_time('mysql'),
                'before' => $before, 'after' => ['code' => '0808330', 'inventory_id' => 53, 'qty' => $qty, 'value' => $value, 'average' => $average]];
            if ($this->db->insert($this->db_prefix . 'shop_conversion_meta', ['conversion_id' => 140,
                'meta_key' => $this->cardamom_audit_key(), 'meta_value' => wp_json_encode($audit)]) !== 1) {
                throw new RuntimeException('ثبت سابقهٔ اصلاح انجام نشد؛ اصلاح برگردانده شد.');
            }
            $this->cardamom_query('COMMIT'); $transaction = FALSE;
            return $this->ok('کد هل ممتاز اصلاح شد. همان ۴۴ بسته به موجودی هل هشت‌گرمی منتقل شد؛ تعداد کل، وزن و هزینهٔ تولید تغییر نکرد.');
        } catch (Throwable $error) {
            if ($transaction) { $this->db->query('ROLLBACK'); }
            return $this->fail($error->getMessage());
        } finally {
            foreach (array_reverse($held) as $name) { $this->db->get_var($this->db->prepare('SELECT RELEASE_LOCK(%s)', $name)); }
        }
    }
}
