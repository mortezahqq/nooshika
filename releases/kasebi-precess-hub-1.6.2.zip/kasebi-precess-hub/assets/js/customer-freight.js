(function ($) {
    'use strict';
    function requestKey() {
        if (window.crypto && window.crypto.randomUUID) return window.crypto.randomUUID();
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
            var r = Math.floor(Math.random()*16); return (c === 'x' ? r : (r&3)|8).toString(16);
        });
    }
    function purpose() {
        var modal = $('#addUserPayments'), freight = modal.find('[data-for="payment_purpose"]').val() === 'customer_freight';
        modal.find('#payment_method').closest('.col-md-6').toggle(!freight);
        modal.find('#payment_side_credit').closest('.col-md-6').toggle(!freight);
        modal.find('.kph-freight-help').toggle(freight);
        if (freight && !modal.data('freightActive')) {
            modal.data('normalMethod',modal.find('#payment_method').val());
            modal.data('normalSide',modal.find('[name=payment_side]:checked').val());
        }
        if (!freight && modal.data('freightActive')) {
            modal.find('#payment_method').val(modal.data('normalMethod')).trigger('change');
            modal.find('[name=payment_side]').each(function(){ $(this).prop('checked',this.value===modal.data('normalSide')); });
        }
        if (freight) {
            modal.find('#payment_method').val('other').trigger('change');
            modal.find('#payment_side_credit').prop('checked', true);
            modal.find('#payment_side_debit').prop('checked', false);
        }
        modal.find('[name=payment_side]').each(function(){ $(this).closest('.custom-control').toggleClass('checked',this.checked); });
        modal.data('freightActive',freight);
    }
    $(document).on('shown.bs.modal', '#addUserPayments', function () {
        $(this).find('[data-for="payment_purpose"]').val('normal');
        $(this).find('[data-for="freight_request_key"]').val(requestKey());
        purpose();
    }).on('change', '#addUserPayments [data-for="payment_purpose"]', purpose);
    function notify(message,type){
        if(window.NioApp && typeof window.NioApp.Toast==='function'){window.NioApp.Toast($('<div>').text(String(message)).html(),type,{position:'top-right'});}
        else{window.alert(message);}
    }
    $(document).on('click', '.kph-freight-action', function(e) {
        e.preventDefault();var button=$(this),box=button.closest('.kph-customer-freight'),op=button.data('operation');
        if(button.prop('disabled'))return;
        function send(reason){
            if(button.prop('disabled'))return;
            button.prop('disabled',true);
            $.ajax({url:(window.kphData&&window.kphData.ajax_url)||window.ajax_url||(typeof ajax_url!=='undefined'?ajax_url:'/wp-admin/admin-ajax.php'),method:'POST',dataType:'json',data:{action:'kph_freight_action',nonce:box.data('nonce'),operation:op,record_id:button.data('record'),version:button.data('version'),reason:reason}})
                .done(function(r){notify((r&&(r.message||r.msg))||'پاسخ عملیات کرایه معتبر نیست؛ نسخه افزونه و کش سایت را بررسی کنید.',r&&r.status==='success'?'success':'error');if(r&&r.status==='success')window.location.reload();})
                .fail(function(xhr,status){var r=xhr&&xhr.responseJSON;notify((r&&(r.message||r.msg))||(status==='parsererror'?'پاسخ سرور JSON نیست؛ نشست ورود، کش و خطای PHP را بررسی کنید.':'پاسخ ثبت دریافت نشد؛ پیش از تلاش مجدد وضعیت رکورد را بررسی کنید.'),'error');})
                .always(function(){button.prop('disabled',false);});
        }
        if(window.Swal && typeof window.Swal.fire==='function'){
            window.Swal.fire({title:op==='cancel'?'ابطال کرایه مشتری':'آماده‌سازی ثبت کرایه',text:op==='cancel'?'کسر مشتری و هزینه هر دو برگشت می‌خورند.':'ابتدا نسخه پشتیبان دیتابیس تهیه کنید.',input:op==='cancel'?'text':undefined,inputLabel:op==='cancel'?'علت ابطال':undefined,showCancelButton:true,confirmButtonText:'تأیید',cancelButtonText:'لغو',inputValidator:op==='cancel'?function(value){if(!value||!value.trim())return 'علت را وارد کنید.';}:undefined}).then(function(result){if(result.isConfirmed)send(op==='cancel'?result.value:'');});
            return;
        }
        var reason='';if(op==='prepare'&&!window.confirm('ابتدا نسخه پشتیبان دیتابیس تهیه کنید. آماده‌سازی جدول‌های مالی برای ثبت یکپارچه انجام شود؟'))return;
        if(op==='cancel'){reason=window.prompt('علت ابطال کرایه (کسر مشتری و هزینه هر دو برگشت می‌خورند):');if(!reason||!reason.trim())return;}
        send(reason);
    });
})(jQuery);
