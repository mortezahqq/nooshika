(function ($) {
    'use strict';
    const digits = value => String(value || '').replace(/[۰-۹٠-٩]/g, c => '۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩'.indexOf(c) % 10).trim();
    function request(action, data) {
        return $.ajax({url: kphData.ajax_url, type: 'POST', dataType: 'json', global: false, data: Object.assign({action, production_nonce: kphData.production_nonce}, data)});
    }
    function message($form, text, error) {
        $form.find('.kph-code-message').text(text).toggleClass('text-danger', !!error).toggleClass('text-soft', !error);
    }
    function ready($form, value) {
        $form.data('kphCodeReady', value).find('.submit_modal_form').prop('disabled', !value);
    }
    function clearSelection($form) {
        ready($form, false);
        $form.find('#wc_product_id, #unique_product_code, #saloon_product_name').val('');
        $form.find('#saloon_product_name').removeClass('d-none');
        $form.find('#saloon_product_choices').empty().addClass('d-none');
        $form.find('#saloon_stock_choices').empty();
        $form.find('#saloon_stock_choice_wrap, #saloon_new_product').addClass('d-none');
        $form.data('kphCodeItems', []);
    }
    function cancelLookup($form) {
        clearTimeout($form.data('kphCodeTimer'));
        $form.data('kphCodeVersion', ($form.data('kphCodeVersion') || 0) + 1);
        const pending = $form.data('kphCodeRequest');
        if (pending) pending.abort();
    }
    function selectProduct($form, id) {
        ready($form, false);
        $form.find('#wc_product_id, #unique_product_code').val('');
        $form.find('#saloon_stock_choice_wrap').addClass('d-none');
        const product = ($form.data('kphCodeItems') || []).find(item => String(item.id) === String(id));
        if (!product) { message($form, 'محصول موردنظر را انتخاب کنید.'); return; }
        $form.find('#wc_product_id').val(product.id);
        $form.find('#saloon_product_name').val(product.title);
        const stock = product.stock_codes || [];
        if (stock.length === 1) {
            $form.find('#unique_product_code').val(stock[0].code);
            ready($form, true);
            message($form, 'محصول مشخص شد؛ وزن و هزینه بسته‌بندی را وارد کنید.');
        } else {
            const $select = $form.find('#saloon_stock_choices').empty().append($('<option>').val('').text('انتخاب ردیف انبار'));
            stock.forEach(row => $select.append($('<option>').val(row.code).text(row.code + ' — موجودی: ' + row.qty_available)));
            $form.find('#saloon_stock_choice_wrap').removeClass('d-none');
            message($form, 'این محصول چند کد تولید دارد؛ ردیف انبار مقصد را انتخاب کنید.');
        }
    }
    function showProducts($form, data) {
        clearSelection($form);
        const items = data.items || [];
        $form.data('kphCodeItems', items);
        if (!items.length) {
            $form.find('#saloon_new_product').removeClass('d-none');
            message($form, 'محصولی با این کد پیدا نشد. محصول موجود را انتخاب کنید یا نام محصول جدید را بنویسید و ثبت کنید.');
        } else if (items.length === 1) {
            selectProduct($form, items[0].id);
        } else {
            $form.find('#saloon_product_name').addClass('d-none');
            const $select = $form.find('#saloon_product_choices').removeClass('d-none').append($('<option>').val('').text('انتخاب محصول با این کد'));
            items.forEach(item => $select.append($('<option>').val(item.id).text(item.title)));
            message($form, 'این کد مشترک است؛ محصول موردنظر را انتخاب کنید.');
        }
    }
    function lookup($form) {
        const code = digits($form.find('#saloon_product_code').val());
        if (code && ($form.data('kphLookedUpCode') === code || ($form.data('kphLookupCode') === code && $form.data('kphCodeRequest')))) return;
        cancelLookup($form);
        $form.removeData('kphLookedUpCode');
        clearSelection($form);
        if (!code) { message($form, 'کد محصول را وارد کنید تا نام آن نمایش داده شود.'); return; }
        $form.find('#saloon_product_code').val(code);
        message($form, 'در حال پیدا کردن محصول…');
        const version = $form.data('kphCodeVersion');
        const current = () => document.contains($form[0]) && version === $form.data('kphCodeVersion') && code === digits($form.find('#saloon_product_code').val());
        const pending = request('kph_lookup_sales_product_code', {product_code: code});
        $form.data('kphLookupCode', code);
        $form.data('kphCodeRequest', pending);
        pending.done(function (response) {
            if (!current()) return;
            if (response && response.status === 'success' && response.data && response.data.code === code) {
                $form.data('kphLookedUpCode', code);
                showProducts($form, response.data);
            }
            else message($form, response?.message || 'خواندن محصول انجام نشد؛ کد را دوباره وارد کنید.', true);
        }).fail(function (_, status) {
            if (status !== 'abort' && current()) message($form, 'پاسخ دریافت نشد؛ کد را دوباره وارد کنید.', true);
        }).always(function () { if (current()) $form.removeData('kphCodeRequest'); });
    }
    $(document).on('input', '#saloon_product_code', function () {
        const $form = $(this).closest('form');
        cancelLookup($form);
        clearSelection($form);
        $form.removeData('kphLookedUpCode kphLookupCode');
        $form.find('#saloon_new_product_name').val('');
        $form.find('#saloon_existing_product').val('0').trigger('change');
        message($form, 'در حال پیدا کردن محصول…');
        $form.data('kphCodeTimer', setTimeout(() => lookup($form), 350));
    }).on('change', '#saloon_product_code', function () { lookup($(this).closest('form')); });
    $(document).on('change', '#saloon_product_choices', function () { selectProduct($(this).closest('form'), $(this).val()); });
    $(document).on('change', '#saloon_stock_choices', function () {
        const $form = $(this).closest('form'), code = $(this).val();
        $form.find('#unique_product_code').val(code);
        ready($form, !!code);
        message($form, code ? 'محصول مشخص شد؛ وزن و هزینه بسته‌بندی را وارد کنید.' : 'ردیف انبار مقصد را انتخاب کنید.');
    });
    $(document).on('shown.bs.modal', '#convertLotToProduct', function () {
        const $form = $(this).find('[data-code-first]');
        cancelLookup($form);
        clearSelection($form);
        $form.removeData('kphLookedUpCode kphLookupCode');
        $form.find('#saloon_product_code, #saloon_new_product_name').val('');
        $form.find('#saloon_existing_product').val('0').trigger('change');
        message($form, 'کد محصول را وارد کنید تا نام آن نمایش داده شود.');
        $form.find('#saloon_product_code').trigger('focus');
    }).on('hidden.bs.modal', '#convertLotToProduct', function () { cancelLookup($(this).find('[data-code-first]')); });
    $(document).on('submit', '[data-code-first]', function (event) {
        event.preventDefault();
        if ($(this).data('kphCodeReady')) $(this).find('.submit_modal_form').trigger('click');
        else message($(this), 'ابتدا کد محصول را وارد کنید و منتظر نمایش نام محصول بمانید.', true);
    });
    $(document).on('change', '#saloon_existing_product', function () { $('#saloon_new_name_wrap').toggleClass('d-none', $(this).val() !== '0'); });
    $(document).on('click', '#saloon_create_product', function () {
        const $button = $(this), $form = $button.closest('form');
        if ($form.data('kphCreatingProduct')) return;
        const code = digits($form.find('#saloon_product_code').val()), version = $form.data('kphCodeVersion');
        const title = $form.find('#saloon_new_product_name').val().trim(), existing = $form.find('#saloon_existing_product').val();
        if (!existing || (existing === '0' && !title)) { message($form, 'نام محصول جدید را وارد کنید یا محصول موجود را انتخاب کنید.', true); return; }
        $form.data('kphCreatingProduct', true); $button.prop('disabled', true);
        message($form, 'در حال ثبت محصول…');
        request('kph_create_sales_product_for_code', {product_code: code, title, existing_product_id: existing})
            .done(function (response) {
                if (!document.contains($form[0]) || version !== $form.data('kphCodeVersion') || code !== digits($form.find('#saloon_product_code').val())) return;
                if (response?.status === 'success' && response.data) showProducts($form, response.data);
                else message($form, response?.message || 'ثبت محصول انجام نشد.', true);
            }).fail(function () { if (version === $form.data('kphCodeVersion')) {
                $form.removeData('kphLookedUpCode');
                message($form, 'پاسخ ثبت دریافت نشد؛ کد را دوباره وارد کنید تا وضعیت محصول مشخص شود.', true);
            } })
            .always(function () { $form.data('kphCreatingProduct', false); $button.prop('disabled', false); });
    });

    // Settings use the same native list, modal and controls as supplier products.
    $(document).on('click', '.kph-edit-sales-code, .kph-new-sales-product', function () {
        const $form = $('#kphSalesProductCode form');
        $form[0].reset();
        $form.find('.kph-settings-code-message').text('');
        $form.find('[name="product_id"]').val($(this).attr('data-product-id') || '0').trigger('change');
        $form.find('[name="product_code"]').val($(this).attr('data-code') || '');
    });
    $(document).on('change', '#kphCodeProduct', function () {
        const $form = $(this).closest('form');
        $form.find('.kph-new-product-name').toggleClass('d-none', $(this).val() !== '0');
    });
    $(document).on('input', '.kph-product-code-filter', function () {
        const query = digits($(this).val()).toLowerCase();
        const $rows = $('#sales_products .kph-product-code-row');
        $rows.each(function () { $(this).toggleClass('d-none', !digits($(this).find('.kph-product-title').text() + ' ' + $(this).find('.kph-saved-product-code').text()).toLowerCase().includes(query)); });
        $('#sales_products .kph-product-code-empty').toggleClass('d-none', $rows.not('.d-none').length > 0);
    });
    $(document).on('submit', '.kph-product-code-form', function (event) {
        event.preventDefault();
        const $form = $(this), $button = $form.find('[type="submit"]'), $message = $form.find('.kph-settings-code-message');
        if ($form.data('saving')) return;
        const id = $form.find('[name="product_id"]').val(), code = digits($form.find('[name="product_code"]').val()), title = $form.find('[name="title"]').val().trim();
        if (!code || (id === '0' && !title)) { $message.text('کد و نام محصول را وارد کنید.').addClass('text-danger'); return; }
        $form.data('saving', true); $button.prop('disabled', true); $message.removeClass('text-danger').text('در حال ذخیره…');
        const action = id === '0' ? 'kph_create_sales_product_for_code' : 'kph_save_sales_product_code';
        request(action, {product_id: id, product_code: code, title}).done(function (response) {
            if (response?.status !== 'success') { $message.text(response?.message || 'ذخیره انجام نشد.').addClass('text-danger'); return; }
            if (id === '0') {
                window.location.href = '/crm/settings-products?tab=sales_products';
            } else {
                const $row = $('#sales_products .kph-product-code-row').filter(function () { return $(this).attr('data-product-id') === id; });
                $row.find('.kph-saved-product-code').text(code);
                $row.find('.kph-edit-sales-code').attr('data-code', code);
                $('#kphSalesProductCode').modal('hide');
            }
            $message.text('کد محصول ذخیره شد.');
        }).fail(function () { $message.text('پاسخ دریافت نشد؛ فرم را ببندید و صفحه را تازه کنید تا وضعیت ذخیره مشخص شود.').addClass('text-danger'); })
            .always(function () { $form.data('saving', false); $button.prop('disabled', false); });
    });
})(jQuery);
