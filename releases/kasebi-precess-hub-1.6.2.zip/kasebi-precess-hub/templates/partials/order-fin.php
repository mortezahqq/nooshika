<?php
/**
 * @var int     $order_id
 * @var \kph_db $DB
 */

$entries     = $DB->get_ledger_entries_by_order_number( $order_id );
$order_data  = $DB->get_order_data( $order_id );
$items       = $order_data['items'];
$order_total = 0;
?>
<div class="card mb-3">
    <div class="nk-tb-list nk-tb-ulist is-compact">
        <div class="nk-tb-item nk-tb-head">
            <div class="nk-tb-col"><span class="sub-text">تاریخ ثبت</span></div>
            <div class="nk-tb-col"><span class="sub-text">توضیحات</span></div>
            <div class="nk-tb-col text-end"><span class="sub-text">مبلغ</span></div>
        </div>
		<?php
		foreach ( $entries['data']['items'] as $entry ) {
			$date   = date_i18n( 'j F Y', strtotime( $entry['posted_at'] ) );
			$amount = number_format( $entry['amount'] );
			if ( $entry['type'] == 'debit' ) {
				$order_total += $entry['amount'];
				$amount      = $amount . '-';
			} else {
				$order_total -= $entry['amount'];
				$amount      = $amount . '+';
			}
			?>
            <div class="nk-tb-item">
                <div class="nk-tb-col">
                    <span><?php echo $date; ?></span>
                </div>
                <div class="nk-tb-col">
					<?php echo $entry['note']; ?>
                </div>
                <div class="nk-tb-col text-end">
                    <span><?php echo $amount; ?></span>
                </div>
            </div>
			<?php
		}
		?>
    </div>
</div>
<div class="d-flex justify-between mb-2 w-350px pe-4" style="margin-right: auto">
    <span>جمع کل حسابداری</span>
    <span><?php echo number_format( $order_total ); ?></span>
</div>