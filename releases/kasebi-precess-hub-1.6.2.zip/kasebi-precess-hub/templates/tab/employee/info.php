<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
/**
 * @var $user_id
 */

$DB         = new kph_db();
$user_color = get_user_meta( $user_id, 'user_color', TRUE ) ?: 'primary';
$first_name = get_user_meta( $user_id, 'first_name', TRUE );
$last_name  = get_user_meta( $user_id, 'last_name', TRUE );
$gender     = get_user_meta( $user_id, 'gender', TRUE );
$is_visitor = nooshika_get_user_role( $user_id ) === 'visitor';
if (kph_hr::allowed() && !current_user_can('manage_options')) { $is_visitor = FALSE; }
$summary = $is_visitor ? $DB->get_visitor_summaries( [ (int) $user_id ], TRUE )[ $user_id ] : [];
$balance    = $DB->get_ledger_balance_now( $user_id );
$balance    = (float) ( $balance['balance'] ?? 0 );
$class      = '';
$icon       = '';
if ( $balance != 0 ) {
	$icon  = $balance < 0 ? 'ni-arrow-long-up' : 'ni-arrow-long-down';
	$class = $balance < 0 ? ' text-success' : ' text-danger';
}

?>
<div class="card-inner">
    <div class="user-card user-card-s2">
        <div class="user-avatar fs-38px lg bg-<?php echo $user_color; ?>">
			<?php
			if ( $gender == 'female' ) {
				echo '<i class="uik-r fa-woman-head"></i>';
			} else {
				echo '<i class="uik-r fa-smile"></i>';
			}
			?>
        </div>
        <div class="user-info">
            <h5><?php echo $first_name . ' ' . $last_name; ?></h5>
        </div>
    </div>
</div>
<div class="card-inner card-inner-sm">
    <ul class="btn-toolbar justify-center gx-1">
        <?php if ( ! $is_visitor && kph_hr::allowed() ) { foreach ( [ 'payments' => 'پرداخت', 'transfers' => 'حواله', 'cheque' => 'چک پرداختی' ] as $key => $label ) { ?>
            <li><a class="btn btn-sm btn-light page_activator" href="<?php echo esc_url(kph_hr_url((int)$user_id,$key)); ?>"><?php echo esc_html($label); ?></a></li>
        <?php } } ?>
		<?php if ( $is_visitor ) { ?>
		<li>
			<div data-bs-toggle="modal" class="select_current_user_for_modal" data-id="<?php echo $user_id; ?>"
			     data-input="#new_payment_customer_id" data-bs-target="#addUserPayments">
				<a class="btn btn-icon icon bg-purple-dim" data-bs-toggle="tooltip"
				   data-bs-placement="top" title="افزودن پرداختی">
					<em class="icon ni ni-cc-alt2"></em>
				</a>
			</div>
		</li>
		<li>
			<div data-bs-toggle="modal" class="select_current_user_for_modal" data-id="<?php echo $user_id; ?>"
			     data-input="#new_cheque_customer_id" data-bs-target="#addCheque">
				<a class="btn btn-icon icon bg-indigo-dim" data-bs-toggle="tooltip"
				   data-bs-placement="top" title="ثبت چک">
					<em class="icon ni ni-activity-round"></em>
				</a>
			</div>
		</li>
		<li>
			<div data-bs-toggle="modal" class="select_current_user_for_modal" data-id="<?php echo $user_id; ?>"
			     data-input="#new_transfer_customer_id" data-bs-target="#addUserTransfer">
				<a class="btn btn-icon icon bg-orange-dim" data-bs-toggle="tooltip"
				   data-bs-placement="top" title="ثبت حواله">
					<em class="icon ni ni-tranx"></em>
				</a>
			</div>
		</li>
		<?php } ?>
        <?php if(current_user_can('manage_options')){ ?><li>
            <a class="btn btn-icon icon bg-success-dim login_as_this" data-id="<?php echo $user_id; ?>"
               data-bs-toggle="tooltip"
               data-bs-placement="top" title="ورود به عنوان کارمند">
                <em class="icon ni ni-signin"></em>
            </a>
        </li><?php } ?>
    </ul>
</div>
<?php if ( $is_visitor || kph_hr::allowed() ) { ?>
<div class="card-inner">
	<div class="profile-stats text-center">
		<div class="amount<?php echo $class; ?>">
			<span><?php echo number_format( abs( $balance ) ); ?></span>
			<?php if ( $icon ) { ?>
				<em class="icon ni <?php echo $icon; ?>"></em>
			<?php } ?>
		</div>
		<span class="sub-text"><?php echo $is_visitor ? 'مانده حساب خود ویزیتور' : 'مانده حساب پرسنل (ریال)'; ?></span>
	</div>
</div>
<?php if ( $is_visitor ) { ?>
<div class="card-inner text-center">
	<strong><?php echo number_format( abs( $summary['customer_balance'] ) ); ?></strong>
	<span class="sub-text">مانده کل مشتریان (تومان) — <?php echo $summary['customer_balance'] > 0 ? 'بدهکار' : ( $summary['customer_balance'] < 0 ? 'بستانکار' : 'تسویه' ); ?></span>
	<strong class="d-block mt-3"><?php echo number_format( $summary['open_orders'] ); ?></strong>
	<span class="sub-text">سفارش باز</span>
</div>
<?php } } ?>
