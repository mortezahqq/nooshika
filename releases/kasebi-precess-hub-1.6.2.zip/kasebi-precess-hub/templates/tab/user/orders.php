<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * @var $user_id
 */
$defaults   = [
	'per_page'    => 10,
	'page_number' => 1,
	'date'        => [
		'from' => '',
		'to'   => '',
	],
	'status'      => '',
];
$args       = wp_parse_args( $_REQUEST, $defaults );
$args       = array_map( fn( $v ) => $v == 0 ? '' : $v, $args );
$has_filter = kph_page_has_filter( $args, $defaults );
extract( $args );
$date_from  = $date['from'] ?? '';
$date_to    = $date['to'] ?? '';
$DB         = new kph_db();
$statuses   = $DB->get_order_statuses();
$entries    = $DB->get_orders_list( [
	'page'        => $page_number,
	'per_page'    => $per_page,
	'customer_id' => $user_id,
	'status'      => $status,
	'date_from'   => $date_from ? nooshika_jalali_to_gregorian( $date_from ) : NULL,
	'date_to'     => $date_to ? nooshika_jalali_to_gregorian( $date_to ) : NULL,
] );
$total_page = $entries['pagination']['total_page'];
$entries    = $entries['items'];
$shipment_dates = $DB->get_order_last_shipment_dates( array_column( $entries, 'id' ) );
?>
<?php echo kph_get_template( 'components/preparation-print-controls.php' ); ?>
<div class="nk-block nk-block-between">
    <div class="nk-block-head">
        <h6 class="title">لیست سفارش ها</h6>
    </div>
    <ul class="btn-toolbar gx-1">
        <li class="nk-block-tools-opt">
            <a href="#" class="btn btn-info print_list_items" data-type="c-factor"
               data-collect="ids">
                <em class="icon ni ni-printer"></em>
                <span>پرینت رسمی</span>
            </a>
        </li>
        <li class="nk-block-tools-opt">
            <a href="#" class="btn btn-icon btn-primary print_list_items" data-type="factor"
               data-collect="ids">
                <em class="icon ni ni-printer"></em></a>
        </li>
        <li>
			<?php
			$filter_fields = [
				[
					'type'  => 'date-range',
					'label' => 'تاریخ فاکتور',
					'name'  => 'date',
					'value' => [
						'from' => $date_from ?? '',
						'to'   => $date_to ?? '',
					],
				],
				[
					'type'    => 'select',
					'label'   => 'وضعیت فاکتور',
					'name'    => 'status',
					'value'   => $status,
					'options' => [ 0 => 'همه موارد' ] + array_combine(
							array_keys( $statuses ),
							array_column( $statuses, 'label' )
						),
				],
				[
					'type'  => 'hidden',
					'name'  => 'tab',
					'value' => 'orders',
				],
			];
			echo kph_get_template( 'components/filter-dropdown.php', [
				'has_filter'    => $has_filter,
				'filter_fields' => $filter_fields,
			] );
			?>
        </li>
    </ul>
</div>
<div class="nk-block">
	<?php
	if ( empty( $entries ) ) {
		echo '<div class="no_massages">آیتمی برای نمایش وجود ندارد.</div>';
	} else {
		?>
        <div class="card">
            <div class="nk-tb-list nk-tb-ulist is-compact">
                <div class="nk-tb-item nk-tb-head">
                    <div class="nk-tb-col nk-tb-col-check"></div>
                    <div class="nk-tb-col"><span class="sub-text">تاریخ ثبت</span></div>
                    <div class="nk-tb-col"><span class="sub-text">تاریخ ارسال</span></div>
                    <div class="nk-tb-col"><span class="sub-text">جمع کل</span></div>
                    <div class="nk-tb-col"><span class="sub-text">تعداد محصولات</span></div>
                    <div class="nk-tb-col"><span class="sub-text">وضعیت</span></div>
                    <div class="nk-tb-col nk-tb-col-tools text-end"></div>
                </div>
				<?php
				foreach ( $entries as $entry ) {
					$date         = date_i18n( 'Y/m/d', strtotime( $entry['created_at'] ) );
					$amount       = number_format( $entry['total_payable'] );
					$note         = $entry['note'];
					$order_status = $statuses[ $entry['status'] ];
					$attachment   = $DB->get_order_meta( $entry['id'], 'attachments' );
					$address_id   = $DB->get_order_meta( $entry['id'], 'address_id' );
					$factor_date  = $DB->get_order_meta( $entry['id'], 'factor_date' );
					?>
                    <div class="nk-tb-item">
                        <div class="nk-tb-col nk-tb-col-check">
                            <div class="custom-control custom-control-sm custom-checkbox notext">
                                <input type="checkbox" class="custom-control-input select_item_for_print<?php echo $entry['status'] === 'proforma' && kph_preparation_print_allowed() ? ' kph-preparation-select' : ''; ?>" data-viewer="<?php echo esc_attr( get_current_user_id() ); ?>"
                                       value="<?php echo $entry['id']; ?>"
                                       id="print_item_<?php echo $entry['id']; ?>">
                                <label class="custom-control-label"
                                       for="print_item_<?php echo $entry['id']; ?>"></label>
                            </div>
                        </div>
                        <div class="nk-tb-col">
                            <span><?php echo $date; ?></span>
                        </div>
                        <div class="nk-tb-col">
                            <span><?php echo esc_html( ! empty( $shipment_dates[$entry['id']] ) ? date_i18n( 'Y/m/d', strtotime( $shipment_dates[$entry['id']] ) ) : 'ارسال نشده' ); ?></span>
                        </div>
                        <div class="nk-tb-col">
                            <div class="amount">
                                <span><?php echo $amount; ?></span>
                            </div>
                        </div>
                        <div class="nk-tb-col">
                            <strong class="fs-14px"><?php echo $entry['total_ordered_qty']; ?> عدد کالا</strong>
							<?php
							if ( $entry['total_expected_free_qty'] ) {
								?><span class="sub-text">
                                +<?php echo $entry['total_expected_free_qty']; ?> هدیه</span><?php
							}
							?>
                        </div>
                        <div class="nk-tb-col">
                            <span class="badge bg-<?php echo $order_status['class']; ?>">
                                <?php echo $order_status['label']; ?></span>
                        </div>
                        <div class="nk-tb-col">
                            <ul class="nk-tb-actions gx-2">
								<?php
								$hidden_actions = [
									[
										'link'  => '',
										'title' => 'حسابداری سفارش',
										'class' => 'load_item_data_to_modal',
										'icon'  => 'ni-coin-alt',
										'data'  => [
											'item-id' => $entry['id'],
											'action'  => 'kph_load_order_financial',
											'modal'   => '#orderFinancialTable',
										],
									],
									'date' => [
										'link'  => "",
										'title' => 'تاریخ فاکتور: ' . $factor_date,
										'icon'  => 'ni-calendar-alt',
									],
									[
										'link'  => '',
										'title' => 'آیتم های سفارش',
										'class' => 'load_item_data_to_modal',
										'icon'  => 'ni-package',
										'data'  => [
											'item-id' => $entry['id'],
											'action'  => 'kph_load_order_items',
											'modal'   => '#invoiceItemsTable',
										],
									],
									
									[
										'link'  => '',
										'title' => 'ارسال های سفارش',
										'class' => 'load_item_data_to_modal',
										'icon'  => 'ni-send',
										'data'  => [
											'item-id' => $entry['id'],
											'action'  => 'kph_load_order_fulfillment',
											'modal'   => '#invoiceFulfillmentTable',
										],
									],
								];
								echo kph_get_template( 'components/row-actions.php', [
									'actions' => $hidden_actions,
								] );
								if ( $note ) {
									?>
                                    <li class="nk-tb-action">
                                        <div class="btn btn-sm btn-icon btn-trigger"
                                             data-bs-toggle="popover"
                                             data-bs-trigger="hover"
                                             data-bs-html="true"
                                             title="یادداشت"
                                             data-bs-content="<?php echo wpautop( $note ); ?>"
                                             data-bs-placement="top">
                                            <em class="icon ni ni-note-add-c"></em>
                                        </div>
                                    </li>
									<?php
								}
								if ( $attachment ) {
									$attachment = explode( ',', $attachment );
									?>
                                    <li class="nk-tb-action">
										<?php
										$actions = [];
										foreach ( $attachment as $url ) {
											$file_data = $DB->get_uploaded_file_data( $url );
											if ( ! $file_data ) {
												$file_name = $url;
											} else {
												$file_name = $file_data['original_name'];
											}
											$actions[] = [
												'link'     => $url,
												'title'    => $file_name,
												'icon'     => 'ni-download',
												'target'   => '_blank',
												'download' => TRUE,
											];
										}
										echo kph_get_template( 'components/row-actions-dropdown.php', [
											'actions'   => $actions,
											'main_icon' => 'file-docs',
											'title'     => 'فایل ضمیمه',
										] );
										?>
                                    </li>
									<?php
								}
								if ( $entry['status'] == 'proforma' ) {
									?>
                                    <li>
										<?php
										$actions = [
											'edit'     => [
												'link'   => home_url() . "/crm/order-customer-edit?order-id={$entry['id']}",
												'icon'   => 'ni-edit',
												'title'  => 'ویرایش فاکتور',
												'target' => '_blank',
											],
											'register' => [
												'link'  => '',
												'title' => 'تایید فاکتور',
												'icon'  => 'ni-check-round-cut',
												'class' => 'change_order_status',
												'data'  => [
													'order-id' => $entry['id'],
													'status'   => 'registered',
													'user-id'  => $user_id,
												],
											],
										];
										echo kph_get_template( 'components/row-actions-dropdown.php', [
											'actions' => $actions,
										] );
										?>
                                    </li>
									<?php
								}
								?>
                            </ul>
                        </div>
                    </div>
					<?php
				}
				?>
            </div>
        </div>
        <div class="p-1 mt-2">
			<?php
			echo kph_get_template( 'components/pagination.php', [
				'max_page_num' => $total_page,
				'current_page' => $page_number,
				'show_count'   => 2,
				'data'         => [
					'tab' => 'orders',
				],
			] );
			?>
        </div>
		<?php
	}
	?>
</div>
