<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * @var array $ids
 * @var int   $user_id
 * @var array $date
 * @var array $request
 */

global $wpdb;

$DB = new kph_db();

$ids     = isset( $ids ) && is_array( $ids ) ? array_map( 'absint', $ids ) : [];
$user_id = isset( $user_id ) ? absint( $user_id ) : 0;

$date_from = trim( $date['from'] ?? '' );
$date_to   = trim( $date['to'] ?? '' );

$payments_table  = $wpdb->prefix . 'kph_payments';
$payment_methods = $DB->get_payment_methods();

$payments = [];

if ( ! empty( $ids ) ) {
	$placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
	
	$payments = $wpdb->get_results(
		$wpdb->prepare(
			"
			SELECT *
			FROM {$payments_table}
			WHERE id IN ({$placeholders})
			ORDER BY paid_at ASC, id ASC
			",
			$ids
		),
		ARRAY_A
	);
} else {
	if ( ! $user_id ) {
		wp_die( 'برای پرینت پرداخت‌ها باید شناسه کاربر یا شناسه پرداخت‌ها مشخص شود.' );
	}
	
	$res = $DB->get_payments_list( [
		'user_id'   => $user_id,
		'page'      => 1,
		'per_page'  => 5000,
		'date_from' => $date_from ? $date_from . ' 00:00:00' : NULL,
		'date_to'   => $date_to ? $date_to . ' 23:59:59' : NULL,
		'orderby'   => 'paid_at',
		'order'     => 'ASC',
	] );
	
	$payments = $res['items'] ?? [];
}

if ( empty( $payments ) ) {
	wp_die( 'پرداختی برای پرینت یافت نشد.' );
}

$report_title = count( $payments ) === 1 ? 'رسید پرداخت' : 'گزارش پرداخت‌ها';

$customer_title = $user_id ? kph_print_user_name( $user_id ) : 'همه کاربران';

$range_label = 'همه تاریخ‌ها';

if ( $date_from || $date_to ) {
	$range_label = trim( ( $date_from ?: 'ابتدا' ) . ' تا ' . ( $date_to ?: 'امروز' ) );
}

$total_in  = 0;
$total_out = 0;
$total_abs = 0;
$net       = 0;

foreach ( $payments as $payment ) {
	$amount = (float) ( $payment['amount'] ?? 0 );
	
	if ( $amount < 0 ) {
		$total_in += abs( $amount );
	} else {
		$total_out += $amount;
	}
	
	$total_abs += abs( $amount );
	$net       += $amount;
}

if ( ! function_exists( 'kph_print_payment_method_label' ) ) {
	function kph_print_payment_method_label( string $method, array $payment_methods ): string {
		return $payment_methods[ $method ]['label'] ?? $method;
	}
}

if ( ! function_exists( 'kph_print_payment_direction_label' ) ) {
	function kph_print_payment_direction_label( $amount ): string {
		return (float) $amount < 0 ? 'دریافت' : 'پرداخت';
	}
}

if ( ! function_exists( 'kph_print_payment_direction_class' ) ) {
	function kph_print_payment_direction_class( $amount ): string {
		return (float) $amount < 0 ? 'text-success' : 'text-danger';
	}
}

?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title><?php echo esc_html( $report_title ); ?></title>
    <link rel="stylesheet" id="nooshika_fonts_css-css"
          href="/wp-content/plugins/nooshika-main/assets/css/nooshika-fonts.css?ver=5.4.0"
          media="all">
    <style>
        @page {
            size: A4 portrait;
            margin: 10mm;
        }
        
        * {
            box-sizing: border-box;
        }
        
        body {
            direction: rtl;
            margin: 2mm;
            background: #fff;
            color: #111;
            font-size: 12px;
            line-height: 1.8;
        }
        
        .print-page {
            width: 100%;
            min-height: 277mm;
            padding: 0;
            page-break-after: always;
        }
        
        .print-page:last-child {
            page-break-after: auto;
        }
        
        .factor-header {
            display: grid;
            grid-template-columns: 120px 1fr 170px;
            gap: 12px;
            align-items: start;
            margin-bottom: 8px;
        }
        
        .factor-logo img {
            max-width: 100px;
            max-height: 70px;
            object-fit: contain;
        }
        
        .factor-title {
            text-align: center;
            font-size: 17px;
            font-weight: 700;
            padding-top: 8px;
        }
        
        .factor-meta {
            text-align: right;
            font-size: 12px;
            line-height: 2;
        }
        
        .customer-box {
            border: 1px solid #222;
            border-radius: 7px;
            padding: 10px 10px;
            margin-bottom: 8px;
            font-weight: 700;
            position: relative;
        }
        
        .customer-box .side-label {
            position: absolute;
            left: 0;
            top: 0;
            bottom: 0;
            writing-mode: vertical-rl;
            transform: rotate(180deg);
            border-left: 1px solid #222;
            background: #e7e7e7;
            padding: 5px 3px;
            font-size: 11px;
            border-radius: 0 7px 7px 0;
            text-align: center;
        }
        
        .summary-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 8px;
            margin-bottom: 8px;
        }
        
        .summary-card {
            border: 1px solid #222;
            border-radius: 7px;
            padding: 6px 8px;
            text-align: center;
        }
        
        .summary-card .label {
            font-size: 11px;
            font-weight: 700;
        }
        
        .summary-card .value {
            font-size: 13px;
            font-weight: 700;
            direction: ltr;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .factor-table th,
        .factor-table td {
            border: 1px solid #222;
            padding: 4px 6px;
            vertical-align: middle;
        }
        
        .factor-table th {
            background: #d9d9d9;
            font-weight: 700;
            text-align: center;
        }
        
        .factor-table td {
            text-align: center;
        }
        
        .factor-table .desc {
            text-align: right;
        }
        
        .factor-table .ltr {
            direction: ltr;
            text-align: left;
        }
        
        .summary-row td {
            background: #d9d9d9;
            font-weight: 700;
        }
        
        .status-label {
            display: inline-block;
            min-width: 70px;
            padding: 1px 6px;
            border: 1px solid #222;
            border-radius: 12px;
            background: #f2f2f2;
            font-size: 11px;
            font-weight: 700;
        }
        
        .text-success {
            color: #047857;
        }
        
        .text-danger {
            color: #b91c1c;
        }
        
        .signatures {
            display: grid;
            grid-template-columns: 1fr 1fr;
            margin-top: 30px;
            text-align: center;
            font-weight: 700;
        }
        
        .footer-note {
            margin-top: 25px;
            text-align: center;
            font-size: 10px;
            font-weight: 700;
        }
        
        .print-actions {
            position: fixed;
            top: 12px;
            left: 12px;
            z-index: 99;
        }
        
        .print-actions button {
            border: 0;
            background: #111827;
            color: #fff;
            border-radius: 7px;
            padding: 8px 14px;
            cursor: pointer;
            font-family: inherit;
        }
        
        @media print {
            .print-actions {
                display: none;
            }
            
            body {
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
        }
    </style>
</head>
<body>

<div class="print-actions">
    <button onclick="window.print()">پرینت</button>
</div>

<section class="print-page">
    <div class="factor-header">
        <div class="factor-logo"></div>

        <div class="factor-title">
			<?php echo esc_html( $report_title ); ?>
        </div>

        <div class="factor-meta">
            <div>تاریخ چاپ: <?php echo esc_html( date_i18n( 'Y/m/d' ) ); ?></div>
            <div>تعداد پرداخت: <?php echo esc_html( number_format( count( $payments ) ) ); ?></div>
            <div>بازه: <?php echo esc_html( $range_label ); ?></div>
        </div>
    </div>

    <div class="customer-box">
        <span class="side-label">پرداخت</span>
        طرف حساب: <?php echo esc_html( $customer_title ); ?>
    </div>

    <div class="summary-grid">
        <div class="summary-card">
            <div class="label">جمع دریافت</div>
            <div class="value text-success"><?php echo esc_html( kph_print_money( $total_in ) ); ?> ریال</div>
        </div>

        <div class="summary-card">
            <div class="label">جمع پرداخت</div>
            <div class="value text-danger"><?php echo esc_html( kph_print_money( $total_out ) ); ?> ریال</div>
        </div>

        <div class="summary-card">
            <div class="label">جمع کل گردش</div>
            <div class="value"><?php echo esc_html( kph_print_money( $total_abs ) ); ?> ریال</div>
        </div>

        <div class="summary-card">
            <div class="label">خالص</div>
            <div class="value <?php echo esc_attr( $net < 0 ? 'text-success' : 'text-danger' ); ?>">
				<?php echo esc_html( kph_print_money( abs( $net ) ) ); ?> ریال
            </div>
        </div>
    </div>

    <table class="factor-table">
        <thead>
        <tr>
            <th style="width: 35px;">ردیف</th>
			<?php if ( ! $user_id ) { ?>
                <th style="width: 125px;">طرف حساب</th>
			<?php } ?>
            <th style="width: 80px;">تاریخ</th>
            <th style="width: 90px;">نوع</th>
            <th style="width: 90px;">روش پرداخت</th>
            <th style="width: 120px;">مبلغ</th>
            <th style="width: 75px;">فاکتور</th>
            <th style="width: 100px;">ثبت‌کننده</th>
            <th>یادداشت</th>
        </tr>
        </thead>

        <tbody>
		<?php
		$row = 1;
		foreach ( $payments as $payment ) {
			$payment_id = (int) $payment['id'];
            $freight = $DB->freight_payment($payment_id);
            if($freight && !$DB->freight_allowed()){wp_die('اجازه مشاهده کرایه مشتریان را ندارید.','',['response'=>403]);}
			$amount     = (float) $payment['amount'];
			
			$method = (string) ( $payment['payment_method'] ?? 'other' );
			
			$creator_id = (int) $DB->get_payment_meta( $payment_id, 'creator_id' );
			$creator    = $creator_id ? kph_print_user_name( $creator_id ) : '-';
			
			$payment_user_id = (int) ( $payment['user_id'] ?? 0 );
			
			$attachment     = $DB->get_payment_meta( $payment_id, 'attachment' );
			$has_attachment = ! empty( $attachment );
			?>
            <tr>
                <td><?php echo esc_html( $row ); ?></td>
				
				<?php if ( ! $user_id ) { ?>
                    <td class="desc"><?php echo esc_html( kph_print_user_name( $payment_user_id ) ); ?></td>
				<?php } ?>

                <td><?php echo esc_html( kph_print_date( $payment['paid_at'] ) ); ?></td>

                <td>
					<span class="status-label <?php echo esc_attr( kph_print_payment_direction_class( $amount ) ); ?>">
						<?php echo esc_html( ($freight ? 'کسر بابت کرایه' : kph_print_payment_direction_label( $amount )) ); ?>
					</span>
                </td>

                <td>
					<?php echo esc_html( ($freight ? 'پرداختی کرایه' : kph_print_payment_method_label( $method, $payment_methods )) ); ?>
                </td>

                <td class="ltr <?php echo esc_attr( kph_print_payment_direction_class( $amount ) ); ?>">
					<?php echo esc_html( kph_print_money( abs( $amount ) ) ); ?>
                </td>

                <td>
					<?php echo ! empty( $payment['ref_id'] ) ? esc_html( '#' . $payment['ref_id'] ) : '-'; ?>
                </td>

                <td><?php echo esc_html( $creator ); ?></td>

                <td class="desc">
					<?php
					echo wp_kses_post( ! empty( $payment['note'] ) ? nl2br( $payment['note'] ) : '-' );
					
					if ( $has_attachment ) {
						echo '<br><small>دارای ضمیمه</small>';
					}
					?>
                </td>
            </tr>
			<?php
			$row ++;
		}
		?>

        <tr class="summary-row">
            <td colspan="<?php echo $user_id ? 5 : 6; ?>">جمع دریافت</td>
            <td class="ltr text-success"><?php echo esc_html( kph_print_money( $total_in ) ); ?></td>
            <td colspan="2"></td>
        </tr>

        <tr class="summary-row">
            <td colspan="<?php echo $user_id ? 5 : 6; ?>">جمع پرداخت</td>
            <td class="ltr text-danger"><?php echo esc_html( kph_print_money( $total_out ) ); ?></td>
            <td colspan="2"></td>
        </tr>

        <tr class="summary-row">
            <td colspan="<?php echo $user_id ? 5 : 6; ?>">خالص</td>
            <td class="ltr <?php echo esc_attr( $net < 0 ? 'text-success' : 'text-danger' ); ?>">
				<?php echo esc_html( kph_print_money( abs( $net ) ) ); ?>
            </td>
            <td colspan="2"></td>
        </tr>
        </tbody>
    </table>

    <div class="signatures">
        <div>امضا واحد مالی</div>
        <div>امضا طرف حساب</div>
    </div>

    <div class="footer-note">
        این گزارش بر اساس پرداخت‌های ثبت‌شده در سیستم صادر شده است.
    </div>
</section>

</body>
</html>