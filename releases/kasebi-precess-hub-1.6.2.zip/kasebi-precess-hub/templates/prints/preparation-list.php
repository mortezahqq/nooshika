<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
$nonce = $request['_wpnonce'] ?? '';
if ( ! kph_preparation_print_allowed() || ! is_string( $nonce ) || ! wp_verify_nonce( $nonce, 'kph_preparation_print' ) ) {
    wp_die( 'برای چاپ لیست آماده‌سازی، پیش‌فاکتورها را در پنل انتخاب و از دکمه چاپ استفاده کنید.', '', [ 'response' => 403 ] );
}
$DB = new kph_db();
$result = $DB->get_preparation_orders( is_array( $ids ?? NULL ) ? $ids : [] );
if ( $result['status'] !== 'success' ) {
    wp_die( esc_html( $result['message'] ), '', [ 'response' => (int) ( $result['data']['http_status'] ?? 400 ) ] );
}
$orders = $result['data'];
$row_number = 0;
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>لیست آماده‌سازی پیش‌فاکتورها</title>
    <link rel="stylesheet" href="/wp-content/plugins/nooshika-main/assets/css/nooshika-fonts.css" media="all">
<style>
        @page { size: A4 landscape; margin: 12mm; }
        body {  color: #111; line-height: 1.8; margin: 24px; }
        h1 { font-size: 22px; } .controls { padding: 14px; background: #f5f5f5; margin-bottom: 20px; }
        .controls label { display: inline-block; margin: 0 0 8px 18px; }
        button { font: inherit; cursor: pointer; padding: 8px 16px; background: #fff; color: #111; border: 1px solid #888; border-radius: 0; }
        button:disabled { opacity: .5; cursor: default; } input { width: 18px; height: 18px; vertical-align: middle; }
        table { width: 100%; border-collapse: collapse; } th, td { border: 1px solid #aaa; padding: 7px; text-align: right; overflow-wrap: anywhere; }
        th { background: #f5f5f5; } tbody + tbody tr:first-child td { border-top-width: 2px; }
        .excluded { opacity: .4; } .numbers { text-align: center; white-space: nowrap; }
        @media print {
            .controls, .excluded { display: none !important; } body { color: black; margin: 0; }
            thead { display: table-header-group; } tr { break-inside: avoid; } th { background: white; }
        }
    </style>
</head>
<body>
    <div class="controls">
        <p>هر پیش‌فاکتور با تمام اقلامش چاپ می‌شود. در صورت نیاز انتخاب یک پیش‌فاکتور را بردارید.</p>
        <label><input id="preparation-all" type="checkbox" checked> انتخاب همه</label>
        <?php foreach ( $orders as $order ) : ?>
        <label><input class="preparation-order-toggle" type="checkbox" value="<?php echo esc_attr( $order['id'] ); ?>" checked> <?php echo esc_html( '#' . $order['id'] . ' — ' . kph_print_user_name( $order['customer_id'] ) ); ?></label>
        <?php endforeach; ?><br>
        <button type="button" id="preparation-print">پرینت / ذخیره PDF</button>
    </div>
    <h1>لیست آماده‌سازی پیش‌فاکتورها</h1>
    <p><span id="preparation-summary" role="status"></span> · تعداد آماده‌سازی شامل اقلام سفارش و هدیه است.</p>
    <table>
        <thead><tr><th>ردیف</th><th>شماره سفارش</th><th>مشتری</th><th>تاریخ سفارش</th><th>محصول</th><th>تعداد سفارش</th><th>هدیه</th><th>تعداد آماده‌سازی</th></tr></thead>
        <?php foreach ( $orders as $order ) : ?>
        <tbody data-preparation-order="<?php echo esc_attr( $order['id'] ); ?>">
            <?php foreach ( $order['items'] as $item ) : $row_number++; ?>
            <tr>
                <td class="numbers preparation-row-number"><?php echo esc_html( $row_number ); ?></td>
                <td class="numbers"><?php echo esc_html( $order['id'] ); ?></td>
                <td><?php echo esc_html( kph_print_user_name( $order['customer_id'] ) ); ?></td>
                <td class="numbers"><?php echo esc_html( kph_print_date( $order['created_at'] ) ); ?></td>
                <td><?php echo esc_html( $item['product_title'] ); ?></td>
                <td class="numbers"><?php echo esc_html( number_format( $item['qty_ordered'] ) ); ?></td>
                <td class="numbers"><?php echo esc_html( number_format( $item['free_qty'] ) ); ?></td>
                <td class="numbers"><?php echo esc_html( number_format( $item['preparation_qty'] ) ); ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
        <?php endforeach; ?>
    </table>
    <noscript>برای چاپ فقط موارد انتخاب‌شده، جاوااسکریپت مرورگر را فعال کنید.</noscript>
    <script>
    (() => {
        const toggles = Array.from(document.querySelectorAll('.preparation-order-toggle'));
        const all = document.getElementById('preparation-all');
        const print = document.getElementById('preparation-print');
        const format = new Intl.NumberFormat('fa-IR');
        function update() {
            let selected = 0, rows = 0;
            toggles.forEach(toggle => {
                const group = document.querySelector('[data-preparation-order="' + toggle.value + '"]');
                group.classList.toggle('excluded', !toggle.checked);
                if (toggle.checked) {
                    selected++;
                    group.querySelectorAll('.preparation-row-number').forEach(cell => { cell.textContent = format.format(++rows); });
                }
            });
            all.checked = selected === toggles.length;
            all.indeterminate = selected > 0 && selected < toggles.length;
            print.disabled = selected === 0;
            document.getElementById('preparation-summary').textContent = format.format(selected) + ' پیش‌فاکتور · ' + format.format(rows) + ' قلم';
        }
        toggles.forEach(toggle => toggle.addEventListener('change', update));
        all.addEventListener('change', () => { toggles.forEach(toggle => { toggle.checked = all.checked; }); update(); });
        print.addEventListener('click', () => { if (!print.disabled) window.print(); });
        window.addEventListener('beforeprint', update);
        update();
    })();
    </script>
</body>
</html>
