<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * @var array $ids
 * @var int   $user_id
 * @var array $date
 * @var array $request
 */

$DB = new kph_db();

$ids     = isset( $ids ) && is_array( $ids ) ? array_map( 'absint', $ids ) : [];
$user_id = isset( $user_id ) ? absint( $user_id ) : 0;

$date_from = trim( $date['from'] ?? '' );
$date_to   = trim( $date['to'] ?? '' );

$statuses = $DB->get_cheque_statuses();

$cheques = [];

if ( ! empty( $ids ) ) {
	foreach ( $ids as $cheque_id ) {
		$cheque = $DB->get_cheque( $cheque_id );
		
		if ( ! empty( $cheque ) && empty( $cheque['status'] ) === FALSE ) {
			$cheques[] = $cheque;
		}
	}
} else {
	if ( ! $user_id && ! $date_from && ! $date_to ) {
		wp_die( 'برای پرینت چک‌ها باید شناسه چک، کاربر یا بازه تاریخی مشخص شود.' );
	}
	
	$res = $DB->get_cheques( [
		'user_id'   => $user_id,
		'page'      => 1,
		'per_page'  => 5000,
		'date_from' => $date_from ?: NULL,
		'date_to'   => $date_to ?: NULL,
		'orderby'   => 'due_at',
		'order'     => 'ASC',
	] );
	
	$cheques = $res['items'] ?? [];
}

if ( empty( $cheques ) ) {
	wp_die( 'چکی برای پرینت یافت نشد.' );
}

$report_title = count( $cheques ) === 1 ? 'رسید چک' : 'گزارش چک‌ها';

$customer_title = $user_id ? kph_print_user_name( $user_id ) : 'همه کاربران';

$range_label = 'همه تاریخ‌ها';

if ( $date_from || $date_to ) {
	$range_label = trim( ( $date_from ?: 'ابتدا' ) . ' تا ' . ( $date_to ?: 'امروز' ) );
}

$total_amount  = 0;
$status_totals = [];

foreach ( $statuses as $status_key => $status_data ) {
	$status_totals[ $status_key ] = [
		'count'  => 0,
		'amount' => 0,
	];
}

foreach ( $cheques as $cheque ) {
	$amount = (float) ( $cheque['amount'] ?? 0 );
	$status = $cheque['status'] ?? '';
	
	$total_amount += $amount;
	
	if ( isset( $status_totals[ $status ] ) ) {
		$status_totals[ $status ]['count'] ++;
		$status_totals[ $status ]['amount'] += $amount;
	}
}

function kph_print_cheque_status_label( string $status, array $statuses ): string {
	return $statuses[ $status ]['label'] ?? $status;
}

function kph_print_cheque_party_name( array $cheque ): string {
	$user_id = 0;
	
	if ( ( $cheque['status'] ?? '' ) === 'endorsed' && ! empty( $cheque['current_holder_user_id'] ) ) {
		$user_id = (int) $cheque['current_holder_user_id'];
	} elseif ( ! empty( $cheque['user_id'] ) ) {
		$user_id = (int) $cheque['user_id'];
	}
	
	return $user_id ? kph_print_user_name( $user_id ) : '-';
}

?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title><?php echo esc_html( $report_title ); ?></title>
    <link rel="stylesheet" id="nooshika_fonts_css-css"
          href="/wp-content/plugins/nooshika-main/assets/css/nooshika-fonts.css?ver=5.4.0"
          media="all">
    <style>
        @page {
            size: A4 portrait;
            margin: 10mm;
        }
        
        * {
            box-sizing: border-box;
        }
        
        body {
            direction: rtl;
            margin: 2mm;
            background: #fff;
            color: #111;
            font-size: 12px;
            line-height: 1.8;
        }
        
        .print-page {
            width: 100%;
            min-height: 277mm;
            padding: 0;
            page-break-after: always;
        }
        
        .print-page:last-child {
            page-break-after: auto;
        }
        
        .print-header {
            display: grid;
            grid-template-columns: 120px 1fr 170px;
            gap: 12px;
            align-items: start;
            margin-bottom: 8px;
        }
        
        .print-logo img {
            max-width: 100px;
            max-height: 70px;
            object-fit: contain;
        }
        
        .print-title {
            text-align: center;
            font-size: 17px;
            font-weight: 700;
            padding-top: 8px;
        }
        
        .print-meta {
            text-align: right;
            font-size: 12px;
            line-height: 2;
        }
        
        .customer-box {
            border: 1px solid #222;
            border-radius: 7px;
            padding: 10px 10px;
            margin-bottom: 8px;
            font-weight: 700;
            position: relative;
        }
        
        .customer-box .side-label {
            position: absolute;
            left: 0;
            top: 0;
            bottom: 0;
            writing-mode: vertical-rl;
            transform: rotate(180deg);
            border-left: 1px solid #222;
            background: #e7e7e7;
            padding: 5px 3px;
            font-size: 11px;
            border-radius: 0 7px 7px 0;
            text-align: center;
        }
        
        .summary-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 8px;
            margin-bottom: 8px;
        }
        
        .summary-card {
            border: 1px solid #222;
            border-radius: 7px;
            padding: 6px 8px;
            text-align: center;
        }
        
        .summary-card .label {
            font-size: 11px;
            font-weight: 700;
        }
        
        .summary-card .value {
            font-size: 13px;
            font-weight: 700;
            direction: ltr;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .cheque-table th,
        .cheque-table td {
            border: 1px solid #222;
            padding: 4px 6px;
            vertical-align: middle;
        }
        
        .cheque-table th {
            background: #d9d9d9;
            font-weight: 700;
            text-align: center;
        }
        
        .cheque-table td {
            text-align: center;
        }
        
        .cheque-table .desc {
            text-align: right;
        }
        
        .cheque-table .ltr {
            direction: ltr;
            text-align: left;
        }
        
        .summary-row td {
            background: #d9d9d9;
            font-weight: 700;
        }
        
        .status-label {
            display: inline-block;
            min-width: 70px;
            padding: 1px 6px;
            border: 1px solid #222;
            border-radius: 12px;
            background: #f2f2f2;
            font-size: 11px;
            font-weight: 700;
        }
        
        .signatures {
            display: grid;
            grid-template-columns: 1fr 1fr;
            margin-top: 30px;
            text-align: center;
            font-weight: 700;
        }
        
        .footer-note {
            margin-top: 25px;
            text-align: center;
            font-size: 10px;
            font-weight: 700;
        }
        
        .print-actions {
            position: fixed;
            top: 12px;
            left: 12px;
            z-index: 99;
        }
        
        .print-actions button {
            border: 0;
            background: #111827;
            color: #fff;
            border-radius: 7px;
            padding: 8px 14px;
            cursor: pointer;
            font-family: inherit;
        }
        
        @media print {
            .print-actions {
                display: none;
            }
            
            body {
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
        }
    </style>
</head>
<body>

<div class="print-actions">
    <button onclick="window.print()">پرینت</button>
</div>

<section class="print-page">
    <div class="print-header">
        <div class="print-logo"></div>

        <div class="print-title">
			<?php echo esc_html( $report_title ); ?>
        </div>

        <div class="print-meta">
            <div>تاریخ چاپ: <?php echo esc_html( date_i18n( 'Y/m/d' ) ); ?></div>
            <div>تعداد چک: <?php echo esc_html( number_format( count( $cheques ) ) ); ?></div>
            <div>بازه: <?php echo esc_html( $range_label ); ?></div>
        </div>
    </div>

    <div class="customer-box">
        <span class="side-label">گزارش</span>
        طرف حساب: <?php echo esc_html( $customer_title ); ?>
    </div>

    <div class="summary-grid">
        <div class="summary-card">
            <div class="label">جمع کل چک‌ها</div>
            <div class="value"><?php echo esc_html( kph_print_money( $total_amount ) ); ?> ریال</div>
        </div>

        <div class="summary-card">
            <div class="label">در اختیار</div>
            <div class="value">
				<?php echo esc_html( number_format( $status_totals['in_hand']['count'] ?? 0 ) ); ?>
                /
				<?php echo esc_html( kph_print_money( $status_totals['in_hand']['amount'] ?? 0 ) ); ?>
            </div>
        </div>

        <div class="summary-card">
            <div class="label">وصول شده</div>
            <div class="value">
				<?php echo esc_html( number_format( $status_totals['cleared']['count'] ?? 0 ) ); ?>
                /
				<?php echo esc_html( kph_print_money( $status_totals['cleared']['amount'] ?? 0 ) ); ?>
            </div>
        </div>

        <div class="summary-card">
            <div class="label">برگشتی</div>
            <div class="value">
				<?php echo esc_html( number_format( $status_totals['bounced']['count'] ?? 0 ) ); ?>
                /
				<?php echo esc_html( kph_print_money( $status_totals['bounced']['amount'] ?? 0 ) ); ?>
            </div>
        </div>
    </div>

    <table class="cheque-table">
        <thead>
        <tr>
            <th style="width: 35px;">ردیف</th>
            <th style="width: 120px;">طرف حساب</th>
            <th style="width: 95px;">شناسه صیادی</th>
            <th style="width: 95px;">شماره سریال</th>
            <th style="width: 95px;">بانک</th>
            <th style="width: 90px;">صاحب حساب</th>
            <th style="width: 75px;">سررسید</th>
            <th style="width: 115px;">مبلغ</th>
            <th style="width: 75px;">وضعیت</th>
            <th style="width: 70px;">فاکتور</th>
            <th>یادداشت</th>
        </tr>
        </thead>

        <tbody>
		<?php
		$row = 1;
		foreach ( $cheques as $cheque ) {
			$cheque_id   = (int) $cheque['id'];
			$status      = (string) ( $cheque['status'] ?? '' );
			$status_text = kph_print_cheque_status_label( $status, $statuses );
			
			$bank_branch = $DB->get_cheque_meta( $cheque_id, 'bank_branch' );
			$bank_owner  = $DB->get_cheque_meta( $cheque_id, 'bank_owner' );
			$invoice_id  = $DB->get_cheque_meta( $cheque_id, 'invoice_id' );
			
			$bank_text = trim( ( $cheque['bank_name'] ?? '' ) . ( $bank_branch ? ' - ' . $bank_branch : '' ) );
			?>
            <tr>
                <td><?php echo esc_html( $row ); ?></td>

                <td class="desc">
					<?php echo esc_html( kph_print_cheque_party_name( $cheque ) ); ?>
                </td>

                <td class="ltr"><?php echo esc_html( $cheque['sayad_id'] ?: '-' ); ?></td>

                <td class="ltr"><?php echo esc_html( $cheque['cheque_no'] ?: '-' ); ?></td>

                <td><?php echo esc_html( $bank_text ?: '-' ); ?></td>

                <td><?php echo esc_html( $bank_owner ?: '-' ); ?></td>

                <td><?php echo esc_html( kph_print_date( $cheque['due_at'] ) ); ?></td>

                <td class="ltr">
					<?php echo esc_html( kph_print_money( $cheque['amount'] ) ); ?>
                </td>

                <td>
                    <span class="status-label"><?php echo esc_html( $status_text ); ?></span>
                </td>

                <td>
					<?php echo $invoice_id ? esc_html( '#' . $invoice_id ) : '-'; ?>
                </td>

                <td class="desc">
					<?php echo wp_kses_post( ! empty( $cheque['note'] ) ? nl2br( $cheque['note'] ) : '-' ); ?>
                    <?php if ( current_user_can( 'manage_options' ) && (string) $DB->get_cheque_meta( $cheque_id, 'admin_note_print' ) === '1' ) {
                        $private_note = $DB->get_cheque_meta( $cheque_id, 'admin_note' );
                        if ( is_string( $private_note ) && $private_note !== '' ) { ?>
                        <div class="mt-2"><strong>یادداشت داخلی:</strong><br><?php echo nl2br( esc_html( $private_note ) ); ?></div>
                    <?php } } ?>
                </td>
            </tr>
			<?php
			$row ++;
		}
		?>

        <tr class="summary-row">
            <td colspan="7">جمع کل</td>
            <td class="ltr"><?php echo esc_html( kph_print_money( $total_amount ) ); ?></td>
            <td colspan="3"></td>
        </tr>
        </tbody>
    </table>

    <div class="signatures">
        <div>امضا واحد مالی</div>
        <div>امضا طرف حساب</div>
    </div>

    <div class="footer-note">
        این گزارش بر اساس چک‌های ثبت‌شده در سیستم صادر شده است.
    </div>
</section>

</body>
</html>