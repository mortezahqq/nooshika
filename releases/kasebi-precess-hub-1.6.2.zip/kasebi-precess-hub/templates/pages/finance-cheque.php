<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
$per_page_key = basename( __FILE__, '.php' );
$per_page_key = "kph_{$per_page_key}_per_page";
$user_id      = get_current_user_id();
$defaults     = [
	'status'      => 'in_hand',
	'sayad_id'    => '',
	'cheque_no'   => '',
	'page_number' => 1,
	'per_page'    => get_user_meta( $user_id, $per_page_key, TRUE ) ?: 20,
	
	'date' => [
		'from' => '',
		'to'   => '',
	],
];
$args         = wp_parse_args( $_REQUEST, $defaults );
$args         = array_map( fn( $v ) => $v == 0 ? '' : $v, $args );
$has_filter   = kph_page_has_filter( $args, $defaults );
extract( $args );
update_user_meta( $user_id, $per_page_key, $per_page );

$date_from   = $date['from'] ?? '';
$date_to     = $date['to'] ?? '';
$sayad_id    = nooshika_sanitize_numbers( $sayad_id );
$cheque_no   = nooshika_sanitize_numbers( $cheque_no );
$DB          = new kph_db();
$statuses    = $DB->get_cheque_statuses();
$cheques     = $DB->get_cheques( [
	'page'      => $page_number,
	'per_page'  => $per_page,
	'status'    => $status,
	'sayad_id'  => $sayad_id,
	'cheque_no' => $cheque_no,
	'date_from' => $date_from ? nooshika_jalali_to_gregorian( $date_from ) : NULL,
	'date_to'   => $date_to ? nooshika_jalali_to_gregorian( $date_to ) : NULL,
] );
$total_page  = $cheques['pagination']['total_page'];
$total_items = $cheques['pagination']['total'];
$cheques     = $cheques['items'];
$accounts    = $DB->get_accounts( [
	'page'     => 1,
	'per_page' => 100,
] );
$accounts    = $accounts['items'];

$needs = [
	'accounts' => [
		'type'    => 'select',
		'label'   => 'انتخاب حساب',
		'key'     => 'target_account',
		'options' => [],
	],
];
foreach ( $accounts as $entry ) {
	$needs['accounts']['options'][] = [
		'id'    => $entry['id'],
		'label' => $entry['title'],
	];
}
$needs = array_values( $needs );
?>
<div class="nk-block-head nk-block-head-sm">
    <div class="nk-block-between">
        <div class="nk-block-head-content">
            <h3 class="nk-block-title page-title">لیست چک ها</h3>
            <div class="nk-block-des text-soft">
                <p class="mb-0">شما در مجموع <?php echo $total_items; ?> چک دارید.</p>
            </div>
        </div>
        <div class="nk-block-head-content">
            <div class="toggle-wrap nk-block-tools-toggle">
                <div class="toggle-expand-content">
                    <ul class="nk-block-tools g-3">
                        <li class="nk-block-tools-opt">
                            <a href="#" class="btn btn-icon btn-primary print_list_items" data-type="cheques"
                               data-collect="ids">
                                <em class="icon ni ni-printer"></em></a>
                        </li>
                        <li class="nk-block-tools-opt">
                            <a href="#addCheque" class=" btn btn-icon btn-primary" data-bs-target="#addCheque"
                               data-bs-toggle="modal"><em class="icon ni ni-plus"></em></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="nk-block">
    <div class="card card-stretch">
        <div class="card-inner-group">
            <div class="card-inner position-relative card-tools-toggle">
                <div class="card-title-group">
                    <div class="card-tools">
                    </div>
                    <div class="card-tools">
                        <ul class="btn-toolbar gx-1">
                            <li>
								<?php
								$filter_fields = [
									[
										'type'  => 'date-range',
										'label' => 'تاریخ سررسید چک',
										'name'  => 'date',
										'value' => [
											'from' => $date_from ?? '',
											'to'   => $date_to ?? '',
										],
									],
									[
										'type'  => 'text',
										'label' => 'شناسه صیادی',
										'name'  => 'sayad_id',
										'value' => $sayad_id,
									],
									[
										'type'  => 'text',
										'label' => 'سریال چک',
										'name'  => 'cheque_no',
										'value' => $cheque_no,
									],
									[
										'type'  => 'hidden',
										'name'  => 'status',
										'value' => $status,
									],
								];
								echo kph_get_template( 'components/filter-dropdown.php', [
									'has_filter'    => $has_filter,
									'filter_fields' => $filter_fields,
								] );
								?>
                            </li>
                            <li class="btn-toolbar-sep"></li>
                            <li>
								<?php
								echo kph_get_template( 'components/per-page-selector.php', [
									'per_page' => $per_page,
								] );
								?>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="card-inner p-0">
                <div class="nk-tb-list nk-tb-ulist is-compact">
                    <div class="nk-tb-item nk-tb-head">
                        <div class="nk-tb-col nk-tb-col-check"></div>
						<?php
						if ( $status == 'endorsed' ) {
							?>
                            <div class="nk-tb-col"><span class="sub-text">واگذار شده به:</span></div>
							<?php
						} else {
							?>
                            <div class="nk-tb-col"><span class="sub-text">صاحب چک</span></div>
							<?php
						}
						?>
                        <div class="nk-tb-col"><span class="sub-text">شناسه صیادی</span></div>
                        <div class="nk-tb-col"><span class="sub-text">سریال چک</span></div>
                        <div class="nk-tb-col"><span class="sub-text">سررسید چک</span></div>
                        <div class="nk-tb-col"><span class="sub-text">مقدار</span></div>
                        <div class="nk-tb-col"><span class="sub-text">وضعیت</span></div>
                        <div class="nk-tb-col text-end nk-tb-col-tools"></div>
                    </div>
					<?php
					if ( empty( $cheques ) ) {
						echo '<div class="no-item-found">چکی یافت نشد</div>';
					} else {
						foreach ( $cheques as $entry ) {
							$date          = date_i18n( 'Y/m/d', strtotime( $entry['due_at'] ) );
							$amount        = number_format( $entry['amount'] );
							$note          = $entry['note'];
							$cheque_status = $statuses[ $entry['status'] ];
							$attachment    = $DB->get_cheque_meta( $entry['id'], 'attachment' );
							$bank_branch   = $DB->get_cheque_meta( $entry['id'], 'bank_branch' );
							$bank_owner    = $DB->get_cheque_meta( $entry['id'], 'bank_owner' );
							$invoice_id    = $DB->get_cheque_meta( $entry['id'], 'invoice_id' );
							$user_id       = 0;
							?>
                            <div class="nk-tb-item">
                                <div class="nk-tb-col nk-tb-col-check">
                                    <div class="custom-control custom-control-sm custom-checkbox notext">
                                        <input type="checkbox" class="custom-control-input select_item_for_print"
                                               value="<?php echo $entry['id']; ?>"
                                               id="print_item_<?php echo $entry['id']; ?>">
                                        <label class="custom-control-label"
                                               for="print_item_<?php echo $entry['id']; ?>"></label>
                                    </div>
                                </div>
								<?php
								if ( $entry['status'] == 'endorsed' ) {
									$user_id = $entry['current_holder_user_id'];
									?>
                                    <div class="nk-tb-col">
										<?php
										echo kph_get_template( 'components/user-card.php', [
											'user_id'    => $entry['current_holder_user_id'],
											'show_phone' => TRUE,
										] );
										?>
                                    </div>
									<?php
								} else {
									$user_id = $entry['user_id'];
									?>
                                    <div class="nk-tb-col">
										<?php
										echo kph_get_template( 'components/user-card.php', [
											'user_id'    => $entry['user_id'],
											'show_phone' => TRUE,
										] );
										?>
                                    </div>
									<?php
								}
								?>
                                <div class="nk-tb-col"><span><?php echo $entry['sayad_id']; ?></span><?php echo kph_get_template( 'components/cheque-admin-note.php', [ 'DB' => $DB, 'cheque_id' => $entry['id'] ] ); ?></div>
                                <div class="nk-tb-col"><span><?php echo $entry['cheque_no']; ?></span></div>
                                <div class="nk-tb-col">
                                    <span><?php echo $date; ?></span>
                                </div>
                                <div class="nk-tb-col">
                                    <div class="amount">
                                        <span><?php echo $amount; ?></span>
                                    </div>
                                </div>
                                <div class="nk-tb-col">
                                    <span
                                        class="badge <?= $cheque_status['class']; ?>"><?php echo $cheque_status['label']; ?></span>
                                </div>
                                <div class="nk-tb-col">
                                    <ul class="nk-tb-actions gx-2">
										<?php
										$hidden_actions = [
											[
												'link'  => "",
												'title' => $entry['bank_name'] . ( $bank_branch ? ' - ' . $bank_branch : '' ),
												'icon'  => 'ni-server',
											],
											[
												'link'  => '',
												'title' => 'تاریخچه گردش چک',
												'class' => 'load_cheque_moves_table',
												'icon'  => 'ni-repeat',
												'data'  => [
													'cheque-id' => $entry['id'],
												],
											],
										];
										if ( $invoice_id ) {
											$hidden_actions[] = [
												'link'  => "",
												'title' => "فاکتور #$invoice_id",
												'icon'  => 'ni-file-text',
											];
										}
										echo kph_get_template( 'components/row-actions.php', [
											'actions' => $hidden_actions,
										] );
										if ( $note ) {
											?>
                                            <li class="nk-tb-action">
                                                <div class="btn btn-sm btn-icon btn-trigger"
                                                     data-bs-toggle="popover"
                                                     data-bs-trigger="hover"
                                                     data-bs-html="true"
                                                     title="یادداشت"
                                                     data-bs-content="<?php echo wpautop( $note ); ?>"
                                                     data-bs-placement="top">
                                                    <em class="icon ni ni-note-add-c"></em>
                                                </div>
                                            </li>
											<?php
										}
										if ( $attachment ) {
											$attachment = explode( ',', $attachment );
											?>
                                            <li class="nk-tb-action">
												<?php
												$actions = [];
												foreach ( $attachment as $url ) {
													$file_data = $DB->get_uploaded_file_data( $url );
													if ( ! $file_data ) {
														$file_name = $url;
													} else {
														$file_name = $file_data['original_name'];
													}
													$actions[] = [
														'link'     => $url,
														'title'    => $file_name,
														'icon'     => 'ni-download',
														'target'   => '_blank',
														'download' => TRUE,
													];
												}
												echo kph_get_template( 'components/row-actions-dropdown.php', [
													'actions'   => $actions,
													'main_icon' => 'file-docs',
													'title'     => 'فایل ضمیمه',
												] );
												?>
                                            </li>
											<?php
										}
										?>
                                        <li>
											<?php
											$actions = [
												[
													'link'  => '/crm/user/' . $user_id,
													'title' => 'مشخصات مشتری',
													'icon'  => 'ni-eye',
													'class' => 'page_activator',
												],
												[
													'link'  => '/crm/user/' . $user_id . '?tab=financial',
													'title' => 'تاریخچه حسابداری',
													'icon'  => 'ni-coin-alt',
													'class' => 'page_activator',
												],
											];
											if ( $entry['status'] == 'in_hand' || $entry['status'] == 'bounced' ) {
												$actions['cleared'] = [
													'title' => 'وصول چک',
													'icon'  => 'ni-check-round-cut',
													'class' => 'populate_modal_inputs',
													'data'  => [
														'modal' => '#addChequeToAccount',
														'set'   => esc_attr( wp_json_encode(
															[
																'#cheque_to_account_cheque_id'               => $entry['id'],
																'#cost_transaction_cheque_id'                => $entry['id'],
																'#cheque_to_account_cost_transaction_amount' => $amount,
															]
														) ),
													],
												];
											}
											if ( $entry['status'] == 'in_hand' ) {
												$actions['bounced'] = [
													'title' => 'برگشت چک',
													'icon'  => 'ni-na',
													'class' => 'change_cheque_status',
													'data'  => [
														'cheque-id' => $entry['id'],
														'status'    => 'bounce',
													],
												];
											}
											$actions['delete'] = [
												'title' => 'حذف چک',
												'icon'  => 'ni-trash',
												'class' => 'delete_db_item',
												'data'  => [
													'page'    => '/crm/finance-cheque',
													'item_id' => $entry['id'],
													'status'  => $status,
													'action'  => 'kph_delete_cheque',
												],
											];
											echo kph_get_template( 'components/row-actions-dropdown.php', [
												'actions' => $actions,
											] );
											?>
                                        </li>
                                    </ul>
                                </div>
                            </div>
							<?php
						}
					}
					?>
                </div>
            </div>
            <div class="card-inner">
				<?php
				echo kph_get_template( 'components/pagination.php', [
					'max_page_num' => $total_page,
					'current_page' => $page_number,
					'class_name'   => 'user_pagination_link',
					'show_count'   => 2,
				] );
				?>
            </div>
        </div>
    </div>
</div>

