<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
$user_id    = get_current_user_id();
$defaults   = [
	'type' => '',
];
$args       = wp_parse_args( $_REQUEST, $defaults );
$args       = array_map( fn( $v ) => $v == 0 ? '' : $v, $args );
$has_filter = kph_page_has_filter( $args, $defaults );
extract( $args );

$DB       = new kph_db();
$types    = $DB->get_account_types();
$accounts = $DB->get_accounts( [
	'page'     => 1,
	'per_page' => 100,
	'type'     => $type,
] );
$accounts = $accounts['items'];

?>
<div class="nk-block-head nk-block-head-sm">
    <div class="nk-block-between">
        <div class="nk-block-head-content">
            <h3 class="nk-block-title page-title">لیست حساب های مجموعه</h3>
            <div class="nk-block-des text-soft">
                <p class="mb-0">شما در مجموع <?php echo $total_items; ?> حساب دارید.</p>
            </div>
        </div>
        <div class="nk-block-head-content">
            <div class="toggle-wrap nk-block-tools-toggle">
                <div class="toggle-expand-content">
                    <ul class="nk-block-tools g-3">
                        <li class="nk-block-tools-opt">
                            <a href="#addAccount" class=" btn btn-icon btn-primary" data-bs-target="#addAccount"
                               data-bs-toggle="modal"><em class="icon ni ni-plus"></em></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="nk-block">
    <div class="card card-stretch">
        <div class="card-inner-group">
            <div class="card-inner position-relative card-tools-toggle">
                <div class="card-title-group">
                    <div class="card-tools">
                    </div>
                    <div class="card-tools">
                        <ul class="btn-toolbar gx-1">
                            <li>
								<?php
								$filter_fields = [
									[
										'type'    => 'select',
										'label'   => 'نوع حساب',
										'name'    => 'type',
										'value'   => $type,
										'options' => [ 0 => 'همه موارد' ] + array_combine(
												array_keys( $types ),
												array_column( $types, 'label' )
											),
									],
								];
								
								echo kph_get_template( 'components/filter-dropdown.php', [
									'has_filter'    => $has_filter,
									'filter_fields' => $filter_fields,
								] );
								?>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="card-inner p-0">
                <div class="nk-tb-list nk-tb-ulist is-compact">
                    <div class="nk-tb-item nk-tb-head">
                        <div class="nk-tb-col"><span class="sub-text">تاریخ ایجاد</span></div>
                        <div class="nk-tb-col"><span class="sub-text">نام حساب</span></div>
                        <div class="nk-tb-col"><span class="sub-text">مانده حساب</span></div>
                        <div class="nk-tb-col text-end nk-tb-col-tools"></div>
                    </div>
					<?php
					if ( empty( $accounts ) ) {
						echo '<div class="no-item-found">حسابی یافت نشد</div>';
					} else {
						foreach ( $accounts as $entry ) {
							$date    = date_i18n( 'Y/m/d', strtotime( $entry['created_at'] ) );
							$balance = number_format( $entry['balance'] );
							?>
                            <div class="nk-tb-item">
                                <div class="nk-tb-col">
                                    <span><?php echo $date; ?></span>
                                </div>
                                <div class="nk-tb-col"><span><?php echo $entry['title']; ?></span></div>
                                <div class="nk-tb-col">
                                    <div class="amount">
                                        <span><?php echo $balance; ?></span>
                                    </div>
                                </div>
                                <div class="nk-tb-col nk-tb-col-tools">
                                    <ul class="nk-tb-actions gx-2">
										<?php
										$hidden_actions = [];
										
										if ( $entry['bank_name'] ) {
											$hidden_actions[] = [
												'link'  => "",
												'title' => $entry['bank_name'],
												'icon'  => 'ni-server',
											];
										}
										if ( $entry['owner_name'] ) {
											$hidden_actions[] = [
												'link'  => "",
												'title' => $entry['owner_name'],
												'icon'  => 'ni-user-list-fill',
											];
										}
										if ( $entry['account_no'] ) {
											$hidden_actions[] = [
												'link'  => "",
												'title' => $entry['account_no'],
												'icon'  => 'ni-slack-hash',
											];
										}
										$hidden_actions[] = [
											'link'  => '/crm/finance-transactions/?account_id=' . $entry['id'],
											'title' => 'تاریخچه تراکنش ها',
											'icon'  => 'ni-swap-v',
											'class' => 'page_activator',
										];
										$hidden_actions[] = [
											'title' => 'ویرایش حساب',
											'icon'  => 'ni-edit',
											'class' => 'edit_item',
											'data'  => [
												'modal'      => 'addAccount',
												'account_id' => $entry['id'],
												'title'      => $entry['title'],
												'type'       => $entry['type'],
												'bank_name'  => $entry['bank_name'],
												'account_no' => $entry['account_no'],
												'owner_name' => $entry['owner_name'],
											],
										];
										$hidden_actions[] = [
											'title' => 'ثبت تراکنش جدید',
											'icon'  => 'ni-ticket-plus',
											'class' => 'populate_modal_inputs',
											'data'  => [
												'modal' => '#addAccountTransaction',
												'set'   => esc_attr( wp_json_encode(
													[
														'#new_transaction_account_id' => $entry['id'],
													]
												) ),
											],
										];
										echo kph_get_template( 'components/row-actions.php', [
											'actions' => $hidden_actions,
										] );
										
										?>
                                    </ul>
                                </div>
                            </div>
							<?php
						}
					}
					?>
                </div>
            </div>
        </div>
    </div>
</div>

