<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$per_page_key    = basename( __FILE__, '.php' );
$per_page_key    = "kph_{$per_page_key}_per_page";
$current_user_id = get_current_user_id();

$defaults = [
	'page_number'  => 1,
	'per_page'     => get_user_meta( $current_user_id, $per_page_key, TRUE ) ?: 20,
	'date'         => [
		'from' => '',
		'to'   => '',
	],
	'level'        => '',
	'balance_side' => '',
	'sort'         => 'purchase_amount',
	'search'       => '',
	'customer_id'  => 0,
];

$args       = wp_parse_args( array_intersect_key( $_REQUEST, $defaults ), $defaults );
$args       = array_map( fn( $v ) => $v == 0 ? '' : $v, $args );
$has_filter = kph_page_has_filter( $args, $defaults );

extract( $args );

update_user_meta( $current_user_id, $per_page_key, $per_page );

$selected_customer_id = is_scalar( $customer_id ) ? absint( $customer_id ) : 0;
$report_request       = $_REQUEST;
require dirname( __DIR__ ) . '/partials/customer-report-context.php';
$level        = $customer_report_args['level'];
$balance_side = $customer_report_args['balance_side'];
$search       = $customer_report_args['search'];
$sort         = $customer_report_args['sort'] ?: 'purchase_amount';
$page_number  = max( 1, (int) $page_number );
$per_page     = max( 1, min( 200, (int) $per_page ) );
$date_from    = $date['from'] ?? '';
$date_to      = $date['to'] ?? '';

$date_from_g = $customer_report_args['date_from'];
$date_to_g   = $customer_report_args['date_to'];

$DB              = new kph_db();
$customer_levels = $DB->get_customer_levels();

$report     = $DB->get_users_performance_report( [
	'date_from'    => $date_from_g,
	'date_to'      => $date_to_g,
	'level'        => $level,
	'balance_side' => $balance_side,
	'search'       => $search,
	'sort'         => $sort,
	'page'         => $page_number,
	'per_page'     => $per_page,
] );
$summary    = $report['summary'];
$items      = $report['items'];
$pagination = $report['pagination'];

$total_page  = $pagination['total_page'];
$total_items = $pagination['total'];

$selected_customer_id = absint( $customer_id );

$customer_rows = $selected_customer_id ? [
	[
		'user_id'      => $selected_customer_id,
		'display_name' => get_the_author_meta( 'display_name', $selected_customer_id ),
	],
] : $DB->get_all_customer_report_rows( $customer_report_args );
$receivables   = $DB->get_customer_report_aging( $customer_rows );
$invoices      = $selected_customer_id ? $DB->get_customer_invoice_report( $selected_customer_id, $customer_report_args ) : [];
require dirname( __DIR__ ) . '/partials/customer-report-style.php';

$balance_side_options = [
	0         => 'همه موارد',
	'debit'   => 'بدهکار',
	'credit'  => 'بستانکار',
	'settled' => 'تسویه',
];

$sort_options = [
	'purchase_amount'       => 'بیشترین خرید',
	'payment_amount'        => 'بیشترین پرداختی',
	'balance_amount'        => 'بیشترین مانده حساب',
	'bounced_cheque_amount' => 'بیشترین مبلغ چک برگشتی',
	'bounced_cheque_count'  => 'بیشترین تعداد چک برگشتی',
	'order_count'           => 'بیشترین تعداد سفارش',
	'ordered_qty'           => 'بیشترین تعداد کالا',
	'last_order_at'         => 'آخرین خرید',
];

if ( ! function_exists( 'kph_report_user_money' ) ) {
	function kph_report_user_money( $amount ): string {
		return number_format( abs( (float) $amount ) );
	}
}
if ( ! function_exists( 'kph_report_user_date' ) ) {
	function kph_report_user_date( $date ): string {
		if ( empty( $date ) ) {
			return '-';
		}
		
		return date_i18n( 'j M Y', strtotime( $date ) );
	}
}
?>
    <div class="nk-block-head nk-block-head-sm">
        <div class="nk-block-between">
            <div class="nk-block-head-content">
                <h3 class="nk-block-title page-title">گزارش مشتریان</h3>
                <div class="nk-block-des text-soft">
                    <p class="mb-0">گزارش عملکرد مشتریان بر اساس خرید، پرداختی، چک برگشتی و مانده حساب.</p>
                </div>
            </div>
            <div class="card-tools">
                <ul class="btn-toolbar gx-1">
                    <li><?php echo $customer_print_button( 'all', 'چاپ گزارش کامل' ); ?></li>
                    <li>
						<?php
						$filter_fields = [
							[
								'type'  => 'hidden',
								'name'  => 'customer_id',
								'value' => $selected_customer_id,
							],
							[
								'type'  => 'date-range',
								'label' => 'بازه گزارش',
								'name'  => 'date',
								'value' => [
									'from' => $date_from ?? '',
									'to'   => $date_to ?? '',
								],
							],
							[
								'type'    => 'select',
								'label'   => 'سطح مشتری',
								'name'    => 'level',
								'value'   => $level,
								'col'     => 6,
								'options' => [ 0 => 'همه موارد' ] + array_combine(
										array_keys( $customer_levels ),
										array_column( $customer_levels, 'label' )
									),
							],
							[
								'type'    => 'select',
								'label'   => 'وضعیت حساب',
								'name'    => 'balance_side',
								'value'   => $balance_side,
								'col'     => 6,
								'options' => $balance_side_options,
							],
							[
								'type'    => 'select',
								'label'   => 'مرتب‌سازی',
								'name'    => 'sort',
								'value'   => $sort,
								'col'     => 12,
								'options' => $sort_options,
							],
						];
						
						echo kph_get_template( 'components/filter-dropdown.php', [
							'has_filter'    => $has_filter,
							'filter_fields' => $filter_fields,
						] );
						?>
                    </li>
                    <li class="btn-toolbar-sep"></li>
                    <li>
						<?php
						echo kph_get_template( 'components/per-page-selector.php', [
							'per_page' => $per_page,
						] );
						?>
                    </li>
                </ul>
            </div>
        </div>
    </div>
<?php if ( $selected_customer_id ) { ?>
    <div class="nk-block-head">
        <div class="nk-block-between">
            <div><h4>ریز
                    فاکتورهای <?php echo esc_html( get_the_author_meta( 'display_name', $selected_customer_id ) ); ?></h4>
                <p class="text-soft">هر فاکتور، جمع برکت و نسخهٔ چاپ مستقل دارد.</p></div>
            <div><?php echo $customer_print_button( 'invoices', 'چاپ همه فاکتورها' ); ?>
                <a class="btn btn-light page_activator"
                   href="<?php echo esc_url( add_query_arg( $customer_filter_args, home_url( '/crm/reports-user' ) ) ); ?>">بازگشت
                    به گزارش کلی</a></div>
        </div>
    </div>
	<?php require dirname( __DIR__ ) . '/partials/customer-invoices-report.php'; ?>
	<?php require dirname( __DIR__ ) . '/partials/customer-receivables-report.php'; ?>
<?php } else {
	?>
    <div class="mb-3"><?php echo $customer_print_button( 'summary', 'چاپ خلاصهٔ عملکرد' ); ?></div>
    <div class="nk-block">
        <div class="row g-gs">
            <div class="col-md-3">
                <div class="card card-full">
                    <div class="card-inner">
                        <div class="card-title-group align-center mb-0">
                            <div class="card-title">
                                <h6 class="title">تعداد مشتریان</h6>
                            </div>
                            <div class="card-amount">
                                <div class="amount">
									<?php echo number_format( $summary['total_customers'] ); ?>
                                    <small class="currency currency-usd fs-12px">نفر</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card card-full">
                    <div class="card-inner">
                        <div class="card-title-group align-center mb-0">
                            <div class="card-title">
                                <h6 class="title">حجم کل خرید</h6>
                            </div>
                            <div class="card-amount">
                                <div class="amount">
									<?php echo number_format( $summary['total_purchase_amount'] ); ?>
                                    <small class="currency currency-usd fs-12px">ریال</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card card-full">
                    <div class="card-inner">
                        <div class="card-title-group align-center mb-0">
                            <div class="card-title">
                                <h6 class="title">مجموع پرداختی</h6>
                            </div>
                            <div class="card-amount">
                                <div class="amount text-success">
									<?php echo number_format( $summary['total_payment_amount'] ); ?>
                                    <small class="currency currency-usd fs-12px">ریال</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="card card-full">
                    <div class="card-inner">
                        <div class="card-title-group align-center mb-0">
                            <div class="card-title">
                                <h6 class="title">چک برگشتی</h6>
                            </div>
                            <div class="card-amount">
                                <div class="amount text-danger">
									<?php echo number_format( $summary['total_bounced_cheque_amount'] ); ?>
                                    <small class="currency currency-usd fs-12px">
                                        / <?php echo number_format( $summary['total_bounced_cheque_count'] ); ?> چک
                                    </small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card card-full">
                    <div class="card-inner">
                        <div class="card-title-group align-center mb-0">
                            <div class="card-title">
                                <h6 class="title">مجموع مانده بدهکاری</h6>
                            </div>
                            <div class="card-amount">
                                <div class="amount text-danger">
									<?php echo number_format( $summary['total_debit_balance'] ); ?>
                                    <small class="currency currency-usd fs-12px">ریال</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card card-full">
                    <div class="card-inner">
                        <div class="card-title-group align-center mb-0">
                            <div class="card-title">
                                <h6 class="title">مجموع مانده بستانکاری</h6>
                            </div>
                            <div class="card-amount">
                                <div class="amount text-success">
									<?php echo number_format( $summary['total_credit_balance'] ); ?>
                                    <small class="currency currency-usd fs-12px">ریال</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <div class="nk-block">
        <div class="card card-stretch">
            <div class="card-inner position-relative card-tools-toggle">
                <div class="card-title-group">
                    <div class="card-tools">
                        <div class="form-inline flex-nowrap gx-3">
                            <div class="form-wrap">
                                <input type="text"
                                       class="form-control form-control-sm search_kph_list"
                                       value="<?php echo esc_attr( $search ); ?>"
                                       placeholder="جستجوی مشتری، موبایل، ایمیل...">
                            </div>
                        </div>
                    </div>
                    <div class="card-tools">
						<?php echo $customer_print_button( 'customers', 'چاپ جدول مشتریان' ); ?>
                        <span class="sub-text">تعداد نتیجه: <?php echo number_format( $total_items ); ?></span>
                    </div>
                </div>
            </div>

            <div class="card-inner p-0 overflow-auto">
                <div class="nk-tb-list nk-tb-ulist is-compact">
                    <div class="nk-tb-item nk-tb-head">
                        <div class="nk-tb-col"><span class="sub-text">مشتری</span></div>
                        <div class="nk-tb-col"><span class="sub-text">سطح</span></div>
                        <div class="nk-tb-col"><span class="sub-text">خرید ثبت شده</span></div>
                        <div class="nk-tb-col"><span class="sub-text">پرداختی</span></div>
                        <div class="nk-tb-col"><span class="sub-text">چک برگشتی</span></div>
                        <div class="nk-tb-col"><span class="sub-text">مانده حساب</span></div>
                        <div class="nk-tb-col"><span class="sub-text">سررسید و دیرکرد فعلی</span></div>
                        <div class="nk-tb-col"><span class="sub-text">محصول پرتکرار</span></div>
                        <div class="nk-tb-col"><span class="sub-text">آخرین خرید</span></div>
                        <div class="nk-tb-col text-end nk-tb-col-tools"></div>
                    </div>
					
					<?php
					if ( empty( $items ) ) {
						echo '<div class="no-item-found">گزارشی یافت نشد</div>';
					} else {
						foreach ( $items as $entry ) {
							$user_id = (int) $entry['user_id'];
							$balance = (float) $entry['balance'];
							
							$balance_class = '';
							$balance_icon  = '';
							$balance_label = 'تسویه';
							
							if ( $balance > 0 ) {
								$balance_class = ' text-danger';
								$balance_icon  = 'ni-arrow-long-down';
								$balance_label = 'بدهکار';
							} elseif ( $balance < 0 ) {
								$balance_class = ' text-success';
								$balance_icon  = 'ni-arrow-long-up';
								$balance_label = 'بستانکار';
							}
							?>
                            <div class="nk-tb-item">
                                <div class="nk-tb-col">
									<?php
									echo kph_get_template( 'components/user-card.php', [
										'user_id'    => $user_id,
										'show_phone' => TRUE,
									] );
									?>
                                </div>

                                <div class="nk-tb-col">
                                    <select class="form-select form-select-sm js-select2 kph-report-user-level"
                                            data-user-id="<?php echo esc_attr( $user_id ); ?>">
                                        <option value="">بدون سطح</option>
										<?php foreach ( $customer_levels as $level_key => $level_data ) { ?>
                                            <option value="<?php echo esc_attr( $level_key ); ?>"
												<?php selected( $entry['customer_level'], $level_key ); ?>>
												<?php echo esc_html( $level_data['label'] ); ?>
                                            </option>
										<?php } ?>
                                    </select>
                                </div>

                                <div class="nk-tb-col">
                                    <span
                                        class="tb-amount"><?php echo number_format( $entry['purchase_amount'] ); ?></span>
                                    <span class="sub-text">
                                    <?php echo number_format( $entry['order_count'] ); ?> سفارش /
                                    <?php echo number_format( $entry['ordered_qty'] ); ?> کالا
                                </span>
                                </div>

                                <div class="nk-tb-col">
                                    <span
                                        class="tb-amount text-success"><?php echo number_format( $entry['payment_amount'] ); ?></span>
                                    <span class="sub-text"><?php echo $entry['payment_percent']; ?>٪ نسبت به خرید</span>
                                </div>

                                <div class="nk-tb-col">
                                    <span
                                        class="tb-amount text-danger"><?php echo number_format( $entry['bounced_cheque_amount'] ); ?></span>
                                    <span
                                        class="sub-text"><?php echo number_format( $entry['bounced_cheque_count'] ); ?> چک</span>
                                </div>

                                <div class="nk-tb-col">
                                    <div class="amount<?php echo esc_attr( $balance_class ); ?>">
                                        <span><?php echo number_format( abs( $balance ) ); ?></span>
										<?php
										if ( $balance_icon ) {
											echo "<em class='icon ni {$balance_icon}'></em>";
										}
										?>
                                    </div>
                                    <span class="sub-text"><?php echo esc_html( $balance_label ); ?></span>
                                </div>

                                <div class="nk-tb-col">
									<?php $customer_aging = $receivables[ $user_id ] ?? NULL; ?>
									<?php if ( $customer_aging && $customer_aging['overdue'] > 0 ) { ?>
                                        <span
                                            class="tb-amount text-danger"><?php echo number_format_i18n( $customer_aging['overdue'] ); ?> ریال دیرکرد</span>
									<?php } else { ?><span class="sub-text">بدون بدهی سررسیدگذشتهٔ مشخص</span><?php } ?>
									<?php if ( $customer_aging && $customer_aging['average_days'] !== NULL ) { ?>
                                        <span
                                            class="sub-text">میانگین: <?php echo esc_html( number_format_i18n( abs( $customer_aging['average_days'] ), 1 ) . ( $customer_aging['average_days'] < 0 ? ' روز دیرکرد' : ' روز مانده' ) ); ?></span>
									<?php } ?>
									<?php if ( $customer_aging && $customer_aging['unknown'] > 0 ) { ?><span
                                        class="sub-text">دارای فاکتور بدون سررسید</span><?php } ?>
                                </div>
                                <div class="nk-tb-col">
									<?php if ( $entry['top_product_id'] ) { ?>
                                        <span
                                            class="tb-lead"><?php echo esc_html( $entry['top_product_title'] ); ?></span>
                                        <span class="sub-text"><?php echo number_format( $entry['top_product_qty'] ); ?> عدد</span>
									<?php } else { ?>
                                        <span>-</span>
									<?php } ?>
                                </div>

                                <div class="nk-tb-col">
									<?php echo kph_report_user_date( $entry['last_order_at'] ); ?>
                                </div>

                                <div class="nk-tb-col nk-tb-col-tools">
                                    <ul class="nk-tb-actions gx-2">
										<?php
										echo kph_get_template( 'components/row-actions-hidden.php', [
											'actions' => [
												[
													'link'  => add_query_arg( array_merge( $customer_filter_args, [ 'customer_id' => $user_id ] ), '/crm/reports-user' ),
													'title' => 'ریز خرید محصولات',
													'icon'  => 'ni-list-thumb',
													'class' => 'page_activator',
												],
												[
													'link'  => '/crm/user/' . $user_id,
													'title' => 'مشاهده مشخصات',
													'icon'  => 'ni-eye',
													'class' => 'page_activator',
												],
												[
													'link'  => '/crm/user/' . $user_id . '?tab=financial',
													'title' => 'حسابداری',
													'icon'  => 'ni-coin-alt',
													'class' => 'page_activator',
												],
											],
										] );
										?>
                                    </ul>
                                </div>
                            </div>
							<?php
						}
					}
					?>
                </div>
            </div>

            <div class="card-inner">
				<?php
				echo kph_get_template( 'components/pagination.php', [
					'max_page_num' => $total_page,
					'current_page' => $page_number,
					'class_name'   => 'reports_user_pagination_link',
					'show_count'   => 2,
				] );
				?>
            </div>
        </div>
    </div>
	<?php require dirname( __DIR__ ) . '/partials/customer-receivables-report.php'; ?>
	<?php
}
